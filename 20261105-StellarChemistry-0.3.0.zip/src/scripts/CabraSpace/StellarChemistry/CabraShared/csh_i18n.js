// ============================================================================
// CabraShared/csh_i18n.js — EL IDIOMA, BASE COMUN (15-oct-2026)
// ----------------------------------------------------------------------------
// La interfaz se escribe en ingles y cada script lleva su tabla de castellano (CabraStars CS_ES, Cabra3D C3_I18N_ES +
// C3_OWN_ES, CabraComposition CC_TXT por clave). Aqui:
//   · `cshT( s )`: el castellano de los textos de CabraShared (red, astrometria, polvo): primero la tabla del script
//     (`optT`, si la tiene), luego la de aqui (CSH_ES). Asi CabraShared no depende de que tabla tenga cada script.
//   · `cshLangIsEs()`: el idioma vigente, sea cual sea el script (CSH_LANG si lo fija CabraStarAnalysis; si no, el del
//     script: CS_LANG, CP_LANG o CC_LANG).
//   · `cshLangSetAll( l )`: pone el MISMO idioma a los tres a la vez (CabraStarAnalysis: un solo boton EN/ES).
//   · `cshLangRead/Write( clave )`: lo recordado entre sesiones.
// ES5.
// ============================================================================

var CSH_LANG = null;                 // null = el del script; "en" | "es" lo fija CabraStarAnalysis para todos
var CSH_ES = {
   "Open in Gaia DR3 (VizieR)": "Abrir en Gaia DR3 (VizieR)",
   "SIMBAD · Gaia DR3": "SIMBAD · Gaia DR3",
   "Open in Wikipedia": "Abrir en Wikipedia",                                   // (29-oct, csh_link.js: a dónde lleva el nombre-enlace)
   "Open the sky around it (Aladin)": "Abrir el cielo de alrededor (Aladin)",
   "SIMBAD · Aladin": "SIMBAD · Aladin",
   "Wikipedia · SIMBAD": "Wikipedia · SIMBAD",
   "the service did not answer in time.": "el servicio no ha contestado a tiempo.",
   "HTTP %d — %s": "HTTP %d — %s",
   "the server is down or overloaded": "el servidor está caído o saturado",
   "the query was refused": "rechazó la consulta",
   "no answer in time": "no contestó a tiempo",
   "it answered something that is not a table": "contestó algo que no es una tabla",
   "no connection (no network, or the server cannot be reached)": "sin conexión (no hay red, o no se llega al servidor)",
   "%s did not answer: %s.": "%s no contesta: %s.",
   "no image is selected.": "no hay ninguna imagen elegida.",
   "Solving the image with ImageSolver…": "Resolviendo la imagen con ImageSolver…",
   "ImageSolver cancelled by the user": "ImageSolver cancelado por el usuario",
   "ImageSolver could not start: ": "ImageSolver no ha podido arrancar: ",
   "ImageSolver did not get a valid solution (give it the centre and the pixel scale in its dialog).": "ImageSolver no ha dado una solución válida (dale el centro y la escala del píxel en su diálogo).",
   "To solve without coordinates, choose an astrometric index file in the preferences of the Gaia process.": "Para resolver sin coordenadas, elige un fichero de índice astrométrico en las preferencias del proceso Gaia.",
   "The ImageSolver library is not loaded: run Script > Astrometry > ImageSolver on the image and try again.": "La librería de ImageSolver no está cargada: ejecuta Script > Astrometry > ImageSolver sobre la imagen y vuelve a probar.",
   "could not read the astrometric solution: ": "no se ha podido leer la solución astrométrica: "
};
function cshLangIsEs() {
   if (CSH_LANG === "es" || CSH_LANG === "en") return CSH_LANG === "es";
   if (typeof CS_LANG !== "undefined") return CS_LANG === "es";
   if (typeof CP_LANG !== "undefined") return CP_LANG === "es";
   if (typeof CC_LANG !== "undefined") return CC_LANG === "es";
   return false;
}
function cshT(s) {
   s = String(s);
   if (!cshLangIsEs()) return s;
   if (typeof optT === "function") { try { var t = optT(s); if (typeof t === "string" && t !== s) return t; } catch (e) {} }
   var u = CSH_ES[s];
   return (typeof u === "string") ? u : s;
}
function cshLangSetAll(l) {
   CSH_LANG = (l === "es") ? "es" : "en";
   if (typeof CS_LANG !== "undefined") CS_LANG = CSH_LANG;
   if (typeof CP_LANG !== "undefined") CP_LANG = CSH_LANG;
   if (typeof CC_LANG !== "undefined") CC_LANG = CSH_LANG;
}
function cshLangRead(key, fallback) {
   try { var v = Settings.read(key, DataType_String); if (Settings.lastReadOK !== false && (v === "en" || v === "es")) return v; } catch (e) {}
   return fallback;
}
function cshLangWrite(key, l) { try { Settings.write(key, DataType_String, l); } catch (e) {} }
