#ifndef __CC_GALAXY_UI_JS
#define __CC_GALAXY_UI_JS
// ============================================================================
// src/ui/cc_galaxy_ui.js — III · LA GALAXIA: los MANDOS, el LIENZO del mapa con su ratón y el VÍDEO «Órbitas»
// ----------------------------------------------------------------------------
// PARA EL INTEGRADOR (cc_dialog.js ya tiene el gancho de la fase 1: `D.mountGalaxy(body)` llama a ccGalaxyMount(D, body)):
//   1. Incluir en CabraComposition.js, ANTES de cc_dialog.js (después de cc_atlas.js, cc_frame.js y cc_dynamics.js):
//         #include "src/ui/cc_galaxy_i18n.js"   #include "src/ui/cc_galaxy.js"
//         #include "src/ui/cc_galaxy_paint.js"  #include "src/ui/cc_galaxy_ui.js"
//      Y nada más: ccGalaxyMount(D, body) (abajo) monta los mandos en `body`, deja D.galaxy y devuelve true (el diálogo
//      esconde entonces su rótulo «en construcción»).
//   2. DÓNDE SE PINTA EL MAPA: mientras III está abierto, el mapa OCUPA EL SITIO DE LA COLUMNA B/C/D (D.colBox): B, C y D
//      se ocultan y el mapa toma su alto entero; al plegar III, vuelven. Se engancha SOLO: el cuerpo del grupo avisa al
//      enseñarse y al esconderse (body.onShow / body.onHide, que dispara D.openSection con h.ccBody.show()/hide()), y el
//      mapa se crea la primera vez que se abre, como hijo de D.colBox y en su sizer (en ccGalaxyMount D.colBox aún no
//      existe: el diálogo construye los grupos antes que la columna). Si hiciera falta a mano: D.galaxy.setOpen(true | false).
//      Por qué ahí (y no en el panel A): con un grupo abierto la línea de tiempo E ya se pliega a franja (D1-A), así que la
//      columna B–D es el hueco más alto de la ventana (≈ 600–700 px lógicos a 1560 × 960); la foto (A) y la ficha siguen a
//      la vista, y es lo que hace falta para el enlace: clic en el mapa = D.select(i) = la foto marca la estrella y la
//      ficha cuenta su historia. Tapar A rompería justo ese enlace. B, C y D no se pierden: vuelven al plegar III (y con
//      III abierto aplastados no se leían: pendiente 11 del HANDOFF del 22-oct).
//      POR VER EN LA INTEGRACIÓN: D.fitGroups / groupRoom reservan PLOT_OPEN a B/C/D con un grupo abierto; con III abierto
//      están ocultos (el cuerpo de III es pequeño: tres filas). Comprobar que la cuenta no deja hueco ni recorta el mapa.
//   3. Mientras está abierto, un Timer de 0,25 s mira S.res, S.list, S.sel y el idioma: un análisis nuevo, una carga
//      parcial, otra elegida desde la foto o B–D, o EN/ES repintan el mapa solos (sin tocar cc_dialog.js). Lo mismo a mano:
//      D.galaxy.refresh() (resultado nuevo) · D.galaxy.update() (repintar) · D.galaxy.retranslate() · D.galaxy.stop().
//      Al cerrar la ventana: D.galaxy.stop() + watchStop() (el vigía).
//   4. (29-oct-2026, Nino: «la parte de Viaje y Vídeo de La Galaxia en el tiempo debe moverse a la parte III») EL VÍDEO vive AQUÍ:
//      ccGalaxyMount pone al final de la fila «Tiempo» [▶ Vista previa] [● Grabar] [▾] (sin fila propia: el mapa no pierde alto) con la MISMA máquina de II
//      (ccJourneyBuild de cc_journey_ui.js, modo «orbits», D.gxVideo = D.galaxy.video). UNA línea de tiempo para mirar y grabar: con la
//      vista previa o la grabación en marcha la regla «Tiempo» sigue al reloj del vídeo (GX.videoClock); arrastrarla mueve la vista
//      previa (J.seek); al parar, el mapa se queda en el instante en que se paró (GX.videoEnd). ROJO «gxrulerfree»: la regla va por su
//      lado, como antes (dos relojes).
//   LO QUE ESPERA DE D: D.S (S.res, S.list, S.sel), D.select(i), D.colBox con su sizer y D.panelB/C/D (si no están, el
//   mapa va dentro de `body` con alto fijo), D.closing, y el global CC_QUIET (con un proceso en marcha no se pinta).
//   El estado propio es D.galaxy.G (el modelo, una vez por resultado) con sus mandos en D.galaxy.ui; de S solo LEE S.res,
//   S.list y S.sel, y la elección la hace D.select (no se escribe S.sel aquí).
//
// EL VÍDEO «Órbitas»: ccGalaxyVideo(G, opts) -> { frameFn(g, w, h, t), durationS, fps, name }, con t en SEGUNDOS
// (0 ≤ t < durationS: lo que pasa el grabador de la fase 2a) o en fracción 0…1 con opts.tUnit = "frac".
// Grabar: ccGalaxyRecord(G, opts, onProgress) -> ccJourneyRecord(opts, frameFn, onProgress) de src/ui/cc_journey_video.js
// (opts del grabador: path, width, height, fps, duration, format…; lo que falte lo pone el vídeo: 14 s, 30 fps).
// ES5 puro (los Control de PJSR, sin clases).
// ============================================================================


// ---------------------------------------------------------------------------
// LOS MANDOS
// ---------------------------------------------------------------------------
function ccGxSettingRead(key, dflt, ok) {
   var v = dflt;
   try { if (typeof ccSettingRead === "function") v = ccSettingRead("galaxy_" + key, DataType_UCString, dflt); } catch (e) { v = dflt; }
   return (ok && ok.indexOf(v) < 0) ? dflt : v;
}
function ccGxSettingWrite(GX, key, v) {
   if (GX.noPersist) return;
   try { if (typeof ccSettingWrite === "function") ccSettingWrite("galaxy_" + key, DataType_UCString, v); } catch (e) {}
}
// LA REGLA DEL TIEMPO (23-oct): un Control pintado, ADAPTADO de Cabra3D src/tm/timeruler.js (c3TimeRuler) a un solo lado: el Big Bang
// a la izquierda, HOY a la derecha (la muesca de oro), las marcas en su sitio del reloj (no lineal: el pasado lejano apretado), el tramo
// de oro DESDE HOY hasta el tirador (cuánto te has ido) y el tirador. Clic o arrastre = mover el tiempo; cerca de hoy se pega a hoy.
// value 0…CC_GXT.STEPS (STEPS = hoy). onChange(v) al moverlo; onRelease() al soltar. Nada se calcula en onPaint salvo su geometría.
function ccGxTimeRuler(parent, onChange, onRelease) {
   var c = new Control(parent), N = CC_GXT.STEPS;
   c.value = N; c.ccDrag = false;
   try { c.setFixedHeight(ccPx(26)); } catch (eH) {}
   try { c.setMinWidth(ccPx(150)); } catch (eW) {}
   function geo() { var w = c.width, h = c.height, mx = Math.round(h * 0.5); return { w: w, h: h, mx: mx, y: Math.round(h * 0.36), span: Math.max(1, w - 2 * mx) }; }
   function xOf(G, v) { return G.mx + G.span * v / N; }
   function vOf(G, x) { return Math.max(0, Math.min(N, Math.round((x - G.mx) / G.span * N))); }
   c.ccSet = function(v) { v = Math.max(0, Math.min(N, Math.round(v))); if (v === c.value) return; c.value = v; try { c.repaint(); } catch (e) { try { c.update(); } catch (e2) {} } };
   c.ccMove = function(x) {
      var v = vOf(geo(), x);
      if (N - v <= Math.max(2, Math.round(N * 0.008))) v = N;          // (cerca de hoy, hoy: es un sitio, no un punto que acertar)
      if (v === c.value) return;
      c.value = v; try { c.repaint(); } catch (e) {}
      if (typeof onChange === "function") onChange(v);
   };
   c.onMousePress = function(x, y) { if (!c.enabled) return; c.ccDrag = true; c.ccMove(x); };
   c.onMouseMove = function(x, y, buttons) { if (c.ccDrag) c.ccMove(x); };
   c.onMouseRelease = function(x, y) { if (!c.ccDrag) return; c.ccDrag = false; if (typeof onRelease === "function") onRelease(); };
   c.onPaint = function() {
      var g = new Graphics(c), G = geo(), k = ccScale(c), on = c.enabled, A = CC_ATLAS, gold = ccInt(on ? A.gold : A.line);
      try {
         g.antialiasing = true; g.textAntialiasing = true;
         var lw = Math.max(1, Math.round(2 * k)), x0 = G.mx, x1 = G.mx + G.span, xh = xOf(G, c.value);
         g.pen = new Pen(ccInt(A.line), lw); g.drawLine(x0, G.y, x1, G.y);
         var lang = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en", F = ccFont("text", 7.6 * k), placed = [];
         // las marcas (primero hoy y el Big Bang; las demás si caben)
         var marks = [[0, lang === "es" ? "hoy" : "today"], [ccGxtU(), ccAgeBare(ccGxtU() / 1000, lang)], [5000, "5"], [1000, "1"], [10000, "10"], [2000, "2"], [500, ccAgeNum(0.5, lang)]];
         g.font = F;
         for (var q = 0; q < marks.length; ++q) {
            var xm = xOf(G, ccGxtTToFrac(marks[q][0]) * N), t = marks[q][1], tw = F.width(t), tx = Math.max(0, Math.min(G.w - tw, xm - tw / 2)), ok = true;
            for (var p = 0; p < placed.length; ++p) if (tx < placed[p][1] + 5 * k && tx + tw > placed[p][0] - 5 * k) ok = false;
            g.pen = new Pen(q === 0 ? gold : ccInt(A.text3), Math.max(1, k));
            g.drawLine(xm, G.y - (q === 0 ? 5 : 3) * k, xm, G.y + (q === 0 ? 5 : 3) * k);
            if (!ok) continue;
            placed.push([tx, tx + tw]);
            g.pen = new Pen(ccInt(q === 0 ? (on ? A.goldLight : A.text3) : A.text3));
            g.drawText(tx, G.h - Math.max(1, Math.round(1 * k)), t);
         }
         if (Math.abs(x1 - xh) > 0.5) { g.pen = new Pen(gold, Math.max(2, Math.round(3 * k))); g.drawLine(xh, G.y, x1, G.y); }
         var r = Math.max(4, Math.round(5.5 * k));
         g.pen = new Pen(ccInt(A.bg), Math.max(1, k)); g.brush = new Brush(ccInt(on ? A.goldLight : A.line));
         g.drawCircle(xh, G.y, r);
      } finally { g.end(); }
   };
   return c;
}
function ccGalaxyBuild(body, D, opts) {
   var o = opts || {}, GX = { D: D, body: body, G: null, ui: ccGalaxyDefaultUi(), open: false, noPersist: !!o.noPersist || !!(D && D.gxNoPersist), anim: null, drag: null };
   // (integración: en pruebas —D.gxNoPersist— ni se lee ni se escribe lo recordado, como el resto del diálogo)
   if (!GX.noPersist) {
      GX.ui.mode = ccGxSettingRead("mode", "top", ["top", "edge", "3d"]);
      GX.ui.show = ccGxSettingRead("show", "orbit", ["now", "orbit"]);
      GX.ui.color = ccGxSettingRead("color", "pop", ["pop", "age", "feh"]);
   }
   function lbl() { var l = new Label(body); ccStyle(l, ccCssBarLabel()); ccFixSize(l, 82, 0); return l; }
   function btn(key, tipKey, onClick) { var b = ccToggleButton(body, ccGxT(key), ccGxT(tipKey), onClick); b.ccGxKey = key; b.ccGxTip = tipKey; return b; }
   GX.lblView = lbl(); GX.lblShow = lbl(); GX.lblColour = lbl();
   GX.bTop = btn("gxTop", "gxTopTip", function() { GX.set("mode", "top"); });
   GX.bEdge = btn("gxEdge", "gxEdgeTip", function() { GX.set("mode", "edge"); });
   GX.b3d = btn("gx3d", "gx3dTip", function() { GX.set("mode", "3d"); });
   GX.bNow = btn("gxNow", "gxNowTip", function() { GX.set("show", "now"); });
   GX.bOrbit = btn("gxOrbit", "gxOrbitTip", function() { GX.set("show", "orbit"); });
   GX.bPop = btn("gxPop", "gxPopTip", function() { GX.set("color", "pop"); });
   GX.bAge = btn("gxAge", "gxAgeTip", function() { GX.set("color", "age"); });
   GX.bFeh = btn("gxFeh", "gxFehTip", function() { GX.set("color", "feh"); });
   // (23-oct, revisor R15: «▶ Animar» hacía lo mismo que II › Órbitas › Vista previa: dos caminos a lo mismo. Fuera)
   // (23-oct) EL MANDO DE TIEMPO: «⟲ Hoy» + la regla (el Big Bang a la izquierda, hoy a la derecha; el mismo reloj que el vídeo) + el instante.
   // (29-oct) Y al final de esta fila, ▶ ● ▾ del vídeo (ccGalaxyMount): con su vista previa en marcha, esta regla ES su línea de tiempo (la sigue y la mueve).
   GX.lblTime = lbl();
   GX.vid = function() { var V = D ? D.gxVideo : null; return (V && !ccGxtBroken("gxrulerfree")) ? V : null; };
   GX.bTimeNow = btn("gxTimeNow", "gxTimeNowTip", function() { var V = GX.vid(); if (V && V.preview !== null) V.stop(); GX.setTime(0, false); });
   GX.ruler = ccGxTimeRuler(body, function(v) {
      var T = ccGxtFracToT(v / CC_GXT.STEPS), V = GX.vid();
      if (V && V.preview !== null) { V.seek(ccGxtTimeAt(T)); return; }      // (la vista previa, agarrada en ese instante)
      GX.setTime(T, true);
   }, function() { var V = GX.vid(); if (V && V.preview !== null) { V.seekRelease(); return; } GX.timeSettle(); });
   GX.timeLabel = new Label(body); ccStyle(GX.timeLabel, ccCssBarLabel()); ccFixSize(GX.timeLabel, 92, 0);
   try { GX.timeLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter; } catch (eTA) {}
   GX.buttons = [GX.bTop, GX.bEdge, GX.b3d, GX.bNow, GX.bOrbit, GX.bPop, GX.bAge, GX.bFeh, GX.bTimeNow];
   function row(items) {
      var r = new HorizontalSizer; r.margin = 0; r.spacing = 0;
      r.addSpacing(ccPx((typeof CC_UI !== "undefined" && CC_UI.INDENT) ? CC_UI.INDENT : 26));
      for (var i = 0; i < items.length; ++i) {
         if (typeof items[i] === "number") r.addSpacing(ccPx(items[i]));
         else if (items[i] === "stretch") r.addStretch();
         else { r.add(items[i]); if (i + 1 < items.length && typeof items[i + 1] !== "number" && items[i + 1] !== "stretch") r.addSpacing(ccPx(6)); }
      }
      if (items[items.length - 1] !== "stretch") r.addStretch();
      return r;
   }
   var vs = body.sizer || new VerticalSizer;
   if (!body.sizer) { vs.margin = 0; vs.spacing = 0; }
   if (!body.ccWip) vs.addSpacing(ccPx(6));       // (en el diálogo, el cuerpo ya trae 14 px de arriba)
   vs.add(row([GX.lblView, GX.bTop, GX.bEdge, GX.b3d])); vs.addSpacing(ccPx(5));
   vs.add(row([GX.lblShow, GX.bNow, GX.bOrbit])); vs.addSpacing(ccPx(5));
   vs.add(row([GX.lblColour, GX.bPop, GX.bAge, GX.bFeh])); vs.addSpacing(ccPx(5));
   var rt = new HorizontalSizer; rt.margin = 0; rt.spacing = 0;
   rt.addSpacing(ccPx((typeof CC_UI !== "undefined" && CC_UI.INDENT) ? CC_UI.INDENT : 26));
   rt.add(GX.lblTime); rt.add(GX.bTimeNow); rt.addSpacing(ccPx(8)); rt.add(GX.ruler, 100); rt.addSpacing(ccPx(6)); rt.add(GX.timeLabel); rt.addSpacing(ccPx(10));
   vs.add(rt); vs.addSpacing(ccPx(8));
   GX.timeRow = rt;          // (29-oct) ccGalaxyMount pone al final de esta fila ▶ ● ▾ del vídeo: la regla y sus mandos, UNA fila
   if (!body.sizer) body.sizer = vs;

   // --- EL MAPA: en la columna B/C/D (ver la cabecera); sin ella, dentro del cuerpo con alto fijo ---
   // (perezoso: en ccGalaxyMount la columna aún no existe; se crea al abrir el grupo por primera vez. opts.inBody: en el cuerpo)
   GX.canvas = null; GX.inColumn = false;
   GX.makeCanvas = function() {
      if (GX.canvas) return GX.canvas;
      var col = (!o.inBody && D && D.colBox && D.colBox.sizer) ? D.colBox : null;
      var c = new Control(col || body);
      GX.canvas = c; GX.inColumn = !!col;
      try { c.mouseTracking = true; } catch (e) {}
      if (col) { col.sizer.add(c, 100); c.hide(); }
      else { c.setFixedHeight(ccPx(o.mapH || 420)); vs.add(c); }
      GX.wireCanvas(c);
      GX.sync();
      return c;
   };
   GX.wireCanvas = function(c) {
   c.onPaint = function() {
      if (typeof CC_QUIET !== "undefined" && CC_QUIET) return;
      // (26-oct, propagado de Cabra3D/src/ui/photo_view.js) EL CASO REAL de CabraComposition: el primer pintado con la regla en el pasado calcula
      //  el pasado de las órbitas (GX.paintTo → GX.ensureDeep → cshProcessEvents en cada tanda) DENTRO de este onPaint. Con ccPaintGuarded
      //  (cc_paint.js) CSH_PAINTING > 0 mientras pinta y ese bombeo no atiende eventos (el cálculo se hace igual).
      var self = this;
      ccPaintGuarded(self, function() {
         var g = new Graphics(self);
         // (23-oct, revisor R15: con la vista previa o la grabación de II en marcha, el mapa no se pinta dos veces: lo lleva el vídeo)
         try { if (D && D.videoCovered && typeof ccPaintVideoCover === "function") ccPaintVideoCover(g, self.width, self.height, ccScale(self)); else GX.paintTo(g, self.width, self.height, ccScale(self)); } finally { g.end(); }
      });
   };
   c.onMousePress = function(x, y, button, buttons, modifiers) { GX.press(x, y, button, modifiers); };
   c.onMouseMove = function(x, y, buttons, modifiers) { GX.move(x, y, buttons); };
   c.onMouseRelease = function(x, y, button, buttons, modifiers) { GX.release(x, y, button); };
   c.onMouseDoubleClick = function() { GX.resetView(); };
   c.onMouseWheel = function(x, y, delta) { GX.wheel(x, y, delta); };
   };
   // el cuerpo del grupo avisa al abrirse y al plegarse (D.openSection hace h.ccBody.show() / hide())
   try { body.onShow = function() { GX.setOpen(true); }; body.onHide = function() { GX.setOpen(false); }; } catch (eSH) {}

   // --- el estado ---
   GX.model = function() {
      var S = D ? D.S : null, res = S ? S.res : null, list = S ? S.list : null;
      if (!res) { GX.G = null; return null; }
      var n = list ? list.length : -1;
      if (!GX.G || GX.G.res !== res || GX.G.nList !== n) {
         var ui = GX.ui;
         GX.G = ccGalaxyModel(res, list);
         GX.G.nList = n; GX.G.ui = ui;
      }
      return GX.G;
   };
   GX.paintTo = function(g, w, h, sc) {
      var G = GX.model(), ui = GX.ui;
      ui.sel = (D && D.S && ccIsNum(D.S.sel)) ? D.S.sel : -1;
      ui.selLabel = false;           // (26-oct) en el panel, la elegida sin rótulo: lo dice la ficha (cc_galaxy_paint.js, «gxsellabel»)
      if (!G) { ccGalaxyPaint(g, w, h, G, sc, ui); return; }
      if (ui.tMyr < 0 && !G.deep) GX.ensureDeep(G);       // (un resultado nuevo con el mando en el pasado: su pasado, antes de pintar)
      // la BASE (lo caro) se guarda en un bitmap mientras no cambie su clave; la elegida y los rótulos, encima
      var key = ccGxBaseKey(G, ui, w, h, sc);
      if (!GX.base || GX.baseKey !== key) {
         var bmp = new Bitmap(Math.max(8, w), Math.max(8, h)), gb = new Graphics(bmp), C = null;
         try { gb.antialiasing = true; gb.textAntialiasing = true; C = ccGxPaintBase(gb, w, h, G, sc, ui); } finally { gb.end(); }
         GX.base = { bmp: bmp, C: C }; GX.baseKey = key; GX.baseRenders = (GX.baseRenders || 0) + 1;
      }
      g.drawBitmap(0, 0, GX.base.bmp);
      if (GX.base.C.empty) return;
      GX.lastR = ccGxPaintOver(g, w, h, G, sc, ui, ccGxCloneCtx(GX.base.C));
   };
   GX.update = function() { try { if (GX.canvas && (GX.open || !GX.inColumn)) GX.canvas.update(); } catch (e) {} };
   GX.refresh = function() { GX.G = null; GX.update(); };
   GX.sync = function() {
      var u = GX.ui;
      ccSetToggle(GX.bTop, u.mode === "top"); ccSetToggle(GX.bEdge, u.mode === "edge"); ccSetToggle(GX.b3d, u.mode === "3d");
      ccSetToggle(GX.bNow, u.show === "now"); ccSetToggle(GX.bOrbit, u.show === "orbit");
      ccSetToggle(GX.bPop, u.color === "pop"); ccSetToggle(GX.bAge, u.color === "age"); ccSetToggle(GX.bFeh, u.color === "feh");
      var tip = ccGxT(u.mode === "3d" ? "gx3dTip" : (u.mode === "edge" ? "gxEdgeTip" : "gxTopTip"));
      if (GX.canvas) { try { GX.canvas.toolTip = tip; } catch (e) {} try { GX.canvas.cursor = new Cursor(StdCursor_Cross); } catch (e2) {} }
      GX.syncTime();
   };
   // --- EL TIEMPO (23-oct): T en Ma atrás; GX.ui.tMyr = −T (el pintor: negativo = el pasado) ---
   GX.timeT = function() { return (ccIsNum(GX.ui.tMyr) && GX.ui.tMyr < 0) ? -GX.ui.tMyr : 0; };
   GX.syncTime = function() {
      var T = GX.timeT(), lang = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en";
      try { GX.ruler.ccSet(Math.round(ccGxtTToFrac(T) * CC_GXT.STEPS)); } catch (eR) {}
      var t = ccGxtAgoText(T, lang);
      if (GX.timeLabel.text !== t) GX.timeLabel.text = t;
      ccSetToggle(GX.bTimeNow, T === 0);
      // (29-oct) mientras se graba el vídeo de aquí, la regla no se toca (sigue al vídeo, apagada)
      try { var en = !!(D && D.S && D.S.res) && !(D.gxVideo && D.gxVideo.rec !== null); GX.ruler.enabled = en; GX.bTimeNow.enabled = en; } catch (eE) {}
   };
   // (29-oct) EL RELOJ DEL VÍDEO EN LA REGLA (cfg.onClock de D.gxVideo): la regla y su rótulo dicen el instante del vídeo sin tocar el mapa
   // (que está tapado por la vista previa); st null = el vídeo soltó la columna: la regla vuelve a lo suyo.
   GX.videoClock = function(mode, st) {
      if (ccGxtBroken("gxrulerfree")) return;
      if (!st || mode !== "orbits" || !st.R || !st.R.clock || !ccIsNum(st.R.clock.T)) { GX.syncTime(); return; }
      var T = Math.max(0, st.R.clock.T), lang = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en";
      if (ccJourneyIsToday(st.R.clock.phase || "run", T)) T = 0;
      GX.videoT = T;
      try { GX.ruler.ccSet(Math.round(ccGxtTToFrac(T) * CC_GXT.STEPS)); } catch (eR) {}
      var t = ccGxtAgoText(T, lang);
      if (GX.timeLabel.text !== t) GX.timeLabel.text = t;
      ccSetToggle(GX.bTimeNow, T === 0);
   };
   // (29-oct) al acabar: la vista previa deja el mapa en el instante en que se paró (una sola línea de tiempo); la grabación, como estaba
   GX.videoEnd = function(what, T) {
      if (what === "preview" && ccIsNum(T) && !ccGxtBroken("gxrulerfree")) { GX.setTime(T, false); return; }
      GX.syncTime();
   };
   // el pasado entero de las órbitas (una vez por resultado: ccGalaxyDeepPast, cc_galaxy_time.js), con la barra de estado diciendo qué hace
   GX.ensureDeep = function(G0) {
      var G = G0 || GX.model();
      if (!G || G.deep) return G ? G.deep : null;
      var say = (D && typeof D.say === "function") ? function(fr) { try { D.say(ccGxF("gxtComputing", { n: ccGxNumInt(G.stars.length) }), fr, true, false, ""); } catch (eS) {} } : null;
      if (say) say(0);
      var out = ccGalaxyDeepPast(G, say ? function(i, n) { say(n ? i / n : 0); try { cshProcessEvents(); } catch (eP) {} } : null);
      if (D && typeof D.sayIdle === "function" && !D.busy) { try { D.sayIdle(); } catch (eI) {} }
      return out;
   };
   GX.setTime = function(T, light) {
      T = Math.max(0, Math.min(ccGxtU(), ccIsNum(T) ? T : 0));
      if (ccJourneyIsToday("run", T)) T = 0;      // (24-oct, H7: el mismo umbral de «hoy» que el reloj)
      if (T > 0) GX.ensureDeep();
      GX.ui.tMyr = (T > 0) ? -T : 0; GX.ui.light = !!light;
      GX.syncTime(); GX.update();
      GX.pushClock();
      return T;
   };
   GX.timeSettle = function() { if (GX.ui.light) { GX.ui.light = false; GX.update(); } GX.pushClock(); };
   // (23-oct, opción (a) de Nino) el instante de la regla, al diálogo: la línea de tiempo E con su cursor, y la foto y B/C/D con solo las
   // nacidas (al soltar la regla: arrastrando, solo E). Con III plegado, o en «hoy», el diálogo vuelve a lo de siempre. ROJO «gxnoclock»
   GX.pushClock = function() {
      if (!D || typeof D.setClock !== "function" || ccGxBroken("gxnoclock")) return;
      var T = GX.timeT();
      try { D.setClock("galaxy", (GX.open && T > 0) ? { T: T / 1000, photo: true, light: !!GX.ui.light } : null); } catch (e) {}
   };
   GX.set = function(key, v) {
      GX.ui[key] = v; ccGxSettingWrite(GX, key, v);
      GX.sync(); GX.update();
   };
   GX.retranslate = function() {
      GX.lblView.text = ccGxT("gxView"); GX.lblShow.text = ccGxT("gxShow"); GX.lblColour.text = ccGxT("gxColour"); GX.lblTime.text = ccGxT("gxTime");
      var tTip = (typeof ccWrapTip === "function") ? ccWrapTip(ccGxT("gxTimeTip")) : ccGxT("gxTimeTip");
      try { GX.ruler.toolTip = tTip; GX.timeLabel.toolTip = tTip; GX.lblTime.toolTip = tTip; GX.ruler.repaint(); } catch (eRT) {}
      for (var i = 0; i < GX.buttons.length; ++i) {
         var b = GX.buttons[i];
         b.text = ccGxT(b.ccGxKey); b.toolTip = ccGxT(b.ccGxTip);
         ccFitButton(b, 22, 0, 10, 22);
      }
      GX.sync(); GX.update();
   };
   // abrir / cerrar el grupo: el mapa en el sitio de B/C/D
   GX.setOpen = function(on) {
      on = !!on;
      if (on && D && D.closing) return;
      if (GX.open === on && GX.canvas) return;
      GX.open = on;
      // (29-oct) plegar III para la vista previa de su vídeo (la grabación sigue: se ve en la columna con su barra, como en II)
      if (!on && D && D.gxVideo && D.gxVideo.preview !== null) { try { D.gxVideo.stop(); } catch (eVS) {} }
      GX.pushClock();
      if (on) GX.makeCanvas();
      if (on) GX.watchStart(); else GX.watchStop();
      if (!GX.inColumn) { if (!on) GX.stop(); GX.update(); return; }
      // (23-oct) con la vista previa o la grabación de un vídeo en la columna (D.journey o D.gxVideo .colTaken), la columna es suya: aquí
      // solo se apunta si III está abierto; al parar, el vídeo la devuelve (al mapa si III sigue abierto, a B/C/D si no)
      if (D && ((D.journey && D.journey.colTaken) || (D.gxVideo && D.gxVideo.colTaken))) { if (!on) GX.stop(); return; }
      var P = [D.panelB, D.panelC, D.panelD];
      // (ROJO «nohidebcd» de T17: B, C y D no se esconden y el mapa se reparte la columna con ellos)
      for (var i = 0; i < P.length; ++i) if (P[i] && !ccGxBroken("nohidebcd")) { try { if (on) P[i].hide(); else P[i].show(); } catch (e) {} }
      try { if (on) GX.canvas.show(); else { GX.stop(); GX.canvas.hide(); } } catch (e2) {}
      if (on) GX.update();
   };
   // EL VIGÍA: mientras está abierto, repinta si cambian el resultado, la lista, la elegida o el idioma
   GX.watchKey = function() {
      var S = D ? D.S : null, lang = (typeof CC_LANG !== "undefined") ? CC_LANG : "";
      return [S && S.res ? (S.res.__ccGxId || (S.res.__ccGxId = "r" + (++CC_GX_STAMP) + "_" + Date.now())) : "-", S && S.list ? S.list.length : -1, S ? S.sel : -1, lang].join("|");
   };
   GX.watchStart = function() {
      GX.lastWatch = GX.watchKey(); GX.lastLang = (typeof CC_LANG !== "undefined") ? CC_LANG : "";
      if (!GX.watch) {
         GX.watch = new Timer; GX.watch.interval = 0.25; GX.watch.periodic = true;
         GX.watch.onTimeout = function() {
            if (!GX.open || (D && D.closing)) { GX.watchStop(); return; }
            var k = GX.watchKey();
            if (k === GX.lastWatch) return;
            GX.lastWatch = k;
            var lang = (typeof CC_LANG !== "undefined") ? CC_LANG : "";
            if (lang !== GX.lastLang) { GX.lastLang = lang; GX.retranslate(); } else GX.update();
         };
      }
      try { GX.watch.start(); } catch (e) {}
   };
   GX.watchStop = function() { if (GX.watch) { try { GX.watch.stop(); } catch (e) {} } };
   // --- el ratón (el de Cabra3D: izquierdo gira; derecho, central o Mayús desplazan; rueda hacia el cursor; doble clic encuadra) ---
   GX.press = function(x, y, button, modifiers) {
      if ((typeof CC_QUIET !== "undefined" && CC_QUIET) || !GX.G || !GX.G.proj) return;
      var left = (typeof MouseButton_Left !== "undefined") ? MouseButton_Left : 1, shift = (typeof KeyModifier_Shift !== "undefined") ? KeyModifier_Shift : 0x02000000;
      var P = GX.G.proj.P;
      GX.drag = { x: x, y: y, button: button, moved: false, pan: (button !== left || (((modifiers || 0) & shift) !== 0)), fit: P.cam || null, xf: P.xf || null };
   };
   GX.move = function(x, y, buttons) {
      var d = GX.drag;
      if (!d || !buttons) return;
      var dx = x - d.x, dy = y - d.y;
      if (!d.moved && dx * dx + dy * dy <= 9) return;
      d.moved = true;
      var u = GX.ui;
      if (u.mode === "3d" && d.fit) u.cam = d.pan ? ccGxCamPan(d.fit, dx, dy) : ccGxCamOrbit(d.fit.view, dx, dy);
      else if (d.xf) u.v2[u.mode] = ccGx2DPan(d.xf, dx, dy);
      u.light = true;
      GX.update();
   };
   GX.release = function(x, y, button) {
      var d = GX.drag, left = (typeof MouseButton_Left !== "undefined") ? MouseButton_Left : 1;
      GX.drag = null;
      if (GX.ui.light) { GX.ui.light = false; GX.update(); }
      if (!d || d.moved || button !== left || !GX.G) return;
      var i = ccGalaxyPick(GX.G, x, y, ccScale(GX.canvas));
      GX.lastPick = i;
      if (i >= 0 && D && typeof D.select === "function") D.select(i);
      GX.update();
   };
   GX.wheel = function(x, y, delta) {
      if (!GX.G || !GX.G.proj || !delta) return;
      var f = (delta > 0) ? 1.25 : 0.8, P = GX.G.proj.P, u = GX.ui;
      if (u.mode === "3d" && P.cam) {
         var near = -1, bd = Math.pow(10 * ccScale(GX.canvas), 2), pr = GX.G.proj;
         for (var i = 0; i < pr.n; ++i) { if (!pr.ok[i]) continue; var ddx = pr.x[i] - x, ddy = pr.y[i] - y, dd = ddx * ddx + ddy * ddy; if (dd < bd) { bd = dd; near = i; } }
         u.cam = ccGxCamZoomAt(P.cam, f, x, y, (near >= 0) ? pr.z[near] : undefined);
      } else if (P.xf) u.v2[u.mode] = ccGx2DZoomAt(P.xf, f, x, y);
      GX.update();
   };
   GX.resetView = function() {
      var u = GX.ui;
      if (u.mode === "3d") u.cam = null; else u.v2[u.mode] = null;
      GX.update();
   };
   // (la vista previa de «La Galaxia en el tiempo» es D.gxVideo, montada en este cuerpo por ccGalaxyMount. GX.stop queda para quien la
   //  llamaba: al cerrar, para el vigía)
   GX.stop = function() { if (D && D.closing) GX.watchStop(); };
   if (o.inBody || (D && D.colBox && D.colBox.sizer && o.eager)) GX.makeCanvas();
   GX.retranslate();
   return GX;
}
// EL GANCHO de cc_dialog.js (fase 1): D.mountGalaxy(body) llama aquí UNA vez al construir el diálogo.
// (29-oct) y, al final de la fila «Tiempo», ▶ ● ▾ de «La Galaxia en el tiempo» (antes en II): la máquina de II con un solo modo, sus Settings
// propios (`…/GalaxyVideo/…`, heredando la primera vez los de II) y los ganchos de la regla. ROJO «jorbitsinII»: sin fila (el vídeo, en II).
function ccGalaxyMount(D, body) {
   var GX = D.galaxy = ccGalaxyBuild(body, D);
   if (typeof ccJourneyBuild === "function" && !(typeof ccJBroken === "function" && ccJBroken("jorbitsinII"))) {
      GX.video = ccJourneyBuild(body, D, { modes: CC_JOURNEY.GALAXY_MODES, key: "GalaxyVideo", slot: "gxVideo", labelKey: "jGxVideo", labelW: 82,
                                           row: ccJBroken("gxvideorow") ? null : GX.timeRow,      // (ROJO «gxvideorow»: su fila propia, el mapa 46 px más bajo)
                                           modeTip: "jGxVideoTip", previewTip: "jPreviewTipGx", recordTip: "jRecordTipGx", hintWhyOnly: true,
                                           onClock: function(mode, st) { GX.videoClock(mode, st); }, onEnd: function(what, T) { GX.videoEnd(what, T); } });
      GX.video.sync();
   }
   return true;
}

// ---------------------------------------------------------------------------
// EL VÍDEO «LA GALAXIA EN EL TIEMPO» (23-oct; sustituye a «Órbitas»: un solo vídeo de III, del Big Bang a hoy)
// ---------------------------------------------------------------------------
// Por qué UNO y no dos: el final de este vídeo (los últimos 210 Ma) va a 35 Ma por segundo con estelas de 40 Ma —«Órbitas» iba a
// 30 Ma/s con estelas de 40 Ma—: lo que enseñaba «Órbitas» (las estrellas girando con la vista y los colores de III) ya está aquí,
// hacia hoy en vez de hacia el futuro, y además se ve cómo van naciendo. Dos modos de II que animan las mismas órbitas en las mismas
// vistas serían dos caminos a lo mismo.
// El reloj, las estelas y el pasado: cc_galaxy_time.js (su cabecera dice cada decisión y su medida).
// opts: { color, sel, title (el nombre del campo), tUnit ("frac" | "s"), mode ("3d" de fábrica | "top" | "edge"), show ("orbit" | "now"), uiScale (la letra fija: vista previa),
//         cam (la vista 3D de III: el giro parte de ella), v2 (el zoom y centro 2D de III), turnDeg (120), fps }
// V = { durationS, fps, name: "orbits", frameFn(g, w, h, t), last }. R (lo que devuelve frameFn) lleva además R.clock y R.look.
var CC_GX_VIDEO = { FPS: 30, PITCH0: -24, PITCH_SWING: 8, NOTE_S: 5.5, DIAL_R: 39, DIAL_R_PREVIEW: 52 };   // (DIAL_R: el radio del reloj analógico por unidad de sc en el VÍDEO: 78 px a 1080p desde el 26-oct —Nino: «demasiado grande», 70; luego «las cifras se ven pequeñas», 78; era 52, 104 px, como en II—; DIAL_R_PREVIEW: el de la vista previa del diálogo, sin cambio)   // diseño (NOTE_S: la nota de honestidad entera, los primeros 5,5 s)
function ccGalaxyVideo(G, opts) {
   var o = opts || {}, dur = ccGxtDuration(), turn = ccIsNum(o.turnDeg) ? o.turnDeg : CC_GXT.TURN_DEG;
   if (G && G.stars && typeof ccGalaxyDeepPast === "function") ccGalaxyDeepPast(G);
   var name = o.title || (G && G.res && G.res.field && (G.res.field.viewId || G.res.field.name)) || "";
   var V = { durationS: dur, fps: o.fps || CC_GX_VIDEO.FPS, name: "orbits", last: null, legendMem: {} };      // (legendMem: dónde puso la leyenda la última vez, 18a)
   V.frameFn = function(g, w, h, t) {
      var ts = (o.tUnit === "frac") ? t * dur : t;           // (de fábrica, SEGUNDOS: lo que pasa ccJourneyRecorder)
      ts = Math.max(0, Math.min(dur, ccIsNum(ts) ? ts : 0));
      var f = ts / dur, C = ccGxtClock(ts), T = C.T, rate = (C.phase === "run") ? C.rate : ((C.phase === "intro") ? ccGxtRate(ccGxtU()) : CC_GXT.R_END), look = ccGxtLook(rate);
      var sc = Math.max(1, Math.min(w, h) / 540);           // (la letra crece con el fotograma: 1080p = 2; en vertical, por el ancho)
      if (o.uiScale > 0) sc = o.uiScale;                     // (23-oct: la vista previa del diálogo, con la letra del diálogo —legible a 387 lógicos—)
      var wide = (w / h >= 1.25), lang = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en", A = CC_ATLAS, m = Math.round(10 * sc), signH = Math.round(30 * sc);
      var mode = (o.mode === "top" || o.mode === "edge") ? o.mode : "3d", c0 = (mode === "3d" && o.cam) ? o.cam : null;
      var cam = c0 ? { yaw: c0.yaw + turn * (f - 0.5), pitch: c0.pitch - CC_GX_VIDEO.PITCH_SWING * Math.sin(Math.PI * f), zoom: c0.zoom, ox: c0.ox, oy: c0.oy, oz: c0.oz }
                   : { yaw: CC_GX_CAM.YAW + turn * (f - 0.5), pitch: CC_GX_VIDEO.PITCH0 - CC_GX_VIDEO.PITCH_SWING * Math.sin(Math.PI * f), zoom: 1.0 };
      // --- las dos placas, MEDIDAS antes de pintar el mapa (se reservan: ni rótulos ni leyenda debajo) ---
      var noteA = (C.phase === "intro") ? 1 : Math.max(0, Math.min(1, (CC_GX_VIDEO.NOTE_S - C.s) / 0.8));
      // (la vista previa alta y estrecha del diálogo —uiScale—: la placa del título corta y sin leyenda: a 387 lógicos no queda esquina
      //  libre y la placa la tapaba —captura del 23-oct—; la leyenda sigue en el mapa de III y en la grabación)
      var narrow = (o.uiScale > 0 && !wide);
      if (narrow) noteA = 0;
      var tItems = [{ text: "Stellar Chemistry", font: ["text", 8.6, true, false, A.labelTracking], color: ccInt(A.gold), caps: true, gap: 3 },
                    { text: ccGxT("gxVideoTitle"), font: ["display", 21, false, true], color: ccInt(A.goldLight), gap: 3 },
                    { text: narrow ? "" : ccGxT("gxVideoSub") + (name ? " · " + name : ""), font: ["text", 9.6, false, true], color: ccInt(A.text2), wrap: 2, gap: 4 },
                    { text: (noteA > 0.02) ? ccGxT("gxtVideoNote") : ccGxT("gxtIllustrative"), font: ["text", 8.2, false, false], color: ccInt(A.text3), wrap: 3 }];
      var tM = ccGxtPlateMeasure(tItems, sc, wide ? Math.round(w * 0.42) : w - 2 * m - Math.round(24 * sc));
      // el reloj, el episodio y las cuentas (abajo a la izquierda)
      var cItems = ccGxtClockItems(G, C, T, rate, lang);
      // (24-oct) EL RELOJ ANALÓGICO (CabraShared/csh_clock.js, el mismo de II, cc_journey_paint.js): encima de la placa, que pierde sus dos
      //  primeras filas («RELOJ CÓSMICO» y «hace 9,3 Ga»: la cifra exacta va pequeña bajo la esfera). Se achica si no cabe entre la placa y
      //  el título. ROJO «jclockold» (CC_BREAK): la placa de texto de antes.
      var dialOn = (typeof ccJourneyDialOn === "function") && ccJourneyDialOn(), dialCap = cItems[1] ? cItems[1].text : "", dF = null, dY = 0, dGap = Math.round(6 * sc);
      if (dialOn) cItems = cItems.slice(2);
      var cM = ccGxtPlateMeasure(cItems, sc, wide ? Math.round(w * 0.34) : w - 2 * m - Math.round(24 * sc));
      var cY = h - signH - m - cM.H;
      // DÓNDE (medido en la sonda tests/cc_clock_probe.js, K4: lo que brilla del mapa debajo del reloj), y QUIETO todo el vídeo: se coloca
      // contra la placa MÁS ALTA del vídeo y el título más alto (medidos una vez por tamaño e idioma, ccGxtDialRoom), no contra la del
      // fotograma (revisor visual del 24-oct: pegado a la placa, saltaba 20 px en cada episodio y 165 px al final):
      //  · de fábrica, encima de la placa (1080p y 1080 × 1920: 0,0 % de lo que brilla debajo);
      //  · en la vista previa alta y estrecha (sin leyenda), arriba a la derecha: junto al título si cabe con el título de los DOS idiomas,
      //    si no, bajo él (el mismo sitio en castellano y en inglés; encima de la placa tapaba el 4–7 % del mapa, que allí llena el ancho);
      //  · en un fotograma bajo no cabe encima: a la derecha de la placa, abajo;
      //  · si nada de eso cabe, encima de la placa y más pequeño.
      //  En la vista previa (uiScale) las cifras no bajan de 7 px lógicos (T17 X9).
      var dX = m, dRoom = null;
      if (dialOn) {
         var dPrev = (o.uiScale > 0 || ccJBroken("jclockbig")), dK = sc * (dPrev ? CC_GX_VIDEO.DIAL_R_PREVIEW : CC_GX_VIDEO.DIAL_R) / CC_JDIAL.R_K, dV = ccJourneyDialVariant(), dMin = (o.uiScale > 0) ? ccJourneyDialPreviewPx() : 0, dCap = dPrev ? 0 : CC_JDIAL.CAP_MIN_PX, nom = ccJourneyDialFit(dK, { h: h }, dialCap, dV, lang, 1, dMin, dCap);
         var room = dRoom = ccGxtDialRoom(V, G, w, h, sc, lang, narrow, tItems, wide ? Math.round(w * 0.42) : w - 2 * m - Math.round(24 * sc), wide ? Math.round(w * 0.34) : w - 2 * m - Math.round(24 * sc));
         var cYf = h - signH - m - room.cH, dTop = m + room.tH + m, tWf = room.tW;
         var yN = (m + tWf + 2 * m + nom.FP.w <= w) ? m : dTop - m + dGap, xB = m + room.cW + dGap, yB = h - signH - m - nom.FP.h;
         if (yB < dTop) xB = Math.max(xB, m + tWf + m);      // (más alto que el hueco bajo el título: a la derecha del título también)
         if (narrow && yN + nom.FP.h + dGap <= cYf - m) { dF = nom; dX = w - m - nom.FP.w; dY = yN; }
         else if (cYf - dGap - dTop >= nom.FP.h) { dF = nom; dY = cYf - dGap - nom.FP.h; }
         else if (xB + nom.FP.w <= w - m && (yB >= dTop || xB >= m + tWf + m)) { dF = nom; dX = xB; dY = yB; }
         else { dF = ccJourneyDialFit(dK, { h: h }, dialCap, dV, lang, Math.max(0.05, (cYf - dGap - dTop) / h), dMin, dCap); dY = cYf - dGap - dF.FP.h; }
      }
      var view = { mode: mode, show: (o.show === "now") ? "now" : "orbit", color: o.color || "pop", sel: ccIsNum(o.sel) ? o.sel : -1, chrome: false, arms: true,
                   cam: (mode === "3d") ? cam : null, v2: { top: (o.v2 && o.v2.top) || null, edge: (o.v2 && o.v2.edge) || null },
                   tMyr: (T > 0) ? -T : 0, trail: look.trail, trailFlat: look.flat, trailSeg: look.seg, dotAlpha: look.dot, flash: (C.phase === "run"),      // (en el título, el anillo de las que nacen a 13,8 Ga se quedaba abierto y quieto)
                   noAgeAlpha: (C.phase === "hold") ? Math.min(1, C.hold / CC_GXT.NOAGE_FADE_S) : 0, timePlate: false, legendPrefer: "tr", legendMem: V.legendMem, legend: narrow ? false : undefined,
                   reserve: [[0, 0, m + tM.W + m, m + tM.H + m], [0, cY - m, m + cM.W + m, h], [0, h - signH, w, h]].concat(dF ? [[dX - m, dY - m, dX + dF.FP.w + m, dY + dF.FP.h + m]] : [])
                            // (18a, 26-oct) y las placas MÁS ALTAS y anchas del vídeo (ccGxtDialRoom, medidas una vez): la leyenda, cuando no cabe en ningún rincón y se desliza
                            // (cc_galaxy_paint.js), se queda QUIETA todo el vídeo en vez de saltar cada vez que la placa del reloj crece o encoge. ROJO «legoverlap»: sin ellas.
                            .concat((dialOn && dRoom && !ccGxtBroken("legstatic")) ? [[0, 0, m + dRoom.tW + m, m + dRoom.tH + m], [0, h - signH - m - dRoom.cH - m, m + dRoom.cW + m, h]] : []) };
      var R = ccGalaxyPaint(g, w, h, G, sc, view);
      R.titlePlate = ccGxtPlatePaint(g, R, tM, m, m, 1);
      R.clockPlate = ccGxtPlatePaint(g, R, cM, m, cY, 1);
      if (dF && ccGxtBroken("gxdialcenter")) { dX = Math.round((w - dF.FP.w) / 2); dY = Math.round((h - dF.FP.h) / 2); }      // (ROJO de la sonda: el reloj en medio del mapa)
      if (dF) R.clockDial = cshClockPaint(g, dX, dY, dF.R, dF.L.S, -T / 1000, { variant: dF.L.variant, lang: lang, caption: dialCap, fontFn: ccFont, layout: dF.L, faceAlpha: CC_JDIAL.FACE_A,
                                                                           textFn: function(gg, ff, cc, xx, yy, ss) { ccGxText(gg, R, ff, cc, xx, yy, ss); } });
      // la barra de avance, fina, a lo ancho (dorada) y la firma común (R18: CC_VIDEO_SIGN, ccVideoSignFont)
      g.fillRect(0, h - Math.max(2, Math.round(2 * sc)), Math.round(w * f), h, new Brush(ccInt(A.gold, 0.8)));
      var mk = CC_VIDEO_SIGN, fSg = ccVideoSignFont(540 * sc);      // (1080p y 1080 × 1920: sc = 2, la de siempre; la vista previa, a su letra)
      ccGxText(g, R, fSg, ccInt(A.text3, 0.85), w - fSg.width(mk) - Math.round(16 * sc), h - Math.round(12 * sc), mk);
      R.clock = C; R.look = look; R.f = f;
      V.last = R;
      return R;
   };
   return V;
}
// Lo que dice la placa del reloj: RELOJ CÓSMICO · «hace 9,4 Ga» · el episodio en curso (de CC_TIMELINE, como «La historia del campo»)
// con su referencia · las nacidas · a qué ritmo va el reloj. En el final, «La Galaxia, ahora».
function ccGxtClockItems(G, C, T, rate, lang) {
   var A = CC_ATLAS, nAge = 0, lit = 0, noAge = 0, i, Tga = T / 1000;
   if (G && G.stars) for (i = 0; i < G.stars.length; ++i) { var e = G.stars[i]; if (!e.tr) continue; var b = ccGxtBirth(e, Tga); if (b < 0) ++noAge; else { ++nAge; if (b >= 0.5) ++lit; } }
   var big = ccJourneyIsToday(C.phase, T) ? ccGxT("gxVideoNow") : ccGxtAgoText(T, lang), items = [{ text: ccGxT("gxtClock"), font: ["text", 8, true, false, A.labelTracking], color: ccInt(A.text3), caps: true, gap: 2 },
                { text: big, font: ["display", 22, false, true], color: ccInt(A.text), gap: 5 }];
   if (C.phase === "hold") {
      items.push({ text: ccGxT("gxtNowEyebrow"), font: ["text", 8.4, true, false, A.labelTracking], color: ccInt(A.gold), caps: true, gap: 3 });
      items.push({ text: noAge ? ccGxF("gxtNowLine", { n: ccGxNumInt(noAge), t: ccGxNumInt(G && G.stars ? G.stars.length : noAge + nAge) }) : ccGxT("gxtNowAll"), font: ["text", 9.6, false, false], color: ccInt(A.goldLight), wrap: 2 });
      return items;
   }
   var ep = (typeof ccJourneyEpisodes === "function") ? ccJourneyEpisodes(Tga) : null, pr = ep ? ep.primary : null, es = (lang === "es");
   items.push({ text: ccGxT("gxtThen"), font: ["text", 8.4, true, false, A.labelTracking], color: ccInt(A.gold), caps: true, gap: 3 });
   if (pr) { items.push({ text: es ? pr.es : pr.en, font: ["text", 12.5, true, false], color: ccInt(A.text), wrap: 2, gap: 1 }); items.push({ text: ccAgeLocalize(pr.ref || "", lang), font: ["text", 7.8, false, true], color: ccInt(A.text3), gap: 4 }); }
   // (24-oct, B2c = sí de Nino) «también: …» como en la placa de II: LA MISMA función (ccJourneyAlso, cc_journey.js), no una lista copiada
   var also = (typeof ccJourneyAlso === "function" && ep && !ccGxtBroken("gxtnoalso")) ? ccJourneyAlso(ep, ccGxtBroken("gxtalsolang") ? undefined : lang) : null;
   if (also && also.line) items.push({ text: also.line, font: ["text", 8.4, false, false], color: ccInt(A.text2), wrap: 3, gap: 4 });
   items.push({ text: ccGxF("gxtBorn", { n: ccGxNumInt(lit), m: ccGxNumInt(nAge), t: ccGxNumInt(G && G.stars ? G.stars.length : nAge + noAge) }) + (noAge ? " · " + ccGxF("gxtNoAge", { n: ccGxNumInt(noAge) }) : ""), font: ["text", 9, false, false], color: ccInt(A.goldLight), wrap: 2, gap: 3 });
   var rr = Math.round(rate / 5) * 5;
   items.push({ text: (rate > CC_GXT.RATE_SLOW * 1.5) ? ccGxF("gxtFast", { r: ccGxNumInt(rr) }) : ccGxF("gxtSlow", { r: ccGxNumInt(Math.round(rate)) }), font: ["text", 7.8, false, true], color: ccInt(A.text3), wrap: 2 });
   return items;
}
// (24-oct) EL SITIO DEL RELOJ ANALÓGICO, quieto en todo el vídeo: la placa del reloj (sin sus dos primeras filas) y el título MÁS
// ALTOS y más anchos del vídeo, medidos una vez por tamaño, escala e idioma (141 instantes del Big Bang a hoy + el final; el título con
// la nota larga del principio y con la corta). { cH, cW, tH, tW } en px. Se guarda en V (el vídeo): ~0,1 s la primera vez.
function ccGxtDialRoom(V, G, w, h, sc, lang, narrow, tItems, maxWt, maxWc) {
   var key = [w, h, sc, lang, narrow ? 1 : 0].join("|");
   if (V._dialRoom && V._dialRoom.key === key) return V._dialRoom.room;
   var room = { cH: 0, cW: 0, tH: 0, tW: 0 }, U = ccGxtU(), i, M;
   // la placa y el título, en LOS DOS idiomas (el sitio del reloj no cambia con el idioma: revisor del 24–25-oct, en inglés el título es
   // más largo y la placa a 9,3 Ga una línea más corta)
   var keepL = (typeof CC_LANG !== "undefined") ? CC_LANG : "en", langs = ["es", "en"], li, last = tItems[tItems.length - 1];
   try {
      for (li = 0; li < langs.length; ++li) {
         CC_LANG = langs[li];
         for (i = 0; i <= 141; ++i) {
            var hold = (i === 141), T = hold ? 0 : U * (1 - i / 140), C = { phase: hold ? "hold" : "run" }, it = ccGxtClockItems(G, C, T, hold ? 0 : ccGxtRate(T), langs[li]).slice(2);
            M = ccGxtPlateMeasure(it, sc, maxWc);
            room.cH = Math.max(room.cH, M.H); room.cW = Math.max(room.cW, M.W);
         }
         var notes = narrow ? [ccGxT("gxtIllustrative")] : [ccGxT("gxtVideoNote"), ccGxT("gxtIllustrative")];
         for (i = 0; i < notes.length; ++i) {
            var t2 = tItems.slice();
            t2[1] = { text: ccGxT("gxVideoTitle"), font: tItems[1].font, color: tItems[1].color, gap: tItems[1].gap };
            t2[t2.length - 1] = { text: notes[i], font: last.font, color: last.color, wrap: last.wrap };
            M = ccGxtPlateMeasure(t2, sc, maxWt);
            room.tH = Math.max(room.tH, M.H); room.tW = Math.max(room.tW, M.W);
         }
      }
   } finally { CC_LANG = keepL; }
   V._dialRoom = { key: key, room: room };
   return room;
}
// Las opciones de vista y color del grupo III para su vídeo (las usa D.gxVideo, ▶ ● de la fila «Tiempo» de III: la vista previa y la grabación)
function ccGalaxyVideoOpts(GX, extra) {
   var u = (GX && GX.ui) ? GX.ui : ccGalaxyDefaultUi(), o = { color: u.color, mode: u.mode, show: u.show, cam: u.cam ? ccGxCamView(u.cam) : null,
            v2: { top: u.v2 ? u.v2.top : null, edge: u.v2 ? u.v2.edge : null }, sel: (GX && GX.D && GX.D.S && ccIsNum(GX.D.S.sel)) ? GX.D.S.sel : u.sel };
   for (var k in (extra || {})) if (extra.hasOwnProperty(k)) o[k] = extra[k];
   return o;
}
// GRABAR con el grabador de la fase 2a (src/ui/cc_journey_video.js · ccJourneyRecord(opts, frameFn, onProgress)).
// opts: los del grabador (path, width, height, fps, duration, format, title, sheet…) y los del vídeo (color, sel, myr, turnDeg).
function ccGalaxyRecord(G, opts, onProgress) {
   var o = opts || {}, vo = {};
   for (var k in o) if (o.hasOwnProperty(k)) vo[k] = o[k];
   vo.tUnit = "s";
   var V = ccGalaxyVideo(G, vo);
   if (typeof ccJourneyRecord !== "function") return { ok: false, why: "ccJourneyRecord no está (src/ui/cc_journey_video.js sin incluir)" };
   var ro = {};
   for (k in o) if (o.hasOwnProperty(k)) ro[k] = o[k];
   if (!ro.duration) ro.duration = V.durationS;
   if (!ro.fps) ro.fps = V.fps;
   if (!ro.title) ro.title = ccGxT("gxVideoTitle");
   return ccJourneyRecord(ro, V.frameFn, onProgress);
}
#endif
