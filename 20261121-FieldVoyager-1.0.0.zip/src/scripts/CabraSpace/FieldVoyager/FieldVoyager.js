#engine v8
// ============================================================================
// FieldVoyager.js — VUELA DENTRO DE TU FOTO (CabraScripts, F1, 3-nov-2026)
// ----------------------------------------------------------------------------
// Convierte la imagen activa (con solucion astrometrica; si no la tiene, se resuelve) en una escena 3D: estrellas de Gaia DR3
// a su distancia, nebulosa en capas a su distancia de catalogo; y la vuela desde una cabina retro.
//   src/engine  la escena, la camara y los vuelos: PURO, serializable a JSON (D1: lo leera tambien el visor WebGL)
//   src/build   de la foto a la escena (lo que toca PixInsight: Gaia, astrometria y nebulosas de CabraShared, estrellas fuera)
//   src/ui      el pintor PJSR, la ficha, la cabina, la botonera y el dialogo
// CabraShared se INCLUYE (../CabraShared), no se edita. Uso: README.md; estado: HANDOFF.md.
// Para incluirlo sin abrir el dialogo (pruebas):  #define FV_NO_MAIN 1  y  #include ".../FieldVoyager.js"
// ES5 salvo las clases de widget (V8).
// ============================================================================

#feature-id    FieldVoyager : CabraSpace > FieldVoyager
#feature-icon  @script_icons_dir/FieldVoyager.svg
#feature-info  FieldVoyager: fly inside your astrophoto. Gaia DR3 stars at their distances and the nebula in layers at its \
               catalogue distance, flown from a retro spaceship cockpit.

#define FV_VERSION "1.0.0"
#ifndef FV_NO_MAIN
#define FV_NO_MAIN 0
#endif

#include "src/fv_shared.jsh"
#include "src/engine/fv_math.js"
#include "src/engine/fv_scene.js"
#include "src/engine/fv_look.js"
#include "src/engine/fv_pilot.js"
// (8-nov) el LABORATORIO DE VUELO: la navegacion nueva detras de FV_LAB.ON (apagado = la de antes; tecla L en la nave)
#include "src/engine/fv_flightlab.js"
// (F4b) quitar el polvo (color y Teff verdaderos) y la Via Lactea de fondo simulada (puros)
#include "src/engine/fv_dust.js"
#include "src/engine/fv_galaxy3d.js"         // (encargo D, 9-nov) la galaxia vista desde fuera (Reid et al. 2019)
#include "src/engine/fv_galdata.js"          // (encargo GP, 9-nov) la Via Lactea de catalogos publicos (bandera FV_GAL_DATA.ON, encendida por defecto desde el 10-nov)
#include "src/engine/fv_galgeom.js"         // (encargo GG, 9-nov) la geometria ajustada de la galaxia propia (bandera FV_GAL_GG.ON, encendida por defecto desde el 10-nov)
#include "src/engine/fv_galgeom_fit.js"     // (encargo GG) los numeros del ajuste directo (tests/_galaxy/gg/gg_fit.js): datos, no codigo
#include "src/engine/fv_galcolor.js"         // (encargo GC, 9-nov) el color real de la galaxia, blanco = espiral media de SPCC (bandera FV_GAL_COLOR.ON, encendida por defecto desde el 10-nov)
#include "src/engine/fv_milkyway.js"
#include "src/engine/fv_ambient.js"          // (11-nov) el campo de estrellas de fondo simulado, con paralaje (bandera FV_AMB.ON)
// (F4b) la fecha de la luz redondeada al error de la distancia
#include "src/engine/fv_epoch.js"
#include "src/engine/fv_time.js"
// (F2, 20-nov) la estrella fugitiva con el criterio de la literatura (velocidad peculiar, errores de Gaia, estrella caliente y luminosa) y la velocidad peculiar de cada estrella para el modo GALAXIA de AETAS (bandera FV_RUNAWAY.ON)
#include "src/engine/fv_runaway.js"
// (N8) los objetos singulares del campo: segmentacion, volumen, clic, ficha y destino (puro)
#include "src/engine/fv_objects.js"
// (V2, 5-nov) el volumen por familias de forma (cascara / disco / nebulosa extensa) y los mapas de relieve del visor web (los mismos: paridad)
#include "src/engine/fv_volume.js"
// (V3, ronda 3) pilas genericas: el disco en pilas alineadas con el disco, el relieve de la nebulosa solo con estructura de la foto
#include "src/engine/fv_volume3.js"
#include "web/fw_relief.js"
// (pasada M) la ruta propuesta (fvTourPlan, Codex K6): el boton PROPONER del mapa grande
#include "src/engine/fv_tour_plan.js"
// (19-nov, I5) el vigilante del sonido que informa (E1-18 y E1-19): FV_E1A, fvE1aStep (puro); lo oye la radio (src/radio)
#include "src/engine/fv_e1a.js"
#include "src/engine/fv_e1.js"            // (20-nov, I4) E1-01 QUAESTIO, E1-12 balanceo, E1-13 mirar a casa, E1-14 silencio: la parte pura (la misma en el visor web)
// (I1, 19-nov) AENIGMATA + la cadena de «¿por que?» (E1-03 y E1-04): los misterios de la foto y el eslabon de cada ficha (puro; bandera FV_E1C.ON)
#include "src/engine/fv_aenigma.js"
#include "src/engine/fv_photostars.js"
#include "src/build/fv_exo.js"
#include "src/build/fv_stf.js"            // (E2, 11-nov) el estirado de la foto (la regla comun de CabraShared) y su reconstruccion
#include "src/build/fv_mira.js"           // (R8, 12-nov) MIRABILIA solo lo que se ve en la foto: estrellas detectadas, cumulos, brillo superficial (FV_MIRA)
#include "src/build/fv_hipdist.js"          // (3b, 20-nov) distancia de Hipparcos para las brillantes que Gaia no mide + su nombre (FV_HIPD)
#include "src/build/fv_build.js"
#include "src/build/fv_ps_build.js"
#include "src/build/fv_rv.js"
// (F3) el paquete de escena y «Abrir en el navegador» (fvOpenInBrowser); trae csh_web.js de CabraShared (navegador del sistema)
#include "src/export/fv_export.js"
#include "src/ui/fv_text.js"
#include "src/ui/fv_painter.js"
// (Blender 2, 5-nov) la ventana de la nave renderizada (solo con FV_FG.ON)
#include "src/ui/fv_foreground.js"
// (N8) el pintor de los objetos compactos (lo llama una linea del pintor)
#include "src/ui/fv_objects_paint.js"
// (V2, 5-nov) el pintor del volumen por familias (solo con FV_VOLM.ON)
#include "src/ui/fv_volume_paint.js"
#include "src/ui/fv_hud.js"
// (6-nov) los dos modos (Foto / Espacio): lo que se dibuja en Espacio (la regla esta en src/engine/fv_pilot.js)
#include "src/ui/fv_navmodes.js"
// (8-nov) el panel del laboratorio de vuelo (solo se pinta con el laboratorio encendido)
#include "src/ui/fv_flightlab_ui.js"
// (I12/I13) la ficha: el espectro XP (panel animado) y la composicion; los datos los trae fv_card_sci.js fuera del pintado
#include "src/ui/fv_hud_xp.js"
#include "src/ui/fv_card_sci.js"
// (pasada N) la composicion solidaria de la foto (N7) y TABULA / PROFUNDITAS / MIRABILIA en la franja (N1)
// (I3, 5-nov) el buscador de MIRABILIA: el indice, la consulta y las teclas (fv_nav.js lo pinta, fv_dialog.js lo gobierna)
#include "src/ui/fv_search.js"
#include "src/ui/fv_nav.js"
// (I1, 19-nov) el reverso AENIGMATA de la placa MIRABILIA y la pregunta de la ficha (lo que pinta y lo que se pulsa)
#include "src/ui/fv_aenigma_ui.js"
// (9-nov, encargo C) los planos que limitan el 3D de la imagen (vuelo y PROFUNDITAS) y el icono de la nave; FV_BOUNDS apagado = hoy
#include "src/ui/fv_bounds.js"
#include "src/ui/fv_cockpit.js"
// (I3, 19-nov) AETAS con proposito: las estelas de ±100 000 años, la placa del año y los rotulos (bandera FV_E1T, en fv_cockpit.js)
#include "src/ui/fv_trails.js"
// (pasada M) ITINERARIUM: TABULA / PROFUNDITAS en grande, las camaras de la ruta y la fila de viaje de la ficha
#include "src/ui/fv_route.js"
#include "src/ui/fv_boot.js"
#include "src/ui/fv_exo_view.js"
// (Blender 1, 5-nov) los exoplanetas como mundos (sprites de Blender, rsc/planetas/); FV_PL3D.ON false = los de hoy
#include "src/ui/fv_planets3d.js"
#include "src/ui/fv_galaxy.js"               // (encargo D, 9-nov) boton GALAXIA y la Via Lactea de fondo nueva
#include "src/engine/fv_hr.js"               // (I2, 19-nov) el diagrama HR animado: motor puro (bandera FV_HR.ON)
#include "src/ui/fv_hr_ui.js"                // (I2) su boton, sus enganches del pintor y sus ejes
#include "src/ui/fv_buttons.js"
// (5-nov) LA COLUMNA DERECHA: foto, nombres, constelaciones desde la nave, escala y pantalla completa. Calculo puro en src/engine/fv_skyov.js;
// las figuras (Stellarium «modern», CC BY-SA 4.0) y las estrellas con nombre de la IAU en web/fw_const_data.js (THIRD_PARTY.txt; el mismo fichero lo carga el visor web)
#include "web/fw_const_data.js"
#include "src/engine/fv_skyov.js"
#include "src/ui/fv_stf_panel.js"         // (E2, 11-nov) el boton STF de la columna derecha y su panel
#include "src/ui/fv_rightbar.js"
// (F4b) REC: el video con reloj fijo. ffmpeg solo si el usuario lo elige (CabraShared) y el AVI propio de Cabra3D (incluidos, no editados)
#include "CabraShared/csh_ffmpeg.js"
#include "Cabra3D/src/engine/video_avi.js"
#include "src/ui/fv_rec.js"
#include "src/ui/fv_e1_ui.js"           // (20-nov, I4) lo que se ve y se toca de E1 (placa QUAESTIO, balanceo, boton CASA)
// (pasada N, N2) la radio de a bordo de verdad: un WebView con src/radio/fv_radio.html (que tiene que viajar junto a fv_radio.js)
#include "src/radio/fv_radio.js"
#include "src/ui/fv_dialog.js"

function fvMain() {
   fvLoadLang();
   console.show();
   var w = ImageWindow.activeWindow;
   if (!w || w.isNull) { new MessageBox("FieldVoyager: open an image first (a deep-sky photo).\nFieldVoyager: abre primero una imagen (una foto de cielo profundo).", "FieldVoyager", StdIcon_Information, StdButton_Ok).execute(); return; }
   fvLog("version " + FV_VERSION + " · " + w.mainView.id + ": the ship opens powered down; pull the lever to build the scene");
   console.flush();
   // (F2, D10) la nave se abre APAGADA: la escena se construye al tirar de la palanca, con cada sistema encendiendose a la vista
   // (pasada N, N7) auto: la ventana se compone con su tamaño (el de la ultima vez, o el 92 % de la pantalla) y se recompone al redimensionarla
   var ww = 0, wh = 0; try { ww = parseInt(Settings.read(CP_SETTINGS_PREFIX + "/winW", DataType_String), 10) || 0; wh = parseInt(Settings.read(CP_SETTINGS_PREFIX + "/winH", DataType_String), 10) || 0; } catch (eW) {}
   var D = new FVDialog(w.mainView, { online: true, solverDialog: true, auto: true, winW: ww >= 760 ? ww : 0, winH: wh >= 480 ? wh : 0 });
   D.execute();
   D.shutdown("execute returned");
}

if (!FV_NO_MAIN) fvMain();
