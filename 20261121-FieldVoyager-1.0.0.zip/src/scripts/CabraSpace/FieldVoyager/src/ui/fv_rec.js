// ============================================================================
// FieldVoyager/src/ui/fv_rec.js — REC: GRABAR EL VUELO A VIDEO CON RELOJ FIJO (F4b, 4-nov-2026; idea I5 del analisis, de OpenSpace/Gaia Sky)
// ----------------------------------------------------------------------------
// Volar en vivo va a lo que de la maquina (30–40 fps, irregular); un video tiene que salir a 30 fps exactos y a 1920 × 1080. Por eso se
// graba el GUION, no la pantalla:
//   1. REC: en cada paso del reloj de escena se apunta un fotograma clave (camara, warp, estelas, destello, objeto elegido, rotulos,
//      ficha, idioma, relojes de la cabina) — fvRecSnap;
//   2. STOP: se rehace cada fotograma n del video en t = t0 + n/fps (RELOJ FIJO), interpolando entre las claves (posicion lineal, mirada
//      por slerp, campo de vision en logaritmo; lo discreto, de la clave anterior) y se pinta con el MISMO pintor a W × H, aunque cada
//      fotograma tarde lo que tarde (fvRecRender). La ficha y los rotulos se escalan con la pantalla (texto vectorial, nitido);
//   3. el video: AVI (Motion JPEG) que escribe el script solo (Cabra3D/src/engine/video_avi.js, incluido) o, si el USUARIO ha elegido un
//      ffmpeg (CabraShared/csh_ffmpeg.js, regla CPD 5.3 b: nunca se busca ni se lanza sin que lo elija), MP4 H.264 a partir de ese AVI.
// Con la cabina (opcion): la nave entera escalada a la altura del video (pantalla + franja de instrumentos), con bandas laterales del
// color de la cabina. Sin ella: la pantalla a 1920 × 1080.
// Las carpetas que elige el usuario (video y exportacion) se recuerdan (fvPickDir). Nada de dialogos en las pruebas: FV_PICKDIR_HOOK.
// ES5.
// ============================================================================

// (nA2, E7) MIENTRAS SE PINTA EL VIDEO la nave queda bloqueada (fv_dialog.js: recLocked); false = el comportamiento de antes (CONTROL EN ROJO de las pruebas)
var FV_REC_LOCK = true;
// pruebas: function(n, N, phase) llamada en cada fotograma pintado, desde dentro del bucle (simula lo que el usuario haria en ese instante)
var FV_REC_PROBE = null;
var FV_REC = { W: 1920, H: 1080, FPS: 30, Q_AVI: 92, MAX_S: 600, PUMP_MS: 120 };
var FV_PICKDIR_HOOK = null;     // pruebas: function(key, current) -> carpeta | null (en vez del cuadro de elegir carpeta)
var FV_REMEMBER = true;         // pruebas: false = no se toca lo recordado de verdad (Settings)
var FV_OPENDIR_DRY = false;     // pruebas: abrir la carpeta solo se prepara, no se lanza el gestor de archivos
// F4-D1 (decision de Nino, PENDIENTE): regla CPD 5.8 «PixInsight is not a launcher for other applications». Exportar el vuelo escribe una
// carpeta que el usuario abre por su cuenta; lanzar el navegador automaticamente queda APAGADO. Con true, tras exportar se abriria
// index.html con el navegador del sistema (cshSystemBrowser). «PTeam alone decides» si eso es usar PixInsight como lanzador.
var FV_LAUNCH_BROWSER = false;

function fvSetRead(key, def) { try { var v = Settings.read(CP_SETTINGS_PREFIX + "/" + key, DataType_String); if (v !== null && v !== undefined && String(v).length) return String(v); } catch (e) {} return def; }
function fvSetWrite(key, v) { if (!FV_REMEMBER) return; try { Settings.write(CP_SETTINGS_PREFIX + "/" + key, DataType_String, String(v)); } catch (e) {} }
// la carpeta recordada para `key`; si no hay (o force), se pide (cuadro de PixInsight; en pruebas, el gancho). -> ruta | null
function fvPickDir(key, caption, force) {
   var cur = fvSetRead(key, "").split("\\").join("/");
   if (cur && !force && File.directoryExists(cur)) return cur;
   var p = null;
   if (typeof FV_PICKDIR_HOOK === "function") p = FV_PICKDIR_HOOK(key, cur);
   else { try { var d = new GetDirectoryDialog; d.caption = caption; if (cur && File.directoryExists(cur)) d.initialPath = cur; if (d.execute()) p = d.directory; } catch (e) { p = null; } }
   if (!p) return null;
   p = String(p).split("\\").join("/").replace(/\/+$/, "");
   fvSetWrite(key, p);
   return p;
}
// abrir una CARPETA con el gestor de archivos del sistema (utilidad del sistema, auxiliar: CPD 5.3 c; solo con un clic del usuario)
function fvOpenFolder(dir) {
   if (typeof cshSystemBrowser !== "function") return { ok: false, why: "cshSystemBrowser not available" };
   var r = cshSystemBrowser(dir, { dry: FV_OPENDIR_DRY === true });
   fvLog("open folder " + dir + (FV_OPENDIR_DRY ? " (dry)" : "") + " with " + r.exe + " → " + (r.ok ? "ok" : "FAILED " + r.why));
   return r;
}
// el formato del video: "avi" (sin programas externos, de fabrica) | "mp4" (con el ffmpeg que eligio el usuario)
function fvRecFormat() { var m = (typeof cshFfmpegMode === "function") ? cshFfmpegMode(CP_SETTINGS_PREFIX) : "off"; return (m === "off") ? "avi" : "mp4"; }
function fvRecFfmpeg() { try { return (typeof cpAviFfmpeg === "function") ? cpAviFfmpeg(true) : { available: false, why: "video_avi.js not included" }; } catch (e) { return { available: false, why: String(e) }; } }

// ---------------------------------------------------------------------------
// 1. EL GUION: un fotograma clave del dialogo D
// ---------------------------------------------------------------------------
function fvRecSnap(D) {
   var P = D.P, fl = P.flight, gz = D.gauges(), s = P.sel;
   return { t: P.t, pos: P.cam.pos.slice(), look: P.cam.look.slice(), fov: P.cam.fov, roll: P.cam.roll || 0, warp: P.warp, flash: P.flash, trail: P.trail,   // (nP) roll de la camara
            fl: fl ? { T: fl.T ? fl.T.slice() : null, sel: fl.sel || null, kind: fl.kind } : null,
            sel: s ? { kind: s.kind, i: s.i, sx: s.sx, sy: s.sy, t0: s.t0 } : null, arrivedAt: P.arrivedAt, sunMark: P.sunMark, homeFov: P.homeFov, style: P.style,
            gz: { speedLyS: gz.speedLyS || 0, speedC: gz.speedC || 0, warp: gz.warp || 0, dist: gz.dist || 0, clock: gz.clock || 0, reg: gz.reg || 0, regSet: (gz.regSet !== undefined ? gz.regSet : 0.5), style: gz.style, power: 1, seen: !!gz.seen },
            lang: FV_LANG, mw: D.painter ? D.painter.mwOn : true,
            // (11-nov, NV-14) CON EL LABORATORIO la camara es una base completa (cam.B) en el espacio de vuelo estirado S: sin guardarlas, el video
            // se pintaba con el proyector de antes y la lente de 50° sin estirar (otra imagen que la que se vio). Y lo que el pintor lee de P.lab (el ancla)
            lab: (P.lab && P.cam.B) ? { f: P.cam.B.f.slice(), r: P.cam.B.r.slice(), d: P.cam.B.d.slice(), S: P.cam.S || P.lab.S || 1, anchor: P.lab.anchor || 0, anchorOn: !!P.lab.anchorOn, orb: (typeof fvAmbTurning === "function") ? fvAmbTurning(P) : false } : null,
            // (N2, punto 2 de Nino) la ficha solo sale con INFO o al llegar: el video la respeta (cardClosed / hideCard del dialogo en ese instante)
            ui: { legendOpen: D.ui.legendOpen, cardMore: D.ui.cardMore, caption: D.ui.caption, exo: D.ui.exo, exoList: D.ui.exoList, cardClosed: D.ui.cardClosed, hideCard: D.ui.hideCard } };
}
function fvRecLerpLog(a, b, u) { return Math.exp(Math.log(a) + (Math.log(b) - Math.log(a)) * u); }
// el estado en el instante t (interpolado) -> { P (lo que lee el pintor), ui, gz, lang, mw }
function fvRecState(keys, t, scene) {
   var n = keys.length, lo = 0, hi = n - 1;
   if (t <= keys[0].t) hi = 0; else if (t >= keys[n - 1].t) lo = n - 1;
   else { while (hi - lo > 1) { var m = (lo + hi) >> 1; if (keys[m].t <= t) lo = m; else hi = m; } }
   var a = keys[lo], b = keys[Math.max(lo, hi)], u = (b.t > a.t) ? fvClamp((t - a.t) / (b.t - a.t), 0, 1) : 0;
   var P = { scene: scene, t: t, cam: { pos: fvLerp(a.pos, b.pos, u), look: fvSlerpDir(a.look, b.look, u), fov: fvRecLerpLog(a.fov, b.fov, u), roll: (a.roll || 0) + ((b.roll || 0) - (a.roll || 0)) * u },
             warp: a.warp + (b.warp - a.warp) * u, trail: a.trail + (b.trail - a.trail) * u, flash: (u < 0.5) ? a.flash : b.flash,
             flight: a.fl ? { T: a.fl.T, sel: a.fl.sel, kind: a.fl.kind } : null, sel: a.sel, arrivedAt: a.arrivedAt, sunMark: a.sunMark,
             homeFov: a.homeFov, style: a.style, orbit: null, mode: "rec" };
   if (a.lab) {
      var lb = b.lab || a.lab, Bf = fvSlerpDir(a.lab.f, lb.f, u), Br = fvNorm(fvLerp(a.lab.r, lb.r, u));
      Br = fvNorm(fvSub(Br, fvMul(Bf, fvDot(Br, Bf))));
      P.cam.B = { f: Bf, r: Br, d: fvNorm(fvCross(Bf, Br)) }; P.cam.look = Bf.slice(); P.cam.roll = 0;
      P.cam.S = fvRecLerpLog(Math.max(1e-9, a.lab.S), Math.max(1e-9, lb.S), u);
      P.lab = { rec: true, S: P.cam.S, anchor: a.lab.anchor + (lb.anchor - a.lab.anchor) * u, anchorOn: a.lab.anchorOn, orb: !!a.lab.orb, keys: {} };
   }
   var gz = {}; for (var k in a.gz) gz[k] = (typeof a.gz[k] === "number") ? a.gz[k] + (b.gz[k] - a.gz[k]) * u : a.gz[k];
   gz.clock = t;
   return { P: P, ui: a.ui, gz: gz, lang: a.lang, mw: a.mw };
}

// ---------------------------------------------------------------------------
// 2. LOS FOTOGRAMAS A RELOJ FIJO y 3. el video
// D: el dialogo (pintor, cabina, tamaño de la pantalla); rec: { t0, t1, keys }
// o: { dir, fps, W, H, cockpit, ffmpeg (para las pruebas: { available, path }), saveFrames: [n…], savePrefix, onProgress(n, N, phase) -> false cancela }
// -> { ok, why, frames, file, format, w, h, fps, ms, renderMs: [], avi, mp4, mp4Why }
// ---------------------------------------------------------------------------
function fvRecRender(D, rec, o) {
   o = o || {};
   var t00 = Date.now(), W = o.W || FV_REC.W, H = o.H || FV_REC.H, fps = o.fps || FV_REC.FPS, out = { ok: false, why: "", frames: 0, file: "", format: "", w: W, h: H, fps: fps, ms: 0, renderMs: [] };
   if (!rec || !rec.keys || rec.keys.length < 1) { out.why = "nothing recorded"; return out; }
   if (typeof cpAviOpen !== "function") { out.why = "video_avi.js not included"; return out; }
   var N = Math.max(1, Math.round((rec.t1 - rec.t0) * fps)), VW = D.VW, VH = D.VH, SH = D.stripH || FV_UI.STRIP_H, cab = !!o.cockpit;
   var s = cab ? H / (VH + SH) : W / VW, sw = cab ? Math.round(VW * s) : W, sh = cab ? Math.round(VH * s) : H, x0 = Math.round((W - sw) / 2);
   var frame = new Bitmap(W, H, BitmapFormat.RGB32), scn = cab ? new Bitmap(sw, sh, BitmapFormat.RGB32) : frame;
   var stamp = (function() { var d = new Date, p = function(v) { return (v < 10 ? "0" : "") + v; }; return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + "_" + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds()); })();
   var base = String(o.dir).split("\\").join("/").replace(/\/+$/, "") + "/" + (o.name || ("FieldVoyager_" + stamp)), ff = o.ffmpeg || fvRecFfmpeg(), mp4 = !!(ff && ff.available);
   var avi = base + ".avi", wr = null, keepLang = FV_LANG, pnt = D.painter, keepMw = pnt.mwOn, keepHits = pnt.hits, lastPump = Date.now();
   try {
      // la carpeta elegida puede no existir aun (borrada entre sesiones, o recordada en otro disco): se crea, como hace la exportacion
      var dirOut = base.substring(0, base.lastIndexOf("/"));
      if (!File.directoryExists(dirOut)) File.createDirectory(dirOut, true);
      wr = cpAviOpen(avi, W, H, fps, {});
      for (var n = 0; n < N; ++n) {
         var tr = Date.now(), st = fvRecState(rec.keys, rec.t0 + n / fps, D.scene);
         FV_LANG = st.lang; pnt.mwOn = st.mw;
         pnt.render(scn, st.P, { hud: false, frame: false, vignette: true, fg: (typeof fvFgRecOn === "function") ? fvFgRecOn(cab) : false });   // (Blender 2) la ventana, con la cabina
         var g = new Graphics(scn);
         try {
            g.antialiasing = true; g.textAntialiasing = true;
            g.transformationMatrix = new Matrix(sw / VW, 0, 0, 0, sh / VH, 0, 0, 0, 1);
            if (pnt.stats.heroR) pnt.stats.heroR /= (sw / VW);
            fvHudPaint(g, pnt, fvProjector(st.P.cam, VW, VH), st.P, VW, VH, { ui: st.ui });
            if (!(pnt.stats.fg && pnt.stats.fg.frame)) fvFramePaint(g, VW, VH);      // (Blender 2) con la ventana renderizada, sin el marco dibujado
         } finally { g.end(); }
         if (cab) {
            frame.fill(0xff110D09);
            var g2 = new Graphics(frame);
            try {
               g2.drawBitmap(x0, 0, scn);
               g2.antialiasing = true; g2.textAntialiasing = true; g2.smoothInterpolation = true;
               g2.transformationMatrix = new Matrix(s, 0, x0, 0, s, sh, 0, 0, 1);
               D.cockpit.paint(g2, st.gz);
               // (pasada N) la TABULA, PROFUNDITAS y MIRABILIA tambien en el video (con la camara del fotograma)
               st.P.VW = VW; st.P.VH = VH;
               if (D.nav && typeof D.cockpit.paintNav === "function") D.cockpit.paintNav(g2, { scene: D.scene, P: st.P, map2d: D.nav.map2d, map3d: D.nav.map3d, list: { items: D.nav.list.items, top: D.nav.list.top, sel: st.P.sel, ready: true } });
            } finally { g2.end(); }
         }
         if (o.saveFrames && o.saveFrames.indexOf(n) >= 0) frame.save((o.savePrefix || base + "_f") + ("00" + n).slice(-3) + ".png");
         var ra = wr.addBitmap(frame, mp4 ? CP_AVI.MP4_SOURCE_QUALITY : FV_REC.Q_AVI);
         if (!ra.ok) throw new Error("AVI frame " + n + ": " + ra.why);
         out.renderMs.push(Date.now() - tr); out.frames = n + 1;
         if (typeof o.onProgress === "function" && (Date.now() - lastPump > FV_REC.PUMP_MS || n === N - 1)) {
            lastPump = Date.now(); FV_LANG = keepLang; pnt.mwOn = keepMw;
            var keepOn = o.onProgress(n + 1, N, "render");
            // (pruebas) justo despues del aviso de progreso (con sus zonas pulsables puestas): lo que el usuario haria en este instante
            if (typeof FV_REC_PROBE === "function") { try { FV_REC_PROBE(n + 1, N, "render"); } catch (eProbe) { fvLog("REC probe: " + eProbe); } }
            if (keepOn === false) throw new Error("cancelled");
         }
      }
      var cl = wr.close(); wr = null;
      if (!cl.ok) throw new Error("AVI: " + cl.why);
      out.avi = avi; out.file = avi; out.format = "avi"; out.bytes = cl.bytes;
      if (mp4) {
         if (typeof o.onProgress === "function") o.onProgress(N, N, "mp4");
         var keepFf = (typeof CP_AVI_FFMPEG_CACHE !== "undefined") ? CP_AVI_FFMPEG_CACHE : null;
         if (o.ffmpeg) CP_AVI_FFMPEG_CACHE = o.ffmpeg;                       // las pruebas eligen el ejecutable sin tocar lo recordado
         var r = cpAviToMp4(avi, base + ".mp4", { onTick: function() { if (typeof o.onProgress === "function") o.onProgress(N, N, "mp4"); return true; } });
         if (o.ffmpeg) CP_AVI_FFMPEG_CACHE = keepFf;
         if (r.ok) { out.mp4 = base + ".mp4"; out.file = out.mp4; out.format = "mp4"; out.bytes = r.bytes; try { File.remove(avi); out.avi = ""; } catch (eR) {} }
         else { out.mp4Why = r.why; fvLog("REC: MP4 failed (" + r.why + "): the AVI stays · " + String(r.log || "").substring(0, 300)); }
      }
      out.ok = true;
   } catch (e) { out.why = String((e && e.message) ? e.message : e); try { if (wr) wr.abort(); } catch (eA) {}
      // (nA2, E7) cancelado: el AVI a medias no sirve de nada (abort() lo cierra pero lo deja en el disco)
      if (out.why === "cancelled") { try { if (File.exists(avi)) File.remove(avi); } catch (eRm) {} } }
   finally { FV_LANG = keepLang; pnt.mwOn = keepMw; pnt.hits = keepHits; pnt.cardKey = ""; }
   out.ms = Date.now() - t00;
   fvLog("REC: " + (out.ok ? out.frames + " frames " + W + "x" + H + " @ " + fps + " fps → " + out.file + " (" + out.format + ", " + Math.round(out.ms / 1000) + " s)" : "FAILED " + out.why));
   return out;
}
