#engine v8
// ============================================================================
// fv_navmodes.js — LOS DOS MODOS en la pantalla de PixInsight (6-nov-2026; la regla y lo que se dibuja: fvNmStep / fvNmHud en
// src/engine/fv_pilot.js; su gemelo web: web/fw_navmodes.js). En ESPACIO nunca hay «niebla del desierto»:
//   · la foto como PIRAMIDE FANTASMA en su sitio: aristas doradas finas de la Tierra al marco y la foto translucida en su plano (vista por
//     detras sale al reves y mas apagada: «la espalda de tu foto»); nunca opacidad 0 (fvNmGhostPaint, desde FVPainter.paintLayers)
//   · marcadores en el borde de la pantalla (estilo KSP / Elite, oro Atlas): TU FOTO, CASA y el DESTINO; en pantalla, una mira
//   · (20-nov, E-nav) la brujula redonda y el marcador CASA YA NO SALEN de fabrica (FV_NMX en fv_pilot.js: el boton Home ya vuelve); el marcador TU FOTO se
//     PULSA: clic o doble clic en su placa, flecha o rotulo = la nave vuelve volando a la foto (fvNmPhotoSel; zonas en painter.nmHits, id «nm-photo»)
//   · (20-nov, O1) el marcador TU FOTO ENSEÑA UNA MINIATURA de la propia foto (painter.nmThumb, hecha una vez al construir el pintor) con marco dorado fino y «TU FOTO · n a.l.»
//     debajo: en la placa del borde, en la mira y como POSTAL de la foto minima (la foto fantasma a tamaño minimo pasa a ser esa tarjeta, nitida y del derecho) (FV_NMX.THUMB false = la placa con icono y texto de antes). Dibujo: fvNmThumbPaint
//   · el rotulo fijo «ESPACIO · fuera de tu foto — H para volver»
// En FOTO, con una estrella de detras de la nebulosa, una nota de profundidad (el tour se queda en Foto y mira a traves de la nebulosa).
// Nada de procesos aqui: solo dibuja lo que da fvNmHud.
// ============================================================================
var FV_NMP = { GOLD: 0xE5B53F, GOLDL: 0xF3D27E, TEXT: 0xFBF2E0, TEXT2: 0xD0C1A5, INK: 0x0B0906, EARTH: 0x9CC3E6 };
// (Blender 4 · defectos 5 y 6) NOCLASH false = lo de antes (el rotulo ESPACIO centrado aunque la placa DATOS lo pise; el rotulo DESTINO bajo
// el disco del transito): el ROJO de la comprobacion de solapes de tests/fv_pl3d_app_test.js
var FV_NM_B4 = { NOCLASH: true };
function fvNmArgb(rgb, a) { return (((Math.round(fvClamp(a, 0, 1) * 255)) << 24) | rgb) >>> 0; }

// la foto fantasma en su plano (dentro del paso de capas, antes de las estrellas)
function fvNmGhostPaint(painter, g, pr, P) {
   var labA = !!(P.lab && P.lab.anchorOn);                               // (8-nov, LABORATORIO, D10) el ancla tambien en Foto
   // (v2) con el laboratorio encendido el fantasma es SOLO el ancla, con su fundido (sin paisaje); el modo Espacio de hoy no lo pinta
   var labOn = !!(P.lab && typeof FV_LAB !== "undefined" && FV_LAB.ON === true), labF = labOn ? (P.lab.anchor || 0) : 1;
   if (labOn && labF < 0.01) return false;
   if (typeof fvNmOn !== "function" || !fvNmOn() || (fvNmMode(P) !== "space" && !labA && !labOn) || !painter.photoPlane) return false;
   var N = painter.scene.nebula; if (!N || !N.layers || !N.layers.length) return false;
   var v = fvNmValid(P, P.cam.pos), gh = Math.max(0.35, 1 - v), behind = P.cam.pos[2] > N.distLy;
   var op = FV_NAV_MODES.GHOST_A * gh * (behind ? 0.6 : 1) * (1 - 0.8 * fvSmooth((P.warp || 0) / 0.6));
   if (labOn) op *= labF;
   if (op < 0.01) return false;
   var L0 = N.layers[0], d0 = N.distLy, spacing = (N.layers.length > 1) ? N.thickLy / (N.layers.length - 1) : N.thickLy;
   var Lp = { z: d0, x0: L0.x0 / L0.z * d0, y0: L0.y0 / L0.z * d0, x1: L0.x1 / L0.z * d0, y1: L0.y1 / L0.z * d0 };
   var keep = g.compositionOperator; g.compositionOperator = CompositionOp_SourceOver;
   var ok = painter.drawPlane(g, pr, P, painter.photoPlane, Lp, op, spacing);
   g.compositionOperator = keep; g.opacity = 1;
   painter.stats.navGhost = ok ? op : 0;
   return ok;
}

// el rotulo, la piramide, los marcadores y la brujula (encima de todo, antes del HUD de la ficha)
// (Blender 5b · R5-3) las zonas que el rotulo DESTINO no puede pisar, calculadas EN ESTE FOTOGRAMA (pixeles reales): el disco del transito sobre la estrella (con el rotulo de
// debajo) y la escuadra de seleccion de la ficha. Antes se usaba el disco del fotograma ANTERIOR (painter.exoOnStar): tras un fotograma de otro tamano o al abrirse el
// panel no habia disco y el rotulo salia debajo de el («STINO · 14 a.l.»), y la escuadra no contaba. FV_B5B.DEST false = lo de Blender 5 (el ROJO de la comprobacion)
function fvNmClearZones(painter, P, W, H, pr, ui) {
   var out = [], sc = painter.scene;
   if (!pr || !sc || typeof fvHudScaledPr !== "function") return out;
   var k = fvHudK(W), pk = fvHudScaledPr(pr, k), E = ui ? ui.exo : null, Wu = W / k, Hu = H / k;
   if (E && E.star !== undefined && E.star !== null && sc.stars && typeof FV_EXOV !== "undefined") {
      var sp = pk.project(fvStarPos(sc, E.star));
      if (sp && sp[0] > -20 && sp[0] < Wu + 20 && sp[1] > -20 && sp[1] < Hu + 20) {
         var Rd = FV_EXOV.ON_STAR_R, r = Rd + 5, eo = painter.exoOnStar, cap;
         out.push([(sp[0] - r) * k, (sp[1] - r) * k, (sp[0] + r) * k, (sp[1] + r) * k]);
         // el rotulo de debajo del disco: su caja del fotograma anterior si es de la misma estrella en el mismo sitio; si no, una franja ancha (mejor de mas que de menos)
         if (eo && eo.cap && Math.abs(eo.x - sp[0] * k) < 1 && Math.abs(eo.y - sp[1] * k) < 1) cap = eo.cap;
         else cap = [(sp[0] - 200) * k, (sp[1] + Rd + 7) * k, (sp[0] + 200) * k, (sp[1] + Rd + 22) * k];
         out.push(cap);
      }
   }
   var sel = P.sel;
   if (sel && (sel.kind === "star" || sel.kind === "object") && typeof fvCardAnchor === "function") {
      var an = fvCardAnchor(painter, sc, pk, P, sel);
      if (an && an.sx > -4 && an.sy > -4 && an.sx < Wu + 4 && an.sy < Hu + 4) {
         var kk = fvEaseOutBack((P.t - sel.t0) / 0.4), R = Math.max(an.rr, an.rr * (1 + 2.2 * (1 - kk))) + 2;
         out.push([(an.sx - R) * k, (an.sy - R) * k, (an.sx + R) * k, (an.sy + R) * k]);
      }
   }
   return out;
}
// (20-nov, E-nav) las zonas pulsables del marcador TU FOTO, en pixeles reales del fotograma (como g). Se rehacen en cada fvNmPaint y fvPainter las suma a painter.hits
// DESPUES del HUD (el HUD vacia la lista y sus placas, encima, mandan: las nuestras van las ultimas). FV_NMX.PHOTO_GO false = ninguna
var FV_NM_HITS = [], FV_NM_OP = 1;      // FV_NM_OP: el fundido del ancla del laboratorio; con menos de 0,35 el rotulo casi no se ve y no se pulsa
var FV_NM_TB = null, FV_NM_ST = null;   // FV_NM_TB: la miniatura de TU FOTO de este fotograma (null = sin ella: lo de antes); FV_NM_ST: painter.stats, donde se apunta la ultima tarjeta (nmThumb)
function fvNmHitAdd(x0, y0, x1, y1) {
   if (typeof FV_NMX === "undefined" || FV_NMX.PHOTO_GO !== true || FV_NM_OP < 0.35) return;
   FV_NM_HITS.push({ id: "nm-photo", x0: Math.min(x0, x1), y0: Math.min(y0, y1), x1: Math.max(x0, x1), y1: Math.max(y0, y1) });
}
function fvNmPaint(g, painter, P, W, H, pr, ui) {
   painter.nmHits = FV_NM_HITS = []; FV_NM_OP = 1;
   FV_NM_TB = (typeof FV_NMX !== "undefined" && FV_NMX.THUMB === true && painter.nmThumb) ? painter.nmThumb : null; FV_NM_ST = painter.stats; painter.stats.nmThumb = null;
   if (typeof fvNmHud !== "function" || !fvNmOn()) return null;
   var hud = fvNmHud(P, W, H), k = (typeof fvHudK === "function") ? fvHudK(W) : 1, C = FV_NMP;
   painter.stats.nav = { mode: hud.mode, lines: hud.lines.length, markers: hud.markers.length, ghostOnScreen: hud.ghostOnScreen };
   fvV1AidPaint(g, painter, P, W, H, hud, k);                             // (20-nov, V1a, V1-10) la flecha «la foto esta detras» y la reticula de la foto
   var labA = !!(P.lab && P.lab.anchorOn);                               // (8-nov, LABORATORIO, D10)
   // (v2) laboratorio: piramide, marcadores y foto minima solo como ANCLA y con su fundido (con paisaje se apaga: no tapa nada); sin rotulo de Espacio
   var labOn = !!(P.lab && typeof FV_LAB !== "undefined" && FV_LAB.ON === true), labF = labOn ? (P.lab.anchor || 0) : 1;
   FV_NM_OP = labF;
   if (labOn) { hud.banner = false; if (labF < 0.01 && !hud.note) return hud; labA = labF >= 0.01; if (!labA) hud.mode = "photo"; }
   if (hud.mode !== "space" && !hud.note && !labA) return hud;
   g.antialiasing = true; g.textAntialiasing = true; g.opacity = labF;
   var fB = cpFont("display", Math.round(12 * k), false, false, 2), fS = cpFont("text", Math.round(10 * k)), fM = cpFont("mono", Math.round(9 * k));
   if (hud.mode === "space" || labA) {
      // (F1) el halo dorado del borde hacia la foto (de espaldas a ella): tenue, debajo de lo demas
      if (hud.glow) {
         var gr = 0.42 * Math.min(W, H), gpt = new Point(hud.glow.x, hud.glow.y);
         g.pen = new Pen(0x00000000, 0);
         g.fillCircle(hud.glow.x, hud.glow.y, gr, new RadialGradientBrush(gpt, gr, gpt, [[0, fvNmArgb(C.GOLD, 0.26)], [0.45, fvNmArgb(C.GOLD, 0.09)], [1, fvNmArgb(C.GOLD, 0)]]));
      }
      // (F2) la foto fantasma a su tamaño minimo (de lejos, desde detras), con su marco luminoso y su rotulo «TU FOTO · x a.l.»
      var gm = hud.ghostMin;
      if (gm && FV_NM_TB) {
         // (O1) la POSTAL: la foto a tamaño minimo como la tarjeta de TU FOTO (placa, miniatura con su marco dorado fino y el rotulo debajo), nitida y del derecho (la «espalda» al reves
         // de antes no se reconocia); toda ella se pulsa. La tarjeta centra la miniatura en el centro de la foto
         var tGp = fvTx("nav.m.photo") + " · " + fvNmLy(gm.dist), fT = fvNmThumbFont(k); g.font = fT;
         var cdp = fvNmThumbCard(k, FV_NM_TB.height / FV_NM_TB.width, fT.width(tGp), 12 * k, Math.max(gm.w, gm.h));
         var pxp = gm.cx - cdp.cw / 2, pyp = gm.cy - gm.h / 2 - cdp.ty;
         fvNmThumbPaint(g, "postal", cdp, pxp, pyp, k, fT, tGp, C.GOLDL);
         fvNmHitAdd(pxp, pyp, pxp + cdp.cw, pyp + cdp.ch);
      } else if (gm && painter.photoPlane) {
         var gx0 = gm.cx - gm.w / 2, gy0 = gm.cy - gm.h / 2, gx1 = gm.cx + gm.w / 2, gy1 = gm.cy + gm.h / 2;
         g.opacity = Math.min(1, 0.55 * hud.ghost + 0.25) * (gm.behind ? 0.7 : 1) * labF;
         g.drawScaledBitmap(gx0, gy0, gx1, gy1, painter.photoPlane); g.opacity = labF;
         var halo = [[6, 0.12], [3.5, 0.25], [1.6, 0.95]];
         for (var hh = 0; hh < halo.length; ++hh) { g.pen = new Pen(fvNmArgb(C.GOLDL, halo[hh][1]), halo[hh][0] * k); g.brush = new Brush(0x00000000); g.drawRect(gx0, gy0, gx1, gy1); }
         var tG = fvTx("nav.m.photo") + " · " + fvNmLy(gm.dist); g.font = fB; g.pen = new Pen(fvNmArgb(C.GOLDL, 0.95));
         g.drawText(gm.cx - fB.width(tG) / 2, gy1 + 18 * k, tG);
         fvNmHitAdd(gm.cx - fB.width(tG) / 2 - 4 * k, gy1 + 18 * k - 14 * k, gm.cx + fB.width(tG) / 2 + 4 * k, gy1 + 18 * k + 5 * k);      // (E-nav) el rotulo «TU FOTO · x a.l.» de la foto minima
      }
      // la piramide: aristas finas, el marco un poco mas firme (mas fuertes con la foto pequeña en pantalla)
      var aL = FV_NAV_MODES.LINE_A * hud.ghost * (gm ? 1.6 : 1), wL = gm ? 1.7 : 1;
      for (var i = 0; i < hud.lines.length; ++i) {
         var Ls = hud.lines[i]; g.pen = new Pen(fvNmArgb(Ls[4] ? C.GOLDL : C.GOLD, Math.min(1, Ls[4] ? aL : 0.7 * aL)), (Ls[4] ? 1.6 : 1.0) * k * wL);
         g.drawLine(Ls[0], Ls[1], Ls[2], Ls[3]);
      }
      // los marcadores (la mira de la foto no, si ya se dibuja a tamaño minimo)
      // (7-nov) los rotulos no se montan: zonas ocupadas (la foto a tamaño minimo con su halo y su rotulo) y cada rotulo puesto
      var occ = []; if (gm) occ.push([gm.cx - gm.w / 2 - 8 * k, gm.cy - gm.h / 2 - 8 * k, gm.cx + gm.w / 2 + 8 * k, gm.cy + gm.h / 2 + 24 * k]);
      // (Blender 4 · defecto 6) el disco del transito sobre la estrella (fvExoOnStar, fotograma anterior) y su rotulo tapaban «DESTINO»
      // («STINO · 14 a.l.»): son zonas ocupadas y el rotulo de la mira se pone fuera de ellas
      var eo = FV_NM_B4.NOCLASH ? painter.exoOnStar : null;
      if (FV_NM_B4.NOCLASH && FV_B5B.DEST) { var zs = fvNmClearZones(painter, P, W, H, pr, ui); for (var zi = 0; zi < zs.length; ++zi) occ.push(zs[zi]); }
      else if (eo) { occ.push([eo.x - eo.r, eo.y - eo.r, eo.x + eo.r, eo.y + eo.r]); if (eo.cap) occ.push(eo.cap); }
      for (var m = 0; m < hud.markers.length; ++m) if (!(gm && hud.markers[m].kind === "photo" && hud.markers[m].on)) fvNmMarkPaint(g, hud.markers[m], k, fS, fM, fB, W, H, occ);
      painter.stats.nmLabels = occ.filter(function(b) { return !!b.lab; });     // (Blender 4) las cajas de los rotulos de las miras, para la prueba de solapes
      // la brujula (mas grande; la direccion de la foto, resaltada)
      if (hud.compass) {
         var R = 44 * k, cx = W - 90 * k, cy = 110 * k;
         g.pen = new Pen(fvNmArgb(C.INK, 0.6), 1); g.brush = new Brush(fvNmArgb(C.INK, 0.6)); g.fillCircle(cx, cy, R + 10 * k);
         g.pen = new Pen(fvNmArgb(C.GOLD, 0.9), 1.6 * k); g.brush = new Brush(0x00000000); g.drawCircle(cx, cy, R);
         g.pen = new Pen(fvNmArgb(C.GOLD, 0.3), 1 * k); g.drawLine(cx - R, cy, cx + R, cy); g.drawLine(cx, cy - R, cx, cy + R);
         var pts = [["earth", hud.compass.earth, C.EARTH, 1.6, 3.6], ["photo", hud.compass.photo, C.GOLDL, 3.0, 5.2]];
         for (var q = 0; q < pts.length; ++q) {
            var d = pts[q][1], lx = d[0], ly = d[1], n = Math.sqrt(lx * lx + ly * ly), rr = R * Math.min(1, n);
            var ex = cx + (n > 1e-9 ? lx / n : 0) * rr, ey = cy + (n > 1e-9 ? ly / n : 0) * rr;
            g.pen = new Pen(fvNmArgb(pts[q][2], 0.95), pts[q][3] * k); g.drawLine(cx, cy, ex, ey);
            if (d[2] >= 0) { g.brush = new Brush(fvNmArgb(pts[q][2], 1)); g.fillCircle(ex, ey, pts[q][4] * k); }
            else { g.brush = new Brush(0x00000000); g.pen = new Pen(fvNmArgb(pts[q][2], 0.95), 1.4 * k); g.drawCircle(ex, ey, pts[q][4] * k); }
         }
         g.font = fS; g.pen = new Pen(fvNmArgb(C.TEXT2, 0.9));
         var t1 = fvTx("nav.cEarth"), t2 = fvTx("nav.cPhoto");
         g.drawText(cx - R - 8 * k, cy + R + 26 * k, t1); g.font = fB; g.pen = new Pen(fvNmArgb(C.GOLDL, 1)); g.drawText(cx + R + 8 * k - fB.width(t2), cy + R + 26 * k, t2);
      }
      // el rotulo
      if (hud.banner !== false) {
      var tB = fvTx("nav.banner"); g.font = fB; var bw = fB.width(tB) + 36 * k, bh = 30 * k, bx = (W - bw) / 2, by = 16 * k;
      // (Blender 4 · defecto 5) la placa DATOS (arriba a la izquierda, fotograma anterior: painter.legendBox) invadia el rotulo 12 px a 1440 y
      // tapaba la «E» de ESPACIO en ventanas estrechas: el rotulo se aparta a su derecha y, si no cabe, baja por debajo de la placa
      var lrB = painter.legendBox || painter.legendRect;     // (legendBox: la placa plegada o abierta; legendRect solo la abierta)
      if (FV_NM_B4.NOCLASH && lrB && lrB[1] < by + bh && lrB[3] > by && lrB[2] + 10 * k > bx) { if (lrB[2] + 10 * k + bw <= W - 8 * k) bx = lrB[2] + 10 * k; else { by = lrB[3] + 8 * k; bx = Math.max(bx, 8 * k); } }
      painter.nmBannerRect = [bx, by, bx + bw, by + bh];
      g.pen = new Pen(fvNmArgb(C.GOLD, 0.95), 1.2 * k); g.brush = new Brush(fvNmArgb(C.INK, 0.78)); g.fillRect(bx, by, bx + bw, by + bh); g.drawRect(bx, by, bx + bw, by + bh);
      g.pen = new Pen(fvNmArgb(C.GOLDL, 1)); g.drawText(bx + 18 * k, by + bh / 2 + 5 * k, tB);
      }
   } else if (hud.note) {
      var tN = fvTx("nav.note", { b: fvNmLy(hud.note.beyondLy) }); g.font = fS; var nw = fS.width(tN) + 28 * k, nh = 24 * k, nx = (W - nw) / 2, ny = 16 * k;
      g.pen = new Pen(fvNmArgb(C.GOLD, 0.8), 1 * k); g.brush = new Brush(fvNmArgb(C.INK, 0.7)); g.fillRect(nx, ny, nx + nw, ny + nh); g.drawRect(nx, ny, nx + nw, ny + nh);
      g.pen = new Pen(fvNmArgb(C.TEXT, 0.95)); g.drawText(nx + 14 * k, ny + nh / 2 + 4 * k, tN);
   }
   // (v2) lo que se pinte despues no hereda el fundido del ancla; y sin rotulo, el HUD hereda el pincel y la pluma que le dejaria el rotulo
   // (algunas placas del HUD rellenan con el pincel en curso: sin esto salian de oro macizo con el de la brujula; sonda lab_pi_gold.js, 8-nov)
   if (labOn) { g.opacity = 1; if (hud.banner === false) { g.brush = new Brush(fvNmArgb(C.INK, 0.78)); g.pen = new Pen(fvNmArgb(C.GOLDL, 1)); } }
   return hud;
}
// (20-nov-2026, V1a, V1-10) AYUDAS DE ORIENTACION del vuelo a mano (FV_V1.AIDS; el motor da los datos: fvNmHud.aidPhoto, fvV1Reticle). Gemelo: fwNmAid en web/fw_navmodes.js
//   · la flecha dorada del marcador TU FOTO en el borde por donde queda la foto, con su distancia, cuando el rectangulo no toca la pantalla
//   · la reticula: una cruz fina en el centro con una marca hacia el «arriba» de la foto mientras se gira a > 6 °/s o se avanza a mas de la mitad del tope (se funde al parar)
function fvV1AidPaint(g, painter, P, W, H, hud, k) {
   if (typeof fvV1Reticle !== "function") return;
   var C = FV_NMP, i, rt = fvV1Reticle(P);
   if (hud.aidPhoto) {
      g.antialiasing = true; g.textAntialiasing = true; g.opacity = 1;
      var fB = cpFont("display", Math.round(12 * k), false, false, 2), fS = cpFont("text", Math.round(10 * k)), fM = cpFont("mono", Math.round(9 * k));
      for (i = 0; i < hud.markers.length; ++i) if (hud.markers[i].kind === "photo" && !hud.markers[i].on) fvNmMarkPaint(g, hud.markers[i], k, fS, fM, fB, W, H, null);
   }
   if (rt) {
      g.antialiasing = true; g.opacity = 1;
      var cx = W / 2, cy = H / 2, R = 14 * k, a = rt.a, col = fvNmArgb(C.GOLDL, 0.55 * rt.k);
      g.pen = new Pen(col, 1 * k); g.brush = new Brush(0x00000000);
      g.drawLine(cx - R, cy, cx - 0.35 * R, cy); g.drawLine(cx + 0.35 * R, cy, cx + R, cy); g.drawLine(cx, cy - R, cx, cy - 0.35 * R); g.drawLine(cx, cy + 0.35 * R, cx, cy + R);
      g.pen = new Pen(fvNmArgb(C.GOLD, 0.95 * rt.k), 1.8 * k); g.drawLine(cx + Math.cos(a) * R * 0.5, cy + Math.sin(a) * R * 0.5, cx + Math.cos(a) * R * 1.7, cy + Math.sin(a) * R * 1.7);
   }
}
function fvNmLy(d) { if (FV_B5B.FMT && typeof fvNum === "function") return fvNum(Math.round(d), 0) + " " + fvTx("nav.ly");   // (Blender 5b · R5-11) el separador de miles de su idioma
   var s = Math.round(d).toString(), o = ""; while (s.length > 3) { o = " " + s.slice(-3) + o; s = s.slice(0, -3); } return s + o + " " + fvTx("nav.ly"); }
// (F1) el icono de cada marcador: la foto = un marco; casa = el Sol (disco y rayos); el destino = un anillo con cruz
function fvNmIconPaint(g, kind, x, y, r, argb) {
   g.pen = new Pen(argb, Math.max(1, r / 4)); g.brush = new Brush(0x00000000);
   if (kind === "photo") { g.drawRect(x - r, y - 0.7 * r, x + r, y + 0.7 * r); g.fillRect(x - 0.6 * r, y - 0.35 * r, x + 0.6 * r, y + 0.35 * r, new Brush((argb & 0x00FFFFFF) | 0x80000000)); }
   else if (kind === "home") { g.brush = new Brush(argb); g.fillCircle(x, y, 0.5 * r); for (var a = 0; a < 8; ++a) { var t = a * Math.PI / 4; g.drawLine(x + 0.75 * r * Math.cos(t), y + 0.75 * r * Math.sin(t), x + 1.1 * r * Math.cos(t), y + 1.1 * r * Math.sin(t)); } }
   else { g.drawCircle(x, y, 0.8 * r); g.drawLine(x - 1.1 * r, y, x - 0.4 * r, y); g.drawLine(x + 0.4 * r, y, x + 1.1 * r, y); g.drawLine(x, y - 1.1 * r, x, y - 0.4 * r); g.drawLine(x, y + 0.4 * r, x, y + 1.1 * r); }
}
// (7-nov) donde va el rotulo de una mira en pantalla sin pisar lo ocupado: a la derecha, izquierda, abajo, arriba o, si todo choca, fuera
// de la zona que lo tapa (con una linea guia). Devuelve { x, y (linea base), lead }; añade su caja a occ
function fvNmLabelPlace(mk, w, k, W, H, occ) {
   var s = 11 * k, hA = 10 * k, hB = 3 * k, c = [[mk.x + s + 5 * k, mk.y - s + 4 * k], [mk.x - s - 5 * k - w, mk.y - s + 4 * k], [mk.x - w / 2, mk.y + s + 14 * k], [mk.x - w / 2, mk.y - s - 6 * k]], i, j;
   for (i = 0; i < occ.length; ++i) { var o = occ[i]; c.push([o[2] + 6 * k, mk.y + 4 * k], [o[0] - 6 * k - w, mk.y + 4 * k], [mk.x - w / 2, o[3] + 14 * k], [mk.x - w / 2, o[1] - 6 * k]); }
   function hit(b) { if (b[0] < 2 || b[1] < 2 || b[2] > W - 2 || b[3] > H - 2) return true; for (var q = 0; q < occ.length; ++q) { var o = occ[q]; if (b[0] < o[2] && b[2] > o[0] && b[1] < o[3] && b[3] > o[1]) return true; } return false; }
   for (j = 0; j < c.length; ++j) { var b = [c[j][0], c[j][1] - hA, c[j][0] + w, c[j][1] + hB]; if (!hit(b)) { b.lab = mk.kind; occ.push(b); return { x: c[j][0], y: c[j][1], lead: j >= 4 }; } }
   var b0 = [c[0][0], c[0][1] - hA, c[0][0] + w, c[0][1] + hB]; b0.lab = mk.kind; occ.push(b0); return { x: c[0][0], y: c[0][1], lead: false };
}
// (20-nov, O1) la tarjeta de TU FOTO: placa oscura con el marco dorado fino de la plaza de siempre, la miniatura (FV_NM_TB) con su marco y el rotulo «TU FOTO · n a.l.» debajo.
// (x, y) = su esquina superior izquierda; cd = fvNmThumbCard (motor). Apunta su caja en stats.nmThumb para las pruebas
function fvNmThumbFont(k) { return cpFont("text", Math.max(10, Math.round(11 * k))); }      // el rotulo de la tarjeta: legible a k = 1 (10 px como minimo)
function fvNmThumbPaint(g, kind, cd, x, y, k, fS, tT, col) {
   var C = FV_NMP, ix = x + cd.tx, iy = y + cd.ty;
   g.pen = new Pen(fvNmArgb(col, 0.6), 1 * k); g.brush = new Brush(fvNmArgb(C.INK, 0.72)); g.fillRect(x, y, x + cd.cw, y + cd.ch); g.drawRect(x, y, x + cd.cw, y + cd.ch);
   g.drawScaledBitmap(ix, iy, ix + cd.tw, iy + cd.th, FV_NM_TB);
   g.pen = new Pen(fvNmArgb(C.GOLDL, 0.95), 1.2 * k); g.brush = new Brush(0x00000000); g.drawRect(ix, iy, ix + cd.tw, iy + cd.th);
   g.font = fS; g.pen = new Pen(fvNmArgb(col, 0.97)); g.drawText(x + (cd.cw - fS.width(tT)) / 2, y + cd.ly, tT);
   FV_NM_ST.nmThumb = { kind: kind, x0: x, y0: y, x1: x + cd.cw, y1: y + cd.ch, tx0: ix, ty0: iy, tx1: ix + cd.tw, ty1: iy + cd.th };
}
// donde va la tarjeta de la mira sin pisar lo ocupado: a la derecha, izquierda, abajo, arriba o junto a lo que lo tapa (con linea guia); occ null = a la derecha. Devuelve { x, y (esquina), lead }
function fvNmBoxPlace(mk, w, h, k, W, H, occ) {
   var s = 11 * k, c = [[mk.x + s + 5 * k, mk.y - h / 2], [mk.x - s - 5 * k - w, mk.y - h / 2], [mk.x - w / 2, mk.y + s + 6 * k], [mk.x - w / 2, mk.y - s - 6 * k - h]], i, j;
   if (!occ) return { x: fvClamp(c[0][0], 2, W - w - 2), y: fvClamp(c[0][1], 2, H - h - 2), lead: false };
   for (i = 0; i < occ.length; ++i) { var o = occ[i]; c.push([o[2] + 6 * k, mk.y - h / 2], [o[0] - 6 * k - w, mk.y - h / 2], [mk.x - w / 2, o[3] + 6 * k], [mk.x - w / 2, o[1] - 6 * k - h]); }
   function hit(b) { if (b[0] < 2 || b[1] < 2 || b[2] > W - 2 || b[3] > H - 2) return true; for (var q = 0; q < occ.length; ++q) { var o2 = occ[q]; if (b[0] < o2[2] && b[2] > o2[0] && b[1] < o2[3] && b[3] > o2[1]) return true; } return false; }
   for (j = 0; j < c.length; ++j) { var b = [c[j][0], c[j][1], c[j][0] + w, c[j][1] + h]; if (!hit(b)) { b.lab = mk.kind; occ.push(b); return { x: c[j][0], y: c[j][1], lead: j >= 4 }; } }
   var b0 = [c[0][0], c[0][1], c[0][0] + w, c[0][1] + h]; b0.lab = mk.kind; occ.push(b0); return { x: c[0][0], y: c[0][1], lead: false };
}
function fvNmMarkPaint(g, mk, k, fS, fM, fB, W, H, occ) {
   var C = FV_NMP, col = mk.kind === "photo" ? C.GOLDL : (mk.kind === "home" ? C.EARTH : C.TEXT), lab = fvTx("nav.m." + mk.kind), dl = fvNmLy(mk.dist);
   if (mk.on) {
      var s = 11 * k; g.pen = new Pen(fvNmArgb(col, 0.95), 1.5 * k);
      g.drawLine(mk.x - s, mk.y - s, mk.x - s / 2, mk.y - s); g.drawLine(mk.x - s, mk.y - s, mk.x - s, mk.y - s / 2);
      g.drawLine(mk.x + s, mk.y + s, mk.x + s / 2, mk.y + s); g.drawLine(mk.x + s, mk.y + s, mk.x + s, mk.y + s / 2);
      var tL = lab + " · " + dl; g.font = fS;
      if (mk.kind === "photo" && FV_NM_TB) {      // (O1) la mira de la foto: su miniatura con marco y el rotulo debajo, sin pisar lo ocupado
         var fT = fvNmThumbFont(k), cdm = fvNmThumbCard(k, FV_NM_TB.height / FV_NM_TB.width, fT.width(tL), 12 * k), plm = fvNmBoxPlace(mk, cdm.cw, cdm.ch, k, W, H, occ);
         if (plm.lead) { g.pen = new Pen(fvNmArgb(col, 0.55), 1 * k); g.drawLine(mk.x, mk.y, plm.x + (plm.x < mk.x ? cdm.cw : 0), plm.y + cdm.ch / 2); }
         fvNmThumbPaint(g, "mira", cdm, plm.x, plm.y, k, fT, tL, col);
         fvNmHitAdd(plm.x, plm.y, plm.x + cdm.cw, plm.y + cdm.ch); fvNmHitAdd(mk.x - s, mk.y - s, mk.x + s, mk.y + s);
         return;
      }
      var pl = occ ? fvNmLabelPlace(mk, fS.width(tL), k, W, H, occ) : { x: mk.x + s + 5 * k, y: mk.y - s + 4 * k, lead: false };
      if (pl.lead) { g.pen = new Pen(fvNmArgb(col, 0.55), 1 * k); g.drawLine(mk.x, mk.y, pl.x + (pl.x < mk.x ? fS.width(tL) : 0), pl.y - 4 * k); }
      g.pen = new Pen(fvNmArgb(col, 0.95)); g.drawText(pl.x, pl.y, tL);
      if (mk.kind === "photo") { fvNmHitAdd(pl.x - 3 * k, pl.y - 13 * k, pl.x + fS.width(tL) + 3 * k, pl.y + 5 * k); fvNmHitAdd(mk.x - s, mk.y - s, mk.x + s, mk.y + s); }   // (E-nav) el rotulo y la mira
      return;
   }
   // fuera: flecha grande en el borde + placa con icono, rotulo y distancia (se lee de un vistazo)
   var a = mk.ang, c = Math.cos(a), sn = Math.sin(a), L = 22 * k, Wd = 13 * k;
   var tip = new Point(mk.x + c * L, mk.y + sn * L), b1 = new Point(mk.x - sn * Wd, mk.y + c * Wd), b2 = new Point(mk.x + sn * Wd, mk.y - c * Wd);
   g.pen = new Pen(fvNmArgb(C.INK, 0.9), 1.2 * k); g.brush = new Brush(fvNmArgb(col, 0.97)); g.drawPolygon([tip, b1, b2]);
   if (mk.kind === "photo" && FV_NM_TB) {      // (O1) el borde: la flecha y, hacia dentro, la tarjeta con la miniatura de la foto (en vez de la placa con icono y texto)
      var fT = fvNmThumbFont(k), tT = lab + " · " + dl, cd = fvNmThumbCard(k, FV_NM_TB.height / FV_NM_TB.width, fT.width(tT), 12 * k);
      var off = 6 * k + Math.abs(c) * cd.cw / 2 + Math.abs(sn) * cd.ch / 2, cx0 = fvClamp(mk.x - c * off - cd.cw / 2, 4, W - cd.cw - 4), cy0 = fvClamp(mk.y - sn * off - cd.ch / 2, 4, H - cd.ch - 4);
      fvNmThumbPaint(g, "edge", cd, cx0, cy0, k, fT, tT, col);
      fvNmHitAdd(Math.min(cx0, tip.x, b1.x, b2.x) - 3 * k, Math.min(cy0, tip.y, b1.y, b2.y) - 3 * k, Math.max(cx0 + cd.cw, tip.x, b1.x, b2.x) + 3 * k, Math.max(cy0 + cd.ch, tip.y, b1.y, b2.y) + 3 * k);
      return;
   }
   var pw = Math.max(fB.width(lab), fM.width(dl)) + 34 * k, ph = 34 * k, bx = mk.x - c * 52 * k, by = mk.y - sn * 52 * k;
   var px = fvClamp(bx - pw / 2, 4, W - pw - 4), py = fvClamp(by - ph / 2, 4, H - ph - 4);
   g.pen = new Pen(fvNmArgb(col, 0.6), 1 * k); g.brush = new Brush(fvNmArgb(C.INK, 0.62)); g.fillRect(px, py, px + pw, py + ph); g.drawRect(px, py, px + pw, py + ph);
   if (mk.kind === "photo") {      // (E-nav) la placa y la flecha del borde: una sola zona que las cubre a las dos
      fvNmHitAdd(Math.min(px, tip.x, b1.x, b2.x) - 3 * k, Math.min(py, tip.y, b1.y, b2.y) - 3 * k, Math.max(px + pw, tip.x, b1.x, b2.x) + 3 * k, Math.max(py + ph, tip.y, b1.y, b2.y) + 3 * k);
   }
   fvNmIconPaint(g, mk.kind, px + 13 * k, py + ph / 2, 6 * k, fvNmArgb(col, 0.95));
   g.font = fB; g.pen = new Pen(fvNmArgb(col, 0.97)); g.drawText(px + 25 * k, py + 15 * k, lab);
   g.font = fM; g.pen = new Pen(fvNmArgb(C.TEXT2, 0.92)); g.drawText(px + 25 * k, py + 28 * k, dl);
}

// (7-nov) EL SALTO A CASA: el fundido dorado (color de placa, nunca negro) con un destello mas claro en el centro alrededor del salto
function fvNmJumpPaint(g, painter, P, W, H) {
   if (typeof fvNmJumpFade !== "function") return 0;
   var f = fvNmJumpFade(P); painter.stats.jumpFade = f.a;
   if (f.a < 0.003) return 0;
   var C = FV_NMP, cx = W / 2, cy = H / 2, R = 0.75 * Math.sqrt(W * W + H * H), c0 = new Point(cx, cy);
   var mid = 0x8A6A35, edge = 0x5A4422, core = f.flash > 0 ? C.GOLDL : C.GOLD;
   g.opacity = 1; g.pen = new Pen(0x00000000, 0);
   g.fillRect(0, 0, W, H, new Brush(fvNmArgb(edge, f.a)));
   g.fillRect(0, 0, W, H, new RadialGradientBrush(c0, R, c0, [[0, fvNmArgb(core, f.a * (0.85 + 0.15 * f.flash))], [0.45, fvNmArgb(mid, f.a * 0.9)], [1, fvNmArgb(edge, 0)]]));
   return f.a;
}
