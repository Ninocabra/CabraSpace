// ============================================================================
// FieldVoyager/src/ui/fv_aenigma_ui.js — (I1, 19-nov-2026) AENIGMATA y la cadena de «¿por que?» EN LA CABINA DE PIXINSIGHT
// ----------------------------------------------------------------------------
// El calculo y los textos son de src/engine/fv_aenigma.js (puro; el visor web usa el mismo fichero). Aqui, solo lo que pinta y lo que se pulsa:
//   · el REVERSO de la placa MIRABILIA: un clic en su titulo (id «listFlip») gira la placa; las filas son los sobres (lacrado / abierto), con los
//     mismos gestos que las de MIRABILIA (clic = elegir · flecha o doble clic = ir). Sin misterios en la foto, el titulo no se puede girar ni lleva marca.
//   · la FICHA: la prueba del misterio y la respuesta del eslabon, en oro, delante del resumen; sus numeros, en MÁS; y al pie del resumen, UNA
//     pregunta dorada que se pulsa (id «card-link») y lleva la nave al objeto que la contesta.
//   · con la ficha de una de las dos estrellas de la pareja abierta, un rombo de oro marca a la otra y un hilo las une (la prueba, a la vista).
// Los ganchos en el resto del codigo son de una linea cada uno: fv_hud.js (fvCardPaint), fv_nav.js (fvNavListPaint, fvNavListHit, fvNavIcon),
// fv_dialog.js (navState, click, stripClick) y fv_cockpit.js (isAction). FV_E1C.ON = false: ninguno hace nada.
// ES5.
// ============================================================================

// las ayudas (texto largo -> tooltip, §11.7); se añaden a FV_TX como hacen fv_nav.js y fv_search.js
(function() {
   if (typeof FV_TX === "undefined") return;
   FV_TX.en["tipck.listFlip"] = "Turn the plate. One side is MIRABILIA (the most singular things in your photo); the other is AENIGMATA: up to three riddles of this photo, each one true and computed from the Gaia measurements of your stars. Go to the object (find it yourself, or press the arrow of its row) and its card shows the proof.";
   FV_TX.es["tipck.listFlip"] = "Gira la placa. Una cara es MIRABILIA (lo más singular de tu foto); la otra es AENIGMATA: hasta tres enigmas de esta foto, todos ciertos y calculados con las medidas de Gaia de tus estrellas. Ve al objeto (búscalo tú o pulsa la flecha de su fila) y su ficha enseña la prueba.";
})();

// la ficha: lo que añade el motor. C = el contenido de la ficha (fvCardContent / fvObjectCardContent), recien hecho
function fvE1cUiInto(C, scene, sel, L) {
   if (!C || typeof fvE1cCard !== "function" || !fvE1cOn()) return C;
   var R; try { R = fvE1cCard(scene, sel, L); } catch (e) { if (typeof fvLog === "function") fvLog("e1c: card failed: " + e); return C; }
   C.e1c = R; C.e1cGold = []; C.e1cLink = R.link || null;
   if (R.proof) { C.l1.unshift(R.proof); C.e1cGold.push(R.proof); }
   if (R.ans) { C.l1.unshift(R.ans); C.e1cGold.push(R.ans); }
   if (R.ans2) C.l2.unshift(R.ans2);
   if (R.proof2) C.l2.unshift(R.proof2);
   return C;
}
// el color de las frases de la cadena en la ficha (oro claro sobre la ficha oscura; laton oscuro sobre la de esmalte)
function fvE1cUiGold() { return (typeof fvCardDark === "function" && fvCardDark()) ? 0xffF3D27E : 0xff5E4214; }
function fvE1cUiIsGold(C, s) { return !!(C && C.e1cGold && C.e1cGold.indexOf(s) >= 0); }

// seguir el eslabon de la ficha a la vista: elegir el destino y viajar (la ficha se reabre al llegar, con la respuesta delante)
function fvE1cUiFollow(D) {
   var C = D.painter ? D.painter.cardC : null, lk = C ? C.e1cLink : null;
   if (!lk || !D.P || !D.scene) return false;
   var to = fvE1cFollow(D.scene, lk);
   if (!to) return false;
   if (typeof fvLog === "function") fvLog("e1c: link " + lk.key + " followed");
   if (typeof fvE1aPost === "function") fvE1aPost(D.e1a, "chain");      // (I5) el sonido que informa: un eslabon de la cadena
   D.tour = null;
   var sel = (to.kind === "nebula") ? { kind: "nebula", sx: D.VW / 2, sy: D.VH / 2 } : { kind: to.kind, i: to.i };
   D.select(sel);
   var ok = false; try { ok = D.travel(D.P.sel); } catch (e) { ok = false; }
   if (!ok && typeof D.openCard === "function") D.openCard();      // ya se esta alli (o no se puede viajar): la ficha, sin vuelo
   return true;
}

// la placa: que cara se enseña. Se llama en cada pintada de la franja (navState): barato (las filas se rehacen solo si cambia el idioma o la sesion)
function fvE1cUiSync(D) {
   var st = D.nav ? D.nav.list : null; if (!st) return;
   if (FV_E1C_ST && FV_E1C_ST.scene === D.scene && FV_E1C_ST.resolved) { FV_E1C_ST.resolved = false; if (typeof fvE1aPost === "function") fvE1aPost(D.e1a, "resolve"); }      // (I5) el sonido que informa: un AENIGMA resuelto
   var on = typeof fvE1cOn === "function" && fvE1cOn() && FV_E1C.AENIG && !!D.scene && !!st.ready;
   if (!on) { if (st.items && st.items._aen) { st.items = st.base || []; st.top = 0; } st.flip = false; st.face = 0; st.aen = null; return; }
   var key = FV_LANG + ":" + fvE1cVer(D.scene);
   if (!st.aen || st.aenKey !== key) { var was = !!(st.items && st.items._aen); st.aen = fvE1cItems(D.scene, FV_LANG); st.aen._aen = true; st.aenKey = key; if (was) st.items = st.aen; }
   st.flip = st.aen.length > 0;
   var searching = !!(st.search && st.search.text.length > 0);
   if (st.face === 1 && st.flip && !searching) { if (st.items !== st.aen) { st.items = st.aen; st.top = 0; } }
   else if (st.items && st.items._aen) { st.items = st.base || []; st.top = 0; }
   if (!st.flip) st.face = 0;
}
function fvE1cUiFlip(D) {
   var st = D.nav ? D.nav.list : null; if (!st || !st.flip) return false;
   if (st.search && st.search.text.length && typeof D.searchClear === "function") D.searchClear(true);      // la placa girada no enseña resultados de busqueda
   st.face = (st.face === 1) ? 0 : 1;
   fvE1cUiSync(D);
   if (typeof fvLog === "function") fvLog("e1c: plate turned to " + (st.face === 1 ? "AENIGMATA" : "MIRABILIA"));
   return true;
}
// la cara que se ve (para el titulo de la placa)
function fvE1cUiFace(st) { return !!(st && st.items && st.items._aen); }
// el titulo de la placa y su marca de giro (dos medias flechas grabadas); deja en st.flipX1 hasta donde llega lo que se pulsa. -> el titulo pintado
function fvE1cUiHeader(g, st, x, y, kc, f) {
   var back = fvE1cUiFace(st), ttl = back ? "AENIGMATA" : "MIRABILIA", hov = (st.hover === "listFlip");
   g.font = f; g.pen = new Pen(hov ? 0xffFFE9A8 : FV_CK.gold); g.drawText(x, y, ttl);
   st.flipX1 = 0;
   if (!st.flip) return ttl;
   var w = f.width(ttl), gx = x + w + 5 * kc, gy = y - 2.6 * kc, a = 3.2 * kc, c = hov ? 0xffFFE9A8 : FV_CK.brass2;
   g.antialiasing = true; g.pen = new Pen(c, Math.max(0.9, 1.1 * kc));
   g.drawLine(gx - a, gy - 1.3 * kc, gx + a, gy - 1.3 * kc); g.drawLine(gx + a, gy - 1.3 * kc, gx + a - 1.8 * kc, gy - 3 * kc);        // →
   g.drawLine(gx - a, gy + 1.3 * kc, gx + a, gy + 1.3 * kc); g.drawLine(gx - a, gy + 1.3 * kc, gx - a + 1.8 * kc, gy + 3 * kc);        // ←
   st.flipX1 = gx + a + 4 * kc;
   return ttl;
}
// los iconos de los sobres: lacrado (el sobre cerrado con su lacre) y abierto (la solapa levantada, sin lacre). -> true si lo ha pintado
function fvE1cUiIcon(g, type, cx, cy, r, c) {
   if (type !== "seal" && type !== "sealOpen") return false;
   var w = r * 0.95, h = r * 0.66;
   g.antialiasing = true; g.pen = new Pen(c, Math.max(0.8, r * 0.16));
   g.drawRect(cx - w, cy - h, cx + w, cy + h);
   if (type === "seal") { g.drawLine(cx - w, cy - h, cx, cy + 0.1 * h); g.drawLine(cx, cy + 0.1 * h, cx + w, cy - h); g.fillCircle(cx, cy + 0.1 * h, r * 0.26, new Brush(c)); }
   else { g.drawLine(cx - w, cy - h, cx, cy - h - 0.9 * h); g.drawLine(cx, cy - h - 0.9 * h, cx + w, cy - h); }
   return true;
}
// la prueba de la pareja a la vista: con la ficha de una abierta, un rombo en la otra y un hilo entre las dos (pr = proyector del HUD)
function fvE1cUiMark(g, painter, pr, scene, sel, sx, sy) {
   if (typeof fvE1cOf !== "function" || !fvE1cOn() || !FV_E1C.AENIG) return;
   var my = fvE1cOf(scene, sel); if (!my || my.k !== "pair") return;
   var c = fvE1cCanon(scene, sel), other = (my.sel.i === c.i) ? my.also : my.sel.i, p = pr.project(fvStarPos(scene, other));
   if (!p) return;
   var r = 7, col = 0xd0F3D27E;
   g.antialiasing = true; g.pen = new Pen(col, 1);
   g.drawLine(p[0], p[1] - r, p[0] + r, p[1]); g.drawLine(p[0] + r, p[1], p[0], p[1] + r); g.drawLine(p[0], p[1] + r, p[0] - r, p[1]); g.drawLine(p[0] - r, p[1], p[0], p[1] - r);
   var dx = p[0] - sx, dy = p[1] - sy, l = Math.sqrt(dx * dx + dy * dy);
   if (l > 3 * r) { g.pen = new Pen(0x80F3D27E, 0.8); g.drawLine(sx + dx / l * 2 * r, sy + dy / l * 2 * r, p[0] - dx / l * 1.4 * r, p[1] - dy / l * 1.4 * r); }
}
