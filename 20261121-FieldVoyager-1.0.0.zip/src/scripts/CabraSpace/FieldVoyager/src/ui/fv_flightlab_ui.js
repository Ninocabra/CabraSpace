// ============================================================================
// FieldVoyager/src/ui/fv_flightlab_ui.js — el PANEL del laboratorio de vuelo en PixInsight (8-nov-2026)
// ----------------------------------------------------------------------------
// Solo existe con el laboratorio encendido (tecla L): apagado no se pinta nada (los fotogramas son los de antes, bit a bit).
// Abajo a la izquierda de la vista, PLEGADO por defecto: una placa «FLIGHT LAB» con lo que esta puesto (S, telescopio). Un clic la
// despliega con los conmutadores para comparar en caliente: laboratorio (apagar), espacio S, telescopio, ancla y llegada D7. Los textos
// largos van en el tooltip (EN + ES). Teclas: L laboratorio · V espacio S · O telescopio · Q/Z alabeo. Nada de procesos aqui: solo dibuja.
// (v4, 9-nov) fila «Vuelo v4» (la v4 detras del laboratorio; apagada = la v3) y, con la v4, las flechas miran 360°; sin la fila D7 (no aplica)
// Estetica Atlas (oro sobre tinta, la de fv_navmodes.js). ES5.
// ============================================================================
var FV_LABUI = { open: false };
(function() {
   var add = {
      en: { "lab.title": "NAVIGATIO", "lab.on": "Navigation v5 · L for the classic one", "lab.s": "Space S", "lab.sReal": "real (×1)", "lab.tele": "Telescope · O",
            "lab.anchor": "Anchor", "lab.d7": "Arrival D7", "lab.keys": "Q/Z roll · left drag orbit/look · right drag pan", "lab.off": "off", "lab.onW": "on",
            "lab.toast.on": "Navigation v5 (L for the classic one)", "lab.toast.off": "Classic navigation (L to come back)",
            "tiplab.tab": "NAVIGATIO — how the ship flies: fixed 50° lens and your photo's space stretched sideways so that you can turn inside it. Click to open the switches. L changes to the classic navigation (a telescope lens) and back.",
            "tiplab.on": "Change to the classic navigation (L): the one before v5, exactly as it was. L again comes back.",
            "tiplab.s": "Lateral stretch of the space (V): real, ~15° or ~40° of photo at home. From home the view is the same; flying, sideways gets wider and you can turn. Distances read are always real.",
            "tiplab.tele": "Telescope (O): fixed 50° lens outside home; the telescope zooms in (mouse wheel changes the power) up to the resolution limit of your photo.",
            "tiplab.anchor": "Anchor: when there is nothing to see (no nebula, few stars) or you are outside your photo, the golden box of the photo and markers for target, photo and home.",
            "tiplab.d7": "Arrival D7: arrive with your nebula behind the target, going round it in an arc while looking at it (never flying backwards). Off: arrive from where you come.",
            "lab.content": "Look at content · K", "lab.heading": "heading", "lab.dest": "target",
            "lab.toast.cOn": "Look at content on (K): the nose points at what can be seen, even flying backwards", "lab.toast.cOff": "Look at content off (K): the nose points at the target",
            "tiplab.content": "Look at content (K): on trips the nose points at the centre of what can be seen (your nebula, by its light, and the stars that are painted), even if you fly backwards; inside the nebula and on arrival it looks at the target. The small golden chevron on the edge is your heading.",
            "lab.v4": "Flight v4", "lab.keys4": "arrows / pad look 360° · W/S thrust · Q/Z roll · left drag orbit · right drag pan",
            "lab.toast.v4On": "Flight v4 on: almost straight trips with the target always on screen; arrows look all around", "lab.toast.v4Off": "Flight v4 off: back to v3",
            "tiplab.v4": "Flight v4: trips almost straight with a gentle curve, the target always inside the central frame, arriving still and level. The pad and the arrow keys turn the view all the way round (360°) without moving; W/S thrust. Look at content (K) only tilts the framing. Off: v3.",
            "lab.v5": "Flight v5", "lab.toast.v5On": "Flight v5 on: arrival with your nebula behind the star, faster where there is nothing to see", "lab.toast.v5Off": "Flight v5 off: back to v4",
            "tiplab.v5": "Flight v5 (on top of v4): if there is nothing of your photo behind the star when you arrive, the ship turns round it without moving away (the turn starts while it is still arriving) until the nebula is behind it, and stops level. Where nothing can be seen, the trip goes faster. While it turns towards a target behind you, it already starts moving." },
      es: { "lab.title": "NAVIGATIO", "lab.on": "Navegación v5 · L para la clásica", "lab.s": "Espacio S", "lab.sReal": "real (×1)", "lab.tele": "Telescopio · O",
            "lab.anchor": "Ancla", "lab.d7": "Llegada D7", "lab.keys": "Q/Z alabeo · arrastre izq. orbitar/mirar · der. desplazar", "lab.off": "no", "lab.onW": "sí",
            "lab.toast.on": "Navegación v5 (L para la clásica)", "lab.toast.off": "Navegación clásica (L para volver)",
            "tiplab.tab": "NAVIGATIO — cómo vuela la nave: lente fija de 50° y el espacio de tu foto estirado de lado para poder girar dentro. Clic para abrir los conmutadores. L cambia a la navegación clásica (una lente de telescopio) y vuelve.",
            "tiplab.on": "Cambiar a la navegación clásica (L): la de antes de la v5, tal cual. Otra L vuelve.",
            "tiplab.s": "Estirar el espacio de lado (V): real, ~15° o ~40° de foto en casa. Desde casa se ve igual; al volar, lo lateral se ensancha y se puede girar. Las distancias que lees son siempre las reales.",
            "tiplab.tele": "Telescopio (O): lente fija de 50° fuera de casa; el telescopio acerca (la rueda cambia el aumento) hasta el límite de detalle de tu foto.",
            "tiplab.anchor": "Ancla: cuando no hay nada que ver (sin nebulosa, pocas estrellas) o estás fuera de tu foto, la caja dorada de la foto y marcadores de destino, foto y casa.",
            "tiplab.d7": "Llegada D7: llegar con tu nebulosa detrás del destino, rodeándolo en arco mientras lo miras (nunca de espaldas). Apagada: llegar desde donde vienes.",
            "lab.content": "Mirada al contenido · K", "lab.heading": "rumbo", "lab.dest": "destino",
            "lab.toast.cOn": "Mirada al contenido encendida (K): el morro apunta a lo que se ve, aunque se vuele de espaldas", "lab.toast.cOff": "Mirada al contenido apagada (K): el morro apunta al destino",
            "tiplab.content": "Mirada al contenido (K): en los viajes el morro apunta al centro de lo que se ve (tu nebulosa, por su luz, y las estrellas que se pintan), aunque se vuele de espaldas; dentro de la nebulosa y al llegar mira al destino. El pequeño chevrón dorado del borde es tu rumbo.",
            "lab.v4": "Vuelo v4", "lab.keys4": "flechas / cruceta miran 360° · W/S empujan · Q/Z alabeo · arrastre izq. orbitar · der. desplazar",
            "lab.toast.v4On": "Vuelo v4 encendido: viajes casi rectos con el destino siempre en pantalla; las flechas miran alrededor", "lab.toast.v4Off": "Vuelo v4 apagado: vuelve la v3",
            "tiplab.v4": "Vuelo v4: viajes casi rectos con una curva suave, el destino siempre dentro del recuadro central y llegada quieta y derecha. La cruceta y las flechas del teclado giran la mirada la vuelta entera (360°) sin avanzar; W/S empujan. La mirada al contenido (K) solo inclina el encuadre. Apagado: la v3.",
            "lab.v5": "Vuelo v5", "lab.toast.v5On": "Vuelo v5 encendido: llegada con tu nebulosa detrás de la estrella, más deprisa donde no hay nada que ver", "lab.toast.v5Off": "Vuelo v5 apagado: vuelve la v4",
            "tiplab.v5": "Vuelo v5 (encima de la v4): si al llegar no hay nada de tu foto detrás de la estrella, la nave le da la vuelta sin alejarse (empieza a girar cuando aún está llegando) hasta dejar la nebulosa detrás, y se para derecha. Donde no se ve nada, el viaje va más deprisa. Mientras gira hacia un destino que queda detrás, ya empieza a avanzar." }
   };
   if (typeof FV_TX !== "undefined") for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
function fvLabUiTx(k) { return (typeof fvTx === "function") ? fvTx(k) : k; }
function fvLabUiTip(id) { var k = "tiplab." + String(id).replace(/^lab-/, ""); return (typeof fvTipBoth === "function") ? fvTipBoth(k) : k; }

// la placa y, abierta, los conmutadores. Apunta lo pulsable en painter.hits (ids «lab-…»)
function fvLabUiPaint(g, painter, pr, P, W, H) {
   if (!P || !P.lab || typeof FV_LAB === "undefined" || FV_LAB.ON !== true) return;
   // (v2) letra legible: nunca por debajo de la del resto del HUD (14/12/11 px; fv_hud.js), aunque la vista sea mas estrecha que la de referencia
   var C = FV_NMP, k = Math.max(1, (typeof fvHudK === "function") ? fvHudK(W) : 1), L = P.lab;
   var fB = cpFont("display", Math.round(14 * k), false, false, 2), fS = cpFont("text", Math.round(12 * k)), fM = cpFont("mono", Math.round(11 * k));
   g.antialiasing = true; g.textAntialiasing = true; g.opacity = 1; g.compositionOperator = CompositionOp_SourceOver;
   var sDeg = FV_LAB.S_DEG[FV_LAB.S_MODE] || 0, sTxt = sDeg > 0 ? (Math.round(sDeg) + "° · ×" + Math.round(L.S0 || L.S)) : fvLabUiTx("lab.sReal"), v4 = (typeof fvLab4On === "function") && fvLab4On(), v5 = (typeof fvLab5On === "function") && fvLab5On();   // (v4) S de la tecla
   var tTxt = L.teleOn ? ("×" + (Math.round(L.tele * 10) / 10)) : fvLabUiTx("lab.off");
   var head = fvLabUiTx("lab.title") + "  ·  S " + sTxt + (L.teleOn ? "  ·  TELE " + tTxt : "");
   var keysTx = fvLabUiTx(v4 ? "lab.keys4" : "lab.keys");
   var x0 = 16 * k, pad = 9 * k, rh = 26 * k, w = Math.max(fB.width(head) + 34 * k, FV_LABUI.open ? Math.max(380 * k, fM.width(keysTx) + 24 * k) : 0);
   var rows = FV_LABUI.open ? [["lab-on", fvLabUiTx("lab.on"), true],
                               ["lab-v4", fvLabUiTx("lab.v4") + ": " + fvLabUiTx(v4 ? "lab.onW" : "lab.off"), v4],
                               ["lab-v5", fvLabUiTx("lab.v5") + ": " + fvLabUiTx(v5 ? "lab.onW" : "lab.off"), v5],
                               ["lab-s", fvLabUiTx("lab.s") + ": " + sTxt + "  (V)", sDeg > 0],
                               ["lab-tele", fvLabUiTx("lab.tele") + ": " + tTxt, L.teleOn],
                               ["lab-anchor", fvLabUiTx("lab.anchor") + ": " + fvLabUiTx(FV_LAB.ANCHOR ? "lab.onW" : "lab.off"), FV_LAB.ANCHOR],
                               ["lab-d7", fvLabUiTx("lab.d7") + ": " + fvLabUiTx(FV_LAB.D7 ? "lab.onW" : "lab.off"), FV_LAB.D7],
                               ["lab-content", fvLabUiTx("lab.content") + ": " + fvLabUiTx(fvLabContentOn() ? "lab.onW" : "lab.off"), fvLabContentOn()]] : [];
   if (v4) rows = rows.filter(function(r) { return r[0] !== "lab-d7"; });   // (v4) la llegada D7 no existe en la v4 (se llega por donde se viene): sin conmutador muerto
   if (!v4) rows = rows.filter(function(r) { return r[0] !== "lab-v5"; });   // (v5) va encima de la v4: sin la v4 no hay conmutador
   var h = 32 * k + rows.length * rh + (rows.length ? 30 * k : 0), y1 = H - 16 * k, y0 = y1 - h;
   g.pen = new Pen(fvNmArgb(C.GOLD, 0.95), 1.2 * k); g.brush = new Brush(fvNmArgb(C.INK, 0.80));
   g.fillRect(x0, y0, x0 + w, y1); g.drawRect(x0, y0, x0 + w, y1);
   // cabecera: un triangulo (plegado ▸ / abierto ▾) y el estado
   var cx = x0 + 12 * k, cy = y0 + 16 * k; g.brush = new Brush(fvNmArgb(C.GOLDL, 1)); g.pen = new Pen(fvNmArgb(C.GOLDL, 1), 1);
   if (FV_LABUI.open) g.drawPolygon([new Point(cx - 4 * k, cy - 2.5 * k), new Point(cx + 4 * k, cy - 2.5 * k), new Point(cx, cy + 3.5 * k)]);
   else g.drawPolygon([new Point(cx - 2.5 * k, cy - 4 * k), new Point(cx - 2.5 * k, cy + 4 * k), new Point(cx + 3.5 * k, cy)]);
   g.font = fB; g.pen = new Pen(fvNmArgb(C.GOLDL, 1)); g.drawText(x0 + 24 * k, y0 + 21 * k, head);
   painter.hits.push({ id: "lab-tab", x0: x0, y0: y0, x1: x0 + w, y1: y0 + 32 * k });
   for (var i = 0; i < rows.length; ++i) {
      var ry = y0 + 32 * k + i * rh, on = rows[i][2];
      g.pen = new Pen(fvNmArgb(C.GOLD, 0.9), 1.2 * k); g.brush = new Brush(on ? fvNmArgb(C.GOLD, 0.95) : 0x00000000);
      g.drawCircle(x0 + pad + 4 * k, ry + rh / 2, 4 * k); if (on) g.fillCircle(x0 + pad + 4 * k, ry + rh / 2, 2.6 * k);
      g.font = fS; g.pen = new Pen(fvNmArgb(C.TEXT, 0.95)); g.drawText(x0 + pad + 16 * k, ry + rh / 2 + 5 * k, rows[i][1]);
      painter.hits.push({ id: rows[i][0], x0: x0, y0: ry, x1: x0 + w, y1: ry + rh });
   }
   if (rows.length) { g.font = fM; g.pen = new Pen(fvNmArgb(C.TEXT2, 0.9)); g.drawText(x0 + pad, y1 - 11 * k, keysTx); }
   painter.stats.labPanel = { open: FV_LABUI.open, rect: [x0, y0, x0 + w, y1] };
   fvLabUiMarks(g, painter, pr, P, W, H, k, fM);
}
// (v3) dos marcas discretas: el RUMBO (hacia donde se mueve la nave; con la mirada al contenido se puede ir de espaldas), un circulito con alas si
// cae dentro de la vista o un chevron doble en el borde si no; y el DESTINO, una mira fina con su distancia alrededor de la estrella elegida
function fvLabUiMarks(g, painter, pr, P, W, H, k, fM) {
   var C = FV_NMP, c = P.cam, B = c.B, L = P.lab; if (!B) return;
   var st = painter.stats.labMarks = { heading: null, dest: null };
   var fx = (W / 2) / Math.tan(c.fov / 2), cx = W / 2, cy = H / 2, m = 22 * k;
   var proj = function(dF) { var z = fvDot(dF, B.f), x = fvDot(dF, B.r), y = fvDot(dF, B.d); return { z: z, x: x, y: y, sx: cx + fx * x / Math.max(1e-9, z), sy: cy + fx * y / Math.max(1e-9, z) }; };
   var vF = fvLabRelFly(P.vel || [0, 0, 0], L.S), vn = fvLen(vF);
   if (vn > 1e-6 && P.flight) {
      var q = proj(fvMul(vF, 1 / vn)), inV = q.z > 0.05 && q.sx > m && q.sx < W - m && q.sy > m && q.sy < H - m;
      g.pen = new Pen(fvNmArgb(C.GOLDL, 0.85), 1.4 * k); g.brush = new Brush(0x00000000);
      if (inV) {
         var r = 6 * k; g.drawCircle(q.sx, q.sy, r); g.drawLine(q.sx - 2.6 * r, q.sy, q.sx - r, q.sy); g.drawLine(q.sx + r, q.sy, q.sx + 2.6 * r, q.sy); g.drawLine(q.sx, q.sy - r, q.sx, q.sy - 1.8 * r);
         st.heading = { x: q.sx, y: q.sy, edge: false };
      } else {
         var ax = q.x, ay = q.y, an = Math.sqrt(ax * ax + ay * ay); if (an < 1e-9) { ax = 0; ay = 1; an = 1; }
         ax /= an; ay /= an;
         var tx = (ax > 0 ? (W - m - cx) : (m - cx)) / (Math.abs(ax) > 1e-9 ? ax : 1e-9), ty = (ay > 0 ? (H - m - cy) : (m - cy)) / (Math.abs(ay) > 1e-9 ? ay : 1e-9), t = Math.min(Math.abs(tx), Math.abs(ty));
         var ex = cx + ax * t, ey = cy + ay * t, s = 9 * k, px = -ay, py = ax;
         g.drawLine(ex - ax * s + px * s, ey - ay * s + py * s, ex, ey); g.drawLine(ex - ax * s - px * s, ey - ay * s - py * s, ex, ey);
         g.drawLine(ex - ax * 2 * s + px * s, ey - ay * 2 * s + py * s, ex - ax * s, ey - ay * s); g.drawLine(ex - ax * 2 * s - px * s, ey - ay * 2 * s - py * s, ex - ax * s, ey - ay * s);
         g.font = fM; g.pen = new Pen(fvNmArgb(C.TEXT2, 0.8)); var tH = fvLabUiTx("lab.heading"), tw = fM.width(tH);
         g.drawText(fvClamp(ex - ax * 3.2 * s - tw / 2, 4 * k, W - tw - 4 * k), fvClamp(ey - ay * 3.2 * s + 4 * k, 14 * k, H - 4 * k), tH);
         st.heading = { x: ex, y: ey, edge: true, back: q.z < 0 };
      }
   }
   var fl = P.flight, sel = fl && fl.sel;
   if (fl && fl.T && sel && fl.kind !== "home" && fl.kind !== "path") {
      var dT = fvLabRelFly(fvSub(fl.T, c.pos), L.S), dn = fvLen(dT);
      if (dn > 1e-9) {
         var qd = proj(fvMul(dT, 1 / dn));
         if (qd.z > 0.05 && qd.sx > 0 && qd.sx < W && qd.sy > 0 && qd.sy < H) {
            var R = 14 * k, gp = 5 * k; g.pen = new Pen(fvNmArgb(C.GOLD, 0.75), 1.1 * k); g.brush = new Brush(0x00000000);
            g.drawCircle(qd.sx, qd.sy, R);
            g.drawLine(qd.sx - R - gp, qd.sy, qd.sx - R + gp, qd.sy); g.drawLine(qd.sx + R - gp, qd.sy, qd.sx + R + gp, qd.sy);
            g.drawLine(qd.sx, qd.sy - R - gp, qd.sx, qd.sy - R + gp); g.drawLine(qd.sx, qd.sy + R - gp, qd.sx, qd.sy + R + gp);
            g.font = fM; g.pen = new Pen(fvNmArgb(C.TEXT2, 0.8)); var tD = fvLabUiTx("lab.dest") + " · " + fvNmLy(fvLen(fvSub(fl.T, c.pos)));
            g.drawText(qd.sx + R + 8 * k, qd.sy + 4 * k, tD);
            st.dest = { x: qd.sx, y: qd.sy };
         }
      }
   }
}
// un clic en el panel -> true si era suyo
function fvLabUiClick(D, id) {
   if (String(id).indexOf("lab-") !== 0) return false;
   var P = D.P;
   if (id === "lab-tab") FV_LABUI.open = !FV_LABUI.open;
   else if (id === "lab-on") fvLabUiToggle(D, false);
   else if (id === "lab-s") fvLabSetS(P, FV_LAB.S_MODE + 1);
   else if (id === "lab-tele") fvLabTele(P);
   else if (id === "lab-anchor") FV_LAB.ANCHOR = !FV_LAB.ANCHOR;
   else if (id === "lab-d7") FV_LAB.D7 = !FV_LAB.D7;
   else if (id === "lab-content") fvLabUiContent(D);
   else if (id === "lab-v4") fvLabUiV4(D);
   else if (id === "lab-v5") fvLabUiV5(D);
   return true;
}
// encender / apagar desde el dialogo (tecla L o el panel)
function fvLabUiToggle(D, on) {
   var P = D.P; if (!P) return false;
   if (on === undefined) on = !(FV_LAB.ON === true);
   if (D.releaseKeys) { try { D.releaseKeys("lab"); } catch (e) {} }
   D.tour = null; D.lookTo = null;
   fvLabSetOn(P, on);
   if (D.ui) D.ui.caption = { text: fvLabUiTx(on ? "lab.toast.on" : "lab.toast.off"), t0: P.t, dur: 2.6 };
   if (typeof fvLog === "function") fvLog("flight lab: " + (on ? "ON" : "OFF") + (on ? " S=" + P.lab.S.toFixed(2) : ""));
   return on;
}
// teclas del laboratorio en el dialogo: L siempre; V y O solo con el laboratorio encendido -> true si consumida
function fvLabUiKey(D, k) {
   if (!D.P) return false;
   var KL = (typeof Key_L !== "undefined") ? Key_L : 0x4c, KV = (typeof Key_V !== "undefined") ? Key_V : 0x56, KO = (typeof Key_O !== "undefined") ? Key_O : 0x4f, KK = (typeof Key_K !== "undefined") ? Key_K : 0x4b;
   if (k === KL) { fvLabUiToggle(D); return true; }
   if (FV_LAB.ON !== true) return false;
   if (k === KV) { fvLabSetS(D.P, FV_LAB.S_MODE + 1); return true; }
   if (k === KO) { fvLabTele(D.P); return true; }
   if (k === KK) { fvLabUiContent(D); return true; }
   return false;
}
// (v4) conmutar el vuelo v4 (fila del panel), con su aviso. El viaje en curso sigue con su ley; las teclas se vuelven a leer
function fvLabUiV4(D) {
   FV_LAB.V4.ON = !FV_LAB.V4.ON; P_LAB_KEYS = null;
   if (D && D.P && D.P.lab) { D.P.lab.S = D.P.lab.S0 || D.P.lab.S; D.P.cam.S = D.P.lab.S; }
   if (D && D.ui && D.P) D.ui.caption = { text: fvLabUiTx(FV_LAB.V4.ON ? "lab.toast.v4On" : "lab.toast.v4Off"), t0: D.P.t, dur: 2.6 };
   return FV_LAB.V4.ON;
}
// (v5) conmutar el vuelo v5 (encima de la v4), con su aviso
function fvLabUiV5(D) {
   FV_LAB.V5.ON = !FV_LAB.V5.ON;
   if (D && D.ui && D.P) D.ui.caption = { text: fvLabUiTx(FV_LAB.V5.ON ? "lab.toast.v5On" : "lab.toast.v5Off"), t0: D.P.t, dur: 2.6 };
   return FV_LAB.V5.ON;
}
// (v3) conmutar la mirada al contenido (tecla K o el panel), con su aviso
function fvLabUiContent(D) {
   FV_LAB.CONTENT.ON = !FV_LAB.CONTENT.ON;
   if (D && D.ui && D.P) D.ui.caption = { text: fvLabUiTx(FV_LAB.CONTENT.ON ? "lab.toast.cOn" : "lab.toast.cOff"), t0: D.P.t, dur: 2.6 };
   return FV_LAB.CONTENT.ON;
}
// D10: lo que el ancla necesita saber del fotograma recien pintado (estrellas y nebulosa en pantalla)
function fvLabUiAnchorFrame(painter, pr, P, W, H) {
   if (!P || !P.lab || typeof fvLabAnchorWant !== "function") return;
   var cover = 0, pq = null;
   try { pq = painter.photoQuad ? painter.photoQuad(pr) : null; } catch (e) { pq = null; }
   if (pq && pq.q && typeof fvPolyAreaClip === "function") {
      var wl = (painter.stats.wPhoto || 0) + (painter.stats.layers > 0 ? 1 : 0);
      cover = wl > 0 ? fvPolyAreaClip(pq.q, W, H) / (W * H) : 0;
   }
   fvLabAnchorWant(P, painter.stats, cover);
   // (v3) la luz de la foto para la mirada al contenido: una vez por escena
   if (P.lab.lumFor !== painter.scene && painter.photoPlane && typeof fvLabLumGrid === "function") { P.lab.lum = fvLabLumGrid(painter.photoPlane, FV_LAB.CONTENT.GRID_X, FV_LAB.CONTENT.GRID_Y); P.lab.lumFor = painter.scene; }
}
