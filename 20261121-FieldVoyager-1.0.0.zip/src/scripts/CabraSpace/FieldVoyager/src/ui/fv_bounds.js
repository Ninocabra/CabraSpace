// ============================================================================
// FieldVoyager/src/ui/fv_bounds.js — LOS LIMITES DEL 3D DE LA IMAGEN Y EL ICONO DE LA NAVE (encargo C, 9-nov-2026)
// ----------------------------------------------------------------------------
// Nino (N6, M 82 casi negro en la cadena de MIRABILIA): «poner bordes dorados en los planos que limitan el 3D de nuestra imagen, siendo
// consistentes con la propia vista 3D. Que cuando estes cerca se iluminen tenue y transparentes pero que dejen claro que hasta ahi llega la
// imagen. Esto tambien señalarlo en el visor 3D.» Y: «En el visor 3D y 2D usar un icono representacion de la imagen en lugar de una flecha.»
//
// C1 · LA VISTA DE VUELO (fvBoundsPaint, una linea en FVPainter.render). Los planos que acotan el 3D de la imagen, con la MISMA geometria que
//      dibuja PROFUNDITAS (FVNavMap3D): las 4 paredes del cono de la foto (de la Tierra a los bordes de la foto, hasta la boca a dMax, la
//      profundidad 1 del mapa), la boca, y las dos caras de la losa de la nebulosa (las capas primera y ultima, inclinadas como el pintor).
//      · filete dorado en las aristas (las 4 del cono, el rectangulo de la boca y el de cada cara = sus cortes con las paredes)
//      · velo dorado tenue sobre cada plano: opacidad por pixel segun la distancia de la nave al punto del plano (cerca = claro, lejos = nada)
//      Todo en Screen (nunca oscurece: las estrellas y la foto de dentro siguen igual de claras debajo). Nada cerca de casa (HOME_FADE) ni en
//      el salto del warp. Fuera del cono, el alambre entero se enciende un poco (EDGE_OUT): desde fuera se ve donde esta la imagen.
// C2 · PROFUNDITAS (fvBoundsMap3D, una linea en FVNavMap3D.paint; vale para la franja y para el grande de ITINERARIUM): las mismas aristas
//      en oro y el plano que la nave tiene cerca, iluminado con el mismo peso que en el vuelo.
// C3 · EL ICONO DE LA NAVE (fvBoundsShipIcon, una linea en fvNavShipGlyph; fvBoundsShipEdge en TABULA cuando la nave sale de la foto):
//      la silueta en planta de la nave del arranque (casco de galeon con proa, disco y las dos gondolas atras), orientada a su rumbo,
//      laton con filo oscuro. Bandera propia: la frase de Nino es ambigua y puede cambiarse sin tocar C1–C2.
// Banderas apagadas = hoy bit a bit (ninguna funcion toca g). ES5.
// ============================================================================

var FV_BOUNDS = {
   ON: true,           // C1 · los planos en la vista de vuelo (9-nov: encendido para que Nino lo vea; false = lo de antes, bit a bit)
   MAP: true,          // C2 · los planos en PROFUNDITAS
   ICON: true,         // C3 · la silueta de la nave en TABULA y PROFUNDITAS en lugar de la punta de flecha
   SIDES: true, FACES: true, MOUTH: true,     // que planos (paredes del cono, caras de la losa, boca del cono)
   VEIL: true,                                 // el velo (false = solo los filetes)
   // ---- cercania (ELECCION nuestra, ajustada mirando las capturas; ver docs/encargos-9nov/C-bordes-icono.md) ----
   // radio R de cada tipo de plano. Peso del plano w = 1 − smoothstep(d_nave / R): el plano se ENCIENDE entero cuando la nave esta a menos de R;
   // lo que se ve de el (rejilla, velo, filetes) se apaga con la distancia del punto a la nave en FALL_K × R
   K_SIDE: 0.8,        // paredes: × el semiancho menor del cono a la profundidad de la nave (en el centro del cono, apagadas)
   Z_FLOOR: 0.10,      //   ... con esa profundidad acotada abajo a Z_FLOOR × D (junto a la Tierra el cono es una aguja)
   K_FACE: 1.0,        // caras de la losa: × max(grosor de la losa, semiancho menor del cono a la distancia D)
   K_MOUTH: 1.0,       // boca: × el semiancho menor del cono en la boca
   FALL_K: 4.0,        // hasta donde se ve el plano encendido, × R
   ON_PLANE: 0.06,     // con la nave EN el plano (d < ON_PLANE × R) rejilla y velo se apagan: de canto todo caeria en una sola raya
   HOME_FADE: 0.05,    // nada mientras la nave no se ha alejado HOME_FADE × D de la Tierra (en casa la foto llena la pantalla)
   WT: { side: 1.0, front: 0.6, back: 1.0, mouth: 1.0 },   // peso de cada tipo (la cara de delante no es «fin» de la imagen: mas suave)
   // ---- rejilla (lo que hace leer el velo como una PARED: lineas en perspectiva) ----
   GRID: true, GRID_K: 0.7, GRID_MAX: 0.40, GRID_W: 0,     // paso = GRID_K × R (v1 0,5); opacidad maxima; grosor (0 = pluma cosmetica de 1 px: la raya barata de Qt; v1 1,0 a 1280)
   GRID_N: 10, GRID_PX: [3, 14], GRID_ANG: 0.5, GRID_MIN: 0.02,   // (ronda 2) tramos por linea (v1 ~20; con 3 los extremos se cortaban en seco); densidad: apagada a 3 px de separacion, entera desde 14;
                                                                 // de canto al 50 %; un tramo por debajo de GRID_MIN (5/255) no se pinta
   // ---- velo ----
   VEIL_MAX: 0.12,     // opacidad maxima del velo (Screen)
   VEIL_FACE: 0.3,     // de frente el velo es un lavado plano: se queda en VEIL_FACE; de canto, entero
   VEIL_DIV: 16,       // el velo se calcula a 1/VEIL_DIV de resolucion y se escala suave (es una nube sin detalle; v1 4: 16 veces mas pixeles)
   VEIL_COL: 0xE5B53F,
   // (ronda 2) composicion del velo y de las rayas: "add" (Plus: el camino rapido de Qt; con oro ≤ 0,12 sobre negro es Screen salvo en lo muy claro) | "screen" (v1);
   // VEIL_BBOX: componer solo el rectangulo con velo. DBG_*: sondas de coste (sin dibujar el velo / las rayas)
   VEIL_OP: "add", VEIL_BBOX: true, LINE_OP: "add", DBG_NODRAW: false, DBG_NOLINE: false,
   // (ronda 2) el coste de una raya es por PIXEL pintado, no por llamada (probe_lines: 10 px ~0 us, 300 px 20-48 us): GRID_POW = caida de la
   // rejilla (opacidad × cercania^POW: mas tenue hacia fuera) y cada linea se recorta al disco donde aun supera GRID_MIN. VEIL_BBOX_A: un pixel del
   // velo por debajo de esta opacidad (/255) no agranda el rectangulo que se compone
   GRID_POW: 2, VEIL_BBOX_A: 3, GRID_X: 0.9,
   GRID_BUDGET: 16000,     // pixeles de rejilla por fotograma como mucho (los tramos mas opacos primero): el tope duro del peor caso (~0,1 us/px con carga)
   // ---- filetes ----
   EDGE_MAX: 0.90,     // opacidad del filete junto a la nave (radio EDGE_R × R)
   EDGE_R: 1.6,
   EDGE_LIT: 0.80,     // las aristas del plano encendido, por su peso (hasta FALL_K × R)
   EDGE_OUT: 0.35,     // fuera del cono: todo el alambre a esta opacidad (por la distancia fuera, rampa OUT_K × semiancho)
   OUT_K: 1.0,
   SLAB_EDGE: 0.0,     // suelo de opacidad del rectangulo de la losa (el borde duro de N4); 0 = solo de cerca
   EDGE_W: 1.4,        // grosor del filete (px a 1280 de ancho)
   EDGE_COL: 0xF3D27E,
   // ---- PROFUNDITAS ----
   MAP_EDGE: 0.62,     // opacidad base de las aristas doradas del mapa
   MAP_FILL: 0.30,     // relleno maximo del plano encendido
   // ---- icono ----
   ICON_K: 1.2,        // la silueta mide 2 × ICON_K × S de proa a popa (la flecha de antes, 2,4 S)
   ICON_INK: 0xff2A1F15, ICON_HULL: 0xffFFF3C4, ICON_DISC: 0xffE5B53F, ICON_NAC: 0xffC99634
};
var FV_BOUNDS_C = { scene: null, key: "", geom: null };   // la geometria de la ultima escena (se rehace si cambia la escena o la inclinacion)

// ---------------------------------------------------------------------------
// LA GEOMETRIA (mundo, a.l.; la Tierra en el origen, +Z hacia la foto, +X derecha, +Y abajo de la foto)
// ---------------------------------------------------------------------------
// la inclinacion de la losa, como el pintor (FVPainter.tiltOf): null | { t, D, n }
function fvBoundsTilt(scene) {
   var N = scene.nebula, t = N && N.tilt;
   if (typeof FV_PAINT !== "undefined" && FV_PAINT.TILT_ON === false) return null;
   if (!t || (!(Math.abs(t[0]) > 1e-9) && !(Math.abs(t[1]) > 1e-9))) return null;
   var tp = (typeof fvPaintTiltPt === "function") ? fvPaintTiltPt : fvNavTiltPt;
   return { t: t, D: N.distLy, n: fvNorm(tp([0, 0, 1], 0, t)), tp: tp };
}
// el punto (wx, wy) de la cara a la profundidad z (sin inclinar) llevado al plano inclinado (FVPainter.planePt)
function fvBoundsFacePt(z, wx, wy, T) {
   if (!T) return [wx, wy, z];
   var c = T.tp([0, 0, z], T.D, T.t), dx = wx / z, dy = wy / z, den = T.n[0] * dx + T.n[1] * dy + T.n[2];
   var s = (T.n[0] * c[0] + T.n[1] * c[1] + T.n[2] * c[2]) / (Math.abs(den) > 1e-12 ? den : 1e-12);
   return [s * dx, s * dy, s];
}
// un plano acotado (poligono convexo): normal, desplazamiento y los bordes para «¿cae dentro?» (m·p >= o en todos)
function fvBoundsPlane(id, kind, V, e1h) {
   var n = fvNorm(fvCross(fvSub(V[1], V[0]), fvSub(V[2], V[0]))), pc = [0, 0, 0], i, M = [];
   for (i = 0; i < V.length; ++i) pc = fvAdd(pc, V[i]);
   pc = fvMul(pc, 1 / V.length);
   for (i = 0; i < V.length; ++i) {
      var a = V[i], b = V[(i + 1) % V.length], m = fvCross(n, fvSub(b, a));
      if (fvDot(m, fvSub(pc, a)) < 0) m = fvMul(m, -1);
      M.push({ m: m, o: fvDot(m, a) });
   }
   // los ejes del plano para la rejilla: e1 (en las paredes, a lo largo del cono desde la Tierra; en los cuadrilateros, el primer lado) y e2 = n × e1
   var e1 = fvNorm(e1h ? fvSub(e1h, fvMul(n, fvDot(n, e1h))) : fvSub(V[1], V[0])), e2 = fvNorm(fvCross(n, e1)), UV = [];
   for (i = 0; i < V.length; ++i) { var w = fvSub(V[i], V[0]); UV.push([fvDot(w, e1), fvDot(w, e2)]); }
   return { id: id, kind: kind, V: V, n: n, c: fvDot(n, V[0]), M: M, e1: e1, e2: e2, UV: UV };
}
function fvBoundsGeom(scene) {
   var N = scene.nebula, f = scene.field, T = fvBoundsTilt(scene);
   // (14-nov, encargo A) dMax sale de fvBoxDMax (fv_objects.js; la misma cuenta que estaba aqui) y entra en la clave: si se pedia antes del primer piloto (fvSceneTuckAssumed mueve estrellas), la cache se quedaba con la boca de antes
   var dMax = (typeof fvBoxDMax === "function") ? fvBoxDMax(scene) : 0;
   var key = (T ? T.t[0].toFixed(4) + "," + T.t[1].toFixed(4) : "-") + "|" + (N ? N.distLy + ":" + N.thickLy : "x") + "|" + FV_BOUNDS.SIDES + FV_BOUNDS.FACES + FV_BOUNDS.MOUTH + "|" + dMax;
   if (FV_BOUNDS_C.scene === scene && FV_BOUNDS_C.key === key) return FV_BOUNDS_C.geom;
   // dMax: el MISMO que FVNavMap3D (la boca del cono del mapa es la profundidad 1)
   var S = scene.stars, i;
   if (!(dMax > 0)) { var ds = []; if (S) for (i = 0; i < S.n; ++i) if (S.inFrame[i]) ds.push(S.dEarth[i]); ds.sort(function(a, b) { return a - b; }); var p97 = ds.length ? ds[Math.min(ds.length - 1, Math.floor(0.97 * ds.length))] : 1000; dMax = Math.max(100, N ? 1.35 * N.distLy : 0, p97); }
   var hx = (f.width / 2) / f.F, hy = (f.height / 2) / f.F;
   var zM = dMax / Math.sqrt(hx * hx + hy * hy + 1);           // las esquinas de la boca, a la distancia dMax de la Tierra
   var SG = [[-1, -1], [1, -1], [1, 1], [-1, 1]], O = [0, 0, 0], C = [], A = null, B = null, k;
   for (k = 0; k < 4; ++k) C.push([SG[k][0] * hx * zM, SG[k][1] * hy * zM, zM]);
   var D = N ? N.distLy : 0.5 * zM, th = N ? N.thickLy : 0, zA = 0, zB = 0;
   if (N && N.layers && N.layers.length) {
      zA = N.layers[0].z; zB = N.layers[N.layers.length - 1].z;
      if (zB - zA < 1e-6) { zA = D - 0.5 * Math.max(th, 1e-3); zB = D + 0.5 * Math.max(th, 1e-3); }
      A = []; B = [];
      for (k = 0; k < 4; ++k) { A.push(fvBoundsFacePt(zA, SG[k][0] * hx * zA, SG[k][1] * hy * zA, T)); B.push(fvBoundsFacePt(zB, SG[k][0] * hx * zB, SG[k][1] * hy * zB, T)); }
   }
   // los planos: 0..3 paredes (arriba, derecha, abajo, izquierda de la foto), 4 boca, 5 cara de delante, 6 cara de detras
   var P = [], E = [], SIDE = ["top", "right", "bottom", "left"];
   for (k = 0; k < 4; ++k) P.push(FV_BOUNDS.SIDES ? fvBoundsPlane(SIDE[k], "side", [O, C[k], C[(k + 1) % 4]], fvAdd(C[k], C[(k + 1) % 4])) : null);
   P.push(FV_BOUNDS.MOUTH ? fvBoundsPlane("mouth", "mouth", C) : null);
   P.push(FV_BOUNDS.FACES && A ? fvBoundsPlane("front", "front", A) : null);
   P.push(FV_BOUNDS.FACES && B ? fvBoundsPlane("back", "back", B) : null);
   // las aristas: { a, b, ka, kb (claves de los extremos para el mapa), planes: [i…], face }
   for (k = 0; k < 4; ++k) E.push({ a: O, b: C[k], ka: ["E", k], kb: ["C", k], planes: [k, (k + 3) % 4], face: false });
   for (k = 0; k < 4; ++k) E.push({ a: C[k], b: C[(k + 1) % 4], ka: ["C", k], kb: ["C", (k + 1) % 4], planes: [k, 4], face: false });
   if (A) for (k = 0; k < 4; ++k) {
      E.push({ a: A[k], b: A[(k + 1) % 4], ka: ["A", k], kb: ["A", (k + 1) % 4], planes: [k, 5], face: true });
      E.push({ a: B[k], b: B[(k + 1) % 4], ka: ["B", k], kb: ["B", (k + 1) % 4], planes: [k, 6], face: true });
   }
   var G = { hx: hx, hy: hy, hmin: Math.min(hx, hy), dMax: dMax, zM: zM, D: D, th: th, zA: zA, zB: zB, C: C, A: A, B: B, planes: P, edges: E, tilt: T };
   FV_BOUNDS_C.scene = scene; FV_BOUNDS_C.key = key; FV_BOUNDS_C.geom = G;
   return G;
}
// distancia de p al plano acotado (poligono convexo)
function fvBoundsPolyDist(p, Q) {
   var s = fvDot(Q.n, p) - Q.c, q = fvSub(p, fvMul(Q.n, s)), inside = true, i;
   for (i = 0; i < Q.M.length; ++i) if (fvDot(Q.M[i].m, q) < Q.M[i].o) { inside = false; break; }
   if (inside) return Math.abs(s);
   var best = 1e300;
   for (i = 0; i < Q.V.length; ++i) best = Math.min(best, fvBoundsSegDist(p, Q.V[i], Q.V[(i + 1) % Q.V.length]).d);
   return best;
}
// distancia de p al segmento a–b -> { d, t }
function fvBoundsSegDist(p, a, b) {
   var ab = fvSub(b, a), L2 = fvDot(ab, ab), t = L2 > 0 ? fvClamp(fvDot(fvSub(p, a), ab) / L2, 0, 1) : 0;
   return { d: fvLen(fvSub(fvAdd(a, fvMul(ab, t)), p)), t: t };
}
function fvBoundsNear(x) { return x >= 1 ? 0 : 1 - fvSmooth(x); }
// el estado de la nave respecto a los limites: radios, distancias y pesos de cada plano, cuanto esta fuera del cono y el fundido de casa
//   w[i]   peso del plano (1 − smoothstep(d / R) × el peso de su tipo): cuanto se enciende
//   wv[i]  lo mismo apagado cuando la nave esta EN el plano (ON_PLANE): lo que usan rejilla y velo
function fvBoundsState(G, pos) {
   var D = G.D, zc = fvClamp(pos[2], FV_BOUNDS.Z_FLOOR * D, G.zM), Wc = G.hmin * zc, R = [], dist = [], w = [], wv = [], i;
   var Rk = { side: FV_BOUNDS.K_SIDE * Wc, mouth: FV_BOUNDS.K_MOUTH * G.hmin * G.zM, front: FV_BOUNDS.K_FACE * Math.max(G.th, G.hmin * D) };
   Rk.back = Rk.front;
   for (i = 0; i < G.planes.length; ++i) {
      var Q = G.planes[i];
      if (!Q) { R.push(1); dist.push(1e300); w.push(0); wv.push(0); continue; }
      R.push(Math.max(1e-9, Rk[Q.kind])); dist.push(fvBoundsPolyDist(pos, Q));
      w.push((FV_BOUNDS.WT[Q.kind] || 1) * fvBoundsNear(dist[i] / R[i]));
      wv.push(w[i] * fvSmooth(Math.abs(fvDot(Q.n, pos) - Q.c) / (FV_BOUNDS.ON_PLANE * R[i])));
   }
   var z = pos[2], zp = Math.max(z, 0), dOut = Math.max(Math.abs(pos[0]) - G.hx * zp, Math.abs(pos[1]) - G.hy * zp, -z, fvLen(pos) - G.dMax);
   var out = dOut > 0 ? fvSmooth(dOut / Math.max(1e-9, FV_BOUNDS.OUT_K * Wc)) : 0;
   var wHome = fvSmooth(fvLen(pos) / Math.max(1e-9, FV_BOUNDS.HOME_FADE * D));
   return { R: R, dist: dist, w: w, wv: wv, out: out, dOut: dOut, wHome: wHome, Wc: Wc };
}

// ---------------------------------------------------------------------------
// C1 · LA VISTA DE VUELO
// ---------------------------------------------------------------------------
function fvBoundsPaint(painter, g, pr, P) {
   if (!FV_BOUNDS.ON) return;
   var sc = painter.scene;
   if (!sc || !sc.field || !P || !P.cam) return;
   var t0 = fvNowMs(), G = fvBoundsGeom(sc), pos = P.cam.pos, st = fvBoundsState(G, pos);
   var wAll = st.wHome * (1 - fvSmooth((P.warp || 0) / 0.6));
   var info = { w: st.w.slice(), out: st.out, wAll: wAll, veil: 0, grid: 0, edges: 0, ms: 0 };
   painter.stats.bounds = info;
   if (wAll <= 0.002) return;
   var keepOp = g.compositionOperator, keepSm = g.smoothInterpolation;
   try {
      g.resetTransformation(); g.opacity = 1; g.compositionOperator = CompositionOp_Screen; g.antialiasing = true;
      var t1 = fvNowMs();
      if (FV_BOUNDS.VEIL) info.veil = fvBoundsVeil(painter, g, pr, G, st, wAll, pos);
      if (FV_BOUNDS.LINE_OP === "add") g.compositionOperator = CompositionOp_Add;
      var t2 = fvNowMs(), ctx = { g: g, pr: pr, pos: pos, nearZ: 1e-4 * G.D, box: [-4, -4, pr.W + 4, pr.H + 4], n: 0 };
      if (FV_BOUNDS.GRID) {
         ctx.lw = FV_BOUNDS.GRID_W * Math.max(1, pr.W / 1280); ctx.pens = fvBoundsPens(ctx.lw); g.antialiasing = FV_BOUNDS.GRID_AA !== false;
         ctx.defer = []; fvBoundsGrid(ctx, G, st, wAll);
         // (ronda 2) el coste de la raya es por pixel: se pintan los tramos de mas opacos a menos hasta GRID_BUDGET pixeles; lo que sobra es lo mas tenue
         var Dq = ctx.defer, budget = FV_BOUNDS.GRID_BUDGET || 1e12, used = 0, nd = 0; ctx.defer = null;
         Dq.sort(function(a, b) { return b.q - a.q; });
         // el nivel de corte qc = la opacidad del primer tramo que ya no cabe; los que caben se re-escalan (q - qc) / (qmax - qc) para que las
         // lineas se apaguen a 0 justo donde se corta (si no, todas acababan en seco a la misma opacidad: un borde falso, visto en side_in)
         var qc = 0, acc = 0, qmax = Dq.length ? Dq[0].q : 0;
         for (var dj = 0; dj < Dq.length; ++dj) { acc += Dq[dj].px; if (acc > budget) { qc = Dq[dj].q; break; } }
         for (var di = 0; di < Dq.length; ++di) {
            var it = Dq[di]; if (it.q <= qc) break;
            var pen = qc > 0 ? fvBoundsPen(ctx, (it.q - qc) / (qmax - qc) * qmax / 63) : it.pen; if (!pen) continue;
            used += it.px; ++nd;
            if (ctx.lastPen !== pen) { g.pen = pen; ctx.lastPen = pen; }
            g.drawLine(it.c[0], it.c[1], it.c[2], it.c[3]);
         }
         info.gridCut = qc;
         g.antialiasing = true; info.grid = nd; info.gridPx = used; info.gridAll = Dq.length; ctx.n = 0;
      }
      var t3 = fvNowMs();
      ctx.lw = FV_BOUNDS.EDGE_W * Math.max(1, pr.W / 1280); ctx.pens = fvBoundsPens(ctx.lw); ctx.lastPen = null;
      fvBoundsEdges(ctx, G, st, wAll); info.edges = ctx.n;
      info.msVeil = t2 - t1; info.msGrid = t3 - t2; info.msEdges = fvNowMs() - t3;
   } finally {
      g.resetTransformation(); g.opacity = 1; g.compositionOperator = keepOp; g.smoothInterpolation = keepSm;
   }
   info.ms = fvNowMs() - t0;
}
// el velo: por pixel (a 1/VEIL_DIV), el rayo de la camara cortado con cada plano encendido; opacidad = peso del plano × caida con la distancia
// de la nave al punto (FALL_K × R) × angulo (de frente VEIL_FACE, de canto 1) -> numero de planos que lo pintaron
function fvBoundsVeil(painter, g, pr, G, st, wAll, pos) {
   var act = [], i, k;
   for (i = 0; i < G.planes.length; ++i) if (G.planes[i] && st.wv[i] > 0.003) act.push({ Q: G.planes[i], RF: FV_BOUNDS.FALL_K * st.R[i], w: st.wv[i] });
   if (!act.length) return 0;
   var W = pr.W, H = pr.H, div = Math.max(1, FV_BOUNDS.VEIL_DIV), bw = Math.max(2, Math.ceil(W / div)), bh = Math.max(2, Math.ceil(H / div)), sx = W / bw, sy = H / bh;
   var C = painter._fvBounds;
   if (!C || C.bw !== bw || C.bh !== bh) { C = painter._fvBounds = { bw: bw, bh: bh, bmp: new Bitmap(bw, bh, BitmapFormat.ARGB32), buf: new Uint32Array(bw * bh) }; }
   var buf = C.buf, S = pr.S || 1, fw = pr.fw, r = pr.r, d = pr.d, f = pr.f, cx = pr.cx, cy = pr.cy, px = pos[0], py = pos[1], pz = pos[2];
   var bi0 = 1e9, bi1 = -1, bj0 = 1e9, bj1 = -1, Abb = FV_BOUNDS.VEIL_BBOX_A || 1;
   var vmax = FV_BOUNDS.VEIL_MAX * wAll, vf = FV_BOUNDS.VEIL_FACE, col = FV_BOUNDS.VEIL_COL & 0xffffff, nA = act.length, any = 0;
   // por plano: normal, lado de la nave y los bordes (en arrays planos: el bucle no crea objetos)
   var NX = new Float64Array(nA), NY = new Float64Array(nA), NZ = new Float64Array(nA), NC = new Float64Array(nA), RR = new Float64Array(nA), WT = new Float64Array(nA), ME = [];
   for (k = 0; k < nA; ++k) { var Q = act[k].Q; NX[k] = Q.n[0]; NY[k] = Q.n[1]; NZ[k] = Q.n[2]; NC[k] = Q.c - (Q.n[0] * px + Q.n[1] * py + Q.n[2] * pz); RR[k] = act[k].RF; WT[k] = act[k].w; ME.push(Q.M); }
   for (var j = 0; j < bh; ++j) {
      var v = ((j + 0.5) * sy - cy) / f;
      for (i = 0; i < bw; ++i) {
         var u = ((i + 0.5) * sx - cx) / f;
         var dx = (fw[0] + u * r[0] + v * d[0]) / S, dy = (fw[1] + u * r[1] + v * d[1]) / S, dz = fw[2] + u * r[2] + v * d[2];
         var dl = Math.sqrt(dx * dx + dy * dy + dz * dz), rem = 1;
         for (k = 0; k < nA; ++k) {
            var den = NX[k] * dx + NY[k] * dy + NZ[k] * dz;
            if (den > -1e-12 && den < 1e-12) continue;
            var t = NC[k] / den;
            if (!(t > 0)) continue;
            var x = t * dl / RR[k];
            if (x >= 1) continue;
            var hx = px + t * dx, hy = py + t * dy, hz = pz + t * dz, M = ME[k], ok = true;
            for (var e = 0; e < M.length; ++e) { var me = M[e].m; if (me[0] * hx + me[1] * hy + me[2] * hz < M[e].o - 1e-9 * (1 + Math.abs(M[e].o))) { ok = false; break; } }
            if (!ok) continue;
            var cs = Math.abs(den) / dl, sm = x * x * (3 - 2 * x);
            var a = vmax * WT[k] * (1 - sm) * (vf + (1 - vf) * (1 - cs));
            rem *= 1 - (a > 1 ? 1 : a);
         }
         var A = Math.round(255 * (1 - rem));
         buf[j * bw + i] = A > 0 ? (((A << 24) | col) >>> 0) : 0;
         if (A >= Abb) { any = 1; if (i < bi0) bi0 = i; if (i > bi1) bi1 = i; if (j < bj0) bj0 = j; if (j > bj1) bj1 = j; }
      }
   }
   if (!any) return 0;
   var bmp = C.bmp;
   new Uint32Array(bmp.pixelData()).set(buf);       // (fv_painter.js, paintFog) la vista nativa solo para copiar, con el Bitmap vivo
   if (FV_BOUNDS.DBG_NODRAW) return nA;
   if (FV_BOUNDS.VEIL_OP === "add") g.compositionOperator = CompositionOp_Add;
   g.smoothInterpolation = FV_BOUNDS.VEIL_SMOOTH !== false;
   if (FV_BOUNDS.VEIL_BBOX) {        // solo el rectangulo con velo (un pixel de margen para el suavizado)
      bi0 = Math.max(0, bi0 - 1); bj0 = Math.max(0, bj0 - 1); bi1 = Math.min(bw - 1, bi1 + 1); bj1 = Math.min(bh - 1, bj1 + 1);
      g.transformationMatrix = new Matrix(sx, 0, bi0 * sx, 0, sy, bj0 * sy, 0, 0, 1);
      g.drawBitmapRect(0, 0, bmp, bi0, bj0, bi1 + 1, bj1 + 1);
   } else {
      g.transformationMatrix = new Matrix(sx, 0, 0, 0, sy, 0, 0, 0, 1);
      g.drawBitmap(0, 0, bmp);
   }
   g.resetTransformation();
   g.compositionOperator = CompositionOp_Screen;
   return nA;
}
// (ronda 2) LOS TRAMOS DORADOS, BARATOS: sin arrays por tramo (proyeccion en linea con la base del proyector, con el espacio estirado S del
// laboratorio), plumas cacheadas por nivel de opacidad (64 niveles: 4/255 de paso) y cortes fijos. Antes (v1) cada tramo creaba ~8 arrays,
// una pluma y una proyeccion con closure: la rejilla de la esquina de la losa costaba 16 ms (tests/bounds, PERF).
// ctx = { g, pr, pos, nearZ, box, lw, n, pens }
var FV_BOUNDS_PENS = {};
function fvBoundsPens(lw) { var k = lw.toFixed(3) + ":" + FV_BOUNDS.EDGE_COL; return FV_BOUNDS_PENS[k] || (FV_BOUNDS_PENS[k] = []); }
function fvBoundsPen(ctx, al) {
   var q = Math.round(63 * (al > 1 ? 1 : al));
   if (q <= 0) return null;
   var P = ctx.pens || (ctx.pens = []);
   return P[q] || (P[q] = new Pen((((q * 4 + 3) << 24) | (FV_BOUNDS.EDGE_COL & 0xffffff)) >>> 0, ctx.lw));
}
// un tramo p0–p1 (coordenadas sueltas) ya con su opacidad: recorte al plano cercano, proyeccion, recorte a la pantalla y raya
function fvBoundsPiece(ctx, x0, y0, z0, x1, y1, z1, al) {
   var pen = fvBoundsPen(ctx, al); if (!pen) return;
   var pr = ctx.pr, S = pr.S || 1, fw = pr.fw, r = pr.r, d = pr.d, f = pr.f, ps = ctx.pos, nz = ctx.nearZ;
   var ax = S * (x0 - ps[0]), ay = S * (y0 - ps[1]), az = z0 - ps[2], bx = S * (x1 - ps[0]), by = S * (y1 - ps[1]), bz = z1 - ps[2];
   var za = ax * fw[0] + ay * fw[1] + az * fw[2], zb = bx * fw[0] + by * fw[1] + bz * fw[2];
   if (za < nz && zb < nz) return;
   if (za < nz) { var ta = (nz - za) / (zb - za); ax += ta * (bx - ax); ay += ta * (by - ay); az += ta * (bz - az); za = nz; }
   else if (zb < nz) { var tb = (nz - zb) / (za - zb); bx += tb * (ax - bx); by += tb * (ay - by); bz += tb * (az - bz); zb = nz; }
   var sx0 = pr.cx + f * (ax * r[0] + ay * r[1] + az * r[2]) / za, sy0 = pr.cy + f * (ax * d[0] + ay * d[1] + az * d[2]) / za;
   var sx1 = pr.cx + f * (bx * r[0] + by * r[1] + bz * r[2]) / zb, sy1 = pr.cy + f * (bx * d[0] + by * d[1] + bz * d[2]) / zb;
   var cl = fvNavClip(sx0, sy0, sx1, sy1, ctx.box); if (!cl) return;
   ++ctx.n; if (FV_BOUNDS.DBG_NOLINE) return;
   if (ctx.defer) { ctx.defer.push({ q: Math.round(63 * (al > 1 ? 1 : al)), pen: pen, c: cl, px: Math.max(Math.abs(cl[2] - cl[0]), Math.abs(cl[3] - cl[1])) }); return; }
   if (ctx.lastPen !== pen) { ctx.g.pen = pen; ctx.lastPen = pen; }
   ctx.g.drawLine(cl[0], cl[1], cl[2], cl[3]);
}
// un segmento a–b partido en tramos: cortes mas finos cerca del punto mas proximo a la nave (FV_BOUNDS_OFF × R) o, con nU > 0, nU tramos
// iguales. alpha(d, mx, my, mz) = la opacidad del tramo por la distancia d de su punto medio a la nave (y el punto, para la rejilla)
var FV_BOUNDS_OFF = [0.1, 0.25, 0.45, 0.7, 1.0, 1.3];
function fvBoundsSeg(ctx, a, b, R, alpha, dense, nU) {
   var pos = ctx.pos, k, q, abx = b[0] - a[0], aby = b[1] - a[1], abz = b[2] - a[2], L2 = abx * abx + aby * aby + abz * abz;
   if (!(L2 > 0)) return;
   var ts;
   if (nU > 0) { ts = []; for (k = 0; k <= nU; ++k) ts.push(k / nU); }
   else {
      var L = Math.sqrt(L2), tc = fvClamp(((pos[0] - a[0]) * abx + (pos[1] - a[1]) * aby + (pos[2] - a[2]) * abz) / L2, 0, 1);
      ts = [0, 1, tc];
      for (k = 0; k < FV_BOUNDS_OFF.length; ++k) { q = FV_BOUNDS_OFF[k] * R / L; if (tc - q > 0) ts.push(tc - q); if (tc + q < 1) ts.push(tc + q); }
      if (dense) for (k = 1; k < 12; ++k) ts.push(k / 12);
      ts.sort(function(x, y) { return x - y; });
   }
   for (k = 1; k < ts.length; ++k) {
      var ta = ts[k - 1], tb = ts[k]; if (tb - ta < 1e-9) continue;
      var tm = 0.5 * (ta + tb), mx = a[0] + abx * tm, my = a[1] + aby * tm, mz = a[2] + abz * tm, dx = mx - pos[0], dy = my - pos[1], dz = mz - pos[2];
      var al = alpha(Math.sqrt(dx * dx + dy * dy + dz * dz), mx, my, mz);
      if (al < (nU > 0 ? FV_BOUNDS.GRID_MIN : 0.008)) continue;
      fvBoundsPiece(ctx, a[0] + abx * ta, a[1] + aby * ta, a[2] + abz * ta, a[0] + abx * tb, a[1] + aby * tb, a[2] + abz * tb, al);
   }
}
// los filetes: cerca de la nave (EDGE_R × R), las del plano encendido (EDGE_LIT × su peso, hasta FALL_K × R) y, fuera del cono, todo el alambre
function fvBoundsEdges(ctx, G, st, wAll) {
   var E = G.edges, i, k;
   for (i = 0; i < E.length; ++i) {
      var e = E[i], R = 0, wl = 0, live = false;
      for (k = 0; k < e.planes.length; ++k) { var pi = e.planes[k]; if (G.planes[pi]) { live = true; R = Math.max(R, st.R[pi]); wl = Math.max(wl, st.w[pi]); } }
      if (!live) continue;
      var Re = FV_BOUNDS.EDGE_R * R, RF = FV_BOUNDS.FALL_K * R, floor = Math.max(FV_BOUNDS.EDGE_OUT * st.out, e.face ? FV_BOUNDS.SLAB_EDGE : 0), lit = FV_BOUNDS.EDGE_LIT * wl;
      var sd = fvBoundsSegDist(ctx.pos, e.a, e.b).d;
      if (floor * wAll < 0.004 && sd >= Math.max(Re, lit > 0.01 ? RF : 0)) continue;
      fvBoundsSeg(ctx, e.a, e.b, Math.max(Re, RF), function(d) { return Math.max(floor, FV_BOUNDS.EDGE_MAX * fvBoundsNear(d / Re), lit * fvBoundsNear(d / RF)) * wAll; }, floor > 0, 0);
   }
}
// la rejilla del plano encendido: lineas de paso GRID_K × R (fijas en el plano: no nadan al moverse) alrededor del punto mas cercano a la nave,
// recortadas al poligono del plano y apagandose a FALL_K × R.
// (ronda 2, Nino: «tenue y transparentes») cada tramo se atenua ademas
//   · por la DENSIDAD en pantalla: la separacion proyectada entre dos lineas vecinas (f · paso / d · seno entre el rayo y la direccion de
//     separacion) por debajo de GRID_PX[1] px se apaga hasta 0 en GRID_PX[0]: junto al horizonte las lineas no se amontonan en una malla ni en moire
//   · por el ANGULO: de canto (rayo casi en el plano) a GRID_ANG, de frente entero
function fvBoundsGrid(ctx, G, st, wAll) {
   var pr = ctx.pr, f = pr.f, pos = ctx.pos, P0 = FV_BOUNDS.GRID_PX[0], P1 = FV_BOUNDS.GRID_PX[1], GA = FV_BOUNDS.GRID_ANG;
   // (ronda 2) la rejilla es del plano MAS encendido: los demas solo la llevan si su peso se le acerca (factor suave de w / w_max entre GRID_X y 1,
   // sin saltos al cambiar de plano). En una esquina dos rejillas cruzadas son justo la malla que no queremos, y doblan el coste
   var wTop = 0, X = FV_BOUNDS.GRID_X;
   for (var j = 0; j < G.planes.length; ++j) if (G.planes[j]) wTop = Math.max(wTop, st.wv[j]);
   for (var i = 0; i < G.planes.length; ++i) {
      var Q = G.planes[i], w = st.wv[i];
      if (!Q || w < 0.01) continue;
      if (X > 0 && X < 1) { w *= fvSmooth((w / wTop - X) / (1 - X)); if (w < 0.01) continue; }
      var R = st.R[i], RF = FV_BOUNDS.FALL_K * R, s = FV_BOUNDS.GRID_K * R, am = FV_BOUNDS.GRID_MAX * w * wAll;
      // de frente y muy cerca, el paso se parte por 2 (hasta 8 veces) para que siga habiendo lineas en pantalla: paso <= 0,5 × distancia al plano
      var dP0 = Math.abs(fvDot(Q.n, pos) - Q.c), dP = Math.max(dP0, FV_BOUNDS.ON_PLANE * R), nh = 0;
      while (nh < 3 && s > 0.5 * dP) { s *= 0.5; ++nh; }
      // el disco visible: am · cerca(x)^POW >= GRID_MIN -> x <= xv (biseccion sobre el smoothstep); fuera de el nada se ve y nada se pinta
      var POW = FV_BOUNDS.GRID_POW || 1, qv0 = Math.pow(FV_BOUNDS.GRID_MIN / Math.max(1e-9, am), 1 / POW);
      if (qv0 >= 1) continue;
      var xlo = 0, xhi = 1;
      for (var it = 0; it < 24; ++it) { var xm = 0.5 * (xlo + xhi); if (fvBoundsNear(xm) >= qv0) xlo = xm; else xhi = xm; }
      var rv = xlo * RF, rv2 = rv * rv - dP0 * dP0;
      if (!(rv2 > 0)) continue;
      var rel = fvSub(pos, Q.V[0]), qu = fvDot(rel, Q.e1), qv = fvDot(rel, Q.e2), ax, k, n = Q.n;
      for (ax = 0; ax < 2; ++ax) {
         var rvp = Math.sqrt(rv2), qc = ax === 0 ? qu : qv, k0 = Math.ceil((qc - rvp) / s), k1 = Math.floor((qc + rvp) / s), eA = ax === 0 ? Q.e1 : Q.e2;   // eA: la direccion de SEPARACION entre lineas
         if (k1 - k0 > 80) { k0 = Math.round(qc / s) - 40; k1 = k0 + 80; }
         var fall = (function(eA) {
            return function(d, mx, my, mz) {
               var a0 = am * Math.pow(fvBoundsNear(d / RF), POW); if (a0 < 0.008 || !(d > 0)) return 0;
               var rx = (mx - pos[0]) / d, ry = (my - pos[1]) / d, rz = (mz - pos[2]) / d, ce = rx * eA[0] + ry * eA[1] + rz * eA[2], cn = Math.abs(rx * n[0] + ry * n[1] + rz * n[2]);
               var px = f * s / d * Math.sqrt(Math.max(0, 1 - ce * ce));
               return a0 * fvSmooth((px - P0) / (P1 - P0)) * (GA + (1 - GA) * cn);
            };
         })(eA);
         for (k = k0; k <= k1; ++k) {
            var c = k * s, span = fvBoundsCut(Q.UV, ax, c);       // el tramo de la recta (eje ax = c) dentro del poligono, en la otra coordenada
            if (!span) continue;
            var hh = rv2 - (c - qc) * (c - qc); if (!(hh > 0)) continue;
            hh = Math.sqrt(hh);
            var oc = ax === 0 ? qv : qu, t0 = Math.max(span[0], oc - hh), t1 = Math.min(span[1], oc + hh);
            if (!(t1 > t0)) continue;
            var A = ax === 0 ? fvAdd(Q.V[0], fvAdd(fvMul(Q.e1, c), fvMul(Q.e2, t0))) : fvAdd(Q.V[0], fvAdd(fvMul(Q.e1, t0), fvMul(Q.e2, c)));
            var B = ax === 0 ? fvAdd(Q.V[0], fvAdd(fvMul(Q.e1, c), fvMul(Q.e2, t1))) : fvAdd(Q.V[0], fvAdd(fvMul(Q.e1, t1), fvMul(Q.e2, c)));
            fvBoundsSeg(ctx, A, B, RF, fall, false, FV_BOUNDS.GRID_N);
         }
      }
   }
}
// la recta {coordenada ax = c} cortada con el poligono convexo UV ([[u, v]…]) -> [min, max] de la otra coordenada | null
function fvBoundsCut(UV, ax, c) {
   var lo = 1e300, hi = -1e300, n = UV.length, ob = 1 - ax;
   for (var i = 0; i < n; ++i) {
      var p = UV[i], q = UV[(i + 1) % n], a = p[ax] - c, b = q[ax] - c;
      if (a === 0) { lo = Math.min(lo, p[ob]); hi = Math.max(hi, p[ob]); }
      if ((a < 0 && b > 0) || (a > 0 && b < 0)) { var t = a / (a - b), x = p[ob] + t * (q[ob] - p[ob]); lo = Math.min(lo, x); hi = Math.max(hi, x); }
   }
   return hi > lo ? [lo, hi] : null;
}

// ---------------------------------------------------------------------------
// C2 · PROFUNDITAS (la franja y el grande): las mismas aristas en oro y el plano cercano iluminado
// ---------------------------------------------------------------------------
function fvBoundsMap3D(map, g, r, P, kc) {
   if (!FV_BOUNDS.MAP) return;
   var sc = map.scene; if (!sc || !sc.field) return;
   var G = fvBoundsGeom(sc), SG = [[-1, -1], [1, -1], [1, 1], [-1, 1]], big = !!map.view, i, k;
   var E0 = map.screen([0, 0, 0], r), sA = G.A ? map.depth(G.zA) : 0, sB = G.B ? map.depth(G.zB) : 0;
   function M(s, a, b) { return map.screen([s, a * 0.30 * s, -b * 0.30 * s * (map.hy / map.hx)], r); }
   function at(key) {
      var c = key[1];
      if (key[0] === "E") return E0;
      if (key[0] === "C") return M(1, SG[c][0], SG[c][1]);
      return map.slabPt(key[0] === "A" ? sA : sB, SG[c][0], SG[c][1], r);
   }
   // el poligono de cada plano en el mapa (las paredes: Tierra y dos esquinas de la boca; las caras: la losa del mapa a su profundidad)
   var poly = [];
   for (k = 0; k < 4; ++k) poly.push([E0, at(["C", k]), at(["C", (k + 1) % 4])]);
   poly.push([at(["C", 0]), at(["C", 1]), at(["C", 2]), at(["C", 3])]);
   poly.push(G.A ? [at(["A", 0]), at(["A", 1]), at(["A", 2]), at(["A", 3])] : null);
   poly.push(G.B ? [at(["B", 0]), at(["B", 1]), at(["B", 2]), at(["B", 3])] : null);
   var st = (P && P.cam) ? fvBoundsState(G, P.cam.pos) : null, wH = st ? st.wHome : 0, col = FV_BOUNDS.EDGE_COL & 0xffffff;
   var keepOp = g.compositionOperator;
   try {
      g.antialiasing = true; g.compositionOperator = CompositionOp_Screen; g.opacity = 1;
      // 1. el plano cercano, iluminado (mismo peso que el velo del vuelo)
      if (st) for (i = 0; i < G.planes.length; ++i) {
         var w = G.planes[i] && poly[i] ? st.w[i] * wH : 0;
         if (w < 0.01) continue;
         var pts = poly[i].map(function(q) { return new Point(q[0], q[1]); });
         g.fillPolygon(pts, new Brush(((Math.round(255 * FV_BOUNDS.MAP_FILL * Math.min(1, w)) << 24) | col) >>> 0));
      }
      // 2. las aristas: oro tenue siempre; las del plano encendido, mas claras y gruesas; fuera del cono, todo el alambre algo mas claro
      var lw = big ? Math.max(1, 0.55 * kc) : 1, out = st ? st.out * wH : 0;
      for (i = 0; i < G.edges.length; ++i) {
         var e = G.edges[i], wE = 0, live = false;
         for (k = 0; k < e.planes.length; ++k) { var pi = e.planes[k]; if (G.planes[pi]) { live = true; if (st) wE = Math.max(wE, st.w[pi] * wH); } }
         if (!live) continue;
         wE = Math.max(wE, 0.5 * out);
         var a = at(e.ka), b = at(e.kb), al = FV_BOUNDS.MAP_EDGE + (1 - FV_BOUNDS.MAP_EDGE) * Math.min(1, wE);
         g.pen = new Pen(((Math.round(255 * al) << 24) | col) >>> 0, lw * (1 + 0.9 * Math.min(1, wE)));
         g.drawLine(a[0], a[1], b[0], b[1]);
      }
   } finally { g.compositionOperator = keepOp; g.opacity = 1; }
}

// ---------------------------------------------------------------------------
// C3 · EL ICONO DE LA NAVE: la silueta en planta de la nave del arranque (blender/nave3d.py, rsc/nave/: proa a la izquierda en el perfil)
// Unidades: proa en +x (x = 1), popa en x = −1; y lateral. EXAGERADO a proposito para leerse a 12–20 px: el disco real (radio 0,67 y
// centro 0,16 en estas unidades, medido sobre f_000.jpg) dejaba asomar solo 0,17 de proa; aqui radio 0,48 y la proa asoma 0,42.
// ---------------------------------------------------------------------------
var FV_BOUNDS_SHIP = {
   // (v2, mirada la hoja: con el disco grande y la cupula oscura se leia como un ojo con cola) el casco claro y largo va ENCIMA del disco y
   // acaba en una proa afilada: la direccion se lee por la punta clara; el disco (laton) y las dos gondolas atras dicen que es nuestra nave
   hull: [[1.0, 0], [0.72, 0.075], [0.40, 0.15], [-0.60, 0.15], [-0.88, 0.11], [-0.92, 0], [-0.88, -0.11], [-0.60, -0.15], [0.40, -0.15], [0.72, -0.075]],
   disc: [-0.05, 0, 0.42],
   nac: [[-0.30, 0], [-0.36, 0.06], [-0.88, 0.06], [-1.02, 0.12], [-1.02, -0.12], [-0.88, -0.06], [-0.36, -0.06]],
   NAC_Y: 0.34
};
// -> true si la ha dibujado (con ICON apagado, false: el pintor de siempre sigue con su flecha)
function fvBoundsShipIcon(g, x, y, ux, uy, S, col) {
   if (!FV_BOUNDS.ICON) return false;
   var k = FV_BOUNDS.ICON_K * S, nx = -uy, ny = ux, D = FV_BOUNDS_SHIP, ink = FV_BOUNDS.ICON_INK, i;
   function pt(p, oy) { var px = p[0], py = p[1] + (oy || 0); return new Point(x + (px * ux + py * nx) * k, y + (px * uy + py * ny) * k); }
   function poly(L, oy) { var o = []; for (var q = 0; q < L.length; ++q) o.push(pt(L[q], oy)); return o; }
   var hull = poly(D.hull), nacs = [poly(D.nac, D.NAC_Y), poly(D.nac, -D.NAC_Y)], dc = pt([D.disc[0], D.disc[1]]), dr = D.disc[2] * k;
   var wInk = Math.max(0.9, 0.18 * S);
   g.antialiasing = true;
   g.fillCircle(x, y, S * 2.0, new RadialGradientBrush(new Point(x, y), S * 2.0, new Point(x, y), [[0, 0x70FFF3C4], [1, 0x00FFF3C4]]));
   // 1. el filo oscuro: todas las piezas trazadas gruesas en tinta (el relleno tapa la mitad de dentro: queda un filo por fuera)
   g.pen = new Pen(ink, 2 * wInk);
   for (i = 0; i < 2; ++i) g.drawPolyline(nacs[i].concat([nacs[i][0]]));
   g.drawCircle(dc.x, dc.y, dr);
   g.drawPolyline(hull.concat([hull[0]]));
   // 2. el laton: gondolas y disco
   for (i = 0; i < 2; ++i) g.fillPolygon(nacs[i], new Brush(FV_BOUNDS.ICON_NAC));
   g.fillCircle(dc.x, dc.y, dr, new Brush(FV_BOUNDS.ICON_DISC));
   // 3. el casco claro encima, con su filo fino (se separa del disco)
   g.pen = new Pen(ink, Math.max(0.8, 1.1 * wInk)); g.drawPolyline(hull.concat([hull[0]]));
   g.fillPolygon(hull, new Brush(col || FV_BOUNDS.ICON_HULL));
   return true;
}
// TABULA, nave fuera de la foto: la silueta junto a la marca del borde, hacia dentro, con su rumbo (o mirando hacia donde esta)
// em = la marca del borde [x, y]; (ex, ey) = donde esta la nave (sin recortar); look = [x, y] de su mirada en el panel | null
function fvBoundsShipEdge(g, em, ex, ey, look, S, panel) {
   if (!FV_BOUNDS.ICON || !em) return;
   var cx = (panel[0] + panel[2]) / 2, cy = (panel[1] + panel[3]) / 2, ix = cx - em[0], iy = cy - em[1], il = Math.sqrt(ix * ix + iy * iy) || 1;
   var x = em[0] + ix / il * S * 2.1, y = em[1] + iy / il * S * 2.1, hx = -ix / il, hy = -iy / il;
   if (look) { var lx = look[0] - ex, ly = look[1] - ey, ll = Math.sqrt(lx * lx + ly * ly); if (ll > 2) { hx = lx / ll; hy = ly / ll; } }
   fvBoundsShipIcon(g, x, y, hx, hy, S * 0.8);
}

// ---------------------------------------------------------------------------
// LA AYUDA (tooltip) DE TABULA Y PROFUNDITAS con las banderas encendidas: claves aparte (con todo apagado, la clave de siempre: nada cambia).
// Lo llama una linea de fv_dialog.js (onStripHover). Textos sobre los de fv_route.js (los que valen hoy), cambiando la flecha por la nave y
// añadiendo los planos dorados.
// ---------------------------------------------------------------------------
function fvBoundsTipKey(base) {
   if (base === "map2d" && FV_BOUNDS.ICON) return "map2d.bi";
   if (base === "map3d" && (FV_BOUNDS.ICON || FV_BOUNDS.MAP)) return "map3d.b" + (FV_BOUNDS.ICON ? "i" : "") + (FV_BOUNDS.MAP ? "m" : "");
   return base;
}
(function() {
   var P3 = { en: "PROFUNDITAS: the field in 3D, depth in log scale — the Earth, the stars at their distance, the nebula slab, ",
              es: "PROFUNDITAS: el campo en 3D, profundidad en escala logarítmica — la Tierra, las estrellas a su distancia, la losa de la nebulosa, " };
   var SHIP = { en: "your ship (its silhouette, pointing where it heads) and its target. ", es: "tu nave (su silueta, apuntando hacia donde va) y su destino. " };
   var SHIP0 = { en: "your ship and its target. ", es: "tu nave y su destino. " };
   var PLANES = { en: "Gold edges = where your photo's 3D ends (the cone from the Earth, its mouth and the two faces of the slab); the plane your ship is close to lights up. ",
                  es: "Aristas doradas = hasta dónde llega el 3D de tu foto (el cono desde la Tierra, su boca y las dos caras de la losa); el plano que tu nave tiene cerca se ilumina. " };
   var END3 = { en: "CLICK = open it large in place of the ship view, to place cameras and adjust their depth (click the little ship window or press Esc to come back).",
                es: "CLIC = abrirla en grande en lugar de la vista de la nave, para poner cámaras y ajustar su profundidad (clic en la ventanita de la nave o Esc para volver)." };
   var add = { en: {}, es: {} };
   ["en", "es"].forEach(function(L) {
      add[L]["tipck.map3d.bi"] = P3[L] + SHIP[L] + END3[L];
      add[L]["tipck.map3d.bm"] = P3[L] + SHIP0[L] + PLANES[L] + END3[L];
      add[L]["tipck.map3d.bim"] = P3[L] + SHIP[L] + PLANES[L] + END3[L];
   });
   add.en["tipck.map2d.bi"] = "TABULA: your photo. Gold outline = what the camera sees · ship silhouette = your ship, pointing where it heads · faint trail = where you have been · red target = where you are going. CLICK = open it large in place of the ship view, to place the cameras of a route (the ship goes to this little window; click it or press Esc to come back).";
   add.es["tipck.map2d.bi"] = "TABULA: tu foto. Contorno dorado = lo que ve la cámara · silueta de la nave = tu nave, apuntando hacia donde va · estela tenue = por dónde has ido · mira roja = adónde vas. CLIC = abrirla en grande en lugar de la vista de la nave, para poner las cámaras de una ruta (la nave pasa a esta ventanita; clic en ella o Esc para volver).";
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
