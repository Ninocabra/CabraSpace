// ============================================================================
// FieldVoyager/src/ui/fv_hud.js — LO QUE VA ENCIMA DE LA ESCENA (F1 3-nov; F2 4-nov-2026)
// ----------------------------------------------------------------------------
// · PLACA DE DATOS (A5): arriba a la izquierda, una placa de esmalte y laton, plegada por defecto («DATOS ▸ medidas · supuestas»);
//   al pulsarla se despliega y dice EN LLANO, EN/ES, que es medido y que supuesto (sustituye la leyenda monoespaciada de F1).
// · FICHA DE ESCANEO (D, §06): cuatro esquinas que convergen (0,4 s), linea de llamada con codo y una ficha de esmalte crema con bisel
//   de laton y remaches: a la izquierda una PORTILLA redonda con el objeto en grande (color exagerado coherente con el de la escena),
//   lineas de barrido, grano y una barra de escaneo que lo va revelando; a la derecha el texto que se escribe solo con las CIFRAS QUE
//   GIRAN antes de fijarse; abajo un SELLO de goma «MEDIDO / DUDOSO / SUPUESTO». Dos niveles: frase y «MÁS ▸».
//   Los textos salen de src/science (fvsStar, fvsStarPhrases, fvsScalePhrases, fvsTravelPhrases), EN o ES.
// · El SOL al «mirar a casa», el rotulo de los saltos («ENGAGE», «PUNCH IT») y el del tour.
// Lo que se puede pulsar se apunta en painter.hits = [{ id, x0, y0, x1, y1 }] (el dialogo lo mira antes de elegir objeto).
// ES5.
// ============================================================================

var FV_HUD_COL = { gold: 0xffE5B53F, goldL: 0xffF3D27E, brass: 0xffC99A3A, brassD: 0xff5E4214, brassH: 0xffE9C97A, text: 0xffFBF2E0, text2: 0xffD0C1A5,
                   ok: 0xff7FB77E, warn: 0xffE5B53F, bad: 0xffE0603F, panel: 0xe0120D09, line: 0xff3D2E1F,
                   ink: 0xff2A1F15, sepia: 0xff5E4214, enamel0: 0xffF4EAD2, enamel1: 0xffE2D2AE, enamel2: 0xffB9A57C,
                   stampOk: 0xff2F6B3A, stampWarn: 0xff9A6A12, stampBad: 0xffA8321E };

function fvEaseOutBack(t) { var c1 = 1.70158, c3 = c1 + 1; t = fvClamp(t, 0, 1); return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }
// (Blender 5b · R5-11) los enteros y las distancias del cockpit en el formato de SU idioma (EN: «6,517 ly»; antes «6 517 ly» con espacio, mientras la losa de PROFUNDITAS
// decia «6,520 ly»); FV_B5B.FMT false = lo de antes
function fvFmtInt(x) { if (typeof FV_B5B !== "undefined" && FV_B5B.FMT && typeof fvNum === "function") return fvNum(Math.round(x), 0); var s = String(Math.round(x)), out = ""; while (s.length > 3) { out = " " + s.substring(s.length - 3) + out; s = s.substring(0, s.length - 3); } return s + out; }
function fvFmtLy(ly) { if (typeof FV_B5B !== "undefined" && FV_B5B.FMT && typeof fvNum === "function") return fvNum(ly, ly >= 100 ? 0 : (ly >= 10 ? 1 : 2)); return (ly >= 100) ? fvFmtInt(ly) : (ly >= 10 ? ly.toFixed(1) : ly.toFixed(2)); }
function fvRgbOf(c) { return { r: (c >>> 16) & 255, g: (c >>> 8) & 255, b: c & 255 }; }
function fvHashF(a, b) { var x = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453; return x - Math.floor(x); }

// ---------------------------------------------------------------------------
// EL CONTENIDO DE LA FICHA (texto ya en el idioma): { title, kind, stamp: { word, src, col }, l1: [frases], l2: [frases], col (estrella) }
// ---------------------------------------------------------------------------
// (3b, 20-nov) EL ROTULO DE UNA ESTRELLA: «Gaia DR3 J…» (o su source_id) y, si la escena la casó con Hipparcos (meta.hip, meta.hipName), su nombre propio
// de la IAU o su Bayer/Flamsteed + «HIP n» («Alcyone · HIP 17702», «η Tau · HIP 17702», «HIP 3»). Lo usan la ficha y el rotulo del diagrama HR.
// FV_HIPD_CARD false (web: ?hip=0) = lo de antes. Esta funcion viaja en el paquete web (ui/fv_hud.js).
var FV_HIPD_CARD = true;
function fvStarTitle(m) {
   if (FV_HIPD_CARD === true && m && m.hip > 0) { var h = "HIP " + m.hip, n = String(m.hipName || ""); return (n && n !== h) ? n + " · " + h : h; }
   return "Gaia DR3 " + (m.sourceId ? m.sourceId : fvDesignation(m.ra, m.dec));
}
function fvStarInfo(scene, i) {
   var S = scene.stars, m = S.meta[i], q = S.q[i];
   if (typeof fvsStar !== "function") return null;
   var inp = { teff: m.teff || NaN, G: S.g[i], ruwe: m.ruwe, name: "" };
   if (q < 2 && m.distPc > 0) inp.rgeo = { pc: m.distPc, lo: m.lo || NaN, hi: m.hi || NaN };
   // (F4b) la extincion en G hasta la estrella (fv_dust.js): luminosidad SIN polvo. Su incertidumbre: NO VERIFICADA (no se lee la
   // desviacion del mapa); se pone un 20 % + 0,05 mag (eleccion nuestra, para que la horquilla no presuma)
   if (m.dust && m.dust.ag > 0) { inp.AG = m.dust.ag; inp.sigmaAG = 0.2 * m.dust.ag + 0.05; }
   return fvsStar(inp);
}
function fvCardContent(scene, sel, lang, exoList) {
   var L = lang || FV_LANG, C = { l1: [], l2: [], kind: sel.kind }, sci = (typeof fvsStarPhrases === "function");
   var year = scene.field.obsYear || (new Date()).getFullYear();
   if (sel.kind === "star") {
      var S = scene.stars, i = sel.i, m = S.meta[i], q = S.q[i], d = S.dEarth[i], o = sci ? fvStarInfo(scene, i) : null, P = o ? fvsStarPhrases(o, L, year) : null;
      C.title = fvStarTitle(m);
      // (F4b) la portilla ensena el color VERDADERO (sin polvo); la frase de abajo dice cuanto mas rojo se ve en la foto
      var dz = m.dust || null;
      C.col = (dz && S.colTrue) ? (S.colTrue[i] >>> 0) : (S.col[i] >>> 0); C.colPhoto = S.col[i] >>> 0; C.dust = dz;
      C.sub = fvTx("card.star", null, L) + " · G " + fvNum(S.g[i], 2, L) + (m.bpRp !== null && m.bpRp !== undefined ? " · BP−RP " + fvNum(m.bpRp, 2, L) : "");
      if (P && P.spt) C.l1.push(fvsCap(P.spt) + (o.clsEstimated ? " · " + fvsT(L, "note.estimated") : ""));
      if (q < 2 && P) {
         C.l1.push(fvsCap(P.dist) + (P.distRange ? " · " + P.distRange : ""));
         if (P.temp) C.l1.push(fvsCap(P.temp));
         C.l1.push(fvCardDustLine(scene, i, L));
         // (F4b) la fecha de la luz con el error de la distancia (horquilla medida; supuesta = ± 50 %)
         var eLy = (m.lo > 0 && m.hi > 0) ? 0.5 * Math.abs(m.hi - m.lo) * FV_LY_PER_PC : 0.5 * d;      // (10) abs: con los extremos al reves la semianchura salia negativa
         if (P.light) C.l1.push(fvLightPhraseErr(d, eLy, L, year) || P.light);
         if (P.lum) C.l2.push(fvsCap(P.lum) + " " + (dz && dz.ag > 0 ? fvTx("card.lumDust", { a: fvNum(dz.ag, 1, L) }, L) : fvTx("card.lumNoDust", null, L)));
         if (P.radius) C.l2.push(fvsCap(P.radius) + (P.radiusOrbit ? "; " + P.radiusOrbit : ""));
         if (P.mass) C.l2.push(fvsCap(P.mass));
         if (P.life) C.l2.push(fvsCap(P.life));
         if (P.hz) C.l2.push(fvsCap(P.hz));
      } else {
         C.l1.push(fvTx("card.assWhy", null, L) + ": ~" + fvNum(d, 0, L) + " " + fvsT(L, "u.ly"));
         if (P && P.temp) C.l1.push(fvsCap(P.temp));
         // (con la distancia supuesta mas alla del mapa, el «al menos» ya no depende de ella: sin la coletilla, que salia dos parentesis seguidos)
         C.l1.push(fvCardDustLine(scene, i, L) + (dz && !dz.beyond && dz.av >= 0.05 ? " " + fvTx("card.dustAss", null, L) : ""));
      }
      var ex = null;
      ex = (typeof fvExoForStar === "function") ? fvExoForStar(scene, i, exoList) : null;     // (F4b) solo un cruce verdadero; nunca una demo
      if (ex) { C.l1.push(fvTx("card.planet", { p: ex.row.pl_name }, L)); C.exoRow = ex.row; }     // (PL-6) la portilla de la estrella enseña su planeta
      // (Blender 5 · H4) un planeta de DEMOSTRACION dibujado sobre esta estrella (objeto «exoplaneta» de la escena que no es un cruce verdadero): la ficha lo dice
      else if (typeof FV_EXO_DEMO_CARD !== "undefined" && FV_EXO_DEMO_CARD && scene.objects) {
         for (var oD = 0; oD < scene.objects.length; ++oD) { var obD = scene.objects[oD]; if (obD && obD.type === "exoplanet" && obD.star === i && obD.planet && obD.match !== "gaia-id" && obD.match !== "position") { C.l1.push(fvTx("b5.demoStar", { p: obD.planet.pl_name || obD.name }, L)); C.demoRow = obD.planet; break; } }
      }
      var fT = function(t) { return (typeof fvsFmtTemp === "function") ? fvsFmtTemp(t, L) : t + " K"; };
      if (dz && m.teff) {
         C.l2.push(fvTx("card.colTrue", { t: fT(m.teff), o: fvNum(m.bpRp, 2, L), c: fvNum(dz.bpRp0, 2, L), e: fvNum(dz.ebr, 2, L) }, L));
         if (dz.hot) C.l2.push(fvTx("card.hot", { t: fT(m.teff) }, L));
         if (m.teffObs && Math.abs(m.teffObs - m.teff) >= 50) C.l2.push(fvTx("card.teffObs", { t: fT(m.teffObs) }, L));
      } else C.l2.push(S.colSrc[i] === 1 ? fvTx("card.colPhoto", null, L) : (m.teff ? fvTx("card.colBB", { t: fT(m.teff) }, L) : ""));
      // (I12/I13) la composicion (una frase en el resumen; los detalles en MÁS) y lo que necesita el panel del espectro XP (fv_hud_xp.js)
      fvCardSciInto(C, scene, i, L, o);
      if (typeof fvsTravelPhrases === "function") { var T = fvsTravelPhrases(d, L); C.l2.push(fvsCap(T.warp)); C.l2.push(fvsCap(T.voyager)); }   // (S4, Nino 4-nov: guiños fuera del todo) sin el factor de improbabilidad
      if (o) for (var n = 0; n < o.notes.length; ++n) { var nt = fvsT(L, "note." + o.notes[n]); if (C.l2.indexOf(nt) < 0) C.l2.push("· " + nt); }
      C.l2.push(fvTx("card.recreation", null, L));
      if (q === 0) C.stamp = { word: fvTx("card.meas", null, L), src: m.src === "cluster-catalog" ? fvTx("card.measSrc.cl", null, L) : (m.src === "bailer-jones" ? fvTx("card.measSrc.bj", null, L) : (m.src === "hipparcos-2007" ? fvTx("card.measSrc.hip", null, L) : fvTx("card.measSrc.plx", null, L))), col: FV_HUD_COL.stampOk };
      else if (q === 1) C.stamp = { word: fvTx("card.doubt", null, L), src: fvTx("card.doubtRuwe", { r: m.ruwe ? fvNum(m.ruwe, 2, L) : "≥ 1,4" }, L), col: FV_HUD_COL.stampWarn };
      else C.stamp = { word: fvTx("card.ass", null, L), src: fvTx("card.assSrc", null, L), col: FV_HUD_COL.stampBad };   // (F4b) corto: no repite la linea 2
   } else {
      var bgH = (typeof fvNebBgHero === "function") ? fvNebBgHero(scene) : -1;      // (N13, FV_OBJ.BG_HERO) sin nebulosa de catalogo, la ficha de la «nebulosa» es la del protagonista dibujado (IC 342), no «Background nebulosity»
      if (bgH >= 0) return fvObjectCardContent(scene, bgH, L);
      var N = scene.nebula;
      // (nota de C) el nombre y el tipo en el idioma de la nave: names[lang] y typeLabel[lang] cuando existen («Nebulosidad de fondo»)
      var Lk = (L === "es") ? "es" : "en", nName = (N.names && N.names[Lk]) || N.name || "Nebula", nType = N.typeLabel && N.typeLabel[Lk];
      C.title = fvObjTitle(nName, N.id, N.name);      // (N3) «SH 2-131  ·  Sh 2-131» -> «Sh 2-131»; con FV_OBJ.NAME_DEDUP false, la expresion de antes
      C.sub = (nType ? nType.charAt(0).toUpperCase() + nType.substring(1) : fvTx("card.neb", null, L)) + " · " + fvNum(N.sizeArcmin, 0, L) + "′";
      var nAlias = (typeof fvObjTitleAlias === "function") ? fvObjTitleAlias(fvObjCanonName(nName, N.id), N.id) : "";      // (N3c) la Sharpless de «IC 1396» ya no va en el titulo: aqui, en la linea pequena
      if (nAlias.length > 0) C.sub += " · " + nAlias;
      if (typeof fvsScalePhrases === "function") {
         var SP = fvsScalePhrases(N.sizeArcmin, N.distLy, L);
         C.l1.push(fvsCap(fvsT(L, "dist", { ly: fvsFmtSig(N.distLy, 3, L), pc: fvsFmtSig(N.distLy / FV_LY_PER_PC, 3, L) })));
         C.l1.push(fvsCap(SP.size)); C.l1.push(fvsCap(SP.solarSystems)); C.l1.push(fvsCap(SP.lightCross));
         C.l2.push(fvLightPhraseErr(N.distLy, (N.distHiLy > 0 && N.distLoLy > 0) ? 0.5 * (N.distHiLy - N.distLoLy) : 0.15 * N.distLy, L, year) || fvsLightPhrase(N.distLy, L, year));
         C.l2.push(fvsCap(SP.sand)); C.l2.push(fvsCap(SP.sandObject));
         if (typeof fvsTravelPhrases === "function") C.l2.push(fvsCap(fvsTravelPhrases(N.distLy, L).warp));
      } else C.l1.push(fvFmtLy(N.distLy) + " ly");
      C.l2.push((N.avFront !== undefined && N.avFront !== null) ? fvTx("card.dustFront", { d: fvNum(N.avToLy, 0, L), a: fvNum(N.avFront, 1, L) }, L) : fvTx("card.dustNo", null, L));
      C.l2.push(fvTx("card.thick", { t: fvNum(N.thickLy, 0, L) }, L));
      if (!N.sizeFromCatalogue) C.l2.push(fvTx("card.sizeNo", null, L));
      C.stamp = N.measured ? { word: fvTx("card.meas", null, L), src: N.distRef, col: FV_HUD_COL.stampOk } : { word: fvTx("card.ass", null, L), src: N.distRef.replace(/^ASSUMED: /, ""), col: FV_HUD_COL.stampBad };
   }
   C.l1 = C.l1.filter(function(x) { return !!x; }); C.l2 = C.l2.filter(function(x) { return !!x; });
   return C;
}
// (I12/I13, 4-nov) los datos de la ficha que no trae la escena: el espectro XP y la composicion. En PixInsight los deja fv_card_sci.js en
// meta.sci (la ficha abierta) o meta.sciField (el paso del campo); en el paquete web vienen en meta.xp / meta.chem. Sin ellos, nada cambia.
//   C.xp (compacto) · C.xpBb (cuerpo negro de la Teff de la ficha, en los puntos del compacto: se calcula UNA vez aqui, nunca al pintar)
//   C.xpMsg (sin espectro: el porque, discreto) · C.xpBusy · C.teff · C.spt · C.chem · una frase en C.l1 · los detalles en C.l2
// (xpWhy / chemWhy «skip»: el paso del campo no la miro; entonces no se dice nada)
function fvCardSciData(m) {
   var s = (m && m.sci) || null, f = (m && m.sciField) || null;
   return { st: s ? s.st : (f ? "done" : "none"), xp: (s && s.xp) || (f && f.xp) || null, chem: (s && s.chem) || (f && f.chem) || null,
            xpWhy: s ? s.xpWhy : (f && !f.xp ? "skip" : ""), chemWhy: s ? s.chemWhy : (f && !f.chem ? (f.chemSearched ? "none" : "skip") : "") };
}
function fvCardSciInto(C, scene, i, L, o) {
   if (typeof fvsXpT !== "function" || typeof fvsChemSummary !== "function") return;
   var S = scene.stars, m = S.meta[i], D = fvCardSciData(m);
   C.teff = m.teff || 0; C.spt = (o && o.spt) ? o.spt : ""; C.xp = D.xp; C.chem = D.chem; C.xpBusy = (D.st === "fetch" && !D.xp);
   if (C.xp) C.xpBb = fvsXpBbCurve(C.xp, C.teff || C.xp.fitT);
   else if (D.st === "fetch") C.xpMsg = fvsXpT(L, "xp.fetch");
   else if (D.st === "done" && D.xpWhy !== "skip") C.xpMsg = (D.xpWhy === "no-network" || D.xpWhy === "offline") ? fvsXpT(L, "xp.off") : (S.g[i] > FVS_XP.GMAX ? fvsXpT(L, "xp.faint", { g: fvNum(S.g[i], 1, L) }) : fvsXpT(L, "xp.none"));
   else if (S.g[i] > FVS_XP.GMAX) C.xpMsg = fvsXpT(L, "xp.faint", { g: fvNum(S.g[i], 1, L) });    // sin pedir nada: Gaia no lo publica
   if (fvCardMetalOn()) fvCardMetalInto(C, m, D, L);
   else if (C.chem) { C.l1.push(fvsChemSummary(C.chem, L)); var dl = fvsChemDetails(C.chem, L); for (var k = 0; k < dl.length; ++k) C.l2.push(dl[k]); }
   else if (D.st === "fetch" || (D.st === "done" && D.chemWhy !== "skip")) C.l2.push(fvsChemDetails(null, L, D.st === "fetch" ? "fetch" : ((D.chemWhy === "no-network" || D.chemWhy === "offline") ? "off" : ""))[0]);
   if (C.xp && C.xp.fitT && C.teff && Math.abs(C.xp.fitT - C.teff) / C.teff > 0.03) C.l2.push(fvsXpT(L, "xp.fit", { t: (typeof fvsFmtTemp === "function") ? fvsFmtTemp(C.xp.fitT, L) : C.xp.fitT + " K" }));
}
// (METALICIDAD, 5-nov, Nino: «en el resumen algo de su metalicidad si es posible, y en la ficha extendida algo mas»; FV_METAL.ON en
// src/science/fv_sci_metal.js) UNA linea corta en el resumen, en el color de su fiabilidad (C.metalLine, C.metalQ: 0 MEDIDO, 1 DUDOSO),
// que SUSTITUYE a la frase de composicion de I13 (decia lo mismo, mas largo); en MÁS la comparacion con el Sol y, sin espectro, el valor
// fotometrico con su fuente; debajo, las lineas de I13 ([Fe/H] ± error y fuente, [α/Fe], edad, poblacion, fuentes) como antes.
// El registro: sci.metal (la ficha o la precarga), sciField.metal (el paso del campo) o, sin nada pedido aun, el GSP-Phot del refinado.
// Sin dato: ni linea ni hueco.
function fvCardMetalOn() { return typeof FV_METAL !== "undefined" && FV_METAL.ON === true && typeof fvsMetalBuild === "function"; }
function fvCardMetal(m, D) {
   var s = (m && m.sci) || null, f = (m && m.sciField) || null;
   if (s && s.metal) return s.metal;
   if (f && f.metal) return f.metal;
   var ph = (m && m.mhPhot !== null && m.mhPhot !== undefined && isFinite(m.mhPhot) && isFinite(m.mhPhotT)) ? { v: m.mhPhot, teff: m.mhPhotT } : null;
   return fvsMetalBuild(D.chem, ph, m ? m.teff : undefined);
}
function fvCardMetalInto(C, m, D, L) {
   var M = fvCardMetal(m, D), k;
   if (M) {
      C.metal = M; C.metalQ = M.q; C.metalLine = fvsMetalSummary(M, L); C.l1.push(C.metalLine);
      var ml = fvsMetalDetails(M, L); for (k = 0; k < ml.length; ++k) C.l2.push(ml[k]);
   }
   // (estrella caliente con GSP-Spec: las lineas de I13 —poblacion, edad— se callan; las de la metalicidad ya dicen por que no vale)
   if (C.chem) { if (!(M && M.why === "hot")) { var dl = fvsChemDetails(C.chem, L); for (k = 0; k < dl.length; ++k) C.l2.push(dl[k]); } }
   else if (D.st === "fetch" || (D.st === "done" && D.chemWhy !== "skip")) {
      var st = D.st === "fetch" ? "fetch" : ((D.chemWhy === "no-network" || D.chemWhy === "offline") ? "off" : "");
      if (!(M && st === "")) C.l2.push(fvsChemDetails(null, L, st)[0]);     // con el GSP-Phot a la vista, «sin datos de composicion» sobra
   }
}
// el color de la linea del resumen: el del sello (MEDIDO verde, DUDOSO ambar)
function fvCardMetalCol(C, K) { return K.stamp(C.metalQ === 0 ? FV_HUD_COL.stampOk : FV_HUD_COL.stampWarn); }
// (N1/N8) la ficha de un objeto singular de C: fvObjectCard(scene, i, lang) si existe; si no, una ficha minima con lo que trae el objeto
function fvObjectCardContent(scene, i, L) {
   var C = null;
   if (typeof fvObjectCard === "function") { try { C = fvObjectCard(scene, i, L); } catch (e) { C = null; } }
   if (!C) {
      var o = scene.objects[i], tl = o.typeLabel ? (o.typeLabel[L === "es" ? "es" : "en"] || o.type) : o.type;
      C = { title: (o.names && o.names[L === "es" ? "es" : "en"]) || o.name || o.id, sub: String(tl).toUpperCase(), l1: [], l2: [], stamp: null };
      if (o.distLy > 0) C.l1.push((L === "es" ? "A " : "At ") + fvNum(o.distLy, 0, L) + " " + fvTx("nav.ly", null, L) + (o.distErrLy > 0 ? " (± " + fvNum(o.distErrLy, 0, L) + ")" : ""));
      var meas = (o.distSrc === "measured");
      C.stamp = { word: fvTx(meas ? "card.meas" : "card.ass", null, L), src: o.src || "", col: meas ? FV_HUD_COL.stampOk : FV_HUD_COL.stampBad };
   }
   C.kind = "object"; C.l1 = (C.l1 || []).filter(function(x) { return !!x; }); C.l2 = (C.l2 || []).filter(function(x) { return !!x; });
   if (!C.stamp) C.stamp = { word: "", src: "", col: FV_HUD_COL.stampWarn };
   return C;
}
// (F4b) «la luz salio hacia el …, ± …» con la efemeride que el margen permite (fv_epoch.js); null = usar la de src/science
function fvLightPhraseErr(dLy, errLy, L, year) {
   if (typeof fvLightEpochErr !== "function") return null;
   var e = fvLightEpochErr(dLy, errLy, year);
   if (e.mode !== "year" || !e.event) return null;
   var lk = (L === "es") ? "es" : "en", ey = e.event.approx ? fvsT(L, "year.c", { y: fvsFmtYear(e.event.year, L) }) : fvsFmtYear(e.event.year, L);
   var p = { y: fvsFmtYear(e.yearHist, L), m: fvsFmtNum(e.margin, 0, L), e: e.event[lk], ey: ey, n: fvsFmtNum(e.gap, 0, L) };
   return fvTx("lightE." + e.rel, p, L);
}
// (F4b) la frase del polvo de una estrella: cuanto mas roja se ve en la foto, o por que no se corrigio
function fvCardDustLine(scene, i, L) {
   var S = scene.stars, m = S.meta[i], dz = m.dust;
   if (dz) {
      if (!(dz.av >= 0.05)) return fvTx("card.dustLittle", { a: fvNum(dz.av, 2, L) }, L);
      return dz.beyond ? fvTx("card.dustRedMin", { a: fvNum(dz.av, 1, L), d: fvNum((scene.dust && scene.dust.maxLy) || 4077, 0, L) }, L) : fvTx("card.dustRed", { a: fvNum(dz.av, 1, L) }, L);
   }
   if (m.outside) return fvTx("card.dustOut", null, L);
   return fvTx(scene.dust ? "card.dustCell" : "card.dustNone", null, L);
}
// (F1, para el registro de las pruebas) el texto plano de la ficha
function fvCardLines(scene, sel) { var C = fvCardContent(scene, sel, FV_LANG); return [C.title, C.sub].concat(C.l1).concat(["[" + C.stamp.word + " · " + C.stamp.src + "]"]).map(function(s) { return [s]; }); }

// ---------------------------------------------------------------------------
// (pasada N, N7) TODO lo de encima de la escena esta dibujado para un lienzo de 1280 de ancho y se ESCALA con k = W/1280: la ficha, la
// placa DATOS, los rotulos y el transito son proporcionales a la foto. Las zonas que se pulsan (painter.hits), cardRect y legendRect
// salen en pixeles del fotograma. Con W = 1280 (las pruebas de antes) no cambia nada.
var FV_HUD_REF = 1280;
function fvHudK(W) { return fvClamp(W / FV_HUD_REF, 0.62, 4); }
// (Blender 5b · R5-3) el proyector en unidades del HUD (pixeles reales / k): lo usan el HUD y fvNmPaint (para saber, EN ESTE fotograma, donde caen el disco del
// transito y la escuadra de seleccion antes de poner el rotulo DESTINO)
function fvHudScaledPr(pr, k) {
   if (Math.abs(k - 1) <= 1e-6) return pr;
   return { f: pr.f / k, cx: pr.cx / k, cy: pr.cy / k, W: pr.W / k, H: pr.H / k, B: pr.B, pos: pr.pos, r: pr.r, d: pr.d, fw: pr.fw,
            project: function(p, near) { var q = pr.project(p, near); return q ? [q[0] / k, q[1] / k, q[2]] : null; } };
}
function fvHudPaint(g, painter, pr, P, W, H, o) {
   g.antialiasing = true; g.textAntialiasing = true;
   // (PL-20, 10-nov) el HUD empieza SIEMPRE con el pincel vacio: en PJSR drawRect/drawCircle/drawPolygon RELLENAN con el pincel en curso, y en
   // modo Espacio fvNmPaint (rotulo y brujula) dejaba g.brush = tinta al 78 %. Cada filete del HUD tapaba lo de debajo: el panel del transito a
   // ×0,25, el disco del transito sobre la estrella y la portilla de la ficha vacios (sonda tests/pl20_probe.js: media del panel 47 -> 184 sin
   // fvNmPaint). En Foto fvNmPaint no pinta (salvo la nota de profundidad, que tambien dejaba su pincel) y el video (fv_rec.js) usa un
   // Graphics nuevo: ahora todos los caminos llegan al HUD con el mismo estado.
   // (Blender 4 · PL-20b) y lo que se pinte DESPUES del HUD (fvLabUiPaint, con FV_LAB.ON) recibe el pincel y la pluma con que llego: el
   // laboratorio los deja a proposito al final de fvNmPaint (sonda lab_pi_gold.js, 8-nov) y PL-20 se los quitaba (solo con FV_LAB.ON)
   var brIn = g.brush, penIn = g.pen;
   g.brush = new Brush(0x00000000); g.opacity = 1; g.compositionOperator = CompositionOp_SourceOver;
   painter.hits = []; painter.legendRect = null; painter.cardRect = null; painter.statusRect = null; painter.noticeTop = null; painter.tourRect = null; painter.exoOnStar = null; painter.legendBox = null;   // (Blender 4) la zona del disco del transito (fvExoOnStar) para el fotograma siguiente de fvNmPaint
   var ui = o.ui || {}, k = fvHudK(W), M0 = null, pk = pr;
   painter.hudK = k;
   if (Math.abs(k - 1) > 1e-6) {
      M0 = g.transformationMatrix; g.scaleTransformation(k, k);
      pk = fvHudScaledPr(pr, k);
      W = W / k; H = H / k;
   }
   try {
      if (P.sunMark) fvSunPaint(g, painter, pk, P, W, H, ui);
      if (P.sel) fvCardPaint(g, painter, pk, P, W, H, ui);
      if (o.legend !== false) fvLegendPaint(g, painter, P, W, H, ui);
      if (ui.caption) fvCaptionPaint(g, P, W, H, ui, painter);
      if (ui.exo && typeof fvExoPanelPaint === "function") fvExoPanelPaint(g, painter, P, W, H, ui, pk);
      if (ui.notice) fvNoticePaint(g, painter, W, H, ui.notice);
      if (ui.e1qHud && typeof fvE1qHudPaint === "function") fvE1qHudPaint(g, painter, W, H, ui.e1qHud);        // (20-nov, I4; E1-01) la respuesta de QUAESTIO en la cabina
      if (ui.tourBar) fvTourBarPaint(g, painter, W, H, ui);           // (12-nov, R7) la barra del TOUR: siempre abajo en el centro (encima del aviso, si lo hay)
   } finally { if (M0) g.transformationMatrix = M0; }
   if (M0) {
      var hs = painter.hits;
      for (var i = 0; i < hs.length; ++i) { hs[i].x0 *= k; hs[i].y0 *= k; hs[i].x1 *= k; hs[i].y1 *= k; }
      if (painter.cardRect) painter.cardRect = painter.cardRect.map(function(v) { return v * k; });
      if (painter.legendRect) painter.legendRect = painter.legendRect.map(function(v) { return v * k; });
      if (painter.legendBox) painter.legendBox = painter.legendBox.map(function(v) { return v * k; });
      if (painter.statusRect) painter.statusRect = painter.statusRect.map(function(v) { return v * k; });
      if (painter.tourRect) painter.tourRect = painter.tourRect.map(function(v) { return v * k; });
   }
   if (P && P.lab && typeof FV_LAB !== "undefined" && FV_LAB.ON === true) { g.brush = brIn; g.pen = penIn; }   // solo con el laboratorio (fvFramePaint y demas, como tras PL-20)
}

// ---- (F4b) LA PLACA DE AVISO: vuelo exportado, video grabado o renderizandose (con su barra). Siempre abajo, en el centro: la
// barra de progreso no cambia de sitio (§11.3). n = { title, path, lines[], progress (0…1 | null), buttons: ["openDir", "changeDir"] }
function fvElideMid(f, s, maxW) {
   s = String(s); if (f.width(s) <= maxW) return s;
   var a = Math.floor(s.length / 2), b = a;
   while (a > 4 && f.width(s.substring(0, a) + "…" + s.substring(b)) > maxW) { --a; ++b; }
   return s.substring(0, a) + "…" + s.substring(b);
}
function fvNoticePaint(g, painter, W, H, n) {
   var L = FV_LANG, fT = cpFont("display", 14, false, false, 2), fB = cpFont("text", 12), fP = cpFont("mono", 11), fBt = cpFont("display", 11, false, false, 2);
   var w = Math.min(W - 80, 760), lines = n.lines || [], hasP = (n.progress !== undefined && n.progress !== null), btn = n.buttons || [];
   var h = 42 + (n.path ? 18 : 0) + lines.length * 17 + (hasP ? 24 : 0) + (btn.length ? 32 : 0) + 6;
   var x0 = Math.round((W - w) / 2), y1 = H - 20, y0 = y1 - h;
   painter.noticeTop = y0;                                           // (12-nov, R7) la barra del tour se pone encima
   fvEnamelPanel(g, x0, y0, x0 + w, y1, true);
   g.font = fT; g.pen = new Pen(FV_HUD_COL.ink); g.drawText(x0 + 22, y0 + 27, cpElide(fT, n.title || "", w - 70));
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawLine(x0 + 18, y0 + 34, x0 + w - 18, y0 + 34);
   var y = y0 + 52;
   if (n.path) { g.font = fP; g.pen = new Pen(FV_HUD_COL.sepia); g.drawText(x0 + 22, y, fvElideMid(fP, n.path, w - 44)); y += 18; }
   g.font = fB; g.pen = new Pen(FV_HUD_COL.ink);
   for (var i = 0; i < lines.length; ++i) { g.drawText(x0 + 22, y, cpElide(fB, lines[i], w - 44)); y += 17; }
   if (hasP) {
      var bx0 = x0 + 22, bx1 = x0 + w - 22, by = y - 6, fr = fvClamp(n.progress, 0, 1);
      g.fillRect(bx0, by, bx1, by + 9, new Brush(0xff2A1F15));
      if (fr > 0) g.fillRect(bx0 + 1, by + 1, bx0 + 1 + (bx1 - bx0 - 2) * fr, by + 8, new LinearGradientBrush(new Point(bx0, by), new Point(bx0, by + 9), [[0, 0xffF3D27E], [1, 0xffB8862E]]));
      g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawRect(bx0 + 0.5, by + 0.5, bx1 - 0.5, by + 8.5);
      y += 24;
   }
   painter.hits.push({ id: "notice", x0: x0, y0: y0, x1: x0 + w, y1: y1 });
   if (btn.length) {
      var bx = x0 + w - 18;
      for (var b = btn.length - 1; b >= 0; --b) {
         var lab = fvTx("nb." + btn[b], null, L); g.font = fBt; var bw = fBt.width(lab) + 22, bxa = bx - bw, bya = y1 - 34, byb = y1 - 12;
         g.fillRect(bxa, bya, bx, byb, fvBrassBrush((bxa + bx) / 2, (bya + byb) / 2, bw / 2));
         g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawRect(bxa + 0.5, bya + 0.5, bx - 0.5, byb - 0.5);
         g.pen = new Pen(FV_HUD_COL.ink); g.drawText(bxa + 11, byb - 7, lab);
         painter.hits.unshift({ id: "notice-" + btn[b], x0: bxa, y0: bya, x1: bx, y1: byb });
         bx = bxa - 10;
      }
   }
   if (!hasP) {
      var cx = x0 + w - 22, cy = y0 + 20;
      g.pen = new Pen(FV_HUD_COL.brassD, 1.6); g.drawLine(cx - 5, cy - 5, cx + 5, cy + 5); g.drawLine(cx - 5, cy + 5, cx + 5, cy - 5);
      painter.hits.unshift({ id: "notice-close", x0: cx - 10, y0: cy - 10, x1: cx + 10, y1: cy + 10 });
   }
}

// ---- la placa de datos ----
function fvEnamelPanel(g, x0, y0, x1, y1, rivets) {
   if (fvFine()) {
      // (E6) la lamina crema se queda (es el papel de la ficha) pero con el marco de grabado: filete de laton de 1 px, filete interior
      // sepia a 4,5 px, esquinas de cuarto de circulo y un punto; sin el marco de 3 px ni los remaches en relieve
      g.fillRect(x0, y0, x1, y1, new LinearGradientBrush(new Point(x0, y0), new Point(x1, y1), [[0, FV_HUD_COL.enamel0], [1, FV_HUD_COL.enamel1]]));
      g.pen = new Pen(FV_HUD_COL.brass, 1.2); g.drawRect(x0 + 0.6, y0 + 0.6, x1 - 0.6, y1 - 0.6);
      g.pen = new Pen(0xa05E4214, 0.6); g.drawRect(x0 + 4.5, y0 + 4.5, x1 - 4.5, y1 - 4.5);
      if (rivets && y1 - y0 > 40) {
         var C = [[x0 + 4.5, y0 + 4.5, 1, 1], [x1 - 4.5, y0 + 4.5, -1, 1], [x1 - 4.5, y1 - 4.5, -1, -1], [x0 + 4.5, y1 - 4.5, 1, -1]];
         g.pen = new Pen(0xb05E4214, 0.6);
         for (var i = 0; i < 4; ++i) {
            var x = C[i][0], y = C[i][1], sx = C[i][2], sy = C[i][3], pts = [];
            for (var k = 0; k <= 8; ++k) { var b = (Math.PI / 2) * k / 8; pts.push(new Point(x + sx * 9 * Math.sin(b), y + sy * 9 * Math.cos(b))); }
            g.drawPolyline(pts); g.fillCircle(x + sx * 3.2, y + sy * 3.2, 1, new Brush(0xc05E4214));
         }
      }
      return;
   }
   g.fillRect(x0, y0, x1, y1, new LinearGradientBrush(new Point(x0, y0), new Point(x1, y1), [[0, FV_HUD_COL.enamel0], [0.7, FV_HUD_COL.enamel1], [1, FV_HUD_COL.enamel2]]));
   g.pen = new Pen(FV_HUD_COL.brass, 3); g.drawRect(x0 + 1.5, y0 + 1.5, x1 - 1.5, y1 - 1.5);
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawRect(x0 + 4.5, y0 + 4.5, x1 - 4.5, y1 - 4.5);
   if (rivets) { fvRivet(g, x0 + 9, y0 + 9, 2.4); fvRivet(g, x1 - 9, y0 + 9, 2.4); fvRivet(g, x0 + 9, y1 - 9, 2.4); fvRivet(g, x1 - 9, y1 - 9, 2.4); }
}
function fvLegendPaint(g, painter, P, W, H, ui) {
   var sc = painter.scene, F = sc.facts || { counts: [0, 0, 0], refine: "", engine: "" }, N = sc.nebula, L = FV_LANG, open = !!ui.legendOpen;
   var x0 = 22, y0 = 18, fT = cpFont("display", 11, false, false, 2), fS = cpFont("mono", 10);
   var tab = (open ? "▾ " : "▸ ") + fvTx(open ? "leg.tabOpen" : "leg.tab", null, L);
   var summ = open ? "" : "   " + fvTx("leg.stars", { m: fvNum(F.counts[0], 0, L), d: fvNum(F.counts[1], 0, L), a: fvNum(F.counts[2], 0, L) }, L);
   g.font = fT; var wT = fT.width(tab); g.font = fS; var wS = summ ? fS.width(summ) : 0;
   if (!open) {
      var x1 = x0 + 22 + wT + wS + 12, y1 = y0 + 24;
      g.fillRect(x0, y0, x1, y1, new Brush(0xd0110D09));
      g.pen = new Pen(FV_HUD_COL.brass, fvFine() ? 1 : 1.2); g.drawRect(x0 + 0.5, y0 + 0.5, x1 - 0.5, y1 - 0.5);
      if (fvFine()) { g.pen = new Pen(0x70C99A3A, 0.6); g.drawRect(x0 + 3.5, y0 + 3.5, x1 - 3.5, y1 - 3.5); g.fillCircle(x0 + 9, y0 + 12, 1.4, new Brush(FV_HUD_COL.gold)); }
      else fvRivet(g, x0 + 8, y0 + 12, 2.2);
      g.font = fT; g.pen = new Pen(FV_HUD_COL.gold); g.drawText(x0 + 16, y0 + 16, tab);
      g.font = fS; g.pen = new Pen(FV_HUD_COL.text2); g.drawText(x0 + 16 + wT, y0 + 16, summ);
      painter.hits.push({ id: "legend", x0: x0, y0: y0, x1: x1, y1: y1 });
      painter.legendBox = [x0, y0, x1, y1];      // (Blender 4) la placa plegada (legendRect queda solo para la abierta, como antes)
      return;
   }
   var w = 520, fB = cpFont("text", 12), lines = [], i;
   var nebHow = N ? (N.measured ? fvTx("leg.nebMeas", { ref: N.distRef }, L) : fvTx("leg.nebAss", { ref: String(N.distRef).replace(/^ASSUMED: /, "") }, L)) : "";
   var paras = [[fvTx("leg.stars", { m: fvNum(F.counts[0], 0, L), d: fvNum(F.counts[1], 0, L), a: fvNum(F.counts[2], 0, L) }, L), FV_HUD_COL.ink],
                [fvTx("leg.starsAss", null, L), FV_HUD_COL.sepia]];
   if (F.refine === "failed") paras.push([fvTx("leg.ruweNo", null, L), FV_HUD_COL.stampWarn]);
   else if (F.refine === "offline") paras.push([fvTx("leg.ruweOff", null, L), FV_HUD_COL.stampWarn]);
   if (N) { paras.push([fvTx("leg.neb", { n: (N.names && N.names[(L === "es") ? "es" : "en"]) || N.name, d: fvNum(N.distLy, 0, L), how: nebHow }, L), N.measured ? FV_HUD_COL.stampOk : FV_HUD_COL.stampBad]); paras.push([fvTx("leg.thick", null, L), FV_HUD_COL.stampWarn]); }
   paras.push([fvTx("leg.removal", { how: F.engine }, L), FV_HUD_COL.sepia]);
   // (F4b) el polvo (color verdadero) y la Via Lactea de fondo SIMULADA (con su interruptor: un clic en el parrafo)
   var Fd = F.dust || { n: 0, map: false };
   paras.push([Fd.map ? fvTx("leg.dust", { n: fvNum(Fd.n, 0, L), d: fvNum(Fd.maxLy || 4077, 0, L) }, L) : fvTx("leg.dustNo", null, L), Fd.map ? FV_HUD_COL.stampOk : FV_HUD_COL.stampWarn]);
   var mwI = -1;
   if (sc.galaxy) { mwI = paras.length; paras.push([fvTx(painter.mwOn ? "leg.mw" : "leg.mwOff", null, L), FV_HUD_COL.stampBad]); }
   var fgTx = (typeof fvFgLegend === "function") ? fvFgLegend(L) : null; if (fgTx) paras.push([fgTx, FV_HUD_COL.stampOk]);   // (Blender 2) la ventana (solo con FV_FG.ON): ultimo parrafo, clic = cambiar
   g.font = fB;
   var mwL0 = -1, mwL1 = -1;
   for (i = 0; i < paras.length; ++i) { var wr = fvWrap(fB, paras[i][0], w - 36); if (i === mwI) mwL0 = lines.length; for (var j = 0; j < wr.length; ++j) lines.push([wr[j], paras[i][1], j === 0 && i > 0]); if (i === mwI) mwL1 = lines.length; }
   var h = 40 + lines.length * 16 + 6;
   fvEnamelPanel(g, x0, y0, x0 + w, y0 + h, true);
   g.font = fT; g.pen = new Pen(FV_HUD_COL.sepia); g.drawText(x0 + 18, y0 + 22, tab);
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawLine(x0 + 18, y0 + 28, x0 + w - 18, y0 + 28);
   g.font = fB;
   for (i = 0; i < lines.length; ++i) { g.pen = new Pen(lines[i][1]); g.drawText(x0 + 18, y0 + 46 + i * 16, lines[i][0]); }
   painter.hits.push({ id: "legend", x0: x0, y0: y0, x1: x0 + w, y1: y0 + 30 });
   if (mwL0 >= 0) {
      // el interruptor de la Via Lactea: un piloto (lleno = encendida) delante de su parrafo, y el parrafo entero se puede pulsar
      var my0 = y0 + 46 + mwL0 * 16 - 12, my1 = y0 + 46 + (mwL1 - 1) * 16 + 5;
      g.pen = new Pen(FV_HUD_COL.stampBad, 1.2); g.drawCircle(x0 + 10, my0 + 7, 3.6);
      if (painter.mwOn) g.fillCircle(x0 + 10, my0 + 7, 2.2, new Brush(FV_HUD_COL.stampBad));
      painter.hits.push({ id: "mw-toggle", x0: x0 + 4, y0: my0, x1: x0 + w - 4, y1: my1 });
   }
   if (fgTx) { var fgN = fvWrap(fB, fgTx, w - 36).length, fy0 = y0 + 46 + (lines.length - fgN) * 16 - 12; painter.hits.push({ id: "fg-toggle", x0: x0 + 4, y0: fy0, x1: x0 + w - 4, y1: y0 + 46 + (lines.length - 1) * 16 + 5 }); }   // (Blender 2)
   painter.legendRect = [x0, y0, x0 + w, y0 + h];             // la placa entera (el clic solo en la cabecera)
   painter.legendBox = painter.legendRect;
}

// ---- el rotulo de los saltos y del tour ----
// (E10, Nino 4-nov: «elimina el "Make it so" y otras frases que aparecen en medio de la imagen, menos en el caso del Tour»)
// · ENGAGE / MAKE IT SO / PUNCH IT (adorno, sin dato) ya no se pintan.
// · Lo informativo (elige un objeto primero, estas en casa, vuelo exportado, la ruta…) va a la LINEA DE ESTADO de arriba a la derecha:
//   versalitas pequeñas sobre una banda oscura con filete, fuera del centro y por encima de la ficha (que empieza en y = 58).
// · Solo el TOUR (y la ruta ITINERARIUM, S5) sigue en el centro. El rotulo del tour se reconoce por c.tour o por el comienzo de «cap.tour» («TOUR »), sin tocar el dialogo.
// FV_E10_NO_CENTER_PHRASES = false vuelve al rotulo centrado de antes para todo (el ROJO de fv_nE2_test).
var FV_E10_NO_CENTER_PHRASES = true;
// (E6) el estilo fino (FV_E6_FINE vive en fv_buttons.js; sin el, fino)
function fvFine() { return (typeof FV_E6_FINE === "undefined") ? true : !!FV_E6_FINE; }
// (S5, Nino 4-nov) los rotulos de la ruta ITINERARIUM («RUTA · CÁMARA 2 / 5», «RUTA COMPLETA») van al centro como los del tour
var FV_CENTRE_CAPTIONS = ["cap.tour", "rt.flying", "rt.done"];
function fvCaptionIsTour(c) {
   if (!c) return false;
   if (c.tour === true) return true;
   var s = String(c.text || ""), langs = ["en", "es"];
   for (var k = 0; k < FV_CENTRE_CAPTIONS.length; ++k)
      for (var i = 0; i < langs.length; ++i) { var tp = FV_TX[langs[i]] && FV_TX[langs[i]][FV_CENTRE_CAPTIONS[k]]; if (tp) { var pre = tp.split("{")[0]; if (pre.length >= 3 && s.indexOf(pre) === 0) return true; } }
   return false;
}
function fvCaptionIsFlourish(c) {
   var s = String(c && c.text || ""), keys = ["cap.engage", "cap.makeitso", "cap.punch"], langs = ["en", "es"];
   for (var i = 0; i < keys.length; ++i) for (var j = 0; j < langs.length; ++j) if (FV_TX[langs[j]] && FV_TX[langs[j]][keys[i]] === s) return true;
   return false;
}
// la linea de estado (arriba a la derecha): -> [x0, y0, x1, y1] de lo pintado (para las pruebas)
function fvStatusLinePaint(g, W, H, text, a, painter) {
   var f = cpFont("display", 11, false, false, 3), s = String(text), xr = W - 30, y = 38;
   g.font = f; s = cpElide(f, s, Math.min(620, W * 0.45)); var w = f.width(s), x = xr - w;
   g.fillRect(x - 14, y - 17, xr + 12, y + 9, new Brush(((Math.round(200 * a) << 24) | 0x0D0A07) >>> 0));
   g.pen = new Pen(((Math.round(230 * a) << 24) | 0xC99A3A) >>> 0, 1); g.drawLine(x - 14, y + 8.5, xr + 12, y + 8.5);
   g.pen = new Pen(((Math.round(140 * a) << 24) | 0xC99A3A) >>> 0, 0.6); g.drawLine(x - 14, y - 16.5, xr + 12, y - 16.5);
   g.fillCircle(x - 7, y - 4, 1.6, new Brush(((Math.round(255 * a) << 24) | 0xE5B53F) >>> 0));
   g.pen = new Pen(((Math.round(255 * a) << 24) | 0xF4ECDC) >>> 0); g.drawText(x, y, s);
   if (painter) painter.statusRect = [x - 14, y - 17, xr + 12, y + 9];
}
function fvCaptionPaint(g, P, W, H, ui, painter) {
   var c = ui.caption, t = P.t - c.t0, dur = c.dur || 1.6;
   if (t < 0 || t > dur) return;
   if (FV_E10_NO_CENTER_PHRASES && !fvCaptionIsTour(c)) {
      if (fvCaptionIsFlourish(c)) return;
      fvStatusLinePaint(g, W, H, c.text, fvSmooth(t / 0.25) * (1 - fvSmooth((t - dur + 0.5) / 0.5)), painter);
      return;
   }
   var a = fvSmooth(t / 0.25) * (1 - fvSmooth((t - dur + 0.5) / 0.5)), f = cpFont("display", fvFine() ? 26 : 30, false, false, 9), s = c.text;
   g.font = f; var w = f.width(s), x = (W - w) / 2, y = H * 0.16;
   // con la placa DATA abierta, el rotulo baja por debajo de ella (chocaban: f2_placa_datos.png del 4-nov)
   var lr = painter && painter.legendRect;
   if (lr && lr[2] + 16 > x && lr[3] + 34 > y) y = lr[3] + 44;
   if (fvFine()) {
      // (E6) marfil, sin negrita, con una sombra suave solo para que se lea sobre la nebulosa, y un filete con rombo debajo
      g.pen = new Pen((((Math.round(120 * a)) << 24) | 0x000000) >>> 0); g.drawText(x + 1, y + 1, s);
      g.pen = new Pen((((Math.round(255 * a)) << 24) | 0xF4ECDC) >>> 0); g.drawText(x, y, s);
      if (typeof fvOrnRule === "function") fvOrnRule(g, W / 2 - Math.min(w / 2, 160), W / 2 + Math.min(w / 2, 160), y + 14, (((Math.round(220 * a)) << 24) | 0xC99A3A) >>> 0);
   } else {
      g.pen = new Pen((((Math.round(170 * a)) << 24) | 0x000000) >>> 0); g.drawText(x + 2, y + 2, s);
      g.pen = new Pen((((Math.round(255 * a)) << 24) | 0xF3D27E) >>> 0); g.drawText(x, y, s);
   }
   if (c.sub) { var f2 = cpFont("display", 13, false, true, 2); g.font = f2; var w2 = f2.width(c.sub); g.pen = new Pen((((Math.round(230 * a)) << 24) | 0xFBF2E0) >>> 0); g.drawText((W - w2) / 2, y + 30, c.sub); }
}

// ---- (12-nov, R7) LA BARRA DEL TOUR ----
// Nino: «el Tour es raro: se queda mucho tiempo en cada estrella y no se sabe si sigue haciendo el tour o se ha colgado». Mientras haya tour (ui.tourBar,
// lo rellena fv_dialog.js tourBarSync) hay SIEMPRE una banda abajo en el centro (§11.3: la barra de progreso en el mismo sitio; sin desplazar la foto, es
// un rotulo encima, como la placa de avisos): «TOUR 3 / 5» + lo que pasa («EN RUTA», «ESCANEANDO», «SIGUIENTE PARADA EN 4 s», «EN ESPERA MIENTRAS LEES»,
// «EN PAUSA») + una barra (cuenta atras; en vuelo y al escanear, un tramo dorado que se desliza: se ve que sigue vivo) + los tres mandos del tour:
// anterior, pausa / sigue y siguiente (tambien las teclas , B .). Parar el tour sigue siendo el boton TOUR / la tecla T (no se duplica aqui).
// Se pone encima del aviso de la placa (REC, exportar) si lo hay y, si la ficha cae en su sitio, se aparta al lado libre. Zonas pulsables:
// tour-prev, tour-pause, tour-next (y tour-bar, que se come el clic para no elegir objetos de detras).
function fvTourGlyph(g, kind, cx, cy, col) {
   var br = new Brush(col);
   if (kind === "prev" || kind === "next") {
      var d = (kind === "next") ? 1 : -1;
      g.fillRect(cx + d * 6, cy - 6, cx + d * 8, cy + 6, br);
      g.fillPolygon([new Point(cx - d * 7, cy - 6.5), new Point(cx + d * 3, cy), new Point(cx - d * 7, cy + 6.5)], br);
   } else if (kind === "pause") {
      g.fillRect(cx - 5, cy - 6.5, cx - 1.5, cy + 6.5, br); g.fillRect(cx + 1.5, cy - 6.5, cx + 5, cy + 6.5, br);
   } else {            // play
      g.fillPolygon([new Point(cx - 4, cy - 7.5), new Point(cx + 7, cy), new Point(cx - 4, cy + 7.5)], br);
   }
}
function fvTourBarPaint(g, painter, W, H, ui) {
   var B = ui.tourBar, L = FV_LANG, hov = ui.hover;
   if (!B) return;
   var w = Math.min(W - 60, 460), h = 50, x0 = Math.round((W - w) / 2), y1 = (painter.noticeTop !== null && painter.noticeTop !== undefined) ? painter.noticeTop - 10 : H - 18, y0 = y1 - h;
   // si la ficha cae encima, la barra se aparta al lado libre (la ficha esta siempre en un borde)
   var cr = painter.cardRect;
   if (cr && cr[2] > x0 - 8 && cr[0] < x0 + w + 8 && cr[3] > y0 - 6 && cr[1] < y1 + 6) {
      if (cr[0] > W / 2) x0 = Math.max(12, Math.round(cr[0] - 12 - w)); else x0 = Math.min(W - 12 - w, Math.round(cr[2] + 12));
   }
   // la banda: oscura con filete de laton arriba y abajo (como la linea de estado)
   g.fillRect(x0, y0, x0 + w, y1, new Brush(0xd40D0A07));
   g.pen = new Pen(0xe6C99A3A, 1); g.drawLine(x0, y1 - 0.5, x0 + w, y1 - 0.5);
   g.pen = new Pen(0x8CC99A3A, 0.6); g.drawLine(x0, y0 + 0.5, x0 + w, y0 + 0.5);
   // los tres mandos a la derecha
   var bs = 28, gp = 6, bxN = x0 + w - 14 - bs, bxP = bxN - gp - bs, bxA = bxP - gp - bs, by0 = y0 + Math.round((h - bs) / 2), by1 = by0 + bs;
   var btn = [["tour-prev", "prev", bxA], ["tour-pause", B.paused ? "play" : "pause", bxP], ["tour-next", "next", bxN]], i;
   for (i = 0; i < btn.length; ++i) {
      var id = btn[i][0], bx = btn[i][2], on = (hov === id), cx = bx + bs / 2, cy = by0 + bs / 2;
      if (on) g.fillRect(bx, by0, bx + bs, by1, new Brush(0x33C99A3A));
      g.pen = new Pen(on ? 0xffF3D27E : 0xffC99A3A, on ? 1.2 : 0.9); g.drawRect(bx + 0.5, by0 + 0.5, bx + bs - 0.5, by1 - 0.5);
      fvTourGlyph(g, btn[i][1], cx, cy, on ? 0xffF3D27E : 0xffE5B53F);
      painter.hits.push({ id: id, x0: bx, y0: by0, x1: bx + bs, y1: by1 });
   }
   // «TOUR 3 / 5» y, a su lado, lo que pasa
   var fL = cpFont("display", 12, false, false, 3), fS = cpFont("display", 10, false, false, 2), lab = fvTx("tour.label", { i: B.i, n: B.n }, L);
   g.font = fL; var wl = fL.width(lab), tx = x0 + 16, ty = y0 + 20;
   g.pen = new Pen(0xffF4ECDC); g.drawText(tx, ty, lab);
   var st = "";
   if (B.phase === "fly") st = fvTx("tour.fly", null, L);
   else if (B.phase === "scan") st = fvTx("tour.scan", null, L);
   else if (B.phase === "busy") st = fvTx("tour.busy", null, L);
   else if (B.phase === "paused") st = fvTx("tour.paused", null, L);
   else st = fvTx(B.last ? "tour.endIn" : "tour.nextIn", { s: Math.max(1, Math.ceil(B.left === null || B.left === undefined ? 0 : B.left - 1e-6)) }, L);
   var sx = tx + wl + 14, sw = bxA - 14 - sx;
   g.font = fS; st = cpElide(fS, st, Math.max(40, sw));
   g.pen = new Pen(B.phase === "busy" || B.phase === "paused" ? 0xffF3D27E : 0xffD0C1A5); g.drawText(sx, ty - 1, st);
   // la barra: cuenta atras (o un tramo que se desliza cuando no hay cuenta)
   var ba = x0 + 16, bb = bxA - 14, bw = bb - ba, bY = y0 + 32, bH = 6;
   g.fillRect(ba, bY, bb, bY + bH, new Brush(0xff2A1F15));
   var dim = (B.phase === "paused"), pulse = (B.phase === "busy") ? 0.62 + 0.38 * Math.sin(B.t * 5) : 1;
   if (B.phase === "fly" || B.phase === "scan") {
      var seg = Math.round(bw * 0.22), u = (B.t * 0.7) % 2, pos = (u <= 1 ? u : 2 - u) * (bw - seg);
      g.fillRect(ba + 1 + pos, bY + 1, ba + 1 + pos + seg, bY + bH - 1, new LinearGradientBrush(new Point(ba, bY), new Point(ba, bY + bH), [[0, (B.phase === "fly" ? 0xffF3D27E : 0xb0F3D27E) >>> 0], [1, (B.phase === "fly" ? 0xffB8862E : 0xb0B8862E) >>> 0]]));
   } else if (B.frac > 0) {
      var a8 = Math.round(255 * pulse) << 24, c0 = dim ? 0xB89A4A : 0xF3D27E, c1 = dim ? 0x6E5420 : 0xB8862E;
      g.fillRect(ba + 1, bY + 1, ba + 1 + (bw - 2) * fvClamp(B.frac, 0, 1), bY + bH - 1, new LinearGradientBrush(new Point(ba, bY), new Point(ba, bY + bH), [[0, (a8 | c0) >>> 0], [1, (a8 | c1) >>> 0]]));
   }
   g.pen = new Pen(0xff5E4214, 0.8); g.drawRect(ba + 0.5, bY + 0.5, bb - 0.5, bY + bH - 0.5);
   painter.hits.push({ id: "tour-bar", x0: x0, y0: y0, x1: x0 + w, y1: y1 });
   painter.tourRect = [x0, y0, x0 + w, y1];
}

// ---- el Sol (mirar a casa) ----
function fvSunPaint(g, painter, pr, P, W, H, ui) {
   var L = FV_LANG, d = fvLen(P.cam.pos), p = pr.project([0, 0, 0]);
   if (!p || d < 1e-6) return;
   var dpc = d / FV_LY_PER_PC, mgSun = (typeof FVS !== "undefined" && FVS.MG_SUN) ? FVS.MG_SUN : 4.68, m = mgSun + 5 * Math.log(dpc / 10) / Math.LN10;
   var x = p[0], y = p[1], r = 16;
   g.pen = new Pen(0xffF3D27E, 1.4); g.drawCircle(x, y, r); g.drawCircle(x, y, 2.2);
   g.pen = new Pen(0x90F3D27E, 1); g.drawCircle(x, y, r + 5);
   for (var k = 0; k < 4; ++k) { var a = k * Math.PI / 2; g.drawLine(x + Math.cos(a) * (r + 7), y + Math.sin(a) * (r + 7), x + Math.cos(a) * (r + 14), y + Math.sin(a) * (r + 14)); }
   var f1 = cpFont("display", 14, false, false, 2), f2 = cpFont("text", 11), right = x < W * 0.6, tx = right ? x + r + 20 : x - r - 20, l1 = fvTx("sun.label", null, L);
   var l2 = fvTx("sun.mag", { m: fvNum(m, 1, L) }, L) + " · " + fvTx(m < 6 ? "sun.eye" : "sun.tel", null, L), l3 = fvNum(d, 0, L) + " " + (typeof fvsT === "function" ? fvsT(L, "u.ly") : "ly");
   var rows = [l2, l3];
   // (20-nov, I4; E1-13 RETROSPECTIO) la magnitud en V con M_V,sol = 4,81 (Willmer 2018) y la frase segun cuanto brilla (src/engine/fv_e1.js: la misma del visor web);
   // desde otra galaxia, ademas, cuanto ocuparia la Via Lactea. Con FV_E1H.ON = false, lo de antes (banda G, 4,68)
   var sE = (typeof FV_E1H !== "undefined" && FV_E1H.ON && typeof fvE1hSun === "function") ? fvE1hSun(P.cam.pos, L) : null;
   if (sE && sE.ok) { m = sE.m; rows = sE.lines.concat([fvE1Tx("h.dist", { d: fvNum(d, 0, L) }, L)]); }
   g.font = f1; var w1 = f1.width(l1); g.font = f2; var w2 = 0, ri; for (ri = 0; ri < rows.length; ++ri) w2 = Math.max(w2, f2.width(rows[ri]));
   var ww = Math.max(w1, w2) + 16, bx = right ? tx : tx - ww, by = y - 26, bh = 20 + 15 * rows.length + 4;
   if (bx + ww > W - 6) bx = W - 6 - ww; if (bx < 6) bx = 6;
   g.fillRect(bx, by, bx + ww, by + bh, new Brush(0xd0110D09)); g.pen = new Pen(FV_HUD_COL.brass, 1); g.drawRect(bx + 0.5, by + 0.5, bx + ww - 0.5, by + bh - 0.5);
   g.font = f1; g.pen = new Pen(FV_HUD_COL.goldL); g.drawText(bx + 8, by + 17, l1);
   g.font = f2;
   for (ri = 0; ri < rows.length; ++ri) { g.pen = new Pen(ri === rows.length - 1 ? FV_HUD_COL.text2 : FV_HUD_COL.text); g.drawText(bx + 8, by + 33 + 15 * ri, rows[ri]); }
   painter.sunInfo = { m: m, x: x, y: y, d: d, rows: rows };
}

// ---------------------------------------------------------------------------
// LA FICHA DE ESCANEO
// ---------------------------------------------------------------------------
// (Blender 5b · R5-3) donde cae la reticula de la ficha: centro (sx, sy) y radio base rr, en unidades del HUD (pr = fvHudScaledPr). null = no se ve (detras de la camara).
// Lo mismo que calculaba fvCardPaint; ahora tambien lo usa fvNmPaint para no poner el rotulo DESTINO bajo la escuadra
function fvCardAnchor(painter, scene, pr, P, sel) {
   var sx, sy, rr;
   // (19-nov, N6; FV_N6.MARK) la seleccion «nebula» con la fila principal medida (laboratorio): el marcador va al centro de su contorno, adonde mira la camara (antes: el punto de pantalla donde se eligio, p. ej. un clic a 472 px)
   var iN6 = (sel.kind === "nebula" && typeof FV_N6 !== "undefined" && FV_N6.ON && FV_N6.MARK && FV_N6.DIST && typeof fvN6Main === "function") ? fvN6Main(scene) : -1;
   if (sel.kind === "star") {
      var p = pr.project(fvStarPos(scene, sel.i));
      if (!p) return null;
      sx = p[0]; sy = p[1];
      var hrA = (typeof fvHrAnchor === "function") ? fvHrAnchor(painter, sel.i) : null; if (hrA) { var hkA = painter.hudK || 1; sx = hrA[0] / hkA; sy = hrA[1] / hkA; }   // (I2, 19-nov) con el diagrama HR puesto, la reticula en su punto del diagrama
      var dc = fvLen(fvSub(fvStarPos(scene, sel.i), P.cam.pos)), lev = fvLookLevel(fvApparentMag(scene.stars.g[sel.i], scene.stars.dEarth[sel.i], dc), fvLookLimits(P.cam.fov, P.homeFov));
      rr = 12 + Math.min(40, 2.5 * fvLookParams(lev).sigma);
      if (painter.heroIdx === sel.i && painter.stats.heroR) rr = Math.max(rr, Math.min(60, 0.45 * painter.stats.heroR / (painter.hudK || 1)));
   } else if (sel.kind === "object" || iN6 >= 0) {
      // (N1/N8) un objeto singular de C: su posicion en la escena y su radio aparente
      // (14-nov, encargo A) un objeto mas alla de la boca de la caja se enseña a escala k en la losa (fvObjBoxK): el anillo lo sigue
      // (17-nov, F34; FV_F34.MARK) con contorno medido (FV_OBJ.FRAME) la camara mira al CENTRO DEL CONTORNO (o.frame.pos), no a la posicion de catalogo (o.pos): el marcador cae donde se mira
      // (en la nebulosa principal, o.pos es [0, 0, distancia] = el centro de la foto y el contorno de IC 2118 esta a 1 100 px de el: el marcador caia fuera de la nebulosa)
      var ob = scene.objects ? scene.objects[iN6 >= 0 ? iN6 : sel.i] : null, kbO = (ob && typeof fvObjBoxK === "function") ? fvObjBoxK(scene, ob) : 1, ofp = (ob && ob.pos) ? ob.pos : null;
      if (ob && ofp && typeof FV_F34 !== "undefined" && FV_F34.ON && FV_F34.MARK && typeof FV_OBJ !== "undefined" && FV_OBJ.FRAME && ob.frame && ob.frame.pos && ob.type !== "star" && ob.type !== "exoplanet") ofp = ob.frame.pos;
      var obp = ofp ? [ofp[0] * kbO, ofp[1] * kbO, ofp[2] * kbO] : null, po = obp ? pr.project(obp) : null;
      if (!po) return null;
      sx = po[0]; sy = po[1];
      var dco = fvLen(fvSub(obp, P.cam.pos)), rpx = (ob.radiusLy > 0 && dco > 0) ? pr.f * ob.radiusLy * kbO / dco : 0;
      rr = fvClamp(rpx || 18, 12, 90);
   } else if (sel.kind === "nebula" && typeof FV_N6 !== "undefined" && FV_N6.ON && FV_N6.MARK && FV_N6.WHOLE && scene.nebula && typeof fvN6WholeDist === "function" && fvN6WholeDist(scene) > 0) {
      // (19-nov, N6; FV_N6.WHOLE + MARK) sin fila principal que encuadrar la nebulosa es la lamina entera (la foto): el marcador en el centro de la foto, adonde mira la camara (no en el punto del clic)
      var pW = pr.project([0, 0, scene.nebula.distLy]);
      if (!pW) return null;
      sx = pW[0]; sy = pW[1]; rr = 26;
   } else { var hk = painter.hudK || 1; sx = sel.sx / hk; sy = sel.sy / hk; rr = 26; }
   return { sx: sx, sy: sy, rr: rr };
}
function fvCardPaint(g, painter, pr, P, W, H, ui) {
   var K = fvCardCols();
   var sel = P.sel, scene = painter.scene, t = P.t - sel.t0, sx, sy, rr, L = FV_LANG;
   // (6-nov, FV_TOUR_READ) lo que lee la espera del TOUR (fv_dialog.js tourStep): se rehace en cada pintada; sin pintar la ficha entera, «no completa»
   painter.cardRead = { t: P.t, sel: sel.kind + ":" + sel.i, typed: false, started: false, data: false, words: 0, closed: !!ui.cardClosed, hidden: !!(ui.hideCard || ui.exo) };
   var an = fvCardAnchor(painter, scene, pr, P, sel);
   if (!an) return;
   sx = an.sx; sy = an.sy; rr = an.rr;
   // fuera de la pantalla (p. ej. al mirar a casa): ni reticula ni linea de llamada hacia la nada (f2_mirar_a_casa.png del 4-nov)
   var onScreen = sx > -4 && sy > -4 && sx < W + 4 && sy < H + 4;
   // retícula: cuatro esquinas que convergen (0,4 s, rebote leve)
   var k = fvEaseOutBack(t / 0.4), R = rr * (1 + 2.2 * (1 - k)), a = Math.max(6, R * 0.45), i;
   g.pen = new Pen(FV_HUD_COL.gold, fvFine() ? 1.1 : 1.6);
   var Cn = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
   if (onScreen) for (i = 0; i < 4; ++i) { var cx0 = sx + Cn[i][0] * R, cy0 = sy + Cn[i][1] * R; g.drawLine(cx0, cy0, cx0 - Cn[i][0] * a, cy0); g.drawLine(cx0, cy0, cx0, cy0 - Cn[i][1] * a); }
   if (onScreen && typeof fvE1cUiMark === "function" && !ui.cardClosed && !ui.hideCard) { try { fvE1cUiMark(g, painter, pr, scene, sel, sx, sy); } catch (eM) {} }      // (I1) la pareja que viaja junta: la otra, marcada
   // (N4) ficha cerrada (× o Esc) u oculta durante el viaje: solo la reticula. Con el transito abierto, la ficha se aparta (se tapaban)
   if (t < 0.25 || ui.hideCard || ui.cardClosed || ui.exo) return;
   // el contenido (una vez por objeto e idioma)
   // (I12/I13) + la version de los datos de la ficha (espectro y composicion): cuando llegan, el texto se rehace. La PETICION es barata (un
   // Timer de un disparo en fv_card_sci.js): aqui no se trae nada
   var key = sel.kind + ":" + (sel.i === undefined ? "" : sel.i) + ":" + L + ":" + ((sel.kind === "star" && typeof fvCsciVer === "function") ? fvCsciVer(scene, sel.i) : 0);
   // (I1, 19-nov; FV_E1C) + la sesion de la cadena de «¿por que?» (un eslabon seguido o un sobre abierto rehacen la ficha); apagada, la clave de antes
   if (typeof fvE1cVer === "function" && fvE1cOn()) key += ":e" + fvE1cVer(scene);
   if (sel.kind === "star" && typeof fvCsciRequest === "function" && FV_CARD_SCI_AUTO) fvCsciRequest(scene, sel.i);
   if (!painter.cardC || painter.cardKey !== key) { painter.cardC = (sel.kind === "object") ? fvObjectCardContent(scene, sel.i, L) : fvCardContent(scene, sel, L, ui.exoList); painter.cardKey = key;
      if (typeof fvE1cUiInto === "function") { fvE1cUiInto(painter.cardC, scene, sel, L); if (typeof fvE1cVer === "function" && fvE1cOn()) painter.cardKey = key.replace(/:e\d+$/, ":e" + fvE1cVer(scene)); } }      // (I1) la prueba del misterio, la respuesta del eslabon y la pregunta (abrir un sobre cambia la sesion: la clave se pone al dia para no rehacer la ficha dos veces)
   var C = painter.cardC, more = !!ui.cardMore;
   var cw = 470, fTitle = cpFont("display", 17, false, false, 1), fSub = cpFont("display", 11, false, true, 1), fBody = cpFont("text", 12), fSmall = cpFont("text", 11);
   var tx0 = 162, maxW = cw - tx0 - 16, body = [], j;
   g.font = fBody;
   for (i = 0; i < C.l1.length; ++i) { var w1 = fvWrap(fBody, C.l1[i], maxW), c1 = (C.metalLine && C.l1[i] === C.metalLine) ? fvCardMetalCol(C, K) : ((C.e1cGold && fvE1cUiIsGold(C, C.l1[i])) ? fvE1cUiGold() : K.ink); for (j = 0; j < w1.length; ++j) body.push({ s: w1[j], f: fBody, c: c1, gap: j === 0 && i > 0 ? 3 : 0 }); }
   // (I1, 19-nov) la ficha acaba en UNA pregunta (el eslabon de la cadena): en oro, se pulsa («card-link») y lleva al objeto que la contesta
   if (C.e1cLink) { var fQ = cpFont("text", 12, false, true), wq = fvWrap(fQ, C.e1cLink.q, maxW); for (j = 0; j < wq.length; ++j) body.push({ s: wq[j], f: fQ, c: fvE1cUiGold(), gap: j === 0 ? 10 : 0, link: true }); }      // en cursiva y con aire: no es un dato mas, es la puerta al siguiente
   if (more) { g.font = fSmall; for (i = 0; i < C.l2.length; ++i) { var w2 = fvWrap(fSmall, C.l2[i], cw - 32); for (j = 0; j < w2.length; ++j) body.push({ s: w2[j], f: fSmall, c: K.sepia, gap: j === 0 ? 2 : 0, wide: true }); } }
   var hText = 0, nar = 0; for (i = 0; i < body.length; ++i) { if (!body[i].wide) nar += 16 + body[i].gap; else hText += 15 + body[i].gap; }
   // alto minimo: portilla + sello + su fuente (antes la fuente del sello se salia por abajo: f2_info_estrella.png del 4-nov)
   // (E6) 248: la fuente del sello (y0 + 234) quedaba debajo de la fila VIAJAR / WARP (nE2_pi_antes_ficha.png, 4-nov)
   // (I12) el panel del espectro XP va debajo de la portilla y del texto corto, a todo el ancho, y antes de los detalles de MÁS
   var chBase = Math.max(fvFine() ? 248 : 222, 62 + nar + 20), xpH = (typeof fvXpPanelH === "function") ? fvXpPanelH(C, more) : 0;
   // (I12) con MÁS abierto y una ficha que ya no cabe (NGC 2392, nI12_pi_ngc2392_A_mas.png del 5-nov: subia a la placa DATOS), el panel
   // plegado del espectro cede su sitio a los detalles: el espectro sigue en la ficha con MÁS cerrado
   if (more && xpH && chBase + xpH + 10 + hText + 24 + 30 > H - 80) xpH = 0;
   var ch = chBase + (xpH ? xpH + 10 : 0) + (more ? hText + 24 : 0) + 30;
   var right = sx < W * 0.55, x0 = right ? W - cw - 26 : 26, yMin = 58;
   // (M) con la tira de respuesta de QUAESTIO en la cabina (arriba al centro), la ficha de una estrella de arriba no se coloca debajo de ella: el titulo quedaba tapado
   if (ui.e1qHud && typeof fvE1qCardMinY === "function") yMin = fvE1qCardMinY(W, x0, x0 + cw, yMin);
   var y0 = Math.round(fvClamp(sy - 90, yMin, Math.max(yMin, H - ch - 22)));
   // linea de llamada con codo
   var ax = sx + (right ? R : -R), ay = sy - R, ex = right ? x0 : x0 + cw, mx = ax + (ex - ax) * 0.35, grow = fvClamp((t - 0.25) / 0.3, 0, 1);
   g.pen = new Pen(onScreen ? 0xc0E5B53F : 0x00000000, 1);
   var pts = [[ax, ay], [mx, y0 + 22], [ex, y0 + 22]], tot = 0, seg = [];
   for (i = 1; i < 3; ++i) { var l = Math.sqrt(Math.pow(pts[i][0] - pts[i - 1][0], 2) + Math.pow(pts[i][1] - pts[i - 1][1], 2)); seg.push(l); tot += l; }
   var left = tot * grow;
   for (i = 1; i < 3 && left > 0; ++i) { var u = Math.min(1, left / seg[i - 1]); g.drawLine(pts[i - 1][0], pts[i - 1][1], pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * u, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * u); left -= seg[i - 1]; }
   if (grow < 1) return;
   var tc = t - 0.55;                                   // reloj de la ficha
   // la placa
   var open = fvSmooth(tc / 0.25), chOpen = Math.max(30, ch * open);
   fvCardPanel(g, x0, y0, x0 + cw, y0 + chOpen, chOpen > 60);
   if (open < 1) return;
   // titulo
   g.font = fTitle; g.pen = new Pen(K.title); g.drawText(x0 + 18, y0 + 28, cpElide(fTitle, C.title, cw - 64));
   // (N4) el aspa de cerrar, arriba a la derecha (y Esc)
   var xc = x0 + cw - 24, yc = y0 + 22, hovX = (ui.hover === "card-close");
   if (hovX) { if (fvFine()) { g.pen = new Pen(K.btn, 1); g.drawCircle(xc, yc, 10); } else g.fillCircle(xc, yc, 10, fvBrassBrush(xc, yc, 10)); }
   g.pen = new Pen(hovX ? K.closeHov : K.close, fvFine() ? 1.1 : 1.8); g.drawLine(xc - 5, yc - 5, xc + 5, yc + 5); g.drawLine(xc - 5, yc + 5, xc + 5, yc - 5);
   painter.hits.push({ id: "card-close", x0: xc - 12, y0: yc - 12, x1: xc + 12, y1: yc + 12 });
   g.font = fSub; g.pen = new Pen(K.sepia); g.drawText(x0 + 18, y0 + 44, cpElide(fSub, C.sub, cw - 36));
   fvCardRule(g, x0 + 16, x0 + cw - 16, y0 + 51);
   // la portilla con el objeto
   var pcx = x0 + 86, pcy = y0 + 126, pr0 = 58;
   fvPorthole(g, painter, sel, C, pcx, pcy, pr0, tc, P, pr);
   // el subtitulo y su filete otra vez, encima: el anillo de esmalte de la portilla (hasta 1,44·r) mordia «NEBULOSA DE» (nA_mirabilia_ficha, 4-nov)
   g.font = fSub; g.pen = new Pen(K.sepia); g.drawText(x0 + 18, y0 + 44, cpElide(fSub, C.sub, cw - 36));
   fvCardRule(g, x0 + 16, x0 + cw - 16, y0 + 51);
   // el sello
   fvStamp(g, C.stamp, pcx, pcy + pr0 + 14, tc);
   // el texto que se escribe solo, con las cifras que giran
   // 150 car./s el nivel 1 (la ficha en ~2 s; a 95 seguia escribiendo a los 3 s) y 450 el «más» (700 caracteres en la nebulosa)
   var ty = y0 + 72, tLine = 0.35;
   for (i = 0; i < body.length; ++i) {
      var b = body[i], cpsL = b.wide ? 450 : 150;
      if (b.wide && (i === 0 || !body[i - 1].wide)) ty = Math.max(ty + 6, pcy + pr0 + 64, xpH ? y0 + chBase + xpH + 16 : 0);
      ty += b.gap;
      var shown = Math.floor((tc - tLine) * cpsL);
      if (shown > 0) { g.font = b.f; g.pen = new Pen(b.c); g.drawText(b.wide ? x0 + 18 : x0 + tx0, ty, fvRolling(b.s, shown, tc, 0, cpsL, tLine)); }
      if (b.link && shown >= b.s.length) { var lw = b.f.width(b.s); if (ui.hover === "card-link") { g.pen = new Pen(b.c, 0.8); g.drawLine(x0 + tx0, ty + 2.5, x0 + tx0 + lw, ty + 2.5); } painter.hits.push({ id: "card-link", x0: x0 + tx0 - 2, y0: ty - 12, x1: x0 + tx0 + lw + 2, y1: ty + 4 }); }      // (I1) la pregunta del eslabon
      tLine += b.s.length / cpsL;
      ty += b.wide ? 15 : 16;
   }
   // (6-nov, FV_TOUR_READ) la ficha esta COMPLETA cuando el texto se ha escrito entero y sus datos (espectro, metalicidad) ya no estan en camino
   var sciR = (sel.kind === "star" && typeof fvCsciState === "function") ? fvCsciState(scene, sel.i) : null;
   painter.cardRead.started = tc >= 0.4;     // (12-nov, R7) started = el texto ya empezo a escribirse (el reloj de lectura del tour)
   painter.cardRead.typed = tc >= tLine; painter.cardRead.data = !sciR || sciR.st !== "fetch";
   painter.cardRead.words = (typeof fvTourWords === "function") ? fvTourWords(body) + fvTourWords(C.title) + fvTourWords(C.sub) : body.length * 6;
   // (I12) el panel del espectro: su reloj empieza cuando HAY espectro y la ficha lleva FV_XP_UI.START_S abierta (o al llegar, si llega luego)
   if (xpH) {
      // (la ficha reabierta: su reloj vuelve a empezar y el barrido tambien)
      if (!painter.xpT0 || painter.xpT0.key !== key || (painter.xpT0.tc !== null && tc + 0.3 < painter.xpT0.tc)) painter.xpT0 = { key: key, tc: C.xp ? Math.max(tc, FV_XP_UI.START_S) : null };
      fvXpPanelPaint(g, x0 + 16, y0 + chBase + 2, cw - 32, xpH, C, (painter.xpT0.tc !== null) ? tc - painter.xpT0.tc : tc, L);
      painter.xpRect = [x0 + 16, y0 + chBase + 2, x0 + cw - 16, y0 + chBase + 2 + xpH];
   } else painter.xpRect = null;
   // MÁS / MENOS
   var lab = fvTx(more ? "card.less" : "card.more", null, L), fM = cpFont("display", 11, false, false, 2);
   g.font = fM; var wm = fM.width(lab) + 18, bx1 = x0 + cw - 14, bx0 = bx1 - wm, by1 = y0 + ch - 10, by0 = by1 - 20;
   if (fvFine()) { var hvM = (ui.hover === "card-more"); if (hvM) g.fillRect(bx0, by0, bx1, by1, new Brush(K.hovFill)); g.pen = new Pen(hvM ? K.btnHov : K.btn, hvM ? 1.2 : 0.9); g.drawRect(bx0 + 0.5, by0 + 0.5, bx1 - 0.5, by1 - 0.5); g.pen = new Pen(K.btnTx); g.drawText(bx0 + 9, by1 - 6, lab); }
   else {
   g.fillRect(bx0, by0, bx1, by1, fvBrassBrush((bx0 + bx1) / 2, (by0 + by1) / 2, wm / 2));
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawRect(bx0 + 0.5, by0 + 0.5, bx1 - 0.5, by1 - 0.5);
   g.pen = new Pen(FV_HUD_COL.ink); g.drawText(bx0 + 9, by1 - 6, lab);
   }
   painter.hits.push({ id: "card-more", x0: bx0, y0: by0, x1: bx1, y1: by1 });
   // (pasada M, Nino: «debo tener el boton de Travel en la propia ficha, e informacion para ir mas rapido») en la fila de MÁS: VIAJAR (el
   // icono de la flecha curva, con el MODUS de la cabina) y el OTRO modo (WARP o CINE), cada uno con lo que dura el viaje con el REGULATOR
   // de ahora, y la distancia desde la nave. ui.trip lo calcula el dialogo (fv_route.js, fvRouteTrip: el motor sobre una copia del
   // piloto); sin ui.trip (el video REC) la fila no se pinta.
   if (ui.trip) fvCardTripPaint(g, painter, ui, x0 + 16, by0, bx0 - 10, by1);
   painter.hits.push({ id: "card", x0: x0, y0: y0, x1: x0 + cw, y1: y0 + ch });
   painter.cardRect = [x0, y0, x0 + cw, y0 + ch];
}
// (S2, Nino 4-nov: «ficha oscura grabada, como la portada») la paleta de la ficha: oscura (marfil y oro sobre negro calido) o la de
// esmalte de antes. FV_CARD_DARK = false vuelve a la lamina crema (el ROJO de fv_nE2_test). Solo la ficha: el transito y los avisos siguen
// en esmalte.
var FV_CARD_DARK = true;
function fvCardDark() { return FV_CARD_DARK && fvFine(); }
function fvCardCols() {
   if (fvCardDark()) return { title: 0xffF4ECDC, ink: 0xffE6DCC6, sepia: 0xffBFA06A, rule: 0xc0C99A3A, btn: 0xffC99A3A, btnHov: 0xffF3D27E, btnTx: 0xffF4ECDC, btnDis: 0xff6E604A,
                              hovFill: 0x26C99A3A, close: 0xffC99A3A, closeHov: 0xffF3D27E, mask: 0xff0E0B08, stampSrc: 0xBFA06A,
                              stamp: function(c) { return c === FV_HUD_COL.stampOk ? 0xff9CC48E : (c === FV_HUD_COL.stampWarn ? 0xffE5B53F : (c === FV_HUD_COL.stampBad ? 0xffE0704F : c)); } };
   return { title: FV_HUD_COL.ink, ink: FV_HUD_COL.ink, sepia: FV_HUD_COL.sepia, rule: 0xc05E4214, btn: FV_HUD_COL.brass, btnHov: FV_HUD_COL.ink, btnTx: FV_HUD_COL.ink, btnDis: 0xff9A8A6A,
            hovFill: 0x30C99A3A, close: FV_HUD_COL.brassD, closeHov: FV_HUD_COL.ink, mask: FV_HUD_COL.enamel1, stampSrc: 0x5E4214, stamp: function(c) { return c; } };
}
// la placa de la ficha: oscura grabada (opaca: la portilla tapa sus esquinas con el color del fondo) o la de esmalte
function fvCardPanel(g, x0, y0, x1, y1, deco) {
   if (fvCardDark() && typeof fvEngravedPanel === "function") { g.fillRect(x0, y0, x1, y1, new Brush(0xff0E0B08)); fvEngravedPanel(g, x0, y0, x1, y1, false); return; }
   fvEnamelPanel(g, x0, y0, x1, y1, deco);
}
// (E6) el filete de la ficha: con rombo central en el estilo fino; recto en el de antes
function fvCardRule(g, xa, xb, y) {
   if (fvFine() && typeof fvOrnRule === "function") { fvOrnRule(g, xa, xb, y, fvCardCols().rule, 0.8); return; }
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawLine(xa, y, xb, y);
}
// (pasada M) la fila de viaje de la ficha entre x0 y x1 (la fila de MÁS, y0…y1): [⤳ VIAJAR 18 s] [WARP 9 s]  a 1 230 a.l. de la nave
function fvCardTripPaint(g, painter, ui, x0, y0, x1, y1) {
   var K = fvCardCols();
   var T = ui.trip, fB = cpFont("display", 11, false, false, 2), fI = cpFont("text", 11, false, true), x = x0;
   function btn(id, label, icon, sec, ok) {
      var txt = label + (ok && sec > 0 ? "  " + fvRouteDur(sec, FV_LANG) : ""), w = fB.width(txt) + (icon ? 36 : 18), hov = (ui.hover === id);
      if (fvFine()) { if (ok && hov) g.fillRect(x, y0, x + w, y1, new Brush(K.hovFill)); g.pen = new Pen(ok ? (hov ? K.btnHov : K.btn) : K.btnDis, hov && ok ? 1.2 : 0.9); g.drawRect(x + 0.5, y0 + 0.5, x + w - 0.5, y1 - 0.5); }
      else {
      if (ok) g.fillRect(x, y0, x + w, y1, fvBrassBrush(x + w / 2, (y0 + y1) / 2, w / 2)); else g.fillRect(x, y0, x + w, y1, new Brush(0xffD8C9A4));
      g.pen = new Pen(hov && ok ? FV_HUD_COL.ink : FV_HUD_COL.brassD, hov && ok ? 1.6 : 0.8); g.drawRect(x + 0.5, y0 + 0.5, x + w - 0.5, y1 - 0.5);
      }
      if (icon) fvEngrave(g, "travel", x + 12, (y0 + y1) / 2, 9, false, fvFine() ? (ok ? (fvCardDark() ? 0xffE9C97A : K.btnTx) : K.btnDis) : undefined);
      g.font = fB; g.pen = new Pen(ok ? K.btnTx : K.btnDis); g.drawText(x + (icon ? 27 : 9), y1 - 6, txt);      // (el icono llegaba a tocar la V)
      if (ok) painter.hits.push({ id: id, x0: x, y0: y0, x1: x + w, y1: y1 });
      x += w + 6;
   }
   var go = !T.here;
   btn("card-travel", fvTx("card.go"), true, T.sMain, go && T.okMain);
   if (!fvGwarpUi()) btn("card-alt", fvTx(T.alt === "spectacular" ? "card.warp" : "card.cine"), false, T.sAlt, go && T.okAlt);      // (21-nov, N-galaxias-warp) con FV_GWARP, un solo boton
   // (Blender 5b · R5-8) «ESTÁS AQUÍ» dice a cuanto: la nave llega a una distancia de la estrella (14 a.l.) y el rotulo DESTINO y la ficha del planeta daban esa cifra
   var info = T.here ? ((FV_B5B.HERE && T.d > 0) ? fvTx("b5b.hereD", { d: (typeof fvNmLy === "function" ? fvNmLy(T.d) : fvNavDistText(T.d, "measured", FV_LANG)) }) : fvTx("card.here")) : fvTx("card.from", { d: fvNavDistText(T.d, "measured", FV_LANG) });
   g.font = fI; g.pen = new Pen(K.sepia); var s = cpElide(fI, info, x1 - x - 2);
   if (x1 - x > 24) g.drawText(x + 2, y1 - 6, s);
}
// el texto tecleado: los `shown` primeros caracteres; las cifras recien escritas (< 0,35 s) giran
// (F4b) solo giran las CIFRAS DE MEDIDA: no las de un nombre o una cita («3D», «A9V», «DR3», «Edenhofer 2024»), que salian como «1D» y
// «0037» en las capturas (revision del 4-nov): un trozo con letras, o un año de 1800–2099, se escribe tal cual
function fvRollable(s, j) {
   var a = j, b = j;
   while (a > 0 && !/\s/.test(s.charAt(a - 1))) --a;
   while (b < s.length && !/\s/.test(s.charAt(b))) ++b;
   var tok = s.substring(a, b);
   if (/[A-Za-zÀ-ÿ]/.test(tok)) return false;
   var num = tok.replace(/[^0-9]/g, "");
   return !(num.length === 4 && +num >= 1800 && +num <= 2099);
}
function fvRolling(s, shown, tc, used, cps, t0l) {
   var n = Math.min(s.length, shown), out = "";
   for (var j = 0; j < n; ++j) {
      var ch = s.charAt(j), age = tc - t0l - (used + j) / cps;
      if (ch >= "0" && ch <= "9" && age < 0.35 && fvRollable(s, j)) out += String(Math.floor(fvHashF(used + j, Math.floor(tc * 24)) * 10));
      else out += ch;
   }
   return out;
}
// la portilla: bisel de laton, el objeto en grande (color exagerado), barrido de escaneo, lineas y grano
// (Blender 1) P y pr (opcionales): la camara y el proyector, para la fase del exoplaneta vista desde la nave
function fvPorthole(g, painter, sel, C, cx, cy, r, tc, P, pr) {
   if (fvFine()) g.fillCircle(cx, cy, r + 6, new Brush(0xff2A1F15)); else g.fillCircle(cx, cy, r + 6, fvBrassBrush(cx, cy, r + 6));
   g.fillCircle(cx, cy, r, new Brush(0xff07060A));
   var x0 = cx - r, y0 = cy - r, x1 = cx + r, y1 = cy + r, rev = fvClamp(tc / 0.9, 0, 1), scanY = y0 + 2 * r * rev;
   g.compositionOperator = CompositionOp_Add;
   // (Blender 2 · PL-6, 10-nov) el MUNDO del planeta en la portilla: la de un objeto «exoplaneta» y la de una ESTRELLA con planeta conocido
   // (cruce verdadero o un objeto «exoplaneta» de la escena sobre ella: fvPl3dHostObj). Con FV_PL3D.ON false no se entra
   var plObj = (P && typeof fvPl3dActive === "function" && fvPl3dActive()) ? fvPl3dHostObj(painter, sel, C) : null, plSt = null;
   // (Blender 3 · D4) la de una ESTRELLA pinta su estrella (la portilla de siempre, mas abajo) y el mundo en un recuadro al final
   var plInset = !!(plObj && sel.kind === "star" && typeof fvPl3dInsetObj === "function");
   if (plObj && !plInset && fvPl3dPortholeObj(g, painter, P, pr, plObj, cx, cy, r, tc)) {
      // (punto 5) el planeta LIMPIO, como en la web (F3c): sin lineas de barrido, grano, barra dorada ni brillo del cristal encima
      plSt = painter.stats.pl3d;
      g.compositionOperator = CompositionOp_SourceOver;
      g.pen = new Pen(fvCardCols().mask, r * 0.44); g.drawCircle(cx, cy, r * 1.22);
      g.pen = new Pen(FV_HUD_COL.brassD, 1); g.drawCircle(cx, cy, r + 6);
      if (fvFine()) { g.pen = new Pen(FV_HUD_COL.brass, 1); g.drawCircle(cx, cy, r + 3); g.pen = new Pen(0x90C99A3A, 0.6); g.drawCircle(cx, cy, r + 0.5);
         for (var mk2 = 0; mk2 < 36; ++mk2) { var pm2 = fvPol(r + 6, mk2 * 10), qm2 = fvPol(r + (mk2 % 9 === 0 ? 3 : 4.6), mk2 * 10); g.drawLine(cx + pm2[0], cy + pm2[1], cx + qm2[0], cy + qm2[1]); } }
      // (Blender 3 · D6) los rotulos curvados por dentro del cristal; el brazo de la cruz que ocupa un rotulo no se pinta
      if (typeof fvPl3dLabels === "function") fvPl3dCross(g, cx, cy, r, fvPl3dLabels(g, cx, cy, r, plSt));
      else { g.pen = new Pen(0x80E5B53F, 1); g.drawLine(cx, cy - r + 4, cx, cy - r + 13); g.drawLine(cx, cy + r - 13, cx, cy + r - 4); g.drawLine(cx - r + 4, cy, cx - r + 13, cy); g.drawLine(cx + r - 13, cy, cx + r - 4, cy); }
      return;
   }
   if (sel.kind === "star") {
      var c = fvRgbOf(C.col), ex = (typeof fvsExaggerateColour === "function") ? fvsExaggerateColour(c) : c;
      var sp = painter.heroSpriteCol(((ex.r << 16) | (ex.g << 8) | ex.b) >>> 0), zr = r * 1.25;
      g.drawScaledBitmap(cx - zr, cy - zr, cx + zr, cy + zr, sp);
   } else if (C && C.portBmp && C.portBmp.width > 1 && C.portBmp.height > 1) {
      // (N4, nota de C) el recorte del objeto que trae la ficha (card.portBmp): llena la portilla sin deformarse (lado menor = diametro)
      var pb = C.portBmp;
      if (painter.portSrc !== pb) {        // el cuadrado central (si no, lo alargado se saldria del anillo de esmalte)
         var s0 = Math.min(pb.width, pb.height), ox0 = Math.floor((pb.width - s0) / 2), oy0 = Math.floor((pb.height - s0) / 2);
         painter.portSq = (pb.width === pb.height) ? pb : new Bitmap(pb, ox0, oy0, ox0 + s0, oy0 + s0); painter.portSrc = pb;
      }
      g.drawScaledBitmap(x0, y0, x1, y1, painter.portSq); g.opacity = 0.6; g.drawScaledBitmap(x0, y0, x1, y1, painter.portSq); g.opacity = 1;
   } else if (sel.kind === "object" && painter.photoPlane && painter.scene.objects && painter.scene.objects[sel.i] && painter.scene.objects[sel.i].px &&
              painter.scene.objects[sel.i].type !== "nebula" && 2.5 * (painter.scene.objects[sel.i].px.r || 20) < 0.4 * Math.min(painter.photoPlane.width, painter.photoPlane.height)) {
      // (una nebulosa que llena la foto, como IC 1848, va por la rama de abajo: su recorte de 1,6·r salia como una mancha parda, nA_mirabilia_ficha)
      // (N1) el objeto: su recorte de la foto sin estrellas (px en pixeles del Bitmap de trabajo), dos veces en Add como la nebulosa
      var op = painter.scene.objects[sel.i].px, ppb = painter.photoPlane, half = Math.max(40, 2.5 * (op.r || 20));
      var qx0 = Math.round(fvClamp(op.x - half, 0, ppb.width - 2)), qy0 = Math.round(fvClamp(op.y - half, 0, ppb.height - 2)), qx1 = Math.round(fvClamp(op.x + half, qx0 + 2, ppb.width)), qy1 = Math.round(fvClamp(op.y + half, qy0 + 2, ppb.height));
      if (painter.objSqKey !== sel.i) { painter.objSq = new Bitmap(ppb, qx0, qy0, qx1, qy1); painter.objSqKey = sel.i; }
      g.drawScaledBitmap(x0, y0, x1, y1, painter.objSq); g.opacity = 0.6; g.drawScaledBitmap(x0, y0, x1, y1, painter.objSq); g.opacity = 1;
   } else if (painter.photoPlane) {
      if (!painter.nebSquare) { var pp = painter.photoPlane, s = Math.min(pp.width, pp.height), ox = (pp.width - s) / 2, oy = (pp.height - s) / 2;
                                painter.nebSquare = new Bitmap(pp, Math.round(ox), Math.round(oy), Math.round(ox + s), Math.round(oy + s)).scaledTo(256, 256); }
      // color exagerado: el mismo bitmap dibujado dos veces en Add (mas contraste y saturacion aparente)
      var sub = painter.nebSquare;
      g.drawScaledBitmap(x0, y0, x1, y1, sub); g.opacity = 0.6; g.drawScaledBitmap(x0, y0, x1, y1, sub); g.opacity = 1;
   }
   g.compositionOperator = CompositionOp_SourceOver;
   // lo que aun no ha barrido el escaner, a oscuras
   if (rev < 1) g.fillRect(x0, scanY, x1, y1, new Brush(0xf007060A));
   // lineas de barrido y grano
   g.pen = new Pen(0x38000000, 1);
   for (var yy = y0 + 1; yy < y1; yy += 3) g.drawLine(x0, yy, x1, yy);
   var seed = Math.floor(tc * 18);
   for (var k = 0; k < 90; ++k) { var gx = x0 + fvHashF(k, seed) * 2 * r, gy = y0 + fvHashF(k + 300, seed) * 2 * r; g.fillRect(gx, gy, gx + 1, gy + 1, new Brush(fvHashF(k, seed + 7) > 0.5 ? 0x30FFFFFF : 0x40000000)); }
   var sweep = y0 + ((tc * 0.6) % 1) * 2 * r;
   g.fillRect(x0, (rev < 1 ? scanY : sweep) - 1, x1, (rev < 1 ? scanY : sweep) + 1.5, new Brush(0x80F3D27E));
   // las esquinas del cuadrado fuera del circulo (r … r·√2): un anillo del color del esmalte, justo ese ancho (con 0,62·r
   // se salia de la ficha y tapaba el subtitulo: f2_info_estrella.png del 4-nov)
   g.pen = new Pen(fvCardCols().mask, r * 0.44); g.drawCircle(cx, cy, r * 1.22);
   g.pen = new Pen(FV_HUD_COL.brassD, 1); g.drawCircle(cx, cy, r + 6);
   if (fvFine()) { g.pen = new Pen(FV_HUD_COL.brass, 1); g.drawCircle(cx, cy, r + 3); g.pen = new Pen(0x90C99A3A, 0.6); g.drawCircle(cx, cy, r + 0.5);
      for (var mk = 0; mk < 36; ++mk) { var pm = fvPol(r + 6, mk * 10), qm = fvPol(r + (mk % 9 === 0 ? 3 : 4.6), mk * 10); g.drawLine(cx + pm[0], cy + pm[1], cx + qm[0], cy + qm[1]); } }
   g.fillCircle(cx, cy, r, new RadialGradientBrush(new Point(cx - 0.35 * r, cy - 0.45 * r), 0.8 * r, new Point(cx - 0.35 * r, cy - 0.45 * r), [[0, 0x30FFFFFF], [1, 0x00FFFFFF]]));
   // retícula de la portilla
   g.pen = new Pen(0x80E5B53F, 1);
   g.drawLine(cx, cy - r + 4, cx, cy - r + 13); g.drawLine(cx, cy + r - 13, cx, cy + r - 4); g.drawLine(cx - r + 4, cy, cx - r + 13, cy); g.drawLine(cx + r - 13, cy, cx + r - 4, cy);
   // (Blender 3 · D4) la estrella con planeta: el mundo en un recuadro encima de la portilla de siempre (fuera de el, la portilla es la de HEAD)
   // (Blender 5 · H4) un planeta de DEMOSTRACION lleva «DEMO» en el recuadro (el nombre entero no cabe en el arco y no es el de esta estrella)
   if (plInset) fvPl3dInsetObj(g, painter, P, pr, plObj, cx, cy, r, tc, (typeof FV_EXO_DEMO_CARD !== "undefined" && FV_EXO_DEMO_CARD && plObj.match !== "gaia-id" && plObj.match !== "position" && plObj.match !== undefined) ? fvTx("b5.demoWord") : (plObj.planet.pl_name || plObj.name));
}
// el sello de goma: aparece de golpe (0,9 s) con un leve desplazamiento de la tinta
function fvStamp(g, st, cx, y, tc) {
   if (!st || tc < 0.9) return;
   var f = cpFont("display", 14, true, false, 3), fs = cpFont("text", 9), a = fvClamp((tc - 0.9) / 0.12, 0, 1);
   var K = fvCardCols();
   g.font = f; var w = f.width(st.word) + 18, x0 = cx - w / 2, col = ((Math.round(220 * a) << 24) | (K.stamp(st.col) & 0xffffff)) >>> 0;
   g.pen = new Pen(col, 2); g.drawRect(x0, y, x0 + w, y + 24); g.pen = new Pen(col, 0.8); g.drawRect(x0 + 3, y + 3, x0 + w - 3, y + 21);
   g.drawText(x0 + 9, y + 17, st.word);
   g.font = fs; g.pen = new Pen(((Math.round(200 * a) << 24) | K.stampSrc) >>> 0);
   var src = cpElide(fs, st.src || "", 136); g.drawText(cx - fs.width(src) / 2, y + 36, src);
}

// el marco de laton de la ventana (maqueta §10): filete oscuro, laton con brillo, esquineras y remaches
function fvFramePaint(g, W, H) {
   g.antialiasing = true;
   // (N7) el marco con la escala de la foto (con W = 1280, igual que antes)
   var kf = fvHudK(W);
   if (Math.abs(kf - 1) > 1e-6) { var M0 = g.transformationMatrix; g.scaleTransformation(kf, kf); try { fvFramePaintK(g, W / kf, H / kf); } finally { g.transformationMatrix = M0; } return; }
   fvFramePaintK(g, W, H);
}
function fvFramePaintK(g, W, H) {
   if (fvFine()) {
      // (E6) el marco de grabado: filete de oro de 1 px, otro de oro tenue a 4 px por dentro, esquinas de doble arco a linea con un
      // punto, y marcas de escala finas en el centro de cada lado (sin el laton de 3 px ni los remaches en relieve)
      g.pen = new Pen(0xff2A1F12, 1); g.drawRect(1.5, 1.5, W - 1.5, H - 1.5);
      g.pen = new Pen(FV_HUD_COL.brass, 1); g.drawRect(4.5, 4.5, W - 4.5, H - 4.5);
      g.pen = new Pen(0x80C99A3A, 0.6); g.drawRect(8.5, 8.5, W - 8.5, H - 8.5);
      var Cf = [[8.5, 8.5, 1, 1], [W - 8.5, 8.5, -1, 1], [W - 8.5, H - 8.5, -1, -1], [8.5, H - 8.5, 1, -1]], q, k2;
      for (q = 0; q < 4; ++q) {
         var xq = Cf[q][0], yq = Cf[q][1], sxq = Cf[q][2], syq = Cf[q][3];
         for (var rr = 0; rr < 2; ++rr) {
            var Rq = rr ? 18 : 26, pq = [];
            for (k2 = 0; k2 <= 12; ++k2) { var bq = (Math.PI / 2) * k2 / 12; pq.push(new Point(xq + sxq * Rq * Math.sin(bq), yq + syq * Rq * Math.cos(bq))); }
            g.pen = new Pen(rr ? 0x80C99A3A : 0xc0C99A3A, rr ? 0.6 : 0.9); g.drawPolyline(pq);
         }
         g.fillCircle(xq + sxq * 6, yq + syq * 6, 1.3, new Brush(0xd0C99A3A));
      }
      g.pen = new Pen(0x90C99A3A, 0.7);
      for (k2 = -4; k2 <= 4; ++k2) {
         var L2 = (k2 === 0) ? 7 : 3.5;
         g.drawLine(W / 2 + k2 * 9, 8.5, W / 2 + k2 * 9, 8.5 + L2); g.drawLine(W / 2 + k2 * 9, H - 8.5, W / 2 + k2 * 9, H - 8.5 - L2);
         g.drawLine(8.5, H / 2 + k2 * 9, 8.5 + L2, H / 2 + k2 * 9); g.drawLine(W - 8.5, H / 2 + k2 * 9, W - 8.5 - L2, H / 2 + k2 * 9);
      }
      return;
   }
   g.pen = new Pen(FV_HUD_COL.brassD, 1); g.drawRect(1.5, 1.5, W - 1.5, H - 1.5);
   g.pen = new Pen(FV_HUD_COL.brass, 3); g.drawRect(6, 6, W - 6, H - 6);
   g.pen = new Pen(0x90E9C97A, 1); g.drawRect(4.5, 4.5, W - 4.5, H - 4.5);
   var C = [[6, 6, 1, 1], [W - 6, 6, -1, 1], [W - 6, H - 6, -1, -1], [6, H - 6, 1, -1]];
   g.pen = new Pen(FV_HUD_COL.brass, 1.2);
   for (var i = 0; i < 4; ++i) {
      var x = C[i][0], y = C[i][1], sx = C[i][2], sy = C[i][3], pts = [];
      for (var k = 0; k <= 12; ++k) { var u = k / 12, a = (1 - u) * (1 - u), b = 2 * u * (1 - u), c = u * u; pts.push(new Point(a * x + b * (x + 4 * sx) + c * (x + 34 * sx), a * (y + 34 * sy) + b * (y + 4 * sy) + c * y)); }
      g.drawPolyline(pts);
      g.drawLine(x + 8 * sx, y + 22 * sy, x + 14 * sx, y + 20 * sy); g.drawLine(x + 14 * sx, y + 20 * sy, x + 22 * sx, y + 8 * sy);
      fvRivet(g, x + 11 * sx, y + 11 * sy, 2.6);
   }
}
function fvRivet(g, x, y, r) {
   g.fillCircle(x, y, r, new RadialGradientBrush(new Point(x - r * 0.3, y - r * 0.35), r * 1.4, new Point(x - r * 0.3, y - r * 0.35), [[0, 0xffF3D27E], [0.55, 0xff9C7325], [1, 0xff3B2A0C]]));
}
