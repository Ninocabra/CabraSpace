// ============================================================================
// FieldVoyager/src/ui/fv_nav.js — LA VENTANA SOLIDARIA DE LA FOTO Y LOS INSTRUMENTOS DE NAVEGACION (pasada N, 4-nov-2026)
// ----------------------------------------------------------------------------
// N7 · fvLayout(anchoDisponible, altoDisponible, aspecto, nBotones): TODO sale del tamaño de la ventana. La foto ocupa lo maximo con
//      su aspecto; la columna de botones va pegada a su borde izquierdo y la franja de instrumentos pegada debajo, con su mismo ancho;
//      botones, relojes, letras y fichas son proporcionales al ancho de la foto (sin mar negro entre la foto y los mandos; si la
//      ventana tiene otra forma, el conjunto se centra).
// N1 · En la franja, a la izquierda:
//      TABULA      miniatura 2D de la foto con lo que mira la camara marcado (y la nave, si ha salido de casa); clic = mirar alli,
//                  doble clic = ir alli (a la estrella u objeto mas cercano al punto).
//      PROFUNDITAS mapa 3D del campo en vista oblicua: el cono de la foto con la Tierra en el vertice, las estrellas a su distancia
//                  (profundidad en escala logaritmica: si no, todo se amontona en la nebulosa), la nebulosa como losa, los objetos
//                  singulares, y la nave con su direccion de mirada (en vivo).
//      A la derecha, MIRABILIA: la lista de lo mas singular (scene.objects de C por score; sin ellos, las estrellas notables y la
//      nebulosa); clic = elegir (ficha), doble clic o la flecha = ir.
// Las posiciones estan en una rejilla de 1440 × 156 unidades (FVCockpit las escala con k = ancho/1440). ES5.
// ============================================================================

var FV_NAV = { LIST_X_GW: 1182, GRID_W: 1440, GRID_H: 156, BTN_K: 0.040, LABEL_K: 0.30, GAP_K: 0.16, ASPECT_MIN: 1.0, ASPECT_MAX: 2.4, MARGIN: 6,
               RMAX_PX: 2.2e6,                 // pixeles maximos del fotograma de la escena (mas, y se pinta a menos y se escala: fps)
               LIST_MAX: 14, MAP_STARS: 700,
               EXO_FRAC: 1 / 3,                // (N2, punto 5 de Nino) como mucho un tercio de MIRABILIA son exoplanetas, y van los ultimos
               // (B, 14-nov) MIRABILIA mas clara y con mas filas. LABELS: la estrella elegida por un superlativo se llama por el («La estrella mas luminosa»), no
               // «Gaia DR3 …» (que pasa a la ayuda de la fila); false = ROJO, el nombre de catalogo de antes. LIST_V2: filas mas apretadas (6 en 1920×1080, 5 en
               // 1280×800, antes 4 y 4); false = ROJO, las filas de 25 unidades de antes. Titulo y subtitulo con la letra minima de la cabina (7 px: el suelo de
               // fvNavListPaint de antes) y la fila justo lo que miden los dos renglones; si con dos renglones no salen al menos ROW2_MIN filas (ventana pequeña),
               // un solo renglon (titulo y, si cabe, el subtitulo detras) de alto tamaño de letra + ROW1_PAD; HD2 = la cabecera (antes 16)
               LABELS: true, LIST_V2: true, ROW_H: 16, ROW_T: 8.0, ROW_S: 7.0, ROW2_MIN: 5, ROW1_PAD: 4.5, HD2: 13,
               // (P28, 16-nov · DECISION DE NINO) legibilidad de los rotulos de objeto de PROFUNDITAS (buildStatic, paso 6): 0 = lo de siempre (de fabrica) ·
               // 1 = colocacion que no pisa otro texto ni las aristas del cono (con una linea guia fina si el rotulo se aparta) · 2 = placa oscura translucida
               // y difuminada detras del texto · 3 = las dos. Medido en tests/_p28/fv_p28_labels.js
               // (D1, 16-nov, DECISION DE NINO: de fabrica 2 = la placa; 0 devuelve lo de antes)
               LABEL_FIX: 2,
               // (P23-mapas, 16-nov) los mapas coherentes con el viaje: un objeto MAS ALLA de la boca de la caja 3D (fvObjBoxK < 1; en M 82, la galaxia a 12,2 millones
               // de a.l. con la caja acabando en 5 798) se marca en PROFUNDITAS donde la camara va de verdad (la losa de la foto, en su misma linea de vision), con
               // «»» tras el icono y su distancia real en el rotulo; true = asi · false = en su distancia de catalogo (fuera del panel), como hasta el 15-nov. TABULA no
               // cambia de sitio nada (su proyeccion es de la Tierra: no depende de la escala) y solo anade «»» junto al aro del objeto elegido si esta mas alla de la boca.
               // ENCENDIDA de fabrica: en fotos sin objetos fuera de la caja el mapa sale identico pixel a pixel (tests/_p28/fv_p23_maps.js: Collinder 34 y NGC 2392, 0 px)
               BOX_MAP: true,
               TRAIL_N: 48, TRAIL_S: 10 };     // (N2, punto 1) la estela de la nave: ultimos 48 puntos o 10 s de reloj de escena

// ---------------------------------------------------------------------------
// N7 · LA COMPOSICION
// ---------------------------------------------------------------------------
// -> { pw, ph (la foto, con SU aspecto), sw (ancho de la franja: = pw salvo foto vertical), sh, b, bh, gap, colW, x0, y0, vx, vy, sx, sy, W, H, k (= pw/1280: la escala de la ficha y los rotulos), kc (= pw/1440) }
function fvLayout(availW, availH, aspect, nBtn) {
   // (Codex H-2, 4-nov) la FOTO conserva SIEMPRE su aspecto. Antes el aspecto se recortaba a [1,0; 2,4] y, con una foto vertical o una
   // panoramica, la pantalla salia con otro aspecto y la vista de casa (que CUBRE el fotograma) cortaba la foto. Ahora el bloque (franja
   // de ancho legible) se calcula con el aspecto acotado y la foto se encaja dentro con el suyo: vertical → mas estrecha que la franja y
   // centrada sobre ella; panoramica → del ancho de la franja y mas baja. Dentro de [1,0; 2,4] no cambia nada (foto = franja de ancho).
   var aT = (isFinite(aspect) && aspect > 0) ? aspect : 1.5;
   var a = fvClamp(aT, FV_NAV.ASPECT_MIN, FV_NAV.ASPECT_MAX), m = FV_NAV.MARGIN, n = Math.max(1, nBtn || 8);
   var sR = FV_NAV.GRID_H / FV_NAV.GRID_W, cR = FV_NAV.BTN_K * 1.34;
   var sw = Math.min((availW - 2 * m) / (1 + cR), (availH - 2 * m) / (1 / a + sR));
   sw = Math.max(320, Math.floor(sw));
   var phB = Math.round(sw / a), sh = Math.round(sw * sR);
   var pw = sw, ph = phB;
   if (aT < a) { ph = phB; pw = Math.max(16, Math.round(ph * aT)); }          // vertical: el alto del bloque, mas estrecha
   else if (aT > a) { pw = sw; ph = Math.max(16, Math.round(sw / aT)); }      // panoramica: el ancho de la franja, mas baja
   // el boton: proporcional a la franja, pero la columna entera (con rotulos) tiene que caber a lo alto de la foto y la franja
   var b = Math.round(FV_NAV.BTN_K * sw), per = 1 + FV_NAV.LABEL_K + FV_NAV.GAP_K;
   if (n * per * b > ph + sh) b = Math.floor((ph + sh) / (n * per));
   b = Math.max(24, b);
   var bh = Math.round(b * (1 + FV_NAV.LABEL_K)), gap = Math.max(2, Math.round(b * FV_NAV.GAP_K)), colW = Math.round(b * 1.34);
   var W = colW + sw, H = ph + sh, x0 = Math.max(0, Math.floor((availW - W) / 2)), y0 = Math.max(0, Math.floor((availH - H) / 2));
   var vx = x0 + colW + Math.floor((sw - pw) / 2);
   return { pw: pw, ph: ph, sw: sw, sh: sh, b: b, bh: bh, gap: gap, colW: colW, x0: x0, y0: y0, vx: vx, vy: y0, sx: x0 + colW, sy: y0 + ph,
            W: W, H: H, aspect: aT, aspectBox: a, k: sw / 1280, kc: sw / FV_NAV.GRID_W };
}

// el tamaño del fotograma de la escena para una pantalla de vw × vh (tope de pixeles: por encima se pinta a menos y se escala)
function fvFrameSize(vw, vh) {
   var px = vw * vh;
   if (px <= FV_NAV.RMAX_PX) return { w: vw, h: vh, s: 1 };
   var s = Math.sqrt(FV_NAV.RMAX_PX / px);
   return { w: Math.round(vw * s), h: Math.round(vh * s), s: s };
}

// ---------------------------------------------------------------------------
// la geometria de los tres paneles en la franja (unidades de rejilla); la rellena FVCockpit con su k
// ---------------------------------------------------------------------------
function fvNavGeom(aspect) {
   var a = (isFinite(aspect) && aspect > 0) ? fvClamp(aspect, 0.2, 6) : 1.5;     // (H-2) la miniatura con el aspecto de la foto, sin deformar
   var w2 = Math.min(196, 132 * a), h2 = w2 / a, y2 = 10 + (132 - h2) / 2;
   // (21-nov, N-galaxias-warp; FV_GWARP) sin la placa MODUS (centro 1200, ±26) la franja gana el hueco entre la radio (acaba en 1166) y MIRABILIA: la lista empieza en LIST_X_GW en vez de 1240 (192 -> 250 unidades de ancho)
   var lx0 = (typeof fvGwarpUi === "function" && fvGwarpUi()) ? FV_NAV.LIST_X_GW : 1240;
   return { map2d: [10, y2, 10 + w2, y2 + h2], map3d: [10 + w2 + 10, 10, 10 + w2 + 10 + 184, 142], list: [lx0, 8, 1432, 148] };
}

// ---------------------------------------------------------------------------
// los iconos de tipo (grabados, como los botones): pn · galaxy · cluster · nebula · quasar · star · other
// ---------------------------------------------------------------------------
function fvNavIcon(g, type, cx, cy, r, col) {
   var c = col || 0xffE5B53F, i;
   if (typeof fvE1cUiIcon === "function" && fvE1cUiIcon(g, type, cx, cy, r, c)) return;      // (I1) los sobres de AENIGMATA (lacrado / abierto)
   g.antialiasing = true;
   g.pen = new Pen(c, Math.max(0.8, r * 0.16));
   if (type === "pn") { g.drawCircle(cx, cy, r * 0.85); g.fillCircle(cx, cy, r * 0.25, new Brush(c)); }
   else if (type === "galaxy") { g.drawEllipse(cx - r, cy - r * 0.42, cx + r, cy + r * 0.42); g.fillEllipse(cx - r * 0.3, cy - r * 0.18, cx + r * 0.3, cy + r * 0.18, new Brush(c)); }
   else if (type === "cluster") { var P = [[0, -0.6], [-0.6, 0.1], [0.55, 0.05], [-0.2, 0.65], [0.35, 0.6], [0.1, -0.05]]; for (i = 0; i < P.length; ++i) g.fillCircle(cx + P[i][0] * r, cy + P[i][1] * r, r * 0.2, new Brush(c)); }
   else if (type === "nebula") { g.drawEllipse(cx - r, cy - r * 0.35, cx + r * 0.2, cy + r * 0.55); g.drawEllipse(cx - r * 0.3, cy - r * 0.7, cx + r, cy + r * 0.3); }
   else if (type === "exoplanet") { g.fillCircle(cx - r * 0.25, cy, r * 0.42, new Brush(c)); g.drawEllipse(cx - r, cy - r * 0.38, cx + r, cy + r * 0.38); g.fillCircle(cx + r * 0.78, cy - r * 0.2, r * 0.18, new Brush(c)); }
   else if (type === "quasar") { g.fillCircle(cx, cy, r * 0.3, new Brush(c)); g.drawLine(cx - r, cy + r * 0.5, cx + r, cy - r * 0.5); }
   else if (type === "star") { for (i = 0; i < 4; ++i) { var a = i * Math.PI / 4; g.drawLine(cx - Math.cos(a) * r * (i % 2 ? 0.55 : 1), cy - Math.sin(a) * r * (i % 2 ? 0.55 : 1), cx + Math.cos(a) * r * (i % 2 ? 0.55 : 1), cy + Math.sin(a) * r * (i % 2 ? 0.55 : 1)); } g.fillCircle(cx, cy, r * 0.28, new Brush(c)); }
   else { g.drawLine(cx, cy - r, cx + r, cy); g.drawLine(cx + r, cy, cx, cy + r); g.drawLine(cx, cy + r, cx - r, cy); g.drawLine(cx - r, cy, cx, cy - r); }
}

// (P27c, 16-nov) el icono de la fila de la nebulosa PRINCIPAL: el de su tipo real. La entrada principal es siempre type «nebula» (el motor y el orden de la lista cuelgan de eso),
// pero su etiqueta (scene.nebula.typeLabel = fvNebMainKind) puede ser cumulo, planetaria, galaxia...: se busca en FV_OBJ_LABEL la clave de esa etiqueta. Con Sharpless (o sin etiqueta,
// o con FV_MIRA.ICON_BY_TYPE = false) devuelve `type` sin tocarlo. Una clave sin icono propio (snr, unknown) cae en el rombo de «other», como fvNavIcon.
function fvNavIconKind(type, typeLabel) {
   if (typeof FV_MIRA === "undefined" || FV_MIRA.ICON_BY_TYPE === false || !typeLabel || typeof FV_OBJ_LABEL === "undefined") return type;
   for (var k in FV_OBJ_LABEL) if (FV_OBJ_LABEL.hasOwnProperty(k) && FV_OBJ_LABEL[k].en === typeLabel.en && FV_OBJ_LABEL[k].es === typeLabel.es) return (k === "rne" ? "nebula" : k);   // (P32) «nebulosa de reflexion» tiene etiqueta propia pero el icono de nebulosa
   return type;
}
// (P29, 17-nov) el icono de un objeto en el MAPA PROFUNDITAS: la misma funcion que la lista (fvNavIconKind), solo para el principal (sin etiqueta, type tal cual).
// FV_MIRA.MAP_ICON_BY_TYPE = false: ROJO, el type de siempre (icono de nebulosa para un cumulo principal).
function fvNavMapIcon(o) {
   if (typeof FV_MIRA === "undefined" || FV_MIRA.MAP_ICON_BY_TYPE === false) return o.type;
   return fvNavIconKind(o.type, o.main ? o.typeLabel : null);
}

// ---------------------------------------------------------------------------
// N1 · LOS ELEMENTOS DE LA LISTA: scene.objects (C) o, sin ellos, las estrellas notables y la nebulosa
// -> [{ kind: "object"|"star"|"nebula", i, name, type, sub, dist }]
// ---------------------------------------------------------------------------
// (N2, punto 5 de Nino: «en Mirabilia solo veo exoplanetas») CAUSA, medida en tests/fv_nA_test.js: scene.objects viene ordenado por
// `score` y cada exoplaneta cruzado puntua 8 (7 por posicion), por encima de CUALQUIER objeto del cielo profundo (cuasar/planetaria 5,
// galaxia 4, nebulosa/cumulo 3) y de las estrellas notables (2 + bonus): tras la nebulosa principal (9), con 3 o mas planetas en el
// campo las filas visibles (4) y, con 13 o mas, las 14 de la lista son todo planetas. Arreglo en la lista, no en el score del motor:
// el orden es por CATEGORIA (0 nebulosa principal · 1 cielo profundo: cumulos, planetarias, galaxias, cuasares, nebulosas · 2 estrellas
// notables · 3 exoplanetas) y dentro de cada una por score; los exoplanetas, como mucho un tercio de la lista (FV_NAV.EXO_FRAC).
function fvNavRank(it) { if (it.main || it.hero) return 0; if (it.type === "exoplanet") return 3; if (it.type === "star") return 2; return 1; }   // (E2b) hero: el protagonista de la foto, en la categoria 0 y el primero de ella
function fvNavOrder(items, max) {
   var g = [[], [], [], []], out = [], i, capExo = Math.max(1, Math.floor(max * FV_NAV.EXO_FRAC));
   for (i = 0; i < items.length; ++i) g[fvNavRank(items[i])].push({ it: items[i], k: i });
   for (i = 0; i < 4; ++i) g[i].sort(function(a, b) { return ((b.it.hero ? 1 : 0) - (a.it.hero ? 1 : 0)) || ((b.it.score || 0) - (a.it.score || 0)) || (a.k - b.k); });      // (E2b) el protagonista primero (hero solo existe con FV_HERO.FIRST)
   if (g[3].length > capExo) g[3] = g[3].slice(0, capExo);
   var all = g[0].concat(g[1], g[2], g[3]);
   for (i = 0; i < all.length && out.length < max; ++i) out.push(all[i].it);
   return out;
}
// el orden de antes (solo por score y cortado a LIST_MAX): el ROJO de la prueba
function fvNavOrderOld(items, max) { return items.slice().sort(function(a, b) { return (b.score || 0) - (a.score || 0); }).slice(0, max); }
var FV_NAV_ORDER_OLD = false;
// (I3) el elemento de la lista de UN objeto de la escena: lo usan la lista y el buscador (src/ui/fv_search.js), para que sean el mismo
function fvNavCap(t) { t = String(t || ""); return t.length ? t.charAt(0).toUpperCase() + t.substring(1) : t; }
// (B) la ayuda de una fila con rotulo: el titulo, el nombre de catalogo y el criterio exacto (el idioma de la nave y, en cursiva, el otro)
function fvNavEsc(t) { return String(t).split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;"); }
function fvNavLabelTip(cat, lb, L) {
   var a = (L === "es") ? "es" : "en", b = (a === "es") ? "en" : "es";
   return "<html><b>" + fvNavEsc(lb[a].t) + "</b>" + (lb[a].v ? " · " + fvNavEsc(lb[a].v) : "") + "<br>" + fvNavEsc(cat) + "<br>" + fvNavEsc(lb[a].d) + "<br><i>" + fvNavEsc(lb[b].d) + "</i></html>";
}
// (P32, 17-nov) el tipo CORTO de la fila de un renglon (modo 1: «NGC 1435 · tipo» solo si el tipo cabe entero): «Nebulosa de reflexion» no cabe donde cabia «Nebulosa»; sin esto la fila
// pierde su tipo (antes decia «Nebulosa»). Solo para la etiqueta rne (FV_OBJ.RNE_LABEL); "" = sin tipo corto (lo de siempre).
function fvNavSubShort(o, L) {
   if (typeof FV_OBJ === "undefined" || FV_OBJ.RNE_LABEL === false || !o.typeLabel || typeof FV_OBJ_LABEL === "undefined" || !FV_OBJ_LABEL.rne || o.typeLabel.en !== FV_OBJ_LABEL.rne.en) return "";
   return fvNavCap(FV_OBJ_LABEL.nebula[L === "es" ? "es" : "en"]);
}
// (E2b, 17-nov) ¿es el protagonista de la foto (scene.hero, fv_build.js) y se pone el primero? Solo con FV_HERO.FIRST; sin protagonista o con la bandera a false, false (la lista de antes)
function fvNavHero(o) { return !!(o && o.hero === true && typeof FV_HERO !== "undefined" && FV_HERO.ON && FV_HERO.FIRST); }
function fvNavObjItem(scene, i, lang) {
   var L = lang || FV_LANG, o = scene.objects[i], tl = o.typeLabel ? (o.typeLabel[L === "es" ? "es" : "en"] || o.typeLabel.en || o.type) : o.type;
   // (Blender 5b · R5-1) el planeta de DEMOSTRACION: «DEMO ·» delante y no la distancia de la estrella del campo como si fuera la suya (la misma fila que sale de
   // refreshItems sin objeto en la escena; antes, con el objeto en la escena, salia «HD 189733 b · exoplaneta · 6 530 a.l.»)
   if (typeof fvObjIsDemo === "function" && fvObjIsDemo(o)) return { kind: "object", i: i, main: !!o.main, score: o.score || 0, name: "DEMO · " + ((o.names && o.names[L === "es" ? "es" : "en"]) || o.name || o.id || "?"), type: "exoplanet", dist: o.distLy, sub: fvTx("b5.navDemo", { d: fvNavDistText(o.distLy, o.distSrc, L) }, L) };
   var nm = (o.names && o.names[L === "es" ? "es" : "en"]) || o.name || o.id || "?", dt = (o.distLy > 0 ? fvNavDistText(o.distLy, o.distSrc, L) : "");
   // (B, 14-nov) una estrella elegida por un criterio: el titulo ES el criterio (o.label, fv_mira.js), su valor y la distancia debajo; el nombre de catalogo, en la ayuda
   var lb = (FV_NAV.LABELS !== false && o.label && o.label[L === "es" ? "es" : "en"]) ? o.label : null;
   if (lb) { var lt = lb[L === "es" ? "es" : "en"]; return { kind: "object", i: i, main: !!o.main, hero: fvNavHero(o), score: o.score || 0, name: lt.t, cat: nm, crit: lb.crit, type: o.type || "other", icon: fvNavIconKind(o.type || "other", o.main ? o.typeLabel : null), dist: o.distLy, sub: (lt.v ? lt.v + (dt ? " · " : "") : "") + dt, tip: fvNavLabelTip(nm, lb, L), short: lt.s || "" }; }
   return { kind: "object", i: i, main: !!o.main, hero: fvNavHero(o), score: o.score || 0, name: nm, type: o.type || "other", icon: fvNavIconKind(o.type || "other", o.main ? o.typeLabel : null), dist: o.distLy, sub: (FV_NAV.LABELS !== false ? fvNavCap(tl) : tl) + (dt ? " · " + dt : ""), subShort: fvNavSubShort(o, L) };
}
// (I3) lo mismo para una estrella de la escena y para la nebulosa suelta (sin objetos de C)
function fvNavStarItem(scene, k, lang) {
   var L = lang || FV_LANG, S = scene.stars, m = S.meta[k] || {};
   return { kind: "star", i: k, name: "Gaia DR3 " + (m.sourceId ? m.sourceId : fvDesignation(m.ra, m.dec)), type: "star", dist: S.dEarth[k], sub: (FV_NAV.LABELS !== false ? (L === "es" ? "Estrella" : "Star") : (L === "es" ? "estrella" : "star")) + " · G " + fvNum(S.g[k], 1, L) + " · " + fvNavDistText(S.dEarth[k], S.q[k] === 0 ? "measured" : "assumed", L) };
}
function fvNavNebItem(scene, lang) {
   var L = lang || FV_LANG, N = scene ? scene.nebula : null;
   if (!N) return null;
   return { kind: "nebula", name: (N.names && N.names[L === "es" ? "es" : "en"]) || N.name || N.id || "Nebula", type: "nebula", icon: fvNavIconKind("nebula", N.typeLabel), dist: N.distLy, sub: fvTx("nav.neb", null, L) + " · " + fvNavDistText(N.distLy, N.measured ? "measured" : "assumed", L) };
}
// (21-nov, T1-A; FV_NOTABLE.NODATA_ROW) la fila «sin datos» (scene.noData, fvObjFinalList): titulo del criterio, «sin datos» en lugar del valor, la razon en la ayuda. NO es un destino (kind
// «nodata», sin flecha, no se elige ni se viaja a ella: FVDialog.listSelect / listGo); ordena como una estrella notable (type «star», el score que tendria la fila de verdad)
function fvNavNoDataItem(nd, lang) {
   var L = (lang || FV_LANG) === "es" ? "es" : "en", lb = nd.label, lt = lb[L];
   return { kind: "nodata", noData: true, i: -1, main: false, score: nd.score || 0, name: lt.t, cat: "", crit: lb.crit, type: "star", icon: "star", dist: 0, sub: lt.v, tip: "<html><b>" + fvNavEsc(lt.t) + " · " + fvNavEsc(lt.v) + "</b><br>" + fvNavEsc(lt.d) + "<br><i>" + fvNavEsc(lb[L === "es" ? "en" : "es"].d) + "</i></html>", short: lt.s || "" };
}
function fvNavItems(scene, exoList, lang) {
   var L = lang || FV_LANG, out = [], i;
   if (!scene) return out;
   if (scene.objects && scene.objects.length) {
      for (i = 0; i < scene.objects.length; ++i) out.push(fvNavObjItem(scene, i, L));
      if (FV_NOTABLE.NODATA_ROW !== false && FV_NAV.LABELS !== false && scene.noData) for (i = 0; i < scene.noData.length; ++i) if (scene.noData[i] && scene.noData[i].label) out.push(fvNavNoDataItem(scene.noData[i], L));
      return FV_NAV_ORDER_OLD ? fvNavOrderOld(out, FV_NAV.LIST_MAX) : fvNavOrder(out, FV_NAV.LIST_MAX);
   }
   var hosts = (exoList || []).map(function(e) { return e.star; });
   var list = (typeof fvTourPick === "function") ? fvTourPick(scene, function(k) { var s = (typeof fvStarInfo === "function") ? fvStarInfo(scene, k) : null; return s ? { radius: s.radius, teff: s.teff } : null; }, hosts, 7) : [];
   for (i = 0; i < list.length; ++i) {
      var it = list[i];
      if (it.kind === "nebula" && scene.nebula) { var N = scene.nebula; out.push({ kind: "nebula", name: (N.names && N.names[L === "es" ? "es" : "en"]) || N.name || N.id || "Nebula", type: "nebula", icon: fvNavIconKind("nebula", N.typeLabel), dist: N.distLy, sub: fvTx("nav.neb", null, L) + " · " + fvNavDistText(N.distLy, N.measured ? "measured" : "assumed", L) }); }
      else if (it.kind === "star") { var S = scene.stars; out.push({ kind: "star", i: it.i, name: (FV_NAV.LABELS !== false && typeof fvMiraTitle === "function") ? fvMiraTitle(it.why, L) : fvTx("why." + it.why, null, L), type: "star", dist: S.dEarth[it.i], sub: "G " + fvNum(S.g[it.i], 1, L) + " · " + fvNavDistText(S.dEarth[it.i], S.q[it.i] === 0 ? "measured" : "assumed", L) }); }
   }
   return out;
}
function fvNavDistText(d, src, L) {
   // 3 cifras significativas, como la ficha (fvsFmtSig): «6 540», no «6 536»
   var s = (d >= 100 ? fvsFmtSig(d, 3, L) : fvNum(d, 1, L)) + " " + fvTx("nav.ly", null, L);
   return (src === "assumed" ? "~" : "") + s;
}

// ---------------------------------------------------------------------------
// la proyeccion de la foto: punto del mundo -> fraccion (u, v) de la foto vista desde la Tierra (null si esta detras)
// ---------------------------------------------------------------------------
function fvNavPhotoUV(scene, p) {
   if (!(p[2] > 1e-9)) return null;
   var f = scene.field;
   return [(f.width / 2 + f.F * p[0] / p[2]) / f.width, (f.height / 2 + f.F * p[1] / p[2]) / f.height];
}
// lo que mira la camara, en la foto: el borde de la pantalla (32 puntos) proyectado al plano de referencia y llevado a la foto
// -> { poly: [[u, v]…] (puede salirse de 0…1), away: bool (no mira hacia la foto), ship: [u, v] | null, look: [u, v] | null }
function fvNavFov(scene, P) {
   var out = { poly: [], away: false, ship: null, look: null };
   if (!scene || !P) return out;
   var cam = P.cam, pr = fvProjector(cam, P.VW, P.VH), N = scene.nebula, pos = cam.pos;
   var dRef = N ? N.distLy : 1000;
   var zRef = (pos[2] < 0.85 * dRef) ? dRef : pos[2] + 0.6 * dRef;
   function rayAt(sx, sy) {
      var u = (sx - pr.cx) / pr.f, v = (sy - pr.cy) / pr.f;
      return [pr.fw[0] + u * pr.r[0] + v * pr.d[0], pr.fw[1] + u * pr.r[1] + v * pr.d[1], pr.fw[2] + u * pr.r[2] + v * pr.d[2]];
   }
   function hit(dir) { if (!(dir[2] > 1e-9)) return null; var t = (zRef - pos[2]) / dir[2]; if (!(t > 0)) return null; return fvNavPhotoUV(scene, [pos[0] + t * dir[0], pos[1] + t * dir[1], zRef]); }
   var W = P.VW, H = P.VH, n = 8, pts = [], k;
   for (k = 0; k < n; ++k) pts.push([W * k / n, 0]);
   for (k = 0; k < n; ++k) pts.push([W, H * k / n]);
   for (k = 0; k < n; ++k) pts.push([W - W * k / n, H]);
   for (k = 0; k < n; ++k) pts.push([0, H - H * k / n]);
   for (k = 0; k < pts.length; ++k) { var q = hit(rayAt(pts[k][0], pts[k][1])); if (q) out.poly.push(q); }
   out.look = hit(rayAt(W / 2, H / 2));
   out.away = out.poly.length < 3 || !out.look;
   if (fvLen(pos) > 1e-6) out.ship = fvNavPhotoUV(scene, pos);
   return out;
}

// ---------------------------------------------------------------------------
// el mapa 3D: profundidad logaritmica y cono exagerado a lo ancho
// ---------------------------------------------------------------------------
function FVNavMap3D(scene) {
   this.scene = scene;
   var S = scene.stars, N = scene.nebula, ds = [], i;
   if (S) for (i = 0; i < S.n; ++i) if (S.inFrame[i]) ds.push(S.dEarth[i]);
   ds.sort(function(a, b) { return a - b; });
   var p97 = ds.length ? ds[Math.min(ds.length - 1, Math.floor(0.97 * ds.length))] : 1000;
   this.dMax = Math.max(100, N ? 1.35 * N.distLy : 0, p97);
   this.d0 = this.dMax / 250;
   var f = scene.field; this.hx = (f.width / 2) / f.F; this.hy = (f.height / 2) / f.F;
   this.stat = null; this.statKey = "";
   this.view = null;                  // (nD2) null = la proyeccion de gabinete de siempre (la franja); { az, el, zoom } = vista orbitable (mapa grande)
   this.tilt = [0, 0];                // (nD2) inclinacion de los planos de la nebulosa, grados: [alrededor de X (cabeceo), alrededor de Y (guiñada)]
   this.photo = null; this.thumbs = {};   // (nD3) la foto para la losa de la nebulosa (setPhoto; la pone FVRoute.attach)
}
// ---------------------------------------------------------------------------
// (nD2, encargo E5 de Nino: «PROFUNDITAS: mover el 3D con el boton izquierdo · inclinar los planos») LA VISTA ORBITABLE Y LOS PLANOS INCLINADOS
// Vista: ortografica de «tocadiscos» alrededor del centro del modelo (profundidad 0,5): azimut alrededor del eje vertical del mapa, elevacion
// alrededor del horizontal de la pantalla, zoom. AZ0 / EL0 reproducen a ojo la de gabinete (lo lateral sube 0,32 y se va 0,45 a la derecha:
// sin(27°) = 0,45 y cos(27°)·sin(21°) = 0,32), asi abrir el mapa grande no da un salto respecto a la franja.
// ---------------------------------------------------------------------------
var FV_NAV_ORBIT = { AZ0: 27, EL0: 21, EL_MIN: -85, EL_MAX: 85, Z_MIN: 0.5, Z_MAX: 8, L: 0.86, DEG_PER_W: 200, DEG_PER_H: 140, WHEEL: 1.15,
                     TILT_MAX: 60, TILT_DEG_PX: 0.35 };
function fvNavViewHome() { return { az: FV_NAV_ORBIT.AZ0, el: FV_NAV_ORBIT.EL0, zoom: 1 }; }
FVNavMap3D.prototype.setView = function(v) { this.view = v ? { az: +v.az, el: fvClamp(+v.el, FV_NAV_ORBIT.EL_MIN, FV_NAV_ORBIT.EL_MAX), zoom: fvClamp(+v.zoom || 1, FV_NAV_ORBIT.Z_MIN, FV_NAV_ORBIT.Z_MAX) } : null; };
FVNavMap3D.prototype.viewKey = function() { var v = this.view, t = this.tilt || [0, 0]; return (v ? v.az.toFixed(3) + "," + v.el.toFixed(3) + "," + v.zoom.toFixed(4) : "cab") + "|" + t[0].toFixed(3) + "," + t[1].toFixed(3); };
// la inclinacion: un punto del mundo girado alrededor del centro de la nebulosa [0, 0, D] (primero X, luego Y). La misma para el mapa y, cuando
// el pintor la lea (scene.nebula.tilt), para el vuelo
function fvNavTiltPt(p, D, tilt) {
   if (!tilt || (!tilt[0] && !tilt[1])) return p.slice();
   var q = [p[0], p[1], p[2] - D];
   q = fvRotate(q, [1, 0, 0], tilt[0] * FV_DEG); q = fvRotate(q, [0, 1, 0], tilt[1] * FV_DEG);
   return [q[0], q[1], q[2] + D];
}
// la normal de los planos con esa inclinacion (sin inclinar: +Z, hacia el fondo)
function fvNavTiltNormal(tilt) { return fvNorm(fvNavTiltPt([0, 0, 1], 0, tilt)); }
// las cuatro esquinas (mundo) del plano de la foto a la distancia D, inclinado
FVNavMap3D.prototype.slabWorld = function(D) {
   var hx = this.hx * D, hy = this.hy * D, C = [[-hx, -hy], [hx, -hy], [hx, hy], [-hx, hy]], out = [];
   for (var i = 0; i < 4; ++i) out.push(fvNavTiltPt([C[i][0], C[i][1], D], D, this.tilt));
   return out;
};
// la losa en el MAPA (medido el 4-nov: inclinar en el MUNDO el plano de la foto, 14° x 10,5°, apenas cambia su profundidad — de 6 521 a
// 6 552 a.l. a 6 536 — y en la escala logaritmica del mapa movia las esquinas 14 px: no se veia). El mapa no es metrico (profundidad log,
// cono exagerado a lo ancho), asi que dibuja el ANGULO elegido: el rectangulo de la losa (±0,30·s de ancho a la profundidad s) girado con
// la inclinacion en el espacio del mapa. Sin inclinar sale identico a M(s, ±1, ±1). El vuelo usa la inclinacion en el mundo (slabWorld).
// (lx, ly) = fraccion del semiancho / semialto de la foto (ly + abajo) -> punto del modelo [profundidad, lateral, arriba]
FVNavMap3D.prototype.slabLocal = function(s, lx, ly) {
   var q = fvNavTiltPt([lx * 0.30 * s, ly * 0.30 * s * (this.hy / this.hx), 0], 0, this.tilt);
   return [s + q[2], q[0], -q[1]];
};
FVNavMap3D.prototype.slabPt = function(s, lx, ly, r) { return this.screen(this.slabLocal(s, lx, ly), r); };
FVNavMap3D.prototype.depth = function(d) { return Math.log(1 + Math.max(0, d) / this.d0) / Math.log(1 + this.dMax / this.d0); };
// punto del mundo -> [X profundidad 0…1, Y lateral, Z arriba] del modelo del mapa (null si esta detras de la Tierra)
FVNavMap3D.prototype.model = function(p) {
   var d = fvLen(p);
   if (d < 1e-9) return [0, 0, 0];
   var z = Math.max(p[2], 1e-9 * d), s = this.depth(d), a = fvClamp((p[0] / z) / this.hx, -1.8, 1.8), b = fvClamp((p[1] / z) / this.hy, -1.8, 1.8);
   if (p[2] <= 0) { a = fvClamp(p[0] / d * 4, -1.8, 1.8); b = fvClamp(p[1] / d * 4, -1.8, 1.8); }
   return [s, a * 0.30 * s, -b * 0.30 * s * (this.hy / this.hx)];
};
// modelo -> pixel del panel r = [x0, y0, x1, y1] (proyeccion de gabinete: la profundidad a la derecha, lo lateral hacia el fondo)
FVNavMap3D.prototype.screen = function(m, r) {
   var w = r[2] - r[0], h = r[3] - r[1], v = this.view;
   if (v) {                                            // (nD2) la vista orbitable
      var az = v.az * FV_DEG, el = v.el * FV_DEG, d0 = m[0] - 0.5, xr = d0 * Math.cos(az) + m[1] * Math.sin(az), yd = -d0 * Math.sin(az) + m[1] * Math.cos(az);
      var up = m[2] * Math.cos(el) + yd * Math.sin(el), Lv = Math.min(FV_NAV_DET.BIG_L * w, FV_NAV_DET.BIG_LH * h) * v.zoom;   // (nD3) cabe entero
      return [r[0] + FV_NAV_DET.BIG_CX * w + Lv * xr, r[1] + FV_NAV_DET.BIG_CY * h - Lv * up];
   }
   var L = w * 0.80, ca = Math.cos(0.62), sa = Math.sin(0.62);
   var x = r[0] + 0.07 * w + L * (m[0] + 0.55 * m[1] * ca), y = r[1] + 0.56 * h - L * (m[2] + 0.55 * m[1] * sa) * 1.0;
   return [x, y];
};
FVNavMap3D.prototype.pt = function(p, r) { var m = this.model(p); return m ? this.screen(m, r) : null; };
// ---------------------------------------------------------------------------
// (nD3, 4-nov-2026; Nino: «PROFUNDITAS debe tener mayor resolucion y detalle») NITIDEZ Y DETALLE DEL MAPA 3D
// · lo fijo se cachea en un Bitmap con el origen en un pixel ENTERO de la franja (antes se pintaba en r[0], r[1] fraccionarios, 176,93 / 8,83
//   en la prueba: el Bitmap entero se remuestreaba medio pixel y todo salia borroso); las rayas de 1 px caen en el centro del pixel
// · estrellas: las de la escena (no se inventa ninguna), tantas como quepan legibles por superficie del panel; tamaño y brillo por magnitud
//   G (relativa a la mas brillante del mapa) y color de la escena (BP-RP / foto); las mas brillantes del mapa grande con un halo
// · la losa de la nebulosa con la MINIATURA DE LA FOTO (afin exacta: el mapa es una proyeccion lineal, la losa un paralelogramo)
// · regla de distancias grabada: marcas finas 2…9 de cada decada, las decadas rotuladas, y el corte del cono en cada decada, muy tenue
// · rotulos de los objetos principales de MIRABILIA (pocos en la franja, mas en el grande) sin pisarse entre si ni con lo demas
// ---------------------------------------------------------------------------
var FV_NAV_DET = { STRIP_STARS: 1600, BIG_STARS: 4000, STRIP_PX: 12, BIG_PX: 110, STRIP_LAB: 2, CONE_DEG: 16, CONE_L: 4.2, BIG_LAB: 10, LAB_CH: 20,
                   THUMBS: [192, 384, 768, 1536], SLAB_OP: 0.88, BIG_L: 0.80, BIG_CX: 0.45, BIG_CY: 0.52, BIG_LH: 1.0 };
FVNavMap3D.prototype.setPhoto = function(bmp) { if (bmp === this.photo) return; this.photo = bmp || null; this.thumbs = {}; this.stat = null; };
// la miniatura de la foto con el lado largo >= px (escalones fijos: se hacen una vez; la de 1 536 sale de la foto y las demas de ella)
FVNavMap3D.prototype.photoThumb = function(px) {
   if (!this.photo) return null;
   var L = FV_NAV_DET.THUMBS, want = L[L.length - 1], i;
   for (i = 0; i < L.length; ++i) if (L[i] >= px) { want = L[i]; break; }
   if (!this.thumbs) this.thumbs = {};
   if (this.thumbs[want] !== undefined) return this.thumbs[want];
   var P = this.photo, src = P, s = want / Math.max(P.width, P.height), t = null;
   if (want < L[L.length - 1]) { var m = this.photoThumb(L[L.length - 1]); if (m) src = m; }
   if (s >= 1) t = P;
   else try { t = src.scaledTo(Math.max(2, Math.round(P.width * s)), Math.max(2, Math.round(P.height * s))); } catch (e) { t = null; }
   this.thumbs[want] = t;
   return t;
};
// la losa con la foto: Q = las cuatro esquinas en pantalla (arriba-izq, arriba-der, abajo-der, abajo-izq de la foto) -> true si la pinto
FVNavMap3D.prototype.photoSlab = function(g, Q, op) {
   var ax = Q[1][0] - Q[0][0], ay = Q[1][1] - Q[0][1], bx = Q[3][0] - Q[0][0], by = Q[3][1] - Q[0][1];
   if (Math.abs(ax * by - ay * bx) < 4) return false;                                     // de canto: no hay nada que ver
   var tb = this.photoThumb(Math.max(Math.sqrt(ax * ax + ay * ay), Math.sqrt(bx * bx + by * by)));
   if (!tb) return false;
   var bw = tb.width, bh = tb.height;
   g.opacity = op;
   g.transformationMatrix = new Matrix(ax / bw, bx / bh, Q[0][0], ay / bw, by / bh, Q[0][1], 0, 0, 1);
   g.drawBitmap(0, 0, tb);
   g.resetTransformation(); g.opacity = 1;
   return true;
};
function fvNavFree(occ, R, box) {
   if (box && (R[0] < box[0] || R[1] < box[1] || R[2] > box[2] || R[3] > box[3])) return false;
   for (var i = 0; i < occ.length; ++i) { var o = occ[i]; if (R[0] < o[2] && R[2] > o[0] && R[1] < o[3] && R[3] > o[1]) return false; }
   return true;
}
// (P23-mapas) donde se dibuja un objeto en el mapa 3D: su posicion de catalogo o, con FV_NAV.BOX_MAP, donde la camara va de verdad (escalado a la losa si cae mas alla de
// la boca: fvObjBoxK de fv_objects.js, el MISMO factor que el destino del viaje). Dentro de la caja devuelve o.pos tal cual (mismo array: ni un pixel de diferencia)
function fvNavObjK(sc, o) { return (FV_NAV.BOX_MAP && o && o.pos && typeof fvObjBoxK === "function") ? fvObjBoxK(sc, o) : 1; }
function fvNavObjPos(sc, o) {
   var k = fvNavObjK(sc, o);
   return (k === 1) ? o.pos : [o.pos[0] * k, o.pos[1] * k, o.pos[2] * k];
}
// la marca de «mas lejos»: dos chevrones «»» a la derecha de (x, y), de tamaño r
function fvNavFarMark(g, x, y, r, col) {
   var i, x0;
   g.pen = new Pen(col, Math.max(1, r * 0.34));
   for (i = 0; i < 2; ++i) { x0 = x + i * r * 0.9; g.drawLine(x0, y - r * 0.8, x0 + r * 0.7, y); g.drawLine(x0 + r * 0.7, y, x0, y + r * 0.8); }
}
// el rotulo de un objeto del mapa: el nombre y, si cae mas alla de la boca, « » 12,2 M a.l.» (la distancia VERDADERA, la de la ficha)
function fvNavFarText(o) {
   var d = o.distLy > 0 ? o.distLy : fvLen(o.pos);
   return " » " + (d >= 1e6 ? fvsFmtSig(d / 1e6, 3, FV_LANG) + " " + fvTx("gal.mly") : fvsFmtSig(d, 3, FV_LANG) + " " + fvTx("nav.ly"));
}
// el nombre corto de un objeto para su rotulo
function fvNavObjName(sc, o) {
   var L = FV_LANG === "es" ? "es" : "en", n = (o.names && o.names[L]) || o.name || o.id || "";
   if (o.main && sc.nebula) { var nn = sc.nebula.names; n = (nn && (nn[L] || nn.en)) || sc.nebula.name || n; }
   n = String(n);
   return n.length > FV_NAV_DET.LAB_CH ? n.substr(0, FV_NAV_DET.LAB_CH - 1) + "…" : n;
}
// (P28, 16-nov, FV_NAV.LABEL_FIX) la legibilidad de los rotulos de objeto. OFFS = cuanto se puede apartar el rotulo de su icono (px, × max(1, 0,8·kc)) probando las 8
// direcciones; PAD_1 = margen alrededor del texto que no pisa nada (variante 1); la placa (2 y 3): rectangulo redondeado de UNA pasada (con la pluma translucida de la
// 1718 las pasadas repetidas se acumulan) en tres capas de tamaño creciente = bordes difuminados; PLATE_A = alfa de cada capa (de dentro afuera), FEATHER = lo que crece cada capa
var FV_NAV_LABFIX = { OFFS: [0, 7, 14, 22, 32], PAD_1: 2, PAD_X: 0.45, PAD_Y: 0.16, PLATE_RGB: 0x0C0906, PLATE_A: [0x58, 0x40, 0x2c], FEATHER: 1.4, LEADER: 0x78E5B53F,
                      DIRS: [[1, 0], [-1, 0], [0, -1], [0, 1], [1, -1], [-1, -1], [1, 1], [-1, 1]] };
function fvNavPill(x0, y0, x1, y1) {
   var r = (y1 - y0) / 2, cs = [[x1 - r, y0 + r, -90], [x1 - r, y1 - r, 0], [x0 + r, y1 - r, 90], [x0 + r, y0 + r, 180]], pts = [], c, k, a;
   for (c = 0; c < 4; ++c) for (k = 0; k <= 6; ++k) { a = (cs[c][2] + 90 * k / 6) * FV_DEG; pts.push(new Point(cs[c][0] + r * Math.cos(a), cs[c][1] + r * Math.sin(a))); }
   return pts;
}
// la placa detras del texto (caja de tinta [x0, y0, x1, y1] ya con su margen)
function fvNavLabelPlate(g, x0, y0, x1, y1) {
   var F = FV_NAV_LABFIX, i, e;
   for (i = 0; i < F.PLATE_A.length; ++i) { e = (F.PLATE_A.length - 1 - i) * F.FEATHER; g.fillPolygon(fvNavPill(x0 - e, y0 - e, x1 + e, y1 + e), new Brush(((F.PLATE_A[i] << 24) | F.PLATE_RGB) >>> 0)); }
}
// donde poner el rotulo de un objeto (variantes 1, 2 y 3) -> { x, y (linea base), box (con margen), off } | null.
// fix 2: los 4 sitios de siempre (derecha, izquierda, arriba, abajo; el primero libre), pero con el margen de la placa. fix 1 y 3: 8 direcciones a distancias crecientes
// del icono; gana el que corta MENOS aristas del cono (cone8: [[x0, y0, x1, y1] ×8]) y, a igual numero, el mas cercano (la derecha, la izquierda, arriba, abajo...)
function fvNavLabelPlace(fix, occ, bounds, qo, ic, ow, oa, od, kc, cone8, cand4) {
   var F = FV_NAV_LABFIX, plate = (fix === 2 || fix === 3), px = plate ? (oa + od) * F.PAD_X : F.PAD_1, py = plate ? (oa + od) * F.PAD_Y + 1 : F.PAD_1, ks = Math.max(1, 0.8 * kc), best = null, bs = 1e9, i, j, k, bx;
   function mk(x, y) { var cx = Math.round(x), cy = Math.round(y); return { x: cx, y: cy, box: [cx - px, cy - oa - py, cx + ow + px, cy + od + py], off: 0 }; }
   if (fix === 2) {
      for (j = 0; j < cand4.length; ++j) { var t = mk(cand4[j][0], cand4[j][1]); if (fvNavFree(occ, t.box, bounds)) return t; }
      // si con el margen de la placa no cabe en ninguno, el criterio de siempre (la caja de tinta ± 1 px): mejor una placa apretada que perder el rotulo
      for (j = 0; j < cand4.length; ++j) { var t3 = mk(cand4[j][0], cand4[j][1]); if (fvNavFree(occ, [t3.x - 1, t3.y - oa - 1, t3.x + ow + 1, t3.y + 2], bounds)) return t3; }
      return null;
   }
   for (k = 0; k < F.OFFS.length; ++k) for (j = 0; j < F.DIRS.length; ++j) {
      var d = F.DIRS[j], off = F.OFFS[k] * ks, ax = qo[0] + d[0] * (ic + off), ay = qo[1] + d[1] * (ic + off), lx = d[0] > 0 ? ax : (d[0] < 0 ? ax - ow : ax - ow / 2), ty = d[1] < 0 ? ay - (oa + od) : (d[1] > 0 ? ay : ay - (oa + od) / 2);
      var t2 = mk(lx, ty + oa); t2.off = off;
      if (!fvNavFree(occ, t2.box, bounds)) continue;
      var cr = 0; bx = [t2.box[0] + px - 1, t2.box[1] + py - 1, t2.box[2] - px + 1, t2.box[3] - py + 1];
      for (i = 0; i < cone8.length; ++i) if (fvNavClip(cone8[i][0], cone8[i][1], cone8[i][2], cone8[i][3], bx)) ++cr;
      var sc = cr * 1000 + k * 8 + j;
      if (sc < bs) { bs = sc; best = t2; }
   }
   return best;
}
// lo fijo (cono, regla, losa con la foto, estrellas, rotulos, Tierra) en un Bitmap. (ox, oy) = la parte fraccionaria del origen del panel:
// el Bitmap se pinta en el pixel entero y su dibujo va desplazado lo que falta, asi lo fijo y lo vivo coinciden al decimo de pixel
FVNavMap3D.prototype.buildStatic = function(w, h, kc, ox, oy) {
   ox = ox || 0; oy = oy || 0;
   var b = new Bitmap(Math.max(8, Math.ceil(w + ox) + 1), Math.max(8, Math.ceil(h + oy) + 1), BitmapFormat.ARGB32), r = [ox, oy, ox + w, oy + h];
   var sc = this.scene, S = sc.stars, N = sc.nebula, big = !!this.view, i, j, self = this, occ = [];
   b.fill(0x00000000);
   var g = new Graphics(b);
   try {
      g.antialiasing = true; g.textAntialiasing = true; g.smoothInterpolation = true;
      function M(s, a, bb) { return self.screen([s, a * 0.30 * s, -bb * 0.30 * s * (self.hy / self.hx)], r); }
      function px(v) { return Math.floor(v) + 0.5; }                                         // una raya de 1 px en el centro del pixel
      var lw = big ? Math.max(1, 0.55 * kc) : 1;
      var fN = cpFont("text", big ? Math.max(9, 5.6 * kc) : Math.max(8, 8 * kc), false, true);        // cifras y rotulos
      var fO = cpFont("text", big ? Math.max(10, 6.2 * kc) : Math.max(8, 8 * kc), false, true);
      // lo reservado: arriba a la izquierda las distancias (vivas) y abajo a la izquierda el rotulo del panel (franja) o la botonera (grande)
      if (big) { occ.push([0, 0, 0.62 * w + ox, 0.09 * h + oy]); occ.push([0.25 * w + ox, 0.88 * h + oy, 0.75 * w + ox, h + oy]); occ.push([ox, 0.86 * h + oy, 0.30 * w + ox, h + oy]); }
      else { occ.push([0, 0, 0.75 * w + ox, 22 * kc + oy]); occ.push([0, h - 11 * kc + oy, 0.55 * w + ox, h + oy]); }
      // 1. el cono: las cuatro aristas y la boca (1 px nitido), y su corte en cada decada, muy tenue (grabado)
      var E = M(0, 0, 0), C = [M(1, -1, -1), M(1, 1, -1), M(1, 1, 1), M(1, -1, 1)];
      var dec = []; for (var t = 1; t <= 1e6; t *= 10) if (t >= this.d0 * 1.5 && t <= this.dMax * 1.02) dec.push(t);
      g.pen = new Pen(big ? 0x34C99A3A : 0x2cC99A3A, lw);
      for (i = 0; i < dec.length; ++i) { var sd = this.depth(dec[i]), Dq = [M(sd, -1, -1), M(sd, 1, -1), M(sd, 1, 1), M(sd, -1, 1)]; g.drawPolyline([new Point(Dq[0][0], Dq[0][1]), new Point(Dq[1][0], Dq[1][1]), new Point(Dq[2][0], Dq[2][1]), new Point(Dq[3][0], Dq[3][1]), new Point(Dq[0][0], Dq[0][1])]); }
      g.pen = new Pen(0x90C99A3A, lw);
      for (i = 0; i < 4; ++i) g.drawLine(E[0], E[1], C[i][0], C[i][1]);
      for (i = 0; i < 4; ++i) g.drawLine(C[i][0], C[i][1], C[(i + 1) % 4][0], C[(i + 1) % 4][1]);
      // 2. la nebulosa: la losa a su distancia, con la miniatura de la foto (o lisa si no hay foto), y su borde
      if (N) {
         var sN = this.depth(N.distLy), Q = [this.slabPt(sN, -1, -1, r), this.slabPt(sN, 1, -1, r), this.slabPt(sN, 1, 1, r), this.slabPt(sN, -1, 1, r)];
         var QP = [new Point(Q[0][0], Q[0][1]), new Point(Q[1][0], Q[1][1]), new Point(Q[2][0], Q[2][1]), new Point(Q[3][0], Q[3][1])];
         g.fillPolygon(QP, new Brush(0x40B0506A));
         this.slabPhoto = this.photoSlab(g, Q, FV_NAV_DET.SLAB_OP);
         g.pen = new Pen(0xb0E08AA0, lw); g.drawPolyline(QP.concat([QP[0]]));
      }
      // 3. las estrellas: las mas brillantes del campo, tantas como quepan por superficie; tamaño y opacidad por magnitud, color de la escena
      if (S) {
         var idx = []; for (i = 0; i < S.n; ++i) if (S.inFrame[i]) idx.push(i);
         idx.sort(function(x, y) { return S.g[x] - S.g[y]; });
         var nMax = big ? Math.min(FV_NAV_DET.BIG_STARS, Math.round(w * h / FV_NAV_DET.BIG_PX)) : Math.min(FV_NAV_DET.STRIP_STARS, Math.round(w * h / FV_NAV_DET.STRIP_PX));
         idx = idx.slice(0, Math.max(FV_NAV.MAP_STARS, nMax)); this.nStars = idx.length;
         var gB = idx.length ? S.g[idx[0]] : 6, gF = idx.length ? S.g[idx[idx.length - 1]] : 16, gR = Math.max(1, gF - gB);
         var rMax = big ? 2.2 * kc : 1.7 * Math.max(1, kc), rMin = big ? 0.6 : 0.42;
         for (j = idx.length - 1; j >= 0; --j) {
            var k = idx[j], q = this.pt(fvStarPos(sc, k), r); if (!q) continue;
            var u = 1 - fvClamp((S.g[k] - gB) / gR, 0, 1), rr = rMin + (rMax - rMin) * u * u, al = (0.30 + 0.70 * Math.pow(u, 1.2)) * (S.q[k] === 2 ? 0.55 : 1), c = S.col[k] & 0xffffff;
            if (big && u > 0.82) g.fillCircle(q[0], q[1], rr * 3, new RadialGradientBrush(new Point(q[0], q[1]), rr * 3, new Point(q[0], q[1]), [[0, ((Math.round(0x50 * al) << 24) | c) >>> 0], [1, c >>> 0]]));
            g.fillCircle(q[0], q[1], rr, new Brush(((Math.round(255 * al) << 24) | c) >>> 0));
         }
      }
      // 4. la regla de distancias: por debajo del cono (b = 1,15), marcas finas 2…9 y las decadas mas largas y rotuladas
      var R0 = M(this.depth(this.d0 * 1.5), 0, 1.15), R1 = M(1.0, 0, 1.15);
      g.pen = new Pen(0x70E5B53F, lw); g.drawLine(R0[0], R0[1], R1[0], R1[1]);
      g.font = fN;
      for (i = 0; i < dec.length; ++i) {
         for (j = 1; j <= 9; ++j) {
            var dt = dec[i] * j; if (dt > this.dMax || dt < this.d0 * 1.5) continue;
            var tq = M(this.depth(dt), 0, 1.15), tl = (j === 1 ? 3.6 : (j === 5 ? 2.4 : 1.6)) * (big ? 0.75 * kc : Math.max(1, kc)), xx = px(tq[0]);
            g.pen = new Pen(j === 1 ? 0xd0E5B53F : 0x80E5B53F, 1); g.drawLine(xx, tq[1] - tl, xx, tq[1] + tl);
         }
         var tk = M(this.depth(dec[i]), 0, 1.15), lab = fvNum(dec[i], 0), lwd = fN.width(lab), tkM = Math.ceil(3.6 * (big ? 0.75 * kc : Math.max(1, kc))) + 2;   // la cifra, por debajo de la marca (no cruzada por ella)
         var LR = [tk[0] - lwd / 2 - 1, tk[1] + tkM, tk[0] + lwd / 2 + 1, tk[1] + tkM + 1 + fN.ascent];
         if (fvNavFree(occ, LR, [0, 0, w + ox, h + oy])) { g.pen = new Pen(0xd8D0C1A5); g.drawText(Math.round(tk[0] - lwd / 2), Math.round(tk[1] + tkM + fN.ascent), lab); occ.push(LR); }
      }
      // la distancia de la nebulosa, encima de la esquina de la losa
      if (N) {
         var tn = M(this.depth(N.distLy), 1.05, -1.05), nl = fvsFmtSig(N.distLy, 3, FV_LANG) + " " + fvTx("nav.ly"), nw = fN.width(nl);
         var nx = Math.round(Math.min(w + ox - nw - 2, tn[0] - nw / 2)), ny = Math.round(Math.max(fN.ascent + 1, tn[1] - 3));
         g.font = fN; g.pen = new Pen(0xf0E8A0B4); g.drawText(nx, ny, nl); occ.push([nx - 1, ny - fN.ascent - 1, nx + nw + 1, ny + 2]);
      }
      // 5. la Tierra
      g.fillCircle(E[0], E[1], 2.6 * Math.max(1, kc * (big ? 0.7 : 1)), new Brush(0xff6FA8DC)); g.pen = new Pen(0xff2A4A6A, 0.8); g.drawCircle(E[0], E[1], 2.6 * Math.max(1, kc * (big ? 0.7 : 1)));
      g.font = fN; g.pen = new Pen(0xe06FA8DC); var tE = [Math.round(E[0] - 2), Math.round(E[1] + 5 + fN.ascent)]; g.drawText(tE[0], tE[1], "TERRA"); occ.push([tE[0] - 1, tE[1] - fN.ascent - 1, tE[0] + fN.width("TERRA") + 1, tE[1] + 2]);
      // 6. los iconos de los objetos (antes en cada fotograma: ahora en lo fijo; el elegido se repinta claro encima) y sus rotulos
      if (sc.objects) for (i = 0; i < Math.min(sc.objects.length, FV_NAV.LIST_MAX); ++i) { var oi = sc.objects[i]; if (!oi.pos) continue; var ki = fvNavObjK(sc, oi), qi = this.pt(ki === 1 ? oi.pos : fvNavObjPos(sc, oi), r); if (qi) { fvNavIcon(g, fvNavMapIcon(oi), qi[0], qi[1], 3.2 * kc, 0xd0E5B53F); if (ki < 1) fvNavFarMark(g, qi[0] + 3.2 * kc + 1.5, qi[1], 2.2 * kc, 0xd0E5B53F); } }
      // los rotulos de los objetos principales (por singularidad, como MIRABILIA): a la derecha, izquierda, arriba o abajo, donde quepa
      if (sc.objects && sc.objects.length) {
         var nL = 0, maxL = big ? FV_NAV_DET.BIG_LAB : FV_NAV_DET.STRIP_LAB, ic = (big ? 3.2 * kc : 3.2 * kc) + 2, fix = (FV_NAV.LABEL_FIX | 0), cone8 = [];
         // (P28) las 8 aristas del cono (4 de la Tierra a la boca y las 4 de la boca): lo que la colocacion 1 y 3 procura no cruzar
         if (fix === 1 || fix === 3) for (i = 0; i < 4; ++i) { cone8.push([E[0], E[1], C[i][0], C[i][1]]); cone8.push([C[i][0], C[i][1], C[(i + 1) % 4][0], C[(i + 1) % 4][1]]); }
         for (i = 0; i < sc.objects.length && nL < maxL; ++i) {
            var o = sc.objects[i]; if (!o.pos || (!big && (o.type === "exoplanet" || o.type === "star"))) continue;   // en la franja, solo los objetos (no estrellas)
            var ko = fvNavObjK(sc, o), qo = this.pt(ko === 1 ? o.pos : fvNavObjPos(sc, o), r); if (!qo) continue;
            var nm = fvNavObjName(sc, o); if (!nm) continue;
            // en el mapa grande el rotulo lleva la distancia verdadera; en la franja (pocos pixeles) solo el nombre y los chevrones del icono
            if (ko < 1 && big) nm += fvNavFarText(o);
            // (P23-mapas) con la marca «»» tras el icono, el rotulo a la derecha empieza mas lejos
            var icL = (ko < 1) ? ic + 7 * kc + 2 : ic;
            var ow = fO.width(nm), oa = fO.ascent, cand = [[qo[0] + icL, qo[1] + oa / 2 - 1], [qo[0] - icL - ow, qo[1] + oa / 2 - 1], [qo[0] - ow / 2, qo[1] - icL - 1], [qo[0] - ow / 2, qo[1] + icL + oa]];
            if (fix === 0) {
               for (j = 0; j < cand.length; ++j) {
                  var cx0 = Math.round(cand[j][0]), cy0 = Math.round(cand[j][1]), RR = [cx0 - 1, cy0 - oa - 1, cx0 + ow + 1, cy0 + 2];
                  if (!fvNavFree(occ, RR, [ox + 1, oy + 1, w + ox - 1, h + oy - 1])) continue;
                  g.font = fO; g.pen = new Pen(0xd0000000); g.drawText(cx0 + 1, cy0 + 1, nm); g.pen = new Pen(o.main ? 0xffF0B8C8 : 0xffF3D27E); g.drawText(cx0, cy0, nm);
                  occ.push(RR); ++nL; break;
               }
            } else {
               var pl = fvNavLabelPlace(fix, occ, [ox + 1, oy + 1, w + ox - 1, h + oy - 1], qo, icL, ow, oa, fO.descent, kc, cone8, cand);
               if (!pl) continue;
               if (fix === 2 || fix === 3) fvNavLabelPlate(g, pl.box[0], pl.box[1], pl.box[2], pl.box[3]);
               if (pl.off > 0) {
                  // la linea guia: del borde del icono al punto mas cercano de la caja del texto (fina, dorada y tenue)
                  var gx = fvClamp(qo[0], pl.x, pl.x + ow), gy = fvClamp(qo[1], pl.y - oa, pl.y + fO.descent), gl = Math.sqrt((gx - qo[0]) * (gx - qo[0]) + (gy - qo[1]) * (gy - qo[1])) || 1;
                  g.pen = new Pen(FV_NAV_LABFIX.LEADER, 1); g.drawLine(qo[0] + (gx - qo[0]) / gl * (ic - 1), qo[1] + (gy - qo[1]) / gl * (ic - 1), gx, gy);
               }
               g.font = fO; g.pen = new Pen(0xd0000000); g.drawText(pl.x + 1, pl.y + 1, nm); g.pen = new Pen(o.main ? 0xffF0B8C8 : 0xffF3D27E); g.drawText(pl.x, pl.y, nm);
               occ.push(pl.box); ++nL;
            }
         }
         this.nLabels = nL;
      }
   } finally { g.end(); }
   this.stat = b;
};
// ---------------------------------------------------------------------------
// (N2, punto 1 de Nino: «no se ve bien por donde vas») LA NAVE, SU ESTELA Y SU DESTINO, en TABULA y en PROFUNDITAS
// ---------------------------------------------------------------------------
var FV_NAV_COL = { ship: 0xffFFF3C4, gold: 0xffF3D27E, dest: 0xffFF8A5A, ink: 0xff2A1F15, casing: 0xc0000000 };
// la estela: cada ~0,1 s de reloj de escena, si la nave se ha movido, un punto (posicion del mundo); caduca a TRAIL_S s o TRAIL_N puntos
function fvNavTrailPush(tr, P, scene) {
   var pos = P.cam.pos, t = P.t, n = tr.length, dRef = (scene && scene.nebula) ? scene.nebula.distLy : 1000;
   if (n && t < tr[n - 1].t) { tr.length = 0; n = 0; }
   if (!n || (t - tr[n - 1].t >= 0.1 && fvLen(fvSub(pos, tr[n - 1].p)) > 0.0002 * dRef)) tr.push({ p: pos.slice(), t: t });
   while (tr.length && (t - tr[0].t > FV_NAV.TRAIL_S || tr.length > FV_NAV.TRAIL_N)) tr.shift();
}
// el destino de un viaje en curso (posicion del objeto elegido), o null (parado, vista inicial, giro suave)
function fvNavDest(P) {
   var fl = P ? P.flight : null;
   if (!fl || !fl.sel || fl.kind === "home" || fl.kind === "look") return null;
   try { return fvSelPos(P, fl.sel); } catch (e) { return null; }
}
// segmento (x0,y0)-(x1,y1) recortado al rectangulo r = [x0, y0, x1, y1] (Liang-Barsky) -> [x0, y0, x1, y1] | null
function fvNavClip(ax, ay, bx, by, r) {
   var t0 = 0, t1 = 1, dx = bx - ax, dy = by - ay, p = [-dx, dx, -dy, dy], q = [ax - r[0], r[2] - ax, ay - r[1], r[3] - ay];
   for (var i = 0; i < 4; ++i) {
      if (Math.abs(p[i]) < 1e-12) { if (q[i] < 0) return null; continue; }
      var u = q[i] / p[i];
      if (p[i] < 0) { if (u > t1) return null; if (u > t0) t0 = u; } else { if (u < t0) return null; if (u < t1) t1 = u; }
   }
   return [ax + t0 * dx, ay + t0 * dy, ax + t1 * dx, ay + t1 * dy];
}
// poligono [[x, y]…] recortado al rectangulo r = [x0, y0, x1, y1] (Sutherland-Hodgman) -> [[x, y]…] (vacio si queda fuera)
function fvNavClipPoly(poly, r) {
   var out = poly, e, i;
   for (e = 0; e < 4 && out.length; ++e) {
      var inp = out, a, b, ia, ib; out = [];
      function inside(p) { return e === 0 ? p[0] >= r[0] : (e === 1 ? p[0] <= r[2] : (e === 2 ? p[1] >= r[1] : p[1] <= r[3])); }
      function cut(p, q) {
         var t = e < 2 ? ((e === 0 ? r[0] : r[2]) - p[0]) / (q[0] - p[0]) : ((e === 2 ? r[1] : r[3]) - p[1]) / (q[1] - p[1]);
         return [p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])];
      }
      for (i = 0; i < inp.length; ++i) {
         a = inp[i]; b = inp[(i + 1) % inp.length]; ia = inside(a); ib = inside(b);
         if (ia && ib) out.push(b); else if (ia && !ib) out.push(cut(a, b)); else if (!ia && ib) { out.push(cut(a, b)); out.push(b); }
      }
   }
   return out;
}
function fvNavDash(g, ax, ay, bx, by, on, off) {
   var dx = bx - ax, dy = by - ay, L = Math.sqrt(dx * dx + dy * dy), s = 0;
   if (L < 1) return;
   dx /= L; dy /= L;
   while (s < L) { var e = Math.min(L, s + on); g.drawLine(ax + dx * s, ay + dy * s, ax + dx * e, ay + dy * e); s += on + off; }
}
// la nave: punta de flecha de laton claro con filo oscuro y un halo; (ux, uy) = hacia donde mira (unitario)
function fvNavShipGlyph(g, x, y, ux, uy, S, col) {
   if (typeof fvBoundsShipIcon === "function" && fvBoundsShipIcon(g, x, y, ux, uy, S, col)) return;   // (9-nov, encargo C3) la silueta de la nave (FV_BOUNDS.ICON)
   var nx = -uy, ny = ux, c = col || FV_NAV_COL.ship;
   g.fillCircle(x, y, S * 2.0, new RadialGradientBrush(new Point(x, y), S * 2.0, new Point(x, y), [[0, 0x90FFF3C4], [1, 0x00FFF3C4]]));
   var tri = [new Point(x + ux * S * 1.5, y + uy * S * 1.5), new Point(x - ux * S * 0.9 + nx * S * 0.9, y - uy * S * 0.9 + ny * S * 0.9),
              new Point(x - ux * S * 0.35, y - uy * S * 0.35), new Point(x - ux * S * 0.9 - nx * S * 0.9, y - uy * S * 0.9 - ny * S * 0.9)];
   g.fillPolygon(tri, new Brush(c));
   g.pen = new Pen(FV_NAV_COL.ink, Math.max(1, S * 0.24)); g.drawPolyline(tri.concat([tri[0]]));
}
// el destino: anillo con cuatro marcas (como una mira), en bermellon claro con filo oscuro
function fvNavDestGlyph(g, x, y, S) {
   var i, a;
   for (var pass = 0; pass < 2; ++pass) {
      g.pen = new Pen(pass === 0 ? FV_NAV_COL.casing : FV_NAV_COL.dest, Math.max(1, S * (pass === 0 ? 0.55 : 0.3)));
      g.drawCircle(x, y, S);
      for (i = 0; i < 4; ++i) { a = i * Math.PI / 2; g.drawLine(x + Math.cos(a) * S * 0.6, y + Math.sin(a) * S * 0.6, x + Math.cos(a) * S * 1.7, y + Math.sin(a) * S * 1.7); }
   }
}
// una marca en el borde del panel r hacia un punto de fuera (px, py): triangulo que apunta hacia fuera -> [x, y]
function fvNavEdgeMark(g, r, px, py, S, col) {
   var cx = (r[0] + r[2]) / 2, cy = (r[1] + r[3]) / 2, dx = px - cx, dy = py - cy, L = Math.sqrt(dx * dx + dy * dy) || 1;
   var hw = (r[2] - r[0]) / 2 - S * 1.5, hh = (r[3] - r[1]) / 2 - S * 1.5;
   var t = Math.min(hw / Math.max(1e-6, Math.abs(dx)), hh / Math.max(1e-6, Math.abs(dy)));
   var x = cx + dx * t, y = cy + dy * t, ux = dx / L, uy = dy / L, nx = -uy, ny = ux;
   var tri = [new Point(x + ux * S * 1.5, y + uy * S * 1.5), new Point(x - ux * S * 0.7 + nx * S * 1.1, y - uy * S * 0.7 + ny * S * 1.1), new Point(x - ux * S * 0.7 - nx * S * 1.1, y - uy * S * 0.7 - ny * S * 1.1)];
   g.fillPolygon(tri, new Brush(col));
   g.pen = new Pen(FV_NAV_COL.ink, Math.max(1, S * 0.24)); g.drawPolyline(tri.concat([tri[0]]));
   return [x, y];
}
// la fraccion de la foto (0…1 en u, v) que cae dentro del poligono de lo que ve la camara (rejilla de 16 × 10, par-impar)
function fvNavCover(poly) {
   if (!poly || poly.length < 3) return 0;
   var n = 0, tot = 0, i, j, a, b;
   for (var y = 0; y < 10; ++y) for (var x = 0; x < 16; ++x) {
      var u = (x + 0.5) / 16, v = (y + 0.5) / 10, inside = false; ++tot;
      for (i = 0, j = poly.length - 1; i < poly.length; j = i++) { a = poly[i]; b = poly[j]; if (((a[1] > v) !== (b[1] > v)) && (u < (b[0] - a[0]) * (v - a[1]) / (b[1] - a[1]) + a[0])) inside = !inside; }
      if (inside) ++n;
   }
   return n / tot;
}
function fvNavBoxArea(poly) { var a = 1e9, b = -1e9, c = 1e9, d = -1e9; for (var i = 0; i < poly.length; ++i) { a = Math.min(a, poly[i][0]); b = Math.max(b, poly[i][0]); c = Math.min(c, poly[i][1]); d = Math.max(d, poly[i][1]); } return poly.length ? (b - a) * (d - c) : 0; }

// un fotograma: lo fijo + objetos (C) + la nave y su mirada + (N2) estela, destino, distancias y la escala
FVNavMap3D.prototype.paint = function(g, r, P, kc, sel, trail) {
   // (nD3) lo fijo se pinta en un pixel ENTERO (antes en r[0], r[1] fraccionarios: el Bitmap se remuestreaba y salia borroso)
   var w = r[2] - r[0], h = r[3] - r[1], X0 = Math.floor(r[0]), Y0 = Math.floor(r[1]), ox = r[0] - X0, oy = r[1] - Y0;
   var key = Math.round(w) + "x" + Math.round(h) + "|" + this.viewKey() + "|" + kc.toFixed(3) + "|" + ox.toFixed(2) + "," + oy.toFixed(2) + "|" + (this.photo ? 1 : 0) + "|" + FV_LANG;   // (nD2) la vista y la inclinacion rehacen lo fijo; (Blender 5 · H8) y el idioma: la distancia de la losa («6 540 ly» / «a.l.») es parte de lo fijo y se quedaba en el idioma anterior
   if (!this.stat || this.statKey !== key) { this.buildStatic(w, h, kc, ox, oy); this.statKey = key; }
   g.drawBitmap(X0, Y0, this.stat);
   if (typeof fvBoundsMap3D === "function") fvBoundsMap3D(this, g, r, P, kc);   // (9-nov, encargo C2) los planos que limitan la imagen (FV_BOUNDS.MAP)
   var sc = this.scene, i;
   // (nD3) los iconos de los objetos van en lo fijo; aqui solo el elegido, claro, encima
   if (sel && sel.kind === "object" && sc.objects && sel.i < Math.min(sc.objects.length, FV_NAV.LIST_MAX) && sc.objects[sel.i].pos) { var qo = this.pt(fvNavObjPos(sc, sc.objects[sel.i]), r); if (qo) { fvNavIcon(g, fvNavMapIcon(sc.objects[sel.i]), qo[0], qo[1], 3.2 * kc, 0xffFFE9A8); if (fvNavObjK(sc, sc.objects[sel.i]) < 1) fvNavFarMark(g, qo[0] + 3.2 * kc + 1.5, qo[1], 2.2 * kc, 0xffFFE9A8); } }
   if (sel && sel.kind === "star" && sc.stars) { var qs = this.pt(fvStarPos(sc, sel.i), r); if (qs) { g.pen = new Pen(0xffF3D27E, Math.max(0.8, kc)); g.drawCircle(qs[0], qs[1], 3.5 * kc); } }
   if (!P) return;
   // la nave: punta de flecha grande hacia donde mira; la linea Tierra → nave → destino; la estela; su profundidad en el eje (la escala)
   var pos = P.cam.pos, E = this.screen([0, 0, 0], r), q0 = this.pt(pos, r) || E, d0 = fvLen(pos), step = Math.max(0.5, 0.25 * d0, 0.08 * this.dMax);
   var dest = fvNavDest(P), qd = dest ? this.pt(dest, r) : null, pts, a, n;
   var q1 = this.pt(fvAdd(pos, fvMul(fvNorm(P.cam.look), step)), r) || [q0[0] + 10, q0[1]];
   var dx = q1[0] - q0[0], dy = q1[1] - q0[1], dl = Math.sqrt(dx * dx + dy * dy) || 1, ux = dx / dl, uy = dy / dl, S = Math.max(7.5, 8.2 * kc);
   if (d0 > 1e-3) {
      g.pen = new Pen(0x60E5B53F, Math.max(1, 1.1 * kc)); g.drawLine(E[0], E[1], q0[0], q0[1]);                        // la Tierra → la nave
      var ax = this.screen([this.depth(d0), 0, 0], r);                                                                   // su profundidad en el eje: la escala
      g.pen = new Pen(FV_NAV_COL.gold, Math.max(1, 1.2 * kc)); g.drawLine(ax[0], ax[1] - 4 * kc, ax[0], ax[1] + 4 * kc);
      g.fillPolygon([new Point(ax[0], ax[1] - 1), new Point(ax[0] - 3 * kc, ax[1] - 6 * kc), new Point(ax[0] + 3 * kc, ax[1] - 6 * kc)], new Brush(FV_NAV_COL.gold));
   }
   // (nD3) el cono de vision de la nave, nitido: una cuña de 1 px hacia donde mira. (Medido el 4-nov: su piramide real, 40°, es mucho mas
   // ancha que la foto y en el mapa —que exagera lo lateral— llenaba el panel de arriba abajo. La cuña dice hacia donde, no cuanto.)
   var wa = FV_NAV_DET.CONE_DEG * FV_DEG, wl = S * FV_NAV_DET.CONE_L, cwa = Math.cos(wa), swa = Math.sin(wa);
   var Wd = [new Point(q0[0], q0[1]), new Point(q0[0] + (ux * cwa - uy * swa) * wl, q0[1] + (uy * cwa + ux * swa) * wl), new Point(q0[0] + (ux * cwa + uy * swa) * wl, q0[1] + (uy * cwa - ux * swa) * wl)];
   g.fillPolygon(Wd, new Brush(0x2cF3D27E)); g.pen = new Pen(0xa8F3D27E, 1); g.drawPolyline(Wd.concat([Wd[0]]));
   this.lastCone = [[Wd[0].x, Wd[0].y], [Wd[1].x, Wd[1].y], [Wd[2].x, Wd[2].y]];
   if (trail && trail.length > 1) {          // la estela: mas tenue cuanto mas vieja
      pts = []; for (n = 0; n < trail.length; ++n) { var qt = this.pt(trail[n].p, r); if (qt) pts.push(qt); }
      pts.push(q0);
      for (n = 1; n < pts.length; ++n) { a = Math.round(0x38 + 0xc7 * n / (pts.length - 1)); g.pen = new Pen(((a << 24) | 0xFFF3C4) >>> 0, Math.max(1.6, 2.2 * kc)); g.drawLine(pts[n - 1][0], pts[n - 1][1], pts[n][0], pts[n][1]); }
   }
   if (qd) {                                  // nave → destino (a trazos) y su marca
      g.pen = new Pen(0xd0FF8A5A, Math.max(1, 1.2 * kc)); fvNavDash(g, q0[0], q0[1], qd[0], qd[1], 3 * kc, 2.4 * kc);
   }
   g.pen = new Pen(FV_NAV_COL.gold, Math.max(1, 1.2 * kc)); g.drawLine(q0[0], q0[1], q0[0] + ux * S * 3.4, q0[1] + uy * S * 3.4);      // la mirada
   fvNavShipGlyph(g, q0[0], q0[1], ux, uy, S);
   if (qd) fvNavDestGlyph(g, qd[0], qd[1], Math.max(5, 5.6 * kc));          // encima de la nave: cerca del destino se taparia
   // las distancias (arriba a la izquierda): de la Tierra a la nave y de la nave al destino
   var fL = cpFont("text", Math.max(8, 7.2 * kc)), rows = [], yy = r[1] + 3 * kc;
   // (Blender 5b · R5-8.6) la MISMA cifra que DISTANTIA (la distancia de la nave a la Tierra): «6 517», no «6 520» (3 cifras) frente a «6 517» del dial
   if (d0 > 0.01) rows.push([fvTx("nav.ship") + " " + ((FV_B5B.DIST && typeof fvFmtLy === "function") ? fvFmtLy(d0) + " " + fvTx("nav.ly") : fvNavDistText(d0, "measured", FV_LANG)), FV_NAV_COL.gold]);
   if (dest) rows.push([fvTx("nav.dest") + " " + fvNavDistText(fvLen(fvSub(dest, pos)), "measured", FV_LANG), 0xffFF9A7A]);
   g.font = fL;
   if (this.view) yy = r[3] - 3 * kc - rows.length * 10 * kc - 0.12 * h;     // (nD3) en el grande, abajo a la izquierda
   yy = Math.round(yy);
   for (n = 0; n < rows.length; ++n) {
      g.fillRect(r[0] + 2 * kc, yy, r[0] + 6 * kc + fL.width(rows[n][0]), yy + 9 * kc, new Brush(0xc0110D09));
      g.pen = new Pen(rows[n][1]); g.drawText(r[0] + 4 * kc, yy + 7.2 * kc, rows[n][0]); yy += 10 * kc;
   }
};

// ---------------------------------------------------------------------------
// LA MINIATURA 2D
// ---------------------------------------------------------------------------
function FVNavMap2D(photo) { this.photo = photo; this.thumb = null; this.key = ""; }
// (N2, punto 1 de Nino) TABULA: la foto, la HUELLA de lo que ve la camara (relleno suave + contorno con filo oscuro + la mira del centro),
// la ESTELA corta de la nave, el DESTINO del viaje (mira bermellon + linea a trazos desde la nave), el objeto elegido, y la NAVE como punta
// de flecha grande hacia donde mira. En casa, un anillo en el centro de la huella («estas aqui»). Si la nave sale del rectangulo de la
// foto, una flecha en el borde hacia donde esta y el rotulo «NAVE FUERA DE LA FOTO»; lo mismo con un destino fuera.
FVNavMap2D.prototype.paint = function(g, r, scene, P, kc, trail) {
   var w = Math.max(4, Math.round(r[2] - r[0])), h = Math.max(4, Math.round(r[3] - r[1])), key = w + "x" + h;
   if (this.photo && (!this.thumb || this.key !== key)) { try { this.thumb = this.photo.scaledTo(w, h); } catch (e) { this.thumb = null; } this.key = key; }
   if (this.thumb) g.drawBitmap(r[0], r[1], this.thumb); else g.fillRect(r[0], r[1], r[2], r[3], new Brush(0xff07060A));
   if (!scene || !P) return;
   var F = fvNavFov(scene, P), x0 = r[0], y0 = r[1], panel = [x0, y0, x0 + w, y0 + h], i, n, a, pos = P.cam.pos, home = fvLen(pos) < 1e-6, S = Math.max(9, 10 * kc), gold = FV_NAV_COL.gold;
   function X(u) { return x0 + fvClamp(u, -0.02, 1.02) * w; }
   function Y(v) { return y0 + fvClamp(v, -0.02, 1.02) * h; }
   function XR(u) { return x0 + u * w; }          // sin recortar (para saber si algo cae fuera)
   function YR(v) { return y0 + v * h; }
   function inside(uv) { return !!uv && uv[0] >= 0 && uv[0] <= 1 && uv[1] >= 0 && uv[1] <= 1; }
   g.antialiasing = true;
   // 1. la huella de lo que ve la camara
   F.cover = F.away ? 0 : fvNavCover(F.poly); F.big = F.away ? 0 : fvNavBoxArea(F.poly);
   F.drawn = !F.away && F.cover < 0.97 && F.big < 3;
   if (F.drawn) {
      // la huella con su geometria verdadera, recortada al panel (antes los vertices se aplastaban contra el borde y salian rayas falsas)
      var fp = [], cpoly, cs0, nP;
      for (i = 0; i < F.poly.length; ++i) fp.push([XR(F.poly[i][0]), YR(F.poly[i][1])]);
      cpoly = fvNavClipPoly(fp, panel);
      if (cpoly.length >= 3) { var pts = []; for (i = 0; i < cpoly.length; ++i) pts.push(new Point(cpoly[i][0], cpoly[i][1])); g.fillPolygon(pts, new Brush(0x2AF3D27E)); }
      for (var pass = 0; pass < 2; ++pass) {
         g.pen = pass === 0 ? new Pen(FV_NAV_COL.casing, Math.max(2.4, 3 * kc)) : new Pen(gold, Math.max(1.4, 1.6 * kc));
         for (i = 0, nP = fp.length; i < nP; ++i) { cs0 = fvNavClip(fp[i][0], fp[i][1], fp[(i + 1) % nP][0], fp[(i + 1) % nP][1], panel); if (cs0) g.drawLine(cs0[0], cs0[1], cs0[2], cs0[3]); }
      }
      if (F.look) { var lx = X(F.look[0]), ly = Y(F.look[1]), c = 3.2 * kc; g.pen = new Pen(gold, Math.max(1, 1.2 * kc)); g.drawLine(lx - c, ly, lx + c, ly); g.drawLine(lx, ly - c, lx, ly + c); }
   } else if (!F.away) {                  // lo que ve cubre casi toda la foto: el marco se enciende
      g.pen = new Pen(FV_NAV_COL.casing, Math.max(3, 3.6 * kc)); g.drawRect(x0 + 1.5, y0 + 1.5, x0 + w - 1.5, y0 + h - 1.5);
      g.pen = new Pen(gold, Math.max(1.6, 2 * kc)); g.drawRect(x0 + 1.5, y0 + 1.5, x0 + w - 1.5, y0 + h - 1.5);
   }
   // 2. la estela (recortada al panel, mas tenue cuanto mas vieja)
   var fov = null, sUV = F.ship, dest = fvNavDest(P), dUV = dest ? fvNavPhotoUV(scene, dest) : null;
   if (trail && trail.length > 1) {
      var tp = []; for (n = 0; n < trail.length; ++n) { var tu = fvNavPhotoUV(scene, trail[n].p); tp.push(tu ? [XR(tu[0]), YR(tu[1])] : null); }
      if (sUV) tp.push([XR(sUV[0]), YR(sUV[1])]);
      for (n = 1; n < tp.length; ++n) {
         if (!tp[n - 1] || !tp[n]) continue;
         var cs = fvNavClip(tp[n - 1][0], tp[n - 1][1], tp[n][0], tp[n][1], panel); if (!cs) continue;
         a = Math.round(0x40 + 0xc0 * n / (tp.length - 1));
         g.pen = new Pen(((a << 24) | 0xFFF3C4) >>> 0, Math.max(1.4, 1.7 * kc)); g.drawLine(cs[0], cs[1], cs[2], cs[3]);
      }
   }
   // 3. el objeto elegido (anillo claro)
   var sel = P.sel, su = null;
   if (sel) { var sp = null; try { sp = (sel.kind === "nebula") ? null : fvSelPos(P, sel); } catch (eS) { sp = null; } su = sp ? fvNavPhotoUV(scene, sp) : null; }
   if (inside(su)) {
      g.pen = new Pen(FV_NAV_COL.casing, Math.max(2, 2.4 * kc)); g.drawCircle(XR(su[0]), YR(su[1]), 4.2 * kc + 1); g.pen = new Pen(0xffFFE9A8, Math.max(1, 1.2 * kc)); g.drawCircle(XR(su[0]), YR(su[1]), 4.2 * kc + 1);
      // (P23-mapas) el objeto elegido mas alla de la boca: «»» junto al aro (el aro ya cae donde va la camara: la proyeccion desde la Tierra no depende de la escala)
      if (sel && sel.kind === "object" && scene.objects && scene.objects[sel.i] && fvNavObjK(scene, scene.objects[sel.i]) < 1) fvNavFarMark(g, XR(su[0]) + 1.7 * Math.max(6, 6.6 * kc) + 3, YR(su[1]), 2.2 * kc, 0xffFFE9A8);
   }
   // 4. el destino del viaje: linea a trazos desde la nave y su mira; fuera de la foto, una flecha bermellon en el borde
   if (dUV) {
      if (sUV) { var cd = fvNavClip(XR(sUV[0]), YR(sUV[1]), XR(dUV[0]), YR(dUV[1]), panel); if (cd) { g.pen = new Pen(0xd0FF8A5A, Math.max(1, 1.3 * kc)); fvNavDash(g, cd[0], cd[1], cd[2], cd[3], 3 * kc, 2.2 * kc); } }
      if (!inside(dUV)) fvNavEdgeMark(g, panel, XR(dUV[0]), YR(dUV[1]), S * 0.75, FV_NAV_COL.dest);
   }
   // 5. la nave
   var out = false;
   if (home) {                                   // en casa: anillo en el centro de lo que se ve (la nave esta en la Tierra, mirando la foto)
      var hx = F.look ? XR(F.look[0]) : x0 + w / 2, hy = F.look ? YR(F.look[1]) : y0 + h / 2;
      g.pen = new Pen(FV_NAV_COL.casing, Math.max(2.4, 3 * kc)); g.drawCircle(hx, hy, S * 1.1);
      g.pen = new Pen(FV_NAV_COL.ship, Math.max(1.4, 1.6 * kc)); g.drawCircle(hx, hy, S * 1.1);
      g.fillCircle(hx, hy, S * 0.34, new Brush(FV_NAV_COL.ship));
   } else if (inside(sUV)) {
      var sx = XR(sUV[0]), sy = YR(sUV[1]), ux = 0, uy = 0, ul = 0;
      if (F.look) { ux = XR(F.look[0]) - sx; uy = YR(F.look[1]) - sy; ul = Math.sqrt(ux * ux + uy * uy); }
      if (ul > 2) fvNavShipGlyph(g, sx, sy, ux / ul, uy / ul, S);
      else {                                      // mira justo hacia el fondo de la foto: anillo con punto (sin direccion lateral)
         g.fillCircle(sx, sy, S * 2.0, new RadialGradientBrush(new Point(sx, sy), S * 2.0, new Point(sx, sy), [[0, 0x90FFF3C4], [1, 0x00FFF3C4]]));
         g.pen = new Pen(FV_NAV_COL.casing, Math.max(2.4, 3 * kc)); g.drawCircle(sx, sy, S * 0.9);
         g.pen = new Pen(FV_NAV_COL.ship, Math.max(1.4, 1.6 * kc)); g.drawCircle(sx, sy, S * 0.9);
         g.fillCircle(sx, sy, S * 0.38, new Brush(FV_NAV_COL.ship));
      }
   } else {                                      // fuera del rectangulo de la foto: flecha en el borde hacia donde esta
      out = true;
      var ex = sUV ? XR(sUV[0]) : x0 + w / 2 + pos[0] * 1e6, ey = sUV ? YR(sUV[1]) : y0 + h / 2 + pos[1] * 1e6;
      if (!sUV) { var ll = Math.sqrt(pos[0] * pos[0] + pos[1] * pos[1]) || 1; ex = x0 + w / 2 + pos[0] / ll * w * 4; ey = y0 + h / 2 + pos[1] / ll * h * 4; }
      var em = fvNavEdgeMark(g, panel, ex, ey, S * 1.15, FV_NAV_COL.ship);
      g.fillCircle(em[0], em[1], S * 2.2, new RadialGradientBrush(new Point(em[0], em[1]), S * 2.2, new Point(em[0], em[1]), [[0, 0x60FFF3C4], [1, 0x00FFF3C4]]));
      if (typeof fvBoundsShipEdge === "function") fvBoundsShipEdge(g, em, ex, ey, F.look ? [XR(F.look[0]), YR(F.look[1])] : null, S, panel);   // (9-nov, C3) la silueta junto al borde (FV_BOUNDS.ICON)
   }
   // 5b. la mira del destino ENCIMA de la nave: en un vuelo recto la nave y el destino caen en el mismo punto de la foto (se ve desde la Tierra)
   if (dUV && inside(dUV)) fvNavDestGlyph(g, XR(dUV[0]), YR(dUV[1]), Math.max(6, 6.6 * kc));
   // 6. el aviso: nave fuera de la foto, o la camara no mira hacia ella
   if (out || F.away) {
      var f = cpFont("display", Math.max(6, 6.6 * kc), false, false, Math.round(kc)), s = fvTx(out ? "nav.out" : "nav.away"); g.font = f;
      var by = out ? y0 + 2 * kc : y0 + h / 2 - 7 * kc;                // arriba (abajo lo tapa el rotulo TABULA)
      g.fillRect(x0 + 2, by, x0 + w - 2, by + 11 * kc, new Brush(0xd0110D09));
      g.pen = new Pen(out ? FV_NAV_COL.ship : gold); var st = cpElide(f, s, w - 6); g.drawText(x0 + (w - f.width(st)) / 2, by + 8.2 * kc, st);
   }
};
// pixel del panel -> fraccion de la foto (u, v)
function fvNavMapUV(r, x, y) { return [(x - r[0]) / (r[2] - r[0]), (y - r[1]) / (r[3] - r[1])]; }

// ---------------------------------------------------------------------------
// LA LISTA (pintar y tocar). st = { items, top, hover, sel } ; r en pixeles
// ---------------------------------------------------------------------------
// (I3) la caja de MIRABILIA: la cabecera, las filas y, al pie, el campo del buscador (sh). Con el campo, las filas siguen siendo 4 (la caja de
// 132 unidades daba 4,5 filas: sobraban 14, que es justo lo que ocupa el campo)
// (B, 14-nov) las filas. LIST_V2 false = las de 25 unidades de antes. Si no, la letra minima de la cabina (7 px: cpFont da de suelo a este panel Math.max(7, 9.4·kc) y
// Math.max(6.5, 7.6·kc), redondeadas) y la fila lo que miden la tinta de los dos renglones (cifras de la ascendente/descendente de la letra, medidas en
// tests/_mira/fv_B_font_probe.js: 0,74·tamaño de altura de mayuscula, 0,22 de descendente del titulo, 0,78 de ascendente y 0,25 de descendente del subtitulo):
// «modo 2» = titulo y subtitulo; si en la caja no caben ROW2_MIN filas asi (1280×800: 4), «modo 1» = un renglon (titulo y, si cabe, el subtitulo detras, mas tenue)
// -> { v2, mode (0 antes · 1 un renglon · 2 dos), tPx, sPx, pitch (entre lineas base, modo 2), rh, hd }. boxH = alto de la caja (px)
function fvNavRowSpec(kc, boxH) {
   if (FV_NAV.LIST_V2 === false) return { v2: false, mode: 0, rh: 25 * kc, hd: 16 * kc };
   var hd = FV_NAV.HD2 * kc, avail = boxH - hd - 2 * kc - 14 * kc;
   var tPx = Math.max(6, Math.round(Math.max(7, FV_NAV.ROW_T * kc))), sPx = Math.max(6, Math.round(Math.max(6.5, FV_NAV.ROW_S * kc)));
   // (P24, 16-nov) FV_MIRA.LIST_FIT 1 · 2 (decision de Nino, de fabrica 0 = lo de hoy; fv_mira.js): siempre dos renglones. 1 = letra mayor (FIT1_T / FIT1_S) con la fila lo que miden;
   // 2 = la letra de hoy con filas HOLGADAS (la caja repartida entre las filas que caben). tMin / sMin = la letra de hoy (hasta ahi baja la variante 1 si un texto no cabe); pad = el aire
   // que el painter pone sobre el bloque de texto para centrarlo en la fila
   var fit = (typeof FV_MIRA !== "undefined") ? FV_MIRA.LIST_FIT : 0;
   // (D2, 16-nov, decision de Nino) LIST_FIT 3 = la variante 1 SOLO donde hoy la lista caia a un renglon (ventana pequeña: no caben ROW2_MIN filas de dos renglones);
   // donde ya cabian los dos renglones, lo de hoy sin tocar
   if (fit === 3) {
      var pit0 = 0.22 * tPx + 0.78 * sPx + 0.8, need0 = 0.8 + 0.74 * tPx + pit0 + 0.25 * sPx, rh0 = Math.max(FV_NAV.ROW_H * kc, need0);
      // y solo si la letra de hoy es MENOR que la de la variante (si ya es mayor, la variante no aporta letra y solo quitaria filas)
      fit = (avail >= FV_NAV.ROW2_MIN * rh0 - 1e-6 || tPx >= FV_MIRA.FIT1_T) ? 0 : 1;
   }
   if (fit === 1 || fit === 2) {
      var tF = (fit === 1) ? Math.max(tPx, FV_MIRA.FIT1_T) : tPx, sF = (fit === 1) ? Math.max(sPx, FV_MIRA.FIT1_S) : sPx;
      var pitF = 0.22 * tF + 0.78 * sF + 0.8, needF = 0.8 + 0.74 * tF + pitF + 0.25 * sF, nF = Math.max(1, Math.floor(avail / needF + 1e-6)), rhF = (fit === 2) ? avail / nF : needF;
      return { v2: true, mode: 2, tPx: tF, sPx: sF, tMin: tPx, sMin: sPx, pitch: pitF, rh: rhF, hd: hd, fit: fit, pad: Math.max(0, (rhF - needF) / 2) };
   }
   var pitch = 0.22 * tPx + 0.78 * sPx + 0.8, need = 0.8 + 0.74 * tPx + pitch + 0.25 * sPx, rh2 = Math.max(FV_NAV.ROW_H * kc, need);
   if (avail >= FV_NAV.ROW2_MIN * rh2 - 1e-6) return { v2: true, mode: 2, tPx: tPx, sPx: sPx, pitch: pitch, rh: rh2, hd: hd };
   return { v2: true, mode: 1, tPx: tPx, sPx: sPx, pitch: 0, rh: tPx + FV_NAV.ROW1_PAD, hd: hd };
}
function fvNavListRows(r, kc) { var sp = fvNavRowSpec(kc, r[3] - r[1]), hd = sp.hd, rh = sp.rh, sh = 14 * kc; return { hd: hd, rh: rh, sh: sh, n: Math.max(1, Math.floor((r[3] - r[1] - hd - 2 * kc - sh) / rh + 1e-6)), v2: sp.v2, mode: sp.mode, tPx: sp.tPx, sPx: sp.sPx, pitch: sp.pitch, fit: sp.fit || 0, pad: sp.pad || 0, tMin: sp.tMin || sp.tPx, sMin: sp.sMin || sp.sPx }; }
// el campo del buscador [x0, y0, x1, y1] en pixeles
function fvNavSearchRect(r, kc) { var R = fvNavListRows(r, kc); return [r[0] + 2 * kc, r[3] - R.sh, r[2] - 2 * kc, r[3] - 0.5 * kc]; }
// el campo: hueco grabado en el laton (sombra arriba, filo de luz abajo), lupa de trazo fino, el texto, el cursor que parpadea y la × que lo vacia
function fvNavSearchPaint(g, r, st, kc) {
   var S = st.search || { text: "", focus: false }, q = fvNavSearchRect(r, kc), x0 = q[0], y0 = q[1], x1 = q[2], y1 = q[3], cy = (y0 + y1) / 2, has = S.text.length > 0;
   var hov = (st.hover === "search" || st.hover === "searchClear"), f = cpFont("text", Math.max(6.5, 8 * kc), false, false, 0), fi = cpFont("text", Math.max(6.5, 7.8 * kc), false, true, 0);
   g.fillRect(x0, y0, x1, y1, new Brush(S.focus ? 0xff130E08 : 0xff07060A));
   g.pen = new Pen(S.focus ? FV_CK.gold : (hov ? FV_CK.brass2 : FV_CK.brass3), Math.max(0.8, kc)); g.drawRect(x0 + 0.5, y0 + 0.5, x1 - 0.5, y1 - 0.5);
   g.pen = new Pen(0xff000000, Math.max(0.8, kc)); g.drawLine(x0 + 1.5, y0 + 1.5, x1 - 1.5, y0 + 1.5);                 // la sombra del grabado
   g.pen = new Pen(0x38E9C97A, Math.max(0.6, 0.7 * kc)); g.drawLine(x0 + 1.5, y1 - 1.2, x1 - 1.5, y1 - 1.2);           // el filo de luz
   var lx = x0 + 8 * kc, lr = 2.6 * kc, ly = cy - 0.6 * kc, col = S.focus ? FV_CK.gold : FV_CK.brass2;                     // la lupa
   g.pen = new Pen(col, Math.max(0.9, 1.1 * kc)); g.drawCircle(lx, ly, lr); g.drawLine(lx + lr * 0.72, ly + lr * 0.72, lx + lr * 0.72 + 2.2 * kc, ly + lr * 0.72 + 2.2 * kc);
   var tx = x0 + 15.5 * kc, avail = x1 - tx - (has ? 12 * kc : 3 * kc), base = cy + (f.ascent - f.descent) / 2 - 1.3 * kc, tEnd = tx;
   if (has) {
      var t = S.text, cut = false; g.font = f;
      while (t.length > 1 && f.width((cut ? "…" : "") + t) > avail) { t = t.substring(1); cut = true; }
      t = (cut ? "…" : "") + t;
      g.pen = new Pen(0xffFBF2E0); g.drawText(tx, base, t); tEnd = tx + f.width(t);
   } else {
      g.font = fi; g.pen = new Pen(S.focus ? 0xff8C7F67 : 0xff6E634F); g.drawText(tx, base, cpElide(fi, fvTx("nav.searchPh"), avail));
   }
   if (S.focus && (Math.floor(fvNowMs() / (500 * FV_SEARCH.BLINK_S)) % 2 === 0)) { g.pen = new Pen(FV_CK.gold, Math.max(1, kc)); g.drawLine(tEnd + 1 * kc, y0 + 3.2 * kc, tEnd + 1 * kc, y1 - 3.2 * kc); }
   if (has) {                                                                                                          // la × que vacia
      var cx = x1 - 6.5 * kc, cr = 2.1 * kc;
      g.pen = new Pen(st.hover === "searchClear" ? FV_CK.gold : FV_CK.brass2, Math.max(0.9, 1.1 * kc)); g.drawLine(cx - cr, cy - cr, cx + cr, cy + cr); g.drawLine(cx - cr, cy + cr, cx + cr, cy - cr);
   }
}
// (P24, 16-nov) LIST_FIT 1 · 2: el titulo y el subtitulo de UNA fila (R.tPx / R.sPx; en la variante 1, la letra mayor). Si el texto no cabe en tw se baja la letra de 1 en 1 hasta la de hoy (R.tMin / R.sMin;
// en la variante 2 son la misma: no hay bajada); el titulo corto (it.short) sustituye al largo en cada tamaño donde el largo no cabe y el corto si; a la letra de hoy el titulo hace EXACTAMENTE lo de
// hoy (corto si el largo no cabe, «…» si aun asi no cabe) y el subtitulo enseña las partes que caben enteras: nunca se corta con «…» un titulo que hoy no se corta. -> { fT, nm, fS, sub }
function fvNavFitRow(it, R, tw) {
   var s, f, fS, nm = String(it.name), sh = it.short || "", sub = String(it.sub || ""), t = null, u = null;
   for (s = R.tPx; s >= R.tMin && !t; --s) { f = cpFont("display", s); if (f.width(nm) <= tw) t = { f: f, text: nm }; else if (sh && f.width(sh) <= tw) t = { f: f, text: sh }; }
   if (!t) { f = cpFont("display", R.tMin); t = { f: f, text: cpElide(f, (sh && f.width(nm) > tw) ? sh : nm, tw) }; }
   for (s = R.sPx; s >= R.sMin && !u; --s) { fS = cpFont("text", s, false, true); if (fS.width(sub) <= tw) u = { f: fS, text: sub }; }
   if (!u) {
      // a la letra de hoy y aun asi no cabe: las partes del subtitulo (separadas por « · ») que quepan ENTERAS, de izquierda a derecha, en vez de un «…» a media cifra
      fS = cpFont("text", R.sMin, false, true);
      var parts = sub.split(" · "), kp;
      for (kp = parts.length - 1; kp >= 1 && !u; --kp) { var tr = parts.slice(0, kp).join(" · "); if (fS.width(tr) <= tw) u = { f: fS, text: tr }; }
      if (!u) u = { f: fS, text: cpElide(fS, parts[0], tw) };
   }
   return { fT: t.f, nm: t.text, fS: u.f, sub: u.text };
}
function fvNavListPaint(g, r, st, kc) {
   var R = fvNavListRows(r, kc), items = st.items || [], L = FV_LANG, i, S = st.search || null, searching = !!(S && S.text.length > 0);
   var fH = cpFont("display", Math.max(6.5, 7.6 * kc), false, false, Math.round(1.5 * kc)), fN = cpFont("display", Math.max(7, 9.4 * kc)), fS = cpFont("text", Math.max(6.5, 7.6 * kc), false, true);
   var fT2 = R.v2 ? cpFont("display", R.tPx) : null, fS2 = R.v2 ? cpFont("text", R.sPx, false, true) : null;
   g.antialiasing = true; g.textAntialiasing = true;
   g.font = fH; g.pen = new Pen(FV_CK.gold);
   var hy = R.v2 ? r[1] + R.hd - 3.4 * kc : r[1] + 11 * kc;                      // (B) la linea base de la cabecera: justo sobre la primera fila
   var ttl = "MIRABILIA";
   // (I1, 19-nov; FV_E1C) la placa tiene REVERSO (AENIGMATA): el titulo dice la cara que se ve y, si la foto tiene misterios, lleva la marca de giro y se pulsa («listFlip»)
   if (typeof fvE1cUiHeader === "function" && typeof fvE1cOn === "function" && fvE1cOn()) ttl = fvE1cUiHeader(g, st, r[0] + 6 * kc, hy, kc, fH); else g.drawText(r[0] + 6 * kc, hy, ttl);
   g.font = fH;
   if (items.length > R.n || searching) {
      var tot = (searching && S.n > items.length) ? S.n : items.length;
      var pg = items.length > R.n ? (st.top + 1) + "–" + Math.min(items.length, st.top + R.n) + " / " + tot + (tot > items.length ? "+" : "") : (items.length ? fvTx(items.length === 1 ? "nav.res1" : "nav.resN", { n: items.length }) : "");
      if (pg) { g.pen = new Pen(FV_CK.brass3); g.drawText(r[2] - 6 * kc - fH.width(pg), hy, pg); }
   }
   fvNavSearchPaint(g, r, st, kc);
   if (!items.length) {
      g.font = fS; g.pen = new Pen(0xffA3957B);
      var ws = fvWrap(fS, searching ? fvTx("nav.noRes", { q: S.text }) : fvTx(st.ready ? "nav.empty" : "nav.wait"), r[2] - r[0] - 12 * kc);
      for (i = 0; i < ws.length && i < 4; ++i) g.drawText(r[0] + 6 * kc, r[1] + R.hd + 12 * kc + i * 11 * kc, ws[i]);
      return;
   }
   for (var n = 0; n < R.n && st.top + n < items.length; ++n) {
      var it = items[st.top + n], y0 = r[1] + R.hd + n * R.rh, y1 = y0 + R.rh - (R.v2 ? 0.5 : 2 * kc), sel = st.sel && st.sel.kind === it.kind && (it.kind === "nebula" || st.sel.i === it.i);
      var ndr = !!it.noData;      // (21-nov, T1-A) la fila «sin datos»: apagada, sin flecha, sin resalte de clic (no es un destino); la ayuda sale igual
      if (!ndr && (st.hover === "list:" + (st.top + n) || st.hover === "listGo:" + (st.top + n))) g.fillRect(r[0] + 2, y0, r[2] - 2, y1, new Brush(0x30E5B53F));
      if (sel) { g.pen = new Pen(0xc0F3D27E, Math.max(0.8, kc)); g.drawRect(r[0] + 2.5, y0 + 0.5, r[2] - 2.5, y1 - 0.5); }
      // (I3) con el campo activo, la primera fila (a la que viaja Intro) lleva una barra de oro a la izquierda
      if (searching && S.focus && st.top + n === 0) g.fillRect(r[0] + 2, y0 + 1, r[0] + 2 + 2.2 * kc, y1 - 1, new Brush(FV_CK.gold));
      var tx = r[0] + 22 * kc, tw = r[2] - tx - 22 * kc, gx = r[2] - 11 * kc, gy = y0 + 11 * kc, gr = 6.5 * kc;
      if (R.v2) {        // (B) modo 2: titulo arriba y subtitulo debajo · modo 1: un renglon · icono y flecha centrados en la fila
         var rowH = y1 - y0, cyR = y0 + rowH / 2, icr = Math.min(5.5 * kc, rowH * 0.3), tB = (R.mode === 2) ? y0 + 0.4 + R.pad + 0.74 * R.tPx : cyR + 0.37 * R.tPx;
         fvNavIcon(g, it.icon || it.type, r[0] + 11 * kc, cyR, icr, sel ? 0xffFFE9A8 : (ndr ? 0xff8C7A4E : 0xffE5B53F));      // (P27c) it.icon = el del tipo real de la principal (fvNavIconKind); sin el, it.type
         gy = cyR; gr = Math.min(6.5 * kc, rowH * 0.36);
         var nmS = cpElide(fT2, (it.short && fT2.width(it.name) > tw) ? it.short : it.name, tw), fTr = fT2, fSr = fS2, subS = null;      // (P21) si el titulo largo no cabe y la fila trae uno corto, el corto (la ayuda lleva el largo)
         if (R.fit === 1 || R.fit === 2) { var fr = fvNavFitRow(it, R, tw); fTr = fr.fT; nmS = fr.nm; fSr = fr.fS; subS = fr.sub; }      // (P24) variantes 1 y 2: la letra que corresponda (la 1 baja hasta la de hoy si no cabe)
         g.font = fTr; g.pen = new Pen(sel ? 0xffFFE9A8 : (ndr ? 0xffB5A98F : 0xffFBF2E0)); g.drawText(tx, tB, nmS);
         g.font = fSr; g.pen = new Pen(0xffA3957B);
         if (R.mode === 2) g.drawText(tx, tB + R.pitch, subS !== null ? subS : cpElide(fS2, it.sub || "", tw));
         else { var sx = tx + fT2.width(nmS) + 4 * kc, sw2 = r[2] - 22 * kc - sx; var sg = String(it.sub || "").split(" · ")[0]; if (sg && it.subShort && fS2.width("· " + sg) > sw2) sg = it.subShort; if (sg && fS2.width("· " + sg) <= sw2) g.drawText(sx, tB, "· " + sg); }      // modo 1: si cabe ENTERO, la primera parte del subtitulo (tipo, valor o distancia); un trozo cortado no dice nada
      } else {
         fvNavIcon(g, it.icon || it.type, r[0] + 12 * kc, y0 + 11.5 * kc, 5.5 * kc, sel ? 0xffFFE9A8 : (ndr ? 0xff8C7A4E : 0xffE5B53F));
         g.font = fN; g.pen = new Pen(sel ? 0xffFFE9A8 : (ndr ? 0xffB5A98F : 0xffFBF2E0)); g.drawText(tx, y0 + 10 * kc, cpElide(fN, it.name, tw));
         g.font = fS; g.pen = new Pen(0xffA3957B); g.drawText(tx, y0 + 20 * kc, cpElide(fS, it.sub || "", tw));
      }
      // la flecha de «ir»: un boton de laton redondo (la fila «sin datos» no la lleva: no hay a donde ir)
      if (ndr) continue;
      var hov = (st.hover === "listGo:" + (st.top + n));
      g.fillCircle(gx, gy, gr, fvBrassBrush(gx, gy, gr));
      if (hov) { g.pen = new Pen(0xffFFF3C4, Math.max(1, kc)); g.drawCircle(gx, gy, gr + 1); }
      g.pen = new Pen(0xff2A1F15, Math.max(1, 1.2 * kc)); g.drawLine(gx - 3 * kc, gy, gx + 3 * kc, gy); g.drawLine(gx + 3 * kc, gy, gx + 0.5 * kc, gy - 2.5 * kc); g.drawLine(gx + 3 * kc, gy, gx + 0.5 * kc, gy + 2.5 * kc);
   }
}
// -> "list:<n>" | "listGo:<n>" | "search" | "searchClear" | "list" (cabecera / hueco) | null
function fvNavListHit(r, st, kc, x, y) {
   if (x < r[0] || x > r[2] || y < r[1] || y > r[3]) return null;
   var R = fvNavListRows(r, kc), items = st.items || [], q = fvNavSearchRect(r, kc);
   if (y >= q[1] - 1 * kc && x >= q[0] && x <= q[2]) return (st.search && st.search.text.length && x > q[2] - 13 * kc) ? "searchClear" : "search";
   if (y < r[1] + R.hd) return (st.flip && st.flipX1 > 0 && x <= st.flipX1) ? "listFlip" : "list";      // (I1) el titulo de la placa la gira si tiene reverso
   var n = Math.floor((y - r[1] - R.hd) / R.rh), idx = st.top + n;
   if (n < 0 || n >= R.n || idx >= items.length) return "list";
   if (x > r[2] - 20 * kc) return "listGo:" + idx;
   return "list:" + idx;
}

// ---------------------------------------------------------------------------
// (pasada N2, 4-nov-2026) TEXTOS NUEVOS Y CORREGIDOS (se añaden/sobrescriben en FV_TX, como el bloque de fv_text.js; este fichero se
// incluye despues de fv_text.js y antes de fv_buttons.js, que lee btn.* y tip.* al cargarse)
//   · TABULA / PROFUNDITAS (punto 1) · ficha solo con INFO o al llegar (punto 2) · MIRABILIA (punto 5)
//   · el boton EXPORTAR pasa a NAVEGADOR y su aviso trae «Abrir en el navegador» (punto 6) · CON/SIN CABINA (punto 7)
//   · REGULATOR = velocidad del viaje, LENTO · RAPIDO (punto 8)
// ---------------------------------------------------------------------------
(function() {
   var add = {
      en: {
         "nav.ship": "FROM EARTH", "nav.dest": "TO GO", "nav.out": "SHIP OUTSIDE THE PHOTO",
         "tipck.map2d": "TABULA: your photo. Gold outline = what the camera sees · large arrow = your ship and where it looks · faint trail = where you have been · red target and dashed line = where you are going. If the ship leaves the photo, an arrow on the edge says where it is. Click = look there · double-click = go there.",
         "tipck.map3d": "PROFUNDITAS (indicator): the field in 3D, depth in log scale — the cone of your photo from the Earth, the stars at their distance, the nebula slab. Large arrow = your ship and where it looks · line Earth → ship (SHIP = its distance) · dashed red line to the target (TARGET = what is left). The tick on the axis is the ship's depth.",
         "lab.web": "BROWSER", "btn.web": "Open in the browser",
         "tip.web": "Browser: exports this flight and opens it in your system browser (Chrome or Edge). It is the smoothest viewer — the same scene, with the nebula in volume. It writes its files to a folder you choose (remembered) and starts the browser only when you click «Open in the browser» on the notice.",
         "ex.title": "FLIGHT EXPORTED FOR THE BROWSER", "ex.open": "Press «Open in the browser» to see it there (it opens index.html with your system browser, Chrome or Edge).",
         "nb.openBrowser": "Open in the browser", "cap.browser": "OPENING THE BROWSER", "cap.browserFail": "THE BROWSER DID NOT OPEN (SEE CONSOLE)",
         "ck.cabin": "WITH COCKPIT", "ck.cabinNo": "PHOTO ONLY",
         "tipck.reccab": "What REC will record: WITH COCKPIT (the photo with the strip of instruments under it, as you see it now) or PHOTO ONLY (no instruments). The drawing shows it. Click to switch.",
         "ck.slow": "SLOW", "ck.fast": "FAST",
         "tipck.reg": "REGULATOR: travel speed, for CINEMA, WARP and the camera route: the whole trip (setting off, cruise, braking and the warp jump). Drag the lever from SLOW to FAST (the middle is the default speed; it is remembered). The thin red needle shows what the engine is giving now.",
         "cap.noSel": "SELECT AN OBJECT FIRST (CLICK IT, OR PICK IT IN MIRABILIA)",
         "tipck.list": "MIRABILIA: the most singular things in your photo (nebula, clusters, planetary nebulae, galaxies first; then notable stars and known planets). A notable star is named by what makes it notable («Hottest star», «Nearest star»…): hover its row for the exact criterion and its catalogue name. Click = select it (its card appears with INFO or when you arrive) · double-click or the arrow = go there. Wheel = scroll."
      },
      es: {
         "nav.ship": "DESDE LA TIERRA", "nav.dest": "FALTAN", "nav.out": "NAVE FUERA DE LA FOTO",
         "tipck.map2d": "TABULA: tu foto. Contorno dorado = lo que ve la cámara · flecha grande = tu nave y hacia dónde mira · estela tenue = por dónde has ido · mira roja y línea a trazos = adónde vas. Si la nave sale de la foto, una flecha en el borde dice dónde está. Clic = mirar allí · doble clic = ir allí.",
         "tipck.map3d": "PROFUNDITAS (indicador): el campo en 3D, profundidad en escala logarítmica — el cono de tu foto desde la Tierra, las estrellas a su distancia, la losa de la nebulosa. Flecha grande = tu nave y hacia dónde mira · línea Tierra → nave (NAVE = su distancia) · línea roja a trazos hasta el destino (DESTINO = lo que falta). La marca del eje es la profundidad de la nave.",
         "lab.web": "NAVEGADOR", "btn.web": "Abrir en el navegador",
         "tip.web": "Navegador: exporta este vuelo y lo abre en el navegador de tu sistema (Chrome o Edge). Es el visor más fluido — la misma escena, con la nebulosa en volumen. Escribe sus ficheros en una carpeta que eliges (recordada) y solo arranca el navegador cuando pulsas «Abrir en el navegador» en el aviso.",
         "ex.title": "VUELO EXPORTADO PARA EL NAVEGADOR", "ex.open": "Pulsa «Abrir en el navegador» para verlo allí (abre index.html con el navegador de tu sistema, Chrome o Edge).",
         "nb.openBrowser": "Abrir en el navegador", "cap.browser": "ABRIENDO EL NAVEGADOR", "cap.browserFail": "EL NAVEGADOR NO SE ABRIÓ (MIRA LA CONSOLA)",
         "ck.cabin": "CON CABINA", "ck.cabinNo": "SOLO FOTO",
         "tipck.reccab": "Lo que grabará REC: CON CABINA (la foto con la franja de instrumentos debajo, como la ves ahora) o SOLO FOTO (sin instrumentos). El dibujo lo muestra. Clic para cambiar.",
         "ck.slow": "LENTO", "ck.fast": "RÁPIDO",
         "tipck.reg": "REGULATOR: velocidad del viaje, para CINE, WARP y la ruta de cámaras: todo el viaje (arranque, crucero, frenada y el salto del warp). Arrastra la palanca de LENTO a RÁPIDO (el centro es la velocidad por defecto; se recuerda). La aguja roja fina marca lo que da el motor ahora.",
         "cap.noSel": "ELIGE UN OBJETO PRIMERO (CLIC EN ÉL, O ELÍGELO EN MIRABILIA)",
         "tipck.list": "MIRABILIA: lo más singular de tu foto (primero nebulosa, cúmulos, planetarias y galaxias; luego estrellas notables y planetas conocidos). Una estrella notable se llama por lo que la hace notable («La estrella más caliente», «La más cercana»…): pon el ratón sobre su fila para ver el criterio exacto y su nombre de catálogo. Clic = elegirlo (su ficha sale con INFO o al llegar) · doble clic o la flecha = ir allí. Rueda = desplazar."
      }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
