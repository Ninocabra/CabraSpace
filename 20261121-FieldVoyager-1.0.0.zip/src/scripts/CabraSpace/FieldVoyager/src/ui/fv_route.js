// ============================================================================
// FieldVoyager/src/ui/fv_route.js — ITINERARIUM: EL MAPA EN GRANDE, LAS CAMARAS DE LA RUTA Y LA FICHA QUE VIAJA (pasada M, 4-nov-2026)
// ----------------------------------------------------------------------------
// Encargo de Nino: «Haz que haciendo clic en TABULA o PROFUNDITAS estas aparezcan en lugar de la vista de la nave, en grande. Aqui se deben
// poder definir camaras que tu pongas manualmente para hacer la exploracion de la imagen que se quiera.» y «Cuando se muestre la
// informacion de un objeto, debo tener el boton de Travel en la propia ficha, e informacion para ir mas rapido.»
//
// (a) INTERCAMBIO: un clic en TABULA o PROFUNDITAS (la franja) pone ese mapa en la pantalla grande y la vista de la nave pasa, EN VIVO, a su
//     hueco pequeño. Un clic en la nave (el hueco) o Esc vuelve. Clic en el otro mapa pequeño: cambia de mapa grande. La nave sigue
//     volando, con su estela, su destino y los objetos.
// (b) CAMARAS en el mapa grande:
//     TABULA       clic en la foto = una camara mirando ahi; si hay una estrella u objeto a menos de PICK_PX, se toma el (su distancia);
//                  si no, la nebulosa a su distancia. ARRASTRAR desde el punto = la distancia de la camara a ese objetivo (log: de 0,001 a
//                  1 vez su distancia a la Tierra). Arrastrar una camara ya puesta = moverla por la foto.
//     PROFUNDITAS  clic en una estrella u objeto = una camara para el; arrastrar una camara a la derecha/izquierda = mas lejos/cerca
//                  de la Tierra (la profundidad, con su objetivo; conserva la direccion).
//     «＋ VISTA ACTUAL» guarda la camara de la nave tal cual. Cada camara se dibuja en los dos mapas, numerada, con su cono de vision; la
//     ruta que las une, como curva (Catmull-Rom en el plano del mapa).
// (c) LA LISTA (ITINERARIUM) ocupa el hueco de MIRABILIA mientras el mapa grande esta abierto (no se despliega encima: MIRABILIA sirve
//     para elegir objetos y en el mapa grande se eligen con el clic; asi no hay dos sitios para lo mismo). Copia el editor «My flight» de
//     Cabra3D (ui/flight_editor.js, dos rondas de revision de Nino): numero, miniatura REAL (un fotograma del pintor hecho al refrescar,
//     nunca en onPaint), nombre, tiempo de parada (chip que cambia con un clic), ▲ ▼ ⟳ ✎ ✕ dibujados con el mismo peso, clic en la fila =
//     la nave va a esa camara, «Borrar todo» con confirmacion de un segundo clic (moverse fuera la cancela), pie «▾ n mas» / «▴ n arriba»
//     y la rueda. Se guarda entre sesiones POR IMAGEN (Settings, clave con el centro y el tamaño de la foto).
// (d) RECORRER: fvPilotFlyPath(P, keys, opts) del motor (keys = [{ pos, look, fov, holdS }]) si existe (typeof); si no, el RESPALDO de
//     aqui: un vuelo suave de camara en camara (posicion por Catmull-Rom, mirada por slerp, campo en log, frenada en cada una y su parada).
// (e) REC graba el recorrido como cualquier vuelo (fvRecSnap toma la pose de la nave en cada tic).
// (f) LA FICHA: VIAJAR (icono de la flecha curva) con el MODUS de la cabina y, al lado, el OTRO modo (WARP si el MODUS es CINE, CINE si es
//     WARP): dos acciones distintas, sin repetir el boton VIAJAR de la columna. Cada boton dice cuanto dura el viaje con el REGULATOR de
//     ahora (fvPilotFly sobre una COPIA del piloto: la duracion que de verdad saldra), y la ficha dice la distancia desde la nave.
// ES5. Textos EN/ES en FV_TX (bloque del final).
// ============================================================================

var FV_ROUTE = {
   HOLDS: [0, 2, 3, 5, 8], HOLD0: 3,  // parada en cada camara (s): el chip de la fila pasa al siguiente con un clic
   MAX: 24,                           // camaras como mucho
   VIS: 3,                            // filas visibles de la lista (alto fijo: añadir o quitar no mueve nada)
   KB: 1.9,                           // los dibujos del mapa grande: KB × fvHudK(ancho del fotograma)
   PICK_PX: 18,                       // TABULA/PROFUNDITAS grandes: radio para tomar la estrella u objeto mas cercano al clic
   DRAG_PX: 6,                        // a partir de cuantos pixeles un clic es un arrastre
   STAND_LO: 1e-3, STAND_HI: 1.0,     // el arrastre: distancia al objetivo de STAND_LO a STAND_HI × su distancia a la Tierra (log)
   STAND_NEB: 0.25,                   // clic sin objeto: como mucho a 0,25 × D de la nebulosa (mirandola desde delante)
   NEB_VIEW: 0.35,                    // … y a la distancia a la que su campo abarca el 35 % del ancho de la foto (fvRouteNebStand)
   FOV_DEG: 40,                       // campo de una camara puesta con el clic (la de la nave, la suya)
   LEG: { MIN: 5, DEC: 4, MAX: 24, TURN_DPS: 25 },   // RESPALDO: segundos por tramo = MIN + DEC·log10(d/llegada) (≈ cine), × el regulador
   TAN_MAX: 2,                        // RESPALDO (K12 H-2): cota de la tangente de cada tramo, en veces su largo (ver fvRouteLeg)
   FORCE_FALLBACK: false,             // pruebas: usar el respaldo aunque el motor ya traiga fvPilotFlyPath
   TRIP_EVERY_S: 0.4,                 // la ficha: la duracion del viaje se recalcula como mucho cada 0,4 s de reloj de escena
   // (nD2, encargo E5) PROFUNDITAS grande: arrastrar el vacio = orbitar; menos de ORBIT_PX = clic (camara)
   ORBIT_PX: 4,
   // (nD2) la ANIMACION AL LLEGAR a cada camara (chip de la fila; se guarda con la ruta). Orden del chip y duraciones (s) que ofrece el suyo
   ANIMS: ["none", "orbit", "dolly", "pull", "pan", "roll", "parallax"],
   ANIM_S: [4, 6, 8, 12, 16],
   ANIM_S0: { orbit: 12, dolly: 8, pull: 8, pan: 8, roll: 6, parallax: 8 },
   ANIM: { ORBIT_DEG: 90,             // orbita: barre 90° alrededor del objetivo (eje = la vertical de la pantalla), distancia constante
           DOLLY_K: 0.5,              // acercamiento: termina a la mitad de la distancia al objetivo
           PULL_K: 1.5,               // alejamiento: termina a 2,5 veces
           PAN_DEG: 20,               // barrido: la mirada va ±20° a los lados y vuelve (la posicion no se mueve)
           ROLL_DEG: 12,              // balanceo: hasta 12° alrededor del eje de mirada y vuelve (necesita cam.roll en el proyector: ver HANDOFF)
           PARALLAX_K: 0.25 }         // paralaje: ±0,25 × la distancia al objetivo de lado, mirada fija (lo cercano se mueve mas que lo lejano)
};
var FV_ROUTE_STORE = null;            // pruebas: un objeto {} hace de Settings (las camaras se guardan ahi y no en el registro)

// ---------------------------------------------------------------------------
// GUARDAR Y CARGAR (por imagen)
// ---------------------------------------------------------------------------
// la firma de la imagen: centro (1e-4°) y tamaño de la foto -> "r…" (solo letras, cifras y _: vale como clave de Settings)
// (K12 H-4) la firma ANTIGUA (sin la escala) se sigue calculando para recuperar las rutas guardadas con ella; la NUEVA añade la escala de la
// foto: ln(F) × 100 (un 1 % de escala por escalon: dos fotos con el mismo centro y tamaño pero otro campo ya no comparten rutas, y un
// resolvido que baile un 0,01 % no las huerfana). Sin F valida, la firma es la antigua.
function fvRouteSigOld(scene) {
   var f = scene && scene.field;
   if (!f || !isFinite(f.ra) || !isFinite(f.dec)) return "";
   return "r" + Math.round(f.ra * 1e4) + "_" + Math.round((f.dec + 90) * 1e4) + "_" + Math.round(f.width) + "x" + Math.round(f.height);
}
function fvRouteSig(scene) {
   var s = fvRouteSigOld(scene), f = scene && scene.field;
   if (!s || !f || typeof f.F !== "number" || !isFinite(f.F) || !(f.F > 1)) return s;
   return s + "_s" + Math.round(100 * Math.log(f.F));
}
function fvRouteR(x) { return (isFinite(x) && x !== 0) ? Number(x.toPrecision(10)) : 0; }
// (nD2) la animacion de llegada va en «a» (tipo) y «as» (segundos) SOLO si la hay, y la inclinacion de los planos en «tilt» solo si no es cero:
// una ruta sin nada de eso se escribe EXACTAMENTE como antes (la bateria K12 compara el JSON)
function fvRouteToJson(cams, tilt) {
   var a = [];
   for (var i = 0; i < cams.length; ++i) {
      var c = cams[i], o = { n: c.name || "", p: c.pos.map(fvRouteR), l: c.look.map(fvRouteR), f: fvRouteR(c.fov), h: c.holdS, t: (c.tgt || fvAdd(c.pos, c.look)).map(fvRouteR) }, an = fvRouteAnimOf(c);
      if (an) { o.a = an.k; o.as = an.s; }
      a.push(o);
   }
   var J = { v: 1, cams: a };
   if (tilt && (tilt[0] || tilt[1])) J.tilt = [fvRouteR(tilt[0]), fvRouteR(tilt[1])];
   return JSON.stringify(J);
}
// (nD2) la animacion de una camara -> { k, s } | null (sin animacion o «none»)
function fvRouteAnimOf(c) { var a = c && c.anim; return (a && a.k && a.k !== "none" && FV_ROUTE.ANIMS.indexOf(a.k) > 0 && a.s > 0) ? a : null; }
// (nD2) la inclinacion guardada en un JSON de ruta -> [x, y] grados (sin el campo, o mal formado: [0, 0])
function fvRouteTiltFromJson(s) {
   var J = null; try { J = JSON.parse(s); } catch (e) { return [0, 0]; }
   if (!J || J.v !== 1 || !(J.tilt instanceof Array) || J.tilt.length !== 2) return [0, 0];
   var x = J.tilt[0], y = J.tilt[1], M = FV_NAV_ORBIT.TILT_MAX;
   if (typeof x !== "number" || typeof y !== "number" || !isFinite(x) || !isFinite(y)) return [0, 0];
   return [fvClamp(x, -M, M), fvClamp(y, -M, M)];
}
function fvRouteFromJson(s) {
   var out = [], J = null, i;
   try { J = JSON.parse(s); } catch (e) { return out; }
   // (K12 H-5) solo la version 1 y solo NUMEROS (un JSON con «0.7» entre comillas pasaba la comparacion por coercion y reventaba despues en toFixed)
   if (!J || J.v !== 1 || !(J.cams instanceof Array)) return out;
   function num(x) { return typeof x === "number" && isFinite(x); }
   function v3(a) { return (a instanceof Array) && a.length === 3 && num(a[0]) && num(a[1]) && num(a[2]); }
   for (i = 0; i < J.cams.length && out.length < FV_ROUTE.MAX; ++i) {
      var c = J.cams[i];
      if (!c || !v3(c.p) || !v3(c.l) || !v3(c.t) || !num(c.f) || !(c.f > 1e-5 && c.f < 3.1)) continue;
      var cam = { name: String(c.n || ""), pos: c.p.slice(), look: fvNorm(c.l), fov: c.f, holdS: (num(c.h) && c.h >= 0) ? c.h : FV_ROUTE.HOLD0, tgt: c.t.slice() };
      // (nD2) la animacion: una ruta antigua (sin «a») o un tipo desconocido = sin animacion; segundos validos o los del tipo
      if (typeof c.a === "string" && FV_ROUTE.ANIMS.indexOf(c.a) > 0) cam.anim = { k: c.a, s: (num(c.as) && c.as > 0 && c.as <= 120) ? c.as : FV_ROUTE.ANIM_S0[c.a] };
      out.push(cam);
   }
   return out;
}
function fvRouteRead(sig) {
   var s = null;
   if (FV_ROUTE_STORE) s = FV_ROUTE_STORE[sig] || null;
   else { try { s = Settings.read(CP_SETTINGS_PREFIX + "/route/" + sig, DataType_String); } catch (e) { s = null; } }
   return s ? String(s) : null;
}
function fvRouteWrite(sig, js) {
   if (FV_ROUTE_STORE) { FV_ROUTE_STORE[sig] = js; return true; }
   if (typeof FV_REMEMBER !== "undefined" && !FV_REMEMBER) return false;      // pruebas de otros ficheros: no se toca el registro
   try { Settings.write(CP_SETTINGS_PREFIX + "/route/" + sig, DataType_String, js); return true; } catch (e) { return false; }
}
// carga: primero la clave nueva (con la escala); si no hay, la antigua, y entonces SE MIGRA (se copia a la nueva). La antigua NO se borra: dos
// fotos con el mismo centro y tamaño la comparten y cada una debe poder migrarla (desde la migracion cada una guarda en la suya).
function fvRouteLoad(scene) {
   var sig = fvRouteSig(scene), old = fvRouteSigOld(scene), s;
   if (!sig) return [];
   s = fvRouteRead(sig);
   if (s) return fvRouteFromJson(s);
   if (old && old !== sig && (s = fvRouteRead(old))) {
      var cams = fvRouteFromJson(s);
      if (cams.length) fvRouteWrite(sig, fvRouteToJson(cams));
      return cams;
   }
   return [];
}
function fvRouteSave(scene, cams, tilt) {
   var sig = fvRouteSig(scene);
   if (!sig) return false;
   return fvRouteWrite(sig, fvRouteToJson(cams, tilt));
}
// (nD2) la inclinacion guardada con la ruta de esta foto (la clave nueva o, si no hay, la antigua)
function fvRouteLoadTilt(scene) {
   var sig = fvRouteSig(scene), old = fvRouteSigOld(scene), s = sig ? fvRouteRead(sig) : null;
   if (!s && old && old !== sig) s = fvRouteRead(old);
   return s ? fvRouteTiltFromJson(s) : [0, 0];
}
// (nD2) la inclinacion en la ESCENA: scene.nebula.tilt (grados) y su normal. Es el contrato con el pintor y el visor (que aun no la leen: ver
// HANDOFF); el mapa la dibuja ya. Viaja al paquete del navegador con la escena.
function fvRouteApplyTilt(sc, t) {
   if (!sc || !sc.nebula) return;
   sc.nebula.tilt = [t[0], t[1]];
   sc.nebula.normal = fvNavTiltNormal(t);
}

// ---------------------------------------------------------------------------
// LAS CAMARAS: { name, pos, look, fov, holdS, tgt (el punto al que mira: dibuja el cono y fija la profundidad) }
// ---------------------------------------------------------------------------
function fvRouteFov() { return FV_ROUTE.FOV_DEG * FV_DEG; }
// la camara de la nave tal cual; su objetivo: donde la mirada cruza el plano de la nebulosa (o un cuarto de su distancia si no lo cruza)
function fvRouteCamOfShip(P, name) {
   var c = P.cam, D = (P.scene && P.scene.nebula) ? P.scene.nebula.distLy : 1000, lk = fvNorm(c.look), d = 0.25 * D;
   if (lk[2] > 0.05 && c.pos[2] < D) d = fvClamp((D - c.pos[2]) / lk[2], 0.01 * D, 2 * D);
   return { name: name || "", pos: c.pos.slice(), look: lk, fov: c.fov, holdS: FV_ROUTE.HOLD0, tgt: fvAdd(c.pos, fvMul(lk, d)) };
}
// una camara mirando a `tgt` desde la linea de vision de la Tierra, a `stand` a.l. de el
function fvRouteCamAt(tgt, stand, name, fov) {
   var dir = fvLen(tgt) > 1e-9 ? fvNorm(tgt) : [0, 0, 1];
   return { name: name || "", pos: fvSub(tgt, fvMul(dir, stand)), look: dir, fov: fov || fvRouteFov(), holdS: FV_ROUTE.HOLD0, tgt: tgt.slice() };
}
// el nombre de lo elegido (para la camara): objeto o nebulosa por su nombre; estrella «★ G 9,3»
function fvRouteSelName(scene, sel) {
   var L = (FV_LANG === "es") ? "es" : "en";
   if (!sel) return "";
   if (sel.kind === "object" && scene.objects && scene.objects[sel.i]) { var o = scene.objects[sel.i]; return (o.names && o.names[L]) || o.name || ""; }
   if (sel.kind === "nebula" && scene.nebula) { var N = scene.nebula; return (N.names && N.names[L]) || N.name || ""; }
   if (sel.kind === "star" && scene.stars) return "★ G " + fvNum(scene.stars.g[sel.i], 1, FV_LANG);
   return "";
}
// la camara de LLEGADA a lo elegido: el objetivo y su distancia de llegada (fvArriveDist del motor), mirando desde la Tierra
function fvRouteCamForSel(P, sel, stand) {
   var T = null; try { T = fvSelPos(P, sel); } catch (e) { T = null; }
   if (!T) return null;
   var dA = stand; if (!(dA > 0)) { try { dA = fvArriveDist(P, sel); } catch (e2) { dA = 0.05 * fvLen(T); } }
   dA = Math.min(dA, 0.95 * fvLen(T));
   var c = fvRouteCamAt(T, dA, fvRouteSelName(P.scene, sel), (sel.kind === "nebula") ? FV_PILOT.ARRIVE_FOV : fvRouteFov());
   c.sel = { kind: sel.kind, i: sel.i };
   return c;
}
// las claves del recorrido (el contrato con el motor: fvPilotFlyPath(P, keys, opts))
function fvRouteKeys(cams) { var k = []; for (var i = 0; i < cams.length; ++i) k.push({ pos: cams[i].pos.slice(), look: cams[i].look.slice(), fov: cams[i].fov, holdS: cams[i].holdS }); return k; }
// ¿la nave esta en la camara c? (para el filete «estas aqui» de la lista)
function fvRouteSamePose(P, c) {
   var d = fvLen(fvSub(P.cam.pos, c.pos)), ref = Math.max(1e-3, 0.002 * fvLen(c.tgt));
   return d < ref && fvDot(fvNorm(P.cam.look), c.look) > Math.cos(0.5 * FV_DEG) && Math.abs(Math.log(P.cam.fov / c.fov)) < 0.02;
}

// ---------------------------------------------------------------------------
// (f) LA DURACION DE UN VIAJE: fvPilotFly sobre una COPIA del piloto (lo que de verdad saldria: camino, esquives, regulador, vertigo del
// primer warp). La copia no comparte cam, vuelo, vuelo libre ni eventos: el piloto de verdad no se toca. -> { ok, s, d, kind } | null
// ---------------------------------------------------------------------------
var FV_ROUTE_BREAK = "";      // pruebas: "share" = el ensayo de viaje comparte el estado del laboratorio (el fallo de antes del 11-nov)
function fvRouteTrip(P, sel, style) {
   if (!P || !sel) return null;
   var T = null; try { T = fvSelPos(P, sel); } catch (e) { T = null; }
   if (!T) return null;
   var Q = {}, k;
   for (k in P) Q[k] = P[k];
   Q.cam = { pos: P.cam.pos.slice(), look: P.cam.look.slice(), fov: P.cam.fov };
   // (11-nov, NV-1) CON EL LABORATORIO la copia tiene que llevar SU estado: Q.lab era el MISMO objeto que P.lab y la camara copiada no traia la base
   // (cam.B) ni S. Cada fotograma con la ficha abierta, este ensayo de viaje (fvLabFly sobre Q) escribia en el laboratorio de la nave de verdad:
   // le quitaba el «seguir mirando al destino» (L.hold) y la mirada se iba. Medido en el dialogo real (tests/_nav11/nav_default_probe.js): 1,5 s
   // despues de llegar la estrella estaba en (2593, -1234) de una pantalla de 1271 x 930, con su ficha abierta. Es el «sale la ficha y la estrella no esta»
   if (typeof FV_ROUTE_BREAK !== "undefined" && FV_ROUTE_BREAK === "share") { /* control en ROJO de las pruebas: el estado compartido de antes */ } else {
   if (P.cam.B) Q.cam.B = { f: P.cam.B.f.slice(), r: P.cam.B.r.slice(), d: P.cam.B.d.slice() };
   if (P.cam.S !== undefined) Q.cam.S = P.cam.S;
   if (P.cam.roll !== undefined) Q.cam.roll = P.cam.roll;
   if (P.lab) {
      var Lc = {}, kl, vl;
      for (kl in P.lab) { vl = P.lab[kl]; Lc[kl] = Array.isArray(vl) ? vl.slice() : ((vl && typeof vl === "object" && vl.constructor === Object) ? (function(o) { var c = {}; for (var q in o) c[q] = Array.isArray(o[q]) ? o[q].slice() : o[q]; return c; })(vl) : vl); }
      Q.lab = Lc;
   }
   }
   Q.events = []; Q.free = null; Q.flight = null; Q.orbit = null; Q.coast = null; Q.lookState = null; Q.style = (style === "spectacular") ? "spectacular" : "cine";
   var ok = false; try { ok = fvPilotFly(Q, "travel", sel) === true; } catch (e2) { ok = false; }
   return { ok: ok, s: (ok && Q.flight) ? Q.flight.dur : 0, d: fvLen(fvSub(T, P.cam.pos)), kind: (ok && Q.flight) ? Q.flight.kind : "" };
}
function fvRouteDur(s, L) {
   if (!(s > 0)) return "—";
   if (s < 59.5) return Math.round(s) + " s";
   var m = Math.floor(Math.round(s) / 60), r = Math.round(s) - 60 * m;
   return m + " min" + (r ? " " + r + " s" : "");
}

// ---------------------------------------------------------------------------
// (d) EL RESPALDO DEL RECORRIDO (mientras el motor no traiga fvPilotFlyPath): de la pose de ahora a cada camara, una tras otra
// ---------------------------------------------------------------------------
function fvRouteCR(p0, p1, p2, p3, t) {          // Catmull-Rom uniforme entre p1 y p2
   var t2 = t * t, t3 = t2 * t, o = [0, 0, 0];
   for (var i = 0; i < 3; ++i) o[i] = 0.5 * ((2 * p1[i]) + (-p0[i] + p2[i]) * t + (2 * p0[i] - 5 * p1[i] + 4 * p2[i] - p3[i]) * t2 + (-p0[i] + 3 * p1[i] - 3 * p2[i] + p3[i]) * t3);
   return o;
}
// (K12 H-2) la posicion del tramo p1 -> p2: la misma curva que fvRouteCR (Hermite con las tangentes de Catmull-Rom), pero con cada tangente
// de largo <= TAN_MAX × el del tramo. En tres camaras alineadas la tangente del medio vale (La + Lb) / 2, es decir (1 + Lb/La) / 2 veces el
// tramo La: con TAN_MAX = 2 la curva NO cambia mientras el tramo vecino mida hasta 3 veces el propio, y solo se toca lo que se pasa de eso.
// Donde hacia daño es en un tramo corto o NULO junto a uno largo: con p1 == p2 la tangente del vecino lo sacaba y lo devolvia (excursion de
// un 7 % de la distancia a la siguiente camara, medida), y 1e-6 mas alla pasaba igual (la correccion «si p1 == p2, p1» dejaria ese caso).
// Con la cota, tramo corto = excursion corta (≈ su largo) y nulo = quieto.
function fvRouteLeg(p0, p1, p2, p3, t) {
   var L = fvLen(fvSub(p2, p1)), cap = FV_ROUTE.TAN_MAX * L, m1 = [0, 0, 0], m2 = [0, 0, 0], o = [0, 0, 0], i, n1, n2;
   for (i = 0; i < 3; ++i) { m1[i] = 0.5 * (p2[i] - p0[i]); m2[i] = 0.5 * (p3[i] - p1[i]); }
   n1 = fvLen(m1); n2 = fvLen(m2);
   if (n1 > cap) m1 = fvMul(m1, cap / n1);
   if (n2 > cap) m2 = fvMul(m2, cap / n2);
   var t2 = t * t, t3 = t2 * t, h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
   for (i = 0; i < 3; ++i) o[i] = h00 * p1[i] + h10 * m1[i] + h01 * p2[i] + h11 * m2[i];
   return o;
}
function FVRoutePlay(P, keys) {
   var L = FV_ROUTE.LEG, k = (typeof fvPathDurK === "function") ? fvPathDurK(P) : ((typeof fvSpeedDurK === "function") ? fvSpeedDurK(P) : 1), i;   // (6-nov) como el motor
   this.pts = [P.cam.pos.slice()]; this.looks = [fvNorm(P.cam.look)]; this.fovs = [P.cam.fov]; this.holds = [0];
   for (i = 0; i < keys.length; ++i) { this.pts.push(keys[i].pos.slice()); this.looks.push(fvNorm(keys[i].look)); this.fovs.push(keys[i].fov); this.holds.push(keys[i].holdS || 0); }
   this.dur = [];
   for (i = 1; i < this.pts.length; ++i) {
      var d = fvLen(fvSub(this.pts[i], this.pts[i - 1])), near = Math.max(1e-3, 0.05 * Math.min(fvLen(this.pts[i]) || 1, fvLen(this.pts[i - 1]) || 1));
      var s = fvClamp(L.MIN + L.DEC * Math.log(Math.max(1, d / near)) / Math.LN10, L.MIN, L.MAX) * k;
      var turn = fvAngle(this.looks[i - 1], this.looks[i]) / FV_DEG;
      this.dur.push(Math.max(s, 1.875 * turn / L.TURN_DPS));
   }
   this.leg = 0; this.t = 0; this.hold = false; this.done = this.dur.length === 0; this.visited = [];
}
FVRoutePlay.prototype.total = function() { var s = 0, i; for (i = 0; i < this.dur.length; ++i) s += this.dur[i] + this.holds[i + 1]; return s; };
// un paso: pone la camara de P; -> el indice de la camara en la que esta parada o a la que va
FVRoutePlay.prototype.step = function(P, dt) {
   if (this.done) return -1;
   this.t += dt;
   var n = this.pts.length, i = this.leg;
   while (!this.done) {
      if (!this.hold) {
         if (this.t < this.dur[i]) break;
         this.t -= this.dur[i]; this.hold = true; this.visited.push(i);
      }
      if (this.hold) {
         if (this.t < this.holds[i + 1]) break;
         this.t -= this.holds[i + 1]; this.hold = false; ++i; this.leg = i;
         if (i >= this.dur.length) { this.done = true; i = this.dur.length - 1; }
      }
   }
   var c;
   if (this.done || this.hold) { var e = i + 1; P.cam.pos = this.pts[e].slice(); P.cam.look = this.looks[e].slice(); P.cam.fov = this.fovs[e]; return i; }
   var u = fvClamp(this.t / this.dur[i], 0, 1), x = fvSmoother(u);
   var p0 = this.pts[Math.max(0, i - 1)], p1 = this.pts[i], p2 = this.pts[i + 1], p3 = this.pts[Math.min(n - 1, i + 2)];
   c = fvRouteLeg(p0, p1, p2, p3, x);
   P.cam.pos = c;
   P.cam.look = fvSlerpDir(this.looks[i], this.looks[i + 1], fvSmoother(fvClamp((u - 0.08) / 0.84, 0, 1)));
   P.cam.fov = Math.exp(Math.log(this.fovs[i]) + (Math.log(this.fovs[i + 1]) - Math.log(this.fovs[i])) * x);
   return i;
};

// ---------------------------------------------------------------------------
// (nD2, encargo E5 de Nino: «varias opciones de animacion una vez que llegues al punto deseado, en cada camara») LA ANIMACION DE LLEGADA
// Un integrador propio (no toca el piloto): parte de la pose en la que la nave LLEGO a la camara c, con su objetivo T = c.tgt a la distancia R.
// Ley de tiempo: smootherstep (velocidad 0 al empezar y al acabar: sin tirones al enlazar con el tramo siguiente).
//   orbit     la posicion gira ORBIT_DEG alrededor de T (eje: la vertical de la pantalla de llegada); la mirada gira lo mismo (T sigue donde
//             estaba en pantalla). Distancia a T constante (rotacion exacta).
//   dolly     la posicion se acerca por la linea de mirada: R → (1 − DOLLY_K)·R. Monotona.
//   pull      se aleja: R → (1 + PULL_K)·R. Monotona.
//   pan       quieta; la mirada barre +PAN_DEG, −PAN_DEG y vuelve (seno de un ciclo en el tiempo suave).
//   roll      quieta; la camara se balancea ROLL_DEG alrededor de la mirada y vuelve: P.cam.roll (rad). El pintor y el visor aun no lo aplican.
//   parallax  la posicion va ±PARALLAX_K·R de lado y vuelve con la mirada FIJA: lo cercano se desplaza mas que lo lejano (se ve la profundidad).
// El final es una pose quieta: el tramo siguiente sale de ahi.
// ---------------------------------------------------------------------------
function FVRouteAnim(P, c, a) {
   var A = FV_ROUTE.ANIM;
   this.k = a.k; this.dur = a.s; this.t = 0; this.done = !(this.dur > 0) || FV_ROUTE.ANIMS.indexOf(a.k) <= 0;
   this.p0 = P.cam.pos.slice(); this.l0 = fvNorm(P.cam.look); this.fov = P.cam.fov;
   var T = c && c.tgt ? c.tgt.slice() : null, R = T ? fvLen(fvSub(T, this.p0)) : 0;
   // sin objetivo delante (camara «vista actual» mirando fuera, o la nave no llego del todo): un objetivo en la mirada
   if (!T || !(R > 1e-9) || fvDot(fvNorm(fvSub(T, this.p0)), this.l0) < 0.5) { R = Math.max(1e-3, 0.05 * fvLen(this.p0)); T = fvAdd(this.p0, fvMul(this.l0, R)); }
   this.T = T; this.R = R; this.B = fvBasis(this.l0, [0, 1, 0]); this.A = A;
}
// la pose en u ∈ [0, 1] -> { pos, look, roll }
FVRouteAnim.prototype.pose = function(u) {
   var e = fvSmoother(fvClamp(u, 0, 1)), A = this.A, p0 = this.p0, l0 = this.l0, T = this.T, B = this.B, k = this.k;
   if (k === "orbit") { var ang = A.ORBIT_DEG * FV_DEG * e, v = fvRotate(fvSub(p0, T), B.d, ang); return { pos: fvAdd(T, v), look: fvNorm(fvRotate(l0, B.d, ang)), roll: 0 }; }
   if (k === "dolly" || k === "pull") { var s = (k === "dolly") ? 1 - A.DOLLY_K * e : 1 + A.PULL_K * e; return { pos: fvSub(T, fvMul(fvSub(T, p0), s)), look: l0.slice(), roll: 0 }; }
   if (k === "pan") return { pos: p0.slice(), look: fvNorm(fvRotate(l0, B.d, A.PAN_DEG * FV_DEG * Math.sin(2 * Math.PI * e))), roll: 0 };
   if (k === "roll") return { pos: p0.slice(), look: l0.slice(), roll: A.ROLL_DEG * FV_DEG * Math.sin(Math.PI * e) };
   if (k === "parallax") return { pos: fvAdd(p0, fvMul(B.r, A.PARALLAX_K * this.R * Math.sin(2 * Math.PI * e))), look: l0.slice(), roll: 0 };
   return { pos: p0.slice(), look: l0.slice(), roll: 0 };
};
// un paso: pone la camara de P; al acabar, la pose final exacta y sin balanceo
FVRouteAnim.prototype.step = function(P, dt) {
   if (this.done) return;
   this.t += dt;
   var u = this.t / this.dur, q = this.pose(u);
   P.cam.pos = q.pos; P.cam.look = q.look; P.cam.fov = this.fov;
   if (q.roll) P.cam.roll = q.roll; else if (P.cam.roll) P.cam.roll = 0;
   if (u >= 1) { this.done = true; P.cam.roll = 0; }
};
// los tramos del recorrido: se corta en cada camara CON animacion (el motor vuela hasta ella, frena, se anima, para su parada y sigue).
// Sin animaciones sale UN tramo con todas: el recorrido de siempre (Catmull-Rom del motor sin frenar en las camaras sin parada).
function fvRouteSegs(cams) {
   var segs = [], a = 0;
   for (var i = 0; i < cams.length; ++i) { var an = fvRouteAnimOf(cams[i]); if (an || i === cams.length - 1) { segs.push({ a: a, b: i, anim: an }); a = i + 1; } }
   return segs;
}

// ---------------------------------------------------------------------------
// LOS DIBUJOS: glifos de la lista (con el peso de Cabra3D, dibujados), insignia numerada, curva de la ruta
// ---------------------------------------------------------------------------
var FV_RT_COL = { gold: 0xffF3D27E, goldD: 0xffC99A3A, text: 0xffFBF2E0, dim: 0xffA3957B, off: 0x55A3957B, verm: 0xffE0603F, ink: 0xff2A1F15, bg: 0xff1B140E, cone: 0x38F3D27E, sel: 0xffFFF3C4 };
function fvRtGlyph(g, kind, cx, cy, s, col) {
   var br = new Brush(col), k;
   if (kind === "up" || kind === "down") {
      var d = (kind === "up") ? -1 : 1;
      g.fillPolygon([new Point(cx, cy + d * 0.42 * s), new Point(cx - 0.46 * s, cy - d * 0.34 * s), new Point(cx + 0.46 * s, cy - d * 0.34 * s)], br);
   } else if (kind === "delete") {
      g.pen = new Pen(col, Math.max(1.5, 0.17 * s)); g.drawLine(cx - 0.36 * s, cy - 0.36 * s, cx + 0.36 * s, cy + 0.36 * s); g.drawLine(cx - 0.36 * s, cy + 0.36 * s, cx + 0.36 * s, cy - 0.36 * s);
   } else if (kind === "rename") {                // el lapiz de Cabra3D (c3FlEdPencil): cuerpo + punta, macizo, en diagonal
      var kk = 0.7071, w = 0.15, T = [-0.5, 0.5], S0 = [-0.27, 0.27], E0 = [0.40, -0.40];
      function p(a, b) { return new Point(cx + a * s, cy + b * s); }
      g.fillPolygon([p(T[0], T[1]), p(S0[0] + kk * w, S0[1] + kk * w), p(E0[0] + kk * w, E0[1] + kk * w), p(E0[0] - kk * w, E0[1] - kk * w), p(S0[0] - kk * w, S0[1] - kk * w)], br);
   } else if (kind === "replace") {               // ⟳ de Cabra3D (c3FlEdRefresh): arco de 260° con su punta maciza
      var r = 0.38 * s, a0 = -40, a1 = 220, pts = [], a, K = Math.PI / 180;
      for (a = a0; a <= a1 + 0.1; a += 10) pts.push(new Point(cx + r * Math.cos(a * K), cy + r * Math.sin(a * K)));
      g.pen = new Pen(col, Math.max(1.5, 0.17 * s)); g.drawPolyline(pts);
      var e = a1 * K, ex = cx + r * Math.cos(e), ey = cy + r * Math.sin(e), tx = -Math.sin(e), ty = Math.cos(e), nx = Math.cos(e), ny = Math.sin(e), hl = 0.30 * s, hw = 0.24 * s;
      g.fillPolygon([new Point(ex + tx * hl, ey + ty * hl), new Point(ex + nx * hw, ey + ny * hw), new Point(ex - nx * hw, ey - ny * hw)], br);
   } else if (kind === "play") {
      g.fillPolygon([new Point(cx - 0.32 * s, cy - 0.4 * s), new Point(cx + 0.42 * s, cy), new Point(cx - 0.32 * s, cy + 0.4 * s)], br);
   } else if (kind === "stop") {
      g.fillRect(cx - 0.32 * s, cy - 0.32 * s, cx + 0.32 * s, cy + 0.32 * s, br);
   } else if (kind === "add") {
      g.pen = new Pen(col, Math.max(1.5, 0.17 * s)); g.drawLine(cx - 0.4 * s, cy, cx + 0.4 * s, cy); g.drawLine(cx, cy - 0.4 * s, cx, cy + 0.4 * s);
   } else if (kind === "suggest") {               // ✦ dibujada: cuatro puntas
      var P4 = []; for (k = 0; k < 8; ++k) { var ang = k * Math.PI / 4 - Math.PI / 2, rr = (k % 2) ? 0.16 * s : 0.48 * s; P4.push(new Point(cx + rr * Math.cos(ang), cy + rr * Math.sin(ang))); }
      g.fillPolygon(P4, br);
   }
}
// (nD2) los iconos de las animaciones de llegada (dibujados, el mismo peso que los de la fila; el gemelo SVG esta en web/fw_route.js)
//   none ‖ (parada) · orbit elipse con su flecha alrededor de un punto · dolly flecha que llega al punto · pull el punto y la flecha que se va ·
//   pan ↔ sobre un ojo · roll arco con flecha y el horizonte inclinado · parallax dos puntos (cerca grande, lejos pequeño) con ↔ largo y corto
function fvRtAnimGlyph(g, kind, cx, cy, s, col) {
   var br = new Brush(col), lw = Math.max(1.2, 0.12 * s), K = Math.PI / 180, i;
   function P(a, b) { return new Point(cx + a * s, cy + b * s); }
   function head(x, y, ux, uy, L) { var nx = -uy, ny = ux; g.fillPolygon([P(x + ux * L, y + uy * L), P(x - ux * L * 0.4 + nx * L * 0.75, y - uy * L * 0.4 + ny * L * 0.75), P(x - ux * L * 0.4 - nx * L * 0.75, y - uy * L * 0.4 - ny * L * 0.75)], br); }
   function line(a, b, c, d) { g.drawLine(cx + a * s, cy + b * s, cx + c * s, cy + d * s); }
   g.pen = new Pen(col, lw);
   if (kind === "orbit") {
      var pts = []; for (i = 0; i <= 300; i += 15) pts.push(P(0.44 * Math.cos(i * K), 0.20 * Math.sin(i * K)));
      g.drawPolyline(pts); head(0.44 * Math.cos(300 * K), 0.20 * Math.sin(300 * K), 0.86, 0.5, 0.17); g.fillCircle(cx, cy, 0.1 * s, br);
   } else if (kind === "dolly") {
      line(-0.46, 0, 0.08, 0); head(0.12, 0, 1, 0, 0.17); g.fillCircle(cx + 0.36 * s, cy, 0.12 * s, br);
   } else if (kind === "pull") {
      g.fillCircle(cx - 0.36 * s, cy, 0.12 * s, br); line(-0.16, 0, 0.36, 0); head(0.38, 0, 1, 0, 0.17);
   } else if (kind === "pan") {
      line(-0.36, -0.08, 0.36, -0.08); head(0.4, -0.08, 1, 0, 0.16); head(-0.4, -0.08, -1, 0, 0.16);
      g.drawEllipse(cx - 0.16 * s, cy + 0.12 * s, cx + 0.16 * s, cy + 0.34 * s); g.fillCircle(cx, cy + 0.23 * s, 0.05 * s, br);
   } else if (kind === "roll") {
      var pr = []; for (i = -200; i <= 40; i += 15) pr.push(P(0.38 * Math.cos(i * K), 0.38 * Math.sin(i * K)));
      g.drawPolyline(pr); head(0.38 * Math.cos(40 * K), 0.38 * Math.sin(40 * K), -Math.sin(40 * K), Math.cos(40 * K), 0.17); line(-0.26, 0.1, 0.26, -0.1);
   } else if (kind === "parallax") {
      g.fillCircle(cx, cy - 0.24 * s, 0.07 * s, br); line(-0.16, -0.24, 0.16, -0.24); head(0.2, -0.24, 1, 0, 0.11); head(-0.2, -0.24, -1, 0, 0.11);
      g.fillCircle(cx, cy + 0.2 * s, 0.13 * s, br); line(-0.36, 0.2, 0.36, 0.2); head(0.42, 0.2, 1, 0, 0.15); head(-0.42, 0.2, -1, 0, 0.15);
   } else {                                       // none: ‖ (parada)
      g.fillRect(cx - 0.26 * s, cy - 0.3 * s, cx - 0.1 * s, cy + 0.3 * s, br); g.fillRect(cx + 0.1 * s, cy - 0.3 * s, cx + 0.26 * s, cy + 0.3 * s, br);
   }
}
// (nD2) el asa de inclinacion de los planos (PROFUNDITAS grande): disco con un arco de doble flecha (girar)
function fvRtTiltGlyph(g, x, y, S, on) {
   var col = on ? FV_RT_COL.sel : FV_RT_COL.gold, K = Math.PI / 180, pts = [], i;
   g.fillCircle(x, y, S, new Brush(0xe0110D09));
   g.pen = new Pen(col, Math.max(1.2, 0.16 * S)); g.drawCircle(x, y, S);
   for (i = 200; i <= 340; i += 10) pts.push(new Point(x + 0.55 * S * Math.cos(i * K), y + 0.2 * S + 0.55 * S * Math.sin(i * K)));
   g.pen = new Pen(col, Math.max(1.1, 0.12 * S)); g.drawPolyline(pts);
   var br = new Brush(col), a0 = 200 * K, a1 = 340 * K;
   function hd(a, sg) { var ex = x + 0.55 * S * Math.cos(a), ey = y + 0.2 * S + 0.55 * S * Math.sin(a), tx = -Math.sin(a) * sg, ty = Math.cos(a) * sg, nx = Math.cos(a), ny = Math.sin(a), L = 0.3 * S;
      g.fillPolygon([new Point(ex + tx * L, ey + ty * L), new Point(ex + nx * L * 0.6 - tx * L * 0.3, ey + ny * L * 0.6 - ty * L * 0.3), new Point(ex - nx * L * 0.6 - tx * L * 0.3, ey - ny * L * 0.6 - ty * L * 0.3)], br); }
   hd(a0, -1); hd(a1, 1);
   g.drawLine(x - 0.45 * S, y + 0.35 * S, x + 0.45 * S, y + 0.05 * S);
}
// la insignia numerada de una camara: disco oscuro con aro de oro (claro si esta elegida) y su numero
function fvRtBadge(g, x, y, n, S, on) {
   var f = cpFont("display", Math.max(6, 0.95 * S), false, false, 0), t = String(n);
   g.fillCircle(x, y, S, new Brush(0xe0110D09));
   g.pen = new Pen(on ? FV_RT_COL.sel : FV_RT_COL.gold, Math.max(1.2, 0.16 * S)); g.drawCircle(x, y, S);
   g.font = f; g.pen = new Pen(on ? FV_RT_COL.sel : FV_RT_COL.gold); g.drawText(x - f.width(t) / 2, y + 0.36 * S, t);
}
// la ruta como curva (Catmull-Rom en el plano del mapa) por los puntos dados [[x, y]…], a trazos con una flecha a mitad de cada tramo
function fvRtCurve(g, pts, kc, col) {
   if (pts.length < 2) return;
   var n = pts.length, i, j, q = [];
   for (i = 0; i < n - 1; ++i) {
      var p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(n - 1, i + 2)];
      for (j = (i ? 1 : 0); j <= 16; ++j) { var c = fvRouteCR([p0[0], p0[1], 0], [p1[0], p1[1], 0], [p2[0], p2[1], 0], [p3[0], p3[1], 0], j / 16); q.push([c[0], c[1], i, j]); }
   }
   g.pen = new Pen(FV_NAV_COL.casing, Math.max(2.2, 2.6 * kc)); for (i = 1; i < q.length; ++i) g.drawLine(q[i - 1][0], q[i - 1][1], q[i][0], q[i][1]);
   g.pen = new Pen(col || 0xd0F3D27E, Math.max(1.2, 1.3 * kc));
   for (i = 1; i < q.length; ++i) if (Math.floor(i / 2) % 2 === 0) g.drawLine(q[i - 1][0], q[i - 1][1], q[i][0], q[i][1]);
   for (i = 1; i < q.length; ++i) if (q[i][3] === 8) {          // la flecha a mitad del tramo
      var dx = q[i][0] - q[i - 1][0], dy = q[i][1] - q[i - 1][1], L = Math.sqrt(dx * dx + dy * dy); if (L < 1e-6) continue;
      dx /= L; dy /= L; var S = 4.2 * kc, x = q[i][0], y = q[i][1];
      g.fillPolygon([new Point(x + dx * S, y + dy * S), new Point(x - dx * S * 0.6 - dy * S * 0.7, y - dy * S * 0.6 + dx * S * 0.7), new Point(x - dx * S * 0.6 + dy * S * 0.7, y - dy * S * 0.6 - dx * S * 0.7)], new Brush(col || 0xd0F3D27E));
   }
}
// las cuatro esquinas del cono de la camara c a la distancia de su objetivo (mundo)
function fvRtCorners(c, VW, VH) {
   var B = fvBasis(c.look, [0, 1, 0]), d = fvLen(fvSub(c.tgt, c.pos)), tx = Math.tan(c.fov / 2), ty = tx * VH / VW, out = [], S = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
   for (var i = 0; i < 4; ++i) out.push(fvAdd(c.pos, fvMul(fvAdd(B.f, fvAdd(fvMul(B.r, S[i][0] * tx), fvMul(B.d, S[i][1] * ty))), d)));
   return out;
}

// ---------------------------------------------------------------------------
// EL CONTROLADOR (uno por dialogo). D = FVDialog
// ---------------------------------------------------------------------------
function FVRoute(D) {
   this.D = D; this.cams = []; this.sel = -1; this.big = null; this.frame = null; this.mini = null; this.m2 = null; this.m3 = null;
   this.top = 0; this.hover = null; this.vhover = null; this.drag = null; this.clearAsk = false; this.thumbs = {}; this.thumbOrder = [];
   this.play = null; this.edit = null; this.renaming = -1; this.hits = []; this.tripAt = -1e9; this.tripKey = ""; this.loadedSig = "";
   this.tilt = [0, 0];                                        // (nD2) inclinacion de los planos (grados), se guarda con la ruta
}
FVRoute.prototype.attach = function() {
   var D = this.D, sc = D.scene;
   this.cams = fvRouteLoad(sc); this.loadedSig = fvRouteSig(sc); this.sel = -1; this.top = 0; this.freeThumbs();
   var ph = (D.built && D.built.bmps) ? (D.built.bmps.photo || D.built.bmps.starless) : null;
   this.m2 = new FVNavMap2D(ph); this.m3 = new FVNavMap3D(sc);
   if (typeof FVNavMap3D.prototype.setPhoto === "function") { this.m3.setPhoto(ph); if (D.nav && D.nav.map3d) D.nav.map3d.setPhoto(ph); }   // (nD3) la losa con la foto
   this.m3.setView(fvNavViewHome());                          // (nD2) el mapa grande orbita; la franja sigue con la de gabinete
   this.setTilt(fvRouteLoadTilt(sc));
   this.hookView();
   fvLog("route: " + this.cams.length + " camera(s) loaded for " + this.loadedSig + " · tilt " + this.tilt.join("/") + " · engine path " + (typeof fvPilotFlyPath === "function" ? "fvPilotFlyPath" : "not yet (fallback)"));
};
// (nD2) la rueda, el doble clic y el boton pulsado de la pantalla grande. fv_dialog.js (no es de este fichero) se traga la rueda y el doble
// clic con el mapa en grande y no pasa el boton ni los modificadores: se envuelven aqui sus manejadores UNA vez (lo de antes sigue igual con
// el mapa cerrado). Convendria moverlo a fv_dialog.js (ver el informe de nD2).
FVRoute.prototype.hookView = function() {
   var D = this.D, v = D.view, self = this;
   if (!v || v.fvRouteHooked) return;
   v.fvRouteHooked = true;
   var w0 = v.onMouseWheel, d0 = v.onMouseDoubleClick, p0 = v.onMousePress;
   function R() { return D.route || self; }
   v.onMouseWheel = function(x, y, delta, buttons, mods) { var r = R(); if (r.big) { var f = D.toFrame(x, y); r.viewWheel(f[0], f[1], delta); return; } if (w0) return w0.apply(this, arguments); };
   v.onMouseDoubleClick = function(x, y, buttons, mods) { var r = R(); if (r.big) { var f = D.toFrame(x, y); r.viewDouble(f[0], f[1]); return; } if (d0) return d0.apply(this, arguments); };
   v.onMousePress = function(x, y, button, buttons, mods) {
      var r = R(); r.pressMods = mods || 0;
      if (r.big && button !== undefined && button !== MouseButton_Left) return;           // con el mapa en grande solo el boton IZQUIERDO
      if (p0) return p0.apply(this, arguments);
   };
};
// (nD2) la inclinacion de los planos: el mapa grande, el de la franja y la escena (contrato con el pintor y el visor)
FVRoute.prototype.setTilt = function(t) {
   var M = FV_NAV_ORBIT.TILT_MAX, D = this.D;
   this.tilt = [fvClamp(+t[0] || 0, -M, M), fvClamp(+t[1] || 0, -M, M)];
   if (this.m3) this.m3.tilt = this.tilt.slice();
   if (D.nav && D.nav.map3d) D.nav.map3d.tilt = this.tilt.slice();
   fvRouteApplyTilt(D.scene, this.tilt);
   return this.tilt;
};
// (K12 H-1) guardar = la lista acaba de cambiar (anadir, quitar, reordenar, sustituir, renombrar, parada, mover): el recorrido en marcha lleva
// una INSTANTANEA de las camaras (fvRouteKeys) y seguiria hacia destinos que ya no estan en la lista -> se para. Los vuelos de UNA camara
// (goTo, clic en una fila) tampoco se guardan, pero tampoco pasan por aqui.
FVRoute.prototype.save = function() { this.stopFly("edit"); var r = fvRouteSave(this.D.scene, this.cams, this.tilt); this.freeThumbsUnused(); return r; };
// ---- (a) el intercambio ----
FVRoute.prototype.toggleBig = function(which) { if (this.big === which) this.close(); else this.open(which); return this.big; };
FVRoute.prototype.open = function(which) {
   var D = this.D; if (!D.P) return false;
   this.big = (which === "map3d") ? "map3d" : "map2d"; this.drag = null; this.vhover = null; this.clearAsk = false;
   try { D.view.toolTip = fvTipBoth(this.big === "map2d" ? "rt.tipBig2" : "rt.tipBig3"); D.view.cursor = new Cursor(StdCursor_Cross); D.viewHand = false; } catch (e) {}
   D.renderNow(); try { D.view.repaint(); D.strip.repaint(); } catch (e2) {}
   return true;
};
FVRoute.prototype.close = function() {
   var D = this.D; this.renameEnd(true);
   this.big = null; this.drag = null; this.vhover = null; this.clearAsk = false; this.full = null; this.mini = null;
   try { D.view.toolTip = ""; } catch (e) {}
   if (D.P) D.renderNow(); try { D.view.repaint(); D.strip.repaint(); } catch (e2) {}
};
// ---- la geometria de la pantalla grande (fotograma VW × VH): mapa, placa de titulo y botonera ----
FVRoute.prototype.geom = function() {
   var D = this.D, W = D.VW, H = D.VH, kH = fvHudK(W), G = { W: W, H: H, kH: kH, kB: FV_ROUTE.KB * kH };
   if (this.big === "map3d") { var w3 = Math.min(W, H * 1.62), h3 = Math.min(H, w3 / 1.30); G.map = [(W - w3) / 2, (H - h3) / 2 + 0.02 * H, (W + w3) / 2, (H + h3) / 2]; }
   else G.map = [0, 0, W, H];
   // la botonera: abajo en el centro (como la placa de aviso, que tambien es una barra de mandos en el mismo sitio)
   var fB = cpFont("display", 11 * kH, false, false, Math.round(2 * kH)), btn = [], P = D.P, n = this.cams.length;
   var playing = !!this.play;
   btn.push({ id: "add", glyph: "add", text: fvTx("rt.add"), on: n < FV_ROUTE.MAX });
   btn.push({ id: "play", glyph: playing ? "stop" : "play", text: playing ? fvTx("rt.stop") : fvTx("rt.play") + (n ? " · " + fvRouteDur(this.estimate(), FV_LANG) : ""), on: n > 0 || playing });
   if (typeof fvTourPlan === "function" && this.D.scene.objects && this.D.scene.objects.length) btn.push({ id: "suggest", glyph: "suggest", text: fvTx("rt.suggest"), on: true });
   var bh = 24 * kH, pad = 12 * kH, gap = 10 * kH, wTot = 0, i;
   for (i = 0; i < btn.length; ++i) { btn[i].w = fB.width(btn[i].text) + 26 * kH + 22 * kH; wTot += btn[i].w + (i ? gap : 0); }
   var x0 = (W - wTot) / 2, y1 = H - 18 * kH, y0 = y1 - bh;
   G.bar = [x0 - pad, y0 - pad * 0.7, x0 + wTot + pad, y1 + pad * 0.7];
   for (i = 0; i < btn.length; ++i) { btn[i].r = [x0, y0, x0 + btn[i].w, y1]; x0 += btn[i].w + gap; }
   G.btn = btn; G.fB = fB;
   return G;
};
// ---- pintar la pantalla grande (en D.renderNow, en el reloj: nunca en onPaint) ----
FVRoute.prototype.render = function() {
   var D = this.D, P = D.P, t0 = fvNowMs();
   if (!this.frame || this.frame.width !== D.VW || this.frame.height !== D.VH) this.frame = new Bitmap(D.VW, D.VH, BitmapFormat.RGB32);
   // la nave en su hueco: el fotograma de verdad a su tamaño (el hueco del mapa que esta en grande)
   // (el pintor dibuja las estrellas en pixeles absolutos: en un mapa de bits pequeño salian enormes y blancas; se pinta a tamaño de
   // fotograma, como siempre, y se reduce con scaledTo)
   var c = D.cockpit, slot = (this.big === "map3d") ? c.map3d : c.map2d, sw = slot[2] - slot[0], sh = slot[3] - slot[1], a = D.VW / D.VH;
   var mw = Math.max(16, Math.round(Math.min(sw, sh * a))), mh = Math.max(9, Math.round(mw / a));
   if (!this.full || this.full.width !== D.VW || this.full.height !== D.VH) this.full = new Bitmap(D.VW, D.VH, BitmapFormat.RGB32);
   var ps = D.painter.render(this.full, P, { hud: false, frame: false, vignette: true }), st = {}, k;
   for (k in ps) st[k] = ps[k];                                        // copia: el objeto de estadisticas del pintor es compartido
   this.mini = this.full.scaledTo(mw, mh);
   this.paintBig();
   st.ms = fvNowMs() - t0; st.route = true;
   return st;
};
FVRoute.prototype.paintBig = function() {
   var D = this.D, P = D.P, sc = D.scene, b = this.frame, G = this.geom(), kB = G.kB, kH = G.kH, i;
   b.fill(0xff07060A);
   var g = new Graphics(b);
   try {
      g.antialiasing = true; g.textAntialiasing = true;
      var r = G.map;
      if (this.big === "map2d") this.m2.paint(g, r, sc, P, kB, D.nav.trail);
      else this.m3.paint(g, r, P, kB, P.sel, D.nav.trail);
      this.paintCams(g, r, kB, this.big, D.VW, D.VH, "B");
      if (this.drag && this.drag.kind === "new" && this.drag.moved) this.paintPreview(g, r, kB);
      if (this.big === "map3d") this.paintTilt(g, r, kB, kH);                          // (nD2) el asa de inclinacion de los planos
      // la placa del titulo (arriba a la izquierda) con la ayuda corta; la larga va en el tooltip (§11.7)
      var fT = cpFont("display", 13 * kH, false, false, Math.round(2.5 * kH)), fS = cpFont("text", 11 * kH, false, true);
      var ttl = (this.big === "map2d" ? "TABULA" : "PROFUNDITAS") + " · ITINERARIUM", hint = fvTx(this.big === "map2d" ? "rt.hint2" : "rt.hint3");
      var tw = Math.max(fT.width(ttl), fS.width(hint)) + 30 * kH, x0 = 16 * kH, y0 = 14 * kH;
      g.fillRect(x0, y0, x0 + tw, y0 + 40 * kH, new Brush(0xd0110D09));
      g.pen = new Pen(FV_CK.brass2, 1.2 * kH); g.drawRect(x0 + 0.5, y0 + 0.5, x0 + tw - 0.5, y0 + 40 * kH - 0.5);
      fvRivet(g, x0 + 8 * kH, y0 + 12 * kH, 2.2 * kH);
      g.font = fT; g.pen = new Pen(FV_CK.gold); g.drawText(x0 + 16 * kH, y0 + 17 * kH, ttl);
      g.font = fS; g.pen = new Pen(0xffD0C1A5); g.drawText(x0 + 16 * kH, y0 + 33 * kH, hint);
      // la botonera
      var B = G.bar; this.hits = [];
      g.fillRect(B[0], B[1], B[2], B[3], new Brush(0xd8110D09)); g.pen = new Pen(FV_CK.brass2, 1.2 * kH); g.drawRect(B[0] + 0.5, B[1] + 0.5, B[2] - 0.5, B[3] - 0.5);
      for (i = 0; i < G.btn.length; ++i) {
         var t = G.btn[i], q = t.r, hov = (this.vhover === "btn:" + t.id) && t.on;
         if (t.on) g.fillRect(q[0], q[1], q[2], q[3], fvBrassBrush((q[0] + q[2]) / 2, (q[1] + q[3]) / 2, (q[2] - q[0]) / 2)); else g.fillRect(q[0], q[1], q[2], q[3], new Brush(0xff2A2016));
         g.pen = new Pen(hov ? 0xffFFF3C4 : FV_HUD_COL.brassD, hov ? 1.6 * kH : 0.8 * kH); g.drawRect(q[0] + 0.5, q[1] + 0.5, q[2] - 0.5, q[3] - 0.5);
         var ink = t.on ? FV_HUD_COL.ink : 0xff6A5A40;
         fvRtGlyph(g, t.glyph, q[0] + 14 * kH, (q[1] + q[3]) / 2, 13 * kH, ink);
         g.font = G.fB; g.pen = new Pen(ink); g.drawText(q[0] + 26 * kH, q[3] - 7.5 * kH, t.text);
         this.hits.push({ id: "btn:" + t.id, r: q, on: t.on });
      }
   } finally { g.end(); }
};
// las camaras en un mapa (grande o pequeño): cono (TABULA: su huella; PROFUNDITAS: las aristas), insignia numerada y la ruta como curva
// which = "map2d" | "map3d"; r = rectangulo del mapa; kc = escala de los dibujos; tag = "B" (mapa grande: lo que se pulsa), "P" (vista previa)
// o "" (franja). Guarda en this.marks[which + tag] la posicion de cada insignia.
FVRoute.prototype.paintCams = function(g, r, kc, which, VW, VH, tag, base) {
   var sc = this.D.scene, cams = this.cams, i, j, S = Math.max(7, 6.5 * kc), pts = [], marks = [], self = this;
   var w = r[2] - r[0], h = r[3] - r[1];
   function uvXY(p) { var uv = fvNavPhotoUV(sc, p); return uv ? [r[0] + uv[0] * w, r[1] + uv[1] * h] : null; }
   function at(p) { return which === "map2d" ? uvXY(p) : self.m3pt(p, r, !tag); }
   g.antialiasing = true;
   for (i = 0; i < cams.length; ++i) {
      var c = cams[i], on = (i === this.sel), apex = at(c.pos), tg = at(c.tgt), cr = fvRtCorners(c, VW, VH), q = [];
      for (j = 0; j < 4; ++j) { var qq = at(cr[j]); if (qq) q.push(qq); }
      if (q.length === 4) {
         var poly = q.map(function(v) { return new Point(v[0], v[1]); });
         g.fillPolygon(poly, new Brush(on ? 0x40FFF3C4 : FV_RT_COL.cone));
         g.pen = new Pen(on ? 0xe0FFF3C4 : 0xa0F3D27E, Math.max(1, (on ? 1.4 : 1.0) * kc)); g.drawPolyline(poly.concat([poly[0]]));
         if (which === "map3d" && apex) { g.pen = new Pen(on ? 0xc0FFF3C4 : 0x70F3D27E, Math.max(0.8, 0.8 * kc)); for (j = 0; j < 4; ++j) g.drawLine(apex[0], apex[1], q[j][0], q[j][1]); }
      }
      if (apex && tg && (Math.abs(apex[0] - tg[0]) + Math.abs(apex[1] - tg[1]) > 3)) { g.pen = new Pen(0x90F3D27E, Math.max(1, 0.9 * kc)); fvNavDash(g, apex[0], apex[1], tg[0], tg[1], 3 * kc, 2 * kc); }
      var m = apex || tg;
      if (m) pts.push(m);
      marks.push(m);
   }
   fvRtCurve(g, pts, kc);
   for (i = 0; i < marks.length; ++i) if (marks[i]) fvRtBadge(g, marks[i][0], marks[i][1], (base || 0) + i + 1, S, i === this.sel);
   if (!this.marks) this.marks = {};
   this.marks[which + (tag || "")] = { pts: marks, S: S, r: r };
};
// (nD2) el mapa grande orbita; la franja (tag "") sigue con la proyeccion de gabinete del mapa pequeño
FVRoute.prototype.m3pt = function(p, r, cab) {
   if (!cab) return this.m3.pt(p, r);
   var v = this.m3.view; this.m3.view = null;
   try { return this.m3.pt(p, r); } finally { this.m3.view = v; }
};
// (nD2) el asa de inclinacion: en el borde de arriba de la losa de la nebulosa (inclinada), un poco por encima -> [x, y, S] | null
FVRoute.prototype.tiltHandle = function(r, kB) {
   var N = this.D.scene.nebula; if (!N || !this.m3) return null;
   var q = this.m3.slabPt(this.m3.depth(N.distLy), 0, -1.25, r);
   return q ? [q[0], q[1], Math.max(8, 7.5 * kB)] : null;
};
FVRoute.prototype.paintTilt = function(g, r, kB, kH) {
   var h = this.tiltHandle(r, kB); if (!h) return;
   var on = (this.drag && this.drag.kind === "tilt") || this.vhover === "tilt";
   fvRtTiltGlyph(g, h[0], h[1], h[2], on);
   if (on || this.tilt[0] || this.tilt[1]) {
      var f = cpFont("text", 11 * kH, false, true), lab = fvTx("rt.tiltLab", { x: fvNum(this.tilt[0], 0, FV_LANG), y: fvNum(this.tilt[1], 0, FV_LANG) });
      g.font = f; var x = h[0] + h[2] + 6 * kH, y = h[1] + 4 * kH, ww = f.width(lab) + 10 * kH;
      if (x + ww > r[2]) x = h[0] - h[2] - 6 * kH - ww;
      g.fillRect(x, y - f.ascent - 3 * kH, x + ww, y + 4 * kH, new Brush(0xd0110D09)); g.pen = new Pen(on ? FV_RT_COL.sel : FV_RT_COL.gold); g.drawText(x + 5 * kH, y, lab);
   }
};
// el cono de la camara que se esta poniendo (arrastre en TABULA)
FVRoute.prototype.paintPreview = function(g, r, kc) {
   var d = this.drag, c = d.cam; if (!c) return;
   var keep = this.cams; this.cams = [c];
   var keepSel = this.sel; this.sel = 0;
   try { this.paintCams(g, r, kc, this.big, this.D.VW, this.D.VH, "P", keep.length); } finally { this.cams = keep; this.sel = keepSel; }      // con el numero que tendra
   var f = cpFont("text", 12 * fvHudK(this.D.VW), false, true), stand = fvLen(fvSub(c.tgt, c.pos)), lab = fvTx("rt.dragLab", { t: d.tName || fvNavDistText(fvLen(c.tgt), "measured", FV_LANG), d: fvNavDistText(stand, "measured", FV_LANG) });
   g.font = f; var x = d.x1 + 14, y = d.y1 - 10, ww = f.width(lab) + 12;
   if (x + ww > r[2]) x = d.x1 - 14 - ww;
   g.fillRect(x, y - f.ascent - 4, x + ww, y + 6, new Brush(0xd0110D09)); g.pen = new Pen(FV_RT_COL.sel); g.drawText(x + 6, y, lab);
   g.pen = new Pen(0xc0FFF3C4, 1.2); fvNavDash(g, d.x0, d.y0, d.x1, d.y1, 5, 4);
};
// ---- el raton en la pantalla grande (coordenadas del FOTOGRAMA) ----
FVRoute.prototype.hitBtn = function(x, y) { for (var i = 0; i < this.hits.length; ++i) { var q = this.hits[i].r; if (x >= q[0] && x <= q[2] && y >= q[1] && y <= q[3]) return this.hits[i]; } return null; };
FVRoute.prototype.hitMark = function(x, y) {
   var M = this.marks ? this.marks[this.big + "B"] : null, best = -1, bd = 1e9;
   if (!M) return -1;
   for (var i = 0; i < M.pts.length; ++i) { var p = M.pts[i]; if (!p) continue; var d = Math.sqrt(Math.pow(p[0] - x, 2) + Math.pow(p[1] - y, 2)); if (d <= 1.3 * M.S && d < bd) { bd = d; best = i; } }
   return best;
};
// lo mas cercano al punto (x, y) del mapa grande: objeto de C o estrella (medida, G ≤ 13) -> sel | null
FVRoute.prototype.pickAt = function(x, y) {
   var D = this.D, sc = D.scene, S = sc.stars, G = this.geom(), r = G.map, R = FV_ROUTE.PICK_PX * G.kH, best = null, bs = 1e9, i, q, self = this;
   function at(p) { if (self.big === "map2d") { var uv = fvNavPhotoUV(sc, p); return uv ? [r[0] + uv[0] * (r[2] - r[0]), r[1] + uv[1] * (r[3] - r[1])] : null; } return self.m3.pt(p, r); }
   if (sc.objects) for (i = 0; i < sc.objects.length; ++i) {
      var o = sc.objects[i]; if (!o.pos || o.main) continue;
      // (P23-mapas) el objeto se busca donde el mapa lo dibuja (FV_NAV.BOX_MAP: en la losa si cae mas alla de la boca)
      q = at(fvNavObjPos(sc, o)); if (!q) continue;
      var dd = Math.sqrt(Math.pow(q[0] - x, 2) + Math.pow(q[1] - y, 2));
      if (dd < R && dd < bs) { bs = dd; best = { kind: "object", i: i }; }
   }
   if (!best && S) for (i = 0; i < S.n; ++i) {
      if (!S.inFrame[i] || S.q[i] > 1 || S.g[i] > 13) continue;
      q = at(fvStarPos(sc, i)); if (!q) continue;
      var e = Math.sqrt(Math.pow(q[0] - x, 2) + Math.pow(q[1] - y, 2)) * (1 + 0.06 * (S.g[i] - 6));
      if (e < R && e < bs) { bs = e; best = { kind: "star", i: i }; }
   }
   return best;
};
// el objetivo de un clic en TABULA grande: lo mas cercano o la nebulosa en ese punto -> { tgt, name, sel, stand0 }
FVRoute.prototype.targetAt = function(x, y) {
   var D = this.D, sc = D.scene, P = D.P, G = this.geom(), r = G.map, s = this.pickAt(x, y);
   if (s) { var c = fvRouteCamForSel(P, s); if (c) return { tgt: c.tgt, name: c.name, sel: s, stand0: fvLen(fvSub(c.tgt, c.pos)) }; }
   if (this.big !== "map2d") return null;
   var u = (x - r[0]) / (r[2] - r[0]), v = (y - r[1]) / (r[3] - r[1]), f = sc.field, Dn = sc.nebula ? sc.nebula.distLy : 1000;
   if (u < 0 || u > 1 || v < 0 || v > 1) return null;
   return { tgt: fvPixelPoint(sc, u * f.width, v * f.height, Dn), name: "", sel: null, stand0: fvRouteNebStand(sc) };
};
// clic en la nebulosa sin objeto: la camara a la distancia a la que su campo (FOV_DEG) abarca NEB_VIEW del ancho de la foto en el plano de
// la nebulosa (con 0,25 × D, la primera version, el cono de 40° abarcaba ~10 veces la foto y la tapaba entera con su velo)
function fvRouteNebStand(sc) {
   var f = sc.field, Dn = sc.nebula ? sc.nebula.distLy : 1000;
   if (!f || !(f.F > 0)) return FV_ROUTE.STAND_NEB * Dn;
   var wLy = (f.width / f.F) * Dn;
   return fvClamp(0.5 * FV_ROUTE.NEB_VIEW * wLy / Math.tan(fvRouteFov() / 2), 1e-3 * Dn, FV_ROUTE.STAND_NEB * Dn);
}
FVRoute.prototype.standFromDrag = function(L, dT) {
   var H = this.D.VH, a = fvClamp(L / (0.55 * H), 0, 1);
   return dT * Math.exp(Math.log(FV_ROUTE.STAND_LO) + (Math.log(FV_ROUTE.STAND_HI) - Math.log(FV_ROUTE.STAND_LO)) * a);
};
// -> true si lo consume
FVRoute.prototype.viewPress = function(x, y) {
   if (!this.big) return false;
   var h = this.hitBtn(x, y);
   if (h) { this.drag = { kind: "btn", id: h.id, on: h.on }; return true; }
   if (this.big === "map3d" && this.hitTilt(x, y)) { this.drag = { kind: "tilt", x0: x, y0: y, x1: x, y1: y, moved: false, t0: this.tilt.slice() }; return true; }   // (nD2)
   var m = this.hitMark(x, y);
   if (m >= 0) { this.sel = m; this.reveal(m); this.drag = { kind: "cam", i: m, x0: x, y0: y, x1: x, y1: y, moved: false, c0: { pos: this.cams[m].pos.slice(), look: this.cams[m].look.slice(), tgt: this.cams[m].tgt.slice() } }; this.D.strip.repaint(); return true; }
   var T = this.targetAt(x, y);
   this.drag = { kind: "new", x0: x, y0: y, x1: x, y1: y, moved: false, T: T, cam: null, tName: T ? T.name : "" };
   // (nD2) PROFUNDITAS: si se arrastra (> ORBIT_PX) es ORBITAR la vista (aunque se empiece sobre una estrella); si no, al soltar, su camara
   if (this.big === "map3d") { var v = this.m3.view || fvNavViewHome(); this.drag.v0 = { az: v.az, el: v.el, zoom: v.zoom }; }
   return true;
};
// (nD2) ¿el asa de inclinacion esta en (x, y)?
FVRoute.prototype.hitTilt = function(x, y) {
   if (this.big !== "map3d") return false;
   var G = this.geom(), h = this.tiltHandle(G.map, G.kB);
   return !!h && Math.sqrt(Math.pow(x - h[0], 2) + Math.pow(y - h[1], 2)) <= 1.35 * h[2];
};
// (nD2) la rueda en el mapa grande: PROFUNDITAS acerca / aleja la vista (15 % por muesca de 120); TABULA no hace nada (no hay zoom en la foto)
FVRoute.prototype.viewWheel = function(x, y, delta) {
   if (this.big !== "map3d" || !this.m3) return true;
   var v = this.m3.view || fvNavViewHome(), n = (delta || 0) / 120;
   this.m3.setView({ az: v.az, el: v.el, zoom: v.zoom * Math.pow(FV_NAV_ORBIT.WHEEL, n) });
   this.redraw();
   return true;
};
// (nD2) doble clic en PROFUNDITAS grande: en el asa = planos sin inclinar; en el vacio = la vista de partida (sin camara debajo ni estrella)
FVRoute.prototype.viewDouble = function(x, y) {
   if (this.big !== "map3d" || !this.m3) return true;
   if (this.hitTilt(x, y)) { this.setTilt([0, 0]); this.save(); this.redraw(); return true; }
   if (this.hitMark(x, y) < 0 && !this.pickAt(x, y)) { this.m3.setView(fvNavViewHome()); this.redraw(); }
   return true;
};
FVRoute.prototype.redraw = function() { try { this.D.renderNow(); this.D.view.repaint(); } catch (e) {} };
FVRoute.prototype.viewMove = function(x, y, buttons) {
   if (!this.big) return false;
   var d = this.drag, G;
   if (!d || !buttons) {
      var h = this.hitBtn(x, y), id = h ? "btn:" + h.id : (this.hitTilt(x, y) ? "tilt" : (this.hitMark(x, y) >= 0 ? "mark" : null));
      if (id !== this.vhover) { this.vhover = id; try { this.D.view.toolTip = fvTipBoth(id === "tilt" ? "rt.tipTilt" : (this.big === "map2d" ? "rt.tipBig2" : "rt.tipBig3")); } catch (eT) {} var hand = !!id; if (hand !== this.D.viewHand) { this.D.viewHand = hand; this.D.view.cursor = new Cursor(hand ? StdCursor_PointingHand : StdCursor_Cross); } }
      return true;
   }
   d.x1 = x; d.y1 = y;
   // (nD2) en PROFUNDITAS el umbral es ORBIT_PX (4 px): por debajo, un clic
   if (Math.abs(x - d.x0) + Math.abs(y - d.y0) > (this.big === "map3d" ? FV_ROUTE.ORBIT_PX : FV_ROUTE.DRAG_PX)) d.moved = true;
   if (!d.moved) return true;
   if (d.kind === "cam") this.stopFly("edit");               // (K12 H-1) arrastrar una camara la cambia: el recorrido en marcha ya no es el de la lista
   var sc = this.D.scene;
   if (d.kind === "new" && this.big === "map3d") {
      // (nD2) ORBITAR: azimut con lo horizontal, elevacion con lo vertical (DEG_PER_W / DEG_PER_H grados por ancho / alto del mapa)
      G = this.geom(); var rM = G.map, wM = rM[2] - rM[0], hM = rM[3] - rM[1];
      this.m3.setView({ az: d.v0.az + (x - d.x0) / wM * FV_NAV_ORBIT.DEG_PER_W, el: d.v0.el + (y - d.y0) / hM * FV_NAV_ORBIT.DEG_PER_H, zoom: d.v0.zoom });
      d.orbit = true;
   } else if (d.kind === "tilt") {
      // (nD2) INCLINAR los planos: arriba/abajo = alrededor de X (cabeceo), izquierda/derecha = alrededor de Y (guiñada)
      this.setTilt([d.t0[0] - (y - d.y0) * FV_NAV_ORBIT.TILT_DEG_PX, d.t0[1] + (x - d.x0) * FV_NAV_ORBIT.TILT_DEG_PX]);
   } else if (d.kind === "new" && d.T && this.big === "map2d") {
      var dT = fvLen(d.T.tgt), L = Math.sqrt(Math.pow(x - d.x0, 2) + Math.pow(y - d.y0, 2));
      d.cam = fvRouteCamAt(d.T.tgt, Math.min(0.95 * dT, this.standFromDrag(L, dT)), d.T.name);
   } else if (d.kind === "cam") {
      var c = this.cams[d.i]; G = this.geom(); var r = G.map;
      if (this.big === "map2d") {
         // mover por la foto: gira la camara entera (posicion, mirada y objetivo) alrededor de la Tierra lo que gira su objetivo
         var u = fvClamp((x - r[0]) / (r[2] - r[0]), 0, 1), v = fvClamp((y - r[1]) / (r[3] - r[1]), 0, 1), f = sc.field;
         var a = fvNorm(d.c0.tgt), b = fvNorm(fvPixelRay(sc, u * f.width, v * f.height)), ax = fvCross(a, b), ang = fvAngle(a, b);
         if (fvLen(ax) > 1e-12 && ang > 1e-9) { ax = fvNorm(ax); c.pos = fvRotate(d.c0.pos, ax, ang); c.look = fvNorm(fvRotate(d.c0.look, ax, ang)); c.tgt = fvRotate(d.c0.tgt, ax, ang); }
      } else {
         // la profundidad: hacia donde apunta el eje de distancias del mapa, mas lejos de la Tierra (escala logaritmica); camara y objetivo se
         // alejan juntos. (nD2) con la vista orbitable el eje puede apuntar a cualquier lado: el arrastre se proyecta sobre el eje en pantalla
         // (con la vista de gabinete el eje es horizontal y mide 0,80 del ancho: la formula de antes, (x − x0) / (0,80 · ancho))
         var m3 = this.m3, A0 = m3.screen([0, 0, 0], r), A1 = m3.screen([1, 0, 0], r), ax = A1[0] - A0[0], ay = A1[1] - A0[1], aa = Math.max(1e-9, ax * ax + ay * ay);
         var dt0 = fvLen(d.c0.tgt), s0 = m3.depth(dt0), s1 = fvClamp(s0 + ((x - d.x0) * ax + (y - d.y0) * ay) / aa, 0.02, 0.995);
         var dNew = m3.d0 * (Math.exp(s1 * Math.log(1 + m3.dMax / m3.d0)) - 1), k = dNew / Math.max(1e-9, dt0);
         c.pos = fvMul(d.c0.pos, k); c.tgt = fvMul(d.c0.tgt, k);
      }
      this.freeThumbOf(c);
   }
   return true;
};
FVRoute.prototype.viewRelease = function(x, y) {
   if (!this.big) return false;
   var d = this.drag; this.drag = null;
   if (!d) return true;
   if (d.kind === "btn") { var h = this.hitBtn(x, y); if (h && h.id === d.id && h.on) this.button(h.id.replace(/^btn:/, "")); return true; }
   if (d.kind === "cam") { if (d.moved) { this.save(); fvLog("route: camera " + (d.i + 1) + " moved"); } this.D.strip.repaint(); return true; }
   if (d.kind === "tilt") { if (d.moved) { this.save(); fvLog("route: planes tilted " + this.tilt.map(function(v) { return v.toFixed(1); }).join("/") + " deg"); } this.redraw(); return true; }
   if (d.kind === "new" && d.orbit) return true;                       // (nD2) fue orbitar: no se pone camara
   if (d.kind === "new") {
      var c = null;
      if (d.moved && d.cam) c = d.cam;
      else if (!d.moved && d.T) {
         if (d.T.sel) c = fvRouteCamForSel(this.D.P, d.T.sel);
         else c = fvRouteCamAt(d.T.tgt, d.T.stand0, "");
      }
      if (c) this.addCam(c);
   }
   return true;
};
FVRoute.prototype.button = function(id) {
   if (id === "add") this.addCam(fvRouteCamOfShip(this.D.P, ""));
   else if (id === "play") { if (this.play) this.stopFly("button"); else this.fly(); }
   else if (id === "suggest") this.suggest();
};
// ---- las acciones de la lista (las usan la franja y las pruebas) ----
FVRoute.prototype.addCam = function(c) {
   if (this.cams.length >= FV_ROUTE.MAX) { this.D.ui.caption = { text: fvTx("rt.full", { n: FV_ROUTE.MAX }), t0: this.D.P.t, dur: 2.2 }; return -1; }
   this.cams.push(c); this.sel = this.cams.length - 1; this.reveal(this.sel); this.save();
   fvLog("route: camera " + this.cams.length + " added (" + (c.name || "-") + ") at " + fvNum(fvLen(c.pos), 1, "en") + " ly from Earth, target " + fvNum(fvLen(c.tgt), 1, "en") + " ly");
   try { this.D.strip.repaint(); } catch (e) {}
   return this.sel;
};
FVRoute.prototype.move = function(i, delta) {
   var j = i + delta, a = this.cams; if (!(i >= 0 && i < a.length && j >= 0 && j < a.length)) return false;
   var t = a[i]; a[i] = a[j]; a[j] = t; this.sel = j; this.reveal(j); this.save(); return true;
};
FVRoute.prototype.remove = function(i) {
   if (!(i >= 0 && i < this.cams.length)) return false;
   if (this.sel > i) --this.sel;                              // (K12 H-3) borrar una camara anterior a la elegida: la elegida es la misma, una fila mas arriba
   this.cams.splice(i, 1); if (this.sel >= this.cams.length) this.sel = this.cams.length - 1; this.clamp(); this.save(); return true;
};
FVRoute.prototype.replace = function(i) { if (!(i >= 0 && i < this.cams.length)) return false; var o = this.cams[i], c = fvRouteCamOfShip(this.D.P, o.name); c.holdS = o.holdS; this.cams[i] = c; this.sel = i; this.save(); return true; };
FVRoute.prototype.rename = function(i, s) {
   if (!(i >= 0 && i < this.cams.length)) return false;
   var nm = String(s || "").replace(/^\s+|\s+$/g, "").substring(0, 60);
   if (nm === (this.cams[i].name || "")) return true;         // (K12 H-1) sin cambio no se guarda: abrir el campo y salir sin tocar no debe parar el recorrido
   this.cams[i].name = nm; this.save(); return true;
};
FVRoute.prototype.cycleHold = function(i) {
   if (!(i >= 0 && i < this.cams.length)) return false;
   var H = FV_ROUTE.HOLDS, cur = this.cams[i].holdS, at = 0, q; for (q = 0; q < H.length; ++q) if (H[q] <= cur + 1e-9) at = q;
   this.cams[i].holdS = H[(at + 1) % H.length]; this.save(); return true;
};
// (nD2) el chip de la animacion: un clic pasa al tipo siguiente (ninguna → orbita → acercamiento → alejamiento → barrido → balanceo →
// paralaje → ninguna) con la duracion de ese tipo; el de la duracion pasa a la siguiente de ANIM_S
FVRoute.prototype.setAnim = function(i, kind, sec) {
   if (!(i >= 0 && i < this.cams.length)) return false;
   if (!kind || kind === "none" || FV_ROUTE.ANIMS.indexOf(kind) <= 0) delete this.cams[i].anim;
   else this.cams[i].anim = { k: kind, s: (sec > 0) ? sec : FV_ROUTE.ANIM_S0[kind] };
   this.save(); return true;
};
FVRoute.prototype.cycleAnim = function(i) {
   if (!(i >= 0 && i < this.cams.length)) return false;
   var A = FV_ROUTE.ANIMS, an = fvRouteAnimOf(this.cams[i]), at = an ? A.indexOf(an.k) : 0, nk = A[(at + 1) % A.length];
   return this.setAnim(i, nk, an && nk !== "none" ? an.s : 0);
};
FVRoute.prototype.cycleAnimDur = function(i) {
   var an = (i >= 0 && i < this.cams.length) ? fvRouteAnimOf(this.cams[i]) : null; if (!an) return false;
   var S = FV_ROUTE.ANIM_S, at = -1, q; for (q = 0; q < S.length; ++q) if (S[q] <= an.s + 1e-9) at = q;
   return this.setAnim(i, an.k, S[(at + 1) % S.length]);
};
FVRoute.prototype.clearAll = function() { this.cams = []; this.sel = -1; this.top = 0; this.save(); return true; };
FVRoute.prototype.name = function(i) { var c = this.cams[i]; return (c && c.name) ? c.name : fvTx("rt.cam", { n: i + 1 }); };
// ✦ PROPONER: la ruta de fvTourPlan (Codex, K6) con los objetos de C; se AÑADEN al final (no borra lo que hay)
FVRoute.prototype.suggest = function() {
   var D = this.D, P = D.P, sc = D.scene; if (typeof fvTourPlan !== "function" || !sc.objects) return 0;
   var L = FV_ROUTE.LEG, k = (typeof fvPathDurK === "function") ? fvPathDurK(P) : fvSpeedDurK(P);
   var plan = fvTourPlan(sc.objects, P.cam.pos, { maxStops: Math.min(6, FV_ROUTE.MAX - this.cams.length), maxTotalS: 240, legS: function(a, b) { var d = fvLen(fvSub(b, a)); return fvClamp(L.MIN + L.DEC * Math.log(Math.max(1, d / Math.max(1e-3, 0.05 * fvLen(b)))) / Math.LN10, L.MIN, L.MAX) * k; } });
   var n = 0;
   for (var s = 0; s < plan.stops.length; ++s) {
      var st = plan.stops[s], o = sc.objects[st.i], sel = o.main ? { kind: "nebula" } : ((o.type === "star" || o.type === "exoplanet") && o.star >= 0 ? { kind: "star", i: o.star } : { kind: "object", i: st.i });
      var c = fvRouteCamForSel(P, sel); if (!c) continue;
      c.holdS = Math.min(8, st.holdS || FV_ROUTE.HOLD0); if (!c.name) c.name = o.name || "";
      if (this.addCam(c) >= 0) ++n;
   }
   fvLog("route: suggested " + n + " stop(s) (" + plan.reason + ", " + Math.round(plan.totalS) + " s)");
   if (!n) D.ui.caption = { text: fvTx("rt.noSuggest"), t0: P.t, dur: 2.4 };
   return n;
};
// ---- (d) RECORRER ----
// la duracion: el respaldo de todas las camaras (lo de antes) + las animaciones de llegada
FVRoute.prototype.estimate = function() {
   if (!this.cams.length || !this.D.P) return 0;
   var pl = new FVRoutePlay(this.D.P, fvRouteKeys(this.cams)), s = pl.total(), i;
   for (i = 0; i < this.cams.length; ++i) { var an = fvRouteAnimOf(this.cams[i]); if (an) s += an.s; }
   return s;
};
// (nD2) el recorrido va por TRAMOS (fvRouteSegs): cada uno vuela con el motor (o el respaldo) hasta la camara animada que lo cierra, y alli
// la animacion de llegada (FVRouteAnim), su parada y el tramo siguiente. play = { engine, i0, n, at, quiet, snap (las camaras), segs, si,
// phase: "fly" | "anim" | "hold", fl (vuelo del motor del tramo), pl (respaldo del tramo), an, holdT }
FVRoute.prototype.fly = function(from, quiet) {
   var D = this.D, P = D.P, i0 = from || 0;
   if (!P || this.cams.length <= i0) return false;
   if (this.renaming >= 0) this.renameEnd(true);              // (K12 H-1) el renombrado pendiente se guarda ANTES (guardar para el recorrido; despues pararia el que se arranca)
   var snap = this.cams.slice(i0).map(function(c) { return { name: c.name, pos: c.pos.slice(), look: c.look.slice(), fov: c.fov, holdS: c.holdS, tgt: c.tgt.slice(), anim: c.anim ? { k: c.anim.k, s: c.anim.s } : null }; });
   D.tour = null; D.lookTo = null; if (P.flight || P.orbit) fvPilotStop(P); P.coast = null; if (typeof fvFreeHalt === "function") fvFreeHalt(P);
   D.ui.hideCard = true; D.reopenCard = false; D.reopenAt = null;
   this.play = { engine: (typeof fvPilotFlyPath === "function") && !FV_ROUTE.FORCE_FALLBACK, i0: i0, n: snap.length, at: -1, quiet: !!quiet, snap: snap, segs: fvRouteSegs(snap), si: -1, phase: "fly", fl: null, pl: null, an: null, holdT: 0 };
   this.nextSeg();
   if (!this.play) return false;
   fvLog("route: flying " + snap.length + " camera(s) in " + this.play.segs.length + " leg(s) with " + (this.play.fl ? "fvPilotFlyPath" : "the fallback") + (this.play.pl ? " · " + fvNum(this.play.pl.total(), 1, "en") + " s" : ""));
   if (this.big) this.close();
   if (!quiet) D.ui.caption = { text: fvTx("rt.flying", { i: 1, n: snap.length }), t0: P.t, dur: 2.0 };
   return true;
};
// el tramo siguiente (o el final)
FVRoute.prototype.nextSeg = function() {
   var p = this.play, P = this.D.P; if (!p) return;
   p.si += 1; p.an = null; p.fl = null; p.pl = null;
   if (p.si >= p.segs.length) { this.finish(); return; }
   var sg = p.segs[p.si], keys = fvRouteKeys(p.snap.slice(sg.a, sg.b + 1)), ok = false;
   if (sg.anim) keys[keys.length - 1].holdS = 0;              // la parada de una camara animada va DESPUES de su animacion
   p.phase = "fly";
   if (p.engine) { try { ok = fvPilotFlyPath(P, keys, { speed: P.speed, style: P.style }) !== false; } catch (e) { ok = false; fvLog("route: fvPilotFlyPath failed: " + e); } }
   if (ok) p.fl = P.flight;
   else { p.pl = new FVRoutePlay(P, keys); P.mode = "route"; P.arrivedAt = null; }
};
// el tramo llego a su ultima camara: su animacion (si la tiene) o el siguiente
FVRoute.prototype.segEnd = function() {
   var p = this.play, P = this.D.P, sg = p.segs[p.si];
   if (sg.anim) { p.phase = "anim"; p.an = new FVRouteAnim(P, p.snap[sg.b], sg.anim); P.mode = "route"; P.arrivedAt = null; fvLog("route: camera " + (p.i0 + sg.b + 1) + " arrival animation " + sg.anim.k + " " + sg.anim.s + " s"); }
   else this.nextSeg();
};
FVRoute.prototype.finish = function() {
   var p = this.play, D = this.D, P = D.P; this.play = null; D.ui.hideCard = false;
   if (P) { if (P.mode === "route") P.mode = "free"; P.cam.roll = 0; P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] }; P.vel = [0, 0, 0]; P.speedLyS = 0; P.speedC = 0; }
   if (p && !p.quiet) this.done();
};
// la camara (indice de la lista) hacia la que se va o en la que se esta, o -1
FVRoute.prototype.playAt = function() {
   var p = this.play; if (!p || p.si < 0 || p.si >= p.segs.length) return -1;
   var sg = p.segs[p.si], k = sg.b;
   if (p.phase === "fly") { if (p.fl) k = sg.a + Math.max(0, p.fl.keyIdx !== undefined ? p.fl.keyIdx : 0); else if (p.pl) k = sg.a + Math.min(p.pl.leg, p.pl.dur.length - 1); }
   return p.i0 + k;
};
FVRoute.prototype.stopFly = function(why) {
   var p = this.play, P = this.D.P; if (!p) return false;
   this.play = null; this.D.ui.hideCard = false;
   if (P) { if (p.fl && P.flight && P.flight === p.fl) fvPilotStop(P); if (P.mode === "route") P.mode = "free"; P.cam.roll = 0; P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] }; }
   fvLog("route: stopped (" + (why || "?") + ")");
   return true;
};
// un tic del reloj (despues de fvPilotStep): mueve la camara del respaldo y de la animacion, sigue al motor, cuida la ficha y las miniaturas
FVRoute.prototype.tick = function(dt) {
   var D = this.D, P = D.P, p = this.play;
   if (!P) return;
   if (p) {
      var userAct = (D.drag && D.drag.moved) || P.orbit;
      if (p.phase === "fly" && p.fl) {
         // el motor: su vuelo se acabo (null) = llego; otro vuelo = lo lanzo el usuario
         if (P.flight !== p.fl) { if (P.flight || userAct) this.stopFly("user"); else this.segEnd(); }
      } else if (P.flight || userAct) this.stopFly("user");    // cualquier mando de vuelo del usuario (viajar, casa, orbitar, arrastrar)
      else {
         var prev = P.cam.pos.slice();
         if (p.phase === "fly") { p.pl.step(P, dt); if (p.pl.done) this.segEnd(); }
         else if (p.phase === "anim") { p.an.step(P, dt); if (p.an.done) { p.phase = "hold"; p.holdT = p.snap[p.segs[p.si].b].holdS || 0; if (!(p.holdT > 0)) this.nextSeg(); } }
         else if (p.phase === "hold") { p.holdT -= dt; if (p.holdT <= 1e-9) this.nextSeg(); }
         if (dt > 0) { P.vel = fvMul(fvSub(P.cam.pos, prev), 1 / dt); P.speedLyS = fvLen(P.vel); P.speedC = P.speedLyS * FV_PILOT.SEC_PER_YEAR; }
      }
      var at = this.playAt();
      if (this.play && at >= 0 && at !== this.play.at) { this.play.at = at; if (!this.play.quiet) D.ui.caption = { text: fvTx("rt.flying", { i: at - this.play.i0 + 1, n: this.play.n }), t0: P.t, dur: 2.0 }; }
   }
   this.tripStep();
   if (this.big) this.thumbStep();
};
FVRoute.prototype.done = function() { var D = this.D; D.ui.caption = { text: fvTx("rt.done"), t0: D.P.t, dur: 2.2 }; fvLog("route: done"); };
// (f) la linea de la ficha: distancia desde la nave y duracion del viaje con el MODUS y con el otro modo (como mucho cada TRIP_EVERY_S)
FVRoute.prototype.tripStep = function() {
   var D = this.D, P = D.P, sel = P.sel;
   if (!sel || P.flight || !D.cardOpen() || D.ui.hideCard) { D.ui.trip = null; this.tripKey = ""; return; }
   var key = sel.kind + ":" + sel.i + ":" + D.style + ":" + (P.speed || 0).toFixed(3) + ":" + P.cam.pos.map(function(v) { return v.toPrecision(5); }).join(",");
   if (key === this.tripKey && D.ui.trip) return;
   if (D.ui.trip && P.t - this.tripAt < FV_ROUTE.TRIP_EVERY_S && key.split(":").slice(0, 4).join(":") === this.tripKey.split(":").slice(0, 4).join(":")) return;
   var main = D.style === "spectacular" ? "spectacular" : "cine", alt = main === "spectacular" ? "cine" : "spectacular";
   var gwUi = fvGwarpUi();      // (21-nov, N-galaxias-warp) un solo boton VIAJAR: el modo lo da el destino (fvTravelKind); sin «otro modo»
   var a = fvRouteTrip(P, sel, main), b = gwUi ? null : fvRouteTrip(P, sel, alt), here = false;
   if (fvSelSameArrival(P.scene, P.arrivedAt, sel)) { try { here = fvLen(fvSub(fvSelPos(P, sel), P.cam.pos)) < 1.6 * fvArriveDist(P, sel); } catch (e) { here = false; } }
   D.ui.trip = { d: a ? a.d : 0, sMain: a && a.ok ? a.s : 0, sAlt: b && b.ok ? b.s : 0, main: main, alt: alt, okMain: !!(a && a.ok), okAlt: !!(b && b.ok), here: here };
   this.tripKey = key; this.tripAt = P.t;
};
// ---- las miniaturas: un fotograma del pintor por camara, al refrescar (una por tic como mucho), nunca en onPaint ----
// el tamaño de la miniatura: 46 unidades de ancho como mucho y el alto de la fila menos un margen, con el aspecto de la pantalla
FVRoute.prototype.thumbSize = function() {
   var c = this.D.cockpit, kc = c.k, r = c.listIn, rh = (r[3] - r[1] - 26 * kc) / FV_ROUTE.VIS, a = this.D.VW / this.D.VH;
   var h = Math.min(46 * kc / a, rh - 6 * kc), w = h * a;
   return [Math.max(12, Math.round(w)), Math.max(8, Math.round(h))];
};
FVRoute.prototype.thumbSig = function(c) { var ts = this.thumbSize(); return ts[0] + "x" + ts[1] + "|" + c.pos.concat(c.look).map(function(v) { return v.toPrecision(7); }).join(",") + "|" + c.fov.toFixed(5); };
FVRoute.prototype.thumbOf = function(c) { var s = this.thumbSig(c); return Object.prototype.hasOwnProperty.call(this.thumbs, s) ? this.thumbs[s] : null; };
FVRoute.prototype.makeThumb = function(c) {
   // a tamaño de fotograma y reducida (el pintor dibuja las estrellas en pixeles absolutos: en 35 × 26 salian blancas)
   var D = this.D, P = D.P, ts = this.thumbSize();
   if (!this.full || this.full.width !== D.VW || this.full.height !== D.VH) this.full = new Bitmap(D.VW, D.VH, BitmapFormat.RGB32);
   var Pf = { scene: P.scene, t: P.t, cam: { pos: c.pos.slice(), look: c.look.slice(), fov: c.fov }, homeFov: P.homeFov, VW: P.VW, VH: P.VH, warp: 0, flash: 0, trail: 0, flight: null, sel: null, arrivedAt: null, mode: "free", vel: [0, 0, 0] };
   D.painter.render(this.full, Pf, { hud: false, frame: false, vignette: true });
   return this.full.scaledTo(ts[0], ts[1]);
};
FVRoute.prototype.thumbStep = function() {
   var n = this.cams.length, end = Math.min(n, this.top + FV_ROUTE.VIS);
   for (var k = this.top; k < end; ++k) {
      var c = this.cams[k], s = this.thumbSig(c);
      if (Object.prototype.hasOwnProperty.call(this.thumbs, s)) continue;
      var b = null; try { b = this.makeThumb(c); } catch (e) { b = null; fvLog("route: thumbnail " + (k + 1) + " failed: " + e); }
      this.thumbs[s] = b; this.thumbOrder.push(s);
      while (this.thumbOrder.length > FV_ROUTE.MAX + 6) { var old = this.thumbOrder.shift(); delete this.thumbs[old]; }
      return true;                                   // una por tic
   }
   return false;
};
FVRoute.prototype.freeThumbs = function() { this.thumbs = {}; this.thumbOrder = []; };
FVRoute.prototype.freeThumbOf = function(c) { var s = this.thumbSig(c); delete this.thumbs[s]; };
FVRoute.prototype.freeThumbsUnused = function() {
   var keep = {}, i; for (i = 0; i < this.cams.length; ++i) keep[this.thumbSig(this.cams[i])] = true;
   for (var s in this.thumbs) if (!keep[s]) delete this.thumbs[s];
   this.thumbOrder = this.thumbOrder.filter(function(s) { return !!keep[s]; });
};
// ---- (c) LA LISTA EN EL HUECO DE MIRABILIA ----
FVRoute.prototype.clamp = function() { this.top = Math.max(0, Math.min(Math.max(0, this.cams.length - FV_ROUTE.VIS), this.top)); };
FVRoute.prototype.reveal = function(i) { if (i < this.top) this.top = i; else if (i >= this.top + FV_ROUTE.VIS) this.top = i - FV_ROUTE.VIS + 1; this.clamp(); };
FVRoute.prototype.listGeom = function() {
   var c = this.D.cockpit, k = c.k, r = c.listIn, M = { r: r, k: k, hd: 15 * k, foot: 11 * k };
   M.rh = (r[3] - r[1] - M.hd - M.foot) / FV_ROUTE.VIS;
   var ts = this.thumbSize(); M.tw = ts[0]; M.th = ts[1];
   M.numW = 11 * k; M.tx = r[0] + 2 * k + M.numW; M.textX = M.tx + M.tw + 4 * k; M.bs = 12 * k; M.bg = 1.6 * k;
   M.btnX0 = r[2] - 3 * k - (5 * M.bs + 4 * M.bg);
   M.fH = cpFont("display", Math.max(6.5, 7.6 * k), false, false, Math.round(1.5 * k)); M.fN = cpFont("display", Math.max(7, 8.8 * k)); M.fS = cpFont("text", Math.max(6.5, 7.2 * k), false, true);
   var clr = this.clearAsk ? fvTx("rt.sure") : fvTx("rt.clear"), cw = M.fS.width(clr) + 8 * k;
   M.clrTxt = clr; M.clr = [r[2] - cw - 2 * k, r[1] + 1 * k, r[2] - 2 * k, r[1] + M.hd - 1 * k];
   var n = this.cams.length, above = Math.max(0, Math.min(n, this.top)), below = Math.max(0, n - this.top - FV_ROUTE.VIS);
   M.footY0 = r[1] + M.hd + FV_ROUTE.VIS * M.rh; M.above = above; M.below = below;
   // (el triangulo se DIBUJA: «▴ ▾» no estan en la fuente de la cabina y salian como «r»)
   M.upTxt = above > 0 ? fvTx("rt.above", { n: above }) : ""; M.downTxt = below > 0 ? fvTx("rt.more", { n: below }) : "";
   var cx = (r[0] + r[2]) / 2, pw = 8.5 * k;                          // 5 de margen + el triangulo
   M.up = above > 0 ? [cx - 3 * k - M.fS.width(M.upTxt) - 2 * pw, M.footY0 + 1 * k, cx - 3 * k, r[3] - 0.5 * k] : null;
   M.down = below > 0 ? [cx + 3 * k, M.footY0 + 1 * k, cx + 3 * k + M.fS.width(M.downTxt) + 2 * pw, r[3] - 0.5 * k] : null;
   if (M.up && !M.down) { var s1 = (M.up[2] - M.up[0]) / 2 + 3 * k; M.up[0] += s1; M.up[2] += s1; }
   if (M.down && !M.up) { var s2 = (M.down[2] - M.down[0]) / 2 + 3 * k; M.down[0] -= s2; M.down[2] -= s2; }
   return M;
};
FVRoute.prototype.btnRect = function(M, row, bi) { var y0 = M.r[1] + M.hd + row * M.rh + 0.60 * M.rh - M.bs / 2, x0 = M.btnX0 + bi * (M.bs + M.bg); return [x0, y0, x0 + M.bs, y0 + M.bs]; };
FVRoute.prototype.holdRect = function(M, row, k) { var t = this.holdText(k), y0 = M.r[1] + M.hd + row * M.rh + 0.60 * M.rh - M.bs / 2; return [M.textX, y0, M.textX + M.fS.width(t) + 7 * M.k, y0 + M.bs, t]; };
// (nD2) los chips de la animacion de llegada, en la linea del nombre a la derecha: [icono del tipo] [duracion] (la duracion solo si hay animacion)
// -> { k: [x0, y0, x1, y1], d: [x0, y0, x1, y1, texto] | null }
FVRoute.prototype.animRects = function(M, row, k) {
   var an = fvRouteAnimOf(this.cams[k]), y0 = M.r[1] + M.hd + row * M.rh + 0.07 * M.rh, y1 = y0 + M.bs, x1 = M.r[2] - 3 * M.k, d = null;
   if (an) { var t = fvTx("rt.hold", { s: an.s }), w = M.fS.width(t) + 6 * M.k; d = [x1 - w, y0, x1, y1, t]; x1 = d[0] - 1.5 * M.k; }
   return { k: [x1 - M.bs * 1.15, y0, x1, y1], d: d };
};
FVRoute.prototype.holdText = function(k) { var h = this.cams[k].holdS; return h > 0 ? fvTx("rt.hold", { s: h }) : fvTx("rt.noHold"); };
var FV_RT_BTNS = ["up", "down", "replace", "rename", "delete"];
// que hay en (x, y) de la franja (solo con el mapa grande abierto) -> id | null
FVRoute.prototype.stripHit = function(x, y) {
   if (!this.big) return null;
   var c = this.D.cockpit, slot = (this.big === "map3d") ? c.map3d : c.map2d;
   if (x >= slot[0] && x <= slot[2] && y >= slot[1] && y <= slot[3]) return "rt:ship";
   var L = c.list; if (x < L[0] || x > L[2] || y < L[1] || y > L[3]) return null;
   var M = this.listGeom(), r = M.r, n = this.cams.length, i;
   if (y < r[1] + M.hd) return (n > 0 && x >= M.clr[0] && x <= M.clr[2]) ? "rt:clear" : "rt:list";
   if (y >= M.footY0) {
      if (M.down && x >= M.down[0] && x <= M.down[2]) return "rt:more";
      if (M.up && x >= M.up[0] && x <= M.up[2]) return "rt:above";
      return "rt:list";
   }
   var row = Math.floor((y - r[1] - M.hd) / M.rh), k = this.top + row;
   if (row < 0 || row >= FV_ROUTE.VIS || k >= n) return "rt:list";
   for (i = 0; i < FV_RT_BTNS.length; ++i) { var q = this.btnRect(M, row, i); if (x >= q[0] - 0.5 * M.bg && x <= q[2] + 0.5 * M.bg && y >= q[1] - 2 * M.k && y <= q[3] + 2 * M.k) return "rt:btn:" + k + ":" + FV_RT_BTNS[i]; }
   var hq = this.holdRect(M, row, k); if (x >= hq[0] && x <= hq[2] && y >= hq[1] && y <= hq[3]) return "rt:btn:" + k + ":hold";
   var ar = this.animRects(M, row, k);                                  // (nD2) la animacion de llegada
   if (x >= ar.k[0] && x <= ar.k[2] && y >= ar.k[1] - 1 * M.k && y <= ar.k[3] + 1 * M.k) return "rt:btn:" + k + ":anim";
   if (ar.d && x >= ar.d[0] && x <= ar.d[2] && y >= ar.d[1] - 1 * M.k && y <= ar.d[3] + 1 * M.k) return "rt:btn:" + k + ":adur";
   if (x >= M.textX && y < r[1] + M.hd + row * M.rh + 0.45 * M.rh) return "rt:name:" + k;
   return "rt:row:" + k;
};
FVRoute.prototype.btnOff = function(b, k) {
   if (b === "up") return k <= 0;
   if (b === "down") return k >= this.cams.length - 1;
   return false;
};
// el clic en la franja -> el id de lo pulsado si lo consume la ruta, o null
FVRoute.prototype.stripClick = function(x, y) {
   var h = this.stripHit(x, y); if (!h) return null;
   if (this.renaming >= 0) this.renameEnd(true);
   if (h !== "rt:clear" && this.clearAsk) this.clearAsk = false;
   var m;
   if (h === "rt:ship") this.close();
   else if (h === "rt:clear") { if (!this.clearAsk) this.clearAsk = true; else { this.clearAsk = false; this.clearAll(); } }
   else if (h === "rt:more") { this.top += FV_ROUTE.VIS; this.clamp(); }
   else if (h === "rt:above") { this.top -= FV_ROUTE.VIS; this.clamp(); }
   else if ((m = /^rt:btn:(\d+):(\w+)$/.exec(h))) {
      var k = parseInt(m[1], 10), b = m[2];
      if (this.btnOff(b, k)) return h;
      if (b === "up") this.move(k, -1); else if (b === "down") this.move(k, 1); else if (b === "replace") this.replace(k);
      else if (b === "rename") this.renameStart(k); else if (b === "delete") this.remove(k); else if (b === "hold") this.cycleHold(k);
      else if (b === "anim") this.cycleAnim(k); else if (b === "adur") this.cycleAnimDur(k);
   }
   else if ((m = /^rt:(row|name):(\d+)$/.exec(h))) { var kk = parseInt(m[2], 10); this.sel = kk; this.goTo(kk); }
   try { this.D.renderNow(); this.D.view.repaint(); this.D.strip.repaint(); } catch (e) {}
   return h;
};
FVRoute.prototype.stripDouble = function(x, y) { var h = this.stripHit(x, y), m; if (h && (m = /^rt:name:(\d+)$/.exec(h))) { this.renameStart(parseInt(m[1], 10)); return true; } return !!h; };
FVRoute.prototype.stripWheel = function(x, y, delta) { var h = this.stripHit(x, y); if (!h || h === "rt:ship") return false; this.top += (delta < 0 ? 1 : -1); this.clamp(); this.D.strip.repaint(); return true; };
// el raton sobre la franja: realce, cursor y tooltip de lo de la ruta -> true si lo lleva la ruta
FVRoute.prototype.stripMove = function(x, y) {
   var D = this.D, h = this.stripHit(x, y);
   if (!h) { if (this.hover) { this.hover = null; if (this.clearAsk) this.clearAsk = false; } return false; }
   if (h !== "rt:clear" && this.clearAsk) this.clearAsk = false;          // moverse fuera de «Borrar todo» cancela la confirmacion
   if (h === this.hover) return true;
   this.hover = h; D.stripHover = h; if (D.cockpit) D.cockpit.hover = (h === "rt:ship") ? (this.big === "map3d" ? "map3d" : "map2d") : null;
   var m = /^rt:btn:(\d+):(\w+)$/.exec(h), act = (h !== "rt:list"), tip = "";
   if (m) { act = !this.btnOff(m[2], parseInt(m[1], 10)); tip = fvTipBoth("rt.tip." + m[2]); }
   if (m && m[2] === "anim") { var an0 = fvRouteAnimOf(this.cams[parseInt(m[1], 10)]); tip = "<html>" + fvTx("rt.an." + (an0 ? an0.k : "none")) + "<br><br>" + fvTx("rt.tip.anim") + "</html>"; }
   else if (h === "rt:ship") tip = fvTipBoth("rt.tipShip");
   else if (h === "rt:clear") tip = fvTipBoth("rt.tipClear");
   else if (/^rt:(row|name)/.test(h)) tip = fvTipBoth("rt.tipRow");
   else tip = fvTipBoth("rt.tipList");
   D.strip.cursor = new Cursor(act ? StdCursor_PointingHand : StdCursor_Arrow);
   D.strip.toolTip = tip;
   D.strip.repaint();
   return true;
};
// ir a la camara k (clic en su fila): un recorrido de UNA camara (con el motor o el respaldo), sin parada
FVRoute.prototype.goTo = function(k) {
   var c = this.cams[k]; if (!c) return false;
   var keep = this.cams; this.cams = [{ name: c.name, pos: c.pos, look: c.look, fov: c.fov, holdS: 0, tgt: c.tgt, anim: c.anim || null }];   // (nD2) con su animacion de llegada
   var bigKeep = this.big; this.big = null;
   try { this.fly(0, true); } finally { this.cams = keep; this.big = bigKeep; }
   return true;
};
// ✎: un campo de texto encima del nombre (sin dialogo)
FVRoute.prototype.renameStart = function(k) {
   var D = this.D, self = this; if (!(k >= 0 && k < this.cams.length)) return false;
   this.reveal(k);
   var M = this.listGeom(), row = k - this.top;
   if (!this.edit) {
      var E = this.edit = new Edit(D.strip);
      E.onEditCompleted = function() { self.renameEnd(true); };
      E.onKeyPress = function(key) { if (key === Key_Escape || key === 27) { self.renameEnd(false); return true; } return false; };
   }
   this.renaming = k;
   var y0 = M.r[1] + M.hd + row * M.rh, w = Math.max(40, M.r[2] - M.textX - 3 * M.k), h = Math.round(M.fN.ascent + M.fN.descent + 6);
   try { this.edit.setFixedSize(Math.round(w), h); this.edit.move(Math.round(M.textX), Math.round(y0 + 1 * M.k)); this.edit.text = this.cams[k].name || ""; this.edit.show(); this.edit.bringToFront(); this.edit.setFocus(); try { this.edit.selectAll(); } catch (eS) {} }
   catch (e) { this.renaming = -1; return false; }
   return true;
};
FVRoute.prototype.renameEnd = function(commit) {
   if (this.renaming < 0 || !this.edit) return;
   var k = this.renaming, t = ""; this.renaming = -1;
   try { t = String(this.edit.text); } catch (e) {}
   try { this.edit.hide(); } catch (e2) {}
   if (commit) this.rename(k, t);
   try { this.D.strip.repaint(); this.D.view.setFocus(); } catch (e3) {}
};
// ---- pintar en la franja: la nave en el hueco del mapa grande y la lista en el de MIRABILIA (despues de paintNav) ----
FVRoute.prototype.paintStrip = function(g) {
   var D = this.D, c = D.cockpit, k = c.k;
   if (!this.big) {
      // recorriendo la ruta (con el mapa pequeño): las camaras numeradas tambien en TABULA y PROFUNDITAS pequeñas
      if (this.play && this.play.n > 1 && this.cams.length && D.scene) { this.paintCams(g, c.map2d, k * 0.8, "map2d", D.VW, D.VH, ""); this.paintCams(g, c.map3d, k * 0.8, "map3d", D.VW, D.VH, ""); }
      return;
   }
   var slot = (this.big === "map3d") ? c.map3d : c.map2d, sw = slot[2] - slot[0], sh = slot[3] - slot[1];
   g.fillRect(slot[0], slot[1], slot[2], slot[3], new Brush(0xff07060A));
   if (this.mini) { var x0 = slot[0] + (sw - this.mini.width) / 2, y0 = slot[1] + (sh - this.mini.height) / 2; g.drawBitmap(x0, y0, this.mini); }
   var f = cpFont("display", Math.max(6, 6.2 * k), false, false, Math.round(1.5 * k)), cap = fvTx("rt.ship");
   g.font = f; g.fillRect(slot[0] + 2 * k, slot[3] - 9.5 * k, slot[0] + 6 * k + f.width(cap), slot[3] - 1 * k, new Brush(0xb0110D09)); g.pen = new Pen(FV_CK.gold); g.drawText(slot[0] + 4 * k, slot[3] - 3 * k, cap);
   if (this.hover === "rt:ship") { g.pen = new Pen(0xa0F3D27E, 1.2 * k); g.drawRect(slot[0] - 2 * k, slot[1] - 2 * k, slot[2] + 2 * k, slot[3] + 2 * k); }
   this.paintList(g);
};
FVRoute.prototype.paintList = function(g) {
   var D = this.D, P = D.P, M = this.listGeom(), r = M.r, k = M.k, n = this.cams.length, i, row;
   g.fillRect(r[0], r[1], r[2], r[3], new Brush(FV_RT_COL.bg));
   g.antialiasing = true; g.textAntialiasing = true;
   g.font = M.fH; g.pen = new Pen(FV_CK.gold); var ttl = "ITINERARIUM"; g.drawText(r[0] + 4 * k, r[1] + 11 * k, ttl);
   if (n) { g.font = M.fS; g.pen = new Pen(FV_RT_COL.dim); var info = n + " · " + fvRouteDur(this.estimate(), FV_LANG); var ix = r[0] + 8 * k + M.fH.width(ttl); if (ix + M.fS.width(info) < M.clr[0] - 2 * k) g.drawText(ix, r[1] + 11 * k, info); }
   if (n) { g.font = M.fS; g.pen = new Pen(this.clearAsk ? FV_RT_COL.verm : (this.hover === "rt:clear" ? FV_CK.gold : FV_RT_COL.dim)); g.drawText(M.clr[0] + 4 * k, r[1] + 11 * k, M.clrTxt); }
   g.pen = new Pen(0x60E5B53F, 0.8); g.drawLine(r[0], r[1] + M.hd, r[2], r[1] + M.hd);
   if (!n) {
      g.font = M.fS; g.pen = new Pen(FV_RT_COL.dim);
      var ws = fvWrap(M.fS, fvTx(this.big === "map2d" ? "rt.empty2" : "rt.empty3"), r[2] - r[0] - 10 * k);
      for (i = 0; i < ws.length && i < 6; ++i) g.drawText(r[0] + 5 * k, r[1] + M.hd + 11 * k + i * 10 * k, ws[i]);
      return;
   }
   for (row = 0; row < FV_ROUTE.VIS; ++row) {
      var kk = this.top + row; if (kk >= n) break;
      var c = this.cams[kk], y0 = r[1] + M.hd + row * M.rh, hov = this.hover && (this.hover === "rt:row:" + kk || this.hover === "rt:name:" + kk || this.hover.indexOf("rt:btn:" + kk + ":") === 0);
      var here = P && fvRouteSamePose(P, c), playing = !!this.play && this.playAt() === kk;
      if (hov) g.fillRect(r[0] + 1, y0, r[2] - 1, y0 + M.rh, new Brush(0x30E5B53F));
      if (here || playing) { g.fillRect(r[0] + 1, y0, r[2] - 1, y0 + M.rh, new Brush(0x1AE5B53F)); g.fillRect(r[0] + 1, y0, r[0] + 1 + 2 * k, y0 + M.rh, new Brush(FV_CK.gold)); }
      if (kk === this.sel) { g.pen = new Pen(0xc0F3D27E, Math.max(0.8, k)); g.drawRect(r[0] + 1.5, y0 + 0.5, r[2] - 1.5, y0 + M.rh - 0.5); }
      if (row > 0) { g.pen = new Pen(0x803D2E1F, 0.8); g.drawLine(r[0] + 3 * k, y0, r[2] - 3 * k, y0); }
      // el numero
      g.font = M.fN; g.pen = new Pen(here ? FV_CK.gold : FV_RT_COL.dim); var num = String(kk + 1); g.drawText(r[0] + 2 * k + (M.numW - M.fN.width(num)) / 2, y0 + M.rh / 2 + 3 * k, num);
      // la miniatura (o «…» mientras se hace)
      var ty = y0 + (M.rh - M.th) / 2, th = this.thumbOf(c);
      if (th) g.drawBitmap(M.tx, ty, th);
      else { g.fillRect(M.tx, ty, M.tx + M.tw, ty + M.th, new Brush(0xff2A2016)); g.font = M.fS; g.pen = new Pen(FV_RT_COL.dim); g.drawText(M.tx + (M.tw - M.fS.width("…")) / 2, ty + M.th / 2 + 3 * k, "…"); }
      g.pen = new Pen(0xff5E4214, 0.8); g.drawRect(M.tx, ty, M.tx + M.tw, ty + M.th);
      // el nombre (renombrandose: lo tapa el campo de texto)
      var ar = this.animRects(M, row, kk), anK = fvRouteAnimOf(c);
      if (this.renaming !== kk) { g.font = M.fN; g.pen = new Pen(FV_RT_COL.text); g.drawText(M.textX, y0 + 0.38 * M.rh, cpElide(M.fN, this.name(kk), ar.k[0] - M.textX - 2 * k)); }
      // (nD2) la animacion de llegada: el chip del tipo (icono) y el de la duracion
      var hotA = (this.hover === "rt:btn:" + kk + ":anim"), hotD = (this.hover === "rt:btn:" + kk + ":adur"), aq = ar.k;
      g.fillRect(aq[0], aq[1], aq[2], aq[3], new Brush(anK ? 0x24E5B53F : 0x00000000)); g.pen = new Pen(hotA ? FV_CK.gold : (anK ? 0xb0E5B53F : 0x90A3957B), 0.8); g.drawRect(aq[0] + 0.5, aq[1] + 0.5, aq[2] - 0.5, aq[3] - 0.5);
      fvRtAnimGlyph(g, anK ? anK.k : "none", (aq[0] + aq[2]) / 2, (aq[1] + aq[3]) / 2, 0.82 * (aq[3] - aq[1]), hotA || anK ? FV_CK.gold : FV_RT_COL.dim);
      if (ar.d) { var dq = ar.d; g.fillRect(dq[0], dq[1], dq[2], dq[3], new Brush(0x24E5B53F)); g.pen = new Pen(hotD ? FV_CK.gold : 0xb0E5B53F, 0.8); g.drawRect(dq[0] + 0.5, dq[1] + 0.5, dq[2] - 0.5, dq[3] - 0.5); g.font = M.fS; g.pen = new Pen(FV_CK.gold); g.drawText(dq[0] + 3 * k, dq[3] - 3 * k, dq[4]); }
      // el chip de la parada y los cinco botones
      var hq = this.holdRect(M, row, kk), hotH = (this.hover === "rt:btn:" + kk + ":hold"), onH = c.holdS > 0;
      g.fillRect(hq[0], hq[1], hq[2], hq[3], new Brush(onH ? 0x24E5B53F : 0x00000000)); g.pen = new Pen(hotH ? FV_CK.gold : (onH ? 0xb0E5B53F : 0x90A3957B), 0.8); g.drawRect(hq[0] + 0.5, hq[1] + 0.5, hq[2] - 0.5, hq[3] - 0.5);
      g.font = M.fS; g.pen = new Pen(hotH || onH ? FV_CK.gold : FV_RT_COL.dim); g.drawText(hq[0] + 3.5 * k, hq[3] - 3 * k, hq[4]);
      for (i = 0; i < FV_RT_BTNS.length; ++i) {
         var b = FV_RT_BTNS[i], q = this.btnRect(M, row, i), off = this.btnOff(b, kk), hot = !off && this.hover === "rt:btn:" + kk + ":" + b;
         if (hot) { g.fillRect(q[0], q[1], q[2], q[3], new Brush(0xff3A2A10)); g.pen = new Pen(b === "delete" ? FV_RT_COL.verm : FV_CK.gold, 0.8); g.drawRect(q[0] + 0.5, q[1] + 0.5, q[2] - 0.5, q[3] - 0.5); }
         fvRtGlyph(g, b, (q[0] + q[2]) / 2, (q[1] + q[3]) / 2, 0.78 * M.bs, off ? FV_RT_COL.off : (hot ? (b === "delete" ? FV_RT_COL.verm : FV_CK.gold) : 0xffD0C1A5));
      }
   }
   // el fundido (mas filas debajo / encima) y el pie «▴ n arriba · ▾ n mas»
   var NST = 6, fh = 7 * k, st;
   if (M.below > 0) for (st = 0; st < NST; ++st) { var fy0 = M.footY0 - fh + fh * st / NST; g.fillRect(r[0] + 1, fy0, r[2] - 1, fy0 + fh / NST + 0.5, new Brush((Math.round(0xd8 * (st + 1) / NST) << 24 | 0x1B140E) >>> 0)); }
   if (M.above > 0) for (st = 0; st < NST; ++st) { var gy0 = r[1] + M.hd + 1 + fh * st / NST; g.fillRect(r[0] + 1, gy0, r[2] - 1, gy0 + fh / NST + 0.5, new Brush((Math.round(0x90 * (NST - st) / NST) << 24 | 0x1B140E) >>> 0)); }
   g.pen = new Pen(0x603D2E1F, 0.8); g.drawLine(r[0] + 3 * k, M.footY0, r[2] - 3 * k, M.footY0);
   var pills = [[M.up, M.upTxt, "rt:above"], [M.down, M.downTxt, "rt:more"]];
   for (i = 0; i < 2; ++i) {
      var pq = pills[i][0]; if (!pq) continue; var hp = this.hover === pills[i][2];
      g.fillRect(pq[0], pq[1], pq[2], pq[3], new Brush(hp ? 0xff3A2A10 : 0x1AE5B53F)); g.pen = new Pen(hp ? FV_CK.gold : 0x99E5B53F, 0.8); g.drawRect(pq[0] + 0.5, pq[1] + 0.5, pq[2] - 0.5, pq[3] - 0.5);
      fvRtGlyph(g, i === 0 ? "up" : "down", pq[0] + 6 * k, (pq[1] + pq[3]) / 2, 5 * k, FV_CK.gold);
      g.font = M.fS; g.pen = new Pen(FV_CK.gold); g.drawText(pq[0] + 10 * k, pq[3] - 2.5 * k, pills[i][1]);
   }
};

// ---------------------------------------------------------------------------
// TEXTOS (EN / ES). Tambien se rehacen los tooltips de TABULA y PROFUNDITAS: ahora un clic los pone en grande (antes: clic = mirar alli,
// doble clic = ir; PROFUNDITAS era solo un indicador)
// ---------------------------------------------------------------------------
(function() {
   var add = {
      en: {
         "tipck.map2d": "TABULA: your photo. Gold outline = what the camera sees · large arrow = your ship · faint trail = where you have been · red target = where you are going. CLICK = open it large in place of the ship view, to place the cameras of a route (the ship goes to this little window; click it or press Esc to come back).",
         "tipck.map3d": "PROFUNDITAS: the field in 3D, depth in log scale — the Earth, the stars at their distance, the nebula slab, your ship and its target. CLICK = open it large in place of the ship view, to place cameras and adjust their depth (click the little ship window or press Esc to come back).",
         "rt.ship": "NAVIS", "rt.tipShip": "The ship, live: click to bring it back to the big screen (or press Esc).",
         "rt.add": "CURRENT VIEW", "rt.play": "FLY THE ROUTE", "rt.stop": "STOP", "rt.suggest": "SUGGEST",
         "rt.hint2": "Click: a camera looking there · drag: its distance · drag a camera: move it", "rt.hint3": "Drag: turn the 3D · wheel: zoom · click a star or object: its camera · drag a camera: its depth · round handle: tilt the planes",
         "rt.tipBig2": "TABULA, large: click a point of the photo = a camera looking there (if there is a star or object next to the click, it takes it and its distance; otherwise the nebula). Drag from the point = how far from it the camera stays. Drag a numbered camera = move it over the photo. Each camera shows its cone; the gold curve is the route. «＋ CURRENT VIEW» saves the ship's camera; «▶ FLY THE ROUTE» flies through them in order (REC records it). Esc or a click on the little ship window: back to the ship.",
         "rt.tipBig3": "PROFUNDITAS, large. LEFT button: drag on the map (not on a camera) = turn the 3D view around the field (sideways = around, up/down = from above or below) · wheel = zoom · double-click on empty space = the starting view. Click without moving (less than 4 px) on a star or object = a camera for it. Drag a numbered camera = its depth: along the distance axis, farther from or nearer to the Earth (it keeps its direction). The round handle over the nebula slab tilts the planes of the nebula (drag; double-click on it = untilted). The gold curve is the route. «▶ FLY THE ROUTE» flies through the cameras in order. Esc or a click on the little ship window: back to the ship.",
         "rt.tipTilt": "Tilt the planes of the nebula: drag up / down = around the horizontal axis, left / right = around the vertical axis (up to 60°). Double-click = untilted. It is saved with the route of this photo. The map shows it now; the flight will show it when the painter reads it (pending).",
         "rt.tiltLab": "TILT {x}° · {y}°",
         "rt.tip.anim": "Arrival animation: what the ship does when it reaches this camera, before its stop. Click = next one: none · orbit · dolly in · pull back · pan · roll · parallax. It plays when flying the route, when you click the row, and REC records it.",
         "rt.tip.adur": "How long the arrival animation lasts (click to change: 4, 6, 8, 12, 16 s).",
         "rt.an.none": "No animation: the ship arrives and stays still (its stop).",
         "rt.an.orbit": "Orbit: the ship circles 90° around what it is looking at, keeping its distance (the background turns by parallax).",
         "rt.an.dolly": "Dolly in: the ship slowly moves in towards the target, down to half the distance.",
         "rt.an.pull": "Pull back: the ship slowly moves away from the target, out to 2.5 times the distance.",
         "rt.an.pan": "Pan: the ship stays put and the gaze sweeps 20° to one side, to the other and back.",
         "rt.an.roll": "Roll: a gentle tilt of up to 12° around the line of sight and back. (The painter does not apply it yet: pending.)",
         "rt.an.parallax": "Parallax: the ship slides sideways and back with its gaze fixed: the near stars move more than the far ones, so you see the depth.",
         "rt.dragLab": "{t} · camera {d} away", "rt.cam": "Camera {n}", "rt.hold": "{s} s", "rt.noHold": "+ stop",
         "rt.clear": "CLEAR ALL", "rt.sure": "SURE?", "rt.more": "{n} more", "rt.above": "{n} above",
         "rt.empty2": "No cameras yet. Click the large photo: a camera looking there. Drag: its distance. ＋ CURRENT VIEW saves the ship's.",
         "rt.empty3": "No cameras yet. Click a star or object in the large map: a camera for it (drag on the map: turn the 3D). ＋ CURRENT VIEW saves the ship's.",
         "rt.tip.up": "Move up", "rt.tip.down": "Move down", "rt.tip.replace": "Replace with the ship's camera now", "rt.tip.rename": "Rename (also double-click the name)", "rt.tip.delete": "Delete this camera",
         "rt.tip.hold": "Stop: how long the ship stays on this camera (click to change: none, 2, 3, 5, 8 s)",
         "rt.tipClear": "Delete ALL the cameras of this photo: a second click confirms (moving away cancels).", "rt.tipRow": "Click = the ship goes to this camera.",
         "rt.tipList": "ITINERARIUM: the cameras of the route for this photo, in order (they are remembered with the photo). Wheel = scroll.",
         "rt.flying": "ROUTE · CAMERA {i} / {n}", "rt.done": "ROUTE COMPLETE", "rt.full": "AT MOST {n} CAMERAS", "rt.noSuggest": "NOTHING TO SUGGEST IN THIS FIELD",
         "card.go": "TRAVEL", "card.cine": "CINEMA", "card.warp": "WARP", "card.from": "{d} from the ship", "card.here": "YOU ARE HERE",
         "card.tipGo": "Travel there now", "card.tipAlt": "Travel there in the other mode"
      },
      es: {
         "tipck.map2d": "TABULA: tu foto. Contorno dorado = lo que ve la cámara · flecha grande = tu nave · estela tenue = por dónde has ido · mira roja = adónde vas. CLIC = abrirla en grande en lugar de la vista de la nave, para poner las cámaras de una ruta (la nave pasa a esta ventanita; clic en ella o Esc para volver).",
         "tipck.map3d": "PROFUNDITAS: el campo en 3D, profundidad en escala logarítmica — la Tierra, las estrellas a su distancia, la losa de la nebulosa, tu nave y su destino. CLIC = abrirla en grande en lugar de la vista de la nave, para poner cámaras y ajustar su profundidad (clic en la ventanita de la nave o Esc para volver).",
         "rt.ship": "NAVIS", "rt.tipShip": "La nave, en vivo: clic para devolverla a la pantalla grande (o Esc).",
         "rt.add": "VISTA ACTUAL", "rt.play": "RECORRER LA RUTA", "rt.stop": "PARAR", "rt.suggest": "PROPONER",
         "rt.hint2": "Clic: cámara mirando ahí · arrastrar: su distancia · arrastrar una cámara: moverla", "rt.hint3": "Arrastrar: girar el 3D · rueda: zoom · clic en estrella u objeto: su cámara · arrastrar una cámara: su profundidad · asa redonda: inclinar los planos",
         "rt.tipBig2": "TABULA en grande: clic en un punto de la foto = una cámara mirando ahí (si hay una estrella u objeto junto al clic, lo toma con su distancia; si no, la nebulosa). Arrastrar desde el punto = a qué distancia de él se queda la cámara. Arrastrar una cámara numerada = moverla por la foto. Cada cámara lleva su cono; la curva dorada es la ruta. «＋ VISTA ACTUAL» guarda la cámara de la nave; «▶ RECORRER LA RUTA» las recorre en orden (REC lo graba). Esc o clic en la ventanita de la nave: volver a la nave.",
         "rt.tipBig3": "PROFUNDITAS en grande. Botón IZQUIERDO: arrastrar sobre el mapa (no sobre una cámara) = girar la vista 3D alrededor del campo (de lado = rodear, arriba/abajo = verlo desde encima o desde debajo) · rueda = zoom · doble clic en el vacío = la vista de partida. Clic sin mover (menos de 4 px) en una estrella u objeto = una cámara para él. Arrastrar una cámara numerada = su profundidad: a lo largo del eje de distancias, más lejos o más cerca de la Tierra (conserva su dirección). El asa redonda sobre la losa de la nebulosa inclina sus planos (arrastrar; doble clic en ella = sin inclinar). La curva dorada es la ruta. «▶ RECORRER LA RUTA» recorre las cámaras en orden. Esc o clic en la ventanita de la nave: volver a la nave.",
         "rt.tipTilt": "Inclinar los planos de la nebulosa: arrastrar arriba / abajo = alrededor del eje horizontal, izquierda / derecha = alrededor del vertical (hasta 60°). Doble clic = sin inclinar. Se guarda con la ruta de esta foto. El mapa ya lo enseña; el vuelo lo enseñará cuando el pintor lo lea (pendiente).",
         "rt.tiltLab": "INCLINACIÓN {x}° · {y}°",
         "rt.tip.anim": "Animación de llegada: lo que hace la nave al llegar a esta cámara, antes de su parada. Clic = la siguiente: ninguna · órbita · acercamiento · alejamiento · barrido · balanceo · paralaje. Se ejecuta al recorrer la ruta, al hacer clic en la fila, y REC la graba.",
         "rt.tip.adur": "Cuánto dura la animación de llegada (clic para cambiar: 4, 6, 8, 12, 16 s).",
         "rt.an.none": "Sin animación: la nave llega y se queda quieta (su parada).",
         "rt.an.orbit": "Órbita: la nave da un cuarto de vuelta (90°) alrededor de lo que mira, sin cambiar la distancia (el fondo gira por paralaje).",
         "rt.an.dolly": "Acercamiento: la nave se acerca despacio al objetivo, hasta la mitad de la distancia.",
         "rt.an.pull": "Alejamiento: la nave se aleja despacio del objetivo, hasta 2,5 veces la distancia.",
         "rt.an.pan": "Barrido: la nave no se mueve y la mirada recorre 20° a un lado, al otro y vuelve.",
         "rt.an.roll": "Balanceo: un giro suave de hasta 12° alrededor de la línea de mirada y vuelta. (El pintor aún no lo aplica: pendiente.)",
         "rt.an.parallax": "Paralaje: la nave se desliza de lado y vuelve con la mirada fija: las estrellas cercanas se mueven más que las lejanas y se ve la profundidad.",
         "rt.dragLab": "{t} · cámara a {d}", "rt.cam": "Cámara {n}", "rt.hold": "{s} s", "rt.noHold": "+ parada",
         "rt.clear": "BORRAR TODO", "rt.sure": "¿SEGURO?", "rt.more": "{n} más", "rt.above": "{n} arriba",
         "rt.empty2": "Aún no hay cámaras. Clic en la foto grande: una cámara mirando ahí. Arrastrar: su distancia. ＋ VISTA ACTUAL guarda la de la nave.",
         "rt.empty3": "Aún no hay cámaras. Clic en una estrella u objeto del mapa grande: su cámara (arrastrar en el mapa: girar el 3D). ＋ VISTA ACTUAL guarda la de la nave.",
         "rt.tip.up": "Subir", "rt.tip.down": "Bajar", "rt.tip.replace": "Sustituir por la cámara de la nave ahora", "rt.tip.rename": "Renombrar (también doble clic en el nombre)", "rt.tip.delete": "Borrar esta cámara",
         "rt.tip.hold": "Parada: cuánto se queda la nave en esta cámara (clic para cambiar: sin parada, 2, 3, 5, 8 s)",
         "rt.tipClear": "Borra TODAS las cámaras de esta foto: un segundo clic lo confirma (moverse fuera lo cancela).", "rt.tipRow": "Clic = la nave va a esta cámara.",
         "rt.tipList": "ITINERARIUM: las cámaras de la ruta de esta foto, en orden (se recuerdan con la foto). Rueda = desplazar.",
         "rt.flying": "RUTA · CÁMARA {i} / {n}", "rt.done": "RUTA COMPLETA", "rt.full": "COMO MUCHO {n} CÁMARAS", "rt.noSuggest": "NADA QUE PROPONER EN ESTE CAMPO",
         "card.go": "VIAJAR", "card.cine": "CINE", "card.warp": "WARP", "card.from": "a {d} de la nave", "card.here": "ESTÁS AQUÍ",
         "card.tipGo": "Viajar allí ahora", "card.tipAlt": "Viajar allí en el otro modo"
      }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
