// ============================================================================
// FieldVoyager/src/ui/fv_card_sci.js — LOS DATOS DE LA FICHA QUE NO TRAE LA ESCENA: ESPECTRO XP (I12) Y COMPOSICION (I13), 4-nov-2026
// ----------------------------------------------------------------------------
// Lo de PixInsight (disco y red). La ciencia pura esta en src/science/fv_sci_xp.js y fv_sci_chem.js.
//   fvCsciRequest(scene, i)      la ficha la PIDE al abrirse (barato: solo apunta y arranca un Timer de un disparo). NUNCA se trae nada dentro
//                                del pintado: el trabajo lo hace el Timer, fuera de onPaint y del fotograma (la red bombea eventos con
//                                CSH_NET_PUMP, asi la ficha sigue animandose mientras «consulta Gaia…»).
//   fvCsciFetch(scene, i, o)     lo hace YA (el Timer y las pruebas): deja scene.stars.meta[i].sci = { st, xp, xpWhy, chem, chemWhy, id, ms }
//   fvCsciField(scene, o)        PASO ADICIONAL para el paquete web: el XP de todas las del campo de una vez (base local DR3/SP) y la
//                                composicion de las brillantes por lotes de identificadores. Lo llama quien exporta (ver HANDOFF de I12).
//   fvCsciVer(scene, i)          un numero que cambia cuando llegan datos (la ficha rehace su texto)
//   fvCsciPrefetch(scene, sel)   (5-nov, Nino: «justo al empezar el viaje ve pidiendo toda la informacion de la estrella») lo mismo que
//                                pide la ficha, pero al ARRANCAR el viaje (fv_dialog.js, travel): al llegar ya esta. FV_CSCI_PREFETCH.
// (METALICIDAD, 5-nov, con FV_METAL.ON de src/science/fv_sci_metal.js) la fila de Gaia trae tambien el [M/H] y la Teff de GSP-Phot; la
// ficha tiene sci.metal (fvsMetalBuild) en cuanto llega esa fila (GSP-Spec o GSP-Phot, segundos) y otra vez al acabar los surveys.
//
// LA RED (reglas CPD: solo https, plazos, sin reintentos ciegos; la ayuda lo declara):
//   1. Gaia DR3 por un cono de 3″ en la posicion de la estrella: identificador, has_xp_sampled, GSP-Spec y FLAME. VizieR (CDS) I/355/gaiadr3 +
//      I/355/paramp; si calla, archivo de Gaia de la ESA y de ARI (Heidelberg) con las mismas columnas de gaia_source + astrophysical_parameters.
//      cshNfFetchHedged (CabraShared): plazo FV_CSCI.TIMEOUT_S, cesion a los FV_CSCI.HEDGE_S, cache sellada «last».
//   2. El espectro XP: la base LOCAL DR3/SP del proceso Gaia (la de SPCC) si esta instalada (sin red); si no, el servicio de datos de la ESA
//      (datalink XP_SAMPLED) y ARI (gaiadr3.xp_sampled_mean_spectrum) por el identificador. Solo si Gaia dice que lo publico.
//   3. APOGEE DR17, GALAH DR4 y LAMOST DR11 en VizieR por el identificador de Gaia (cpSfHttpText: CDS y su espejo IDIA por https).
// PROCEDENCIA: la busqueda local, las URL y la lectura del XP son las de CabraStars/lib/cs_engine.js:24-30, 261-294, 302-362, 364-417
// (csXpLocal, csXpFieldLocal, csXpParseEsa, csXpParseAri, csXpServers), copiadas y adaptadas a la escena; la consulta de la ficha de Gaia
// sigue la de cs_engine.js:170-224 (csStarDetailsAdql/AdqlGaia, CS_DET_COLS, csFetchStarDetails con cshNfFetchHedged). CabraStars no se toca.
// ES5.
// ============================================================================

var FV_CSCI = {
   TIMEOUT_S: 15, HEDGE_S: 6, CONE_ARCSEC: 3.0, DG_MAX: 0.4, SURVEY_TIMEOUT_S: 12,
   ESA_TAP: "https://gea.esac.esa.int/tap-server/tap/sync", ARI_TAP: "https://gaia.ari.uni-heidelberg.de/tap/sync",
   ESA_XP: "https://gea.esac.esa.int/data-server/data?RETRIEVAL_TYPE=XP_SAMPLED&FORMAT=csv&ID=Gaia+DR3+",
   FIELD_XP_MAX: 400,       // el paquete web lleva el XP de las 400 mas brillantes del campo como mucho (~0,5 kB cada una: ~200 kB)
   FIELD_CHEM_GMAX: 13.0,   // y la composicion de las de G < 13 (las que tienen espectroscopia casi siempre; un lote de identificadores)
   FIELD_ID_CHUNK: 200
};
var FV_CSCI_ONLINE = true;        // false = sin red (las pruebas «sin red» y el control)
var FV_CARD_SCI_AUTO = true;      // la ficha pide sus datos al abrirse (false: solo fvCsciFetch a mano; las pruebas lo apagan)
var FV_CSCI_HOOK = null;          // pruebas: function(kind, url) -> { ok, text } | undefined (undefined = la red de verdad)
var FV_CSCI_LOG = [];             // lo que se pidio (para el registro de las pruebas)
var FV_CSCI_Q = { busy: false, queue: [], timer: null, ver: 0 };
var FV_CSCI_PREFETCH = true;      // false = la ficha pide sus datos al abrirse al llegar, como antes del 5-nov (el ROJO de fv_metal_test P)
function fvCsciMetalOn() { return typeof FV_METAL !== "undefined" && FV_METAL.ON === true && typeof fvsMetalBuild === "function"; }

function fvCsciLog(s) { FV_CSCI_LOG.push(s); if (FV_CSCI_LOG.length > 200) FV_CSCI_LOG.shift(); try { if (typeof fvLog === "function") fvLog("card-sci " + s); } catch (e) {} }
function fvCsciMeta(scene, i) { return (scene && scene.stars && scene.stars.meta) ? scene.stars.meta[i] : null; }
function fvCsciVer(scene, i) { var m = fvCsciMeta(scene, i); return (m && m.sci) ? (m.sci.v || 0) : 0; }
function fvCsciState(scene, i) { var m = fvCsciMeta(scene, i); return (m && m.sci) ? m.sci : null; }

// ---------------------------------------------------------------------------
// LA PETICION DESDE LA FICHA (barata: nada de red aqui)
// ---------------------------------------------------------------------------
function fvCsciRequest(scene, i) {
   var m = fvCsciMeta(scene, i);
   if (!m || (m.sci && m.sci.st !== "none")) return;
   m.sci = { st: "fetch", v: ++FV_CSCI_Q.ver, xp: null, xpWhy: "fetch", chem: null, chemWhy: "fetch" };
   FV_CSCI_Q.queue.push({ scene: scene, i: i });
   if (FV_CSCI_Q.timer === null) {
      try {
         FV_CSCI_Q.timer = new Timer; FV_CSCI_Q.timer.interval = 0.05; FV_CSCI_Q.timer.periodic = false;
         FV_CSCI_Q.timer.onTimeout = function() { fvCsciDrain(); };
      } catch (e) { FV_CSCI_Q.timer = null; }
   }
   if (FV_CSCI_Q.timer && !FV_CSCI_Q.busy) { try { FV_CSCI_Q.timer.start(); } catch (e2) {} }
}
// (5-nov) la precarga al arrancar el viaje: solo estrellas (los objetos y la nebulosa no piden nada a la red en su ficha). Barata: apunta
// y arranca el Timer de un disparo; el trabajo va fuera del fotograma, con la red bombeando eventos (CSH_NET_PUMP) como cuando la pide la ficha.
function fvCsciPrefetch(scene, sel) {
   if (!FV_CSCI_PREFETCH || !FV_CARD_SCI_AUTO || !sel || sel.kind !== "star" || !(sel.i >= 0)) return false;
   var m = fvCsciMeta(scene, sel.i);
   if (!m || (m.sci && m.sci.st !== "none")) return false;
   fvCsciRequest(scene, sel.i); fvCsciLog("prefetch star " + sel.i);
   return true;
}
function fvCsciDrain() {
   if (FV_CSCI_Q.busy) return;
   FV_CSCI_Q.busy = true;
   var ownPump = (typeof CSH_NET_PUMP !== "undefined" && CSH_NET_PUMP === null);
   if (ownPump) CSH_NET_PUMP = function() { if (typeof optProcessEvents === "function") optProcessEvents(); return false; };
   try {
      while (FV_CSCI_Q.queue.length) { var q = FV_CSCI_Q.queue.shift(); try { fvCsciFetch(q.scene, q.i, {}); } catch (e) { fvCsciLog("error " + e); var m = fvCsciMeta(q.scene, q.i); if (m && m.sci) { m.sci.st = "done"; m.sci.v = ++FV_CSCI_Q.ver; } } }
   } finally { if (ownPump) CSH_NET_PUMP = null; FV_CSCI_Q.busy = false; }
}

// ---------------------------------------------------------------------------
// LA FILA DE GAIA (identificador, XP publicado, GSP-Spec, FLAME): VizieR -> ESA -> ARI
// ---------------------------------------------------------------------------
var FV_CSCI_COLS = { Source: ["Source", "source_id"], RA_ICRS: ["RA_ICRS", "ra"], DE_ICRS: ["DE_ICRS", "dec"], Gmag: ["Gmag", "phot_g_mean_mag"], XPsamp: ["XPsamp", "has_xp_sampled"],
                     logg: ["logg", "logg_gspphot"], "Teff-S": ["Teff-S", "teff_gspspec"], "logg-S": ["logg-S", "logg_gspspec"], "[M/H]-S": ["[M/H]-S", "mh_gspspec"],
                     "b_[M/H]-S": ["b_[M/H]-S", "mh_gspspec_lower"], "B_[M/H]-S": ["B_[M/H]-S", "mh_gspspec_upper"], "[alpha/Fe]-S": ["[alpha/Fe]-S", "alphafe_gspspec"],
                     "b_[alpha/Fe]-S": ["b_[alpha/Fe]-S", "alphafe_gspspec_lower"], "B_[alpha/Fe]-S": ["B_[alpha/Fe]-S", "alphafe_gspspec_upper"], Flags: ["Flags", "flags_gspspec"],
                     "Age-Flame": ["Age-Flame", "age_flame"], "b_Age-Flame": ["b_Age-Flame", "age_flame_lower"], "B_Age-Flame": ["B_Age-Flame", "age_flame_upper"],
                     "Flags-Flame": ["Flags-Flame", "flags_flame"], "Mass-Flame": ["Mass-Flame", "mass_flame"],
                     // (metalicidad) GSP-Phot: [M/H] y Teff (VizieR I/355/gaiadr3 «[Fe/H]» y «Teff» = mh_gspphot y teff_gspphot); solo con FV_METAL.ON
                     "FeH-P": ["[Fe/H]", "mh_gspphot"], "Teff-P": ["Teff", "teff_gspphot"] };
function fvCsciGaiaWhere(raCol, decCol, ra, dec, rDeg) { return "1=CONTAINS(POINT('ICRS'," + raCol + "," + decCol + "),CIRCLE('ICRS'," + ra.toFixed(7) + "," + dec.toFixed(7) + "," + rDeg.toFixed(6) + "))"; }
function fvCsciAdqlVz(where, top) {
   return "SELECT " + (top ? "TOP " + top + " " : "") + "g.Source,g.RA_ICRS,g.DE_ICRS,g.Gmag,g.XPsamp,g.logg,p.\"Teff-S\",p.\"logg-S\",p.\"[M/H]-S\",p.\"b_[M/H]-S\",p.\"B_[M/H]-S\"," +
          "p.\"[alpha/Fe]-S\",p.\"b_[alpha/Fe]-S\",p.\"B_[alpha/Fe]-S\",p.\"Flags\",p.\"Age-Flame\",p.\"b_Age-Flame\",p.\"B_Age-Flame\",p.\"Flags-Flame\",p.\"Mass-Flame\"" + (fvCsciMetalOn() ? ",g.\"[Fe/H]\",g.Teff" : "") + " " +
          "FROM \"I/355/gaiadr3\" AS g LEFT JOIN \"I/355/paramp\" AS p ON g.Source=p.Source WHERE " + where;
}
function fvCsciAdqlGaia(where, top) {
   return "SELECT " + (top ? "TOP " + top + " " : "") + "g.source_id, g.ra, g.dec, g.phot_g_mean_mag, g.has_xp_sampled, ap.logg_gspphot, ap.teff_gspspec, ap.logg_gspspec, ap.mh_gspspec, ap.mh_gspspec_lower, " +
          "ap.mh_gspspec_upper, ap.alphafe_gspspec, ap.alphafe_gspspec_lower, ap.alphafe_gspspec_upper, ap.flags_gspspec, ap.age_flame, ap.age_flame_lower, ap.age_flame_upper, ap.flags_flame, ap.mass_flame" + (fvCsciMetalOn() ? ", g.mh_gspphot, g.teff_gspphot" : "") + " " +
          "FROM gaiadr3.gaia_source AS g LEFT JOIN gaiadr3.astrophysical_parameters AS ap ON g.source_id = ap.source_id WHERE " + where;
}
function fvCsciTapUrl(base, adql) { return base + "?REQUEST=doQuery&LANG=ADQL&FORMAT=csv&QUERY=" + encodeURIComponent(adql); }
// una fila de cualquiera de los tres -> objeto con los nombres de VizieR
function fvCsciNormRow(r) { var o = {}; for (var k in FV_CSCI_COLS) if (FV_CSCI_COLS.hasOwnProperty(k)) { var v = cshNfCol(r, FV_CSCI_COLS[k]); o[k] = (v === undefined) ? "" : String(v).replace(/^\s+|\s+$/g, "").replace(/^"|"$/g, ""); } return o; }
// el texto de una peticion: la costura de las pruebas o la red. -> { ok, text, server, code }
function fvCsciGet(kind, servers, key, timeoutS) {
   if (typeof FV_CSCI_HOOK === "function") {
      for (var i = 0; i < servers.length; ++i) { var h = FV_CSCI_HOOK(kind, servers[i].url); if (h !== undefined) return { ok: !!(h && h.ok), text: h ? h.text : "", server: "hook", code: h && h.ok ? "" : "no-network" }; }
   }
   if (!FV_CSCI_ONLINE) return { ok: false, text: "", code: "offline" };
   var f = cshNfFetchHedged({ key: key, cache: "last", timeoutS: timeoutS || FV_CSCI.TIMEOUT_S, servers: servers }, FV_CSCI.HEDGE_S);
   return { ok: !!f.ok, text: f.ok ? f.text : "", server: f.server || "", code: f.ok ? "" : (f.code || "no-network"), fromCache: !!f.fromCache };
}
// la fila de Gaia de la estrella i (la mas cercana con |ΔG| < DG_MAX) -> { ok, row (nombres de VizieR), code, server }
function fvCsciGaiaRow(scene, i) {
   var S = scene.stars, m = S.meta[i], rDeg = FV_CSCI.CONE_ARCSEC / 3600;
   if (!(isFinite(m.ra) && isFinite(m.dec))) return { ok: false, code: "no-position" };
   var where = fvCsciGaiaWhere("g.RA_ICRS", "g.DE_ICRS", m.ra, m.dec, rDeg), whereG = fvCsciGaiaWhere("g.ra", "g.dec", m.ra, m.dec, rDeg), adG = fvCsciAdqlGaia(whereG, 5);
   var servers = [{ url: cpSfTapUrl(CP_SF_VIZIER_TAP, fvCsciAdqlVz(where, 5)), check: { csv: "Source" } },
                  { url: fvCsciTapUrl(FV_CSCI.ESA_TAP, adG), check: { csv: "source_id" } },
                  { url: fvCsciTapUrl(FV_CSCI.ARI_TAP, adG), check: { csv: "source_id" } }];
   var r = fvCsciGet("gaia", servers, "fvsci-gaia|" + m.ra.toFixed(6) + "|" + m.dec.toFixed(6));
   if (!r.ok) return { ok: false, code: r.code };
   var t = cpSfParseTable(r.text, ","), best = null, bd = 1e9;
   for (var k = 0; k < t.rows.length; ++k) {
      var o = fvCsciNormRow(t.rows[k]), g = cpSfNum(o.Gmag), ra = cpSfNum(o.RA_ICRS), de = cpSfNum(o.DE_ICRS);
      if (ra === null || de === null) continue;
      var dg = (g !== null) ? Math.abs(g - S.g[i]) : 0;
      if (dg > FV_CSCI.DG_MAX) continue;
      var sc = cpSfSeparation(ra, de, m.ra, m.dec) * 3600 + 2 * dg;
      if (sc < bd) { bd = sc; best = o; }
   }
   if (!best) return { ok: false, code: "not-found", server: r.server };
   return { ok: true, row: best, server: r.server };
}

// ---------------------------------------------------------------------------
// EL ESPECTRO XP: local (DR3/SP) o por red (ESA, ARI)
// ---------------------------------------------------------------------------
var FV_CSCI_SP = null;
function fvCsciSpInfo() {
   if (FV_CSCI_SP !== null) return FV_CSCI_SP;
   var info = { ok: false, release: null, spectrum: null };
   try { var rel = Gaia.DataRelease_3_SP, p = cshGaiaProbe(rel); if (p.valid && p.spectrum && p.spectrum.count > 0) { info.ok = true; info.release = rel; info.spectrum = p.spectrum; } } catch (e) {}
   FV_CSCI_SP = info;
   return info;
}
function fvCsciGaiaSearch(info, ra, dec, rDeg, gLo, gHi, maxRows) {
   var g = new Gaia;
   g.command = "search"; g.dataRelease = info.release;
   g.centerRA = ra; g.centerDec = dec; g.radius = rDeg;
   g.magnitudeLow = gLo; g.magnitudeHigh = gHi; g.sourceLimit = maxRows;
   g.requiredFlags = 0; g.inclusionFlags = 0; g.exclusionFlags = 0;
   try { g.normalizeSpectrum = false; } catch (eN) {}
   try { g.photonFluxUnits = false; } catch (eP) {}
   g.sortBy = Gaia.SortBy_G; g.generateTextOutput = false; g.generateBinaryOutput = false;
   try { g.verbosity = 0; } catch (eV) {}
   if (g.executeGlobal() === false) return null;
   return g.sources || [];
}
// -> { ok, code, lam, flux, err, src }
function fvCsciXpLocal(scene, i) {
   var out = { ok: false, code: "no-sp-database", lam: [], flux: [], err: null, src: "local" }, info = fvCsciSpInfo(), S = scene.stars, m = S.meta[i];
   if (!info.ok) return out;
   try {
      var rows = fvCsciGaiaSearch(info, m.ra, m.dec, 1.5 / 3600, S.g[i] - 0.5, S.g[i] + 0.5, 10);
      if (rows === null) { out.code = "gaia-failed"; return out; }
      var best = null, bd = 1e9;
      for (var k = 0; k < rows.length; ++k) { var dg = Math.abs(Number(rows[k][5]) - S.g[i]); if (dg < bd) { bd = dg; best = rows[k]; } }
      if (best === null || !best[9] || !(best[9].length > 0)) { out.code = "not-in-sp"; return out; }
      var f = best[9], sp = info.spectrum;
      for (var q = 0; q < f.length; ++q) { out.lam.push(sp.start + q * sp.step); out.flux.push(Number(f[q])); }
      out.ok = true; out.code = "";
   } catch (e) { out.code = "gaia-failed"; }
   return out;
}
// de csXpParseEsa / csXpParseAri (cs_engine.js:364-385)
function fvCsciXpParseEsa(text) {
   var t = cpSfParseTable(String(text || ""), ","), out = { lam: [], flux: [], err: [] };
   for (var i = 0; i < t.rows.length; ++i) { var l = cpSfNum(t.rows[i].wavelength), f = cpSfNum(t.rows[i].flux), e = cpSfNum(t.rows[i].flux_error); if (l === null || f === null) continue; out.lam.push(l); out.flux.push(f); out.err.push((e !== null) ? e : NaN); }
   return out;
}
function fvCsciXpParseAri(text) {
   var t = cpSfParseTable(String(text || ""), ","), out = { lam: [], flux: [], err: [] };
   if (!t.rows.length) return out;
   function arr(v) { var s = String(v || "").replace(/[{}"\s]/g, ""); return s.length ? s.split(",").map(function(x) { var n = Number(x); return isFinite(n) ? n : NaN; }) : []; }
   var f = arr(t.rows[0].flux), e = arr(t.rows[0].flux_error);
   for (var k = 0; k < f.length; ++k) { if (!isFinite(f[k])) continue; out.lam.push(FVS_XP.L0 + FVS_XP.STEP * k); out.flux.push(f[k]); out.err.push((k < e.length) ? e[k] : NaN); }
   return out;
}
function fvCsciXpOnline(sourceId) {
   var out = { ok: false, code: "", lam: [], flux: [], err: [], src: "esa" }, id = String(sourceId).replace(/[^0-9]/g, "");
   var servers = [{ url: FV_CSCI.ESA_XP + id, check: { has: "wavelength" }, noTrip: [500] },
                  { url: fvCsciTapUrl(FV_CSCI.ARI_TAP, "SELECT source_id, flux, flux_error FROM gaiadr3.xp_sampled_mean_spectrum WHERE source_id = " + id), check: { csv: "source_id" } }];
   var r = fvCsciGet("xp", servers, "xp|" + id);
   if (!r.ok) { out.code = r.code === "offline" ? "offline" : "no-network"; return out; }
   var esa = String(r.text).indexOf("wavelength") >= 0, p = esa ? fvCsciXpParseEsa(r.text) : fvCsciXpParseAri(r.text);
   out.src = esa ? "esa" : "ari";
   if (p.lam.length < 50) { out.code = "no-xp"; return out; }
   out.lam = p.lam; out.flux = p.flux; out.err = p.err; out.ok = true;
   return out;
}

// ---------------------------------------------------------------------------
// LOS SURVEYS por el identificador de Gaia (VizieR)
// ---------------------------------------------------------------------------
// (una estrella: un cono de 10″ Y el identificador. El cono es lo que deja traducirla a ASU para el espejo de IDIA cuando el CDS no contesta
// —cshVizierAdqlToAsu exige cono—; el identificador elige la fila. Un lote: IN, solo el CDS.)
function fvCsciSurveyAdql(k, ids, pos) {
   var T = FVS_CHEM_TAB[k], c = [];
   for (var i = 0; i < T.cols.length; ++i) c.push("\"" + T.cols[i] + "\"");
   var w = (ids.length === 1) ? "\"" + T.id + "\" = " + ids[0] : "\"" + T.id + "\" IN (" + ids.join(",") + ")";
   if (ids.length === 1 && pos) w = "1=CONTAINS(POINT('ICRS',RAJ2000,DEJ2000),CIRCLE('ICRS'," + pos[0].toFixed(6) + "," + pos[1].toFixed(6) + ",0.0028)) AND " + w;
   return "SELECT " + c.join(", ") + " FROM \"" + T.table + "\" WHERE " + w;
}
// -> { ok, rows: [filas], code }
function fvCsciSurveyRows(k, ids, pos) {
   var url = cpSfTapUrl(CP_SF_VIZIER_TAP, fvCsciSurveyAdql(k, ids, pos));
   if (typeof FV_CSCI_HOOK === "function") { var h = FV_CSCI_HOOK("survey-" + k, url); if (h !== undefined) return (h && h.ok) ? { ok: true, rows: cpSfParseTable(h.text, ",").rows } : { ok: false, rows: [], code: "no-network" }; }
   if (!FV_CSCI_ONLINE) return { ok: false, rows: [], code: "offline" };
   var r = null;
   try { r = cpSfHttpText(url, { timeoutS: FV_CSCI.SURVEY_TIMEOUT_S }); } catch (e) { r = null; }
   if (!r || !r.ok || String(r.text || "").indexOf(FVS_CHEM_TAB[k].id) < 0) return { ok: false, rows: [], code: "no-network" };
   return { ok: true, rows: cpSfParseTable(r.text, ",").rows };
}
// las filas de un survey para UN identificador -> registro adoptado (el mejor por S/N, sin duplicados) | null
function fvCsciBestRec(k, rows) {
   var best = null;
   for (var i = 0; i < rows.length; ++i) {
      var rec = fvsChemParse(k, rows[i]);
      if (!rec || !rec.feh) continue;
      if (!best || (best.dup && !rec.dup) || ((!!best.dup === !!rec.dup) && (rec.snr || 0) > (best.snr || 0))) best = rec;
   }
   return best;
}

// (metalicidad) el [M/H] de GSP-Phot: el de la fila de la ficha o, si no lo trae, el del refinado de la escena (fv_build.js, meta.mhPhot)
function fvCsciPhot(m, row) {
   var v = row ? cpSfNum(row["FeH-P"]) : null, t = row ? cpSfNum(row["Teff-P"]) : null;
   if (v !== null && t !== null) return { v: v, teff: t };
   return (m && isFinite(m.mhPhot) && m.mhPhot !== null && isFinite(m.mhPhotT)) ? { v: m.mhPhot, teff: m.mhPhotT } : null;
}

// ---------------------------------------------------------------------------
// TODO PARA UNA ESTRELLA (sincrono: el Timer o las pruebas)
// ---------------------------------------------------------------------------
function fvCsciFetch(scene, i, o) {
   o = o || {};
   var S = scene.stars, m = S.meta[i], t0 = Date.now();
   if (!m) return null;
   var sci = m.sci && m.sci.st === "done" && !o.force ? m.sci : null;
   if (sci) return sci;
   sci = { st: "fetch", v: m.sci ? m.sci.v : 0, xp: null, xpWhy: "", chem: null, chemWhy: "", id: m.sourceId || "" };
   m.sci = sci;
   // 1. la fila de Gaia (identificador, XP publicado, GSP-Spec, FLAME)
   var gr = fvCsciGaiaRow(scene, i), row = gr.ok ? gr.row : null;
   if (row && row.Source && /^\d{6,20}$/.test(row.Source)) sci.id = row.Source;
   // (metalicidad) lo de la fila de Gaia YA a la vista: GSP-Spec (si pasa sus banderas) o GSP-Phot; los surveys lo mejoran al acabar
   var phot = null;
   if (fvCsciMetalOn()) {
      phot = fvCsciPhot(m, row);
      var g0 = row ? fvsChemParse("gspspec", row) : null;
      sci.metal = fvsMetalBuild(g0 ? fvsChemBuild({ gspspec: g0 }, null, cpSfNum(row.logg)) : null, phot, m.teff); sci.metalT = Date.now() - t0; sci.v = ++FV_CSCI_Q.ver;
   }
   var xpPub = row ? String(row.XPsamp).toLowerCase() : "";
   xpPub = (xpPub === "1" || xpPub === "true" || xpPub === "t") ? true : ((xpPub === "0" || xpPub === "false" || xpPub === "f") ? false : null);
   // 2. el espectro XP
   var xp = fvCsciXpLocal(scene, i);
   if (!xp.ok) {
      if (xpPub === false) xp.code = "no-xp";
      else if (sci.id) { var on = fvCsciXpOnline(sci.id); if (on.ok) xp = on; else xp.code = (on.code === "no-xp") ? "no-xp" : (xp.code === "not-in-sp" ? "not-in-sp" : on.code); }
      else xp.code = gr.ok ? "no-id" : (gr.code === "not-found" ? "no-xp" : (gr.code === "offline" ? "offline" : "no-network"));
   }
   if (xp.ok) { sci.xp = fvsXpCompact(xp.lam, xp.flux, xp.err, xp.src); sci.xpWhy = sci.xp ? "" : "no-xp"; }
   else sci.xpWhy = (xp.code === "not-in-sp" || xp.code === "no-xp") ? "no-xp" : (xp.code === "offline" ? "offline" : (xp.code === "no-sp-database" ? "no-network" : xp.code));
   // el espectro YA a la vista (la ficha empieza su barrido) mientras se pregunta por la composicion: sci.v cambia, st sigue «fetch»
   var tXp = Date.now() - t0; sci.v = ++FV_CSCI_Q.ver;
   if (o.pump !== false) { try { if (typeof optProcessEvents === "function" && typeof CSH_NET_PUMP === "function") optProcessEvents(); } catch (eP) {} }
   // 3. la composicion: GSP-Spec + FLAME de la fila de Gaia y los tres surveys por el identificador
   var recs = {}, flame = null, anyNet = false, anyOk = gr.ok;
   if (row) { var g = fvsChemParse("gspspec", row); if (g) recs.gspspec = g; flame = fvsChemFlameRow(row); }
   if (sci.id) {
      var ks = ["apogee", "galah", "lamost"];
      for (var k = 0; k < ks.length; ++k) { var sr = fvCsciSurveyRows(ks[k], [sci.id], [m.ra, m.dec]); if (sr.ok) { anyOk = true; var b = fvCsciBestRec(ks[k], sr.rows); if (b) recs[ks[k]] = b; } else anyNet = true; }
   }
   var tSv = Date.now() - t0 - tXp;
   var logg0 = row ? cpSfNum(row.logg) : null;
   sci.chem = fvsChemBuild(recs, flame, logg0);
   sci.chemWhy = sci.chem ? "" : (anyOk ? "none" : (gr.code === "offline" ? "offline" : "no-network"));
   if (sci.chem && anyNet) sci.chem.partial = 1;            // algun survey no contesto: lo que hay es lo que hay
   if (fvCsciMetalOn()) sci.metal = fvsMetalBuild(sci.chem, phot, m.teff);
   sci.st = "done"; sci.ms = Date.now() - t0; sci.v = ++FV_CSCI_Q.ver;
   fvCsciLog("star " + i + " id " + (sci.id || "-") + " · gaia " + (gr.ok ? "ok " + (gr.server || "") : gr.code) + " · xp " + (sci.xp ? sci.xp.src + " fitT " + sci.xp.fitT : sci.xpWhy) +
             " · chem " + (sci.chem ? sci.chem.srcs.join("+") + " [Fe/H] " + sci.chem.feh.v : sci.chemWhy) + (fvCsciMetalOn() ? " · metal " + (sci.metal ? sci.metal.s + " " + sci.metal.v + " q" + sci.metal.q : "none") + " at " + sci.metalT + " ms" : "") +
             " · " + sci.ms + " ms (gaia+xp " + tXp + ", surveys " + tSv + ")");
   return sci;
}

// ---------------------------------------------------------------------------
// EL PASO DEL CAMPO PARA EL PAQUETE WEB (lo llama quien exporta: ver el HANDOFF de I12)
// ---------------------------------------------------------------------------
// XP: una busqueda en DR3/SP con el cono del campo (como csXpFieldLocal) y el compacto de las FIELD_XP_MAX mas brillantes de la foto que lo
// tengan. Composicion: la fila de Gaia de las de G < FIELD_CHEM_GMAX por el cono (un lote) y los surveys por lotes de identificadores.
// Lo ya traido por la ficha (meta.sci «done») no se toca. -> { xp: n, chem: n, ms, notes: [] }
function fvCsciField(scene, o) {
   o = o || {};
   var S = scene.stars, F = scene.field, t0 = Date.now(), out = { xp: 0, chem: 0, ms: 0, notes: [] }, i, k;
   if (!S || !F) return out;
   var rDeg = 0.5 * Math.sqrt(F.width * F.width + F.height * F.height) * F.scaleArcsec / 3600;
   var order = [];
   for (i = 0; i < S.n; ++i) if (S.inFrame[i] && S.g[i] < FVS_XP.GMAX && S.meta[i] && isFinite(S.meta[i].ra)) order.push(i);
   order.sort(function(a, b) { return S.g[a] - S.g[b]; });
   // --- XP local ---
   var info = fvCsciSpInfo();
   if (info.ok && o.xp !== false) {
      var rows = null;
      try { rows = fvCsciGaiaSearch(info, F.ra, F.dec, rDeg + 2 / 3600, -1.5, Math.min(18.2, (S.g[order[Math.min(order.length, FV_CSCI.FIELD_XP_MAX) - 1]] || 17.65) + 0.5), 200000); } catch (eS) { rows = null; }
      if (rows) {
         var cell = 1.5 / 3600, strips = {}, R2 = cell * cell, kk = Math.PI / 180;
         for (k = 0; k < rows.length; ++k) { var rr = rows[k]; if (!rr[9] || !(rr[9].length > 0)) continue; var key = Math.floor(Number(rr[1]) / cell); (strips[key] = strips[key] || []).push(rr); }
         var nX = 0, sp = info.spectrum;
         for (k = 0; k < order.length && nX < FV_CSCI.FIELD_XP_MAX; ++k) {
            var si = order[k], m = S.meta[si];
            if (m.sci && m.sci.st === "done") { if (m.sci.xp) ++nX; continue; }
            var kd = Math.floor(m.dec / cell), best = null, bd = 1e9, cd = Math.cos(m.dec * kk);
            for (var dk = -1; dk <= 1; ++dk) { var Ls = strips[kd + dk]; if (!Ls) continue; for (var q = 0; q < Ls.length; ++q) { var dra = Number(Ls[q][0]) - m.ra; if (dra > 180) dra -= 360; else if (dra < -180) dra += 360; var dx = dra * cd, dy = Number(Ls[q][1]) - m.dec; if (dx * dx + dy * dy > R2) continue; var dg = Math.abs(Number(Ls[q][5]) - S.g[si]); if (dg <= 0.5 && dg < bd) { bd = dg; best = Ls[q]; } } }
            if (!best) continue;
            var lam = [], fl = [], f = best[9];
            for (var z = 0; z < f.length; ++z) { lam.push(sp.start + z * sp.step); fl.push(Number(f[z])); }
            var X = fvsXpCompact(lam, fl, null, "local");
            if (!X) continue;
            m.sciField = m.sciField || {}; m.sciField.xp = X; ++nX;
         }
         out.xp = nX;
      } else out.notes.push("local DR3/SP search failed");
   } else if (!info.ok) out.notes.push("no local Gaia DR3/SP database: the web package carries only the spectra of the cards opened");
   // --- composicion de las brillantes ---
   if (o.chem !== false && (FV_CSCI_ONLINE || typeof FV_CSCI_HOOK === "function")) {
      var bright = order.filter(function(j) { return S.g[j] < FV_CSCI.FIELD_CHEM_GMAX && !(S.meta[j].sci && S.meta[j].sci.st === "done"); });
      if (bright.length) {
         var where = fvCsciGaiaWhere("g.RA_ICRS", "g.DE_ICRS", F.ra, F.dec, rDeg) + " AND g.Gmag < " + (FV_CSCI.FIELD_CHEM_GMAX + 0.5).toFixed(1);
         var whereG = fvCsciGaiaWhere("g.ra", "g.dec", F.ra, F.dec, rDeg) + " AND g.phot_g_mean_mag < " + (FV_CSCI.FIELD_CHEM_GMAX + 0.5).toFixed(1);
         var gq = fvCsciGet("gaia-field", [{ url: cpSfTapUrl(CP_SF_VIZIER_TAP, fvCsciAdqlVz(where, 0)), check: { csv: "Source" } }, { url: fvCsciTapUrl(FV_CSCI.ESA_TAP, fvCsciAdqlGaia(whereG, 0)), check: { csv: "source_id" } },
                                             { url: fvCsciTapUrl(FV_CSCI.ARI_TAP, fvCsciAdqlGaia(whereG, 0)), check: { csv: "source_id" } }], "fvsci-gaiafield|" + F.ra.toFixed(5) + "|" + F.dec.toFixed(5) + "|" + rDeg.toFixed(4), 40);
         if (gq.ok) {
            var grow = cpSfParseTable(gq.text, ",").rows.map(fvCsciNormRow), byId = {}, ids = [];
            for (k = 0; k < bright.length; ++k) {
               var bi = bright[k], mb = S.meta[bi], bb = null, bs = 1e9;
               for (var r2 = 0; r2 < grow.length; ++r2) { var ra2 = cpSfNum(grow[r2].RA_ICRS), de2 = cpSfNum(grow[r2].DE_ICRS), g2 = cpSfNum(grow[r2].Gmag); if (ra2 === null || g2 === null || Math.abs(g2 - S.g[bi]) > FV_CSCI.DG_MAX) continue; var sep = cpSfSeparation(ra2, de2, mb.ra, mb.dec) * 3600; if (sep > FV_CSCI.CONE_ARCSEC) continue; var sc2 = sep + 2 * Math.abs(g2 - S.g[bi]); if (sc2 < bs) { bs = sc2; bb = grow[r2]; } }
               if (bb && /^\d{6,20}$/.test(bb.Source)) { byId[bb.Source] = { i: bi, row: bb, recs: {} }; ids.push(bb.Source); var gs = fvsChemParse("gspspec", bb); if (gs) byId[bb.Source].recs.gspspec = gs; mb.sciField = mb.sciField || {}; mb.sciField.chemSearched = true; }
            }
            var ks2 = ["apogee", "galah", "lamost"];
            for (k = 0; k < ks2.length; ++k) for (var c0 = 0; c0 < ids.length; c0 += FV_CSCI.FIELD_ID_CHUNK) {
               var sr2 = fvCsciSurveyRows(ks2[k], ids.slice(c0, c0 + FV_CSCI.FIELD_ID_CHUNK));
               if (!sr2.ok) { out.notes.push(ks2[k] + ": no answer"); continue; }
               var per = {};
               for (var r3 = 0; r3 < sr2.rows.length; ++r3) { var idc = String(sr2.rows[r3][FVS_CHEM_TAB[ks2[k]].id] || "").replace(/\s+/g, ""); if (byId[idc]) (per[idc] = per[idc] || []).push(sr2.rows[r3]); }
               for (var idk in per) { var be = fvCsciBestRec(ks2[k], per[idk]); if (be) byId[idk].recs[ks2[k]] = be; }
            }
            for (var id2 in byId) {
               var E = byId[id2], C = fvsChemBuild(E.recs, fvsChemFlameRow(E.row), cpSfNum(E.row.logg)), me = S.meta[E.i];
               if (C) { me.sciField = me.sciField || {}; me.sciField.chem = C; ++out.chem; }
               if (fvCsciMetalOn()) { var MM = fvsMetalBuild(C, fvCsciPhot(me, E.row), me.teff); if (MM) { me.sciField = me.sciField || {}; me.sciField.metal = MM; } }
            }
         } else out.notes.push("Gaia field query: no answer");
      }
   }
   out.ms = Date.now() - t0;
   fvCsciLog("field: xp " + out.xp + " · chem " + out.chem + " · " + out.ms + " ms" + (out.notes.length ? " · " + out.notes.join("; ") : ""));
   return out;
}
// lo que viaja al paquete de una estrella: { xp, chem } o null (la ficha abierta manda sobre el paso del campo)
// MISMA FORMA que meta.sci (st, xp, chem, xpWhy, chemWhy): el visor web la lee igual. null = no se miro (el visor no dice nada).
function fvCsciExport(m) {
   if (!m) return null;
   var s = (m.sci && m.sci.st === "done") ? m.sci : null, f = m.sciField || null;
   if (!s && !f) return null;
   var xp = (s && s.xp) || (f && f.xp) || null, chem = (s && s.chem) || (f && f.chem) || null;
   var o = { st: "done", xp: xp, chem: chem, xpWhy: s ? s.xpWhy : (xp ? "" : "skip"), chemWhy: s ? s.chemWhy : (chem ? "" : (f && f.chemSearched ? "none" : "skip")) };
   // (metalicidad) el registro de fvsMetalBuild tal cual lo pinta PixInsight (el visor puede pintar sus lineas con fv_sci_metal.js)
   if (fvCsciMetalOn()) { var mt = (s && s.metal) || (f && f.metal) || null; if (mt) o.metal = mt; }
   return o;
}
