// ============================================================================
// FieldVoyager/src/ui/fv_volume_paint.js — EL PINTOR DEL VOLUMEN POR FAMILIAS (fase 2 de la sonda V, 5-nov-2026). Solo con FV_VOLM.ON.
// ----------------------------------------------------------------------------
// OBJETOS COMPACTOS (cascara / disco, src/engine/fv_volume.js): el volumen factorizado en TRES pilas de cortes alineadas con el objeto (Z de cara
// a la Tierra, X, Y); al mirar en oblicuo se mezclan las dos mas alineadas (fvVolStackOpacity). Se pintan con VECINO MAS PROXIMO en un LIENZO
// PROPIO a ~1 texel por pixel (sumas exactas en 8 bits: Qt TRUNCA el bilineal y las motas de 1 nivel de la difusion se perdian, sonda V
// tests/fv_V_qt_probe.log) y el lienzo se amplia UNA vez, suave. Disco: los cortes van a 1/HEAD y el lienzo pasa por el HOMBRO (sin quemar).
// NEBULOSA EXTENSA: cortes de emision (Add) y de polvo (Multiply) ordenados de LEJOS A CERCA respecto a la camara (el polvo tapa lo de detras).
// PROCEDENCIA: vPaint / vPaintOff / prScaled / vFrame de tests/fv_V_sonda.js (sonda V, mismo autor), con el hombro y el polvo añadidos.
// Lo llaman fv_objects_paint.js (fvObjectsPaint) y fv_painter.js (paintLayers), cada uno con una linea marcada «(V2)». ES5.
// ============================================================================

var FV_VOL_PAINT = { OFF_MAX: 6e6, NEAR_K: 0.6, DUST_EPS: 0.02, LP_MAX: 8,
   SLAB_NEAR: 1,     // fundido de un corte de la nebulosa al acercarse: SLAB_NEAR × la separacion entre cortes (1 = el de las capas de hoy)
   // (V3, ronda 3) DENTRO del objeto: el mismo lienzo propio que fuera, a pantalla completa y a ~1 texel por pixel del lienzo en el centro del objeto
   // (× IN_K), y los cortes que cruzan el plano de la camara se pintan por TESELAS que quedan delante (antes: pintor directo a pantalla completa,
   // HEAD pasadas y paso bajo: 33–74 ms y rejilla). IN_V3 false = el camino de la fase 2 (ROJO del coste y de la rejilla).
   IN_V3: true, IN_K: 1, TILE_MIN: 6, TILE_DEPTH: 4, SH_ANG: 15 };

function fvVolBmpOf(px, w, h) { var b = new Bitmap(w, h, BitmapFormat.RGB32); new Uint32Array(b.pixelData()).set(px); return b; }

// el MARCO del objeto en el mundo (como desde la Tierra, sin girar): origen de la esquina 0 del recorte y ejes por PIXEL DEL MODELO
function fvVolObjFrameOf(sc, o, m, ds) {
   var G = o._gfx, F = fvObjFrame(sc, o, fvSub(o.pos, fvMul(fvNorm(o.pos), 10 * o.radiusLy)));
   if (!F) return null;
   var e1 = fvMul(fvSub(F.off[1], F.off[0]), (ds || 1) / G.w), e2 = fvMul(fvSub(F.off[3], F.off[0]), (ds || 1) / G.h), s = fvLen(e1);
   var o0 = fvAdd(F.c, F.off[0]), ez = fvMul(F.u0, s);
   return { o0: o0, e1: e1, e2: e2, ez: ez, ex: fvNorm(e1), ey: fvNorm(e2), ez1: F.u0, s: s, center: fvAdd(fvAdd(o0, fvMul(e1, m.cx)), fvMul(e2, m.cy)) };
}
function fvVolW(V, x, y, z) { var f = V.fr; return fvAdd(fvAdd(fvAdd(f.o0, fvMul(f.e1, x)), fvMul(f.e2, y)), fvMul(f.ez, z)); }

// (build) el volumen de un objeto: medir, clasificar, construir y hacer los Bitmap de las tres pilas. Deja o.vol (enumerable: familia, confianza,
// por que; lo leen la ficha, el log y el exportador) y o._vol (no enumerable: modelo, pilas, marco). -> o.vol
function fvVolMakeObj(sc, o, cut, geom) {
   var t0 = Date.now(), info = { type: o.type, subtype: o.subtype, otype: o.otype, sizeArcmin: o.sizeArcmin, sizeCatArcmin: o.sizeCatArcmin };
   var r = fvVolFromCut(cut, geom, info, {}), cls = r.cls, mm = r.meas;
   o.vol = { family: cls.family || "fallback", conf: Math.round(1000 * cls.conf) / 1000, score: { shell: Math.round(1000 * cls.score.shell) / 1000, disk: Math.round(1000 * cls.score.disk) / 1000 },
             why: cls.why.join(" | "), meas: { q: +mm.q.toFixed(3), qAll: +mm.qAll.toFixed(3), sym: +mm.sym.toFixed(3), lb: +Math.min(999, mm.lb).toFixed(2), conc: +mm.conc.toFixed(2) }, ds: r.ds, ms: 0 };
   if (!r.m) { o.vol.ms = Date.now() - t0; return o.vol; }
   // (V3) pilas GENERICAS (src/engine/fv_volume3.js): el disco en pilas alineadas con el disco, la cascara y el resto en Z/X/Y de la imagen. El disco
   // toma el detalle del recorte a resolucion completa (Cs) con texeles de 1/ds px del modelo (tope FV_VOLM3.TEX_MAX)
   var m = r.m, ds = r.ds, N = FV_VOLM.N[m.family] || 32, mb = 0, gw0 = geom.w, gh0 = geom.h;
   var Cs = ds > 1 ? function(x, y, cv) { fv3CutBil(cut, gw0, gh0, x * ds, y * ds, cv); } : null;
   var S = fvVol3Stacks(m, mm, { Cs: Cs, tex: 1 / ds, N: N }), texMin = 1e9, box = [1e9, -1e9, 1e9, -1e9, 1e9, -1e9];
   S.stacks.forEach(function(st) {
      for (var j = 0; j < st.cuts.length; ++j) {
         var C = st.cuts[j]; if (!C) continue; C.bmp = fvVolBmpOf(C.px, C.bw, C.bh); mb += 4 * C.bw * C.bh; C.px = null; texMin = Math.min(texMin, fvLen(C.U), fvLen(C.V));
         for (var cu = 0; cu < 2; ++cu) for (var cv = 0; cv < 2; ++cv) for (var a3 = 0; a3 < 3; ++a3) { var pv = C.P0[a3] + C.U[a3] * cu * C.bw + C.V[a3] * cv * C.bh; box[2 * a3] = Math.min(box[2 * a3], pv); box[2 * a3 + 1] = Math.max(box[2 * a3 + 1], pv); }
      }
   });
   var V = { m: m, stacks: S.stacks, info: S.info, ds: ds, lut: (m.head > 1) ? fvVolShoulderLut(m.head) : null, mb: mb / 1048576, texMin: texMin < 1e9 ? texMin : 1, box: box[1] > box[0] ? box : null };
   V.fr = fvVolObjFrameOf(sc, o, m, ds);
   if (V.fr) S.stacks.forEach(function(st) { st.nW = fvNorm(fvVolV(V, st.nrm)); st.spW = st.sp * V.fr.s; });
   try { Object.defineProperty(o, "_vol", { value: V, enumerable: false, writable: true, configurable: true }); } catch (e) { o._vol = V; }
   o.vol.ms = Date.now() - t0; o.vol.mb = Math.round(100 * V.mb) / 100; o.vol.N = N; o.vol.D = m.D; o.vol.head = m.head;
   o.vol.stacks = S.stacks.map(function(st) { return st.group + ":" + st.name + st.N; }).join(" ");
   if (m.family === "shell") { o.vol.kappa = +m.kappa.toFixed(3); o.vol.prolate = +m.prolate.toFixed(3); }
   else { o.vol.incDeg = +(m.inc * 180 / Math.PI).toFixed(1); o.vol.windFrac = +m.windFrac.toFixed(3); o.vol.windW = +m.windW.toFixed(3); }
   if (S.info.v3) { var Dk = S.info.disk; o.vol.v3 = { Ra: +Dk.Ra.toFixed(1), tex: +Dk.tex.toFixed(3), smin: +Dk.smin.toFixed(2), nAB: Dk.nAB, restFrac: +S.info.restFrac.toFixed(4), rest: S.info.rest, gain: Dk.gain ? [+Dk.gain.p05.toFixed(3), +Dk.gain.p50.toFixed(3), +Dk.gain.p95.toFixed(3)] : null, ms: Dk.ms }; }
   return o.vol;
}
// un vector del modelo (px del modelo) en el mundo (sin el origen)
function fvVolV(V, v) { var f = V.fr; return fvAdd(fvAdd(fvMul(f.e1, v[0]), fvMul(f.e2, v[1])), fvMul(f.ez, v[2])); }
// LOS CORTES de las pilas en Add sobre g (proyector pr). only = { Z, X, Y } forzadas o null. nearest: vecino mas proximo (lienzo propio)
// (V3) pilas genericas: cada grupo (disco, resto, cascara) reparte su opacidad entre sus DOS pilas mas alineadas con la vista (fv3StackOpacity) y
// cada corte es un plano con su esquina P0 y sus pasos U, V (coordenadas del modelo). only = { nombre de pila: opacidad } forzadas o null.
function fvVolPaintStacks(g, pr, V, camPos, op0, only, nearest) {
   var fr = V.fr, d = fvNorm(fvSub(fr.center, camPos)), drawn = 0, groups = {}, gk;
   g.compositionOperator = CompositionOp_Add; g.smoothInterpolation = !nearest;
   V.stacks.forEach(function(st, k) { (groups[st.group] = groups[st.group] || []).push(k); });
   for (gk in groups) {
      var ks = groups[gk], opG = fv3StackOpacity(d, ks.map(function(k) { return V.stacks[k].nW; }));
      for (var ii = 0; ii < ks.length; ++ii) {
         var st = V.stacks[ks[ii]], a = only ? (only[st.name] || 0) : opG[ii];
         if (!(a > 0.003)) continue;
         for (var j = 0; j < st.N; ++j) {
            var C = st.cuts[j]; if (!C || !C.bmp) continue;
            var pc = fvVolW(V, C.pc[0], C.pc[1], C.pc[2]), dPl = Math.abs(fvDot(fvSub(camPos, pc), st.nW)), op = op0 * a * fvSmooth(dPl / (FV_VOL_PAINT.NEAR_K * st.spW));
            if (op <= 0.004) continue;
            if (fvVolDrawCut(g, pr, V, C, Math.min(1, op), 0.25 * st.spW)) ++drawn;
         }
      }
   }
   g.opacity = 1;
   return drawn;
}
// un corte: si las cuatro esquinas quedan delante de la camara, entero con su homografia; si no (el plano cruza el de la camara: DENTRO del
// objeto), por teselas del texel que quedan delante (2×2 recursivo hasta TILE_DEPTH o TILE_MIN texeles). -> true si se pinto algo
function fvVolDrawCut(g, pr, V, C, op, near) {
   function proj(u, v) { return pr.project(fvVolW(V, C.P0[0] + C.U[0] * u + C.V[0] * v, C.P0[1] + C.U[1] * u + C.V[1] * v, C.P0[2] + C.U[2] * u + C.V[2] * v), near); }
   function quad(u0, v0, u1, v1, depth) {
      var Q = [proj(u0, v0), proj(u1, v0), proj(u1, v1), proj(u0, v1)], ok = Q[0] && Q[1] && Q[2] && Q[3], k;
      if (!ok) {
         if (!FV_VOL_PAINT.IN_V3 || depth > FV_VOL_PAINT.TILE_DEPTH) return false;
         if (depth === FV_VOL_PAINT.TILE_DEPTH || (u1 - u0) < 2 * FV_VOL_PAINT.TILE_MIN || (v1 - v0) < 2 * FV_VOL_PAINT.TILE_MIN) return leaf(u0, v0, u1, v1);
         var um = Math.floor((u0 + u1) / 2), vm = Math.floor((v0 + v1) / 2), any = false;
         if (quad(u0, v0, um, vm, depth + 1)) any = true; if (quad(um, v0, u1, vm, depth + 1)) any = true;
         if (quad(u0, vm, um, v1, depth + 1)) any = true; if (quad(um, vm, u1, v1, depth + 1)) any = true;
         return any;
      }
      var q = [[Q[0][0], Q[0][1]], [Q[1][0], Q[1][1]], [Q[2][0], Q[2][1]], [Q[3][0], Q[3][1]]];
      var a1 = 0, b1 = 0, c1 = 0, d1 = 0; for (k = 0; k < 4; ++k) { if (q[k][0] < 0) ++a1; if (q[k][0] > pr.W) ++b1; if (q[k][1] < 0) ++c1; if (q[k][1] > pr.H) ++d1; }
      if (a1 === 4 || b1 === 4 || c1 === 4 || d1 === 4) return false;
      var bw = u1 - u0, bh = v1 - v0, Hm = fvHomography([[0, 0], [bw, 0], [bw, bh], [0, bh]], q);
      if (!Hm) return false;
      if (Math.abs(Hm[6]) * bw + Math.abs(Hm[7]) * bh < 1e-3) Hm = [(q[1][0] - q[0][0]) / bw, (q[3][0] - q[0][0]) / bh, q[0][0], (q[1][1] - q[0][1]) / bw, (q[3][1] - q[0][1]) / bh, q[0][1], 0, 0, 1];
      g.opacity = op;
      g.transformationMatrix = new Matrix(Hm[0], Hm[1], Hm[2], Hm[3], Hm[4], Hm[5], Hm[6], Hm[7], Hm[8]);
      if (u0 === 0 && v0 === 0 && u1 === C.bw && v1 === C.bh) g.drawBitmap(0, 0, C.bmp); else g.drawBitmapRect(0, 0, C.bmp, u0, v0, u1, v1);
      g.resetTransformation();
      return true;
   }
   // (V3, hallazgo H-3 de Codex) una tesela hoja que aun cruza el plano cercano no se tira entera: la profundidad es afin en (u, v), asi que el
   // trozo [ua, ub] × [v0, v1] (o [u0, u1] × [va, vb]) con las cuatro esquinas delante esta entero delante; se pinta el mayor de los dos.
   function zc(u, v) { var P = fvVolW(V, C.P0[0] + C.U[0] * u + C.V[0] * v, C.P0[1] + C.U[1] * u + C.V[1] * v, C.P0[2] + C.U[2] * u + C.V[2] * v); return fvDot(fvSub(P, pr.pos), pr.fw); }
   function span(za, zb, lo, hi) {   // intervalo de t ∈ [lo, hi] con z(t) > near (z lineal de za en lo a zb en hi)
      var n = near * 1.001 + 1e-9;
      if (za > n && zb > n) return [lo, hi];
      if (za <= n && zb <= n) return null;
      var t = lo + (hi - lo) * (n - za) / (zb - za);
      return za > n ? [lo, Math.floor(t)] : [Math.ceil(t), hi];
   }
   function inter(A, B) { if (!A || !B) return null; var a0 = Math.max(A[0], B[0]), a1 = Math.min(A[1], B[1]); return a1 > a0 ? [a0, a1] : null; }
   function leaf(u0, v0, u1, v1) {
      var z00 = zc(u0, v0), z10 = zc(u1, v0), z11 = zc(u1, v1), z01 = zc(u0, v1);
      var Uu = inter(span(z00, z10, u0, u1), span(z01, z11, u0, u1)), Vv = inter(span(z00, z01, v0, v1), span(z10, z11, v0, v1));
      var aU = Uu ? (Uu[1] - Uu[0]) * (v1 - v0) : 0, aV = Vv ? (u1 - u0) * (Vv[1] - Vv[0]) : 0;
      if (aU <= 0 && aV <= 0) return false;
      return aU >= aV ? quad(Uu[0], v0, Uu[1], v1, FV_VOL_PAINT.TILE_DEPTH + 1) : quad(u0, Vv[0], u1, Vv[1], FV_VOL_PAINT.TILE_DEPTH + 1);
   }
   return quad(0, 0, C.bw, C.bh, 0);
}
// el proyector reducido ×k y desplazado (el del lienzo propio)
// (V3, H-2) la tabla del hombro segun lo que la vista se aparta de la de la Tierra: θ = angulo entre (Tierra -> objeto) y (camara -> objeto);
// fuerza s = suave(θ / SH_ANG): desde la Tierra lineal exacto (el frente es la foto, sin comprimir lo brillante); al girar alrededor del objeto,
// donde las sumas pueden pasar de 255, el hombro de la fase 2. SH_ANG 0 = siempre el hombro (ROJO: la fase 2).
function fvVolLutAt(V, cam) {
   if (!(V.m.head > 1)) return null;
   var A = FV_VOL_PAINT.SH_ANG, s = 1;
   if (A > 0) {
      var e = fvNorm(V.fr.center), c = fvNorm(fvSub(V.fr.center, cam)), th = Math.acos(Math.max(-1, Math.min(1, fvDot(e, c)))) * 180 / Math.PI, t = Math.min(1, th / A);
      s = t * t * (3 - 2 * t);
   }
   var key = Math.round(16 * s);
   if (!V._luts) V._luts = {};
   if (!V._luts[key]) V._luts[key] = fvVolShoulderLut(V.m.head, key / 16);
   return V._luts[key];
}
function fvVolPrScaled(pr, k, bx0, by0, ow, oh) {
   var px = pr.pos, f = pr.f / k, cx = (pr.cx - bx0) / k, cy = (pr.cy - by0) / k, r = pr.r, d = pr.d, fw = pr.fw;
   return { pos: px, f: f, cx: cx, cy: cy, W: ow, H: oh, r: r, d: d, fw: fw, project: function(p, near) { var vx = p[0] - px[0], vy = p[1] - px[1], vz = p[2] - px[2], zc = vx * fw[0] + vy * fw[1] + vz * fw[2]; if (!(zc > (near || 1e-9))) return null; return [cx + f * (vx * r[0] + vy * r[1] + vz * r[2]) / zc, cy + f * (vx * d[0] + vy * d[1] + vz * d[2]) / zc, zc]; } };
}
// UN OBJETO: lienzo propio (vecino mas proximo, sumas exactas) -> hombro si HEAD > 1 -> a la pantalla, suave, en Add con opacidad op0.
// Si alguna esquina de la caja cae detras de la camara (dentro del objeto) o el lienzo seria enorme: el pintor directo.
function fvVolPaintObject(painter, g, pr, P, sc, o, op0) {
   var V = o._vol, m = V.m, D = m.D, cam = P.cam.pos, bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9, Bx = V.box, xs = Bx ? [Bx[0], Bx[1]] : [0, m.w], ys = Bx ? [Bx[2], Bx[3]] : [0, m.h], zs = Bx ? [Bx[4], Bx[5]] : [-D / 2, D / 2], n = 0, direct = false;
   for (var a = 0; a < 2 && !direct; ++a) for (var b = 0; b < 2 && !direct; ++b) for (var c = 0; c < 2; ++c) { var p = pr.project(fvVolW(V, xs[a], ys[b], zs[c]), 1e-9); if (!p) { direct = true; break; } bx0 = Math.min(bx0, p[0]); bx1 = Math.max(bx1, p[0]); by0 = Math.min(by0, p[1]); by1 = Math.max(by1, p[1]); }
   var tm = V.texMin || 1, k, ow, oh, inside = direct;
   if (!direct) {
      bx0 = Math.max(0, Math.floor(bx0) - 2); by0 = Math.max(0, Math.floor(by0) - 2); bx1 = Math.min(pr.W, Math.ceil(bx1) + 2); by1 = Math.min(pr.H, Math.ceil(by1) + 2);
      if (bx1 <= bx0 || by1 <= by0) return 0;
      var dist = fvDot(fvSub(V.fr.center, pr.pos), pr.fw);
      k = Math.max(1, pr.f * V.fr.s * tm / Math.max(1e-12, dist)); ow = Math.ceil((bx1 - bx0) / k) + 2; oh = Math.ceil((by1 - by0) / k) + 2;   // (V3) 1 texel por pixel del lienzo (texeles del disco de 1/ds px)
      if (ow * oh > FV_VOL_PAINT.OFF_MAX) direct = true;
   }
   if (direct && FV_VOL_PAINT.IN_V3) {
      // (V3) DENTRO: el lienzo propio a pantalla completa, a 1 texel por pixel en el centro del objeto (× IN_K); los cortes que cruzan el plano de
      // la camara van por teselas (fvVolDrawCut). Mismo hombro y misma ampliacion suave que fuera: sin HEAD pasadas ni paso bajo.
      var distI = Math.max(1e-12, fvLen(fvSub(V.fr.center, cam)));
      k = Math.max(1, FV_VOL_PAINT.IN_K * pr.f * V.fr.s * tm / distI); bx0 = 0; by0 = 0; ow = Math.ceil(pr.W / k) + 2; oh = Math.ceil(pr.H / k) + 2; direct = false;
   }
   if (direct) {
      // DENTRO del objeto (una esquina de la caja detras de la camara): pintor directo en un lienzo de pantalla y PASO BAJO de la escala del texel.
      // Sin el paso bajo, cada texel ampliado ×10–20 enseñaba su difusion de ±1 nivel por corte y salia una REJILLA (fv_V2_probe, NGC 2392 dentro,
      // 5-nov). Los cortes van a 1/HEAD: se pintan HEAD veces (Add; satura en 255 como el pintor de hoy).
      var full = new Bitmap(pr.W, pr.H, BitmapFormat.RGB32); full.fill(0xff000000);
      var gF = new Graphics(full);
      try { for (var rr = 0; rr < (V.m.head || 1); ++rr) n += fvVolPaintStacks(gF, pr, V, cam, 1, null, false); } finally { gF.end(); }
      var distC = Math.max(1e-12, fvLen(fvSub(V.fr.center, cam))), tex = pr.f * V.fr.s / distC, kb = Math.max(1, Math.min(FV_VOL_PAINT.LP_MAX, Math.round(tex / 2)));
      if (kb > 1) full = full.scaledTo(Math.max(2, Math.round(pr.W / kb)), Math.max(2, Math.round(pr.H / kb))).scaledTo(pr.W, pr.H);
      var keepS0 = g.smoothInterpolation; g.compositionOperator = CompositionOp_Add; g.opacity = Math.min(1, op0); g.drawBitmap(0, 0, full); g.opacity = 1; g.smoothInterpolation = keepS0;
      V.lastLp = kb; painter.stats.objPlanes += n; return n;
   }
   var off = new Bitmap(ow, oh, BitmapFormat.RGB32); off.fill(0xff000000);
   var g2 = new Graphics(off);
   try { n = fvVolPaintStacks(g2, fvVolPrScaled(pr, k, bx0, by0, ow, oh), V, cam, 1, null, true); } finally { g2.end(); }
   var LT = fvVolLutAt(V, cam);
   if (LT) {   // el hombro: el lienzo guarda brillo/HEAD (graduado con el angulo de la vista, H-2)
      var lut = LT.lut, q = new Uint32Array(off.pixelData()).slice();
      for (var i = 0; i < q.length; ++i) { var v = q[i]; if ((v & 0xffffff) === 0) continue; q[i] = (0xff000000 | (lut[(v >>> 16) & 255] << 16) | (lut[(v >>> 8) & 255] << 8) | lut[v & 255]) >>> 0; }
      new Uint32Array(off.pixelData()).set(q);
   }
   var keepS = g.smoothInterpolation;
   g.compositionOperator = CompositionOp_Add; g.smoothInterpolation = true; g.opacity = Math.min(1, op0);
   g.transformationMatrix = new Matrix(k, 0, bx0, 0, k, by0, 0, 0, 1); g.drawBitmap(0, 0, off); g.resetTransformation(); g.opacity = 1; g.smoothInterpolation = keepS;
   V.lastOff = { k: k, ow: ow, oh: oh, inside: inside };
   painter.stats.objPlanes += n;
   return n;
}

// ---------------------------------------------------------------------------
// NEBULOSA EXTENSA. (build) N._vol = { Ke, w0, dw, L: [geometria de cada corte de emision], Ld: [del polvo], emit: [Bitmap], dust: [Bitmap|null], stats }
// slLay = la foto sin estrellas y SIN los objetos (Uint32 bw·bh), la de las capas.
// ---------------------------------------------------------------------------
function fvVolMakeSlab(scene, slLay, bw, bh) {
   var t0 = Date.now(), N = scene.nebula, f = scene.field;
   var tmp = new Bitmap(bw, bh, BitmapFormat.RGB32); new Uint32Array(tmp.pixelData()).set(slLay);
   var rw = FW_RELIEF.NX, rh = Math.max(8, Math.round(rw * bh / bw)), sm = new Uint32Array(tmp.scaledTo(rw, rh).pixelData()).slice(), rgba = new Uint8Array(4 * rw * rh);
   for (var i = 0; i < rw * rh; ++i) { var p = sm[i]; rgba[4 * i] = (p >>> 16) & 255; rgba[4 * i + 1] = (p >>> 8) & 255; rgba[4 * i + 2] = p & 255; rgba[4 * i + 3] = 255; }
   var rel = fvVolSlabEnvelope(fwReliefBuild(rgba, rw, rh), rgba), tRel = Date.now() - t0;
   var sl = fvVolSlabSlices(slLay, bw, bh, rel, { KB: fvVolSlabKB(FW_RELIEF), SHEETS: FW_RELIEF.SHEETS, edgeFrac: FV_BUILD.EDGE, seed: 911 });
   var d0 = N.distLy, th = N.thickLy, V = { Ke: sl.Ke, w0: sl.w0, dw: sl.dw, L: [], Ld: [], emit: [], dust: [], stats: sl.stats, msRelief: tRel };
   for (var k = 0; k < sl.Ke; ++k) {
      var w = sl.w0 + (k + 0.5) * sl.dw, z = d0 - th / 2 + th * w, zd = z - FV_VOL_PAINT.DUST_EPS * sl.dw * th;
      V.L.push({ z: z, band: k, x0: (-f.width / 2) / f.F * z, y0: (-f.height / 2) / f.F * z, x1: (f.width / 2) / f.F * z, y1: (f.height / 2) / f.F * z });
      V.Ld.push({ z: zd, band: k, x0: (-f.width / 2) / f.F * zd, y0: (-f.height / 2) / f.F * zd, x1: (f.width / 2) / f.F * zd, y1: (f.height / 2) / f.F * zd });
      V.emit.push(fvVolBmpOf(sl.emit[k], bw, bh)); sl.emit[k] = null;
      V.dust.push(sl.dust[k] ? fvVolBmpOf(sl.dust[k], sl.dsw, sl.dsh) : null); sl.dust[k] = null;
   }
   V.ms = Date.now() - t0;
   V.mb = (sl.Ke * bw * bh * 4 + sl.stats.dustSlices * sl.dsw * sl.dsh * 4) / 1048576;
   try { Object.defineProperty(N, "_vol", { value: V, enumerable: false, writable: true, configurable: true }); } catch (e) { N._vol = V; }
   N.volume3 = { model: "slab: envelope body + 3 sheets + dust (fw_relief.js maps)", Ke: sl.Ke, w: [+sl.w0.toFixed(4), +(sl.w0 + sl.Ke * sl.dw).toFixed(4)], dustSlices: sl.stats.dustSlices, dustPix: sl.stats.dustPix, ms: V.ms, mb: Math.round(V.mb) };
   return V;
}
// los cortes de la nebulosa, de LEJOS A CERCA (por la distancia a lo largo de la normal de la losa), emision en Add y polvo en Multiply.
// opL = la opacidad de las capas de paintLayers (fundido desde la foto, de canto, en el salto). -> cortes dibujados
function fvVolPaintSlab(painter, g, pr, P, N, opL) {
   var V = N._vol, cam = P.cam.pos, T = painter.tiltOf(), list = [], k, n = 0, spacing = Math.max(1e-9, FV_VOL_PAINT.SLAB_NEAR * V.dw * N.thickLy);
   for (k = 0; k < V.Ke; ++k) {
      list.push({ L: V.L[k], bm: V.emit[k], mul: false, d: Math.abs(painter.planeDist(V.L[k], cam, T)) });
      if (V.dust[k]) list.push({ L: V.Ld[k], bm: V.dust[k], mul: true, d: Math.abs(painter.planeDist(V.Ld[k], cam, T)) });
   }
   list.sort(function(a, b) { return b.d - a.d; });
   var keep = g.compositionOperator;
   for (k = 0; k < list.length; ++k) {
      var it = list[k];
      g.compositionOperator = it.mul ? CompositionOp_Multiply : CompositionOp_Add;
      if (painter.drawPlane(g, pr, P, it.bm, it.L, opL, spacing)) { ++n; if (!it.mul) ++painter.stats.layers; }
   }
   g.compositionOperator = keep; g.opacity = 1;
   painter.stats.volSlices = n;
   return n;
}
