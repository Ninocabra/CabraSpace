// ============================================================================
// FieldVoyager/src/ui/fv_cockpit.js — LA FRANJA DE INSTRUMENTOS DE LA CABINA (3-nov-2026, F1)
// ----------------------------------------------------------------------------
// Traduccion al pintor PJSR de la maqueta §10 de docs/vuelo-3d-analisis.html (viewBox 960 × 560; franja de y = 447 a 560),
// a la escala k = ancho/960: VELOCITAS, DISTANTIA y CHRONOMETRUM (reloj de bolsillo del XIX: bisel estriado de laton, esfera de
// esmalte crema, aro de capitulos doble, numeros romanos, agujas Breguet pavonadas, cristal con reflejo, corona), la placa del
// fabricante remachada, el REGULATOR (cuadrante con muescas y palanca) y la RADIOPHONIA (disco numerado bajo un indice fijo,
// mando moleteado, lampara): en F1 la radio esta solo dibujada, sin sonido.
// Lo fijo se pinta UNA vez en un Bitmap; cada fotograma solo pone agujas, lecturas, palanca y cristal.
// Los relojes leen el piloto (F2, con sentido fisico en todos los modos; ver fvPilotGauges): VELOCITAS en años luz por segundo,
// DISTANTIA a la Tierra («a Terra»), CHRONOMETRUM el reloj de a bordo, REGULATOR la potencia.
// F2: el conmutador MODUS (CINE / WARP: el estilo de camara), la pestaña de idioma EN · ES bajo la placa, la radio sintonizada en
// «Awesome Mix» (lampara encendida; sin sonido todavia) y la cabina APAGADA hasta el encendido (gz.power 0…1).
// ES5.
// ============================================================================

var FV_CK = { brass0: 0xffE9C97A, brass1: 0xff9C7325, brass2: 0xffC99A3A, brass3: 0xff5E4214, dark: 0xff3B2A0C, ink: 0xff2A1F15, sepia: 0xff5E4214,
              enamel0: 0xffF4EAD2, enamel1: 0xffE2D2AE, enamel2: 0xffB9A57C, blued0: 0xff1B2C55, blued1: 0xff3A5AA0, bg: 0xff110D09, line: 0xff3D2E1F, gold: 0xffE5B53F, verm: 0xffE0603F, text: 0xffFBF2E0 };

function fvPol(r, deg) { var a = deg * Math.PI / 180; return [Math.sin(a) * r, -Math.cos(a) * r]; }
function fvBrassBrush(cx, cy, r) { return new LinearGradientBrush(new Point(cx - r, cy - r), new Point(cx + r, cy + r), [[0, FV_CK.brass0], [0.35, FV_CK.brass1], [0.6, FV_CK.brass2], [1, FV_CK.brass3]]); }
function fvCrownBrush(cx, cy, r) { return new RadialGradientBrush(new Point(cx - 0.12 * r, cy - 0.18 * r), r * 1.5, new Point(cx - 0.12 * r, cy - 0.18 * r), [[0, 0xffF3D27E], [0.55, FV_CK.brass1], [1, FV_CK.dark]]); }

// (pasada N, N7) la franja es una rejilla de 1440 × 156 unidades escalada con k = ancho/1440 (todo proporcional al ancho de la foto):
// a la izquierda TABULA y PROFUNDITAS (fv_nav.js), en el medio REC, los tres relojes, la placa con EN · ES, REGULATOR, la radio y
// MODUS, y a la derecha MIRABILIA. H = 156·k (el dialogo la crea asi). aspect = el de la foto (para la miniatura).
// (E9, Nino 4-nov: «el indicador de VELOCITAS: haz más claro dónde está la velocidad de la luz») la esfera lleva la LUZ marcada sin duda:
// en −60° (1 c) un filete bermellon que cruza el aro de capitulos y la cifra «c» en bermellon (antes un «1» en tinta, y la unica marca
// roja era la del warp 9,975, arriba: se leia como si la luz estuviera ahi); el tramo SUPERLUMINICO (de c a 10¹² c) va en el aro con una
// banda bermellon muy tenue y el subluminico limpio; la marca del warp pasa a azul pavonado. La lectura sale en tinta por debajo de c y en
// bermellon por encima. FV_E9_CMARK = false: la esfera de antes (el ROJO de fv_nE2_test).
var FV_E9_CMARK = true;
var FV_H8_UNITS = true;           // (Blender 5 · H8) DISTANTIA lee «ly» con el ingles puesto (antes «a.l.» fijo); false = lo de antes
var FV_E9_COL = { lux: 0xffB0301E, band: 0x2CB0301E, sub: 0xff2A1F15 };
// (9-nov, N8) con el laboratorio de vuelo (FV_LAB.ON) la aguja de VELOCITAS da la velocidad VISTA (la del espacio de vuelo, que puede estirarse:
// fv_flightlab.js SPEED_SHOW_S), no la fisica, y la esfera marcaba «c» como si lo fuera. Una plaquita de laton grabada bajo el pivote lo dice
// (VISTA / SEEN) y el tooltip lo explica (tipck.gVseen). El dialogo da gz.seen = laboratorio encendido. false = la esfera de hoy (ROJO).
var FV_N8_SEEN = true;
// (I4, Nino 4-nov: «máquina del tiempo, al lado de CHRONOMETRUM») el mando AETAS: placa de laton con ranura vertical y palanca deslizante
// (arriba + = futuro, abajo − = pasado, muesca dorada = hoy), la lectura del año debajo (clic = volver a hoy) y el rotulo AETAS a la altura
// del de los relojes. Para hacerle sitio la placa del fabricante (y EN · ES y Nº XLII, que cuelgan de ella) se corre 22 unidades a la
// derecha (medido en fv_nI4_test L1: con 32 quedaba 1 px hasta LENTO; con 22, ~9 px). El motor es src/engine/fv_time.js. FV_I4_AETAS = false: la cabina de antes (el ROJO de fv_nI4_test).
var FV_I4_AETAS = true;
var FV_CHRONO_AETAS = true;      // (5-nov) CHRONOMETRUM cuenta los años de AETAS (false = ROJO de fv_chrono_aetas_test)
var FV_CHRONO_OBJ = true;        // (5-nov, C-1) CHRONOMETRUM = año en que salio del objeto la luz que ves, como el navegador (false = ROJO)
var FV_I4 = { X: 763, DX: 22, HW: 12, HH: 34, TRAVEL: 17 };
// (I3, 19-nov-2026, Nino: «El botón que hace mover las estrellas para delante y para atrás debe estar más visible y tiene que tener al lado una
// flecha play para arriba y otra play para abajo que recorra hacia el futuro y hacia el pasado de forma automática y visualmente agradable»)
// EL MANDO DEL TIEMPO VISIBLE: (a) a la derecha de la ranura, dos botones redondos de laton —▲ reproduce hacia el futuro, ▼ hacia el pasado—
// que se encienden en oro y cambian a «pausa» mientras corren y se apagan en el tope; (b) la ranura se llena de oro entre «hoy» y la palanca
// (se ve de lejos donde esta el tiempo) y la palanca lleva su filo de luz siempre que no es hoy; (c) la lectura crece (6,4 -> 7) y se centra
// en el conjunto. La ranura se corre 7 unidades a la izquierda (AX) para hacer sitio: de 13 a 6 unidades hasta CHRONOMETRUM y 4 entre la ranura,
// los botones y la placa de la cruceta (medido por pixeles: tests/_e1t/fv_E1T_layout.js). El motor de la reproduccion es fvTplay* (src/engine/
// fv_time.js); el dialogo solo llama a cockpit.aetasTick(scene, dt) en su reloj. Las estelas y la placa del año: src/ui/fv_trails.js.
// FV_E1T = false: la cabina y la escena de antes (sin botones, sin estelas, sin placa).
var FV_E1T = true;
var FV_E1TG = { AX: 756, KX: 781, KR: 9, KY: 17, RX: 763, READ_PX: 7, READ_HW: 27, FR: 5.8 };      // (F2) FR: el radio del boton SOL | GALAXIA, entre ▲ y ▼ (16 unidades libres entre los dos botones: 11,6 de boton y 2,2 de aire a cada lado)
// (5-nov, Nino: «elimina el letrero de Field Voyager y añade en su lugar 4 flechas: cambian la visualización, moviendo la vista arriba, abajo,
// izquierda y derecha; si tiramos hacia delante esa es la dirección de movimiento») LA CRUCETA: en el hueco de la placa del fabricante, cuatro
// teclas de laton grabado con su flecha (y un cubo de brujula en el centro). Giran la MIRADA sin avanzar (clic = un paso, mantener = giro
// continuo; src/engine/fv_pilot.js fvPilotLookPad: las mismas teclas de giro del vuelo libre); avanzar despues va hacia donde se mira. La
// flecha se apaga (tenue) cuando la pared de la foto ya no deja girar a ese lado (A_GUARD) y se ilumina mientras gira. La placa se estrecha
// (de ±70 a ±54: sin rotulo sobraba) y pierde «FIELDVOYAGER» y «CabraSpace & C.ia · Anno MMXXVI»; «Nº XLII» y EN · ES se quedan.
// FV_PAD.ON = false: la placa de antes con su rotulo (el ROJO de fv_nI4_test y fv_pad_test).
var FV_PAD = { ON: true, HW: 54, K: { padUp: [-7, -16, 7, -8], padDown: [-7, 8, 7, 16], padLeft: [-32, -4.5, -18, 4.5], padRight: [18, -4.5, 32, 4.5] }, HUB: 5.2 };
var FV_PAD_DIR = { padUp: "up", padDown: "down", padLeft: "left", padRight: "right" };
// (6-nov-2026, Nino: «El boton entre las flechas que tenemos en el panel de control debe frenar la nave») EL CUBO DE BRUJULA FRENA (zona
// «padHub», fv_dialog.js brake -> fvPilotBrake del motor): al pulsarlo se hunde y se enciende en oro (como una tecla encendida) mientras dura la
// frenada y al menos HUB_FLASH_S; con el cursor encima, un aro de luz. FV_PAD.BRAKE false = el cubo de antes (adorno, sin zona)
FV_PAD.BRAKE = true; FV_PAD.HUB_FLASH_S = 0.35;
// ---------------------------------------------------------------------------
// (1c, 5-nov, Nino: «mejórala, teniendo en cuenta que podré trabajar con pantallas de distintas resoluciones (ahora una 6K); las mejoras
// sutiles pero realistas; las letras más claras y legibles, mejor que las originales») LA CABINA 3D: las piezas fisicas (biseles, esmaltes,
// placas, teclas, palancas, pomos, cristales) son sprites renderizados en Blender (blender/cabina3d_v3.py -> blender/build_cabina_rsc.py ->
// rsc/cabina/), en tres NIVELES (1,2 / 2,0 / 3,0 px por unidad de rejilla); se usa el inmediatamente superior a k (la franja mide k = ancho/1440:
// 0,82 en 1920 × 1080, 1,10 en 2560 × 1440, 1,67 en 4K, 2,6–2,96 en 6K) y se reduce UNA vez por promedio de area (Bitmap.scaledTo; medido:
// drawScaledBitmap muestrea bilineal y a 0,4 deja un tablero de 1 px en 19–236), cacheado hasta que cambia k. La TINTA (cifras, graduaciones,
// rotulos, lecturas) la sigue pintando Qt encima, mas legible: tinta mas oscura, cuerpo minimo FV_CK3D_INK.MIN px, negrita por debajo de
// BOLD_BELOW px y el espaciado recortado para que el rotulo no crezca; los rotulos de laton llevan un filo de sombra de 1 px abajo-derecha
// (la luz del render viene de arriba-izquierda). La chapa la pinta el script (FV_CK.bg, la de hoy) y las sombras de cada sprite caen sobre ella.
// Si faltan los recursos, la cabina dibujada de siempre (y fvLog lo dice). FV_CK3D = false: la cabina dibujada, pixel identica (fv_ck3d_test).
var FV_CK3D = true;              // (5-nov, Nino: «Sí, enciéndela») la cabina de Blender por defecto
var FV_CK3D_INK = { ink: 0xff17100A, sepia: 0xff4A3410, lux: 0xff9C2716, MIN: 7, BOLD_BELOW: 9.5, CAP_A: 0.66, SHADOW: 0x9A000000 };
var FV_CK3D_ROOT = (function() { try { return (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/").replace(/\/src\/ui\/?$/, ""); } catch (e) { return ""; } })();
var FV_CK3D_STORE = { man: null, tried: false, err: "", bmp: {}, sets: {} };
function fvCk3dLog(s) { try { if (typeof fvLog === "function") fvLog("[ck3d] " + s); } catch (e) {} }
// el manifiesto (una vez por sesion) -> true si hay recursos
function fvCk3dReady() {
   var S = FV_CK3D_STORE;
   if (!S.tried) {
      S.tried = true;
      try {
         var p = FV_CK3D_ROOT + "/rsc/cabina/manifest.json";
         if (!File.exists(p)) throw new Error("missing " + p);
         S.man = JSON.parse(File.readTextFile(p));
         if (!S.man || !S.man.levels) throw new Error("bad manifest");
      } catch (e) { S.man = null; S.err = String(e); fvCk3dLog("cockpit sprites not available, drawn cockpit instead: " + S.err); }
   }
   return !!S.man;
}
// el nivel para una k: el de menor escala >= k (si ninguno llega, el mayor) -> clave ("1.2", "2.0", "3.0")
function fvCk3dLevel(k) {
   var lv = FV_CK3D_STORE.man.levels, best = null, top = null;
   for (var key in lv) {
      var s = lv[key].scale;
      if (top === null || s > lv[top].scale) top = key;
      if (s >= k - 1e-6 && (best === null || s < lv[best].scale)) best = key;
   }
   return best !== null ? best : top;
}
function fvCk3dBitmap(lvKey, name) {
   var S = FV_CK3D_STORE, id = lvKey + "/" + name;
   if (S.bmp[id] !== undefined) return S.bmp[id];
   var L = S.man.levels[lvKey], sp = L.sprites[name], b = null;
   if (sp) { try { var p = FV_CK3D_ROOT + "/rsc/cabina/" + L.dir + "/" + sp.file; if (File.exists(p)) b = new Bitmap(p); else fvCk3dLog("missing " + p); } catch (e) { fvCk3dLog("cannot read " + name + ": " + e); } }
   S.bmp[id] = b;
   return b;
}
// el juego de sprites a la k de una franja: { lv, s, f, sp: { nombre: { b, ax, ay } } } (se reduce cada sprite al pedirlo, una vez)
function fvCk3dSet(k) {
   var S = FV_CK3D_STORE, key = k.toFixed(5);
   if (S.sets[key]) return S.sets[key];
   var names = []; for (var n in S.sets) names.push(n);
   if (names.length >= 2) delete S.sets[names[0]];                 // k solo cambia al redimensionar: con dos basta (el dialogo y el video)
   var lv = fvCk3dLevel(k), s = S.man.levels[lv].scale;
   return (S.sets[key] = { lv: lv, s: s, f: k / s, sp: {} });
}
function fvCk3dSprite(set, name) {
   if (set.sp[name] !== undefined) return set.sp[name];
   var L = FV_CK3D_STORE.man.levels[set.lv], m = L.sprites[name], b = m ? fvCk3dBitmap(set.lv, name) : null, r = null;
   if (b) {
      var w = Math.max(1, Math.round(b.width * set.f)), h = Math.max(1, Math.round(b.height * set.f));
      var sb = (w === b.width && h === b.height) ? b : b.scaledTo(w, h);
      r = { b: sb, ax: m.anchor_px[0] * w / b.width, ay: m.anchor_px[1] * h / b.height, gx: m.anchor_grid[0], gy: m.anchor_grid[1] };
   }
   set.sp[name] = r;
   return r;
}
function FVCockpit(W, H, aspect) {
   this.W = W; this.H = H; this.k = W / FV_NAV.GRID_W; this.aspect = aspect || 1.5;
   var k = this.k, cy = 70 * k;
   this.g = [
      // (F4b, revision del 4-nov) VELOCITAS en VECES LA LUZ: 0 parado de verdad, lineal de 0 a 1 c y logaritmica de 1 a 10¹² c; la marca roja W
      // es warp 9,975 (5 160 c, la de la ficha): el viaje va comprimido en el tiempo y la aguja dice cuanto (≈ 10¹⁰ c en un warp)
      { id: "V", x: 505 * k, y: cy, r: 38 * k, a0: -120, a1: 120, labels: ["0", FV_E9_CMARK ? "c" : "1", "10⁴", "10⁸", "10¹²"], minor: 48, title: "× c", caption: "VELOCITAS" },
      { id: "D", x: 600 * k, y: cy, r: 38 * k, a0: -120, a1: 120, labels: ["I", "X", "C", "M", "X̅"], minor: 40, title: "a Terra", caption: "DISTANTIA" },
      // (F4b) CHRONOMETRUM: el año en que salio la luz de la Tierra que se ve desde la nave (2026 − distancia en años luz): corre hacia
      // atras al alejarse. Horaria = una vuelta cada 12 000 años (cada cifra, 1 000); minutero = una vuelta cada 1 000; segundero = 100
      { id: "T", x: 695 * k, y: cy, r: 38 * k, a0: 0, a1: 360, full: true, labels: ["XII", "I", "II", "III", "IIII", "V", "", "VII", "VIII", "IX", "X", "XI"], minor: 60, sub: true, crown: true, caption: "CHRONOMETRUM" }
   ];
   this.plate = { x: (828 + (FV_I4_AETAS ? FV_I4.DX : 0)) * k, y: cy - 4 * k, hw: FV_PAD.ON ? FV_PAD.HW : 70 };
   this.aetas = FV_I4_AETAS ? { x: FV_I4.X * k, y: cy - 4 * k } : null;            // (I4) el mando AETAS
   // (I3) con el mando visible: la ranura corrida (AX), el centro del conjunto para la lectura y el rotulo (rx) y la columna de los botones (kx)
   this.e1t = !!(this.aetas && typeof FV_E1T !== "undefined" && FV_E1T === true && typeof fvTplayNew === "function");
   if (this.aetas) { if (this.e1t) { this.aetas.x = FV_E1TG.AX * k; this.aetas.rx = FV_E1TG.RX * k; this.aetas.kx = FV_E1TG.KX * k; } else this.aetas.rx = this.aetas.x; }
   this.tplay = this.e1t ? fvTplayNew() : null;
   this.aetasYears = 0; this.aetasDrag = false; this.aetasOk = true;
   this.reg = { x: 990 * k, y: cy + 25 * k };
   this.radio = { x: 1112 * k, y: cy - 6 * k, hw: 54 * k, hh: 50 * k };      // la caja donde va el WebView de la radio (RADIOPHONIA)
   this.modus = { x: 1200 * k, y: cy - 4 * k };
   this.lang = { x: this.plate.x - 70 * k, y: cy + 33 * k };                  // (lang.x + 70·k = centro de EN · ES, como en F2)
   // (F4b) REC: a la izquierda de los relojes (boton de laton con piloto rojo, y debajo el formato AVI · MP4 y «con cabina»)
   this.rec = { x: 425 * k, y: cy - 12 * k };
   // (N1) los paneles de navegacion, en pixeles
   var ng = fvNavGeom(this.aspect);
   function px(r) { return [r[0] * k, r[1] * k, r[2] * k, r[3] * k]; }
   this.map2d = px(ng.map2d); this.map3d = px(ng.map3d); this.list = px(ng.list);
   this.listIn = [this.list[0] + 4 * k, this.list[1] + 4 * k, this.list[2] - 4 * k, this.list[3] - 4 * k];
   this.stat = null; this.hover = null;
   // (1c) la cabina 3D: sprites al nivel de esta k y la tinta mas legible (con FV_CK3D = false, los colores de siempre)
   this.ck3d = (FV_CK3D === true) && fvCk3dReady();
   this.k3 = this.ck3d ? fvCk3dSet(k) : null;
   this.inkC = this.ck3d ? FV_CK3D_INK.ink : FV_CK.ink; this.sepiaC = this.ck3d ? FV_CK3D_INK.sepia : FV_CK.sepia; this.luxC = this.ck3d ? FV_CK3D_INK.lux : FV_E9_COL.lux;
}
FVCockpit.prototype.ck3dInfo = function() { return this.ck3d ? ("3D nivel " + this.k3.lv + " (×" + this.k3.f.toFixed(3) + ")") : ("dibujada" + (FV_CK3D && FV_CK3D_STORE.err ? " (" + FV_CK3D_STORE.err + ")" : "")); };
// (1c) un sprite con su ancla en (x, y) PIXELES de la franja (x, y = ancla en rejilla × k, o la que se pida)
FVCockpit.prototype.sprite = function(g, name, x, y) {
   var s = fvCk3dSprite(this.k3, name); if (!s) return false;
   g.drawBitmap(Math.round(x - s.ax), Math.round(y - s.ay), s.b);
   return true;
};
// (1c) los sprites fijos, compuestos al nivel del render y reducidos UNA vez a la franja (asi encajan entre si al pixel)
FVCockpit.prototype.ck3dStatic = function() {
   var lv = this.k3.lv, L = FV_CK3D_STORE.man.levels[lv], s = L.scale, Wl = Math.round(FV_NAV.GRID_W * s), Hl = Math.round(FV_NAV.GRID_H * s);
   var c = new Bitmap(Wl, Hl, BitmapFormat.ARGB32); c.fill(0x00000000);
   var g = new Graphics(c), self = this;
   function put(name, du, dv) {
      var m = L.sprites[name], b = m ? fvCk3dBitmap(lv, name) : null; if (!b) return;
      g.drawBitmap(Math.round((m.anchor_grid[0] + (du || 0)) * s - m.anchor_px[0]), Math.round((m.anchor_grid[1] + (dv || 0)) * s - m.anchor_px[1]), b);
   }
   try {
      put("bead");
      put("dial_face"); put("dial_face", this.g[1].x / this.k - this.g[0].x / this.k, 0); put("dial_face_T");
      // (la placa de AETAS la pone aetasFace: asi es suya entera, tambien para fv_nI4_test L2)
      put("pad_plate"); put("reg_face"); put("radio_face"); put("radio_knob"); put("radio_lamp_off"); if (!fvGwarpUi()) put("modus_plate"); put("rec_face");      // (21-nov, N-galaxias-warp) sin MODUS no hay placa
   } finally { g.end(); }
   return c.scaledTo(this.W, this.H);
};
// (1c) una fuente de TINTA legible: cuerpo minimo, negrita si es pequeña, y (si lleva espaciado) el espaciado recortado lo que crece la letra,
// para que el rotulo no se ensanche (CHRONOMETRUM y AETAS ya estaban al limite: fv_nI4_test L1)
// minPx: cuerpo minimo (por defecto FV_CK3D_INK.MIN; las cifras romanas del CHRONOMETRUM, apretadas, piden 6). La negrita, solo en redonda:
// la cursiva negrita de Georgia ensancha «a Terra» hasta pisar X y M (visto en la primera captura de la 1c)
FVCockpit.prototype.inkFont = function(role, px, italic, spacingEm, minPx) {
   var I = FV_CK3D_INK, size = Math.max(minPx || I.MIN, Math.round(px)), bold = !italic && px < I.BOLD_BELOW;
   var sp0 = spacingEm ? Math.round(px * spacingEm) : 0, grow = (size - Math.max(6, Math.round(px))) + (bold ? 0.08 * size : 0);
   var sp = Math.max(0, Math.round(sp0 - I.CAP_A * grow));
   return cpFont(role, size, bold, !!italic, sp);
};
// (1c) la fuente legible que NO ensancha este texto: si la de tinta queda mas ancha que la de hoy, primero se quita espaciado, luego la negrita y
// por ultimo cuerpo (nunca por debajo del de hoy). Sin la cabina 3D, la de siempre. (CHRONOMETRUM y AETAS se tocaban; «CON CABINA» salia cortado)
FVCockpit.prototype.fitFont = function(role, px, italic, spacingEm, text) {
   if (!this.ck3d) return this.font(role, px, italic, spacingEm);
   var c3 = this.ck3d; this.ck3d = false; var f0 = this.font(role, px, italic, spacingEm); this.ck3d = c3;
   var w0 = f0.width(text), I = FV_CK3D_INK, size = Math.max(I.MIN, Math.round(px)), bold = !italic && px < I.BOLD_BELOW, sp = spacingEm ? Math.round(px * spacingEm) : 0;
   var base = Math.max(6, Math.round(px));
   for (var guard = 0; guard < 40; ++guard) {
      var f = cpFont(role, size, bold, !!italic, sp);
      if (f.width(text) <= w0 + 0.5) return f;
      if (sp > 0) --sp; else if (bold) { bold = false; sp = spacingEm ? Math.round(px * spacingEm) : 0; } else if (size > base) { --size; bold = !italic && px < I.BOLD_BELOW; sp = spacingEm ? Math.round(px * spacingEm) : 0; } else return f0;
   }
   return f0;
};
// las zonas que se pueden tocar o señalar (tooltip y realce): [{ id, x0, y0, x1, y1, act }] (act = se acciona; si no, es indicador)
FVCockpit.prototype.zones = function() {
   if (this._zones) return this._zones;
   var k = this.k, Z = [], r = this.rec, m = this.modus, l = this.lang, R = this.reg, X = this.radio, P = this.plate, i;
   function add(id, x0, y0, x1, y1, act) { Z.push({ id: id, x0: x0, y0: y0, x1: x1, y1: y1, act: act }); }
   add("rec", r.x - 15 * k, r.y - 15 * k, r.x + 15 * k, r.y + 15 * k, true);
   add("recfmt", r.x - 26 * k, r.y + 30 * k, r.x + 26 * k, r.y + 41 * k, true);
   add("reccab", r.x - 26 * k, r.y + 41 * k, r.x + 26 * k, r.y + 64 * k, true);
   if (!fvGwarpUi()) add("modus", m.x - 26 * k, m.y - 40 * k, m.x + 26 * k, m.y + 40 * k, true);      // (21-nov, N-galaxias-warp) FV_GWARP: el modo lo elige el destino, sin selector
   add("lang", l.x + 70 * k - 26 * k, l.y - 9 * k, l.x + 70 * k + 26 * k, l.y + 9 * k, true);
   add("reg", R.x - 60 * k, R.y - 62 * k, R.x + 60 * k, R.y + 8 * k, true);
   add("radioTab", X.x - 40 * k, 136 * k, X.x + 40 * k, 152 * k, true);
   add("radioInfo", X.x - 60 * k, X.y + X.hh, X.x + 60 * k, 136 * k, false);
   for (i = 0; i < 3; ++i) { var o = this.g[i]; add("g" + o.id, o.x - o.r - 5 * k, o.y - o.r - 20 * k, o.x + o.r + 5 * k, o.y + o.r + 22 * k, false); }
   if (FV_PAD.ON) for (var pk in FV_PAD.K) { var kr = FV_PAD.K[pk]; add(pk, P.x + (kr[0] - 1) * k, P.y + (kr[1] - 1) * k, P.x + (kr[2] + 1) * k, P.y + (kr[3] + 1) * k, true); }     // (5-nov) la cruceta
   if (FV_PAD.ON && FV_PAD.BRAKE) add("padHub", P.x - (FV_PAD.HUB + 1.2) * k, P.y - (FV_PAD.HUB + 1.2) * k, P.x + (FV_PAD.HUB + 1.2) * k, P.y + (FV_PAD.HUB + 1.2) * k, true);   // (6-nov) el freno
   add("plate", P.x - P.hw * k, P.y - 24 * k, P.x + P.hw * k, P.y + 24 * k, false);
   if (this.aetas) { var A = this.aetas, rhw = this.e1t ? FV_E1TG.READ_HW : 25; add("aetas", A.x - FV_I4.HW * k, A.y - FV_I4.HH * k, A.x + FV_I4.HW * k, A.y + FV_I4.HH * k, true); add("aetasNow", A.rx - rhw * k, A.y + 40 * k, A.rx + rhw * k, A.y + 51 * k, true);
      // (I3) los dos botones de reproduccion: ▲ futuro (arriba) y ▼ pasado (abajo)
      if (this.e1t) { var kr = (FV_E1TG.KR + 0.5) * k; add("aetasFwd", A.kx - kr, A.y - FV_E1TG.KY * k - kr, A.kx + kr, A.y - FV_E1TG.KY * k + kr, true); add("aetasBack", A.kx - kr, A.y + FV_E1TG.KY * k - kr, A.kx + kr, A.y + FV_E1TG.KY * k + kr, true);
         if (FV_TIME.GAL_ON === true) { var kf = (FV_E1TG.FR + 0.6) * k; add("aetasFrame", A.kx - kf, A.y - kf, A.kx + kf, A.y + kf, true); } } }      // (F2) el interruptor SOL | GALAXIA
   var LK = this.lookGeom(); if (LK) for (i = 0; i < LK.ids.length; ++i) add(LK.ids[i], LK.x[i] - 2 * k, LK.y - 4 * k, LK.x[i] + LK.w[i] + 2 * k, LK.y + 2.5 * k, true);   // (5-nov) STELLAE
   add("map2d", this.map2d[0], this.map2d[1], this.map2d[2], this.map2d[3], true);
   // (pasada M) PROFUNDITAS tambien se acciona: un clic la abre en grande (fv_route.js)
   add("map3d", this.map3d[0], this.map3d[1], this.map3d[2], this.map3d[3], typeof FVRoute === "function");
   this._zones = Z;
   return Z;
};
// (5-nov, Nino: «que las estrellas se vean como Gaia o como están en la imagen, como en los otros scripts») EL ASPECTO DE LAS ESTRELLAS:
// bajo la placa (debajo de EN · ES), tres palabras como las de EN · ES o AVI · MP4 — GAIA · COLOR · FOTO, la puesta en oro — y el rotulo
// STELLAE a la altura de los de los relojes. Un solo camino (§11.5): no hay tecla ni menu que haga lo mismo. FV_PS.ON false = la cabina de antes.
var FV_CK_LOOK_IDS = ["lookGaia", "lookPhcol", "lookPhstar"], FV_CK_LOOK_OF = { lookGaia: "gaia", lookPhcol: "phcol", lookPhstar: "phstar" };
FVCockpit.prototype.lookGeom = function() {
   if (typeof FV_PS === "undefined" || !FV_PS.ON) return null;
   var k = this.k, f = this.font("display", 6.2 * k, false, 0.12), sep = f.width(" · "), words = [fvTx("ck.lookGaia"), fvTx("ck.lookPhcol"), fvTx("ck.lookPhstar")], w = [], tot = 0, i;
   for (i = 0; i < 3; ++i) { w.push(f.width(words[i])); tot += w[i] + (i ? sep : 0); }
   var x = [], x0 = this.plate.x - tot / 2;
   for (i = 0; i < 3; ++i) { x.push(x0); x0 += w[i] + sep; }
   return { ids: FV_CK_LOOK_IDS, words: words, x: x, w: w, sep: sep, y: this.plate.y + 51 * k, capY: this.plate.y + 60 * k, font: f };   // la zona (y − 4·k … y + 2,5·k) no toca la de EN · ES (hasta plate.y + 46·k)
};
FVCockpit.prototype.font = function(role, px, italic, spacingEm, minPx) {
   if (this.ck3d) return this.inkFont(role, px, italic, spacingEm, minPx);   // (1c) la tinta legible
   var f = cpFont(role, Math.max(6, px), false, !!italic, 0);
   if (spacingEm) { try { f = new Font(f); f.letterSpacing = Math.round(px * spacingEm); } catch (e) {} }
   return f;
};
// (1c) ¿color claro (laton u oro sobre la chapa)? -> lleva filo de sombra
function fvCkLight(col) { var r = (col >>> 16) & 255, g = (col >>> 8) & 255, b = col & 255; return (0.299 * r + 0.587 * g + 0.114 * b) > 110; }
FVCockpit.prototype.textC = function(g, x, y, s, f, col) {
   if (this.ck3d) { this.textS(g, x - f.width(s) / 2, y, s, f, col); return; }
   g.font = f; g.pen = new Pen(col); g.drawText(x - f.width(s) / 2, y, s);
};
// (1c) texto alineado a la izquierda; los rotulos claros, con su filo de sombra de 1 px abajo-derecha (luz de arriba-izquierda, como el render)
FVCockpit.prototype.textS = function(g, x, y, s, f, col) {
   g.font = f;
   if (this.ck3d && fvCkLight(col)) { var o = Math.max(1, Math.round(0.55 * this.k)); g.pen = new Pen(FV_CK3D_INK.SHADOW); g.drawText(x + o, y + o, s); }
   g.pen = new Pen(col); g.drawText(x, y, s);
};

// ---- lo fijo ----
FVCockpit.prototype.buildStatic = function() {
   var W = this.W, H = this.H, k = this.k, b = new Bitmap(W, H, BitmapFormat.RGB32);
   b.fill(FV_CK.bg);
   var g = new Graphics(b);
   try {
      g.antialiasing = true; g.textAntialiasing = true;
      if (this.ck3d) g.drawBitmap(0, 0, this.ck3dStatic());                 // (1c) las piezas fisicas; encima, la tinta
      else { g.pen = new Pen(FV_CK.line, 1); g.drawLine(8, 1.5, W - 8, 1.5); }
      for (var i = 0; i < this.g.length; ++i) this.dialFace(g, this.g[i]);
      this.plateFace(g); this.regFace(g); this.radioFace(g); if (!fvGwarpUi()) this.modusFace(g); this.recFace(g);
      if (this.aetas) this.aetasFace(g);
      this.navFaces(g);
   } finally { g.end(); }
   this.stat = b;
};
FVCockpit.prototype.dialFace = function(g, o) {
   var x = o.x, y = o.y, R = o.r, k = this.k, i, p, q, c3 = this.ck3d, ink = this.inkC;
   if (!c3) {                                                                // (1c) con la cabina 3D, corona, bisel y esmalte son el sprite
   if (o.crown) {
      g.fillRect(x - 3 * k, y - R - 12 * k, x + 3 * k, y - R - 5 * k, fvBrassBrush(x, y - R - 9 * k, 4 * k));
      g.fillEllipse(x - 6.5 * k, y - R - 19 * k, x + 6.5 * k, y - R - 11 * k, fvCrownBrush(x, y - R - 15 * k, 6 * k));
      g.pen = new Pen(FV_CK.dark, 0.6); for (i = -5; i <= 5; i += 2) g.drawLine(x + i * k, y - R - 18.5 * k, x + i * k, y - R - 11.5 * k);
   }
   g.fillCircle(x, y, R + 5 * k, fvBrassBrush(x, y, R + 5 * k));
   g.pen = new Pen(FV_CK.brass3, 0.8);
   for (i = 0; i < 90; ++i) { p = fvPol(R + 5 * k, i * 4); q = fvPol(R + 2.5 * k, i * 4); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]); }
   g.pen = new Pen(FV_CK.dark, 1); g.drawCircle(x, y, R + 0.5 * k);
   g.fillCircle(x, y, R, new RadialGradientBrush(new Point(x - 0.1 * R, y - 0.2 * R), 1.4 * R, new Point(x - 0.1 * R, y - 0.2 * R), [[0, FV_CK.enamel0], [0.75, FV_CK.enamel1], [1, FV_CK.enamel2]]));
   }
   // (1c) trazos de tinta con un grosor minimo en pixeles (a k 0,82 el filete menor medía 0,33 px: gris, no tinta)
   g.pen = new Pen(ink, c3 ? Math.max(0.7, 0.55 * k) : 0.5); g.drawCircle(x, y, R - 3 * k); g.drawCircle(x, y, R - 6 * k);
   var n = o.minor, nl = o.labels.length - (o.full ? 0 : 1);
   for (var m = 0; m <= n; ++m) {
      if (o.full && m === n) break;
      var a = o.a0 + (o.a1 - o.a0) * m / n, major = (m % Math.round(n / nl)) === 0;
      p = fvPol(R - 3 * k, a); q = fvPol(R - 6 * k, a);
      g.pen = new Pen(ink, major ? (c3 ? Math.max(1.2, 1.15 * k) : 1.1 * k) : (c3 ? Math.max(0.65, 0.45 * k) : 0.4 * k)); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]);
   }
   var fl = this.font("display", (o.full ? 6.0 : 6.6) * k, false, 0, o.full ? 6 : 0);
   for (i = 0; i < o.labels.length; ++i) {
      var al = o.a0 + (o.a1 - o.a0) * i / nl; p = fvPol(o.full ? R - 12 * k : R - 15 * k, al);
      // la raya de millar (vinculum) del romano se dibuja a mano: el caracter combinante U+0305 sale desplazado en Qt (visto 3-nov)
      var lab = o.labels[i], vin = lab.length > 1 && lab.charCodeAt(lab.length - 1) === 0x0305;
      if (vin) lab = lab.substring(0, lab.length - 1);
      if (!(FV_E9_CMARK && o.id === "V" && i === 1)) this.textC(g, x + p[0], y + p[1] + (o.full ? 2.3 : 3) * k, lab, fl, ink);
      if (vin) { var vw = fl.width(lab) / 2; g.pen = new Pen(ink, c3 ? Math.max(0.9, 0.7 * k) : 0.7 * k); g.drawLine(x + p[0] - vw, y + p[1] - 3.6 * k, x + p[0] + vw, y + p[1] - 3.6 * k); }
   }
   // titulo de las esferas de arco ARRIBA (-0.30 R): abajo chocaba con la ultima cifra (anni lucis contra X con raya, 3-nov)
   if (o.title) this.textC(g, x, y + (o.full ? -R * 0.32 : -R * 0.30), o.title, this.font("display", 6.6 * k, true), this.sepiaC);
   if (o.id === "V") {        // la marca de warp 9,975 (5 160 c)
      var aw = fvSpeedCAngle(5160); p = fvPol(R - 2 * k, aw); q = fvPol(R - 8 * k, aw);
      g.pen = new Pen(FV_E9_CMARK ? FV_CK.blued1 : 0xffB0301E, (FV_E9_CMARK ? 1.0 : 1.4) * k); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]);
      if (FV_E9_CMARK) {
         // (E9) el tramo superluminico: una banda bermellon tenue en el aro de capitulos, de c (−60°) a 10¹² c (+120°)
         var bp = []; for (var ab = -60; ab <= 120; ab += 3) { var pb = fvPol(R - 4.5 * k, ab); bp.push(new Point(x + pb[0], y + pb[1])); }
         g.pen = new Pen(FV_E9_COL.band, 2.6 * k); g.drawPolyline(bp);
         // la LUZ: filete bermellon de lado a lado del aro, con un triangulito por fuera, y la «c» en bermellon
         var ac = fvSpeedCAngle(1), pc0 = fvPol(R - 0.5 * k, ac), pc1 = fvPol(R - 10.5 * k, ac);
         g.pen = new Pen(this.luxC, c3 ? Math.max(1.3, 1.3 * k) : 1.3 * k); g.drawLine(x + pc0[0], y + pc0[1], x + pc1[0], y + pc1[1]);
         var t0 = fvPol(R - 3.2 * k, ac), t1 = fvPol(R - 0.4 * k, ac - 2.6), t2 = fvPol(R - 0.4 * k, ac + 2.6);
         g.fillPolygon([new Point(x + t0[0], y + t0[1]), new Point(x + t1[0], y + t1[1]), new Point(x + t2[0], y + t2[1])], new Brush(this.luxC));
         // (1c) la «c» en negrita cursiva (cuerpo minimo +2: es la marca que se busca de un vistazo)
         var pcl = fvPol(R - 15.5 * k, ac), fc = c3 ? cpFont("display", Math.max(FV_CK3D_INK.MIN + 2, Math.round(9.5 * k)), true, true, 0) : this.font("display", 9.5 * k, true);
         this.textC(g, x + pcl[0], y + pcl[1] + 3.4 * k, "c", fc, this.luxC);
      }
   }
   if (o.sub) {
      var sy = y + R * 0.42; g.pen = new Pen(ink, c3 ? Math.max(0.7, 0.55 * k) : 0.5); g.drawCircle(x, sy, 7.5 * k);
      for (i = 0; i < 12; ++i) { p = fvPol(7.5 * k, i * 30); q = fvPol(6.2 * k, i * 30); g.drawLine(x + p[0], sy + p[1], x + q[0], sy + q[1]); }
   }
   this.textC(g, x, y + R + 18 * k, o.caption, this.fitFont("display", 7.5 * k, false, 0.24, o.caption), FV_CK.gold);
};
FVCockpit.prototype.plateFace = function(g) {
   var k = this.k, x = this.plate.x, y = this.plate.y;
   var hw = this.plate.hw || 92;
   if (this.ck3d) { this.textS(g, x - (hw - 2) * k, y + 35 * k, "Nº XLII", this.fitFont("display", 6.4 * k, false, 0.2, "Nº XLII"), FV_CK.brass2); return; }   // (1c) placa, remaches y cruceta: sprites (Nº XLII en laton algo mas claro: el 5E4214 de hoy no se leia)
   g.fillRect(x - hw * k, y - 24 * k, x + hw * k, y + 24 * k, new Brush(0xff1B140E));
   g.pen = new Pen(FV_CK.brass2, 1.2 * k); g.drawRect(x - hw * k, y - 24 * k, x + hw * k, y + 24 * k);
   g.pen = new Pen(FV_CK.brass3, 0.8 * k); g.drawRect(x - (hw - 6) * k, y - 18 * k, x + (hw - 6) * k, y + 18 * k);
   var RV = [[-(hw - 12), -12], [hw - 12, -12], [-(hw - 12), 12], [hw - 12, 12]];
   for (var i = 0; i < 4; ++i) g.fillCircle(x + RV[i][0] * k, y + RV[i][1] * k, 2 * k, fvCrownBrush(x + RV[i][0] * k, y + RV[i][1] * k, 2 * k));
   if (FV_PAD.ON) this.padFace(g);
   else {
      // (21-nov, P5) sin subtitulo de marca: solo el nombre del script, centrado en la placa
      this.textC(g, x, y + 6 * k, "FIELDVOYAGER", this.font("display", (hw < 90 ? 10.5 : 12) * k, false, 0.16), FV_CK.gold);
   }
   // numero de serie de la nave, grabado bajo la placa (guiño: 42)
   var fs = this.font("display", 6.4 * k, false, 0.2); g.font = fs; g.pen = new Pen(FV_CK.brass3); g.drawText(x - (hw - 2) * k, y + 35 * k, "Nº XLII");
};
// (5-nov) LA CRUCETA: el cubo de brujula del centro y las cuatro teclas; mode 0 = reposo, 1 = encendida (girando). Flecha grabada: filo de luz
// medio trazo debajo (como los iconos de la botonera) y la flecha en marron oscuro
FVCockpit.prototype.padFace = function(g) {
   var k = this.k, x = this.plate.x, y = this.plate.y, i, p, q, h = FV_PAD.HUB;
   g.fillCircle(x, y, h * k, fvBrassBrush(x, y, h * k));
   g.pen = new Pen(FV_CK.dark, 0.8 * k); g.drawCircle(x, y, h * k);
   g.pen = new Pen(FV_CK.brass3, 0.5 * k); g.drawCircle(x, y, (h - 1.4) * k);
   g.fillCircle(x, y, 1.5 * k, fvCrownBrush(x, y, 1.5 * k));
   for (i = 0; i < 4; ++i) { p = fvPol((h - 0.6) * k, i * 90); q = fvPol((h - 2.4) * k, i * 90); g.pen = new Pen(FV_CK.dark, 0.6 * k); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]); }
   for (var id in FV_PAD.K) this.padKey(g, id, 0);
};
FVCockpit.prototype.padKey = function(g, id, mode) {
   var k = this.k, x = this.plate.x, y = this.plate.y, r = FV_PAD.K[id], x0 = x + r[0] * k, y0 = y + r[1] * k, x1 = x + r[2] * k, y1 = y + r[3] * k, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
   var br = mode ? new LinearGradientBrush(new Point(x0, y0), new Point(x1, y1), [[0, 0xffFFF3C4], [0.5, 0xffF3D27E], [1, FV_CK.gold]])
                 : new LinearGradientBrush(new Point(x0, y0), new Point(x1, y1), [[0, FV_CK.brass0], [0.4, FV_CK.brass2], [1, FV_CK.brass1]]);
   g.fillRect(x0, y0, x1, y1, br);
   g.pen = new Pen(FV_CK.dark, 0.9 * k); g.drawRect(x0, y0, x1, y1);
   g.pen = new Pen(mode ? 0xffFFF3C4 : 0x80F3D27E, 0.5 * k); g.drawLine(x0 + 0.9 * k, y0 + 0.9 * k, x1 - 0.9 * k, y0 + 0.9 * k);
   var d = FV_PAD_DIR[id], T = (d === "up") ? [[0, -3.4], [-3.8, 2.2], [3.8, 2.2]] : (d === "down") ? [[0, 3.4], [-3.8, -2.2], [3.8, -2.2]] : (d === "left") ? [[-3.6, 0], [2.0, -3.1], [2.0, 3.1]] : [[3.6, 0], [-2.0, -3.1], [-2.0, 3.1]];
   function poly(dx, dy) { var a = []; for (var j = 0; j < 3; ++j) a.push(new Point(cx + (T[j][0] + dx) * k, cy + (T[j][1] + dy) * k)); return a; }
   g.fillPolygon(poly(0.4, 0.4), new Brush(0x90FFF3C4));                    // el filo de luz de la gubia
   g.fillPolygon(poly(0, 0), new Brush(FV_CK.dark));
};
// la tecla en vivo: encendida (gira), apagada (la pared de la foto no deja girar a ese lado) y, con el cursor encima, un aro de luz
FVCockpit.prototype.padPaint = function(g, gz) {
   if (!FV_PAD.ON) return;
   var k = this.k, x = this.plate.x, y = this.plate.y, st = gz && gz.pad;
   for (var id in FV_PAD.K) {
      var d = FV_PAD_DIR[id], s = st ? st[d] : null, r = FV_PAD.K[id], x0 = x + r[0] * k, y0 = y + r[1] * k, x1 = x + r[2] * k, y1 = y + r[3] * k;
      if (this.ck3d) {                                                       // (1c) la tecla es un sprite por estado: reposo, encendida, apagada (hundida y mate)
         var nm = "pad_" + d + "_" + ((s && s.ok === false) ? "off" : ((s && s.on) ? "lit" : "rest")), sp = fvCk3dSprite(this.k3, nm);
         if (sp) g.drawBitmap(Math.round(sp.gx * k - sp.ax), Math.round(sp.gy * k - sp.ay), sp.b);
         if (this.hover === id && !(s && s.ok === false)) { g.pen = new Pen(0xffF3D27E, Math.max(1, 1.3 * k)); g.drawRect(x0 - 1 * k, y0 - 1 * k, x1 + 1 * k, y1 + 1 * k); }
         continue;
      }
      if (s && s.on && s.ok !== false) this.padKey(g, id, 1);
      if (s && s.ok === false) { g.fillRect(x0 - 0.5 * k, y0 - 0.5 * k, x1 + 0.5 * k, y1 + 0.5 * k, new Brush(0xB41B140E)); g.pen = new Pen(FV_CK.brass3, 0.6 * k); g.drawRect(x0, y0, x1, y1); }
      else if (this.hover === id) { g.pen = new Pen(0xffF3D27E, 1.3 * k); g.drawRect(x0 - 1 * k, y0 - 1 * k, x1 + 1 * k, y1 + 1 * k); }
   }
   if (FV_PAD.BRAKE) this.padHubPaint(g, gz);
};
// (6-nov) el cubo-freno en vivo, encima de la placa (dibujada o sprite 3D): frenando (gz.brake > 0, o recien pulsado: hubT) se hunde medio punto
// y se enciende en oro con un aro de luz; con el cursor encima, el aro solo. gz.brake = lo que queda de frenada (1 -> 0)
FVCockpit.prototype.padHubPaint = function(g, gz) {
   var k = this.k, x = this.plate.x, y = this.plate.y, h = FV_PAD.HUB, now = (typeof fvNowMs === "function") ? fvNowMs() / 1000 : 0;
   var lit = !!(gz && gz.brake > 0) || (this.hubT !== undefined && this.hubT !== null && now - this.hubT < FV_PAD.HUB_FLASH_S);
   if (lit) {
      var dx = 0.4 * k, dy = 0.5 * k, r = h * k;
      g.fillCircle(x + dx, y + dy, r, new RadialGradientBrush(new Point(x + dx - 0.3 * r, y + dy - 0.3 * r), 1.3 * r, new Point(x + dx - 0.3 * r, y + dy - 0.3 * r), [[0, 0xffFFF3C4], [0.55, 0xffF3D27E], [1, FV_CK.gold]]));
      g.pen = new Pen(FV_CK.dark, 0.9 * k); g.drawCircle(x + dx, y + dy, r);
      g.pen = new Pen(0xff5E4214, 0.5 * k); g.drawCircle(x + dx, y + dy, (h - 1.4) * k);
      g.fillCircle(x + dx, y + dy, 1.5 * k, new Brush(FV_CK.dark));
      g.pen = new Pen(0xC0F3D27E, 1.2 * k); g.drawCircle(x, y, (h + 1.1) * k);
   } else if (this.hover === "padHub") { g.pen = new Pen(0xffF3D27E, 1.3 * k); g.drawCircle(x, y, (h + 1.1) * k); }
};
// MODUS: placa de laton con CINE arriba y WARP abajo; la palanca la pone paint()
FVCockpit.prototype.modusFace = function(g) {
   var k = this.k, x = this.modus.x, y = this.modus.y;
   if (!this.ck3d) {                                                         // (1c) la placa y la ranura: sprite
   g.fillRect(x - 22 * k, y - 34 * k, x + 22 * k, y + 34 * k, new Brush(0xff1B140E));
   g.pen = new Pen(FV_CK.brass2, 1.2 * k); g.drawRect(x - 22 * k, y - 34 * k, x + 22 * k, y + 34 * k);
   g.pen = new Pen(FV_CK.brass3, 0.7 * k); g.drawRect(x - 18 * k, y - 30 * k, x + 18 * k, y + 30 * k);
   g.fillRect(x - 2.5 * k, y - 20 * k, x + 2.5 * k, y + 20 * k, new Brush(0xff07060A));                 // la ranura
   }
   var f = this.font("display", 6.6 * k, false, 0.2);
   this.textC(g, x, y - 23 * k, (FV_B5B.FMT ? fvTx("ck.cine") : "CINE"), f, FV_CK.gold);   // (Blender 5b · R5-11) «CINEMA» con el ingles puesto
   this.textC(g, x, y + 29 * k, "WARP", f, FV_CK.gold);
   this.textC(g, x, y + 50 * k, "MODUS", this.fitFont("display", 7.5 * k, false, 0.24, "MODUS"), FV_CK.gold);
};
// (F4b) REC: bisel de laton estriado y cristal rojo apagado; la lampara, la lectura y las opciones las pone paint()
FVCockpit.prototype.recFace = function(g) {
   var k = this.k, x = this.rec.x, y = this.rec.y, i, p, q;
   if (this.ck3d) return;                                                    // (1c) sprite
   g.fillCircle(x, y, 13 * k, fvBrassBrush(x, y, 13 * k));
   g.pen = new Pen(FV_CK.brass3, 0.7);
   for (i = 0; i < 40; ++i) { p = fvPol(13 * k, i * 9); q = fvPol(11.2 * k, i * 9); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]); }
   g.fillCircle(x, y, 9 * k, new RadialGradientBrush(new Point(x - 3 * k, y - 3 * k), 11 * k, new Point(x - 3 * k, y - 3 * k), [[0, 0xff6A2418], [1, 0xff250A06]]));
   g.pen = new Pen(FV_CK.dark, 0.8); g.drawCircle(x, y, 9 * k);
};
// ¿que hay en (px, py) de la franja? -> id de zone() ("rec", "modus", "lang", "reg", "map2d"…) | "list:<n>" | "listGo:<n>" | "list" | null
// (st = estado de la lista de MIRABILIA, para saber que fila hay bajo el cursor)
FVCockpit.prototype.hit = function(px, py, st) {
   var Z = this.zones();
   for (var i = 0; i < Z.length; ++i) {
      var z = Z[i]; if (!(px >= z.x0 && px <= z.x1 && py >= z.y0 && py <= z.y1)) continue;
      if ((z.id === "aetas" || z.id === "aetasNow" || z.id === "aetasFwd" || z.id === "aetasBack" || z.id === "aetasFrame") && !this.aetasOk) return "aetasOff";       // (I4) sin datos: indicador con su porque (I3: tambien los botones)
      return z.id;
   }
   if (st) return fvNavListHit(this.listIn, st, this.k, px, py);
   var L = this.list; if (px >= L[0] && px <= L[2] && py >= L[1] && py <= L[3]) return "list";
   return null;
};
// ¿se acciona? (cursor de mano y realce) — los relojes y la placa son indicadores
FVCockpit.prototype.isAction = function(id) {
   if (!id) return false;
   if (id.indexOf("list:") === 0 || id.indexOf("listGo:") === 0 || id === "search" || id === "searchClear" || id === "listFlip") return true;     // (I3) el buscador de MIRABILIA
   var Z = this.zones(); for (var i = 0; i < Z.length; ++i) if (Z[i].id === id) return Z[i].act;
   return false;
};
FVCockpit.prototype.zone = function(id) { var Z = this.zones(); for (var i = 0; i < Z.length; ++i) if (Z[i].id === id) return Z[i]; return null; };
// (N1) los biseles de laton de los tres paneles de navegacion, y sus rotulos
FVCockpit.prototype.navFaces = function(g) {
   var k = this.k, self = this;
   function bezel(r, cap) {
      g.fillRect(r[0] - 4 * k, r[1] - 4 * k, r[2] + 4 * k, r[3] + 4 * k, fvBrassBrush((r[0] + r[2]) / 2, (r[1] + r[3]) / 2, Math.max(r[2] - r[0], r[3] - r[1]) / 2));
      g.pen = new Pen(FV_CK.dark, 0.8); g.drawRect(r[0] - 4 * k + 0.5, r[1] - 4 * k + 0.5, r[2] + 4 * k - 0.5, r[3] + 4 * k - 0.5);
      g.fillRect(r[0] - 1 * k, r[1] - 1 * k, r[2] + 1 * k, r[3] + 1 * k, new Brush(0xff2A1D08));
      g.fillRect(r[0], r[1], r[2], r[3], new Brush(0xff07060A));
      var RV = [[r[0] - 2 * k, r[1] - 2 * k], [r[2] + 2 * k, r[1] - 2 * k], [r[0] - 2 * k, r[3] + 2 * k], [r[2] + 2 * k, r[3] + 2 * k]];
      for (var i = 0; i < 4; ++i) g.fillCircle(RV[i][0], RV[i][1], 1.4 * k, fvCrownBrush(RV[i][0], RV[i][1], 1.4 * k));
      if (cap) { var f = self.font("display", 6.2 * k, false, 0.24); g.font = f; g.fillRect(r[0] + 3 * k, r[3] - 9.5 * k, r[0] + 7 * k + f.width(cap), r[3] - 1 * k, new Brush(0xb0110D09)); g.pen = new Pen(FV_CK.gold); g.drawText(r[0] + 5 * k, r[3] - 3 * k, cap); }
   }
   bezel(this.map2d, ""); bezel(this.map3d, "");
   var L = this.list;
   g.fillRect(L[0], L[1], L[2], L[3], new Brush(0xff1B140E));
   g.pen = new Pen(FV_CK.brass2, 1.2 * k); g.drawRect(L[0], L[1], L[2], L[3]);
   g.pen = new Pen(FV_CK.brass3, 0.7 * k); g.drawRect(L[0] + 3 * k, L[1] + 3 * k, L[2] - 3 * k, L[3] - 3 * k);
};
// (N1) los paneles en vivo: nav = { scene, P, map2d: FVNavMap2D, map3d: FVNavMap3D, list: { items, top, hover, sel, ready } }
FVCockpit.prototype.paintNav = function(g, nav) {
   var k = this.k, sc = nav ? nav.scene : null, P = nav ? nav.P : null;
   g.antialiasing = true; g.textAntialiasing = true;
   if (nav && nav.map2d) nav.map2d.paint(g, this.map2d, sc, P, k, nav.trail);
   if (sc && nav.map3d) nav.map3d.paint(g, this.map3d, P, k, P ? P.sel : null, nav.trail);
   var f = this.font("display", 6.2 * k, false, 0.24), self = this;
   function cap(r, s) { g.font = f; g.fillRect(r[0] + 2 * k, r[3] - 9.5 * k, r[0] + 6 * k + f.width(s), r[3] - 1 * k, new Brush(0xb0110D09)); g.pen = new Pen(FV_CK.gold); g.drawText(r[0] + 4 * k, r[3] - 3 * k, s); }
   cap(this.map2d, "TABULA"); cap(this.map3d, "PROFUNDITAS");
   fvNavListPaint(g, this.listIn, nav && nav.list ? nav.list : { items: [], top: 0 }, k);
};
FVCockpit.prototype.regFace = function(g) {
   var k = this.k, x = this.reg.x, y = this.reg.y, i, pts = [];
   // (N2, punto 8 de Nino) el REGULATOR es la VELOCIDAD DEL VIAJE (cine y warp): marcas LENTO · RAPIDO en los extremos del arco y una marca
   // mas larga en el centro (la velocidad de siempre); las cifras romanas de la potencia del warp ya no dicen nada
   var f = this.font("display", 6.2 * k, false, 0.1);
   if (!this.ck3d) {                                                         // (1c) arco y marcas en relieve: sprite
   for (i = 0; i <= 40; ++i) { var p = fvPol(48 * k, -62 + 124 * i / 40); pts.push(new Point(x + p[0], y + p[1] - 6 * k + 6 * k)); }
   g.pen = new Pen(FV_CK.brass2, 6 * k); g.drawPolyline(pts);
   g.pen = new Pen(FV_CK.dark, 0.6); g.drawPolyline(pts);
   }
   for (i = 0; i < 7 && !this.ck3d; ++i) {
      var a = -62 + 124 * i / 6, p1 = fvPol(52 * k, a), p2 = fvPol((i === 3 ? 62 : (i % 3 === 0 ? 60 : 57)) * k, a);
      g.pen = new Pen(i === 3 ? FV_CK.gold : FV_CK.brass2, (i === 3 ? 1.3 : 0.8) * k); g.drawLine(x + p1[0], y + p1[1], x + p2[0], y + p2[1]);
   }
   var pl = fvPol(48 * k, -62), pr = fvPol(48 * k, 62);
   this.textC(g, x + pl[0] - 1 * k, y + pl[1] + 11 * k, fvTx("ck.slow"), f, FV_CK.gold);
   this.textC(g, x + pr[0] + 1 * k, y + pr[1] + 11 * k, fvTx("ck.fast"), f, FV_CK.gold);
   this.textC(g, x, y + 22 * k, "REGULATOR", this.fitFont("display", 7.5 * k, false, 0.24, "REGULATOR"), FV_CK.gold);
};
FVCockpit.prototype.radioFace = function(g) {
   var k = this.k * 0.85, x = this.radio.x, y = this.radio.y, i, p, q, c3 = this.ck3d;
   if (!c3) {                                                                // (1c) bisel, disco, mando y lampara: sprites
   g.fillCircle(x, y, 43 * k, fvBrassBrush(x, y, 43 * k));
   g.pen = new Pen(FV_CK.brass3, 0.8);
   for (i = 0; i < 90; ++i) { p = fvPol(43 * k, i * 4); q = fvPol(40.5 * k, i * 4); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]); }
   g.fillCircle(x, y, 38 * k, new RadialGradientBrush(new Point(x - 4 * k, y - 8 * k), 52 * k, new Point(x - 4 * k, y - 8 * k), [[0, FV_CK.enamel0], [0.75, FV_CK.enamel1], [1, FV_CK.enamel2]]));
   }
   var rot = 150 - 3 * 3, f = this.font("display", 7 * k, false);       // disco quieto (sintonia 3, como la maqueta al abrir)
   for (var fq = 0; fq <= 100; fq += 2) {
      var a = -150 + fq * 3 + rot; p = fvPol(36 * k, a); q = fvPol((fq % 10 ? 33.5 : 31) * k, a);
      g.pen = new Pen(this.inkC, fq % 10 ? (c3 ? 0.6 : 0.4) : 0.9); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]);
      if (fq % 20 === 0) { var pt = fvPol(24 * k, a); this.textC(g, x + pt[0], y + pt[1] + 2.5 * k, String(fq), f, this.inkC); }
   }
   for (i = 0; i < 10; ++i) { var fs = 6 + i * 9.8, as = -150 + fs * 3 + rot, ps = fvPol(36.5 * k, as); g.fillCircle(x + ps[0], y + ps[1], 1.1 * k, new Brush(FV_CK.verm)); }
   // (el disco: sintonia 3; F2 sin sonido todavia)
   g.fillPolygon([new Point(x, y - 44 * k), new Point(x - 3.5 * k, y - 36 * k), new Point(x + 3.5 * k, y - 36 * k)], new Brush(FV_CK.verm));
   if (c3) { this.textC(g, x, y + 56 * k, "RADIOPHONIA", this.fitFont("display", 7.5 * k, false, 0.24, "RADIOPHONIA"), FV_CK.gold); return; }
   // mando moleteado
   g.fillCircle(x, y, 13 * k, fvBrassBrush(x, y, 13 * k));
   g.pen = new Pen(FV_CK.dark, 1);
   for (i = 0; i < 24; ++i) { p = fvPol(13 * k, i * 15); q = fvPol(10.5 * k, i * 15); g.drawLine(x + p[0], y + p[1], x + q[0], y + q[1]); }
   g.fillCircle(x, y, 9 * k, fvCrownBrush(x, y, 9 * k));
   g.fillCircle(x - 50 * k, y - 30 * k, 4 * k, new Brush(0x40E5B53F));      // lampara apagada (sin sonido en F1)
   this.textC(g, x, y + 56 * k, "RADIOPHONIA", this.fitFont("display", 7.5 * k, false, 0.24, "RADIOPHONIA"), FV_CK.gold);
};

// aguja Breguet de largo len, girada `deg` (0 = arriba, sentido del reloj), en (x, y). Puntos girados a mano: con
// translate/rotate/scaleTransformation la aguja salia girada y encogida (medido en f1_info.png de la primera pasada)
FVCockpit.prototype.hand = function(g, x, y, len, deg, w, shadow) {
   // (1c) shadow = color: la aguja entera de ese color (su sombra, desplazada por quien llama)
   var s = len / 38, a = deg * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a), ww = w || 1, c0 = shadow || FV_CK.blued0, c1 = shadow || FV_CK.blued1;
   function P(px, py) { px *= s; py *= s; return new Point(x + px * ca - py * sa, y + px * sa + py * ca); }
   g.fillPolygon([P(0, 6), P(1.4 * ww, -18), P(-1.4 * ww, -18)], new Brush(c0));
   var c = P(0, -22.1);
   g.pen = new Pen(c0, Math.max(1, 1.6 * s)); g.drawCircle(c.x, c.y, 3.4 * s);
   g.fillPolygon([P(1.4, -26.2), P(0, -38), P(-1.4, -26.2)], new Brush(c1));
   var p1 = P(0, 4), p2 = P(0, -17);
   g.pen = new Pen(c1, Math.max(0.5, 0.5 * s)); g.drawLine(p1.x, p1.y, p2.x, p2.y);
};
// (1c) la aguja con su sombra suave abajo-derecha (la luz del render), y la sombra solo con la cabina 3D
FVCockpit.prototype.handS = function(g, x, y, len, deg, w) {
   if (this.ck3d) { var o = 1.0 * this.k; this.hand(g, x + 0.9 * o, y + 1.1 * o, len, deg, w, 0x45000000); }
   this.hand(g, x, y, len, deg, w);
};

// (9-nov, N8) la plaquita «VISTA» / «SEEN» de VELOCITAS: laton con el borde oscuro y la palabra grabada en tinta (Bodoni
// italica de versalitas espaciadas, como los titulos de las esferas), a un tercio bajo el pivote, entre las cifras del aro y la lectura
FVCockpit.prototype.seenPlate = function(g, V) {
   var k = this.k, x = V.x, y = V.y + V.r * 0.43, word = fvTx("ck.seen"), f = this.font("display", 4.7 * k, true, 0.1, 5), w = f.width(word) + 3.4 * k, h = 6.6 * k;
   var x0 = x - w / 2, y0 = y - h / 2;
   g.fillRect(x0, y0, x0 + w, y0 + h, new LinearGradientBrush(new Point(x0, y0), new Point(x0, y0 + h), [[0, FV_CK.brass0], [0.45, FV_CK.brass2], [1, FV_CK.brass1]]));
   g.pen = new Pen(FV_CK.dark, Math.max(0.7, 0.5 * k)); g.drawRect(x0 + 0.5, y0 + 0.5, x0 + w - 0.5, y0 + h - 0.5);
   g.font = f; g.pen = new Pen(FV_CK.dark); g.drawText(x - f.width(word) / 2, y + 1.8 * k, word);
};

// ---- un fotograma ----  gz = fvPilotGauges(P) + { reg } -> pinta en g (control o bitmap) de W × H
FVCockpit.prototype.paint = function(g, gz) {
   if (!this.stat) this.buildStatic();
   var k = this.k;
   g.drawBitmap(0, 0, this.stat);
   g.antialiasing = true; g.textAntialiasing = true;
   var fr = this.font("display", 6.8 * k, true);
   // VELOCITAS: años luz por segundo, logaritmica de 10⁻² a 10⁴ (por encima, a tope: «WARP» en la lectura si el warp esta a fondo)
   var V = this.g[0], vc = (gz.speedC !== undefined) ? gz.speedC : (gz.speedLyS || 0) * 3.15576e7;
   if (FV_N8_SEEN && gz.seen) this.seenPlate(g, V);              // (N8) debajo de la aguja: la aguja pasa por encima
   this.handS(g, V.x, V.y, V.r - 8 * k, fvSpeedCAngle(vc));
   // (E9) por debajo de c en tinta; por encima, en bermellon (la aguja ya ha pasado la marca «c»)
   var vSup = FV_E9_CMARK && vc >= 0.995;
   this.textC(g, V.x, V.y + V.r * 0.70, gz.warp > 0.97 ? "WARP" : (vc < 0.005 ? "0" : fvSpeedLyText(vc) + " c"), fr, vSup ? this.luxC : this.inkC);
   this.vSuper = vSup;
   // DISTANTIA: a la Tierra, logaritmica de 1 a 10 000 años luz
   var D = this.g[1], ad = -120 + 60 * fvClamp(Math.log(Math.max(1, gz.dist)) / Math.LN10, 0, 4);
   this.handS(g, D.x, D.y, D.r - 8 * k, ad);
   this.textC(g, D.x, D.y + D.r * 0.70, (gz.dist < 0.01 ? "0" : fvFmtLy(gz.dist)) + " " + (FV_H8_UNITS ? fvTx("nav.ly") : "a.l."), fr, this.inkC);   // (Blender 5 · H8) «ly» con el ingles puesto
   // CHRONOMETRUM: el reloj de escena (horas, minutos y segundero pequeño)
   // (5-nov, Nino: «cuando muevo AETAS, CHRONOMETRUM debe moverse de acuerdo») con la maquina del tiempo el «hoy» de la escena es el
   // año de AETAS: el año que se lee es (hoy + AETAS) − distancia, y las agujas siguen a ese año. FV_CHRONO_AETAS = false: lo de antes (ROJO)
   var T = this.g[2], back = Math.max(0, gz.dist || 0), aYr = (FV_CHRONO_AETAS && gz.epoch && gz.epoch.ok) ? (gz.epoch.years || 0) : 0;
   back -= aYr;
   var md = function(v, m) { return ((v % m) + m) % m; }, chTxt = fvLightYearText(back), aH = back / 12000 * 360, aM = back / 1000 * 360, aS = back / 100 * 360;
   // (5-nov, C-1, Nino: «sí») CHRONOMETRUM dice lo mismo que en el navegador: el año en que salio DEL OBJETO la luz que ves (el destino, lo
   // elegido o la nebulosa; distancia camara–objeto, redondeo al error de la distancia, + AETAS: gz.chrono = fvChronoOf). Distancia supuesta: «—»
   // y agujas a las XII. FV_CHRONO_OBJ = false: el año de la luz de la Tierra vista desde la nave (lo de antes, ROJO de fv_chrono_aetas_test C5)
   if (FV_CHRONO_OBJ && gz.chrono) {
      var cy0 = gz.chrono.known ? gz.chrono.year : null;
      chTxt = (cy0 !== null) ? gz.chrono.txt : "—";
      aH = (cy0 !== null) ? cy0 / 12000 * 360 : 0; aM = (cy0 !== null) ? cy0 / 1000 * 360 : 0; aS = (cy0 !== null) ? cy0 / 100 * 360 : 0;
   }
   this.handS(g, T.x, T.y, 20 * k, md(aH, 360), 1.3);
   this.handS(g, T.x, T.y, 30 * k, md(aM, 360));
   var sp = fvPol(6.5 * k, md(aS, 360)), sy = T.y + T.r * 0.42;
   // el año, donde las otras esferas llevan el titulo (abajo chocaba con VII y V)
   this.textC(g, T.x, T.y - T.r * 0.32, chTxt, this.font("display", 6.6 * k, true), this.sepiaC);
   g.pen = new Pen(FV_CK.blued0, this.ck3d ? Math.max(1, 0.8 * k) : 0.8 * k); g.drawLine(T.x, sy, T.x + sp[0], sy + sp[1]);
   for (var i = 0; i < 3; ++i) {
      var o = this.g[i];
      if (this.ck3d) { this.sprite(g, "dial_cap", o.x, o.y); this.sprite(g, "dial_glass", o.x, o.y); continue; }      // (1c) pivote y cristal (capa de luz) renderizados
      g.fillCircle(o.x, o.y, 2.4 * k, fvCrownBrush(o.x, o.y, 2.4 * k));
      g.fillCircle(o.x, o.y, o.r, new RadialGradientBrush(new Point(o.x - 0.3 * o.r, o.y - 0.5 * o.r), 0.75 * o.r, new Point(o.x - 0.3 * o.r, o.y - 0.5 * o.r), [[0, 0x47FFFFFF], [1, 0x00FFFFFF]]));
   }
   // REGULATOR (N2): la PALANCA es un mando — la potencia del warp que elige el usuario arrastrandola (gz.regSet 0…1); la aguja fina
   // bermellon lee lo que da el motor ahora (gz.reg: el warp en curso o el empuje de un viaje de cine)
   var R = this.reg, regSet = (gz.regSet !== undefined) ? gz.regSet : (gz.reg || 0), ang = -62 + 124 * fvClamp(regSet, 0, 1), a1 = fvPol(50 * k, ang), a2 = fvPol(53 * k, ang);
   if (gz.reg > 0.005) { var an = -62 + 124 * fvClamp(gz.reg, 0, 1), n1 = fvPol(47 * k, an); g.pen = new Pen(0xd0E0603F, 1.3 * k); g.drawLine(R.x, R.y, R.x + n1[0], R.y + n1[1]); }
   if (this.ck3d) this.regLever3d(g, ang, a1, a2, this.hover === "reg" || gz.regDrag);           // (1c) varilla pintada en cilindro + pomo y cubo renderizados
   else {
   g.pen = new Pen(FV_CK.brass2, 3.5 * k); g.drawLine(R.x, R.y, R.x + a1[0], R.y + a1[1]);
   g.fillCircle(R.x + a2[0], R.y + a2[1], 5.5 * k, fvCrownBrush(R.x + a2[0], R.y + a2[1], 5.5 * k));
   if (this.hover === "reg" || gz.regDrag) { g.pen = new Pen(0xffFFF3C4, 1.2 * k); g.drawCircle(R.x + a2[0], R.y + a2[1], 7 * k); }
   g.fillCircle(R.x, R.y, 6 * k, fvCrownBrush(R.x, R.y, 6 * k));
   }
   // (N2, punto 8) la cifra solo mientras se toca la palanca: la lectura de verdad son las marcas LENTO · RAPIDO
   var fRg = this.font("display", 6.4 * k, true); if (gz.regDrag || this.hover === "reg") this.textC(g, R.x, R.y + 12 * k, Math.round(100 * regSet) + " %", fRg, FV_CK.gold);
   // la radio: cristal y, encendida la nave, la lampara de sintonia (lo pintado solo se ve en el VIDEO y si no hay WebView: en la nave
   // lo tapa la radio de verdad, src/radio). Debajo, el rotulo de la emisora y la pestaña EMISORAS (N2)
   var X = this.radio, pw = (gz.power === undefined) ? 1 : gz.power, kr = 0.85 * k;
   if (this.ck3d) this.sprite(g, "radio_glass", X.x, X.y);
   else g.fillCircle(X.x, X.y, 38 * kr, new RadialGradientBrush(new Point(X.x - 12 * kr, X.y - 20 * kr), 26 * kr, new Point(X.x - 12 * kr, X.y - 20 * kr), [[0, 0x40FFFFFF], [1, 0x00FFFFFF]]));
   if (gz.radio) {
      var rd = gz.radio, fR = this.font("display", 6.6 * k, true, 0.02), fTb = this.font("display", 6.2 * k, false, 0.2);
      g.font = fR; g.pen = new Pen(rd.col || FV_CK.gold);
      var rt = cpElide(fR, rd.text || "", 128 * k);
      if (rd.hot) { g.pen = new Pen((0xB0000000 | (rd.col & 0xFFFFFF)) >>> 0, 0.9 * k); g.drawRect(X.x - 62 * k, 122.5 * k, X.x + 62 * k, 134.5 * k); g.pen = new Pen(rd.col || FV_CK.gold); }       // (P14) el marco del aviso
      g.drawText(X.x - fR.width(rt) / 2, 131 * k, rt);
      var tz = this.zone("radioTab"), lab = rd.tab || "";
      if (lab) {
         g.fillRect(tz.x0, tz.y0, tz.x1, tz.y1, this.hover === "radioTab" ? new Brush(0xff3A2A10) : new Brush(0xff1B140E));
         g.pen = new Pen(this.hover === "radioTab" ? FV_CK.gold : FV_CK.brass3, 0.9 * k); g.drawRect(tz.x0 + 0.5, tz.y0 + 0.5, tz.x1 - 0.5, tz.y1 - 0.5);
         g.font = fTb; g.pen = new Pen(FV_CK.gold); g.drawText((tz.x0 + tz.x1) / 2 - fTb.width(lab) / 2, tz.y1 - 4.5 * k, lab);
      }
   }
   if (pw >= 1 && !gz.radio) {
      var lx = X.x - 50 * kr, ly = X.y - 30 * kr;
      if (this.ck3d) { var spl = fvCk3dSprite(this.k3, "radio_lamp_on"); if (spl) g.drawBitmap(Math.round(spl.gx * k - spl.ax), Math.round(spl.gy * k - spl.ay), spl.b); }
      g.fillCircle(lx, ly, 9 * kr, new RadialGradientBrush(new Point(lx, ly), 9 * kr, new Point(lx, ly), [[0, 0xc0FFC860], [1, 0x00FFC860]]));
      if (!this.ck3d) g.fillCircle(lx, ly, 3.6 * kr, new Brush(0xffFFD98A));
      var fa = this.font("display", 6.2 * k, true, 0.05); this.textS(g, lx - fa.width(fvTx("ck.radio")) / 2, ly - 8 * kr, fvTx("ck.radio"), fa, FV_CK.gold);
   }
   // MODUS: la palanca arriba (CINE) o abajo (WARP)
   var M = this.modus, up = (gz.style !== "spectacular"), ly2 = M.y + (up ? -13 : 13) * k;
   if (fvGwarpUi()) { /* (21-nov, N-galaxias-warp) sin selector MODUS: ni placa ni palanca */ }
   else if (this.ck3d) this.sprite(g, up ? "modus_lever_up" : "modus_lever_down", M.x, M.y);     // (1c) la palanca renderizada (ancla en el pivote)
   else {
   g.pen = new Pen(FV_CK.brass2, 3 * k); g.drawLine(M.x, M.y, M.x, ly2);
   g.fillCircle(M.x, M.y, 4 * k, fvCrownBrush(M.x, M.y, 4 * k));
   g.fillCircle(M.x, ly2, 5.5 * k, fvCrownBrush(M.x, ly2, 5.5 * k));
   }
   var dim = this.ck3d ? 0xff9C7325 : FV_CK.brass3;                    // (1c) lo no elegido, legible (el 5E4214 de hoy da contraste 2 sobre la chapa)
   // idioma: EN · ES (el activo en oro)
   var Lg = this.lang, fl = this.font("display", 6.6 * k, false, 0.2), en = (FV_LANG !== "es");
   g.font = fl; var wEN = fl.width("EN"), wDot = fl.width(" · ");
   var lx0 = Lg.x + 70 * k - (wEN + wDot + fl.width("ES")) / 2;
   g.pen = new Pen(en ? FV_CK.gold : dim); g.drawText(lx0, Lg.y + 2 * k, "EN");
   g.pen = new Pen(dim); g.drawText(lx0 + wEN, Lg.y + 2 * k, " · ");
   g.pen = new Pen(en ? dim : FV_CK.gold); g.drawText(lx0 + wEN + wDot, Lg.y + 2 * k, "ES");
   // (5-nov) STELLAE: GAIA · COLOR · FOTO (la puesta en oro; con el cursor encima, laton claro). gz.look = { cur, busy } (busy: midiendo)
   var LK = this.lookGeom();
   if (LK) {
      var lkCur = (gz.look && gz.look.cur) ? gz.look.cur : "gaia";
      g.font = LK.font;
      for (var il = 0; il < 3; ++il) {
         var on = FV_CK_LOOK_OF[LK.ids[il]] === lkCur;
         g.pen = new Pen(on ? FV_CK.gold : (this.hover === LK.ids[il] ? FV_CK.brass0 : dim));
         g.drawText(LK.x[il], LK.y, LK.words[il]);
         if (il < 2) { g.pen = new Pen(dim); g.drawText(LK.x[il] + LK.w[il], LK.y, " · "); }
      }
      this.textC(g, this.plate.x, LK.capY, (gz.look && gz.look.busy) ? fvTx("ck.lookBusy") : "STELLAE", this.fitFont("display", 7.5 * k, false, 0.24, "STELLAE"), FV_CK.gold);
   }
   // (F4b) REC: el piloto (rojo y parpadeando al grabar; ambar mientras se renderiza), la lectura y las opciones
   var Rc = this.rec, rs = gz.rec || { on: false }, fr2 = this.font("display", 7.2 * k, false, 0.2), fo = this.font("display", 6.2 * k, false, 0.12);
   if (rs.on || rs.busy) {
      var lit = rs.busy ? 0xffE5A23F : ((Math.floor((rs.t || 0) * 2) % 2 === 0) ? 0xffFF3B2A : 0xffA8241A);
      g.fillCircle(Rc.x, Rc.y, 14 * k, new RadialGradientBrush(new Point(Rc.x, Rc.y), 14 * k, new Point(Rc.x, Rc.y), [[0, (lit & 0x00ffffff) | 0x90000000], [1, (lit & 0x00ffffff) >>> 0]]));
      if (this.ck3d) this.sprite(g, rs.busy ? "rec_gem_amber" : "rec_gem_red", Rc.x, Rc.y);          // (1c) el cabujon encendido, renderizado
      else g.fillCircle(Rc.x, Rc.y, 8 * k, new RadialGradientBrush(new Point(Rc.x - 2 * k, Rc.y - 2 * k), 9 * k, new Point(Rc.x - 2 * k, Rc.y - 2 * k), [[0, 0xffFFE0D0], [0.35, lit], [1, 0xff4A0E08]]));
   }
   if (!this.ck3d) g.fillCircle(Rc.x - 3 * k, Rc.y - 3.5 * k, 2.6 * k, new Brush(0x55FFFFFF));
   var tRec = rs.on ? (Math.floor((rs.t || 0) / 60) + ":" + ("0" + Math.floor((rs.t || 0) % 60)).slice(-2)) : (rs.busy ? Math.round(100 * (rs.frac || 0)) + " %" : "REC");
   this.textC(g, Rc.x, Rc.y + 24 * k, tRec, fr2, rs.on ? 0xffFF6A50 : FV_CK.gold);
   g.font = fo; var fmt = rs.fmt || "avi", wA = fo.width("AVI"), wD = fo.width(" · "), xf = Rc.x - (wA + wD + fo.width("MP4")) / 2;
   g.pen = new Pen(fmt === "avi" ? FV_CK.gold : dim); g.drawText(xf, Rc.y + 38 * k, "AVI");
   g.pen = new Pen(dim); g.drawText(xf + wA, Rc.y + 38 * k, " · ");
   g.pen = new Pen(fmt === "mp4" ? FV_CK.gold : dim); g.drawText(xf + wA + wD, Rc.y + 38 * k, "MP4");
   // (N2, punto 7 de Nino: «no sé qué hace CABINA») un conmutador con dos dibujos y el rotulo que dice lo que se grabara:
   // CON CABINA = el fotograma de la foto con la franja de instrumentos debajo (dibujo: marco + franja rellena) · SIN CABINA = solo la foto
   var cabT = fvTx(rs.cab ? "ck.cabin" : "ck.cabinNo"), iw = 14 * k, ih = 9.5 * k, xl = Rc.x - iw / 2, yc = Rc.y + 47 * k, col = rs.cab ? FV_CK.gold : 0xffA3957B;
   var fcb = this.fitFont("display", 5.9 * k, false, 0.04, cabT); cabT = cpElide(fcb, cabT, 52 * k);
   g.pen = new Pen(col, Math.max(0.9, 0.9 * k));
   g.drawRect(xl, yc - ih / 2, xl + iw, yc + ih / 2);
   if (rs.cab) { g.fillRect(xl, yc + ih * 0.12, xl + iw, yc + ih / 2, new Brush(col)); g.fillRect(xl + 1.2 * k, yc - ih / 2 + 1.2 * k, xl + iw - 1.2 * k, yc + ih * 0.12 - 1.2 * k, new Brush(0x60E5B53F)); }
   else g.fillRect(xl + 1.2 * k, yc - ih / 2 + 1.2 * k, xl + iw - 1.2 * k, yc + ih / 2 - 1.2 * k, new Brush(0x40A3957B));
   g.font = fcb; g.pen = new Pen(col); g.drawText(Rc.x - fcb.width(cabT) / 2, Rc.y + 60 * k, cabT);
   // (I4) AETAS: la palanca en su sitio y la lectura del año
   if (this.aetas) this.aetasPaint(g, gz);
   this.padPaint(g, gz);                                                // (5-nov) la cruceta
   // (N2) realce del mando bajo el cursor: un aro de luz dorada
   var hz = this.hover ? this.zone(this.hover) : null;
   if (hz && hz.act && hz.id !== "map2d" && hz.id !== "map3d" && hz.id !== "radioTab" && !FV_PAD_DIR[hz.id] && hz.id !== "padHub" && hz.id !== "aetasFwd" && hz.id !== "aetasBack" && hz.id !== "aetasFrame") { g.pen = new Pen(0x90F3D27E, 1.4 * k); g.drawRect(hz.x0, hz.y0, hz.x1, hz.y1); }
   if (hz && hz.act && (hz.id === "map2d" || hz.id === "map3d")) { g.pen = new Pen(0xa0F3D27E, 1.2 * k); g.drawRect(hz.x0 - 2 * k, hz.y0 - 2 * k, hz.x1 + 2 * k, hz.y1 + 2 * k); }
   // la cabina apagada (antes del encendido) y encendiendose (a la par que los sistemas)
   if (pw < 1) g.fillRect(0, 0, this.W, this.H, new Brush(((Math.round(255 * 0.74 * (1 - pw)) << 24) | 0x07060A) >>> 0));
};
// ---------------------------------------------------------------------------
// (I4) AETAS, la maquina del tiempo. La lectura vive SOLO aqui (CHRONOMETRUM sigue diciendo el año de la luz que ves: otra cosa).
// ---------------------------------------------------------------------------
FVCockpit.prototype.aetasFace = function(g) {
   var k = this.k, x = this.aetas.x, y = this.aetas.y, hw = FV_I4.HW, hh = FV_I4.HH, tr = FV_I4.TRAVEL, i;
   if (this.ck3d) this.sprite(g, "aetas_plate", x, y);                      // (1c) placa y ranura: sprite (las marcas, grabadas, siguen aqui)
   else {
   g.fillRect(x - hw * k, y - hh * k, x + hw * k, y + hh * k, new Brush(0xff1B140E));
   g.pen = new Pen(FV_CK.brass2, 1.2 * k); g.drawRect(x - hw * k, y - hh * k, x + hw * k, y + hh * k);
   g.pen = new Pen(FV_CK.brass3, 0.7 * k); g.drawRect(x - (hw - 4) * k, y - (hh - 4) * k, x + (hw - 4) * k, y + (hh - 4) * k);
   g.fillRect(x - 2 * k, y - (tr + 1.5) * k, x + 2 * k, y + (tr + 1.5) * k, new Brush(0xff07060A));            // la ranura
   }
   // las marcas: ±1 000, ±10 000 y ±100 000 años (finas) y HOY (dorada, de lado a lado)
   var marks = [1e3, 1e4, 1e5];
   for (i = 0; i < marks.length; ++i) for (var sg = -1; sg <= 1; sg += 2) {
      var yy = y - sg * tr * k * fvTimeToS(sg * marks[i]);
      g.pen = new Pen(FV_CK.brass2, this.ck3d ? Math.max(0.8, (i === 2 ? 0.9 : 0.6) * k) : (i === 2 ? 0.9 : 0.6) * k); g.drawLine(x - 7 * k, yy, x - 3.5 * k, yy); g.drawLine(x + 3.5 * k, yy, x + 7 * k, yy);
   }
   g.pen = new Pen(FV_CK.gold, this.ck3d ? Math.max(1.3, 1.2 * k) : 1.2 * k); g.drawLine(x - 8.5 * k, y, x - 3 * k, y); g.drawLine(x + 3 * k, y, x + 8.5 * k, y);
   var f = this.font("display", 8 * k, false, 0);
   this.textC(g, x, y - (tr + 4) * k, "+", f, FV_CK.gold);
   this.textC(g, x, y + (tr + 11) * k, "−", f, FV_CK.gold);
   this.textC(g, this.aetas.rx, y + 60 * k, "AETAS", this.fitFont("display", 7.5 * k, false, 0.14, "AETAS"), FV_CK.gold);      // (espaciado 0,14: a 0,24 tocaba CHRONOMETRUM) (I3: centrado en el conjunto ranura + botones)
};
// (I3) un boton redondo de reproduccion: aro de laton, disco oscuro y su triangulo (dir +1 = ▲ futuro, −1 = ▼ pasado). Estados: "off" (en el
// tope o sin datos: mate), "idle", "hover" (filo de luz) y "on" (corriendo: disco encendido en oro y el icono pasa a «pausa»)
FVCockpit.prototype.aetasKey = function(g, cx, cy, dir, state) {
   var k = this.k, r = FV_E1TG.KR * k, ri = (FV_E1TG.KR - 2.3) * k, off = (state === "off"), on = (state === "on");
   g.fillCircle(cx + 0.7 * k, cy + 0.9 * k, r, new Brush(0x70000000));                                    // la sombra, abajo-derecha (la luz de la cabina)
   g.fillCircle(cx, cy, r, off ? new Brush(0xff5E4214) : fvBrassBrush(cx, cy, r));
   g.pen = new Pen(FV_CK.dark, Math.max(0.8, 0.8 * k)); g.drawCircle(cx, cy, r);
   var face = on ? new RadialGradientBrush(new Point(cx - 0.3 * ri, cy - 0.3 * ri), 1.4 * ri, new Point(cx - 0.3 * ri, cy - 0.3 * ri), [[0, 0xffFFF3C4], [0.55, 0xffF3D27E], [1, FV_CK.gold]])
                 : new RadialGradientBrush(new Point(cx - 0.3 * ri, cy - 0.35 * ri), 1.5 * ri, new Point(cx - 0.3 * ri, cy - 0.35 * ri), [[0, off ? 0xff2A2118 : 0xff3D2C14], [1, 0xff120D08]]);
   g.fillCircle(cx, cy, ri, face);
   g.pen = new Pen(on ? 0xff7A5A1C : FV_CK.dark, Math.max(0.7, 0.6 * k)); g.drawCircle(cx, cy, ri);
   var ink = on ? FV_CK.dark : (off ? FV_CK.brass3 : (state === "hover" ? 0xffFFF3C4 : FV_CK.gold)), u = k;
   if (on) { g.fillRect(cx - 3.0 * u, cy - 3.2 * u, cx - 0.9 * u, cy + 3.2 * u, new Brush(ink)); g.fillRect(cx + 0.9 * u, cy - 3.2 * u, cx + 3.0 * u, cy + 3.2 * u, new Brush(ink)); }
   else {
      var s = dir > 0 ? -1 : 1, oy = cy - s * 0.5 * u;                                                     // el triangulo, centrado por su baricentro
      g.pen = new Pen(ink, Math.max(0.6, 0.5 * k));
      g.fillPolygon([new Point(cx, oy + s * 3.9 * u), new Point(cx - 3.8 * u, oy - s * 2.6 * u), new Point(cx + 3.8 * u, oy - s * 2.6 * u)], new Brush(ink));
   }
   if (state === "hover" || on) { g.pen = new Pen(on ? 0xC0F3D27E : 0xffF3D27E, Math.max(1, 1.2 * k)); g.drawCircle(cx, cy, r + 1.1 * k); }
};
FVCockpit.prototype.aetasPaint = function(g, gz) {
   var k = this.k, A = this.aetas, ep = gz && gz.epoch, yrs = ep ? (ep.years || 0) : this.aetasYears, ok = ep ? !!ep.ok : this.aetasOk;
   this.aetasOk = ok; this.aetasYears = yrs;
   var e1 = this.e1t, playing = !!(e1 && this.tplay && this.tplay.on);
   var yk = A.y - FV_I4.TRAVEL * k * fvTimeToS(yrs), live = ok && (this.hover === "aetas" || this.aetasDrag || (e1 && (yrs !== 0 || playing)));
   // (I3) la ranura se llena de oro entre «hoy» y la palanca: el tiempo elegido se ve de lejos
   if (e1 && ok && Math.abs(yk - A.y) > 0.5) g.fillRect(A.x - 1.5 * k, Math.min(yk, A.y), A.x + 1.5 * k, Math.max(yk, A.y), new LinearGradientBrush(new Point(A.x - 1.5 * k, 0), new Point(A.x + 1.5 * k, 0), [[0, 0xffF3D27E], [0.5, FV_CK.gold], [1, 0xff9C7325]]));
   // la palanca: una barra de laton horizontal que corre por la ranura (apagada sin datos)
   if (this.ck3d) {                                                          // (1c) la palanca renderizada; sin datos, velada
      var spa = fvCk3dSprite(this.k3, "aetas_lever");
      if (spa) { var bx = Math.round(A.x - spa.ax), by = Math.round(yk - spa.ay); g.drawBitmap(bx, by, spa.b); if (!ok) g.fillRect(A.x - 7 * k, yk - 3 * k, A.x + 7 * k, yk + 3 * k, new Brush(0xB01B140E)); }
      if (live) { g.pen = new Pen(0xffFFF3C4, Math.max(1, 1.0 * k)); g.drawRect(A.x - 8 * k, yk - 3.8 * k, A.x + 8 * k, yk + 3.8 * k); }
   } else {
   if (ok) g.fillRect(A.x - 6.5 * k, yk - 2.4 * k, A.x + 6.5 * k, yk + 2.4 * k, fvCrownBrush(A.x, yk, 6.5 * k));
   else g.fillRect(A.x - 6.5 * k, yk - 2.4 * k, A.x + 6.5 * k, yk + 2.4 * k, new Brush(0xff4A3A20));
   g.pen = new Pen(FV_CK.dark, 0.6 * k); g.drawRect(A.x - 6.5 * k, yk - 2.4 * k, A.x + 6.5 * k, yk + 2.4 * k); g.drawLine(A.x - 4 * k, yk, A.x + 4 * k, yk);
   if (live) { g.pen = new Pen(0xffFFF3C4, 1.0 * k); g.drawRect(A.x - 8 * k, yk - 3.8 * k, A.x + 8 * k, yk + 3.8 * k); }
   }
   // la lectura: «hoy» en oro; otra epoca en bermellon (el cielo que se ve no es el de hoy); sin datos, apagada
   var txt = ok ? fvTimeText(yrs, FV_LANG) : fvTx("ck.aetasNone"), col = !ok ? FV_CK.brass3 : (yrs === 0 ? FV_CK.gold : FV_CK.verm);
   this.textC(g, A.rx, A.y + 48 * k, txt, this.fitFont("display", (e1 ? FV_E1TG.READ_PX : 6.4) * k, true, 0.02, txt), col);     // (1c) fitFont: la lectura no se ensancha hacia CHRONOMETRUM
   // (I3) los dos botones: ▲ futuro, ▼ pasado
   if (e1) {
      var dirOn = playing ? this.tplay.dir : 0, stopping = playing && this.tplay.phase === "stop";
      for (var sg = 1; sg >= -1; sg -= 2) {
         var id = sg > 0 ? "aetasFwd" : "aetasBack", st = !ok ? "off" : ((dirOn === sg && !stopping) ? "on" : (!fvTplayCan(yrs, sg) ? "off" : (this.hover === id ? "hover" : "idle")));
         this.aetasKey(g, A.kx, A.y - sg * FV_E1TG.KY * k, sg, st);
      }
      // (F2) el interruptor SOL | GALAXIA, entre los dos botones: sol (rayos) = el movimiento visto desde el Sol (lo de siempre); espiral encendida = GALAXIA
      this.aetasCanGal = !!(ep && ep.canGal); this.aetasGal = !!(ep && ep.mode === "gal");
      if (FV_TIME.GAL_ON === true) this.aetasFrameKey(g, A.kx, A.y, this.aetasGal, (!ok || !this.aetasCanGal) ? "off" : (this.hover === "aetasFrame" ? "hover" : "idle"));
   }
};
// (F2) el boton redondo SOL | GALAXIA: aro de laton y disco; SOL = un sol con sus rayos (disco oscuro, dibujo dorado); GALAXIA = una espiral de dos brazos sobre el disco encendido en oro
FVCockpit.prototype.aetasFrameKey = function(g, cx, cy, gal, state) {
   var k = this.k, r = FV_E1TG.FR * k, ri = (FV_E1TG.FR - 1.7) * k, off = (state === "off"), u = k, i, a;
   g.fillCircle(cx + 0.6 * k, cy + 0.8 * k, r, new Brush(0x70000000));
   g.fillCircle(cx, cy, r, off ? new Brush(0xff5E4214) : fvBrassBrush(cx, cy, r));
   g.pen = new Pen(FV_CK.dark, Math.max(0.8, 0.8 * k)); g.drawCircle(cx, cy, r);
   var lit = gal && !off, face = lit ? new RadialGradientBrush(new Point(cx - 0.3 * ri, cy - 0.3 * ri), 1.4 * ri, new Point(cx - 0.3 * ri, cy - 0.3 * ri), [[0, 0xffFFF3C4], [0.55, 0xffF3D27E], [1, FV_CK.gold]])
                                      : new RadialGradientBrush(new Point(cx - 0.3 * ri, cy - 0.35 * ri), 1.5 * ri, new Point(cx - 0.3 * ri, cy - 0.35 * ri), [[0, off ? 0xff2A2118 : 0xff3D2C14], [1, 0xff120D08]]);
   g.fillCircle(cx, cy, ri, face);
   g.pen = new Pen(lit ? 0xff7A5A1C : FV_CK.dark, Math.max(0.7, 0.6 * k)); g.drawCircle(cx, cy, ri);
   var ink = lit ? FV_CK.dark : (off ? FV_CK.brass3 : (state === "hover" ? 0xffFFF3C4 : FV_CK.gold));
   g.antialiasing = true;
   if (!gal) {                                                                                    // el sol: un disco y ocho rayos
      g.fillCircle(cx, cy, 1.5 * u, new Brush(ink));
      g.pen = new Pen(ink, Math.max(0.7, 0.7 * k));
      for (i = 0; i < 8; ++i) { a = i * Math.PI / 4; g.drawLine(cx + 2.4 * u * Math.cos(a), cy + 2.4 * u * Math.sin(a), cx + 3.5 * u * Math.cos(a), cy + 3.5 * u * Math.sin(a)); }
   } else {                                                                                       // la galaxia: dos brazos de espiral y el nucleo
      g.pen = new Pen(ink, Math.max(0.8, 0.8 * k));
      for (var arm = 0; arm < 2; ++arm) {
         var px = 0, py = 0;
         for (i = 0; i <= 12; ++i) { a = arm * Math.PI + i * 0.36; var rr = (0.9 + 0.2 * i) * u, x = cx + rr * Math.cos(a), y = cy + rr * Math.sin(a); if (i > 0) g.drawLine(px, py, x, y); px = x; py = y; }
      }
      g.fillCircle(cx, cy, 1.0 * u, new Brush(ink));
   }
   if (state === "hover") { g.pen = new Pen(0xffF3D27E, Math.max(1, 1.2 * k)); g.drawCircle(cx, cy, r + 1.1 * k); }
};
// (F2) pulsar el interruptor: SOL <-> GALAXIA; la escena se vuelve a aplicar en el mismo año (el motor cambia la velocidad de cada estrella, fvTimeSetMode)
FVCockpit.prototype.aetasToggleFrame = function(scene) {
   if (!scene || !this.aetasOk || !this.aetasCanGal) return false;
   var to = (typeof fvTimeMode === "function" && fvTimeMode(scene) === "gal") ? "sun" : "gal";
   if (typeof fvTimeSetMode === "function" && fvTimeSetMode(scene, to)) { this.aetasSet(scene, this.aetasYears); if (typeof fvLog === "function") fvLog("AETAS: frame " + to); return true; }
   return false;
};
// (I3) el reloj del dialogo (una vez por fotograma, fuera de todo onPaint): si la reproduccion esta en marcha, avanza el año -> true si movio la escena
FVCockpit.prototype.aetasTick = function(scene, dt) {
   if (!this.tplay || !this.tplay.on) return false;
   if (!this.aetasOk) { fvTplayHardStop(this.tplay, this.aetasYears); return false; }
   this.aetasSet(scene, fvTplayStep(this.tplay, dt));
   return true;
};
// (1c) la palanca del REGULATOR con la cabina 3D: la VARILLA pintada como un cilindro de laton (mas gruesa que la de hoy, 4,2 frente a 3,5
// unidades: la 1b renderizada se veia fina) con su sombra abajo-derecha; el POMO y el CUBO son sprites (luz direccional: igual en cualquier angulo)
FVCockpit.prototype.regLever3d = function(g, ang, a1, a2, hot) {
   var k = this.k, R = this.reg, w = 4.2 * k, ex = R.x + a1[0], ey = R.y + a1[1];
   var o = 1.1 * k; g.pen = new Pen(0x50000000, w); g.drawLine(R.x + o, R.y + o * 1.2, ex + o, ey + o * 1.2);              // la sombra
   // el cilindro: un degradado perpendicular a la varilla; la cara que mira arriba-izquierda (la luz) clara
   // perpendicular (nx, ny); si apunta hacia la luz (−1, −1), ese borde es el claro
   var a = ang * Math.PI / 180, nx = Math.cos(a), ny = Math.sin(a), lit = (-nx - ny) >= 0 ? 1 : -1, hx = nx * w / 2 * lit, hy = ny * w / 2 * lit, mx = (R.x + ex) / 2, my = (R.y + ey) / 2;
   var br = new LinearGradientBrush(new Point(mx + hx, my + hy), new Point(mx - hx, my - hy), [[0, 0xffFBE2A0], [0.28, 0xffE2B65A], [0.62, 0xffA87A2C], [1, 0xff4E3812]]);
   g.pen = new Pen(0xff3B2A0C, Math.max(0.6, 0.4 * k));
   g.fillPolygon([new Point(R.x + hx, R.y + hy), new Point(ex + hx, ey + hy), new Point(ex - hx, ey - hy), new Point(R.x - hx, R.y - hy)], br);
   this.sprite(g, "reg_knob", R.x + a2[0], R.y + a2[1]);
   if (hot) { g.pen = new Pen(0xffFFF3C4, Math.max(1, 1.2 * k)); g.drawCircle(R.x + a2[0], R.y + a2[1], 7 * k); }
   this.sprite(g, "reg_hub", R.x, R.y);
};
// el raton (lo llama el dialogo): s ∈ [−1, 1] desde la altura del puntero
FVCockpit.prototype.aetasYearsAt = function(y) { return fvTimeFromS((this.aetas.y - y) / (FV_I4.TRAVEL * this.k)); };
FVCockpit.prototype.aetasSet = function(scene, years) {
   this.aetasYears = years;
   if (scene && typeof fvTimeApply === "function") { try { fvTimeApply(scene, years); } catch (e) { if (typeof fvLog === "function") fvLog("fvTimeApply: " + e); } }
};
// h = cockpit.hit(x, y): «aetas» empieza a arrastrar (y pone la palanca donde se pulso), «aetasNow» vuelve a hoy. -> true si era suyo
FVCockpit.prototype.aetasPress = function(h, x, y, scene) {
   var key = this.e1t && (h === "aetasFwd" || h === "aetasBack");
   if (this.aetas && this.e1t && h === "aetasFrame") { if (this.aetasOk) this.aetasToggleFrame(scene); return true; }      // (F2) SOL | GALAXIA
   if (!this.aetas || (h !== "aetas" && h !== "aetasNow" && !key)) return false;
   if (!this.aetasOk) return true;
   // (I3) un boton: arranca hacia su lado, o pausa si ya corria hacia el; la palanca y la lectura cortan la reproduccion (el mando manual manda)
   if (key) { fvTplayPress(this.tplay, h === "aetasFwd" ? 1 : -1, this.aetasYears); return true; }
   if (this.tplay) fvTplayHardStop(this.tplay, this.aetasYears);
   if (h === "aetasNow") { this.aetasDrag = false; this.aetasSet(scene, 0); return true; }
   this.aetasDrag = true; this.aetasSet(scene, this.aetasYearsAt(y)); return true;
};
FVCockpit.prototype.aetasMove = function(x, y, scene) { if (!this.aetasDrag) return false; this.aetasSet(scene, this.aetasYearsAt(y)); return true; };
FVCockpit.prototype.aetasRelease = function() { var w = this.aetasDrag; this.aetasDrag = false; return w; };

// la velocidad en años luz por segundo, con las cifras justas
// angulo de la aguja de VELOCITAS para v veces c (0 → −120°, 1 c → −60°, 10¹² c → +120°)
function fvSpeedCAngle(vc) {
   if (!(vc > 0)) return -120;
   if (vc < 1) return -120 + 60 * vc;
   return -60 + 15 * Math.min(12, Math.log(vc) / Math.LN10);
}
// el año en que salio la luz de la Tierra que se ve a «back» años luz (redondeo: al año hasta 1 000, a la decena despues)
var FV_NOW_YEAR = (new Date).getFullYear();
function fvLightYearText(back) {
   var y = FV_NOW_YEAR - (Math.abs(back) < 1000 ? Math.round(back) : 10 * Math.round(back / 10)), es = (FV_LANG === "es");   // back < 0: AETAS en el futuro
   if (y > 0) return (es ? "año " : "AD ") + y;
   return (1 - y) + (es ? " a. C." : " BC");
}
// (5-nov, C-1) EL AÑO DE CHRONOMETRUM, gemelo de fwChrono / fwChronoObject / fwDistSigma / fwLightYear (web/fw_viewer.js): el objeto es el destino
// del vuelo, lo elegido o donde se llego; si no hay, la nebulosa. -> { known, d, year, txt, sig } o null (sin escena)
function fvChronoSigma(sc, sel) {
   if (!sel) return null;
   if (sel.kind === "object" && sc.objects) { var o = sc.objects[sel.i]; if (!o || o.distSrc === "assumed") return null; if (o.star >= 0 && (o.type === "star" || o.type === "exoplanet")) return fvChronoSigma(sc, { kind: "star", i: o.star }); return o.distErrLy > 0 ? Math.max(1, o.distErrLy) : 0.1 * o.distLy; }
   if (sel.kind === "star") {
      var S = sc.stars, m = S.meta[sel.i] || {}, q = S.q[sel.i];
      if (q >= 2) return null;
      if (m.lo > 0 && m.hi > 0) return Math.max(1, 0.5 * (m.hi - m.lo) * FV_LY_PER_PC);
      return 0.1 * S.dEarth[sel.i];
   }
   var N = sc.nebula; if (!N || !N.measured) return null;
   if (N.distLoLy > 0 && N.distHiLy > N.distLoLy) return Math.max(1, 0.5 * (N.distHiLy - N.distLoLy));
   return 0.1 * N.distLy;
}
function fvChronoOf(P, sc, epochYears) {
   if (!P || !sc) return null;
   var s = (P.flight && P.flight.sel) ? P.flight.sel : (P.sel || P.arrivedAt), pos = null, sel = null;
   if (s && s.kind === "star") { sel = s; pos = fvStarPos(sc, s.i); }
   else if (s && s.kind === "object" && sc.objects && sc.objects[s.i]) { sel = s; pos = sc.objects[s.i].pos; }
   else if (sc.nebula) { sel = { kind: "nebula" }; pos = sc.nebula.center || [0, 0, sc.nebula.distLy]; }
   if (!pos) return null;
   var d = fvLen(fvSub(pos, P.cam.pos)), sig = fvChronoSigma(sc, sel);
   if (!(sig > 0)) return { known: false, d: d, kind: sel.kind };
   var f = sc.field || {}, now = ((f.obsYear > 1800) ? f.obsYear : FV_NOW_YEAR) + (epochYears || 0);
   var step = Math.pow(10, Math.max(0, Math.floor(Math.log(Math.max(1, sig)) / Math.LN10))), y = now - d;
   var yr = (step <= 1) ? Math.round(y) : Math.round(y / step) * step, yh = (step > 1) ? yr : ((yr < 1) ? yr - 1 : yr);
   if (yh === 0) yh = 1;
   return { known: true, d: d, year: yh, txt: fvsFmtYear(yh, FV_LANG), sig: sig, kind: sel.kind };
}
function fvSpeedLyText(v) {
   if (!(v > 1e-4)) return "0";
   if (v < 0.01) return "< 0,01";
   if (v < 10) return v.toFixed(v < 1 ? 2 : 1).replace(".", ",");
   if (v < 1e5) return fvFmtInt(v);
   var e = Math.floor(Math.log(v) / Math.LN10), m = v / Math.pow(10, e);
   return m.toFixed(1).replace(".", ",") + "·10" + fvSup(e);
}
function fvSup(n) { var d = "⁰¹²³⁴⁵⁶⁷⁸⁹", s = String(n), o = ""; for (var i = 0; i < s.length; ++i) o += (s.charAt(i) === "-") ? "⁻" : d.charAt(Number(s.charAt(i))); return o; }
