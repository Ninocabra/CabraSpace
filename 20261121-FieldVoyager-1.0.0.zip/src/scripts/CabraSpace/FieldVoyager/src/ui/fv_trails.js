// ============================================================================
// FieldVoyager/src/ui/fv_trails.js — AETAS CON PROPOSITO en el pintor de PixInsight (encargo I3, 19-nov-2026; ficha E1-17)
// ----------------------------------------------------------------------------
// Que se pinta cuando el mando del tiempo NO esta en «hoy» (en «hoy» la foto se ve limpia: ni una linea):
//   fvTrailsPaint  las ESTELAS de ±100 000 años de las estrellas que importan (src/engine/fv_time.js, fvTrailsBuild): en oro las que cruzan
//                  la foto (las cercanas), en marfil los miembros de un cumulo (paralelas y del mismo largo: viajan en bloque) y en bermellon
//                  una candidata a fugitiva (APAGADA de fabrica: FV_TRAILS.RUN_ON, src/engine/fv_time.js). Cada estela: lo ya recorrido hasta el año elegido (se apaga con la edad), el camino que le queda
//                  (tenue), un aro donde esta HOY en tu foto y un punto donde esta en el año elegido.
//   fvTrailsHud    la PLACA del año, arriba en el centro (el año en grande: en la franja no cabe una cifra legible) con la leyenda de los
//                  colores presentes, y los ROTULOS discretos de lo notable (la mas rapida, el cumulo, la fugitiva).
// Los textos y los criterios son del motor (los mismos en el navegador: web/fw_time.js). Aqui solo se dibuja; nada de procesos.
// La bandera es FV_E1T (src/ui/fv_cockpit.js): false = no se pinta nada de esto.
// ES5.
// ============================================================================

var FV_TRAILS_UI = { COL: { cross: 0xE5B53F, group: 0xF4EAD2, run: 0xFFD25A }, SEGS: 8, W_WAKE: 1.5, W_GROUP: 1.15, W_RUN: 2.4, W_AHEAD: 0.85, RING: 3.4, HEAD: 1.8, ARROW: 28, MARGIN: 60,
                     PLATE_Y: 18, LABEL_PX: 11, LABEL_MAX: 4 };

// (I3) la ayuda de los dos botones de reproduccion de la cabina (el dialogo la pide como tipck.<id>)
(function() {
   if (typeof FV_TX === "undefined") return;
   var en = "time runs by itself up to {lim} years (about 10 seconds from today), starting and stopping gently. Click again to pause; touching the lever also stops it. " +
            "While the lever is away from today, the stars that matter leave their trail of ±100,000 years: in gold the ones that cross your photo (the nearby ones) and in ivory the members of a star cluster, " +
            "which travel together with parallel trails of the same length. Everything comes from Gaia DR3 proper motions and radial velocities.";
   var es = "el tiempo corre solo hasta {lim} años (unos 10 segundos desde hoy), arrancando y frenando con suavidad. Vuelve a pulsar para pausar; tocar la palanca también lo para. " +
            "Mientras la palanca no esté en hoy, las estrellas que importan dejan su estela de ±100 000 años: en oro las que cruzan tu foto (las cercanas) y en marfil los miembros de un cúmulo, " +
            "que viajan juntos con estelas paralelas y del mismo largo. Todo sale de los movimientos propios y las velocidades radiales de Gaia DR3.";
   var add = {
      en: { "tipck.aetasFwd": "AETAS ▲ — play towards the future: " + en.split("{lim}").join("+100,000"),
            "tipck.aetasBack": "AETAS ▼ — play towards the past: " + en.split("{lim}").join("−100,000") },
      es: { "tipck.aetasFwd": "AETAS ▲ — reproducir hacia el futuro: " + es.split("{lim}").join("+100 000"),
            "tipck.aetasBack": "AETAS ▼ — reproducir hacia el pasado: " + es.split("{lim}").join("−100 000") }
   };
   // (F2) el interruptor SOL | GALAXIA del mando AETAS
   add.en["tipck.aetasFrame"] = "AETAS · SUN | GALAXY — what the stars move against. SUN (the sun glyph): the motion you see from the Sun, as always: it carries the reflection of the Sun's own motion and of the rotation of the Galaxy, mixed with each star's own. " +
      "GALAXY (the spiral, lit): every star moves with its PECULIAR velocity, the one it has relative to the circular orbit at its own place in the Galaxy (the Sun's motion and the Galaxy's rotation taken off, Reid et al. 2019): most stars stay almost still and the ones that really run stand out. " +
      "Without radial velocity, only the sideways part is moved. Click to switch.";
   add.es["tipck.aetasFrame"] = "AETAS · SOL | GALAXIA — respecto a qué se mueven las estrellas. SOL (el dibujo del sol): el movimiento visto desde el Sol, como siempre: lleva el reflejo del movimiento del propio Sol y de la rotación de la Galaxia mezclado con lo de cada estrella. " +
      "GALAXIA (la espiral, encendida): cada estrella se mueve con su velocidad PECULIAR, la que tiene respecto a la órbita circular de su propio sitio de la Galaxia (descontados el movimiento del Sol y la rotación de la Galaxia, Reid et al. 2019): casi todas se quedan quietas y las que de verdad corren saltan a la vista. " +
      "Sin velocidad radial, solo se mueve la parte de lado. Pulsa para cambiar.";
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();

function fvTrailsUiOn(scene) { return typeof FV_E1T !== "undefined" && FV_E1T === true && !!scene && !!scene.stars && typeof fvTrailsBuild === "function"; }
function fvTrailsArgb(rgb, a) { return (((Math.round(255 * Math.max(0, Math.min(1, a))) & 255) << 24) | (rgb & 0xFFFFFF)) >>> 0; }
// recorte de un segmento al rectangulo de la vista con margen (Liang–Barsky): los extremos de una estela pueden caer a decenas de miles de
// pixeles de la pantalla y Qt no los traza bien tan lejos -> [x0, y0, x1, y1] | null
function fvTrailsClip(x0, y0, x1, y1, W, H, m) {
   var t0 = 0, t1 = 1, dx = x1 - x0, dy = y1 - y0, p = [-dx, dx, -dy, dy], q = [x0 + m, W + m - x0, y0 + m, H + m - y0];
   for (var i = 0; i < 4; ++i) {
      if (p[i] === 0) { if (q[i] < 0) return null; }
      else { var r = q[i] / p[i]; if (p[i] < 0) { if (r > t1) return null; if (r > t0) t0 = r; } else { if (r < t0) return null; if (r < t1) t1 = r; } }
   }
   return [x0 + t0 * dx, y0 + t0 * dy, x0 + t1 * dx, y0 + t1 * dy];
}
// los puntos de la estela de una estrella, proyectados: [{ t, q: [sx, sy] | null, now }] (SEGS tramos entre −R y +R, mas el año elegido)
function fvTrailsScreenPath(scene, T, pr, i, years) {
   var S = scene.stars, R = FV_TIME.RANGE_YR, n = FV_TRAILS_UI.SEGS, out = [], y = Math.max(-R, Math.min(R, years || 0)), done = false, k;
   function at(t, now) { var q = pr.project([S.x[i] + T.vx[i] * t, S.y[i] + T.vy[i] * t, S.z[i] + T.vz[i] * t]); out.push({ t: t, q: q, now: !!now }); }
   for (k = 0; k <= n; ++k) {
      var t = -R + 2 * R * k / n;
      if (!done && y < t - 1e-6) { at(y, true); done = true; }
      if (!done && Math.abs(y - t) <= 1e-6) { at(t, true); done = true; continue; }
      at(t, false);
   }
   return out;
}

// ---- las estelas (composicion normal, despues del viñeteado y antes de la ventana de la nave) ----
function fvTrailsPaint(g, painter, pr, P, W, H) {
   var st = painter.stats; st.e1t = null;
   var sc = painter.scene; if (!fvTrailsUiOn(sc)) return;
   var T = sc.time; if (!T || !T.years) return;                                   // hoy: nada
   var years = T.years, a0 = fvTrailsAlpha(years) * (1 - fvSmooth((P.trail || 0) / 0.2));   // en el warp, fuera (ya hay rayas)
   if (a0 < 0.01) return;
   var Tr = fvTrailsBuild(sc); if (!Tr || !Tr.items.length) return;
   var U = FV_TRAILS_UI, k = fvHudK(W), m = U.MARGIN, nLines = 0, nHeads = 0, nRings = 0, nItems = 0, nArrows = 0, i, s;
   var op0 = g.compositionOperator, aa0 = g.antialiasing, br0 = g.brush, pen0 = g.pen, o0 = g.opacity;
   g.compositionOperator = CompositionOp_SourceOver; g.antialiasing = true; g.opacity = 1; g.brush = new Brush(0x00000000);
   try {
      for (i = 0; i < Tr.items.length; ++i) {
         var it = Tr.items[i], col = U.COL[it.cls], path = fvTrailsScreenPath(sc, T, pr, it.i, years), grp = (it.cls === "group"), run = (it.cls === "run"), any = false;
         for (s = 0; s + 1 < path.length; ++s) {
            var A = path[s], B = path[s + 1]; if (!A.q || !B.q) continue;
            var c = fvTrailsClip(A.q[0], A.q[1], B.q[0], B.q[1], W, H, m); if (!c) continue;
            var tm = 0.5 * (A.t + B.t), wake = fvTrailsInWake(tm, years), al = a0 * fvTrailsSegAlpha(tm, years) * (grp ? 0.85 : 1);
            g.pen = new Pen(fvTrailsArgb(col, run ? Math.min(1, al * 1.15) : al), Math.max(1, (wake ? (grp ? U.W_GROUP : (run ? U.W_RUN : U.W_WAKE)) : U.W_AHEAD) * k));
            g.drawLine(c[0], c[1], c[2], c[3]); ++nLines; any = true;
         }
         if (any) ++nItems;
         for (s = 0; s < path.length; ++s) {
            var q = path[s].q; if (!q || q[0] < -m || q[1] < -m || q[0] > W + m || q[1] > H + m) continue;
            if (path[s].now) { g.fillCircle(q[0], q[1], Math.max(1.4, U.HEAD * k), new Brush(fvTrailsArgb(col, 0.95 * a0))); ++nHeads; }
            else if (path[s].t === 0 && !grp) { g.pen = new Pen(fvTrailsArgb(col, 0.7 * a0), Math.max(1, 0.9 * k)); g.drawCircle(q[0], q[1], U.RING * k); ++nRings; }   // el aro de HOY
         }
         if (run) {                                                                      // (F2) la flecha de velocidad peculiar: hacia donde corre respecto a la Galaxia, con la cabeza en el año elegido
            var ar = fvTrailsRunDir(sc, T, pr, it.i, years);
            if (ar && ar.q[0] > -m && ar.q[1] > -m && ar.q[0] < W + m && ar.q[1] < H + m) {
               var a1x = ar.q[0] + ar.d[0] * 8 * k, a1y = ar.q[1] + ar.d[1] * 8 * k, a2x = ar.q[0] + ar.d[0] * (8 + U.ARROW) * k, a2y = ar.q[1] + ar.d[1] * (8 + U.ARROW) * k, hl = 6.5 * k, hw = 3.4 * k;
               g.pen = new Pen(fvTrailsArgb(col, a0), Math.max(1.2, 1.7 * k)); g.drawLine(a1x, a1y, a2x, a2y);
               g.fillPolygon([new Point(a2x + ar.d[0] * hl * 0.55, a2y + ar.d[1] * hl * 0.55), new Point(a2x - ar.d[0] * hl * 0.45 - ar.d[1] * hw, a2y - ar.d[1] * hl * 0.45 + ar.d[0] * hw), new Point(a2x - ar.d[0] * hl * 0.45 + ar.d[1] * hw, a2y - ar.d[1] * hl * 0.45 - ar.d[0] * hw)], new Brush(fvTrailsArgb(col, a0)));
               ++nArrows;
            }
         }
      }
   } finally { g.compositionOperator = op0; g.antialiasing = aa0; g.brush = br0; g.pen = pen0; g.opacity = o0; }
   st.e1t = { years: years, alpha: Math.round(a0 * 1000) / 1000, mode: fvTimeMode(sc), arrows: nArrows, items: Tr.items.length, drawn: nItems, lines: nLines, heads: nHeads, rings: nRings, cross: Tr.nCross, group: Tr.nGroup, run: Tr.nRun, groups: Tr.groups.length };
}

// ---- la placa del año y los rotulos (en unidades del HUD, como fvHudPaint) ----
function fvTrailsHud(g, painter, pr, P, W, H) {
   painter.e1tPlate = null; painter.e1tLabels = [];
   var sc = painter.scene; if (!fvTrailsUiOn(sc)) return;
   var T = sc.time; if (!T || !T.years) return;
   var years = T.years, a0 = fvTrailsAlpha(years); if (a0 < 0.01) return;
   var U = FV_TRAILS_UI, k = fvHudK(W), M0 = null, pk = pr, L = FV_LANG;
   var op0 = g.compositionOperator, br0 = g.brush, pen0 = g.pen, o0 = g.opacity;
   g.compositionOperator = CompositionOp_SourceOver; g.antialiasing = true; g.textAntialiasing = true; g.brush = new Brush(0x00000000);
   if (Math.abs(k - 1) > 1e-6) { M0 = g.transformationMatrix; g.scaleTransformation(k, k); pk = fvHudScaledPr(pr, k); W = W / k; H = H / k; }
   try {
      g.opacity = a0;
      // 1. la placa: «AETAS  +37 200 years» y, debajo, la leyenda de los colores que hay en esta foto
      var fA = cpFont("display", 11, false, false, 3), fY = cpFont("display", 19, false, false, 1), fL = cpFont("text", 10.5), txt = fvTimeText(years, L), leg = fvTrailsLegend(sc, L), i;
      var tagM = fvTimeModeTag(sc, L), wA = fA.width("AETAS"), wY = Math.max(fY.width(fvTimeText(-1e5, L)), fY.width(fvTimeText(1e5, L))), wM = tagM ? 16 + fA.width(tagM) : 0, row1 = wA + 14 + wY + wM, row2 = 0, lw = [];
      for (i = 0; i < leg.length; ++i) { lw.push(22 + fL.width(leg[i].text)); row2 += lw[i] + (i ? 14 : 0); }
      var w = Math.round(Math.max(row1, row2) + 36), h = leg.length ? 54 : 36, x0 = Math.round((W - w) / 2), y0 = U.PLATE_Y, x1, y1;
      // la placa DATOS (plegada o abierta) manda en su esquina: si llega hasta aqui, la del año se aparta a su derecha
      var lb = painter.legendBox || painter.legendRect || null;
      if (lb && lb[2] / k + 10 > x0 && lb[1] / k < y0 + h + 6) x0 = Math.min(Math.round(W - w - 12), Math.round(lb[2] / k + 12));
      x1 = x0 + w; y1 = y0 + h;
      g.fillRect(x0, y0, x1, y1, new Brush(0xd0110D09));
      g.pen = new Pen(FV_HUD_COL.brass, 1); g.drawRect(x0 + 0.5, y0 + 0.5, x1 - 0.5, y1 - 0.5);
      g.pen = new Pen(0x70C99A3A, 0.6); g.drawRect(x0 + 3.5, y0 + 3.5, x1 - 3.5, y1 - 3.5);
      var xr = x0 + (w - row1) / 2;
      g.font = fA; g.pen = new Pen(FV_HUD_COL.gold); g.drawText(xr, y0 + 24, "AETAS");
      g.font = fY; g.pen = new Pen(FV_HUD_COL.text); g.drawText(xr + wA + 14 + (wY - fY.width(txt)) / 2, y0 + 26, txt);
      if (tagM) { g.font = fA; g.pen = new Pen(FV_HUD_COL.gold); g.drawText(xr + wA + 14 + wY + 16, y0 + 24, tagM); }      // (F2) «GALAXY»: las estrellas se mueven respecto a la Galaxia
      if (leg.length) {
         var xl = x0 + (w - row2) / 2;
         for (i = 0; i < leg.length; ++i) {
            g.pen = new Pen(fvTrailsArgb(U.COL[leg[i].cls], 1), 1.6); g.drawLine(xl, y0 + 41.5, xl + 16, y0 + 41.5);
            g.font = fL; g.pen = new Pen(FV_HUD_COL.text2); g.drawText(xl + 22, y0 + 45, leg[i].text);
            xl += lw[i] + 14;
         }
      }
      painter.e1tPlate = [x0 * k, y0 * k, x1 * k, y1 * k];
      // 2. los rotulos de lo notable: junto a la estrella en el año elegido; si ya no esta en pantalla, junto a su aro de HOY
      var notes = fvTrailsNotes(sc), fN = cpFont("text", U.LABEL_PX), used = [[x0 - 6, y0 - 6, x1 + 6, y1 + 6]], cr = painter.cardRect ? painter.cardRect.map(function(v) { return v / k; }) : null;
      if (cr) used.push(cr);
      for (i = 0; i < notes.length && i < U.LABEL_MAX; ++i) {
         var nt = notes[i], S = sc.stars, j = nt.i, col = U.COL[nt.kind];
         var q = pk.project([S.x[j] + T.vx[j] * years, S.y[j] + T.vy[j] * years, S.z[j] + T.vz[j] * years]), onHead = !!(q && q[0] > 8 && q[1] > 8 && q[0] < W - 8 && q[1] < H - 8);
         if (!onHead) {
            q = pk.project([S.x[j], S.y[j], S.z[j]]);
            if (!(q && q[0] > 8 && q[1] > 8 && q[0] < W - 8 && q[1] < H - 8)) {
               // ni la estrella ni su aro de hoy estan a la vista: el punto de su estela que se ve mas cercano al año elegido
               var bestT = 1e30, RR = FV_TIME.RANGE_YR; q = null;
               for (var ts = 0; ts <= 64; ++ts) { var tt = -RR + 2 * RR * ts / 64, qq = pk.project([S.x[j] + T.vx[j] * tt, S.y[j] + T.vy[j] * tt, S.z[j] + T.vz[j] * tt]); if (qq && qq[0] > 8 && qq[1] > 8 && qq[0] < W - 8 && qq[1] < H - 8 && Math.abs(tt - years) < bestT) { bestT = Math.abs(tt - years); q = qq; } }
               if (!q) continue;
            }
         }
         var s = cpElide(fN, fvTrailsLabel(nt, L), Math.max(120, W * 0.42)), tw = fN.width(s), th = 16, right = (q[0] + 16 + tw + 10 < W), lx = right ? q[0] + 16 : q[0] - 16 - tw, ly = q[1] - 22, tries = 0;
         if (ly < 6) ly = q[1] + 10;
         var hit = function(r) { for (var u = 0; u < used.length; ++u) { var o = used[u]; if (!(r[2] <= o[0] || o[2] <= r[0] || r[3] <= o[1] || o[3] <= r[1])) return true; } return false; };
         while (hit([lx - 5, ly - 2, lx + tw + 5, ly + th]) && tries < 12) { ly += th + 4; ++tries; }
         if (ly + th > H - 6) continue;
         used.push([lx - 5, ly - 2, lx + tw + 5, ly + th]);
         g.fillRect(lx - 5, ly - 2, lx + tw + 5, ly + th, new Brush(0xb80D0A07));
         g.pen = new Pen(fvTrailsArgb(col, 0.75), 0.8); g.drawLine(lx - 5, ly + th - 0.5, lx + tw + 5, ly + th - 0.5);
         g.drawLine(q[0] + (right ? 4 : -4), q[1] - (ly < q[1] ? 4 : -4), right ? lx - 5 : lx + tw + 5, ly + th - 0.5);                // el hilo hasta la estrella
         g.font = fN; g.pen = new Pen(FV_HUD_COL.text); g.drawText(lx, ly + 12, s);
         painter.e1tLabels.push({ kind: nt.kind, text: s, rect: [(lx - 5) * k, (ly - 2) * k, (lx + tw + 5) * k, (ly + th) * k], onHead: onHead });
      }
   } finally { if (M0) g.transformationMatrix = M0; g.compositionOperator = op0; g.brush = br0; g.pen = pen0; g.opacity = o0; }
}
