// ============================================================================
// FieldVoyager/src/ui/fv_exo_view.js — EL TRANSITO DE UN EXOPLANETA (E, F2 4-nov-2026)
// ----------------------------------------------------------------------------
// Panel de esmalte y laton sobre la escena: a la izquierda la estrella (disco con el limbo oscurecido, en su color de cuerpo negro) y
// el planeta cruzandola A ESCALA por su cuerda (parametro de impacto b); a la derecha la CURVA DE LUZ dibujandose como en el papel
// milimetrado de un registrador de epoca (tinta oscura y la plumilla bermellon). Calculos: src/science (fvsTransitSetup, fvsTransitPos,
// fvsTransitCurve, fvsTransitPhrases) con la fila de pscomppars del NASA Exoplanet Archive. La animacion repite el transito cada 9 s.
// ui.exo = { tr, row, curve, t0 }. ES5.
// ============================================================================

var FV_EXOV = { LOOP_S: 9.0, CAP_M: 28 };    // CAP_M (Blender 5 · H6): margen de la caja del rotulo del transito sobre la estrella, en unidades del HUD (0 = el 20 de Blender 4)

function fvExoPrepare(row) {
   if (typeof fvsTransitSetup !== "function") return null;
   var tr = fvsTransitSetup(row);
   if (!(tr.k > 0) || !(tr.aR > 0) || !(tr.t14 > 0)) return null;
   return { tr: tr, row: row, curve: fvsTransitCurve(tr, 320) };
}

// (pasada N, N12) «la ventana del transito es demasiado grande y tapa la estrella»: el panel de antes (900 × 338) se pinta a escala
// FV_EXOV.PANEL_S en el lado CONTRARIO a la estrella (como la ficha), y el transito se dibuja ADEMAS sobre la propia estrella: su disco con
// el limbo oscurecido y el planeta cruzando, AMPLIADO (desde la distancia de llegada el disco no se resuelve: el rotulo dice cuanto).
// pr = el proyector del HUD (ya escalado). Las zonas que se pulsan salen en coordenadas del HUD.
FV_EXOV.PANEL_S = 0.56; FV_EXOV.ON_STAR_R = 26;
var FV_R_SUN_LY = 6.957e8 / 9.4607e15;
// (Blender 2 · PL-6, 10-nov) con los mundos encendidos (FV_PL3D.ON) el panel lleva a la derecha de la curva de luz una PORTILLA con el
// planeta (la misma que la de la ficha: fase vista desde la nave, girando en su orbita). El panel se ensancha FV_EXOV.PL_W (en unidades del
// panel) y la curva de luz cede ese ancho; las frases de abajo siguen a todo el ancho. Apagado: el panel de hoy, pixel a pixel.
FV_EXOV.PL_W = 200;
function fvExoPlW(E) { return (E && E.row && typeof fvPl3dActive === "function" && fvPl3dActive() && E.tr && E.tr.aR > 0 && E.tr.Ph > 0) ? FV_EXOV.PL_W : 0; }
// ---------------------------------------------------------------------------------------------------------------------------------------
// (Blender 5 · H2) EL TEXTO DEL PANEL SE LEE A TAMAÑO REAL. Con FV_EXOV.LEGIBLE (y la portilla del mundo, es decir el panel ancho) el texto del
// panel ya no es el de Blender 4 (cuerpo 11 unidades × PANEL_S 0,56 = 6,2 px: mayusculas de 4 px, minusculas de 3 px, y con el suavizado por
// subpixel de Qt flecos de color): cada cadena se pinta UNA vez en un mapa ARGB transparente al cuerpo REAL FV_EXOV.TX_HUD (13 px del HUD:
// altura de la x ≥ 6 px a 1440, hudK 1; crece con hudK en una ventana mayor) con suavizado en gris, y se pega en pixeles enteros
// (fvExoTx). El panel se recompone para eso (fvExoLayout): la imagen de la estrella y la curva de luz se quedan arriba a escala 0,56 y el
// texto va debajo a todo el ancho; el panel es mas alto (altura segun las lineas, calculada ANTES de pintar para colocarlo).
// FV_EXOV.LEGIBLE false = el panel de Blender 4 (el ROJO de la prueba); apagado el mundo (FV_PL3D.ON false) sigue el panel de siempre.
// ---------------------------------------------------------------------------------------------------------------------------------------
FV_EXOV.LEGIBLE = true; FV_EXOV.TX_HUD = 13; FV_EXOV.LINE_HUD = 17.5; FV_EXOV.TITLE_HUD = 14.5;
var FV_EXOV_TXC = { m: {}, keys: [] };
function fvExoTxFont(role, hud, K, bold, italic, sp) { return cpFont(role, hud * K / FV_EXOV.PANEL_S, bold, italic, sp); }
// la cadena a `hud` pixeles HUD de cuerpo con la base en (ux, uy) unidades del panel (ax: 0 izquierda, 0,5 centro, 1 derecha). K = pixeles reales por
// unidad del panel. Devuelve el ancho en unidades. Pixel a pixel: la posicion se pasa por la matriz de g y se redondea
function fvExoTx(g, K, role, hud, bold, italic, sp, col, ux, uy, str, ax) {
   var f = fvExoTxFont(role, hud, K, bold, italic, sp), key = [role, f.pixelSize, bold ? 1 : 0, italic ? 1 : 0, sp || 0, col, str].join("|"), C = FV_EXOV_TXC.m[key];
   if (!C) {
      var tw = f.width(str), w = Math.ceil(tw) + 6, asc = Math.ceil(f.ascent) + 2, h = asc + Math.ceil(f.descent) + 3, b = new Bitmap(w, h, BitmapFormat.ARGB32);
      b.fill(0x00000000);
      var gb = new Graphics(b);
      try { gb.antialiasing = true; gb.textAntialiasing = true; gb.font = f; gb.pen = new Pen(col); gb.drawText(3, asc, str); } finally { gb.end(); }
      C = FV_EXOV_TXC.m[key] = { b: b, tw: tw, asc: asc };
      FV_EXOV_TXC.keys.push(key);
      if (FV_EXOV_TXC.keys.length > 200) delete FV_EXOV_TXC.m[FV_EXOV_TXC.keys.shift()];
   }
   var M = g.transformationMatrix, dx = M.at(0, 0) * ux + M.at(0, 1) * uy + M.at(0, 2), dy = M.at(1, 0) * ux + M.at(1, 1) * uy + M.at(1, 2), cop = g.compositionOperator;
   try { g.resetTransformation(); g.compositionOperator = CompositionOp_SourceOver; g.drawBitmap(Math.round(dx - C.tw * (ax || 0)) - 3, Math.round(dy) - C.asc, C.b); }
   finally { g.transformationMatrix = M; g.compositionOperator = cop; }
   return C.tw / K;
}
// la composicion del texto del panel ancho: lineas ya partidas al ancho, la fuente al pie y el alto total. E._ly se guarda por (K, idioma)
function fvExoLayout(E, K, L) {
   var key = [K.toFixed(3), L, FV_EXOV.TX_HUD].join("|");
   if (E._ly && E._ly.key === key) return E._ly;
   var s = FV_EXOV.PANEL_S, plW = FV_EXOV.PL_W, tw = 900 + plW - 40, U = 1 / s, lp = FV_EXOV.LINE_HUD * U, tr = E.tr;
   var fB = fvExoTxFont("text", FV_EXOV.TX_HUD, K, false, false), fC = fvExoTxFont("display", FV_EXOV.TX_HUD, K, false, true);
   var PH = (typeof fvsTransitPhrases === "function") ? fvsTransitPhrases(tr, L) : null, rows = [], T = [], i, j;
   T.push([fC, "cap", fvTx("exo.scale", null, L) + " · " + fvTx("exo.illus", null, L)]);
   if (PH) { T.push([fB, "ink", fvsCap(PH.size)]); T.push([fB, "ink", fvsCap(PH.depth) + "; " + PH.compare]); T.push([fB, "ink", fvsCap(PH.duration) + " · " + PH.year + " · " + PH.speed]); }
   for (i = 0; i < T.length; ++i) { var wr = fvWrap(T[i][0], T[i][2], tw * K); for (j = 0; j < wr.length; ++j) rows.push({ s: wr[j], k: T[i][1] }); }
   var zy0 = 284, y1 = zy0 + 19 + (rows.length - 1) * lp, srcY = y1 + 8 * U + lp * 0.8, ph = srcY + 14 * U;
   return (E._ly = { key: key, rows: rows, lp: lp, zy0: zy0, srcY: srcY, ph: ph, H: ph + 38, capL: fvWrap(fC, fvExoCapBind(fvTx("pl3.portTr", null, L)), (plW - 14) * K), K: K, nRows: rows.length });
}
// la altura total del lienzo del panel ancho (para quien lo pinta fuera de fvExoPanelPaint: las pruebas)
function fvExoPanelH(E, K, L) { return fvExoLayout(E, K > 0 ? K : 1, L || FV_LANG).H; }
function fvExoPanelPaintLeg(g, painter, P, W, H, ui, PL) {
   var E = ui.exo, tr = E.tr, cv = E.curve, L = FV_LANG, plW = FV_EXOV.PL_W, K = PL.k > 0 ? PL.k : 1, LY = fvExoLayout(E, K, L), pw = 900 + plW, ph = LY.ph, x0 = Math.round((W - pw) / 2), y0 = H - ph - 18;
   var cI = FV_HUD_COL.ink, cS = FV_HUD_COL.sepia, TXH = FV_EXOV.TX_HUD, i, j;
   fvEnamelPanel(g, x0, y0, x0 + pw, y0 + ph, true);
   fvExoTx(g, K, "display", FV_EXOV.TITLE_HUD, false, false, 1, cI, x0 + 20, y0 + 34, (E.demo ? fvTx("exo.demo", null, L) + " · " : "") + fvTx("exo.title", { p: E.row.pl_name }, L), 0);
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawLine(x0 + 18, y0 + 42, x0 + pw - 18, y0 + 42);
   painter.hits.push({ id: "exo-close", x0: x0 + pw - 44, y0: y0 + 8, x1: x0 + pw - 10, y1: y0 + 40 });
   fvExoTx(g, K, "display", FV_EXOV.TITLE_HUD, false, false, 0, cS, x0 + pw - 34, y0 + 34, "×", 0);
   // ---- la estrella y el planeta (arriba a la izquierda, a escala 0,56 como siempre) ----
   var half = cv.t[cv.t.length - 1], tt = ((P.t - E.t0) % FV_EXOV.LOOP_S) / FV_EXOV.LOOP_S, th = -half + 2 * half * tt, q = fvsTransitPos(tr, th);
   var bx0 = x0 + 20, by0 = y0 + 52, bs = 214, cx = bx0 + bs / 2, cy = by0 + bs / 2;
   g.fillRect(bx0, by0, bx0 + bs, by0 + bs, new Brush(0xff07060A));
   var span = Math.max(1.25, Math.abs(tr.aR * Math.sin(2 * Math.PI * half / tr.Ph)) + tr.k + 0.1), Rs = Math.min(92, (bs / 2 - 8) / span);
   var col = (typeof fvsBlackbodyColour === "function" && tr.teff > 0) ? fvsBlackbodyColour(tr.teff) : { r: 255, g: 230, b: 200 };
   g.fillCircle(cx, cy, Rs * 1.6, new RadialGradientBrush(new Point(cx, cy), Rs * 1.6, new Point(cx, cy), [[0.55, ((0x70 << 24) | (col.r << 16) | (col.g << 8) | col.b) >>> 0], [1, ((col.r << 16) | (col.g << 8) | col.b) & 0x00ffffff]]));
   for (var k = 24; k >= 1; --k) {
      var rr = k / 24, mu = Math.sqrt(Math.max(0, 1 - rr * rr)), I = 1 - tr.u1 * (1 - mu) - tr.u2 * (1 - mu) * (1 - mu);
      g.fillCircle(cx, cy, Rs * rr, new Brush((0xff000000 | (Math.round(col.r * I) << 16) | (Math.round(col.g * I) << 8) | Math.round(col.b * I)) >>> 0));
   }
   g.pen = new Pen(0x50F3D27E, 1); g.drawLine(cx - Rs * 1.5, cy - tr.b * Rs, cx + Rs * 1.5, cy - tr.b * Rs);
   var px = cx + q.x * Rs, py = cy - q.y * Rs;
   if (q.front && Math.abs(px - cx) < bs / 2 - 4 && !fvExoPl3d(g, E, q, px, py, tr.k * Rs, (painter.hudK || 1) * FV_EXOV.PANEL_S)) { g.fillCircle(px, py, Math.max(1.5, tr.k * Rs), new Brush(0xff050404)); g.pen = new Pen(0x40F3D27E, 0.8); g.drawCircle(px, py, Math.max(1.5, tr.k * Rs) + 0.5); }
   // ---- el papel milimetrado ----
   var gx0 = bx0 + bs + 82, gy0 = by0 + 26, gw = x0 + pw - 24 - gx0 - plW, gh = 150;
   fvExoPlPort(g, painter, P, E, x0 + pw - 24 - plW / 2 + 8, gy0 + 78, 76, PL, L, q, LY);
   g.fillRect(gx0, gy0, gx0 + gw, gy0 + gh, new Brush(0xffF1E8CF));
   for (i = 0; i <= gw; i += 6) { g.pen = new Pen(i % 30 === 0 ? 0x70B0783C : 0x30B0783C, i % 30 === 0 ? 0.9 : 0.5); g.drawLine(gx0 + i, gy0, gx0 + i, gy0 + gh); }
   for (i = 0; i <= gh; i += 6) { g.pen = new Pen(i % 30 === 0 ? 0x70B0783C : 0x30B0783C, i % 30 === 0 ? 0.9 : 0.5); g.drawLine(gx0, gy0 + i, gx0 + gw, gy0 + i); }
   g.pen = new Pen(0xff8A5A22, 1.2); g.drawRect(gx0, gy0, gx0 + gw, gy0 + gh);
   var dmax = Math.max(1e-5, cv.depthMax), fLo = 1 - 1.3 * dmax, fHi = 1 + 0.25 * dmax;
   function X(t) { return gx0 + (t + half) / (2 * half) * gw; }
   function Y(f) { return gy0 + (fHi - f) / (fHi - fLo) * gh; }
   for (var hh = Math.ceil(-half); hh <= Math.floor(half); ++hh) { var xh = X(hh); g.pen = new Pen(cS); g.drawLine(xh, gy0 + gh, xh, gy0 + gh + 6); fvExoTx(g, K, "text", TXH, false, false, 0, cS, xh, gy0 + gh + 26, (hh > 0 ? "+" : "") + hh, 0.5); }
   var levels = [1, 1 - dmax / 2, 1 - dmax];
   for (i = 0; i < 3; ++i) { var yl = Y(levels[i]), lt = fvNum(100 * levels[i], dmax < 0.002 ? 3 : 2, L); fvExoTx(g, K, "text", TXH, false, false, 0, cS, gx0 - 7, yl + 7, lt, 1); g.pen = new Pen(0x60A8321E, 0.6); g.drawLine(gx0, yl, gx0 + gw, yl); }
   fvExoTx(g, K, "display", TXH, false, true, 0, cS, gx0 + gw / 2, gy0 + gh + 50, fvTx("exo.hours", null, L), 0.5);
   fvExoTx(g, K, "display", TXH, false, true, 0, cS, gx0 + 2, gy0 - 7, fvTx("exo.flux", null, L), 0);
   var pts = [], ink = [];
   for (i = 0; i < cv.t.length; ++i) { var pt = new Point(X(cv.t[i]), Y(cv.f[i])); pts.push(pt); if (cv.t[i] <= th) ink.push(pt); }
   g.pen = new Pen(0x40322A20, 0.8); g.drawPolyline(pts);
   if (ink.length > 1) { g.pen = new Pen(0xff1E1810, 1.7); g.drawPolyline(ink); }
   var nib = new Point(X(th), Y(q.flux));
   g.fillCircle(nib.x, nib.y, 3.2, new Brush(0xffC0392B)); g.pen = new Pen(0xff5E1A10, 0.6); g.drawCircle(nib.x, nib.y, 3.2);
   // ---- el texto, a todo el ancho, bajo la imagen y la curva ----
   for (j = 0; j < LY.rows.length; ++j) { var rw = LY.rows[j]; fvExoTx(g, K, rw.k === "cap" ? "display" : "text", TXH, false, rw.k === "cap", 0, rw.k === "cap" ? cS : cI, bx0, y0 + LY.zy0 + 19 + j * LY.lp, rw.s, 0); }
   var fSm = fvExoTxFont("text", TXH, K, false, false);
   fvExoTx(g, K, "text", TXH, false, false, 0, cS, x0 + 20, y0 + LY.srcY, cpElide(fSm, fvTx("exo.src", null, L), (pw - 40) * K), 0);
   // las cajas (unidades del panel, origen del lienzo) para las pruebas: lo que mide la prueba esta en el FOTOGRAMA; esto solo dice donde mirar
   LY.box = [bx0, by0, bx0 + bs, by0 + bs]; LY.text = [bx0, y0 + LY.zy0, bx0 + pw - 40, y0 + LY.srcY + 8]; LY.title = [x0 + 20, y0 + 8, x0 + pw - 50, y0 + 40]; LY.graph = [gx0 - 70, gy0 - 20, gx0 + gw, gy0 + gh + 56];
   LY.origin = [x0, y0]; LY.size = [pw, ph];
}
// (Blender 5b · R5-11) el pie de la portilla («backlit · from Earth») se parte SOLO donde hay un « · »: antes salia «backlit · from / Earth». Las palabras de cada trozo van
// unidas con espacios duros (el «·» pegado al trozo de antes); FV_B5B.FMT false = el pie sin unir (lo de antes)
function fvExoCapBind(s) {
   if (!FV_B5B.FMT) return s;
   var NB = String.fromCharCode(160), segs = String(s).split(" " + String.fromCharCode(183) + " "), out = [];
   for (var i = 0; i < segs.length; ++i) out.push(segs[i].split(" ").join(NB) + (i < segs.length - 1 ? NB + String.fromCharCode(183) : ""));
   return out.join(" ");
}
function fvExoPanelPaint(g, painter, P, W, H, ui, pr) {
   var E = ui.exo, s = FV_EXOV.PANEL_S, plW = fvExoPlW(E), pw = (900 + plW) * s, ph = 338 * s, sp = null;
   // (Blender 5 · H2) el panel ancho con el texto legible es mas alto (segun las lineas): su alto sale del layout, que depende del escalado real
   var leg = !!(plW && FV_EXOV.LEGIBLE), LY = leg ? fvExoLayout(E, (painter.hudK || 1) * s, FV_LANG) : null;
   if (leg) ph = LY.ph * s;
   if (pr && E.star !== undefined && E.star !== null && painter.scene.stars) sp = pr.project(fvStarPos(painter.scene, E.star));
   var onScreen = sp && sp[0] > -20 && sp[0] < W + 20 && sp[1] > -20 && sp[1] < H + 20;
   var right = !onScreen || sp[0] < W * 0.55, X = right ? W - pw - 26 : 26, Y = onScreen ? fvClamp(sp[1] - ph / 2, 58, H - ph - 22) : H - ph - 22;
   E._hudW = W; if (onScreen) fvExoOnStar(g, painter, P, E, sp, pr);
   var M0 = g.transformationMatrix, n0 = painter.hits.length;
   g.translateTransformation(X - 20 * s, Y - 20 * s); g.scaleTransformation(s, s);
   try { fvExoPanelPaintFull(g, painter, P, 940 + plW, leg ? LY.H : 376, ui, plW ? { pr: pr, k: (painter.hudK || 1) * s } : null); } finally { g.transformationMatrix = M0; }
   for (var i = n0; i < painter.hits.length; ++i) { var h = painter.hits[i]; h.x0 = X + (h.x0 - 20) * s; h.x1 = X + (h.x1 - 20) * s; h.y0 = Y + (h.y0 - 20) * s; h.y1 = Y + (h.y1 - 20) * s; }
   painter.hits.push({ id: "exo-panel", x0: X, y0: Y, x1: X + pw, y1: Y + ph });
   painter.exoRect = [X, Y, X + pw, Y + ph];
}
// el transito sobre la estrella: disco ampliado (limbo oscurecido, color de su Teff) y la silueta del planeta, al mismo reloj que el panel
// (Blender 1, 5-nov) el planeta como MUNDO (src/ui/fv_planets3d.js: silueta, atmosfera a contraluz, incandescencia) donde hoy va la mancha
// negra. Con FV_PL3D.ON false (o sin recursos) devuelve false y se pinta lo de hoy. rPx = k·R★ en pantalla.
function fvExoPl3d(g, E, q, px, py, rPx, sc) {
   if (typeof fvPl3dActive !== "function" || !fvPl3dActive()) return false;
   if (!E.look) E.look = fvPl3dLook(E.row, E.tr);
   // (Blender 3 · D3) las bandas con el eje de giro fijo, vistas desde la Tierra (la normal de la orbita proyectada en el panel)
   if (E.band === undefined) E.band = (typeof fvsPlanetBandAngle === "function") ? fvsPlanetBandAngle(E.tr, null, null, null) : null;
   return !!fvPl3dOnStar(g, E.look, q, px, py, rPx, sc, E.band);
}
function fvExoOnStar(g, painter, P, E, sp, pr) {
   var tr = E.tr, cv = E.curve, L = FV_LANG, Rd = FV_EXOV.ON_STAR_R, cx = sp[0], cy = sp[1];
   var half = cv.t[cv.t.length - 1], tt = ((P.t - E.t0) % FV_EXOV.LOOP_S) / FV_EXOV.LOOP_S, th = -half + 2 * half * tt, q = fvsTransitPos(tr, th);
   var col = (typeof fvsBlackbodyColour === "function" && tr.teff > 0) ? fvsBlackbodyColour(tr.teff) : { r: 255, g: 230, b: 200 };
   for (var k = 16; k >= 1; --k) {
      var rr = k / 16, mu = Math.sqrt(Math.max(0, 1 - rr * rr)), I = 1 - tr.u1 * (1 - mu) - tr.u2 * (1 - mu) * (1 - mu);
      g.fillCircle(cx, cy, Rd * rr, new Brush((0xff000000 | (Math.round(col.r * I) << 16) | (Math.round(col.g * I) << 8) | Math.round(col.b * I)) >>> 0));
   }
   if (q.front) { var px = cx + q.x * Rd, py = cy - q.y * Rd; if (Math.abs(q.x) < 1.6 && !fvExoPl3d(g, E, q, px, py, tr.k * Rd, painter.hudK || 1)) g.fillCircle(px, py, Math.max(1.2, tr.k * Rd), new Brush(0xff050404)); }
   g.pen = new Pen(0xc0F3D27E, 1); g.drawCircle(cx, cy, Rd + 3);
   // cuanto esta ampliado: el radio verdadero de la estrella en la pantalla (radio solar × st_rad a la distancia de la camara)
   var stR = Number(E.row && E.row.st_rad) || 1, dc = fvLen(fvSub(fvStarPos(painter.scene, E.star), P.cam.pos)), trueR = (dc > 0) ? pr.f * stR * FV_R_SUN_LY / dc : 0;
   var z = trueR > 0 ? Rd / trueR : 0, zs = z >= 1e3 ? "10" + fvSup(Math.round(Math.log(z) / Math.LN10)) : fvNum(Math.max(1, z), 0, L);
   var f = cpFont("display", 10, false, true, 1), s = (z > 1.5) ? fvTx("exo.zoom", { z: zs }, L) : fvTx("exo.scale", null, L);
   if (E.demo) s = fvTx("exo.demo", null, L) + " · " + s;
   g.font = f; var w = f.width(s);
   // (Blender 3 · D9) el rotulo («DEMO · …») ya no se corta por la izquierda/derecha: se mete en la pantalla. Solo con los mundos encendidos
   // (apagado, el panel y la estrella quedan pixel a pixel como hoy)
   var lx = cx;
   // (Blender 4 · D9) margen 20 (antes 10): la caja se montaba 5 px sobre el marco de laton de la ventana
   // (Blender 5 · H6) con 20 la caja (borde = lx − w/2 − 6) quedaba a 14 unidades del borde de la vista: a 6 px del marco (que acaba en x 8), pegada.
   // Ahora FV_EXOV.CAP_M = 28: el borde de la caja a 22, como el de la placa DATOS (legend: x 22) y el resto del HUD
   var cm = (FV_EXOV.CAP_M > 0) ? FV_EXOV.CAP_M : 20;
   if (typeof fvPl3dActive === "function" && fvPl3dActive() && E._hudW > 0) lx = Math.max(w / 2 + cm, Math.min(E._hudW - w / 2 - cm, cx));
   else if (typeof fvPl3dActive === "function" && fvPl3dActive()) lx = Math.max(w / 2 + cm, cx);
   g.fillRect(lx - w / 2 - 6, cy + Rd + 7, lx + w / 2 + 6, cy + Rd + 22, new Brush(0xc0110D09));
   g.pen = new Pen(0xffF3D27E); g.drawText(lx - w / 2, cy + Rd + 18, s);
   E.zoom = z;
   // (Blender 4) en pixeles reales, para que fvNmPaint no ponga el rotulo DESTINO debajo del disco ni de su rotulo
   var hk = painter.hudK || 1; painter.exoOnStar = { x: cx * hk, y: cy * hk, r: (Rd + 5) * hk, cap: [(lx - w / 2 - 6) * hk, (cy + Rd + 7) * hk, (lx + w / 2 + 6) * hk, (cy + Rd + 22) * hk] };
}
// (PL-6) la portilla del mundo en el panel (unidades del panel; PL = { pr: proyector del HUD, k: pixeles reales por unidad del panel }):
// bisel de laton oscuro sobre el esmalte, el planeta limpio (sin barrido) y debajo «el mundo · ilustración»
// (Blender 3 · D5) la portilla ensena el MISMO momento que el esquema de la izquierda (q, mismo reloj) y la misma geometria: desde la Tierra,
// el planeta a contraluz delante de su estrella (fvPl3dTransitPort). La vista iluminada desde la nave queda en la ficha. Rotulo corto; lo
// largo, en el tooltip (hit «exo-plport», fv_dialog.js)
function fvExoPlPort(g, painter, P, E, cx, cy, r, PL, L, q, LY) {
   g.fillCircle(cx, cy, r + 6, new Brush(0xff2A1F15)); g.fillCircle(cx, cy, r, new Brush(0xff07060A));
   if (!E.look) E.look = fvPl3dLook(E.row, E.tr);
   var st = fvPl3dTransitPort(g, E.look, E.tr, q, cx, cy, r);
   painter.stats = painter.stats || {}; painter.stats.pl3dPanel = st;
   g.pen = new Pen(FV_HUD_COL.brassD, 1.2); g.drawCircle(cx, cy, r + 6); g.pen = new Pen(FV_HUD_COL.brass, 1); g.drawCircle(cx, cy, r + 3);
   g.pen = new Pen(0x80E5B53F, 1);
   g.drawLine(cx, cy - r + 4, cx, cy - r + 12); g.drawLine(cx, cy + r - 12, cx, cy + r - 4); g.drawLine(cx - r + 4, cy, cx - r + 12, cy); g.drawLine(cx + r - 12, cy, cx + r - 4, cy);
   if (LY) {
      // (Blender 5 · H2) el pie en 2 lineas al cuerpo legible, centrado bajo la portilla
      for (var c2 = 0; c2 < LY.capL.length; ++c2) fvExoTx(g, PL.k, "display", FV_EXOV.TX_HUD, false, true, 0, FV_HUD_COL.sepia, cx, cy + r + 24 + c2 * LY.lp, LY.capL[c2], 0.5);
      painter.hits.push({ id: "exo-plport", x0: cx - r - 6, y0: cy - r - 6, x1: cx + r + 6, y1: cy + r + 26 + LY.capL.length * LY.lp });
      return st;
   }
   var fI = cpFont("display", 10, false, true, 1), cap = fvTx("pl3.portTr", null, L);
   g.font = fI; g.pen = new Pen(FV_HUD_COL.sepia); g.drawText(cx - fI.width(cap) / 2, cy + r + 21, cap);
   painter.hits.push({ id: "exo-plport", x0: cx - r - 6, y0: cy - r - 6, x1: cx + r + 6, y1: cy + r + 26 });
   return st;
}
function fvExoPanelPaintFull(g, painter, P, W, H, ui, PL) {
   if (PL && FV_EXOV.LEGIBLE) return fvExoPanelPaintLeg(g, painter, P, W, H, ui, PL);
   var E = ui.exo, tr = E.tr, cv = E.curve, L = FV_LANG, plW = PL ? FV_EXOV.PL_W : 0;
   var pw = Math.min(W - 40, 900 + plW), ph = 338, x0 = Math.round((W - pw) / 2), y0 = H - ph - 18;
   fvEnamelPanel(g, x0, y0, x0 + pw, y0 + ph, true);
   var fT = cpFont("display", 17, false, false, 2), fS = cpFont("text", 11), fSm = cpFont("text", 10), fI = cpFont("display", 10, false, true, 1);
   g.font = fT; g.pen = new Pen(FV_HUD_COL.ink); g.drawText(x0 + 20, y0 + 30, (E.demo ? fvTx("exo.demo", null, L) + " · " : "") + fvTx("exo.title", { p: E.row.pl_name }, L));
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawLine(x0 + 18, y0 + 38, x0 + pw - 18, y0 + 38);
   painter.hits.push({ id: "exo-close", x0: x0 + pw - 40, y0: y0 + 8, x1: x0 + pw - 10, y1: y0 + 36 });
   g.font = fT; g.pen = new Pen(FV_HUD_COL.sepia); g.drawText(x0 + pw - 32, y0 + 29, "×");
   // ---- la estrella y el planeta ----
   var half = cv.t[cv.t.length - 1], tt = ((P.t - E.t0) % FV_EXOV.LOOP_S) / FV_EXOV.LOOP_S, th = -half + 2 * half * tt, q = fvsTransitPos(tr, th);
   var bx0 = x0 + 20, by0 = y0 + 50, bs = 250, cx = bx0 + bs / 2, cy = by0 + bs / 2 - 6;
   g.fillRect(bx0, by0, bx0 + bs, by0 + bs - 12, new Brush(0xff07060A));
   var span = Math.max(1.25, Math.abs(tr.aR * Math.sin(2 * Math.PI * half / tr.Ph)) + tr.k + 0.1), Rs = Math.min(92, (bs / 2 - 8) / span);
   var col = (typeof fvsBlackbodyColour === "function" && tr.teff > 0) ? fvsBlackbodyColour(tr.teff) : { r: 255, g: 230, b: 200 };
   g.fillCircle(cx, cy, Rs * 1.6, new RadialGradientBrush(new Point(cx, cy), Rs * 1.6, new Point(cx, cy), [[0.55, ((0x70 << 24) | (col.r << 16) | (col.g << 8) | col.b) >>> 0], [1, ((col.r << 16) | (col.g << 8) | col.b) & 0x00ffffff]]));
   for (var k = 24; k >= 1; --k) {                                   // limbo oscurecido: 24 anillos con I(μ) cuadratica
      var rr = k / 24, mu = Math.sqrt(Math.max(0, 1 - rr * rr)), I = 1 - tr.u1 * (1 - mu) - tr.u2 * (1 - mu) * (1 - mu);
      g.fillCircle(cx, cy, Rs * rr, new Brush((0xff000000 | (Math.round(col.r * I) << 16) | (Math.round(col.g * I) << 8) | Math.round(col.b * I)) >>> 0));
   }
   g.pen = new Pen(0x50F3D27E, 1); g.drawLine(cx - Rs * 1.5, cy - tr.b * Rs, cx + Rs * 1.5, cy - tr.b * Rs);      // la cuerda
   var px = cx + q.x * Rs, py = cy - q.y * Rs;
   if (q.front && Math.abs(px - cx) < bs / 2 - 4 && !fvExoPl3d(g, E, q, px, py, tr.k * Rs, (painter.hudK || 1) * FV_EXOV.PANEL_S)) { g.fillCircle(px, py, Math.max(1.5, tr.k * Rs), new Brush(0xff050404)); g.pen = new Pen(0x40F3D27E, 0.8); g.drawCircle(px, py, Math.max(1.5, tr.k * Rs) + 0.5); }
   // el pie, envuelto al ancho de la imagen (de una linea se metia en las frases de la derecha: f2_exoplaneta.png del 4-nov)
   g.font = fI; g.pen = new Pen(FV_HUD_COL.sepia);
   var capW = fvWrap(fI, fvTx("exo.scale", null, L) + " · " + fvTx("exo.illus", null, L), bs);
   for (var ci = 0; ci < capW.length && ci < 2; ++ci) g.drawText(bx0, by0 + bs - 2 + 12 * ci, capW[ci]);    // bajo la imagen (alto bs − 12), encima de la fuente
   // ---- el papel milimetrado ----
   // 48: las cifras del eje (100,00) caben sin pisar la imagen
   var gx0 = bx0 + bs + 48, gy0 = by0, gw = x0 + pw - 24 - gx0 - plW, gh = 170, i;
   if (PL) fvExoPlPort(g, painter, P, E, x0 + pw - 24 - plW / 2 + 8, gy0 + 80, 76, PL, L, q);
   var gwT = gw + plW;          // las frases, a todo el ancho (debajo de la curva y de la portilla)
   g.fillRect(gx0, gy0, gx0 + gw, gy0 + gh, new Brush(0xffF1E8CF));
   for (i = 0; i <= gw; i += 6) { g.pen = new Pen(i % 30 === 0 ? 0x70B0783C : 0x30B0783C, i % 30 === 0 ? 0.9 : 0.5); g.drawLine(gx0 + i, gy0, gx0 + i, gy0 + gh); }
   for (i = 0; i <= gh; i += 6) { g.pen = new Pen(i % 30 === 0 ? 0x70B0783C : 0x30B0783C, i % 30 === 0 ? 0.9 : 0.5); g.drawLine(gx0, gy0 + i, gx0 + gw, gy0 + i); }
   g.pen = new Pen(0xff8A5A22, 1.2); g.drawRect(gx0, gy0, gx0 + gw, gy0 + gh);
   var dmax = Math.max(1e-5, cv.depthMax), fLo = 1 - 1.3 * dmax, fHi = 1 + 0.25 * dmax;
   function X(t) { return gx0 + (t + half) / (2 * half) * gw; }
   function Y(f) { return gy0 + (fHi - f) / (fHi - fLo) * gh; }
   // marcas: horas enteras y tres niveles de brillo
   g.font = fSm; g.pen = new Pen(FV_HUD_COL.sepia);
   for (var hh = Math.ceil(-half); hh <= Math.floor(half); ++hh) { var xh = X(hh); g.drawLine(xh, gy0 + gh, xh, gy0 + gh + 4); var lb = (hh > 0 ? "+" : "") + hh; g.drawText(xh - fSm.width(lb) / 2, gy0 + gh + 15, lb); }
   var levels = [1, 1 - dmax / 2, 1 - dmax];
   for (i = 0; i < 3; ++i) { var yl = Y(levels[i]), lt = fvNum(100 * levels[i], dmax < 0.002 ? 3 : 2, L); g.drawText(gx0 - fSm.width(lt) - 4, yl + 4, lt); g.pen = new Pen(0x60A8321E, 0.6); g.drawLine(gx0, yl, gx0 + gw, yl); g.pen = new Pen(FV_HUD_COL.sepia); }
   g.font = fI; g.drawText(gx0 + gw / 2 - fI.width(fvTx("exo.hours", null, L)) / 2, gy0 + gh + 28, fvTx("exo.hours", null, L));
   g.drawText(gx0 + 4, gy0 - 2, fvTx("exo.flux", null, L));       // (Blender 4) a gy0 − 4 el filete del titulo (y0 + 38) cortaba 1 px de las letras
   // la curva: fantasma entero (punteado claro) y la tinta hasta ahora
   var pts = [], ink = [];
   for (i = 0; i < cv.t.length; ++i) { var pt = new Point(X(cv.t[i]), Y(cv.f[i])); pts.push(pt); if (cv.t[i] <= th) ink.push(pt); }
   g.pen = new Pen(0x40322A20, 0.8); g.drawPolyline(pts);
   if (ink.length > 1) { g.pen = new Pen(0xff1E1810, 1.7); g.drawPolyline(ink); }
   var nib = new Point(X(th), Y(q.flux));
   g.fillCircle(nib.x, nib.y, 3.2, new Brush(0xffC0392B)); g.pen = new Pen(0xff5E1A10, 0.6); g.drawCircle(nib.x, nib.y, 3.2);
   // las frases
   var PH = (typeof fvsTransitPhrases === "function") ? fvsTransitPhrases(tr, L) : null, ty = gy0 + gh + 46;
   if (PH) {
      // (Blender 3 · D5) con la portilla (panel ancho) la cuarta frase («duración: … calculada, … en la tabla de la NASA») ya cabia y repetia
      // la duracion de la tercera: se quita. Apagado, como hoy (alli no llegaba a caber)
      var lines = [fvsCap(PH.size), fvsCap(PH.depth) + "; " + PH.compare, fvsCap(PH.duration) + " · " + PH.year + " · " + PH.speed, PL ? "" : PH.check];
      g.font = fS;
      for (i = 0; i < lines.length; ++i) {
         if (!lines[i]) continue;
         var wr = fvWrap(fS, lines[i], gwT);
         for (var j = 0; j < wr.length && ty < y0 + ph - 22; ++j) { g.pen = new Pen(i === 3 ? FV_HUD_COL.sepia : FV_HUD_COL.ink); g.drawText(gx0, ty, wr[j]); ty += 14; }
      }
   }
   g.font = fSm; g.pen = new Pen(FV_HUD_COL.sepia); g.drawText(x0 + 20, y0 + ph - 12, cpElide(fSm, fvTx("exo.src", null, L), pw - 40));
}
