// ============================================================================
// FieldVoyager/src/ui/fv_search.js — EL BUSCADOR DE MIRABILIA (encargo I3 de Nino, 5-nov-2026)
// ----------------------------------------------------------------------------
// «Buscador por nombre, en la zona de MIRABILIA, en la parte de abajo.» (inspirado en NASA Eyes)
// Un campo grabado al pie de la caja MIRABILIA. Al escribir, los resultados SUSTITUYEN la lista (mientras hay texto); Esc o borrar vuelve la
// lista; Intro viaja al primero. Cada resultado es un elemento de la MISMA lista (misma forma que fvNavItems: { kind, i, name, type, dist,
// sub }), asi que la tarjeta, el clic = elegir, doble clic / flecha = viajar y la rueda son los de siempre (§11.5: nada de dos caminos).
// BUSCA EN: los objetos de MIRABILIA (TODOS los de scene.objects, no solo los 14 de la lista) · la nebulosa · los planetas conocidos ·
// las estrellas de la escena (las de la foto, con su designacion Gaia). NADA de catalogos externos.
// COINCIDENCIA: sin mayusculas ni acentos («cumulo» halla «cúmulo»); por trozos («coll»); sin espacios ni signos («ngc2392» halla «NGC 2392»,
// «j0259» halla «J025923.2+603359»); el id Gaia entero o una parte; el tipo en español o inglés («cumulo», «cluster», «galaxy»…).
// ORDEN: calidad (nombre entero > empieza por > empieza una palabra > dentro > solo el tipo) y, a igualdad, el de MIRABILIA (nebulosa
// principal, cielo profundo, estrellas notables, planetas) y luego las estrellas de la mas a la menos brillante.
// RAPIDEZ: el indice se construye UNA vez (al adjuntar la escena o cambiar de idioma), fuera de onPaint; cada tecla es un barrido de
// cadenas ya normalizadas (medido en tests/fv_nI3_test.js). Puro salvo fvSearchClock/fvTx. ES5. Gemelo web: web/fw_search.js (mismo
// nucleo; tests/fv_nI3_node.js comprueba que dan lo mismo).
// ============================================================================

var FV_SEARCH = {
   MAX: 40,                 // resultados que se guardan (la rueda los recorre)
   MAX_CHARS: 48,           // largo maximo del texto
   BLINK_S: 1.06,           // periodo del cursor
   FOLD: true,              // false = ROJO (tests/fv_nI3_test.js): sin quitar acentos, «cumulo» no halla «cúmulo»
   // palabras de cada tipo (sin acentos, en los dos idiomas: se busca «cumulo» y «cluster» igual esté la nave en el idioma que esté)
   TW: { pn: "nebulosa planetaria planetaria planetary nebula pn", galaxy: "galaxia galaxy", cluster: "cumulo de estrellas cumulo star cluster cluster open cluster",
         nebula: "nebulosa nebula", quasar: "cuasar quasar", star: "estrella star", exoplanet: "exoplaneta planeta exoplanet planet",
         other: "objeto object resto de supernova supernova remnant" }
};

var FV_SEARCH_FOLD = (function() {
   var m = {}, P = ["a:àáâãäåāăą", "c:çćĉċč", "d:ďđ", "e:èéêëēĕėęě", "g:ĝğġģ", "h:ĥħ", "i:ìíîïĩīĭįı", "j:ĵ", "k:ķ", "l:ĺļľŀł", "n:ñńņňŉ", "o:òóôõöøōŏő",
                    "r:ŕŗř", "s:śŝşš", "t:ţťŧ", "u:ùúûüũūŭůűų", "w:ŵ", "y:ýÿŷ", "z:źżž"], i, j;
   for (i = 0; i < P.length; ++i) for (j = 2; j < P[i].length; ++j) m[P[i].charAt(j)] = P[i].charAt(0);
   m["ß"] = "ss"; m["æ"] = "ae"; m["œ"] = "oe";
   return m;
})();
// minusculas y sin acentos (un caracter a la vez; los combinantes U+0300…036F se quitan)
function fvSearchFold(s) {
   var t = String(s === null || s === undefined ? "" : s).toLowerCase(), out = "", i, c, k, m, n = t.length;
   if (FV_SEARCH.FOLD === false) return t;
   for (i = 0; i < n; ++i) {
      c = t.charAt(i);
      k = t.charCodeAt(i);
      if (k < 768 || k > 879) { c = t.charAt(i); m = FV_SEARCH_FOLD[c]; out += (m !== undefined) ? m : c; }          // (los combinantes U+0300…036F se quitan)
   }
   return out;
}
// la forma de buscar: plegada, un solo espacio entre palabras, sin espacios en los bordes
function fvSearchNorm(s) { return fvSearchFold(s).replace(/\s+/g, " ").replace(/^ | $/g, ""); }
// la forma «compacta»: solo letras y cifras (ni espacios ni signos): «ngc 2392» → «ngc2392»; «j025923.2+603359» → «j0259232603359»
function fvSearchComp(s) {
   var t = fvSearchFold(s), out = "", i, k;
   for (i = 0; i < t.length; ++i) { k = t.charCodeAt(i); if ((k >= 48 && k <= 57) || (k >= 97 && k <= 122) || k >= 192) out += t.charAt(i); }
   return out;
}

// el estado del campo (lo pinta fv_nav.js; lo gobierna fv_dialog.js): text, focus y lo ultimo medido (n coincidencias, ms)
function fvSearchNew() { return { text: "", focus: false, n: 0, ms: 0 }; }
function fvSearchClock() { return (typeof fvNowMs === "function") ? fvNowMs() : (new Date).getTime(); }

// ---------------------------------------------------------------------------
// EL INDICE. scene: la escena de la nave. o: { lang, exo: [items de planetas conocidos (kind "exo")], objItem(scene, i, lang) -> item,
//   nebItem(scene, lang) -> item | null, starItem(scene, i, lang) -> item }
// -> { ents, nObj, nStar, ms, lang }
// ---------------------------------------------------------------------------
function fvSearchBuild(scene, o) {
   var t0 = fvSearchClock(), L = (o && o.lang === "es") ? "es" : "en", A = [], B = [], S = scene ? scene.stars : null, covered = {}, i, j, e, it, ob;
   if (!scene) return { ents: [], nObj: 0, nStar: 0, ms: 0, lang: L };
   function twOf(type, tl) { return fvSearchNorm((FV_SEARCH.TW[type] || FV_SEARCH.TW.other) + " " + (tl ? (tl.en || "") + " " + (tl.es || "") : "")); }
   function addFields(raw, list) { for (var q = 0; q < raw.length; ++q) if (raw[q] !== null && raw[q] !== undefined && String(raw[q]).length) list.push(String(raw[q])); }
   function starFields(k, list) {
      var m = S.meta[k] || {}, ds = (isFinite(m.ra) && isFinite(m.dec) && typeof fvDesignation === "function") ? fvDesignation(m.ra, m.dec) : "";
      if (m.sourceId) list.push("Gaia DR3 " + m.sourceId); else if (ds) list.push("Gaia DR3 " + ds);
      if (ds) list.push(ds);
      if (m.name) list.push(m.name);
   }
   function mkEnt(item, rawFields, tw, extraRank) {
      var f = [], c = [], q, nf;
      for (q = 0; q < rawFields.length; ++q) { nf = fvSearchNorm(rawFields[q]); if (nf.length) { f.push(nf); c.push(fvSearchComp(rawFields[q])); } }
      return { f: f, c: c, tw: tw, item: item, rank: (item.main ? 0 : (item.type === "exoplanet" ? 3 : (item.type === "star" ? 2 : 1))), score: item.score || 0, k: A.length + (extraRank || 0) };
   }
   // 1. los objetos de MIRABILIA (todos) y las estrellas que ya son un objeto
   if (scene.objects && scene.objects.length) {
      for (i = 0; i < scene.objects.length; ++i) {
         ob = scene.objects[i]; it = o.objItem(scene, i, L);
         var raw = [it.name];
         addFields([ob.name, ob.id && String(ob.id).replace(/^[a-z]+:/i, ""), ob.names && ob.names.en, ob.names && ob.names.es], raw);
         if (ob.planets && ob.planets.length) addFields(ob.planets, raw);
         if (ob.label) addFields([ob.label.en && ob.label.en.t, ob.label.es && ob.label.es.t, ob.label.crit], raw);      // (B, 14-nov) el rotulo («estrella mas caliente») tambien se busca, en los dos idiomas
         if (ob.star >= 0 && S && ob.star < S.n) { var sf = []; starFields(ob.star, sf); addFields(sf, raw); if (ob.type === "star" || ob.type === "exoplanet") covered[ob.star] = true; }
         A.push(mkEnt(it, raw, twOf(it.type, ob.typeLabel)));
      }
   } else if (o.nebItem) {
      it = o.nebItem(scene, L);
      if (it) A.push(mkEnt(it, [it.name, scene.nebula && scene.nebula.name, scene.nebula && scene.nebula.id], twOf("nebula", scene.nebula && scene.nebula.typeLabel)));
   }
   // 2. los planetas conocidos que MIRABILIA ofrece aparte (cuando los objetos de C no los traen)
   var ex = o.exo || [];
   for (i = 0; i < ex.length; ++i) {
      var raw2 = [ex[i].name]; if (ex[i].star >= 0 && S) { starFields(ex[i].star, raw2); }
      A.push(mkEnt(ex[i], raw2, twOf("exoplanet")));
   }
   // el orden de MIRABILIA: categoria, singularidad, orden de aparicion
   A.sort(function(a, b) { return (a.rank - b.rank) || (b.score - a.score) || (a.k - b.k); });
   // 3. las estrellas de la escena que estan en la foto (no las del cielo de alrededor ni las del modelo de la Galaxia: no tienen nombre propio)
   var twStar = twOf("star"), list = [];
   if (S) for (i = 0; i < S.n; ++i) {
      var m = S.meta[i] || {};
      if (!S.inFrame[i] || m.wide || m.outside || m.ring || covered[i]) continue;
      list.push(i);
   }
   list.sort(function(a, b) { return (S.g[a] - S.g[b]) || (a - b); });
   for (j = 0; j < list.length; ++j) {
      i = list[j]; var fl = [], f2 = [];
      starFields(i, fl);
      for (var q2 = 0; q2 < fl.length; ++q2) f2.push(fvSearchNorm(fl[q2]));
      B.push({ f: f2, c: null, tw: twStar, item: null, star: i, rank: 2, score: 0 });
   }
   var ents = A.concat(B);
   return { ents: ents, nObj: A.length, nStar: B.length, ms: fvSearchClock() - t0, lang: L };
}

// ---------------------------------------------------------------------------
// LA PUNTUACION de un campo plegado f frente a la consulta q (plegada) y sus trozos
// ---------------------------------------------------------------------------
function fvSearchScoreField(f, q, toks) {
   var p = f.indexOf(q);
   if (p === 0) return f.length === q.length ? 100 : 90;
   if (p > 0 && f.charAt(p - 1) === " ") return 75;
   if (toks.length > 1) {
      var allWord = true, k, tp;
      for (k = 0; k < toks.length; ++k) {
         tp = f.indexOf(toks[k]);
         if (tp < 0) return p > 0 ? 50 : 0;
         if (!(tp === 0 || f.charAt(tp - 1) === " ")) allWord = false;
      }
      return allWord ? 70 : 45;
   }
   return p > 0 ? 50 : 0;
}
function fvSearchScoreEnt(e, q, qc, toks, twOk) {
   var best = 0, F = e.f, C = e.c, j, s, c;
   for (j = 0; j < F.length; ++j) { s = fvSearchScoreField(F[j], q, toks); if (s > best) best = s; }
   if (best === 0 && C && qc.length >= 2) {                     // sin espacios ni signos (solo los objetos: son pocos)
      for (j = 0; j < C.length; ++j) { p = C[j].indexOf(qc); if (p >= 0) { s = (p === 0) ? 85 : 45; if (s > best) best = s; } }
   }
   var p;
   if (best === 0) {                                             // solo el tipo (o el tipo mas un trozo del nombre)
      if (twOk[e.tw] === undefined) { var ok = true, w = " " + e.tw, k; for (k = 0; k < toks.length; ++k) if (w.indexOf(" " + toks[k]) < 0) { ok = false; break; } twOk[e.tw] = ok; }
      if (twOk[e.tw]) best = 30;
      else if (C) {
         var all = F.join(" ") + " " + e.tw, ok2 = true;
         for (j = 0; j < toks.length; ++j) if (all.indexOf(toks[j]) < 0) { ok2 = false; break; }
         if (ok2) best = 20;
      }
   }
   return best;
}

// ---------------------------------------------------------------------------
// LA CONSULTA. -> { q, n (coincidencias en total), items (hasta max), ms }
// ---------------------------------------------------------------------------
function fvSearchRun(idx, text, max, o) {
   var t0 = fvSearchClock(), q = fvSearchNorm(text), out = { q: q, n: 0, items: [], ms: 0 };
   if (!q || !idx) { out.ms = fvSearchClock() - t0; return out; }
   var qc = fvSearchComp(q), toks = q.split(" "), E = idx.ents, keys = [], twOk = {}, i, s, big = 1e7;
   for (i = 0; i < E.length; ++i) { s = fvSearchScoreEnt(E[i], q, qc, toks, twOk); if (s > 0) keys.push(s * big + (big - 1 - i)); }
   keys.sort(function(a, b) { return b - a; });
   out.n = keys.length;
   var mx = Math.min(keys.length, max || FV_SEARCH.MAX);
   for (i = 0; i < mx; ++i) {
      var e = E[big - 1 - (keys[i] % big)];
      out.items.push(e.item ? e.item : (o && o.starItem ? o.starItem(e.star) : { kind: "star", i: e.star, name: "?", type: "star", sub: "" }));
   }
   out.ms = fvSearchClock() - t0;
   return out;
}

// ---------------------------------------------------------------------------
// LA TECLA → CARACTER (PixInsight da el codigo de tecla de Qt, no el texto: A…Z llegan en mayuscula; 0x20…0x7E y 0xA0…0xFF son el propio
// caracter, acentos y ñ incluidos). -> "" si no es texto
// ---------------------------------------------------------------------------
function fvSearchKeyChar(k, mod) {
   var m = mod || 0, ctl = (typeof KeyModifier_Control !== "undefined" ? KeyModifier_Control : 0x02) | (typeof KeyModifier_Meta !== "undefined" ? KeyModifier_Meta : 0x08);
   if (m & ctl) return "";
   if (!(k >= 0x20 && k <= 0x7e) && !(k >= 0xa0 && k <= 0xff)) return "";
   var ch = String.fromCharCode(k), shift = (m & (typeof KeyModifier_Shift !== "undefined" ? KeyModifier_Shift : 0x01)) !== 0;
   if (ch.toLowerCase() !== ch.toUpperCase()) ch = shift ? ch.toUpperCase() : ch.toLowerCase();
   return ch;
}

// ---------------------------------------------------------------------------
// TEXTOS (se añaden a FV_TX, como hace fv_nav.js: este fichero se incluye despues de fv_text.js)
// ---------------------------------------------------------------------------
(function() {
   var add = {
      en: { "nav.searchPh": "search by name…", "nav.noRes": "No results for “{q}”", "nav.resN": "{n} results", "nav.res1": "1 result",
            "tipck.search": "Search in MIRABILIA: a name or part of it (no capitals or accents needed: «coll», «ngc», «J0259»), a Gaia id or part of it, or a kind («cluster», «galaxy»). The results replace the list while you type; Enter travels to the first; Esc (or clearing the field) brings the list back. Key: / ." },
      es: { "nav.searchPh": "buscar por nombre…", "nav.noRes": "Sin resultados para «{q}»", "nav.resN": "{n} resultados", "nav.res1": "1 resultado",
            "tipck.search": "Buscador de MIRABILIA: un nombre o parte de él (sin mayúsculas ni acentos: «coll», «ngc», «J0259»), un id de Gaia o parte de él, o un tipo («cúmulo», «galaxia»). Los resultados sustituyen la lista mientras escribes; Intro viaja al primero; Esc (o vaciar el campo) devuelve la lista. Tecla: / ." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
