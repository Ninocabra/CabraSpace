// ============================================================================
// FieldVoyager/src/ui/fv_text.js — TEXTOS DE LA CABINA EN + ES (F2, 4-nov-2026)
// ----------------------------------------------------------------------------
// Los de la ciencia (ficha, transito, escala, viaje) estan en src/science (FVS_I18N); aqui solo lo de la nave: sistemas del
// encendido, guiños, leyenda, botones, rotulos. fvTx(clave, {param}) en el idioma de la nave (FV_LANG).
// Guiños (G): frases cortas PROPIAS o referencias de pocas palabras a la Guia del autoestopista galactico, Star Trek, Star Wars y
// Guardianes de la Galaxia; nada de citas largas, logos, imagenes ni musica. Raros y discretos: nunca tapan un dato.
// (S4, Nino 4-nov) los guiños del encendido, FUERA del todo (y el titulo de la placa pasa a «FIELD VOYAGER», S3).
// ES5.
// ============================================================================

var FV_TX = {
   en: {
      // --- encendido (D10) ---
      "boot.title": "FIELD VOYAGER",
      "boot.sub": "FieldVoyager · ship's systems",
      "boot.pull": "Pull the lever to power the ship",
      "boot.powering": "Powering up…",
      "boot.ready": "All systems ready.",
      "boot.failed": "The ship cannot fly: {why}",
      "sys.nav": "Navigation computer", "sys.nav.what": "astrometric solution",
      "sys.charts": "Star charts", "sys.charts.what": "Gaia DR3 (local)",
      "sys.range": "Long range telescope",         // (6-nov, Nino: era «Long-range rangefinder»)
      "sys.range.what": "VizieR: RUWE + Bailer-Jones",
      "sys.filters": "Optical filters", "sys.filters.what": "stars removed from the photo",
      "sys.atlas": "Nebula atlas", "sys.atlas.what": "Sharpless + SIMBAD distance",
      "sys.shields": "Deflector shields", "sys.shields.what": "3D dust map (Edenhofer 2024)",
      "sys.sensors": "Long-range sensors", "sys.sensors.what": "NASA Exoplanet Archive",
      "sys.dome": "Celestial dome", "sys.dome.what": "stars in 3D and the sky around",
      "sys.holo": "Nebula projector", "sys.holo.what": "nebula layers",
      "st.off": "off", "st.warm": "warming up", "st.ok": "ready", "st.local": "offline: local data", "st.skip": "not available",
      "do.nav": "Solving where the photo points…", "do.charts": "Reading the local Gaia DR3 star charts…",
      "do.range": "Asking VizieR for RUWE and Bailer-Jones distances… {s} s", "do.filters": "Removing the stars ({how})…",
      "do.atlas": "Asking SIMBAD for the nebula's distance… {s} s", "do.shields": "Reading the 3D dust map… {s} s",
      "do.sensors": "Asking the NASA Exoplanet Archive… {s} s", "do.dome": "Placing {n} stars in 3D…", "do.holo": "Cutting the nebula into layers…",
      // --- leyenda (placa) ---
      "leg.tab": "DATA", "leg.tabOpen": "DATA — what is measured, what is assumed",
      "leg.stars": "Stars: {m} measured · {d} doubtful · {a} with assumed distance",
      "leg.starsAss": "Assumed distances are drawn along each line of sight from a simple model of the Galaxy; they dim as you leave the Earth.",
      "leg.neb": "Nebula {n}: {d} light-years, {how}", "leg.nebMeas": "measured ({ref})", "leg.nebAss": "ASSUMED ({ref})",
      "leg.thick": "Its thickness is assumed and its relief is invented from the photo's colour and brightness.",
      "leg.ruweNo": "RUWE not checked (VizieR did not answer).", "leg.ruweOff": "RUWE not checked (offline).",
      "leg.removal": "Stars removed with {how}.",
      // --- ficha ---
      "card.more": "MORE ▸", "card.less": "◂ LESS", "card.star": "STAR", "card.neb": "EMISSION NEBULA",
      "card.meas": "MEASURED", "card.doubt": "DOUBTFUL", "card.ass": "ASSUMED",
      "card.measSrc.bj": "Bailer-Jones 2021", "card.measSrc.hip": "distance: Hipparcos 2007 (not Gaia)", "card.measSrc.plx": "Gaia DR3 parallax", "card.measSrc.cl": "cluster distance",
      "card.doubtRuwe": "RUWE {r}", "card.assWhy": "no reliable parallax: distance from a model", "card.assSrc": "galaxy model",
      "card.colPhoto": "colour: from your photo (through the dust)", "card.colBB": "colour: blackbody at {t}",
      "card.recreation": "recreation: no telescope can see its disc from here",
      "card.dustFront": "dust in front (to {d} ly): A(V) ≈ {a} mag", "card.dustNo": "dust in front: not known (3D map unavailable)",
      "card.thick": "thickness {t} ly ASSUMED · relief INVENTED", "card.sizeNo": "size: from the photo, not from a catalogue",
      "card.lumNoDust": "(not corrected for dust)",
      // (F4b) el polvo: color y temperatura verdaderos
      "card.lumDust": "(dust removed: A(G) {a} mag)",
      "card.dustRed": "In your photo it looks redder: {a} magnitudes of dust in front (A(V), 3D map of Edenhofer 2024)",
      "card.dustRedMin": "In your photo it looks redder: at least {a} magnitudes of dust in front (the 3D map ends at {d} ly)",
      "card.dustLittle": "Almost no dust in front (A(V) {a} mag): your photo shows its true colour",
      "card.dustNone": "Colour and temperature NOT corrected for dust (no 3D dust map: offline)",
      "card.dustCell": "Colour and temperature NOT corrected for dust (no dust map for this line of sight)",
      "card.dustOut": "Colour NOT corrected for dust (outside the photo: no dust map there)",
      "card.dustAss": "(to its ASSUMED distance)",
      "card.colTrue": "true colour: blackbody at {t}, dust removed · in the photo BP−RP {o}, without the dust {c} (E(BP−RP) {e})",
      "card.hot": "bluer than the end of the colour table: hotter than {t}",
      "card.teffObs": "from the reddened colour it would seem {t}",
      "leg.dust": "Star colours and temperatures: dust removed in {n} stars with the 3D map of Edenhofer et al. 2024 (to {d} ly; beyond, a lower bound). From home you see the photo's colour; next to a star, its true colour.",
      "leg.dustNo": "Star colours: from the photo, NOT corrected for dust (no 3D dust map: offline).",
      "leg.mw": "Milky Way and field stars away from home: SIMULATED from a simple model of the Galaxy, not photographed. Click to switch them off.",
      "leg.mwOff": "Simulated Milky Way and field stars: OFF. Click to switch them on.",
      "card.planet": "has a known planet: {p}",
      // --- sol / mirar a casa ---
      "sun.label": "SUN · our home", "sun.mag": "magnitude {m}", "sun.eye": "visible to the naked eye", "sun.tel": "you would need a telescope",
      // --- vuelos ---
      "cap.engage": "ENGAGE", "cap.makeitso": "MAKE IT SO", "cap.punch": "PUNCH IT", "cap.tour": "TOUR {i} / {n} · {why}",
      "why.brightest": "the brightest star", "why.largest": "the largest star", "why.hottest": "the hottest star", "why.nearest": "the nearest star",
      "why.exoplanet": "a star with a planet", "why.nebula": "the nebula", "why.hero": "the subject of your photo",
      // --- cabina ---
      "ck.modus": "MODUS", "ck.cine": "CINEMA", "ck.warp": "WARP", "ck.aTerra": "a Terra", "ck.lys": "a.l./s",
      "ck.radio": "Awesome Mix", "ck.serial": "Nº XLII", "ck.cabin": "COCKPIT", "ck.seen": "SEEN",
      "ck.lookGaia": "GAIA", "ck.lookPhcol": "COLOUR", "ck.lookPhstar": "PHOTO", "ck.lookBusy": "MEASURING…",
      "look.title": "STELLAE · MEASURING THE STARS OF YOUR PHOTO", "look.line": "cut-out of each star (once per scene)", "look.fail": "Could not measure the stars of the photo: GAIA look kept",
      // --- (F4b) REC y exportar ---
      "rec.title": "REC · RENDERING THE VIDEO", "rec.frame": "frame {n} of {N} · {w} × {h} · fixed clock {fps} fps", "rec.mp4": "making the MP4 with your ffmpeg…",
      "rec.done": "VIDEO RECORDED", "rec.info": "{n} frames · {w} × {h} · {fps} fps · {fmt}", "rec.fail": "VIDEO NOT RECORDED: {why}",
      "rec.mp4fail": "the MP4 failed ({why}): the AVI stays", "rec.nodir": "REC: no folder chosen", "rec.short": "REC: too short to make a video",
      "ex.title": "FLIGHT EXPORTED FOR THE BROWSER", "ex.open": "The viewer opens in your default browser. To open it again: index.html (double-click).",
      "ex.fail": "FLIGHT NOT EXPORTED: {why}", "ex.nodir": "EXPORT: no folder chosen",
      "nb.recCancel": "Cancel video", "rec.locked": "controls locked while the video renders · Esc or CANCEL to stop", "rec.cancelled": "VIDEO CANCELLED",
      "nb.openDir": "Open folder", "nb.changeDir": "Change folder", "nb.close": "×", "rec.next": "next videos go to {d}",
      "tip.rec": "REC: records the flight as a video. Click to start, click again to stop: the flight is re-rendered frame by frame at 1920 × 1080 and a fixed 30 fps (however slow it is). AVI · MP4: AVI needs nothing; MP4 uses the ffmpeg YOU choose (asked once). COCKPIT: with or without the instruments.",
      // --- exoplaneta ---
      "lightE.near": "The light you see left it around {y} (± {m} years), in the time of {e} ({ey}).",
      "lightE.before": "The light you see left it around {y} (± {m} years), about {n} years before {e} ({ey}).",
      "lightE.after": "The light you see left it around {y} (± {m} years), about {n} years after {e} ({ey}).",
      "exo.demo": "DEMO (not this star)", "exo.title": "TRANSIT · {p}", "exo.hours": "hours from mid-transit", "exo.flux": "brightness (%)",
      "exo.src": "NASA Exoplanet Archive (pscomppars) · circular orbit · limb darkening: grey atmosphere",
      "exo.none": "No star in this photo has a known transiting planet (NASA Exoplanet Archive, {n} rows in the field).",
      "exo.net": "The NASA Exoplanet Archive did not answer: the planets could not be checked.",
      "exo.off": "Offline: the planets were not checked.",
      "exo.go": "Exoplanet: {p} orbits a star of this photo. Click to fly there and watch the transit.",
      "exo.scale": "star and planet to scale", "exo.illus": "orbit orientation: illustrative",
      // --- botones nuevos ---
      "cap.web": "FLIGHT EXPORTED", "cap.webFail": "EXPORT FAILED (SEE CONSOLE)",
      "btn.travel": "Travel", "btn.tour": "Tour", "btn.web": "Export flight for the browser",
      "tip.travel": "Travel to the selected object. MODUS on the dashboard chooses how: CINEMA (smooth, cinematic) or WARP (spectacular). Key: Space.",
      "tip.tour": "Tour: an automatic trip through the most interesting objects of the field, with their cards. Again to stop. Key: T.",
      "tip.web": "Export flight for the browser: writes the same scene (WebGL viewer, no network, no server) to a folder you choose (remembered). Then open its index.html yourself with Chrome or Edge.",
      "tip.webSoon": "Open in browser: coming soon (F3)."
   },
   es: {
      "boot.title": "FIELD VOYAGER",
      "boot.sub": "FieldVoyager · sistemas de la nave",
      "boot.pull": "Tira de la palanca para encender la nave",
      "boot.powering": "Encendiendo…",
      "boot.ready": "Todos los sistemas listos.",
      "boot.failed": "La nave no puede volar: {why}",
      "sys.nav": "Ordenador de navegación", "sys.nav.what": "solución astrométrica",
      "sys.charts": "Cartas estelares", "sys.charts.what": "Gaia DR3 (local)",
      "sys.range": "Telescopio de largo alcance",   // (6-nov, Nino: era «Telémetro de largo alcance»)
      "sys.range.what": "VizieR: RUWE + Bailer-Jones",
      "sys.filters": "Filtros ópticos", "sys.filters.what": "estrellas quitadas de la foto",
      "sys.atlas": "Atlas de nebulosas", "sys.atlas.what": "Sharpless + distancia de SIMBAD",
      "sys.shields": "Escudos deflectores", "sys.shields.what": "mapa 3D del polvo (Edenhofer 2024)",
      "sys.sensors": "Sensores de largo alcance", "sys.sensors.what": "NASA Exoplanet Archive",
      "sys.dome": "Cúpula celeste", "sys.dome.what": "estrellas en 3D y el cielo de alrededor",
      "sys.holo": "Proyector de nebulosas", "sys.holo.what": "capas de la nebulosa",
      "st.off": "apagado", "st.warm": "calentando", "st.ok": "listo", "st.local": "sin red: datos locales", "st.skip": "no disponible",
      "do.nav": "Calculando hacia dónde apunta la foto…", "do.charts": "Leyendo las cartas estelares de Gaia DR3 (locales)…",
      "do.range": "Pidiendo a VizieR el RUWE y las distancias de Bailer-Jones… {s} s", "do.filters": "Quitando las estrellas ({how})…",
      "do.atlas": "Pidiendo a SIMBAD la distancia de la nebulosa… {s} s", "do.shields": "Leyendo el mapa 3D del polvo… {s} s",
      "do.sensors": "Preguntando al NASA Exoplanet Archive… {s} s", "do.dome": "Colocando {n} estrellas en 3D…", "do.holo": "Cortando la nebulosa en capas…",
      "leg.tab": "DATOS", "leg.tabOpen": "DATOS — qué es medido y qué es supuesto",
      "leg.stars": "Estrellas: {m} medidas · {d} dudosas · {a} con distancia supuesta",
      "leg.starsAss": "Las distancias supuestas se sortean a lo largo de cada visual con un modelo sencillo de la Galaxia; se atenúan al alejarte de la Tierra.",
      "leg.neb": "Nebulosa {n}: {d} años luz, {how}", "leg.nebMeas": "medida ({ref})", "leg.nebAss": "SUPUESTA ({ref})",
      "leg.thick": "Su grosor es supuesto y su relieve, inventado a partir del color y el brillo de la foto.",
      "leg.ruweNo": "RUWE sin comprobar (VizieR no contestó).", "leg.ruweOff": "RUWE sin comprobar (sin red).",
      "leg.removal": "Estrellas quitadas con {how}.",
      "card.more": "MÁS ▸", "card.less": "◂ MENOS", "card.star": "ESTRELLA", "card.neb": "NEBULOSA DE EMISIÓN",
      "card.meas": "MEDIDO", "card.doubt": "DUDOSO", "card.ass": "SUPUESTO",
      "card.measSrc.bj": "Bailer-Jones 2021", "card.measSrc.hip": "distancia: Hipparcos 2007 (no Gaia)", "card.measSrc.plx": "paralaje de Gaia DR3", "card.measSrc.cl": "distancia del cúmulo",
      "card.doubtRuwe": "RUWE {r}", "card.assWhy": "sin paralaje fiable: distancia de un modelo", "card.assSrc": "modelo de la Galaxia",
      "card.colPhoto": "color: el de tu foto (a través del polvo)", "card.colBB": "color: cuerpo negro a {t}",
      "card.recreation": "recreación: desde aquí ningún telescopio ve su disco",
      "card.dustFront": "polvo delante (hasta {d} a.l.): A(V) ≈ {a} mag", "card.dustNo": "polvo delante: desconocido (sin mapa 3D)",
      "card.thick": "grosor {t} a.l. SUPUESTO · relieve INVENTADO", "card.sizeNo": "tamaño: el de la foto, no de un catálogo",
      "card.lumNoDust": "(sin corregir el polvo)",
      "card.lumDust": "(sin el polvo: A(G) {a} mag)",
      "card.dustRed": "En tu foto se ve más roja: {a} magnitudes de polvo delante (A(V), mapa 3D de Edenhofer 2024)",
      "card.dustRedMin": "En tu foto se ve más roja: al menos {a} magnitudes de polvo delante (el mapa 3D acaba a {d} a.l.)",
      "card.dustLittle": "Casi sin polvo delante (A(V) {a} mag): tu foto da su color verdadero",
      "card.dustNone": "Color y temperatura SIN CORREGIR del polvo (sin mapa 3D: sin red)",
      "card.dustCell": "Color y temperatura SIN CORREGIR del polvo (sin mapa de polvo en esta visual)",
      "card.dustOut": "Color SIN CORREGIR del polvo (fuera de la foto: ahí no hay mapa)",
      "card.dustAss": "(hasta su distancia SUPUESTA)",
      "card.colTrue": "color verdadero: cuerpo negro a {t}, sin el polvo · en la foto BP−RP {o}, sin el polvo {c} (E(BP−RP) {e})",
      "card.hot": "más azul que el final de la tabla de colores: más de {t}",
      "card.teffObs": "por el color enrojecido parecería de {t}",
      "leg.dust": "Colores y temperaturas de las estrellas: polvo quitado en {n} estrellas con el mapa 3D de Edenhofer et al. 2024 (hasta {d} a.l.; más allá, un mínimo). Desde casa ves el color de la foto; junto a una estrella, su color verdadero.",
      "leg.dustNo": "Colores de las estrellas: los de la foto, SIN CORREGIR del polvo (sin mapa 3D: sin red).",
      "leg.mw": "Vía Láctea y estrellas de campo lejos de casa: SIMULADAS con un modelo de la Galaxia, no fotografiadas. Clic para apagarlas.",
      "leg.mwOff": "Vía Láctea y estrellas de campo simuladas: APAGADAS. Clic para encenderlas.",
      "card.planet": "tiene un planeta conocido: {p}",
      "sun.label": "SOL · nuestra casa", "sun.mag": "magnitud {m}", "sun.eye": "visible a simple vista", "sun.tel": "haría falta un telescopio",
      "cap.engage": "ENGAGE", "cap.makeitso": "MAKE IT SO", "cap.punch": "PUNCH IT", "cap.tour": "TOUR {i} / {n} · {why}",
      "why.brightest": "la estrella más brillante", "why.largest": "la estrella más grande", "why.hottest": "la estrella más caliente", "why.nearest": "la estrella más cercana",
      "why.exoplanet": "una estrella con planeta", "why.nebula": "la nebulosa", "why.hero": "el protagonista de tu foto",
      "ck.modus": "MODUS", "ck.cine": "CINE", "ck.warp": "WARP", "ck.aTerra": "a Terra", "ck.lys": "a.l./s",
      "ck.radio": "Awesome Mix", "ck.serial": "Nº XLII", "ck.cabin": "CABINA", "ck.seen": "VISTA",
      "ck.lookGaia": "GAIA", "ck.lookPhcol": "COLOR", "ck.lookPhstar": "FOTO", "ck.lookBusy": "MIDIENDO…",
      "look.title": "STELLAE · MIDIENDO LAS ESTRELLAS DE TU FOTO", "look.line": "recorte de cada estrella (una vez por escena)", "look.fail": "No se pudieron medir las estrellas de la foto: se queda el aspecto GAIA",
      "rec.title": "REC · RENDERIZANDO EL VÍDEO", "rec.frame": "fotograma {n} de {N} · {w} × {h} · reloj fijo a {fps} fps", "rec.mp4": "haciendo el MP4 con tu ffmpeg…",
      "rec.done": "VÍDEO GRABADO", "rec.info": "{n} fotogramas · {w} × {h} · {fps} fps · {fmt}", "rec.fail": "VÍDEO NO GRABADO: {why}",
      "rec.mp4fail": "el MP4 falló ({why}): queda el AVI", "rec.nodir": "REC: no se eligió carpeta", "rec.short": "REC: demasiado corto para un vídeo",
      "ex.title": "VUELO EXPORTADO PARA EL NAVEGADOR", "ex.open": "El visor se abre en tu navegador. Para abrirlo otra vez: index.html (doble clic).",
      "ex.fail": "VUELO NO EXPORTADO: {why}", "ex.nodir": "EXPORTAR: no se eligió carpeta",
      "nb.recCancel": "Cancelar vídeo", "rec.locked": "mandos bloqueados mientras se pinta el vídeo · Esc o CANCELAR para parar", "rec.cancelled": "VÍDEO CANCELADO",
      "nb.openDir": "Abrir carpeta", "nb.changeDir": "Cambiar carpeta", "nb.close": "×", "rec.next": "los próximos vídeos van a {d}",
      "tip.rec": "REC: graba el vuelo en vídeo. Clic para empezar y otro para parar: el vuelo se vuelve a pintar fotograma a fotograma a 1920 × 1080 y a 30 fps fijos (tarde lo que tarde). AVI · MP4: el AVI no necesita nada; el MP4 usa el ffmpeg que TÚ eliges (se pregunta una vez). CABINA: con o sin los instrumentos.",
      "lightE.near": "La luz que ves salió de allí hacia el {y} (± {m} años), por la época de {e} ({ey}).",
      "lightE.before": "La luz que ves salió de allí hacia el {y} (± {m} años), unos {n} años antes de {e} ({ey}).",
      "lightE.after": "La luz que ves salió de allí hacia el {y} (± {m} años), unos {n} años después de {e} ({ey}).",
      "exo.demo": "DEMO (no es esta estrella)", "exo.title": "TRÁNSITO · {p}", "exo.hours": "horas desde la mitad del tránsito", "exo.flux": "brillo (%)",
      "exo.src": "NASA Exoplanet Archive (pscomppars) · órbita circular · oscurecimiento del limbo: atmósfera gris",
      "exo.none": "Ninguna estrella de esta foto tiene un planeta en tránsito conocido (NASA Exoplanet Archive, {n} filas en el campo).",
      "exo.net": "El NASA Exoplanet Archive no contestó: no se pudieron buscar planetas.",
      "exo.off": "Sin red: no se buscaron planetas.",
      "exo.go": "Exoplaneta: {p} gira alrededor de una estrella de esta foto. Clic para ir allí y ver el tránsito.",
      "exo.scale": "estrella y planeta a escala", "exo.illus": "orientación de la órbita: ilustrativa",
      "cap.web": "VUELO EXPORTADO", "cap.webFail": "NO SE PUDO EXPORTAR (VER CONSOLA)",
      "btn.travel": "Viajar", "btn.tour": "Tour", "btn.web": "Exportar vuelo para el navegador",
      "tip.travel": "Viajar al objeto elegido. MODUS, en el cuadro de mandos, elige cómo: CINE (suave, de cine) o WARP (espectacular). Tecla: espacio.",
      "tip.tour": "Tour: un viaje automático por los objetos más interesantes del campo, con sus fichas. Otra vez, para. Tecla: T.",
      "tip.web": "Exportar vuelo para el navegador: escribe la misma escena (visor WebGL, sin red ni servidor) en una carpeta que eliges (recordada). Luego abre tú su index.html con Chrome o Edge.",
      "tip.webSoon": "Abrir en el navegador: próximamente (F3)."
   }
};
// (pasada N) textos nuevos: navegacion (N1), mandos de la franja con su tooltip (N2), vista inicial (N3), ficha que se cierra (N4),
// radio (N2) y transito sobre la estrella (N12). Se añaden a FV_TX sin tocar los de antes.
(function() {
   var add = {
      en: {
         "nav.ly": "ly", "nav.neb": "nebula", "nav.away": "looking away from the photo", "nav.exo": "known planet",
         "nav.empty": "Nothing singular found in this field.", "nav.wait": "Pull the lever: the list fills when the ship is powered.",
         "btn.start": "Home", "tip.start": "Home: fly back smoothly to where you began, the Earth, seeing your photo as you took it. Also double-click on the scene or key H. Key U (no button): turns the ship toward the Sun from where you are, without flying, and shows how bright the Sun would look from there.",
         "lab.info": "INFO", "lab.travel": "TRAVEL", "lab.tour": "TOUR", "lab.web": "EXPORT", "lab.start": "HOME",
         "card.close": "Close the card (Esc). The object stays selected: Travel still goes there.",
         "rec.closeNoDir": "REC not saved: no folder chosen. Still recording · close again to discard it",
         "rd.off": "OFF · click the knob", "rd.arm": "ON · click the dial to hear", "rd.tuning": "tuning… turn the knob", "rd.none": "no verified track yet", "rd.fail": "radio not available",
         "rd.wait": "radio warming up…", "rd.tab": "STATIONS ▴", "rd.tabClose": "CLOSE ▾", "rd.on": "on",
         "rd.armAt": "{id} · click the dial",      // (R3-arreglos H8) radio muda con la emisora que la persona sintonizo con la rueda
         "rd.nudge": "click the dial to play",   // (P14, 14-nov) el aviso al clicar fuera de la radio mientras esta encendida y muda
         "cap.objNoFly": "THE PILOT CANNOT FLY TO THIS OBJECT YET",
         "exo.zoom": "transit on the star, magnified ×{z}: the disc is not resolved from here",
         "tipck.rec": "REC: click to start recording the flight, click again to stop; then the video is rendered (key R).",
         "tipck.recfmt": "AVI · MP4: click to switch. AVI needs nothing; MP4 uses the ffmpeg you choose (asked once).",
         "tipck.reccab": "COCKPIT: click to record the video with or without these instruments.",
         "tipck.modus": "MODUS lever: click to switch how you travel — CINEMA (smooth, cinematic camera) or WARP (spectacular). Key M.",
         "tipck.lang": "EN · ES: click to switch the language of the ship.",
         "tipck.lookGaia": "STELLAE · GAIA: every star in the colour of its real TEMPERATURE, from Gaia (BP−RP / Teff) — the same rule for all of them: blue-white the hot ones, orange-red the cool ones. Close to a star you see its colour without the dust that reddens it in your photo. Not the colour of your photo (that is COLOUR). Remembered.",
         "tipck.lookPhcol": "STELLAE · COLOUR: each star in the colour it has in YOUR photo (its core, sky subtracted, with the green removed). Stars the photo cannot measure take their Gaia temperature colour. The drawn star of the ship (size and brightness from Gaia). Remembered.",
         "tipck.lookPhstar": "STELLAE · PHOTO: each star as it looks in YOUR photo — its own cut-out (sky subtracted, soft edge). From home the view is your photo; flying, the cut-out grows and dims like the drawn star, and when it would look magnified and soft it blends into the drawn star (in the COLOUR look). Stars without a cut-out keep the COLOUR look. Measured once. Remembered.",
         "tipck.reg": "REGULATOR: drag the lever to set the warp power (how hard the WARP pushes). The thin red needle shows the power in use.",
         "tipck.radioTab": "STATIONS: open the radio panel — your music folder and the free tracks (downloaded only when you press their button).",
         "tipck.radioInfo": "RADIOPHONIA: click the lamp to switch on or off, drag the knob round to tune.",
         "tipck.radioNudge": "RADIOPHONIA is on but silent: PixInsight only lets sound start after a click on the dial itself (a click on the 3D view does not count). Click the dial once and it plays.",
         "tipck.gV": "VELOCITAS (indicator): speed in multiples of the speed of light; red mark: warp 9.975 = 5,160 c (the trip is compressed in time).",
         "tipck.gVseen": "VELOCITAS (indicator), navigation v5 — the SEEN plate: the needle shows the speed you SEE in the flight space (stretched sideways so that the turns read well), not the physical speed, so the “c” mark is a guide, not a measure. With the classic navigation (L) it is the physical speed.",
         "tipck.gD": "DISTANTIA (indicator): distance to the Earth in light-years.",
         "tipck.gT": "CHRONOMETRUM (indicator): the year in which the light you are seeing now left the object you are travelling to (or the nebula), from where the camera is. Rounded to the error of the distance; it follows AETAS. Short hand: millennia (XII = 12,000 years); long hand: centuries.",
         "tipck.plate": "The maker's plate (indicator).",
         "tipck.padLeft": "VIEW · left: turn the camera's view to the left without moving. One click = one step; hold = keep turning. The same as the ← key (or A). If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
         "tipck.padRight": "VIEW · right: turn the camera's view to the right without moving. One click = one step; hold = keep turning. The same as the → key (or D). If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
         "tipck.padUp": "VIEW · up: turn the camera's view up without moving. One click = one step; hold = keep turning. The same as the Page Up key. If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
         "tipck.padDown": "VIEW · down: turn the camera's view down without moving. One click = one step; hold = keep turning. The same as the Page Down key. If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
         "tipck.padHub": "BRAKE: brings the ship smoothly to a stop from whatever speed it has (cine trip, warp, route, tour, wheel or keys), with no drift afterwards. How long it takes is set by the REGULATOR (slow = long brake). Afterwards the ship keeps looking into your photo.",
         "nav.banner": "SPACE · outside your photo — H to return", "nav.note": "Behind the nebula: {b} beyond it · TRAVEL to go there (Space mode)",
         "nav.m.photoTip": "Click to fly back to your photo (the arrow shows which way it is)", "nav.m.photo": "YOUR PHOTO", "nav.m.home": "HOME", "nav.m.target": "TARGET", "nav.cEarth": "EARTH", "nav.cPhoto": "PHOTO", "nav.ly": "ly",
         "tipck.map2d": "TABULA: your photo with what the camera is looking at (gold outline) and the ship (dot). Click = look there · double-click = go there.",
         "tipck.map3d": "PROFUNDITAS (indicator): the field in 3D — the cone of your photo from the Earth, stars at their distances (log scale), the nebula slab and the ship with its gaze.",
         "tipck.list": "MIRABILIA: the most singular things in your photo. Click = select (its card) · double-click or the arrow = go there. Wheel = scroll.",
         "tipck.listGo": "Go there (the trip uses MODUS: CINEMA or WARP)."
      },
      es: {
         "nav.ly": "a.l.", "nav.neb": "nebulosa", "nav.away": "mirando fuera de la foto", "nav.exo": "planeta conocido",
         "nav.empty": "No se encontró nada singular en este campo.", "nav.wait": "Tira de la palanca: la lista se llena al encender la nave.",
         "btn.start": "Inicio", "tip.start": "Inicio: vuelve volando suave a donde empezaste, la Tierra, viendo tu foto como la hiciste. También doble clic en la escena o tecla H. Tecla U (sin botón): gira la nave hacia el Sol desde donde estés, sin volar, y enseña cuánto brillaría el Sol visto desde allí.",
         "lab.info": "INFO", "lab.travel": "VIAJAR", "lab.tour": "TOUR", "lab.web": "EXPORTAR", "lab.start": "INICIO",
         "card.close": "Cerrar la ficha (Esc). El objeto sigue elegido: Viajar sigue yendo allí.",
         "rec.closeNoDir": "REC sin guardar: no se eligió carpeta. Sigue grabando · cierra otra vez para descartarlo",
         "rd.off": "APAGADA · clic en el mando", "rd.arm": "ENCENDIDA · clic en el dial", "rd.tuning": "sintonizando… gira el mando", "rd.none": "sin pista verificada", "rd.fail": "radio no disponible",
         "rd.wait": "calentando la radio…", "rd.tab": "EMISORAS ▴", "rd.tabClose": "CERRAR ▾", "rd.on": "encendida",
         "rd.armAt": "{id} · pulsa el dial",
         "rd.nudge": "pulsa el dial para que suene",
         "cap.objNoFly": "EL PILOTO AÚN NO SABE IR A ESTE OBJETO",
         "exo.zoom": "tránsito sobre la estrella, ampliado ×{z}: desde aquí el disco no se resuelve",
         "tipck.rec": "REC: clic para empezar a grabar el vuelo y otro para parar; entonces se pinta el vídeo (tecla R).",
         "tipck.recfmt": "AVI · MP4: clic para cambiar. El AVI no necesita nada; el MP4 usa el ffmpeg que elijas (se pregunta una vez).",
         "tipck.reccab": "CABINA: clic para grabar el vídeo con o sin estos instrumentos.",
         "tipck.modus": "Palanca MODUS: clic para cambiar cómo se viaja — CINE (cámara suave, de cine) o WARP (espectacular). Tecla M.",
         "tipck.lang": "EN · ES: clic para cambiar el idioma de la nave.",
         "tipck.lookGaia": "STELLAE · GAIA: todas las estrellas con el color de su TEMPERATURA real, la de Gaia (BP−RP / Teff), con la misma regla para todas: blanco azuladas las calientes, naranja rojizas las frías. Junto a una estrella ves su color sin el polvo que la enrojece en tu foto. No es el color de tu foto (ese es COLOR). Se recuerda.",
         "tipck.lookPhcol": "STELLAE · COLOR: cada estrella con el color que tiene en TU foto (su núcleo, cielo restado, y sin el verde). Las que la foto no deja medir toman el color de su temperatura de Gaia. La estrella dibujada de la nave (tamaño y brillo de Gaia). Se recuerda.",
         "tipck.lookPhstar": "STELLAE · FOTO: cada estrella como se ve en TU foto — su propio recorte (cielo restado, borde suave). Desde casa la vista es tu foto; al volar, el recorte crece y se apaga como la estrella dibujada y, cuando se vería ampliado y blando, se funde con la estrella dibujada (con el color de COLOR). Las que no tienen recorte siguen como COLOR. Se mide una vez. Se recuerda.",
         "tipck.reg": "REGULATOR: arrastra la palanca para fijar la potencia del warp (cuánto empuja el WARP). La aguja roja fina marca la potencia en uso.",
         "tipck.radioTab": "EMISORAS: abre el panel de la radio — tu carpeta de música y las pistas libres (solo se bajan al pulsar su botón).",
         "tipck.radioInfo": "RADIOPHONIA: clic en la lámpara para encender o apagar; arrastra el mando en círculo para sintonizar.",
         "tipck.radioNudge": "RADIOPHONIA está encendida pero muda: PixInsight solo deja sonar tras un clic en el propio dial (un clic en la vista 3D no cuenta). Pulsa el dial una vez y suena.",
         "tipck.gV": "VELOCITAS (indicador): velocidad en veces la de la luz; marca roja: warp 9,975 = 5 160 c (el viaje va comprimido en el tiempo).",
         "tipck.gVseen": "VELOCITAS (indicador), navegación v5 — la placa VISTA: la aguja marca la velocidad que VES en el espacio de vuelo (estirado de lado para que los giros se lean bien), no la física, así que la marca « c » es una guía, no una medida. Con la navegación clásica (L) es la velocidad física.",
         "tipck.gD": "DISTANTIA (indicador): distancia a la Tierra en años luz.",
         "tipck.gT": "CHRONOMETRUM (indicador): el año en que salió la luz que ves ahora del objeto al que viajas (o de la nebulosa), desde donde está la cámara. Redondeado al error de la distancia; sigue a AETAS. Aguja corta: milenios (XII = 12 000 años); larga: siglos.",
         "tipck.plate": "La placa del fabricante (indicador).",
         "tipck.padLeft": "VISTA · izquierda: gira la mirada a la izquierda sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla ← (o A). Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella.",
         "tipck.padRight": "VISTA · derecha: gira la mirada a la derecha sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla → (o D). Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella.",
         "tipck.padUp": "VISTA · arriba: gira la mirada hacia arriba sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla RePág. Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella.",
         "tipck.padDown": "VISTA · abajo: gira la mirada hacia abajo sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla AvPág. Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella.",
         "tipck.padHub": "FRENO: para la nave con suavidad desde la velocidad que lleve (viaje de cine, warp, ruta, tour, rueda o teclas) hasta quedarse quieta, sin deriva. Lo que tarda en frenar lo marca el REGULATOR (lento = frenada larga). Después la nave sigue mirando dentro de tu foto.",
         "nav.banner": "ESPACIO · fuera de tu foto — H para volver", "nav.note": "Detrás de la nebulosa: {b} más allá · VIAJAR para ir (modo Espacio)",
         "nav.m.photoTip": "Clic para volver volando a tu foto (la flecha dice hacia dónde queda)", "nav.m.photo": "TU FOTO", "nav.m.home": "CASA", "nav.m.target": "DESTINO", "nav.cEarth": "TIERRA", "nav.cPhoto": "FOTO", "nav.ly": "a.l.",
         "tipck.map2d": "TABULA: tu foto con lo que mira la cámara (contorno dorado) y la nave (punto). Clic = mirar allí · doble clic = ir allí.",
         "tipck.map3d": "PROFUNDITAS (indicador): el campo en 3D — el cono de tu foto desde la Tierra, las estrellas a su distancia (escala logarítmica), la losa de la nebulosa y la nave con su mirada.",
         "tipck.list": "MIRABILIA: lo más singular de tu foto. Clic = elegir (su ficha) · doble clic o la flecha = ir allí. Rueda = desplazar.",
         "tipck.listGo": "Ir allí (el viaje usa MODUS: CINE o WARP)."
      }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (I4, 4-nov) la maquina del tiempo: el mando AETAS de la cabina (src/ui/fv_cockpit.js; motor src/engine/fv_time.js)
(function() {
   var add = {
      en: { "ck.aetasNone": "no data",
            "tipck.aetas": "AETAS — time machine: drag the lever up to go into the future, down into the past (up to 100,000 years; the notch in the middle is today). The stars of your photo move with their Gaia proper motion and, where Gaia measured it, their radial velocity: straight-line motion, which at this range differs from the real orbit by less than 0.1 %. Stars without radial velocity move only across the sky (their distance hardly changes). Stars without proper motion stay put.",
            "tipck.aetasNow": "The chosen epoch, from the date of your photo. Click to come back to today.",
            "tipck.aetasOff": "AETAS — time machine: this scene has no proper motions (built without them). Rebuild the scene to move the stars in time." },
      es: { "ck.aetasNone": "sin datos",
            "tipck.aetas": "AETAS — máquina del tiempo: arrastra la palanca hacia arriba para ir al futuro y hacia abajo al pasado (hasta 100 000 años; la muesca del centro es hoy). Las estrellas de tu foto se mueven con su movimiento propio de Gaia y, donde Gaia la midió, su velocidad radial: movimiento en línea recta, que a esta escala se separa de la órbita real menos de un 0,1 %. Las que no tienen velocidad radial solo se mueven por el cielo (su distancia apenas cambia). Las que no tienen movimiento propio se quedan quietas.",
            "tipck.aetasNow": "La época elegida, contada desde la fecha de tu foto. Clic para volver a hoy.",
            "tipck.aetasOff": "AETAS — máquina del tiempo: esta escena no trae movimientos propios (se construyó sin ellos). Vuelve a construir la escena para mover las estrellas en el tiempo." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo D, 9-nov) el boton GALAXIA y su vista (src/ui/fv_galaxy.js)
(function() {
   var add = {
      en: { "btn.galaxy": "Galaxy", "lab.galaxy": "GALAXY",
            "tip.galaxy": "Galaxy: where this field is in the Milky Way. The view pulls back until you see our galaxy from outside, with the Sun, the line of sight to your photo and its distance. Drag: turn the galaxy in 3D (face-on to edge-on) · wheel: closer or farther. Click without dragging (or Esc) to come back.",
            "gal.sun": "Sun", "gal.gc": "Galactic Centre", "gal.beyond": "(beyond the Milky Way, same direction)", "gal.field": "the field", "gal.title": "THE MILKY WAY", "gal.outside": "(outside the Milky Way)", "gal.mly": "Mly",
            "gal.note": "Simulated from published parameters (spiral arms: Reid et al. 2019) · far side extrapolated · click or Esc to return", "gal.note3d": "Simulated from published parameters (spiral arms: Reid et al. 2019) · far side extrapolated · drag to turn · wheel to zoom · click or Esc to return",
            "gal.arm.norma": "Norma Arm", "gal.arm.scucen": "Scutum–Centaurus Arm", "gal.arm.sgrcar": "Sagittarius–Carina Arm", "gal.arm.local": "Local Arm",
            "gal.arm.perseus": "Perseus Arm", "gal.arm.outer": "Outer Arm" },
      es: { "btn.galaxy": "Galaxia", "lab.galaxy": "GALAXIA",
            "tip.galaxy": "Galaxia: dónde está este campo en la Vía Láctea. La vista se aleja hasta ver nuestra galaxia desde fuera, con el Sol, la línea de visión hasta tu foto y su distancia. Arrastrar: girar la galaxia en 3D (de cara a de canto) · rueda: acercar o alejar. Clic sin arrastrar (o Esc) para volver.",
            "gal.sun": "Sol", "gal.gc": "Centro galáctico", "gal.beyond": "(fuera de la Vía Láctea, en la misma dirección)", "gal.field": "el campo", "gal.title": "LA VÍA LÁCTEA", "gal.outside": "(fuera de la Vía Láctea)", "gal.mly": "M a.l.",
            "gal.note": "Simulada con parámetros publicados (brazos espirales: Reid et al. 2019) · lado lejano extrapolado · clic o Esc para volver", "gal.note3d": "Simulada con parámetros publicados (brazos espirales: Reid et al. 2019) · lado lejano extrapolado · arrastrar para girar · rueda para acercar · clic o Esc para volver",
            "gal.arm.norma": "Brazo de Norma", "gal.arm.scucen": "Brazo de Escudo–Centauro", "gal.arm.sgrcar": "Brazo de Sagitario–Carina", "gal.arm.local": "Brazo Local",
            "gal.arm.perseus": "Brazo de Perseo", "gal.arm.outer": "Brazo Exterior" }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GP, 9-nov) la Via Lactea de catalogos publicos en GALAXIA (src/engine/fv_galdata.js, src/ui/fv_galaxy.js)
(function() {
   var add = {
      en: { "gal.d.note": "Measured positions on {pct} % of the disc · the rest is modelled · far side extrapolated · drag to turn · click or Esc to return",
            "gal.d.legM": "masers (parallax)", "gal.d.legH": "HII regions", "gal.d.legC": "CO clouds",
            "gal.d.far1": "far side: kinematic distances only", "gal.d.far2": "almost no direct measurements · extrapolated",
            "gal.d.solo": "DATA ONLY",
            "gal.d.tipSolo": "Data only: hide the model (spiral arms, bar, old disc) and the illustrative texture; show only the measured tracers and the smoothed gas density.",
            "gal.d.tip": "How this Milky Way is made. Measured positions: {nc} molecular clouds (CO; Miville-Deschênes, Murray & Lee 2017, CC0), {nm} masers with VLBI parallax (Reid et al. 2019) and {nh} HII regions with distance (WISE catalogue, Anderson et al. 2014). Where they are dense enough (thin gold line: confidence 0.5) the image follows them: {pct} % of the disc inside 16.5 kpc. Elsewhere it follows the model: spiral arms of Reid et al. 2019, bar and bulge of Bland-Hawthorn & Gerhard 2016, warp of Skowron et al. 2019. Cloud and HII distances are kinematic (uncertain); behind the bulge there are almost no direct measurements. Texture, grain and colour are illustration, not data." },
      es: { "gal.d.note": "Posiciones medidas en el {pct} % del disco · el resto es modelo · lado lejano extrapolado · arrastrar para girar · clic o Esc para volver",
            "gal.d.legM": "máseres (paralaje)", "gal.d.legH": "regiones HII", "gal.d.legC": "nubes de CO",
            "gal.d.far1": "lado lejano: solo distancias cinemáticas", "gal.d.far2": "casi sin medidas directas · extrapolado",
            "gal.d.solo": "SOLO DATOS",
            "gal.d.tipSolo": "Solo datos: oculta el modelo (brazos espirales, barra, disco viejo) y la textura ilustrativa; deja solo los trazadores medidos y la densidad de gas suavizada.",
            "gal.d.tip": "Cómo está hecha esta Vía Láctea. Posiciones medidas: {nc} nubes moleculares (CO; Miville-Deschênes, Murray y Lee 2017, CC0), {nm} máseres con paralaje VLBI (Reid et al. 2019) y {nh} regiones HII con distancia (catálogo WISE, Anderson et al. 2014). Donde son bastantes (línea dorada fina: confianza 0,5) la imagen las sigue: el {pct} % del disco dentro de 16,5 kpc. En el resto sigue el modelo: brazos espirales de Reid et al. 2019, barra y bulbo de Bland-Hawthorn y Gerhard 2016, alabeo de Skowron et al. 2019. Las distancias de nubes y HII son cinemáticas (inciertas); detrás del bulbo casi no hay medidas directas. La textura, el grano y el color son ilustración, no datos." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GG, 9-nov) la geometria ajustada de la galaxia propia (src/engine/fv_galgeom.js, bandera FV_GAL_GG.ON)
(function() {
   var add = {
      en: { "gal.gg.note": "Arm positions measured on {pct} % of the disc (inside the gold line) · beyond it, extrapolated from the symmetry of the arms · drag to turn · click or Esc to return",
            "gal.gg.far1": "arm positions extrapolated (±{kpc} kpc)",
            "gal.gg.far2": "beyond the gold line: few direct measurements",
            "gal.gg.tip": "How this Milky Way is drawn. Shape: spiral arms fitted to {nh} HII regions and {nc} molecular clouds (only clouds massive enough to be seen out to 14 kpc, so the sample is uniform; Miville-Deschênes, Murray & Lee 2017; WISE catalogue, Anderson et al. 2014), taking the arm positions measured with {nm} maser parallaxes (Reid et al. 2019) as the starting point and modelling what each catalogue can and cannot see. Beyond the measured stretches each arm continues towards the shape of its partner arm turned 180° (Scutum–Centaurus and Perseus, Norma and Sagittarius–Carina, the two 3 kpc arms: Dame & Thaddeus 2008); the error of that continuation was measured by hiding stretches of real arms and predicting them (about ±{kpc} kpc 40° beyond the data). The thin gold line is where the position error reaches the width of the arm: inside it ({pct} % of the disc within 16.5 kpc) the arms are measured. Old disc with the two-armed pattern of Drimmel & Spergel 2001; dust lanes on the inner edge of the arms inside corotation; the far side drawn with the same contrast as the near side (the gold line and the label say where it is extrapolated)." },
      es: { "gal.gg.note": "Posición de los brazos medida en el {pct} % del disco (dentro de la línea dorada) · fuera, extrapolada con la simetría de los brazos · arrastrar para girar · clic o Esc para volver",
            "gal.gg.far1": "posición de los brazos extrapolada (±{kpc} kpc)",
            "gal.gg.far2": "fuera de la línea dorada: pocas medidas directas",
            "gal.gg.tip": "Cómo está dibujada esta Vía Láctea. Forma: brazos espirales ajustados a {nh} regiones HII y {nc} nubes moleculares (solo las nubes con masa para verse hasta 14 kpc, para que la muestra sea homogénea; Miville-Deschênes, Murray y Lee 2017; catálogo WISE, Anderson et al. 2014), partiendo de las posiciones de los brazos medidas con {nm} paralajes de máseres (Reid et al. 2019) y modelando lo que cada catálogo puede y no puede ver. Más allá de los tramos medidos cada brazo sigue hacia la forma de su brazo pareja girado 180° (Escudo–Centauro y Perseo, Norma y Sagitario–Carina, los dos brazos de 3 kpc: Dame y Thaddeus 2008); el error de esa continuación se midió ocultando tramos de brazos reales y prediciéndolos (unos ±{kpc} kpc a 40° del dato). La línea dorada fina es donde el error de posición llega a la anchura del brazo: dentro ({pct} % del disco hasta 16,5 kpc) los brazos están medidos. Disco viejo con el patrón de dos brazos de Drimmel y Spergel 2001; polvo en el borde interior de los brazos dentro de la corrotación; el lado lejano con el mismo contraste que el cercano (la línea dorada y el rótulo dicen dónde está extrapolado)." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF2, 9-nov) la galaxia final corregida (FV_GAL_GF2.ON, con color real + datos + geometria ajustada): lo que el tooltip tiene que decir
(function() {
   var add = {
      en: { "gal.gf2.tip": "Colour: hue from the calibration (white = average spiral galaxy, SPCC), shown with a colour-preserving stretch (same factor on R, G and B, like ArcsinhStretch) and a display saturation of ×{sat} (a display choice): it makes the calibrated hue visible, it does not change it. Golden bulge and bar = old stars; bluish-white arms = young stars; pink knots = HII regions. Bar: half-length about 5 kpc at 28° from the Sun–centre line (Bland-Hawthorn & Gerhard 2016), with straight dust lanes on its leading edges (Athanassoula 1992); the two main arms start at the bar ends (Benjamin 2008). The measured points (masers and HII regions) are not drawn here, so that the picture does not show where we happen to have measurements: tick DATA ONLY to see them." },
      es: { "gal.gf2.tip": "Color: tono de la calibración (blanco = galaxia espiral media, SPCC), mostrado con un estiramiento que conserva el color (el mismo factor en R, G y B, como ArcsinhStretch) y una saturación de pantalla ×{sat} (una elección de presentación): hace visible el tono calibrado, no lo cambia. Bulbo y barra dorados = estrellas viejas; brazos blanco-azulados = estrellas jóvenes; nudos rosas = regiones HII. Barra: semilongitud de unos 5 kpc a 28° de la línea Sol–centro (Bland-Hawthorn y Gerhard 2016), con líneas de polvo rectas en sus bordes de ataque (Athanassoula 1992); los dos brazos principales nacen en los extremos de la barra (Benjamin 2008). Los puntos medidos (máseres y regiones HII) no se dibujan aquí, para que la imagen no muestre dónde da la casualidad de que hay medidas: marca SOLO DATOS para verlos." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF3, 10-nov) la galaxia GF2 corregida (FV_GAL_GF3.ON): el tooltip sustituye al de GF2 (carriles curvos, brazos menores, nudos de muestra, pantalla)
(function() {
   var add = {
      en: { "gal.gf3.tip": "Colour: hue from the calibration (white = average spiral galaxy, SPCC), shown with a colour-preserving stretch (same factor on R, G and B, like ArcsinhStretch) with a soft shoulder so that the centre is not burnt to white, and a display saturation of ×{sat} that is applied in full only to weakly coloured light (a display choice): it makes the calibrated hue visible, it does not change it. Golden bulge and bar = old stars; bluish-white arms = young stars, with star clouds; pink knots = HII regions placed along the arms as an illustration (they are not catalogue positions). Bar: half-length about 5 kpc at 28° from the Sun–centre line (Bland-Hawthorn & Gerhard 2016); its dust lanes run along the leading edges, curve at the bar ends and join the inner edge of the arms (Athanassoula 1992). Minor arms (Local Arm, Sagittarius–Carina, Norma) are fainter than the two main arms (Reid et al. 2019). The measured points (masers and HII regions) are not drawn here, so that the picture does not show where we happen to have measurements: tick DATA ONLY to see them." },
      es: { "gal.gf3.tip": "Color: tono de la calibración (blanco = galaxia espiral media, SPCC), mostrado con un estiramiento que conserva el color (el mismo factor en R, G y B, como ArcsinhStretch) con un hombro suave para que el centro no se queme a blanco, y una saturación de pantalla ×{sat} que solo se aplica entera a la luz de poco color (una elección de presentación): hace visible el tono calibrado, no lo cambia. Bulbo y barra dorados = estrellas viejas; brazos blanco-azulados = estrellas jóvenes, con nubes estelares; nudos rosas = regiones HII puestas a lo largo de los brazos como ilustración (no son posiciones de catálogo). Barra: semilongitud de unos 5 kpc a 28° de la línea Sol–centro (Bland-Hawthorn y Gerhard 2016); sus líneas de polvo van por los bordes de ataque, se curvan en los extremos de la barra y se unen al borde interior de los brazos (Athanassoula 1992). Los brazos menores (Brazo Local, Sagitario-Carina, Norma) son más tenues que los dos principales (Reid et al. 2019). Los puntos medidos (máseres y regiones HII) no se dibujan aquí, para que la imagen no muestre dónde da la casualidad de que hay medidas: marca SOLO DATOS para verlos." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF4, 10-nov) la galaxia GF3 corregida (FV_GAL_GF4.ON): el tooltip sustituye al de GF3 (carriles en gancho, brazos con su azul, nudos, nucleo)
(function() {
   var add = {
      en: { "gal.gf4.tip": "Colour: hue from the calibration (white = average spiral galaxy, SPCC), shown with a colour-preserving stretch (same factor on R, G and B, like ArcsinhStretch) with a soft shoulder so that the centre is not burnt to white, and a display saturation of ×{sat} that is applied in full only to weakly coloured light (a display choice): it makes the calibrated hue visible, it does not change it. The integrated colour of the galaxy is kept: the young light of the arms is not taken from the arms but from the smooth old disc, mostly between the arms. Golden bulge and bar = old stars, with a compact nucleus; bluish-white arms = young stars, with star clouds; pink knots = HII regions (their magenta hue comes from the hydrogen lines through the camera curves, with reduced chroma; placed along the arms as an illustration, only where the arm is visible; they are not catalogue positions). Bar: half-length about 5 kpc at 28° from the Sun–centre line (Bland-Hawthorn & Gerhard 2016; Wegg et al. 2015); its dust lanes run along the leading edges, curve around the bar ends and enter the inner edge of the arms without a break (Athanassoula 1992). Dust lanes are dark brown, not black, seen face-on. Minor arms (Local Arm, Sagittarius–Carina, Norma) are fainter than the two main arms; the Local Arm is drawn only over its measured stretch (Reid et al. 2019). The measured points (masers and HII regions) are not drawn here, so that the picture does not show where we happen to have measurements: tick DATA ONLY to see them." },
      es: { "gal.gf4.tip": "Color: tono de la calibración (blanco = galaxia espiral media, SPCC), mostrado con un estiramiento que conserva el color (el mismo factor en R, G y B, como ArcsinhStretch) con un hombro suave para que el centro no se queme a blanco, y una saturación de pantalla ×{sat} que solo se aplica entera a la luz de poco color (una elección de presentación): hace visible el tono calibrado, no lo cambia. El color integrado de la galaxia se conserva: la luz joven de los brazos no se quita de los brazos sino del disco viejo liso, sobre todo entre los brazos. Bulbo y barra dorados = estrellas viejas, con un núcleo compacto; brazos blanco-azulados = estrellas jóvenes, con nubes estelares; nudos rosas = regiones HII (su tono magenta sale de las líneas del hidrógeno a través de las curvas de la cámara, con menos croma; puestas a lo largo de los brazos como ilustración y solo donde el brazo se ve; no son posiciones de catálogo). Barra: semilongitud de unos 5 kpc a 28° de la línea Sol–centro (Bland-Hawthorn y Gerhard 2016; Wegg et al. 2015); sus líneas de polvo van por los bordes de ataque, rodean los extremos de la barra y entran sin corte en el borde interior de los brazos (Athanassoula 1992). De cara, las líneas de polvo son pardo oscuro, no negras. Los brazos menores (Brazo Local, Sagitario-Carina, Norma) son más tenues que los dos principales; el Brazo Local se dibuja solo en su tramo medido (Reid et al. 2019). Los puntos medidos (máseres y regiones HII) no se dibujan aquí, para que la imagen no muestre dónde da la casualidad de que hay medidas: marca SOLO DATOS para verlos." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF5, 10-nov) la galaxia GF4 corregida (FV_GAL_GF5.ON): el tooltip sustituye al de GF4 (gancho por dentro del brazo, nucleo en cuspide, nudos con su color fisico)
(function() {
   var add = {
      en: { "gal.gf5.tip": "Colour: hue from the calibration (white = average spiral galaxy, SPCC), shown with a colour-preserving stretch (same factor on R, G and B, like ArcsinhStretch) with a soft shoulder so that the centre is not burnt to white, and a display saturation of ×{sat} that is applied in full only to weakly coloured light (a display choice): it makes the calibrated hue visible, it does not change it. The integrated colour of the galaxy is kept: the young light of the arms is taken from the smooth old disc between the arms, outside the bar region. Golden bulge and bar = old stars, with a nucleus that brightens smoothly towards the centre; bluish-white arms = young stars, with star clouds; red-pink knots = HII regions (their colour comes from the hydrogen, nitrogen, oxygen and sulphur lines of a disc HII region, reddened by its typical dust, through the camera curves; placed along the arms as an illustration, only where the arm is visible; they are not catalogue positions). Bar: half-length about 5 kpc at 28° from the Sun–centre line (Bland-Hawthorn & Gerhard 2016; Wegg et al. 2015); its dust lanes run along the leading edges, curve at the bar ends inside the arm and enter the inner edge of the same arm without a break (Athanassoula 1992); where they cross the bar axis they are fainter, so the bar is still seen whole. Dust lanes are dark brown, not black, seen face-on. Minor arms (Local Arm, Sagittarius–Carina, Norma) are fainter than the two main arms; the Local Arm is drawn only over its measured stretch (Reid et al. 2019). The measured points (masers and HII regions) are not drawn here, so that the picture does not show where we happen to have measurements: tick DATA ONLY to see them." },
      es: { "gal.gf5.tip": "Color: tono de la calibración (blanco = galaxia espiral media, SPCC), mostrado con un estiramiento que conserva el color (el mismo factor en R, G y B, como ArcsinhStretch) con un hombro suave para que el centro no se queme a blanco, y una saturación de pantalla ×{sat} que solo se aplica entera a la luz de poco color (una elección de presentación): hace visible el tono calibrado, no lo cambia. El color integrado de la galaxia se conserva: la luz joven de los brazos sale del disco viejo liso entre los brazos, fuera de la región de la barra. Bulbo y barra dorados = estrellas viejas, con un núcleo que se aviva poco a poco hacia el centro; brazos blanco-azulados = estrellas jóvenes, con nubes estelares; nudos rojo-rosados = regiones HII (su color sale de las líneas del hidrógeno, el nitrógeno, el oxígeno y el azufre de una región HII del disco, enrojecidas por su polvo típico, a través de las curvas de la cámara; puestas a lo largo de los brazos como ilustración y solo donde el brazo se ve; no son posiciones de catálogo). Barra: semilongitud de unos 5 kpc a 28° de la línea Sol–centro (Bland-Hawthorn y Gerhard 2016; Wegg et al. 2015); sus líneas de polvo van por los bordes de ataque, se curvan en los extremos de la barra por dentro del brazo y entran sin corte en el borde interior del mismo brazo (Athanassoula 1992); donde cruzan el eje de la barra son más tenues, para que la barra se siga viendo entera. De cara, las líneas de polvo son pardo oscuro, no negras. Los brazos menores (Brazo Local, Sagitario-Carina, Norma) son más tenues que los dos principales; el Brazo Local se dibuja solo en su tramo medido (Reid et al. 2019). Los puntos medidos (máseres y regiones HII) no se dibujan aquí, para que la imagen no muestre dónde da la casualidad de que hay medidas: marca SOLO DATOS para verlos." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF6, 10-nov) la galaxia GF5 corregida (FV_GAL_GF6.ON): el tooltip sustituye al de GF5 (flancos de la barra, polvo exterior, bulbo en caja, disco grueso viejo)
(function() {
   var add = {
      en: { "gal.gf6.tip": "Colour: hue from the calibration (white = average spiral galaxy, SPCC), shown with a colour-preserving stretch (same factor on R, G and B, like ArcsinhStretch) with a soft shoulder so that the centre is not burnt to white and no channel reaches full scale, and a display saturation of ×{sat} that is applied in full only to weakly coloured light (a display choice): it makes the calibrated hue visible, it does not change it. The integrated colour of the galaxy is kept: the young light of the arms is taken from the smooth old disc between the arms. Golden bulge and bar = old stars, with a nucleus that brightens smoothly towards the centre; the regions on either side of the bar are darker, because the bar is made of disc stars it has swept up (their light is moved to the bar, not removed), with a little diffuse dust; bluish-white arms = young stars, with star clouds; red-pink knots = HII regions (their colour comes from the hydrogen, nitrogen, oxygen and sulphur lines of a disc HII region, reddened by its typical dust, through the camera curves; placed along the arms as an illustration, only where the arm is visible; they are not catalogue positions). Bar: half-length about 5 kpc at 28° from the Sun–centre line (Bland-Hawthorn & Gerhard 2016; Wegg et al. 2015); its dust lanes run along the leading edges, curve at the bar ends inside the arm and enter the inner edge of the same arm without a break (Athanassoula 1992). Dust lanes are dark brown, not black, seen face-on, also in the outer arms. Edge-on: the bulge is a box/peanut (the inner part of the bar, thickened; Wegg & Gerhard 2013); the thick disc above and below the plane holds the old, yellowish stars and the thin disc the young, bluish ones; the disc fades smoothly with height. Minor arms (Local Arm, Sagittarius–Carina, Norma) are fainter than the two main arms; the Local Arm is drawn only over its measured stretch (Reid et al. 2019). The measured points (masers and HII regions) are not drawn here, so that the picture does not show where we happen to have measurements: tick DATA ONLY to see them." },
      es: { "gal.gf6.tip": "Color: tono de la calibración (blanco = galaxia espiral media, SPCC), mostrado con un estiramiento que conserva el color (el mismo factor en R, G y B, como ArcsinhStretch) con un hombro suave para que el centro no se queme a blanco y ningún canal llegue al tope, y una saturación de pantalla ×{sat} que solo se aplica entera a la luz de poco color (una elección de presentación): hace visible el tono calibrado, no lo cambia. El color integrado de la galaxia se conserva: la luz joven de los brazos sale del disco viejo liso entre los brazos. Bulbo y barra dorados = estrellas viejas, con un núcleo que se aviva poco a poco hacia el centro; las regiones a los lados de la barra son más oscuras, porque la barra está hecha de las estrellas del disco que ha barrido (su luz pasa a la barra, no se quita), con un poco de polvo difuso; brazos blanco-azulados = estrellas jóvenes, con nubes estelares; nudos rojo-rosados = regiones HII (su color sale de las líneas del hidrógeno, el nitrógeno, el oxígeno y el azufre de una región HII del disco, enrojecidas por su polvo típico, a través de las curvas de la cámara; puestas a lo largo de los brazos como ilustración y solo donde el brazo se ve; no son posiciones de catálogo). Barra: semilongitud de unos 5 kpc a 28° de la línea Sol–centro (Bland-Hawthorn y Gerhard 2016; Wegg et al. 2015); sus líneas de polvo van por los bordes de ataque, se curvan en los extremos de la barra por dentro del brazo y entran sin corte en el borde interior del mismo brazo (Athanassoula 1992). De cara, las líneas de polvo son pardo oscuro, no negras, también en los brazos exteriores. De canto: el bulbo es una caja/cacahuete (la parte interior de la barra, engordada; Wegg y Gerhard 2013); el disco grueso, por encima y por debajo del plano, guarda las estrellas viejas y amarillentas y el fino las jóvenes y azuladas; el disco se apaga suavemente con la altura. Los brazos menores (Brazo Local, Sagitario-Carina, Norma) son más tenues que los dos principales; el Brazo Local se dibuja solo en su tramo medido (Reid et al. 2019). Los puntos medidos (máseres y regiones HII) no se dibujan aquí, para que la imagen no muestre dónde da la casualidad de que hay medidas: marca SOLO DATOS para verlos." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (Blender 2 · exoplanetas, 10-nov) la portilla del planeta: el lado nocturno (PL-5) y la ventana del mundo en el panel del transito (PL-6)
(function() {
   var add = {
      en: { "pl.night": "NIGHT SIDE", "pl.expo": "exposure ×{x}", "pl.port": "the world · illustration" },
      es: { "pl.night": "LADO NOCTURNO", "pl.expo": "exposición ×{x}", "pl.port": "el mundo · ilustración" }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF7) el texto de la galaxia GF7: fosa ni agujero ni gris, polvo de los menores junto al Sol, un solo carril de canto y la X a lo largo de la barra
(function() {
   var add = {
      en: { "gal.gf7.tip": "Colour: hue from the calibration (white = average spiral galaxy, SPCC), shown with a colour-preserving stretch (same factor on R, G and B, like ArcsinhStretch) with a soft shoulder so that the centre is not burnt to white and no channel reaches full scale, and a display saturation of ×{sat} that is applied in full only to weakly coloured light (a display choice): it makes the calibrated hue visible, it does not change it. The integrated colour of the galaxy is kept: the young light of the arms is taken from the smooth old disc between the arms. Golden bulge and bar = old stars, with a nucleus that brightens smoothly towards the centre; the regions on either side of the bar are darker but not empty, because the bar is made of disc stars it has swept up (their light is moved to the bar, not removed), brownish with a little diffuse dust; bluish-white arms = young stars, with star clouds; red-pink knots = HII regions (their colour comes from the hydrogen, nitrogen, oxygen and sulphur lines of a disc HII region, reddened by its typical dust, through the camera curves; placed along the arms as an illustration, only where the arm is visible; they are not catalogue positions). Bar: half-length about 5 kpc at 28° from the Sun–centre line (Bland-Hawthorn & Gerhard 2016; Wegg et al. 2015); its dust lanes run along the leading edges, curve at the bar ends inside the arm and enter the inner edge of the same arm without a break (Athanassoula 1992). Dust lanes are dark brown, not black, seen face-on, also in the outer arms and, near the Sun, in the minor arms. Edge-on: a single dark dust lane, thinner than the stars and reaching further out than the stellar disc; seen edge-on its colour is greyer than the extinction law alone would give, as an approximation to the light scattered into the lane (scattering itself is not computed). The bulge is a box/peanut that is the inner part of the bar, thickened, with its X along the bar (Wegg & Gerhard 2013): seen with the bar side-on it shows two humps; nearly end-on, as from the Sun, it looks rounded (Athanassoula 2005). The thick disc above and below the plane holds the old, yellowish stars and the thin disc the young, bluish ones; the disc fades smoothly with height. Minor arms (Local Arm, Sagittarius–Carina, Norma) are fainter than the two main arms; the Local Arm is drawn only over its measured stretch (Reid et al. 2019). The measured points (masers and HII regions) are not drawn here, so that the picture does not show where we happen to have measurements: tick DATA ONLY to see them." },
      es: { "gal.gf7.tip": "Color: tono de la calibración (blanco = galaxia espiral media, SPCC), mostrado con un estiramiento que conserva el color (el mismo factor en R, G y B, como ArcsinhStretch) con un hombro suave para que el centro no se queme a blanco y ningún canal llegue al tope, y una saturación de pantalla ×{sat} que solo se aplica entera a la luz de poco color (una elección de presentación): hace visible el tono calibrado, no lo cambia. El color integrado de la galaxia se conserva: la luz joven de los brazos sale del disco viejo liso entre los brazos. Bulbo y barra dorados = estrellas viejas, con un núcleo que se aviva poco a poco hacia el centro; las regiones a los lados de la barra son más oscuras pero no vacías, porque la barra está hecha de las estrellas del disco que ha barrido (su luz pasa a la barra, no se quita), pardas y con un poco de polvo difuso; brazos blanco-azulados = estrellas jóvenes, con nubes estelares; nudos rojo-rosados = regiones HII (su color sale de las líneas del hidrógeno, el nitrógeno, el oxígeno y el azufre de una región HII del disco, enrojecidas por su polvo típico, a través de las curvas de la cámara; puestas a lo largo de los brazos como ilustración y solo donde el brazo se ve; no son posiciones de catálogo). Barra: semilongitud de unos 5 kpc a 28° de la línea Sol–centro (Bland-Hawthorn y Gerhard 2016; Wegg et al. 2015); sus líneas de polvo van por los bordes de ataque, se curvan en los extremos de la barra por dentro del brazo y entran sin corte en el borde interior del mismo brazo (Athanassoula 1992). De cara, las líneas de polvo son pardo oscuro, no negras, también en los brazos exteriores y, junto al Sol, en los brazos menores. De canto: un solo carril de polvo oscuro, más fino que las estrellas y que llega más lejos que el disco estelar; de canto su color es más gris que el que daría solo la ley de extinción, como aproximación a la luz que el polvo dispersa hacia el carril (la dispersión no se calcula). El bulbo es una caja/cacahuete que es la parte interior de la barra, engordada, con su X a lo largo de la barra (Wegg y Gerhard 2013): con la barra de lado se ven dos jorobas; casi de punta, como desde el Sol, parece redondeado (Athanassoula 2005). El disco grueso, por encima y por debajo del plano, guarda las estrellas viejas y amarillentas y el fino las jóvenes y azuladas; el disco se apaga suavemente con la altura. Los brazos menores (Brazo Local, Sagitario-Carina, Norma) son más tenues que los dos principales; el Brazo Local se dibuja solo en su tramo medido (Reid et al. 2019). Los puntos medidos (máseres y regiones HII) no se dibujan aquí, para que la imagen no muestre dónde da la casualidad de que hay medidas: marca SOLO DATOS para verlos." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (Blender 3 · exoplanetas, 10-nov) rotulos cortos de la portilla (curvados por dentro del cristal) y el panel del transito a contraluz
(function() {
   var add = {
      en: { "pl3.night": "night side", "pl3.expo": "exposure ×{x}", "pl3.portTr": "backlit · from Earth",
            "pl3.portTrTip": "The same moment as the transit on the left, zoomed on the planet: seen from Earth it is a dark disc in front of its star, whose limb darkening shows behind it. If the planet has an atmosphere, starlight filtered through it makes a thin reddish ring around the disc: that transmitted light is what transmission spectroscopy measures. Illustration: the ring is drawn thicker than a real atmosphere (a few hundred km) so that it can be seen. The lit planet, as seen from the ship, is in its card." },
      es: { "pl3.night": "lado nocturno", "pl3.expo": "exposición ×{x}", "pl3.portTr": "a contraluz · desde la Tierra",
            "pl3.portTrTip": "El mismo momento que el tránsito de la izquierda, ampliado sobre el planeta: desde la Tierra es un disco oscuro delante de su estrella, con el oscurecimiento del limbo detrás. Si el planeta tiene atmósfera, la luz de la estrella que la atraviesa forma un anillo fino y rojizo alrededor del disco: esa luz transmitida es la que mide la espectroscopía de transmisión. Ilustración: el anillo se dibuja más grueso que una atmósfera real (unos cientos de km) para que se vea. El planeta iluminado, visto desde la nave, está en su ficha." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF8) el texto de la galaxia GF8: el de GF7 con el canto nuevo (estrellas jovenes dentro del polvo y enrojecidas; por encima del plano el disco
// es liso: la barra, la fosa y los brazos son del disco fino). Se elige en src/ui/fv_galaxy.js como los anteriores
(function() {
   function gf8(L) {
      var t = FV_TX[L]["gal.gf7.tip"]; if (!t) return null;
      var a = L === "en" ? "Edge-on: a single dark dust lane, thinner than the stars and reaching further out than the stellar disc; seen edge-on its colour is greyer than the extinction law alone would give, as an approximation to the light scattered into the lane (scattering itself is not computed)."
                         : "De canto: un solo carril de polvo oscuro, más fino que las estrellas y que llega más lejos que el disco estelar; de canto su color es más gris que el que daría solo la ley de extinción, como aproximación a la luz que el polvo dispersa hacia el carril (la dispersión no se calcula).";
      var b = L === "en" ? "Edge-on: a single dark dust lane, thinner than the stars and reaching further out than the stellar disc. The young stars of the thin disc (about 75 pc high, like the Cepheids; Skowron et al. 2019) lie inside the dust layer and are reddened by it; the old light is seen greyer than the extinction law alone would give, as an approximation to the light scattered into the lane (scattering itself is not computed). In real edge-on galaxies the main dust lane can look bluish in colour maps, because of young stars in clearer patches and scattered light, while the dust filaments look red (NGC 891, de Vaucouleurs Atlas of Galaxies). Above the plane the disc is smooth: the bar, the darker regions beside it and the arms belong to the thin, cold disc."
                         : "De canto: un solo carril de polvo oscuro, más fino que las estrellas y que llega más lejos que el disco estelar. Las estrellas jóvenes del disco fino (unos 75 pc de altura, como las cefeidas; Skowron et al. 2019) están dentro de la capa de polvo y salen enrojecidas; la luz vieja se ve más gris que lo que daría solo la ley de extinción, como aproximación a la luz que el polvo dispersa hacia el carril (la dispersión no se calcula). En las galaxias de canto reales el carril principal puede verse azulado en los mapas de color, por las estrellas jóvenes de los claros y la luz dispersada, mientras que los filamentos de polvo se ven rojos (NGC 891, de Vaucouleurs Atlas of Galaxies). Por encima del plano el disco es liso: la barra, las regiones más oscuras a sus lados y los brazos son del disco fino y frío.";
      return t.indexOf(a) >= 0 ? t.replace(a, b) : t + " " + b;
   }
   var en = gf8("en"), es = gf8("es");
   if (en) FV_TX.en["gal.gf8.tip"] = en;
   if (es) FV_TX.es["gal.gf8.tip"] = es;
})();
// tooltip con los dos idiomas (el de la nave primero)
function fvTipBoth(key) {
   var en = FV_TX.en[key] || key, es = FV_TX.es[key] || en;
   return "<html>" + (FV_LANG === "es" ? es + "<br><i>" + en + "</i>" : en + "<br><i>" + es + "</i>") + "</html>";
}
function fvTx(key, params, lang) {
   var L = (lang || FV_LANG) === "es" ? "es" : "en", tab = FV_TX[L], s = Object.prototype.hasOwnProperty.call(tab, key) ? tab[key] : (FV_TX.en[key] || key);
   if (params) for (var k in params) if (params.hasOwnProperty(k)) s = s.split("{" + k + "}").join(String(params[k]));
   // (6-nov) contracciones del castellano tras rellenar la plantilla («antes de el Libro» -> «antes del Libro»), como fvsEsContract
   if (L === "es" && params) s = s.split(" de el ").join(" del ").split(" a el ").join(" al ");
   return s;
}
// numero con separador de miles del idioma (ES: espacio duro; EN: coma)
function fvNum(x, dec, lang) {
   if (typeof fvsFmtNum === "function") return fvsFmtNum(x, dec || 0, (lang || FV_LANG));
   return (dec ? x.toFixed(dec) : String(Math.round(x)));
}
// partir un texto en lineas de ancho maximo (pixeles) con la fuente f
function fvWrap(f, text, maxW) {
   var words = String(text).split(" "), lines = [], cur = "";
   for (var i = 0; i < words.length; ++i) {
      var t = cur ? cur + " " + words[i] : words[i];
      if (f.width(t) <= maxW || !cur) cur = t; else { lines.push(cur); cur = words[i]; }
   }
   if (cur) lines.push(cur);
   return lines;
}
// (Blender 5 · exoplanetas, 10-nov) el planeta de DEMOSTRACION (la fila inyectada que se dibuja sobre una estrella de tu foto que NO es la suya):
// su ficha lleva la marca DEMO, su distancia es la de SU estrella (sy_dist del archivo) y nunca la de la estrella del campo; un planeta de prueba
// sin estrella con nombre no dice «alrededor de». Mismos textos en la lista (MIRABILIA) y en la ficha de la estrella sobre la que se dibuja
(function() {
   var add = {
      en: { "b5.demoWord": "DEMO", "b5.demoSrc": "not a planet of this star",
            "b5.demoSub": "DEMO · {t} · around {h}", "b5.demoSubNoHost": "DEMO · {t}",
            "b5.demoCard": "DEMO: this planet is drawn on a star of your photo ({d}) so that you can see how a planet looks. It does not orbit that star.",
            "b5.demoOwn": "Its real star, {h}: {d}.",
            "b5.demoStar": "In the small window, a DEMO planet ({p}): it does not orbit this star.",
            "b5.navDemo": "demo planet · target star {d}" },
      es: { "b5.demoWord": "DEMO", "b5.demoSrc": "no es un planeta de esta estrella",
            "b5.demoSub": "DEMO · {t} · alrededor de {h}", "b5.demoSubNoHost": "DEMO · {t}",
            "b5.demoCard": "DEMO: este planeta se dibuja sobre una estrella de tu foto ({d}) para que veas cómo se ve un planeta. No gira alrededor de esa estrella.",
            "b5.demoOwn": "Su estrella real, {h}: {d}.",
            "b5.demoStar": "En la ventanita, un planeta de DEMO ({p}): no gira alrededor de esta estrella.",
            "b5.navDemo": "planeta de demostración · estrella de destino {d}" }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (encargo GF9) el texto de la galaxia GF9: el de GF8 con el canto nuevo (la capa joven y la de polvo se ensanchan hacia fuera, como el hidrogeno neutro;
// el carril tiene grumos; el bulbo en caja conserva la luz de la barra a toda altura). Se elige en src/ui/fv_galaxy.js como los anteriores
(function() {
   function gf9(L) {
      var t = FV_TX[L]["gal.gf8.tip"]; if (!t) return null;
      var a = L === "en" ? "Above the plane the disc is smooth: the bar, the darker regions beside it and the arms belong to the thin, cold disc."
                         : "Por encima del plano el disco es liso: la barra, las regiones más oscuras a sus lados y los brazos son del disco fino y frío.";
      var b = L === "en" ? "Beyond the Sun's distance the young stars and the dust layer get thicker outwards, as the neutral hydrogen does (Kalberla et al. 2007), so the warped outer disc in front of the lane no longer draws a second thin line along it. The dust lane is patchy, with uneven edges, as an illustration of the dust structures seen in edge-on galaxies such as NGC 891 (Howk & Savage 1997); the patches are not real positions. Above the plane the disc is smooth outside the bulge: the bar, the darker regions beside it and the arms belong to the thin, cold disc (the long bar is about 180 pc thick; Wegg et al. 2015), while inside about 3.5 kpc the box/peanut bulge keeps the light of the bar at all heights."
                         : "Más allá de la distancia del Sol, las estrellas jóvenes y la capa de polvo se ensanchan hacia fuera, como el hidrógeno neutro (Kalberla et al. 2007), de modo que el disco exterior alabeado que queda delante del carril ya no dibuja una segunda línea fina a lo largo de él. El carril de polvo es irregular, con bordes desiguales, como ilustración de las estructuras de polvo que se ven en galaxias de canto como NGC 891 (Howk y Savage 1997); los grumos no son posiciones reales. Por encima del plano el disco es liso fuera del bulbo: la barra, las regiones más oscuras a sus lados y los brazos son del disco fino y frío (la barra larga tiene unos 180 pc de grosor; Wegg et al. 2015), mientras que por dentro de unos 3,5 kpc el bulbo en caja conserva la luz de la barra a cualquier altura.";
      return t.indexOf(a) >= 0 ? t.replace(a, b) : t + " " + b;
   }
   var en = gf9("en"), es = gf9("es");
   if (en) FV_TX.en["gal.gf9.tip"] = en;
   if (es) FV_TX.es["gal.gf9.tip"] = es;
})();
// (Blender 5b, 10-nov) textos de la ronda 5b (R5-8: cifras que se contradecian; R5-11: ingles)
(function() {
   var add = {
      en: { "b5b.hereD": "YOU ARE HERE · {d} away",
            "b5b.depth": "NASA Exoplanet Archive: when it crosses, the star dims {d} % (the model in the transit window, with limb darkening, gives {q}).",
            "b5b.dur": "NASA Exoplanet Archive: each crossing lasts {h} hours (the model in the transit window gives {q})." },
      es: { "b5b.hereD": "ESTÁS AQUÍ · a {d}",
            "b5b.depth": "Archivo de la NASA: cuando pasa, la estrella se apaga un {d} % (el modelo de la ventana del tránsito, con el limbo oscurecido, da un {q}).",
            "b5b.dur": "Archivo de la NASA: cada paso dura {h} horas (el modelo de la ventana del tránsito da {q})." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (E2, 11-nov) el boton STF y su panel (src/ui/fv_stf_panel.js); claves nuevas, prefijo stf.
(function() {
   var add = {
      en: { "stf.lab": "STF", "stf.btn": "Stretch (STF)",
            "stf.tip": "Stretch (STF): your photo is linear (or has its own STF in PixInsight), so FieldVoyager stretches it to show it. This opens a small panel to change that stretch: shadows, sky background and linked channels; AUTO goes back to the automatic rule. The photo, the photo without stars, the star colours, the objects and the nebula layers are all redone with it. Remembered for this photo.",
            "stf.title": "STF · STRETCH", "stf.shadows": "Shadows", "stf.bkg": "Sky background", "stf.linked": "Linked channels", "stf.auto": "AUTO",
            "stf.stAuto": "automatic (the rule)", "stf.stView": "the STF of the view in PixInsight", "stf.stUser": "set by you · this photo",
            "stf.foot": "drag: live · release: rebuild", "stf.busy": "APPLYING THE STRETCH…", "stf.fail": "THE STRETCH COULD NOT BE APPLIED: THE PREVIOUS ONE STAYS",
            "stf.tip.close": "Close the panel (Esc). A change still pending is applied.",
            "stf.tip.status": "Where the stretch comes from. Automatic: shadows at −2.8 MAD and the sky at 12 %, linked if the colour is calibrated (or the photo is grey), each channel on its own if not. The STF of the view: the one your image has in PixInsight. Set by you: what you chose here, remembered for this photo.",
            "stf.tip.clip": "Shadows: where black starts, in sigmas (MAD) from the sky background. More negative keeps more of the faint sky (greyer); towards −1 clips more (deeper blacks, faint nebula lost). The photo without stars changes while you drag; the rest is rebuilt when you release.",
            "stf.tip.bkg": "Sky background: how bright the sky is after the stretch (0.12 = 12 %). Higher shows more faint nebula and a lighter sky; lower, a darker sky. The photo without stars changes while you drag; the rest is rebuilt when you release.",
            "stf.tip.linked": "Linked channels: one stretch for the three channels (keeps the colour balance of a calibrated photo) or one per channel (neutralises the sky of an uncalibrated photo; can shift the colours). It starts as the automatic rule says. Disabled in a grey photo.",
            "stf.tip.auto": "AUTO: back to the automatic rule (or to the STF of the view if it has one) and forget what was set for this photo." },
      es: { "stf.lab": "STF", "stf.btn": "Estirado (STF)",
            "stf.tip": "Estirado (STF): tu foto es lineal (o tiene su propio STF en PixInsight), así que FieldVoyager la estira para enseñarla. Abre un panel pequeño para cambiar ese estirado: sombras, fondo del cielo y canales enlazados; AUTO vuelve a la regla automática. Con él se rehacen la foto, la foto sin estrellas, el color de las estrellas, los objetos y las capas de la nebulosa. Se recuerda para esta foto.",
            "stf.title": "STF · ESTIRADO", "stf.shadows": "Sombras", "stf.bkg": "Fondo del cielo", "stf.linked": "Canales enlazados", "stf.auto": "AUTO",
            "stf.stAuto": "automático (la regla)", "stf.stView": "el STF de la vista en PixInsight", "stf.stUser": "puesto por ti · esta foto",
            "stf.foot": "arrastrar: en vivo · soltar: rehacer", "stf.busy": "APLICANDO EL ESTIRADO…", "stf.fail": "NO SE PUDO APLICAR EL ESTIRADO: SE QUEDA EL DE ANTES",
            "stf.tip.close": "Cerrar el panel (Esc). Si quedaba un cambio pendiente, se aplica.",
            "stf.tip.status": "De dónde sale el estirado. Automático: sombras a −2,8 MAD y el cielo al 12 %, enlazado si el color está calibrado (o la foto es gris), cada canal el suyo si no. El STF de la vista: el que tu imagen tiene en PixInsight. Puesto por ti: lo que elegiste aquí, recordado para esta foto.",
            "stf.tip.clip": "Sombras: dónde empieza el negro, en sigmas (MAD) desde el fondo del cielo. Más negativo guarda más cielo débil (más gris); hacia −1 recorta más (negros más hondos, se pierde nebulosa débil). La foto sin estrellas cambia mientras arrastras; lo demás se rehace al soltar.",
            "stf.tip.bkg": "Fondo del cielo: lo claro que queda el cielo tras el estirado (0,12 = 12 %). Más alto enseña más nebulosa débil y un cielo más claro; más bajo, un cielo más oscuro. La foto sin estrellas cambia mientras arrastras; lo demás se rehace al soltar.",
            "stf.tip.linked": "Canales enlazados: un estirado para los tres canales (conserva el equilibrio de color de una foto calibrada) o uno por canal (neutraliza el cielo de una foto sin calibrar; puede cambiar los colores). Empieza como dice la regla automática. Apagada en una foto gris.",
            "stf.tip.auto": "AUTO: vuelve a la regla automática (o al STF de la vista si lo tiene) y olvida lo puesto para esta foto." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();

// (12-nov-2026, R7) LA BARRA DEL TOUR (fv_hud.js fvTourBarPaint): rotulos EN / ES y la ayuda de cada mando. Las teclas: «,» anterior · «.» siguiente · B pausa.
(function() {
   var add = {
      en: {
         "tour.label": "TOUR {i} / {n}", "tour.fly": "EN ROUTE", "tour.scan": "SCANNING", "tour.nextIn": "NEXT STOP IN {s} s", "tour.endIn": "TOUR ENDS IN {s} s",
         "tour.busy": "HOLDING WHILE YOU READ", "tour.paused": "PAUSED",
         "tip.tour_prev": "Previous stop of the tour (key: , ). On the first one it starts that stop again.",
         "tip.tour_pause": "Pause or resume the tour: it stays on this object until you resume (key: B). It also waits by itself while the pointer is over the card or MORE is open, and then gives you 3 s more.",
         "tip.tour_next": "Next stop of the tour, right now (key: . ). On the last one it ends the tour. To stop the tour: the TOUR button (key: T).",
         "tip.tour_bar": "The tour is running: the bar counts down to the next jump. It waits while the pointer is over the card or MORE is open; to stop the tour press TOUR (key: T).",
         "tip.tour": "Tour: an automatic trip through the most interesting objects of the field, with their cards. Again to stop. Key: T. While it runs, the bar at the bottom shows where it is and has previous, pause and next (keys , B .)."
      },
      es: {
         "tour.label": "TOUR {i} / {n}", "tour.fly": "EN RUTA", "tour.scan": "ESCANEANDO", "tour.nextIn": "SIGUIENTE PARADA EN {s} s", "tour.endIn": "EL TOUR ACABA EN {s} s",
         "tour.busy": "EN ESPERA MIENTRAS LEES", "tour.paused": "EN PAUSA",
         "tip.tour_prev": "Parada anterior del tour (tecla: , ). En la primera, vuelve a empezar esa parada.",
         "tip.tour_pause": "Pausa o sigue el tour: se queda en este objeto hasta que lo reanudes (tecla: B). También espera solo mientras el cursor está sobre la ficha o MÁS está abierto, y luego te da 3 s más.",
         "tip.tour_next": "Siguiente parada del tour, ahora mismo (tecla: . ). En la última, acaba el tour. Para parar el tour: el botón TOUR (tecla: T).",
         "tip.tour_bar": "El tour está en marcha: la barra cuenta hasta el siguiente salto. Espera mientras el cursor está sobre la ficha o MÁS está abierto; para pararlo, el botón TOUR (tecla: T).",
         "tip.tour": "Tour: un viaje automático por los objetos más interesantes del campo, con sus fichas. Otra vez, para. Tecla: T. Mientras corre, la barra de abajo dice por dónde va y trae anterior, pausa y siguiente (teclas , B .)."
      }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
})();
// (21-nov-2026, N-galaxias-warp; FV_GWARP, src/engine/fv_objects.js) SIN el selector MODUS el modo de viaje lo elige el destino: los textos que lo nombraban lo dicen (con FV_GWARP.ON = false, los de antes)
(function() {
   // el visor web: ?gwarp=0 apaga FV_GWARP (selector MODUS y «otro modo» como antes); aqui porque es lo primero que lee la bandera (texto, cabina, ficha, viaje)
   try { if (typeof location !== "undefined" && typeof FV_GWARP !== "undefined" && /[?&]gwarp=0/.test(String(location.search))) FV_GWARP.ON = false; } catch (eGw) {}
   if (typeof fvGwarpUi !== "function" || !fvGwarpUi()) return;
   var add = {
      en: { "tip.travel": "Travel to the selected object. Inside the Milky Way the ship flies a cinematic trip; to another galaxy it makes a short warp jump. Key: Space.",
            "tipck.listGo": "Go there (a cinematic flight inside the Milky Way, a short warp jump to another galaxy)." },
      es: { "tip.travel": "Viajar al objeto elegido. Dentro de la Vía Láctea la nave hace un viaje de cine; a otra galaxia, un salto warp corto. Tecla: espacio.",
            "tipck.listGo": "Ir allí (un vuelo de cine dentro de la Vía Láctea, un salto warp corto a otra galaxia)." }
   };
   for (var L in add) for (var k in add[L]) FV_TX[L][k] = add[L][k];
   if (typeof FV_E1_TX !== "undefined") {
      FV_E1_TX.en["q.tipHud"] = "The star Gaia measured as {what}. Distance and its margin are Gaia DR3 + Bailer-Jones 2021. FLY THERE travels to it.";
      FV_E1_TX.es["q.tipHud"] = "La estrella que Gaia midió como {what}. La distancia y su margen son de Gaia DR3 + Bailer-Jones 2021. IR ALLÍ viaja hasta ella.";
   }
})();
