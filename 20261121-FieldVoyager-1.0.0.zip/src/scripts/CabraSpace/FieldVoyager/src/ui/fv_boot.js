// ============================================================================
// FieldVoyager/src/ui/fv_boot.js — EL ENCENDIDO DE LA NAVE (D10, F2 4-nov-2026)
// ----------------------------------------------------------------------------
// Al abrir, la cabina esta APAGADA: la foto en penumbra, la franja de instrumentos a oscuras y, en el centro, una placa de esmalte con
// «DON'T PANIC» (letras grandes y amables, guiño a la Guia del autoestopista galactico), la lista de SISTEMAS de la nave con su lampara
// y un interruptor de cuchilla de laton. Al tirar de el, cada sistema es un paso REAL de fvBuildScene (src/build): la lampara pasa de
// apagada a «calentando» (ambar que late) y a «listo» (verde) o, si la red fallo, a ambar fijo («sin red: datos locales») y la nave
// sigue con lo local. Abajo, lo que se esta haciendo de verdad (con los segundos de espera de la red) y, intercalado, un guiño.
// Nada de barras falsas: si un paso tarda, la lampara late y el contador de segundos lo dice.
// (E6/E10, 4-nov) la placa pasa a PORTADA GRABADA (fvBootPaint; la de esmalte queda en fvBootPaintN) y sin guiños ni «Make it so».
// B = { sys: { id: { st, info, t } }, order, t (s desde que se abrio), started, done, fail, winkAt, cachedSeen }
// ES5.
// ============================================================================

var FV_BOOT_ORDER = ["nav", "charts", "range", "filters", "atlas", "shields", "sensors", "dome", "holo"];
var FV_LAMP = { off: 0xff3B2A0C, warm: 0xffE5A53F, ok: 0xff8FD07A, local: 0xffE5B53F, skip: 0xff6A604F, fail: 0xffE0603F };

function fvBootNew() {
   var B = { sys: {}, order: FV_BOOT_ORDER.slice(), t: 0, started: false, done: false, fail: "", cachedSeen: false, current: "", lever: 0 };
   for (var i = 0; i < B.order.length; ++i) B.sys[B.order[i]] = { st: "off", info: {}, t: 0 };
   return B;
}
function fvBootSet(B, id, st, info) {
   var s = B.sys[id];
   if (!s) return;
   if (st === "warm" && s.st !== "warm") s.t = B.t;
   // (nave, 6-nov) cuando TERMINA (la nave del arranque lo necesita para su cola de flechas; nada mas lo lee)
   if (st !== "warm" && st !== "off" && s.tOk === undefined) { s.tOk = B.t; if (s.st === "off") s.t = B.t; }
   s.st = st; s.info = info || s.info || {};
   if (st === "warm") B.current = id;
   if ((st === "ok" || st === "local") && info && info.cached) B.cachedSeen = true;
}
function fvBootFraction(B) { var n = 0; for (var i = 0; i < B.order.length; ++i) { var st = B.sys[B.order[i]].st; if (st === "ok" || st === "local" || st === "skip") ++n; } return n / B.order.length; }

// el texto de lo que se esta haciendo
function fvBootDoing(B) {
   if (B.fail) return fvTx("boot.failed", { why: B.fail });
   if (B.done) return fvTx("boot.ready");
   if (!B.started) return fvTx("boot.pull");
   var id = B.current, s = B.sys[id];
   if (!s) return fvTx("boot.powering");
   var sec = Math.max(0, Math.round((s.info && s.info.elapsedMs) ? s.info.elapsedMs / 1000 : (B.t - s.t)));
   return fvTx("do." + id, { s: sec, how: (s.info && s.info.how) || "", n: (s.info && s.info.n) ? fvNum(s.info.n, 0) : "" });
}
// (E10 y S4, Nino 4-nov) los guiños, FUERA del todo: no hay frases sueltas en la placa del centro. Se queda la funcion (la llaman los dos
// pintores y las pruebas) y siempre devuelve "".
function fvBootWink(B) { return ""; }

// (E6, 4-nov-2026) LA PORTADA GRABADA: la placa del encendido en el lenguaje de cabraspace.com (grabado de lineas doradas de 1 px sobre
// negro calido): placa oscura con filete doble y esquinas de grabado, dos diagonales muy tenues, el titulo en serif de alto contraste
// color marfil (sin negrita, sin sombra, sin el rojo), versalitas espaciadas, filetes con rombo central, lamparas como anillos finos con
// su punto de color apagado y el interruptor de cuchilla dibujado a linea. La geometria (y leverRect) es la de antes: el clic no cambia.
// FV_E6_FINE (fv_buttons.js) = false pinta la placa de esmalte de antes (fvBootPaintN).
var FV_BOOT_COL = { ivory: 0xffF4ECDC, ivory2: 0xffD9CDB4, gold: 0xffC99A3A, goldL: 0xffE9C97A, goldT: 0xff9C8358, dim: 0xff6E604A,
                    ok: 0xff9CC48E, warm: 0xffE5B53F, local: 0xffD9A441, fail: 0xffD0603F, panel: 0xee0D0A07 };
function fvBootLamp(st) { return st === "ok" ? FV_BOOT_COL.ok : (st === "warm" ? FV_BOOT_COL.warm : (st === "local" ? FV_BOOT_COL.local : (st === "fail" ? FV_BOOT_COL.fail : 0))); }
// filete con un rombo en el centro y dos puntos (como los de los grabados de la web)
function fvOrnRule(g, xa, xb, y, col, s) {
   var xm = (xa + xb) / 2, d = 3.2 * (s || 1);
   g.pen = new Pen(col, 0.8); g.drawLine(xa, y, xm - 3 * d, y); g.drawLine(xm + 3 * d, y, xb, y);
   g.drawPolygon([new Point(xm - d * 1.6, y), new Point(xm, y - d), new Point(xm + d * 1.6, y), new Point(xm, y + d)]);
   g.fillCircle(xm - 2.3 * d, y, 0.9, new Brush(col)); g.fillCircle(xm + 2.3 * d, y, 0.9, new Brush(col));
}
// placa grabada: fondo casi negro, filete exterior de oro (1 px), interior de oro tenue a 5 px y esquinas de cuarto de circulo
function fvEngravedPanel(g, x0, y0, x1, y1, diag) {
   g.fillRect(x0, y0, x1, y1, new Brush(FV_BOOT_COL.panel));
   if (diag) {            // dos diagonales muy tenues, como las de las laminas de la web
      g.pen = new Pen(0x16C99A3A, 1); g.drawLine(x0 + (x1 - x0) * 0.08, y0, x0 + (x1 - x0) * 0.62, y1); g.drawLine(x1, y0 + (y1 - y0) * 0.30, x0 + (x1 - x0) * 0.55, y1);
   }
   g.pen = new Pen(FV_BOOT_COL.gold, 1); g.drawRect(x0 + 0.5, y0 + 0.5, x1 - 0.5, y1 - 0.5);
   g.pen = new Pen(0x90C99A3A, 0.6); g.drawRect(x0 + 5.5, y0 + 5.5, x1 - 5.5, y1 - 5.5);
   var C = [[x0 + 5.5, y0 + 5.5, 1, 1], [x1 - 5.5, y0 + 5.5, -1, 1], [x1 - 5.5, y1 - 5.5, -1, -1], [x0 + 5.5, y1 - 5.5, 1, -1]];
   g.pen = new Pen(0xb0C99A3A, 0.6);
   for (var i = 0; i < 4; ++i) {
      // el arco une (x, y+12) con (x+12, y): un cuarto de circulo con centro en la esquina
      var x = C[i][0], y = C[i][1], sx = C[i][2], sy = C[i][3], pts = [];
      for (var k = 0; k <= 10; ++k) { var b = (Math.PI / 2) * k / 10; pts.push(new Point(x + sx * 12 * Math.sin(b), y + sy * 12 * Math.cos(b))); }
      g.drawPolyline(pts);
      g.fillCircle(x + sx * 4.2, y + sy * 4.2, 1.1, new Brush(0xc0C99A3A));
   }
}
// kb (opcional, 6-nov): la escala de la cabina que ya lleva g (scaleTransformation); con ella la nave se pinta pixel a pixel
function fvBootPaint(g, W, H, B, bg, alpha, kb) {
   if (typeof FV_E6_FINE !== "undefined" && !FV_E6_FINE) return fvBootPaintN(g, W, H, B, bg, alpha);
   if (FV_BOOT_SHIP.ON && fvBootShipManifest()) return fvBootPaintShip(g, W, H, B, bg, alpha, kb || 1);
   g.antialiasing = true; g.textAntialiasing = true;
   if (bg) {
      var cover = Math.max(W / bg.width, H / bg.height), bw = bg.width * cover, bh = bg.height * cover;
      g.drawScaledBitmap((W - bw) / 2, (H - bh) / 2, (W + bw) / 2, (H + bh) / 2, bg);
      g.fillRect(0, 0, W, H, new Brush(((Math.round(255 * (0.78 - 0.45 * fvBootFraction(B))) << 24) | 0x07060A) >>> 0));
   }
   var a = (alpha === undefined) ? 1 : alpha;
   if (a <= 0.01) return;
   var op = g.opacity; g.opacity = a;
   var pw = 620, ph = 500, x0 = Math.round((W - pw) / 2), y0 = Math.round((H - ph) / 2) - 6, i, C = FV_BOOT_COL;
   fvEngravedPanel(g, x0, y0, x0 + pw, y0 + ph, true);
   // el titulo: serif de alto contraste, marfil, muy espaciado
   var fBig = cpFont("display", 33, false, false, 9), title = fvTx("boot.title");
   g.font = fBig; var wt = fBig.width(title);
   g.pen = new Pen(C.ivory); g.drawText(x0 + (pw - wt) / 2, y0 + 56, title);
   var fSub = cpFont("display", 12, false, true, 2), sub = fvTx("boot.sub");
   g.font = fSub; g.pen = new Pen(C.goldT); g.drawText(x0 + (pw - fSub.width(sub)) / 2, y0 + 76, sub);
   fvOrnRule(g, x0 + 40, x0 + pw - 40, y0 + 88, C.gold);
   // los sistemas
   var fN = cpFont("display", 13, false, false, 1), fW = cpFont("text", 10, false, true), fS = cpFont("display", 8, false, false, 2), ry = y0 + 112;
   for (i = 0; i < B.order.length; ++i) {
      var id = B.order[i], s = B.sys[id], lc = fvBootLamp(s.st), lx = x0 + 42, ly = ry - 4;
      g.pen = new Pen(s.st === "off" ? 0xff5E4A26 : C.gold, 0.9); g.drawCircle(lx, ly, 5.2);
      if (lc) {
         var la = (s.st === "warm") ? 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(B.t * 7)) : 1;
         g.fillCircle(lx, ly, 2.8, new Brush(((Math.round(255 * la) << 24) | (lc & 0xffffff)) >>> 0));
      }
      var nm = fvTx("sys." + id);
      g.font = fN; g.pen = new Pen(s.st === "off" ? C.dim : C.ivory); g.drawText(lx + 16, ry, nm);
      var wN = fN.width(nm);
      g.font = fW; g.pen = new Pen(s.st === "off" ? 0xff5A4D3A : C.goldT); g.drawText(lx + 24 + wN, ry, fvTx("sys." + id + ".what"));
      var stTxt = fvTx("st." + (s.st === "fail" ? "skip" : s.st)).toUpperCase();
      g.font = fS; g.pen = new Pen(lc && s.st !== "skip" ? lc : C.dim);
      g.drawText(x0 + pw - 36 - fS.width(stTxt), ry - 1, stTxt);
      ry += 30;
   }
   fvOrnRule(g, x0 + 40, x0 + pw - 40, ry - 12, C.gold);
   // lo que se hace (los guiños ya no: E10)
   var fD = cpFont("text", 12, false, true), fWk = cpFont("display", 12, false, true, 1), doing = fvBootDoing(B), wink = fvBootWink(B);
   g.font = fD; g.pen = new Pen(B.fail ? C.fail : C.ivory2); g.drawText(x0 + 34, ry + 12, cpElide(fD, doing, pw - 210));
   if (wink) { g.font = fWk; g.pen = new Pen(C.goldT); g.drawText(x0 + 34, ry + 32, cpElide(fWk, "— " + wink, pw - 210)); }
   // el interruptor de cuchilla (POTENTIA), a linea
   fvKnifeSwitchFine(g, x0 + pw - 92, ry + 42, B.started ? 1 : 0);
   B.leverRect = [x0 + pw - 150, ry - 4, x0 + pw - 30, ry + 92];
   g.opacity = op;
}
// (E6) el interruptor de cuchilla dibujado a buril: base con filete doble, bornes y pivote a linea, la cuchilla como dos filetes
// paralelos y el mango como un ovalo; nada relleno salvo el punto del pivote
function fvKnifeSwitchFine(g, cx, cy, on) {
   var C = FV_BOOT_COL;
   g.pen = new Pen(C.gold, 1); g.drawRect(cx - 44, cy - 20, cx + 44, cy + 30);
   g.pen = new Pen(0x90C99A3A, 0.6); g.drawRect(cx - 40, cy - 16, cx + 40, cy + 26);
   g.pen = new Pen(C.gold, 0.9); g.drawRect(cx + 14, cy + 2, cx + 26, cy + 18); g.drawLine(cx + 17, cy + 2, cx + 17, cy + 18); g.drawLine(cx + 23, cy + 2, cx + 23, cy + 18);
   var px = cx - 22, py = cy + 10, ang = (-70 + 70 * on) * Math.PI / 180, L = 44, ca = Math.cos(ang), sa = Math.sin(ang), nx = -sa * 2, ny = ca * 2;
   var ex = px + ca * L, ey = py + sa * L;
   g.pen = new Pen(C.goldL, 1); g.drawLine(px + nx, py + ny, ex + nx, ey + ny); g.drawLine(px - nx, py - ny, ex - nx, ey - ny);
   g.pen = new Pen(C.gold, 1); g.drawCircle(px, py, 5.5); g.fillCircle(px, py, 1.6, new Brush(C.goldL));
   var hx = px + ca * (L + 9), hy = py + sa * (L + 9);
   g.pen = new Pen(C.ivory2, 1); g.drawLine(ex, ey, hx, hy); g.drawCircle(hx, hy, 4.2);
   var f = cpFont("display", 8, false, false, 3); g.font = f; g.pen = new Pen(C.goldT); g.drawText(cx - f.width("POTENTIA") / 2, cy + 44, "POTENTIA");
}
// (pasada N) la placa de esmalte de antes: solo para el ROJO de las comparativas
function fvBootPaintN(g, W, H, B, bg, alpha) {
   g.antialiasing = true; g.textAntialiasing = true;
   if (bg) {
      var cover = Math.max(W / bg.width, H / bg.height), bw = bg.width * cover, bh = bg.height * cover;
      g.drawScaledBitmap((W - bw) / 2, (H - bh) / 2, (W + bw) / 2, (H + bh) / 2, bg);
      g.fillRect(0, 0, W, H, new Brush(((Math.round(255 * (0.78 - 0.45 * fvBootFraction(B))) << 24) | 0x07060A) >>> 0));
   }
   var a = (alpha === undefined) ? 1 : alpha;
   if (a <= 0.01) return;
   var op = g.opacity; g.opacity = a;
   var pw = 620, ph = 500, x0 = Math.round((W - pw) / 2), y0 = Math.round((H - ph) / 2) - 6, i;
   fvEnamelPanel(g, x0, y0, x0 + pw, y0 + ph, true);
   // DON'T PANIC
   var fBig = cpFont("display", 34, true, false, 6), title = fvTx("boot.title");
   g.font = fBig; var wt = fBig.width(title);
   g.pen = new Pen(0x50000000); g.drawText(x0 + (pw - wt) / 2 + 2, y0 + 54, title);
   g.pen = new Pen(0xffB8442A); g.drawText(x0 + (pw - wt) / 2, y0 + 52, title);
   var fSub = cpFont("display", 12, false, true, 2), sub = fvTx("boot.sub");
   g.font = fSub; g.pen = new Pen(FV_HUD_COL.sepia); g.drawText(x0 + (pw - fSub.width(sub)) / 2, y0 + 72, sub);
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawLine(x0 + 24, y0 + 84, x0 + pw - 24, y0 + 84);
   // los sistemas
   var fN = cpFont("display", 13, false, false, 1), fW = cpFont("text", 10, false, true), fS = cpFont("mono", 10), ry = y0 + 108;
   for (i = 0; i < B.order.length; ++i) {
      var id = B.order[i], s = B.sys[id], lc = FV_LAMP[s.st] || FV_LAMP.off, lx = x0 + 40, ly = ry - 4;
      var glow = (s.st === "warm") ? 0.5 + 0.5 * Math.sin(B.t * 7) : (s.st === "ok" || s.st === "local") ? 1 : 0;
      if (glow > 0) g.fillCircle(lx, ly, 13, new RadialGradientBrush(new Point(lx, ly), 13, new Point(lx, ly), [[0, ((Math.round(150 * glow) << 24) | (lc & 0xffffff)) >>> 0], [1, (lc & 0xffffff) >>> 0]]));
      g.fillCircle(lx, ly, 7.5, fvBrassBrush(lx, ly, 7.5));
      g.fillCircle(lx, ly, 5.2, new RadialGradientBrush(new Point(lx - 1.5, ly - 2), 6, new Point(lx - 1.5, ly - 2), [[0, s.st === "off" ? 0xff5A4630 : 0xffFFF6DC], [0.45, lc], [1, s.st === "off" ? 0xff1A1208 : lc]]));
      g.font = fN; g.pen = new Pen(s.st === "off" ? 0xff8A7A60 : FV_HUD_COL.ink); g.drawText(lx + 18, ry, fvTx("sys." + id));
      var wN = fN.width(fvTx("sys." + id));
      g.font = fW; g.pen = new Pen(FV_HUD_COL.sepia); g.drawText(lx + 24 + wN, ry, "· " + fvTx("sys." + id + ".what"));
      var stTxt = fvTx("st." + (s.st === "fail" ? "skip" : s.st));
      g.font = fS; g.pen = new Pen(s.st === "ok" ? FV_HUD_COL.stampOk : (s.st === "local" || s.st === "warm") ? FV_HUD_COL.stampWarn : (s.st === "fail" ? FV_HUD_COL.stampBad : 0xff8A7A60));
      g.drawText(x0 + pw - 34 - fS.width(stTxt), ry, stTxt);
      ry += 30;
   }
   g.pen = new Pen(FV_HUD_COL.brassD, 0.8); g.drawLine(x0 + 24, ry - 12, x0 + pw - 24, ry - 12);
   // lo que se hace y el guiño
   var fD = cpFont("text", 12), fWk = cpFont("display", 12, false, true, 1), doing = fvBootDoing(B), wink = fvBootWink(B);
   g.font = fD; g.pen = new Pen(B.fail ? FV_HUD_COL.stampBad : FV_HUD_COL.ink); g.drawText(x0 + 30, ry + 8, cpElide(fD, doing, pw - 200));
   if (wink) { g.font = fWk; g.pen = new Pen(0xffB8442A); g.drawText(x0 + 30, ry + 28, cpElide(fWk, "— " + wink, pw - 200)); }
   // el interruptor de cuchilla (POTENTIA)
   // debajo de la raya (en F2 v1 la tapaba, y tambien el «off» de la ultima fila: f2_apagada.png del 4-nov)
   fvKnifeSwitch(g, x0 + pw - 92, ry + 42, B.started ? 1 : 0);
   B.leverRect = [x0 + pw - 150, ry - 4, x0 + pw - 30, ry + 92];
   g.opacity = op;
}
// interruptor de cuchilla: base de pizarra, dos bornes de laton, la cuchilla y su mango de ebano. on: 0 (arriba) … 1 (cerrada)
function fvKnifeSwitch(g, cx, cy, on) {
   g.fillRect(cx - 44, cy - 20, cx + 44, cy + 30, new Brush(0xff2A231C)); g.pen = new Pen(FV_HUD_COL.brass, 1.2); g.drawRect(cx - 44, cy - 20, cx + 44, cy + 30);
   fvRivet(g, cx - 38, cy - 14, 2); fvRivet(g, cx + 38, cy - 14, 2); fvRivet(g, cx - 38, cy + 24, 2); fvRivet(g, cx + 38, cy + 24, 2);
   g.fillRect(cx + 14, cy + 2, cx + 26, cy + 18, fvBrassBrush(cx + 20, cy + 10, 8));                 // borne de contacto
   var px = cx - 22, py = cy + 10, ang = (-70 + 70 * on) * Math.PI / 180, L = 44, ex = px + Math.cos(ang) * L, ey = py + Math.sin(ang) * L;
   g.fillCircle(px, py, 6, fvBrassBrush(px, py, 6));                                                   // pivote
   g.pen = new Pen(0xffD9B260, 5); g.drawLine(px, py, ex, ey);
   g.pen = new Pen(0xff7A5A1E, 1); g.drawLine(px, py + 2, ex, ey + 2);
   var hx = px + Math.cos(ang) * (L + 10), hy = py + Math.sin(ang) * (L + 10);
   g.pen = new Pen(0xff1A1208, 8); g.drawLine(ex, ey, hx, hy);                                          // mango
   g.fillCircle(hx, hy, 5, new Brush(0xff1A1208));
   var f = cpFont("display", 8, false, false, 2); g.font = f; g.pen = new Pen(FV_HUD_COL.ink); g.drawText(cx - f.width("POTENTIA") / 2, cy + 44, "POTENTIA");     // tinta: el oro no se leia sobre el esmalte
}

// ============================================================================
// (6-nov-2026) LA NAVE DEL ARRANQUE: en vez de la lista, la nave FieldVoyager girando despacio (72 fotogramas de Blender, rsc/nave/,
// hechos por tools/build_nave_rsc.py) y, segun arranca cada sistema REAL de fvBuildScene, una flecha fina de laton desde su rotulo
// (a los lados de la nave, huecos fijos: nunca se pisan) hasta la pieza que lo representa, con un halo ambar sobre ella mientras
// calienta; al terminar, el rotulo lleva su ✓ y se apaga. Al final (todo listo) se encienden los casquetes de las gondolas y los
// ojos de la cabra, y la placa se funde con la cabina como siempre. La animacion NUNCA retrasa el arranque: lee el estado de
// verdad (B.sys) y, si varios sistemas acaban casi a la vez, los enseña en cola con un minimo de MIN_S cada uno; esa cola solo
// alarga el fundido final, y como mucho MAX_EXTRA_S.
// En onPaint no se hace nada de esto: se pinta en el fotograma (renderNow, desde el reloj o el bombeo de power()); los fotogramas
// se leen de disco UNA vez, a demanda (el primero al abrir, el resto segun gira), ya escalados a pixeles de pantalla, y se sueltan
// al terminar el fundido (fvBootShipFree).
// FV_BOOT_SHIP.ON = false: la placa de antes con la lista de sistemas (ROJO de las comparativas).
// ============================================================================
var FV_BOOT_SHIP = { ON: true,
                     TURN_S: 30,            // una vuelta en 30 s (Nino, 6-nov: más lenta; con 144 fotogramas, 4,8 por segundo + fundido)
                     START_DEG: 315,        // tres cuartos, la proa a la izquierda (todo va por ANGULO: vale cualquier numero de fotogramas)
                     SMOOTH: true,          // (6-nov, Nino: «totalmente fluido») angulo continuo: fotograma i y el i+1 fundido con la parte
                                            // fraccionaria; las anclas tambien se interpolan. false = a saltos (ROJO)
                     MIN_S: 0.30,           // lo minimo que se ve la flecha de un sistema (si acaban varios a la vez, en cola)
                     LAG_MAX: 0.8,          // con la cola atrasada mas de esto, el minimo encoge (hasta un 25 %)
                     FINAL_S: 0.45,         // el brillo final (casquetes y cabra) antes de la partida
                     MAX_EXTRA_S: 0.6,      // lo que la cola puede alargar el fundido como mucho (el brillo final va en los 0,5 s de
                                            // espera que el fundido ya tenia: fvDialog.renderNow)
                     OUT_S: 0.6,            // lo que tarda en apagarse la flecha de un sistema ya listo
                     HALO: 70, HALO_END: 120,   // diametro del halo (unidades de la cabina): sistema calentando y brillo final
                     CACHE: 12,             // fotogramas escalados que se guardan (los N ultimos; 0 = todos: ~1,2 MB cada uno, con 144 serian 170 MB)
                     // (7-nov, Nino: «al principio el barco gira. Cuando aprieto el interruptor, deja de girar y cada una de las frases muestra
                     // una zona del barco donde apunta y la perspectiva desde un punto diferente. Así no hay paradas ni movimientos extraños»)
                     // LOS PLANOS FIJOS: con rsc/nave/manifest.json «shots», el giro es solo la ESPERA (antes de POTENTIA); al tirar de el, el
                     // giro se frena (STOP_S) y se funde con el plano fijo del sistema que arranca; cada sistema nuevo, otro fundido (XF) a su
                     // plano, con su flecha y su halo. Como la imagen esta QUIETA, los pasos pesados (sin bombeo) ya no se ven como tirones.
                     // Si varios sistemas llegan seguidos, cada plano se ve al menos XF + HOLD y se salta a lo mas nuevo (nunca se espera).
                     // false = el giro con flechas durante el arranque (6-nov; el ROJO de la prueba de tirones)
                     STILLS: true,
                     STOP_S: 0.4,           // lo que tarda el giro en pararse al tirar del interruptor
                     XF: 0.5,               // fundido entre planos
                     HOLD: 0.35,            // (cola apagada) lo minimo que un plano se queda quieto, ya fundido, antes del siguiente
                     XF_OK: 0.45,           // fundido al plano final (casquetes y ojos de la cabra encendidos)
                     // (7-nov, Nino: «Sí, los 9 siempre») LA COLA: los 9 planos SIEMPRE, en el orden en que arrancan, cada uno quieto al menos
                     // Q_HOLD s ya fundido (rotulo + flecha + halo se leen); si su sistema ya habia acabado mientras esperaba en la cola, se ve
                     // calentando WARM_MIN s y luego el ✓. El arranque de verdad no espera a nadie: lo que alarga es la PRESENTACION, despues.
                     // false = el comportamiento anterior (se salta a lo mas nuevo: el ROJO de la prueba)
                     // (8-nov, Nino: primero «un mínimo de 3 segundos viéndose», luego «cambia a 2 segundos») Q_HOLD 1,2 → 2 y el plano
                     // final también ≥ OK_HOLD s quieto antes de la partida (antes XF_OK + FINAL_S = 0,9 s)
                     QUEUE: true, Q_HOLD: 2.0, WARM_MIN: 0.6, OK_HOLD: 2.0,
                     // (9-nov, Nino viendo el arranque en su PixInsight: «cuando algo tarda mas de dos segundos parece que pasa por encima de las
                     // imagenes siguientes. Cada imagen tiene que tardar un minimo de 2 segundos y un maximo de lo que tarde en cargar el tema»)
                     // LA REGLA, por plano (los 9 y el final): se VE entero (fundido hecho) ≥ Q_HOLD / OK_HOLD s y no acaba antes que su tarea; el
                     // siguiente no empieza hasta que se cumplen las dos cosas; ninguno se salta ni se pisa. Dos fallos de antes:
                     //  (a) fvBootSet sellaba las tareas con B.t, que solo avanza al PINTAR: tras un paso largo sin pintar (StarXTerminator, PixInsight
                     //      ocupado) el sello iba atrasado y el siguiente plano ya «estaba vencido»;
                     //  (b) la pantalla congelada medio fundido no cuenta como visto: al volver a pintar el plano ya estaba fundido y la cola lo
                     //      sustituia de inmediato (el plano se «saltaba» sin haberse visto). Ahora el fundido en curso se PAUSA con el reloj de
                     //      pintado (huecos > GAP_S) y continua donde iba. El plano final cuenta OK_HOLD quieto (fundido aparte), como los demas.
                     // false = lo de antes (el ROJO de tests/fv_boot_hold_test.js)
                     HOLD_TASK: true, GAP_S: 0.15,
                     // (7-nov, Nino: «la nave girando está como desenfocada») el fundido entre fotogramas del giro solo en la parte central
                     // de cada intervalo (BLEND_W; 1 = fundido lineal de todo el intervalo, el de antes): menos doble exposicion.
                     // Medido (tests/fv_boot_ship_nitidez.py, barco a 977 px, 30 pintadas/s): lineal nitidez media 70 % y escalones 1,1;
                     // 0,5 → 88 % y 2,98; 0,35 → 92 % y 4,1; corte 100 % y 6,7. 0,5: lo mas nitido sin pasar de 3 (el «sin golpe» de G y F)
                     BLEND_W: 0.5 };
// (9-nov) BANDERA DE PRUEBAS: TEST_DELAY = { <id>: { s: segundos, pump: true|false } } hace que la tarea de ese sistema tarde s segundos mas
// (pump: la placa se sigue pintando, como con la red; false: PixInsight ocupado sin pintar, como el StarXTerminator). null = nada (lo de serie)
FV_BOOT_SHIP.TEST_DELAY = null;
function fvBootTestDelay(id, st, pump) {
   var d = FV_BOOT_SHIP.TEST_DELAY, e = d && d[id];
   if (!e || e.done || st === "warm" || st === "off") return;
   e.done = true;
   var t0 = fvNowMs();
   while ((fvNowMs() - t0) / 1000 < e.s) { if (e.pump) { if (pump(true)) break; } }
}
var FV_BOOT_SHIP_ROOT = (function() { try { return (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/").replace(/\/src\/ui\/?$/, ""); } catch (e) { return ""; } })();
var FV_BOOT_SHIP_STORE = { man: null, tried: false, err: "", bmp: {}, keys: [], key: "", halo: {}, nLoad: 0, msLoad: 0, still: {}, stillKey: "", nStill: 0, msStill: 0 };
// los sistemas a la izquierda (0) y a la derecha (1) de la nave (alternos, en el orden del arranque)
var FV_BOOT_SHIP_SIDE = { nav: 0, charts: 1, range: 0, filters: 1, atlas: 0, shields: 1, sensors: 0, dome: 1, holo: 0 };

function fvBootShipManifest() {
   var S = FV_BOOT_SHIP_STORE;
   if (S.man || S.tried) return S.man;
   S.tried = true;
   try {
      var p = FV_BOOT_SHIP_ROOT + "/rsc/nave/manifest.json";
      if (!File.exists(p)) S.err = "missing " + p;
      else {
         var m = JSON.parse(File.readTextFile(p));
         if (!m || !m.frames || !m.crop || !m.anchors || !m.ready) S.err = "bad manifest " + p;
         else S.man = m;
      }
   } catch (e) { S.err = String(e); S.man = null; }
   if (S.err && typeof fvLog === "function") fvLog("boot ship: " + S.err + " (the old boot plate is used)");
   return S.man;
}
// el fotograma i escalado a dw x dh pixeles de pantalla (cache; si cambia el tamaño, se vacia)
function fvBootShipFrame(i, dw, dh) {
   var S = FV_BOOT_SHIP_STORE, key = dw + "x" + dh;
   if (S.key !== key) { S.bmp = {}; S.keys = []; S.halo = {}; S.key = key; }
   if (S.bmp[i] !== undefined) return S.bmp[i];
   if (FV_BOOT_SHIP.CACHE > 0) while (S.keys.length >= FV_BOOT_SHIP.CACHE) delete S.bmp[S.keys.shift()];
   var b = null, t0 = Date.now();
   try {
      var nm = S.man.file.replace("%03d", ("00" + i).slice(-3)), p = FV_BOOT_SHIP_ROOT + "/rsc/nave/" + nm;
      if (File.exists(p)) b = fvBootShipScaled(new Bitmap(p), dw, dh);
   } catch (e) { b = null; }
   S.bmp[i] = b; S.keys.push(i); ++S.nLoad; S.msLoad += Date.now() - t0;
   return b;
}
function fvBootShipScaled(src, dw, dh) {
   if (src.width === dw && src.height === dh) return src;
   var c = new Bitmap(dw, dh, BitmapFormat.ARGB32); c.fill(0x00000000);
   var g = new Graphics(c);
   try { g.smoothInterpolation = true; g.drawScaledBitmap(0, 0, dw, dh, src); } finally { g.end(); }
   return c;
}
// el halo a d pixeles de pantalla (cache por tamaño)
function fvBootShipHalo(d) {
   var S = FV_BOOT_SHIP_STORE, k = Math.max(4, Math.round(d));
   if (S.halo[k] !== undefined) return S.halo[k];
   var b = null;
   try { var p = FV_BOOT_SHIP_ROOT + "/rsc/nave/" + S.man.halo; if (File.exists(p)) b = fvBootShipScaled(new Bitmap(p), k, k); } catch (e) { b = null; }
   S.halo[k] = b;
   return b;
}
// suelta los fotogramas (al acabar el fundido o al cerrar). El manifiesto se queda (es pequeño)
function fvBootShipFree() { var S = FV_BOOT_SHIP_STORE; S.bmp = {}; S.keys = []; S.halo = {}; S.key = ""; S.still = {}; S.stillKey = ""; S.band = null; S.bandKey = ""; }
// el fotograma que toca a los t s
function fvBootShipDpf() { var m = FV_BOOT_SHIP_STORE.man; return m.deg_per_frame || 360 / m.frames; }
// B (opcional): con los planos fijos, desde B.tSwitch (POTENTIA) el giro se frena en STOP_S con deceleracion constante
function fvBootShipAngle(t, B) {
   var C = FV_BOOT_SHIP, v = 360 / C.TURN_S;
   if (B && B.tSwitch !== undefined && fvBootShotsOn() && t > B.tSwitch) { var u = Math.min(1, (t - B.tSwitch) / C.STOP_S); return C.START_DEG + v * Math.max(0, B.tSwitch) + v * C.STOP_S * (u - u * u / 2); }
   return C.START_DEG + v * Math.max(0, t);
}

// ---------------------------------------------------------------------------
// (7-nov) LOS PLANOS FIJOS (ver FV_BOOT_SHIP.STILLS). B.shot = { ch: [{ t, key }], seen: {id: true}, nxt, okT }: los cambios de plano YA
// decididos (se deciden al pintar, con el reloj del arranque: un cambio nunca cae en el pasado, asi que un hueco largo sin pintar no
// produce un salto a mitad de fundido). key: "tt" (el giro, parado), un sistema de B.order o "ok" (el final).
// ---------------------------------------------------------------------------
function fvBootShotsOn() { var m = FV_BOOT_SHIP_STORE.man; return !!(FV_BOOT_SHIP.STILLS && m && m.shots && m.shots.list); }
// la caja del plano (unidades de la cabina): el FOTOGRAMA ENTERO del giro (src_res) a la escala del giro; asi el plano final casa con
// d_000 de la partida (Blender lo hace con su camara) y la partida sigue sin salto
function fvBootShotBox(L) {
   var m = FV_BOOT_SHIP_STORE.man, r = m.src_res || [960, 540];
   return { x: L.sx - m.crop[0] * L.s, y: L.sy - m.crop[1] * L.s, w: r[0] * L.s, h: r[1] * L.s };
}
// el plano «key» a dw x dh pixeles de pantalla (se lee UNA vez y se escala UNA vez; al cambiar el tamaño se vacia)
function fvBootStill(key, dw, dh) {
   var S = FV_BOOT_SHIP_STORE, k = dw + "x" + dh;
   if (S.stillKey !== k) { S.still = {}; S.stillKey = k; }
   if (S.still[key] !== undefined) return S.still[key];
   var b = null, t0 = Date.now(), e = S.man.shots.list[key];
   try { var p = FV_BOOT_SHIP_ROOT + "/rsc/nave/" + (e ? e.file : ""); if (e && File.exists(p)) b = fvBootShipScaled(new Bitmap(p), dw, dh); } catch (eS) { b = null; }
   S.still[key] = b; ++S.nStill; S.msStill += Date.now() - t0;
   return b;
}
// decide los cambios de plano hasta B.t (lo llama el pintor)
function fvBootShotUpdate(B, SC) {
   var C = FV_BOOT_SHIP, t = B.t, list = FV_BOOT_SHIP_STORE.man.shots.list, i, id;
   if (!B.started) return;
   if (B.tSwitch === undefined) B.tSwitch = t;
   var S = B.shot || (B.shot = { ch: [], seen: {}, nxt: B.tSwitch + C.STOP_S, okT: undefined });
   var last = S.ch.length ? S.ch[S.ch.length - 1] : null;
   // (9-nov) el reloj de pintado: un hueco largo entre dos pintadas con un fundido a medias lo PAUSA (ver HOLD_TASK). Se descuenta GAP_S: una pintada
      // lenta pero constante (maquina muy cargada) sigue avanzando GAP_S por pintada y el fundido siempre acaba. ch[].p = cuando se decidio el cambio
   if (C.HOLD_TASK) {
      if (S.pt !== undefined && last && t - S.pt > C.GAP_S && S.pt < last.t + ((last.key === "ok") ? C.XF_OK : C.XF)) {
         var sh = t - S.pt - C.GAP_S; last.t += sh; S.nxt += sh; if (S.okT !== undefined) S.okT = last.t;
      }
      S.pt = t;
   }
   if (S.okT !== undefined) return;
   if (C.QUEUE) {
      if (t < S.nxt) return;
      // (9-nov) y el siguiente no sale hasta que acabe de verdad la tarea del plano que se ve
      if (C.HOLD_TASK && last && last.key !== "ok" && !B.done) { var ps = B.sys[last.key]; if (ps && ps.tOk === undefined) return; }
      // el siguiente de la cola: de los que ya han EMPEZADO de verdad (o todos, si el arranque ya acabo) y sin plano, el que empezo antes
      var nx = null, nt = Infinity, ni = Infinity, left = 0;
      for (i = 0; i < B.order.length; ++i) {
         id = B.order[i]; if (!list[id] || S.seen[id]) continue;
         ++left;
         var sy = B.sys[id], st0 = (sy.st !== "off") ? (typeof sy.t === "number" ? sy.t : 0) : (B.done ? 1e9 : Infinity);
         if (st0 === Infinity) continue;
         if (st0 < nt || (st0 === nt && i < ni)) { nt = st0; ni = i; nx = id; }
      }
      if (nx) { S.ch.push({ t: t, key: nx, p: t }); S.seen[nx] = true; S.nxt = t + C.XF + C.Q_HOLD; return; }
      // todos enseñados: el final, cuando el arranque de verdad ha acabado
      if (left === 0 && B.done && list.ok) { S.ch.push({ t: t, key: "ok" }); S.okT = t; }
      return;
   }
   // el final: en cuanto todo esta listo (y el fundido anterior ha acabado), al plano final
   if (SC.ready !== Infinity && t >= SC.ready && list.ok) {
      if (t >= (last ? last.t + C.XF : B.tSwitch + C.STOP_S)) { S.ch.push({ t: t, key: "ok" }); S.okT = t; }
      return;
   }
   if (t < S.nxt) return;
   // de los sistemas ya enseñados por la cola (SC.w <= t) y sin plano aun, el MAS NUEVO; los otros se saltan
   var pick = null, pw = -Infinity;
   for (i = 0; i < B.order.length; ++i) { id = B.order[i]; var sc = SC[id]; if (!sc || S.seen[id] || !(sc.w <= t) || !list[id]) continue; if (sc.w >= pw) { pw = sc.w; pick = id; } }
   if (!pick) return;
   for (i = 0; i < B.order.length; ++i) { id = B.order[i]; if (SC[id] && SC[id].w <= t) S.seen[id] = true; }
   S.ch.push({ t: t, key: pick }); S.nxt = t + C.XF + C.HOLD;
}
// (7-nov) LA FRANJA bajo los rotulos: los planos de cerca (4 y 9: el casco y la celosia llenan los tercios) llegan por debajo de las
// columnas de rotulos. Un mapa de bits del tamaño de la caja, transparente en el centro y con el color de la placa a los lados (casi
// opaco donde estan los rotulos y desvaneciendose hacia la nave) y un fundido corto arriba y abajo para que la caja no se vea como un
// recorte. Se hace UNA vez por tamaño (columnas de 2 px en pixeles de pantalla) y se pinta con una sola copia
function fvBootShotBand(L, BX, kb, dw, dh) {
   var S = FV_BOOT_SHIP_STORE, key = dw + "x" + dh + "/" + Math.round(L.sx * kb);
   if (S.bandKey === key) return S.band;
   var b = new Bitmap(dw, dh, BitmapFormat.ARGB32); b.fill(0x00000000);
   var g = new Graphics(b), x, y, st = 2;
   try {
      g.antialiasing = false;
      var x1 = (L.sx - 30 - BX.x) * kb, x2 = (L.sx + 40 - BX.x) * kb, FT = 36 * kb;
      var aL = function(x) { return x <= x1 ? 1 - 0.12 * x / Math.max(1, x1) : Math.max(0, 0.88 * (1 - (x - x1) / (x2 - x1))); };
      for (x = 0; x < x2; x += st) {
         var al = aL(x + st / 2); if (al <= 0.003) continue;
         var br = new Brush(fvBootA(al, 0xff0D0A07));
         g.fillRect(x, 0, Math.min(x + st, dw), dh, br); g.fillRect(dw - Math.min(x + st, dw), 0, dw - x, dh, br);
      }
      for (y = 0; y < FT; y += st) { var av = 1 - (y + st / 2) / FT; var bv = new Brush(fvBootA(av, 0xff0D0A07)); g.fillRect(0, y, dw, y + st, bv); g.fillRect(0, dh - y - st, dw, dh - y, bv); }
   } finally { g.end(); }
   S.band = b; S.bandKey = key;
   return b;
}
// (7-nov) LA PRESENTACION con la cola: el estado de cada sistema tal como se ENSEÑA (no como va de verdad): calentando desde que sale su
// plano (w) hasta k = max(cuando acabo de verdad, w + WARM_MIN); antes de su plano, apagado. Mismo formato que fvBootShipSched.
function fvBootPresSched(B) {
   var C = FV_BOOT_SHIP, out = {}, w = {}, ch = (B.shot && B.shot.ch) || [], i;
   for (i = 0; i < ch.length; ++i) w[ch[i].key] = ch[i].t;
   for (i = 0; i < B.order.length; ++i) {
      var id = B.order[i], s = B.sys[id], st = s.st;
      if (st === "off" && B.done) st = "skip";
      var wi = (w[id] !== undefined) ? w[id] : Infinity, k = Infinity;
      if (wi !== Infinity && st !== "warm" && st !== "off") { var tOk = (s.tOk !== undefined) ? s.tOk : ((B.tDone !== undefined) ? B.tDone : wi); k = Math.max(tOk, wi + C.WARM_MIN); }
      out[id] = { w: wi, k: k, st: st };
   }
   out.ready = (B.shot && B.shot.okT !== undefined) ? B.shot.okT : Infinity; out.extra = 0;
   return out;
}
// lo que se ve a los t s: { from, to, f } (fundido de from a to; f = 1 ya fundido)
function fvBootShotView(B, t) {
   var ch = (B.shot && B.shot.ch) || [], k = ch.length - 1;
   while (k >= 0 && ch[k].t > t) --k;
   if (k < 0) return { from: null, to: "tt", f: 1 };
   var cur = ch[k], xf = (cur.key === "ok") ? FV_BOOT_SHIP.XF_OK : FV_BOOT_SHIP.XF;
   return { from: k > 0 ? ch[k - 1].key : "tt", to: cur.key, f: fvBootSmooth01((t - cur.t) / xf) };
}
// el angulo -> { i0, i1, f }: fotograma de debajo, el siguiente y cuanto de el (0 sin SMOOTH)
function fvBootShipPosAt(deg) {
   var n = FV_BOOT_SHIP_STORE.man.frames, fp = deg / fvBootShipDpf(), fl = Math.floor(fp), i0 = ((fl % n) + n) % n;
   if (!FV_BOOT_SHIP.SMOOTH) return { i0: ((Math.round(fp) % n) + n) % n, i1: i0, f: 0 };
   var f = fp - fl, bw = FV_BOOT_SHIP.BLEND_W;
   if (bw < 0.999) f = fvBootSmooth01((f - (1 - bw) / 2) / Math.max(1e-3, bw));          // fundido solo en la parte central del intervalo
   return { i0: i0, i1: (i0 + 1) % n, f: f };
}
function fvBootShipIndex(t) { return fvBootShipPosAt(fvBootShipAngle(t)).i0; }
// un ancla interpolada entre dos fotogramas -> [x, y, peso de visibilidad 0..1] (si solo esta en uno, su posicion con su peso)
function fvBootShipLerp(a0, a1, f) {
   if (!a0 && !a1) return null;
   if (!a1 || f <= 0) return a0 ? [a0[0], a0[1], (a0[2] ? 1 : 0) * (a1 ? 1 - f : 1)] : null;
   if (!a0) return [a1[0], a1[1], (a1[2] ? 1 : 0) * f];
   return [a0[0] + (a1[0] - a0[0]) * f, a0[1] + (a1[1] - a0[1]) * f, (a0[2] ? 1 : 0) * (1 - f) + (a1[2] ? 1 : 0) * f];
}
// los brillos del final (casquetes y cabra) interpolados por grupo -> [[x, y, peso]]
function fvBootShipReadyAt(m, P) {
   var R0 = m.ready[P.i0] || [], R1 = (P.f > 0 ? m.ready[P.i1] : null) || [], out = [], i, j, by = {};
   for (j = 0; j < R1.length; ++j) by[R1[j][2]] = R1[j];
   for (i = 0; i < R0.length; ++i) { var b = by[R0[i][2]]; if (b) { out.push([R0[i][0] + (b[0] - R0[i][0]) * P.f, R0[i][1] + (b[1] - R0[i][1]) * P.f, 1]); delete by[R0[i][2]]; } else out.push([R0[i][0], R0[i][1], 1 - P.f]); }
   for (var k in by) out.push([by[k][0], by[k][1], P.f]);
   return out;
}
function fvBootClamp01(x, lo) { return Math.max(lo || 0, Math.min(1, x)); }

// LA COLA: cuando se ENSEÑA cada sistema (calentando desde w hasta k; listo desde k) a partir de cuando paso de verdad (s.t, s.tOk).
// Devuelve { <id>: { w, k, st }, ready (cuando empieza el brillo final, o Infinity), extra (lo que alarga el fundido, ≤ MAX_EXTRA_S) }
// La cola va en el orden en que EMPEZARON (s.t; a igualdad, el de B.order); los que no han empezado, al final.
function fvBootShipSched(B) {
   var C = FV_BOOT_SHIP, cur = 0, out = {}, i, ord = B.order.slice();
   ord.sort(function(x, y) {
      var sx = B.sys[x], sy = B.sys[y], ox = sx.st === "off" ? 1 : 0, oy = sy.st === "off" ? 1 : 0;
      if (ox !== oy) return ox - oy;
      var tx = (typeof sx.t === "number") ? sx.t : 0, ty = (typeof sy.t === "number") ? sy.t : 0;
      return (tx !== ty) ? tx - ty : B.order.indexOf(x) - B.order.indexOf(y);
   });
   for (i = 0; i < ord.length; ++i) {
      var id = ord[i], s = B.sys[id], st = s.st;
      if (st === "off" && B.done) st = "skip";
      if (st === "off" || cur === Infinity) { out[id] = { w: Infinity, k: Infinity, st: st }; if (st !== "off") cur = Infinity; continue; }
      var t0 = (typeof s.t === "number") ? s.t : 0, w = Math.max(t0, cur), k = Infinity;
      if (st !== "warm") {
         var tOk = (s.tOk !== undefined) ? s.tOk : ((B.done && B.tDone !== undefined) ? B.tDone : t0);
         var lag = w - t0, minD = C.MIN_S * fvBootClamp01(1 - lag / C.LAG_MAX, 0.25);
         k = Math.max(tOk, w + minD);
      }
      out[id] = { w: w, k: k, st: st };
      cur = k;
   }
   var td = (B.done && B.tDone !== undefined) ? B.tDone : Infinity;
   out.ready = (td === Infinity || cur === Infinity) ? Infinity : Math.max(td, cur);
   out.extra = (td === Infinity) ? 0 : Math.min(C.MAX_EXTRA_S, Math.max(0, out.ready - td));
   return out;
}
// lo que el fundido final tiene que esperar por la cola (power() lo suma a bootFadeT0)
function fvBootShipExtra(B) { if (!FV_BOOT_SHIP.ON || !fvBootShipManifest()) return 0; return fvBootShipSched(B).extra; }

// LA GEOMETRIA (en unidades de la cabina, las de fvBootPaint): placa, nave, columnas de rotulos y huecos
function fvBootShipLayout(W, H) {
   var m = FV_BOOT_SHIP_STORE.man, cw = m.crop[2], ch = m.crop[3];
   var pw = Math.min(W - 48, 1180), ph = Math.min(H - 36, 640), x0 = Math.round((W - pw) / 2), y0 = Math.round((H - ph) / 2), x1 = x0 + pw, y1 = y0 + ph;
   var sy0 = y0 + 98, sy1 = y1 - 84, colW = Math.max(150, Math.min(220, pw * 0.17));
   var s = Math.min(1.0, (sy1 - sy0) / ch, (pw - 2 * colW - 40) / cw), sw = cw * s, sh = ch * s;
   var sx = x0 + (pw - sw) / 2, syy = sy0 + (sy1 - sy0 - sh) / 2;
   var L = { x0: x0, y0: y0, x1: x1, y1: y1, pw: pw, ph: ph, s: s, sx: sx, sy: syy, sw: sw, sh: sh, slots: {} };
   // huecos: 5 a la izquierda, 4 a la derecha (a media altura entre los de la izquierda)
   var ya = syy + 26, yb = syy + sh - 26, nL = 0, i, id;
   for (i = 0; i < FV_BOOT_ORDER.length; ++i) if (!FV_BOOT_SHIP_SIDE[FV_BOOT_ORDER[i]]) ++nL;
   var kL = 0, kR = 0, stepL = (yb - ya) / Math.max(1, nL - 1);
   for (i = 0; i < FV_BOOT_ORDER.length; ++i) {
      id = FV_BOOT_ORDER[i];
      if (FV_BOOT_SHIP_SIDE[id]) { L.slots[id] = { side: 1, x: sx + sw + 12, y: ya + stepL * (kR + 0.5), wMax: x1 - 30 - (sx + sw + 24) }; ++kR; }
      else { L.slots[id] = { side: 0, x: sx - 12, y: ya + stepL * kL, wMax: (sx - 24) - (x0 + 30) }; ++kL; }
   }
   return L;
}
// un color con su alfa multiplicado por a
function fvBootA(a, col) { return ((Math.round(255 * Math.max(0, Math.min(1, a)) * (((col >>> 24) & 255) / 255)) << 24) | (col & 0xffffff)) >>> 0; }

// la flecha: del rotulo, un tramo corto horizontal y luego recta hasta la pieza; punta abierta y un anillo fino sobre la pieza.
// hidden: la pieza esta detras (en este fotograma la tapa el casco): linea discontinua y anillo tenue
function fvBootArrow(g, sx, sy, tx, ty, side, a, hidden) {
   var C = FV_BOOT_COL, ex = sx + (side ? -16 : 16), dx = tx - ex, dy = ty - sy, d = Math.sqrt(dx * dx + dy * dy);
   if (d < 1) return;
   var ux = dx / d, uy = dy / d, gap = 7, px = tx - ux * gap, py = ty - uy * gap;
   g.pen = hidden ? new Pen(fvBootA(a * 0.75, C.goldL), 1, PenStyle_Dash) : new Pen(fvBootA(a, C.goldL), 1);
   g.drawLine(sx, sy, ex, sy); g.drawLine(ex, sy, px, py);
   g.pen = new Pen(fvBootA(a, C.goldL), 1.1);
   var ca = Math.cos(0.42), sa = Math.sin(0.42), hl = 7;
   g.drawLine(px, py, px - hl * (ux * ca - uy * sa), py - hl * (uy * ca + ux * sa));
   g.drawLine(px, py, px - hl * (ux * ca + uy * sa), py - hl * (uy * ca - ux * sa));
   g.pen = new Pen(fvBootA(a * (hidden ? 0.6 : 1), C.ivory), 0.9); g.drawCircle(tx, ty, 3.4);
   g.fillCircle(sx, sy, 1.6, new Brush(fvBootA(a, C.goldL)));
}
// el ✓ a linea (sin depender de la fuente)
function fvBootTick(g, x, y, col) { g.pen = new Pen(col, 1.4); g.drawLine(x - 3.2, y + 0.2, x - 1, y + 2.6); g.drawLine(x - 1, y + 2.6, x + 3.6, y - 3); }

// ---------------------------------------------------------------------------
// (6-nov, Nino) LA PARTIDA: tras el ✓ final, la nave enseña la popa (casquetes encendidos), se aleja hacia el centro de la foto
// encogiendo con perspectiva mientras la foto crece hasta el encuadre de la cabina (7-nov), con una estela calida de las gondolas; en el
// punto de fuga, un destello y la placa se funde con la cabina. Todo DESPUES de que el arranque
// ha terminado (nunca lo retrasa). Con rsc/nave/manifest.json «dep» (la secuencia de partida de Blender, d_000…) la popa sale de ahi;
// sin ella, del fotograma del giro mas a popa (STERN) con halos en los casquetes.
// Tiempos (s, reloj del arranque B.t): empieza en ready + FINAL_S; TURN gira a popa, RECEDE se aleja, FLASH destello, FADE se funde.
// FV_BOOT_SHIP.DEPART = false: el fundido de antes (la placa con la nave se desvanece sobre la cabina).
// ---------------------------------------------------------------------------
// (7-nov, Nino: «la nave se debe ir un poco mas despacio y se va haciendo pequeña y la imagen se va volviendo un poco mas grande hasta mostrar
// la imagen completa y el cockpit») RECEDE 0,85 → 1,8 s y encoge mas parejo (EASE 1,6 → 1,25); la foto ya no va y vuelve (ZOOM 0,07): empieza
// a Z0 de su encuadre (detras de la placa) y CRECE sin parar hasta el encuadre de la cabina justo cuando la nave se pierde; luego destello y
// fundido. TRAIL_S: la estela en segundos (no en fraccion de RECEDE: con mas RECEDE se separaba)
var FV_BOOT_DEP = { TURN: 0.6, RECEDE: 1.8, FLASH: 0.32, FADE: 0.6, Z0: 0.6, EASE: 1.25, STERN: 270, SHRINK: 14, TRAIL: 6, TRAIL_S: 0.03 };   // STERN en grados (popa franca)
FV_BOOT_SHIP.DEPART = true;
// la foto en la partida: { z (escala sobre su encuadre), g (0 → 1, lo que ha crecido) }; antes de la partida, Z0
function fvBootDepPhoto(ud) {
   var D = FV_BOOT_DEP, g = (ud === undefined || ud < 0) ? 0 : fvBootSmooth01((ud - D.TURN * 0.3) / (D.TURN * 0.7 + D.RECEDE));
   return { z: D.Z0 + (1 - D.Z0) * g, g: g };
}
// cuando empieza la partida (o Infinity si aun no)
// (7-nov) con los planos fijos, desde el plano final ya fundido (B.shot.okT + XF_OK) + FINAL_S
// (8-nov) y nunca antes de que el plano final lleve OK_HOLD s en pantalla
// (9-nov) con HOLD_TASK: el fundido (XF_OK) y ademas OK_HOLD s quieto (antes OK_HOLD contaba desde que empezaba el fundido: 1,55 s quieto)
function fvBootOkHoldS() { var C = FV_BOOT_SHIP; return C.HOLD_TASK ? C.XF_OK + Math.max(C.FINAL_S, C.OK_HOLD) : Math.max(C.XF_OK + C.FINAL_S, C.OK_HOLD); }
function fvBootDepStart(B, SC) {
   if (fvBootShotsOn() && FV_BOOT_SHIP_STORE.man.shots.list.ok) return (B.shot && B.shot.okT !== undefined) ? B.shot.okT + fvBootOkHoldS() : Infinity;
   var r = (SC || fvBootShipSched(B)).ready; return (r === Infinity) ? Infinity : r + FV_BOOT_SHIP.FINAL_S;
}
function fvBootDepTotal() { var D = FV_BOOT_DEP; return D.TURN + D.RECEDE + D.FLASH + D.FADE; }
// ¿la placa del final se pinta con la partida? (el dialogo entonces le da la foto y la opacidad sale de aqui)
function fvBootShipDepartOn() { return FV_BOOT_SHIP.ON && FV_BOOT_SHIP.DEPART && !!fvBootShipManifest() && !(typeof FV_E6_FINE !== "undefined" && !FV_E6_FINE); }
// opacidad de la placa del final con la partida: 1 hasta el destello, luego se funde en FADE
function fvBootShipOverlayAlpha(B) {
   var d0 = fvBootDepStart(B); if (d0 === Infinity) return 1;
   var D = FV_BOOT_DEP, e = d0 + D.TURN + D.RECEDE + D.FLASH;
   return 1 - fvSmooth(Math.max(0, Math.min(1, (B.t - e) / D.FADE)));
}
function fvBootSmooth01(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
// el fotograma de popa y sus casquetes: { kind: "dep"|"tt", i, caps: [[x, y], …] en px del recorte DEL GIRO }
function fvBootDepFrame(m, u) {
   var D = FV_BOOT_DEP, dep = m.dep;
   if (dep && dep.frames > 0) {
      var i = Math.max(0, Math.min(dep.frames - 1, Math.round(u * (dep.frames - 1)))), ox = dep.crop[0] - m.crop[0], oy = dep.crop[1] - m.crop[1], cs = [];
      var C = (dep.caps && dep.caps[i]) || []; for (var k = 0; k < C.length; ++k) cs.push([C[k][0] + ox, C[k][1] + oy]);
      return { kind: "dep", i: i, caps: cs, ox: ox, oy: oy, w: dep.crop[2], h: dep.crop[3] };
   }
   var st = fvBootShipPosAt(D.STERN).i0, R = m.ready[st] || [], c2 = [];
   for (var j = 0; j < R.length; ++j) if (String(R[j][2]).indexOf("nac") === 0) c2.push([R[j][0], R[j][1]]);
   return { kind: "tt", i: st, caps: c2, ox: 0, oy: 0, w: m.crop[2], h: m.crop[3] };
}
// el fotograma i de la partida escalado (misma cache que el giro, clave «d<i>»)
function fvBootDepBitmap(i, dw, dh) {
   var S = FV_BOOT_SHIP_STORE, k = "d" + i;
   if (S.key !== dw + "x" + dh) { S.bmp = {}; S.keys = []; S.halo = {}; S.key = dw + "x" + dh; }
   if (S.bmp[k] !== undefined) return S.bmp[k];
   var b = null;
   try { var p = FV_BOOT_SHIP_ROOT + "/rsc/nave/" + S.man.dep.file.replace("%03d", ("00" + i).slice(-3)); if (File.exists(p)) b = new Bitmap(p); } catch (e) { b = null; }
   // la partida va a su propio tamaño: se escala con la misma relacion que el giro
   if (b) { var sx = dw / S.man.crop[2]; b = fvBootShipScaled(b, Math.max(4, Math.round(b.width * sx)), Math.max(4, Math.round(b.height * sx))); }
   S.bmp[k] = b; ++S.nLoad;
   return b;
}

// la placa: panel, titulo, rotulos (y flechas y halos si arrows) y la fila de abajo, con opacidad a
function fvBootShipChrome(g, L, B, SC, t, a, part) {
   var C = FV_BOOT_COL, i, id;
   g.opacity = a;
   if (part === "back") {
      // placa OPACA: con la foto ya aclarada (todo listo) el 7 % que deja pasar el panel de la portada se veia como nebulosa dentro (pi_final, 6-nov)
      g.fillRect(L.x0, L.y0, L.x1, L.y1, new Brush(0xff0D0A07));
      // (7-nov) sin las dos diagonales tenues cuando la nave va en JPG opaco (sobre el color de la placa): la caja de la imagen las cortaria
      fvEngravedPanel(g, L.x0, L.y0, L.x1, L.y1, !FV_BOOT_SHIP_STORE.man.opaque);
      return;
   }
   if (part === "title") {
      // (7-nov) el titulo va DESPUES de la nave: la caja del plano fijo (el fotograma entero) llega a la altura del subtitulo
      var fBig = cpFont("display", 33, false, false, 9), title = fvTx("boot.title");
      g.font = fBig; g.pen = new Pen(C.ivory); g.drawText(L.x0 + (L.pw - fBig.width(title)) / 2, L.y0 + 56, title);
      var fSub = cpFont("display", 12, false, true, 2), sub = fvTx("boot.sub");
      g.font = fSub; g.pen = new Pen(C.goldT); g.drawText(L.x0 + (L.pw - fSub.width(sub)) / 2, L.y0 + 76, sub);
      fvOrnRule(g, L.x0 + L.pw * 0.28, L.x1 - L.pw * 0.28, L.y0 + 88, C.gold);
      return;
   }
   // los rotulos (huecos fijos: no se pisan nunca)
   var fN = cpFont("display", 12, false, false, 1), fW = cpFont("text", 9.5, false, true);
   for (i = 0; i < B.order.length; ++i) {
      id = B.order[i]; var sc = SC[id];
      var sl = L.slots[id], st = sc ? sc.st : "off", shown = !!sc && t >= sc.w, isWarm = shown && t < sc.k, isDone = shown && !isWarm;
      var nm = cpElide(fN, fvTx("sys." + id), sl.wMax - 8), wh = cpElide(fW, fvTx("sys." + id + ".what"), sl.wMax - 8);
      var cN = isWarm ? C.ivory : (isDone ? C.ivory2 : fvBootA(0.38, C.ivory2)), cW = isWarm ? C.goldL : (isDone ? fvBootA(0.75, C.goldT) : fvBootA(0.35, C.goldT));
      var lx = sl.x, ly = sl.y, tx0 = sl.side ? lx + 12 : lx - 12;
      g.font = fN; g.pen = new Pen(cN); g.drawText(sl.side ? tx0 : tx0 - fN.width(nm), ly + 4, nm);
      g.font = fW; g.pen = new Pen(cW); g.drawText(sl.side ? tx0 : tx0 - fW.width(wh), ly + 18, wh);
      // la lampara: anillo; calentando, punto ambar que late; listo, ✓ (verde; ambar con datos locales); sin servicio, una raya
      g.pen = new Pen(shown ? C.gold : fvBootA(0.45, C.gold), 0.9); g.drawCircle(lx, ly, 5.2);
      if (isWarm) g.fillCircle(lx, ly, 2.8, new Brush(fvBootA(0.45 + 0.55 * (0.5 + 0.5 * Math.sin(t * 7)), C.warm)));
      else if (isDone) {
         if (st === "ok") fvBootTick(g, lx, ly, C.ok);
         else if (st === "local") fvBootTick(g, lx, ly, C.local);
         else { g.pen = new Pen(st === "fail" ? C.fail : C.dim, 1.2); g.drawLine(lx - 2.8, ly, lx + 2.8, ly); }
      }
   }
   // abajo: lo que se hace de verdad y el interruptor de cuchilla (POTENTIA)
   var kx = L.x1 - 92, ky = L.y1 - 64;
   fvOrnRule(g, L.x0 + 40, kx - 70, L.y1 - 74, C.gold);
   var fD = cpFont("text", 12, false, true), doing = (B.done && !B.fail) ? fvTx("boot.ready") : fvBootDoing(B);
   // (7-nov) con la cola, acabado ya el arranque de verdad, abajo va el sistema que se ENSEÑA (no «listos» mientras siguen saliendo planos)
   if (B.done && !B.fail && FV_BOOT_SHIP.QUEUE && FV_BOOT_SHIP.ON && fvBootShotsOn() && !(B.shot && B.shot.okT !== undefined)) {
      var VQ = fvBootShotView(B, t);
      if (VQ.to && VQ.to !== "tt" && VQ.to !== "ok") doing = fvTx("sys." + VQ.to) + " · " + fvTx("sys." + VQ.to + ".what");
   }
   g.font = fD; g.pen = new Pen(B.fail ? C.fail : C.ivory2); g.drawText(L.x0 + 34, L.y1 - 40, cpElide(fD, doing, kx - 80 - (L.x0 + 34)));
   fvKnifeSwitchFine(g, kx, ky, B.started ? 1 : 0);
   B.leverRect = [kx - 58, ky - 46, kx + 62, ky + 50];
}

function fvBootPaintShip(g, W, H, B, bg, alpha, kb) {
   g.antialiasing = true; g.textAntialiasing = true;
   var a = (alpha === undefined) ? 1 : alpha;
   var L = fvBootShipLayout(W, H), m = FV_BOOT_SHIP_STORE.man, t = B.t, i, id, sc, p, q, scaled = Math.abs(kb - 1) > 1e-6;
   var SC = fvBootShipSched(B);
   // (7-nov) con los planos fijos los cambios se deciden aqui, antes de todo; con la cola, los rotulos siguen a la PRESENTACION
   if (FV_BOOT_SHIP.ON && fvBootShotsOn()) { fvBootShotUpdate(B, SC); if (FV_BOOT_SHIP.QUEUE) SC = fvBootPresSched(B); }
   var d0 = (B.done && FV_BOOT_SHIP.DEPART) ? fvBootDepStart(B, SC) : Infinity, ud = t - d0, DP = FV_BOOT_DEP;
   var dep = ud >= 0;
   // la foto de fondo, en penumbra; con la partida, mas pequeña (Z0) y en la partida crece y se aclara hasta el encuadre de la cabina
   if (bg) {
      var z = 1, dim = 0.78 - 0.45 * fvBootFraction(B);
      if (FV_BOOT_SHIP.DEPART) { var PH = fvBootDepPhoto(dep ? ud : undefined); z = PH.z; dim = dim * (1 - PH.g); }
      var cover = Math.max(W / bg.width, H / bg.height) * z, bw = bg.width * cover, bh = bg.height * cover;
      g.opacity = a;
      if (z < 0.9999) g.fillRect(0, 0, W, H, new Brush(0xff07060A));          // debajo esta la cabina: fuera de la foto, oscuro
      g.drawScaledBitmap((W - bw) / 2, (H - bh) / 2, (W + bw) / 2, (H + bh) / 2, bg);
      if (dim > 0.004) g.fillRect(0, 0, W, H, new Brush(((Math.round(255 * dim) << 24) | 0x07060A) >>> 0));
   }
   if (a <= 0.01) { g.opacity = 1; return; }
   var op = g.opacity;
   // un mapa de bits ya escalado a pixeles de pantalla, en su sitio (sin volver a escalarlo)
   function blit(b, x, y) {
      if (scaled) { g.resetTransformation(); g.drawBitmap(Math.round(x * kb), Math.round(y * kb), b); g.scaleTransformation(kb, kb); }
      else g.drawBitmap(Math.round(x), Math.round(y), b);
   }
   // escalado al dibujar (solo en la partida, para encoger la nave): en pixeles de pantalla
   function blitScaled(b, x, y, w, h) {
      g.smoothInterpolation = true;
      if (scaled) { g.resetTransformation(); g.drawScaledBitmap(x * kb, y * kb, (x + w) * kb, (y + h) * kb, b); g.scaleTransformation(kb, kb); }
      else g.drawScaledBitmap(x, y, x + w, y + h, b);
   }
   var HD = FV_BOOT_SHIP.HALO, HD2 = FV_BOOT_SHIP.HALO_END, hb = fvBootShipHalo(HD * kb), hb2 = fvBootShipHalo(HD2 * kb);
   function halo(x, y, al, big, base) {
      var b = big ? hb2 : hb, d = big ? HD2 : HD;
      if (!b || al <= 0.01) return;
      g.opacity = base * Math.min(1, al); blit(b, x - d / 2, y - d / 2); g.opacity = base;
   }
   // halo de tamaño libre (la partida): escalado al dibujar
   function haloAt(x, y, d, al) { if (!hb2 || al <= 0.01 || d < 1) return; var o = g.opacity; g.opacity = o * Math.min(1, al); blitScaled(hb2, x - d / 2, y - d / 2, d, d); g.opacity = o; }
   var s = L.s;
   function at(r) { return r ? [L.sx + r[0] * s, L.sy + r[1] * s, r[2]] : null; }
   // la nave en la posicion P: el fotograma i0 y, encima, el i1 con opacidad f (el fundido que hace fluido el giro)
   var sdw = Math.max(8, Math.round(L.sw * kb)), sdh = Math.max(8, Math.round(L.sh * kb));
   // Con fundido SourceOver, donde el de encima es transparente (el contorno) asoma el de debajo: un «fantasma» que desaparece de golpe al
   // cambiar de fotograma (medido: paso 2,4 veces mayor en los cruces). Por eso va DEBAJO el mas cercano (f < 0,5: i0; si no, i1) y
   // ENCIMA el otro con su peso: el fantasma pesa como mucho 0,5 y el cruce de fotograma queda continuo (Add exacto no sirve en
   // PixInsight: satura antes de la opacidad, CabraBase/pjsr/add-con-opacidad-satura-antes-de-la-opacidad.md)
   function shipAt(P) {
      if (m.opaque) {
         // (7-nov) JPG opaco sobre el color de la placa: el fundido SourceOver es exacto (no hay contorno transparente que deje asomar)
         var o0 = g.opacity, c0 = fvBootShipFrame(P.i0, sdw, sdh); if (c0) blit(c0, L.sx, L.sy);
         if (P.f > 0.004) { var c1 = fvBootShipFrame(P.i1, sdw, sdh); if (c1) { g.opacity = o0 * P.f; blit(c1, L.sx, L.sy); g.opacity = o0; } }
         return;
      }
      var near = (P.f < 0.5) ? P.i0 : P.i1, far = (P.f < 0.5) ? P.i1 : P.i0, w = (P.f < 0.5) ? P.f : 1 - P.f;
      var b0 = fvBootShipFrame(near, sdw, sdh); if (b0) blit(b0, L.sx, L.sy);
      if (w > 0.004) { var b1 = fvBootShipFrame(far, sdw, sdh); if (b1) { var o = g.opacity; g.opacity = o * w; blit(b1, L.sx, L.sy); g.opacity = o; } }
   }

   var shots = fvBootShotsOn(), BX = shots ? fvBootShotBox(L) : null, bdw = BX ? Math.max(8, Math.round(BX.w * kb)) : 0, bdh = BX ? Math.max(8, Math.round(BX.h * kb)) : 0;
   // el ancla de un plano fijo, en unidades de la cabina
   function anc(r) { var rs = m.shots.res; return r ? [BX.x + r[0] * BX.w / rs[0], BX.y + r[1] * BX.h / rs[1]] : null; }
   if (!dep) {
      fvBootShipChrome(g, L, B, SC, t, a, "back");
      // la nave: el fotograma que toca (con los planos fijos, parado desde POTENTIA)
      var PP = fvBootShipPosAt(fvBootShipAngle(t, B)), fi = PP.i0;
      if (shots) {
         var V = fvBootShotView(B, t), LS = m.shots.list, k2;
         // en la espera (antes de POTENTIA), un plano por pintada (un tropiezo de ~50 ms en un giro de 12 °/s no se ve): al tirar ya estan
         if (!B.started && t > 0.6) { var SS = FV_BOOT_SHIP_STORE; for (k2 in LS) if (SS.stillKey !== bdw + "x" + bdh || SS.still[k2] === undefined) { fvBootStill(k2, bdw, bdh); break; } }
         var drawKey = function(key, o) {
            if (!key || o <= 0.004) return;
            g.opacity = a * o;
            if (key === "tt") shipAt(PP); else { var bs = fvBootStill(key, bdw, bdh); if (bs) blit(bs, BX.x, BX.y); }
            g.opacity = a;
         };
         if (V.f < 1) drawKey(V.from, 1);
         drawKey(V.to, V.f);
         var isSys = function(k3) { return !!k3 && k3 !== "tt" && k3 !== "ok"; }, wB = (isSys(V.to) ? V.f : 0) + (isSys(V.from) && V.f < 1 ? 1 - V.f : 0);
         if (wB > 0.004) { var bb = fvBootShotBand(L, BX, kb, bdw, bdh); g.opacity = a * Math.min(1, wB); blit(bb, BX.x, BX.y); g.opacity = a; }
         fvBootShipChrome(g, L, B, SC, t, a, "title");
         // halo y flecha del sistema de cada plano (el que se va, con 1 − f; el que llega, con f)
         var arr2 = [], VV = [[V.from, V.f < 1 ? 1 - V.f : 0], [V.to, V.f]];
         for (i = 0; i < VV.length; ++i) {
            var kk = VV[i][0], wv = VV[i][1];
            if (!kk || wv <= 0.01) continue;
            if (kk === "ok") {
               // el final: los casquetes y los ojos de la cabra (el plano ya los trae encendidos; el halo es el de la partida, para que no salte)
               var RR = LS.ok.ready || [];
               for (var r2 = 0; r2 < RR.length; ++r2) { q = anc(RR[r2]); if (String(RR[r2][2]).indexOf("nac") === 0) { haloAt(q[0], q[1], HD2 * 1.1, wv); haloAt(q[0], q[1], HD2 * 0.5, wv); } else halo(q[0], q[1], wv * 0.8, false, a); }
               continue;
            }
            sc = SC[kk]; p = anc(LS[kk] && LS[kk].a);
            if (kk === "tt" || !sc || !p) continue;
            var warm2 = t < sc.k, hk = warm2 ? 0.55 + 0.4 * (0.5 + 0.5 * Math.sin((t - sc.w) * 6.5)) : 0.95 * fvBootClamp01(1 - (t - sc.k) / FV_BOOT_SHIP.OUT_S);
            halo(p[0], p[1], wv * hk, false, a);
            arr2.push([kk, p, wv]);
         }
         fvBootShipChrome(g, L, B, SC, t, a, "front");
         g.opacity = a;
         for (i = 0; i < arr2.length; ++i) { var A2 = arr2[i], so2 = L.slots[A2[0]]; fvBootArrow(g, so2.x + (so2.side ? -6 : 6), so2.y, A2[1][0], A2[1][1], so2.side, A2[2], false); }
         g.opacity = op;
         return;
      }
      g.opacity = a; shipAt(PP);
      fvBootShipChrome(g, L, B, SC, t, a, "title");
      // los halos (debajo de las flechas): el de cada sistema calentando y, al final, los de los casquetes y la cabra
      var arrows = [];
      for (i = 0; i < B.order.length; ++i) {
         id = B.order[i]; sc = SC[id]; p = at(m.anchors[id] ? fvBootShipLerp(m.anchors[id][PP.i0], m.anchors[id][PP.i1], PP.f) : null);
         if (!sc || !p || t < sc.w) continue;
         var warm = t < sc.k, fin = warm ? 1 : 1 - (t - sc.k) / FV_BOOT_SHIP.OUT_S;
         if (fin <= 0) continue;
         var fadeIn = fvBootClamp01((t - sc.w) / 0.15);
         if (p[2] > 0.01) halo(p[0], p[1], p[2] * fadeIn * (warm ? 0.55 + 0.4 * (0.5 + 0.5 * Math.sin((t - sc.w) * 6.5)) : 0.95 * fin), false, a);
         arrows.push([id, [p[0], p[1], p[2] >= 0.5], fadeIn * fin]);
      }
      var rdy = SC.ready, rk = (rdy !== Infinity && t >= rdy) ? fvBootClamp01((t - rdy) / 0.35) : 0;
      if (rk > 0) { var R = fvBootShipReadyAt(m, PP); for (i = 0; i < R.length; ++i) { q = at(R[i]); halo(q[0], q[1], q[2] * rk * (0.85 + 0.15 * Math.sin((t - rdy) * 5)), true, a); } }
      fvBootShipChrome(g, L, B, SC, t, a, "front");
      g.opacity = a;
      for (i = 0; i < arrows.length; ++i) { var A = arrows[i], so = L.slots[A[0]]; fvBootArrow(g, so.x + (so.side ? -6 : 6), so.y, A[1][0], A[1][1], so.side, A[2], !A[1][2]); }
      g.opacity = op;
      return;
   }

   // ---- LA PARTIDA ----
   // (7-nov) con los planos fijos: el plano final (que casa con d_000) se funde con la partida en XO s con la placa aun entera (si la placa
   // se fuera a la vez, la caja opaca del plano se veria como un rectangulo oscuro sobre la foto); despues la placa se va y gira a popa
   var shotsDep = shots && !!m.dep && !!B.shot && B.shot.okT !== undefined, XO = shotsDep ? 0.15 : 0;
   var pA = a * (1 - fvBootSmooth01((ud - XO) / (DP.TURN * 0.9 - XO)));          // la placa y los rotulos se van mientras gira a popa
   if (pA > 0.01) { fvBootShipChrome(g, L, B, SC, t, pA, "back"); if (!shotsDep) { fvBootShipChrome(g, L, B, SC, t, pA, "title"); fvBootShipChrome(g, L, B, SC, t, pA, "front"); } }
   g.opacity = a;
   var dw = Math.max(8, Math.round(L.sw * kb)), dh = Math.max(8, Math.round(L.sh * kb)), cx0 = L.sx + L.sw / 2, cy0 = L.sy + L.sh / 2, tx = W / 2, ty = H / 2;
   if (ud < DP.TURN) {
      // 1. GIRA A POPA: el giro rapido hasta el fotograma de popa por el camino corto (con la secuencia de Blender: el giro hasta su
      //    angulo de salida en la primera mitad y su secuencia en la segunda); los casquetes se encienden
      var u1 = ud / DP.TURN, a0 = fvBootShipAngle(d0) % 360, goal = !m.dep ? DP.STERN : (typeof m.dep.from_deg === "number" ? m.dep.from_deg : (typeof m.dep.from_frame === "number" ? m.dep.from_frame * 5 : DP.STERN));
      var uSpin = m.dep ? Math.min(1, u1 / 0.45) : u1, dlt = ((goal - a0) % 360 + 360) % 360; if (dlt > 180) dlt -= 360;
      var cap = null;
      if (shotsDep) {
         var uT = fvBootClamp01((ud - XO) / (DP.TURN - XO)), DFs = fvBootDepFrame(m, uT), bds = fvBootDepBitmap(DFs.i, dw, dh);
         if (bds) blit(bds, L.sx + DFs.ox * s, L.sy + DFs.oy * s);
         cap = DFs.caps;
         var ko = 1 - fvBootSmooth01(ud / XO);
         if (ko > 0.004) {
            var bok = fvBootStill("ok", bdw, bdh); if (bok) { g.opacity = a * ko; blit(bok, BX.x, BX.y); g.opacity = a; }
            var RO = m.shots.list.ok.ready || []; for (i = 0; i < RO.length; ++i) if (String(RO[i][2]).indexOf("nac") !== 0) { q = anc(RO[i]); halo(q[0], q[1], ko * 0.8, false, a); }
         }
         if (pA > 0.01) { fvBootShipChrome(g, L, B, SC, t, pA, "title"); fvBootShipChrome(g, L, B, SC, t, pA, "front"); g.opacity = a; }
      } else if (!m.dep || u1 < 0.45) {
         shipAt(fvBootShipPosAt(a0 + dlt * fvBootSmooth01(uSpin)));
         if (!m.dep && uSpin > 0.97) cap = fvBootDepFrame(m, 1).caps;
      } else {
         var DF = fvBootDepFrame(m, (u1 - 0.45) / 0.55), bd = fvBootDepBitmap(DF.i, dw, dh);
         if (bd) blit(bd, L.sx + DF.ox * s, L.sy + DF.oy * s);
         cap = DF.caps;
      }
      var ck = shotsDep ? 1 : fvBootSmooth01((u1 - 0.5) / 0.5);          // con el plano final los casquetes ya venian encendidos
      // (dos pasadas: el halo solo se leia apenas sobre el laton, captura pi_partida_popa del 6-nov)
      if (cap && ck > 0) for (i = 0; i < cap.length; ++i) { q = at(cap[i]); haloAt(q[0], q[1], HD2 * 1.1, ck); haloAt(q[0], q[1], HD2 * 0.5, ck); }
   } else if (ud < DP.TURN + DP.RECEDE) {
      // 2. SE ALEJA: la popa encoge con perspectiva (1 / (1 + SHRINK·e)) y va hacia el centro de la foto; estela calida de las gondolas
      var ur2 = (ud - DP.TURN) / DP.RECEDE;
      var DFr = fvBootDepFrame(m, 1), br = DFr.kind === "dep" ? fvBootDepBitmap(DFr.i, dw, dh) : fvBootShipFrame(DFr.i, dw, dh);
      var place = function(u) { var e = Math.pow(u, DP.EASE), k = 1 / (1 + DP.SHRINK * e), e2 = fvBootSmooth01(u); return { k: k, x: cx0 + (tx - cx0) * e2, y: cy0 + (ty - cy0) * e2 }; };
      // la estela: halos de los casquetes en las posiciones de hace un momento, cada vez mas tenues
      for (var tr = DP.TRAIL; tr >= 1; --tr) {
         var uu = ur2 - tr * DP.TRAIL_S / DP.RECEDE; if (uu < 0) continue;
         var P2 = place(uu);
         for (i = 0; i < DFr.caps.length; ++i) {
            var c0 = DFr.caps[i], qx = P2.x + (c0[0] * s - L.sw / 2) * P2.k, qy = P2.y + (c0[1] * s - L.sh / 2) * P2.k;
            haloAt(qx, qy, Math.max(8, HD2 * 0.7 * P2.k + 6), 0.45 * (1 - tr / (DP.TRAIL + 1)));
         }
      }
      var P1 = place(ur2), fadeShip = 1 - fvBootSmooth01((ur2 - 0.82) / 0.18);
      if (br) {
         var bw2 = (br.width / kb) * P1.k, bh2 = (br.height / kb) * P1.k, bx = P1.x + (DFr.ox * s - L.sw / 2) * P1.k, by = P1.y + (DFr.oy * s - L.sh / 2) * P1.k;
         g.opacity = a * fadeShip; blitScaled(br, bx, by, bw2, bh2); g.opacity = a;
      }
      for (i = 0; i < DFr.caps.length; ++i) {
         var c1 = DFr.caps[i]; haloAt(P1.x + (c1[0] * s - L.sw / 2) * P1.k, P1.y + (c1[1] * s - L.sh / 2) * P1.k, Math.max(10, HD2 * 1.1 * P1.k + 8), 1);
         haloAt(P1.x + (c1[0] * s - L.sw / 2) * P1.k, P1.y + (c1[1] * s - L.sh / 2) * P1.k, Math.max(6, HD2 * 0.5 * P1.k + 4), 1);
      }
   } else if (ud < DP.TURN + DP.RECEDE + DP.FLASH) {
      // 3. DESTELLO en el punto de fuga: halo que crece y se apaga y una cruz fina de luz
      var u3 = (ud - DP.TURN - DP.RECEDE) / DP.FLASH, fl = u3 < 0.3 ? u3 / 0.3 : 1 - (u3 - 0.3) / 0.7;
      haloAt(tx, ty, HD2 * (0.6 + 1.6 * u3), fl);
      var ln = 70 * (0.4 + u3) * fl;
      g.pen = new Pen(fvBootA(0.85 * fl, FV_BOOT_COL.ivory), 1); g.drawLine(tx - ln, ty, tx + ln, ty); g.drawLine(tx, ty - ln * 0.6, tx, ty + ln * 0.6);
   }
   // 4. (FADE) la opacidad a viene del dialogo (fvBootShipOverlayAlpha): la foto ya esta en su encuadre y se funde con la cabina
   g.opacity = op;
}
