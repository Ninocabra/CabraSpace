// ============================================================================
// FieldVoyager/src/ui/fv_hud_xp.js — EL PANEL DEL ESPECTRO XP DE LA FICHA, EN PIXINSIGHT (I12, 4-nov-2026)
// ----------------------------------------------------------------------------
// Un panel ADICIONAL de la ficha (no sustituye nada): el espectro BP/RP de Gaia DR3 de 330 a 1050 nm que se ANIMA como un analisis.
//   · una rendija (cursor) barre de izquierda a derecha en FV_XP_UI.SWEEP_S y va REVELANDO la curva sobre la tira de colores del espectro
//     (el color real de cada longitud de onda; apagada fuera del visible y en lo que aun no ha barrido);
//   · las marcas de lineas (Hβ 486, Hα 656, triplete del Ca II 850–866; la zona de TiO solo en estrellas frias, «esperada») se ENCIENDEN al
//     pasar la rendija; las que se MIDEN en el espectro (fv_sci_xp.js) quedan encendidas con su profundidad;
//   · un cuerpo negro de la temperatura de la ficha, tenue y a trazos, para comparar;
//   · al final la lectura «T ≈ … · tipo» se «resuelve» (las cifras giran y se fijan).
// Estetica de la ficha oscura grabada (E/S2): trazo fino oro/marfil, rotulos en versalitas, nada chillon.
// SOLO DIBUJA: el espectro compacto (60 puntos) y la curva del cuerpo negro llegan calculados (fvCardSciData, fuera del pintado; la curva del
// cuerpo negro se calcula una vez por ficha y se guarda en el propio objeto). Ningun proceso aqui.
// FV_XP_PANEL = false: la ficha sin el panel (el ROJO de fv_nI12_test).
// ES5.
// ============================================================================

var FV_XP_PANEL = true;
var FV_XP_UI = { SWEEP_S: 2.6, START_S: 0.9, RESOLVE_S: 0.5, H: 132, H_MORE: 26, H_MSG: 22 };

// ¿cuanto mide el panel en la ficha? (0 = no hay panel)
// (con MÁS abierto el panel se PLIEGA a una linea con la tira y la lectura: la ficha con los detalles no cabia en 930 px y tapaba la placa
// DATOS — nI12_pi_ngc2392_A_mas.png del 4-nov; el barrido ya se vio al abrir la ficha)
function fvXpPanelH(C, more) {
   if (!FV_XP_PANEL || !C || C.kind !== "star") return 0;
   if (C.xp) return more ? FV_XP_UI.H_MORE : FV_XP_UI.H;
   return (C.xpMsg) ? FV_XP_UI.H_MSG : 0;
}
function fvXpArgb(a, rgb) { return ((Math.max(0, Math.min(255, Math.round(a))) << 24) | (rgb & 0xffffff)) >>> 0; }
function fvXpRgbInt(v) { return ((v[0] << 16) | (v[1] << 8) | v[2]) >>> 0; }
// el color (ARGB) de la tira en λ: el del visible, o un pardo apagado fuera; `lit` 0–1 (lo barrido)
function fvXpStripCol(l, lit) {
   var c = fvsXpWaveRgb(l), k = 0.22 + 0.68 * lit;
   if (!c) { var d = Math.round(40 + 18 * lit); return (0xff000000 | (d << 16) | (Math.round(d * 0.82) << 8) | Math.round(d * 0.62)) >>> 0; }
   return (0xff000000 | (Math.round(c[0] * k) << 16) | (Math.round(c[1] * k) << 8) | Math.round(c[2] * k)) >>> 0;
}
// el panel en (x, y, w, h); t = segundos desde que empezo el barrido (< 0: aun no); C = contenido de la ficha (C.xp, C.xpBb, C.teff, C.spt…)
function fvXpPanelPaint(g, x, y, w, h, C, t, L) {
   var K = fvCardCols(), fT = cpFont("display", 10, false, false, 2), fM = cpFont("mono", 9), fL = cpFont("display", 9, false, false, 1), fI = cpFont("text", 10, false, true);
   // marco: filete de oro fino y uno tenue por dentro (como el de la ficha)
   g.pen = new Pen(0x90C99A3A, 0.8); g.drawRect(x + 0.5, y + 0.5, x + w - 0.5, y + h - 0.5);
   if (!C.xp) {
      // sin espectro: una linea discreta (o «consultando Gaia…» con un punto que respira)
      g.font = fI; g.pen = new Pen(K.sepia);
      var msg = C.xpMsg || "";
      if (C.xpBusy) { var a = 0.5 + 0.5 * Math.sin(t * 5); g.fillCircle(x + 10, y + h / 2, 2.2, new Brush(fvXpArgb(80 + 150 * a, 0xE5B53F))); g.drawText(x + 20, y + h / 2 + 4, cpElide(fI, msg, w - 28)); }
      else g.drawText(x + 10, y + h / 2 + 4, cpElide(fI, msg, w - 18));
      return;
   }
   if (h < 40) {
      // plegado (MÁS abierto): rotulo, la tira del espectro entera en pequeño y la lectura con las lineas medidas
      var Xc = C.xp, Tc = C.teff || Xc.fitT, seen = [];
      for (var si = 0; si < (Xc.lines || []).length; ++si) if (Xc.lines[si].v === 1) { var Dd = fvsXpLineDef(Xc.lines[si].k); if (Dd) seen.push(fvsXpT(L, "xp.seen", { l: Dd.label, d: fvNum(Xc.lines[si].d / 10, 0, L) })); }
      g.font = fT; g.pen = new Pen(K.sepia); var tw = fT.width(fvsXpT(L, "xp.title")); g.drawText(x + 8, y + h / 2 + 4, fvsXpT(L, "xp.title"));
      var s0 = x + 16 + tw, s1 = s0 + 90;
      for (var lq = 336; lq < 1020; lq += 8) g.fillRect(s0 + (lq - 336) / 684 * 90, y + h / 2 - 3, s0 + (lq + 8 - 336) / 684 * 90 + 0.6, y + h / 2 + 3, new Brush(fvXpStripCol(lq + 4, 1)));
      var rdC = ((C.teff && C.spt) ? fvsXpT(L, "xp.read", { t: fvXpFmtT(Tc, L), spt: C.spt }) : fvsXpT(L, "xp.readNoT", { t: fvXpFmtT(Xc.fitT, L) })) + (seen.length ? " · " + seen.join(" · ") : "");
      g.font = fM; g.pen = new Pen(0xffE6DCC6); g.drawText(s1 + 8, y + h / 2 + 4, cpElide(fM, rdC, x + w - s1 - 16));
      return;
   }
   var X = C.xp, V0 = FVS_XP.VIEW0, V1 = FVS_XP.VIEW1, xa = x + 6, xb = x + w - 6, top = y + 20, bot = y + h - 26, sy0 = bot + 2, sy1 = bot + 8;
   function PX(l) { return xa + (l - V0) / (V1 - V0) * (xb - xa); }
   // (la curva empieza por debajo de la banda de rotulos de las lineas: el pico tapaba «Hβ», nI12_web_A_100.png del 4-nov)
   function PY(v) { return bot - Math.max(0, Math.min(1.08, v / 1000)) * (bot - top - 22) / 1.08; }
   var u = fvClamp(t / FV_XP_UI.SWEEP_S, 0, 1), lc = V0 + (V1 - V0) * fvSmooth(u), going = (t >= 0 && u < 1);
   // rotulo
   g.font = fT; g.pen = new Pen(K.sepia); g.drawText(x + 8, y + 13, fvsXpT(L, "xp.title"));
   // la tira de colores (revelada hasta la rendija)
   for (var l = 336; l < 1020; l += 4) {
      var lit = (t < 0) ? 0 : (l <= lc ? 1 : 0);
      g.fillRect(PX(l), sy0, PX(l + 4) + 0.6, sy1, new Brush(fvXpStripCol(l + 2, lit)));
   }
   g.pen = new Pen(0x70C99A3A, 0.6); g.drawLine(xa, sy1 + 0.5, xb, sy1 + 0.5);
   // marcas del eje
   g.font = fM; g.pen = new Pen(0xa0BFA06A);
   for (var tk = 400; tk <= 1000; tk += 100) { var tx = PX(tk); g.drawLine(tx, sy1, tx, sy1 + 3); var lab = String(tk) + (tk === 1000 ? " nm" : ""); g.drawText(tx - fM.width(String(tk)) / 2, sy1 + 13, lab); }
   // zona de TiO (solo frias, «esperada»)
   if (fvsXpTioExpected(C.teff || X.fitT)) {
      var tx0 = PX(FVS_XP.TIO[0]), tx1 = PX(FVS_XP.TIO[1]), on = (t >= 0 && lc >= FVS_XP.TIO[0]);
      g.fillRect(tx0, top, tx1, bot, new Brush(on ? 0x14E5B53F : 0x08E5B53F));
      g.pen = new Pen(on ? 0x60C99A3A : 0x30C99A3A, 0.6); for (var hx = tx0; hx < tx1; hx += 5) g.drawLine(hx, bot, Math.min(tx1, hx + 6), bot - 6);
      g.font = fL; g.pen = new Pen(on ? 0xc0BFA06A : 0x50BFA06A); g.drawText(tx0 + 2, top + 9, fvsXpT(L, "xp.tio"));
   }
   if (t < 0) return;
   // la curva revelada: relleno tenue con los colores del espectro y el trazo de marfil
   var pts = [], j, lam, last = null;
   for (j = 0; j < X.n; ++j) { lam = fvsXpLam(X, j); if (lam > lc) break; pts.push([PX(lam), PY(X.f[j]), lam]); }
   if (j < X.n && j > 0) { var l0 = fvsXpLam(X, j - 1), l1 = fvsXpLam(X, j), q = (lc - l0) / (l1 - l0); last = [PX(lc), PY(X.f[j - 1] + (X.f[j] - X.f[j - 1]) * q), lc]; pts.push(last); }
   if (pts.length > 1) {
      var poly = [new Point(pts[0][0], bot)];
      for (j = 0; j < pts.length; ++j) poly.push(new Point(pts[j][0], pts[j][1]));
      poly.push(new Point(pts[pts.length - 1][0], bot));
      var stops = [];
      for (var sl = 340; sl <= 1040; sl += 20) { var cc = fvsXpWaveRgb(sl); stops.push([(sl - V0) / (V1 - V0), cc ? fvXpArgb(54, fvXpRgbInt(cc)) : 0x1C6E5A40]); }
      // (fillPolygon(pts, regla, brocha) da «signed integer expected» en 1.9.6: se rellena con drawPolygon y la brocha puesta)
      g.pen = new Pen(0x00000000, 0); g.brush = new LinearGradientBrush(new Point(xa, 0), new Point(xb, 0), stops);
      g.drawPolygon(poly);
      g.brush = new Brush(0x00000000);
      // BP por debajo de 400 nm es casi ruido en las frias: apagado (como CabraStars)
      var pa = [], pb = [];
      for (j = 0; j < pts.length; ++j) { var pp = new Point(pts[j][0], pts[j][1]); if (pts[j][2] <= 400) pa.push(pp); if (pts[j][2] >= 400) pb.push(pp); }
      if (pa.length > 1) { g.pen = new Pen(0x90D9CDB4, 1); g.drawPolyline(pa); }
      if (pb.length > 1) { g.pen = new Pen(0xffF4ECDC, 1.3); g.drawPolyline(pb); }
   }
   // el cuerpo negro de la temperatura de la ficha (a trazos, tenue), revelado con la rendija
   if (C.xpBb) {
      var bp = [];
      for (j = 0; j < X.n; ++j) { lam = fvsXpLam(X, j); if (lam > lc) break; bp.push(new Point(PX(lam), PY(C.xpBb[j]))); }
      if (bp.length > 1) { g.pen = new Pen(0x90E5B53F, 0.9, PenStyle_Dash); g.drawPolyline(bp); }
   }
   // las lineas: tick arriba, linea punteada fina, rotulo; se encienden al pasar
   for (var li = 0; li < FVS_XP.LINES.length; ++li) {
      var D = FVS_XP.LINES[li], meas = null;
      for (var mi = 0; mi < (X.lines || []).length; ++mi) if (X.lines[mi].k === D.k) meas = X.lines[mi];
      var passed = lc >= D.nm, age = passed ? (t - FV_XP_UI.SWEEP_S * fvXpUAt(D.nm)) : -1, seen = meas && meas.v === 1;
      var base = seen ? 235 : 130, a2 = !passed ? 55 : (age < 0.35 ? 255 : base), lx = PX(D.nm);
      g.pen = new Pen(fvXpArgb(a2, 0xE5B53F), passed && age < 0.35 ? 1.4 : 0.9);
      if (D.span) { var s0 = PX(D.span[0]), s1 = PX(D.span[1]); g.drawLine(s0, top + 2, s1, top + 2); g.drawLine(s0, top + 2, s0, top + 6); g.drawLine(s1, top + 2, s1, top + 6); g.drawLine(PX(864.2), top + 2, PX(864.2), top + 6); g.drawLine(PX(854.2), top + 2, PX(854.2), top + 6); }
      else g.drawLine(lx, top + 1, lx, top + 7);
      g.pen = new Pen(fvXpArgb(a2 * 0.35, 0xE5B53F), 0.6, PenStyle_Dot); g.drawLine(lx, top + 8, lx, bot);
      g.font = fL; g.pen = new Pen(fvXpArgb(a2, 0xF4ECDC));
      var lbl = (seen && passed) ? fvsXpT(L, "xp.seen", { l: D.label, d: fvNum(meas.d / 10, 0, L) }) : D.label, lw = fL.width(lbl);
      g.drawText(Math.min(xb - lw, Math.max(xa, lx - lw / 2)), top + 17, lbl);
   }
   // la rendija
   if (going) {
      var cx = PX(lc), cw0 = fvsXpWaveRgb(lc), tint = cw0 ? fvXpRgbInt(cw0) : 0xE5B53F;
      g.fillRect(cx - 7, top, cx + 7, sy1, new Brush(fvXpArgb(16, tint)));
      g.fillRect(cx - 2.5, top, cx + 2.5, sy1, new Brush(fvXpArgb(40, tint)));
      g.pen = new Pen(0xe0F3D27E, 1.1); g.drawLine(cx, top - 2, cx, sy1 + 1);
      g.pen = new Pen(0xe0F3D27E, 0.8); g.brush = new Brush(0xe0F3D27E); g.drawPolygon([new Point(cx - 3, top - 5), new Point(cx + 3, top - 5), new Point(cx, top - 1)]); g.brush = new Brush(0x00000000);
      var rd = fvsXpT(L, "xp.scan", { nm: String(Math.round(lc)) });
      g.font = fM; g.pen = new Pen(0xffE5B53F); g.drawText(x + w - 8 - fM.width(rd), y + 13, rd);
   } else if (u >= 1) {
      // la lectura que se resuelve
      var tr = t - FV_XP_UI.SWEEP_S, T = C.teff || X.fitT, rdS = (C.teff && C.spt) ? fvsXpT(L, "xp.read", { t: fvXpFmtT(T, L), spt: C.spt }) : fvsXpT(L, "xp.readNoT", { t: fvXpFmtT(X.fitT, L) });
      var shown = fvClamp(tr / FV_XP_UI.RESOLVE_S, 0, 1), txt = fvXpResolve(rdS, shown, t);
      var fR = cpFont("display", 11, false, false, 1);
      g.font = fR; g.pen = new Pen(fvXpArgb(110 + 145 * shown, 0xF4ECDC)); g.drawText(x + w - 8 - fR.width(rdS), y + 13, txt);
      // la leyenda del cuerpo negro, dentro de la grafica, arriba a la derecha (cuando ya esta todo)
      if (C.xpBb) { var lb = "- - " + fvsXpT(L, "xp.bb", { t: fvXpFmtT(C.teff || X.fitT, L) }); g.font = fI; var lbw = fI.width(lb); g.fillRect(xa + 2, bot - 15, xa + lbw + 10, bot - 2, new Brush(fvXpArgb(170 * shown, 0x0E0B08))); g.pen = new Pen(fvXpArgb(150 * shown, 0xE5B53F)); g.drawText(xa + 6, bot - 5, lb); }
   }
}
// en que fraccion del barrido pasa la rendija por λ (inversa de fvSmooth por biseccion; barato: 20 vueltas)
function fvXpUAt(l) {
   var target = (l - FVS_XP.VIEW0) / (FVS_XP.VIEW1 - FVS_XP.VIEW0), a = 0, b = 1;
   for (var k = 0; k < 20; ++k) { var m = 0.5 * (a + b); if (fvSmooth(m) < target) a = m; else b = m; }
   return 0.5 * (a + b);
}
function fvXpFmtT(T, L) { return (typeof fvsFmtTemp === "function") ? fvsFmtTemp(T, L) : Math.round(T) + " K"; }
// las cifras giran mientras shown < 1 (el reloj t decide el giro: el mismo fotograma, el mismo dibujo)
function fvXpResolve(s, shown, t) {
   if (shown >= 1) return s;
   var out = "", seed = Math.floor(t * 24);
   for (var i = 0; i < s.length; ++i) { var ch = s.charAt(i); out += (ch >= "0" && ch <= "9" && (i / s.length) > shown) ? String(Math.floor(fvHashF(i, seed) * 10)) : ch; }
   return out;
}
