// ============================================================================
// FieldVoyager/src/ui/fv_stf_panel.js — EL BOTON STF Y SU PANEL (encargo E2, 11-nov-2026)
// ----------------------------------------------------------------------------
// Un boton de laton mas en la columna DERECHA (la de la foto: foto, nombres, constelaciones, escala), entre ESCALA y COMPLETA. Va ahi y no a la
// izquierda porque cambia como se VE la foto, como sus vecinos; y la columna derecha tenia un hueco (5 frente a 6): la composicion no cambia.
// SOLO SE ENSEÑA cuando hay estirado (§11.10, detectar el contexto): foto lineal (estirado automatico) o con STF propio en PixInsight. Con una foto
// YA ESTIRADA y sin STF no aparece: ahi FieldVoyager no aplica ninguna curva, la foto es la que el usuario termino, y un mando de «estirado»
// solo serviria para estirarla dos veces (y rompería el «tal cual, bit a bit» de esas fotos). Si alguien quiere aclararla u oscurecerla, ese
// ajuste es de PixInsight, antes de abrir la nave.
// El panel es un Control propio pintado con la estetica Atlas del script (oro sobre tinta, como NAVIGATIO), NO un Menu nativo (no admite
// estilo: leccion de CabraPilot stf_popup.js). Lecciones de alli que se respetan:
//   · el numero se mueve EN VIVO; la foto sin estrellas (lo que se ve desde casa) se repinta rapido mientras se arrastra (cada FV_STF.LIVE s);
//     la RECONSTRUCCION (estrellas, objetos, capas) espera a soltar: temporizador de un disparo de FV_STF.SETTLE s, reiniciado con cada cambio;
//   · los deslizadores recorren solo su zona util (sombras −5…−1 σ, fondo 0,05…0,50);
//   · el texto largo va al tooltip (EN + ES); en el panel, rotulos cortos;
//   · la casilla «canales enlazados» ENSEÑA lo que da la regla (enlazado si la foto esta calibrada o es gris) y cambiarla manda.
// Un solo camino para cada cosa: sombras, fondo, enlazado y AUTO (volver a la regla; borra lo recordado de esta foto). Abrir el panel cierra
// NAVIGATIO, DATOS y las EMISORAS; abrir cualquiera de ellos lo cierra a el.
// ES5 salvo la clase de widget.
// ============================================================================

// las claves del boton (las de fvRbDefs: btn./tip./lab.) salen de las stf.* de src/ui/fv_text.js
(function() {
   if (typeof FV_TX === "undefined") return;
   var L = ["en", "es"];
   for (var i = 0; i < L.length; ++i) { var T = FV_TX[L[i]]; if (!T) continue; T["btn.stf"] = T["stf.btn"]; T["tip.stf"] = T["stf.tip"]; T["lab.stf"] = T["stf.lab"]; }
})();
var FV_STFUI = { W: 300 };
var FV_STF_HOOK = null;            // pruebas: function(kind, info) tras cada repintado rapido ("live") o reconstruccion ("commit")

// ¿hay estirado que ajustar? (el boton existe solo entonces)
function fvStfUiMode(D) {
   if (D.built && D.built.stf && D.built.stf.S) return D.built.stf.S.mode;
   if (D.stfPre) return D.stfPre.mode;
   return "none";
}
function fvStfUiAvailable(D) { return FV_STF.ON && fvStfUiMode(D) !== "none"; }

// el icono grabado: los ejes de un histograma con su pico de cielo a la izquierda y la curva de medios tonos que lo levanta (el estirado)
function fvStfEngrave(g, cx, cy, u, stroke, hair, dot) {
   function X(x) { return cx + x * u; }
   function Y(y) { return cy + y * u; }
   stroke(function(o) {
      g.drawLine(X(-14) + o, Y(-13) + o, X(-14) + o, Y(13) + o); g.drawLine(X(-14) + o, Y(13) + o, X(14) + o, Y(13) + o);
      var pts = [], m = 0.12;
      for (var k = 0; k <= 22; ++k) { var x = k / 22, y = fvStfMtf(m, x); pts.push(new Point(X(-14 + 28 * x) + o, Y(13 - 26 * y) + o)); }
      g.drawPolyline(pts);
   });
   hair(function() {
      var H = [0, 0.15, 0.9, 1.0, 0.55, 0.3, 0.18, 0.1, 0.06, 0.04, 0.02];
      for (var i = 0; i < H.length; ++i) { var x = -12 + 2.2 * i; g.drawLine(X(x), Y(13), X(x), Y(13 - 9 * H[i])); }
      g.drawLine(X(-14), Y(-13), X(14), Y(-13));
   });
   dot(-14 + 28 * 0.12, 13 - 26 * 0.5, 1.4);
}

// ---------------------------------------------------------------------------
// EL PANEL
// ---------------------------------------------------------------------------
class FVStfPanel extends Control {
   constructor(D) {
      super(D);
      var self = this;
      this.D = D; this.visibleFV = false; this.drag = null; this.hot = null; this.rects = {}; this.k = 1;
      this.p = null;                       // lo que enseñan los mandos { clip, bkg, linked } (de la regla o lo puesto)
      this.dirty = false; this.livePend = false;
      this.mouseTracking = true;
      this.cursor = new Cursor(StdCursor_PointingHand);
      this.timer = new Timer; this.timer.periodic = false; this.timer.interval = FV_STF.SETTLE;
      this.timer.onTimeout = function() { if (self.D.shut) return; if (self.drag) { self.timer.start(); return; } self.commit(); };
      this.liveTimer = new Timer; this.liveTimer.periodic = false; this.liveTimer.interval = FV_STF.LIVE;
      this.liveTimer.onTimeout = function() { if (self.D.shut) return; self.live(); };
      this.onPaint = function() {
         ++FV_PAINTING; if (typeof CSH_PAINTING === "number") ++CSH_PAINTING;
         var g = new Graphics(self);
         try { self.paintFV(g); } finally { g.end(); --FV_PAINTING; if (typeof CSH_PAINTING === "number") --CSH_PAINTING; }
      };
      this.onMousePress = function(x, y) { self.press(x, y); };
      this.onMouseMove = function(x, y, buttons) { self.moveFV(x, y, buttons); };
      this.onMouseRelease = function(x, y) { self.release(x, y); };
      this.onMouseWheel = function(x, y, delta) { self.wheelFV(x, y, delta); };
      this.hide();
   }
   // los valores que enseña el panel: lo aplicado (built.stf.applied)
   syncFromBuilt() {
      var B = this.D.built && this.D.built.stf;
      if (!B || !B.applied) { this.p = { clip: FV_STF.CLIP0, bkg: fvStfBkg0(), linked: true }; return; }
      this.p = { clip: fvClamp(B.applied.clip, FV_STF.CLIP_MIN, FV_STF.CLIP_MAX), bkg: fvClamp(B.applied.bkg, FV_STF.BKG_MIN, FV_STF.BKG_MAX), linked: !!B.applied.linked };
   }
   place() {
      var D = this.D, L = D.L; if (!L) return;
      var k = Math.max(1, L.b / 54); this.k = k;
      var w = Math.round(FV_STFUI.W * k), h = Math.round(196 * k), bt = D.rbtns && D.rbtns.stf;
      var x = (L.rx !== undefined ? L.rx : L.vx + L.pw) - w - Math.round(6 * k), y = bt ? Math.min(bt.position.y, L.vy + L.ph - h - 6) : L.vy + 8;
      x = Math.max(L.vx + 4, x); y = Math.max(L.vy + 4, y);
      if (this.width !== w || this.height !== h) this.setFixedSize(w, h);
      this.move(x, y);
   }
   open() {
      var D = this.D;
      if (!fvStfUiAvailable(D) || !D.built) return false;
      // un panel a la vez: se cierran NAVIGATIO, DATOS y las EMISORAS
      if (typeof FV_LABUI !== "undefined") FV_LABUI.open = false;
      if (D.ui) D.ui.legendOpen = false;
      if (D.radioOpen && typeof D.radioToggle === "function") D.radioToggle(false);
      this.syncFromBuilt(); this.place(); this.show(); this.bringToFront(); this.visibleFV = true;
      this.seen = { lab: false, leg: false, radio: false };
      this.update(); D.syncButtons();
      return true;
   }
   close() {
      if (!this.visibleFV) return;
      // lo que quedara pendiente de un arrastre se aplica (cerrar no pierde el ultimo cambio sin decir nada)
      var pend = this.dirty; this.timer.stop(); this.liveTimer.stop();
      this.hide(); this.visibleFV = false; this.drag = null;
      if (pend) this.commit();
      this.D.syncButtons();
   }
   // ---- el dibujo ----
   paintFV(g) {
      var D = this.D, C = FV_NMP, k = this.k, W = this.width, H = this.height, p = this.p || { clip: FV_STF.CLIP0, bkg: fvStfBkg0(), linked: true };
      var B = D.built && D.built.stf, S = B && B.S, mono = !!(S && S.nc === 1), user = !!(B && B.params), mode = S ? S.mode : "none";
      var fB = cpFont("display", Math.round(13 * k), false, false, 2), fS = cpFont("text", Math.round(11.5 * k)), fM = cpFont("mono", Math.round(10.5 * k));
      g.antialiasing = true; g.textAntialiasing = true;
      g.fillRect(0, 0, W, H, new Brush(fvNmArgb(C.INK, 0.94)));
      g.pen = new Pen(fvNmArgb(C.GOLD, 0.95), 1.2 * k); g.brush = new Brush(0x00000000); g.drawRect(0.6 * k, 0.6 * k, W - 0.6 * k, H - 0.6 * k);
      this.rects = {};
      var pad = 12 * k, y = 0;
      // cabecera: titulo y el aspa
      g.font = fB; g.pen = new Pen(fvNmArgb(C.GOLDL, 1)); g.drawText(pad, 21 * k, fvTx("stf.title"));
      var xs = W - 22 * k; g.pen = new Pen(fvNmArgb(this.hot === "close" ? C.TEXT : C.GOLD, 0.95), 1.3 * k);
      g.drawLine(xs, 9 * k, xs + 9 * k, 18 * k); g.drawLine(xs + 9 * k, 9 * k, xs, 18 * k);
      this.rects.close = [W - 30 * k, 2 * k, W - 2 * k, 28 * k];
      // de donde sale lo que se ve (una linea corta; el porque, en el tooltip)
      var st = user ? fvTx("stf.stUser") : fvTx(mode === "view" ? "stf.stView" : "stf.stAuto");
      g.font = fM; g.pen = new Pen(fvNmArgb(user ? C.GOLD : C.TEXT2, 0.95)); g.drawText(pad, 40 * k, st);
      this.rects.status = [0, 28 * k, W, 46 * k];
      y = 52 * k;
      var dim = (mode === "view" && !user);            // con el STF de la vista, los mandos muestran la regla automatica hasta que se tocan
      this.slider(g, "clip", y, fvTx("stf.shadows"), fvNum(p.clip, 2, FV_LANG) + " σ", (p.clip - FV_STF.CLIP_MIN) / (FV_STF.CLIP_MAX - FV_STF.CLIP_MIN), dim, fS, fM); y += 40 * k;
      this.slider(g, "bkg", y, fvTx("stf.bkg"), fvNum(p.bkg, 2, FV_LANG), (p.bkg - FV_STF.BKG_MIN) / (FV_STF.BKG_MAX - FV_STF.BKG_MIN), dim, fS, fM); y += 42 * k;
      // la casilla (gris: sin canales que enlazar)
      var bx = pad, by = y + 4 * k, bs = 11 * k, on = mono ? true : !!p.linked;
      g.pen = new Pen(fvNmArgb(mono ? C.TEXT2 : C.GOLD, mono ? 0.45 : 0.95), 1.2 * k); g.brush = new Brush(0x00000000); g.drawRect(bx, by, bx + bs, by + bs);
      if (on) g.fillRect(bx + 2.5 * k, by + 2.5 * k, bx + bs - 2.5 * k, by + bs - 2.5 * k, new Brush(fvNmArgb(mono ? C.TEXT2 : C.GOLD, mono ? 0.45 : 0.95)));
      g.font = fS; g.pen = new Pen(fvNmArgb(C.TEXT, mono ? 0.45 : (this.hot === "linked" ? 1 : 0.92))); g.drawText(bx + bs + 8 * k, by + bs - 1 * k, fvTx("stf.linked"));
      this.rects.linked = [0, y, W * 0.62, y + 22 * k];
      // AUTO: vuelve a la regla (apagado si ya es la regla)
      var aw = 70 * k, ax = W - pad - aw, ay = y - 1 * k, ah = 22 * k, aOn = user;
      g.pen = new Pen(fvNmArgb(C.GOLD, aOn ? 0.95 : 0.35), 1.2 * k); g.brush = new Brush(aOn && this.hot === "auto" ? fvNmArgb(C.GOLD, 0.25) : 0x00000000);
      g.drawRect(ax, ay, ax + aw, ay + ah);
      g.font = fB; var at = fvTx("stf.auto"); g.pen = new Pen(fvNmArgb(aOn ? C.GOLDL : C.TEXT2, aOn ? 1 : 0.45)); g.drawText(ax + (aw - fB.width(at)) / 2, ay + 16 * k, at);
      this.rects.auto = [ax, ay, ax + aw, ay + ah];
      // pie: las teclas del arrastre (corto)
      g.font = fM; g.pen = new Pen(fvNmArgb(C.TEXT2, 0.75)); g.drawText(pad, H - 10 * k, fvTx("stf.foot"));
   }
   slider(g, id, y, label, val, f, dim, fS, fM) {
      var C = FV_NMP, k = this.k, W = this.width, pad = 12 * k, x0 = pad + 4 * k, x1 = W - pad - 4 * k, ty = y + 26 * k, fr = fvClamp(f, 0, 1), hot = (this.hot === id || (this.drag && this.drag.id === id));
      g.font = fS; g.pen = new Pen(fvNmArgb(C.TEXT, 0.95)); g.drawText(pad, y + 12 * k, label);
      g.font = fM; g.pen = new Pen(fvNmArgb(dim ? C.TEXT2 : C.GOLDL, dim ? 0.7 : 1)); g.drawText(W - pad - fM.width(val), y + 12 * k, val);
      g.pen = new Pen(fvNmArgb(C.GOLD, 0.35), 2 * k); g.drawLine(x0, ty, x1, ty);
      g.pen = new Pen(fvNmArgb(C.GOLD, dim ? 0.5 : 0.95), 2 * k); g.drawLine(x0, ty, x0 + fr * (x1 - x0), ty);
      for (var i = 0; i <= 4; ++i) { var tx = x0 + i * (x1 - x0) / 4; g.pen = new Pen(fvNmArgb(C.GOLD, 0.4), 1 * k); g.drawLine(tx, ty + 4 * k, tx, ty + 7 * k); }
      var kx = x0 + fr * (x1 - x0);
      g.pen = new Pen(fvNmArgb(C.GOLDL, 1), 1.2 * k); g.brush = new Brush(fvNmArgb(hot ? C.GOLDL : C.GOLD, dim ? 0.6 : 1)); g.drawCircle(kx, ty, (hot ? 6.5 : 5.5) * k); g.fillCircle(kx, ty, (hot ? 5.5 : 4.5) * k, new Brush(fvNmArgb(hot ? C.GOLDL : C.GOLD, dim ? 0.6 : 1)));
      this.rects[id] = [0, y, W, y + 36 * k, x0, x1];
   }
   // ---- el raton ----
   hitFV(x, y) {
      var order = ["close", "clip", "bkg", "linked", "auto", "status"];
      for (var i = 0; i < order.length; ++i) { var r = this.rects[order[i]]; if (r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) return order[i]; }
      return null;
   }
   valueAt(id, x) {
      var r = this.rects[id], f = fvClamp((x - r[4]) / Math.max(1, r[5] - r[4]), 0, 1);
      if (id === "clip") return Math.round(100 * (FV_STF.CLIP_MIN + f * (FV_STF.CLIP_MAX - FV_STF.CLIP_MIN))) / 100;
      return Math.round(100 * (FV_STF.BKG_MIN + f * (FV_STF.BKG_MAX - FV_STF.BKG_MIN))) / 100;
   }
   press(x, y) {
      var h = this.hitFV(x, y), mono = !!(this.D.built && this.D.built.stf && this.D.built.stf.S && this.D.built.stf.S.nc === 1);
      if (h === "close") { this.close(); return; }
      if (h === "clip" || h === "bkg") { this.drag = { id: h }; this.set(h, this.valueAt(h, x)); return; }
      if (h === "linked" && !mono) { this.p.linked = !this.p.linked; this.dirty = true; this.update(); this.commit(); return; }
      if (h === "auto" && this.D.built && this.D.built.stf && this.D.built.stf.params) { this.auto(); return; }
   }
   moveFV(x, y, buttons) {   // (20-nov) se llamaba move() y chocaba con Control.move(x, y) nativo: errores rojos en consola al mover el raton
      if (this.drag && buttons) { this.set(this.drag.id, this.valueAt(this.drag.id, x)); return; }
      var h = this.hitFV(x, y);
      if (h !== this.hot) { this.hot = h; this.toolTip = h ? fvTipBoth("stf.tip." + h) : ""; this.update(); }
   }
   release() { if (this.drag) { this.drag = null; this.update(); if (this.dirty) { this.timer.stop(); this.timer.start(); } } }
   wheelFV(x, y, delta) {
      var h = this.hitFV(x, y); if (h !== "clip" && h !== "bkg") return;
      var st = (delta > 0 ? 1 : -1) * (h === "clip" ? 0.05 : 0.01);
      this.set(h, Math.round(100 * ((h === "clip" ? this.p.clip : this.p.bkg) + st)) / 100);
      this.timer.stop(); this.timer.start();
   }
   // un valor nuevo: el numero YA (gratis), la foto sin estrellas pronto (cada FV_STF.LIVE s) y la reconstruccion al parar (FV_STF.SETTLE s)
   set(id, v) {
      if (id === "clip") v = fvClamp(v, FV_STF.CLIP_MIN, FV_STF.CLIP_MAX); else v = fvClamp(v, FV_STF.BKG_MIN, FV_STF.BKG_MAX);
      if (this.p[id] === v && this.dirty) return;
      this.p[id] = v; this.dirty = true; this.update();
      if (!this.liveTimer.isRunning) { this.livePend = true; this.liveTimer.start(); } else this.livePend = true;
      this.timer.stop(); this.timer.start();
   }
   live() {
      if (!this.livePend || !this.dirty) return;
      this.livePend = false;
      fvStfUiLive(this.D, { clip: this.p.clip, bkg: this.p.bkg, linked: this.p.linked });
   }
   commit() {
      this.timer.stop(); this.liveTimer.stop(); this.livePend = false;
      if (!this.dirty) return;
      this.dirty = false;
      fvStfUiCommit(this.D, { clip: this.p.clip, bkg: this.p.bkg, linked: this.p.linked });
      this.update();
   }
   auto() {
      this.timer.stop(); this.liveTimer.stop(); this.dirty = false; this.livePend = false;
      fvStfUiCommit(this.D, (FV_STF.BREAK === "noauto") ? { clip: this.p.clip, bkg: this.p.bkg, linked: this.p.linked } : null);
      this.syncFromBuilt(); this.update();
   }
   stopFV() { try { this.timer.stop(); this.liveTimer.stop(); } catch (e) {} }
}

// ---------------------------------------------------------------------------
// EL DIALOGO: crear, pulsar, estado, repintado rapido y reconstruccion
// ---------------------------------------------------------------------------
function fvStfUiInit(D) {
   D.stfPanel = null;
   if (!FV_STF.ON) return;
   try { D.stfPanel = new FVStfPanel(D); } catch (e) { D.stfPanel = null; fvLog("stf panel: " + e); }
}
function fvStfUiToggle(D) {
   var pn = D.stfPanel; if (!pn || !D.P) return false;
   if (pn.visibleFV) pn.close(); else pn.open();
   return pn.visibleFV;
}
// cada tick (desde syncButtons): si se abrio otro panel, este se cierra
function fvStfUiWatch(D) {
   var pn = D.stfPanel; if (!pn || !pn.visibleFV) return;
   var lab = (typeof FV_LABUI !== "undefined" && FV_LABUI.open === true), leg = !!(D.ui && D.ui.legendOpen), rad = !!D.radioOpen;
   if (lab || leg || rad || (D.route && D.route.big) || !fvStfUiAvailable(D)) pn.close();
}
// la respuesta rapida: la foto sin estrellas nueva en el pintor (lo que se ve desde casa); el resto, al soltar
function fvStfUiLive(D, p) {
   if (!D.built || !D.painter) return null;
   var r = fvStfLive(D.built, p);
   if (!r) return null;
   D.painter.photoPlane = r.bmp;
   try { D.renderNow(); D.view.repaint(); } catch (e) {}
   if (typeof FV_STF_HOOK === "function") { try { FV_STF_HOOK("live", { ms: r.ms, p: p }); } catch (eH) {} }
   return r;
}
// la reconstruccion entera con la placa de progreso de siempre (la de REC y STELLAE: misma placa, mismo sitio); la camara, la seleccion, la
// ruta y el vuelo no se tocan. p = null: la regla (AUTO; borra lo recordado). -> el resultado de fvStfRebuild
function fvStfUiCommit(D, p) {
   if (!D.built || !D.built.stf || !D.built.stf.S || !D.built.stf.S.on) return null;
   var self = D, bg = null, VW = D.VW, VH = D.VH, t0 = Date.now(), r;
   try { bg = new Bitmap(D.frame); } catch (e0) { bg = null; }
   var prog = function(fr) {
      if (!bg) return true;
      self.ui.notice = { kind: "stfprog", title: fvTx("stf.busy"), lines: [], progress: fr };
      var g = new Graphics(self.frame), kn = fvHudK(VW);
      try { g.drawBitmap(0, 0, bg); if (Math.abs(kn - 1) > 1e-6) g.scaleTransformation(kn, kn); fvNoticePaint(g, self.painter, VW / kn, VH / kn, self.ui.notice); } finally { g.end(); }
      self.painter.hits = [];
      self.view.repaint();
      if (FV_PAINTING === 0) { try { CoreApplication.processEvents(); } catch (eP) {} }
      return self.closing !== true;
   };
   D.stfBusy = true;
   prog(0);
   try { r = fvStfRebuild(D.built, p, { onProgress: prog }); } catch (e) { r = { ok: false, why: String(e && e.message ? e.message : e) }; }
   D.ui.notice = null; D.stfBusy = false;
   if (!r || !r.ok) { fvLog("stf: rebuild FAILED " + (r ? r.why : "?")); if (D.P) D.ui.caption = { text: fvTx("stf.fail"), t0: D.P.t, dur: 3 }; try { D.painter.photoPlane = D.built.bmps.starless; D.renderNow(); D.view.repaint(); } catch (eR) {} return r; }
   // lo recordado: por imagen (AUTO lo borra)
   fvStfSave(D.built.stf.sig, p ? D.built.stf.params : null);
   fvStfUiReattach(D);
   r.msTotal = Date.now() - t0;
   fvLog("stf: applied (" + (p ? "manual" : "rule") + ") in " + r.msTotal + " ms");
   if (typeof FV_STF_HOOK === "function") { try { FV_STF_HOOK("commit", r); } catch (eH) {} }
   return r;
}
// el pintor y lo que deriva de la foto, con los bitmaps nuevos; lo demas (piloto, camara, seleccion, vuelo, ruta) igual
function fvStfUiReattach(D) {
   var b = D.built;
   D.painter = new FVPainter(D.scene, b.bmps);
   D.painter.mwOn = D.mwOn;
   if (typeof fvRbToPainter === "function") fvRbToPainter(D);
   D.nav.map2d = new FVNavMap2D(b.bmps.photo || b.bmps.starless);
   if (D.P && D.P.lab) D.P.lab.lumFor = null;                        // la luz de la foto para la mirada al contenido (fv_flightlab_ui.js)
   if (D.starLook !== "gaia") D.setStarLook(D.starLook, { noSave: true });
   try { D.renderNow(); D.view.repaint(); D.strip.repaint(); } catch (e) {}
}
