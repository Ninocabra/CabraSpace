// ============================================================================
// FieldVoyager/src/ui/fv_foreground.js — BLENDER 2: EL PRIMER PLANO FISICO (la ventana de la nave) delante de la foto (5-nov-2026)
// ----------------------------------------------------------------------------
// Nino: «mejorar la calidad de la experiencia visual», mejoras sutiles pero realistas; la foto MANDA (nunca la tapa ni la ensucia).
// La vista se enmarca con el ojo de buey de la nave renderizado en Blender (blender/primerplano.py -> blender/build_primerplano_rsc.py ->
// rsc/primerplano/): marco de laton en penumbra con su sombra suave sobre el cristal y un brillo levisimo de la lampara de cabina en
// la esquina de arriba a la izquierda (capa OVER, fija), la LUZ DE FUERA que recoge el labio del marco (capa RIM, aditiva: sube con el
// brillo de la escena —warp, destello, estrella brillante cerca del borde, foto en casa—) y, segun la variante:
//   a  ojo de buey (over + rim)
//   b  a + suciedad / micro-rayado del cristal junto al marco (capa DIRT, aditiva: SOLO se enciende cerca de una estrella muy brillante
//      o en el warp; en reposo, apagada)
//   c  a + escuadras de la estructura en las cuatro esquinas, en penumbra (over_g / rim_g)
// El marco renderizado SUSTITUYE al marco dibujado (fvFramePaint): con el primer plano encendido, stats.fg.frame = true y el pintor y el
// video no lo dibujan (dos marcos = redundancia).
// Nada en el centro: todo vive a < 50 unidades del borde (unidad = W / 1280 px, la del marco: fvHudK); medido en tests/fv_fg_test.js.
// Barato: los trozos se escalan UNA vez por tamaño (esquinas de 50 u; bordes de 45 u ESTIRADOS a lo largo; suciedad REPETIDA cada 250 u)
// y cada fotograma son ~40 drawBitmap de bitmaps pequeños (los de opacidad < 1/64 no se dibujan). Presupuesto ≤ 1 ms.
// La luz de la escena sale de lo que el pintor ya sabe (sin leer pixeles): las estrellas mas brillantes que dibuja paintStars (gancho
// fvFgTracker), el warp (P.trail), el destello (P.flash) y el brillo del borde de la foto (una vez por escena) por su peso en pantalla.
// FV_FG.ON = false: nada cambia (pixel identico; fv_fg_test F1). La variante elegida se recuerda (Settings "FieldVoyager/foreground").
// Video: el primer plano va en el video si la cabina va en el video (REC con cabina); con SOLO FOTO, no (FV_FG.REC_PHOTO_ONLY).
// Al paquete van solo los PNG (CPD): el usuario no necesita Blender. Todo propio y procedural.
// ============================================================================

var FV_FG = {
   ON: true,                   // BANDERA (encendida 5-nov tarde, decision de Nino): false = la ventana de hoy (marco dibujado), pixel identica
   DEFAULT: "a",               // la variante si el usuario no eligio ninguna (o la recordada ya no esta en CYCLE)
   VARIANTS: ["off", "a", "b", "c"],   // las que sabe pintar el codigo (pruebas); "b" y "off" no estan a la vista
   CYCLE: ["a", "c"],          // las que ofrece el clic de la placa DATOS (Nino, 5-nov: «A por defecto, C como opcion»)
   REC_PHOTO_ONLY: false,      // con REC «solo foto» (sin cabina) el primer plano tampoco va; true = va siempre que este encendido
   // LUZ DE FUERA en el labio (opacidad de la capa rim, 0..1): suelo + foto en casa + warp + destello + estrellas (gaussiana por distancia)
   RIM_BASE: 0.06, RIM_PHOTO: 0.45, RIM_WARP: 0.70, RIM_FLASH: 0.55, RIM_STAR: 0.95,
   // SUCIEDAD (opacidad de la capa dirt): solo estrellas y warp; en reposo 0
   DIRT_STAR: 1.0, DIRT_WARP: 0.30,
   STAR_LEV0: 11,              // nivel de estrella (fvLookLevel) desde el que cuenta como «luz»: DIM 8 + 3 (sigma ×2,3 del suelo saturado)
   STAR_R: 0.16,               // alcance de su luz sobre el marco: fraccion de la diagonal (gaussiana)
   STAR_N: 6,                  // cuantas fuentes se guardan por fotograma (las mas brillantes)
   CORNER_U: 50, EDGE_U: 250   // (del manifiesto; aqui por si falta)
};
var FV_FG_ROOT = (function() { try { return (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/").replace(/\/src\/ui\/?$/, ""); } catch (e) { return ""; } })();
var FV_FG_STORE = { man: null, tried: false, err: "", bmp: {}, sets: {}, setKeys: [], variant: null };
function fvFgLog(s) { try { if (typeof fvLog === "function") fvLog("[fg] " + s); } catch (e) {} }

// el manifiesto (una vez por sesion) -> true si hay recursos
function fvFgReady() {
   var S = FV_FG_STORE;
   if (!S.tried) {
      S.tried = true;
      try {
         var p = FV_FG_ROOT + "/rsc/primerplano/manifest.json";
         if (!File.exists(p)) throw new Error("missing " + p);
         S.man = JSON.parse(File.readTextFile(p));
         if (!S.man || !S.man.levels) throw new Error("bad manifest");
      } catch (e) { S.man = null; S.err = String(e); fvFgLog("window foreground not available, drawn frame instead: " + S.err); }
   }
   return !!S.man;
}
// la variante vigente (la recordada o la de por defecto)
function fvFgVariant() {
   var S = FV_FG_STORE;
   if (S.variant === null) {
      var v = FV_FG.DEFAULT;
      try { var r = Settings.read(CP_SETTINGS_PREFIX + "/foreground", DataType_String); if (r !== null && r !== undefined && FV_FG.CYCLE.indexOf(String(r)) >= 0) v = String(r); } catch (e) {}
      S.variant = v;
   }
   return S.variant;
}
function fvFgSetVariant(v) {
   if (FV_FG.VARIANTS.indexOf(v) < 0) return fvFgVariant();
   FV_FG_STORE.variant = v;
   try { if (typeof FV_REMEMBER === "undefined" || FV_REMEMBER) Settings.write(CP_SETTINGS_PREFIX + "/foreground", DataType_String, v); } catch (e) {}
   return v;
}
// la siguiente variante del ciclo (a -> c -> a; desde una fuera del ciclo, la primera) -> la puesta
function fvFgCycle() { var L = FV_FG.CYCLE, i = L.indexOf(fvFgVariant()); return fvFgSetVariant(L[(i + 1) % L.length]); }
// ¿se pinta? (bandera, recursos y variante)
function fvFgActive() { return !!FV_FG.ON && fvFgVariant() !== "off" && fvFgReady(); }
// ¿va en el video? (cab = REC con cabina)
function fvFgRecOn(cab) { return fvFgActive() && (!!cab || !!FV_FG.REC_PHOTO_ONLY); }
// rotulo de la opcion (EN/ES)
function fvFgLabel(v, lang) {
   var es = (lang || (typeof FV_LANG !== "undefined" ? FV_LANG : "en")) === "es";
   var T = es ? { off: "VENTANA: marco dibujado", a: "VENTANA: ojo de buey de laton", b: "VENTANA: laton y cristal con polvo", c: "VENTANA: laton y estructura" }
              : { off: "WINDOW: drawn frame", a: "WINDOW: brass porthole", b: "WINDOW: brass and dusty glass", c: "WINDOW: brass and hull ribs" };
   return T[v] || T.off;
}

// el parrafo de la placa DATOS (fv_hud.js, ultimo parrafo; clic = la siguiente variante). null con la bandera apagada (la placa de hoy)
function fvFgLegend(lang) {
   if (!FV_FG.ON || !fvFgReady()) return null;
   var es = (lang || (typeof FV_LANG !== "undefined" ? FV_LANG : "en")) === "es";
   return fvFgLabel(fvFgVariant(), lang) + (es ? " · clic para cambiar" : " · click to change");
}
// el nivel para una k: el de menor escala >= k (si ninguno llega, el mayor)
function fvFgLevel(k) {
   var lv = FV_FG_STORE.man.levels, best = null, top = null;
   for (var key in lv) {
      var s = lv[key].scale;
      if (top === null || s > lv[top].scale) top = key;
      if (s >= k - 1e-6 && (best === null || s < lv[best].scale)) best = key;
   }
   return best !== null ? best : top;
}
function fvFgBitmap(lv, piece, layer) {
   var S = FV_FG_STORE, id = lv + "/" + piece + "/" + layer;
   if (S.bmp[id] !== undefined) return S.bmp[id];
   var L = S.man.levels[lv], P = L.pieces[piece], m = P ? P.layers[layer] : null, b = null;
   if (m) { try { var p = FV_FG_ROOT + "/rsc/primerplano/" + L.dir + "/" + m.file; if (File.exists(p)) b = new Bitmap(p); else fvFgLog("missing " + p); } catch (e) { fvFgLog("cannot read " + id + ": " + e); } }
   S.bmp[id] = b;
   return b;
}
function fvFgScaled(b, w, h) {
   w = Math.max(1, Math.round(w)); h = Math.max(1, Math.round(h));
   return (w === b.width && h === b.height) ? b : b.scaledTo(w, h);
}

// ---------------------------------------------------------------------------
// EL JUEGO DE UN TAMAÑO: los trozos escalados y colocados (una vez por W × H × variante; se guardan los 3 ultimos: pantalla, video, prueba)
// -> { W, H, v, lv, over: [{ b, x, y }], rim: [{ b, x, y, cx, cy }], dirt: [{ b, x, y, cx, cy }] }
// ---------------------------------------------------------------------------
function fvFgSet(W, H, v) {
   var S = FV_FG_STORE, key = W + "x" + H + ":" + v;
   if (S.sets[key]) return S.sets[key];
   while (S.setKeys.length >= 3) delete S.sets[S.setKeys.shift()];
   var man = S.man, k = W / 1280, lv = fvFgLevel(k), sc = man.levels[lv].scale, f = k / sc;
   var CU = man.corner_u || FV_FG.CORNER_U, EU = man.edge_len_u || FV_FG.EDGE_U;
   var c = Math.round(CU * k), tl = Math.max(8, Math.round(EU * k)), set = { W: W, H: H, v: v, lv: lv, over: [], rim: [], dirt: [] };
   var G = (v === "c"), corners = [["c_tl", 0, 0], ["c_tr", W - c, 0], ["c_bl", 0, H - c], ["c_br", W - c, H - c]];
   function put(list, b, x, y, w, h) { if (b) list.push({ b: b, x: x, y: y, cx: x + w / 2, cy: y + h / 2 }); }
   var i, L;
   for (i = 0; i < 4; ++i) {
      var cp = corners[i], bo = fvFgBitmap(lv, cp[0], G ? "over_g" : "over"), br = fvFgBitmap(lv, cp[0], G ? "rim_g" : "rim");
      if (bo) put(set.over, fvFgScaled(bo, c, c), cp[1], cp[2], c, c);
      if (br) put(set.rim, fvFgScaled(br, c, c), cp[1], cp[2], c, c);
      if (v === "b") { var bd = fvFgBitmap(lv, cp[0], "dirt"); if (bd) put(set.dirt, fvFgScaled(bd, c, c), cp[1], cp[2], c, c); }
   }
   var edges = [["e_top", true], ["e_bottom", true], ["e_left", false], ["e_right", false]];
   for (i = 0; i < 4; ++i) {
      var e = edges[i], hz = e[1], span = (hz ? W : H) - 2 * c;
      if (span <= 0) continue;
      var lays = ["over", "rim"]; if (v === "b") lays.push("dirt");
      for (var j = 0; j < lays.length; ++j) {
         var lay = lays[j], b = fvFgBitmap(lv, e[0], lay);
         if (!b) continue;
         var dep = Math.max(1, Math.round((hz ? b.height : b.width) * f)), ml = man.levels[lv].pieces[e[0]].layers[lay], nr = Math.round(((ml && ml.near_px) || 0) * f);
         // la posicion de un tramo de largo n que empieza en o (a lo largo del borde); nr = distancia del recorte al borde de la pantalla
         var at = function(o, n) {
            if (hz) return [c + o, (e[0] === "e_top") ? nr : H - nr - dep, n, dep];
            return [(e[0] === "e_left") ? nr : W - nr - dep, c + o, dep, n];
         };
         if (lay === "over") { var so = fvFgScaled(b, hz ? span : dep, hz ? dep : span), p0 = at(0, span); put(set.over, so, p0[0], p0[1], p0[2], p0[3]); continue; }
         if (lay === "rim") {
            // estirada y partida en tramos de ~250 u: cada tramo recibe la luz de su sitio
            var sr = fvFgScaled(b, hz ? span : dep, hz ? dep : span), ns = Math.max(1, Math.round(span / tl));
            for (var q = 0; q < ns; ++q) {
               var o0 = Math.round(q * span / ns), o1 = Math.round((q + 1) * span / ns), pq = at(o0, o1 - o0);
               var sub = hz ? sr.subimage(o0, 0, o1, dep) : sr.subimage(0, o0, dep, o1);
               put(set.rim, sub, pq[0], pq[1], pq[2], pq[3]);
            }
            continue;
         }
         // dirt: repetida cada 250 u (el ultimo tramo, recortado)
         var td = fvFgScaled(b, hz ? tl : dep, hz ? dep : tl);
         for (var o = 0; o < span; o += tl) {
            var n = Math.min(tl, span - o), pd = at(o, n), bt = (n === tl) ? td : (hz ? td.subimage(0, 0, n, dep) : td.subimage(0, 0, dep, n));
            put(set.dirt, bt, pd[0], pd[1], pd[2], pd[3]);
         }
      }
   }
   S.sets[key] = set; S.setKeys.push(key);
   return set;
}

// ---------------------------------------------------------------------------
// LA LUZ DE LA ESCENA
// ---------------------------------------------------------------------------
// gancho de paintStars: antes del bucle (devuelve null si no hace falta: con la bandera apagada no se guarda nada)
function fvFgTracker(painter) {
   if (!fvFgActive()) { painter.fgT = null; return null; }
   var T = painter.fgT;
   if (!T) {
      T = painter.fgT = { lev0: FV_FG.STAR_LEV0, n: 0, x: new Float64Array(FV_FG.STAR_N), y: new Float64Array(FV_FG.STAR_N), I: new Float64Array(FV_FG.STAR_N) };
      T.add = function(sx, sy, lev, a) {
         var I = Math.min(1, (lev - this.lev0 + 1) / 6) * (a > 1 ? 1 : a), N = FV_FG.STAR_N, k;
         if (this.n < N) k = this.n++;
         else { k = 0; for (var j = 1; j < N; ++j) if (this.I[j] < this.I[k]) k = j; if (this.I[k] >= I) return; }
         this.x[k] = sx; this.y[k] = sy; this.I[k] = I;
      };
   }
   T.n = 0;
   return T;
}
// el brillo del borde de la foto (0..1), una vez por pintor: 4 × 48 muestras a un 4 % de cada lado de la foto sin estrellas
function fvFgPhotoEdgeLum(painter) {
   if (painter._fgPhotoLum !== undefined) return painter._fgPhotoLum;
   var b = painter.photoPlane, s = 0, n = 0;
   try {
      if (b) {
         var W = b.width, H = b.height, N = 48;
         for (var i = 0; i < N; ++i) {
            var t = (i + 0.5) / N, pts = [[t * W, 0.04 * H], [t * W, 0.96 * H], [0.04 * W, t * H], [0.96 * W, t * H]];
            for (var q = 0; q < 4; ++q) {
               var c = b.pixel(Math.floor(pts[q][0]), Math.floor(pts[q][1]));
               s += (0.2126 * ((c >>> 16) & 255) + 0.7152 * ((c >>> 8) & 255) + 0.0722 * (c & 255)) / 255; ++n;
            }
         }
      }
   } catch (e) { s = 0; n = 0; }
   painter._fgPhotoLum = n ? s / n : 0;
   return painter._fgPhotoLum;
}
// -> { rim, dirt (globales), L: [{ x, y, I }], R (alcance en px) }
function fvFgLights(painter, P, W, H) {
   var st = painter.stats, T = painter.fgT, tr = P.trail || 0, fl = P.flash || 0, wP = (st.wPhoto !== undefined) ? st.wPhoto : 0;
   var warp = fvSmooth((tr - 0.05) / 0.6);
   var out = { rim: FV_FG.RIM_BASE + FV_FG.RIM_PHOTO * fvFgPhotoEdgeLum(painter) * wP + FV_FG.RIM_WARP * warp + FV_FG.RIM_FLASH * fl,
               dirt: FV_FG.DIRT_WARP * warp, L: [], R: FV_FG.STAR_R * Math.sqrt(W * W + H * H) };
   if (T) for (var i = 0; i < T.n; ++i) out.L.push({ x: T.x[i], y: T.y[i], I: T.I[i] });
   return out;
}
function fvFgLocal(lt, x, y) {
   var s = 0, R2 = lt.R * lt.R;
   for (var i = 0; i < lt.L.length; ++i) { var l = lt.L[i], dx = l.x - x, dy = l.y - y; s += l.I * Math.exp(-(dx * dx + dy * dy) / R2); }
   return s;
}

// ---------------------------------------------------------------------------
// EL GANCHO DEL PINTOR (FVPainter.render, tras el viñeteado y antes del HUD)
// o.fg: true = pintalo (video), false = no; sin decir, solo en la pantalla con HUD (no en la nave pequeña del mapa grande)
// ---------------------------------------------------------------------------
function fvFgPaint(g, painter, P, W, H, o) {
   painter.stats.fg = null;
   if (!FV_FG.ON) return;
   var want = (o && o.fg !== undefined) ? !!o.fg : !(o && o.hud === false);
   if (!want || !fvFgActive()) return;
   var t0 = fvNowMs(), v = fvFgVariant(), set = fvFgSet(W, H, v), lt = fvFgLights(painter, P, W, H), nd = 0, i, it, a, op0 = g.opacity, cop = g.compositionOperator;
   var rimMax = 0, dirtMax = 0;
   try {
      g.compositionOperator = CompositionOp_SourceOver; g.opacity = 1;
      for (i = 0; i < set.over.length; ++i) { it = set.over[i]; g.drawBitmap(it.x, it.y, it.b); ++nd; }
      g.compositionOperator = CompositionOp_Add;
      var lays = [[set.rim, lt.rim, FV_FG.RIM_STAR], [set.dirt, lt.dirt, FV_FG.DIRT_STAR]];
      for (var q = 0; q < 2; ++q) {
         var list = lays[q][0], base = lays[q][1], kS = lays[q][2], last = -1;
         for (i = 0; i < list.length; ++i) {
            it = list[i]; a = base + kS * fvFgLocal(lt, it.cx, it.cy);
            a = Math.round(32 * Math.min(1, a)) / 32;
            if (q === 0) { if (a > rimMax) rimMax = a; } else if (a > dirtMax) dirtMax = a;
            if (a < 1 / 64) continue;
            if (a !== last) { g.opacity = a; last = a; }
            g.drawBitmap(it.x, it.y, it.b); ++nd;
         }
      }
   } finally { g.compositionOperator = cop; g.opacity = op0; }
   painter.stats.fg = { v: v, lv: set.lv, frame: true, draws: nd, rim: Math.min(1, lt.rim), rimMax: rimMax, dirtMax: dirtMax, lights: lt.L.length, ms: fvNowMs() - t0 };
}
