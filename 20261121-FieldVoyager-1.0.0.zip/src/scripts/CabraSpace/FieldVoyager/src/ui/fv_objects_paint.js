// ============================================================================
// FieldVoyager/src/ui/fv_objects_paint.js — EL PINTOR DE LOS OBJETOS COMPACTOS (pasada N, encargo C, N8; 4-nov-2026)
// ----------------------------------------------------------------------------
// Cada objeto con segmentacion (src/engine/fv_objects.js) trae en o._gfx sus CAPAS: Bitmap del recorte × peso de la capa (los pesos
// suman 1 por pixel). Aqui se dibujan en 3D a su distancia, en composicion Add (desde la Tierra suman exactamente el recorte), con la
// misma opacidad (1 − peso de la foto) con la que el pintor funde la foto sin estrellas con las capas de la nebulosa: en casa la vista
// sigue siendo la foto, sin doble objeto.
//   · planetaria, nebulosa, otro: capas que giran la MITAD que la camara (de lado quedan a 45°), con el nucleo en la del medio y la cascara
//     exterior en las de delante y detras (fv_objects.js fvObjShellWeights). ESTETICO: la foto solo da una cara. Desde la Tierra, exacta.
//   · galaxia: capas FIJAS perpendiculares a la visual desde la Tierra (disco fino): de canto se ve el canto (con un minimo de opacidad).
//   Las capas van separadas a lo largo de la visual desde la Tierra (fijas en el mundo): de lado se abren y hay paralaje al rodearla.
// Lo llama UNA linea de src/ui/fv_painter.js marcada «(N8) objetos», despues de las capas y antes de las estrellas.
// ES5.
// ============================================================================

var FV_OBJ_PAINT = { EDGE_MIN: 0.35, NEAR_K: 0.6, ON: true, HALF: true };   // HALF = false: de cara a la camara del todo (la segunda pasada; control)

// (build) los Bitmap del objeto a partir del recorte y los pesos -> o._gfx = { cutBmp, planes: [Bitmap], t: [K], w, h, x0, y0 } (no enumerable)
// photoRect (opcional) = { x0, y0, x1, y1 } en px de la FOTO a los que corresponde el recorte (el de resolucion completa); sin el, el de trabajo
function fvObjMakeGfx(o, seg, cut, shells, photoRect) {
   var w = seg.w, h = seg.h, planes = [];
   var cutBmp = new Bitmap(w, h, BitmapFormat.RGB32); new Uint32Array(cutBmp.pixelData()).set(cut);
   for (var k = 0; k < shells.K; ++k) {
      var b = new Bitmap(w, h, BitmapFormat.RGB32), q = new Uint32Array(b.pixelData()), wk = shells.w[k];
      for (var i = 0; i < q.length; ++i) {
         var p = cut[i], f = wk[i];
         q[i] = (f <= 0.002) ? 0xff000000 : ((0xff000000 | (Math.round(((p >>> 16) & 255) * f) << 16) | (Math.round(((p >>> 8) & 255) * f) << 8) | Math.round((p & 255) * f)) >>> 0);
      }
      planes.push(b);
   }
   var gfx = { cutBmp: cutBmp, planes: planes, t: shells.t, K: shells.K, w: w, h: h, x0: seg.x0, y0: seg.y0, photo: photoRect || null, seg: seg, cut: cut };   // seg y cut: para rehacer las capas (sondas)
   try { Object.defineProperty(o, "_gfx", { value: gfx, enumerable: false, writable: true, configurable: true }); } catch (e) { o._gfx = gfx; }
   return gfx;
}

// rotacion minima que lleva el vector unitario a al b (Rodrigues) -> function(v)
function fvObjRotFn(a, b) {
   var ax = fvCross(a, b), s = fvLen(ax), c = fvDot(a, b);
   if (s < 1e-9) {
      if (c > 0) return function(v) { return v; };
      var perp = fvNorm(Math.abs(a[0]) < 0.9 ? fvCross(a, [1, 0, 0]) : fvCross(a, [0, 1, 0]));
      return function(v) { return fvSub(fvMul(perp, 2 * fvDot(perp, v)), v); };
   }
   var k = fvMul(ax, 1 / s);
   return function(v) { return fvAdd(fvAdd(fvMul(v, c), fvMul(fvCross(k, v), s)), fvMul(k, fvDot(k, v) * (1 - c))); };
}

// el peso de la foto sin estrellas en este punto (el mismo calculo que FVPainter.paintLayers)
function fvObjPhotoWeight(painter, P) {
   var N = painter.scene.nebula;
   if (!painter.photoPlane || !N) return 0;
   return 1 - fvSmooth(fvLen(P.cam.pos) / (FV_PAINT.PHOTO_FADE * N.distLy));
}

function fvObjectsPaint(painter, g, pr, P) {
   var sc = painter.scene, O = sc.objects;
   painter.stats.objPlanes = 0;
   if (!FV_OBJ_PAINT.ON || !O || !O.length) return;
   var op0 = 1 - fvObjPhotoWeight(painter, P);
   painter.stats.objOp = op0;
   if (op0 < 0.01) return;
   var keep = g.compositionOperator;
   g.resetTransformation(); g.compositionOperator = CompositionOp_Add;
   for (var i = 0; i < O.length; ++i) {
      // (14-nov, encargo A «la caja») un objeto MAS ALLA de la boca de la caja (M 82: 12 millones de a.l.) se viaja a su sitio en la losa de la foto, a escala k
      // (fvObjBoxK, fv_objects.js: mismo rayo, mismo tamaño angular). Pintarlo igual que antes seria dejar la silueta del recorte en la losa (el agujero) y el objeto a
      // 12 millones de a.l.: desde la camara en la losa no casan (paralaje). Pintar el objeto a escala k desde la camara en pos es pintar el objeto SIN escalar
      // desde la camara en pos / k (la proyeccion no cambia con la escala): su geometria (capas, volumen) sale tal cual, sin tocarla
      var kb = (typeof fvObjBoxK === "function") ? fvObjBoxK(sc, O[i]) : 1, prI = pr, PI = P;
      if (kb < 1) {
         var cam2 = {}, kc, P2 = {};
         for (kc in P.cam) cam2[kc] = P.cam[kc];
         cam2.pos = [P.cam.pos[0] / kb, P.cam.pos[1] / kb, P.cam.pos[2] / kb];
         for (kc in P) P2[kc] = P[kc];
         P2.cam = cam2; prI = fvProjector(cam2, pr.W, pr.H); PI = P2;
      }
      if (O[i]._vol && typeof FV_VOLM !== "undefined" && FV_VOLM.ON && typeof fvVolPaintObject === "function") { fvVolPaintObject(painter, g, prI, PI, sc, O[i], op0); continue; }   // (V2) volumen por familias
      if (O[i]._gfx && O[i]._gfx.planes && O[i]._gfx.planes.length) fvObjPaintOne(painter, g, prI, PI, sc, O[i], op0);
   }
   g.resetTransformation(); g.opacity = 1; g.compositionOperator = keep;
}

// LA GEOMETRIA de las capas de un objeto vista desde camPos (la usan el pintor y el clic, H-2):
//   { c, u0, R, depth, fixed, nPl, rot, off: [4 esquinas rel. al centro, sin girar], X: [x0, x1], Y: [y0, y1] en px de la FOTO } | null
function fvObjFrame(sc, o, camPos) {
   var G = o._gfx, c = o.pos, dC = fvLen(c), toCam = fvSub(camPos, c), dCam = fvLen(toCam);
   if (!G || dC <= 0 || dCam <= 1e-12) return null;
   var u0 = fvMul(c, 1 / dC), R = Math.max(1e-9, o.radiusLy), depth = (FV_OBJ.DEPTH[o.type] || 0.5) * R, fixed = (o.type === "galaxy");
   // las cuatro esquinas del recorte vistas desde la Tierra, a la distancia del centro (px de trabajo -> px de la foto)
   var kk = (sc.field && o.workK) ? o.workK : 1, X = G.photo ? [G.photo.x0, G.photo.x1] : [G.x0 / kk, (G.x0 + G.w) / kk], Y = G.photo ? [G.photo.y0, G.photo.y1] : [G.y0 / kk, (G.y0 + G.h) / kk];
   var cornersPx = [[X[0], Y[0]], [X[1], Y[0]], [X[1], Y[1]], [X[0], Y[1]]], off = [];
   for (var j = 0; j < 4; ++j) off.push(fvSub(fvPixelPoint(sc, cornersPx[j][0], cornersPx[j][1], dC), c));
   // (4-nov, tercera pasada) las capas giran la MITAD que la camara (de −u0 hacia la bisectriz entre −u0 y la camara): de lado quedan a 45°,
   // se ven con escorzo y la separacion en profundidad se nota (de cara del todo, de lado se veia igual que de frente). Por detras (≥ ~170°),
   // de cara a la camara.
   var vC = fvMul(toCam, 1 / dCam), hv = fvAdd(fvMul(u0, -1), vC), nT = (fvLen(hv) > 0.2) ? fvNorm(hv) : vC;
   var rot = fixed ? function(v) { return v; } : fvObjRotFn(fvMul(u0, -1), FV_OBJ_PAINT.HALF ? nT : vC), nPl = fixed ? u0 : (FV_OBJ_PAINT.HALF ? nT : vC);
   return { c: c, u0: u0, R: R, depth: depth, fixed: fixed, nPl: nPl, rot: rot, off: off, X: X, Y: Y, toCam: toCam, dCam: dCam };
}

// (4-nov, revision de Codex H-2) el ALFA de la mascara bajo el punto de pantalla (mx, my), en la capa del medio del objeto -> 0..1, o null si no se
// puede calcular (sin mascara, rayo paralelo, fuera del recorte = 0)
function fvObjAlphaAt(sc, o, pr, mx, my) {
   var sg = o._seg, F = sg && sg.alpha ? fvObjFrame(sc, o, pr.pos) : null;
   if (!F) return null;
   var v = fvNorm([pr.fw[0] + ((mx - pr.cx) / pr.f) * pr.r[0] + ((my - pr.cy) / pr.f) * pr.d[0], pr.fw[1] + ((mx - pr.cx) / pr.f) * pr.r[1] + ((my - pr.cy) / pr.f) * pr.d[1], pr.fw[2] + ((mx - pr.cx) / pr.f) * pr.r[2] + ((my - pr.cy) / pr.f) * pr.d[2]]);
   var den = fvDot(v, F.nPl); if (Math.abs(den) < 1e-9) return null;
   var sHit = fvDot(fvSub(F.c, pr.pos), F.nPl) / den; if (!(sHit > 0)) return null;
   var Xw = fvSub(fvAdd(pr.pos, fvMul(v, sHit)), fvAdd(F.c, F.rot(F.off[0]))), e1 = fvSub(F.rot(F.off[1]), F.rot(F.off[0])), e2 = fvSub(F.rot(F.off[3]), F.rot(F.off[0]));
   var a11 = fvDot(e1, e1), a12 = fvDot(e1, e2), a22 = fvDot(e2, e2), b1 = fvDot(Xw, e1), b2 = fvDot(Xw, e2), det = a11 * a22 - a12 * a12;
   if (Math.abs(det) < 1e-30) return null;
   var ua = (b1 * a22 - b2 * a12) / det, ub = (a11 * b2 - a12 * b1) / det;
   if (ua < 0 || ub < 0 || ua > 1 || ub > 1) return 0;
   var kk = (sc.field && o.workK) ? o.workK : 1, wx = Math.floor((F.X[0] + ua * (F.X[1] - F.X[0])) * kk - sg.x0), wy = Math.floor((F.Y[0] + ub * (F.Y[1] - F.Y[0])) * kk - sg.y0);
   if (wx < 0 || wy < 0 || wx >= sg.w || wy >= sg.h) return 0;
   return sg.alpha[wy * sg.w + wx];
}

function fvObjPaintOne(painter, g, pr, P, sc, o, op0) {
   var F = fvObjFrame(sc, o, P.cam.pos);
   if (!F) return;
   var G = o._gfx, c = F.c, u0 = F.u0, R = F.R, depth = F.depth, fixed = F.fixed, rot = F.rot, nPl = F.nPl, off = F.off, toCam = F.toCam, dCam = F.dCam, cam = P.cam.pos, j;
   var dirZ = u0, spacing = Math.max(1e-9, 2 * depth / Math.max(1, G.K - 1), 0.15 * R);
   var edge = 1;
   if (fixed) { var ce = Math.abs(fvDot(fvMul(toCam, 1 / dCam), u0)); edge = Math.max(FV_OBJ_PAINT.EDGE_MIN, fvSmooth((ce - 0.05) / 0.4)); }
   var bw = G.w, bh = G.h;
   for (var k = 0; k < G.K; ++k) {
      var dz = G.t[k] * depth, pc = fvAdd(c, fvMul(dirZ, dz)), q = [], ok = true;
      // cerca de una capa, se desvanece (no hay pared borrosa delante de la camara)
      var dPl = Math.abs(fvDot(fvSub(cam, pc), nPl));
      var op = op0 * edge * fvSmooth(dPl / (FV_OBJ_PAINT.NEAR_K * spacing));
      if (op <= 0.01) continue;
      for (j = 0; j < 4; ++j) { var w3 = fvAdd(pc, rot(off[j])), p = pr.project(w3, 1e-6 * dCam + 1e-12); if (!p) { ok = false; break; } q.push([p[0], p[1]]); }
      if (!ok || painter.offscreen(q, pr.W, pr.H)) continue;
      var Hm = fvHomography([[0, 0], [bw, 0], [bw, bh], [0, bh]], q);
      if (!Hm) continue;
      if (Math.abs(Hm[6]) * bw + Math.abs(Hm[7]) * bh < 1e-3) Hm = [(q[1][0] - q[0][0]) / bw, (q[3][0] - q[0][0]) / bh, q[0][0], (q[1][1] - q[0][1]) / bw, (q[3][1] - q[0][1]) / bh, q[0][1], 0, 0, 1];
      g.opacity = Math.min(1, op);
      g.transformationMatrix = new Matrix(Hm[0], Hm[1], Hm[2], Hm[3], Hm[4], Hm[5], Hm[6], Hm[7], Hm[8]);
      g.drawBitmap(0, 0, G.planes[k]);
      g.resetTransformation();
      ++painter.stats.objPlanes;
   }
}
