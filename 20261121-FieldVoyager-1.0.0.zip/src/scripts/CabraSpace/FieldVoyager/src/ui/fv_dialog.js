// ============================================================================
// FieldVoyager/src/ui/fv_dialog.js — LA NAVE: la pantalla (la foto manda), la botonera a la izquierda y la franja de instrumentos
// (F1 3-nov; F2 4-nov; pasada N 4-nov-2026)
// ----------------------------------------------------------------------------
// F2: la nave se abre APAGADA (D10). new FVDialog(view, opts) enseña la foto en penumbra y la placa de encendido; al tirar de la
// palanca (clic o barra espaciadora) power() construye la escena paso a paso (fvBuildScene con onSystem) y cada paso enciende su
// lampara; durante las esperas de la red la interfaz se sigue atendiendo (CSH_NET_PUMP de CabraShared). new FVDialog(built) (las
// pruebas de F1) abre ya encendida.
// Un Timer mueve el reloj de escena, pinta el fotograma en un Bitmap (FVPainter) y pide repintar; los onPaint SOLO dibujan bitmaps
// (regla 4) y suben FV_PAINTING/CSH_PAINTING para que nadie bombee eventos dentro.
// PASADA N (lo que pidio Nino tras probarlo en su pantalla):
//   N7  opts.auto: la ventana se compone a partir de su tamaño (fvLayout, fv_nav.js) y se recompone al redimensionarla: la foto con su
//       aspecto lo mas grande posible, la botonera pegada a su izquierda y la franja pegada debajo con su ancho; todo proporcional.
//       El fotograma de la escena se pinta a como mucho FV_NAV.RMAX_PX pixeles (por encima se escala al pintarlo: fps). VW × VH es el
//       tamaño del FOTOGRAMA (el del piloto); viewW × viewH el del control. Sin opts.auto (las pruebas de antes): 1280 × 720 fijo.
//   N1  la franja trae TABULA (miniatura 2D con lo que mira la camara), PROFUNDITAS (mapa 3D) y MIRABILIA (lista de lo singular).
//   N2  todo lo de la franja se acciona y se nota: cursor de mano, realce y tooltip EN/ES por mando; REGULATOR se arrastra; la radio
//       de verdad (src/radio, un WebView en el hueco del dial: clic en la lampara = encender, girarlo = sintonizar; EMISORAS
//       la despliega).
//   N3  boton VISTA INICIAL arriba (vuelo suave a la Tierra); N4 fichas con × y Esc, y la ficha se oculta durante el viaje a ese
//       objeto y se vuelve a abrir al llegar; N9 el aspa cierra (onClose devolvia undefined = veto en PJSR; ahora true y para todo);
//   N11 la rueda y el raton pasan primero por fvPilotMouse de B; el teclado por fvPilotKey; N12 sin boton Exoplaneta: los planetas
//       van en MIRABILIA y el transito es un panel pequeño a un lado y se dibuja sobre la propia estrella.
// Raton en la pantalla: arrastrar = mirar · rueda = avanzar/retroceder (o lo que diga el piloto) · doble clic = vista inicial ·
// clic con Info activo = elegir el objeto bajo el cursor · clic en la placa DATOS / «MÁS» / × = desplegar / cerrar.
// Teclas (atajos de los botones, no caminos nuevos): espacio = encender / viajar · I · H (vista inicial) · T · M · R · G · y los de la
// columna derecha (5-nov, src/ui/fv_rightbar.js): P foto · N nombres · C constelaciones · E escala · F / F11 pantalla completa ·
// Esc (sale de pantalla completa; cierra ficha, aviso, transito o panel de la radio; nunca la nave). (5-nov) Sin «Orbitar» (O) ni «Mirar al Sol» (L).
// Clases de widget (V8 class): lo unico que no es ES5.
// ============================================================================

var FV_UI = { VW: 1280, VH: 720, STRIP_H: 160, BTN: 54, FPS: 60, TOUR_HOLD: { cine: 6.0, spectacular: 4.0 },
              CARD_REOPEN_S: 2.0 };          // (N4 + cine §10.5) la ficha se vuelve a abrir 2 s DESPUES de llegar: el plano de llegada respira

// (punto 6 de Nino) abrir el index.html exportado con el navegador del SISTEMA. FV_BROWSER_SIM = un Array en las pruebas: NO se abre nada de
// verdad, se apunta { path, exe, args } (el modo simulado; cshSystemBrowser con dry). Se le pasa la RUTA, como en fvOpenInBrowser: cada
// sistema la abre con el navegador por defecto. -> { ok, exe, args, why, sim }
var FV_BROWSER_SIM = null;
// (R4, 12-nov-2026) LA RADIO NO RESPIRA. R3 midio, con las teclas y la ficha cerrada, 89 envios de atenuacion en 25 s (3,6/s) y el volumen bajando hasta 0,40 (-8 dB) lejos de las
// estrellas: se oia como un volumen que «respira» o se apaga. Ahora: suelo del vacio 0,70 (-3 dB), el objetivo del vacio se filtra en el tiempo (paso bajo de VOID_TAU_S sobre
// log10 r: el salto al cambiar la «estrella mas proxima» ya no llega a la radio) y solo se envia a la radio si cambia mas de SEND_HYST (los extremos 0 y 1 siempre llegan).
var FV_DUCK = { VOID_FLOOR: 0.70, VOID_TAU_S: 2.0, SEND_HYST: 0.05 };
// (P14, 14-nov-2026) AVISO DE LA RADIO MUDA. En PixInsight el audio solo arranca con un gesto sobre el propio dial (R5, medido): un clic en la vista 3D no llega a la pagina de la radio.
// Al clicar FUERA del dial (vista 3D o franja, salvo la pestaña EMISORAS) con la radio encendida y muda, la lampara del dial respira x3 (la de R5) y su bisel brilla, y el rotulo de la
// franja dice «pulsa el dial» (el tooltip lo explica) SECONDS s; se quita solo al sonar. Como mucho MAX avisos por sesion y nunca solapados (un clic durante el aviso no lo reinicia).
// ON false = sin aviso (lo de antes: ROJO). REQUIRE_MUTE false = avisa tambien si la radio ya suena (ROJO: la prueba lo detecta).
var FV_RADIO_NUDGE = { ON: true, SECONDS: 4, MAX: 2, REQUIRE_MUTE: true };
// (R3-arreglos H7, 14-nov) el tope MAX es POR SESION de PixInsight, no por ventana de la nave: lo cuenta esta variable de modulo (no Settings), asi cerrar y reabrir la nave no da otros MAX avisos.
// Las pruebas la ponen a 0 para repetir casos.
var FV_RADIO_NUDGE_SESSION = { n: 0 };
function fvOpenIndexInBrowser(path) {
   if (typeof cshSystemBrowser !== "function") return { ok: false, why: "cshSystemBrowser not available (CabraShared/csh_web.js)", exe: "", args: [], sim: false };
   var sim = (FV_BROWSER_SIM instanceof Array), r = cshSystemBrowser(path, { dry: sim });
   r.sim = sim;
   if (sim) FV_BROWSER_SIM.push({ path: String(path), exe: r.exe, args: r.args.slice() });
   fvLog("open in the browser " + path + (sim ? " (simulated)" : "") + " with " + r.exe + " → " + (r.ok ? "ok" : "FAILED " + r.why));
   return r;
}

class FVDialog extends Dialog {
   constructor(arg, opts) {
      super();
      var self = this, o = opts || {};
      this.opts = o;
      this.auto = (o.auto === true);
      this.VW = o.VW || FV_UI.VW; this.VH = o.VH || FV_UI.VH;
      this.online = (o.online !== false);
      this.built = null; this.scene = null; this.P = null; this.painter = null;
      this.view0 = (arg && arg.scene) ? null : arg;
      this.infoOn = false; this.drag = null; this.frameMs = []; this.lastTick = 0; this.running = false; this.closing = false; this.shut = false;
      this.ui = { legendOpen: false, cardMore: false, caption: null, exo: null, exoList: [], cardClosed: false, hideCard: false, hover: null };
      this.phase = "off"; this.boot = fvBootNew(); this.bootT0 = fvNowMs(); this.bootFadeT0 = null; this.tour = null; this.pendingExo = null; this.nEngage = 0;
      this.style = "cine";
      // (F4b) REC, la cabina en el video y la Via Lactea simulada (recordados)
      this.rec = null; this.recBusy = null; this.recCab = (fvSetRead("recCockpit", "1") !== "0"); this.mwOn = (fvSetRead("milkyway", "1") !== "0");
      // (N2; punto 8 de Nino, 4-nov) la VELOCIDAD DEL VIAJE (cine y warp) que fija el REGULATOR (0…1; 0,5 = la de siempre). El campo se
      // sigue llamando warpPower (las pruebas lo leen); lo recordado ahora es «travelSpeed» (si no hay, la «warpPower» de antes)
      var spd0 = parseFloat(fvSetRead("travelSpeed", fvSetRead("warpPower", "0.5")));
      this.warpPower = fvClamp(isNaN(spd0) ? 0.5 : spd0, 0, 1);
      this.nav = { list: { items: [], base: [], top: 0, hover: null, sel: null, ready: false, search: fvSearchNew() }, map2d: null, map3d: null, trail: [] };      // (I3) search: el campo del buscador de MIRABILIA
      this.searchIdx = null;
      // (5-nov, Nino: «que las estrellas se vean como Gaia o como están en la imagen») el ASPECTO DE LAS ESTRELLAS recordado (STELLAE de la
      // cabina): "gaia" | "phcol" | "phstar"; la medida se hace al elegirlo o, si estaba recordado, al entrar la escena (attach). FV_PS.ON false: siempre "gaia"
      var lk0 = fvSetRead("starLook", "gaia"); this.starLook = (typeof FV_PS !== "undefined" && FV_PS.ON && fvPsIsLook(lk0)) ? lk0 : "gaia"; this.lookBusy = false;
      // (pasada M) ITINERARIUM: TABULA / PROFUNDITAS en grande, las camaras de la ruta y la fila de viaje de la ficha (src/ui/fv_route.js)
      this.route = (typeof FVRoute === "function") ? new FVRoute(this) : null;
      this.stripHover = null; this.regDrag = false; this.wasFlying = false; this.reopenCard = false; this.reopenAt = null; this.lookTo = null; this.duckSent = null;
      // (21-nov, N-galaxias-warp; FV_GWARP) sin selector el modo lo elige el destino: el estilo recordado de una sesion con MODUS se ignora (una opcion explicita de o.style, solo las pruebas, sigue valiendo)
      if (!fvGwarpUi()) { try { var st = Settings.read(CP_SETTINGS_PREFIX + "/style", DataType_String); if (st === "spectacular" || st === "cine") this.style = st; } catch (eS) {} }
      if (o.style) this.style = o.style;
      this.bootBg = null;
      if (typeof fvE1uInit === "function") fvE1uInit(this);          // (20-nov, I4) E1-01 QUAESTIO, E1-12 balanceo, E1-14 silencio: src/ui/fv_e1_ui.js
      // (E2, 11-nov) con estirado (foto lineal o con STF en PixInsight) la foto en penumbra del arranque sale ya estirada (antes, negra), y lo leido
      // se le pasa a fvBuildScene (o.stfPre: la foto lineal de trabajo no se lee dos veces). Ya estirada: lo de antes
      this.stfPre = null;
      if (this.view0 && typeof fvStfPrepare === "function") {
         try {
            var im0 = this.view0.image, W0 = im0.width, H0 = im0.height, rd0 = Math.max(1, Math.floor(Math.max(W0, H0) / FV_BUILD.WORK));
            var bw0 = (W0 >= H0) ? FV_BUILD.WORK : Math.round(FV_BUILD.WORK * W0 / H0), bh0 = (W0 >= H0) ? Math.round(FV_BUILD.WORK * H0 / W0) : FV_BUILD.WORK;
            this.stfPre = fvStfPrepare(this.view0, rd0, bw0, bh0);
            if (this.stfPre.on) this.bootBg = fvStfBitmap(fvStfStretchPx(this.stfPre.lin, fvStfRowsFor(this.stfPre, null).rows), bw0, bh0);
         } catch (eSt) { this.stfPre = null; fvLog("stretch: prepare failed " + eSt); }
      }
      if (this.view0 && !this.bootBg) { try { var img = this.view0.image, red = Math.max(1, Math.floor(Math.max(img.width, img.height) / 1600)); this.bootBg = img.render(red > 1 ? -red : 1, true, false); } catch (eB) { this.bootBg = null; } }
      // el aspecto de la foto (la pantalla de la nave tiene el suyo en modo auto)
      this.aspect = 16 / 9;
      if (arg && arg.scene && arg.scene.field) this.aspect = arg.scene.field.width / arg.scene.field.height;
      else if (this.view0) { try { this.aspect = this.view0.image.width / this.view0.image.height; } catch (eA) {} }
      this.windowTitle = "FieldVoyager";
      this.backgroundColor = 0xff110D09;
      // ---- la pantalla de la nave ----
      this.view = new Control(this);
      this.view.mouseTracking = true;
      this.view.onPaint = function() {
         ++FV_PAINTING; if (typeof CSH_PAINTING === "number") ++CSH_PAINTING;
         var g = new Graphics(self.view);
         try {
            // (pasada M) con TABULA o PROFUNDITAS en grande, la pantalla enseña el mapa (pintado en el reloj por fv_route.js)
            var fb = (self.route && self.route.big && self.route.frame) ? self.route.frame : self.frame;
            if (fb.width === self.view.width && fb.height === self.view.height) g.drawBitmap(0, 0, fb);
            else { g.smoothInterpolation = true; g.drawScaledBitmap(0, 0, self.view.width, self.view.height, fb); }
         } finally { g.end(); --FV_PAINTING; if (typeof CSH_PAINTING === "number") --CSH_PAINTING; }
      };
      // (pasada M) con el mapa en grande, el raton de la pantalla es del mapa (camaras de la ruta): fv_route.js, en pixeles del fotograma
      this.view.onMousePress = function(x, y, button, buttons) { if (self.recLocked()) return; self.radioNudge(); if (self.gal && typeof fvGalToggle === "function") { self.drag = null; if (typeof fvGalPress === "function") { var fg = self.toFrame(x, y); if (fvGalPress(self, fg[0], fg[1])) return; } fvGalToggle(self); return; } if (self.route && self.route.big) { var fr = self.toFrame(x, y); self.route.viewPress(fr[0], fr[1]); return; } var swayStopped = (typeof fvE1sCancel === "function") ? fvE1sCancel(self) : false; if (typeof fvE1qPress === "function" && fvE1qPress(self, x, y)) return;
         // (M, R3-H1) el primer clic durante el balanceo de paralaje SOLO lo para: el fotograma que veia Nino iba desplazado y estrechado (P.cam solo se mueve dentro del pintado) y fvPick buscaba con la camara de casa
         // (461 px de desfase en la prueba de Gemini): elegia otra cosa. Sin arrastre ni clic; el segundo clic ya elige con la camara que se ve
         if (swayStopped) { self.drag = null; return; }
         self.drag = { x: x, y: y, x0: x, y0: y, moved: false }; };
      this.view.onMouseMove = function(x, y, buttons) { if (self.recLocked()) return; if (typeof fvE1qMove === "function" && fvE1qMove(self, x, y, buttons)) return; if (self.gal && typeof fvGalMove === "function") { var fg = self.toFrame(x, y); if (fvGalMove(self, fg[0], fg[1], buttons)) return; } if (self.route && self.route.big) { var fm = self.toFrame(x, y); self.route.viewMove(fm[0], fm[1], buttons); return; } self.viewMove(x, y, buttons); };
      this.view.onMouseRelease = function(x, y, button) {
         if (self.recLocked()) { self.recLockedClick(x, y); return; }          // (nA2, E7) solo vive el boton CANCELAR del aviso
         if (self.gal && typeof fvGalRelease === "function") { var fg = self.toFrame(x, y); if (fvGalRelease(self, fg[0], fg[1])) { self.drag = null; return; } }   // (ronda 2b) girar la galaxia
         if (self.route && self.route.big) { var fq = self.toFrame(x, y); self.route.viewRelease(fq[0], fq[1]); self.drag = null; return; }
         if (typeof fvE1qRelease === "function" && fvE1qRelease(self)) return;
         var d = self.drag; self.drag = null;
         // (N10) al soltar, el piloto de B deja la mirada planeando (fvPilotMouse con buttons = 0)
         // (B, 4-nov) SIEMPRE al soltar, se haya movido o no: si no, un arrastre que el piloto ya habia empezado quedaba con el boton «pulsado»
         if (self.P && typeof fvPilotMouse === "function") { try { fvPilotMouse(self.P, 0, 0, 0); } catch (eR) {} }
         // (I5) el clic (elegir) solo con el boton izquierdo: el derecho es el pan
         if (d && !d.moved && (button === undefined || button === MouseButton_Left || !(FV_PILOT.FREE.GAIA_MOUSE === true))) { var f = self.toFrame(x, y); self.click(f[0], f[1]); }
      };
      this.view.onMouseWheel = function(x, y, delta, buttons) { if (self.recLocked()) return; if (self.route && self.route.big) return; self.wheel(delta, buttons); };
      // (I5) doble clic sobre una estrella u objeto = viajar alli (como VIAJAR); en el vacio, nada. GAIA_MOUSE false = ROJO (a casa, lo de antes)
      this.view.onMouseDoubleClick = function(x, y) { if (self.recLocked()) return; if (self.route && self.route.big) return; if (FV_PILOT.FREE.GAIA_MOUSE === true && x !== undefined) { var fd = self.toFrame(x, y); self.doubleClick(fd[0], fd[1]); return; } self.goHome(); };
      this.view.onLeave = function() { if (self.ui.hover) { self.ui.hover = null; } };
      this.view.cursor = new Cursor(StdCursor_Cross);
      this.view.onKeyPress = function(key, mod) { return self.keyDown(key, mod); };
      this.view.onKeyRelease = function(key, mod) { return self.keyUp(key, mod); };
      this.onKeyPress = function(key, mod) { return self.keyDown(key, mod); };
      this.onKeyRelease = function(key, mod) { return self.keyUp(key, mod); };
      // (B, 4-nov: «tecla pegada») si la tecla se suelta con el foco en otro sitio (radio, un boton, otra ventana) la suelta no llega: al perder el
      // foco la vista o el dialogo, se sueltan todas las del vuelo libre
      this.view.onLoseFocus = function() { self.releaseKeys("view focus"); };
      this.onLoseFocus = function() { self.releaseKeys("dialog focus"); };
      // ---- la franja de instrumentos ----
      this.strip = new Control(this);
      this.strip.mouseTracking = true;
      this.strip.onPaint = function() {
         ++FV_PAINTING; if (typeof CSH_PAINTING === "number") ++CSH_PAINTING;
         var g = new Graphics(self.strip);
         try { self.cockpit.paint(g, self.gauges()); self.cockpit.paintNav(g, self.navState()); if (self.route) self.route.paintStrip(g); }
         finally { g.end(); --FV_PAINTING; if (typeof CSH_PAINTING === "number") --CSH_PAINTING; }
      };
      this.strip.onMousePress = function(x, y) { self.stripPress(x, y); };
      this.strip.onMouseMove = function(x, y, buttons) { self.stripMove(x, y, buttons); };
      this.strip.onMouseRelease = function(x, y) { if (self.padHold) { self.padRelease(); self.strip.repaint(); return; }                // (5-nov) la cruceta
                                                   if (self.cockpit && self.cockpit.aetasRelease && self.cockpit.aetasRelease()) { self.strip.repaint(); return; }   // (I4) AETAS
                                                   if (self.regDrag) { self.regDrag = false; fvSetWrite("travelSpeed", self.warpPower.toFixed(2)); self.strip.repaint(); } };
      this.strip.onMouseDoubleClick = function(x, y) { self.stripDouble(x, y); };
      this.strip.onMouseWheel = function(x, y, delta) { self.stripWheel(x, y, delta); };
      this.strip.onLeave = function() { self.setStripHover(null); };
      // ---- la botonera ----
      this.btns = {}; this.btnList = [];
      for (var i = 0; i < FV_BTN.length; ++i) { var b = new FVBrassButton(this, FV_BTN[i], FV_UI.BTN, function(id) { self.button(id); }, Math.round(FV_UI.BTN * (1 + FV_NAV.LABEL_K))); this.btns[FV_BTN[i].id] = b; this.btnList.push(b); }
      // (5-nov) la columna derecha (src/ui/fv_rightbar.js; FV_RB.ON false = sin ella)
      this.rbtns = {}; this.rbtnList = [];
      if (typeof fvRbInit === "function") fvRbInit(this);
      if (typeof fvStfUiInit === "function") fvStfUiInit(this);             // (E2, 11-nov) el panel del estirado (src/ui/fv_stf_panel.js)
      // ---- la composicion (N7) ----
      this.frame = null; this.cockpit = null; this.L = null; this.inLayout = false;
      if (this.auto) {
         try { this.userResizable = true; } catch (eU) {}
         var sr = null; try { sr = this.availableScreenRect; } catch (eR) {}
         var aw = (o.winW || 0) || Math.round((sr ? sr.width : 1600) * 0.92), ah = (o.winH || 0) || Math.round((sr ? sr.height : 1000) * 0.90);
         if (sr && sr.width > 0) { aw = Math.min(aw, sr.width); ah = Math.min(ah, sr.height); }
         this.setMinSize(760, 480);
         this.applyLayout(this.layoutFor(aw, ah));
         this.resize(aw, ah);
         this.onResize = function(w, h) { if (!self.inLayout && !self.shut) self.relayout(w, h); };
      } else {
         this.applyLayout(this.fixedLayout());
         this.setFixedSize(this.L.W + 16, this.L.H + 16);
      }
      // ---- la radio (N2): el WebView de src/radio en el hueco del dial de la franja ----
      this.radio = null; this.radioErr = ""; this.radioOpen = false;
      if ((o.radio === true || (o.radio !== false && this.auto)) && typeof FVRadio === "function") {
         try {
            // (R5, 12-nov) al abrir: encendida y sintonizada (de fabrica S2; lo que el usuario dejo guardado manda); suena con el primer gesto en el dial. o.radioAutostart false = la de antes (pruebas)
            this.radio = new FVRadio(this, { lang: FV_LANG, log: function(s) { fvLog(s); }, minWidth: 40, minHeight: 40, mute: o.radioMute === true, autostart: o.radioAutostart !== false, holdStart: (typeof FV_M1 !== "undefined" && FV_M1.ON === true && o.radioHold !== false) });   // (M1) holdStart: se enciende al tirar de POTENTIA, no al abrir
            this.radio.onReady = function() { self.radio.query("__fvr.setCompact(true)"); self.placeRadio(); };
            this.radio.onStationTuned = function() { self.strip.repaint(); };
            this.radio.onStationLost = function() { self.strip.repaint(); };
            this.radio.onPower = function() { self.strip.repaint(); };
            this.radio.onClosePanel = function() { if (self.radioOpen) self.radioToggle(false); };      // (5-nov) el aspa del panel EMISORAS
            this.radio.onArmChange = function() { self.strip.repaint(); };                              // (R3-arreglos H2) el audio dejo de sonar / volvio
            this.radio.onNudgeCancel = function() { if (self.nudge) self.nudge.until = 0; self.strip.repaint(); };      // (R3-arreglos H6) el aviso ya no procede en la pagina: tampoco en la franja
            if (this.radio.failed) this.radioErr = this.radio.failed;
            this.placeRadio();
         } catch (eRd) { this.radio = null; this.radioErr = String(eRd); fvLog("radio not available: " + this.radioErr); }
      }
      // ---- el reloj y el cierre (N9) ----
      this.timer = new Timer; this.timer.interval = 1 / FV_UI.FPS; this.timer.periodic = true;
      this.timer.onTimeout = function() { if (!self.shut) self.tick(); };
      this.onShow = function() { if (!self.shut) self.start(); };
      this.onHide = function() { self.stop(); };
      // (N9) el aspa: en PJSR un onClose que no devuelve nada es un VETO (medido en Cabra3D, 15-oct: «no se cerraba»). Devuelve true
      // y antes lo para todo: el reloj, la radio (WebView y su temporizador), la grabacion y el encendido en curso.
      this.onClose = function() { return self.closeRequest(); };
      if (arg && arg.scene) { this.attach(arg); for (var id in this.boot.sys) this.boot.sys[id].st = "ok"; this.boot.started = true; this.boot.done = true; if (this.radio && typeof this.radio.startNow === "function") this.radio.startNow(); }   // (M1) sin POTENTIA (escena ya dada): la radio no se queda retenida
      this.renderNow();
      this.syncButtons();
   }
   // ---------------------------------------------------------------------------
   // N7 · LA COMPOSICION
   // ---------------------------------------------------------------------------
   fixedLayout() {
      var b = FV_UI.BTN, bh = Math.round(b * (1 + FV_NAV.LABEL_K)), sh = Math.round(this.VW * FV_NAV.GRID_H / FV_NAV.GRID_W), colW = Math.round(b * 1.34);
      var L = { pw: this.VW, ph: this.VH, sh: sh, b: b, bh: bh, gap: 9, colW: colW, x0: 8, y0: 8, vx: 8 + colW, vy: 8, sx: 8 + colW, sy: 8 + this.VH,
               W: colW + this.VW, H: this.VH + sh, aspect: this.VW / this.VH, k: this.VW / 1280, kc: this.VW / FV_NAV.GRID_W };
      return (typeof fvRbFixed === "function") ? fvRbFixed(this, L) : L;          // (5-nov) la columna derecha
   }
   // (5-nov) la composicion con la columna derecha (y la de pantalla completa): src/ui/fv_rightbar.js; sin ella, la de siempre
   layoutFor(w, h) { return (typeof fvLayoutRB === "function") ? fvLayoutRB(this, w, h) : fvLayout(w, h, this.aspect, this.btnList.length); }
   relayout(w, h) { this.applyLayout(this.layoutFor(w, h)); }
   applyLayout(L) {
      this.inLayout = true;
      try {
         this.L = L; this.viewW = L.pw; this.viewH = L.ph; this.stripH = L.sh;
         var fs = this.auto ? fvFrameSize(L.pw, L.ph) : { w: L.pw, h: L.ph, s: 1 };
         if (!this.frame || this.frame.width !== fs.w || this.frame.height !== fs.h) {
            this.frame = new Bitmap(fs.w, fs.h, BitmapFormat.RGB32);
            this.VW = fs.w; this.VH = fs.h;
            if (this.P) fvPilotResize(this.P, this.VW, this.VH);
            // (11-nov, hallazgo del encargo NV-13) con la navegacion v5, fvPilotResize rehace el campo de casa SIN el estirado S: la foto de casa
            // salia ampliada ×55 (1 estrella en pantalla en vez de 2 545, medido en tests/_nav11/nav_default_probe.js) y no se recuperaba
            if (this.P && this.P.lab && typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabSetS === "function") fvLabSetS(this.P, FV_LAB.S_MODE);
            if (this.painter) this.painter.cardKey = "";
         }
         this.view.setFixedSize(L.pw, L.ph); this.view.move(L.vx, L.vy);
         var sw = L.sw || L.pw;                                          // (H-2) la franja puede ser mas ancha que una foto vertical
         this.strip.setFixedSize(sw, L.sh); this.strip.move(L.sx, L.sy);
         if (!this.cockpit || this.cockpit.W !== sw || this.cockpit.H !== L.sh) this.cockpit = new FVCockpit(sw, L.sh, this.aspect);
         var bx = L.x0 + Math.round((L.colW - L.b) / 2), by = L.vy + Math.round(L.gap / 2);
         for (var i = 0; i < this.btnList.length; ++i) { var b = this.btnList[i]; b.setSizeFV(L.b, L.bh); b.move(bx, by + i * (L.bh + L.gap)); }
         if (typeof fvRbPlace === "function") fvRbPlace(this, L);                // (5-nov) la columna derecha (y lo que se esconde en pantalla completa)
         this.placeRadio();
      } finally { this.inLayout = false; }
      if (this.P || this.phase !== "off") { this.renderNow(); }
      try { this.view.repaint(); this.strip.repaint(); } catch (e) {}
   }
   // el WebView de la radio: en el hueco del dial (compacta) o desplegado sobre la esquina de la foto (EMISORAS)
   placeRadio() {
      if (!this.radio || !this.radio.control || !this.L || !this.cockpit) return;
      var L = this.L, c = this.cockpit, X = c.radio, v = this.radio.control;
      try {
         if (this.radioOpen) {
            var w = Math.round(fvClamp(0.40 * L.pw, 360, 900)), h = Math.round(w * 0.62);
            v.setFixedSize(w, h); v.move(L.vx + L.pw - w - Math.round(0.015 * L.pw), L.vy + L.ph - h - Math.round(0.015 * L.pw));
            try { v.zoomFactor = fvClamp(w / 440, 0.8, 2.5); } catch (eZ) {}
            v.bringToFront();
         } else {
            v.setFixedSize(Math.round(2 * X.hw), Math.round(2 * X.hh)); v.move(Math.round(L.sx + X.x - X.hw), Math.round(L.sy + X.y - X.hh));
            try { v.zoomFactor = 1; } catch (eZ2) {}
         }
      } catch (e) { fvLog("radio placement: " + e); }
   }
   radioToggle(open) {
      if (!this.radio) return;
      this.radioOpen = (open === undefined) ? !this.radioOpen : !!open;
      this.radio.query("__fvr.setCompact(" + (this.radioOpen ? "false" : "true") + ")");
      if (this.radioOpen) this.radio.openList(true);
      this.placeRadio();
      this.strip.repaint();
   }
   // pixel del control de la pantalla -> pixel del fotograma (el del piloto)
   toFrame(x, y) { return [x * this.VW / Math.max(1, this.viewW), y * this.VH / Math.max(1, this.viewH)]; }
   start() { if (this.running || this.shut) return; this.running = true; this.lastTick = fvNowMs(); this.timer.start(); }
   stop() { this.running = false; try { this.timer.stop(); } catch (e) {} }
   // (N9) cerrar de verdad: idempotente (el aspa, y fvMain al volver de execute)
   shutdown(why) {
      if (this.shut) return;
      this.shut = true; this.closing = true;
      this.stop();
      try { this.timer.onTimeout = null; } catch (e0) {}
      if (typeof fvBootShipFree === "function") fvBootShipFree();            // (6-nov) los fotogramas de la nave del arranque
      if (this.stfPanel) this.stfPanel.stopFV();                              // (E2) sus temporizadores
      this.rec = null;
      if (this.radio) { try { this.radio.stop(); } catch (e1) {} try { this.radio.dispose(); } catch (e2) {} }
      try { Settings.write(CP_SETTINGS_PREFIX + "/winW", DataType_String, String(this.width)); Settings.write(CP_SETTINGS_PREFIX + "/winH", DataType_String, String(this.height)); } catch (e3) {}
      fvLog("ship closed (" + (why || "?") + ")");
   }
   // (Codex H-1, 4-nov) el aspa con REC: antes shutdown() tiraba la grabacion (this.rec = null) sin pasar por el guardado.
   //  · grabando → se termina el video por el camino normal de REC (carpeta + progreso) y luego se cierra; si no se elige carpeta, la
   //    nave NO se cierra esa vez (aviso; la grabacion sigue): un segundo cierre la descarta
   //  · pintando un video → no se corta: se cierra al terminar (closeAfterRec)
   //  -> true = cerrar (PJSR: undefined/false = veto)
   closeRequest() {
      if (this.shut) return true;
      if (this.recBusy) { this.closeAfterRec = true; fvLog("close: waiting for the video to finish"); return false; }
      if (this.rec && this.P && !this.recCloseAsked) {
         this.recCloseAsked = true;
         var keep = this.rec, long = (this.P.t - keep.t0) >= 1 / FV_REC.FPS;
         var r = this.recToggle(this.recCloseOpts || {});
         if (long && !r && !this.shut) {
            this.rec = keep; keep.keys.pop(); delete keep.t1;                                    // sin carpeta: sigue grabando, nada se pierde
            this.ui.caption = { text: fvTx("rec.closeNoDir"), t0: this.P.t, dur: 4.0 };
            fvLog("close: REC not saved (no folder): window kept open; closing again discards it");
            return false;
         }
         fvLog("close: REC saved before closing (" + (r && r.ok ? r.file : (r ? r.why : "too short")) + ")");
      }
      this.shutdown("close"); return true;
   }
   // la escena construida entra en la nave
   attach(built) {
      var self = this;
      this.built = built; this.scene = built.scene;
      if (built.scene && built.scene.field) {
         var a = built.scene.field.width / built.scene.field.height;
         if (this.auto && Math.abs(a - this.aspect) > 1e-3) { this.aspect = a; this.cockpit = null; this.relayout(this.width, this.height); }
         else this.aspect = a;
      }
      this.P = fvPilotNew(this.scene, this.VW, this.VH);
      if (typeof fvE1aNew === "function") this.e1a = fvE1aNew();             // (19-nov, I5) el vigilante del sonido que informa, de cero con cada foto
      fvPilotSetStyle(this.P, this.style);
      this.P.warpPower = this.warpPower; this.applySpeed();
      this.P.onFlightEnd = function() { self.onArrive(); };
      // (11-nov, NV-1) el laboratorio de vuelo es la navegacion por defecto (FV_LAB.DEFAULT_ON); L vuelve a la de antes
      if (typeof FV_LAB !== "undefined" && FV_LAB.DEFAULT_ON === true && typeof fvLabSetOn === "function") { fvLabSetOn(this.P, true); if (typeof fvLog === "function") fvLog("flight lab: ON by default"); }
      this.painter = new FVPainter(this.scene, built.bmps);
      this.painter.mwOn = this.mwOn;
      if (typeof fvRbToPainter === "function") fvRbToPainter(this);         // (5-nov) nombres, constelaciones y escala recordados
      this.ui.exoList = (built.exo && built.exo.list) ? built.exo.list : [];
      this.nav.map2d = new FVNavMap2D(built.bmps ? (built.bmps.photo || built.bmps.starless) : null);
      this.nav.map3d = new FVNavMap3D(this.scene);
      // (cine §10.4) separacion media entre estrellas del campo: el volumen del cono de la foto hasta la nebulosa (o 2 000 a.l.) entre las que caen dentro
      try {
         var S0 = this.scene.stars, fd = this.scene.field, dR = this.scene.nebula ? this.scene.nebula.distLy : 2000, nIn = 0;
         for (var q = 0; q < S0.n; ++q) if (S0.inFrame[q] && S0.dEarth[q] <= dR) ++nIn;
         var Vc = (fd.width / fd.F) * (fd.height / fd.F) * dR * dR * dR / 3;
         this.meanSep = nIn > 0 ? Math.pow(Vc / nIn, 1 / 3) : 0;
      } catch (eM) { this.meanSep = 0; }
      this.refreshItems();
      if (this.starLook !== "gaia") this.setStarLook(this.starLook, { noSave: true });   // (5-nov) el aspecto recordado
      if (this.route) this.route.attach();                           // (pasada M) las camaras guardadas de ESTA foto
      if (this.L && this.stfPanel && typeof fvRbPlace === "function") fvRbPlace(this, this.L);   // (E2) el boton STF segun la escena (con estirado o no)
      this.phase = "on";
   }
   // (N1/N12) MIRABILIA: los objetos de C (o las estrellas notables) y los planetas conocidos de fv_exo si C aun no los trae
   refreshItems() {
      var sc = this.scene, items = fvNavItems(sc, this.ui.exoList, FV_LANG), L = this.ui.exoList || [], exoItems = [];
      var hasExo = !!(sc && sc.objects && sc.objects.some(function(o) { return o.type === "exoplanet" || (o.planets && o.planets.length); }));
      if (!hasExo && L.length) {
         var ex = [];
         for (var i = 0; i < L.length; ++i) {
            var e = L[i], demo = (e.match !== "gaia-id" && e.match !== "position"), d = sc.stars ? sc.stars.dEarth[e.star] : 0;
            ex.push({ kind: "exo", i: i, star: e.star, name: (demo ? "DEMO · " : "") + e.row.pl_name, type: "exoplanet", score: demo ? 5 : 7, dist: d, sub: (demo && FV_EXO_DEMO_CARD) ? fvTx("b5.navDemo", { d: fvNavDistText(d, "measured", FV_LANG) }) : fvTx("nav.exo") + " · " + fvNavDistText(d, "measured", FV_LANG) });   // (Blender 5 · H4) la demo no dice que el planeta este a la distancia de la estrella del campo
         }
         // (punto 5 de Nino) antes iban justo tras los dos primeros y llenaban las filas visibles; ahora van donde les toca: al final, con tope
         exoItems = ex;
         items = fvNavOrder(items.concat(ex), FV_NAV.LIST_MAX);
      }
      this.nav.list.base = items; this.nav.list.items = items; this.nav.list.ready = true;
      if (this.nav.list.top >= items.length) this.nav.list.top = 0;
      this.searchRebuild(exoItems);                                  // (I3) el indice del buscador (y, si hay texto, sus resultados otra vez: otro idioma)
      // (Blender 1, PL-3) los planetas como mundos: su juego compuesto AHORA y no en el primer fotograma de su ficha (FV_PL3D.ON false: nada)
      if (typeof fvPl3dPrewarm === "function") { try { fvPl3dPrewarm(sc, this.ui.exoList, this.VW); } catch (eP) { fvLog("[pl3d] prewarm failed: " + eP); } }
   }
   // ---------------------------------------------------------------------------
   // (I3) EL BUSCADOR DE MIRABILIA (src/ui/fv_search.js: indice y consulta; el campo lo pinta fv_nav.js)
   // ---------------------------------------------------------------------------
   searchRebuild(exoItems) {
      this.searchExo = exoItems || [];
      if (!this.scene || typeof fvSearchBuild !== "function") { this.searchIdx = null; this.searchApply(); return; }
      try {
         this.searchIdx = fvSearchBuild(this.scene, { lang: FV_LANG, exo: this.searchExo, objItem: fvNavObjItem, nebItem: fvNavNebItem });
         fvLog("search index: " + this.searchIdx.nObj + " objects + " + this.searchIdx.nStar + " stars in " + this.searchIdx.ms.toFixed(1) + " ms");
      } catch (e) { this.searchIdx = null; fvLog("search index failed: " + e); }
      this.searchApply();
   }
   // los resultados del texto actual SUSTITUYEN la lista; sin texto vuelve la lista de siempre
   searchApply() {
      var self = this, st = this.nav.list, S = st.search;
      if (!S.text.length || !this.searchIdx) { S.n = 0; S.ms = 0; if (st.base && st.items !== st.base) { st.items = st.base; st.top = 0; } return; }
      var r = fvSearchRun(this.searchIdx, S.text, FV_SEARCH.MAX, { starItem: function(k) { return fvNavStarItem(self.scene, k, FV_LANG); } });
      S.n = r.n; S.ms = r.ms; st.items = r.items; st.top = 0;
   }
   searchSet(text) {
      this.nav.list.search.text = String(text);
      this.searchApply();
      if (this.strip) this.strip.repaint();
   }
   searchFocus(on) {
      var S = this.nav.list.search, was = S.focus;
      S.focus = !!on && !!this.scene && !!this.P;
      if (S.focus && !was) this.releaseKeys("search focus");        // una tecla de vuelo pulsada no se queda pegada mientras se escribe
      if (S.focus !== was && this.strip) this.strip.repaint();
   }
   // Esc o borrar: vuelve la lista y se suelta el campo
   searchClear(blur) {
      this.searchSet("");
      if (blur !== false) this.searchFocus(false);
   }
   // Intro: viajar al primero de los resultados (como su flecha de «ir»)
   searchEnter() {
      var st = this.nav.list, S = st.search;
      if (!S.text.length || !st.items.length || !this.P) return false;
      this.searchFocus(false);
      this.listGo(0);
      return true;
   }
   // una tecla con el campo activo. PixInsight da el codigo de tecla de Qt (fvSearchKeyChar lo vuelve caracter). -> true si se la come
   searchKey(k, mod) {
      var S = this.nav.list.search;
      if (!S.focus) return false;
      if (k === Key_Escape) { this.searchClear(true); return true; }
      if (k === Key_Return || k === Key_Enter) { this.searchEnter(); return true; }
      if (k === Key_Backspace) { if (S.text.length) this.searchSet(S.text.substring(0, S.text.length - 1)); return true; }
      if (k === Key_Delete) { this.searchSet(""); return true; }
      if (k === Key_Tab) { this.searchFocus(false); return true; }
      var ch = fvSearchKeyChar(k, mod);
      if (ch && S.text.length < FV_SEARCH.MAX_CHARS) this.searchSet(S.text + ch);
      return true;                                                   // con el campo activo el teclado es suyo (las flechas no mueven la nave mientras se escribe)
   }
   navState() {
      var st = this.nav.list;
      if (typeof fvE1cUiSync === "function") fvE1cUiSync(this);      // (I1, 19-nov) la cara de la placa: MIRABILIA o su reverso AENIGMATA
      st.sel = this.P ? this.P.sel : null;
      if (st.sel && this.ui.exo) st.sel = { kind: "exo", i: this.ui.exoIdx };
      st.hover = this.stripHover;
      return { scene: this.scene, P: this.P, map2d: this.nav.map2d || (this.bootBg ? (this.nav.map2d = new FVNavMap2D(this.bootBg)) : null), map3d: this.nav.map3d, list: st, trail: this.nav.trail };
   }
   gauges() {
      var rs = { on: !!this.rec, t: (this.rec && this.P) ? this.P.t - this.rec.t0 : 0, busy: !!this.recBusy, frac: this.recBusy ? this.recBusy.frac : 0, fmt: fvRecFormat(), cab: this.recCab };
      var rd = this.radioStatus();
      if (!this.P) return { speedLyS: 0, warp: 0, dist: 0, clock: 0, reg: 0, regSet: this.warpPower, style: this.style, power: 0.999 * fvBootFraction(this.boot), rec: rs, radio: rd };
      var gz = fvPilotGauges(this.P), fl = this.P.flight;
      gz.reg = fl ? (fl.kind === "warp" ? this.P.warp : 0.35 * Math.sin(Math.PI * fvClamp(fl.t / fl.dur, 0, 1))) : 0;
      if (!fl && typeof fvV1RegHand === "function") { var rh = fvV1RegHand(this.P); if (rh !== null) gz.reg = 0.35 * rh; }      // (20-nov, V1a, V1-10) en vuelo a mano la aguja roja = la fraccion del tope (FV_V1.AIDS)
      // (F4b) parado de verdad = 0 (la ultima velocidad del vuelo se quedaba en la aguja: 3,3 en reposo, revision del 4-nov)
      if (!fl && !this.P.orbit && !this.P.wheel) { gz.speedLyS = 0; gz.speedC = 0; }
      gz.power = 1; gz.rec = rs; gz.regSet = this.warpPower; gz.regDrag = this.regDrag; gz.radio = rd;
      if (typeof fvTimeGauge === "function" && this.scene) gz.epoch = fvTimeGauge(this.scene);       // (I4) AETAS: el año elegido y si hay datos
      if (typeof fvChronoOf === "function" && this.scene) { try { gz.chrono = fvChronoOf(this.P, this.scene, (gz.epoch && gz.epoch.ok) ? gz.epoch.years : 0); } catch (e) { gz.chrono = null; } }   // (C-1) el año de CHRONOMETRUM, como la web
      gz.look = { cur: this.painter ? this.painter.look : this.starLook, busy: this.lookBusy };          // (5-nov) STELLAE
      gz.seen = (typeof fvLabOn === "function" && fvLabOn(this.P));                                       // (9-nov, N8) la aguja de VELOCITAS da la velocidad VISTA (laboratorio de vuelo)
      return gz;
   }
   // (N2) el rotulo de la radio bajo su dial: el estado de verdad (sin pista verificada, apagada, sintonizando, lo que suena)
   radioStatus() {
      var R = this.radio, tab = this.radioOpen ? fvTx("rd.tabClose") : fvTx("rd.tab");
      if (!R) return { text: fvTx("rd.fail"), col: 0xff8A7D68, tab: "" };
      if (R.failed) return { text: fvTx("rd.fail"), col: 0xff8A7D68, tab: "" };
      if (!R.ready) return { text: fvTx("rd.wait"), col: 0xffA3957B, tab: tab };
      var n = 0; try { n = R.stationList().length; } catch (e) {}
      if (!R.on) return { text: n ? fvTx("rd.off") : fvTx("rd.none"), col: 0xffA3957B, tab: tab };
      if (!R.armed) {
         // (R3-arreglos H8) la rueda sobre el dial sintoniza sin desbloquear el audio: el rotulo dice la emisora que ha elegido la persona y SIGUE pidiendo el clic («S2 · pulsa el dial»)
         var at = (R.current && R.current.user === true) ? fvTx("rd.armAt", { id: R.current.id === "mine" ? "♪" : String(R.current.id) }) : null;
         // (P14) con el aviso en marcha el rotulo dice «pulsa el dial» y late entre el dorado y el crema (1 Hz, como la lampara); `hot` = el marco del rotulo
         if (this.radioNudgeOn()) { var u = 0.5 + 0.5 * Math.sin(fvNowMs() / 1000 * 2 * Math.PI), ch = function(sh) { return Math.round(((0xE5B53F >> sh) & 255) * (1 - u) + ((0xFFF3C4 >> sh) & 255) * u); }; return { text: at || fvTx("rd.nudge"), col: (0xff000000 | (ch(16) << 16) | (ch(8) << 8) | ch(0)) >>> 0, tab: tab, hot: true }; }
         return { text: at || fvTx("rd.arm"), col: 0xffE5B53F, tab: tab };      // (R5) encendida y sintonizada, muda hasta el primer clic o tecla en el dial
      }
      if (R.current) return { text: "♪ " + R.current.title + " · " + R.current.author, col: 0xffF3D27E, tab: tab };
      if (!n) return { text: fvTx("rd.none"), col: 0xffE0603F, tab: tab };
      return { text: fvTx("rd.tuning"), col: 0xffE5B53F, tab: tab };
   }
   // (P14) ¿se esta mostrando el aviso de la radio muda? (se apaga solo al sonar o a los SECONDS s)
   radioNudgeOn() { var N = this.nudge, R = this.radio; return !!(N && R && R.on && !R.armed && fvNowMs() < N.until); }
   // (P14) un clic fuera del dial: si la radio esta encendida y muda, lo avisa. Nunca consume el clic. -> true si arranco un aviso nuevo
   radioNudge() {
      var C = FV_RADIO_NUDGE, R = this.radio;
      if (!C.ON || !R || !R.ready || R.failed || !R.on) return false;
      if (C.REQUIRE_MUTE && R.armed) return false;
      var N = this.nudge || (this.nudge = { until: 0 }), S = FV_RADIO_NUDGE_SESSION, now = fvNowMs();
      if (now < N.until || S.n >= C.MAX) return false;
      ++S.n; N.until = now + 1000 * C.SECONDS;
      R.nudge(C.SECONDS);
      fvLog("radio: nudge " + S.n + "/" + C.MAX + " (click outside the dial, radio on and silent)");
      try { this.strip.repaint(); } catch (e) {}
      return true;
   }
   // ---- EL ENCENDIDO (D10) ----
   power() {
      if (this.phase !== "off" || !this.view0) return false;
      var self = this, prev = (typeof CSH_NET_PUMP !== "undefined") ? CSH_NET_PUMP : null, last = 0;
      this.phase = "booting"; this.boot.started = true; this.bootT0 = fvNowMs() - this.boot.t * 1000;
      if (this.radio && typeof this.radio.startNow === "function") { try { this.radio.startNow(); } catch (eM1) { fvLog("radio M1: " + eM1); } }      // (19-nov, M1) POTENTIA: la musica empieza aqui
      function pump(force) {
         var now = fvNowMs();
         if (!force && now - last < 33) return self.closing === true;
         last = now; self.boot.t = (now - self.bootT0) / 1000;
         if (typeof self.opts.onBootFrame === "function") { try { self.opts.onBootFrame(self); } catch (eF) {} }
         if (self.shut) return true;
         self.renderNow(); self.view.repaint(); self.strip.repaint();
         if (FV_PAINTING === 0) { try { CoreApplication.processEvents(); } catch (eP) {} }
         return self.closing === true;
      }
      CSH_NET_PUMP = function() { return pump(false); };
      var built = null;
      try {
         built = fvBuildScene(this.view0, { online: this.online, dialog: this.opts.solverDialog === true, layers: this.opts.layers, exoRows: this.opts.exoRows, spoilLayers: this.opts.spoilLayers, stfPre: this.stfPre,
                                            onSystem: function(id, st, info) {
                                               // (9-nov) SOLO PRUEBAS: una tarea que tarda de mas (FV_BOOT_SHIP.TEST_DELAY, apagado = nada); va ANTES de anotar que acabo
                                               if (typeof fvBootTestDelay === "function") fvBootTestDelay(id, st, pump);
                                               // (9-nov) el sello de la tarea es el reloj REAL: B.t solo avanza al pintar y tras un paso largo sin pintar iba atrasado
                                               if (typeof FV_BOOT_SHIP !== "undefined" && FV_BOOT_SHIP.HOLD_TASK) self.boot.t = (fvNowMs() - self.bootT0) / 1000;
                                               fvBootSet(self.boot, id, st, info); pump(st !== "warm" || !(info && info.elapsedMs)); } });
      } catch (e) { built = { ok: false, why: String(e && e.message ? e.message : e) }; }
      finally { CSH_NET_PUMP = prev; }
      if (this.shut) { this.phase = "off"; return false; }
      if (!built || !built.ok) { this.boot.fail = built ? built.why : "?"; this.phase = "off"; this.renderNow(); this.view.repaint(); this.syncButtons(); fvLog("boot failed: " + this.boot.fail); return false; }
      this.boot.t = (fvNowMs() - this.bootT0) / 1000; this.boot.tDone = this.boot.t;
      this.boot.done = true;
      this.attach(built);
      // (6-nov) la nave del arranque: si la cola de flechas va atrasada, el fundido espera lo que falte (≤ FV_BOOT_SHIP.MAX_EXTRA_S)
      this.bootFadeT0 = this.P.t + ((typeof fvBootShipExtra === "function") ? fvBootShipExtra(this.boot) : 0);
      this.ui.caption = { text: fvTx("cap.makeitso"), t0: this.P.t + 0.6, dur: 1.8 };
      this.lastTick = fvNowMs();
      this.renderNow(); this.view.repaint(); this.strip.repaint(); this.syncButtons();
      return true;
   }
   // (7-nov) para PRUEBAS: quita ya la placa del arranque (planos fijos, plano final y partida) y deja la cabina limpia. Sin efecto si
   // la nave aun no ha encendido. Sustituye a poner D.bootFadeT0 = null a mano
   bootSkip() {
      if (!this.P) return false;
      this.bootFadeT0 = null;
      if (typeof fvBootShipFree === "function") fvBootShipFree();
      this.renderNow(); this.view.repaint(); this.strip.repaint();
      return true;
   }
   // un paso: reloj → fotograma → repintar (nada de esto dentro de un onPaint)
   tick(dtForced) {
      if (this.shut) return;
      if (this.recLocked()) return;                                  // (nA2, E7) el reloj de la nave se para mientras se pinta el video
      var now = fvNowMs(), dt = (dtForced !== undefined) ? dtForced : Math.min((typeof fvV1On === "function" && fvV1On("CLOCK")) ? FV_V1.DT_MAX : 0.05, (now - this.lastTick) / 1000);      // (20-nov, V1-11, FV_V1.CLOCK) 0,05 -> 0,1 s: por debajo de 20 fps el vuelo iba a camara lenta (la web ya recortaba a 0,1)
      this.lastTick = now;
      if (this.phase === "booting") return;                         // lo pinta el bombeo de power()
      if (!this.P) { this.boot.t += dt; this.renderNow(); this.view.repaint(); this.strip.repaint(); return; }
      fvPilotStep(this.P, dt);
      if (this.gal && typeof fvGalStep === "function") fvGalStep(this, dt);   // (encargo D1) el zoom de GALAXIA
      if (this.hr && typeof fvHrStep === "function") fvHrStep(this, dt);      // (I2, 19-nov) el reloj del diagrama HR (src/ui/fv_hr_ui.js)
      if (this.route) this.route.tick(dt);                         // (pasada M) el recorrido de la ruta (respaldo), la fila de viaje de la ficha y las miniaturas
      fvNavTrailPush(this.nav.trail, this.P, this.scene);          // (N2) la estela de la nave en TABULA y PROFUNDITAS
      this.lookStep(dt);
      if (this.cockpit && this.cockpit.aetasTick) this.cockpit.aetasTick(this.scene, dt);   // (I3, 19-nov) AETAS: la reproduccion automatica del tiempo (▲ ▼), un paso por fotograma
      // (N4) fin de un vuelo: si el piloto no avisa (P.onFlightEnd de B), se detecta aqui el paso de «volando» a «parado»
      var flying = !!this.P.flight;
      if (this.wasFlying && !flying) this.onArrive();
      this.wasFlying = flying;
      if (this.reopenAt !== null && this.P.t >= this.reopenAt) this.reopenNow();
      if (typeof fvE1uTick === "function") fvE1uTick(this);                   // (I4) placa de la respuesta, balanceo, silencio de llegada
      this.duckStep();
      this.e1aStep();                                               // (19-nov, I5) E1-18 / E1-19: sonido que informa (nota de la estrella elegida, tic al pasar cerca, motivo al llegar)
      this.tourStep();
      this.tourBarSync();
      if (this.rec) { this.rec.keys.push(fvRecSnap(this)); if (this.P.t - this.rec.t0 > FV_REC.MAX_S) this.recToggle(); }
      if (this.pendingExo && !this.P.flight && this.P.arrivedAt && this.P.arrivedAt.kind === "star" && this.P.arrivedAt.i === this.pendingExo.star) { this.openExo(this.pendingExo); this.pendingExo = null; }
      this.renderNow();
      this.view.repaint(); this.strip.repaint();
      this.syncButtons();
   }
   // (N4) al llegar: la ficha que se oculto al salir se vuelve a abrir (con su barrido de escaner otra vez)
   onArrive() {
      if (!this.P) return;
      if (typeof fvE1tArrive === "function") fvE1tArrive(this);                  // (I4; E1-14) silencio de llegada a un objeto principal
      if (this.reopenCard) { if (this.reopenAt === null) this.reopenAt = this.P.t + FV_UI.CARD_REOPEN_S; }
      else this.ui.hideCard = false;
   }
   reopenNow() {
      this.reopenAt = null;
      if (!this.reopenCard || !this.P) return;
      this.reopenCard = false; this.ui.hideCard = false; this.ui.cardClosed = false; if (this.P.sel) this.P.sel.t0 = this.P.t;
      this.cardReopenedAt = this.P.t;
   }
   // (cine §10.4) LA RADIO RESPIRA CON EL VIAJE: un factor temporal sobre el volumen del usuario (radio.duck, no se guarda). CINE: 0,7 al
   // salir, 0,7 → 0,85 en crucero, crescendo a 1 en la llegada. WARP: 0,35 con paso bajo en la preparacion, SILENCIO en el salto, vuelve
   // en crucero y pico al salir. Parado: 1 en casa o con ficha, 0,85 en vuelo libre y menos en el vacio (lejos de todo, hasta FV_DUCK.VOID_FLOOR = 0,70).
   // Nunca enciende ni cambia de pista: solo atenua. Devuelve { f, s, hz } (lo que pediria; las pruebas lo leen sin radio).
   duckTarget() {
      var P = this.P, fl = P ? P.flight : null;
      if (!P) return { f: 1, s: 1.0, hz: 18000 };
      if (this.e1hush && P.t < this.e1hush.until && !fl) return { f: this.e1hush.f, s: this.e1hush.s, hz: this.e1hush.hz };   // (I4; E1-14) silencio de llegada
      if (fl && (fl.kind === "warp" || fl.gwHome === true) && fl.warpPhase) {
         // (B, 4-nov) prep → jump → breath → flash → cruise → exit: la pausa (breath) va justo ANTES del destello; la radio calla en breath y flash
         var wp = fl.warpPhase;
         if (wp === "prep") return { f: 0.35, s: 1.5, hz: 1200 };
         if (wp === "jump") return { f: 0.2, s: 0.4, hz: 900 };
         if (wp === "breath" || wp === "flash") return { f: 0, s: 0.12, hz: 900 };
         if (wp === "cruise") return { f: 0.8, s: 1.2, hz: 18000 };
         return { f: (P.warp > 0.3 ? 1.0 : 0.85), s: (P.warp > 0.3 ? 0.3 : 1.0), hz: 18000 };       // exit
      }
      if (fl && (fl.kind === "warp" || fl.gwHome === true)) {
         var ph = fl.phase || "depart";
         if (ph === "depart") return (P.warp > 0.02 || P.flash > 0.05) ? { f: 0, s: 0.12, hz: 1200 } : { f: 0.35, s: 1.5, hz: 1200 };
         if (ph === "cruise") return { f: 0.8, s: 1.2, hz: 18000 };
         return { f: (P.warp > 0.3 ? 1.0 : 0.85), s: (P.warp > 0.3 ? 0.3 : 1.0), hz: 18000 };
      }
      if (fl && (fl.kind === "cine" || fl.kind === "home")) {
         var u = fvClamp(fl.t / Math.max(0.01, fl.dur), 0, 1), ph2 = fl.phase || (u < 0.2 ? "depart" : (u < 0.75 ? "cruise" : "arrive"));
         if (u >= 0.75) return { f: 0.85 + 0.15 * (u - 0.75) / 0.25, s: 0.5, hz: 18000 };          // crescendo del ultimo 25 %
         if (ph2 === "depart") return { f: 0.7, s: 1.2, hz: 18000 };
         return { f: 0.7 + 0.15 * fvClamp((u - 0.2) / 0.55, 0, 1), s: 1.0, hz: 18000 };
      }
      if (fvLen(P.cam.pos) < 1e-6 || this.cardOpen()) return { f: 1, s: 1.0, hz: 18000 };
      // el vacio (Contact): r = distancia a lo mas cercano / separacion media del campo; r < 0,5 → 1 · r > 5 → FV_DUCK.VOID_FLOOR (lineal en log r filtrado)
      var f = 0.85;
      if (this.meanSep > 0 && typeof fvNearestDist === "function") {
         var lr = this.duckVoidLogR(Math.log(Math.max(1e-9, fvNearestDist(P) / this.meanSep) / 0.5) / Math.LN10);
         f = Math.min(f, 1 - (1 - FV_DUCK.VOID_FLOOR) * fvClamp(lr, 0, 1));
      }
      return { f: f, s: 3.0, hz: 18000 };
   }
   // (R4) log10(r / 0,5) filtrado con un paso bajo de FV_DUCK.VOID_TAU_S segundos (reloj de la nave P.t: llamadas repetidas en el mismo instante devuelven lo mismo);
   // sin historia (primera muestra, o se vuelve de otra rama del duck tras mas de 0,5 s) arranca en el valor sin filtrar
   duckVoidLogR(raw) {
      var P = this.P, t = P ? P.t : 0, s = this.duckLr;
      raw = fvClamp(raw, -0.5, 1.5);
      if (!s || t < s.t || t - s.t > 0.5) { this.duckLr = { v: raw, t: t }; return raw; }
      var dt = t - s.t;
      if (dt > 0) { s.v += (raw - s.v) * (1 - Math.exp(-dt / FV_DUCK.VOID_TAU_S)); s.t = t; }
      return s.v;
   }
   // (4-nov, radio generativa) la intensidad que pide el viaje a las emisoras de a bordo: fvRadioLevelFor (src/radio/fv_radio.js)
   radioLevelStep() {
      if (!this.radio || !this.radio.ready || typeof this.radio.level !== "function" || typeof fvRadioLevelFor !== "function") return;
      var lv = Math.round(fvRadioLevelFor(this.P, this.cardOpen()) * 20) / 20;
      if (this.e1hush && this.P.t < this.e1hush.until && !this.P.flight) lv = Math.round(this.e1hush.level * 20) / 20;   // (I4; E1-14) una sola capa
      if (this.radioLvSent === lv) return;
      this.radioLvSent = lv; this.radio.level(lv);
   }
   // (19-nov, I5; E1-18 y E1-19) lo que ha pasado en la nave (seleccion, paso cerca, llegada a un objeto) → lo que dice la radio. El vigilante es puro (src/engine/fv_e1a.js, el mismo que el visor
   // web); la radio decide si suena (apagada o muda, interruptor, emisora de a bordo, atenuacion, enfriamiento). FV_E1A.ON = false: no hace nada
   e1aStep() {
      if (!this.radio || !this.e1a || !this.P || typeof fvE1aStep !== "function" || typeof this.radio.inform !== "function") return;
      var ev = fvE1aStep(this.e1a, this.P);
      for (var i = 0; i < ev.length; ++i) { try { this.radio.inform(ev[i]); } catch (eE) { fvLog("e1a: " + eE); } }
   }
   duckStep() {
      this.radioLevelStep();
      var t = this.duckTarget(), D = this.duckSent;
      this.duckNow = t;
      // (Codex H-3, 4-nov) mientras la radio carga no se da nada por enviado: al estar lista recibe la atenuacion vigente
      if (!this.radio || !this.radio.ready || typeof this.radio.duck !== "function") { this.duckSent = null; return; }
      // (R4) histeresis: solo se envia si el objetivo cambia mas de FV_DUCK.SEND_HYST (antes 0,02); 0 y 1 (silencio / volumen pleno) siempre llegan al valor exacto
      if (D && D.hz === t.hz && Math.abs(D.f - t.f) < FV_DUCK.SEND_HYST && !(t.f !== D.f && (t.f >= 0.999 || t.f <= 0.001))) return;
      this.duckSent = { f: t.f, hz: t.hz, at: this.P ? this.P.t : 0 };
      this.radio.duck(t.f, t.s, t.hz);
   }
   renderNow() {
      if (this.shut) return { ms: 0 };
      if (this.recLocked()) return { ms: 0 };                       // (nA2, E7) lo unico que pinta la pantalla es el aviso de progreso (recRender)
      if (!this.P) {
         this.frame.fill(0xff07060A);                                   // fill ANTES de abrir el Graphics (PJSR lo prohibe con uno activo)
         var g = new Graphics(this.frame), kb = fvHudK(this.VW);
         try {
            if (Math.abs(kb - 1) > 1e-6) g.scaleTransformation(kb, kb);
            fvBootPaint(g, this.VW / kb, this.VH / kb, this.boot, this.bootBg, 1, kb);
            if (typeof fvE1qPaint === "function") fvE1qPaint(g, this, this.VW / kb, this.VH / kb, kb, 1);          // (20-nov, I4) E1-01 la pregunta mientras carga
            g.resetTransformation(); fvFramePaint(g, this.VW, this.VH);
         } finally { g.end(); }
         var r = this.boot.leverRect; this.leverPx = r ? [r[0] * kb, r[1] * kb, r[2] * kb, r[3] * kb] : null;
         return { ms: 0 };
      }
      // (pasada M) mapa en grande: la nave se pinta a su hueco pequeño y el mapa en la pantalla (fv_route.js)
      if (this.route && this.route.big) { var stR = this.route.render(); this.frameMs.push(stR.ms); if (this.frameMs.length > 600) this.frameMs.shift(); return stR; }
      if (this.gal && typeof fvGalRender === "function") { var stG = fvGalRender(this); this.frameMs.push(stG.ms); if (this.frameMs.length > 600) this.frameMs.shift(); return stG; }   // (encargo D1)
      // (20-nov, I4; E1-12) el balanceo de paralaje: la camara va de lado SOLO mientras se pinta (los instrumentos y el piloto no lo ven)
      var e1Off = (typeof fvE1sNow === "function") ? fvE1sNow(this) : 0, e1Pos = null, e1Fov = null;
      if (e1Off) {
         e1Pos = this.P.cam.pos;
         // (20-nov, H7) el borde de la foto no asoma: la vista se acerca lo justo mientras la camara va de lado (fvE1sZoomK; 1 en casa)
         var e1k = this.e1s ? fvE1sZoomK(this.P.cam, this.scene, e1Off, this.e1s.plan.ampLy, this.frame.width, this.frame.height) : 1;
         if (e1k > 1) { e1Fov = this.P.cam.fov; this.P.cam.fov = fvE1sFovK(e1Fov, e1k); }
         this.P.cam.pos = fvE1sShift(this.P.cam, e1Off);
      }
      var st;
      try { st = this.painter.render(this.frame, this.P, { hud: true, frame: true, vignette: true, ui: this.ui }); } finally { if (e1Pos) this.P.cam.pos = e1Pos; if (e1Fov !== null) this.P.cam.fov = e1Fov; }
      if (this.bootFadeT0 !== null) {
         this.boot.t = (fvNowMs() - this.bootT0) / 1000;               // (6-nov) la nave sigue girando y brillando durante el fundido
         // (6-nov, Nino) con la nave, LA PARTIDA: la placa lleva la foto (se acerca y vuelve a su encuadre) y su opacidad la marca fv_boot.js
         var dep = (typeof fvBootShipDepartOn === "function") && fvBootShipDepartOn(), kb2 = fvHudK(this.VW);
         var a = dep ? fvBootShipOverlayAlpha(this.boot) : 1 - fvSmooth((this.P.t - this.bootFadeT0 - 0.5) / 0.9);
         if (a > 0.01) { var g2 = new Graphics(this.frame); try { if (Math.abs(kb2 - 1) > 1e-6) g2.scaleTransformation(kb2, kb2); fvBootPaint(g2, this.VW / kb2, this.VH / kb2, this.boot, dep ? this.bootBg : null, a, kb2); if (typeof fvE1qPaint === "function") fvE1qPaint(g2, this, this.VW / kb2, this.VH / kb2, kb2, a); } finally { g2.end(); } }
         else { this.bootFadeT0 = null; if (typeof fvBootShipFree === "function") fvBootShipFree(); }
      }
      this.frameMs.push(st.ms); if (this.frameMs.length > 600) this.frameMs.shift();
      return st;
   }
   // ---------------------------------------------------------------------------
   // RATON Y TECLADO DE LA PANTALLA
   // ---------------------------------------------------------------------------
   hitAt(fx, fy) {
      var H = (this.painter && this.painter.hits) || [];
      for (var i = 0; i < H.length; ++i) { var h = H[i]; if (fx >= h.x0 && fx <= h.x1 && fy >= h.y0 && fy <= h.y1) return h.id; }
      return null;
   }
   viewMove(x, y, buttons) {
      var f = this.toFrame(x, y);
      if (typeof fvE1qHover === "function") { var tq = fvE1qHover(this, x, y); if (tq !== null) { if (this.e1tip !== tq) { this.e1tip = tq; this.view.toolTip = tq; } } else if (this.e1tip) { this.e1tip = ""; this.view.toolTip = ""; } }   // (I4) la placa QUAESTIO lleva su texto largo en el tooltip
      if (!this.drag || !buttons) {
         // (N2) cursor de mano sobre lo que se pulsa de la pantalla (placa DATOS, «MÁS», ×, botones de los avisos) y realce del ×
         var h = this.P ? this.hitAt(f[0], f[1]) : null, act = !!h && h !== "card" && h !== "notice" && h !== "exo-panel" && h !== "exo-plport" && h !== "tour-bar";
         if (!this.P && this.leverPx) { var r = this.leverPx; act = f[0] >= r[0] && f[0] <= r[2] && f[1] >= r[1] && f[1] <= r[3]; }
         if (act !== this.viewHand) { this.viewHand = act; this.view.cursor = new Cursor(act ? StdCursor_PointingHand : StdCursor_Cross); }
         this.ui.hover = h;
         var tipL = (h && String(h).indexOf("lab-") === 0 && typeof fvLabUiTip === "function") ? fvLabUiTip(h) : "";   // (8-nov) tooltip del panel del laboratorio
         if (h === "exo-plport" && typeof fvTipBoth === "function") tipL = fvTipBoth("pl3.portTrTip");          // (Blender 3 · D5) la portilla del transito
         if (h && String(h).indexOf("e1q") === 0 && typeof fvE1qHudTip === "function") tipL = fvE1qHudTip(this);          // (I4) la placa QUAESTIO de la cabina
         if (h === "nm-photo" && typeof fvTipBoth === "function") tipL = fvTipBoth("nav.m.photoTip");          // (20-nov, E-nav) el rotulo TU FOTO
         if (h && String(h).indexOf("tour-") === 0 && typeof fvTipBoth === "function") tipL = fvTipBoth("tip." + String(h).replace("-", "_"));   // (12-nov, R7) la barra del tour: tip.tour_next, tip.tour_prev, tip.tour_pause, tip.tour_bar
         if (this.hr && typeof fvHrTipAt === "function") { var tipH = fvHrTipAt(this, f[0], f[1]); if (!tipL) tipL = tipH; }   // (I2) el punto bajo el cursor y los tooltips del diagrama HR
         if (tipL !== (this.labTip || "")) { this.labTip = tipL; this.view.toolTip = tipL; }
         return;
      }
      if (!this.P) return;
      if (this.hr && typeof fvHrHold === "function" && fvHrHold(this)) return;   // (I2) con el diagrama HR la mirada no se arrastra
      var dx = x - this.drag.x, dy = y - this.drag.y;
      if (Math.abs(x - this.drag.x0) + Math.abs(y - this.drag.y0) > 3) this.drag.moved = true;
      if (!this.drag.moved) return;
      this.drag.x = x; this.drag.y = y; this.lookTo = null;
      // (N10/N11) el vuelo libre es de B: si fvPilotMouse lo consume, aqui no se mueve la camara
      if (typeof fvPilotMouse === "function") { var used = false; try { used = fvPilotMouse(this.P, dx * this.VW / this.viewW, dy * this.VH / this.viewH, buttons) === true; } catch (eM) {} if (used) return; }
      var k = this.P.cam.fov / this.viewW; fvPilotLook(this.P, -dx * k, dy * k);
   }
   wheel(delta, buttons) {
      if (!this.P) return;
      this.lookTo = null;
      if (this.hr && typeof fvHrHold === "function" && fvHrHold(this)) return;   // (I2) ni la rueda
      if (this.gal) { if (typeof fvGalWheel === "function") fvGalWheel(this, delta); return; }   // (encargo D1) la rueda no mueve la nave escondida; (ronda 2b) acerca o aleja la galaxia
      // (N11) la rueda: primero el piloto de B (fvPilotMouse con el 5.º argumento = muescas de la rueda); si no la consume, la de F1
      if (typeof fvPilotMouse === "function") { var used = false; try { used = fvPilotMouse(this.P, 0, 0, buttons || 0, delta / 120) === true; } catch (eW) {} if (used) return; }
      // (5-nov, rueda por ritmo) la hora de pared del evento: el ritmo de la rueda (muescas/s) decide cuanto avanza cada muesca
      fvPilotWheel(this.P, delta / 120, fvNowMs() / 1000);
   }
   keyDown(k, mod) {
      if (this.recLocked()) { if (k === Key_Escape) this.recCancelNow("Esc"); return true; }     // (nA2, E7) con el video pintandose, solo Esc (cancelar); el resto se come
      if (k === Key_Escape && this.P && this.bootFadeT0 !== null) { this.bootSkip(); return true; }   // (7-nov) Esc salta la placa del arranque
      if (this.gal && typeof fvGalKey === "function" && fvGalKey(this, k)) return true;              // (encargo D1) Esc vuelve de GALAXIA
      if (this.hr && typeof fvHrKey === "function" && fvHrKey(this, k)) return true;                 // (I2) Esc devuelve las estrellas del diagrama HR
      if (this.nav.list.search.focus && this.searchKey(k, mod)) return true;                    // (I3) con el campo de MIRABILIA activo, el teclado es del campo
      if (typeof fvE1uKey === "function" && fvE1uKey(this, k)) return true;                  // (I4) cualquier tecla salta el balanceo de paralaje; Y lo repite
      if (this.P && typeof fvPilotKey === "function") { var used = false; try { used = fvPilotKey(this.P, k, true) === true; } catch (eK) {} if (used) return true; }
      return this.key(k);
   }
   keyUp(k, mod) {
      if (this.recLocked()) return true;
      if (this.P && typeof fvPilotKey === "function") { try { if (fvPilotKey(this.P, k, false) === true) return true; } catch (eK) {} }
      return false;
   }
   // suelta todas las teclas del vuelo libre de B (P.free.keys) -> cuantas estaban pulsadas
   releaseKeys(why) {
      this.padRelease(true);                                              // (5-nov) y la cruceta (de golpe: sin el minimo de un clic)
      var F = this.P && this.P.free, n = 0;
      if (!F || !F.keys) return 0;
      for (var a in F.keys) if (F.keys[a]) { F.keys[a] = false; ++n; }
      if (n) fvLog("free flight: " + n + " key(s) released (" + why + ")");
      return n;
   }
   click(x, y) {
      this.searchFocus(false);                                                 // (I3) un clic en la foto suelta el campo del buscador
      // (7-nov) con la nave ya encendida y la placa del arranque aun encima (los 9 planos, el final y la partida), un clic la SALTA:
      // directo a la cabina (antes se pulsaban botones que no se veian)
      if (this.P && this.bootFadeT0 !== null) { this.bootSkip(); return; }
      if (!this.P) { var r = this.leverPx || this.boot.leverRect; if (r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) this.power(); return; }
      var H = this.painter.hits || [];
      for (var i = 0; i < H.length; ++i) {
         var h = H[i];
         if (x < h.x0 || x > h.x1 || y < h.y0 || y > h.y1) continue;
         if (String(h.id).indexOf("lab-") === 0 && typeof fvLabUiClick === "function") { fvLabUiClick(this, h.id); return; }   // (8-nov) panel del laboratorio
         if (h.id === "legend") { this.ui.legendOpen = !this.ui.legendOpen; return; }
         if (h.id === "card-more") { this.ui.cardMore = !this.ui.cardMore; return; }
         if (h.id === "card-close") { this.closeCard(); return; }
         if (h.id === "card-link" && typeof fvE1cUiFollow === "function") { fvE1cUiFollow(this); return; }      // (I1, 19-nov) la pregunta de la ficha: ir al objeto que la contesta
         // (pasada M) la fila de viaje de la ficha: VIAJAR con el MODUS, o con el otro modo
         if (h.id === "card-travel" || h.id === "card-alt") { this.cardGo(h.id === "card-alt"); return; }
         if (h.id === "exo-close") { this.ui.exo = null; this.syncButtons(); return; }
         if (h.id === "exo-panel" || h.id === "exo-plport") return;
         if (h.id === "mw-toggle") { this.toggleMw(); return; }
         if (h.id === "fg-toggle" && typeof fvFgCycle === "function") { fvFgCycle(); return; }   // (Blender 2) la ventana de la nave
         if (typeof fvE1qClickId === "function" && String(h.id).indexOf("e1q") === 0 && fvE1qClickId(this, h.id)) return;   // (I4) la placa QUAESTIO de la cabina
         if (h.id === "notice-close") { this.ui.notice = null; return; }
         if (h.id === "notice-openDir" && this.ui.notice) { this.lastOpenDir = fvOpenFolder(this.ui.notice.dir); return; }
         if (h.id === "notice-openBrowser" && this.ui.notice) { this.launchBrowser(); return; }
         if (h.id === "notice-changeDir" && this.ui.notice) { this.changeDir(this.ui.notice.kind); return; }
         if (h.id === "notice") return;
         if (h.id === "tour-next") { this.tourNext(); return; }                   // (12-nov, R7) la barra del tour
         if (h.id === "tour-prev") { this.tourPrev(); return; }
         if (h.id === "tour-pause") { this.tourPause(); return; }
         if (h.id === "tour-bar") return;
         if (h.id === "card") return;
         if (h.id === "nm-photo") { this.goPhoto(); return; }                     // (20-nov, E-nav) el rotulo TU FOTO: volver volando a la foto
      }
      if (this.hr && typeof fvHrClick === "function" && fvHrClick(this, x, y)) return;   // (I2) con el diagrama HR: clic en un punto = su ficha
      // (N2, punto 2 de Nino) un clic en un objeto lo SELECCIONA (la reticula) pero NO abre su ficha: la ficha sale con INFO o al llegar
      // (N8) los objetos extensos de C tienen prioridad sobre la estrella si el clic cae dentro (fvObjectHit)
      if (typeof fvObjectHit === "function" && this.scene.objects) {
         var oi = -1; try { oi = fvObjectHit(this.scene, fvProjector(this.P.cam, this.VW, this.VH), this.P, x, y); } catch (eO) { oi = -1; }
         if (oi >= 0) { this.select({ kind: "object", i: oi }); return; }
      }
      var hit = fvPick(this.P, x, y, 24);
      if (hit) this.select({ kind: hit.kind, i: hit.i, sx: hit.sx, sy: hit.sy }); else { this.P.sel = null; this.ui.cardMore = false; this.syncButtons(); }
   }
   // elegir un objeto: queda la reticula y la ficha CERRADA (openCard = true la abre: INFO, el viaje al llegar, las pruebas que lo piden)
   select(sel, openCard) {
      if (!this.P) return;
      sel.t0 = this.P.t; this.P.sel = sel;
      this.ui.cardMore = false; this.ui.hideCard = false; this.reopenCard = false; this.reopenAt = null;
      this.ui.cardClosed = (openCard !== true);
      if (this.ui.exo && !(sel.kind === "star" && sel.i === this.ui.exo.star)) this.ui.exo = null;
      this.syncButtons();
   }
   // (N4) cerrar la ficha (× o Esc): el objeto sigue elegido
   closeCard() {
      this.ui.cardClosed = true; this.ui.cardMore = false; this.reopenCard = false; this.reopenAt = null;
      // (16-nov, P17; FV_TOUR_READ.CLOSE_CLEARS_HOVER) la ficha cerrada no puede tener el cursor encima: su hover («card-close») duraba hasta el siguiente movimiento del raton y tourStep lo leia como «en la ficha»
      if (FV_TOUR_READ.CLOSE_CLEARS_HOVER && this.ui.hover && String(this.ui.hover).indexOf("card") === 0) this.ui.hover = null;
      this.tourCardClosed();
   }
   // (16-nov, P17; FV_TOUR_READ.CLOSE_NOW, DECISION DE NINO, apagada de fabrica) con el tour esperando en una parada, cerrar la ficha pasa ya a la siguiente. En pausa del usuario o en vuelo no
   tourCardClosed() {
      var T = this.tour;
      if (!FV_TOUR_READ.CLOSE_NOW || !T || !this.P || T.state !== "hold" || this.P.flight || T.paused) return false;
      fvLog("tour: card closed by the user, next stop at once (from stop " + (T.i + 1) + ")");
      this.tourGoTo(T.i + 1); this.tourBarSync(); this.syncButtons();
      return true;
   }
   cardOpen() { return !!(this.P && this.P.sel && !this.ui.cardClosed && !this.ui.exo); }
   // la ficha esta A LA VISTA (abierta y no oculta por un viaje)
   cardShown() { return this.cardOpen() && !this.ui.hideCard; }
   openCard() {
      if (!this.P || !this.P.sel) return false;
      this.ui.cardClosed = false; this.ui.hideCard = false; this.ui.cardMore = false; this.reopenCard = false; this.reopenAt = null; this.P.sel.t0 = this.P.t;
      return true;
   }
   // (pasada M) VIAJAR desde la ficha: con el MODUS (alt false) o con el otro modo (alt true). La ficha se oculta y se reabre al llegar (travel).
   cardGo(alt) {
      var P = this.P; if (!P || !P.sel || P.flight) return false;
      this.tour = null;
      var st = (alt && !fvGwarpUi()) ? (this.style === "spectacular" ? "cine" : "spectacular") : null;      // (N-galaxias-warp) con FV_GWARP no hay «otro modo»
      return this.travel(P.sel, st || undefined);
   }
   // el boton INFO (tecla I): abre la ficha del objeto elegido, o la cierra si ya esta abierta; sin objeto elegido, lo dice
   infoToggle() {
      var P = this.P;
      if (!P) return;
      if (this.cardShown()) { this.closeCard(); return; }
      if (!P.sel) { this.ui.caption = { text: fvTx("cap.noSel"), t0: P.t, dur: 2.6 }; return; }
      this.openCard();
   }
   key(k) {
      if (k === Key_Escape) {
         // (N4) Esc cierra lo que haya abierto, de lo mas reciente a lo mas viejo; NUNCA la nave (devuelve true: no sube al dialogo)
         // (5-nov) primero sale de la pantalla completa (como Esc en el navegador)
         if (this.rbFsOn && typeof fvRbFullscreen === "function") fvRbFullscreen(this, false);
         else if (this.stfPanel && this.stfPanel.visibleFV) this.stfPanel.close();          // (E2) el panel del estirado
         else if (this.nav.list.search.text.length) this.searchClear(true);               // (I3) los resultados del buscador: vuelve la lista
         else if (this.radioOpen) this.radioToggle(false);
         else if (this.route && this.route.big) this.route.close();                      // (pasada M) el mapa grande vuelve a su hueco
         else if (this.route && this.route.play) this.route.stopFly("Esc");               // (pasada M) y para el recorrido de la ruta
         else if (this.ui.notice) this.ui.notice = null;
         else if (this.ui.exo) this.ui.exo = null;
         else if (this.cardOpen() || this.reopenCard) this.closeCard();       // (punto 2) tambien la que esta pendiente de abrirse al llegar
         else if (this.ui.legendOpen) this.ui.legendOpen = false;
         return true;
      }
      if (k === Key_Space) { if (!this.P) this.power(); else this.button("travel"); return true; }
      if (typeof fvRbKey === "function" && fvRbKey(this, k)) return true;            // (5-nov) P · N · C · E · F/F11 (la columna derecha)
      if (!this.P) return false;
      if (typeof fvLabUiKey === "function" && fvLabUiKey(this, k)) return true;      // (8-nov) L laboratorio de vuelo · V espacio S · O telescopio
      if (k === Key_I) this.button("info");
      else if (k === Key_H) this.goHome();
      else if (k === Key_T) this.button("tour");
      else if (this.tour && (k === 0x2e || k === 0x3e)) this.tourNext();               // (12-nov, R7) «.» siguiente parada del tour (como el boton ▶| de su barra)
      else if (this.tour && (k === 0x2c || k === 0x3c)) this.tourPrev();               // «,» anterior
      else if (this.tour && k === 0x42) this.tourPause();                              // B = pausa / sigue
      else if (k === Key_X) this.exoButton();
      else if (k === Key_M && !fvGwarpUi()) { this.toggleStyle(); this.strip.repaint(); }      // (21-nov, N-galaxias-warp) la tecla M del selector desaparece con el selector
      else if (k === Key_R) { this.recToggle(); this.strip.repaint(); }
      else if (k === Key_G) this.toggleMw();
      else if (k === 0x2f) this.searchFocus(true);                                    // (I3) «/» = al buscador de MIRABILIA
      else return false;
      return true;
   }
   // ---------------------------------------------------------------------------
   // LA FRANJA (N1/N2)
   // ---------------------------------------------------------------------------
   setStripHover(id) {
      if (id === this.stripHover) return;
      this.stripHover = id; if (this.cockpit) this.cockpit.hover = id;
      var base = id ? String(id).replace(/:\d+$/, "") : null, c = this.cockpit;
      if (base === "searchClear") base = "search";
      var cur = !id ? StdCursor_Arrow : ((id === "reg" || id === "aetas") ? StdCursor_OpenHand : (id === "search" && typeof StdCursor_IBeam !== "undefined" ? StdCursor_IBeam : (c && c.isAction(id) ? StdCursor_PointingHand : StdCursor_Arrow)));
      this.strip.cursor = new Cursor(cur);
      if (base === "gV" && typeof fvLabOn === "function" && typeof FV_N8_SEEN !== "undefined" && FV_N8_SEEN && fvLabOn(this.P)) base = "gVseen";        // (9-nov, N8)
      if (base === "radioInfo" && this.radioNudgeOn()) base = "radioNudge";          // (P14) el rotulo avisando: el tooltip explica por que
      this.strip.toolTip = base ? fvTipBoth("tipck." + (typeof fvBoundsTipKey === "function" ? fvBoundsTipKey(base) : base)) : "";   // (9-nov, encargo C) con FV_BOUNDS, la ayuda de TABULA / PROFUNDITAS dice «nave» y los planos
      // (B, 14-nov) la ayuda de una fila de MIRABILIA con rotulo: el titulo, el nombre de catalogo y el criterio exacto (fvNavLabelTip); el resto de filas, la ayuda de la lista
      if (id && /^list(Go)?:\d+$/.test(String(id))) { var rIt = this.nav.list.items[parseInt(String(id).replace(/^\D+:/, ""), 10)]; if (rIt && rIt.tip) this.strip.toolTip = rIt.tip; }
      this.strip.repaint();
   }
   stripMove(x, y, buttons) {
      if (this.recLocked()) return;
      if (this.regDrag) { this.setRegFromXY(x, y); return; }
      if (this.cockpit.aetasMove && this.cockpit.aetasMove(x, y, this.scene)) { this.renderNow(); this.view.repaint(); this.strip.repaint(); return; }   // (I4) AETAS
      if (this.route && this.route.stripMove(x, y)) return;          // (pasada M) la lista de camaras y la ventanita de la nave
      this.setStripHover(this.cockpit.hit(x, y, this.nav.list));
   }
   setRegFromXY(x, y) {
      var R = this.cockpit.reg, a = Math.atan2(x - R.x, -(y - R.y)) * 180 / Math.PI;
      this.warpPower = fvClamp((a + 62) / 124, 0, 1);
      if (this.P) this.P.warpPower = this.warpPower;
      this.applySpeed();
      this.strip.repaint();
   }
   // (punto 8 de Nino) la velocidad del viaje al motor de B: fvPilotSetSpeed(P, s) con s de 0 a 1 (0,5 = la de ahora), para cine y warp.
   // Mientras el motor no la tenga, el REGULATOR sigue escalando el crucero del warp desde travel() (el apaño de antes).
   applySpeed() { if (this.P && typeof fvPilotSetSpeed === "function") { try { fvPilotSetSpeed(this.P, this.warpPower); } catch (e) { fvLog("fvPilotSetSpeed: " + e); } } }
   // (5-nov) LA CRUCETA: pulsar una flecha = girar la mirada hacia ese lado (clic = un paso, mantener = continuo); soltar la suelta
   padPress(h) {
      // (6-nov, punto 3 de Nino) el centro de la cruceta FRENA: para el tour, la ruta y el vuelo; la frenada la escala el REGULATOR
      if (h === "padHub" && this.P && typeof fvPilotBrake === "function" && typeof FV_PILOT !== "undefined" && FV_PILOT.BRAKE && FV_PILOT.BRAKE.ON) {
         this.padRelease(true); this.tour = null; this.lookTo = null; this.searchFocus(false);
         if (this.route && this.route.play) { try { this.route.stopFly("brake"); } catch (e) { fvLog("route.stopFly: " + e); } }
         try { fvPilotBrake(this.P); } catch (e) { fvLog("fvPilotBrake: " + e); }
         if (this.cockpit) this.cockpit.hubT = fvNowMs() / 1000;
         fvLog("brake: hub pressed");
         return true;
      }
      var d = (typeof FV_PAD_DIR !== "undefined") ? FV_PAD_DIR[h] : null;
      if (!d || !this.P || typeof fvPilotLookPad !== "function") return false;
      this.padRelease(); this.lookTo = null; this.searchFocus(false);
      this.padHold = d; try { fvPilotLookPad(this.P, d, true); } catch (e) { fvLog("fvPilotLookPad: " + e); }
      return true;
   }
   padRelease(hard) {
      var d = this.padHold; this.padHold = null;
      if (this.P && typeof fvPilotLookPad === "function") { try { if (d) fvPilotLookPad(this.P, d, false); if (hard && typeof fvPilotLookPadRelease === "function") fvPilotLookPadRelease(this.P); } catch (e) {} }
   }
   stripPress(x, y) {
      if (this.recLocked()) return;
      var h = this.cockpit.hit(x, y, this.nav.list);
      if (h !== "radioTab") this.radioNudge();                    // (P14) un clic en la franja fuera de la radio (la pestaña EMISORAS es de la radio)
      if (this.padPress(h)) { this.renderNow(); this.view.repaint(); this.strip.repaint(); return; }
      if (h === "reg") { this.regDrag = true; this.strip.cursor = new Cursor(StdCursor_ClosedHand); this.setRegFromXY(x, y); return; }
      if (this.cockpit.aetasPress && this.cockpit.aetasPress(h, x, y, this.scene)) { this.renderNow(); this.view.repaint(); this.strip.repaint(); return; }   // (I4) AETAS
      this.stripClick(x, y);
   }
   stripClick(x, y) {
      if (this.recLocked()) return null;
      var hR = this.route ? this.route.stripClick(x, y) : null;        // (pasada M) con el mapa en grande: la nave (volver) y la lista de camaras
      if (hR) return hR;
      var h = this.cockpit.hit(x, y, this.nav.list);
      // (I3) el campo del buscador (y su ×); un clic en cualquier otro sitio de la franja lo suelta (los resultados se quedan)
      if (h === "search" || h === "searchClear") { if (!(this.route && this.route.big)) { if (h === "searchClear") this.searchSet(""); this.searchFocus(true); } }
      else this.searchFocus(false);
      if (h === "modus" && !fvGwarpUi()) this.toggleStyle();
      else if (h && typeof FV_CK_LOOK_OF !== "undefined" && FV_CK_LOOK_OF[h]) this.setStarLook(FV_CK_LOOK_OF[h]);     // (5-nov) STELLAE
      else if (h === "rec") this.recToggle();
      else if (h === "recfmt") this.recFormatToggle();
      else if (h === "reccab") { this.recCab = !this.recCab; fvSetWrite("recCockpit", this.recCab ? "1" : "0"); }
      else if (h === "lang") {
         FV_LANG = (FV_LANG === "es") ? "en" : "es"; try { Settings.write(CP_SETTINGS_PREFIX + "/lang", DataType_String, FV_LANG); } catch (e) {}
         if (this.painter) this.painter.cardKey = "";
         if (this.radio) this.radio.setLang(FV_LANG);
         if (this.cockpit) { this.cockpit.stat = null; this.cockpit._zones = null; }        // (5-nov) las zonas de STELLAE dependen del idioma
         for (var i = 0; i < this.btnList.length; ++i) this.btnList[i].update();
         for (var ir = 0; this.rbtnList && ir < this.rbtnList.length; ++ir) this.rbtnList[ir].update();     // (5-nov) la columna derecha
         if (this.scene) this.refreshItems();
      }
      else if (h === "radioTab") this.radioToggle();
      // (pasada M, Nino: «clic en TABULA o PROFUNDITAS = que aparezcan en grande») antes: TABULA clic = mirar alli (queda mapLook, sin raton)
      else if (h === "map2d" || h === "map3d") { if (this.route) this.route.toggleBig(h); else if (h === "map2d") this.mapLook(x, y); }
      else if (h === "listFlip" && typeof fvE1cUiFlip === "function") { if (!(this.route && this.route.big)) fvE1cUiFlip(this); }      // (I1, 19-nov) girar la placa MIRABILIA / AENIGMATA
      else if (h && h.indexOf("list:") === 0) this.listSelect(parseInt(h.substring(5), 10));
      else if (h && h.indexOf("listGo:") === 0) this.listGo(parseInt(h.substring(7), 10));
      if (!this.shut) { this.renderNow(); this.view.repaint(); this.strip.repaint(); }
      return h;
   }
   stripDouble(x, y) {
      if (this.recLocked()) return;
      if (this.route && this.route.stripDouble(x, y)) return;         // (pasada M) doble clic en el nombre de una camara = renombrarla
      var h = this.cockpit.hit(x, y, this.nav.list);
      if (h && h.indexOf("list:") === 0) this.listGo(parseInt(h.substring(5), 10));
      else if (h === "map2d" && !this.route) this.mapGo(x, y);        // (pasada M) el primer clic ya abrio el mapa grande
   }
   stripWheel(x, y, delta) {
      if (this.recLocked()) return;
      if (this.route && this.route.stripWheel(x, y, delta)) return;   // (pasada M) la rueda en la lista de camaras
      var h = this.cockpit.hit(x, y, this.nav.list);
      if (!h || (h.indexOf("list") !== 0 && h !== "search" && h !== "searchClear")) return;
      var R = fvNavListRows(this.cockpit.listIn, this.cockpit.k), n = this.nav.list.items.length;
      this.nav.list.top = fvClamp(this.nav.list.top + (delta < 0 ? 1 : -1), 0, Math.max(0, n - R.n));
      this.setStripHover(null); this.setStripHover(h);                 // (B) la fila bajo el cursor es otra: su ayuda tambien
      this.strip.repaint();
   }
   // ---- la lista ----
   itemSel(it) {
      if (!it) return null;
      if (it.kind === "object") return { kind: "object", i: it.i };
      if (it.kind === "star") return { kind: "star", i: it.i };
      if (it.kind === "exo") return { kind: "star", i: it.star };
      if (it.kind === "nebula") return { kind: "nebula", sx: this.VW / 2, sy: this.VH / 2 };
      return null;
   }
   listSelect(n) {
      var it = this.nav.list.items[n];
      if (!it || it.noData || !this.P) return;      // (21-nov, T1-A) la fila «sin datos» no es un destino: ni se elige ni se deselecciona lo elegido
      this.tour = null;
      this.select(this.itemSel(it));                       // (punto 2) elegir, sin ficha: sale con INFO o al llegar
      // (N12) un planeta: el panel pequeño del transito y el transito dibujado sobre la estrella
      var e = this.exoOfItem(it);
      if (e) this.openExo(e);
   }
   listGo(n) {
      var it = this.nav.list.items[n];
      if (!it || it.noData || !this.P) return;
      this.listSelect(n);
      var e = this.exoOfItem(it);
      if (this.travel(this.P.sel) && e) this.pendingExo = e;
   }
   exoOfItem(it) {
      var L = this.ui.exoList || [];
      if (it.kind === "exo") return L[it.i] || null;
      if (it.kind === "object" && this.scene.objects) {
         var o = this.scene.objects[it.i];
         for (var j = 0; j < L.length; ++j) if (o && (L[j].row.pl_name === o.name || (o.planets && o.planets.indexOf(L[j].row.pl_name) >= 0))) return L[j];
      }
      return null;
   }
   // ---- la miniatura: clic = mirar alli (con zoom si se esta en casa) · doble clic = ir a lo mas notable de ese punto ----
   mapUV(x, y) { return fvNavMapUV(this.cockpit.map2d, x, y); }
   mapLook(x, y) {
      if (!this.P || !this.scene) return false;
      var uv = this.mapUV(x, y), f = this.scene.field, N = this.scene.nebula, d = N ? N.distLy : 1000;
      var T = fvPixelPoint(this.scene, uv[0] * f.width, uv[1] * f.height, d), dir = fvNorm(fvSub(T, this.P.cam.pos));
      var fov = this.P.cam.fov; if (fvLen(this.P.cam.pos) < 1e-6) fov = Math.min(fov, 0.4 * this.P.homeFov);
      if (typeof fvPilotLookAt === "function") { try { if (fvPilotLookAt(this.P, dir, fov) !== false) return true; } catch (eL) {} }
      if (this.P.flight || this.P.orbit) fvPilotStop(this.P);
      // en la Tierra se queda en "home": la deriva viva de B (0,12° + 0,08°) se aplica en "free" y, con el campo de la foto (<1°), se comia el
      // punto pulsado (prueba N1 TABULA del 4-nov: llego a 0,12/0,33 en vez de 0,25/0,30)
      if (fvLen(this.P.cam.pos) > 1e-6) this.P.mode = "free";
      this.lookTo = { dir: dir, fov: fov };
      return true;
   }
   // el giro suave hacia lo pulsado en la miniatura (muelle exponencial de 0,35 s), y el zoom si se esta en casa
   lookStep(dt) {
      var LT = this.lookTo, P = this.P;
      if (!LT || !P) return;
      if (P.flight || P.orbit) { this.lookTo = null; return; }
      var a = 1 - Math.exp(-dt / 0.35), c = P.cam;
      c.look = fvNorm(fvLerp(c.look, LT.dir, a));
      c.fov = c.fov + (LT.fov - c.fov) * a;
      P.lookState = null;
      if (fvDot(c.look, LT.dir) > Math.cos(0.05 * FV_DEG) && Math.abs(c.fov - LT.fov) < 1e-4) { c.look = LT.dir.slice(); c.fov = LT.fov; this.lookTo = null; }
   }
   mapGo(x, y) {
      if (!this.P || !this.scene) return false;
      var uv = this.mapUV(x, y), sc = this.scene, S = sc.stars, best = null, bs = 1e9, i;
      var ph = this.built && this.built.bmps ? this.built.bmps.photo : null;
      if (sc.objects && ph) for (i = 0; i < sc.objects.length; ++i) {
         var o = sc.objects[i]; if (!o.px) continue;
         var du = o.px.x / ph.width - uv[0], dv = o.px.y / ph.height - uv[1], dd = Math.sqrt(du * du + dv * dv);
         if (dd < Math.max(0.04, (o.px.r || 0) / ph.width) && dd < bs) { bs = dd; best = { kind: "object", i: i }; }
      }
      if (!best && S) for (i = 0; i < S.n; ++i) {
         if (!S.inFrame[i] || S.q[i] > 1 || S.g[i] > 13) continue;
         var q = fvNavPhotoUV(sc, fvStarPos(sc, i)); if (!q) continue;
         var e = Math.sqrt(Math.pow(q[0] - uv[0], 2) + Math.pow(q[1] - uv[1], 2)) * (1 + 0.08 * (S.g[i] - 6));
         if (e < 0.05 && e < bs) { bs = e; best = { kind: "star", i: i }; }
      }
      if (!best) return false;
      this.select(best);
      return this.travel(this.P.sel);
   }
   // (5-nov) EL ASPECTO DE LAS ESTRELLAS (STELLAE): "gaia" | "phcol" | "phstar". La medida de la foto (fvPsEnsure, src/build/fv_ps_build.js) se
   // hace UNA vez por escena, aqui, con la placa de progreso de siempre (la de REC, sin botones); nunca al pintar. o.noSave: no escribe Settings
   // (el aspecto recordado al entrar la escena). -> el aspecto puesto (si la medida falla, "gaia" y se dice)
   setStarLook(look, o) {
      var self = this, opt = o || {};
      if (typeof FV_PS === "undefined" || !FV_PS.ON || !fvPsIsLook(look)) look = "gaia";
      this.starLook = look; if (!opt.noSave) fvSetWrite("starLook", look);
      if (!this.painter || !this.built) return look;
      var ps = null;
      // (B1) COLOR ya no se mide (es el color de la foto que trae la escena): solo FOTO (los recortes) pide la medida; sin la bandera, los dos como antes
      if (look === "phstar" || (look === "phcol" && FV_PS.GAIA_TEMP !== true)) {
         ps = this.built.ps;
         if (!ps || !ps.ok) {
            var bg = new Bitmap(this.frame), VW = this.VW, VH = this.VH, t0 = Date.now();
            this.lookBusy = true; this.strip.repaint();
            var prog = function(fr) {
               self.ui.notice = { kind: "lookprog", title: fvTx("look.title"), lines: [fvTx("look.line")], progress: fr };
               var g = new Graphics(self.frame), kn = fvHudK(VW);
               try { g.drawBitmap(0, 0, bg); if (Math.abs(kn - 1) > 1e-6) g.scaleTransformation(kn, kn); fvNoticePaint(g, self.painter, VW / kn, VH / kn, self.ui.notice); } finally { g.end(); }
               self.painter.hits = [];
               self.view.repaint(); self.strip.repaint();
               if (FV_PAINTING === 0) { try { CoreApplication.processEvents(); } catch (eP) {} }
               return self.closing !== true;
            };
            prog(0);
            try { ps = fvPsEnsure(this.built, { onProgress: prog }); } catch (eM) { ps = { ok: false, why: String(eM) }; }
            this.ui.notice = null; this.lookBusy = false;
            fvLog("star look: measured in " + (Date.now() - t0) + " ms" + (ps.ok ? "" : " · FAILED " + ps.why));
         }
         if (!ps || !ps.ok) { if (this.P) this.ui.caption = { text: fvTx("look.fail"), t0: this.P.t, dur: 3.0 }; look = "gaia"; this.starLook = "gaia"; }
      }
      var got = this.painter.setStarLook(look, ps);
      fvLog("star look: " + got + (ps && ps.ok ? " (" + ps.nCol + " photo colours, " + ps.nSpr + " cut-outs, " + ps.engine.label + ")" : ""));
      if (this.P) { this.renderNow(); this.view.repaint(); }
      this.strip.repaint();
      return got;
   }
   toggleStyle() {
      this.style = (this.style === "spectacular") ? "cine" : "spectacular";
      if (this.P) fvPilotSetStyle(this.P, this.style);
      try { Settings.write(CP_SETTINGS_PREFIX + "/style", DataType_String, this.style); } catch (e) {}
   }
   // (N3) VISTA INICIAL: el vuelo suave de vuelta a la Tierra, viendo la foto (no un salto)
   // (I5) doble clic en la vista (pixeles del fotograma): lo que hay debajo (fvPilotPickAt: objetos, estrellas, la nebulosa) se elige y se viaja
   // alli con VIAJAR; en el vacio, nada. -> la seleccion o null
   doubleClick(fx, fy) {
      if (this.P && this.hitAt(fx, fy) === "nm-photo") { this.goPhoto(); return null; }     // (20-nov, E-nav) el rotulo TU FOTO: volver volando a la foto (el clic ya lo habra lanzado; en vuelo no relanza)
      if (!this.P || this.P.flight) return null;                       // en pleno vuelo, nada (como VIAJAR, que no relanza a mitad)
      if (this.hr) return null;                                        // (I2) con el diagrama HR no se viaja con doble clic
      var sel = fvPilotPickAt(this.P, fx, fy, 24);
      // (6-nov, LOS DOS MODOS) en el Espacio, doble clic en el cielo (sin nada debajo) = volver a casa (y al modo Foto)
      if (!sel && typeof fvNmMode === "function" && fvNmMode(this.P) === "space") { this.goHome(); return null; }
      if (!sel) return null;
      this.select(sel); this.tour = null; this.travel(this.P.sel || sel);
      return sel;
   }
   // (20-nov, E-nav; Nino: «No hacen nada si les hago doble clic») el rotulo TU FOTO del borde (marcador de Espacio / ayuda del vuelo a mano): clic o doble clic = volar
   // a la foto, al protagonista (fvNmPhotoSel), con el vuelo de siempre de VIAJAR (travel: LABORATORIO o piloto clasico, y de vuelta a Foto al llegar). -> true si arranco
   goPhoto() {
      var P = this.P; if (!P || P.flight || this.hr || this.recLocked() || typeof fvNmPhotoSel !== "function") return false;
      if (typeof FV_NMX !== "undefined" && FV_NMX.PHOTO_GO !== true) return false;
      var sel = fvNmPhotoSel(this.scene); if (!sel) return false;
      if (sel.kind === "nebula") { sel.sx = this.VW / 2; sel.sy = this.VH / 2; }
      this.tour = null; this.select(sel);
      var ok = this.travel(this.P.sel || sel);
      fvLog("nav: TU FOTO marker -> fly to " + sel.kind + (sel.i !== undefined ? " " + sel.i : "") + ": " + (ok ? "started" : "not started"));
      return ok;
   }
   goHome() { if (!this.P) return; this.tour = null; this.lookTo = null; this.P.sel = null; this.ui.exo = null; this.ui.cardClosed = false; this.reopenCard = false; fvPilotFly(this.P, "home", null); }
   // (F4b, CPD 5.8) EXPORTAR EL VUELO PARA EL NAVEGADOR: fvExportScene (src/export) en <carpeta elegida y recordada>/FieldVoyager_<objeto>/
   // y una placa con la ruta y «abre index.html con Chrome o Edge». PixInsight NO lanza el navegador (FV_LAUNCH_BROWSER, F4-D1); la
   // placa puede abrir la CARPETA con el gestor de archivos (utilidad del sistema, 5.3 c) si el usuario lo pulsa. o = { dir, force }
   exportFlight(o) {
      o = o || {};
      if (typeof fvExportScene !== "function" || !this.built) return null;
      var base = o.dir || fvPickDir("exportDir", "FieldVoyager: folder to export the flight · carpeta para exportar el vuelo", o.force === true);
      if (!base) { if (this.P) this.ui.caption = { text: fvTx("ex.nodir"), t0: this.P.t, dur: 2.2 }; return null; }
      var N = this.scene.nebula, nm = String((N && (N.id || N.name)) || "scene").replace(/[^A-Za-z0-9_-]+/g, "_").replace(/^_+|_+$/g, "") || "scene";
      var dir = base + "/FieldVoyager_" + nm, ex = null, r;
      // (nA2, E1) la vista de PixInsight: el exportador rehace la foto y la foto sin estrellas a resolucion completa (antes, la de trabajo de 2048)
      try { ex = fvExportScene(this.built, dir, { view: this.view0, starLook: this.painter ? this.painter.look : this.starLook }); } catch (eW) { ex = { ok: false, why: String(eW) }; }
      r = { ok: !!ex.ok, why: ex.why || "", export: ex, dir: dir, url: ex.ok ? fvFileUrl(ex.index) : "" };
      if (ex.ok && FV_LAUNCH_BROWSER === true && typeof cshSystemBrowser === "function") r.launch = cshSystemBrowser(ex.index, { dry: o.dry === true });
      fvLog("export flight: " + (r.ok ? "ok · " + ex.index + " · " + Math.round((ex.bytes || 0) / 1048576 * 10) / 10 + " MiB · " + ex.ms + " ms" : "FAILED · " + r.why));
      if (this.P) this.ui.caption = { text: fvTx(r.ok ? "cap.web" : "cap.webFail"), t0: this.P.t, dur: 2.2 };
      this.ui.notice = r.ok ? { kind: "export", title: fvTx("ex.title"), path: ex.index, lines: [fvTx("ex.open")], buttons: ["openBrowser", "openDir", "changeDir"], dir: dir }
                            : { kind: "export", title: fvTx("ex.fail", { why: r.why }), lines: [], buttons: ["changeDir"], dir: base };
      this.lastWeb = r;
      return r;
   }
   // (punto 6 de Nino) «Abrir en el navegador»: UNA accion del usuario (el boton del aviso) abre el index.html exportado con el navegador del
   // sistema (cshSystemBrowser de CabraShared: rundll32 url.dll en Windows, /usr/bin/open en macOS, xdg-open en Linux; sin shell). Ayuda y
   // tooltip lo dicen («abre el navegador del sistema»). Nunca se lanza solo (FV_LAUNCH_BROWSER sigue en false).
   launchBrowser() {
      var r = this.lastWeb, res;
      if (!r || !r.ok || !r.export || !r.export.index) { res = { ok: false, why: "nothing exported yet" }; }
      else res = fvOpenIndexInBrowser(r.export.index);
      this.lastBrowser = res;
      if (this.P) this.ui.caption = { text: fvTx(res.ok ? "cap.browser" : "cap.browserFail"), t0: this.P.t, dur: 2.2 };
      return res;
   }
   // (Nino, 4-nov: «cuando pulso browser me pone carpeta donde exportar el vuelo cuando deberia aparecer el explorador») EL BOTON NAVEGADOR:
   // un clic = el visor abierto. Exporta SIN preguntar (la carpeta recordada si la hay; si no, la temporal del sistema, que se reescribe) y
   // abre index.html con el navegador del sistema: es la accion que el usuario acaba de pedir con su clic (CPD 5.3; la ayuda lo dice).
   // Elegir otra carpeta sigue en el aviso («cambiar carpeta»). exportFlight solo (sin este boton) sigue sin abrir nada.
   browserNow(opts) {
      var o = opts || {}, rem = fvSetRead("exportDir", "").split("\\").join("/");
      var base = o.dir || ((rem && File.directoryExists(rem)) ? rem : fvExportDefaultDir().replace(/\/[^\/]*$/, ""));
      var r = this.exportFlight({ dir: base, dry: o.dry });
      if (r && r.ok) r.browser = this.launchBrowser();
      return r;
   }
   // (F2/F3, las pruebas de antes) { dry } escribe en la carpeta temporal sin preguntar
   openWeb(opts) { var o = opts || {}; return this.exportFlight({ dir: o.dir || (o.dry ? fvExportDefaultDir().replace(/\/[^\/]*$/, "") : undefined), dry: o.dry }); }
   changeDir(kind) {
      if (kind === "export") return this.exportFlight({ force: true });
      if (kind === "photo" && typeof fvRbChangeDir === "function") return fvRbChangeDir(this);     // (5-nov) la FOTO de la columna derecha
      var d = fvPickDir("recDir", "FieldVoyager: folder for the videos · carpeta para los vídeos", true);
      if (d && this.ui.notice) { this.ui.notice.dir = d; this.ui.notice.lines = [fvTx("rec.next", { d: d })]; }
      return d;
   }
   toggleMw() { this.mwOn = !this.mwOn; if (this.painter) this.painter.mwOn = this.mwOn; fvSetWrite("milkyway", this.mwOn ? "1" : "0"); }
   // ---- (F4b) REC ----
   recFormatToggle() {
      if (typeof cshFfmpegSetMode !== "function") return;
      if (fvRecFormat() === "mp4") { if (FV_REMEMBER) cshFfmpegSetMode(CP_SETTINGS_PREFIX, "off"); return; }
      var cur = cshFfmpegManualPath(CP_SETTINGS_PREFIX), p = (cur && File.exists(cur)) ? cur : cshFfmpegPick(CP_SETTINGS_PREFIX, cur);
      if (!p) return;
      if (FV_REMEMBER) { cshFfmpegSetManualPath(CP_SETTINGS_PREFIX, p); cshFfmpegSetMode(CP_SETTINGS_PREFIX, "manual"); }
   }
   // (nA2, E7; Nino: «cuando este renderizando el video, que no se pueda hacer nada mas, porque si no la pantalla se vuelve loca») MIENTRAS SE PINTA
   // EL VIDEO la nave queda inerte: raton, rueda, teclas, franja, botonera, reloj y repintado de la pantalla no hacen nada; solo vive CANCELAR
   // (boton del aviso, o Esc). La causa de que se volviera loca: fvRecRender bombea eventos entre fotogramas (CoreApplication.processEvents) y por ahi
   // entraban el temporizador (tick -> renderNow pisaba el aviso y compartia el pintor con el video), el raton (movia la camara en vivo) y los botones.
   // FV_REC_LOCK = false (en fv_rec.js) es el CONTROL EN ROJO de las pruebas.
   recLocked() { return FV_REC_LOCK !== false && !!this.recBusy; }
   // un clic con el video pintandose: solo cuenta el boton CANCELAR del aviso (sus zonas las pone recRender en painter.hits)
   recLockedClick(x, y) {
      var f = this.toFrame(x, y), H = (this.painter && this.painter.hits) || [];
      for (var i = 0; i < H.length; ++i) { var h = H[i]; if (h.id === "notice-recCancel" && f[0] >= h.x0 && f[0] <= h.x1 && f[1] >= h.y0 && f[1] <= h.y1) { this.recCancelNow("button"); return true; } }
      return false;
   }
   recCancelNow(why) { if (!this.recBusy) return false; this.recCancel = true; fvLog("REC: cancel requested (" + why + ")"); return true; }
   recToggle(o) {
      if (!this.P || this.recBusy) return null;
      if (!this.rec) { this.rec = { t0: this.P.t, keys: [fvRecSnap(this)] }; fvLog("REC: recording the flight script"); return null; }
      var rec = this.rec; this.rec = null; rec.t1 = this.P.t; rec.keys.push(fvRecSnap(this));
      return this.recRender(rec, o || {});
   }
   // o = { dir, cockpit, ffmpeg, fps, W, H, saveFrames, savePrefix } (pruebas; en la nave, lo recordado)
   recRender(rec, o) {
      var self = this, P = this.P, VW = this.VW, VH = this.VH;
      if (rec.t1 - rec.t0 < 1 / FV_REC.FPS) { if (P) this.ui.caption = { text: fvTx("rec.short"), t0: P.t, dur: 2.0 }; return null; }
      var dir = o.dir || fvPickDir("recDir", "FieldVoyager: folder for the videos · carpeta para los vídeos");
      if (!dir) { if (P) this.ui.caption = { text: fvTx("rec.nodir"), t0: P.t, dur: 2.0 }; return null; }
      var W = o.W || FV_REC.W, H = o.H || FV_REC.H, fps = o.fps || FV_REC.FPS, bg = new Bitmap(this.frame);
      this.recBusy = { frac: 0 }; this.recCancel = false;
      // (nA2, E7) la nave se bloquea: sueltas las teclas del vuelo libre, sin arrastre ni mirada en curso, cursor de espera
      this.releaseKeys("rec lock"); this.drag = null; this.lookTo = null; this.regDrag = false;
      if (P && typeof fvPilotMouse === "function") { try { fvPilotMouse(P, 0, 0, 0); } catch (eLk) {} }
      try { if (typeof StdCursor_Wait !== "undefined") { this.view.cursor = new Cursor(StdCursor_Wait); this.strip.cursor = new Cursor(StdCursor_Wait); } } catch (eCu) {}
      this.syncButtons();
      // el progreso: sobre una copia del ultimo fotograma (no se vuela mientras), la placa con su barra, siempre en el mismo sitio
      function prog(n, N, phase) {
         self.recBusy.frac = n / N;
         self.ui.notice = { kind: "recprog", title: fvTx("rec.title"), lines: [phase === "mp4" ? fvTx("rec.mp4") : fvTx("rec.frame", { n: n, N: N, w: W, h: H, fps: fps }), fvTx("rec.locked")], progress: n / N, buttons: ["recCancel"] };
         var g = new Graphics(self.frame), kn = fvHudK(VW);
         // (nA2, E7) las zonas pulsables son SOLO las del aviso (las del fotograma que acaba de pintar el video ya no cuentan): en px de la pantalla de la nave
         self.painter.hits = [];
         try { g.drawBitmap(0, 0, bg); if (Math.abs(kn - 1) > 1e-6) g.scaleTransformation(kn, kn); fvNoticePaint(g, self.painter, VW / kn, VH / kn, self.ui.notice); } finally { g.end(); }
         if (Math.abs(kn - 1) > 1e-6) for (var ih = 0; ih < self.painter.hits.length; ++ih) { var hh = self.painter.hits[ih]; hh.x0 *= kn; hh.y0 *= kn; hh.x1 *= kn; hh.y1 *= kn; }
         self.view.repaint(); self.strip.repaint();
         if (FV_PAINTING === 0) { try { CoreApplication.processEvents(); } catch (eP) {} }
         return self.closing !== true && self.recCancel !== true;
      }
      var N0 = Math.max(1, Math.round((rec.t1 - rec.t0) * fps));
      prog(0, N0, "render");                                        // (nA2, E7) el aviso con CANCELAR sale ya, no tras el primer fotograma
      var r = fvRecRender(this, rec, { dir: dir, cockpit: (o.cockpit !== undefined) ? o.cockpit : this.recCab, ffmpeg: o.ffmpeg, fps: fps, W: W, H: H, saveFrames: o.saveFrames, savePrefix: o.savePrefix, name: o.name, onProgress: prog });
      this.recBusy = null;
      try { this.view.cursor = new Cursor(StdCursor_Cross); this.strip.cursor = new Cursor(StdCursor_Arrow); } catch (eCu2) {}
      var wasCancel = (this.recCancel === true && !r.ok); this.recCancel = false;
      this.syncButtons();
      if (this.shut) return r;
      if (wasCancel) {           // (nA2, E7) cancelado por el usuario: no es un fallo, ni queda aviso de error
         this.ui.notice = null; if (this.P) this.ui.caption = { text: fvTx("rec.cancelled"), t0: this.P.t, dur: 2.4 };
         this.lastRec = r; this.lastTick = fvNowMs(); this.renderNow(); this.view.repaint(); this.strip.repaint();
         if (this.closeAfterRec && !this.shut) { this.closeAfterRec = false; this.shutdown("close after video"); try { this.cancel(); } catch (eX2) {} }
         return r;
      }
      var fmt = (r.format === "mp4") ? "MP4 H.264 (ffmpeg)" : "AVI Motion JPEG";
      this.ui.notice = r.ok ? { kind: "rec", title: fvTx("rec.done"), path: r.file, lines: [fvTx("rec.info", { n: r.frames, w: W, h: H, fps: fps, fmt: fmt })].concat(r.mp4Why ? [fvTx("rec.mp4fail", { why: r.mp4Why })] : []), buttons: ["openDir", "changeDir"], dir: dir }
                            : { kind: "rec", title: fvTx("rec.fail", { why: r.why }), lines: [], buttons: ["changeDir"], dir: dir };
      this.lastRec = r; this.lastTick = fvNowMs();
      this.renderNow(); this.view.repaint(); this.strip.repaint();
      // (H-1) el aspa se pulso mientras se pintaba el video: ahora que esta entero, se cierra
      if (this.closeAfterRec && !this.shut) { this.closeAfterRec = false; this.shutdown("close after video"); try { this.cancel(); } catch (eX) {} }
      return r;
   }
   travel(sel, styleOverride) {
      var P = this.P;
      if (!sel) return false;
      // (N4; punto 2 de Nino) la ficha del destino se abre SIEMPRE al llegar (2 s despues), la hubiese abierto el usuario o no; durante el
      // viaje esta oculta. Si el usuario la cierra con × o Esc en pleno viaje, no vuelve (closeCard apaga reopenCard)
      if (!P.sel || P.sel.kind !== sel.kind || P.sel.i !== sel.i) { sel.t0 = P.t; P.sel = sel; }
      this.lookTo = null;
      if (styleOverride) fvPilotSetStyle(P, styleOverride);
      var ok = fvPilotFly(P, "travel", sel);
      if (styleOverride) fvPilotSetStyle(P, this.style);
      if (!ok && sel.kind === "object") { this.ui.caption = { text: fvTx("cap.objNoFly"), t0: P.t, dur: 2.2 }; return false; }
      if (ok) {
         this.ui.exo = null;
         // (5-nov, Nino: «justo al empezar el viaje ve pidiendo toda la informacion de la estrella; asi, al llegar la puedes mostrar») la
         // ficha del destino pide ya su espectro XP, su quimica y su metalicidad (fv_card_sci.js; FV_CSCI_PREFETCH = false: como antes)
         if (typeof fvCsciPrefetch === "function") { try { fvCsciPrefetch(this.scene, sel); } catch (eF) { fvLog("prefetch: " + eF); } }
         var fl = P.flight, spec = (fl.kind === "warp");
         // (N2) la potencia del REGULATOR: si el piloto no la lee (P.warpPower), se aplica al crucero del warp (0,5 = la de siempre)
         if (spec && !fl.powerApplied && fl.cruise && fl.prof && typeof fvWarpTable === "function" && typeof fvPilotSetSpeed !== "function" && !(typeof FV_PILOT !== "undefined" && FV_PILOT.WARP_POWER_READS)) {
            fl.cruise = fvClamp(fl.cruise * (0.55 + 0.9 * this.warpPower), 0.8, 3.8); fl.prof = fvWarpTable(fl.cruise); fl.dur = fl.pre + fl.prof.end; fl.powerApplied = true;
         }
         this.ui.hideCard = true; this.reopenCard = true; this.reopenAt = null;
         this.wasFlying = true;
         this.ui.caption = { text: spec ? fvTx("cap.punch") : fvTx((this.nEngage++ % 2) ? "cap.makeitso" : "cap.engage"), t0: P.t, dur: spec ? 1.3 : 1.6 };
      }
      return ok;
   }
   button(id) {
      if (this.recLocked()) return;
      var P = this.P;
      if (!P) { if (id === "travel") this.power(); return; }
      if (this.gal && id !== "galaxy" && typeof fvGalEnd === "function") fvGalEnd(this);   // (encargo D1) otro boton: fuera de GALAXIA
      if (this.hr && id !== "hr" && id !== "info" && typeof fvHrEnd === "function") fvHrEnd(this);   // (I2, 19-nov) otro boton (menos INFO): fuera del diagrama HR
      if (id === "galaxy") { if (typeof fvGalToggle === "function") fvGalToggle(this); }
      else if (id === "hr") { if (typeof fvHrToggle === "function") fvHrToggle(this); }
      else if (id === "info") this.infoToggle();
      else if (id === "start") this.goHome();
      else if (id === "travel" && P.sel) { this.tour = null; this.travel(P.sel); }
      else if (id === "warp" && P.sel) this.travel(P.sel, "spectacular");           // (F1: las pruebas siguen pidiendo «warp» e «ir a»)
      else if (id === "goto" && P.sel) this.travel(P.sel, "cine");
      else if (id === "tour") { if (this.tour) this.tour = null; else this.startTour(); }
      else if (id === "exo") this.exoButton();
      else if (id === "web") this.browserNow();
      this.syncButtons();
   }
   // ---- tour ----
   startTour() {
      var sc = this.scene, hosts = this.ui.exoList.map(function(e) { return e.star; });
      var list = fvTourPick(sc, function(i) { var o = fvStarInfo(sc, i); return o ? { radius: o.radius, teff: o.teff } : null; }, hosts, 5);
      if (!list.length) return;
      this.tour = { list: list, i: -1, state: "next", since: 0 };
      fvLog("tour: " + JSON.stringify(list));
   }
   tourStep() {
      var T = this.tour, P = this.P;
      if (!T || P.flight) return;
      if (T.state === "fly") { T.state = "hold"; T.since = P.t; T.lastT = P.t; T.dwell = (typeof fvTourDwellNew === "function") ? fvTourDwellNew() : null; if (P.sel) P.sel.t0 = P.t; return; }
      // (6-nov, FV_TOUR_READ, src/engine/fv_tour_plan.js) la espera empieza con la ficha COMPLETA y dura lo que se tarda en leerla; el cursor
      // sobre la ficha la para. Lo de antes (espera fija desde la llegada) con FV_TOUR_READ.ON false
      // (12-nov, R7) con FV_TOUR_READ.SHORT: el reloj empieza cuando la ficha EMPIEZA a escribirse; con el cursor sobre la ficha o MÁS abierto NO se va
      // y, al soltarlos, quedan GRACE_S; la PAUSA del usuario (T.paused) para el reloj. tourBarSync() lo pinta (barra del tour)
      if (T.state === "hold" && T.dwell && typeof FV_TOUR_READ !== "undefined" && FV_TOUR_READ.ON) {
         var dtT = Math.max(0, P.t - (T.lastT === undefined ? P.t : T.lastT)), cr = this.painter ? this.painter.cardRead : null; T.lastT = P.t;
         var crOk = !!(cr && P.sel && cr.sel === P.sel.kind + ":" + P.sel.i && P.t - cr.t <= 0.25);
         var hv = this.ui.hover, onCard = !!(hv && String(hv).indexOf("card") === 0), more = !!(this.ui.cardMore && !(crOk && cr.closed));
         // (16-nov, P18; FV_TOUR_READ.SKY_CLICK) con la parada ya en espera, P.sel vacio = el usuario hizo clic en cielo vacio: la ficha no se pinta mas y sin esto
         // crOk quedaba falso para siempre y la parada esperaba hasta HARD_S. Cuenta como ficha cerrada por el usuario (la misma regla que la web: fwTourStep)
         var skyClr = !!(FV_TOUR_READ.SKY_CLICK && !P.sel);
         var stR = { complete: skyClr || (crOk && (cr.closed || (cr.typed && cr.data))), words: (crOk && !cr.closed) ? cr.words : 0, paused: onCard || !!T.paused, hold: !!T.paused,
                     started: skyClr || (crOk && (cr.closed || !!cr.started)), busy: onCard || more, more: more };
         T.busy = onCard || more;
         if (!fvTourDwellStep(T.dwell, dtT, stR)) return;
         fvLog("tour: stop " + (T.i + 1) + " read " + T.dwell.readS.toFixed(2) + " s of " + T.dwell.needS.toFixed(2) + " (" + T.dwell.words + " words) after waiting " + T.dwell.waitS.toFixed(2) + " s for the card (" + T.dwell.readyWhy + "), paused " + T.dwell.pausedS.toFixed(2) + " s");
      }
      else if (T.state === "hold" && T.paused) return;
      else if (T.state === "hold" && P.t - T.since < (FV_UI.TOUR_HOLD[P.style] || 5)) return;
      this.tourGoTo(T.i + 1);
   }
   // (12-nov, R7) ir a la parada idx (0-based) YA: lo usan el paso natural del tour, SIGUIENTE y ANTERIOR (mismo camino: no hay dos). Pasada la
   // ultima, el tour acaba. En pleno vuelo tambien vale (el viaje nuevo sustituye al que llevaba la nave)
   tourGoTo(idx) {
      var T = this.tour, P = this.P;
      if (!T || !P) return false;
      if (idx >= T.list.length) { fvLog("tour: end after " + T.list.length + " stops"); this.tour = null; this.ui.tourBar = null; return false; }
      idx = Math.max(0, idx);
      T.i = idx; T.paused = false; T.busy = false; T.dwell = null;
      var it = T.list[T.i], sel = (it.kind === "star") ? { kind: "star", i: it.i, t0: P.t } : (it.kind === "object" ? { kind: "object", i: it.i, t0: P.t } : { kind: "nebula", sx: this.VW / 2, sy: this.VH / 2, t0: P.t });   // (E2b) object: el protagonista de la foto, ultima parada
      P.sel = sel; this.ui.cardMore = false; this.ui.cardClosed = false;
      // (6-nov, LOS DOS MODOS) el tour se queda en el modo Foto: lo de detras de la nebulosa se mira a traves de ella (nota de profundidad)
      P.navStayFoto = true; var okT = this.travel(sel); P.navStayFoto = false;
      if (okT) { T.state = "fly"; this.ui.caption = { text: fvTx("cap.tour", { i: T.i + 1, n: T.list.length, why: fvTx("why." + it.why) }), t0: P.t, dur: 2.4 }; }
      else { T.state = "hold"; T.since = P.t; T.lastT = P.t; T.dwell = (typeof fvTourDwellNew === "function") ? fvTourDwellNew() : null; if (T.dwell) T.dwell.done = true; }
      return okT;
   }
   // (12-nov, R7) los mandos del tour (la barra de la pantalla, las teclas , . B): siguiente, anterior y pausa. -> true si hubo tour
   tourNext() { var T = this.tour; if (!T || !this.P || this.recLocked()) return false; fvLog("tour: next (from stop " + (T.i + 1) + ")"); this.tourGoTo(T.i + 1); this.tourBarSync(); this.syncButtons(); return true; }
   tourPrev() { var T = this.tour; if (!T || !this.P || this.recLocked()) return false; fvLog("tour: previous (from stop " + (T.i + 1) + ")"); this.tourGoTo(Math.max(0, T.i - 1)); this.tourBarSync(); return true; }
   tourPause() { var T = this.tour; if (!T || !this.P || this.recLocked()) return false; T.paused = !T.paused; fvLog("tour: " + (T.paused ? "paused" : "resumed") + " at stop " + (T.i + 1)); this.tourBarSync(); return true; }
   // (12-nov, R7) lo que pinta la barra del tour (fv_hud.js fvTourBarPaint): ui.tourBar = { i, n, phase, left, frac, paused, last, t }; null sin tour.
   // phase: "fly" (en viaje) · "scan" (ha llegado: la ficha se esta abriendo) · "read" (cuenta atras a la siguiente) · "busy" (el usuario esta con
   // la ficha: la espera se aguanta) · "paused" (pausa suya)
   tourBarSync() {
      var T = this.tour, P = this.P;
      if (!T || !P) { this.ui.tourBar = null; return; }
      var B = { i: Math.max(1, T.i + 1), n: T.list.length, phase: "fly", left: null, frac: 0, paused: !!T.paused, last: (T.i >= T.list.length - 1), t: P.t }, D = T.dwell;
      var holdS = FV_UI.TOUR_HOLD[P.style] || 5;
      if (P.flight || T.state !== "hold") B.phase = "fly";
      else if (T.paused) B.phase = "paused";
      else if (T.busy) B.phase = "busy";
      else if (D && D.ready && D.left !== null) B.phase = "read";
      else B.phase = "scan";
      if (D && D.ready) { B.left = D.left; B.frac = D.frac; }
      else if (T.state === "hold" && !D) { B.frac = fvClamp((P.t - T.since) / holdS, 0, 1); B.left = Math.max(0, holdS - (P.t - T.since)); if (!T.paused) B.phase = "read"; }
      this.ui.tourBar = B;
   }
   // ---- exoplaneta (N12: sin boton; la tecla X y las pruebas de antes siguen llegando aqui) ----
   exoButton() {
      var L = this.ui.exoList, P = this.P;
      if (!L.length) return;
      if (this.ui.exo) { this.ui.exo = null; return; }
      var e = L[0];
      if (P.arrivedAt && P.arrivedAt.kind === "star" && P.arrivedAt.i === e.star && !P.flight) { this.openExo(e); return; }
      P.sel = { kind: "star", i: e.star, t0: P.t }; this.tour = null;
      if (this.travel(P.sel)) this.pendingExo = e;
   }
   openExo(e) {
      var X = fvExoPrepare(e.row);
      if (!X) { fvLog("exoplanet " + e.row.pl_name + ": not enough data to draw the transit"); return; }
      X.t0 = this.P.t; X.star = e.star; X.demo = (e.match !== "gaia-id" && e.match !== "position"); this.ui.exo = X;   // (F4b) fila inyectada = DEMO en pantalla
      this.ui.exoIdx = (this.ui.exoList || []).indexOf(e);
   }
   exoTip() {
      var b = this.built, q = (b && b.exo) ? b.exo.query : null, L = this.ui.exoList;
      if (L.length) return fvTx("exo.go", { p: L.map(function(e) { return e.row.pl_name; }).join(", ") });
      if (!q) return fvTx("exo.off");
      if (q.code === "offline") return fvTx("exo.off");
      if (!q.ok) return fvTx("exo.net");
      return fvTx("exo.none", { n: q.rows.length });
   }
   syncButtons() {
      var P = this.P, b = this.btns, on = !!P;
      if (typeof fvRbSync === "function") fvRbSync(this);                       // (5-nov) la columna derecha
      if (this.recLocked()) { for (var idL in b) b[idL].setStateFV("normal", false); return; }     // (nA2, E7) botonera apagada
      if (!on) { for (var id in b) b[id].setStateFV("normal", false); return; }
      var hasSel = !!P.sel, flying = !!P.flight;
      b.start.setStateFV("normal", (fvLen(P.cam.pos) > 1e-6 || Math.abs(P.cam.fov - P.homeFov) > 1e-4 || fvDot(fvNorm(P.cam.look), [0, 0, 1]) < 0.99999) && !(flying && P.flight.kind === "home"));
      this.infoOn = this.cardShown();                                  // INFO encendido = la ficha esta a la vista
      b.info.setStateFV(this.infoOn ? "on" : "normal", true);
      b.travel.setStateFV(flying && (P.flight.kind === "warp" || P.flight.kind === "cine") ? "on" : "normal", hasSel && !flying);
      b.tour.setStateFV(this.tour ? "on" : "normal", true);
      if (b.galaxy) b.galaxy.setStateFV(this.gal ? "on" : "normal", !!this.gal || (!flying && !!(this.scene && this.scene.galaxy)));   // (encargo D1)
      if (b.hr) b.hr.setStateFV(this.hr ? "on" : "normal", !!this.hr || (!flying && !this.gal && typeof fvHrAvailable === "function" && fvHrAvailable(this)));   // (I2, 19-nov) el diagrama HR
      var web = (typeof fvExportScene === "function");
      b.web.setStateFV("normal", web);
      b.web.setTipFV(fvBtnTip({ en: FV_TX.en["btn.web"], es: FV_TX.es["btn.web"], tipEn: FV_TX.en[web ? "tip.web" : "tip.webSoon"], tipEs: FV_TX.es[web ? "tip.web" : "tip.webSoon"] }));
   }
}
