// ============================================================================
// FieldVoyager/src/ui/fv_e1_ui.js — I4 (20-nov-2026): lo que se VE y se toca de E1-01, E1-12, E1-13 y E1-14 en PixInsight (docs/ideas-enganche-19nov.md).
// El calculo es de src/engine/fv_e1.js (puro, el mismo que usa el visor web: web/fw_e1.js). Aqui solo hay pintura, raton y enganches al dialogo.
// ----------------------------------------------------------------------------
//  E1-01 QUAESTIO: durante la carga, una placa grabada con UNA pregunta sobre la foto y la escala logaritmica (10 a.l. … 100 000) donde se contesta con un
//        clic o arrastrando; es opcional y el arranque sigue igual. Se crea en cuanto fvBuildScene tiene las distancias afinadas (gancho FV_E1_HOOK, tras el
//        paso «range»). Al acabar la carga se REVELA la medida de Gaia (la aguja bermellon junto a la tuya) y el boton «IR ALLI» viaja a esa estrella: la
//        pregunta desemboca en el viaje. Sin dato (pocas estrellas medidas, dudosas, sin distancia) NO hay placa. Sin nota ni puntos.
//        La placa va bajo la placa del arranque (en el margen de la ventana) o, si no cabe, encima de su fila de abajo; tras el arranque queda arriba al
//        centro de la cabina HUD_S segundos (o hasta el ×, o hasta ir allí).
//  E1-12 el balanceo de paralaje: al acabar la placa del arranque, SOLO la primera vez con cada foto (recordado por la firma de la foto), la camara se
//        desplaza de lado y vuelve (fvE1sOffset) durante DUR_S s. Es solo al PINTAR (P.cam.pos se pone y se quita alrededor de painter.render): los
//        instrumentos no se mueven, la nave sigue en casa. Cualquier tecla o clic lo salta; la tecla Y lo repite desde casa.
//  E1-13 mirar a casa (RETROSPECTIO): el motor ya tenia fvPilotLookHome y fvSunPaint (Nino quito el boton el 5-nov); vuelve como boton CASA en la columna
//        derecha (catalejo) y tecla U, con la magnitud calculada con M_V,sol = 4,81 (fvE1hSun) en vez de la de la banda G de antes.
//  E1-14 silencio de llegada: al llegar a un objeto PRINCIPAL (nunca a una estrella), durante DUR_S s la radio baja a una capa y se atenua (la ficha ya
//        espera CARD_REOPEN_S = 2 s: el hueco es el mismo). Lo gobiernan duckTarget y radioLevelStep del dialogo.
// ES5.
// ============================================================================

var FV_E1_HOOK = null;     // function(stage, res): lo llama fvBuildScene tras «range» (src/build/fv_build.js); la pone el dialogo (fvE1uInit)

(function() {
   var add = {
      en: { "lab.home": "HOME", "btn.home": "Home", "tip.home": fvE1Tx("h.tip", { mv: "4.81", key: FV_E1H.KEY }, "en") },
      es: { "lab.home": "CASA", "btn.home": "Casa", "tip.home": fvE1Tx("h.tip", { mv: "4,81", key: FV_E1H.KEY }, "es") }
   };
   for (var L in add) for (var k in add[L]) if (Object.prototype.hasOwnProperty.call(add[L], k)) FV_TX[L][k] = add[L][k];
})();

// ---------------------------------------------------------------------------
// el dialogo
// ---------------------------------------------------------------------------
function fvE1uInit(D) {
   D.e1q = null; D.e1s = null; D.e1sTried = false; D.e1hush = null; D.e1tip = "";
   FV_E1_HOOK = function(stage, res) { try { fvE1qStart(D, stage, res); } catch (e) { fvLog("E1Q: error " + e); } };
}
// la firma de ESTA foto (para recordar el balanceo ya hecho)
function fvE1uSig(scene) { var f = scene.field; return Math.round(f.ra * 1e4) + "_" + Math.round(f.dec * 1e4) + "_" + Math.round(f.scaleArcsec * 1e3) + "_" + f.width + "x" + f.height; }

// ---------------------------------------------------------------------------
// E1-01 · crear, revelar, contestar
// ---------------------------------------------------------------------------
function fvE1qStart(D, stage, res) {
   if (!FV_E1Q.ON || !res || !res.stars) { D.e1q = null; return; }
   var last = fvE1uLast(), pk = fvE1qPick(fvE1qFromRes(res.stars, res.field), fvE1qOpts(last));
   if (pk.ok && FV_E1Q.VARY) fvE1uLastSet(pk.kind);
   if (!pk.ok) { D.e1q = { state: "none", why: pk.why }; fvLog("E1Q: no question (" + pk.why + ")"); return; }
   D.e1q = { Q: pk, state: "ask", guess: null, drag: false, hit: null, idx: -1, tReveal: null, closed: false, flown: false, tipOn: false };
   fvLog("E1Q: question " + pk.kind + " (last " + (last || "-") + ", fits " + (pk.fits ? pk.fits.join("/") : "-") + ") · answer " + Math.round(pk.answerLy) + " ly (± " + Math.round(pk.rel * 100) + " %) · " + pk.n + " measured stars · target Gaia " + (pk.target.id || "?"));
}
// al acabar la carga: la misma pregunta sobre la escena FINAL; si no da la misma respuesta (otro orden, otro afinado), no se revela nada
function fvE1qResolve(D) {
   var E = D.e1q;
   if (!E || E.state !== "ask" || !D.scene) return;
   var pk = fvE1qPick(fvE1qFromScene(D.scene), { kind: E.Q.kind });
   if (!pk.ok || Math.abs(pk.answerLy - E.Q.answerLy) > 0.002 * E.Q.answerLy) {
      fvLog("E1Q: the final scene does not give the asked answer (" + (pk.ok ? Math.round(pk.answerLy) + " ly vs " + Math.round(E.Q.answerLy) : pk.why) + "): no reveal");
      E.state = "none"; return;
   }
   E.Q = pk; E.idx = fvE1qFind(D.scene, pk.target); E.state = "reveal"; E.tReveal = fvNowMs();
   fvLog("E1Q: reveal · " + pk.kind + " " + Math.round(pk.answerLy) + " ly · star " + E.idx + " · you said " + (E.guess ? Math.round(E.guess) + " ly" : "nothing"));
}
// el tipo de pregunta de la ultima vez (Settings), para no repetirlo; se guarda al elegir la pregunta
function fvE1uLast() { try { return fvSetRead("e1qLast", ""); } catch (e) { return ""; } }
function fvE1uLastSet(kind) { try { fvSetWrite("e1qLast", kind); } catch (e) {} }
// la geometria de la placa en el arranque (unidades de la cabina): ARRIBA (FV_E1Q.TOP; src/engine/fv_e1.js fvE1qBox) o, sin la bandera, bajo la placa del arranque / sobre su fila de abajo
function fvE1qBootBox(W, H) {
   var plate, ship = FV_BOOT_SHIP.ON && (typeof fvBootShipManifest === "function") && !!fvBootShipManifest();
   if (ship) { var L = fvBootShipLayout(W, H); plate = { x0: L.x0, y0: L.y0, x1: L.x1, y1: L.y1 }; }
   else { var y0p = Math.round((H - 500) / 2) - 6, x0p = Math.round((W - 620) / 2); plate = { x0: x0p, y0: y0p, x1: x0p + 620, y1: y0p + 500 }; }
   var b = fvE1qBox(W, H, plate);
   return { x0: b.x0, y0: b.y0, w: b.w, h: b.h };
}
function fvE1qTxt(g, f, col, x, y, s) { g.font = f; g.pen = new Pen(col); g.drawText(x, y, s); }
// la placa: titulo + pregunta, la escala con las agujas y, abajo, la pista o la revelacion con el boton
function fvE1qPlaque(g, D, E, B, a, kb) {
   var C = FV_BOOT_COL, L = FV_LANG, rev = (E.state === "reveal"), x0 = B.x0, y0 = B.y0, w = B.w, h = B.h, op = g.opacity, i;
   g.opacity = op * a;
   g.fillRect(x0, y0, x0 + w, y0 + h, new Brush(0xff0D0A07));                 // opaca: encima de la fila de abajo de la placa no tiene que asomar su texto
   fvEngravedPanel(g, x0, y0, x0 + w, y0 + h, false);
   var fT = cpFont("display", 10, false, false, 3), fQ = cpFont("text", 12, false, true), fS = cpFont("text", 9), fD = cpFont("display", 8, false, false, 2), fR = cpFont("text", 12, false, true);
   var tt = fvE1Tx("q.title", null, L), wT = 0; g.font = fT; wT = fT.width(tt);
   fvE1qTxt(g, fT, C.gold, x0 + 22, y0 + 24, tt);
   fvE1qTxt(g, fQ, C.ivory, x0 + 22 + wT + 16, y0 + 24, cpElide(fQ, fvE1qQuestion(E.Q, L), w - 44 - wT - 16));
   fvOrnRule(g, x0 + 22, x0 + w - 22, y0 + 32, C.gold, 0.8);
   // la escala logaritmica
   var tx0 = x0 + 40, tx1 = x0 + w - 40, ty = y0 + 58, ticks = [10, 100, 1000, 10000, 100000];
   g.pen = new Pen(C.gold, 1); g.drawLine(tx0, ty, tx1, ty);
   for (i = 0; i < ticks.length; ++i) {
      var tx = tx0 + (tx1 - tx0) * fvE1qPos(ticks[i]);
      g.pen = new Pen(C.gold, 1); g.drawLine(tx, ty - 6, tx, ty + 6);
      var tl = fvE1Num(ticks[i], 0, L); g.font = fS; fvE1qTxt(g, fS, C.goldT, Math.min(tx1 + 14 - fS.width(tl), Math.max(tx0 - 14, tx - fS.width(tl) / 2)), ty + 19, tl);
   }
   for (i = 1; i < 5; ++i) for (var m = 2; m <= 9; ++m) { var v = Math.pow(10, i) * m / 10; if (v < 10 || v > 100000) continue; var tx2 = tx0 + (tx1 - tx0) * fvE1qPos(v); g.pen = new Pen(0x80C99A3A, 0.7); g.drawLine(tx2, ty - 2.5, tx2, ty + 2.5); }
   var un = fvE1Tx("q.axisNote", null, L); fvE1qTxt(g, fD, C.dim, tx1 - fD.width(un.toUpperCase()), ty - 12, un.toUpperCase());
   // la aguja del usuario (hueso, hacia abajo) y, revelada, la de Gaia (bermellon, hacia arriba)
   if (E.guess) {
      var gx = tx0 + (tx1 - tx0) * fvE1qPos(E.guess);
      g.pen = new Pen(C.ivory, 1.2); g.drawLine(gx, ty - 14, gx, ty);
      g.drawPolygon([new Point(gx - 4, ty - 14), new Point(gx + 4, ty - 14), new Point(gx, ty - 7)]);
      var gl = fvE1LyText(E.guess, L); g.font = fS; fvE1qTxt(g, fS, C.ivory, Math.min(tx1 - fS.width(gl), Math.max(tx0, gx - fS.width(gl) / 2)), ty - 18, gl);
   }
   if (rev) {
      var rx = tx0 + (tx1 - tx0) * fvE1qPos(E.Q.answerLy), x1r = tx0 + (tx1 - tx0) * fvE1qPos(E.Q.loLy || E.Q.answerLy), x2r = tx0 + (tx1 - tx0) * fvE1qPos(E.Q.hiLy || E.Q.answerLy), VER = 0xffD0603F;
      g.pen = new Pen(0xb0D0603F, 2.2); g.drawLine(x1r, ty + 3, x2r, ty + 3);                          // el margen de la medida
      g.pen = new Pen(VER, 1.6); g.drawLine(rx, ty - 9, rx, ty + 9);
      g.drawPolygon([new Point(rx - 4, ty + 15), new Point(rx + 4, ty + 15), new Point(rx, ty + 8)]);
   }
   // abajo: la pista, o lo medido y lo dicho con el boton
   var yb = y0 + 104;
   if (!rev) {
      var txt = E.guess ? fvE1Tx("q.set", { v: fvE1LyText(E.guess, L) + " " + (L === "es" ? "a. l." : "ly") }, L) : fvE1Tx("q.hint", null, L);
      fvE1qTxt(g, fR, E.guess ? C.ivory2 : C.goldT, x0 + 22, yb - 6, cpElide(fR, txt, w - 44));
      E.btn = null;
   } else {
      var ls = fvE1qRevealLines(E.Q, E.guess, L), canFly = FV_E1Q.FLY && E.idx >= 0 && !E.flown, bw = 0, bx1 = x0 + w - 22, bx0 = bx1;
      if (canFly) { var lab = fvE1Tx("q.fly", null, L), fB = cpFont("display", 10, false, false, 2); g.font = fB; bw = fB.width(lab) + 28; bx0 = bx1 - bw; E.btn = [bx0, yb - 18, bx1, yb + 10];
         g.fillRect(bx0, yb - 18, bx1, yb + 10, new Brush(0x40C99A3A)); g.pen = new Pen(C.gold, 1); g.drawRect(bx0 + 0.5, yb - 17.5, bx1 - 0.5, yb + 9.5);
         fvE1qTxt(g, fB, C.ivory, bx0 + 14, yb + 1, lab); } else E.btn = null;
      fvE1qTxt(g, fR, 0xffE08A6F, x0 + 22, yb - 6, cpElide(fR, ls[0], bx0 - x0 - 44));
      fvE1qTxt(g, fR, C.ivory2, x0 + 22, yb + 12, cpElide(fR, ls[1], bx0 - x0 - 44));
   }
   g.opacity = op;
   // las zonas de pulsacion, en pixeles del fotograma (la cabina va escalada por kb)
   E.hit = { all: [x0 * kb, y0 * kb, (x0 + w) * kb, (y0 + h) * kb], scale: [(tx0 - 12) * kb, (ty - 20) * kb, (tx1 + 12) * kb, (ty + 18) * kb], tx0: tx0 * kb, tx1: tx1 * kb,
             btn: E.btn ? [E.btn[0] * kb, E.btn[1] * kb, E.btn[2] * kb, E.btn[3] * kb] : null };
}
// lo llama renderNow (dos sitios: la espera y el fundido de la placa del arranque). a = opacidad de la placa del arranque
function fvE1qPaint(g, D, W, H, kb, a) {
   var E = D.e1q;
   if (!E || !FV_E1Q.ON || E.closed || E.state === "none") return;
   if (E.state === "ask" && D.boot.done && D.scene) fvE1qResolve(D);
   if (E.state !== "ask" && E.state !== "reveal") return;
   fvE1qPlaque(g, D, E, fvE1qBootBox(W, H), a, kb);
}
function fvE1qInBox(r, x, y) { return !!r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]; }
// ¿esta pulsacion es de la placa? (en la espera o en la placa del arranque); true = consumida
function fvE1qPress(D, x, y) {
   var E = D.e1q;
   if (!E || !E.hit || (E.state !== "ask" && E.state !== "reveal") || (D.P && D.bootFadeT0 === null)) return false;
   var f = D.toFrame(x, y);
   if (!fvE1qInBox(E.hit.all, f[0], f[1])) return false;
   if (E.state === "ask" && fvE1qInBox(E.hit.scale, f[0], f[1])) { E.drag = true; fvE1qSetGuess(D, f[0]); }
   else if (E.state === "reveal" && E.hit.btn && fvE1qInBox(E.hit.btn, f[0], f[1])) fvE1qFly(D);
   return true;
}
function fvE1qSetGuess(D, fx) {
   var E = D.e1q, u = (fx - E.hit.tx0) / Math.max(1, E.hit.tx1 - E.hit.tx0);
   E.guess = fvE1qVal(u);
   try { D.renderNow(); D.view.repaint(); } catch (e) {}
}
function fvE1qMove(D, x, y, buttons) {
   var E = D.e1q;
   if (!E || !E.drag) return false;
   if (!buttons) { E.drag = false; return false; }
   var f = D.toFrame(x, y); fvE1qSetGuess(D, f[0]);
   return true;
}
function fvE1qRelease(D) { var E = D.e1q; if (!E || !E.drag) return false; E.drag = false; return true; }
// el tooltip de la placa (texto largo: aqui, no en pantalla). -> texto | null (no esta encima)
function fvE1qHover(D, x, y) {
   var E = D.e1q;
   if (!E || !E.hit || (E.state !== "ask" && E.state !== "reveal") || E.closed || (D.P && D.bootFadeT0 === null)) return null;      // en la cabina el tooltip es el de la placa HUD (fvE1qHudTip)
   var f = D.toFrame(x, y);
   if (!fvE1qInBox(E.hit.all, f[0], f[1])) return null;
   return "<html>" + fvE1Tx("q.tip", { mr: Math.round(FV_E1Q.MAX_REL * 100) }, "en") + "<br><i>" + fvE1Tx("q.tip", { mr: Math.round(FV_E1Q.MAX_REL * 100) }, "es") + "</i></html>";
}
// el tooltip de la placa de la cabina (ids e1q…, los pone viewMove)
function fvE1qHudTip(D) {
   var E = D.e1q; if (!E || !E.Q) return "";
   var en = fvE1Tx("q.tipHud", { what: fvE1Tx("q.what." + E.Q.kind, null, "en") }, "en"), es = fvE1Tx("q.tipHud", { what: fvE1Tx("q.what." + E.Q.kind, null, "es") }, "es");
   return "<html>" + (FV_LANG === "es" ? es + "<br><i>" + en + "</i>" : en + "<br><i>" + es + "</i>") + "</html>";
}
// IR ALLI: la pregunta desemboca en el viaje (salta la placa del arranque si aun esta, elige la estrella y viaja con el MODUS actual)
function fvE1qFly(D) {
   var E = D.e1q, P = D.P;
   if (!E || E.idx < 0 || !P) return false;
   if (D.bootFadeT0 !== null) D.bootSkip();
   D.tour = null; D.lookTo = null;
   var sel = { kind: "star", i: E.idx, t0: P.t };
   D.select(sel, false);
   var ok = D.travel(sel);
   E.flown = ok; fvLog("E1Q: fly to star " + E.idx + " (" + E.Q.kind + ", " + Math.round(E.Q.answerLy) + " ly) -> " + ok);
   D.syncButtons();
   return ok;
}

// la placa de DESPUES del arranque: arriba al centro, compacta (la llama fvHudPaint con ui.e1qHud). Pulsaciones: ids e1q-fly, e1q-close, e1q
function fvE1qHudPaint(g, painter, W, H, E) {
   var C = FV_BOOT_COL, L = FV_LANG, lgR = painter && painter.legendRect, HB = fvE1qHudBox(W, lgR ? { x1: lgR[2], y1: lgR[3] } : null), w = HB.w, h = HB.h, x0 = HB.x0, y0 = HB.y0, ls = fvE1qRevealLines(E.Q, E.guess, L);
   fvEngravedPanel(g, x0, y0, x0 + w, y0 + h, false);
   var fT = cpFont("display", 10, false, false, 3), fR = cpFont("text", 12, false, true), tt = fvE1Tx("q.title", null, L);
   g.font = fT; var wT = fT.width(tt);
   fvE1qTxt(g, fT, C.gold, x0 + 22, y0 + 24, tt);
   fvE1qTxt(g, fR, 0xffE08A6F, x0 + 22 + wT + 14, y0 + 24, cpElide(fR, fvE1Tx("q.what." + E.Q.kind, null, L) + ": " + ls[0], w - 44 - wT - 14 - 24));
   fvOrnRule(g, x0 + 22, x0 + w - 22, y0 + 34, C.gold, 0.8);
   var canFly = FV_E1Q.FLY && E.idx >= 0 && !E.flown, bx0 = x0 + w - 22;
   if (canFly) { var lab = fvE1Tx("q.fly", null, L), fB = cpFont("display", 10, false, false, 2); g.font = fB; var bw = fB.width(lab) + 28; bx0 = x0 + w - 22 - bw;
      g.fillRect(bx0, y0 + 44, x0 + w - 22, y0 + 68, new Brush(0x40C99A3A)); g.pen = new Pen(C.gold, 1); g.drawRect(bx0 + 0.5, y0 + 44.5, x0 + w - 22.5, y0 + 67.5);
      fvE1qTxt(g, fB, C.ivory, bx0 + 14, y0 + 61, lab);
      painter.hits.unshift({ id: "e1q-fly", x0: bx0, y0: y0 + 44, x1: x0 + w - 22, y1: y0 + 68 }); }
   fvE1qTxt(g, fR, C.ivory2, x0 + 22, y0 + 60, cpElide(fR, ls[1], bx0 - x0 - 40));
   var cx = x0 + w - 18, cy = y0 + 18;
   g.pen = new Pen(C.goldT, 1.2); g.drawLine(cx - 4, cy - 4, cx + 4, cy + 4); g.drawLine(cx - 4, cy + 4, cx + 4, cy - 4);
   painter.hits.unshift({ id: "e1q-close", x0: cx - 10, y0: cy - 10, x1: cx + 10, y1: cy + 10 });
   painter.hits.push({ id: "e1q", x0: x0, y0: y0, x1: x0 + w, y1: y0 + h });
}
// un clic en una zona de la placa de la cabina (lo llama click() del dialogo)
function fvE1qClickId(D, id) {
   var E = D.e1q;
   if (!E) return false;
   if (id === "e1q-close") { E.closed = true; D.ui.e1qHud = null; return true; }
   if (id === "e1q-fly") { fvE1qFly(D); D.ui.e1qHud = null; return true; }
   return id === "e1q";
}

// ---------------------------------------------------------------------------
// E1-12 · balanceo de paralaje
// ---------------------------------------------------------------------------
function fvE1sStart(D, forced) {
   var P = D.P;
   if (!FV_E1S.ON || !P || !D.scene || P.flight || (D.e1s && D.e1s.on)) return false;
   if (fvLen(P.cam.pos) > 1e-6) { if (forced) D.ui.caption = { text: fvE1Tx("s.needHome", null, FV_LANG), t0: P.t, dur: 2.6 }; return false; }
   var plan = fvE1sPlan(D.scene.stars, fvE1sFov(P), D.scene.nebula ? D.scene.nebula.distLy : 0);
   if (!plan.ok) { fvLog("E1S: no sway (" + plan.why + ")"); return false; }
   D.e1s = { plan: plan, t0: fvNowMs(), on: true, u: 0 };
   D.ui.caption = { text: fvE1sText(plan, FV_LANG), t0: P.t, dur: plan.durS + 1.4 };
   fvLog("E1S: sway · amplitude " + plan.ampLy.toFixed(2) + " ly · span " + Math.round(plan.spanLy) + " ly · " + plan.n + " stars");
   return true;
}
function fvE1sCancel(D) { if (D.e1s && D.e1s.on) { D.e1s.on = false; D.e1s.u = 0; fvLog("E1S: sway skipped"); return true; } return false; }
// el desplazamiento de ESTE fotograma (a.l.) o 0; renderNow lo pone en P.cam.pos y lo quita tras pintar
function fvE1sNow(D) {
   var S = D.e1s;
   if (!S || !S.on) return 0;
   S.u = (fvNowMs() - S.t0) / 1000 / S.plan.durS;
   if (S.u >= 1) { S.on = false; S.u = 1; return 0; }
   return fvE1sOffset(S.plan, S.u);
}

// ---------------------------------------------------------------------------
// E1-14 · silencio de llegada
// ---------------------------------------------------------------------------
function fvE1tArrive(D) {
   var P = D.P;
   if (!P || !P.arrivedAt) return;
   var pl = fvE1tPlan(D.scene, P.arrivedAt, P.t);
   if (pl) { D.e1hush = pl; fvLog("E1T: arrival silence (" + P.arrivedAt.kind + " " + (P.arrivedAt.i === undefined ? "-" : P.arrivedAt.i) + ") for " + FV_E1T.DUR_S + " s"); }
}

// ---------------------------------------------------------------------------
// el reloj y las teclas
// ---------------------------------------------------------------------------
function fvE1uTick(D) {
   var P = D.P;
   if (!P || D.shut) return;
   if (D.e1hush && P.t >= D.e1hush.until) D.e1hush = null;
   // la placa de la respuesta en la cabina: desde que acaba la placa del arranque, HUD_S s
   var E = D.e1q;
   if (E && E.state === "reveal" && !E.closed && !E.flown && D.bootFadeT0 === null) {
      if (E.tHud === undefined) E.tHud = P.t;
      D.ui.e1qHud = (P.t - E.tHud < FV_E1Q.HUD_S && !P.flight) ? E : null;
   } else if (D.ui) D.ui.e1qHud = null;
   // el balanceo: una vez, al acabar la placa del arranque (o, si no hubo, al encender), primera vez con esta foto
   if (!D.e1sTried && D.bootFadeT0 === null && D.scene && !P.flight && FV_E1S.ON) {
      D.e1sTried = true;
      var sig = fvE1uSig(D.scene), seen = FV_E1S.ONCE && fvSetRead("e1s_" + sig, "") === "1";
      if (!seen) { if (fvE1sStart(D, false)) fvSetWrite("e1s_" + sig, "1"); }
      else fvLog("E1S: already shown for this photo (key " + FV_E1S.KEY + " repeats it)");
   }
}
// cualquier tecla salta el balanceo; la Y lo repite. -> true si la tecla es suya
function fvE1uKey(D, k) {
   if (fvE1sCancel(D)) return false;
   if (!D.P) return false;
   if (k === ((typeof Key_Y !== "undefined") ? Key_Y : 0x59) && FV_E1S.ON && !(D.e1s && D.e1s.on)) return fvE1sStart(D, true) || true;
   return false;
}

// ---------------------------------------------------------------------------
// E1-13 · mirar a casa: el boton CASA de la columna derecha
// ---------------------------------------------------------------------------
function fvE1hGo(D) {
   var P = D.P;
   if (!P || P.flight && P.flight.kind === "look") return false;
   if (fvLen(P.cam.pos) < 1e-6) { D.ui.caption = { text: fvE1Tx("h.athome", null, FV_LANG), t0: P.t, dur: 3.0 }; return true; }
   D.tour = null; D.lookTo = null;
   var ok = fvE1hFly(P);
   if (ok) { var r = fvE1hSun(P.cam.pos, FV_LANG); fvLog("E1H: look home from " + Math.round(r.dLy) + " ly · m(V) = " + r.m.toFixed(2)); }
   return ok;
}
// el icono grabado: un catalejo de tres cuerpos en diagonal con una estrella (el Sol) al fondo
function fvE1hEngrave(g, cx, cy, u, stroke, hair, dot) {
   function X(x) { return cx + x * u; }
   function Y(y) { return cy + y * u; }
   stroke(function(o) {
      var d = [14.5 / 17.2, -7.7 / 17.2], n = [7.7 / 17.2, 14.5 / 17.2];      // direccion de la diagonal y su perpendicular (unitarias)
      var tubes = [[-14, 10, -7, 5.8, 1.7], [-7, 5.8, 0, 1.6, 2.7], [0, 1.6, 8, -3.2, 3.8]];
      for (var k = 0; k < tubes.length; ++k) {
         var t = tubes[k], w = t[4], px = n[0] * w, py = n[1] * w;
         g.drawLine(X(t[0] - px) + o, Y(t[1] - py) + o, X(t[2] - px) + o, Y(t[3] - py) + o); g.drawLine(X(t[0] + px) + o, Y(t[1] + py) + o, X(t[2] + px) + o, Y(t[3] + py) + o);
         g.drawLine(X(t[2] - px) + o, Y(t[3] - py) + o, X(t[2] + px) + o, Y(t[3] + py) + o);
      }
      g.drawLine(X(8 - n[0] * 3.8) + o, Y(-3.2 - n[1] * 3.8) + o, X(8 + n[0] * 3.8) + o, Y(-3.2 + n[1] * 3.8) + o);
   });
   hair(function() { g.drawCircle(X(7.4), Y(-2.2), 2.3 * u); g.drawLine(X(-14), Y(10), X(-16), Y(11.6)); });
   dot(13.5, -9.5, 1.7);
}
