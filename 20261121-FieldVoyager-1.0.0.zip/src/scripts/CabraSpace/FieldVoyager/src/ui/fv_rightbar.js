// ============================================================================
// FieldVoyager/src/ui/fv_rightbar.js — LA COLUMNA DERECHA (decision de Nino, 5-nov-2026)
// ----------------------------------------------------------------------------
// Simetrica a la botonera de la izquierda (mismo laton, mismo grabado fino FV_E6_FINE, mismo tamaño, rotulo corto debajo y tooltip EN/ES):
//   D1 FOTO        guarda la vista actual a la resolucion de la foto (PNG, en la carpeta recordada) y la abre como imagen de PixInsight
//   D2 NOMBRES     rotulos de los objetos de la escena y de las estrellas con nombre propio de la IAU (on/off, recordado)
//   D3 CONSTEL.    las figuras de las constelaciones vistas DESDE LA NAVE (cada estrella en su sitio 3D: se deforman al viajar)
//   D5 ESCALA      una regla de longitud redonda y el ancho de la vista en años luz y en Sistemas Solares, a la distancia de lo que se mira
//   D6 COMPLETA    pantalla completa: la ventana ocupa la pantalla y se esconden la franja y la botonera izquierda (F11 / F / Esc)
//   D8 ¿DONDE ESTOY? NO SE HACE: repetiria PROFUNDITAS (la franja ya enseña la Tierra, el cono de la foto, la nave y su mirada, la linea al
//                  destino y las distancias, en vivo, y en grande con un clic). Dicho al coordinador (§11.5: dos caminos a lo mismo es un bug).
// El calculo de D2/D3/D5 es PURO (src/engine/fv_skyov.js) para que el visor web haga lo mismo; aqui solo se dibuja con Graphics.
// Banderas: FV_RB.ON false = sin columna (la ventana de antes); cada boton con la suya (false = ese boton no esta). Con todo apagado
// (nombres, constelaciones y escala sin pulsar) el fotograma es el de siempre, pixel a pixel (fvRbPaint no toca el lienzo).
// ES5 (los botones son FVBrassButton de fv_buttons.js).
// ============================================================================

var FV_RB = { ON: true, PHOTO: true, NAMES: true, CONST: true, SCALE: true, FULL: true,
              PHOTO_OPEN: true,          // D1: ademas del PNG, abrir la foto como imagen de PixInsight
              PHOTO_MAX: 8192,           // D1: lado mayor maximo (la foto de 6K se guarda entera; una de 16K se reduce a 8K)
              NAMES_MAX: 24 };           // D2: rotulos como mucho a la vez
var FV_RB_PHOTO_HOOK = null;             // pruebas: function(res) tras guardar (sin dialogos)

// ---- textos (se añaden a FV_TX sin tocar los de antes) ----
(function() {
   var add = {
      en: {
         "lab.photo": "PHOTO", "lab.names": "NAMES", "lab.const": "CONSTEL.", "lab.scale": "SCALE", "lab.full": "FULL",
         "btn.photo": "Photo", "btn.names": "Names", "btn.const": "Constellations", "btn.scale": "Scale", "btn.full": "Full screen",
         "tip.photo": "Photo: saves what you are seeing now as a PNG at the resolution of your image (names, constellations and scale go in if they are on; the cockpit and the window frame do not), in a folder you choose once (remembered), and opens it as a PixInsight image. Key: P.",
         "tip.names": "Names: shows or hides the names of the objects of your photo and of the stars with an IAU-approved proper name, where they are seen from the ship. Key: N.",
         "tip.const": "Constellations: the figures of the constellations (Stellarium's modern sky culture) drawn as they would be seen FROM THE SHIP: each star at its Hipparcos distance, so they deform as you travel. From home they look as always. Key: C.",
         "tip.scale": "Scale: a ruler and the width of the view at the distance of what you are looking at (the selected object, or else the nebula), in light years and in Solar Systems (out to Neptune's orbit, 60 au across). Key: E.",
         "tip.full": "Full screen: the window fills the screen and the cockpit and the left buttons hide, so the photo is as large as it can be. Again, F11 or Esc to come back. Key: F or F11.",
         "rb.nodir": "PHOTO NOT SAVED: NO FOLDER CHOSEN", "rb.photoTitle": "PHOTO SAVED", "rb.photoInfo": "{w} × {h} px · PNG{pi}", "rb.photoPI": " · also open in PixInsight",
         "rb.photoFail": "PHOTO NOT SAVED: {why}", "rb.busy": "SAVING THE PHOTO ({w} × {h})…", "rb.fsHint": "F11 or Esc: leave full screen",
         "rb.scaleW": "VIEW WIDTH {w} {u} ≈ {n} SOLAR SYSTEMS", "rb.scaleAt": "at {d} {u} · {name}", "rb.selStar": "selected star", "rb.au": "au",
         "tipck.rbscale": ""
      },
      es: {
         "lab.photo": "FOTO", "lab.names": "NOMBRES", "lab.const": "CONSTEL.", "lab.scale": "ESCALA", "lab.full": "COMPLETA",
         "btn.photo": "Foto", "btn.names": "Nombres", "btn.const": "Constelaciones", "btn.scale": "Escala", "btn.full": "Pantalla completa",
         "tip.photo": "Foto: guarda lo que estás viendo como PNG a la resolución de tu imagen (con nombres, constelaciones y escala si están encendidos; sin la cabina ni el marco de la ventana), en una carpeta que eliges una vez (recordada), y la abre como imagen de PixInsight. Tecla: P.",
         "tip.names": "Nombres: enseña u oculta los nombres de los objetos de tu foto y de las estrellas con nombre propio aprobado por la IAU, donde se ven desde la nave. Tecla: N.",
         "tip.const": "Constelaciones: las figuras de las constelaciones (cultura del cielo moderna de Stellarium) dibujadas como se verían DESDE LA NAVE: cada estrella a su distancia de Hipparcos, así que se deforman al viajar. Desde casa se ven como siempre. Tecla: C.",
         "tip.scale": "Escala: una regla y el ancho de la vista a la distancia de lo que miras (el objeto elegido o, si no hay, la nebulosa), en años luz y en Sistemas Solares (hasta la órbita de Neptuno, 60 ua de lado a lado). Tecla: E.",
         "tip.full": "Pantalla completa: la ventana ocupa la pantalla y se esconden la cabina y los botones de la izquierda, para que la foto se vea lo más grande posible. Otra vez, F11 o Esc para volver. Tecla: F o F11.",
         "rb.nodir": "FOTO SIN GUARDAR: NO SE ELIGIÓ CARPETA", "rb.photoTitle": "FOTO GUARDADA", "rb.photoInfo": "{w} × {h} px · PNG{pi}", "rb.photoPI": " · abierta también en PixInsight",
         "rb.photoFail": "FOTO SIN GUARDAR: {why}", "rb.busy": "GUARDANDO LA FOTO ({w} × {h})…", "rb.fsHint": "F11 o Esc: salir de pantalla completa",
         "rb.scaleW": "ANCHO DE LA VISTA {w} {u} ≈ {n} SISTEMAS SOLARES", "rb.scaleAt": "a {d} {u} · {name}", "rb.selStar": "estrella elegida", "rb.au": "ua",
         "tipck.rbscale": ""
      }
   };
   for (var L in add) for (var k in add[L]) if (Object.prototype.hasOwnProperty.call(add[L], k)) FV_TX[L][k] = add[L][k];
})();

// ---- los botones (mismo formato que FV_BTN) ----
function fvRbDefs() {
   var ids = [], out = [];
   if (!FV_RB.ON) return out;
   if (FV_RB.PHOTO) ids.push("photo");
   if (FV_RB.NAMES) ids.push("names");
   if (FV_RB.CONST) ids.push("const");
   if (FV_RB.SCALE) ids.push("scale");
   if (typeof FV_E1H !== "undefined" && FV_E1H.ON && FV_E1H.BUTTON) ids.push("home");        // (20-nov, I4; E1-13) RETROSPECTIO: mirar a casa (catalejo)
   if (typeof FV_STF !== "undefined" && FV_STF.ON && typeof FVStfPanel === "function") ids.push("stf");   // (E2, 11-nov) src/ui/fv_stf_panel.js: solo se ENSEÑA con estirado
   if (FV_RB.FULL) ids.push("full");
   for (var i = 0; i < ids.length; ++i) out.push({ id: ids[i], en: FV_TX.en["btn." + ids[i]], es: FV_TX.es["btn." + ids[i]], tipEn: FV_TX.en["tip." + ids[i]], tipEs: FV_TX.es["tip." + ids[i]] });
   return out;
}

// ---- los iconos grabados (los llama fvEngrave con SUS trazos: mismo buril, mismo grosor, misma reticula de ±15) ----
function fvRbEngrave(g, id, cx, cy, u, stroke, hair, dot, ellipse) {
   function X(x) { return cx + x * u; }
   function Y(y) { return cy + y * u; }
   if (id === "photo") {
      // una camara de placas: el cuerpo, el visor encima, el objetivo con dos anillos
      stroke(function(o) {
         g.drawRect(X(-14) + o, Y(-7) + o, X(14) + o, Y(10) + o);
         g.drawLine(X(-6) + o, Y(-7) + o, X(-3.5) + o, Y(-11) + o); g.drawLine(X(-3.5) + o, Y(-11) + o, X(3.5) + o, Y(-11) + o); g.drawLine(X(3.5) + o, Y(-11) + o, X(6) + o, Y(-7) + o);
         g.drawCircle(X(0) + o, Y(1.5) + o, 6.2 * u);
      });
      hair(function() { g.drawCircle(X(0), Y(1.5), 3.6 * u); g.drawLine(X(-14), Y(-3.5), X(-7.5), Y(-3.5)); g.drawLine(X(7.5), Y(-3.5), X(14), Y(-3.5)); g.drawRect(X(9), Y(-5.6), X(12), Y(-4.2)); });
      dot(0, 1.5, 1.2);
   } else if (id === "names") {
      // una estrella con su rotulo: la estrella de cuatro puntas, una linea de guia y dos renglones de letra
      stroke(function(o) {
         g.drawLine(X(-11) + o, Y(1) + o, X(-11) + o, Y(13) + o); g.drawLine(X(-17) + o, Y(7) + o, X(-5) + o, Y(7) + o);
         g.drawLine(X(-6.5) + o, Y(2.5) + o, X(-1) + o, Y(-5) + o); g.drawLine(X(-1) + o, Y(-5) + o, X(15) + o, Y(-5) + o);
      });
      hair(function() { g.drawLine(X(-13.4), Y(4.6), X(-8.6), Y(9.4)); g.drawLine(X(-8.6), Y(4.6), X(-13.4), Y(9.4)); g.drawLine(X(1), Y(-9.5), X(14), Y(-9.5)); g.drawLine(X(1), Y(-1), X(10), Y(-1)); });
      dot(-11, 7, 1.5);
   } else if (id === "const") {
      // una figura de cinco estrellas unidas (la «W» de Casiopea) con sus anillos finos
      var T = [[-15, -6], [-7, 6], [0, -2], [7, 7], [15, -7]];
      stroke(function(o) { for (var i = 1; i < T.length; ++i) { var a = T[i - 1], b = T[i], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.sqrt(dx * dx + dy * dy), k = 2.6 / l; g.drawLine(X(a[0] + dx * k) + o, Y(a[1] + dy * k) + o, X(b[0] - dx * k) + o, Y(b[1] - dy * k) + o); } });
      hair(function() { for (var j = 0; j < T.length; ++j) g.drawCircle(X(T[j][0]), Y(T[j][1]), 2.2 * u); });
      for (var j = 0; j < T.length; ++j) dot(T[j][0], T[j][1], j === 2 ? 1.5 : 1.15);
   } else if (id === "scale") {
      // una regla graduada: el canto, las marcas largas en las decenas y cortas entre medias, y un compas de puntas
      stroke(function(o) {
         g.drawLine(X(-15) + o, Y(5) + o, X(15) + o, Y(5) + o);
         for (var i = 0; i <= 6; ++i) { var x = -15 + 5 * i, h = (i % 3 === 0) ? 8 : 4.5; g.drawLine(X(x) + o, Y(5) + o, X(x) + o, Y(5 - h) + o); }
      });
      hair(function() { for (var i = 0; i < 6; ++i) { var x = -12.5 + 5 * i; g.drawLine(X(x), Y(5), X(x), Y(2.8)); } g.drawLine(X(-15), Y(9), X(15), Y(9)); g.drawLine(X(-15), Y(7.5), X(-15), Y(10.5)); g.drawLine(X(15), Y(7.5), X(15), Y(10.5)); });
   } else if (id === "full") {
      // las cuatro esquinas que se abren hacia fuera (escuadras) y el marco fino de la foto dentro
      stroke(function(o) {
         var C = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
         for (var i = 0; i < 4; ++i) { var sx = C[i][0], sy = C[i][1]; g.drawLine(X(15 * sx) + o, Y(11 * sy) + o, X(8 * sx) + o, Y(11 * sy) + o); g.drawLine(X(15 * sx) + o, Y(11 * sy) + o, X(15 * sx) + o, Y(5 * sy) + o); }
      });
      hair(function() { g.drawRect(X(-9), Y(-6), X(9), Y(6)); g.drawLine(X(-6), Y(3), X(-2), Y(-2)); g.drawLine(X(-2), Y(-2), X(2), Y(3)); });
   } else if (id === "home" && typeof fvE1hEngrave === "function") fvE1hEngrave(g, cx, cy, u, stroke, hair, dot);   // (I4; E1-13) el catalejo
   else if (id === "stf" && typeof fvStfEngrave === "function") fvStfEngrave(g, cx, cy, u, stroke, hair, dot);   // (E2) la curva del estirado
}
// (E2, 11-nov) los botones de la columna que se ENSEÑAN (el STF solo con estirado: src/ui/fv_stf_panel.js); sin el STF, todos, como antes
function fvRbShown(D) {
   var list = D.rbtnList || [], out = [];
   for (var i = 0; i < list.length; ++i) if (!(list[i].def.id === "stf" && !(typeof fvStfUiAvailable === "function" && fvStfUiAvailable(D)))) out.push(list[i]);
   return out;
}

// ---------------------------------------------------------------------------
// LA COMPOSICION: la columna derecha simetrica (mismo ancho colW, mismo boton) o, en pantalla completa, solo la foto y esta columna
// ---------------------------------------------------------------------------
function fvLayoutRB(D, availW, availH) {
   var nL = D.btnList.length, nR = D.rbtnList ? fvRbShown(D).length : 0;
   if (!FV_RB.ON || !nR) return fvLayout(availW, availH, D.aspect, nL);
   var n = Math.max(nL, nR), L, cw = 0, k;
   if (D.rbFsOn) return fvLayoutRBFull(availW, availH, D.aspect, n);
   // el ancho de la columna depende del ancho de la franja, que depende del hueco: punto fijo (2-3 vueltas)
   for (k = 0; k < 6; ++k) { L = fvLayout(availW - cw, availH, D.aspect, n); if (L.colW === cw) break; cw = L.colW; }
   var W2 = L.W + L.colW, x0 = Math.max(0, Math.floor((availW - W2) / 2)), sh = x0 - L.x0;
   L.x0 += sh; L.vx += sh; L.sx += sh; L.W = W2;
   L.rx = L.x0 + L.colW + (L.sw || L.pw); L.nR = nR; L.fs = false;
   return L;
}
// pantalla completa: la foto con su aspecto en todo el alto (sin franja) y la columna derecha pegada a ella; la franja queda escondida
function fvLayoutRBFull(availW, availH, aspect, n) {
   var aT = (isFinite(aspect) && aspect > 0) ? aspect : 1.5, m = FV_NAV.MARGIN, per = 1 + FV_NAV.LABEL_K + FV_NAV.GAP_K, cw = 0, pw = 0, ph = 0, b = 0, k;
   for (k = 0; k < 6; ++k) {
      pw = Math.min(availW - 2 * m - cw, (availH - 2 * m) * aT); ph = Math.round(pw / aT); pw = Math.round(pw);
      b = Math.round(FV_NAV.BTN_K * pw); if (n * per * b > ph) b = Math.floor(ph / (n * per)); b = Math.max(24, b);
      var c2 = Math.round(b * 1.34); if (c2 === cw) break; cw = c2;
   }
   var bh = Math.round(b * (1 + FV_NAV.LABEL_K)), gap = Math.max(2, Math.round(b * FV_NAV.GAP_K)), sR = FV_NAV.GRID_H / FV_NAV.GRID_W;
   var W = pw + cw, x0 = Math.max(0, Math.floor((availW - W) / 2)), y0 = Math.max(0, Math.floor((availH - ph) / 2)), sh = Math.round(pw * sR);
   return { pw: pw, ph: ph, sw: pw, sh: sh, b: b, bh: bh, gap: gap, colW: cw, x0: x0, y0: y0, vx: x0, vy: y0, sx: x0, sy: y0 + ph,
            W: W, H: ph, aspect: aT, aspectBox: aT, k: pw / 1280, kc: pw / FV_NAV.GRID_W, rx: x0 + pw, nR: n, fs: true };
}
// la composicion fija de las pruebas de antes (1280 × 720): la columna se añade a la derecha
function fvRbFixed(D, L) {
   if (!FV_RB.ON || !D.rbtnList || !D.rbtnList.length) return L;
   L.rx = L.vx + L.pw; L.W += L.colW; L.nR = fvRbShown(D).length; L.fs = false;
   return L;
}
// colocar la columna (y esconder lo accesorio en pantalla completa)
function fvRbPlace(D, L) {
   var list = fvRbShown(D), all = D.rbtnList || [], i;
   for (i = 0; i < all.length; ++i) if (list.indexOf(all[i]) < 0) { try { all[i].hide(); } catch (eH) {} }      // (E2) el STF sin estirado: fuera de la columna
   if (list.length && L.rx !== undefined) {
      var bx = L.rx + Math.round((L.colW - L.b) / 2), by = L.vy + Math.round(L.gap / 2);
      for (i = 0; i < list.length; ++i) { list[i].setSizeFV(L.b, L.bh); list[i].move(bx, by + i * (L.bh + L.gap)); if (!list[i].visible) list[i].show(); }
   }
   if (D.stfPanel && D.stfPanel.visibleFV) D.stfPanel.place();
   var fs = !!L.fs;
   if (D.rbFsShown === fs) return;
   D.rbFsShown = fs;
   try {
      for (i = 0; i < D.btnList.length; ++i) { if (fs) D.btnList[i].hide(); else D.btnList[i].show(); }
      if (fs) D.strip.hide(); else D.strip.show();
      if (D.radio && D.radio.control) { if (fs) D.radio.control.hide(); else D.radio.control.show(); }
   } catch (e) { fvLog("right column: show/hide " + e); }
}

// ---------------------------------------------------------------------------
// EL DIALOGO: crear, estado recordado, pulsar, teclas, estados
// ---------------------------------------------------------------------------
function fvRbInit(D) {
   D.rbtns = {}; D.rbtnList = []; D.rbFsOn = false; D.rbFsShown = false; D.rbFsPrev = null; D.rbLast = null;
   D.rb = { names: fvSetRead("rbNames", "0") === "1", cons: fvSetRead("rbConst", "0") === "1", scale: fvSetRead("rbScale", "0") === "1" };
   var defs = fvRbDefs();
   for (var i = 0; i < defs.length; ++i) {
      var b = new FVBrassButton(D, defs[i], FV_UI.BTN, function(id) { fvRbButton(D, id); }, Math.round(FV_UI.BTN * (1 + FV_NAV.LABEL_K)));
      D.rbtns[defs[i].id] = b; D.rbtnList.push(b);
   }
}
// el estado de los dibujos al pintor (lo leen fvRbPaint en la nave, en REC y en la FOTO)
function fvRbToPainter(D) { if (D.painter) D.painter.rb = { names: !!(D.rb && D.rb.names && FV_RB.NAMES), cons: !!(D.rb && D.rb.cons && FV_RB.CONST), scale: !!(D.rb && D.rb.scale && FV_RB.SCALE) }; }
function fvRbButton(D, id) {
   if (D.recLocked && D.recLocked()) return false;
   var P = D.P, done = true;
   if (id === "full") fvRbFullscreen(D, !D.rbFsOn);
   else if (!P) done = false;
   else if (id === "photo") fvRbPhoto(D, {});
   else if (id === "stf" && typeof fvStfUiToggle === "function") fvStfUiToggle(D);           // (E2) el panel del estirado
   else if (id === "home" && typeof fvE1hGo === "function") done = fvE1hGo(D);                 // (I4; E1-13) mirar a casa
   else if (id === "names" || id === "const" || id === "scale") {
      var key = (id === "const") ? "cons" : id;
      D.rb[key] = !D.rb[key];
      fvSetWrite(id === "names" ? "rbNames" : (id === "const" ? "rbConst" : "rbScale"), D.rb[key] ? "1" : "0");
      fvRbToPainter(D);
   } else done = false;
   if (done) { try { D.renderNow(); D.view.repaint(); } catch (e) {} }
   D.syncButtons();
   return done;
}
// teclas: P foto · N nombres · C constelaciones · E escala · F / F11 pantalla completa -> true si es suya
function fvRbKey(D, k) {
   function K(name, num) { return (typeof CP_GLOBAL !== "undefined" && typeof CP_GLOBAL[name] === "number") ? CP_GLOBAL[name] : num; }
   var map = {}; map[K("Key_P", 0x50)] = "photo"; map[K("Key_N", 0x4e)] = "names"; map[K("Key_C", 0x43)] = "const"; map[K("Key_E", 0x45)] = "scale";
   if (typeof FV_E1H !== "undefined") map[K("Key_U", 0x55)] = "home";                          // (I4; E1-13; B2: sin boton, la tecla U se queda)
   map[K("Key_F", 0x46)] = "full"; map[K("Key_F11", 0x0800000b)] = "full";
   var id = map[k];
   if (!id || (!D.rbtns[id] && !(id === "home" && typeof FV_E1H !== "undefined" && FV_E1H.ON))) return false;   // (B2) U vale aunque el boton CASA ya no exista
   if (id !== "full" && !D.P) return false;
   fvRbButton(D, id);
   return true;
}
function fvRbSync(D) {
   var b = D.rbtns || {}, P = D.P;
   if (!D.rbtnList || !D.rbtnList.length) return;
   if (D.recLocked && D.recLocked()) { for (var a in b) b[a].setStateFV("normal", false); return; }
   if (b.full) b.full.setStateFV(D.rbFsOn ? "on" : "normal", !!D.auto);
   if (b.photo) b.photo.setStateFV("normal", !!P);
   if (b.names) b.names.setStateFV(D.rb.names ? "on" : "normal", !!P);
   if (b.const) b.const.setStateFV(D.rb.cons ? "on" : "normal", !!P && typeof FV_CONST_DATA !== "undefined");
   if (b.scale) b.scale.setStateFV(D.rb.scale ? "on" : "normal", !!P);
   if (b.home) b.home.setStateFV((P && P.sunMark) ? "on" : "normal", !!P);                       // (I4; E1-13) encendido mientras se mira a casa
   if (b.stf) { if (typeof fvStfUiWatch === "function") fvStfUiWatch(D); b.stf.setStateFV(D.stfPanel && D.stfPanel.visibleFV ? "on" : "normal", !!P && !!D.built && !D.stfBusy); }   // (E2)
}

// ---------------------------------------------------------------------------
// D6 · PANTALLA COMPLETA. PJSR no tiene showFullScreen (sonda tests/fv_rb_probe_fs.js, 5-nov: Dialog sin showFullScreen/showMaximized/
// windowState): la ventana se lleva al rectangulo util de la pantalla (availableScreenRect) y se esconden la franja y la botonera izquierda.
// Al salir vuelve a su sitio y tamaño. Esc, F o F11 salen.
// ---------------------------------------------------------------------------
function fvRbFullscreen(D, on) {
   if (!D.auto || on === D.rbFsOn) return D.rbFsOn;
   if (on) {
      var p = null; try { p = D.position; } catch (e0) {}
      D.rbFsPrev = { x: p ? p.x : 0, y: p ? p.y : 0, w: D.width, h: D.height };
      if (D.route && D.route.big) { try { D.route.close(); } catch (eR) {} }
      if (D.radioOpen) { try { D.radioToggle(false); } catch (eRd) {} }
      D.rbFsOn = true;
      var r = null; try { r = D.availableScreenRect; } catch (e1) {}
      if (r && r.width > 0) { D.move(r.x0, r.y0); D.resize(r.width, r.height); }
      D.relayout(D.width, D.height);
      if (D.P) D.ui.caption = { text: fvTx("rb.fsHint"), t0: D.P.t, dur: 2.6 };
      fvLog("full screen ON · " + D.width + "x" + D.height + " · photo " + D.L.pw + "x" + D.L.ph);
   } else {
      D.rbFsOn = false;
      var q = D.rbFsPrev;
      if (q) { D.resize(q.w, q.h); D.move(q.x, q.y); }
      D.relayout(D.width, D.height);
      fvLog("full screen OFF · " + D.width + "x" + D.height + " · photo " + D.L.pw + "x" + D.L.ph);
   }
   D.syncButtons();
   return D.rbFsOn;
}

// ---------------------------------------------------------------------------
// D1 · LA FOTO: la vista de ahora a la resolucion de la imagen (lado mayor ≤ PHOTO_MAX), con lo que este encendido de la columna; sin HUD,
// sin marco, sin viñeta ni ventana de la nave. PNG en la carpeta recordada («photoDir», la primera vez se pregunta) y, si FV_RB.PHOTO_OPEN,
// una ImageWindow de 8 bits con la misma imagen. o = { dir, W, H, open } (pruebas) -> { ok, why, file, w, h, ms, win }
// ---------------------------------------------------------------------------
function fvRbPhoto(D, o) {
   o = o || {};
   var P = D.P, sc = D.scene, out = { ok: false, why: "", file: "", w: 0, h: 0, ms: 0, win: null };
   if (!P || !D.painter || !sc) { out.why = "no scene"; return out; }
   var dir = o.dir || fvPickDir("photoDir", "FieldVoyager: folder for the photos · carpeta para las fotos");
   if (!dir) { D.ui.caption = { text: fvTx("rb.nodir"), t0: P.t, dur: 2.4 }; out.why = "no folder"; return out; }
   var f = sc.field, a = D.VW / D.VH, W = o.W || Math.round(f.width), H = o.H || Math.round(W / a);
   var s = Math.min(1, FV_RB.PHOTO_MAX / Math.max(W, H)); W = Math.max(D.VW, Math.round(W * s)); H = Math.max(1, Math.round(W / a));
   out.w = W; out.h = H;
   var t0 = Date.now(), pnt = D.painter, keepHits = pnt.hits, bmp = null;
   // el aviso de «guardando» en la pantalla de ahora (la foto tarda ~2 s, casi todo el PNG). repaint() pinta YA, sin atender eventos: con
   // processEvents aqui se colaba lo pendiente de la nave (medido el 5-nov: la precarga de la ficha, 35 s de red, dentro de la FOTO)
   var tb = Date.now();
   try { D.ui.caption = { text: fvTx("rb.busy", { w: W, h: H }), t0: P.t, dur: 30 }; D.renderNow(); out.tBusyR = Date.now() - tb; D.view.repaint(); } catch (eB) {}
   out.tBusy = Date.now() - tb;
   try {
      var ta = Date.now(); bmp = new Bitmap(W, H, BitmapFormat.RGB32); out.tAlloc = Date.now() - ta;
      var tr = Date.now();
      pnt.render(bmp, P, { hud: false, frame: false, vignette: false, fg: false });
      out.tRender = Date.now() - tr;
      var stamp = (function() { var d = new Date, p2 = function(v) { return (v < 10 ? "0" : "") + v; }; return d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + "_" + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()); })();
      var N = sc.nebula, nm = String((N && (N.id || N.name)) || "scene").replace(/[^A-Za-z0-9_-]+/g, "_").replace(/^_+|_+$/g, "") || "scene";
      dir = String(dir).split("\\").join("/").replace(/\/+$/, "");
      if (!File.directoryExists(dir)) File.createDirectory(dir, true);
      var file = dir + "/FieldVoyager_" + nm + "_" + stamp + ".png";
      var ts = Date.now(); bmp.save(file); out.tSave = Date.now() - ts;
      if (!File.exists(file)) throw new Error("the PNG was not written");
      out.file = file; out.ok = true;
      if (o.open !== undefined ? o.open : FV_RB.PHOTO_OPEN) {
         // (el identificador de una vista solo admite letras, cifras y _: «Sh 2-199» lo tumbaba, medido el 5-nov). Si falla, el PNG ya esta
         try {
            var w = new ImageWindow(W, H, 3, 8, false, true, ("FieldVoyager_" + nm).replace(/[^A-Za-z0-9_]/g, "_"));
            w.mainView.beginProcess(UndoFlag_NoSwapFile);
            w.mainView.image.blend(bmp);
            w.mainView.endProcess();
            w.show();
            out.win = w; out.tOpen = Date.now() - ts - out.tSave;
         } catch (eW) { out.winWhy = String((eW && eW.message) ? eW.message : eW); fvLog("photo: PixInsight image not opened: " + out.winWhy); }
      }
   } catch (e) { out.ok = false; out.why = String((e && e.message) ? e.message : e); }
   finally { pnt.hits = keepHits; pnt.cardKey = ""; }
   out.ms = Date.now() - t0;
   D.ui.caption = null;
   D.ui.notice = out.ok ? { kind: "photo", title: fvTx("rb.photoTitle"), path: out.file, lines: [fvTx("rb.photoInfo", { w: W, h: H, pi: out.win ? fvTx("rb.photoPI") : "" })], buttons: ["openDir", "changeDir"], dir: dir }
                        : { kind: "photo", title: fvTx("rb.photoFail", { why: out.why }), lines: [], buttons: ["changeDir"], dir: dir };
   D.rbLast = out;
   fvLog("photo: " + (out.ok ? W + "x" + H + " → " + out.file + (out.win ? " (and a PixInsight image)" : "") + " in " + out.ms + " ms (aviso " + out.tBusy + " [pintar " + out.tBusyR + "], lienzo " + out.tAlloc + ", render " + out.tRender + ", PNG " + out.tSave + (out.win ? ", image " + out.tOpen : "") + ")" : "FAILED " + out.why));
   if (typeof FV_RB_PHOTO_HOOK === "function") { try { FV_RB_PHOTO_HOOK(out); } catch (eH) {} }
   return out;
}
// «cambiar carpeta» del aviso de la foto
function fvRbChangeDir(D) {
   var d = fvPickDir("photoDir", "FieldVoyager: folder for the photos · carpeta para las fotos", true);
   if (d && D.ui.notice) D.ui.notice.dir = d;
   return d;
}

// ---------------------------------------------------------------------------
// EL DIBUJO (lo llama una linea de FVPainter.render, despues de la viñeta y antes de la ventana y el HUD). Sin nada encendido no toca g.
// ---------------------------------------------------------------------------
var FV_RB_COL = { line: 0x8CE5B53F, dot: 0xC8FFF3C4, cname: 0xA8E5B53F, ink: 0xffFBF2E0, gold: 0xffF3D27E, dim: 0xffC9B48A, casing: 0xB0000000, plate: 0x8C07060A };
function fvRbPaint(g, painter, pr, P, W, H, o) {
   var st = painter && painter.rb;
   if (!FV_RB.ON || !st || !(st.names || st.cons || st.scale)) { if (painter && painter.stats) painter.stats.rb = null; return; }
   var sc = painter.scene, u = W / 1280, prep = (st.names || st.cons) ? fvSkyovPrep(sc) : null, t0 = fvNowMs();
   g.antialiasing = true; g.textAntialiasing = true;
   var r = { cons: null, names: 0, scale: null };
   if (st.cons && prep) r.cons = fvRbPaintConst(g, prep, pr, W, H, u);
   if (st.names) r.names = fvRbPaintNames(g, sc, prep, pr, W, H, u);
   if (st.scale) r.scale = fvRbPaintScale(g, P, sc, W, H, u);
   r.ms = fvNowMs() - t0;
   if (painter.stats) painter.stats.rb = r;
}
// el color con su opacidad multiplicada por a (0…1)
function fvRbFade(col, a) { var al = Math.round(((col >>> 24) & 255) * Math.max(0, Math.min(1, a))); return ((al << 24) | (col & 0xffffff)) >>> 0; }
function fvRbPaintConst(g, prep, pr, W, H, u) {
   var C = fvSkyovConst(prep, pr, W, H, u), i, lw = Math.max(0.8, 0.85 * u), lastA = -1;
   // (5-nov) las lineas en el orden de su opacidad, cuantizada a 1/16: un Pen por nivel, no por segmento
   var idx = []; for (i = 0; i < C.segs.length; ++i) idx.push(i);
   idx.sort(function(x, y) { return C.segs[x][4] - C.segs[y][4]; });
   for (i = 0; i < idx.length; ++i) {
      var s = C.segs[idx[i]], aq = Math.round(s[4] * 16) / 16;
      if (aq !== lastA) { g.pen = new Pen(fvRbFade(FV_RB_COL.line, aq), lw); lastA = aq; }
      g.drawLine(s[0], s[1], s[2], s[3]);
   }
   for (i = 0; i < C.dots.length; ++i) { var d = C.dots[i]; g.fillCircle(d[0], d[1], Math.max(0.9, (1.9 - 0.22 * Math.min(6, Math.max(-1, d[2]))) * u), new Brush(fvRbFade(FV_RB_COL.dot, d[3]))); }
   var f = cpFont("display", Math.max(9, 10.5 * u), false, false, Math.max(1, Math.round(1.6 * u))), placed = [], hh = f.ascent + f.descent;
   g.font = f;
   for (i = 0; i < C.labels.length; ++i) {
      var l = C.labels[i], t = l.text.toUpperCase(), w = f.width(t), R = [l.x - w / 2 - 4 * u, l.y - f.ascent - 2 * u, l.x + w / 2 + 4 * u, l.y - f.ascent + hh + 2 * u], clash = false;
      if (l.x - w / 2 < 0 || l.x + w / 2 > W) continue;
      for (var jq = 0; jq < placed.length && !clash; ++jq) { var Q = placed[jq]; clash = R[0] < Q[2] && R[2] > Q[0] && R[1] < Q[3] && R[3] > Q[1]; }
      if (clash) continue;                                          // (5-nov, montaje) los nombres de las figuras no se pisan
      placed.push(R);
      g.pen = new Pen(fvRbFade(FV_RB_COL.casing, l.alpha)); g.drawText(l.x - w / 2 + 1, l.y + 1, t);
      g.pen = new Pen(fvRbFade(FV_RB_COL.cname, l.alpha)); g.drawText(l.x - w / 2, l.y, t);
   }
   return { nSeg: C.segs.length, nDots: C.dots.length, nFig: C.nFig, nFaded: C.nFaded, cached: C.cached, labels: C.labels.map(function(l) { return l.abbr; }) };
}
function fvRbPaintNames(g, sc, prep, pr, W, H, u) {
   var cand = fvSkyovNames(sc, prep, pr, W, H, FV_LANG), placed = [], f = cpFont("text", Math.max(9, 11 * u)), asc = f.ascent, des = f.descent, n = 0;
   g.font = f;
   function free(r) { if (r[0] < 2 || r[2] > W - 2 || r[1] < 2 || r[3] > H - 2) return false; for (var j = 0; j < placed.length; ++j) { var q = placed[j]; if (r[0] < q[2] && r[2] > q[0] && r[1] < q[3] && r[3] > q[1]) return false; } return true; }
   for (var i = 0; i < cand.length && n < FV_RB.NAMES_MAX; ++i) {
      var c = cand[i], w = f.width(c.text), off = (c.kind === "object" ? 7 : 5) * u, rr = null;
      var R1 = [c.x + off, c.y - off - asc, c.x + off + w, c.y - off + des], R2 = [c.x - off - w, c.y - off - asc, c.x - off, c.y - off + des];
      if (free(R1)) rr = R1; else if (free(R2)) rr = R2;
      if (!rr) continue;
      placed.push([rr[0] - 2 * u, rr[1] - u, rr[2] + 2 * u, rr[3] + u]); ++n;
      // la marca: anillo fino (objeto) o dos rayitas (estrella), y la guia corta hasta el rotulo
      g.pen = new Pen(FV_RB_COL.casing, Math.max(1.6, 2.0 * u));
      if (c.kind === "object") g.drawCircle(c.x, c.y, 4.2 * u); else { g.drawLine(c.x - 4.5 * u, c.y, c.x - 2 * u, c.y); g.drawLine(c.x + 2 * u, c.y, c.x + 4.5 * u, c.y); }
      g.pen = new Pen(FV_RB_COL.gold, Math.max(0.8, 0.9 * u));
      if (c.kind === "object") g.drawCircle(c.x, c.y, 4.2 * u); else { g.drawLine(c.x - 4.5 * u, c.y, c.x - 2 * u, c.y); g.drawLine(c.x + 2 * u, c.y, c.x + 4.5 * u, c.y); }
      var tx = rr[0], ty = c.y - off;
      g.pen = new Pen(FV_RB_COL.casing); g.drawText(tx + 1, ty + 1, c.text);
      g.pen = new Pen(c.kind === "object" ? FV_RB_COL.ink : FV_RB_COL.dim); g.drawText(tx, ty, c.text);
   }
   return n;
}
function fvRbPaintScale(g, P, sc, W, H, u) {
   var S = fvSkyovScale(P, sc, FV_LANG);
   if (!S) return;
   var L = FV_LANG, ly = fvTx("nav.ly"), unit = (S.bar.unit === "au") ? fvTx("rb.au") : ly;
   var x0 = Math.round(64 * u), yb = Math.round(H - 72 * u), len = S.bar.frac * W;
   var lab = fvNum(S.bar.len, S.bar.len < 1 ? (S.bar.len < 0.1 ? 2 : 1) : 0, L) + " " + unit;
   var inAu = S.bar.unit === "au", wv = inAu ? S.widthLy * ((typeof FVS !== "undefined") ? FVS.LY_AU : 63241.077) : S.widthLy;
   var l2 = fvTx("rb.scaleW", { w: fvNum(fvSkyovRound2(wv), wv < 10 ? 1 : 0, L), u: unit, n: fvNum(fvSkyovRound2(S.solarSystems), S.solarSystems < 10 ? 1 : 0, L) });
   var nm = S.refName || (S.refKind === "star" ? fvTx("rb.selStar") : "");
   var l3 = fvTx("rb.scaleAt", { d: fvNum(fvSkyovRound2(S.dRef), S.dRef < 10 ? 1 : 0, L), u: ly, name: nm }).replace(/ · $/, "");
   var f1 = cpFont("display", Math.max(9, 11 * u), false, false, Math.max(1, Math.round(1.4 * u))), f2 = cpFont("text", Math.max(8, 9.5 * u));
   var wBox = Math.max(len, f2.width(l2), f2.width(l3)) + 16 * u;
   g.fillRect(x0 - 8 * u, yb - 22 * u, x0 - 8 * u + wBox, yb + 30 * u, new Brush(FV_RB_COL.plate));
   // la regla: el canto, las puntas y las marcas de cuartos
   g.pen = new Pen(FV_RB_COL.gold, Math.max(1, 1.2 * u));
   g.drawLine(x0, yb, x0 + len, yb);
   g.drawLine(x0, yb - 5 * u, x0, yb + 5 * u); g.drawLine(x0 + len, yb - 5 * u, x0 + len, yb + 5 * u);
   g.pen = new Pen(FV_RB_COL.gold, Math.max(0.7, 0.7 * u));
   for (var q = 1; q < 4; ++q) g.drawLine(x0 + len * q / 4, yb - (q === 2 ? 3.5 : 2.2) * u, x0 + len * q / 4, yb);
   g.font = f1; g.pen = new Pen(FV_RB_COL.ink); g.drawText(x0 + (len - f1.width(lab)) / 2, yb - 7 * u, lab);
   g.font = f2; g.pen = new Pen(FV_RB_COL.gold); g.drawText(x0, yb + 14 * u, l2);
   g.pen = new Pen(FV_RB_COL.dim); g.drawText(x0, yb + 25 * u, l3);
   return { len: len, lab: lab, l2: l2, l3: l3, x0: x0, yb: yb, widthLy: S.widthLy, dRef: S.dRef, ss: S.solarSystems };
}
