// ============================================================================
// FieldVoyager/src/ui/fv_hr_ui.js — (I2, 19-nov-2026) EL BOTON «DIAGRAMA HR» EN PIXINSIGHT
// ----------------------------------------------------------------------------
// Nino: «Un botón diagrama HR que, al pulsarlo, las estrellas se muevan a un diagrama HR que aparezca en la pantalla, de forma dinámica.»
// El motor (que estrella entra, donde cae, ejes, escalonado, trayectoria) es src/engine/fv_hr.js, el mismo del navegador. Aqui:
//   · el icono grabado del boton (fvHrEngrave, lo llama fvEngrave de fv_buttons.js) y sus textos EN/ES;
//   · el estado en el dialogo (D.hr = FV_HR_ST): fvHrToggle / fvHrStep (lo mueve el Timer del dialogo, NUNCA un onPaint) / fvHrEnd;
//   · los enganches del pintor: fvHrFrame + fvHrStar + fvHrLev (FVPainter.paintStars: cada estrella se pinta donde le toca en este
//     fotograma, con SU sprite y SU color), fvHrVeil (el velo sobre la foto, debajo de las estrellas) y fvHrPaint (ejes y rotulos);
//   · el raton: fvHrTipAt (punto bajo el cursor + tooltips), fvHrClick (la ficha de esa estrella, la de siempre), fvHrAnchor (la reticula
//     de la ficha cae en el punto del diagrama).
// FV_HR.ON = false: sin boton y sin nada de esto (el pintor no cambia: fvHrFrame devuelve null). ES5.
// ============================================================================

var FV_HR_ST = null;       // el diagrama vivo: { k, dir, t, scene, model, rect, vis, nVis, hover, … } | null

// los textos EN/ES estan en el motor (FV_HR_TX, src/engine/fv_hr.js: los mismos para el navegador): aqui pasan a la tabla de la nave
(function() { if (typeof FV_TX !== "undefined" && typeof FV_HR_TX !== "undefined") for (var L in FV_HR_TX) for (var k in FV_HR_TX[L]) FV_TX[L][k] = FV_HR_TX[L][k]; })();

// EL ICONO GRABADO (misma reticula ±15 y mismos trazos que fvEngrave): los dos ejes, la secuencia principal en diagonal (de arriba a la
// izquierda a abajo a la derecha), la rama de las gigantes arriba a la derecha y dos enanas blancas abajo a la izquierda
function fvHrEngrave(g, cx, cy, u, stroke, hair, dot) {
   stroke(function(o) {
      g.drawLine(cx - 12 * u + o, cy - 13 * u + o, cx - 12 * u + o, cy + 11 * u + o);
      g.drawLine(cx - 12 * u + o, cy + 11 * u + o, cx + 14 * u + o, cy + 11 * u + o);
   });
   hair(function() {
      for (var k = 0; k < 4; ++k) { g.drawLine(cx - 12 * u, cy + (-9 + 6 * k) * u, cx - 14 * u, cy + (-9 + 6 * k) * u); g.drawLine(cx + (-6 + 6 * k) * u, cy + 11 * u, cx + (-6 + 6 * k) * u, cy + 13 * u); }
      var pts = []; for (var j = 0; j <= 12; ++j) { var t = j / 12; pts.push(new Point(cx + (-8.5 + 20 * t) * u, cy + (-10 + 17.5 * t + 2.2 * Math.sin(Math.PI * t)) * u)); }
      g.drawPolyline(pts);
   });
   var MS = [[-8.5, -10, 1.5], [-5, -6.3, 1.25], [-1.5, -2.6, 1.15], [2, 0.9, 1.05], [5.5, 4.2, 0.95], [9, 6.4, 0.85], [11.5, 7.5, 0.8]], i;
   for (i = 0; i < MS.length; ++i) dot(MS[i][0], MS[i][1], MS[i][2]);
   var RG = [[4, -8.5, 1.5], [8, -10.5, 1.7], [11.5, -8, 1.3]];
   for (i = 0; i < RG.length; ++i) dot(RG[i][0], RG[i][1], RG[i][2]);
   dot(-7.5, 6.5, 0.8); dot(-4.5, 8, 0.75);
}

// el modelo HR de la escena (una vez por escena y por bandera de polvo)
function fvHrModel(scene) {
   if (!scene || !scene.stars) return null;
   var key = scene.stars.n + "|" + (FV_HR.DEREDDEN ? 1 : 0) + "|" + FV_HR_BREAK;
   if (!scene._hr || scene._hrKey !== key) { scene._hr = fvHrBuild(scene.stars); scene._hrKey = key; }
   return scene._hr;
}
function fvHrAvailable(D) { return !!(typeof FV_HR !== "undefined" && FV_HR.ON && D && D.scene && D.scene.stars && D.P); }

// EL BOTON: la primera pulsacion manda las estrellas al diagrama; la segunda (o Esc) las devuelve
function fvHrToggle(D) {
   if (!fvHrAvailable(D)) return false;
   if (D.hr) { D.hr.dir = -1; D.hr.done = false; return true; }
   if (D.P.flight) return false;
   var st = fvHrStateNew();
   st.scene = D.scene; st.model = fvHrModel(D.scene); st.vis = []; st.nVis = 0; st.hover = -1; st.out = [0, 0]; st.ox = 0; st.oy = 0; st.oa = 1; st.ot = 0;
   D.hr = st; FV_HR_ST = st;
   if (st.model.nOk === 0 && D.ui) D.ui.caption = { text: fvTx("hr.none"), t0: D.P.t, dur: 3.2 };
   if (typeof fvLog === "function") fvLog("HR diagram: " + st.model.nOk + " of " + st.model.n + " stars with a distance (" + st.model.nDered + " dereddened; skipped: " + st.model.skipped.noDistance + " no distance, " + st.model.skipped.noColour + " no colour, " + st.model.skipped.outOfRange + " out of range)");
   return true;
}
// fuera ya (otro boton, un viaje): sin animacion de vuelta
function fvHrEnd(D) { if (D) D.hr = null; FV_HR_ST = null; }
// el reloj: lo llama tick() del dialogo. Un viaje en marcha saca del diagrama (las estelas del warp no son de este modo)
function fvHrStep(D, dt) {
   var st = D.hr; if (!st) return;
   if (D.P && D.P.flight) { fvHrEnd(D); return; }
   fvHrStateStep(st, dt);
   if (st.done) fvHrEnd(D);
}
function fvHrKey(D, k) { if (!D.hr) return false; if (k === Key_Escape) { if (D.hr.dir >= 0) fvHrToggle(D); return true; } return false; }
// con el diagrama a la vista la camara no se mueve con el raton (arrastrar, rueda): las estrellas saldrian de la vista bajo sus puntos
function fvHrHold(D) { return !!(D && D.hr); }

// ---------------------------------------------------------------------------
// LOS ENGANCHES DEL PINTOR
// ---------------------------------------------------------------------------
// el diagrama de este fotograma (null = no hay: el pintor sigue como siempre). W, H = el fotograma
function fvHrFrame(painter, P, W, H) {
   var st = FV_HR_ST;
   if (!st || typeof FV_HR === "undefined" || !FV_HR.ON || !painter || st.scene !== painter.scene || !st.model || !(st.k > 0)) return null;
   st.rect = fvHrRect(W, H); st.nVis = 0; st.W = W; st.H = H;
   var s = st.k; st.aK = s * s * (3 - 2 * s);
   return st;
}
// la estrella i, que el pintor iba a pintar en (sx, sy) con alfa fa: donde va y con que alfa (F.ox, F.oy, F.oa); F.ot = su avance (0 = en la foto)
function fvHrStar(F, i, sx, sy, fa) {
   var M = F.model;
   if (!M.ok[i]) { F.ox = sx; F.oy = sy; F.oa = fa * (1 - (1 - FV_HR.DIM) * F.aK); F.ot = 0; return; }
   var t = fvHrProgress(F.k, M.delay[i]);
   F.ot = t; F.oa = fa;
   if (t <= 0) { F.ox = sx; F.oy = sy; return; }
   F.oa = fa * (1 - (1 - M.alpha[i]) * t);            // el apelotonamiento: en el corazon de la secuencia principal cada punto brilla menos
   fvHrPath(sx, sy, F.rect.x + M.u[i] * F.rect.w, F.rect.y + M.v[i] * F.rect.h, t, F.out);
   F.ox = F.out[0]; F.oy = F.out[1];
}
// el nivel del sprite en el diagrama: las brillantes encogen hasta LEV_CAP (no tapan a sus vecinas) y las muy debiles suben a LEV_FLOOR;
// de paso apunta donde ha quedado la estrella (para el cursor)
function fvHrLev(F, i, lev) {
   if (F.ot > 0) {
      if (lev > FV_HR.LEV_CAP) lev = Math.round(lev + (FV_HR.LEV_CAP - lev) * F.ot);
      else if (lev < FV_HR.LEV_FLOOR) lev = Math.round(lev + (FV_HR.LEV_FLOOR - lev) * F.ot);
   }
   else if (!F.model.ok[i] && lev > FV_HR.LEV_REST) lev = Math.round(lev + (FV_HR.LEV_REST - lev) * F.aK);   // la que se queda en la foto, pequeña
   if (F.model.ok[i]) { var n = F.nVis; F.vis[n] = i; F.vis[n + 1] = F.ox; F.vis[n + 2] = F.oy; F.nVis = n + 3; }
   return lev;
}
// el velo sobre la foto (debajo de las estrellas): la nebulosa se apaga para que el diagrama se lea
function fvHrVeil(painter, g, P, W, H) {
   var st = FV_HR_ST;
   if (!st || !FV_HR.ON || st.scene !== painter.scene || !(st.k > 0) || !(fvHrVeilK() > 0)) return;
   var a = Math.round(255 * fvHrVeilK() * fvHrAxesAlpha(st.k)); if (a < 1) return;
   var op = g.compositionOperator;
   g.compositionOperator = CompositionOp_SourceOver;
   g.fillRect(0, 0, W, H, new Brush(((a << 24) | 0x060508) >>> 0));
   g.compositionOperator = op;
}
function fvHrCol(rgb, a) { return ((Math.max(0, Math.min(255, Math.round(255 * a))) << 24) | (rgb & 0xffffff)) >>> 0; }
function fvHrNum(x, dec) { var s = x.toFixed(dec); if (x < 0) s = "−" + s.substring(1); return (FV_LANG === "es") ? s.replace(".", ",") : s; }
function fvHrThousands(n) { var s = String(Math.round(n)), o = ""; while (s.length > 3) { o = (FV_LANG === "es" ? " " : ",") + s.substring(s.length - 3) + o; s = s.substring(0, s.length - 3); } return s + o; }

// LOS EJES Y ROTULOS (encima de las estrellas, debajo de la ficha y de la cabina). Trazos finos de oro, como una lamina grabada
function fvHrPaint(g, painter, P, W, H, o) {
   var st = FV_HR_ST;
   if (!st || !FV_HR.ON || st.scene !== painter.scene || !(st.k > 0) || !st.rect) return;
   var a = fvHrAxesAlpha(st.k); if (a < 0.01) return;
   var M = st.model, R = M.range, r = st.rect, u = W / 1280, x0 = r.x, y0 = r.y, x1 = r.x + r.w, y1 = r.y + r.h, i;
   var GOLD = 0xE5B53F, PALE = 0xFFF3C4, IVORY = 0xF4ECDC, DARK = 0x110D09;
   g.antialiasing = true; g.textAntialiasing = true;
   st.tips = [];
   // el marco: filete doble
   g.pen = new Pen(fvHrCol(GOLD, 0.85 * a), Math.max(1, 1.1 * u)); g.drawRect(x0, y0, x1, y1);
   g.pen = new Pen(fvHrCol(GOLD, 0.30 * a), Math.max(0.6, 0.6 * u)); g.drawRect(x0 - 4 * u, y0 - 4 * u, x1 + 4 * u, y1 + 4 * u);
   var T = fvHrTicks(R), fN = cpFont("text", Math.max(9, 10.5 * u)), fT = cpFont("display", Math.max(9, 10.5 * u), false, false, Math.max(1, Math.round(1.6 * u))), tl = 5 * u;
   function tx(c) { return x0 + fvHrNorm(R, c, R.m0)[0] * r.w; }
   function ty(m) { return y0 + fvHrNorm(R, R.c0, m)[1] * r.h; }
   // reticula tenue y marcas
   g.pen = new Pen(fvHrCol(GOLD, 0.10 * a), Math.max(0.6, 0.6 * u));
   for (i = 0; i < T.c.length; ++i) if (Math.abs(T.c[i] - Math.round(T.c[i])) < 1e-6 && T.c[i] > R.c0 && T.c[i] < R.c1) g.drawLine(tx(T.c[i]), y0, tx(T.c[i]), y1);
   for (i = 0; i < T.m.length; ++i) if (T.m[i] % 4 === 0 && T.m[i] > R.m0 && T.m[i] < R.m1) g.drawLine(x0, ty(T.m[i]), x1, ty(T.m[i]));
   g.font = fN;
   for (i = 0; i < T.c.length; ++i) {
      var X = tx(T.c[i]), whole = Math.abs(T.c[i] - Math.round(T.c[i])) < 1e-6;
      g.pen = new Pen(fvHrCol(GOLD, 0.85 * a), Math.max(0.8, 0.9 * u)); g.drawLine(X, y1, X, y1 + (whole ? tl : 0.55 * tl));
      if (whole) { var s = fvHrNum(T.c[i], 0); g.pen = new Pen(fvHrCol(PALE, 0.9 * a)); g.drawText(X - fN.width(s) / 2, y1 + tl + fN.ascent + 2 * u, s); }
   }
   for (i = 0; i < T.m.length; ++i) {
      var Y = ty(T.m[i]), big = (T.m[i] % 4 === 0);
      g.pen = new Pen(fvHrCol(GOLD, 0.85 * a), Math.max(0.8, 0.9 * u)); g.drawLine(x0 - (big ? tl : 0.55 * tl), Y, x0, Y);
      if (big) { var sm = fvHrNum(T.m[i], 0); g.pen = new Pen(fvHrCol(PALE, 0.9 * a)); g.drawText(x0 - tl - 4 * u - fN.width(sm), Y + 0.35 * fN.ascent, sm); }
   }
   // arriba: temperaturas (de una enana de ese color)
   var lastX = -1e9;
   for (i = 0; i < T.teff.length; ++i) {
      var Xt = tx(T.teff[i].c), st2 = fvHrThousands(T.teff[i].teff);
      g.pen = new Pen(fvHrCol(GOLD, 0.85 * a), Math.max(0.8, 0.9 * u)); g.drawLine(Xt, y0 - tl, Xt, y0);
      if (Xt - fN.width(st2) / 2 < lastX + 6 * u) continue;
      g.pen = new Pen(fvHrCol(PALE, 0.9 * a)); g.drawText(Xt - fN.width(st2) / 2, y0 - tl - 3 * u, st2); lastX = Xt + fN.width(st2) / 2;
   }
   // los titulos de los ejes (versalitas espaciadas) y los extremos
   g.font = fT;
   var sx = fvTx("hr.x"), stt = fvTx("hr.t"), sy = fvTx("hr.y"), hh = fT.ascent + fT.descent;
   g.pen = new Pen(fvHrCol(GOLD, a));
   var yX = y1 + tl + fN.ascent + 2 * u + hh + 6 * u, yT = y0 - tl - 3 * u - fN.ascent - 7 * u;
   g.drawText((x0 + x1) / 2 - fT.width(sx) / 2, yX, sx);
   g.drawText((x0 + x1) / 2 - fT.width(stt) / 2, yT, stt);
   st.tips.push({ id: "hr-t", x0: x0, y0: yT - hh - 2 * u, x1: x1, y1: y0 - 1 });
   var fS = cpFont("display", Math.max(8, 9 * u), false, false, Math.max(1, Math.round(1.4 * u)));
   g.font = fS; g.pen = new Pen(fvHrCol(GOLD, 0.62 * a));
   g.drawText(x0, yX, fvTx("hr.hot")); g.drawText(x1 - fS.width(fvTx("hr.cool")), yX, fvTx("hr.cool"));
   // el titulo del eje vertical, girado
   var xL = x0 - tl - 4 * u - fN.width("−10") - 10 * u;
   g.font = fT; g.pen = new Pen(fvHrCol(GOLD, a));
   g.translateTransformation(xL, (y0 + y1) / 2); g.rotateTransformation(Math.PI / 2);
   g.drawText(-fT.width(sy) / 2, 0, sy);
   g.font = fS; g.pen = new Pen(fvHrCol(GOLD, 0.62 * a));
   g.drawText(r.h / 2 - fS.width(fvTx("hr.bright")), 0, fvTx("hr.bright")); g.drawText(-r.h / 2, 0, fvTx("hr.faint"));
   g.resetTransformation();
   // el titulo y la cuenta
   var fH = cpFont("display", Math.max(11, 15 * u), false, false, Math.max(2, Math.round(3.2 * u))), ttl = fvTx("hr.title");
   var cnt = fvTx("hr.count", { n: fvHrThousands(M.nOk), N: fvHrThousands(M.n) });
   g.font = fH; g.pen = new Pen(fvHrCol(PALE, a));
   var yH = yT - hh - 12 * u;
   g.drawText((x0 + x1) / 2 - fH.width(ttl) / 2, yH, ttl);
   g.font = fN; g.pen = new Pen(fvHrCol(IVORY, 0.72 * a));
   var yC = y1 + tl + fN.ascent + 2 * u + hh + 6 * u + fN.ascent + 9 * u;
   g.drawText((x0 + x1) / 2 - fN.width(cnt) / 2, yC, cnt);
   st.tips.push({ id: "hr-title", x0: (x0 + x1) / 2 - fH.width(ttl) / 2 - 8 * u, y0: yH - fH.ascent - 4 * u, x1: (x0 + x1) / 2 + fH.width(ttl) / 2 + 8 * u, y1: yH + fH.descent + 2 * u });
   st.tips.push({ id: "hr-title", x0: x0, y0: y1 + 2, x1: x1, y1: yC + fN.descent + 2 * u });
   // los rotulos de region (discretos: marfil en cursiva), solo con el diagrama casi entero
   var aL = a * fvSmooth((st.k - 0.7) / 0.3);
   if (aL > 0.02) {
      var fR = cpFont("text", Math.max(9, 11 * u), false, true), lk = r.x + "|" + r.y + "|" + r.w + "|" + r.h + "|" + FV_LANG;
      if (st.labKey !== lk) { st.labels = fvHrPlaceLabels(M, r, function(key) { return { w: fR.width(fvTx("hr." + key)) + 6 * u, h: fR.ascent + fR.descent + 2 * u }; }, 3 * u); st.labKey = lk; }
      g.font = fR;
      for (i = 0; i < st.labels.length; ++i) {
         var lb = st.labels[i], sL = fvTx("hr." + lb.key);
         g.pen = new Pen(fvHrCol(DARK, 0.9 * aL)); g.drawText(lb.x + 3 * u + 1, lb.y + fR.ascent + u + 1, sL);
         g.pen = new Pen(fvHrCol(IVORY, 0.82 * aL)); g.drawText(lb.x + 3 * u, lb.y + fR.ascent + u, sL);
      }
      // el Sol: un anillo con su punto (el signo ☉ dibujado) y su nombre
      var su = fvHrNorm(R, FV_HR.SUN[0], FV_HR.SUN[1]);
      if (su[0] > 0.02 && su[0] < 0.98 && su[1] > 0.02 && su[1] < 0.98) {
         var sxp = x0 + su[0] * r.w, syp = y0 + su[1] * r.h, rs = 5.5 * u;
         g.pen = new Pen(fvHrCol(DARK, 0.9 * aL), Math.max(2.2, 2.6 * u)); g.drawCircle(sxp, syp, rs);
         g.pen = new Pen(fvHrCol(PALE, 0.95 * aL), Math.max(1, 1.1 * u)); g.drawCircle(sxp, syp, rs);
         g.fillCircle(sxp, syp, Math.max(1, 1.3 * u), new Brush(fvHrCol(PALE, 0.95 * aL)));
         g.font = fR; var sS = fvTx("hr.sun");
         g.pen = new Pen(fvHrCol(DARK, 0.9 * aL)); g.drawText(sxp - rs - 5 * u - fR.width(sS) + 1, syp + 0.35 * fR.ascent + 1, sS);
         g.pen = new Pen(fvHrCol(PALE, 0.9 * aL)); g.drawText(sxp - rs - 5 * u - fR.width(sS), syp + 0.35 * fR.ascent, sS);
         st.tips.push({ id: "hr-sun", x0: sxp - rs - 6 * u - fR.width(sS), y0: syp - rs - 2 * u, x1: sxp + rs + 2 * u, y1: syp + rs + 2 * u });
      }
   }
   // la estrella bajo el cursor: anillo y su nombre con sus dos numeros (si su ficha ya esta abierta, no: diria lo mismo dos veces)
   var hovCard = !!(P && P.sel && P.sel.kind === "star" && P.sel.i === st.hover && o && o.ui && !o.ui.cardClosed && !o.ui.hideCard);
   if (st.hover >= 0 && M.ok[st.hover] && !hovCard) {
      var hx = -1, hy = -1; for (i = 0; i < st.nVis; i += 3) if (st.vis[i] === st.hover) { hx = st.vis[i + 1]; hy = st.vis[i + 2]; break; }
      if (hx >= 0) {
         g.pen = new Pen(fvHrCol(DARK, 0.9 * a), Math.max(2.4, 3 * u)); g.drawCircle(hx, hy, 8 * u);
         g.pen = new Pen(fvHrCol(PALE, a), Math.max(1.1, 1.3 * u)); g.drawCircle(hx, hy, 8 * u);
         if (st.hoverI !== st.hover) { st.hoverI = st.hover; st.hoverTxt = fvHrHoverText(st.scene, M, st.hover); }
         var fC = cpFont("text", Math.max(10, 12 * u)), wC = fC.width(st.hoverTxt) + 14 * u, hC = fC.ascent + fC.descent + 8 * u, bx = hx + 13 * u, by = hy - hC - 6 * u;
         if (bx + wC > W - 6) bx = hx - 13 * u - wC; if (by < 6) by = hy + 12 * u;
         g.fillRect(bx, by, bx + wC, by + hC, new Brush(fvHrCol(DARK, 0.88 * a)));
         g.pen = new Pen(fvHrCol(GOLD, 0.8 * a), Math.max(0.8, 0.9 * u)); g.drawRect(bx, by, bx + wC, by + hC);
         g.font = fC; g.pen = new Pen(fvHrCol(IVORY, a)); g.drawText(bx + 7 * u, by + 4 * u + fC.ascent, st.hoverTxt);
      }
   }
   if (painter.stats) painter.stats.hr = { k: st.k, inDiagram: st.nVis / 3, nOk: M.nOk, n: M.n, rect: [r.x, r.y, r.w, r.h], labels: st.labels ? st.labels.map(function(l) { return l.key; }) : [] };
}
// el rotulo de la estrella bajo el cursor: su nombre (el titulo de su ficha), M y BP−RP
function fvHrHoverText(scene, M, i) {
   var name = "";
   try { var C = (typeof fvCardContent === "function") ? fvCardContent(scene, { kind: "star", i: i }, FV_LANG) : null; if (C && C.title) name = String(C.title); } catch (e) { name = ""; }
   var dec = function(x, k) { return fvHrNum(x, k); };
   return (name ? name + "  ·  " : "") + "M " + dec(M.absMag[i], 1) + "  ·  BP − RP " + dec(M.color[i], 2);
}

// ---------------------------------------------------------------------------
// EL RATON
// ---------------------------------------------------------------------------
// el cursor en (x, y) del fotograma: apunta la estrella de debajo (para el anillo) y devuelve el tooltip que toque ("" = ninguno)
function fvHrTipAt(D, x, y) {
   var st = D.hr; if (!st || !(st.k > 0)) return "";
   var u = (st.W || 1280) / 1280;
   st.hover = (st.dir === 0 && st.k >= 1) ? fvHrPickIn(st.vis, st.nVis, x, y, FV_HR.PICK_PX * u) : -1;
   if (st.hover >= 0) return "";
   var T = st.tips || [];
   for (var i = 0; i < T.length; ++i) if (x >= T[i].x0 && x <= T[i].x1 && y >= T[i].y0 && y <= T[i].y1) {
      if (T[i].id === "hr-title") {
         var en = FV_TX.en["hr.tipTitle"] + (st.model.dereddened ? FV_TX.en["hr.tipDust"] : ""), es = FV_TX.es["hr.tipTitle"] + (st.model.dereddened ? FV_TX.es["hr.tipDust"] : "");
         return "<html>" + (FV_LANG === "es" ? es + "<br><i>" + en + "</i>" : en + "<br><i>" + es + "</i>") + "</html>";
      }
      return fvTipBoth(T[i].id === "hr-t" ? "hr.tipT" : "hr.tipSun");
   }
   return "";
}
// un clic con el diagrama puesto: sobre un punto, su ficha (la de siempre); en el resto, nada (ni elegir estrellas de debajo ni mover la nave)
function fvHrClick(D, x, y) {
   var st = D.hr; if (!st) return false;
   var u = (st.W || 1280) / 1280, i = (st.k >= 1) ? fvHrPickIn(st.vis, st.nVis, x, y, FV_HR.PICK_PX * u) : -1;
   if (i >= 0) D.select({ kind: "star", i: i }, true);
   return true;
}
// donde cae la reticula de la ficha de la estrella i con el diagrama puesto: [x, y] en px del fotograma | null (no esta en el diagrama)
function fvHrAnchor(painter, i) {
   var st = FV_HR_ST;
   if (!st || !painter || st.scene !== painter.scene || !(st.k > 0) || !st.model.ok[i]) return null;
   for (var k = 0; k < st.nVis; k += 3) if (st.vis[k] === i) return [st.vis[k + 1], st.vis[k + 2]];
   return null;
}
