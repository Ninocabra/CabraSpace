// ============================================================================
// FieldVoyager/src/ui/fv_planets3d.js — BLENDER 1: LOS EXOPLANETAS COMO MUNDOS (5-nov-2026)
// ----------------------------------------------------------------------------
// Hoy un exoplaneta es una mancha negra sobre su estrella (fv_exo_view.js) y su portilla de la ficha muestra la foto. Con esto el planeta
// se pinta como un mundo: su FAMILIA (src/science/fv_sci_planet.js: rocoso, supertierra, neptuno, gigante, jupiter caliente, por radio y
// Teq con umbrales citados), su COLOR por temperatura (clases de Sudarsky para los gigantes…), la luz de SU estrella (cuerpo negro), su
// ATMOSFERA (el anillo de luz a contraluz) y su INCANDESCENCIA (cuerpo negro del lado de dia y de noche, con la redistribucion de
// Cowan & Agol 2011: solo brilla donde la fisica dice), con la FASE que da el angulo estrella-planeta-camara.
//
// Recursos: blender/planetas.py -> blender/build_planetas_rsc.py -> rsc/planetas/ (manifest.json + s64/s160/s384). Al paquete van solo PNG
// (CPD); Blender es de desarrollo. Por familia: albedo gris, silueta, y por fase (0..180 cada 15°) sombreado, luz de atmosfera y
// resplandor de dia/noche. EN TIEMPO DE EJECUCION, una vez por planeta y nivel (≈ 13 composiciones de 6 dibujos en mapas pequeños):
//     P_α = tinte × albedo × sombreado_α  (Multiply)  + atmosfera_α (Add)  + resplandor_dia_α × color_dia + resplandor_noche_α × color_noche
// y en cada fotograma 2 dibujos con giro y escala: la silueta (SourceOver: tapa lo de detras, p. ej. la estrella en el transito) y las dos
// fases vecinas fundidas en un mapa pequeño (fvPl3dBlend) sumadas con Add a opacidad 1. Por que asi y no un sprite por fase y color: el color es continuo con la
// temperatura (un sprite por color multiplicaria el paquete) y la fase se funde sin saltos; y no sombreado por pixel en JS: en PJSR un
// bucle por pixel de 300 × 300 cuesta decenas de ms, y las composiciones nativas (Graphics) cuestan decimas.
// Giro: el sprite tiene la estrella a la DERECHA (+x); se gira para ponerla donde este en la pantalla.
// FV_PL3D.ON = false: nada cambia (ninguna funcion pinta; los ganchos de la fase B lo comprueban primero). ES5.
// ============================================================================

var FV_PL3D = {
   ON: true,               // BANDERA (ENCENDIDA el 10-nov, Blender 2: PL-4/5/6/8 y la portilla limpia, medidos): false = los exoplanetas de antes, pixel identicos
   RINGS: false,           // anillos (solo gigantes frios): ningun exoplaneta tiene anillos confirmados -> apagado
   ORBIT_S: 24,            // la portilla: una vuelta de orbita cada 24 s (fases visibles); el transito sigue con su reloj (FV_EXOV.LOOP_S)
   PORT_R: 0.62,           // radio del planeta en la portilla (fraccion del radio de la portilla)
   UPSCALE_MAX: 1.25,      // se usa el nivel menor cuyo planeta mide ≥ r / 1,25 (ampliar mas ablanda)
   SETS_MAX: 6,            // juegos compuestos que se guardan (planeta × nivel; Blender 3: 4 -> 6, la portilla, el recuadro y el transito de dos planetas)
   // (PL-1, 5-nov) en el TRANSITO, un planeta de ≤ 20 px de radio se pinta SOLO con su silueta: la luz de la atmosfera a contraluz (capa at_a)
   // sumada (Add) sobre el disco brillante de la estrella satura y sale un aro blanco duro (montaje_planetas_app.png filas 1-3); a esa escala
   // el anillo real es invisible frente a la estrella: ahi se deja la mancha de hoy (fvPl3dOnStar -> null). Por encima de 20 px se pinta el
   // mundo con su atmosfera. 0 = sin corte (el rojo de la prueba)
   TRANSIT_SIL_PX: 20
};
var FV_PL3D_ROOT = (function() { try { return (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/").replace(/\/src\/ui\/?$/, ""); } catch (e) { return ""; } })();
var FV_PL3D_STORE = { man: null, tried: false, err: "", bmp: {}, sets: {}, setKeys: [] };
function fvPl3dLog(s) { try { if (typeof fvLog === "function") fvLog("[pl3d] " + s); } catch (e) {} }

function fvPl3dReady() {
   var S = FV_PL3D_STORE;
   if (!S.tried) {
      S.tried = true;
      try {
         var p = FV_PL3D_ROOT + "/rsc/planetas/manifest.json";
         if (!File.exists(p)) throw new Error("missing " + p);
         S.man = JSON.parse(File.readTextFile(p));
         if (!S.man || !S.man.levels || !S.man.phases) throw new Error("bad manifest");
      } catch (e) { S.man = null; S.err = String(e); fvPl3dLog("planet sprites not available, the drawn planet stays: " + S.err); }
   }
   return !!S.man;
}
function fvPl3dActive() { return !!FV_PL3D.ON && fvPl3dReady() && typeof fvsPlanetLook === "function"; }

// el aspecto del planeta (fisica pura) + la clave de su juego
// (el resplandor de dia: la capa gd tiene maximo 1 en el punto subestelar y forma cos^p; su media en el hemisferio es 1/(p+1): se multiplica
// por (p+1) para que el brillo MEDIO del lado de dia sea el de T_dia)
function fvPl3dLook(row, tr) {
   fvPl3dReady();
   // (PL-4) la familia se sabe antes de mirar el manifiesto: la forma del resplandor (glow_p) y la media del albedo entran en la exposicion
   var fam0 = fvsPlanetLook(row || {}, tr || null).fam, fm0 = FV_PL3D_STORE.man ? FV_PL3D_STORE.man.families[fam0] : null;
   var L = fvsPlanetLook(row || {}, tr || null, fm0 ? { glowP: fm0.glow_p, albMean: fm0.alb_mean } : null), fm = FV_PL3D_STORE.man ? FV_PL3D_STORE.man.families[L.fam] : null, p1 = 1 + (fm ? fm.glow_p : 0);
   L.paint = { day: fvsPlanetPaint([L.glowDay[0] * p1, L.glowDay[1] * p1, L.glowDay[2] * p1]), night: fvsPlanetPaint(L.glowNight) };
   L.key = L.fam + ":" + L.tint.map(function(v) { return v.toFixed(3); }).join(",") + ":" + L.paint.day.col.join(",") + ":" + L.paint.day.op.toFixed(3) + ":" + L.paint.night.col.join(",") + ":" + L.paint.night.op.toFixed(3);
   return L;
}
// (Blender 3 · coste) el lado del juego a la medida: si el nivel es mayor que lo que ocupa el planeta en pantalla (2·r·encuadre, redondeado a
// multiplos de 16 hacia arriba), el juego se prepara a ese lado (menos pixeles por fotograma). null = el del nivel
function fvPl3dExactN(lv, rReal) {
   if (!FV_PL3D.EXACT || !FV_PL3D_STORE.man || !(rReal > 0)) return null;
   var L = FV_PL3D_STORE.man.levels[lv], nT = 16 * Math.ceil(2 * rReal * FV_PL3D_STORE.man.frame / 16);
   return (L && nT < L.size - 8) ? nT : null;
}
// el nivel para un planeta de radio rPx en pantalla
function fvPl3dLevel(rPx) {
   var lv = FV_PL3D_STORE.man.levels, best = null, top = null;
   for (var k in lv) {
      var r = lv[k].planet_r_px;
      if (top === null || r > lv[top].planet_r_px) top = k;
      if (r >= rPx / FV_PL3D.UPSCALE_MAX && (best === null || r < lv[best].planet_r_px)) best = k;
   }
   return best !== null ? best : top;
}
function fvPl3dBitmap(lv, fam, lay) {
   var S = FV_PL3D_STORE, id = lv + "/" + fam + "/" + lay;
   if (S.bmp[id] !== undefined) return S.bmp[id];
   var L = S.man.levels[lv], m = L.families[fam] ? L.families[fam][lay] : null, b = null;
   if (m) { try { var p = FV_PL3D_ROOT + "/rsc/planetas/" + (m.dir || L.dir) + "/" + m.file; if (File.exists(p)) b = new Bitmap(p); else fvPl3dLog("missing " + p); } catch (e) { fvPl3dLog("cannot read " + id + ": " + e); } }
   S.bmp[id] = b;
   return b;
}
function fvPl3dScale(c, k) { return [Math.round(c[0] * k), Math.round(c[1] * k), Math.round(c[2] * k)]; }
function fvPl3dRgb(c) { return ((0xff000000 | (c[0] << 16) | (c[1] << 8) | c[2]) >>> 0); }
// una capa gris multiplicada por un color (los dos opacos: el producto es exacto) -> Bitmap n × n
function fvPl3dTinted(src, col, n) {
   var b = new Bitmap(n, n, BitmapFormat.ARGB32); b.fill(fvPl3dRgb(col));
   var g = new Graphics(b);
   try { g.smoothInterpolation = true; g.compositionOperator = CompositionOp_Multiply; g.drawScaledBitmap(0, 0, n, n, src); } finally { g.end(); }
   return b;
}

// ---------------------------------------------------------------------------
// EL JUEGO de un planeta a un nivel: las 13 fases compuestas + la silueta (+ el anillo). Una vez; se guardan los FV_PL3D.SETS_MAX ultimos
// ---------------------------------------------------------------------------
// (Blender 3 · coste) nT (opcional): el lado del juego a la medida de la pantalla (menor que el nivel: se reduce una vez al preparar, y cada
// fotograma trabaja con menos pixeles y sin reescalar). FV_PL3D.TEX_SCREEN false = la textura dentro de las fases, girando con la estrella
// (Blender 1-2: el ROJO de D3)
FV_PL3D.TEX_SCREEN = true; FV_PL3D.EXACT = true;
function fvPl3dSet(look, lv, nT) {
   var S = FV_PL3D_STORE, key = look.key + "@" + lv + (nT ? ":" + nT : "") + (FV_PL3D.TEX_SCREEN ? "" : ":texin");
   if (S.sets[key]) return S.sets[key];
   while (S.setKeys.length >= FV_PL3D.SETS_MAX) delete S.sets[S.setKeys.shift()];
   var t0 = (typeof fvNowMs === "function") ? fvNowMs() : Date.now(), man = S.man, L = man.levels[lv], fam = look.fam, n = nT || L.size, ph = man.phases;
   var alb = fvPl3dBitmap(lv, fam, "alb"), sil = fvPl3dBitmap(lv, fam, "sil"), P = look.paint, out = [];
   if (!alb || !sil) return null;
   if (n !== L.size) { var sb = new Bitmap(n, n, BitmapFormat.ARGB32); sb.fill(0x00000000); var gs = new Graphics(sb); try { gs.smoothInterpolation = true; gs.compositionOperator = CompositionOp_Source; gs.drawScaledBitmap(0, 0, n, n, sil); } finally { gs.end(); } sil = sb; }
   // tinte: el color del albedo×luz, dividido por la media de la textura (la textura esta normalizada a maximo 1); sin pasar de 1
   var fm = man.families[fam], k = 1 / Math.max(0.2, fm.alb_mean), tl = [look.tint[0] * k, look.tint[1] * k, look.tint[2] * k];
   var mx = Math.max(tl[0], tl[1], tl[2]), sc = mx > 1 ? 1 / mx : 1;
   var tint = [0, 1, 2].map(function(i) { return Math.round(255 * fvsSrgbGamma(tl[i] * sc)); });
   // (Blender 3 · D3) la TEXTURA del albedo ya no va dentro de las fases (que giran con la estrella): las fases llevan el tinte LISO y la textura
   // se multiplica en la pantalla con el eje de giro fijo (fvPl3dDraw, o.band). Producto igual que antes: (tinte · sombreado) · textura
   var albW = FV_PL3D.TEX_SCREEN ? fvPl3dAlbW(lv, fam, alb, n, man.frame) : null, albT = FV_PL3D.TEX_SCREEN ? null : fvPl3dTinted(alb, tint, n);
   for (var i = 0; i < ph.length; ++i) {
      var a = ("00" + ph[i]).slice(-3), sh = fvPl3dBitmap(lv, fam, "sh_a" + a), at = fvPl3dBitmap(lv, fam, "at_a" + a);
      if (look.tone && albW) { out.push(fvPl3dComposeLin(look, lv, fam, a, n, [tl[0] * sc, tl[1] * sc, tl[2] * sc], fm)); continue; }
      var b = new Bitmap(n, n, BitmapFormat.ARGB32); b.fill(albT ? 0xff000000 : fvPl3dRgb(tint));
      var g = new Graphics(b);
      try {
         g.smoothInterpolation = true;
         if (albT) { g.compositionOperator = CompositionOp_SourceOver; g.drawBitmap(0, 0, albT); }
         if (sh) { g.compositionOperator = CompositionOp_Multiply; g.drawScaledBitmap(0, 0, n, n, sh); }
         g.compositionOperator = CompositionOp_Add;
         if (at) g.drawScaledBitmap(0, 0, n, n, at);
         // la opacidad va DENTRO del color (no g.opacity): con Add y opacidad < 1 Qt satura ANTES de aplicarla, dst + op·(min(255, dst + src) − dst),
         // y sobre algo claro suma de menos (medido en tests/fv_pl3d_probe.js: +31 en vez de +62 sobre gris 144). Con opacidad 1 el Add es exacto.
         if (P.day.op > 1 / 512) { var gd = fvPl3dBitmap(lv, fam, "gd_a" + a); if (gd) g.drawScaledBitmap(0, 0, n, n, fvPl3dTinted(gd, fvPl3dScale(P.day.col, P.day.op), gd.width)); }
         if (P.night.op > 1 / 512) { var gn = fvPl3dBitmap(lv, fam, "gn_a" + a); if (gn) g.drawScaledBitmap(0, 0, n, n, fvPl3dTinted(gn, fvPl3dScale(P.night.col, P.night.op), gn.width)); }
      } finally { g.end(); }
      out.push(b);
   }
   var set = { key: key, lv: lv, n: n, rpx: n / 2 / man.frame, phases: ph, P: out, sil: sil, ring: (fm.ring ? fvPl3dBitmap(lv, fam, "ring") : null), ringFrame: fm.ring ? fm.ring.frame : 0,
               frame: man.frame, ms: ((typeof fvNowMs === "function") ? fvNowMs() : Date.now()) - t0, tint: tint, albW: albW, atm: !!fm.atm, ringS: n / L.size };
   S.sets[key] = set; S.setKeys.push(key);
   return set;
}
// (Blender 3 · D3) la textura del albedo para MULTIPLICAR en la pantalla: el gris del albedo dentro del disco y BLANCO fuera (multiplicar por
// blanco no cambia nada: lo de detras, la estrella o el cristal, queda igual). Una vez por nivel y familia
function fvPl3dAlbW(lv, fam, alb, n, frame) {
   var S = FV_PL3D_STORE, id = lv + "/" + fam + "/" + n;
   S.albW = S.albW || {};
   if (S.albW[id]) return S.albW[id];
   var b = new Bitmap(n, n, BitmapFormat.ARGB32); b.fill(0xffffffff);
   var g = new Graphics(b); try { g.smoothInterpolation = true; g.drawScaledBitmap(0, 0, n, n, alb); } finally { g.end(); }
   // (Blender 3) COPIA de los pixeles y vuelta con .set() con el Bitmap vivo: la vista de pixelData() apunta a la memoria nativa y PixInsight
   // se cerraba en seco a mitad de la bateria (10-nov, salida 0 y el log cortado en sitios distintos; CabraBase/pjsr/la-vista-de-pixeldata-muere-con-su-bitmap.md)
   var A = new Uint32Array(b.pixelData()).slice(), R = n / 2 / (frame || 1.15), c = n / 2;
   for (var y = 0; y < n; ++y) for (var x = 0; x < n; ++x) {
      var dx = x + 0.5 - c, dy = y + 0.5 - c, m = Math.max(0, Math.min(1, R - Math.sqrt(dx * dx + dy * dy) + 0.5)), i = y * n + x;
      var v = Math.round((A[i] & 255) * m + 255 * (1 - m));
      A[i] = (0xff000000 | (v << 16) | (v << 8) | v) >>> 0;
   }
   new Uint32Array(b.pixelData()).set(A);
   S.albW[id] = b;
   return b;
}
// (Blender 3 · D2) una fase de un mundo CALIENTE compuesta pixel a pixel en LUZ LINEAL y llevada a la pantalla con el tono que conserva el tono
// (fvsPlanetToneK: mismo factor en R, G y B, hombro arcsinh). lin = tinte·sombreado + atmosfera + resplandor_dia·color + resplandor_noche·color
// (todo × ap = 1/alb_mean: la textura, media alb_mean, se multiplica despues en la pantalla). La atmosfera se guardo como «suma en pantalla»
// sobre un albedo ALB_REF 0,6 (build_planetas_rsc.py): se deshace con esa misma referencia
var FV_PL3D_LUT = null;
function fvPl3dLuts() {
   if (FV_PL3D_LUT) return FV_PL3D_LUT;
   var lin = new Float64Array(256), enc = new Uint8Array(4097), e06 = new Float64Array(256), dec = new Float64Array(2049), i;
   for (i = 0; i < 256; ++i) { lin[i] = fvsSrgbLinear(i / 255); e06[i] = fvsSrgbGamma(0.6 * lin[i]); }
   for (i = 0; i <= 4096; ++i) enc[i] = Math.round(255 * fvsSrgbGamma(i / 4096));
   for (i = 0; i <= 2048; ++i) dec[i] = fvsSrgbLinear(i / 2048);
   return (FV_PL3D_LUT = { lin: lin, enc: enc, e06: e06, dec: dec });
}
function fvPl3dScaledPx(src, n) {
   if (!src) return null;
   var b = new Bitmap(n, n, BitmapFormat.ARGB32); b.fill(0xff000000);
   var g = new Graphics(b); try { g.smoothInterpolation = true; g.drawScaledBitmap(0, 0, n, n, src); } finally { g.end(); }
   var A = new Uint32Array(b.pixelData()).slice();
   b.clear();            // usa b DESPUES de copiar (vivo durante el .slice()) y suelta ya su memoria nativa (4 por fase y juego)
   return A;
}
function fvPl3dComposeLin(look, lv, fam, a, n, tl, fm) {
   var LU = fvPl3dLuts(), LIN = LU.lin, ENC = LU.enc, ap = look.tone.ap || 1, p1 = 1 + (fm ? fm.glow_p : 0);
   var SH = fvPl3dScaledPx(fvPl3dBitmap(lv, fam, "sh_a" + a), n), AT = fvPl3dScaledPx(fvPl3dBitmap(lv, fam, "at_a" + a), n);
   var GD = fvPl3dScaledPx(fvPl3dBitmap(lv, fam, "gd_a" + a), n), GN = fvPl3dScaledPx(fvPl3dBitmap(lv, fam, "gn_a" + a), n);
   var T = [tl[0], tl[1], tl[2]], D = [0, 1, 2].map(function(c) { return look.glowDay[c] * p1 * ap; }), N = [0, 1, 2].map(function(c) { return look.glowNight[c] * ap; });
   // la atmosfera dispersa la luz que le llega: se guardo para un albedo×luz de 0,6 (ALB_REF); aqui escala con el tinte de ESTE mundo y su
   // exposicion (en un ultracaliente oscuro, sumada tal cual, lavaba su color con una luz neutra que no tiene)
   var AS = [T[0] / 0.6, T[1] / 0.6, T[2] / 0.6];
   // los pixeles se escriben en memoria JS y pasan al Bitmap al final con .set() (ver fvPl3dAlbW)
   var O = new Uint32Array(n * n), tone = look.tone, A0 = 0.6;
   for (var i0 = 0; i0 < n * n; ++i0) O[i0] = 0xff000000;
   for (var i = 0; i < n * n; ++i) {
      var s = SH ? LIN[SH[i] & 255] : 0, gd = GD ? LIN[GD[i] & 255] : 0, gn = GN ? LIN[GN[i] & 255] : 0;
      var r = T[0] * s + D[0] * gd + N[0] * gn, gg = T[1] * s + D[1] * gd + N[1] * gn, bb = T[2] * s + D[2] * gd + N[2] * gn;
      if (AT) { var p = AT[i], e0 = LU.e06[SH ? SH[i] & 255 : 0], as = A0 * s, DC = LU.dec;
         r += AS[0] * Math.max(0, DC[Math.min(2048, Math.round(2048 * (((p >>> 16) & 255) / 255 + e0)))] - as); gg += AS[1] * Math.max(0, DC[Math.min(2048, Math.round(2048 * (((p >>> 8) & 255) / 255 + e0)))] - as); bb += AS[2] * Math.max(0, DC[Math.min(2048, Math.round(2048 * ((p & 255) / 255 + e0)))] - as); }
      var m = Math.max(r, gg, bb);
      if (!(m > 1e-7)) continue;
      var k = fvsPlanetToneK(m, tone) * 4096;
      O[i] = (0xff000000 | (ENC[Math.min(4096, Math.round(r * k))] << 16) | (ENC[Math.min(4096, Math.round(gg * k))] << 8) | ENC[Math.min(4096, Math.round(bb * k))]) >>> 0;
   }
   var b = new Bitmap(n, n, BitmapFormat.ARGB32);
   new Uint32Array(b.pixelData()).set(O);
   return b;
}

// las dos fases vecinas FUNDIDAS en un mapa pequeño (Source + SourceOver con opacidad: exacto, los dos son opacos), w a 1/32; se guarda la
// ultima. (Fundirlas en la pantalla con Add y opacidades 1 − w y w no vale: Qt satura antes de la opacidad y a mitad de fundido lo claro
// bajaba ~11 %.)
function fvPl3dBlend(set, i0, w) {
   var wq = Math.round(w * 32) / 32;
   if (wq <= 0) return set.P[i0];
   if (wq >= 1) return set.P[i0 + 1];
   var B = set._blend;
   if (B && B.i0 === i0 && B.wq === wq) return B.bmp;
   if (!B) B = set._blend = { bmp: new Bitmap(set.n, set.n, BitmapFormat.ARGB32) };
   var g = new Graphics(B.bmp);
   try { g.compositionOperator = CompositionOp_Source; g.drawBitmap(0, 0, set.P[i0]); g.compositionOperator = CompositionOp_SourceOver; g.opacity = wq; g.drawBitmap(0, 0, set.P[i0 + 1]); } finally { g.end(); }
   B.i0 = i0; B.wq = wq;
   return B.bmp;
}

// ---------------------------------------------------------------------------
// PINTAR un planeta: centro (cx, cy), radio rPx del disco, fase alpha (grados), rot = angulo en pantalla hacia la estrella (rad, y abajo)
// o = { rings: bool } -> stats { lv, ms, prep, i0, w } o null si no pinta
// ---------------------------------------------------------------------------
function fvPl3dDraw(g, cx, cy, rPx, look, alphaDeg, rot, o) {
   if (!fvPl3dActive() || !look || !(rPx > 0)) return null;
   // o.pxScale: la escala del HUD (fvHudK) bajo la que se pinta: el nivel se elige por los pixeles REALES (a 6K el HUD va ×4 y un nivel
   // elegido por las unidades del HUD se ampliaba ×2)
   var t0 = (typeof fvNowMs === "function") ? fvNowMs() : Date.now(), lv = fvPl3dLevel(rPx * ((o && o.pxScale > 0) ? o.pxScale : 1)), set = fvPl3dSet(look, lv, fvPl3dExactN(lv, rPx * ((o && o.pxScale > 0) ? o.pxScale : 1)));
   if (!set) return null;
   var prep = set._shown ? 0 : set.ms; set._shown = true;
   var ph = set.phases, a = Math.max(0, Math.min(180, alphaDeg)), i0 = 0;
   while (i0 < ph.length - 2 && a > ph[i0 + 1]) ++i0;
   var w = (ph[i0 + 1] > ph[i0]) ? Math.max(0, Math.min(1, (a - ph[i0]) / (ph[i0 + 1] - ph[i0]))) : 0;
   var s = rPx / set.rpx, h = set.n / 2, M0 = g.transformationMatrix, op0 = g.opacity, cop = g.compositionOperator, sm = g.smoothInterpolation;
   var nb = (o && o.nightBoost) ? fvPl3dNightBoost(look, a) : 0;
   try {
      g.translateTransformation(cx, cy); g.rotateTransformation(-rot); g.scaleTransformation(s, s);
      g.smoothInterpolation = true; g.opacity = 1;
      g.compositionOperator = CompositionOp_SourceOver; g.drawBitmap(-h, -h, set.sil);
      if (!(o && o.silOnly)) { g.compositionOperator = CompositionOp_Add; var bl = fvPl3dBlend(set, i0, w); g.drawBitmap(-h, -h, bl);
         // (PL-5) el lado nocturno de un mundo sin aire: la MISMA imagen sumada otra vez, hasta dos veces (nb 0..2: ×3 en sRGB, ≈ ×11 en luz).
         // La forma de la media luna es la fisica; solo sube la exposicion, y la portilla lo dice con un rotulo (no es fisico).
         // Qt con opacidad < 1: dst + op·(min(255, dst+src) − dst), un fundido hacia la suma recortada (aqui es lo que se quiere)
         for (var nr = nb; nr > 0.004; nr -= 1) { g.opacity = Math.min(1, nr); g.drawBitmap(-h, -h, bl); } g.opacity = 1;     // (Blender 3: hasta nb veces, como la web)
         // (Blender 3 · D3) la TEXTURA (bandas, crateres) con el EJE DE GIRO FIJO: o.band = angulo en pantalla de las bandas (fvsPlanetBandAngle);
         // sin o.band, gira con la estrella como antes. Multiply sobre la pantalla: blanco fuera del disco (no toca lo de detras). Por debajo de 4 px
         // reales la textura no se ve: no se pinta (coste)
         var band = (o && o.band !== undefined && o.band !== null) ? o.band : rot;
         if (set.albW && rPx * ((o && o.pxScale > 0) ? o.pxScale : 1) >= 4) {
            g.transformationMatrix = M0; g.translateTransformation(cx, cy); g.rotateTransformation(-band); g.scaleTransformation(s, s);
            g.compositionOperator = CompositionOp_Multiply; g.drawBitmap(-h, -h, set.albW);
         } }
      if (FV_PL3D.RINGS && (o && o.rings !== undefined ? o.rings : true) && set.ring && look.fam === "giant") {
         // el anillo (con el planeta en holdout) DESPUES del planeta; su brillo sigue la fase (lo iluminado que se ve)
         g.transformationMatrix = M0; g.translateTransformation(cx, cy); g.rotateTransformation(-rot); g.scaleTransformation(s * (set.ringS || 1), s * (set.ringS || 1));
         var rw = set.ring.width, rh = set.ring.height;
         g.compositionOperator = CompositionOp_SourceOver; g.opacity = 0.35 + 0.65 * fvsPlanetLitFraction(a);
         g.drawBitmap(-rw / 2, -rh / 2, set.ring);
      }
   } finally { g.transformationMatrix = M0; g.opacity = op0; g.compositionOperator = cop; g.smoothInterpolation = sm; }
   return { lv: lv, ms: ((typeof fvNowMs === "function") ? fvNowMs() : Date.now()) - t0, prep: prep, i0: i0, w: w, alpha: a, rot: rot, boost: nb, night: fvPl3dNightSide(look, a),
            band: (o && o.band !== undefined && o.band !== null) ? o.band : rot, pxScale: (o && o.pxScale > 0) ? o.pxScale : 1 };
}
// (PL-5, 10-nov) un mundo SIN AIRE (rocoso, supertierra: sin el anillo de luz de una atmosfera gruesa) a fase alta es una media luna finisima
// y tenue (a 165° se ilumina el 1,7 % del disco, con la luz rasante del terminador) y la portilla quedaba negra. Ayuda NO fisica, marcada
// en la portilla: entre NIGHT_A0 y NIGHT_A1 la exposicion sube hasta ×(1 + NIGHT_MAX) en sRGB (la media luna se ve; su forma sigue la
// fisica). Con ×2 el rocoso de prueba a 165° llegaba a 62 de 255 (medido, P10): poco; con ×3, ~90 (Blender 2). Blender 3: la textura se multiplica en la pantalla y el juego va a la medida: ×3,5 daba 89 (P10); ×3,7. Mismo calculo en web/fw_pl_view.js.
// NIGHT_A1 = 0 la apaga (el ROJO de la prueba)
FV_PL3D.NIGHT_A0 = 140; FV_PL3D.NIGHT_A1 = 160; FV_PL3D.NIGHT_MAX = 2.7; FV_PL3D.NIGHT_FAM = { rocky: true, superearth: true };
function fvPl3dNightBoost(look, a) {
   if (!look || !FV_PL3D.NIGHT_FAM[look.fam] || !(FV_PL3D.NIGHT_A1 > FV_PL3D.NIGHT_A0)) return 0;
   var x = Math.max(0, Math.min(1, (a - FV_PL3D.NIGHT_A0) / (FV_PL3D.NIGHT_A1 - FV_PL3D.NIGHT_A0)));
   return FV_PL3D.NIGHT_MAX * x * x * (3 - 2 * x);
}
// ¿se ve el lado nocturno? (el rotulo de la portilla: con la ayuda puesta, o cualquier mundo casi a contraluz)
function fvPl3dNightSide(look, a) { return fvPl3dNightBoost(look, a) > 0.02 || a >= 172; }
// el factor de exposicion en LUZ de la ayuda: (1 + nb) en sRGB ≈ (1 + nb)^2,2 en lineal
function fvPl3dBoostFactor(nb) { return Math.pow(1 + Math.max(0, nb), 2.2); }
// el rotulo de la portilla (cx, cy, r = la portilla; st = lo que devolvio fvPl3dDraw): «LADO NOCTURNO» encima del planeta y, con la ayuda,
// «exposición ×N» debajo. Texto corto: cabe en la cuerda de la portilla a 0,72–0,80 r
// name (opcional): el nombre del planeta, arriba, cuando la portilla es la de su ESTRELLA (la ficha es de la estrella: que se sepa que el
// mundo es su planeta). De noche manda el rotulo del lado nocturno
// (Blender 3 · D6) los rotulos ya no van rectos (llegaban a r ≈ 60 y pisaban el aro del bisel, 59-62): van CURVADOS por dentro del cristal,
// entre el planeta (0,62·r × 1,15 del encuadre = 0,71·r) y el bisel, como lo grabado en un dial: arriba «lado nocturno» (letras hacia fuera)
// y abajo «exposición ×N» (letras de pie). Donde va un rotulo no se pinta ese brazo de la cruz (devuelve { top, bottom } para fvPorthole):
// ningun rotulo pisa el bisel ni la cruz. Nunca sustituye al nombre del planeta (D4: el nombre va con el recuadro de la ficha de la estrella).
// Mismo dibujo en web/fw_pl_view.js (fwPlLabels)
// (Blender 4 · D6 en PI) los rotulos curvos se leian mal en la app (~5 px por letra, flecos de color del suavizado por subpixel del texto
// sobre un mapa opaco, dorado sobre el resplandor pardo). Ahora: (1) letra mas grande (FV_PL3D.LABEL_K de r), (2) cada rotulo se pinta UNA
// vez en un mapa ARGB transparente a la resolucion REAL (sd = escala del HUD): sobre un mapa con alfa Qt suaviza en gris, sin flecos, y
// (3) lleva un halo oscuro alrededor de cada letra (contraste sobre cualquier fondo: el resplandor, la estrella, la barra del escaner).
// Se guarda en FV_PL3D_LABC (por texto, tamaño, radio, lado, color y escala): el fotograma solo hace un drawBitmap.
// FV_PL3D.LABEL_HQ false = lo de Blender 3 (texto directo; el ROJO de P25)
FV_PL3D.LABEL_HQ = true; FV_PL3D.LABEL_K = 0.19; FV_PL3D.LABEL_HALO = 0xd0060504;
var FV_PL3D_LABC = { m: {}, keys: [] };
function fvPl3dArcGlyphs(g, cx, cy, rb, s, f, col, top, thC, halo, hw) {
   var w = f.width(s), th = w / rb, dir = top ? 1 : -1, c = (thC !== undefined) ? thC : (top ? -Math.PI / 2 : Math.PI / 2), M0 = g.transformationMatrix;
   g.font = f;
   var pass = halo ? [[halo, hw], [col, 0]] : [[col, 0]];
   try {
      for (var p = 0; p < pass.length; ++p) {
         var a = c - dir * th / 2, offs = pass[p][1] > 0 ? [[-1, 0], [1, 0], [0, -1], [0, 1], [-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7], [0.7, 0.7]] : [[0, 0]];
         g.pen = new Pen(pass[p][0]);
         for (var i = 0; i < s.length; ++i) {
            var ch = s.charAt(i), cw = f.width(ch), am = a + dir * (cw / 2) / rb;
            g.transformationMatrix = M0; g.translateTransformation(cx + rb * Math.cos(am), cy + rb * Math.sin(am));
            g.rotateTransformation(-(am + dir * Math.PI / 2));
            for (var k = 0; k < offs.length; ++k) g.drawText(-cw / 2 + offs[k][0] * pass[p][1], offs[k][1] * pass[p][1], ch);
            a += dir * cw / rb;
         }
      }
   } finally { g.transformationMatrix = M0; }
   return { a0: c - th / 2, a1: c + th / 2 };
}
// (Blender 5 · H3) «lado nocturno» se leia «lado nodurno» en PixInsight: cada letra se colocaba con su anchura ENTERA al cuerpo de la letra (a 10 px
// la «c» mide 4,38 y daba 4; la «t» 3,25 y daba 3; el espacio 2,75 y daba 3) y la fuente cursiva con ese remate de ±0,4 px por letra se pegaba
// («ct») y dejaba un hueco antes de «no». Ahora cada rotulo se compone UNA vez a FV_PL3D.LABEL_SS veces la resolucion real (el cuerpo de la fuente a
// SS× pixeles: la anchura entera de cada letra pasa a ±0,5/SS px reales y el trazado deja de depender del hinting de un cuerpo de 10 px) con el
// origen de cada letra = ancho del prefijo − ancho de la letra (lleva el kerning), y se reduce a la resolucion real con suavizado (gris sobre
// alfa, sin flecos). FV_PL3D.LABEL_SS = 0 = lo de Blender 4 (el ROJO de P27)
FV_PL3D.LABEL_SS = 8;            // (LABEL_K sube de 0,17 a 0,19: el cuerpo de la letra 11 px a r 58 -> altura de la x de 6 px a escala 1)
function fvPl3dArcGlyphsFrac(g, cx, cy, rb, s, f, col, top, thC, halo, hw) {
   // como fvPl3dArcGlyphs pero con el origen de cada letra = f.width(prefijo) − f.width(letra): el ancho de la cadena entera, sin sumar anchuras enteras
   var wAll = f.width(s), th = wAll / rb, dir = top ? 1 : -1, c = (thC !== undefined) ? thC : (top ? -Math.PI / 2 : Math.PI / 2), M0 = g.transformationMatrix;
   g.font = f;
   var pass = halo ? [[halo, hw], [col, 0]] : [[col, 0]], a0 = c - dir * th / 2;
   try {
      for (var p = 0; p < pass.length; ++p) {
         var offs = pass[p][1] > 0 ? [[-1, 0], [1, 0], [0, -1], [0, 1], [-0.7, -0.7], [0.7, -0.7], [-0.7, 0.7], [0.7, 0.7]] : [[0, 0]];
         g.pen = new Pen(pass[p][0]);
         for (var i = 0; i < s.length; ++i) {
            var ch = s.charAt(i), cw = f.width(ch);
            if (ch === " ") continue;
            var o = f.width(s.substring(0, i + 1)) - cw, am = a0 + dir * (o + cw / 2) / rb;
            g.transformationMatrix = M0; g.translateTransformation(cx + rb * Math.cos(am), cy + rb * Math.sin(am));
            g.rotateTransformation(-(am + dir * Math.PI / 2));
            for (var k = 0; k < offs.length; ++k) g.drawText(-cw / 2 + offs[k][0] * pass[p][1], offs[k][1] * pass[p][1], ch);
         }
      }
   } finally { g.transformationMatrix = M0; }
   return { a0: c - th / 2, a1: c + th / 2 };
}
function fvPl3dArcText(g, cx, cy, rb, s, f, col, top, thC, sd) {
   // rb = radio de la linea base; top: letras hacia fuera, de izquierda a derecha por arriba (θ crece); si no, de pie por abajo (θ decrece);
   // thC = angulo del centro del rotulo (por defecto −90° arriba, +90° abajo); sd = pixeles reales por unidad (escala del HUD)
   if (!FV_PL3D.LABEL_HQ) return fvPl3dArcGlyphs(g, cx, cy, rb, s, f, col, top, thC, 0, 0);
   var S = (sd > 0) ? sd : 1, fh = f.height || (f.ascent + f.descent) || 12, R = rb + 1.6 * fh + 2, N = Math.ceil(2 * R * S) + 2, SS = FV_PL3D.LABEL_SS > 0 ? (S > 2 ? Math.min(FV_PL3D.LABEL_SS, 4) : FV_PL3D.LABEL_SS) : 0;      // (a 6K el mapa a 8× pesaria ~75 MB: 4×)
   var key = [s, f.pixelSize || f.pointSize || fh, rb.toFixed(2), top ? 1 : 0, thC === undefined ? "d" : thC.toFixed(3), col, S.toFixed(3), SS].join("|"), C = FV_PL3D_LABC.m[key];
   if (!C) {
      var b = new Bitmap(N, N, BitmapFormat.ARGB32); b.fill(0x00000000);
      var gb = new Graphics(b), arc = null;
      if (SS > 0) {
         var fu = f.pixelSize || fh, fB = cpFont("text", fu * S * SS, !!f.bold, !!f.italic), NB = N * SS, bB = new Bitmap(NB, NB, BitmapFormat.ARGB32), gB = null;
         bB.fill(0x00000000); gB = new Graphics(bB);      // el fill ANTES de abrir el Graphics (PJSR lo prohibe con uno activo)
         try { gB.antialiasing = true; gB.textAntialiasing = true; arc = fvPl3dArcGlyphsFrac(gB, NB / 2, NB / 2, rb * S * SS, s, fB, col, top, thC, FV_PL3D.LABEL_HALO, 0.9 * SS); }
         finally { gB.end(); }
         try { gb.smoothInterpolation = true; gb.compositionOperator = CompositionOp_Source; gb.drawScaledBitmap(0, 0, N, N, bB); } finally { gb.end(); }
         bB.clear();
      } else {
         try { gb.antialiasing = true; gb.textAntialiasing = true; gb.scaleTransformation(S, S); arc = fvPl3dArcGlyphs(gb, N / 2 / S, N / 2 / S, rb, s, f, col, top, thC, FV_PL3D.LABEL_HALO, 0.9 / S); }
         finally { gb.end(); }
      }
      C = FV_PL3D_LABC.m[key] = { b: b, arc: arc, n: N };
      FV_PL3D_LABC.keys.push(key);
      if (FV_PL3D_LABC.keys.length > 24) delete FV_PL3D_LABC.m[FV_PL3D_LABC.keys.shift()];
   }
   // la escala del HUD se deshace para pintar el mapa pixel a pixel (M0 = escala S + traslacion: M0·S⁻¹ deja la traslacion en pixeles reales)
   var M0 = g.transformationMatrix, cop = g.compositionOperator;
   try { g.compositionOperator = CompositionOp_SourceOver; g.scaleTransformation(1 / S, 1 / S); g.drawBitmap(Math.round(cx * S - C.n / 2), Math.round(cy * S - C.n / 2), C.b); }
   finally { g.transformationMatrix = M0; g.compositionOperator = cop; }
   return C.arc;
}
// (Blender 4) la cartela bajo un rotulo curvo de pie (abajo): un arco oscuro y translucido del ancho de la letra, de un extremo al otro
// del rotulo (el remate cuadrado del trazo añade media letra a cada lado). Lo que pasa por debajo (la barra del escaner, el resplandor) queda apagado tras las letras
function fvPl3dCartouche(g, cx, cy, rb, f, s, thC) {
   var fh = f.height || 10, w = Math.max(fh, f.width(s) - 0.6 * fh), th = w / rb, rm = rb - 0.32 * fh, pts = [], n = Math.max(8, Math.ceil(th * 24));
   for (var i = 0; i <= n; ++i) { var a = thC + th / 2 - th * i / n; pts.push(new Point(cx + rm * Math.cos(a), cy + rm * Math.sin(a))); }
   var cop = g.compositionOperator; g.compositionOperator = CompositionOp_SourceOver;
   g.pen = new Pen(0xc8070608, 1.25 * fh); g.drawPolyline(pts);
   g.compositionOperator = cop;
}
function fvPl3dLabels(g, cx, cy, r, st) {
   var R = { top: false, bottom: false };
   if (!st || typeof cpFont !== "function" || typeof fvTx !== "function") return R;
   var fs = Math.max(6, Math.round(r * (FV_PL3D.LABEL_HQ ? FV_PL3D.LABEL_K : 0.15))), sd = st.pxScale || 1;
   if (st.night) { fvPl3dArcText(g, cx, cy, 0.78 * r, fvTx("pl3.night"), cpFont("text", fs, false, true), FV_PL3D.LABEL_HQ ? 0xffF2D58C : 0xd8E9C97A, true, undefined, sd); R.top = true; }
   if (st.boost > 0.02) { fvPl3dArcText(g, cx, cy, 0.90 * r, fvTx("pl3.expo", { x: fvNum(fvPl3dBoostFactor(st.boost), 1) }), cpFont("text", fs, false, true), FV_PL3D.LABEL_HQ ? 0xf0DDBE7E : 0xc8BFA06A, false, undefined, sd); R.bottom = true; }
   return R;
}
// los cuatro brazos cortos de la cruz de la portilla (los de fvPorthole), sin los que ocupa un rotulo
function fvPl3dCross(g, cx, cy, r, skip) {
   g.pen = new Pen(0x80E5B53F, 1);
   if (!skip || !skip.top) g.drawLine(cx, cy - r + 4, cx, cy - r + 13);
   if (!skip || !skip.bottom) g.drawLine(cx, cy + r - 13, cx, cy + r - 4);
   g.drawLine(cx - r + 4, cy, cx - r + 13, cy); g.drawLine(cx + r - 13, cy, cx + r - 4, cy);
}

// (Blender 3 · D1) el resplandor de la estrella en una portilla (cx, cy, rPort) con el planeta de radio rPl: un relleno del cristal con un
// degradado radial centrado donde esta la estrella (fvsPlanetGlare: direccion rot, a d radios del planeta), con su disco (rs) y la luz que se
// dispersa en la optica (I0 / (1 + (u/w)²)). Se SUMA (Add) al cristal, ANTES del planeta (su silueta lo tapa). Color: el de la estrella.
// -> el resplandor (o null si no se pinta)
// (Blender 4 · PL-23) DOS PASADAS: (1) esta, antes del planeta, sumada, con el disco a FVS_PL.GLARE_UNDER (0,55: con ella el aro de atmosfera
// sumado encima no quema, P18b); (2) fvPl3dGlareOver, DESPUES del planeta, con el disco a GLARE_CORE (0,92) en modo ACLARAR (max) y fuera del
// disco del planeta (un anillo): la estrella se ve con su brillo y el aro del planeta queda si es mas claro, sin sumarse (sin quemar)
function fvPl3dGlare(g, cx, cy, rPort, rPl, look, alphaDeg, rot, aR, over) {
   if (typeof fvsPlanetGlare !== "function") return null;
   var G = fvsPlanetGlare(alphaDeg, aR);
   if (!G.on) return null;
   if (!over && FVS_PL.GLARE_UNDER > 0 && FVS_PL.GLARE_UNDER < FVS_PL.GLARE_CORE) G.core = 255 * FVS_PL.GLARE_UNDER;
   var sx = cx + G.d * rPl * Math.cos(rot), sy = cy + G.d * rPl * Math.sin(rot), rc = Math.max(0.6, G.rs * rPl), wv = G.w * rPl, Rg = rc + 7 * wv;
   // (Blender 4 · PL-23) el color de SU estrella (fvsPlanetGlareCol: cuerpo negro de la Teff, el camino del panel), sin mezclar con blanco
   var col = (typeof fvsPlanetGlareCol === "function") ? fvsPlanetGlareCol(look) : [1, 1, 1];
   function argb(I) { I = Math.max(0, Math.min(255, I)); return ((0xff000000 | (Math.round(col[0] * I) << 16) | (Math.round(col[1] * I) << 8) | Math.round(col[2] * I)) >>> 0); }
   var C0 = G.core || 255, stops = [[0, argb(C0)], [0.6 * rc / Rg, argb(0.96 * C0)], [rc / Rg, argb(0.82 * C0)]];      // el disco de la estrella, con limbo (GLARE_CORE)
   [0.15, 0.35, 0.6, 1, 1.5, 2.2, 3, 4.2, 5.6].forEach(function(u) { stops.push([(rc + u * wv) / Rg, argb(Math.min(0.82 * C0, G.i0 / (1 + u * u)))]); });
   stops.push([1, 0xff000000]);
   var cop = g.compositionOperator, br = new RadialGradientBrush(new Point(sx, sy), Rg, new Point(sx, sy), stops);
   if (!over) { g.compositionOperator = CompositionOp_Add; g.fillCircle(cx, cy, rPort, br); }
   else {
      // el anillo cristal − planeta (par-impar: la vuelta de dentro en sentido contrario), en modo aclarar
      var pts = [], n = 96, i, rIn = rPl + 0.5;
      for (i = 0; i <= n; ++i) pts.push(new Point(cx + rPort * Math.cos(2 * Math.PI * i / n), cy + rPort * Math.sin(2 * Math.PI * i / n)));
      for (i = n; i >= 0; --i) pts.push(new Point(cx + rIn * Math.cos(2 * Math.PI * i / n), cy + rIn * Math.sin(2 * Math.PI * i / n)));
      var brk = g.brush, pen = g.pen;
      g.compositionOperator = CompositionOp_Max; g.pen = new Pen(0x00000000, 0); g.brush = br; g.fillPolygon(pts);
      g.brush = brk; g.pen = pen;
   }
   g.compositionOperator = cop;
   G.sx = sx; G.sy = sy;
   return G;
}
// la segunda pasada (ver arriba): solo si el disco de la estrella entra en el cristal (si no, la primera ya es la de siempre)
function fvPl3dGlareOver(g, cx, cy, rPort, rPl, look, alphaDeg, rot, aR) {
   if (typeof fvsPlanetGlare !== "function" || !(FVS_PL.GLARE_UNDER > 0 && FVS_PL.GLARE_UNDER < FVS_PL.GLARE_CORE) || typeof CompositionOp_Max === "undefined") return null;
   var G = fvsPlanetGlare(alphaDeg, aR);
   if (!G.on || (G.d - G.rs) * rPl > rPort) return null;
   return fvPl3dGlare(g, cx, cy, rPort, rPl, look, alphaDeg, rot, aR, true);
}

// (Blender 3 · D5) EL PANEL DEL TRANSITO, A CONTRALUZ: el MISMO momento y la misma geometria que el esquema de la izquierda (q de fvsTransitPos
// al mismo reloj), ampliado sobre el planeta: un disco oscuro delante de la superficie de su estrella (oscurecimiento del limbo cuadratico,
// u1 u2 de la ficha) y, si tiene atmosfera, el anillo rojizo de la luz que la atraviesa (lo que mide la espectroscopia de transmision;
// ILUSTRACION: mas grueso que una atmosfera real). La estrella es un degradado radial que llena el cristal: sin recortes ni mapas aparte.
// (cx, cy, r) = la portilla; el planeta mide FV_PL3D.TR_RP·r. -> { k, sx, sy, rs, atm } o null
FV_PL3D.TR_RP = 0.40;
function fvPl3dTransitPort(g, look, tr, q, cx, cy, r) {
   if (!fvPl3dActive() || !tr || !(tr.k > 0) || !q) return null;
   var Rp = FV_PL3D.TR_RP * r, S = Rp / tr.k, sx = cx - q.x * S, sy = cy + q.y * S;
   var col = (typeof fvsBlackbodyColour === "function" && tr.teff > 0) ? fvsBlackbodyColour(tr.teff) : { r: 255, g: 230, b: 200 };
   function I(t) { var mu = Math.sqrt(Math.max(0, 1 - t * t)); return Math.max(0, 1 - tr.u1 * (1 - mu) - tr.u2 * (1 - mu) * (1 - mu)); }
   function argb(k) { return ((0xff000000 | (Math.round(col.r * k) << 16) | (Math.round(col.g * k) << 8) | Math.round(col.b * k)) >>> 0); }
   var stops = [], eps = Math.min(0.01, 0.6 / S);
   for (var j = 0; j <= 20; ++j) { var t = (1 - eps) * j / 20; stops.push([t, argb(I(t))]); }
   stops.push([1, 0xff000000]);
   var cop = g.compositionOperator;
   g.compositionOperator = CompositionOp_SourceOver;
   g.fillCircle(cx, cy, r, new RadialGradientBrush(new Point(sx, sy), S, new Point(sx, sy), stops));
   var M = FV_PL3D_STORE.man, atm = !!(look && M && M.families[look.fam] && M.families[look.fam].atm);
   g.fillCircle(cx, cy, Rp, new Brush(0xff050404));
   if (atm) {
      // el anillo: la luz de la estrella filtrada por la atmosfera, enrojecida (la dispersion se lleva antes el azul; SUPUESTO el factor)
      var wr = Math.max(1.2, 0.07 * Rp), k = 0.62;
      g.pen = new Pen(((0xe0 << 24) | (Math.round(col.r * k) << 16) | (Math.round(col.g * k * 0.62) << 8) | Math.round(col.b * k * 0.38)) >>> 0, wr);
      g.drawCircle(cx, cy, Rp + wr / 2);
   }
   g.compositionOperator = cop;
   return { k: tr.k, sx: sx, sy: sy, rs: S, rp: Rp, atm: atm, front: q.front };
}

// fase en el TRANSITO (vista de la Tierra, fvsTransitPos: X a lo largo, Y arriba, Z hacia el observador) -> { alpha, rot } para fvPl3dDraw
// con la pantalla del panel: x = X, y = −Y (py = cy − q.y·R)
function fvPl3dTransitPhase(q) {
   var l = Math.sqrt(q.x * q.x + q.y * q.y + q.z * q.z) || 1;
   var c = Math.max(-1, Math.min(1, -q.z / l));
   return { alpha: Math.acos(c) * 180 / Math.PI, rot: Math.atan2(q.y / l, -q.x / l) };
}

// el planeta EN el transito (sustituye a la mancha negra: fv_exo_view.js, fase B). (px, py) centro, rPx = k·R★ en pantalla
function fvPl3dOnStar(g, look, q, px, py, rPx, pxScale, band) {
   if (!fvPl3dActive()) return null;
   var T = fvPl3dTransitPhase(q);
   var r = Math.max(1.2, rPx), ks = (pxScale > 0) ? pxScale : 1;
   // (PL-1) ≤ TRANSIT_SIL_PX px reales: solo cuenta la silueta, y el disco de hoy (fillCircle con antialias) la pinta MEJOR que el sprite de
   // 64 px reducido ×5 (bordes en escalera: montaje_planetas_app.png de las 18:55) -> null y el gancho pinta lo de hoy
   if (r * ks <= FV_PL3D.TRANSIT_SIL_PX) return null;
   // (Blender 3 · D3) band: las bandas con el eje de giro fijo (fvsPlanetBandAngle desde la Tierra)
   return fvPl3dDraw(g, px, py, r, look, T.alpha, T.rot, { rings: false, pxScale: ks, band: band });
}

// el gancho de fvPorthole (fv_hud.js): o = scene.objects[i] de tipo «exoplanet» (fila de pscomppars en o.planet, estrella o.star).
// El sistema (fvsTransitSetup) y su aspecto se guardan en el pintor por objeto. -> true si pinto (si no, la portilla sigue con lo de hoy)
var FV_R_SUN_LY_PL = 6.957e8 / 9.4607e15;
function fvPl3dPortholeObj(g, painter, P, pr, o, cx, cy, r, tc) {
   if (!o || o.type !== "exoplanet" || !o.planet || !(o.star >= 0) || !painter.scene.stars) return false;
   var C = painter._pl3dObj;
   if (!C || C.o !== o) {
      var tr = (typeof fvsTransitSetup === "function") ? fvsTransitSetup(o.planet) : null;
      C = painter._pl3dObj = { o: o, tr: (tr && tr.aR > 0 && tr.Ph > 0) ? tr : null, look: null };
      if (C.tr) C.look = fvPl3dLook(o.planet, C.tr);
   }
   if (!C.tr) return false;
   var G = { tr: C.tr, starPos: fvStarPos(painter.scene, o.star), camPos: P.cam.pos, rStarU: (Number(o.planet.st_rad) || 1) * FV_R_SUN_LY_PL, basis: pr || null, pxScale: painter.hudK || 1 };
   var st = fvPl3dPorthole(g, C.look, G, cx, cy, r, tc);
   painter.stats.pl3d = st;
   return !!st;
}

// (PL-6, 10-nov) el planeta que enseña la portilla de la seleccion: un objeto «exoplaneta»; o una ESTRELLA con un objeto «exoplaneta» de la
// escena sobre ella (fvObjExoEntries ya exige el cruce verdadero) o con un cruce verdadero de la lista (C.exoRow, de fvCardContent:
// fvExoForStar, nunca una demo). El objeto sintetico se guarda en el pintor (misma identidad: fvPl3dPortholeObj no rehace el sistema).
function fvPl3dHostObj(painter, sel, C) {
   var ob = (painter && painter.scene && painter.scene.objects) || null, i;
   if (!sel) return null;
   if (sel.kind === "object") { var o = ob ? ob[sel.i] : null; return (o && o.type === "exoplanet" && o.planet) ? o : null; }
   if (sel.kind !== "star" || !(sel.i >= 0)) return null;
   if (ob) for (i = 0; i < ob.length; ++i) if (ob[i] && ob[i].type === "exoplanet" && ob[i].planet && ob[i].star === sel.i) return ob[i];
   var row = C && C.exoRow;
   if (!row) return null;
   var K = painter._pl3dHost;
   if (!K || K.planet !== row || K.star !== sel.i) K = painter._pl3dHost = { type: "exoplanet", planet: row, star: sel.i, name: row.pl_name };
   return K;
}

// LA PORTILLA de la ficha (fv_hud.js fvPorthole, fase B): el planeta de cerca, a la fase que tiene visto DESDE LA NAVE, girando en su orbita
// G = { tr, starPos, camPos, rStarU (radio de la estrella en unidades de la escena), basis: { r, d } }, t = segundos desde que se abrio
// (Blender 3) G.band: el angulo de las bandas (eje de giro fijo, D3; si falta se calcula de la camara); el resplandor de la estrella a fase
// alta (D1) se suma al cristal antes del planeta. G.kPl (opcional): radio del planeta / r (el recuadro de la ficha de la estrella usa otro)
function fvPl3dPorthole(g, look, G, cx, cy, r, t) {
   if (!fvPl3dActive() || !G || !G.tr) return null;
   var phi = 2 * Math.PI * ((t || 0) / FV_PL3D.ORBIT_S) + Math.PI / 2;          // empieza en cuadratura (media fase): se ve la forma
   var F = fvsPlanetPhase(G.tr, phi, G.starPos, G.camPos, G.rStarU || 0, G.basis || null, G.frame || null);
   if (G.band === undefined) G.band = (G.basis && typeof fvsPlanetBandAngle === "function") ? fvsPlanetBandAngle(G.tr, G.starPos, G.basis, G.frame || null) : null;
   var rPl = (G.kPl || FV_PL3D.PORT_R) * r;
   var gl = (fvPl3dActive() && G.glare !== false) ? fvPl3dGlare(g, cx, cy, r, rPl, look, F.alpha, F.rot, G.tr.aR) : null;
   var st = fvPl3dDraw(g, cx, cy, rPl, look, F.alpha, F.rot, { pxScale: G.pxScale || 1, nightBoost: G.nightBoost !== false, band: G.band });
   if (gl) fvPl3dGlareOver(g, cx, cy, r, rPl, look, F.alpha, F.rot, G.tr.aR);
   if (st) { st.phi = phi; st.front = F.front; st.glare = gl ? { d: gl.d, rs: gl.rs, sx: gl.sx, sy: gl.sy } : null; }
   return st;
}
// (Blender 3 · D4) la ficha de la ESTRELLA enseña SU estrella (la portilla de siempre) y el mundo en un RECUADRO pequeño dentro del cristal,
// abajo a la derecha (imagen en imagen), con el nombre del planeta curvado por dentro del cristal abajo a la izquierda: nunca sustituido por
// otro rotulo. Sin la ayuda nocturna (no cabe su rotulo): a fase alta lo que se ve es el resplandor de la estrella (fisico). Sin botones.
// FV_PL3D.INSET = { d: centro a d·r del centro a 45°, k: radio del recuadro / r, pl: radio del planeta / radio del recuadro }
// (Blender 4 · PL-22) con d 0,50 k 0,38 el recuadro tapaba el 24 % del NUCLEO de la estrella (L > 150) y su borde pasaba a ~7 px del centro:
// se leia como un planeta gigante en transito. Ahora mas lejos y mas pequeño (borde interior a 0,32·r del centro; el exterior a 0,92·r + el
// bisel, dentro del cristal): medido en fv_pl3d_test P24 (≤ 5 % del nucleo; ROJO las medidas de antes)
FV_PL3D.INSET = { d: 0.62, k: 0.30, pl: 0.78 };
FV_PL3D.INSET_OLD = { d: 0.50, k: 0.38, pl: 0.78 };
function fvPl3dInsetObj(g, painter, P, pr, o, cx, cy, r, tc, name) {
   if (!fvPl3dActive() || !o || o.type !== "exoplanet" || !o.planet || !(o.star >= 0) || !painter.scene.stars) return null;
   var C = painter._pl3dObj;
   if (!C || C.o !== o) {
      var tr = (typeof fvsTransitSetup === "function") ? fvsTransitSetup(o.planet) : null;
      C = painter._pl3dObj = { o: o, tr: (tr && tr.aR > 0 && tr.Ph > 0) ? tr : null, look: null };
      if (C.tr) C.look = fvPl3dLook(o.planet, C.tr);
   }
   if (!C.tr) return null;
   var I = FV_PL3D.INSET, ix = cx + I.d * r * Math.SQRT1_2, iy = cy + I.d * r * Math.SQRT1_2, ir = I.k * r, cop = g.compositionOperator;
   g.compositionOperator = CompositionOp_SourceOver; g.fillCircle(ix, iy, ir + 1.6, new Brush(0xff2A1F15)); g.fillCircle(ix, iy, ir, new Brush(0xff07060A));
   var G = { tr: C.tr, starPos: fvStarPos(painter.scene, o.star), camPos: P.cam.pos, rStarU: (Number(o.planet.st_rad) || 1) * FV_R_SUN_LY_PL, basis: pr || null, pxScale: painter.hudK || 1,
             kPl: I.pl, nightBoost: false };
   g.compositionOperator = CompositionOp_Add;
   var st = fvPl3dPorthole(g, C.look, G, ix, iy, ir, tc);
   g.compositionOperator = CompositionOp_SourceOver;
   g.pen = new Pen(FV_HUD_COL.brassD, 1.2); g.drawCircle(ix, iy, ir + 1.6); g.pen = new Pen(FV_HUD_COL.brass, 0.8); g.drawCircle(ix, iy, ir + 0.4);
   var insName = null;
   if (name && typeof cpFont === "function") {
      // el nombre: por dentro del cristal, abajo a la izquierda (entre los brazos de la cruz: 100°-170°), letras de pie; se achica si no cabe
      var s = String(name), fs0 = 0, fs = Math.max(6, Math.round(r * (FV_PL3D.LABEL_HQ ? FV_PL3D.LABEL_K : 0.15))), f = cpFont("text", fs, false, true), rb = 0.90 * r, maxA = 66 * Math.PI / 180;
      while (fs > 6 && f.width(s) / rb > maxA) { --fs; f = cpFont("text", fs, false, true); }
      if (f.width(s) / rb > maxA && typeof cpElide === "function") s = cpElide(f, s, maxA * rb);
      // (Blender 4 · PL-22) una cartela oscura bajo el nombre: la barra dorada del escaner (que barre la portilla) ya no cruza las letras
      insName = s;
      if (FV_PL3D.LABEL_HQ) fvPl3dCartouche(g, cx, cy, rb, f, s, 133 * Math.PI / 180);
      fvPl3dArcText(g, cx, cy, rb, s, f, FV_PL3D.LABEL_HQ ? 0xffF2D58C : 0xe0E9C97A, false, 133 * Math.PI / 180, painter.hudK || 1);
   }
   g.compositionOperator = cop;
   if (st) { st.inset = { x: ix, y: iy, r: ir, name: insName }; painter.stats.pl3d = st; }
   return st;
}

// (PL-3, 5-nov) PRECARGA fuera del fotograma: leer los PNG y componer el juego del planeta costaba 26 ms la primera vez que se abria su ficha
// (un tiron). FVDialog.refreshItems (al construir la escena y cada vez que cambia MIRABILIA) llama aqui: para los primeros planetas de la
// escena (objetos «exoplaneta» y filas de MIRABILIA) compone el juego del nivel de la portilla y el del transito. Con la bandera apagada no
// hace nada. -> { n, ms } o null
function fvPl3dPrewarm(scene, exoList, VW) {
   if (!fvPl3dActive()) return null;
   var t0 = (typeof fvNowMs === "function") ? fvNowMs() : Date.now(), rows = [], seen = {}, i;
   function add(row) { if (row && row.pl_name && !seen[row.pl_name] && rows.length < 2) { seen[row.pl_name] = true; rows.push(row); } }
   var ob = (scene && scene.objects) || [];
   for (i = 0; i < ob.length; ++i) if (ob[i] && ob[i].type === "exoplanet") add(ob[i].planet);
   for (i = 0; exoList && i < exoList.length; ++i) add(exoList[i].row);
   var hk = (typeof fvHudK === "function" && VW > 0) ? fvHudK(VW) : 1, rP = FV_PL3D.PORT_R * 58 * hk, rI = FV_PL3D.INSET.k * FV_PL3D.INSET.pl * 58 * hk, lvPort = fvPl3dLevel(rP), lvIn = fvPl3dLevel(rI), lvTr = fvPl3dLevel(FV_PL3D.TRANSIT_SIL_PX), n = 0;
   for (i = 0; i < rows.length; ++i) {
      var tr = (typeof fvsTransitSetup === "function") ? fvsTransitSetup(rows[i]) : null;
      if (!tr || !(tr.aR > 0)) continue;
      var look = fvPl3dLook(rows[i], tr), sA = fvPl3dSet(look, lvPort, fvPl3dExactN(lvPort, rP)), sB = fvPl3dSet(look, lvIn, fvPl3dExactN(lvIn, rI));   // (Blender 3) la portilla y el recuadro de la ficha de la estrella, a su medida (el transito de ≤ 20 px no usa juego)
      // _shown: su preparacion ya no cae en un fotograma (fvPl3dDraw da prep 0)
      if (sA) { sA._shown = true; ++n; }
      if (sB) { sB._shown = true; ++n; }
      // (Blender 3 · PL-3) un fotograma de prueba en un mapa de 8 × 8: crea el mapa del fundido y deja compilado el camino de pintar (el
      // primer fotograma de la portilla costaba 1,5 ms con la precarga; medido en tests/fv_pl3d_app_test.js)
      if (sA || sB) { var wb = new Bitmap(8, 8, BitmapFormat.ARGB32), wg = new Graphics(wb);
         try { if (sA) fvPl3dDraw(wg, 4, 4, rP, look, 90, 0, { band: 0 }); if (sB) fvPl3dDraw(wg, 4, 4, rI, look, 90, 0, { band: 0 }); } finally { wg.end(); } }
   }
   var ms = ((typeof fvNowMs === "function") ? fvNowMs() : Date.now()) - t0;
   fvPl3dLog("prewarm: " + n + " sets (" + rows.length + " planets, levels " + lvPort + "/" + lvTr + ") in " + ms.toFixed(1) + " ms");
   return { n: n, ms: ms };
}
