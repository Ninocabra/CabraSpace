// ============================================================================
// FieldVoyager/src/ui/fv_buttons.js — LA BOTONERA DE LATON (D7: columna a la izquierda de la pantalla de la nave)
// ----------------------------------------------------------------------------
// Botones redondos de laton con el icono GRABADO (trazo oscuro con un filo de luz debajo, como un buril), mismo lenguaje que la
// cabina (§10). El texto va en el tooltip, en ingles y en castellano. Estados: normal, encendido (Info activo: hundido con el aro
// de oro), deshabilitado (apagado; Exoplaneta en F1: «Coming soon / Próximamente»).
// Es una subclase de widget (V8 class): lo unico que no es ES5 (regla 1 de CabraScripts).
// (E6 + S1, 4-nov) Nino: «buen estilo, pero no acaba de ser refinado» y, vistos los montajes, «latón con los iconos nuevos, más brillo y
// contraste, iconos aún más sutiles»: laton claro pulido e iconos a buril fino con detalle de grabado; el de antes en fvPaintButtonN.
// ============================================================================

// (F2) Warp e Ir a se funden en VIAJAR: el COMO lo elige el conmutador MODUS de la cabina (CINE / WARP). Con los dos botones y el
// conmutador habria dos caminos a lo mismo (§11.5). Nuevos: Mirar a casa, Tour y Abrir en el navegador (si F3 lo trae).
// (pasada N) N3: arriba del todo, VISTA INICIAL (volver volando a la Tierra, a la foto); «Mirar a casa» pasa a «Mirar al Sol» con un
// icono de Sol (antes una casita: se confundia con volver a casa). N12: el boton Exoplaneta SE QUITA (los planetas van en MIRABILIA,
// la lista de la franja). Cada boton lleva su rotulo corto debajo (lab.*) y el tooltip largo EN/ES.
// (5-nov-2026, decision de Nino) SE QUITAN «Orbitar» y «Mirar al Sol» (botones, teclas O y L, iconos y textos). El motor se queda
// (fvPilotOrbit, la animacion «orbit» de las camaras de la ruta). La columna DERECHA nueva vive en src/ui/fv_rightbar.js.
var FV_BTN = [
   { id: "start", en: FV_TX.en["btn.start"], es: FV_TX.es["btn.start"], tipEn: FV_TX.en["tip.start"], tipEs: FV_TX.es["tip.start"] },
   { id: "info",  en: "Info", es: "Info", tipEn: "Info: opens the scan card of the object you have selected (click an object first, or pick it in MIRABILIA): what it is, and whether each figure is measured, doubtful or assumed. The card also opens by itself when you arrive at a destination. Press again to close it. Key: I.",
     tipEs: "Info: abre la ficha de escaneo del objeto que has elegido (haz clic en un objeto antes, o elígelo en MIRABILIA): qué es, y si cada dato es medido, dudoso o supuesto. La ficha también se abre sola al llegar a un destino. Otra pulsación la cierra. Tecla: I." },
   { id: "travel", en: FV_TX.en["btn.travel"], es: FV_TX.es["btn.travel"], tipEn: FV_TX.en["tip.travel"], tipEs: FV_TX.es["tip.travel"] },
   { id: "tour",  en: FV_TX.en["btn.tour"], es: FV_TX.es["btn.tour"], tipEn: FV_TX.en["tip.tour"], tipEs: FV_TX.es["tip.tour"] },
   { id: "web",   en: FV_TX.en["btn.web"], es: FV_TX.es["btn.web"], tipEn: FV_TX.en["tip.web"], tipEs: FV_TX.es["tip.web"] }
];
if (typeof FV_GAL !== "undefined" && FV_GAL.ON) FV_BTN.splice(4, 0, { id: "galaxy", en: FV_TX.en["btn.galaxy"], es: FV_TX.es["btn.galaxy"], tipEn: FV_TX.en["tip.galaxy"], tipEs: FV_TX.es["tip.galaxy"] });   // (encargo D1, 9-nov) src/ui/fv_galaxy.js
// (I2, 19-nov) el boton DIAGRAMA HR (src/ui/fv_hr_ui.js), antes de EXPORTAR; FV_HR.ON false = sin boton
if (typeof FV_HR !== "undefined" && FV_HR.ON) FV_BTN.splice(FV_BTN.length - 1, 0, { id: "hr", en: FV_TX.en["btn.hr"], es: FV_TX.es["btn.hr"], tipEn: FV_TX.en["tip.hr"], tipEs: FV_TX.es["tip.hr"] });
function fvBtnTip(d) { return "<html><b>" + d.en + "</b> — " + d.tipEn.substring(d.tipEn.indexOf(":") + 1) + "<br><i><b>" + d.es + "</b> — " + d.tipEs.substring(d.tipEs.indexOf(":") + 1) + "</i></html>"; }

// (E6 + S1, 4-nov-2026) EL ICONO GRABADO A BURIL FINO sobre LATON (Nino: «latón con los iconos nuevos, con un poco más de brillo y
// contraste, y los iconos todavía más refinados y sutiles, como las láminas»). Todos en la MISMA reticula (40 unidades, ±15) y con el MISMO
// trazo: el surco oscuro fino (0,72 u) con un filo de luz de medio pixel debajo, y un segundo trazo aun mas fino (0,4 u) para el detalle
// delicado de grabado (filetes dobles, rayos cortos, meridianos). col = color del trazo sin filo de luz (la fila VIAJAR de la ficha oscura).
// FV_E6_FINE = false vuelve al grabado grueso de la pasada N (el ROJO de la comparativa y de fv_nE2_test).
var FV_E6_FINE = true;
var FV_ENGRAVE = { cut: 0xff2A1B06, cutOn: 0xff1E1304, edge: 0x99FFF3D0, gold: 0xffE5B53F, goldL: 0xffFFF3C4, ivory: 0xffF4ECDC };
function fvEngrave(g, id, cx, cy, r, on, col) {
   var u = r / 20, fine = FV_E6_FINE, sw = fine ? Math.max(0.85, 0.72 * u) : 1.6, sw2 = fine ? Math.max(0.6, 0.4 * u) : 1.0;
   var ink = (col !== undefined) ? col : (fine ? (on ? FV_ENGRAVE.cutOn : FV_ENGRAVE.cut) : (on ? 0xff1A1204 : 0xff3B2A0C));
   var edge = (col === undefined), eo = fine ? Math.max(0.5, 0.35 * u) : 0.8;
   function stroke(fn) {
      if (edge) { g.pen = new Pen(fine ? FV_ENGRAVE.edge : 0x90F3D27E, fine ? Math.max(0.5, 0.5 * sw) : 1.0); fn(eo); }
      g.pen = new Pen(ink, sw); fn(0);
   }
   function hair(fn) { g.pen = new Pen(ink, sw2); fn(0); }               // el detalle delicado (sin filo de luz)
   function dot(x, y, rr) { g.fillCircle(cx + x * u, cy + y * u, Math.max(0.8, rr * u), new Brush(ink)); }
   function ellipse(o, x0, y0, x1, y1) { g.drawEllipse(cx + x0 * u + o, cy + y0 * u + o, cx + x1 * u + o, cy + y1 * u + o); }
   if (id === "info") {
      stroke(function(o) {
         g.drawCircle(cx + o, cy + o, 11.5 * u);
         g.drawLine(cx + o, cy - 1.5 * u + o, cx + o, cy + 6 * u + o);
         g.drawLine(cx - 2.5 * u + o, cy + 6 * u + o, cx + 2.5 * u + o, cy + 6 * u + o); g.drawLine(cx - 1.6 * u + o, cy - 1.5 * u + o, cx + o, cy - 1.5 * u + o);
      });
      hair(function() { g.drawCircle(cx, cy, 13.6 * u); for (var k = 0; k < 4; ++k) { var p = fvPol(13.6 * u, k * 90), q = fvPol(15.4 * u, k * 90); g.drawLine(cx + p[0], cy + p[1], cx + q[0], cy + q[1]); } });
      dot(0, -5.2, 1.35);
   } else if (id === "travel") {
      // (N2, punto 3 de Nino) VIAJAR: una flecha CURVA que sale de abajo a la izquierda, sube y baja hacia un PUNTO REDONDO (el destino)
      var P0 = [-15, 9], C0 = [-9, -15], P1 = [3.5, -2.5], tx = P1[0] - C0[0], ty = P1[1] - C0[1], tl = Math.sqrt(tx * tx + ty * ty); tx /= tl; ty /= tl;
      stroke(function(o) {
         var pts = [], k, t, a, b;
         for (k = 0; k <= 24; ++k) { t = k / 24; a = (1 - t) * (1 - t); b = 2 * (1 - t) * t; pts.push(new Point(cx + (a * P0[0] + b * C0[0] + t * t * P1[0]) * u + o, cy + (a * P0[1] + b * C0[1] + t * t * P1[1]) * u + o)); }
         g.drawPolyline(pts);
         for (k = -1; k <= 1; k += 2) { var ca = Math.cos(0.45), sa = Math.sin(k * 0.45), rx = -tx * ca + ty * sa, ry = -tx * sa - ty * ca; g.drawLine(cx + P1[0] * u + o, cy + P1[1] * u + o, cx + (P1[0] + rx * 5.5) * u + o, cy + (P1[1] + ry * 5.5) * u + o); }
         g.drawCircle(cx + 11.5 * u + o, cy + 4.5 * u + o, 3.8 * u);
      });
      hair(function() { g.drawCircle(cx + 11.5 * u, cy + 4.5 * u, 6.2 * u); for (var k = 0; k < 4; ++k) { var p = fvPol(6.2 * u, k * 90 + 45), q = fvPol(7.8 * u, k * 90 + 45); g.drawLine(cx + 11.5 * u + p[0], cy + 4.5 * u + p[1], cx + 11.5 * u + q[0], cy + 4.5 * u + q[1]); } });
      dot(11.5, 4.5, 1.3);
   } else if (id === "warp") {
      stroke(function(o) {
         var L = [[-14, -9, 4, -3], [-16, 0, 2, 0], [-14, 9, 4, 3], [-8, -14, 6, -6], [-8, 14, 6, 6]];
         for (var i = 0; i < L.length; ++i) g.drawLine(cx + L[i][0] * u + o, cy + L[i][1] * u + o, cx + L[i][2] * u + o, cy + L[i][3] * u + o);
         g.drawCircle(cx + 11 * u + o, cy + o, 3.5 * u);
      });
   } else if (id === "goto") {
      stroke(function(o) {
         g.drawLine(cx - 14 * u + o, cy + o, cx + 6 * u + o, cy + o);
         g.drawLine(cx + 6 * u + o, cy + o, cx + 1 * u + o, cy - 5 * u + o); g.drawLine(cx + 6 * u + o, cy + o, cx + 1 * u + o, cy + 5 * u + o);
         g.drawCircle(cx + 12 * u + o, cy + o, 3 * u);
      });
   } else if (id === "start") {
      // (B2, 20-nov, Nino: «que el dibujo parezca más Home») UNA CASA: tejado a dos aguas con chimenea, paredes, puerta y un ojo de buey en el hastial;
      // el filete fino repite el alero y marca el suelo. Mismo surco (0,72) y mismo filete (0,4) que el resto; gemelo en web/fw_cockpit.js (fwIcon «start»)
      function pt(x, y, o) { return new Point(cx + x * u + o, cy + y * u + o); }
      stroke(function(o) {
         g.drawPolyline([pt(-15, 0, o), pt(0, -13, o), pt(15, 0, o)]);                                                     // el tejado
         g.drawPolyline([pt(-11, -3.5, o), pt(-11, 12, o), pt(11, 12, o), pt(11, -3.5, o)]);                                // las paredes
         g.drawPolyline([pt(-3, 12, o), pt(-3, 4, o), pt(3, 4, o), pt(3, 12, o)]);                                          // la puerta
         g.drawPolyline([pt(7, -6.9, o), pt(7, -12.5, o), pt(10.5, -12.5, o), pt(10.5, -3.9, o)]);                          // la chimenea
      });
      hair(function() {
         g.drawPolyline([pt(-9.5, -2.4, 0), pt(0, -10.6, 0), pt(9.5, -2.4, 0)]); g.drawLine(cx - 15 * u, cy + 12 * u, cx + 15 * u, cy + 12 * u);
         g.drawCircle(cx, cy - 4.4 * u, 2.4 * u);
      });
      dot(0, -4.4, 0.9); dot(1.6, 8.6, 0.7);
   } else if (id === "tour") {
      // un camino de cinco paradas: las paradas como anillos con su punto
      var T = [[-14, 8], [-6, -6], [3, 6], [10, -8], [15, 2]];
      stroke(function(o) { for (var i = 1; i < T.length; ++i) g.drawLine(cx + T[i - 1][0] * u + o, cy + T[i - 1][1] * u + o, cx + T[i][0] * u + o, cy + T[i][1] * u + o); });
      hair(function() { for (var j = 0; j < T.length; ++j) g.drawCircle(cx + T[j][0] * u, cy + T[j][1] * u, 2.9 * u); });
      for (var j = 0; j < T.length; ++j) dot(T[j][0], T[j][1], 1.25);
   } else if (id === "web") {
      // un globo terraqueo con meridianos y paralelos finos
      stroke(function(o) {
         g.drawCircle(cx + o, cy + o, 12 * u);
         ellipse(o, -5, -12, 5, 12);
         g.drawLine(cx - 12 * u + o, cy + o, cx + 12 * u + o, cy + o);
      });
      hair(function() { ellipse(0, -9.4, -12, 9.4, 12); g.drawLine(cx, cy - 12 * u, cx, cy + 12 * u); g.drawLine(cx - 10.4 * u, cy - 6 * u, cx + 10.4 * u, cy - 6 * u); g.drawLine(cx - 10.4 * u, cy + 6 * u, cx + 10.4 * u, cy + 6 * u); });
   } else if (id === "exo") {
      stroke(function(o) {
         g.drawCircle(cx - 2 * u + o, cy + o, 11 * u);
         g.drawLine(cx - 16 * u + o, cy + 13 * u + o, cx + 16 * u + o, cy - 9 * u + o);
      });
      dot(6, -3.5, 3.2);
   } else if (id === "galaxy" && typeof fvGalEngrave === "function") fvGalEngrave(g, cx, cy, u, stroke, hair, dot, ellipse);   // (encargo D1) la espiral
   else if (id === "hr" && typeof fvHrEngrave === "function") fvHrEngrave(g, cx, cy, u, stroke, hair, dot);   // (I2, 19-nov) el diagrama HR
   else if (typeof fvRbEngrave === "function") fvRbEngrave(g, id, cx, cy, u, stroke, hair, dot, ellipse);   // (5-nov) la columna derecha (src/ui/fv_rightbar.js), con los MISMOS trazos
}
// el boton entero (para el control y para las capturas sin dialogo)
// (N2/N3) H puede ser mayor que W: el disco arriba (W × W) y el rotulo corto debajo. hover = realce al pasar el raton.
// (S1) LATON CON MAS BRILLO Y CONTRASTE: bisel de laton claro con estriado fino (72 marcas de medio pixel), filete oscuro, esfera de laton
// pulido (luz arriba a la izquierda, del oro palido al bronce) con un filete grabado interior, y el icono a buril fino. Encendido: la esfera
// hundida (mas oscura) y un aro de oro claro. Sin halos.
function fvPaintButton(g, id, W, H, state, hover) {
   if (!FV_E6_FINE) return fvPaintButtonN(g, id, W, H, state, hover);
   var cx = W / 2, cy = W / 2, R = W / 2 - 3, on = state === "on", dis = state === "disabled", s = Math.max(1, W / 64), i;
   g.antialiasing = true; g.textAntialiasing = true;
   g.fillRect(0, 0, W, H, new Brush(0xff110D09));
   if (H > W + 4) {
      // (la fuente se encoge con un contador propio: cpFont redondea el tamaño y «pixelSize − 0,5» volvia al mismo: bucle infinito con
      // los rotulos largos en castellano, medido el 4-nov en fv_nA_test). Versalitas espaciadas en oro; marfil al pasar o encendido
      var lab = fvTx("lab." + id), px = Math.max(6, Math.min(0.16 * W, (H - W) * 0.66)), f = cpFont("display", px, false, false, 2);
      for (var it = 0; it < 20 && f.width(lab) > W - 2 && px > 6; ++it) { px = Math.max(6, px - 1); f = cpFont("display", px, false, false, px > 9 ? 2 : 1); }
      g.font = f; g.pen = new Pen(dis ? 0xff5E4214 : (hover || on ? FV_ENGRAVE.ivory : FV_ENGRAVE.gold)); g.drawText((W - f.width(lab)) / 2, W + (H - W) * 0.70, lab);
   }
   // bisel
   g.fillCircle(cx, cy, R, new LinearGradientBrush(new Point(cx - R, cy - R), new Point(cx + R, cy + R), [[0, 0xffFBE7A8], [0.3, 0xffD9AE52], [0.62, 0xffB8862E], [1, 0xff5E4214]]));
   g.pen = new Pen(0x8C5E4214, 0.5 * s);
   for (i = 0; i < 72; ++i) { var p = fvPol(R - 0.3 * s, i * 5), q = fvPol(R - 2.2 * s, i * 5); g.drawLine(cx + p[0], cy + p[1], cx + q[0], cy + q[1]); }
   g.pen = new Pen(0xff3B2A0C, 0.8 * s); g.drawCircle(cx, cy, R - 0.2 * s);
   // esfera de laton pulido
   var ri = R - 4 * s, lx = cx - ri * 0.32, ly = cy - ri * 0.38;
   g.fillCircle(cx, cy, ri, new RadialGradientBrush(new Point(lx, ly), ri * 1.55, new Point(lx, ly),
      on ? [[0, 0xffE6C676], [0.55, 0xffB88A34], [1, 0xff6E4E18]] : [[0, 0xffFFF2C6], [0.35, 0xffF0CB72], [0.75, 0xffC89A3E], [1, 0xff8A6422]]));
   g.pen = new Pen(0xff3B2A0C, 0.7 * s); g.drawCircle(cx, cy, ri);
   g.pen = new Pen(0x705E4214, 0.45 * s); g.drawCircle(cx, cy, ri - 2.4 * s);                    // filete grabado interior
   fvEngrave(g, id, cx, cy, ri - 3 * s, on);
   if (on) { g.pen = new Pen(0xffFFE9A8, 1.3 * s); g.drawCircle(cx, cy, R + 1.2); }
   else if (hover && !dis) { g.pen = new Pen(0xffFFF3C4, 1.0 * s); g.drawCircle(cx, cy, R + 1.2); }
   if (dis) g.fillCircle(cx, cy, R + 1, new Brush(0xa0110D09));
}
// (pasada N) el boton de laton de antes: solo para el ROJO de las comparativas (FV_E6_FINE = false)
// (N2/N3) H puede ser mayor que W: el disco arriba (W × W) y el rotulo corto debajo. hover = realce al pasar el raton.
function fvPaintButtonN(g, id, W, H, state, hover) {
   var cx = W / 2, cy = W / 2, R = W / 2 - 3, on = state === "on", dis = state === "disabled";
   g.antialiasing = true; g.textAntialiasing = true;
   g.fillRect(0, 0, W, H, new Brush(0xff110D09));
   if (H > W + 4) {
      // (la fuente se encoge con un contador propio: cpFont redondea el tamaño y «pixelSize − 0,5» volvia al mismo: bucle infinito con
      // los rotulos largos en castellano, medido el 4-nov en fv_nA_test)
      var lab = fvTx("lab." + id), px = Math.max(6, Math.min(0.19 * W, (H - W) * 0.78)), f = cpFont("display", px, false, false, 1);
      for (var it = 0; it < 20 && f.width(lab) > W - 2 && px > 6; ++it) { px = Math.max(6, px - 1); f = cpFont("display", px, false, false, 1); }
      g.font = f; g.pen = new Pen(dis ? 0xff5E4214 : (hover ? 0xffFFE9A8 : 0xffE5B53F)); g.drawText((W - f.width(lab)) / 2, W + (H - W) * 0.72, lab);
   }
   if (hover && !dis) g.fillCircle(cx, cy, R + 2.5, new RadialGradientBrush(new Point(cx, cy), R + 3, new Point(cx, cy), [[0.75, 0x80FFF3C4], [1, 0x00FFF3C4]]));
   if (on) g.fillCircle(cx, cy, R + 2.5, new RadialGradientBrush(new Point(cx, cy), R + 3, new Point(cx, cy), [[0.7, 0xa0E5B53F], [1, 0x00E5B53F]]));
   g.fillCircle(cx, cy, R, fvBrassBrush(cx, cy, R));
   g.pen = new Pen(0xff5E4214, 0.8);
   for (var i = 0; i < 60; ++i) { var p = fvPol(R, i * 6), q = fvPol(R - 2.2, i * 6); g.drawLine(cx + p[0], cy + p[1], cx + q[0], cy + q[1]); }
   var ri = R - 4;
   g.fillCircle(cx, cy, ri, new RadialGradientBrush(new Point(cx - ri * 0.3, cy - ri * 0.35), ri * 1.5, new Point(cx - ri * 0.3, cy - ri * 0.35),
      on ? [[0, 0xffD9B260], [0.6, 0xffA77C2C], [1, 0xff6B4C18]] : [[0, 0xffF3D27E], [0.55, 0xffC99A3A], [1, 0xff7A5A1E]]));
   g.pen = new Pen(0xff3B2A0C, 0.8); g.drawCircle(cx, cy, ri);
   fvEngrave(g, id, cx, cy, ri, on);
   if (on) { g.pen = new Pen(0xffF3D27E, 2); g.drawCircle(cx, cy, R + 1.2); }
   if (dis) g.fillCircle(cx, cy, R + 0.5, new Brush(0xa0110D09));
}

class FVBrassButton extends Control {
   constructor(parent, def, size, onClick, height) {
      super(parent);
      this.def = def; this.state = "normal"; this.enabledFV = true; this.onClickFV = onClick; this.hoverFV = false;
      this.setFixedSize(size, height || size);
      this.toolTip = fvBtnTip(def);
      this.cursor = new Cursor(StdCursor_PointingHand);
      var self = this;
      this.onPaint = function() {
         if (typeof CSH_PAINTING === "number") ++CSH_PAINTING;
         var g = new Graphics(self);
         try { fvPaintButton(g, self.def.id, self.width, self.height, !self.enabledFV ? "disabled" : self.state, self.hoverFV); } finally { g.end(); if (typeof CSH_PAINTING === "number") --CSH_PAINTING; }
      };
      this.onMousePress = function() { if (self.enabledFV && typeof self.onClickFV === "function") self.onClickFV(self.def.id); };
      this.onEnter = function() { self.hoverFV = true; self.update(); };
      this.onLeave = function() { self.hoverFV = false; self.update(); };
   }
   // (N7) tamaño proporcional a la foto: el disco b × b y el rotulo debajo (alto bh)
   setSizeFV(b, bh) { if (this.width !== b || this.height !== bh) { this.setFixedSize(b, bh); this.update(); } }
   setTipFV(html) { if (html !== this.tipFV) { this.tipFV = html; this.toolTip = html; } }
   setStateFV(state, enabled) {
      if (state === this.state && enabled === this.enabledFV) return;
      this.state = state; this.enabledFV = enabled; this.update();
   }
}
