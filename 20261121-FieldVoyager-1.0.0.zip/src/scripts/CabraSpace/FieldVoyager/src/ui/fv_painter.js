// ============================================================================
// FieldVoyager/src/ui/fv_painter.js — EL PINTOR PJSR DE LA ESCENA (3-nov-2026, F1)
// ----------------------------------------------------------------------------
// Lee la escena (engine/fv_scene.js) y el piloto (engine/fv_pilot.js) y dibuja UN fotograma en un Bitmap RGB32. Nada se calcula
// fuera de aqui ni se ejecuta ningun proceso: el onPaint del dialogo solo hace drawBitmap de este Bitmap (regla 4).
// Como se pinta rapido (sonda F0a, tests/fv_perf_probe.log, y sonda F1 tests/fv_f1_probe.log):
//   · capas de nebulosa: cada una es un plano; su Bitmap se dibuja con una HOMOGRAFIA (Graphics.transformationMatrix 3×3, fila
//     mayor, vector columna: medido en la sonda F1 P1) y composicion Add: las mascaras suman 1, asi que desde la Tierra la suma de
//     las capas es la foto sin estrellas; el orden de dibujo da igual (Add conmuta). Planos que cruzan la camara: en 8×8 teselas.
//   · estrellas: sprites precalculados por (color cuantizado, nivel) con nucleo gaussiano y halo, en Add, con drawBitmap
//   · estelas del warp: drawLine con plumas en cache, solo las 10 000 mas brillantes (presupuesto F0a)
//   · destello, viñeteado suave y la cabina de la ventana (marco de laton, esquineras, remaches) encima
// ES5 (salvo nada: no hay clases aqui).
// ============================================================================

var FV_PAINT = { NEAR: 1e-4, WARP_MAX: 2200, WARP_AA: 300,   // (F2) 7000/1500 -> 5500/1200: con el cielo entero G<5,5 el warp de extremo a extremo rozaba 41,7 ms al salir de casa; (N6) 5000/1000 con cabezas y polvo dio p95 52 ms (tests/fv_nB_test.log, corrida 3) y un crucero blanco empastado -> 3000/500; con Max p95 54 ms (Add 26: Max cuesta el doble) -> 2200/300 y TRAIL_PX 0,30 -> 0,26 (el coste va con el largo)
                  // (N6) TRAIL_PX 0,12 -> 0,30 y TRAIL_K 0,22 -> 0,35: rayas largas en crucero (eran cortas y escasas: f2_warp_espectacular)
                  TRAIL_PX: 0.26, TRAIL_K: 0.35, TILE: 8, TILE_RAMP: 3, TILE_STEP: 0.12, VIGNETTE: 0.38, SMOOTH: true,
                 // (F2) la foto sin estrellas se ve desde la Tierra y se funde con las capas en el primer 3 % del camino a la nebulosa
                 PHOTO_FADE: 0.03,
                 // (F2) capas vistas de canto: se apagan entre |cos| 0,55 y 0,15 (la mirada casi paralela al plano: eran costuras rectas)
                 EDGE_LO: 0.15, EDGE_HI: 0.55,
                 // (F4b) DENTRO de la losa de capas (o a menos de un grosor) el canto no las apaga del todo: queda EDGE_IN (niebla alrededor;
                 // a 0 la nebulosa desaparecia al orbitar una estrella de dentro, f2_orbita del 4-nov)
                 EDGE_IN: 0.35,
                 // (F4b) NIEBLA de dentro: con la camara dentro de la losa, el trozo de foto sin estrellas de alrededor, suavizado (FOG_K de
                 // opacidad en Screen, FOG_SPAN del ancho de la foto): el gas se ve en TODAS las direcciones, tambien mirando hacia fuera desde una cara de la
                 // nebulosa (f2_llegada_cine: mirando a la Tierra desde una estrella de IC 1848 quedaba negro). ESTETICO, no es una medida.
                 FOG_K: 0.3, FOG_SPAN: 0.3, FOG_GAMMA: 1.7, FOG_DET: 640, FOG_MIX: 0.65,
                 // (F2) las estrellas de distancia SUPUESTA se atenuan 2 magnitudes (x0,16) en cuanto la camara se aleja de la Tierra
                 // (un 2 % de la distancia de la nebulosa): desde casa siguen como en la foto; fuera, no forman «bolas» de mentira
                 ASSUMED_DM: 2.0, ASSUMED_AWAY: 0.02,
                 // (F2) el cono (ver paintStars): fuera de casa, las que se ven mas debiles que CONE_GC (el cielo amplio llega a G 9,5;
                 // 2 de margen) se apagan CONE_DM magnitudes, con una rampa de CONE_SOFT
                 CONE_GC: 11.5, CONE_DM: 8, CONE_SOFT: 1.5, DEPTH_BY_FOV: "auto",   // (B, 5.ª corrida) profundidad uniforme al abrir el campo desde casa (false = ROJO, la «bola»); (nP) "auto" = solo sin PRINT_ONLY (ver paintStars)
                 // (F4b) EL TUBO: las estrellas que el catalogo solo trae en un cono (las de la foto, G > 12,5, en su radio; las del anillo, G 9,5–12,5,
                 // en su radio de ~1,9°) llenan un tubo, no el espacio. Desde dentro, las del tubo a mas de su radio se ven apretadas en pocos grados
                 // (el grumo de la llegada); solo la esfera de UN radio del tubo alrededor de la camara esta muestreada por igual en todas las
                 // direcciones. Se apagan desde CONE_TUBE radios (rampa hasta el doble). Medido el 4-nov en la llegada a la A9V de 2 940 a.l.:
                 // 0,25 × d -> 33 frente a 34 (sin efecto); 3 radios de la foto -> 285 frente a 381 (sigue el grumo: eran las del anillo).
                 // CONE_NEAR = la fraccion de d si la escena no trae los radios. CONE_NEAR_ON = false = la regla de F2 (ROJO)
                 CONE_TUBE: 1, CONE_NEAR: 0.02, CONE_NEAR_ON: true,
                 // (B2) las reglas del cono segun lo que SE VE (paintStars): rampa de TUBE_SOFT del radio del cono; CONE_BY_VIEW false = por distancia (ROJO)
                 CONE_BY_VIEW: true, TUBE_SOFT: 0.5,
                 // (F2) la protagonista: la estrella a la que se va o a la que se llego, en cuanto brilla mas que magnitud 3,5
                 HERO_MAG: 3.5, HERO_R0: 14, HERO_MAX: 120, HERO_SPR: 128,
                 // (F2) las capas se componen con Screen (1 − (1−a)(1−b)): saturan suave, nunca queman a blanco (F1: Add sumaba sin tope)
                 LAYER_OP: CompositionOp_Screen,
                 // (F4b) EL COLOR CON Y SIN POLVO: cada estrella pasa del color de la foto (todo su polvo delante) al VERDADERO (fv_dust.js)
                 // segun el polvo que queda entre la camara y ella. DUST_STEPS pasos de mezcla (el color ya va cuantizado a 6 niveles por canal).
                 // F2-D3: se hace POR DEFECTO (es lo fisicamente correcto); DUST_ON = false lo apaga (control en ROJO y por si Nino prefiere otra cosa).
                 DUST_ON: true, DUST_STEPS: 5, HERO_DUST_STEPS: 16,
                 // (F4b) LA VIA LACTEA de fondo (fv_milkyway.js): rejilla de MW_GW × MW_GH direcciones por fotograma, escalada a la pantalla;
                 // llega a plena intensidad al alejarse MW_AWAY × la distancia de la nebulosa (en casa ya esta en la foto: peso 0).
                 // MW_PEAK: el brillo del p99,5 del cielo visto desde el Sol (0,24 de blanco, con gamma 0,6: tenue pero visible; 0,15 y 0,75 dejaban la franja en 2/255 de mediana, f4 del 4-nov). MW_GRAIN: estrellas no resueltas.
                 MW_GW: 160, MW_GH: 90, MW_AWAY: 0.03, MW_PEAK: 0.24, MW_GAMMA: 0.6, MW_GRAIN: 5000,
                 // (N6) EL WARP DE TNG en el pintor. La fase sale de (warp, trail, flash) — lo que graba REC —, ver warpFx:
                 //   WARP_COMP   composicion de estrellas y estelas en el warp: Max (= Lighten) en vez de Add, para que los miles de
                 //               estrellas del cono apretadas en el punto de fuga NO se sumen en una bola blanca (f4_video_f060, defecto 5 de F4b)
                 //   WARP_SHAKE_PX  temblor de la preparacion (px a 1280 de ancho)
                 //   TRAIL_PX0 + TRAIL_PX·trail^1,5  largo maximo de una raya (fraccion del ancho): apenas en la preparacion, 31 % en crucero
                 //   WARP_HEAD   las WARP_AA rayas mas brillantes llevan cabeza brillante (este tramo final) y cola al WARP_TAIL de intensidad
                 //   WARP_DOPPLER  tinte azul hacia el punto de fuga y rojizo en los bordes, en crucero (discreto: mezcla del 22 %)
                 //   WARP_DUST_*  POLVO DE WARP: rayas sinteticas en el espacio de la camara (un tunel de estrellas como en TNG) que solo
                 //               salen con el warp: ESTETICO, no son estrellas del catalogo (el warp ya es ficcion). WARP_DUST_ON = false lo apaga
                 //   FLASH_*     destello azul-blanco centrado (sprite radial) + un velo leve en toda la pantalla
                 //   (§15, medido en TNG/Voyager) el destello es PEQUEÑO y en el punto de fuga: nucleo blanco tirando a azul-violeta, < 5 % del
                 //   cuadro muy brillante, una espiga vertical hasta ~0,9 del alto y otra horizontal mas corta; sin velo (FLASH_WASH 0). Su
                 //   duracion (0,8 s, sube 40 % / baja 60 %) la pone el piloto. Sin temblor (WARP_SHAKE_PX 0: ningun plano medido tiembla)
                 WARP_COMP: CompositionOp_Max, WARP_SHAKE_PX: 0, TRAIL_PX0: 0.012, WARP_HEAD: 0.35, WARP_TAIL: 0.45, WARP_DOPPLER: 0.22,
                 WARP_DUST_ON: true, WARP_DUST_N: 300, WARP_DUST_RATE: 0.9, WARP_DUST_I: 0.55,
                 FLASH_RGB: [222, 214, 255], FLASH_WASH: 0, FLASH_SIZE: 0.9, FLASH_CORE: 0.05, FLASH_SPIKE: 0.75,
                 // (B2, Nino: «las estelas son muy brillantes, el destello poco natural») ESTELAS V2: finas (≤ STREAK_W px) y tenues; la raya de
                 // una brillante sale de la estrella al STREAK_GAIN y se apaga hacia atras en STREAK_SEG tramos (× STREAK_FALL); las debiles a
                 // STREAK_FAINT. Antes: cabeza al 100 % y cola al 45 %, trazo de hasta 2,5 px (STREAK_V2 false = ROJO). DESTELLO V2: pulso
                 // suave azulado-blanco FLASH_RGB2 sin espigas que ilumina las estelas cercanas (STREAK_LIT); FLASH_V2 false = el de espigas (ROJO)
                 STREAK_V2: true, STREAK_W: 1.2, STREAK_GAIN: 0.42, STREAK_FALL: 0.5, STREAK_SEG: 3, STREAK_FAINT: 0.22, STREAK_LIT: 0.8,
                 FLASH_V2: true, FLASH_RGB2: [196, 214, 255],
                 // (B, costura de IC 1848) BORDE DE LAS CAPAS: el borde suave del build (18 %) es RECTO; dentro o al lado de la losa, de
                 // lado, los bordes x1 de las 8 capas caen en pantalla como rayas casi verticales (nA_llegada_profunditas: costura a ~55 %).
                 // Se apaga ademas la franja de EDGE_SOFT × el lado mayor junto a cada borde, con un borde ONDULADO (EDGE_WOB de amplitud,
                 // tres senos por capa): ni recto ni a escalon. Una vez, al crear el pintor, sobre los Bitmap de las capas (tambien los
                 // exporta D). EDGE_SOFT 0 = como antes (ROJO).
                 // (2.ª vuelta) EDGE_MODE "line" (POR DEFECTO: franja de ancho fijo EDGE_SOFT con ondulacion EDGE_WOB) | "contour" (la caida
                 // sigue las isofotas de la propia capa, ver fvSoftEdgeApply; relativo 0,57, PEOR) | "lum" (el ancho depende de la luz del pixel; probado: PEOR,
                 // lo brillante aguanta hasta el borde y lo corta en seco, escalon relativo 0,61 frente a 0,30 del rojo) | "lum":
                 // EDGE_LUM = [ancho para lo debil, para lo brillante], ondulacion EDGE_LUM_WOB) | "off" (ROJO). PHOTO_EDGE = [ancho, ondulacion]
                 // del borde de la FOTO en la revelacion (mascara en Multiply, solo cuando su borde entra en pantalla; 0 = ROJO)
                 // (RUTA, D2 del analisis de la ruta, 4-nov) franja mas ESTRECHA: 0,14 + 0,12 apagaban el 18 % de cada lado (la parte limpia era
                 // el 33 % del area de la foto y dos tercios de los destinos caian en el borde oscurecido, R14). 0,10 + 0,07 dejan la media luz
                 // a ~0,12 del lado mayor, donde ya la deja el borde suave del build (FV_BUILD.EDGE 0,18): parte limpia ~52 % del area.
                 // EDGE_OLD = la franja de antes (ROJO: FV_PAINT.EDGE_SOFT = EDGE_OLD[0], EDGE_WOB = EDGE_OLD[1])
                 EDGE_MODE: "line", EDGE_SOFT: 0.10, EDGE_WOB: 0.07, EDGE_OLD: [0.14, 0.12], EDGE_LUM: [0.30, 0.03], EDGE_LUM_WOB: 0.06, PHOTO_EDGE: [0.12, 0.06],
                 // "contour": CONT = [ancho de la franja, ondulacion, umbral junto al borde (× p98 de la capa), rampa (× p98), ultima franja dura]
                 CONT: [0.30, 0.05, 0.7, 0.9, 0.03], CONT_RES: 96,
                 // (nF2, 4-nov noche; Nino, E3: «parece que se dibujan mas estrellas fuera del campo que hemos adquirido») EL UNIVERSO ES LA FOTO:
                 // solo se pintan las estrellas cuya direccion desde la Tierra cae dentro del rectangulo de la foto (fvPrintW); las de fuera (en
                 // Collinder 34: 4 334 que Gaia trae algo mas alla del marco, 1 347 del anillo y 8 204 del cielo de 12°) se apagan en PRINT_SOFT del
                 // medio lado mas alla del borde. Se veian al salir del campo (warp a una estrella del borde: hasta 237 en pantalla, 211 claras).
                 // PRINT_ONLY false = ROJO (todas)
                 PRINT_ONLY: true, PRINT_SOFT: 0.03,
                 // (nP-2) las estrellas se apagan con el borde de la foto (franja PHOTO_EDGE, kE): false = ROJO (sobresalen de la foto visible)
                 // STAR_EDGE_RAMP: su rampa, mas lenta que la del borde de la foto (0,04): con 0,04 el zoom de campo apagaba de golpe la franja (I2)
                 STAR_EDGE: true, STAR_EDGE_RAMP: 0.15,
                 // (11-nov) la protagonista crece al llegar (ver paintHero): × K desde FROM veces la distancia de llegada; tope MAX px
                 HERO_NEAR: { ON: true, K: 2.0, FROM: 8, MAX: 150, ON_PHOTO: 0.85 } };   // ON_PHOTO: cuanto del crecimiento se quita si la estrella cae sobre la foto

function FVPainter(scene, bmps) {
   this.scene = scene;
   this.layers = (bmps && bmps.layers) ? bmps.layers : [];
   // una sola vez por juego de capas (la marca va en el objeto bmps de JS: un Bitmap nativo puede no guardar propiedades nuevas)
   var softKey = FV_PAINT.EDGE_MODE + ":" + FV_PAINT.EDGE_SOFT + ":" + FV_PAINT.EDGE_WOB + ":" + FV_PAINT.EDGE_LUM + ":" + FV_PAINT.EDGE_LUM_WOB + ":" + FV_PAINT.CONT;
   this.bmpsRef = bmps || {};
   if (bmps && bmps.layers && bmps._fvSoft !== softKey) { this.softenLayers(); bmps._fvSoft = softKey; }
   this.layersN2c = (bmps && bmps._fvN2c && bmps._fvN2c.length === this.layers.length) ? bmps._fvN2c : null;   // (19-nov, N2c) las capas con el cielo fundido hacia el borde (null con FV_N2C.ON = false)
   this.photoPlane = (bmps && bmps.starless) ? bmps.starless : null;
   this.hero = {}; this.hits = []; this.heroIdx = -1;
   this.nmThumb = null; this.nmThumbBuild();                      // (20-nov, O1) la miniatura de TU FOTO, una sola vez (src/ui/fv_navmodes.js la dibuja)
   this.spr = {}; this.sprH = {}; this.pens = {};
   this.vig = null; this.vigKey = "";
   this.stats = { ms: 0, stars: 0, trails: 0, layers: 0, tiles: 0 };
   this.colKey = null; this.keyMix = null; this.colKeyG = null; this.keyMixG = null;
   // (5-nov, Nino: «que las estrellas se vean como Gaia o como están en la imagen») EL ASPECTO DE LAS ESTRELLAS (src/engine/fv_photostars.js):
   // "gaia" (lo de siempre: con el no cambia ni un pixel) | "phcol" | "phstar". setStarLook lo pone; las claves de color de la foto y los recortes
   // escalados se hacen una vez (las claves al elegir, los recortes la primera vez que se pintan a una escala)
   this.look = "gaia"; this.ps = null; this.colKeyPh = null; this.keyMixPh = null; this.psCache = {}; this.psCacheN = 0;
   this.stats.mwRemaps = 0;
   this.mwOn = true; this.mw = null; this.mwRef = 0; this.mwGrain = null; this.mwSmall = null; this.mwSpr = null;
   if (scene.stars) {
      var S = scene.stars, K = FV_PAINT.DUST_STEPS; this.colKey = new Uint8Array(S.n);
      for (var i = 0; i < S.n; ++i) this.colKey[i] = fvColKey(S.col[i]);
      // (F4b) las claves de color de cada paso de la mezcla foto -> verdadero (j = 0 foto … K−1 verdadero)
      if (S.colTrue && scene.dust) {
         this.keyMix = new Uint8Array(S.n * K);
         for (i = 0; i < S.n; ++i) for (var j = 0; j < K; ++j) this.keyMix[i * K + j] = (S.dustCell[i] >= 0) ? fvColKey(fvMixRgb(S.col[i], S.colTrue[i], j / (K - 1))) : this.colKey[i];
      }
      // (B1, 5-nov) las mismas claves con el color de la TEMPERATURA de Gaia (colG, y colGT sin polvo): el aspecto GAIA con FV_PS.GAIA_TEMP. Se hacen
      // siempre que la escena las traiga (la bandera se mira al pintar)
      if (S.colG) {
         this.colKeyG = new Uint8Array(S.n);
         for (i = 0; i < S.n; ++i) this.colKeyG[i] = fvColKey(S.colG[i]);
         if (S.colTrue && scene.dust) {
            this.keyMixG = new Uint8Array(S.n * K);
            for (i = 0; i < S.n; ++i) for (j = 0; j < K; ++j) this.keyMixG[i * K + j] = (S.dustCell[i] >= 0) ? fvColKey(fvMixRgb(S.colG[i], S.colGT[i], j / (K - 1))) : this.colKeyG[i];
         }
      }
   }
}
// (5-nov) EL ASPECTO DE LAS ESTRELLAS: look "gaia" | "phcol" | "phstar"; ps = la medida de src/build/fv_ps_build.js (fvPsEnsure). Sin medida
// (o con FV_PS.ON false) se queda en "gaia". -> el aspecto puesto
FVPainter.prototype.setStarLook = function(look, ps) {
   var S = this.scene.stars, b1 = this.gaiaTemp();
   // (B1) COLOR ("phcol") ya no se mide: es el color de la foto de la escena (scene.stars.col), asi que se pone sin ps
   if (typeof FV_PS === "undefined" || !FV_PS.ON || !fvPsIsLook(look) || (look !== "gaia" && !(ps && ps.ok) && !(b1 && look === "phcol")) || !S) look = "gaia";
   this.look = look; this.ps = (look === "gaia") ? null : ((ps && ps.ok) ? ps : null);
   if (look !== "gaia" && this.ps && this.ps.rgb && (!this.colKeyPh || this.colKeyPhOf !== ps)) {
      // las claves de color con el color MEDIDO en la foto (las que no lo tienen, el de la escena) y su mezcla hacia el color sin polvo
      var K = FV_PAINT.DUST_STEPS, i, j;
      this.colKeyPh = new Uint8Array(S.n);
      for (i = 0; i < S.n; ++i) this.colKeyPh[i] = (ps.rgb[i] >= 0) ? fvColKey(ps.rgb[i]) : this.colKey[i];
      this.keyMixPh = null;
      if (this.keyMix) {
         this.keyMixPh = new Uint8Array(S.n * K);
         for (i = 0; i < S.n; ++i) for (j = 0; j < K; ++j) this.keyMixPh[i * K + j] = (ps.rgb[i] >= 0 && S.dustCell[i] >= 0) ? fvColKey(fvMixRgb(ps.rgb[i], S.colTrue[i], j / (K - 1))) : ((ps.rgb[i] >= 0) ? this.colKeyPh[i] : this.keyMix[i * K + j]);
      }
      this.colKeyPhOf = ps; this.psCache = {}; this.psCacheN = 0;
   }
   return this.look;
};
// (B1) ¿GAIA es el color de la temperatura (y COLOR el de la foto)? FV_PS.GAIA_TEMP y FV_PS.ON, y que la escena traiga colG. false = el STELLAE de antes
FVPainter.prototype.gaiaTemp = function() { return typeof FV_PS !== "undefined" && FV_PS.ON === true && FV_PS.GAIA_TEMP === true && !!this.colKeyG; };
// (B1) el juego de colores del aspecto puesto: { key, mix (claves; mix null sin mapa de polvo), c (color visto desde casa), t (color sin polvo) }.
// GAIA con GAIA_TEMP = la temperatura; todo lo demas (COLOR, FOTO, y GAIA sin la bandera) = el color de la escena; con la bandera apagada y
// COLOR/FOTO, las claves del color medido phcol (el STELLAE de antes)
FVPainter.prototype.colSet = function() {
   var S = this.scene.stars, b1 = this.gaiaTemp();
   if (b1 && this.look === "gaia") return { key: this.colKeyG, mix: this.keyMixG, c: S.colG, t: S.colGT };
   if (!b1 && this.ps && this.look !== "gaia" && this.colKeyPh) return { key: this.colKeyPh, mix: this.keyMixPh, c: S.col, t: S.colTrue };
   return { key: this.colKey, mix: this.keyMix, c: S.col, t: S.colTrue };
};
// el recorte de la estrella i a la escala sc (px de pantalla por px de recorte), cuantizada a 1/8 de octava: { b, k } (k = escala real)
FVPainter.prototype.psScaled = function(i, sc) {
   var q = Math.round(8 * Math.log(sc) / Math.LN2), key = i * 128 + (q + 64), c = this.psCache[key];
   if (c) return c;
   var sp = this.ps.spr[i], b0 = this.ps.bmp ? this.ps.bmp[i] : null;
   if (!sp || !b0) return null;
   if (this.psCacheN > 12000) { this.psCache = {}; this.psCacheN = 0; }
   var s = Math.pow(2, q / 8), sw = Math.max(1, Math.round(sp.w * s)), sh = Math.max(1, Math.round(sp.h * s));
   c = { b: (sw === sp.w && sh === sp.h) ? b0 : b0.scaledTo(sw, sh), kx: sw / sp.w, ky: sh / sp.h };
   this.psCache[key] = c; ++this.psCacheN; ++this.stats.psNew;
   return c;
};
// (F4b) lo que queda de polvo entre la camara y la estrella i (1 = todo, como desde casa; 0 = nada, junto a ella)
FVPainter.prototype.dustLeft = function(P, i) {
   var S = (typeof fvTimeStars === "function") ? fvTimeStars(this.scene) : this.scene.stars, D = this.scene.dust;   // (nP, AETAS) la posicion del año elegido
   if (!D || !S.dustCell || S.dustCell[i] < 0 || !(S.eStar[i] > 0)) return 1;
   var p = P.cam.pos, dE = S.dEarth[i], t = (S.x[i] * p[0] + S.y[i] * p[1] + S.z[i] * p[2]) / Math.max(1e-9, dE);
   return fvDustLeft(D.tabs[S.dustCell[i]], t / FV_LY_PER_PC, dE / FV_LY_PER_PC, S.eStar[i]);
};
// (F4b) el color de la estrella i visto desde la camara (mezcla foto -> verdadero); sin mapa o con DUST_ON apagado, el de la foto
FVPainter.prototype.starColour = function(P, i, steps) {
   var S = this.scene.stars, cs = this.colSet();
   if (!FV_PAINT.DUST_ON || !cs.t || !this.scene.dust || S.dustCell[i] < 0) return cs.c[i] >>> 0;
   var n = steps || FV_PAINT.HERO_DUST_STEPS, w = Math.round((1 - this.dustLeft(P, i)) * (n - 1)) / (n - 1);
   return fvMixRgb(cs.c[i], cs.t[i], w);
};
// el sprite de (clave de color, nivel[, paso de fundido aq de FV_LOOK.A_Q]): RGB32 sobre negro, para Add. Deja su media anchura en
// this.sprHl (nP: con el fundido la clave ya no es ck·64 + lev)
FVPainter.prototype.sprite = function(ck, lev, exaggerate, aq) {
   var AQ = FV_LOOK.A_Q || 16; if (aq === undefined || aq >= AQ) aq = AQ;
   var key = ck * 64 + lev + (exaggerate ? 100000 : 0) + (AQ - aq) * 1000000;
   var b = this.spr[key];
   if (b) { this.sprHl = this.sprH[key]; return b; }
   ++this.stats.newSpr;
   var c = fvColOfKey(ck), pr = fvLookParams(lev), s = pr.sigma, I = pr.I * aq / AQ, half = Math.max(2, Math.min(44, Math.ceil(6 * s)));
   if (exaggerate) { var m = Math.max(c[0], c[1], c[2], 1), mn = Math.min(c[0], c[1], c[2]); for (var q = 0; q < 3; ++q) c[q] = Math.round(255 * Math.max(0, (c[q] - mn * 0.85)) / Math.max(1, m - mn * 0.85)); }
   var sz = 2 * half + 1;
   b = new Bitmap(sz, sz, BitmapFormat.RGB32);
   var px = new Uint32Array(b.pixelData());
   for (var y = 0; y < sz; ++y) for (var x = 0; x < sz; ++x) {
      var dx = x - half, dy = y - half, d2 = dx * dx + dy * dy, d = Math.sqrt(d2);
      var v = I * (Math.exp(-d2 / (2 * s * s)) + 0.09 * Math.exp(-d / (2.2 * s)));
      var r = Math.min(255, Math.round(c[0] * v + 255 * Math.max(0, v - 1) * 0.6)), g = Math.min(255, Math.round(c[1] * v + 255 * Math.max(0, v - 1) * 0.6)), bb = Math.min(255, Math.round(c[2] * v + 255 * Math.max(0, v - 1) * 0.6));
      px[y * sz + x] = (0xff000000 | (r << 16) | (g << 8) | bb) >>> 0;
   }
   this.spr[key] = b; this.sprH[key] = half; this.sprHl = half;
   return b;
};
FVPainter.prototype.pen = function(ck, lev, k, aa) {
   // (B2) 32 niveles de intensidad (antes 8: el escalon mas bajo, 1/8, no dejaba estelas tenues) y, con STREAK_V2, trazo fino (≤ STREAK_W px)
   var v2 = FV_PAINT.STREAK_V2, NQ = v2 ? 32 : 8, kq = Math.round(fvClamp(k, 0, 1) * NQ), key = (((ck * 64 + lev) * 40 + kq) * 2 + (aa ? 1 : 0)) * 2 + (v2 ? 1 : 0), p = this.pens[key];
   if (p) return p;
   var c = fvColOfKey(ck), pr = fvLookParams(lev), I = Math.min(1, pr.I) * kq / NQ;
   var argb = (0xff000000 | (Math.round(c[0] * I) << 16) | (Math.round(c[1] * I) << 8) | Math.round(c[2] * I)) >>> 0;
   // trazos finos: el coste de una estela crece con su ancho y su largo (sonda F0a); sin antialiasing, 1 px
   p = new Pen(argb, aa ? Math.max(1, Math.min(v2 ? FV_PAINT.STREAK_W : 2.5, 0.9 * pr.sigma)) : 1); try { p.cap = PenCap_Round; } catch (eC) {}
   this.pens[key] = p;
   return p;
};
// viñeteado: un Bitmap ARGB negro con alfa radial (se dibuja con SourceOver)
FVPainter.prototype.vignette = function(W, H) {
   var key = W + "x" + H;
   if (this.vig && this.vigKey === key) return this.vig;
   // (F4b) una por tamaño (la pantalla y el video): alternar entre las dos no las rehace
   if (!this.vigs) this.vigs = {};
   if (this.vigs[key]) { this.vig = this.vigs[key]; this.vigKey = key; return this.vig; }
   var b = new Bitmap(W, H, BitmapFormat.ARGB32), px = new Uint32Array(b.pixelData()), cx = W / 2, cy = H / 2, R = Math.sqrt(cx * cx + cy * cy);
   for (var y = 0; y < H; ++y) for (var x = 0; x < W; ++x) {
      var d = Math.sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy)) / R, a = FV_PAINT.VIGNETTE * fvSmooth((d - 0.55) / 0.45);
      px[y * W + x] = ((Math.round(255 * a) << 24) >>> 0);
   }
   this.vig = b; this.vigKey = key; this.vigs[key] = b;
   return b;
};

// ---------------------------------------------------------------------------
// (nP, PROFUNDITAS) LA INCLINACION DE LAS CAPAS Y EL GIRO (ROLL) DE LA CAMARA
// Contrato (lo comparten el mapa —fvNavTiltPt de fv_nav.js—, el piloto de Q y este pintor): scene.nebula.tilt = [X, Y] grados; cada
// plano gira alrededor del centro de la nebulosa [0, 0, distLy], primero X y luego Y; scene.nebula.normal = la normal (sin inclinar +Z).
// DECIDIDO SIN NINO: cada capa es el MISMO plano que el del contrato (su centro girado y la normal), pero su cuadrilatero es el corte de ese
// plano con el haz de la foto desde la Tierra (las 4 esquinas son los rayos de las esquinas de la foto): desde casa la suma de capas
// sigue siendo la foto exacta. Girar el rectangulo rigido (fvNavTiltPt en las esquinas) descuadraba las 8 capas entre si al estar en
// casa (con 15° y 114 a.l. de grosor, el centro de la capa 0 se iba 14,8 a.l.: el 17 % del alto de la foto). Sin inclinacion: el camino
// de antes, identico. FV_PAINT.TILT_ON false = sin inclinacion aunque la escena la traiga (ROJO).
// Roll: cam.roll (rad) gira la base del proyector alrededor de la mirada (r' = cos·r + sin·d, d' = −sin·r + cos·d: con roll > 0 lo que
// estaba a la derecha sube; la camara gira en sentido horario y la imagen al reves). El proyector es del piloto (fvProjector, de Q); mientras no lo lleve el (pr.roll === undefined), el pintor lo gira aqui.
// ---------------------------------------------------------------------------
FV_PAINT.TILT_ON = true;
function fvPaintTiltPt(p, D, t) {
   if (typeof fvNavTiltPt === "function") return fvNavTiltPt(p, D, t);
   if (!t || (!t[0] && !t[1])) return p.slice();
   var q = [p[0], p[1], p[2] - D];
   q = fvRotate(q, [1, 0, 0], t[0] * FV_DEG); q = fvRotate(q, [0, 1, 0], t[1] * FV_DEG);
   return [q[0], q[1], q[2] + D];
}
// el giro inverso (mundo -> marco de la losa sin inclinar)
function fvPaintTiltInv(p, D, t) {
   var q = [p[0], p[1], p[2] - D];
   q = fvRotate(q, [0, 1, 0], -t[1] * FV_DEG); q = fvRotate(q, [1, 0, 0], -t[0] * FV_DEG);
   return [q[0], q[1], q[2] + D];
}
// la inclinacion de la escena -> null (sin inclinar) | { t, D, n }
FVPainter.prototype.tiltOf = function() {
   var N = this.scene.nebula, t = N && N.tilt;
   if (!FV_PAINT.TILT_ON || !t || (!(Math.abs(t[0]) > 1e-9) && !(Math.abs(t[1]) > 1e-9))) return null;
   // la normal SALE de tilt (la verdad del contrato): scene.nebula.normal puede venir sin actualizar ([0, 0, 1] de fvSceneSetNebula)
   var n = fvNorm(fvPaintTiltPt([0, 0, 1], 0, t));
   return { t: t, D: N.distLy, n: n };
};
// el punto (wx, wy) de la capa L (coordenadas sin inclinar, a la profundidad L.z) en el plano inclinado: el rayo desde la Tierra por ese
// punto cortado con el plano (centro girado, normal n). Sin inclinacion, [wx, wy, L.z] tal cual
FVPainter.prototype.planePt = function(L, wx, wy, T) {
   if (!T) return [wx, wy, L.z];
   var c = fvPaintTiltPt([0, 0, L.z], T.D, T.t), dx = wx / L.z, dy = wy / L.z, den = T.n[0] * dx + T.n[1] * dy + T.n[2];
   var s = (T.n[0] * c[0] + T.n[1] * c[1] + T.n[2] * c[2]) / (Math.abs(den) > 1e-12 ? den : 1e-12);
   return [s * dx, s * dy, s];
};
// distancia de la camara al plano de la capa L (con signo: + = la camara delante, del lado de la Tierra)
FVPainter.prototype.planeDist = function(L, pos, T) {
   if (!T) return L.z - pos[2];
   var c = fvPaintTiltPt([0, 0, L.z], T.D, T.t);
   return T.n[0] * (c[0] - pos[0]) + T.n[1] * (c[1] - pos[1]) + T.n[2] * (c[2] - pos[2]);
};
// el proyector con el roll de la camara (si el piloto aun no lo trae)
function fvPaintRoll(pr, roll) {
   if (!roll || pr.roll !== undefined) return pr;
   var c = Math.cos(roll), s = Math.sin(roll), r = pr.r, d = pr.d;
   var r2 = [c * r[0] + s * d[0], c * r[1] + s * d[1], c * r[2] + s * d[2]], d2 = [-s * r[0] + c * d[0], -s * r[1] + c * d[1], -s * r[2] + c * d[2]];
   var px = pr.pos, f = pr.f, cx = pr.cx, cy = pr.cy, fw = pr.fw;
   var o = {}; for (var k in pr) if (Object.prototype.hasOwnProperty.call(pr, k)) o[k] = pr[k];
   o.r = r2; o.d = d2; o.roll = roll; o.B = { r: r2, d: d2, f: fw };
   o.project = function(p, near) {
      var vx = p[0] - px[0], vy = p[1] - px[1], vz = p[2] - px[2], zc = vx * fw[0] + vy * fw[1] + vz * fw[2];
      if (!(zc > (near || 1e-9))) return null;
      return [cx + f * (vx * r2[0] + vy * r2[1] + vz * r2[2]) / zc, cy + f * (vx * d2[0] + vy * d2[1] + vz * d2[2]) / zc, zc];
   };
   return o;
}

// ---------------------------------------------------------------------------
// UN FOTOGRAMA. opts: { hud, frame, vignette, info (estado de la ficha), legend } -> estadisticas
// ---------------------------------------------------------------------------
FVPainter.prototype.render = function(bmp, P, opts) {
   var o = opts || {}, t0 = fvNowMs(), W = bmp.width, H = bmp.height, cam = P.cam, st = this.stats;
   st.stars = 0; st.trails = 0; st.layers = 0; st.tiles = 0; st.newSpr = 0; st.coneHid = 0; st.centre = 0; st.nebOp = 0;
   bmp.fill(0xff000000);
   var pr = fvPaintRoll(fvProjector(cam, W, H), cam.roll), g = new Graphics(bmp);   // (nP) roll de la camara
   try {
      g.smoothInterpolation = FV_PAINT.SMOOTH && P.warp < 0.3;      // a toda velocidad no se nota y cuesta el doble (sonda F1 P5)
      var tm0 = fvNowMs();
      if (this.mwOn && this.scene.galaxy) this.paintMilkyWay(g, (P.lab && typeof fvLabSkyPr === "function") ? fvLabSkyPr(pr) : pr, P);   // (9-nov, LABORATORIO v4) el cielo de fondo en direcciones reales
      st.tMw = fvNowMs() - tm0;
      g.compositionOperator = FV_PAINT.LAYER_OP;
      var ta = fvNowMs();
      // (F12, 17-nov) con la camara casi PARADA el freno no se aplica: la llegada se pintaba con vecino mas proximo (bloques) y el freno solo vale para que el vuelo sea fluido
      var restF = !!(P.lab && this.labFastLayers && typeof FV_SHARP !== "undefined" && FV_SHARP.ON && FV_SHARP.SMOOTH && this.cameraAtRest(P)); st.sharpRest = restF;
      var smooth0 = g.smoothInterpolation; if (P.lab && this.labFastLayers && !restF) g.smoothInterpolation = false;   // (v2, LABORATORIO) p95: capas caras -> sin suavizado (el doble de rapido)
      this.paintLayers(g, pr, P);
      if (typeof fvObjectsPaint === "function") fvObjectsPaint(this, g, pr, P);   // (N8) objetos
      g.resetTransformation();
      if (typeof fvHrVeil === "function") fvHrVeil(this, g, P, W, H);   // (I2, 19-nov) el velo del diagrama HR, debajo de las estrellas (src/ui/fv_hr_ui.js; FV_HR.ON false = nada)
      g.compositionOperator = CompositionOp_Add;
      var tb = fvNowMs();
      if (P.lab) { var tL = tb - ta; this.labFastLayers = this.labFastLayers ? tL > 0.5 * FV_LAB.PERF_LAYERS_MS : tL > FV_LAB.PERF_LAYERS_MS; g.smoothInterpolation = smooth0; }
      this.paintStars(g, pr, P);
      this.paintWarpDust(g, pr, P);
      if (typeof fvAmbPaint === "function") fvAmbPaint(this, g, pr, P);   // (11-nov) el campo de estrellas de fondo simulado, con paralaje (src/engine/fv_ambient.js; FV_AMB.ON false = nada)
      if (P.lab && typeof fvLabUiAnchorFrame === "function") fvLabUiAnchorFrame(this, pr, P, W, H);   // (8-nov, LABORATORIO, D10) ¿hay paisaje?
      if (typeof fvBoundsPaint === "function") fvBoundsPaint(this, g, pr, P);   // (9-nov, encargo C) los planos que limitan la imagen (src/ui/fv_bounds.js; FV_BOUNDS.ON false = nada)
      st.tLayers = tb - ta; st.tStars = fvNowMs() - tb;
      g.compositionOperator = CompositionOp_SourceOver;
      g.opacity = 1;
      if (P.flash > 0) this.paintFlash(g, W, H, P.flash);              // (N6) destello azul-blanco en el centro (antes, velo calido plano)
      if (o.vignette !== false) g.drawBitmap(0, 0, this.vignette(W, H));
      if (typeof fvHrPaint === "function") fvHrPaint(g, this, P, W, H, o);   // (I2) los ejes y rotulos del diagrama HR (nada sin diagrama)
      if (typeof fvRbPaint === "function") fvRbPaint(g, this, pr, P, W, H, o);   // (5-nov) columna derecha: nombres, constelaciones y escala (nada encendido = no toca g)
      if (typeof fvTrailsPaint === "function") fvTrailsPaint(g, this, pr, P, W, H);   // (I3, 19-nov) AETAS con proposito: las estelas de ±100 000 años (src/ui/fv_trails.js; FV_E1T false u «hoy» = no toca g)
      if (typeof fvFgPaint === "function") fvFgPaint(g, this, P, W, H, o);      // (Blender 2) la ventana de la nave (src/ui/fv_foreground.js; FV_FG.ON false = nada)
      if (o.hud !== false && typeof fvNmPaint === "function") fvNmPaint(g, this, P, W, H, pr, o.ui);   // (6-nov) Espacio: rotulo, piramide, marcadores, brujula
      if (o.hud !== false) fvHudPaint(g, this, pr, P, W, H, o);
      if (o.hud !== false && this.nmHits && this.nmHits.length) { for (var inh = 0; inh < this.nmHits.length; ++inh) this.hits.push(this.nmHits[inh]); }   // (20-nov, E-nav) el marcador TU FOTO se pulsa: sus zonas, las ultimas (src/ui/fv_navmodes.js)
      if (o.hud !== false && typeof fvTrailsHud === "function") fvTrailsHud(g, this, pr, P, W, H);   // (I3, 19-nov) la placa del año y los rotulos de lo notable (src/ui/fv_trails.js)
      if (o.hud !== false && P.lab && typeof fvLabUiPaint === "function") fvLabUiPaint(g, this, pr, P, W, H);   // (8-nov) el panel del laboratorio de vuelo
      if (typeof fvNmJumpPaint === "function") fvNmJumpPaint(g, this, P, W, H);   // (7-nov) el salto a casa: fundido dorado (tambien sin HUD: es la vista)
      if (o.frame !== false && !(st.fg && st.fg.frame)) fvFramePaint(g, W, H);   // (Blender 2) con la ventana renderizada, sin el marco dibujado
   } finally { g.end(); }
   st.ms = fvNowMs() - t0;
   return st;
};

// (F12) ¿la camara esta (casi) parada? Su velocidad (P.vel, a.l./s, la calcula el piloto cada fotograma) entre la distancia a la capa mas cercana de la nebulosa
// < FV_SHARP.REST_RATE (1/s). Sin velocidad (la escena sin piloto) o sin nebulosa: no. Barato: solo las capas, no las estrellas (fvNearestDist las recorre todas).
FVPainter.prototype.cameraAtRest = function(P) {
   var N = this.scene.nebula, v = P.vel;
   if (!N || !N.layers || !N.layers.length || !v || (P.warp || 0) > 0.05) return false;
   var sp = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]), d = 1e30, p = P.cam.pos, i;
   for (i = 0; i < N.layers.length; ++i) { var dz = Math.abs(N.layers[i].z - p[2]); if (dz < d) d = dz; }
   return sp < FV_SHARP.REST_RATE * Math.max(d, 1e-9);
};
FVPainter.prototype.paintLayers = function(g, pr, P) {
   var N = this.scene.nebula;
   if (!N || this.layers.length === 0) return;
   var cam = P.cam, spacing = (N.layers.length > 1) ? N.thickLy / (N.layers.length - 1) : N.thickLy;
   // desde la Tierra, la foto sin estrellas (identica a la suma de las capas, sin su borde suave); al salir, las capas
   var wP = this.photoPlane ? 1 - fvSmooth(fvLen(cam.pos) / (FV_PAINT.PHOTO_FADE * N.distLy)) : 0;
   // de canto: el coseno entre la mirada y la normal de las capas (+Z)
   // (nP) con las capas inclinadas, la normal es la del contrato y la camara se mide en el marco de la losa sin inclinar
   var T = this.tiltOf(); this.stats.tilt = T ? T.t.slice() : null;
   var lk = fvNorm(cam.look), cL = T ? fvPaintTiltInv(cam.pos, T.D, T.t) : cam.pos;
   var ce = Math.abs(T ? fvDot(lk, T.n) : lk[2]), edge = fvSmooth((ce - FV_PAINT.EDGE_LO) / (FV_PAINT.EDGE_HI - FV_PAINT.EDGE_LO));
   var zA = N.layers[0].z, zB = N.layers[N.layers.length - 1].z, outZ = Math.max(0, zA - cL[2], cL[2] - zB), inW = 1 - fvSmooth(outZ / Math.max(1, N.thickLy));
   edge = Math.max(edge, FV_PAINT.EDGE_IN * inW); this.stats.inSlab = inW;
   this.stats.edge = edge; this.stats.wPhoto = wP;
   // (N6) en el salto la foto y las capas se apagan (quedan al 10 %): la vista pasa a ser el tunel de rayas; vuelven en la salida
   var wFade = 1 - 0.9 * fvSmooth(((typeof fvWarpFadeW === "function") ? fvWarpFadeW(P) : (P.warp || 0)) / 0.6);   // (20-nov, W1b) fvWarpFadeW: P.warp, o el apagado de la carga del warp
   this.stats.warpLayerFade = wFade;
   var wP0 = wP; if (wFade < 0.999) { wP *= wFade; edge *= wFade; }
   if (wP > 0.002 && this.photoPlane) {
      var L0 = N.layers[0], d0 = N.distLy;
      var Lp = { z: d0, x0: L0.x0 / L0.z * d0, y0: L0.y0 / L0.z * d0, x1: L0.x1 / L0.z * d0, y1: L0.y1 / L0.z * d0 };
      this.drawPlane(g, pr, P, this.photoPlane, Lp, wP, spacing);
      // (B) el borde de la foto en pantalla (revelacion, vuelta a casa): kE sube de 0 a 1 cuando un canto entra en el cuadro (rampa del 4 %)
      var pqL = this.photoQuad(pr), kE = (FV_PAINT.PHOTO_EDGE[0] > 0 && pqL) ? pqL.kE : 0;   // (nP-2) el mismo kE que usan las estrellas
      this.stats.photoEdge = kE;
      if (kE > 0.002) {
         var keepOp2 = g.compositionOperator; g.compositionOperator = CompositionOp_Multiply;
         this.drawPlane(g, pr, P, this.photoEdgeMask(), Lp, kE, spacing);
         g.compositionOperator = keepOp2;
      }
   }
   if (typeof fvNmGhostPaint === "function") fvNmGhostPaint(this, g, pr, P);   // (6-nov, LOS DOS MODOS) en Espacio, la foto fantasma en su plano
   g.compositionOperator = FV_PAINT.LAYER_OP;
   // (6-nov, F3 de los dos modos) en el Espacio, con la camara DENTRO de la losa, niebla y capas se aclaran (nunca un campo de color uniforme)
   var nmF = (typeof fvNmSlabFade === "function") ? fvNmSlabFade(P) : 1; this.stats.slabFade = nmF;
   if (inW > 0.01 && this.photoPlane) this.paintFog(g, P, N, inW * wFade * nmF, pr, cL);
   var opL = (1 - wP0) * edge * nmF; this.stats.nebOp = opL;   // (11-nov) la opacidad de la nebulosa (capas o volumen): la leen el campo de fondo y la protagonista
   // (16-nov, P22) velo: con FV_VEIL.MODE > 0 y un objeto escalado a la losa, las capas van a un lienzo aparte al que se le resta el pedestal (veilClose); MODE 0 = gs es g, lo de antes
   var vl = (typeof FV_VEIL !== "undefined" && FV_VEIL.MODE > 0 && opL > 0.01 && this.photoPlane && typeof fvVeilActive === "function" && fvVeilActive(this.scene)) ? this.veilOpen(g, pr) : null, gs = vl ? vl.g : g;
   this.stats.veil = null;
   if (opL > 0.01 && N._vol && typeof FV_VOLM !== "undefined" && FV_VOLM.ON && typeof fvVolPaintSlab === "function") { fvVolPaintSlab(this, gs, pr, P, N, opL); gs.compositionOperator = FV_PAINT.LAYER_OP; gs.opacity = 1; if (vl) this.veilClose(g, vl, opL); g.compositionOperator = FV_PAINT.LAYER_OP; g.opacity = 1; return; }   // (V2) nebulosa extensa en cortes con polvo
   // (19-nov, N2c) con el borde de la foto bien DENTRO de la pantalla (FV_N2C.SHOW: mIn de photoQuad, 12-25 % del ancho), las capas con el cielo fundido hacia el borde (this.layersN2c) en vez de las de siempre; en la rampa las dos con pesos kN y 1 − kN
   var kN = 0; this.stats.n2c = 0;
   if (opL > 0.01 && this.layersN2c && typeof FV_N2C !== "undefined" && FV_N2C.ON) { var pqN = this.photoQuad(pr); kN = pqN ? fvN2cShowK(pqN.mIn / pr.W) : 0; if (kN < 0.002) kN = 0; else if (kN > 0.998) kN = 1; this.stats.n2c = kN; }
   if (opL > 0.01) for (var k = 0; k < N.layers.length; ++k) {
      var L = N.layers[k], bm = this.layers[k];
      if (!bm) continue;
      if (kN > 0 && this.layersN2c[k]) {
         if (kN < 1 && this.drawPlane(gs, pr, P, bm, L, opL * (1 - kN), spacing)) ++this.stats.layers;
         if (this.drawPlane(gs, pr, P, this.layersN2c[k], L, opL * kN, spacing)) ++this.stats.layers;
      } else if (this.drawPlane(gs, pr, P, bm, L, opL, spacing)) ++this.stats.layers;
   }
   gs.opacity = 1;
   if (vl) this.veilClose(g, vl, opL);
   g.opacity = 1;
};
// (16-nov, P22) el pedestal de cielo de la foto sin estrellas: p25 por canal sobre una miniatura de 64 px (lo de la niebla, sacado a metodo para que lo use tambien el velo). -> this.fogPed [r, g, b]
FVPainter.prototype.skyPed = function() {
   if (this.fogPed) return this.fogPed;
   var pp = this.photoPlane;
   var sm = new Uint32Array(pp.scaledTo(64, Math.max(2, Math.round(64 * pp.height / pp.width))).pixelData()).slice(), ch3 = [[], [], []];   // .slice(): el Bitmap temporal no queda vivo
   for (var t = 0; t < sm.length; ++t) { ch3[0].push((sm[t] >>> 16) & 255); ch3[1].push((sm[t] >>> 8) & 255); ch3[2].push(sm[t] & 255); }
   this.fogPed = ch3.map(function(a) { a.sort(function(p1, p2) { return p1 - p2; }); return a[Math.floor(0.25 * (a.length - 1))]; });
   return this.fogPed;
};
// (16-nov, P22) EL VELO: las capas de la losa se pintan en un lienzo aparte y se les resta (pedestal + margen) × su opacidad antes de sumarlas al fotograma (FV_VEIL, fv_objects.js).
// No hay resta en Graphics: max(0, x − c) = 255 − min(255, (255 − x) + c) = Difference(blanco) · Add(c) · Difference(blanco). Devuelve { bmp, g } o null
FVPainter.prototype.veilOpen = function(g, pr) {
   if (!this.veilBmp || this.veilBmp.width !== pr.W || this.veilBmp.height !== pr.H) this.veilBmp = new Bitmap(pr.W, pr.H, BitmapFormat.RGB32);
   this.veilBmp.fill(0xff000000);
   var gs = new Graphics(this.veilBmp);
   gs.compositionOperator = FV_PAINT.LAYER_OP; gs.smoothInterpolation = g.smoothInterpolation;
   return { bmp: this.veilBmp, g: gs, W: pr.W, H: pr.H };
};
FVPainter.prototype.veilClose = function(g, vl, opL) {
   vl.g.end();
   var ped = this.skyPed(), m = (FV_VEIL.MODE === 2) ? FV_VEIL.MARGIN : 0, c = [], i;
   for (i = 0; i < 3; ++i) c.push(Math.max(0, Math.min(255, Math.round((ped[i] + m) * opL))));
   this.stats.veil = c;
   var g3 = new Graphics(vl.bmp);
   try {
      g3.antialiasing = false; g3.opacity = 1;
      g3.compositionOperator = CompositionOp_Difference; g3.fillRect(0, 0, vl.W, vl.H, new Brush(0xffffffff));
      g3.compositionOperator = CompositionOp_Add; g3.fillRect(0, 0, vl.W, vl.H, new Brush((0xff000000 | (c[0] << 16) | (c[1] << 8) | c[2]) >>> 0));
      g3.compositionOperator = CompositionOp_Difference; g3.fillRect(0, 0, vl.W, vl.H, new Brush(0xffffffff));
   } finally { g3.end(); }
   g.compositionOperator = FV_PAINT.LAYER_OP; g.opacity = 1;
   g.resetTransformation(); g.drawBitmap(0, 0, vl.bmp);
};
// (F4b) la niebla de dentro de la nebulosa: el trozo de la foto sin estrellas alrededor de la posicion de la camara (FOG_SPAN del ancho),
// muy suavizado y estirado a toda la pantalla, en Screen con opacidad FOG_K: nubes con estructura, no un velo plano (el velo plano
// levantaba los negros: f4_dentro_nebulosa_canto del 4-nov). Se rehace al moverse 1/64 de la foto.
FVPainter.prototype.paintFog = function(g, P, N, inW, pr, cLocal) {
   var L0 = N.layers[0], c = cLocal || P.cam.pos, zc = Math.max(1, c[2]), pp = this.photoPlane;   // (nP) cLocal: la camara en el marco de la losa sin inclinar
   var u = (c[0] / zc * L0.z - L0.x0) / (L0.x1 - L0.x0), v = (c[1] / zc * L0.z - L0.y0) / (L0.y1 - L0.y0);
   var inside = fvSmooth(Math.min(u, 1 - u, v, 1 - v) / 0.08), k = FV_PAINT.FOG_K * inW * inside;
   this.stats.fog = k;
   if (k <= 0.01) return;
   var qu = Math.round(u * 64), qv = Math.round(v * 64), key = qu + ":" + qv + ":" + pr.W + "x" + pr.H;
   if (this.fogKey !== key) {
      var sw = FV_PAINT.FOG_SPAN * pp.width, sh = sw * pr.H / pr.W, cx = qu / 64 * pp.width, cy = qv / 64 * pp.height;
      var x0 = Math.round(fvClamp(cx - sw / 2, 0, pp.width - sw)), y0 = Math.round(fvClamp(cy - sh / 2, 0, pp.height - sh));
      if (!this.fogPed) this.skyPed();   // el fondo de cielo de la foto (p25 por canal): se resta, para que la niebla no levante los negros
      var crop = new Bitmap(pp, x0, y0, Math.round(x0 + sw), Math.round(y0 + sh)), pd = this.fogPed;
      // sin el fondo y con contraste (potencia FOG_GAMMA): huecos oscuros entre las nubes, no un velo
      var fg = function(x, p0) { var t = Math.max(0, x - p0) / Math.max(1, 255 - p0); return 255 * Math.pow(t, FV_PAINT.FOG_GAMMA); };
      // (4-nov, Nino: «darle detalle de la foto») dos escalas: la bruma ancha de antes (48 px) y el DETALLE del mismo trozo de foto a
      // FOG_DET px de ancho (filamentos y bordes del gas), mezclados FOG_MIX; antes era solo la bruma y se veia blando, sin estructura
      var Dw = Math.max(48, Math.min(FV_PAINT.FOG_DET, Math.round(sw))), Dh = Math.max(2, Math.round(Dw * pr.H / pr.W));
      var base = crop.scaledTo(48, Math.max(2, Math.round(48 * pr.H / pr.W))).scaledTo(320, Math.round(320 * pr.H / pr.W)).scaledTo(Dw, Dh);
      // OJO (4-nov, cierre en seco de PixInsight al entrar en IC 1848): la vista Uint32Array de pixelData() apunta a la memoria
      // NATIVA del Bitmap; si el Bitmap ya no se usa despues, V8 puede recogerlo a mitad del bucle y la vista lee memoria liberada.
      // Por eso: los pixeles de la bruma se COPIAN (.slice()), el bucle no crea objetos (menos recolecciones) y det se escribe
      // en una copia que vuelve al Bitmap con .set() al final, con det vivo
      var det = crop.scaledTo(Dw, Dh), bpx = new Uint32Array(base.pixelData()).slice(), dpx = new Uint32Array(det.pixelData()).slice(), mx = FV_PAINT.FOG_MIX;
      // (5-nov noche, PERF orbita de f2) fg solo ve 256 valores por canal: tabla de 3 × 256 con los MISMOS dobles (pixel identico, medido en
      // tests/_perf_orbita/probe_orbita_ab.log). El bucle con Math.pow por pixel costaba 41 ms de los 43 de cada rehecho (614 × 345 px), y en la
      // orbita dentro de IC 1848 se rehace cada ~0,5 s: eran los fotogramas de 50–90 ms del p95
      var lR = new Float64Array(256), lG = new Float64Array(256), lB = new Float64Array(256), m0 = 1 - mx;
      for (var x8 = 0; x8 < 256; ++x8) { lR[x8] = fg(x8, pd[0]); lG[x8] = fg(x8, pd[1]); lB[x8] = fg(x8, pd[2]); }
      for (var j = 0; j < dpx.length; ++j) {
         var a0 = bpx[j], a1 = dpx[j];
         var rr = Math.min(255, Math.round(m0 * lR[(a0 >>> 16) & 255] + mx * lR[(a1 >>> 16) & 255]));
         var gg = Math.min(255, Math.round(m0 * lG[(a0 >>> 8) & 255] + mx * lG[(a1 >>> 8) & 255]));
         var bb = Math.min(255, Math.round(m0 * lB[a0 & 255] + mx * lB[a1 & 255]));
         dpx[j] = (0xff000000 | (rr << 16) | (gg << 8) | bb) >>> 0;
      }
      new Uint32Array(det.pixelData()).set(dpx);
      this.fogBmp = det.scaledTo(pr.W, pr.H);
      this.fogKey = key;
   }
   var keep = g.compositionOperator; g.compositionOperator = CompositionOp_Screen; g.opacity = Math.min(1, k);
   g.drawBitmap(0, 0, this.fogBmp);
   g.opacity = 1; g.compositionOperator = keep;
};
// un plano (capa o foto) a profundidad L.z con opacidad base op0 -> true si se dibujo
FVPainter.prototype.drawPlane = function(g, pr, P, bm, L, op0, spacing) {
   var cam = P.cam, i, T = this.tiltOf();
   {
      // cerca del plano, se desvanece (un plano a un paso de la camara seria una pared borrosa). (nP) Inclinado: la distancia a lo largo de la normal
      var dz = Math.abs(this.planeDist(L, cam.pos, T)), op = op0 * fvSmooth(dz / spacing);
      if (op <= 0.01) return false;
      g.opacity = op;
      var bw = bm.width, bh = bm.height, C = [[L.x0, L.y0], [L.x1, L.y0], [L.x1, L.y1], [L.x0, L.y1]], q = [], ok = true;
      for (i = 0; i < 4; ++i) { var p = pr.project(this.planePt(L, C[i][0], C[i][1], T), FV_PAINT.NEAR * L.z); if (!p) { ok = false; break; } q.push([p[0], p[1]]); }
      if (ok) {
         if (this.offscreen(q, pr.W, pr.H)) return false;
         var Hm = fvHomography([[0, 0], [bw, 0], [bw, bh], [0, bh]], q);
         if (!Hm) return false;
         // casi de frente: la homografia se cambia por la afin de tres esquinas. Qt tiene un camino rapido para lo afin y otro
         // ~3 veces mas lento para la perspectiva (medido: 35 ms frente a 11 con 8 capas casi de frente, fv_f1_test.log del 3-nov).
         // Error: |h20|·bw + |h21|·bh < 1e-3 → menos de 1e-3 de la diagonal de la capa en pantalla.
         if (Math.abs(Hm[6]) * bw + Math.abs(Hm[7]) * bh < 1e-3) Hm = [(q[1][0] - q[0][0]) / bw, (q[3][0] - q[0][0]) / bh, q[0][0], (q[1][1] - q[0][1]) / bw, (q[3][1] - q[0][1]) / bh, q[0][1], 0, 0, 1];
         g.transformationMatrix = new Matrix(Hm[0], Hm[1], Hm[2], Hm[3], Hm[4], Hm[5], Hm[6], Hm[7], Hm[8]);
         g.drawBitmap(0, 0, bm);
         g.resetTransformation();
         return true;
      } else {
         // el plano cruza la camara: teselas delante. Cada tesela lleva UNA opacidad (la de su profundidad media) que se apaga al
         // acercarse a la camara (sin eso quedaba un corte recto donde la capa cruza el plano de la camara: f1_orbita.png). Si la
         // rampa cambia mucho dentro de una tesela, se parte en 3×3 (hasta dos veces): con teselas enteras y la opacidad de la
         // esquina mas cercana, el salto entre vecinas dibujaba COSTURAS verticales rectas (f2_orbita_capas_peor_angulo.png, 4-nov).
         var T = FV_PAINT.TILE, drew = false, ramp = FV_PAINT.TILE_RAMP * spacing;
         for (var ty = 0; ty < T; ++ty) for (var tx = 0; tx < T; ++tx)
            if (this.drawTile(g, pr, bm, L, Math.floor(bw * tx / T), Math.floor(bh * ty / T), Math.floor(bw * (tx + 1) / T), Math.floor(bh * (ty + 1) / T), op, ramp, 0)) drew = true;
         g.resetTransformation();
         return drew;
      }
   }
};
FVPainter.prototype.drawTile = function(g, pr, bm, L, u0, v0, u1, v1, op, ramp, depth) {
   var bw = bm.width, bh = bm.height, UV = [[u0, v0], [u1, v0], [u1, v1], [u0, v1]], qq = [], zmin = 1e30, zmax = -1e30, zs = 0, i, T = this.tiltOf(), P4 = [], nBack = 0;
   if (u1 - u0 < 2 || v1 - v0 < 2) return false;
   for (i = 0; i < 4; ++i) {
      var wx = L.x0 + (L.x1 - L.x0) * UV[i][0] / bw, wy = L.y0 + (L.y1 - L.y0) * UV[i][1] / bh, pp = pr.project(this.planePt(L, wx, wy, T), FV_PAINT.NEAR * L.z);
      P4.push(pp); if (!pp) ++nBack;
   }
   // (5-nov noche, PERF orbita) las CUATRO esquinas detras del plano cercano: la profundidad es afin (o lineal-fraccional con inclinacion) sobre la
   // tesela, su maximo esta en una esquina, asi que toda subtesela queda detras y la recursion (1 + 9 + 81 llamadas) no dibujaba nada. Con la
   // camara dentro de la losa eran ~17 000 llamadas por fotograma para nada (tests/_perf_orbita/probe_orbita2.log). Resultado identico
   if (nBack === 4) return false;
   if (nBack > 0) {
      if (depth < 2) return this.splitTile(g, pr, bm, L, u0, v0, u1, v1, op, ramp, depth);
      return false;
   }
   for (i = 0; i < 4; ++i) { var pq = P4[i]; qq.push([pq[0], pq[1]]); zmin = Math.min(zmin, pq[2]); zmax = Math.max(zmax, pq[2]); zs += pq[2]; }
   if (this.offscreen(qq, pr.W, pr.H)) return false;
   if (depth < 2 && zmin < ramp && (fvSmooth(zmax / ramp) - fvSmooth(zmin / ramp)) > FV_PAINT.TILE_STEP) return this.splitTile(g, pr, bm, L, u0, v0, u1, v1, op, ramp, depth);
   var tf = fvSmooth(0.25 * zs / ramp);
   if (tf <= 0.01) return false;
   g.opacity = op * tf;
   var Ht = fvHomography([[0, 0], [u1 - u0, 0], [u1 - u0, v1 - v0], [0, v1 - v0]], qq);
   if (!Ht) return false;
   g.transformationMatrix = new Matrix(Ht[0], Ht[1], Ht[2], Ht[3], Ht[4], Ht[5], Ht[6], Ht[7], Ht[8]);
   g.drawBitmapRect(0, 0, bm, u0, v0, u1, v1);
   ++this.stats.tiles;
   return true;
};
FVPainter.prototype.splitTile = function(g, pr, bm, L, u0, v0, u1, v1, op, ramp, depth) {
   var drew = false, n = 3;
   for (var j = 0; j < n; ++j) for (var k = 0; k < n; ++k)
      if (this.drawTile(g, pr, bm, L, Math.floor(u0 + (u1 - u0) * k / n), Math.floor(v0 + (v1 - v0) * j / n), Math.floor(u0 + (u1 - u0) * (k + 1) / n), Math.floor(v0 + (v1 - v0) * (j + 1) / n), op, ramp, depth + 1)) drew = true;
   return drew;
};
FVPainter.prototype.offscreen = function(q, W, H) {
   var x0 = 1e30, y0 = 1e30, x1 = -1e30, y1 = -1e30;
   for (var i = 0; i < q.length; ++i) { x0 = Math.min(x0, q[i][0]); x1 = Math.max(x1, q[i][0]); y0 = Math.min(y0, q[i][1]); y1 = Math.max(y1, q[i][1]); }
   return (x1 < 0 || y1 < 0 || x0 > W || y0 > H);
};

FVPainter.prototype.paintStars = function(g, pr, P) {
   // (nP, AETAS) las estrellas del año elegido en la maquina del tiempo (src/engine/fv_time.js): x, y, z nuevos, lo demas compartido;
   // hoy (o sin datos) es scene.stars tal cual. La huella (printW) sigue siendo la de HOY: la foto es de hoy
   var S = (typeof fvTimeStars === "function") ? fvTimeStars(this.scene) : this.scene.stars;
   if (!S) return;
   var cam = P.cam, lim = fvLookLimits(cam.fov, P.homeFov), px = cam.pos[0], py = cam.pos[1], pz = cam.pos[2];
   var f = pr.f, cx = pr.cx, cy = pr.cy, W = pr.W, H = pr.H, r = pr.r, d = pr.d, fw = pr.fw;
   var SS = pr.S || 1;                                   // (8-nov, LABORATORIO, D1) exageracion lateral: se proyecta (S·x, S·y, z); el brillo con la distancia REAL
   var sideF = !!(P.lab && typeof fvLabSideFadeK === "function");
   var trail = P.trail > 0.02, back = null, nT = 0, fx = this.warpFx(P);
   if (trail) {
      var R = (P.flight && P.flight.T) ? fvLen(fvSub(P.flight.T, cam.pos)) : 1;   // (F2) el destino es fl.T
      var dl = FV_PAINT.TRAIL_K * P.trail * R;
      back = [px - fw[0] * dl, py - fw[1] * dl, pz - fw[2] * dl];
   }
   // (N6) largo maximo de la raya: apenas en la preparacion (trail 0,14 -> 2,7 % del ancho), 31 % en crucero
   var maxL = W * (FV_PAINT.TRAIL_PX0 + FV_PAINT.TRAIL_PX * Math.pow(Math.max(0, P.trail), 1.5)), buckets = {}, bkeys = [];
   // (N6) temblor de la preparacion y tinte Doppler del crucero; composicion Max en el warp (sin bola blanca en el punto de fuga)
   var shA = FV_PAINT.WARP_SHAKE_PX * fx.shake * W / 1280, tt = P.t || 0, dop = fx.doppler > 0.01, hd2 = 0.25 * (W * W + H * H), abK = 1 - fx.aberr;
   var keepOp = g.compositionOperator;
   if (fx.max) g.compositionOperator = FV_PAINT.WARP_COMP;
   this.stats.warpComp = fx.max; this.stats.shake = fx.shake;
   // en el warp, las que pasan cerca no crecen mas que el nivel DIM+4 (la estela ya dice que estan cerca): los sprites grandes
   // cuestan por area y eran el 80 % del fotograma lento (fv_f1_test.log de las 23:27: 3 515 estrellas en 35 ms)
   var levCap = (P.trail > 0.25) ? FV_LOOK.DIM + 4 : 999;
   var dRef = this.scene.nebula ? this.scene.nebula.distLy : 1000, dmAss = FV_PAINT.ASSUMED_DM * fvSmooth(fvLen(cam.pos) / (FV_PAINT.ASSUMED_AWAY * dRef));
   // (I2, 19-nov) el diagrama HR de este fotograma (null = no hay: todo como siempre). Con el, sin protagonista aparte: viaja como las demas
   var hrF = (typeof fvHrFrame === "function") ? fvHrFrame(this, P, W, H) : null;
   var hero = hrF ? null : this.heroOf(P), heroI = hero ? hero.i : -1;
   this.heroIdx = heroI; this.stats.dmAss = dmAss;
   // (F2) EL CONO: el catalogo tiene estrellas debiles (G < 19) solo en el ~1° de la foto, y del resto del cielo solo las G < 9,5.
   // Desde dentro, todas las de detras del objetivo se apretaban en ese grado y formaban un «cumulo» falso alrededor de la
   // protagonista (f2_llegada_protagonista.png, 4-nov). Fuera de casa se ocultan las que se ven mas debiles que el limite del
   // cielo completo (CONE_GC): quedan las que brillan por estar CERCA (eso si es 3D real) y el cielo amplio. En casa no cambia nada.
   // (N6, 1.ª corrida) en el warp, desde el salto, el cono se trata como «fuera de casa» aunque la nave aun este cerca: miles de estrellas
   // debiles del cono apretadas en el punto de fuga formaban un disco blanco (nB_warp_tira, columnas 5–6) y costaban 95 ms de p95
   var distAway = fvSmooth(fvLen(cam.pos) / (FV_PAINT.ASSUMED_AWAY * dRef)), trailAway = fvSmooth(((P.trail || 0) - 0.16) / 0.3);
   var away = Math.max(distAway, trailAway), coneGc = (this.scene.facts && this.scene.facts.coneGc) || FV_PAINT.CONE_GC;   // del build: hasta donde llega el cielo completo
   this.stats.coneAway = away; this.stats.coneGc = coneGc;
   var Fc = this.scene.facts || {}, wideG = (Fc.wideMag > 0) ? Fc.wideMag : coneGc - 2, ringG = Fc.ringMag || 12.5;
   // (B2, 4-nov, Nino: «hago rodar un poco el raton y las estrellas desaparecen muy pronto») EL CONO SEGUN LO QUE SE VE, no segun lo
   // lejos que se esta de casa. Las reglas del cono (CONE_NEAR, CONE_GC, ASSUMED_DM) se encendian con la DISTANCIA a la Tierra (un 2 % de
   // la de la nebulosa): con tres muescas de rueda (41 a.l. de 6 536) ya apagaban la mitad de las estrellas de la foto y con seis todas
   // (tests/fv_nB2_node.js, R1), aunque la vista siguiera mirando por DENTRO del cono de la foto, donde el catalogo es completo y no hay
   // grumo posible. Ahora cada estrella pregunta si, a SU profundidad, el corte de la vista cabe en el cono del catalogo: con la camara
   // en c mirando a f (semidiagonal de la vista tanHd), a la profundidad Z de la estrella el centro de la vista esta en q = c + s·f
   // (s = (Z − c_z) / f_z) y su radio es s·tanHd / f_z; el cono tiene radio Z·tan(cono). Si radio(vista) ≤ radio(cono) no hay borde que
   // ver a esa profundidad y la regla no se aplica (kS = 0); si lo pasa, entra con una rampa (TUBE_SOFT). Llegando a una estrella con
   // 60° de campo, o de lado, kS = 1: igual que antes. CONE_BY_VIEW = false = la regla por distancia (ROJO).
   var byView = FV_PAINT.CONE_BY_VIEW && distAway > 0.001, tanHd = Math.sqrt(W * W + H * H) / (2 * f), fz = fw[2];
   var tanCp = Math.tan((Fc.coneDeg > 0 ? Fc.coneDeg : 0.6) * FV_DEG), tanCr = Math.tan((Fc.ringDeg > 0 ? Fc.ringDeg : 2 * (Fc.coneDeg > 0 ? Fc.coneDeg : 0.6)) * FV_DEG), tSoft = FV_PAINT.TUBE_SOFT, nTube = 0;
   var nearPhoto = (Fc.coneDeg > 0) ? FV_PAINT.CONE_TUBE * Math.tan(Fc.coneDeg * FV_DEG) : FV_PAINT.CONE_NEAR;
   var nearRing = (Fc.ringDeg > 0 && Fc.nRing > 0) ? FV_PAINT.CONE_TUBE * Math.tan(Fc.ringDeg * FV_DEG) : nearPhoto;
   this.stats.coneNear = nearPhoto; this.stats.coneNearRing = nearRing;
   // (B, 5.ª corrida) PROFUNDIDAD SEGUN EL CAMPO, junto a casa (la revelacion del cine, la vuelta a casa): el catalogo son regiones
   // anidadas — la foto (G < 19, ~coneDeg), el anillo (G < ringMag, ringDeg), el cielo de alrededor (G < wideMag, WIDE_DEG = 12°) y el
   // cielo entero (G < ALLSKY_MAG = 5,5). Al abrir el campo, el borde de cada region entra en la vista y se veia como un disco (la «bola»
   // de N11: con 66° el disco de 24° del cielo de alrededor, nB_cine_tira col. 2–3). Cuando el semicampo pasa de ~la mitad del radio de
   // una region, lo mas debil que la siguiente se apaga con una rampa: queda un cielo de profundidad uniforme y la foto dentro.
   var Bc = (typeof FV_BUILD !== "undefined") ? FV_BUILD : { WIDE_DEG: 12, ALLSKY_MAG: 5.5 }, hf = 0.5 * cam.fov / FV_DEG, near0 = 1 - distAway;
   var cDeg = Fc.coneDeg > 0 ? Fc.coneDeg : 0.6, rDeg = Fc.ringDeg > 0 ? Fc.ringDeg : 2 * cDeg, wDeg = Bc.WIDE_DEG || 12;
   var kR = fvSmooth((hf - 0.75 * cDeg) / cDeg), kW = fvSmooth((hf - 0.5 * rDeg) / rDeg), kA = fvSmooth((hf - 0.45 * wDeg) / (0.45 * wDeg));
   var depthG = 19.5; if (kR > 0) depthG = fvMix(depthG, ringG, kR); if (kW > 0) depthG = fvMix(depthG, wideG, kW); if (kA > 0) depthG = fvMix(depthG, (Bc.ALLSKY_MAG || 5.5) + 0.3, kA);
   // (nP, I1) DEPTH_BY_FOV "auto": solo sin PRINT_ONLY. La regla apagaba lo mas debil que el anillo y el cielo de alrededor para que no se
   // viera su DISCO; con la huella (nF2) esas regiones no se pintan y dentro de la foto el catalogo es completo: con 2× el campo de casa
   // dejaba solo las G < 12,5 (la escena se vaciaba al abrir el campo) y su rampa de 25 mag en 0,6 de G era un corte duro (8 040 saltos
   // en el zoom de tests/fv_nP_i12_node.js). Ahora lo lleva el brillo automatico (FV_LOOK.AUTO_*). El visor web nunca tuvo esta regla.
   // true = siempre (ROJO de I1/I2), false = nunca
   var depthRule = FV_PAINT.DEPTH_BY_FOV === true || (FV_PAINT.DEPTH_BY_FOV === "auto" && !(FV_PAINT.PRINT_ONLY && typeof fvPrintW === "function"));
   var depthOn = near0 > 0.001 && depthG < 19.4 && depthRule;
   this.stats.depthG = depthOn ? depthG : 99;
   var selI = (P.sel && P.sel.kind === "star") ? P.sel.i : ((P.flight && P.flight.sel && P.flight.sel.kind === "star") ? P.flight.sel.i : -1);
   var colS = this.colSet();
   var mixOn = FV_PAINT.DUST_ON && !!colS.mix && (px * px + py * py + pz * pz) > 1e-12, dTabs = this.scene.dust ? this.scene.dust.tabs : null, KM = FV_PAINT.DUST_STEPS, pcK = 1 / FV_LY_PER_PC;
   // (nF2) la huella de la foto: el peso de cada estrella (la direccion desde la Tierra no cambia: se calcula una vez)
   var pw = null;
   if (FV_PAINT.PRINT_ONLY && typeof fvPrintW === "function") {
      if (!this.printW || this.printW.length !== S.n || this.printSoft !== FV_PAINT.PRINT_SOFT) {
         this.printW = new Float32Array(S.n); this.printSoft = FV_PAINT.PRINT_SOFT;
         for (var iw = 0; iw < S.n; ++iw) this.printW[iw] = fvPrintW(this.scene, iw, FV_PAINT.PRINT_SOFT);
      }
      pw = this.printW;
   }
   this.stats.printHid = 0; this.stats.fadeHid = 0; this.stats.fading = 0; this.stats.lookOff = lim.off || 0;
   // (nP, I2) el fundido (FV_LOOK.FADE_*): por debajo de aMin no se pinta; AQ pasos de sprite
   var fadeOn = !!FV_LOOK.FADE_ON, aMin = FV_LOOK.A_MIN || 1 / 32, AQ = FV_LOOK.A_Q || 16;
   // (nP-2, 5-nov) AL ALEJARSE, LA FOTO PEQUEÑA: (a) con el borde de la foto en pantalla (kE, el mismo que apaga el borde de la foto en
   // paintLayers) las estrellas se apagan en la misma franja PHOTO_EDGE hacia dentro: ninguna sobresale de la foto visible (STAR_EDGE false
   // = ROJO); (b) el presupuesto de luz por area de foto (fvStarBudget, FV_BUDGET.ON false = ROJO): nunca mas luz por area que en casa
   var pq = this.photoQuad(pr), kE = (FV_PAINT.STAR_EDGE && pq) ? pq.kS : 0, pe = null, ebx = 1, eby = 1, kA = 1;
   if (kE > 0.002 && typeof fvPrintUV === "function") {
      if (!this.printUV || this.printUV.length !== 2 * S.n) { this.printUV = new Float32Array(2 * S.n); for (var iu = 0; iu < S.n; ++iu) { var uv = fvPrintUV(this.scene, iu); this.printUV[2 * iu] = uv[0]; this.printUV[2 * iu + 1] = uv[1]; } }
      pe = this.printUV; var fld = this.scene.field, lng = Math.max(fld.width, fld.height), eb = FV_PAINT.PHOTO_EDGE[0] + FV_PAINT.PHOTO_EDGE[1];
      ebx = 2 * eb * lng / fld.width; eby = 2 * eb * lng / fld.height;
   }
   if (typeof fvStarBudget === "function" && pq) { var bud = fvStarBudget(this.scene, cam, P.homeFov, pr, lim, pw, pq.q, W, H, pe ? { uv: pe, k: kE, bx: ebx, by: eby } : null); kA = bud.k; lim = bud.lim; this.stats.budget = { k: bud.k, dLim: bud.dLim, area: bud.area, vis: bud.vis, S: bud.S, B0: bud.B0 }; } else this.stats.budget = null;
   this.stats.kE = kE; this.stats.kA = kA;
   // (5-nov) EL ASPECTO: con "phcol"/"phstar" las claves de color medidas en la foto; con "phstar" ademas los recortes (fvPsWeights: escala,
   // luz y fundido al sprite de Gaia), que se dibujan DESPUES del bucle con su opacidad. Con "gaia" nada de esto se toca (identico a antes)
   var b1 = this.gaiaTemp(), psOn = !!(this.ps && this.look !== "gaia" && (b1 || this.colKeyPh)), keyArr = colS.key, mixArr = colS.mix;
   var sprOn = psOn && this.look === "phstar" && !!this.ps.spr, psList = sprOn ? [] : null, limH = sprOn ? fvLookLimits(P.homeFov, P.homeFov) : null;
   var psHome = sprOn ? fvPsHomeScale(this.scene, W, P.homeFov, this.ps.k) : 0, psTr = P.trail || 0;
   this.stats.look = (psOn || (b1 && this.look === "phcol")) ? this.look : "gaia"; this.stats.psDrawn = 0; this.stats.psFading = 0; this.stats.psNew = 0; this.stats.psMagMax = 0;
   var fgT = (typeof fvFgTracker === "function") ? fvFgTracker(this) : null;   // (Blender 2) las luces de la escena para la ventana
   g.antialiasing = true;
   for (var i = 0; i < S.n; ++i) {
      if (pw && pw[i] < 0.999 && i !== heroI && i !== selI && pw[i] <= 0.01) { ++this.stats.printHid; continue; }
      var vx = S.x[i] - px, vy = S.y[i] - py, vz = S.z[i] - pz, fqx = (SS === 1) ? vx : SS * vx, fqy = (SS === 1) ? vy : SS * vy, zc = fqx * fw[0] + fqy * fw[1] + vz * fw[2];
      if (!(zc > 1e-7)) continue;
      var sx = cx + f * (fqx * r[0] + fqy * r[1] + vz * r[2]) / zc, sy = cy + f * (fqx * d[0] + fqy * d[1] + vz * d[2]) / zc;
      if (sx < -80 || sy < -80 || sx > W + 80 || sy > H + 80) continue;
      if (shA > 0.02) { sx += shA * Math.sin(31 * tt + 1.7 * i); sy += shA * Math.cos(27 * tt + 2.3 * i); }     // (N6) temblor
      if (abK < 1) { sx = cx + (sx - cx) * abK; sy = cy + (sy - cy) * abK; }                                       // (E) aberracion en el salto
      var aw = away, kS = 1;
      if (byView) {
         if (fz > 0.05) {
            var sZ = (S.z[i] - pz) / fz;
            if (sZ > 0) { var qx = SS * px + sZ * fw[0], qy = SS * py + sZ * fw[1], rhoV = Math.sqrt(qx * qx + qy * qy) + sZ * tanHd / fz, rC = SS * S.z[i] * ((S.inFrame[i] && S.g[i] > ringG) ? tanCp : tanCr); kS = rC > 0 ? fvSmooth((rhoV / rC - 1) / tSoft) : 1; }
         }
         aw = Math.max(distAway * kS, trailAway);
         if (kS < 0.999) ++nTube;
      }
      var dc = Math.sqrt(vx * vx + vy * vy + vz * vz), m = fvApparentMag(S.g[i], S.dEarth[i], dc) + (S.q[i] === 2 ? dmAss * (byView ? kS : 1) : 0);
      if (pw && pw[i] < 0.999 && i !== heroI && i !== selI) { m -= 2.5 * Math.log(pw[i]) / Math.LN10; if (fvLookAlpha(m, lim) < aMin) { ++this.stats.printHid; continue; } }   // (nF2) borde de la huella
      // (F4b) el «grumo» de la llegada: las del cono MAS DEBILES que el limite del cielo completo (G desde la Tierra > coneGc) que NO estan
      // cerca de la camara (a mas de CONE_NEAR × su distancia a la Tierra) se apagan aunque desde aqui se vean claras: fuera del cono sus
      // gemelas no estan en el catalogo, asi que se veian como una bola de pocos grados detras de la protagonista (f2_llegada_protagonista.png).
      // Las cercanas de verdad (3D real, paralaje) se quedan.
      // (B, 5.ª corrida) profundidad segun el campo (ver arriba): las mas debiles que depthG se apagan, solo junto a casa
      if (depthOn && i !== heroI && i !== selI && S.g[i] > depthG - 0.5) { m += near0 * 25 * fvSmooth((S.g[i] - depthG + 0.5) / 0.6); if (fvLookAlpha(m, lim) < aMin) { ++this.stats.coneHid; continue; } }   // 25 mag: del todo fuera (con 8 quedaban en el suelo de fvLookLevel)
      if (FV_PAINT.CONE_NEAR_ON && aw > 0.001 && i !== heroI && i !== selI && S.g[i] > wideG) {
         var nk = dc / S.dEarth[i], coneNear = (S.inFrame[i] && S.g[i] > ringG) ? nearPhoto : nearRing;
         if (nk > coneNear) { m += aw * FV_PAINT.CONE_DM * fvSmooth((nk - coneNear) / coneNear); if (fvLookAlpha(m, lim) < aMin) { ++this.stats.coneHid; continue; } }
      }
      if (aw > 0.001 && i !== heroI && i !== selI && m > coneGc - FV_PAINT.CONE_SOFT) {
         m += aw * FV_PAINT.CONE_DM * fvSmooth((m - coneGc + FV_PAINT.CONE_SOFT) / FV_PAINT.CONE_SOFT);
         // el suelo de fvLookLevel dibuja TODA estrella a 0,22 aunque este bajo el limite: las del cono seguian ahi como puntitos
         // (y se pintaban 20 000 en el warp: 50 ms). Las apagadas por el cono, bajo el limite, no se dibujan.
         // (nP, I2) «bajo el limite» = alfa de fundido < A_MIN (con FADE_ON false, el corte duro de antes: m > magLim + 0,5)
         if (fvLookAlpha(m, lim) < aMin) continue;
      }
      // (nP, I2) EL FUNDIDO: alfa continuo por magnitud (con las reglas ya sumadas); la protagonista y la elegida, enteras. Con FADE_ON
      // false las estrellas sin regla se pintan en el suelo como antes (ROJO identico)
      var fa = (!fadeOn || i === heroI || i === selI) ? 1 : fvLookAlpha(m, lim);
      if (i !== heroI && i !== selI) { fa *= kA; if (pe) fa *= 1 - kE * (1 - fvPrintEdgeW(pe[2 * i], pe[2 * i + 1], ebx, eby)); }   // (nP-2)
      if (SS !== 1 && sideF && i !== heroI && i !== selI) fa *= fvLabSideFadeK(dc, Math.sqrt(fqx * fqx + fqy * fqy + vz * vz));   // (9-nov, LABORATORIO v4) las aplastadas de lado se apagan
      if (hrF) { fvHrStar(hrF, i, sx, sy, fa); sx = hrF.ox; sy = hrF.oy; fa = hrF.oa; }   // (I2) camino del diagrama HR (o atenuada si no tiene distancia)
      var aq = Math.round(fa * AQ);
      if (aq < 1) { ++this.stats.fadeHid; continue; }
      if (aq < AQ) ++this.stats.fading;
      var lev = fvLookLevel(m, lim), ck = keyArr[i];
      if (hrF) lev = fvHrLev(hrF, i, lev);   // (I2)
      if (mixOn && S.dustCell[i] >= 0) {
         // (F4b) proyeccion de la camara sobre la visual de la estrella -> polvo que queda -> paso de la mezcla
         var tP = (S.x[i] * px + S.y[i] * py + S.z[i] * pz) / S.dEarth[i], left = fvDustLeft(dTabs[S.dustCell[i]], tP * pcK, S.dEarth[i] * pcK, S.eStar[i]);
         ck = mixArr[i * KM + Math.round((1 - left) * (KM - 1))];
      }
      // (5-nov, "phstar") el recorte de la foto: su parte (1 − wG) va a la lista con su escala y opacidad; el sprite de Gaia se queda con wG
      var psGaia = true;
      if (sprOn && i !== heroI && this.ps.spr[i]) {
         var mH0 = S.g[i] + ((pw && pw[i] < 0.999) ? -2.5 * Math.log(pw[i]) / Math.LN10 : 0), wPs = fvPsWeights(m, mH0, lim, limH, psHome, psTr);
         if (hrF && hrF.ot > 0) wPs.wG += (1 - wPs.wG) * hrF.ot;   // (I2) camino del diagrama HR el recorte de la foto se funde al sprite
         var opPs = fa * wPs.alpha * (1 - wPs.wG);
         if (opPs >= 1 / 64) psList.push(i, sx, sy, wPs.scale, opPs);
         if (wPs.wG > 0.001 && wPs.wG < 0.999) ++this.stats.psFading;
         if (wPs.scale > this.stats.psMagMax) this.stats.psMagMax = wPs.scale;
         aq = Math.round(fa * wPs.wG * AQ); psGaia = aq >= 1;
      }
      if (lev > levCap) lev = levCap;
      if (trail && nT < FV_PAINT.WARP_MAX) {
         var bx = S.x[i] - back[0], by = S.y[i] - back[1], bz = S.z[i] - back[2];
         if (SS !== 1) { bx = SS * vx + fw[0] * dl; by = SS * vy + fw[1] * dl; bz = vz + fw[2] * dl; }   // (LABORATORIO) la estela en el espacio de vuelo
         var zb = bx * fw[0] + by * fw[1] + bz * fw[2];
         if (zb > 1e-7) {
            var tx = cx + f * (bx * r[0] + by * r[1] + bz * r[2]) / zb, ty = cy + f * (bx * d[0] + by * d[1] + bz * d[2]) / zb;
            if (abK < 1) { tx = cx + (tx - cx) * abK; ty = cy + (ty - cy) * abK; }
            // el largo de la estela, con tope en pantalla (el coste lo marca el largo del trazo: sonda F0a)
            var lx = tx - sx, ly = ty - sy, ll = Math.sqrt(lx * lx + ly * ly);
            if (ll > maxL) { tx = sx + lx * maxL / ll; ty = sy + ly * maxL / ll; }
            // (N6) Doppler discreto en crucero: hacia el punto de fuga azul, en los bordes rojizo (tres bandas por radio en pantalla)
            var ckT = ck;
            if (dop) { var rr2 = ((sx - cx) * (sx - cx) + (sy - cy) * (sy - cy)) / hd2; ckT = this.tintKey(ck, rr2 < 0.09 ? 0 : (rr2 > 0.42 ? 2 : 1)); }
            // a cubos por pluma: cambiar de pluma en cada trazo costaba mas que el trazo (40–55 ms con 7 000, frente a 20 ms de la sonda F0a,
            // que las tenia ordenadas por clave). Las mas brillantes con antialiasing; el resto sin (3–4 veces mas barato)
            var pk = (ckT * 64 + lev) * 2 + (nT < FV_PAINT.WARP_AA ? 1 : 0), bk = buckets[pk];
            if (!bk) { bk = buckets[pk] = { ck: ckT, lev: lev, aa: nT < FV_PAINT.WARP_AA, c: [] }; bkeys.push(pk); }
            bk.c.push(tx, ty, sx, sy);
            ++nT;
         }
      }
      if (fgT && lev >= fgT.lev0) fgT.add(sx, sy, lev, aq / AQ);                 // (Blender 2)
      if (i === heroI && hero.w >= 0.999) continue;          // la protagonista se pinta aparte, encima
      if (lev >= 4 && i !== heroI) { var ccx = sx - cx, ccy = sy - cy; if (ccx * ccx + ccy * ccy < 22500) ++this.stats.centre; }   // (F4b) las claras a < 150 px del centro (el «grumo»)
      if (!psGaia) continue;                                   // (5-nov, "phstar") todo recorte: el sprite no se pinta
      var sp = this.sprite(ck, lev, false, aq), h = this.sprHl;
      g.drawBitmap(Math.round(sx) - h, Math.round(sy) - h, sp);
      ++this.stats.stars;
   }
   // (5-nov, "phstar") LOS RECORTES DE LA FOTO, con la composicion de las estrellas (Add; Max en el warp) y su opacidad (1/32 de paso: se
   // cambia g.opacity solo cuando cambia). Premultiplicados sobre negro: el borde suma 0, sin cuadros
   if (psList && psList.length) {
      var opQ = -1;
      for (var ip = 0; ip < psList.length; ip += 5) {
         var c5 = this.psScaled(psList[ip], psList[ip + 3]); if (!c5) continue;
         var sp5 = this.ps.spr[psList[ip]], oq = Math.max(1, Math.round(32 * Math.min(1, psList[ip + 4]))) / 32;
         if (oq !== opQ) { g.opacity = oq; opQ = oq; }
         g.drawBitmap(Math.round(psList[ip + 1] - sp5.cx * c5.kx), Math.round(psList[ip + 2] - sp5.cy * c5.ky), c5.b);
         ++this.stats.psDrawn;
      }
      g.opacity = 1;
   }
   if (hero) this.paintHero(g, pr, P, hero);
   // las estelas, cubo a cubo. (N6) Las brillantes (aa) con cola tenue (WARP_TAIL) y cabeza brillante en su ultimo WARP_HEAD: la raya
   // «nace» en el punto de fuga y se enciende al pasar (degradado en dos trazos); el resto, un trazo a 0,7
   var kk = Math.min(1, P.trail * 1.2), hf = FV_PAINT.WARP_HEAD, nH = 0;
   if (FV_PAINT.STREAK_V2) {
      // (B2, Nino: «las estelas son muy brillantes») ESTELAS FINAS Y TENUES: la estrella (el sprite, ya pintado) es lo mas brillante; la
      // raya sale de ella al STREAK_GAIN y se apaga hacia atras en STREAK_SEG tramos (x STREAK_FALL cada uno); trazo ≤ STREAK_W px; las
      // debiles (sin antialiasing) a STREAK_FAINT. Con Max no se suman: nada satura a blanco. EL DESTELLO las ilumina un poco cerca del
      // punto de fuga (× 1 + STREAK_LIT · destello en un radio de 0,3 del alto) en vez de pegarse encima.
      var SG = FV_PAINT.STREAK_GAIN, SF = FV_PAINT.STREAK_FALL, NS = FV_PAINT.STREAK_SEG, lit = FV_PAINT.STREAK_LIT * (P.flash || 0), rL2 = Math.pow(0.3 * H, 2);
      for (var b2 = 0; b2 < bkeys.length; ++b2) {
         var B2 = buckets[bkeys[b2]], C2 = B2.c, j2, s2;
         g.antialiasing = B2.aa;
         if (lit <= 0.005) {        // sin destello: una pluma por cubo (y por tramo), no por raya (cambiar de pluma cuesta mas que el trazo)
            if (B2.aa) {
               for (s2 = 0; s2 < NS; ++s2) {
                  g.pen = this.pen(B2.ck, B2.lev, kk * SG * Math.pow(SF, s2), true);
                  for (j2 = 0; j2 < C2.length; j2 += 4) g.drawLine(C2[j2 + 2] + (C2[j2] - C2[j2 + 2]) * s2 / NS, C2[j2 + 3] + (C2[j2 + 1] - C2[j2 + 3]) * s2 / NS, C2[j2 + 2] + (C2[j2] - C2[j2 + 2]) * (s2 + 1) / NS, C2[j2 + 3] + (C2[j2 + 1] - C2[j2 + 3]) * (s2 + 1) / NS);
               }
               nH += C2.length / 4;
            } else { g.pen = this.pen(B2.ck, B2.lev, kk * FV_PAINT.STREAK_FAINT, false); for (j2 = 0; j2 < C2.length; j2 += 4) g.drawLine(C2[j2], C2[j2 + 1], C2[j2 + 2], C2[j2 + 3]); }
            continue;
         }
         for (j2 = 0; j2 < C2.length; j2 += 4) {
            var tx2 = C2[j2], ty2 = C2[j2 + 1], hx = C2[j2 + 2], hy = C2[j2 + 3], kL = 1;
            if (lit > 0.005) { var ex2 = hx - cx, ey2 = hy - cy; kL = 1 + lit * Math.exp(-(ex2 * ex2 + ey2 * ey2) / rL2); }
            if (B2.aa) {
               for (s2 = 0; s2 < NS; ++s2) {
                  g.pen = this.pen(B2.ck, B2.lev, kk * SG * Math.pow(SF, s2) * kL, true);
                  g.drawLine(hx + (tx2 - hx) * s2 / NS, hy + (ty2 - hy) * s2 / NS, hx + (tx2 - hx) * (s2 + 1) / NS, hy + (ty2 - hy) * (s2 + 1) / NS);
               }
               ++nH;
            } else { g.pen = this.pen(B2.ck, B2.lev, kk * FV_PAINT.STREAK_FAINT * kL, false); g.drawLine(tx2, ty2, hx, hy); }
         }
      }
      bkeys = [];
   }
   for (var b = 0; b < bkeys.length; ++b) {
      var B = buckets[bkeys[b]], C = B.c, j;
      g.antialiasing = B.aa;
      if (B.aa && P.trail > 0.3) {
         g.pen = this.pen(B.ck, B.lev, kk * FV_PAINT.WARP_TAIL, true);
         for (j = 0; j < C.length; j += 4) g.drawLine(C[j], C[j + 1], C[j + 2], C[j + 3]);
         g.pen = this.pen(B.ck, B.lev, kk, true);
         for (j = 0; j < C.length; j += 4) { g.drawLine(C[j + 2] + (C[j] - C[j + 2]) * hf, C[j + 3] + (C[j + 1] - C[j + 3]) * hf, C[j + 2], C[j + 3]); ++nH; }
      } else {
         g.pen = this.pen(B.ck, B.lev, B.aa ? kk : kk * 0.7, B.aa);
         for (j = 0; j < C.length; j += 4) g.drawLine(C[j], C[j + 1], C[j + 2], C[j + 3]);
      }
   }
   this.stats.trails = nT; this.stats.heads = nH; this.stats.tubeKept = nTube;
   g.antialiasing = true;
   g.compositionOperator = keepOp;
};
// (N6) LA FASE DEL WARP vista por el pintor, solo con lo que graba REC (warp w, trail tr, flash):
//   preparacion  w = 0 y tr > 0           -> shake = tr / PREP_TRAIL (temblor) y rayas apenas
//   salto        tr sube antes que w      -> el temblor se apaga con (1 − w)
//   crucero      w = tr = 1               -> Doppler
//   salida       tr = w^1,6 ≤ w           -> sin temblor; las rayas se recogen
// -> { shake, doppler, max (composicion Max), w, tr }
// (E) aliento: w = 0 y tr = BREATH_TRAIL (> PREP_TRAIL) -> todo quieto, sin temblor · salto: tr > w con 0 < w < 1 -> ABERRACION (las
// estrellas se apelotonan hacia el punto de fuga, pico a mitad del salto)
FVPainter.prototype.warpFx = function(P) {
   var w = P.warp || 0, tr = P.trail || 0, WW = (typeof FV_PILOT !== "undefined" && FV_PILOT.WARP) ? FV_PILOT.WARP : { PREP_TRAIL: 0.14, ABERR: 0.3 }, pt = WW.PREP_TRAIL;
   var shake = (w < 0.001 && tr <= pt + 0.005) ? fvClamp(tr / pt, 0, 1) : 0;
   var aberr = (tr > w + 0.01 && w > 0) ? (WW.ABERR || 0) * 4 * w * (1 - w) : 0;
   return { w: w, tr: tr, shake: shake, aberr: aberr, doppler: FV_PAINT.WARP_DOPPLER * fvSmooth((tr - 0.5) / 0.4), max: tr > 0.05 };
};
// (N6) la clave de color con el tinte Doppler: banda 0 azul (hacia el punto de fuga), 1 sin tinte, 2 rojiza (bordes)
FVPainter.prototype.tintKey = function(ck, band) {
   if (band === 1) return ck;
   // (20-nov, W1b) con el warp del laboratorio (FV_W1.ON y DOP_ON) la mezcla del Doppler es DOP_A (0,55; la de W1 era 0,22: casi invisible); la tabla se rehace si cambia
   var a = FV_PAINT.WARP_DOPPLER; if (typeof FV_W1 !== "undefined" && FV_W1.ON && FV_W1.DOP_ON) a = FV_W1.DOP_A;
   if (this.tintKeys && this.tintA !== a) this.tintKeys = null;
   if (!this.tintKeys) {
      this.tintKeys = new Int16Array(216 * 3); this.tintA = a;
      var blue = [150, 190, 255], red = [255, 160, 120];
      for (var k = 0; k < 216; ++k) {
         var c = fvColOfKey(k), cb = [0, 0, 0], cr = [0, 0, 0];
         for (var q = 0; q < 3; ++q) { cb[q] = Math.round(c[q] + (blue[q] - c[q]) * a); cr[q] = Math.round(c[q] + (red[q] - c[q]) * a); }
         this.tintKeys[k * 3] = fvColKey((cb[0] << 16) | (cb[1] << 8) | cb[2]); this.tintKeys[k * 3 + 1] = k; this.tintKeys[k * 3 + 2] = fvColKey((cr[0] << 16) | (cr[1] << 8) | cr[2]);
      }
   }
   return this.tintKeys[ck * 3 + band];
};
// (N6) POLVO DE WARP (ESTETICO): WARP_DUST_N rayas en el espacio de la camara, en un tunel alrededor de la direccion de vuelo, que vienen
// del fondo y salen por los bordes (el «campo de estrellas» de TNG). Su avance se integra aqui con el reloj de escena (P.t) y w²: en vivo
// y en REC (que pinta los fotogramas en orden) da lo mismo. Solo con el warp (w > 0,02); intensidad ∝ trail.
FVPainter.prototype.paintWarpDust = function(g, pr, P) {
   var fx = this.warpFx(P), st = this.stats;
   st.dust = 0;
   var dtp = (this.wdT === undefined) ? 0 : (P.t || 0) - this.wdT;
   if (!(dtp >= 0 && dtp < 0.5)) dtp = 0;
   this.wdT = P.t || 0;
   if (!FV_PAINT.WARP_DUST_ON || fx.w < 0.02 || fx.tr < 0.05) return;
   this.wdPhase = (this.wdPhase || 0) + dtp * fx.w * fx.w * FV_PAINT.WARP_DUST_RATE;
   var N = FV_PAINT.WARP_DUST_N, i;
   if (!this.wd || this.wd.n !== N) {
      var rg = fvRng(4242), th = new Float64Array(N), rho = new Float64Array(N), ph = new Float64Array(N), band = new Uint8Array(N);
      for (i = 0; i < N; ++i) { th[i] = 2 * Math.PI * rg(); rho[i] = 0.18 + 1.3 * Math.sqrt(rg()); ph[i] = rg(); band[i] = Math.floor(rg() * 3); }
      this.wd = { n: N, th: th, rho: rho, ph: ph, band: band };
   }
   if (!this.wdPens) {
      this.wdPens = [];
      var cols = [[190, 215, 255], [235, 240, 255], [255, 236, 220]];         // azulada, blanca, calida
      for (var b = 0; b < 3; ++b) for (var lv = 0; lv < 4; ++lv) {
         var I = FV_PAINT.WARP_DUST_I * (lv + 1) / 4, c = cols[b];
         var pen = new Pen((0xff000000 | (Math.round(c[0] * I) << 16) | (Math.round(c[1] * I) << 8) | Math.round(c[2] * I)) >>> 0, lv >= 2 ? 1.4 : 1);
         this.wdPens.push(pen);
      }
   }
   var D = this.wd, zN = 0.12, zF = 4.0, sc = 0.5 * pr.H, cx = pr.cx, cy = pr.cy, W = pr.W, H = pr.H, dz = 0.55 * fx.tr, ph0 = this.wdPhase;
   var lines = [[], [], [], [], [], [], [], [], [], [], [], []];
   var dopD = (typeof FV_W1 !== "undefined" && FV_W1.ON && FV_W1.DOP_ON && fx.doppler > 0.01), hd2D = 0.25 * (W * W + H * H);   // (W1b)
   for (i = 0; i < N; ++i) {
      var fr = (D.ph[i] + ph0) % 1, z = zF - fr * (zF - zN), z2 = Math.min(zF + 0.5, z + dz);
      var ca = Math.cos(D.th[i]), sa = Math.sin(D.th[i]), R1 = sc * D.rho[i] / z, R2 = sc * D.rho[i] / z2;
      var x1 = cx + ca * R1, y1 = cy + sa * R1;
      if (x1 < -50 || y1 < -50 || x1 > W + 50 || y1 > H + 50) { if (cx + ca * R2 < 0 || cx + ca * R2 > W || cy + sa * R2 < 0 || cy + sa * R2 > H) continue; }
      var a = fvSmooth((zF - z) / 1.2) * fx.tr, lv2 = Math.min(3, Math.floor(a * 4 * Math.min(1, 0.6 + 0.8 / z)));
      if (lv2 < 0 || a < 0.05) continue;
      var bnd = D.band[i];
      if (dopD) { var rrD = ((x1 - pr.cx) * (x1 - pr.cx) + (y1 - pr.cy) * (y1 - pr.cy)) / hd2D; bnd = rrD < 0.09 ? 0 : (rrD > 0.42 ? 2 : 1); }   // (W1b, DOP_ON) el Doppler tambien en el polvo: azul hacia el punto de fuga, calido en los bordes (las mismas bandas que las estrellas, rr2 0,09 / 0,42)
      lines[bnd * 4 + lv2].push(cx + ca * R2, cy + sa * R2, x1, y1);
   }
   g.antialiasing = true;
   for (var q = 0; q < 12; ++q) {
      var Lq = lines[q]; if (!Lq.length) continue;
      g.pen = this.wdPens[q];
      for (var j = 0; j < Lq.length; j += 4) { g.drawLine(Lq[j], Lq[j + 1], Lq[j + 2], Lq[j + 3]); ++st.dust; }
   }
};
// (N6/§15) EL DESTELLO: sprite cuadrado de FLASH_SIZE × alto, en Add, en el punto de fuga: nucleo pequeño (FLASH_CORE de la media
// anchura), halo corto, espiga vertical (hasta el borde del sprite = 0,9 del alto) y horizontal a la mitad. Se hace una vez.
FVPainter.prototype.paintFlash = function(g, W, H, k) {
   // (20-nov, H6) como en la web (fw_viewer.js, fx.flashBall): el NUCLEO del destello solo se pinta con destello alto, k·suave((k − LO) / (HI − LO)). El brillo de la carga del warp (0,30) era un
   // disco gris plano en el centro de la pantalla; ahora no hay disco y el pulso del salto (1,0) queda igual. Las rayas siguen iluminandose con P.flash entero (STREAK_LIT). BALL_ON false = lo de antes
   if (typeof FV_W1 !== "undefined" && FV_W1.ON && FV_W1.BALL_ON) { k = k * fvSmooth((k - FV_W1.BALL_LO) / (FV_W1.BALL_HI - FV_W1.BALL_LO)); if (k < 0.002) return; }
   if (this.flashSpr && this.flashV2 !== !!FV_PAINT.FLASH_V2) this.flashSpr = null;
   if (!this.flashSpr && FV_PAINT.FLASH_V2) {
      // (B2, Nino: «el destello poco natural») UN PULSO DE LUZ SUAVE: tres gaussianas/exponenciales concentricas (nucleo, halo, resplandor),
      // azulado-blanco, sin espigas ni anillos ni bordes; el nucleo apenas pasa a blanco. La forma en el tiempo (subida rapida, bajada
      // exponencial) la da el piloto (FV_PILOT.WARP.FLASH_UP / FLASH_EXP). FLASH_V2 false = el de §15 con espigas (ROJO).
      var R2 = 200, sz2 = 2 * R2 + 1, b2 = new Bitmap(sz2, sz2, BitmapFormat.RGB32), px2 = new Uint32Array(b2.pixelData()).slice(), c2 = FV_PAINT.FLASH_RGB2, rc2 = FV_PAINT.FLASH_CORE;
      for (var y2 = 0; y2 < sz2; ++y2) for (var x2 = 0; x2 < sz2; ++x2) {
         var ddx = (x2 - R2) / R2, ddy = (y2 - R2) / R2, r2 = Math.sqrt(ddx * ddx + ddy * ddy);
         var v2 = 0.8 * Math.exp(-(r2 / rc2) * (r2 / rc2)) + 0.28 * Math.exp(-Math.pow(r2 / (3.5 * rc2), 2)) + 0.07 * Math.exp(-r2 / (9 * rc2));
         v2 *= fvSmooth((1 - r2) / 0.25);                                   // a 0 antes del borde del sprite: sin cuadrado visible
         var wv2 = Math.max(0, v2 - 0.75) * 0.6;
         px2[y2 * sz2 + x2] = (0xff000000 | (Math.min(255, Math.round(c2[0] * v2 + 255 * wv2)) << 16) | (Math.min(255, Math.round(c2[1] * v2 + 255 * wv2)) << 8) | Math.min(255, Math.round(c2[2] * v2 + 255 * wv2))) >>> 0;
      }
      new Uint32Array(b2.pixelData()).set(px2);
      this.flashSpr = b2; this.flashV2 = true;
   }
   if (!this.flashSpr) {
      this.flashV2 = false;
      var R = 200, sz = 2 * R + 1, b = new Bitmap(sz, sz, BitmapFormat.RGB32), px = new Uint32Array(b.pixelData()), c = FV_PAINT.FLASH_RGB, rc = FV_PAINT.FLASH_CORE, sk = FV_PAINT.FLASH_SPIKE;
      for (var y = 0; y < sz; ++y) for (var x = 0; x < sz; ++x) {
         var dx = (x - R) / R, dy = (y - R) / R, ax = Math.abs(dx), ay = Math.abs(dy), rr = Math.sqrt(dx * dx + dy * dy);
         var v = 1.0 * Math.exp(-(rr / rc) * (rr / rc)) + 0.22 * Math.exp(-rr / (2.2 * rc));
         v += sk * Math.exp(-(ax / 0.006) * (ax / 0.006)) * Math.pow(Math.max(0, 1 - ay), 2.2);              // espiga vertical
         v += 0.5 * sk * Math.exp(-(ay / 0.006) * (ay / 0.006)) * Math.pow(Math.max(0, 1 - 2 * ax), 2.5);     // horizontal, a la mitad
         var wv = Math.max(0, v - 0.7) * 0.9;      // el centro tira a blanco
         px[y * sz + x] = (0xff000000 | (Math.min(255, Math.round(c[0] * v + 255 * wv)) << 16) | (Math.min(255, Math.round(c[1] * v + 255 * wv)) << 8) | Math.min(255, Math.round(c[2] * v + 255 * wv))) >>> 0;
      }
      this.flashSpr = b;
   }
   var s = FV_PAINT.FLASH_SIZE * H * (0.85 + 0.15 * k), op = g.opacity, co = g.compositionOperator;
   g.compositionOperator = CompositionOp_Add; g.opacity = Math.min(1, k);
   g.drawScaledBitmap(W / 2 - s / 2, H / 2 - s / 2, W / 2 + s / 2, H / 2 + s / 2, this.flashSpr);
   g.opacity = 1; g.compositionOperator = CompositionOp_SourceOver;
   if (FV_PAINT.FLASH_WASH > 0) { var c2 = FV_PAINT.FLASH_RGB; g.fillRect(0, 0, W, H, new Brush(((Math.round(255 * FV_PAINT.FLASH_WASH * k) << 24) | (c2[0] << 16) | (c2[1] << 8) | c2[2]) >>> 0)); }
   g.opacity = op; g.compositionOperator = co;
};
// (B) BORDE SUAVE Y ONDULADO, comun a capas y foto: multiplica px (en su sitio) por f = smooth((d − wob) / E)², con d la distancia al
// borde (fraccion del lado mayor) y wob ∈ [0, A] una ondulacion a lo largo de ese borde (cuatro senos, fase ph). o.lum = [E debil,
// E brillante]: el ancho de la caida depende de la luz del pixel (lo debil se apaga antes y lejos del borde, lo brillante aguanta hasta
// cerca): el borde sigue el contorno de la nebulosa en vez de una linea. lRef = la luz de referencia (p99 de la capa).
function fvSoftEdgeApply(px, W, H, o) {
   var S = Math.max(W, H), A = o.A, x, y, nx = new Float32Array(W), ny = new Float32Array(H), ph = o.ph || 0;
   for (x = 0; x < W; ++x) { var a = x / S * 2 * Math.PI; nx[x] = 0.5 + 0.22 * Math.sin(2.1 * a + ph) + 0.14 * Math.sin(5.3 * a + 2 * ph) + 0.09 * Math.sin(11.7 * a + 3 * ph) + 0.05 * Math.sin(23.3 * a + 5 * ph); }
   for (y = 0; y < H; ++y) { var b = y / S * 2 * Math.PI; ny[y] = 0.5 + 0.22 * Math.sin(2.3 * b + 2.5 * ph) + 0.14 * Math.sin(4.9 * b + ph) + 0.09 * Math.sin(12.1 * b + 4 * ph) + 0.05 * Math.sin(22.7 * b + 6 * ph); }
   var LUT = new Float32Array(1025); for (var q = 0; q <= 1024; ++q) { var v = fvSmooth(q / 1024); LUT[q] = v * v; }
   var lum = o.lum, Emax = lum ? Math.max(lum[0], lum[1]) : o.E, lInv = (lum && o.lRef > 0) ? 1 / o.lRef : 0;
   // o.cont = { map (luz suavizada, Float32Array mw × mh), mw, mh, T (umbral junto al borde, × lRef), w (rampa, × lRef), hard (ultima franja) }:
   // junto al borde solo queda lo que supera un umbral que sube hacia el borde -> se apaga siguiendo las isofotas (el contorno de la
   // nebulosa), no una linea; la ultima franja `hard` remata a 0 lo poco que quede
   var C = o.cont; if (C) Emax = o.E;
   for (y = 0; y < H; ++y) {
      var wy = A * ny[y], row = y * W;
      for (x = 0; x < W; ++x) {
         var dx = Math.min(x, W - 1 - x) / S - wy, dy = Math.min(y, H - 1 - y) / S - A * nx[x], d = dx < dy ? dx : dy;
         if (d >= Emax) continue;
         var p = px[row + x], r = (p >>> 16) & 255, g = (p >>> 8) & 255, bl = p & 255, E = o.E;
         if (lum) { var l = (0.2126 * r + 0.7152 * g + 0.0722 * bl) * lInv; E = lum[0] + (lum[1] - lum[0]) * fvSmooth(l); if (d >= E) continue; }
         var f;
         if (C) {
            // bilineal (con el vecino mas cercano las isofotas salian a bloques de W/CONT_RES px: cortes rectos)
            var fx = fvClamp((x + 0.5) * C.mw / W - 0.5, 0, C.mw - 1.001), fy = fvClamp((y + 0.5) * C.mh / H - 0.5, 0, C.mh - 1.001), ix = Math.floor(fx), iy = Math.floor(fy), tx = fx - ix, ty = fy - iy, i0 = iy * C.mw + ix;
            var lb = (C.map[i0] * (1 - tx) + C.map[i0 + 1] * tx) * (1 - ty) + (C.map[i0 + C.mw] * (1 - tx) + C.map[i0 + C.mw + 1] * tx) * ty;
            var T = -C.w + (C.T + C.w) * (1 - fvSmooth(d / E)), u = fvClamp((lb - T) / C.w, 0, 1);
            f = d <= 0 ? 0 : fvSmooth(u) * fvSmooth(d / C.hard);
         } else f = d <= 0 ? 0 : LUT[Math.round(d / E * 1024)];
         px[row + x] = (0xff000000 | (Math.round(r * f) << 16) | (Math.round(g * f) << 8) | Math.round(bl * f)) >>> 0;
      }
   }
}
// las capas (ver FV_PAINT.EDGE_*). Los pixeles se copian (.slice()) y vuelven con .set().
FVPainter.prototype.softenLayers = function() {
   var mode = FV_PAINT.EDGE_MODE, E = FV_PAINT.EDGE_SOFT, A = FV_PAINT.EDGE_WOB;
   if (mode === "off" || (mode === "line" && !(E > 0))) return;
   // (19-nov, N2c; FV_N2C) el juego de capas con el pedestal de cielo quitado hacia el borde (antes del borde suave del pintor: cielo × (1 − rem) × f). Se hace con TODAS las capas a la vez (el pedestal esta repartido entre ellas)
   // y se guarda en bmps._fvN2c: las capas de siempre siguen igual (se usan mientras el borde de la foto no entra en pantalla)
   var nV = (typeof FV_N2C !== "undefined" && FV_N2C.ON && typeof fvN2cLayersApply === "function") ? [] : null, rawV = null;
   if (nV) {
      var ok0 = this.layers.length > 0, q0, w0 = 0, h0 = 0; rawV = [];
      for (q0 = 0; q0 < this.layers.length && ok0; ++q0) { var b0 = this.layers[q0]; if (!b0 || (q0 > 0 && (b0.width !== w0 || b0.height !== h0))) { ok0 = false; break; } w0 = b0.width; h0 = b0.height; rawV.push(new Uint32Array(b0.pixelData()).slice()); }
      var tN0 = Date.now();
      if (ok0) { this.n2cPed = fvN2cLayersApply(rawV, w0, h0, (typeof FV_BUILD !== "undefined" && FV_BUILD.EDGE > 0) ? FV_BUILD.EDGE : 0.18); this.bmpsRef._fvN2c = nV; this.n2cMs = Date.now() - tN0; } else { nV = null; rawV = null; }
   }
   for (var k = 0; k < this.layers.length; ++k) {
      var bm = this.layers[k];
      if (!bm) continue;
      var W = bm.width, H = bm.height, px = new Uint32Array(bm.pixelData()).slice(), o = { E: E, A: A, ph: 1.7 * k + 0.3 };
      if (mode === "contour") {
         // la luz de la capa, suavizada (reducida a CONT_RES px de ancho: la isofota sale redonda, sin el detalle fino)
         var mw = FV_PAINT.CONT_RES, mh = Math.max(2, Math.round(mw * H / W)), sm = new Uint32Array(bm.scaledTo(mw, mh).pixelData()).slice(), map = new Float32Array(mw * mh), sv = [];
         for (var j = 0; j < sm.length; ++j) { var pj = sm[j]; map[j] = 0.2126 * ((pj >>> 16) & 255) + 0.7152 * ((pj >>> 8) & 255) + 0.0722 * (pj & 255); sv.push(map[j]); }
         sv.sort(function(a, b) { return a - b; }); var lR2 = Math.max(4, sv[Math.floor(0.98 * (sv.length - 1))]);
         o.E = FV_PAINT.CONT[0]; o.A = FV_PAINT.CONT[1]; o.cont = { map: map, mw: mw, mh: mh, T: FV_PAINT.CONT[2] * lR2, w: FV_PAINT.CONT[3] * lR2, hard: FV_PAINT.CONT[4] };
      }
      if (mode === "lum") {
         var smp = []; for (var i = 0; i < px.length; i += 97) { var p = px[i]; smp.push(0.2126 * ((p >>> 16) & 255) + 0.7152 * ((p >>> 8) & 255) + 0.0722 * (p & 255)); }
         smp.sort(function(a, b) { return a - b; });
         o.lum = FV_PAINT.EDGE_LUM; o.A = FV_PAINT.EDGE_LUM_WOB; o.lRef = Math.max(8, smp[Math.floor(0.99 * (smp.length - 1))]);
      }
      if (nV) { var pxV = rawV[k]; fvSoftEdgeApply(pxV, W, H, o); var bV = new Bitmap(W, H, BitmapFormat.RGB32); new Uint32Array(bV.pixelData()).set(pxV); nV[k] = bV; rawV[k] = null; }
      fvSoftEdgeApply(px, W, H, o);
      new Uint32Array(bm.pixelData()).set(px);
   }
};
// (B) la MASCARA DEL BORDE DE LA FOTO (blanca dentro, caida ondulada en el borde), pequeña; se pinta en Multiply sobre la foto cuando su
// borde esta en pantalla (la revelacion): la foto se funde con el cielo en vez de ser un cromo de cantos rectos. En casa no se usa.
// (nP-2) la foto (capa 0 llevada a la distancia de la nebulosa, con la inclinacion) en pantalla: { q: 4 esquinas, kE } o null si alguna
// esquina queda detras. kE sube de 0 a 1 cuando un canto entra en el cuadro (rampa del 4 % del ancho); en casa 0
FVPainter.prototype.photoQuad = function(pr) {
   var N = this.scene.nebula; if (!N || !N.layers || !N.layers.length || !(N.distLy > 0)) return null;
   var L0 = N.layers[0], d0 = N.distLy, T = this.tiltOf();
   var Lp = { z: d0, x0: L0.x0 / L0.z * d0, y0: L0.y0 / L0.z * d0, x1: L0.x1 / L0.z * d0, y1: L0.y1 / L0.z * d0 };
   var cq = [[Lp.x0, Lp.y0], [Lp.x1, Lp.y0], [Lp.x1, Lp.y1], [Lp.x0, Lp.y1]], qs = [];
   for (var ci = 0; ci < 4; ++ci) { var q = pr.project(this.planePt(Lp, cq[ci][0], cq[ci][1], T)); if (!q) return null; qs.push(q); }
   var mL = -Math.max(qs[0][0], qs[3][0]), mR = Math.min(qs[1][0], qs[2][0]) - pr.W, mT = -Math.max(qs[0][1], qs[1][1]), mB = Math.min(qs[2][1], qs[3][1]) - pr.H;
   var mIn = -Math.min(mL, mR, mT, mB);
   return { q: qs, kE: fvSmooth(mIn / (0.04 * pr.W)), kS: fvSmooth(mIn / ((FV_PAINT.STAR_EDGE_RAMP || 0.04) * pr.W)), mIn: mIn };   // (N2c) mIn: lo que entra el canto que mas entra, px
};
// (20-nov-2026, O1) LA MINIATURA DE TU FOTO para el marcador del borde: la foto de trabajo (ya estirada, con sus estrellas) a su proporcion, con el lado mayor a 3 × FV_NMX.THUMB_W
// (el doble de lo que se ve a 1920 de ancho: nitida sin escalar hacia arriba). Se hace UNA vez al construir el pintor, nunca al pintar. null con FV_NMX.THUMB false o sin foto
FVPainter.prototype.nmThumbBuild = function() {
   this.nmThumb = null;
   if (typeof FV_NMX === "undefined" || FV_NMX.THUMB !== true) return null;
   var src = (this.bmpsRef && this.bmpsRef.photo) ? this.bmpsRef.photo : this.photoPlane;
   if (!src || !(src.width > 0) || !(src.height > 0)) return null;
   try {
      var Lm = Math.round(3 * FV_NMX.THUMB_W), asp = src.height / src.width, w = asp <= 1 ? Lm : Math.max(2, Math.round(Lm / asp)), h = asp <= 1 ? Math.max(2, Math.round(Lm * asp)) : Lm;
      var mid = (src.width > 3 * w) ? src.scaledTo(3 * w, Math.max(2, 3 * h)) : src;      // dos pasos: de una foto grande de un salto a 264 px el reescalado bilineal da dientes
      this.nmThumb = mid.scaledTo(w, h);
   } catch (e) { this.nmThumb = null; if (typeof fvLog === "function") fvLog("nmThumb: " + e); }
   return this.nmThumb;
};
FVPainter.prototype.photoEdgeMask = function() {
   if (this.photoMaskBmp) return this.photoMaskBmp;
   var pp = this.photoPlane, W = 512, H = Math.max(2, Math.round(512 * pp.height / pp.width)), b = new Bitmap(W, H, BitmapFormat.RGB32);
   b.fill(0xffffffff);
   var px = new Uint32Array(b.pixelData()).slice();
   fvSoftEdgeApply(px, W, H, { E: FV_PAINT.PHOTO_EDGE[0], A: FV_PAINT.PHOTO_EDGE[1], ph: 0.9 });
   new Uint32Array(b.pixelData()).set(px);
   this.photoMaskBmp = b;
   return b;
};
// la estrella i en pantalla: [sx, sy, mag aparente] o null
FVPainter.prototype.starScreen = function(P, i, W, H) {
   var pr = fvPaintRoll(fvProjector(P.cam, W, H), P.cam.roll), p = pr.project(fvStarPos(this.scene, i));
   if (!p) return null;
   var S = this.scene.stars, dc = fvLen(fvSub(fvStarPos(this.scene, i), P.cam.pos));
   return [p[0], p[1], fvApparentMag(S.g[i], S.dEarth[i], dc)];
};

// ---------------------------------------------------------------------------
// (F2) LA PROTAGONISTA: la estrella del viaje (a la que se va o a la que se llego; si no, la elegida) cuando brilla mas que magnitud 3,5.
// Nucleo blanco caliente con limbo oscurecido, corona y resplandor en SU color (el unico: el de la escena) y cuatro rayos finos.
// Es una RECREACION (a decenas de años luz ningun telescopio ve su disco: la ficha lo dice). -> { i, m, w } | null
// ---------------------------------------------------------------------------
FVPainter.prototype.heroOf = function(P) {
   var sel = (P.flight && P.flight.sel && P.flight.sel.kind === "star") ? P.flight.sel : ((P.arrivedAt && P.arrivedAt.kind === "star") ? P.arrivedAt : ((P.sel && P.sel.kind === "star") ? P.sel : null));
   if (!sel && P.lab) {   // (v2, LABORATORIO) un destino de MIRABILIA que es una estrella del campo tambien es la protagonista (con la lente fija de 50° se veia como un punto)
      var so = (P.flight && P.flight.sel) || P.arrivedAt || P.sel, Ob = so && so.kind === "object" && this.scene.objects ? this.scene.objects[so.i] : null;
      if (Ob && Ob.star >= 0) sel = { kind: "star", i: Ob.star, arriveLy: (typeof fvObjectTarget === "function" && fvObjectTarget(this.scene, so.i)) ? fvObjectTarget(this.scene, so.i).arriveLy : 0 };
   }
   if (!sel) return null;
   var S = this.scene.stars, i = sel.i, dc = fvLen(fvSub(fvStarPos(this.scene, i), P.cam.pos)), m = fvApparentMag(S.g[i], S.dEarth[i], dc);
   if (P.lab && typeof fvArriveDist === "function") {
      // (v2, LABORATORIO) el destino se anuncia antes de llegar: a 300 x la distancia de llegada empieza a crecer y llega entero (1,5 mag por
      // encima del umbral) a la distancia de llegada, aunque su brillo real sea menor (una enana roja a 1 a.l. es de magnitud 5: no se veia)
      var dA = fvArriveDist(P, sel), pr0 = fvClamp(Math.log(Math.max(dc, 1e-9) / Math.max(dA, 1e-9)) / Math.log(300), 0, 1);
      m = Math.min(m, FV_PAINT.HERO_MAG - 1.5 * (1 - pr0));
   }
   if (m >= FV_PAINT.HERO_MAG) return null;
   return { i: i, m: m, w: fvSmooth((FV_PAINT.HERO_MAG - m) / 1.5) };
};
FVPainter.prototype.heroSprite = function(i) { return this.heroSpriteCol(this.colSet().c[i] >>> 0); };
FVPainter.prototype.heroSpriteCol = function(col, soft) {
   // (11-nov) soft: la variante de la llegada (HERO_NEAR): halo que cae suave hasta el borde (al doble de tamaño el corte del 12 % se veia como un
   // disco gris con borde) y nucleo mas teñido de su color (una M salia blanca junto a su portilla naranja: revision visual del 11-nov)
   var key = String(col) + (soft ? "s" : "");
   if (this.hero[key]) return this.hero[key];
   var R = FV_PAINT.HERO_SPR, sz = 2 * R + 1, b = new Bitmap(sz, sz, BitmapFormat.RGB32), px = new Uint32Array(b.pixelData());
   var c = [((col >>> 16) & 255) / 255, ((col >>> 8) & 255) / 255, (col & 255) / 255], mc = Math.max(c[0], c[1], c[2], 1e-3), RC = 0.16 * R;
   c = [c[0] / mc, c[1] / mc, c[2] / mc];
   for (var y = 0; y < sz; ++y) for (var x = 0; x < sz; ++x) {
      var dx = x - R, dy = y - R, r = Math.sqrt(dx * dx + dy * dy), rho = r / RC, v = [0, 0, 0], q;
      if (rho < 1) {
         var mu = Math.sqrt(1 - rho * rho), I = 1 - 0.55 * (1 - mu);                       // limbo oscurecido (lineal, u = 0,55: estetico)
         for (q = 0; q < 3; ++q) v[q] = I * (soft ? (0.3 + 0.7 * c[q]) * 1.2 : (0.6 + 0.4 * c[q]) * 1.15);
      } else {
         var e1 = Math.exp(-(rho - 1) / 0.45), e2 = Math.exp(-(rho - 1) / 2.6);
         var ax = Math.abs(dx), ay = Math.abs(dy), fall = Math.max(0, 1 - r / R), sp = (Math.exp(-ay / 0.9) + Math.exp(-ax / 0.9)) * 0.55 * fall * fall;
         for (q = 0; q < 3; ++q) v[q] = (0.95 * e1 + 0.28 * e2) * c[q] + sp * (0.5 + 0.5 * c[q]);
      }
      var edge = fvSmooth((R - r) / ((soft ? 0.6 : 0.12) * R));
      px[y * sz + x] = (0xff000000 | (Math.min(255, Math.round(255 * v[0] * edge)) << 16) | (Math.min(255, Math.round(255 * v[1] * edge)) << 8) | Math.min(255, Math.round(255 * v[2] * edge))) >>> 0;
   }
   this.hero[key] = b;
   return b;
};
FVPainter.prototype.paintHero = function(g, pr, P, h) {
   var p = pr.project(fvStarPos(this.scene, h.i));
   if (!p) return;
   // (F4b) su color con el polvo que queda delante (al llegar, ya casi el verdadero)
   var hc = this.starColour(P, h.i); this.stats.heroCol = hc; this.stats.heroDustLeft = this.dustLeft(P, h.i);
   var rr = Math.min(FV_PAINT.HERO_MAX, FV_PAINT.HERO_R0 * Math.pow(2, 0.4 * (FV_PAINT.HERO_MAG - h.m))) * (0.35 + 0.65 * h.w), sp = this.heroSpriteCol(hc);
   // (11-nov, revision de la navegabilidad) LA LLEGADA: la protagonista CRECE en el ultimo tramo (desde HERO_NEAR.FROM veces la distancia de
   // llegada hasta ella) hasta HERO_NEAR.K veces su radio: se llega a un sol, no a un punto de 8 px de nucleo perdido entre las del fondo.
   // Es la misma RECREACION de siempre (la ficha lo dice), mas grande. HERO_NEAR.ON false = como antes
   var HN = FV_PAINT.HERO_NEAR;
   if (HN && HN.ON && HN.K > 1 && typeof fvArriveDist === "function") {
      var selH = (P.flight && P.flight.sel && P.flight.sel.kind === "star" && P.flight.sel.i === h.i) ? P.flight.sel : ((P.arrivedAt && P.arrivedAt.kind === "star" && P.arrivedAt.i === h.i) ? P.arrivedAt : { kind: "star", i: h.i });
      var dAh = fvArriveDist(P, selH), dch = fvLen(fvSub(fvStarPos(this.scene, h.i), P.cam.pos));
      var kN = fvSmooth(1 - Math.log(Math.max(dch, 1e-9) / Math.max(dAh, 1e-9)) / Math.log(HN.FROM));
      // sobre la foto no crece (o casi): un sol de 100 px encima de la nebulosa era un borron quemado (revision visual del 11-nov)
      var kPh = 0;
      if (typeof fvAmbInQuad === "function" && ((this.stats.nebOp || 0) > 0.01 || (this.stats.wPhoto || 0) > 0.02)) { var pqH = fvAmbPhotoPoly(this, pr); if (pqH) kPh = fvAmbInQuad(pqH, p[0], p[1], 0.05 * pr.W); }
      rr = Math.min(HN.MAX, rr * (1 + (HN.K - 1) * kN * (1 - HN.ON_PHOTO * kPh))); this.stats.heroNear = kN; this.stats.heroOnPhoto = kPh;
      if (kN > 0) sp = this.heroSpriteCol(hc, true);
   }
   var op = g.opacity; g.opacity = h.w;
   g.drawScaledBitmap(p[0] - rr, p[1] - rr, p[0] + rr, p[1] + rr, sp);
   g.opacity = op;
   this.stats.heroR = rr;
};

// ---------------------------------------------------------------------------
// (F4b) LA VIA LACTEA DE FONDO (SIMULADA: src/engine/fv_milkyway.js). Peso 0 en casa (la foto ya la trae), 1 al alejarse MW_AWAY × la
// distancia de la nebulosa. El mapa (l, b) se rehace al moverse mas de FV_MW.REMAP_LY; cada fotograma se muestrea en una rejilla de
// MW_GW × MW_GH direcciones de la pantalla y se escala (resplandor suave), y encima el grano de estrellas no resueltas.
// ---------------------------------------------------------------------------
FVPainter.prototype.mwWeight = function(P) {
   var dRef = this.scene.nebula ? this.scene.nebula.distLy : 1000;
   return fvSmooth(fvLen(P.cam.pos) / (FV_PAINT.MW_AWAY * dRef));
};
FVPainter.prototype.paintMilkyWay = function(g, pr, P) {
   if (typeof FV_MW2 !== "undefined" && FV_MW2.ON && this.paintMilkyWay2) return this.paintMilkyWay2(g, pr, P);   // (encargo D2, 9-nov) src/ui/fv_galaxy.js
   var w = this.mwWeight(P) * ((typeof fvN4bMwK === "function") ? fvN4bMwK(this.scene, P.cam.pos) : 1), Fr = this.scene.galaxy;   // (19-nov, N4b) ver paintMilkyWay2
   this.stats.mwW = w; this.stats.mwMean = 0; this.stats.mwGrain = 0;
   if (w < 0.01) return;
   if (!this.mwRef) { var m0 = fvMwMap(Fr, [0, 0, 0]); this.mwRef = fvMwRef(m0); this.mwGrain = fvMwGrain(m0, Fr, FV_PAINT.MW_GRAIN, 9091); this.mw = m0; }
   // se rehace al moverse mas de REMAP_LY o del 20 % de la distancia a casa (el cielo cambia despacio con la distancia), y no a toda
   // velocidad (con las estelas no se ve y cada mapa cuesta 30–90 ms)
   var mv = fvLen(fvSub(P.cam.pos, this.mw.camLy));
   if (mv > Math.max(FV_MW.REMAP_LY, 0.2 * fvLen(P.cam.pos)) && P.warp < 0.3) { var tq = fvNowMs(); this.mw = fvMwMap(Fr, P.cam.pos); this.stats.mwRemapMs = fvNowMs() - tq; ++this.stats.mwRemaps; }
   var GW = FV_PAINT.MW_GW, GH = FV_PAINT.MW_GH;
   if (!this.mwSmall) this.mwSmall = new Bitmap(GW, GH, BitmapFormat.RGB32);
   var px = new Uint32Array(this.mwSmall.pixelData()), r = pr.r, d = pr.d, fw = pr.fw, f = pr.f, sx = pr.W / GW, sy = pr.H / GH, ref = this.mwRef;
   var cD = FV_MW.COL_DISC, cB = FV_MW.COL_BULGE, k = FV_PAINT.MW_PEAK * w, ga = FV_PAINT.MW_GAMMA, dir = [0, 0, 0], sum = 0, mwS = pr.S || 1;
   for (var y = 0; y < GH; ++y) {
      var vy = ((y + 0.5) * sy - pr.cy) / f;
      for (var x = 0; x < GW; ++x) {
         var vx = ((x + 0.5) * sx - pr.cx) / f;
         dir[0] = fw[0] + vx * r[0] + vy * d[0]; dir[1] = fw[1] + vx * r[1] + vy * d[1]; dir[2] = fw[2] + vx * r[2] + vy * d[2];
         if (mwS !== 1) { dir[0] /= mwS; dir[1] /= mwS; }                 // (LABORATORIO) del rayo en vuelo a la direccion real del cielo
         var nn = 1 / Math.sqrt(dir[0] * dir[0] + dir[1] * dir[1] + dir[2] * dir[2]); dir[0] *= nn; dir[1] *= nn; dir[2] *= nn;
         var smp = fvMwSample(this.mw, Fr, dir), v = k * Math.pow(Math.min(1.6, smp[0] / ref), ga), b = smp[1];
         var R = Math.min(255, Math.round(v * (cD[0] + (cB[0] - cD[0]) * b))), G = Math.min(255, Math.round(v * (cD[1] + (cB[1] - cD[1]) * b))), B = Math.min(255, Math.round(v * (cD[2] + (cB[2] - cD[2]) * b)));
         px[y * GW + x] = (0xff000000 | (R << 16) | (G << 8) | B) >>> 0; sum += v;
      }
   }
   this.stats.mwMean = sum / (GW * GH);
   var op = g.compositionOperator, sm = g.smoothInterpolation;
   g.compositionOperator = CompositionOp_Add; g.smoothInterpolation = true;
   g.drawScaledBitmap(0, 0, pr.W, pr.H, this.mwSmall);
   g.smoothInterpolation = sm;
   // el grano: 4 sprites de 3×3 (blanco calido) de intensidad creciente
   if (!this.mwSpr) {
      this.mwSpr = [];
      for (var lv = 0; lv < 4; ++lv) {
         var I = [0.16, 0.28, 0.45, 0.7][lv], bm = new Bitmap(3, 3, BitmapFormat.RGB32), q = new Uint32Array(bm.pixelData());
         for (var j = 0; j < 9; ++j) { var dd = (j === 4) ? 1 : ((j % 2) ? 0.35 : 0.15), c = Math.round(255 * I * dd); q[j] = (0xff000000 | (c << 16) | (Math.round(c * 0.95) << 8) | Math.round(c * 0.86)) >>> 0; }
         this.mwSpr.push(bm);
      }
   }
   var Gn = this.mwGrain, gd = Gn.d, nG = 0;
   for (var n = 0; n < Gn.n; ++n) {
      var ax = gd[3 * n], ay = gd[3 * n + 1], az = gd[3 * n + 2];
      if (mwS !== 1) { ax *= mwS; ay *= mwS; var nG2 = 1 / Math.sqrt(ax * ax + ay * ay + az * az); ax *= nG2; ay *= nG2; az *= nG2; }   // (LABORATORIO)
      var zc = ax * fw[0] + ay * fw[1] + az * fw[2];
      if (zc < 0.05) continue;
      var X = pr.cx + f * (ax * r[0] + ay * r[1] + az * r[2]) / zc, Y = pr.cy + f * (ax * d[0] + ay * d[1] + az * d[2]) / zc;
      if (X < 1 || Y < 1 || X > pr.W - 2 || Y > pr.H - 2) continue;
      var lev = Math.floor(Gn.w[n] * w * 4.2); if (lev > 3) lev = 3;
      g.drawBitmap(Math.round(X) - 1, Math.round(Y) - 1, this.mwSpr[lev]); ++nG;
   }
   this.stats.mwGrain = nG;
   g.compositionOperator = op;
};
