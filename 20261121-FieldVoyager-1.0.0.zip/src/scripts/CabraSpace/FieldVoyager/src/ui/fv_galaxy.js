// ============================================================================
// FieldVoyager/src/ui/fv_galaxy.js — EL BOTON GALAXIA y LA VIA LACTEA DE FONDO NUEVA en el pintor (encargo D, 9-nov-2026)
// ----------------------------------------------------------------------------
// Nino (9-nov): «Añade un boton Galaxy a la izquierda de la imagen que haga zoom out y que se vea donde esta el campo en la via lactea.»
//               «Dibuja la Via Lactea con mayor prominencia y detalle en la navegacion explorando la imagen.»
// D1 · GALAXIA (bandera FV_GAL.ON; false = sin boton, la ventana de antes). Pulsar = la camara se aleja (DUR s, suave: la distancia crece
//      en progresion geometrica) desde la vista de la nave hasta ver la Via Lactea desde fuera, casi de cara y algo oblicua, con el Sol,
//      la linea de vision y el cono de la foto hasta la nebulosa, una marca en el campo con su nombre y su distancia, y los brazos rotulados.
//      La foto de la nave se queda pegada en su sitio (el plano de la nebulosa) y se encoge hasta ser la marca. Otro clic (boton o
//      pantalla) o Esc = la vuelta por el mismo camino, a donde estabas (la nave no se mueve: es solo la vista).
//      La galaxia es la de src/engine/fv_galaxy3d.js (Reid et al. 2019 + barra; procedimental, sin imagenes de terceros).
// D2 · FVPainter.paintMilkyWay2: la Via Lactea de fondo nueva (FV_MW2 de fv_milkyway.js). Peso 0 en casa como siempre: en casa NO pinta
//      nada (el fotograma es el de antes, bit a bit) pero va adelantando por trozos el mapa de cara y el mapa del cielo desde el Sol, para
//      que al salir no haya tiron.
// Ganchos de una linea en fv_painter.js (paintMilkyWay), fv_dialog.js (reloj, pintado, teclado, raton, boton) y fv_buttons.js (icono).
// ES5.
// ============================================================================

var FV_GAL = { ON: true, DUR: 3.2, DUR_BACK: 2.4, SCALE: 0.5,     // duraciones (s) y resolucion de la galaxia durante el zoom (la final, entera)
               TILT: 34, AZ: -18, DIST: 40, HFOV: 54, TX: 0.40,   // la vista final (fvGal3FinalCam)
               // (encargo GF) la misma con FV_GAL_GG.ON: de cara, los brazos del modelo ajustado (hasta 19,5 kpc) tocaban el borde superior (medido: 77 px fuera
               // a 40 kpc y tx 0,40, en 1271 × 930); a 45 kpc y con el objetivo mas hacia el lado de los brazos que sobran quedan 65 px de margen arriba y 150 abajo
               GG_VIEW: { dist: 45, tx: 0.85 },
               // (ronda 2) D-11: sin fotogramas casi negros. El cielo de dentro se EXPONE a medida que el campo se abre (fvGalSky: suelo al
               // percentil SKY_PLO de lo visto, el percentil SKY_PHI a SKY_XHI, ganancia ≤ SKY_GMAX) y el relevo cielo -> galaxia SE SOLAPA
               // (la galaxia entra en G0…G0+G1 kpc recorridos; el cielo se va en S0…S0+S1 kpc)
               SKY_PLO: 0.30, SKY_PHI: 0.98, SKY_XHI: 0.45, SKY_GMAX: 20, G0: 0.0, G1: 0.5, S0: 0.9, S1: 2.6,
               // la camara se aleja antes (escala inicial de la progresion geometrica D0 kpc; antes 0,02) y la galaxia vista de cerca se expone
               // mas (×(1 + EN) junto al Sol, ×1 a EN_R kpc: como el ojo que se adapta; el disco junto al Sol es mucho mas tenue que el centro).
               // Un campo lejos del plano (|b| -> 25°) baja antes la mirada: la vuelta empieza en LW_OFF[0] y dura LW_OFF[1] (en s)
               D0: 0.15, EN: 1.0, EN_R: 8, LW_OFF: [0.32, 0.55],
               // y un campo lejos del plano (peso 0 si |b| < LP_B0, 1 si |b| > LP_B0 + LP_B1) primero baja la mirada al plano en s ∈ [0, LP_S]
               // (bajada en s ∈ [LP_S0, LP_S0 + LP_S]; el campo se abre en WFS_OFF en vez de 0,45). Mientras baja, la foto NO se sale del cuadro:
               // se queda pegada al borde mientras se encoge (PIN_FADE: fraccion del ancho que «deberia» haberse ido para apagarse; 50 = solo la apaga su tamaño)
               LP_B0: 12, LP_B1: 16, LP_S0: 0.03, LP_S: 0.15, WFS_OFF: 0.22, PIN_FADE: 50,
               // D-1: la vista final (fija) se calcula a trozos durante la ida: PRE_MS por fotograma (PRE_MS0 mientras la galaxia aun no se ve)
               PRE: true, PRE_MS: 5, PRE_MS0: 14,
               // D-10: si lo principal de la foto es una galaxia de fuera, el cono llega al borde de la Via Lactea (R > EDGE_R o |Z| > EDGE_Z, kpc;
               // ELECCION NUESTRA: el radio donde se apagan los brazos y ~ la altura de escala del disco grueso, 0,9 kpc)
               EDGE_R: 15.5, EDGE_Z: 1.0,
               MAIN_FRAC: 0.05 };                                  // una galaxia es «la foto» si mide al menos este tanto del lado menor del campo

// ---------------------------------------------------------------------------
// el ICONO: una espiral de dos brazos vista algo oblicua, a buril fino como los demas (mismos trazos de fvEngrave)
// ---------------------------------------------------------------------------
function fvGalEngrave(g, cx, cy, u, stroke, hair, dot, ellipse) {
   var rot = -24 * Math.PI / 180, cr = Math.cos(rot), sr = Math.sin(rot), q = 0.60;
   function P(x, y) { var yy = y * q; return new Point(cx + (x * cr - yy * sr) * u, cy + (x * sr + yy * cr) * u); }
   function arm(ph, th0, th1, a, b, o) {
      var pts = [], n = 30;
      for (var k = 0; k <= n; ++k) { var th = th0 + (th1 - th0) * k / n, r = a * Math.exp(b * th), p = P(r * Math.cos(th + ph), r * Math.sin(th + ph)); pts.push(new Point(p.x + o, p.y + o)); }
      g.drawPolyline(pts);
   }
   stroke(function(o) { arm(0, 0.15, 1.8 * Math.PI, 3.1, 0.27, o); arm(Math.PI, 0.15, 1.8 * Math.PI, 3.1, 0.27, o); });
   hair(function() {
      arm(0.5 * Math.PI, 0.5, 1.45 * Math.PI, 3.1, 0.27, 0); arm(1.5 * Math.PI, 0.5, 1.45 * Math.PI, 3.1, 0.27, 0);
      var c0 = P(0, 0); g.drawEllipse(c0.x - 5.2 * u, c0.y - 3.6 * u, c0.x + 5.2 * u, c0.y + 3.6 * u);
   });
   dot(0, 0, 2.3);
   var S = [[-13.5, -9], [12.5, -11.5], [14, 9.5], [-12, 11]];
   for (var i = 0; i < S.length; ++i) dot(S[i][0], S[i][1], 0.55);
}

// ---------------------------------------------------------------------------
// el estado: D.gal = { t (0…1), dir (+1 ida, −1 vuelta), c0, c1 (camaras), look0, snap (la foto limpia), corners, field, ... }
// ---------------------------------------------------------------------------
// (10-nov-2026) la raiz del script (de #__FILE__, como FV_BOOT_SHIP_ROOT: sin rutas fijas) y el extracto de trazadores que va con el paquete:
// la galaxia nueva (encendida por defecto) lo lee de aqui; si falta, fvGalDefaultsGuard (fv_galdata.js) la devuelve a HOY
var FV_GAL_DATA_ROOT = (function() { try { return (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/").replace(/\/src\/ui\/?$/, ""); } catch (e) { return ""; } })();
if (!FV_GAL_DATA.SRC && FV_GAL_DATA_ROOT) FV_GAL_DATA.SRC = FV_GAL_DATA_ROOT + "/rsc/galaxia/gg_tracers.csv";
function fvGalStart(D) {
   if (!FV_GAL.ON || !D || !D.P || !D.scene || !D.scene.galaxy || !D.painter) return false;
   if (D.P.flight) return false;
   if (D.route && D.route.big && typeof D.route.close === "function") D.route.close();
   D.tour = null;
   var P = D.P, VW = D.VW, VH = D.VH, Fr = D.scene.galaxy, t0 = fvNowMs();
   fvGal3Tex();                                                         // si el pintor no lo adelanto en casa (FV_MW2 apagada), aqui
   FV_GAL3_MIX = (typeof FV_GAL_DATA !== "undefined" && FV_GAL_DATA.ON && fvGalDataEnsure(0)) ? fvGalDataTex() : null;   // (encargo GP) la galaxia de datos
   if (FV_GAL3_MIX && typeof fvGf11Get === "function") fvGf11Get(FV_GAL3_MIX);   // (GF11) las estrellas, una vez por mapa (apagado: null, nada)
   fvMw2Prep(D.painter, Fr, true);                                      // el cielo desde el Sol (el fondo del primer tramo del zoom)
   var snap = new Bitmap(VW, VH, BitmapFormat.RGB32);
   D.painter.render(snap, P, { hud: false, frame: false, vignette: true, ui: D.ui });
   var pr = fvPaintRoll(fvProjector(P.cam, VW, VH), P.cam.roll);
   var c0 = { pos: fvGal3Pt(Fr, P.cam.pos), fw: fvGal3Norm(fvGal3Vec(Fr, pr.fw)), r: fvGal3Norm(fvGal3Vec(Fr, pr.r)), d: fvGal3Norm(fvGal3Vec(Fr, pr.d)), f: pr.f, cx: pr.cx, cy: pr.cy };
   var N = D.scene.nebula, dLy = N ? N.distLy : 2000, fp = fvGal3Pt(Fr, [0, 0, dLy]);
   var dv = [fp[0] - c0.pos[0], fp[1] - c0.pos[1], fp[2] - c0.pos[2]], dph = Math.max(0.05, Math.sqrt(dv[0] * dv[0] + dv[1] * dv[1] + dv[2] * dv[2]));
   var look0 = [c0.pos[0] + c0.fw[0] * Math.max(0.3, dph), c0.pos[1] + c0.fw[1] * Math.max(0.3, dph), c0.pos[2] + c0.fw[2] * Math.max(0.3, dph)];
   var tx = c0.cx / c0.f, ty = c0.cy / c0.f, corners = [];
   [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(function(s) { corners.push([c0.pos[0] + dph * (c0.fw[0] + s[0] * tx * c0.r[0] + s[1] * ty * c0.d[0]), c0.pos[1] + dph * (c0.fw[1] + s[0] * tx * c0.r[1] + s[1] * ty * c0.d[1]), c0.pos[2] + dph * (c0.fw[2] + s[0] * tx * c0.r[2] + s[1] * ty * c0.d[2])]); });
   // el cono de la foto desde la Tierra hasta la nebulosa (la vista de casa)
   var hf = (P.homeFov || P.cam.fov), htx = Math.tan(hf / 2), hty = htx * VH / VW, HB = fvBasis([0, 0, 1], [0, 1, 0]), cone = [];
   [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(function(s) { cone.push(fvGal3Pt(Fr, [dLy * (HB.f[0] + s[0] * htx * HB.r[0] + s[1] * hty * HB.d[0]), dLy * (HB.f[1] + s[0] * htx * HB.r[1] + s[1] * hty * HB.d[1]), dLy * (HB.f[2] + s[0] * htx * HB.r[2] + s[1] * hty * HB.d[2])])); });
   var gv = (typeof fvGgOn === "function" && fvGgOn()) ? FV_GAL.GG_VIEW : null;      // (encargo GF) con la geometria ajustada, el disco llega a 19,5 kpc: otro encuadre inicial (el de hoy, sin banderas, no cambia)
   var c1 = fvGal3FinalCam(VW, VH, { tilt: FV_GAL.TILT, az: FV_GAL.AZ, dist: gv ? gv.dist : FV_GAL.DIST, hfov: FV_GAL.HFOV, tx: gv ? gv.tx : FV_GAL.TX });
   var lz = fvGal3Vec(Fr, [0, 0, 1]), l = Math.atan2(lz[1], lz[0]) * 180 / Math.PI; if (l < 0) l += 360;
   var wq = fvGal3Smooth((Math.abs(Math.asin(lz[2]) * 180 / Math.PI) - 8) / 17);
   c1.d0 = FV_GAL.D0; c1.lw0 = 0.32 + (FV_GAL.LW_OFF[0] - 0.32) * wq; c1.lw1 = 0.55 + (FV_GAL.LW_OFF[1] - 0.55) * wq;
   // la bajada de la mirada al plano (fvGal3CamAt): el punto del plano en el azimut del campo, a la misma distancia horizontal
   c1.lookP = [look0[0], look0[1], -FV_GAL3.ZSUN]; c1.lpW = fvGal3Smooth((Math.abs(Math.asin(lz[2]) * 180 / Math.PI) - FV_GAL.LP_B0) / FV_GAL.LP_B1); c1.lpS = FV_GAL.LP_S; c1.lpS0 = FV_GAL.LP_S0; c1.wfS = 0.45 + (FV_GAL.WFS_OFF - 0.45) * c1.lpW;
   // (ronda 2, D-10) EL ROTULO DEL CAMPO = el objeto principal de la FOTO: la nebulosa medida si la hay (IC 1848); si no (la «nebulosidad de
   // fondo» supuesta), la galaxia de fuera mas puntuada (M 82, IC 342) o el objeto mas puntuado con distancia (un cumulo…)
   var LG = FV_LANG === "es" ? "es" : "en", objs = D.scene.objects || [], nebReal = !!(N && N.id);
   function nm(o) { return (o.names && o.names[LG]) || o.name || o.id; }
   // la galaxia de fuera PRINCIPAL = la de mayor tamaño aparente (catalogo o medido), luego la mas brillante: en Caldwell 5 la de mas puntos era
   // LEDA 166861, una galaxia de fondo; la de la foto es IC 342
   function gsz(o) { return Math.max(o.sizeCatArcmin || 0, o.sizeArcmin || 0); }
   var ext = objs.filter(function(o) { return o.type === "galaxy" && o.distLy > 1e5; }).sort(function(a, b) { return (gsz(b) - gsz(a)) || ((a.mag === null || a.mag === undefined ? 99 : a.mag) - (b.mag === null || b.mag === undefined ? 99 : b.mag)) || ((b.score || 0) - (a.score || 0)); })[0] || null;
   // una galaxia de fondo de 2′ no es «la foto»: lo es si ocupa al menos MAIN_FRAC del lado menor del campo, o si es la que la construccion dejo
   // fuera por GRANDE (scene.photoGalaxy, fv_build.js: IC 342 en Caldwell 5), que tiene preferencia
   var fld = D.scene.field, fMin = fld && fld.scaleArcsec ? Math.min(fld.width, fld.height) * fld.scaleArcsec / 60 : 0, isBg = function(o) { return fMin > 0 && gsz(o) < FV_GAL.MAIN_FRAC * fMin; };
   var PG = D.scene.photoGalaxy;
   if (PG && PG.distLy > 1e5) ext = { name: PG.name, distLy: PG.distLy, distSrc: PG.distSrc, pos: [0, 0, 1], photo: true };
   var extMain = ext && (ext.photo || !isBg(ext)) ? ext : null;
   var title, sub = "", distTxt, extTxt = "", outside = null, exitP = null;
   if (nebReal) {
      title = (N.names && N.names[LG]) || N.name || N.id;
      distTxt = fvNavDistText(dLy, N.measured ? "measured" : "assumed", FV_LANG);
      // y si en la foto hay ademas una galaxia de fuera, una tercera linea: esta mucho mas lejos, en la misma direccion
      if (ext) extTxt = nm(ext) + " · " + fvGalDistShort(ext.distLy, ext.distSrc) + " " + fvTx("gal.beyond");
   } else if (extMain) {
      ext = extMain;
      // la galaxia de fuera ES la foto: el cono sale del disco por su direccion y una flecha sigue «→ M 82 · 12 Mly (fuera de la Via Lactea)»
      title = nm(ext) + " · " + fvGalDistShort(ext.distLy, ext.distSrc);     // la flecha es la dibujada (una «→» escrita apuntaria a otro lado)
      distTxt = fvTx("gal.outside");
      var ed = fvGal3Norm(fvGal3Pt(Fr, ext.pos && fvLen(ext.pos) > 0 ? ext.pos : [0, 0, 1])), se = fvGalEdge(ed);
      exitP = [ed[0] * se, ed[1] * se, ed[2] * se]; outside = { dir: ed, s: se };
   } else {
      var top = objs.filter(function(o) { return !o.main && o.type !== "star" && o.distLy > 0 && !(o.type === "galaxy" && isBg(o)); }).sort(function(a, b) { return (b.score || 0) - (a.score || 0); })[0];
      if (top) { title = nm(top); fp = fvGal3Pt(Fr, top.pos); dLy = top.distLy; distTxt = fvNavDistText(dLy, top.distSrc === "measured" ? "measured" : "assumed", FV_LANG); }
      else { title = fvTx("gal.field"); distTxt = fvNavDistText(dLy, "assumed", FV_LANG); }
   }
   if (exitP) {          // el cono y la marca, hasta el borde
      var kk = outside.s / Math.max(1e-6, fvLen(fp)); cone = cone.map(function(p) { return [p[0] * kk, p[1] * kk, p[2] * kk]; }); fp = exitP;
   }
   var Gn = D.painter.mw2Grain, gg = new Float32Array(3 * Gn.n);
   for (var n = 0; n < Gn.n; ++n) { var gv = fvGal3Vec(Fr, [Gn.d[3 * n], Gn.d[3 * n + 1], Gn.d[3 * n + 2]]); gg[3 * n] = gv[0]; gg[3 * n + 1] = gv[1]; gg[3 * n + 2] = gv[2]; }
   D.gal = { t: 0, dir: 1, dur: FV_GAL.DUR, c0: c0, c1: c1, look0: look0, snap: snap, corners: corners, cone: cone, field: fp, ext: extTxt, name: title, sub: sub, grain: gg,
             outside: outside, distTxt: distTxt,
             // el cielo del primer tramo: desde casa, el mapa de casa (al volver de lejos, el del pintor puede seguir siendo el de alli)
             skyMap: (fvLen(P.cam.pos) < FV_MW.REMAP_LY && D.painter.mw2Home) ? D.painter.mw2Home : D.painter.mw2, skyRef: (fvLen(P.cam.pos) < FV_MW.REMAP_LY && D.painter.mw2Home) ? D.painter.mw2HomeRef : D.painter.mw2Ref, buf: null, bmp: null, hold: null, pre: null, preMs: 0,
             info: { l: Math.round(l * 10) / 10, b: Math.round(Math.asin(lz[2]) * 1800 / Math.PI) / 10, kpc: Math.round(dLy / (1000 * FV_LY_PER_PC) * 100) / 100, startMs: Math.round(fvNowMs() - t0) } };
   fvLog("galaxy view: field at l " + D.gal.info.l + "°, b " + D.gal.info.b + "°, " + D.gal.info.kpc + " kpc (" + D.gal.info.startMs + " ms to start)");
   return true;
}
function fvGalStep(D, dt) {
   var G = D.gal; if (!G) return;
   if (G.orb) fvGalOrbStep(D, dt);                                    // (ronda 2b) girar la galaxia
   G.t += G.dir * dt / (G.dir > 0 ? FV_GAL.DUR : FV_GAL.DUR_BACK);
   if (G.t >= 1) G.t = 1;
   if (G.t <= 0) { G.t = 0; if (G.dir < 0) D.gal = null; }
}
function fvGalToggle(D) {
   if (!D.gal) return fvGalStart(D);
   // (ronda 2b) girada: primero a la vista de partida (fvGalOrbStep) y desde alli el zoom de vuelta de siempre
   if (D.gal.orb && D.gal.dir > 0 && fvGalOrbAway(D.gal.orb)) { D.gal.orb.goHome = true; D.gal.orb.drag = null; return true; }
   D.gal.dir = -D.gal.dir;          // (ronda 2) la vista final se guarda: es la misma a la vuelta y en la siguiente ida
   return true;
}
function fvGalEnd(D) { D.gal = null; }
// con la vista de la galaxia, el teclado es suyo: Esc vuelve; lo demas se come (no mueve la nave escondida)
function fvGalKey(D, k) { if (!D.gal) return false; if (k === Key_Escape && D.gal.dir > 0) fvGalToggle(D); return true; }

// la afin que lleva el rectangulo W × H a un paralelogramo (Cabra3D/src/ui/starfield_view.js cpSvAffineQr, copiada: «rotateTransformation
// de PJSR gira al reves: se le pasa −rot», medido alli)
function fvGalAffine(a, b, c, d) {
   var sx = Math.sqrt(a * a + b * b); if (!(sx > 1e-9)) return null;
   var ct = a / sx, st = b / sx, r0 = ct * c + st * d, sy = -st * c + ct * d;
   if (!(Math.abs(sy) > 1e-9)) return null;
   return { rot: Math.atan2(b, a), shear: r0 / sy, sx: sx, sy: sy };
}
// distancia corta para los rotulos: «12 Mly» / «12 M a.l.» por encima del millon; si no, la de siempre
function fvGalDistShort(ly, src) {
   if (!(ly >= 1e6)) return fvNavDistText(ly, src === "measured" ? "measured" : "assumed", FV_LANG);
   return (src === "measured" ? "" : "~") + fvsFmtSig(ly / 1e6, 2, FV_LANG) + " " + fvTx("gal.mly");
}
// recorrido (kpc) desde el Sol por la direccion u (galacticas) hasta salir del disco: R > EDGE_R o |Z| > EDGE_Z
function fvGalEdge(u) {
   var R0 = FV_GAL3.R0, zs = FV_GAL3.ZSUN;
   for (var s = 0.05; s < 30; s += 0.05) { var X = u[0] * s - R0, Y = u[1] * s, Z = u[2] * s + zs; if (X * X + Y * Y > FV_GAL.EDGE_R * FV_GAL.EDGE_R || Math.abs(Z) > FV_GAL.EDGE_Z) return s; }
   return 30;
}
function fvGalArgb(a, rgb) { return ((Math.max(0, Math.min(255, Math.round(255 * a))) << 24) | (rgb & 0xffffff)) >>> 0; }

// ---------------------------------------------------------------------------
// EL FOTOGRAMA de la vista de la galaxia (sustituye al del pintor mientras D.gal existe) -> { ms }
// ---------------------------------------------------------------------------
function fvGalRender(D) {
   var G = D.gal, t0 = fvNowMs(), W = D.VW, H = D.VH, s = fvSmoother(G.t), FG = FV_GAL;
   if (G.orb && G.t >= 1 && G.dir > 0 && fvGalOrbAway(G.orb)) return fvGalOrbRender(D);     // (ronda 2b) girada en 3D
   var cam = fvGal3CamAt(G.c0, G.c1, G.look0, s), tr = cam.travelled;
   // (ronda 2, D-11) relevo SOLAPADO: la galaxia entra antes de que el cielo se vaya (nunca los dos a medias a la vez)
   var aG = fvGal3Smooth((tr - FG.G0) / FG.G1), aS = 1 - fvGal3Smooth((tr - FG.S0) / FG.S1);
   var hold = (G.t >= 1 && G.dir > 0), bmp = null;
   // D-1: la vista final se va calculando a trozos (en el ultimo fotograma, lo que falte de golpe)
   if (FG.PRE && G.dir > 0 && !G.hold) { var tp = fvNowMs(); fvGalPre(D, hold ? 0 : (aG > 0.01 ? FG.PRE_MS : FG.PRE_MS0)); G.preMs += fvNowMs() - tp; }
   if (aG > 0.002) {
      if (hold && G.hold) bmp = G.hold;
      else {
         var sc = hold ? 1 : FG.SCALE, gw = Math.max(16, Math.round(W * sc)), gh = Math.max(16, Math.round(H * sc));
         if (!G.bmp || G.bmp.width !== gw || G.bmp.height !== gh) { G.bmp = new Bitmap(gw, gh, BitmapFormat.RGB32); G.buf = new Float32Array(3 * gw * gh); }
         var cs = { pos: cam.pos, fw: cam.fw, r: cam.r, d: cam.d, f: cam.f * gw / W, cx: cam.cx * gw / W, cy: cam.cy * gh / H };
         fvGal3Render(cs, gw, gh, G.buf, aG, 0, gh, hold ? null : { move: true });   // (GF11) move: en movimiento, solo las estrellas mas brillantes (apagado, nada)
         var ex = FV_GAL3.EXPO * (1 + FG.EN * (1 - fvGal3Smooth(tr / FG.EN_R)));
         fvGal3Tone(G.buf, new Uint32Array(G.bmp.pixelData()), gw * gh, Math.round(ex * 100) / 100);
         bmp = G.bmp;
         if (hold) { G.hold = G.bmp; G.bmp = null; G.buf = null; }
      }
   }
   D.frame.fill(0xff000000);
   var g = new Graphics(D.frame);
   try {
      g.antialiasing = true; g.smoothInterpolation = true;
      // el primer tramo: el CIELO desde el Sol (la Via Lactea vista desde dentro, el mismo mapa que el fondo de la nave) alrededor de la foto,
      // cada vez mas expuesto a medida que el campo se abre (como una foto de gran campo: si no, al encogerse la foto queda negro)
      if (aS > 0.01) fvGalSky(g, D, cam, aS, cam.wf);
      g.compositionOperator = CompositionOp_Add;
      if (bmp) { if (bmp.width === W && bmp.height === H) g.drawBitmap(0, 0, bmp); else g.drawScaledBitmap(0, 0, W, H, bmp); }
      g.compositionOperator = CompositionOp_SourceOver;
      // la foto de la nave pegada en el plano de la nebulosa: se encoge hasta la marca
      var pc = G.corners.map(function(p) { return fvGal3Project(cam, p); }), aP = 0;
      if (pc[0] && pc[1] && pc[2] && pc[3]) {
         var size = Math.sqrt((pc[1][0] - pc[0][0]) * (pc[1][0] - pc[0][0]) + (pc[1][1] - pc[0][1]) * (pc[1][1] - pc[0][1]));
         aP = fvGal3Smooth((size - 6) / 60);
         // (ronda 2, D-11) si la mirada baja antes de que la foto sea un punto, la foto se queda dentro del cuadro (pegada al borde) y se apaga
         var bx0 = Math.min(pc[0][0], pc[1][0], pc[2][0], pc[3][0]), bx1 = Math.max(pc[0][0], pc[1][0], pc[2][0], pc[3][0]), by0 = Math.min(pc[0][1], pc[1][1], pc[2][1], pc[3][1]), by1 = Math.max(pc[0][1], pc[1][1], pc[2][1], pc[3][1]), mg = 6;
         var shx = (bx1 - bx0 > W - 2 * mg) ? 0 : (bx0 < mg ? mg - bx0 : (bx1 > W - mg ? W - mg - bx1 : 0)), shy = (by1 - by0 > H - 2 * mg) ? 0 : (by0 < mg ? mg - by0 : (by1 > H - mg ? H - mg - by1 : 0));
         if (shx || shy) { pc = pc.map(function(q) { return [q[0] + shx, q[1] + shy, q[2]]; }); aP *= 1 - fvGal3Smooth(Math.sqrt(shx * shx + shy * shy) / (FG.PIN_FADE * W)); }
         var A = fvGalAffine((pc[1][0] - pc[0][0]) / W, (pc[1][1] - pc[0][1]) / W, (pc[2][0] - pc[0][0]) / H, (pc[2][1] - pc[0][1]) / H);
         if (aP > 0.01 && A) {
            g.translateTransformation(pc[0][0], pc[0][1]); g.rotateTransformation(-A.rot); g.shearTransformation(A.shear, 0); g.scaleTransformation(A.sx, A.sy);
            g.opacity = aP; g.drawBitmap(0, 0, G.snap); g.opacity = 1;
            g.resetTransformation();
         }
      }
      G.aP = aP; G.aG = aG; G.aS = aS; G.s = s;
      var aA = fvGal3Smooth((s - 0.70) / 0.22), aM = Math.max(aA, (1 - aP) * fvGal3Smooth((tr - 0.3) / 1.5));
      if (aM > 0.01) fvGalOverlay(g, D, cam, aA, aM);
      fvFramePaint(g, W, H);
   } finally { g.end(); }
   return { ms: fvNowMs() - t0, stars: 0 };
}
// (ronda 2, D-1) la vista FINAL es fija (la camara c1): se calcula por franjas de filas a pantalla entera, ms como mucho (0 = hasta acabar)
function fvGalPre(D, ms) {
   var G = D.gal, W = D.VW, H = D.VH;
   if (G.hold) return;
   if (!G.pre) G.pre = { buf: new Float32Array(3 * W * H), y: 0 };
   var p = G.pre, t0 = fvNowMs(), band = Math.max(4, Math.round(H / 64));
   while (p.y < H && (ms <= 0 || fvNowMs() - t0 < ms)) { var y1 = Math.min(H, p.y + band); fvGal3Render(G.c1, W, H, p.buf, 1, p.y, y1); p.y = y1; }
   if (p.y >= H) { var bm = new Bitmap(W, H, BitmapFormat.RGB32); fvGal3Tone(p.buf, new Uint32Array(bm.pixelData()), W * H); G.hold = bm; G.pre = null; }
}
// el cielo visto desde dentro con la camara del zoom (mapa FV_MW2 desde el Sol y su grano), con peso a
var FV_GAL_ID = { ex: [1, 0, 0], ey: [0, 1, 0], ez: [0, 0, 1] };
// (ronda 2, D-11) con wf (0 -> 1 a medida que el campo se abre) el cielo se EXPONE como una foto de gran campo: el suelo sube al percentil
// SKY_PLO de lo que se ve (ese tanto queda negro: el negro no se vuelve gris) y lo que esta en el percentil SKY_PHI llega a SKY_XHI (la
// franja se ve aunque se mire al anticentro), con la ganancia topada en SKY_GMAX (hacia los polos no se inventa una franja)
function fvGalSky(g, D, cam, a, wf) {
   var G = D.gal, P = D.painter, M2 = FV_MW2, GW = M2.GW, GH = M2.GH, W = D.VW, H = D.VH, FG = FV_GAL, ww = wf || 0, n0 = GW * GH, MAP = G.skyMap || P.mw2;
   if (!G.skyBmp) { G.skyBmp = new Bitmap(GW, GH, BitmapFormat.RGB32); G.skyS = new Float32Array(3 * n0); G.skyQ = new Float32Array(Math.ceil(n0 / 3)); }
   var px = new Uint32Array(G.skyBmp.pixelData()), SS = G.skyS, Q = G.skyQ, r = cam.r, d = cam.d, fw = cam.fw, f = cam.f, sx = W / GW, sy = H / GH, dir = [0, 0, 0], ref = G.skyRef || P.mw2Ref, nq = 0, i = 0;
   for (var y = 0; y < GH; ++y) {
      var vy = ((y + 0.5) * sy - cam.cy) / f;
      for (var x = 0; x < GW; ++x, ++i) {
         var vx = ((x + 0.5) * sx - cam.cx) / f;
         dir[0] = fw[0] + vx * r[0] + vy * d[0]; dir[1] = fw[1] + vx * r[1] + vy * d[1]; dir[2] = fw[2] + vx * r[2] + vy * d[2];
         var nn = 1 / Math.sqrt(dir[0] * dir[0] + dir[1] * dir[1] + dir[2] * dir[2]); dir[0] *= nn; dir[1] *= nn; dir[2] *= nn;
         var sm = fvMw2Sample(MAP, FV_GAL_ID, dir), xv = Math.min(1.8, sm[0] / ref);
         SS[3 * i] = xv; SS[3 * i + 1] = sm[1]; SS[3 * i + 2] = sm[2];
         if (i % 3 === 0) Q[nq++] = xv;
      }
   }
   var fl = M2.FLOOR, sc = 1;
   if (ww > 0.001) {
      var qs = Array.prototype.slice.call(Q, 0, nq).sort(function(u, v) { return u - v; }), pLo = qs[Math.floor(FG.SKY_PLO * (nq - 1))], pHi = qs[Math.floor(FG.SKY_PHI * (nq - 1))];
      // el suelo puede bajar del fijo (hacia los polos, M 82, todo esta por debajo); entra entero cuando el campo ya es algo ancho (wf 0,3):
      // con la mezcla lineal en wf el suelo quedaba por encima de todo el cielo de M 82 y el fotograma salia negro (medido en node)
      var wq = fvGal3Smooth(ww / 0.3), flE = pLo; fl = M2.FLOOR + wq * (flE - M2.FLOOR);
      sc = 1 + wq * (Math.min(FG.SKY_GMAX, Math.max(1, FG.SKY_XHI / Math.max(1e-4, pHi - flE))) - 1);
   }
   G.skyExp = { floor: fl, gain: sc };
   var pk = M2.PEAK * a, kn = M2.KNEE, gm = M2.GAMMA, inv = 1 / (1 - M2.FLOOR), cD = M2.COL_DISC, cB = M2.COL_BULGE, cY = M2.COL_YOUNG;
   for (i = 0; i < n0; ++i) {
      var xx = (SS[3 * i] - fl) * sc;
      if (xx <= 0) { px[i] = 0xff000000; continue; }
      xx = xx * xx / (xx + kn);
      var v = pk * Math.pow(xx * inv, gm), bb = SS[3 * i + 1], yy = Math.min(1, 0.8 * SS[3 * i + 2]) * (1 - bb), wd = 1 - bb - yy;
      var cr = Math.min(255, Math.round(v * (cD[0] * wd + cB[0] * bb + cY[0] * yy))), cg = Math.min(255, Math.round(v * (cD[1] * wd + cB[1] * bb + cY[1] * yy))), cb = Math.min(255, Math.round(v * (cD[2] * wd + cB[2] * bb + cY[2] * yy)));
      px[i] = (0xff000000 | (cr << 16) | (cg << 8) | cb) >>> 0;
   }
   g.drawScaledBitmap(0, 0, W, H, G.skyBmp);
   fvMw2Sprites(P);
   var gd = G.grain, wn = P.mw2Grain.w, n = wn.length, op = g.compositionOperator;
   g.compositionOperator = CompositionOp_Add;
   for (var k = 0; k < n; ++k) {
      var ax = gd[3 * k], ay = gd[3 * k + 1], az = gd[3 * k + 2], zc = ax * fw[0] + ay * fw[1] + az * fw[2];
      if (zc < 0.05) continue;
      var X = cam.cx + f * (ax * r[0] + ay * r[1] + az * r[2]) / zc, Y = cam.cy + f * (ax * d[0] + ay * d[1] + az * d[2]) / zc;
      if (X < 1 || Y < 1 || X > W - 2 || Y > H - 2) continue;
      var lev = Math.floor(wn[k] * a * 4.4); if (lev > 3) lev = 3; if (lev < 0) continue;
      g.drawBitmap(Math.round(X) - 1, Math.round(Y) - 1, P.mwSpr2[lev]);
   }
   g.compositionOperator = op;
}
// los rotulos: Sol, linea de vision y cono, la marca del campo, los brazos, el centro, la escala y la placa. aA = rotulos; aM = la marca
// (encargo GF2) ¿actua GF2 en esta vista? (subinterruptor + las tres banderas; apagado, todo como en GF)
function fvGalGf2() { return (typeof fvGf2On === "function") && fvGf2On() && (typeof fvGalDataOn === "function") && fvGalDataOn(); }
// (encargo GF3) ¿actua GF3? (su subinterruptor encima de GF2)
function fvGalGf3() { return fvGalGf2() && (typeof fvGf3On === "function") && fvGf3On(); }
// (encargo GF3) el radio galactocentrico (kpc) del punto del plano que se ve en el pixel (sx, sy) de la vista; Infinity si el rayo no corta el plano
function fvGalPlaneR(cam, sx, sy) {
   var px = (sx - cam.cx) / cam.f, py = (sy - cam.cy) / cam.f, d = [cam.fw[0] + px * cam.r[0] + py * cam.d[0], cam.fw[1] + px * cam.r[1] + py * cam.d[1], cam.fw[2] + px * cam.r[2] + py * cam.d[2]];
   var Oz = cam.pos[2] + FV_GAL3.ZSUN; if (Math.abs(d[2]) < 1e-9 || -Oz / d[2] <= 0) return Infinity;
   var t = -Oz / d[2], X = cam.pos[0] - FV_GAL3.R0 + t * d[0], Y = cam.pos[1] + t * d[1]; return Math.sqrt(X * X + Y * Y);
}
// (encargo GF3) donde va el rotulo del centro: fuera del bulbo y de la barra, en la perpendicular a la barra EN LA IMAGEN (hacia arriba), a la distancia
// que deja fuera la caja de ±2,2 kpc (en el plano, a lo ancho de la barra) × ±1,1 kpc (en altura) mas un margen; con GF2 iba 34 px encima del centro,
// sobre el bulbo quemado y el carril de la barra (contraste 1,08, revision de GF2). -> { x, y (linea base del texto centrado), lead: [x0, y0, x1, y1] }
function fvGalGcPlace(cam, pC, k, fh) {
   var D2R = Math.PI / 180, a = FV_GAL_GF2.BAR.ANG * D2R, R0 = FV_GAL3.R0;
   var pu = fvGal3Project(cam, [R0 - Math.cos(a), Math.sin(a), 0]), bu = pu ? [pu[0] - pC[0], pu[1] - pC[1]] : [1, 0], lu = Math.sqrt(bu[0] * bu[0] + bu[1] * bu[1]);
   var n = lu > 1e-3 ? [-bu[1] / lu, bu[0] / lu] : [0, -1]; if (n[1] > 0) n = [-n[0], -n[1]]; if (Math.abs(n[1]) < 0.35) n = [0, -1];   // hacia arriba; casi horizontal -> arriba
   var ext = 0, P = [[R0 + 2.2 * Math.sin(a), 2.2 * Math.cos(a), 0], [R0 - 2.2 * Math.sin(a), -2.2 * Math.cos(a), 0], [R0, 0, 1.1], [R0, 0, -1.1]];
   for (var i = 0; i < P.length; ++i) { var p = fvGal3Project(cam, P[i]); if (p) ext = Math.max(ext, (p[0] - pC[0]) * n[0] + (p[1] - pC[1]) * n[1]); }
   var dd = Math.max(34 * k, ext + 12 * k), x = pC[0] + n[0] * dd, y = pC[1] + n[1] * dd;
   return { x: x, y: y + 0.35 * fh, lead: [pC[0] + n[0] * 6 * k, pC[1] + n[1] * 6 * k, pC[0] + n[0] * (dd - 0.6 * fh), pC[1] + n[1] * (dd - 0.6 * fh)] };
}
// (encargo GF2) texto con halo oscuro en 8 direcciones (legible sobre brazos blancos y polvo); la sombra de 1 px de siempre no bastaba
function fvGalHaloText(g, f, x, y, s, col, a, centre) {
   g.font = f; var w = f.width(s), x0 = centre ? x - w / 2 : x, dd = [[-1, -1], [0, -1], [1, -1], [-1, 0], [1, 0], [-1, 1], [0, 1], [1, 1], [0, 2], [2, 0], [-2, 0], [0, -2]];
   g.pen = new Pen(fvGalArgb(0.55 * a, 0x0A0806), 1);
   for (var i = 0; i < dd.length; ++i) g.drawText(x0 + dd[i][0], y + dd[i][1], s);
   g.pen = new Pen(fvGalArgb(a, col), 1); g.drawText(x0, y, s);
}
// (encargo GF2) el punto del rotulo de un brazo, desplazado 0,6 kpc hacia fuera del eje: cae en el interbrazo, no encima del brazo blanco
function fvGalArmLabPt(q, gf2, id) { if (!gf2 || !q) return q; var off = (id && typeof fvGf4LabOff === "function") ? fvGf4LabOff(id) : 0.6, R = Math.sqrt(q[0] * q[0] + q[1] * q[1]), k = (R + off) / Math.max(R, 1e-6); return [q[0] * k, q[1] * k]; }   // (GF4) id: apartamiento por brazo
function fvGalOverlay(g, D, cam, aA, aM) {
   var G = D.gal, W = D.VW, H = D.VH, k = fvHudK(W), gold = 0xE5B53F, ivory = 0xF4ECDC, brass = 0xC9A35A;
   var fI = cpFont("display", 15 * k, false, true, 0), fS = cpFont("display", 13 * k, false, true, 0), fT = cpFont("display", 15 * k, false, false, 2), fL = cpFont("display", 17 * k, true, false, 1);
   function text(f, x, y, s, col, a, centre) { g.font = f; g.pen = new Pen(fvGalArgb(a, 0x0A0806), 1); var w = f.width(s), x0 = centre ? x - w / 2 : x; g.drawText(x0 + 1, y + 1, s); g.pen = new Pen(fvGalArgb(a, col), 1); g.drawText(x0, y, s); }
   g.brush = new Brush(0x00000000);
   var pS = fvGal3Project(cam, [0, 0, 0]), pF = fvGal3Project(cam, G.field);
   // el cono de la foto (si se ve de mas de 3 px) y la linea de vision
   if (pS && pF) {
      var pcn = G.cone.map(function(p) { return fvGal3Project(cam, p); });
      if (pcn[0] && pcn[1] && pcn[2] && pcn[3]) {
         var wpx = Math.max(Math.abs(pcn[0][0] - pcn[2][0]), Math.abs(pcn[0][1] - pcn[2][1]), Math.abs(pcn[1][0] - pcn[3][0]), Math.abs(pcn[1][1] - pcn[3][1]));
         if (wpx > 3) { var pts = [new Point(pS[0], pS[1])]; for (var i = 0; i < 4; ++i) pts.push(new Point(pcn[i][0], pcn[i][1])); g.pen = new Pen(fvGalArgb(0.5 * aM, gold), 0.8 * k); g.brush = new Brush(fvGalArgb(0.18 * aM, gold)); g.drawPolygon(pts); g.brush = new Brush(0x00000000); }
      }
      g.pen = new Pen(fvGalArgb(0.9 * aM, gold), 1.4 * k); g.drawLine(pS[0], pS[1], pF[0], pF[1]);
   }
   // (ronda 2, D-9) las cajas ya ocupadas (la marca del campo y sus rotulos): el del Sol se pone donde no pise ninguna
   var boxes = [];
   if (pF) {
      if (G.outside) {
         // la galaxia de fuera: en el borde, una FLECHA que sigue la linea de vision hacia fuera
         var far = fvGal3Project(cam, [G.field[0] + G.outside.dir[0] * 2, G.field[1] + G.outside.dir[1] * 2, G.field[2] + G.outside.dir[2] * 2]);
         var ax = far ? far[0] - pF[0] : 1, ay = far ? far[1] - pF[1] : 0, al = Math.sqrt(ax * ax + ay * ay);
         if (al < 1e-3 && pS) { ax = pF[0] - pS[0]; ay = pF[1] - pS[1]; al = Math.sqrt(ax * ax + ay * ay); }
         if (al > 1e-3) { ax /= al; ay /= al; } else { ax = 1; ay = 0; }
         var L1 = 34 * k, tx = pF[0] + ax * L1, ty = pF[1] + ay * L1, hw = 6 * k;
         g.pen = new Pen(fvGalArgb(0.95 * aM, gold), 1.6 * k); g.drawLine(pF[0], pF[1], tx, ty);
         g.brush = new Brush(fvGalArgb(0.95 * aM, gold));
         g.drawPolygon([new Point(tx + ax * 9 * k, ty + ay * 9 * k), new Point(tx - ay * hw, ty + ax * hw), new Point(tx + ay * hw, ty - ax * hw)]);
         g.brush = new Brush(0x00000000);
         g.pen = new Pen(fvGalArgb(0.6 * aM, gold), 0.8 * k); g.drawCircle(pF[0], pF[1], 5 * k);
         // el rotulo, del lado de la punta de la flecha
         var lx = tx + ax * 14 * k, ly = ty + ay * 14 * k, w1 = fL.width(G.name), w2 = fI.width(G.distTxt), wm = Math.max(w1, w2), x0 = ax >= -0.2 ? lx : lx - wm;
         x0 = Math.max(10 * k, Math.min(W - wm - 10 * k, x0)); var y0 = Math.max(24 * k, Math.min(H - 70 * k, ly));
         text(fL, x0, y0, G.name, ivory, aM, false); text(fI, x0, y0 + 18 * k, G.distTxt, gold, aM, false);
         boxes.push([x0, y0 - 16 * k, x0 + wm, y0 + 24 * k], [Math.min(pF[0], tx) - 10 * k, Math.min(pF[1], ty) - 10 * k, Math.max(pF[0], tx) + 10 * k, Math.max(pF[1], ty) + 10 * k]);
      } else {
         g.pen = new Pen(fvGalArgb(aM, gold), 1.4 * k); g.drawCircle(pF[0], pF[1], 7 * k);
         g.pen = new Pen(fvGalArgb(0.6 * aM, gold), 0.8 * k); g.drawCircle(pF[0], pF[1], 11 * k);
         var wl = Math.max(fL.width(G.name), fI.width(G.sub + G.distTxt), G.ext ? fS.width(G.ext) : 0), xF = pF[0] + 14 * k, dyF = 0;
         // (encargo GF2) el campo cae cerca del Sol (de canto casi encima; de cara a 2 kpc): el rotulo va al lado (derecha/izquierda) y a la altura
         // (0, arriba, abajo) que no pisa la marca del Sol ni la linea de vision; apagado, siempre a la derecha como hoy
         if (fvGalGf2() && pS) {
            // el rotulo del centro (se pinta despues, centrado 34 px encima del centro) tambien cuenta: de canto el lado izquierdo caia encima de el
            var cF = [[1, 0, 0], [1, -30, 1], [1, 30, 1], [-1, 0, 2], [-1, -30, 3], [-1, 30, 3]], bF = Infinity, pCg = fvGal3Project(cam, [FV_GAL3.R0, 0, 0]), wGc = fS.width(fvTx("gal.gc"));
            var bGc = pCg ? [pCg[0] - wGc / 2 - 4 * k, pCg[1] - 50 * k, pCg[0] + wGc / 2 + 4 * k, pCg[1] - 26 * k] : null, GF3f = fvGalGf3();
            if (GF3f) {          // (encargo GF3) la caja del rotulo del centro donde va de verdad, mas sitios para el del campo (de canto: misma linea a 22 px y encima del Sol)
               if (pCg) { var gp3 = fvGalGcPlace(cam, pCg, k, 13 * k); bGc = [gp3.x - wGc / 2 - 4 * k, gp3.y - 14 * k, gp3.x + wGc / 2 + 4 * k, gp3.y + 5 * k]; }
               cF = cF.concat([[1, -55, 4], [1, 55, 4], [-1, -55, 5], [-1, 55, 5], [1, -80, 6], [1, 80, 6], [-1, -80, 7], [-1, 80, 7]]);
            }
            for (var cf = 0; cf < cF.length; ++cf) {
               var x0c = cF[cf][0] > 0 ? pF[0] + 14 * k : pF[0] - 14 * k - wl, y0c = cF[cf][1] * k, bb0 = [x0c - 3 * k, pF[1] - 22 * k + y0c, x0c + wl + 3 * k, pF[1] + (G.ext ? 32 : 16) * k + y0c], sc = cF[cf][2];
               var ox0 = Math.min(bb0[2], pS[0] + 10 * k) - Math.max(bb0[0], pS[0] - 10 * k), oy0 = Math.min(bb0[3], pS[1] + 10 * k) - Math.max(bb0[1], pS[1] - 10 * k);
               if (ox0 > 0 && oy0 > 0) sc += 100 + ox0 * oy0;
               if (bGc) { var ox1 = Math.min(bb0[2], bGc[2]) - Math.max(bb0[0], bGc[0]), oy1 = Math.min(bb0[3], bGc[3]) - Math.max(bb0[1], bGc[1]); if (ox1 > 0 && oy1 > 0) sc += 100 + ox1 * oy1;
                  if (GF3f && oy1 > -4 * k && ox1 > -40 * k) sc += 60; }      // (GF3) ni en la misma linea a menos de 40 px
               if (GF3f && pS[0] >= bb0[0] - 6 * k && pS[0] <= bb0[2] + 6 * k && pS[1] >= bb0[1] - 6 * k && pS[1] <= bb0[3] + 6 * k) sc += 200;   // (GF3) ni encima del punto del Sol
               if (GF3f && pCg) { var ox2 = Math.min(bb0[2], pCg[0] + 45 * k) - Math.max(bb0[0], pCg[0] - 45 * k), oy2 = Math.min(bb0[3], pCg[1] + 28 * k) - Math.max(bb0[1], pCg[1] - 28 * k); if (ox2 > 0 && oy2 > 0) sc += 150; }   // (GF3) ni encima del bulbo (de canto caia sobre el)
               for (var sq = 0; sq <= 10; ++sq) { var xs = pS[0] + (pF[0] - pS[0]) * sq / 10, ys = pS[1] + (pF[1] - pS[1]) * sq / 10; if (xs >= bb0[0] && xs <= bb0[2] && ys >= bb0[1] && ys <= bb0[3]) sc += 20; }
               if (bb0[0] < 4 * k || bb0[2] > W - 4 * k || bb0[1] < 4 * k || bb0[3] > H - 4 * k) sc += 1e6;
               if (sc < bF) { bF = sc; xF = x0c; dyF = y0c; }
            }
         }
         text(fL, xF, pF[1] - 6 * k + dyF, G.name, ivory, aM, false);
         text(fI, xF, pF[1] + 12 * k + dyF, G.sub + G.distTxt, gold, aM, false);
         if (G.ext) text(fS, xF, pF[1] + 28 * k + dyF, G.ext, brass, 0.9 * aM, false);
         boxes.push([pF[0] - 13 * k, pF[1] - 13 * k, pF[0] + 13 * k, pF[1] + 13 * k], [xF - 2 * k, pF[1] - 22 * k + dyF, xF + 2 * k + wl, pF[1] + (G.ext ? 32 : 16) * k + dyF]);
         if (fvGalGf2()) G.labF = boxes[boxes.length - 1].slice();          // (encargo GF3) para las pruebas (gf3_pi.js; tambien con GF2, para su control en rojo)
      }
   }
   if (aA <= 0.01) return;
   var GD = (typeof fvGalDataOn === "function") && fvGalDataOn();      // (encargo GP) la galaxia de datos
   if (GD) fvGalDataOverlayPre(g, D, cam, aA);
   if (pS) {
      g.brush = new Brush(fvGalArgb(aA, 0xFFF3C4)); g.pen = new Pen(fvGalArgb(aA, gold), 1.2 * k); g.drawCircle(pS[0], pS[1], 3.2 * k);
      g.brush = new Brush(0x00000000); g.pen = new Pen(fvGalArgb(0.7 * aA, gold), 0.8 * k); g.drawCircle(pS[0], pS[1], 7.5 * k);
      // el rotulo del Sol: el primer sitio (izquierda, izquierda abajo/arriba, debajo, encima, derecha…) que no pise la marca ni los rotulos
      // del campo; si todos pisan, el que menos (D-9: en M 82 rozaba el anillo del campo). La caja: de y a y + sh, la linea base a y + 0,8·sh
      var sl = fvTx("gal.sun"), sw = fI.width(sl), sh = 15 * k, gap = 11 * k, best = null, bestOv = Infinity;
      var cand = [[-gap - sw, -sh / 2], [-gap - sw, gap], [-gap - sw, -gap - sh], [-sw / 2, gap + 2 * k], [-sw / 2, -gap - sh - 2 * k], [gap, gap], [gap, -gap - sh], [gap, -sh / 2], [-sw / 2, 2 * gap + sh], [-2 * gap - sw, 2 * gap]];
      for (var c = 0; c < cand.length; ++c) {
         var bx0 = pS[0] + cand[c][0], by0 = pS[1] + cand[c][1], bb = [bx0 - 2 * k, by0 - 2 * k, bx0 + sw + 2 * k, by0 + sh + 2 * k], ov = 0;
         for (var q = 0; q < boxes.length; ++q) { var ox = Math.min(bb[2], boxes[q][2]) - Math.max(bb[0], boxes[q][0]), oy = Math.min(bb[3], boxes[q][3]) - Math.max(bb[1], boxes[q][1]); if (ox > 0 && oy > 0) ov += ox * oy; }
         if (bx0 < 4 * k || by0 < 4 * k || bx0 + sw > W - 4 * k || by0 + sh > H - 4 * k) ov += 1e6;
         if (ov < bestOv) { bestOv = ov; best = [bx0, by0]; if (ov <= 0) break; }
      }
      G.sunLab = { x: best[0], y: best[1], w: sw, h: sh, ov: bestOv };
      text(fI, best[0], best[1] + 0.8 * sh, sl, ivory, aA, false);
   }
   var pC = fvGal3Project(cam, [FV_GAL3.R0, 0, 0]), GF2 = fvGalGf2();
   if (pC && fvGalGf3()) {        // (encargo GF3) fuera del bulbo y de la barra, con una linea fina hasta el centro, y mas claro (contraste)
      var gp = fvGalGcPlace(cam, pC, k, 13 * k), wg3 = fS.width(fvTx("gal.gc"));
      g.pen = new Pen(fvGalArgb(0.55 * aA, brass), 0.8 * k); g.drawLine(gp.lead[0], gp.lead[1], gp.lead[2], gp.lead[3]);
      fvGalHaloText(g, fS, gp.x, gp.y, fvTx("gal.gc"), 0xF0D9A0, 0.95 * aA, true);
      G.labGc = [gp.x - wg3 / 2 - 2 * k, gp.y - 14 * k, gp.x + wg3 / 2 + 2 * k, gp.y + 5 * k];
   }
   else if (pC) { if (GF2) { fvGalHaloText(g, fS, pC[0], pC[1] - 34 * k, fvTx("gal.gc"), brass, 0.9 * aA, true); var wg2 = fS.width(fvTx("gal.gc")); G.labGc = [pC[0] - wg2 / 2 - 2 * k, pC[1] - 34 * k - 14 * k, pC[0] + wg2 / 2 + 2 * k, pC[1] - 34 * k + 5 * k]; } else text(fS, pC[0], pC[1] - 34 * k, fvTx("gal.gc"), brass, 0.85 * aA, true); }   // (GF3) la caja, tambien con GF2 (pruebas)
   // (ronda 2b) los rotulos de los brazos estan en el plano: de canto se amontonan sobre la raya del disco y se apagan (de cara, 1: la vista de hoy)
   var A = FV_GAL3.ARMS, aArm = fvGal3Smooth((Math.abs(cam.fw[2]) - 0.18) / 0.25);
   if (GD && FV_GAL_DATA.SOLO) aArm = 0;                               // (encargo GP) «solo datos»: los brazos son modelo, sin rotulos
   for (var j = 0; j < A.length && aArm > 0.01; ++j) {
      if (!A[j].lab) continue;
      var q = (GD && FV_GAL_DATA_ST.gg) ? fvGgArmPoint(A[j].id, (typeof fvGf3LabBeta === "function") ? fvGf3LabBeta(A[j]) : A[j].lb) : fvGal3ArmPoint(A[j].id, A[j].lb); if (!q) continue;   // (encargo GG) en los brazos ajustados; (GF3) donde el brazo se ve
      q = fvGalArmLabPt(q, GF2, A[j].id);                                                                                              // (encargo GF2) en el interbrazo; (GF4) Sgr-Car sobre su cresta
      var pa = fvGal3Project(cam, [q[0] + FV_GAL3.R0, q[1], 0]);
      if (pa && pa[0] > 40 * k && pa[0] < W - 40 * k && pa[1] > 20 * k && pa[1] < H - 60 * k) { if (GF2) fvGalHaloText(g, fS, pa[0], pa[1], fvTx(A[j].lab), brass, 0.9 * aA * aArm, true); else text(fS, pa[0], pa[1], fvTx(A[j].lab), brass, 0.8 * aA * aArm, true); }
   }
   // la escala: 10 000 a.l. a la profundidad del Sol
   if (pS) {
      var L10 = 10000 / (1000 * FV_LY_PER_PC), px10 = cam.f * L10 / pS[2], x1 = W - 30 * k, x0 = x1 - px10, yb = H - 34 * k;
      g.pen = new Pen(fvGalArgb(0.85 * aA, gold), 1.2 * k); g.drawLine(x0, yb, x1, yb); g.drawLine(x0, yb - 5 * k, x0, yb + 5 * k); g.drawLine(x1, yb - 5 * k, x1, yb + 5 * k);
      text(fS, (x0 + x1) / 2, yb - 9 * k, fvNum(10000, 0, FV_LANG) + " " + fvTx("nav.ly"), gold, 0.85 * aA, true);
   }
   text(fT, 30 * k, H - 50 * k, fvTx("gal.title"), gold, aA, false);
   if (GD) { fvGalDataFooter(g, D, cam, aA, text, fT, fS); return; }    // (encargo GP) fuentes, % medido y «solo datos»
   text(fS, 30 * k, H - 30 * k, fvTx((typeof FV_GAL_ORB !== "undefined" && FV_GAL_ORB.ON) ? "gal.note3d" : "gal.note"), brass, 0.8 * aA, false);   // (ronda 2b) con el giro, la placa lo dice
}

// ---------------------------------------------------------------------------
// D2 · LA VIA LACTEA DE FONDO NUEVA (gancho de una linea en FVPainter.paintMilkyWay)
// ---------------------------------------------------------------------------
// en casa (peso 0) no se pinta nada: solo se adelanta el calculo (mapa de cara y cielo desde el Sol). finish = terminarlo ya
function fvMw2Prep(painter, Fr, finish) {
   if (painter.mw2) { if (typeof FV_GAL_DATA !== "undefined" && FV_GAL_DATA.ON && !finish) fvGalDataEnsure(FV_MW2.JOB_MS); return true; }   // (encargo GP) y la galaxia de datos, por trozos
   if (!fvGal3TexReady()) { if (finish) fvGal3Tex(); else { fvGal3TexStep(FV_MW2.JOB_MS); return false; } }
   if (!painter.mw2Job0) painter.mw2Job0 = fvMw2MapBegin(Fr, [0, 0, 0]);
   if (!fvMw2MapStep(painter.mw2Job0, finish ? 0 : FV_MW2.JOB_MS)) return false;
   var m0 = painter.mw2Job0.map; painter.mw2Job0 = null;
   painter.mw2Ref = fvMw2Ref(m0); painter.mw2Grain = fvMw2Grain(m0, Fr, FV_MW2.GRAIN, 9092); painter.mw2 = m0;
   painter.mw2Home = m0; painter.mw2HomeRef = painter.mw2Ref;   // (ronda 2) el mapa desde casa se guarda: en casa el pintor no remapea (peso 0)
   return true;
}
function fvMw2Sprites(painter) {
   if (painter.mwSpr2) return painter.mwSpr2;
   painter.mwSpr2 = [];
   for (var lv = 0; lv < 4; ++lv) {
      var I = [0.18, 0.32, 0.52, 0.80][lv], bm = new Bitmap(3, 3, BitmapFormat.RGB32), q = new Uint32Array(bm.pixelData());
      for (var j = 0; j < 9; ++j) { var dd = (j === 4) ? 1 : ((j % 2) ? 0.35 : 0.15), cc = Math.round(255 * I * dd); q[j] = (0xff000000 | (cc << 16) | (Math.round(cc * 0.95) << 8) | Math.round(cc * 0.86)) >>> 0; }
      painter.mwSpr2.push(bm);
   }
   return painter.mwSpr2;
}
FVPainter.prototype.paintMilkyWay2 = function(g, pr, P) {
   var M2 = FV_MW2, Fr = this.scene.galaxy, w = (M2.FORCE_W !== null && M2.FORCE_W !== undefined) ? M2.FORCE_W : this.mwWeight(P) * ((typeof fvN4bMwK === "function") ? fvN4bMwK(this.scene, P.cam.pos) : 1);   // (19-nov, N4b) la Via Lactea se atenua junto al protagonista cuyo FV_N4 alejo la llegada (FV_N4B; 1 = como antes)
   this.stats.mwW = w; this.stats.mwMean = 0; this.stats.mwGrain = 0;
   if (w < 0.01) { fvMw2Prep(this, Fr, false); return; }
   if (!this.mw2) fvMw2Prep(this, Fr, true);
   // el mapa se rehace (por trozos) al moverse mas de REMAP_LY o del 20 % de la distancia a casa; SYNC (pruebas) = de una vez
   var mv = fvLen(fvSub(P.cam.pos, this.mw2.camLy));
   if (mv > Math.max(FV_MW.REMAP_LY, 0.2 * fvLen(P.cam.pos))) {
      if (M2.SYNC) { var tq = fvNowMs(); this.mw2 = fvMw2Map(Fr, P.cam.pos); this.mw2Job = null; this.stats.mwRemapMs = fvNowMs() - tq; ++this.stats.mwRemaps; }
      else if (!this.mw2Job) this.mw2Job = fvMw2MapBegin(Fr, P.cam.pos);
   }
   if (this.mw2Job && fvMw2MapStep(this.mw2Job, M2.JOB_MS)) { this.mw2 = this.mw2Job.map; this.mw2Job = null; ++this.stats.mwRemaps; }
   var GW = M2.GW, GH = M2.GH;
   if (!this.mwSmall2) this.mwSmall2 = new Bitmap(GW, GH, BitmapFormat.RGB32);
   var px = new Uint32Array(this.mwSmall2.pixelData()), r = pr.r, d = pr.d, fw = pr.fw, f = pr.f, sx = pr.W / GW, sy = pr.H / GH, ref = this.mw2Ref;
   var pk = M2.PEAK * w, dir = [0, 0, 0], sum = 0, mwS = pr.S || 1;
   var MS = fvMw2Soft(this.mw2);                                     // (ronda 3) el mapa suavizado (bordes suaves); SOFT_B = SOFT_L = 0: el de siempre
   // (ronda 3) EL CIELO DE HOY DEBAJO. La Via Lactea de antes (su mapa, su curva y sus colores, sin suelo) es el minimo de cada celda y la nueva
   // solo sube donde es mas brillante (maximo por canal). Asi, fuera de la banda el cielo no es mas oscuro que hoy, y la banda nueva no arranca
   // de un negro recortado: el SUELO restado dejaba 0 junto a una rampa casi lineal, y eso se veia como una franja de borde duro (tiras v5 de A).
   // Mapa propio (mwB), no el del pintor de hoy: con FV_MW2.ON = false el estado de hoy no cambia. FV_MW2.BASE = false: la ronda 2 (control en rojo)
   var base = M2.BASE !== false, kO = FV_PAINT.MW_PEAK * w, gaO = FV_PAINT.MW_GAMMA, cOD = FV_MW.COL_DISC, cOB = FV_MW.COL_BULGE, refO = 1;
   if (base) {
      if (!this.mwB) { var mB0 = fvMwMap(Fr, [0, 0, 0]); this.mwBRef = fvMwRef(mB0); this.mwB = mB0; }
      if (fvLen(fvSub(P.cam.pos, this.mwB.camLy)) > Math.max(FV_MW.REMAP_LY, 0.2 * fvLen(P.cam.pos)) && P.warp < 0.3) this.mwB = fvMwMap(Fr, P.cam.pos);
      refO = this.mwBRef;
   }
   for (var y = 0; y < GH; ++y) {
      var vy = ((y + 0.5) * sy - pr.cy) / f;
      for (var x = 0; x < GW; ++x) {
         var vx = ((x + 0.5) * sx - pr.cx) / f;
         dir[0] = fw[0] + vx * r[0] + vy * d[0]; dir[1] = fw[1] + vx * r[1] + vy * d[1]; dir[2] = fw[2] + vx * r[2] + vy * d[2];
         if (mwS !== 1) { dir[0] /= mwS; dir[1] /= mwS; }                 // (LABORATORIO) del rayo en vuelo a la direccion real del cielo
         var nn = 1 / Math.sqrt(dir[0] * dir[0] + dir[1] * dir[1] + dir[2] * dir[2]); dir[0] *= nn; dir[1] *= nn; dir[2] *= nn;
         var c = fvMw2Colour(fvMw2Sample(MS, Fr, dir), ref, pk);
         if (base) {
            var so = fvMwSample(this.mwB, Fr, dir), vo = kO * Math.pow(Math.min(1.6, so[0] / refO), gaO), bo = so[1];
            var oR = Math.min(255, Math.round(vo * (cOD[0] + (cOB[0] - cOD[0]) * bo))), oG = Math.min(255, Math.round(vo * (cOD[1] + (cOB[1] - cOD[1]) * bo))), oB = Math.min(255, Math.round(vo * (cOD[2] + (cOB[2] - cOD[2]) * bo)));
            if (oR > c[0]) c[0] = oR; if (oG > c[1]) c[1] = oG; if (oB > c[2]) c[2] = oB;
         }
         px[y * GW + x] = (0xff000000 | (c[0] << 16) | (c[1] << 8) | c[2]) >>> 0; sum += c[1];
      }
   }
   this.stats.mwMean = sum / (255 * GW * GH);
   var op = g.compositionOperator, sm = g.smoothInterpolation;
   g.compositionOperator = CompositionOp_Add; g.smoothInterpolation = true;
   g.drawScaledBitmap(0, 0, pr.W, pr.H, this.mwSmall2);
   g.smoothInterpolation = sm;
   // el grano: 4 sprites de 3×3 (blanco calido), algo mas brillantes que antes
   fvMw2Sprites(this);
   var Gn = this.mw2Grain, gd = Gn.d, nG = 0;
   for (var n = 0; n < Gn.n; ++n) {
      var ax = gd[3 * n], ay = gd[3 * n + 1], az = gd[3 * n + 2];
      if (mwS !== 1) { ax *= mwS; ay *= mwS; var nG2 = 1 / Math.sqrt(ax * ax + ay * ay + az * az); ax *= nG2; ay *= nG2; az *= nG2; }   // (LABORATORIO)
      var zc = ax * fw[0] + ay * fw[1] + az * fw[2];
      if (zc < 0.05) continue;
      var X = pr.cx + f * (ax * r[0] + ay * r[1] + az * r[2]) / zc, Y = pr.cy + f * (ax * d[0] + ay * d[1] + az * d[2]) / zc;
      if (X < 1 || Y < 1 || X > pr.W - 2 || Y > pr.H - 2) continue;
      var lev = Math.floor(Gn.w[n] * w * 4.4); if (lev > 3) lev = 3;
      g.drawBitmap(Math.round(X) - 1, Math.round(Y) - 1, this.mwSpr2[lev]); ++nG;
   }
   this.stats.mwGrain = nG;
   g.compositionOperator = op;
};

// ---------------------------------------------------------------------------
// (ronda 2b, 9-nov) GIRAR LA GALAXIA EN 3D (bandera FV_GAL_ORB.ON). Nino: «En el modo Galaxia, haz que aparezca la representacion real de
// la Via Lactea y que se pueda mover en 3D». En la vista final (quieta): ARRASTRAR = girarla (de lado = alrededor; arriba/abajo = de cara
// a de canto, y por debajo), RUEDA = acercar o alejar; con inercia suave (la vista sigue al raton con retardo TAU y, al soltar, sigue
// girando y frena en TAU_V). CLIC sin mover (< CLICK_PX) = volver, como siempre: si se habia girado, primero vuelve a la vista de partida
// (HOME_S) y luego hace el zoom de vuelta de siempre (la manera de volver no cambia). Doble mando, nada mas: no hay botones nuevos.
// Mientras se mueve, la galaxia se pinta a escala SCALE con NMAX_MOVE pasos por rayo; quieta, se rehace a pantalla entera por franjas
// (REF_MS por fotograma). Sin girar, la vista es la de siempre (G.hold), bit a bit.
// El disco sale del mapa de cara: el procedimental o, si FV_GAL_ORB.IMG.path apunta a una imagen de cara de la Via Lactea que exista,
// esa imagen (fvGalDiscTex; gc y sun = sus pixeles del centro galactico y del Sol). Aqui no se baja ninguna: la elige Nino.
// ---------------------------------------------------------------------------
var FV_GAL_ORB = { ON: true, DEG_PER_W: 200, DEG_PER_H: 140, WHEEL: 1.15, D_MIN: 6, D_MAX: 140, TAU: 0.09, TAU_V: 0.45, V_MAX: 360,
                   CLICK_PX: 4, HOME_S: 0.6, SCALE: 0.4, NMAX_MOVE: 10, REF_MS: 40,
                   IMG: { path: "", gc: null, sun: null, south: false } };
// el mapa de cara del disco: la imagen si la hay (una vez), si no null (el procedimental)
function fvGalDiscTex() {
   var I = FV_GAL_ORB.IMG;
   if (!I || !I.path || !I.gc || !I.sun) { FV_GAL3_DISC = null; return null; }
   if (FV_GAL3_DISC && FV_GAL3_DISC.srcPath === I.path) return FV_GAL3_DISC;
   try {
      if (!File.exists(I.path)) { fvLog("galaxy view: disc image not found, procedural disc: " + I.path); FV_GAL3_DISC = null; return null; }
      var bm = new Bitmap(I.path), w = bm.width, h = bm.height, px = new Uint32Array(w * h), src = new Uint32Array(bm.pixelData());
      for (var i = 0; i < w * h; ++i) px[i] = src[i];
      FV_GAL3_DISC = fvGal3TexFromPixels(px, w, h, { gc: I.gc, sun: I.sun, south: !!I.south });
      FV_GAL3_DISC.srcPath = I.path;
      fvLog("galaxy view: disc from image " + w + "×" + h + " (gain " + FV_GAL3_DISC.gain.toFixed(2) + ")");
   } catch (e) { fvLog("galaxy view: disc image failed, procedural disc: " + e); FV_GAL3_DISC = null; }
   return FV_GAL3_DISC;
}
function fvGalOrbHold(D) { var G = D && D.gal; return !!(FV_GAL_ORB.ON && G && G.t >= 1 && G.dir > 0); }
// el estado de la orbita: home (la de partida, = la vista final), cur (la que se ve), tgt (a la que va), v (°/s al soltar)
function fvGalOrbNew(D) {
   var G = D.gal, h = fvGal3OrbitFrom(G.c1);
   return { home: h, cur: { az: h.az, el: h.el, dist: h.dist, roll: h.roll }, tgt: { az: h.az, el: h.el, dist: h.dist, roll: h.roll }, v: [0, 0], drag: null,
            away: false, goHome: false, key: "", lo: null, hi: null, ref: null, ms: [] };
}
function fvGalOrbCam(D, O, W, H, sc) {
   var h = O.home, k = (sc || 1);
   return fvGal3OrbitCam({ tgt: h.tgt, az: O.cur.az, el: O.cur.el, dist: O.cur.dist, roll: O.cur.roll, f: h.f * k, cx: h.cx * k, cy: h.cy * k });
}
// el signo del giro de lado: que la galaxia siga al raton (lo que se mueve la camara hacia su derecha, la galaxia se va a la izquierda)
function fvGalOrbSign(D, O) {
   var c = fvGalOrbCam(D, O, D.VW, D.VH, 1), D2R = Math.PI / 180, el = O.cur.el * D2R, az = O.cur.az * D2R, du = [-Math.cos(el) * Math.sin(az), Math.cos(el) * Math.cos(az), 0];
   var s = du[0] * c.r[0] + du[1] * c.r[1] + du[2] * c.r[2];
   return s >= 0 ? 1 : -1;
}
// -> true si lo consume (en la vista final con la bandera); si no, lo de siempre (el clic vuelve)
function fvGalPress(D, x, y) {
   if (!fvGalOrbHold(D)) return false;
   var G = D.gal;
   if (typeof fvGalDataOn === "function" && fvGalDataOn() && fvGalDataHit(G.dChip, x, y)) { G.chipPress = true; return true; }   // (encargo GP) el chip «solo datos»
   if (!G.orb) G.orb = fvGalOrbNew(D);
   var O = G.orb; if (O.goHome) return true;
   O.v = [0, 0];
   O.drag = { x0: x, y0: y, az0: O.tgt.az, el0: O.tgt.el, moved: false, sg: fvGalOrbSign(D, O), hist: [[fvNowMs(), O.tgt.az, O.tgt.el]] };
   return true;
}
function fvGalMove(D, x, y, buttons) {
   var G = D.gal, O = G && G.orb, d = O && O.drag;
   if (!d && G && typeof fvGalDataOn === "function" && fvGalDataOn()) fvGalDataHover(D, x, y);   // (encargo GP) tooltip del pie y del chip
   if (!d) return false;
   if (!d.moved && Math.abs(x - d.x0) + Math.abs(y - d.y0) > FV_GAL_ORB.CLICK_PX) d.moved = true;
   if (!d.moved) return true;
   var FO = FV_GAL_ORB;
   O.tgt.az = d.az0 - d.sg * (x - d.x0) / D.VW * FO.DEG_PER_W;
   O.tgt.el = Math.max(-90, Math.min(90, d.el0 + (y - d.y0) / D.VH * FO.DEG_PER_H));
   O.tgt.roll = O.home.roll * fvGalOrbRollW(O.tgt.el, O.home.el);
   O.away = true;
   var now = fvNowMs(); d.hist.push([now, O.tgt.az, O.tgt.el]); while (d.hist.length > 2 && now - d.hist[0][0] > 90) d.hist.shift();
   return true;
}
// el giro de pantalla de partida (que deja el centro galactico arriba en la vista final) se va quitando al ponerse de canto
function fvGalOrbRollW(el, el0) { return fvGal3Smooth((Math.abs(el) - 10) / Math.max(1, Math.abs(el0) - 10)); }
function fvGalRelease(D, x, y) {
   var G = D.gal, O = G && G.orb, d = O && O.drag;
   if (G && G.chipPress) { G.chipPress = false; if (fvGalDataHit(G.dChip, x, y)) fvGalDataSetSolo(D, !FV_GAL_DATA.SOLO); return true; }   // (encargo GP)
   if (!d) return false;
   O.drag = null;
   if (!d.moved) { fvGalToggle(D); return true; }
   // la inercia: la velocidad de los ultimos ~90 ms
   var h = d.hist, a = h[0], b = h[h.length - 1], dt = (b[0] - a[0]) / 1000, FO = FV_GAL_ORB;
   if (dt > 0.005 && fvNowMs() - b[0] < 80) { O.v = [Math.max(-FO.V_MAX, Math.min(FO.V_MAX, (b[1] - a[1]) / dt)), Math.max(-FO.V_MAX, Math.min(FO.V_MAX, (b[2] - a[2]) / dt))]; }
   else O.v = [0, 0];
   return true;
}
function fvGalWheel(D, delta) {
   if (!fvGalOrbHold(D)) return false;
   var G = D.gal; if (!G.orb) G.orb = fvGalOrbNew(D);
   var O = G.orb, FO = FV_GAL_ORB; if (O.goHome) return true;
   O.tgt.dist = Math.max(FO.D_MIN, Math.min(FO.D_MAX, O.tgt.dist * Math.pow(FO.WHEEL, -(delta || 0) / 120)));
   O.away = true;
   return true;
}
// un paso del reloj: inercia, la vista que sigue a su objetivo y la vuelta a la de partida
function fvGalOrbStep(D, dt) {
   var G = D.gal, O = G && G.orb, FO = FV_GAL_ORB; if (!O || !(dt > 0)) return;
   if (O.goHome) { O.tgt = { az: O.home.az, el: O.home.el, dist: O.home.dist, roll: O.home.roll }; O.v = [0, 0]; }
   else if (!O.drag && (O.v[0] || O.v[1])) {
      var k = Math.exp(-dt / FO.TAU_V); O.v = [O.v[0] * k, O.v[1] * k];
      O.tgt.az += O.v[0] * dt; O.tgt.el = Math.max(-90, Math.min(90, O.tgt.el + O.v[1] * dt)); O.tgt.roll = O.home.roll * fvGalOrbRollW(O.tgt.el, O.home.el);
      if (Math.abs(O.v[0]) + Math.abs(O.v[1]) < 0.5) O.v = [0, 0];
   }
   var tau = O.goHome ? FO.HOME_S / 4 : FO.TAU, a = 1 - Math.exp(-dt / tau), c = O.cur, t = O.tgt;
   c.az += (t.az - c.az) * a; c.el += (t.el - c.el) * a; c.roll += (t.roll - c.roll) * a; c.dist = Math.exp(Math.log(c.dist) + (Math.log(t.dist) - Math.log(c.dist)) * a);
   // casi llegado: llegado (si no, la vista cambiaria una milesima en cada fotograma y no se quedaria nunca quieta para rehacerse entera)
   if (Math.abs(c.az - t.az) + Math.abs(c.el - t.el) + Math.abs(c.roll - t.roll) < 0.01 && Math.abs(Math.log(c.dist / t.dist)) < 1e-4) { c.az = t.az; c.el = t.el; c.roll = t.roll; c.dist = t.dist; }
   if (O.goHome) {
      var h = O.home, off = Math.abs(c.az - h.az) + Math.abs(c.el - h.el) + Math.abs(c.roll - h.roll) + 100 * Math.abs(Math.log(c.dist / h.dist));
      if (off < 0.05) {        // en casa: la vista de siempre y el zoom de vuelta de siempre
         G.orb = null; G.dir = -1;
      }
   }
}
// ¿se ha girado? (si no, la vista es la de siempre)
function fvGalOrbAway(O) {
   if (!O || !O.away) return false;
   var h = O.home, c = O.cur;
   return Math.abs(c.az - h.az) + Math.abs(c.el - h.el) + Math.abs(c.roll - h.roll) + 100 * Math.abs(Math.log(c.dist / h.dist)) > 1e-6 || !!O.drag || O.v[0] !== 0 || O.v[1] !== 0;
}
// EL FOTOGRAMA girado: en movimiento, a escala SCALE; quieta, a pantalla entera por franjas (y se ve la reducida hasta que acaba)
function fvGalOrbRender(D) {
   var G = D.gal, O = G.orb, FO = FV_GAL_ORB, W = D.VW, H = D.VH, t0 = fvNowMs(), T = fvGalDiscTex(), opt = { T: T || undefined };
   var cam = fvGalOrbCam(D, O, W, H, 1), key = [O.cur.az, O.cur.el, O.cur.dist, O.cur.roll].map(function(v) { return v.toFixed(4); }).join(",");
   if (key !== O.key) {
      var sc = FO.SCALE, gw = Math.max(16, Math.round(W * sc)), gh = Math.max(16, Math.round(H * sc));
      if (!O.lo || O.lo.width !== gw) { O.lo = new Bitmap(gw, gh, BitmapFormat.RGB32); O.loBuf = new Float32Array(3 * gw * gh); }
      var cl = fvGalOrbCam(D, O, W, H, gw / W);
      fvGal3RenderVol(cl, gw, gh, O.loBuf, 1, 0, gh, { T: opt.T, nmax: FO.NMAX_MOVE, move: true });   // (GF11) move (apagado, nada)
      fvGal3Tone(O.loBuf, new Uint32Array(O.lo.pixelData()), gw * gh);
      O.key = key; O.ref = { y: 0, key: key, buf: O.ref && O.ref.buf ? O.ref.buf : new Float32Array(3 * W * H) }; O.hi = null;
      O.ms.push(fvNowMs() - t0); if (O.ms.length > 120) O.ms.shift();
   } else if (!O.hi && O.ref) {
      var p = O.ref, tq = fvNowMs(), band = Math.max(4, Math.round(H / 48));
      while (p.y < H && fvNowMs() - tq < FO.REF_MS) { var y1 = Math.min(H, p.y + band); fvGal3RenderVol(cam, W, H, p.buf, 1, p.y, y1, opt); p.y = y1; }
      if (p.y >= H) { var bm = new Bitmap(W, H, BitmapFormat.RGB32); fvGal3Tone(p.buf, new Uint32Array(bm.pixelData()), W * H); O.hi = bm; }
   }
   D.frame.fill(0xff000000);
   var g = new Graphics(D.frame);
   try {
      g.antialiasing = true; g.smoothInterpolation = true;
      if (O.hi) g.drawBitmap(0, 0, O.hi); else g.drawScaledBitmap(0, 0, W, H, O.lo);
      fvGalOverlay(g, D, cam, 1, 1);
      fvFramePaint(g, W, H);
   } finally { g.end(); }
   return { ms: fvNowMs() - t0, stars: 0 };
}

// ---------------------------------------------------------------------------
// (encargo GP, fase 1, 9-nov) LA VIA LACTEA DE DATOS en GALAXIA (motor puro: src/engine/fv_galdata.js; bandera FV_GAL_DATA.ON, encendida por
// defecto desde el 10-nov: con ella apagada nada de esto se ejecuta). En la placa, discreto y en el dorado de Atlas: la linea c = 0,5 (donde acaba el dato),
// el lado lejano rotulado, una leyenda de los puntos, la linea de pie con las fuentes y el % del disco medido (texto largo: tooltip) y el
// chip «SOLO DATOS» (oculta modelo y textura). Sin botones nuevos en la columna: el chip vive en la placa de la vista, como su leyenda.
// ---------------------------------------------------------------------------
function fvGalDataOn() { return !!(typeof FV_GAL_DATA !== "undefined" && FV_GAL_DATA.ON && FV_GAL_DATA_ST && FV_GAL3_MIX); }
// construir (o seguir construyendo, ms por llamada; 0 = acabar) la galaxia de datos desde el extracto FV_GAL_DATA.SRC -> true si esta lista
function fvGalDataEnsure(ms) {
   var A = FV_GAL_DATA, S = FV_GAL_DATA_ST, gk = (typeof fvGgKey === "function") ? fvGgKey() : "";     // (encargo GG) "" con su bandera apagada
   if (S && S.src === A.SRC && S.brk === FV_GAL3_BREAK && S.ks === A.KS && (S.ggKey || "") === gk) return true;
   if (!A.job || A.job.src !== A.SRC || A.job.brk !== FV_GAL3_BREAK || A.job.ks !== A.KS || (A.job.gk || "") !== gk) {
      if (!A.SRC || !File.exists(A.SRC)) { if (A.warned !== A.SRC) { fvLog("galaxy data: no extract (" + (A.SRC || "FV_GAL_DATA.SRC empty") + "): today's galaxy"); A.warned = A.SRC; } if (typeof fvGalDefaultsFall === "function") fvGalDefaultsFall("no extract"); return false; }
      try { A.job = fvGalDataBegin(String(File.readTextFile(A.SRC))); A.job.src = A.SRC; A.job.brk = FV_GAL3_BREAK; A.job.ks = A.KS; if (gk) A.job.gk = gk; }
      catch (e) { fvLog("galaxy data: cannot read the extract: " + e); A.warned = A.SRC; return false; }
   }
   var t0 = fvNowMs();
   if (!fvGalDataStep(A.job, ms)) return false;
   S = FV_GAL_DATA_ST = A.job.S; S.src = A.SRC; S.ks = A.KS; A.job = null;
   fvLog("galaxy data: " + S.n.C + " CO clouds, " + S.n.H + " HII, " + S.n.M + " masers · disc measured " + (100 * S.cov).toFixed(1) + " % · build ms " + JSON.stringify(S.ms) + " (last step " + Math.round(fvNowMs() - t0) + " ms)");
   if (S.gg) fvLog("galaxy geometry (GG): arm positions measured (u < 0.5) on " + (100 * S.gg.cov).toFixed(1) + " % of the disc · fit " + ((typeof fvGgFit === "function" && fvGgFit()) ? fvGgFit().id : "none (Reid 2019)") + " · prep ms " + JSON.stringify(S.gg.ms));
   return true;
}
function fvGalDataHit(b, x, y) { return !!(b && x >= b[0] && x <= b[2] && y >= b[1] && y <= b[3]); }
// «solo datos» si/no: el mapa cambia y la vista quieta se rehace
function fvGalDataSetSolo(D, on) {
   FV_GAL_DATA.SOLO = !!on; FV_GAL3_MIX = fvGalDataTex();
   var G = D && D.gal; if (!G) return;
   G.hold = null; G.pre = null; if (G.orb) { G.orb.key = ""; G.orb.hi = null; }
}
function fvGalDataHover(D, x, y) {
   var G = D.gal, tip = fvGalDataHit(G.dChip, x, y) ? fvTipBoth("gal.d.tipSolo") : (fvGalDataHit(G.dFoot, x, y) ? fvGalDataTip() : "");
   if (tip !== (G.dTip || "")) { G.dTip = tip; try { D.view.toolTip = tip; } catch (e) {} }
   var hand = fvGalDataHit(G.dChip, x, y);
   if (hand !== !!G.dHand) { G.dHand = hand; try { D.view.cursor = new Cursor(hand ? StdCursor_PointingHand : StdCursor_Cross); } catch (e2) {} }
}
// el tooltip largo con las fuentes y las cifras de verdad
function fvGalDataTip() {
   var S = FV_GAL_DATA_ST, N = S.gg ? S.gg.n : S.n, p = { nc: fvNum(N.C, 0, "en"), nh: fvNum(N.H, 0, "en"), nm: fvNum(N.M, 0, "en"), pct: (100 * S.cov).toFixed(0) },
       q = { nc: fvNum(N.C, 0, "es"), nh: fvNum(N.H, 0, "es"), nm: fvNum(N.M, 0, "es"), pct: (100 * S.cov).toFixed(0) };
   if (S.gg) { p.pct = q.pct = (100 * S.gg.cov).toFixed(0); p.kpc = q.kpc = fvGgLabKpc(); }        // (encargo GG) el tooltip de la geometria ajustada
   var key = S.gg ? "gal.gg.tip" : "gal.d.tip", en = fvTx(key, p, "en"), es = fvTx(key, q, "es");
   if (S.gg && fvGalGf2()) { var sat = { sat: fvNum(FV_GAL_GF2.SAT, 1, "en") }, sat2 = { sat: fvNum(FV_GAL_GF2.SAT, 1, "es") }; var tk = (fvGalGf3() && typeof fvGf9On === "function" && fvGf9On()) ? "gal.gf9.tip" : (fvGalGf3() && typeof fvGf8On === "function" && fvGf8On()) ? "gal.gf8.tip" : (fvGalGf3() && typeof fvGf7On === "function" && fvGf7On()) ? "gal.gf7.tip" : (fvGalGf3() && typeof fvGf6On === "function" && fvGf6On()) ? "gal.gf6.tip" : (fvGalGf3() && typeof fvGf5On === "function" && fvGf5On()) ? "gal.gf5.tip" : (fvGalGf3() && typeof fvGf4On === "function" && fvGf4On()) ? "gal.gf4.tip" : (fvGalGf3() ? "gal.gf3.tip" : "gal.gf2.tip"); en += "<br>" + fvTx(tk, sat, "en"); es += "<br>" + fvTx(tk, sat2, "es"); }   // (encargo GF2; GF3: su texto)
   return "<html>" + (FV_LANG === "es" ? es + "<br><i>" + en + "</i>" : en + "<br><i>" + es + "</i>") + "</html>";
}
// antes de los rotulos del Sol y del campo: la linea c = 0,5 (fina, tenue) y el rotulo del lado lejano tras el bulbo
function fvGalDataOverlayPre(g, D, cam, aA) {
   var S = FV_GAL_DATA_ST, W = D.VW, H = D.VH, k = fvHudK(W), gold = 0xE5B53F, brass = 0xC9A35A, R0 = FV_GAL3.R0, zs = FV_GAL3.ZSUN, sg = S.seg;
   var aE = fvGal3Smooth((Math.abs(cam.fw[2]) - 0.18) / 0.25);           // de canto, las dos cosas del plano se apagan (como los rotulos de los brazos)
   if (aE <= 0.01) return;
   if (S.gg) return fvGgOverlayPre(g, D, cam, aA, aE);                  // (encargo GG) la linea u = 0,5 y su rotulo, sin pisar rotulos
   g.pen = new Pen(fvGalArgb(0.42 * aA * aE, gold), 0.9 * k);
   for (var i = 0; i + 3 < sg.length; i += 4) {
      var a = fvGal3Project(cam, [sg[i] + R0, sg[i + 1], fvGalDataWarp(sg[i], sg[i + 1]) - zs]), b = fvGal3Project(cam, [sg[i + 2] + R0, sg[i + 3], fvGalDataWarp(sg[i + 2], sg[i + 3]) - zs]);
      if (a && b) g.drawLine(a[0], a[1], b[0], b[1]);
   }
   var pf = fvGal3Project(cam, [S.far[0] + R0, S.far[1], -zs]);
   if (pf && pf[0] > -0.5 * W && pf[0] < 1.5 * W && pf[1] > -0.5 * H && pf[1] < 1.5 * H) {
      pf = [Math.max(170 * k, Math.min(W - 170 * k, pf[0])), Math.max(40 * k, Math.min(H - 110 * k, pf[1]))];   // dentro del cuadro (de cara caia por encima del borde)
      var f = cpFont("display", 13 * k, false, true, 0), l1 = fvTx("gal.d.far1"), l2 = fvTx("gal.d.far2");
      g.font = f;
      [[l1, 0], [l2, 16 * k]].forEach(function(t) { var w = f.width(t[0]); g.pen = new Pen(fvGalArgb(0.8 * aA * aE, 0x0A0806), 1); g.drawText(pf[0] - w / 2 + 1, pf[1] + t[1] + 1, t[0]); g.pen = new Pen(fvGalArgb(0.8 * aA * aE, brass), 1); g.drawText(pf[0] - w / 2, pf[1] + t[1], t[0]); });
   }
}
// (encargo GG) la linea u = 0,5 (donde la posicion de los brazos deja de estar medida) y su rotulo «posicion de los brazos extrapolada (±N kpc)».
// Nino: la linea de GP era irregular y PISABA los rotulos. Aqui: la linea es un contorno suave de u (fv_galgeom.js) y no se dibuja dentro de las
// cajas de los rotulos de los brazos, del Sol ni del centro; el rotulo busca, entre varios sitios cerca de su ancla (lo mas extrapolado tras el
// bulbo), el que menos segmentos de la linea cruza y no pisa otro rotulo.
function fvGgLabKpc() { var F = (typeof fvGgFit === "function") ? fvGgFit() : null; return (F && F.loo && F.loo.labKpc > 0) ? String(F.loo.labKpc) : "2"; }
function fvGgLabelBoxes(cam, W, H, k) {
   var B = [], A = FV_GAL3.ARMS, fS = cpFont("display", 13 * k, false, true, 0), R0 = FV_GAL3.R0, GF2 = fvGalGf2();   // la de los rotulos de los brazos
   for (var j = 0; j < A.length; ++j) { if (!A[j].lab) continue; var q = fvGalArmLabPt(fvGgArmPoint(A[j].id, (typeof fvGf3LabBeta === "function") ? fvGf3LabBeta(A[j]) : A[j].lb), GF2, A[j].id); if (!q) continue; var pa = fvGal3Project(cam, [q[0] + R0, q[1], 0]); if (!pa) continue;
      var w = fS.width(fvTx(A[j].lab)); B.push([pa[0] - w / 2 - 6 * k, pa[1] - 14 * k, pa[0] + w / 2 + 6 * k, pa[1] + 5 * k]); }
   var pS = fvGal3Project(cam, [0, 0, 0]), sx = GF2 ? 44 : 70, sy = GF2 ? 20 : 24; if (pS) B.push([pS[0] - sx * k, pS[1] - sy * k, pS[0] + sx * k, pS[1] + sy * k]);   // (encargo GF2) caja del Sol mas justa: la linea no se corta tan lejos de el
   var pC = fvGal3Project(cam, [R0, 0, 0]);
   if (pC && fvGalGf3()) { var gp = fvGalGcPlace(cam, pC, k, 13 * k); B.push([gp.x - 80 * k, gp.y - 16 * k, gp.x + 80 * k, gp.y + 8 * k]); }   // (encargo GF3) donde va de verdad
   else if (pC) B.push([pC[0] - 80 * k, pC[1] - 50 * k, pC[0] + 80 * k, pC[1] - 26 * k]);
   return B;
}
function fvGgOverlayPre(g, D, cam, aA, aE) {
   var S = FV_GAL_DATA_ST, GG = S.gg, W = D.VW, H = D.VH, k = fvHudK(W), gold = 0xE5B53F, brass = 0xC9A35A, R0 = FV_GAL3.R0, zs = FV_GAL3.ZSUN, sg = GG.seg, i, q;
   var boxes = fvGgLabelBoxes(cam, W, H, k), P = [], PA = [], GF2 = fvGalGf2();
   function inBox(x, y) { for (var m = 0; m < boxes.length; ++m) { var b = boxes[m]; if (x >= b[0] && x <= b[2] && y >= b[1] && y <= b[3]) return true; } return false; }
   for (i = 0; i + 3 < sg.length; i += 4) {
      // (encargo GF2) no cruza bulbo ni barra: se apaga suave entre 6 y 4,5 kpc del centro (cortada en seco dejaba dos cabos sueltos)
      var wg = 1; if (GF2) { var mxg = 0.5 * (sg[i] + sg[i + 2]), myg = 0.5 * (sg[i + 1] + sg[i + 3]); wg = fvGal3Smooth((Math.sqrt(mxg * mxg + myg * myg) - 4.5) / 1.5); if (wg < 0.02) continue; }
      var a = fvGal3Project(cam, [sg[i] + R0, sg[i + 1], fvGalDataWarp(sg[i], sg[i + 1]) - zs]), b = fvGal3Project(cam, [sg[i + 2] + R0, sg[i + 3], fvGalDataWarp(sg[i + 2], sg[i + 3]) - zs]);
      if (a && b) { P.push(a[0], a[1], b[0], b[1]); PA.push(wg); }
   }
   // el rotulo: el sitio (de 9 cerca del ancla) que menos linea cruza y no pisa otros rotulos; su caja se suma a las que la linea evita
   var f = cpFont("display", 13.5 * k, false, false, 0), l1 = fvTx("gal.gg.far1", { kpc: fvGgLabKpc() }), l2 = fvTx("gal.gg.far2"), lw = Math.max(f.width(l1), f.width(l2)), lab = null;
   var fx = GG.far[0], fy = GG.far[1];
   if (GF2) { var fr0 = Math.sqrt(fx * fx + fy * fy), fk = Math.max(fr0, 18.5) / Math.max(fr0, 1e-6); fx *= fk; fy *= fk; }   // (encargo GF2) el ancla, fuera del disco: no tapa brazos
   var pf = fvGal3Project(cam, [fx + R0, fy, -zs]);
   if (pf && pf[0] > -0.5 * W && pf[0] < 1.5 * W && pf[1] > -0.5 * H && pf[1] < 1.5 * H) {
      var best = Infinity, cand = [[0, 0], [0, -40], [0, 40], [-90, 0], [90, 0], [-90, -40], [90, -40], [-90, 40], [90, 40]], GF3n = fvGalGf3();
      if (GF3n) cand = cand.concat([[0, -90], [0, -140], [-180, -90], [180, -90], [-180, 0], [180, 0], [-180, 90], [180, 90], [0, 90], [0, 140]]);   // (encargo GF3) mas sitios
      for (q = 0; q < cand.length; ++q) {
         var cx = Math.max(lw / 2 + 12 * k, Math.min(W - lw / 2 - 12 * k, pf[0] + cand[q][0] * k)), cy = Math.max(40 * k, Math.min(H - 110 * k, pf[1] + cand[q][1] * k));
         var bx = [cx - lw / 2 - 4 * k, cy - 14 * k, cx + lw / 2 + 4 * k, cy + 22 * k], n = 0;
         // (encargo GF3) que no pise el disco: 5 × 3 puntos de la caja, cada uno que cae en el plano a R < 16 kpc cuenta 8 (con GF2 tapaba el brazo exterior)
         if (GF3n) for (var gy = 0; gy < 3; ++gy) for (var gx = 0; gx < 5; ++gx) if (fvGalPlaneR(cam, bx[0] + (bx[2] - bx[0]) * gx / 4, bx[1] + (bx[3] - bx[1]) * gy / 2) < 16) n += 8;
         for (i = 0; i + 3 < P.length; i += 4) { var mx = 0.5 * (P[i] + P[i + 2]), my = 0.5 * (P[i + 1] + P[i + 3]); if (mx >= bx[0] && mx <= bx[2] && my >= bx[1] && my <= bx[3]) ++n; }
         for (var m = 0; m < boxes.length; ++m) { var o = boxes[m], ox = Math.min(bx[2], o[2]) - Math.max(bx[0], o[0]), oy = Math.min(bx[3], o[3]) - Math.max(bx[1], o[1]); if (ox > 0 && oy > 0) n += 50; }
         n += 0.02 * Math.abs(cand[q][0]) + 0.02 * Math.abs(cand[q][1]);
         if (n < best) { best = n; lab = [cx, cy, bx]; }
      }
      boxes.push(lab[2]);
   }
   g.pen = new Pen(fvGalArgb((GF2 ? 0.30 : 0.42) * aA * aE, gold), (GF2 ? 0.8 : 0.9) * k);
   for (i = 0; i + 3 < P.length; i += 4) { if (inBox(0.5 * (P[i] + P[i + 2]), 0.5 * (P[i + 1] + P[i + 3]))) continue; if (GF2) g.pen = new Pen(fvGalArgb(0.30 * PA[i >> 2] * aA * aE, gold), 0.8 * k); g.drawLine(P[i], P[i + 1], P[i + 2], P[i + 3]); }
   if (lab) {
      // (encargo GF) en la vista oblicua el rotulo se leia mal (13 px en cursiva, sobre brazos y estrellas): ahora lleva una placa oscura detras, no es cursiva y va mas clara
      var fr = cpFont("display", 13.5 * k, false, false, 0), bx0 = lab[2];
      if (GF2) { [[l1, 0], [l2, 16 * k]].forEach(function(t) { fvGalHaloText(g, fr, lab[0], lab[1] + t[1], t[0], 0xE9D6A2, 0.95 * aA * aE, true); }); GG.labBox = lab[2]; return; }   // (encargo GF2) sin placa: fuera del disco basta el halo
      g.pen = new Pen(0x00000000, 1); g.brush = new Brush(fvGalArgb(0.62 * aA * aE, 0x0A0806)); g.drawRect(bx0[0] - 3 * k, bx0[1] - 1 * k, bx0[2] + 3 * k, bx0[3] + 2 * k); g.brush = new Brush(0x00000000);
      g.font = fr;
      [[l1, 0], [l2, 16 * k]].forEach(function(t) { var w = fr.width(t[0]); g.pen = new Pen(fvGalArgb(0.9 * aA * aE, 0x0A0806), 1); g.drawText(lab[0] - w / 2 + 1, lab[1] + t[1] + 1, t[0]); g.pen = new Pen(fvGalArgb(0.97 * aA * aE, 0xE9D6A2), 1); g.drawText(lab[0] - w / 2, lab[1] + t[1], t[0]); });
   }
   GG.labBox = lab ? lab[2] : null;
}
// la linea de pie (fuentes y % medido), la leyenda de los puntos y el chip «SOLO DATOS»
function fvGalDataFooter(g, D, cam, aA, text, fT, fS) {
   var S = FV_GAL_DATA_ST, G = D.gal, W = D.VW, H = D.VH, k = fvHudK(W), gold = 0xE5B53F, ivory = 0xF4ECDC, brass = 0xC9A35A, A = FV_GAL_DATA;
   var note = S.gg ? fvTx("gal.gg.note", { pct: (100 * S.gg.cov).toFixed(0) }) : fvTx("gal.d.note", { pct: (100 * S.cov).toFixed(0) });   // (encargo GG)
   text(fS, 30 * k, H - 30 * k, note, brass, 0.8 * aA, false);
   // la leyenda: punto dorado = maseres, rosa = HII, azul = nubes (esta, solo en «solo datos»: en la vista mezclada las nubes son la forma)
   var items = [], x = 30 * k, y = H - 72 * k, np = (S.pts || {});                  // (11-nov) solo los tipos que hay en el extracto (el paquete lleva las nubes)
   if (np.M && np.M.length) items.push([A.PT_M.col, "gal.d.legM"]);
   if (np.H && np.H.length) items.push([A.PT_H.col, "gal.d.legH"]);
   if (A.SOLO) items.push([A.PT_C.col, "gal.d.legC"]);
   if (fvGalGf2() && !A.SOLO && !FV_GAL_GF2.PTS) items = [];              // (encargo GF2) sin puntos en la vista principal, sin su leyenda
   g.font = fS;
   for (var i = 0; i < items.length; ++i) {
      var c = items[i][0], rgb = (Math.round(255 * Math.min(1, c[0])) << 16) | (Math.round(255 * Math.min(1, c[1])) << 8) | Math.round(255 * Math.min(1, c[2])), lb = fvTx(items[i][1]);
      g.pen = new Pen(fvGalArgb(0.9 * aA, rgb), 1); g.brush = new Brush(fvGalArgb(0.9 * aA, rgb)); g.drawCircle(x + 3 * k, y - 4 * k, 2.6 * k); g.brush = new Brush(0x00000000);
      text(fS, x + 10 * k, y, lb, ivory, 0.75 * aA, false); x += 10 * k + fS.width(lb) + 18 * k;
   }
   // el chip, a la derecha del titulo
   var lab = fvTx("gal.d.solo"), cx0 = 30 * k + fT.width(fvTx("gal.title")) + 22 * k, cy0 = H - 50 * k - 13 * k, bw = 16 * k + fS.width(lab) + 10 * k, bh = 18 * k;
   g.pen = new Pen(fvGalArgb(0.75 * aA, gold), 1 * k); g.brush = new Brush(fvGalArgb((A.SOLO ? 0.28 : 0.10) * aA, gold)); g.drawRect(cx0, cy0, cx0 + bw, cy0 + bh); g.brush = new Brush(0x00000000);
   g.pen = new Pen(fvGalArgb(0.9 * aA, gold), 1 * k); g.drawRect(cx0 + 5 * k, cy0 + 5 * k, cx0 + 13 * k, cy0 + 13 * k);
   if (A.SOLO) { g.brush = new Brush(fvGalArgb(0.95 * aA, gold)); g.drawRect(cx0 + 7 * k, cy0 + 7 * k, cx0 + 11 * k, cy0 + 11 * k); g.brush = new Brush(0x00000000); }
   text(fS, cx0 + 17 * k, cy0 + 13.5 * k, lab, A.SOLO ? ivory : gold, aA, false);
   G.dChip = [cx0, cy0, cx0 + bw, cy0 + bh];
   G.dFoot = [20 * k, H - 86 * k, 30 * k + Math.max(fS.width(note), x - 30 * k), H - 22 * k];
}
