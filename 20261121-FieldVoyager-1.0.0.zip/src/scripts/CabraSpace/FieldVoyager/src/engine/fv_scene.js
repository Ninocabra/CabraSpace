// ============================================================================
// FieldVoyager/src/engine/fv_scene.js — LA ESCENA 3D (pura, serializable a JSON) (3-nov-2026, F1)
// ----------------------------------------------------------------------------
// D1: PixInsight calcula UNA escena y la leen dos pintores (el de PJSR ahora; el visor WebGL despues). Aqui solo hay datos
// y cuentas, sin PixInsight. Unidad: AÑO LUZ. Ejes: los de fv_math.js (Tierra en el origen, +Z al centro de la foto,
// +X derecha y +Y abajo de la foto).
//
// LA FOTO ES LA VISTA DESDE LA TIERRA. Cada pixel (x, y) de la foto es la direccion ((x − W/2)/F, (y − H/2)/F, 1), con F la
// focal en pixeles (1 / escala en radianes por pixel). Cada estrella va en la direccion de SU pixel (el que da la solucion
// astrometrica, distorsion incluida) a su distancia: desde la Tierra cae exactamente donde esta en la foto, sea cual sea la
// distancia. Las capas de nebulosa son planos perpendiculares a +Z a la distancia del objeto, del tamaño justo para que
// desde la Tierra cubran la foto entera.
//
// scene = {
//   version, field: { ra, dec, width, height, scaleArcsec, F, epochKnown },
//   stars: { n, x, y, z (Float64Array, años luz), g (Float32Array, magnitud G), dEarth (Float32Array, años luz),
//            col (Uint32Array 0xRRGGBB), colSrc (Uint8Array: 1 foto, 2 Gaia BP−RP, 3 sin color → blanco),
//            q (Uint8Array: 0 medida, 1 dudosa —RUWE ≥ 1,4 o paralaje de tramo bajo—, 2 supuesta —sin paralaje de fiar—),
//            inFrame (Uint8Array), meta: [{ ra, dec, bpRp, plx, distPc, lo, hi, src, teff, teffSrc, ruwe, cluster, source_id }] },
//   nebula: null | { id, name, distLy, distLoLy, distHiLy, measured, distRef, sizeArcmin, thickLy, relief: "invented",
//                    layers: [{ z, band, x0, y0, x1, y1 (esquinas en el mundo, a profundidad z) }], center, normal, half,
//                    volume: (D9) hueco para el volumen 3D del visor WebGL — no se construye en F1 },
//   notes: [ texto de lo supuesto ]
// }
// ES5.
// ============================================================================

var FV_SCENE_VERSION = 1;
var FV_ARCSEC = Math.PI / (180 * 3600);

function fvSceneNew(field) {
   var F = 1 / (field.scaleArcsec * FV_ARCSEC);
   return { version: FV_SCENE_VERSION,
            field: { ra: field.ra, dec: field.dec, width: field.width, height: field.height, scaleArcsec: field.scaleArcsec, F: F, epochKnown: !!field.epochKnown },
            stars: null, nebula: null, notes: [] };
}
// la direccion (sin normalizar, z = 1) del pixel (x, y) de la foto
function fvPixelRay(scene, x, y) { var f = scene.field; return [(x - f.width / 2) / f.F, (y - f.height / 2) / f.F, 1]; }
// el punto del mundo a la distancia d (años luz, a lo largo del rayo) que se ve en el pixel (x, y)
function fvPixelPoint(scene, x, y, d) { var r = fvNorm(fvPixelRay(scene, x, y)); return [r[0] * d, r[1] * d, r[2] * d]; }

// list: [{ x, y (pixel de la foto) | dir (direccion en el mundo, para el cielo de fuera de la foto), g, dLy, q, col, colSrc, meta, inFrame }]
function fvSceneSetStars(scene, list) {
   var n = list.length, S = { n: n, x: new Float64Array(n), y: new Float64Array(n), z: new Float64Array(n), g: new Float32Array(n), dEarth: new Float32Array(n),
                              col: new Uint32Array(n), colSrc: new Uint8Array(n), q: new Uint8Array(n), inFrame: new Uint8Array(n), meta: [],
                              // (F4b) el color SIN polvo, la celda de polvo de la estrella (-1 sin mapa) y el E del mapa hasta ella (fv_dust.js)
                              colTrue: new Uint32Array(n), dustCell: new Int16Array(n), eStar: new Float32Array(n),
                              // (B1, 5-nov) STELLAE «GAIA»: el color de la TEMPERATURA (colG, como se ve desde casa) y el de la temperatura SIN polvo (colGT)
                              colG: new Uint32Array(n), colGT: new Uint32Array(n) };
   for (var i = 0; i < n; ++i) {
      var s = list[i], p = s.dir ? fvMul(fvNorm(s.dir), s.dLy) : fvPixelPoint(scene, s.x, s.y, s.dLy);
      S.x[i] = p[0]; S.y[i] = p[1]; S.z[i] = p[2]; S.g[i] = s.g; S.dEarth[i] = s.dLy;
      S.col[i] = s.col >>> 0; S.colSrc[i] = s.colSrc || 0; S.q[i] = s.q || 0; S.inFrame[i] = s.inFrame ? 1 : 0;
      S.colTrue[i] = (s.colTrue !== undefined ? s.colTrue : s.col) >>> 0; S.dustCell[i] = (s.dustCell !== undefined) ? s.dustCell : -1; S.eStar[i] = s.eStar || 0;
      S.colG[i] = (s.colG !== undefined ? s.colG : s.col) >>> 0; S.colGT[i] = (s.colGT !== undefined ? s.colGT : S.colG[i]) >>> 0;
      S.meta.push(s.meta || {});
   }
   scene.stars = S;
   return S;
}
// (5-nov, AETAS) con la maquina del tiempo la estrella esta donde la pone fvTimeStars (fv_time.js): la ficha, el heroe, los mapas y el
// esquive la siguen; hoy (o sin fv_time.js) es scene.stars, identico a antes. Prueba: S4 de tests/fv_nI4_time_node.js.
function fvStarPos(scene, i) {
   var S = (typeof fvTimeStars === "function") ? fvTimeStars(scene) : scene.stars;
   if (!S || !(i < S.n)) S = scene.stars;
   return [S.x[i], S.y[i], S.z[i]];
}

// La nebulosa: K capas entre distLy − thick/2 y distLy + thick/2; la capa k lleva la banda k (0 = la mas cercana).
function fvSceneSetNebula(scene, neb, K) {
   var f = scene.field, layers = [], d0 = neb.distLy, th = neb.thickLy;
   for (var k = 0; k < K; ++k) {
      var u = (K > 1) ? k / (K - 1) : 0.5, z = d0 - th / 2 + th * u;
      // las esquinas del plano z que desde la Tierra cubren la foto: (x − W/2)/F · z
      layers.push({ z: z, band: k, x0: (-f.width / 2) / f.F * z, y0: (-f.height / 2) / f.F * z, x1: (f.width / 2) / f.F * z, y1: (f.height / 2) / f.F * z });
   }
   scene.nebula = { id: neb.id, name: neb.name, distLy: d0, distLoLy: neb.distLoLy, distHiLy: neb.distHiLy, measured: !!neb.measured, distRef: neb.distRef || "",
                    sizeArcmin: neb.sizeArcmin, thickLy: th, thickWhy: neb.thickWhy || "", relief: "invented", engine: neb.engine || "", layers: layers,
                    // geometria explicita (D9): centro, normal de las capas (mira a la Tierra) y semiejes; el visor WebGL podra cambiar la
                    // orientacion sin rehacer los datos
                    center: [0, 0, d0], normal: [0, 0, 1], half: [(f.width / 2) / f.F * d0, (f.height / 2) / f.F * d0, th / 2],
                    // D9 (3-nov): en Chrome/Edge la nebulosa sera un VOLUMEN (raymarching de una textura 3D de 128³–256³) derivado de estas capas y
                    // mascaras; se exportara en el paquete de escena. En F1 NO se construye: queda el hueco.
                    volume: { status: "not built (D9: GPU volume in the WebGL viewer)", res: null, file: null } };
   return scene.nebula;
}

// El color de una estrella a partir de BP−RP (tabla propia, aproximada, SIN corregir el enrojecimiento): para las que la foto no da.
var FV_BPRP_COL = [[-0.4, 160, 185, 255], [0.0, 200, 215, 255], [0.4, 240, 242, 255], [0.8, 255, 240, 222], [1.2, 255, 218, 175], [1.8, 255, 190, 128], [2.6, 255, 160, 92], [3.6, 255, 138, 70]];
function fvColorFromBpRp(c) {
   if (c === null || !isFinite(c)) return 0xFFFFFF;
   var T = FV_BPRP_COL;
   if (c <= T[0][0]) return (T[0][1] << 16) | (T[0][2] << 8) | T[0][3];
   for (var i = 1; i < T.length; ++i) if (c <= T[i][0]) {
      var u = (c - T[i - 1][0]) / (T[i][0] - T[i - 1][0]);
      return (Math.round(fvMix(T[i - 1][1], T[i][1], u)) << 16) | (Math.round(fvMix(T[i - 1][2], T[i][2], u)) << 8) | Math.round(fvMix(T[i - 1][3], T[i][3], u));
   }
   var L = T[T.length - 1]; return (L[1] << 16) | (L[2] << 8) | L[3];
}
// Teff aproximada desde BP−RP (enana de la secuencia principal, SIN enrojecimiento: con polvo delante sale MAS FRIA de lo que es).
// Puntos de la secuencia de Mamajek 2022.04 (Bp−Rp de DR2) leidos de CabraShared/data/main_sequence.csv el 3-nov-2026.
var FV_BPRP_TEFF = [[-0.12, 10700], [0.068, 8800], [0.222, 7910], [0.377, 7220], [0.546, 6670], [0.803, 5860], [0.95, 5380], [1.21, 4830], [1.7, 4100], [2.39, 3470], [3.16, 3110], [4.5, 2740]];
function fvTeffFromBpRp(c) {
   if (c === null || !isFinite(c)) return null;
   var T = FV_BPRP_TEFF;
   if (c <= T[0][0]) return T[0][1];
   for (var i = 1; i < T.length; ++i) if (c <= T[i][0]) { var u = (c - T[i - 1][0]) / (T[i][0] - T[i - 1][0]); return Math.round(fvMix(T[i - 1][1], T[i][1], u) / 10) * 10; }
   return T[T.length - 1][1];
}
// ---------------------------------------------------------------------------
// (F2, 4-nov-2026) LA DISTANCIA SUPUESTA de una estrella SIN paralaje de fiar. En F1 iban todas a 0,5–1,5 × la distancia de la
// nebulosa: al llegar a una estrella de la nebulosa se veia una «bola» de miles de estrellas a la misma distancia (f1_llegada.png).
// Ahora cada una se SORTEA a lo largo de su visual con la probabilidad de un modelo sencillo de la Galaxia (TODO SUPUESTO, dicho
// en pantalla):  p(d | G) ∝ d² · ρ(d) · φ(M_G(d)),  con
//   ρ  disco fino + disco grueso exponenciales: R0 8,2 kpc, z☉ 25 pc, h_R 2,6 kpc, h_z 300 pc; grueso 4 % local, h_R 2,0, h_z 900 pc
//      (valores de Bland-Hawthorn & Gerhard 2016, ARA&A 54, 529, escritos de memoria: NO VERIFICADO en el articulo);
//   φ  la magnitud absoluta de una estrella de campo cualquiera ~ Normal(3,5; 2,0) en G (ELECCION NUESTRA: centra las enanas F-G y
//      deja sitio a gigantes y enanas K; no es una funcion de luminosidad medida);
//   M_G = G − 5·log10(d/10 pc) − A_G(d), A_G = 0,79·A_V y A_V = 1 mag/kpc en el plano, con el polvo en una capa de 100 pc
//      (la regla clasica de ~1 mag/kpc; 0,79 = A_G/A_V de Wang & Chen 2019, de memoria: NO VERIFICADO).
// Rejilla de 120 distancias de 50 pc a 25 kpc en logaritmo; u ∈ [0, 1) es el cuantil (sorteado con semilla: la escena es repetible).
// -> años luz
// ---------------------------------------------------------------------------
var FV_GALMOD = { R0: 8.2, ZSUN: 0.025, HR: 2.6, HZ: 0.3, FTHICK: 0.04, HRT: 2.0, HZT: 0.9, AV_KPC: 1.0, HDUST: 0.1, AG_AV: 0.79,
                  MU_M: 3.5, SIG_M: 2.0, DMIN: 0.05, DMAX: 25, N: 120 };
// (nF2) la tabla del modelo (rejilla y probabilidad acumulada) aparte, para poder TRUNCARLA (fvAssumedCapLy); fvAssumedDistLy da lo mismo
// que antes (misma rejilla, mismas cuentas)
function fvAssumedCdf(l, b, g) {
   var M = FV_GALMOD, lr = l * Math.PI / 180, br = b * Math.PI / 180, cb = Math.cos(br), sb = Math.sin(br), cl = Math.cos(lr), sl = Math.sin(lr);
   var n = M.N, k = Math.log(M.DMAX / M.DMIN) / (n - 1), lp = new Float64Array(n), d = new Float64Array(n), mx = -1e30, i, A = 0, prevD = 0;
   for (i = 0; i < n; ++i) {
      var dk = M.DMIN * Math.exp(k * i), x = M.R0 - dk * cb * cl, y = dk * cb * sl, z = dk * sb + M.ZSUN, R = Math.sqrt(x * x + y * y);
      // polvo: A_V acumulado (trapecio sobre la rejilla) en una capa de semiespesor HDUST
      A += M.AV_KPC * (dk - prevD) * Math.exp(-Math.abs(z) / M.HDUST); prevD = dk;
      var rho = Math.exp(-(R - M.R0) / M.HR - Math.abs(z) / M.HZ) + M.FTHICK * Math.exp(-(R - M.R0) / M.HRT - Math.abs(z) / M.HZT);
      var absG = g - 5 * Math.log(dk * 100) / Math.LN10 - M.AG_AV * A, t = (absG - M.MU_M) / M.SIG_M;
      d[i] = dk; lp[i] = 3 * Math.log(dk) + Math.log(Math.max(1e-300, rho)) - 0.5 * t * t;       // d³: d² del volumen × d de la rejilla en log
      if (lp[i] > mx) mx = lp[i];
   }
   var cdf = new Float64Array(n), s = 0;
   for (i = 0; i < n; ++i) { s += Math.exp(lp[i] - mx); cdf[i] = s; }
   return { n: n, k: k, d: d, cdf: cdf, s: s };
}
// el cuantil u (0…1) -> años luz
function fvAssumedQuantLy(T, u) {
   var n = T.n, d = T.d, cdf = T.cdf, k = T.k, target = fvClamp(u, 0, 0.999999) * T.s, i;
   for (i = 0; i < n; ++i) if (cdf[i] >= target) {
      var c0 = (i > 0) ? cdf[i - 1] : 0, f = (cdf[i] > c0) ? (target - c0) / (cdf[i] - c0) : 0;
      var dd = (i > 0) ? d[i - 1] * Math.exp(k * f) : d[0];
      return dd * 1000 * FV_LY_PER_PC;
   }
   return d[n - 1] * 1000 * FV_LY_PER_PC;
}
// años luz -> el cuantil (la inversa exacta de fvAssumedQuantLy en la misma rejilla)
function fvAssumedCdfAt(T, ly) {
   var n = T.n, d = T.d, cdf = T.cdf, k = T.k, dk = ly / (1000 * FV_LY_PER_PC), i;
   if (dk <= d[0]) return cdf[0] / T.s * 0;
   if (dk >= d[n - 1]) return 1;
   i = Math.min(n - 1, Math.max(1, Math.ceil(Math.log(dk / d[0]) / k)));
   var f = Math.log(dk / d[i - 1]) / k;
   return (cdf[i - 1] + fvClamp(f, 0, 1) * (cdf[i] - cdf[i - 1])) / T.s;
}
function fvAssumedDistLy(l, b, g, u) { return fvAssumedQuantLy(fvAssumedCdf(l, b, g), u); }
// (nF2, 4-nov noche; Nino, E3: «al ir hacia adelante parece que unas estrellas tambien se mueven hacia delante») LA FOTO ES EL FONDO. En
// Collinder 34 / IC 1848 el 85 % de las estrellas de la foto (6 845 de 8 085) no tienen paralaje de fiar y el modelo las sorteaba a lo largo
// de su visual: 6 403 caian DETRAS de la nebulosa (mediana 15 800 a.l., 2,4 veces la nebulosa). Al avanzar, todo lo que esta detras del plano
// de la foto crece menos que la foto: esas estrellas «resbalan hacia dentro» sobre la nebulosa, como si fueran con la nave (medido: el 45 %
// de las estrellas pintadas en el viaje recto, el 100 % de ellas detras y con distancia supuesta; tests/fv_nF2_node.js). Como la distancia es
// SUPUESTA (la foto no dice si estan delante o detras), se sortean del mismo modelo TRUNCADO en el plano de la foto: las que ya caian delante
// no cambian; las de detras se vuelven a sortear delante con la misma ley (cuantil u' = c·(u − c)/(1 − c), c = P(d ≤ dCap)). Las de
// distancia MEDIDA no se tocan (en esta escena, 27 detras). FV_SCENE_TUCK false = ROJO (el modelo sin truncar). -> años luz
var FV_SCENE_TUCK = true;
function fvAssumedCapLy(l, b, g, dOldLy, dCapLy) {
   if (!(dOldLy > dCapLy)) return dOldLy;
   var T = fvAssumedCdf(l, b, g), c = fvAssumedCdfAt(T, dCapLy), u = fvAssumedCdfAt(T, dOldLy);
   if (!(c > 1e-9)) return Math.min(dOldLy, dCapLy);
   var u2 = c * fvClamp((u - c) / Math.max(1e-12, 1 - c), 0, 0.999999);
   return Math.min(dCapLy, fvAssumedQuantLy(T, u2));
}
// recoloca en la escena las estrellas de distancia SUPUESTA (q 2) que caen detras de la nebulosa (una vez: scene.tucked). Necesita la
// nebulosa y meta.ra/dec. -> cuantas se movieron
function fvSceneTuckAssumed(scene) {
   var S = scene ? scene.stars : null, N = scene ? scene.nebula : null;
   if (!FV_SCENE_TUCK || !S || !N || scene.tucked || !(N.distLy > 0) || !S.meta) return 0;
   var dCap = N.distLy, moved = 0;
   for (var i = 0; i < S.n; ++i) {
      if (S.q[i] !== 2 || !(S.dEarth[i] > dCap)) continue;
      var m = S.meta[i]; if (!m || m.ra === undefined || m.ra === null || m.dec === null) continue;
      var gl = fvGalactic(m.ra, m.dec), d1 = fvAssumedCapLy(gl.l, gl.b, S.g[i], S.dEarth[i], dCap), k = d1 / S.dEarth[i];
      if (!(k > 0) || k >= 1) continue;
      S.x[i] *= k; S.y[i] *= k; S.z[i] *= k; S.dEarth[i] = d1; ++moved;
   }
   scene.tucked = { n: moved, capLy: dCap };
   if (scene.notes && moved) scene.notes.push("Assumed star distances truncated at the nebula (" + moved + " stars moved in front of it: the photo is the backdrop)");
   return moved;
}
// (nF2, E3: «se dibujan mas estrellas fuera del campo que hemos adquirido») LA HUELLA DE LA FOTO: el peso (0…1) de la estrella i segun caiga,
// vista desde la Tierra, dentro (1) o fuera del rectangulo de la foto, con una caida de `soft` del medio lado (0 = corte seco). Las del cielo de
// alrededor (anillo, 12°, cielo entero) y las que Gaia trae algo mas alla del marco quedan fuera.
// (nP-2, 5-nov; Nino: «solo las estrellas de la foto») FV_PRINT_IN: la franja suave va HACIA DENTRO del rectangulo y fuera el peso es 0
// (ninguna estrella fuera de la huella de la FOTO). false = la franja hacia fuera de nF2 (ROJO: estrellas un 3 % mas alla del borde)
var FV_PRINT_IN = true;
function fvPrintW(scene, i, soft) {
   var S = scene.stars, f = scene.field, z = S.z[i];
   if (!(z > 0)) return 0;
   var e = Math.max(Math.abs(S.x[i] / z) * 2 * f.F / f.width, Math.abs(S.y[i] / z) * 2 * f.F / f.height) - 1;
   if (FV_PRINT_IN) { if (e >= 0) return 0; return (soft > 0) ? fvSmooth(-e / soft) : 1; }
   if (e <= 0) return 1;
   return (soft > 0) ? 1 - fvSmooth(e / soft) : 0;
}
// (nP-2) coordenadas de la estrella en la foto, por eje, vista desde la Tierra: [|u|, |v|] con 1 = el borde (9 = detras)
function fvPrintUV(scene, i) {
   var S = scene.stars, f = scene.field, z = S.z[i];
   if (!(z > 0)) return [9, 9];
   return [Math.abs(S.x[i] / z) * 2 * f.F / f.width, Math.abs(S.y[i] / z) * 2 * f.F / f.height];
}
// (nP-2) peso de la franja del borde de la foto (bx, by: ancho de la franja en medios lados, por eje): 0 en el borde, 1 hacia dentro
function fvPrintEdgeW(au, av, bx, by) { return fvSmooth((1 - au) / bx) * fvSmooth((1 - av) / by); }

// (nP-2, 5-nov; coordinador: «al alejarse la escena debe parecer la FOTO pequeña, nunca mas brillante que en casa») PRESUPUESTO DE LUZ:
// la luz de estrellas por unidad de AREA DE FOTO en pantalla no pasa de la de casa. Luz = suma de I·alfa·sigma² (fv_look) de las estrellas
// en pantalla (sin las reglas del cono: solo pueden quitar, la estimacion es por exceso -> conservadora). B0 = la misma suma en casa (cache
// en la escena). Solo cuando la foto entera esta delante y ocupa menos que la pantalla (al abrir el campo o alejarse): kA = min(1, B0·area/S).
// FV_BUDGET.ON false = ROJO (sin presupuesto)
// SAFE: la luz se estima con I·sigma² por estrella; frente a los PIXELES reales, al quedar solo las brillantes esa estimacion se queda corta
// (medido el 5-nov en Collinder 34 con SAFE 1: PixInsight 1,09 / 1,17 / 1,23 y web 1,02 / 1,05 / 1,10 a 2, 4 y 8 ×). 0,75 deja el peor en ~0,92
var FV_BUDGET = { ON: true, SAFE: 0.75 };
function fvPolyAreaClip(q, W, H) {
   function clip(pts, inside, cut) { var out = []; for (var k = 0; k < pts.length; ++k) { var a = pts[k], b = pts[(k + 1) % pts.length], ia = inside(a), ib = inside(b); if (ia) out.push(a); if (ia !== ib) out.push(cut(a, b)); } return out; }
   function lx(x0) { return function(a, b) { var t = (x0 - a[0]) / (b[0] - a[0]); return [x0, a[1] + t * (b[1] - a[1])]; }; }
   function ly(y0) { return function(a, b) { var t = (y0 - a[1]) / (b[1] - a[1]); return [a[0] + t * (b[0] - a[0]), y0]; }; }
   var p = q.slice();
   p = clip(p, function(a) { return a[0] >= 0; }, lx(0)); if (!p.length) return 0;
   p = clip(p, function(a) { return a[0] <= W; }, lx(W)); if (!p.length) return 0;
   p = clip(p, function(a) { return a[1] >= 0; }, ly(0)); if (!p.length) return 0;
   p = clip(p, function(a) { return a[1] <= H; }, ly(H)); if (!p.length) return 0;
   var s = 0; for (var k = 0; k < p.length; ++k) { var a = p[k], b = p[(k + 1) % p.length]; s += a[0] * b[1] - b[0] * a[1]; }
   return Math.abs(s) / 2;
}
// la lista de estrellas en pantalla para el presupuesto: magnitud aparente y peso (huella × franja del borde, si edge = { uv, k, bx, by })
function fvStarLightList(scene, pr, camPos, pw, W, H, edge) {
   var S = (typeof fvTimeStars === "function") ? fvTimeStars(scene) : scene.stars, m = [], w = [];
   for (var i = 0; i < S.n; ++i) {
      var wi = pw ? pw[i] : 1; if (wi <= 0.01) continue;
      var p = [S.x[i], S.y[i], S.z[i]], q = pr.project(p); if (!q || q[0] < 0 || q[1] < 0 || q[0] > W || q[1] > H) continue;
      if (edge && edge.k > 0.002) wi *= 1 - edge.k * (1 - fvPrintEdgeW(edge.uv[2 * i], edge.uv[2 * i + 1], edge.bx, edge.by));
      if (wi <= 0.001) continue;
      m.push(fvApparentMag(S.g[i], S.dEarth[i], fvLen(fvSub(p, camPos)))); w.push(wi);
   }
   return { m: m, w: w };
}
// luz de la lista con unos limites: suma de peso · alfa · min(1,6, I) · sigma²
function fvStarLightOf(Lst, lim) {
   var s = 0, fadeOn = (typeof FV_LOOK !== "undefined") && !!FV_LOOK.FADE_ON;
   for (var k = 0; k < Lst.m.length; ++k) {
      var m = Lst.m[k], fa = fadeOn ? fvLookAlpha(m, lim) : (m > lim.magLim + 0.5 ? 0 : 1); if (fa <= 0) continue;
      var L = fvLookParams(fvLookLevel(m, lim)); s += Lst.w[k] * fa * Math.min(1.6, L.I) * L.sigma * L.sigma;
   }
   return s;
}
function fvStarLightSum(scene, pr, camPos, lim, pw, W, H) { return fvStarLightOf(fvStarLightList(scene, pr, camPos, pw, W, H, null), lim); }
// -> { k (factor de alfa que queda, 0…1), lim (los limites con el corte: magLim y fadeLo mas brillantes), dLim (mag), area, vis, S, B0 }
// Primero se suben el limite y el fundido (se apagan las DEBILES; las brillantes conservan su nivel: como una foto reducida, donde solo
// quedan de punto las brillantes) hasta que la luz cabe; si ni con el limite junto a la saturacion cabe, el resto con alfa (k).
function fvStarBudget(scene, cam, homeFov, pr, lim, pw, quad, W, H, edge) {
   // Solo mirando la foto desde fuera: con la camara junto a casa o alejandose (z hasta 0.1 D entero, se apaga hasta 0.4 D); mas cerca las
   // estrellas de delante son 3D de verdad. Y solo con la foto casi entera a la vista (fraccion visible del cuadrilatero de 0.5 a 0.9)
   var r = { k: 1, lim: lim, dLim: 0, area: 1, S: 0, B0: 0 }, wVis = 0, wDep = 1;
   if (!FV_BUDGET.ON || !quad || !(homeFov > 0)) return r;
   var N = scene.nebula;
   if (N && N.distLy > 0) wDep = 1 - fvSmooth((cam.pos[2] / N.distLy - 0.1) / 0.3);
   if (wDep <= 0) return r;
   var aC = fvPolyAreaClip(quad, W, H), aT = 0;
   for (var k = 0; k < quad.length; ++k) { var qa = quad[k], qb = quad[(k + 1) % quad.length]; aT += qa[0] * qb[1] - qb[0] * qa[1]; }
   aT = Math.abs(aT) / 2;
   r.area = aC / (W * H);
   r.vis = (aT > 0) ? aC / aT : 0;
   wVis = wDep * fvSmooth((r.vis - 0.5) / 0.4);
   if (!(r.area < 0.999) || wVis <= 0) return r;
   var limH = fvLookLimits(homeFov, homeFov), key = homeFov + ":" + W + "x" + H + ":" + JSON.stringify(limH) + ":" + (pw ? pw.length : 0) + ":" + FV_PRINT_IN;
   var labS = (cam.B && cam.S && typeof fvLabLevel === "function") ? cam.S : 0; if (labS) key += ":S" + labS;   // (8-nov, LABORATORIO) casa en el espacio de vuelo
   if (!scene._fvB0 || scene._fvB0.key !== key) {
      var cH = { pos: [0, 0, 0], look: [0, 0, 1], fov: homeFov };
      if (labS) { cH.B = fvLabLevel([0, 0, 1], null); cH.S = labS; }
      scene._fvB0 = { key: key, v: fvStarLightSum(scene, fvProjector(cH, W, H), cH.pos, limH, pw, W, H) };
   }
   r.B0 = scene._fvB0.v;
   var Lst = fvStarLightList(scene, pr, cam.pos, pw, W, H, edge), S0 = fvStarLightOf(Lst, lim);
   r.S = S0;
   // SAFE entra con el area (en casa 1: sin salto al empezar a abrir el campo; del todo con la foto en la mitad de la pantalla o menos)
   var sF = 1 - (1 - (FV_BUDGET.SAFE || 1)) * fvSmooth((1 - r.area) / 0.5), T = S0 - wVis * Math.max(0, S0 - sF * r.B0 * r.area);
   if (!(S0 > T * 1.0001)) return r;
   function limD(d) { return { magLim: lim.magLim - d, satMag: lim.satMag, off: lim.off, fadeLo: ((lim.fadeLo !== undefined) ? lim.fadeLo : lim.magLim) - d, fadeW: lim.fadeW }; }
   var dMax = Math.max(0, lim.magLim - lim.satMag - 0.3), lo = 0, hi = dMax, sHi = fvStarLightOf(Lst, limD(dMax));
   if (sHi > T) { r.dLim = dMax; r.lim = limD(dMax); r.k = T / sHi; return r; }
   for (var it = 0; it < 14; ++it) { var mid = 0.5 * (lo + hi); if (fvStarLightOf(Lst, limD(mid)) > T) lo = mid; else hi = mid; }
   r.dLim = hi; r.lim = limD(hi); r.k = 1;
   return r;
}

// designacion «Gaia DR3 Jhhmmss.s+ddmmss» a partir de la posicion (sin el source_id, que la base local no trae)
function fvDesignation(ra, dec) {
   function p2(v) { return (v < 10 ? "0" : "") + v; }
   var h = ra / 15, hh = Math.floor(h), mm = Math.floor((h - hh) * 60), ss = ((h - hh) * 60 - mm) * 60;
   var sg = dec < 0 ? "-" : "+", a = Math.abs(dec), dd = Math.floor(a), dm = Math.floor((a - dd) * 60), ds = Math.floor(((a - dd) * 60 - dm) * 60);
   var sst = ss.toFixed(1); if (Number(sst) < 10) sst = "0" + sst;
   return "J" + p2(hh) + p2(mm) + sst + sg + p2(dd) + p2(dm) + p2(ds);
}

// EL CIELO DE ALREDEDOR: la rotacion que lleva un vector unitario del cielo (ICRS) a una direccion del mundo, sacada de tres pixeles
// de la foto (centro, a la derecha y abajo) con la solucion astrometrica (unproject: pixel -> {ra, dec}). Con el tercero se
// comprueba la mano (una foto puede venir en espejo). -> function(ra, dec) -> [x, y, z] | null
function fvRaDecVec(ra, dec) { var a = ra * FV_DEG, d = dec * FV_DEG; return [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)]; }
function fvSkyRotation(scene, unproject) {
   var f = scene.field, px = [[f.width / 2, f.height / 2], [f.width * 0.75, f.height / 2], [f.width / 2, f.height * 0.75]], c = [], w = [];
   for (var i = 0; i < 3; ++i) { var q = unproject(px[i][0], px[i][1]); if (!q) return null; c.push(fvRaDecVec(q.ra, q.dec)); w.push(fvNorm(fvPixelRay(scene, px[i][0], px[i][1]))); }
   function frame(a, b) { var e1 = fvNorm(a), e2 = fvNorm(fvSub(b, fvMul(e1, fvDot(b, e1)))); return [e1, e2, fvCross(e1, e2)]; }
   var E = frame(c[0], c[1]), F = frame(w[0], w[1]);
   function mk(F3) { return function(ra, dec) { var x = fvRaDecVec(ra, dec), a = fvDot(x, E[0]), b = fvDot(x, E[1]), cc = fvDot(x, E[2]); return [a * F[0][0] + b * F[1][0] + cc * F3[0], a * F[0][1] + b * F[1][1] + cc * F3[1], a * F[0][2] + b * F[1][2] + cc * F3[2]]; }; }
   var m1 = mk(F[2]), m2 = mk(fvMul(F[2], -1)), q2 = unproject(px[2][0], px[2][1]);
   var e1 = fvLen(fvSub(m1(q2.ra, q2.dec), w[2])), e2 = fvLen(fvSub(m2(q2.ra, q2.dec), w[2]));
   var M = (e1 <= e2) ? m1 : m2;
   M.err = Math.min(e1, e2); M.mirrored = (e1 > e2);
   return M;
}

// ---------------------------------------------------------------------------
// A JSON (D1: el paquete de escena que leera el visor WebGL). Las capas de nebulosa van aparte como PNG (`files`).
// ---------------------------------------------------------------------------
function fvSceneToJSON(scene, files) {
   var S = scene.stars, st = null;
   if (S) {
      st = { n: S.n, x: [], y: [], z: [], g: [], dEarth: [], col: [], colSrc: [], q: [], inFrame: [] };
      for (var i = 0; i < S.n; ++i) {
         st.x.push(Math.round(S.x[i] * 1e4) / 1e4); st.y.push(Math.round(S.y[i] * 1e4) / 1e4); st.z.push(Math.round(S.z[i] * 1e3) / 1e3);
         st.g.push(Math.round(S.g[i] * 1e3) / 1e3); st.dEarth.push(Math.round(S.dEarth[i] * 10) / 10); st.col.push(S.col[i]); st.colSrc.push(S.colSrc[i]); st.q.push(S.q[i]); st.inFrame.push(S.inFrame[i]);
      }
   }
   var neb = null;
   if (scene.nebula) { neb = JSON.parse(JSON.stringify(scene.nebula)); if (files) for (var k = 0; k < neb.layers.length; ++k) neb.layers[k].file = files[k] || ""; }
   return JSON.stringify({ version: scene.version, units: "light-year", axes: "Earth at origin; +Z to photo centre; +X photo right; +Y photo down",
                           field: scene.field, stars: st, nebula: neb, notes: scene.notes });
}

// ---------------------------------------------------------------------------
// CONTROLES EN ROJO (pruebas): escenas estropeadas a proposito.
//   "dist": distancias barajadas (desde la Tierra NO se nota, por construccion: cada estrella sigue en su rayo);
//   "dir":  direcciones barajadas (cada estrella al rayo de otra): desde la Tierra SI se nota.
// ---------------------------------------------------------------------------
function fvSceneSpoil(scene, how, seed) {
   var S = scene.stars, R = fvRng(seed || 7), n = S.n, i, j, t, perm = [];
   for (i = 0; i < n; ++i) perm.push(i);
   for (i = n - 1; i > 0; --i) { j = Math.floor(R() * (i + 1)); t = perm[i]; perm[i] = perm[j]; perm[j] = t; }
   var X = Float64Array.from(S.x), Y = Float64Array.from(S.y), Z = Float64Array.from(S.z), D = Float32Array.from(S.dEarth);
   for (i = 0; i < n; ++i) {
      var p = perm[i];
      if (how === "dist") { var k = D[p] / D[i]; S.x[i] = X[i] * k; S.y[i] = Y[i] * k; S.z[i] = Z[i] * k; S.dEarth[i] = D[p]; }
      else if (how === "dir") { var k2 = D[i] / D[p]; S.x[i] = X[p] * k2; S.y[i] = Y[p] * k2; S.z[i] = Z[p] * k2; }
   }
   return scene;
}
