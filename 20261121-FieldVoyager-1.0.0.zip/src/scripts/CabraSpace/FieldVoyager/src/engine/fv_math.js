// ============================================================================
// FieldVoyager/src/engine/fv_math.js — MATEMATICA PURA DEL MOTOR (3-nov-2026, F1)
// ----------------------------------------------------------------------------
// Vectores 3D (arrays [x, y, z]), base de camara, homografia de 4 puntos, Catmull-Rom centripeta, muelle criticamente
// amortiguado, suavizados y PRNG con semilla. Nada de PixInsight: lo podra usar tal cual el visor WebGL (D1).
// Ejes del mundo (unidad: AÑO LUZ): la Tierra en el origen; +Z hacia el centro de la foto; +X hacia la derecha de la foto;
// +Y hacia ABAJO de la foto (como los pixeles). Asi la vista desde la Tierra es la foto sin mas cuentas.
// ES5.
// ============================================================================

function fvV(x, y, z) { return [x, y, z]; }
function fvAdd(a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; }
function fvSub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
function fvMul(a, k) { return [a[0] * k, a[1] * k, a[2] * k]; }
function fvDot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
function fvCross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
function fvLen(a) { return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }
function fvNorm(a) { var l = fvLen(a); return (l > 0) ? [a[0] / l, a[1] / l, a[2] / l] : [0, 0, 1]; }
function fvLerp(a, b, t) { return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
function fvClamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fvSmooth(t) { t = fvClamp(t, 0, 1); return t * t * (3 - 2 * t); }
function fvSmoother(t) { t = fvClamp(t, 0, 1); return t * t * t * (t * (t * 6 - 15) + 10); }
function fvMix(a, b, t) { return a + (b - a) * t; }

// Base de la camara a partir de la direccion de mirada y un «abajo» de referencia (+Y del mundo): balanceo cero.
// -> { f: adelante, r: derecha, d: abajo } (ortonormales; r = d × f para que sea la misma mano que los pixeles)
function fvBasis(fwd, downRef) {
   var f = fvNorm(fwd), dr = downRef || [0, 1, 0];
   var r = fvCross(dr, f);
   if (fvLen(r) < 1e-6) r = fvCross([0, 0, 1], f);
   if (fvLen(r) < 1e-6) r = [1, 0, 0];
   r = fvNorm(r);
   var d = fvNorm(fvCross(f, r));
   return { f: f, r: r, d: d };
}
// direccion desde guiñada (yaw, alrededor de +Y) y cabeceo (pitch): yaw = pitch = 0 mira a +Z
function fvDirYawPitch(yaw, pitch) { var cp = Math.cos(pitch); return [Math.sin(yaw) * cp, -Math.sin(pitch), Math.cos(yaw) * cp]; }
function fvYawPitchOf(dir) { var d = fvNorm(dir); return { yaw: Math.atan2(d[0], d[2]), pitch: Math.asin(fvClamp(-d[1], -1, 1)) }; }
// rotar v alrededor del eje unitario k un angulo a (Rodrigues)
function fvRotate(v, k, a) {
   var c = Math.cos(a), s = Math.sin(a), kv = fvCross(k, v), kd = fvDot(k, v);
   return [v[0] * c + kv[0] * s + k[0] * kd * (1 - c), v[1] * c + kv[1] * s + k[1] * kd * (1 - c), v[2] * c + kv[2] * s + k[2] * kd * (1 - c)];
}
// angulo entre dos direcciones (rad)
function fvAngle(a, b) { return Math.acos(fvClamp(fvDot(fvNorm(a), fvNorm(b)), -1, 1)); }
// interpolacion esferica de direcciones unitarias
function fvSlerpDir(a, b, t) {
   a = fvNorm(a); b = fvNorm(b);
   var w = fvAngle(a, b);
   if (w < 1e-5) return fvNorm(fvLerp(a, b, t));
   // (K9 H-1) direcciones (casi) OPUESTAS: sin(w) ~ 1e-16 amplificaba el residuo y la mirada se invertia de un paso a otro (tras un warp
   // desde casa, «mirar a casa» las deja exactamente opuestas). Se gira por el plano de a y q, con q perpendicular a a: la componente de b
   // perpendicular a a (el camino corto de siempre) y, si b es opuesta del todo, el eje DERECHO de la camara de a. Con r el giro es de
   // GUIÑADA (la mirada horizontal se queda en el horizonte); el «arriba/abajo» de la camara pasaria por el polo y volteria el balanceo.
   if (w > Math.PI - 1e-5) {
      var q = fvSub(b, fvMul(a, fvDot(a, b)));
      q = (fvLen(q) > 1e-8) ? fvNorm(q) : fvBasis(a).r;
      return fvNorm(fvAdd(fvMul(a, Math.cos(t * w)), fvMul(q, Math.sin(t * w))));
   }
   var s = Math.sin(w);
   return fvNorm(fvAdd(fvMul(a, Math.sin((1 - t) * w) / s), fvMul(b, Math.sin(t * w) / s)));
}

// ---------------------------------------------------------------------------
// HOMOGRAFIA: la matriz 3×3 H (fila mayor, h22 = 1) que lleva los 4 puntos src a los 4 dst:  [x' y' w']ᵀ = H [x y 1]ᵀ.
// src, dst: [[x, y] × 4]. -> [h00, h01, h02, h10, h11, h12, h20, h21, h22] o null si es degenerada.
// ---------------------------------------------------------------------------
function fvHomography(src, dst) {
   var A = [], b = [], i, j, k;
   for (i = 0; i < 4; ++i) {
      var x = src[i][0], y = src[i][1], u = dst[i][0], v = dst[i][1];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
   }
   // Gauss con pivote parcial (8 × 8)
   for (i = 0; i < 8; ++i) {
      var p = i, mx = Math.abs(A[i][i]);
      for (k = i + 1; k < 8; ++k) if (Math.abs(A[k][i]) > mx) { mx = Math.abs(A[k][i]); p = k; }
      if (mx < 1e-12) return null;
      if (p !== i) { var tA = A[i]; A[i] = A[p]; A[p] = tA; var tb = b[i]; b[i] = b[p]; b[p] = tb; }
      for (k = i + 1; k < 8; ++k) {
         var f = A[k][i] / A[i][i];
         if (f === 0) continue;
         for (j = i; j < 8; ++j) A[k][j] -= f * A[i][j];
         b[k] -= f * b[i];
      }
   }
   var h = [0, 0, 0, 0, 0, 0, 0, 0];
   for (i = 7; i >= 0; --i) { var s = b[i]; for (j = i + 1; j < 8; ++j) s -= A[i][j] * h[j]; h[i] = s / A[i][i]; }
   return [h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1];
}
function fvHomApply(H, x, y) { var w = H[6] * x + H[7] * y + H[8]; return [(H[0] * x + H[1] * y + H[2]) / w, (H[3] * x + H[4] * y + H[5]) / w]; }

// ---------------------------------------------------------------------------
// CATMULL-ROM CENTRIPETA (alfa = 0,5; Yuksel et al. 2011): sin bucles ni cuspides. pts: [[x,y,z] × n ≥ 2].
// fvSplineMake(pts) -> { pts, at(u) } con u ∈ [0, 1] uniforme EN LONGITUD de arco (tabla de 256 muestras).
// ---------------------------------------------------------------------------
function fvCrPoint(p0, p1, p2, p3, t) {
   function tj(ti, a, b) { var d = fvLen(fvSub(b, a)); return ti + Math.max(1e-9, Math.sqrt(d)); }
   var t0 = 0, t1 = tj(t0, p0, p1), t2 = tj(t1, p1, p2), t3 = tj(t2, p2, p3);
   var tt = t1 + (t2 - t1) * t;
   function L(a, b, ta, tb) { return fvAdd(fvMul(a, (tb - tt) / (tb - ta)), fvMul(b, (tt - ta) / (tb - ta))); }
   var A1 = L(p0, p1, t0, t1), A2 = L(p1, p2, t1, t2), A3 = L(p2, p3, t2, t3);
   var B1 = L(A1, A2, t0, t2), B2 = L(A2, A3, t1, t3);
   return L(B1, B2, t1, t2);
}
function fvSplineMake(pts) {
   var n = pts.length, P = [fvSub(fvMul(pts[0], 2), pts[1])].concat(pts).concat([fvSub(fvMul(pts[n - 1], 2), pts[n - 2])]);
   var segs = n - 1, N = 256, tab = [0], prev = pts[0], acc = 0, raw = [pts[0]];
   function rawAt(u) {
      var s = Math.min(segs - 1, Math.floor(u * segs)), t = u * segs - s;
      return fvCrPoint(P[s], P[s + 1], P[s + 2], P[s + 3], t);
   }
   for (var i = 1; i <= N; ++i) { var q = rawAt(i / N); acc += fvLen(fvSub(q, prev)); tab.push(acc); raw.push(q); prev = q; }
   var total = acc;
   return {
      length: total,
      at: function(u) {
         u = fvClamp(u, 0, 1);
         if (total <= 0) return pts[0].slice();
         var target = u * total, lo = 0, hi = N;
         while (hi - lo > 1) { var m = (lo + hi) >> 1; if (tab[m] < target) lo = m; else hi = m; }
         var f = (tab[hi] > tab[lo]) ? (target - tab[lo]) / (tab[hi] - tab[lo]) : 0;
         return rawAt((lo + f) / N);
      }
   };
}

// ---------------------------------------------------------------------------
// MUELLE CRITICAMENTE AMORTIGUADO (la mirada que persigue al objetivo con la inercia de un operador): estado { x, v }
// por componente; omega = 2π/periodo. Integracion exacta para un paso dt (Kirmse, «Game Programming Gems 4»).
// ---------------------------------------------------------------------------
function fvSpringStep(x, v, target, omega, dt) {
   var e = Math.exp(-omega * dt), d = x - target, tmp = (v + omega * d) * dt;
   return { x: target + (d + tmp) * e, v: (v - omega * tmp) * e };
}
function fvSpringVec(state, target, omega, dt) {        // state = { x: [3], v: [3] }
   for (var i = 0; i < 3; ++i) { var s = fvSpringStep(state.x[i], state.v[i], target[i], omega, dt); state.x[i] = s.x; state.v[i] = s.v; }
   return state;
}

// PRNG determinista (mulberry32)
function fvRng(seed) { var a = seed >>> 0; return function() { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

var FV_LY_PER_PC = 3.26156;

// ---------------------------------------------------------------------------
// (F2, 4-nov-2026) ECUATORIALES J2000 -> GALACTICAS (l, b en grados). Matriz ICRS -> galacticas de la Hipparcos
// Catalogue Vol. 1, §1.5.3 (la de astropy), escrita de memoria: NO VERIFICADO en el PDF; la prueba la comprueba con el
// polo galactico (ra 192,85948°, dec 27,12825° -> b = 90°) y el centro (ra 266,40499°, dec −28,93617° -> l = 0, b = 0).
// ---------------------------------------------------------------------------
var FV_GAL_M = [[-0.0548755604, -0.8734370902, -0.4838350155],
                [ 0.4941094279, -0.4448296300,  0.7469822445],
                [-0.8676661490, -0.1980763734,  0.4559837762]];
function fvGalactic(ra, dec) {
   var a = ra * Math.PI / 180, d = dec * Math.PI / 180, x = [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)], M = FV_GAL_M;
   var gx = M[0][0] * x[0] + M[0][1] * x[1] + M[0][2] * x[2], gy = M[1][0] * x[0] + M[1][1] * x[1] + M[1][2] * x[2], gz = M[2][0] * x[0] + M[2][1] * x[1] + M[2][2] * x[2];
   var l = Math.atan2(gy, gx) * 180 / Math.PI; if (l < 0) l += 360;
   return { l: l, b: Math.asin(fvClamp(gz, -1, 1)) * 180 / Math.PI };
}
