// ============================================================================
// FieldVoyager/src/engine/fv_e1.js — I4 (20-nov-2026): «E1» = ideas de enganche de docs/ideas-enganche-19nov.md (E1-01, E1-12, E1-13, E1-14). PURO.
// ----------------------------------------------------------------------------
// Lo que se calcula aqui lo comparten PixInsight (src/ui/fv_e1_ui.js) y el visor web (web/fw_e1.js); ninguno de los dos lleva sus propias
// cuentas (§11.5: dos caminos a lo mismo es un bug). Sin PixInsight, sin DOM: se prueba en node (tests/_e1q/fv_e1q_node.js).
//
//  E1-01  QUAESTIO, la pregunta del encendido. fvE1qFromRes / fvE1qFromScene -> lista de estrellas; fvE1qPick -> { kind, answerLy, rel, target }.
//         Solo se pregunta lo que tiene calidad MEDIDO (paralaje de Gaia DR3 y distancia de Bailer-Jones 2021: q = 0, RUWE < 1,4, error relativo
//         del intervalo <= MAX_REL) y hay al menos MIN_MEAS estrellas asi en la foto; si no, NO hay pregunta (nunca se inventa).
//         (20-nov) Siete tipos: la mas cercana, brillante, lejana, debil, azul (BP−RP), roja y la del centro de la foto; con FV_E1Q.VARY se SORTEA entre los que caben
//         en la escala sin repetir la ultima (opts.last); sin VARY, como antes: de cercana / brillante / lejana la que MAS SE APARTA de la distancia tipica
//         de la foto (log10 del cociente con la mediana): es la que mas sorprende. Sin nota ni puntos: fvE1qCompare solo da el cociente.
//  E1-12  El balanceo de paralaje: fvE1sPlan (amplitud tal que la estrella del percentil 10 se desplaza SHIFT_FRAC del campo de la foto),
//         fvE1sOffset (ida y vuelta suave, velocidad nula al principio y al final), fvE1sShift (la posicion de la camara desplazada de lado).
//  E1-13  Mirar a casa: fvE1hSun — magnitud aparente del Sol desde donde esta la nave, m = M_V + 5·log10(d_pc) − 5 con M_V = 4,81 (Willmer 2018,
//         ApJS 236, 47: 4,81 en el sistema de Vega; 4,83 es el valor antiguo), y la direccion hacia el Sol. Banda V (la de «a simple vista»).
//  E1-14  Silencio de llegada: fvE1tPlan — solo al llegar a un objeto principal (la nebulosa, la fila principal, el protagonista), nunca a estrellas.
// Banderas de fabrica TRUE; false = lo de antes. ES5.
// ============================================================================

var FV_E1Q = { ON: true,
               MIN_MEAS: 8,          // estrellas MEDIDAS en la foto como minimo para preguntar
               MAX_REL: 0.30,        // semianchura relativa maxima del intervalo de distancia de la estrella que se pregunta (hi − lo) / (2 d)
               LO_LY: 10, HI_LY: 100000,   // la escala logaritmica de la respuesta (años luz)
               FLY: true,            // el boton «IR ALLI» de la revelacion (la pregunta desemboca en el viaje)
               // (20-nov, queja de Nino: «la pregunta es siempre la misma y esta abajo») false = lo de antes (la mas «sorprendente» de cercana / brillante / lejana, siempre la misma)
               VARY: true,           // siete tipos de pregunta y se sortea entre los que caben (sin repetir la ultima: opts.last)
               TOP: true,            // la placa del arranque va ARRIBA de la animacion (false: debajo / sobre su fila de abajo)
               FORCE: "",            // solo pruebas: fuerza el tipo de pregunta (nearest, brightest, farthest, faintest, bluest, reddest, centre)
               HUD_S: 45 };          // segundos que la placa de la respuesta queda en la cabina tras el encendido (el × la quita antes)
var FV_E1S = { ON: true,
               DUR_S: 3.6,           // duracion del balanceo
               SHIFT_FRAC: 0.35,     // la estrella del percentil 10 de distancia se mueve esta fraccion del ancho de la foto
               MED_FRAC: 0.02,       // ...y la de la distancia mediana (con la nebulosa, que suele estar ahi) como mucho esta: casi nada, la foto «queda detras». La amplitud manda el MENOR de los dos topes. (20-nov, H7) 0,04 → 0,02: con EDGE_ON el acercamiento que tapa la franja crece con esta amplitud (con 0,04: ×1,047–1,093 segun la foto) y las estrellas cercanas siguen cruzando cientos de px
               MIN_MEAS: 8, ONCE: true,   // solo la primera vez con cada foto; la tecla Y lo repite
               // (20-nov, H7) EL BORDE DE LA FOTO NO ASOMA: en casa la foto llena el ancho de la pantalla justo (margen izquierdo/derecho 0 px: la foto es mas estrecha que la pantalla de
               // 16:9 y se ajusta por el ancho), asi que CUALQUIER desplazamiento de lado dejaba una franja negra (M 82 en la web, 1 439 px: 21–23 px a un lado; la Rosette en PixInsight, el
               // canto de la foto). Bajar la amplitud no lo arregla (la franja crece con ella y con 0 px de margen solo desaparece con amplitud 0): con EDGE_ON la camara se acerca un
               // poco mientras dura el balanceo (fvE1sZoomK: el campo se estrecha lo justo para que el canto de la foto quede EDGE_PX del ancho FUERA de la pantalla en cada extremo,
               // 0 en casa y suave: el factor sube con el desplazamiento y vuelve a 1). false = lo de antes (la franja)
               EDGE_ON: true, EDGE_PX: 0.004,
               KEY: "Y" };
// (B2, 20-nov, Nino: «hay dos iconos de Home… eliminar uno») BUTTON false = SIN el boton CASA/RETROSPECTIO (catalejo) de la columna derecha: se queda el Home de la izquierda
// (vuelve volando a la Tierra). La tecla U (girar al Sol sin volar + la placa de su brillo) SIGUE como atajo, sin boton; la dice el tooltip de Home. BUTTON true = lo de antes.
var FV_E1H = { ON: true, BUTTON: false,
               MV_SUN: 4.81,         // magnitud absoluta del Sol en V (Willmer 2018, ApJS 236, 47, sistema de Vega: 4,81; AB 4,80). 4,83 es el valor antiguo
               MW_KPC: 30,           // diametro del disco de la Vía Láctea en kpc [S, orden de magnitud: se rotula «≈»]
               MOON_DEG: 0.52,       // diametro aparente medio de la Luna
               KEY: "U" };
var FV_E1Z = { ON: true, DUR_S: 2.0, DUCK: 0.38, LEVEL: 0.18 };

// ---------------------------------------------------------------------------
// TEXTOS (EN primero, ES en paralelo). Las dos lenguas salen de aqui en PixInsight y en la web.
// ---------------------------------------------------------------------------
var FV_E1_TX = {
   en: {
      "q.title": "QUAESTIO",
      "q.nearest": "How far away is the NEAREST star of your photo?",
      "q.brightest": "How far away is the BRIGHTEST star of your photo?",
      "q.farthest": "How far away is the MOST DISTANT star of your photo with a good distance?",
      "q.faintest": "How far away is the FAINTEST star of your photo with a measured distance?",
      "q.bluest": "How far away is the BLUEST star of your photo with a measured distance?",
      "q.reddest": "How far away is the REDDEST star of your photo with a measured distance?",
      "q.centre": "How far away is the star at the CENTRE of your photo?",
      "q.hint": "Click or drag on the scale. Optional: the start-up carries on.",
      "q.set": "Your answer: {v}. Gaia answers when the ship is ready.",
      "q.axisNote": "light years",
      "q.revealTitle": "QUAESTIO · what Gaia measured",
      "q.reveal": "{v} light years (± {r} %)",
      "q.you": "You said {g}: {f}× {side}.",
      "q.close": "You said {g}: almost exactly right.",
      "q.far": "farther", "q.near": "closer",
      "q.none": "You did not answer.",
      "q.fly": "FLY THERE",
      "q.what.nearest": "the nearest measured star of your photo", "q.what.brightest": "the brightest measured star of your photo", "q.what.farthest": "the most distant measured star of your photo",
      "q.what.faintest": "the faintest measured star of your photo", "q.what.bluest": "the bluest measured star of your photo (BP−RP)", "q.what.reddest": "the reddest measured star of your photo (BP−RP)",
      "q.what.centre": "the measured star nearest the centre of your photo",
      "q.tip": "QUAESTIO: a question about YOUR photo, asked while the ship starts up. Optional, with no score: it only shows how far off you were. Only stars with a MEASURED distance count (Gaia DR3 parallax, Bailer-Jones 2021, RUWE < 1.4, error of the interval ≤ {mr} %) and the question only appears if there are enough of them. The answer is revealed when the start-up ends and FLY THERE takes you to that star.",
      "q.tipHud": "The star Gaia measured as {what}. Distance and its margin are Gaia DR3 + Bailer-Jones 2021. FLY THERE travels to it with the current MODUS.",
      "s.needHome": "The parallax sway works from home: press H to go back first.",
      "s.line": "What looked together is spread over {span} light years ({n} measured stars, 5–95 %).",
      "h.label": "SUN · our home", "h.btn": "Home", "h.lab": "HOME",
      "h.mag": "From here the Sun is a star of magnitude {m} (V).",
      "h.eye": "You could see it with the naked eye.", "h.bino": "You would need binoculars.", "h.scope": "You would need a telescope and a dark night.",
      "h.long": "Only a long exposure through a telescope like yours could record it.", "h.vlong": "Not even your longest exposures would reach it.",
      "h.none": "From here the Sun cannot be told apart.",
      "h.mw": "The whole Milky Way (disc ≈ {kpc} kpc) would span about {deg}° of sky; the full Moon is {moon}°.",
      "h.dist": "{d} light years from home",
      "h.tip": "Home: turns the ship toward the Sun from wherever it is and shows how bright the Sun would look from there: m = {mv} + 5·log10(d/10 pc), band V, no dust. The naked-eye, binocular and telescope limits are rule-of-thumb magnitudes (6, 10, 14). Key {key}.",
      "h.athome": "You are at home: the Sun is behind you, in your photo."
   },
   es: {
      "q.title": "QUAESTIO",
      "q.nearest": "¿A qué distancia está la estrella MÁS CERCANA de tu foto?",
      "q.brightest": "¿A qué distancia está la estrella MÁS BRILLANTE de tu foto?",
      "q.farthest": "¿A qué distancia está la estrella MÁS LEJANA de tu foto con distancia fiable?",
      "q.faintest": "¿A qué distancia está la estrella MÁS DÉBIL de tu foto con distancia medida?",
      "q.bluest": "¿A qué distancia está la estrella MÁS AZUL de tu foto con distancia medida?",
      "q.reddest": "¿A qué distancia está la estrella MÁS ROJA de tu foto con distancia medida?",
      "q.centre": "¿A qué distancia está la estrella del CENTRO de tu foto?",
      "q.hint": "Pulsa o arrastra sobre la escala. Opcional: el encendido sigue igual.",
      "q.set": "Tu respuesta: {v}. Gaia contesta cuando la nave esté lista.",
      "q.axisNote": "años luz",
      "q.revealTitle": "QUAESTIO · lo que midió Gaia",
      "q.reveal": "{v} años luz (± {r} %)",
      "q.you": "Dijiste {g}: {f} veces {side}.",
      "q.close": "Dijiste {g}: casi exacto.",
      "q.far": "más lejos", "q.near": "más cerca",
      "q.none": "No contestaste.",
      "q.fly": "IR ALLÍ",
      "q.what.nearest": "la estrella medida más cercana de tu foto", "q.what.brightest": "la estrella medida más brillante de tu foto", "q.what.farthest": "la estrella medida más lejana de tu foto",
      "q.what.faintest": "la estrella medida más débil de tu foto", "q.what.bluest": "la estrella medida más azul de tu foto (BP−RP)", "q.what.reddest": "la estrella medida más roja de tu foto (BP−RP)",
      "q.what.centre": "la estrella medida más cercana al centro de tu foto",
      "q.tip": "QUAESTIO: una pregunta sobre TU foto, mientras la nave se enciende. Opcional y sin nota: solo enseña cuánto te equivocaste. Cuentan solo las estrellas con distancia MEDIDA (paralaje de Gaia DR3, Bailer-Jones 2021, RUWE < 1,4, error del intervalo ≤ {mr} %) y la pregunta solo sale si hay suficientes. La respuesta se revela al acabar el encendido e IR ALLÍ lleva a esa estrella.",
      "q.tipHud": "La estrella que Gaia midió como {what}. La distancia y su margen son de Gaia DR3 + Bailer-Jones 2021. IR ALLÍ viaja hasta ella con el MODUS actual.",
      "s.needHome": "El balanceo de paralaje funciona desde casa: pulsa H para volver antes.",
      "s.line": "Lo que parecía junto está repartido en {span} años luz ({n} estrellas medidas, 5–95 %).",
      "h.label": "SOL · nuestra casa", "h.btn": "Casa", "h.lab": "CASA",
      "h.mag": "Desde aquí el Sol es una estrella de magnitud {m} (V).",
      "h.eye": "Se vería a simple vista.", "h.bino": "Haría falta unos prismáticos.", "h.scope": "Haría falta un telescopio y una noche oscura.",
      "h.long": "Solo una larga exposición con un telescopio como el tuyo lo registraría.", "h.vlong": "Ni tus exposiciones más largas llegarían.",
      "h.none": "Desde aquí el Sol no se distingue.",
      "h.mw": "La Vía Láctea entera (disco ≈ {kpc} kpc) ocuparía unos {deg}° de cielo; la Luna llena, {moon}°.",
      "h.dist": "a {d} años luz de casa",
      "h.tip": "Casa: gira la nave hacia el Sol desde donde esté y enseña cuánto brillaría el Sol visto desde allí: m = {mv} + 5·log10(d/10 pc), banda V, sin polvo. Los límites de simple vista, prismáticos y telescopio son magnitudes de regla de andar por casa (6, 10, 14). Tecla {key}.",
      "h.athome": "Estás en casa: el Sol queda a tu espalda, en tu foto."
   }
};
function fvE1Lang(l) {
   if (l === "es" || l === "en") return l;
   try { if (typeof FW_LANG !== "undefined") return FW_LANG === "es" ? "es" : "en"; } catch (e) {}
   try { if (typeof FV_LANG !== "undefined") return FV_LANG === "es" ? "es" : "en"; } catch (e2) {}
   return "en";
}
function fvE1Tx(key, p, lang) {
   var L = fvE1Lang(lang), s = (FV_E1_TX[L] && FV_E1_TX[L][key] !== undefined) ? FV_E1_TX[L][key] : ((FV_E1_TX.en[key] !== undefined) ? FV_E1_TX.en[key] : key);
   if (p) for (var k in p) if (Object.prototype.hasOwnProperty.call(p, k)) s = s.split("{" + k + "}").join(String(p[k]));
   return s;
}
// numero con el separador de miles del idioma (ES: espacio duro; EN: coma); usa el de src/science si esta
function fvE1Num(x, dec, lang) {
   var L = fvE1Lang(lang);
   if (typeof fvsFmtNum === "function") return fvsFmtNum(x, dec || 0, L);
   var d = Math.max(0, dec | 0), s = Math.abs(x).toFixed(d), p = s.split("."), ip = p[0], out = "", i;
   for (i = 0; i < ip.length; ++i) { if (i > 0 && (ip.length - i) % 3 === 0 && ip.length >= 4) out += (L === "es" ? " " : ","); out += ip.charAt(i); }
   return (x < 0 ? "−" : "") + out + (p.length > 1 ? (L === "es" ? "," : ".") + p[1] : "");
}
// una distancia en años luz como se dice: < 1000 al entero; hasta 20 000 a la decena; mas, a la centena
function fvE1RoundLy(x) { var st = x < 1000 ? 1 : (x < 20000 ? 10 : 100); return Math.round(x / st) * st; }
function fvE1LyText(x, lang) { return fvE1Num(fvE1RoundLy(x), 0, lang); }

// ---------------------------------------------------------------------------
// E1-01 · la pregunta
// ---------------------------------------------------------------------------
var FV_E1_LYPC = (typeof FV_LY_PER_PC === "number") ? FV_LY_PER_PC : 3.26156;
function fvE1RelOf(d, lo, hi) { return (isFinite(lo) && isFinite(hi) && lo > 0 && hi > lo && d > 0) ? (hi - lo) / (2 * d) : null; }
// la lista que sale de lo que fvBuildScene tiene tras el afinado (res.stars de cpStarfieldBuild): las MISMAS reglas que el paso «dome» de fv_build.js
// (q = 1 con RUWE >= 1,4 o distancia dudosa; q = 2 sin distancia). pc -> a.l.
// field (opcional, res.field): { width, height } para saber cuanto se aparta del centro de la foto (rc, en pixeles); sin el, no hay pregunta del centro
function fvE1qFromRes(stars, field) {
   var out = [], i, hw = field && field.width > 0 ? field.width / 2 : 0, hh = field && field.height > 0 ? field.height / 2 : 0;
   for (i = 0; i < (stars ? stars.length : 0); ++i) {
      var s = stars[i];
      if (!s || s.x === null || s.y === null || s.g === null || s.x === undefined || s.g === undefined) continue;
      var q, dLy = 0, lo = null, hi = null;
      if (s.dist && s.dist.pc > 0) { dLy = s.dist.pc * FV_E1_LYPC; q = (s.dist.quality === "suspect") ? 1 : 0; lo = (s.dist.lo > 0) ? s.dist.lo * FV_E1_LYPC : null; hi = (s.dist.hi > 0) ? s.dist.hi * FV_E1_LYPC : null; }
      else q = 2;
      if (s.ruwe !== null && s.ruwe !== undefined && s.ruwe >= 1.4 && q === 0) q = 1;
      var bp = (s.bpRp !== null && s.bpRp !== undefined && isFinite(s.bpRp)) ? s.bpRp : null;
      var rc = (hw > 0 && isFinite(s.x) && isFinite(s.y)) ? Math.sqrt((s.x - hw) * (s.x - hw) + (s.y - hh) * (s.y - hh)) : null;
      out.push({ dLy: dLy, loLy: lo, hiLy: hi, q: q, g: s.g, inFrame: !!s.inFrame, ra: s.ra, dec: s.dec, id: s.sourceId ? String(s.sourceId) : null, idx: i, bpRp: bp, rc: rc });
   }
   return out;
}
// la lista de la escena ya construida (scene.stars: dEarth en a.l., q, g, inFrame y meta[i].lo/hi en pc)
function fvE1qFromScene(scene) {
   var S = scene && scene.stars, out = [], i, F = scene && scene.field && scene.field.F > 0 ? scene.field.F : 0;
   if (!S) return out;
   for (i = 0; i < S.n; ++i) {
      var m = S.meta[i] || {}, lo = (m.lo > 0) ? m.lo * FV_E1_LYPC : null, hi = (m.hi > 0) ? m.hi * FV_E1_LYPC : null;
      // (M, R6-H1) la pregunta cuenta SOLO distancias medidas por Gaia (el texto de la tira dice «Gaia DR3 + Bailer-Jones»): la lista de arranque (fvE1qFromRes, res.stars)
      // no lleva las de Hipparcos (fv_build.js las añade solo a la escena: Alcione) y, si esta si, la revelacion elegia otra estrella y se cancelaba (Pleyades)
      if (m.src === "hipparcos-2007") continue;
      var bp = (m.bpRp !== null && m.bpRp !== undefined && isFinite(m.bpRp)) ? m.bpRp : null;
      // el pixel de la estrella es (x/z, y/z)·F desde el centro de la foto (fvPixelRay): el mismo rc que da fvE1qFromRes
      var rc = (F > 0 && S.z[i] > 0) ? F * Math.sqrt(S.x[i] * S.x[i] + S.y[i] * S.y[i]) / S.z[i] : null;
      out.push({ dLy: S.dEarth[i], loLy: lo, hiLy: hi, q: S.q[i], g: S.g[i], inFrame: !!S.inFrame[i], ra: m.ra, dec: m.dec, id: m.sourceId ? String(m.sourceId) : null, idx: i, bpRp: bp, rc: rc });
   }
   return out;
}
function fvE1Median(a) { var b = a.slice().sort(function(x, y) { return x - y; }), n = b.length; return n ? (n % 2 ? b[(n - 1) / 2] : 0.5 * (b[n / 2 - 1] + b[n / 2])) : 0; }
function fvE1Pct(a, p) { var b = a.slice().sort(function(x, y) { return x - y; }); return b.length ? b[Math.min(b.length - 1, Math.max(0, Math.round(p * (b.length - 1))))] : 0; }
// los tipos de pregunta: para cada uno, la estrella «mejor» entre las de distancia MEDIDA. (20-nov) Los tres primeros son los de siempre; los otros cuatro dan variedad.
// Todos se miden con datos que ven igual la lista de res.stars (en el arranque) y la de la escena final: la magnitud G, el color BP−RP OBSERVADO (no el corregido de polvo,
// que solo existe en la escena) y el radio en pixeles al centro de la foto
var FV_E1Q_KINDS_OLD = ["nearest", "brightest", "farthest"];
var FV_E1Q_KINDS = ["nearest", "brightest", "farthest", "faintest", "bluest", "reddest", "centre"];
function fvE1qBetter(kind, a, b) {      // ¿es a mejor que b para este tipo? (b = null: si)
   if (!b) return true;
   if (kind === "nearest") return a.s.dLy < b.s.dLy;
   if (kind === "farthest") return a.s.dLy > b.s.dLy;
   if (kind === "brightest") return a.s.g < b.s.g;
   if (kind === "faintest") return a.s.g > b.s.g;
   if (kind === "bluest") return a.s.bpRp < b.s.bpRp;
   if (kind === "reddest") return a.s.bpRp > b.s.bpRp;
   return a.s.rc < b.s.rc;              // centre
}
function fvE1qHas(kind, s) { return (kind === "bluest" || kind === "reddest") ? (s.bpRp !== null && s.bpRp !== undefined) : (kind === "centre" ? (s.rc !== null && s.rc !== undefined) : true); }
// -> { ok, why, kind, answerLy, loLy, hiLy, rel, target: { id, ra, dec, g, idx }, n, medianLy, interest, fits[] } ;
//    opts: { kind (forzar: la revalidacion de la escena final y las pruebas), last (el tipo de la vez anterior: no se repite), rnd (function() -> [0,1): el sorteo; por defecto Math.random) }
//    Con FV_E1Q.VARY se sortea entre los tipos que caben en la escala; sin ella, como antes: de cercana / brillante / lejana la que mas se aparta de la mediana.
function fvE1qPick(list, opts) {
   var o = opts || {}, C = FV_E1Q, el = [], i, bad = 0;
   if (!C.ON) return { ok: false, why: "off" };
   for (i = 0; i < list.length; ++i) {
      var s = list[i];
      if (!s.inFrame || s.q !== 0 || !(s.dLy > 0)) continue;
      var rel = fvE1RelOf(s.dLy, s.loLy, s.hiLy);
      if (rel === null || rel > C.MAX_REL) { ++bad; continue; }
      el.push({ s: s, rel: rel });
   }
   if (el.length < C.MIN_MEAS) return { ok: false, why: "only " + el.length + " measured stars in the photo (" + C.MIN_MEAS + " needed)", n: el.length };
   var med = fvE1Median(el.map(function(e) { return e.s.dLy; })), best = {}, kinds = (C.VARY || o.kind) ? FV_E1Q_KINDS : FV_E1Q_KINDS_OLD, k, e;
   for (k = 0; k < kinds.length; ++k) for (i = 0; i < el.length; ++i) { e = el[i]; if (fvE1qHas(kinds[k], e.s) && fvE1qBetter(kinds[k], e, best[kinds[k]])) best[kinds[k]] = e; }
   var fits = [], pick = null, pi = -1;
   for (k = 0; k < kinds.length; ++k) {
      var b = best[kinds[k]]; if (!b) continue;
      var ly = b.s.dLy, it = Math.abs(Math.log(ly / med) / Math.LN10);
      if (ly < C.LO_LY * 1.2 || ly > C.HI_LY / 1.2) continue;           // fuera de la escala de la respuesta: no cabe la aguja
      if (o.kind) { if (o.kind === kinds[k]) pick = { kind: kinds[k], e: b, interest: it }; continue; }
      fits.push({ kind: kinds[k], e: b, interest: it });
      if (!C.VARY && it > pi + 1e-9) { pi = it; pick = fits[fits.length - 1]; }
   }
   if (C.VARY && !o.kind && fits.length) {
      var pool = fits.filter(function(f) { return f.kind !== o.last; });
      if (!pool.length) pool = fits;                                    // solo cabe el de la vez anterior: se repite (mejor eso que no preguntar)
      var u = (typeof o.rnd === "function") ? o.rnd() : Math.random();
      pick = pool[Math.min(pool.length - 1, Math.max(0, Math.floor(u * pool.length)))];
   }
   if (!pick) return { ok: false, why: "no question fits the scale", n: el.length };
   var t = pick.e.s;
   return { ok: true, why: "", kind: pick.kind, answerLy: t.dLy, loLy: t.loLy, hiLy: t.hiLy, rel: pick.e.rel, n: el.length, medianLy: med, interest: pick.interest,
            fits: fits.map(function(f) { return f.kind; }), target: { id: t.id, ra: t.ra, dec: t.dec, g: t.g, idx: t.idx } };
}
// la caja de la placa del arranque (unidades de la cabina) en la pantalla W×H con la placa del arranque en plate = { x0, y0, x1, y1 }. -> { x0, y0, w, h, where }
// TOP (20-nov): ARRIBA. Si el margen de encima de la placa del arranque la admite, centrada en ese margen; si no, pegada al borde de arriba de la ventana (y = 8), encima de
// la franja del titulo de la placa del arranque (la nave, los rotulos y la fila de abajo con el progreso quedan a la vista). Como la de la cabina (y = 14, centrada).
// Sin TOP, como antes: bajo la placa del arranque o, si no cabe, sobre su fila de abajo.
function fvE1qBox(W, H, plate) {
   var ph = 124, wFull = Math.min(W - 48, 720), free, x0, y0, w;
   if (FV_E1Q.TOP) {
      free = plate.y0;
      w = wFull; x0 = Math.round((W - w) / 2);
      if (free >= ph + 16) y0 = Math.round((free - ph) / 2);
      else y0 = 8;
      return { x0: x0, y0: y0, w: w, h: ph, where: "top" };
   }
   free = H - plate.y1;
   if (free >= ph + 10) { w = wFull; x0 = Math.round((W - w) / 2); y0 = Math.round(plate.y1 + (free - ph) / 2); }
   else { w = Math.min(wFull, (plate.x1 - 150) - (plate.x0 + 28)); x0 = plate.x0 + 28; y0 = plate.y1 - ph - 10; }
   return { x0: x0, y0: y0, w: w, h: ph, where: "bottom" };
}
// (M) la placa de la respuesta de QUAESTIO en la cabina (arriba al centro, unidades de la cabina; W = el ancho): la geometria, en un solo sitio para fvE1qHudPaint (src/ui/fv_e1_ui.js), la ficha de PixInsight
// (fvCardPaint) y la web (fw_e1.js, fw_cockpit.js). La ficha de una estrella de arriba (Alcione en el diagrama HR de las Pleyades) quedaba con el titulo BAJO la tira
// (21-nov, PKG-final) Y0 = 52 (antes 14): la tira de QUAESTIO va DEBAJO de la cinta DATA (la placa plegada ocupa y 18–42) y del rotulo de estado de arriba a la derecha (fvStatusLinePaint,
// y 21–47: lo que escribe el balanceo E1S, «Lo que parecia junto esta repartido…»), que a 1280 de ancho de la cabina ocupaban x 22–454 y la tira (x 320–960) los tapaba. BAND_Y1 = 48: la y
// por debajo de la cual no hay nada de la cinta (la mide fv_Q_pi.js con los rectangulos reales y fv_Q_node.js con los de la geometria). MIN_W: la anchura minima de la tira desplazada.
var FV_E1Q_HUD = { Y0: 52, H: 78, GAP: 10, BAND_Y1: 48, MIN_W: 420 };
// avoid (opcional) = { x1, y1 }: la placa DATA ABIERTA (x 22–542, alta): la tira se pone a su derecha si cabe (anchura >= MIN_W) y, si no, debajo de ella. Las dos interfaces pasan lo suyo
// (PixInsight: painter.legendRect; web: el rectangulo de #legend), asi la geometria es una sola.
function fvE1qHudBox(W, avoid) {
   var w = Math.min(W - 80, 640), x0 = Math.round((W - w) / 2), y0 = FV_E1Q_HUD.Y0;
   if (avoid && avoid.y1 > y0 && avoid.x1 + FV_E1Q_HUD.GAP > x0) {
      var nx0 = Math.round(avoid.x1 + FV_E1Q_HUD.GAP), nw = Math.min(640, W - 40 - nx0);
      if (nw >= FV_E1Q_HUD.MIN_W) { x0 = nx0; w = nw; } else y0 = Math.round(avoid.y1 + FV_E1Q_HUD.GAP);
   }
   return { x0: x0, y0: y0, x1: x0 + w, y1: y0 + FV_E1Q_HUD.H, w: w, h: FV_E1Q_HUD.H };
}
// la y minima de una ficha que ocupa [cx0, cx1] en x: la de siempre (baseMin) o, si cae bajo la tira (se solapan en x), justo debajo de ella + GAP
function fvE1qCardMinY(W, cx0, cx1, baseMin, avoid) { var b = fvE1qHudBox(W, avoid); return (cx1 <= b.x0 || cx0 >= b.x1) ? baseMin : Math.max(baseMin, b.y1 + FV_E1Q_HUD.GAP); }
// las opciones de fvE1qPick para esta vez: el tipo de la ultima (no se repite) y, en pruebas, el forzado
function fvE1qOpts(last) { var o = { last: last || "" }; if (FV_E1Q.FORCE) o.kind = FV_E1Q.FORCE; return o; }
// la posicion 0…1 de una distancia en la escala logaritmica de la respuesta, y su inversa
function fvE1qPos(ly) { var a = Math.log(FV_E1Q.LO_LY), b = Math.log(FV_E1Q.HI_LY); return Math.max(0, Math.min(1, (Math.log(Math.max(1e-9, ly)) - a) / (b - a))); }
function fvE1qVal(u) { var a = Math.log(FV_E1Q.LO_LY), b = Math.log(FV_E1Q.HI_LY); return Math.exp(a + Math.max(0, Math.min(1, u)) * (b - a)); }
// comparar lo dicho con lo medido: solo el cociente (≥ 1) y de que lado; nada de acierto o fallo
function fvE1qCompare(guessLy, answerLy) {
   if (!(guessLy > 0) || !(answerLy > 0)) return null;
   var r = guessLy / answerLy, f = (r >= 1) ? r : 1 / r;
   return { ratio: f, side: r >= 1 ? "far" : "near", close: f < 1.15 };
}
// el texto de la pregunta
function fvE1qQuestion(Q, lang) { return fvE1Tx("q." + Q.kind, null, lang); }
// las lineas de la revelacion: [medido, lo dicho]
function fvE1qRevealLines(Q, guessLy, lang) {
   var L = fvE1Lang(lang), c = fvE1qCompare(guessLy, Q.answerLy), l1 = fvE1Tx("q.reveal", { v: fvE1LyText(Q.answerLy, L), r: fvE1Num(Math.max(1, Math.round(Q.rel * 100)), 0, L) }, L), l2;
   if (!c) l2 = fvE1Tx("q.none", null, L);
   else if (c.close) l2 = fvE1Tx("q.close", { g: fvE1LyText(guessLy, L) + " " + (L === "es" ? "a. l." : "ly") }, L);
   else l2 = fvE1Tx("q.you", { g: fvE1LyText(guessLy, L) + " " + (L === "es" ? "a. l." : "ly"), f: fvE1Num(c.ratio, c.ratio < 10 ? 1 : 0, L), side: fvE1Tx("q." + c.side, null, L) }, L);
   return [l1, l2];
}
// donde esta la estrella de la pregunta en la escena ya construida: por Gaia source_id y, sin el, por posicion (< 1″). -> indice o -1
function fvE1qFind(scene, target) {
   var S = scene && scene.stars, i, best = -1, bd = 1e9;
   if (!S || !target) return -1;
   if (target.id) for (i = 0; i < S.n; ++i) if (S.meta[i] && S.meta[i].sourceId && String(S.meta[i].sourceId) === String(target.id)) return i;
   for (i = 0; i < S.n; ++i) {
      var m = S.meta[i]; if (!m || m.ra === undefined || m.dec === undefined) continue;
      var dd = Math.abs(m.dec - target.dec) * 3600, dr = Math.abs(m.ra - target.ra) * Math.cos(target.dec * Math.PI / 180) * 3600, d = Math.sqrt(dd * dd + dr * dr);
      if (d < bd) { bd = d; best = i; }
   }
   return (bd < 1.0) ? best : -1;
}

// ---------------------------------------------------------------------------
// E1-12 · el balanceo de paralaje
// ---------------------------------------------------------------------------
// S = scene.stars; homeFov = campo de la vista en casa (rad). -> { ok, ampLy, durS, spanLy, n, d10, d50 }
function fvE1sPlan(S, homeFov, nebLy) {
   var C = FV_E1S, ds = [], i;
   if (!C.ON || !S || !(homeFov > 0)) return { ok: false, why: "off" };
   for (i = 0; i < S.n; ++i) if (S.inFrame[i] && S.q[i] === 0 && S.dEarth[i] > 0) ds.push(S.dEarth[i]);
   if (ds.length < C.MIN_MEAS) return { ok: false, why: "only " + ds.length + " measured stars" };
   var d10 = fvE1Pct(ds, 0.10), d50 = fvE1Median(ds), p05 = fvE1Pct(ds, 0.05), p95 = fvE1Pct(ds, 0.95);
   // (H7) nebLy = distancia de la lamina de la foto (scene.nebula.distLy): la foto se desplaza MED_FRAC del campo si esta a la mediana de las estrellas; si la lamina esta MAS CERCA que la
   // mediana (Pleiades: lamina a ~440 a.l., mediana de las estrellas medidas ~1 400) se desplazaria mas y el acercamiento que tapa el borde (EDGE_ON) llegaba a ×1,30: el tope usa la menor
   var dRef = (nebLy > 0) ? Math.min(d50, nebLy) : d50;
   var amp = Math.min(d10 * Math.tan(C.SHIFT_FRAC * homeFov), dRef * Math.tan(C.MED_FRAC * homeFov));
   return { ok: true, ampLy: amp, durS: C.DUR_S, spanLy: p95 - p05, n: ds.length, d10: d10, d50: d50 };
}
// el desplazamiento lateral (a.l.) en el instante u (0…1): izquierda, derecha y de vuelta, con velocidad nula en los dos extremos
// el campo REAL de la foto en casa (rad). Con el laboratorio de vuelo la pantalla enseña la foto a una lente ancha (cam.fov, 40°) y el proyector multiplica lo lateral por
// cam.S (fvLabProjector: S·(p − pos)), asi que un desplazamiento lateral de la camara pesa S veces mas en pantalla: el campo con que se mide la amplitud es cam.fov / cam.S
// (medido 20-nov con la Rosette: con 40° la estrella cercana cruzaba 2 447 px de una pantalla de 1 222)
function fvE1sFov(P) { var f = P.homeFov, S = (P.cam && P.cam.B && P.cam.S > 0) ? P.cam.S : 1; return f / S; }
function fvE1sOffset(plan, u) { if (!plan || u <= 0 || u >= 1) return 0; return plan.ampLy * Math.sin(2 * Math.PI * u) * Math.sin(Math.PI * u) / 0.7698; }
// la posicion de la camara desplazada de lado (su vector «derecha»: la base del laboratorio si la hay, si no la de la mirada)
function fvE1sShift(cam, offLy) {
   var r = (cam.B && cam.B.r) ? cam.B.r : fvBasis(cam.look, [0, 1, 0]).r;
   return [cam.pos[0] + r[0] * offLy, cam.pos[1] + r[1] * offLy, cam.pos[2] + r[2] * offLy];
}
// (H7) cuanto hay que acercar la vista (factor >= 1 sobre la distancia focal) para que el borde de la foto no asome con la camara desplazada offLy de lado: la foto (capa 0 a la
// distancia de la nebulosa, como FVPainter.photoQuad y el sombreador del visor) con la camara en su sitio de AHORA; cada canto que en casa esta FUERA de la pantalla (o justo en
// ella) se pide a EDGE_PX·ancho fuera, en proporcion a |off| / amp (en casa 0 → k = 1 exacto). El zoom es respecto al centro de la pantalla: x' = cx + k·(x − cx).
// Solo cuenta el plano de la foto sin inclinar (la inclinacion es del orden de 0,1 px; se mide aparte). Sin nebulosa / sin capas / sin la bandera → 1
function fvE1sEdges(cam, sc, offLy, VW, VH) {
   var N = sc && sc.nebula; if (!N || !N.layers || !N.layers.length || !(N.distLy > 0)) return null;
   var L0 = N.layers[0], d0 = N.distLy, cs = [[L0.x0, L0.y0], [L0.x1, L0.y0], [L0.x1, L0.y1], [L0.x0, L0.y1]], q = [], i;
   var pr = fvProjector({ pos: fvE1sShift(cam, offLy), look: cam.look, fov: cam.fov, roll: cam.roll || 0, B: cam.B, S: cam.S }, VW, VH);
   for (i = 0; i < 4; ++i) { var p = pr.project([cs[i][0] / L0.z * d0, cs[i][1] / L0.z * d0, d0]); if (!p) return null; q.push(p); }
   return { L: Math.max(q[0][0], q[3][0]), R: Math.min(q[1][0], q[2][0]), T: Math.max(q[0][1], q[1][1]), B: Math.min(q[2][1], q[3][1]) };
}
function fvE1sZoomK(cam, sc, offLy, ampLy, VW, VH) {
   var C = FV_E1S; if (!C.EDGE_ON || !offLy || !(ampLy > 0)) return 1;
   var e = fvE1sEdges(cam, sc, offLy, VW, VH), e0 = fvE1sEdges(cam, sc, 0, VW, VH); if (!e || !e0) return 1;
   var cx = VW / 2, cy = VH / 2, mt = C.EDGE_PX * VW * Math.min(1, Math.abs(offLy) / ampLy), k = 1, t;
   // (lado en casa dentro de la pantalla = fotograma con franjas de siempre: no se persigue)
   if (e0.L <= 0.5 && cx - e.L > 0) { t = (cx + mt) / (cx - e.L); if (t > k) k = t; }
   if (e0.R >= VW - 0.5 && e.R - cx > 0) { t = (VW - cx + mt) / (e.R - cx); if (t > k) k = t; }
   if (e0.T <= 0.5 && cy - e.T > 0) { t = (cy + mt) / (cy - e.T); if (t > k) k = t; }
   if (e0.B >= VH - 0.5 && e.B - cy > 0) { t = (VH - cy + mt) / (e.B - cy); if (t > k) k = t; }
   return k;
}
// el campo (rad) con el que se pinta con el factor k: f' = k·f
function fvE1sFovK(fov, k) { return k > 1 ? 2 * Math.atan(Math.tan(fov / 2) / k) : fov; }
function fvE1sText(plan, lang) { return fvE1Tx("s.line", { span: fvE1LyText(plan.spanLy, lang), n: fvE1Num(plan.n, 0, lang) }, lang); }

// ---------------------------------------------------------------------------
// E1-13 · mirar a casa
// ---------------------------------------------------------------------------
// posLy: la posicion de la nave (el Sol, la Tierra, esta en el origen). -> { ok, dLy, dPc, m, band, dir, kind, lines[], mwDeg }
function fvE1hSun(posLy, lang) {
   var C = FV_E1H, d = Math.sqrt(posLy[0] * posLy[0] + posLy[1] * posLy[1] + posLy[2] * posLy[2]), L = fvE1Lang(lang);
   if (!(d > 1e-6)) return { ok: false, why: "home" };
   var dPc = d / FV_E1_LYPC, m = C.MV_SUN + 5 * Math.log(dPc) / Math.LN10 - 5;
   var kind = m <= 6 ? "eye" : (m <= 10 ? "bino" : (m <= 14 ? "scope" : (m <= 21 ? "long" : (m <= 27 ? "vlong" : "none"))));
   var lines = [fvE1Tx("h.mag", { m: fvE1Num(m, 1, L) }, L)];
   lines.push(fvE1Tx("h." + kind, null, L));
   var mw = null;
   if (dPc >= 100) {          // desde mas de 100 pc el disco de la galaxia cabe en el cielo: dice cuanto ocuparia
      mw = 2 * Math.atan((C.MW_KPC * 500) / (dPc)) * 180 / Math.PI;      // radio 15 kpc = 15000 pc -> (MW_KPC/2)*1000 pc = MW_KPC*500
      if (dPc >= 1e5 && mw < 60) lines.push(fvE1Tx("h.mw", { kpc: fvE1Num(C.MW_KPC, 0, L), deg: fvE1Num(mw, mw < 10 ? 2 : 1, L), moon: fvE1Num(C.MOON_DEG, 2, L) }, L));
   }
   return { ok: true, dLy: d, dPc: dPc, m: m, band: "V", dir: [-posLy[0] / d, -posLy[1] / d, -posLy[2] / d], kind: kind, lines: lines, mwDeg: mw };
}

// el giro hacia el Sol desde donde se esta (lo comparten PixInsight y la web). Con el laboratorio de vuelo (la navegacion por defecto desde el 11-nov) el viaje
// «look» es el suyo (fvLabFly con sel.dir: su giro y su arbitraje de la mirada); fvPilotLookHome, el motor de antes (F2), arma un vuelo SIN la parte del laboratorio
// y con el el giro no llegaba al Sol (medido 20-nov: coseno −0,997 al acabar). -> true si sale el giro; deja P.sunMark = true (la placa del Sol)
function fvE1hFly(P) {
   var r = fvE1hSun(P.cam.pos), ok = false;
   if (!r.ok) return false;
   var lab = (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P) && !!P.cam.B);
   if (lab && typeof fvPilotFly === "function") {
      ok = fvPilotFly(P, "look", { dir: r.dir });
      // el viaje «look» del laboratorio dura 2 s y a 28 °/s no llega a girar media vuelta (medido: 65° de los 180° y el Sol sin salir): se alarga lo que pide el giro
      if (ok && P.flight && P.flight.kind === "look" && FV_LAB.TURN) {
         var tc = FV_LAB.TURN.look || FV_LAB.TURN.cine, ang = fvAngle(P.cam.B.f, r.dir) / (Math.PI / 180);
         P.flight.dur = Math.max(P.flight.dur, Math.min(14, ang / tc[0] + tc[0] / tc[1] + 1.0));
      }
   }
   else if (typeof fvPilotLookHome === "function") ok = fvPilotLookHome(P);
   if (ok) P.sunMark = true;
   return !!ok;
}

// ---------------------------------------------------------------------------
// E1-14 · silencio de llegada
// ---------------------------------------------------------------------------
// ¿es la llegada a un objeto PRINCIPAL? (la nebulosa, la fila principal, el protagonista). Nunca una estrella ni un objeto menor
function fvE1tIsMain(scene, sel) {
   if (!FV_E1Z.ON || !scene || !sel) return false;
   if (sel.kind === "nebula") return true;
   if (sel.kind === "object" && scene.objects && scene.objects[sel.i]) {
      var o = scene.objects[sel.i];
      return o.main === true || o.hero === true || !!(scene.hero && scene.hero.id && scene.hero.id === o.id);
   }
   return false;
}
// lo que pide el silencio a la radio mientras dura: { until (s del reloj de la nave), f (atenuacion), level (capas) } o null
function fvE1tPlan(scene, sel, nowT) {
   if (!fvE1tIsMain(scene, sel)) return null;
   return { until: nowT + FV_E1Z.DUR_S, f: FV_E1Z.DUCK, level: FV_E1Z.LEVEL, s: 0.35, hz: 6000 };
}
