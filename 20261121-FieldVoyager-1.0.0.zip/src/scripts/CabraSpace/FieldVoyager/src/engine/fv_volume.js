// ============================================================================
// FieldVoyager/src/engine/fv_volume.js — EL VOLUMEN POR FAMILIAS DE FORMA (fase 2 de la sonda V, 5-nov-2026). PURO: sin PixInsight ni DOM.
// Se carga en PixInsight (FieldVoyager.js), en node (pruebas) y en el navegador (paquete exportado). ES5.
// PROCEDENCIA: portado de tests/fv_V_volume.jsh (sonda V del mismo dia, mismo autor) y ampliado.
// ----------------------------------------------------------------------------
// UN METODO PARA CUALQUIER FOTO (decision de Nino, 5-nov: «tiene que ser extrapolable a otras imagenes ... una forma consistente y uniforme»):
//   1. CLASIFICAR cada objeto compacto en una FAMILIA DE FORMA a partir de lo que ya da el build (tipo de SIMBAD / catalogo, tamaño) y de
//      MEDIDAS DE LA PROPIA IMAGEN (elongacion, simetria central, perfil radial invertido, concentracion). Familias:
//        · "shell"  CASCARA: planetarias, restos de supernova, burbujas. Elipsoide; si la foto lo ve alargado, prolato con el eje en el eje
//                   mayor proyectado y semieje de profundidad = el menor (cociente de la propia imagen, no un ×2 fijo).
//        · "disk"   DISCO: galaxias. Esferoide achatado a la inclinacion que da su elongacion; lo que sobra fuera del disco a lo largo del eje
//                   menor (viento, halo: M 82) va a una componente APARTE, con simetria cilindrica alrededor de ese eje; nucleo con margen
//                   (headroom) y hombro suave en vez de quemarse.
//        · "slab"   NEBULOSA EXTENSA (la del fondo de la foto): ver la segunda mitad del fichero.
//        · null     FALLBACK = el modelo de hoy (capas de fv_objects.js), cuando la confianza es baja o la familia esta apagada.
//   2. EL VOLUMEN ES FACTORIZADO: V_c(x, y, z) = C_c(x, y) · p_c(z | x, y), Σ_z p_c = 1 en cada columna (la columna es el rayo desde la Tierra).
//      INVARIANTE COMUN A TODAS LAS FAMILIAS: proyectado DE FRENTE reproduce la foto por construccion (no depende de que la forma acierte).
//      La forma solo decide COMO se reparte la luz de cada pixel en profundidad: de lado se ve la forma 3D con el detalle de la foto encima.
//   3. Todos los parametros salen de la imagen o son constantes documentadas con su origen (pregunta 4 de la ficha de las seis formas).
// Banderas: FV_VOLM.ON (false = hoy, pixel identico: nadie llama a este fichero) y FV_VOLM.FAM.{shell, disk, slab}.
// OJO: el nombre FV_VOL ya lo usa src/export/fv_export_volume.js (el volumen D9 del visor web, F3); por eso aqui es FV_VOLM («por modelo»).
// ============================================================================

var FV_VOLM = {
   ON: false,                                   // false = el modelo de hoy (capas), pixel identico
   // sub-banderas por familia (false = esa familia cae al modelo de hoy). slab APAGADA (5-nov, medido en tests/fv_V2_sweep.log): ninguna de las
   // 8 variantes de nebulosa extensa pasa los 7 criterios en IC 1848 (drama entrando 0,16-0,23 frente a 0,405 de hoy, 2-3× mas lenta, y la
   // losa plana r0 sale igual que v0: el relieve por cortes Add normalizados no se ve). La nebulosa sigue con las capas de hoy (G1).
   FAM: { shell: true, disk: true, slab: false },
   // ---- clasificador ----
   SCORE_MIN: 0.55,      // puntuacion minima de la familia ganadora (0..1) — ELECCION nuestra, calibrada en las 13 fotos de validacion (fv_V2_*.log)
   MARGIN_MIN: 0.12,     // y ventaja minima sobre la segunda — idem
   // ---- cascara ----
   ABEL_SMOOTH: 1.5,     // suavizado del perfil antes de invertir (px; sonda V)
   EPS_SMOOTH: 1.0,      // suavizado de la emisividad invertida (px; sonda V)
   Q_ROUND: 0.95, Q_LONG: 0.70,   // q ≥ 0,95: esfera (semieje de profundidad √(a·b)); q ≤ 0,70: prolato del todo (profundidad = b); entre medias, continuo.
                                  // ELECCION nuestra [SIN NINO]: la foto no distingue prolato de oblato; las planetarias alargadas suelen ser bipolares
                                  // o elipticas vistas de lado (prolatas). Un objeto redondo puede ser un prolato visto de polo (NGC 2392): la imagen
                                  // no lo dice y se usa la esfera (la suposicion minima).
   ASYM: 0.4, ASYM_CELL: 0.6, ASYM_Z0: 0.12,   // asimetria delante/detras (sin ella, de lado todo sale en espejo) — ESTETICO (sonda V)
   // ---- disco ----
   GAL_Q0: 0.2,          // grosor intrinseco b/a de un disco: la convencion de la formula de inclinacion cos²i = (q² − q0²)/(1 − q0²) (Hubble 1926;
                         // la de las correcciones de Tully-Fisher). NO VERIFICADO hoy en la fuente; tipico 0,1–0,25
   SHAPE_LUM: 0.15,      // la forma del disco se mide con los pixeles por encima del 15 % del pico suavizado (lo brillante es disco; viento y halo
                         // son debiles y extensos y redondeaban M 82: q 0,46 con todo el recorte) — ELECCION nuestra
   WIND_Q: [0.50, 0.70], // la componente perpendicular se activa con q < 0,70 y del todo con q < 0,50 (de cara no hay «viento» que separar: los
                         // brazos brillantes no son halo) — ELECCION nuestra
   WIND_M: 1.6,          // un pixel es disco hasta WIND_M × el perfil del disco (mediana del anillo eliptico): lo que pasa de ahi es viento/halo
   WIND_SMOOTH: 2.0,     // suavizado entre filas de la emisividad cilindrica del viento (px)
   HEAD: { shell: 1, disk: 2 },   // margen de brillo: los cortes se guardan a 1/HEAD y el lienzo se expande con hombro (de canto el disco suma mas
                                  // camino: el nucleo de M 82 se quemaba en la sonda V)
   KNEE: 0.8,            // rodilla del hombro (fraccion de 255): por debajo, lineal exacto
   // ---- pilas de cortes ----
   N: { shell: 32, disk: 48 },    // cortes por pila (sonda V: con 16/32 el disco de M 82 hacia bandas de cara; 64 sin bandas; 48 con el rebin por solape)
   GRID_MAX: 384,        // lado maximo de la rejilla del modelo (el recorte se reduce por bloques si es mayor; M 82 1024 -> 342)
   DZ_MAX: 256,          // bins de profundidad maximos de las pilas laterales (rebin por solape)
   QUANT: "diffuse",     // "round" = ROJO (cada corte redondeado por su cuenta: la luz debil repartida en N cortes se pierde)
   PHASE: "random",      // fase de la difusion del error a lo largo de la pila
   ZBIN: "area",         // "floor" = ROJO (rayas cada ~5 px si Dz < D; sonda V pasada 2)
   SEED: 7121,
   BREAK: ""             // pruebas: "nowind" (sin componente perpendicular) · "nohead" (sin margen) · "sphere" (cascara siempre esferica) · "noclass" · "noguard" (sin la guarda de simetria)
};

function fvvClamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fvvSmooth(t) { t = fvvClamp(t, 0, 1); return t * t * (3 - 2 * t); }
function fvvH3(ix, iy, iz, s) { var t = Math.sin(ix * 127.1 + iy * 311.7 + iz * 74.7 + s * 19.19) * 43758.5453; return t - Math.floor(t); }
function fvvSm(t) { return t * t * (3 - 2 * t); }
function fvvNoise3(x, y, z, s) {
   var ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z), fx = fvvSm(x - ix), fy = fvvSm(y - iy), fz = fvvSm(z - iz);
   var a = fvvH3(ix, iy, iz, s), b = fvvH3(ix + 1, iy, iz, s), c = fvvH3(ix, iy + 1, iz, s), d = fvvH3(ix + 1, iy + 1, iz, s);
   var e = fvvH3(ix, iy, iz + 1, s), f = fvvH3(ix + 1, iy, iz + 1, s), g = fvvH3(ix, iy + 1, iz + 1, s), h = fvvH3(ix + 1, iy + 1, iz + 1, s);
   var l0 = (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fy, l1 = (e + (f - e) * fx) + ((g + (h - g) * fx) - (e + (f - e) * fx)) * fy;
   return l0 + (l1 - l0) * fz;
}
function fvvRng(seed) { var s = (seed >>> 0) || 1; return function() { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
function fvvGauss1(a, sig) {
   var n = a.length, out = new Float64Array(n), i, k;
   if (!(sig > 0.05)) { for (i = 0; i < n; ++i) out[i] = a[i]; return out; }
   var r = Math.ceil(3 * sig);
   for (i = 0; i < n; ++i) { var s = 0, ws = 0; for (k = -r; k <= r; ++k) { var j = i + k; if (j < 0 || j >= n) continue; var w = Math.exp(-k * k / (2 * sig * sig)); s += w * a[j]; ws += w; } out[i] = ws > 0 ? s / ws : 0; }
   return out;
}
function fvvMedian(a) { if (!a.length) return 0; var s = a.slice().sort(function(p, q) { return p - q; }); return s[s.length >> 1]; }
// Uint32 RGB -> [Float32 R, G, B]
function fvvChannels(cut, n) {
   var R = new Float32Array(n), G = new Float32Array(n), B = new Float32Array(n);
   for (var i = 0; i < n; ++i) { var p = cut[i]; R[i] = (p >>> 16) & 255; G[i] = (p >>> 8) & 255; B[i] = p & 255; }
   return [R, G, B];
}
// el recorte reducido por bloques ×ds (media) -> { cut, w, h }
function fvvDownCut(cut, w, h, ds) {
   if (ds <= 1) return { cut: cut, w: w, h: h };
   var w2 = Math.floor(w / ds), h2 = Math.floor(h / ds), out = new Uint32Array(w2 * h2), k = ds * ds;
   for (var y = 0; y < h2; ++y) for (var x = 0; x < w2; ++x) {
      var s0 = 0, s1 = 0, s2 = 0;
      for (var b = 0; b < ds; ++b) for (var a = 0; a < ds; ++a) { var p = cut[(y * ds + b) * w + x * ds + a]; s0 += (p >>> 16) & 255; s1 += (p >>> 8) & 255; s2 += p & 255; }
      out[y * w2 + x] = (0xff000000 | (Math.round(s0 / k) << 16) | (Math.round(s1 / k) << 8) | Math.round(s2 / k)) >>> 0;
   }
   return { cut: out, w: w2, h: h2 };
}
// PELADO DE CEBOLLA (inversion de Abel discreta): perfil proyectado prof[i] (impacto en [i, i+1)) -> emisividad eps[j] (r en [j, j+1)), ≥ 0.
// Vale igual para una esfera (impacto en un plano) que para un cilindro (impacto en una fila): la cuerda de la corona j a la distancia
// b = i + 0,5 es L_ij = 2(√((j+1)² − b²) − √(j² − b²)) en los dos casos.
function fvvOnion(prof) {
   var nb = prof.length, eps = new Float64Array(nb), i, j;
   function chord(i2, j2) { var b = i2 + 0.5, o = (j2 + 1) * (j2 + 1) - b * b, n = j2 * j2 - b * b; return 2 * (Math.sqrt(Math.max(0, o)) - Math.sqrt(Math.max(0, n))); }
   for (i = nb - 1; i >= 0; --i) { var s = prof[i]; for (j = i + 1; j < nb; ++j) s -= chord(i, j) * eps[j]; eps[i] = Math.max(0, s / chord(i, i)); }
   return eps;
}
// Abel directo discreto (control de las pruebas)
function fvvProjectAbel(eps) {
   var nb = eps.length, out = new Float64Array(nb);
   for (var i = 0; i < nb; ++i) { var s = 0; for (var j = i; j < nb; ++j) { var b = i + 0.5, o = (j + 1) * (j + 1) - b * b, n = j * j - b * b; s += 2 * (Math.sqrt(Math.max(0, o)) - Math.sqrt(Math.max(0, n))) * eps[j]; } out[i] = s; }
   return out;
}
// emisividad del perfil e a radio r (bins de 1 px, lineal entre centros, 0 fuera)
function fvvEpsAt(e, r) {
   var u = r - 0.5, j = Math.floor(u), n = e.length;
   if (j < 0) return e[0];
   if (j >= n - 1) return (j === n - 1) ? e[n - 1] * Math.max(0, 1 - (u - j)) : 0;
   return e[j] + (e[j + 1] - e[j]) * (u - j);
}

// ----------------------------------------------------------------------------
// MEDIDAS DE LA IMAGEN (las mismas para todas las fotos). cut Uint32 w·h (foto − fondo)·alfa; geom { w, h, cx, cy, rMax }
// -> { q, phi, qAll, phiAll, sym, lb, conc, nb, S (radio eliptico por pixel), profL (perfil de luminancia), epsL, peak, ch, why }
//   q, phi    elipse por momentos de 2.º orden de los pixeles por encima de SHAPE_LUM del pico suavizado (la forma de lo brillante)
//   qAll      la misma con todo el recorte (si es mucho mas redonda que q, hay luz extensa a lo largo del eje menor: viento o halo)
//   sym       simetria central: correlacion entre el recorte y su giro de 180° alrededor del centro (galaxias y planetarias, altas)
//   lb        abrillantamiento del borde: max de la emisividad INVERTIDA en 0,25–0,95 R frente a su valor central (cascara > 1, disco < 1)
//   conc      concentracion r80/r20 de la luz (disco con bulbo, alta; cascara, baja)
// ----------------------------------------------------------------------------
function fvvMoments(ch, w, h, cx, cy, R, thr) {
   var sw = 0, sx = 0, sy = 0, sxx = 0, syy = 0, sxy = 0, R2 = R * R, x, y;
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
      var dx = x + 0.5 - cx, dy = y + 0.5 - cy; if (dx * dx + dy * dy > R2) continue;
      var i = y * w + x, l = (ch[0][i] + ch[1][i] + ch[2][i]) / 3; if (!(l > thr)) continue;
      sw += l; sx += l * dx; sy += l * dy; sxx += l * dx * dx; syy += l * dy * dy; sxy += l * dx * dy;
   }
   if (!(sw > 0)) return { q: 1, phi: 0, mx: 0, my: 0 };
   var mx = sx / sw, my = sy / sw, a = sxx / sw - mx * mx, c = syy / sw - my * my, b = sxy / sw - mx * my, tr = a + c, det = a * c - b * b, dsc = Math.sqrt(Math.max(0, tr * tr / 4 - det));
   var l1 = tr / 2 + dsc, l2 = Math.max(1e-9, tr / 2 - dsc);
   return { q: Math.max(0.08, Math.min(1, Math.sqrt(l2 / l1))), phi: 0.5 * Math.atan2(2 * b, a - c), mx: mx, my: my };
}
function fvvEllRadius(w, h, cx, cy, q, phi) {
   var S = new Float32Array(w * h), cp = Math.cos(phi), sp = Math.sin(phi);
   for (var y = 0; y < h; ++y) for (var x = 0; x < w; ++x) { var dx = x + 0.5 - cx, dy = y + 0.5 - cy, xp = dx * cp + dy * sp, yp = -dx * sp + dy * cp; S[y * w + x] = Math.sqrt(xp * xp + (yp / q) * (yp / q)); }
   return S;
}
function fvVolMeasure(cut, geom) {
   var w = geom.w, h = geom.h, n = w * h, cx = geom.cx, cy = geom.cy, R = Math.max(3, geom.rMax), ch = fvvChannels(cut, n), i, x, y;
   // pico suavizado (caja 5×5 sobre la luminancia) para el umbral de forma
   var L = new Float32Array(n), pk = 0;
   for (i = 0; i < n; ++i) L[i] = (ch[0][i] + ch[1][i] + ch[2][i]) / 3;
   for (y = 2; y < h - 2; y += 2) for (x = 2; x < w - 2; x += 2) { var s = 0; for (var b = -2; b <= 2; ++b) for (var a = -2; a <= 2; ++a) s += L[(y + b) * w + x + a]; if (s / 25 > pk) pk = s / 25; }
   var mAll = fvvMoments(ch, w, h, cx, cy, 1.3 * R, 0), mIn = fvvMoments(ch, w, h, cx, cy, 1.3 * R, FV_VOLM.SHAPE_LUM * pk);
   var q = mIn.q, phi = mIn.phi, S = fvvEllRadius(w, h, cx, cy, q, phi), sMax = 0;
   for (i = 0; i < n; ++i) if (L[i] > 0 && S[i] > sMax) sMax = S[i];
   var nb = Math.max(4, Math.ceil(sMax) + 2), prof = new Float64Array(nb), cnt = new Float64Array(nb);
   for (i = 0; i < n; ++i) { var bi = Math.floor(S[i]); if (bi >= nb) continue; cnt[bi] += 1; prof[bi] += L[i]; }
   for (i = 0; i < nb; ++i) prof[i] = cnt[i] > 0 ? prof[i] / cnt[i] : 0;
   var profS = fvvGauss1(prof, FV_VOLM.ABEL_SMOOTH), eps = fvvGauss1(fvvOnion(profS), FV_VOLM.EPS_SMOOTH);
   // abrillantamiento del borde (en el radio de la luz: el 95 % de la luz proyectada dentro)
   var cum = 0, tot = 0, r95 = nb - 1, r20 = 0, r80 = nb - 1, c20 = false, c80 = false;
   for (i = 0; i < nb; ++i) tot += prof[i] * (2 * i + 1);
   for (i = 0; i < nb; ++i) { cum += prof[i] * (2 * i + 1); if (!c20 && cum >= 0.2 * tot) { r20 = i + 0.5; c20 = true; } if (!c80 && cum >= 0.8 * tot) { r80 = i + 0.5; c80 = true; } if (cum >= 0.95 * tot) { r95 = i + 0.5; break; } }
   var e0 = 0, ne0 = 0; for (i = 0; i < Math.max(1, Math.round(0.12 * r95)); ++i) { e0 += eps[i]; ++ne0; } e0 /= Math.max(1, ne0);
   var eMax = 0; for (i = Math.round(0.25 * r95); i <= Math.round(0.95 * r95) && i < nb; ++i) eMax = Math.max(eMax, eps[i]);
   var lb = eMax / Math.max(1e-6, e0);
   // simetria central (180°) dentro de R
   var sab = 0, saa = 0, sbb = 0, ma = 0, mb = 0, np = 0, pairs = [];
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
      var dx = x + 0.5 - cx, dy = y + 0.5 - cy; if (dx * dx + dy * dy > R * R) continue;
      var x2 = Math.floor(cx - dx), y2 = Math.floor(cy - dy); if (x2 < 0 || y2 < 0 || x2 >= w || y2 >= h) continue;
      pairs.push(L[y * w + x], L[y2 * w + x2]);
   }
   for (i = 0; i < pairs.length; i += 2) { ma += pairs[i]; mb += pairs[i + 1]; ++np; }
   ma /= Math.max(1, np); mb /= Math.max(1, np);
   for (i = 0; i < pairs.length; i += 2) { var u = pairs[i] - ma, v = pairs[i + 1] - mb; sab += u * v; saa += u * u; sbb += v * v; }
   var sym = (saa > 0 && sbb > 0) ? sab / Math.sqrt(saa * sbb) : 0;
   return { q: q, phi: phi, qAll: mAll.q, phiAll: mAll.phi, sym: sym, lb: lb, conc: r80 / Math.max(0.5, r20), r20: r20, r80: r80, r95: r95, nb: nb, S: S, prof: prof, eps: eps, peak: pk, ch: ch, L: L };
}

// ----------------------------------------------------------------------------
// CLASIFICADOR. info = { type ("pn"|"galaxy"|"nebula"|"other"|...), subtype ("snr"|"unknown"|""), otype (SIMBAD), sizeArcmin }
// meas = fvVolMeasure(...). -> { family ("shell"|"disk"|null), conf (0..1), score: { shell, disk }, prior, why: [texto] }
// Puntuacion = prior del catalogo (si lo hay) + evidencia de la imagen, cada termino continuo y acotado. Sin catalogo, solo la imagen (con
// un listón mas alto: SCORE_MIN se aplica igual pero la evidencia sola da como mucho 0,6). Fallback (family null) si gana con poca ventaja o
// poca puntuacion, o si la imagen contradice al catalogo (simetria central < 0,35: la segmentacion recogio otra cosa).
// ----------------------------------------------------------------------------
var FV_VOLM_SHELL_OT = { "PN": 1, "PN?": 1, "SNR": 1, "SNR?": 1, "bub": 1, "Bub": 1, "WR*": 0.5, "HII": 0.3 };
function fvVolPrior(info) {
   var ty = info.type || "", st = info.subtype || "", ot = info.otype || "";
   if (ty === "pn" || st === "snr" || FV_VOLM_SHELL_OT[ot] === 1) return { shell: 1, disk: 0, src: "catalogue: " + (ot || ty || st) };
   if (ty === "galaxy" || /^(G|GiG|GiP|GiC|BiC|IG|PaG|SBG|SyG|Sy1|Sy2|AGN|LIN|SFG|bCG|EmG|H2G|LSB|rG|Sy|QSO)$/.test(ot)) return { shell: 0, disk: 1, src: "catalogue: " + (ot || ty) };
   if (ty === "nebula") return { shell: (FV_VOLM_SHELL_OT[ot] || 0.2), disk: 0, src: "catalogue: " + (ot || ty) + " (weak)" };
   return { shell: 0, disk: 0, src: "no catalogue type" };
}
function fvVolClassify(info, meas) {
   var pr = fvVolPrior(info || {}), why = [pr.src], m = meas;
   // evidencia de la imagen, cada una en [0, 1]
   var eLB = fvvSmooth((m.lb - 1.0) / 0.6), eCen = fvvSmooth((1.15 - m.lb) / 0.4);      // borde brillante / centro lleno
   var eSym = fvvSmooth((m.sym - 0.35) / 0.45);                                          // simetria central
   var eConcLo = fvvSmooth((3.2 - m.conc) / 1.2), eConcHi = fvvSmooth((m.conc - 2.6) / 1.4);
   var eRound = fvvSmooth((m.q - 0.55) / 0.35);
   var imgShell = 0.45 * eLB + 0.25 * eSym + 0.15 * eConcLo + 0.15 * eRound;
   var imgDisk = 0.40 * eCen + 0.25 * eSym + 0.35 * eConcHi;
   var hasPrior = (pr.shell + pr.disk) > 0, wP = hasPrior ? 0.55 : 0;
   var sS = wP * pr.shell + (1 - wP) * imgShell, sD = wP * pr.disk + (1 - wP) * imgDisk;
   if (!hasPrior) { sS *= 0.85; sD *= 0.85; }   // sin catalogo la imagen sola no basta para estar muy seguro
   var fam = sS >= sD ? "shell" : "disk", best = Math.max(sS, sD), second = Math.min(sS, sD), conf = best > 0 ? (best - second) / best : 0;
   why.push("image: limb " + m.lb.toFixed(2) + ", 180° symmetry " + m.sym.toFixed(2) + ", r80/r20 " + m.conc.toFixed(2) + ", b/a " + m.q.toFixed(2));
   var out = { family: fam, conf: conf, score: { shell: sS, disk: sD }, prior: pr, why: why };
   if (FV_VOLM.BREAK === "noclass") { out.family = null; why.push("BREAK noclass"); return out; }
   if (m.sym < 0.35 && FV_VOLM.BREAK !== "noguard") { out.family = null; why.push("fallback: the cut is not centrally symmetric (" + m.sym.toFixed(2) + "): probably more than one object"); return out; }
   if (best < FV_VOLM.SCORE_MIN || best - second < FV_VOLM.MARGIN_MIN) { out.family = null; why.push("fallback: low confidence (" + best.toFixed(2) + " vs " + second.toFixed(2) + ")"); return out; }
   if (!FV_VOLM.FAM[fam]) { out.family = null; why.push("fallback: family " + fam + " switched off"); return out; }
   why.push(fam + " (" + best.toFixed(2) + " vs " + second.toFixed(2) + ")");
   return out;
}

// ----------------------------------------------------------------------------
// EL MODELO de un objeto compacto. cut Uint32 w·h; geom { w, h, cx, cy, rMax }; cls = fvVolClassify(...) (o { family } forzado)
// opts: { asym, flat (ROJO: el recorte sustituido por su perfil medio), seed }
// -> m = { family, w, h, cx, cy, q, phi, cp, sp, nb, D, eps: [3], ch, head, ... } (shell: kappa, A, asym, z0 · disk: inc, ci, si, q0, fd, wind)
// ----------------------------------------------------------------------------
function fvVolBuild(cut, geom, cls, opts, meas) {
   var o = opts || {}, fam = cls && cls.family;
   if (fam !== "shell" && fam !== "disk") return null;
   var M = meas || fvVolMeasure(cut, geom), w = geom.w, h = geom.h, n = w * h, cx = geom.cx, cy = geom.cy, R = Math.max(3, geom.rMax), i, c, x, y;
   var ch = M.ch, q = M.q, phi = M.phi, cp = Math.cos(phi), sp = Math.sin(phi), S = M.S, nb = M.nb;
   var m = { family: fam, w: w, h: h, cx: cx, cy: cy, R: R, q: q, phi: phi, cp: cp, sp: sp, nb: nb, ch: ch, S: S, head: (FV_VOLM.BREAK === "nohead") ? 1 : (FV_VOLM.HEAD[fam] || 1), meas: { lb: M.lb, sym: M.sym, conc: M.conc, q: M.q, qAll: M.qAll } };
   // perfil medio por canal en anillos elipticos de 1 px y su emisividad (Abel)
   var prof = [], eps = [], cnt = new Float64Array(nb);
   for (c = 0; c < 3; ++c) prof.push(new Float64Array(nb));
   if (fam === "disk") {
      // DISCO: el perfil del disco es la MEDIANA del anillo (el viento ocupa menos de medio anillo: no la mueve); con ella, la fraccion de disco
      // de cada pixel fd_c = min(1, WIND_M · perfil / valor). Lo que sobra (1 − fd) es la componente perpendicular (viento / halo).
      var rings = []; for (i = 0; i < nb; ++i) rings.push([[], [], []]);
      for (i = 0; i < n; ++i) { var bi = Math.floor(S[i]); if (bi >= nb) continue; for (c = 0; c < 3; ++c) rings[bi][c].push(ch[c][i]); }
      for (i = 0; i < nb; ++i) for (c = 0; c < 3; ++c) prof[c][i] = fvvMedian(rings[i][c]);
      rings = null;
      var wq = FV_VOLM.WIND_Q, ww = (FV_VOLM.BREAK === "nowind") ? 0 : fvvSmooth((wq[1] - q) / (wq[1] - wq[0]));
      m.windW = ww;
      var fd = [new Float32Array(n), new Float32Array(n), new Float32Array(n)], Cw = [new Float32Array(n), new Float32Array(n), new Float32Array(n)], wLight = 0, tLight = 0;
      for (i = 0; i < n; ++i) {
         var b2 = Math.min(nb - 1, Math.floor(S[i]));
         for (c = 0; c < 3; ++c) {
            var v = ch[c][i], pm = FV_VOLM.WIND_M * prof[c][b2], f = (v > 0) ? Math.min(1, pm / v) : 1;
            f = 1 - ww * (1 - f); fd[c][i] = f; Cw[c][i] = v * (1 - f); wLight += v * (1 - f); tLight += v;
         }
      }
      m.fd = fd; m.windFrac = tLight > 0 ? wLight / tLight : 0;
      // el perfil del disco para invertir: la media de lo que es disco (fd·C) en cada anillo
      for (c = 0; c < 3; ++c) for (i = 0; i < nb; ++i) prof[c][i] = 0;
      for (i = 0; i < n; ++i) { var b3 = Math.floor(S[i]); if (b3 >= nb) continue; cnt[b3] += 1; for (c = 0; c < 3; ++c) prof[c][b3] += ch[c][i] * fd[c][i]; }
      for (c = 0; c < 3; ++c) { for (i = 0; i < nb; ++i) prof[c][i] = cnt[i] > 0 ? prof[c][i] / cnt[i] : 0; eps.push(fvvGauss1(fvvOnion(fvvGauss1(prof[c], FV_VOLM.ABEL_SMOOTH)), FV_VOLM.EPS_SMOOTH)); }
      var q0 = FV_VOLM.GAL_Q0, c2 = Math.max(0, (q * q - q0 * q0) / (1 - q0 * q0));
      m.q0 = q0; m.inc = Math.acos(Math.min(1, Math.sqrt(c2))); m.ci = Math.cos(m.inc); m.si = Math.sin(m.inc); m.D = 2 * nb; m.kappa = 1;
      // VIENTO / HALO: simetria CILINDRICA alrededor del eje menor proyectado (la normal del disco, casi en el cielo cuando hay viento: q < 0,7 ->
      // i > ~47°; aproximacion: el eje se toma EN el plano del cielo). Por cada fila de altura yp (1 px), Abel en |xp| -> j_c(yp, ρ).
      if (ww > 0 && m.windFrac > 0.002) {
         var ny = 2 * nb + 1, nr = nb, jr = [], cntR = [];
         for (c = 0; c < 3; ++c) { var rows = []; for (y = 0; y < ny; ++y) rows.push(new Float64Array(nr)); jr.push(rows); }
         for (y = 0; y < ny; ++y) cntR.push(new Float64Array(nr));
         for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
            var i2 = y * w + x, dx = x + 0.5 - cx, dy = y + 0.5 - cy, xp = dx * cp + dy * sp, yp = -dx * sp + dy * cp, ry = Math.round(yp) + nb, rr = Math.floor(Math.abs(xp));
            if (ry < 0 || ry >= ny || rr >= nr) continue;
            cntR[ry][rr] += 1; for (c = 0; c < 3; ++c) jr[c][ry][rr] += Cw[c][i2];
         }
         for (c = 0; c < 3; ++c) for (y = 0; y < ny; ++y) { var row = jr[c][y]; for (i = 0; i < nr; ++i) row[i] = cntR[y][i] > 0 ? row[i] / cntR[y][i] : 0; jr[c][y] = fvvOnion(fvvGauss1(row, FV_VOLM.ABEL_SMOOTH)); }
         // suavizado entre filas (sin rayas de una fila a otra)
         for (c = 0; c < 3; ++c) for (i = 0; i < nr; ++i) { var col = new Float64Array(ny); for (y = 0; y < ny; ++y) col[y] = jr[c][y][i]; col = fvvGauss1(col, FV_VOLM.WIND_SMOOTH); for (y = 0; y < ny; ++y) jr[c][y][i] = col[y]; }
         m.wind = { j: jr, ny: ny, nr: nr, y0: nb };
      } else m.wind = null;
   } else {
      for (i = 0; i < n; ++i) { var b4 = Math.floor(S[i]); if (b4 >= nb) continue; cnt[b4] += 1; for (c = 0; c < 3; ++c) prof[c][b4] += ch[c][i]; }
      for (c = 0; c < 3; ++c) { for (i = 0; i < nb; ++i) prof[c][i] = cnt[i] > 0 ? prof[c][i] / cnt[i] : 0; eps.push(fvvGauss1(fvvOnion(fvvGauss1(prof[c], FV_VOLM.ABEL_SMOOTH)), FV_VOLM.EPS_SMOOTH)); }
      // semieje de profundidad (en unidades del eje mayor): √q (esfera de radio √(ab)) si es redonda; q (= b: prolato alrededor del eje mayor) si es alargada
      var tLong = (FV_VOLM.BREAK === "sphere") ? 0 : fvvSmooth((FV_VOLM.Q_ROUND - q) / (FV_VOLM.Q_ROUND - FV_VOLM.Q_LONG));
      m.kappa = Math.pow(q, 0.5 + 0.5 * tLong); m.prolate = tLong;
      m.D = 2 * Math.ceil(m.kappa * nb) + 2;
      m.asym = (o.asym !== undefined) ? o.asym : FV_VOLM.ASYM; m.z0 = Math.max(1, FV_VOLM.ASYM_Z0 * R);
      if (m.asym > 0) { var A = new Float32Array(n), cell = Math.max(3, FV_VOLM.ASYM_CELL * R), sd = (o.seed || FV_VOLM.SEED); for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) A[y * w + x] = 2 * fvvNoise3(x / cell, y / cell, 0.37, sd) - 1; m.A = A; }
      else m.A = null;
   }
   m.eps = eps; m.prof = prof;
   if (o.flat) { var ch2 = [new Float32Array(n), new Float32Array(n), new Float32Array(n)]; for (i = 0; i < n; ++i) { var bb = Math.min(nb - 1, Math.floor(S[i])); for (c = 0; c < 3; ++c) ch2[c][i] = prof[c][bb]; } m.ch = ch2; m.fd = null; m.wind = null; }
   return m;
}
// la emisividad SIN normalizar de la columna (x, y) entera a la profundidad z (px, 0 = plano del centro), por canal -> out[3]
// disco: dos partes (disco y viento), cada una sin normalizar: outD[3], outW[3]
function fvVolUnShell(m, x, y, z, out) {
   var dx = x + 0.5 - m.cx, dy = y + 0.5 - m.cy, xp = dx * m.cp + dy * m.sp, yp = -dx * m.sp + dy * m.cp, s2 = xp * xp + (yp / m.q) * (yp / m.q);
   var r = Math.sqrt(s2 + (z / m.kappa) * (z / m.kappa)), aF = m.A ? m.asym * m.A[y * m.w + x] : 0, f = aF ? 1 + aF * z / Math.sqrt(z * z + m.z0 * m.z0) : 1;
   out[0] = fvvEpsAt(m.eps[0], r) * f; out[1] = fvvEpsAt(m.eps[1], r) * f; out[2] = fvvEpsAt(m.eps[2], r) * f;
}
function fvVolUnDisk(m, x, y, z, outD, outW) {
   var dx = x + 0.5 - m.cx, dy = y + 0.5 - m.cy, xp = dx * m.cp + dy * m.sp, yp = -dx * m.sp + dy * m.cp;
   var Z = yp * m.si + z * m.ci, Rb = yp * m.ci - z * m.si, r = Math.sqrt(xp * xp + Rb * Rb + (Z / m.q0) * (Z / m.q0));
   outD[0] = fvvEpsAt(m.eps[0], r); outD[1] = fvvEpsAt(m.eps[1], r); outD[2] = fvvEpsAt(m.eps[2], r);
   var Wd = m.wind;
   if (!Wd) { outW[0] = outW[1] = outW[2] = 0; return; }
   var fy = yp + Wd.y0, iy = Math.floor(fy), ty = fy - iy, rho = Math.sqrt(xp * xp + z * z);
   for (var c = 0; c < 3; ++c) {
      var a = (iy >= 0 && iy < Wd.ny) ? fvvEpsAt(Wd.j[c][iy], rho) : 0, b = (iy + 1 >= 0 && iy + 1 < Wd.ny) ? fvvEpsAt(Wd.j[c][iy + 1], rho) : 0;
      outW[c] = a + (b - a) * ty;
   }
}
// LA COLUMNA (x, y): p_c(z_k), k = 0..D−1 (z_k = k + 0,5 − D/2), normalizada por canal (y mezclada disco/viento con fd). out Float64Array(3·D)
var FV_VOLM_TMP = { a: [0, 0, 0], b: [0, 0, 0], colW: null };
function fvVolColumn(m, x, y, out) {
   var D = m.D, k, c, s3 = [0, 0, 0], a = FV_VOLM_TMP.a, b = FV_VOLM_TMP.b;
   if (m.family === "disk") {
      var sW = [0, 0, 0], cw = FV_VOLM_TMP.colW; if (!cw || cw.length < 3 * D) cw = FV_VOLM_TMP.colW = new Float64Array(3 * D);
      for (k = 0; k < D; ++k) { fvVolUnDisk(m, x, y, k + 0.5 - D / 2, a, b); for (c = 0; c < 3; ++c) { out[k * 3 + c] = a[c]; s3[c] += a[c]; cw[k * 3 + c] = b[c]; sW[c] += b[c]; } }
      var i = y * m.w + x, rw = (m.part === "rest" && m.restW) ? m.restW[i] : 1;   // (V3) «resto»: solo la parte de disco que queda fuera de la caja de fv_volume3.js + el viento
      for (c = 0; c < 3; ++c) {
         var f = m.fd ? m.fd[c][i] : 1, okD = s3[c] > 1e-12, okW = sW[c] > 1e-12;
         if (!okW) f = 1; if (!okD) f = okW ? 0 : 1;
         for (k = 0; k < D; ++k) out[k * 3 + c] = (okD ? f * rw * out[k * 3 + c] / s3[c] : 0) + (okW ? (1 - f) * cw[k * 3 + c] / sW[c] : 0);
         s3[c] = okD || okW ? 1 : 0;
      }
   } else {
      for (k = 0; k < D; ++k) { fvVolUnShell(m, x, y, k + 0.5 - D / 2, a); for (c = 0; c < 3; ++c) { out[k * 3 + c] = a[c]; s3[c] += a[c]; } }
      for (c = 0; c < 3; ++c) if (s3[c] > 1e-12) { for (k = 0; k < D; ++k) out[k * 3 + c] /= s3[c]; s3[c] = 1; }
   }
   // columna sin soporte en el modelo: gaussiana de 2 px en z = 0 (la luz nunca se pierde)
   var rwF = (m.part === "rest" && m.restW) ? m.restW[y * m.w + x] : 1;
   for (c = 0; c < 3; ++c) if (!(s3[c] > 0)) { var tot = 0; for (k = 0; k < D; ++k) { var zz = k + 0.5 - D / 2, g = Math.exp(-zz * zz / 8); out[k * 3 + c] = g; tot += g; } for (k = 0; k < D; ++k) out[k * 3 + c] *= rwF / tot; }
   return out;
}
// UNA PILA DE CORTES. axis "Z" | "X" | "Y"; N cortes; ds = bins de profundidad del corte lateral (≤ D). Los valores se guardan a 1/head.
// -> { axis, N, D, Dz, gw, gh, head, cuts: [ { px: Uint32Array, bw, bh, u0, v0 } | null ] }
// (V3, ronda 3, V2-4) LAMINA DE DETALLE de la cascara, SOLO en la pila Z (la que se ve de frente). CAUSA MEDIDA de la fidelidad baja a la
// llegada (nC C13 0,46 frente a 0,61 de las capas de hoy): con V = C·p(z) cada pixel reparte su luz entre la pared de delante y la de detras;
// desde la distancia de llegada las dos se ven a escalas distintas y el detalle fino sale doble (la misma causa que el borron de la nebulosa
// gruesa, prueba del 5-nov). Arreglo: en la pila Z la parte FINA de la foto (C menos su suelo suave: erosion + suavizado de SHEET_R px del
// modelo) va a UNA superficie, el plano medio z = 0 (SHEET_POS "mid"; las capas de hoy ponen el nucleo ahi); el suelo suave sigue repartido por
// p(z) (es liso: no se duplica nada). Desde la Tierra la suma por columna es la misma (C): el frente no cambia. Las pilas de lado (X/Y) no la
// llevan: de lado la lamina seria una raya brillante; entre medias se funden con la regla de siempre (cos²).
// HIPOTESIS REFUTADA (nC, 5-nov): la lamina en la PARED DE DELANTE (donde la columna acumula el 15 % de su luz) y en las tres pilas bajo la
// fidelidad a 0,19 (< ROJO 0,21): de cerca la pared de delante se ve un 20 % mas grande que el plano por el centro y el detalle no casa.
// FV_VOLM3.SHEET = fraccion de la parte fina que va a la lamina (0 = la fase 2, ROJO).
function fvVolSheetLow(m) {
   if (m._low) return m._low;
   var w = m.w, h = m.h, n = w * h, r = Math.max(1, Math.round(FV_VOLM3.SHEET_R)), low = [];
   for (var c = 0; c < 3; ++c) {
      var ng = new Float32Array(n), i; for (i = 0; i < n; ++i) ng[i] = -m.ch[c][i];
      var er = fv3MaxF(ng, w, h, r); for (i = 0; i < n; ++i) er[i] = -er[i];
      var bl = fv3Box3(er, w, h, r); for (i = 0; i < n; ++i) bl[i] = Math.max(0, Math.min(m.ch[c][i], bl[i]));
      low.push(bl);
   }
   m._low = low;
   return low;
}
function fvVolSheet(m, x, y, out) {
   var D = m.D, i = y * m.w + x, low = fvVolSheetLow(m), Q = FV_VOLM3, k, c, cum = 0, kf = D / 2, tot = 0;
   if (Q.SHEET_POS === "front") {   // (refutada, se deja para la prueba) la pared de delante: donde la luz acumulada desde la Tierra llega a SHEET_Q
      for (k = 0; k < D; ++k) tot += out[k * 3] + out[k * 3 + 1] + out[k * 3 + 2];
      if (!(tot > 0)) return;
      for (k = 0; k < D; ++k) { var dk = out[k * 3] + out[k * 3 + 1] + out[k * 3 + 2]; if (cum + dk >= Q.SHEET_Q * tot) { kf = k + (Q.SHEET_Q * tot - cum) / Math.max(1e-12, dk); break; } cum += dk; }
   }
   var g = FV_VOLM_TMP.sheetG; if (!g || g.length < D) g = FV_VOLM_TMP.sheetG = new Float64Array(D);
   var gs = 0, inv = 1 / (2 * Q.SHEET_S * Q.SHEET_S);
   for (k = 0; k < D; ++k) { var dz = k + 0.5 - kf; g[k] = Math.exp(-dz * dz * inv); gs += g[k]; }
   for (c = 0; c < 3; ++c) {
      var C = m.ch[c][i]; if (!(C > 0)) continue;
      var fh = Q.SHEET * (C - low[c][i]) / C; if (!(fh > 0)) continue;
      for (k = 0; k < D; ++k) out[k * 3 + c] = (1 - fh) * out[k * 3 + c] + fh * g[k] / gs;
   }
}
function fvVolStack(m, axis, N, ds) {
   var w = m.w, h = m.h, D = m.D, Dz = Math.max(1, Math.min(D, ds || D)), zk = Dz / D, ch = m.ch, hk = 1 / (m.head || 1), x, y, k, j;
   var gw = (axis === "Z") ? w : (axis === "X" ? Dz : w), gh = (axis === "Z") ? h : (axis === "X" ? h : Dz), G = gw * gh;
   var acc = []; for (j = 0; j < N; ++j) acc.push(new Float32Array(G * 3));
   var col = new Float64Array(3 * D), fl = FV_VOLM.ZBIN === "floor";
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
      var i = y * w + x, C0 = ch[0][i] * hk, C1 = ch[1][i] * hk, C2 = ch[2][i] * hk;
      if (!(C0 > 0 || C1 > 0 || C2 > 0)) continue;
      fvVolColumn(m, x, y, col);
      if (axis === "Z" && m.family === "shell" && typeof FV_VOLM3 !== "undefined" && FV_VOLM3.ON && FV_VOLM3.SHEET > 0) fvVolSheet(m, x, y, col);
      if (axis === "Z") {
         for (k = 0; k < D; ++k) { var a = acc[Math.min(N - 1, Math.floor(k * N / D))], o3 = i * 3; a[o3] += C0 * col[k * 3]; a[o3 + 1] += C1 * col[k * 3 + 1]; a[o3 + 2] += C2 * col[k * 3 + 2]; }
      } else {
         var aL = (axis === "X") ? acc[Math.min(N - 1, Math.floor(x * N / w))] : acc[Math.min(N - 1, Math.floor(y * N / h))];
         for (k = 0; k < D; ++k) {
            // el bin k de profundidad cubre [k·zk, (k+1)·zk) texeles: se reparte por SOLAPE entre los dos texeles que toca (sonda V, pasada 4)
            var t0 = k * zk, ta = Math.min(Dz - 1, Math.floor(t0)), tb = Math.min(Dz - 1, Math.floor((k + 1) * zk - 1e-9)), wa = fl ? zk : (tb > ta ? (ta + 1 - t0) : zk), wb = fl ? 0 : zk - wa;
            var ia = ((axis === "X") ? (y * Dz + ta) : (ta * w + x)) * 3, ib = ((axis === "X") ? (y * Dz + tb) : (tb * w + x)) * 3;
            aL[ia] += C0 * col[k * 3] * wa; aL[ia + 1] += C1 * col[k * 3 + 1] * wa; aL[ia + 2] += C2 * col[k * 3 + 2] * wa;
            if (wb > 0) { aL[ib] += C0 * col[k * 3] * wb; aL[ib + 1] += C1 * col[k * 3 + 1] * wb; aL[ib + 2] += C2 * col[k * 3 + 2] * wb; }
         }
      }
   }
   var st = fvVolQuantize(acc, gw, gh, N, m.seedQ || FV_VOLM.SEED);
   st.axis = axis; st.D = D; st.Dz = Dz; st.head = m.head || 1;
   return st;
}
// cuantizacion con difusion del error A LO LARGO DE LA PILA (Σ pila = valor ± 1 nivel sin perder la luz debil) + recorte de cada corte
function fvVolQuantize(acc, gw, gh, N, seed) {
   var G = gw * gh, rnd = fvvRng(seed), out = [], j, q, c, outPx = [];
   for (j = 0; j < N; ++j) outPx.push(new Uint32Array(G));
   for (q = 0; q < G; ++q) for (c = 0; c < 3; ++c) {
      var u = (FV_VOLM.PHASE === "coherent") ? 0 : rnd() - 0.5, S = 0, prev = Math.round(u), sh = 16 - 8 * c;
      if (FV_VOLM.QUANT === "round") { for (j = 0; j < N; ++j) { var e0 = Math.max(0, Math.min(255, Math.round(acc[j][q * 3 + c]))); if (e0) outPx[j][q] |= e0 << sh; } continue; }
      for (j = 0; j < N; ++j) { S += acc[j][q * 3 + c]; var r = Math.round(S + u), e = Math.max(0, Math.min(255, r - prev)); prev = r; if (e) outPx[j][q] |= e << sh; }
   }
   for (j = 0; j < N; ++j) {
      var P = outPx[j], x0 = gw, y0 = gh, x1 = -1, y1 = -1, x, y;
      for (y = 0; y < gh; ++y) for (x = 0; x < gw; ++x) if (P[y * gw + x]) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
      if (x1 < 0) { out.push(null); continue; }
      x0 = Math.max(0, x0 - 1); y0 = Math.max(0, y0 - 1); x1 = Math.min(gw - 1, x1 + 1); y1 = Math.min(gh - 1, y1 + 1);
      var bw = x1 - x0 + 1, bh = y1 - y0 + 1, px = new Uint32Array(bw * bh);
      for (y = 0; y < bh; ++y) for (x = 0; x < bw; ++x) px[y * bw + x] = (0xff000000 | P[(y + y0) * gw + x + x0]) >>> 0;
      out.push({ px: px, bw: bw, bh: bh, u0: x0, v0: y0 });
      outPx[j] = null;
   }
   return { N: N, gw: gw, gh: gh, cuts: out };
}
// el HOMBRO del lienzo: el lienzo guarda v = brillo/head (0..255, 8 bits); lut[v] = brillo de pantalla 0..255. Lineal exacto hasta la rodilla
// (KNEE·255); por encima, exponencial que en el tope del lienzo (brillo head·255) llega a ~252 (1 − e^−3): sin escalon y sin quemar.
// (V3, hallazgo H-2 de la revision de Codex, comprobado: con head 2 el original 250 se guarda 125 y salia 223, −10,8 % desde la Tierra sin error
// geometrico) s ∈ [0, 1] = fuerza del hombro: 0 = lineal exacto hasta 255 (y recorte), 1 = el hombro de la fase 2. El pintor la gradua con lo
// que la vista se aparta de la de la Tierra (fvVolLutAt de fv_volume_paint.js). Sin s, 1 (la fase 2).
function fvVolShoulderLut(head, s) {
   if (s === undefined) s = 1;
   var H = Math.max(1, head), lut = new Uint8Array(256), k = 255 * (1 - Math.max(0, Math.min(1, s)) * (1 - FV_VOLM.KNEE)), tau = Math.max(1, (H * 255 - k) / 3);
   for (var v = 0; v < 256; ++v) { var x = v * H; lut[v] = (H === 1 || x <= k || k >= 254.5) ? Math.min(255, Math.round(x)) : Math.min(255, Math.round(k + (255 - k) * (1 - Math.exp(-(x - k) / tau)))); }
   return { lut: lut, head: H, s: s };
}
// MODELO COMPLETO desde el recorte: medir -> clasificar -> construir (con rejilla reducida si el recorte es grande). geom en px del recorte.
// -> { cls, meas, m (o null = fallback), ds }
function fvVolFromCut(cut, geom, info, opts) {
   var ds = Math.max(1, Math.ceil(Math.max(geom.w, geom.h) / FV_VOLM.GRID_MAX)), dc = fvvDownCut(cut, geom.w, geom.h, ds);
   var g2 = { w: dc.w, h: dc.h, cx: geom.cx / ds, cy: geom.cy / ds, rMax: geom.rMax / ds };
   var meas = fvVolMeasure(dc.cut, g2), cls = fvVolClassify(info, meas), m = cls.family ? fvVolBuild(dc.cut, g2, cls, opts, meas) : null;
   if (m) m.ds = ds;
   return { cls: cls, meas: meas, m: m, ds: ds, geom: g2 };
}
// (pruebas y referencia) RENDER ORTOGRAFICO EXACTO del modelo en la direccion d (marco del objeto: x derecha, y abajo, z alejandose de la
// Tierra), integrando V = C · p a lo largo de cada rayo (paso 0,5 px, columna mas proxima). Independiente del pintor de Qt: es el instrumento
// contra el que se valida la forma. -> { img: Float32Array(size² · 3), size }
function fvVolRenderOrtho(m, d, size, scale) {
   var w = m.w, h = m.h, D = m.D, cx = m.cx, cy = m.cy, sz = size || 128, img = new Float32Array(sz * sz * 3), L = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
   var dd = [d[0] / L, d[1] / L, d[2] / L], up = Math.abs(dd[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
   var e1 = [up[1] * dd[2] - up[2] * dd[1], up[2] * dd[0] - up[0] * dd[2], up[0] * dd[1] - up[1] * dd[0]], l1 = Math.sqrt(e1[0] * e1[0] + e1[1] * e1[1] + e1[2] * e1[2]); e1 = [e1[0] / l1, e1[1] / l1, e1[2] / l1];
   var e2 = [dd[1] * e1[2] - dd[2] * e1[1], dd[2] * e1[0] - dd[0] * e1[2], dd[0] * e1[1] - dd[1] * e1[0]];
   // si mira de frente (d = +z), que e1 = +x y e2 = +y (la imagen sale como la foto)
   if (Math.abs(dd[2]) > 0.999) { e1 = [1, 0, 0]; e2 = [0, dd[2] > 0 ? 1 : -1, 0]; }
   var ext = scale || Math.max(w, h, D), pxs = ext / sz, cols = {}, colBuf = new Float64Array(3 * D), half = ext * 0.9;
   function colOf(ix, iy) { var key = iy * w + ix, cc = cols[key]; if (!cc) { fvVolColumn(m, ix, iy, colBuf); cc = cols[key] = Float32Array.from(colBuf); } return cc; }
   for (var v = 0; v < sz; ++v) for (var u = 0; u < sz; ++u) {
      var a = (u + 0.5 - sz / 2) * pxs, b = (v + 0.5 - sz / 2) * pxs, s0 = 0, s1 = 0, s2 = 0;
      for (var t = -half; t <= half; t += 0.5) {
         var X = cx + a * e1[0] + b * e2[0] + t * dd[0], Y = cy + a * e1[1] + b * e2[1] + t * dd[1], Zz = a * e1[2] + b * e2[2] + t * dd[2];
         var ix = Math.floor(X), iy = Math.floor(Y), k = Math.floor(Zz + D / 2);
         if (ix < 0 || iy < 0 || ix >= w || iy >= h || k < 0 || k >= D) continue;
         var i = iy * w + ix; if (!(m.ch[0][i] > 0 || m.ch[1][i] > 0 || m.ch[2][i] > 0)) continue;
         var cc = colOf(ix, iy);
         s0 += 0.5 * m.ch[0][i] * cc[k * 3]; s1 += 0.5 * m.ch[1][i] * cc[k * 3 + 1]; s2 += 0.5 * m.ch[2][i] * cc[k * 3 + 2];
      }
      var o = (v * sz + u) * 3; img[o] = s0; img[o + 1] = s1; img[o + 2] = s2;
   }
   return { img: img, size: sz, pxs: pxs };
}

// ============================================================================
// NEBULOSA EXTENSA («slab»): la nebulosa del fondo de la foto en CORTES con polvo que ABSORBE (fase 2, 5-nov-2026).
// ----------------------------------------------------------------------------
// EL MODELO ES EL DEL VISOR WEB (web/fw_relief.js, relieve v2 «cuerpo + 3 laminas + polvo», F3b/F3c): mismos mapas (los calcula la MISMA
// funcion fwReliefBuild sobre la misma foto sin estrellas y sin objetos, reducida a FW_RELIEF.NX de ancho) y mismo reparto de la luz:
//   · CUERPO: KB × la foto muy suavizada (con el tono local), perfil gaussiano en profundidad (centro cD, anchura sD por pixel);
//   · 3 LAMINAS: el detalle de la foto POR ENCIMA del cuerpo (H·(1 − lB/lH), con el color de la foto), pesos SHEETS[i].wt, en cS_i;
//   · POLVO: donde la foto queda POR DEBAJO del cuerpo (pilares, globulos, bordes oscuros), la lamina de delante (cS_0) ABSORBE en gris
//     con la transmision x' de fw_gl.js (lo que hay del cuerpo detras del polvo se atenua lo justo para que desde la Tierra salga la foto).
// El relieve sale de la ESTRUCTURA de la propia foto (escalas grande y media, bordes oscuros), sin ruido inventado — y el polvo DELANTE de la
// emision es lo que da el drama al moverse: la silueta oscura tapa el gas brillante de detras y deja ver su borde (paralaje con oclusion).
// DISCRETIZACION (lo unico propio de PixInsight): Ke cortes de emision (Add) en el tramo de profundidad ocupado, y el polvo en cortes que se
// componen en Multiply justo delante de su corte de emision (el pintor los ordena de lejos a cerca respecto a la camara). Cada lamina fina se
// ensancha a ≥ SIG_MIN cortes (si no, cada pixel caeria entero en un corte y la frontera entre cortes seria una costura).
// INVARIANTE: desde la Tierra, Σ_k e_k · Π_{polvo delante de k} T = la foto sin estrellas (normalizacion EXACTA por pixel y canal tras
// discretizar; error medido en las pruebas). Banderas: FV_VOLM.FAM.slab; FV_VOLM.SLAB.DUST (false = ROJO sin polvo).
// ============================================================================
FV_VOLM.SLAB = {
   KE: 12,            // cortes de emision en el tramo ocupado (sonda V: 8 capas de hoy cuestan 14–21 ms; 12 + polvo, medido en fv_V2_*)
   SIG_MIN: 0.6,      // anchura minima de una lamina, en cortes (anti-costura)
   DUST: true,        // false = ROJO (sin polvo: la silueta no tapa nada al moverse)
   DUST_HALF: true,   // el polvo a media resolucion (memoria: 12 cortes de 2048×1365 en gris = 134 MB; a la mitad, 34)
   PAD: 2.5,          // tramo ocupado = percentiles 1–99 de (cD ± PAD·sD) y de las laminas
   GAIN_CLAMP: [0.25, 4],   // la normalizacion por pixel no corrige mas alla de esto (lo que quede, al error medido)
   BREAK: ""          // "nonorm" (sin normalizacion: ROJO del invariante) · "nosig" (laminas sin ensanchar: ROJO de las costuras)
};
function fvvPhi(x) { x = x < -6 ? -6 : (x > 6 ? 6 : x); var t = 0.7978845608 * (x + 0.044715 * x * x * x), e = Math.exp(-2 * Math.abs(t)), th = (1 - e) / (1 + e); return 0.5 + 0.5 * (t < 0 ? -th : th); }
// pesos de un perfil gaussiano (centro c, anchura s, en w) en los Ke cortes [w0 + k·dw, w0 + (k+1)·dw), con las colas en los extremos (Σ = 1)
function fvvSliceW(c, s, w0, dw, Ke, out) {
   var prev = 0;
   for (var k = 0; k < Ke; ++k) { var b = (k === Ke - 1) ? 1 : fvvPhi((w0 + (k + 1) * dw - c) / s); out[k] = b - prev; prev = b; }
   return out;
}
// el tramo de profundidad ocupado por los mapas (percentiles 1 y 99)
function fvVolSlabRange(rel) {
   var n = rel.w * rel.h, lo = [], hi = [], K = FV_VOLM.SLAB, step = Math.max(1, Math.floor(n / 20000));
   for (var i = 0; i < n; i += step) {
      var cD = rel.rel[4 * i], sD = rel.rel[4 * i + 1];
      lo.push(cD - K.PAD * sD); hi.push(cD + K.PAD * sD);
      for (var j = 0; j < 3; ++j) { var cs = rel.sheets[4 * i + j]; lo.push(cs - 0.02); hi.push(cs + 0.02); }
   }
   lo.sort(function(a, b) { return a - b; }); hi.sort(function(a, b) { return a - b; });
   var w0 = Math.max(0, lo[Math.floor(0.01 * (lo.length - 1))]), w1 = Math.min(1, hi[Math.floor(0.99 * (hi.length - 1))]);
   if (!(w1 > w0 + 0.05)) { var m = 0.5 * (w0 + w1); w0 = Math.max(0, m - 0.025); w1 = Math.min(1, m + 0.025); }
   return { w0: w0, w1: w1 };
}
// LOS CORTES. photo Uint32 sw·sh (la foto sin estrellas SIN los objetos, a la resolucion de los cortes); rel = fwReliefBuild(...) (sus mapas
// rw × rh); prm = { KB, SHEETS (los de FW_RELIEF), edgeFrac (borde suave de las capas de hoy, FV_BUILD.EDGE), seed }
// -> { Ke, w0, dw, emit: [Uint32Array sw·sh], dust: [Uint32Array dsw·dsh | null], dsw, dsh, stats }
function fvVolSlabSlices(photo, sw, sh, rel, prm) {
   var K = FV_VOLM.SLAB, Ke = K.KE, rg = fvVolSlabRange(rel), w0 = rg.w0, dw = (rg.w1 - rg.w0) / Ke, rw = rel.w, rh = rel.h, n = sw * sh, i, k, c, x, y, j;
   var KB = prm.KB, SH = prm.SHEETS, sig0 = (K.BREAK === "nosig") ? 0 : K.SIG_MIN * dw, rnd = fvvRng(prm.seed || 911), dust = K.DUST && FV_VOLM.BREAK !== "nodust";
   var e = Math.max(4, Math.round((prm.edgeFrac || 0.18) * Math.max(sw, sh)));
   var emit = [];
   for (k = 0; k < Ke; ++k) emit.push(new Uint32Array(n));
   var half = dust && K.DUST_HALF, dsw = half ? Math.ceil(sw / 2) : sw, dsh = half ? Math.ceil(sh / 2) : sh, Tsum = [], Tcnt = new Float32Array(dsw * dsh), used = new Uint8Array(Ke);
   if (dust) for (k = 0; k < Ke; ++k) Tsum.push(new Float32Array(dsw * dsh));
   var bwk = new Float64Array(Ke), swk = [new Float64Array(Ke), new Float64Array(Ke), new Float64Array(Ke)], ek = new Float64Array(Ke * 3), Tk = new Float64Array(Ke), A = new Float64Array(Ke);
   var st = { clip: 0, gainLo: 0, gainHi: 0, nPix: 0, dustPix: 0, w0: w0, w1: rg.w1 };
   function smooth(t) { t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t); }
   var R = rel.rel, Sh = rel.sheets, Bo = rel.body, a00, a01, a10, a11, w00, w01, w10, w11;
   function bl(arr, ch) { return arr[4 * a00 + ch] * w00 + arr[4 * a01 + ch] * w01 + arr[4 * a10 + ch] * w10 + arr[4 * a11 + ch] * w11; }
   for (y = 0; y < sh; ++y) {
      var gy = (y + 0.5) / sh * rh - 0.5, iy = Math.max(0, Math.min(rh - 2, Math.floor(gy))), fy = Math.max(0, Math.min(1, gy - iy)), ey = smooth(Math.min(y, sh - 1 - y) / e); ey *= ey;
      for (x = 0; x < sw; ++x) {
         i = y * sw + x; var p = photo[i], ex = smooth(Math.min(x, sw - 1 - x) / e); ex = ex * ex * ey;
         if (ex <= 0 || !(p & 0xffffff)) continue;
         ++st.nPix;
         var gx = (x + 0.5) / sw * rw - 0.5, ix = Math.max(0, Math.min(rw - 2, Math.floor(gx))), fx = Math.max(0, Math.min(1, gx - ix));
         a00 = iy * rw + ix; a01 = a00 + 1; a10 = a00 + rw; a11 = a10 + 1; w00 = (1 - fx) * (1 - fy); w01 = fx * (1 - fy); w10 = (1 - fx) * fy; w11 = fx * fy;
         var cD = bl(R, 0), sD = Math.max(1e-4, bl(R, 1)), sS = bl(R, 2);
         var Hc = [((p >>> 16) & 255) * ex, ((p >>> 8) & 255) * ex, (p & 255) * ex], Bk = [KB * 255 * bl(Bo, 0) * ex, KB * 255 * bl(Bo, 1) * ex, KB * 255 * bl(Bo, 2) * ex];
         var lH = 0.2126 * Hc[0] + 0.7152 * Hc[1] + 0.0722 * Hc[2], lB = 0.2126 * Bk[0] + 0.7152 * Bk[1] + 0.0722 * Bk[2], fS = lH > 1e-4 ? Math.max(0, 1 - lB / lH) : 0;
         fvvSliceW(cD, Math.max(sD, sig0), w0, dw, Ke, bwk);
         for (j = 0; j < 3; ++j) fvvSliceW(bl(Sh, j), Math.max(sS * SH[j].mul, sig0), w0, dw, Ke, swk[j]);
         for (k = 0; k < Ke; ++k) for (c = 0; c < 3; ++c) ek[3 * k + c] = Bk[c] * bwk[k] + fS * Hc[c] * (SH[0].wt * swk[0][k] + SH[1].wt * swk[1][k] + SH[2].wt * swk[2][k]);
         // polvo en la lamina de delante: x = lH/lB; fb = parte del cuerpo detras del polvo (con el polvo repartido como la lamina 0)
         var anyT = false;
         for (k = 0; k < Ke; ++k) Tk[k] = 1;
         if (dust && lB > 0.5 && lH < lB) {
            var xr = lH / lB, fb = 0, cum = 0;
            for (k = 0; k < Ke; ++k) { cum += swk[0][k]; fb += bwk[k] * cum; }
            var xp = Math.max(0.003, Math.min(1, (xr - (1 - fb)) / Math.max(fb, 0.05)));
            for (k = 0; k < Ke; ++k) if (swk[0][k] > 1e-4) { Tk[k] = Math.pow(xp, swk[0][k]); anyT = true; }
            if (anyT) ++st.dustPix;
         }
         // atenuacion de cada corte (el polvo k va justo DELANTE de la emision k: la atenua) y NORMALIZACION exacta desde la Tierra
         var tr = 1; for (k = 0; k < Ke; ++k) { tr *= Tk[k]; A[k] = tr; }
         for (c = 0; c < 3; ++c) {
            var Rr = 0; for (k = 0; k < Ke; ++k) Rr += ek[3 * k + c] * A[k];
            var g = (K.BREAK === "nonorm" || !(Rr > 1e-6)) ? 1 : Hc[c] / Rr;
            if (g < K.GAIN_CLAMP[0]) { g = K.GAIN_CLAMP[0]; ++st.gainLo; } else if (g > K.GAIN_CLAMP[1]) { g = K.GAIN_CLAMP[1]; ++st.gainHi; }
            // cuantizacion con difusion del error a lo largo de la pila (Σ e_k = valor ± 1)
            var u = rnd() - 0.5, S = 0, prev = Math.round(u), shf = 16 - 8 * c;
            for (k = 0; k < Ke; ++k) { S += ek[3 * k + c] * g; var r = Math.round(S + u), v = r - prev; prev = r; if (v > 255) { v = 255; ++st.clip; } if (v > 0) { emit[k][i] |= v << shf; used[k] = 1; } }
         }
         if (dust) { var di = half ? ((y >> 1) * dsw + (x >> 1)) : i; Tcnt[di] += 1; for (k = 0; k < Ke; ++k) Tsum[k][di] += 1 - ex * (1 - Tk[k]); }
      }
   }
   for (k = 0; k < Ke; ++k) { var P = emit[k]; for (var q = 0; q < n; ++q) P[q] = (0xff000000 | P[q]) >>> 0; }
   var dOut = [];
   for (k = 0; k < Ke; ++k) {
      if (!dust) { dOut.push(null); continue; }
      var Ts = Tsum[k], any = false, D8 = new Uint32Array(dsw * dsh);
      for (var q2 = 0; q2 < dsw * dsh; ++q2) { var t = Tcnt[q2] > 0 ? Ts[q2] / Tcnt[q2] : 1, v8 = Math.max(0, Math.min(255, Math.round(255 * t))); if (v8 < 255) any = true; D8[q2] = (0xff000000 | (v8 << 16) | (v8 << 8) | v8) >>> 0; }
      dOut.push(any ? D8 : null);
   }
   st.used = Array.prototype.slice.call(used); st.dustSlices = dOut.filter(function(d) { return !!d; }).length;
   return { Ke: Ke, w0: w0, dw: dw, emit: emit, dust: dOut, dsw: dsw, dsh: dsh, sw: sw, sh: sh, stats: st };
}
// EL FONDO QUE EL POLVO TAPA (fase 2): con el cuerpo de fw_relief.js (la foto suavizada a R_BODY), un pilar oscuro de la escala del suavizado
// no queda POR DEBAJO de su cuerpo (el cuerpo tambien es oscuro alli) y no hay polvo: medido en IC 1848, T < 0,9 en el 0,0 % de la foto con
// KB 0,30 y en el 1,5 % con KB 0,75 (fv_V2_slab_node.log). Lo que un pilar tapa es el gas brillante de ALREDEDOR: el cuerpo pasa a ser la
// ENVOLVENTE SUPERIOR suave de la foto (maximo local en un radio ENV_R y suavizado del mismo radio), con el tono local de la foto. Asi lo
// oscuro de la escala de los pilares queda por debajo del cuerpo -> polvo delante, y el cuerpo detras es liso (sin «fantasma» del pilar).
// Se aplica sobre los mapas de fwReliefBuild (rel.body) y lo usan IGUAL PixInsight y el visor web (paridad). rgba = la misma entrada (w × h).
FV_VOLM.SLAB.ENV = true;        // false = ROJO (el cuerpo de fw_relief.js: casi sin polvo)
FV_VOLM.SLAB.ENV_R = 1 / 40;    // radio de la envolvente, fraccion del ancho (13 px de 512): mayor que un pilar de IC 1848 (≈ 1/60–1/25) — ELECCION nuestra [SIN NINO]
FV_VOLM.SLAB.KB = 0.7;          // parte de la envolvente que es cuerpo (el resto, detalle en las laminas). fw_relief.js usa 0,30 con su cuerpo — ELECCION nuestra [SIN NINO]
function fvvBoxBlur3(a, W, H, r) {
   var src = Float32Array.from(a), tmp = new Float32Array(W * H), x, y, s, n = 2 * r + 1;
   for (var pass = 0; pass < 3; ++pass) {
      for (y = 0; y < H; ++y) { var o = y * W; s = 0; for (x = -r; x <= r; ++x) s += src[o + fvvClamp(x, 0, W - 1)]; for (x = 0; x < W; ++x) { tmp[o + x] = s / n; s += src[o + Math.min(W - 1, x + r + 1)] - src[o + Math.max(0, x - r)]; } }
      for (x = 0; x < W; ++x) { s = 0; for (y = -r; y <= r; ++y) s += tmp[fvvClamp(y, 0, H - 1) * W + x]; for (y = 0; y < H; ++y) { src[y * W + x] = s / n; s += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x]; } }
   }
   return src;
}
function fvvMaxFilter(a, W, H, r) {   // maximo en un cuadrado (2r+1)², separable
   var tmp = new Float32Array(W * H), out = new Float32Array(W * H), x, y, k;
   for (y = 0; y < H; ++y) for (x = 0; x < W; ++x) { var m = 0; for (k = Math.max(0, x - r); k <= Math.min(W - 1, x + r); ++k) if (a[y * W + k] > m) m = a[y * W + k]; tmp[y * W + x] = m; }
   for (x = 0; x < W; ++x) for (y = 0; y < H; ++y) { var m2 = 0; for (k = Math.max(0, y - r); k <= Math.min(H - 1, y + r); ++k) if (tmp[k * W + x] > m2) m2 = tmp[k * W + x]; out[y * W + x] = m2; }
   return out;
}
function fvVolSlabEnvelope(rel, rgba) {
   if (!FV_VOLM.SLAB.ENV) return rel;
   var w = rel.w, h = rel.h, N = w * h, i, r = Math.max(2, Math.round(FV_VOLM.SLAB.ENV_R * w));
   var L = new Float32Array(N), R = new Float32Array(N), G = new Float32Array(N), B = new Float32Array(N);
   for (i = 0; i < N; ++i) { R[i] = rgba[4 * i] / 255; G[i] = rgba[4 * i + 1] / 255; B[i] = rgba[4 * i + 2] / 255; L[i] = 0.2126 * R[i] + 0.7152 * G[i] + 0.0722 * B[i]; }
   // envolvente: maximo de la foto apenas suavizada (r 2: sin que manden los pixeles sueltos) en radio r, y suavizado de radio r
   var Ls = fvvBoxBlur3(L, w, h, 2), Env = fvvBoxBlur3(fvvMaxFilter(Ls, w, h, r), w, h, r), Rc = fvvBoxBlur3(R, w, h, 2), Gc = fvvBoxBlur3(G, w, h, 2), Bc = fvvBoxBlur3(B, w, h, 2);
   var body = new Float32Array(4 * N);
   for (i = 0; i < N; ++i) { var lc = 0.2126 * Rc[i] + 0.7152 * Gc[i] + 0.0722 * Bc[i], kk = Env[i] / Math.max(lc, 0.004); body[4 * i] = Math.min(1, Rc[i] * kk); body[4 * i + 1] = Math.min(1, Gc[i] * kk); body[4 * i + 2] = Math.min(1, Bc[i] * kk); body[4 * i + 3] = 1; }
   var out = {}; for (var key in rel) if (rel.hasOwnProperty(key)) out[key] = rel[key];
   out.body = body; out.envR = r; out.params = out.params || {}; out.envelope = { r: r, kb: FV_VOLM.SLAB.KB };
   return out;
}
// el KB que va con el cuerpo en uso (envolvente: FV_VOLM.SLAB.KB; sin ella, el de fw_relief.js)
function fvVolSlabKB(relief) { return FV_VOLM.SLAB.ENV ? FV_VOLM.SLAB.KB : (FV_VOLM.SLAB.KB_RAW || relief.KB); }   // KB_RAW: pruebas (sin envolvente)
// (pruebas) lo que se ve DESDE LA TIERRA con los cortes: Σ_k e_k · Π_{j ≤ k} T_j -> Float32Array sw·sh·3
function fvVolSlabFront(sl) {
   var n = sl.sw * sl.sh, out = new Float32Array(n * 3), half = sl.dsw !== sl.sw;
   for (var i = 0; i < n; ++i) {
      var x = i % sl.sw, y = (i / sl.sw) | 0, di = half ? ((y >> 1) * sl.dsw + (x >> 1)) : i, tr = 1;
      for (var k = 0; k < sl.Ke; ++k) {
         if (sl.dust[k]) tr *= ((sl.dust[k][di] >>> 16) & 255) / 255;
         var p = sl.emit[k][i]; out[3 * i] += ((p >>> 16) & 255) * tr; out[3 * i + 1] += ((p >>> 8) & 255) * tr; out[3 * i + 2] += (p & 255) * tr;
      }
   }
   return out;
}
