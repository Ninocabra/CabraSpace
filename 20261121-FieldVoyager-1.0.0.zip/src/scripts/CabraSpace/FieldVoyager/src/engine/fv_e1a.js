// ============================================================================
// FieldVoyager/src/engine/fv_e1a.js — EL VIGILANTE DEL «SONIDO QUE INFORMA» (E1-18 y E1-19, 19-nov-2026, I5). PURO.
// ----------------------------------------------------------------------------
// Lee el piloto (P: seleccion, llegada, vuelo, camara, escena) y dice QUE hay que decirle a la radio; no suena nada aqui. Lo comparten la nave de PixInsight
// (src/ui/fv_dialog.js: e1aStep → FVRadio.inform → __fvr.inform del dial) y el visor web (web/fw_radio.js: FWRadio.e1aStep → inform): una sola regla. El sonido, la
// correspondencia temperatura → nota, el motivo y el enfriamiento viven en src/radio/fv_music.js (FVMusic.E1A, e1aTeffMap, e1aMotif, e1aGate), que viaja con la radio.
//
//   fvE1aNew()                 → estado del vigilante (uno por nave)
//   fvE1aStep(ST, P)           → [eventos] de este fotograma:
//        { kind: "star", teff, src, why: "select", i }   una estrella con Teff pasa a estar SELECCIONADA (clic, MIRABILIA, Tour, viaje)
//        { kind: "pass", teff, src, i, d }               en pleno viaje la nave pasa a menos de FV_E1A.PASS_K · (separacion tipica del campo) de una estrella con Teff
//        { kind: "motif", name: "arrive", why: "arrive" } la nave llega a un OBJETO principal (object / nebula) y han pasado FV_E1A.ARRIVE_DELAY_S s
//        { kind: "motif", name: ... , why: "post" }       lo que otros modulos pidan con fvE1aPost (E1-19: «resolve» pregunta o misterio resuelto, «chain» final de cadena)
//   fvE1aPost(ST, name)        → E1-19: ENGANCHE para quien cierre una pregunta o un misterio (la cadena de «¿por qué?», AENIGMATA): al siguiente fotograma sale un motivo
// Sin Teff en la estrella (meta.teff ausente o ≤ 0) NO hay evento: no se inventa un dato. ST.log guarda lo descartado (pruebas).
// La llegada espera FV_E1A.ARRIVE_DELAY_S (2,2 s): el silencio de llegada de E1-14 (dos segundos con la radio atenuada) cabe antes del motivo; si E1-14 cambia
// su duracion, ES ESTA CONSTANTE la que se alinea con ella (la puerta de la pagina ademas calla todo con la radio atenuada por debajo de FVMusic.E1A.DUCK_MIN).
// ES5; sin «barra asterisco» (preprocesador de PJSR).
// ============================================================================

var FV_E1A = {
   ON: true,                    // false = lo de antes: ni vigilante ni sonido (FVRadio.inform tampoco hace nada)
   SEL: true,                   // E1-18: una nota al seleccionar una estrella
   PASS: true,                  // E1-18: un tic al pasar cerca de una estrella durante un viaje
   ARRIVE: true,                // E1-19: el motivo al llegar a un objeto principal
   ARRIVE_KINDS: { object: 1, nebula: 1 },
   TEFF_SRC: "any",             // «any»: la Teff que muestra la ficha (Gaia GSP-Phot o, si falta, la de BP−RP); «gsp»: solo la de GSP-Phot de Gaia DR3
   ARRIVE_DELAY_S: 2.2,
   PASS_K: 0.5,                 // «cerca» = a menos de PASS_K veces la separacion tipica entre estrellas del campo (mediana del vecino mas proximo)
   PASS_HZ: 4,                  // el barrido de estrellas, como mucho 4 veces por segundo de nave
   PASS_GAP_S: 1.2,             // entre dos tics de paso
   PASS_SAME_S: 40,             // la misma estrella no vuelve a dar tic antes de esto
   RETRY_S: 6,                  // un motivo atenuado por la cabina se reintenta hasta 6 s despues de pedirlo...
   RETRY_EVERY_S: 0.25          // ...cada 0,25 s
};

function fvE1aNew() { return { defer: null, deferT: 0, ready: false, selKey: "", arrKey: "", arrDue: -1, passT: -1e9, passLast: -1e9, passAt: {}, pPrev: null, sep: null, sepScene: null, queue: [], log: [] }; }
function fvE1aKeyOf(s) { return s ? (s.kind + ":" + (s.i === undefined ? "" : s.i)) : ""; }
function fvE1aLog(ST, o) { ST.log.push(o); if (ST.log.length > 100) ST.log.shift(); }
// la estrella detras de una seleccion: una estrella, o un objeto de C que ES una estrella (scene.objects[i].star)
function fvE1aSelStar(P, sel) {
   if (!sel) return -1;
   if (sel.kind === "star" && sel.i >= 0) return sel.i;
   if (sel.kind === "object" && P.scene && P.scene.objects) { var o = P.scene.objects[sel.i]; if (o && o.star >= 0 && o.type === "star") return o.star; }
   return -1;
}
// la Teff de la estrella i: la de la ficha (meta.teff: la de GSP-Phot o la de BP−RP, con el polvo quitado) → { teff, src } | null
function fvE1aTeffOf(P, i) {
   var S = P.scene ? P.scene.stars : null; if (!S || !S.meta) return null;
   var m = S.meta[i]; if (!m) return null;
   var T = m.teff; if (!(T > 0) || !isFinite(T)) return null;
   var src = m.teffSrc ? String(m.teffSrc) : "";
   if (FV_E1A.TEFF_SRC === "gsp" && !/GSP/i.test(src)) return null;
   return { teff: T, src: src };
}
// la separacion tipica del campo: mediana de la distancia al vecino mas proximo en una muestra de ≤ 100 estrellas (una vez por escena)
function fvE1aSep(ST, scene) {
   if (ST.sepScene === scene && ST.sep !== null) return ST.sep;
   var S = scene ? scene.stars : null, n = S ? S.n : 0, d = [], k, j;
   if (n >= 3) {
      var step = Math.max(1, Math.floor(n / 100));
      for (k = 0; k < n; k += step) {
         var best = 1e30;
         for (j = 0; j < n; ++j) { if (j === k) continue; var dx = S.x[j] - S.x[k], dy = S.y[j] - S.y[k], dz = S.z[j] - S.z[k], q = dx * dx + dy * dy + dz * dz; if (q < best) best = q; }
         d.push(Math.sqrt(best));
      }
      d.sort(function(a, b) { return a - b; });
    }
   ST.sepScene = scene; ST.sep = d.length ? d[d.length >> 1] : 0;
   return ST.sep;
}
// E1-19 · un motivo que la radio no pudo tocar porque estaba atenuada (el silencio de llegada de E1-14, el salto del warp) NO se pierde: se reintenta cada RETRY_EVERY_S hasta RETRY_S s
// despues de pedirlo. fvE1aDefer(ST, ev, res, nowS) se llama con cada respuesta de la radio (true = queda aplazado); fvE1aRetry(ST, nowS) devuelve el evento que toca reintentar ahora o null.
// El tiempo es el de quien llama (segundos; la nave de PixInsight usa Date.now, el visor performance.now): aqui no se mira ningun reloj.
function fvE1aDefer(ST, ev, res, nowS) {
   if (ST && ev && ev.kind === "motif" && res && res.why !== "ducked") ST.defer = null;           // sono, o se descarto por otra razon: ya no hay nada que reintentar
   if (!ST || !ev || ev.kind !== "motif" || !res || res.played || res.why !== "ducked") return false;
   if (ev.until === undefined) ev.until = nowS + FV_E1A.RETRY_S;
   if (nowS >= ev.until) return false;
   ST.defer = ev; ST.deferT = nowS; return true;
}
function fvE1aRetry(ST, nowS) {
   var ev = ST ? ST.defer : null; if (!ev) return null;
   if (nowS >= ev.until) { ST.defer = null; return null; }
   if (nowS - ST.deferT < FV_E1A.RETRY_EVERY_S) return null;
   ST.defer = null; return ev;
}
function fvE1aPost(ST, name) { if (ST && name) ST.queue.push({ kind: "motif", name: String(name), why: "post" }); }

function fvE1aStep(ST, P) {
   var out = [];
   if (!ST || !P || !FV_E1A.ON) return out;
   var t = P.t, sc = P.scene, i;
   if (ST.queue.length) { out = out.concat(ST.queue); ST.queue = []; }
   var sel = P.sel, key = fvE1aKeyOf(sel), flying = !!P.flight;
   // el primer fotograma solo aprende lo que ya hay (una foto que se abre con algo seleccionado no suena)
   if (!ST.ready) { ST.ready = true; ST.selKey = key; ST.arrKey = (P.arrivedAt && !flying) ? fvE1aKeyOf(P.arrivedAt) : ""; return out; }
   // E1-18 · seleccion
   if (key !== ST.selKey) {
      ST.selKey = key;
      if (FV_E1A.SEL && sel) {
         var si = fvE1aSelStar(P, sel);
         if (si >= 0) {
            var T = fvE1aTeffOf(P, si);
            if (T) out.push({ kind: "star", teff: T.teff, src: T.src, why: "select", i: si });
            else fvE1aLog(ST, { kind: "star", i: si, why: "no-teff", t: t });
         }
      }
   }
   // E1-19 · llegada a un objeto principal: tras ARRIVE_DELAY_S de nave, y solo si sigue parada alli
   var arr = P.arrivedAt, ak = (arr && !flying) ? fvE1aKeyOf(arr) : "";
   if (ak !== ST.arrKey) {
      ST.arrKey = ak; ST.arrDue = -1;
      if (ak && FV_E1A.ARRIVE && FV_E1A.ARRIVE_KINDS[arr.kind]) ST.arrDue = t + FV_E1A.ARRIVE_DELAY_S;
   }
   if (flying) ST.arrDue = -1;
   if (ST.arrDue >= 0 && t >= ST.arrDue && !flying && ak === ST.arrKey) { ST.arrDue = -1; out.push({ kind: "motif", name: "arrive", why: "arrive", key: ak }); }
   // E1-18 · pasar cerca: en pleno viaje, la estrella con Teff que pasa a menos de PASS_K · separacion del segmento recorrido desde el barrido anterior
   if (FV_E1A.PASS && flying && sc && sc.stars && P.cam && t - ST.passT >= 1 / FV_E1A.PASS_HZ) {
      var S = sc.stars, a = ST.pPrev, b = P.cam.pos, thr = FV_E1A.PASS_K * fvE1aSep(ST, sc);
      ST.passT = t; ST.pPrev = [b[0], b[1], b[2]];
      if (a && thr > 0) {
         var abx = b[0] - a[0], aby = b[1] - a[1], abz = b[2] - a[2], L2 = abx * abx + aby * aby + abz * abz, best = -1, bd = thr * thr, selStar = fvE1aSelStar(P, sel);
         for (i = 0; i < S.n; ++i) {
            if (i === selStar) continue;
            var px = S.x[i] - a[0], py = S.y[i] - a[1], pz = S.z[i] - a[2], u = L2 > 0 ? (px * abx + py * aby + pz * abz) / L2 : 0;
            u = u < 0 ? 0 : (u > 1 ? 1 : u);
            var ex = px - abx * u, ey = py - aby * u, ez = pz - abz * u, q = ex * ex + ey * ey + ez * ez;
            if (q < bd) { if (ST.passAt[i] !== undefined && t - ST.passAt[i] < FV_E1A.PASS_SAME_S) continue; bd = q; best = i; }
         }
         if (best >= 0) {
            ST.passAt[best] = t;
            var T2 = fvE1aTeffOf(P, best);
            if (!T2) fvE1aLog(ST, { kind: "pass", i: best, why: "no-teff", t: t });
            else if (t - ST.passLast >= FV_E1A.PASS_GAP_S) { ST.passLast = t; out.push({ kind: "pass", teff: T2.teff, src: T2.src, i: best, d: Math.sqrt(bd) }); }
         }
      }
   } else if (!flying) ST.pPrev = null;
   return out;
}
