// ============================================================================
// FieldVoyager/src/engine/fv_galdata.js — UNA VIA LACTEA PROPIA HECHA CON CATALOGOS PUBLICOS (encargo GP, fase 1, 9-nov-2026). PURO.
// ----------------------------------------------------------------------------
// Nino quiere una galaxia que pueda usar libremente: sin la imagen de ESA (CC BY-SA) y sin capas de Gaia (licencia NC; DR4 sale el 2-dic).
// Fase 1 = solo el ASPECTO (que lo juzgue Nino). Las descargas en ejecucion y el paquete vienen en la fase 2. Bandera FV_GAL_DATA.ON
// (ENCENDIDA por defecto desde el 10-nov-2026, decision de Nino: ve la ultima galaxia, GF9 con la fosa D1; si falta el extracto rsc/galaxia/gg_tracers.csv,
// fvGalDefaultsGuard() la devuelve a HOY sin cerrar nada; con todas las banderas apagadas todo es como hoy, bit a bit). Especificacion: docs/investigacion-galaxia-propia-catalogos.md §3–4.
// Tres capas MEDIDAS, en galactocentricas con la R0 = 8,15 kpc y la Z☉ de fv_galaxy3d.js (FV_GAL3):
//   · nubes de CO: Miville-Deschenes, Murray & Lee 2017 (ApJ 834, 57), catalogo v3 de 2021 (DOI 10.7910/DVN/QR9CFW), CC0. Masa y tamaño ->
//     densidad de gas y polvo (distancias CINEMATICAS: con la ambiguedad cercano/lejano que el catalogo resuelve a su manera);
//   · maseres con paralaje VLBI: Reid et al. 2019 (ApJ 885, 131), tabla 1: puntos DORADOS (d = 1/π, error e_π/π²);
//   · regiones HII con distancia: catalogo WISE (Anderson et al. 2014, ApJS 212, 1; v2.2 de IRSA): puntos ROSAS.
// El extracto comun (t,l,b,d,ed,m,r,arm) lo escribe la herramienta de desarrollo tests/_galaxy/gp_extract.py; aqui solo se lee el texto.
// MEZCLA DATO–MODELO en el mapa de cara (§3 de la investigacion): densidad por nucleos de los trazadores (nucleo gausiano ALARGADO a lo largo
// de la linea de vision: el error de una distancia es radial desde el Sol) y una CONFIANZA c = 1 − exp(−n), n = suma de los nucleos con pico 1
// (un trazador en su centro: c = 0,63). Donde c es alta manda el dato; donde es baja, el modelo de hoy (brazos de Reid 2019 + barra BHG16).
// La textura procedimental fina (grumos y vetas de fbm) se queda: el dato le da la FORMA, no el grano.
// ALABEO del disco: Skowron et al. 2019 (Science 365, 478), ec. S3 del material suplementario, leido el 9-nov-2026 en ar5iv:
//   Z(R, φ) = −z0 + z1·(R − Rd)²·sin(φ − φ0) para R ≥ Rd; z1 = 0,0152 kpc⁻¹, φ0 = −28°, Rd = 8 kpc (fijo), φ = 0 hacia el Sol.
//   El SENTIDO de φ no lo define el texto; lo fijan sus dos frases: «el disco se alabea hacia Z negativa en 0° < φ < 135° y hacia Z positiva
//   en 165° < φ < 330°» y «entre 240° < l < 330° el disco joven queda por debajo del plano». Las dos casan con φ = −β (β de este codigo: 0 hacia
//   el Sol, creciendo hacia l = 90°) y z = z1·(R − Rd)²·sin(β − 28°): norte hacia l ≈ 90°, sur hacia l ≈ 270°, como el HI. La ecuacion tal
//   cual (con φ = −β y +sin) daria el signo contrario a su propio texto: NO VERIFICADO contra el PDF del suplemento; me quedo con el texto.
//   z0 (la altura del Sol, 15 pc) no se usa: la Z☉ es la del codigo.
// Nucleos, pesos, colores y tamaños de los puntos: ELECCION NUESTRA (se dicen en el informe GP con su sensibilidad).
// ES5.
// ============================================================================

var FV_GAL_DATA = {
   ON: true,                // la bandera (ENCENDIDA por defecto, 10-nov): apagada = la galaxia de hoy, bit a bit
   SOLO: false,             // «solo datos»: oculta el modelo y la textura
   SRC: "",                 // el extracto de trazadores (desde el 11-nov solo las nubes moleculares CC0: 5 008 filas, 398 KB): fichero LOCAL del paquete, sin red. El defecto lo pone fv_galaxy.js (FV_GAL_DATA_ROOT, de #__FILE__, sin rutas fijas: este fichero tambien lo carga node); si falta: la galaxia de HOY (fvGalDefaultsGuard)
   // (11-nov-2026) lo que entro en el AJUSTE de los brazos (fv_galgeom_fit.js, hecho fuera de linea): regiones HII y maseres. Sus filas ya NO van en el
   // paquete (catalogos sin licencia escrita de redistribucion); la galaxia dibujada es la misma bit a bit, y el tooltip cita estos numeros
   FIT_N: { H: 1499, M: 199 },
   NK: 320,                 // rejilla de los nucleos sobre ±TEX_H kpc (125 pc)
   R_DISC: 16.5, C_HALF: 0.5,
   KS: 1,                   // escala de todos los nucleos (prueba de sensibilidad del % de disco medido)
   // la CONFIANZA c = 1 − exp(−Σ q·nucleo / N0): q = cuanto vale un trazador (paralaje 1; distancia CINEMATICA, con la ambiguedad cercano/
   // lejano, menos) y N0 = cuantos trazadores «de paralaje» hacen falta bajo el nucleo para c = 0,63
   Q: { M: 1.0, H: 0.5, C: 0.3, HP: 1.0, HT: 0.25 }, N0: 2.0,   // HP: HII con paralaje · HT: HII en el punto tangente (distancia por convenio)
   // nucleos (kpc): sl = a lo largo de la linea de vision, sp = de traves
   K_M: { los0: 0.10, perp: 0.15 },                         // maser: sl = max(los0, error de la paralaje)
   K_H: { los0: 0.20, losF: 0.10, perp: 0.15 },             // HII: sl = max(los0, err_dist, losF·d)
   K_C: { los0: 0.30, losF: 0.05, perp0: 0.15 },            // nube: sl = los0 + losF·d (distancia cinematica, sin error en el catalogo); sp = max(perp0, radio)
   WY: { C: 0.45, H: 0.40, M: 0.15 },                       // pesos de cada trazador en la densidad de estrellas jovenes
   // la FORMA (densidad) usa nucleos mas redondos que la confianza: con el alargado de la linea de vision la imagen salia en «rayos» desde el
   // Sol (visto en gp_node, ronda 1); la confianza si guarda el alargado (el error de la distancia es radial)
   DK: { MIN: 0.30, MAX: 0.45 },                            // sl_forma = entre MIN y MAX, sp_forma ≥ MIN (kpc)
   YSAT: 2.5, Y_GAMMA: 1.0,  // saturacion suave (× la media) de la densidad de datos: una nube cercana compacta no hace un foco blanco
   CMAX: 0.85,               // el peso del dato no pasa de esto: la textura y los brazos del modelo nunca desaparecen del todo
   WARP: { ON: true, RD: 8.0, Z1: 0.0152, PHI0: 28, RMAX: 18 },
   // los puntos medidos (sprites en el bufer lineal, con su altura real): color lineal, amplitud, radio en px
   PT_M: { col: [1.00, 0.76, 0.30], a: 0.95, r: 1.25 },
   PT_H: { col: [1.00, 0.30, 0.52], a: 0.42, r: 0.85 },
   PT_C: { col: [0.50, 0.66, 0.92], a: 0.16, r: 0.80 },
   SOLO_GLOW: 0.30, SOLO_COL: [0.42, 0.55, 0.80],           // «solo datos»: el resplandor de la densidad de gas (es dato suavizado)
   ARM_MAP: { "3kN": "3kpc", "3kF": "3kpcF", "Nor": "norma", "ScN": "scucen", "ScF": "scucen", "CtN": "scucen", "OSC": "scucen",
              "CrN": "sgrcar", "SgN": "sgrcar", "SgF": "sgrcar", "Loc": "local", "Per": "perseus", "Out": "outer" }
};
var FV_GAL_DATA_ST = null;       // lo construido (una vez por sesion): { pts, k, c, cov, mix, solo, seg, far, ms }
// (10-nov-2026) LA GUARDA DEL DEFECTO. Las banderas de la galaxia nueva (COLOR, DATA, GG, GF2 … GF9) vienen ENCENDIDAS; todas dependen del extracto
// FV_GAL_DATA.SRC. Si el fichero falta o no se puede leer, fvGalDefaultsFall() las apaga todas (la galaxia de HOY, bit a bit), deja UNA linea en el log
// y no cierra nada ni abre ningun dialogo. fvGalDefaultsGuard() lo comprueba una vez por valor de SRC (cuesta un File.exists); se llama desde
// fvGalColorSync (todo mapa o vista pasa por ahi) y desde fvGalDataEnsure. Devuelve true si la galaxia nueva puede usarse.
function fvGalDefaultsFall(why) {
   var A = FV_GAL_DATA, was = A.ON;
   A.ON = false;
   if (typeof FV_GAL_COLOR !== "undefined") FV_GAL_COLOR.ON = false;
   if (typeof FV_GAL_GG !== "undefined") FV_GAL_GG.ON = false;
   if (typeof FV_GAL_GF2 !== "undefined") FV_GAL_GF2.ON = false;
   if (typeof FV_GAL_GF3 !== "undefined") FV_GAL_GF3.ON = false;
   if (typeof FV_GAL_GF4 !== "undefined") FV_GAL_GF4.ON = false;
   if (typeof FV_GAL_GF5 !== "undefined") FV_GAL_GF5.ON = false;
   if (typeof FV_GAL_GF6 !== "undefined") FV_GAL_GF6.ON = false;
   if (typeof FV_GAL_GF7 !== "undefined") FV_GAL_GF7.ON = false;
   if (typeof FV_GAL_GF8 !== "undefined") FV_GAL_GF8.ON = false;
   if (typeof FV_GAL_GF9 !== "undefined") FV_GAL_GF9.ON = false;
   A.job = null; FV_GAL_DATA_ST = null; A.chk = null; A.fell = why;
   if (was && typeof fvLog === "function") fvLog("galaxy data: " + why + ": the galaxy falls back to today's (all new-galaxy flags off)");
   return false;
}
function fvGalDefaultsGuard() {
   var A = FV_GAL_DATA;
   if (!A.ON) return false;
   if (typeof File === "undefined") return true;       // node (pruebas del motor puro): no hay ficheros que comprobar; el texto lo pone la prueba
   if (A.chk && A.chk.src === A.SRC) return A.chk.ok;
   var ok = false, why = "";
   try {
      if (!A.SRC) why = "no extract path (FV_GAL_DATA.SRC empty)";
      else if (!File.exists(A.SRC)) why = "no extract (" + A.SRC + ")";
      else { File.readTextFile(A.SRC); ok = true; }
   } catch (e) { why = "cannot read the extract (" + A.SRC + "): " + e; }
   if (!ok) return fvGalDefaultsFall(why);
   A.chk = { src: A.SRC, ok: true };
   return true;
}

// ---------------------------------------------------------------------------
// el extracto -> { C: [...], H: [...], M: [...] }, cada punto { X, Y, Z (galactocentricas, kpc), l, b, d, ed, m, r, arm, ux, uy }
// ---------------------------------------------------------------------------
function fvGalDataParse(txt) {
   var G = FV_GAL3, D2R = Math.PI / 180, out = { C: [], H: [], M: [] }, L = String(txt).split(/\r?\n/);
   for (var i = 1; i < L.length; ++i) {
      var p = L[i].split(","); if (p.length < 7) continue;
      var t = p[0], l = parseFloat(p[1]), b = parseFloat(p[2]), d = parseFloat(p[3]);
      if (!out[t] || !(d > 0) || !isFinite(l) || !isFinite(b)) continue;
      var cl = Math.cos(l * D2R), sl = Math.sin(l * D2R), cb = Math.cos(b * D2R);
      out[t].push({ X: d * cb * cl - G.R0, Y: d * cb * sl, Z: d * Math.sin(b * D2R) + G.ZSUN, l: l, b: b, d: d, ed: parseFloat(p[4]) || 0, m: parseFloat(p[5]) || 0,
                    r: parseFloat(p[6]) || 0, arm: (p[7] || "").replace(/\s+/g, ""), ux: cl, uy: sl });
   }
   return out;
}
// el alabeo: altura del plano medio (kpc, galactocentrica) en (X, Y)
function fvGalDataWarp(X, Y) {
   var W = FV_GAL_DATA.WARP; if (!W.ON) return 0;
   var R = Math.sqrt(X * X + Y * Y); if (R <= W.RD) return 0; if (R > W.RMAX) R = W.RMAX;
   var dr = R - W.RD; return W.Z1 * dr * dr * Math.sin((fvGal3Beta(X, Y) - W.PHI0) * Math.PI / 180);
}
// los anchos del nucleo de un punto (kpc)
function fvGalDataSig(t, p) {
   var A = FV_GAL_DATA, k = A.KS, sl, sp;
   if (t === "M") { sl = Math.max(A.K_M.los0, p.ed); sp = A.K_M.perp; }
   else if (t === "H") { sl = Math.max(A.K_H.los0, p.ed, (p.arm === "T" ? 1.5 : 1) * A.K_H.losF * p.d); sp = A.K_H.perp; }
   else { sl = A.K_C.los0 + A.K_C.losF * p.d; sp = Math.max(A.K_C.perp0, p.r / 1000); }
   return [sl * k, sp * k];
}
// nucleos en la rejilla NK: n (suma de nucleos de pico 1: la «cuenta»), w (suma de nucleos NORMALIZADOS × peso: densidad superficial)
function fvGalDataKdeNew(NK) { return { n: new Float32Array(NK * NK), w: new Float32Array(NK * NK) }; }
function fvGalDataKdeAdd(acc, p, t, NK, H, wt) {
   var A = FV_GAL_DATA, s = fvGalDataSig(t, p), ks = A.KS;
   var q = t === "M" ? A.Q.M : (t === "C" ? A.Q.C : (p.arm === "P" ? A.Q.HP : (p.arm === "T" ? A.Q.HT : A.Q.H)));
   fvGalDataKer(acc.n, p, NK, H, s[0], s[1], q, false);                                            // la cuenta (confianza): el nucleo del error × lo que vale
   var sl = Math.min(Math.max(s[0], A.DK.MIN * ks), A.DK.MAX * ks), sp = Math.max(s[1], A.DK.MIN * ks);
   fvGalDataKer(acc.w, p, NK, H, sl, sp, wt / (2 * Math.PI * sl * sp), true);                      // la forma: densidad superficial
}
function fvGalDataKer(arr, p, NK, H, sl, sp, amp, isNorm) {
   var cs = 2 * H / NK, e = 3 * Math.max(sl, sp);
   var i0 = Math.max(0, Math.floor((p.X - e + H) / cs)), i1 = Math.min(NK - 1, Math.floor((p.X + e + H) / cs)), j0 = Math.max(0, Math.floor((p.Y - e + H) / cs)), j1 = Math.min(NK - 1, Math.floor((p.Y + e + H) / cs));
   var isl = 1 / (sl * sl), isp = 1 / (sp * sp), ux = p.ux, uy = p.uy;
   for (var j = j0; j <= j1; ++j) {
      var dy = -H + (j + 0.5) * cs - p.Y;
      for (var i = i0; i <= i1; ++i) {
         var dx = -H + (i + 0.5) * cs - p.X, a = dx * ux + dy * uy, b = -dx * uy + dy * ux, qq = a * a * isl + b * b * isp;
         if (qq > 9) continue;
         arr[j * NK + i] += amp * Math.exp(-0.5 * qq);
      }
   }
}
// muestra bilineal de una rejilla NK×NK sobre ±H en (X, Y)
function fvGalDataAt(A, NK, H, X, Y) {
   var cs = 2 * H / NK, u = (X + H) / cs - 0.5, v = (Y + H) / cs - 0.5, i0 = Math.floor(u), j0 = Math.floor(v);
   if (i0 < 0) { i0 = 0; u = 0; } if (j0 < 0) { j0 = 0; v = 0; } if (i0 > NK - 2) { i0 = NK - 2; u = NK - 1; } if (j0 > NK - 2) { j0 = NK - 2; v = NK - 1; }
   var fu = u - i0, fv = v - j0, o = j0 * NK + i0;
   return (A[o] * (1 - fu) + A[o + 1] * fu) * (1 - fv) + (A[o + NK] * (1 - fu) + A[o + NK + 1] * fu) * fv;
}

// ---------------------------------------------------------------------------
// LA CONSTRUCCION (una vez por sesion), POR TROZOS para no dar un tiron (el pintor la adelanta en casa como el mapa de cara: fvMw2Prep):
// nucleos, confianza, % del disco medido, linea c = 0,5, lado lejano, alabeo, mapa mezclado y mapa «solo datos».
//   J = fvGalDataBegin(txt); while (!fvGalDataStep(J, ms)) {…}; J.S es lo construido. fvGalDataBuild(txt) = todo de una vez.
// ---------------------------------------------------------------------------
function fvGalDataBegin(txt) { return { txt: txt, st: 0, q: 0, row: 0, ms: { parse: 0, kde: 0, conf: 0, contour: 0, model: 0, mix: 0, solo: 0 }, S: null, done: false }; }
function fvGalDataBuild(txt) { var J = fvGalDataBegin(txt), t0 = Date.now(); while (!fvGalDataStep(J, 0)) {} J.S.ms.total = Date.now() - t0; return J.S; }
function fvGalDataStep(J, ms) {
   if (J.done) return true;
   var A = FV_GAL_DATA, G = FV_GAL3, NK = A.NK, H = G.TEX_H, cs = 2 * H / NK, t0 = Date.now(), NAMES = ["parse", "kde", "kde", "kde", "conf", "contour", "model", "mix", "mix", "solo"];
   var GG = (typeof fvGgOn === "function") && fvGgOn();             // (encargo GG) la geometria ajustada: fv_galgeom.js (bandera FV_GAL_GG.ON)
   function over() { return ms > 0 && Date.now() - t0 > ms; }
   while (J.st <= 9) {
      var tm = Date.now(), st = J.st, i, j, o;
      if (GG && st >= 5 && st <= 8) { if (!fvGalDataStepGG(J, over)) { J.ms[NAMES[st]] += Date.now() - tm; return false; } J.ms[NAMES[st]] += Date.now() - tm; if (J.st <= 9 && over()) return false; continue; }
      if (st === 0) {
         J.P = fvGalDataParse(J.txt); J.kC = fvGalDataKdeNew(NK); J.kH = fvGalDataKdeNew(NK); J.kM = fvGalDataKdeNew(NK); J.q = 0; J.st = 1;
         if (GG) J.PJ = fvGgPrepBegin(J.txt);
      } else if (st <= 3) {
         var t = ["C", "H", "M"][st - 1], list = J.P[t], acc = [J.kC, J.kH, J.kM][st - 1];
         for (; J.q < list.length; ++J.q) {
            if ((J.q & 31) === 0 && over()) { J.ms.kde += Date.now() - tm; return false; }
            fvGalDataKdeAdd(acc, list[J.q], t, NK, H, t === "C" ? list[J.q].m : 1);
         }
         J.q = 0; J.st = st + 1;
      } else if (st === 4) {
         var kC = J.kC, kH = J.kH, kM = J.kM, P = J.P, n2 = NK * NK, c = new Float32Array(n2), yd = new Float32Array(n2), dd = new Float32Array(n2);
         // la confianza y el % del disco (R < R_DISC) con c > C_HALF, de verdad: celda a celda
         var nD = 0, nHi = 0, mC = 0, mH = 0, mM = 0, nMean = 0, farN = 0, farHi = 0, fx = 0, fy = 0, fw = 0, cnN = 0, cnHi = 0;
         for (j = 0; j < NK; ++j) for (i = 0; i < NK; ++i) {
            o = j * NK + i; var X = -H + (i + 0.5) * cs, Y = -H + (j + 0.5) * cs, R = Math.sqrt(X * X + Y * Y);
            c[o] = 1 - Math.exp(-(kC.n[o] + kH.n[o] + kM.n[o]) / A.N0);
            if (R < A.R_DISC) { ++nD; if (c[o] > A.C_HALF) { ++nHi; mC += kC.w[o]; mH += kH.w[o]; mM += kM.w[o]; ++nMean; } }
            // el lado lejano TRAS EL BULBO: mas alla del centro visto desde el Sol (X > 1,5 kpc), anillo de 2,5 a 13 kpc
            if (X > 1.5 && R > 2.5 && R < 13) { ++farN; if (c[o] > A.C_HALF) ++farHi; var wl = Math.max(0, 0.25 - c[o]); fx += wl * X; fy += wl * Y; fw += wl; }
            // y el cono justo detras del bulbo (|l| < 15° visto desde el Sol, mas alla del centro): donde la cinematica no da distancias
            var xs = X + G.R0; if (X > 1.5 && R < 13 && Math.abs(Math.atan2(Y, xs)) < 15 * Math.PI / 180) { ++cnN; if (c[o] > A.C_HALF) ++cnHi; }
         }
         mC = nMean ? mC / nMean : 1; mH = nMean ? mH / nMean : 1; mM = nMean ? mM / nMean : 1;
         for (o = 0; o < n2; ++o) {
            var y0 = A.WY.C * kC.w[o] / Math.max(1e-12, mC) + A.WY.H * kH.w[o] / Math.max(1e-12, mH) + A.WY.M * kM.w[o] / Math.max(1e-12, mM);
            var d0 = kC.w[o] / Math.max(1e-12, mC);
            y0 = y0 / (1 + y0 / A.YSAT); d0 = d0 / (1 + d0 / A.YSAT);       // saturacion suave
            yd[o] = A.Y_GAMMA === 1 ? y0 : Math.pow(y0, A.Y_GAMMA); dd[o] = d0;
         }
         J.S = { pts: P, NK: NK, H: H, c: c, yd: yd, dd: dd, kC: kC, kH: kH, kM: kM, ms: J.ms,
                 cov: nD ? nHi / nD : 0, covN: [nHi, nD], farCov: farN ? farHi / farN : 0, coneCov: cnN ? cnHi / cnN : 0, far: fw > 0 ? [fx / fw, fy / fw] : [6, 0],
                 n: { C: P.C.length, H: P.H.length, M: P.M.length }, brk: FV_GAL3_BREAK };
         if (GG) J.S.ggKey = fvGgKey();
         J.st = 5;
      } else if (st === 5) {
         J.S.seg = fvGalDataContour(J.S, A.C_HALF); J.S.wg = fvGalDataWarpGrid(G.TEX_N, H); J.st = 6;
      } else if (st === 6) {
         // el mapa de cara del modelo (el de hoy), si aun no estaba
         if (!fvGal3TexStep(ms > 0 ? Math.max(1, ms - (Date.now() - t0)) : 0)) { J.ms.model += Date.now() - tm; return false; }
         J.mx = fvGalDataMixBegin(fvGal3Tex(), J.S); J.row = 0; J.st = 7;
      } else if (st === 7 || st === 8) {
         var MX = J.mx, NN = MX.N;
         for (; J.row < NN; ++J.row) {
            if (over()) { J.ms.mix += Date.now() - tm; return false; }
            if (st === 7) fvGalDataMixRow1(MX, J.row); else fvGalDataMixRow2(MX, J.row);
         }
         J.row = 0;
         if (st === 7) { fvGalDataMixMid(MX); J.st = 8; } else { J.S.mix = fvGalDataMixEnd(MX, J.S); J.mx = null; J.st = 9; }
      } else {
         J.S.solo = fvGalDataSolo(J.S); J.st = 10;
      }
      J.ms[NAMES[st]] += Date.now() - tm;
      if (J.st <= 9 && over()) return false;
   }
   J.done = true; J.txt = null; J.kC = J.kH = J.kM = null;
   return true;
}
// (encargo GG) las etapas 5–8 con la geometria ajustada (fv_galgeom.js): 5 = λ de las nubes, densidad a posteriori, mapa u y su linea (en vez de
// la linea c = 0,5 de GP); 6 = el mapa de cara del MODELO AJUSTADO (en vez del de hoy); 7–8 = la mezcla con c′ ≤ 0,5 donde u es baja. Por trozos.
function fvGalDataStepGG(J, over) {
   var A = FV_GAL_DATA, G = FV_GAL3, st = J.st;
   if (st === 5) {
      if (!J.S.wg) J.S.wg = fvGalDataWarpGrid(G.TEX_N, G.TEX_H);
      if (!fvGgPrepStep(J.PJ, over)) return false;
      J.S.seg = new Float32Array(0);
      // n = lo que ENTRA en la forma: nubes del corte en masa y HII fuera de las mascaras (las HII con paralaje van al prior con los maseres)
      var PG = J.PJ.PG, nC = 0, nH = 0, q;
      for (q = 0; q < PG.C.length; ++q) if (!PG.C[q].msk && PG.C[q].m > 0) ++nC;
      for (q = 0; q < PG.H.length; ++q) if (!PG.H[q].msk && PG.H[q].arm !== "P") ++nH;
      J.S.gg = { seg: J.PJ.seg, cov: J.PJ.U.cov, far: J.PJ.U.far, ms: J.PJ.ms, n: { C: nC, H: nH || FV_GAL_DATA.FIT_N.H, M: PG.M.length || FV_GAL_DATA.FIT_N.M } };   // (11-nov) el paquete ya no lleva las filas HII ni los maseres: sus numeros son los del ajuste
      J.st = 6; return true;
   }
   if (st === 6) {
      if (!J.ggTex) J.ggTex = fvGgTexBegin();
      if (!fvGgTexStep(J.ggTex, over ? 6 : 0)) { if (over()) return false; while (!fvGgTexStep(J.ggTex, 6)) { if (over()) return false; } }
      J.S.ggModel = J.ggTex.T; J.mx = fvGgMixBegin(J.ggTex.T, J.S, J.PJ); J.ggTex = null; J.row = 0; J.st = 7; return true;
   }
   var MX = J.mx, NN = MX.N;
   // 7 = escala global; 8 = dos fases: (ph 0) el dato saturado y las sumas gruesas del nivel, (ph 1) la mezcla
   for (; J.row < NN; ++J.row) { if (over()) return false; if (st === 7) fvGgMixRow1(MX, J.row); else if (!MX.ph) fvGgMixRowS(MX, J.row); else fvGgMixRow2(MX, J.row); }
   J.row = 0;
   if (st === 7) { fvGgMixMid(MX); J.st = 8; }
   else if (!MX.ph) { fvGgMixMid2(MX); MX.ph = 1; }
   else { J.S.mix = fvGgMixEnd(MX, J.S, J.PJ); J.mx = null; J.PJ.Dpost = J.PJ.lamC = null; J.st = 9; }
   return true;
}
// una rejilla NK×NK (±H) muestreada en los centros de la rejilla N×N del mapa de cara (bilineal, sin llamadas por texel)
function fvGalDataUp(A, NK, H, N) {
   var out = new Float32Array(N * N), r = NK / N, iu = new Int32Array(N), fu = new Float32Array(N), k;
   for (k = 0; k < N; ++k) { var u = (k + 0.5) * r - 0.5; if (u < 0) u = 0; if (u > NK - 1.000001) u = NK - 1.000001; iu[k] = Math.floor(u); fu[k] = u - iu[k]; }
   for (var j = 0; j < N; ++j) {
      var j0 = iu[j], fv = fu[j], r0 = j0 * NK, r1 = r0 + NK;
      for (var i = 0; i < N; ++i) { var i0 = iu[i], f = fu[i]; out[j * N + i] = (A[r0 + i0] * (1 - f) + A[r0 + i0 + 1] * f) * (1 - fv) + (A[r1 + i0] * (1 - f) + A[r1 + i0 + 1] * f) * fv; }
   }
   return out;
}
// la linea c = lev (marching squares en una rejilla de NK/2) -> [X1, Y1, X2, Y2, ...] galactocentricos
function fvGalDataContour(S, lev) {
   var M = S.NK >> 1, H = S.H, cs = 2 * H / M, v = new Float32Array((M + 1) * (M + 1)), seg = [], i, j;
   for (j = 0; j <= M; ++j) for (i = 0; i <= M; ++i) { var X0 = -H + i * cs, Y0 = -H + j * cs; v[j * (M + 1) + i] = fvGalDataAt(S.c, S.NK, H, X0, Y0) * (1 - fvGal3Smooth((Math.sqrt(X0 * X0 + Y0 * Y0) - FV_GAL_DATA.R_DISC) / 1.0)); }
   // SOLO PARA DIBUJAR la linea (el % se cuenta con la c sin suavizar): caja de ±2 celdas (±0,5 kpc) dos veces; sin esto la linea salia en
   // pinchos radiales (los nucleos alargados de las nubes lejanas) y dominaba la vista (visto en el montaje, ronda 1)
   var M1 = M + 1, tmp = new Float32Array(M1 * M1), rb = 2;
   for (var pass = 0; pass < 2; ++pass) {
      for (j = 0; j < M1; ++j) for (i = 0; i < M1; ++i) { var sA = 0, nA = 0; for (var e = -rb; e <= rb; ++e) { var ii = i + e; if (ii >= 0 && ii < M1) { sA += v[j * M1 + ii]; ++nA; } } tmp[j * M1 + i] = sA / nA; }
      for (j = 0; j < M1; ++j) for (i = 0; i < M1; ++i) { var sB = 0, nB = 0; for (var e2 = -rb; e2 <= rb; ++e2) { var jj = j + e2; if (jj >= 0 && jj < M1) { sB += tmp[jj * M1 + i]; ++nB; } } v[j * M1 + i] = sB / nB; }
   }
   for (j = 0; j < M1 * M1; ++j) v[j] -= lev;
   function P(i0, j0, i1, j1) { var a = v[j0 * (M + 1) + i0], b = v[j1 * (M + 1) + i1], t = a / (a - b); return [-H + (i0 + (i1 - i0) * t) * cs, -H + (j0 + (j1 - j0) * t) * cs]; }
   for (j = 0; j < M; ++j) for (i = 0; i < M; ++i) {
      var X = -H + (i + 0.5) * cs, Y = -H + (j + 0.5) * cs; if (X * X + Y * Y > (FV_GAL_DATA.R_DISC + 1) * (FV_GAL_DATA.R_DISC + 1)) continue;
      var a = v[j * (M + 1) + i] > 0, b = v[j * (M + 1) + i + 1] > 0, cc = v[(j + 1) * (M + 1) + i + 1] > 0, d = v[(j + 1) * (M + 1) + i] > 0;
      var e = [];       // cruces en los cuatro lados (abajo, derecha, arriba, izquierda)
      if (a !== b) e.push(P(i, j, i + 1, j)); if (b !== cc) e.push(P(i + 1, j, i + 1, j + 1)); if (cc !== d) e.push(P(i + 1, j + 1, i, j + 1)); if (d !== a) e.push(P(i, j + 1, i, j));
      if (e.length === 2) seg.push(e[0][0], e[0][1], e[1][0], e[1][1]);
      else if (e.length === 4) seg.push(e[0][0], e[0][1], e[1][0], e[1][1], e[2][0], e[2][1], e[3][0], e[3][1]);
   }
   return new Float32Array(seg);
}
// la rejilla del alabeo en la del mapa de cara (N×N)
function fvGalDataWarpGrid(N, H) {
   var px = 2 * H / N, Wz = new Float32Array(N * N), mx = 0;
   for (var j = 0; j < N; ++j) for (var i = 0; i < N; ++i) { var z = fvGalDataWarp(-H + (i + 0.5) * px, -H + (j + 0.5) * px); Wz[j * N + i] = z; if (Math.abs(z) > mx) mx = Math.abs(z); }
   return { z: Wz, max: mx };
}
// los puntos de una capa como sprites (Float32Array X, Y, Z galactocentricos y su amplitud)
function fvGalDataPts(S, kinds) {
   var A = FV_GAL_DATA, L = [];
   kinds.forEach(function(t) {
      var st = t === "M" ? A.PT_M : (t === "H" ? A.PT_H : A.PT_C), list = S.pts[t], mx = 0, q;
      if (t === "H") list = list.filter(function(p) { return p.arm !== "T"; });   // los de punto TANGENTE no se pintan: su distancia es un convenio (dibujaban el circulo Sol–centro)
      if (t === "C") for (q = 0; q < list.length; ++q) mx = Math.max(mx, Math.sqrt(list[q].m));
      var p = new Float32Array(3 * list.length), am = new Float32Array(list.length);
      for (q = 0; q < list.length; ++q) {
         p[3 * q] = list[q].X; p[3 * q + 1] = list[q].Y; p[3 * q + 2] = list[q].Z;
         am[q] = st.a * (t === "C" ? 0.25 + 0.75 * Math.sqrt(Math.sqrt(list[q].m) / Math.max(1e-9, mx)) : 1);   // nubes: mas masa, algo mas claras
      }
      L.push({ t: t, n: list.length, p: p, a: am, col: st.col, r: st.r });
   });
   return L;
}
// EL MAPA MEZCLADO: el mismo formato que fvGal3Tex() (r, g, b, dust, arm, armDust) con el alabeo (warp) y los puntos (pts). Por filas, en dos
// pasadas: 1) grumos y vetas del modelo, confianza y sumas para la escala; 2) la mezcla
function fvGalDataMixBegin(Tm, S) {
   var N = Tm.N, n2 = N * N;
   return { Tm: Tm, N: N, H: Tm.H, px: Tm.px, cN: fvGalDataUp(S.c, S.NK, S.H, N), Yd: fvGalDataUp(S.yd, S.NK, S.H, N), Dd: fvGalDataUp(S.dd, S.NK, S.H, N),
            FL: new Float32Array(n2), DN: new Float32Array(n2), OLD: new Float32Array(n2), sAr: 0, sYd: 0, sAD: 0, sDd: 0,
            r: new Float32Array(n2), g: new Float32Array(n2), b: new Float32Array(n2), dust: new Float32Array(n2), arm: new Float32Array(n2), armDust: new Float32Array(n2) };
}
function fvGalDataMixRow1(M, j) {
   var A = FV_GAL_DATA, G = FV_GAL3, N = M.N, H = M.H, px = M.px, Tm = M.Tm, Y = -H + (j + 0.5) * px;
   for (var i = 0; i < N; ++i) {
      var X = -H + (i + 0.5) * px, R = Math.sqrt(X * X + Y * Y), o = j * N + i;
      if (R > H) continue;
      // los mismos grumos (floc) y vetas (dn) que el modelo: misma cuenta, mismas semillas (fvGal3TexStep)
      M.FL[o] = 0.30 + 1.45 * fvGal3Fbm2(X / 0.9, Y / 0.9, 11, 3); M.DN[o] = fvGal3Fbm2(X / 0.55, Y / 0.55, 23, 3);
      M.OLD[o] = Math.exp(-R / G.HR_OLD) * (1 - Math.exp(-R * R / (2.6 * 2.6))) * (1 - fvGal3Smooth((R - 15) / 4.5));
      M.Yd[o] *= 1 - fvGal3Smooth((R - 14) / 4);                       // el dato se apaga hacia fuera como los brazos del modelo
      if (R < A.R_DISC) { var c = M.cN[o] * A.CMAX; M.sAr += c * Tm.arm[o]; M.sYd += c * M.Yd[o] * M.FL[o]; M.sAD += c * Tm.armDust[o]; M.sDd += c * M.Dd[o]; }
   }
}
// la escala: que donde manda el dato el brillo medio de jovenes y de polvo sea el del modelo en las mismas celdas
function fvGalDataMixMid(M) { M.sY = M.sYd > 0 ? M.sAr / M.sYd : 1; M.sD = M.sDd > 0 ? M.sAD / M.sDd : 1; }
function fvGalDataMixRow2(M, j) {
   var G = FV_GAL3, N = M.N, H = M.H, px = M.px, Tm = M.Tm, cO = G.COL_OLD, cY = G.COL_YOUNG, kd = G.DUST_RGB, Y = -H + (j + 0.5) * px, sY = M.sY, sD = M.sD;
   for (var i = 0; i < N; ++i) {
      var X = -H + (i + 0.5) * px, R = Math.sqrt(X * X + Y * Y), o = j * N + i;
      if (R > H) continue;
      var cc = M.cN[o], old = M.OLD[o], am = Tm.arm[o], tdu = Tm.dust[o], aO = G.A_OLD * old, aY = G.A_YOUNG * am;
      // el continuo del MODELO (lo de fvGal3TexStep) para separar sus nudos HII y cumulos sembrados (que llevan peso 1 − c)
      var kr = Tm.r[o] - (aO * cO[0] + aY * cY[0]) * Math.exp(-tdu * kd[0]), kg = Tm.g[o] - (aO * cO[1] + aY * cY[1]) * Math.exp(-tdu * kd[1]), kb = Tm.b[o] - (aO * cO[2] + aY * cY[2]) * Math.exp(-tdu * kd[2]);
      if (kr < 0) kr = 0; if (kg < 0) kg = 0; if (kb < 0) kb = 0;
      cc *= FV_GAL_DATA.CMAX;
      var young = (1 - cc) * am + cc * sY * M.Yd[o] * M.FL[o], adl = (1 - cc) * Tm.armDust[o] + cc * sD * M.Dd[o], dn = M.DN[o];
      var dust = G.DUST_K * (adl * (0.30 + 1.5 * dn) + 0.22 * Math.exp(-R / 4.5) * dn * (1 - fvGal3Smooth((R - 13) / 5)));
      var er = aO * cO[0] + G.A_YOUNG * young * cY[0], eg = aO * cO[1] + G.A_YOUNG * young * cY[1], eb = aO * cO[2] + G.A_YOUNG * young * cY[2];
      M.r[o] = er * Math.exp(-dust * kd[0]) + (1 - cc) * kr; M.g[o] = eg * Math.exp(-dust * kd[1]) + (1 - cc) * kg; M.b[o] = eb * Math.exp(-dust * kd[2]) + (1 - cc) * kb;
      M.dust[o] = dust; M.arm[o] = young; M.armDust[o] = adl;
   }
}
function fvGalDataMixEnd(M, S) {
   var WG = S.wg;
   return { N: M.N, H: M.H, px: M.px, r: M.r, g: M.g, b: M.b, dust: M.dust, arm: M.arm, armDust: M.armDust, ms: 0, brk: FV_GAL3_BREAK, stars: null, data: "mix",
            warp: WG.z, warpMax: WG.max, warpR0: (FV_GAL_DATA.WARP.RD - 0.5) * (FV_GAL_DATA.WARP.RD - 0.5), warpF: fvGalDataWarp, pts: fvGalDataPts(S, ["H", "M"]), conf: M.cN, sY: M.sY, sD: M.sD };
}
// EL MAPA «SOLO DATOS»: sin modelo (ni disco viejo, ni brazos, ni bulbo, ni grano procedimental, ni estrellas sembradas): el resplandor de la
// densidad de gas de las nubes (dato suavizado) y los tres trazadores como puntos con su altura real
function fvGalDataSolo(S) {
   var A = FV_GAL_DATA, G = FV_GAL3, N = G.TEX_N, H = G.TEX_H, px = 2 * H / N, n2 = N * N, col = A.SOLO_COL;
   var R_ = new Float32Array(n2), G_ = new Float32Array(n2), B_ = new Float32Array(n2), Z0 = new Float32Array(n2), DD = fvGalDataUp(S.dd, S.NK, S.H, N);
   for (var o = 0; o < n2; ++o) { var g = DD[o], v = A.SOLO_GLOW * g / (g + 1.5); R_[o] = v * col[0]; G_[o] = v * col[1]; B_[o] = v * col[2]; }
   var WG = S.wg;
   return { N: N, H: H, px: px, r: R_, g: G_, b: B_, dust: Z0, arm: Z0, armDust: Z0, ms: 0, brk: FV_GAL3_BREAK, stars: null, data: "solo",
            noStars: true, bulgeK: 0, warp: WG.z, warpMax: WG.max, warpR0: (FV_GAL_DATA.WARP.RD - 0.5) * (FV_GAL_DATA.WARP.RD - 0.5), pts: fvGalDataPts(S, ["C", "H", "M"]) };
}
// el mapa que toca ahora (o null si la bandera esta apagada o no hay datos)
function fvGalDataTex() {
   var S = FV_GAL_DATA_ST; if (!FV_GAL_DATA.ON || !S) return null;
   return FV_GAL_DATA.SOLO ? S.solo : S.mix;
}
// los puntos al bufer lineal: un sprite gausiano de radio r px con reparto subpixel; amplitud fija (son marcas, no estrellas)
function fvGalDataSplatPts(cam, W, H, buf, L, gn) {
   var G = FV_GAL3, R0 = G.R0, fw = cam.fw, r = cam.r, d = cam.d, f = cam.f, cx = cam.cx, cy = cam.cy;
   for (var q = 0; q < L.length; ++q) {
      var S = L[q], P = S.p, Am = S.a, col = S.col, rr = S.r, ir2 = 1 / (2 * rr * rr), rad = Math.ceil(2 * rr);
      for (var m = 0; m < S.n; ++m) {
         var rx = P[3 * m] + R0 - cam.pos[0], ry = P[3 * m + 1] - cam.pos[1], rz = P[3 * m + 2] - G.ZSUN - cam.pos[2];
         var zc = rx * fw[0] + ry * fw[1] + rz * fw[2]; if (zc < 0.05) continue;
         var X2 = cx + f * (rx * r[0] + ry * r[1] + rz * r[2]) / zc - 0.5, Y2 = cy + f * (rx * d[0] + ry * d[1] + rz * d[2]) / zc - 0.5;
         var ix = Math.round(X2), iy = Math.round(Y2); if (ix < rad || iy < rad || ix >= W - rad || iy >= H - rad) continue;
         var a = Am[m] * gn;
         for (var dy = -rad; dy <= rad; ++dy) for (var dx = -rad; dx <= rad; ++dx) {
            var ex = ix + dx - X2, ey = iy + dy - Y2, k = Math.exp(-(ex * ex + ey * ey) * ir2) * a; if (k < 0.004) continue;
            var o = 3 * ((iy + dy) * W + ix + dx); buf[o] += col[0] * k; buf[o + 1] += col[1] * k; buf[o + 2] += col[2] * k;
         }
      }
   }
}

// ---------------------------------------------------------------------------
// LA METRICA PUNTO–EJE DE BRAZO (pruebas): distancia (kpc, en el plano) de cada punto al eje de brazo mas cercano (o al suyo, si se da el
// mapa de nombres de Reid); rot = puntos girados 180° alrededor del centro (control en ROJO). Con FV_GAL3_BREAK = "beta", los ejes en espejo.
// ---------------------------------------------------------------------------
function fvGalDataArmAxes(minW) {
   var tabs = fvGal3Tables(), out = [], mw = (minW === undefined) ? 0.05 : minW;
   for (var t = 0; t < tabs.length; ++t) {
      var T = tabs[t], xs = [], ys = [];
      for (var k = 0; k < T.n; ++k) {
         if (T.w[k] < mw) continue;
         var bb = T.b0 + k * T.st, R = Math.exp(T.ln[k]), b = (FV_GAL3_BREAK === "beta" ? -bb : bb) * Math.PI / 180;
         xs.push(-R * Math.cos(b)); ys.push(R * Math.sin(b));
      }
      out.push({ id: T.a.id, x: xs, y: ys });
   }
   return out;
}
function fvGalDataArmDist(list, axes, rot, own) {
   var res = [];
   for (var q = 0; q < list.length; ++q) {
      var p = list[q], X = rot ? -p.X : p.X, Y = rot ? -p.Y : p.Y, want = own ? FV_GAL_DATA.ARM_MAP[p.arm] : null;
      if (own && !want) continue;
      var best = Infinity;
      for (var a = 0; a < axes.length; ++a) {
         if (want && axes[a].id !== want) continue;
         var xs = axes[a].x, ys = axes[a].y;
         for (var k = 0; k < xs.length; ++k) { var dx = xs[k] - X, dy = ys[k] - Y, d2 = dx * dx + dy * dy; if (d2 < best) best = d2; }
      }
      if (best < Infinity) res.push(Math.sqrt(best));
   }
   res.sort(function(a, b) { return a - b; });
   return { n: res.length, med: res.length ? res[res.length >> 1] : NaN, f03: res.length ? res.filter(function(v) { return v < 0.3; }).length / res.length : NaN };
}
