// ============================================================================
// FieldVoyager/src/engine/fv_galaxy3d.js — LA VIA LACTEA VISTA DESDE FUERA (encargo D, 9-nov-2026). PURO (sin PixInsight).
// ----------------------------------------------------------------------------
// Una galaxia PROCEDIMENTAL hecha solo con parametros publicados (nada de imagenes de terceros):
//   · BRAZOS: espirales logaritmicas de Reid et al. 2019, ApJ 885, 131 («Trigonometric parallaxes of high-mass star-forming regions:
//     our view of the Milky Way», arXiv:1910.03357v1), TABLA 2 («Spiral Arm Characteristics»): para cada brazo, el azimut del codo β_kink,
//     su radio R_kink, la inclinacion ψ antes y despues del codo, la anchura y el tramo de β con paralajes. Formula de la §3 (sin numero):
//     ln(R/R_kink) = −(β − β_kink)·tan ψ, β = 0 hacia el Sol y creciendo en el sentido de la rotacion (hacia l = 90°).
//     VERIFICADO el 9-nov-2026 contra la tabla 2 del arXiv v1: los siete brazos, cifra a cifra (los β_kink sin error son ASIGNADOS por los
//     autores, no ajustados: lo dice la nota de la tabla). R0 = 8,15 ± 0,15 kpc y Z☉ = 5,5 ± 5,8 pc: resumen y §6 del mismo trabajo.
//     Comprobacion del convenio: con ψ< prolongado hacia β < 0, Norma es tangente en l ≈ 327° y Sgr–Car en l ≈ 286° (tabla 2: 327,5° y 285,6°).
//     El LADO LEJANO no tiene paralajes: cada brazo mayor se prolonga EXT_FULL = 100° por cada punta con SU inclinacion medida en esa punta
//     (ψ< hacia abajo, ψ> hacia arriba) y se desvanece; Sgr–Car, hacia abajo, pasa a 10° mas alla de la tangente del 4.º cuadrante
//     (β ≈ −26°), como dice el texto de Reid et al. 2019. Lo mas sobrio: ninguna inclinacion inventada, y ningun brazo da la vuelta entera
//     (el mas largo, Perseo, cubre 138° medidos + 200° extrapolados, desvaneciendose). La placa lo dice: «lado lejano extrapolado».
//     El brazo de 3 kpc LEJANO (3kpcF) es el cercano girado 180°: Reid et al. solo dan el cercano, pero Dame & Thaddeus 2008 (ApJ 683, L143)
//     encontraron en CO el brazo de 3 kpc lejano, simetrico del cercano en longitud, velocidad, anchura, altura y masa (encargo GG, S4).
//   · BARRA Y BULBO: Bland-Hawthorn & Gerhard 2016, ARA&A 54, 529 (arXiv:1602.07702v2), VERIFICADO el 9-nov-2026:
//     §4.2.1, bulbo en caja/cacahuete a 27° ± 2° de la linea Sol–centro, escalas exponenciales 0,70 : 0,44 : 0,18 kpc;
//     §4.3, barra larga de semilongitud 5,0 ± 0,2 kpc a 28°–33°, altura de escala ~180 pc. Extremo cercano en l > 0.
//     Aqui son gausianas triaxiales (su integral a lo largo de un rayo es cerrada; la exponencial no): σ = 2h con la MISMA razon de ejes
//     para el bulbo, σ = 2,5 kpc a lo largo de la barra larga (la luz cae a e⁻² en 5 kpc) a 30° (el medio del intervalo); la anchura de la
//     barra larga en el plano y el nucleo son ELECCION NUESTRA.
//   · DISCO VIEJO exponencial de escala 2,6 kpc (el mismo FV_GALMOD.HR de fv_scene.js).
//   · POLVO en el borde INTERIOR (concavo) de cada brazo, como en las espirales vistas de cara, y nudos HII rosas y cumulos azules
//     sembrados a lo largo de los brazos (posiciones al azar con semilla fija: ilustrativas).
// Todo es un mapa de cara (TEX_N × TEX_N texeles sobre ±TEX_H kpc) que se calcula UNA vez; la vista se pinta rayo a rayo: el disco es
// el plano z = 0 (brillo superficial × 1/|cos i|: un disco fino se ve mas brillante de canto) y el bulbo, la integral de sus gausianas.
// El mismo mapa de brazos y polvo alimenta la Via Lactea de fondo (fv_milkyway.js, FV_MW2): una sola galaxia, vista desde fuera o
// desde dentro.
// Coordenadas: «Sol» = galacticas centradas en el Sol en kpc (x hacia el centro, y hacia l = 90°, z al polo norte); «gc» = galactocentricas
// X = x − R0, Y = y, Z = z + Z☉. Un punto del brazo (R, β) esta en X = −R·cos β, Y = R·sin β.
// ES5.
// ============================================================================

var FV_GAL3 = {
   R0: 8.15, ZSUN: 0.0055,
   TEX_N: 640, TEX_H: 20,                 // texeles de 62,5 pc
   R_IN: 3.0, R_OUT: 16.5, EXT_FULL: 100,  // la prolongacion de los brazos mayores: grados por cada punta (ELECCION NUESTRA; inclinacion, la medida)
   // Reid et al. 2019, tabla 2 (VERIFICADA, arXiv:1910.03357v1): bk β_kink (°), rk R_kink (kpc), p1 ψ< (°), p2 ψ> (°), w anchura (kpc), [b0, b1] tramo con
   // paralajes (°). Lo nuestro: L brillo de estrellas jovenes, D polvo, full = se prolonga por el lado lejano, ext = grados de prolongacion
   // (con su propia inclinacion) de los que no; lo2 = [β, ψ]: por debajo de ese β, esa inclinacion (Sgr–Car, texto de Reid et al.);
   // lab/lb = rotulo y azimut donde va.
   ARMS: [
      { id: "3kpc",  bk: 15, rk: 3.52,  p1: -4.2, p2: -4.2, w: 0.18, b0: 15,  b1: 18,  L: 0.30, D: 0.35, ext: 60 },
      { id: "3kpcF", bk: 195, rk: 3.52, p1: -4.2, p2: -4.2, w: 0.18, b0: 195, b1: 198, L: 0.30, D: 0.35, ext: 60 },   // el 3 kpc lejano (simetrico)
      { id: "norma", bk: 18, rk: 4.46,  p1: -1.0, p2: 19.5, w: 0.14, b0: 5,   b1: 54,  L: 0.70, D: 0.85, full: true, lab: "gal.arm.norma", lb: -70 },
      { id: "scucen", bk: 23, rk: 4.91, p1: 14.1, p2: 12.1, w: 0.23, b0: 0,   b1: 104, L: 1.00, D: 1.00, full: true, lab: "gal.arm.scucen", lb: -95 },
      { id: "sgrcar", bk: 24, rk: 6.04, p1: 17.1, p2: 1.0,  w: 0.27, b0: 2,   b1: 97,  L: 0.80, D: 0.90, full: true, lo2: [-26, 10], lab: "gal.arm.sgrcar", lb: -40 },
      { id: "local", bk: 9,  rk: 8.26,  p1: 11.4, p2: 11.4, w: 0.31, b0: -8,  b1: 34,  L: 0.45, D: 0.45, ext: 35, lab: "gal.arm.local", lb: 30 },
      { id: "perseus", bk: 40, rk: 8.87, p1: 10.3, p2: 8.7, w: 0.35, b0: -23, b1: 115, L: 1.00, D: 0.95, full: true, lab: "gal.arm.perseus", lb: 75 },
      { id: "outer", bk: 18, rk: 12.24, p1: 3.0,  p2: 9.4,  w: 0.65, b0: -16, b1: 71,  L: 0.45, D: 0.35, ext: 60, lab: "gal.arm.outer", lb: 40 }
   ],
   BAR_ANG: 27,                            // el bulbo en caja: 27° ± 2° (Bland-Hawthorn & Gerhard 2016, §4.2.1); la barra larga lleva el suyo
   // gausianas triaxiales (sx a lo largo de la barra, sy de canto en el plano, sz en altura; kpc), su brillo (ELECCION NUESTRA) y su angulo (°)
   BULGE: [ { sx: 1.40, sy: 0.88, sz: 0.36, a: 0.55, ang: 27 },  // caja/cacahuete: σ = 2h, h = 0,70 : 0,44 : 0,18 kpc (BHG16 §4.2.1)
            { sx: 2.50, sy: 0.50, sz: 0.20, a: 0.22, ang: 30 },  // barra larga: semilongitud 5,0 kpc = 2σ, 28°–33° (BHG16 §4.3); sy NUESTRO
            { sx: 0.28, sy: 0.28, sz: 0.22, a: 1.10, ang: 27 } ],// el nucleo (ELECCION NUESTRA)
   HR_OLD: 2.6,
   // colores lineales (esteticos: tonos de las fotos de espirales de cara)
   COL_OLD: [1.00, 0.80, 0.58], COL_YOUNG: [0.58, 0.72, 1.00], COL_HII: [1.00, 0.34, 0.50], COL_CL: [0.70, 0.82, 1.00], COL_BULGE: [1.00, 0.74, 0.47],
   A_OLD: 0.55, A_YOUNG: 0.55, A_HII: 1.6, A_CL: 0.9, DUST_K: 1.4, DUST_RGB: [0.72, 1.0, 1.32],
   N_HII: 560, N_CL: 1100, N_STARS: 16000, SEED: 20191131,
   EXPO: 1.25, GAMMA: 0.88,
   KMAX: 2.5,                             // (ronda 2) tope del 1/|cos i| del disco (antes 4: rasante y de cerca se quemaba; de cara no llega a 1,3)
   SLAB0: 0.35                            // (ronda 2) brillo minimo del disco visto desde muy cerca del plano (antes 0: negro por debajo de 50 pc)
};
var FV_GAL3_TEX = null;          // el mapa de cara (se calcula la primera vez que se pide)
var FV_GAL3_MIX = null;           // (encargo GP) el mapa de cara de los DATOS (fv_galdata.js) cuando FV_GAL_DATA.ON; null = el de hoy
var FV_GAL3_BREAK = "";           // controles en ROJO de las pruebas: "beta" (β al reves: los brazos salen en espejo), "dustout" (polvo por fuera)

// ---------------------------------------------------------------------------
// ruido de valor con semilla (2D y 3D) y su fbm en [0, 1]
// ---------------------------------------------------------------------------
function fvGal3H(i, j, k, s) {
   var h = (Math.imul(i | 0, 374761393) + Math.imul(j | 0, 668265263) + Math.imul(k | 0, 2147483647) + Math.imul(s | 0, 1274126177)) | 0;
   h = Math.imul(h ^ (h >>> 13), 1103515245); h ^= h >>> 16;
   return (h >>> 0) / 4294967296;
}
var FV_GAL3_LAT2 = null;
// ruido de valor 2D sobre una red fija de 256² (periodica, 256 unidades: mucho mas que la galaxia a cualquier escala usada); la semilla desplaza
function fvGal3N2(x, y, s) {
   var L = FV_GAL3_LAT2; if (!L) { L = FV_GAL3_LAT2 = new Float32Array(65536); var r = fvRng(8128); for (var q = 0; q < 65536; ++q) L[q] = r(); }
   x += 37.17 * s; y += 11.31 * s;
   var ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy, x0 = ix & 255, y0 = iy & 255, x1 = (x0 + 1) & 255, y1 = (y0 + 1) & 255;
   fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
   var a = L[(y0 << 8) | x0], b = L[(y0 << 8) | x1], c = L[(y1 << 8) | x0], d = L[(y1 << 8) | x1];
   return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy;
}
function fvGal3Fbm2(x, y, s, oct) { var v = 0, A = 0, a = 1, f = 1; for (var o = 0; o < oct; ++o) { v += a * fvGal3N2(x * f, y * f, s + 17 * o); A += a; a *= 0.55; f *= 2.03; } return v / A; }
var FV_GAL3_LAT = null;
function fvGal3Lat() { if (!FV_GAL3_LAT) { var a = new Float32Array(32 * 32 * 32), r = fvRng(4242); for (var i = 0; i < a.length; ++i) a[i] = r(); FV_GAL3_LAT = a; } return FV_GAL3_LAT; }
function fvGal3Smooth(t) { t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t); }

// ---------------------------------------------------------------------------
// LOS BRAZOS: tabla de ln R(β) cada 0,5° (tramo medido + prolongacion) y su peso (se desvanecen en las puntas)
// ---------------------------------------------------------------------------
function fvGal3ArmTable(a) {
   var G = FV_GAL3, st = 0.5, D2R = Math.PI / 180;
   function lnRm(bb) { var p = bb < a.bk ? a.p1 : a.p2; return Math.log(a.rk) - (bb - a.bk) * D2R * Math.tan(p * D2R); }
   var lo = a.b0, hi = a.b1, lnLo = lnRm(lo), lnHi = lnRm(hi), tLo = Math.tan(a.p1 * D2R), tHi = Math.tan(a.p2 * D2R);
   var ext = a.full ? G.EXT_FULL : (a.ext || 0), w0 = a.full ? 0.85 : 1;
   // prolongacion hacia abajo con ψ< (y el cambio publicado de Sgr–Car), hacia arriba con ψ>: la inclinacion MEDIDA en cada punta
   function lnBelow(bb) {
      if (a.lo2 && bb < a.lo2[0] && a.lo2[0] < lo) return lnLo + (lo - a.lo2[0]) * D2R * tLo + (a.lo2[0] - bb) * D2R * Math.tan(a.lo2[1] * D2R);
      return lnLo + (lo - bb) * D2R * tLo;
   }
   // el peso se mantiene el primer 35 % de la prolongacion y luego cae suave hasta 0 en la punta
   function fade(x) { return w0 * (1 - fvGal3Smooth((x / Math.max(1, ext) - 0.35) / 0.65)); }
   var b0 = lo - ext, b1 = hi + ext, n = Math.ceil((b1 - b0) / st) + 1, ln = new Float64Array(n), w = new Float32Array(n);
   for (var k = 0; k < n; ++k) {
      var bb = b0 + k * st, l, ww;
      if (bb < lo) { l = lnBelow(bb); ww = fade(lo - bb); }
      else if (bb > hi) { l = lnHi - (bb - hi) * D2R * tHi; ww = fade(bb - hi); }
      else { l = lnRm(bb); ww = 1; }
      var R = Math.exp(l);
      ww *= fvGal3Smooth((R - G.R_IN) / 1.3) * (1 - fvGal3Smooth((R - 13.5) / 3.2));
      ln[k] = l; w[k] = ww;
   }
   return { a: a, b0: b0, b1: b1, st: st, ln: ln, w: w, n: n };
}
// radio del brazo en el azimut bb (grados, dentro de su tramo) -> [R, peso] (o null)
function fvGal3ArmAt(T, bb) {
   if (bb < T.b0 || bb > T.b1) return null;
   var u = (bb - T.b0) / T.st, k = Math.floor(u), f = u - k; if (k >= T.n - 1) { k = T.n - 2; f = 1; }
   return [Math.exp(T.ln[k] * (1 - f) + T.ln[k + 1] * f), T.w[k] * (1 - f) + T.w[k + 1] * f];
}
// la anchura de la luz del brazo (kpc): mas ancha que la de los maseres de Reid (las estrellas jovenes se dispersan)
function fvGal3Sigma(a, R) { return 0.22 + 0.9 * a.w + 0.02 * R; }
function fvGal3Tables() { if (!FV_GAL3.tabs || FV_GAL3.tabsBreak !== FV_GAL3_BREAK) { FV_GAL3.tabs = FV_GAL3.ARMS.map(fvGal3ArmTable); FV_GAL3.tabsBreak = FV_GAL3_BREAK; } return FV_GAL3.tabs; }
// el azimut β (grados) de un punto galactocentrico (X, Y)
function fvGal3Beta(X, Y) { var b = Math.atan2(Y, -X) * 180 / Math.PI; return FV_GAL3_BREAK === "beta" ? -b : b; }
// el punto (X, Y) galactocentrico de un brazo en su azimut
function fvGal3ArmPoint(id, bb) {
   var tabs = fvGal3Tables();
   for (var i = 0; i < tabs.length; ++i) if (tabs[i].a.id === id) { var r = fvGal3ArmAt(tabs[i], bb); if (!r) return null; var b = (FV_GAL3_BREAK === "beta" ? -bb : bb) * Math.PI / 180; return [-r[0] * Math.cos(b), r[0] * Math.sin(b)]; }
   return null;
}

// la luz de UN brazo en (X, Y) (las pruebas)
function fvGal3ArmOnly(id, X, Y, dust) {
   var tabs = fvGal3Tables(), R = Math.sqrt(X * X + Y * Y), beta = fvGal3Beta(X, Y), v = 0;
   for (var t = 0; t < tabs.length; ++t) {
      var T = tabs[t]; if (T.a.id !== id) continue;
      for (var kk = -2; kk <= 1; ++kk) {
         var r = fvGal3ArmAt(T, beta + 360 * kk); if (!r) continue; var s = fvGal3Sigma(T.a, r[0]), dR = R - r[0];
         if (dust) { var dd = (FV_GAL3_BREAK === "dustout") ? dR - 0.45 * s : dR + 0.45 * s, sd = 0.32 * s; v += r[1] * Math.exp(-0.5 * dd * dd / (sd * sd)); }
         else v += r[1] * Math.exp(-0.5 * dR * dR / (s * s));
      }
   }
   return v;
}
// ---------------------------------------------------------------------------
// EL MAPA DE CARA (una vez): r, g, b (emision ya atenuada por su polvo), dust (profundidad optica), arm (densidad de jovenes con ruido)
// ---------------------------------------------------------------------------
var FV_GAL3_BUILD = null;        // el calculo del mapa de cara POR TROZOS (para no dar un tiron: lo va adelantando el pintor en casa)
function fvGal3Tex() { while (!fvGal3TexStep(0)) {} return FV_GAL3_TEX; }
function fvGal3TexReady() { if (typeof fvGalColorSync === "function") fvGalColorSync(); return !!(FV_GAL3_TEX && FV_GAL3_TEX.brk === FV_GAL3_BREAK); }   // (encargo GC) con FV_GAL_COLOR.ON pone los colores reales antes de cualquier mapa; apagada no hace nada
// avanza el calculo como mucho ms milisegundos (0 = sin tope) -> true cuando esta hecho
function fvGal3TexStep(ms) {
   if (fvGal3TexReady()) return true;
   var G = FV_GAL3, N = G.TEX_N, H = G.TEX_H, px = 2 * H / N, n2 = N * N, t0 = Date.now(), NR = 480, NBt = 1080;
   if (!FV_GAL3_BUILD || FV_GAL3_BUILD.brk !== FV_GAL3_BREAK)
      FV_GAL3_BUILD = { brk: FV_GAL3_BREAK, jb: 0, j: 0, ms: 0, R_: new Float32Array(n2), G_: new Float32Array(n2), B_: new Float32Array(n2), Du: new Float32Array(n2), Ar: new Float32Array(n2), AD: new Float32Array(n2), PY: new Float32Array(NR * NBt), PD: new Float32Array(NR * NBt) };
   var BS = FV_GAL3_BUILD, R_ = BS.R_, G_ = BS.G_, B_ = BS.B_, Du = BS.Du, Ar = BS.Ar, AD = BS.AD;
   var cO = G.COL_OLD, cY = G.COL_YOUNG, kd = G.DUST_RGB, i, j;
   function over() { return ms > 0 && Date.now() - t0 > ms; }
   // los brazos en una rejilla POLAR (R, β): en cada columna de β los cruces de cada brazo se buscan UNA vez (la misma cuenta que
   // fvGal3ArmDensity, que queda para las pruebas) y luego se pasan a la rejilla cartesiana con una muestra bilineal
   var dRp = H / NR, PY = BS.PY, PD = BS.PD, tabs0 = fvGal3Tables(), q, kk;
   for (var jb = BS.jb; jb < NBt; ++jb) {
      if (over()) { BS.jb = jb; BS.ms += Date.now() - t0; return false; }
      var beta = -180 + 360 * jb / NBt, base = jb * NR;
      for (q = 0; q < tabs0.length; ++q) for (kk = -2; kk <= 1; ++kk) {
         var ra = fvGal3ArmAt(tabs0[q], beta + 360 * kk); if (!ra || ra[1] <= 0) continue;
         var A0 = tabs0[q].a, s = fvGal3Sigma(A0, ra[0]), sd = 0.32 * s, sh = (FV_GAL3_BREAK === "dustout") ? -0.45 * s : 0.45 * s;
         var ir0 = Math.max(0, Math.floor((ra[0] - 4 * s) / dRp)), ir1 = Math.min(NR - 1, Math.ceil((ra[0] + 4 * s) / dRp)), aL = A0.L * ra[1], aD = A0.D * ra[1], i2s = 0.5 / (s * s), i2d = 0.5 / (sd * sd);
         for (var ir = ir0; ir <= ir1; ++ir) { var dR = (ir + 0.5) * dRp - ra[0], dd = dR + sh; PY[base + ir] += aL * Math.exp(-dR * dR * i2s); PD[base + ir] += aD * Math.exp(-dd * dd * i2d); }
      }
   }
   BS.jb = NBt;
   function polar(arr, R, beta) {
      var u = R / dRp - 0.5, v = (beta + 180) / 360 * NBt, i0 = Math.floor(u), j0 = Math.floor(v), fu = u - i0, fv = v - j0;
      if (i0 < 0) { i0 = 0; fu = 0; } if (i0 >= NR - 1) { i0 = NR - 2; fu = 1; }
      var j1 = (j0 + 1) % NBt; j0 = ((j0 % NBt) + NBt) % NBt;
      return (arr[j0 * NR + i0] * (1 - fu) + arr[j0 * NR + i0 + 1] * fu) * (1 - fv) + (arr[j1 * NR + i0] * (1 - fu) + arr[j1 * NR + i0 + 1] * fu) * fv;
   }
   for (j = BS.j; j < N; ++j) {
      if (over()) { BS.j = j; BS.ms += Date.now() - t0; return false; }
      var Y = -H + (j + 0.5) * px;
      for (i = 0; i < N; ++i) {
         var X = -H + (i + 0.5) * px, R = Math.sqrt(X * X + Y * Y), o = j * N + i;
         if (R > H) continue;
         var old = Math.exp(-R / G.HR_OLD) * (1 - Math.exp(-R * R / (2.6 * 2.6))) * (1 - fvGal3Smooth((R - 15) / 4.5));
         var bt = fvGal3Beta(X, Y), ay = polar(PY, R, bt), adl = polar(PD, R, bt);
         var floc = 0.30 + 1.45 * fvGal3Fbm2(X / 0.9, Y / 0.9, 11, 3);                  // estrellas jovenes en grumos
         var dn = fvGal3Fbm2(X / 0.55, Y / 0.55, 23, 3), young = ay * floc;
         var dust = G.DUST_K * (adl * (0.30 + 1.5 * dn) + 0.22 * Math.exp(-R / 4.5) * dn * (1 - fvGal3Smooth((R - 13) / 5)));
         var er = G.A_OLD * old * cO[0] + G.A_YOUNG * young * cY[0], eg = G.A_OLD * old * cO[1] + G.A_YOUNG * young * cY[1], eb = G.A_OLD * old * cO[2] + G.A_YOUNG * young * cY[2];
         R_[o] = er * Math.exp(-dust * kd[0]); G_[o] = eg * Math.exp(-dust * kd[1]); B_[o] = eb * Math.exp(-dust * kd[2]);
         Du[o] = dust; Ar[o] = young; AD[o] = adl;
      }
   }
   // nudos HII (rosas) y cumulos jovenes (azules) a lo largo de los brazos: semilla fija, ilustrativos
   var rng = fvRng(G.SEED), tabs = fvGal3Tables(), wsum = 0, cum = [];
   for (i = 0; i < tabs.length; ++i) { wsum += tabs[i].a.L * (tabs[i].b1 - tabs[i].b0); cum.push(wsum); }
   function gauss() { var u = Math.max(1e-9, rng()), v = rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
   function splat(X, Y, rr, col, amp) {
      var ci = (X + H) / px - 0.5, cj = (Y + H) / px - 0.5, rp = rr / px, rad = Math.ceil(2.5 * rp);
      for (var jj = Math.max(0, Math.floor(cj - rad)); jj <= Math.min(N - 1, Math.ceil(cj + rad)); ++jj)
         for (var ii = Math.max(0, Math.floor(ci - rad)); ii <= Math.min(N - 1, Math.ceil(ci + rad)); ++ii) {
            var dx = ii - ci, dy = jj - cj, q = Math.exp(-0.5 * (dx * dx + dy * dy) / (rp * rp)) * amp, oo = jj * N + ii, tr = Math.exp(-0.6 * Du[oo]);
            R_[oo] += q * col[0] * tr; G_[oo] += q * col[1] * tr; B_[oo] += q * col[2] * tr;
         }
   }
   var nk = G.N_HII + G.N_CL;
   for (var n = 0; n < nk; ++n) {
      var hii = n < G.N_HII, pick = rng() * wsum, ti = 0; while (ti < cum.length - 1 && cum[ti] < pick) ++ti;
      var T = tabs[ti], bb = T.b0 + rng() * (T.b1 - T.b0), ar = fvGal3ArmAt(T, bb);
      if (!ar || rng() > ar[1]) continue;
      var Rk = ar[0] + gauss() * 0.45 * fvGal3Sigma(T.a, ar[0]), be = (FV_GAL3_BREAK === "beta" ? -bb : bb) * Math.PI / 180, Xk = -Rk * Math.cos(be), Yk = Rk * Math.sin(be);
      if (hii) splat(Xk, Yk, 0.035 + 0.06 * rng(), G.COL_HII, G.A_HII * (0.25 + 0.75 * rng() * rng()));
      else splat(Xk, Yk, 0.03 + 0.03 * rng(), G.COL_CL, G.A_CL * (0.2 + 0.8 * rng() * rng()));
   }
   FV_GAL3_TEX = { N: N, H: H, px: px, r: R_, g: G_, b: B_, dust: Du, arm: Ar, armDust: AD, ms: BS.ms + Date.now() - t0, brk: FV_GAL3_BREAK, stars: null };
   FV_GAL3_BUILD = null;
   return true;
}
// muestra bilineal de un canal del mapa en (X, Y) galactocentricos (0 fuera)
function fvGal3TexAt(T, ch, X, Y) {
   var u = (X + T.H) / T.px - 0.5, v = (Y + T.H) / T.px - 0.5, i0 = Math.floor(u), j0 = Math.floor(v), N = T.N;
   if (i0 < 0 || j0 < 0 || i0 >= N - 1 || j0 >= N - 1) return 0;
   var fu = u - i0, fv = v - j0, o = j0 * N + i0;
   return (ch[o] * (1 - fu) + ch[o + 1] * fu) * (1 - fv) + (ch[o + N] * (1 - fu) + ch[o + N + 1] * fu) * fv;
}

// ---------------------------------------------------------------------------
// LAS ESTRELLAS SUELTAS de la vista (el grano: se ven moverse al alejarse) — repartidas como el brillo del mapa
// ---------------------------------------------------------------------------
function fvGal3Stars() { return fvGal3StarsOf(fvGal3Tex()); }
// (ronda 2b) las de cualquier mapa de cara (el procedimental o el hecho desde una imagen, fvGal3TexFromPixels): la misma cuenta y semilla
function fvGal3StarsOf(T) {
   if (T.stars) return T.stars;
   var G = FV_GAL3, N = T.N, n2 = N * N, cdf = new Float64Array(n2), s = 0, i, rng = fvRng(G.SEED + 7);
   for (i = 0; i < n2; ++i) { s += Math.pow(T.r[i] + T.g[i] + T.b[i], 1.2); cdf[i] = s; }
   var M = G.N_STARS, P = new Float32Array(3 * M), C = new Float32Array(3 * M);
   for (var n = 0; n < M; ++n) {
      var t = rng() * s, lo = 0, hi = n2 - 1;
      while (lo < hi) { var m = (lo + hi) >> 1; if (cdf[m] < t) lo = m + 1; else hi = m; }
      var X = -T.H + ((lo % N) + rng()) * T.px, Y = -T.H + (Math.floor(lo / N) + rng()) * T.px, young = T.arm[lo] > 0.25 && rng() < 0.6;
      var u = Math.max(1e-9, rng()), z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * rng()) * (young ? 0.05 : 0.15);
      if (T.warpF) z += T.warpF(X, Y);                                 // (encargo GP) el alabeo del disco
      P[3 * n] = X; P[3 * n + 1] = Y; P[3 * n + 2] = z;
      var c = young ? G.COL_CL : G.COL_OLD, a = 0.25 + 0.75 * Math.pow(rng(), 3);
      C[3 * n] = c[0] * a; C[3 * n + 1] = c[1] * a; C[3 * n + 2] = c[2] * a;
   }
   T.stars = { n: M, p: P, c: C };
   return T.stars;
}

// ---------------------------------------------------------------------------
// LA VISTA: rayo a rayo en un bufer lineal RGB (Float32Array 3·W·H). cam: { pos (Sol, kpc), fw, r, d (unitarios en galacticas), f, cx, cy }
// (cx, cy, f en pixeles del bufer). gain multiplica todo (la entrada en fundido).
// ---------------------------------------------------------------------------
// (ronda 2) y0, y1: solo esas filas (la vista final se va calculando a trozos durante la ida); las estrellas, en el trozo que acaba en H.
// DETALLE: cuando el disco se ve de cerca (un texel de 62,5 pc ocupa mas de ~2 px) se le añade grano fino de ruido (escalas de 90 y 30 pc, ±50 %),
// para que no se vea borroso al pasar cerca del plano (D-2); de lejos su peso es 0 y la vista es la de antes.
var FV_GAL3_DETAIL = { ON: true, PX0: 2.0, PX1: 8.0, AMP: 0.5, S1: 0.090, S2: 0.030 };
function fvGal3Render(cam, W, H, buf, gain, y0, y1, opt) {
   var G = FV_GAL3, T = FV_GAL3_MIX || fvGal3Tex(), R0 = G.R0, gn = (gain === undefined) ? 1 : gain, ya = (y0 === undefined) ? 0 : y0, yb = (y1 === undefined) ? H : y1;
   // (GF11) con la bandera: el mapa de fondo (la luz no resuelta; en movimiento, opt.move, el de movimiento) y lo que cada pixel deja a las estrellas. Apagada: nada
   var g11 = (typeof fvGf11Get === "function") ? fvGf11Get(T) : null, mv11 = !!(opt && opt.move), P11 = null, PA = null, PB = null, PT = null, PF = null;
   if (g11) { T = mv11 ? g11.bgMove : g11.bg; P11 = fvGf11Pix(buf, W, H); PA = P11.A; PB = P11.B; PT = P11.T; PF = P11.F; }
   var WZ = T.warp || null, WT = WZ ? { N: T.N, H: T.H, px: T.px } : null, bK = (T.bulgeK === undefined ? 1 : T.bulgeK);     // (encargo GP) alabeo y bulbo del mapa de datos
   var Ox = cam.pos[0] - R0, Oy = cam.pos[1], Oz = cam.pos[2] + G.ZSUN, slab = (G.SLAB0 + (1 - G.SLAB0) * fvGal3Smooth((Math.abs(Oz) - 0.02) / 0.5)) * (0.45 + 0.55 * fvGal3Smooth(Math.abs(Oz) / 4));   // cerca del plano, sin quemar (ronda 2: sin apagarse del todo, SLAB0)
   var fw = cam.fw, r = cam.r, d = cam.d, f = cam.f, cx = cam.cx, cy = cam.cy, cB = G.COL_BULGE, i;
   for (i = 3 * ya * W; i < 3 * yb * W; ++i) buf[i] = 0;
   if (gn <= 0) return;
   // la barra y el bulbo: cada gausiana en sus ejes (u hacia el extremo cercano, en l > 0; v en el plano; z) con su angulo
   var sg = (FV_GAL3_BREAK === "beta" ? -1 : 1), Bc = T.bulge || G.BULGE, nb = Bc.length, S = [];      // (GF2) T.bulge: el bulbo del mapa de GF2
   for (var q = 0; q < nb; ++q) {
      var ang = (Bc[q].ang !== undefined ? Bc[q].ang : G.BAR_ANG) * Math.PI / 180 * sg, ux = -Math.cos(ang), uy = Math.sin(ang), vx = Math.sin(ang), vy = Math.cos(ang);
      S.push([1 / (Bc[q].sx * Bc[q].sx), 1 / (Bc[q].sy * Bc[q].sy), 1 / (Bc[q].sz * Bc[q].sz), (bK === 1 ? Bc[q].a : Bc[q].a * bK), ux, uy, vx, vy, Ox * ux + Oy * uy - (Bc[q].u0 || 0), Ox * vx + Oy * vy - (Bc[q].v0 || 0), Oz - (Bc[q].z0 || 0)]);   // (GF5) v0, z0: desplazamientos (0 = lo de antes)
   }
   var Rr = T.r, Rg = T.g, Rb = T.b, Du = T.dust, N = T.N, TH = T.H, tpx = T.px, DT = FV_GAL3_DETAIL, dOn = DT.ON, fT = f * tpx, iS1 = 1 / DT.S1, iS2 = 1 / DT.S2, iDP = 1 / (DT.PX1 - DT.PX0);
   for (var y = ya; y < yb; ++y) {
      var py = (y + 0.5 - cy) / f;
      for (var x = 0; x < W; ++x) {
         var px = (x + 0.5 - cx) / f;
         var dx = fw[0] + px * r[0] + py * d[0], dy = fw[1] + px * r[1] + py * d[1], dz = fw[2] + px * r[2] + py * d[2], nn = 1 / Math.sqrt(dx * dx + dy * dy + dz * dz);
         dx *= nn; dy *= nn; dz *= nn;
         var er = 0, eg = 0, eb = 0, tau = 0, kA = 0;
         // el disco: el plano z = 0
         if (dz * Oz < 0 && slab > 0) {
            var t = -Oz / dz, X = Ox + t * dx, Yp = Oy + t * dy;
            if (WZ && X * X + Yp * Yp > T.warpR0) { for (var itw = 0; itw < 2; ++itw) { t = (fvGal3TexAt(WT, WZ, X, Yp) - Oz) / dz; X = Ox + t * dx; Yp = Oy + t * dy; } if (!(t > 0)) X = 1e9; }   // (encargo GP) el plano medio alabeado
            var u = (X + TH) / tpx - 0.5, v = (Yp + TH) / tpx - 0.5, i0 = Math.floor(u), j0 = Math.floor(v);
            if (i0 >= 0 && j0 >= 0 && i0 < N - 1 && j0 < N - 1) {
               var fu = u - i0, fv = v - j0, o = j0 * N + i0, w00 = (1 - fu) * (1 - fv), w10 = fu * (1 - fv), w01 = (1 - fu) * fv, w11 = fu * fv;
               var k = Math.min(1 / Math.abs(dz), G.KMAX) * slab;
               if (PA) kA = Math.min(1, G.KMAX * Math.abs(dz)) * slab;   // (GF11) el brillo del plano frente al fisico (1/|dz|): lo mismo para sus estrellas
               if (dOn) {
                  var mg = (fT / t - DT.PX0) * iDP;     // texeles por pixel -> peso del grano fino
                  if (mg > 0) { if (mg > 1) mg = 1; mg = mg * mg * (3 - 2 * mg); k *= 1 + mg * DT.AMP * (0.62 * fvGal3N2(X * iS1, Yp * iS1, 5) + 0.38 * fvGal3N2(X * iS2, Yp * iS2, 9) - 0.5) * 2; if (k < 0) k = 0; }
               }
               er = k * (Rr[o] * w00 + Rr[o + 1] * w10 + Rr[o + N] * w01 + Rr[o + N + 1] * w11);
               eg = k * (Rg[o] * w00 + Rg[o + 1] * w10 + Rg[o + N] * w01 + Rg[o + N + 1] * w11);
               eb = k * (Rb[o] * w00 + Rb[o + 1] * w10 + Rb[o + N] * w01 + Rb[o + N + 1] * w11);
               tau = Du[o] * w00 + Du[o + 1] * w10 + Du[o + N] * w01 + Du[o + N + 1] * w11;
            }
         }
         // el bulbo y la barra: integral cerrada de cada gausiana a lo largo del rayo
         var bul = 0;
         for (q = 0; q < nb; ++q) {
            var sq = S[q], du = dx * sq[4] + dy * sq[5], dv = dx * sq[6] + dy * sq[7], Ou = sq[8], Ov = sq[9], Oq = sq[10];
            var a2 = du * du * sq[0] + dv * dv * sq[1] + dz * dz * sq[2], b2 = Ou * du * sq[0] + Ov * dv * sq[1] + Oq * dz * sq[2], c2 = Ou * Ou * sq[0] + Ov * Ov * sq[1] + Oq * Oq * sq[2];
            var ex = 0.5 * (c2 - b2 * b2 / a2);
            if (ex < 30 && b2 < 0) bul += sq[3] * Math.sqrt(2 * Math.PI / a2) * Math.exp(-ex);
         }
         if (bul > 0) { var tr = (tau > 0) ? 0.5 + 0.5 * Math.exp(-tau) : 1; bul *= tr; er += bul * cB[0]; eg += bul * cB[1]; eb += bul * cB[2]; }
         var oi = 3 * (y * W + x); buf[oi] = er * gn; buf[oi + 1] = eg * gn; buf[oi + 2] = eb * gn;
         if (PA) { var p11 = y * W + x; PA[p11] = kA; PB[p11] = 0; PT[p11] = tau; PF[p11] = -1; }   // (GF11) PF −1: la transmision del bulbo se saca de PT en fvGf11Splat (solo para sus estrellas: sin una exp por pixel)
      }
   }
   if (yb < H) return;
   // el grano de estrellas: cada una, un punto con reparto bilineal; brillo con la distancia (cerca, mas)
   if (T.pts && typeof fvGalDataSplatPts === "function") fvGalDataSplatPts(cam, W, H, buf, T.pts, gn);   // (encargo GP) los puntos medidos
   if (g11) { fvGf11Splat(cam, W, H, buf, g11, gn, P11, mv11, null); return; }   // (GF11) las estrellas (sustituyen al grano de siempre)
   if (T.noStars) return;
   var St = FV_GAL3_MIX ? fvGal3StarsOf(T) : fvGal3Stars(), P = St.p, C = St.c;
   for (var m = 0; m < St.n; ++m) {
      var rx = P[3 * m] + R0 - cam.pos[0], ry = P[3 * m + 1] - cam.pos[1], rz = P[3 * m + 2] - G.ZSUN - cam.pos[2];
      var zc = rx * fw[0] + ry * fw[1] + rz * fw[2]; if (zc < 0.05) continue;
      var X2 = cx + f * (rx * r[0] + ry * r[1] + rz * r[2]) / zc - 0.5, Y2 = cy + f * (rx * d[0] + ry * d[1] + rz * d[2]) / zc - 0.5;
      var ix = Math.floor(X2), iy = Math.floor(Y2); if (ix < 0 || iy < 0 || ix >= W - 1 || iy >= H - 1) continue;
      var a3 = 0.06 * gn * Math.min(6, (30 * 30) / (zc * zc)), fx = X2 - ix, fy = Y2 - iy, oo = 3 * (iy * W + ix), ws = [(1 - fx) * (1 - fy), fx * (1 - fy), (1 - fx) * fy, fx * fy], offs = [0, 3, 3 * W, 3 * W + 3];
      for (var w4 = 0; w4 < 4; ++w4) { var ow = oo + offs[w4], ww4 = ws[w4] * a3; buf[ow] += C[3 * m] * ww4; buf[ow + 1] += C[3 * m + 1] * ww4; buf[ow + 2] += C[3 * m + 2] * ww4; }
   }
}
// del bufer lineal a 0xffRRGGBB (curva 1 − e^(−x): satura suave, nunca quema; el negro queda negro). (ronda 2) Con TABLA: 8192 escalones
// sobre x·e en [0, 10] (paso 0,0012: menos de medio nivel de 8 bits en todo el tramo); lo de mas arriba ya es 255.
var FV_GAL3_TONE = { LUT: true, N: 8192, XMAX: 10, tab: null, key: "" };
function fvGal3ToneTab(e) {
   var TT = FV_GAL3_TONE, key = e + "|" + FV_GAL3.GAMMA;
   if (TT.tab && TT.key === key) return TT.tab;
   var n = TT.N, tb = new Uint8Array(n + 1), ig = 1 / FV_GAL3.GAMMA;
   for (var i = 0; i <= n; ++i) tb[i] = Math.round(255 * Math.pow(1 - Math.exp(-(i + 0.5) * TT.XMAX / n), ig));
   tb[0] = 0; TT.tab = tb; TT.key = key; return tb;
}
function fvGal3Tone(buf, px, n, expo) {
   var G = FV_GAL3, e = (expo === undefined) ? G.EXPO : expo, ig = 1 / G.GAMMA;
   if (typeof fvGf2Tone === "function") { var g2 = fvGf2Tone(); if (g2) { fvGf2ToneRun(buf, px, n, e, g2); return; } }   // (encargo GF2) null con su subinterruptor apagado
   if (FV_GAL3_TONE.LUT) {
      var tb = fvGal3ToneTab(e), sc = e * FV_GAL3_TONE.N / FV_GAL3_TONE.XMAX, top = FV_GAL3_TONE.N;
      for (var j = 0; j < n; ++j) {
         var ir = (buf[3 * j] * sc) | 0, ig2 = (buf[3 * j + 1] * sc) | 0, ib = (buf[3 * j + 2] * sc) | 0;
         if (ir > top) ir = top; if (ig2 > top) ig2 = top; if (ib > top) ib = top;
         if (ir < 0) ir = 0; if (ig2 < 0) ig2 = 0; if (ib < 0) ib = 0;
         px[j] = (0xff000000 | (tb[ir] << 16) | (tb[ig2] << 8) | tb[ib]) >>> 0;
      }
      return;
   }
   for (var i = 0; i < n; ++i) {
      var r = Math.pow(1 - Math.exp(-buf[3 * i] * e), ig), g = Math.pow(1 - Math.exp(-buf[3 * i + 1] * e), ig), b = Math.pow(1 - Math.exp(-buf[3 * i + 2] * e), ig);
      px[i] = (0xff000000 | (Math.round(255 * r) << 16) | (Math.round(255 * g) << 8) | Math.round(255 * b)) >>> 0;
   }
}
// del mundo de la escena (años luz, la Tierra en el origen) a galacticas centradas en el Sol (kpc), con el marco de fvMwFrame
function fvGal3Vec(frame, v) { return [v[0] * frame.ex[0] + v[1] * frame.ex[1] + v[2] * frame.ex[2], v[0] * frame.ey[0] + v[1] * frame.ey[1] + v[2] * frame.ey[2], v[0] * frame.ez[0] + v[1] * frame.ez[1] + v[2] * frame.ez[2]]; }
function fvGal3Pt(frame, p) { var k = 1 / (1000 * FV_LY_PER_PC), g = fvGal3Vec(frame, p); return [g[0] * k, g[1] * k, g[2] * k]; }
// la camara de la vista final: casi de cara, algo oblicua, desde detras del Sol, el centro arriba
function fvGal3FinalCam(W, H, o) {
   var G = FV_GAL3, op = o || {}, tilt = (op.tilt !== undefined ? op.tilt : 34) * Math.PI / 180, az = (op.az !== undefined ? op.az : -18) * Math.PI / 180;
   var dist = op.dist || 46, tgt = [G.R0 * (op.tx !== undefined ? op.tx : 0.40), op.ty || 0, 0];
   var up = [-Math.sin(tilt) * Math.cos(az), -Math.sin(tilt) * Math.sin(az), Math.cos(tilt)];
   var pos = [tgt[0] + dist * up[0], tgt[1] + dist * up[1], tgt[2] + dist * up[2]], fw = [-up[0], -up[1], -up[2]];
   var gcs = [1, 0, 0], dd = [-(gcs[0] - fw[0] * fw[0]), -(gcs[1] - fw[0] * fw[1]), -(gcs[2] - fw[0] * fw[2])];     // abajo = −(centro sin su parte a lo largo de la mirada)
   var B = fvGal3Basis(fw, dd), hf = (op.hfov || 54) * Math.PI / 180;
   return { pos: pos, fw: B.f, r: B.r, d: B.d, f: (W / 2) / Math.tan(hf / 2), cx: W / 2, cy: H / 2, tgt: tgt };
}
// base de camara con el mismo convenio que fvBasis (r = abajo × adelante, d = adelante × r)
function fvGal3Basis(fw, down) {
   var f = fvGal3Norm(fw), r = fvGal3Cross(down, f);
   if (Math.sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]) < 1e-9) r = fvGal3Cross([0, 0, 1], f);
   r = fvGal3Norm(r);
   return { f: f, r: r, d: fvGal3Norm(fvGal3Cross(f, r)) };
}
function fvGal3Norm(a) { var l = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]) || 1; return [a[0] / l, a[1] / l, a[2] / l]; }
function fvGal3Cross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
// proyectar un punto (Sol, kpc) con una camara -> [x, y, zc] o null
function fvGal3Project(cam, p) {
   var rx = p[0] - cam.pos[0], ry = p[1] - cam.pos[1], rz = p[2] - cam.pos[2], zc = rx * cam.fw[0] + ry * cam.fw[1] + rz * cam.fw[2];
   if (!(zc > 1e-6)) return null;
   return [cam.cx + cam.f * (rx * cam.r[0] + ry * cam.r[1] + rz * cam.r[2]) / zc, cam.cy + cam.f * (rx * cam.d[0] + ry * cam.d[1] + rz * cam.d[2]) / zc, zc];
}
// LA CAMARA DEL ZOOM en el instante s (0 = la de la nave, 1 = la final). c0, c1: camaras; look0: el punto que mira la nave (Sol, kpc)
function fvGal3CamAt(c0, c1, look0, s) {
   var dx = c1.pos[0] - c0.pos[0], dy = c1.pos[1] - c0.pos[1], dz = c1.pos[2] - c0.pos[2], D = Math.sqrt(dx * dx + dy * dy + dz * dz);
   var K = Math.log(1 + D / (c1.d0 || 0.02)), u = (Math.exp(K * s) - 1) / (Math.exp(K) - 1);   // la distancia crece en progresion geometrica (c1.d0: su escala inicial, kpc)
   var pos = [c0.pos[0] + dx * u, c0.pos[1] + dy * u, c0.pos[2] + dz * u];
   // la mirada gira cuando el campo ya es ancho (si no, la foto se sale del cuadro). (ronda 2) c1.lw0/lw1: cuando y cuanto tarda; un campo
   // lejos del plano (M 82, b = +40°) gira antes: mirando hacia arriba, fuera del disco, no hay nada que ver hasta que la mirada baja
   var w = fvGal3Smooth((s - (c1.lw0 !== undefined ? c1.lw0 : 0.32)) / (c1.lw1 !== undefined ? c1.lw1 : 0.55)),
       lp = look0;
   // (ronda 2, D-11) campo lejos del plano: primero la mirada BAJA hasta el plano galactico en el mismo azimut (c1.lookP, peso c1.lpW, en
   // s ∈ [c1.lpS0, c1.lpS0 + c1.lpS]: cuando el campo ya se ha abierto; antes, un grado de giro sacaba la foto del cuadro): la Via Lactea de dentro entra por abajo mientras la foto se encoge y sale por arriba; luego gira al centro como siempre
   if (c1.lookP && c1.lpW > 0) { var w0 = fvGal3Smooth((s - (c1.lpS0 || 0)) / (c1.lpS || 0.22)) * c1.lpW; lp = [look0[0] + (c1.lookP[0] - look0[0]) * w0, look0[1] + (c1.lookP[1] - look0[1]) * w0, look0[2] + (c1.lookP[2] - look0[2]) * w0]; }
   var tg = [lp[0] + (c1.tgt[0] - lp[0]) * w, lp[1] + (c1.tgt[1] - lp[1]) * w, lp[2] + (c1.tgt[2] - lp[2]) * w];
   var fw = [tg[0] - pos[0], tg[1] - pos[1], tg[2] - pos[2]];
   if (s <= 0) fw = c0.fw.slice();
   var dd = [c0.d[0] + (c1.d[0] - c0.d[0]) * w, c0.d[1] + (c1.d[1] - c0.d[1]) * w, c0.d[2] + (c1.d[2] - c0.d[2]) * w];
   var B = (s <= 0) ? { f: c0.fw, r: c0.r, d: c0.d } : fvGal3Basis(fw, dd);
   // (ronda 2) c1.wfS: lo que tarda en abrirse el campo (menos para un campo lejos del plano)
   var wf = fvGal3Smooth(s / (c1.wfS || 0.45)), t0 = c0.cx / c0.f, t1 = c1.cx / c1.f, tt = Math.exp(Math.log(t0) + (Math.log(t1) - Math.log(t0)) * wf);
   return { pos: pos, fw: B.f, r: B.r, d: B.d, f: c0.cx / tt, cx: c0.cx, cy: c0.cy, travelled: D * u, wf: wf };
}

// ============================================================================
// (ronda 2b, 9-nov) LA GALAXIA QUE SE GIRA EN 3D. Nino: «En el modo Galaxia, haz que aparezca la representacion real de la Via Lactea y
// que se pueda mover en 3D». Tres piezas, puras:
//   · fvGal3OrbitFrom / fvGal3OrbitCam: camara en orbita alrededor de un punto (az, el, dist); la de partida reproduce la vista final c1.
//   · fvGal3RenderVol: el disco con ESPESOR. Mientras la mirada cruza el plano con |dz| ≥ VOL.DZ1 (de cara y oblicua) el pixel es EL MISMO
//     que fvGal3Render (bit a bit: la vista final de hoy no cambia); por debajo de VOL.DZ0 (de canto) el rayo recorre la capa del disco
//     por pasos (perfil exponencial en altura, la luz del mapa de cara y su polvo, de delante a atras): de canto sale una banda con su
//     linea de polvo, no una raya. El bulbo y la barra ya eran volumen (gausianas). Particulas con altura (disco grueso y bulbo) que entran
//     al ponerse de canto.
//   · fvGal3TexFromPixels: el mapa de cara desde una IMAGEN de cara de la Via Lactea (la que elija Nino; aqui no se baja ninguna). Dos
//     puntos la ponen a escala: el pixel del centro galactico y el del Sol (R0 entre ellos). Sin imagen, el procedimental.
// Alturas de escala: disco fino 300 pc y grueso 900 pc (Bland-Hawthorn & Gerhard 2016, §5.1, comprobado el 9-nov-2026, ver fv_milkyway.js);
// la del polvo, 100 pc, ELECCION NUESTRA (NO VERIFICADO), constante con R: el disco de polvo se ENSANCHA hacia fuera (flare), h(R) = 134 pc +
// 14,8 pc/kpc·(R − 4,4 kpc) en el modelo de Drimmel & Spergel 2001 (ApJ 556, 181, tabla 1; segun la investigacion GR, encargo GG S4): no se aplica.
// ============================================================================
var FV_GAL3_VOL = { HZ: 0.30, HZY: 0.10, HZD: 0.10, ZK: 3, DZ0: 0.22, DZ1: 0.42, STEP: 0.15, NMAX: 48, DUST: 1.0, TAUF: 0.5, HRD: 5.0, KMIN: 0.20,
                    N_THICK: 6000, HZT: 0.90, N_BULGE: 5000, VW0: 0.35, VW1: 0.45 };
var FV_GAL3_DISC = null;          // el mapa de cara de una imagen (fvGal3TexFromPixels); null = el procedimental
// tablas del rayo por la capa: perfiles en altura normalizados (∫ dz = 1 en |z| < ZM, ×2 caras) para lo liso (HZ), la estructura (HZY:
// brazos, nudos y cumulos, mas finos: si no, cada nudo se estira en vertical al verse oblicuo) y el polvo (HZD); y e^(−x) en [0, 16]
function fvGal3VolTabs(Vx) {
   var V = Vx || FV_GAL3_VOL, key = V.HZ + "|" + V.HZY + "|" + V.HZD + "|" + V.ZK + (V.DSECH ? "|s" : "") + (V.THK > 0 ? "|t" + V.THK + "|" + V.HZT2 : "");      // (GF3) Vx: la capa del mapa (T.vol); sin el, la de siempre. (GF7) THK
   if (FV_GAL3.volTabs && FV_GAL3.volTabs.key === key) return FV_GAL3.volTabs;
   var ZM = V.ZK * V.HZ, n = 512, pz = new Float32Array(n), pzy = new Float32Array(n), pzd = new Float32Array(n), ex = new Float32Array(2048), i;
   function nrm(h) { return 0.5 / (h * (1 - Math.exp(-ZM / h))); }
   var a = nrm(V.HZ), ay = nrm(V.HZY), ad = nrm(V.HZD);
   for (i = 0; i < n; ++i) { var z = (i + 0.5) * ZM / n; pz[i] = a * Math.exp(-z / V.HZ); pzy[i] = ay * Math.exp(-z / V.HZY); pzd[i] = ad * Math.exp(-z / V.HZD); }
   if (V.DSECH) {   // (GF4) polvo en sech²(z/2h) (sin cuspide en z = 0: la raya fina y discontinua del centro del carril era esa cuspide), misma ∫ dz = 1/2 por cara
      var sS = 0; for (i = 0; i < n; ++i) { var zs = (i + 0.5) * ZM / n, ch = Math.cosh(zs / (2 * V.HZD)); pzd[i] = 1 / (ch * ch); sS += pzd[i] * ZM / n; }
      for (i = 0; i < n; ++i) pzd[i] *= 0.5 / sS;
   }
   if (V.THK > 0) {   // (GF7) (5) parte THK de la luz vieja en un disco GRUESO e^(−z/HZT2) (BHG16 §5.1.3: f_Σ = 12 % ± 4 %, z_T = 900 ± 100 pc), misma ∫ dz = 1/2 por cara
      var aT = nrm(V.HZT2); for (i = 0; i < n; ++i) { var zt = (i + 0.5) * ZM / n; pz[i] = (1 - V.THK) * pz[i] + V.THK * aT * Math.exp(-zt / V.HZT2); }
   }
   for (i = 0; i < 2048; ++i) ex[i] = Math.exp(-(i + 0.5) * 16 / 2048);
   FV_GAL3.volTabs = { key: key, pz: pz, pzy: pzy, pzd: pzd, zsc: n / ZM, ex: ex, nex: 2048, esc: 2048 / 16, tauStop: 12 };
   return FV_GAL3.volTabs;
}
// el polvo del rayo por la capa (profundidad optica de cara, por texel): el del mapa × DUST + un disco de polvo LISO de τ = TAUF junto al Sol
// y escala HRD (mas larga que la de las estrellas; ELECCION NUESTRA, NO VERIFICADO): sin el, de canto no salia linea de polvo (prueba O4)
function fvGal3VolDust(T, Vx) {
   var V = Vx || FV_GAL3_VOL, key = V.DUST + "|" + V.TAUF + "|" + V.HRD + (V.RC0 ? "|" + V.RC0 + "|" + V.RCW : ""), rc0 = V.RC0 || 14, rcw = V.RCW || 5;   // (GF3) RC0, RCW: donde acaba el disco de polvo liso
   if (T.vdust && T.vdustKey === key) return T.vdust;
   var N = T.N, out = new Float32Array(N * N), R0 = FV_GAL3.R0;
   for (var j = 0; j < N; ++j) for (var i = 0; i < N; ++i) {
      var X = -T.H + (i + 0.5) * T.px, Y = -T.H + (j + 0.5) * T.px, R = Math.sqrt(X * X + Y * Y), o = j * N + i;
      out[o] = T.dust[o] * V.DUST + V.TAUF * Math.exp(-(R - R0) / V.HRD) * (1 - fvGal3Smooth((R - rc0) / rcw)) * fvGal3Smooth(R / 1.5);
   }
   T.vdust = out; T.vdustKey = key;
   return out;
}
// el mapa de cara partido en LISO (media en una caja de ~1,5 kpc) y ESTRUCTURA (lo que sobra por encima); una vez por mapa
function fvGal3VolSplit(T) {
   if (T.split) return T.split;
   var N = T.N, n2 = N * N, rad = Math.max(1, Math.round(0.75 / T.px)), out = {};
   if (T.vol && T.vol.POP > 0) return fvGal3VolSplitPop(T, rad);   // (GF6) por poblaciones (solo con la capa de GF6)
   [["r", "sr", "yr"], ["g", "sg", "yg"], ["b", "sb", "yb"]].forEach(function(c) {
      var src = T[c[0]], tmp = new Float32Array(n2), sm = new Float32Array(n2), st = new Float32Array(n2), i, j, acc;
      for (j = 0; j < N; ++j) { acc = 0; var row = j * N;
         for (i = 0; i < Math.min(N, rad); ++i) acc += src[row + i];
         for (i = 0; i < N; ++i) { if (i + rad < N) acc += src[row + i + rad]; if (i - rad - 1 >= 0) acc -= src[row + i - rad - 1]; tmp[row + i] = acc / (2 * rad + 1); } }
      for (i = 0; i < N; ++i) { acc = 0;
         for (j = 0; j < Math.min(N, rad); ++j) acc += tmp[j * N + i];
         for (j = 0; j < N; ++j) { if (j + rad < N) acc += tmp[(j + rad) * N + i]; if (j - rad - 1 >= 0) acc -= tmp[(j - rad - 1) * N + i]; sm[j * N + i] = acc / (2 * rad + 1); } }
      for (i = 0; i < n2; ++i) { var m = Math.min(sm[i], src[i]); sm[i] = m; st[i] = src[i] - m; }
      out[c[1]] = sm; out[c[2]] = st;
   });
   T.split = out;
   return out;
}
// (GF6) (6) EL MAPA PARTIDO POR POBLACIONES: a la capa GRUESA (HZ) va solo la luz con el COLOR DE LA POBLACION VIEJA (COL_OLD): en cada texel, la mayor
// cantidad a·COL_OLD que cabe en (r, g, b) (a = POP·min(r/cO_r, g/cO_g, b/cO_b)), media en la misma caja de ~1,5 kpc y nunca mas de lo que hay; lo demas
// (la luz joven, azul, los nudos y la estructura) va a la FINA (HZY). Con el reparto de siempre, la parte lisa de TODA la luz (tambien la azul de los
// brazos) iba a la gruesa: de canto, la piel por encima del plano salia mas azul que el plano (revision de GF5). El disco grueso es viejo (BHG16 §5.1).
function fvGal3VolSplitPop(T, rad) {
   var N = T.N, n2 = N * N, cO = FV_GAL3.COL_OLD, pop = T.vol.POP, Rr = T.r, Rg = T.g, Rb = T.b, A = new Float32Array(n2), F = new Float32Array(n2), tmp = new Float32Array(n2), i, j, acc;
   for (i = 0; i < n2; ++i) { var f = Math.min(Rr[i] / cO[0], Rg[i] / cO[1], Rb[i] / cO[2]); if (!(f > 0)) f = 0; F[i] = f; A[i] = pop * f; }
   for (j = 0; j < N; ++j) { acc = 0; var row = j * N;
      for (i = 0; i < Math.min(N, rad); ++i) acc += A[row + i];
      for (i = 0; i < N; ++i) { if (i + rad < N) acc += A[row + i + rad]; if (i - rad - 1 >= 0) acc -= A[row + i - rad - 1]; tmp[row + i] = acc / (2 * rad + 1); } }
   var sm = new Float32Array(n2);
   for (i = 0; i < N; ++i) { acc = 0;
      for (j = 0; j < Math.min(N, rad); ++j) acc += tmp[j * N + i];
      for (j = 0; j < N; ++j) { if (j + rad < N) acc += tmp[(j + rad) * N + i]; if (j - rad - 1 >= 0) acc -= tmp[(j - rad - 1) * N + i]; sm[j * N + i] = acc / (2 * rad + 1); } }
   var out = { sr: new Float32Array(n2), sg: new Float32Array(n2), sb: new Float32Array(n2), yr: new Float32Array(n2), yg: new Float32Array(n2), yb: new Float32Array(n2) };
   for (i = 0; i < n2; ++i) { var a = Math.min(sm[i], F[i]);
      out.sr[i] = a * cO[0]; out.sg[i] = a * cO[1]; out.sb[i] = a * cO[2];
      out.yr[i] = Rr[i] - out.sr[i]; out.yg[i] = Rg[i] - out.sg[i]; out.yb[i] = Rb[i] - out.sb[i]; }
   T.split = out;
   return out;
}
// (GF8) la luz vieja de la capa gruesa (sr, sg, sb) en MEDIA AZIMUTAL (anillos de un texel): lo que queda de ella por encima del plano (FV_GAL_GF8.VOL.SAX).
// La barra, la fosa, los carriles de cara y los brazos viejos son del disco FINO y frio; el disco que sube (y el grueso de 900 pc) es liso. Una vez por mapa
function fvGf8VolAxi(T, SP) {
   if (SP.ax8) return SP.ax8;
   var N = T.N, n2 = N * N, px = T.px, H = T.H, nb = Math.ceil(H * 1.5 / px) + 2, s = [new Float64Array(nb), new Float64Array(nb), new Float64Array(nb)], c = new Float64Array(nb), bi = new Int32Array(n2), i, j, o;
   for (j = 0; j < N; ++j) for (i = 0; i < N; ++i) { var X = -H + (i + 0.5) * px, Y = -H + (j + 0.5) * px, k = Math.floor(Math.sqrt(X * X + Y * Y) / px); o = j * N + i; bi[o] = k; s[0][k] += SP.sr[o]; s[1][k] += SP.sg[o]; s[2][k] += SP.sb[o]; c[k] += 1; }
   var out = { r: new Float32Array(n2), g: new Float32Array(n2), b: new Float32Array(n2) };
   for (o = 0; o < n2; ++o) { var kk = bi[o], cc = c[kk] > 0 ? 1 / c[kk] : 0; out.r[o] = s[0][kk] * cc; out.g[o] = s[1][kk] * cc; out.b[o] = s[2][kk] * cc; }
   SP.ax8 = out;
   return out;
}
// (GF9) por texel, una vez por mapa (ver FV_GAL_GF9.VOL en fv_galgeom.js):
//   fy = 1/fY(R): el ENSANCHAMIENTO de la capa JOVEN exterior, fY = 1 + YFK·(e^((R − YF0)/YFS) − 1) para R > YF0 (1 dentro)
//   fl = 1/fD(R): el del POLVO de canto, fD = e^((R − YF0)/DFS) para R > YF0, por los GRUMOS de altura e^(CLH·n')
//   cm = los GRUMOS de la columna de polvo, e^(CLA·n), media 1 (no cambian la columna total); n, n' ruido de valor de dos octavas (CLS y CLS/2,5 kpc) en [−1, 1]
//   wb = el peso (1 dentro de RB0, rampa RBW) con el que la luz vieja CONSERVA su estructura por encima del plano (el bulbo en caja es la barra interior, gruesa)
//   YFX > 0: TOPE del ensanchamiento de la capa joven (fY <= YFX). Sin tope, a R 15 la capa joven es ×4,6 (el HI, ×2,1: Kalberla 2007) y el final de un
//        brazo joven en el borde del disco sale de canto como una columna azul de borde vertical (canto x1, x ~247 px)
function fvGf9Tabs(T, V) {
   var key = [V.YF0, V.YFK, V.YFS, V.DFS, V.RB0, V.RBW, V.CLS, V.CLA, V.CLH, V.YFX].join("|"); if (T.gf9t && T.gf9t.key === key) return T.gf9t;
   var N = T.N, n2 = N * N, cl = V.CLS > 0, cm = (cl && V.CLA > 0) ? new Float32Array(n2) : null, cmS = 0, R0 = V.YF0 || FV_GAL3.R0, iC = cl ? 1 / V.CLS : 0;
   var fl = (V.DFS > 0 || (cl && V.CLH > 0)) ? new Float32Array(n2) : null, wb = (V.RB0 > 0) ? new Float32Array(n2) : null, fy = (V.YFK > 0 && V.YFS > 0) ? new Float32Array(n2) : null;
   for (var j = 0; j < N; ++j) for (var i = 0; i < N; ++i) {
      var X = -T.H + (i + 0.5) * T.px, Y = -T.H + (j + 0.5) * T.px, R = Math.sqrt(X * X + Y * Y), o = j * N + i, n1 = 0, n2c = 0;
      if (cl) { n1 = 2 * (0.65 * fvGal3N2(X * iC, Y * iC, 21) + 0.35 * fvGal3N2(X * iC * 2.5, Y * iC * 2.5, 22)) - 1; n2c = 2 * (0.65 * fvGal3N2(X * iC, Y * iC, 23) + 0.35 * fvGal3N2(X * iC * 2.5, Y * iC * 2.5, 24)) - 1; }
      if (cm) { cm[o] = Math.exp(V.CLA * 2 * n1); cmS += cm[o]; }
      if (fl) { var f = (V.DFS > 0 && R > R0) ? Math.exp((R - R0) / V.DFS) : 1; if (cl && V.CLH > 0) f *= Math.exp(V.CLH * 2 * n2c); fl[o] = 1 / f; }
      if (wb) wb[o] = 1 - fvGal3Smooth((R - V.RB0) / Math.max(1e-3, V.RBW));
      if (fy) { var fY9 = 1 + (R > R0 ? V.YFK * (Math.exp((R - R0) / V.YFS) - 1) : 0); if (V.YFX > 0 && fY9 > V.YFX) fY9 = V.YFX; fy[o] = 1 / fY9; }
   }
   if (cm) { var kn = n2 / cmS; for (var q9 = 0; q9 < n2; ++q9) cm[q9] *= kn; }
   T.gf9t = { key: key, fl: fl, wb: wb, fy: fy, cm: cm };
   return T.gf9t;
}
// (GF8) e^(−|z|/SAX) en la rejilla de alturas de las tablas del rayo (zi = |z|·zsc)
function fvGf8SaxTab(sax, zsc) {
   var key = sax + "|" + zsc; if (FV_GAL3.sax8 && FV_GAL3.sax8.key === key) return FV_GAL3.sax8.t;
   var t = new Float32Array(512); for (var i = 0; i < 512; ++i) t[i] = Math.exp(-((i + 0.5) / zsc) / sax);
   FV_GAL3.sax8 = { key: key, t: t }; return t;
}

// la orbita que reproduce la camara c (con tgt): az, el (°) de la camara vista desde el punto, dist, y el giro que deja su «abajo»
function fvGal3OrbitFrom(c) {
   var t = c.tgt, v = [c.pos[0] - t[0], c.pos[1] - t[1], c.pos[2] - t[2]], dist = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
   var o = { tgt: t.slice(), dist: dist, el: Math.asin(Math.max(-1, Math.min(1, v[2] / dist))) * 180 / Math.PI, az: Math.atan2(v[1], v[0]) * 180 / Math.PI,
             f: c.f, cx: c.cx, cy: c.cy, roll: 0 };
   var c0 = fvGal3OrbitCam(o), fw = c0.fw, d0 = c0.d, d1 = c.d;
   var cr = fvGal3Cross(d0, d1);
   o.roll = Math.atan2(cr[0] * fw[0] + cr[1] * fw[1] + cr[2] * fw[2], d0[0] * d1[0] + d0[1] * d1[1] + d0[2] * d1[2]) * 180 / Math.PI;
   return o;
}
// la camara de la orbita o = { tgt, az, el, dist, f, cx, cy, roll }: «arriba» en pantalla = hacia donde sube la elevacion (sin polo: vale
// tambien de cara, el = ±90°, y por debajo del plano)
function fvGal3OrbitCam(o) {
   var D2R = Math.PI / 180, el = o.el * D2R, az = o.az * D2R, ce = Math.cos(el), se = Math.sin(el), ca = Math.cos(az), sa = Math.sin(az);
   var u = [ce * ca, ce * sa, se], up = [-se * ca, -se * sa, ce], pos = [o.tgt[0] + o.dist * u[0], o.tgt[1] + o.dist * u[1], o.tgt[2] + o.dist * u[2]];
   var B = fvGal3Basis([-u[0], -u[1], -u[2]], [-up[0], -up[1], -up[2]]), r = B.r, d = B.d;
   if (o.roll) {
      var q = o.roll * D2R, cq = Math.cos(q), sq = Math.sin(q);
      var r2 = [r[0] * cq + d[0] * sq, r[1] * cq + d[1] * sq, r[2] * cq + d[2] * sq], d2 = [d[0] * cq - r[0] * sq, d[1] * cq - r[1] * sq, d[2] * cq - r[2] * sq];
      r = r2; d = d2;
   }
   return { pos: pos, fw: B.f, r: r, d: d, f: o.f, cx: o.cx, cy: o.cy, tgt: o.tgt };
}
// el peso de las particulas con altura: 0 mirando de cara (|fw_z| > VW0 + VW1), 1 de canto
function fvGal3VolW(cam) { var V = FV_GAL3_VOL; return 1 - fvGal3Smooth((Math.abs(cam.fw[2]) - V.VW0) / V.VW1); }
// particulas con altura: disco grueso (h_R 2,6 kpc del viejo, h_z 900 pc) y bulbo (la caja de BULGE[0]); semilla fija
function fvGal3VolStars() {
   if (FV_GAL3.volStars) return FV_GAL3.volStars;
   var V = FV_GAL3_VOL, G = FV_GAL3, rng = fvRng(G.SEED + 13), n = V.N_THICK + V.N_BULGE, P = new Float32Array(3 * n), C = new Float32Array(3 * n), B = G.BULGE[0], i;
   function gauss() { var u = Math.max(1e-9, rng()), v = rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
   for (i = 0; i < n; ++i) {
      var X, Y, Z, c;
      if (i < V.N_THICK) {
         var R = -G.HR_OLD * Math.log(Math.max(1e-9, rng() * rng())), ph = 2 * Math.PI * rng(); if (R > 16) R = 16 * rng();   // gamma(2): R·e^(−R/h)
         X = R * Math.cos(ph); Y = R * Math.sin(ph); Z = -V.HZT * Math.log(Math.max(1e-9, rng())) * (rng() < 0.5 ? -1 : 1); c = G.COL_OLD;
      } else {
         var a = B.ang * Math.PI / 180, uu = gauss() * B.sx, vv = gauss() * B.sy;
         X = -Math.cos(a) * uu + Math.sin(a) * vv; Y = Math.sin(a) * uu + Math.cos(a) * vv; Z = gauss() * B.sz; c = G.COL_BULGE;
      }
      var aa = 0.20 + 0.8 * Math.pow(rng(), 3);
      P[3 * i] = X; P[3 * i + 1] = Y; P[3 * i + 2] = Z; C[3 * i] = c[0] * aa; C[3 * i + 1] = c[1] * aa; C[3 * i + 2] = c[2] * aa;
   }
   FV_GAL3.volStars = { n: n, p: P, c: C };
   return FV_GAL3.volStars;
}
// puntos (galactocentricos X, Y, Z) al bufer, con reparto bilineal (la misma cuenta que las estrellas de fvGal3Render)
function fvGal3Splat(cam, W, H, buf, St, k) {
   var G = FV_GAL3, R0 = G.R0, fw = cam.fw, r = cam.r, d = cam.d, f = cam.f, cx = cam.cx, cy = cam.cy, P = St.p, C = St.c;
   for (var m = 0; m < St.n; ++m) {
      var rx = P[3 * m] + R0 - cam.pos[0], ry = P[3 * m + 1] - cam.pos[1], rz = P[3 * m + 2] - G.ZSUN - cam.pos[2];
      var zc = rx * fw[0] + ry * fw[1] + rz * fw[2]; if (zc < 0.05) continue;
      var X2 = cx + f * (rx * r[0] + ry * r[1] + rz * r[2]) / zc - 0.5, Y2 = cy + f * (rx * d[0] + ry * d[1] + rz * d[2]) / zc - 0.5;
      var ix = Math.floor(X2), iy = Math.floor(Y2); if (ix < 0 || iy < 0 || ix >= W - 1 || iy >= H - 1) continue;
      var a3 = 0.06 * k * Math.min(6, (30 * 30) / (zc * zc)), fx = X2 - ix, fy = Y2 - iy, oo = 3 * (iy * W + ix), ws = [(1 - fx) * (1 - fy), fx * (1 - fy), (1 - fx) * fy, fx * fy], offs = [0, 3, 3 * W, 3 * W + 3];
      for (var w4 = 0; w4 < 4; ++w4) { var ow = oo + offs[w4], ww4 = ws[w4] * a3; buf[ow] += C[3 * m] * ww4; buf[ow + 1] += C[3 * m + 1] * ww4; buf[ow + 2] += C[3 * m + 2] * ww4; }
   }
}
// LA VISTA CON VOLUMEN. opt: { T (mapa de cara; si no, FV_GAL3_DISC o el procedimental), nmax (pasos como mucho por rayo) }
function fvGal3RenderVol(cam, W, H, buf, gain, y0, y1, opt) {
   var G = FV_GAL3, V = FV_GAL3_VOL, op = opt || {}, T = op.T || FV_GAL3_DISC || FV_GAL3_MIX || fvGal3Tex(), R0 = G.R0, gn = (gain === undefined) ? 1 : gain, ya = (y0 === undefined) ? 0 : y0, yb = (y1 === undefined) ? H : y1;
   // (GF11) con la bandera: el mapa de fondo (en movimiento, op.move, el de movimiento) y lo que cada pixel deja a las estrellas. Apagada: nada
   // De canto (el rayo por la capa, peso wM) la luz es la de GF9 entera y LISA (el mapa original, Tv): las estrellas solo llevan la parte del plano (1 − wM).
   // Con estrellas tambien de canto salian motas en el carril y una nube de chispas sobre el disco (E14 44/54, E15, E19: medido en GF11-galaxia-estrellas.md)
   var g11 = (typeof fvGf11Get === "function") ? fvGf11Get(T) : null, mv11 = !!op.move, P11 = null, PA = null, PB = null, PT = null, PF = null, Tv = T;
   if (g11) { T = mv11 ? g11.bgMove : g11.bg; P11 = fvGf11Pix(buf, W, H); PA = P11.A; PB = P11.B; PT = P11.T; PF = P11.F; }
   if (T.vol) V = T.vol;                       // (GF3) la capa de canto del mapa; sin T.vol, la de siempre
   var Ox = cam.pos[0] - R0, Oy = cam.pos[1], Oz = cam.pos[2] + G.ZSUN, slab = (G.SLAB0 + (1 - G.SLAB0) * fvGal3Smooth((Math.abs(Oz) - 0.02) / 0.5)) * (0.45 + 0.55 * fvGal3Smooth(Math.abs(Oz) / 4));
   var fw = cam.fw, r = cam.r, d = cam.d, f = cam.f, cx = cam.cx, cy = cam.cy, cB = G.COL_BULGE, kd = G.DUST_RGB, i;
   if (V.KG > 0 && V.KG !== 1) kd = [1 + V.KG * (kd[0] - 1), 1 + V.KG * (kd[1] - 1), 1 + V.KG * (kd[2] - 1)];   // (GF7) (5) KG: polvo mas gris en la capa de canto (ver FV_GAL_GF7.VOL); sin KG: el de siempre
   for (i = 3 * ya * W; i < 3 * yb * W; ++i) buf[i] = 0;
   if (gn <= 0) return;
   var sg = (FV_GAL3_BREAK === "beta" ? -1 : 1), Bc = T.bulge || G.BULGE, nb = Bc.length, S = [], bK = (T.bulgeK === undefined ? 1 : T.bulgeK);   // (GF2) T.bulge
   for (var q = 0; q < nb; ++q) {
      var ang = (Bc[q].ang !== undefined ? Bc[q].ang : G.BAR_ANG) * Math.PI / 180 * sg, ux = -Math.cos(ang), uy = Math.sin(ang), vx = Math.sin(ang), vy = Math.cos(ang);
      S.push([1 / (Bc[q].sx * Bc[q].sx), 1 / (Bc[q].sy * Bc[q].sy), 1 / (Bc[q].sz * Bc[q].sz), Bc[q].a * bK, ux, uy, vx, vy, Ox * ux + Oy * uy - (Bc[q].u0 || 0), Ox * vx + Oy * vy - (Bc[q].v0 || 0), Oz - (Bc[q].z0 || 0)]);   // u0: desplazamiento (GF2; 0 = hoy); (GF5) v0, z0
   }
   var Rr = T.r, Rg = T.g, Rb = T.b, Du = T.dust, N = T.N, TH = T.H, tpx = T.px, DT = FV_GAL3_DETAIL, dOn = DT.ON && !T.image, fT = f * tpx, iS1 = 1 / DT.S1, iS2 = 1 / DT.S2, iDP = 1 / (DT.PX1 - DT.PX0);
   var WZ = T.warp || null, WT = WZ ? { N: T.N, H: T.H, px: T.px } : null;   // (encargo GP) el alabeo del mapa de datos
   var ZM = V.ZK * V.HZ, ZMb = WZ ? ZM + T.warpMax : ZM, nE = 1, nD = V.DUST, nmax = op.nmax || V.NMAX, iDZ = 1 / (V.DZ1 - V.DZ0), TH2 = TH * TH * 0.98, ihp = 1 / tpx;
   var vDZ0 = V.DZ0, vDZ1 = V.DZ1, vKMIN = V.KMIN, vSTEP = V.STEP;          // (GF3) en locales: V puede ser FV_GAL3_VOL o T.vol (dos formas de objeto en el bucle caliente)
   var vKB = V.KB || 0, vK0 = FV_GAL3_VOL.KMIN;   // (GF3) KB: el bulbo sube de canto como el disco (KMIN frente al de siempre); 0 o sin KB: nada (lo de siempre)
   var LT = fvGal3VolTabs(T.vol), PZ = LT.pz, PZY = LT.pzy, PZD = LT.pzd, zsc = LT.zsc, EXT = LT.ex, NEX = LT.nex, esc = LT.esc, tauStop = LT.tauStop / Math.min(kd[0], kd[1], kd[2]);
   var SP = fvGal3VolSplit(Tv), Sr = SP.sr, Sg = SP.sg, Sb = SP.sb, Yr = SP.yr, Yg = SP.yg, Yb = SP.yb, DD = fvGal3VolDust(Tv, Tv.vol);   // (GF11) Tv: sin GF11, T
   // (GF8) ver FV_GAL_GF8.VOL: KGY, el color del polvo para la capa JOVEN (la que esta dentro del polvo); SAX, la altura (kpc) a la que se apaga la parte NO
   // axisimetrica de la luz vieja (barra, fosa, carriles de cara, brazos viejos): por encima del plano solo queda su media en azimut. Sin GF8: nada (g8 false)
   var g8 = !!(V.GF8), kY = kd, AXr = null, AXg = null, AXb = null, SAXT = null;
   if (g8) {
      if (V.KGY !== undefined && V.KGY >= 0) { var k8 = G.DUST_RGB, ty8 = V.TY > 0 ? V.TY : 1; kY = [ty8 * (1 + V.KGY * (k8[0] - 1)), ty8 * (1 + V.KGY * (k8[1] - 1)), ty8 * (1 + V.KGY * (k8[2] - 1))]; tauStop = LT.tauStop / Math.min(kd[0], kd[1], kd[2], kY[0], kY[1], kY[2]); }   // TY: la capa joven ve TY veces la columna de polvo
      if (V.SAX > 0) { var AX8 = fvGf8VolAxi(Tv, SP); AXr = AX8.r; AXg = AX8.g; AXb = AX8.b; SAXT = fvGf8SaxTab(V.SAX, zsc); }
   }
   // (GF9) ver FV_GAL_GF9.VOL y fvGf9Tabs: la capa joven exterior y el polvo ensanchados, los grumos del polvo y la luz vieja del bulbo en caja con altura.
   // Sin GF9: null (la linea de siempre)
   var FL9 = null, WB9 = null, FY9 = null, CM9 = null;
   if (g8 && V.GF9) { var T9 = fvGf9Tabs(Tv, V); FL9 = T9.fl; FY9 = T9.fy; CM9 = T9.cm; if (SAXT) WB9 = T9.wb; }
   for (var y = ya; y < yb; ++y) {
      var py = (y + 0.5 - cy) / f;
      for (var x = 0; x < W; ++x) {
         var px = (x + 0.5 - cx) / f;
         var dx = fw[0] + px * r[0] + py * d[0], dy = fw[1] + px * r[1] + py * d[1], dz = fw[2] + px * r[2] + py * d[2], nn = 1 / Math.sqrt(dx * dx + dy * dy + dz * dz);
         dx *= nn; dy *= nn; dz *= nn;
         var adz = dz < 0 ? -dz : dz, wM = 1 - (adz - vDZ0) * iDZ;
         if (wM < 0) wM = 0; else if (wM > 1) wM = 1; else wM = wM * wM * (3 - 2 * wM);
         var er = 0, eg = 0, eb = 0, tau = 0, u, v, i0, j0, fu, fv, o, w00, w10, w01, w11, kA = 0;
         // 1) el disco como plano (lo de fvGal3Render, igual cifra a cifra), con peso 1 − wM
         if (wM < 1 && dz * Oz < 0 && slab > 0) {
            var t = -Oz / dz, X = Ox + t * dx, Yp = Oy + t * dy;
            if (WZ && X * X + Yp * Yp > T.warpR0) { for (var itw = 0; itw < 2; ++itw) { t = (fvGal3TexAt(WT, WZ, X, Yp) - Oz) / dz; X = Ox + t * dx; Yp = Oy + t * dy; } if (!(t > 0)) X = 1e9; }
            u = (X + TH) / tpx - 0.5; v = (Yp + TH) / tpx - 0.5; i0 = Math.floor(u); j0 = Math.floor(v);
            if (i0 >= 0 && j0 >= 0 && i0 < N - 1 && j0 < N - 1) {
               fu = u - i0; fv = v - j0; o = j0 * N + i0; w00 = (1 - fu) * (1 - fv); w10 = fu * (1 - fv); w01 = (1 - fu) * fv; w11 = fu * fv;
               var k = Math.min(1 / Math.abs(dz), G.KMAX) * slab;
               if (PA) kA = (1 - wM) * Math.min(1, G.KMAX * Math.abs(dz)) * slab;   // (GF11)
               if (dOn) {
                  var mg = (fT / t - DT.PX0) * iDP;
                  if (mg > 0) { if (mg > 1) mg = 1; mg = mg * mg * (3 - 2 * mg); k *= 1 + mg * DT.AMP * (0.62 * fvGal3N2(X * iS1, Yp * iS1, 5) + 0.38 * fvGal3N2(X * iS2, Yp * iS2, 9) - 0.5) * 2; if (k < 0) k = 0; }
               }
               er = k * (Rr[o] * w00 + Rr[o + 1] * w10 + Rr[o + N] * w01 + Rr[o + N + 1] * w11);
               eg = k * (Rg[o] * w00 + Rg[o + 1] * w10 + Rg[o + N] * w01 + Rg[o + N + 1] * w11);
               eb = k * (Rb[o] * w00 + Rb[o + 1] * w10 + Rb[o + N] * w01 + Rb[o + N + 1] * w11);
               tau = Du[o] * w00 + Du[o + 1] * w10 + Du[o + N] * w01 + Du[o + N + 1] * w11;
            }
         }
         var trB = (tau > 0) ? 0.5 + 0.5 * Math.exp(-tau) : 1;
         // 2) de canto: el rayo por la capa |Z| < ZM y R < TH, a pasos, de delante a atras
         if (wM > 0) {
            var ta = 0, tb = 1e9;
            if (adz > 1e-9) { var t1 = (-ZMb - Oz) / dz, t2 = (ZMb - Oz) / dz; ta = Math.min(t1, t2); tb = Math.max(t1, t2); }
            else if (Oz > ZMb || Oz < -ZMb) tb = -1;
            var ax2 = dx * dx + dy * dy, bx2 = Ox * dx + Oy * dy, cx2 = Ox * Ox + Oy * Oy - TH2, di = bx2 * bx2 - ax2 * cx2;
            if (ax2 > 1e-12 && di > 0) { var sd = Math.sqrt(di), c1 = (-bx2 - sd) / ax2, c2 = (-bx2 + sd) / ax2; if (c1 > ta) ta = c1; if (c2 < tb) tb = c2; }
            else if (cx2 > 0) tb = -1;
            if (ta < 0) ta = 0;
            var mr = 0, mgr = 0, mb = 0, tauM = 0;
            if (tb > ta) {
               var L = tb - ta, ns = Math.ceil(L / vSTEP); if (ns < 2) ns = 2; if (ns > nmax) ns = nmax;
               var dt = L / ns, jit = fvGal3H(x, y, 0, 77), dE = dt * nE, dD = dt * nD;
               for (var s = 0; s < ns; ++s) {
                  var ts = ta + (s + jit) * dt, Zs = Oz + ts * dz, ii = ((Ox + ts * dx + TH) * ihp) | 0, jj = ((Oy + ts * dy + TH) * ihp) | 0;
                  if (ii < 0 || jj < 0 || ii >= N || jj >= N) continue;
                  if (WZ) { Zs -= WZ[jj * N + ii]; if (Zs > ZM || Zs < -ZM) continue; }   // fuera de la capa alabeada: nada
                  var zi = ((Zs < 0 ? -Zs : Zs) * zsc) | 0; if (zi > 511) zi = 511;
                  o = jj * N + ii;
                  var pS = PZ[zi] * dE, pY = PZY[zi] * dE, dd2 = DD[o] * PZD[zi] * dt;
                  if (FL9) { var fi9 = FL9[o], zd9 = ((Zs < 0 ? -Zs : Zs) * zsc * fi9) | 0; if (zd9 > 511) zd9 = 511; dd2 = DD[o] * PZD[zd9] * fi9 * dt; }   // (GF9) el polvo ensanchado: p(z/f)/f
                  if (FY9) { var fy9 = FY9[o], zy9 = ((Zs < 0 ? -Zs : Zs) * zsc * fy9) | 0; if (zy9 > 511) zy9 = 511; pY = PZY[zy9] * fy9 * dE; }       // (GF9) la capa joven exterior ensanchada
                  if (CM9) dd2 *= CM9[o];                                                                                                            // (GF9) los grumos del polvo
                  var h = (tauM + 0.5 * dd2) * esc;
                  var aR = 0, aG2 = 0, aB = 0, ix = (h * kd[0]) | 0; if (ix < NEX) aR = EXT[ix]; ix = (h * kd[1]) | 0; if (ix < NEX) aG2 = EXT[ix]; ix = (h * kd[2]) | 0; if (ix < NEX) aB = EXT[ix];
                  if (g8) {                                // (GF8) capa joven con su polvo (kY) y luz vieja sin estructura por encima del plano (SAX)
                     var yR = aR, yG = aG2, yB = aB; if (kY !== kd) { yR = 0; yG = 0; yB = 0; ix = (h * kY[0]) | 0; if (ix < NEX) yR = EXT[ix]; ix = (h * kY[1]) | 0; if (ix < NEX) yG = EXT[ix]; ix = (h * kY[2]) | 0; if (ix < NEX) yB = EXT[ix]; }
                     var s8r = Sr[o], s8g = Sg[o], s8b = Sb[o]; if (SAXT) { var gz8 = SAXT[zi]; if (WB9) gz8 = WB9[o] + (1 - WB9[o]) * gz8; s8r = AXr[o] + (s8r - AXr[o]) * gz8; s8g = AXg[o] + (s8g - AXg[o]) * gz8; s8b = AXb[o] + (s8b - AXb[o]) * gz8; }
                     mr += aR * s8r * pS + yR * Yr[o] * pY; mgr += aG2 * s8g * pS + yG * Yg[o] * pY; mb += aB * s8b * pS + yB * Yb[o] * pY;
                  } else {
                  mr += aR * (Sr[o] * pS + Yr[o] * pY); mgr += aG2 * (Sg[o] * pS + Yg[o] * pY); mb += aB * (Sb[o] * pS + Yb[o] * pY);
                  }
                  tauM += dd2;
                  if (tauM > tauStop) break;               // opaco: lo de detras ya no llega
               }
            }
            // de canto, el brillo sube menos que 1/|dz| (si no, la banda se quema): continuo con el plano en DZ1, y ×KMIN/DZ1 de canto del todo
            var km = wM * Math.min(1, Math.max(adz, vKMIN) / vDZ1), kp = 1 - wM;
            er = er * kp + mr * km; eg = eg * kp + mgr * km; eb = eb * kp + mb * km;
            // el bulbo: la mitad de delante tras la cuarta parte del polvo, la de atras tras tres cuartas partes
            trB = trB * kp + (0.5 * Math.exp(-0.25 * tauM) + 0.5 * Math.exp(-0.75 * tauM)) * wM;
         }
         var bul = 0;
         for (q = 0; q < nb; ++q) {
            var sq = S[q], du = dx * sq[4] + dy * sq[5], dv = dx * sq[6] + dy * sq[7], Ou = sq[8], Ov = sq[9], Oq = sq[10];
            var a2 = du * du * sq[0] + dv * dv * sq[1] + dz * dz * sq[2], b2 = Ou * du * sq[0] + Ov * dv * sq[1] + Oq * dz * sq[2], c2 = Ou * Ou * sq[0] + Ov * Ov * sq[1] + Oq * Oq * sq[2];
            var ex = 0.5 * (c2 - b2 * b2 / a2);
            if (ex < 30 && b2 < 0) bul += sq[3] * Math.sqrt(2 * Math.PI / a2) * Math.exp(-ex);
         }
         if (bul > 0) { bul *= trB; if (vKB > 0 && wM > 0) bul *= 1 + vKB * wM * (Math.max(adz, vKMIN) / Math.max(adz, vK0) - 1); er += bul * cB[0]; eg += bul * cB[1]; eb += bul * cB[2]; }
         var oi = 3 * (y * W + x); buf[oi] = er * gn; buf[oi + 1] = eg * gn; buf[oi + 2] = eb * gn;
         if (PA) { var p11 = y * W + x; PA[p11] = kA; PB[p11] = 0; PT[p11] = 0; PF[p11] = trB * ((vKB > 0 && wM > 0) ? 1 + vKB * wM * (Math.max(adz, vKMIN) / Math.max(adz, vK0) - 1) : 1); }   // (GF11)
      }
   }
   if (yb < H) return;
   if (T.pts && typeof fvGalDataSplatPts === "function") fvGalDataSplatPts(cam, W, H, buf, T.pts, gn);   // (encargo GP) los puntos medidos
   if (g11) { fvGf11Splat(cam, W, H, buf, g11, gn, P11, mv11, V); return; }   // (GF11) las estrellas (sustituyen al grano y a las particulas con altura)
   if (T.noStars) return;
   fvGal3Splat(cam, W, H, buf, fvGal3StarsOf(T), gn);
   var vw = fvGal3VolW(cam);
   if (vw > 0.001) fvGal3Splat(cam, W, H, buf, fvGal3VolStars(), gn * vw);
}
// EL MAPA DE CARA DESDE UNA IMAGEN: px (Uint32 0xAARRGGBB, w × h). o = { gc: [x, y] pixel del centro galactico, sun: [x, y] pixel del Sol,
// south: true si la imagen esta vista desde el polo SUR (por defecto, desde el norte: con el centro arriba, l = 90° queda a la IZQUIERDA),
// gain: brillo (si no, el que iguala la luz media del procedimental entre 3 y 12 kpc), dust: cuanto polvo se deduce de lo oscuro,
// bulgeK: cuanto bulbo procedimental se suma (la imagen ya trae el suyo de cara) }
// -> el mismo formato que fvGal3Tex() (r, g, b lineales; dust; arm), con T.image = true
function fvGal3TexFromPixels(px, w, h, o) {
   var G = FV_GAL3, N = G.TEX_N, H = G.TEX_H, tp = 2 * H / N, n2 = N * N, gc = o.gc, sn = o.sun;
   var ex = sn[0] - gc[0], ey = sn[1] - gc[1], Ls = Math.sqrt(ex * ex + ey * ey), k = Ls / G.R0;
   ex /= Ls; ey /= Ls;
   // el eje Y (hacia l = 90°) en la imagen. Desde el norte, con el centro arriba (e = hacia el Sol = abajo) l = 90° queda a la izquierda:
   // e = (0, 1) -> Y = (−1, 0), es decir Y = (−ey, ex)... con signo: (yx, yy) = (−ey, ex)·sY
   var sY = o.south ? -1 : 1, yx = -ey * sY, yy = ex * sY;
   var LIN = new Float32Array(256);
   for (var q = 0; q < 256; ++q) { var c = q / 255; LIN[q] = c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
   var R_ = new Float32Array(n2), G_ = new Float32Array(n2), B_ = new Float32Array(n2), Du = new Float32Array(n2), Ar = new Float32Array(n2), Lm = new Float32Array(n2);
   function samp(xi, yi, sh) {
      var X0 = Math.floor(xi), Y0 = Math.floor(yi); if (X0 < 0 || Y0 < 0 || X0 >= w - 1 || Y0 >= h - 1) return 0;
      var fx = xi - X0, fy = yi - Y0, b = Y0 * w + X0;
      return (LIN[(px[b] >>> sh) & 255] * (1 - fx) + LIN[(px[b + 1] >>> sh) & 255] * fx) * (1 - fy) + (LIN[(px[b + w] >>> sh) & 255] * (1 - fx) + LIN[(px[b + w + 1] >>> sh) & 255] * fx) * fy;
   }
   var i, j;
   for (j = 0; j < N; ++j) {
      var Y = -H + (j + 0.5) * tp;
      for (i = 0; i < N; ++i) {
         var X = -H + (i + 0.5) * tp, oo = j * N + i;
         // galactocentrico (X, Y) -> imagen: el Sol esta en X = −R0, es decir, a R0 a lo largo de +e desde el centro
         var xi = gc[0] + k * (-X * ex + Y * yx), yi = gc[1] + k * (-X * ey + Y * yy);
         R_[oo] = samp(xi, yi, 16); G_[oo] = samp(xi, yi, 8); B_[oo] = samp(xi, yi, 0); Lm[oo] = 0.2126 * R_[oo] + 0.7152 * G_[oo] + 0.0722 * B_[oo];
      }
   }
   // el brillo: el que da la misma luz media que el procedimental en el anillo de 3 a 12 kpc (si no se da gain)
   var gain = o.gain;
   if (!(gain > 0)) {
      var Tp = fvGal3Tex(), sP = 0, sI = 0;
      for (j = 0; j < N; ++j) for (i = 0; i < N; ++i) {
         var X1 = -H + (i + 0.5) * tp, Y1 = -H + (j + 0.5) * tp, R1 = Math.sqrt(X1 * X1 + Y1 * Y1); if (R1 < 3 || R1 > 12) continue;
         var o1 = j * N + i; sP += 0.2126 * Tp.r[o1] + 0.7152 * Tp.g[o1] + 0.0722 * Tp.b[o1]; sI += Lm[o1];
      }
      gain = sI > 0 ? sP / sI : 1;
   }
   // el polvo: lo que es mas oscuro que su entorno (caja de ~1 kpc); lo azul, «jovenes» (para las estrellas sueltas)
   var rad = Math.max(1, Math.round(0.5 / tp)), tmp = new Float32Array(n2), bl = new Float32Array(n2), dk = (o.dust === undefined) ? 2.0 : o.dust;
   for (j = 0; j < N; ++j) for (i = 0; i < N; ++i) { var a0 = 0, n0 = 0; for (var e = -rad; e <= rad; ++e) { var ii = i + e; if (ii >= 0 && ii < N) { a0 += Lm[j * N + ii]; ++n0; } } tmp[j * N + i] = a0 / n0; }
   for (j = 0; j < N; ++j) for (i = 0; i < N; ++i) { var a1 = 0, n1 = 0; for (var e2 = -rad; e2 <= rad; ++e2) { var jj = j + e2; if (jj >= 0 && jj < N) { a1 += tmp[jj * N + i]; ++n1; } } bl[j * N + i] = a1 / n1; }
   for (i = 0; i < n2; ++i) {
      R_[i] *= gain; G_[i] *= gain; B_[i] *= gain;
      Du[i] = bl[i] > 1e-6 ? dk * Math.max(0, 1 - Lm[i] / bl[i]) : 0;
      Ar[i] = Math.max(0, B_[i] - R_[i]) * 4;
   }
   return { N: N, H: H, px: tp, r: R_, g: G_, b: B_, dust: Du, arm: Ar, armDust: Du, ms: 0, brk: FV_GAL3_BREAK, stars: null, image: true, gain: gain, bulgeK: (o.bulgeK === undefined ? 0.35 : o.bulgeK) };
}

// ============================================================================
// (GF11, 12-nov-2026) LA GALAXIA HECHA DE ESTRELLAS (bandera FV_GAL_GF11 en fv_galgeom.js; ver alli el porque y cada parametro).
//   fvGf11Get(T): el estado de GF11 para un mapa de GF9 (o null: bandera apagada, o el mapa no es de GF9). Se calcula una vez por mapa y parametros.
//   fvGf11Prep: las estrellas (X, Y, Z galactocentricos en kpc, flujo RGB, poblacion) y los dos mapas de fondo: bg (la luz no resuelta, parado) y bgMove
//     (la de los fotogramas en movimiento: bg + la luz media de las estrellas que en movimiento no se pintan).
//   fvGf11Pix: por pixel, lo que el rayo de la vista deja a las estrellas: A (peso del plano frente a la luz fisica), B (el del rayo por la capa, de canto),
//     T (la τ total del rayo por la capa) y F (la transmision del bulbo). Lo escriben fvGal3Render y fvGal3RenderVol solo con GF11 (apagado, nada).
//   fvGf11Splat: cada estrella, flujo L·f²/(zc² + ZNEAR²) × (A + B·r·e^(−k·T·φ)) con un perfil gausiano de σ SIG px (tabla de 64 posiciones subpixel).
// ============================================================================
// ruido de valor 2D sobre una red fija de 1024² (periodo 1024 unidades: a la escala mas fina, 0,04 kpc, 41 kpc, mas que la galaxia: no se repite dentro);
// la semilla desplaza. Una tabla en vez del hash: la preparacion pasaba 3 s aqui (600 000 estrellas × 4 escalas)
var FV_GF11_LAT = null;
function fvGf11N(x, y, s) {
   var L = FV_GF11_LAT; if (!L) { L = FV_GF11_LAT = new Float32Array(1048576); var r = fvRng(1112); for (var q = 0; q < 1048576; ++q) L[q] = r(); }
   x += 91.7 * s; y += 53.3 * s;
   var ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy, x0 = ix & 1023, y0 = iy & 1023, x1 = (x0 + 1) & 1023, y1 = (y0 + 1) & 1023;
   fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
   var a = L[(y0 << 10) | x0], b = L[(y0 << 10) | x1], c = L[(y1 << 10) | x0], d = L[(y1 << 10) | x1];
   return (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy;
}
// las crestas del polvo turbulento en (X, Y) kpc: Σ AMP·(1 − |2n − 1|)^P / Σ AMP
function fvGf11Ridge(X, Y, TU) {
   var v = 0, A = 0, sc = TU.SC, am = TU.AMP, P = TU.P || 2;
   for (var o = 0; o < sc.length; ++o) { var q = 1 - Math.abs(2 * fvGf11N(X / sc[o], Y / sc[o], 501 + 13 * o) - 1); v += am[o] * (P === 2 ? q * q : Math.pow(q, P)); A += am[o]; }
   return v / A;
}
function fvGf11Get(T) {
   if (typeof FV_GAL_GF11 === "undefined" || !FV_GAL_GF11.ON || !T || !T.gf9 || T.isG11 || !T.vol || !(T.vol.POP > 0) || !fvGf11On()) return null;
   var key = JSON.stringify(FV_GAL_GF11);
   if (T.g11 && T.g11.key === key) return T.g11;
   T.g11 = fvGf11Prep(T, key);
   return T.g11;
}
// la tabla del perfil: para la posicion subpixel q (fx = (q + 0,5)/64) los pesos de los NT pixeles floor − (NT/2 − 1) … floor + NT/2, normalizados (flujo
// constante). NT = 4 con σ <= 1 px; 6 con σ mayor (ronda 2: con 4 tomas un σ de 1,4 px quedaba recortado en caja)
function fvGf11Kern(sig) {
   if (FV_GAL3.k11 && FV_GAL3.k11.sig === sig) return FV_GAL3.k11.t;
   var NT = sig > 1 ? 6 : 4, h = NT / 2 - 1, t = new Float32Array(64 * NT), i2 = 0.5 / (sig * sig);
   for (var q = 0; q < 64; ++q) { var fx = (q + 0.5) / 64, s = 0, w = [];
      for (var k = 0; k < NT; ++k) { var dd = (k - h) - fx; w[k] = Math.exp(-dd * dd * i2); s += w[k]; }
      for (k = 0; k < NT; ++k) t[NT * q + k] = w[k] / s; }
   t.NT = NT; FV_GAL3.k11 = { sig: sig, t: t };
   return t;
}
function fvGf11Pix(buf, W, H) {
   var p = buf._g11;
   if (!p || p.W !== W || p.H !== H) { var n = W * H; p = buf._g11 = { W: W, H: H, A: new Float32Array(n), B: new Float32Array(n), T: new Float32Array(n), F: new Float32Array(n) }; }
   return p;
}
// el mapa de fondo: copia de T con la luz S × (1 − kS·CW), la Y × (1 − kY·CW) (CW: la fraccion que se resuelve por texel, el apiñamiento) y el bulbo × fB
function fvGf11Bg(T, SP, kS, kY, fB, CW, LA, LS) {
   // LA: ganancia de toda la luz del fondo (P1, zonas de polvo); LS: ganancia de la luz lisa S (P2, resplandor del disco). null = 1
   var n2 = T.N * T.N, o = {}, k, i;
   for (k in T) if (T.hasOwnProperty(k)) o[k] = T[k];
   var sp = { sr: new Float32Array(n2), sg: new Float32Array(n2), sb: new Float32Array(n2), yr: new Float32Array(n2), yg: new Float32Array(n2), yb: new Float32Array(n2) };
   o.r = new Float32Array(n2); o.g = new Float32Array(n2); o.b = new Float32Array(n2);
   for (i = 0; i < n2; ++i) {
      var la = LA ? LA[i] : 1, fS = (1 - kS * CW[i]) * la * (LS ? LS[i] : 1), fY = (1 - kY * CW[i]) * la;
      sp.sr[i] = SP.sr[i] * fS; sp.sg[i] = SP.sg[i] * fS; sp.sb[i] = SP.sb[i] * fS; sp.yr[i] = SP.yr[i] * fY; sp.yg[i] = SP.yg[i] * fY; sp.yb[i] = SP.yb[i] * fY;
      o.r[i] = sp.sr[i] + sp.yr[i]; o.g[i] = sp.sg[i] + sp.yg[i]; o.b[i] = sp.sb[i] + sp.yb[i];
   }
   o.split = sp; o.bulgeK = (T.bulgeK === undefined ? 1 : T.bulgeK) * fB; o.noStars = true; o.isG11 = true; o.g11 = null; o.stars = null;
   return o;
}
// caja separable de radio r (texeles) sobre un mapa N x N, en su sitio (bordes: media de lo que cae dentro)
function fvGf11Box(A, N, r) {
   var tmp = new Float32Array(N), x, y, k;
   for (y = 0; y < N; ++y) {
      var s = 0, c = 0, o = y * N;
      for (k = 0; k < r && k < N; ++k) { s += A[o + k]; ++c; }
      for (x = 0; x < N; ++x) { if (x + r < N) { s += A[o + x + r]; ++c; } if (x - r - 1 >= 0) { s -= A[o + x - r - 1]; --c; } tmp[x] = s / c; }
      for (x = 0; x < N; ++x) A[o + x] = tmp[x];
   }
   for (x = 0; x < N; ++x) {
      var s2 = 0, c2 = 0;
      for (k = 0; k < r && k < N; ++k) { s2 += A[k * N + x]; ++c2; }
      for (y = 0; y < N; ++y) { if (y + r < N) { s2 += A[(y + r) * N + x]; ++c2; } if (y - r - 1 >= 0) { s2 -= A[(y - r - 1) * N + x]; --c2; } tmp[y] = s2 / c2; }
      for (y = 0; y < N; ++y) A[y * N + x] = tmp[y];
   }
}
function fvGf11Prep(T, key) {
   var F = FV_GAL_GF11, G = FV_GAL3, t0 = Date.now(), N = T.N, n2 = N * N, px = T.px, H = T.H, V = T.vol, i, o, c;
   var SP = fvGal3VolSplit(T), T9 = fvGf9Tabs(T, V), FY9 = T9.fy, WB9 = T9.wb, AX = (V.SAX > 0) ? fvGf8VolAxi(T, SP) : null, ZM = V.ZK * V.HZ;
   var rng = fvRng(F.SEED), cO = G.COL_OLD, CL = F.CL, TU = F.TURB, GM = F.GAM || [0, 0, 0], gS = GM[0], gY = GM[1], gB = GM[2], tms = {};
   var g2 = 0, gHave = false;   // gausiana por Box-Muller, de dos en dos
   function gauss() { if (gHave) { gHave = false; return g2; } var u = Math.max(1e-12, rng()), v = 2 * Math.PI * rng(), rr = Math.sqrt(-2 * Math.log(u)); g2 = rr * Math.sin(v); gHave = true; return rr * Math.cos(v); }
   function lfPrep(LF) { return [1 - Math.pow(LF.WMAX, 1 - LF.A), 1 / (1 - LF.A)]; }
   function lfw(q) { return Math.pow(1 - rng() * q[0], q[1]); }
   function expz(h) { for (var q = 0; q < 20; ++q) { var z = -h * Math.log(Math.max(1e-12, rng())); if (z < ZM) return z; } return ZM * rng(); }
   function pexN(h) { return 1 / (h * (1 - Math.exp(-ZM / h))); }   // la normalizacion de la exponencial truncada en ZM (una cara)
   var LFY = lfPrep(F.LF), LFO = lfPrep(F.LFO || F.LF), LFB = lfPrep(F.LFB || F.LF);
   function tent() { return rng() + rng() - 1; }   // reparto dentro del texel: triangular sobre dos texeles (sin escalones de 62,5 pc)
   // luminancias por texel y sus distribuciones acumuladas (la Y, pesada por lo que da cada suceso: 1 estrella de campo o un cumulo de En de media)
   var lS = new Float64Array(n2), lY = new Float64Array(n2), wY = new Float64Array(n2), pC = new Float32Array(n2), sS = 0, sYw = 0;
   var En = Math.log(CL.N1 / CL.N0) / (1 / CL.N0 - 1 / CL.N1), qOld = cO[2] / cO[0];
   // MX: la parte de la luz lisa S que viaja con las estrellas Y (en sus cumulos, con el color de la mezcla local) en vez de quedarse en el fondo. Con MX = 1 el
   // fondo pierde la MISMA fraccion de S y de Y y conserva el color de GF9 (A1); con estrellas S propias (FO) el grano amarillo era ruido (n12, n13)
   var MX = F.MX || 0;
   // BW (ronda 2): la fraccion resuelta se multiplica por P0 + (1 − P0)·suave((q − Q0)/QW), q = el azul de la luz Y (B/R relativo a COL_OLD): la luz Y de
   // color viejo (flanco de la barra, fosa) queda lisa; con ella resuelta salia grano amarillento sobre el flanco (revision de Nino, ronda 1 (b))
   var BW = F.BW || null, PHI = (F.PHI && F.PHI.K > 0) ? F.PHI : null;
   // (apiñamiento) la fraccion que se resuelve en estrellas cae donde la luz se amontona (bulbo, barra, nucleo): CW = 1/(1 + (L/Lc)^P), Lc = K × la mediana
   // de la luz del disco en R 3–12 kpc. Una galaxia real tampoco resuelve estrellas en su centro; y alli el grano solo era ruido (N1, N4, B1)
   var CW = new Float32Array(n2), CR = F.CROWD || { K: 1e9, P: 2 }, lt = [], R2a = 9 / (px * px), R2b = 144 / (px * px);
   for (o = 0; o < n2; o += 7) { var xj = (o % N) - N / 2 + 0.5, yj = Math.floor(o / N) - N / 2 + 0.5, q2 = xj * xj + yj * yj; if (q2 >= R2a && q2 <= R2b) lt.push(0.2126 * T.r[o] + 0.7152 * T.g[o] + 0.0722 * T.b[o]); }
   lt.sort(function(x1, y1) { return x1 - y1; }); var Lc = CR.K * (lt.length ? lt[lt.length >> 1] : 1);
   // y la fraccion resuelta es la MISMA para la luz S y la Y de cada texel (el fondo conserva su color: con FY >> FO el fondo entre estrellas quedaba viejo y
   // amarillo, A1 −5,5 -> −3,4), mayor donde la luz es de brazo (fraccion Y alta) y pequeña entre brazos: RS.MAX·(RS.MIN + (1 − RS.MIN)·suave((y − Y0)/YW))
   // y nada dentro de RC.R0 (kpc), rampa suave hasta RC.R1: el nucleo y la barra interior quedan lisos (con el apiñamiento solo, el perfil del nucleo
   // aun tenia escalones de estrella: N1 +0,01/+0,04 contra <= −0,02)
   // La fraccion Y se mide sobre la luz promediada en RES.BR texeles (caja separable, dos pasadas): medida texel a texel seguia a los grumos de GF9 y el fondo
   // quedaba con agujeros negros donde las estrellas (que se esparcen en cumulos) no caian
   var RS = F.RES || { MAX: 1, MIN: 1, Y0: 0, YW: 1, BR: 0 }, RC = F.RC || { R0: 0, R1: 1e-6 };
   var bL = new Float32Array(n2), bY = new Float32Array(n2);
   for (o = 0; o < n2; ++o) { bL[o] = 0.2126 * T.r[o] + 0.7152 * T.g[o] + 0.0722 * T.b[o]; bY[o] = 0.2126 * SP.yr[o] + 0.7152 * SP.yg[o] + 0.0722 * SP.yb[o]; }
   if (RS.BR > 0) { fvGf11Box(bL, N, RS.BR | 0); fvGf11Box(bY, N, RS.BR | 0); }
   for (o = 0; o < n2; ++o) { var Lt = 0.2126 * T.r[o] + 0.7152 * T.g[o] + 0.0722 * T.b[o], yf = bL[o] > 1e-12 ? bY[o] / bL[o] : 0;
      var xr = ((o % N) - N / 2 + 0.5) * px, yr = (Math.floor(o / N) - N / 2 + 0.5) * px, rr = Math.sqrt(xr * xr + yr * yr);
      CW[o] = RS.MAX * (RS.MIN + (1 - RS.MIN) * fvGal3Smooth((yf - RS.Y0) / RS.YW)) * fvGal3Smooth((rr - RC.R0) / (RC.R1 - RC.R0)) / (1 + Math.pow(Math.max(0, Lt) / Lc, CR.P)); }
   for (o = 0; o < n2; ++o) {
      var a = (0.2126 * SP.sr[o] + 0.7152 * SP.sg[o] + 0.0722 * SP.sb[o]) * CW[o], b = (0.2126 * SP.yr[o] + 0.7152 * SP.yg[o] + 0.0722 * SP.yb[o]) * CW[o] + MX * a;
      if (!(a > 0)) a = 0; if (!(b > 0)) b = 0;
      var q = (SP.yr[o] > 1e-9) ? (SP.yb[o] / SP.yr[o]) / qOld : 1, p = fvGal3Smooth((q - CL.Q0) / CL.QW); pC[o] = p;
      if (BW) { var kb = BW.P0 + (1 - BW.P0) * fvGal3Smooth((q - BW.Q0) / BW.QW); CW[o] *= kb; a *= kb; b *= kb; }
      sS += Math.pow(a, 1 - gS); lS[o] = sS; lY[o] = b; sYw += Math.pow(b, 1 - gY) / ((1 - p) + p * En); wY[o] = sYw;
   }
   function pick(cdf, tot) { var t = rng() * tot, lo = 0, hi = n2 - 1; while (lo < hi) { var m = (lo + hi) >> 1; if (cdf[m] < t) lo = m + 1; else hi = m; } return lo; }
   var NT = F.NO + F.NY + F.NB, X = new Float32Array(NT), Y = new Float32Array(NT), Z = new Float32Array(NT), C = new Float32Array(3 * NT), K = new Uint8Array(NT), RZ = new Float32Array(NT), Wt = new Float32Array(NT), Dt = new Float32Array(NT), n = 0;
   var warpF = T.warpF || null;
   // (1) la luz lisa y gruesa S (color COL_OLD): perfil en altura del disco fino + grueso (THK de HZT2), el de GF9; r = la luz de GF9 a esa altura / S
   var thk = V.THK > 0 ? V.THK : 0, h1 = V.HZ, h2 = V.HZT2 || V.HZ, h1q = h1 / (1 - gS), h2q = h2 / (1 - gS), nz1 = pexN(h1), nz2 = pexN(h2), nz1q = pexN(h1q), nz2q = pexN(h2q);
   tms.pre = Date.now() - t0;
   for (i = 0; i < F.NO; ++i) {
      o = pick(lS, sS); var xS = -H + ((o % N) + 0.5 + tent()) * px, yS = -H + (Math.floor(o / N) + 0.5 + tent()) * px;
      var za = expz(rng() < thk ? h2q : h1q), zz = za * (rng() < 0.5 ? -1 : 1), a0 = (0.2126 * SP.sr[o] + 0.7152 * SP.sg[o] + 0.0722 * SP.sb[o]) * CW[o];
      var w = lfw(LFO) * Math.pow(Math.max(a0, 1e-30), gS) * ((1 - thk) * nz1 * Math.exp(-za / h1) + thk * nz2 * Math.exp(-za / h2)) / ((1 - thk) * nz1q * Math.exp(-za / h1q) + thk * nz2q * Math.exp(-za / h2q));
      var rr = 1; if (AX) { var gz = Math.exp(-Math.abs(zz) / V.SAX); if (WB9) gz = WB9[o] + (1 - WB9[o]) * gz; var sg0 = SP.sg[o]; if (sg0 > 1e-12) rr = (AX.g[o] + (sg0 - AX.g[o]) * gz) / sg0; if (!(rr >= 0)) rr = 0; }
      X[n] = xS; Y[n] = yS; Z[n] = zz + (warpF ? warpF(xS, yS) : 0); K[n] = 0; RZ[n] = rr; Wt[n] = w;
      C[3 * n] = cO[0] * w; C[3 * n + 1] = cO[1] * w; C[3 * n + 2] = cO[2] * w; ++n;
   }
   var nS = n, nY0 = n; tms.S = Date.now() - t0;
   // (2) la luz estructurada y fina Y (su color local): de campo o en cumulo segun el azul; capa de HZY ensanchada por fY (GF9)
   while (n < nY0 + F.NY) {
      o = pick(wY, sYw); var lum = lY[o]; if (!(lum > 0)) continue;
      var lu0 = lum / Math.max(1e-12, CW[o]), cr = (SP.yr[o] + MX * SP.sr[o]) / lu0, cg = (SP.yg[o] + MX * SP.sg[o]) / lu0, cb = (SP.yb[o] + MX * SP.sb[o]) / lu0, xc = -H + ((o % N) + 0.5 + tent()) * px, yc = -H + (Math.floor(o / N) + 0.5 + tent()) * px;
      // PHI (ronda 2): las nubes de estrellas siguen un campo FIJO de crestas en kpc (red propia, independiente de SEED): se acepta el suceso con
      // probabilidad min(1, (Φ/R0)^K). La semilla solo elige estrellas dentro de las nubes; los bordes de las nubes (la alta frecuencia) son los mismos con
      // cualquier semilla: estructura, no sal (G1, gf11_grain.py)
      if (PHI && rng() > Math.min(1, Math.pow(fvGf11Ridge(xc, yc, PHI) / PHI.R0, PHI.K))) continue;
      var hzy = V.HZY * (FY9 ? 1 / FY9[o] : 1), hzq = hzy / (1 - gY), zca = expz(hzq), zc0 = zca * (rng() < 0.5 ? -1 : 1), nm = 1, sgc = 0, wE = Math.pow(lum, gY) * pexN(hzy) * Math.exp(-zca / hzy) / (pexN(hzq) * Math.exp(-zca / hzq));
      if (rng() < pC[o]) { nm = Math.round(1 / (1 / CL.N0 - rng() * (1 / CL.N0 - 1 / CL.N1))); sgc = CL.S0 * Math.pow(nm, CL.SE); }
      for (var mm = 0; mm < nm && n < nY0 + F.NY; ++mm) {
         var xm = xc + gauss() * sgc, ym = yc + gauss() * sgc, zm = zc0 + gauss() * sgc * CL.ZF, w2 = lfw(LFY) * wE;
         X[n] = xm; Y[n] = ym; Z[n] = zm + (warpF ? warpF(xm, ym) : 0); K[n] = 1; RZ[n] = 1; Wt[n] = w2;
         C[3 * n] = cr * w2; C[3 * n + 1] = cg * w2; C[3 * n + 2] = cb * w2; ++n;
      }
   }
   var nY = n; tms.Y = Date.now() - t0;
   // (3) el bulbo: sus gausianas triaxiales (las del render: T.bulge × T.bulgeK), cada una por su luz
   var Bc = T.bulge || G.BULGE, bK = (T.bulgeK === undefined ? 1 : T.bulgeK), sgB = (FV_GAL3_BREAK === "beta" ? -1 : 1), Lq = [], LB = 0, cB = G.COL_BULGE;
   for (var q2 = 0; q2 < Bc.length; ++q2) { var l2 = Bc[q2].a * bK * Math.pow(2 * Math.PI, 1.5) * Bc[q2].sx * Bc[q2].sy * Bc[q2].sz; LB += l2; Lq.push(LB); }
   for (i = 0; i < F.NB && LB > 0 && F.FB > 0; ++i) {
      var tq = rng() * LB, qq = 0; while (qq < Lq.length - 1 && Lq[qq] < tq) ++qq;
      var Bq = Bc[qq], ang = (Bq.ang !== undefined ? Bq.ang : G.BAR_ANG) * Math.PI / 180 * sgB, ux = -Math.cos(ang), uy = Math.sin(ang), vx = Math.sin(ang), vy = Math.cos(ang);
      var kq = 1 / Math.sqrt(1 - gB), g1 = gauss() * kq, g2 = gauss() * kq, g3 = gauss() * kq, uu = (Bq.u0 || 0) + g1 * Bq.sx, vv = (Bq.v0 || 0) + g2 * Bq.sy, w3 = lfw(LFB) * Math.exp(-0.5 * gB * (g1 * g1 + g2 * g2 + g3 * g3));
      X[n] = uu * ux + vv * vx; Y[n] = uu * uy + vv * vy; Z[n] = (Bq.z0 || 0) + g3 * Bq.sz; K[n] = 2; RZ[n] = 1; Wt[n] = w3;
      C[3 * n] = cB[0] * w3; C[3 * n + 1] = cB[1] * w3; C[3 * n + 2] = cB[2] * w3; ++n;
   }
   var nB = n; tms.B = Date.now() - t0;
   // (4) el polvo turbulento de cada estrella del disco (una vez, en kpc): Δτ = K·τ_mapa·(c/<c> − 1)
   if (TU && TU.ON && TU.K > 0) {
      var sc = 0, kd = G.DUST_RGB;
      for (i = 0; i < nY; ++i) { Dt[i] = fvGf11Ridge(X[i], Y[i], TU); sc += Dt[i]; }
      sc = nY > 0 ? sc / nY : 1;
      for (i = 0; i < nY; ++i) { var tl = fvGal3TexAt(T, T.dust, X[i], Y[i]), dta = TU.K * tl * (Dt[i] / sc - 1);
         C[3 * i] *= Math.exp(-kd[0] * dta); C[3 * i + 1] *= Math.exp(-kd[1] * dta); C[3 * i + 2] *= Math.exp(-kd[2] * dta); }
   }
   // (4b) CROMA: ninguna estrella mas saturada que CMAX ((max − min)/luminancia): los puntos azules saturados sueltos de la ronda 1 (a) eran cumulos de color
   //      local extremo mas el polvo turbulento negativo. Se acerca el color a gris conservando su luminancia; la renormalizacion por canal de (5) devuelve
   //      el color integrado de la poblacion
   if (F.CMAX > 0) for (i = 0; i < nY; ++i) {
      var c0 = C[3 * i], c1 = C[3 * i + 1], c2 = C[3 * i + 2], lm = 0.2126 * c0 + 0.7152 * c1 + 0.0722 * c2;
      if (lm > 0) { var mxc = Math.max(c0, c1, c2), mnc = Math.min(c0, c1, c2), sat = (mxc - mnc) / lm;
         if (sat > F.CMAX) { var kc = F.CMAX / sat; C[3 * i] = lm + (c0 - lm) * kc; C[3 * i + 1] = lm + (c1 - lm) * kc; C[3 * i + 2] = lm + (c2 - lm) * kc; } }
   }
   tms.turb = Date.now() - t0;
   // (5) el flujo: cada poblacion lleva exactamente su fraccion de la luz del mapa, canal a canal (el color integrado no se mueve)
   var A2 = px * px, tgt = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
   for (o = 0; o < n2; ++o) { var cw = CW[o]; tgt[0][0] += SP.sr[o] * cw; tgt[0][1] += SP.sg[o] * cw; tgt[0][2] += SP.sb[o] * cw; tgt[1][0] += (SP.yr[o] + MX * SP.sr[o]) * cw; tgt[1][1] += (SP.yg[o] + MX * SP.sg[o]) * cw; tgt[1][2] += (SP.yb[o] + MX * SP.sb[o]) * cw; }
   for (c = 0; c < 3; ++c) { tgt[0][c] *= F.FO * A2; tgt[1][c] *= F.FY * A2; tgt[2][c] = F.FB * LB * cB[c]; }
   var span = [[0, nS], [nY0, nY], [nY, nB]];
   for (var pp = 0; pp < 3; ++pp) { var s3 = [0, 0, 0];
      for (i = span[pp][0]; i < span[pp][1]; ++i) for (c = 0; c < 3; ++c) s3[c] += C[3 * i + c];
      for (c = 0; c < 3; ++c) { var kk = s3[c] > 0 ? tgt[pp][c] / s3[c] : 0; for (i = span[pp][0]; i < span[pp][1]; ++i) C[3 * i + c] *= kk; } }
   // (6) las que se pintan en movimiento: las de mas flujo (verde; la fraccion MOVE), delante en los arrays; la luz media de las demas, al mapa de movimiento
   for (i = 0; i < n; ++i) Wt[i] = C[3 * i + 1];
   var smp = []; for (i = 0; i < 4000; ++i) smp.push(Wt[Math.floor(rng() * n)]); smp.sort(function(x1, y1) { return y1 - x1; });
   var wthr = F.MOVE >= 1 ? -Infinity : smp[Math.min(smp.length - 1, Math.floor(F.MOVE * smp.length))], ord = new Int32Array(n), nm2 = 0, mvL = [[0, 0], [0, 0], [0, 0]];
   for (i = 0; i < n; ++i) if (Wt[i] >= wthr) ord[nm2++] = i;
   var nMove = nm2;
   for (i = 0; i < n; ++i) if (Wt[i] < wthr) ord[nm2++] = i;
   for (i = 0; i < n; ++i) { var lu = C[3 * i + 1], kq = K[i]; mvL[kq][1] += lu; if (Wt[i] >= wthr) mvL[kq][0] += lu; }
   function perm(Ar, k) { var B = new Ar.constructor(n * k); for (var ii = 0; ii < n; ++ii) for (var jj = 0; jj < k; ++jj) B[k * ii + jj] = Ar[k * ord[ii] + jj]; return B; }
   var st = { n: n, nMove: nMove, x: perm(X, 1), y: perm(Y, 1), z: perm(Z, 1), c: perm(C, 3), k: perm(K, 1), rz: perm(RZ, 1) };
   // (8) LOD de movimiento (ronda 2: el SALTO AL PARAR): las estrellas en orden de Morton sobre una red de 2H/4096 (vecinas en el plano, juntas en el array) y
   //     cada grupo de MSTRIDE consecutivas fundido en UNA: su centro pesado por flujo y la suma del flujo. En movimiento se pinta el LOD: la MISMA luz que
   //     parado, agrupada a la escala del grupo (con una de cada MSTRIDE al azar, el azar del submuestreo era el salto: 0,59 L*)
   if (F.MOVE >= 1 && F.MSTRIDE > 1) {
      var KL = F.MSTRIDE | 0, mk = new Float64Array(n), idx = new Int32Array(n), sc4 = 4096 / (2 * H);
      function spread(v) { v &= 0xfff; v = (v | (v << 8)) & 0x00ff00ff; v = (v | (v << 4)) & 0x0f0f0f0f; v = (v | (v << 2)) & 0x33333333; v = (v | (v << 1)) & 0x55555555; return v; }
      for (i = 0; i < n; ++i) { var gx = Math.max(0, Math.min(4095, ((st.x[i] + H) * sc4) | 0)), gy = Math.max(0, Math.min(4095, ((st.y[i] + H) * sc4) | 0)); mk[i] = (spread(gx) | (spread(gy) << 1)) + i / (n + 1); idx[i] = i; }
      mk.sort(); var srt = idx; for (i = 0; i < n; ++i) { var vk = mk[i]; srt[i] = Math.round((vk - Math.floor(vk)) * (n + 1)); }   // el indice va en la parte fraccionaria (orden numerico de la tabla tipada, sin comparador)
      var nl = Math.ceil(n / KL), LX = new Float32Array(nl), LY = new Float32Array(nl), LZ = new Float32Array(nl), LC = new Float32Array(3 * nl), LK = new Uint8Array(nl);
      for (var g = 0; g < nl; ++g) { var sw = 0, sx = 0, sy = 0, sz = 0, s0 = 0, s1 = 0, s2 = 0, kq0 = 1;
         for (var jj = g * KL; jj < Math.min(n, (g + 1) * KL); ++jj) { var q = srt[jj], wq = st.c[3 * q + 1] + 1e-30; sw += wq; sx += st.x[q] * wq; sy += st.y[q] * wq; sz += st.z[q] * wq; s0 += st.c[3 * q]; s1 += st.c[3 * q + 1]; s2 += st.c[3 * q + 2]; kq0 = st.k[q]; }
         LX[g] = sx / sw; LY[g] = sy / sw; LZ[g] = sz / sw; LC[3 * g] = s0; LC[3 * g + 1] = s1; LC[3 * g + 2] = s2; LK[g] = kq0; }
      st.lod = { n: nl, x: LX, y: LY, z: LZ, c: LC, k: LK };
   }
   var mS = mvL[0][1] > 0 ? mvL[0][0] / mvL[0][1] : 0, mY = mvL[1][1] > 0 ? mvL[1][0] / mvL[1][1] : 0, mB = mvL[2][1] > 0 ? mvL[2][0] / mvL[2][1] : 0;
   // (7) P1 / P2 (ronda 2, «mas brillo en el polvo»): P1 = toda la luz del fondo × (1 + K·m), m = suave((τ promediado en BR texeles − T0)/(T1 − T0)) en el
   //     disco (R1..R2 kpc): las zonas de polvo (carriles y su entorno pardo) mas luminosas y, como la ganancia es la misma a ambos lados del carril (τ
   //     promediado a 0,5 kpc), su contraste se conserva. P2 = la luz lisa S × (1 + K) con rampa R0..R1 (sin tocar el nucleo: N4): mas resplandor del disco
   //     bajo el polvo. Ambos solo en el fondo: el mismo en movimiento y parado
   var LA = null, LS = null, P1 = F.P1, P2 = F.P2;
   if (P1 && P1.K > 0) { LA = new Float32Array(n2); var tb = new Float32Array(n2); for (o = 0; o < n2; ++o) tb[o] = T.dust[o]; fvGf11Box(tb, N, P1.BR | 0);
      for (o = 0; o < n2; ++o) { var xp = ((o % N) - N / 2 + 0.5) * px, yp = (Math.floor(o / N) - N / 2 + 0.5) * px, rp = Math.sqrt(xp * xp + yp * yp);
         LA[o] = 1 + P1.K * fvGal3Smooth((tb[o] - P1.T0) / (P1.T1 - P1.T0)) * fvGal3Smooth((rp - P1.R1) / 0.8) * (1 - fvGal3Smooth((rp - P1.R2) / 2)); } }
   if (P2 && P2.K > 0) { LS = new Float32Array(n2);
      for (o = 0; o < n2; ++o) { var xq = ((o % N) - N / 2 + 0.5) * px, yq = (Math.floor(o / N) - N / 2 + 0.5) * px; LS[o] = 1 + P2.K * fvGal3Smooth((Math.sqrt(xq * xq + yq * yq) - P2.R0) / (P2.R1 - P2.R0)); } }
   var bg = fvGf11Bg(T, SP, F.FO + F.FY * MX, F.FY, 1 - F.FB, CW, LA, LS), bgM = fvGf11Bg(T, SP, F.FO * mS + F.FY * MX * mY, F.FY * mY, 1 - F.FB * mB, CW, LA, LS);
   tms.end = Date.now() - t0;
   return { key: key, st: st, bg: bg, bgMove: bgM, ms: Date.now() - t0, tms: tms, nS: nS, nY: nY - nY0, nB: nB - nY, mv: [mS, mY, mB] };
}
// las estrellas al bufer. P: fvGf11Pix del mismo bufer (ya escrito por el render); mv: solo las de movimiento; V: la capa de canto (vol) para el polvo del rayo
function fvGf11Splat(cam, W, H, buf, g11, gn, P, mv, V) {
   var F = FV_GAL_GF11, G = FV_GAL3, S = g11.st, n = mv ? S.nMove : S.n, R0 = G.R0;
   // MSTRIDE (ronda 2): en movimiento, una de cada MSTRIDE estrellas con su flujo × MSTRIDE (con MOVE 1: las mismas nubes que parado, sin salto al parar)
   var stp = (mv && F.MSTRIDE > 1) ? (F.MSTRIDE | 0) : 1;
   var fw = cam.fw, r = cam.r, d = cam.d, cx = cam.cx, cy = cam.cy, ox = cam.pos[0] - R0, oy = cam.pos[1], oz = cam.pos[2] + G.ZSUN, f = cam.f;
   var f2 = f * f * gn * stp, zn2 = F.ZNEAR * F.ZNEAR, PA = P.A, PT = P.T, PF = P.F, KT = fvGf11Kern(mv && F.SIGMV > 0 ? F.SIGMV : F.SIG), NT = KT.NT;   // SIGMV: en movimiento (media resolucion, 1/MSTRIDE de las estrellas) un perfil algo mas ancho: el azar del submuestreo no centellea
   var Xs = S.x, Ys = S.y, Zs = S.z, C = S.c, K = S.k, W3 = 3 * W;
   if (mv && S.lod) { Xs = S.lod.x; Ys = S.lod.y; Zs = S.lod.z; C = S.lod.c; K = S.lod.k; n = S.lod.n; stp = 1; f2 = f * f * gn; }   // en movimiento, el LOD (8)
   var brk = FV_GF11_BREAK === "screen", cs = brk ? ((Math.round(cam.cx * 131 + cam.cy * 17 + cam.f * 7 + cam.pos[0] * 1013 + cam.pos[1] * 977 + cam.pos[2] * 1171)) | 0) : 0;
   for (var m = 0; m < n; m += stp) {
      var rx = Xs[m] - ox, ry = Ys[m] - oy, rz = Zs[m] - oz, zc = rx * fw[0] + ry * fw[1] + rz * fw[2];
      if (zc < 0.05) continue;
      var iz = f / zc, X2 = cx + (rx * r[0] + ry * r[1] + rz * r[2]) * iz - 0.5, Y2 = cy + (rx * d[0] + ry * d[1] + rz * d[2]) * iz - 0.5;
      if (brk) { X2 += 3 * (fvGal3H(m, cs, 1, 5) - 0.5); Y2 += 3 * (fvGal3H(m, cs, 2, 5) - 0.5); }
      var ix = Math.floor(X2), iy = Math.floor(Y2);
      if (ix < 1 || iy < 1 || ix > W - 3 || iy > H - 3) continue;
      var pc = ((Y2 + 0.5) | 0) * W + ((X2 + 0.5) | 0), s = f2 / (zc * zc + zn2), kk = K[m], m3 = 3 * m, c0, c1, c2;
      if (kk === 2) { var fb = PF[pc]; if (fb < 0) { var tb = PT[pc]; fb = tb > 0 ? 0.5 + 0.5 * Math.exp(-tb) : 1; } fb *= s; if (!(fb > 0)) continue; c0 = C[m3] * fb; c1 = C[m3 + 1] * fb; c2 = C[m3 + 2] * fb; }
      else { var sa = s * PA[pc]; if (!(sa > 0)) continue; c0 = C[m3] * sa; c1 = C[m3 + 1] * sa; c2 = C[m3 + 2] * sa; }   // el disco: solo la parte del plano (A)
      if (NT === 4) {
         var kx4 = 4 * (((X2 - ix) * 64) | 0), ky4 = 4 * (((Y2 - iy) * 64) | 0);
         var wx0 = KT[kx4], wx1 = KT[kx4 + 1], wx2 = KT[kx4 + 2], wx3 = KT[kx4 + 3], o0 = 3 * ((iy - 1) * W + ix - 1);
         for (var jy = 0; jy < 4; ++jy) {
            var wy = KT[ky4 + jy], o1 = o0 + jy * W3, q0 = wy * wx0, q1 = wy * wx1, q2 = wy * wx2, q3 = wy * wx3;
            buf[o1] += c0 * q0; buf[o1 + 1] += c1 * q0; buf[o1 + 2] += c2 * q0;
            buf[o1 + 3] += c0 * q1; buf[o1 + 4] += c1 * q1; buf[o1 + 5] += c2 * q1;
            buf[o1 + 6] += c0 * q2; buf[o1 + 7] += c1 * q2; buf[o1 + 8] += c2 * q2;
            buf[o1 + 9] += c0 * q3; buf[o1 + 10] += c1 * q3; buf[o1 + 11] += c2 * q3;
         }
      } else {
         if (ix < 3 || iy < 3 || ix > W - 4 || iy > H - 4) continue;
         var kx = NT * (((X2 - ix) * 64) | 0), ky = NT * (((Y2 - iy) * 64) | 0), ob = 3 * ((iy - 2) * W + ix - 2);
         for (var jy2 = 0; jy2 < NT; ++jy2) { var wy2 = KT[ky + jy2], ob1 = ob + jy2 * W3;
            for (var jx2 = 0; jx2 < NT; ++jx2) { var qq = wy2 * KT[kx + jx2], ob2 = ob1 + 3 * jx2; buf[ob2] += c0 * qq; buf[ob2 + 1] += c1 * qq; buf[ob2 + 2] += c2 * qq; } }
      }
   }
}
