// ============================================================================
// FieldVoyager/src/engine/fv_time.js — LA MAQUINA DEL TIEMPO de la escena (encargo I4, 4-nov-2026). PURO (PixInsight y navegador).
// ----------------------------------------------------------------------------
// Nino: «Máquina del tiempo, al lado de CHRONOMETRUM»: mover las estrellas de la foto ±100 000 años con su movimiento propio y su
// velocidad radial de Gaia.
//
// PROCEDENCIA (regla del repo: se COPIA y se adapta, sin depender en tiempo de ejecucion):
//   Cabra3D/src/tm/timemachine.js (14-oct-2026) — C3_TM (unidades KMS_PCYR, K_PM, DEG), c3TmState (estado 3D ICRS), c3TmPropagate
//   (solo el modelo "linear": movimiento rectilineo y uniforme relativo al Sol, ESA 1997 vol. 1 §1.5.5, con la aceleracion de
//   perspectiva porque se propaga el vector), c3TmSliderToYears / c3TmYearsToSlider (seno hiperbolico, K = 4) y c3TmRoundYears
//   (3 cifras). Cabra3D/src/tm/timemachine_ui.js — RANGE_DEFAULT ±100 000 años y c3TmTimeText (lectura «+12 000 años»).
//   Lo que NO se copia: el modelo «galactic» (epiciclos): a ±100 000 años la recta y la orbita difieren < 0,1 % del desplazamiento
//   (MEDIDO en Cabra3D, tests/c3_tm_cases.js 4.3; C3_TM.LINEAR_OK_YR = 1e5), asi que aqui manda la recta.
//
// EL MARCO. La escena no esta en ICRS: cada estrella va en el rayo de SU pixel (fv_scene.js; Tierra en el origen, +Z al centro de la foto,
// +X derecha, +Y abajo). El desplazamiento se calcula en ICRS (pc) y se lleva al mundo con la rotacion M (ICRS -> mundo) que se AJUSTA
// a las propias estrellas de la escena: el centro de masas de las direcciones ICRS (meta.ra, meta.dec) va al de las direcciones del
// mundo, y el giro en el plano tangente (o la reflexion, si la foto viene en espejo) es el de minimos cuadrados (Procrustes 2D). El
// residuo por estrella (segundos de arco) se guarda: dice si la foto y el catalogo casan (en una foto resuelta, del orden del pixel).
//
// QUE SE MUEVE. Cada estrella con movimiento propio (meta.pmRa —YA por cos dec, el «pmra» de Gaia— y meta.pmDec, mas/año):
//   · con velocidad radial (meta.rv, km/s): movimiento 3D completo (has = 2);
//   · sin ella: SOLO TANGENCIAL (rv = 0, has = 1): en el cielo se mueve bien (el angulo recorrido no depende de la distancia ni de rv a
//     primer orden), pero la distancia a la Tierra apenas cambia — se dice en la lectura;
//   · sin movimiento propio: quieta (has = 0).
// La velocidad tangencial usa la distancia DE LA ESCENA (dEarth): la misma con la que se pinta (supuesta si no hay paralaje de fiar).
//
// INTERFAZ (lo que usara el pintor cuando F termine):
//   fvTimeApply(scene, years) -> la vista de estrellas de ese año (scene.time.stars): un objeto como scene.stars con x, y, z NUEVOS
//                                (Float64Array) y todo lo demas COMPARTIDO (g, dEarth, col… sin copiar). scene.stars NO se toca.
//                                g y dEarth se dejan los de hoy a proposito: fvApparentMag(g, dEarth, dCam) con la distancia de la camara
//                                a la posicion NUEVA da ya el brillo correcto (la luminosidad no cambia). dNow (Float32Array) = la
//                                distancia nueva a la Tierra, para la ficha.
//   fvTimeStars(scene)        -> las estrellas que hay que pintar: la vista del año elegido o scene.stars si es hoy (o no hay datos).
//   fvTimeGauge(scene)        -> { years, ok, nFull, nTan, nNone } para la cabina (mando AETAS).
// ES5. Sin PixInsight ni DOM.
// ============================================================================

var FV_TIME = {
   RANGE_YR: 1e5,                                   // ±100 000 años (Cabra3D C3_TMUI.RANGE_DEFAULT)
   K: 4,                                            // la curva del mando (Cabra3D: sinh(K s) / sinh(K))
   DETENT: 0.035,                                   // muesca de «hoy»: |s| por debajo -> 0 años exactos
   KMS_PCYR: 31557600 / 3.0856775814913673e13,      // 1 km/s en pc/año (exacto, IAU)
   K_PM: 149597870.7 / 31557600,                    // km/s por (mas/año · kpc) = 1 UA/año en km/s
   DEG: Math.PI / 180,
   FRAME_MAX: 4000,                                 // estrellas como mucho para ajustar el marco (las primeras con meta)
   GAL_ON: true                                     // (F2, 20-nov) el interruptor SOL | GALAXIA del mando AETAS (false = solo el movimiento visto desde el Sol, como antes)
};
// CONTROLES EN ROJO (pruebas): "norv" ignora la velocidad radial · "frame" usa la identidad como marco · "sign" invierte el tiempo · (F2) "nogal" / "galsign": el modo GALAXIA sin descontar / con el signo cambiado
var FV_TIME_BREAK = "";

function fvTimeLyPerPc() { return (typeof FV_LY_PER_PC === "number") ? FV_LY_PER_PC : 3.26156; }
function fvTimeDot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
function fvTimeNorm(a) { var l = Math.sqrt(fvTimeDot(a, a)); return l > 0 ? [a[0] / l, a[1] / l, a[2] / l] : [0, 0, 0]; }
function fvTimeCross(a, b) { return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]; }
function fvTimeRaDec(ra, dec) { var a = ra * FV_TIME.DEG, d = dec * FV_TIME.DEG; return [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)]; }
function fvTimeMul(M, v) { return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2], M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2], M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]]; }

// EL ESTADO 3D de una estrella (copia de c3TmState): posicion (pc) y velocidad (pc/año) en ICRS, con el Sol en el origen.
//   ra, dec (grados), d (pc), pmRa (mas/año, YA por cos dec), pmDec (mas/año), rv (km/s)
function fvTimeState(ra, dec, d, pmRa, pmDec, rv) {
   var a = ra * FV_TIME.DEG, b = dec * FV_TIME.DEG, ca = Math.cos(a), sa = Math.sin(a), cb = Math.cos(b), sb = Math.sin(b);
   var r = [cb * ca, cb * sa, sb], p = [-sa, ca, 0], q = [-sb * ca, -sb * sa, cb];
   var vt = FV_TIME.K_PM * d / 1000, va = (pmRa || 0) * vt, vd = (pmDec || 0) * vt, vr = rv || 0, k = FV_TIME.KMS_PCYR;
   return { x: d * r[0], y: d * r[1], z: d * r[2],
            vx: (va * p[0] + vd * q[0] + vr * r[0]) * k, vy: (va * p[1] + vd * q[1] + vr * r[1]) * k, vz: (va * p[2] + vd * q[2] + vr * r[2]) * k };
}
// PROPAGAR T años en linea recta (copia de c3TmPropagate, modelo "linear")
function fvTimePropagate(s, T) { return { x: s.x + s.vx * T, y: s.y + s.vy * T, z: s.z + s.vz * T, vx: s.vx, vy: s.vy, vz: s.vz }; }
// de vuelta a { ra, dec (grados), d (pc) } (copia de c3TmSky)
function fvTimeSky(x, y, z) {
   var d = Math.sqrt(x * x + y * y + z * z);
   if (!(d > 0)) return { ra: 0, dec: 0, d: 0 };
   var ra = Math.atan2(y, x) / FV_TIME.DEG; if (ra < 0) ra += 360;
   return { ra: ra, dec: Math.asin(Math.max(-1, Math.min(1, z / d))) / FV_TIME.DEG, d: d };
}
// el encuentro mas cercano con el Sol de un movimiento rectilineo (copia de c3TmClosest): { t (años), d (pc) }
function fvTimeClosest(s) {
   var v2 = s.vx * s.vx + s.vy * s.vy + s.vz * s.vz;
   if (!(v2 > 0)) return { t: 0, d: Math.sqrt(s.x * s.x + s.y * s.y + s.z * s.z) };
   var t = -(s.x * s.vx + s.y * s.vy + s.z * s.vz) / v2, x = s.x + s.vx * t, y = s.y + s.vy * t, z = s.z + s.vz * t;
   return { t: t, d: Math.sqrt(x * x + y * y + z * z) };
}

// EL MARCO ICRS -> MUNDO ajustado a las estrellas de la escena -> { M (3×3), n, medArcsec, maxArcsec, mirrored } | null (menos de 3)
function fvTimeFrame(scene) {
   var S = scene && scene.stars; if (!S || !S.n) return null;
   // las estrellas DE LA FOTO primero (van en el rayo de su pixel: son las que miden el marco; las del cielo de alrededor ya se
   // colocaron con una rotacion), repartidas por toda la lista (paso fijo) y como mucho FRAME_MAX
   var R = [], W = [], i, cr = [0, 0, 0], cw = [0, 0, 0], idx = [], pass, nIn = 0, k0 = 0;
   for (i = 0; i < S.n; ++i) if (S.inFrame && S.inFrame[i]) ++nIn;
   for (pass = 0; pass < 2; ++pass) {
      var want = (pass === 0) ? nIn : S.n - nIn, step = Math.max(1, Math.ceil(want / Math.max(1, FV_TIME.FRAME_MAX - idx.length)));
      for (i = 0, k0 = 0; i < S.n; ++i) { var inF = !!(S.inFrame && S.inFrame[i]); if (inF !== (pass === 0)) continue; if ((k0++ % step) === 0 && idx.length < FV_TIME.FRAME_MAX) idx.push(i); }
      if (pass === 0 && idx.length >= 3) break;
   }
   for (var j = 0; j < idx.length; ++j) {
      i = idx[j];
      var m = S.meta ? S.meta[i] : null;
      if (!m || !isFinite(m.ra) || !isFinite(m.dec) || m.ra === null || m.dec === null) continue;
      var w = fvTimeNorm([S.x[i], S.y[i], S.z[i]]); if (!(w[0] || w[1] || w[2])) continue;
      var r = fvTimeRaDec(m.ra, m.dec);
      R.push(r); W.push(w); cr[0] += r[0]; cr[1] += r[1]; cr[2] += r[2]; cw[0] += w[0]; cw[1] += w[1]; cw[2] += w[2];
   }
   var n = R.length; if (n < 3) return null;
   cr = fvTimeNorm(cr); cw = fvTimeNorm(cw);
   if (FV_TIME_BREAK === "frame") return { M: [[1, 0, 0], [0, 1, 0], [0, 0, 1]], n: n, medArcsec: NaN, maxArcsec: NaN, mirrored: false, broken: true };
   // bases de los dos planos tangentes
   function basis(c) { var t = Math.abs(c[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0], e1 = fvTimeNorm(fvTimeCross(t, c)); return [e1, fvTimeCross(c, e1)]; }
   var Br = basis(cr), Bw = basis(cw), sxx = 0, sxy = 0, syx = 0, syy = 0;
   for (i = 0; i < n; ++i) {
      var u = fvTimeDot(R[i], Br[0]), v = fvTimeDot(R[i], Br[1]), p = fvTimeDot(W[i], Bw[0]), q = fvTimeDot(W[i], Bw[1]);
      sxx += u * p; sxy += u * q; syx += v * p; syy += v * q;
   }
   function build(Q) {
      var M = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], a, b;
      // M = cw crᵀ + Bw0 (Q00 Br0ᵀ + Q01 Br1ᵀ) + Bw1 (Q10 Br0ᵀ + Q11 Br1ᵀ)
      for (a = 0; a < 3; ++a) for (b = 0; b < 3; ++b)
         M[a][b] = cw[a] * cr[b] + Bw[0][a] * (Q[0][0] * Br[0][b] + Q[0][1] * Br[1][b]) + Bw[1][a] * (Q[1][0] * Br[0][b] + Q[1][1] * Br[1][b]);
      return M;
   }
   // giro (det +1) y reflexion (det −1, foto en espejo): el que deje menos residuo
   var th = Math.atan2(sxy - syx, sxx + syy), c1 = Math.cos(th), s1 = Math.sin(th);
   var ph = Math.atan2(sxy + syx, sxx - syy), c2 = Math.cos(ph), s2 = Math.sin(ph);
   var cand = [{ M: build([[c1, -s1], [s1, c1]]), mirrored: false }, { M: build([[c2, s2], [s2, -c2]]), mirrored: true }];
   for (var k = 0; k < 2; ++k) {
      var res = [];
      for (i = 0; i < n; ++i) { var mr = fvTimeMul(cand[k].M, R[i]), dx = mr[0] - W[i][0], dy = mr[1] - W[i][1], dz = mr[2] - W[i][2]; res.push(Math.sqrt(dx * dx + dy * dy + dz * dz) * 206264.806); }
      res.sort(function(x, y) { return x - y; });
      cand[k].med = res[Math.floor(n / 2)]; cand[k].max = res[n - 1];
   }
   var best = (cand[0].med <= cand[1].med) ? cand[0] : cand[1];
   return { M: best.M, n: n, medArcsec: best.med, maxArcsec: best.max, mirrored: best.mirrored, otherMedArcsec: (best === cand[0] ? cand[1] : cand[0]).med };
}

// PREPARAR (una vez por escena): velocidades en el MUNDO (años luz/año) -> scene.time
function fvTimePrepare(scene) {
   var S = scene && scene.stars; if (!S) return null;
   if (scene.time && scene.time.src === S && scene.time.brk === FV_TIME_BREAK) return scene.time;
   var n = S.n, F = fvTimeFrame(scene), LY = fvTimeLyPerPc(), vx = new Float64Array(n), vy = new Float64Array(n), vz = new Float64Array(n), has = new Uint8Array(n);
   var nFull = 0, nTan = 0, nNone = 0;
   for (var i = 0; i < n; ++i) {
      var m = S.meta ? (S.meta[i] || {}) : {};
      var okPm = F && isFinite(m.pmRa) && isFinite(m.pmDec) && m.pmRa !== null && m.pmDec !== null && isFinite(m.ra) && isFinite(m.dec) && S.dEarth[i] > 0;
      if (!okPm) { ++nNone; continue; }
      var okRv = (m.rv !== null && m.rv !== undefined && isFinite(m.rv)) && FV_TIME_BREAK !== "norv";
      var st = fvTimeState(m.ra, m.dec, S.dEarth[i] / LY, m.pmRa, m.pmDec, okRv ? m.rv : 0);
      var w = fvTimeMul(F.M, [st.vx * LY, st.vy * LY, st.vz * LY]);
      vx[i] = w[0]; vy[i] = w[1]; vz[i] = w[2]; has[i] = okRv ? 2 : 1;
      if (okRv) ++nFull; else ++nTan;
   }
   scene.time = { src: S, brk: FV_TIME_BREAK, frame: F, vx: vx, vy: vy, vz: vz, has: has, nFull: nFull, nTan: nTan, nNone: nNone, years: 0, stars: null, sun: { vx: vx, vy: vy, vz: vz }, mode: "sun", gal: null };
   return scene.time;
}

// LA ESCENA EN EL AÑO `years` (desde la foto; negativo = pasado). -> la vista de estrellas (no toca scene.stars)
function fvTimeApply(scene, years) {
   var T = fvTimePrepare(scene); if (!T) return scene && scene.stars ? scene.stars : null;
   var S = scene.stars, y = isFinite(years) ? Math.max(-FV_TIME.RANGE_YR, Math.min(FV_TIME.RANGE_YR, years)) : 0;
   if (FV_TIME_BREAK === "sign") y = -y;
   T.years = isFinite(years) ? Math.max(-FV_TIME.RANGE_YR, Math.min(FV_TIME.RANGE_YR, years)) : 0;
   if (T.years === 0) { T.stars = null; return S; }
   var n = S.n, X = (T.stars && T.stars.x.length === n) ? T.stars.x : new Float64Array(n), Y = (T.stars && T.stars.y.length === n) ? T.stars.y : new Float64Array(n),
       Z = (T.stars && T.stars.z.length === n) ? T.stars.z : new Float64Array(n), D = (T.stars && T.stars.dNow) ? T.stars.dNow : new Float32Array(n);
   for (var i = 0; i < n; ++i) {
      var x = S.x[i], yy = S.y[i], z = S.z[i];
      if (T.has[i]) { x += T.vx[i] * y; yy += T.vy[i] * y; z += T.vz[i] * y; }
      X[i] = x; Y[i] = yy; Z[i] = z; D[i] = Math.sqrt(x * x + yy * yy + z * z);
   }
   if (!T.stars) {
      var V = {}; for (var k in S) if (Object.prototype.hasOwnProperty.call(S, k)) V[k] = S[k];      // todo compartido…
      T.stars = V;
   }
   T.stars.x = X; T.stars.y = Y; T.stars.z = Z; T.stars.dNow = D; T.stars.years = T.years;          // …menos las posiciones
   return T.stars;
}
function fvTimeStars(scene) { return (scene && scene.time && scene.time.years && scene.time.stars) ? scene.time.stars : (scene ? scene.stars : null); }
function fvTimeGauge(scene) {
   var T = scene && scene.stars ? fvTimePrepare(scene) : null;
   if (!T) return { years: 0, ok: false, nFull: 0, nTan: 0, nNone: 0 };
   var okG = (T.nFull + T.nTan) > 0;
   return { years: T.years, ok: okG, nFull: T.nFull, nTan: T.nTan, nNone: T.nNone, mode: fvTimeMode(scene), canGal: okG && fvTimeCanGal(scene) };      // (F2) mode y canGal: el interruptor SOL | GALAXIA
}

// ----------------------------------------------------------------------------
// (F2, 20-nov-2026) EL INTERRUPTOR SOL | GALAXIA del mando AETAS. Nino: «Quiero que aparezcan las fugitivas» y la propuesta V1 de F-fugitivas.md: lo que enseña la
// Galaxia no es la flecha de una estrella sino mover TODAS con su velocidad PECULIAR (la observada menos la de una orbita circular en SU sitio de la Galaxia y menos
// el movimiento del Sol: Schönrich+ 2010, Reid+ 2019; src/engine/fv_runaway.js, fvRunExpected). En SOL (lo de siempre) las estrellas llevan el reflejo del Sol y la
// rotacion mezclado con lo suyo; en GALAXIA casi todas se quedan quietas y la que corre salta a la vista, haya fugitiva o no. Sin velocidad radial, solo la parte
// tangencial (lo que se mide). La camara no se mueve: solo cambia la velocidad de cada estrella. Con las estrellas de distancia SUPUESTA se hace lo mismo con esa distancia.
// scene.time.mode = "sun" | "gal"; T.vx/vy/vz son SIEMPRE las del modo activo (los pintores y las estelas no se enteran); T.sun y T.gal guardan las dos.
// ----------------------------------------------------------------------------
function fvTimeGalPrepare(scene) {
   var T = scene && scene.stars ? fvTimePrepare(scene) : null; if (!T) return null;
   if (T.gal) return T.gal;
   if (typeof fvRunExpected !== "function" || typeof fvRunBasis !== "function" || typeof fvRunParams !== "function" || typeof fvRunRng !== "function" || typeof fvRunMul !== "function" || !T.frame) return null;
   var S = scene.stars, n = S.n, LY = fvTimeLyPerPc(), P = fvRunParams(fvRunRng(1), false), G = FV_RUN_AG, k = FV_TIME.KMS_PCYR, i;
   var vx = new Float64Array(n), vy = new Float64Array(n), vz = new Float64Array(n), pmRa = new Float64Array(n), pmDec = new Float64Array(n), nOk = 0;
   for (i = 0; i < n; ++i) {
      if (!T.has[i]) continue;
      var m = S.meta[i], dPc = S.dEarth[i] / LY, dK = dPc / 1000, B = fvRunBasis(m.ra, m.dec), X = [dK * B.r[0], dK * B.r[1], dK * B.r[2]], ex = fvRunExpected(X, P);      // km/s, ejes galacticos
      var st = fvTimeState(m.ra, m.dec, dPc, m.pmRa, m.pmDec, T.has[i] === 2 ? m.rv : 0), vG = fvRunMul(G, [st.vx / k, st.vy / k, st.vz / k]);                          // la heliocentrica de SOL, en ejes galacticos
      var er = ex[0] * B.r[0] + ex[1] * B.r[1] + ex[2] * B.r[2];
      var xu = (T.has[i] === 2) ? ex : [ex[0] - er * B.r[0], ex[1] - er * B.r[1], ex[2] - er * B.r[2]];                                                              // sin v. r.: solo la parte tangencial
      var sgn = (FV_TIME_BREAK === "galsign") ? -1 : 1, pG = (FV_TIME_BREAK === "nogal") ? vG : [vG[0] - sgn * xu[0], vG[1] - sgn * xu[1], vG[2] - sgn * xu[2]];      // (rojos: "nogal" no descuenta nada · "galsign" descuenta con el signo cambiado)
      var pI = [G[0][0] * pG[0] + G[1][0] * pG[1] + G[2][0] * pG[2], G[0][1] * pG[0] + G[1][1] * pG[1] + G[2][1] * pG[2], G[0][2] * pG[0] + G[1][2] * pG[1] + G[2][2] * pG[2]];      // de vuelta a ICRS (la matriz es ortonormal: su traspuesta)
      var w = fvTimeMul(T.frame.M, [pI[0] * k * LY, pI[1] * k * LY, pI[2] * k * LY]);
      vx[i] = w[0]; vy[i] = w[1]; vz[i] = w[2];
      var kd = FV_RUN_K * dK, ep = ex[0] * B.p[0] + ex[1] * B.p[1] + ex[2] * B.p[2], eq = ex[0] * B.q[0] + ex[1] * B.q[1] + ex[2] * B.q[2];      // el movimiento propio PECULIAR (mas/año): lo medido menos lo esperado
      pmRa[i] = (kd > 0) ? m.pmRa - ep / kd : 0; pmDec[i] = (kd > 0) ? m.pmDec - eq / kd : 0; ++nOk;
   }
   T.gal = { vx: vx, vy: vy, vz: vz, pmRa: pmRa, pmDec: pmDec, n: nOk };
   return T.gal;
}
// «sun» | «gal»
function fvTimeMode(scene) { return (scene && scene.time && scene.time.mode === "gal") ? "gal" : "sun"; }
// ¿se puede ofrecer el interruptor? (bandera, datos de movimiento y el motor de la fugitiva cargado)
function fvTimeCanGal(scene) {
   if (FV_TIME.GAL_ON !== true || !scene || !scene.stars) return false;
   var T = fvTimePrepare(scene); if (!T || (T.nFull + T.nTan) <= 0) return false;
   return !!fvTimeGalPrepare(scene);
}
// elegir el modo -> true si CAMBIO (quien llama vuelve a aplicar el año: fvTimeApply(scene, years))
function fvTimeSetMode(scene, mode) {
   var T = scene && scene.stars ? fvTimePrepare(scene) : null; if (!T) return false;
   var want = (mode === "gal" && fvTimeCanGal(scene)) ? "gal" : "sun";
   if ((T.mode || "sun") === want) return false;
   var V = (want === "gal") ? T.gal : T.sun;
   T.vx = V.vx; T.vy = V.vy; T.vz = V.vz; T.mode = want; T.trails = null; T.stars = null;
   return true;
}
// la marca del modo para las placas: "" en SOL, «GALAXY» / «GALAXIA» en GALAXIA
function fvTimeModeTag(scene, lang) { return (fvTimeMode(scene) === "gal") ? ((lang === "es") ? "GALAXIA" : "GALAXY") : ""; }

// EL MANDO: s en [−1, 1] (arriba = futuro) <-> años (copia de c3TmSliderToYears / c3TmYearsToSlider sin los pasos), con muesca en «hoy»
function fvTimeFromS(s) {
   s = Math.max(-1, Math.min(1, s));
   if (Math.abs(s) < FV_TIME.DETENT) return 0;
   return FV_TIME.RANGE_YR * Math.sinh(FV_TIME.K * s) / Math.sinh(FV_TIME.K);
}
function fvTimeToS(y) {
   var a = Math.abs(y) / FV_TIME.RANGE_YR * Math.sinh(FV_TIME.K), s = Math.log(a + Math.sqrt(a * a + 1)) / FV_TIME.K;
   return Math.max(-1, Math.min(1, y < 0 ? -s : s));
}
// 3 cifras significativas (copia de c3TmRoundYears)
function fvTimeRound(y) {
   var a = Math.abs(y); if (a < 1) return 0;
   var p = Math.pow(10, Math.max(0, Math.floor(Math.log(a) / Math.LN10) - 2));
   return Math.round(y / p) * p;
}
// la lectura: «hoy» · «+12 000 años» · «−830 años» (lang "es" | "en"; espacio fino de millar, signo menos de verdad)
function fvTimeText(y, lang) {
   var es = (lang === "es"), r = fvTimeRound(y), a = Math.abs(r);
   if (a === 0) return es ? "hoy" : "today";
   var s = String(a), o = ""; while (s.length > 3) { o = " " + s.substring(s.length - 3) + o; s = s.substring(0, s.length - 3); }
   return (r < 0 ? "−" : "+") + s + o + (es ? (a === 1 ? " año" : " años") : (a === 1 ? " year" : " years"));
}

// ============================================================================
// (I3, 19-nov-2026) LA REPRODUCCION AUTOMATICA DEL TIEMPO y AETAS CON PROPOSITO (ficha E1-17 de docs/ideas-enganche-19nov.md). PURO.
// ----------------------------------------------------------------------------
// Nino: «El botón que hace mover las estrellas para delante y para atrás debe estar más visible y tiene que tener al lado una flecha play
// para arriba y otra play para abajo que recorra hacia el futuro y hacia el pasado de forma automática y visualmente agradable.»
//
// 1. LA REPRODUCCION (fvTplay*). Un estado { on, dir, phase, years, v } que el reloj de quien pinta avanza con fvTplayStep(st, dt): PixInsight
//    lo llama una vez por fotograma (animacion por fotogramas, nada dentro de un onPaint) y el navegador igual. El tiempo corre UNIFORME en
//    años (las estrellas van en linea recta: su velocidad en pantalla es constante en el crucero), con la velocidad en rampa suave:
//      · arranque: v(t) = v0 + (±V − v0) · suave(t / RAMP_S)  (suave = 3x² − 2x³; tambien al invertir el sentido en marcha);
//      · llegada al tope (±100 000 años): cuando lo que falta D ≤ |v| · RAMP_S / 2 se pasa a la frenada ANALITICA
//        y(τ) = y0 + v0 · Tb · (x − x³ + x⁴/2), x = τ / Tb, Tb = 2 D / |v0|: acaba EXACTAMENTE en el tope con velocidad 0;
//      · pausa (volver a pulsar la misma flecha): la misma frenada con Tb = STOP_S; tocar la palanca la corta en seco (fvTplayHardStop).
//    V = RANGE_YR / (SPAN_S − RAMP_S): de hoy al tope en SPAN_S segundos justos. SPAN_S = 10 (pedido: 8–12 s) MEDIDO en las tres fotos de
//    la prueba (tests/_e1t/fv_e1t_node.js, P5): la estrella que mas corre cruza la pantalla a cientos de px/s y los miembros del cumulo
//    a decenas: se sigue con el ojo sin esperar.
// 2. LAS ESTELAS (fvTrails*). Que estrellas llevan estela de ±100 000 años y por que, calculado UNA vez por escena (scene.time.trails) con
//    lo que Gaia midio y nada mas:
//      · "group"  los miembros de cada cumulo CONFIRMADO de la escena (meta.cluster: la pertenencia que ya calcula CabraShared con el
//                 movimiento propio y la paralaje de Gaia DR3 contra Hunt & Reffert 2023): viajan en bloque -> estelas paralelas y del
//                 mismo largo. Su vector comun es la MEDIANA de los movimientos propios de los miembros;
//      · "cross"  las que mas recorren en la foto y no son de un cumulo (las CROSS_MAX primeras por recorrido en pixeles de la foto, con
//                 su perspectiva y su velocidad radial donde la hay): son las cercanas, que cruzan la foto;
//      · "run"    candidata a fugitiva de un cumulo. Criterio clasico (Blaauw 1961; Tetzlaff et al. 2011 usan 28 km/s): paralaje
//                 compatible con la del cumulo (≤ RUN_NSIG σ, con paralaje/error ≥ RUN_SNR), velocidad relativa en el cielo ≥ RUN_KMS km/s
//                 y TRAZA HACIA ATRAS que pasa por el nucleo (a menos de RUN_IMPACT × radio mediano del cumulo, hace menos de RUN_BACK_YR).
//                 Sin velocidad radial de las dos es solo candidata (una estrella de campo que pasa por alli da lo mismo): c3d = false y
//                 el rotulo lleva «?». Si no hay ninguna, no hay rotulo. APAGADA DE FABRICA (FV_TRAILS.RUN_ON = false): ver la constante.
//    Nada se inventa: sin movimiento propio no hay estela; la distancia supuesta solo afecta a los km/s (que entonces no se dan).
// ES5. Sin PixInsight ni DOM.
// ============================================================================
var FV_TPLAY = { SPAN_S: 10, RAMP_S: 1.5, STOP_S: 0.5, DT_MAX: 0.25 };
var FV_TPLAY_BREAK = "";       // CONTROLES EN ROJO: "nostop" no frena en el tope (se pasa) · "nopause" la pausa no para
function fvTplaySmooth(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
function fvTplayCruise() { return FV_TIME.RANGE_YR / Math.max(0.5, FV_TPLAY.SPAN_S - FV_TPLAY.RAMP_S); }     // años por segundo
function fvTplayNew() { return { on: false, dir: 0, phase: "idle", years: 0, v: 0, t: 0, v0: 0, y0: 0, Tb: 0, lim: 0 }; }
// ¿queda recorrido hacia ese lado? (en el tope la flecha se apaga)
function fvTplayCan(years, dir) { return dir > 0 ? years < FV_TIME.RANGE_YR - 0.5 : years > -FV_TIME.RANGE_YR + 0.5; }
// pulsar una flecha (dir = +1 futuro, −1 pasado) con la escena en `years` -> "start" | "pause" | "none"
function fvTplayPress(st, dir, years) {
   dir = dir > 0 ? 1 : -1;
   if (st.on && st.dir === dir && st.phase !== "stop") {                     // la misma flecha en marcha: pausa (frenada corta)
      if (FV_TPLAY_BREAK === "nopause") return "pause";
      st.phase = "stop"; st.t = 0; st.y0 = st.years; st.v0 = st.v; st.Tb = FV_TPLAY.STOP_S;
      return "pause";
   }
   if (!st.on) { st.years = isFinite(years) ? years : 0; st.v = 0; }
   if (!fvTplayCan(st.years, dir)) { if (!st.on) { st.dir = 0; st.phase = "idle"; } return "none"; }
   st.on = true; st.dir = dir; st.phase = "ramp"; st.t = 0; st.v0 = st.v; st.lim = dir * FV_TIME.RANGE_YR;
   return "start";
}
// cortar en seco (el usuario toca la palanca o la lectura): la escena queda en `years`
function fvTplayHardStop(st, years) { st.on = false; st.dir = 0; st.phase = "idle"; st.v = 0; st.t = 0; if (isFinite(years)) st.years = years; }
// un paso de dt segundos -> el año nuevo (st.on pasa a false al acabar)
function fvTplayStep(st, dt) {
   if (!st.on) return st.years;
   dt = Math.max(0, Math.min(FV_TPLAY.DT_MAX, +dt || 0));
   var R = FV_TIME.RANGE_YR, x;
   if (st.phase === "land" || st.phase === "stop") {
      st.t += dt; x = st.Tb > 0 ? Math.min(1, st.t / st.Tb) : 1;
      st.years = st.y0 + st.v0 * st.Tb * (x - x * x * x + 0.5 * x * x * x * x); st.v = st.v0 * (1 - fvTplaySmooth(x));
      if (st.years > R) st.years = R; if (st.years < -R) st.years = -R;
      if (x >= 1) { if (st.phase === "land") st.years = st.lim; st.on = false; st.dir = 0; st.phase = "idle"; st.v = 0; }
      return st.years;
   }
   st.t += dt; x = Math.min(1, st.t / FV_TPLAY.RAMP_S);
   var v = st.v0 + (st.dir * fvTplayCruise() - st.v0) * fvTplaySmooth(x);
   st.years += 0.5 * (st.v + v) * dt; st.v = v;
   var D = (st.lim - st.years) * st.dir;
   if (FV_TPLAY_BREAK === "nostop") return st.years;
   if (D <= 0) { st.years = st.lim; st.on = false; st.dir = 0; st.phase = "idle"; st.v = 0; }
   else if (v * st.dir > 0 && D <= 0.5 * Math.abs(v) * FV_TPLAY.RAMP_S) { st.phase = "land"; st.t = 0; st.y0 = st.years; st.v0 = v; st.Tb = 2 * D / Math.abs(v); }
   return st.years;
}

var FV_TRAILS = {
   CROSS_MAX: 16,               // estelas de «cruzan la foto» como mucho (maraña en campos densos: E1-17, riesgos)
   CROSS_MIN_FRAC: 0.02,        // y solo si recorren en ±RANGE al menos esta fraccion del lado mayor de la foto
   GROUP_MIN: 5,                // miembros con movimiento propio para que un cumulo cuente como grupo
   GROUP_MAX: 48,               // estelas por cumulo como mucho (los mas brillantes)
   NAME_K: 3, NAME_MIN_AS: 600, // el nombre: el objeto «cluster» de la escena a menos de max(NAME_K × radio mediano, NAME_MIN_AS″) del centro
   // LA FUGITIVA SALE APAGADA DE FABRICA (RUN_ON false; decidido el 20-nov tras mirar Collinder 34): el criterio encuentra bien un sintetico de verdad
   // conocida, pero no distingue una fugitiva de una estrella de campo que pasa por delante del nucleo. En Collinder 34 marco una («salio hace 510 000
   // años a 41 km/s») cuya paralaje (0,34 mas, ventana de 3 σ = de 1,9 a 7 kpc)
   // no dice si esta en el cumulo, y el control de azar (las que PASARAN por el nucleo, tests/_e1t/fv_e1t_node.js R) da 10 casualidades por 1 candidata
   // (docs/encargos-19nov/I3.md §4.4b). Rotular eso como «¿fugitiva?» seria inventar. RUN_ON true lo enciende (y las pruebas).
   RUN_ON: false,
   RUN_KMS: 30, RUN_SNR: 5, RUN_NSIG: 3, RUN_IMPACT: 1, RUN_BACK_YR: 3e6, RUN_MIN_R_AS: 60, RUN_MAX: 2, RUN_RUWE: 1.4,
   RUN_3D_PC: 0.5,              // con velocidad radial de las dos: paso a menos de max(RUN_3D_PC, RUN_IMPACT × radio mediano) pc en 3D
   FADE_YR: 2500,               // las estelas entran al alejarse de hoy (a 0 años la foto se ve limpia)
   KV: 4.740470446              // km/s por (mas/año · kpc) (ESA 1997, A_v)
};
var FV_TRAILS_BREAK = "";        // CONTROLES EN ROJO: "nogroup" ignora los cumulos · "slow" elige las que MENOS se mueven · "norun" sin fugitivas · "future" (control de azar de la fugitiva)
function fvTrailsMedian(a) { if (!a.length) return NaN; var b = a.slice().sort(function(p, q) { return p - q; }), m = b.length >> 1; return (b.length & 1) ? b[m] : 0.5 * (b[m - 1] + b[m]); }
// el pixel de la foto donde se ve la estrella i en el año t (la vista desde la Tierra: fv_scene.js) | null si queda detras
function fvTrailsPix(scene, T, i, t) {
   var S = scene.stars, f = scene.field, X = S.x[i] + T.vx[i] * t, Y = S.y[i] + T.vy[i] * t, Z = S.z[i] + T.vz[i] * t;
   return Z > 0 ? [f.width / 2 + f.F * X / Z, f.height / 2 + f.F * Y / Z] : null;
}
// (F2) la FLECHA de velocidad peculiar de una estrella: donde esta en el año `years` (en pantalla) y hacia donde corre respecto a la Galaxia (vector unitario en pantalla).
// pr = un proyector (fvProjector). La direccion sale de la velocidad peculiar (T.gal), sea cual sea el modo del mando. null si no se ve o no hay motor de la fugitiva
function fvTrailsRunDir(scene, T, pr, i, years) {
   var G = (typeof fvTimeGalPrepare === "function") ? fvTimeGalPrepare(scene) : null; if (!G) return null;
   var S = scene.stars, y = years || 0, x = S.x[i] + T.vx[i] * y, yy = S.y[i] + T.vy[i] * y, z = S.z[i] + T.vz[i] * y, tau = 20000;
   var q0 = pr.project([x, yy, z]), q1 = pr.project([x + G.vx[i] * tau, yy + G.vy[i] * tau, z + G.vz[i] * tau]);
   if (!q0 || !q1) return null;
   var dx = q1[0] - q0[0], dy = q1[1] - q0[1], l = Math.sqrt(dx * dx + dy * dy);
   return (l > 1e-9) ? { q: q0, d: [dx / l, dy / l] } : null;
}
// cuando sale del encuadre (futuro, años) y cuando entro (pasado, años negativos) una estrella que hoy esta dentro; null = no en ±RANGE
function fvTrailsEdgeTimes(scene, T, i) {
   var S = scene.stars, f = scene.field, hw = f.width / 2, hh = f.height / 2, F = f.F, R = FV_TIME.RANGE_YR, out = Infinity, inn = -Infinity;
   var E = [[F, 0, hw], [F, 0, -hw], [0, F, hh], [0, F, -hh]];              // F·X ± (W/2)·Z = 0 y F·Y ± (H/2)·Z = 0
   for (var k = 0; k < 4; ++k) {
      var num = -(E[k][0] * S.x[i] + E[k][1] * S.y[i] + E[k][2] * S.z[i]), den = E[k][0] * T.vx[i] + E[k][1] * T.vy[i] + E[k][2] * T.vz[i];
      if (den === 0) continue;
      var t = num / den; if (t > 0 && t < out) out = t; if (t < 0 && t > inn) inn = t;
   }
   return { out: out <= R ? out : null, inn: inn >= -R ? inn : null };
}
// LAS ESTELAS DE LA ESCENA (una vez; se rehace si cambian las estrellas o un control en rojo) ->
//   { items: [{ i, cls: "cross"|"group"|"run", gi, lenPx, frac, arcmin (en 100 000 años), mu (mas/año), kms | null, tOut, tInn }],
//     groups: [{ ci, name, n, nDrawn, pmRa, pmDec, mu, pa (grados, N por E), sdMu, arcmin, kms | null, plx, ra, dec, r50as, anchor }],
//     runs: [{ i, gi, kms, tAgo, bAs, c3d }], top: indice en items de la que mas recorre | −1, nPm, nCross, nGroup, nRun }
function fvTrailsBuild(scene) {
   var T = fvTimePrepare(scene); if (!T) return null;
   var C0 = FV_TRAILS;
   var runKey = (typeof fvRunList === "function" && FV_RUNAWAY.ON === true && C0.RUN_ON !== true) ? "new" : (C0.RUN_ON === true ? "old" : "none");           // (F2) que criterio de fugitiva rige
   if (T.trails && T.trails.brk === FV_TRAILS_BREAK && T.trails.run === runKey && T.trails.mode === (T.mode || "sun")) return T.trails;
   var S = scene.stars, f = scene.field, n = S.n, R = FV_TIME.RANGE_YR, C = FV_TRAILS, LY = fvTimeLyPerPc(), longPx = Math.max(f.width, f.height), asPx = 206264.806 / f.F;
   var out = { brk: FV_TRAILS_BREAK, run: runKey, mode: T.mode || "sun", items: [], groups: [], runs: [], top: -1, nPm: 0, nCross: 0, nGroup: 0, nRun: 0 }, i, k;
   var cand = [], byCl = {}, clKeys = [];
   // (F2) el movimiento propio con el que se cuentan las estelas: el medido (SOL) o el PECULIAR (GALAXIA); la posicion de cada estrella en las estelas ya viene de T.vx (el modo activo)
   var galP = (T.mode === "gal" && T.gal) ? T.gal : null;
   function pR(j) { return galP ? galP.pmRa[j] : S.meta[j].pmRa; }
   function pD(j) { return galP ? galP.pmDec[j] : S.meta[j].pmDec; }
   for (i = 0; i < n; ++i) {
      if (!S.inFrame[i] || !T.has[i]) continue;
      var m = S.meta[i] || {}, a = fvTrailsPix(scene, T, i, -R), b = fvTrailsPix(scene, T, i, R), mu = Math.sqrt(pR(i) * pR(i) + pD(i) * pD(i));
      var len = (a && b) ? Math.sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1])) : mu * 2 * R / 1000 / asPx;
      var dKpc = S.dEarth[i] / LY / 1000, o = { i: i, cls: "", gi: -1, lenPx: len, frac: len / longPx, arcmin: mu * 1e5 / 1000 / 60, mu: mu, kms: (S.q[i] === 0 && dKpc > 0) ? C.KV * mu * dKpc : null, tOut: null, tInn: null };
      ++out.nPm; cand.push(o);
      var ci = (FV_TRAILS_BREAK !== "nogroup" && m.cluster !== undefined && m.cluster !== null && m.cluster >= 0) ? m.cluster : -1;
      if (ci >= 0) { if (!byCl[ci]) { byCl[ci] = []; clKeys.push(ci); } byCl[ci].push(o); }
   }
   // ---- los grupos: cada cumulo confirmado con miembros suficientes ----
   for (k = 0; k < clKeys.length; ++k) {
      var mem = byCl[clKeys[k]]; if (mem.length < C.GROUP_MIN) continue;
      var pa = [], pd = [], px = [], vec = [0, 0, 0], xs = [], ys = [], j, mm;
      for (j = 0; j < mem.length; ++j) {
         mm = S.meta[mem[j].i]; pa.push(pR(mem[j].i)); pd.push(pD(mem[j].i)); if (mm.plx > 0) px.push(mm.plx);
         var u = fvTimeRaDec(mm.ra, mm.dec); vec[0] += u[0]; vec[1] += u[1]; vec[2] += u[2];
         var p0 = fvTrailsPix(scene, T, mem[j].i, 0); if (p0) { xs.push(p0[0]); ys.push(p0[1]); }
      }
      var gRa = fvTrailsMedian(pa), gDec = fvTrailsMedian(pd), gMu = Math.sqrt(gRa * gRa + gDec * gDec), sky = fvTimeSky(vec[0], vec[1], vec[2]), cxp = fvTrailsMedian(xs), cyp = fvTrailsMedian(ys), dev = [], rr = [];
      for (j = 0; j < mem.length; ++j) { mm = S.meta[mem[j].i]; dev.push(Math.sqrt((pR(mem[j].i) - gRa) * (pR(mem[j].i) - gRa) + (pD(mem[j].i) - gDec) * (pD(mem[j].i) - gDec))); var pj = fvTrailsPix(scene, T, mem[j].i, 0); if (pj) rr.push(Math.sqrt((pj[0] - cxp) * (pj[0] - cxp) + (pj[1] - cyp) * (pj[1] - cyp))); }
      var plxG = px.length ? fvTrailsMedian(px) : NaN, plxDev = []; for (j = 0; j < px.length; ++j) plxDev.push(Math.abs(px[j] - plxG));
      var gi = out.groups.length, G = { ci: clKeys[k], name: "", n: mem.length, nDrawn: 0, pmRa: gRa, pmDec: gDec, mu: gMu, pa: (Math.atan2(gRa, gDec) / FV_TIME.DEG + 360) % 360, sdMu: 1.4826 * fvTrailsMedian(dev),
                                    arcmin: gMu * 1e5 / 1000 / 60, kms: (plxG > 0) ? C.KV * gMu / plxG : null, plx: plxG, plxSd: px.length ? 1.4826 * fvTrailsMedian(plxDev) : NaN, ra: sky.ra, dec: sky.dec,
                                    r50as: fvTrailsMedian(rr) * asPx, cx: cxp, cy: cyp, anchor: -1 };
      // el nombre: el cumulo de catalogo de la escena mas cercano al centro (scene.objects, tipo «cluster»)
      var O = scene.objects || [], bestS = Math.max(C.NAME_K * G.r50as, C.NAME_MIN_AS);
      // (la separacion: en la foto, de la posicion del objeto en el mundo —o.pos, que viaja tambien en el paquete del navegador— al centro del grupo;
      // sin o.pos, de sus coordenadas)
      for (j = 0; j < O.length; ++j) {
         var ob = O[j], sp = NaN; if (!ob || ob.type !== "cluster") continue;
         if (ob.pos && ob.pos.length === 3 && ob.pos[2] > 0) { var ox = f.width / 2 + f.F * ob.pos[0] / ob.pos[2] - cxp, oy = f.height / 2 + f.F * ob.pos[1] / ob.pos[2] - cyp; sp = Math.sqrt(ox * ox + oy * oy) * asPx; }
         else if (isFinite(ob.ra) && isFinite(ob.dec) && ob.ra !== null && ob.dec !== null && ob.ra !== undefined) { var cd = Math.cos(G.dec * FV_TIME.DEG), dra = ((ob.ra - G.ra + 540) % 360 - 180) * cd * 3600, dde = (ob.dec - G.dec) * 3600; sp = Math.sqrt(dra * dra + dde * dde); }
         if (sp < bestS) { bestS = sp; G.name = String(ob.name || ""); }
      }
      mem.sort(function(p, q) { return S.g[p.i] - S.g[q.i]; });
      for (j = 0; j < mem.length; ++j) { mem[j].gi = gi; mem[j].cls = "member"; if (j < C.GROUP_MAX) { mem[j].cls = "group"; ++G.nDrawn; } }
      G.anchor = mem[0].i;
      out.groups.push(G);
   }
   // ---- las candidatas a fugitiva de cada grupo ----
   if (C.RUN_ON === true && FV_TRAILS_BREAK !== "norun") for (var g2 = 0; g2 < out.groups.length; ++g2) {
      var Gq = out.groups[g2]; if (!(Gq.plx > 0)) continue;
      var fut = (FV_TRAILS_BREAK === "future"), sG = Math.max(isFinite(Gq.plxSd) ? Gq.plxSd : 0, 0.03 * Gq.plx), cdg = Math.cos(Gq.dec * FV_TIME.DEG), Rg = Math.max(Gq.r50as, C.RUN_MIN_R_AS), found = [];
      // la velocidad radial comun (mediana de los miembros que la tienen; hacen falta 3)
      var rvs = []; for (i = 0; i < cand.length; ++i) if (cand[i].gi === g2) { var mr = S.meta[cand[i].i]; if (mr.rv !== null && mr.rv !== undefined && isFinite(mr.rv)) rvs.push(mr.rv); }
      var rvG = rvs.length >= 3 ? fvTrailsMedian(rvs) : NaN;
      for (i = 0; i < cand.length; ++i) {
         var c = cand[i]; if (c.gi >= 0) continue;
         var ms = S.meta[c.i];
         if (!(ms.plx > 0) || !(ms.plxErr > 0) || ms.plx / ms.plxErr < C.RUN_SNR) continue;
         if (isFinite(ms.ruwe) && ms.ruwe !== null && ms.ruwe >= C.RUN_RUWE) continue;
         if (Math.abs(ms.plx - Gq.plx) > C.RUN_NSIG * Math.sqrt(ms.plxErr * ms.plxErr + sG * sG)) continue;
         var dmx = ms.pmRa - Gq.pmRa, dmy = ms.pmDec - Gq.pmDec, dm = Math.sqrt(dmx * dmx + dmy * dmy), dv = C.KV * dm / Gq.plx;
         if (!(dv >= C.RUN_KMS)) continue;
         var rx = ((ms.ra - Gq.ra + 540) % 360 - 180) * cdg * 3600, ry = (ms.dec - Gq.dec) * 3600;      // segundos de arco, hoy
         var ts = -(rx * dmx + ry * dmy) / (dm * dm) * 1000;                                           // años (dm en mas/año)
         // (control de azar, FV_TRAILS_BREAK = "future": las que PASARAN por el nucleo en vez de las que pasaron; por simetria, las casualidades son igual de probables)
         if (fut ? !(ts > 0 && ts <= C.RUN_BACK_YR) : !(ts < 0 && ts >= -C.RUN_BACK_YR)) continue;
         var bx = rx + dmx / 1000 * ts, by = ry + dmy / 1000 * ts, bb = Math.sqrt(bx * bx + by * by);
         if (bb > C.RUN_IMPACT * Rg) continue;
         var c3d = false;
         if (!fut && C.RUN_3D !== false && isFinite(rvG) && ms.rv !== null && ms.rv !== undefined && isFinite(ms.rv)) {
            // en 3D (pc y pc/año, ICRS): la estrella contra el centro del grupo, los dos en linea recta
            var s1 = fvTimeState(ms.ra, ms.dec, 1000 / ms.plx, ms.pmRa, ms.pmDec, ms.rv), s0 = fvTimeState(Gq.ra, Gq.dec, 1000 / Gq.plx, Gq.pmRa, Gq.pmDec, rvG);
            var rel = { x: s1.x - s0.x, y: s1.y - s0.y, z: s1.z - s0.z, vx: s1.vx - s0.vx, vy: s1.vy - s0.vy, vz: s1.vz - s0.vz }, ca = fvTimeClosest(rel);
            var r50pc = Gq.r50as / 206264.806 * 1000 / Gq.plx;
            // (solo si la paralaje de la estrella resuelve el fondo del cumulo: error en distancia <= radio mediano; si no, se queda en candidata)
            if (1000 / ms.plx * (ms.plxErr / ms.plx) <= r50pc) {
               if (!(ca.t < 0 && ca.d <= Math.max(C.RUN_3D_PC, C.RUN_IMPACT * r50pc))) continue;       // con las dos velocidades radiales NO pasa por el nucleo: fuera
               c3d = true;
            }
         }
         found.push({ i: c.i, gi: g2, kms: dv, tAgo: fut ? ts : -ts, bAs: bb, c3d: c3d, it: c });
      }
      found.sort(function(p, q) { return (q.c3d ? 1 : 0) - (p.c3d ? 1 : 0) || q.kms - p.kms; });
      for (i = 0; i < found.length && i < C.RUN_MAX; ++i) { found[i].it.cls = "run"; found[i].it.gi = g2; out.runs.push({ i: found[i].i, gi: g2, kms: found[i].kms, tAgo: found[i].tAgo, bAs: found[i].bAs, c3d: found[i].c3d }); }
   }
   // ---- (F2, 20-nov) las candidatas a fugitiva con el criterio de la literatura (src/engine/fv_runaway.js): velocidad PECULIAR (respecto a la Galaxia) con el percentil 5 por encima
   // de 30 km/s, calidad de Gaia y estrella caliente y luminosa. Sustituye al de I3 (de arriba, RUN_ON, apagado): ese no medía si la estrella corre sino si apunta al cumulo.
   // Si no hay ninguna, no hay estela ni rotulo ni entrada en la leyenda (nada se inventa).
   if (runKey === "new" && FV_TRAILS_BREAK !== "norun") {
      var RL = fvRunList(scene), byStar = {}, ri; for (i = 0; i < cand.length; ++i) byStar[cand[i].i] = cand[i];
      for (ri = 0; ri < RL.length; ++ri) {
         var rc = RL[ri], it0 = byStar[rc.i]; if (!it0 || it0.cls !== "") continue;
         it0.cls = "run"; it0.gi = -1;
         out.runs.push({ i: rc.i, gi: -1, kms: rc.vt, tAgo: null, c3d: false, rn: rc, it: it0 });
      }
   }
   // ---- las que cruzan la foto: las que mas recorren y no son de un grupo ----
   var free = []; for (i = 0; i < cand.length; ++i) if (cand[i].gi < 0 && cand[i].cls === "") free.push(cand[i]);
   if (FV_TRAILS_BREAK === "slow") free.sort(function(p, q) { return p.lenPx - q.lenPx; }); else free.sort(function(p, q) { return q.lenPx - p.lenPx; });
   for (i = 0; i < free.length && i < C.CROSS_MAX; ++i) { if (FV_TRAILS_BREAK !== "slow" && free[i].frac < C.CROSS_MIN_FRAC) break; free[i].cls = "cross"; }
   for (i = 0; i < cand.length; ++i) {
      var it = cand[i]; if (it.cls !== "cross" && it.cls !== "group" && it.cls !== "run") continue;
      var et = fvTrailsEdgeTimes(scene, T, it.i); it.tOut = et.out; it.tInn = et.inn;
      if (it.cls === "cross") { ++out.nCross; if (out.top < 0 || it.lenPx > out.items[out.top].lenPx) out.top = out.items.length; }
      else if (it.cls === "group") ++out.nGroup; else ++out.nRun;
      out.items.push(it);
   }
   T.trails = out;
   return out;
}
// la opacidad de las estelas en el año elegido (0 hoy, 1 a partir de FADE_YR)
function fvTrailsAlpha(years) { return fvTplaySmooth(Math.abs(years || 0) / FV_TRAILS.FADE_YR); }
// lo notable, para los rotulos (los textos los pone quien pinta): [{ kind: "cross"|"group"|"run", i (estrella ancla), … }]
function fvTrailsNotes(scene) {
   var Tr = fvTrailsBuild(scene), N = []; if (!Tr) return N;
   if (Tr.top >= 0) { var c = Tr.items[Tr.top]; N.push({ kind: "cross", i: c.i, arcmin: c.arcmin, tOut: c.tOut, kms: c.kms }); }
   for (var g = 0; g < Tr.groups.length; ++g) { var G = Tr.groups[g]; N.push({ kind: "group", i: G.anchor, gi: g, name: G.name, n: G.n, arcmin: G.arcmin, kms: G.kms, sdMu: G.sdMu, mu: G.mu }); }
   for (var r = 0; r < Tr.runs.length; ++r) { var Q = Tr.runs[r]; N.push({ kind: "run", i: Q.i, gi: Q.gi, name: (Q.gi >= 0 && Tr.groups[Q.gi]) ? Tr.groups[Q.gi].name : "", kms: Q.kms, tAgo: Q.tAgo, c3d: Q.c3d, rn: Q.rn || null }); }
   return N;
}
// ---- LOS TEXTOS (los mismos en PixInsight y en el navegador; EN con ES en paralelo) ----
function fvTrailsInt(x) { var s = String(Math.round(Math.abs(x))), o = ""; while (s.length > 3) { o = " " + s.substring(s.length - 3) + o; s = s.substring(0, s.length - 3); } return (x < 0 ? "−" : "") + s + o; }
// un angulo en el cielo, de minutos de arco: «17,7°» · «41′» · «2,3′» · «28″»
function fvTrailsAngle(arcmin, lang) {
   var dec = function(v) { var t = (v >= 10) ? String(Math.round(v)) : v.toFixed(1); return (lang === "es") ? t.replace(".", ",") : t; };
   if (arcmin >= 60) return dec(arcmin / 60) + "°";
   if (arcmin >= 1) return dec(arcmin) + "′";
   return String(Math.max(1, Math.round(arcmin * 60))) + "″";
}
// dos cifras significativas (los años de una traza hacia atras no dan para mas)
function fvTrailsRound2(x) { var a = Math.abs(x); if (!(a >= 1)) return 0; var p = Math.pow(10, Math.floor(Math.log(a) / Math.LN10) - 1); return Math.round(x / p) * p; }
// el rotulo de una nota de fvTrailsNotes
function fvTrailsLabel(nt, lang) {
   var es = (lang === "es"), K = "100 000", ang = (nt.arcmin !== undefined) ? fvTrailsAngle(nt.arcmin, lang) : "";
   if (nt.kind === "cross") return (es ? "La más rápida · " + ang + " en " + K + " años" : "The fastest here · " + ang + " in " + K + " years") +
                                   (nt.tOut ? (es ? " · sale de tu foto en " : " · leaves your photo at ") + fvTimeText(nt.tOut, lang) : "");
   if (nt.kind === "group") return (nt.name ? nt.name : (es ? "Un cúmulo" : "A star cluster")) + " · " + fvTrailsInt(nt.n) + (es ? " estrellas que viajan juntas · " : " stars travelling together · ") + ang + (es ? " en " + K + " años" : " in " + K + " years");
   if (nt.kind === "run" && nt.rn) return fvRunText(nt.rn, "label", lang);                       // (F2) la candidata del criterio de la literatura
   if (nt.kind === "run") {
      var T = fvTrailsInt(fvTrailsRound2(nt.tAgo)), v = String(Math.round(nt.kms));
      return es ? (nt.c3d ? "Fugitiva" : "¿Fugitiva?") + " · salió " + (nt.name ? "de " + nt.name : "del cúmulo") + " hace " + T + " años a " + v + " km/s"
                : (nt.c3d ? "Runaway" : "Runaway?") + " · left " + (nt.name ? nt.name : "the cluster") + " " + T + " years ago at " + v + " km/s";
   }
   return "";
}
// la leyenda de la placa: una entrada por clase PRESENTE -> [{ cls, text }]
function fvTrailsLegend(scene, lang) {
   var Tr = fvTrailsBuild(scene), es = (lang === "es"), out = []; if (!Tr) return out;
   if (Tr.nCross) out.push({ cls: "cross", text: es ? "cruzan tu foto" : "cross your photo" });
   if (Tr.nGroup) out.push({ cls: "group", text: es ? "viajan juntas" : "travel together" });
   if (Tr.nRun) { var r0 = Tr.runs[0] && Tr.runs[0].rn; out.push({ cls: "run", text: r0 ? (r0.highLat ? (es ? "veloz respecto a la Galaxia" : "fast vs the Galaxy") : (es ? "candidata a fugitiva" : "runaway candidate")) : (es ? "¿fugitiva?" : "runaway?") }); }
   return out;
}
// LA ESTELA es el tramo entre HOY (donde esta la estrella en tu foto) y el año elegido: lo que se ha movido desde la foto (hacia el futuro) o lo que
// le faltaba por recorrer para llegar a ella (hacia el pasado). Va viva y se apaga con la distancia en años a la estrella, como la de una barca; el
// resto de la recta de ±100 000 años, tenue y constante. (20-nov, tras mirar el montaje: con «lo anterior al año elegido» como estela, en −100 000
// no quedaba nada vivo y hacia el pasado el mando no contaba nada; asi las dos flechas cuentan lo mismo.)
function fvTrailsInWake(t, years) { return years >= 0 ? (t >= 0 && t <= years) : (t <= 0 && t >= years); }
function fvTrailsSegAlpha(t, years) { return fvTrailsInWake(t, years) ? Math.max(0.34, 0.85 * Math.exp(-Math.abs(years - t) / 45000)) : 0.2; }
