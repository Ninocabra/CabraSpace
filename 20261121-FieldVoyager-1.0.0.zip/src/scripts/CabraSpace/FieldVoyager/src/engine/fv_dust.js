// ============================================================================
// FieldVoyager/src/engine/fv_dust.js — QUITAR EL POLVO: color, Teff y luminosidad VERDADEROS (F4b, 4-nov-2026). PURO.
// ----------------------------------------------------------------------------
// El color de una estrella en la foto (y su BP−RP de Gaia) lleva el ENROJECIMIENTO del polvo que hay entre ella y la Tierra: una F9
// detras de 2 magnitudes de polvo sale roja y «fria» (f2_info_estrella_mas.png: 6 020 K sacados del color enrojecido). Aqui:
//   1. el polvo hasta la estrella: E acumulado del mapa 3D de Edenhofer et al. 2024 (A&A 685, A82), que lee CabraShared/csh_dust.js
//      (perfil por linea de vista; el mapa llega a 1 250 pc = 4 077 a.l.: MAS ALLA no sabe nada y lo que sale es un MINIMO);
//   2. de E a extinciones (mismas conversiones, con su derivacion, que CabraShared/csh_dust.js; no se inventa ninguna):
//        A_V = 2,8·E      Edenhofer et al. 2024 §2 (V = 540 nm; la curva de ZGR23 da R(540) = 2,78)
//        A0  = 2,74·E     A a 550 nm (el A0 de Gaia): 2,8/1,022, A(540)/A(550) con CCM R_V 3,1 (csh_dust.js, 28-oct)
//   3. de A0 a A_G y E(BP−RP): los coeficientes de Gaia de Gaia Collaboration, Babusiaux et al. 2018 (A&A 616, A10; arXiv:1804.09378),
//      ec. 1 y Tabla 1: k_X = c1 + c2·x + c3·x² + c4·x³ + c5·A0 + c6·A0² + c7·x·A0, x = (BP−RP)0 el color INTRINSECO, A_X = k_X·A0
//      (rejilla de Kurucz con la ley de Fitzpatrick & Massa 2007; valida para (BP−RP)0 de −0,06 a 2,5 y A0 < 5: fuera se sujeta y se dice).
//      PROCEDENCIA: los siete coeficientes por banda, copiados de CabraStars/lib/cs_extra.js:26-29 (CS_EXT.K, leidos del articulo el
//      14-oct-2026), y la iteracion de csDeredden (cs_extra.js:39-48), adaptada. La version EDR3 (Fitzpatrick 2019) no esta en ningun
//      sitio del repo (solo en un .zip de la ESA): no se usa.
//   4. Teff verdadera: la del color sin polvo en la secuencia de Mamajek (FV_BPRP_TEFF de fv_scene.js); la de GSP-Phot de Gaia ya viene
//      sin polvo (la ajusta junto con A0) y se respeta.
// Sin mapa (sin red, o estrella fuera de la foto) NO se corrige: el resultado lo dice (ok false) y la ficha pone «sin corregir».
// ES5. Sin PixInsight (node lo ejecuta).
// ============================================================================

var FV_DUST = {
   AV_PER_E: 2.8,           // Edenhofer et al. 2024 §2
   A0_PER_E: 2.74,          // CabraShared/csh_dust.js (2,8·E a 540 nm -> 550 nm)
   R_OUT_PC: 1250,          // el mapa acaba aqui (Edenhofer 2024: «out to 1.25 kpc»)
   TAB_N: 128,              // muestras de la tabla E(d) que lee el pintor (0 … R_OUT)
   // Babusiaux et al. 2018, Tabla 1 (CabraStars/lib/cs_extra.js CS_EXT.K)
   K: { G:  [0.9761, -0.1704, 0.0086, 0.0011, -0.0438, 0.0013, 0.0099],
        BP: [1.1517, -0.0871, -0.0333, 0.0173, -0.0230, 0.0006, 0.0043],
        RP: [0.6104, -0.0170, -0.0026, -0.0017, -0.0078, 0.00005, 0.0006] },
   X_LO: -0.06, X_HI: 2.5, A0_MAX: 5
};
var FV_DUST_BREAK = "";     // control en ROJO de las pruebas: "nocorr" = no se quita nada (el comportamiento de F2)

function fvDustK(band, x, a0) {
   var c = FV_DUST.K[band], X = Math.max(FV_DUST.X_LO, Math.min(FV_DUST.X_HI, x)), A = Math.max(0, Math.min(FV_DUST.A0_MAX, a0));
   return c[0] + c[1] * X + c[2] * X * X + c[3] * X * X * X + c[4] * A + c[5] * A * A + c[6] * X * A;
}
// el color observado de una estrella de color intrinseco c0 detras de A0 (para las pruebas: el camino de ida)
function fvRedden(c0, a0) { return c0 + (fvDustK("BP", c0, a0) - fvDustK("RP", c0, a0)) * a0; }
// quitar A0 a un color observado: los coeficientes dependen del color INTRINSECO, asi que se itera (converge en 3-4 vueltas)
// -> { c0, AG, EBR, clamped }
function fvDeredden(bpRp, a0) {
   if (!isFinite(bpRp) || !(a0 > 0)) return { c0: bpRp, AG: 0, EBR: 0, clamped: false };
   var c0 = bpRp, AG = 0, EBR = 0;
   for (var it = 0; it < 8; ++it) {
      EBR = (fvDustK("BP", c0, a0) - fvDustK("RP", c0, a0)) * a0;
      AG = fvDustK("G", c0, a0) * a0;
      c0 = bpRp - EBR;
   }
   return { c0: c0, AG: AG, EBR: EBR, clamped: (c0 < FV_DUST.X_LO || c0 > FV_DUST.X_HI || a0 > FV_DUST.A0_MAX) };
}
// el BP−RP intrinseco de una enana de temperatura T (la tabla FV_BPRP_TEFF al reves; fuera de la tabla, su borde)
function fvBpRpOfTeff(T) {
   var Tb = FV_BPRP_TEFF;
   if (!(T > 0)) return null;
   if (T >= Tb[0][1]) return Tb[0][0];
   for (var i = 1; i < Tb.length; ++i) if (T >= Tb[i][1]) { var u = (T - Tb[i - 1][1]) / (Tb[i][1] - Tb[i - 1][1]); return Tb[i - 1][0] + u * (Tb[i][0] - Tb[i - 1][0]); }
   return Tb[Tb.length - 1][0];
}

// EL POLVO DE UNA ESTRELLA. bpRp: su BP−RP de Gaia (con polvo); dPc: su distancia; eAt(pc) -> E acumulado del mapa en su linea de vista
// (null = sin mapa); gspTeff: la Teff de GSP-Phot si la hay (ya sin polvo).
// -> { ok, E, av, a0, ag, ebr, bpRp0, teffObs, teff, hot (mas azul que la tabla: Teff es un minimo), beyond (estrella mas alla del
//      mapa: el polvo es un MINIMO), clamped (fuera de la validez de Babusiaux), why }
function fvDustStar(bpRp, dPc, eAt, gspTeff) {
   var o = { ok: false, E: 0, av: 0, a0: 0, ag: 0, ebr: 0, bpRp0: bpRp, teffObs: null, teff: null, hot: false, beyond: false, clamped: false, why: "" };
   o.teffObs = (gspTeff > 0) ? gspTeff : fvTeffFromBpRp(bpRp);
   o.teff = o.teffObs;
   if (typeof eAt !== "function") { o.why = "no-map"; return o; }
   if (!(dPc > 0)) { o.why = "no-distance"; return o; }
   var E = eAt(Math.min(dPc, FV_DUST.R_OUT_PC));
   if (!(E >= 0) || !isFinite(E)) { o.why = "no-map"; return o; }
   o.E = E; o.av = FV_DUST.AV_PER_E * E; o.a0 = FV_DUST.A0_PER_E * E; o.beyond = dPc > FV_DUST.R_OUT_PC; o.ok = true;
   if (FV_DUST_BREAK === "nocorr") { o.av = 0; o.a0 = 0; return o; }
   if (bpRp === null || bpRp === undefined || !isFinite(bpRp)) { o.ag = fvDustK("G", 0.8, o.a0) * o.a0; return o; }
   var r = fvDeredden(bpRp, o.a0);
   o.ag = r.AG; o.ebr = r.EBR; o.bpRp0 = r.c0; o.clamped = r.clamped;
   o.hot = r.c0 < FV_BPRP_TEFF[0][0];
   if (!(gspTeff > 0)) o.teff = fvTeffFromBpRp(r.c0);
   return o;
}

// LA TABLA E(d) de una linea de vista para el pintor: TAB_N+1 muestras de 0 a R_OUT pc
function fvDustTable(eAt) {
   var n = FV_DUST.TAB_N, t = new Float32Array(n + 1);
   for (var k = 0; k <= n; ++k) t[k] = Math.max(0, eAt(FV_DUST.R_OUT_PC * k / n));
   return t;
}
function fvDustTabAt(tab, pc) {
   var n = tab.length - 1, x = pc / FV_DUST.R_OUT_PC * n;
   if (!(x > 0)) return tab[0] * Math.max(0, x);
   if (x >= n) return tab[n];
   var k = Math.floor(x), u = x - k;
   return tab[k] + (tab[k + 1] - tab[k]) * u;
}
// LO QUE QUEDA DE POLVO entre la camara y la estrella (0 … 1): el polvo de su linea de vista que queda DETRAS del punto donde la camara
// cruza esa linea (proyeccion), sobre el total. En casa 1 (todo el polvo delante), junto a la estrella 0. tPc = proyeccion de la camara
// sobre la direccion de la estrella (pc); dPc la distancia de la estrella; eStar = E hasta ella.
function fvDustLeft(tab, tPc, dPc, eStar) {
   if (!(eStar > 1e-6)) return 0;
   var t = Math.max(0, Math.min(tPc, dPc));
   return Math.max(0, Math.min(1, (eStar - fvDustTabAt(tab, Math.min(t, FV_DUST.R_OUT_PC))) / eStar));
}
// mezcla de dos colores 0xRRGGBB (w = 0 -> a, 1 -> b)
function fvMixRgb(a, b, w) {
   var r = Math.round(((a >>> 16) & 255) * (1 - w) + ((b >>> 16) & 255) * w), g = Math.round(((a >>> 8) & 255) * (1 - w) + ((b >>> 8) & 255) * w), bl = Math.round((a & 255) * (1 - w) + (b & 255) * w);
   return ((r << 16) | (g << 8) | bl) >>> 0;
}
