// ============================================================================
// FieldVoyager/src/engine/fv_epoch.js — «LA LUZ QUE VES SALIO…» CON EL ERROR DE LA DISTANCIA (F4b, revision del 4-nov-2026). PURO.
// ----------------------------------------------------------------------------
// La frase de src/science (fvsLightPhrase) da el año exacto y lo compara con una efemeride sin mirar el error de la distancia:
// «unos 6,2 años antes de Carnac» con la distancia a ± 230 años; «6815 a. C., unos 77 años despues de 4500 a. C.»; la misma estrella
// con dos fechas en dos capturas. Aqui:
//   - el año se REDONDEA al orden del error (± 230 años -> a la centena) y se dice el margen;
//   - la efemeride mas cercana se elige igual (tabla FVS_HISTORY de src/science, que no se toca), pero si cae DENTRO del margen la frase
//     es «por la epoca de …» (no se puede decir antes ni despues); fuera, «unos N años antes/despues», con N redondeado al mismo paso
//     y calculado del año sin redondear (la aritmetica la comprueba tests/fv_f4_engine_node.js, E2).
// Mas alla de FVS_DEEP_YEARS (tiempo profundo) o por debajo de 1 año, manda la frase de src/science (ya es aproximada).
// ES5. Sin PixInsight (usa FVS_HISTORY, fvsHistToAstro y fvsAstroToHist de src/science, solo en la llamada).
// ============================================================================

// -> { mode: "sci" } | { mode: "year", yearHist, margin, step, event: { year, approx, en, es }, rel: "near"|"before"|"after", gap, yearAstro }
function fvLightEpochErr(dLy, errLy, obsYear) {
   var deep = (typeof FVS_DEEP_YEARS === "number") ? FVS_DEEP_YEARS : 15000;
   if (!(dLy >= 1) || dLy >= deep || typeof FVS_HISTORY === "undefined") return { mode: "sci" };
   var now = (obsYear > 0) ? obsYear : (new Date()).getFullYear(), yA = now - dLy;
   var mg = Math.max(1, errLy > 0 ? errLy : 0), step = Math.pow(10, Math.floor(Math.log(mg) / Math.LN10));
   var h = fvsAstroToHist(yA), hr = Math.round(h / step) * step;
   if (hr === 0) hr = (h < 0) ? -1 : 1;                                     // no hay año 0 en la cuenta historica
   var mgR = Math.max(step, Math.round(mg / step) * step);
   var H = FVS_HISTORY.years, best = null, bd = 1e30;
   for (var i = 0; i < H.length; ++i) {
      var ey = fvsHistToAstro(H[i][0]);
      if (ey > now - 1) continue;
      var d = Math.abs(ey - yA);
      if (d < bd) { bd = d; best = H[i]; }
   }
   var o = { mode: "year", yearHist: hr, yearAstro: yA, margin: mgR, step: step };
   if (!best) return o;
   var eya = fvsHistToAstro(best[0]);
   o.event = { year: best[0], approx: best[1], en: best[2], es: best[3] };
   o.rel = (bd <= mg) ? "near" : (yA < eya ? "before" : "after");
   o.gap = Math.max(step, Math.round(bd / step) * step);
   return o;
}
