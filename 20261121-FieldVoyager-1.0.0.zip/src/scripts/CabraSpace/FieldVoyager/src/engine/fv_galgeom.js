// ============================================================================
// FieldVoyager/src/engine/fv_galgeom.js — LA GEOMETRIA DE LA GALAXIA PROPIA (encargo GG, 9-nov-2026). PURO (sin PixInsight).
// ----------------------------------------------------------------------------
// Nino, al ver la columna NUEVA de GP: «debe ser homogenea y sin sesgo de medicion», «donde faltan datos, la mejor extrapolacion posible»,
// «le falta simetria, parece a medio hacer», «familiar pero cientificamente correcta, con extrapolaciones con sustento matematico».
// Diseño D + B + C de docs/investigacion-galaxia-color-real-y-homogenea.md (§2.4, §3.2, §7 pasos 3–9):
//   B · ENTRADA HOMOGENEA: nubes de CO solo con M > M_min(14 kpc) (completas hasta 14 kpc; gp_extract.py --gg) y una confianza que NO cuenta
//       trazadores: la del dato es la COMPLETITUD de la muestra homogenea (1 hasta 14 kpc) fuera de las mascaras cinematicas de Wenger.
//   C · PDF CINEMATICA: cada objeto con distancia cinematica es una mezcla cercano/lejano a lo largo de su linea de vision con
//       σ_d = σ_v / |dv/dd| (columnas dA, sA, dB, sB, pA, msk del extracto ampliado).
//   D · AJUSTE DIRECTO fuera de linea (tests/_galaxy/gg/gg_fit.js, node): verosimilitud de Poisson inhomogeneo con la seleccion medida
//       (Bovy et al. 2015), priores = tabla 2 de Reid et al. 2019 con sus errores (es la informacion de los maseres: no se cuentan dos veces),
//       datos = HII y nubes. Salida: unos 50 numeros + covarianza en src/engine/fv_galgeom_fit.js (NUESTROS). Aqui solo se usan.
// GEOMETRIA (O3):
//   (1) BRAZOS COMPLETOS: cada brazo mayor sigue mas alla de su tramo medido mezclando su continuacion con la de su GEMELO girado 180°
//       (pares m = 2: Scutum-Centaurus ↔ Perseo, Norma ↔ Sagitario-Carina; el de 3 kpc ↔ el de 3 kpc lejano, Dame & Thaddeus 2008, ApJ 683,
//       L143: los dos brazos de 3 kpc son simetricos en longitud, velocidad, anchura, altura y masa):
//         ln R_k(β) = w_e(Δβ)·[continuacion lineal] + (1 − w_e(Δβ))·ln R_k*(β ∓ 180°),  w_e = exp(−Δβ/Λ)
//       Λ y la vuelta de la inclinacion a la media (REVERT) los fija la validacion dejando tramos fuera (tests/_galaxy/gg/gg_loo.js).
//   (1b) PARES SIMETRICOS (PAIRS, por defecto con GG): la mezcla de (1) no es simetrica fuera de los tramos medidos (la continuacion de A
//       tiende a la de B girada, pero la de B tiende a la de A una vuelta mas fuera: con Λ = 20° la simetria a escala de brazo cayo de 0,80 a
//       0,56, medido). En su lugar, UNA espiral comun S por par en las β del maestro: el tramo medido del maestro (y el del Exterior, su
//       cadena), el de la pareja GIRADO 180° (en la vuelta que da una espiral con R decreciente y huecos con la inclinacion mas cercana a la
//       media) y, entre tramos, interpolacion de Hermite en ln R con la inclinacion medida en cada punta; fuera de los extremos, (1) sin
//       gemelo (vuelta a la media con Λ). Maestro A(β) = S(β), pareja B(β) = S(β + 180° − 360°·n): simetricos POR CONSTRUCCION y cada
//       tramo medido exacto. La luz y la anchura de cada muestra son las del tramo medido de que procede (interpoladas en los huecos), asi que
//       tambien la luz es simetrica (salvo el lado lejano al FAR). La confianza c y σ, en cambio, son de cada miembro: la distancia a SUS
//       tramos medidos (lo girado de la pareja es una hipotesis de simetria, no una medida).
//       MEDIDO (gg_loo.js, 9-nov): predice MAL los tramos quitados (χ²/n 6,4, como la recta), porque el Hermite hereda la inclinacion ruidosa
//       de la punta y los pares de Reid no son giros exactos el uno del otro. Queda apagada (PAIRS: false) como registro.
//   (1c) PESOS SIMETRICOS (SYMW, la que se usa): fuera de su tramo medido, cada miembro del par es la media de SU continuacion y la del
//       gemelo (en la vuelta coherente del par, fvGgPairOff), pesadas por la cercania de cada una a su dato:
//         ln R_A(β) = [e^(−dA/Λ)·ln R_A,propio(β) + e^(−dB/Λ)·ln R_B,propio(β − off)] / [e^(−dA/Λ) + e^(−dB/Λ)]
//       con dA la distancia (°) de β a los tramos medidos de A y dB la de β − off a los de B. La expresion es la misma vista desde B, asi que
//       A(β) = B(β − off) en todas partes salvo dentro de los tramos medidos (que mandan): simetrica por construccion. La (1) original,
//       w_e·propio + (1 − w_e)·gemelo, no lo es: cada brazo acaba en la continuacion LIBRE del otro, y las dos no son giro la una de la otra.
//       MEDIDO (gg_loo.js): sola, predice peor que la (1) los tramos quitados (χ²/n 3,0 con Λ = 10°, 3,9 con 20°, frente a 1,53): el dato
//       prefiere irse PRONTO al gemelo. Por eso se usa HIBRIDA: hasta SYM_D0 = 55° de su dato (todo lo que la validacion puede medir) manda
//       la (1) tal cual (χ²/n 1,53 intacto: ningun maser quitado esta mas alla de 55°) y de SYM_D0 a SYM_D1 = 125° pasa suave a la simetrica.
//       Lejos de todo dato (lado lejano) los dos miembros son giro el uno del otro; cerca, lo que diga el dato. ELECCION: 55° y 125°.
//       La (1) usa su vuelta de siempre (la mas cercana en la punta); la simetrica solo entra si esa vuelta es la del par (si no, salto de
//       una vuelta entera en la transicion): en el producto lo es en los cuatro brazos mayores (comprobado con gg_arms_dump.js).
//   (2) INCERTIDUMBRE de la posicion: σ_lnR(Δβ)² = σ0² + w_e²·(Δβ·sec²ψ·σ_ψ)² + (1 − w_e)²·(Δβ·sec²ψ·σ_sym)²; u = σ_pos/(σ_pos + w_brazo).
//       La linea dorada es u = 0,5 (donde la posicion de los brazos deja de estar medida).
//   (3) DISCO VIEJO m = 2: Σ_viejo·[1 + A2·cos(2·(β + ln R / tan ψ2) − φ2)], A2 = 0,138 ((1 + A2)/(1 − A2) = 1,32, contraste en K) y
//       ψ2 = 15,6° de Drimmel & Spergel 2001 (ApJ 556, 181, tabla 2); la fase φ2 anclada a Scutum-Centaurus y Perseo (ajuste).
//   LADO LEJANO al 70 % del contraste (decision 3 de la investigacion). POLVO en el borde interior DENTRO de la corrotacion (R_CR = 8,51 kpc,
//   Dias et al. 2019, solo resumen) y pasando al exterior fuera (choque de la onda de densidad, Roberts 1969). Nudos HII AGUAS ABAJO del polvo.
//   EL DATO AJUSTA EL MODELO y se pinta como PUNTOS (maseres y HII) mas una MODULACION FINA (la densidad a posteriori de las nubes, con el modelo
//   ajustado como prior) donde u es baja, con c′ ≤ 0,5. La FORMA la da el modelo ajustado.
// Bandera FV_GAL_GG.ON (ENCENDIDA por defecto desde el 10-nov-2026, decision de Nino: GF9 con la fosa D1 es la galaxia que se ve; con ella apagada no se ejecuta nada de esto: la galaxia de datos de GP sale bit a bit).
// ES5.
// ============================================================================

var FV_GAL_GG = {
   ON: true,                 // la bandera (necesita FV_GAL_DATA.ON y el extracto AMPLIADO en FV_GAL_DATA.SRC)
   LAMBDA: 40,                // Λ (°) de la formula (1): se sustituye por el de la validacion (FV_GAL_GG_FIT.loo) si existe
   REVERT: true,              // la inclinacion de la continuacion vuelve a la media de la Galaxia con el mismo Λ (gg_loo.js lo decide)
   PSI_BAR: 0,                // la media (°); 0 = la media de la tabla 2 de Reid ponderada por el tramo medido (fvGgPsiBar)
   FAR: 1.0,                  // el lado lejano lleva el 100 % del contraste de los brazos (encargo GF, 9-nov: decision del coordinador por el criterio de Nino
                              // «homogenea y sin sesgo de medicion»; la incertidumbre ya la dicen la linea dorada y el rotulo, no hace falta oscurecer.
                              // Con 0,70 (decision 3 de la investigacion) fallaban A1, la pendiente y (a′); con 1,0 pasan: gg_metrics.js)
   EXT_MAX: 420, R_MIN: 2.2, R_MAX: 19.5,
   TWIN: { norma: "sgrcar", sgrcar: "norma", scucen: "perseus", perseus: "scucen", "3kpc": "3kpcF", "3kpcF": "3kpc" },
   FULL: { norma: 1, scucen: 1, sgrcar: 1, perseus: 1 },
   CHAIN: { norma: { id: "outer", off: -360 } },        // el Exterior = Norma una vuelta mas fuera (ver fvGgChainOf)
   PAIRS: false,              // (1b) espiral comun por par con Hermite entre tramos (fvGgPairTable): REFUTADA por gg_loo.js (χ²/n 6,4 frente a 1,5)
   SYMW: true,                // (1c) cerca del dato, la (1) validada; LEJOS (Δβ > SYM_D0), la mezcla SIMETRICA por cercania (fvGgSymW)
   SYM_D0: 55, SYM_D1: 125,   // (°) la transicion: hasta 55° (lo que valida gg_loo.js) manda la (1); desde 125°, la simetrica
   PAIR: { scucen: "perseus", norma: "sgrcar" },        // maestro: pareja (el maestro lleva la cadena del Exterior)
   A2: 0.138, PSI2: 15.6, M2_R0: 2.6, M2_RW: 1.8,      // m = 2 viejo (Drimmel & Spergel 2001); arranque suave fuera de la barra (ELECCION)
   // (encargo GF, 9-nov) EL BRILLO DE LOS BRAZOS: la ELECCION de Nino mirando el montaje, en UNA constante con nombre.
   //   "A" = medido en la Via Lactea: el m = 2 de arriba (A2 = 0,138, Drimmel & Spergel 2001; 0,13 mag de brazo/interbrazo con el color real).
   //   "B" = dos brazos viejos con contraste de Sb: la luz VIEJA sigue SOLO a los dos brazos mayores (Escudo-Centauro y Perseo: los de estrellas viejas
   //         de la Via Lactea, GLIMPSE, Benjamin 2005/2008; Drimmel 2000) con la amplitud OLD_KAPPA que lleva esos dos a ≈ 1 mag (lo tipico de una
   //         Sb/Sbc vista desde fuera, Elmegreen+ 2011, leido en resumen); el m = 2 sinusoidal no se usa. Los brazos menores, solo gas, jovenes y polvo.
   //   Cada una lleva su propio presupuesto de luz en FV_GAL_COLOR.BUDGET_GG (el color integrado de cara en R/G 1,03 · B/G 0,94 en las dos).
   OLD_MODE: "B",             // (10-nov-2026) por defecto "B": es la opcion que usan GF2…GF9 (fvGf2On la exige); "A" solo vale con GF2 apagado
   OLD_ARMS: ["scucen", "perseus"], OLD_KAPPA: 4.6, OLD_SIG: 0.5, OLD_YW: 0.5,   // B: ids de los brazos viejos, exceso de luz vieja en el eje (1 + κ) y σ (kpc) del perfil gaussiano
   //   OLD_YW: el exceso de los brazos viejos NO tiene el color de la poblacion vieja pura (Elliptical): lleva el color MEDIO del disco = mezcla de vieja y joven con este peso
   //   (0,13 daria B/G ≈ 0,94 del disco, pero los brazos salian aun mas rojos que el interbrazo, Δ ln(B/G) −0,039 con κ = 5 por el polvo del brazo; 0,5 los deja en la ventana: −0,009). Con la Elliptical pura los brazos salian MAS ROJOS que el interbrazo (Δ ln(B/G) −0,047 frente a +0,05 ± 0,07 de Elmegreen+ 2011:
   //   en una Sb/Sbc el contraste en B no es menor que en 3,6 µm); medido con gc_fit.js --gg=B. ELECCION.
   //   OLD_KAPPA = 4,6: da ≈ 1,0 mag de brillo brazo/interbrazo en los dos brazos (medido, gc_fit.js --gg=B --kappa=…)
   RCR: 8.51, RCR_W: 2.0,     // corotacion (Dias et al. 2019) y el ancho de la transicion del lado del polvo (ELECCION)
   HII_DOWN: 0.20,            // kpc: nudos HII aguas abajo (ELECCION dentro de 0,1–0,3 kpc; desfase de edad 1–4 Myr, Tamburro 2008)
   CMAX: 0.5,                 // c′ ≤ 0,5: el dato modula, no dibuja
   LVL: true,                 // el dato NO cambia el NIVEL de la luz por encima de LVL_KPC: solo la reparte (fvGgMixMid2). Sin esto, la
   LVL_KPC: 1.5,              // mascara de Wenger se veia como una CUÑA desde el Sol (dentro, el modelo; fuera, el dato mas tenue): (g) 0,39
   LVL_RHO: 0.25,             // donde el dato tiene menos de 1/4 de la luz del modelo no hay nada que repartir: c′ se apaga en proporcion
   MASK_RAMP: 10,             // (°) en la MEZCLA, c′ entra en 10° desde el borde de las mascaras de Wenger, no en 3°: junto a ellas |dv/dd| → 0 y
                              // la distancia cinematica ya es mala; con 3° el borde se veia como una linea recta desde el Sol (ELECCION)
   SUN_FADE: [0.5, 2.5],      // (GF) kpc: c′ entra con la distancia al Sol (0 a 0,5 kpc, 1 a 2,5). Sin esto, la mascara de Wenger (|l| < 15°) dejaba junto al Sol una
                              // muesca en V sin los carriles de polvo del dato, mas clara que su entorno (visto en el montaje de GG, medido en gf: cociente final/modelo)
   U_HALF: 0.5, U_LO: 0.30, U_HI: 0.70,                 // la linea dorada y el tramo de u en que el dato deja de modular
   SIG_PSI: 3.0, SIG_SYM: 5.0, SIG0: 0.03,             // (2): σ_ψ (°), σ_sym (°), σ_lnR del tramo medido (se sustituyen por los de la validacion)
   W_REID: [0.336, 0.036],    // anchura de los brazos de gas (kpc): 336 + 36·(R − 8,15) pc, Reid et al. 2019 §3
   D_COMPLETE: 14,            // las nubes del corte en masa estan completas hasta aqui (gp_extract.py --gg)
   PT_KIN: 0.35,              // kpc: cada punto se pinta con alfa min(1, PT_KIN/σ_d); los de la mascara de Wenger y los tangentes, no
   PT_GAIN: 0.75,             // los puntos, algo mas tenues que en GP (son marcas; con su brillo de GP desequilibraban la mitad cercana)
   YSAT: 2.5,
   FLOC: 1.0,                 // amplitud del grano flocular de hoy (0,30 + 1,45·fBm a 0,9 kpc) en el mapa del modelo: 1 = el de hoy
   NL: 160                    // rejilla de λ y de u (250 pc sobre ±20 kpc)
};
var FV_GAL_GG_TABS = null;

// ============================================================================
// (encargo GF2, 9-nov) LA GALAXIA FINAL CORREGIDA tras la revision visual de GF (docs/encargos-9nov/GF/revision-visual-GF.md, 14 defectos).
// Subinterruptor FV_GAL_GF2.ON (ENCENDIDO por defecto desde el 10-nov-2026). Solo actua con las tres banderas encendidas (FV_GAL_COLOR.ON + FV_GAL_DATA.ON +
// FV_GAL_GG.ON); apagado, o con cualquiera de ellas apagada, nada de esto se ejecuta y GF sale bit a bit. Lo que cambia:
//   · PANTALLA: estiramiento que CONSERVA LOS COCIENTES DE COLOR (como ArcsinhStretch de PixInsight: el mismo factor en R, G y B, con la curva
//     de hoy aplicada a la intensidad media) mas una SATURACION DE PANTALLA documentada (SAT, alrededor de la media: no cambia el tono). El tono
//     lo sigue fijando la calibracion (blanco = espiral media de SPCC): la saturacion solo lo hace visible. Lo dice el tooltip.
//   · BULBO Y BARRA: el bulbo en caja con dos lobulos (cacahuete) y su escala de luz BULGE_K; la BARRA LARGA pasa al mapa de cara como barra
//     plana de semilongitud ~5 kpc a 28° (BHG16 §4.3: 5,0 ± 0,2 kpc, 28°–33°), con LINEAS DE POLVO RECTAS en sus bordes de ataque (Athanassoula
//     1992, MNRAS 259, 345: rectas, desplazadas hacia el lado que avanza).
//   · BRAZOS: los viejos de la opcion B nacen en los extremos de la barra (Benjamin 2008; pie de la ilustracion de Hurt 2008); la luz joven y el
//     polvo de los brazos siguen al disco exponencial (sin «diana» en las afueras); nudos HII compactos y brillantes (menos, mas brillantes).
//   · COSTURA de la continuacion de los brazos: peso C¹ (1 + x)·e^(−x) en vez de e^(−x) (el codo de 45° de Sgr–Car en β = 97°, R = 5,9 kpc era el
//     salto de pendiente del peso en la punta medida; ver fvGgWe).
//   · PUNTOS medidos fuera de la vista principal (sesgo de seleccion): solo en «SOLO DATOS», que ya existe.
// ============================================================================
var FV_GAL_GF2 = {
   ON: true,
   SAT: 2.0,                  // saturacion de pantalla (ELECCION; medido con gf2_hue.py frente a SAT 1: croma media ×1,99, tono medio mostrado −3° a −3,5°; que el procesado habitual use ×1,5–3 es NO VERIFICADO)
   TONE: { B: 2.5, X1: 7 },   // la curva de pantalla de GF2: T(x) = asinh(B·x)/asinh(B·X1), x = I·EXPO (como ArcsinhStretch: el nucleo no se quema a blanco y conserva su color)
   BULGE_K: 2.6,              // escala de la luz del bulbo (todas sus gausianas): fraccion de luz bulbo+barra en G en [0,15; 0,35] (BHG16 §4.2.4 y §4.3, ver gf2_metrics.py)
   // bulbo (gausianas triaxiales, kpc; u0 = desplazamiento a lo largo de la barra): caja de BHG16 §4.2.1 (σ = 2h con h 0,70 : 0,44 : 0,18) + dos lobulos
   // (cacahuete/X de canto, Wegg y Gerhard 2013: ELECCION de forma) + el nucleo de hoy. La barra larga va al mapa (BAR).
   BULGE: [ { sx: 1.40, sy: 0.88, sz: 0.36, a: 0.55, ang: 27 },
            { sx: 0.70, sy: 0.60, sz: 0.75, a: 0.25, ang: 27, u0: 1.0 },
            { sx: 0.70, sy: 0.60, sz: 0.75, a: 0.25, ang: 27, u0: -1.0 },
            { sx: 0.28, sy: 0.28, sz: 0.22, a: 1.10, ang: 27 } ],
   // la barra larga en el mapa de cara: A·exp(−(|u|/L)^N)·exp(−v²/2W²) (perfil plano con extremo marcado, como las barras de las SB), luz vieja
   BAR: { A: 0.55, L: 5.3, N: 6, W: 0.9, ANG: 28 },          // L, ANG: BHG16 §4.3; W (anchura en el plano) y A: ELECCION (A fija la fraccion de luz)
   // las lineas de polvo de la barra: v = signo(u)·(V0 + |u|·tan TH) (hacia el lado que avanza), σ W, τ TAU; entran en |u| U0–U1 y acaban en el extremo
   LANE: { V0: 0.35, TH: 5, W: 0.11, TAU: 1.1, U0: 0.6, U1: 1.3 },
   DESERT: { R0: 4.3, R1: 5.3, MIN: 0.25, D0: 4.4, D1: 5.6, DMIN: 0.10 },   // D0–D1, DMIN: lo mismo para el POLVO de los brazos (si no, sus carriles cortaban los extremos de la barra como un anillo oscuro: medido, A2 caia a 0,15 en R = 4 kpc)            // dentro de la barra, la luz joven y el polvo de los brazos x (MIN … 1): el «desierto» de formacion estelar que barre una barra (James y Percival 2016, NO VERIFICADO el numero)
   SWEEP: { D: 0.6, R0: 4.8, RW: 1.6 },               // la barra se hace con el disco interior: el disco liso dentro de R0 + RW/2 baja hasta ×(1 − D) (ELECCION; su luz pasa a la barra)
   ARM_SH: 0.85,              // el carril de polvo de los brazos a ARM_SH·σ del eje (GG: 0,45·σ, encima de la luz del brazo: lo enrojecia, B/G 1,10 -> 0,99 medido); en las espirales el carril va en el borde interior y la luz joven fuera (ELECCION)
   RIDGE_FLOC: 1.0,           // el grano flocular (el de la luz joven, media 1) tambien sobre el exceso de los dos brazos mayores (ELECCION: sin el, tubos lisos)
   RIDGE_YW: 1.0,             // el exceso de luz de los dos brazos mayores (opcion B) con el color de la poblacion JOVEN en esta proporcion (en optico los brazos son mas azules que el interbrazo, Elmegreen+ 2011); GG usa OLD_YW
   OLD_R0: 5.1,               // kpc: la luz vieja de los brazos (opcion B) entra de OLD_R0 − 0,5 a OLD_R0 + 0,5 (los extremos de la barra)
   ENV_R: 4.5,                // kpc: la luz joven de los brazos ∝ e^(−(max(R, ENV_R) − R0)/HR_OLD) (el disco); su polvo, con escala ENV_HD (la del disco de polvo liso)
   ENV_HD: 5.0,
   HII: { N: 0.35, R0: 0.022, R1: 0.018, AMP: 3.5, KMIN: 0.05 },   // nudos HII: fraccion del numero, radio (kpc) R0 + R1·azar, brillo ×AMP (ELECCION: compactos y visibles con la misma luz total ~0,3); KMIN: dentro del desierto de la barra (DESERT.R0–R1) los nudos x KMIN … 1 (visto en el fotograma: habia nudos rosas dentro del anillo de 3 kpc)
   SEAM_K: 0.6,               // peso C¹ de la costura: x = Δβ / (SEAM_K·Λ). ELECCION medida (gf2_seam.js, gg_loo.js --gf2): 0,5 deja un giro de 5,9° en 1°; 0,6, 4,3° con el cambio de posicion en 0,91 σ_pos y χ²/n de la validacion 1,57 (e^(−Δβ/Λ): 1,53); 0,7, 3,9° pero 0,98 σ_pos
   PTS: false                 // los puntos medidos en la vista principal (no: sesgo de seleccion; estan en «SOLO DATOS»)
};
// la geometria de GF2 (la costura) con GG encendida (y el color, si el modulo esta cargado); el resto de GF2, ademas con el color real.
// Solo con la opcion B (OLD_MODE "B"): la opcion A queda como en GF (lo pide el encargo; su presupuesto de luz no esta ajustado para GF2)
function fvGf2Geo() { return !!(FV_GAL_GF2.ON && fvGgOn() && FV_GAL_GG.OLD_MODE === "B" && (typeof FV_GAL_COLOR === "undefined" || FV_GAL_COLOR.ON)); }
function fvGf2On() { return !!(FV_GAL_GF2.ON && fvGgOn() && FV_GAL_GG.OLD_MODE === "B" && typeof FV_GAL_COLOR !== "undefined" && FV_GAL_COLOR.ON); }
// el peso de la continuacion propia frente a la del gemelo a Δβ = db de la punta medida: e^(−db/Λ) (GG) o, con GF2, C¹: (1 + x)·e^(−x)
function fvGgWe(db, lam) { if (!fvGf2Geo()) return Math.exp(-db / lam); var x = db / (FV_GAL_GF2.SEAM_K * lam); return (1 + x) * Math.exp(-x); }
function fvGf2Key() { if (!fvGf2On()) return ""; var F = FV_GAL_GF2; return JSON.stringify(["gf2", F.BULGE_K, F.BULGE, F.BAR, F.LANE, F.DESERT, F.SWEEP, F.RIDGE_YW, F.RIDGE_FLOC, F.ARM_SH, F.OLD_R0, F.ENV_R, F.ENV_HD, F.HII, F.SEAM_K, F.PTS]) + fvGf3Key(); }   // (GF3) "" apagado
function fvGf2Sweep(R) { var W = FV_GAL_GF2.SWEEP; return 1 - W.D * (1 - fvGal3Smooth((R - W.R0) / W.RW + 0.5)); }
// la barra del mapa en (X, Y): [brillo (unidades del disco viejo), τ de sus lineas de polvo]. Perfil A·exp(−(|u|/L)^N): plano y con extremo marcado
function fvGf2Bar(X, Y) {
   var F = FV_GAL_GF2, B = F.BAR, Ln = F.LANE, R = Math.sqrt(X * X + Y * Y);
   if (FV_GAL_GF4.ON && FV_GAL_GF4.BAR && fvGf4On()) B = FV_GAL_GF4.BAR;   // (GF4) el extremo de la barra, mas neto (acaba en el gancho)
   if (R > B.L * 1.6) return [0, 0];
   var d = (fvGal3Beta(X, Y) - B.ANG) * Math.PI / 180, u = R * Math.cos(d), v = R * Math.sin(d), au = Math.abs(u), q = au / B.L, qn = Math.pow(q, B.N);
   var s = B.A * Math.exp(-qn) * Math.exp(-0.5 * v * v / (B.W * B.W));
   var vl = (u >= 0 ? 1 : -1) * (Ln.V0 + au * Math.tan(Ln.TH * Math.PI / 180)), dv = v - vl;
   var tau = Ln.TAU * Math.exp(-0.5 * dv * dv / (Ln.W * Ln.W)) * fvGal3Smooth((au - Ln.U0) / (Ln.U1 - Ln.U0)) * Math.exp(-qn);
   return [s, tau];
}
// la informacion de la barra para las pruebas (gf2_pi.js, gf2_metrics.py)
function fvGf2BarInfo() { return fvGf2On() ? { L: FV_GAL_GF2.BAR.L, ang: FV_GAL_GF2.BAR.ANG, w: FV_GAL_GF2.BAR.W } : null; }
// el estiramiento de pantalla de GF2 (null si GF2 no actua): tabla en coma flotante de la misma curva de hoy, (1 − e^(−x))^(1/γ)
var FV_GF2_TONE = { N: 8192, XMAX: 7, tab: null, key: "" };
function fvAsinh(x) { return Math.log(x + Math.sqrt(x * x + 1)); }
function fvGf2Tone() {
   if (!fvGf2On()) return null;
   if (fvGf3On()) return fvGf3ToneTab();                                   // (GF3) hombro y tope suave (no se quema el centro)
   var TT = FV_GF2_TONE, C = FV_GAL_GF2.TONE, key = C.B + "|" + C.X1 + "|" + TT.N;
   if (!TT.tab || TT.key !== key) { var n = TT.N, tb = new Float32Array(n + 2), d = fvAsinh(C.B * C.X1); TT.XMAX = C.X1; for (var i = 0; i <= n + 1; ++i) tb[i] = Math.min(1, fvAsinh(C.B * i * C.X1 / n) / d); TT.tab = tb; TT.key = key; }
   return TT;
}
// del bufer lineal a 0xffRRGGBB conservando los cocientes R:G:B (factor comun T(I)/I, I = media de los tres) y con la saturacion SAT alrededor de
// la media; fuera de [0, 1] se comprime hacia la media (mismo tono), nunca se recorta por canal
function fvGf2ToneRun(buf, px, n, e, TT) {
   if (TT.gf3) return fvGf3ToneRun(buf, px, n, e, TT);                    // (GF3)
   var tb = TT.tab, sc = e * TT.N / TT.XMAX, top = TT.N, S = FV_GAL_GF2.SAT, j3 = 0;
   for (var j = 0; j < n; ++j, j3 += 3) {
      var r = buf[j3], g = buf[j3 + 1], b = buf[j3 + 2]; if (r < 0) r = 0; if (g < 0) g = 0; if (b < 0) b = 0;
      var I = (r + g + b) * 0.3333333333;
      if (!(I > 0)) { px[j] = 0xff000000; continue; }
      var xi = I * sc; if (xi > top) xi = top; var i0 = xi | 0, T = tb[i0] + (tb[i0 + 1] - tb[i0]) * (xi - i0), k = S * T / I, T1 = T * (1 - S);
      var cr = T1 + r * k, cg = T1 + g * k, cb = T1 + b * k;            // T + S·(c·T/I − T)
      var mn = cr < cg ? cr : cg; if (cb < mn) mn = cb; var mx = cr > cg ? cr : cg; if (cb > mx) mx = cb;
      if (mn < 0 || mx > 1) {
         var f = 1; if (mn < 0) f = T / (T - mn); if (mx > 1) { var f2 = T >= 1 ? 0 : (1 - T) / (mx - T); if (f2 < f) f = f2; }
         cr = T + f * (cr - T); cg = T + f * (cg - T); cb = T + f * (cb - T);
      }
      var R8 = (255 * cr + 0.5) | 0, G8 = (255 * cg + 0.5) | 0, B8 = (255 * cb + 0.5) | 0;
      if (R8 > 255) R8 = 255; else if (R8 < 0) R8 = 0; if (G8 > 255) G8 = 255; else if (G8 < 0) G8 = 0; if (B8 > 255) B8 = 255; else if (B8 < 0) B8 = 0;
      px[j] = (0xff000000 | (R8 << 16) | (G8 << 8) | B8) >>> 0;
   }
}

// ============================================================================
// (encargo GF3, 10-nov) LA GALAXIA GF2 CORREGIDA tras su revision visual adversaria (docs/encargos-9nov/GF/revision-visual-GF2.md, 12 defectos).
// Subinterruptor FV_GAL_GF3.ON (ENCENDIDO por defecto desde el 10-nov-2026). Solo actua ENCIMA de GF2 encendido (las cuatro banderas de GF2 y la opcion B); apagado, nada de esto
// se ejecuta y GF2 sale bit a bit. Lo que cambia (cada causa, MEDIDA antes de tocar; ver docs/encargos-9nov/GF3-galaxia.md):
//   · CARRILES DE LA BARRA curvos (LANE): salen de dentro de la barra (no del bulbo), van por el borde de ataque y se funden con el carril del brazo que
//     nace en ese extremo (Athanassoula 1992, MNRAS 259, 345: carriles desplazados al lado que avanza, curvos, que enlazan con los brazos; NGC 1300).
//     Anchura y profundidad cambian a lo largo. Antes: dos rayas rectas de τ y anchura constantes que cruzaban el anillo (la «X»).
//   · ANILLO DE POLVO abierto (MINOR): el «anillo» de 5,5 kpc era el tramo casi circular de Sagitario-Carina (ψ = 1,0° por encima del codo, tabla 2 de Reid
//     et al. 2019) mas su gemelo simetrico (Norma girado 180°): polvo sin luz (el presupuesto B2 dejo la luz joven del disco en su tope inferior, 0,01).
//     El polvo y la luz de los brazos MENORES siguen su angulo de paso: los tramos casi circulares (|ψ| < PSI0–PSI1) llevan menos. NO cambia su POSICION.
//   · DESIERTO DE LA BARRA sin resto (DESERT_FLOOR): los arcos concentricos tenues del bulbo eran los brazos menores casi circulares (los dos de 3 kpc,
//     Norma por debajo de su codo) que GF2 dejaba al 25 % de luz y al 10 % de polvo dentro de la barra (medido: con el resto a 0 desaparecen).
//   · LUZ DE LOS BRAZOS MENORES (ML): el Brazo Local (Espolon de Orion, Reid et al. 2019: β_codo 9°, R_codo 8,26 kpc, ψ 11,4°, anchura 0,31 kpc) y los tramos
//     con angulo de paso de Sagitario-Carina y Norma(-Exterior) llevan una cresta de luz joven mas debil que la de los mayores. La luz joven TOTAL de las
//     crestas se conserva (κ de los mayores baja en proporcion): el color integrado calibrado no se mueve (se mide).
//   · NUDOS HII sobre los brazos luminosos (HII): sembrados con el peso de la luz que se pinta (antes, con el de todos los brazos, tambien los invisibles),
//     con un brillo que cae la mitad de deprisa que el de su brazo y de 50–85 pc (antes 22–40: 4 px). Son de MUESTRA (sintéticos), no de catalogo.
//   · NUBES ESTELARES (CLOUDS): grumos de estrellas jovenes a lo largo de los brazos luminosos (detalle de menos de 2 px).
//     La luz de nudos y nubes sale de las crestas, canal a canal (fvGgTexStep): el color integrado no se mueve por ellos.
//   · PANTALLA (TONE, VIB): hombro suave por encima de TK y tope TCAP (el centro no se quema: antes la curva se cortaba en 1 y la compresion de gama ponia
//     R = 255 en todo el bulbo calido) y saturacion «vibrance»: la de ×2 de GF2 solo en los colores poco saturados (bulbo, brazos) y menos en los muy
//     saturados (el borde rojizo del polvo: S de entrada 0,48 -> 0,61–0,77 con ×2); tope de saturacion de salida S_OUT.
//   · DE CANTO (VOL): capa de polvo del rayo mas gruesa y menos opaca, disco de polvo liso mas corto, mas pasos por rayo y algo mas de brillo de canto
//     (ver VOL). Causas medidas: el carril descentrado era el alabeo (apagado: 18 -> 0,1 px en el canto ×3); las rayas horizontales eran los carriles de los
//     brazos vistos cada uno a su profundidad en una capa de polvo de 70–100 pc (refutado: el alabeo al texel mas cercano y el aliasing del mapa de polvo).
// ============================================================================
var FV_GAL_GF3 = {
   ON: true,
   // (1) carriles: P0 en (U_IN, V_IN) del marco de la barra (kpc, v hacia el lado que avanza) -> union J con el carril de polvo del brazo donde este esta a
   //     V_J del eje (0: donde cruza el eje, en la punta de la barra; con 0,62 la union hacia un codo de 90°, visto en el fotograma) -> el carril del brazo
   //     hasta R_END (donde su propio polvo ya esta entero: DESERT.D1 de GF2). τ TAU con rampa de entrada RAMP (kpc de recorrido) y rizado NOISE (escala NP
   //     kpc); anchura σ W_IN -> W_OUT (rizado WN). K0, K1: tangentes de Hermite en P0 y J (× la cuerda). ELECCION todo, medido (gf3_metrics.py (1)).
   LANE: { U_IN: 1.5, V_IN: 0.18, V_J: 0.0, TAU: 1.0, RAMP: 1.2, NOISE: 0.6, NP: 0.4, W_IN: 0.065, W_OUT: 0.15, WN: 0.5, K0: 0.8, K1: 0.35, R_END: 5.7, ST: 0.02 },
   // (2) brazos menores: polvo × D y × [FLOOR + (1 − FLOOR)·suave((|ψ| − PSI0)/(PSI1 − PSI0))·suave(Δβ_punta/ENDW)] (ψ local de su tabla; Δβ_punta, grados a
   //     la punta de la tabla: sin el, la luz nueva de los menores acababa en un corte recto radial, visto en el fotograma). ψ, el medio en ±DB grados (con la
   //     diferencia de ±0,5°, el codo de Sgr-Car, 17,1° -> 1,0°, cortaba su polvo y su luz en una recta radial, visto en el fotograma). ELECCION
   MINOR: { D: 0.55, PSI0: 2.5, PSI1: 7.5, FLOOR: 0.10, ENDW: 25, DB: 12 },
   DESERT_FLOOR: 0,           // (10) dentro de la barra (DESERT de GF2), luz joven, polvo y nudos de los brazos x DESERT_FLOOR … 1 (GF2: 0,25 · 0,10 · 0,05)
   // (7) cresta de luz de los brazos menores (fraccion del κ de los mayores; con el mismo peso de angulo de paso) y su σ (kpc). La luz total de las crestas
   //     se conserva: a los mayores les queda k3 = 0,81 (medido). ELECCION
   ML: { local: 0.42, sgrcar: 0.30, norma: 0.26 }, ML_SIG: 0.36,
   // (5) nudos HII: fraccion del numero de hoy, radio R0 + R1·azar (kpc), brillo ×AMP·e^(−(max(R, ENV_R) − R0)/(HK·h_R)) (HK = 2: caen la mitad de deprisa
   //     que la luz del brazo, para que se vean en las afueras). ELECCION, medido (gf3_metrics.py (5))
   HII: { N: 0.4, R0: 0.050, R1: 0.035, AMP: 6.0, HK: 2 },
   // (8) nubes estelares: N grumos, PER estrellas por grumo, dispersion SIG (kpc), brillo AMP. ELECCION, medido (gf3_metrics.py (8))
   CLOUDS: { N: 900, PER: 7, SIG: 0.05, AMP: 1.0, R0: 0.025, R1: 0.02 },
   // (3)(4) pantalla: T(x) = asinh(B·x)/asinh(B·X1) de GF2 SIN tope (tabla hasta XMAX); por encima de TK, hombro T = TK + (1 − TK)·ln(1 + A·y)/A,
   //     y = (T − TK)/(1 − TK); por encima de TC0, tope suave en TCAP (tanh). Saturacion: S de GF2 para s0 <= S_LO, baja a 1 en s0 >= S_HI (s0 = saturacion
   //     del color lineal de entrada), y a 1 tambien en las luces (T de H0 a H1); tope de saturacion de salida S_OUT. ELECCION, medido (gf3_metrics.py (3)(4))
   TONE: { TK: 0.45, A: 0.65, TC0: 0.90, TCAP: 0.95, XMAX: 48, N: 16384 },
   VIB: { S_LO: 0.24, S_HI: 0.46, H0: 0.70, H1: 0.92, S_OUT: 0.56 },
   // (6) de canto, sustituyen a los de FV_GAL3_VOL en el rayo por la capa: polvo del mapa ×DUST (1,0), escala de altura del polvo HZD (0,10 kpc; 0,07 dejaba
   //     rayas: «dash» 0,39; 0,12: 0,22), disco liso de τ TAUF (0,5) y escala HRD (5 kpc; Drimmel y Spergel 2001 dan 3,3 kpc para el polvo, tabla 1, segun la
   //     investigacion GR: NO VERIFICADO aqui) cortado en RC0 ± RCW (14 ± 5), pasos NMAX (48: ruido de pixel 1,7 L* en el carril; 96: 1,1) y brillo de canto
   //     KMIN (0,20: el disco de canto salia a L* 41 frente a 50 de GF-B). ELECCION todo, medido con gf3_metrics.py (6).
   //     KB: el bulbo sube de canto en la misma proporcion que el disco con KMIN (1 = igual): solo con KMIN 0,33 el bulbo de canto se quedaba bajo
   //     (gf2_metrics.py (k1): semialtura centro/disco 2,16 con GF2 -> 1,81; con KB 1, 2,03, medido en node). 0 = el bulbo de siempre.
   VOL: { DUST: 0.55, HZD: 0.12, TAUF: 0.25, HRD: 3.2, RC0: 9.5, RCW: 3, NMAX: 96, KMIN: 0.33, KB: 1 },
   // (7) el punto (β) del rotulo de un brazo cuando el de siempre cae donde ese brazo no se ve con GF3 (Sgr-Car en β −40: contraste eje − interbrazo −0,4 L*;
   //     en β −15, +6,6 L*, medido con gf3_metrics.py sobre el fotograma de PixInsight). ELECCION
   LAB: { sgrcar: -15 }
};
function fvGf3LabBeta(a) { if (typeof FV_GAL_GF6 !== "undefined" && FV_GAL_GF6.LAB && FV_GAL_GF6.LAB[a.id] && fvGf6On()) return FV_GAL_GF6.LAB[a.id].b;   // (GF6)
   if (typeof FV_GAL_GF5 !== "undefined" && FV_GAL_GF5.LAB && FV_GAL_GF5.LAB[a.id] && fvGf5On()) return FV_GAL_GF5.LAB[a.id].b;   // (GF5)
   if (typeof FV_GAL_GF4 !== "undefined" && FV_GAL_GF4.ON && fvGf4On() && FV_GAL_GF4.LAB[a.id]) return FV_GAL_GF4.LAB[a.id].b;   // (GF4) (10)
   return (fvGf3On() && FV_GAL_GF3.LAB[a.id] !== undefined) ? FV_GAL_GF3.LAB[a.id] : a.lb; }
// (GF4) (10) cuanto se aparta el rotulo de un brazo hacia fuera de su eje (kpc): 0,6 (GF2, en el interbrazo) o el de FV_GAL_GF4.LAB (0 = sobre la cresta)
function fvGf4LabOff(id) { if (typeof FV_GAL_GF6 !== "undefined" && FV_GAL_GF6.LAB && FV_GAL_GF6.LAB[id] && fvGf6On()) return FV_GAL_GF6.LAB[id].off;   // (GF6)
   if (typeof FV_GAL_GF5 !== "undefined" && FV_GAL_GF5.LAB && FV_GAL_GF5.LAB[id] && fvGf5On()) return FV_GAL_GF5.LAB[id].off;   // (GF5)
   return (typeof FV_GAL_GF4 !== "undefined" && FV_GAL_GF4.ON && fvGf4On() && FV_GAL_GF4.LAB[id]) ? FV_GAL_GF4.LAB[id].off : 0.6; }
function fvGf3On() { return !!(FV_GAL_GF3.ON && fvGf2On()); }
function fvGf3Key() { if (!fvGf3On()) return ""; var F = FV_GAL_GF3; return JSON.stringify(["gf3", F.LANE, F.MINOR, F.DESERT_FLOOR, F.ML, F.ML_SIG, F.HII, F.CLOUDS, F.VOL]) + fvGf4Key(); }   // (GF4) "" apagado
// ruido de valor 1D en [0, 1] con semilla (para la profundidad y la anchura a lo largo de los carriles)
function fvGf3N1(x, s) { var i = Math.floor(x), f = x - i; f = f * f * (3 - 2 * f); var a = fvGal3H(i, s, 3, 911), b = fvGal3H(i + 1, s, 3, 911); return a + (b - a) * f; }
// el radio del carril de polvo de un brazo en β (el mismo que pinta el bucle polar: R − ARM_SH·σ·lado) o null
function fvGf3DustR(T, bb) {
   var r = fvGgAt(T, bb); if (!r) return null; var GG = FV_GAL_GG, s = fvGal3Sigma(fvGgArmShape(T, r), r[0]), side = 1 - 2 * fvGal3Smooth((r[0] - GG.RCR + 0.5 * GG.RCR_W) / GG.RCR_W);
   return r[0] - FV_GAL_GF2.ARM_SH * s * side;
}
// el peso de angulo de paso de un brazo en β: suave((|ψ| − PSI0)/(PSI1 − PSI0)), ψ local de la tabla (ln R cada 0,5°)
function fvGf3PitchW(T, bb) {
   var M = FV_GAL_GF3.MINOR, b0 = Math.max(T.b0, bb - M.DB), b1 = Math.min(T.b1, bb + M.DB), a = fvGgAt(T, b0), b = fvGgAt(T, b1); if (!a || !b || !(b1 > b0)) return 0;   // ψ medio en ±DB (en las puntas, de un lado)
   var psi = Math.abs(Math.atan((Math.log(a[0]) - Math.log(b[0])) / ((b1 - b0) * Math.PI / 180))) * 180 / Math.PI;
   return fvGal3Smooth((psi - M.PSI0) / (M.PSI1 - M.PSI0)) * fvGf3EndW(T, bb);   // y la punta de la tabla, sin corte recto
}
function fvGf3EndW(T, bb) { return fvGal3Smooth(Math.min(bb - T.b0, T.b1 - bb) / FV_GAL_GF3.MINOR.ENDW); }
// (1) EL MAPA DE τ DE LOS CARRILES DE LA BARRA (N×N sobre ±H). Por cada mitad de la barra: el brazo viejo cuyo carril de polvo cruza el eje de la barra junto a
// su extremo; la union J donde ese carril esta a V_J del eje por el lado que avanza; Hermite de P0 a J (tangente de salida a lo largo de la barra, de llegada
// la del carril del brazo hacia fuera) y despues el carril del brazo hasta R_END, apagandose a la vez que se enciende su polvo propio (DESERT.D0–D1).
// Cada muestra (cada ST kpc) suma una gausiana de linea normalizada: τ·exp(−d²/2w²) a lo largo del tubo. Devuelve { tau, curves } (curves: para las pruebas).
function fvGf3LaneMap(tabs, N, H) {
   var F = FV_GAL_GF3.LANE, B = FV_GAL_GF2.BAR, DS = FV_GAL_GF2.DESERT, D2R = Math.PI / 180, px = 2 * H / N, out = new Float32Array(N * N), curves = [], oldIds = FV_GAL_GG.OLD_ARMS, h, q, kk;
   function xy(R, bb) { var b = (FV_GAL3_BREAK === "beta" ? -bb : bb) * D2R; return [-R * Math.cos(b), R * Math.sin(b)]; }
   for (h = 1; h >= -1; h -= 2) {
      var bE = B.ANG + (h < 0 ? 180 : 0), best = null;
      for (q = 0; q < tabs.length; ++q) { if (oldIds.indexOf(tabs[q].a.id) < 0) continue;
         for (kk = -2; kk <= 1; ++kk) { var Rd0 = fvGf3DustR(tabs[q], bE + 360 * kk); if (Rd0 === null || Rd0 < 3.0 || Rd0 > 5.8) continue; var sc = Math.abs(Rd0 - 0.85 * B.L); if (!best || sc < best.sc) best = { sc: sc, T: tabs[q], off: 360 * kk }; } }
      if (!best) continue;
      var T = best.T, o = best.off, bJ = null, bb, Rd;
      for (bb = bE + o; bb <= bE + o + 60; bb += 0.25) { Rd = fvGf3DustR(T, bb); if (Rd === null || Rd < 2.0) break; if (Rd * Math.sin((bb - o - bE) * D2R) >= F.V_J) { bJ = bb; break; } }
      if (bJ === null) continue;
      // el tramo C: el carril del brazo desde J hacia fuera (β decreciente) hasta R_END
      var C = [];
      for (bb = bJ; bb >= bJ - 120; bb -= 0.25) { Rd = fvGf3DustR(T, bb); if (Rd === null) break; C.push([xy(Rd, bb), Rd]); if (Rd >= F.R_END) break; }
      if (C.length < 3) continue;
      var J = C[0][0], J2 = C[1][0], tJ = [J2[0] - J[0], J2[1] - J[1]], lj = Math.sqrt(tJ[0] * tJ[0] + tJ[1] * tJ[1]); tJ = [tJ[0] / lj, tJ[1] / lj];
      var b0 = bE + Math.atan2(F.V_IN, F.U_IN) / D2R, P0 = xy(Math.sqrt(F.U_IN * F.U_IN + F.V_IN * F.V_IN), b0);
      var eb = (FV_GAL3_BREAK === "beta" ? -bE : bE) * D2R, eu = [-Math.cos(eb), Math.sin(eb)], ev = [Math.sin(eb), Math.cos(eb)], sv = FV_GAL3_BREAK === "beta" ? -1 : 1;
      var cl = Math.sqrt((J[0] - P0[0]) * (J[0] - P0[0]) + (J[1] - P0[1]) * (J[1] - P0[1])), T0 = [(eu[0] + 0.10 * sv * ev[0]) * F.K0 * cl, (eu[1] + 0.10 * sv * ev[1]) * F.K0 * cl], T1 = [tJ[0] * F.K1 * cl, tJ[1] * F.K1 * cl];
      // la curva: Hermite (A) + tramo C, con su recorrido s
      var P = [], nA = 400, t, sAcc = 0, prev = null, sJ = 0;
      for (var i = 0; i <= nA; ++i) {
         t = i / nA; var t2 = t * t, t3 = t2 * t, h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
         var p = [h00 * P0[0] + h10 * T0[0] + h01 * J[0] + h11 * T1[0], h00 * P0[1] + h10 * T0[1] + h01 * J[1] + h11 * T1[1]];
         if (prev) sAcc += Math.sqrt((p[0] - prev[0]) * (p[0] - prev[0]) + (p[1] - prev[1]) * (p[1] - prev[1])); P.push([p[0], p[1], sAcc, 0, -1]); prev = p;
      }
      sJ = sAcc;
      for (i = 1; i < C.length; ++i) { var pc = C[i][0]; sAcc += Math.sqrt((pc[0] - prev[0]) * (pc[0] - prev[0]) + (pc[1] - prev[1]) * (pc[1] - prev[1])); P.push([pc[0], pc[1], sAcc, 1, C[i][1]]); prev = pc; }
      // remuestreo cada ST y el tubo
      var sd = 17 + (h > 0 ? 0 : 5), k = 0, pts = [];
      for (var s = 0; s <= sAcc; s += F.ST) {
         while (k < P.length - 2 && P[k + 1][2] < s) ++k;
         var a0 = P[k], a1 = P[k + 1], f = (s - a0[2]) / Math.max(1e-9, a1[2] - a0[2]), X = a0[0] + (a1[0] - a0[0]) * f, Y = a0[1] + (a1[1] - a0[1]) * f;
         var tau = F.TAU * fvGal3Smooth(s / F.RAMP) * Math.max(0.25, 1 + F.NOISE * (2 * fvGf3N1(s / F.NP, sd) - 1));
         if (a1[3] > 0) { var Rq = a0[4] > 0 ? a0[4] + (a1[4] - a0[4]) * f : a1[4]; tau *= 1 - fvGal3Smooth((Rq - DS.D0) / (DS.D1 - DS.D0)); }
         var w = (F.W_IN + (F.W_OUT - F.W_IN) * fvGal3Smooth(Math.min(1, s / Math.max(1e-6, sJ)))) * (1 + F.WN * (2 * fvGf3N1(s / F.NP + 7.3, sd + 2) - 1));
         if (w < 0.06) w = 0.06;
         pts.push([X, Y, tau, w]);
         if (!(tau > 1e-4)) continue;
         var qn = tau * F.ST / (Math.sqrt(2 * Math.PI) * w), ci = (X + H) / px - 0.5, cj = (Y + H) / px - 0.5, rad = Math.ceil(3 * w / px), iw = 0.5 / (w * w);
         for (var jj = Math.max(0, Math.floor(cj - rad)); jj <= Math.min(N - 1, Math.ceil(cj + rad)); ++jj)
            for (var ii = Math.max(0, Math.floor(ci - rad)); ii <= Math.min(N - 1, Math.ceil(ci + rad)); ++ii) { var dx = (ii - ci) * px, dy = (jj - cj) * px; out[jj * N + ii] += qn * Math.exp(-(dx * dx + dy * dy) * iw); }
      }
      curves.push({ h: h, arm: T.a.id, sJ: sJ, s: sAcc, pts: pts });
   }
   return { tau: out, curves: curves };
}
// la informacion de GF3 para las pruebas (gf3_pi.js, gf3_node.js): la luz de brazo de cada brazo (para la mascara de «brazos luminosos») y las curvas de los carriles
function fvGf3Info() {
   if (!fvGf3On()) return null; var t = fvGgTables(), F = FV_GAL_GF3, lum = {};
   var g4 = fvGf4On();                                                 // (GF4) la luz de los menores con su peso promediado y el Brazo Local en su tramo
   for (var q = 0; q < t.length; ++q) { var T = t[q], id = T.a.id, base = FV_GAL_GG.OLD_ARMS.indexOf(id) >= 0 ? 1 : ((g4 && id === "local") ? FV_GAL_GF4.LOCAL.ML : (F.ML[id] || 0)), arr = [];
      for (var k = 0; k < T.n; k += 2) { var bb = T.b0 + k * T.st; arr.push(+(base * (base < 1 ? (g4 ? fvGf4PitchW(T, bb) : fvGf3PitchW(T, bb)) : 1)).toFixed(3)); } lum[id] = arr; }
   return { lum: lum, lanes: (FV_GAL3_MIX && FV_GAL3_MIX.gf3lanes) ? FV_GAL3_MIX.gf3lanes.map(function(c) { return { h: c.h, arm: c.arm, sJ: c.sJ, s: c.s }; }) : null };
}
// (3)(4) LA PANTALLA DE GF3: la curva de GF2 sin tope + hombro + tope suave, en una tabla (coma flotante) sobre x ∈ [0, XMAX]
var FV_GF3_TONE = { tab: null, key: "", N: 0, XMAX: 0 };
function fvGf3ToneTab() {
   var TT = FV_GF3_TONE, C = FV_GAL_GF2.TONE, E = FV_GAL_GF3.TONE, key = [C.B, C.X1, E.TK, E.A, E.TC0, E.TCAP, E.XMAX, E.N].join("|");
   if (TT.tab && TT.key === key) return TT;
   var n = E.N, tb = new Float32Array(n + 2), d = fvAsinh(C.B * C.X1);
   for (var i = 0; i <= n + 1; ++i) {
      var T = fvAsinh(C.B * i * E.XMAX / n) / d;
      if (T > E.TK) { var y = (T - E.TK) / (1 - E.TK); T = E.TK + (1 - E.TK) * Math.log(1 + E.A * y) / E.A; }
      if (T > E.TC0) T = E.TC0 + (E.TCAP - E.TC0) * Math.tanh((T - E.TC0) / (E.TCAP - E.TC0));
      tb[i] = T;
   }
   TT.tab = tb; TT.key = key; TT.N = n; TT.XMAX = E.XMAX; TT.gf3 = true;
   return TT;
}
// del bufer lineal a 0xffRRGGBB: el mismo factor comun T/I de GF2 (conserva los cocientes antes de la saturacion) con la curva de GF3, saturacion
// «vibrance» y tope de saturacion de salida; fuera de [0, 1], la compresion hacia la media de GF2
function fvGf3ToneRun(buf, px, n, e, TT) {
   var tb = TT.tab, sc = e * TT.N / TT.XMAX, top = TT.N, S = FV_GAL_GF2.SAT, V = (FV_GAL_GF5.ON && FV_GAL_GF5.VIB && fvGf5On()) ? FV_GAL_GF5.VIB : FV_GAL_GF3.VIB, j3 = 0, iV = 1 / (V.S_HI - V.S_LO), iH = 1 / (V.H1 - V.H0), SO = V.S_OUT;   // (GF5) su saturacion
   var T6 = (FV_GAL_GF6.ON && fvGf6On()) ? FV_GAL_GF6.TONE : null, K6 = T6 ? T6.K : 2, D6 = T6 ? T6.TOP - T6.K : 0;   // (GF6) hombro del canal mayor
   for (var j = 0; j < n; ++j, j3 += 3) {
      var r = buf[j3], g = buf[j3 + 1], b = buf[j3 + 2]; if (r < 0) r = 0; if (g < 0) g = 0; if (b < 0) b = 0;
      var I = (r + g + b) * 0.3333333333;
      if (!(I > 0)) { px[j] = 0xff000000; continue; }
      var xi = I * sc; if (xi > top) xi = top; var i0 = xi | 0, T = tb[i0] + (tb[i0 + 1] - tb[i0]) * (xi - i0);
      var mx0 = r > g ? r : g; if (b > mx0) mx0 = b; var mn0 = r < g ? r : g; if (b < mn0) mn0 = b; var s0 = (mx0 - mn0) / mx0;
      var wv = (s0 - V.S_LO) * iV; wv = wv <= 0 ? 0 : (wv >= 1 ? 1 : wv * wv * (3 - 2 * wv));
      var wh = (V.HB1 > 0 && b > r) ? (T - V.HB0) / (V.HB1 - V.HB0) : (T - V.H0) * iH; wh = wh <= 0 ? 0 : (wh >= 1 ? 1 : wh * wh * (3 - 2 * wh));   // (GF5) las luces azules con su propio umbral (HB0–HB1)
      var Se = 1 + (S - 1) * (1 - wv) * (1 - wh), k = Se * T / I, T1 = T * (1 - Se);
      var cr = T1 + r * k, cg = T1 + g * k, cb = T1 + b * k;
      var mn = cr < cg ? cr : cg; if (cb < mn) mn = cb; var mx = cr > cg ? cr : cg; if (cb > mx) mx = cb;
      if (mx > 0 && (mx - mn) > SO * mx) { var fS = SO * T / ((mx - mn) - SO * (mx - T)); if (fS < 1 && fS > 0) { cr = T + fS * (cr - T); cg = T + fS * (cg - T); cb = T + fS * (cb - T); mn = T + fS * (mn - T); mx = T + fS * (mx - T); } }
      if (T6 && mx > K6 && mx > T) {   // (GF6) (4) el canal mayor entra en un hombro suave hacia TOP (< 1: nunca 255), acercando los tres a T (mismo tono)
         var m6 = K6 + D6 * Math.tanh((mx - K6) / D6); if (m6 < T) m6 = T; var f6 = (m6 - T) / (mx - T); cr = T + f6 * (cr - T); cg = T + f6 * (cg - T); cb = T + f6 * (cb - T); mn = T + f6 * (mn - T); mx = m6; }
      if (mn < 0 || mx > 1) {
         var f = 1; if (mn < 0) f = T / (T - mn); if (mx > 1) { var f2 = T >= 1 ? 0 : (1 - T) / (mx - T); if (f2 < f) f = f2; }
         cr = T + f * (cr - T); cg = T + f * (cg - T); cb = T + f * (cb - T);
      }
      var R8 = (255 * cr + 0.5) | 0, G8 = (255 * cg + 0.5) | 0, B8 = (255 * cb + 0.5) | 0;
      if (R8 > 255) R8 = 255; else if (R8 < 0) R8 = 0; if (G8 > 255) G8 = 255; else if (G8 < 0) G8 = 0; if (B8 > 255) B8 = 255; else if (B8 < 0) B8 = 0;
      px[j] = (0xff000000 | (R8 << 16) | (G8 << 8) | B8) >>> 0;
   }
}

// ============================================================================
// (encargo GF4, 10-nov) LA GALAXIA GF3 CORREGIDA tras su revision visual adversaria (docs/encargos-9nov/GF/revision-visual-GF3.md).
// Subinterruptor FV_GAL_GF4.ON (ENCENDIDO por defecto desde el 10-nov-2026). Solo actua ENCIMA de GF3 encendido; apagado, nada de esto se ejecuta y GF3 sale bit a bit.
// Lo que cambia (cada causa MEDIDA antes de tocar; ver docs/encargos-9nov/GF4-galaxia.md):
//   · CARRILES DE LA BARRA EN GANCHO (LANE): una sola curva que nace cerca del extremo interior de la barra, va por el borde de ataque combada (concava
//     hacia el eje), rodea el extremo de la barra por fuera (no lo corta: la barra se ve de ~5 kpc, Wegg et al. 2015) y entra TANGENTE en el carril del
//     brazo viejo que nace alli, con la misma τ que el carril del brazo en la union (Athanassoula 1992; NGC 1300). En la union el carril del brazo y el de
//     la barra se reparten la τ (suman 1 sobre el mismo camino): sin hueco ni codo. Antes (GF3): trazos rectos de 1,5 kpc, hueco de 0,3 kpc y codo de ~70°.
//   · BRAZOS CON AZUL (K3, COMP): los mayores conservan entera su cresta de luz joven (κ) y la luz de las crestas de los menores y la de nudos y nubes sale
//     del DISCO VIEJO LISO, canal a canal (antes salia de las crestas: k3 = 0,81 y fq; medido, era la causa del gris). El color integrado no se mueve.
//   · NUDOS HII (HII): el tono magenta sale de la fisica (lineas del caso B con las curvas de la camara y el blanco de espiral media: h 331° ya en
//     lineal, medido con gf4_hii_hue.js): se queda, con menos croma (C: mezcla hacia su gris) y solo donde el brazo se ve (fondo del mapa >= BG).
//   · NUCLEO (BULGE): el componente nuclear mas compacto y mas alto, la caja y los lobulos mas tenues; la luz que el bulbo pierde vuelve al disco liso
//     (el color integrado no cambia): pico sin quemar.
//   · POLVO (DUST): la τ de cara se satura suave (τ/(1 + τ/TMAX)): los carriles quedan pardos oscuros, no negros; de canto el rayo sigue con la τ entera.
//   · DE CANTO, BRAZO LOCAL, PUNTAS DE LOS MENORES, ROTULO de Sgr-Car: ver cada bloque.
// ============================================================================
var FV_GAL_GF4 = {
   ON: true,
   // (1)(9) el gancho, en el marco de la barra de cada mitad (u a lo largo hacia ese extremo, v hacia el lado que avanza; kpc): nace en (U_IN, V_IN) con
   //     pendiente S0, pasa por (U_M, V_M) paralelo al eje, cruza el eje en U_X con rumbo ψ_X hacia el lado que se queda atras y entra en el carril del brazo
   //     donde este llega a R_J (tangente). Tramos de Hermite con tangentes K × cuerda. τ = la del carril del brazo en la union × [G0 … 1] (rampa de entrada
   //     RAMP kpc); anchura W_IN -> la del carril del brazo. Pasada la union, el carril del brazo se enciende en DJ grados mientras el gancho se apaga.
   //     ELECCION todo, medido con gf4_metrics.py (1) y (9).
   LANE: { U_IN: 1.6, V_IN: 0.22, S0: 0.12, U_M: 3.0, V_M: 0.75, U_X: 5.35, PSI_X: 14, R_J: 5.2, DJ: 25, K: 1.0, G0: 0.45, RAMP: 0.7, W_IN: 0.07, ST: 0.02, NZ: 0.45, NP: 0.35 },
   // (3) la cresta de los mayores × K3 (GF3: 0,81; 1 = la de GF2). ELECCION, medido (b* de la cresta de cara / recorte, gf4_metrics.py (3), con el bulbo de
   //     GF4): 1 -> −4,6 / −6,4; 1,06 -> −4,8 / −6,9; 1,08 -> −5,1 / −7,0; 1,10 -> −5,3 / −7,2 pero las rayas de canto (6d de gf3_metrics.py) 0,251 > 0,25
   K3: 1.08,
   COMP: true,                // (3) la luz anadida (crestas de los menores, nudos, nubes) sale del disco viejo liso, canal a canal
   // (3) el disco cede luz con peso 1/(1 + cresta/COMP_K): sobre todo entre los brazos y en el anillo amarillo de dentro (0 = por igual). ELECCION, medido:
   //     b* de la cresta de cara (gf4_metrics.py (3)) −4,2 con 0, −4,7 con 0,5 (pero el azul del disco se recortaba al tope), −4,4 con 1,5 (el disco cede
   //     31 % de R, 34 % de G y 45 % de B, ponderado hacia el interbrazo; medido con el bulbo de GF4)
   COMP_K: 1.5,
   CLOUD_RIDGE: false,        // (3) la luz de las nubes estelares sale de las crestas (como GF3) y no del disco (true: b* de la cresta −3,2 en vez de −3,9)
   // (2) C: croma del color de los nudos (1 = el calibrado; mezcla hacia su gris, el tono no cambia). BG: fondo minimo del mapa en el sitio del nudo (media
   //     de R, G, B en ±BGR texeles de 62,5 pc); 0,146 = L* 12 de cara (la curva de pantalla de GF3 con ganancia 1: T(1,25·0,146) = 0,124). ELECCION, medido:
   //     C 0,70 -> croma de los nudos en el recorte 31; 0,55 -> 24 (hoy ~25)
   HII: { C: 0.55, BG: 0.146, BGR: 6 },
   // (3) C: croma del color de los cumulos azules (mezcla hacia su gris; 1 = el de GF3). ELECCION, medido con gf4_metrics.py (3): pixeles con b* < −22 en el
   //     recorte 798 (GF3) -> ~30 con 0,3–0,5; con 1, b* minimo −30. Lo que queda por debajo de −22 son nudos HII (a* 16–18) sobre la cresta azul
   CL: { C: 0.3 },
   // (4) el bulbo de GF4: la caja y los lobulos de GF2 × 0,65 y el nucleo mas compacto (σ 0,15/0,15/0,13 kpc en vez de 0,28/0,28/0,22) y mas alto; la luz que
   //     el bulbo tiene de menos vuelve al disco liso (fvGf4BulgeDeficit: el color integrado no cambia; fraccion bulbo+barra 0,34 -> 0,30, dentro de
   //     [0,15; 0,35] de BHG16). ELECCION, medido (gf4_metrics.py (4)): caida de cara centro -> 20–30 px 10,9 -> 20,9 L*; meseta del recorte 283 -> 48 px;
   //     0 px quemados en las cinco vistas (R maximo 252: con a = 6, 3 px a 254 en el recorte). Los lobulos (cacahuete) mas altos con la misma luz
   //     (σz 0,75 -> 1,0 y a × 0,75: a·σz igual, la vista de cara no cambia): con σz 0,75 la semialtura de canto del centro bajaba de 1,69 a 1,52 kpc y k1 de
   //     gf2_metrics.py fallaba (1,82 < 2); con 1,0, 1,89 kpc y k1 2,26 (0,9: 2,08), la caida de cara sigue en 20,8 y la meseta del recorte en 45 px
   BULGE: [ { sx: 1.40, sy: 0.88, sz: 0.36, a: 0.3575, ang: 27 },
            { sx: 0.70, sy: 0.60, sz: 1.00, a: 0.122, ang: 27, u0: 1.0 },
            { sx: 0.70, sy: 0.60, sz: 1.00, a: 0.122, ang: 27, u0: -1.0 },
            { sx: 0.15, sy: 0.15, sz: 0.13, a: 5.3, ang: 27 } ],
   // (9) la barra del mapa: el extremo mas neto (N 6 -> 10) y L 5,3 -> 5,1 con A × 1,013 (misma luz: ∫ e^(−(u/L)^N) du = 2·L·Γ(1 + 1/N)); asi su luz acaba en
   //     el gancho y no se derrama sobre el arranque de los brazos (u = 5,5: 0,29 -> 0,12 de A). ELECCION; semilongitud de BHG16 §4.3 (5,0 ± 0,2 kpc)
   BAR: { A: 0.557, L: 5.1, N: 10, W: 0.9, ANG: 28 },
   // (5) τ de cara saturada a TMAX (0 = sin saturar): con 2,5, cero pixeles negros (L* < 5 sobre fondo > 20) en cara y recorte (GF3: 321 / 446). ELECCION
   DUST: { TMAX: 2.5 },
   // (6) el borde de la luz joven (crestas y brazos) × [1 − D·suave((R − R0)/RW)]: de canto, la tangente del brazo mas externo (R ~ 14 kpc) acababa en un
   //     escalon (2,4 L*/px). La luz quitada la deja de ceder el disco (color integrado igual). ELECCION, medido (gf4_metrics.py (6))
   EDGE: { D: 0, R0: 11, RW: 6 },
   MINOR: { PW_W: 20 },       // (8) ± grados del promedio del peso de angulo de paso de los menores (ELECCION, medido con gf4_metrics.py (8))
   // (7) el Brazo Local: tramo medido ± EXT con bordes de TAPER (grados), cresta ML (fraccion de κ; GF3 0,42) de σ SIG kpc (GF3 0,36), polvo × DK. ELECCION
   //     (σ 0,26 dejaba el entorno del Sol en L* 16,2 < 18, 7a de gf3_metrics.py; polvo × 1,6 descentraba el carril de canto 3,1 px > 3, 6b)
   LOCAL: { EXT: 4, TAPER: 12, ML: 0.60, SIG: 0.36, DK: 1.0 },
   // (10) rotulos: β del punto y apartamiento hacia fuera (kpc). Sgr-Car en β 30° (R 6,0 kpc), sobre su cresta: contraste eje − interbrazo +5,7 L* en el
   //     fotograma de cara y a ~110 px del Sol (en β −15°, el de GF3, a 55 px: pegado al rotulo «Sol»). ELECCION, medido con gf4_metrics.py (10)
   LAB: { sgrcar: { b: 30, off: 0 } }
};
function fvGf4On() { return !!(FV_GAL_GF4.ON && fvGf3On()); }
// (8) el peso de angulo de paso de un brazo menor, promediado a lo largo del brazo en ±PW_W grados (pesos 1-2-3-4-3-2-1): los tramos con paso que GF3
// encendia y apagaba en ±12° (las «comas» sueltas de Norma y Sgr-Car) se encienden y apagan en ~2·PW_W. (7) El Brazo Local, ademas, en su tramo medido
function fvGf4PitchW(T, bb) {
   var W = FV_GAL_GF4.MINOR.PW_W, s = 0, wk = [1, 2, 3, 4, 3, 2, 1];
   for (var k = -3; k <= 3; ++k) s += wk[k + 3] * fvGf3PitchW(T, bb + k * W / 3);
   return (s / 16) * (T.a.id === "local" ? fvGf4LocalW(T, bb) : 1);
}
// (7) el tramo del Brazo Local: el medido de Reid et al. 2019 (tabla 2: β −8° a 34°) ± EXT grados, con bordes suaves de TAPER grados (GF3 lo pintaba en toda su
// tabla, prolongada 35° por cada lado: un velo de 90°)
function fvGf4LocalW(T, bb) { var L = FV_GAL_GF4.LOCAL, a = T.a; return fvGal3Smooth((bb - (a.b0 - L.EXT)) / L.TAPER) * fvGal3Smooth(((a.b1 + L.EXT) - bb) / L.TAPER); }
function fvGf4Key() { if (!fvGf4On()) return ""; var F = FV_GAL_GF4; return JSON.stringify(["gf4", F.LANE, F.K3, F.COMP, F.COMP_K, F.CLOUD_RIDGE, F.HII, F.CL, F.BULGE, F.BAR, F.DUST, F.VOL, F.MINOR, F.LOCAL, F.EDGE]) + fvGf5Key(); }   // (GF5) "" apagado
// la τ de cara con la que se tine el mapa (saturada suave; la del rayo de canto es la entera). (GF5) × K y su TMAX
function fvGf4DustF(t) { if (FV_GAL_GF5.ON && fvGf5On()) { var D5 = FV_GAL_GF5.DUST; t = D5.T0 >= 0 ? t + (D5.K - 1) * Math.max(0, t - D5.T0) : t * D5.K; return D5.TMAX > 0 ? t / (1 + t / D5.TMAX) : t; }
   var M = FV_GAL_GF4.DUST.TMAX; return M > 0 ? t / (1 + t / M) : t; }
// (1) LOS GANCHOS: por cada mitad de la barra, el brazo viejo cuyo carril pasa junto a su extremo (el mismo criterio que GF3) y el β de la union J (donde
// su carril llega a R_J hacia fuera). Se calculan ANTES del bucle polar: el polvo propio del brazo se apaga aguas arriba de J (fvGf4HookW)
function fvGf4Hooks(tabs, RJ) {   // (GF5) RJ: su radio de union (0 o nada = el de GF4)
   var F = FV_GAL_GF4.LANE, B = FV_GAL_GF2.BAR, oldIds = FV_GAL_GG.OLD_ARMS, out = [], h, q, kk, bb, Rd, rJ = RJ > 0 ? RJ : F.R_J;
   for (h = 1; h >= -1; h -= 2) {
      var bE = B.ANG + (h < 0 ? 180 : 0), best = null;
      for (q = 0; q < tabs.length; ++q) { if (oldIds.indexOf(tabs[q].a.id) < 0) continue;
         for (kk = -2; kk <= 1; ++kk) { var Rd0 = fvGf3DustR(tabs[q], bE + 360 * kk); if (Rd0 === null || Rd0 < 3.0 || Rd0 > 5.8) continue; var sc = Math.abs(Rd0 - 0.85 * B.L); if (!best || sc < best.sc) best = { sc: sc, q: q, off: 360 * kk }; } }
      if (!best) continue;
      var T = tabs[best.q], bJ = null;
      for (bb = bE + best.off; bb >= bE + best.off - 150; bb -= 0.25) { Rd = fvGf3DustR(T, bb); if (Rd === null) break; if (Rd >= rJ) { bJ = bb; break; } }
      if (bJ !== null) out.push({ h: h, q: best.q, off: best.off, bE: bE, bJ: bJ });
   }
   return out;
}
// el peso del polvo PROPIO del brazo viejo q en β = bb: 0 aguas arriba de la union (lo pinta el gancho), sube a 1 en DJ grados hacia fuera; 1 lejos
function fvGf4HookW(hk, q, bb, DJ5) {   // (GF5) DJ5: sus grados de relevo (0 o nada = los de GF4)
   var w = 1, DJ = DJ5 > 0 ? DJ5 : FV_GAL_GF4.LANE.DJ;
   for (var i = 0; i < hk.length; ++i) { if (hk[i].q !== q) continue; var d = bb - hk[i].bJ; if (d > -DJ - 1 && d < 300) w *= fvGal3Smooth(-d / DJ); }   // aguas arriba (d > 0, dentro de la barra), nada
   return w;
}
// (1) EL MAPA DE τ DE LOS GANCHOS (N×N sobre ±H): por cada gancho, tres tramos de Hermite (P0 -> P1 -> PX -> J) y el carril del brazo de J a J − DJ.
// Cada muestra (cada ST kpc) suma una gausiana de linea normalizada (como GF3). τ por muestra = DUST_K · aD(brazo) · g(s) · (0,30 + 1,5·dn): la misma
// cuenta y el mismo grano (dn) que el carril del brazo, para que la union no se note. Devuelve { tau, curves } (curves: para las pruebas).
function fvGf4LaneMap(tabs, hk, amps, N, H) {
   var F = FV_GAL_GF4.LANE, G = FV_GAL3, F2 = FV_GAL_GF2, D2R = Math.PI / 180, px = 2 * H / N, out = new Float32Array(N * N), curves = [], sgB = FV_GAL3_BREAK === "beta" ? -1 : 1;
   function xy(R, bb) { var b = sgB * bb * D2R; return [-R * Math.cos(b), R * Math.sin(b)]; }
   function armD(q, bb) { var T = tabs[q], ra = fvGgAt(T, bb); if (!ra || ra[1] <= 0) return [0, 0.1]; var aD = (ra.length > 8 ? ra[7] : amps[q][1] + (amps[q][3] - amps[q][1]) * ra[5]) * ra[1], Rv = Math.max(ra[0], F2.ENV_R) - G.R0; return [aD * Math.exp(-Rv / F2.ENV_HD), 0.32 * fvGal3Sigma(fvGgArmShape(T, ra), ra[0])]; }
   function herm(P, Q, TP, TQ, n, arr, tag) { for (var i = 1; i <= n; ++i) { var t = i / n, t2 = t * t, t3 = t2 * t, a = 2 * t3 - 3 * t2 + 1, b = t3 - 2 * t2 + t, c = -2 * t3 + 3 * t2, d = t3 - t2; arr.push([a * P[0] + b * TP[0] + c * Q[0] + d * TQ[0], a * P[1] + b * TP[1] + c * Q[1] + d * TQ[1], tag]); } }
   function nrm(v) { var l = Math.sqrt(v[0] * v[0] + v[1] * v[1]) || 1; return [v[0] / l, v[1] / l]; }
   function dst(a, b) { return Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1])); }
   for (var k = 0; k < hk.length; ++k) {
      var e = hk[k], T = tabs[e.q], eb = sgB * e.bE * D2R, eu = [-Math.cos(eb), Math.sin(eb)], ev = [sgB * Math.sin(eb), sgB * Math.cos(eb)];   // ev: hacia el lado que avanza
      var fr = function(u, v) { return [u * eu[0] + v * ev[0], u * eu[1] + v * ev[1]]; };
      var P0 = fr(F.U_IN, F.V_IN), P1 = fr(F.U_M, F.V_M), PX = fr(F.U_X, 0), d0 = nrm(fr(1, F.S0)), d1 = nrm(fr(1, 0)), dX = nrm(fr(Math.sin(F.PSI_X * D2R), -Math.cos(F.PSI_X * D2R)));
      var RJ0 = fvGf3DustR(T, e.bJ), RJ1 = fvGf3DustR(T, e.bJ - 0.25); if (RJ0 === null || RJ1 === null) continue;
      var J = xy(RJ0, e.bJ), tJ = nrm([xy(RJ1, e.bJ - 0.25)[0] - J[0], xy(RJ1, e.bJ - 0.25)[1] - J[1]]);
      var c1 = F.K * dst(P0, P1), c2 = F.K * dst(P1, PX), c3 = F.K * dst(PX, J), P = [[P0[0], P0[1], null]];
      herm(P0, P1, [d0[0] * c1, d0[1] * c1], [d1[0] * c1, d1[1] * c1], 200, P, null);
      herm(P1, PX, [d1[0] * c2, d1[1] * c2], [dX[0] * c2, dX[1] * c2], 200, P, null);
      var iX = P.length - 1;
      herm(PX, J, [dX[0] * c3, dX[1] * c3], [tJ[0] * c3, tJ[1] * c3], 300, P, null);
      var iJ = P.length - 1, bb, Rd; P[iJ][2] = e.bJ;                     // la union lleva su β; los tramos C, el suyo
      for (bb = e.bJ - 0.25; bb >= e.bJ - F.DJ - 0.25; bb -= 0.25) { Rd = fvGf3DustR(T, bb); if (Rd === null) break; var pc = xy(Rd, bb); P.push([pc[0], pc[1], bb]); }
      // el recorrido s
      var S = [0], i; for (i = 1; i < P.length; ++i) S.push(S[i - 1] + dst(P[i - 1], P[i]));
      var sX = S[iX], sJ = S[iJ], sE = S[P.length - 1], dJ = armD(e.q, e.bJ), tJ0 = G.DUST_K * dJ[0], pts = [], m = 0;
      for (var s = 0; s <= sE; s += F.ST) {
         while (m < P.length - 2 && S[m + 1] < s) ++m;
         var a0 = P[m], a1 = P[m + 1], f = (s - S[m]) / Math.max(1e-9, S[m + 1] - S[m]), X = a0[0] + (a1[0] - a0[0]) * f, Y = a0[1] + (a1[1] - a0[1]) * f, amp, g, w;
         if (s <= sJ) { amp = tJ0; g = (F.G0 + (1 - F.G0) * fvGal3Smooth(s / sX)) * fvGal3Smooth(s / F.RAMP); w = F.W_IN + (dJ[1] - F.W_IN) * fvGal3Smooth(s / sX); }
         else { var bq = (a0[2] === null || a1[2] === null) ? e.bJ : a0[2] + (a1[2] - a0[2]) * f, dC = armD(e.q, bq); amp = G.DUST_K * dC[0]; g = 1 - fvGal3Smooth((e.bJ - bq) / F.DJ); w = dC[1]; }
         var tau = amp * g * (0.30 + 1.5 * fvGal3Fbm2(X / 0.55, Y / 0.55, 23, 3));
         if (s <= sJ && F.NZ > 0) tau *= 1 + F.NZ * (2 * fvGf3N1(s / F.NP, 29) - 1);   // rizado a lo largo, la MISMA semilla en las dos mitades (simetria)
         if (w < 0.05) w = 0.05;
         pts.push([X, Y, tau, w]);
         if (!(tau > 1e-4)) continue;
         var qn = tau * F.ST / (Math.sqrt(2 * Math.PI) * w), ci = (X + H) / px - 0.5, cj = (Y + H) / px - 0.5, rad = Math.ceil(3 * w / px), iw = 0.5 / (w * w);
         for (var jj = Math.max(0, Math.floor(cj - rad)); jj <= Math.min(N - 1, Math.ceil(cj + rad)); ++jj)
            for (var ii = Math.max(0, Math.floor(ci - rad)); ii <= Math.min(N - 1, Math.ceil(ci + rad)); ++ii) { var dx = (ii - ci) * px, dy = (jj - cj) * px; out[jj * N + ii] += qn * Math.exp(-(dx * dx + dy * dy) * iw); }
      }
      curves.push({ h: e.h, arm: T.a.id, sX: sX, sJ: sJ, s: sE, bJ: e.bJ, pts: pts });
   }
   return { tau: out, curves: curves };
}
// la informacion de GF4 para las pruebas (gf4_pi.js, gf4_node.js): los ganchos (cada 5 muestras: X, Y, τ, σ), la compensacion del disco
function fvGf4Info() {
   if (!fvGf4On()) return null; var T = FV_GAL3_MIX;
   var lanes = (T && T.gf3lanes) ? T.gf3lanes.map(function(c) { var p = []; for (var i = 0; i < c.pts.length; i += 5) p.push([+c.pts[i][0].toFixed(4), +c.pts[i][1].toFixed(4), +c.pts[i][2].toFixed(3), +c.pts[i][3].toFixed(3)]); return { h: c.h, arm: c.arm, sX: c.sX, sJ: c.sJ, s: c.s, bJ: c.bJ, pts: p }; }) : null;
   return { lanes: lanes, discK: T ? T.discK : null, comp: T ? T.comp : null, k3g3: T ? T.k3g3 : null, lane: FV_GAL_GF4.LANE };
}

// ============================================================================
// (encargo GF5, 10-nov) LA GALAXIA GF4 CORREGIDA tras su revision visual adversaria (docs/encargos-9nov/GF/revision-visual-GF4.md).
// Subinterruptor FV_GAL_GF5.ON (ENCENDIDO por defecto desde el 10-nov-2026). Solo actua ENCIMA de GF4 encendido; apagado, nada de esto se ejecuta y GF4 sale bit a bit.
// Lo que cambia (cada causa MEDIDA antes de tocar, con gf5_metrics.py; ver docs/encargos-9nov/GF5-galaxia.md):
//   · GANCHO (LANE): el carril de la barra va por el borde de ataque, se curva en el extremo y cruza el eje de la barra POR DENTRO del eje del brazo
//     (en GF4 lo cruzaba en u = 5,35 kpc, 0,5 kpc por fuera del eje de Scutum, y se pegaba al carril de Sgr-Car) y entra tangente en el carril del borde
//     interior del MISMO brazo (Athanassoula 1992). El eje de Scutum (y su gemelo) cruza el eje de la barra a R = 4,82 kpc, por dentro de la semilongitud
//     de 5,1: un carril por dentro del eje cruza la barra antes de 4,9 kpc por geometria; ahi su τ se topa a TC para que la barra se siga viendo entera,
//     y el gancho es estrecho (WX) hasta la union.
//   · FOSA (COMP): la luz que se anade (crestas, nudos) sigue saliendo del disco viejo liso, pero no del de dentro de R0 (la region de la barra): alli
//     el disco perdia 51 % de B y 35 % de R y quedaba oliva (G/B 1,69 en el recorte); la de los nudos HII sale de las crestas.
//   · NUCLEO (BULGE, VIB): una cadena de gausianas anidadas en vez de la punta de GF4 sobre la caja: cuspide continua del color del bulbo, sin quemar.
//   · POLVO (DUST, VOL): la τ de cara por encima de T0 × K, saturada a TMAX: carriles mas oscuros que GF4, pardos y sin negro; de canto, mas opaco.
//   · NUDOS HII (HII): el color fisico (lineas con [NII], [OIII], [SII] y el enrojecimiento tipico de una HII de disco a traves de las curvas de la
//     camara: fvGalColorCompute -> hii5), mas nudos, mas cerca de la cresta, solo donde el brazo se ve.
//   · DE CANTO (BULGE, VOL): bulbo en caja/cacahuete (dos «tapas» a ±z0).
//   · ROTULO de Sgr-Car (LAB) donde su cresta destaca.
// ============================================================================
var FV_GAL_GF5 = {
   ON: true,
   // (1) el gancho, en el marco de la barra de cada mitad (u hacia ese extremo, v hacia el lado que avanza; kpc): nace en (U_IN, V_IN) con pendiente S0,
   //     pasa por (U_M, V_M) paralelo al eje, cruza el eje en U_X con rumbo PSI_X grados desde −v hacia +u y entra tangente en el carril del brazo donde
   //     este llega a R_J. τ como GF4 (la del carril del brazo en la union × [G0 … 1], rizado NZ), topada a TC junto al eje de la barra (supergausiana
   //     exp(−½(v/DIPW)⁴), peso DIP); anchura no mayor que WX hasta J. Pasada la union, el carril del brazo se enciende en DJ grados mientras el gancho
   //     se apaga. ELECCION todo, medido con gf5_metrics.py (n1) y gf4_metrics.py (1)(9):
   //     · el × (1 − DIP·gauss) de antes: con 0,7/0,3 la barra seguia cortada (dep 10,4 en u 4,3); con 0,8/0,45 se abria un hueco de 0,36–0,40 kpc.
   //       Con el tope: TC 0,35–0,66, hueco 0,32–0,54 kpc; TC 0,85–0,93, hueco 0 y dep maxima sobre el eje 7,0–9,4 (< 10).
   //     · WX: con la anchura del carril del brazo (σ ≈ 0,2 kpc) el ala oscura del gancho hacia un arco de radio constante de 48° (2a de gf3 <= 40°);
   //       WX 0,12 y 0,09 -> 40°. NZ 0,45 -> 0,60: con WX el carril salia demasiado uniforme (1b de gf3, CV 0,15 -> 0,24).
   LANE: { U_IN: 1.6, V_IN: 0.22, S0: 0.12, U_M: 3.0, V_M: 0.70, U_X: 4.55, PSI_X: 40, R_J: 4.75, DJ: 25, K: 1.0, G0: 0.45, RAMP: 0.7, W_IN: 0.07, ST: 0.02, NZ: 0.60, NP: 0.35, DIP: 1.0, DIPW: 0.45, TC: 0.93, WX: 0.09 },
   // (2) el disco liso cede la luz anadida × suave((R − R0)/RW): nada dentro de R0 (la fosa junto a la barra). ELECCION, medido (gf5_metrics.py (n4))
   //     HII_RIDGE: la luz de los nudos HII sale de las crestas, canal a canal (no del disco: el interbrazo quedaba oliva)
   COMP: { R0: 3.6, RW: 1.2, HII_RIDGE: true },
   // (2) la cresta de los mayores × K3 (GF4 1,08): los nudos rojos (mas y mas brillantes) suben el b* de la cresta (−4,4…−4,9 con K3 1,08–1,10);
   //     con 1,16, −5,4 de cara y −7,1 en el recorte. ELECCION, medido (gf4_metrics.py (3))
   K3: 1.16,
   // (3) el bulbo: una caja (la barra vista de canto), dos «tapas» desplazadas ±z0 por encima y por debajo del plano (de canto, la caja/cacahuete de
   //     BHG16 en vez del huso de GF4) y una cadena de cuatro gausianas anidadas para el nucleo (σ 0,50 · 0,35 · 0,17 · 0,085 kpc; cuspide continua, sin
   //     el punto de GF4). ELECCION tras siete barridos solo del bulbo (40 candidatos), medido: caida de cara 21 L* (4a de gf4 >= 20), k1 2,07 (gf2 >= 2),
   //     caja 0,77 (n6b), meseta del recorte 9–10 px. Con cuatro lobulos (u0 ±0,9) k1 caia a 1,57; con la cadena hasta σ 0,7 la meseta era de 14–18 px
   BULGE: [ { sx: 1.40, sy: 0.90, sz: 0.40, a: 0.045, ang: 27 },
            { sx: 1.30, sy: 1.30, sz: 0.46, a: 0.085, ang: 27, z0: 0.98 },
            { sx: 1.30, sy: 1.30, sz: 0.46, a: 0.085, ang: 27, z0: -0.98 },
            { sx: 0.50, sy: 0.45, sz: 0.375, a: 0.14, ang: 27 },
            { sx: 0.35, sy: 0.315, sz: 0.2625, a: 0.30, ang: 27 },
            { sx: 0.17, sy: 0.153, sz: 0.1275, a: 0.90, ang: 27 },
            { sx: 0.085, sy: 0.0765, sz: 0.0638, a: 3.2, ang: 27 } ],
   // (3) la saturacion de pantalla de GF5 (null = la de GF3): la de GF3 con la desaturacion de luces calidas (H0–H1) mas arriba, para que el nucleo no
   //     salga blanco (con 0,70–0,92 el pico de GF4 queda B/R +0,21 sobre su anillo), y la de las luces AZULES (b > r: HB0–HB1) como GF3 (con la de las
   //     calidas, los cumulos azules brillantes daban 308 px de b* < −22 en el recorte; asi 39–49). ELECCION, medido (n2c; 3b de gf4_metrics.py)
   VIB: { S_LO: 0.24, S_HI: 0.46, H0: 0.84, H1: 0.97, S_OUT: 0.56, HB0: 0.70, HB1: 0.92 },
   // (4) τ de cara: t + (K − 1)·max(0, t − T0), saturada a TMAX (GF4: × 1, TMAX 2,5): solo el nucleo de los carriles fuertes se oscurece. Con × K
   //     uniforme (1,15–1,3) el polvo debil tambien subia: pendiente de los menores 0,81–0,85 (8 de gf4 <= 0,8), anillo de 45–48° e interbrazo oliva.
   //     MD × el polvo propio de los brazos menores (con MD 1, Norma 0,95 en 8 de gf4). ELECCION, medido (gf5_metrics.py (n3); gf4 (5)(8); gf3 (2))
   DUST: { K: 1.4, T0: 0.9, TMAX: 3.5, MD: 0.6 },
   // (5) nudos HII: C, croma del color fisico (mezcla hacia su gris, el tono en lineal no cambia; con 1, croma 28,8–29,5 en el recorte, 2a de gf4 <= 28);
   //     N × el numero de GF4; BG, fondo minimo (como GF4); AMP × el brillo de GF3; SAT, tope suave (brillos nominales de GF3); BGS, brillo / (1 + fondo/BGS)
   //     (un nudo rojo sobre el fondo claro de la punta de la barra llevaba R a 251–255); SPREAD × su dispersion radial (con 1, 0,68 en brazo, 5a de
   //     gf3 >= 0,70); FLOOR, suelo de su brillo al azar (GF3 0,25; con 0,25 el contraste mediano era 7,6–7,7, 5c de gf3 >= 8).
   //     ELECCION, medido (n5; gf4_metrics.py (2)(4); gf3_metrics.py (5))
   HII: { C: 0.5, N: 2.6, BG: 0.146, BGR: 6, AMP: 1.35, SAT: 3.0, BGS: 0.8, SPREAD: 0.7, FLOOR: 0.45 },
   // (6) el borde de la luz joven (como EDGE de GF4, que lo dejo en D = 0). Sin probar en GF5: los extremos de canto siguen abruptos (n6c, abierto)
   EDGE: { D: 0, R0: 11, RW: 6 },
   // (4)(6) la capa de canto sobre la de GF3/GF4 (DUST 0,55, TAUF 0,25): con el polvo de cara mas oscuro y el de canto igual, el canto quedaba mas
   //     translucido que la cara (0,385 frente a 0,30 + 0,05: 5d de gf4). ELECCION, medido
   VOL: { DUST: 0.70, TAUF: 0.30 },
   // (7) el rotulo de Sgr-Car (GF4: β 30). Con el gancho ya por dentro del eje de Scutum, entre Scutum y Sgr-Car no queda el carril de GF4 y en β 16–35
   //     la cresta de Sgr-Car apenas destaca (2,4–4,7 L*; GF4 9–12): el rotulo va a β 12, donde destaca 8,7 L* (gf3_metrics.py 7c). En β 6 (7,3 L*)
   //     su texto tocaba el de «Local Arm» en la vista de cara. ELECCION, medido
   LAB: { sgrcar: { b: 12, off: 0 } }
};
function fvGf5On() { return !!(FV_GAL_GF5.ON && fvGf4On()); }
function fvGf5Key() { if (!fvGf5On()) return ""; var F = FV_GAL_GF5; return JSON.stringify(["gf5", F.LANE, F.COMP, F.K3, F.BULGE, F.VIB, F.DUST, F.HII, F.EDGE, F.VOL]) + fvGf6Key(); }   // (GF6) "" apagado
// (1) EL MAPA DE τ DE LOS GANCHOS DE GF5 (N×N sobre ±H): copia adaptada de fvGf4LaneMap (que no se toca) con el cruce del eje por dentro (U_X, PSI_X),
// la union donde el carril del brazo llega a R_J (hk: fvGf4Hooks con el R_J de GF5) y la τ rebajada junto al cruce (DIP).
function fvGf5LaneMap(tabs, hk, amps, N, H) {
   var F = FV_GAL_GF5.LANE, G = FV_GAL3, F2 = FV_GAL_GF2, D2R = Math.PI / 180, px = 2 * H / N, out = new Float32Array(N * N), curves = [], sgB = FV_GAL3_BREAK === "beta" ? -1 : 1;
   var L6 = (FV_GAL_GF6.ON && fvGf6On() && FV_GAL_GF6.LANE) ? FV_GAL_GF6.LANE : null;   // (GF6) (3) el cuello (null: el de GF5, bit a bit)
   var L7 = (L6 && FV_GAL_GF7.ON && fvGf7On() && FV_GAL_GF7.LANE.HU0 > 0) ? FV_GAL_GF7.LANE : null;   // (GF7) (4) la cabeza: el cuello de GF6 solo lejos de la punta
   function xy(R, bb) { var b = sgB * bb * D2R; return [-R * Math.cos(b), R * Math.sin(b)]; }
   function armD(q, bb) { var T = tabs[q], ra = fvGgAt(T, bb); if (!ra || ra[1] <= 0) return [0, 0.1]; var aD = (ra.length > 8 ? ra[7] : amps[q][1] + (amps[q][3] - amps[q][1]) * ra[5]) * ra[1], Rv = Math.max(ra[0], F2.ENV_R) - G.R0; return [aD * Math.exp(-Rv / F2.ENV_HD), 0.32 * fvGal3Sigma(fvGgArmShape(T, ra), ra[0])]; }
   function herm(P, Q, TP, TQ, n, arr, tag) { for (var i = 1; i <= n; ++i) { var t = i / n, t2 = t * t, t3 = t2 * t, a = 2 * t3 - 3 * t2 + 1, b = t3 - 2 * t2 + t, c = -2 * t3 + 3 * t2, d = t3 - t2; arr.push([a * P[0] + b * TP[0] + c * Q[0] + d * TQ[0], a * P[1] + b * TP[1] + c * Q[1] + d * TQ[1], tag]); } }
   function nrm(v) { var l = Math.sqrt(v[0] * v[0] + v[1] * v[1]) || 1; return [v[0] / l, v[1] / l]; }
   function dst(a, b) { return Math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1])); }
   for (var k = 0; k < hk.length; ++k) {
      var e = hk[k], T = tabs[e.q], eb = sgB * e.bE * D2R, eu = [-Math.cos(eb), Math.sin(eb)], ev = [sgB * Math.sin(eb), sgB * Math.cos(eb)];   // ev: hacia el lado que avanza
      var fr = function(u, v) { return [u * eu[0] + v * ev[0], u * eu[1] + v * ev[1]]; };
      var P0 = fr(F.U_IN, F.V_IN), P1 = fr(F.U_M, F.V_M), PX = fr(F.U_X, 0), d0 = nrm(fr(1, F.S0)), d1 = nrm(fr(1, 0)), dX = nrm(fr(Math.sin(F.PSI_X * D2R), -Math.cos(F.PSI_X * D2R)));
      var RJ0 = fvGf3DustR(T, e.bJ), RJ1 = fvGf3DustR(T, e.bJ - 0.25); if (RJ0 === null || RJ1 === null) continue;
      var J = xy(RJ0, e.bJ), tJ = nrm([xy(RJ1, e.bJ - 0.25)[0] - J[0], xy(RJ1, e.bJ - 0.25)[1] - J[1]]);
      var c1 = F.K * dst(P0, P1), c2 = F.K * dst(P1, PX), c3 = F.K * dst(PX, J), P = [[P0[0], P0[1], null]];
      herm(P0, P1, [d0[0] * c1, d0[1] * c1], [d1[0] * c1, d1[1] * c1], 200, P, null);
      herm(P1, PX, [d1[0] * c2, d1[1] * c2], [dX[0] * c2, dX[1] * c2], 200, P, null);
      var iX = P.length - 1;
      herm(PX, J, [dX[0] * c3, dX[1] * c3], [tJ[0] * c3, tJ[1] * c3], 300, P, null);
      var iJ = P.length - 1, bb, Rd; P[iJ][2] = e.bJ;
      for (bb = e.bJ - 0.25; bb >= e.bJ - F.DJ - 0.25; bb -= 0.25) { Rd = fvGf3DustR(T, bb); if (Rd === null) break; var pc = xy(Rd, bb); P.push([pc[0], pc[1], bb]); }
      var S = [0], i; for (i = 1; i < P.length; ++i) S.push(S[i - 1] + dst(P[i - 1], P[i]));
      var sX = S[iX], sJ = S[iJ], sE = S[P.length - 1], dJ = armD(e.q, e.bJ), tJ0 = G.DUST_K * dJ[0], pts = [], m = 0, iDW = 1 / Math.max(1e-6, F.DIPW);
      for (var s = 0; s <= sE; s += F.ST) {
         while (m < P.length - 2 && S[m + 1] < s) ++m;
         var a0 = P[m], a1 = P[m + 1], f = (s - S[m]) / Math.max(1e-9, S[m + 1] - S[m]), X = a0[0] + (a1[0] - a0[0]) * f, Y = a0[1] + (a1[1] - a0[1]) * f, amp, g, w;
         if (s <= sJ) { amp = tJ0; g = (F.G0 + (1 - F.G0) * fvGal3Smooth(s / sX)) * fvGal3Smooth(s / F.RAMP); w = F.W_IN + (dJ[1] - F.W_IN) * fvGal3Smooth(s / sX); }
         else { var bq = (a0[2] === null || a1[2] === null) ? e.bJ : a0[2] + (a1[2] - a0[2]) * f, dC = armD(e.q, bq); amp = G.DUST_K * dC[0]; g = 1 - fvGal3Smooth((e.bJ - bq) / F.DJ); w = dC[1];
            if (F.WX > 0 && w > F.WX) w = F.WX + (w - F.WX) * fvGal3Smooth((e.bJ - bq) / F.DJ); }   // pasada la union, de WX a la anchura del carril del brazo
         if (F.WX > 0 && s <= sJ && w > F.WX) w = F.WX;   // el gancho, no mas ancho que WX hasta J (con la anchura del carril del brazo, su ala oscura hacia un arco de radio constante: 2a de gf3)
         var tau = amp * g * (0.30 + 1.5 * fvGal3Fbm2(X / 0.55, Y / 0.55, 23, 3));
         if (s <= sJ && F.NZ > 0) tau *= 1 + F.NZ * (2 * fvGf3N1(s / F.NP, 29) - 1);
         if (F.DIP > 0 && s <= sJ) { var zd = (X * ev[0] + Y * ev[1]) * iDW, z2 = zd * zd, wD = F.DIP * Math.exp(-0.5 * (F.TC > 0 ? z2 * z2 : z2));
            if (L7) { var gU = fvGal3Smooth(((X * eu[0] + Y * eu[1]) - L7.HU0) / L7.HUW), t5 = F.TC > 0 ? tau - wD * Math.max(0, tau - F.TC) : tau * (1 - wD), t6 = tau - wD * Math.max(0, tau - L6.TC);   // (GF7) (4) GF5 en la punta,
               tau = t5 + gU * (t6 - t5); if (w < L6.WC) w += gU * wD * (L6.WC - w); }                                                                                                   // GF6 en el cruce
            else if (L6) { tau = tau - wD * Math.max(0, tau - L6.TC); if (w < L6.WC) w += wD * (L6.WC - w); }   // (GF6) (3) el cuello: tope mas alto y carril mas ancho
            else tau = F.TC > 0 ? tau - wD * Math.max(0, tau - F.TC) : tau * (1 - wD); }   // junto al eje de la barra (v = 0), donde el gancho lo cruza: τ topada a TC en |v| < ~DIPW (supergausiana; sin TC, × (1 − DIP·gauss))
         if (w < 0.05) w = 0.05;
         pts.push([X, Y, tau, w]);
         if (!(tau > 1e-4)) continue;
         var qn = tau * F.ST / (Math.sqrt(2 * Math.PI) * w), ci = (X + H) / px - 0.5, cj = (Y + H) / px - 0.5, rad = Math.ceil(3 * w / px), iw = 0.5 / (w * w);
         for (var jj = Math.max(0, Math.floor(cj - rad)); jj <= Math.min(N - 1, Math.ceil(cj + rad)); ++jj)
            for (var ii = Math.max(0, Math.floor(ci - rad)); ii <= Math.min(N - 1, Math.ceil(ci + rad)); ++ii) { var dx = (ii - ci) * px, dy = (jj - cj) * px; out[jj * N + ii] += qn * Math.exp(-(dx * dx + dy * dy) * iw); }
      }
      curves.push({ h: e.h, arm: T.a.id, sX: sX, sJ: sJ, s: sE, bJ: e.bJ, pts: pts });
   }
   return { tau: out, curves: curves };
}
// la informacion de GF5 para las pruebas (gf5_pi.js, gf5_node.js): los ganchos (cada 5 muestras: X, Y, τ, σ), la compensacion, los nudos
function fvGf5Info() {
   if (!fvGf5On()) return null; var T = FV_GAL3_MIX;
   var lanes = (T && T.gf3lanes) ? T.gf3lanes.map(function(c) { var p = []; for (var i = 0; i < c.pts.length; i += 5) p.push([+c.pts[i][0].toFixed(4), +c.pts[i][1].toFixed(4), +c.pts[i][2].toFixed(3), +c.pts[i][3].toFixed(3)]); return { h: c.h, arm: c.arm, sX: c.sX, sJ: c.sJ, s: c.s, bJ: c.bJ, pts: p }; }) : null;
   return { lanes: lanes, comp: T ? T.comp : null, hii: T ? T.hii5 : null, lane: FV_GAL_GF5.LANE };
}

// ============================================================================
// (encargo GF6, 10-nov) LA GALAXIA GF5 CORREGIDA tras su revision visual adversaria (docs/encargos-9nov/GF/revision-visual-GF5.md), vigilada por las
// GUARDAS PERMANENTES de tests/_galaxy/gfguard/gf_guard.py (ninguna que GF5 pasa puede caer a rojo). Subinterruptor FV_GAL_GF6.ON (ENCENDIDO por defecto desde el 10-nov-2026).
// Solo actua ENCIMA de GF5 encendido; apagado, nada de esto se ejecuta y GF5 sale bit a bit. Lo que cambia (cada causa MEDIDA antes de tocar; ver
// docs/encargos-9nov/GF6-galaxia.md):
//   · FOSA Y BARRA (MOAT, BULGE): el oliva de GF4 lo hacia fvGf4Comp (el disco liso cedia 32 % de R y 55 % de B tambien junto a la barra: el disco
//     que quedaba era amarillo-verdoso); GF5 dejo de restarlo dentro de R0 = 3,6 kpc y la fosa volvio a tener toda la luz del disco (gris levantado).
//     Y las «tapas» del bulbo de GF5 eran REDONDAS (σ 1,3 × 1,3 kpc): de cara, un halo redondo que diluye la barra. Ahora: (a) la luz del disco liso
//     a los lados de la barra baja × (1 − D·w), con w maximo perpendicular a la barra entre R0 y R1 (el «deficit de luz» del disco dentro del radio de
//     la barra, mas hondo cuanto mas larga y fuerte es la barra: Kim et al. 2016, MNRAS 462, 3430, en 3,6 µm de S4G; en sus N-body la barra crece
//     capturando estrellas del disco) y ESA luz pasa a la barra en el mismo tramo de radio (mismo color, COL_OLD: el color
//     integrado no se mueve). Sin restar canal a canal (la causa del oliva sigue fuera, como en GF5): la fosa se oscurece con el mismo factor en R, G, B;
//     (b) un poco de polvo difuso en la fosa (TAU): gira el tono hacia el pardo; (c) el bulbo en caja con los lobulos de la caja APARTADOS de la barra
//     (v0) por encima y por debajo del plano (ver BULGE).
//   · POLVO DE LOS BRAZOS EXTERIORES (DUST): el polvo de los brazos mayores × [1 + OB·suave((R − OR0)/ORW)], en carril algo mas estrecho y mas apartado
//     de la cresta (los de fuera de 7,5 kpc estaban lavados).
//   · CANAL AZUL (TONE): hombro suave del canal mayor por encima de K con techo TOP < 255 (la compresion de GF2/GF3 llevaba el canal mayor a 1,0
//     exacto: 255).
//   · CUELLO DEL GANCHO (LANE), CANTO (VOL, BULGE) y ROTULOS (LAB): ver cada bloque.
// ============================================================================
var FV_GAL_GF6 = {
   ON: true,
   // (1) fosa: × (1 − D·w) en el disco liso, w = suave((R − R0)/RW)·(1 − suave((R − R1)/RW))·|sen(β − β_barra)|^P; TAU: τ difuso × w. La luz quitada pasa a
   //     la barra × (1 + k·suave(R)) en el mismo tramo de radio (k = Σ quitado / Σ barra·ventana). ELECCION, medido (gf_guard sobre node, 10-nov; en
   //     estos barridos y en los de BULGE y VOL el polvo exterior iba con OS 0,5 y el cuello con TC 1,8 / WC 0,2): D 0,65 -> fosa L* 6 de cara, tono peor (h 84,8°) y meseta del nucleo en el recorte 10 px (N2 rojo); D 0,3 -> B/G en
   //     pantalla 0,90 (X2 rojo) y la misma meseta de 10 px; D 0,5 -> L* 7,8, h 82,9°, meseta 9, B/G 0,89. TAU sube G/B a la vez que baja h: TAU 0,55 ->
   //     h 81,1° pero G/B 1,46 (F1 rojo) y B/G en pantalla 0,90; TAU 1,0 -> h 79,1°, G/B 1,55–1,60. Con TAU 0,3, G/B 1,36 y h 82,9° (F3 sigue en rojo)
   MOAT: { D: 0.5, R0: 1.5, R1: 4.0, RW: 0.9, P: 2, TAU: 0.3 },
   // (1)(6) el bulbo: el de GF5 (caja en el plano y cadena de cuatro gausianas del nucleo, sin tocar) con las dos «tapas» redondas (σ 1,3 × 1,3 kpc a
   //     z ±0,98) cambiadas por CUATRO lobulos a v ±0,70 kpc (perpendicular a la barra en el plano) y z ±0,9 kpc, σ 1,0 (a lo largo) × 0,5 × 0,42 kpc, y
   //     una columna de relleno en el eje (v 0, z ±0,5, σ 1,0 × 0,6 × 0,4). De canto vemos la barra casi de punta (9° de la linea de vision): la
   //     caja/cacahuete de BHG16 (0,70 : 0,44 : 0,18) se ve como caja solo si la luz de arriba esta APARTADA del eje en v. Medido (gf_guard E2, exceso de
   //     caja sobre la elipse): tapas redondas −0,05; columna vertical de lobulos en el eje −0,01…+0,02; lobulos a v ±0,55 −0,11; ±0,70 +0,03; ±0,85
   //     +0,09…+0,19; ±1,0 +0,22. Pero con v ±0,85 y sin relleno el canto ×3 enseña CUATRO MANCHAS (muesca: luz en el eje / maximo a lo ancho a z ±0,9
   //     = 0,89, medido; GF5 1,00): con la columna, 1,00 y E2 0,14–0,16. σ 1,3 a lo largo de la barra aplana el perfil del nucleo de cara (N1 de cara
   //     0,00: rojo tambien de cara); σ 1,0 -> −0,10…−0,12 (GF5 −0,11). Luz por encima del plano (Σ a·σx·σy·σz): lobulos + columna 0,090 frente a 0,132
   //     de las tapas de GF5
   BULGE: [ { sx: 1.40, sy: 0.90, sz: 0.40, a: 0.045, ang: 27 },
            { sx: 1.00, sy: 0.50, sz: 0.42, a: 0.078, ang: 27, v0: 0.70, z0: 0.9 },
            { sx: 1.00, sy: 0.50, sz: 0.42, a: 0.078, ang: 27, v0: 0.70, z0: -0.9 },
            { sx: 1.00, sy: 0.50, sz: 0.42, a: 0.078, ang: 27, v0: -0.70, z0: 0.9 },
            { sx: 1.00, sy: 0.50, sz: 0.42, a: 0.078, ang: 27, v0: -0.70, z0: -0.9 },
            { sx: 1.00, sy: 0.60, sz: 0.40, a: 0.05, ang: 27, z0: 0.5 },
            { sx: 1.00, sy: 0.60, sz: 0.40, a: 0.05, ang: 27, z0: -0.5 },
            { sx: 0.50, sy: 0.45, sz: 0.375, a: 0.14, ang: 27 },
            { sx: 0.35, sy: 0.315, sz: 0.2625, a: 0.30, ang: 27 },
            { sx: 0.17, sy: 0.153, sz: 0.1275, a: 0.90, ang: 27 },
            { sx: 0.085, sy: 0.0765, sz: 0.0638, a: 3.2, ang: 27 } ],
   // (2) polvo de los brazos mayores fuera de OR0 × (1 + OB·suave((R − OR0)/ORW)), con el carril × (1 + OW·w) de ancho y × (1 + OS·w) de apartado de la
   //     cresta. ELECCION, medido (gf_guard D1–D8, A1): la banda 7,5–9 de cara la hacen los carriles de Scutum-Centaurus y Perseo (pocos pixeles: necesitan
   //     τ alta); con OR0 6,2 la banda 6,5–7,5 se oscurecia a 0,15 antes de que la de 7,5–9 bajara de 0,32. Carril mas ancho EMPEORA la banda (0,34–0,36)
   //     y mueve R/G +0,006. Con la anchura y el sitio de GF2 (OW 0, OS 0) el ala del carril enrojece la cresta: b* −4,56 (A1 rojo; con OB 0, −5,50) y el
   //     interbrazo pasa a G/B 1,62 (F4 rojo); carril estrecho (OW −0,4, OS 0) arregla la cresta (−5,88) pero da grano de canto (ruido 1,68) y extremos
   //     1,93 (con OB 4 y OW −0,3…−0,55, ademas, pixeles negros: D9 7–310). Apartado de la cresta con OW −0,12: OS 0 -> b* −5,03 y G/B 1,62 (F4 rojo);
   //     OS 0,25 -> b* −5,49, G/B 1,54, extremos del disco de canto (E3) 1,12; OS 0,5 -> b* −5,79 pero extremos 1,47 (rojo: el ala del carril apartada
   //     destapa el canto del brazo exterior a x −13,9 kpc). OB 2 -> extremos 1,65 y B/G en pantalla 0,90. ELECCION: OS 0,25 (todo en verde)
   DUST: { OB: 3.0, OR0: 7.6, ORW: 1.0, OW: -0.12, OS: 0.25 },
   // (4) pantalla: hombro del canal mayor (tanh) de K a TOP (254/255: nunca 255)
   TONE: { K: 0.93, TOP: 254 / 255 },
   // (6) canto: capa de ZK escalas de altura (GF5: 3 -> el disco se cortaba a |z| = 0,9 kpc); POP: la parte de la luz con el color de la poblacion vieja
   //     va a la capa gruesa (HZ) y el resto (joven, azul) a la fina (HZY) (GF5: la parte LISA de toda la luz, tambien la azul, iba a la gruesa y la piel
   //     salia mas azul que el plano); HZD y DSECH: el polvo. Drimmel y Spergel 2001 (ApJ 556, 181; arXiv astro-ph/0101259, §4, leido el 10-nov):
   //     polvo en sech²(z/h_d) con h_d de 134 pc a 188 pc en el circulo solar (R0 = 8 kpc). DSECH true da sech²(z/(2·HZD)): HZD 0,094 es h_d = 188 pc,
   //     el perfil de Drimmel y Spergel tal cual. Medido (gf_guard sobre node, mismo motor; GF5: caja E2 −0,05 · raya E6 0,30 · relleno E8 1,14 · piel E9 43):
   //       sech² HZD 0,094 -> E2 0,04 · E3 1,21 · E4 7,6 · E6 0,42 · E8 1,00 · E9 31,3 (ninguna guarda que GF5 pasa cae a rojo)
   //       sech² HZD 0,11 -> E2 0,05 · E6 0,38 · E8 0,67 · E9 24,7 · 0,13 -> 0,07 · 0,32 · 0,41 · 19,0 · 0,15 -> 0,11 · 0,28 · 0,28 · 15,9 (E3 1,54)
   //       e^(−z/0,22) (sin DSECH) -> E2 0,16 · E3 1,20 · E6 0,24 · E8 0,41 · E9 17,5 (caja y raya en verde, pero el bulbo queda como una caja arriba y otra
   //       abajo de una banda oscura ancha y el disco apagado: E8 y E9 caen a rojo; visto en el canto ×3). e^(−z/0,16) -> 0,08 · 1,13 · 0,30 · 0,62 · 23,1.
   //     E2 y E6 suben (mejoran) con el polvo grueso y E8 y E9 caen: no hay altura que pase las cuatro (E2 >= 0,08 pide polvo que E8 >= 0,80 no deja).
   //     ELECCION: la sech² de Drimmel y Spergel (fisica, sin regresion en gf_guard y la que se ve como una galaxia de canto); caja y raya quedan sin cumplir
   //     (E2 mejora de −0,05 a 0,04; E6 empeora de 0,30 a 0,42: mide toda estructura horizontal fina, tambien un carril nitido). Decision D1 del informe GF6.
   VOL: { ZK: 5, POP: 1.0, HZD: 0.094, DSECH: true },
   // (3) el cuello del gancho: donde el gancho cruza el eje de la barra, GF5 topaba su τ a TC 0,93 (el carril se aclaraba: 0,16 -> 0,55 -> 0,09). Aqui el
   //     tope pasa a TC (9: en la practica, sin tope) y el carril se ensancha hasta WC (kpc) en ese tramo. CONFLICTO MEDIDO con gf4 (9) («ningun carril
   //     corta el eje de la barra antes de 4,9 kpc»): el cruce esta en u ≈ 4,1–4,3 (dentro de la barra, por ir el gancho por dentro del eje del brazo) y un
   //     carril oscuro ahi da dep >= 10. Barrido sobre GF6 (node + gf4_metrics + gf_guard L4, cuello cara·recorte por gancho): GF5 (null) 0,36–0,39 y gf4
   //     entero en verde; TC 1,1 / WC 0,3 -> 0,32–0,35 y barra visible 4,0 kpc de un lado; TC 1,8 / WC 0,45 -> 0,26–0,31 y barra visible 3,8; TC 2,6 /
   //     WC 0,42 -> 0,17–0,20, barra visible 3,7 y gf4 1a/1e rojos; TC 1,4 / WC 0,15 -> 0,16–0,20; TC 3 / WC 0,15 -> 0,06–0,16 pero gf4 8 rojo; TC 9 /
   //     WC 0,12 -> 0,08–0,17 y barra visible 5,04 en los dos lados, con (9) en u 4,14–4,16. Ningun carril oscuro y continuo pasa (9): ELECCION (la del
   //     encargo GF6, punto 3) cuello continuo con la barra entera; (9) queda en rojo y se marca en el informe
   LANE: { TC: 9, WC: 0.12 },
   // (5) rotulos: β y apartamiento (kpc, < 0 hacia dentro). GF5 (β 12, sobre la cresta): cajas de «Sagittarius–Carina Arm» y «Local Arm» a 0,4 px de cara
   //     y solapadas 1,6 px en la oblicua. β 12 / −0,5 (primer intento, medido en PixInsight): 13,75 / 8,12 / 32,69 px (cara / oblicua / recorte) pero el
   //     rotulo cae a medio camino de Scutum (gf_guard T3: distancia a su eje / al de otro brazo 1,02–1,18; GF5 0,11–0,17). Estimado moviendo esa caja real
   //     con la proyeccion de su punto (el estimador reproduce GF5 y ese intento a ±0,1 px en T1): β 18 / −0,1 -> 14,1 / 7,8 / 26,5 px y T3 0,23–0,36;
   //     contraste eje − interbrazo del brazo junto al rotulo (gf3 7c, >= 3) 9,3 en β 12, 4,6 en β 18, 4,1 en β 20. ELECCION β 18 / −0,1
   LAB: { sgrcar: { b: 18, off: -0.1 } }
};
function fvGf6On() { return !!(FV_GAL_GF6.ON && fvGf5On()); }
function fvGf6Key() { if (!fvGf6On()) return ""; var F = FV_GAL_GF6; return JSON.stringify(["gf6", F.MOAT, F.BULGE, F.DUST, F.LANE, F.VOL]) + fvGf7Key(); }   // (GF7) "" apagado
// (GF7) los parametros de la fosa en uso: los de GF7 (si esta encendido) o los de GF6 (el mismo objeto de siempre: apagado, bit a bit)
function fvGf6M() { return (FV_GAL_GF7.ON && fvGf7On()) ? FV_GAL_GF7.MOAT : FV_GAL_GF6.MOAT; }
// (1) el peso de la fosa en (X, Y) (0 … 1): entre R0 y R1, maximo perpendicular a la barra (la del mapa: la de GF4, encendida debajo)
function fvGf6MoatR(R) { var M = fvGf6M(); return fvGal3Smooth((R - M.R0) / M.RW) * (1 - fvGal3Smooth((R - M.R1) / M.RW)); }   // la ventana en radio (0 dentro de R0)
function fvGf6MoatW(X, Y, R) {
   var M = fvGf6M(), wR = fvGf6MoatR(R); if (!(wR > 0)) return 0;
   var s = Math.abs(Math.sin((fvGal3Beta(X, Y) - FV_GAL_GF4.BAR.ANG) * Math.PI / 180)); return wR * Math.pow(s, M.P);
}
// la informacion de GF6 para las pruebas (gf6_pi.js, gf6_node.js): los ganchos (como GF5), el refuerzo de la barra, la compensacion
function fvGf6Info() {
   if (!fvGf6On()) return null; var T = FV_GAL3_MIX, g5 = fvGf5Info();
   return { lanes: g5 ? g5.lanes : null, comp: T ? T.comp : null, barBoost: T ? T.mBoost : null, moat: FV_GAL_GF6.MOAT, dust: FV_GAL_GF6.DUST, vol: FV_GAL_GF6.VOL };
}

// ============================================================================
// (encargo GF7, 10-nov) LA GALAXIA GF6 CORREGIDA tras su revision visual adversaria (docs/encargos-9nov/GF/revision-visual-GF6.md), con las guardas
// ampliadas de gfguard (techo y suelo en cada guarda de contraste u oscuridad; lo de un sector, por sector). Subinterruptor FV_GAL_GF7.ON (ENCENDIDO por
// defecto desde el 10-nov-2026). Solo actua ENCIMA de GF6 encendido (y por tanto de GF4 y GF5); apagado, nada de esto se ejecuta y GF6 sale bit a bit. Lo que cambia (cada
// causa MEDIDA antes de tocar; ver docs/encargos-9nov/GF7-galaxia.md): la fosa (MOAT), el polvo junto al Sol y el del borde exterior de Perseo (DUST),
// la cabeza de los ganchos (LANE), el canto (VOL) y los lobulos del bulbo (BULGE).
// ============================================================================
var FV_GAL_GF7 = {
   ON: true,
   // (1) la fosa (sustituye a FV_GAL_GF6.MOAT; R0, R1, RW, P, TAU los de GF6). D: cuanto se oscurece el disco liso (la luz quitada pasa a la barra, como en
   //     GF6); TINT: el color de la luz vieja que queda en la fosa (× R, G, B en lineal, con el peso de la fosa). Barrido (node, gf_guard, cara + recorte):
   //       D 0,50 (= GF6): B1 49,3 · B2 34,2 · A2 1,23 · C2 59 · F5 0,27/8,6 (agujero) · F3 h 83,6 a* +0,9 (caqui)
   //       D 0,30 TINT 1,12: B1 31,7 · F5 0,14/12,8 · F3 h 62 a* +5,2 (rojo de mas)      D 0,25 TINT 1,18: B1 28,5 · F5 0,09/13,9 · F3 h 58 a* +6,6
   //       D 0,25 sin TINT: F3 h 84 a* +0,9 (caqui otra vez)                               D 0,25 TINT 1,04: F5 0,102 (justo fuera) · F3 h 73 a* +2,9
   //       D 0,22 TINT 1,04 (ELEGIDO): B1 27,9 (3,6 mag) · B2 18,7 · A2 1,05 · C1 21,0 · C2 34,8 · C3 10,8 · F2 21,4/11,3 · F3 h 73 a* +2,9 · F5 0,08/14,2
   //       D 0,20 TINT 1,05: B1 26,6 · F3 h 71 a* +3,4 (por encima del +3 del encargo)
   //     El contraste barra/interbarra de las barradas fuertes es de 2–4 mag (Elmegreen 1985; Kim et al. 2016 §3.3, solo cualitativo): 15–30 en Y lineal es
   //     2,9–3,7 mag. TINT es ELECCION (color del encargo: pardo con algo de rojo, sin oliva); X1 se mantiene (1,03/0,95)
   MOAT: { D: 0.22, R0: 1.5, R1: 4.0, RW: 0.9, P: 2, TAU: 0.3, TINT: [1.04, 1, 1] },
   // (2)(3) polvo. MB: refuerzo del polvo de los brazos MENORES (Sgr-Car, Local, Norma) en la banda MR0–MR1 (con rampas MRW); LB: refuerzo de mas solo para
   //     el Brazo Local; MW: su carril × (1 + MW·w) de ancho. CV: donde se APAGA por fuera el refuerzo de GF6 de los mayores (OB, OW, OS): × (1 − suave((R − CV0)/CVW))
   //     D12 (p1 de T por sectores, R 6,5–9; GF6 0,41 en 135–180 y 0,37 en 180–225, cara):
   //       MB 1,0 MW −0,15 (ELEGIDO): 180–225 0,37 -> 0,27 (Sgr-Car) y 0–45 0,32 -> 0,18; 135–180 sigue en 0,42. MB 1,5: 180–225 0,22 pero D2/D3 0,17/0,16 y L* a R 8 cae
   //       LB 3 · LB 6 · LB 4 con MW −0,4: 135–180 0,45 · 0,40 · 0,43 (REFUTADO: el carril del Brazo Local apenas cambia T; causa NO VERIFICADA) -> LB 0
   //       un suelo del peso de paso de los menores (MF) no cambiaba nada (los menores ya tienen peso 1 junto al Sol) -> quitado
   //     D13 (lado convexo de Perseo junto al Sol): CV0 9,0 -> p5 de T por fuera 0,10/0,08 -> 0,23/0,18; CV0 9,6 -> 0,15/0,11. El L* del disco a R 8 no se
   //       recupera (16,1 -> 15,9; GF5 17,8). Ojo: fuera de la corrotacion (R > 8,5) el carril va por el lado CONVEXO (Roberts 1969); esto solo quita el refuerzo
   DUST: { MB: 1.0, LB: 0, MR0: 6.0, MR1: 9.5, MRW: 0.8, MW: -0.15, CV0: 9.0, CVW: 0.6 },
   // (4) la cabeza de los ganchos: el tratamiento del cuello de GF6 (sin tope y carril ensanchado junto al eje de la barra) solo a partir de u >= HU0 (rampa HUW)
   //     a lo largo de la barra; mas cerca de la punta, el de GF5. HU0 2,8: L5 (cabeza/cuello) 1,31 -> 1,02 · S5 (aro) +6,8 -> +6,3 · L4 0,16/0,08 igual
   LANE: { HU0: 2.8, HUW: 0.8 },
   // (5) canto (se suma a FV_GAL_GF6.VOL). El «carril doble» de GF6 (E10 = 2: dos minimos a z ±0,15 con una raya 2,6 L* mas clara en z = 0) es la capa
   //     JOVEN del disco cercano (R 8–12, poco polvo) asomando entre las dos mitades de un polvo sech² sin cuspide. Barrido (E10 · E9 piel · E4 corte · S4 cinturon):
   //       REFUTADOS, E10 sigue en 2: capa joven en sech² · estrellas sueltas tras el polvo · capa joven ensanchada hacia fuera (Skowron et al. 2019) · HZY 0,2 ·
   //         RC0 13 solo · HRD 6 RC0 13 con sech² (E9 26, rojo) · HRD 5,05 RC0 14,3 (Davies 1997 y el corte de Drimmel y Spergel 2001: E10 3, E9 25)
   //       polvo en e^(−z/HZD) (DSECH false, HZD 0,094 de GF6): E10 1 · E9 40 · E4 8,1 · S4 2,9;  + HRD 6 RC0 13: 1 · 37 · 8,0 · 2,5
   //       + THK 0,12 HZT2 0,9 (disco grueso, BHG16 §5.1.3, leido: f_Σ = 12 % ± 4 %, z_T = 900 ± 100 pc): 1 · 37 · 7,1 · 2,3
   //       + KG 0,4: 1 · 39 · 7,0 · 1,92 (E8 1,24, E3 1,25/1,50 -GF6 1,21/0,92, ya rojo-, E6 0,41 como GF6; se ven dos hilos naranjas en los bordes)
   //       KG 0,2 · 0,15 · 0,1 (ELEGIDO) · 0,01: S4 1,59 · 1,49 · 1,43 · 1,35; E5 piel b* 7,2 · 6,6 · 6,0 · 4,6 (>= +3); E9, E10, E8 y E4 no se mueven
   //     KG: el color del polvo de canto × (1 + KG·(k − 1)), casi gris: el rayo no calcula la luz dispersada, que rellena el carril de azul y hace la atenuacion
   //     efectiva mas gris que la extincion (ELECCION; la cifra no sale de ninguna fuente: es la mayor que deja S4 <= 1,5 con margen). HRD 6 (escala del polvo liso) es mas larga que la de Drimmel y
   //     Spergel (0,28 R⊙ ≈ 2,3 kpc) y que la de Davies (0,62 R⊙, citada por ellos): ELECCION. La decision D1 (perfil vertical del polvo) sigue abierta para Nino
   VOL: { DSECH: false, HRD: 6, RC0: 13, KG: 0.1, THK: 0.12, HZT2: 0.9 },
   // (6) el bulbo (sustituye al de GF6): el de GF6 con los CUATRO lobulos de la caja/cacahuete llevados al eje MAYOR de la barra (u0, a lo largo; en GF6
   //     estaban en v0 ±0,70, el eje menor: revision de GF6 §5, comprobado en fv_galaxy3d.js:595-596). Misma luz por lobulo (a·σx·σy·σz 0,0164 en los dos).
   //     La X va a lo largo de la barra (Wegg y Gerhard 2013; Ness y Lang 2016). E2b (cacahuete: altura de la isofota a los lados / en el centro):
   //     barra de lado (cantoL) 1,06 · casi de punta (cantoZ, 27°) 0,97 (redondo); E7 1,00 · E8 1,24. Lobulos ±0,90 en u y ±0,75 en z: ELECCION de forma
   //     Con la barra casi de punta desde el lado del Sol, los lobulos en u caen sobre el nucleo en el recorte oblicuo: el pico sube y el hombro lo blanquea
   //     (N3, color del pico frente al anillo a 14–20 px: ΔB/R 0,048 en GF6 -> 0,073; con el bulbo de GF6, 0,05). Los dos componentes mas pequenos del nucleo
   //     bajan (a 3,2 -> 2,4 y 0,90 -> 0,80; ELECCION): ΔB/R 0,04, C* pico − anillo −0,7. Probado antes: lobulos a u ±1,1 · σx 0,75 · a 0,085 (0,06–0,07)
   BULGE: [ { sx: 1.40, sy: 0.90, sz: 0.40, a: 0.045, ang: 27 },
            { sx: 0.60, sy: 0.60, sz: 0.42, a: 0.1083, ang: 27, u0: 0.90, z0: 0.75 },
            { sx: 0.60, sy: 0.60, sz: 0.42, a: 0.1083, ang: 27, u0: 0.90, z0: -0.75 },
            { sx: 0.60, sy: 0.60, sz: 0.42, a: 0.1083, ang: 27, u0: -0.90, z0: 0.75 },
            { sx: 0.60, sy: 0.60, sz: 0.42, a: 0.1083, ang: 27, u0: -0.90, z0: -0.75 },
            { sx: 1.00, sy: 0.60, sz: 0.40, a: 0.05, ang: 27, z0: 0.5 },
            { sx: 1.00, sy: 0.60, sz: 0.40, a: 0.05, ang: 27, z0: -0.5 },
            { sx: 0.50, sy: 0.45, sz: 0.375, a: 0.14, ang: 27 },
            { sx: 0.35, sy: 0.315, sz: 0.2625, a: 0.30, ang: 27 },
            { sx: 0.17, sy: 0.153, sz: 0.1275, a: 0.80, ang: 27 },
            { sx: 0.085, sy: 0.0765, sz: 0.0638, a: 2.4, ang: 27 } ]
};
function fvGf7On() { return !!(FV_GAL_GF7.ON && fvGf6On()); }
function fvGf7Key() { if (!fvGf7On()) return ""; var F = FV_GAL_GF7; return JSON.stringify(["gf7", F.MOAT, F.DUST, F.LANE, F.VOL, F.BULGE]) + fvGf8Key(); }   // (GF8) "" apagado
// (2) la ventana en radio del refuerzo de los menores
function fvGf7MinorW(R) { var D = FV_GAL_GF7.DUST; return fvGal3Smooth((R - D.MR0) / D.MRW) * (1 - fvGal3Smooth((R - D.MR1) / D.MRW)); }
function fvGf7Info() {
   if (!fvGf7On()) return null; var g6 = fvGf6Info();
   return { lanes: g6 ? g6.lanes : null, barBoost: g6 ? g6.barBoost : null, moat: FV_GAL_GF7.MOAT, dust: FV_GAL_GF7.DUST, lane: FV_GAL_GF7.LANE, vol: FV_GAL_GF7.VOL };
}

// ============================================================================
// (encargo GF8, 10-nov) LA GALAXIA GF7 CORREGIDA tras su revision visual adversaria (docs/encargos-9nov/GF/revision-visual-GF7.md), con las guardas
// nuevas de gfguard (E11 columnas, E12 tono del carril, D12c, N6, F3c, S4 tambien de lado, S5 tambien en el recorte). Subinterruptor FV_GAL_GF8.ON
// (ENCENDIDO por defecto desde el 10-nov-2026). Solo actua ENCIMA de GF7 encendido (y por tanto de GF4, GF5 y GF6); apagado, nada de esto se ejecuta y GF7 sale bit a bit.
// Cada causa MEDIDA antes de tocar; barridos y ELECCIONES en cada bloque; informe en docs/encargos-9nov/GF8-galaxia.md.
// ============================================================================
var FV_GAL_GF8 = {
   ON: true,
   // (1)(2) canto (se suma a FV_GAL_GF7.VOL; solo cambia el rayo de canto, fvGal3RenderVol, |dz| < DZ1: de cara, oblicua y recorte, nada).
   //   SAX (kpc): la parte NO axisimetrica de la luz vieja de la capa gruesa (barra, fosa, carriles de cara, brazos viejos) se apaga con la altura como
   //     e^(−|z|/SAX); por encima del plano queda su media en azimut (fvGf8VolAxi). CAUSA de la costura (E11), medida en node: la luz del rayo de canto sale
   //     del mapa de CARA, con su estructura en todas las alturas (HZ 0,3 kpc + el disco grueso de 900 pc de GF7, ZK 5 -> hasta 1,5 kpc): donde la visual
   //     roza la punta de la barra o el nacimiento de un brazo sale una columna vertical. Hipotesis del revisor CONFIRMADA en parte: GF6, sin disco grueso,
   //     ya daba E11 1,37/1,24 (el disco fino basta); el grueso la sube a 1,74/1,58. SAX 0,3 (la HZ del disco fino): E11 1,74/1,58 -> 0,32/0,19
   //     (node, canto x1 / de lado); E3 1,22/1,52 -> 1,06/1,30. ELECCION de la altura (la barra exterior y los brazos son del disco fino y frio)
   //   KGY: color del polvo para la capa JOVEN en el rayo (1 + KGY·(k − 1)); GF7 la veia con el polvo casi gris (KG 0,1) de toda la capa. HZY: la altura de
   //     la capa joven (Skowron et al. 2019, leido en GF7: cefeidas 73,5 pc dentro de 8 kpc; GF3 0,10). CAUSA del carril azul (E12), medida: la capa joven
   //     (azul) esta en el plano, dentro del carril, y con KG 0,1 el polvo apenas la enrojece. Barrido (node; E12 canto x1 / de lado · S4 peor de canto x3 y de
   //     lado · E3), sobre SAX 0,3:
   //       GF7 (KG 0,1 para todo): +0,05 / +0,40 · 1,43 · 1,22/1,52
   //       KGY 1: −0,10 / +0,14 · 1,40 · 1,06/1,30          KGY 1, HZY 0,0735 (ELEGIDO): −0,08 / +0,14 · 1,38 · 1,14/1,02 (E3 en verde)
   //       KG 0,2 · 0,3 · 0,4 (todo el polvo de canto mas rojo): S4 1,57 · 1,75 · 1,92 (los hilos naranjas de GF7 vuelven) con E12 de lado +0,08 · +0,04 · +0,01
   //       KGY 1,6 · 2,0 · 2,5: E12 de lado 0,00 · −0,07 · −0,14 con S4 1,46 · 1,49 · 1,54; con HZY 0,0735: KGY 1,6 +0,01 / S4 1,39; KGY 2,0 −0,06 / 1,40
   //         (E12 en verde, pero KGY > 1 es una ley de enrojecimiento mas empinada que la del polvo, sin fuente; y salen motas naranjas en el borde del carril)
   //       TY 2 · 3 (la capa joven ve 2 · 3 veces la columna de polvo, nubes natales; NO VERIFICADO, sin fuente leida): E12 de lado +0,08 · +0,05, E3 0,93 · 0,80
   //       KGB 1 (el bulbo tras el carril enrojecido, pantalla): E12 de lado +0,12 y E2b 0,97 (ROJO): descartado, codigo quitado
   //     Lo que queda de azul de lado (+0,14) es luz vieja casi gris (KG 0,1, que deja S4 en verde) frente a un disco de referencia con mas bulbo. FUENTE LEIDA
   //     (de Vaucouleurs Atlas of Galaxies, Buta, Corwin y Odewahn 2007, ficha de NGC 891): «the B-V color index map shows that virtually all of these filaments
   //     are red, but the main dust layer is blue»; lo atribuye a estrellas jovenes en claros de poca extincion y a luz dispersada. El «pardo-negro» del revisor
   //     (de memoria) no lo confirma esa fuente: decision para Nino (informe GF8 §12)
   VOL: { GF8: true, KGY: 1.0, SAX: 0.3, HZY: 0.0735 },
   // (3) bulbo: null = el de GF7. N6 (contraste del nucleo de cara) NO se arregla: barrido (node; N6 · N3):
   //       nucleo a 0,90 / 3,2 (los de GF6): 1,42 · ROJO (ΔB/R 0,07: el pico se blanquea en el hombro de pantalla, la causa por la que GF7 los bajo)
   //       componente 0,35 kpc a 0,40 · 0,48: 1,37 · ROJO;  componente 0,17 a 1,0: 1,39 · ROJO;  0,35 a 0,40 y 0,50 a 0,10: 1,38 · verde
   //       lobulos en u ±1,05 σx 0,5: 1,37 y N1/N2 ROJOS (meseta 19 px);  lobulos a 0,085 (−22 %): 1,39 · verde, E2b 1,04/0,96 (en el borde)
   //     N6 mide Y de PANTALLA: el centro esta en el hombro del tono (L* 85) y mas luz en el nucleo apenas sube Y; lo que lo baja es la luz de los lobulos y de la
   //     barra a 0,5 kpc (los lobulos en u de GF7). Queda en ROJO (pendiente medido)
   BULGE: null,
   // (4) polvo junto al Sol. SMIN = el lado del carril de los brazos MENORES dentro de la corotacion no baja de SMIN; RW (kpc) = ancho de la transicion del
   //     lado del carril en la corotacion (GG.RCR_W 2,0, ELECCION de GG). Hipotesis del revisor (el carril del Brazo Local se sube a su cresta en la corotacion)
   //     medida en node (D12 cara / recorte · D12c · D13):
   //       GF7: 0,42 / 0,38 · 0,43 / 0,40 · 0,23 / 0,18 / L* 15,95
   //       SMIN 0,8 (menores): 0,41 / 0,37 · 0,43 / 0,38 -> REFUTADA para los menores: no son ellos
   //       RCR 99 (carril siempre en el lado concavo, TODOS los brazos; prueba, no fisica): 0,26 / 0,29 · 0,37 / 0,38 · L* 14,3, D8 0,07 (ROJO, negro)
   //       RW 1,0: 0,41 / 0,35 · 0,44 / 0,40 · 0,22 / 0,17 / L* 16,9     RW 0,5: 0,38 / 0,33 · 0,41 / 0,39 · 0,22 / 0,17 / L* 17,5
   //     El lado del carril en la corotacion SI mueve D12 (los mayores fuera de 8,5 kpc), pero ninguna variante fisica lo lleva a 0,28, y RW 0,5 deja un NUDO en
   //     el carril de canto (canto x1 y x3, en la punta de la barra en proyeccion): el carril que cambia de lado en 0,5 kpc es un puente de polvo radial que la
   //     visual recorre de punta (con RW 0 o 1,0 no sale; con SAXN 0,1 o SAX 0,2 sigue: no es la luz vieja). Por eso RW 0 = el de GF7 (DUST sin efecto)
   DUST: { SMIN: 0, RW: 0 },
   // (5) fosa DE CARA (F3c): null = la de GF7; si no, { TINT: [R, G, B] } sustituye a FV_GAL_GF7.MOAT.TINT. De cara la fosa de GF7 sigue caqui a R 2,5–4
   //     (h 78,5–78,7, a* +1,3) con el recorte (F3) en verde. Barrido (node; F3 recorte h / a* · F3c tres anillos h / a*):
   //       GF7 [1,04, 1, 1]: 73,2 / 2,9 · 77,8 / 1,59 · 78,7 / 1,31 · 78,5 / 1,33 (ROJO)
   //       [1,05, 1, 0,99]: 70,9 / 3,4 · 74,3 / 2,1 · 74,8 / 1,8 · 78,5 / 1,33 (ROJO)      [1,05, 1, 0,98]: 72,7 / 3,3 · 76,6 / 1,95 · 77,3 / 1,67 · 78,5 / 1,33 (ROJO)
   //       [1,06, 1, 1] (ELEGIDO): 70,9 / 3,4 · 74,3 / 2,1 · 74,8 / 1,8 · 74,6 / 1,86 (verde); F1 (G/B de la fosa, <= 1,40) 1,39 / 1,37
   //       [1,06, 1, 0,98]: 72,7 / 3,3 · 76,6 / 1,95 · 77,3 / 1,67 · 74,6 / 1,86, pero F1 1,41 / 1,42 (ROJO: menos B sube G/B; medido en node, descartado)
   //       [1,08, 1, 1]: 66,6 / 4,4 (rojo de mas en el recorte)
   //     El anillo 3–4 kpc salta en escalon (pocos pixeles con L* >= 10): hace falta R 1,06. B1 27,6 · B2 18,6 · F2 21,4 / 11,4 · F5 0,08 / 14,1 · X1 1,03 / 0,95
   //     sin cambio. a* del recorte +3,4: por encima del +3 del encargo GF7 (ELECCION; la guarda F3 pide >= +2)
   MOAT: { TINT: [1.06, 1, 1] }
};
function fvGf8On() { return !!(FV_GAL_GF8.ON && fvGf7On()); }
function fvGf8Key() { if (!fvGf8On()) return ""; var F = FV_GAL_GF8; return JSON.stringify(["gf8", F.VOL, F.BULGE, F.DUST, F.MOAT]) + fvGf9Key(); }   // (GF9) "" apagado
function fvGf8Info() {
   if (!fvGf8On()) return null; var g7 = fvGf7Info();
   return { lanes: g7 ? g7.lanes : null, barBoost: g7 ? g7.barBoost : null, vol: FV_GAL_GF8.VOL, dust: FV_GAL_GF8.DUST, bulge: FV_GAL_GF8.BULGE, moat: FV_GAL_GF8.MOAT };
}

// ============================================================================
// (encargo GF9, 10-nov) LA GALAXIA GF8 CORREGIDA tras su revision visual adversaria (docs/encargos-9nov/GF/revision-visual-GF8.md) y las decisiones de
// Nino A–E (encargo GF9). Subinterruptor FV_GAL_GF9.ON (ENCENDIDO por defecto desde el 10-nov-2026). Solo actua ENCIMA de GF8 encendido (y por tanto de GF4…GF7); apagado,
// nada de esto se ejecuta y GF8 sale bit a bit. Cada causa MEDIDA antes de tocar; barridos y ELECCIONES en cada bloque; informe en
// docs/encargos-9nov/GF9-galaxia.md.
// ============================================================================
var FV_GAL_GF9 = {
   ON: true,
   // (D) la fosa DE CARA: dos variantes elegibles con una linea (decision de Nino pendiente). "D1" = el tono de GF7 (TINT [1,04, 1, 1]: el cambio de GF8
   //     a [1,06, 1, 1] no se veia, ΔE ~0,5); "D2" = una fosa mas roja que SI se percibe (ΔE >= 3 frente a GF7, hacia el pardo rojizo de HOY). Por defecto D1
   //   Barrido de D2 (node; tono de la MITAD OSCURA de los anillos R 2–3 · 3–4 kpc a >= 55° de la barra, ΔE76 frente a GF7; de cara y en el recorte ×1,7;
   //   F1 = G/B del recorte · cara; GF7 de cara: h 75,1 / 72,6; HOY de cara h 69,5 / 67,9, y su pardo rojizo h 35–54 en la revision de GF8):
   //     [1,10, 1, 1]: cara ΔE 1,55 / 1,34 (h 65 / 61) · recorte 2,44 / 2,16 · F1 1,36 / 1,40
   //     [1,16, 1, 1]: cara 2,72 / 2,29 (h 58 / 53) · recorte 4,26 / 3,58 · F1 1,35 / 1,34       [1,18, 1, 0,97]: cara 2,67 / 2,19 (el azul bajo resta ΔE)
   //     [1,22, 1, 1]: cara 3,50 / 2,82 (h 53 / 48) · recorte 5,47 / 4,53 · F1 1,29 / 1,30       [1,25, 1, 0,97]: cara 3,33 / 2,71
   //     [1,26, 1, 1] (ELEGIDO: el menor con los DOS anillos >= 3 de cara): cara 3,87 / 3,11 (h 50 / 46) · recorte 6,03 / 4,94 (h 50 / 49) · F1 1,29 / 1,30 ·
   //       F2 21,8 / 11,8 (no levanta negros) · F5 0,06 / 14,6 · sin quemar (S1, S3, N4 0; maximos 247 / 237 / 252)
   //     [1,30, 1, 1]: cara 4,13 / 3,34 (h 48 / 44) · F1 1,26 / 1,24         [1,26, 0,99, 1]: cara 4,07 / 3,23 (h 49 / 45)
   FOSA: "D1",
   MOAT: { D1: [1.04, 1, 1], D2: [1.26, 1, 1] },
   // (A)(E) canto (se suma a FV_GAL_GF8.VOL; solo el rayo de canto, |dz| < DZ1: de cara, oblicua y recorte, nada). Ver fvGf9Tabs (fv_galaxy3d.js).
   //   CAUSA del doble minimo, de la banda gris azulada y de las motas del carril con la barra de lado (cantoL), MEDIDA en node quitando trozos del mapa:
   //     sin alabeo: 0/54 bloques con doble minimo (GF8 22/54) · sin el polvo del lado CERCANO a R > 10 kpc: 1/54 · sin la luz del lado cercano a R > 10: 0/54
   //     y E12 −0,04 · sin la capa JOVEN del lado cercano a R > 10: 1/54, E12 −0,04, motas (E15) 4,3 -> 2,0. Es decir: el disco exterior del lado de la
   //     camara (R 10–16 kpc), ALABEADO (Skowron 2019: hasta −0,5 kpc a R 14 justo en esa direccion), se pone delante del carril: su capa joven, de 73,5 pc,
   //     es la franja clara y las motas (sus nudos enrojecidos), y su polvo, el segundo minimo por debajo. GF8 lo subio (SAX: 14 -> 22 bloques).
   //   YF0, YFS, YFK: el ENSANCHAMIENTO de la capa joven exterior, fY = 1 + YFK·(e^((R − YF0)/YFS) − 1). FUENTES LEIDAS (10-nov): Skowron et al. 2019
   //     (ar5iv 1806.10653, material suplementario): «the flaring of the disk in Cepheids matches that seen in neutral hydrogen» (solo cualitativo: su
   //     fig. S2); Kalberla et al. 2007 (arXiv 0704.3925, resumen): la HWHM del HI «is 60 pc at R=4 kpc and increases to ~2700 pc at R=40 kpc», ×45 en
   //     36 kpc = una escala exponencial de 9,45 kpc (YFS; la forma exponencial entre los dos puntos es ELECCION). YF0 = R0 (el alabeo empieza a ~8 kpc,
   //     Skowron). YFK = 4 es ELECCION: con YFK 1 (el HI relativo tal cual, ×1,5 a R 12) quedan 15/54 bloques; barrido (node, cantoL; E14 bloques · E15
   //     motas · E12 de lado · E11 canto x1):
   //       YFK 1: 15 · 3,8 · +0,15 · 0,33     YFK 2: 2 · 3,0 · +0,10 · 0,38     YFK 3: 2 · 2,7 · +0,09 · 0,35     (con el polvo ensanchado igual, DFS)
   //       lineal desde 9 kpc, 0,5 · 1 · 2 /kpc: 2 · 2 · 1 bloques, pero E11 canto x1 0,45 · 0,81 · 1,06 (la capa joven alta enseña columnas de los brazos)
   //   DFS: el polvo de canto se ensancha igual (fD = e^((R − YF0)/DFS)): el polvo sigue al gas. Drimmel y Spergel 2001 (tabla 1, leida en la investigacion
   //     GR) dan h(R) = 134 pc + 14,8 pc/kpc·(R − 4,4), mas suave (×1,3 a R 12): probado (FLD 1 · 2 · 3): 26 · 18 · 17 bloques, no basta solo
   //   CLS, CLA, CLH: GRUMOS del polvo de canto (PROCEDIMENTAL, declarado: ruido de valor de dos octavas, CLS y CLS/2,5 kpc): columna × e^(CLA·n) con media 1
   //     y altura × e^(CLH·n'). Sin ellos el carril es una banda uniforme de punta a punta (revision de GF8 §1): el polvo del modelo (disco liso de TAUF y el
   //     de los brazos) se integra a lo largo de ~20 kpc y sale liso. FUENTE LEIDA de que el polvo real no es liso: Howk y Savage 1997 (AJ 114, 2463,
   //     resumen en arXiv astro-ph/9709197): en NGC 891, «hundreds of dust absorbing structures far from the mid-plane», visibles hasta |z| < 1,5 kpc. La
   //     forma (ruido de valor, escalas, contrastes) es ELECCION. Barrido (node, cantoL; E18 sT / sW = variacion de la transmision / del grosor del carril a
   //     lo largo; E14; E17 arriba / abajo; E16; vista):
   //       sin grumos: 0,016 / 0,022 · 3 · 0,48 / 0,48 · 40,0 · banda uniforme
   //       CLS 0,6 CLA 0,8 CLH 0,4: 0,035 / 0,064 · 6 · 0,97 / 1,99 · 40,3 · polvo, con bloques de borde vertical
   //       CLS 1,2 CLA 1,0 CLH 0,5: 0,039 / 0,063 · 7 (franja 2,85) · 0,49 / 0,72 · 34,6 (ROJO) · el carril ondula como una serpiente
   //       CLS 0,6 CLA 0,8 CLH 0: 0,036 / 0,056 · 2 · 0,36 / 1,64 · 40,4 · «salchichas» oscuras en cantoZ
   //       CLS 0,35 CLA 0,6 CLH 0,2 (ELEGIDO): 0,032 / 0,045 · 5 · 0,42 / 1,95 · 41,2 · grano fino de polvo, bordes irregulares
   //     El lado de ABAJO del carril (E17 abajo) sube con los grumos: el carril de lado va bajo y sus bordes irregulares caen en 0,45–0,8 kpc. E17 mide ARRIBA
   //     («sobre el carril», encargo GF9) e informa de abajo
   //   KGY 0,8 (sustituye al 1 de GF8): la capa joven ve el polvo un 20 % mas gris que la ley de extincion. La fuente leida en GF8 (atlas de de Vaucouleurs,
   //     ficha de NGC 891) atribuye el azul de la capa principal de polvo a estrellas jovenes en claros y a LUZ DISPERSADA, que el rayo no calcula; la cifra
   //     es ELECCION. Con los grumos, KGY 1: motas (E15) 3,2 (ROJO) · KGY 0,8: 2,8 · KGY 0,6: 2,7 pero E12 de lado +0,22 (mas azul de lo que se pidio mantener)
   //   SAX 0,18 (sustituye al 0,3 de GF8) y RB0, RBW: la luz vieja NO axisimetrica se apaga con la altura como e^(−|z|/SAX) solo FUERA del bulbo en caja; dentro
   //     de RB0 (rampa RBW) conserva su estructura a toda altura. FUENTE de SAX: la barra larga es delgada, h_z ≈ 180 pc (Wegg, Gerhard y Portail 2015; BHG16
   //     §4.3; tabla de la investigacion GR). El bulbo en caja es la parte interior de la barra, gruesa (BHG16 §4.2): RB0 3,5 · RBW 1 es ELECCION. CAUSA del
   //     bulbo de canto mas plano en GF8 (decision E), medida: SAX 0,3 en TODO el disco sustituia por encima del plano la luz de la barra interior por su media
   //     en azimut (la del eje, a lo largo de la visual, es mucho mayor). Barrido (node; E16 bulbo − disco a 3 kpc canto x1 / cantoZ · E11 · E17 arriba):
   //       GF8: 31,6 / 31,4 · 0,33 / 0,20 · 0,61                RB0 1,5: 34,2 · 0,35         RB0 2: 34,6 · 0,43         RB0 3 (SAX 0,3): 38,9 / 38,9 · 0,39 / 0,17 · 0,56
   //       RB0 3, SAX 0,18: 38,1 / 38,0 · 0,42 / 0,14 · 0,35     RB0 3,5, SAX 0,18 (ELEGIDO, sin grumos): 40,1 / 40,0 · 0,42 / 0,14 · 0,35
   //       RB0 2,5 RBW 2, SAX 0,18: 37,6 (ROJO) · SAX 0,12: E16 37,8 (ROJO), E17 0,32
   //   Probado y QUITADO: polvo EXTRAPLANAR como fraccion (2–10 %) del polvo con estructura del mapa en una capa de 0,4 kpc: no da estructura (E18 0,016 igual)
   //     y con el 10 % E17 0,70 (ROJO); SAX solo dentro de R < 6,5 / 8 kpc: E11 canto x1 1,75 / 0,42 (vuelven columnas de los brazos)
   //   YFX: TOPE del ensanchamiento de la capa joven (fY <= YFX; 0 = sin tope, lo ENTREGADO). Sin tope (fY ×4,6 a R 15, ×10 a R 20; el HI de Kalberla, ×2,1
   //     a R 15) el final de un brazo joven en el borde del disco sale de canto x1 como una COLUMNA AZUL de borde vertical en x ~247 px (visto en la revision
   //     propia de GF9, brillo ×2,2). Apagar la capa joven en los ultimos 3–5 kpc antes del borde del volumen (YTW, probado y quitado) no la cambiaba: no es
   //     el borde del volumen. El tope la acorta pero AFILA el extremo del disco (E3, guarda de GF4): barrido (node; E3 izq. · E14 de lado · E15 · E12 de lado ·
   //     E11 canto x1 · columna a la vista):
   //       sin tope (ENTREGADO): 1,08 · 3 · 2,77 · +0,141 · 0,52 · alta     YFX 3,5: 1,18 · 3 · 2,76 · +0,144 · 0,48 · igual     YFX 3,0: 1,26 (ROJO) · 2
   //       YFX 2,5: 1,36 (ROJO) · 2 · 2,77 · +0,154 · 0,42 · la mitad de alta     YFX 2,0: E14 6 (ROJO)     YFX 1,6: E14 11 (ROJO), E15 3,29 (ROJO)
   //     Ninguno acorta la columna sin poner E3 en rojo: queda sin tope (decision para Nino en GF9-galaxia.md)
   VOL: { GF9: true, YF0: 8.15, YFS: 9.45, YFK: 4, YFX: 0, DFS: 9.45, CLS: 0.35, CLA: 0.6, CLH: 0.2, KGY: 0.8, SAX: 0.18, RB0: 3.5, RBW: 1.0 }
};
function fvGf9On() { return !!(FV_GAL_GF9.ON && fvGf8On()); }
function fvGf9Key() { if (!fvGf9On()) return ""; var F = FV_GAL_GF9; return JSON.stringify(["gf9", F.FOSA, F.MOAT, F.VOL]); }
function fvGf9MoatTint() { var M = FV_GAL_GF9.MOAT; return (FV_GAL_GF9.FOSA === "D2") ? M.D2 : M.D1; }
function fvGf9Info() {
   if (!fvGf9On()) return null; var g8 = fvGf8Info();
   return { lanes: g8 ? g8.lanes : null, barBoost: g8 ? g8.barBoost : null, fosa: FV_GAL_GF9.FOSA, tint: fvGf9MoatTint(), vol: FV_GAL_GF9.VOL };
}

// ============================================================================
// (GF11, 12-nov-2026) LA GALAXIA HECHA DE ESTRELLAS. Nino (GP-13): «borrosa y a poca resolucion». Medido y refutado: mas texeles (nitidez 20,48 /
// 20,49 / 20,50), detalle fino encima del mismo mapa liso (GF10) y detalle calculado por pixel (+28–36 % por fotograma). La causa: el mapa pinta
// DENSIDADES suaves. GF11 pinta ESTRELLAS: cientos de miles de puntos con semilla fija en coordenadas galacticas (X, Y, Z en kpc), muestreados del
// MISMO mapa de GF9 (la luz lisa y gruesa, S, y la estructurada y fina, Y, de fvGal3VolSplitPop; el bulbo de sus gausianas), proyectados en cada
// vista con un perfil gausiano subpixel de flujo constante, sobre el mismo mapa ATENUADO (la luz no resuelta: × (1 − FO), × (1 − FY), bulbo × (1 − FB)).
// El color integrado no se mueve (cada estrella lleva el color de la luz que quita; el flujo se conserva). El POLVO TURBULENTO (crestas de ruido de
// varias escalas con semilla fija, en kpc) se aplica a cada estrella una vez al crearla: nunca por pixel de pantalla.
// Motor: fvGf11Get / fvGf11Prep / fvGf11Splat en fv_galaxy3d.js. Bandera APAGADA de fabrica: apagada, GF9 bit a bit.
//   FO, FY, FB: fraccion de la luz S, Y y del bulbo que pasa a estrellas. ELEGIDO: solo la Y (FO 0, NO 0; FB 0). FY 0,75 en la ronda 2 (en la ronda 1, 0,5: con estrellas sueltas 0,75 ponia D9, K2 y K3 en rojo; con las nubes de la ronda 2, no). Las estrellas S (viejas, amarillas)
//        resueltas se ven como grano amarillo, tambien dentro de los carriles de polvo (n12, n13, n16 en el informe); el bulbo, apiñado, no se resuelve.
//   RES: multiplicador de la fraccion resuelta segun la fraccion Y local (y, medida sobre la luz promediada en BR texeles): MAX·(MIN + (1 − MIN)·suave((y − Y0)/YW)).
//        De fabrica plano (1). Probado: hace el fondo del brazo del mismo color pero deja agujeros oscuros con BR 0 y pierde las estrellas azules con BR 8.
//   MX: parte de la luz S que viaja con las estrellas Y (con el color de la mezcla local). De fabrica 0 (con 0,5–1 el brazo se deshace en nubes blancas: B1, D9 rojas)
//   RC: nada resuelto dentro de R0 kpc, rampa suave hasta R1: nucleo y barra interior lisos (sin ella, N1 y N4 en rojo)
// RONDA 2 (12-nov, Nino: «cero grano: que se lea como resolucion, no como sal»). Lo de la ronda 1 era sal: 400 000 estrellas sueltas al azar dentro de cada
//   texel de 62,5 pc (G1r, la fraccion de la alta frecuencia que cambia con la semilla: 0,62 / 0,67 / 0,51 en boton / cara / oblicua, node) y puntos azules
//   saturados. Ahora:
//   PHI: las nubes de estrellas siguen un campo FIJO de crestas en kpc (escalas SC, red propia independiente de SEED): se acepta cada suceso con prob.
//        min(1, (Φ/R0)^K). Nubes coherentes de 0,15–0,6 kpc con borde: estructura, la misma con cualquier semilla
//   LF estrecha (WMAX 4) y 800 000 estrellas: ninguna destaca sola; SIG 0,85 px
//   CMAX: croma maxima por estrella ((max − min)/luminancia): sin puntos azules saturados. BW: solo la luz Y azulada se resuelve (sin grano amarillento en
//        el flanco de la barra): × P0 + (1 − P0)·suave((q − Q0)/QW), q = B/R de la Y relativo a COL_OLD
//   MOVE 1 + MSTRIDE: en movimiento se pintan TODAS las nubes (una de cada MSTRIDE estrellas con su flujo × MSTRIDE): el mismo contenido que parado, sin el
//        salto al parar de la ronda 1 (allí, en movimiento solo las brillantes y el resto liso)
//   RC 2,0–4,0 kpc (ronda 1: 1,2–3,0): con las nubes, la fosa perdia su rojo (F3 a* 1,9 < 2; con 2–4 kpc, 2,83)
//   P1, P2: variantes de «mas brillo en el polvo» (P1 apagada; P2 ENCENDIDA desde el 12-nov, decision de Nino; ver fvGf11Prep (7) y el informe): P1 = zonas de polvo × (1 + K) con el contraste del
//        carril conservado; P2 = la luz lisa S del disco × (1 + K)
//   NO, NY, NB: estrellas de cada poblacion. LF: funcion de luminosidad dN/dw ∝ w^(−A) en [1, WMAX] (media normalizada a 1 por poblacion). ELECCION
//   CL: la luz Y azulada sale en CUMULOS: miembros n ∝ n^(−2) en [N0, N1], radio σ = S0·n^SE kpc, σz = ZF·σ; la fraccion en cumulo sube con el azul
//       q = (B/R de Y)/(B/R de COL_OLD): 0 por debajo de Q0, 1 por encima de Q0 + QW. ELECCION (las asociaciones OB miden 20–100 pc: orden de magnitud)
//   SIG: σ del perfil de cada estrella en pixeles (con 0,7 el pico varia ×1,7 entre centrado y en esquina; el flujo, nada). ZNEAR: f²/(zc² + ZNEAR²)
//   MOVE: fraccion (las MAS BRILLANTES por su peso w) que se pinta en los fotogramas en movimiento; la luz del resto vuelve al mapa de movimiento (bgMove)
//   TURB: polvo turbulento por estrella: Δτ = K·τ_mapa·(c/<c> − 1), c = Σ AMP·(1 − |2n − 1|)^P a las escalas SC (kpc); renormalizado por canal
//   CROWD: APIÑAMIENTO: la fraccion resuelta se multiplica por 1/(1 + (L/Lc)^P), Lc = K × la mediana de la luz del disco (R 3–12 kpc): en el bulbo, la barra y el
//       nucleo casi nada se resuelve (como en una galaxia real), en los brazos si
//   DE CANTO las estrellas se apagan con el peso del rayo por la capa (wM, |dz| < DZ1 ≈ 25°): alli la luz es la de GF9 entera y lisa (ver fvGal3RenderVol)
// ============================================================================
var FV_GAL_GF11 = {
   ON: true,   // (12-nov-2026) ENCENDIDA de fabrica: decision de Nino (ronda 2 + P2)
   FO: 0, FY: 0.75, FB: 0, MX: 0, RES: { MAX: 1, MIN: 1, Y0: 0, YW: 1, BR: 0 }, RC: { R0: 2.0, R1: 4.0 },
   NO: 0, NY: 800000, NB: 40000,
   SEED: 20261112,
   LF: { A: 3, WMAX: 4 }, LFO: { A: 3, WMAX: 8 }, LFB: { A: 3, WMAX: 8 },   // LF de la Y (cumulos); LFO de la S y LFB del bulbo, mas suaves
   // GAM: reparto por MUESTREO DE IMPORTANCIA: el numero de estrellas va como ρ^(1 − γ) y su flujo medio como ρ^γ (ρ: la luz en 3D de GF9; la cuenta en
   //   cada sitio es exacta: flujo × ρ/q). Con γ = 0 (todas iguales) donde hay poca luz cada estrella destaca muchisimo (de canto, una nube de chispas
   //   por encima del disco); el contraste de una estrella frente a su fondo va como ρ^(γ − 1). [S, Y, bulbo]. ELECCION (barrido en el informe)
   GAM: [0.7, 0.3, 0.6],
   CL: { N0: 6, N1: 300, S0: 0.009, SE: 0.5, ZF: 0.35, Q0: 0.9, QW: 1.0 },
   SIG: 0.85, ZNEAR: 0.6,
   MOVE: 1, MSTRIDE: 16, SIGMV: 1.0,
   CMAX: 0.6, BW: { P0: 0.3, Q0: 1.0, QW: 0.6 },
   PHI: { K: 3, R0: 0.7, SC: [0.6, 0.3, 0.15], AMP: [1, 0.7, 0.4], P: 2 },
   P1: null, P2: { K: 0.1, R0: 3, R1: 5 },   // (12-nov, Nino eligio P2: mas resplandor del disco bajo el polvo, K 0,1 entre 3 y 5 kpc)
   TURB: { ON: true, K: 0.6, SC: [0.30, 0.15, 0.075, 0.04], AMP: [1.0, 0.8, 0.6, 0.45], P: 2 },
   CROWD: { K: 12, P: 3 }
};
var FV_GF11_BREAK = "";          // control ROJO de las pruebas: "screen" = cada estrella desplazada al azar segun la CAMARA (grano que no se mueve con la galaxia)
function fvGf11On() { return !!(typeof FV_GAL_GF11 !== "undefined" && FV_GAL_GF11.ON && fvGf9On()); }
function fvGf11Info() { return fvGf11On() ? { FO: FV_GAL_GF11.FO, FY: FV_GAL_GF11.FY, FB: FV_GAL_GF11.FB, NO: FV_GAL_GF11.NO, NY: FV_GAL_GF11.NY, NB: FV_GAL_GF11.NB } : null; }

function fvGgOn() { return !!(FV_GAL_GG.ON && typeof FV_GAL_DATA !== "undefined" && FV_GAL_DATA.ON); }
// la clave de lo construido (para rehacerlo si cambia algo que lo define); "" con la bandera apagada
function fvGgKey() { if (!fvGgOn()) return ""; var G = FV_GAL_GG, F = fvGgFit(); return [F ? F.id : "reid", fvGgLambda(), fvGgRevert(), G.FAR, G.A2, G.PSI2, G.SUN_FADE ? G.SUN_FADE.join("/") : "", G.OLD_MODE, G.OLD_KAPPA, G.OLD_SIG, G.OLD_YW, G.OLD_ARMS.join(","), FV_GAL3_BREAK].join("|") + fvGf2Key(); }   // (GF2) "" apagado
function fvGgFit() { return (typeof FV_GAL_GG_FIT !== "undefined" && FV_GAL_GG_FIT) ? FV_GAL_GG_FIT : null; }
function fvGgRevert() { var F = fvGgFit(); return (F && F.loo && typeof F.loo.revert === "boolean" && !FV_GAL_GG.LAMBDA_FORCE) ? F.loo.revert : FV_GAL_GG.REVERT; }
function fvGgLambda() { var F = fvGgFit(); return (F && F.loo && F.loo.lambda > 0 && !FV_GAL_GG.LAMBDA_FORCE) ? F.loo.lambda : FV_GAL_GG.LAMBDA; }
function fvGgArmDef(id) { var A = FV_GAL3.ARMS; for (var i = 0; i < A.length; ++i) if (A[i].id === id) return A[i]; return null; }
// los parametros de un brazo: los ajustados (si hay ajuste) o los de la tabla 2 de Reid et al. 2019. El 3 kpc lejano lleva los del cercano.
function fvGgP(id, over) {
   if (over && over[id]) return over[id];
   var F = fvGgFit(), src = id === "3kpcF" ? "3kpc" : id, a = fvGgArmDef(id);
   if (F && F.arms && F.arms[src]) { var q = F.arms[src]; return { rk: q.rk, p1: q.p1, p2: q.p2 }; }
   return { rk: a.rk, p1: a.p1, p2: a.p2 };
}
// la media de la inclinacion de la Galaxia: tabla 2 de Reid et al. 2019 ponderada por el tramo con paralajes de cada lado del codo
function fvGgPsiBar() {
   if (FV_GAL_GG.PSI_BAR > 0) return FV_GAL_GG.PSI_BAR;
   var A = FV_GAL3.ARMS, s = 0, w = 0;
   for (var i = 0; i < A.length; ++i) { var a = A[i]; if (a.id === "3kpcF") continue; var w1 = Math.max(0, Math.min(a.bk, a.b1) - a.b0), w2 = Math.max(0, a.b1 - Math.max(a.bk, a.b0)); s += w1 * a.p1 + w2 * a.p2; w += w1 + w2; }
   return w > 0 ? s / w : 10;
}
// ln R de un brazo SIN gemelo en cualquier β: el tramo medido (forma con codo de Reid et al. 2019) y, fuera, la continuacion con la
// inclinacion de su punta (Sgr–Car: 10° por debajo de β = −26°, texto de Reid et al. 2019, como hoy), que vuelve a la media con Λ si REVERT
function fvGgLnFree(a, p, bb, lam) {
   var D2R = Math.PI / 180, G = FV_GAL_GG;
   function meas(b) { var ps = b < a.bk ? p.p1 : p.p2; return Math.log(p.rk) - (b - a.bk) * D2R * Math.tan(ps * D2R); }
   if (bb >= a.b0 && bb <= a.b1) return meas(bb);
   var dir = bb < a.b0 ? -1 : 1, tip = dir < 0 ? a.b0 : a.b1, x = (dir < 0 ? a.b0 - bb : bb - a.b1) * D2R, L = Math.max(1e-3, lam * D2R);
   var tb = Math.tan(fvGgPsiBar() * D2R), rev = fvGgRevert();
   // ∫0^x tan ψ(s) ds con ψ(s) = w(s)·ψ_punta + (1 − w(s))·ψ_media (en tangentes), w = e^(−s/L); por tramos si hay un cambio publicado (lo2)
   function integ(t, x0, x1) { if (!rev) return t * (x1 - x0); return tb * (x1 - x0) + (t - tb) * L * (Math.exp(-x0 / L) - Math.exp(-x1 / L)); }
   var t1 = Math.tan((dir < 0 ? p.p1 : p.p2) * D2R), I;
   if (dir < 0 && a.lo2 && a.lo2[0] < a.b0) {
      var x2 = (a.b0 - a.lo2[0]) * D2R, t2 = Math.tan(a.lo2[1] * D2R);
      I = x <= x2 ? integ(t1, 0, x) : integ(t1, 0, x2) + integ(t2, x2, x);
   } else I = integ(t1, 0, x);
   return meas(tip) - dir * I;      // hacia abajo (β baja) R sube con ψ > 0; hacia arriba, baja
}
// LA TABLA DE UN BRAZO (cada 0,5°): ln R, peso de la luz w (con el lado lejano al FAR), peso geometrico wg (ventana en R; para λ), confianza
// c = w_e (1 en el tramo medido) y σ_lnR (formula 2). over = parametros de prueba (ajuste, validacion); lam = Λ
// (CHAIN) el brazo Exterior es la continuacion del de Norma una vuelta mas fuera: Reid et al. 2019 (§ de los brazos, leido en ar5iv el
// 9-nov-2026): el de Norma «most likely wraps around the far side of the Galactic center and becomes the Outer arm» (el brazo «Norma–
// Exterior» de los modelos de cuatro brazos). Sin esto, la segunda vuelta de Norma caia a 0,3 kpc del
// Exterior medido (brazo doble en la mitad cercana, medido con gg_arms_dump.js). Entre los dos tramos medidos se INTERPOLA (Hermite en ln R con
// la inclinacion de cada punta), no se extrapola; mas alla del Exterior sigue la formula (1). La tabla del Exterior queda vacia.
function fvGgChainOf(id) { var C = FV_GAL_GG.CHAIN; return C ? C[id] : null; }
function fvGgChainSucc(id) { var C = FV_GAL_GG.CHAIN; if (!C) return null; for (var k in C) if (C.hasOwnProperty(k) && C[k].id === id) return k; return null; }
function fvGgArmTable(a, over, lam) {
   var G = FV_GAL_GG, GL = FV_GAL3, st = 0.5, D2R = Math.PI / 180, p = fvGgP(a.id, over), twid = G.TWIN[a.id], full = !!G.FULL[a.id];
   if (fvGgChainSucc(a.id)) return { a: a, b0: 1, b1: 0, st: st, ln: new Float64Array(0), w: new Float32Array(0), wg: new Float32Array(0), c: new Float32Array(0), sg: new Float32Array(0), ab: new Float32Array(0), n: 0, p: p, chained: true };
   if (G.PAIRS) { var pm = fvGgPairOf(a.id); if (pm) { var PT = fvGgPairTable(a, pm, over, lam); if (PT) return PT; } }
   var ch = fvGgChainOf(a.id);
   if (ch) return fvGgChainTable(a, fvGgArmDef(ch.id), ch.off, over, lam);
   var at = twid ? fvGgArmDef(twid) : null, pt = twid ? fvGgP(twid, over) : null, ext = full ? G.EXT_MAX : (a.ext || 0);
   var F = fvGgFit(), sPsi = (F && F.loo && F.loo.sigPsi > 0) ? F.loo.sigPsi : G.SIG_PSI, sSym = (F && F.loo && F.loo.sigSym >= 0) ? F.loo.sigSym : G.SIG_SYM;
   var s0 = (F && F.arms && F.arms[a.id === "3kpcF" ? "3kpc" : a.id] && F.arms[a.id === "3kpcF" ? "3kpc" : a.id].s_ln > 0) ? F.arms[a.id === "3kpcF" ? "3kpc" : a.id].s_ln : G.SIG0;
   var sym = fvGgSymTwin(a, over);
   function side(dir) {
      var out = [], nTw = null, tip = dir < 0 ? a.b0 : a.b1;
      for (var db = st; db <= ext + 1e-9; db += st) {
         var bb = tip + dir * db, lin = fvGgLnFree(a, p, bb, lam), we = fvGgWe(db, lam), lnv = lin;      // (GF2) fvGgWe: C¹ con GF2, e^(−db/Λ) sin
         if (at) {
            if (nTw === null) { var best = 1e9; for (var n = -2; n <= 2; ++n) { var lt0 = fvGgLnOwn(at, pt, bb - 180 + 360 * n, lam, over), dd = Math.abs(lt0 - lin); if (dd < best) { best = dd; nTw = n; } } }
            lnv = we * lin + (1 - we) * fvGgLnOwn(at, pt, bb - 180 + 360 * nTw, lam, over);
         }
         var sw = (sym && at && sym.at === at && -180 + 360 * nTw === sym.off) ? fvGgSymW(lin, db, sym, bb, lam, over) : null, shv = null;
         if (sw) { var hy = fvGgHybrid(a, lnv, we, db, sym, sw); lnv = hy.ln; shv = hy.sh; }
         var R = Math.exp(lnv); if (R < G.R_MIN || R > G.R_MAX) break;
         out.push([bb, lnv, we, fvGgSig(db, dir < 0 ? p.p1 : p.p2, s0), shv]);
      }
      return out;
   }
   var lo = side(-1), hi = side(1), b0 = lo.length ? lo[lo.length - 1][0] : a.b0, b1 = hi.length ? hi[hi.length - 1][0] : a.b1;
   var n = Math.round((b1 - b0) / st) + 1, ln = new Float64Array(n), w = new Float32Array(n), wg = new Float32Array(n), c = new Float32Array(n), sg = new Float32Array(n);
   var SH = sym ? [new Float32Array(n), new Float32Array(n), new Float32Array(n), new Float32Array(n)] : null, sh0 = fvGgOwnShape(a, a.b0);
   function fadeMinor(x) { return 1 - fvGal3Smooth((x / Math.max(1, ext) - 0.35) / 0.65); }   // los menores (local, exterior) se desvanecen como hoy
   for (var k = 0; k < n; ++k) {
      var bb = b0 + k * st, l, cc, sgv, shv = sh0;
      if (bb < a.b0 - 1e-9) { var e1 = lo[Math.max(0, Math.min(lo.length - 1, Math.round((a.b0 - bb) / st) - 1))]; l = e1[1]; cc = e1[2]; sgv = e1[3]; if (e1[4]) shv = e1[4]; }
      else if (bb > a.b1 + 1e-9) { var e2 = hi[Math.max(0, Math.min(hi.length - 1, Math.round((bb - a.b1) / st) - 1))]; l = e2[1]; cc = e2[2]; sgv = e2[3]; if (e2[4]) shv = e2[4]; }
      else { l = fvGgLnFree(a, p, bb, lam); cc = 1; sgv = s0; }
      if (SH) { SH[0][k] = shv[0]; SH[1][k] = shv[1]; SH[2][k] = shv[2]; SH[3][k] = shv[3]; }
      var R = Math.exp(l), win = fvGal3Smooth((R - GL.R_IN) / 1.3) * (1 - fvGal3Smooth((R - 13.5) / 3.2));
      var dx = bb < a.b0 ? a.b0 - bb : (bb > a.b1 ? bb - a.b1 : 0);
      var wl = full ? (cc + (1 - cc) * G.FAR) : (dx > 0 ? fadeMinor(dx) : 1);
      ln[k] = l; w[k] = wl * win; wg[k] = (full ? 1 : wl) * win; c[k] = cc; sg[k] = sgv;
   }
   var T = { a: a, b0: b0, b1: b1, st: st, ln: ln, w: w, wg: wg, c: c, sg: sg, ab: new Float32Array(n), n: n, p: p };
   if (SH) { T.aL = SH[0]; T.aD = SH[1]; T.wk = SH[2]; T.rk = SH[3]; }
   return T;
}
// ln R «propio» de un brazo (sin gemelo) contando la cadena: lo que se usa como GEMELO de otro brazo
function fvGgLnOwn(a, p, bb, lam, over) {
   var ch = fvGgChainOf(a.id); if (!ch) return fvGgLnFree(a, p, bb, lam);
   var o = fvGgArmDef(ch.id), po = fvGgP(ch.id, over), off = ch.off, D2R = Math.PI / 180, oA = o.b0 + off, oB = o.b1 + off;
   if (bb >= a.b0) return fvGgLnFree(a, p, bb, lam);
   if (bb <= oB) return fvGgLnFree(o, po, bb - off, lam);
   var lA = fvGgLnFree(o, po, oB - off, lam), lB = fvGgLnFree(a, p, a.b0, lam), mA = -Math.tan(po.p2 * D2R), mB = -Math.tan(p.p1 * D2R), span = (a.b0 - oB) * D2R;
   var t = (bb - oB) / (a.b0 - oB), t2 = t * t, t3 = t2 * t;
   return (2 * t3 - 3 * t2 + 1) * lA + (t3 - 2 * t2 + t) * span * mA + (-2 * t3 + 3 * t2) * lB + (t3 - t2) * span * mB;
}
// σ_lnR de la formula (2) a Δβ grados de la punta mas cercana con datos
function fvGgSig(db, psi, s0) {
   var G = FV_GAL_GG, F = fvGgFit(), D2R = Math.PI / 180, lam = fvGgLambda(), sPsi = (F && F.loo && F.loo.sigPsi > 0) ? F.loo.sigPsi : G.SIG_PSI, sSym = (F && F.loo && F.loo.sigSym >= 0) ? F.loo.sigSym : G.SIG_SYM;
   var we = Math.exp(-db / lam), xr = db * D2R, sec2 = 1 / Math.pow(Math.cos(Math.min(60, Math.abs(psi)) * D2R), 2);
   if (F && F.loo && F.loo.k > 0) return Math.sqrt(s0 * s0 + Math.pow(F.loo.k * xr, 2));      // la ley EMPIRICA de la validacion dejando tramos fuera
   return Math.sqrt(s0 * s0 + Math.pow(we * xr * sec2 * sPsi * D2R, 2) + Math.pow((1 - we) * xr * sec2 * sSym * D2R, 2));
}
// la tabla de un brazo ENCADENADO (Norma + Exterior una vuelta mas fuera): tramo medido interior, interpolacion, tramo medido exterior y las
// dos continuaciones (formula 1, con el gemelo del brazo interior)
function fvGgChainTable(a, o, off, over, lam) {
   var G = FV_GAL_GG, GL = FV_GAL3, st = 0.5, D2R = Math.PI / 180, p = fvGgP(a.id, over), po = fvGgP(o.id, over), twid = G.TWIN[a.id], at = twid ? fvGgArmDef(twid) : null, pt = twid ? fvGgP(twid, over) : null;
   var F = fvGgFit(), s0a = (F && F.arms && F.arms[a.id] && F.arms[a.id].s_ln > 0) ? F.arms[a.id].s_ln : G.SIG0, s0o = (F && F.arms && F.arms[o.id] && F.arms[o.id].s_ln > 0) ? F.arms[o.id].s_ln : G.SIG0;
   var oA = o.b0 + off, oB = o.b1 + off, ext = G.EXT_MAX;                  // el Exterior en las coordenadas de β del brazo interior
   function lnIn(bb) { return fvGgLnFree(a, p, bb, lam); }
   function lnOut(bb) { return fvGgLnFree(o, po, bb - off, lam); }
   // Hermite entre (oB, ln, pendiente) y (a.b0, ln, pendiente); pendiente d lnR/dβ = −tan ψ (por radian)
   var bA = oB, bB = a.b0, lA = lnOut(bA), lB = lnIn(bB), mA = -Math.tan(po.p2 * D2R), mB = -Math.tan(p.p1 * D2R), span = (bB - bA) * D2R;
   function herm(bb) { var t = (bb - bA) / (bB - bA), t2 = t * t, t3 = t2 * t; return (2 * t3 - 3 * t2 + 1) * lA + (t3 - 2 * t2 + t) * span * mA + (-2 * t3 + 3 * t2) * lB + (t3 - t2) * span * mB; }
   var sym = fvGgSymTwin(a, over);
   function extend(tip, dir, own, psiTip, s0) {
      var out = [], nTw = null;
      for (var db = st; db <= ext + 1e-9; db += st) {
         var bb = tip + dir * db, lin = own(bb), we = fvGgWe(db, lam), lnv = lin;      // (GF2) fvGgWe
         if (at) {
            if (nTw === null) { var best = 1e9; for (var n = -2; n <= 2; ++n) { var dd = Math.abs(fvGgLnOwn(at, pt, bb - 180 + 360 * n, lam, over) - lin); if (dd < best) { best = dd; nTw = n; } } }
            lnv = we * lin + (1 - we) * fvGgLnOwn(at, pt, bb - 180 + 360 * nTw, lam, over);
         }
         var sw = (sym && at && sym.at === at && -180 + 360 * nTw === sym.off) ? fvGgSymW(lin, db, sym, bb, lam, over) : null, shv = null;
         if (sw) { var hy = fvGgHybrid(a, lnv, we, db, sym, sw); lnv = hy.ln; shv = hy.sh; }
         var R = Math.exp(lnv); if (R < G.R_MIN || R > G.R_MAX) break;
         out.push([bb, lnv, we, fvGgSig(db, psiTip, s0), shv]);
      }
      return out;
   }
   var hi = extend(a.b1, 1, lnIn, p.p2, s0a), lo = extend(oA, -1, lnOut, po.p1, s0o);
   var b0 = lo.length ? lo[lo.length - 1][0] : oA, b1 = hi.length ? hi[hi.length - 1][0] : a.b1;
   var n = Math.round((b1 - b0) / st) + 1, ln = new Float64Array(n), w = new Float32Array(n), wg = new Float32Array(n), c = new Float32Array(n), sg = new Float32Array(n), ab = new Float32Array(n);
   var SH = sym ? [new Float32Array(n), new Float32Array(n), new Float32Array(n), new Float32Array(n)] : null;
   for (var k = 0; k < n; ++k) {
      var bb = b0 + k * st, l, cc, sgv, abv, shv = null;
      if (bb > a.b1 + 1e-9) { var e1 = hi[Math.max(0, Math.min(hi.length - 1, Math.round((bb - a.b1) / st) - 1))]; l = e1[1]; cc = e1[2]; sgv = e1[3]; abv = 0; shv = e1[4]; }
      else if (bb >= a.b0 - 1e-9) { l = lnIn(bb); cc = 1; sgv = s0a; abv = 0; }
      else if (bb > oB + 1e-9) { var dA = bb - oB, dB = a.b0 - bb, swg = sym ? fvGgSymW(herm(bb), Math.min(dA, dB), sym, bb, lam, over) : null; l = swg ? swg.ln : herm(bb); if (swg) shv = fvGgMixShape(fvGgOwnShape(a, bb), swg); cc = Math.max(Math.exp(-dA / lam), Math.exp(-dB / lam)); sgv = Math.min(fvGgSig(dA, po.p2, s0o), fvGgSig(dB, p.p1, s0a)); abv = dA / (dA + dB); abv = 1 - abv; }
      else if (bb >= oA - 1e-9) { l = lnOut(bb); cc = 1; sgv = s0o; abv = 1; }
      else { var e2 = lo[Math.max(0, Math.min(lo.length - 1, Math.round((oA - bb) / st) - 1))]; l = e2[1]; cc = e2[2]; sgv = e2[3]; abv = 1; shv = e2[4]; }
      var R = Math.exp(l), win = fvGal3Smooth((R - GL.R_IN) / 1.3) * (1 - fvGal3Smooth((R - 13.5) / 3.2));
      ln[k] = l; w[k] = (cc + (1 - cc) * G.FAR) * win; wg[k] = win; c[k] = cc; sg[k] = sgv; ab[k] = abv;
      if (SH) { var sv = shv || fvGgOwnShape(a, bb); SH[0][k] = sv[0]; SH[1][k] = sv[1]; SH[2][k] = sv[2]; SH[3][k] = sv[3]; }
   }
   var T = { a: a, b0: b0, b1: b1, st: st, ln: ln, w: w, wg: wg, c: c, sg: sg, ab: ab, n: n, p: p, chain: o.id, off: off };
   if (SH) { T.aL = SH[0]; T.aD = SH[1]; T.wk = SH[2]; T.rk = SH[3]; }
   return T;
}
function fvGgTables(over, lam) {
   var L = lam || fvGgLambda();
   if (over) return FV_GAL3.ARMS.map(function(a) { return fvGgArmTable(a, over, L); });
   var key = fvGgKeyTabs(L);
   if (!FV_GAL_GG_TABS || FV_GAL_GG_TABS.key !== key) FV_GAL_GG_TABS = { key: key, t: FV_GAL3.ARMS.map(function(a) { return fvGgArmTable(a, null, L); }) };
   return FV_GAL_GG_TABS.t;
}
function fvGgKeyTabs(L) { var F = fvGgFit(), G = FV_GAL_GG; return [F ? F.id : "reid", L, fvGgRevert(), G.FAR, G.PSI_BAR, G.EXT_MAX, G.SIG_PSI, G.SIG_SYM].join("|") + (fvGf2Geo() ? "|c1:" + FV_GAL_GF2.SEAM_K : ""); }
// muestra de una tabla en bb: [R, w, wg, c, σ_lnR] o null
function fvGgAt(T, bb) {
   if (bb < T.b0 || bb > T.b1) return null;
   var u = (bb - T.b0) / T.st, k = Math.floor(u), f = u - k; if (k >= T.n - 1) { k = T.n - 2; f = 1; } if (k < 0) { k = 0; f = 0; }
   var r = [Math.exp(T.ln[k] * (1 - f) + T.ln[k + 1] * f), T.w[k] * (1 - f) + T.w[k + 1] * f, T.wg[k] * (1 - f) + T.wg[k + 1] * f, T.c[k] * (1 - f) + T.c[k + 1] * f, T.sg[k] * (1 - f) + T.sg[k + 1] * f, T.ab[k] * (1 - f) + T.ab[k + 1] * f];
   if (T.aL) r.push(T.aL[k] * (1 - f) + T.aL[k + 1] * f, T.aD[k] * (1 - f) + T.aD[k + 1] * f, T.wk[k] * (1 - f) + T.wk[k + 1] * f, T.rk[k] * (1 - f) + T.rk[k + 1] * f);
   return r;
}
// la «forma de brazo» de una muestra (anchura y R_kink para fvGal3Sigma / fvGgWidth): la del tramo de que procede (pares) o la del brazo
function fvGgArmShape(T, r) { return (r.length > 8) ? { w: r[8], rk: r[9] } : T.a; }

// la vuelta coherente de un par (maestro m, pareja p): β_maestro = β_pareja + off. La que da una espiral con R decreciente con β y huecos
// con la inclinacion mas cercana a la media (la misma regla que fvGgPairTable). null si ninguna es coherente.
function fvGgPairOff(A, B, over) {
   var D2R = Math.PI / 180, pA = fvGgP(A.id, over), pB = fvGgP(B.id, over), psb = fvGgPsiBar(), best = null, k;
   function meas(d, p, b) { var ps = b < d.bk ? p.p1 : p.p2; return Math.log(p.rk) - (b - d.bk) * D2R * Math.tan(ps * D2R); }
   var segA = [{ b0: A.b0, b1: A.b1, off: 0, d: A, p: pA }], ch = fvGgChainOf(A.id);
   if (ch) { var o = fvGgArmDef(ch.id); segA.push({ b0: o.b0 + ch.off, b1: o.b1 + ch.off, off: ch.off, d: o, p: fvGgP(ch.id, over) }); }
   for (var n = -2; n <= 2; ++n) {
      var sb = { b0: B.b0 - 180 + 360 * n, b1: B.b1 - 180 + 360 * n, off: -180 + 360 * n, d: B, p: pB };
      var L = segA.concat([sb]).sort(function(x, y) { return x.b0 - y.b0; }), okn = true, cost = 0;
      for (k = 0; k + 1 < L.length; ++k) {
         var gap = L[k + 1].b0 - L[k].b1; if (gap <= 0) { okn = false; break; }
         var pit = Math.atan((meas(L[k].d, L[k].p, L[k].b1 - L[k].off) - meas(L[k + 1].d, L[k + 1].p, L[k + 1].b0 - L[k + 1].off)) / (gap * D2R)) / D2R;
         if (pit < 2 || pit > 30) { okn = false; break; } cost += Math.abs(pit - psb);
      }
      if (okn && (!best || cost < best.cost)) best = { cost: cost, off: sb.off };
   }
   return best ? best.off : null;
}
// (1c) distancia (°) de β a los tramos medidos de un brazo (con su cadena)
function fvGgOwnDist(a, bb) {
   var d = bb < a.b0 ? a.b0 - bb : (bb > a.b1 ? bb - a.b1 : 0), ch = fvGgChainOf(a.id);
   if (ch && d > 0) { var o = fvGgArmDef(ch.id), o0 = o.b0 + ch.off, o1 = o.b1 + ch.off, d2 = bb < o0 ? o0 - bb : (bb > o1 ? bb - o1 : 0); if (d2 < d) d = d2; }
   return d;
}
// (1c) el gemelo de un brazo y su desfase: { at, pt, off } con β_gemelo = β + off; null si no es de un par de PAIR
function fvGgSymTwin(a, over) {
   var G = FV_GAL_GG; if (!G.SYMW) return null; var pm = fvGgPairOf(a.id); if (!pm) return null;
   var A = a.id === pm.m ? a : fvGgArmDef(pm.m), B = a.id === pm.p ? a : fvGgArmDef(pm.p), off = fvGgPairOff(A, B, over); if (off === null) return null;
   return pm.role === "A" ? { at: B, pt: fvGgP(B.id, over), off: -off } : { at: A, pt: fvGgP(A.id, over), off: off };
}
// (1c) ln R simetrico en bb fuera del tramo propio: lnOwn y dA del brazo; el gemelo en bb + off. Devuelve { ln, ws (peso propio), tsh (forma
// del gemelo en su β: [L, D, w, R_kink]) }: la luz y la anchura se mezclan con el MISMO peso, para que tambien sean simetricas
function fvGgSymW(lnOwn, dA, tw, bb, lam, over) {
   var bt = bb + tw.off, lnT = fvGgLnOwn(tw.at, tw.pt, bt, lam, over), dB = fvGgOwnDist(tw.at, bt), eA = Math.exp(-dA / lam), eB = Math.exp(-dB / lam);
   return { ln: (eA * lnOwn + eB * lnT) / (eA + eB), ws: eA / (eA + eB), tsh: fvGgOwnShape(tw.at, bt), bb: bb };
}
// la forma propia de un brazo en su β (con su cadena: el Exterior hacia fuera, interpolada en el hueco): [L, D, w, R_kink]
function fvGgOwnShape(a, bb) {
   var e = fvGgArmAmp(a), sh = [e[0], e[1], a.w, a.rk], ch = fvGgChainOf(a.id); if (!ch || bb >= a.b0) return sh;
   var o = fvGgArmDef(ch.id), eo = fvGgArmAmp(o), so = [eo[0], eo[1], o.w, o.rk], oB = o.b1 + ch.off; if (bb <= oB) return so;
   var t = (bb - oB) / (a.b0 - oB); return [so[0] + (sh[0] - so[0]) * t, so[1] + (sh[1] - so[1]) * t, so[2] + (sh[2] - so[2]) * t, so[3] + (sh[3] - so[3]) * t];
}
// (1c) el hibrido: la (1) (propio + gemelo en el desfase coherente del par, peso w_e) hasta SYM_D0 de su dato; la simetrica desde SYM_D1
function fvGgHybrid(a, f1, we, db, tw, sw) {
   var G = FV_GAL_GG, g = 1 - fvGal3Smooth((db - G.SYM_D0) / (G.SYM_D1 - G.SYM_D0)), bb = sw.bb;
   var own = fvGgOwnShape(a, bb), tsh = sw.tsh, s1 = [we * own[0] + (1 - we) * tsh[0], we * own[1] + (1 - we) * tsh[1], we * own[2] + (1 - we) * tsh[2], we * own[3] + (1 - we) * tsh[3]], ss = fvGgMixShape(own, sw);
   return { ln: g * f1 + (1 - g) * sw.ln, sh: [g * s1[0] + (1 - g) * ss[0], g * s1[1] + (1 - g) * ss[1], g * s1[2] + (1 - g) * ss[2], g * s1[3] + (1 - g) * ss[3]] };
}
function fvGgMixShape(own, r) { if (!r) return own; var w = r.ws; return [w * own[0] + (1 - w) * r.tsh[0], w * own[1] + (1 - w) * r.tsh[1], w * own[2] + (1 - w) * r.tsh[2], w * own[3] + (1 - w) * r.tsh[3]]; }
// (1b) LOS PARES SIMETRICOS: ver la cabecera
function fvGgPairOf(id) { var P = FV_GAL_GG.PAIR; if (!P) return null; for (var m in P) if (P.hasOwnProperty(m)) { if (m === id) return { m: m, p: P[m], role: "A" }; if (P[m] === id) return { m: m, p: P[m], role: "B" }; } return null; }
function fvGgPairTable(a, pm, over, lam) {
   var G = FV_GAL_GG, GL = FV_GAL3, st = 0.5, D2R = Math.PI / 180, F = fvGgFit(), k, q;
   var A = a.id === pm.m ? a : fvGgArmDef(pm.m), B = a.id === pm.p ? a : fvGgArmDef(pm.p), pA = fvGgP(A.id, over), pB = fvGgP(B.id, over);
   function s0of(id) { var e = F && F.arms && F.arms[id]; return (e && e.s_ln > 0) ? e.s_ln : G.SIG0; }
   function meas(d, p, b) { var ps = b < d.bk ? p.p1 : p.p2; return Math.log(p.rk) - (b - d.bk) * D2R * Math.tan(ps * D2R); }
   function psiAt(d, p, b) { return b < d.bk ? p.p1 : p.p2; }
   // los tramos en las β de S (= las del maestro): β_S = β_brazo + off
   var segA = [{ b0: A.b0, b1: A.b1, off: 0, d: A, p: pA, own: "A" }], ch = fvGgChainOf(A.id);
   if (ch) { var o = fvGgArmDef(ch.id); segA.push({ b0: o.b0 + ch.off, b1: o.b1 + ch.off, off: ch.off, d: o, p: fvGgP(ch.id, over), own: "A" }); }
   var psb = fvGgPsiBar(), best = null;
   for (var n = -2; n <= 2; ++n) {
      var sb = { b0: B.b0 - 180 + 360 * n, b1: B.b1 - 180 + 360 * n, off: -180 + 360 * n, d: B, p: pB, own: "B" };
      var L = segA.concat([sb]).sort(function(x, y) { return x.b0 - y.b0; }), okn = true, cost = 0;
      for (k = 0; k + 1 < L.length; ++k) {
         var gap = L[k + 1].b0 - L[k].b1; if (gap <= 0) { okn = false; break; }
         var l1 = meas(L[k].d, L[k].p, L[k].b1 - L[k].off), l2 = meas(L[k + 1].d, L[k + 1].p, L[k + 1].b0 - L[k + 1].off), pit = Math.atan((l1 - l2) / (gap * D2R)) / D2R;
         if (pit < 2 || pit > 30) { okn = false; break; } cost += Math.abs(pit - psb);
      }
      if (okn && (!best || cost < best.cost)) best = { L: L, cost: cost, n: n, offB: sb.off };
   }
   if (!best) return null;                                   // sin espiral coherente: la formula (1) de siempre
   var Ls = best.L, S0 = Ls[0], S1 = Ls[Ls.length - 1], ext = G.EXT_MAX, Lr = Math.max(1e-3, lam * D2R), tb = Math.tan(psb * D2R), rev = fvGgRevert();
   function integ(t, x) { if (!rev) return t * x; return tb * x + (t - tb) * Lr * (1 - Math.exp(-x / Lr)); }
   function amp(d) { return fvGgArmAmp(d); }
   // las muestras de S: [β_S, ln R, aL, aD, w, rk]
   var lnLo = meas(S0.d, S0.p, S0.b0 - S0.off), tLo = Math.tan(psiAt(S0.d, S0.p, S0.b0 - S0.off) * D2R), lnHi = meas(S1.d, S1.p, S1.b1 - S1.off), tHi = Math.tan(psiAt(S1.d, S1.p, S1.b1 - S1.off) * D2R);
   var lo = [], hi = [];
   for (var db = st; db <= ext + 1e-9; db += st) { var lv = lnLo + integ(tLo, db * D2R); if (Math.exp(lv) > G.R_MAX) break; lo.push(lv); }
   for (db = st; db <= ext + 1e-9; db += st) { var hv = lnHi - integ(tHi, db * D2R); if (Math.exp(hv) < G.R_MIN) break; hi.push(hv); }
   var b0 = S0.b0 - lo.length * st, b1 = S1.b1 + hi.length * st, N = Math.round((b1 - b0) / st) + 1;
   var ln = new Float64Array(N), aL = new Float32Array(N), aD = new Float32Array(N), wk = new Float32Array(N), rk = new Float32Array(N);
   for (k = 0; k < N; ++k) {
      var bb = b0 + k * st, done = false;
      if (bb < S0.b0 - 1e-9) { ln[k] = lo[Math.max(0, Math.min(lo.length - 1, Math.round((S0.b0 - bb) / st) - 1))]; var e0 = amp(S0.d); aL[k] = e0[0]; aD[k] = e0[1]; wk[k] = S0.d.w; rk[k] = S0.d.rk; continue; }
      if (bb > S1.b1 + 1e-9) { ln[k] = hi[Math.max(0, Math.min(hi.length - 1, Math.round((bb - S1.b1) / st) - 1))]; var e1 = amp(S1.d); aL[k] = e1[0]; aD[k] = e1[1]; wk[k] = S1.d.w; rk[k] = S1.d.rk; continue; }
      for (q = 0; q < Ls.length && !done; ++q) {
         var sg = Ls[q];
         if (bb >= sg.b0 - 1e-9 && bb <= sg.b1 + 1e-9) { ln[k] = meas(sg.d, sg.p, bb - sg.off); var e2 = amp(sg.d); aL[k] = e2[0]; aD[k] = e2[1]; wk[k] = sg.d.w; rk[k] = sg.d.rk; done = true; }
         else if (q + 1 < Ls.length && bb > sg.b1 && bb < Ls[q + 1].b0) {
            var nx = Ls[q + 1], bA = sg.b1, bB = nx.b0, lA = meas(sg.d, sg.p, bA - sg.off), lB = meas(nx.d, nx.p, bB - nx.off);
            var mA = -Math.tan(psiAt(sg.d, sg.p, bA - sg.off) * D2R), mB = -Math.tan(psiAt(nx.d, nx.p, bB - nx.off) * D2R), span = (bB - bA) * D2R;
            var t = (bb - bA) / (bB - bA), t2 = t * t, t3 = t2 * t, ea = amp(sg.d), eb = amp(nx.d);
            ln[k] = (2 * t3 - 3 * t2 + 1) * lA + (t3 - 2 * t2 + t) * span * mA + (-2 * t3 + 3 * t2) * lB + (t3 - t2) * span * mB;
            aL[k] = ea[0] + (eb[0] - ea[0]) * t; aD[k] = ea[1] + (eb[1] - ea[1]) * t; wk[k] = sg.d.w + (nx.d.w - sg.d.w) * t; rk[k] = sg.d.rk + (nx.d.rk - sg.d.rk) * t; done = true;
         }
      }
   }
   // el miembro pedido: sus β = β_S − off; su confianza y su σ, por la distancia a SUS tramos medidos
   var role = a.id === pm.m ? "A" : "B", offM = role === "A" ? 0 : best.offB, own = Ls.filter(function(x) { return x.own === role; });
   var w = new Float32Array(N), wg = new Float32Array(N), c = new Float32Array(N), sgm = new Float32Array(N), ab = new Float32Array(N);
   for (k = 0; k < N; ++k) {
      var bs = b0 + k * st, dmin = 1e9, near = own[0], dpsi = 0;
      for (q = 0; q < own.length; ++q) { var x = own[q], dd = bs < x.b0 ? x.b0 - bs : (bs > x.b1 ? bs - x.b1 : 0); if (dd < dmin) { dmin = dd; near = x; dpsi = psiAt(x.d, x.p, (bs < x.b0 ? x.b0 : (bs > x.b1 ? x.b1 : bs)) - x.off); } }
      var cc = Math.exp(-dmin / lam), R = Math.exp(ln[k]), win = fvGal3Smooth((R - GL.R_IN) / 1.3) * (1 - fvGal3Smooth((R - 13.5) / 3.2));
      c[k] = cc; sgm[k] = dmin > 0 ? fvGgSig(dmin, dpsi, s0of(near.d.id)) : s0of(near.d.id);
      w[k] = (cc + (1 - cc) * G.FAR) * win; wg[k] = win;
   }
   return { a: a, b0: b0 - offM, b1: b1 - offM, st: st, ln: ln, w: w, wg: wg, c: c, sg: sgm, ab: ab, aL: aL, aD: aD, wk: wk, rk: rk, n: N, p: fvGgP(a.id, over), pair: { m: pm.m, p: pm.p, n: best.n, offB: best.offB, role: role } };
}
function fvGgArmPoint(id, bb) {
   var t = fvGgTables(), pr = fvGgChainSucc(id); if (pr) { bb += FV_GAL_GG.CHAIN[pr].off; id = pr; }
   for (var i = 0; i < t.length; ++i) if (t[i].a.id === id) { var r = fvGgAt(t[i], bb); if (!r) return null; var b = (FV_GAL3_BREAK === "beta" ? -bb : bb) * Math.PI / 180; return [-r[0] * Math.cos(b), r[0] * Math.sin(b)]; }
   return null;
}
// la anchura (1σ) de un brazo de gas: Reid et al. 2019, w(R) = w(R_kink) + 42 pc/kpc·(R − R_kink) (tabla 2 y §3, ar5iv 9-nov-2026), × escala
// ajustada por tipo de trazador; sin brazo, la ley media W_REID
function fvGgWidth(R, s, a) { var W = FV_GAL_GG.W_REID, w = a ? a.w + 0.042 * (R - a.rk) : W[0] + W[1] * (R - FV_GAL3.R0); return Math.max(0.10, w * (s || 1)); }
// la fase del m = 2 viejo (radianes): la del ajuste (anclada a Scutum-Centaurus y Perseo) o, sin ajuste, la media de sus tramos medidos
// el color de la luz de los brazos viejos (opcion B): mezcla (1 − OLD_YW)·vieja + OLD_YW·joven, con el canal mayor en 1
function fvGgRidgeCol(cO, cY) {
   var w = fvGf2On() ? FV_GAL_GF2.RIDGE_YW : FV_GAL_GG.OLD_YW, c = [(1 - w) * cO[0] + w * cY[0], (1 - w) * cO[1] + w * cY[1], (1 - w) * cO[2] + w * cY[2]], m = Math.max(c[0], c[1], c[2]);
   return [c[0] / m, c[1] / m, c[2] / m];
}
function fvGgM2Phase(tabs) {
   var F = fvGgFit(); if (F && F.m2 && isFinite(F.m2.phase)) return F.m2.phase;
   var t = tabs || fvGgTables(), cs = 0, sn = 0, k2 = 1 / Math.tan(FV_GAL_GG.PSI2 * Math.PI / 180);
   for (var i = 0; i < t.length; ++i) { var T = t[i]; if (T.a.id !== "scucen" && T.a.id !== "perseus") continue;
      for (var k = 0; k < T.n; ++k) { var bb = T.b0 + k * T.st; if (bb < T.a.b0 || bb > T.a.b1) continue; var ph = 2 * (bb * Math.PI / 180 + T.ln[k] * k2); cs += Math.cos(ph); sn += Math.sin(ph); } }
   return Math.atan2(sn, cs);
}
// el factor m = 2 del disco viejo en (X, Y): 1 + A2·cos(2·(β + ln R / tan ψ2) − φ2), con arranque suave fuera de la barra
function fvGgM2(X, Y, ph) {
   var G = FV_GAL_GG, R = Math.sqrt(X * X + Y * Y); if (R < 0.3) return 1;
   var b = fvGal3Beta(X, Y) * Math.PI / 180, arg = 2 * (b + Math.log(R) / Math.tan(G.PSI2 * Math.PI / 180)) - ph;
   return 1 + G.A2 * fvGal3Smooth((R - G.M2_R0) / G.M2_RW) * Math.cos(arg);
}

// ---------------------------------------------------------------------------
// EL MAPA DE CARA DEL MODELO AJUSTADO (copia adaptada de fvGal3TexStep, que no se toca): brazos completos con su gemelo, polvo en el lado
// del choque segun la corotacion, nudos HII aguas abajo y el m = 2 del disco viejo. Mismo formato que fvGal3Tex(). Por trozos.
// ---------------------------------------------------------------------------
function fvGgTexBegin(amp) {
   var G = FV_GAL3, N = G.TEX_N, n2 = N * N, NR = 480, NBt = 1080;
   return { amp: amp || null, jb: 0, j: 0, k: 0, ms: 0, done: false, R_: new Float32Array(n2), G_: new Float32Array(n2), B_: new Float32Array(n2), Du: new Float32Array(n2), Ar: new Float32Array(n2), AD: new Float32Array(n2),
            PY: new Float32Array(NR * NBt), PD: new Float32Array(NR * NBt), PO: (FV_GAL_GG.OLD_MODE === "B") ? new Float32Array(NR * NBt) : null, OF: (FV_GAL_GG.OLD_MODE === "B") ? new Float32Array(n2) : null, NR: NR, NBt: NBt, T: null,
            gf2: fvGf2On(), BX: fvGf2On() ? new Float32Array(n2) : null, LD: fvGf2On() ? new Float32Array(n2) : null, barL: [0, 0, 0],     // (GF2) barra (luz vieja) y polvo de sus lineas, por texel
            gf3: fvGf3On(), PM: fvGf3On() ? new Float32Array(NR * NBt) : null,       // (GF3) la cresta de luz de los brazos menores
            gf4: fvGf4On(), gf5: fvGf5On(), gf6: fvGf6On(), gf7: fvGf7On(), gf8: fvGf8On(), gf9: fvGf9On() };         // (GF4) (GF5) (GF6) (GF7) (GF8) (GF9)
}
// la amplitud de un brazo en la imagen: L (jovenes) y D (polvo); con ajuste, la relativa ajustada de HII y de nubes (Scutum-Centaurus = 1)
function fvGgArmAmp(a) {
   var F = fvGgFit(), id = a.id === "3kpcF" ? "3kpc" : a.id;
   if (!F || !F.img || !F.img[id]) return [a.L, a.D];
   return [F.img[id].L, F.img[id].D];
}
function fvGgTexStep(BS, ms) {
   if (BS.done) return true;
   var G = FV_GAL3, GG = FV_GAL_GG, N = G.TEX_N, H = G.TEX_H, px = 2 * H / N, t0 = Date.now(), NR = BS.NR, NBt = BS.NBt, i, j;
   var R_ = BS.R_, G_ = BS.G_, B_ = BS.B_, Du = BS.Du, Ar = BS.Ar, AD = BS.AD, cO = G.COL_OLD, cY = G.COL_YOUNG, kd = G.DUST_RGB;
   function over() { return ms > 0 && Date.now() - t0 > ms; }
   var dRp = H / NR, PY = BS.PY, PD = BS.PD, PO = BS.PO, oldIds = GG.OLD_ARMS, tabs0 = fvGgTables(), q, kk;
   if (!BS.amps) BS.amps = tabs0.map(function(T) { var a0 = fvGgArmAmp(T.a); if (T.chain) { var a1 = fvGgArmAmp(fvGgArmDef(T.chain)); return [a0[0], a0[1], a1[0], a1[1]]; } return [a0[0], a0[1], a0[0], a0[1]]; });
   if (BS.gf4 && !BS.hk) { BS.hk = BS.gf5 ? fvGf4Hooks(tabs0, FV_GAL_GF5.LANE.R_J) : fvGf4Hooks(tabs0); BS.hkq = {}; for (q = 0; q < BS.hk.length; ++q) BS.hkq[BS.hk[q].q] = true; }   // (GF4) los ganchos, antes del bucle polar
   for (var jb = BS.jb; jb < NBt; ++jb) {
      if (over()) { BS.jb = jb; BS.ms += Date.now() - t0; return false; }
      var beta = -180 + 360 * jb / NBt, base = jb * NR;
      for (q = 0; q < tabs0.length; ++q) for (kk = -2; kk <= 1; ++kk) {
         var ra = fvGgAt(tabs0[q], beta + 360 * kk); if (!ra || ra[1] <= 0) continue;
         var A0 = fvGgArmShape(tabs0[q], ra), s = fvGal3Sigma(A0, ra[0]), sd = 0.32 * s;
         // el polvo en el borde INTERIOR (concavo) dentro de la corrotacion y en el EXTERIOR fuera, con una transicion suave (Roberts 1969)
         var side = 1 - 2 * fvGal3Smooth((ra[0] - GG.RCR + 0.5 * GG.RCR_W) / GG.RCR_W);
         if (BS.gf8 && FV_GAL_GF8.DUST.RW > 0) side = 1 - 2 * fvGal3Smooth((ra[0] - GG.RCR + 0.5 * FV_GAL_GF8.DUST.RW) / FV_GAL_GF8.DUST.RW);   // (GF8) (4) transicion del lado del carril mas corta
         if (BS.gf8 && FV_GAL_GF8.DUST.SMIN > 0 && ra[0] < GG.RCR && oldIds.indexOf(tabs0[q].a.id) < 0) side = Math.max(side, FV_GAL_GF8.DUST.SMIN);   // (GF8) (4) el carril de los menores no se sube a su cresta junto al Sol
         var sh =(FV_GAL3_BREAK === "dustout" ? -0.45 : 0.45) * (BS.gf2 ? FV_GAL_GF2.ARM_SH / 0.45 : 1) * s * side;   // (GF2) el carril, en el borde del brazo
         var ir0 = Math.max(0, Math.floor((ra[0] - 4 * s) / dRp)), ir1 = Math.min(NR - 1, Math.ceil((ra[0] + 4 * s) / dRp)), aL = (ra.length > 8 ? ra[6] : BS.amps[q][0] + (BS.amps[q][2] - BS.amps[q][0]) * ra[5]) * ra[1], aD = (ra.length > 8 ? ra[7] : BS.amps[q][1] + (BS.amps[q][3] - BS.amps[q][1]) * ra[5]) * ra[1], i2s = 0.5 / (s * s), i2d = 0.5 / (sd * sd);
         if (BS.gf2) { var Rv = Math.max(ra[0], FV_GAL_GF2.ENV_R) - G.R0, DS = FV_GAL_GF2.DESERT, dmn = BS.gf3 ? FV_GAL_GF3.DESERT_FLOOR : DS.MIN, dmd = BS.gf3 ? FV_GAL_GF3.DESERT_FLOOR : DS.DMIN, ds = dmn + (1 - dmn) * fvGal3Smooth((ra[0] - DS.R0) / (DS.R1 - DS.R0)), dd = dmd + (1 - dmd) * fvGal3Smooth((ra[0] - DS.D0) / (DS.D1 - DS.D0));
            if (BS.gf4 && BS.hkq[q]) dd = BS.gf5 ? fvGf4HookW(BS.hk, q, beta + 360 * kk, FV_GAL_GF5.LANE.DJ) : fvGf4HookW(BS.hk, q, beta + 360 * kk);   // (GF4) (GF5) brazo viejo con gancho: su polvo, entero pasada la union (antes la pinta el gancho)
            aL *= ds * Math.exp(-Rv / G.HR_OLD); aD *= dd * Math.exp(-Rv / FV_GAL_GF2.ENV_HD);   // (GF2) los brazos siguen al disco: sin diana en las afueras
            if (BS.gf6 && oldIds.indexOf(tabs0[q].a.id) >= 0) { var D6 = FV_GAL_GF6.DUST, w6 = fvGal3Smooth((ra[0] - D6.OR0) / D6.ORW);
               if (BS.gf7) w6 *= 1 - fvGal3Smooth((ra[0] - FV_GAL_GF7.DUST.CV0) / FV_GAL_GF7.DUST.CVW);                                      // (GF7) (3) sin refuerzo en el borde de Perseo junto al Sol
               aD *= 1 + D6.OB * w6;   // (GF6) (2) polvo de los mayores, fuera:
               if (D6.OW) { var sd6 = sd * (1 + D6.OW * w6); i2d = 0.5 / (sd6 * sd6); }                                                           // mas τ y carril mas estrecho (OW < 0)
               if (D6.OS) sh *= 1 + D6.OS * w6; }                                                                                                  // y mas apartado de la cresta (OS)
            if (BS.gf3 && oldIds.indexOf(tabs0[q].a.id) < 0) {      // (GF3) brazos menores: polvo y luz con su angulo de paso; luz en una cresta propia (PM)
               var M3 = FV_GAL_GF3.MINOR, pw3 = fvGf3PitchW(tabs0[q], beta + 360 * kk), ml3 = FV_GAL_GF3.ML[tabs0[q].a.id] || 0, sm3 = FV_GAL_GF3.ML_SIG;
               if (BS.gf4) { var isL4 = tabs0[q].a.id === "local", L4 = FV_GAL_GF4.LOCAL; pw3 = fvGf4PitchW(tabs0[q], beta + 360 * kk);   // (GF4) (7)(8)
                  if (isL4) { var wL4 = fvGf4LocalW(tabs0[q], beta + 360 * kk); ml3 = L4.ML; sm3 = L4.SIG; aL *= wL4; aD *= L4.DK * wL4; } }
               aD *= (BS.gf5 ? FV_GAL_GF5.DUST.MD * M3.D : M3.D) * (M3.FLOOR * fvGf3EndW(tabs0[q], beta + 360 * kk) + (1 - M3.FLOOR) * pw3);   // (GF5) × MD
               if (BS.gf7) { var D7 = FV_GAL_GF7.DUST, w7 = fvGf7MinorW(ra[0]); if (w7 > 0) { aD *= 1 + (D7.MB + (tabs0[q].a.id === "local" ? D7.LB : 0)) * w7;                           // (GF7) (2) polvo de los menores junto al Sol
                  if (D7.MW) { var sd7 = sd * (1 + D7.MW * w7); i2d = 0.5 / (sd7 * sd7); } } }                                                      // y su carril (MW < 0: mas estrecho)
               if (ml3 > 0) { var ism3 = 0.5 / (sm3 * sm3), am3 = ml3 * pw3 * ds * ra[1], mr0 = Math.max(0, Math.floor((ra[0] - 4 * sm3) / dRp)), mr1 = Math.min(NR - 1, Math.ceil((ra[0] + 4 * sm3) / dRp));
                  for (var mr = mr0; mr <= mr1; ++mr) { var dRm = (mr + 0.5) * dRp - ra[0]; BS.PM[base + mr] += am3 * Math.exp(-dRm * dRm * ism3); } }
            }
         }
         for (var ir = ir0; ir <= ir1; ++ir) { var dR = (ir + 0.5) * dRp - ra[0], dd = dR + sh; PY[base + ir] += aL * Math.exp(-dR * dR * i2s); PD[base + ir] += aD * Math.exp(-dd * dd * i2d); }
         // (GF, opcion B) la luz VIEJA de los dos brazos mayores: perfil gaussiano de σ OLD_SIG alrededor del eje, con el peso del brazo (lado lejano al FAR)
         if (PO && oldIds.indexOf(tabs0[q].a.id) >= 0) {
            var so = GG.OLD_SIG, iso = 0.5 / (so * so), jr0 = Math.max(0, Math.floor((ra[0] - 4 * so) / dRp)), jr1 = Math.min(NR - 1, Math.ceil((ra[0] + 4 * so) / dRp));
            var wo = BS.gf2 ? fvGal3Smooth(ra[0] - FV_GAL_GF2.OLD_R0 + 0.5) : 1;      // (GF2) nacen en los extremos de la barra (Benjamin 2008)
            for (var jr = jr0; jr <= jr1; ++jr) { var dRo = (jr + 0.5) * dRp - ra[0]; PO[base + jr] += wo * ra[1] * Math.exp(-dRo * dRo * iso); }
         }
      }
   }
   BS.jb = NBt;
   if (BS.ph === undefined) BS.ph = fvGgM2Phase(tabs0);
   var cR = fvGgRidgeCol(cO, cY);
   // (GF3) la luz de las crestas se conserva: κ de los mayores × k3 = S_may/(S_may + S_men), S = ∫ disco viejo(R)·cresta dA (el color integrado no se mueve)
   function oldR(R) { return Math.exp(-R / G.HR_OLD) * (1 - Math.exp(-R * R / (2.6 * 2.6))) * (1 - fvGal3Smooth((R - 15) / 4.5)) * fvGf2Sweep(R); }
   if (BS.gf3 && BS.k3 === undefined) {
      var sMj = 0, sMn = 0;
      for (var ir3 = 0; ir3 < NR; ++ir3) { var R3 = (ir3 + 0.5) * dRp, ow3 = R3 * oldR(R3); for (var jb3 = 0; jb3 < NBt; ++jb3) { sMj += ow3 * PO[jb3 * NR + ir3]; sMn += ow3 * BS.PM[jb3 * NR + ir3]; } }
      BS.k3 = sMj / Math.max(1e-12, sMj + sMn);
      if (BS.gf4) { BS.k3g3 = BS.k3; BS.k3 = BS.gf5 ? FV_GAL_GF5.K3 : FV_GAL_GF4.K3; var l4 = BS.gf5 ? fvGf5LaneMap(tabs0, BS.hk, BS.amps, N, H) : fvGf4LaneMap(tabs0, BS.hk, BS.amps, N, H); BS.LM = l4.tau; BS.lanes = l4.curves; }   // (GF4) crestas enteras; ganchos (GF5: el suyo)
      else { var l3 = fvGf3LaneMap(tabs0, N, H); BS.LM = l3.tau; BS.lanes = l3.curves; }
   }
   // (GF6) (1) la luz que la fosa quita al disco liso pasa a la barra EN EL MISMO TRAMO DE RADIO (ventana fvGf6MoatR: el nucleo no se toca; con la barra
   // entera × 1,12 el nucleo cogia meseta, N2 9 -> 10 px): barra × (1 + mBoost·ventana(R)), mBoost = Σ quitado / Σ barra·ventana (rejilla de 4 en 4: unos ms)
   if (BS.gf6 && BS.mBoost === undefined) {
      var sQ6 = 0, sB6 = 0, M6 = fvGf6M();   // (GF7) la de GF7 si esta encendido
      for (var j6 = 0; j6 < N; j6 += 4) { var Y6 = -H + (j6 + 0.5) * px; for (var i6 = 0; i6 < N; i6 += 4) { var X6 = -H + (i6 + 0.5) * px, R6 = Math.sqrt(X6 * X6 + Y6 * Y6); if (R6 > 8) continue;
         var w6 = fvGf6MoatW(X6, Y6, R6); if (w6 > 0) sQ6 += oldR(R6) * M6.D * w6; sB6 += fvGf2Bar(X6, Y6)[0] * fvGf6MoatR(R6); } }
      BS.mBoost = sQ6 / Math.max(1e-9, sB6);   // (quitando la luz sin pasarla a la barra, el B/G en pantalla subia a 0,90: X2 rojo, medido en node)
   }
   function polar(arr, R, beta) {
      var u = R / dRp - 0.5, v = (beta + 180) / 360 * NBt, i0 = Math.floor(u), j0 = Math.floor(v), fu = u - i0, fv = v - j0;
      if (i0 < 0) { i0 = 0; fu = 0; } if (i0 >= NR - 1) { i0 = NR - 2; fu = 1; }
      var j1 = (j0 + 1) % NBt; j0 = ((j0 % NBt) + NBt) % NBt;
      return (arr[j0 * NR + i0] * (1 - fu) + arr[j0 * NR + i0 + 1] * fu) * (1 - fv) + (arr[j1 * NR + i0] * (1 - fu) + arr[j1 * NR + i0 + 1] * fu) * fv;
   }
   for (j = BS.j; j < N; ++j) {
      if (over()) { BS.j = j; BS.ms += Date.now() - t0; return false; }
      var Y = -H + (j + 0.5) * px;
      for (i = 0; i < N; ++i) {
         var X = -H + (i + 0.5) * px, R = Math.sqrt(X * X + Y * Y), o = j * N + i;
         if (R > H) continue;
         var bt = fvGal3Beta(X, Y);
         // el disco viejo: con la opcion A, el m = 2 sinusoidal de la Via Lactea; con la B, liso mas la luz vieja de los dos brazos mayores (1 + κ en el eje)
         var oldFac = PO ? 1 : fvGgM2(X, Y, BS.ph), ridge = PO ? GG.OLD_KAPPA * (BS.gf3 ? BS.k3 * (polar(PO, R, bt) + polar(BS.PM, R, bt)) : polar(PO, R, bt)) : 0;   // (GF3) + la cresta de los menores
         if (PO) BS.OF[o] = ridge;                                   // la mezcla (fvGgMixRow2) lo necesita para restar la misma luz de los brazos viejos
         var old = Math.exp(-R / G.HR_OLD) * (1 - Math.exp(-R * R / (2.6 * 2.6))) * (1 - fvGal3Smooth((R - 15) / 4.5)) * oldFac * (BS.gf2 ? fvGf2Sweep(R) : 1);
         var mw6 = BS.gf6 ? fvGf6MoatW(X, Y, R) : 0; if (mw6 > 0) old *= 1 - fvGf6M().D * mw6;   // (GF6) (1) la fosa: el disco liso, mas tenue a los lados de la barra
         var ay = polar(PY, R, bt), adl = polar(PD, R, bt);
         var floc = 1 + GG.FLOC * (0.30 + 1.45 * fvGal3Fbm2(X / 0.9, Y / 0.9, 11, 3) - 1), dn = fvGal3Fbm2(X / 0.55, Y / 0.55, 23, 3), young = ay * floc;
         if (BS.gf2 && ridge > 0) { ridge *= 1 + FV_GAL_GF2.RIDGE_FLOC * (floc - 1); BS.OF[o] = ridge; }   // (GF2) el exceso de los brazos, con el grano de la luz joven (no «tubos de escayola»)
         var tY = 0, tRg = 0;
         if (BS.gf4) { var ED = BS.gf5 ? FV_GAL_GF5.EDGE : FV_GAL_GF4.EDGE, tp = 1 - ED.D * fvGal3Smooth((R - ED.R0) / ED.RW); if (tp < 1) { tY = young * (1 - tp); tRg = ridge * (1 - tp); young *= tp; ridge *= tp; if (PO) BS.OF[o] = ridge; } }   // (GF4) (6) el borde de la luz joven
         var dust = G.DUST_K * (adl * (0.30 + 1.5 * dn) + 0.22 * Math.exp(-R / 4.5) * dn * (1 - fvGal3Smooth((R - 13) / 5)));
         if (mw6 > 0) dust += fvGf6M().TAU * mw6;                   // (GF6) (1) polvo difuso en la fosa (parda, no crema)
         var er = G.A_OLD * old * (cO[0] + ridge * cR[0]) + G.A_YOUNG * young * cY[0], eg = G.A_OLD * old * (cO[1] + ridge * cR[1]) + G.A_YOUNG * young * cY[1], eb = G.A_OLD * old * (cO[2] + ridge * cR[2]) + G.A_YOUNG * young * cY[2];
         if (BS.gf7 && mw6 > 0) { var T7 = BS.gf9 ? fvGf9MoatTint() : ((BS.gf8 && FV_GAL_GF8.MOAT) ? FV_GAL_GF8.MOAT.TINT : FV_GAL_GF7.MOAT.TINT); er += G.A_OLD * old * cO[0] * (T7[0] - 1) * mw6; eg += G.A_OLD * old * cO[1] * (T7[1] - 1) * mw6; eb += G.A_OLD * old * cO[2] * (T7[2] - 1) * mw6; }   // (GF7) (1) el color de la fosa
         if (BS.gf2) {            // (GF2) la barra larga (luz vieja) y las lineas de polvo de sus bordes de ataque
            var gb = fvGf2Bar(X, Y); if (BS.gf6) gb[0] *= 1 + BS.mBoost * fvGf6MoatR(R);   // (GF6) (1) la barra, con la luz que la fosa quita al disco
            var aB = G.A_OLD * gb[0]; BS.BX[o] = gb[0]; var ld3 = BS.gf3 ? BS.LM[o] : gb[1]; BS.LD[o] = ld3; dust += ld3;   // (GF3) los carriles curvos (GF2: el mismo doble de antes)
            er += aB * cO[0]; eg += aB * cO[1]; eb += aB * cO[2];
            var dB = BS.gf4 ? fvGf4DustF(dust) : dust;                     // (GF4) la τ de cara, saturada
            BS.barL[0] += aB * cO[0] * Math.exp(-dB * kd[0]) * px * px; BS.barL[1] += aB * cO[1] * Math.exp(-dB * kd[1]) * px * px; BS.barL[2] += aB * cO[2] * Math.exp(-dB * kd[2]) * px * px;
         }
         if (BS.gf4) { var dF = fvGf4DustF(dust); R_[o] = er * Math.exp(-dF * kd[0]); G_[o] = eg * Math.exp(-dF * kd[1]); B_[o] = eb * Math.exp(-dF * kd[2]);
            if (!BS.dRec) BS.dRec = [0, 0, 0];                            // la luz que la τ saturada deja pasar de mas (sale tambien del disco: el color integrado no se mueve)
            BS.dRec[0] += R_[o] - er * Math.exp(-dust * kd[0]); BS.dRec[1] += G_[o] - eg * Math.exp(-dust * kd[1]); BS.dRec[2] += B_[o] - eb * Math.exp(-dust * kd[2]);
            if (tY > 0 || tRg > 0) for (var c4 = 0; c4 < 3; ++c4) BS.dRec[c4] -= (G.A_OLD * old * tRg * cR[c4] + G.A_YOUNG * tY * cY[c4]) * Math.exp(-dF * kd[c4]); }   // la luz joven quitada en el borde: el disco cede menos
         else { R_[o] = er * Math.exp(-dust * kd[0]); G_[o] = eg * Math.exp(-dust * kd[1]); B_[o] = eb * Math.exp(-dust * kd[2]); }
         Du[o] = dust; Ar[o] = young; AD[o] = adl;
      }
   }
   BS.j = N;
   // nudos HII (rosas) y cumulos (azules) a lo largo de los brazos con la misma semilla que hoy; los HII, AGUAS ABAJO del polvo (hacia fuera
   // dentro de la corrotacion, hacia dentro fuera de ella); el peso, el de la luz del brazo (el lado lejano al FAR)
   var rng = fvRng(G.SEED), tabs = tabs0, wsum = 0, cum = [];
   for (i = 0; i < tabs.length; ++i) { wsum += 0.5 * (BS.amps[i][0] + BS.amps[i][2]) * Math.max(0, tabs[i].b1 - tabs[i].b0); cum.push(wsum); }
   function gauss() { var u = Math.max(1e-9, rng()), v = rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
   function splat(X, Y, rr, col, amp) {
      var ci = (X + H) / px - 0.5, cj = (Y + H) / px - 0.5, rp = rr / px, rad = Math.ceil(2.5 * rp);
      for (var jj = Math.max(0, Math.floor(cj - rad)); jj <= Math.min(N - 1, Math.ceil(cj + rad)); ++jj)
         for (var ii = Math.max(0, Math.floor(ci - rad)); ii <= Math.min(N - 1, Math.ceil(ci + rad)); ++ii) {
            var dx = ii - ci, dy = jj - cj, qv = Math.exp(-0.5 * (dx * dx + dy * dy) / (rp * rp)) * amp, oo = jj * N + ii, tr = Math.exp(-0.6 * Du[oo]);
            R_[oo] += qv * col[0] * tr; G_[oo] += qv * col[1] * tr; B_[oo] += qv * col[2] * tr;
         }
   }
   // tantos nudos por grado de brazo como hoy (los brazos completos son mas largos: mas nudos, la misma densidad)
   var nk = Math.round((G.N_HII + G.N_CL) * wsum / Math.max(1e-9, fvGgKnotRef())), nH = Math.round(G.N_HII * wsum / Math.max(1e-9, fvGgKnotRef()));
   var HK = BS.gf2 ? FV_GAL_GF2.HII : null;
   if (HK) { var nCl = nk - nH; nH = Math.round(nH * HK.N); nk = nH + nCl; }          // (GF2) menos nudos HII, compactos y mas brillantes (la misma luz ~0,3)
   if (BS.gf3) {             // (GF3) nudos y nubes sobre los brazos que se pintan; su luz sale de las crestas, canal a canal: el color integrado no se mueve
      var s0 = [fvGf3Sum(R_, N), fvGf3Sum(G_, N), fvGf3Sum(B_, N)]; fvGf3Knots(BS, tabs, rng, gauss, splat, oldR, cR, nk, nH);
      var dS = [fvGf3Sum(R_, N) - s0[0], fvGf3Sum(G_, N) - s0[1], fvGf3Sum(B_, N) - s0[2]], rS = [0, 0, 0], c3;
      if (BS.gf4) fvGf4Comp(BS, N, H, px, oldR, cR, cO, kd, dS);          // (GF4) la luz anadida sale del disco viejo liso (las crestas se quedan enteras)
      else {
      for (j = 0; j < N; ++j) { var Yq = -H + (j + 0.5) * px; for (i = 0; i < N; ++i) { var Xq = -H + (i + 0.5) * px, oq = j * N + i; if (!(BS.OF[oq] > 0)) continue; var rq = G.A_OLD * oldR(Math.sqrt(Xq * Xq + Yq * Yq)) * BS.OF[oq]; for (c3 = 0; c3 < 3; ++c3) rS[c3] += rq * cR[c3] * Math.exp(-Du[oq] * kd[c3]); } }
      var fq = [0, 0, 0]; for (c3 = 0; c3 < 3; ++c3) fq[c3] = rS[c3] > 0 ? Math.max(0, Math.min(0.5, dS[c3] / rS[c3])) : 0; BS.fq = fq;
      for (j = 0; j < N; ++j) { var Yr = -H + (j + 0.5) * px; for (i = 0; i < N; ++i) { var Xr = -H + (i + 0.5) * px, orr = j * N + i; if (!(BS.OF[orr] > 0)) continue;
         var rl = G.A_OLD * oldR(Math.sqrt(Xr * Xr + Yr * Yr)) * BS.OF[orr]; R_[orr] -= fq[0] * rl * cR[0] * Math.exp(-Du[orr] * kd[0]); G_[orr] -= fq[1] * rl * cR[1] * Math.exp(-Du[orr] * kd[1]); B_[orr] -= fq[2] * rl * cR[2] * Math.exp(-Du[orr] * kd[2]); BS.OF[orr] *= 1 - fq[1]; } }
      }
   }
   else for (var n = 0; n < nk; ++n) {
      var hii = n < nH, pick = rng() * wsum, ti = 0; while (ti < cum.length - 1 && cum[ti] < pick) ++ti;
      var T = tabs[ti], bb = T.b0 + rng() * (T.b1 - T.b0), ar = fvGgAt(T, bb);
      if (!ar || rng() > ar[1]) continue;
      var s1 = fvGal3Sigma(fvGgArmShape(T, ar), ar[0]), side2 = 1 - 2 * fvGal3Smooth((ar[0] - GG.RCR + 0.5 * GG.RCR_W) / GG.RCR_W);
      var Rk = ar[0] + gauss() * 0.45 * s1 + (hii ? GG.HII_DOWN * side2 : 0), be = (FV_GAL3_BREAK === "beta" ? -bb : bb) * Math.PI / 180, Xk = -Rk * Math.cos(be), Yk = Rk * Math.sin(be);
      var dK = HK ? HK.KMIN + (1 - HK.KMIN) * fvGal3Smooth((Rk - FV_GAL_GF2.DESERT.R0) / (FV_GAL_GF2.DESERT.R1 - FV_GAL_GF2.DESERT.R0)) : 1;   // (GF2) el desierto de la barra
      if (hii) { if (HK) splat(Xk, Yk, HK.R0 + HK.R1 * rng(), G.COL_HII, dK * HK.AMP * Math.exp(-Math.max(0, Rk - G.R0) / G.HR_OLD) * G.A_HII * (0.25 + 0.75 * rng() * rng())); else splat(Xk, Yk, 0.035 + 0.06 * rng(), G.COL_HII, G.A_HII * (0.25 + 0.75 * rng() * rng())); }   // (GF2) fuera del Sol, el brillo de los nudos baja con el disco
      else splat(Xk, Yk, 0.03 + 0.03 * rng(), G.COL_CL, dK * G.A_CL * (0.2 + 0.8 * rng() * rng()));
   }
   BS.T = { N: N, H: H, px: px, r: R_, g: G_, b: B_, dust: Du, arm: Ar, armDust: AD, ms: BS.ms + Date.now() - t0, brk: FV_GAL3_BREAK, stars: null, data: "ggmodel", m2ph: BS.ph, oldF: BS.OF };
   if (BS.gf2) { BS.T.barX = BS.BX; BS.T.laneD = BS.LD; BS.T.barL = BS.barL; }
   if (BS.gf3) { BS.T.lanes = BS.lanes; BS.T.k3 = BS.k3; BS.PM = null; BS.LM = null; }
   if (BS.gf4) { BS.T.discK = BS.discK; BS.T.DK = BS.DK; BS.T.dsat = true; BS.T.k3g3 = BS.k3g3; BS.T.comp = BS.comp; BS.DK = null; }   // (GF4) la mezcla los necesita (disco compensado, τ de cara)
   if (BS.gf5) { BS.T.gf5 = true; BS.T.hii5 = BS.hii5 || null; }                                                                       // (GF5) lo que miran las pruebas
   if (BS.gf6) { BS.T.gf6 = true; BS.T.mBoost = BS.mBoost; if (BS.gf7) BS.T.gf7 = true; if (BS.gf8) BS.T.gf8 = true; if (BS.gf9) BS.T.gf9 = true; }                                                                       // (GF6) la mezcla lo necesita (fosa)
   BS.done = true; BS.PY = BS.PD = BS.PO = null;
   return true;
}
function fvGf3Sum(a, N) { var s = 0; for (var i = 0; i < N * N; ++i) s += a[i]; return s; }
// (GF4) (3) LA LUZ ANADIDA, canal a canal: la de los nudos HII y los cumulos y la que las crestas ganan (K3 en vez de k3 de GF3: la fraccion (K3 − k3)/K3
// de la luz de las crestas) sale del DISCO VIEJO LISO (sin barra ni bulbo); la de las nubes estelares (grumos de la misma luz joven, mismo color que la
// cresta) sale de las crestas (como en GF3: no cambia su color). El color integrado del mapa no se mueve. discK: el factor del disco liso por canal.
function fvGf4Comp(BS, N, H, px, oldR, cR, cO, kd, dK) {
   var G = FV_GAL3, R_ = BS.R_, G_ = BS.G_, B_ = BS.B_, Du = BS.Du, OF = BS.OF, dC = BS.dCl || [0, 0, 0], kn = [dK[0] - dC[0], dK[1] - dC[1], dK[2] - dC[2]], rS = [0, 0, 0], D = [0, 0, 0];
   var ex = BS.k3 > 0 ? Math.max(0, BS.k3 - BS.k3g3) / BS.k3 : 0, i, j, c, X, Y, R, o, df, ol, ka = FV_GAL_GF4.COMP_K, CL = FV_GAL_GF4.CLOUD_RIDGE;
   if (!FV_GAL_GF4.COMP) { BS.discK = null; BS.comp = null; return; }
   if (!CL) { kn = [dK[0], dK[1], dK[2]]; dC = [0, 0, 0]; }
   // (GF5) (2) la luz de los nudos HII (roja) sale de las crestas, canal a canal (como las nubes de GF3): si saliera del disco liso, el interbrazo perderia
   // mas rojo que hoy y quedaria oliva (medido: G/B del interbrazo 1,50 -> 1,88, h 87° -> 110°)
   if (BS.gf5 && BS.kH5 && FV_GAL_GF5.COMP.HII_RIDGE) { dC = BS.kH5.slice(); kn = [dK[0] - dC[0], dK[1] - dC[1], dK[2] - dC[2]]; }
   var rec = BS.dRec || [0, 0, 0]; kn = [kn[0] + rec[0], kn[1] + rec[1], kn[2] + rec[2]];   // y la que deja pasar la τ de cara saturada
   var dBl = fvGf4BulgeDeficit();                                     // (4) la luz que el bulbo de GF4 tiene de menos vuelve al disco (mismo color: COL_BULGE = COL_OLD)
   for (c = 0; c < 3; ++c) kn[c] -= dBl * G.COL_BULGE[c] / (px * px);
   var C5 = BS.gf5 ? FV_GAL_GF5.COMP : null;                           // (GF5) (2) nada dentro de R0 (la fosa junto a la barra)
   function uW(o) { return ka > 0 ? 1 / (1 + Math.max(0, OF[o]) / ka) : 1; }   // el disco liso cede su luz sobre todo entre los brazos (u = 1 sin cresta)
   function oM(X, Y, R) { return BS.gf6 ? 1 - fvGf6M().D * fvGf6MoatW(X, Y, R) : 1; }   // (GF6) (1) el disco liso de la fosa, ya rebajado
   for (j = 0; j < N; ++j) { Y = -H + (j + 0.5) * px; for (i = 0; i < N; ++i) { X = -H + (i + 0.5) * px; R = Math.sqrt(X * X + Y * Y); if (R > H) continue; o = j * N + i; df = fvGf4DustF(Du[o]); ol = G.A_OLD * oldR(R) * oM(X, Y, R); var u = C5 ? uW(o) * fvGal3Smooth((R - C5.R0) / C5.RW) : uW(o);
      for (c = 0; c < 3; ++c) { var tr = Math.exp(-df * kd[c]); D[c] += u * ol * cO[c] * tr; if (OF[o] > 0) rS[c] += ol * OF[o] * cR[c] * tr; } } }
   var e = [0, 0, 0], fq = [0, 0, 0]; for (c = 0; c < 3; ++c) { e[c] = D[c] > 0 ? Math.max(0, Math.min(0.75, (kn[c] + ex * rS[c]) / D[c])) : 0; fq[c] = rS[c] > 0 ? Math.max(0, Math.min(0.5, dC[c] / rS[c])) : 0; }
   var DK = BS.DK = new Float32Array(N * N);                           // el factor del disco liso por texel (verde; para la mezcla)
   for (j = 0; j < N; ++j) { Y = -H + (j + 0.5) * px; for (i = 0; i < N; ++i) { X = -H + (i + 0.5) * px; R = Math.sqrt(X * X + Y * Y); if (R > H) continue; o = j * N + i; df = fvGf4DustF(Du[o]); ol = G.A_OLD * oldR(R) * oM(X, Y, R); var rf = OF[o] > 0 ? ol * OF[o] : 0, u2 = C5 ? uW(o) * fvGal3Smooth((R - C5.R0) / C5.RW) : uW(o);
      R_[o] -= (u2 * e[0] * ol * cO[0] + fq[0] * rf * cR[0]) * Math.exp(-df * kd[0]); G_[o] -= (u2 * e[1] * ol * cO[1] + fq[1] * rf * cR[1]) * Math.exp(-df * kd[1]); B_[o] -= (u2 * e[2] * ol * cO[2] + fq[2] * rf * cR[2]) * Math.exp(-df * kd[2]);
      DK[o] = u2; if (rf > 0) OF[o] *= 1 - fq[1]; } }
   BS.discK = e; BS.comp = { e: e, fq: fq, add: [kn[0] + ex * rS[0], kn[1] + ex * rS[1], kn[2] + ex * rS[2]], D: D, ex: ex, knots: kn, clouds: dC };
}
// (GF3) LOS NUDOS HII, LOS CUMULOS Y LAS NUBES ESTELARES sobre los brazos que se PINTAN: el peso de cada brazo es el de su luz (los mayores 1; los
// menores, ML × peso de angulo de paso), no el de la tabla entera (con GF2 caian nudos en los tramos sin luz, p. ej. el anillo de 5,5 kpc). El brillo
// de los nudos sigue al de su brazo (e^(−(max(R, ENV_R) − R0)/h_R), como su luz) y el de las nubes, a la cresta local (× AMP). Desierto: × DESERT_FLOOR.
function fvGf3Knots(BS, tabs, rng, gauss, splat, oldR, cR, nk0, nH0) {
   var G = FV_GAL3, GG = FV_GAL_GG, F3 = FV_GAL_GF3, F2 = FV_GAL_GF2, DS = F2.DESERT, oldIds = GG.OLD_ARMS, HK = F3.HII, CL = F3.CLOUDS, i, n;
   var base = tabs.map(function(T) { return oldIds.indexOf(T.a.id) >= 0 ? 1 : ((BS.gf4 && T.a.id === "local") ? FV_GAL_GF4.LOCAL.ML : (F3.ML[T.a.id] || 0)); }), wsum = 0, cum = [];   // (GF4) el Brazo Local
   for (i = 0; i < tabs.length; ++i) { wsum += base[i] * 0.5 * (BS.amps[i][0] + BS.amps[i][2]) * Math.max(0, tabs[i].b1 - tabs[i].b0); cum.push(wsum); }
   if (!(wsum > 0)) return;
   // los mismos nudos por grado de brazo LUMINOSO que GF2 por grado de tabla (nk0, nH0 son los de GF2 sobre todas las tablas)
   var w2 = 0; for (i = 0; i < tabs.length; ++i) w2 += 0.5 * (BS.amps[i][0] + BS.amps[i][2]) * Math.max(0, tabs[i].b1 - tabs[i].b0);
   var fr = wsum / Math.max(1e-9, w2), nCl = Math.round((nk0 - nH0) * fr), nH = Math.round(nH0 / F2.HII.N * HK.N * fr * (BS.gf5 ? FV_GAL_GF5.HII.N : 1)), nk = nH + nCl;   // (GF5) × N
   function pickArm() { var p = rng() * wsum, t = 0; while (t < cum.length - 1 && cum[t] < p) ++t; return t; }
   function lumW(t, bb) { if (base[t] >= 1) return 1; var w = BS.gf4 ? fvGf4PitchW(tabs[t], bb) : fvGf3PitchW(tabs[t], bb); return w * w; }   // en los menores, peso² (los nudos, donde su luz ya se ve)
   function desert(R) { var f = F3.DESERT_FLOOR; return f + (1 - f) * fvGal3Smooth((R - DS.R0) / (DS.R1 - DS.R0)); }
   // (GF4) el color de los nudos con menos croma (mezcla hacia su gris, mismo tono en lineal) y el fondo del mapa (media R, G, B en ±BGR texeles) en su sitio
   var G4 = BS.gf4 ? (BS.gf5 ? FV_GAL_GF5.HII : FV_GAL_GF4.HII) : null, cH = G.COL_HII, NT = G.TEX_N, HT = G.TEX_H, pxT = 2 * HT / NT, nRej = 0, aH5 = 1;
   if (BS.gf5) {             // (GF5) (5) el color fisico de la HII (fvGalColorCompute: hii5, lineas con [NII], [OIII], [SII] y enrojecimiento; o su reserva)
      var st5 = (typeof FV_GAL_COLOR !== "undefined" && FV_GAL_COLOR.state) ? FV_GAL_COLOR.state : null, c5 = (st5 && st5.hii5) ? st5.hii5 : FV_GAL_COLOR.FALLBACK.hii5;
      cH = fvGalColorToMax(c5); aH5 = G4.AMP; BS.hii5 = { col: cH.slice(), src: (st5 && st5.hii5) ? st5.src : "fallback" };
   }
   if (G4) { var gH = (cH[0] + cH[1] + cH[2]) / 3; cH = [gH + G4.C * (cH[0] - gH), gH + G4.C * (cH[1] - gH), gH + G4.C * (cH[2] - gH)]; }
   var cC = G.COL_CL, C4 = BS.gf4 ? FV_GAL_GF4.CL : null;   // (GF4) (3) los cumulos azules con menos croma (las «motas» saturadas), mismo tono y misma luz media
   if (C4 && C4.C !== 1) { var gC = (cC[0] + cC[1] + cC[2]) / 3; cC = [gC + C4.C * (cC[0] - gC), gC + C4.C * (cC[1] - gC), gC + C4.C * (cC[2] - gC)]; }
   function bgAt(X, Y) { var ci = Math.floor((X + HT) / pxT), cj = Math.floor((Y + HT) / pxT), r = G4.BGR || 6, s = 0, m = 0;
      for (var jj = Math.max(0, cj - r); jj <= Math.min(NT - 1, cj + r); ++jj) for (var ii = Math.max(0, ci - r); ii <= Math.min(NT - 1, ci + r); ++ii) { var oo = jj * NT + ii; s += BS.R_[oo] + BS.G_[oo] + BS.B_[oo]; ++m; }
      return m ? s / (3 * m) : 0; }
   var sH0 = BS.gf5 ? [fvGf3Sum(BS.R_, NT), fvGf3Sum(BS.G_, NT), fvGf3Sum(BS.B_, NT)] : null;   // (GF5) la luz de los nudos HII, aparte (sale de las crestas)
   function hiiDone() { if (sH0 && !BS.kH5) BS.kH5 = [fvGf3Sum(BS.R_, NT) - sH0[0], fvGf3Sum(BS.G_, NT) - sH0[1], fvGf3Sum(BS.B_, NT) - sH0[2]]; }
   for (n = 0; n < nk; ++n) {
      if (sH0 && n === nH) hiiDone();
      var hii = n < nH, ti = pickArm(), T = tabs[ti], bb = T.b0 + rng() * (T.b1 - T.b0), ar = fvGgAt(T, bb);
      if (!ar || rng() > ar[1] * lumW(ti, bb)) continue;
      var s1 = fvGal3Sigma(fvGgArmShape(T, ar), ar[0]), side2 = 1 - 2 * fvGal3Smooth((ar[0] - GG.RCR + 0.5 * GG.RCR_W) / GG.RCR_W);
      var Rk = ar[0] + gauss() * 0.45 * s1 * ((hii && G4 && BS.gf5 && G4.SPREAD > 0) ? G4.SPREAD : 1) + (hii ? GG.HII_DOWN * side2 : 0), be = (FV_GAL3_BREAK === "beta" ? -bb : bb) * Math.PI / 180, Xk = -Rk * Math.cos(be), Yk = Rk * Math.sin(be);   // (GF5) los nudos HII mas cerca de la cresta (SPREAD)
      var dK = desert(Rk), env = Math.exp(-(Math.max(Rk, F2.ENV_R) - G.R0) / G.HR_OLD), envH = Math.exp(-(Math.max(Rk, F2.ENV_R) - G.R0) / (HK.HK * G.HR_OLD));
      var bgK = (hii && G4 && G4.BG > 0) ? bgAt(Xk, Yk) : 0;
      if (hii && G4 && G4.BG > 0 && bgK < G4.BG) { rng(); rng(); rng(); ++nRej; continue; }   // (GF4) nudo sobre fondo que no se ve: no (mismo consumo de azar)
      if (hii) { var fK = (BS.gf5 && G4.FLOOR > 0) ? G4.FLOOR : 0.25, rH = HK.R0 + HK.R1 * rng(), aK = aH5 * dK * HK.AMP * envH * G.A_HII * (fK + (1 - fK) * rng() * rng());   // (GF5) × AMP (1 sin GF5) y suelo FLOOR (0,25 sin GF5)
         if (BS.gf5 && G4.SAT > 0) aK /= 1 + aK / (G4.SAT * HK.AMP * G.A_HII);   // (GF5) los nudos mas brillantes, con tope suave
         if (BS.gf5 && G4.BGS > 0) aK /= 1 + bgK / G4.BGS;   // (GF5) y menos brillo sobre fondo muy claro (junto a la punta de la barra, el canal R de un nudo se quemaba)
         splat(Xk, Yk, rH, cH, aK); }
      else splat(Xk, Yk, 0.03 + 0.03 * rng(), cC, dK * env * G.A_CL * (0.2 + 0.8 * rng() * rng()));
   }
   if (sH0) hiiDone();
   // las nubes estelares: grupos de PER puntos (σ SIG) en el lado luminoso del brazo, con el color y el brillo de su cresta
   var kap = GG.OLD_KAPPA * BS.k3, sC0 = G4 ? [fvGf3Sum(BS.R_, NT), fvGf3Sum(BS.G_, NT), fvGf3Sum(BS.B_, NT)] : null;   // (GF4) la luz de las nubes, aparte
   for (n = 0; n < CL.N; ++n) {
      var tc = pickArm(), Tc = tabs[tc], bc = Tc.b0 + rng() * (Tc.b1 - Tc.b0), ac = fvGgAt(Tc, bc);
      if (!ac || rng() > ac[1] * lumW(tc, bc)) continue;
      var sc = fvGal3Sigma(fvGgArmShape(Tc, ac), ac[0]), Rc = ac[0] + gauss() * 0.35 * sc, bec = (FV_GAL3_BREAK === "beta" ? -bc : bc) * Math.PI / 180, Xc = -Rc * Math.cos(bec), Yc = Rc * Math.sin(bec);
      var amp = CL.AMP * G.A_OLD * oldR(Rc) * kap * (base[tc] >= 1 ? 1 : base[tc]) * desert(Rc);
      for (var p = 0; p < CL.PER; ++p) splat(Xc + gauss() * CL.SIG, Yc + gauss() * CL.SIG, CL.R0 + CL.R1 * rng(), cR, amp * (0.3 + 0.7 * rng() * rng()));
   }
   if (G4) { BS.hiiRej = nRej; BS.dCl = [fvGf3Sum(BS.R_, NT) - sC0[0], fvGf3Sum(BS.G_, NT) - sC0[1], fvGf3Sum(BS.B_, NT) - sC0[2]]; }
}
// la referencia de nudos de hoy: Σ L·(tramo) de las tablas de fv_galaxy3d.js (para guardar la densidad de nudos por grado de brazo)
function fvGgKnotRef() { var t = fvGal3Tables(), s = 0; for (var i = 0; i < t.length; ++i) s += t[i].a.L * (t[i].b1 - t[i].b0); return s; }
function fvGgTex(amp) { var B = fvGgTexBegin(amp); while (!fvGgTexStep(B, 0)) {} return B.T; }

// ---------------------------------------------------------------------------
// LA DENSIDAD DEL MODELO PARA UN TIPO DE TRAZADOR (rejilla NL×NL, 250 pc): Σ_k b_k·wg_k·exp(−dR²/2w²) + suelo exponencial con agujero.
// La usan el ajuste (gg_fit.js), la validacion y, en ejecucion, el prior de la densidad a posteriori de las nubes.
//   prm = { b: {id: amplitud}, s: escala de anchura, f: suelo, h: escala del suelo (kpc) }; tabs = tablas (las de ejecucion si null)
// ---------------------------------------------------------------------------
function fvGgLambdaGrid(prm, tabs, NL, H) {
   var t = tabs || fvGgTables(), n = NL || FV_GAL_GG.NL, HH = H || FV_GAL3.TEX_H, cs = 2 * HH / n, out = new Float32Array(n * n), i, j, q, kk;
   var bq = t.map(function(T) { var id = T.a.id === "3kpcF" ? "3kpc" : T.a.id; return prm.b[id] || 0; }), bq2 = t.map(function(T, q) { return T.chain ? (prm.b[T.chain] || 0) : bq[q]; });
   for (j = 0; j < n; ++j) { var Y = -HH + (j + 0.5) * cs;
      for (i = 0; i < n; ++i) {
         var X = -HH + (i + 0.5) * cs, R = Math.sqrt(X * X + Y * Y), o = j * n + i; if (R > 19.5) continue;
         var be = fvGal3Beta(X, Y), v = 0;
         for (q = 0; q < t.length; ++q) { if (!bq[q] && !bq2[q]) continue; var T = t[q], a2 = T.chain ? fvGgArmDef(T.chain) : null;
            for (kk = -2; kk <= 1; ++kk) { var r = fvGgAt(T, be + 360 * kk); if (!r || r[2] <= 0) continue;
               var w = fvGgWidth(r[0], prm.s, fvGgArmShape(T, r)); if (a2) w += (fvGgWidth(r[0], prm.s, a2) - w) * r[5];
               var dR = R - r[0]; if (dR > 4 * w || dR < -4 * w) continue; v += (bq[q] + (bq2[q] - bq[q]) * r[5]) * r[2] * Math.exp(-0.5 * dR * dR / (w * w)); } }
         out[o] = v + prm.f * Math.exp(-R / prm.h) * fvGal3Smooth((R - 1.5) / 2.0) * (1 - fvGal3Smooth((R - 16) / 4));
      } }
   return out;
}

// ---------------------------------------------------------------------------
// EL EXTRACTO AMPLIADO (gp_extract.py --gg): t,l,b,d,ed,m,r,arm,dA,sA,dB,sB,pA,msk -> por tipo, con su pdf
// ---------------------------------------------------------------------------
function fvGgParse(txt) {
   var G = FV_GAL3, D2R = Math.PI / 180, out = { C: [], H: [], M: [] }, L = String(txt).split(/\r?\n/);
   for (var i = 1; i < L.length; ++i) {
      var p = L[i].split(","); if (p.length < 14) continue;
      var t = p[0], l = parseFloat(p[1]), b = parseFloat(p[2]); if (!out[t] || !isFinite(l)) continue;
      var cl = Math.cos(l * D2R), sl = Math.sin(l * D2R), cb = Math.cos(b * D2R);
      out[t].push({ l: l, b: b, d: parseFloat(p[3]), m: parseFloat(p[5]) || 0, arm: (p[7] || "").replace(/\s+/g, ""), ux: cl * cb, uy: sl * cb,
                    dA: parseFloat(p[8]), sA: parseFloat(p[9]), dB: parseFloat(p[10]) || 0, sB: parseFloat(p[11]) || 0, pA: parseFloat(p[12]), msk: p[13] === "1" || p[13] === "1\r" });
   }
   return out;
}
// las muestras de la pdf de posicion de un objeto a lo largo de su linea de vision: [X, Y, peso] (peso de la pdf, suma 1); paso ≤ dstep kpc
function fvGgPdfSamples(o, dstep) {
   var R0 = FV_GAL3.R0, out = [], modes = [[o.dA, o.sA, o.pA]];
   if (o.pA < 1 && o.dB > 0) modes.push([o.dB, o.sB, 1 - o.pA]);
   for (var m = 0; m < modes.length; ++m) {
      var d0 = modes[m][0], s = Math.max(0.02, modes[m][1]), pm = modes[m][2], ns = Math.max(3, Math.min(61, Math.ceil(6 * s / dstep) + 1)), sw = 0, tmp = [];
      for (var k = 0; k < ns; ++k) { var z = -3 + 6 * k / (ns - 1), d = d0 + z * s; if (d <= 0.05) continue; var w = Math.exp(-0.5 * z * z); tmp.push([d * o.ux - R0, d * o.uy, w, d]); sw += w; }
      for (k = 0; k < tmp.length; ++k) out.push([tmp[k][0], tmp[k][1], pm * tmp[k][2] / sw, tmp[k][3]]);
   }
   return out;
}
// la completitud de la muestra homogenea de nubes a la distancia d (1 hasta D_COMPLETE, cae despues) y la mascara de Wenger en (X, Y)
function fvGgSelC(d) { var D = FV_GAL_GG.D_COMPLETE; return d <= D ? 1 : Math.exp(-0.5 * Math.pow((d - D) / 3, 2)); }
function fvGgMaskXY(X, Y, ramp) {
   var x = X + FV_GAL3.R0, l = Math.atan2(Y, x) * 180 / Math.PI, rw = ramp || 3; if (l < 0) l += 360;
   function edge(a) { return fvGal3Smooth(a / rw); }                    // 3° de transicion (la SELECCION del ajuste); la mezcla usa MASK_RAMP
   var m1 = Math.min(l, 360 - l) - 15, m2 = Math.abs(l - 180) - 20;      // > 0 fuera de las mascaras
   return edge(m1) * edge(m2);
}
// bilineal en una rejilla n×n sobre ±H
function fvGgSamp(A, n, H, X, Y) {
   var cs = 2 * H / n, u = (X + H) / cs - 0.5, v = (Y + H) / cs - 0.5, i0 = Math.floor(u), j0 = Math.floor(v);
   if (i0 < 0 || j0 < 0 || i0 >= n - 1 || j0 >= n - 1) return 0;
   var fu = u - i0, fv = v - j0, o = j0 * n + i0;
   return (A[o] * (1 - fu) + A[o + 1] * fu) * (1 - fv) + (A[o + n] * (1 - fu) + A[o + n + 1] * fu) * fv;
}
function fvGgSplat(A, n, H, X, Y, q) {
   var cs = 2 * H / n, u = (X + H) / cs - 0.5, v = (Y + H) / cs - 0.5, i0 = Math.floor(u), j0 = Math.floor(v);
   if (i0 < 0 || j0 < 0 || i0 >= n - 1 || j0 >= n - 1) return;
   var fu = u - i0, fv = v - j0, o = j0 * n + i0;
   A[o] += q * (1 - fu) * (1 - fv); A[o + 1] += q * fu * (1 - fv); A[o + n] += q * (1 - fu) * fv; A[o + n + 1] += q * fu * fv;
}
function fvGgBlur(A, n, sg) {
   var K = [], ks = 0, h = Math.ceil(3 * sg), t, i, j, tmp = new Float32Array(n * n);
   for (t = -h; t <= h; ++t) { var w = Math.exp(-0.5 * t * t / (sg * sg)); K.push(w); ks += w; }
   for (t = 0; t < K.length; ++t) K[t] /= ks;
   for (j = 0; j < n; ++j) for (i = 0; i < n; ++i) { var s = 0; for (t = -h; t <= h; ++t) { var ii = i + t; if (ii >= 0 && ii < n) s += K[t + h] * A[j * n + ii]; } tmp[j * n + i] = s; }
   for (j = 0; j < n; ++j) for (i = 0; i < n; ++i) { var s2 = 0; for (t = -h; t <= h; ++t) { var jj = j + t; if (jj >= 0 && jj < n) s2 += K[t + h] * tmp[jj * n + i]; } A[j * n + i] = s2; }
}

// ---------------------------------------------------------------------------
// LA PREPARACION (una vez por sesion, por trozos): λ de las nubes, densidad A POSTERIORI de las nubes, mapa u y su linea, % del disco con
// la posicion de los brazos medida y el sitio del rotulo del lado lejano. J = { PG (extracto ampliado), st, q, ... }
// ---------------------------------------------------------------------------
function fvGgPrepBegin(txt) { return { PG: fvGgParse(txt), st: 0, q: 0, ms: { lam: 0, post: 0, u: 0, line: 0 } }; }
function fvGgPrepStep(J, over) {
   var GG = FV_GAL_GG, G = FV_GAL3, H = G.TEX_H, NL = GG.NL, NK = (typeof FV_GAL_DATA !== "undefined") ? FV_GAL_DATA.NK : 320, i, j, o;
   while (J.st < 4) {
      var tm = Date.now();
      if (J.st === 0) {
         var F = fvGgFit(), pc = (F && F.lam && F.lam.C) ? F.lam.C : { b: { norma: 1, scucen: 1, sgrcar: 1, perseus: 1, local: 1, outer: 1, "3kpc": 1 }, s: 1, f: 0.3, h: 4 };
         J.lamC = fvGgLambdaGrid(pc, null, NL, H); J.Dpost = new Float32Array(NK * NK); J.q = 0; J.st = 1; J.ms.lam += Date.now() - tm;
      } else if (J.st === 1) {
         // cada nube (corte en masa, fuera de la mascara): su pdf × λ_C × completitud, normalizada, × su masa
         var L = J.PG.C;
         for (; J.q < L.length; ++J.q) {
            if ((J.q & 63) === 0 && over && over()) { J.ms.post += Date.now() - tm; return false; }
            var c = L[J.q]; if (c.msk || !(c.m > 0)) continue;
            var sm = fvGgPdfSamples(c, 0.1), s = 0, k, w = [];
            for (k = 0; k < sm.length; ++k) { var v = sm[k][2] * fvGgSamp(J.lamC, NL, H, sm[k][0], sm[k][1]) * fvGgSelC(sm[k][3]); w.push(v); s += v; }
            if (!(s > 0)) continue;
            for (k = 0; k < sm.length; ++k) if (w[k] > 0) fvGgSplat(J.Dpost, NK, H, sm[k][0], sm[k][1], c.m * w[k] / s);
         }
         fvGgBlur(J.Dpost, NK, 1.2);          // 150 pc: «modulacion fina», no puntos
         J.st = 2; J.ms.post += Date.now() - tm;
      } else if (J.st === 2) {
         J.U = fvGgUMap(NL, H); J.st = 3; J.ms.u += Date.now() - tm;
      } else {
         J.seg = fvGgContour(J.U.u, NL, H, GG.U_HALF); J.st = 4; J.ms.line += Date.now() - tm;
      }
      if (J.st < 4 && over && over()) return false;
   }
   return true;
}
// EL MAPA u = σ_pos / (σ_pos + w_brazo) (formula 2; w_brazo = la anchura de la luz que se PINTA, fvGal3Sigma: u = 0,5 = el brazo puede
// estar a una anchura suya de donde se dibuja): cada celda toma la u de los brazos cercanos (peso: su luz y la cercania, σ 1 kpc) y una
// u = 1 de fondo (sin brazo cerca no hay posicion que medir); suavizado ±0,75 kpc. Devuelve tambien el % del disco con u < 0,5 y el rotulo.
function fvGgUMap(NL, H) {
   var GG = FV_GAL_GG, t = fvGgTables(), cs = 2 * H / NL, u = new Float32Array(NL * NL), i, j, q, kk, nD = 0, nLo = 0, fx = 0, fy = 0, fw = 0;
   for (j = 0; j < NL; ++j) { var Y = -H + (j + 0.5) * cs;
      for (i = 0; i < NL; ++i) {
         var X = -H + (i + 0.5) * cs, R = Math.sqrt(X * X + Y * Y), o = j * NL + i, be = fvGal3Beta(X, Y), su = 0.08, sw = 0.08;   // fondo: u = 1 con peso 0,08
         for (q = 0; q < t.length; ++q) { var T = t[q]; for (kk = -2; kk <= 1; ++kk) { var r = fvGgAt(T, be + 360 * kk); if (!r || r[2] <= 0) continue; var dR = R - r[0]; if (dR > 3 || dR < -3) continue;
            var g = r[2] * Math.exp(-0.5 * dR * dR), sp = r[0] * r[4], uk = sp / (sp + fvGal3Sigma(fvGgArmShape(T, r), r[0])); su += g * uk; sw += g; } }
         u[o] = su / sw;
      } }
   // suavizado (caja ±3 celdas, dos pasadas)
   var tmp = new Float32Array(NL * NL), rb = 3;
   for (var pass = 0; pass < 2; ++pass) {
      for (j = 0; j < NL; ++j) for (i = 0; i < NL; ++i) { var sA = 0, nA = 0; for (var e = -rb; e <= rb; ++e) { var ii = i + e; if (ii >= 0 && ii < NL) { sA += u[j * NL + ii]; ++nA; } } tmp[j * NL + i] = sA / nA; }
      for (j = 0; j < NL; ++j) for (i = 0; i < NL; ++i) { var sB = 0, nB = 0; for (var e2 = -rb; e2 <= rb; ++e2) { var jj = j + e2; if (jj >= 0 && jj < NL) { sB += tmp[jj * NL + i]; ++nB; } } u[j * NL + i] = sB / nB; }
   }
   for (j = 0; j < NL; ++j) for (i = 0; i < NL; ++i) {
      var X2 = -H + (i + 0.5) * cs, Y2 = -H + (j + 0.5) * cs, R2 = Math.sqrt(X2 * X2 + Y2 * Y2), uu = u[j * NL + i];
      if (R2 < 16.5) { ++nD; if (uu < GG.U_HALF) ++nLo; }
      if (X2 > 1.5 && R2 > 2.5 && R2 < 13) { var wl = Math.max(0, uu - 0.75); fx += wl * X2; fy += wl * Y2; fw += wl; }
   }
   return { u: u, cov: nD ? nLo / nD : 0, far: fw > 0 ? [fx / fw, fy / fw] : [6, 0] };
}
// la linea u = lev (marching squares) -> [X1, Y1, X2, Y2, ...] galactocentricos, solo dentro del disco
function fvGgContour(v0, n, H, lev) {
   var cs = 2 * H / n, seg = [], i, j, M = n;
   function V(i2, j2) { return v0[j2 * n + i2] - lev; }
   function P(i0, j0, i1, j1) { var a = V(i0, j0), b = V(i1, j1), t = a / (a - b); return [-H + (i0 + 0.5 + (i1 - i0) * t) * cs, -H + (j0 + 0.5 + (j1 - j0) * t) * cs]; }
   for (j = 0; j < M - 1; ++j) for (i = 0; i < M - 1; ++i) {
      var X = -H + (i + 1) * cs, Y = -H + (j + 1) * cs; if (X * X + Y * Y > 16.5 * 16.5) continue;
      var a = V(i, j) > 0, b = V(i + 1, j) > 0, c = V(i + 1, j + 1) > 0, d = V(i, j + 1) > 0, e = [];
      if (a !== b) e.push(P(i, j, i + 1, j)); if (b !== c) e.push(P(i + 1, j, i + 1, j + 1)); if (c !== d) e.push(P(i + 1, j + 1, i, j + 1)); if (d !== a) e.push(P(i, j + 1, i, j));
      if (e.length === 2) seg.push(e[0][0], e[0][1], e[1][0], e[1][1]);
      else if (e.length === 4) seg.push(e[0][0], e[0][1], e[1][0], e[1][1], e[2][0], e[2][1], e[3][0], e[3][1]);
   }
   return new Float32Array(seg);
}

// ---------------------------------------------------------------------------
// EL MAPA FINAL (mismo formato que fvGal3Tex, con alabeo y puntos): el modelo ajustado; donde u es baja, la densidad a posteriori de las nubes
// modula los jovenes y el polvo con peso c′ = CMAX·completitud·mascara·(1 − rampa(u)) ≤ 0,5, sin cambiar el nivel local de la luz (LVL). Por
// filas, en tres pasadas (escala global; dato saturado y sumas gruesas; mezcla) con el nivel calculado entre la segunda y la tercera.
// ---------------------------------------------------------------------------
function fvGgMixBegin(Tm, S, P) {
   var N = Tm.N, n2 = N * N, NK = S.NK;
   var Dd = fvGalDataUp(P.Dpost, NK, S.H, N), U = fvGalDataUp(P.U.u, FV_GAL_GG.NL, S.H, N);
   return { Tm: Tm, N: N, H: Tm.H, px: Tm.px, Dd: Dd, U: U, cR: fvGgRidgeCol(FV_GAL3.COL_OLD, FV_GAL3.COL_YOUNG), CC: new Float32Array(n2), FL: new Float32Array(n2), DN: new Float32Array(n2), sAr: 0, sYd: 0, sAD: 0, sDd: 0, mean: 0, nm: 0,
            r: new Float32Array(n2), g: new Float32Array(n2), b: new Float32Array(n2), dust: new Float32Array(n2), arm: new Float32Array(n2), armDust: new Float32Array(n2) };
}
function fvGgMixRow1(M, j) {
   var GG = FV_GAL_GG, G = FV_GAL3, N = M.N, H = M.H, px = M.px, Tm = M.Tm, Y = -H + (j + 0.5) * px;
   for (var i = 0; i < N; ++i) {
      var X = -H + (i + 0.5) * px, R = Math.sqrt(X * X + Y * Y), o = j * N + i;
      if (R > H) continue;
      M.FL[o] = 0.30 + 1.45 * fvGal3Fbm2(X / 0.9, Y / 0.9, 11, 3); M.DN[o] = fvGal3Fbm2(X / 0.55, Y / 0.55, 23, 3);
      var d = Math.sqrt((X + G.R0) * (X + G.R0) + Y * Y), uu = M.U[o];
      var cc = GG.CMAX * fvGgSelC(d) * fvGgMaskXY(X, Y, GG.MASK_RAMP) * (1 - fvGal3Smooth((uu - GG.U_LO) / (GG.U_HI - GG.U_LO))) * (1 - fvGal3Smooth((R - 14) / 3)) * (GG.SUN_FADE ? fvGal3Smooth((d - GG.SUN_FADE[0]) / (GG.SUN_FADE[1] - GG.SUN_FADE[0])) : 1);
      M.CC[o] = cc;
      if (cc > 0) { M.sAr += cc * Tm.arm[o]; M.sYd += cc * M.Dd[o] * M.FL[o]; M.sAD += cc * Tm.armDust[o]; M.sDd += cc * M.Dd[o]; }
   }
}
function fvGgMixMid(M) { M.sY = M.sYd > 0 ? M.sAr / M.sYd : 1; M.sD = M.sDd > 0 ? M.sAD / M.sDd : 1; }
// (encargo GG, 9-nov, tras verlo en el fotograma) la luz del dato ya saturada, por fila, y sus sumas en la rejilla gruesa NL×NL (c′·modelo y
// c′·dato), para que el dato solo REPARTA la luz dentro de LVL_KPC y no cambie su nivel (fvGgMixMid2). Guarda la luz joven en FL (ya no hace falta)
function fvGgMixRowS(M, j) {
   var GG = FV_GAL_GG, N = M.N, H = M.H, px = M.px, Tm = M.Tm, Y = -H + (j + 0.5) * px, sY = M.sY, sD = M.sD, YS = GG.YSAT, NC = GG.NL, cj = Math.floor(j * NC / N);
   if (!M.CA) { var nc = NC * NC; M.CA = new Float64Array(nc); M.CY = new Float64Array(nc); M.CAD = new Float64Array(nc); M.CDD = new Float64Array(nc); M.DS = new Float32Array(N * N); }
   for (var i = 0; i < N; ++i) {
      var X = -H + (i + 0.5) * px, o = j * N + i, cc = M.CC[o];
      if (!(cc > 0) || X * X + Y * Y > H * H) continue;
      var am = Tm.arm[o], yd = sY * M.Dd[o] * M.FL[o], dd = sD * M.Dd[o];
      yd = yd / (1 + yd / (YS * am + 0.02)); dd = dd / (1 + dd / (YS * Tm.armDust[o] + 0.02));     // saturacion suave respecto del modelo: el dato no enciende focos
      M.FL[o] = yd; M.DS[o] = dd;
      var q = cj * NC + Math.floor(i * NC / N);
      M.CA[q] += cc * am; M.CY[q] += cc * yd; M.CAD[q] += cc * Tm.armDust[o]; M.CDD[q] += cc * dd;
   }
}
// el NIVEL: las cuatro sumas suavizadas a LVL_KPC (σ) y su cociente k = <c′·modelo>/<c′·dato> en la rejilla gruesa, subido a N×N (bilineal).
// El peso c′ es el mismo arriba y abajo, asi que la mascara (c′ = 0) no entra en la media de su borde. Con LVL apagada, k = 1 (lo de antes).
function fvGgMixMid2(M) {
   var GG = FV_GAL_GG, NC = GG.NL, nc = NC * NC, KY = new Float32Array(nc), KD = new Float32Array(nc), FY = new Float32Array(nc), q;
   if (!M.CA) { var nn = M.N * M.N; M.KY = new Float32Array(nn); M.KD = new Float32Array(nn); M.FY = new Float32Array(nn); M.KY.fill(1); M.KD.fill(1); M.FY.fill(1); return; }
   if (!GG.LVL) { KY.fill(1); KD.fill(1); FY.fill(1); }
   else {
      var sg = GG.LVL_KPC / (2 * M.H / NC);
      fvGgBlur(M.CA, NC, sg); fvGgBlur(M.CY, NC, sg); fvGgBlur(M.CAD, NC, sg); fvGgBlur(M.CDD, NC, sg);
      for (q = 0; q < nc; ++q) {
         var A = M.CA[q], Yq = M.CY[q], rho = A > 1e-9 ? Yq / A : 0, rm = GG.LVL_RHO;
         if (!(A > 1e-9)) { KY[q] = 1; FY[q] = 0; }
         else if (rho < rm) { KY[q] = 1 / rm; FY[q] = rho / rm; }
         else { KY[q] = 1 / rho; FY[q] = 1; }
         var Ad = M.CAD[q], Dq = M.CDD[q]; KD[q] = (Ad > 1e-9 && Dq > 1e-9) ? Math.max(rm, Math.min(1 / rm, Ad / Dq)) : 1;
      }
   }
   M.KY = fvGalDataUp(KY, NC, M.H, M.N); M.KD = fvGalDataUp(KD, NC, M.H, M.N); M.FY = fvGalDataUp(FY, NC, M.H, M.N);
   M.CA = M.CY = M.CAD = M.CDD = null;
}
function fvGgMixRow2(M, j) {
   var GG = FV_GAL_GG, G = FV_GAL3, N = M.N, H = M.H, px = M.px, Tm = M.Tm, cO = G.COL_OLD, cY = G.COL_YOUNG, kd = G.DUST_RGB, Y = -H + (j + 0.5) * px;
   for (var i = 0; i < N; ++i) {
      var X = -H + (i + 0.5) * px, R = Math.sqrt(X * X + Y * Y), o = j * N + i;
      if (R > H) continue;
      var cc = M.CC[o] * M.FY[o];
      if (!(cc > 0)) { M.r[o] = Tm.r[o]; M.g[o] = Tm.g[o]; M.b[o] = Tm.b[o]; M.dust[o] = Tm.dust[o]; M.arm[o] = Tm.arm[o]; M.armDust[o] = Tm.armDust[o]; continue; }
      if (Tm.dsat) { fvGf4MixPx(M, Tm, o, X, Y, R, cc); continue; }          // (GF4) el disco compensado y la τ de cara saturada
      // el disco viejo del modelo (con su m = 2) y los nudos/cumulos sembrados (lo que sobra del continuo) se quedan
      var old = Math.exp(-R / G.HR_OLD) * (1 - Math.exp(-R * R / (2.6 * 2.6))) * (1 - fvGal3Smooth((R - 15) / 4.5)) * (Tm.oldF ? 1 : fvGgM2(X, Y, Tm.m2ph)) * (Tm.barX ? fvGf2Sweep(R) : 1);
      var am = Tm.arm[o], aO = G.A_OLD * old, aR = Tm.oldF ? aO * Tm.oldF[o] : 0, aY = G.A_YOUNG * am, tdu = Tm.dust[o], cR = Tm.oldF ? M.cR : cO;
      if (Tm.barX) aO += G.A_OLD * Tm.barX[o];                          // (GF2) la barra es luz vieja del modelo: se queda, con el polvo nuevo
      var kr = Tm.r[o] - (aO * cO[0] + aR * cR[0] + aY * cY[0]) * Math.exp(-tdu * kd[0]), kg = Tm.g[o] - (aO * cO[1] + aR * cR[1] + aY * cY[1]) * Math.exp(-tdu * kd[1]), kb = Tm.b[o] - (aO * cO[2] + aR * cR[2] + aY * cY[2]) * Math.exp(-tdu * kd[2]);
      if (kr < 0) kr = 0; if (kg < 0) kg = 0; if (kb < 0) kb = 0;
      var yd = M.KY[o] * M.FL[o], dd = M.KD[o] * M.DS[o];      // el dato saturado (fvGgMixRowS), llevado al nivel local del modelo
      var young = (1 - cc) * am + cc * yd, adl = (1 - cc) * Tm.armDust[o] + cc * dd, dn = M.DN[o];
      var dust = G.DUST_K * (adl * (0.30 + 1.5 * dn) + 0.22 * Math.exp(-R / 4.5) * dn * (1 - fvGal3Smooth((R - 13) / 5)));
      if (Tm.laneD) dust += Tm.laneD[o];                                // (GF2) las lineas de polvo de la barra
      var er = aO * cO[0] + aR * cR[0] + G.A_YOUNG * young * cY[0], eg = aO * cO[1] + aR * cR[1] + G.A_YOUNG * young * cY[1], eb = aO * cO[2] + aR * cR[2] + G.A_YOUNG * young * cY[2];
      M.r[o] = er * Math.exp(-dust * kd[0]) + kr; M.g[o] = eg * Math.exp(-dust * kd[1]) + kg; M.b[o] = eb * Math.exp(-dust * kd[2]) + kb;
      M.dust[o] = dust; M.arm[o] = young; M.armDust[o] = adl;
   }
}
// (GF4) (4) la luz del bulbo de GF2 menos la del de GF4 (Σ a·(2π)^1,5·σx·σy·σz × BULGE_K): el bulbo nuevo la cede al disco liso (fvGf4Comp)
function fvGf4BulgeDeficit() {
   var B4 = (FV_GAL_GF5.ON && fvGf5On() && FV_GAL_GF5.BULGE) ? FV_GAL_GF5.BULGE : FV_GAL_GF4.BULGE, B2 = FV_GAL_GF2.BULGE; if (!B4) return 0;   // (GF5) su bulbo
   if (FV_GAL_GF6.ON && fvGf6On() && FV_GAL_GF6.BULGE) B4 = FV_GAL_GF6.BULGE; if (FV_GAL_GF7.ON && fvGf7On() && FV_GAL_GF7.BULGE) B4 = FV_GAL_GF7.BULGE; if (FV_GAL_GF8.ON && fvGf8On() && FV_GAL_GF8.BULGE) B4 = FV_GAL_GF8.BULGE;                                                // (GF6) el suyo
   function L(B) { var s = 0; for (var q = 0; q < B.length; ++q) s += B[q].a * B[q].sx * B[q].sy * B[q].sz; return s; }
   return (L(B2) - L(B4)) * Math.pow(2 * Math.PI, 1.5) * FV_GAL_GF2.BULGE_K;
}
// (GF4) un texel de la mezcla con el dato: la cuenta de fvGgMixRow2 con el disco liso × discK por canal y la τ de cara saturada (fvGf4DustF)
function fvGf4MixPx(M, Tm, o, X, Y, R, cc) {
   var G = FV_GAL3, cO = G.COL_OLD, cY = G.COL_YOUNG, kd = G.DUST_RGB, e4 = Tm.discK || [0, 0, 0], u4 = Tm.DK ? Tm.DK[o] : 0, dk = [1 - u4 * e4[0], 1 - u4 * e4[1], 1 - u4 * e4[2]], c;
   var old = Math.exp(-R / G.HR_OLD) * (1 - Math.exp(-R * R / (2.6 * 2.6))) * (1 - fvGal3Smooth((R - 15) / 4.5)) * (Tm.oldF ? 1 : fvGgM2(X, Y, Tm.m2ph)) * (Tm.barX ? fvGf2Sweep(R) : 1);
   var mw6 = Tm.gf6 ? fvGf6MoatW(X, Y, R) : 0; if (mw6 > 0) old *= 1 - fvGf6M().D * mw6;   // (GF6) (1) la fosa, igual que en el mapa
   var am = Tm.arm[o], aO = G.A_OLD * old, aR = Tm.oldF ? aO * Tm.oldF[o] : 0, aY = G.A_YOUNG * am, aB = Tm.barX ? G.A_OLD * Tm.barX[o] : 0, cR = Tm.oldF ? M.cR : cO, d0 = fvGf4DustF(Tm.dust[o]);
   var yd = M.KY[o] * M.FL[o], dd = M.KD[o] * M.DS[o], young = (1 - cc) * am + cc * yd, adl = (1 - cc) * Tm.armDust[o] + cc * dd, dn = M.DN[o];
   var ED = FV_GAL_GF4.EDGE; if (ED.D > 0) young *= 1 - ED.D * fvGal3Smooth((R - ED.R0) / ED.RW) * (ED.MIX ? 1 : 0);   // (6) el borde de la luz joven, tambien la del dato
   var dust = G.DUST_K * (adl * (0.30 + 1.5 * dn) + 0.22 * Math.exp(-R / 4.5) * dn * (1 - fvGal3Smooth((R - 13) / 5)));
   if (Tm.laneD) dust += Tm.laneD[o];
   if (mw6 > 0) dust += fvGf6M().TAU * mw6;                     // (GF6) (1) el polvo de la fosa
   var df = fvGf4DustF(dust), out = [0, 0, 0], src = [Tm.r[o], Tm.g[o], Tm.b[o]];
   for (c = 0; c < 3; ++c) { var base = (aO * dk[c] + aB) * cO[c] + aR * cR[c], kc = src[c] - (base + aY * cY[c]) * Math.exp(-d0 * kd[c]); if (kc < 0) kc = 0; out[c] = (base + G.A_YOUNG * young * cY[c]) * Math.exp(-df * kd[c]) + kc; }
   M.r[o] = out[0]; M.g[o] = out[1]; M.b[o] = out[2]; M.dust[o] = dust; M.arm[o] = young; M.armDust[o] = adl;
}
function fvGgMixEnd(M, S, P) {
   var WG = S.wg;
   var T = { N: M.N, H: M.H, px: M.px, r: M.r, g: M.g, b: M.b, dust: M.dust, arm: M.arm, armDust: M.armDust, ms: 0, brk: FV_GAL3_BREAK, stars: null, data: "gg",
            warp: WG.z, warpMax: WG.max, warpR0: (FV_GAL_DATA.WARP.RD - 0.5) * (FV_GAL_DATA.WARP.RD - 0.5), warpF: fvGalDataWarp, pts: fvGgPts(P.PG), conf: M.CC, sY: M.sY, sD: M.sD };
   if (M.Tm.barX && fvGf2On()) {         // (GF2) el bulbo en caja con lobulos y su escala de luz; la luz de la barra (pruebas); los puntos, solo en SOLO DATOS
      T.bulge = FV_GAL_GF2.BULGE; T.bulgeK = FV_GAL_GF2.BULGE_K; T.barL = M.Tm.barL; T.gf2 = true;
      if (!FV_GAL_GF2.PTS) T.pts = null;
      if (fvGf3On() && M.Tm.lanes) {     // (GF3) la capa de canto (polvo del rayo) y las curvas de los carriles (pruebas)
         var V0 = FV_GAL3_VOL, V3 = FV_GAL_GF3.VOL, VV = {}; for (var kv in V0) if (V0.hasOwnProperty(kv)) VV[kv] = V0[kv];
         for (kv in V3) if (V3.hasOwnProperty(kv)) VV[kv] = V3[kv];
         T.vol = VV; T.gf3 = true; T.gf3lanes = M.Tm.lanes; T.k3 = M.Tm.k3;
         if (fvGf4On() && M.Tm.dsat) {   // (GF4) el bulbo con el nucleo compacto, la capa de canto de GF4 y lo que miran las pruebas
            var F4 = FV_GAL_GF4; if (F4.BULGE) T.bulge = F4.BULGE;
            if (F4.VOL) for (kv in F4.VOL) if (F4.VOL.hasOwnProperty(kv)) VV[kv] = F4.VOL[kv];
            T.gf4 = true; T.discK = M.Tm.discK; T.comp = M.Tm.comp; T.k3g3 = M.Tm.k3g3;
            if (fvGf5On() && M.Tm.gf5) {   // (GF5) su bulbo, su capa de canto y lo que miran las pruebas
               var F5 = FV_GAL_GF5; if (F5.BULGE) T.bulge = F5.BULGE;
               if (F5.VOL) for (kv in F5.VOL) if (F5.VOL.hasOwnProperty(kv)) VV[kv] = F5.VOL[kv];
               T.gf5 = true; T.hii5 = M.Tm.hii5;
               if (fvGf6On() && M.Tm.gf6) {   // (GF6) su bulbo (si lo hay), su capa de canto (ZK, POP) y lo que miran las pruebas
                  var F6 = FV_GAL_GF6; if (F6.BULGE) T.bulge = F6.BULGE;
                  if (F6.VOL) for (kv in F6.VOL) if (F6.VOL.hasOwnProperty(kv)) VV[kv] = F6.VOL[kv];
                  T.gf6 = true; T.mBoost = M.Tm.mBoost;
                  if (fvGf7On() && M.Tm.gf7) {   // (GF7) su bulbo (lobulos a lo largo de la barra) y su capa de canto (capa joven en sech², disco grueso)
                     var F7 = FV_GAL_GF7; if (F7.BULGE) T.bulge = F7.BULGE;
                     if (F7.VOL) for (kv in F7.VOL) if (F7.VOL.hasOwnProperty(kv)) VV[kv] = F7.VOL[kv];
                     T.gf7 = true;
                     if (fvGf8On() && M.Tm.gf8) {   // (GF8) su capa de canto (polvo de la capa joven, luz vieja sin estructura por encima del plano) y su bulbo (si lo hay)
                        var F8 = FV_GAL_GF8; if (F8.BULGE) T.bulge = F8.BULGE;
                        if (F8.VOL) for (kv in F8.VOL) if (F8.VOL.hasOwnProperty(kv)) VV[kv] = F8.VOL[kv];
                        T.gf8 = true;
                        if (fvGf9On() && M.Tm.gf9) {   // (GF9) su capa de canto (ensanchamiento del polvo, luz vieja del bulbo en caja con altura, ver FV_GAL_GF9.VOL)
                           var F9 = FV_GAL_GF9;
                           if (F9.VOL) for (kv in F9.VOL) if (F9.VOL.hasOwnProperty(kv)) VV[kv] = F9.VOL[kv];
                           T.gf9 = true;
                        }
                     }
                  }
               }
            }
         }
      }
   }
   return T;
}
// los puntos: maseres, HII con paralaje y HII cinematicos, con alfa min(1, PT_KIN/σ_d) (σ_d: paralaje o pdf cinematica); sin tangentes ni mascara
function fvGgPts(PG) {
   var A = FV_GAL_DATA, GG = FV_GAL_GG, G = FV_GAL3, L = [];
   [["M", A.PT_M], ["H", A.PT_H]].forEach(function(e) {
      var t = e[0], st = e[1], list = PG[t], P = [], Am = [];
      for (var q = 0; q < list.length; ++q) {
         var o = list[q], a = st.a * GG.PT_GAIN;
         if (t === "H" && (o.arm === "T" || o.msk)) continue;
         a *= Math.min(1, GG.PT_KIN / Math.max(1e-3, o.sA));      // todos (maseres incluidos): alfa por su error de distancia (los lejanos con paralaje pobre hacian una raya Sol–centro)
         var d = o.d; P.push(d * o.ux - G.R0, d * o.uy, d * Math.sin(o.b * Math.PI / 180) + G.ZSUN); Am.push(a);
      }
      L.push({ t: t, n: Am.length, p: new Float32Array(P), a: new Float32Array(Am), col: st.col, r: st.r });
   });
   return L;
}
