// ============================================================================
// FieldVoyager/src/engine/fv_aenigma.js — (I1, 19-nov-2026) AENIGMATA + LA CADENA DE «¿POR QUE?» (E1-03 y E1-04 de docs/ideas-enganche-19nov.md, JUNTOS)
// ----------------------------------------------------------------------------
// Nino: «junta 2 y 3 e implementalo». Como se unen:
//   · AENIGMATA es el REVERSO de la placa MIRABILIA (la misma caja; un clic en su titulo la gira): hasta FV_E1C.MAX misterios de la foto, cada uno un
//     sobre con su enunciado SIN la solucion. Se resuelve yendo: al abrirse la ficha del objeto, su primera frase es LA PRUEBA (los numeros del
//     catalogo) y el sobre queda abierto. No hay puntos, ni cuenta, ni nota: un sobre abierto solo enseña su dato.
//   · LA CADENA: cada ficha acaba en UNA pregunta dorada cuya respuesta esta en OTRO objeto de la misma foto. Un clic = viajar; al llegar, la primera
//     frase de la ficha nueva es la respuesta, y esa ficha abre la pregunta siguiente. Un misterio es el primer eslabon de una cadena (la intrusa
//     pregunta por el protagonista; la pareja, por su compañera…). Cada eslabon se ofrece una vez por sesion y nunca devuelve al sitio del que se viene.
// TODO sale de los datos de la escena (Gaia DR3: paralaje, movimiento propio y sus errores; Bailer-Jones; los cumulos y objetos que ya trae el script).
// Si un dato no alcanza el umbral, el misterio o la pregunta NO aparecen (nunca se inventa); el porque queda en aenigma.why (para el registro).
// LOS DETECTORES (fvE1cDetect; poblacion = estrellas DENTRO de la foto con distancia MEDIDA, q = 0):
//   near    la intrusa: la mas cercana, con paralaje/error ≥ SNR, y la mediana de la poblacion ≥ NEAR_RATIO veces mas lejos.
//   pair    la pareja que viaja junta: el criterio de El-Badry, Rix y Heintz 2021 (MNRAS 506, 2269): paralajes compatibles a 3 σ, diferencia de
//           movimiento propio ≤ la de una orbita ligada (0,44 mas/año · ϖ^1,5 · θ^−0,5) + 2 σ, separacion proyectada ≤ PAIR_S_MAX au, a menos de 1 kpc.
//           La probabilidad de alineacion casual se MIDE en la propia foto: K = pares de la poblacion (a cualquier separacion) que cumplirian lo mismo;
//           E = max(K, 1) · π θ² / area de la foto = pares asi de juntos esperados por azar. Solo sale si E ≤ PAIR_CHANCE, y la ficha dice «1 entre N».
//   fast    la fugitiva: velocidad de lado (4,74 · μ · d) respecto a la mediana de las FAST_K estrellas de su misma distancia (asi no cuenta el reflejo
//           del Sol ni la rotacion galactica, que a igual distancia y direccion son comunes); sale si Δ ≥ FAST_MIN_KMS y Δ − 2 σ ≥ FAST_SIG veces
//           la dispersion tipica de ese grupo. No se afirma de donde viene: solo que no se mueve con las demas.
//   quasar  la impostora: un objeto de la escena de tipo cuasar con corrimiento al rojo (el cruce que ya hace el script).
//   far     la forastera: una galaxia de la escena (no el protagonista) con distancia de catalogo, si el protagonista no es una galaxia.
//   La VARIABLE (E1-04) NO sale: ni la base local de Gaia ni las consultas del script traen la bandera de variabilidad (phot_variable_flag).
// LOS ESLABONES (fvE1cLink; cada uno con su condicion de datos):
//   pair (a su compañera) · cluster (estrella miembro -> su cumulo) · top (cumulo -> su miembro mas brillante) · twin (gigante -> una enana de su misma
//   temperatura, ≥ 100 veces menos luz) · depth (-> el protagonista, si las dos distancias son conocidas y sus intervalos no se tocan) · near (objeto ->
//   la estrella medida mas cercana).
// PURO y ES5: lo incluye PixInsight y viaja al paquete web (engine/fv_aenigma.js). El visor NO recalcula los misterios: lee scene.aenigma del paquete
// (el paquete no lleva los errores de paralaje ni de movimiento propio); los eslabones si se calculan en los dos lados, con los mismos datos.
// FV_E1C.ON = false: lo de antes (ni reverso ni pregunta). AENIG / CHAIN apagan cada mitad (los rojos de tests/_e1c). Gemelo web: FW_E1C (web/fw_e1c.js).
// ============================================================================

var FV_E1C = {
   ON: true,                // false = lo de antes
   AENIG: true,             // el reverso AENIGMATA de MIRABILIA
   CHAIN: true,             // la pregunta al pie de la ficha
   MAX: 3,                  // como mucho tres misterios por foto (E1-04: pocos y con solucion demostrable)
   MIN_STARS: 30,           // con menos estrellas medidas en la foto no hay «resto» con el que comparar: sin misterios
   SNR: 10,                 // paralaje / error ≥ 10 (distancia al 10 %): el sujeto de un misterio tiene que estar MEDIDO de sobra
   NEAR_RATIO: 10,          // la intrusa: la estrella mediana de la foto, al menos 10 veces mas lejos (un orden de magnitud: se ve en PROFUNDITAS)
   PAIR_PLX_MIN: 1,         // mas: a menos de 1 kpc, el limite del catalogo de El-Badry et al. 2021
   PAIR_S_MAX: 30000,       // au de separacion proyectada: por encima dominan las alineaciones casuales en campos densos (El-Badry 2021, fig. de contaminacion)
   PAIR_PLX_SIG: 3,         // paralajes compatibles a 3 σ (El-Badry 2021, b = 3)
   PAIR_PM_SIG: 2,          // Δμ ≤ Δμ de orbita + 2 σ (El-Badry 2021)
   PAIR_ORBIT: 0.44,        // mas/año · (ϖ/mas)^1,5 · (θ/″)^−0,5: orbita circular de 5 M☉ en total (El-Badry 2021, ec. 4)
   PAIR_CHANCE: 0.01,       // pares igual de juntos esperados por azar en la foto ≤ 0,01 (1 entre 100): umbral nuestro, conservador
   PAIR_NMAX: 1500,         // tope de candidatas (las mas brillantes): el recuento de azar es cuadratico
   PAIR_NEVAL: 12,          // parejas (las mas juntas) a las que se les mide el azar
   FAST_K: 40,              // vecinas de distancia con las que se compara
   FAST_KMIN: 15,           // con menos no hay dispersion que medir
   FAST_DSPAN: 1.5,         // las vecinas, a menos de un factor 1,5 en distancia
   FAST_MIN_KMS: 80,        // y al menos 80 km/s de lado respecto a ellas (la dispersion del disco fino es de 30–40 km/s: dos veces eso)
   FAST_SIG: 5,             // (Δ − 2 σ) ≥ 5 veces la velocidad relativa tipica del grupo
   FAST_ERR: 2,
   FAST_OLD: false,         // (F2, 20-nov) true = el misterio «La fugitiva» de antes (velocidad de lado respecto a las vecinas de su distancia, cualquier tipo de estrella); false = la fugitiva con el criterio de la literatura (src/engine/fv_runaway.js: velocidad peculiar, estrella caliente y luminosa, 0 falsas en el control). Sin fv_runaway.js cargado, el de antes
   TWIN_DT: 0.07,           // la «misma temperatura»: a menos del 7 %
   TWIN_DMAG: 5,            // 5 magnitudes absolutas = 100 veces menos luz
   TWIN_MG: 1,              // la gigante: magnitud absoluta G ≤ 1 (sin quitar el polvo)
   TWIN_T: [3500, 6500],    // solo donde gigante y enana comparten temperatura (por encima, la secuencia principal ya es luminosa)
   TWIN_ERR: 0.2,           // distancias al 20 % las dos
   DEPTH_RATIO: 1.5,        // «mas lejos / delante» solo si las distancias difieren en un factor 1,5 y sus intervalos no se tocan
   _END: 0
};
var FV_E1C_ST = null;       // el estado de la SESION (sobres abiertos, eslabones ya ofrecidos, de donde se viene): no se guarda en disco

function fvE1cOn() { return typeof FV_E1C !== "undefined" && FV_E1C.ON === true; }
function fvE1cLyPerPc() { return (typeof FV_LY_PER_PC !== "undefined") ? FV_LY_PER_PC : 3.2615637769; }
function fvE1cFin(x) { return typeof x === "number" && isFinite(x); }
function fvE1cMed(a) { if (!a.length) return NaN; var s = a.slice().sort(function(p, q) { return p - q; }); return (s.length & 1) ? s[s.length >> 1] : 0.5 * (s[(s.length >> 1) - 1] + s[s.length >> 1]); }
function fvE1cSig(x, n, L) { if (typeof fvsFmtSig === "function") return fvsFmtSig(x, n, L); var v = Number(Number(x).toPrecision(n)); return String(v).replace(".", L === "es" ? "," : "."); }
function fvE1cNum(x, dec, L) { if (typeof fvsFmtNum === "function") return fvsFmtNum(x, dec, L); return Number(x).toFixed(dec).replace(".", L === "es" ? "," : "."); }
function fvE1cFill(s, p) { if (p) for (var k in p) if (Object.prototype.hasOwnProperty.call(p, k)) s = s.split("{" + k + "}").join(String(p[k])); return s; }

// la SESION: una por escena
function fvE1cState(scene) {
   if (!FV_E1C_ST || FV_E1C_ST.scene !== scene) FV_E1C_ST = { scene: scene, ver: 0, open: {}, used: {}, via: null, prev: "", face: 0 };
   return FV_E1C_ST;
}
function fvE1cVer(scene) { return fvE1cOn() ? fvE1cState(scene).ver : 0; }

// la seleccion en su forma unica: un objeto «estrella» es su estrella; la nebulosa principal es su fila (objeto main) si la hay
function fvE1cCanon(scene, sel) {
   if (!sel || !scene) return null;
   var O = scene.objects || [], i;
   if (sel.kind === "star" && sel.i >= 0) return { kind: "star", i: sel.i };
   if (sel.kind === "object" && O[sel.i]) { var o = O[sel.i]; if ((o.type === "star" || o.type === "exoplanet") && o.star >= 0) return { kind: "star", i: o.star }; return { kind: "object", i: sel.i }; }
   if (sel.kind === "nebula") { for (i = 0; i < O.length; ++i) if (O[i] && O[i].main === true) return { kind: "object", i: i }; return { kind: "nebula" }; }
   return null;
}
function fvE1cKey(scene, sel) { var c = fvE1cCanon(scene, sel); return !c ? "" : (c.kind === "nebula" ? "neb" : c.kind + ":" + c.i); }

// la POBLACION: estrellas de dentro de la foto con distancia MEDIDA (q = 0: paralaje de fiar y RUWE < 1,4)
function fvE1cPop(scene) {
   var S = scene && scene.stars, out = [];
   if (!S || !S.meta) return out;
   for (var i = 0; i < S.n; ++i) { var m = S.meta[i]; if (!m || !S.inFrame[i] || S.q[i] !== 0 || !(S.dEarth[i] > 0) || m.outside || m.wide) continue; out.push(i); }
   return out;
}
function fvE1cInCluster(m) { return m && m.cluster !== undefined && m.cluster !== null && m.cluster >= 0; }
// el error relativo de la distancia de una estrella (el intervalo de la escena; sin el, el de la paralaje)
function fvE1cDistErr(S, i) {
   var m = S.meta[i] || {}, d = S.dEarth[i], k = fvE1cLyPerPc();
   if (m.lo > 0 && m.hi > 0 && d > 0) return 0.5 * (m.hi - m.lo) * k / d;
   if (m.plx > 0 && m.plxErr > 0) return m.plxErr / m.plx;
   return NaN;
}

// ---------------------------------------------------------------------------
// LOS DETECTORES. -> { v, n (poblacion), medLy, maxLy, list: [{ k, sel, also, d }], why: { near, pair, fast, notstar, variable } }
// ---------------------------------------------------------------------------
function fvE1cPairOk(a, b, th) {
   var dp = Math.abs(a.p - b.p), sp = Math.sqrt(a.e * a.e + b.e * b.e);
   if (dp > FV_E1C.PAIR_PLX_SIG * sp) return null;
   var pb = 0.5 * (a.p + b.p), orb = FV_E1C.PAIR_ORBIT * Math.pow(pb, 1.5) / Math.sqrt(th), dx = a.mr - b.mr, dy = a.md - b.md, dm = Math.sqrt(dx * dx + dy * dy), sm = Math.sqrt(a.pe * a.pe + b.pe * b.pe);
   if (dm > orb + FV_E1C.PAIR_PM_SIG * sm) return null;
   return { dm: dm, sm: sm, orb: orb, pb: pb };
}
function fvE1cDetect(scene) {
   var S = scene.stars, pop = fvE1cPop(scene), out = { v: 1, n: pop.length, medLy: NaN, maxLy: NaN, list: [], why: { variable: "no variability flag in the data the script loads (local Gaia DR3 base and VizieR refinement)" } }, i, j, k, m, LY = fvE1cLyPerPc();
   if (pop.length < FV_E1C.MIN_STARS) { out.why.all = "only " + pop.length + " measured stars inside the photo (needs " + FV_E1C.MIN_STARS + ")"; return out; }
   var ds = []; for (i = 0; i < pop.length; ++i) ds.push(S.dEarth[pop[i]]);
   out.medLy = fvE1cMed(ds); out.maxLy = Math.max.apply(null, ds);
   var found = {}, taken = {};
   // ---- near: la intrusa ----
   var nb = -1; for (i = 0; i < pop.length; ++i) if (nb < 0 || S.dEarth[pop[i]] < S.dEarth[nb]) nb = pop[i];
   if (nb >= 0) {
      m = S.meta[nb]; var er = fvE1cDistErr(S, nb), ratio = out.medLy / S.dEarth[nb];
      if (fvE1cInCluster(m)) out.why.near = "the nearest star is a member of a cluster of the photo: it is not an intruder, it is the cluster that is near";
      else if (!(er <= 1 / FV_E1C.SNR)) out.why.near ="the nearest star is not measured well enough (distance error " + (fvE1cFin(er) ? Math.round(100 * er) + " %" : "unknown") + ", needs ≤ " + Math.round(100 / FV_E1C.SNR) + " %)";
      else if (!(ratio >= FV_E1C.NEAR_RATIO)) out.why.near = "the nearest star is only " + ratio.toFixed(1) + " times nearer than the middle one (needs ≥ " + FV_E1C.NEAR_RATIO + ")";
      else found.near = { k: "near", sel: { kind: "star", i: nb }, d: { dLy: S.dEarth[nb], eLy: er * S.dEarth[nb], plx: fvE1cFin(m.plx) ? m.plx : null, eplx: fvE1cFin(m.plxErr) ? m.plxErr : null, medLy: out.medLy, N: pop.length, n: ratio } };
   }
   // ---- pair: la pareja que viaja junta ----
   var C = [];
   for (i = 0; i < pop.length; ++i) {
      m = S.meta[pop[i]];
      if (!(m.plx >= FV_E1C.PAIR_PLX_MIN) || !(m.plxErr > 0) || m.plx / m.plxErr < FV_E1C.SNR || !fvE1cFin(m.pmRa) || !fvE1cFin(m.pmDec) || !(m.pmErr > 0) || fvE1cInCluster(m) || !fvE1cFin(m.ra) || !fvE1cFin(m.dec)) continue;
      C.push({ i: pop[i], p: m.plx, e: m.plxErr, mr: m.pmRa, md: m.pmDec, pe: m.pmErr, ra: m.ra, dec: m.dec, g: S.g[pop[i]] });
   }
   if (C.length > FV_E1C.PAIR_NMAX) { C.sort(function(a, b) { return a.g - b.g; }); C.length = FV_E1C.PAIR_NMAX; }
   var f = scene.field || {}, area = (f.width > 0 && f.height > 0 && f.scaleArcsec > 0) ? f.width * f.height * f.scaleArcsec * f.scaleArcsec : 0;
   if (C.length < 2) out.why.pair = "fewer than two stars within 1 kpc with parallax and proper-motion errors (" + C.length + "); offline there are none";
   else if (!(area > 0)) out.why.pair = "no field size to measure the chance alignment";
   else {
      C.sort(function(a, b) { return a.dec - b.dec; });
      var cands = [], nPass = 0;
      for (i = 0; i < C.length; ++i) {
         var a = C[i], cd = Math.cos(a.dec * Math.PI / 180), thMaxA = FV_E1C.PAIR_S_MAX * a.p / 1000;
         for (j = i + 1; j < C.length; ++j) {
            var b = C[j], dy = (b.dec - a.dec) * 3600; if (dy > thMaxA * 1.2 + 1) break;
            var dra = b.ra - a.ra; if (dra > 180) dra -= 360; if (dra < -180) dra += 360;
            var dx = dra * cd * 3600;
            var th = Math.sqrt(dx * dx + dy * dy), pb0 = 0.5 * (a.p + b.p); if (th < 0.2 || th > FV_E1C.PAIR_S_MAX * pb0 / 1000) continue;
            var ok = fvE1cPairOk(a, b, th); if (!ok) continue;
            ++nPass; cands.push({ a: a, b: b, th: th, ok: ok });
         }
      }
      var best = null;
      cands.sort(function(u, w) { return u.th - w.th; });      // E crece con θ²: las mas juntas primero; el recuento de azar (cuadratico) solo para las PAIR_NEVAL primeras
      for (k = 0; k < cands.length && k < FV_E1C.PAIR_NEVAL; ++k) {
         var cc = cands[k], K = 0;
         for (i = 0; i < C.length; ++i) for (j = i + 1; j < C.length; ++j) { if ((C[i] === cc.a && C[j] === cc.b) || (C[i] === cc.b && C[j] === cc.a)) continue; if (fvE1cPairOk(C[i], C[j], cc.th)) ++K; }
         cc.K = K; cc.E = Math.max(K, 1) * Math.PI * cc.th * cc.th / area;
         if (!best || cc.E < best.E) best = cc;
      }
      if (!best) out.why.pair = "no two stars with the same parallax and proper motion close enough (" + C.length + " candidates)";
      else if (best.E > FV_E1C.PAIR_CHANCE) out.why.pair = "the best pair could be a chance alignment (" + best.E.toFixed(3) + " such pairs expected by chance; needs ≤ " + FV_E1C.PAIR_CHANCE + ")";
      else {
         var A = best.a.g <= best.b.g ? best.a : best.b, B = (A === best.a) ? best.b : best.a;
         found.pair = { k: "pair", sel: { kind: "star", i: A.i }, also: B.i, d: { th: best.th, sAu: best.th * 1000 / best.ok.pb, p1: A.p, e1: A.e, p2: B.p, e2: B.e, m1: Math.sqrt(A.mr * A.mr + A.md * A.md), m2: Math.sqrt(B.mr * B.mr + B.md * B.md),
                        dm: best.ok.dm, sm: best.ok.sm, orb: best.ok.orb, K: best.K, E: best.E, odds: 1 / best.E, nC: C.length, nPass: nPass } };
         taken[A.i] = 1; taken[B.i] = 1;
      }
   }
   if (found.near) taken[found.near.sel.i] = 1;
   // ---- fast: la fugitiva ----
   // (F2, 20-nov) con el criterio de la literatura (fv_runaway.js, encendido): la candidata de la escena, si la hay (si no, NO hay misterio: nada se inventa). El de antes (FAST_OLD) mide
   // «velocidad de lado respecto a las vecinas» de cualquier tipo de estrella: no distingue una fugitiva de una vieja del halo.
   var useRun = (typeof fvRunList === "function" && typeof FV_RUNAWAY !== "undefined" && FV_RUNAWAY.ON === true && FV_E1C.FAST_OLD !== true), V = [];
   if (useRun) {
      var RLs = fvRunList(scene), pickR = null;
      for (i = 0; i < RLs.length && !pickR; ++i) if (!taken[RLs[i].i]) pickR = RLs[i];
      if (pickR) { found.fast = { k: "fast", sel: { kind: "star", i: pickR.i }, d: JSON.parse(JSON.stringify(pickR)) }; found.fast.d.run = true; taken[pickR.i] = 1; }
      else out.why.fast = RLs.length ? "the runaway candidate is already another riddle" : "no hot, luminous star of the photo moves at 30 km/s or more relative to the Galaxy with its 5th percentile above the threshold (runaway criterion of the literature)";
   } else {
   V = [];
   for (i = 0; i < pop.length; ++i) {
      m = S.meta[pop[i]];
      if (!(m.plx > 0) || !(m.plxErr > 0) || m.plx / m.plxErr < FV_E1C.SNR || !fvE1cFin(m.pmRa) || !fvE1cFin(m.pmDec) || !(m.pmErr > 0) || fvE1cInCluster(m)) continue;
      var dpc = S.dEarth[pop[i]] / LY, kv = 4.74047e-3 * dpc, mu = Math.sqrt(m.pmRa * m.pmRa + m.pmDec * m.pmDec);
      V.push({ i: pop[i], d: dpc, vx: kv * m.pmRa, vy: kv * m.pmDec, mu: mu, rel: Math.sqrt(Math.pow(m.plxErr / m.plx, 2) + Math.pow(m.pmErr / Math.max(mu, 1e-6), 2)), kv: kv, pe: m.pmErr, ep: m.plxErr / m.plx });
   }
   if (V.length < FV_E1C.FAST_KMIN + 1) out.why.fast = "too few stars with a parallax 10 times its error and a proper-motion error (" + V.length + "; needs " + (FV_E1C.FAST_KMIN + 1) + "); offline there are none";
   else {
      V.sort(function(a, b) { return a.d - b.d; });
      var bestF = null, bestAny = null;
      for (i = 0; i < V.length; ++i) {
         var v0 = V[i], lo = i - 1, hi = i + 1, nbx = [], nby = [];
         while (nbx.length < FV_E1C.FAST_K) {
            var okLo = lo >= 0 && v0.d / V[lo].d <= FV_E1C.FAST_DSPAN, okHi = hi < V.length && V[hi].d / v0.d <= FV_E1C.FAST_DSPAN;
            if (!okLo && !okHi) break;
            var q = (okLo && (!okHi || (v0.d - V[lo].d) <= (V[hi].d - v0.d))) ? V[lo--] : V[hi++];
            nbx.push(q.vx); nby.push(q.vy);
         }
         if (nbx.length < FV_E1C.FAST_KMIN) continue;
         var mx = fvE1cMed(nbx), my = fvE1cMed(nby), rs = [];
         for (j = 0; j < nbx.length; ++j) rs.push(Math.sqrt(Math.pow(nbx[j] - mx, 2) + Math.pow(nby[j] - my, 2)));
         var sT = Math.max(fvE1cMed(rs), 1), dv = Math.sqrt(Math.pow(v0.vx - mx, 2) + Math.pow(v0.vy - my, 2)), vAbs = Math.sqrt(v0.vx * v0.vx + v0.vy * v0.vy);
         // el error de Δ: el del movimiento propio (km/s) y el de la distancia sobre la velocidad propia de la estrella
         var ev = Math.sqrt(Math.pow(v0.kv * v0.pe, 2) + Math.pow(vAbs * v0.ep, 2)), score = (dv - FV_E1C.FAST_ERR * ev) / sT;
         var rec = { i: v0.i, dv: dv, ev: ev, s: sT, K: nbx.length, score: score, mu: v0.mu, dLy: v0.d * LY };
         if (!bestAny || score > bestAny.score) bestAny = rec;
         if (taken[v0.i]) continue;
         if (dv >= FV_E1C.FAST_MIN_KMS && score >= FV_E1C.FAST_SIG && (!bestF || score > bestF.score)) bestF = rec;
      }
      if (bestF) { found.fast = { k: "fast", sel: { kind: "star", i: bestF.i }, d: { v: bestF.dv, ev: bestF.ev, s: bestF.s, K: bestF.K, n: bestF.dv / bestF.s, mu: bestF.mu, arcmin: bestF.mu * 1e5 / 1000 / 60, wArcmin: (f.width > 0 && f.scaleArcsec > 0) ? f.width * f.scaleArcsec / 60 : null, dLy: bestF.dLy, nV: V.length } }; taken[bestF.i] = 1; }
      else out.why.fast = bestAny ? ("no star stands out: the best moves " + bestAny.dv.toFixed(0) + " km/s against its " + bestAny.K + " neighbours (typical " + bestAny.s.toFixed(0) + " km/s; needs ≥ " + FV_E1C.FAST_MIN_KMS + " km/s and (Δ − 2σ) ≥ " + FV_E1C.FAST_SIG + " × typical; got " + bestAny.score.toFixed(1) + ")") : "no star has enough neighbours at its distance";
   }
   }
   // ---- quasar / far: lo que no es una estrella de nuestra Galaxia ----
   var O = scene.objects || [], qz = -1, gx = -1, heroGal = false;
   for (i = 0; i < O.length; ++i) { var o = O[i]; if (o && (o.hero === true || o.main === true) && o.type === "galaxy") heroGal = true; }
   if (scene.hero && scene.hero.type === "galaxy") heroGal = true;
   for (i = 0; i < O.length; ++i) {
      o = O[i]; if (!o) continue;
      if (o.type === "quasar" && o.z > 0 && (qz < 0 || (o.score || 0) > (O[qz].score || 0))) qz = i;
      if (o.type === "galaxy" && !o.hero && !o.main && o.distLy > 0 && o.distSrc && o.distSrc !== "assumed" && (gx < 0 || (o.score || 0) > (O[gx].score || 0))) gx = i;
   }
   if (qz >= 0) found.notstar = { k: "quasar", sel: { kind: "object", i: qz }, d: { z: O[qz].z, lookbackYr: O[qz].lookbackYr > 0 ? O[qz].lookbackYr : null, src: String(O[qz].distRef || O[qz].src || "") } };
   else if (gx >= 0 && !heroGal && O[gx].distLy > 3 * out.maxLy) found.notstar = { k: "far", sel: { kind: "object", i: gx }, d: { dLy: O[gx].distLy, maxLy: out.maxLy, n: O[gx].distLy / out.maxLy, src: String(O[gx].distRef || ""), cat: O[gx].distSrc === "catalog" } };
   else out.why.notstar = heroGal ? "no quasar with a redshift among the objects of the scene (and the main object is itself a galaxy)" : "no quasar with a redshift and no galaxy with a catalogue distance among the objects of the scene";
   // el orden: lo que MIRABILIA no cuenta ya, primero; la intrusa (que coincide con «La estrella mas cercana») cede su sitio si hay mas de MAX
   var ord = ["pair", "fast", "notstar", "near"];
   for (i = 0; i < ord.length && out.list.length < FV_E1C.MAX; ++i) if (found[ord[i]]) out.list.push(found[ord[i]]);
   if (found.near && out.list.indexOf(found.near) < 0) out.why.near = "found, but the photo already has " + FV_E1C.MAX + " other mysteries";
   return out;
}
// los misterios de la escena: los del paquete (visor web) o los que se calculan aqui una vez (PixInsight)
function fvE1cGet(scene) {
   if (!scene) return { v: 1, n: 0, list: [], why: {} };
   if (!scene.aenigma || !scene.aenigma.list) { var A; try { A = fvE1cDetect(scene); } catch (e) { A = { v: 1, n: 0, list: [], why: { all: "detector error: " + e } }; } scene.aenigma = A; }
   return scene.aenigma;
}
// los que se ENSEÑAN (con las banderas)
function fvE1cList(scene) { return (fvE1cOn() && FV_E1C.AENIG && scene) ? fvE1cGet(scene).list.slice(0, FV_E1C.MAX) : []; }
// el misterio del que `sel` es sujeto (o compañera); null si ninguno
function fvE1cOf(scene, sel) {
   var c = fvE1cCanon(scene, sel), L = fvE1cList(scene);
   if (!c) return null;
   for (var i = 0; i < L.length; ++i) { var y = L[i]; if (y.sel.kind === c.kind && (y.sel.i === c.i || (c.kind === "star" && y.also === c.i))) return y; }
   return null;
}

// ---------------------------------------------------------------------------
// LOS TEXTOS (EN / ES en paralelo). t = titulo del sobre · s = enunciado corto (renglon) · q = enunciado entero (ayuda) · p = la prueba (ficha) · o = el dato del sobre abierto
// ---------------------------------------------------------------------------
var FV_E1C_TX = {
   en: {
      "hd": "AENIGMATA", "hdF": "MIRABILIA",
      "flip": "Turn the plate: on the other side, the riddles of this photo (AENIGMATA). Each one is true and comes from the Gaia measurements of your stars; go there and its card shows the proof.",
      "flipB": "Turn the plate back to MIRABILIA.",
      "how": "Find it yourself (PROFUNDITAS and AETAS help), or press the arrow and the ship takes you. Its card shows the proof.",
      "open": "Opened: the proof is on its card.",
      "near.t": "The intruder", "near.s": "{n}× nearer than the rest", "near.q": "One star in this photo is about {n} times nearer than the typical star around it. Which one?", "near.o": "{d} light-years",
      "near.p": "AENIGMA · the intruder: {d} light-years away, about {n} times nearer than the middle star of your photo.",
      "near.p2": "The intruder: distance {d} ± {e} light-years{px}. The median of the {N} stars measured inside your photo is {med} light-years.",
      "near.px": "; Gaia parallax {p} ± {pe} mas",
      "pair.t": "The travelling pair", "pair.s": "two stars, one journey", "pair.q": "Two stars in this photo travel together through the Galaxy: the same distance and the same motion. Which two?", "pair.o": "{s} au apart",
      "pair.p": "AENIGMA · the travelling pair: its companion is {th}″ away in your photo, {s} times the Earth–Sun distance. Same distance, same motion.",
      "pair.p2": "The travelling pair: Gaia parallax {p1} ± {e1} and {p2} ± {e2} mas; motion across the sky {m1} and {m2} mas a year (they differ by {dm} ± {sm}; a bound pair this wide may differ by {orb}). Odds that two unrelated stars of this photo line up like this: about 1 in {odds} (measured on the {nC} stars of your photo nearer than 3 300 light-years; criterion of El-Badry, Rix & Heintz 2021).",
      "fast.t": "The runaway", "fast.s": "{n}× faster than its neighbours", "fast.q": "One star in this photo crosses the sky about {n} times faster than the stars at its own distance. Which one?", "fast.o": "{v} km/s",
      "fast.p": "AENIGMA · the runaway: {v} km/s sideways relative to the stars at its distance, about {n} times their usual difference.",
      "fast.p2": "The runaway: sideways speed {v} ± {ev} km/s relative to the median of the {K} stars measured nearest to its distance in your photo, which typically differ by {s} km/s. Gaia does not say here where it comes from, only that it does not travel with the rest. In 100 000 years it will have moved {a}′ across the sky (your photo is {w}′ wide): AETAS shows it.",
      "quasar.t": "The impostor", "quasar.s": "a light that is not a star", "quasar.q": "One of the points of light in this photo is not a star. Which one?", "quasar.o": "z = {z}",
      "quasar.p": "AENIGMA · the impostor: not a star but the blazing core of a far-away galaxy (redshift z = {z}).",
      "quasar.p2": "The impostor: redshift z = {z}{lb}. Source: {src}.", "quasar.lb": "; its light set off {t} ago",
      "far.t": "The outsider", "far.s": "not from our Galaxy", "far.q": "Something in this photo does not belong to our Galaxy. What?", "far.o": "{d} light-years",
      "far.p": "AENIGMA · the outsider: another galaxy, about {n} times farther than the farthest star measured in your photo.",
      "far.p2": "The outsider: catalogue distance {d} light-years ({src}); the farthest star measured inside your photo is at {mx} light-years.",
      "q.pair": "Does it travel alone? →", "q.cluster": "Where does it come from? → {n}", "q.top": "Which of its stars shines brightest in your photo? →",
      "q.twin": "Why does it shine so much from so far away? → compare it with a neighbour of its own colour",
      "q.depthFar": "How much farther is {n}? →", "q.depthFront": "What lies in front of it? → {n}", "q.near": "What is the nearest thing in this photo? →", "q.deep": "And the farthest star Gaia measures well in this photo? →",
      "a.cluster": "It comes from here: one of the {k} stars of {n} found in your photo, moving together at the same distance (Gaia).",
      "a.top": "The brightest of the {k} stars of {n} found in your photo (G {g}).",
      "a.twin": "Same temperature as the star you came from (≈ {t1} K), yet about {x} times less light: so about {r} times smaller. That one is a giant; this one, a dwarf.",
      "a.twin2": "The comparison: ≈ {t1} K here and ≈ {t2} K there; the light is compared from the brightness seen (G) and the distance of each, dust not removed.",
      "a.depthFar": "About {x} times farther than {w}: {dh} light-years against {d}.",
      "a.depthFront": "It lies about {x} light-years in front of {w} ({dh} against {d} light-years).",
      "a.near": "The nearest star measured in your photo: {d} light-years.",
      "a.deep": "The farthest star of your photo measured to better than 20 %: {dh} light-years, about {x} times farther than the star you came from ({d}).",
      "w.star": "the star you came from", "ly": "light-years"
   },
   es: {
      "hd": "AENIGMATA", "hdF": "MIRABILIA",
      "flip": "Gira la placa: al otro lado, los enigmas de esta foto (AENIGMATA). Cada uno es cierto y sale de las medidas de Gaia de tus estrellas; ve allí y su ficha enseña la prueba.",
      "flipB": "Gira la placa de vuelta a MIRABILIA.",
      "how": "Búscala tú (PROFUNDITAS y AETAS ayudan) o pulsa la flecha y la nave te lleva. Su ficha enseña la prueba.",
      "open": "Abierto: la prueba está en su ficha.",
      "near.t": "La intrusa", "near.s": "{n}× más cerca que el resto", "near.q": "Una estrella de esta foto está unas {n} veces más cerca que la estrella típica de su alrededor. ¿Cuál?", "near.o": "{d} años luz",
      "near.p": "AENIGMA · la intrusa: a {d} años luz, unas {n} veces más cerca que la estrella mediana de tu foto.",
      "near.p2": "La intrusa: distancia {d} ± {e} años luz{px}. La mediana de las {N} estrellas medidas dentro de tu foto es {med} años luz.",
      "near.px": "; paralaje de Gaia {p} ± {pe} mas",
      "pair.t": "La pareja viajera", "pair.s": "dos estrellas, un mismo viaje", "pair.q": "Dos estrellas de esta foto viajan juntas por la Galaxia: la misma distancia y el mismo movimiento. ¿Cuáles?", "pair.o": "a {s} ua una de otra",
      "pair.p": "AENIGMA · la pareja viajera: su compañera está a {th}″ en tu foto, {s} veces la distancia de la Tierra al Sol. La misma distancia y el mismo movimiento.",
      "pair.p2": "La pareja viajera: paralaje de Gaia {p1} ± {e1} y {p2} ± {e2} mas; movimiento en el cielo {m1} y {m2} mas al año (difieren en {dm} ± {sm}; una pareja ligada así de separada puede diferir en {orb}). Probabilidad de que dos estrellas sin relación de esta foto coincidan así: más o menos 1 entre {odds} (medido con las {nC} estrellas de tu foto a menos de 3 300 años luz; criterio de El-Badry, Rix y Heintz 2021).",
      "fast.t": "La fugitiva", "fast.s": "{n}× más rápida que sus vecinas", "fast.q": "Una estrella de esta foto cruza el cielo unas {n} veces más deprisa que las estrellas de su misma distancia. ¿Cuál?", "fast.o": "{v} km/s",
      "fast.p": "AENIGMA · la fugitiva: {v} km/s de lado respecto a las estrellas de su distancia, unas {n} veces lo que difieren entre ellas.",
      "fast.p2": "La fugitiva: velocidad de lado {v} ± {ev} km/s respecto a la mediana de las {K} estrellas medidas más próximas a su distancia en tu foto, que entre sí difieren típicamente {s} km/s. Gaia no dice aquí de dónde viene, solo que no viaja con las demás. En 100 000 años se habrá movido {a}′ en el cielo (tu foto mide {w}′ de ancho): AETAS lo enseña.",
      "quasar.t": "La impostora", "quasar.s": "una luz que no es una estrella", "quasar.q": "Uno de los puntos de luz de esta foto no es una estrella. ¿Cuál?", "quasar.o": "z = {z}",
      "quasar.p": "AENIGMA · la impostora: no es una estrella sino el núcleo ardiente de una galaxia lejanísima (corrimiento al rojo z = {z}).",
      "quasar.p2": "La impostora: corrimiento al rojo z = {z}{lb}. Fuente: {src}.", "quasar.lb": "; su luz salió hace {t}",
      "far.t": "La forastera", "far.s": "no es de nuestra Galaxia", "far.q": "Algo de esta foto no pertenece a nuestra Galaxia. ¿Qué?", "far.o": "{d} años luz",
      "far.p": "AENIGMA · la forastera: otra galaxia, unas {n} veces más lejos que la estrella medida más lejana de tu foto.",
      "far.p2": "La forastera: distancia de catálogo {d} años luz ({src}); la estrella medida más lejana dentro de tu foto está a {mx} años luz.",
      "q.pair": "¿Viaja sola? →", "q.cluster": "¿De dónde viene? → {n}", "q.top": "¿Cuál de sus estrellas brilla más en tu foto? →",
      "q.twin": "¿Por qué brilla tanto desde tan lejos? → compárala con una vecina de su mismo color",
      "q.depthFar": "¿Cuánto más lejos está {n}? →", "q.depthFront": "¿Qué tiene delante? → {n}", "q.near": "¿Qué es lo más cercano de esta foto? →", "q.deep": "¿Y la estrella más lejana que Gaia mide bien en esta foto? →",
      "a.cluster": "Viene de aquí: es una de las {k} estrellas de {n} encontradas en tu foto, que se mueven juntas y a la misma distancia (Gaia).",
      "a.top": "La más brillante de las {k} estrellas de {n} encontradas en tu foto (G {g}).",
      "a.twin": "La misma temperatura que la estrella de la que vienes (≈ {t1} K), pero unas {x} veces menos luz: así que unas {r} veces más pequeña. Aquella es una gigante; esta, una enana.",
      "a.twin2": "La comparación: ≈ {t1} K aquí y ≈ {t2} K allí; la luz se compara con el brillo visto (G) y la distancia de cada una, sin quitar el polvo.",
      "a.depthFar": "Unas {x} veces más lejos que {w}: {dh} años luz frente a {d}.",
      "a.depthFront": "Queda unos {x} años luz por delante de {w} ({dh} frente a {d} años luz).",
      "a.near": "La estrella medida más cercana de tu foto: {d} años luz.",
      "a.deep": "La estrella más lejana de tu foto medida con menos de un 20 % de error: {dh} años luz, unas {x} veces más lejos que la estrella de la que vienes ({d}).",
      "w.star": "la estrella de la que vienes", "ly": "años luz"
   }
};
function fvE1cT(key, p, lang) { var L = (lang === "es") ? "es" : "en", s = FV_E1C_TX[L][key]; if (s === undefined) s = FV_E1C_TX.en[key]; return fvE1cFill(s === undefined ? key : s, p); }
// el texto de un misterio. part = "t" | "s" | "q" | "p" | "o"
function fvE1cText(my, part, lang) {
   var L = (lang === "es") ? "es" : "en", d = my.d || {}, p = {}, S = function(x, n) { return fvE1cSig(x, n, L); };
   if (my.k === "near") { p = { n: S(d.n, 2), d: S(d.dLy, 3), e: S(d.eLy, 1), N: fvE1cNum(d.N, 0, L), med: S(d.medLy, 2), px: (d.plx !== null && d.eplx !== null) ? fvE1cT("near.px", { p: fvE1cNum(d.plx, 2, L), pe: fvE1cNum(d.eplx, 2, L) }, L) : "" }; }
   else if (my.k === "pair") { p = { th: S(d.th, 2), s: S(d.sAu, 2), p1: fvE1cNum(d.p1, 2, L), e1: fvE1cNum(d.e1, 2, L), p2: fvE1cNum(d.p2, 2, L), e2: fvE1cNum(d.e2, 2, L), m1: fvE1cNum(d.m1, 1, L), m2: fvE1cNum(d.m2, 1, L), dm: fvE1cNum(d.dm, 2, L), sm: fvE1cNum(d.sm, 2, L), orb: fvE1cNum(d.orb, 2, L), nC: d.nC, odds: S(Math.max(100, d.odds), 1) }; }
   else if (my.k === "fast" && d.run === true && typeof fvRunText === "function") return fvRunText(d, part === "t" ? "name" : part, L);      // (F2) la fugitiva del criterio de la literatura (fv_runaway.js)
   else if (my.k === "fast") { p = { n: S(d.n, 2), v: S(d.v, 2), ev: S(Math.max(d.ev, 1), 1), K: d.K, s: S(d.s, 2), a: S(d.arcmin, 2), w: (d.wArcmin > 0) ? S(d.wArcmin, 2) : "?" }; }
   else if (my.k === "quasar") { p = { z: fvE1cNum(d.z, 3, L), src: d.src || "SIMBAD", lb: (d.lookbackYr > 0 && typeof fvsFmtDuration === "function") ? fvE1cT("quasar.lb", { t: fvsFmtDuration(d.lookbackYr, L) }, L) : "" }; }
   else if (my.k === "far") { p = { d: S(d.dLy, 2), n: S(d.n, 2), mx: S(d.maxLy, 2), src: d.src || "—" }; }
   return fvE1cT(my.k + "." + part, p, L);
}

// ---------------------------------------------------------------------------
// LA CADENA
// ---------------------------------------------------------------------------
// el protagonista de la foto: el objeto «hero», si no la fila principal, si no la nebulosa. -> { sel, name(L), dLy, eLy, known } | null
function fvE1cHero(scene, lang) {
   var O = scene.objects || [], i, h = -1, mn = -1, Lk = (lang === "es") ? "es" : "en", N = scene.nebula;
   for (i = 0; i < O.length; ++i) { if (O[i] && O[i].hero === true && h < 0) h = i; if (O[i] && O[i].main === true && mn < 0) mn = i; }
   if (h >= 0 && !O[h].main) { var o = O[h]; return { sel: { kind: "object", i: h }, name: (o.names && o.names[Lk]) || o.name || o.id, dLy: o.distLy, eLy: o.distErrLy > 0 ? o.distErrLy : 0, known: !!(o.distLy > 0 && o.distSrc && o.distSrc !== "assumed") }; }
   if (!N || !(N.distLy > 0)) return null;
   var nm = (N.names && N.names[Lk]) || N.name || "", e = (N.distHiLy > 0 && N.distLoLy > 0) ? 0.5 * (N.distHiLy - N.distLoLy) : 0;
   return { sel: (mn >= 0) ? { kind: "object", i: mn } : { kind: "nebula" }, name: nm, dLy: N.distLy, eLy: e, known: N.measured === true };
}
// los cumulos de la escena con sus estrellas: objeto de tipo cumulo -> { c (indice meta.cluster), n (miembros dentro de la foto), top (el mas brillante) }
function fvE1cClusters(scene) {
   var st = fvE1cState(scene); if (st.cl) return st.cl;
   var S = scene.stars, O = scene.objects || [], by = {}, out = { obj: {}, of: {} }, i, c;
   for (i = 0; S && i < S.n; ++i) { var m = S.meta[i]; if (!fvE1cInCluster(m) || !S.inFrame[i]) continue; c = m.cluster; if (!by[c]) by[c] = { n: 0, top: -1, list: [] }; ++by[c].n; by[c].list.push(i); if (by[c].top < 0 || S.g[i] < S.g[by[c].top]) by[c].top = i; }
   for (i = 0; i < O.length; ++i) {
      // un objeto cumulo, o la fila principal cuando el objeto principal de la foto ES un cumulo (M 45: tipo «nebula» con etiqueta de cumulo, fvNebMainKind)
      var o = O[i], mainCl = !!(o && o.main === true && o.typeLabel && /cluster/i.test(String(o.typeLabel.en || "")));
      if (!o || (o.type !== "cluster" && !mainCl) || !o.pos) continue;
      var pl = Math.sqrt(o.pos[0] * o.pos[0] + o.pos[1] * o.pos[1] + o.pos[2] * o.pos[2]); if (!(pl > 0)) continue;
      var szA = o.sizeCatArcmin > 0 ? o.sizeCatArcmin : (o.sizeArcmin > 0 ? o.sizeArcmin : ((mainCl && scene.nebula && scene.nebula.sizeArcmin > 0) ? scene.nebula.sizeArcmin : 20));
      var rad = Math.max(3, 0.5 * szA) * Math.PI / 10800, best = -1, bestN = 0;
      for (c in by) {
         if (!Object.prototype.hasOwnProperty.call(by, c)) continue;
         var inN = 0, Lc = by[c].list;
         for (var q = 0; q < Lc.length; ++q) { var s = Lc[q], sl = Math.sqrt(S.x[s] * S.x[s] + S.y[s] * S.y[s] + S.z[s] * S.z[s]); if (!(sl > 0)) continue; var cosA = (S.x[s] * o.pos[0] + S.y[s] * o.pos[1] + S.z[s] * o.pos[2]) / (sl * pl); if (cosA >= Math.cos(rad)) ++inN; }
         if (inN > bestN) { bestN = inN; best = c; }
      }
      // el cumulo del objeto: el que tiene dentro de su radio al menos 5 miembros y la mayoria de los suyos
      if (best !== -1 && bestN >= 5 && bestN >= 0.5 * by[best].n) { out.obj[i] = { c: Number(best), n: by[best].n, top: by[best].top }; out.of[best] = i; }
   }
   st.cl = out; return out;
}
function fvE1cObjName(scene, i, lang) { var o = scene.objects[i], Lk = (lang === "es") ? "es" : "en"; return (o.names && o.names[Lk]) || o.name || o.id || "?"; }
// la estrella medida mas cercana de la foto (la de la poblacion); -1 si no hay
function fvE1cNearest(scene) {
   var st = fvE1cState(scene); if (st.near !== undefined) return st.near;
   var S = scene.stars, pop = fvE1cPop(scene), nb = -1;
   for (var i = 0; i < pop.length; ++i) if (nb < 0 || S.dEarth[pop[i]] < S.dEarth[nb]) nb = pop[i];
   st.near = nb; return nb;
}
// la estrella mas lejana de la poblacion con la distancia medida a mejor del 20 %; -1 si no hay
function fvE1cFarthest(scene) {
   var st = fvE1cState(scene); if (st.far !== undefined) return st.far;
   var S = scene.stars, pop = fvE1cPop(scene), fb = -1;
   for (var i = 0; i < pop.length; ++i) if (fvE1cDistErr(S, pop[i]) <= 0.2 && (fb < 0 || S.dEarth[pop[i]] > S.dEarth[fb])) fb = pop[i];
   st.far = fb; return fb;
}
// magnitud absoluta G sin quitar el polvo
function fvE1cMG(S, i) { var dpc = S.dEarth[i] / fvE1cLyPerPc(); return S.g[i] + 5 - 5 * Math.log(dpc) / Math.LN10; }
// la enana de la misma temperatura que la gigante i (la mas brillante en la foto de las que cumplen); -1 si no hay
function fvE1cTwin(scene, i) {
   var S = scene.stars, m = S.meta[i] || {}, T = m.teff;
   if (S.q[i] !== 0 || !(T >= FV_E1C.TWIN_T[0] && T <= FV_E1C.TWIN_T[1]) || !(fvE1cDistErr(S, i) <= FV_E1C.TWIN_ERR)) return -1;
   var M0 = fvE1cMG(S, i); if (!(M0 <= FV_E1C.TWIN_MG)) return -1;
   var pop = fvE1cPop(scene), best = -1;
   for (var k = 0; k < pop.length; ++k) {
      var j = pop[k], mj = S.meta[j]; if (j === i || !(mj.teff > 0) || Math.abs(mj.teff - T) / T > FV_E1C.TWIN_DT || !(fvE1cDistErr(S, j) <= FV_E1C.TWIN_ERR)) continue;
      if (fvE1cMG(S, j) - M0 < FV_E1C.TWIN_DMAG) continue;
      if (best < 0 || S.g[j] < S.g[best]) best = j;
   }
   return best;
}
// el intervalo de distancia (años luz) de una seleccion: [lo, hi, d] o null
function fvE1cSpan(scene, c) {
   var S = scene.stars, LY = fvE1cLyPerPc();
   if (c.kind === "star") { if (S.q[c.i] !== 0) return null; var m = S.meta[c.i] || {}, d = S.dEarth[c.i]; if (m.lo > 0 && m.hi > 0) return [m.lo * LY, m.hi * LY, d]; var e = fvE1cDistErr(S, c.i); return fvE1cFin(e) ? [d * (1 - e), d * (1 + e), d] : null; }
   if (c.kind === "object") { var o = scene.objects[c.i]; if (!o || !(o.distLy > 0) || o.main || !o.distSrc || o.distSrc === "assumed") return null; var eo = o.distErrLy > 0 ? o.distErrLy : 0; return [o.distLy - eo, o.distLy + eo, o.distLy]; }
   return null;
}
// EL ESLABON de la ficha de `sel`: { rule, to (seleccion), q (texto), key, data } | null
function fvE1cLink(scene, sel, lang) {
   if (!fvE1cOn() || !FV_E1C.CHAIN || !scene || !scene.stars) return null;
   var c = fvE1cCanon(scene, sel); if (!c) return null;
   var st = fvE1cState(scene), from = fvE1cKey(scene, c), S = scene.stars, O = scene.objects || [], H = fvE1cHero(scene, lang), CL = fvE1cClusters(scene), out = null;
   function offer(rule, to, q, data) {
      if (out || !to) return;
      var tk = fvE1cKey(scene, to), key = rule + ":" + from + ">" + tk;
      // gastado, o de vuelta al sitio del que se viene: no. La excepcion es el eslabon que CIERRA la cadena en el protagonista («¿cuanto mas lejos esta?»), que si puede volver a el
      if (!tk || tk === from || (rule.indexOf("depth") !== 0 && tk === st.prev) || st.used[key]) return;
      out = { rule: rule, to: fvE1cCanon(scene, to), q: q, key: key, from: from, data: data || {} };
   }
   var heroKey = H ? fvE1cKey(scene, H.sel) : "", isHero = !!(H && heroKey === from);
   if (c.kind === "star") {
      var m = S.meta[c.i] || {}, my = fvE1cOf(scene, c);
      // 1. la pareja -> su compañera
      if (my && my.k === "pair") offer("pair", { kind: "star", i: (my.sel.i === c.i) ? my.also : my.sel.i }, fvE1cT("q.pair", null, lang));
      // 2. miembro de un cumulo de la escena -> el cumulo
      if (fvE1cInCluster(m) && CL.of[m.cluster] !== undefined) { var oc = CL.of[m.cluster]; offer("cluster", { kind: "object", i: oc }, fvE1cT("q.cluster", { n: fvE1cObjName(scene, oc, lang) }, lang), { k: CL.obj[oc].n, obj: oc }); }
      // 3. gigante lejana -> una enana de su temperatura
      var tw = fvE1cTwin(scene, c.i);
      if (tw >= 0) { var dM = fvE1cMG(S, tw) - fvE1cMG(S, c.i), x = Math.pow(10, 0.4 * dM); offer("twin", { kind: "star", i: tw }, fvE1cT("q.twin", null, lang), { t1: S.meta[tw].teff, t2: m.teff, x: x, r: Math.sqrt(x), dM: dM }); }
   } else if (c.kind === "object" && CL.obj[c.i] !== undefined) {
      // 4. un cumulo -> su miembro mas brillante en la foto
      var ci = CL.obj[c.i]; if (ci.top >= 0) offer("top", { kind: "star", i: ci.top }, fvE1cT("q.top", null, lang), { k: ci.n, obj: c.i, g: S.g[ci.top] });
   }
   // 5. -> el protagonista: cuanto mas lejos esta, o que tiene delante (las dos distancias conocidas e intervalos que no se tocan)
   // Una estrella cualquiera del campo NO lleva esta pregunta (seria la misma en cientos de fichas: E1-03, «preguntas repetidas»): solo las que tienen historia
   // —sujeto de un misterio, fila de MIRABILIA, o una estrella a la que se ha llegado por un eslabon—. Los objetos, siempre.
   var story = c.kind !== "star" || !!fvE1cOf(scene, c) || !!(st.via && st.via.to === from);
   if (!story) { for (var io = 0; io < O.length && !story; ++io) if (O[io] && O[io].type === "star" && O[io].star === c.i) story = true; }
   if (!out && H && H.known && !isHero && story) {
      var sp = fvE1cSpan(scene, c);
      if (sp) {
         var hLo = H.dLy - H.eLy, hHi = H.dLy + H.eLy, d0 = sp[2];
         if (H.dLy / d0 >= FV_E1C.DEPTH_RATIO && hLo > sp[1]) offer("depthFar", H.sel, fvE1cT("q.depthFar", { n: H.name }, lang), { d: d0, dh: H.dLy, x: H.dLy / d0, w: c.kind === "star" ? "" : fvE1cObjName(scene, c.i, lang) });
         else if (d0 / H.dLy >= FV_E1C.DEPTH_RATIO && sp[0] > hHi) offer("depthFront", H.sel, fvE1cT("q.depthFront", { n: H.name }, lang), { d: d0, dh: H.dLy, x: d0 - H.dLy, w: c.kind === "star" ? "" : fvE1cObjName(scene, c.i, lang) });
      }
   }
   // 5b. una estrella con historia y sin protagonista al que preguntar (su distancia es SUPUESTA, o ya se pregunto): -> la estrella mas lejana que Gaia mide bien en la foto
   if (!out && c.kind === "star" && story) {
      var fa = fvE1cFarthest(scene), sa = fvE1cSpan(scene, c), sb = (fa >= 0 && fa !== c.i) ? fvE1cSpan(scene, { kind: "star", i: fa }) : null;
      if (sa && sb && sb[2] / sa[2] >= FV_E1C.DEPTH_RATIO && sb[0] > sa[1]) offer("deep", { kind: "star", i: fa }, fvE1cT("q.deep", null, lang), { d: sa[2], dh: sb[2], x: sb[2] / sa[2] });
   }
   // 6. un objeto (o el protagonista) -> la estrella medida mas cercana de la foto
   if (!out && c.kind !== "star") {
      var nb = fvE1cNearest(scene);
      if (nb >= 0 && fvE1cDistErr(S, nb) <= 0.2) offer("near", { kind: "star", i: nb }, fvE1cT("q.near", null, lang), { d: S.dEarth[nb], dh: (H && H.known) ? H.dLy : 0, hero: (H && H.known) ? H.name : "" });
   }
   return out;
}
// la RESPUESTA que trae quien llega por un eslabon (la primera frase de la ficha nueva); null si no se llego por uno, o si la prueba de un misterio ya lo dice
function fvE1cAnswer(scene, sel, lang) {
   var st = fvE1cState(scene), v = st.via, key = fvE1cKey(scene, sel);
   if (!v || v.to !== key) return null;
   var d = v.data || {}, L = (lang === "es") ? "es" : "en", S = function(x, n) { return fvE1cSig(x, n, L); }, w = d.w ? d.w : fvE1cT("w.star", null, L);
   if (v.rule === "pair") return null;                                                           // la prueba de la pareja es la respuesta
   if (v.rule === "cluster") return fvE1cT("a.cluster", { k: d.k, n: fvE1cObjName(scene, d.obj, L) }, L);
   if (v.rule === "top") return fvE1cT("a.top", { k: d.k, n: fvE1cObjName(scene, d.obj, L), g: fvE1cNum(d.g, 1, L) }, L);
   if (v.rule === "twin") return fvE1cT("a.twin", { t1: S(d.t1, 2), t2: S(d.t2, 2), x: S(d.x, 2), r: S(d.r, 2) }, L);
   if (v.rule === "depthFar") return fvE1cT("a.depthFar", { x: S(d.x, 2), w: w, dh: S(d.dh, 3), d: S(d.d, 3) }, L);
   if (v.rule === "depthFront") return fvE1cT("a.depthFront", { x: S(d.x, 2), w: w, dh: S(d.dh, 3), d: S(d.d, 3) }, L);
   if (v.rule === "deep") return fvE1cT("a.deep", { x: S(d.x, 2), dh: S(d.dh, 3), d: S(d.d, 3) }, L);
   if (v.rule === "near") { if (fvE1cOf(scene, sel)) return null; return fvE1cT("a.near", { d: S(d.d, 3) }, L); }      // sin adelantar cuanto mas lejos queda el protagonista: esa es la pregunta que abre esta ficha
   return null;
}
// SEGUIR un eslabon (clic en la pregunta): queda gastado y la ficha de llegada sabra de donde se viene
function fvE1cFollow(scene, link) {
   if (!link || !scene) return null;
   var st = fvE1cState(scene);
   st.used[link.key] = 1; st.prev = link.from; st.via = { to: fvE1cKey(scene, link.to), rule: link.rule, data: link.data, from: link.from }; ++st.ver;
   return link.to;
}
// LO QUE LA FICHA AÑADE para `sel` (se llama al ABRIRSE la ficha: abre el sobre): { proof, ans, link, my }
function fvE1cCard(scene, sel, lang) {
   var out = { proof: null, proof2: null, ans: null, ans2: null, link: null, my: null };      // proof / ans = la frase corta (resumen); proof2 / ans2 = los numeros (MAS)
   if (!fvE1cOn() || !scene || !scene.stars) return out;
   var st = fvE1cState(scene), key = fvE1cKey(scene, sel);
   if (!key) return out;
   // una ficha a la que NO se llego por el eslabon: la cadena se corta (ni respuesta ni «de donde se viene»)
   if (st.via && st.via.to !== key && st.via.from !== key) { st.via = null; st.prev = ""; ++st.ver; }
   var my = FV_E1C.AENIG ? fvE1cOf(scene, sel) : null;
   // (F2) la ficha de la fugitiva aunque su misterio no este en la lista (AENIG apagado, o ya otro enigma): la misma prueba, su «¿por que?»
   if (!my && key.indexOf("star:") === 0 && typeof fvRunOf === "function") { var rc = fvRunOf(scene, Number(key.substring(5))); if (rc) { out.proof = fvRunText(rc, "p", lang); out.proof2 = fvRunText(rc, "p2", lang); } }
   if (my) { out.my = my; out.proof = fvE1cText(my, "p", lang); out.proof2 = fvE1cText(my, "p2", lang); if (!st.open[my.k]) { st.open[my.k] = 1; ++st.ver; out.opened = true; st.resolved = true; } }      // resolved: lo recoge quien pinta para el sonido que informa (I5, fvE1aPost)
   if (FV_E1C.CHAIN) {
      out.ans = fvE1cAnswer(scene, sel, lang); out.link = fvE1cLink(scene, sel, lang);
      if (out.ans && st.via && st.via.rule === "twin") { var dT = st.via.data || {}; out.ans2 = fvE1cT("a.twin2", { t1: fvE1cSig(dT.t1, 2, lang), t2: fvE1cSig(dT.t2, 2, lang) }, lang); }
   }
   return out;
}
// las FILAS del reverso AENIGMATA (la misma forma que las de MIRABILIA: kind, i, name, sub, type, icon, tip)
function fvE1cItems(scene, lang) {
   var L = fvE1cList(scene), st = fvE1cState(scene), out = [];
   for (var i = 0; i < L.length; ++i) {
      var y = L[i], op = !!st.open[y.k];
      out.push({ kind: y.sel.kind, i: y.sel.i, aen: y.k, open: op, name: fvE1cText(y, "t", lang), sub: op ? fvE1cText(y, "o", lang) : fvE1cText(y, "s", lang), type: "aenigma", icon: op ? "sealOpen" : "seal",
                 tip: fvE1cText(y, "q", lang) + "\n" + fvE1cT(op ? "open" : "how", null, lang) });
   }
   return out;
}
// el registro (pruebas y barrido): una linea por misterio y por «no salio»
function fvE1cReport(scene) {
   var A = fvE1cGet(scene), out = ["aenigmata: " + A.list.length + " of a population of " + A.n + " measured stars in the photo (median " + (fvE1cFin(A.medLy) ? Math.round(A.medLy) : "?") + " ly)"], i;
   for (i = 0; i < A.list.length; ++i) { var y = A.list[i]; out.push("  [" + y.k + "] " + y.sel.kind + ":" + y.sel.i + (y.also !== undefined ? " + star:" + y.also : "") + " · " + fvE1cText(y, "p", "en") + " · data " + JSON.stringify(y.d)); }
   for (var w in A.why) if (Object.prototype.hasOwnProperty.call(A.why, w)) out.push("  (no " + w + ") " + A.why[w]);
   return out;
}
