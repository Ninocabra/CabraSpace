// ============================================================================
// FieldVoyager/src/engine/fv_milkyway.js — LA VIA LACTEA DE FONDO, SIMULADA y geometricamente en su sitio (F4b, 4-nov-2026). PURO.
// ----------------------------------------------------------------------------
// Fuera de casa el catalogo solo tiene estrellas en el cono de la foto y las brillantes cercanas al Sol: el cielo del destino salia
// casi negro (F2-D2). Aqui, el brillo del cielo de fondo en cada direccion VISTO DESDE LA POSICION DE LA CAMARA, integrando la columna
// de un modelo sencillo de la Galaxia (TODO SUPUESTO; la placa DATOS dice «fondo simulado»):
//   I(dir) = ∫ ρ(c + s·dir) · 10^(−0,4·A_V(s)) ds         (brillo superficial: emisividad ∝ densidad; sin 1/s², es por angulo solido)
//   ρ   disco fino + disco grueso exponenciales (los MISMOS parametros que las distancias supuestas: FV_GALMOD de fv_scene.js —
//       R0 8,2 kpc, z☉ 25 pc, h_R 2,6 kpc, h_z 300 pc; grueso 4 %, h_R 2,0, h_z 900 pc; de Bland-Hawthorn & Gerhard 2016,
//       arXiv:1602.07702v2: R0, h_R, h_z, el 4 % y los 900 pc comprobados el 9-nov-2026 (§3.2.4 y §5.1); z☉ y la h_R del grueso, NO VERIFICADO) + un BULBO exponencial esferico de escala 0,5 kpc y densidad central 100 × la local (ELECCION NUESTRA, orden de
//       magnitud: 1,5·10¹⁰ M☉ en 8π·ρ0·a³);
//   A_V el polvo del mismo modelo: 1 mag/kpc en el plano en una capa de 100 pc (FV_GALMOD.AV_KPC / HDUST): hace la franja oscura del
//       plano y tapa el centro galactico a b = 0 (asi es el cielo de verdad: las nubes de Sagitario asoman a pocos grados).
// La orientacion: la direccion al centro galactico (α 266,405°, δ −28,936°) y el polo norte galactico (α 192,859°, δ 27,128°), en ICRS
// (Hipparcos, ESA 1997 vol. 1 §1.5.3), pasadas al mundo de la escena por la solucion astrometrica de la foto (fvSkyRotation).
// Mapa en coordenadas galacticas (l, b) desde la camara: NL × NB celdas × NS pasos en log de s; se rehace al moverse > REMAP_LY.
// Brillo normalizado con el del cielo desde el Sol (p99,5 = 1): acercarse al centro lo hace mas brillante.
// ES5. Sin PixInsight.
// ============================================================================

var FV_MW = { NL: 120, NB: 60, NS: 36, SMIN: 0.005, SMAX: 25, BULGE_W: 100, BULGE_A: 0.5, REMAP_LY: 150,
              // color: disco blanco azulado, bulbo calido (estetico, tonos de una foto de la Via Lactea)
              COL_DISC: [205, 214, 240], COL_BULGE: [255, 214, 160],
              GC_RA: 266.405, GC_DEC: -28.936, NGP_RA: 192.859, NGP_DEC: 27.128 };
var FV_MW_BREAK = "";       // control en ROJO: "pole" = el polo galactico en una direccion equivocada (la franja sale girada)

// el marco galactico en el mundo de la escena: { ex (hacia el centro), ey (l = 90°), ez (polo norte) } desde la rotacion del cielo
function fvMwFrame(rot) {
   if (typeof rot !== "function") return null;
   var gc = fvNorm(rot(FV_MW.GC_RA, FV_MW.GC_DEC)), np = fvNorm(rot(FV_MW.NGP_RA, FV_MW.NGP_DEC));
   if (FV_MW_BREAK === "pole") { var t = gc; gc = np; np = t; }
   np = fvNorm(fvSub(np, fvMul(gc, fvDot(np, gc))));            // ortogonal exacto
   return { ex: gc, ey: fvCross(np, gc), ez: np };
}
// densidad (relativa a la local del disco fino) y fraccion del bulbo en el punto (x, y, z) galactocentrico (kpc)
function fvMwRho(x, y, z) {
   var M = FV_GALMOD, R = Math.sqrt(x * x + y * y), az = Math.abs(z), r = Math.sqrt(R * R + z * z);
   var disc = Math.exp(-(R - M.R0) / M.HR - az / M.HZ) + M.FTHICK * Math.exp(-(R - M.R0) / M.HRT - az / M.HZT);
   var bul = FV_MW.BULGE_W * Math.exp(-r / FV_MW.BULGE_A);
   return [disc, bul];
}
// EL MAPA desde la camara (posicion en el mundo, años luz) -> { I: Float32Array NL·NB, B: fraccion del bulbo, camLy, max }
function fvMwMap(frame, camLy) {
   var M = FV_GALMOD, NL = FV_MW.NL, NB = FV_MW.NB, NS = FV_MW.NS, k = 1 / (1000 * FV_LY_PER_PC);
   var c = [camLy[0] * k, camLy[1] * k, camLy[2] * k], cx = fvDot(c, frame.ex), cy = fvDot(c, frame.ey), cz = fvDot(c, frame.ez);
   var I = new Float32Array(NL * NB), Bf = new Float32Array(NL * NB), s = new Float64Array(NS), ds = new Float64Array(NS), q = Math.log(FV_MW.SMAX / FV_MW.SMIN) / (NS - 1), i, j, n;
   for (n = 0; n < NS; ++n) { s[n] = FV_MW.SMIN * Math.exp(q * n); }
   for (n = 0; n < NS; ++n) ds[n] = (n === 0) ? s[0] : s[n] - s[n - 1];
   var mx = 0, iHD = 1 / M.HDUST, iHR = 1 / M.HR, iHZ = 1 / M.HZ, iHRT = 1 / M.HRT, iHZT = 1 / M.HZT, BW = FV_MW.BULGE_W, iBA = 1 / FV_MW.BULGE_A;
   for (j = 0; j < NB; ++j) {
      var b = (-90 + 180 * (j + 0.5) / NB) * FV_DEG, cb = Math.cos(b), sb = Math.sin(b);
      for (i = 0; i < NL; ++i) {
         var l = (360 * i / NL) * FV_DEG, dx = cb * Math.cos(l), dy = cb * Math.sin(l), dz = sb, A = 0, tot = 0, bul = 0;
         for (n = 0; n < NS; ++n) {
            // (en linea, sin crear objetos: 300 000 muestras por mapa; fvMwRho es la misma cuenta, para leerla)
            var px = cx + s[n] * dx - M.R0, py = cy + s[n] * dy, pz = cz + s[n] * dz + M.ZSUN, az = pz < 0 ? -pz : pz;
            if (az > 6 && pz * dz > 0) break;                                  // ya fuera del disco y alejandose: no queda luz
            A += M.AV_KPC * ds[n] * Math.exp(-az * iHD);
            var R = Math.sqrt(px * px + py * py), T = Math.exp(-0.921034 * A) * ds[n];
            var disc = Math.exp(-(R - M.R0) * iHR - az * iHZ) + M.FTHICK * Math.exp(-(R - M.R0) * iHRT - az * iHZT), bu = BW * Math.exp(-Math.sqrt(R * R + pz * pz) * iBA);
            tot += (disc + bu) * T; bul += bu * T;
         }
         I[j * NL + i] = tot; Bf[j * NL + i] = tot > 0 ? bul / tot : 0;
         if (tot > mx) mx = tot;
      }
   }
   return { I: I, B: Bf, camLy: camLy.slice(), max: mx };
}
// el valor de referencia (p99,5 del mapa desde el Sol): la normalizacion fija de todos los mapas de la escena
function fvMwRef(map0) { var a = Array.prototype.slice.call(map0.I).sort(function(x, y) { return x - y; }); return a[Math.floor(0.995 * (a.length - 1))] || 1; }
// muestra bilineal del mapa en la direccion (unitaria, mundo) -> [I, fraccion del bulbo]
function fvMwSample(map, frame, d) {
   var gx = d[0] * frame.ex[0] + d[1] * frame.ex[1] + d[2] * frame.ex[2], gy = d[0] * frame.ey[0] + d[1] * frame.ey[1] + d[2] * frame.ey[2], gz = d[0] * frame.ez[0] + d[1] * frame.ez[1] + d[2] * frame.ez[2];
   var l = Math.atan2(gy, gx); if (l < 0) l += 2 * Math.PI;
   var b = Math.asin(Math.max(-1, Math.min(1, gz))), NL = FV_MW.NL, NB = FV_MW.NB;
   var u = l / (2 * Math.PI) * NL, v = (b / Math.PI + 0.5) * NB - 0.5, i0 = Math.floor(u), j0 = Math.floor(v), fu = u - i0, fv = v - j0;
   if (j0 < 0) { j0 = 0; fv = 0; } if (j0 >= NB - 1) { j0 = NB - 2; fv = 1; }
   var i1 = (i0 + 1) % NL; i0 = ((i0 % NL) + NL) % NL;
   var a = map.I, B = map.B, r0 = j0 * NL, r1 = r0 + NL;
   var I = (a[r0 + i0] * (1 - fu) + a[r0 + i1] * fu) * (1 - fv) + (a[r1 + i0] * (1 - fu) + a[r1 + i1] * fu) * fv;
   var bb = (B[r0 + i0] * (1 - fu) + B[r0 + i1] * fu) * (1 - fv) + (B[r1 + i0] * (1 - fu) + B[r1 + i1] * fu) * fv;
   return [I, bb];
}
// EL GRANO de estrellas no resueltas: N direcciones repartidas como el brillo del mapa desde el Sol (semilla fija) -> { d: Float32Array 3N, w }
function fvMwGrain(map0, frame, N, seed) {
   var R = fvRng(seed || 9091), NL = FV_MW.NL, NB = FV_MW.NB, a = map0.I, cdf = new Float64Array(NL * NB), s = 0, i;
   for (i = 0; i < a.length; ++i) { var jb = Math.floor(i / NL), cosb = Math.cos((-90 + 180 * (jb + 0.5) / NB) * FV_DEG); s += Math.pow(a[i], 1.3) * cosb; cdf[i] = s; }
   var d = new Float32Array(3 * N), w = new Float32Array(N);
   for (var n = 0; n < N; ++n) {
      var t = R() * s, lo = 0, hi = cdf.length - 1;
      while (lo < hi) { var m = (lo + hi) >> 1; if (cdf[m] < t) lo = m + 1; else hi = m; }
      var ii = lo % NL, jj = Math.floor(lo / NL), l = (ii + R()) / NL * 2 * Math.PI, b = (-90 + 180 * (jj + R()) / NB) * FV_DEG;
      var gx = Math.cos(b) * Math.cos(l), gy = Math.cos(b) * Math.sin(l), gz = Math.sin(b);
      for (var q = 0; q < 3; ++q) d[3 * n + q] = gx * frame.ex[q] + gy * frame.ey[q] + gz * frame.ez[q];
      w[n] = Math.pow(R(), 2.2);            // muchas muy debiles, pocas algo mas brillantes
   }
   return { d: d, w: w, n: N };
}

// ============================================================================
// (encargo D2, 9-nov-2026) LA VIA LACTEA DE FONDO CON MAS PRESENCIA Y DETALLE. Bandera FV_MW2.ON (false = lo de arriba, bit a bit).
// Nino: «Dibuja la Via Lactea con mayor prominencia y detalle en la navegacion explorando la imagen». Sigue siendo el mismo mapa (l, b)
// integrado DESDE LA POSICION DE LA NAVE, con lo que le faltaba:
//   · los BRAZOS de la galaxia de fuera (fv_galaxy3d.js, Reid et al. 2019): la emisividad del disco × (1 + ARM_GAIN·brazos) y el polvo
//     en el borde interior de cada brazo: las tangentes de los brazos salen como nubes estelares (Cisne, Escudo, Carina…);
//   · la BARRA en vez de un bulbo esferico: el bulbo hacia Sagitario, mas brillante del lado de l > 0 (Bland-Hawthorn & Gerhard 2016);
//   · POLVO con estructura: ruido 3D (escala NOISE_KPC) solo dentro de la capa de polvo, y NUBES OSCURAS cercanas con su posicion real
//     (l, b, distancia) — la Gran Grieta (Aquila), la del Cisne, Ofiuco, la Pipa, el Saco de Carbon, Tauro, Orion… — como gausianas 3D
//     integradas EXACTAS a lo largo del rayo (erf: no se escapan entre dos pasos). DISTANCIAS comprobadas el 9-nov-2026 de las que mas
//     pesan: la Grieta de Aquila 0,24–0,30 kpc (Zucker et al. 2020, A&A 633, A51, arXiv:2001.00591: lineas de vision del norte de la
//     Grieta a 163–280 pc), la Grieta del Cisne 0,75–0,85 kpc (CO de MWISP + Gaia DR3, arXiv:2403.00061: ~0,7–1 kpc) y Ofiuco 0,14 kpc
//     (Ortiz-Leon et al. 2018, arXiv:1812.02360: 138–144 pc). Las DEMAS distancias, y las posiciones (l, b) de todas, siguen de memoria:
//     NO VERIFICADO; tamaños y extinciones elegidos para que se vean como en las fotos de gran campo;
//   · rejilla mas fina (NL × NB con las filas apretadas junto al plano, b = 90°·|v|^BPOW) y mas pasos;
//   · el mapa nuevo se calcula POR TROZOS (JOB_MS por fotograma) para no dar tirones; el viejo se ve mientras.
// En el pintor (src/ui/fv_galaxy.js, FVPainter.paintMilkyWay2): un SUELO que se resta (el negro sigue negro), mas contraste y mas grano.
// ============================================================================
var FV_MW2 = { ON: true, NL: 320, NB: 100, BPOW: 1.7, NS: 40, SMIN: 0.004, SMAX: 25,
               ARM_GAIN: 1.7, DUST_BASE: 0.45, DUST_ARM: 1.3, NOISE_KPC: 0.06, NOISE_LAYER: 0.45,
               // la barra/bulbo: exponencial elipsoidal de escala BULGE_A·BAR_S = 0,70 : 0,44 : 0,18 kpc a 27° (Bland-Hawthorn & Gerhard 2016,
               // arXiv:1602.07702v2, §4.2.1, VERIFICADO el 9-nov-2026; antes 1,4 : 0,6 : 0,45, de memoria)
               BAR_ANG: 27, BAR_S: [1.4, 0.88, 0.36], CLOUDS_ON: true, CLOUD_K: 0.55,
               // [l (°), b (°), distancia (kpc), sigma a lo largo de l, en la visual y en altura (kpc), A_V de la columna desde el Sol por el centro (mag)]
               // alargadas a lo largo del plano: las nubes oscuras de verdad son filamentos, no bolas
               CLOUDS: [ [16, 3.0, 0.24, 0.035, 0.05, 0.010, 2.2], [24, 3.5, 0.25, 0.035, 0.05, 0.012, 2.6], [32, 3.0, 0.26, 0.035, 0.05, 0.011, 2.4],   // Aquila: la Gran Grieta
                         [40, 2.0, 0.28, 0.035, 0.05, 0.010, 2.0], [48, 1.5, 0.30, 0.030, 0.05, 0.010, 1.6],
                         [62, 1.5, 0.75, 0.10, 0.10, 0.025, 2.0], [72, 2.0, 0.80, 0.10, 0.10, 0.030, 2.4], [82, 1.0, 0.85, 0.10, 0.10, 0.025, 2.0],   // la grieta del Cisne
                         [354, 16, 0.14, 0.010, 0.012, 0.006, 3.0], [0, 5, 0.13, 0.012, 0.010, 0.003, 2.5], [340, 14, 0.16, 0.012, 0.012, 0.006, 1.8],   // Ofiuco, la Pipa, Lupus
                         [301, -1, 0.18, 0.009, 0.010, 0.008, 2.5], [300, -16, 0.18, 0.010, 0.010, 0.006, 1.6],                                          // Saco de Carbon, Camaleon
                         [172, -15, 0.14, 0.020, 0.015, 0.008, 2.2], [160, -20, 0.30, 0.025, 0.020, 0.010, 1.6], [210, -19, 0.40, 0.035, 0.030, 0.015, 1.6], [110, 15, 0.30, 0.040, 0.030, 0.020, 1.2] ],   // Tauro, Perseo, Orion, Cefeo
               PEAK: 0.60, GAMMA: 0.55, FLOOR: 0.045, KNEE: 0.03, GW: 240, GH: 135, GRAIN: 9000,
               COL_DISC: [196, 208, 238], COL_BULGE: [255, 204, 146], COL_YOUNG: [172, 196, 255],
               JOB_MS: 6, SYNC: false, FORCE_W: null,
               BASE: true,      // (ronda 3) la Via Lactea de hoy debajo (maximo por canal): ni mas oscuro fuera de la banda ni borde duro; false = ronda 2
               // (ronda 3) bordes SUAVES: el pintor muestrea una copia suavizada del mapa (gausiana de SOFT_B grados en latitud, SOFT_L columnas en
               // longitud). Las filas junto al plano estan a 0,2–0,3° y las columnas a 1,1°: interpoladas en lineal, las grietas daban bordes rectos
               // y bloques. 0 = sin suavizar (la ronda 2)
               SOFT_B: 0.6, SOFT_L: 1.0 };
// erf (Abramowitz & Stegun 7.1.26, error < 1,5·10⁻⁷)
function fvMw2Erf(x) { var s = x < 0 ? -1 : 1; x = Math.abs(x); var t = 1 / (1 + 0.3275911 * x); return s * (1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x)); }
// latitud de la fila j (filas apretadas junto al plano) y su inversa
function fvMw2B(j) { var v = -1 + 2 * (j + 0.5) / FV_MW2.NB; return (v < 0 ? -1 : 1) * 90 * Math.pow(Math.abs(v), FV_MW2.BPOW); }
function fvMw2V(bDeg) { var v = (bDeg < 0 ? -1 : 1) * Math.pow(Math.min(1, Math.abs(bDeg) / 90), 1 / FV_MW2.BPOW); return (v + 1) * FV_MW2.NB / 2 - 0.5; }
// EL TRABAJO del mapa desde la camara (por filas): begin -> step(job, ms) hasta true -> job.map
function fvMw2MapBegin(frame, camLy) {
   var M2 = FV_MW2, NL = M2.NL, NB = M2.NB, NS = M2.NS, k = 1 / (1000 * FV_LY_PER_PC), q = Math.log(M2.SMAX / M2.SMIN) / (NS - 1), n;
   var c = [camLy[0] * k, camLy[1] * k, camLy[2] * k], s = new Float64Array(NS), ds = new Float64Array(NS);
   for (n = 0; n < NS; ++n) s[n] = M2.SMIN * Math.exp(q * n);
   for (n = 0; n < NS; ++n) ds[n] = (n === 0) ? s[0] : s[n] - s[n - 1];
   var cl = [];
   if (M2.CLOUDS_ON) for (n = 0; n < M2.CLOUDS.length; ++n) {
      var C = M2.CLOUDS[n], l = C[0] * FV_DEG, b = C[1] * FV_DEG, er = [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)];
      var et = fvNorm(fvCross([0, 0, 1], er)), ez = fvCross(er, et);                                       // a lo largo de l y «hacia arriba»
      cl.push({ p: [C[2] * er[0], C[2] * er[1], C[2] * er[2]], ax: [[et[0] / C[3], et[1] / C[3], et[2] / C[3]], [er[0] / C[4], er[1] / C[4], er[2] / C[4]], [ez[0] / C[5], ez[1] / C[5], ez[2] / C[5]]],
                rho: M2.CLOUD_K * C[6] / (C[4] * Math.sqrt(2 * Math.PI)) });
   }
   var tex = (typeof fvGal3Tex === "function") ? fvGal3Tex() : null;
   return { frame: frame, c: c, cx: fvDot(c, frame.ex), cy: fvDot(c, frame.ey), cz: fvDot(c, frame.ez), s: s, ds: ds, cl: cl, tex: tex, j: 0,
            map: { I: new Float32Array(NL * NB), B: new Float32Array(NL * NB), Y: new Float32Array(NL * NB), camLy: camLy.slice(), max: 0, v2: true } };
}
function fvMw2MapStep(job, ms) {
   var M = FV_GALMOD, M2 = FV_MW2, NL = M2.NL, NB = M2.NB, NS = M2.NS, t0 = Date.now(), s = job.s, ds = job.ds, cl = job.cl, T = job.tex;
   var cx = job.cx, cy = job.cy, cz = job.cz, I = job.map.I, Bf = job.map.B, Yf = job.map.Y;
   var iHD = 1 / M.HDUST, iHR = 1 / M.HR, iHZ = 1 / M.HZ, iHRT = 1 / M.HRT, iHZT = 1 / M.HZT, BW = FV_MW.BULGE_W, iBA = 1 / FV_MW.BULGE_A;
   var dR0 = M.R0 - (typeof FV_GAL3 !== "undefined" ? FV_GAL3.R0 : M.R0), ang = M2.BAR_ANG * FV_DEG, ux = -Math.cos(ang), uy = Math.sin(ang), vx = Math.sin(ang), vy = Math.cos(ang);
   var isx = 1 / M2.BAR_S[0], isy = 1 / M2.BAR_S[1], isz = 1 / M2.BAR_S[2], iNK = 1 / M2.NOISE_KPC, NLAY = M2.NOISE_LAYER, nCl = cl.length;
   var cA = new Float64Array(nCl), cS = new Float64Array(nCl), cR = new Float64Array(nCl), cE0 = new Float64Array(nCl), on = new Uint8Array(nCl);
   var TN = T ? T.N : 0, TH = T ? T.H : 0, iTpx = T ? 1 / T.px : 0, TA = T ? T.arm : null, TD = T ? T.armDust : null, LT = fvGal3Lat(), LN = 32, LM = 31;
   // ruido de valor 3D sobre una red fija de 32³ (periodica): sin funciones hash por muestra
   function lat(x, y, z) {
      var ix = Math.floor(x), iy = Math.floor(y), iz = Math.floor(z), fx = x - ix, fy = y - iy, fz = z - iz, x0 = ix & LM, y0 = iy & LM, z0 = iz & LM, x1 = (x0 + 1) & LM, y1 = (y0 + 1) & LM, z1 = (z0 + 1) & LM;
      var a = LT[(z0 * LN + y0) * LN + x0], b = LT[(z0 * LN + y0) * LN + x1], c = LT[(z0 * LN + y1) * LN + x0], d = LT[(z0 * LN + y1) * LN + x1];
      var e = LT[(z1 * LN + y0) * LN + x0], f = LT[(z1 * LN + y0) * LN + x1], g = LT[(z1 * LN + y1) * LN + x0], h = LT[(z1 * LN + y1) * LN + x1];
      var p0 = (a + (b - a) * fx) * (1 - fy) + (c + (d - c) * fx) * fy, p1 = (e + (f - e) * fx) * (1 - fy) + (g + (h - g) * fx) * fy;
      return p0 + (p1 - p0) * fz;
   }
   while (job.j < NB) {
      var j = job.j, b = fvMw2B(j) * FV_DEG, cb = Math.cos(b), sb = Math.sin(b);
      for (var i = 0; i < NL; ++i) {
         var l = (360 * i / NL) * FV_DEG, dx = cb * Math.cos(l), dy = cb * Math.sin(l), dz = sb, A = 0, tot = 0, bul = 0, yng = 0, n, h;
         // las nubes que roza este rayo: su extincion acumulada hasta s es cerrada (erf)
         // (gausiana anisotropa: en los ejes escalados de la nube el rayo sigue siendo una recta; la integral es cerrada con erf)
         for (h = 0; h < nCl; ++h) {
            var C = cl[h], rx = C.p[0] - cx, ry = C.p[1] - cy, rz = C.p[2] - cz, X3 = C.ax, P0 = rx * X3[0][0] + ry * X3[0][1] + rz * X3[0][2], P1 = rx * X3[1][0] + ry * X3[1][1] + rz * X3[1][2], P2 = rx * X3[2][0] + ry * X3[2][1] + rz * X3[2][2];
            var V0 = dx * X3[0][0] + dy * X3[0][1] + dz * X3[0][2], V1 = dx * X3[1][0] + dy * X3[1][1] + dz * X3[1][2], V2 = dx * X3[2][0] + dy * X3[2][1] + dz * X3[2][2];
            var vv = V0 * V0 + V1 * V1 + V2 * V2, pv = P0 * V0 + P1 * V1 + P2 * V2, t0c = pv / vv, p2 = P0 * P0 + P1 * P1 + P2 * P2 - pv * t0c, vl = Math.sqrt(vv);
            on[h] = (p2 < 9 && t0c * vl > -3) ? 1 : 0;
            if (on[h]) { cA[h] = C.rho * Math.exp(-0.5 * p2) * Math.sqrt(Math.PI / 2) / vl; cS[h] = t0c; cR[h] = vl / Math.SQRT2; cE0[h] = fvMw2Erf(-t0c * cR[h]); }
         }
         for (n = 0; n < NS; ++n) {
            var sn = s[n], px = cx + sn * dx - M.R0, py = cy + sn * dy, pz = cz + sn * dz + M.ZSUN, az = pz < 0 ? -pz : pz;
            if (az > 6 && pz * dz > 0) break;
            var XR = px + dR0, armY = 0, armD = 0;
            if (T) {
               // muestra bilineal en linea de los brazos (luz joven y polvo) del mapa de cara
               var tu = (XR + TH) * iTpx - 0.5, tv = (py + TH) * iTpx - 0.5, ti0 = Math.floor(tu), tj0 = Math.floor(tv);
               if (ti0 >= 0 && tj0 >= 0 && ti0 < TN - 1 && tj0 < TN - 1) {
                  var tfu = tu - ti0, tfv = tv - tj0, to = tj0 * TN + ti0, t00 = (1 - tfu) * (1 - tfv), t10 = tfu * (1 - tfv), t01 = (1 - tfu) * tfv, t11 = tfu * tfv;
                  armY = TA[to] * t00 + TA[to + 1] * t10 + TA[to + TN] * t01 + TA[to + TN + 1] * t11;
                  armD = TD[to] * t00 + TD[to + 1] * t10 + TD[to + TN] * t01 + TD[to + TN + 1] * t11;
               }
            }
            var dd = M.AV_KPC * Math.exp(-az * iHD) * (M2.DUST_BASE + M2.DUST_ARM * armD);
            if (az < NLAY) { var gx3 = (cx + sn * dx) * iNK, gy3 = (cy + sn * dy) * iNK, gz3 = (cz + sn * dz) * iNK, nz = 0.62 * lat(gx3, gy3, gz3) + 0.38 * lat(2.31 * gx3 + 5.7, 2.31 * gy3 + 1.3, 2.31 * gz3 + 9.1); dd *= 0.12 + 2.1 * nz * nz; }
            A += dd * ds[n];
            var Ac = A;
            for (h = 0; h < nCl; ++h) if (on[h]) Ac += cA[h] * (fvMw2Erf((sn - cS[h]) * cR[h]) - cE0[h]);
            var R = Math.sqrt(px * px + py * py), Tr = Math.exp(-0.921034 * Ac) * ds[n];
            var e1 = Math.exp(-(R - M.R0) * iHR - az * iHZ), disc = e1 * (1 + M2.ARM_GAIN * armY) + M.FTHICK * Math.exp(-(R - M.R0) * iHRT - az * iHZT);
            var bu0 = px * ux + py * uy, bv0 = px * vx + py * vy, rr = Math.sqrt(bu0 * bu0 * isx * isx + bv0 * bv0 * isy * isy + pz * pz * isz * isz), bu = rr < 12 * FV_MW.BULGE_A ? BW * Math.exp(-rr * iBA) : 0;
            tot += (disc + bu) * Tr; bul += bu * Tr; yng += e1 * M2.ARM_GAIN * armY * Tr;
         }
         var o = j * NL + i; I[o] = tot; Bf[o] = tot > 0 ? bul / tot : 0; Yf[o] = tot > 0 ? yng / tot : 0;
         if (tot > job.map.max) job.map.max = tot;
      }
      ++job.j;
      if (ms > 0 && Date.now() - t0 > ms) break;
   }
   return job.j >= NB;
}
function fvMw2Map(frame, camLy) { var job = fvMw2MapBegin(frame, camLy); fvMw2MapStep(job, 0); return job.map; }
// (ronda 3) el mapa SUAVIZADO para el pintor (una vez por mapa): solo la intensidad; bulbo y jovenes son fracciones y se quedan
function fvMw2Soft(map) {
   var M2 = FV_MW2, key = M2.SOFT_B + "|" + M2.SOFT_L;
   if (!(M2.SOFT_B > 0) && !(M2.SOFT_L > 0)) return map;
   if (map.soft && map.softKey === key) return map.soft;
   var NL = M2.NL, NB = M2.NB, I = map.I, T = new Float32Array(NL * NB), O = new Float32Array(NL * NB), i, j, k;
   // en longitud (periodica): gausiana de SOFT_L columnas, radio 3 sigma
   var sl = Math.max(1e-3, M2.SOFT_L), rl = Math.ceil(3 * sl), wl = [], sw = 0;
   for (k = -rl; k <= rl; ++k) { var w0 = Math.exp(-0.5 * k * k / (sl * sl)); wl.push(w0); sw += w0; }
   for (j = 0; j < NB; ++j) for (i = 0; i < NL; ++i) { var a = 0; for (k = -rl; k <= rl; ++k) a += wl[k + rl] * I[j * NL + ((i + k) % NL + NL) % NL]; T[j * NL + i] = a / sw; }
   // en latitud: gausiana de SOFT_B grados con los centros de fila de verdad (no son equidistantes)
   var sb = Math.max(1e-3, M2.SOFT_B), bc = new Float64Array(NB);
   for (j = 0; j < NB; ++j) bc[j] = fvMw2B(j);
   for (j = 0; j < NB; ++j) {
      var ws = [], ks = [], s2 = 0;
      for (k = 0; k < NB; ++k) { var db = bc[k] - bc[j]; if (Math.abs(db) > 3 * sb) continue; var w1 = Math.exp(-0.5 * db * db / (sb * sb)); ws.push(w1); ks.push(k); s2 += w1; }
      for (i = 0; i < NL; ++i) { var a2 = 0; for (var q = 0; q < ks.length; ++q) a2 += ws[q] * T[ks[q] * NL + i]; O[j * NL + i] = a2 / s2; }
   }
   map.soft = { I: O, B: map.B, Y: map.Y, max: map.max, camLy: map.camLy }; map.softKey = key;
   return map.soft;
}
function fvMw2Ref(map0) { var a = Array.prototype.slice.call(map0.I).sort(function(x, y) { return x - y; }); return a[Math.floor(0.995 * (a.length - 1))] || 1; }
// muestra bilineal (direccion unitaria del mundo) -> [I, bulbo, jovenes]
function fvMw2Sample(map, frame, d) {
   var gx = d[0] * frame.ex[0] + d[1] * frame.ex[1] + d[2] * frame.ex[2], gy = d[0] * frame.ey[0] + d[1] * frame.ey[1] + d[2] * frame.ey[2], gz = d[0] * frame.ez[0] + d[1] * frame.ez[1] + d[2] * frame.ez[2];
   var l = Math.atan2(gy, gx); if (l < 0) l += 2 * Math.PI;
   var NL = FV_MW2.NL, NB = FV_MW2.NB, u = l / (2 * Math.PI) * NL, v = fvMw2V(Math.asin(Math.max(-1, Math.min(1, gz))) / FV_DEG), i0 = Math.floor(u), j0 = Math.floor(v), fu = u - i0, fv = v - j0;
   if (j0 < 0) { j0 = 0; fv = 0; } if (j0 >= NB - 1) { j0 = NB - 2; fv = 1; }
   var i1 = (i0 + 1) % NL; i0 = ((i0 % NL) + NL) % NL;
   var r0 = j0 * NL, r1 = r0 + NL, w00 = (1 - fu) * (1 - fv), w10 = fu * (1 - fv), w01 = (1 - fu) * fv, w11 = fu * fv, a = map.I, B = map.B, Y = map.Y;
   return [a[r0 + i0] * w00 + a[r0 + i1] * w10 + a[r1 + i0] * w01 + a[r1 + i1] * w11, B[r0 + i0] * w00 + B[r0 + i1] * w10 + B[r1 + i0] * w01 + B[r1 + i1] * w11, Y[r0 + i0] * w00 + Y[r0 + i1] * w10 + Y[r1 + i0] * w01 + Y[r1 + i1] * w11];
}
// el color pintado de una muestra [I, bulbo, jovenes]: el SUELO se resta (lo que esta por debajo queda negro) y luego la curva -> [R, G, B]
function fvMw2Colour(smp, ref, peak) {
   var M2 = FV_MW2, x = Math.min(1.8, smp[0] / ref) - M2.FLOOR;
   if (x <= 0) return [0, 0, 0];
   x = x * x / (x + M2.KNEE);                                         // rodilla: arranca en 0 con pendiente 0 (sin contorno en el suelo)
   var v = peak * Math.pow(x / (1 - M2.FLOOR), M2.GAMMA), b = smp[1], y = Math.min(1, 0.8 * smp[2]) * (1 - b), cD = M2.COL_DISC, cB = M2.COL_BULGE, cY = M2.COL_YOUNG, o = [0, 0, 0];
   for (var k = 0; k < 3; ++k) o[k] = Math.min(255, Math.round(v * (cD[k] * (1 - b - y) + cB[k] * b + cY[k] * y)));
   return o;
}
// el grano: como fvMwGrain, repartido por el brillo del mapa nuevo (menos estrellas en las grietas) y con el angulo solido de cada fila
function fvMw2Grain(map0, frame, N, seed) {
   var R = fvRng(seed || 9092), NL = FV_MW2.NL, NB = FV_MW2.NB, a = map0.I, cdf = new Float64Array(NL * NB), s = 0, i;
   for (i = 0; i < a.length; ++i) { var jb = Math.floor(i / NL), b0 = fvMw2B(jb - 0.5) * FV_DEG, b1 = fvMw2B(jb + 0.5) * FV_DEG; s += Math.pow(a[i], 1.5) * Math.abs(Math.sin(b1) - Math.sin(b0)); cdf[i] = s; }
   var d = new Float32Array(3 * N), w = new Float32Array(N);
   for (var n = 0; n < N; ++n) {
      var t = R() * s, lo = 0, hi = cdf.length - 1;
      while (lo < hi) { var m = (lo + hi) >> 1; if (cdf[m] < t) lo = m + 1; else hi = m; }
      var ii = lo % NL, jj = Math.floor(lo / NL), l = (ii + R()) / NL * 2 * Math.PI, b = fvMw2B(jj - 0.5 + R()) * FV_DEG;
      var gx = Math.cos(b) * Math.cos(l), gy = Math.cos(b) * Math.sin(l), gz = Math.sin(b);
      for (var q = 0; q < 3; ++q) d[3 * n + q] = gx * frame.ex[q] + gy * frame.ey[q] + gz * frame.ez[q];
      w[n] = Math.pow(R(), 2.0);
   }
   return { d: d, w: w, n: N };
}
