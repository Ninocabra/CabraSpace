// ============================================================================
// FieldVoyager/src/engine/fv_skyov.js — LO QUE SE DIBUJA ENCIMA DEL CIELO: constelaciones vistas DESDE LA NAVE, nombres y la escala
// (columna derecha, D2 · D3 · D5; 5-nov-2026)
// ----------------------------------------------------------------------------
// PURO (sin PixInsight ni navegador): calcula listas de dibujo en pixeles de la pantalla; el pintor de PixInsight (src/ui/fv_rightbar.js)
// y el del navegador las dibujan cada uno con su lienzo. Mismo calculo en los dos visores = mismo comportamiento.
//   D3 · fvSkyovConst: las 88 figuras de Stellarium «modern» (web/fw_const_data.js, CC BY-SA 4.0) con cada estrella en su
//        sitio 3D (Hipparcos: direccion ICRS J2016 + distancia por paralaje si ϖ ≥ 3σ; si no, «al infinito»: solo direccion). Desde casa se
//        ven como siempre; al viajar se DEFORMAN (paralaje de verdad). El marco ICRS → mundo es fvTimeFrame (fv_time.js): la rotacion
//        ajustada a las estrellas de Gaia de la escena (Tierra en el origen, +Z al centro de la foto, años luz).
//   D2 · fvSkyovNames: los candidatos a rotulo — los objetos de la escena (scene.objects, con su nombre) y las estrellas con nombre propio
//        APROBADO por la IAU (WGSN) — en orden de prioridad; el pintor coloca sin solapes con sus medidas de letra.
//   D5 · fvSkyovScale: el ancho de la vista a la distancia de lo que se mira (lo elegido; si no hay, la nebulosa) en años luz y en
//        «Sistemas Solares» (hasta la orbita de Neptuno, FVS_SS_DIAM_AU de src/science/fv_sci_scale.js) y una regla de longitud redonda.
// ES5.
// ============================================================================

var FV_SKYOV = { INF_LY: 1e9,          // «al infinito»: a mil millones de años luz (solo cuenta la direccion)
                 GAP_U: 4.0,           // hueco de la linea junto a cada estrella (unidades = W/1280)
                 MARGIN: 0.25,         // fuera de la pantalla mas de este margen (fraccion) no se dibuja
                 BAR_FRAC: 0.20,       // la regla: la longitud redonda mas grande que no pase del 20 % del ancho
                 AU_SWITCH_LY: 0.05,   // por debajo de este ancho de vista la regla va en unidades astronomicas
                 FRONT_COS: 0.17,      // (5-nov, visto en el montaje) solo segmentos con las DOS estrellas delante a menos de ~80° del eje:
                                       // una estrella casi de lado se proyecta lejisimos y la figura salia como rayos de todo el cielo
                 SEG_MAX_DEG: 40,      // ni ninguno de mas de 40° visto desde la nave (en casa el lado mas largo de una figura no llega; desde
                                       // lejos, un lado entre una estrella cercana y otra lejana cruza medio cielo y no dibuja ninguna figura)
                 SEG_MAX_W: 3,         // seguridad numerica: ninguno mas largo que 3 anchos de pantalla
                 // (5-nov, coordinador: «lejos de casa las figuras se vuelven rayos») cada figura se ATENUA segun lo que se deforma vista desde
                 // la nave: el cambio medio del angulo en cada vertice interior (el mismo instrumento que R4c de fv_rb_test.js) frente al de la
                 // Tierra. Hasta FADE_LO grados, entera; desde FADE_HI, desaparece. Constantes a ojo [NO VERIFICADO con Nino]. FADE false = sin atenuar
                 FADE: true, FADE_LO: 6, FADE_HI: 24,
                 CACHE: true };        // la lista de dibujo se guarda mientras la camara (posicion, mirada, campo, giro) y el lienzo no cambien

// la preparacion (una vez por escena): posiciones en el mundo de las estrellas de las figuras y de las que tienen nombre
function fvSkyovPrep(scene) {
   if (!scene || typeof FV_CONST_DATA === "undefined") return null;
   if (scene.__skyov && scene.__skyov.src === scene.stars) return scene.__skyov;
   var F = (typeof fvTimeFrame === "function") ? fvTimeFrame(scene) : null;
   if (!F || !F.M) return null;
   var D = FV_CONST_DATA, n = D.stars.length, pos = new Float64Array(3 * n), inf = new Uint8Array(n), V = new Float32Array(n), M = F.M, DEG = Math.PI / 180;
   for (var i = 0; i < n; ++i) {
      var s = D.stars[i], a = s[1] * DEG, b = s[2] * DEG, u = [Math.cos(b) * Math.cos(a), Math.cos(b) * Math.sin(a), Math.sin(b)];
      var w = [M[0][0] * u[0] + M[0][1] * u[1] + M[0][2] * u[2], M[1][0] * u[0] + M[1][1] * u[1] + M[1][2] * u[2], M[2][0] * u[0] + M[2][1] * u[1] + M[2][2] * u[2]];
      var d = s[3] > 0 ? s[3] : FV_SKYOV.INF_LY;
      inf[i] = s[3] > 0 ? 0 : 1; V[i] = s[4];
      pos[3 * i] = w[0] * d; pos[3 * i + 1] = w[1] * d; pos[3 * i + 2] = w[2] * d;
   }
   var names = [];
   for (var k in D.names) if (Object.prototype.hasOwnProperty.call(D.names, k)) names.push(+k);
   names.sort(function(x, y) { return V[x] - V[y]; });
   // los vertices interiores de cada figura (a, b, c) y su angulo en b visto desde la Tierra (para medir la deformacion)
   var tri = [];
   for (var f = 0; f < D.figs.length; ++f) {
      var T = [];
      for (var q = 0; q < D.figs[f][2].length; ++q) { var ln = D.figs[f][2][q]; for (var j = 1; j + 1 < ln.length; ++j) T.push([ln[j - 1], ln[j], ln[j + 1], 0]); }
      if (!T.length && D.figs[f][2].length) { var l0 = D.figs[f][2][0]; T.push([l0[0], l0[1], -1, 0]); }      // figura de un solo lado: su longitud
      tri.push(T);
   }
   var prep = { src: scene.stars, n: n, pos: pos, inf: inf, V: V, names: names, frame: F, tri: tri, fadeKey: null, fade: null, cc: null };
   for (var f2 = 0; f2 < tri.length; ++f2) for (var t2 = 0; t2 < tri[f2].length; ++t2) tri[f2][t2][3] = fvSkyovApex(prep, tri[f2][t2], [0, 0, 0]);
   try { Object.defineProperty(scene, "__skyov", { value: prep, enumerable: false, configurable: true, writable: true }); } catch (e) { scene.__skyov = prep; }
   return prep;
}
// el angulo (grados) en el vertice b de (a, b, c) visto desde o; con c = -1, el angulo entre a y b (figura de un lado)
function fvSkyovApex(prep, t, o) {
   var P = prep.pos;
   function dir(i) { var x = P[3 * i] - o[0], y = P[3 * i + 1] - o[1], z = P[3 * i + 2] - o[2], l = Math.sqrt(x * x + y * y + z * z) || 1; return [x / l, y / l, z / l]; }
   var A = dir(t[0]), B = dir(t[1]);
   if (t[2] < 0) return Math.acos(Math.max(-1, Math.min(1, A[0] * B[0] + A[1] * B[1] + A[2] * B[2]))) * 180 / Math.PI;
   var C = dir(t[2]), ka = A[0] * B[0] + A[1] * B[1] + A[2] * B[2], kc = C[0] * B[0] + C[1] * B[1] + C[2] * B[2];
   var u = [A[0] - B[0] * ka, A[1] - B[1] * ka, A[2] - B[2] * ka], v = [C[0] - B[0] * kc, C[1] - B[1] * kc, C[2] - B[2] * kc];
   var lu = Math.sqrt(u[0] * u[0] + u[1] * u[1] + u[2] * u[2]), lv = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
   if (!(lu > 0 && lv > 0)) return 0;
   return Math.acos(Math.max(-1, Math.min(1, (u[0] * v[0] + u[1] * v[1] + u[2] * v[2]) / (lu * lv)))) * 180 / Math.PI;
}
// la deformacion de cada figura vista desde o (grados: cambio medio del angulo de sus vertices; figura de un lado: cambio relativo de su
// longitud × 57,3) y su opacidad (1 entera … 0 desaparecida). Se recalcula solo si la posicion cambia. -> { def: [], alpha: [] }
function fvSkyovFade(prep, o) {
   var key = o[0] + "," + o[1] + "," + o[2] + "," + FV_SKYOV.FADE + "," + FV_SKYOV.FADE_LO + "," + FV_SKYOV.FADE_HI;
   if (prep.fadeKey === key && prep.fade) return prep.fade;
   var nf = prep.tri.length, def = new Float32Array(nf), al = new Float32Array(nf), lo = FV_SKYOV.FADE_LO, hi = FV_SKYOV.FADE_HI;
   for (var f = 0; f < nf; ++f) {
      var T = prep.tri[f], s = 0;
      for (var k = 0; k < T.length; ++k) {
         var a = fvSkyovApex(prep, T[k], o);
         s += (T[k][2] < 0) ? Math.abs(Math.log(Math.max(1e-9, a) / Math.max(1e-9, T[k][3]))) * 57.2958 : Math.abs(a - T[k][3]);
      }
      def[f] = T.length ? s / T.length : 0;
      var x = FV_SKYOV.FADE ? Math.max(0, Math.min(1, (def[f] - lo) / (hi - lo))) : 0;
      al[f] = 1 - x * x * (3 - 2 * x);
   }
   prep.fadeKey = key; prep.fade = { def: def, alpha: al };
   return prep.fade;
}
// un punto del mundo en coordenadas de la camara del proyector (pr de fvProjector / fvPaintRoll): [x, y, z] (z = profundidad)
function fvSkyovCam(pr, p) {
   var vx = p[0] - pr.pos[0], vy = p[1] - pr.pos[1], vz = p[2] - pr.pos[2], r = pr.r, d = pr.d, f = pr.fw;
   return [vx * r[0] + vy * r[1] + vz * r[2], vx * d[0] + vy * d[1] + vz * d[2], vx * f[0] + vy * f[1] + vz * f[2]];
}
function fvSkyovStarCam(prep, pr, i) { var p = prep.pos; return fvSkyovCam(pr, [p[3 * i], p[3 * i + 1], p[3 * i + 2]]); }
function fvSkyovScreen(pr, c) { return [pr.cx + pr.f * c[0] / c[2], pr.cy + pr.f * c[1] / c[2]]; }
// recorte de un segmento 2D a un rectangulo (Liang-Barsky) -> [x0, y0, x1, y1, t0, t1] | null
function fvSkyovClip2(x0, y0, x1, y1, xa, ya, xb, yb) {
   var dx = x1 - x0, dy = y1 - y0, t0 = 0, t1 = 1, P = [-dx, dx, -dy, dy], Q = [x0 - xa, xb - x0, y0 - ya, yb - y0];
   for (var i = 0; i < 4; ++i) {
      if (P[i] === 0) { if (Q[i] < 0) return null; continue; }
      var t = Q[i] / P[i];
      if (P[i] < 0) { if (t > t1) return null; if (t > t0) t0 = t; } else { if (t < t0) return null; if (t < t1) t1 = t; }
   }
   return [x0 + t0 * dx, y0 + t0 * dy, x0 + t1 * dx, y0 + t1 * dy, t0, t1];
}
// D3 · LAS FIGURAS desde la camara -> { segs: [[x0, y0, x1, y1, alpha]], dots: [[x, y, V, alpha]], labels: [{ x, y, text, abbr, alpha }], nSeg,
// nFig (figuras con algo dibujado), nFaded (figuras quitadas por deformadas), cached }
// W, H: el lienzo; u = W / 1280 (la unidad de la cabina). Las lineas se cortan GAP_U antes de cada estrella (estilo de carta celeste).
// (5-nov) Coste: las figuras deformadas (opacidad < 0,02) no se proyectan; y con la camara quieta se devuelve la lista anterior.
function fvSkyovConst(prep, pr, W, H, u) {
   var out = { segs: [], dots: [], labels: [], nSeg: 0, nFig: 0, nFaded: 0, cached: false };
   if (!prep) return out;
   var ck = [pr.pos[0], pr.pos[1], pr.pos[2], pr.fw[0], pr.fw[1], pr.fw[2], pr.r[0], pr.r[1], pr.r[2], pr.f, W, H, u, FV_SKYOV.FADE, FV_SKYOV.FADE_LO, FV_SKYOV.FADE_HI].join(",");
   if (FV_SKYOV.CACHE && prep.cc && prep.cc.key === ck) { prep.cc.out.cached = true; return prep.cc.out; }
   var FA = fvSkyovFade(prep, pr.pos);
   var D = FV_CONST_DATA, mx = FV_SKYOV.MARGIN * W, my = FV_SKYOV.MARGIN * H, xa = -mx, ya = -my, xb = W + mx, yb = H + my;
   var near = 1e-6, gap = FV_SKYOV.GAP_U * u, cam = {}, seen = {};
   function C(i) { if (!cam[i]) cam[i] = fvSkyovStarCam(prep, pr, i); return cam[i]; }
   for (var f = 0; f < D.figs.length; ++f) {
      var fig = D.figs[f], sx = 0, sy = 0, sn = 0, al = FA.alpha[f], n0 = out.segs.length;
      if (al < 0.02) { ++out.nFaded; continue; }
      for (var p = 0; p < fig[2].length; ++p) {
         var line = fig[2][p];
         for (var j = 1; j < line.length; ++j) {
            var a = C(line[j - 1]), b = C(line[j]), aIn = a[2] > near, bIn = b[2] > near;
            if (!aIn || !bIn) continue;
            if (a[2] < FV_SKYOV.FRONT_COS * Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]) || b[2] < FV_SKYOV.FRONT_COS * Math.sqrt(b[0] * b[0] + b[1] * b[1] + b[2] * b[2])) continue;
            var A = a, B = b, cutA = false, cutB = false;
            var pa = fvSkyovScreen(pr, A), pb = fvSkyovScreen(pr, B);
            if (Math.abs(pb[0] - pa[0]) + Math.abs(pb[1] - pa[1]) > FV_SKYOV.SEG_MAX_W * W) continue;
            var la = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]), lb = Math.sqrt(b[0] * b[0] + b[1] * b[1] + b[2] * b[2]);
            if ((a[0] * b[0] + a[1] * b[1] + a[2] * b[2]) / (la * lb) < Math.cos(FV_SKYOV.SEG_MAX_DEG * Math.PI / 180)) continue;
            var q = fvSkyovClip2(pa[0], pa[1], pb[0], pb[1], xa, ya, xb, yb);
            if (!q) continue;
            ++out.nSeg;
            // el hueco junto a la estrella (solo si el extremo es la estrella de verdad, no un corte)
            var dx = q[2] - q[0], dy = q[3] - q[1], L = Math.sqrt(dx * dx + dy * dy);
            if (L < 1e-6) continue;
            var ux = dx / L, uy = dy / L, g0 = (q[4] === 0 && !cutA) ? gap : 0, g1 = (q[5] === 1 && !cutB) ? gap : 0;
            if (L <= g0 + g1 + 0.5) continue;
            out.segs.push([q[0] + ux * g0, q[1] + uy * g0, q[2] - ux * g1, q[3] - uy * g1, al]);
            var ends = [[line[j - 1], aIn, pa], [line[j], bIn, pb]];
            for (var e = 0; e < 2; ++e) {
               var k = ends[e][0], ps = ends[e][2];
               if (!ends[e][1] || ps[0] < 0 || ps[0] > W || ps[1] < 0 || ps[1] > H) continue;
               if (!seen[k]) { seen[k] = 1; out.dots.push([ps[0], ps[1], prep.V[k], al]); }
               sx += ps[0]; sy += ps[1]; ++sn;
            }
         }
      }
      if (out.segs.length > n0) ++out.nFig;
      if (sn >= 3) out.labels.push({ x: sx / sn, y: sy / sn, text: fig[1], abbr: fig[0], alpha: al });
   }
   if (FV_SKYOV.CACHE) prep.cc = { key: ck, out: out };
   return out;
}
// D2 · LOS CANDIDATOS A ROTULO en orden de prioridad -> [{ x, y, text, kind: "object" | "star", r }]
// Primero los objetos de la escena (por score), luego las estrellas con nombre (por brillo). Solo lo que cae delante y en pantalla.
function fvSkyovNames(scene, prep, pr, W, H, L) {
   var out = [], Lk = (L === "es") ? "es" : "en", near = 1e-6, i;
   var obs = (scene && scene.objects) ? scene.objects : [], ord = [];
   for (i = 0; i < obs.length; ++i) if (obs[i] && obs[i].pos) ord.push(i);
   ord.sort(function(a, b) { return (obs[b].main ? 1e6 : 0) + (obs[b].score || 0) - (obs[a].main ? 1e6 : 0) - (obs[a].score || 0); });
   for (var j = 0; j < ord.length; ++j) {
      var o = obs[ord[j]], c = fvSkyovCam(pr, o.pos);
      if (!(c[2] > near)) continue;
      var p = fvSkyovScreen(pr, c);
      if (p[0] < 0 || p[0] > W || p[1] < 0 || p[1] > H) continue;
      var nm = (o.main && scene.nebula && scene.nebula.names) ? (scene.nebula.names[Lk] || scene.nebula.name) : ((o.names && o.names[Lk]) || o.name || o.id);
      if (!nm || /^Gaia DR3 /.test(String(nm))) continue;          // (5-nov, montaje) una estrella sin nombre no es un rotulo: su numero de Gaia esta en la ficha
      out.push({ x: p[0], y: p[1], text: String(nm), kind: "object", r: (o.radiusLy > 0 ? pr.f * o.radiusLy / c[2] : 0) });
   }
   if (prep) for (i = 0; i < prep.names.length; ++i) {
      var k = prep.names[i], cs = fvSkyovStarCam(prep, pr, k);
      if (!(cs[2] > near)) continue;
      var ps = fvSkyovScreen(pr, cs);
      if (ps[0] < 0 || ps[0] > W || ps[1] < 0 || ps[1] > H) continue;
      out.push({ x: ps[0], y: ps[1], text: FV_CONST_DATA.names[k], kind: "star", r: 0, V: prep.V[k] });
   }
   return out;
}
// un numero «redondo» (1, 2 o 5 × 10^n) que no pase de x
function fvSkyovNice(x) { if (!(x > 0)) return 0; var e = Math.pow(10, Math.floor(Math.log(x) / Math.LN10)), m = x / e; return (m >= 5 ? 5 : (m >= 2 ? 2 : 1)) * e; }
// D5 · LA ESCALA de la vista -> { dRef, ref, refName, widthLy, solarSystems, bar: { len, unit ("ly" | "au"), frac } } | null
// Referencia: lo elegido (P.sel) si lo hay; si no, la nebulosa de la foto (su centro). El campo de vision de la camara es el HORIZONTAL.
function fvSkyovScale(P, scene, L) {
   if (!P || !P.cam || !scene) return null;
   var ref = null, refName = "", kind = "";
   if (P.sel && typeof fvSelPos === "function") { try { ref = fvSelPos(P, P.sel); } catch (e) { ref = null; } kind = P.sel.kind; }
   if (ref && P.sel.kind === "object" && scene.objects && scene.objects[P.sel.i]) { var o = scene.objects[P.sel.i]; refName = (o.names && o.names[(L === "es") ? "es" : "en"]) || o.name || ""; }
   if (!ref && scene.nebula) { ref = [0, 0, scene.nebula.distLy]; kind = "nebula"; }
   if (ref && kind === "nebula" && scene.nebula) refName = (scene.nebula.names && scene.nebula.names[(L === "es") ? "es" : "en"]) || scene.nebula.name || "";
   if (!ref) return null;
   var d = fvLen(fvSub(ref, P.cam.pos));
   if (!(d > 0)) return null;
   var w = 2 * d * Math.tan(P.cam.fov / 2);
   var LYAU = (typeof FVS !== "undefined" && FVS.LY_AU) ? FVS.LY_AU : 63241.077, SS = (typeof FVS_SS_DIAM_AU === "number") ? FVS_SS_DIAM_AU : 60.14;
   var au = (w < FV_SKYOV.AU_SWITCH_LY), wu = au ? w * LYAU : w, len = fvSkyovNice(FV_SKYOV.BAR_FRAC * wu);
   return { dRef: d, ref: ref, refKind: kind, refName: refName, widthLy: w, solarSystems: w * LYAU / SS, bar: { len: len, unit: au ? "au" : "ly", frac: len / wu } };
}
// cifras con dos significativas para lo grande (620 000, no 621 384: la escala es una idea, no una medida al metro)
function fvSkyovRound2(x) { if (!(x > 0)) return 0; if (x < 10) return Math.round(x * 10) / 10; var e = Math.pow(10, Math.floor(Math.log(x) / Math.LN10) - 1); return Math.round(x / e) * e; }
