// ============================================================================
// FieldVoyager/src/engine/fv_objects.js — LOS OBJETOS SINGULARES DEL CAMPO (pasada N, encargo C: N8 y los datos de N1; 4-nov-2026)
// ----------------------------------------------------------------------------
// POR QUE: hasta F4b el motor suponia UNA nebulosa grande que llena el campo (capas). Un objeto compacto en medio de un campo de
// estrellas (NGC 2392, la Esquimal: ~0,8′ en la foto de Nino) acababa repartido en las 8 capas de TODA la foto a la distancia de la
// nebulosa «de fondo», y el clic sobre ella elegia su estrella central (N8, 4-nov). Ahora los objetos extensos y compactos del campo
// (planetarias, galaxias, cumulos, nebulosas pequeñas, cuasares) son ENTIDADES propias:
//   · de catalogo (SIMBAD por https con cache, src/build/fv_build.js; sin red, lo local: OpenNGC y los cumulos de CabraShared, y una
//     deteccion en la foto si no hay nada), con su DISTANCIA (medida, de catalogo o supuesta, con su error y dicho);
//   · con su TAMAÑO APARENTE MEDIDO en la foto sin estrellas (fvObjSegment: mascara del objeto que crece desde el centro, con el
//     agujero de la estrella central rellenado y bordes suaves y redondos; depende del ESTIRADO de la foto: se dice en la ficha);
//   · en 3D a su distancia con VOLUMEN (fvObjShellWeights: varias capas recortadas de la foto que, desde la Tierra, SUMAN el recorte;
//     una planetaria o una nebulosa, una esfera de capas de cara a la camara; una galaxia, un disco fino). El volumen es ESTETICO:
//     la foto solo da una cara.
// Tambien estrellas notables (la mas cercana, la mas luminosa, la mas caliente, la mayor, la de RUWE alto, la central de la planetaria)
// y la nebulosa principal, para la lista de N1 (A la dibuja). Todo ordenado por `score` (singularidad).
// CONTRATO (docs/pasada-N-encargo.md): scene.objects = [ o ] con o = { id, name, type, typeLabel {en, es}, px {x, y, r} (Bitmap de trabajo),
//   pos [x, y, z] (años luz, marco de la escena), distLy, distErrLy, distSrc "measured"|"catalog"|"assumed", radiusLy, mag, score, src,
//   arriveLy } y ademas (nuestro): star (indice de la estrella: la central de una planetaria o la propia en las notables), main (la nebulosa
//   grande), seg (resumen de la segmentacion), sizeArcmin (diametro medido), sizeCatArcmin, distRef, why, z, lookbackYr.
//   Los mapas de pixeles y los Bitmap van en o._gfx (NO enumerable: no entra en el JSON de la escena).
//   fvObjectHit(scene, pr, P, mx, my) -> indice | -1 · fvObjectCard(scene, i, lang) -> { title, sub, l1, l2, stamp, … }
//   fvObjectTarget(scene, i) -> { pos, arriveLy, lookAt }
// PURO salvo lo marcado (nada de PixInsight). ES5.
// ============================================================================

var FV_OBJ = {
   MAX: 24,                 // objetos del campo (sin las estrellas notables) que entran en la lista
   COMPACT: 0.25,           // compacto = diametro < 25 % del lado menor de la foto; mas grande es «la nebulosa grande» (las capas)
   // SEGMENTACION (fvObjSegment) — diseño, ajustado a ojo en NGC 2392 y Collinder 34 (4-nov):
   SEG_K: 3.0,              // umbral: fondo + max(SEG_K σ, SEG_REL × (pico − fondo))
   SEG_REL: 0.05,
   SEG_SNR: 6,              // por debajo de (pico − fondo) / σ = 6 el objeto «no se ve en la foto»
   SEG_WIN0: 48,            // ventana inicial (semilado, px de trabajo), o SEG_WINK × el radio de catalogo
   SEG_WINK: 6,
   SEG_EDGE: 0.72,          // si la mascara llega a SEG_EDGE de la ventana, se dobla la ventana; en la mayor, «no es compacto»
   FEATHER: 0.15,           // borde suave = FEATHER × radio equivalente (min 2 px)
   // VOLUMEN (ESTETICO): capas por tipo y semiprofundidad / radio
   SHELLS: { pn: 37, galaxy: 3, nebula: 29, other: 21 },   // (4-nov, cuarta) el doble: de lado, la separacion entre capas vecinas baja a la mitad (sin arcos)
   SHELL_MODE: "sheet", SHELL_CELL: 0.7, SHELL_DOME: 0.65, SPLAT: 1.6, DEPTH_BLUR: 0.3, PLANE_MB: 64, CUT_FROM_REST: true, CUT_AFTER_LIMIT: true, HIT_MASK: true, HIT_ALPHA: 0.25, CORE_BLUR: 0.2,   // "sheet" = lamina continua (por defecto) · "binary" = zonas enteras delante/detras (ROJO: huecos negros al llegar)
   CORE_B: 0.45, CORE_R: 0.6,   // el nucleo / anillo interior: brillo ≥ 0,45 del p99 dentro de 0,6 R (ESTETICO, a ojo en NGC 2392)
   // (5-nov, C11) la profundidad de la cascara atada a 0 en el nucleo y con pendiente maxima SHELL_LIP_K (t por radio): sin salto de profundidad
   // entre el anillo y la cascara no queda hueco de paralaje de lado (ver fvObjLipschitzUp). SHELL_LIP = false: ROJO (la media luna oscura de C11)
   // K 0,6 (sonda tests/fv_S_nC11_fix_probe.js): con 0,7 y 1,0 queda 1 minimo; con 0,6 y 0,5, 0 (0,5 baja la nitidez de llegada de C9 a 1,70 < 1,71).
   // Precio: la cascara junto al nucleo queda menos profunda (|t| medio pesado por luz 0,14 -> 0,08) y de lado se parece mas a de frente
   // (C9: r 0,869 -> 0,892; sin paralaje ninguna, 0,904; el ROJO sin contar la media luna, 0,895: parte de su «volumen» ERA la banda oscura)
   SHELL_LIP: true, SHELL_LIP_K: 0.6,
   DEPTH: { pn: 0.75, galaxy: 0.08, nebula: 0.6, other: 0.5 },
   // LLEGADA (I9): a cuantos radios del objeto se para la nave. Planetaria: 5 R (llena ~40 % de 60°); galaxia mas lejos (9 R)
   ARRIVE_R: { pn: 5, galaxy: 9, cluster: 6, nebula: 5, other: 6, quasar: 6 },
   // SINGULARIDAD (score): peso del tipo
   TYPE_W: { quasar: 5, pn: 5, galaxy: 4, nebula: 3, cluster: 3, star: 2, other: 2 },
   // (N12) un planeta conocido en el campo es de lo mas singular: 8 (por gaia_dr3_id) o 7 (por posicion + paralaje compatible)
   EXO_SCORE: 8, EXO_SCORE_POS: 7,
   CLUSTER_ARCMIN: 4,       // cumulo sin tamaño en el catalogo: 4′ de diametro para el clic de la lista y la llegada (ELECCION nuestra)
   CENTRAL_ARCSEC: 3,       // la estrella central de una planetaria: a menos de 3″ del centro de SIMBAD
   STAR_CLICK: 0.12,        // el clic a menos de 12 % del radio en pantalla (o 4 px) de la estrella central es de la ESTRELLA
   // SUPUESTOS de distancia cuando nadie la mide (dicho en la ficha):
   GAL_DIAM_LY: 30000,      // galaxia sin distancia: un diametro tipico de 30 000 a.l. (ELECCION nuestra)
   PN_DIAM_LY: 1.0,         // planetaria sin distancia: ~1 a.l. de diametro (orden de magnitud tipico; ELECCION nuestra)
   QSO_HOST_LY: 50000,      // cuasar: la galaxia que lo aloja, ~50 000 a.l. (solo para la llegada; ELECCION nuestra)
   // (E4, 4-nov noche) MIRABILIA: lo que se ofrece esta y se ve al llegar (tests/fv_nC2_mirabilia_test.js; cabecera E4 en src/build/fv_build.js)
   PARTS: true,             // false = ROJO: sin galaxias grandes ni «partes de una galaxia» (las 24 planetarias [JMT2009] de M 82)
   GAL_MAX_FRAC: 0.6,       // una galaxia entra hasta el 60 % del lado menor (la ventana de fvObjSegment llega a 0,3 de radio)
   PART_DIST: 0.1,          // dentro de una galaxia, solo se queda lo que tiene distancia MEDIDA < 10 % de la suya (de la Via Lactea, delante)
   PN_UNCAT_MAX: 2,
   MIN_PEAK: 10,            // niveles (de 255) del pico sobre el fondo en la foto de trabajo para que al llegar no sea negro (ver F5b en fv_build.js)
   VISIBLE_ONLY: true,      // false = ROJO: entraban cuasares y galaxias sin segmentar (no se dibujan: al llegar, cielo negro)         // arcmin: una planetaria sin tamaño de catalogo ni distancia medida no puede medir mas en la foto
   // LLEGADA AJUSTADA AL CAMPO REAL: ARRIVE_R supone llegar con 60° de campo, pero delante de la foto el piloto cierra el campo para no
   // enseñar su borde (regla A): a Cl Collinder 34 se llegaba a 15,8 a.l. con 0,58° de campo y el cumulo ocupaba 70 veces la pantalla.
   // Con ARRIVE_FIT la distancia de llegada se alarga hasta que el objeto ocupa del campo de llegada (el que fija el propio piloto,
   // fvPilotFly desde casa) la misma fraccion que ARRIVE_R daba con 60°. false = ROJO
   // FIT_MAX: tolerancia — solo se aleja si el objeto ocuparia mas de FIT_MAX veces su fraccion (NGC 2392 llega con 1,95 veces y se ve bien:
   // no se toca; los cumulos de Collinder 34 llegaban con 100 veces), y entonces a su fraccion NOMINAL: con 2 veces, M 82 (encuadrada en el
   // tercio izquierdo) se salia por el borde de la pantalla (0,66 del campo; el campo real sale ~1,5 veces menor que el que estima fl.fov1)
   ARRIVE_FIT: true, FIT_MAX: 2, FIT_VW: 1280, FIT_VH: 720,
   // (R8, 12-nov) EL ENCUADRE DE LO QUE SE OFRECE: el objeto se enseña ENTERO. Se mide su CONTORNO (o.frame: centroide y radio que contiene el 98 % de su
   // mascara, no el centro de catalogo; la nebulosa principal, el de fvMiraContour) y la camara se aleja hasta que ese radio × FRAME_MARGIN cabe en lo que
   // deja libre el encuadre del tercio (o en la mitad de la pantalla si va centrado) CON EL CAMPO REAL de llegada (el que fija el piloto, como ARRIVE_FIT).
   // Antes se llegaba a ARRIVE_R radios con FIT_MAX = 2 de tolerancia: NGC 2392 llegaba ocupando 0,74 del campo y la mascara se salia por el borde derecho;
   // la nebulosa principal iba al CENTRO DE LA FOTO a hw / tan(30°) + grosor/2 con el tercio: con el tope A del piloto el campo se cerraba a 6,9° y se veia
   // un trozo azul (Collinder 34 / IC 1848: 131 a.l., 6,9°). FRAME = false: ROJO (lo de antes)
   FRAME: true, FRAME_MARGIN: 1.25, FRAME_WHOLE_K: 0.97,   // WHOLE_K: tope de la distancia con que se enseña una nebulosa que ES la foto (fraccion de la distancia a casa)
   // (R8v5, 14-nov) EL ENCUADRE CON LA NAVEGACION v5 (laboratorio de vuelo, FV_LAB.ON): su pantalla estira lo lateral S veces (fvLabProjector: x, y × S; z igual; S = 9,6–60), de modo que
   // el campo LATERAL REAL de la llegada es 2·atan(tan(F/2) / S) y no F. fvObjFrameFit lo calculaba con F (el campo del piloto clasico / la lente de 50°) y el radio en lateral real:
   // el contorno llegaba a 0–1 % en pantalla (IC 1848 a 131 a.l. con 50°, un parche liso). FRAME_LAB = false: ROJO (el encuadre de antes, que ignora S)
   FRAME_LAB: true,
   // (P32, 17-nov) un objeto «RNe» (nebulosa de reflexion de SIMBAD) que NO es el principal se rotula «nebulosa de reflexion» (FV_OBJ_LABEL.rne, via fvObjLabelKey) y no «nebulosa».
   // El TIPO sigue siendo «nebula» (el orden, el motor y el icono cuelgan de el): solo cambia la etiqueta. false = ROJO: «nebulosa» como antes.
   RNE_LABEL: true,
   // (C4, 17-nov) EL CALCULO DE LA SEGMENTACION, no lo que decide (fvObjSegOnce, fvObjBlur): el cielo de la ventana (mediana y MAD) por histograma en vez de ordenar ~200 000
   // valores 5 veces por intento, la luminancia y el suavizado solo donde se mira el pico mientras el objeto «no se ve» (el resto de la ventana solo si pasa), el suavizado de caja
   // con los mismos sumandos en el mismo orden (bit a bit igual) y el p98 de distancias con un Float64Array. Misma mascara, mismos motivos. false = ROJO: el calculo de antes
   FAST_SEG: true,
   // (E2a, 17-nov) LA DETECCION DE LOS OBJETOS EXTENSOS (medida: docs/encargos-17nov/E1.md; cada una con su bandera, false = lo de antes):
   //  · SEG_WIDE: fvObjSegment repite UNA vez con la ventana a SEG_WH_FRAC × el lado menor (en vez de 0,3) lo que de siempre da «not compact» y el catalogo dice que es grande (radio ≥ SEG_WIDE_RC × el tope
   //    de 0,3: 0,5). E1 §3: GAL_MAX_FRAC admite galaxias hasta el 60 % pero con 0,3 la mascara solo cabe hasta ~43 % (SEG_EDGE 0,72 × 0,3 × 2): IC 342 = 58 % salia «not compact (the mask reaches 304 px, the
   //    window 404 px)»; con 0,6 mide rMax 428 de 809. SEG_WH_FRAC 0,6 = el valor medido en E1. SEG_WIDE_RC 0,5: ELECCION nuestra (un radio de catalogo de al menos la mitad del tope de siempre; IC 342: 393 de 404).
   //  · COMPACT_WIDE: una nebulosa / «otro» CON NOMBRE PROPIO (M, NGC, IC, Caldwell, Sharpless, «NAME …»: fvObjDesigRank < 9) ya no se descarta por «larger than 25 %» hasta COMPACT_WIDE_FRAC (0,6 = GAL_MAX_FRAC)
   //    del lado menor: M 42 (66′ = 38 %) en Orion (E1 §3, §7 E2-b.2). Las entradas anonimas (WISE [ABB2014], IRAS, AAJ…) siguen en COMPACT: son alias o fragmentos de la nebulosa grande (5 de los 6 descartes de E1).
   //  · NEB_DEDUP: dos entradas de nebulosa que son el MISMO objeto (M 42 de SIMBAD y su alias WISE G209.107, 66′ y 58′, a 9,4′ una de otra) no entran las dos: se queda la de mejor designacion; y una recien
   //    admitida que es la nebulosa principal (otra entrada de ella) no se dibuja como objeto. SAME_SEP: el centro a menos de SAME_SEP × el radio de la mayor (0,5: la mitad del radio); SAME_RATIO: el menor
   //    mide al menos SAME_RATIO del mayor (0,3; M 42 de 66′ en Barnard's Loop de 1 200′ NO es el mismo). ELECCION nuestra: con los datos reales de SIMBAD, M 42/WISE G209.107 (9,4′ de 16,5′ permitidos) y
   //    WISE G099.484/Sh 2-131 en IC 1396 (22,8′ de 42,5′) son el mismo; WISE G208.445 (39′ de M 42) y WISE G138.069 (61′ de IC 1848) no (tests/_e2a/fv_e2a_node.js).
   //    SAME_IOU: ademas, dos entradas cuyas MASCARAS medidas coinciden (interseccion / union ≥ 0,7) son una sola aunque el catalogo les ponga tamaños distintos (Orion: M 42 de 66′ y WISE G209.037 de 9′, rMax 167 y 169 px).
   //  · ALIAS: la designacion con que se rotula un objeto es la mejor entre las que conocemos EN LOCAL (OpenNGC por posicion para las galaxias, la lista de nebulosas del campo, el main_id de SIMBAD):
   //    Messier > nombre comun > NGC > IC > Caldwell > Sharpless > el resto, y a igual rango la fuente local manda (SIMBAD llama «NGC 3180» a NGC 3184).
   //  · NAME_CLEAN (F7-c, 17-nov): los nombres comunes de SIMBAD («NAME Rosette Nebula», «NAME Barnard's Loop», «NAME Ori Trapezium») se ven SIN el «NAME » (ni el articulo inicial) en todo el producto: se limpian UNA vez, en el origen
   //    (fvObjShowName: el rotulo de cada objeto, de la nebulosa principal y de la galaxia grande de la foto), y de ahi lo leen la ficha, MIRABILIA, el Tour, la capa, PROFUNDITAS y la web. false = lo de antes
   //  · IDENT (F7, 17-nov): el rotulo sale tambien de los IDENTIFICADORES del mismo objeto en SIMBAD (tabla `ident`, una consulta por foto con cache de 30 dias; sin red y sin cache, los nombres de antes):
   //    una NGC / IC / Caldwell / Sharpless cambia a su numero de Messier o a su nombre comun («NAME the Witch Head Nebula» → «Witch Head Nebula»); entre NGC e IC NO se cambia (fvObjIdentPick). false = lo de antes
   //  · NAME_DEDUP (N3, 19-nov): la ficha de la nebulosa principal escribia «nombre  ·  id» comparando las dos cadenas LETRA A LETRA: IC 1396 salia «SH 2-131  ·  Sh 2-131» (el main_id de SIMBAD va en
   //    mayusculas; el id de la lista del campo, no). Ahora dos designaciones que solo difieren en mayusculas / espacios («SH 2-131», «Sh 2-131», «Sh2-131», «Sharpless 2-131») cuentan como UNA (fvObjSameDesig) y se
   //    escribe una vez, con la grafia del catalogo (fvObjCanonName: la del id). Vale en la ficha (HUD, fvObjectCard y la web) y en el nombre de la principal (MIRABILIA / Tour). false = lo de antes, identico
   //  · PREFER_NGCIC (N3b, 19-nov; decision de Nino): cuando una nebulosa tiene A LA VEZ una designacion Sharpless y una NGC / IC, se rotula con la NGC / IC (asi la conoce un astrofotografo: «IC 1396», no «Sh 2-131»).
   //    Orden final: Messier > nombre comun > NGC / IC > Sharpless > el resto. Solo se cambia un rotulo Sharpless: entre NGC e IC NO se cambia nunca (NGC 1909 sigue siendo NGC 1909 aunque sea IC 2118), y una entrada de
   //    catalogos de investigacion (WISE, LEDA…) no se renombra. Los alias salen (1) de los identificadores de SIMBAD (`ident`, la consulta de F7 con LIKE 'NGC %' / 'IC %': fvObjIdentPick) y (2) de la lista de nebulosas
   //    del campo cuando una entrada NGC / IC es la MISMA nebulosa que la Sharpless (fvObjNgcIcTwin: misma posicion y tamaño comparable; la de OpenNGC-Outlines de PixInsight, local, sin red). Ambiguo (dos NGC / IC
   //    candidatas) = no se renombra. false = lo de antes, identico (la consulta ident vuelve a ser la de F7)
   //  · TITLE_NGCIC (N3c, 20-nov; decision de Nino): el TITULO de la ficha de una nebulosa rotulada con su NGC / IC lleva solo ese («IC 1396», no «IC 1396  ·  Sh 2-131»): la Sharpless es un alias y pasa a la linea pequena
   //    (fvObjTitleAlias, tras el tipo y el tamaño). Solo cuando el rotulo es NGC / IC y el id es una Sharpless: M 42, «Rosette Nebula» y «Witch Head Nebula · NGC 1909» no cambian. false = «nombre  ·  id» de antes
   //  · BG_HERO (N13, 20-nov; decision de Nino): sin nebulosa de catalogo la capa se llama «Background nebulosity» (fv_build.js, FV_NEB_BG_NAME) y un doble clic / clic en la foto elegia {kind:"nebula"}: la ficha decia
   //    «Background nebulosity» a una distancia SUPUESTA aunque el Tour y MIRABILIA rotulen el protagonista dibujado («IC 342», una galaxia de 10 millones de a.l.). Ahora, con protagonista dibujado (objects[i].hero) y sin
   //    nebulosa de catalogo (scene.nebula.background), el clic en la capa elige ESE objeto (fvPick) y la ficha de {kind:"nebula"} es la suya (fvCardContent). false = lo de antes
   SEG_WIDE: true, SEG_WH_FRAC: 0.6, SEG_WIDE_RC: 0.5, COMPACT_WIDE: true, COMPACT_WIDE_FRAC: 0.6, NEB_DEDUP: true, SAME_SEP: 0.5, SAME_RATIO: 0.3, SAME_IOU: 0.7, ALIAS: true, IDENT: true, NAME_CLEAN: true, NAME_DEDUP: true, PREFER_NGCIC: true, TITLE_NGCIC: true, BG_HERO: true,
   FRAME_END: 0
};

// el tipo del contrato a partir de la clase de CabraShared (cpSfSimbadClass) y el codigo de SIMBAD
function fvObjType(cls, otype) {
   var c = String(cls || ""), t = String(otype || "");
   if (c === "planetary-nebula" || t === "PN" || t === "PN?") return "pn";
   if (c === "quasar" || t === "QSO" || t === "Q?" || t === "Bla" || t === "BLL") return "quasar";
   if (c === "galaxy" || c === "galaxy-group") return "galaxy";
   if (c === "star-cluster" || c === "association" || t === "OpC" || t === "GlC" || t === "Cl*") return "cluster";
   if (c === "nebula" || t === "HII" || t === "RNe" || t === "GNe") return "nebula";
   if (c === "supernova" || t === "SNR" || t === "SNR?") return "other";
   return "";
}
var FV_OBJ_LABEL = {
   pn: { en: "planetary nebula", es: "nebulosa planetaria" }, galaxy: { en: "galaxy", es: "galaxia" }, cluster: { en: "star cluster", es: "cúmulo de estrellas" },
   nebula: { en: "nebula", es: "nebulosa" }, rne: { en: "reflection nebula", es: "nebulosa de reflexión" }, quasar: { en: "quasar", es: "cuásar" }, star: { en: "star", es: "estrella" }, other: { en: "object", es: "objeto" },
   snr: { en: "supernova remnant", es: "resto de supernova" }, exoplanet: { en: "exoplanet", es: "exoplaneta" }, unknown: { en: "unidentified compact object", es: "objeto compacto sin identificar" }
};

// (P32, 17-nov) la clave de FV_OBJ_LABEL de un objeto: la de siempre (subtipo snr / unknown, si no su tipo) salvo una nebulosa «RNe» de SIMBAD (clave rne, con FV_OBJ.RNE_LABEL).
// El tipo del contrato NO cambia (fvObjType sigue devolviendo «nebula» para RNe): solo la etiqueta que se ve.
function fvObjLabelKey(type, otype, subtype) {
   if (subtype === "snr") return "snr";
   if (subtype === "unknown") return "unknown";
   if (FV_OBJ.RNE_LABEL !== false && type === "nebula" && String(otype || "") === "RNe") return "rne";
   return type;
}
// ---------------------------------------------------------------------------
// (E2a, 17-nov) DESIGNACIONES Y OBJETOS REPETIDOS (puro; node lo ejecuta: tests/_e2a/fv_e2a_node.js)
// ---------------------------------------------------------------------------
function fvObjDesigNorm(s) { return String(s || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }
// el rango de una designacion (menor = mas conocida por un astrofotografo): 0 Messier · 1 nombre comun («NAME …» de SIMBAD) · 2 NGC · 3 IC · 4 Caldwell · 5 Sharpless · 9 el resto
// (WISE, IRAS, LEDA, 2MASX, [ABB2014]… son numeros de catalogos de investigacion que nadie dice en voz alta)
function fvObjDesigRank(name) {
   var s = fvObjDesigNorm(name);
   if (/^M \d+$/i.test(s)) return 0;
   if (/^NAME /i.test(s)) return 1;
   if (FV_OBJ_COMMON_LABELS.hasOwnProperty(s)) return 1;      // (F7) un nombre comun ya limpio de «NAME » («Witch Head Nebula»): sigue valiendo rango 1 donde se compara (vacio con FV_OBJ.IDENT false)
   if (/^NGC \d+[A-Z]?$/i.test(s)) return 2;
   if (/^IC \d+[A-Z]?$/i.test(s)) return 3;
   if (/^(C|Caldwell) \d+$/i.test(s)) return 4;
   if (/^Sh ?2-\d+$/i.test(s)) return 5;
   return 9;
}
// (F7, 17-nov) NOMBRES COMUNES YA LIMPIOS: lo que fvObjIdentLabel (fv_build.js) pone como rotulo se anota aqui para que fvObjDesigRank lo siga contando como nombre comun (rango 1)
var FV_OBJ_COMMON_LABELS = {};
// «NAME the Witch Head Nebula» (el id de SIMBAD) -> «Witch Head Nebula»: sin el «NAME » ni el articulo inicial, con la primera letra en mayuscula
function fvObjCommonLabel(id) {
   var s = fvObjDesigNorm(id).replace(/^NAME\s+/i, "").replace(/^the\s+/i, "");
   return s.length > 0 ? s.charAt(0).toUpperCase() + s.substring(1) : "";
}
// (N3b, 19-nov) «NGC  1976», «IC 1396», «ngc 7129a» -> «NGC 1976», «IC 1396», «NGC 7129A» (sin relleno ni ceros a la izquierda); cualquier otra cosa -> ""
function fvObjNgcIcNorm(s) {
   var m = /^(NGC|IC) ?0*(\d+)([A-Z]?)$/i.exec(fvObjDesigNorm(s));
   return m ? m[1].toUpperCase() + " " + m[2] + m[3].toUpperCase() : "";
}
// (N3b, 19-nov; FV_OBJ.PREFER_NGCIC) el rotulo NGC / IC de una nebulosa que hoy se rotula con una SHARPLESS. `cands` = las NGC / IC del mismo objeto (ya normalizadas, sin repetidos). Solo se cambia un rotulo
// Sharpless (rango 5): una NGC no se cambia por una IC ni al reves (NGC 1909 = IC 2118), una entrada WISE / LEDA no se renombra, y Messier / nombre comun ya ganan antes (fvObjIdentPick). UNA candidata = ella;
// ninguna o varias (dos NGC / IC distintas para la misma Sharpless: ambiguo) = "" (sin cambio). Puro; node lo ejecuta (tests/_n3b/fv_n3b_node.js)
function fvObjPreferNgcIc(current, cands) {
   if (FV_OBJ.PREFER_NGCIC === false || fvObjDesigRank(current) !== 5) return "";
   return (cands && cands.length === 1) ? cands[0] : "";
}
// (N3b) lo mismo con la tabla LOCAL: `local` = [ { id: «IC 1396», … } ] (CabraShared, `ngcicLocal` de cada nebulosa de la lista del campo: las NGC / IC de OpenNGC-Outlines que son esa Sharpless por posicion).
// -> el rotulo NGC / IC o "" (ninguna, varias o el rotulo de ahora no es Sharpless)
function fvObjNgcIcLocal(current, local) {
   var c = [], i;
   for (i = 0; local && i < local.length; ++i) { var n = fvObjNgcIcNorm(local[i] && local[i].id); if (n.length > 0 && c.indexOf(n) < 0) c.push(n); }
   return fvObjPreferNgcIc(current, c);
}
// (F7, 17-nov; FV_OBJ.IDENT) El ROTULO de un objeto a partir de sus identificadores en SIMBAD (`idents`: [«M  42», «NAME Orion Nebula», «NGC  1976», …], todos del MISMO objeto) y del rotulo actual.
// Que quiere un astrofotografo (las dos cosas que SIEMPRE dice en voz alta: el Messier y el nombre propio; entre NGC e IC el numero es solo la cronologia del catalogo —1888 / 1895-1908— y varios objetos
// llevan los dos, p. ej. NGC 1909 = IC 2118— asi que ese orden NO se toca): Messier > nombre comun > lo que ya habia. Solo se cambia un rotulo de rango 2-5 (NGC, IC, Caldwell, Sharpless) o 9; uno que ya es
// Messier o nombre comun se queda. Dos Messier distintos entre los identificadores = ambiguo, no se renombra (""). Varios nombres comunes («NAME Cen A», «NAME Centaurus A», «NAME Cen-A»): el MAS LARGO
// (las abreviaturas son siempre las mas cortas; NGC 7000: «North America Nebula» frente a «Bermuda Cluster» y «North America»), a igual longitud el primero por orden alfabetico — ELECCION nuestra, sin dato
// de uso detras. -> el rotulo nuevo («M 82», «Witch Head Nebula») o "" (sin cambio). `.common` = true si es un nombre comun (para FV_OBJ_COMMON_LABELS)
function fvObjIdentPick(current, idents) {
   var out = { label: "", common: false }, i, mes = {}, nMes = 0, mBest = "", names = [], ngcic = [];
   if (fvObjDesigRank(current) <= 1) return out;
   for (i = 0; idents && i < idents.length; ++i) {
      var s = fvObjDesigNorm(idents[i]); if (!s) continue;
      if (/^M \d+$/i.test(s)) { var u = "M " + s.replace(/^M /i, "").replace(/^0+/, ""); if (!mes[u]) { mes[u] = true; ++nMes; mBest = u; } }
      else if (/^NAME /i.test(s)) { var c = fvObjCommonLabel(s); if (c.length > 0 && names.indexOf(c) < 0) names.push(c); }
      else { var ni = fvObjNgcIcNorm(s); if (ni.length > 0 && ngcic.indexOf(ni) < 0) ngcic.push(ni); }      // (N3b) NGC / IC del mismo objeto
   }
   if (nMes > 1) return out;
   if (nMes === 1) { out.label = mBest; return out; }
   if (names.length === 0) { out.label = fvObjPreferNgcIc(current, ngcic); return out; }      // (N3b) sin Messier ni nombre comun: una Sharpless con UNA NGC / IC se rotula con ella
   names.sort(function(a, b) { return (b.length - a.length) || (a < b ? -1 : (a > b ? 1 : 0)); });
   out.label = names[0]; out.common = true;
   return out;
}
// (F7-c, 17-nov; FV_OBJ.NAME_CLEAN) EL NOMBRE QUE SE VE: un nombre comun de SIMBAD sin el «NAME » ni el articulo («NAME Rosette Nebula» -> «Rosette Nebula»); cualquier otro nombre, tal cual. El limpio se anota
// en FV_OBJ_COMMON_LABELS (fvObjDesigRank lo sigue contando como nombre comun, rango 1). Es la UNICA funcion que quita el prefijo: no se vuelve a cortar «NAME » en ningun otro sitio.
function fvObjShowName(name) {
   if (FV_OBJ.NAME_CLEAN === false || !/^NAME\s+\S/i.test(String(name || ""))) return name;
   var lb = fvObjCommonLabel(name); if (lb.length === 0) return name;
   FV_OBJ_COMMON_LABELS[lb] = true;
   return lb;
}
// (N3, 19-nov; FV_OBJ.NAME_DEDUP) LA MISMA DESIGNACION escrita de dos maneras. La clave: sin «NAME » ni articulo (un nombre comun), en mayusculas, sin espacios y con «Sharpless» como «SH»
// («SH 2-131», «Sh 2-131», «Sh2-131», «Sharpless 2-131» -> «SH2-131»). No une designaciones distintas (NGC 1909 / IC 2118 son dos claves). Puro; node lo ejecuta (tests/_n3/fv_n3_node.js)
function fvObjDesigKey(s) {
   var t = fvObjDesigNorm(s); if (/^NAME\s/i.test(t)) t = fvObjCommonLabel(t);
   return t.toUpperCase().replace(/^SHARPLESS\s*/, "SH").replace(/\s+/g, "");
}
// ¿son a y b la misma designacion? Con FV_OBJ.NAME_DEDUP false, la comparacion de siempre (letra a letra)
function fvObjSameDesig(a, b) {
   if (FV_OBJ.NAME_DEDUP === false) return a === b;
   if (a === b) return true;
   if (!a || !b) return false;
   return fvObjDesigKey(a) === fvObjDesigKey(b);
}
// el nombre con la grafia del catalogo: si `name` es la misma designacion que `id` y esa es de catalogo (NGC / IC / Caldwell / Sharpless, rango 2-5), la del id («SH 2-131» + «Sh 2-131» -> «Sh 2-131»);
// en cualquier otro caso, `name` tal cual (un nombre comun, un Messier, otra designacion). Con la bandera false, `name`
function fvObjCanonName(name, id) {
   if (FV_OBJ.NAME_DEDUP === false || !name || !id || name === id) return name;
   var rk = fvObjDesigRank(id);
   return (rk >= 2 && rk <= 5 && fvObjDesigKey(name) === fvObjDesigKey(id)) ? fvObjDesigNorm(id) : name;
}
// el titulo de la ficha de la nebulosa principal: «nombre  ·  id», o solo el nombre si el id es lo mismo (o lo mismo que `alt`, el nombre de la escena cuando `name` es el traducido).
// Con la bandera false, exactamente la expresion de antes. -> el texto
function fvObjTitle(name, id, alt) {
   if (FV_OBJ.NAME_DEDUP === false) return name + (id && id !== alt && id !== name ? "  ·  " + id : "");
   var nm = fvObjCanonName(name, id);
   if (fvObjTitleAlias(nm, id).length > 0) return nm;      // (N3c) el titulo es solo la NGC / IC; la Sharpless va a la linea pequena
   return nm + (id && !fvObjSameDesig(id, alt) && !fvObjSameDesig(id, name) ? "  ·  " + id : "");
}
// (N3c, 20-nov; FV_OBJ.TITLE_NGCIC) la designacion que NO va en el titulo: el id (Sharpless) de una nebulosa cuyo titulo es una NGC / IC. "" = nada que mover (el titulo sigue como de siempre). Puro
function fvObjTitleAlias(name, id) {
   if (FV_OBJ.TITLE_NGCIC === false || FV_OBJ.NAME_DEDUP === false || !name || !id) return "";
   var rn = fvObjDesigRank(name);
   return ((rn === 2 || rn === 3) && fvObjDesigRank(id) === 5 && !fvObjSameDesig(id, name)) ? fvObjDesigNorm(id) : "";
}
// (N13, 20-nov; FV_OBJ.BG_HERO) el protagonista dibujado de una foto SIN nebulosa de catalogo (scene.nebula.background: la capa se llama «Background nebulosity»): el indice del objeto de scene.objects que es el
// protagonista (objects[i].hero, no la nebulosa principal ni una estrella / exoplaneta, que tienen su seleccion propia). -1 = no aplica (hay nebulosa de catalogo, no hay protagonista dibujado, bandera a false). Puro
function fvNebBgHero(scene) {
   if (FV_OBJ.BG_HERO === false || !scene || !scene.nebula || scene.nebula.background !== true || !scene.objects) return -1;
   for (var i = 0; i < scene.objects.length; ++i) { var o = scene.objects[i]; if (o && o.hero === true && !o.main && o.type !== "star" && o.type !== "exoplanet") return i; }
   return -1;
}
// la mejor designacion de una lista [{ name, src }] YA ordenada por preferencia de fuente (la local primero): la de menor rango; a igual rango, la primera. -> el elemento o null
function fvObjBestDesig(list) {
   var best = null, br = 99;
   for (var i = 0; list && i < list.length; ++i) {
      var nm = fvObjDesigNorm(list[i].name); if (!nm) continue;
      var rk = fvObjDesigRank(nm); if (rk < br) { br = rk; best = list[i]; }
   }
   return best;
}
// separacion (arcmin) de dos posiciones ICRS en grados (plano tangente: vale para las decenas de arcmin de aqui)
function fvObjSepArcmin(ra1, dec1, ra2, dec2) {
   var dr = (ra1 - ra2) * Math.cos((dec1 + dec2) * 0.5 * Math.PI / 180), dd = dec1 - dec2;
   if (Math.abs(ra1 - ra2) > 180) dr = (360 - Math.abs(ra1 - ra2)) * Math.cos((dec1 + dec2) * 0.5 * Math.PI / 180);
   return 60 * Math.sqrt(dr * dr + dd * dd);
}
// ¿son a y b ({ ra, dec, size (arcmin) }) el mismo objeto? Tamaños comparables (el menor, al menos SAME_RATIO del mayor) y centros a menos de SAME_SEP × el radio del mayor
function fvObjSameObject(a, b) {
   if (!a || !b || !(a.size > 0) || !(b.size > 0) || !isFinite(a.ra) || !isFinite(b.ra)) return false;
   var big = Math.max(a.size, b.size), small = Math.min(a.size, b.size);
   if (small < FV_OBJ.SAME_RATIO * big) return false;
   return fvObjSepArcmin(a.ra, a.dec, b.ra, b.dec) <= FV_OBJ.SAME_SEP * 0.5 * big;
}
// ---------------------------------------------------------------------------
// (E2b, 17-nov) EL PROTAGONISTA DE LA FOTO (puro; node lo ejecuta: tests/_e2b/fv_e2b_node.js). Medido y propuesto en docs/encargos-17nov/E1.md §7; resultado en E2b.md.
// Nino fotografio UN objeto; FieldVoyager le daba la primera nebulosa de la lista (la de mayor huella) y el Tour no pasaba por ningun objeto. El protagonista P es, de TODOS los candidatos
// (objetos dibujados, la nebulosa principal y las demas de la lista de nebulosas del campo), el VISIBLE de mayor  min(f, 1) × (1 − q) × prior  con  q ≤ Q_MAX  y  f ≥ F_MIN, donde
//    f = diametro de catalogo / lado corto de la foto · q = distancia del centro del objeto al centro de la foto / mitad del lado corto · prior = 1, o PRIOR_CLUSTER para un cumulo.
// Si ninguno cumple, el mas centrado con q ≤ Q_FALLBACK (una planetaria de 0,3′: NGC 2392, f 0,02); si tampoco, nadie (campo estelar puro, Collinder 34: todo como hoy).
// Constantes y de donde salen: F_MIN 0,08 y Q_MAX 0,5 = las de E1 §7 (a partir de las 14 fotos: lo que un astrofotografo llama «el objeto» ocupa ≥ 8 % del lado corto y esta en la mitad central);
// Q_FALLBACK 0,3 = E1 §7 (NGC 2392 q 0,15, el resto del campo > 0,3); PRIOR_CLUSTER 0,35 = ELECCION de E1, validada en E2b con los candidatos REALES de las 14 fotos (tests/_e2b/e2b_prior_sweep.js, E2b.md §3): con el prior
// entre 0,05 y 0,5 las 14 fotos eligen EXACTAMENTE lo mismo; desde 0,6 gana en Tulip el cumulo NGC 6871 (f 0,22 q 0,46) sobre la Tulipan (f 0,098 q 0,39). Solo Tulip la fija por arriba; por abajo no la fija ninguna foto (un
// cumulo con prior bajo solo gana si no hay otra cosa: Pleyades, M 45, sin mas candidato). Margenes medidos de las otras: F_MIN 0,10 perderia la Tulipan (f 0,098: es un margen estrecho) y Q_MAX 0,4 perderia IC 2118 en Witch (q 0,417).
// Banderas (false = lo de antes, cada una): ON = no hay protagonista (todo como antes) · CAT_DIST = una nebulosa sin distancia en SIMBAD pero con ella en la lista del campo (Sh 2-101: 8 806 a.l. de WISE)
// usa esa y no la SUPUESTA · FIRST = el protagonista es la 1.ª fila de MIRABILIA · TOUR = la ultima parada del Tour es el protagonista, con su hueco reservado · LAYER = si el protagonista es una nebulosa
// de la lista que no es la principal (IC 2118 en Witch) pasa a ser la principal (nombre, tipo y distancia de catalogo) · LAYER_TWIN = lo mismo cuando es un objeto dibujado (M 42, Sh 2-101) cuya
// gemela de la lista (Sh 2-281, Sh 2-101) puede ser la principal de las capas · NEB_FOOT = la principal promovida se encuadra con el contorno de la lista (OpenNGC-Outlines), no con el de la foto ·
// NEB_VIS = una nebulosa de la lista sin objeto dibujado solo es candidata si se ve (contraste de su huella con el resto del campo, como fvMiraExtended).
// CONTOUR_CLEAN = con un protagonista dibujado, el contorno de la capa (scene.nebula.contour) se mide sobre la foto SIN el (la fuente de las capas), no sobre la que lo lleva: en Caldwell 5 el «contorno de la capa» era el de IC 342 (centro a 3 px, radio 2 505 frente a 2 460).
var FV_HERO = { ON: true, F_MIN: 0.08, Q_MAX: 0.5, Q_FALLBACK: 0.3, PRIOR_CLUSTER: 0.35, CAT_DIST: true, FIRST: true, TOUR: true, LAYER: true, LAYER_TWIN: true, NEB_FOOT: true, NEB_VIS: true, NEB_TEST_MAX: 3, CONTOUR_CLEAN: true };
// (17-nov-2026, F34; defectos F3 y F4 de la llegada al protagonista, docs/encargos-17nov/F34.md) De fabrica encendido; ON false = exactamente lo de antes.
//   MARK = el marcador de seleccion (las esquinas doradas, fvCardAnchor) cae en el CENTRO DEL CONTORNO con que se encuadra el objeto (o.frame.pos: el centroide de la mascara; la nebulosa
//     principal, el centro de su contorno), no en la posicion de catalogo (o.pos; en la principal [0, 0, distancia] = el centro de la FOTO): en Witch el centro del contorno de IC 2118 esta
//     a 1 100 px del centro de la foto y el marcador caia fuera de la nebulosa.
//   FIT  = (solo con el laboratorio de vuelo, que es el producto) la llegada pone el objeto en el centro de la parte de la pantalla que la ficha NO tapa y a la distancia en que su contorno
//     entero cabe ahi: antes el laboratorio miraba al centro del contorno (objeto en el centro de la pantalla; la ficha, que ocupa del 61 % al 98 % del ancho, mordia su lado derecho)
//     aunque el ajuste de distancia (fvObjFrameFit) contaba con el tercio. Constantes: CARD_L = borde izquierdo de la ficha (fraccion del ancho; fvCardPaint: x0 = W − 470·k − 26·k con
//     k = W/1280, o sea 1 − 496/1280); GAP = aire entre la huella y la ficha; VMARGIN = fraccion del alto que se usa (la placa DATOS y la barra de abajo se comen el resto); MARGIN_MIN = margen
//     del contorno si con FRAME_MARGIN no cabe; ALL = tambien los demas objetos (de fabrica solo el protagonista: o.hero, o la principal promovida).
var FV_F34 = { ON: true, MARK: true, FIT: true, ALL: false, CARD_L: 1 - 496 / 1280, GAP: 0.02, VMARGIN: 0.92, MARGIN_MIN: 1.0 };
// (17-nov-2026, F9; docs/encargos-17nov/F9.md) LA LLEGADA A LA NEBULOSA PRINCIPAL DE SIEMPRE (protagonista src «main»: Rosette, Soul, IC 1396, Pleiades). De fabrica encendido; ON false = exactamente lo de antes.
//   MAIN = la ULTIMA parada del Tour de esas fotos pasa de la parada «nebula» a la fila principal de MIRABILIA (objeto «main», el mismo camino que la principal promovida de Witch): CAUSA medida en
//     tests/_f9 — la parada «nebula» llega a hw / tan(30°) + grosor/2 (fvArriveDist), la distancia a la que la FOTO ENTERA llena un campo de 60°, pero con el laboratorio la pantalla estira lo
//     lateral S veces (S 9,6-11,2 en estas fotos) y el campo lateral real es 2·atan(tan(25°)/S): a 370 a.l. de la lamina de Rosette la pantalla ve 36 a.l. de los 387 de la foto (un parche gris liso, sin la forma).
//     Por la fila principal se usa su CONTORNO medido (fvObjFrameFit con S), la distancia que lo enseña entero y (F34) a la izquierda de la ficha. Solo con contorno medido; si el contorno ES la foto (whole: Soul, Pleiades) fvObjFrameFit lo trata con su modo «whole» (centrado, la parte limpia de la foto entera), que SI cuenta con S.
//   (FALLBACK, el encuadre centrado cuando ni sin margen cabe junto a la ficha, se QUITO el 19-nov-2026, N7b: ninguna foto real lo activaba; docs/encargos-19nov/N6-N7.md §6 y N2b-N7b-N8.md)
var FV_F9 = { ON: true, MAIN: true };
// (19-nov-2026, N4; docs/encargos-19nov/N4-N5.md) LIMITE DE AMPLIACION en la llegada al protagonista. La Tulipan (contorno de r 108 px en una foto de 6 248) llegaba ENTERA pero a 2,6 px de pantalla por px de foto (ampliada en exceso:
//   el ajuste de distancia solo pide que el contorno quepa, y un contorno pequeño en la foto llena la zona libre de ficha a una ampliacion enorme). Con ON, si a la distancia ajustada la ampliacion
//   (px de pantalla por px de la foto, horizontal) pasa de MAX, la llegada se retrasa a la distancia mas corta que la deja en MAX (el objeto ocupa menos pantalla). Solo el protagonista con contorno medido que no es la foto entera;
//   lo que ya no pasa de MAX no cambia (0 pixeles distintos). false = lo de antes.
//   MAX: ELECCION nuestra (1,5: Nino, 19-nov) en px de la vista REAL del dialogo a 1920 x 1080 (REF_W = 1377 px de ancho, medido: view 1377 x 918); el ajuste calcula con FIT_VW (1280), asi que la ampliacion
//   del modelo se multiplica por REF_W / FIT_VW. SCAN: muestras (en log de la distancia) entre la distancia ajustada y la maxima para buscar la mas corta que cumple.
var FV_N4 = { ON: true, MAX: 1.5, REF_W: 1377, SCAN: 24 };
// (19-nov-2026, N4b; docs/encargos-19nov/N4b.md) EL «VELO GRIS» DE LA TULIPAN CON FV_N4. Medido (tests/_n4b): no entra nada nuevo al alejarse: la Via Lactea de fondo (Add, azulada, direcciones reales) y el
//   pedestal de cielo de las capas estaban ya en la llegada de antes, pero la nebulosa, a 2,6 px por px, llenaba la pantalla y los tapaba. La Via Lactea esta anclada a la PANTALLA (cielo en el infinito), no a
//   la foto: al alejarse la camara el mismo trozo de foto (la corona 1,0-1,6 del contorno) cae sobre una zona mas brillante del cielo (+10 niveles de luminancia, R−B 2,8 → −0,1) y la nebulosa, mas pequeña,
//   ya no lo cubre. MW: la Via Lactea de fondo se atenua a esa fraccion (1 = como antes) cuando la llegada al protagonista la ha alejado FV_N4 (o._arrFit.mode «+mag»): a partir de FAR × la distancia de llegada
//   hacia fuera no se toca, con rampa suave hasta ella. 0,65 = la que devuelve a la corona su nivel de la llegada de antes (medido: 0,60-0,67). ON = false o MW = 1: la de antes (bit a bit).
var FV_N4B = { ON: true, MW: 0.65, FAR: 3 };
// la fraccion de Via Lactea que se pinta en este punto (1 = toda). Solo cerca de un protagonista cuya llegada ha alejado FV_N4: d <= v → MW; d >= FAR × v → 1
function fvN4bMwK(scene, camPos) {
   if (!FV_N4B.ON || FV_N4B.MW >= 1 || !scene || !scene.objects || !camPos) return 1;
   var O = scene.objects, k = 1, i;
   for (i = 0; i < O.length; ++i) {
      var o = O[i], af = o && o._arrFit;
      if (!af || !o.frame || !o.frame.pos || String(af.mode).indexOf("+mag") < 0 || !(af.v > 0)) continue;
      var d = Math.sqrt(Math.pow(camPos[0] - o.frame.pos[0], 2) + Math.pow(camPos[1] - o.frame.pos[1], 2) + Math.pow(camPos[2] - o.frame.pos[2], 2));
      var t = 1 - fvSmooth((d / af.v - 1) / Math.max(1e-6, FV_N4B.FAR - 1)), kk = 1 - (1 - FV_N4B.MW) * t;
      if (kk < k) k = kk;
   }
   return k;
}
function fvF9Main(scene, o) {
   return !!(FV_F9.ON && FV_F9.MAIN && o && o.main === true && scene && scene.hero && scene.hero.src === "main" && o.frame && o.frame.pos);
}
// (19-nov-2026, N6; docs/encargos-19nov/N6-N7.md) LA NEBULOSA ELEGIDA POR CUALQUIER CAMINO. F9 arreglo la llegada de la ULTIMA parada del Tour (la fila principal, con su contorno y S). Pero la seleccion
// {kind:"nebula"} (el Tour de una foto sin protagonista, un clic o doble clic en la nebulosa, una camara de ruta hacia ella, el elemento «nebula» de MIRABILIA cuando no hay objetos de C) seguia
// llegando por fvArriveDist = «la foto ENTERA llena 60°», que con el laboratorio no cuenta con el estiramiento lateral S (Collinder 34: S 55, camara a 131 a.l. de la lamina de IC 1848 y 0 % de la foto en
// pantalla). De fabrica encendido; ON false = exactamente lo de antes.
//   DIST = con el laboratorio de vuelo, la seleccion «nebula» apunta al CENTRO DEL CONTORNO de la fila principal y llega a la distancia con que esa fila se encuadra (fvObjFrameFit: S, F34, F9), o sea la
//     MISMA llegada que si se hubiese elegido la fila principal de MIRABILIA (fvSelPos y fvArriveDist de fv_pilot.js; una sola llegada por foto, no dos). Solo con contorno medido (frame.pos) y la fila
//     principal dibujada; sin ella, lo de antes.
//   AIM  = la fila principal (con contorno) cuenta como protagonista para F34 (fvF34IsHero): la nave llega desplazada y el objeto entero queda a la izquierda de la ficha, tambien cuando el protagonista
//     de la foto es OTRO objeto (la nebulosa principal sigue siendo lo que se pidio al elegirla por su fila o por clic)
//   MARK = el marcador de seleccion de una seleccion «nebula» cae en el centro del contorno (fvCardAnchor), no en el punto de pantalla donde se hizo clic / se eligio (en el Tour, el centro de la vista)
//   WHOLE = una escena SIN fila principal con contorno (Caldwell 5, Orion, M 82... el protagonista es un objeto dibujado y la nebulosa de fondo no tiene fila) llega a su lamina por la misma cuenta que una
//     nebulosa que ES la foto (modo «whole» de fvObjFrameFit): la distancia MENOR en que el ancho limpio de la foto cabe en pantalla CON S (fvN6WholeDist), no la de la foto en 60° sin S (Caldwell 5: 161 a.l. de la lamina, 0 % de la foto)
var FV_N6 = { ON: true, DIST: true, AIM: true, MARK: true, WHOLE: true };
// (19-nov-2026, N2b; docs/encargos-19nov/N2b-N7b-N8.md) LA FICHA NO TAPA LA NEBULOSA QUE ES LA FOTO. En las llegadas «whole» (el contorno de la fila principal ES la foto: Soul, Pleiades, Collinder 34) y en la lamina
// entera de N6.WHOLE (Caldwell 5, M 82, NGC 3184) la nebulosa llenaba la pantalla CENTRADA y la ficha, que ocupa del 61 % al 98 % del ancho, le tapaba el 3-12 % (Soul 3-5, Pleiades 8-12, Collinder 34 8; PixInsight y web). Con ON y
// WHOLE la parte limpia de la foto se encuadra como F34 encuadra un objeto: ENTERA en la zona que la ficha no tapa (fvF34Free) y la nave llega desplazada (fvF34Aim > 0 tambien con frame.whole); la llegada es mas lejana (≈ 1/libre).
//   SHEET = tambien la lamina entera de N6.WHOLE (Caldwell 5, M 82, NGC 3184: el doble clic / la ruta a la nebulosa de fondo, N8); false = esas tres vuelven a llegar centradas (la galaxia pequena ocupa menos al alejarse).
//   MARGIN = margen sobre la parte limpia de la foto (kc de fvLayerCleanK0) al meterla en la zona libre. ELECCION medida (19-nov): con 1,0 el ajuste subestima el ancho REAL de la parte limpia un 13-15 % (Witch 0,681 y Tulip 0,673 del ancho de
//     la vista contra 0,5925 pedido: la ficha le tapaba el 2 %), el campo del viaje de prueba no es el de la llegada con la mirada girada; 1,2 lo cubre. En las que llegan al tope (0,97 de casa: Soul, Pleiades, Collinder 34, M 82...) no cambia nada. false (ON o WHOLE) = lo de antes (centrada, 98 %).
var FV_N2B = { ON: true, WHOLE: true, SHEET: true, MARGIN: 1.2 };
function fvN2bWhole() { return !!(FV_N2B.ON && FV_N2B.WHOLE); }
function fvN2bSheet() { return !!(FV_N2B.ON && FV_N2B.WHOLE && FV_N2B.SHEET); }
// (19-nov-2026, N2c; docs/encargos-19nov/N2c.md) FUNDIR EL BORDE DE LA FOTO. Con N2b la llegada aleja la foto y su RECTANGULO se ve (Soul, Pleiades, Collinder 34, M 82): medido en el fotograma (tests/_n2c), el cielo de la
//   foto estirada (nivel ~36 de 255 en Soul) cae al del espacio sintetico (~10) por una rampa de ~90 px que empieza ~85 px por dentro del canto (el borde del build, FV_BUILD.EDGE 0,18, por el suave de las capas, FV_PAINT.EDGE_SOFT 0,10 +
//   EDGE_WOB 0,07, del lado mayor): un velo gris claro de ~26 niveles con borde definido. Una rampa mas ancha no basta por RESTA del cielo (rodilla); por PRODUCTO si: el cielo que queda es  cielo × (1 − rem) × ex × f  (ex y f = los
//   dos bordes de siempre) con  rem = SKY · (1 − suave(d / DB))  y d = distancia al canto MAS CERCANO en fracciones del LADO MAYOR de la foto (min suave de orden 4: sin la arista de las diagonales). Medir en el lado mayor y no en
//   «radio normalizado» da la misma anchura de banda en px en los cuatro cantos (con el radio normalizado, el canto corto salia mas empinado). rem = 0 donde d >= DB: ahi las capas son EXACTAMENTE las de antes.
//   Lo que SOBRE-sale del cielo (la nebulosa) se queda como estaba salvo CONT: el contenido se atenua (1 − CONT · rem) (0 = nada; para las fotos llenas de nebulosa, cuyo borde es la propia nebulosa cortada).
//   Solo se pinta cuando el borde de la foto ENTRA en pantalla (kE de FVPainter.photoQuad, rampa del 4 % del ancho): las llegadas con la foto fuera de pantalla (Rosette, IC 1396) usan las capas de siempre.
//   ON = false → exactamente lo de antes (no se crea el juego de capas nuevo). DB = ancho de la banda en fracciones del lado mayor. SKY = fraccion del pedestal que se quita en el canto (1 = todo). PED = percentil del pedestal
//   por canal del total de las capas (0,25 = el de FVPainter.skyPed). Las capas se hornean UNA vez al crear el pintor: la bandera hay que ponerla ANTES de crearlo. Gemelo web: FW_N2C (web/fw_gl.js, n2cSub).
//   SHOW = [a, b]: cuanto ha de ENTRAR el borde de la foto en pantalla (fraccion del ancho de la vista, el canto que mas entra) para que el juego nuevo se use: peso 0 por debajo de a, 1 por encima de b (suave en medio). Con kE solo (4 %)
//     tambien se atenuaba la periferia en IC 1396, cuya foto llena la pantalla y solo deja ver su canto derecho a 9 % del ancho: sin ganancia visible y media 6,7 niveles de diferencia en toda la imagen. Soul, Pleiades, Collinder 34... entran 31 %.
var FV_N2C = { ON: true, DB: 0.28, SKY: 1, CONT: 1, PED: 0.25, SHOW: [0.12, 0.25] };
// el peso del juego de capas nuevo segun lo que ENTRA el canto de la foto en pantalla (mIn = fraccion del ancho de la vista, el canto que mas entra): 0 por debajo de SHOW[0], 1 por encima de SHOW[1]
function fvN2cShowK(mIn) { var sh = FV_N2C.SHOW; return fvSmooth((mIn - sh[0]) / Math.max(1e-6, sh[1] - sh[0])); }
// la fraccion rem del pedestal que se quita en el punto (qx, qy) ∈ [0, 1]² de la foto (ax = ancho / lado mayor, ay = alto / lado mayor de la foto: uno de los dos es 1)
function fvN2cRem(qx, qy, ax, ay) {
   var dx = Math.max(1e-4, Math.min(qx, 1 - qx) * ax), dy = Math.max(1e-4, Math.min(qy, 1 - qy) * ay), a2 = dx * dx, b2 = dy * dy;
   var d = 1 / Math.sqrt(Math.sqrt(1 / (a2 * a2) + 1 / (b2 * b2)));   // min suave de orden 4: <= min(dx, dy), sin arista en las diagonales
   return FV_N2C.SKY * (1 - fvSmooth(d / Math.max(1e-6, FV_N2C.DB)));
}
// el pedestal de cielo de la FOTO que forman las capas: percentil PED por canal del TOTAL (suma de las capas por pixel) en el INTERIOR (a mas de `e` px del canto: alli el borde del build aun no oscurece), muestreado cada `stride` pixeles.
//   (Las capas NO se pueden tratar de una en una: el pedestal esta repartido entre todas por los pesos del build, y el percentil de cada una sale 0: medido en Soul, 8 capas con p25 = 0/0/0 y media 1,1-2,4.)
function fvN2cPedestal(lp, W, H, e, stride) {
   var ch = [[], [], []], x, y, k, st = stride || 5, K = lp.length;
   for (y = Math.min(e, H >> 1); y < H - Math.min(e, H >> 1); y += st) for (x = Math.min(e, W >> 1); x < W - Math.min(e, W >> 1); x += st) {
      var t0 = 0, t1 = 0, t2 = 0, i = y * W + x;
      for (k = 0; k < K; ++k) { var p = lp[k][i]; t0 += (p >>> 16) & 255; t1 += (p >>> 8) & 255; t2 += p & 255; }
      ch[0].push(t0); ch[1].push(t1); ch[2].push(t2);
   }
   return ch.map(function(a) { a.sort(function(u, v) { return u - v; }); return a.length ? a[Math.floor(FV_N2C.PED * (a.length - 1))] : 0; });
}
// quita de las capas lp (K arrays Uint32 ARGB de W × H, EN SU SITIO, aun SIN el borde suave del pintor) la fraccion rem(x, y) del pedestal de cielo del TOTAL de cada pixel, repartida entre las capas
//   en proporcion a lo que cada una lleva (los pesos del build no cambian). cielo del pixel = min(total, pedestal × ex), con ex el borde del build (FV_BUILD.EDGE = edgeFrac del lado mayor, suave² por eje: las capas
//   ya vienen oscurecidas hacia el canto); lo que SOBRE-sale del cielo (la nebulosa) queda como estaba. -> el pedestal [r, g, b] usado
function fvN2cLayersApply(lp, W, H, edgeFrac) {
   var K = lp.length, e = Math.max(4, Math.round(edgeFrac * Math.max(W, H))), ped = fvN2cPedestal(lp, W, H, e), cont = fvClamp(FV_N2C.CONT, 0, 1), x, y, k, c;
   var exx = new Float32Array(W), exy = new Float32Array(H);
   for (x = 0; x < W; ++x) { var vx = fvSmooth(Math.min(x, W - 1 - x) / e); exx[x] = vx * vx; }
   for (y = 0; y < H; ++y) { var vy = fvSmooth(Math.min(y, H - 1 - y) / e); exy[y] = vy * vy; }
   var tot = [0, 0, 0], sc = [1, 1, 1], S = Math.max(W, H), ax = W / S, ay = H / S;
   for (y = 0; y < H; ++y) {
      var qy = (y + 0.5) / H, row = y * W;
      for (x = 0; x < W; ++x) {
         var rem = fvN2cRem((x + 0.5) / W, qy, ax, ay);
         if (rem <= 0) continue;
         var i = row + x, ex = exx[x] * exy[y];
         tot[0] = tot[1] = tot[2] = 0;
         for (k = 0; k < K; ++k) { var p = lp[k][i]; tot[0] += (p >>> 16) & 255; tot[1] += (p >>> 8) & 255; tot[2] += p & 255; }
         var any = false;
         for (c = 0; c < 3; ++c) { var sky = Math.min(tot[c], ped[c] * ex) * rem; sc[c] = tot[c] > 0 ? (tot[c] - sky) * (1 - cont * rem) / tot[c] : 1; if (sc[c] < 1) any = true; }
         if (!any) continue;
         for (k = 0; k < K; ++k) {
            var q = lp[k][i];
            lp[k][i] = (0xff000000 | (Math.round(((q >>> 16) & 255) * sc[0]) << 16) | (Math.round(((q >>> 8) & 255) * sc[1]) << 8) | Math.round((q & 255) * sc[2])) >>> 0;
         }
      }
   }
   return ped;
}
// el indice de la fila principal de MIRABILIA con contorno medido (la que representa a la nebulosa de las capas) con el laboratorio activo; -1 si no hay (lo de antes)
function fvN6Main(scene) {
   if (!FV_N6.ON || !scene || !scene.objects || typeof FV_OBJ === "undefined" || !FV_OBJ.FRAME) return -1;
   if (typeof FV_LAB === "undefined" || FV_LAB.ON !== true) return -1;
   for (var i = 0; i < scene.objects.length; ++i) { var o = scene.objects[i]; if (o && o.main === true) return (o.frame && o.frame.pos) ? i : -1; }
   // sin fila principal porque la nebulosa de las capas ES el protagonista dibujado (hero.sameAsMain: M 42 en Orion, Sh 2-101 en Tulip; fv_build.js fvObjFinalList no la repite): su fila, la del objeto
   if (scene.hero && scene.hero.sameAsMain === true && scene.hero.id) for (var j = 0; j < scene.objects.length; ++j) { var oj = scene.objects[j]; if (oj && oj.id === scene.hero.id) return (oj.frame && oj.frame.pos) ? j : -1; }
   return -1;
}
function fvN6Hero(o) { return !!(FV_N6.ON && FV_N6.AIM && o && o.main === true && o.frame && o.frame.pos); }
// el protagonista de la foto: el objeto marcado hero, o la fila principal si el protagonista es la nebulosa de la lista promovida (la misma regla que fvTourPick) o (F9) la principal de siempre con contorno
// o (N6) la fila principal con contorno
function fvF34IsHero(scene, o) { return !!(o && (o.hero === true || (o.main === true && scene && scene.hero && scene.hero.src === "neb") || fvF9Main(scene, o) || fvN6Hero(o))); }
// fraccion del ancho de pantalla que deja libre la ficha (a su izquierda), con su aire
function fvF34Free(W) {
   var k = (W > 0 && typeof fvHudK === "function") ? fvHudK(W) : 1, cardL = (W > 0 && typeof fvHudK === "function") ? 1 - 496 * k / W : FV_F34.CARD_L;
   return Math.max(0.3, cardL - FV_F34.GAP);
}
// c = cuanto se desplaza el objeto a la izquierda del centro, en fraccion del medio campo (tan): el centro de la zona libre esta en free/2 del ancho -> c = 1 − free. 0 = sin encuadre nuevo
function fvF34Aim(scene, o, W) {
   if (!FV_F34.ON || !FV_F34.FIT || !FV_OBJ.FRAME || !o || !o.frame || !o.frame.pos || (o.frame.whole && !fvN2bWhole())) return 0;
   if (typeof FV_LAB === "undefined" || FV_LAB.ON !== true) return 0;
   if (o.type === "star" || o.type === "exoplanet") return 0;
   if (!FV_F34.ALL && !fvF34IsHero(scene, o)) return 0;
   return 1 - fvF34Free(W || FV_OBJ.FIT_VW);
}
function fvHeroScore(f, q, prior) { return Math.min(f, 1) * (1 - q) * prior; }
// cands: [{ id, src: "object" | "main" | "neb", f, q, prior }] (en el orden en que se dieron: desempata). visible(c) -> bool solo se pregunta a las de src "neb" (las demas ya se ven: objeto dibujado,
// principal de las capas). -> { hero (el candidato o null), how: "score" | "fallback" | "none", ranked: [{ id, src, f, q, score, ok (cumple f y q), vis (null = no se probo) }] }
function fvHeroPick(cands, visible) {
   var R = [], i;
   for (i = 0; i < cands.length; ++i) { var c = cands[i]; R.push({ c: c, k: i, score: fvHeroScore(c.f, c.q, c.prior), ok: (c.f >= FV_HERO.F_MIN && c.q <= FV_HERO.Q_MAX), vis: null }); }
   function vis(r) { if (r.c.src !== "neb" || !visible || FV_HERO.NEB_VIS === false) return true; if (r.vis === null) r.vis = !!visible(r.c); return r.vis; }
   var ord = R.slice().sort(function(a, b) { return (b.score - a.score) || (a.k - b.k); }), hero = null, how = "none", tested = 0;
   for (i = 0; i < ord.length && !hero; ++i) {
      if (!ord[i].ok) continue;
      if (ord[i].c.src === "neb") { if (++tested > FV_HERO.NEB_TEST_MAX) continue; }
      if (vis(ord[i])) { hero = ord[i].c; how = "score"; }
   }
   if (!hero) {
      var near = R.filter(function(r) { return r.c.q <= FV_HERO.Q_FALLBACK; }).sort(function(a, b) { return (a.c.q - b.c.q) || (a.k - b.k); });
      for (i = 0; i < near.length && !hero; ++i) if (vis(near[i])) { hero = near[i].c; how = "fallback"; }
   }
   return { hero: hero, how: how, ranked: ord.map(function(r) { return { id: r.c.id, src: r.c.src, f: r.c.f, q: r.c.q, prior: r.c.prior, score: r.score, ok: r.ok, vis: r.vis, visInfo: r.c.visInfo || null }; }) };
}
// la galaxia de OpenNGC (filas { id, m, ra, dec, maj }, de cshGalaxySizes().byKey sin repetidos) en esa posicion: las filas a menos de su tolerancia max(15″, 10 % de su eje mayor) y, de ellas, la de MENOR
// SEPARACION. (H-1, 17-nov, revision de Codex) Antes ganaba la de menor separacion / tolerancia, y una galaxia GRANDE (tolerancia amplia) algo mas lejos le quitaba el nombre a la identificacion correcta mas
// cercana (NGC 1 a 10″ de eje 1′ frente a NGC 2 a 20″ de eje 10′ devolvia NGC 2: el objeto salia rotulado con el nombre de OTRO). Ahora, si hay mas de una fila dentro de tolerancia y la mejor no es CLARAMENTE
// la mas cercana (la segunda a menos de AMBIG_K × su separacion), la identificacion es ambigua y no se renombra (""). AMBIG_K = 2: ELECCION nuestra; NGC 3184 (a 2″, sola en su tolerancia) sigue siendo NGC 3184.
// -> la designacion («M 82» si tiene numero de Messier, si no «NGC n» / «IC n») o ""
function fvObjOpenNgcDesig(rows, ra, dec) {
   var best = null, bs = 1e9, second = 1e9, AMBIG_K = 2;
   for (var i = 0; rows && i < rows.length; ++i) {
      var r = rows[i]; if (Math.abs(r.dec - dec) > 0.3) continue;      // 18′: mas que cualquier tolerancia
      var sep = fvObjSepArcmin(ra, dec, r.ra, r.dec) * 60, tol = Math.max(15, 0.1 * r.maj * 60);
      if (sep > tol) continue;
      if (sep < bs) { second = bs; bs = sep; best = r; } else if (sep < second) second = sep;
   }
   if (!best) return "";
   if (second < AMBIG_K * bs) return "";      // otra fila dentro de tolerancia y no claramente mas lejos: ambiguo, no se renombra
   return (best.m && String(best.m).length > 0) ? "M " + String(best.m).replace(/^0+/, "") : fvObjDesigNorm(best.id);
}
// ---------------------------------------------------------------------------
// (21-nov-2026, N-galaxias-warp; docs/encargos-20nov/N-galaxias-warp.md; DECISION DE NINO: «Tienes que tener la posibilidad de ir a las galaxias... cuando caiga exageradamente se vaya pero con un salto warp
// que tarde poco... dejar los saltos warp para distancias fuera de la galaxia nuestra y eliminar el selector de cine/warp»; opcion I-a2: solo las galaxias que SE DISTINGUEN en su foto)
// FV_GALT · LAS GALAXIAS QUE SE DISTINGUEN EN LA FOTO SON DESTINOS. Hasta hoy una galaxia con borron visible se perdia por tres reglas pensadas para «no llegar a un cielo negro»: el borde OSCURECIDO de las capas
// (D-a, FV_OBJ.VISIBLE_ONLY, antes de segmentar: 781 de las 1 585 candidatas de las cinco fotos de I-galaxias), el pico sobre el fondo < MIN_PEAK (F5b) y la prueba de MIRABILIA (FV_MIRA: contraste de brillo
// superficial y 30 px de diametro). Con ON, una galaxia cuya SEGMENTACION en la foto de trabajo cumple fvGaltVisible (SNR del pico sobre el fondo ≥ SNR y diametro equivalente ≥ MIN_DIAM_PX) es un objeto
// seleccionable (rotulo, ficha, MIRABILIA, clic) aunque al llegar no haya capas detras. Las que no se distinguen (pico / ruido < SEG_SNR, o un punto) siguen fuera. CAP: la llegada a una galaxia usa el limite de
// ampliacion de N4 (FV_N4.MAX px de pantalla por px de foto): una galaxia de 20 px no se enseña a 30× (un borron), se llega mas lejos y ocupa lo que ocupa en la foto. MAX: tope de galaxias rescatadas por foto (las de mas
// SNR × diametro); MAX_SEG: tope de segmentaciones extra del borde (cada una cuesta una segmentacion); PRE_PX: eje de catalogo minimo (px de trabajo) para segmentar una del borde (si el catalogo no da tamaño, se segmenta).
// o.galt = true en el objeto rescatado (una de las tres reglas viejas lo habria quitado). false = lo de antes, bit a bit. Constantes medidas en docs/encargos-20nov/N-galaxias-warp.md (tests/_n_galt/).
var FV_GALT = { ON: true, SNR: 6, PEAK: 8, MIN_DIAM_PX: 10, RATIO: 4, RATIO_MIN_ARCMIN: 2, MAX: 8, MAX_SEG: 150, PRE_PX: 6, SCORE_PEN: 1.5, CAP: true };
// ¿se distingue en su foto? seg = fvObjSegment (px de trabajo: rEq radio equivalente, snr = (pico − fondo) / σ). -> { ok, why }
function fvGaltVisible(seg, sizeArcmin, catArcmin) {
   if (!seg || !seg.ok) return { ok: false, why: "not segmented" };
   // la mascara mucho mayor que el catalogo (Rigel y su halo con «2MASX J05150163»: 101′ frente a 0,23′; un ruido de 6′ con una SDSS de 0,08′) es el cielo de alrededor, no la galaxia
   if (catArcmin > 0 && sizeArcmin > Math.max(FV_GALT.RATIO * catArcmin, FV_GALT.RATIO_MIN_ARCMIN)) return { ok: false, why: "the mask (" + Number(sizeArcmin).toFixed(1) + "′) is far larger than the catalogue says (" + Number(catArcmin).toFixed(2) + "′): it is the sky around it" };
   if (!(seg.snr >= FV_GALT.SNR)) return { ok: false, why: "peak/noise " + Number(seg.snr).toFixed(1) + " < " + FV_GALT.SNR };
   if (!(seg.snr * seg.sigma >= FV_GALT.PEAK)) return { ok: false, why: "peak only " + Number(seg.snr * seg.sigma).toFixed(1) + " levels above the sky (needs " + FV_GALT.PEAK + ")" };
   if (!(2 * seg.rEq >= FV_GALT.MIN_DIAM_PX)) return { ok: false, why: "only " + Math.round(2 * seg.rEq) + " px across (needs " + FV_GALT.MIN_DIAM_PX + ")" };
   return { ok: true, why: "" };
}
// (21-nov-2026, N-galaxias-warp) FV_GWARP · EL MODO DE VIAJE LO ELIGE EL DESTINO, NO UN SELECTOR. Destino FUERA de la Via Lactea (una galaxia, un cuasar, o a mas de DIST_LY a.l.) = SIEMPRE un salto warp CORTO
// (presupuesto total T_SLOW / T_FAST s con la palanca del REGULATOR en SLOW / FAST; en el centro √(T_SLOW × T_FAST): 4,0 s con 4,5 y 3,5 —con 3,0 en FAST el asentamiento del warp (1,4-1,8 s) no cabe: c5 salia en 3,13 s—; el warp de W1 con carga, salto, Doppler y salida acortados por
// FV_W1.SCALE_ON); destino dentro de la Via Lactea = el viaje de cine de siempre. HOME: la vuelta a casa desde una galaxia (la nave llego a una galaxia y sigue junto a ella) tambien es un warp corto (el mismo
// presupuesto y los mismos efectos; el vuelo sigue siendo «home»: fl.gwHome). Con ON desaparece el selector MODUS (cabina de PixInsight y web, tecla M) y el boton «otro modo» de la ficha: un solo camino.
// P.style «spectacular» (solo lo pone una prueba o un ajuste viejo) sigue dando warp con el presupuesto de D5 (FV_V1.T_SLOW[1] / T_FAST[1]). false = lo de antes (el selector y la ficha con dos botones).
// (21-nov-2026, R8) CLASSIC: el piloto CLASICO (FV_LAB.ON false: solo pruebas, no es la navegacion de fabrica) NO convierte en warp el viaje a una galaxia: el planificador clasico del warp termina a la distancia de
// llegada del catalogo con el campo de ARRIVE_FOV (a M 82: 31 a.l. con 24,38°, 47 % del contorno en pantalla) y NO usa la ley de encuadre del cine (1 386 a.l., 0,94°, 100 %). Causa medida con
// tests/_t1/fv_t1_classic_probe.js (el destino SI es M 82; con GWARP.ON false vuelve el cine de antes). true = el warp de N tambien en el clasico (lo de la union del 20-nov, R8 en rojo). La v5 no cambia.
var FV_GWARP = { ON: true, DIST_LY: 100000, T_SLOW: 4.5, T_FAST: 3.5, HOME: true, CLASSIC: false };
function fvGwarpObjFar(o) {
   if (!o || o.type === "star" || o.type === "exoplanet") return false;
   if (o.type === "galaxy" || o.type === "quasar") return true;
   if (o.main && o.typeLabel && /galax/i.test(String(o.typeLabel.en || ""))) return true;
   return o.distLy > FV_GWARP.DIST_LY;
}
// ¿el destino sel esta fuera de la Via Lactea? (sin nada que lo diga: false = cine)
function fvGwarpSelFar(P, sel) {
   if (!FV_GWARP.ON || !P || !P.scene || !sel) return false;
   var sc = P.scene, o = null;
   if (sel.kind === "object") o = sc.objects ? sc.objects[sel.i] : null;
   else if (sel.kind === "nebula") { var mN = (typeof fvN6Main === "function") ? fvN6Main(sc) : -1; if (mN >= 0) o = sc.objects[mN]; }
   else if (sel.kind === "star" && sc.stars && sel.i >= 0 && sel.i < sc.stars.n) return sc.stars.dEarth[sel.i] > FV_GWARP.DIST_LY;
   return fvGwarpObjFar(o);
}
// (N-galaxias-warp; FV_GALT.CAP) el limite de ampliacion de N4 tambien vale para cualquier GALAXIA con contorno medido (no solo el protagonista): una de 20 px de foto no se enseña a 30×
function fvGaltCap(o) { return !!(FV_GALT.ON && FV_GALT.CAP && o && o.type === "galaxy"); }
// ¿la nave esta (llego y sigue) junto a una galaxia? -> la vuelta a casa es un warp corto
function fvGwarpHomeFar(P) {
   if (!FV_GWARP.ON || !FV_GWARP.HOME || !P || !P.scene || !P.arrivedAt || P.arrivedAt.kind === "star") return false;
   if (!(Math.sqrt(P.cam.pos[0] * P.cam.pos[0] + P.cam.pos[1] * P.cam.pos[1] + P.cam.pos[2] * P.cam.pos[2]) > 1e-6)) return false;
   return fvGwarpSelFar(P, P.arrivedAt);
}
// ---------------------------------------------------------------------------
// (I-galaxias, 20-nov-2026; docs/encargos-20nov/I-galaxias.md) LAS GALAXIAS DE LAS BASES LOCALES DE PIXINSIGHT COMO OBJETOS DE LA FOTO.
// Las galaxias del campo salian SOLO de SIMBAD (consulta de red con cache de 30 dias); sin SIMBAD y sin cache, solo las ~10 000 de OpenNGC (M / NGC / IC). Las bases PGC (HyperLEDA, 983 261) y SGA-2020
// (383 620), de la distribucion de PixInsight, se leian ya (CabraShared `cshGalaxyLocal`, ExtendedSources `search`, sin red ni configurar nada) pero SOLO para dar tamaño y z a las de SIMBAD.
// ON: las filas de esas bases que SIMBAD no trae (sin SIMBAD: todas) entran como candidatas con la forma de un objeto de SIMBAD (`fvObjGalLocalPick`) y pasan por las MISMAS pruebas que cualquier otra galaxia
// (marco, tamaño, parte de otra, segmentacion en la foto, MIRABILIA: nada se relaja). false = lo de antes, bit a bit.
//   MIN_PX: diametro minimo (px de la foto de trabajo) del eje mayor del CATALOGO para ser candidata: la isofota 26 de SGA mide ~2× lo que se segmenta en la foto estirada (M 82: 13,7′ de catalogo, 6,1′ medidos)
//     y MIRABILIA pide ≥ FV_MIRA.MIN_DIAM_PX = 30 px medidos: 20 deja pasar todo lo que podria llegar a 30 y ahorra segmentar centenares de galaxias de unos pocos px (ELECCION nuestra, medida en I-galaxias.md)
//   MAX: tope de candidatas locales (las mayores primero): cada una cuesta una segmentacion (ELECCION nuestra)
//   DUP_FRAC / DUP_MIN_ARCSEC / DUP_MAX_ARCSEC: la fila ES una galaxia de SIMBAD si sus posiciones distan menos de DUP_FRAC × el eje mayor, entre un minimo y un maximo (el criterio de cshSameObject, 0,25 del eje,
//     con tope: la posicion de SIMBAD de una galaxia grande puede caer a decenas de ″ de la de HyperLEDA); o si comparten NOMBRE de catalogo (NGC / IC / UGC / PGC / MCG / CGCG / ESO / M)
var FV_GALLOC = { ON: true, MIN_PX: 20, MAX: 40, DUP_FRAC: 0.25, DUP_MIN_ARCSEC: 10, DUP_MAX_ARCSEC: 60, SGA_PGC_TOL_ARCSEC: 15 };
// «NGC  3034», «ngc3034», «M 82», «UGC 5322», «PGC 28655», «PGC28655», «MCG +12-10-007» -> «NGC 3034», «M 82», «UGC 5322»…; cualquier otra cosa -> "" (no es una designacion de catalogo comparable)
function fvObjGalKey(s) {
   var t = String(s || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "").toUpperCase();
   var m = /^(NGC|IC|UGC|UGCA|PGC|MCG|CGCG|ESO|M)\s*0*([0-9+\-A-Z.]+)$/.exec(t);
   return m ? m[1] + " " + m[2] : "";
}
// SIMBAD o local: todas las claves de nombre de un objeto { name, names[] } -> { "NGC 3034": true, … }
function fvObjGalKeys(name, names) {
   var out = {}, k = fvObjGalKey(name), i; if (k) out[k] = true;
   for (i = 0; names && i < names.length; ++i) { k = fvObjGalKey(names[i]); if (k) out[k] = true; }
   return out;
}
// ¿es la fila (name, names[], ra, dec, major en ′) una de las galaxias `known` ([{ name, ra, dec, sizeArcmin }], las de SIMBAD)? -> "" (no), "name" o "position"
function fvObjGalDup(row, known) {
   var kr = fvObjGalKeys(row.name, row.names), i;
   for (i = 0; known && i < known.length; ++i) {
      var g = known[i], kg = fvObjGalKey(g.name), kk;
      if (kg && kr[kg]) return "name";
      if (g.names) for (kk = 0; kk < g.names.length; ++kk) { var k2 = fvObjGalKey(g.names[kk]); if (k2 && kr[k2]) return "name"; }
   }
   for (i = 0; known && i < known.length; ++i) {
      var g2 = known[i]; if (!isFinite(g2.ra) || !isFinite(g2.dec) || Math.abs(g2.dec - row.dec) > 0.1) continue;
      var big = Math.max(row.major > 0 ? row.major : 0, g2.sizeArcmin > 0 ? g2.sizeArcmin : 0);
      var tol = Math.min(FV_GALLOC.DUP_MAX_ARCSEC, Math.max(FV_GALLOC.DUP_MIN_ARCSEC, FV_GALLOC.DUP_FRAC * big * 60));
      if (fvObjSepArcmin(row.ra, row.dec, g2.ra, g2.dec) * 60 <= tol) return "position";
   }
   return "";
}
// la designacion con que se ve la fila: de todos sus nombres, la de menor rango (Messier, NGC, IC…); a igual rango la primera; si ninguna es de catalogo conocido, el nombre de la base tal cual
function fvObjGalLocalName(row) {
   var list = [], i; for (i = 0; row.names && i < row.names.length; ++i) list.push({ name: row.names[i] }); list.push({ name: row.name });
   var best = fvObjBestDesig(list); if (best && fvObjDesigRank(best.name) < 9) return fvObjDesigNorm(best.name);
   return fvObjGalKey(row.name) || fvObjDesigNorm(row.name) || (row.names && row.names.length ? fvObjDesigNorm(row.names[0]) : "");      // «PGC28655» -> «PGC 28655»
}
// LAS FILAS -> candidatas. sga, pgc: filas de cshGalaxyLocal ({ db, name, names[], ra, dec, major, minor (′), pa, circle, z, morph, mag, used }); known: galaxias de SIMBAD ya en el campo;
// o: { minArcmin (eje mayor minimo del catalogo, ′), distOf (z -> distancia de CabraShared o null; opcional), inFrame (ra, dec -> bool; opcional) }.
// SGA-2020 primero; una fila de PGC solo si NINGUNA de SGA cae a SGA_PGC_TOL_ARCSEC (es la misma galaxia). `used` (cshGalaxyLocalApply ya la casó con una de SIMBAD) o duplicada por nombre / posicion: fuera.
// -> { list: [objeto de la forma de SIMBAD con localDb], stats: { rows, used, dupName, dupPos, small, outside, sgaPgc, kept, cut } } ordenado de mayor a menor eje mayor, a lo sumo FV_GALLOC.MAX
function fvObjGalLocalPick(sga, pgc, known, o) {
   var op = o || {}, st = { rows: 0, used: 0, dupName: 0, dupPos: 0, small: 0, outside: 0, sgaPgc: 0, kept: 0, cut: 0 }, out = [], i, j;
   var sgaAll = (sga || []).filter(function(r) { return r && isFinite(r.ra) && isFinite(r.dec) && r.major > 0; });
   var sgaSorted = sgaAll.slice(0).sort(function(a, b) { return a.dec - b.dec; }), win = FV_GALLOC.SGA_PGC_TOL_ARCSEC / 3600 + 1e-6;
   var sgaKeys = {}, kk0;      // los nombres de catalogo de TODAS las filas de SGA: una de PGC con uno de ellos es la misma galaxia aunque su centro difiera mas de la tolerancia (galaxias grandes)
   for (i = 0; i < sgaAll.length; ++i) { var ks0 = fvObjGalKeys(sgaAll[i].name, sgaAll[i].names); for (kk0 in ks0) if (ks0.hasOwnProperty(kk0)) sgaKeys[kk0] = true; }
   function inSga(r) {      // una fila de SGA a menos de la tolerancia, o con el mismo nombre: la misma galaxia (busqueda binaria por declinacion)
      var kr0 = fvObjGalKeys(r.name, r.names), kq0; for (kq0 in kr0) if (kr0.hasOwnProperty(kq0) && sgaKeys[kq0] === true) return true;
      var lo = 0, hi = sgaSorted.length, mid;
      while (lo < hi) { mid = (lo + hi) >> 1; if (sgaSorted[mid].dec < r.dec - win) lo = mid + 1; else hi = mid; }
      for (var q = lo; q < sgaSorted.length && sgaSorted[q].dec <= r.dec + win; ++q) { var s = sgaSorted[q]; if (fvObjSepArcmin(r.ra, r.dec, s.ra, s.dec) * 60 <= FV_GALLOC.SGA_PGC_TOL_ARCSEC) return true; }
      return false;
   }
   var all = [];
   for (i = 0; i < sgaAll.length; ++i) all.push(sgaAll[i]);
   for (j = 0; pgc && j < pgc.length; ++j) { var rp = pgc[j]; if (rp && isFinite(rp.ra) && isFinite(rp.dec) && rp.major > 0) all.push(rp); }
   for (i = 0; i < all.length; ++i) {
      var r = all[i]; ++st.rows;
      if (r.used === true) { ++st.used; continue; }
      if (r.db !== "SGA-2020" && inSga(r)) { ++st.sgaPgc; continue; }
      if (r.major < op.minArcmin) { ++st.small; continue; }
      if (typeof op.inFrame === "function" && !op.inFrame(r.ra, r.dec)) { ++st.outside; continue; }
      var dup = fvObjGalDup(r, known); if (dup === "name") { ++st.dupName; continue; } if (dup === "position") { ++st.dupPos; continue; }
      var dist = (r.z > 0 && typeof op.distOf === "function") ? op.distOf(r.z) : null, nm = fvObjGalLocalName(r), sga1 = (r.db === "SGA-2020");
      out.push({ name: nm, ra: r.ra, dec: r.dec, otype: "G", cls: "galaxy", extragalactic: true, sizeArcmin: r.major, minArcmin: r.circle ? null : r.minor, sizePa: r.circle ? null : r.pa,
                 sizeSource: r.db, sizeRef: r.name, sizeDef: sga1 ? "isophote-26" : "d25", sizeLocal: true, z: (r.z > 0 ? r.z : null), dist: dist, mags: { V: null, B: (r.mag !== null && r.mag !== undefined && isFinite(r.mag)) ? r.mag : null, G: null, g: null, R: null, r: null },
                 catalog: r.db, localDb: r.db, names: r.names ? r.names.slice(0) : [], morph: r.morph || "" });
   }
   out.sort(function(a, b) { return (b.sizeArcmin - a.sizeArcmin) || (a.ra - b.ra); });
   if (out.length > FV_GALLOC.MAX) { st.cut = out.length - FV_GALLOC.MAX; out.length = FV_GALLOC.MAX; }
   st.kept = out.length;
   return { list: out, stats: st };
}
// ---------------------------------------------------------------------------
// LA SEGMENTACION sobre la foto SIN estrellas (Uint32Array RGB, W × H, px de trabajo).
//   (cx, cy) centro de catalogo; rCat radio de catalogo en px (o null). -> { ok, why, … } con, si ok:
//   x0, y0, w, h (el recorte = la ventana), cx, cy, area, rEq (radio equivalente √(A/π)), rMax (p98 de la distancia al centro),
//   snr, bg [r, g, b], bgL, sigma, T, alpha (Float32Array w·h, 0…1, suave y redonda), mask (Uint8Array w·h, la dura)
// La estrella central: el quitaestrellas deja un hueco (o un remiendo) en el centro; la mascara crece desde TODO el centro y se le
// rellenan los agujeros, asi que el objeto no es «la estrella» ni tiene un hueco. Bordes: mascara dura difuminada (FEATHER) y ventana
// radial que llega a 0 antes del borde del recorte: ni cantos rectos ni halo cuadrado.
// ---------------------------------------------------------------------------
function fvObjLum(p) { return (((p >>> 16) & 255) + ((p >>> 8) & 255) + (p & 255)) / 3; }
// (C4) el mismo suavizado de caja separable, sumando EXACTAMENTE los mismos terminos en el mismo orden (k = −r … r, solo los de dentro de la ventana, luego / n):
// el resultado es el mismo bit a bit. Solo calcula el rectangulo [x0,x1) × [y0,y1) (a debe valer en ese rectangulo ensanchado r, recortado a la ventana; fuera del
// rectangulo el resultado es 0). Las columnas/filas interiores van sin comprobar los bordes y la pasada de columnas recorre por filas (contiguo en memoria).
function fvObjBlurR(a, w, h, r, x0, y0, x1, y1) {
   var tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, k, s, n, o, ty0 = Math.max(0, y0 - r), ty1 = Math.min(h, y1 + r), nn = 2 * r + 1;
   for (y = ty0; y < ty1; ++y) {
      o = y * w;
      for (x = x0; x < x1; ++x) {
         s = 0;
         if (x >= r && x < w - r) {
            if (r === 1) { s += a[o + x - 1]; s += a[o + x]; s += a[o + x + 1]; } else for (k = -r; k <= r; ++k) s += a[o + x + k];
            tmp[o + x] = s / nn;
         } else {
            n = 0;
            for (k = -r; k <= r; ++k) { var xx = x + k; if (xx >= 0 && xx < w) { s += a[o + xx]; ++n; } }
            tmp[o + x] = s / n;
         }
      }
   }
   for (y = y0; y < y1; ++y) {
      var inY = (y >= r && y < h - r);
      for (x = x0; x < x1; ++x) {
         s = 0;
         if (inY) {
            if (r === 1) { s += tmp[(y - 1) * w + x]; s += tmp[y * w + x]; s += tmp[(y + 1) * w + x]; } else for (k = -r; k <= r; ++k) s += tmp[(y + k) * w + x];
            out[y * w + x] = s / nn;
         } else {
            n = 0;
            for (k = -r; k <= r; ++k) { var yy = y + k; if (yy >= 0 && yy < h) { s += tmp[yy * w + x]; ++n; } }
            out[y * w + x] = s / n;
         }
      }
   }
   return out;
}
// (C4) el MISMO suavizado con suma deslizante (O(1) por pixel en vez de O(r)). Solo para la cadena de la MASCARA de fvObjSegOnce (entrada 0/1, cuatro pasadas, r ≤ 31): ahi cada pasada
// suma valores float32 que son multiplos de 2^-42 como minimo (los no nulos valen ≥ 2^-6 en la 1.ª pasada, ≥ 2^-12 en la 2.ª ... ≥ 2^-24 en la 4.ª, porque el divisor es ≤ 63) y la suma
// es < 2^6: caben en 48 bits < 53, asi que TODAS las sumas parciales son exactas y da igual el orden: la suma deslizante vale lo mismo, bit a bit, que la directa. Con r > 31 (no ocurre:
// r = round(0,15 · rEq / 2) y rEq ≤ 0,98 × la ventana maxima) vuelve a la directa. NO usar con datos arbitrarios (la exactitud depende de esa entrada).
function fvObjBlurSlide(a, w, h, r) {
   if (r < 1) return a;
   if (r > 31) return fvObjBlurR(a, w, h, r, 0, 0, w, h);
   var tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, o, s, n, hi, sacc = new Float64Array(w);
   for (y = 0; y < h; ++y) {
      o = y * w; hi = Math.min(w - 1, r); s = 0; for (x = 0; x <= hi; ++x) s += a[o + x];
      for (x = 0; x < w; ++x) {
         n = Math.min(w - 1, x + r) - Math.max(0, x - r) + 1; tmp[o + x] = s / n;
         if (x + r + 1 < w) s += a[o + x + r + 1];
         if (x - r >= 0) s -= a[o + x - r];
      }
   }
   var yh = Math.min(h - 1, r);
   for (y = 0; y <= yh; ++y) { o = y * w; for (x = 0; x < w; ++x) sacc[x] += tmp[o + x]; }
   for (y = 0; y < h; ++y) {
      n = Math.min(h - 1, y + r) - Math.max(0, y - r) + 1; o = y * w;
      for (x = 0; x < w; ++x) out[o + x] = sacc[x] / n;
      if (y + r + 1 < h) { var o1 = (y + r + 1) * w; for (x = 0; x < w; ++x) sacc[x] += tmp[o1 + x]; }
      if (y - r >= 0) { var o2 = (y - r) * w; for (x = 0; x < w; ++x) sacc[x] -= tmp[o2 + x]; }
   }
   return out;
}
function fvObjBlur(a, w, h, r) {
   if (r < 1) return a;
   if (FV_OBJ.FAST_SEG) return fvObjBlurR(a, w, h, r, 0, 0, w, h);
   var tmp = new Float32Array(w * h), out = new Float32Array(w * h), x, y, k, s, n;
   for (y = 0; y < h; ++y) { var o = y * w; for (x = 0; x < w; ++x) { s = 0; n = 0; for (k = -r; k <= r; ++k) { var xx = x + k; if (xx >= 0 && xx < w) { s += a[o + xx]; ++n; } } tmp[o + x] = s / n; } }
   for (x = 0; x < w; ++x) for (y = 0; y < h; ++y) { s = 0; n = 0; for (k = -r; k <= r; ++k) { var yy = y + k; if (yy >= 0 && yy < h) { s += tmp[yy * w + x]; ++n; } } out[y * w + x] = s / n; }
   return out;
}
function fvObjMedian(a) { if (!a.length) return 0; var s = a.slice().sort(function(p, q) { return p - q; }); return s[s.length >> 1]; }
// (E2a) el bucle de siempre (ventana inicial, se dobla hasta whMax); fvObjSegment lo llama con el tope de siempre y, con SEG_WIDE, otra vez con el ancho si hace falta
function fvObjSegRun(px, W, H, cx, cy, rc, o, whMax) {
   var wh = Math.min(whMax, Math.max(FV_OBJ.SEG_WIN0, Math.round(FV_OBJ.SEG_WINK * rc))), last = null;
   if (cx < 0 || cy < 0 || cx >= W || cy >= H) return { ok: false, why: "outside the photo" };
   for (var att = 0; att < 5; ++att) {
      var r = fvObjSegOnce(px, W, H, cx, cy, rc, wh, o);
      last = r;
      // «no se ve» con una ventana pequeña puede ser que el anillo del fondo cae DENTRO del objeto (mas grande que la ventana): se prueba
      // con la doble; si en ninguna destaca, no se ve (sintetico de 80 px con ventana de 60: «no se ve» antes de esto, 4-nov)
      if (!r.ok) { if (wh >= whMax || r.why.indexOf("not visible") !== 0) return r; wh = Math.min(whMax, wh * 2); continue; }
      if (!r.touches) return r;
      if (wh >= whMax) { r.ok = false; r.why = "not compact (the mask reaches " + Math.round(r.rMax) + " px, the window " + wh + " px)"; return r; }
      wh = Math.min(whMax, wh * 2);
   }
   last.ok = false; last.why = "not compact"; return last;
}
function fvObjSegment(px, W, H, cx, cy, rCat, opts) {
   var o = opts || {}, rc = (rCat > 0) ? rCat : 0, whMax = Math.max(24, Math.round(0.3 * Math.min(W, H)));
   var r = fvObjSegRun(px, W, H, cx, cy, rc, o, whMax);
   // (E2a, FV_OBJ.SEG_WIDE; false = ROJO, IC 342 vuelve a «not compact») el tope de 0,3 × el lado menor no deja segmentar lo que GAL_MAX_FRAC admite (E1 §3: la mascara solo cabe hasta ~43 % del lado menor y las galaxias entran hasta el 60 %;
   // IC 342 = 58 % salia «not compact (the mask reaches 304 px, the window 404 px)»). Si la segmentacion de siempre da «not compact» Y el catalogo dice que el objeto es grande (su radio ≥ SEG_WIDE_RC × el tope de siempre: no es
   // una galaxia pequeña dentro de la luz de otra, de las que hay 60 en IC 342) se repite UNA vez con el tope ancho SEG_WH_FRAC × el lado menor (0,6, medido en E1: rMax 428 de 809). Todo lo demas da EXACTAMENTE lo de antes:
   // la primera version (el tope ancho para todos) hacia 25 veces mas lento Caldwell 5 (3,6 s → 88 s en node: las 60 galaxias pequeñas crecian hasta la ventana de 809 px) y cambiaba la ventana, luego la mascara, de M 82.
   if (FV_OBJ.SEG_WIDE !== false && !r.ok && r.why.indexOf("not compact") === 0 && rc >= FV_OBJ.SEG_WIDE_RC * whMax) {
      var wide = Math.max(24, Math.round(FV_OBJ.SEG_WH_FRAC * Math.min(W, H)));
      if (wide > whMax) r = fvObjSegRun(px, W, H, cx, cy, rc, o, wide);
   }
   return r;
}
// (C4, FAST_SEG) la luminancia (la de fvObjLum, guardada en Float32 como L de fvObjSegOnce) del rectangulo [rx0,rx1) × [ry0,ry1) de la ventana (x0, y0, w, h en px de la foto)
function fvObjLumRect(px, W, x0, y0, w, h, rx0, ry0, rx1, ry1, L) {
   for (var y = ry0; y < ry1; ++y) { var o = (y + y0) * W + x0; for (var x = rx0; x < rx1; ++x) { var p = px[o + x]; L[y * w + x] = (((p >>> 16) & 255) + ((p >>> 8) & 255) + (p & 255)) / 3; } }
}
// el elemento de indice idx de los valores ordenados de un histograma (el que dejaria a[idx] tras ordenar)
function fvObjNth(hist, idx) { var c = 0; for (var v = 0; v < hist.length; ++v) { c += hist[v]; if (c > idx) return v; } return hist.length - 1; }
var FV_OBJ_F32 = new Float32Array(1), FV_OBJ_NB4 = [[1, 0], [-1, 0], [0, 1], [0, -1]];
// (C4, FAST_SEG) el CIELO de la ventana: lo que fvObjSegOnce sacaba de ~200 000 valores del anillo [0,75 wh, wh] ordenandolos cinco veces (L, |L − mediana|, R, G, B), aqui por HISTOGRAMA:
// la suma R+G+B es entera (0…765) y L = Float32(suma / 3) es monotona en ella, asi que la mediana (el elemento n >> 1 ordenado) sale de recorrer el histograma, y la MAD tambien (|L − bg|
// de cada valor distinto, ≤ 766, ordenados con sus cuentas). Mismos valores que la ordenacion, no una aproximacion. -> { n } si hay < 30 pixeles, si no { n, bg, sigma, rgb [R, G, B] }
function fvObjRingStats(px, W, x0, y0, w, h, ccx, ccy, wh) {
   var hs = new Int32Array(766), hr = new Int32Array(256), hg = new Int32Array(256), hb = new Int32Array(256), n = 0, x, y, rin = 0.75 * wh;
   for (y = 0; y < h; ++y) {
      var o = (y + y0) * W + x0, dy = y - ccy, dy2 = dy * dy;
      for (x = 0; x < w; ++x) {
         var dx = x - ccx, rr = Math.sqrt(dx * dx + dy2);
         if (rr >= rin && rr <= wh) { var p = px[o + x], r8 = (p >>> 16) & 255, g8 = (p >>> 8) & 255, b8 = p & 255; ++hs[r8 + g8 + b8]; ++hr[r8]; ++hg[g8]; ++hb[b8]; ++n; }
      }
   }
   if (n < 30) return { n: n };
   var idx = n >> 1, f = FV_OBJ_F32, v, c;
   f[0] = fvObjNth(hs, idx) / 3; var bg = f[0], vals = [];
   for (v = 0; v < 766; ++v) if (hs[v] > 0) { f[0] = v / 3; vals.push([Math.abs(f[0] - bg), hs[v]]); }
   vals.sort(function(a, b) { return a[0] - b[0]; });
   var cum = 0, med = 0;
   for (c = 0; c < vals.length; ++c) { cum += vals[c][1]; if (cum > idx) { med = vals[c][0]; break; } }
   return { n: n, bg: bg, sigma: Math.max(0.35, 1.4826 * med), rgb: [fvObjNth(hr, idx), fvObjNth(hg, idx), fvObjNth(hb, idx)] };
}
function fvObjSegOnce(px, W, H, cx, cy, rc, wh, o) {
   var x0 = Math.max(0, Math.round(cx - wh)), y0 = Math.max(0, Math.round(cy - wh)), x1 = Math.min(W, Math.round(cx + wh) + 1), y1 = Math.min(H, Math.round(cy + wh) + 1);
   var w = x1 - x0, h = y1 - y0, n = w * h, x, y, i, ccx = cx - x0, ccy = cy - y0;
   if (w < 8 || h < 8) return { ok: false, why: "window too small" };
   // (C4) FAST_SEG: el cielo del anillo por histograma y la luminancia/suavizado solo alrededor de las semillas hasta saber si el objeto se ve (mismo resultado, ver fvObjRingStats)
   var L = null, RS = null, ann = [], aR = [], aG = [], aB = [], bg, sigma, Ls;
   if (FV_OBJ.FAST_SEG) RS = fvObjRingStats(px, W, x0, y0, w, h, ccx, ccy, wh);
   else {
      L = new Float32Array(n);
      for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
         var p = px[(y + y0) * W + x + x0]; i = y * w + x; L[i] = fvObjLum(p);
         var dx = x - ccx, dy = y - ccy, rr = Math.sqrt(dx * dx + dy * dy);
         if (rr >= 0.75 * wh && rr <= wh) { ann.push(L[i]); aR.push((p >>> 16) & 255); aG.push((p >>> 8) & 255); aB.push(p & 255); }
      }
   }
   if ((RS ? RS.n : ann.length) < 30) return { ok: false, why: "no sky around (frame edge)" };
   if (RS) { bg = RS.bg; sigma = RS.sigma; }
   else { bg = fvObjMedian(ann); var dev = ann.map(function(v) { return Math.abs(v - bg); }); sigma = Math.max(0.35, 1.4826 * fvObjMedian(dev)); }
   var rSeed = Math.max(4, 0.6 * Math.max(rc, 8)), peak = -1e9;
   if (RS) {
      var sx0 = Math.max(0, Math.floor(ccx - rSeed)), sx1 = Math.min(w - 1, Math.ceil(ccx + rSeed)), sy0 = Math.max(0, Math.floor(ccy - rSeed)), sy1 = Math.min(h - 1, Math.ceil(ccy + rSeed));
      L = new Float32Array(n);
      fvObjLumRect(px, W, x0, y0, w, h, Math.max(0, sx0 - 2), Math.max(0, sy0 - 2), Math.min(w, sx1 + 3), Math.min(h, sy1 + 3), L);
      Ls = fvObjBlurR(fvObjBlurR(L, w, h, 1, Math.max(0, sx0 - 1), Math.max(0, sy0 - 1), Math.min(w, sx1 + 2), Math.min(h, sy1 + 2)), w, h, 1, sx0, sy0, sx1 + 1, sy1 + 1);
   } else Ls = fvObjBlur(fvObjBlur(L, w, h, 1), w, h, 1);
   for (y = Math.max(0, Math.floor(ccy - rSeed)); y <= Math.min(h - 1, Math.ceil(ccy + rSeed)); ++y)
      for (x = Math.max(0, Math.floor(ccx - rSeed)); x <= Math.min(w - 1, Math.ceil(ccx + rSeed)); ++x)
         if ((x - ccx) * (x - ccx) + (y - ccy) * (y - ccy) <= rSeed * rSeed && Ls[y * w + x] > peak) peak = Ls[y * w + x];
   var snr = (peak - bg) / sigma, out = { ok: false, why: "", x0: x0, y0: y0, w: w, h: h, cx: cx, cy: cy, snr: snr, bgL: bg, sigma: sigma, wh: wh,
                                          bg: RS ? RS.rgb : [fvObjMedian(aR), fvObjMedian(aG), fvObjMedian(aB)] };
   if (!(snr >= (o.minSnr || FV_OBJ.SEG_SNR))) { out.why = "not visible in the photo (peak/noise " + snr.toFixed(1) + ")"; return out; }
   if (RS) { fvObjLumRect(px, W, x0, y0, w, h, 0, 0, w, h, L); Ls = fvObjBlur(fvObjBlur(L, w, h, 1), w, h, 1); }      // (C4) se ve: ahora si, la ventana entera
   var T = bg + Math.max(FV_OBJ.SEG_K * sigma, FV_OBJ.SEG_REL * (peak - bg)), mask = new Uint8Array(n), st = [], R2 = (0.98 * wh) * (0.98 * wh);
   out.T = T;
   // semillas: todo lo que pasa el umbral cerca del centro; crece en 8-vecindad dentro del circulo de la ventana
   for (y = Math.max(0, Math.floor(ccy - rSeed)); y <= Math.min(h - 1, Math.ceil(ccy + rSeed)); ++y)
      for (x = Math.max(0, Math.floor(ccx - rSeed)); x <= Math.min(w - 1, Math.ceil(ccx + rSeed)); ++x) {
         i = y * w + x; if (!mask[i] && Ls[i] >= T && (x - ccx) * (x - ccx) + (y - ccy) * (y - ccy) <= rSeed * rSeed) { mask[i] = 1; st.push(i); }
      }
   while (st.length) {
      var q = st.pop(), qx = q % w, qy = (q - qx) / w;
      for (var ey = -1; ey <= 1; ++ey) for (var ex = -1; ex <= 1; ++ex) {
         var nx = qx + ex, ny = qy + ey; if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
         var j = ny * w + nx; if (mask[j] || Ls[j] < T) continue;
         if ((nx - ccx) * (nx - ccx) + (ny - ccy) * (ny - ccy) > R2) continue;
         mask[j] = 1; st.push(j);
      }
   }
   // los agujeros (la estrella central quitada, un remiendo oscuro): lo que no se alcanza desde el borde sin pasar por la mascara, es objeto
   var ext = new Uint8Array(n);
   for (x = 0; x < w; ++x) { if (!mask[x]) { ext[x] = 1; st.push(x); } var b0 = (h - 1) * w + x; if (!mask[b0] && !ext[b0]) { ext[b0] = 1; st.push(b0); } }
   for (y = 0; y < h; ++y) { var l0 = y * w, r0 = y * w + w - 1; if (!mask[l0] && !ext[l0]) { ext[l0] = 1; st.push(l0); } if (!mask[r0] && !ext[r0]) { ext[r0] = 1; st.push(r0); } }
   while (st.length) {
      var q2 = st.pop(), q2x = q2 % w, q2y = (q2 - q2x) / w, nb = FV_OBJ.FAST_SEG ? FV_OBJ_NB4 : [[1, 0], [-1, 0], [0, 1], [0, -1]];      // (C4) los 4 vecinos: una constante, no 5 arrays nuevos por cada pixel exterior de la ventana
      for (var e = 0; e < 4; ++e) { var mx = q2x + nb[e][0], my = q2y + nb[e][1]; if (mx < 0 || my < 0 || mx >= w || my >= h) continue; var jj = my * w + mx; if (!ext[jj] && !mask[jj]) { ext[jj] = 1; st.push(jj); } }
   }
   var area = 0, holes = 0, dist = FV_OBJ.FAST_SEG ? new Float64Array(n) : [], nd = 0;      // (C4) con FAST_SEG un Float64Array (sort() numerico nativo, los mismos valores)
   for (i = 0; i < n; ++i) {
      if (!ext[i] && !mask[i]) { mask[i] = 1; ++holes; }
      if (mask[i]) { ++area; var ix = i % w, iy = (i - ix) / w; dist[nd++] = Math.sqrt((ix - ccx) * (ix - ccx) + (iy - ccy) * (iy - ccy)); }
   }
   if (area < 6) { out.why = "nothing above the threshold"; return out; }
   if (FV_OBJ.FAST_SEG) dist = dist.subarray(0, nd).sort(); else dist.sort(function(p1, p2) { return p1 - p2; });
   var rMax = dist[Math.min(dist.length - 1, Math.floor(0.98 * dist.length))], rEq = Math.sqrt(area / Math.PI);
   out.area = area; out.holes = holes; out.rEq = rEq; out.rMax = rMax; out.mask = mask;
   out.touches = rMax > FV_OBJ.SEG_EDGE * wh;
   // la mascara SUAVE: la dura difuminada (borde de FEATHER × rEq) por una ventana radial que muere antes del borde del recorte
   var fr = Math.max(2, Math.round(FV_OBJ.FEATHER * rEq)), m = new Float32Array(n);
   for (i = 0; i < n; ++i) m[i] = mask[i];
   // (4-nov) la mascara se ENSANCHA ~fr antes de difuminarla: sin esto el borde suave caia dentro del halo debil y lo que quedaba para las
   // capas tenia un anillo mas oscuro que el halo de fuera (nC_2392_mascara.png, columna 6, primera pasada)
   var bl = FV_OBJ.FAST_SEG ? fvObjBlurSlide : fvObjBlur;      // (C4) la misma cadena con la suma deslizante (exacta aqui, ver fvObjBlurSlide)
   var dl = bl(bl(m, w, h, Math.max(1, Math.round(fr / 2))), w, h, Math.max(1, Math.round(fr / 2)));
   for (i = 0; i < n; ++i) m[i] = (dl[i] > 0.02) ? 1 : 0;
   m = bl(bl(m, w, h, Math.max(1, Math.round(fr / 2))), w, h, Math.max(1, Math.round(fr / 2)));
   var rWin = 0.97 * wh, rRamp = Math.max(3, 0.2 * wh);
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
      var rr2 = Math.sqrt((x - ccx) * (x - ccx) + (y - ccy) * (y - ccy)), wv = fvSmooth((rWin - rr2) / rRamp);
      m[y * w + x] = Math.min(1, m[y * w + x] * 1.0) * wv;
   }
   out.alpha = m; out.ok = true; out.feather = fr;
   return out;
}
// Con la segmentacion: el RECORTE (lo que el objeto pone encima del cielo: (foto − fondo)·α) y la foto SIN el objeto para las capas
// (foto − (foto − fondo)·α). Desde la Tierra, recorte + resto = la foto. -> { cut: Uint32Array w·h } y modifica `rest` (Uint32Array W·H)
function fvObjCutAndRemove(px, rest, W, H, seg) {
   // (4-nov, revision de Codex H-1) el recorte sale de lo que QUEDA (rest), no de la foto: con dos objetos solapados la luz del solape iba entera
   // a los dos (y el fondo se quedaba el minimo): en el solape, 1,8 veces la luz de la foto. CUT_FROM_REST = false: ROJO.
   // share[i] = fraccion de la luz de la foto que se lleva ESTE objeto (1 sin solape): el recorte a resolucion completa la usa como alfa.
   var w = seg.w, h = seg.h, cut = new Uint32Array(w * h), bg = seg.bg, a = seg.alpha, share = new Float32Array(w * h), fromRest = !!(rest && FV_OBJ.CUT_FROM_REST);
   for (var y = 0; y < h; ++y) for (var x = 0; x < w; ++x) {
      var i = y * w + x, J = (y + seg.y0) * W + x + seg.x0, p0 = px[J], p = fromRest ? rest[J] : p0, al = a[i];
      if (al <= 0.002) { cut[i] = 0xff000000; continue; }
      var c = [(p >>> 16) & 255, (p >>> 8) & 255, p & 255], cu = [0, 0, 0], re = [0, 0, 0], e0 = 0, eR = 0;
      for (var k = 0; k < 3; ++k) { var e = Math.max(0, c[k] - bg[k]) * al; eR += e; cu[k] = Math.round(e); re[k] = Math.max(0, Math.min(255, c[k] - cu[k])); e0 += Math.max(0, ((p0 >>> (16 - 8 * k)) & 255) - bg[k]) * al; }
      share[i] = (p === p0 || !(e0 > 0)) ? al : al * Math.min(1, eR / e0);
      cut[i] = (0xff000000 | (cu[0] << 16) | (cu[1] << 8) | cu[2]) >>> 0;
      if (rest) { var q = rest[J]; rest[J] = (0xff000000 | (Math.min((q >>> 16) & 255, re[0]) << 16) | (Math.min((q >>> 8) & 255, re[1]) << 8) | Math.min(q & 255, re[2])) >>> 0; }
   }
   return { cut: cut, share: share };
}
// LAS CAPAS DEL VOLUMEN (ESTETICO). K capas a t_k ∈ [−1, 1] × la semiprofundidad (DEPTH × R), separadas a lo largo de la visual desde la
// Tierra. (4-nov, tercera pasada, a peticion del coordinador: «de lado se ve casi igual que de frente, solo mas borrosa») DOS COMPONENTES:
//   · el NUCLEO / anillo interior: lo brillante (brillo ≥ ~0,45 del p99 del recorte) dentro de 0,6 R -> UNA capa, la del medio (t = 0): una
//     sola copia nitida, sin ecos;
//   · la CASCARA exterior: el resto, en una LAMINA CONTINUA cuya profundidad sigue un campo de ruido suave con semilla dentro de la esfera de
//     radio R: t = (2·ruido − 1)·√(1 − ρ²)·(1 − nucleo difuminado), repartida con una gaussiana de ~1 capa (19 capas). ESTETICO. (A medias
//     delante/detras salian ecos; zona entera delante o detras dejaba huecos negros al llegar: el modo "binary" se queda como control en rojo.) El halo del centro queda delante y detras (bien separado del anillo); el
//     del borde, a la altura del anillo. Al girar, el anillo y las dos caras de la cascara se desplazan unas respecto de otras (paralaje).
// Pesos que SUMAN 1 por pixel: desde la Tierra se ve exactamente el recorte. Galaxia: disco fino, el mismo peso en las K capas.
// -> { t: [K], w: [Float32Array w·h], K, inner (fraccion del brillo que va al nucleo) }
function fvObjShellWeights(seg, type, cut, Kfix) {
   // (4-nov, cuarta) tope de memoria: K capas de w×h×4 bytes ≤ PLANE_MB por objeto (un recorte de 1 024 px con 37 capas serian 155 MB); K impar
   var K0 = FV_OBJ.SHELLS[type] || 3, KM = Math.floor(FV_OBJ.PLANE_MB * 1048576 / Math.max(1, 4 * seg.w * seg.h)), K = Math.max(Math.min(K0, 9), Math.min(K0, KM));
   if (Kfix > 0) K = Kfix;      // (F12) el recorte ajustado del protagonista conserva el numero de planos de antes (mismo aspecto 3D y mismo coste por fotograma con un plano mas pequeño)
   if (K % 2 === 0) --K;
   var w = seg.w, h = seg.h, n = w * h, ccx = seg.cx - seg.x0, ccy = seg.cy - seg.y0, R = Math.max(2, seg.rMax), t = [], W = [], k, i;
   for (k = 0; k < K; ++k) { t.push(K > 1 ? -1 + 2 * k / (K - 1) : 0); W.push(new Float32Array(n)); }
   var flat = (type === "galaxy"), mid = Math.floor(K / 2), lum = null, bMax = 1, eIn = 0, eAll = 0;
   if (cut) { lum = new Float32Array(n); var srt = []; for (i = 0; i < n; ++i) { lum[i] = fvObjLum(cut[i]); if (lum[i] > 0) srt.push(lum[i]); } srt.sort(function(a, b) { return a - b; }); bMax = Math.max(1, srt.length ? srt[Math.floor(0.99 * (srt.length - 1))] : 1); }
   // (tercera pasada) la lamina se reparte con una gaussiana de SPLAT capas de anchura alrededor de su profundidad: con la interpolacion entre
   // dos vecinas, de lado se veian franjas (curvas de nivel) con negro entre medias (nC_2392_antes_despues.png, columna 5, segundo intento)
   // sg (opcional) = anchura en capas para este pixel; < 0,3 -> interpolacion entre las dos vecinas
   function splat(i2, tt, a, sg) {
      if (sg === undefined) sg = FV_OBJ.SPLAT * (K - 1) / 18;   // SPLAT en separaciones de 19 capas: la misma anchura en profundidad con mas capas
      if (sg < 0.3) { put(i2, tt, a); return; }
      var pos = (tt + 1) / 2 * (K - 1), k0 = Math.floor(pos), sg2 = 2 * sg * sg, ws = [], kk, tot = 0, rr = Math.ceil(2.5 * sg);
      for (kk = k0 - rr; kk <= k0 + rr + 1; ++kk) { var v = (kk >= 0 && kk < K) ? Math.exp(-(kk - pos) * (kk - pos) / sg2) : 0; ws.push(v); tot += v; }
      if (tot <= 0) { put(i2, tt, a); return; }
      for (kk = 0; kk < ws.length; ++kk) if (ws[kk] > 0) W[k0 - rr + kk][i2] += a * ws[kk] / tot;
   }
   function put(i2, tt, a) { var pos = (tt + 1) / 2 * (K - 1), k0 = Math.max(0, Math.min(K - 2, Math.floor(pos))), f = fvClamp(pos - k0, 0, 1); W[k0][i2] += a * (1 - f); W[k0 + 1][i2] += a * f; }
   if (flat) { for (i = 0; i < n; ++i) for (k = 0; k < K; ++k) W[k][i] = 1 / K; return { t: t, w: W, K: K, inner: 0 }; }
   // el nucleo (FIN) y su version difuminada (FINB): cerca del nucleo la cascara se acerca a la capa del medio (sin «foso» oscuro entre los dos
   // al llegar: nC_2392_antes_despues.png, tercera pasada, primer intento)
   var FIN = new Float32Array(n), RHO = new Float32Array(n);
   for (i = 0; i < n; ++i) {
      var x = i % w, y = (i - x) / w, rho = Math.sqrt((x - ccx) * (x - ccx) + (y - ccy) * (y - ccy)) / R, b = lum ? Math.min(1, lum[i] / bMax) : 0;
      RHO[i] = rho; FIN[i] = fvSmooth((b - FV_OBJ.CORE_B) / 0.25) * fvSmooth((FV_OBJ.CORE_R - rho) / 0.15);
   }
   var rb = Math.max(1, Math.round(FV_OBJ.CORE_BLUR * R)), FINB = fvObjBlur(fvObjBlur(FIN, w, h, rb), w, h, rb);
   // CARA DE DELANTE O DE DETRAS: cada zona de la cascara va ENTERA a una de las dos (un campo de ruido suave, celdas de ~0,35 R, con semilla):
   // repartida a medias, cada filamento salia dos veces (delante mas grande, detras mas pequeño) = ecos (primer intento de la tercera pasada)
   var cell = Math.max(4, (FV_OBJ.SHELL_MODE === "binary" ? 0.35 : FV_OBJ.SHELL_CELL) * R), gw = Math.ceil(w / cell) + 2, gh = Math.ceil(h / cell) + 2, rnd = fvRng(9173), grid = new Float32Array(gw * gh);
   for (i = 0; i < gw * gh; ++i) grid[i] = rnd();
   var TT = new Float32Array(n);
   // (4-nov, probado y DESCARTADO) suma de 3 ondas planas en vez de la rejilla: pendiente de profundidad mas fuerte -> franjas (cebra) de lado
   // y el halo estirado 2 R a los lados (nC_probe2_lado_half.png de la sonda). La rejilla de ~3 celdas da una lamina casi de una sola inclinacion.
   for (i = 0; i < n; ++i) {
      var x2 = i % w, y2 = (i - x2) / w, gx = x2 / cell, gy = y2 / cell, ix = Math.floor(gx), iy = Math.floor(gy), fx = fvSmooth(gx - ix), fy = fvSmooth(gy - iy);
      var pn = grid[iy * gw + ix] * (1 - fx) * (1 - fy) + grid[iy * gw + ix + 1] * fx * (1 - fy) + grid[(iy + 1) * gw + ix] * (1 - fx) * fy + grid[(iy + 1) * gw + ix + 1] * fx * fy;
      var fin2 = FIN[i], z2 = Math.sqrt(Math.max(0, 1 - RHO[i] * RHO[i])) * (1 - Math.min(1, 2 * FINB[i]));   // ×2: en el borde del nucleo la cascara ya esta en la capa del medio (si no, el hueco del nucleo salia en cada capa = arcos de lado)
      if (FV_OBJ.SHELL_MODE === "binary") {
         // (ROJO, primer intento de la tercera pasada) cada zona ENTERA delante o detras: al llegar, entre las zonas de delante (mas grandes) y las
         // de detras (mas pequeñas) quedaban gusanos NEGROS (nC_2392_antes_despues.png) y la medida de nitidez los premiaba
         var wF = fvSmooth((pn - 0.5) / 0.12 + 0.5);
         W[mid][i] += fin2; put(i, -z2, wF * (1 - fin2)); put(i, z2, (1 - wF) * (1 - fin2));
      } else {
         // LAMINA CONTINUA: cada pixel a UNA profundidad, z = (2·ruido − 1)·√(1 − ρ²)·(1 − nucleo difuminado), que varia SUAVE de un pixel al vecino:
         // sin saltos de profundidad no hay huecos al acercarse, cada estructura sale una sola vez, y de lado se ve el relieve con paralaje
         // (4-nov) con el ruido solo, la lamina era casi un PLANO inclinado: desde un angulo quedaba de canto y el halo se volvia una raya cian
         // (nC_2392_antes_despues.png, columna 7). Ahora es una CUPULA hacia la Tierra (SHELL_DOME) con el ruido como relieve: nunca de canto.
         W[mid][i] += fin2; TT[i] = -(FV_OBJ.SHELL_DOME + (1 - FV_OBJ.SHELL_DOME) * (2 * pn - 1)) * z2;
      }
      if (lum) { eIn += fin2 * lum[i]; eAll += lum[i]; }
   }
   if (FV_OBJ.SHELL_MODE !== "binary") {
      // (4-nov, cuarta) los ARCOS oscuros concentricos de lado eran la ESCALERA de la lamina: donde la profundidad cambia deprisa (junto al nucleo y en
      // el borde de la cupula) cada capa se queda con una franja estrecha y, de lado, franjas vecinas caen a ~18 px una de otra con negro entre medias.
      // Se suaviza el MAPA de profundidad (DEPTH_BLUR·R, caja ×2): la pendiente queda acotada y las franjas se solapan. (Probado y refutado: reparto mas
      // estrecho junto al nucleo para no copiar el borde del hueco -> arcos mucho mas negros: nC_probe3_near_lado.png.)
      var rz = Math.max(0, Math.round(FV_OBJ.DEPTH_BLUR * R)), TB = rz >= 1 ? fvObjBlur(fvObjBlur(TT, w, h, rz), w, h, rz) : TT;
      // (5-nov, C11) EL HUECO DE PARALAJE junto al nucleo: el nucleo va entero a la capa del medio (t = 0), pero la cascara de al lado ya estaba a
      // la profundidad del mapa suavizado (el suavizado mete la cupula hasta el borde del nucleo, y ese borde es un umbral de BRILLO, abrupto):
      // en NGC 2392, t 0 → −0,22 en 4 px de la foto. De lado un salto Δt de profundidad es un salto de Δt·DEPTH·R en pantalla: entre el anillo y
      // la cascara quedaba una banda sin luz (la media luna de C11, r 86 px; sonda tests/fv_S_nC11_fix_probe.js: x en pantalla 57 → 100 px).
      // Arreglo: profundidad 0 en el nucleo (FIN ≥ 0,5) y pendiente maxima SHELL_LIP_K. Con pendiente s = SHELL_LIP_K·DEPTH, de lado a θ la luz
      // se estira 1 + 2·sen(θ/2)·s y no se pliega mientras s < 1/(2·sen(θ/2)) (≥ 0,5 a cualquier angulo).
      // Probado y DESCARTADO (sonda, 5-nov): «cortina» (la luz de cada pixel repartida entre la profundidad acotada y la del mapa) -> el minimo sigue
      // (1 en r 86); solo el cono desde el nucleo (sin acotar el resto del mapa) -> identico a la envolvente completa (lo que ata es el nucleo).
      // «el nucleo encima de la cupula» (sin capa del medio, todo a la profundidad del mapa continuo) -> 0 minimos y r lado/frente 0,71, pero el anillo
      // se separa de su estrella central y sale con contornos dobles (S_nC11fix_cupula_K05_lado.png): descartado.
      // OJO: supone t ≤ 0 (cupula hacia la Tierra, SHELL_DOME ≥ 0,5); con t > 0 en el nucleo, eso no se ataria a 0.
      if (FV_OBJ.SHELL_LIP && FV_OBJ.SHELL_LIP_K > 0) TB = fvObjLipschitzUp(TB === TT ? new Float32Array(TT) : TB, FIN, w, h, FV_OBJ.SHELL_LIP_K / R);
      for (i = 0; i < n; ++i) splat(i, TB[i], 1 - FIN[i]);
   }
   return { t: t, w: W, K: K, inner: eAll > 0 ? eIn / eAll : 0 };
}
// (5-nov, C11) la ENVOLVENTE DE LIPSCHITZ hacia arriba de un mapa de profundidad (t ≤ 0: la cupula va hacia la Tierra): la MENOR funcion ≥ a con
// pendiente ≤ lp (t por px) y 0 donde anc ≥ 0,5 (el nucleo). Solo hace la lamina MENOS profunda donde cambia demasiado deprisa (junto al nucleo
// y en el borde de la cupula); donde ya era suave no cambia nada. Chaflan de 8 vecinos (1 y √2), dos pasadas (exacto para esa metrica).
// Modifica y devuelve a (Float32Array w·h).
function fvObjLipschitzUp(a, anc, w, h, lp) {
   var n = w * h, i, x, y, v, d1 = lp, d2 = lp * Math.SQRT2;
   if (anc) for (i = 0; i < n; ++i) if (anc[i] >= 0.5 && a[i] < 0) a[i] = 0;
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
      i = y * w + x; v = a[i];
      if (x > 0) v = Math.max(v, a[i - 1] - d1);
      if (y > 0) { v = Math.max(v, a[i - w] - d1); if (x > 0) v = Math.max(v, a[i - w - 1] - d2); if (x < w - 1) v = Math.max(v, a[i - w + 1] - d2); }
      a[i] = v;
   }
   for (y = h - 1; y >= 0; --y) for (x = w - 1; x >= 0; --x) {
      i = y * w + x; v = a[i];
      if (x < w - 1) v = Math.max(v, a[i + 1] - d1);
      if (y < h - 1) { v = Math.max(v, a[i + w] - d1); if (x < w - 1) v = Math.max(v, a[i + w + 1] - d2); if (x > 0) v = Math.max(v, a[i + w - 1] - d2); }
      a[i] = v;
   }
   return a;
}

// ---------------------------------------------------------------------------
// LA DISTANCIA de un objeto de catalogo (dist de cpSfSimbadObjects: { pc, lo, hi, kind, methods, catalog, bibcode, z, lookbackYr }) ->
//   { ly, errLy, src: "measured"|"catalog"|"assumed", ref, z, lookbackYr }
// MEDIDA: una paralaje (la mas reciente: Gaia), o el corrimiento al rojo de fiar para lo extragalactico. DE CATALOGO: la mediana de las
// medidas de SIMBAD de otros metodos (estadisticas, de modelo). Nunca se inventa: sin nada, null (quien llama la supone y lo dice).
// ---------------------------------------------------------------------------
function fvObjDistOf(d) {
   if (!d || !(d.pc > 0)) return null;
   var ly = d.pc * FV_LY_PER_PC, lo = (d.lo > 0 ? d.lo : d.pc) * FV_LY_PER_PC, hi = (d.hi > 0 && isFinite(d.hi) ? d.hi : d.pc) * FV_LY_PER_PC, err = Math.max(0, 0.5 * (hi - lo));
   var src = "catalog", ref = "SIMBAD";
   if (d.kind === "parallax") { src = "measured"; ref = "SIMBAD: " + (d.catalog || "parallax") + " parallax" + (d.year ? " (" + d.year + ")" : ""); }
   else if (d.kind === "redshift") { src = (d.quality === "good") ? "measured" : "catalog"; ref = "redshift z = " + (d.z !== undefined ? Number(d.z).toPrecision(4) : "?") + " (" + (d.ref || "cosmology") + ")"; }
   else if (d.kind === "direct") ref = "SIMBAD: " + (d.n > 1 ? "median of " + d.n + " measurements" : "1 measurement") + (d.methods && d.methods.length ? " (" + d.methods.join(", ") + ")" : "");
   else if (d.kind === "redshift-model") ref = "SIMBAD: distance from a flow model (literature)";
   else if (d.source === "cluster-catalog" || d.ref) { src = "measured"; ref = d.ref || "cluster catalogue"; }
   return { ly: ly, errLy: err, src: src, ref: ref, z: (d.z !== undefined ? d.z : null), lookbackYr: (d.lookbackYr > 0 ? d.lookbackYr : null) };
}

// ---------------------------------------------------------------------------
// SINGULARIDAD. Tipo + se ve en la foto (y cuanto) + brillo + distancia medida. Pesos: ELECCION nuestra (para ordenar la lista, no es
// una medida). La nebulosa principal va arriba (9); las estrellas notables, 2 + su motivo.
// ---------------------------------------------------------------------------
function fvObjScore(o) {
   if (o.main) return 9;
   var s = FV_OBJ.TYPE_W[o.type] || 1;
   if (o.seg && o.seg.ok) s += 2 + Math.min(2, Math.log(1 + (o.sizeArcmin || 0) * 6) / Math.LN10);
   else if (o.type === "pn" || o.type === "galaxy" || o.type === "nebula" || o.type === "other") s -= 2;
   if (o.mag !== null && o.mag !== undefined && isFinite(o.mag)) s += fvClamp((16 - o.mag) * 0.25, 0, 2);
   s += (o.distSrc === "measured") ? 1 : (o.distSrc === "catalog" ? 0.5 : 0);
   if (o.type === "quasar" && o.z > 1) s += 1;
   if (o.type === "cluster" && o.members > 0) s += 1;
   if (/^(M|NGC|IC|Collinder|Melotte|Trumpler|Berkeley|King|Stock|Cl Collinder|Cl Melotte|Cl Trumpler|Cl Berkeley|Cl King|Cl Stock)\s/.test(String(o.name))) s += 0.5;
   return Math.round(s * 100) / 100;
}

// el radio aparente que se ve en pantalla de un objeto (px) -> { p: [sx, sy, z], r } | null
function fvObjScreen(o, pr) {
   var p = pr.project(o.pos);
   if (!p) return null;
   return { p: p, r: pr.f * Math.max(1e-12, o.radiusLy) / p[2] };
}

// ---------------------------------------------------------------------------
// EL CLIC (contrato con A): el objeto EXTENSO bajo el cursor tiene prioridad sobre la estrella; si caen varios, el que mejor lo contiene.
// No compiten: los cumulos (son estrellas: se eligen de la lista) ni los objetos que no se ven en la foto. Un cuasar (puntual), a 6 px.
// La estrella central de una planetaria sigue siendo suya: el clic a menos de max(4 px, STAR_CLICK × radio) de ella devuelve −1
// (y A elige la estrella con fvPick, con su ficha). -> indice en scene.objects | −1
// ---------------------------------------------------------------------------
function fvObjectHit(scene, pr, P, mx, my) {
   var O = scene && scene.objects, best = -1, bq = 1e30;
   if (!O || !O.length || !pr) return -1;
   for (var i = 0; i < O.length; ++i) {
      var o = O[i];
      if (o.main || o.type === "star" || o.type === "cluster" || o.type === "exoplanet") continue;
      var sp = fvObjScreen(o, pr); if (!sp) continue;
      var dx = mx - sp.p[0], dy = my - sp.p[1], d = Math.sqrt(dx * dx + dy * dy), rHit;
      if (o.type === "quasar") rHit = 6;
      else if (o.seg && o.seg.ok) rHit = Math.max(6, sp.r);
      else continue;
      if (d > rHit) continue;
      if (o.star >= 0 && scene.stars) {
         var q = pr.project(fvStarPos(scene, o.star));
         if (q) { var ds = Math.sqrt((mx - q[0]) * (mx - q[0]) + (my - q[1]) * (my - q[1])); if (ds <= Math.max(4, FV_OBJ.STAR_CLICK * sp.r)) return -1; }
      }
      // (4-nov, revision de Codex H-2) dentro del circulo, pero sobre la MASCARA: junto a una galaxia alargada, el cielo vacio ya no abre su ficha
      // (con mas de 12 px de radio en pantalla; en pequeño el circulo es mas facil de acertar). HIT_MASK = false: ROJO
      if (FV_OBJ.HIT_MASK && o._seg && sp.r > 12 && typeof fvObjAlphaAt === "function") { var alH = fvObjAlphaAt(scene, o, pr, mx, my); if (alH !== null && alH < FV_OBJ.HIT_ALPHA) continue; }
      var qd = d / rHit;
      if (qd < bq) { bq = qd; best = i; }
   }
   return best;
}

// ---------------------------------------------------------------------------
// EL DESTINO (contrato con B): { pos, arriveLy, lookAt }. Estrella: la regla de la estrella (FV_PILOT); nebulosa principal: la suya.
// ---------------------------------------------------------------------------
function fvObjStarArrive(scene, i) {
   var S = scene.stars, g = S.g[i], d0 = S.dEarth[i];
   if (typeof FV_PILOT === "undefined") return Math.max(0.05, Math.min(60, 0.01 * d0));
   var d = d0 * Math.pow(10, (FV_PILOT.ARRIVE_MAG - g) / 5);
   return fvClamp(d, FV_PILOT.ARRIVE_MIN, Math.min(FV_PILOT.ARRIVE_MAX, 0.5 * d0));
}
// (14-nov-2026, encargo A «la caja») LOS VIAJES NO SALEN DE LA CAJA 3D. La caja es la de fv_bounds.js: el cono de la foto hasta la boca a dMax (fvBoxDMax).
// Nino: «cuando hago tours o uso Mirabilia, hay viajes que se van fuera del voxel 3D y eso no tiene sentido (M82)». Medido (tests/_box/): en M 82 el Tour y las
// estrellas de MIRABILIA caben siempre; lo que sale es la GALAXIA M 82 (catalogo: 12,2 millones de a.l.; caja: 5 798 a.l.): su destino (o.pos / o.frame.pos) esta a 2 100 veces
// la boca y la camara llegaba a 7,9 millones de a.l. de la Tierra (y los viajes que salian de ahi empezaban fuera). Un objeto MAS ALLA DE LA BOCA se enseña
// donde esta su imagen: en la losa de la foto (a la distancia de la nebulosa), en la MISMA linea de vision y con el MISMO tamaño angular (se escalan posicion,
// radio y distancia de llegada por k = D_losa / |pos|). La ficha sigue diciendo su distancia verdadera. FV_BOX.ON = false: lo de antes (ROJO).
var FV_BOX = { ON: true };
// la boca de la caja: la MISMA cuenta que fvBoundsGeom (antes duplicada alli): max(100, 1,35 × distancia de la nebulosa, p97 de las distancias de las estrellas de la foto).
// Cache por escena y por si ya se hizo el «tuck» de fvPilotNew (fvSceneTuckAssumed mueve estrellas: sin esto, el primer calculo antes del piloto daba 22 087 a.l. en M 82 en vez de 5 798)
function fvBoxDMax(scene) {
   var N = scene ? scene.nebula : null, S = scene ? scene.stars : null, tk = (scene && scene.tucked) ? 1 : 0, n = S ? S.n : 0, c = scene ? scene._boxDMax : null;
   if (c && c.tk === tk && c.n === n && c.D === (N ? N.distLy : 0)) return c.v;
   var ds = [], i;
   if (S) for (i = 0; i < S.n; ++i) if (S.inFrame[i]) ds.push(S.dEarth[i]);
   ds.sort(function(a, b) { return a - b; });
   var p97 = ds.length ? ds[Math.min(ds.length - 1, Math.floor(0.97 * ds.length))] : 1000, v = Math.max(100, N ? 1.35 * N.distLy : 0, p97);
   if (scene) scene._boxDMax = { tk: tk, n: n, D: N ? N.distLy : 0, v: v };
   return v;
}
// k < 1 si el objeto cae mas alla de la boca (se escala a la losa de la foto); 1 si cabe en la caja (o FV_BOX.ON = false)
function fvObjBoxK(scene, o) {
   if (!FV_BOX.ON || !scene || !o || !o.pos) return 1;
   var p = (FV_OBJ.FRAME && o.frame && o.frame.pos) ? o.frame.pos : o.pos, d = Math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]), dM = fvBoxDMax(scene);
   if (!(d > dM)) return 1;
   var Dp = scene.nebula ? scene.nebula.distLy : 0.5 * dM;
   return Dp / d;
}
// (16-nov-2026, P22) EL VELO DE LA LLEGADA A M 82. Al llegar a un objeto de mas alla de la boca (k < 1), la camara queda 1 700 a.l. delante de la losa y ve las capas de la
// nebulosa (la foto sin estrellas y SIN el objeto, fv_painter.js paintLayers) tal cual: su pedestal de cielo (en M 82 ~28/18/26 sobre 255, R−G ≈ +9) es un velo rojizo uniforme
// en vez del negro del vacio, y el borde del hueco que dejo el recorte (un reborde de +5..+7 niveles y un valle de −2) es el anillo. Desde la Tierra no se ve: la foto entera
// es el pedestal. Solo se toca la VISTA de las capas de la losa, y solo en una escena con algun objeto escalado a la losa (fvVeilActive); el objeto, las estrellas y todo lo demas
// no cambian. MODE 0 = lo de antes (BIT A BIT, el ROJO). MODE 1 = a las capas se les resta el pedestal de cielo de la foto (p25 por canal, como la niebla): fondo negro,
// el reborde queda como un halo tenue. MODE 2 = pedestal + MARGIN niveles: ademas desaparece el reborde (y lo que no pase de MARGIN niveles sobre el cielo).
// DE FABRICA 0: es decision de Nino (docs/encargos-16nov/P22.md).
// (D6, 17-nov, DECISION DE NINO) de fabrica MODE 2 (pedestal + margen); 0 devuelve lo de antes
var FV_VEIL = { MODE: 2, MARGIN: 7 };
// ¿esta escena enseña algun objeto escalado a la losa (M 82)? Solo entonces las capas de la losa son un pedestal de galaxia y no la nebulosa de la foto
function fvVeilActive(scene) {
   if (!FV_BOX.ON || !scene || !scene.objects) return false;
   for (var i = 0; i < scene.objects.length; ++i) { var o = scene.objects[i]; if (o && o.type !== "star" && o.type !== "exoplanet" && fvObjBoxK(scene, o) < 1) return true; }
   return false;
}
// (14-nov, encargo A) UNA ESTRELLA (o lo que sea) MAS ALLA DE LA BOCA: no se puede llevar a la losa (es un punto de la escena, no una imagen), asi que se llega a la boca:
// la distancia de llegada no baja de |T| − STOP × dMax (la camara queda en la linea de vision, dentro de la caja, mirando a lo de mas alla). Lo llaman los tres sitios que
// planean una llegada (fvPilotFly clasico, fvRouteSetup, fvLabFly/fvLab4Plan); NO fvArriveDist (tambien lo usan los radios de esquive de estrellas). El Tour ni lo pide:
// fvTourPick no elige estrellas fuera de la caja (FV_BOX.TOUR)
FV_BOX.ARRIVE = true; FV_BOX.TOUR = true; FV_BOX.ORBIT = true; FV_BOX.STOP = 0.95;
function fvBoxArrive(P, sel, T, dA) {
   if (!FV_BOX.ON || !FV_BOX.ARRIVE || !P || !P.scene || !T) return dA;
   var dM = fvBoxDMax(P.scene), dT = Math.sqrt(T[0] * T[0] + T[1] * T[1] + T[2] * T[2]);
   if (!(dT > dM)) return dA;
   return Math.max(dA, dT - FV_BOX.STOP * dM);
}
// (16-nov-2026, P23-web) LA MEDIA VUELTA TAMBIEN TIENE PAREDES. FV_BOX.ORBIT solo miraba la boca (|T| + r > dMax); en el visor web, con el pintor de verdad dando el «hay foto detras»,
// la media vuelta v5 alrededor de una estrella junto a la pared del cono (r = 21,8 a.l. con la pared a 4,9 a.l. de la estrella) sacaba la camara de la caja por el lateral:
// 8 fotogramas fuera, hasta el 280 % de la semianchura, en la cadena y en el Tour de M 82 (docs/encargos-16nov/P23-web.md). La vuelta recorre la esfera de radio r alrededor del destino T:
// cabe si r <= fvBoxRoom(escena, T), el radio de la mayor esfera centrada en T que cabe en la caja (distancia a las paredes del cono, a la Tierra y a la boca).
// FV_BOX.WALLS = false: lo de antes (la vuelta solo mira la boca).
// (16-nov, D4-WALLS) MEDIDO EN PIXINSIGHT (dialogo real, instancia 252, docs/encargos-16nov/D4-WALLS.md): con false la media vuelta SALE tambien aqui (M 82: hasta 252,9 % de la
// semianchura en una cadena de MIRABILIA; Collinder 34: hasta 169,4 %); con true 0 fotogramas fuera. DECISION DE NINO (16-nov): encendida de fabrica. El visor web la fija igual (web/fw_box.js)
FV_BOX.WALLS = true;
// (17-nov-2026, P33) LA COMBA DE LA APROXIMACION TAMBIEN TIENE PAREDES. Medido en PixInsight (docs/encargos-16nov/P33.md): con WALLS true, en NGC 2392 quedaban 8 fotogramas fuera
// (hasta 1,5 % de la semianchura) en el vuelo del Tour hacia un destino lejano en el eje, a 5 000 a.l. del destino y a 3 s de salir (uP 0,2): no es la llegada ni el destino (A y T estan
// en el eje, a -100 %), es la COMBA del camino (fvLab4Plan: 16 s²(1-s)² x h hacia el centro de la losa, h = 6 % del camino visto) que fvLab4PathOk daba por buena porque solo exige estar a
// menos de EDGE.OUT = 1,5 semianchuras de la piramide. Con BOW el camino de la comba tiene ademas que caber en la caja (fvBoxLat <= 0 en 64 puntos, o <= lo que ya estuviera fuera la salida);
// si no cabe, la comba se reduce a la mitad hasta que quepa (o recta): se llega al MISMO destino por el mismo sitio y los viajes cuya comba ya cabia no cambian ni un bit.
// FV_BOX.BOW = false: lo de antes (el ROJO).
FV_BOX.BOW = true;
// distancia (a.l.) de p a las paredes laterales de la caja 3D: positiva = fuera. Misma cuenta que la prueba (tests/_box/fv_box_lib.jsh bxOver: lat), con field de la escena (sin depender de fv_bounds.js)
function fvBoxLat(scene, p) {
   var f = scene ? scene.field : null; if (!f || !(f.F > 0) || !p) return -1e30;
   var hx = (f.width / 2) / f.F, hy = (f.height / 2) / f.F, z = Math.max(p[2], 0);
   return Math.max(Math.abs(p[0]) - hx * z, Math.abs(p[1]) - hy * z);
}
function fvBoxRoom(scene, p) {
   var f = scene ? scene.field : null; if (!f || !(f.F > 0) || !p) return 1e30;
   var hx = (f.width / 2) / f.F, hy = (f.height / 2) / f.F, z = p[2], dM = fvBoxDMax(scene);
   var rx = (hx * z - Math.abs(p[0])) / Math.sqrt(1 + hx * hx), ry = (hy * z - Math.abs(p[1])) / Math.sqrt(1 + hy * hy), rz = z, rm = dM - Math.sqrt(p[0] * p[0] + p[1] * p[1] + p[2] * p[2]);
   return Math.min(rx, ry, rz, rm);
}
function fvObjScaled(p, k) { return [p[0] * k, p[1] * k, p[2] * k]; }
function fvObjectTarget(scene, i) {
   var O = scene && scene.objects, o = O ? O[i] : null;
   if (!o) return null;
   if ((o.type === "star" || o.type === "exoplanet") && o.star >= 0) { var sp = fvStarPos(scene, o.star); return { pos: sp, arriveLy: fvObjStarArrive(scene, o.star), lookAt: sp, star: o.star }; }
   var kb = fvObjBoxK(scene, o);       // (14-nov, A) 1 = dentro de la caja
   // (R8) con contorno medido: se va a SU centro y se llega a la distancia que lo enseña entero (fvObjFrameFit); centered = sin el desvio del tercio
   if (FV_OBJ.FRAME && o.frame && o.frame.pos) {
      var fa = fvObjArriveFit(scene, i, o), fr = (o._arrFit && o._arrFit.frame) ? o._arrFit : null, pf = fvObjScaled(o.frame.pos, kb);
      return { pos: pf, arriveLy: fa, lookAt: pf.slice(), centered: FV_OBJ_CENTER_PROBE || !!(fr && fr.centered), boxK: kb };
   }
   return { pos: fvObjScaled(o.pos, kb), arriveLy: fvObjArriveFit(scene, i, o), lookAt: fvObjScaled(o.pos, kb), boxK: kb };
}
// (E4) la distancia de llegada con la que el objeto ocupa del campo de llegada REAL la fraccion que ARRIVE_R daba con ARRIVE_FOV. El campo
// real lo dice el piloto (fvPilotFly desde casa con sel.arriveLy de prueba: barato, no planifica; fl.fov1); biseccion en log. Se guarda en
// o._arrFit (no enumerable; la clave cambia si cambia la distancia base o la de la nebulosa). Desde otro sitio que no sea casa el campo
// puede ser otro: aproximacion, dicha. Sin piloto (o ARRIVE_FIT false), la de siempre.
var FV_OBJ_FITTING = false;
var FV_OBJ_CENTER_PROBE = false;   // durante la sonda del campo de llegada en modo centrado
// (R8v5, 14-nov) la navegacion de la que depende la llegada, para la clave de la cache o._arrFit: el viaje de prueba lo vuela el piloto clasico o el laboratorio (FV_LAB.ON) y la distancia
// de llegada sale distinta (otro campo, otra S). Sin esto la cache servia el valor de la navegacion que estuviera activa la PRIMERA vez (tecla L / fvLabSetOn despues de pedir el encuadre)
function fvObjNavKey() {
   if (typeof FV_LAB === "undefined" || FV_LAB.ON !== true) return "c";
   // (17-nov, F34) el encuadre del protagonista junto a la ficha (fvF34Aim) cambia la distancia de llegada con el laboratorio: sus banderas y constantes van en la clave (con FV_F34 apagado, la de antes)
   var k34 = (typeof FV_F34 !== "undefined" && FV_F34.ON && FV_F34.FIT) ? "|f34:" + (FV_F34.ALL ? 1 : 0) + ":" + FV_F34.CARD_L + ":" + FV_F34.GAP + ":" + FV_F34.VMARGIN + ":" + FV_F34.MARGIN_MIN : "";
   // (19-nov, N6) con FV_N6.AIM la fila principal tambien se encuadra junto a la ficha: otra distancia de llegada, otra clave (con FV_N6 apagado, la de antes)
   var k6 = (typeof FV_N6 !== "undefined" && FV_N6.ON && FV_N6.AIM) ? "|n6" : "";
   var k2b = (typeof FV_N2B !== "undefined" && FV_N2B.ON && FV_N2B.WHOLE) ? "|n2b:" + FV_N2B.MARGIN + (FV_N2B.SHEET ? "s" : "") : "";      // (N2b) la nebulosa «whole» se encuadra junto a la ficha: otra distancia de llegada
   var k4 = (typeof FV_N4 !== "undefined" && FV_N4.ON) ? "|n4:" + FV_N4.MAX + ":" + FV_N4.REF_W + ((typeof FV_GALT !== "undefined" && FV_GALT.ON && FV_GALT.CAP) ? "g" : "") : "";      // (N4) el limite de ampliacion cambia la distancia de llegada del protagonista (N-galaxias-warp: y de las galaxias)
   return "L" + (FV_OBJ.FRAME_LAB ? 1 : 0) + ":" + FV_LAB.S_MODE + ":" + FV_LAB.S_MAX + ":" + FV_LAB.LENS_DEG + k34 + k6 + k4 + k2b;
}
// (R8v5) S con la que se proyectara la llegada del viaje de prueba P (la de la mirada de llegada: fvLabFlyOfReal, que con FV_LAB.WIDE apagado es L.S0); 0 = el piloto clasico (no hay S)
function fvObjLabS(P) {
   if (!FV_OBJ.FRAME_LAB || typeof FV_LAB === "undefined" || FV_LAB.ON !== true || !P || !P.lab || !P.flight || !P.flight.lab) return 0;
   var fl = P.flight, L = P.lab, S = (L.S0 > 0) ? L.S0 : ((L.S > 0) ? L.S : 1);
   if (typeof fvLabFlyOfReal === "function" && fl.p1 && fl.Tlook) { var d = fvSub(fl.Tlook, fl.p1); if (fvLen(d) > 1e-12) { try { S = fvLabFlyOfReal(L, fvNorm(d)).S; } catch (eS) {} } }
   return (S > 1) ? S : 1;
}
function fvObjArriveFit(scene, i, o) {
   if (FV_OBJ.FRAME && o.frame && o.frame.pos && !FV_OBJ_FITTING) return fvObjFrameFit(scene, i, o);
   var kb = fvObjBoxK(scene, o), base = o.arriveLy * kb;      // (14-nov, A) mas alla de la boca: todo a escala de la losa (fvObjBoxK)
   if (!FV_OBJ.ARRIVE_FIT || FV_OBJ_FITTING || o.main || !(base > 0) || !(o.radiusLy > 0) || typeof fvPilotNew !== "function" || typeof fvPilotFly !== "function" || typeof FV_PILOT === "undefined") return base;
   var key = base + "|" + (scene.nebula ? scene.nebula.distLy : 0) + "|" + fvObjNavKey();
   if (o._arrFit && o._arrFit.key === key) return o._arrFit.v;
   var R = o.radiusLy * kb, dE = fvLen(o.pos) * kb, A = FV_PILOT.ARRIVE_FOV, q = 2 * Math.atan(R / base) / A, v = base;
   FV_OBJ_FITTING = true;
   try {
      var fovAt = function(s) {
         var P = fvPilotNew(scene, FV_OBJ.FIT_VW, FV_OBJ.FIT_VH), sel = { kind: "object", i: i, arriveLy: s };
         P.sel = sel;
         if (!fvPilotFly(P, "travel", sel) || !P.flight || !(P.flight.fov1 > 0)) return A;
         return Math.min(A, P.flight.fov1);
      };
      var qM = q * Math.max(1, FV_OBJ.FIT_MAX || 1);
      var over = function(s) { return 2 * Math.atan(R / s) - q * fovAt(s); };   // > 0: el objeto se sale de la fraccion pedida
      if (2 * Math.atan(R / base) > qM * fovAt(base)) {
         var lo = Math.log(base), hi = Math.log(Math.max(base * 1.0001, 0.9 * dE));
         if (over(Math.exp(hi)) > 0) v = Math.exp(hi);
         else { for (var it = 0; it < 22; ++it) { var m = 0.5 * (lo + hi); if (over(Math.exp(m)) > 0) lo = m; else hi = m; } v = Math.exp(hi); }
      }
   } catch (e) { v = base; }
   FV_OBJ_FITTING = false;
   var rec = { key: key, v: v };
   try { Object.defineProperty(o, "_arrFit", { value: rec, enumerable: false, writable: true, configurable: true }); } catch (eD) { o._arrFit = rec; }
   return v;
}

// (R8) lo que cabe a un lado del encuadre: el medio campo (tan) que queda entre el objeto y el borde de la pantalla. Con el tercio: tan(F/2) − tan(FRAME_THIRD · F)
// (a 60°: 0,286, de los 0,577 de medio campo); centrado: tan(F/2). En vertical, tan(F/2) × VH/VW. Se queda el menor.
function fvObjRoomTan(F, centered) {
   var ky = FV_OBJ.FIT_VH / FV_OBJ.FIT_VW, tF = Math.tan(F / 2), h = centered ? tF : tF - Math.tan(((typeof FV_PILOT !== "undefined") ? FV_PILOT.FRAME_THIRD : 0.27) * F);
   // (17-nov, F34) centered === 2: el objeto en el centro de la zona que la ficha no tapa (desplazado c = 1 − libre, en medios campos, a la izquierda): a cada lado le quedan libre · medio campo; en vertical VMARGIN del alto
   if (centered === 2) return Math.min(tF * fvF34Free(FV_OBJ.FIT_VW), tF * ky * FV_F34.VMARGIN);
   return Math.min(h, tF * ky);
}
// (R8) la distancia de llegada que enseña el contorno del objeto entero: el radio × FRAME_MARGIN cabe en lo que deja el encuadre, con el campo que fije el piloto
// al llegar a esa distancia (fvPilotFly desde casa: fl.fov1, como fvObjArriveFit). Primero con el tercio (deja sitio a la ficha); si ni lejos cabe
// (nebulosa que llena la foto: el tope A del piloto casa el campo con la foto), centrado; si tampoco, el contorno ES la foto: centrado y a la distancia
// de siempre (hw / tan(F/2) + grosor/2: el campo lo cierra el tope A y se ve la parte limpia de la foto entera). Cache en o._arrFit (no enumerable).
function fvObjFrameFit(scene, i, o) {
   var kb = fvObjBoxK(scene, o), fr = o.frame;
   if (kb !== 1) fr = { x: fr.x, y: fr.y, rPx: fr.rPx, rLy: fr.rLy * kb, whole: fr.whole, pos: fvObjScaled(fr.pos, kb) };      // (14-nov, A) objeto mas alla de la boca: su contorno a la escala de la losa
   var c34 = fvF34Aim(scene, o), key = "F|" + fr.rLy + "|" + fr.pos[2] + "|" + (scene.nebula ? scene.nebula.distLy : 0) + "|" + (fr.whole ? 1 : 0) + "|" + FV_OBJ.FRAME_MARGIN + "|" + fvObjNavKey();
   if (o._arrFit && o._arrFit.key === key) return o._arrFit.v;
   var A = (typeof FV_PILOT !== "undefined") ? FV_PILOT.ARRIVE_FOV : Math.PI / 3, R = fr.rLy, m = FV_OBJ.FRAME_MARGIN, dE = fvLen(fr.pos), res = { key: key, v: o.arriveLy * kb, frame: true, centered: false, mode: "none" };
   if (!(R > 0) || typeof fvPilotNew !== "function" || typeof fvPilotFly !== "function" || typeof FV_PILOT === "undefined") return res.v;
   // el campo REAL al llegar: el estimado del piloto (fl.fov1) / EVENT_ARRIVE_K (el cierre de la llegada, I9, que fl.fov1 no ve: tests/fv_nQ_fov1_node.js)
   var KE = (FV_PILOT.ROUTE && FV_PILOT.ROUTE.EVENT_ARRIVE_K > 1) ? FV_PILOT.ROUTE.EVENT_ARRIVE_K : 1;
   var fovAt = function(s, centered) {
      var P = fvPilotNew(scene, FV_OBJ.FIT_VW, FV_OBJ.FIT_VH), sel = { kind: "object", i: i, arriveLy: s }; P.sel = sel;
      FV_OBJ_CENTER_PROBE = (centered === true);
      var okF = fvPilotFly(P, "travel", sel); FV_OBJ_CENTER_PROBE = false;
      var F = (okF && P.flight && P.flight.fov1 > 0) ? Math.min(A, P.flight.fov1) : A;
      // (R8v5) con el laboratorio la pantalla estira lo lateral S veces: el campo lateral REAL es el de la lente / S (y EVENT_ARRIVE_K es del piloto clasico)
      var SL = okF ? fvObjLabS(P) : 0;
      return 2 * Math.atan(Math.tan(F / 2) / (SL > 0 ? SL : KE));
   };
   // over > 0: el contorno con margen NO cabe a esa distancia
   var over = function(s, centered, mg) { return mg * R / s - fvObjRoomTan(fovAt(s, centered), centered); };
   var solve = function(centered, mg) {
      var lo = Math.log(Math.max(1e-6, mg * R / fvObjRoomTan(2 * Math.atan(Math.tan(A / 2) / KE), centered))), hi = Math.log(Math.max(Math.exp(lo) * 1.0001, 0.9 * dE));
      if (over(Math.exp(lo), centered, mg) <= 0) return Math.exp(lo);          // cabe ya a la distancia nominal (campo de 60° completo)
      if (over(Math.exp(hi), centered, mg) > 0) return -1;                      // ni lo mas lejos que se puede
      for (var it = 0; it < 22; ++it) { var mid = 0.5 * (lo + hi); if (over(Math.exp(mid), centered, mg) > 0) lo = mid; else hi = mid; }
      return Math.exp(hi);
   };
   FV_OBJ_FITTING = true;
   try {
      if (!fr.whole && c34 > 0) {
         // (17-nov, F34) el objeto en el centro de la zona libre de ficha (fvObjRoomTan modo 2); si con el margen no cabe, sin margen; si ni asi, lo mas lejos que se puede (la huella no cabe: se dice en res.mode)
         var sF = solve(2, m);
         if (sF > 0) { res.v = sF; res.mode = "free"; }
         else { var sF1 = solve(2, FV_F34.MARGIN_MIN); if (sF1 > 0) { res.v = sF1; res.mode = "free-nomargin"; } else { res.v = 0.9 * dE; res.mode = "free-max"; } }
         res.f34 = c34;
      } else if (!fr.whole) {
         var s3 = solve(false, m);
         if (s3 > 0) { res.v = s3; res.mode = "third"; }
         else {
            var s0 = solve(true, m);
            if (s0 > 0) { res.v = s0; res.centered = true; res.mode = "centered"; }
            else { var s1 = solve(true, 1); if (s1 > 0) { res.v = s1; res.centered = true; res.mode = "centered-nomargin"; } else { res.v = o.arriveLy * kb; res.mode = "base"; } }
         }
      } else {
         // el contorno ES la foto (la nebulosa llena el marco): se enseña la parte LIMPIA de la foto, centrada. El campo de llegada lo fija la ley del piloto
         // (se abre como (d_casa/d)^beta desde el de la foto: a 131 a.l. de IC 1848 son 7°, un trozo azul) y solo cubre la foto cerca de casa. Una pantalla de
         // 16:9 no enseña la foto entera (más alta): «entera» = el ancho limpio completo y el alto que da la pantalla. Se busca la distancia MENOR en que la
         // mitad de ancho visible en el plano de la nebulosa cubre ese ancho (98 %); si no llega, la maxima (FRAME_WHOLE_K de la distancia a casa).
         res.centered = true; res.mode = "whole";
         // (19-nov, N2b; FV_N2B.WHOLE) con la fila principal «whole» como protagonista (c34 > 0): la parte limpia de la foto ENTERA en la zona que la ficha no tapa, desplazada a la izquierda (como F34 con un objeto)
         var sh2b = (c34 > 0);
         if (sh2b) { res.centered = false; res.mode = "whole-free"; res.f34 = c34; }
         var Nb = scene.nebula, kc = (typeof fvLayerCleanK0 === "function") ? fvLayerCleanK0({ scene: scene }) : [0.77, 0.68];
         if (Nb && Nb.layers && Nb.layers[0] && scene.field) {
            var hwN = 0.5 * Math.abs(Nb.layers[0].x1 - Nb.layers[0].x0), hhN = hwN * scene.field.height / scene.field.width, ky2 = FV_OBJ.FIT_VH / FV_OBJ.FIT_VW;
            var needW = sh2b ? Math.max(kc[0] * hwN * FV_N2B.MARGIN / fvF34Free(FV_OBJ.FIT_VW), kc[1] * hhN * FV_N2B.MARGIN / (ky2 * FV_F34.VMARGIN)) : 0.98 * Math.min(kc[0] * hwN, kc[1] * hhN / ky2);
            var vis = function(sv) { return Math.tan(fovAt(sv, sh2b ? 2 : true) / 2) * sv / needW; };    // ≥ 1: se ve entera (N2b: entera en la zona libre de ficha)
            var loW = Math.log(Math.max(1e-6, o.arriveLy * kb)), hiW = Math.log(Math.max(Math.exp(loW) * 1.0001, FV_OBJ.FRAME_WHOLE_K * dE));
            if (vis(Math.exp(loW)) >= 1) res.v = Math.exp(loW);
            else if (vis(Math.exp(hiW)) < 1) { res.v = Math.exp(hiW); res.mode = sh2b ? "whole-free-max" : "whole-max"; }
            else { for (var it2 = 0; it2 < 22; ++it2) { var md = 0.5 * (loW + hiW); if (vis(Math.exp(md)) >= 1) hiW = md; else loW = md; } res.v = Math.exp(hiW); }
         } else { res.v = o.arriveLy * kb; res.f34 = 0; res.centered = true; res.mode = "whole"; }
      }
      // (19-nov, N4; FV_N4) limite de ampliacion: si a la distancia ajustada el objeto se ve a mas de MAX px de pantalla por px de la foto, se llega mas lejos (la mas corta que lo deja en MAX). Solo el protagonista con contorno medido
      if (FV_N4.ON && typeof FV_LAB !== "undefined" && FV_LAB.ON === true && !fr.whole && res.mode !== "none" && res.mode !== "error" && fr.rPx > 0 && (fvF34IsHero(scene, o) || fvGaltCap(o))) {
         var cenN4 = (res.centered === true) ? true : (c34 > 0 && res.f34 > 0 ? 2 : false), lyPx = R / fr.rPx, kRef = FV_N4.REF_W / FV_OBJ.FIT_VW;
         var magAt = function(sv) { var Fe = fovAt(sv, cenN4), th = Math.tan(Fe / 2); return (FV_OBJ.FIT_VW / 2) / (Math.max(1e-9, th) * sv) * lyPx * kRef; };
         var m0 = magAt(res.v), sMax = 0.9 * dE;
         res.mag = { before: m0, after: m0, max: FV_N4.MAX, v0: res.v };
         if (m0 > FV_N4.MAX && sMax > res.v * 1.001) {
            var lo4 = Math.log(res.v), hi4 = Math.log(sMax), sc4 = FV_N4.SCAN, found = -1, jj;
            for (jj = 1; jj <= sc4; ++jj) { var sj = Math.exp(lo4 + (hi4 - lo4) * jj / sc4); if (magAt(sj) <= FV_N4.MAX) { found = jj; break; } }
            if (found > 0) {
               var a4 = lo4 + (hi4 - lo4) * (found - 1) / sc4, b4 = lo4 + (hi4 - lo4) * found / sc4;
               for (jj = 0; jj < 14; ++jj) { var md4 = 0.5 * (a4 + b4); if (magAt(Math.exp(md4)) > FV_N4.MAX) a4 = md4; else b4 = md4; }
               res.v = Math.exp(b4); res.mode += "+mag"; res.mag.after = magAt(res.v);
            } else { res.mode += "+mag-nocap"; res.mag.after = m0; }
         }
      }
   } catch (e) { res.v = o.arriveLy * kb; res.mode = "error"; }
   FV_OBJ_FITTING = false; FV_OBJ_CENTER_PROBE = false;
   try { Object.defineProperty(o, "_arrFit", { value: res, enumerable: false, writable: true, configurable: true }); } catch (eD) { o._arrFit = res; }
   return res.v;
}

// (19-nov, N2b) cuanto se desplaza la lamina entera a la izquierda del centro (medios campos) cuando se llega a ella sin fila principal con contorno (fvN6WholeDist): 0 si no aplica
function fvN2bShift(scene) {
   if (!fvN2bSheet() || !FV_F34.ON || !FV_F34.FIT || typeof fvN6WholeDist !== "function") return 0;
   return (fvN6WholeDist(scene) > 0) ? 1 - fvF34Free(FV_OBJ.FIT_VW) : 0;
}
// (19-nov, N6; FV_N6.WHOLE) la distancia de llegada a la LAMINA de la nebulosa (seleccion {kind:"nebula"}) cuando NO hay fila principal con contorno que encuadrar: la misma cuenta que el modo «whole» de
// fvObjFrameFit (la nebulosa ES la foto: la distancia MENOR en que la mitad de ancho visible en el plano de la lamina cubre el ancho limpio de la foto, 98 %; si no llega, FRAME_WHOLE_K de la distancia a casa),
// pero con la propia seleccion «nebula» como viaje de prueba (sel.arriveLy manda sobre fvArriveDist: no hay recursion). Con el laboratorio la pantalla estira lo lateral S veces: sin S la parada llegaba a
// hw / tan(30°) y en Caldwell 5 (S 48,6) veia 0 % de la foto. Cache en scene.nebula._n6w (no enumerable: no viaja en la exportacion). 0 = no aplica (lo de antes)
function fvN6WholeDist(scene) {
   if (!FV_N6.ON || !FV_N6.WHOLE || FV_OBJ_FITTING || !scene || !scene.nebula || !scene.nebula.layers || !scene.nebula.layers[0] || !scene.field) return 0;
   if (typeof FV_LAB === "undefined" || FV_LAB.ON !== true || typeof fvPilotNew !== "function" || typeof fvPilotFly !== "function" || typeof FV_PILOT === "undefined") return 0;
   var Nb = scene.nebula, Ly = Nb.layers[0], fld = scene.field, key = "W|" + Nb.distLy + "|" + Nb.thickLy + "|" + Ly.x0 + "|" + Ly.x1 + "|" + fld.width + "x" + fld.height + "|" + FV_OBJ.FRAME_WHOLE_K + "|" + fvObjNavKey();
   if (Nb._n6w && Nb._n6w.key === key) return Nb._n6w.v;
   var A = FV_PILOT.ARRIVE_FOV, KE = (FV_PILOT.ROUTE && FV_PILOT.ROUTE.EVENT_ARRIVE_K > 1) ? FV_PILOT.ROUTE.EVENT_ARRIVE_K : 1, dE = Nb.distLy;
   var hwN = 0.5 * Math.abs(Ly.x1 - Ly.x0), hhN = hwN * fld.height / fld.width, ky2 = FV_OBJ.FIT_VH / FV_OBJ.FIT_VW, kc = (typeof fvLayerCleanK0 === "function") ? fvLayerCleanK0({ scene: scene }) : [0.77, 0.68];
   // (19-nov, N2b; FV_N2B.WHOLE) la lamina entera tambien entera en la zona que la ficha no tapa (la nave llega desplazada: fvLab4Plan, fvN2bShift)
   var sh2b = fvN2bSheet(), base = hwN / Math.tan(A / 2) + Nb.thickLy / 2, v = base, mode = "base";
   var needW = sh2b ? Math.max(kc[0] * hwN * FV_N2B.MARGIN / fvF34Free(FV_OBJ.FIT_VW), kc[1] * hhN * FV_N2B.MARGIN / (ky2 * FV_F34.VMARGIN)) : 0.98 * Math.min(kc[0] * hwN, kc[1] * hhN / ky2);
   var fovAt = function(sv) {
      var P = fvPilotNew(scene, FV_OBJ.FIT_VW, FV_OBJ.FIT_VH), sel = { kind: "nebula", arriveLy: sv }; P.sel = sel;
      var okF = fvPilotFly(P, "travel", sel), F = (okF && P.flight && P.flight.fov1 > 0) ? Math.min(A, P.flight.fov1) : A, SL = okF ? fvObjLabS(P) : 0;
      return 2 * Math.atan(Math.tan(F / 2) / (SL > 0 ? SL : KE));
   };
   var vis = function(sv) { return Math.tan(fovAt(sv) / 2) * sv / needW; };      // >= 1: se ve el ancho limpio entero
   FV_OBJ_FITTING = true;
   try {
      var loW = Math.log(Math.max(1e-6, base)), hiW = Math.log(Math.max(Math.exp(loW) * 1.0001, FV_OBJ.FRAME_WHOLE_K * dE));
      if (vis(Math.exp(loW)) >= 1) { v = Math.exp(loW); mode = "whole"; }
      else if (vis(Math.exp(hiW)) < 1) { v = Math.exp(hiW); mode = sh2b ? "whole-free-max" : "whole-max"; }
      else { for (var it = 0; it < 22; ++it) { var md = 0.5 * (loW + hiW); if (vis(Math.exp(md)) >= 1) hiW = md; else loW = md; } v = Math.exp(hiW); mode = "whole"; }
   } catch (e) { v = base; mode = "error"; }
   FV_OBJ_FITTING = false;
   var rec = { key: key, v: v, mode: mode };
   try { Object.defineProperty(Nb, "_n6w", { value: rec, enumerable: false, writable: true, configurable: true }); } catch (eD) { Nb._n6w = rec; }
   return v;
}

// ---------------------------------------------------------------------------
// LAS ESTRELLAS NOTABLES de la escena (solo estrellas de la foto con distancia MEDIDA, salvo la de RUWE alto, que es DUDOSA por
// definicion). info(i) = fvsStar (radio, luminosidad) si src/science esta. -> [{ i, why, bonus }]
// ---------------------------------------------------------------------------
// (14-nov-2026, P21; Nino: «en MIRABILIA quiero tambien "Mas brillante" y "Mas pobre de metalicidad"») DOS CRITERIOS MAS, con bandera cada uno (false = ROJO: la fila no sale):
//   · brightest: la de MENOR magnitud G aparente entre las estrellas del marco con distancia MEDIDA y dentro de la caja 3D (la misma poblacion que el Tour: fvTourPick).
//     NO es «la mas luminosa» (luminosidad REAL, necesita distancia, Teff y polvo): una enana cercana de G 8 y una supergigante lejana de G 12 son cosas distintas.
//   · metalpoor: la de menor [M/H] de GSP-Phot (Gaia DR3 mh_gspphot, que YA llega a scene.stars.meta.mhPhot / mhPhotT por la consulta del refinado de CabraShared:
//     fv_build.js:386; sin peticion nueva). DATO DUDOSO (MEDIDO el 5-nov en Collinder 34: dispersion 0,26 dex contra GSP-Spec, src/science/fv_sci_metal.js; el extremo de una lista
//     con ese ruido suele ser el error mas grande), por eso el rotulo dice «posiblemente» y el valor «≈». Corte minimo, cada umbral con su origen:
//       Teff de GSP-Phot en 3 800–7 500 K  = fvsMetalPhotOk (el rango donde SE MIDIO la dispersion; fuera no esta validada y la ficha tampoco la usa)
//       G < 15                              = el mismo corte de brillo que ya usan luminous / largest / hottest de esta lista (las debiles tienen GSP-Phot peor)
//       RUWE < 1,4 (presente)               = FVS.RUWE_MAX de src/science/fv_sci_const.js (documentacion de Gaia: astrometria sospechosa por encima; una doble sesga la fotometria)
//       distancia medida (q 0), en el marco, dentro de la caja = como los demas criterios
//     Si ninguna pasa el corte NO hay fila (no se rellena con la menos mala).
// (19-nov-2026, B1; Nino: «Al ir a Most luminous star en Mirabilia de M82, la nave se queda bloqueada») BOX_ALL: TODOS los criterios (luminous, largest, hottest, binary) piden tambien que la estrella
// este DENTRO de la caja 3D, no solo brightest / metalpoor. Causa medida (docs/encargos-19nov/B1.md): la estrella mas luminosa de una foto es casi siempre una gigante LEJANA; en M 82 salia a 30 821 a.l.
// con la boca de la caja a 8 076: fvBoxArrive (la caja, 14-nov) la lleva «a la boca» y la nave se para a 23 149 a.l. de ella, sin llegar (la ficha dice 30 821 a.l.; arrivedAt se pierde: fvLabFinish
// lo suelta a > 4 dA). El Tour ya evitaba esas estrellas (FV_BOX.TOUR); la lista de MIRABILIA no. Solo se ofrece lo que la nave puede alcanzar. false = lo de antes (la de mas luminosidad aunque este fuera).
// (21-nov-2026, T1-A; decision de Nino) NODATA_ROW: si ninguna estrella ofrece el [M/H] de GSP-Phot (el afinado cayo en GAVO, que no lo trae; sin red; o ninguna pasa el corte) la fila «metalpoor»
// NO desaparece: se queda y dice «sin datos» / «no data» (fvObjNotableStars la deja en el array devuelto como `.noData`; fvObjFinalList la guarda en scene.noData; MIRABILIA la pinta sin flecha y
// sin viaje). false = lo de antes: la fila desaparece (ROJO de tests/_mira/fv_B_labels_test.js, T1). Web: ?ndrow=0 (web/fw_nav.js, FW_NAV.NODATA_ROW).
var FV_NOTABLE = { BRIGHTEST: true, METALPOOR: true, BOX: true, BOX_ALL: true, MP_GMAX: 15, MP_RUWE: 1.4, NODATA_ROW: true };
// la boca de la caja que tendra la escena DESPUES del «tuck» de fvPilotNew (fvSceneTuckAssumed recoloca las supuestas detras de la nebulosa: aqui, al armar la lista, aun no se ha hecho y
// fvBoxDMax daba 22 088 a.l. en M 82 en vez de 5 798): la misma cuenta con las supuestas de mas alla de la nebulosa topadas en su distancia (cota alta de lo que da el tuck)
function fvNotableBoxD(scene) {
   var S = scene.stars, N = scene.nebula;
   if (!FV_NOTABLE.BOX || !FV_BOX.ON || typeof fvBoxDMax !== "function") return 0;
   if (scene.tucked || !N || !(N.distLy > 0) || (typeof FV_SCENE_TUCK !== "undefined" && !FV_SCENE_TUCK)) return fvBoxDMax(scene);
   var ds = [], i, d;
   for (i = 0; i < S.n; ++i) if (S.inFrame[i]) { d = S.dEarth[i]; if (S.q[i] === 2 && d > N.distLy) d = N.distLy; ds.push(d); }
   ds.sort(function(a, b) { return a - b; });
   return Math.max(100, 1.35 * N.distLy, ds.length ? ds[Math.min(ds.length - 1, Math.floor(0.97 * ds.length))] : 1000);
}
function fvObjNotableStars(scene, skip) {
   var S = scene.stars, out = [], used = skip || {}, i;
   if (!S) return out;
   var c = { near: -1, lum: -1, hot: -1, big: -1, ruwe: -1, bright: -1, mp: -1 }, v = { near: 1e30, lum: -1, hot: -1, big: -1, ruwe: 99, bright: 99, mp: 1e9 };
   var dBox = fvNotableBoxD(scene), d2Box = dBox * dBox, ruweMax = (typeof FVS !== "undefined" && FVS.RUWE_MAX > 0) ? FVS.RUWE_MAX : FV_NOTABLE.MP_RUWE, nGsp = 0;
   for (i = 0; i < S.n; ++i) {
      if (!S.inFrame[i]) continue;
      if (typeof S.meta[i].mhPhot === "number" && isFinite(S.meta[i].mhPhot)) ++nGsp;      // (T1-A) cuantas estrellas del marco traen el [M/H] de GSP-Phot (con GAVO o sin red, ninguna)
      var m = S.meta[i], inBox = (!(dBox > 0) || S.x[i] * S.x[i] + S.y[i] * S.y[i] + S.z[i] * S.z[i] <= d2Box), reach = inBox || !FV_NOTABLE.BOX_ALL;     // (B1) reach: la nave puede llegar (BOX_ALL false = todas, como antes)
      if (S.q[i] === 0 && inBox) {
         if (FV_NOTABLE.BRIGHTEST && S.g[i] < v.bright) { v.bright = S.g[i]; c.bright = i; }
         if (FV_NOTABLE.METALPOOR && typeof m.mhPhot === "number" && isFinite(m.mhPhot) && S.g[i] < FV_NOTABLE.MP_GMAX && typeof m.ruwe === "number" && isFinite(m.ruwe) && m.ruwe < ruweMax &&
             (typeof fvsMetalPhotOk !== "function" || fvsMetalPhotOk(m.mhPhot, m.mhPhotT)) && m.mhPhot < v.mp) { v.mp = m.mhPhot; c.mp = i; }
      }
      if (S.q[i] === 0) {
         if (S.dEarth[i] < v.near) { v.near = S.dEarth[i]; c.near = i; }
         if (reach && S.g[i] < 15 && typeof fvsStar === "function" && m.teff > 0) {
            var inp = { teff: m.teff, G: S.g[i], ruwe: m.ruwe, rgeo: { pc: m.distPc, lo: m.lo || NaN, hi: m.hi || NaN } };
            if (m.dust && m.dust.ag > 0) { inp.AG = m.dust.ag; inp.sigmaAG = 0.2 * m.dust.ag + 0.05; }
            var st = fvsStar(inp);
            if (st.lum > v.lum) { v.lum = st.lum; c.lum = i; }
            if (st.radius > v.big) { v.big = st.radius; c.big = i; }
            if (m.teff > v.hot) { v.hot = m.teff; c.hot = i; }
         }
      }
      if (reach && m.ruwe >= 2 && S.g[i] < 13 && S.g[i] < v.ruwe) { v.ruwe = S.g[i]; c.ruwe = i; }
   }
   function add(i2, why, bonus) { if (i2 >= 0 && !used[i2]) { used[i2] = true; out.push({ i: i2, why: why, bonus: bonus }); } }
   add(c.lum, "luminous", 2); add(c.near, "nearest", 1.5); add(c.hot, "hottest", 1.5); add(c.big, "largest", 1.5); add(c.ruwe, "binary", 0.5);
   add(c.bright, "brightest", 1.5); add(c.mp, "metalpoor", 0.8);
   // (T1-A) la fila «metalpoor» sin estrella: «nogsp» = ninguna estrella trae el dato; «cut» = lo traen pero ninguna pasa el corte de calidad. Si la eligio otro criterio (used) no es «sin datos»
   out.noData = [];
   if (FV_NOTABLE.NODATA_ROW && FV_NOTABLE.METALPOOR && c.mp < 0) out.noData.push({ why: "metalpoor", reason: nGsp === 0 ? "nogsp" : "cut", bonus: 0.8 });
   return out;
}

// ---------------------------------------------------------------------------
// LA FICHA (contrato con A): la misma forma y el mismo tono que la de una estrella (fvCardContent de src/ui/fv_hud.js):
//   { title, sub, l1: [frases], l2: [frases del «más»], stamp: { word, src, col }, kind: "object", col, portBmp (Bitmap del recorte: la
//   portilla), objType }. Frases de distancia, escala, luz y viaje de src/science (fvsLightPhrase redondea al error).
// ---------------------------------------------------------------------------
var FV_OBJ_TX = {
   en: {
      "cine.pn": "A dying star blew off its outer layers; the hot core left behind lights them up. In a few tens of thousands of years it will fade away.",
      "cine.galaxy": "Another galaxy: an island of hundreds of millions of suns, far beyond our own Milky Way.",
      "cine.cluster": "Stars born together from the same cloud, still travelling side by side.",
      "cine.nebula": "A cloud of gas glowing in the light of the young stars inside it.",
      "cine.quasar": "The blazing heart of a far-away galaxy: matter falling into a giant black hole outshines all its stars.",
      "cine.other": "Something compact and bright in your photo that is not a star.",
      "cine.snr": "The expanding debris of a star that exploded.",
      "why.luminous": "The most luminous star measured in your photo.", "why.nearest": "The nearest star measured in your photo.",
      "why.hottest": "The hottest star measured in your photo.", "why.largest": "The largest star measured in your photo.",
      "why.brightest": "The brightest star of your photo in the sky (lowest G magnitude; it is not necessarily the one that gives off the most light).",
      "why.metalpoor": "Possibly the most metal-poor star of your photo. DOUBTFUL: it comes from the Gaia photometric estimate (GSP-Phot, about ±0.26 dex), and the extreme of a list is often its biggest error.",
      "why.binary": "Its position wobbles (RUWE {r}): probably a double star or an unseen companion.",
      "why.central": "The central star of {n}: the hot core whose light makes the nebula glow.",
      "size.meas": "{d}′ across in your photo", "size.cat": "{d}′ across (catalogue)",
      "size.note": "Size measured on YOUR photo without stars, down to 3 × the sky noise: it depends on how the photo was stretched (the faint halo counts). Catalogue: {c}.",
      "size.noteNoCat": "Size measured on YOUR photo without stars, down to 3 × the sky noise: it depends on how the photo was stretched (the faint halo counts).",
      "size.notSeen": "It does not stand out of the sky in your photo: the size is the catalogue one.",
      "dist.err": "± {e} light-years", "dist.ass": "Distance ASSUMED: {why}.", "dist.cat": "Distance from a catalogue, not a direct measurement: {why}.",
      "dist.central": "Distance of its central star (Gaia DR3): the star sits inside its nebula.", "dist.centralS": "Distance of its central star (Gaia DR3): the star sits inside its nebula. SIMBAD gives {s} light-years.",
      "vol.shells": "The 3D shape is a RECREATION: the photo only shows one face. Seen from the side it is drawn as a ball of layers cut from your photo.",
      "vol.disc": "The 3D shape is a RECREATION: a thin disc cut from your photo (its true tilt is not known).",
      "vol.none": "In 3D its stars are the stars of the scene.",
      "ass.gal": "a typical galaxy 30 000 light-years across, seen this size", "ass.pn": "a typical planetary nebula 1 light-year across, seen this size",
      "ass.neb": "the distance assumed for the nebula of the photo", "ass.none": "no distance in the catalogues",
      "z": "Redshift z = {z}: the light set off {t} ago.",
      "stamp.meas": "MEASURED", "stamp.cat": "DOUBTFUL", "stamp.ass": "ASSUMED",
      "cine.exo": "A world circling another sun. We know it because it crosses in front of its star and dims it a little, again and again.",
      "exo.host": "around {h}", "exo.year": "Its year lasts {p} days.", "exo.radE": "{e} times the size of the Earth.", "exo.radJ": "{j} times the size of Jupiter ({e} Earths).",
      "exo.teq": "About {t} K on its surface ({c} °C), heated by its star.", "exo.orbit": "It orbits {a} AU from its star.", "exo.depth": "When it crosses, the star dims {d} %.",
      "exo.dur": "Each crossing lasts {h} hours.", "exo.matchId": "Matched to the star of your photo by its Gaia DR3 identifier.",
      "exo.matchPos": "Matched to the star of your photo by position and a compatible parallax (no Gaia identifier to compare).",
      "exo.stampPos": "match by position + parallax", "exo.src": "Planet data: NASA Exoplanet Archive (pscomppars).",
      "seen": "Seen in your photo with signal/noise {s}.", "members": "{n} member stars found in your photo (Gaia proper motions)."
   },
   es: {
      "cine.pn": "Una estrella moribunda expulsó sus capas de fuera; el núcleo caliente que quedó las ilumina. En unas decenas de miles de años se apagará.",
      "cine.galaxy": "Otra galaxia: una isla de cientos de millones de soles, mucho más allá de nuestra Vía Láctea.",
      "cine.cluster": "Estrellas nacidas juntas de la misma nube, que aún viajan lado a lado.",
      "cine.nebula": "Una nube de gas que brilla con la luz de las estrellas jóvenes que lleva dentro.",
      "cine.quasar": "El corazón ardiente de una galaxia lejanísima: la materia que cae en un agujero negro gigante brilla más que todas sus estrellas.",
      "cine.other": "Algo compacto y brillante en tu foto que no es una estrella.",
      "cine.snr": "Los restos en expansión de una estrella que estalló.",
      "why.luminous": "La estrella más luminosa medida en tu foto.", "why.nearest": "La estrella más cercana medida en tu foto.",
      "why.hottest": "La estrella más caliente medida en tu foto.", "why.largest": "La estrella más grande medida en tu foto.",
      "why.brightest": "La estrella más brillante de tu foto en el cielo (menor magnitud G; no es necesariamente la que más luz emite).",
      "why.metalpoor": "Posiblemente la estrella más pobre en metales de tu foto. DUDOSO: sale de la estimación fotométrica de Gaia (GSP-Phot, unos ±0,26 dex) y el extremo de una lista suele ser su mayor error.",
      "why.binary": "Su posición se tambalea (RUWE {r}): seguramente es doble o tiene una compañera que no se ve.",
      "why.central": "La estrella central de {n}: el núcleo caliente cuya luz hace brillar la nebulosa.",
      "size.meas": "{d}′ de lado a lado en tu foto", "size.cat": "{d}′ de lado a lado (catálogo)",
      "size.note": "Tamaño medido en TU foto sin estrellas, hasta 3 veces el ruido del cielo: depende de cómo se estiró la foto (cuenta el halo débil). Catálogo: {c}.",
      "size.noteNoCat": "Tamaño medido en TU foto sin estrellas, hasta 3 veces el ruido del cielo: depende de cómo se estiró la foto (cuenta el halo débil).",
      "size.notSeen": "En tu foto no destaca del cielo: el tamaño es el del catálogo.",
      "dist.err": "± {e} años luz", "dist.ass": "Distancia SUPUESTA: {why}.", "dist.cat": "Distancia de catálogo, no una medida directa: {why}.",
      "dist.central": "Distancia de su estrella central (Gaia DR3): la estrella queda dentro de su nebulosa.", "dist.centralS": "Distancia de su estrella central (Gaia DR3): la estrella queda dentro de su nebulosa. SIMBAD da {s} años luz.",
      "vol.shells": "La forma en 3D es una RECREACIÓN: la foto solo enseña una cara. De lado se dibuja como una bola de capas recortadas de tu foto.",
      "vol.disc": "La forma en 3D es una RECREACIÓN: un disco fino recortado de tu foto (no se sabe su inclinación real).",
      "vol.none": "En 3D, sus estrellas son las estrellas de la escena.",
      "ass.gal": "una galaxia típica de 30 000 años luz que se ve de este tamaño", "ass.pn": "una planetaria típica de 1 año luz que se ve de este tamaño",
      "ass.neb": "la distancia supuesta para la nebulosa de la foto", "ass.none": "sin distancia en los catálogos",
      "z": "Corrimiento al rojo z = {z}: la luz salió hace {t}.",
      "stamp.meas": "MEDIDO", "stamp.cat": "DUDOSO", "stamp.ass": "SUPUESTO",
      "cine.exo": "Un mundo que gira alrededor de otro sol. Lo sabemos porque pasa por delante de su estrella y la apaga un poco, una y otra vez.",
      "exo.host": "alrededor de {h}", "exo.year": "Su año dura {p} días.", "exo.radE": "{e} veces el tamaño de la Tierra.", "exo.radJ": "{j} veces el tamaño de Júpiter ({e} Tierras).",
      "exo.teq": "Unos {t} K en su superficie ({c} °C), calentado por su estrella.", "exo.orbit": "Gira a {a} UA de su estrella.", "exo.depth": "Cuando pasa, la estrella se apaga un {d} %.",
      "exo.dur": "Cada paso dura {h} horas.", "exo.matchId": "Casado con la estrella de tu foto por su identificador de Gaia DR3.",
      "exo.matchPos": "Casado con la estrella de tu foto por posición y paralaje compatible (no hay identificador de Gaia que comparar).",
      "exo.stampPos": "cruce por posición + paralaje", "exo.src": "Datos del planeta: NASA Exoplanet Archive (pscomppars).",
      "seen": "Se ve en tu foto con señal/ruido {s}.", "members": "{n} estrellas del cúmulo encontradas en tu foto (movimientos propios de Gaia)."
   }
};
function fvObjTx(key, p, lang) {
   var L = (lang === "es") ? "es" : "en", s = FV_OBJ_TX[L][key] || FV_OBJ_TX.en[key] || key;
   if (p) for (var k in p) if (p.hasOwnProperty(k)) s = s.split("{" + k + "}").join(String(p[k]));
   return s;
}
function fvObjNum(x, dec, L) { return (typeof fvsFmtNum === "function") ? fvsFmtNum(x, dec, L) : x.toFixed(dec); }
function fvObjectCard(scene, i, lang) {
   var L = lang || (typeof FV_LANG !== "undefined" ? FV_LANG : "en"), O = scene && scene.objects, o = O ? O[i] : null;
   if (!o) return null;
   var cardOf = (typeof fvCardContent === "function") ? fvCardContent : null, C;
   // la nebulosa principal y las estrellas: su ficha de siempre, con el motivo delante
   if (o.main && cardOf) {
      C = cardOf(scene, { kind: "nebula" }, L); C.kind = "object"; C.objType = "nebula";
      var NN = scene.nebula, lk = (L === "es") ? "es" : "en";
      if (NN && NN.names && NN.names[lk]) C.title = fvObjTitle(NN.names[lk], NN.id);      // (N3) una designacion escrita de dos maneras (SH 2-131 / Sh 2-131) sale una vez
      return C;
   }
   if (o.type === "star" && o.star >= 0 && cardOf) {
      C = cardOf(scene, { kind: "star", i: o.star }, L);
      var wl = (o.why === "central") ? fvObjTx("why.central", { n: o.ofName || "" }, L) : fvObjTx("why." + o.why, { r: (scene.stars.meta[o.star].ruwe || 0).toFixed(2) }, L);
      C.l1.unshift(wl); C.kind = "object"; C.objType = "star"; return C;
   }
   if (o.type === "exoplanet") return fvObjExoCard(scene, o, L);
   var year = (scene.field && scene.field.obsYear) || (new Date()).getFullYear(), lab = o.typeLabel[(L === "es") ? "es" : "en"];
   C = { kind: "object", objType: o.type, l1: [], l2: [], col: 0xffffff };
   C.title = o.name;
   var dArc = (o.sizeArcmin > 0) ? o.sizeArcmin : (o.sizeCatArcmin > 0 ? o.sizeCatArcmin : 0);
   C.sub = fvsCapS(lab) + (dArc > 0 ? " · " + fvObjTx((o.seg && o.seg.ok) ? "size.meas" : "size.cat", { d: fvObjNum(dArc, dArc < 10 ? 1 : 0, L) }, L) : "");
   C.l1.push(fvObjTx("cine." + (o.subtype === "snr" ? "snr" : o.type), null, L));
   var sci = (typeof fvsT === "function");
   if (sci) {
      C.l1.push(fvsCapS(fvsT(L, "dist", { ly: fvsFmtSig(o.distLy, 3, L) + (o.distErrLy > 0 ? " ± " + fvsFmtSig(o.distErrLy, 2, L) : ""), pc: fvsFmtSig(o.distLy / FV_LY_PER_PC, 3, L) })));
      if (dArc > 0 && o.type !== "quasar") { var SP = fvsScalePhrases(dArc, o.distLy, L); C.l1.push(fvsCapS(SP.size)); C.l2.push(fvsCapS(SP.lightCross)); C.l2.push(fvsCapS(SP.sand)); C.l2.push(fvsCapS(SP.sandObject)); }
      if (o.type === "quasar" && o.lookbackYr > 0) C.l1.push(fvObjTx("z", { z: fvObjNum(o.z, 3, L), t: fvsFmtDuration(o.lookbackYr, L) }, L));
      else C.l1.push(fvsLightPhrase(o.distLy, L, year, o.distErrLy > 0 ? o.distErrLy : (o.distSrc === "assumed" ? 0.5 * o.distLy : 0)));
      if (typeof fvsTravelPhrases === "function" && o.type !== "quasar") C.l2.push(fvsCapS(fvsTravelPhrases(o.distLy, L).warp));
   } else C.l1.push(Math.round(o.distLy) + " ly");
   if (o.seg && o.seg.ok) {
      C.l2.push(o.sizeCatArcmin > 0 ? fvObjTx("size.note", { c: fvObjNum(o.sizeCatArcmin, 2, L) + "′ (" + ((L === "es" && o.sizeSrc === "isophote 26, SGA-2020") ? "isofota 26, SGA-2020" : (o.sizeSrc || "SIMBAD")) + ")" }, L) : fvObjTx("size.noteNoCat", null, L));
      C.l2.push(fvObjTx("seen", { s: fvObjNum(o.seg.snr, 0, L) }, L));
   } else if (o.type !== "cluster" && o.type !== "quasar") C.l2.push(fvObjTx("size.notSeen", null, L));
   if (o.type === "cluster" && o.members > 0) C.l2.push(fvObjTx("members", { n: o.members }, L));
   if (o.distSrc === "assumed") C.l2.push(fvObjTx("dist.ass", { why: fvObjTx(o.assWhy || "ass.none", null, L) }, L));
   else if (o.distSrc === "catalog") C.l2.push(fvObjTx("dist.cat", { why: o.distRef }, L));
   else if (o.distFromStar) C.l2.push(fvObjTx(o.simbadLy > 0 ? "dist.centralS" : "dist.central", { s: o.simbadLy > 0 ? fvObjNum(Math.round(o.simbadLy / 10) * 10, 0, L) : "" }, L));
   C.l2.push(fvObjTx(o.type === "galaxy" ? "vol.disc" : (o.type === "cluster" || o.type === "quasar" ? "vol.none" : "vol.shells"), null, L));
   var col = (typeof FV_HUD_COL !== "undefined") ? FV_HUD_COL : { stampOk: 0xff2F6B3A, stampWarn: 0xff9A6A12, stampBad: 0xffA8321E };
   // (PL-7, 5-nov) grade: el grado del sello («ok» / «warn» / «bad»), para que el visor web no lo recalcule por su cuenta
   if (o.distSrc === "measured") C.stamp = { word: fvObjTx("stamp.meas", null, L), src: o.distRef, col: col.stampOk, grade: "ok" };
   else if (o.distSrc === "catalog") C.stamp = { word: fvObjTx("stamp.cat", null, L), src: o.distRef, col: col.stampWarn, grade: "warn" };
   else C.stamp = { word: fvObjTx("stamp.ass", null, L), src: fvObjTx(o.assWhy || "ass.none", null, L), col: col.stampBad, grade: "bad" };
   if (o.colAvg !== undefined) C.col = o.colAvg;
   if (o._gfx && o._gfx.cutBmp) C.portBmp = o._gfx.cutBmp;
   C.l1 = C.l1.filter(function(x) { return !!x; }); C.l2 = C.l2.filter(function(x) { return !!x; });
   return C;
}
// (N12) LA FICHA DEL PLANETA: frase de cine, y los datos del NASA Exoplanet Archive (pscomppars: parametros compuestos de la literatura,
// MEDIDOS por transito o velocidad radial). El sello dice si el cruce con la estrella es seguro (mismo gaia_dr3_id: MEDIDO) o por posicion
// y paralaje compatible (DUDOSO). La distancia es la de la estrella de la escena.
// (Blender 5 · H4) false = la ficha de Blender 4 (la distancia de la estrella del campo y «alrededor de» siempre; el ROJO de la prueba)
var FV_EXO_DEMO_CARD = true;
// (Blender 5b) interruptores de las correcciones de la ronda 5b: apagado = lo de Blender 5 (el ROJO de cada comprobacion de tests/fv_pl3d_app_test.js).
// DEMO_NAV: la fila de MIRABILIA del planeta de demostracion lleva «DEMO ·» (R5-1) · DEMO_MORE: el texto de MAS de la ficha DEMO no afirma el cruce (R5-2) ·
// DEST: el rotulo DESTINO no queda bajo el disco ni la escuadra (R5-3) · HERE: «estas aqui» con el mismo criterio en la ficha de la estrella y la del planeta (R5-8.1-2) ·
// NUMS: cifras de la ficha del planeta y del panel rotuladas como lo que son (R5-8.4-5) · DIST: PROFUNDITAS y DISTANTIA con la misma cifra (R5-8.6) ·
// FMT: formato numerico por idioma en el cockpit (R5-11) · SPT: el tipo espectral del panel XP de la web con la extincion del polvo (R5-8.3)
var FV_B5B = { DEMO_NAV: true, DEMO_MORE: true, DEST: true, HERE: true, NUMS: true, DIST: true, FMT: true, SPT: true };
// (Blender 5b · R5-1) el objeto «exoplaneta» de la escena es de DEMOSTRACION si su cruce no es ni «gaia-id» ni «position» (la fila inyectada)
function fvObjIsDemo(o) {
   return !!(o && o.type === "exoplanet" && o.match !== undefined && o.match !== "gaia-id" && o.match !== "position" && FV_EXO_DEMO_CARD && FV_B5B.DEMO_NAV);
}
// (Blender 5b · R5-8) la estrella a la que apunta una seleccion: la propia (kind «star») o la de un objeto «estrella» / «exoplaneta» de la escena; -1 si no es de una estrella.
// «Estas aqui» se decide por la ESTRELLA: llegar a una estrella y mirar la ficha de su planeta (u otra seleccion de la misma estrella) es estar en el mismo sitio
function fvSelHostStar(scene, sel) {
   if (!sel) return -1;
   if (sel.kind === "star") return sel.i;
   if (sel.kind === "object" && scene && scene.objects) { var o = scene.objects[sel.i]; if (o && (o.type === "exoplanet" || o.type === "star") && o.star >= 0) return o.star; }
   return -1;
}
// ¿es esta la misma llegada? (la de siempre: mismo tipo e indice; con FV_B5B.HERE, tambien la misma estrella)
function fvSelSameArrival(scene, arrived, sel) {
   if (!arrived || !sel) return false;
   if (arrived.kind === sel.kind && (sel.kind === "nebula" || arrived.i === sel.i)) return true;
   if (!FV_B5B.HERE) return false;
   var a = fvSelHostStar(scene, arrived);
   return a >= 0 && a === fvSelHostStar(scene, sel);
}
function fvObjExoCard(scene, o, L) {
   var r = o.planet || {}, S = scene.stars, i = o.star, C = { kind: "object", objType: "exoplanet", l1: [], l2: [], col: S ? (S.col[i] >>> 0) : 0xffffff };
   C.title = String(r.pl_name || o.name);
   // (Blender 5 · H4) un planeta de DEMOSTRACION (la fila inyectada sobre una estrella de tu foto que no es la suya: ni «gaia-id» ni «position»):
   // marca DEMO en el subtitulo, en la primera frase y en el sello; su distancia es la de SU estrella (sy_dist, en pc), nunca la de la estrella del
   // campo; y sin estrella con nombre no se dice «alrededor de» (los casos de prueba). fvTx: src/ui/fv_text.js (bloque «Blender 5»)
   var demo = (o.match !== "gaia-id" && o.match !== "position") && typeof fvTx === "function" && FV_EXO_DEMO_CARD, host = String(r.hostname || ""), tl = fvsCapS(o.typeLabel[(L === "es") ? "es" : "en"]);
   if (demo) C.sub = host ? fvTx("b5.demoSub", { t: tl, h: host }, L) : fvTx("b5.demoSubNoHost", { t: tl }, L);
   else C.sub = tl + (host || !FV_EXO_DEMO_CARD ? " · " + fvObjTx("exo.host", { h: host }, L) : "");
   if (demo) C.l1.push(fvTx("b5.demoCard", { d: ((typeof fvsT === "function" && S) ? fvsFmtSig(S.dEarth[i], 3, L) + " " + fvsT(L, "u.ly") : "?") }, L));
   C.l1.push(fvObjTx("cine.exo", null, L));
   if (r.pl_orbper > 0) C.l1.push(fvObjTx("exo.year", { p: fvObjNum(r.pl_orbper, r.pl_orbper < 10 ? 2 : 1, L) }, L));
   if (r.pl_rade > 0) C.l1.push(fvObjTx(r.pl_rade >= 6 ? "exo.radJ" : "exo.radE", { e: fvObjNum(r.pl_rade, 1, L), j: fvObjNum(r.pl_rade / 11.21, 2, L) }, L));
   if (r.pl_eqt > 0) C.l1.push(fvObjTx("exo.teq", { t: fvObjNum(r.pl_eqt, 0, L), c: fvObjNum(r.pl_eqt - 273.15, 0, L) }, L));
   if (demo) {
      // (Blender 5 · H4) la distancia de SU estrella (NASA Exoplanet Archive, sy_dist en pc); sin ella, nada. El viaje (warp) es a la estrella del campo: no se dice
      if (typeof fvsT === "function" && r.sy_dist > 0) { var dO = r.sy_dist * FV_LY_PER_PC; C.l1.push(fvTx("b5.demoOwn", { h: host || String(r.pl_name || ""), d: fvsT(L, "dist", { ly: fvsFmtSig(dO, 3, L), pc: fvsFmtSig(r.sy_dist, 3, L) }) }, L)); }
   } else if (typeof fvsT === "function" && S) {
      var d = S.dEarth[i];
      C.l1.push(fvsCapS(fvsT(L, "dist", { ly: fvsFmtSig(d, 3, L), pc: fvsFmtSig(d / FV_LY_PER_PC, 3, L) })));
      if (typeof fvsTravelPhrases === "function") C.l2.push(fvsCapS(fvsTravelPhrases(d, L).warp));
   }
   if (r.pl_orbsmax > 0) C.l2.push(fvObjTx("exo.orbit", { a: fvObjNum(r.pl_orbsmax, 3, L) }, L));
   // (Blender 5b · R5-8.4-5) la ficha da las cifras del ARCHIVO (profundidad y duracion publicadas) y el panel del transito las de su MODELO (limbo oscurecido,
   // geometria de la orbita): no son la misma magnitud y por eso decian 2,40 % / 1,82 horas frente a 2,6 % / 1 h 48 min. Con las dos a la vista, la ficha las rotula
   var trm = null;
   if (FV_B5B.NUMS && typeof fvsTransitSetup === "function" && typeof fvTx === "function" && typeof fvsFmtPct === "function" && typeof fvsFmtDuration === "function") { try { trm = fvsTransitSetup(r); } catch (eTm) { trm = null; } }
   if (r.pl_trandep > 0) C.l2.push((trm && trm.depthLD > 0) ? fvTx("b5b.depth", { d: fvObjNum(r.pl_trandep, 2, L), q: fvsFmtPct(trm.depthLD, L, trm.depthLD < 0.01 ? 2 : 1) }, L) : fvObjTx("exo.depth", { d: fvObjNum(r.pl_trandep, 2, L) }, L));
   if (r.pl_trandur > 0) C.l2.push((trm && trm.t14 > 0) ? fvTx("b5b.dur", { h: fvObjNum(r.pl_trandur, 2, L), q: fvsFmtDuration(trm.t14 / 24 / 365.25, L) }, L) : fvObjTx("exo.dur", { h: fvObjNum(r.pl_trandur, 2, L) }, L));
   // (Blender 5b · R5-2) el planeta de DEMOSTRACION no esta casado con la estrella de la foto: MAS no dice que lo este (antes: «Casado con la estrella de tu foto por posicion
   // y paralaje compatible», contra «No gira alrededor de esa estrella» de la primera frase)
   if (!(demo && FV_B5B.DEMO_MORE)) C.l2.push(fvObjTx(o.match === "gaia-id" ? "exo.matchId" : "exo.matchPos", null, L));
   C.l2.push(fvObjTx("exo.src", null, L));
   var col = (typeof FV_HUD_COL !== "undefined") ? FV_HUD_COL : { stampOk: 0xff2F6B3A, stampWarn: 0xff9A6A12 };
   // el sello de un planeta califica el CRUCE con su estrella (no la distancia): MEDIDO solo si el archivo da su gaia_dr3_id
   C.stamp = (o.match === "gaia-id") ? { word: fvObjTx("stamp.meas", null, L), src: "NASA Exoplanet Archive", col: col.stampOk, grade: "ok" }
                                    : { word: fvObjTx("stamp.cat", null, L), src: fvObjTx("exo.stampPos", null, L), col: col.stampWarn, grade: "warn" };
   if (demo) C.stamp = { word: fvTx("b5.demoWord", null, L), src: fvTx("b5.demoSrc", null, L), col: col.stampWarn, grade: "warn" };
   C.demo = !!demo;
   return C;
}
// (N12) los planetas cruzados con la escena (fvExoMatch) -> entradas de scene.objects. SOLO cruces verdaderos (fvExoForStar: mismo id o
// posicion + paralaje); la fila DEMO de las pruebas (exq.code "injected") no entra: quien llama no pasa esas filas.
function fvObjExoEntries(scene, exList) {
   var out = [];
   if (!scene || !scene.stars || !exList) return out;
   for (var e = 0; e < exList.length; ++e) {
      var x = exList[e], i = x.star;
      if (typeof fvExoForStar === "function" && fvExoForStar(scene, i, [x]) !== x) continue;
      var r = x.row, S = scene.stars, pos = fvStarPos(scene, i);
      out.push({ id: "exo:" + r.pl_name, name: String(r.pl_name), type: "exoplanet", typeLabel: FV_OBJ_LABEL.exoplanet, star: i, hostStar: i, planet: r, match: x.match,
                 px: { x: null, y: null, r: 0 }, pos: pos, distLy: S.dEarth[i], distErrLy: (S.meta[i].lo > 0 && S.meta[i].hi > 0) ? 0.5 * (S.meta[i].hi - S.meta[i].lo) * FV_LY_PER_PC : 0,
                 distSrc: (S.q[i] === 0) ? "measured" : (S.q[i] === 1 ? "catalog" : "assumed"), radiusLy: 0, mag: S.g[i],
                 score: (x.match === "gaia-id") ? FV_OBJ.EXO_SCORE : FV_OBJ.EXO_SCORE_POS, src: "NASA Exoplanet Archive", arriveLy: fvObjStarArrive(scene, i), why: x.match });
   }
   return out;
}
function fvsCapS(s) { return (typeof fvsCap === "function") ? fvsCap(s) : String(s || ""); }

// el texto plano de la lista (pruebas y registro): «9,00 · nebula · IC 1848 · 6 000 ly (measured)»
function fvObjLine(o) {
   return o.score.toFixed(2) + " · " + o.type + " · " + o.name + " · " + Math.round(o.distLy) + " ly (" + o.distSrc + (o.distErrLy > 0 ? " ± " + Math.round(o.distErrLy) : "") + ")" +
          " · px (" + Math.round(o.px.x) + ", " + Math.round(o.px.y) + ") r " + (o.px.r > 0 ? o.px.r.toFixed(1) : "?") + (o.seg ? (o.seg.ok ? " · seg snr " + o.seg.snr.toFixed(0) : " · seg: " + o.seg.why) : "") +
          (o.star >= 0 ? " · star " + o.star : "") + (o.why ? " · " + o.why : "") + " · arrive " + (o.arriveLy > 0 ? o.arriveLy.toPrecision(3) : "?") + " ly";
}
