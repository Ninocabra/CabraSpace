// ============================================================================
// FieldVoyager/src/engine/fv_ambient.js — EL CAMPO DE ESTRELLAS DE FONDO, SIMULADO y con PARALAJE (11-nov-2026, revision de la navegacion)
// ----------------------------------------------------------------------------
// Por que: el catalogo solo tiene las estrellas del cono de la foto (~1°) y el pintor, con razon, apaga fuera de casa casi todas las que
// no estan cerca (reglas del cono, la huella, el tubo). Resultado medido: lejos de casa quedan 0–20 estrellas pintadas, el cielo es negro
// y, como nada pasa cerca de la nave, no hay sensacion de velocidad ni de sitio (docs/navegacion/06-revision-navegabilidad.md).
// En la Galaxia de verdad, desde CUALQUIER punto del disco se ven miles de estrellas a simple vista: el negro no es «honesto», es el
// hueco del catalogo. Aqui, un campo de estrellas ESTADISTICO que lo rellena (la placa DATOS lo dice: «fondo simulado»):
//   · no son estrellas del catalogo: no se eligen, no tienen ficha, no cuentan como paisaje para el laboratorio, no salen en los mapas
//   · viven en el espacio de VUELO (lo que se ve: x, y × S; z), en un mosaico periodico de OCT octavas: la octava k repite N puntos
//     en un cubo de lado L0·STEP^k; de cada una se ve la esfera de radio L/2 alrededor de la camara, con el brillo ∝ 1/d² y fundido en el borde
//     (nada aparece ni desaparece de golpe). Octavas pequeñas = paralaje al moverse despacio; grandes = al viajar deprisa
//   · una octava se apaga cuando la nave cruza su celda en menos de T_LO s (parpadearia); las que pasan se pintan como trazo (desenfoque de
//     movimiento de EXPO s): eso es la velocidad
//   · la cantidad sigue la densidad del disco del MISMO modelo de la Via Lactea de fondo (FV_GALMOD, fvMwRho) en la posicion REAL de la camara:
//     al salir del disco (M 82, a 1,2 kpc sobre el plano) el campo se aclara, con suelo RHO_MIN (ELECCION NUESTRA: sin suelo no queda paralaje)
//   · peso 0 en casa (la foto es la foto) y 1 al alejarse lo mismo que la Via Lactea de fondo (FV_PAINT.MW_AWAY); se apaga con su mismo boton
// FV_AMB.ON = false: no se llama nada de aqui y el pintor es el de antes BIT A BIT.
// ES5. La parte de arriba es pura (node la prueba: tests/fv_ambient_node.js); fvAmbPaint usa Bitmap / Pen (solo PixInsight).
// ============================================================================

var FV_AMB = { ON: true,
               N: 24000, N0: 5000, OCT: 7, L0: 3, STEP: 4,   // N = el juego de puntos; N0 = los que se usan con la densidad del Sol y la lente de FOV0. 7 octavas: celdas de 3 · 12 · 48 · 192 · 768 · 3 072 · 12 288 a.l. (de vuelo)
               FOV0: 50, FOV_K: [0.6, 4],                // con la lente mas cerrada se usan mas puntos (∝ 1 / angulo solido, hasta × 4: con × 8 costaba 3 ms por fotograma con la lente cerrada de HOY, medido el 11-nov): un teleobjetivo ve estrellas mas debiles, no un cielo vacio
               EDGE: 0.3,                                // fundido en el ultimo 30 % del radio de la esfera vista
               B0: 0.065,                                // I = LUM · B0 / dn² (dn = distancia / radio de la esfera vista), con tope 1
               I_MIN: 0.06,                              // por debajo no se pinta
               T_LO: 0.5, T_HI: 1.4,                     // s que tarda la nave en cruzar la celda: la octava se apaga por debajo de T_LO, entera desde T_HI
               EXPO: 1 / 40,                             // s de «exposicion» del trazo (desenfoque de movimiento)
               STREAK_MIN: 1.6, STREAK_MAX: 0.09,        // px minimos para pintar trazo en vez de punto; largo maximo (fraccion del ancho: con 0,16 eran rayas de 200 px, «arañazos»; con 0,075 aun tachaban la ficha, revision visual del 11-nov)
               STREAK_DIM: 30,                           // un trazo de mas de STREAK_DIM px reparte su luz: intensidad × sqrt(STREAK_DIM / largo)
               PHOTO_MASK: 0.03, MASK_S: 0.35,                        // SOBRE LA FOTO no hay campo: dentro del cuadrilatero de la foto en pantalla se apaga, con una rampa de PHOTO_MASK × ancho hacia dentro (ahi el catalogo SI esta completo y la foto ya trae sus estrellas; puntos y trazos falsos encima eran el defecto 1 de la revision visual). 0 = sin mascara (ROJO)
               RHO_POW: 0.5, RHO_MIN: 0.45, RHO_MAX: 1.3,   // la cantidad va con (densidad relativa a la del Sol)^RHO_POW, entre RHO_MIN y RHO_MAX (ELECCION NUESTRA: con la densidad tal cual, a 15 000 a.l. hacia el anticentro quedaban 20 estrellas, medido el 11-nov)
               WARP_OFF: [0.02, 0.14],                   // en el warp (P.trail, solo con el vuelo de tipo warp) el campo se apaga: ya estan las estelas y el polvo de warp. (11-nov, tras NV-15) [0,15, 0,5] dejaba el campo entero en la preparacion (trail 0,14) y, con la variante C, fv_nB2_test W1 volvia a rojo (luz por estela 329 frente a 221)
               // CRUISE: viajando deprisa las octavas pequeñas se apagan y quedan 2–3 de 7: el cielo se vacia justo cuando hace falta (hoja de contacto del
               // video H, 11-nov: 6 s de pantalla casi negra). Con CRUISE = 1 se usan mas puntos de las octavas que quedan, hasta compensar (tope CRUISE_MAX);
               // 0 = sin compensar (lo de la noche del 10 al 11)
               CRUISE: 1, CRUISE_MAX: 3,
               // (11-nov, NV-15) Nino eligio la VARIANTE C en el video de variantes (tests/_nav11/out/video_H_variantes_ABC.mp4): crucero compensado,
               // GAIN 1,6, N0 5 000, trazos hasta el 9 % del ancho y STREAK_DIM 30. La A era N0 3 600 · CRUISE 0 · GAIN 1 · 4,5 % · 14
               GAIN: 1.6,                                // brillo global
               SEED: 20261111 };
var FV_AMB_BREAK = "";      // control en ROJO de las pruebas: "static" = sin paralaje (la camara no se resta) · "nofade" = sin fundido de borde

// los N puntos del cubo unidad, su luminosidad relativa (pocas brillantes, muchas debiles) y su color (indice 0..5: de azulada a naranja)
function fvAmbBuild(N, seed) {
   var rg = fvRng(seed >>> 0), p = new Float32Array(3 * N), lum = new Float32Array(N), col = new Uint8Array(N);
   for (var i = 0; i < N; ++i) {
      p[3 * i] = rg(); p[3 * i + 1] = rg(); p[3 * i + 2] = rg();
      var u = rg(); lum[i] = 0.35 + 2.65 * u * u * u;                 // 0,35 … 3 (mediana ~0,7): una de cada ~10 pasa de 2
      var c = rg(); col[i] = c < 0.10 ? 0 : (c < 0.32 ? 1 : (c < 0.60 ? 2 : (c < 0.80 ? 3 : (c < 0.93 ? 4 : 5))));
   }
   // desplazamiento y permutacion de ejes de cada octava (para que no se vea que es el mismo juego de puntos)
   var off = new Float32Array(3 * 16);
   for (i = 0; i < 48; ++i) off[i] = rg();
   return { n: N, p: p, lum: lum, col: col, off: off };
}
function fvAmbFrac(x) { x = x - Math.floor(x); return x; }
// densidad del disco (relativa a la del Sol) en la posicion REAL de la camara (a.l., mundo de la escena); sin marco galactico, 1
function fvAmbRho(frame, camLy) {
   if (!frame || typeof fvMwRho !== "function" || typeof FV_GALMOD === "undefined") return 1;
   var k = 1 / (1000 * FV_LY_PER_PC), c = [camLy[0] * k, camLy[1] * k, camLy[2] * k];
   // fvMwRho(x, y, z) toma x, y, z GALACTOCENTRICOS en kpc (R = sqrt(x² + y²)): el Sol esta en x = −R0 (el centro, hacia ex desde el Sol),
   // igual que en fvMwMap (px = cx + s·dx − R0)
   var r = fvMwRho(fvDot(c, frame.ex) - FV_GALMOD.R0, fvDot(c, frame.ey), fvDot(c, frame.ez) + FV_GALMOD.ZSUN);
   var r0 = fvMwRho(-FV_GALMOD.R0, 0, FV_GALMOD.ZSUN);
   return (r[0] + r[1]) / Math.max(1e-9, r0[0] + r0[1]);
}
// el peso de la octava de celda L con la nave a |v| (a.l. de vuelo por segundo)
function fvAmbOctW(L, speed) {
   if (!(speed > 1e-9)) return 1;
   return fvSmooth((L / speed - FV_AMB.T_LO) / Math.max(1e-6, FV_AMB.T_HI - FV_AMB.T_LO));
}
// LO QUE SE VE. q = camara en el espacio de vuelo; r, d, fw = base; f, cx, cy, W, H = lente; vel = velocidad de la camara en vuelo (a.l./s);
// rho = densidad relativa; wAll = peso global (casa, warp). Rellena out (Float32Array, 6 por estrella: x, y, cola x, cola y, intensidad 0..1,
// color) y devuelve cuantas. cap = maximo de estrellas (out.length / 6)
function fvAmbCount(rho, f, W) {
   var A = FV_AMB, f0 = (W / 2) / Math.tan(0.5 * A.FOV0 * Math.PI / 180), fk = fvClamp((f / f0) * (f / f0), A.FOV_K[0], A.FOV_K[1]);
   return Math.min(A.N, A.N0 * fvClamp(Math.pow(Math.max(0, rho), A.RHO_POW), A.RHO_MIN, A.RHO_MAX) * fk);
}
function fvAmbVisible(F, q, r, d, fw, f, cx, cy, W, H, vel, rho, wAll, out) {
   var A = FV_AMB, N = F.n, P = F.p, n = 0, cap = Math.floor(out.length / 6);
   var nEff = Math.min(N, fvAmbCount(rho, f, W)), nSoft = 1 / Math.max(1, 0.08 * nEff);
   var speed = vel ? Math.sqrt(vel[0] * vel[0] + vel[1] * vel[1] + vel[2] * vel[2]) : 0, ex = A.EXPO;
   var tx0 = vel ? vel[0] * ex : 0, ty0 = vel ? vel[1] * ex : 0, tz0 = vel ? vel[2] * ex : 0, maxL = A.STREAK_MAX * W;
   if (A.CRUISE > 0 && speed > 0) {
      var sw = 0; for (var kc = 0; kc < A.OCT; ++kc) sw += fvAmbOctW(A.L0 * Math.pow(A.STEP, kc), speed);
      var kcr = 1 + A.CRUISE * (Math.min(A.CRUISE_MAX, A.OCT / Math.max(1e-6, sw)) - 1);
      nEff = Math.min(N, nEff * kcr); nSoft = 1 / Math.max(1, 0.08 * nEff);
   }
   var stat = FV_AMB_BREAK === "static", nof = FV_AMB_BREAK === "nofade", nI = Math.ceil(nEff);
   for (var k = 0; k < A.OCT; ++k) {
      var L = A.L0 * Math.pow(A.STEP, k), wk = fvAmbOctW(L, speed) * wAll;
      if (wk < 0.02) continue;
      var R = 0.5 * L, iL = 1 / L, o = 3 * k, a0 = k % 3, a1 = (k + 1) % 3, a2 = (k + 2) % 3;
      var qx = stat ? 0 : q[0] * iL, qy = stat ? 0 : q[1] * iL, qz = stat ? 0 : q[2] * iL, ox = F.off[o], oy = F.off[o + 1], oz = F.off[o + 2];
      for (var i = 0; i < nI; ++i) {
         var vx = (fvAmbFrac(P[3 * i + a0] + ox - qx) - 0.5) * L, vy = (fvAmbFrac(P[3 * i + a1] + oy - qy) - 0.5) * L, vz = (fvAmbFrac(P[3 * i + a2] + oz - qz) - 0.5) * L;
         var zc = vx * fw[0] + vy * fw[1] + vz * fw[2];
         if (!(zc > 1e-4 * L)) continue;
         var d2 = vx * vx + vy * vy + vz * vz;
         if (d2 > R * R) continue;
         var sx = cx + f * (vx * r[0] + vy * r[1] + vz * r[2]) / zc, sy = cy + f * (vx * d[0] + vy * d[1] + vz * d[2]) / zc;
         if (sx < -40 || sy < -40 || sx > W + 40 || sy > H + 40) continue;
         var dn = Math.sqrt(d2) / R, I = F.lum[i] * A.B0 / (dn * dn);
         if (I > 1) I = 1;
         I *= wk * (nof ? 1 : fvSmooth((1 - dn) / A.EDGE)) * (i > nEff - 1 / nSoft ? Math.max(0, (nEff - i) * nSoft) : 1);
         if (I < A.I_MIN) continue;
         // la cola: donde estaba la estrella hace EXPO s (la nave avanzo vel·EXPO: la estrella, relativa, retrocede al reves)
         var bx = vx + tx0, by = vy + ty0, bz = vz + tz0, zb = bx * fw[0] + by * fw[1] + bz * fw[2], tx = sx, ty = sy;
         if (speed > 0 && zb > 1e-4 * L) {
            tx = cx + f * (bx * r[0] + by * r[1] + bz * r[2]) / zb; ty = cy + f * (bx * d[0] + by * d[1] + bz * d[2]) / zb;
            var lx = tx - sx, ly = ty - sy, ll = Math.sqrt(lx * lx + ly * ly);
            if (ll > maxL) { tx = sx + lx * maxL / ll; ty = sy + ly * maxL / ll; }
         }
         if (n >= cap) return n;
         var j = 6 * n; out[j] = sx; out[j + 1] = sy; out[j + 2] = tx; out[j + 3] = ty; out[j + 4] = I; out[j + 5] = F.col[i]; ++n;
      }
   }
   return n;
}

// cuanto se apaga un punto de pantalla (x, y) por caer dentro del poligono convexo Q (esquinas [x, y] en orden, cualquier sentido):
// 0 fuera o en el borde, 1 a mas de m px hacia dentro. Sin poligono, 0
function fvAmbInQuad(Q, x, y, m) {
   if (!Q || Q.length < 3) return 0;
   var dmin = 1e30, sg = 0, nq = Q.length;
   for (var i = 0; i < nq; ++i) {
      var a = Q[i], b = Q[(i + 1) % nq], ex = b[0] - a[0], ey = b[1] - a[1], el = Math.sqrt(ex * ex + ey * ey);
      if (!(el > 1e-9)) continue;
      var c = (ex * (y - a[1]) - ey * (x - a[0])) / el;
      if (c === 0) return 0;
      if (sg === 0) sg = c > 0 ? 1 : -1; else if ((c > 0 ? 1 : -1) !== sg) return 0;
      if (Math.abs(c) < dmin) dmin = Math.abs(c);
   }
   return fvSmooth(dmin / Math.max(1e-6, m));
}
// el poligono convexo en camara C (puntos [xc, yc, zc]) recortado con el plano cercano zc >= zn y proyectado -> [[x, y], ...] | null
function fvAmbClipProject(C, zn, f, cx, cy) {
   var out = [], n = C.length;
   for (var i = 0; i < n; ++i) {
      var a = C[i], b = C[(i + 1) % n], ain = a[2] >= zn, bin = b[2] >= zn;
      if (ain) out.push([cx + f * a[0] / a[2], cy + f * a[1] / a[2]]);
      if (ain !== bin) { var u = (zn - a[2]) / (b[2] - a[2]), x = a[0] + (b[0] - a[0]) * u, y = a[1] + (b[1] - a[1]) * u; out.push([cx + f * x / zn, cy + f * y / zn]); }
   }
   return out.length >= 3 ? out : null;
}
// LA FOTO EN PANTALLA como poligono, tambien con esquinas detras de la camara (painter.photoQuad devuelve null en cuanto una esquina queda
// detras: en el espacio estirado del laboratorio eso pasa a cientos de a.l. de la losa, con la nebulosa llenando la vista; medido el 11-nov
// en el viaje H, fotograma 2). Mismas esquinas que photoQuad. null = la foto queda detras
function fvAmbPhotoPoly(painter, pr) {
   var N = painter.scene.nebula; if (!N || !N.layers || !N.layers.length || !(N.distLy > 0)) return null;
   var L0 = N.layers[0], d0 = N.distLy, T = painter.tiltOf(), S = pr.S || 1, c = pr.pos, r = pr.r, d = pr.d, fw = pr.fw;
   var Lp = { z: d0, x0: L0.x0 / L0.z * d0, y0: L0.y0 / L0.z * d0, x1: L0.x1 / L0.z * d0, y1: L0.y1 / L0.z * d0 };
   var cq = [[Lp.x0, Lp.y0], [Lp.x1, Lp.y0], [Lp.x1, Lp.y1], [Lp.x0, Lp.y1]], C = [], zmax = 0;
   for (var i = 0; i < 4; ++i) {
      var w = painter.planePt(Lp, cq[i][0], cq[i][1], T), vx = S * (w[0] - c[0]), vy = S * (w[1] - c[1]), vz = w[2] - c[2];
      var p = [vx * r[0] + vy * r[1] + vz * r[2], vx * d[0] + vy * d[1] + vz * d[2], vx * fw[0] + vy * fw[1] + vz * fw[2]];
      C.push(p); if (p[2] > zmax) zmax = p[2];
   }
   if (!(zmax > 0)) return null;
   return fvAmbClipProject(C, 1e-4 * zmax, pr.f, pr.cx, pr.cy);
}
// ---------------------------------------------------------------------------
// EL PINTOR DEL CAMPO (solo PixInsight). Lo llama FVPainter.render despues de las estrellas, en Add. painter.ambOn = el boton (el mismo
// de la Via Lactea de fondo). Deja painter.stats.amb (puntos), ambStreak (trazos), ambW (peso), ambRho, ambSpeed (a.l. de vuelo / s)
// ---------------------------------------------------------------------------
// ¿la camara esta GIRANDO alrededor de algo (no viajando)? Orbitar el foco con el raton (y su inercia) en la navegacion v5, la orbita de la
// navegacion clasica, o un fotograma de REC grabado asi (P.lab.orb)
function fvAmbTurning(P) {
   var L = P.lab;
   if (L) { if (L.orb) return true; if (L.drag && L.drag.kind !== "pan") return true; if (L.glide && L.glide.kind !== "pan") return true; }
   return !!P.orbit && !P.flight;
}
var FV_AMB_COL = [[170, 196, 255], [214, 226, 255], [255, 250, 244], [255, 238, 205], [255, 214, 165], [255, 186, 130]];
function fvAmbPaint(painter, g, pr, P) {
   var st = painter.stats; st.amb = 0; st.ambStreak = 0; st.ambW = 0;
   if (!FV_AMB.ON || painter.mwOn === false || !P || !P.cam) return;
   var A = FV_AMB, S = pr.S || 1, c = P.cam.pos, q = [S * c[0], S * c[1], c[2]], t = P.t || 0;
   // la velocidad de la camara en vuelo, del fotograma anterior (reloj de escena: en vivo y en REC da lo mismo)
   var vel = null, a = painter.amb;
   if (!a) a = painter.amb = { F: fvAmbBuild(A.N, A.SEED), out: new Float32Array(6 * 4000), q: null, t: 0, v: [0, 0, 0], spr: null, pens: null };
   // (E1, 11-nov, Nino: «cuando estoy quieto y giro no tiene mucho sentido la estela») la velocidad sale del desplazamiento REAL de la camara,
   // pasado al espacio de vuelo con el estirado de AHORA (antes era la diferencia de q = S·c: al mirar alrededor el estirado S cambia con el rumbo
   // y eso solo ya daba «velocidad» sin moverse), y GIRAR alrededor de una estrella (orbitar su foco con el raton, o la orbita automatica) no es
   // viajar: sin velocidad no hay trazos ni se apagan octavas. FV_AMB_BREAK "turn" = como antes (el ROJO)
   var oldV = FV_AMB_BREAK === "turn";
   if (a.c) { var dt = t - a.t; if (dt > 1e-4 && dt < 0.25) { vel = oldV ? [(q[0] - a.q[0]) / dt, (q[1] - a.q[1]) / dt, (q[2] - a.q[2]) / dt] : [S * (c[0] - a.c[0]) / dt, S * (c[1] - a.c[1]) / dt, (c[2] - a.c[2]) / dt]; a.v = vel; } else if (dt === 0) vel = a.v; }
   a.q = q; a.c = c.slice(); a.t = t;
   if (!oldV && fvAmbTurning(P)) { vel = null; a.v = [0, 0, 0]; }
   var w = (typeof painter.mwWeight === "function") ? painter.mwWeight(P) : 1;
   // solo en el WARP (alli estan las estelas y el polvo de warp): el cine tambien pone P.trail (fv_pilot.js: «if (fl.kind !== "warp") P.trail = w»)
   // (y sin vuelo, p. ej. un fotograma repintado desde su estado grabado con trail > 0, tambien: fv_nB2_test W1 media la luz por estela y el
   // campo se la subia de 14,9 a 1 183, 11-nov)
   if (!(P.flight && P.flight.kind !== "warp" && !(typeof fvIsWarpFl === "function" && fvIsWarpFl(P.flight)))) w *= 1 - fvSmooth(((P.trail || 0) - A.WARP_OFF[0]) / (A.WARP_OFF[1] - A.WARP_OFF[0]));
   st.ambW = w;
   if (w < 0.02) return;
   var rho = fvAmbRho(painter.scene.galaxy, c); st.ambRho = rho;
   st.ambSpeed = vel ? Math.sqrt(vel[0] * vel[0] + vel[1] * vel[1] + vel[2] * vel[2]) : 0;
   var n = fvAmbVisible(a.F, q, pr.r, pr.d, pr.fw, pr.f, pr.cx, pr.cy, pr.W, pr.H, vel, rho, w * A.GAIN, a.out), o = a.out;
   if (!a.spr) {
      // puntos: 6 colores × 6 niveles; los 3 primeros de 3×3 (como el grano), los 3 ultimos de 5×5 con nucleo
      a.spr = []; a.pens = [];
      for (var ci = 0; ci < 6; ++ci) for (var lv = 0; lv < 6; ++lv) {
         var big = lv >= 3, sz = big ? 5 : 3, h = (sz - 1) / 2, I = [0.2, 0.32, 0.48, 0.5, 0.72, 1][lv], sg = big ? [0.95, 1.1, 1.3][lv - 3] : 0.62;
         var bm = new Bitmap(sz, sz, BitmapFormat.RGB32), px = new Uint32Array(bm.pixelData()), cc = FV_AMB_COL[ci];
         for (var y = 0; y < sz; ++y) for (var x = 0; x < sz; ++x) {
            var v = I * Math.exp(-((x - h) * (x - h) + (y - h) * (y - h)) / (2 * sg * sg));
            px[y * sz + x] = (0xff000000 | (Math.min(255, Math.round(cc[0] * v)) << 16) | (Math.min(255, Math.round(cc[1] * v)) << 8) | Math.min(255, Math.round(cc[2] * v))) >>> 0;
         }
         a.spr.push(bm);
         var Ip = [0.1, 0.15, 0.21, 0.28, 0.36, 0.45][lv];
         a.pens.push(new Pen((0xff000000 | (Math.round(cc[0] * Ip) << 16) | (Math.round(cc[1] * Ip) << 8) | Math.round(cc[2] * Ip)) >>> 0, lv >= 4 ? 1.3 : 1));
      }
   }
   // la foto en pantalla (si se esta pintando: capas o la foto de casa): dentro no hay campo
   var PQ = null, mPx = A.PHOTO_MASK * pr.W;
   // nebOn: la nebulosa se esta pintando (capas, volumen o la foto de casa); st.layers no vale: el camino del volumen no lo cuenta (medido el 11-nov)
   var nebOn = (st.nebOp || 0) > 0.01 || (st.wPhoto || 0) > 0.02 || (st.layers || 0) > 0;
   if (A.PHOTO_MASK > 0 && typeof painter.planePt === "function" && nebOn) { try { PQ = fvAmbPhotoPoly(painter, pr); } catch (eQ) { PQ = null; } }
   // DENTRO de la losa de la nebulosa (stats.inSlab del pintor) la niebla llena la vista y los trazos la rayaban (H, fotograma 2): el campo
   // entero se apaga, con un paso bajo de MASK_S s (nada de golpe)
   // (sin cuadrilatero FUERA de la losa = la foto queda detras de la camara: ahi el campo se queda; apagarlo con «sin cuadrilatero y nebulosa
   // pintandose» dejaba sin campo todo el viaje por detras de la foto, 7 de 12 fotogramas de H a cero, medido el 11-nov)
   var tq = (A.PHOTO_MASK > 0) ? 1 - fvClamp(st.inSlab || 0, 0, 1) : 1;   // dentro de la losa, la niebla lo llena todo
   var dtq = a.tq === undefined ? 0 : t - a.tq;
   if (a.kq === undefined || !(dtq >= 0 && dtq < 0.5)) a.kq = tq; else if (dtq > 0) a.kq += (tq - a.kq) * (1 - Math.exp(-dtq / A.MASK_S));
   a.tq = t; st.ambKq = a.kq;
   var lines = null, nS = 0, nP = 0, smin = A.STREAK_MIN, nMask = 0, kq = a.kq;
   if (kq < 0.02) { st.ambMasked = n; return; }
   for (var i = 0; i < n; ++i) {
      var j = 6 * i, sx = o[j], sy = o[j + 1], lx = o[j + 2] - sx, ly = o[j + 3] - sy, ll = Math.sqrt(lx * lx + ly * ly), Ii = o[j + 4];
      Ii *= kq;
      if (Ii < A.I_MIN) continue;
      if (PQ) { var km = fvAmbInQuad(PQ, sx, sy, mPx); if (km > 0) { Ii *= 1 - km; ++nMask; if (Ii < A.I_MIN) continue; } }
      if (ll > A.STREAK_DIM) Ii *= Math.sqrt(A.STREAK_DIM / ll);
      var lev = Math.min(5, Math.floor(Ii * 6)), key = o[j + 5] * 6 + lev;
      if (ll >= smin) {
         if (!lines) lines = {};
         var Lq = lines[key]; if (!Lq) Lq = lines[key] = [];
         Lq.push(sx, sy, o[j + 2], o[j + 3]); ++nS;
         // la cabeza: la estrella sigue ahi, un nivel por debajo (la cola se lleva parte de la luz)
         var bh = a.spr[o[j + 5] * 6 + Math.max(0, lev - 1)], h2 = (bh.width - 1) / 2; g.drawBitmap(Math.round(sx) - h2, Math.round(sy) - h2, bh);
      } else {
         var b = a.spr[key], hh = (b.width - 1) / 2;
         g.drawBitmap(Math.round(sx) - hh, Math.round(sy) - hh, b); ++nP;
      }
   }
   if (lines) {
      var aa = g.antialiasing; g.antialiasing = true;
      for (var kq in lines) {
         if (!Object.prototype.hasOwnProperty.call(lines, kq)) continue;
         var C = lines[kq]; g.pen = a.pens[+kq];
         for (var m = 0; m < C.length; m += 4) g.drawLine(C[m], C[m + 1], C[m + 2], C[m + 3]);
      }
      g.antialiasing = aa;
   }
   st.amb = nP; st.ambStreak = nS; st.ambMasked = nMask;
}
