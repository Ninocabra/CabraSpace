// ============================================================================
// FieldVoyager/src/engine/fv_volume3.js — RONDA 3 del volumen por familias (5-nov-2026, tarde). PURO: sin PixInsight ni DOM. ES5.
// Lo carga FieldVoyager.js justo despues de src/engine/fv_volume.js (usa su modelo: fvVolBuild, fvVolMeasure, fvvEpsAt, fvVolStack...).
// Node lo carga igual en las pruebas (tests/fv_V3_*_node.js).
// ----------------------------------------------------------------------------
// QUE CAMBIA RESPECTO A LA FASE 2 (las tres cosas con su bandera; false = la fase 2 = el ROJO):
//  1. PILAS GENERICAS: cada pila lleva su normal y cada corte su geometria (esquina P0 y pasos U, V por texel, en coordenadas del modelo: x, y en
//     px del modelo, z profundidad con 0 en el plano del centro). El pintor de PixInsight, el exportador y el navegador pintan cualquier
//     orientacion con el mismo codigo (en la fase 2, solo Z/X/Y de la imagen).
//  2. DISCO EN PILAS ALINEADAS CON EL DISCO (FV_VOLM3.ON): N paralela al plano medio, B perpendicular al eje menor dentro del plano, A
//     perpendicular al eje mayor. CAUSA MEDIDA de las bandas de la fase 2 (NGC 1726 de cara, pintor de software de tests/fv_V3_disk_node.js,
//     que las reproduce): el disco del modelo es FINO (σ 1,7–2,4 px a lo largo de la normal) y la pila Y de la imagen, que pesa 0,71 de cara,
//     tiene cortes cada 6 px (el ANCHO DEL RECORTE / 48, no el de la galaxia: solo 10 cortes llevan luz). Cada corte guarda una TIRA del disco
//     de ~4 px aplastada en su plano y, vista a 45° del corte, las tiras quedan separadas por huecos: copias paralelas. Con la pila N el disco
//     entero cae en cortes paralelos a el (sin tiras) y las pilas A/B, acotadas a la luz, solo pesan cerca de canto, donde sus tiras se ven
//     casi de frente.
//  3. LA LUZ DONDE ESTA (EXT_K): el disco se acota al radio del 99 % de su luz (× EXT_K) y no a las esquinas del recorte; lo que queda fuera
//     (las afueras debiles) y el viento van a una pila de la imagen aparte («resto», el modelo de la fase 2 con esa luz).
//  4. INVARIANTE DE FRENTE: el volumen es V = G(cielo) · e(X), con G = C · fd / S (la foto entre la suma de la columna): cada texel toma G en
//     el punto del cielo de SU plano (detalle de la foto nitido) y la integral de e a lo ancho de su corte (la luz no se pierde entre cortes).
//     Despues, GANANCIA DE FRENTE (GAIN): se pinta la vista desde la Tierra de las pilas en el build, se compara con la foto y cada texel se
//     multiplica por el cociente suave en su punto del cielo; desde la Tierra sale la foto a la resolucion del modelo.
// ============================================================================

var FV_VOLM3 = {
   ON: true,            // false = las pilas Z/X/Y de la fase 2 tambien para el disco (ROJO de las bandas)
   EXT_K: 1.2,          // radio del disco = EXT_K × radio eliptico del 99 % de la luz — ELECCION nuestra [SIN NINO]
   EXT_FRAC: 0.99,
   TMIN: 1.5,           // grosor minimo del disco: σ ≥ TMIN texeles (convolucion de 3 tomas a lo largo de la normal: no hay disco mas fino que el
                        // paso de la pila; el modelo esferoidal con q0 0,2 daba σ → 0 en el centro) — ELECCION nuestra, medida en fv_V3_disk_node
   NH: 16,              // cortes paralelos al plano medio
   NAB: 48, NAB_MAX: 96,// cortes de las pilas de canto (A y B): al menos NAB y los que pida el grosor (paso ≤ σ·tan i, tope NAB_MAX)
   SUB: 3,              // submuestras a lo ancho de cada corte (integral del corte)
   TEX_MAX: 640,        // texeles maximos a lo ancho del disco (memoria: N 16 × 640² × 4 B = 26 MB)
   GAIN: true, GAIN_CLAMP: [0.5, 2.0], GAIN_BLUR: 1.5,
   REST_N: 24,          // cortes por pila del «resto» (viento y afueras, pilas Z/X/Y de la imagen)
   REST_MIN: 0.003,     // si el resto lleva menos de esto de la luz del objeto, no se hace (se avisa en o.vol)
   SHEET: 1, SHEET_R: 3, SHEET_POS: "mid", SHEET_Q: 0.15, SHEET_S: 1.5,   // (V2-4) lamina de detalle de la cascara en la pila Z (fvVolSheet de fv_volume.js):
                        // fraccion de la parte fina (0 = la fase 2, ROJO), radio del suelo suave (px del modelo), donde ("mid" z = 0; "front" la pared de
                        // delante, refutada: fidelidad 0,19), anchura (bins) — ELECCION [SIN NINO]
   BREAK: ""            // pruebas: "nofloor" (sin grosor minimo) · "nogain" · "nosub" (sin integral del corte) · "fullext" (disco hasta la esquina) · "noray" (difusion por indice)
};

function fv3Dot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
function fv3Lin(o, a, ka, b, kb, c, kc) { return [o[0] + a[0] * ka + b[0] * kb + c[0] * kc, o[1] + a[1] * ka + b[1] * kb + c[1] * kc, o[2] + a[2] * ka + b[2] * kb + c[2] * kc]; }
// bilineal de un mapa Float32 w·h (centros de pixel en i + 0,5) en (x, y) continuos
function fv3Bil(A, w, h, x, y) {
   var u = x - 0.5, v = y - 0.5, i = Math.floor(u), j = Math.floor(v), fu = u - i, fv = v - j;
   if (i < 0) { i = 0; fu = 0; } else if (i >= w - 1) { i = w - 2; fu = 1; }
   if (j < 0) { j = 0; fv = 0; } else if (j >= h - 1) { j = h - 2; fv = 1; }
   var o = j * w + i;
   return (A[o] * (1 - fu) + A[o + 1] * fu) * (1 - fv) + (A[o + w] * (1 - fu) + A[o + w + 1] * fu) * fv;
}

// bilineal del recorte Uint32 RGB (w·h) en (x, y) continuos (px del recorte) -> out[3] 0..255 (0 fuera)
function fv3CutBil(cut, w, h, x, y, out) {
   var u = x - 0.5, v = y - 0.5, i = Math.floor(u), j = Math.floor(v), fu = u - i, fv = v - j;
   if (i < 0) { i = 0; fu = 0; } else if (i >= w - 1) { i = w - 2; fu = 1; }
   if (j < 0) { j = 0; fv = 0; } else if (j >= h - 1) { j = h - 2; fv = 1; }
   var o = j * w + i, p00 = cut[o], p01 = cut[o + 1], p10 = cut[o + w], p11 = cut[o + w + 1], w00 = (1 - fu) * (1 - fv), w01 = fu * (1 - fv), w10 = (1 - fu) * fv, w11 = fu * fv;
   out[0] = ((p00 >>> 16) & 255) * w00 + ((p01 >>> 16) & 255) * w01 + ((p10 >>> 16) & 255) * w10 + ((p11 >>> 16) & 255) * w11;
   out[1] = ((p00 >>> 8) & 255) * w00 + ((p01 >>> 8) & 255) * w01 + ((p10 >>> 8) & 255) * w10 + ((p11 >>> 8) & 255) * w11;
   out[2] = (p00 & 255) * w00 + (p01 & 255) * w01 + (p10 & 255) * w10 + (p11 & 255) * w11;
}
// radio eliptico (en px del modelo, eje mayor) que encierra la fraccion frac de la luz proyectada (perfil de luminancia de fvVolMeasure)
function fv3LightRadius(meas, frac) {
   var prof = meas.prof, nb = prof.length, tot = 0, cum = 0, i;
   for (i = 0; i < nb; ++i) tot += Math.max(0, prof[i]) * (2 * i + 1);
   for (i = 0; i < nb; ++i) { cum += Math.max(0, prof[i]) * (2 * i + 1); if (cum >= frac * tot) return i + 1; }
   return nb;
}

// ---------------------------------------------------------------------------------------------------------------------------------------
// LA GEOMETRIA DEL DISCO (coordenadas del modelo: x derecha, y abajo, z alejandose de la Tierra; las mismas de fvVolUnDisk):
//   a = eje mayor en el cielo · n = normal del disco · b = eje menor DENTRO del plano. Un punto X = c + α a + β b + η n.
// ---------------------------------------------------------------------------------------------------------------------------------------
function fv3DiskFrame(m) {
   var cp = m.cp, sp = m.sp, ci = m.ci, si = m.si;
   return { c: [m.cx, m.cy, 0], a: [cp, sp, 0], n: [-sp * si, cp * si, ci], b: [-sp * ci, cp * ci, -si] };
}
// emisividad del disco SIN normalizar (por canal) en (α, β, η), con el grosor minimo (3 tomas a ±hTap a lo largo de η: varianza añadida
// 0,5 hTap² = σmin²) y, si box, el ahusado al radio Ra (suave entre 0,85 y 1 Ra) y el corte en |η| ≤ Hd
function fv3EDisk(m, V3, al, be, et, box, out) {
   var q0 = m.q0, rho2 = al * al + be * be, h = V3.hTap, e = m.eps, s0 = 0, s1 = 0, s2 = 0, tap = 1;
   if (box) {
      var rho = Math.sqrt(rho2);
      if (rho >= V3.Ra || Math.abs(et) >= V3.Hd) { out[0] = out[1] = out[2] = 0; return; }
      if (rho > 0.85 * V3.Ra) tap = fvvSmooth((V3.Ra - rho) / (0.15 * V3.Ra));
   }
   for (var t = -1; t <= 1; ++t) {
      if (!h && t) continue;
      var z = et + t * h, w = h ? (t ? 0.25 : 0.5) : 1, r = Math.sqrt(rho2 + (z / q0) * (z / q0));
      s0 += w * fvvEpsAt(e[0], r); s1 += w * fvvEpsAt(e[1], r); s2 += w * fvvEpsAt(e[2], r);
   }
   out[0] = s0 * tap; out[1] = s1 * tap; out[2] = s2 * tap;
}
// la columna (x, y) (px continuos del modelo) cruza el esferoide de soporte α² + β² + (η/q')² ≤ R² en [z0, z1] -> null o [z0, z1]
function fv3ColSpan(F, m, V3, x, y) {
   var X0 = [x - m.cx, y - m.cy, 0], a0 = fv3Dot(X0, F.a), b0 = fv3Dot(X0, F.b), e0 = fv3Dot(X0, F.n), si = m.si, ci = m.ci, R = V3.Rsup, q = V3.qsup;
   var A = si * si + ci * ci / (q * q), B = -2 * b0 * si + 2 * e0 * ci / (q * q), C = a0 * a0 + b0 * b0 + e0 * e0 / (q * q) - R * R, dsc = B * B - 4 * A * C;
   if (!(dsc > 0)) return null;
   var sq = Math.sqrt(dsc);
   return [(-B - sq) / (2 * A), (-B + sq) / (2 * A), a0, b0, e0];
}
// suma de la emisividad del disco a lo largo de la columna (x, y): completa (sin caja) y dentro de la caja -> out { f: [3], b: [3] }
function fv3ColSum(F, m, V3, x, y, out) {
   out.f[0] = out.f[1] = out.f[2] = 0; out.b[0] = out.b[1] = out.b[2] = 0;
   var sp = fv3ColSpan(F, m, V3, x, y); if (!sp) return out;
   var n = V3.NZ, dz = (sp[1] - sp[0]) / n, tmp = V3.tmp, si = m.si, ci = m.ci;
   for (var k = 0; k < n; ++k) {
      var z = sp[0] + (k + 0.5) * dz, al = sp[2], be = sp[3] - z * si, et = sp[4] + z * ci;
      fv3EDisk(m, V3, al, be, et, false, tmp); out.f[0] += tmp[0] * dz; out.f[1] += tmp[1] * dz; out.f[2] += tmp[2] * dz;
      fv3EDisk(m, V3, al, be, et, true, tmp); out.b[0] += tmp[0] * dz; out.b[1] += tmp[1] * dz; out.b[2] += tmp[2] * dz;
   }
   return out;
}

// ---------------------------------------------------------------------------------------------------------------------------------------
// EL DISCO EN TRES PILAS ALINEADAS CON EL. m = fvVolBuild(...) (familia disk); meas = fvVolMeasure del mismo recorte; Cs(x, y, out[3]) = la
// foto (0..255) en px continuos del modelo (bilineal; puede leer el recorte a resolucion completa); tex = paso del texel en px del modelo
// (1 = la rejilla del modelo; 1/ds = resolucion completa). -> { stacks: [pila generica], rest (mapa 0..1: fraccion de la luz de disco de cada
// columna que queda fuera de la caja), stats }
// Pila generica: { name, group, nrm: [3], sp (paso entre cortes, px del modelo), N, head, cuts: [ { px, bw, bh, P0: [3], U: [3], V: [3], pc: [3] } | null ] }
// ---------------------------------------------------------------------------------------------------------------------------------------
function fvVol3DiskStacks(m, meas, Cs, tex) {
   var K = FV_VOLM3, t0 = Date.now(), F = fv3DiskFrame(m), w = m.w, h = m.h, n = w * h, i, x, y, c, j;
   var rL = fv3LightRadius(meas, K.EXT_FRAC), Ra = (K.BREAK === "fullext") ? m.nb : Math.min(m.nb, Math.max(4, K.EXT_K * rL));
   var t = Math.max(tex || 1, 2 * Ra / K.TEX_MAX), smin = (K.BREAK === "nofloor") ? 0 : K.TMIN * t;
   var V3 = { Ra: Ra, hTap: smin * Math.SQRT2, tmp: [0, 0, 0], NZ: 96 };
   V3.Hd = m.q0 * Ra + 3 * smin + 1e-6;
   V3.Rsup = m.nb + 3 * smin; V3.qsup = Math.min(1, (m.q0 * m.nb + 3 * smin) / V3.Rsup);
   // 1. suma de la columna: completa (S) y dentro de la caja (Sb), en una rejilla de paso gs y bilineal (es suave)
   var gs = 2, gw = Math.ceil(w / gs) + 1, gh = Math.ceil(h / gs) + 1, SF = [new Float32Array(gw * gh), new Float32Array(gw * gh), new Float32Array(gw * gh)], SB = [new Float32Array(gw * gh), new Float32Array(gw * gh), new Float32Array(gw * gh)], o2 = { f: [0, 0, 0], b: [0, 0, 0] };
   for (y = 0; y < gh; ++y) for (x = 0; x < gw; ++x) { fv3ColSum(F, m, V3, Math.min(w, x * gs + 0.5), Math.min(h, y * gs + 0.5), o2); for (c = 0; c < 3; ++c) { SF[c][y * gw + x] = o2.f[c]; SB[c][y * gw + x] = o2.b[c]; } }
   function Sat(A, xx, yy) { var u = (xx - 0.5) / gs, v = (yy - 0.5) / gs, iu = Math.max(0, Math.min(gw - 2, Math.floor(u))), iv = Math.max(0, Math.min(gh - 2, Math.floor(v))), fu = Math.max(0, Math.min(1, u - iu)), fv = Math.max(0, Math.min(1, v - iv)), o = iv * gw + iu; return (A[o] * (1 - fu) + A[o + 1] * fu) * (1 - fv) + (A[o + gw] * (1 - fu) + A[o + gw + 1] * fu) * fv; }
   // fraccion de la luz de disco de cada pixel del modelo que queda FUERA de la caja (va al resto) y luz de disco total / dentro
   var rest = new Float32Array(n), lD = 0, lIn = 0, cc = [0, 0, 0];
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
      i = y * w + x; var fIn = 0, tot = 0;
      for (c = 0; c < 3; ++c) { var sf = Sat(SF[c], x + 0.5, y + 0.5), sb = Sat(SB[c], x + 0.5, y + 0.5), v = m.ch[c][i] * (m.fd ? m.fd[c][i] : 1); tot += v; fIn += v * (sf > 1e-12 ? Math.min(1, sb / sf) : 0); }
      lD += tot; lIn += fIn; rest[i] = tot > 0 ? 1 - fIn / tot : 1;
   }
   // 2. las pilas. Cada texel: G en el punto del cielo de su plano × integral de e a lo ancho del corte. G = C · fd / S (S completa: la luz
   // de la columna que cae fuera de la caja ya la lleva el resto)
   var hk = 1 / (m.head || 1), Lfd = m.fd, fdAt = function(cq, xx, yy) { return Lfd ? fv3Bil(Lfd[cq], w, h, xx, yy) : 1; };
   var specs = [
      { name: "N", nrm: F.n, uA: F.a, vA: F.b, uR: Ra, vR: Ra, pR: V3.Hd, N: K.NH, ord: [0, 1, 2] },
      { name: "B", nrm: F.b, uA: F.a, vA: F.n, uR: Ra, vR: V3.Hd, pR: Ra, N: 0, ord: [0, 2, 1] },
      { name: "A", nrm: F.a, uA: F.b, vA: F.n, uR: Ra, vR: V3.Hd, pR: Ra, N: 0, ord: [1, 2, 0] }
   ];
   // pilas de canto: paso ≤ σ_min · max(1, tan i) para que, vistas a ±45°, sus tiras no dejen huecos (y al menos NAB)
   var sig = Math.max(smin, 1e-3), nAB = Math.max(K.NAB, Math.min(K.NAB_MAX, Math.ceil(2 * Ra / (1.2 * sig * Math.max(1, Math.tan(m.inc)) + 1e-9))));
   specs[1].N = nAB; specs[2].N = nAB;
   var stacks = [], tmp = [0, 0, 0], Cv = [0, 0, 0], st = { Ra: Ra, rL: rL, tex: t, smin: smin, Hd: V3.Hd, nAB: nAB, lightD: lD, lightIn: lIn, gain: null };
   specs.forEach(function(S) {
      var N = S.N, dp = 2 * S.pR / N, gu = Math.max(1, Math.ceil(2 * S.uR / t)), gv = Math.max(1, Math.ceil(2 * S.vR / t)), G = gu * gv, acc = [], nsub = (K.BREAK === "nosub") ? 1 : K.SUB;
      for (j = 0; j < N; ++j) acc.push(new Float32Array(G * 3));
      var coord = [0, 0, 0];
      for (j = 0; j < N; ++j) {
         var pj = -S.pR + (j + 0.5) * dp, A = acc[j];
         for (var iv = 0; iv < gv; ++iv) for (var iu = 0; iu < gu; ++iu) {
            var u = -S.uR + (iu + 0.5) * t, v = -S.vR + (iv + 0.5) * t;
            coord[S.ord[0]] = u; coord[S.ord[1]] = v; coord[S.ord[2]] = pj;          // (α, β, η)
            if (coord[0] * coord[0] + coord[1] * coord[1] >= Ra * Ra || Math.abs(coord[2]) >= V3.Hd) continue;
            var e0 = 0, e1 = 0, e2 = 0;
            for (var s = 0; s < nsub; ++s) {
               var dd = (nsub === 1) ? 0 : ((s + 0.5) / nsub - 0.5) * dp, cs = [coord[0], coord[1], coord[2]]; cs[S.ord[2]] += dd;
               fv3EDisk(m, V3, cs[0], cs[1], cs[2], true, tmp); e0 += tmp[0]; e1 += tmp[1]; e2 += tmp[2];
            }
            var kk = dp / nsub; e0 *= kk; e1 *= kk; e2 *= kk;
            if (!(e0 > 1e-12 || e1 > 1e-12 || e2 > 1e-12)) continue;
            var X = fv3Lin(F.c, F.a, coord[0], F.b, coord[1], F.n, coord[2]), sx = X[0], sy = X[1];
            if (sx < 0 || sy < 0 || sx > w || sy > h) continue;
            Cs(sx, sy, Cv);
            var o3 = (iv * gu + iu) * 3, es = [e0, e1, e2];
            for (c = 0; c < 3; ++c) { var sf2 = Sat(SF[c], sx, sy); if (sf2 > 1e-12) A[o3 + c] = Cv[c] * fdAt(c, sx, sy) / sf2 * es[c] * hk; }
         }
      }
      S.acc = acc; S.gu = gu; S.gv = gv; S.dp = dp;
      S.O = function(jj) { var pj = -S.pR + (jj + 0.5) * dp; return [F.c[0] - S.uA[0] * S.uR - S.vA[0] * S.vR + S.nrm[0] * pj, F.c[1] - S.uA[1] * S.uR - S.vA[1] * S.vR + S.nrm[1] * pj, F.c[2] - S.uA[2] * S.uR - S.vA[2] * S.vR + S.nrm[2] * pj]; };
   });
   // 3. GANANCIA DE FRENTE: la vista desde la Tierra (ortografica a lo largo de z, con la opacidad de cada pila) frente a C · fd · (1 − resto)
   if (K.GAIN && K.BREAK !== "nogain") st.gain = fv3FrontGain(m, specs, rest, Cs, t);
   // 4. cuantizar (difusion del error a lo largo de cada pila) y geometria de cada corte
   specs.forEach(function(S) {
      // la difusion del error sigue el RAYO DESDE LA TIERRA (no el indice del texel): de un corte al siguiente, el rayo z avanza dz = dp / (z·n) y
      // se desplaza (z·u, z·v)·dz / t texeles en el plano. Asi la suma a lo largo de cada rayo desde la Tierra es exacta ±1 nivel aunque los
      // cortes vayan en oblicuo (con la difusion por indice el ruido de 8 bits de ~50 cortes se suma al azar: medido en fv_V3_disk_node, M 82
      // frente 7,4 % por indice («noray», el ROJO) frente a 3,7 % siguiendo el rayo; fase 2 3,3 %; NGC 1560 8,6 → 7,2 %).
      // La pila A es paralela a z (no la cruza el rayo): difusion por indice, como la fase 2.
      var zn = S.nrm[2], q, seedS = (m.seedQ || FV_VOLM.SEED) + S.name.charCodeAt(0);
      if (Math.abs(zn) > 0.05 && K.BREAK !== "noray") { var dz = S.dp / zn; q = fv3QuantizeRay(S.acc, S.gu, S.gv, S.N, S.uA[2] * dz / t, S.vA[2] * dz / t, seedS); }
      else q = fvVolQuantize(S.acc, S.gu, S.gv, S.N, seedS);
      var U = [S.uA[0] * t, S.uA[1] * t, S.uA[2] * t], Vv = [S.vA[0] * t, S.vA[1] * t, S.vA[2] * t];
      for (var jj = 0; jj < S.N; ++jj) {
         var C = q.cuts[jj]; if (!C) continue;
         var O = S.O(jj); C.P0 = [O[0] + U[0] * C.u0 + Vv[0] * C.v0, O[1] + U[1] * C.u0 + Vv[1] * C.v0, O[2] + U[2] * C.u0 + Vv[2] * C.v0]; C.U = U; C.V = Vv;
         var pj = -S.pR + (jj + 0.5) * S.dp; C.pc = [F.c[0] + S.nrm[0] * pj, F.c[1] + S.nrm[1] * pj, F.c[2] + S.nrm[2] * pj];
      }
      stacks.push({ name: S.name, group: "disk", nrm: S.nrm, sp: S.dp, N: S.N, head: m.head || 1, cuts: q.cuts, gw: S.gu, gh: S.gv });
      S.acc = null;
   });
   st.ms = Date.now() - t0;
   return { stacks: stacks, rest: rest, stats: st, frame: F };
}
// cuantizacion a 8 bits con difusion del error A LO LARGO DE UN RAYO: el error del texel (u, v) del corte j pasa al corte j+1 en (u + du, v + dv)
// (bilineal). Misma salida que fvVolQuantize: { N, gw, gh, cuts: [ { px, bw, bh, u0, v0 } | null ] }
function fv3QuantizeRay(acc, gw, gh, N, du, dv, seed) {
   var G = gw * gh, rnd = fvvRng(seed), E = new Float32Array(G * 3), E2 = new Float32Array(G * 3), out = [], j, q, c, x, y;
   for (q = 0; q < G * 3; ++q) E[q] = rnd() - 0.5;
   var iu = Math.floor(du), iv = Math.floor(dv), fu = du - iu, fv = dv - iv, w00 = (1 - fu) * (1 - fv), w01 = fu * (1 - fv), w10 = (1 - fu) * fv, w11 = fu * fv;
   for (j = 0; j < N; ++j) {
      var A = acc[j], P = new Uint32Array(G); E2.fill(0);
      for (y = 0; y < gh; ++y) for (x = 0; x < gw; ++x) {
         q = y * gw + x;
         for (c = 0; c < 3; ++c) {
            var val = A[q * 3 + c] + E[q * 3 + c], r = Math.round(val), e = r < 0 ? 0 : (r > 255 ? 255 : r), err = val - e;
            if (e) P[q] |= e << (16 - 8 * c);
            if (err === 0) continue;
            var x0 = x + iu, y0 = y + iv;
            if (x0 >= 0 && x0 < gw && y0 >= 0 && y0 < gh) E2[(y0 * gw + x0) * 3 + c] += err * w00;
            if (x0 + 1 >= 0 && x0 + 1 < gw && y0 >= 0 && y0 < gh) E2[(y0 * gw + x0 + 1) * 3 + c] += err * w01;
            if (x0 >= 0 && x0 < gw && y0 + 1 >= 0 && y0 + 1 < gh) E2[((y0 + 1) * gw + x0) * 3 + c] += err * w10;
            if (x0 + 1 >= 0 && x0 + 1 < gw && y0 + 1 >= 0 && y0 + 1 < gh) E2[((y0 + 1) * gw + x0 + 1) * 3 + c] += err * w11;
         }
      }
      var T = E; E = E2; E2 = T;
      var bx0 = gw, by0 = gh, bx1 = -1, by1 = -1;
      for (y = 0; y < gh; ++y) for (x = 0; x < gw; ++x) if (P[y * gw + x]) { if (x < bx0) bx0 = x; if (x > bx1) bx1 = x; if (y < by0) by0 = y; if (y > by1) by1 = y; }
      if (bx1 < 0) { out.push(null); continue; }
      bx0 = Math.max(0, bx0 - 1); by0 = Math.max(0, by0 - 1); bx1 = Math.min(gw - 1, bx1 + 1); by1 = Math.min(gh - 1, by1 + 1);
      var bw = bx1 - bx0 + 1, bh = by1 - by0 + 1, px = new Uint32Array(bw * bh);
      for (y = 0; y < bh; ++y) for (x = 0; x < bw; ++x) px[y * bw + x] = (0xff000000 | P[(y + by0) * gw + x + bx0]) >>> 0;
      out.push({ px: px, bw: bw, bh: bh, u0: bx0, v0: by0 });
   }
   return { N: N, gw: gw, gh: gh, cuts: out };
}
// la vista desde la Tierra de las pilas del disco (rejilla del modelo, ortografica a lo largo de z) y la correccion de ganancia por texel
function fv3FrontGain(m, specs, rest, Cs, t) {
   var w = m.w, h = m.h, n = w * h, R = [new Float32Array(n), new Float32Array(n), new Float32Array(n)], d = [0, 0, 1], i, c, x, y;
   var op = fv3StackOpacity(d, specs.map(function(S) { return S.nrm; }));
   specs.forEach(function(S, k) {
      var a = op[k]; if (!(a > 0.003)) return;
      var U = [S.uA[0] * t, S.uA[1] * t], V = [S.vA[0] * t, S.vA[1] * t], det = U[0] * V[1] - U[1] * V[0];
      if (Math.abs(det) < 1e-6 * t * t) return;
      for (var j = 0; j < S.N; ++j) {
         var O = S.O(j), A = S.acc[j];
         // pixel del cielo (x, y) -> texel (u, v): (x − O.x, y − O.y) = u U + v V
         for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
            var px = x + 0.5 - O[0], py = y + 0.5 - O[1], u = (px * V[1] - py * V[0]) / det - 0.5, v = (U[0] * py - U[1] * px) / det - 0.5;
            if (u < 0 || v < 0 || u > S.gu - 1 || v > S.gv - 1) continue;
            var iu = Math.min(S.gu - 2, Math.floor(u)), iv = Math.min(S.gv - 2, Math.floor(v)), fu = u - iu, fv = v - iv;
            if (S.gu < 2 || S.gv < 2) continue;
            var o00 = (iv * S.gu + iu) * 3, o01 = o00 + 3, o10 = o00 + S.gu * 3, o11 = o10 + 3, q = y * w + x;
            for (c = 0; c < 3; ++c) R[c][q] += a * ((A[o00 + c] * (1 - fu) + A[o01 + c] * fu) * (1 - fv) + (A[o10 + c] * (1 - fu) + A[o11 + c] * fu) * fv);
         }
      }
   });
   // objetivo: la luz de disco de cada pixel que va en la caja (× 1/HEAD, como los texeles)
   var hk = 1 / (m.head || 1), T = [new Float32Array(n), new Float32Array(n), new Float32Array(n)];
   for (i = 0; i < n; ++i) for (c = 0; c < 3; ++c) T[c][i] = m.ch[c][i] * (m.fd ? m.fd[c][i] : 1) * (1 - rest[i]) * hk;
   var bl = FV_VOLM3.GAIN_BLUR, Gm = [], lo = FV_VOLM3.GAIN_CLAMP[0], hi = FV_VOLM3.GAIN_CLAMP[1], stat = { n: 0, p05: 0, p50: 0, p95: 0, clip: 0 }, samp = [];
   for (c = 0; c < 3; ++c) {
      var Rb = fv3Blur2(R[c], w, h, bl), Tb = fv3Blur2(T[c], w, h, bl), g = new Float32Array(n), tmax = 0;
      for (i = 0; i < n; ++i) if (Tb[i] > tmax) tmax = Tb[i];
      for (i = 0; i < n; ++i) {
         if (Rb[i] > 0.002 * tmax && Tb[i] > 0.002 * tmax) { var gg = Tb[i] / Rb[i]; if (gg < lo || gg > hi) ++stat.clip; g[i] = Math.max(lo, Math.min(hi, gg)); if (c === 1 && (i % 7) === 0) samp.push(g[i]); }
         else g[i] = 1;
      }
      Gm.push(g);
   }
   samp.sort(function(p, q) { return p - q; });
   if (samp.length) { stat.n = samp.length; stat.p05 = samp[Math.floor(0.05 * (samp.length - 1))]; stat.p50 = samp[samp.length >> 1]; stat.p95 = samp[Math.floor(0.95 * (samp.length - 1))]; }
   // a cada texel, la ganancia en su punto del cielo
   specs.forEach(function(S) {
      for (var j = 0; j < S.N; ++j) {
         var O = S.O(j), A = S.acc[j];
         for (var iv = 0; iv < S.gv; ++iv) for (var iu = 0; iu < S.gu; ++iu) {
            var o3 = (iv * S.gu + iu) * 3; if (!(A[o3] > 0 || A[o3 + 1] > 0 || A[o3 + 2] > 0)) continue;
            var sx = O[0] + S.uA[0] * (iu + 0.5) * t + S.vA[0] * (iv + 0.5) * t, sy = O[1] + S.uA[1] * (iu + 0.5) * t + S.vA[1] * (iv + 0.5) * t;
            for (var c2 = 0; c2 < 3; ++c2) A[o3 + c2] *= fv3Bil(Gm[c2], w, h, sx, sy);
         }
      }
   });
   return stat;
}
function fv3Blur2(a, w, h, s) {   // gaussiano separable (bordes replicados)
   if (!(s > 0.05)) return a;
   var r = Math.ceil(3 * s), k = [], ks = 0, i, x, y, tmp = new Float32Array(w * h), out = new Float32Array(w * h);
   for (i = -r; i <= r; ++i) { k.push(Math.exp(-i * i / (2 * s * s))); ks += k[k.length - 1]; }
   for (i = 0; i < k.length; ++i) k[i] /= ks;
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var sm = 0; for (i = -r; i <= r; ++i) sm += k[i + r] * a[y * w + Math.max(0, Math.min(w - 1, x + i))]; tmp[y * w + x] = sm; }
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var sm2 = 0; for (i = -r; i <= r; ++i) sm2 += k[i + r] * tmp[Math.max(0, Math.min(h - 1, y + i)) * w + x]; out[y * w + x] = sm2; }
   return out;
}
// OPACIDADES de un grupo de pilas (normales cualesquiera, unitarias) para la direccion de vista d: las DOS mas alineadas, w = cos² / Σcos² y
// opacidad w / cos (el corte en oblicuo se recorre 1/cos mas largo). Con normales ortogonales es fvVolStackOpacity de la fase 2. -> [op]
function fv3StackOpacity(d, nrms) {
   var c = nrms.map(function(v) { return Math.abs(d[0] * v[0] + d[1] * v[1] + d[2] * v[2]); }), idx = c.map(function(v, k) { return k; }).sort(function(p, q) { return c[q] - c[p]; });
   var out = c.map(function() { return 0; }), a = idx[0], b = idx.length > 1 ? idx[1] : -1;
   if (b < 0) { out[a] = Math.min(1, 1 / Math.max(1e-6, c[a])); return out; }
   var s = c[a] * c[a] + c[b] * c[b];
   if (c[b] * c[b] / s < 0.04) { out[a] = Math.min(1, 1 / Math.max(1e-6, c[a])); return out; }
   out[a] = Math.min(1, c[a] / s); out[b] = Math.min(1, c[b] / s);
   return out;
}
// las pilas Z/X/Y de la fase 2 (fvVolStack) en el formato generico (las usan la cascara, el resto del disco y el ROJO V3.ON = false)
function fv3FromV2Stack(st, m, group) {
   var D = m.D, N = st.N, zs = D / st.Dz, ax = st.axis, out = { name: ax, group: group || m.family, N: N, head: st.head || 1, cuts: st.cuts, gw: st.gw, gh: st.gh };
   if (ax === "Z") { out.nrm = [0, 0, 1]; out.sp = D / N; }
   else if (ax === "X") { out.nrm = [1, 0, 0]; out.sp = m.w / N; }
   else { out.nrm = [0, 1, 0]; out.sp = m.h / N; }
   for (var j = 0; j < N; ++j) {
      var C = st.cuts[j]; if (!C) continue;
      if (ax === "Z") { var zc = (j + 0.5) * D / N - D / 2; C.P0 = [C.u0, C.v0, zc]; C.U = [1, 0, 0]; C.V = [0, 1, 0]; C.pc = [m.cx, m.cy, zc]; }
      else if (ax === "X") { var xc = (j + 0.5) * m.w / N; C.P0 = [xc, C.v0, C.u0 * zs - D / 2]; C.U = [0, 0, zs]; C.V = [0, 1, 0]; C.pc = [xc, m.cy, 0]; }
      else { var yc = (j + 0.5) * m.h / N; C.P0 = [C.u0, yc, C.v0 * zs - D / 2]; C.U = [1, 0, 0]; C.V = [0, 0, zs]; C.pc = [m.cx, yc, 0]; }
   }
   return out;
}
// TODAS las pilas de un objeto. r = fvVolFromCut(...); opts { Cs (muestreador de la foto en px del modelo; si falta, la rejilla del modelo),
// tex (paso del texel del disco en px del modelo), N (cortes de la fase 2) }. -> { stacks: [...], info: {...} }
function fvVol3Stacks(m, meas, opts) {
   var o = opts || {}, N = o.N || FV_VOLM.N[m.family] || 32, out = [], info = { v3: false };
   function v2(group, part, NN) { var keep = m.part; m.part = part || null; try { ["Z", "X", "Y"].forEach(function(ax) { out.push(fv3FromV2Stack(fvVolStack(m, ax, NN, ax === "Z" ? 0 : FV_VOLM.DZ_MAX), m, group)); }); } finally { m.part = keep; } }
   if (m.family !== "disk" || !FV_VOLM3.ON) { v2(m.family, null, N); return { stacks: out, info: info }; }
   var Cs = o.Cs || function(x, y, cv) { cv[0] = fv3Bil(m.ch[0], m.w, m.h, x, y); cv[1] = fv3Bil(m.ch[1], m.w, m.h, x, y); cv[2] = fv3Bil(m.ch[2], m.w, m.h, x, y); };
   var D = fvVol3DiskStacks(m, meas, Cs, o.tex || 1);
   D.stacks.forEach(function(s) { out.push(s); });
   info.v3 = true; info.disk = D.stats;
   // el RESTO: viento + la luz de disco que queda fuera de la caja (modelo de la fase 2 en pilas de la imagen)
   var lr = 0, lt = 0, i, c, n = m.w * m.h;
   for (i = 0; i < n; ++i) for (c = 0; c < 3; ++c) { var v = m.ch[c][i], fd = m.fd ? m.fd[c][i] : 1; lt += v; lr += v * ((1 - fd) + fd * D.rest[i]); }
   info.restFrac = lt > 0 ? lr / lt : 0;
   if (info.restFrac >= FV_VOLM3.REST_MIN) { m.restW = D.rest; v2("rest", "rest", FV_VOLM3.REST_N); m.restW = null; info.rest = true; }
   else info.rest = false;
   return { stacks: out, info: info };
}

// ============================================================================
// NEBULOSA EXTENSA: RELIEVE SOLO CON ESTRUCTURA DE LA FOTO (ronda 3). Las mismas K capas planas que hoy (fvLayerBitmaps, paintLayers, el
// visor web): cambia QUE pixel va a QUE capa.
// CAUSA MEDIDA DEL «MARMOL» de hoy (G1; reproducido con el pintor de software de tests/fv_V3_neb_node.js): cada pixel va a la capa de su BANDA
// de puntuacion (0,65·luminancia + 0,35·rojez, suavizadas 14 px) y las bandas van en ALTERNANCIA (fvLayerOrder: 7,6,5,… -> capas 3,4,2,5,1,6,
// 0,7). Las fronteras entre capas son CURVAS DE NIVEL de un mapa suavizado: cruzan por el medio de las estructuras brillantes, y al moverse
// cada curva se abre en una cinta (copias desplazadas). En la Soul (lineal y tenue) las curvas son las del ruido y el gradiente de fondo.
// DOS HIPOTESIS REFUTADAS con la misma prueba (5-nov):
//   1. repartir cada pixel en una gaussiana ANCHA de profundidad (un cuerpo grueso): desde un grosor de distancia la capa de delante se ve
//      2,7 veces mas grande que la de detras y el detalle sale a escalas distintas: todo borroso.
//   2. resplandor suave detras + detalle delante + polvo (Multiply) en medio: el detalle se reparte entre dos superficies a distinta profundidad
//      y, desde un grosor, dos capas contiguas difieren un 13 % de escala: copias desplazadas otra vez (borroso y con tintes del croma
//      amplificado en lo oscuro).
// LA REGLA QUE SALE DE LAS DOS: un trozo de foto con detalle tiene que ir ENTERO a UNA capa; lo que cambia de profundidad son ESTRUCTURAS
// completas, y las costuras entre capas tienen que caer donde la foto es OSCURA (los valles entre estructuras), nunca por el medio de una.
// MODELO NUEVO (cuencas de la propia foto, nada de ruido):
//   · cuencas: division por aguas (watershed) de la luminancia suavizada, con semillas en los maximos locales; dos cuencas se FUNDEN si el
//     valle que las separa no es al menos PROM mas oscuro que la mas debil de las dos (dinamica): solo quedan costuras en valles de verdad.
//     Lo que queda por debajo del percentil FLOOR (el fondo tenue) es una region mas.
//   · cada cuenca va ENTERA a una capa: se ordenan por brillo (media ponderada por la luz) y se reparten en K bandas de igual numero de
//     pixeles con el MISMO orden de hoy (fvLayerOrder: lo brillante en el medio de la losa, lo tenue alternando delante y detras; F2/F4b: con
//     lo brillante delante, desde dentro mirando hacia fuera solo quedaba negro).
//   · la costura se suaviza SOFT pixeles de rejilla (los pixeles del valle se reparten entre las dos capas: son oscuros).
//   · desde la Tierra la suma de las capas es la foto (la difusion del error reparte el redondeo).
// Bandera FV_NEB3.ON (con FV_VOLM.ON): false = las capas de hoy (el ROJO del marmol). BREAK "flat" = todo en un plano (ROJO del relieve);
// "noprom" = sin fundir cuencas (costuras por todas partes); "contour" = las bandas de hoy pero en orden MONOTONO (sin alternancia).
// ============================================================================
var FV_NEB3 = {
   ON: false,          // APAGADA por defecto — ELECCION [SIN NINO]: por la metrica gana a hoy (mas relieve, menos inventado, D-g ×4–6 mejor), pero a la
                       // vista salen grietas oscuras en las costuras y un tinte verdoso en el centro de Collinder 34 (prueba del 5-nov); que lo vea Nino
   GRID: 512,          // la division en cuencas se hace a este ancho y las etiquetas se interpolan (suaves) al ancho de las capas
   SMOOTH_R: 1 / 256,  // suavizado de la luminancia antes de dividir (fraccion del ancho; 2 px de rejilla): quita el grano, no las estructuras
   MARK_R: 1 / 64,     // ventana de los maximos locales (semillas): estructuras de ~1/32 del ancho
   FLOOR: 0.25,        // percentil por debajo del cual la foto es «fondo» (una region)
   PROM: 0.05,         // un valle separa dos cuencas si es al menos un 5 % mas oscuro que la mas debil — ELECCION [SIN NINO], barrido 0,20/0,10/0,05:
                       // con 0,20 la Soul (tenue) queda en UNA region y pierde todo el relieve (σ 0 capas); con 0,05, 17 regiones y σ 0,5–1,5
   SOFT: 1,            // radio (rejilla) de la caja ×3 que suaviza las costuras
   ORDER: "alt",       // "alt": el orden alterno de hoy (lo brillante en el medio) · "mono": lo brillante delante (saltos menores, pero la Soul y el
                       // centro de Collinder 34 pierden relieve y drama: 0,44 frente a 0,81 fuera; prueba del 5-nov)
   BACK: 0.6,          // fraccion del FONDO SUAVE (color medio local escalado al minimo local de la luminancia) que va a la capa de atras: rellena los huecos
                       // que abre la paralaje entre cuencas con el gas de detras en vez de negro (es suave: no se duplica ningun detalle)
   BACK_R: 1 / 48,     // radio de la erosion y del suavizado del fondo (fraccion del ancho)
   BREAK: ""           // pruebas: "flat" · "noprom" · "contour"
};
function fv3Box3(a, W, H, r) {   // caja separable ×3 (casi gaussiana)
   var src = a, x, y, s, n = 2 * r + 1, tmp = new Float32Array(W * H), out;
   for (var pass = 0; pass < 3; ++pass) {
      out = new Float32Array(W * H);
      for (y = 0; y < H; ++y) { var o = y * W; s = 0; for (x = -r; x <= r; ++x) s += src[o + Math.max(0, Math.min(W - 1, x))]; for (x = 0; x < W; ++x) { tmp[o + x] = s / n; s += src[o + Math.min(W - 1, x + r + 1)] - src[o + Math.max(0, x - r)]; } }
      for (x = 0; x < W; ++x) { s = 0; for (y = -r; y <= r; ++y) s += tmp[Math.max(0, Math.min(H - 1, y)) * W + x]; for (y = 0; y < H; ++y) { out[y * W + x] = s / n; s += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x]; } }
      src = out;
   }
   return src;
}
function fv3MaxF(a, W, H, r) {   // maximo en un cuadrado (2r+1)², separable, van Herk / Gil-Werman (coste fijo por pixel)
   var out = new Float32Array(W * H), tmp = new Float32Array(W * H), L = Math.max(W, H), w = 2 * r + 1, g = new Float32Array(L + w), h = new Float32Array(L + w), x, y, k;
   function run(get, set, n) {
      var m = n + 2 * r;   // linea extendida con el borde replicado
      for (k = 0; k < m; ++k) { var v = get(Math.max(0, Math.min(n - 1, k - r))); g[k] = (k % w === 0) ? v : Math.max(g[k - 1], v); }
      for (k = m - 1; k >= 0; --k) { var v2 = get(Math.max(0, Math.min(n - 1, k - r))); h[k] = (k === m - 1 || (k + 1) % w === 0) ? v2 : Math.max(h[k + 1], v2); }
      for (k = 0; k < n; ++k) set(k, Math.max(h[k], g[k + 2 * r]));
   }
   for (y = 0; y < H; ++y) { var o = y * W; run(function(q) { return a[o + q]; }, function(q, v) { tmp[o + q] = v; }, W); }
   for (x = 0; x < W; ++x) run(function(q) { return tmp[q * W + x]; }, function(q, v) { out[q * W + x] = v; }, H);
   return out;
}
function fv3Pct(a, p, step) { var s = []; for (var i = 0; i < a.length; i += (step || 7)) s.push(a[i]); s.sort(function(x, y) { return x - y; }); return s.length ? s[Math.min(s.length - 1, Math.floor(p * (s.length - 1)))] : 0; }
function fv3LayerOrder(K) {   // = fvLayerOrder de fv_build.js (copiado: el motor no depende del constructor)
   var ord = new Array(K), mid = Math.floor((K - 1) / 2);
   for (var r = 0; r < K; ++r) { var off = (r % 2 === 0) ? r / 2 : -(r + 1) / 2, lay = mid - off; if (lay < 0 || lay >= K) lay = (lay < 0) ? K - 1 - r : r; ord[K - 1 - r] = lay; }
   return ord;
}
// cuencas de S (gw·gh, brillo): etiqueta por pixel (0 = fondo bajo FLOOR) tras fundir las separadas por valles poco profundos
function fv3Basins(S, gw, gh, floorV, markR, prom) {
   var n = gw * gh, lab = new Int32Array(n), i, x, y, NQ = 1024, smax = 1e-6;
   for (i = 0; i < n; ++i) if (S[i] > smax) smax = S[i];
   var M = fv3MaxF(S, gw, gh, markR), peak = [0], nl = 0;
   // semillas: maximos locales por encima del fondo (en mesetas, el primero que se encuentra)
   for (i = 0; i < n; ++i) if (S[i] > floorV && S[i] >= M[i] && lab[i] === 0) {
      var ok = true; x = i % gw; y = (i - x) / gw;
      for (var dy = -1; dy <= 1 && ok; ++dy) for (var dx = -1; dx <= 1; ++dx) { var xx = x + dx, yy = y + dy; if (xx < 0 || yy < 0 || xx >= gw || yy >= gh) continue; if (lab[yy * gw + xx] > 0) { ok = false; break; } }
      if (ok) { lab[i] = ++nl; peak.push(S[i]); }
   }
   // inundacion por niveles (de brillante a oscuro), cubos de 1024 niveles; anota el primer encuentro (puerto) de cada par de cuencas
   var heads = new Int32Array(NQ).fill(-1), next = new Int32Array(n).fill(-1), queued = new Uint8Array(n), saddle = {};
   function lv(v) { var q = Math.floor((1 - v / smax) * (NQ - 1)); return q < 0 ? 0 : (q >= NQ ? NQ - 1 : q); }
   function push(j, q) { next[j] = heads[q]; heads[q] = j; queued[j] = 1; }
   for (i = 0; i < n; ++i) if (lab[i] > 0) push(i, lv(S[i]));
   var NB = [-1, 1, -gw, gw];
   for (var q = 0; q < NQ; ++q) {
      while (heads[q] >= 0) {
         var p = heads[q]; heads[q] = next[p];
         var a = lab[p], px0 = p % gw;
         for (var t = 0; t < 4; ++t) {
            var j = p + NB[t]; if (j < 0 || j >= n || (t === 0 && px0 === 0) || (t === 1 && px0 === gw - 1)) continue;
            if (S[j] <= floorV) continue;
            var b = lab[j];
            if (b === 0) { if (!queued[j]) { lab[j] = a; push(j, Math.max(q, lv(S[j]))); } }
            else if (b !== a) { var key = a < b ? a * 65536 + b : b * 65536 + a, sv = Math.min(S[p], S[j]); if (!(key in saddle) || sv > saddle[key]) saddle[key] = sv; }
         }
      }
   }
   // fusion por dinamica: de los puertos mas altos a los mas bajos, funde si el valle no es PROM mas oscuro que el pico mas bajo de los dos
   var par = new Int32Array(nl + 1), pk = new Float32Array(nl + 1);
   for (i = 0; i <= nl; ++i) { par[i] = i; pk[i] = peak[i] || 0; }
   function find(u) { while (par[u] !== u) { par[u] = par[par[u]]; u = par[u]; } return u; }
   var pairs = Object.keys(saddle).map(function(k2) { var kk = +k2; return [Math.floor(kk / 65536), kk % 65536, saddle[k2]]; });
   pairs.sort(function(u, v) { return v[2] - u[2]; });
   var merges = 0;
   if (prom > 0) pairs.forEach(function(e) { var ra = find(e[0]), rb = find(e[1]); if (ra === rb) return; var lo = Math.min(pk[ra], pk[rb]); if (e[2] >= (1 - prom) * lo) { if (pk[ra] >= pk[rb]) par[rb] = ra; else par[ra] = rb; ++merges; } });
   var remap = new Int32Array(nl + 1), nr = 0;
   for (i = 1; i <= nl; ++i) { var r = find(i); if (remap[r] === 0) remap[r] = ++nr; remap[i] = remap[r]; }
   for (i = 0; i < n; ++i) if (lab[i] > 0) lab[i] = remap[find(lab[i])];
   return { lab: lab, n: nr, seeds: nl, merges: merges };
}
// px Uint32 W·H (la foto sin estrellas y sin objetos), K capas (0 = la mas cercana), edgeFrac = FV_BUILD.EDGE
// -> { views: [Uint32Array W·H] (K capas), centers, stats }
function fv3NebLayers(px, W, H, K, edgeFrac) {
   var Q = FV_NEB3, N = W * H, i, k, x, y, t0 = Date.now(), ORD = fv3LayerOrder(K), flat = Q.BREAK === "flat";
   // 1. luminancia (y rojez, para "contour") a la rejilla
   var gw = Math.min(W, Q.GRID), gh = Math.max(2, Math.round(gw * H / W)), sx = W / gw, sy = H / gh, Ls = new Float32Array(gw * gh), Rs = new Float32Array(gw * gh), cnt = new Float32Array(gw * gh);
   for (y = 0; y < H; ++y) { var gy = Math.min(gh - 1, Math.floor(y / sy)); for (x = 0; x < W; ++x) { var p = px[y * W + x], r0 = (p >>> 16) & 255, g0 = (p >>> 8) & 255, b0 = p & 255, gi = gy * gw + Math.min(gw - 1, Math.floor(x / sx)); Ls[gi] += (0.2126 * r0 + 0.7152 * g0 + 0.0722 * b0) / 255; Rs[gi] += 0.5 + 0.5 * (r0 - b0) / (r0 + g0 + b0 + 1); cnt[gi] += 1; } }
   var Cg = null;
   if (Q.BACK > 0 && !flat) { Cg = [new Float32Array(gw * gh), new Float32Array(gw * gh), new Float32Array(gw * gh)]; for (y = 0; y < H; ++y) { var gy2 = Math.min(gh - 1, Math.floor(y / sy)); for (x = 0; x < W; ++x) { var p2 = px[y * W + x], gi2 = gy2 * gw + Math.min(gw - 1, Math.floor(x / sx)); Cg[0][gi2] += (p2 >>> 16) & 255; Cg[1][gi2] += (p2 >>> 8) & 255; Cg[2][gi2] += p2 & 255; } } }
   for (i = 0; i < gw * gh; ++i) { Ls[i] = cnt[i] > 0 ? Ls[i] / cnt[i] : 0; Rs[i] = cnt[i] > 0 ? Rs[i] / cnt[i] : 0.5; if (Cg && cnt[i] > 0) { Cg[0][i] /= cnt[i]; Cg[1][i] /= cnt[i]; Cg[2][i] /= cnt[i]; } }
   var S = fv3Box3(Ls, gw, gh, Math.max(1, Math.round(Q.SMOOTH_R * gw))), layG = new Int32Array(gw * gh), st = { regions: 0, seeds: 0, merges: 0 };
   if (flat) layG.fill(Math.round((K - 1) / 2));
   else if (Q.BREAK === "contour") {   // ROJO de la costura: bandas de curvas de nivel (como hoy) pero en orden monotono
      var sc = new Float32Array(gw * gh), rb = Math.max(1, Math.round(14 / 2048 * gw)), Lb = fv3Box3(Ls, gw, gh, rb), Rb = fv3Box3(Rs, gw, gh, rb);
      for (i = 0; i < gw * gh; ++i) sc[i] = 0.65 * Lb[i] + 0.35 * Rb[i];
      var cs = []; for (k = 1; k < K; ++k) cs.push(fv3Pct(sc, k / K, 3));
      for (i = 0; i < gw * gh; ++i) { var bnd = 0; while (bnd < K - 1 && sc[i] > cs[bnd]) ++bnd; layG[i] = K - 1 - bnd; }
   } else {
      // 2. cuencas
      var floorV = fv3Pct(S, Q.FLOOR, 3), BS = fv3Basins(S, gw, gh, floorV, Math.max(2, Math.round(Q.MARK_R * gw)), Q.BREAK === "noprom" ? 0 : Q.PROM), lab = BS.lab, nr = BS.n;
      st.regions = nr; st.seeds = BS.seeds; st.merges = BS.merges;
      // 3. brillo de cada region (media de S ponderada por la luz) y numero de pixeles; la 0 (fondo) es la mas tenue
      var sw = new Float64Array(nr + 1), sl = new Float64Array(nr + 1), np = new Float64Array(nr + 1);
      for (i = 0; i < gw * gh; ++i) { var lb = lab[i]; sw[lb] += S[i] * Ls[i]; sl[lb] += Ls[i]; np[lb] += 1; }
      var idx = []; for (var rr = 0; rr <= nr; ++rr) idx.push(rr);
      var bri = function(u) { return u === 0 ? -1 : (sl[u] > 0 ? sw[u] / sl[u] : 0); };
      idx.sort(function(u, v) { return bri(u) - bri(v); });
      // 4. K bandas de igual numero de pixeles (como los cuantiles de hoy) -> capa ORD[banda]; una region entera en una banda
      var tot = gw * gh, cum = 0, layR = new Int32Array(nr + 1);
      idx.forEach(function(u) { var mid = (cum + np[u] / 2) / tot, band = Math.min(K - 1, Math.floor(mid * K)); layR[u] = Q.ORDER === "alt" ? ORD[band] : K - 1 - band; cum += np[u]; });
      for (i = 0; i < gw * gh; ++i) layG[i] = layR[lab[i]];
      st.layerPix = []; for (k = 0; k < K; ++k) st.layerPix.push(0); for (i = 0; i < gw * gh; ++i) st.layerPix[layG[i]]++;
   }
   // 5. pesos por capa a la rejilla (una sola capa salvo en las costuras, suavizadas SOFT)
   var Wk = [];
   for (k = 0; k < K; ++k) { var mk = new Float32Array(gw * gh), any = false; for (i = 0; i < gw * gh; ++i) if (layG[i] === k) { mk[i] = 1; any = true; } Wk.push(any ? (Q.SOFT > 0 && !flat ? fv3Box3(mk, gw, gh, Q.SOFT) : mk) : null); }
   // 5b. FONDO SUAVE -> capa de atras: color medio local (suavizado) escalado al minimo local de la LUMINANCIA (erosion + suavizado: queda por
   //     debajo de las estructuras). Tiene que ser SUAVE en luminancia y en color: (prueba del 5-nov) con un minimo por canal el resto cambiaba
   //     de tono (manchas verdes) y con «el color del propio pixel» el fondo era una copia de la foto al 60 % dos capas mas atras (copias).
   //     Cada pixel cede f·fondo con f = BACK·min(1, min_c(pixel_c / fondo_c)): solo los detalles OSCUROS bajan el fondo.
   var Bg = null, kBack = K - 1;
   if (Cg) {
      var rBk = Math.max(2, Math.round(Q.BACK_R * gw)), ng = new Float32Array(gw * gh); for (i = 0; i < gw * gh; ++i) ng[i] = -Ls[i];
      var er = fv3MaxF(ng, gw, gh, rBk); for (i = 0; i < gw * gh; ++i) er[i] = -er[i];
      var Be = fv3Box3(er, gw, gh, rBk), Lb = fv3Box3(Ls, gw, gh, rBk); Bg = [];
      for (var c0 = 0; c0 < 3; ++c0) { var Cb = fv3Box3(Cg[c0], gw, gh, rBk); for (i = 0; i < gw * gh; ++i) Cb[i] *= Lb[i] > 1e-5 ? Math.min(1, Be[i] / Lb[i]) : 0; Bg.push(Cb); }
   }
   // 6. a la resolucion de las capas: pesos bilineales, difusion del error a lo largo de las capas, borde como hoy
   var views = [], e = Math.max(4, Math.round((edgeFrac || 0.18) * Math.max(W, H))), wk = new Float64Array(K), backL = 0, allL = 0;
   for (k = 0; k < K; ++k) views.push(new Uint32Array(N));
   for (y = 0; y < H; ++y) {
      var ey = Math.min(y, H - 1 - y) / e; ey = ey >= 1 ? 1 : (ey <= 0 ? 0 : ey * ey * (3 - 2 * ey)); ey *= ey;
      var v = (y + 0.5) / sy - 0.5, iv = Math.max(0, Math.min(gh - 2, Math.floor(v))), fv = Math.max(0, Math.min(1, v - iv));
      for (x = 0; x < W; ++x) {
         i = y * W + x; var ex = Math.min(x, W - 1 - x) / e; ex = ex >= 1 ? 1 : (ex <= 0 ? 0 : ex * ex * (3 - 2 * ex)); ex = ex * ex * ey;
         var q = px[i]; if (ex <= 0 || (q & 0xffffff) === 0) continue;
         var u = (x + 0.5) / sx - 0.5, iu = Math.max(0, Math.min(gw - 2, Math.floor(u))), fu = Math.max(0, Math.min(1, u - iu)), o = iv * gw + iu, tw = 0;
         for (k = 0; k < K; ++k) { var A = Wk[k]; wk[k] = A ? (A[o] * (1 - fu) + A[o + 1] * fu) * (1 - fv) + (A[o + gw] * (1 - fu) + A[o + gw + 1] * fu) * fv : 0; tw += wk[k]; }
         if (!(tw > 0)) continue;
         var fB = 0, bc0 = 0, bc1 = 0, bc2 = 0;
         if (Bg) {
            var w00 = (1 - fu) * (1 - fv), w01 = fu * (1 - fv), w10 = (1 - fu) * fv, w11 = fu * fv;
            bc0 = ex * (Bg[0][o] * w00 + Bg[0][o + 1] * w01 + Bg[0][o + gw] * w10 + Bg[0][o + gw + 1] * w11); bc1 = ex * (Bg[1][o] * w00 + Bg[1][o + 1] * w01 + Bg[1][o + gw] * w10 + Bg[1][o + gw + 1] * w11); bc2 = ex * (Bg[2][o] * w00 + Bg[2][o + 1] * w01 + Bg[2][o + gw] * w10 + Bg[2][o + gw + 1] * w11);
            var rr0 = bc0 > 0.5 ? ((q >>> 16) & 255) * ex / bc0 : 1e9, rr1 = bc1 > 0.5 ? ((q >>> 8) & 255) * ex / bc1 : 1e9, rr2 = bc2 > 0.5 ? (q & 255) * ex / bc2 : 1e9;
            fB = Q.BACK * Math.min(1, rr0, rr1, rr2);
         }
         for (var c = 0; c < 3; ++c) {
            var sh = 16 - 8 * c, val = ((q >>> sh) & 255) * ex, S2 = 0, prev = 0, bv = fB * (c === 0 ? bc0 : (c === 1 ? bc1 : bc2));
            if (bv > val) bv = val;
            backL += bv; allL += val;
            for (k = 0; k < K; ++k) { var wv = (val - bv) * wk[k] / tw + (k === kBack ? bv : 0); if (wv <= 0) continue; S2 += wv; var rv = Math.round(S2), dv = rv - prev; prev = rv; if (dv > 0) views[k][i] |= (dv > 255 ? 255 : dv) << sh; }
         }
      }
   }
   for (k = 0; k < K; ++k) { var V = views[k]; for (i = 0; i < N; ++i) V[i] = (0xff000000 | V[i]) >>> 0; }
   var centers = []; for (k = 0; k < K; ++k) centers.push(k / Math.max(1, K - 1));
   st.ms = Date.now() - t0; st.grid = [gw, gh]; st.backFrac = allL > 0 ? backL / allL : 0;
   return { views: views, centers: centers, stats: st, labGrid: flat ? null : layG };
}
