// ============================================================================
// FieldVoyager/src/engine/fv_galcolor.js — EL «COLOR REAL» DE LA VIA LACTEA EN GALAXIA (encargo GC, 9-nov-2026). PURO (la lectura de
// PixInsight va aparte, en fvGalColorLoad; el calculo, fvGalColorCompute, no toca nada de PixInsight y corre tambien en node).
// ----------------------------------------------------------------------------
// Nino: «Debe tener el "color real", tomando como balance de blancos la galaxia espiral media». Es lo que hace SPCC con sus fotos:
//   · la REFERENCIA DE BLANCO es el espectro de la «Average Spiral Galaxy» (se lee de una instancia nueva de SpectrophotometricColorCalibration:
//     whiteReferenceSpectrum) y las TRES CURVAS de la camara virtual son las que trae SPCC por defecto (redFilterTrCurve, greenFilterTrCurve,
//     blueFilterTrCurve y deviceQECurve);
//   · cada componente de la galaxia lleva un espectro (de la base de espectros de la instalacion del usuario,
//     <PixInsight>/library/white-references.xspd, SOLO LECTURA, no se copia ni se redistribuye): disco viejo y bulbo = «Elliptical Galaxy»,
//     disco joven integrado = «Sdm Galaxy», cumulos OB = «B0V Star»; la region HII, un espectro de lineas (caso B); el polvo, la ley CCM89.
//   · se integra espectro × filtro × λ (fotones) por canal, se divide por lo mismo del blanco (la espiral media = R = G = B = 1) y se
//     normaliza al verde: [R/G, 1, B/G]. Las asignaciones salen en FV_GAL3.COL_OLD = COL_BULGE, COL_YOUNG, COL_CL, COL_HII y DUST_RGB.
// Fuentes (docs/investigacion-galaxia-color-real-y-homogenea.md, §1): espectros SWIRE (Polletta et al. 2007) tal como los empaqueta SPCC
// (© Vicent Peris / Pleiades Astrophoto 2022); Licquia, Newman & Brinchmann 2015 (el color de la Galaxia entera, B−V = 0,744); Roberts &
// Haynes 1994; Cardelli, Clayton & Mathis 1989 (CCM89, R_V = 3,1); Osterbrock & Ferland 2006 (caso B: Hα/Hβ = 2,86).
// ORDEN: las banderas (FV_GAL_COLOR.ON, FV_GAL_DATA.ON) se fijan ANTES de abrir el dialogo / de pedir el mapa de cara (fvGalStart pide fvGal3Tex() antes de
// construir la galaxia de datos); cambiar una a mitad de una construccion de datos la reinicia.
// SIN RUTAS FIJAS Y SIN SOLO-WINDOWS: la ruta de la base sale de CoreApplication.dirPath; si no se halla el fichero o falla la lectura (o si
// SPCC no expone las curvas), se usan las constantes de reserva (FALLBACK, calculadas con estos mismos espectros) y se dice en el log.
// BANDERA FV_GAL_COLOR.ON, ENCENDIDA por defecto desde el 10-nov-2026 (decision de Nino; sin el extracto de trazadores, fvGalDefaultsGuard la apaga): apagada, nada de esto se ejecuta y la galaxia es la de hoy bit a bit. Encendida (antes de
// abrir el dialogo, como FV_GAL_DATA.ON), fvGalColorSync() (gancho de una linea en fvGal3TexReady) lee, calcula una vez por sesion, y pone en
// FV_GAL3 los colores y el presupuesto de luz; al apagarla los devuelve a los de hoy.
// ES5.
// ============================================================================

var FV_GAL_COLOR = {
   ON: true,
   // las constantes de RESERVA: [R/G, 1, B/G] con el blanco de la espiral media, fotones, filtros por defecto de SPCC (investigacion GR §1.4,
   // medidas con gr_color.js). hii = RGB de las lineas, normalizado al maximo. Con ellas basta si no se halla la base de espectros.
   // (GF5) hii5: el de HII5 de abajo con las curvas por defecto (medido con gf5_hii_color.js: B/R 0,479, G/R 0,344, h 3°)
   FALLBACK: { old: [1.040, 1, 0.915], young: [0.930, 1, 1.131], cl: [0.626, 1, 1.853], hii: [1.00, 0.588, 0.918], dust: [0.867, 1, 1.190], hii5: [1.00, 0.344, 0.479] },
   NAMES: { old: "Elliptical Galaxy", young: "Sdm Galaxy", cl: "B0V Star" },
   // lineas del gas ionizado (caso B): Hα/Hβ = 2,86; [NII]6584/Hα, [OIII]5007/Hβ y [SII]/Hα, tipicos de una HII del disco
   // ([OIII]/Hβ = 1 es un termino medio, NO VERIFICADO: es un mando, entre el magenta y el lila)
   HII: { HA_HB: 2.86, NII: 0.30, OIII: 1.0, SII: 0.10 },
   // (encargo GF5) la HII de los nudos de GF5 (FV_GAL_GF5.ON): cocientes de una HII de disco a metalicidad solar en la secuencia de formacion estelar del
   // BPT ([NII]/Hα 0,35, [OIII]/Hβ 0,45: Kauffmann et al. 2003; Kewley et al. 2006; [SII]/Hα 0,25) y el enrojecimiento medio de las HII de discos
   // espirales, A(Hα) ≈ 1,1 mag -> E(B−V) 0,43 con CCM89 (Kennicutt 1983). Citados de memoria, NO VERIFICADOS en linea; sensibilidad en gf5_hii_color.js
   HII5: { HA_HB: 2.86, NII: 0.35, OIII: 0.45, SII: 0.25, EBV: 0.43 },
   RV: 3.1,
   L0: 300, L1: 1100, DL: 0.5,               // rejilla de la integral (nm)
   // el PRESUPUESTO DE LUZ (A_OLD, A_YOUNG, DUST_K de FV_GAL3 mientras la bandera esta encendida; A_YOUNG_D sustituye a A_YOUNG con FV_GAL_DATA.ON; K_HII y K_CL multiplican A_HII / A_CL de los nudos
   // sembrados; K_HP (si no, K_HII), la amplitud de las HII medidas de NUEVA y K_CL la de sus nubes; K_PM, la de las marcas doradas de los maseres).
   // PROVISIONAL, lo fija tests/_galaxy/gc/gc_fit.js para que el color integrado de cara de HOY y de NUEVA (FV_GAL_DATA) de R/G = 1,03 y
   // B/G = 0,94 (Licquia et al. 2015 con el blanco de la espiral media); hay que repetirlo cuando cambie la geometria de los brazos.
   BUDGET: { A_OLD: 2.267, A_YOUNG: 0.126, A_YOUNG_D: 0.272, DUST_K: 1.4, K_HII: 0.4, K_HP: 0.1, K_CL: 0.15, K_PM: 0.3 },
   // (encargo GF, 9-nov) con la geometria ajustada (FV_GAL_GG.ON) manda ESTE presupuesto, uno por cada opcion de brillo de los brazos
   // (FV_GAL_GG.OLD_MODE: "A" = m = 2 medido en la Via Lactea, "B" = dos brazos viejos con contraste de Sb). Sobre BUDGET: solo cambian A_OLD y
   // A_YOUNG_D (los fija tests/_galaxy/gc/gc_fit.js --gg=A|B --write para el color integrado de cara R/G 1,03 · B/G 0,94 de la galaxia GG).
   BUDGET_GG: { A: { A_OLD: 2.661, A_YOUNG_D: 0.118, K_HII: 0.12 }, B: { A_OLD: 1.635, A_YOUNG_D: 0.058, K_HII: 0.12 }, B2: { A_OLD: 2.183, A_YOUNG_D: 0.01, K_HII: 0.12 } },
   // (encargo GF2) B2 = la opcion B con GF2 (FV_GAL_GF2.ON): bulbo y barra con su luz, brazos exponenciales, nudos compactos (gc_fit.js --gg=B2 --write)
   LIBDIRS: ["/../library/", "/../../library/", "/library/", "/../Resources/library/"],   // relativas a CoreApplication.dirPath (Windows verificado; macOS y Linux NO VERIFICADO)
   state: null,                               // lo calculado: { cols, src, why, msRead, msCalc, ... } (una vez por sesion)
   base: null, basePT: null,                  // los valores de hoy de FV_GAL3 y de los puntos de FV_GAL_DATA (guardados al encender)
   applied: false
};

// ---------------------------------------------------------------------------
// espectros y curvas: «λ,f,λ,f,…» (nm)
// ---------------------------------------------------------------------------
function fvGalColorCurve(str) {
   var p = String(str).split(","), n = p.length >> 1, w = new Float64Array(n), f = new Float64Array(n);
   for (var i = 0; i < n; ++i) { w[i] = parseFloat(p[2 * i]); f[i] = parseFloat(p[2 * i + 1]); }
   return { w: w, f: f, n: n };
}
// interpolacion lineal; 0 fuera del tramo. hint = indice de partida (las llamadas van con λ creciente)
function fvGalColorAt(c, l) {
   var w = c.w, f = c.f, n = c.n; if (n < 2 || l < w[0] || l > w[n - 1]) return 0;
   var lo = 0, hi = n - 1; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (w[m] <= l) lo = m; else hi = m; }
   var t = (l - w[lo]) / Math.max(1e-9, w[hi] - w[lo]); return f[lo] * (1 - t) + f[hi] * t;
}
// ∫ S(λ)·T(λ)·QE(λ)·[λ] dλ  (fotones: × λ)
function fvGalColorInteg(S, T, QE, extra) {
   var C = FV_GAL_COLOR, s = 0;
   for (var l = C.L0; l <= C.L1; l += C.DL) {
      var t = fvGalColorAt(T, l); if (t === 0) continue;
      var v = fvGalColorAt(S, l) * t * l; if (QE) v *= fvGalColorAt(QE, l); if (extra) v *= extra(l);
      s += v;
   }
   return s * C.DL;
}
// la linea «name» de la base de espectros (un <WhiteRef name="…" … data="…"/> por linea) -> el texto de data o null
function fvGalColorLibData(txt, name) {
   var k = txt.indexOf('name="' + name + '"'); if (k < 0) return null;
   var e = txt.indexOf(">", k), d = txt.indexOf('data="', k); if (d < 0 || (e >= 0 && d > e)) return null;
   d += 6; return txt.substring(d, txt.indexOf('"', d));
}
// ley de extincion CCM89 (A_λ/A_V), λ en nm, R_V
function fvGalColorCCM(lnm, Rv) {
   var x = 1000 / lnm, y, a, b;
   if (x < 1.1) { a = 0.574 * Math.pow(x, 1.61); b = -0.527 * Math.pow(x, 1.61); }
   else {
      y = x - 1.82;
      a = 1 + 0.17699 * y - 0.50447 * y * y - 0.02427 * Math.pow(y, 3) + 0.72085 * Math.pow(y, 4) + 0.01979 * Math.pow(y, 5) - 0.7753 * Math.pow(y, 6) + 0.32999 * Math.pow(y, 7);
      b = 1.41338 * y + 2.28305 * y * y + 1.07233 * Math.pow(y, 3) - 5.38434 * Math.pow(y, 4) - 0.62251 * Math.pow(y, 5) + 5.3026 * Math.pow(y, 6) - 2.09002 * Math.pow(y, 7);
   }
   return a + b / Rv;
}
// las lineas de una HII (caso B), [λ nm, flujo relativo a Hβ = 1]; [NII]6548 = 6584/3, [OIII]4959 = 5007/2,98
function fvGalColorLines(h) {
   var Ha = h.HA_HB;
   return [[486.1, 1], [656.3, Ha], [658.4, h.NII * Ha], [654.8, h.NII * Ha / 3], [500.7, h.OIII], [495.9, h.OIII / 2.98], [434.0, 0.468], [410.2, 0.259], [671.6, h.SII * Ha * 0.45], [673.1, h.SII * Ha * 0.55]];
}
// -> max = 1 (los COL_* de FV_GAL3 llevan el canal mayor en 1; la amplitud la da A_*)
function fvGalColorToMax(c) { var m = Math.max(c[0], c[1], c[2]); return [c[0] / m, c[1] / m, c[2] / m]; }

// ---------------------------------------------------------------------------
// EL CALCULO. inp = { white, r, g, b, qe: textos «λ,f,…» (de SPCC); lib: el texto de white-references.xspd o null }
// -> { src: "lib" | "fallback", why, cols: { old, young, cl, hii, dust }, ratios: { old, young, cl (R/G,1,B/G) } }
// ---------------------------------------------------------------------------
function fvGalColorCompute(inp) {
   var C = FV_GAL_COLOR, F = C.FALLBACK, out = { src: "fallback", why: "", cols: null, ratios: { old: F.old.slice(), young: F.young.slice(), cl: F.cl.slice() }, hiiRaw: F.hii.slice(), dust: F.dust.slice() };
   var ok = !!(inp && inp.white && inp.r && inp.g && inp.b);
   if (!ok) out.why = "SPCC does not expose the curves";
   else if (!inp.lib) out.why = "spectra database not found";
   else {
      try {
         var W = fvGalColorCurve(inp.white), T = [fvGalColorCurve(inp.r), fvGalColorCurve(inp.g), fvGalColorCurve(inp.b)], QE = inp.qe ? fvGalColorCurve(inp.qe) : null;
         var wh = [fvGalColorInteg(W, T[0], QE), fvGalColorInteg(W, T[1], QE), fvGalColorInteg(W, T[2], QE)];
         if (!(wh[0] > 0 && wh[1] > 0 && wh[2] > 0)) throw new Error("white spectrum outside the filters");
         var got = {};
         ["old", "young", "cl"].forEach(function (k) {
            var d = fvGalColorLibData(inp.lib, C.NAMES[k]); if (!d) throw new Error("no spectrum " + C.NAMES[k]);
            var S = fvGalColorCurve(d), c = [fvGalColorInteg(S, T[0], QE) / wh[0], fvGalColorInteg(S, T[1], QE) / wh[1], fvGalColorInteg(S, T[2], QE) / wh[2]];
            if (!(c[0] > 0 && c[1] > 0 && c[2] > 0)) throw new Error("spectrum " + C.NAMES[k] + " outside the filters");
            got[k] = [c[0] / c[1], 1, c[2] / c[1]];
         });
         // HII: lineas por los filtros, con el blanco; maximo = 1
         var L = fvGalColorLines(C.HII), h = [0, 0, 0];
         L.forEach(function (e) { var kk = e[1] * e[0]; for (var ch = 0; ch < 3; ++ch) h[ch] += kk * fvGalColorAt(T[ch], e[0]) * (QE ? fvGalColorAt(QE, e[0]) : 1); });
         var hh = fvGalColorToMax([h[0] / wh[0], h[1] / wh[1], h[2] / wh[2]]);
         // polvo CCM89: A_canal/A_V efectivo sobre la espiral media (A_V pequeno, para que sea lineal), normalizado al verde
         var Av = 0.1, kk2 = [];
         for (var c3 = 0; c3 < 3; ++c3) kk2.push(-2.5 * Math.log(fvGalColorInteg(W, T[c3], QE, function (l) { return Math.pow(10, -0.4 * Av * fvGalColorCCM(l, C.RV)); }) / wh[c3]) / Math.LN10 / Av);
         if (!(kk2[0] > 0 && kk2[1] > 0 && kk2[2] > kk2[1] && kk2[1] > kk2[0])) throw new Error("dust law out of order");
         out.ratios = got; out.hiiRaw = hh; out.dust = [kk2[0] / kk2[1], 1, kk2[2] / kk2[1]]; out.src = "lib"; out.why = "";
         // (GF5) la HII de GF5 con enrojecimiento: aparte y sin tocar lo de arriba (si falla, se queda la reserva de FALLBACK.hii5)
         try { var H5 = C.HII5, L5 = fvGalColorLines(H5), h5 = [0, 0, 0];
            L5.forEach(function (e) { var kk = e[1] * e[0] * Math.pow(10, -0.4 * H5.EBV * C.RV * fvGalColorCCM(e[0], C.RV)); for (var ch = 0; ch < 3; ++ch) h5[ch] += kk * fvGalColorAt(T[ch], e[0]) * (QE ? fvGalColorAt(QE, e[0]) : 1); });
            if (h5[0] > 0 && h5[1] > 0 && h5[2] > 0) out.hii5 = fvGalColorToMax([h5[0] / wh[0], h5[1] / wh[1], h5[2] / wh[2]]);
         } catch (e5) { out.hii5 = null; }
      } catch (e) { out.why = String(e && e.message ? e.message : e); out.ratios = { old: F.old.slice(), young: F.young.slice(), cl: F.cl.slice() }; out.hiiRaw = F.hii.slice(); out.dust = F.dust.slice(); }
   }
   out.cols = { old: fvGalColorToMax(out.ratios.old), young: fvGalColorToMax(out.ratios.young), cl: fvGalColorToMax(out.ratios.cl), hii: fvGalColorToMax(out.hiiRaw), dust: out.dust.slice() };
   return out;
}

// ---------------------------------------------------------------------------
// LA LECTURA (PixInsight): las curvas de SPCC y la base de espectros. io (opcional, para las pruebas) = { spcc: {white,r,g,b,qe}|null, lib: texto|null }
// ---------------------------------------------------------------------------
function fvGalColorRead() {
   var res = { spcc: null, lib: null, libPath: "", msRead: 0, notes: [] }, t0 = Date.now();
   try {
      if (typeof SpectrophotometricColorCalibration === "function") {
         var P = new SpectrophotometricColorCalibration;
         res.spcc = { white: P.whiteReferenceSpectrum, r: P.redFilterTrCurve, g: P.greenFilterTrCurve, b: P.blueFilterTrCurve, qe: P.deviceQECurve, name: P.whiteReferenceName };
         if (!(String(res.spcc.white).length > 100 && String(res.spcc.r).length > 20 && String(res.spcc.g).length > 20 && String(res.spcc.b).length > 20)) { res.notes.push("SPCC curves empty"); res.spcc = null; }
      } else res.notes.push("no SPCC process");
   } catch (e) { res.notes.push("SPCC: " + e); res.spcc = null; }
   try {
      if (typeof CoreApplication !== "undefined" && typeof File !== "undefined") {
         var dirs = FV_GAL_COLOR.LIBDIRS, base = String(CoreApplication.dirPath).split("\\").join("/");
         for (var i = 0; i < dirs.length && !res.lib; ++i) {
            var f = base + dirs[i] + "white-references.xspd";
            if (File.exists(f)) { res.lib = String(File.readTextFile(f)); res.libPath = f; }
         }
         if (!res.lib) res.notes.push("white-references.xspd not found under " + base);
      }
   } catch (e2) { res.notes.push("library: " + e2); res.lib = null; }
   res.msRead = Date.now() - t0;
   return res;
}
// calcula UNA vez por sesion (io para las pruebas) -> FV_GAL_COLOR.state
function fvGalColorLoad(io) {
   var C = FV_GAL_COLOR; if (C.state && !io) return C.state;
   var t0 = Date.now(), rd = io || fvGalColorRead(), t1 = Date.now();
   var inp = rd.spcc ? { white: rd.spcc.white, r: rd.spcc.r, g: rd.spcc.g, b: rd.spcc.b, qe: rd.spcc.qe, lib: rd.lib } : { lib: rd.lib };
   var st = fvGalColorCompute(inp);
   st.msRead = rd.msRead !== undefined ? rd.msRead : (t1 - t0); st.msCalc = Date.now() - t1; st.libPath = rd.libPath || ""; st.notes = rd.notes || [];
   if (st.src === "fallback" && !st.why) st.why = (st.notes || []).join("; ");
   if (!io) C.state = st;
   if (typeof fvLog === "function" && !io) fvLog("galaxy colour: " + (st.src === "lib" ? "from SPCC curves + " + st.libPath : "FALLBACK constants (" + st.why + ")") + " · read " + st.msRead + " ms, compute " + st.msCalc + " ms");
   return st;
}

// ---------------------------------------------------------------------------
// LA BANDERA: pone (o quita) los colores y el presupuesto de luz en FV_GAL3. Gancho de una linea en fvGal3TexReady (se llama antes de
// cualquier mapa o vista); apagada y sin haber estado encendida, no hace nada. Al cambiar, invalida lo que depende de los colores.
// ---------------------------------------------------------------------------
function fvGalColorInvalidate() {
   FV_GAL3_TEX = null; FV_GAL3_BUILD = null; FV_GAL3.volStars = null;
   if (typeof FV_GAL_DATA !== "undefined") { FV_GAL_DATA_ST = null; FV_GAL_DATA.job = null; }
   if (typeof FV_GAL3_MIX !== "undefined" && FV_GAL3_MIX && FV_GAL3_MIX.data) FV_GAL3_MIX = null;
}
function fvGalColorSync() {
   var C = FV_GAL_COLOR;
   if (typeof fvGalDefaultsGuard === "function") fvGalDefaultsGuard();   // (10-nov) por defecto la galaxia nueva esta encendida: sin su extracto, todo apagado (HOY) antes de leer ninguna bandera
   if (!C.ON && !C.applied) return false;
   var G = FV_GAL3;
   if (C.ON) {
      var st = fvGalColorLoad(), B = C.BUDGET, c = st.cols, gm = "";
      // (GF) con la geometria ajustada (FV_GAL_GG.ON + FV_GAL_DATA.ON), el presupuesto de su opcion de brillo de los brazos
      // (encargo GF2) su presupuesto; sin fv_galgeom.js cargado (FV_GAL_GG no existe) no hay modo, como antes
      var gmode = (typeof FV_GAL_GG === "undefined") ? "" : (typeof fvGf2On === "function" && fvGf2On() && C.BUDGET_GG && C.BUDGET_GG.B2 && FV_GAL_GG.OLD_MODE === "B") ? "B2" : FV_GAL_GG.OLD_MODE;
      if (typeof fvGgOn === "function" && fvGgOn() && C.BUDGET_GG && C.BUDGET_GG[gmode]) { gm = gmode; B = JSON.parse(JSON.stringify(C.BUDGET)); var bg = C.BUDGET_GG[gm]; for (var kb in bg) if (bg.hasOwnProperty(kb)) B[kb] = bg[kb]; }
      if (!C.base) C.base = { COL_OLD: G.COL_OLD, COL_YOUNG: G.COL_YOUNG, COL_HII: G.COL_HII, COL_CL: G.COL_CL, COL_BULGE: G.COL_BULGE, DUST_RGB: G.DUST_RGB, A_OLD: G.A_OLD, A_YOUNG: G.A_YOUNG, A_HII: G.A_HII, A_CL: G.A_CL, DUST_K: G.DUST_K };
      var useD = (typeof FV_GAL_DATA !== "undefined" && FV_GAL_DATA.ON) ? 1 : 0;       // con la galaxia de datos (NUEVA) manda su propio A_YOUNG_D: sus puntos medidos llevan su luz
      var key = JSON.stringify(gm ? [c, B, useD, gm] : [c, B, useD]);
      if (C.applied === key) return false;
      G.COL_OLD = c.old.slice(); G.COL_BULGE = c.old.slice(); G.COL_YOUNG = c.young.slice(); G.COL_CL = c.cl.slice(); G.COL_HII = c.hii.slice(); G.DUST_RGB = c.dust.slice();
      G.A_OLD = B.A_OLD; G.A_YOUNG = (useD && B.A_YOUNG_D !== undefined) ? B.A_YOUNG_D : B.A_YOUNG; G.DUST_K = B.DUST_K; G.A_HII = C.base.A_HII * B.K_HII; G.A_CL = C.base.A_CL * B.K_CL;
      // los puntos medidos de NUEVA (fv_galdata.js) SON las HII y las nubes: pintan con el color de su componente (los maseres, marcas doradas del
      // tema Atlas, no son un espectro y se quedan como estan). Solo se tocan los valores de FV_GAL_DATA, no su codigo.
      if (typeof FV_GAL_DATA !== "undefined") {
         if (!C.basePT) C.basePT = { H: FV_GAL_DATA.PT_H.col, C: FV_GAL_DATA.PT_C.col, Ha: FV_GAL_DATA.PT_H.a, Ca: FV_GAL_DATA.PT_C.a, Ma: FV_GAL_DATA.PT_M.a };
         FV_GAL_DATA.PT_H.col = c.hii.slice(); FV_GAL_DATA.PT_C.col = c.cl.slice();
         FV_GAL_DATA.PT_H.a = C.basePT.Ha * (B.K_HP === undefined ? B.K_HII : B.K_HP); FV_GAL_DATA.PT_C.a = C.basePT.Ca * B.K_CL;      // las HII y las nubes medidas valen lo que sus nudos sembrados
         FV_GAL_DATA.PT_M.a = C.basePT.Ma * (B.K_PM === undefined ? 1 : B.K_PM);                                                  // las marcas doradas de los maseres: son anotacion, no luz; K_PM las deja visibles sin teñir el color integrado
      }
      C.applied = key; fvGalColorInvalidate(); return true;
   }
   // apagada tras haber estado encendida: los de hoy, tal cual
   var b = C.base; if (b) { for (var k in b) if (b.hasOwnProperty(k)) G[k] = b[k]; }
   if (C.basePT && typeof FV_GAL_DATA !== "undefined") { FV_GAL_DATA.PT_H.col = C.basePT.H; FV_GAL_DATA.PT_C.col = C.basePT.C; FV_GAL_DATA.PT_H.a = C.basePT.Ha; FV_GAL_DATA.PT_C.a = C.basePT.Ca; FV_GAL_DATA.PT_M.a = C.basePT.Ma; }
   C.applied = false; fvGalColorInvalidate(); return true;
}
