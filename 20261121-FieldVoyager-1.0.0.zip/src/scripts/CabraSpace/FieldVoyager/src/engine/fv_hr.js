// ============================================================================
// FieldVoyager/src/engine/fv_hr.js — (I2, 19-nov-2026) EL DIAGRAMA HR ANIMADO: el motor PURO
// ----------------------------------------------------------------------------
// Nino: «Un botón diagrama HR que, al pulsarlo, las estrellas se muevan a un diagrama HR que aparezca en la pantalla, de forma dinámica.»
// Aqui va todo lo que no pinta: que estrella entra en el diagrama y donde cae (color, magnitud absoluta), los ejes, los rotulos de region,
// el escalonado de la animacion y la trayectoria. Lo usan PixInsight (src/ui/fv_hr_ui.js), el visor del navegador (web/fw_hr.js, copiado al
// paquete en engine/) y node (tests/_hr/). ES5, sin PixInsight ni DOM.
//
// PROCEDENCIA (el calculo es el de CabraStars; aqui se COPIA porque el visor web no lleva CabraShared):
//   · fvHrAbsMag          = cpSfAbsMag            (CabraShared/csh_starfield.js:128, 19-nov-2026): M = m − 5·log10(d / 10 pc), sin extincion.
//   · fvHrPointOf         = la rama "gaia" de cpSfHrPoints (CabraShared/csh_starfield.js:2520): entra la estrella con distancia de fiar
//                           (`s.dist.pc > 0`) y con BP−RP y G de Gaia; color = BP−RP, magnitud = M_G. La distancia es la de CabraShared
//                           (paralaje / cota > 5 con la base local; Bailer-Jones 2021 si su intervalo es < 20 %; cumulo): la escena la trae
//                           en meta.distPc y marca con q = 2 las que NO la tienen (distancia supuesta): esas no entran.
//   · el polvo            = el de la propia escena (meta.dust: Edenhofer 2024 + Babusiaux 2018, src/engine/fv_dust.js fvDustStar, hermano de
//                           csDeredden de CabraStars/lib/cs_extra.js): color0 = BP−RP − E(BP−RP), M0 = M_G − A_G. FV_HR.DEREDDEN false = sin quitar.
//   · los rotulos de region = las cajas y umbrales de csHrRegionLabels (CabraStars/lib/cs_hr_labels.js, 28-oct-2026, decision de Nino):
//                           secuencia principal (≥ 12 en 0,3…3,6 × 3…13), gigantes rojas (≥ 6 en 0,9…2,4 × −6…1,6), enanas blancas
//                           (≥ 3 en −0,7…1,3 × 9,5…17, el rotulo junto a su mediana).
//   · el Sol              = BP−RP 0,82, M_G 4,67 (Casagrande & VandenBerg 2018, MNRAS 479, L102).
//   · la temperatura del eje de arriba = la tabla FV_BPRP_TEFF de src/engine/fv_scene.js (secuencia de Mamajek 2022.04) al reves: vale para
//                           ENANAS; es una guia, no una medida (lo dice el tooltip).
// Bandera de fabrica: FV_HR.ON = true (false: sin boton ni diagrama; nada cambia).
// ============================================================================

var FV_HR = {
   ON: true,
   DUR: 2.6, DUR_BACK: 2.0,      // segundos de ida y de vuelta (toda la animacion, con el escalonado dentro)
   STAGGER: 0.5,                 // fraccion del tiempo que se reparte en salidas escalonadas (cada estrella viaja el resto: 1,3 s de 2,6)
   JITTER: 0.3,                  // del escalonado, cuanto es azar por estrella (el resto: las brillantes salen primero)
   ARC: 0.10,                    // comba de la trayectoria (fraccion del trayecto, perpendicular): todas del mismo lado = un giro suave
   DIM: 0.16,                    // lo que queda de brillo en las que NO van al diagrama
   VEIL: 0.72,                   // el velo negro sobre la foto con el diagrama entero (0 = nada); 0,72: la nebulosa queda como un fantasma detras (19-nov)
   // (11b, 20-nov) Nino: «el velo tapa casi toda la nebulosa». Con VEIL_FIX el velo es VEIL_LIGHT (la foto se ve al 60 % en vez de al 28 %); false = VEIL (0,72, lo de antes).
   // Lo lee fvHrVeilK (PixInsight y web). Medido en tests/_hr/fv_hr_veil_probe.js (luminancia de la nebulosa detras del velo)
   VEIL_FIX: true, VEIL_LIGHT: 0.40,
   DEREDDEN: true,               // quitar el polvo de delante (meta.dust) cuando la escena lo trae
   C0: -0.5, C1: 3.5, M0: -4, M1: 14,          // la ventana minima de los ejes (BP−RP, M_G); crece si las estrellas se salen
   C_HARD: [-1.0, 5.5], M_HARD: [-11, 18],     // mas alla, la medida no es creible: fuera del diagrama
   LEV_CAP: 11, LEV_FLOOR: 3,    // PixInsight: en el diagrama ningun sprite pasa de este nivel (las brillantes no tapan) ni baja de este
   LEV_REST: 5,                  // PixInsight: las que se quedan en la foto encogen a este nivel (una brillante sin distancia no parece un punto del diagrama)
   // EL APELOTONAMIENTO: la secuencia principal de un campo rico apila miles de estrellas en un palmo y se quemaba a blanco (Pleyades, 5 609
   // puntos: fv_HR_probe 19-nov). Cada punto baja su brillo segun cuantos vecinos tiene en su celda de los ejes (rejilla GRID, media 3 × 3):
   // alfa = min(1, (CROWD / vecinos)^CROWD_POW), con suelo CROWD_MIN. Las sueltas (gigantes, enanas blancas) quedan enteras. CROWD 0 = sin esto
   GRID: [56, 72], CROWD: 5, CROWD_POW: 0.6, CROWD_MIN: 0.08,
   PICK_PX: 12,                  // alcance del cursor sobre un punto
   SUN: [0.82, 4.67]
};
var FV_HR_BREAK = "";            // controles en ROJO de tests/_hr: "nodist" (entra sin distancia) · "flipx" · "flipy" · "absmag" (sin el modulo de distancia) · "dered" (signo del polvo) · "stagger"

// LOS TEXTOS (EN y ES en paralelo), los mismos en PixInsight (pasan a FV_TX en src/ui/fv_hr_ui.js) y en el navegador (web/fw_hr.js). El rotulo del
// boton es corto; lo largo va a los tooltips (criterio de interfaz §11.7)
var FV_HR_TX = {
      en: { "btn.hr": "HR diagram", "lab.hr": "HR",
            "tip.hr": "HR diagram: the stars of the view fly to their place in the Hertzsprung–Russell diagram (colour and temperature across, true brightness up). Only stars with a trustworthy distance go; the rest stay behind, dimmed. Point at a star for its name, click for its card. Press again (or Esc) and they fly back.",
            "hr.title": "HERTZSPRUNG–RUSSELL", "hr.count": "{n} of {N} stars · measured distance", "hr.x": "COLOUR  BP − RP", "hr.y": "ABSOLUTE MAGNITUDE  M", "hr.t": "TEMPERATURE (K)",
            "hr.hot": "HOT", "hr.cool": "COOL", "hr.bright": "BRIGHT", "hr.faint": "FAINT", "hr.sun": "Sun",
            "hr.main-sequence": "main sequence", "hr.red-giants": "red giants", "hr.white-dwarfs": "white dwarfs",
            "hr.none": "NO STAR OF THIS VIEW HAS A MEASURED DISTANCE",
            "hr.tipTitle": "Each point is a star of your photo: its Gaia DR3 colour (BP − RP) and its absolute magnitude in the G band, M = G − 5·log10(distance / 10 pc). A star enters only with a trustworthy distance (parallax at least 5 times its error, Bailer-Jones 2021, or its cluster); stars placed at an assumed distance stay in the photo, dimmed.",
            "hr.tipDust": " The dust in front of each star has been removed (3D map of Edenhofer et al. 2024, coefficients of Babusiaux et al. 2018); beyond 1 250 pc the map ends and the correction is a minimum.",
            "hr.tipT": "Temperature of a main-sequence star of that colour (Mamajek 2022 sequence). A guide: for giants and white dwarfs it is only approximate.",
            "hr.tipSun": "Where the Sun would fall: BP − RP 0.82, M 4.67 (Casagrande & VandenBerg 2018)." },
      es: { "btn.hr": "Diagrama HR", "lab.hr": "HR",
            "tip.hr": "Diagrama HR: las estrellas de la vista vuelan a su sitio en el diagrama de Hertzsprung–Russell (color y temperatura en horizontal, brillo verdadero en vertical). Solo van las que tienen una distancia de fiar; las demás se quedan, atenuadas. Señala una estrella para ver su nombre, haz clic para su ficha. Otra pulsación (o Esc) y vuelven.",
            "hr.title": "HERTZSPRUNG–RUSSELL", "hr.count": "{n} de {N} estrellas · distancia medida", "hr.x": "COLOR  BP − RP", "hr.y": "MAGNITUD ABSOLUTA  M", "hr.t": "TEMPERATURA (K)",
            "hr.hot": "CALIENTE", "hr.cool": "FRÍA", "hr.bright": "BRILLANTE", "hr.faint": "DÉBIL", "hr.sun": "Sol",
            "hr.main-sequence": "secuencia principal", "hr.red-giants": "gigantes rojas", "hr.white-dwarfs": "enanas blancas",
            "hr.none": "NINGUNA ESTRELLA DE ESTA VISTA TIENE DISTANCIA MEDIDA",
            "hr.tipTitle": "Cada punto es una estrella de tu foto: su color de Gaia DR3 (BP − RP) y su magnitud absoluta en la banda G, M = G − 5·log10(distancia / 10 pc). Una estrella solo entra con una distancia de fiar (paralaje de al menos 5 veces su error, Bailer-Jones 2021, o la de su cúmulo); las que están a una distancia supuesta se quedan en la foto, atenuadas.",
            "hr.tipDust": " Se ha quitado el polvo de delante de cada estrella (mapa 3D de Edenhofer et al. 2024, coeficientes de Babusiaux et al. 2018); más allá de 1 250 pc el mapa se acaba y la corrección es un mínimo.",
            "hr.tipT": "Temperatura de una estrella de la secuencia principal de ese color (secuencia de Mamajek 2022). Es una guía: para gigantes y enanas blancas solo es aproximada.",
            "hr.tipSun": "Donde caería el Sol: BP − RP 0,82, M 4,67 (Casagrande y VandenBerg 2018)." }
   };

// Magnitud absoluta desde la aparente y la distancia. SIN extincion. (copia de cpSfAbsMag, CabraShared/csh_starfield.js)
function fvHrAbsMag(mag, pc) {
   if (!isFinite(mag) || !(pc > 0)) return null;
   if (FV_HR_BREAK === "absmag") return mag;
   return mag - 5 * (Math.log(pc / 10) / Math.LN10);
}

// EL PUNTO HR DE UNA ESTRELLA de la escena. g = su G; meta = scene.stars.meta[i] (bpRp, distPc, dust); q = scene.stars.q[i] (2 = distancia supuesta).
// -> { ok, why ("" | "no-distance" | "no-colour" | "out-of-range"), color, absMag (los que se pintan), raw: { color, absMag } (sin quitar polvo:
//      los de CabraStars), dered (se quito polvo) }
function fvHrPointOf(g, meta, q) {
   var o = { ok: false, why: "", color: null, absMag: null, raw: { color: null, absMag: null }, dered: false }, m = meta || {};
   var pc = (m.distPc > 0) ? m.distPc : 0;
   if (FV_HR_BREAK === "nodist" && !(pc > 0)) pc = 100;
   if ((q === 2 && FV_HR_BREAK !== "nodist") || !(pc > 0)) { o.why = "no-distance"; return o; }
   if (m.bpRp === null || m.bpRp === undefined || !isFinite(m.bpRp) || g === null || g === undefined || !isFinite(g)) { o.why = "no-colour"; return o; }
   var M = fvHrAbsMag(g, pc);
   if (M === null) { o.why = "no-distance"; return o; }
   o.raw.color = m.bpRp; o.raw.absMag = M; o.color = m.bpRp; o.absMag = M;
   if (FV_HR.DEREDDEN && m.dust && isFinite(m.dust.ag) && isFinite(m.dust.ebr) && (m.dust.ag > 0 || m.dust.ebr > 0)) {
      var sg = (FV_HR_BREAK === "dered") ? -1 : 1;
      o.color = m.bpRp - sg * m.dust.ebr; o.absMag = M - sg * m.dust.ag; o.dered = true;
   }
   if (o.color < FV_HR.C_HARD[0] || o.color > FV_HR.C_HARD[1] || o.absMag < FV_HR.M_HARD[0] || o.absMag > FV_HR.M_HARD[1]) { o.why = "out-of-range"; return o; }
   o.ok = true;
   return o;
}

// la opacidad del velo con el diagrama entero (0 … 1): la nueva (VEIL_LIGHT) o la de antes (VEIL)
function fvHrVeilK() { return (FV_HR.VEIL_FIX === true) ? FV_HR.VEIL_LIGHT : FV_HR.VEIL; }

// azar fijo por estrella (0 … 1): el mismo en PixInsight, en el navegador y en node
function fvHrHash(i) { var x = Math.sin((i + 1) * 12.9898) * 43758.5453; return x - Math.floor(x); }

// EL MODELO del diagrama de una escena. S = scene.stars ({ n, g, q, meta }).
// -> { n, ok (Uint8Array), color, absMag, rawColor, rawAbsMag (Float32Array; NaN si no entra), delay (0 … 1: orden de salida), alpha (0 … 1: brillo en el diagrama, por apelotonamiento), u, v (0 … 1 dentro
//      de los ejes: u = 0 caliente, v = 0 brillante), range: { c0, c1, m0, m1 }, nOk, nDered, skipped: { noDistance, noColour, outOfRange },
//      regions: [ { key, n, show, at: [ color, absMag ] } ], dereddened }
function fvHrBuild(S) {
   var n = S ? S.n : 0, M = { n: n, ok: new Uint8Array(n), color: new Float32Array(n), absMag: new Float32Array(n), rawColor: new Float32Array(n), rawAbsMag: new Float32Array(n),
                              delay: new Float32Array(n), alpha: new Float32Array(n), u: new Float32Array(n), v: new Float32Array(n), range: null, nOk: 0, nDered: 0,
                              skipped: { noDistance: 0, noColour: 0, outOfRange: 0 }, regions: [], dereddened: false }, i;
   var cMin = 1e9, cMax = -1e9, mMin = 1e9, mMax = -1e9, idx = [];
   for (i = 0; i < n; ++i) {
      var p = fvHrPointOf(S.g[i], S.meta ? S.meta[i] : null, S.q ? S.q[i] : 0);
      M.color[i] = NaN; M.absMag[i] = NaN; M.rawColor[i] = NaN; M.rawAbsMag[i] = NaN;
      if (p.raw.color !== null) { M.rawColor[i] = p.raw.color; M.rawAbsMag[i] = p.raw.absMag; }
      if (!p.ok) { if (p.why === "no-distance") ++M.skipped.noDistance; else if (p.why === "no-colour") ++M.skipped.noColour; else ++M.skipped.outOfRange; continue; }
      M.ok[i] = 1; M.color[i] = p.color; M.absMag[i] = p.absMag; ++M.nOk; if (p.dered) ++M.nDered;
      if (p.color < cMin) cMin = p.color; if (p.color > cMax) cMax = p.color; if (p.absMag < mMin) mMin = p.absMag; if (p.absMag > mMax) mMax = p.absMag;
      idx.push(i);
   }
   M.dereddened = M.nDered > 0;
   // los ejes: la ventana minima, ensanchada a medios enteros (color) y a pares (magnitud) si alguna estrella se sale
   var R = { c0: FV_HR.C0, c1: FV_HR.C1, m0: FV_HR.M0, m1: FV_HR.M1 };
   if (M.nOk > 0) {
      if (cMin - 0.15 < R.c0) R.c0 = Math.floor((cMin - 0.15) * 2) / 2; if (cMax + 0.15 > R.c1) R.c1 = Math.ceil((cMax + 0.15) * 2) / 2;
      if (mMin - 0.5 < R.m0) R.m0 = 2 * Math.floor((mMin - 0.5) / 2); if (mMax + 0.5 > R.m1) R.m1 = 2 * Math.ceil((mMax + 0.5) / 2);
   }
   M.range = R;
   // el orden de salida: las brillantes (magnitud absoluta menor) primero, con un poco de azar para que no salgan en fila
   idx.sort(function(a, b) { return M.absMag[a] - M.absMag[b]; });
   var J = FV_HR.JITTER;
   for (var r = 0; r < idx.length; ++r) {
      var k = idx[r];
      M.delay[k] = (FV_HR_BREAK === "stagger") ? 0 : (1 - J) * (idx.length > 1 ? r / (idx.length - 1) : 0) + J * fvHrHash(k);
      var uv = fvHrNorm(R, M.color[k], M.absMag[k]); M.u[k] = uv[0]; M.v[k] = uv[1];
   }
   // el apelotonamiento: vecinos por celda (media de 3 × 3 celdas) -> alfa de cada punto
   var GX = FV_HR.GRID[0], GY = FV_HR.GRID[1], cnt = new Float32Array(GX * GY), cell = new Int32Array(n);
   for (r = 0; r < idx.length; ++r) { k = idx[r]; var gx = Math.min(GX - 1, Math.max(0, Math.floor(M.u[k] * GX))), gy = Math.min(GY - 1, Math.max(0, Math.floor(M.v[k] * GY))); cell[k] = gy * GX + gx; ++cnt[cell[k]]; }
   for (r = 0; r < idx.length; ++r) {
      k = idx[r]; M.alpha[k] = 1;
      if (!(FV_HR.CROWD > 0)) continue;
      var cx0 = cell[k] % GX, cy0 = (cell[k] - cx0) / GX, sum = 0, nc = 0;
      for (var dy = -1; dy <= 1; ++dy) for (var dx = -1; dx <= 1; ++dx) { var xx = cx0 + dx, yy = cy0 + dy; if (xx < 0 || yy < 0 || xx >= GX || yy >= GY) continue; sum += cnt[yy * GX + xx]; ++nc; }
      var dens = sum / nc;
      if (dens > FV_HR.CROWD) M.alpha[k] = Math.max(FV_HR.CROWD_MIN, Math.pow(FV_HR.CROWD / dens, FV_HR.CROWD_POW));
   }
   M.regions = fvHrRegions(M);
   return M;
}

// (color, magnitud absoluta) -> (u, v) en 0 … 1 dentro de los ejes: u crece hacia las FRIAS (rojas), v crece hacia las DEBILES (abajo)
function fvHrNorm(R, color, absMag) {
   var u = (color - R.c0) / (R.c1 - R.c0), v = (absMag - R.m0) / (R.m1 - R.m0);
   if (FV_HR_BREAK === "flipx") u = 1 - u;
   if (FV_HR_BREAK === "flipy") v = 1 - v;
   return [u, v];
}

// LAS REGIONES con rotulo (cajas y umbrales de csHrRegionLabels, CabraStars). `at` = donde se propone el rotulo, en (color, magnitud)
function fvHrRegions(M) {
   function count(c0, c1, m0, m1) { var k = 0; for (var j = 0; j < M.n; ++j) if (M.ok[j] && M.color[j] >= c0 && M.color[j] <= c1 && M.absMag[j] >= m0 && M.absMag[j] <= m1) ++k; return k; }
   var out = [], nMs = count(0.3, 3.6, 3, 13), nRg = count(0.9, 2.4, -6, 1.6);
   out.push({ key: "main-sequence", n: nMs, show: nMs >= 12, at: [[2.05, 6.3], [2.5, 7.5], [1.5, 4.6], [3.0, 9.0], [2.3, 5.2], [2.7, 6.4], [0.2, 7.2], [0.6, 9.5]] });
   out.push({ key: "red-giants", n: nRg, show: nRg >= 6, at: [[1.75, -0.6], [2.0, 0.6], [1.5, -2.6], [0.25, -2.2], [2.4, 1.6]] });
   var wc = [], wm = [];
   for (var i = 0; i < M.n; ++i) if (M.ok[i] && M.color[i] >= -0.7 && M.color[i] <= 1.3 && M.absMag[i] >= 9.5 && M.absMag[i] <= 17) { wc.push(M.color[i]); wm.push(M.absMag[i]); }
   if (wc.length >= 3) {
      var c = fvHrMedian(wc), m = fvHrMedian(wm);
      out.push({ key: "white-dwarfs", n: wc.length, show: true, at: [[c + 0.35, m], [c + 0.35, m + 1.3], [c - 0.2, m + 1.9], [c - 0.2, m - 2.0], [c - 1.3, m], [c + 0.35, m - 1.3]] });
   } else out.push({ key: "white-dwarfs", n: wc.length, show: false, at: [] });
   return out;
}
function fvHrMedian(a) { var s = a.slice().sort(function(x, y) { return x - y; }), h = s.length >> 1; return s.length ? ((s.length & 1) ? s[h] : 0.5 * (s[h - 1] + s[h])) : NaN; }

// EL RECUADRO del trazado en la pantalla (W × H px): mas alto que ancho, como el HR de los libros, centrado un poco a la izquierda para
// dejar sitio a la ficha. -> { x, y, w, h }
function fvHrRect(W, H) {
   var h = 0.70 * H, w = Math.min(0.40 * W, 0.92 * h), cx = 0.40 * W;      // (la ficha empieza en 0,61 del ancho: fv_HR_probe)
   return { x: Math.round(cx - w / 2), y: Math.round(0.13 * H), w: Math.round(w), h: Math.round(h) };
}
// el punto de pantalla de la estrella i con el diagrama entero
function fvHrTarget(M, i, rect) { return [rect.x + M.u[i] * rect.w, rect.y + M.v[i] * rect.h]; }

// EL AVANCE DE UNA ESTRELLA: K = avance de toda la animacion (0 … 1, lineal en el tiempo); delay = su orden de salida (0 … 1).
// Cada una espera delay·STAGGER y viaja en (1 − STAGGER) con arranque y frenada suaves. -> 0 … 1
function fvHrProgress(K, delay) {
   var S = FV_HR.STAGGER, t = (K - delay * S) / (1 - S);
   if (t <= 0) return 0;
   if (t >= 1) return 1;
   return t * t * t * (t * (t * 6 - 15) + 10);
}
// LA TRAYECTORIA: de (sx, sy) a (tx, ty) con una comba perpendicular que se anula en los dos extremos. Deja el punto en out[0], out[1]
function fvHrPath(sx, sy, tx, ty, t, out) {
   var dx = tx - sx, dy = ty - sy, b = FV_HR.ARC * Math.sin(Math.PI * t);
   out[0] = sx + dx * t - dy * b; out[1] = sy + dy * t + dx * b;
   return out;
}

// EL ESTADO de la animacion: { k (0 … 1), dir (+1 hacia el diagrama, −1 de vuelta, 0 parado) }
function fvHrStateNew() { return { k: 0, dir: 1, t: 0 }; }
function fvHrStateStep(st, dt) {
   if (!st || !st.dir) return st;
   st.t += dt;
   st.k += st.dir * dt / (st.dir > 0 ? FV_HR.DUR : FV_HR.DUR_BACK);
   if (st.k >= 1) { st.k = 1; st.dir = 0; }
   if (st.k <= 0) { st.k = 0; st.dir = 0; st.done = true; }
   return st;
}
// cuanto se ve el diagrama (ejes, velo): entra en el primer 35 % y sale en el ultimo
function fvHrAxesAlpha(K) { var t = K / 0.35; if (t <= 0) return 0; if (t >= 1) return 1; return t * t * (3 - 2 * t); }

// el BP−RP de una enana de temperatura T: la tabla FV_BPRP_TEFF de src/engine/fv_scene.js al reves (lo mismo que fvBpRpOfTeff de fv_dust.js, que el
// visor web no carga); fuera de la tabla, null (no se inventa una marca)
function fvHrBpRpOfTeff(T) {
   var Tb = (typeof FV_BPRP_TEFF !== "undefined") ? FV_BPRP_TEFF : null;
   if (!Tb || !(T > 0) || T > Tb[0][1] || T < Tb[Tb.length - 1][1]) return null;
   for (var i = 1; i < Tb.length; ++i) if (T >= Tb[i][1]) { var u = (T - Tb[i - 1][1]) / (Tb[i][1] - Tb[i - 1][1]); return Tb[i - 1][0] + u * (Tb[i][0] - Tb[i - 1][0]); }
   return null;
}
// LAS MARCAS de los ejes: color (BP−RP) cada 0,5; magnitud absoluta cada 2; y temperaturas redondas colocadas con la tabla de enanas
// (fvHrBpRpOfTeff; bpRpOfTeff = otra funcion, para pruebas). -> { c: [..], m: [..], teff: [ { teff, c } ] }
function fvHrTicks(R, bpRpOfTeff) {
   var o = { c: [], m: [], teff: [] }, x;
   for (x = Math.ceil(R.c0 / 0.5 - 1e-9) * 0.5; x <= R.c1 + 1e-9; x += 0.5) o.c.push(Math.round(x * 2) / 2);
   for (x = 2 * Math.ceil(R.m0 / 2 - 1e-9); x <= R.m1 + 1e-9; x += 2) o.m.push(x);
   var fn = bpRpOfTeff || fvHrBpRpOfTeff, T = [10000, 7500, 6000, 5000, 4000, 3500, 3000];
   if (fn) for (var i = 0; i < T.length; ++i) { var c = fn(T[i]); if (c !== null && isFinite(c) && c > R.c0 + 0.05 && c < R.c1 - 0.05) o.teff.push({ teff: T[i], c: c }); }
   return o;
}

// COLOCAR LOS ROTULOS de region: para cada region a la vista, la primera propuesta cuya caja (medida por measure(key) -> { w, h } px) cabe en
// el recuadro y pisa MENOS puntos (0 si puede). -> [ { key, x, y, w, h, hits } ] (x, y = esquina de arriba a la izquierda)
function fvHrPlaceLabels(M, rect, measure, margin) {
   var out = [], mg = (margin > 0) ? margin : 3, i, c, j;
   for (i = 0; i < M.regions.length; ++i) {
      var rg = M.regions[i]; if (!rg.show) continue;
      var sz = measure(rg.key); if (!sz || !(sz.w > 0)) continue;
      var best = null;
      for (c = 0; c < rg.at.length; ++c) {
         var uv = fvHrNorm(M.range, rg.at[c][0], rg.at[c][1]), bx = Math.round(rect.x + uv[0] * rect.w), by = Math.round(rect.y + uv[1] * rect.h - sz.h / 2);
         if (bx < rect.x + mg || by < rect.y + mg || bx + sz.w > rect.x + rect.w - mg || by + sz.h > rect.y + rect.h - mg) continue;
         var clash = false;
         for (j = 0; j < out.length; ++j) if (bx < out[j].x + out[j].w + mg && bx + sz.w + mg > out[j].x && by < out[j].y + out[j].h + mg && by + sz.h + mg > out[j].y) { clash = true; break; }
         if (clash) continue;
         var hits = 0;
         for (j = 0; j < M.n; ++j) { if (!M.ok[j]) continue; var px = rect.x + M.u[j] * rect.w, py = rect.y + M.v[j] * rect.h; if (px >= bx - mg && px <= bx + sz.w + mg && py >= by - mg && py <= by + sz.h + mg) ++hits; }
         if (!best || hits < best.hits) best = { key: rg.key, x: bx, y: by, w: sz.w, h: sz.h, hits: hits };
         if (hits === 0) break;
      }
      if (best) out.push(best);
   }
   return out;
}

// ELEGIR UN PUNTO con el cursor: vis = [ i, x, y, i, x, y … ] (las estrellas pintadas en este fotograma y donde). -> indice de estrella | −1
function fvHrPickIn(vis, n, x, y, radius) {
   var best = -1, bd = radius * radius;
   for (var k = 0; k < n; k += 3) { var dx = vis[k + 1] - x, dy = vis[k + 2] - y, d = dx * dx + dy * dy; if (d <= bd) { bd = d; best = vis[k]; } }
   return best;
}

