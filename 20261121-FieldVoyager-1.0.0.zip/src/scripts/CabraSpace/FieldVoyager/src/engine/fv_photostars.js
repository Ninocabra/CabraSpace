// ============================================================================
// FieldVoyager/src/engine/fv_photostars.js — EL ASPECTO DE LAS ESTRELLAS: Gaia · colores de la foto · como en la foto (pura) (5-nov-2026)
// ----------------------------------------------------------------------------
// Nino (5-nov): «¿Puedes poner que las estrellas se vean como Gaia o como están en la imagen, como en los otros scripts?»
// (B1, 5-nov) CON FV_PS.GAIA_TEMP (por defecto) los tres significan otra cosa; lo de abajo describe el STELLAE de antes (GAIA_TEMP false):
//   «gaia»    el color de la TEMPERATURA de Gaia (fvStarColour(Teff, BP−RP)) de TODAS las estrellas y, junto a la estrella, el de la temperatura sin
//             polvo (scene.stars.colG / colGT, fv_build.js). «phcol» (COLOR) el color de la foto con el verde recortado (scene.stars.col / colTrue: el
//             «gaia» de antes; no hay que medir nada). «phstar» (FOTO) los recortes; el sprite al que se funden va en el color de COLOR.
// Tres aspectos (FV_PS_LOOKS), los mismos que CabraStars:
//   «gaia»    lo de siempre: el sprite de fv_look.js con el color de la escena (el de la foto medido en el nucleo con SCNR, o el de cuerpo
//             negro de su Teff si la foto no lo da). Con este valor el pintor no cambia NI UN PIXEL (prueba G1 de tests/fv_ps_test.js).
//   «phcol»   COLORES DE LA FOTO: el mismo sprite con el color que la estrella tiene en la foto, medido en su nucleo (2 FWHM) con el cielo
//             de alrededor restado, sin los pixeles quemados (csPsMeasureOne de CabraStars). Sin medida, el color de «gaia».
//   «phstar»  COMO EN LA FOTO: cada estrella con su RECORTE de la foto (cielo restado, borde suave, luz = la de la foto). Sin recorte, el
//             sprite de «gaia» (con el color de la foto si lo hay).
// ESCALA EN EL VUELO (fvPsWeights): el recorte se dibuja en casa a la escala de la foto en pantalla (desde la Tierra la vista es la foto) y
// en el vuelo crece y se apaga con la MISMA ley que el sprite de Gaia (fv_look.js, en continuo): el tamaño solo crece al saturar
// (sigma ∝ 2^(0,3·(satMag − m'))) y la luz baja con la intensidad de la ley (nunca sube por encima de la de casa: alfa ≤ 1). Cuando el
// recorte se veria AMPLIADO (pixeles de pantalla por pixel de foto > FV_PS.MAG_LO) se funde al sprite de Gaia (del todo en MAG_HI): un
// recorte ampliado con interpolacion bilineal se ve blando y facetado. Umbral medido en tests/fv_ps_node.js (P9). En el warp
// (trail > TRAIL_LO) tambien se funde al sprite (las estelas salen de el). fvPsFacet es la medida del umbral (la usa la prueba).
// PROCEDENCIA (copiado y adaptado; CabraStars y Cabra3D no se tocan):
//   CabraStars/lib/cs_photostars.js:46-165  csPsMeasureOne, csPsFwhmPlanes, csPsMeasureAll, csPsStarsOnly (y sus CS_PS / CS_PS_BREAK).
//     Cambio: el recorte sale PREMULTIPLICADO sobre negro (RGB32: canal − cielo, por el borde suave) en vez de ARGB normalizado: el pintor
//     de PixInsight lo suma (Add) como los sprites de fv_look y el visor WebGL lo suma igual (mezcla aditiva); asi la luz es la de la foto.
//   Cabra3D/src/ui/starfield_photostars.js:218  _psSprites (la idea del recorte: anillo de cielo restado y borde smoothstep 0,75R…R+0,5)
// Lo de PixInsight (los Bitmap, el motor de segmentacion, la barra) esta en src/build/fv_ps_build.js. ES5. Sin PixInsight.
// ============================================================================

var FV_PS = { ON: true,                      // false = sin selector: siempre «gaia» (el comportamiento de antes del 5-nov; ROJO de la cabina)
              // (B1, Nino 5-nov: «tres opciones distintas de verdad») true: GAIA = el color de la TEMPERATURA de Gaia para todas (y el sin polvo junto
              // a la estrella), COLOR = el de la foto con el verde recortado (el «GAIA» de antes, ya medido en la escena: sin segunda medida),
              // FOTO = los recortes. false = el STELLAE del mediodia (GAIA = el de la foto, COLOR = la medida phcol sin recortar el verde): ROJO
              GAIA_TEMP: true,
              MAX_STARS: 6000, MAX_BYTES: 48 * 1024 * 1024, R_MIN: 2, R_MAX: 40, RING: 3, SNR_MIN: 3, FWHM_DEF: 2.5, CLIP: 0.98,
              // el fundido al sprite de Gaia: aumento del recorte (pixeles de pantalla por pixel de foto) y fase del warp (trail)
              // MAG_LO/MAG_HI medidos (tests/fv_ps_node.js P9): el error de curvatura de la bilineal frente al perfil continuo (FWHM 2–3,5 px)
              // es 0,26–0,43 con ×2 y 1,1–1,3 con ×3 (las facetas mandan); con ×1, 0 por construccion
              MAG_LO: 2.0, MAG_HI: 3.0, TRAIL_LO: 0.04, TRAIL_HI: 0.2,
              SCALE_MIN: 0.25 };             // el recorte no mengua por debajo de este factor respecto a casa (las saturadas al alejarse)
var FV_PS_LOOKS = ["gaia", "phcol", "phstar"];
var FV_PS_BREAK = "";            // pruebas: "chan" (ROJO de la medida del color: R y B leidos cambiados) · "tight" (ROJO: el recorte corta la estrella)
                                 //          · "edge" (recorte sin borde suave) · "noclip" (ROJO: el color cuenta los pixeles quemados)
                                 //          · "nofade" (ROJO: el recorte no se funde al sprite al ampliarse)
                                 //          · "nopart" (ROJO: los recortes que se solapan cuentan dos veces la misma luz)

function fvPsIsLook(v) { return FV_PS_LOOKS.indexOf(String(v)) >= 0; }
function fvPsMedian(a, n) {
   var s = Array.prototype.slice.call(a, 0, n).sort(function(p, q) { return p - q; });
   return s.length ? s[s.length >> 1] : 0;
}

// ---------------------------------------------------------------------------
// LA MEDIDA (copia de csPsMeasureOne). P = { w, h, r, g, b } (Float32Array 0…1). (x, y) el centro en pixeles de P (el pixel i cubre
// [i, i+1)). -> null (en el borde) o { rgb (0xRRGGBB, canal mayor 255; -1 sin señal), snr, R, spr (si wantSprite y hay señal:
// { w, h, cx, cy, R, core, px: Uint32Array RGB32 PREMULTIPLICADO sobre negro, peak (luz maxima 0…1) }) }
// ---------------------------------------------------------------------------
function fvPsMeasureOne(P, x, y, fwhm, wantSprite) {
   var W = P.w, H = P.h, fw = (fwhm > 0) ? fwhm : FV_PS.FWHM_DEF, M = FV_PS.RING;
   var R0 = Math.max(FV_PS.R_MIN, Math.ceil(1.5 * fw)), Rmax = Math.min(FV_PS.R_MAX, Math.max(R0 + 2, Math.ceil(10 * fw)));
   var ix = Math.floor(x), iy = Math.floor(y), E = Math.max(Rmax, R0, Math.ceil(Math.max(1.5, 2 * fw))) + M;
   if (ix - E < 0 || iy - E < 0 || ix + E >= W || iy + E >= H) return null;
   var Rc = (FV_PS_BREAK === "chan") ? P.b : P.r, Gc = P.g, Bc = (FV_PS_BREAK === "chan") ? P.r : P.b;
   var nb = E + 1, sum = new Float64Array(nb), cnt = new Float64Array(nb), dx, dy, k, i;
   // el perfil radial de la luz (media de los tres canales)
   for (dy = -E; dy <= E; ++dy)
      for (dx = -E; dx <= E; ++dx) {
         var px = ix + dx, py = iy + dy, d = Math.sqrt((px + 0.5 - x) * (px + 0.5 - x) + (py + 0.5 - y) * (py + 0.5 - y));
         k = Math.floor(d); if (k >= nb) continue;
         i = py * W + px; sum[k] += (Rc[i] + Gc[i] + Bc[i]) / 3; cnt[k] += 1;
      }
   // el cielo de partida: la mediana de lo que esta entre Rmax y Rmax + M; su ruido, la desviacion robusta
   var ring = [];
   for (dy = -E; dy <= E; ++dy)
      for (dx = -E; dx <= E; ++dx) {
         var qx = ix + dx, qy = iy + dy, dq = Math.sqrt((qx + 0.5 - x) * (qx + 0.5 - x) + (qy + 0.5 - y) * (qy + 0.5 - y));
         if (dq > Rmax && dq <= E) { var j = qy * W + qx; ring.push((Rc[j] + Gc[j] + Bc[j]) / 3); }
      }
   var sky = fvPsMedian(ring, ring.length), dev = [];
   for (i = 0; i < ring.length; ++i) dev.push(Math.abs(ring[i] - sky));
   var sig = 1.4826 * fvPsMedian(dev, dev.length); if (!(sig > 1e-5)) sig = 1e-5;
   // el radio: donde el perfil baja de 1,5 ruidos sobre el cielo (y un par de pixeles mas: que las alas no queden cortadas)
   var R = Rmax;
   for (k = R0; k < Rmax; ++k) if (cnt[k] > 0 && sum[k] / cnt[k] - sky < 1.5 * sig) { R = Math.min(Rmax, k + 2); break; }
   R = Math.max(R0, R);
   if (FV_PS_BREAK === "tight") R = Math.max(1, Math.ceil(0.6 * fw));          // (ROJO del recorte que corta la estrella)
   // el cielo de CADA canal: la mediana del anillo justo por fuera del radio (R, R + M]
   var rr = [], gg = [], bb = [];
   for (dy = -E; dy <= E; ++dy)
      for (dx = -E; dx <= E; ++dx) {
         var ax = ix + dx, ay = iy + dy, da = Math.sqrt((ax + 0.5 - x) * (ax + 0.5 - x) + (ay + 0.5 - y) * (ay + 0.5 - y));
         if (da > R && da <= R + M) { var a = ay * W + ax; rr.push(Rc[a]); gg.push(Gc[a]); bb.push(Bc[a]); }
      }
   var br = fvPsMedian(rr, rr.length), bgc = fvPsMedian(gg, gg.length), bbl = fvPsMedian(bb, bb.length);
   // el color: lo que pasa del cielo dentro de 2 FWHM, SIN los pixeles quemados (algun canal >= CLIP); si todos lo estan, blanca
   var core = Math.max(1, fw), ap = Math.max(1.5, 2 * fw), sr = 0, sg = 0, sb = 0, peak = 0, nUse = 0, nClip = 0, noClip = (FV_PS_BREAK === "noclip");
   for (dy = -Math.ceil(ap); dy <= Math.ceil(ap); ++dy)
      for (dx = -Math.ceil(ap); dx <= Math.ceil(ap); ++dx) {
         var cxp = ix + dx, cyp = iy + dy, dc = Math.sqrt((cxp + 0.5 - x) * (cxp + 0.5 - x) + (cyp + 0.5 - y) * (cyp + 0.5 - y));
         if (dc > ap) continue;
         var c = cyp * W + cxp, vr = Math.max(0, Rc[c] - br), vg = Math.max(0, Gc[c] - bgc), vb = Math.max(0, Bc[c] - bbl);
         var lu = (vr + vg + vb) / 3; if (dc <= core && lu > peak) peak = lu;
         if (!noClip && (Rc[c] >= FV_PS.CLIP || Gc[c] >= FV_PS.CLIP || Bc[c] >= FV_PS.CLIP)) { ++nClip; continue; }
         sr += vr; sg += vg; sb += vb; ++nUse;
      }
   if (nUse === 0 && nClip > 0) { sr = sg = sb = 1; }
   var snr = peak / sig, mx = Math.max(sr, sg, sb), rgb = -1;
   if (snr >= FV_PS.SNR_MIN && mx > 0) rgb = (Math.round(255 * sr / mx) << 16) | (Math.round(255 * sg / mx) << 8) | Math.round(255 * sb / mx);
   var out = { rgb: rgb, snr: snr, R: R, spr: null };
   if (!wantSprite || rgb < 0) return out;
   // el recorte PREMULTIPLICADO: (canal − cielo) × borde suave, sobre negro. Sumado (Add) sobre la foto sin estrellas devuelve la foto, y
   // fuera de la estrella es 0: sin cuadros sobre ningun fondo
   var S = 2 * R + 1, x0 = ix - R, y0 = iy - R, buf = new Uint32Array(S * S), hard = (FV_PS_BREAK === "edge"), pk = 0;
   for (dy = 0; dy < S; ++dy)
      for (dx = 0; dx < S; ++dx) {
         var sx = x0 + dx, sy = y0 + dy, ds = Math.sqrt((sx + 0.5 - x) * (sx + 0.5 - x) + (sy + 0.5 - y) * (sy + 0.5 - y));
         var t = (ds - 0.75 * R) / (0.25 * R + 0.5), fe = hard ? ((ds <= R + 0.5) ? 1 : 0) : ((ds <= 0.75 * R) ? 1 : (ds >= R + 0.5) ? 0 : 1 - t * t * (3 - 2 * t));
         var s = sy * W + sx, ur = Math.min(255, Math.round(255 * Math.max(0, Rc[s] - br) * fe)), ug = Math.min(255, Math.round(255 * Math.max(0, Gc[s] - bgc) * fe)), ub = Math.min(255, Math.round(255 * Math.max(0, Bc[s] - bbl) * fe));
         buf[dy * S + dx] = (0xff000000 | (ur << 16) | (ug << 8) | ub) >>> 0;
         var m = Math.max(ur, ug, ub); if (m > pk) pk = m;
      }
   out.spr = { w: S, h: S, x0: x0, y0: y0, cx: x - x0, cy: y - y0, R: R, core: Math.max(0.5, fw / 2), px: buf, peak: pk / 255, fw: fw };
   return out;
}

// La FWHM en P (copia de csPsFwhmPlanes): la mediana del area a media altura de hasta 60 brillantes no saturadas
function fvPsFwhmPlanes(P, list) {
   var vals = [], R = 8, W = P.w, H = P.h;
   for (var q = 0; q < list.length && vals.length < 60; ++q) {
      var x0 = Math.floor(list[q].x), y0 = Math.floor(list[q].y);
      if (x0 < R || y0 < R || x0 >= W - R || y0 >= H - R) continue;
      var a = [], mx = -Infinity, dx, dy;
      for (dy = -R; dy <= R; ++dy) for (dx = -R; dx <= R; ++dx) { var i = (y0 + dy) * W + x0 + dx, v = (P.r[i] + P.g[i] + P.b[i]) / 3; a.push(v); if (v > mx) mx = v; }
      if (mx >= 0.95) continue;
      var md = fvPsMedian(a, a.length), dv = []; for (var k = 0; k < a.length; ++k) dv.push(Math.abs(a[k] - md));
      if (!(mx - md > 10 * 1.4826 * fvPsMedian(dv, dv.length))) continue;
      var half = md + (mx - md) / 2, area = 0; for (k = 0; k < a.length; ++k) if (a[k] > half) ++area;
      if (area >= 2 && area < 150) vals.push(2 * Math.sqrt(area / Math.PI));
   }
   if (vals.length < 5) return 0;
   vals.sort(function(p, q2) { return p - q2; });
   return vals[vals.length >> 1];
}
// Todas (copia de csPsMeasureAll): list = [{ i, x, y }] en pixeles de P, de la mas brillante a la mas debil. Recortes hasta maxBytes.
// -> { rgb: { i: 0xRRGGBB }, spr: { i: spr }, n, nCol, nSpr, nEdge, bytes, fwhm }
function fvPsMeasureAll(P, list, fwhm, maxBytes, onProgress) {
   var out = { rgb: {}, spr: {}, n: 0, nCol: 0, nSpr: 0, nEdge: 0, bytes: 0, fwhm: fwhm }, cap = (maxBytes > 0) ? maxBytes : FV_PS.MAX_BYTES;
   for (var q = 0; q < list.length && q < FV_PS.MAX_STARS; ++q) {
      if (onProgress && (q % 250) === 0 && onProgress(q / Math.max(1, list.length)) === false) break;
      var s = list[q], m = fvPsMeasureOne(P, s.x, s.y, fwhm, out.bytes < cap);
      ++out.n;
      if (m === null) { ++out.nEdge; continue; }
      if (m.rgb >= 0) { out.rgb[s.i] = m.rgb; ++out.nCol; }
      if (m.spr) { out.spr[s.i] = m.spr; ++out.nSpr; out.bytes += m.spr.px.length * 4; }
   }
   return out;
}
// Solo las estrellas (copia de csPsStarsOnly): foto − foto sin estrellas, canal a canal, sin bajar de 0
function fvPsStarsOnly(O, L) {
   var N = O.w * O.h, out = { w: O.w, h: O.h, r: new Float32Array(N), g: new Float32Array(N), b: new Float32Array(N) }, ch = ["r", "g", "b"];
   for (var c = 0; c < 3; ++c) { var o = O[ch[c]], l = L[ch[c]], d = out[ch[c]]; for (var i = 0; i < N; ++i) { var v = o[i] - l[i]; d[i] = (v > 0) ? v : 0; } }
   return out;
}
// Pixeles RGB32 (los de un Bitmap: 0xAARRGGBB, como los copia fv_build.js) -> planos 0…1
function fvPsPlanesOfPx(px, w, h) {
   var N = w * h, out = { w: w, h: h, r: new Float32Array(N), g: new Float32Array(N), b: new Float32Array(N) };
   for (var i = 0; i < N; ++i) { var p = px[i]; out.r[i] = ((p >>> 16) & 255) / 255; out.g[i] = ((p >>> 8) & 255) / 255; out.b[i] = (p & 255) / 255; }
   return out;
}
// El pixel de la foto de trabajo de la estrella i (la direccion desde la Tierra: el inverso de fvPixelRay; k = px de trabajo por px de foto).
// Siempre la de HOY (scene.stars): la foto es de hoy. -> [x, y] o null (detras de la Tierra)
function fvPsStarPx(scene, i, k) {
   var S = scene.stars, f = scene.field, z = S.z[i];
   if (!(z > 0)) return null;
   return [(f.width / 2 + f.F * S.x[i] / z) * k, (f.height / 2 + f.F * S.y[i] / z) * k];
}

// ---------------------------------------------------------------------------
// TODO DE UNA VEZ: photoPx / slPx = pixeles de la foto de trabajo y de la foto sin estrellas (mismo tamaño w × h), k = px de trabajo por
// px de foto. Solo las estrellas del encuadre (inFrame). -> { ok, n, rgb: Int32Array(S.n) (-1 sin medida), spr: [] (por indice; undefined
// sin recorte), nCol, nSpr, nEdge, bytes, fwhm, ms }
// ---------------------------------------------------------------------------
function fvPsBuild(photoPx, slPx, w, h, scene, k, opts) {
   var o = opts || {}, t0 = Date.now(), S = scene.stars, out = { ok: false, n: 0, rgb: new Int32Array(S.n), spr: [], nCol: 0, nSpr: 0, nEdge: 0, bytes: 0, fwhm: 0, ms: 0, k: k, w: w, h: h };
   for (var i = 0; i < S.n; ++i) out.rgb[i] = -1;
   var O = fvPsPlanesOfPx(photoPx, w, h), P = slPx ? fvPsStarsOnly(O, fvPsPlanesOfPx(slPx, w, h)) : O, list = [];
   for (i = 0; i < S.n; ++i) {
      if (!S.inFrame[i]) continue;
      var p = fvPsStarPx(scene, i, k);
      if (p && p[0] >= 0 && p[1] >= 0 && p[0] < w && p[1] < h) list.push({ i: i, x: p[0], y: p[1], g: S.g[i] });
   }
   list.sort(function(a, b) { return a.g - b.g; });
   var fw = (o.fwhm > 0.6) ? o.fwhm : (fvPsFwhmPlanes(P, list) || fvPsFwhmPlanes(O, list) || FV_PS.FWHM_DEF);
   var m = fvPsMeasureAll(P, list, fw, o.maxBytes || FV_PS.MAX_BYTES, o.onProgress);
   for (var key in m.rgb) if (m.rgb.hasOwnProperty(key)) out.rgb[+key] = m.rgb[key];
   for (key in m.spr) if (m.spr.hasOwnProperty(key)) out.spr[+key] = m.spr[key];
   out.part = fvPsPartition(out.spr, w, h);
   out.n = m.n; out.nCol = m.nCol; out.nSpr = m.nSpr; out.nEdge = m.nEdge; out.bytes = m.bytes; out.fwhm = fw; out.ok = true; out.ms = Date.now() - t0;
   return out;
}

// ---------------------------------------------------------------------------
// EL REPARTO DE LA LUZ entre recortes que se solapan (5-nov, visto en la estrella central de IC 1848: sus vecinas tenian recortes de hasta 81 px
// que recogian su halo, y sumados en Add la luz salia contada varias veces: una mancha blanca en PixInsight y verde-amarilla en el navegador).
// Cada pixel de foto que cae en varios recortes se reparte: el recorte i se queda con fe_i·a_i / Σ_j fe_j·a_j de lo suyo, con fe el borde suave
// y a_i = pico_i · exp(−d_i² / (2 s²)) (s = 1,5 × la sigma de la FWHM: el pixel va sobre todo a la estrella mas cercana y mas brillante). Un
// pixel con un solo recorte no cambia (el borde suave sigue igual). Asi, desde casa, la suma de los recortes no pasa de las estrellas de la foto.
// sprites: [] (por indice) con { w, h, x0, y0, cx, cy, R, px, peak, fw }; w, h = la foto de trabajo. -> { nOver (pixeles con mas de un recorte) }
function fvPsPartition(sprites, w, h) {
   if (FV_PS_BREAK === "nopart") return { nOver: -1 };
   var N = w * h, M = new Float32Array(N), Sm = new Float32Array(N), Cn = new Uint8Array(N), list = [], i, x, y;
   for (i = 0; i < sprites.length; ++i) if (sprites[i]) list.push(sprites[i]);
   for (i = 0; i < N; ++i) M[i] = -1e30;
   // el borde suave y el peso (en logaritmo) del recorte sp en su pixel (dx, dy) -> [fe, la]
   function fw2(sp, dx, dy) {
      var R = sp.R, ds = Math.sqrt((dx + 0.5 - sp.cx) * (dx + 0.5 - sp.cx) + (dy + 0.5 - sp.cy) * (dy + 0.5 - sp.cy)), t = (ds - 0.75 * R) / (0.25 * R + 0.5);
      var fe = (ds <= 0.75 * R) ? 1 : (ds >= R + 0.5) ? 0 : 1 - t * t * (3 - 2 * t), sg = 1.5 * (sp.fw > 0 ? sp.fw : FV_PS.FWHM_DEF) / 2.3548;
      return [fe, Math.log(Math.max(1e-4, sp.peak)) - ds * ds / (2 * sg * sg)];
   }
   var q, sp, X, Y, r;
   for (q = 0; q < list.length; ++q) { sp = list[q]; for (y = 0; y < sp.h; ++y) { Y = sp.y0 + y; if (Y < 0 || Y >= h) continue; for (x = 0; x < sp.w; ++x) { X = sp.x0 + x; if (X < 0 || X >= w) continue; r = fw2(sp, x, y); if (r[0] <= 0) continue; var k = Y * w + X; if (r[1] > M[k]) M[k] = r[1]; if (Cn[k] < 255) ++Cn[k]; } } }
   for (q = 0; q < list.length; ++q) { sp = list[q]; for (y = 0; y < sp.h; ++y) { Y = sp.y0 + y; if (Y < 0 || Y >= h) continue; for (x = 0; x < sp.w; ++x) { X = sp.x0 + x; if (X < 0 || X >= w) continue; var k2 = Y * w + X; if (Cn[k2] < 2) continue; r = fw2(sp, x, y); if (r[0] <= 0) continue; Sm[k2] += r[0] * Math.exp(r[1] - M[k2]); } } }
   var nOver = 0; for (i = 0; i < N; ++i) if (Cn[i] > 1) ++nOver;
   for (q = 0; q < list.length; ++q) {
      sp = list[q]; var pk = 0;
      for (y = 0; y < sp.h; ++y) { Y = sp.y0 + y; for (x = 0; x < sp.w; ++x) { X = sp.x0 + x; var j = y * sp.w + x, v = sp.px[j];
         if (Y >= 0 && Y < h && X >= 0 && X < w && Cn[Y * w + X] > 1) {
            r = fw2(sp, x, y); var sh = (r[0] > 0 && Sm[Y * w + X] > 0) ? r[0] * Math.exp(r[1] - M[Y * w + X]) / Sm[Y * w + X] : 0;
            v = (0xff000000 | (Math.round(((v >>> 16) & 255) * sh) << 16) | (Math.round(((v >>> 8) & 255) * sh) << 8) | Math.round((v & 255) * sh)) >>> 0; sp.px[j] = v;
         }
         var m3 = Math.max((v >>> 16) & 255, (v >>> 8) & 255, v & 255); if (m3 > pk) pk = m3; } }
      sp.peakOwn = pk / 255;
   }
   return { nOver: nOver };
}

// ---------------------------------------------------------------------------
// LA LEY DEL VUELO (la comparten el pintor de PixInsight y, en GLSL, el visor web: FW_SH_STAR_V)
// ---------------------------------------------------------------------------
// el tamaño y la intensidad de la ley de fv_look.js, en CONTINUO (sin los niveles cuantizados): sigma ∝ 2^min(e, SAT·SAT_STEP), e = 0,3·(satMag − m)
function fvPsSig(m, lim) { var e = 0.3 * (lim.satMag - m); return Math.pow(2, Math.min(FV_LOOK.SAT * FV_LOOK.SAT_STEP, Math.max(0, e))); }
function fvPsInt(m, lim) { if (m < lim.satMag) return 1; var fr = (lim.magLim - m) / (lim.magLim - lim.satMag); return FV_LOOK.FLOOR + (1 - FV_LOOK.FLOOR) * Math.max(0, Math.min(1, fr)); }
// m = magnitud aparente desde la camara (con las reglas del cono ya sumadas), mH = la de casa (G), lim / limH = limites de ahora y de casa,
// homeScale = pixeles de pantalla por pixel de la foto de trabajo en CASA, trail = fase del warp.
// -> { scale (px de pantalla por px de recorte), alpha (≤ 1: la luz frente a la de casa), wG (0 = todo recorte … 1 = todo sprite de Gaia), mag }
function fvPsWeights(m, mH, lim, limH, homeScale, trail) {
   var g = fvPsSig(m, lim) / fvPsSig(mH, limH), sc = homeScale * Math.max(FV_PS.SCALE_MIN, g);
   var a = Math.min(1, fvPsInt(m, lim) / Math.max(1e-6, fvPsInt(mH, limH)));
   var wM = (FV_PS_BREAK === "nofade") ? 0 : fvPsSmooth((sc - FV_PS.MAG_LO) / (FV_PS.MAG_HI - FV_PS.MAG_LO));
   var wT = fvPsSmooth(((trail || 0) - FV_PS.TRAIL_LO) / (FV_PS.TRAIL_HI - FV_PS.TRAIL_LO));
   return { scale: sc, alpha: a, wG: Math.max(wM, wT), mag: sc };
}
// LA MEDIDA DEL UMBRAL: un perfil gaussiano de FWHM fw muestreado en pixeles de foto y ampliado k veces con interpolacion bilineal (la de
// Bitmap.scaledTo y la de la GPU) frente al perfil continuo a la misma escala: error relativo de la segunda diferencia (la curvatura). Con
// k ≤ 1 la bilineal no deja facetas que se vean; al crecer k cada tramo recto ocupa varios pixeles de pantalla y la curvatura del
// interpolante se concentra en los nudos. -> { facet, fwhmScr (px de pantalla por encima de la mitad) }
function fvPsFacet(fw, k) {
   var s = fw / 2.3548, N = 41, c = 20.3, samp = [], up = [], tr = [], i, j;
   for (i = 0; i < N; i++) { var x = i + 0.5; samp.push(Math.exp(-(x - c) * (x - c) / (2 * s * s))); }
   var M = Math.round(N * k);
   for (j = 0; j < M; j++) {
      var u = (j + 0.5) / k, t = u - 0.5, i0 = Math.floor(t), f = t - i0, a = samp[Math.max(0, Math.min(N - 1, i0))], b = samp[Math.max(0, Math.min(N - 1, i0 + 1))];
      up.push(a + (b - a) * f); tr.push(Math.exp(-(u - c) * (u - c) / (2 * s * s)));
   }
   var e2 = 0, t2 = 0, half = 0;
   for (j = 1; j < M - 1; j++) { var du = up[j - 1] - 2 * up[j] + up[j + 1], dt = tr[j - 1] - 2 * tr[j] + tr[j + 1]; e2 += (du - dt) * (du - dt); t2 += dt * dt; }
   for (j = 0; j < M; j++) if (up[j] > 0.5) ++half;
   return { facet: Math.sqrt(e2 / Math.max(1e-30, t2)), fwhmScr: half };
}
function fvPsSmooth(x) { x = x < 0 ? 0 : (x > 1 ? 1 : x); return x * x * (3 - 2 * x); }
// pixeles de pantalla por pixel de la foto de trabajo, en casa: el campo de casa (horizontal) cubre W px; la foto tiene F px por radian
// (fvSceneNew) y la de trabajo k px por px de foto
function fvPsHomeScale(scene, W, homeFov, k) { return (W / (2 * Math.tan(homeFov / 2))) / (scene.field.F * k); }
