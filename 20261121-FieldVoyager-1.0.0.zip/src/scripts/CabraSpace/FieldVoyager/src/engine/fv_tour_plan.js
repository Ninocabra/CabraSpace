// Procedencia: escrito por Codex (encargo K6, 4-nov-2026), revisado y ejecutado por Claude: 37/0 en node. Aún sin conectar al TOUR.
"use strict";

function fvTourPlan(objects, start, opts) {
    // No modifica objetos ni posiciones del llamador.
    var nodes = [], real = [], assumed = [], stops = [];
    var i, j, o, pool, count, budget, limit, last, previous;
    var total = 0, champion = -1, used = [], costs = [], modes = [];
    opts = opts || {};
    function finite(x) { return typeof x === "number" && isFinite(x); }
    function position(p) {
        return Array.isArray(p) && p.length === 3 &&
            finite(p[0]) && finite(p[1]) && finite(p[2]);
    }
    function norm(v) {
        var m = Math.max(Math.abs(v[0]), Math.abs(v[1]), Math.abs(v[2]));
        if (!m) return 0;
        return m * Math.sqrt(Math.pow(v[0] / m, 2) +
            Math.pow(v[1] / m, 2) + Math.pow(v[2] / m, 2));
    }
    function delta(a, b) { return [b[0]-a[0], b[1]-a[1], b[2]-a[2]]; }
    function distance(a, b) { return norm(delta(a, b)); }
    function hold(type) {
        if (type === "star" || type === "exoplanet") return 6;
        if (type === "nebula" || type === "galaxy") return 10;
        return 8;
    }
    function empty(reason) { return { stops: [], totalS: 0, reason: reason }; }
    function setting(value, fallback) {
        return value === undefined ? fallback : value;
    }
    limit = setting(opts.maxStops, 6);
    budget = setting(opts.maxTotalS, 240);
    if (!position(start)) return empty("invalid-start");
    if (!finite(limit) || limit < 0 || !finite(budget) || budget < 0)
        return empty("invalid-options");
    if (!Array.isArray(objects)) return empty("invalid-objects");
    if (typeof opts.legS !== "function") return empty("missing-legS");
    limit = Math.floor(limit);
    if (!limit) return empty("stop-limit");
    for (i = 0; i < objects.length; i++) {
        o = objects[i];
        if (!o || !position(o.pos)) continue;
        // Una procedencia desconocida no se convierte en medida.
        if (o.distSrc !== "measured" && o.distSrc !== "catalog" &&
            o.distSrc !== "assumed") continue;
        j = {
            i: i, pos: o.pos.slice(0), type: o.type,
            score: finite(o.score) ? o.score : -Infinity,
            distLy: o.distLy, distSrc: o.distSrc,
            hold: hold(o.type)
        };
        if (o.distSrc === "assumed") assumed.push(j);
        else real.push(j);
    }
    pool = real.length ? real : assumed;
    count = pool.length;
    if (!count) return empty("no-valid-objects");
    limit = Math.min(limit, count);
    nodes = pool.slice(0);
    nodes.push({ pos: start.slice(0) });
    // Matriz dirigida: el callback puede ser asimétrico. Se llama una vez por arista.
    for (i = 0; i <= count; i++) {
        costs[i] = [];
        modes[i] = [];
        for (j = 0; j < count; j++) {
            var d = distance(nodes[i].pos, nodes[j].pos);
            var mode = d > 500 ? "warp" : "cine";
            var seconds = Infinity;
            if (finite(d)) {
                try {
                    seconds = opts.legS(nodes[i].pos.slice(0),
                        nodes[j].pos.slice(0), mode);
                } catch (ignored) { seconds = Infinity; }
            }
            modes[i][j] = mode;
            costs[i][j] = finite(seconds) && seconds >= 0 ? seconds : Infinity;
        }
    }
    // Desenlace: máximo score entre los destinos directamente asequibles.
    for (i = 0; i < count; i++) {
        if (costs[count][i] + nodes[i].hold > budget) continue;
        if (champion < 0 || nodes[i].score > nodes[champion].score)
            champion = i;
    }
    if (champion < 0) return empty("no-affordable-stop");
    function finishCost(from) {
        return costs[from][champion] + nodes[champion].hold;
    }
    function turn(a, b, c) {
        if (a < 0) return 0;
        var u = delta(nodes[a].pos, nodes[b].pos);
        var v = delta(nodes[b].pos, nodes[c].pos);
        var nu = norm(u), nv = norm(v);
        if (!finite(nu) || !finite(nv)) return 1;
        if (!nu || !nv) return 0;
        var dot = (u[0]/nu)*(v[0]/nv) + (u[1]/nu)*(v[1]/nv) +
            (u[2]/nu)*(v[2]/nv);
        return dot < -0.5 ? 1 : 0;
    }
    function why(node, first, final) {
        var en, es;
        if (first && final) {
            en = "Straight to the highlight.";
            es = "Directos al plato fuerte.";
        } else if (first) {
            en = "First, a nearby stop.";
            es = "Primero, una parada cercana.";
        } else if (final) {
            en = "The highest-score finale.";
            es = "El broche de mayor score.";
        } else {
            en = "The story grows.";
            es = "La historia crece.";
        }
        if (node.distSrc === "measured") {
            en += " Measured distance.";
            es += " Distancia medida.";
        } else if (node.distSrc === "assumed") {
            en += " Assumed distance: no measured or catalog positions available.";
            es += " Distancia supuesta: no hay posiciones medidas ni de catálogo disponibles.";
        } else {
            en += " Catalog distance.";
            es += " Distancia de catálogo.";
        }
        if (finite(node.distLy) && node.distLy >= 0) {
            en += " " + String(node.distLy) + " ly from Earth.";
            es += " " + String(node.distLy) + " a.l. de la Tierra.";
        }
        return { en: en, es: es };
    }
    function append(index) {
        var node = nodes[index];
        total += costs[last][index] + node.hold;
        stops.push({
            i: node.i, mode: modes[last][index], holdS: node.hold,
            why: why(node, !stops.length, index === champion)
        });
        used[index] = true;
        previous = last;
        last = index;
    }
    last = count;
    previous = -1;
    // Apertura: medida antes que catálogo; después, cercanía a la cámara.
    var opening = -1, openingRank = null;
    function better(a, b) {
        var k;
        if (!b) return true;
        for (k = 0; k < a.length; k++) {
            if (a[k] < b[k]) return true;
            if (a[k] > b[k]) return false;
        }
        return false;
    }
    if (limit > 1) {
        for (i = 0; i < count; i++) {
            if (i === champion || nodes[i].score > nodes[champion].score) continue;
            if (costs[last][i] + nodes[i].hold + finishCost(i) > budget) continue;
            var rank = [nodes[i].distSrc === "measured" ? 0 : 1,
                distance(start, nodes[i].pos), nodes[i].score, nodes[i].i];
            if (better(rank, openingRank)) { opening = i; openingRank = rank; }
        }
    }
    if (opening >= 0) append(opening);
    // Cada incorporación mantiene score no decreciente y reserva el desenlace.
    while (stops.length && stops.length + 1 < limit) {
        var best = -1, bestRank = null;
        for (i = 0; i < count; i++) {
            if (used[i] || i === champion || nodes[i].score < nodes[last].score ||
                nodes[i].score > nodes[champion].score) continue;
            if (total + (costs[last][i] + nodes[i].hold) + finishCost(i) > budget)
                continue;
            rank = [
                nodes[i].type === nodes[last].type ? 1 : 0,
                nodes[i].type === nodes[champion].type ? 1 : 0,
                turn(previous, last, i) + turn(last, i, champion),
                nodes[i].score, costs[last][i], nodes[i].i
            ];
            if (better(rank, bestRank)) { best = i; bestRank = rank; }
        }
        if (best < 0) break;
        append(best);
    }
    append(champion);
    return {
        stops: stops, totalS: total,
        reason: real.length ? "planned" : "planned-assumed-only"
    };
}

// ============================================================================
// (6-nov-2026) LA ESPERA DEL TOUR EN CADA PARADA: el tiempo de LEER la ficha (PixInsight: src/ui/fv_dialog.js tourStep; navegador:
// web/fw_viewer.js fwTourStep). Nino: «Al hacer el tour, justo al desplegarse la informacion de la estrella esta desaparece y el tour
// continua. Tiene que estar un tiempo y esperar a que se pueda leer la info que esta poniendo.»
// Antes la espera contaba desde la LLEGADA (PixInsight 4 s en warp / 6 s en cine; navegador 7 s), pero la ficha se reabre 2 s despues de
// llegar y tarda en desplegarse y escribirse (0,8 s de placa + el texto a 150 caracteres/s en PixInsight, ~2,2 s en el navegador) y los
// datos de la estrella (metalicidad, espectro XP) llegan despues: quedaban 0–3 s con la ficha completa. Ahora:
//   1. la espera EMPIEZA cuando la ficha esta COMPLETA (desplegada, escrita y con sus datos; o WAIT_MAX_S tras llegar si no llega a estarlo);
//   2. dura lo que se tarda en leer lo que se ve: BASE_S (mirar la portilla, el titulo y el sello) + WORD_S por palabra, entre MIN_S y MAX_S.
//      WORD_S 0,12 s = 500 palabras/min: lectura por encima (skimming) de un texto con formato conocido (la ficha siempre tiene la misma
//      forma y Nino la conoce); la lectura normal de un adulto va de 200 a 300 palabras/min (Brysbaert 2019, 238 en silencio para no ficcion)
//      y el skimming de 400 a 700 (Rayner et al. 2016). Una ficha corriente de estrella (60–80 palabras) da 10–13 s; una muy corta, el minimo
//      de 6 s; la nebulosa con MÁS (> 100 palabras), el tope de 15 s (el tour no se eterniza: lo demas se lee con calma parando el tour);
//   3. si el usuario esta con la ficha (el cursor encima, MÁS, el espectro) la espera se PARA; si abre MÁS, la cuenta pide mas tiempo.
// FV_TOUR_READ.ON false = lo de antes (la espera fija desde la llegada).
// ============================================================================
// (12-nov-2026, R7; Nino: «el tour es raro, se queda mucho tiempo en cada estrella y no se sabe si sigue o se ha colgado») TIEMPOS CON NOMBRE.
// Medido el 12-nov con el dialogo real (tests/_tour/fv_tour_time_test.js, informe docs/encargos-12nov/R7-tour.md): con la espera de 6-nov cada
// parada duraba mucho mas de lo que dura leer la ficha, porque se SUMABAN el tiempo de abrirse y escribirse la ficha (2 s de respiro de
// llegada + 0,8 s de placa + el texto) y DESPUES la lectura entera (BASE_S + WORD_S × palabras, 6-15 s). Ahora (SHORT true):
//   · el reloj de lectura EMPIEZA cuando la ficha empieza a escribirse (se lee mientras se escribe), no cuando termina;
//   · lectura: BASE_S 1,5 s + WORD_S 0,05 s/palabra (1 200 palabras/min: es un vistazo; la ficha completa se lee parando el tour), entre
//     MIN_S 4,5 y MAX_S 8 s; una ficha corriente (60-80 palabras) = 4,5-5,5 s;
//   · no se va antes de AFTER_S (2 s) con la ficha ya COMPLETA a la vista (escrita y con sus datos); si los datos no llegan, a los HARD_S (12 s)
//     de tiempo activo se va igual;
//   · si el usuario esta con la ficha (cursor encima, MÁS abierto) NO se va (y ese tiempo cuenta como lectura); al soltarla (cursor fuera, MÁS cerrado)
//     quedan GRACE_S (3 s) de cortesia antes de seguir. Con PAUSA del usuario el reloj SE PARA y sigue donde estaba.
// SHORT false = lo de antes (FV_TOUR_READ_OLD: 3 s + 0,12 s/palabra, 6-15 s, desde la ficha completa; el ROJO de las pruebas).
var FV_TOUR_READ_OLD = { BASE_S: 3.0, WORD_S: 0.12, MIN_S: 6.0, MAX_S: 15.0, WAIT_MAX_S: 14.0 };
// (16-nov-2026, encargo F, informe docs/encargos-16nov/P17-P18.md) tres banderas del Tour (PixInsight: fv_dialog.js tourStep / closeCard; navegador: fw_viewer.js fwCardClose):
//   SKY_CLICK (P18, true) un clic en CIELO VACIO (P.sel = null) cuenta como ficha cerrada por el usuario: la parada sigue su ritmo y no espera a HARD_S (lo de la web, H1 de R3).
//     false = lo de antes (la parada se quedaba esperando una ficha que ya no se pinta). Solo PixInsight: la web lo tiene siempre.
//   CLOSE_NOW (P17, false: DECISION DE NINO) cerrar la ficha (× o Esc o INFO) durante la espera pasa de inmediato a la siguiente parada, sin esperar lectura ni cortesia.
//     false = hoy (la parada espera lo que le quede de lectura y GRACE_S). En pausa del usuario no salta.
//   CLOSE_CLEARS_HOVER (P17, true) al cerrar la ficha el cursor deja de estar «sobre la ficha» (su hover queda en «card-close» hasta que el raton se mueva y la espera se aguanta
//     indefinidamente: lo que la web arreglo en H3). false = lo de antes. Solo PixInsight.
var FV_TOUR_READ = { ON: true, SHORT: true, BASE_S: 1.5, WORD_S: 0.05, MIN_S: 4.5, MAX_S: 8.0, WAIT_MAX_S: 10.0, AFTER_S: 2.0, GRACE_S: 3.0, HARD_S: 12.0, SKY_CLICK: true, CLOSE_NOW: true, CLOSE_CLEARS_HOVER: true };
// la tabla de tiempos en uso (SHORT true: la nueva; false: la de antes)
function fvTourT() { return FV_TOUR_READ.SHORT ? FV_TOUR_READ : FV_TOUR_READ_OLD; }
function fvTourWords(x) {
    if (x === null || x === undefined) return 0;
    if (typeof x === "string") { var m = x.match(/[^\s·|]+/g); return m ? m.length : 0; }
    var n = 0; for (var i = 0; i < x.length; ++i) n += fvTourWords(x[i] && x[i].t !== undefined ? x[i].t : (x[i] && x[i].s !== undefined ? x[i].s : x[i]));
    return n;
}
function fvTourReadS(words) {
    var R = fvTourT(), s = R.BASE_S + R.WORD_S * Math.max(0, words || 0);
    return Math.min(R.MAX_S, Math.max(R.MIN_S, s));
}
// la espera de una parada: D = fvTourDwellNew(); en cada paso fvTourDwellStep(D, dt, st) con
//   st = { complete: ficha completa, started: la ficha ya se esta escribiendo (R7), words, paused: el reloj se para (V1: el cursor), hold: pausa del usuario (V2),
//          busy: el usuario esta con la ficha (V2: cuenta como lectura, no se va, y da GRACE_S al soltarla), more: MÁS abierto }
// -> true cuando ya se puede seguir. Sin st.started (el dialogo de antes, las pruebas de 6-nov) o con SHORT false rige lo de antes: la espera empieza con la ficha COMPLETA.
// D.waitS (llegada -> empieza), D.readS (lo leido), D.needS (lo que pide el texto), D.pausedS, D.afterS (con la ficha completa), D.graceS (cortesia
// que queda), D.left (s que faltan para seguir; null = aun no empieza) y D.frac (0-1, para la barra del tour)
function fvTourDwellNew() { return { waitS: 0, readS: 0, needS: 0, pausedS: 0, ready: false, done: false, words: 0, afterS: 0, graceS: 0, activeS: 0, busyS: 0, left: null, frac: 0 }; }
function fvTourDwellStep(D, dt, st) {
    if (D.done) return true;
    dt = Math.max(0, dt || 0); st = st || {};
    var R = fvTourT(), v2 = !!FV_TOUR_READ.SHORT && st.started !== undefined;
    if (!D.ready) {
        D.waitS += dt;
        var go = v2 ? !!(st.started || st.complete) : !!st.complete;
        if (go || D.waitS >= R.WAIT_MAX_S) { D.ready = true; D.readyWhy = go ? "card" : "timeout"; }
        else return false;
    }
    if (v2) { if (!st.more && st.words) D.words = st.words; } else D.words = Math.max(D.words, st.words || 0);
    D.needS = fvTourReadS(D.words);
    // V2: con el usuario en la ficha (st.busy: cursor encima, MÁS abierto) el tiempo CUENTA como lectura (esta mirandola) pero no se va (graceS se
    // rellena); al soltarla quedan GRACE_S. La pausa del usuario (st.hold) SI para el reloj. V1: st.paused (el cursor) para el reloj
    var freeze = v2 ? !!st.hold : !!st.paused, busy2 = v2 && !!st.busy;
    if (busy2) { D.busyS += dt; D.graceS = FV_TOUR_READ.GRACE_S; }
    if (freeze) D.pausedS += dt;
    else {
        D.readS += dt;
        if (!busy2) D.activeS += dt;
        if (v2) { if (!busy2) D.graceS = Math.max(0, D.graceS - dt); if (st.complete) D.afterS += dt; }
    }
    if (v2) {
        var leftRead = Math.max(0, D.needS - D.readS), leftAfter = st.complete ? Math.max(0, FV_TOUR_READ.AFTER_S - D.afterS) : FV_TOUR_READ.AFTER_S;
        D.left = Math.max(leftRead, leftAfter, D.graceS);
        var span = (D.graceS > 0 && D.graceS >= leftRead && D.graceS >= leftAfter) ? FV_TOUR_READ.GRACE_S : Math.max(D.needS, FV_TOUR_READ.AFTER_S);
        D.frac = Math.min(1, Math.max(0, 1 - D.left / span));
        // se va cuando ha dado el tiempo de lectura y la cortesia, con la ficha completa a la vista AFTER_S; sin ficha completa (los datos no llegan) o sin ficha
        // (nunca llego a escribirse: «timeout»), no espera a AFTER_S: se va tras la lectura o, a mas tardar, a los HARD_S de tiempo activo
        D.done = D.readS >= D.needS && D.graceS <= 0 && (D.afterS >= FV_TOUR_READ.AFTER_S || D.readyWhy === "timeout" || D.activeS >= FV_TOUR_READ.HARD_S);
    } else {
        D.left = Math.max(0, D.needS - D.readS); D.frac = D.needS > 0 ? Math.min(1, D.readS / D.needS) : 1;
        D.done = D.readS >= D.needS;
    }
    return D.done;
}
