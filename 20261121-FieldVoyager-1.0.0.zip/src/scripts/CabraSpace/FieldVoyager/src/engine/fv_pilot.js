// ============================================================================
// FieldVoyager/src/engine/fv_pilot.js — CAMARA, PROYECCION Y VUELOS (pura) (3-nov-2026, F1; F2 4-nov-2026)
// ----------------------------------------------------------------------------
// Un PILOTO lleva la camara por la escena con el reloj de escena (t = n/fps en grabacion; el tiempo real en vivo).
// DOS ESTILOS DE CAMARA (F2, el conmutador MODUS de la cabina), que valen para TODO movimiento (viajar, orbitar, mirar a casa):
//   "cine"        SUAVE / CINEMATOGRAFICO. Ideas (no codigo) de Celestia, Cosmonium, WorldWide Telescope y OpenSpace:
//                 · camino «sube – cruza – baja» de WWT: si se sale de cerca de un objeto hacia otro lejano, primero se aleja hacia
//                   un punto desde el que se ven los dos, cruza y baja (ViewMoverSlew);
//                 · velocidad ∝ distancia al objeto mas cercano de los dos extremos, con DURACION FIJA reescalando (OpenSpace
//                   Path::speedAlongPath): el acercamiento es exponencial a cualquier escala; y arranque y frenada con seno;
//                 · el giro de la mirada solo entre el 25 % y el 75 % del camino (sin²), sin alabeo (Celestia);
//                 · si el camino pasa casi por encima de una estrella, se desvia con un punto de control a 3 «radios» (OpenSpace
//                   AvoidCollisionCurve);
//                 · la mirada persigue su objetivo con un MUELLE CRITICAMENTE AMORTIGUADO (periodo 1,6 s): la inercia de un operador.
//   "spectacular" ESPECTACULAR (§05 E1/E5/E9): el warp con todo — 0,3 s casi parada y subida brutal (el «snap»), campo de vision
//                 de 60° (o el de casa) a 105°, destello < 0,15 s al saltar, estelas, frenazo con rebote; la PRIMERA vez que se
//                 fija un objetivo, un efecto vertigo (dolly zoom) de 1,1 s; y un PASO RASANTE junto a una estrella del camino.
//                 La mirada, con un muelle mas vivo (0,6 s): al pasar junto a la estrella se queda un poco atras.
// Vuelos: travel (warp | cine), home (vuelta a la foto), look (girar la mirada sin moverse: «mirar a casa»).
// orbit: delante del objeto, vueltas alrededor con la INCLINACION del plano cambiando despacio (el cielo «gira»).
// free: arrastrar = mirar; rueda = avanzar/retroceder con paso ∝ distancia al objeto mas cercano.
// Nunca hay alabeo: la base de la camara siempre tiene el «abajo» de la foto como referencia.
// PASADA N (4-nov-2026, Nino: «todo mas cinematografico, sensacion de flotar; avanzar y girar facil»):
//   N5 CINE lento: 12–25 s (3,2 s por decada de escala), velocidad que arranca sin tiron (smootherstep), crucero y frenada
//      exponencial larga (gaussiana) que deja una velocidad residual; giro de la mirada solo en el 18–72 % del TIEMPO; llegada de
//      GRUA (el ultimo tramo rodea el objeto 18°, mirada clavada en el) y DERIVA al llegar (sigue rodeando ≤ 4° y se para sola).
//   N6 WARP de TNG: preparacion (1,3 s: la nave se encara, las estrellas tiemblan y se estiran apenas, el campo «inspira» un 7 %),
//      SALTO (0,55 s: rayas hacia el punto de fuga, destello azul-blanco, campo 60 -> 105°: zoom de tunel), crucero con estelas y
//      SALIDA (1 s: destello, frenazo (1−b)³, las rayas se recogen en puntos). El pintor saca la fase de (warp, trail, flash): lo
//      mismo que graba REC (fv_rec.js), asi el video tiene las cuatro fases sin tocar el grabador.
//   N10 VUELO LIBRE: fvPilotKey / fvPilotMouse (los llama el dialogo) y fvPilotStep lo integra: empuje con inercia y
//      amortiguacion, velocidad ∝ distancia a lo mas cercano, giro con inercia, arrastre que sigue girando al soltar.
// RUTA (4-nov-2026, Nino: «la camara hace cosas muy raras para llegar ... deberia seguir una linea recta o una parabola»;
//   analisis en docs/ruta-del-viaje-analisis.md). Con FV_PILOT.ROUTE.CINE / HOME / WARP (false = la ley de antes, el ROJO):
//   · cine y vuelta a casa PLANIFICADOS en el primer paso (fvRouteSetup + fvRoutePlan, muestreado a 60 Hz): LINEA RECTA de la camara a la
//     llegada (un solo arco parabolico plano solo si una estrella corta de verdad la recta, AVOID_REAL), sin grua, sin esquives por
//     cercania, sin subida WWT; el avance es tau = ∫ ds / escala VISIBLE (destino, plano de salida, losa —que se cruza despacio—, foto
//     al volver, tramo del fundido) con la curva de siempre (fvCineX); la mirada lleva el destino EN PANTALLA de donde esta al tercio
//     de llegada (fvAimAt), con panoramica previa ≤ PAN_DPS (casa ≤ HOME_PAN_DPS) desde un punto fijo; el campo, en ln tan, como
//     rejilla: techo, tope A exacto (fvRouteCover, por biseccion con la mirada), apertura ≤ beta · ln(d_ant / d) (BETA 0,65) y B, cierre
//     planificado hacia atras ≤ FOV_RATE. La vuelta a casa sin latigazo (R6) y con el campo monotono desde su minimo.
//   · warp (fvRouteWarpPlan): mismo camino y fases, pero mirada y campo con la misma rejilla (WARP_BETA, sin borde a la vista, el destino
//     no encoge: R12/R13); desde casa el tunel ya no llega a 105° (lo impide B).
//   · fvPilotFlyPath(P, keys, opts): el vuelo por llaves del editor de camaras (Catmull-Rom centripeta entre paradas, holdS, avisos).
// Contratos: P.flight.phase ∈ "depart" | "cruise" | "arrive"; P.onFlightEnd(P, fl) al llegar (si existe); destino de un objeto de
// C = fvObjectTarget(scene, i) -> { pos, arriveLy, lookAt }; sel.arriveLy (si viene) manda sobre la distancia de llegada.
// ES5. Sin PixInsight.
// ============================================================================

var FV_DEG = Math.PI / 180;
var FV_PILOT = {
   ARRIVE_FOV: 60 * FV_DEG,      // campo de vision de llegada (horizontal)
   MAX_FOV: 105 * FV_DEG,        // a toda velocidad en el warp (§05 E1)
   ARRIVE_MAG: -1.0,             // llegada: a la distancia a la que la estrella brilla como una de magnitud −1
   ARRIVE_MIN: 0.05, ARRIVE_MAX: 60,   // años luz
   ORBIT_DEG_S: { cine: 6, spectacular: 15 },    // (N5) cine 8 -> 6 °/s: mas lento, mas de flotar
   ORBIT_TILT_DEG: 22, ORBIT_TILT_S: 40,         // la inclinacion del plano de la orbita oscila ±22° en 40 s
   LOOK_PERIOD: { cine: 2.2, spectacular: 0.6 }, // periodo del muelle de la mirada (s) — (N5) cine 1,6 -> 2,2: mas inercia
   // (N5) DURACION DEL VIAJE DE CINE: 12 s + 3,2 s por cada decada de (distancia del viaje / distancia de llegada), tope 25 s.
   // Por que: el acercamiento es exponencial (velocidad ∝ escala), asi que lo que «se ve» pasar es una decada de escala tras otra;
   // a 0,9 s por decada (F2: 4–8 s) Nino lo vio rapido. 3,2 s/decada = un objeto dobla su tamaño en pantalla cada ~1 s, lo que tarda en
   // leerse un plano de cine. Un salto corto entre vecinas (×10) dura ~15 s; de la Tierra a una estrella del campo (×10⁴) 25 s.
   // (N, docs/cine-scifi-camara-y-musica.md §11, encargo E) 12/3,2/25 -> 14 s + 4,5 s/decada, tope 40 s (Powers of Ten / Contact): un
   // salto ×10 dura 18,5 s y uno ×10⁴ 32 s. CINE_PRE: 1,2 s de plano casi quieto antes de arrancar (2001, Gravity).
   // (§15, medido: AMNH ~8,4 s/decada de media, Gravity duplica tamaño cada 10–13 s; pre-roll de 2001/Gravity) 4,5 -> 7 s/decada, tope 40 -> 45 s,
   // CINE_PRE 1,2 -> 2,5 s quieto, y RITMO VARIABLE: CINE_VARY = [peso cerca, peso en el vacio] del tiempo por unidad de tau (fvPathMake)
   CINE_S_MIN: 14.0, CINE_S_MAX: 45.0, CINE_S_DEC: 7.0, CINE_PRE: 2.5, CINE_VARY: [1.8, 0.45],
   // ENCUADRE DE LLEGADA (Blade Runner 2049, §10.5): el objeto queda en el TERCIO IZQUIERDO (la ficha sale a la derecha): la mirada se
   // desvia FRAME_THIRD × campo de vision horizontal (0,17 × 60° = 10,2° ≈ 200 px a 1280). 0 = centrado (como F2–F4b). Solo en el cine.
   // (§15) el objeto mas al borde: x ≈ 0,25 del ancho (simetrico de 0,72–0,78 medido: Trek, Interstellar) -> 0,27 × 60° = 16,2°
   FRAME_THIRD: 0.27,
   // DERIVA VIVA en reposo (Gravity, §3/§11): la mirada respira con dos senos incommensurables (±0,12° a 9,3 s y ±0,08° a 14,1 s; en
   // cabeceo, la mitad), que entran en 2,5 s tras quedarse quieta. No en casa (la foto manda) ni en vuelo.
   LIVE_DRIFT: [0.12, 9.3, 0.08, 14.1], LIVE_DRIFT_IN: 2.5,
   // perfil de velocidad (sobre la fraccion de tiempo u): arranque smootherstep hasta CINE_ACC, crucero, frenada gaussiana desde CINE_BRAKE
   // con constante CINE_BRAKE_K, y CINE_VEND de velocidad residual al final (la deriva la continua: sin parada en seco)
   CINE_ACC: 0.20, CINE_BRAKE: 0.58, CINE_BRAKE_K: 3.2, CINE_VEND: 0.04,
   CINE_TURN0: 0.15, CINE_TURN1: 0.80,           // (§15) ventana mas ancha (antes 0,18–0,72) para bajar el pico de giro           // el giro de la mirada, solo en este tramo del TIEMPO (smootherstep)
   CINE_TURN_DPS: 10,                            // pico de giro de la mirada en el cine (°/s): un giro grande alarga el viaje (tope CINE_S_MAX)
   // la GRUA: el ultimo tramo rodea el objeto CRANE_DEG alrededor de un eje casi vertical con algo de horizontal (sube un poco),
   // entrando por un punto a CRANE_APP × la distancia de llegada; solo si el viaje es mas largo que CRANE_MIN × esa distancia
   EVEN_ON: true, EVEN_RATIO: 4, EVEN_MAX: 40,   // (4.ª corrida) escalera de puntos de control en el cine (fvCtrlEven; false = ROJO)
   CRANE_LADDER: 5,              // (4.ª corrida) punto de control extra en la recta de entrada a CRANE_LADDER × CRANE_APP × dA
   CRANE_DEG: 18, CRANE_APP: 2.4, CRANE_MIN: 4, CRANE_TILT: 0.6,
   // la DERIVA de llegada: sigue rodeando con la velocidad angular final, que se apaga con constante COAST_S; tope COAST_MAX_DEG
   COAST_S: 4.0, COAST_MAX_DEG: 6, COAST_EXACT: true,             // (E §10.5) 1,6 s / 4° -> 2,6 s / 6°; (§15) Interstellar frena con constante de 4–5 s -> 4,0 s
   GOTO_S: 8.0,                                  // (F1: duracion de «Ir a»; ya no se usa)
   HOME_S: 2.4,                                  // (N5) se deja en 2,4 s: es el «volver a empezar» (N3) y las pruebas f2/f4 esperan ese tiempo
   LOOKHOME_S: { cine: 4.0, spectacular: 1.1 },  // (N5) cine 2,6 -> 4,0 s
   // (N6) EL WARP DE TNG (segundos): preparacion, salto, crucero (CRUISE_MIN + CRUISE_DEC por decada, tope CRUISE_MAX) y salida.
   // CREEP: velocidad relativa durante la preparacion (casi parada); PREP_TRAIL: estela de la preparacion (estiramiento apenas);
   // INHALE: el campo se cierra un 7 % antes del salto (la nave «coge aire»); FLASH_S: (F4b–N) 0,12 s · (§15, abajo) 0,8 s
   // (E §10.2) PREP 1,3 -> 2,0 s; BREATH nuevo: 0,35 s con todo congelado (sin temblor, campo en su maximo de «inspiracion», sin destello: la
   // radio puede callarse aqui, P.flight.warpPhase === "breath"); JUMP 0,55 -> 0,7 s; CRUISE_MAX 4,5 -> 6 s; EXIT 1,0 -> 1,4 s con rebote
   // del campo FOV_BOUNCE (3 %); INHALE 7 -> 10 %. ABERR: en el salto las estrellas se apelotonan hacia el punto de fuga (aberracion, en el
   // pintor); SHAKE_DEG: vibracion de la camara en crucero (9–14 Hz) y sacudida de salida EXIT_SHAKE_DEG que decae en 0,5 s.
   // (§15, medido fotograma a fotograma en clips oficiales; corrige lo de arriba) el destello NO es un fogonazo: 0,5–1,0 s (TNG 0,98,
   // Voyager 0,54), sube el 40 % y baja el 60 %, pequeño (< 5 % del cuadro) y en el punto de fuga. Orden de Trek: brillo 0,25–0,48 s ->
   // estiramiento 0,34–0,52 s -> PAUSA quieta 0,34–0,45 s -> destello; 1,7–2,3 s del brillo al final del destello. Ni temblor ni sacudida
   // en ningun plano medido: SHAKE_DEG = EXIT_SHAKE_DEG = 0. Fases (warpPhase): prep (encarar 1,2 s + brillo GLOW 0,4 s) · jump
   // (estiramiento: estela a STRETCH_TRAIL, warp a STRETCH_W) · breath (pausa) · flash (destello mientras se entra en warp) · cruise · exit.
   // Del brillo al final del destello: 0,4 + 0,5 + 0,4 + 0,8 = 2,1 s. Para la radio de A: «breath» = la pausa justo antes del destello.
   WARP: { PREP: 1.6, GLOW: 0.4, JUMP: 0.5, BREATH: 0.4, FLASH_S: 0.8, FLASH_UP: 0.4, EXIT: 1.5, EXIT_FLASH_S: 0.6, EXIT_FLASH_K: 0.6,
           CRUISE_MIN: 2.2, CRUISE_DEC: 0.6, CRUISE_MAX: 6.0, CREEP: 0.004, STRETCH_V: 0.03, STRETCH_W: 0.3, STRETCH_TRAIL: 0.55,
           PREP_TRAIL: 0.14, BREATH_TRAIL: 0.55, INHALE: 0.10, FOV_BOUNCE: 0.03, SHAKE_DEG: 0, EXIT_SHAKE_DEG: 0, ABERR: 0.3,
           // (B2) forma del destello en el tiempo: sube en el primer FLASH_UP2 (0,24 s de 0,8) y baja exponencial (FLASH_EXP); 0 = ROJO
           FLASH_UP2: 0.3, FLASH_EXP: 3.5 },
   // (N10) VUELO LIBRE: velocidad de crucero THRUST_K × (distancia a lo mas cercano) por segundo (×BOOST con Mayus); inercia al
   // acelerar ACC_S, deriva al soltar DAMP_S; giro TURN_K × campo de vision por segundo (igual a cualquier zoom) con inercia TURN_S;
   // tope VMAX_K × distancia (en un fotograma nunca se avanza mas que una fraccion de lo que queda: no se atraviesa nada);
   // STANDOFF: no se entra a menos de esta distancia de una estrella (años luz); GLIDE_S: el arrastre sigue girando al soltar;
   // KEY_HOLD_S: una tecla sin «soltar» se da por soltada a los 0,6 s sin repeticion (por si no llega el evento de soltar)
   // (E §10.3) ACC_S 0,9 -> 1,5 · DAMP_S 1,8 -> 3,2 · TURN_S 0,35 -> 0,6 · GLIDE_S 0,55 -> 1,0 · TURN_K 0,42 -> 0,30 (≈ 18 °/s a 60°)
   FREE: { THRUST_K: 0.35, BOOST: 4, ACC_S: 1.5, DAMP_S: 3.2, TURN_K: 0.30, TURN_S: 0.6, VMAX_K: 1.6, STANDOFF: 0.05, GLIDE_S: 1.0,
           KEY_HOLD_S: 0.6, BOOST_HOLD_S: 8, WHEEL_FRAC: 0.06,     // una muesca: 6 % de lo que hay delante (desde casa la foto crece ~6 %)
 FOV_S: 1.4, FOV_AWAY: 0.3, MIN_D: 1e-3, HOME_FLOOR: true,
           // (B2) el campo del vuelo libre sigue a la cobertura de la foto con exponente FOV_BETA (tan(campo/2) ∝ tan(cobertura/2)^FOV_BETA):
           // con 1 (lo de antes) era un efecto vertigo, la foto quieta en pantalla mientras se avanzaba; con 0,6 la foto crece. 1 = ROJO
           FOV_BETA: 0.6,
           // (coordinador, 4-nov tarde) NO SALIR DE LA FOTO antes de entrar en la nebulosa: con 6 muescas desde casa (z ≈ 185 a.l.) la foto
           // ya se ha apagado y las capas, con su borde oscurecido, quedaban como un rectangulo con fondo negro (nB2_rueda_tira.png, col. 5).
           // Fuera del volumen y mirando a la parte limpia, el campo no pasa de lo que esta cubre (fvFreeCleanCap); si el tope baja, el campo
           // se cierra como mucho CLEAN_RATE e-folds por segundo (sin saltos al volver a mirar hacia la foto). CLEAN_CAP false = ROJO.
           CLEAN_CAP: true, CLEAN_RATE: 1.5, CLEAN_OPEN: true,        // (LLEGADA) CLEAN_OPEN: abrir solo hasta ese tope (fvFreeStep); false = ROJO
           AHEAD_ARRIVED: true,    // (LLEGADA) la rueda mide «lo de delante» contando el objeto al que se llego (fvFreeAhead); false = ROJO
           CLEAN_EXACT: true,      // (LLEGADA) el tope del vuelo libre, exacto (fvRouteCover) y no con el suelo de 0,3 (fvFreeCleanCap); false = ROJO
           // (nF2, 4-nov noche; Nino, E8: «cuando hago clic y voy hacia algun lado con el raton, no solo gira sino que avanza mucho»; y K11b c)
           // TAKE_STOP: tomar el mando a mitad de un vuelo o de una orbita (arrastre, teclas) PARA la nave en seco. Antes se heredaba la
           // velocidad (con tope 1,6 × la distancia a lo mas cercano por segundo) y se deslizaba DAMP_S: arrastrar 300 px a mitad de un cine
           // movia la camara 24 a.l. y en orbita 4,6 a.l. (26 % de lo de delante). false = ROJO
           TAKE_STOP: true,
           // (nQ, decision A de F: A2, DECIDIDO SIN NINO) EN CASA la foto llena la pantalla justa: con A_GUARD el arrastre no podia girar nada
           // (cualquier giro dejaba ver fuera). El PRIMER arrastre en casa cierra el campo HOME_DRAG_ZOOM veces en HOME_DRAG_ZOOM_S
           // (smootherstep): da sitio para mirar alrededor dentro de la foto. 1 = ROJO (en casa el arrastre no gira)
           HOME_DRAG_ZOOM: 1.2, HOME_DRAG_ZOOM_S: 0.6,      // (1,2 y no mas: E8 de fv_nF2_node pide que un arrastre en casa no haga zoom de mas de ×0,8)
           // (nF2, E3 d: «al ir hacia adelante unas estrellas tambien se mueven hacia delante») FLOW_FOV: el campo del vuelo libre no se ABRE
           // mientras se avanza mas de lo que manda la ley sin vertigo (FOV_BETA × lo que crece la foto; abrir el campo es alejar con el zoom:
           // lo lejano se encoge hacia el punto de fuga mas deprisa de lo que la nave lo agranda) ni cambia en reposo; al retroceder, libre.
           // Antes, con W tras llegar, el campo se relajaba hacia el de casa avanzando (0,038° -> 0,074°): 2,18 % de las estrellas pintadas
           // convergian (llegadaW de fv_nF2_node; 0,00 % con esto). false = ROJO
           FLOW_FOV: true,
           // (nF2, E3: «nos seguimos yendo fuera del campo») A_GUARD: el vuelo libre (arrastre, teclas, rueda, el planeo al soltar) no ve
           // nunca fuera de la parte limpia de la foto/capas mientras la camara esta delante de la losa y mira hacia ella: el GIRO se para en
           // el borde (desliza por el otro eje) y la TRASLACION que lo exigiria se frena (la pared de la foto; el campo lo sigue cerrando,
           // despacio, CLEAN_CAP: cerrarlo de golpe era un zoom). Limite exacto, sin el margen de la ruta. Antes: un arrastre de 300 px en casa dejaba el 70 %
           // de la pantalla fuera; tras llegar, el 19 %; en orbita, el 100 %. false = ROJO
           A_GUARD: true, A_FLOOR: 0.25,
           // (I5, Nino: «control de raton al estilo Gaia Sky») GAIA_MOUSE: boton IZQUIERDO = girar la mirada (vuelo libre, sin avanzar: E8) u
           // ORBITAR el objeto enfocado (en orbita: ORBIT_DRAG_K radianes por ancho de pantalla, con inercia GLIDE_S; la orbita automatica
           // se para al tocarla); boton DERECHO = desplazar de lado (pan) con la velocidad ∝ distancia a lo que se tiene delante (lo de alli
           // sigue al cursor) y PAN_GLIDE de esa velocidad al soltar (se apaga con DAMP_S); RUEDA en orbita = acercarse/alejarse del objeto
           // (×ORBIT_ZOOM por muesca, suave en ORBIT_ZOOM_S, entre ORBIT_MIN_K y ORBIT_MAX_K de la distancia de partida); DOBLE CLIC sobre
           // una estrella u objeto = viajar alli (fvPilotPickAt; en el vacio, nada). Todo respeta A (A_GUARD). false = ROJO (lo de antes:
           // el derecho no hace nada, arrastrar en orbita la corta, la rueda en orbita la corta, doble clic = a casa)
           GAIA_MOUSE: true, ORBIT_DRAG_K: Math.PI, PAN_GLIDE: 0.6, ORBIT_ZOOM: 0.8, ORBIT_ZOOM_S: 0.25, ORBIT_MIN_K: 0.1, ORBIT_MAX_K: 10,
           // (5-nov, Nino: «cuando la rueda se mueve rapido, que se vaya rapido; lento, lento; igual hacia delante y hacia atras») WHEEL_RATE: la
           // rueda por RITMO y SIMETRICA. (1) Simetria: el paso es LOGARITMICO en la distancia a lo que se tiene delante (dT): adelante la acorta
           // ×e^−f, atras la alarga ×e^+f (f = WHEEL_FRAC × ganancia × muescas), y dT cuenta lo que aun le queda por recorrer a la deriva
           // (F.vW·mirada × WHEEL_GLIDE_S + la deriva de las teclas): N muescas adelante y N atras vuelven al mismo sitio si cada tanda parte de
           // la rueda en reposo y lleva el mismo ritmo. Antes cada muesca sumaba el 6 % de dA (adelante: dA encoge, cada paso mas corto; atras,
           // el primero es el mismo 6 % de una dA pequeña). (2) Ritmo: acumulador exponencial de las muescas con constante WHEEL_TAU = 0,12 s
           // (dentro de la ventana de 120–200 ms pedida; una muesca suelta vale 1/TAU = 8,3 muescas/s) → R en muescas/s; la ganancia por muesca es
           // (R / WHEEL_R0)^WHEEL_P entre 1 y WHEEL_GMAX. R0 = 12/s deja en paso fino ×1 la mano relajada (hasta ~8 muescas/s) y la muesca suelta;
           // con P = 1,5 una rodada de 15/s da ×2, una de 30/s ×4,7 (tope ×6 desde ~46/s). Constantes elegidas a ojo de lo que se sabe de una
           // rueda de raton (relajada 2–6 muescas/s, rodada 15–30, rueda libre > 40: NO VERIFICADO con la mano de Nino; se afinan aqui). En
           // orbita la misma ganancia con tope WHEEL_GMAX_ORBIT (el paso base ×0,8 por muesca ya es grande). Una muesca = delta/120 (PixInsight)
           // o delta/100 (navegador): las ruedas finas y los paneles tactiles mandan fracciones y suman igual (el paso ∝ muescas). WHEEL_MAXN:
           // tope de muescas por evento. false = ROJO (la ley de antes)
           WHEEL_RATE: true, WHEEL_TAU: 0.12, WHEEL_R0: 12, WHEEL_GMAX: 6, WHEEL_GMAX_ORBIT: 3, WHEEL_P: 1.5, WHEEL_MAXN: 4,
           // (3) el DESLIZAMIENTO de la rueda: con la deriva de DAMP_S (3,2 s) cada muesca se arrastraba ~10 s («primero muy rapido, despues
           // despacio», y al parar la rueda la nave seguia): con WHEEL_GLIDE_S (0,5 s) la nave sigue a la rueda y casi se para con ella (95 % a
           // 1,5 s). Sin el tope VMAX_K (el paso logaritmico nunca pasa de lo que queda por delante) mientras dura ese deslizamiento
           WHEEL_GLIDE_S: 0.5, WHEEL_AXIS_TOL: 0.05, WHEEL_REFRESH_K: 0.5,
           // (5-nov, Nino: «cuatro flechas… mueven la vista arriba, abajo, izquierda y derecha») LA CRUCETA de la cabina (fvPilotLookPad): las
           // MISMAS teclas de giro del vuelo libre (←/A, →/D, RePag, AvPag: un solo camino, §11.5) con inercia TURN_S; un clic dura como
           // minimo PAD_TAP_S (un paso de ~TURN_K × campo × PAD_TAP_S), mantener = giro continuo. En casa el primer giro cierra el campo como el
           // arrastre (HOME_DRAG_ZOOM). PAD_HOME_ZOOM tambien para las teclas de giro (antes, en casa, A_GUARD las dejaba inertes). false = ROJO
           PAD_TAP_S: 0.25, PAD_HOME_ZOOM: true, WALL_SLIDE: true },
   WHEEL_FRAC: 0.15,             // la rueda avanza el 15 % de la distancia al objeto mas cercano por muesca (F2; N11: FREE.WHEEL_FRAC de lo que hay delante)
   WHEEL_F2: false,              // (N11) true = la rueda de F2 (control en ROJO de la «bola»)
   // (5.ª corrida, coordinador + Contact / Powers of Ten) DOS GESTOS: (1) REVELACION desde donde se esta, quieta: el campo pasa de fov0 a
   // CINE_FOV_OPEN con un smootherstep en log (REVEAL_DEC s por decada de campo, entre CINE_PRE y REVEAL_MAX; ocupa el plano quieto): desde
   // casa la foto se ve encogerse dentro del cielo entero. (2) AVANCE con el campo YA abierto, fijo, que solo se cierra a fov1 (ARRIVE_FOV)
   // en la frenada (desde CINE_CLOSE0 del viaje): todo lo de delante crece y nada se encoge. Antes el campo se abria DURANTE el avance y la
   // nebulosa encogia mientras la nave iba hacia ella («parece que vuelas hacia atras»). CINE_REVEAL false = la ley anterior (ROJO).
   // La VUELTA A CASA, al reves: viaje de HOME_S con el campo que se tenga y, ya en la Tierra, cierre a la vista de casa (HOME_CLOSE_DEC
   // s por decada, tope HOME_CLOSE_MAX).
   CINE_REVEAL: true, CINE_FOV_OPEN: 66 * FV_DEG, CINE_CLOSE0: 0.6, REVEAL_DEC: 3.5, REVEAL_MAX: 8.0, HOME_CLOSE_DEC: 2.5, HOME_CLOSE_MAX: 5.0,
   CINE_FOV_RATE: 1.5,           // (3.ª corrida) el campo del cine se abre como mucho ×e^1,5 por segundo (×4,5/s; de 2,4° a 60° en 2,1 s)
   // (B2, 4-nov, Nino: «cuando le dices que quieres explorar algo se va fuera de la imagen para despues volver a entrar en ella») EL
   // VIAJE SALE DE LA FOTO, NO DE FUERA. La revelacion de la 5.ª corrida (abrir el campo de 0,76° a 66° quieta en la Tierra: la foto se
   // encogia a un sello en el cielo) se sustituye por un AVANCE con el campo estrecho: desde el primer fotograma la foto llena la
   // pantalla y se ENTRA en ella. Ley del campo (CINE_ADVANCE): tan(campo/2) = tan(campo0/2) · (d0 / d)^beta, con d la distancia al
   // destino y beta < 1 elegido por viaje (CINE_BETA_MIN–MAX) para llegar al campo de llegada al 85 % de la escala recorrida (en log):
   //   · el destino crece en pantalla como d^(beta − 1): nunca encoge (B); ademas, guarda explicita tan(campo/2)·d ≤ la del fotograma previo;
   //   · el campo no pasa de la cobertura de la foto mientras el pintor la dibuja (fvPhotoFovCap; A: ningun borde en cuadro);
   //   · no es un efecto vertigo: la nebulosa crece como (D − z)^(beta − 1) y las estrellas de delante se abren hacia los lados.
   // CINE_ADVANCE false = la ley de la 5.ª corrida (revelacion, CINE_REVEAL) = ROJO de A. HOME_ADVANCE: la vuelta a casa en UN gesto (el
   // campo se cierra mientras se vuelve, con el tope de la foto: se llega a la vista de casa sin pasar por el sello); false = ROJO.
   CINE_ADVANCE: true, CINE_BETA_MIN: 0.5, CINE_BETA_MAX: 0.95, CINE_BETA_AT: 0.85, HOME_ADVANCE: true,
   CINE_FG_FILL: true,       // (B2) destino delante de la nebulosa y dentro de la foto: la nebulosa de fondo llena la pantalla todo el viaje
   // (B2) el tope de la foto se suelta pasado el punto en que el pintor la apaga del todo (1,0 × PHOTO_FADE × D), no antes: con 0,8 la
   // foto aun pesaba un 10 % con su borde en cuadro (A). Antes 0,8–1,15.
   PHOTO_FADE: 0.03, PHOTO_CAP0: 1.0, PHOTO_CAP1: 1.3,   // (N11/N6) tope del campo por la cobertura de la foto; se suelta entre PHOTO_CAP0 y PHOTO_CAP1 × la distancia a la que el pintor apaga la foto (FV_PAINT.PHOTO_FADE × D; esta PHOTO_FADE es la copia para node)
   // (B2, Nino: «cuando la nave esta parada hay un pequeño bamboleo que no tiene sentido: las estrellas estan muy lejos») LA DERIVA VIVA
   // (LIVE_DRIFT, abajo) se APAGA: en reposo la camara queda quieta. Un giro de la mirada mueve igual lo cercano y lo lejano (no hay
   // paralaje que lo justifique) y una traslacion de flotar, con la estrella mas cercana a años luz, seria invisible. true = ROJO.
   LIVE_DRIFT_ON: false,
   // (B2, decision 7B de Nino) EL REGULADOR = VELOCIDAD DEL VIAJE: P.speed 0…1 (0,5 = la de por defecto) multiplica los tiempos por
   // SPEED_SPAN^(1 − 2·speed) (×2 a ×0,5, escala logaritmica; fvSpeedDurK). fvPilotSetSpeed(P, s).
   // (6-nov, FAST_EASE) con FAST_EASE escala TODO el viaje: en el cine el plano quieto y la panoramica previa, el avance (arranque, crucero y
   // frenada) y la deriva de llegada; en el warp el vertigo del primer salto, las fases (preparacion, estiramiento, pausa, destello), el
   // crucero y la salida; en el editor de camaras (ruta) cada tramo (las paradas no: son el tiempo de mirar). Sin FAST_EASE (lo de antes)
   // solo el avance del cine y el crucero del warp.
   SPEED_SPAN: 2.0,
   // (6-nov-2026, Nino: «Tanto al viajar como al hacer el tour, tanto el comienzo como el final son muy lentos. Tarda la nave en avanzar y
   // tarda tambien mucho al llegar y desacelerar. Hazlo cinematografico pero mas rapido. Que el indicador Regulator sirve para esto, tanto
   // en modo Cine como en modo Warp.») FAST_EASE: false = lo de antes, pixel identico (ROJO de tests/fv_viaje_rapido_node.js). Medido en
   // tests/fv_viaje_rapido_node.js (escena real de IC 1848, regulador 0,5): donde estaba la lentitud
   //   · cine: 2,5 s de plano QUIETO (CINE_PRE) + arranque smootherstep del 20 % del viaje (6,5 s) + frenada gaussiana desde el 58 % (13,6 s,
   //     con cola: llega al 4 % de la velocidad y para de golpe) + el ritmo «cerca de algo» ×1,8 en los dos extremos (CINE_VARY[0]);
   //   · warp: 3,3 s de fases antes del crucero (preparacion 1,6 + estiramiento 0,5 + pausa 0,4 + destello 0,8) y 1,65 s de salida, que el
   //     regulador no tocaba;
   //   · ruta: el mismo perfil de avance (fvCineX) en cada tramo entre paradas.
   // FAST: PRE plano quieto (s; lo que pida la panoramica si es mas) · ACC / BRAKE: el arranque llega al crucero en la fraccion ACC del
   // avance y la frenada empieza en BRAKE y baja con smootherstep HASTA 0 (aceleracion continua, sin cola ni parada en seco; la deriva de
   // llegada se queda sin velocidad que heredar) · DUR_K: los tiempos del avance del cine × DUR_K (el crucero va casi igual de rapido: el
   // perfil nuevo tiene mas crucero) · VARY_NEAR: el peso del ritmo cerca de algo (antes 1,8) · WARP_K: las fases del warp × WARP_K ·
   // PATH_K: los tramos de la ruta × PATH_K · COAST_K: la constante de la deriva de llegada × COAST_K
   FAST_EASE: true,
   FAST: { PRE: 0.5, ACC: 0.12, BRAKE: 0.74, DUR_K: 0.6, VARY_NEAR: 1.2, WARP_K: 0.5, PATH_K: 0.7, COAST_K: 0.5 },
   // (6-nov-2026, Nino: «Haz que el morro de la nave siempre apunte a la imagen. De esta forma, si voy de lejos a cerca, no tengo que ver todo
   // negro y no me desoriento. Haz que la nave se mantenga mirando dentro de la fotografia en todas sus maniobras»; y «cuando tiro hacia atras
   // rapido con la rueda del mouse, parece que la nave se descontrola y solo veo negro») KEEP_IN: EL EJE DE LA VISTA SIEMPRE CORTA LA FOTO.
   // Invariante (medido en tests/fv_nav_fix_node.js): fuera de la losa, el rayo de la mirada (t > 0) corta el rectangulo de la foto en su plano
   // z = D (medias HW × HH, fvRouteGeo); dentro de la losa y de su huella la camara esta rodeada de nebulosa y no se toca. Se impone al FINAL de
   // cada paso del piloto (fvKeepInStep), en TODAS las maniobras (vuelo libre, cine, warp, ruta, orbita, deriva de llegada, frenada): si la mirada
   // que pide la maniobra no corta el rectangulo × K (con destino: K = 1, el invariante exacto; en vuelo libre la pared K_WALL al 90 % del
   // medio ancho/alto: con el eje en el borde exacto media pantalla queda fuera), la camara mira a un punto del plano de la foto que va hacia el bueno con constante TAU (sin saltos; el punto se mueve dentro del
   // rectangulo, que es convexo: nunca sale). El punto bueno: con un DESTINO (vuelo, orbita, deriva), el punto de la foto que queda detras de el
   // visto desde la Tierra (dentro de K_AIM: lejos del borde oscurecido de las capas); sin destino (vuelo libre), la mirada pedida recortada
   // radialmente al rectangulo (una pared por la que se desliza). Cuando la mirada pedida vuelve a cortar la foto, el punto la alcanza con
   // TAU_BACK y se suelta a menos de TOL × el campo. MAX_DPS: la mirada corregida nunca gira mas deprisa que eso (sin latigazos). Medido antes de esto (escena real de IC 1848): warp de una estrella lejana a una cercana
   // 99,8 % de fotogramas con el eje fuera (pantalla negra), orbita 97,8 %, tecla de giro tras llegar 55,6 %, tour (lejana -> la mas cercana) 85 %.
   //   WARP_SIGHT  el warp que acabaria mirando FUERA de la foto (de lejos a cerca: llegaba por detras de la estrella, mirando hacia la Tierra)
   //               llega por el lado de la Tierra, en la linea de vision del destino (como el cine I6): al final la estrella esta delante y la
   //               foto detras. Solo cuando la llegada de siempre incumpliria (los demas viajes no cambian)
   //   FOV / FOV_RATE  mientras la mirada esta corregida (mira a la foto en vez de a lo que pedia la maniobra) el campo no pasa de lo que cubre
   //               la foto entera con ese eje (fvRouteCover whole), cerrandose como mucho FOV_RATE e-folds/s: la foto llena la pantalla en
   //               vez de quedar como un sello en un campo de 60–105°
   //   WHEEL_BACK  la rueda hacia atras no lleva la camara mas alla del plano de casa (z = 0, desde delante de la foto) ni, desde detras de
   //               la foto, mas lejos de ella que D (su simetrico): antes la sesion logaritmica de la rueda (×e^+f por muesca, ganancia ×6 a
   //               ritmo alto) mandaba la camara a 1e54 a.l. mirando a la Tierra (pantalla negra para siempre) o la estrellaba contra z = 0
   //               deslizandose de lado 64 a.l. con el campo a 0,001°. Si recorta, la sesion se vuelve a medir en la siguiente muesca
   //   FLOOR_STOP  al tocar el plano de casa se para del todo (antes solo se quitaba la componente z: seguia resbalando de lado)
   // ON false = lo de antes (el ROJO de tests/fv_nav_fix_node.js).
   KEEP_IN: { ON: true, K: 1.0, K_WALL: 0.9, K_AIM: 0.6, TAU: 0.35, TAU_BACK: 0.15, TOL: 0.004, MAX_DPS: 20, FLIP_DPS: 120, TURN_ACC: 240, FOV_FLOOR: 0.3, BEYOND_FREE: true, WARP_SIGHT: true, FOV: true, FOV_RATE: 1.5, WHEEL_BACK: true, FLOOR_STOP: true },
   // (6-nov-2026, Nino: «El boton entre las flechas que tenemos en el panel de control debe frenar la nave») LA FRENADA (fvPilotBrake): el centro
   // de la cruceta para la nave con una deceleracion suave desde la velocidad que lleva (tope VMAX_K × lo mas cercano, como al tomar el mando)
   // hasta 0 con un smootherstep en S s × el REGULATOR (fvSpeedDurK: 0 = ×2 mas larga, 1 = ×0,5), cancelando cine, warp, ruta, orbita y deriva.
   // Sin deriva despues (velocidad 0 exacta al acabar). El campo del warp vuelve al del vuelo libre en el mismo tiempo; las rayas se recogen.
   BRAKE: { ON: true, S: 0.9 },
   AVOID_K: 0.06, AVOID_PUSH: 3.0, AVOID_ITERS: 3, AVOID_PHOTO_ZONE: true,   // (4.ª corrida) sin desvios mientras se ve la foto al salir de casa (false = ROJO)
   // (B2) EL TUBO DE LA FOTO: saliendo de casa, los desvios (a 3 radios = 0,18 × la escala) sacaban la camara 10–14° del eje (vista desde
   // la Tierra) cuando el tubo de la foto mide 0,45°: a mitad de viaje se veia la nebulosa de lado, un rectangulo (tests/fv_nB2_node.js,
   // A'). Dentro del tubo el radio de peligro se reduce a AVOID_TUBE_K × el normal y el punto de desvio se queda dentro del tubo (como mucho
   // TUBE_KEEP de su radio). Rozar una estrella dentro del tubo es «una estrella que pasa al lado», no un choque. false = ROJO.
   AVOID_TUBE: true, AVOID_TUBE_K: 0.08, TUBE_KEEP: 0.7,
   FLYBY_MAG: -2.0, FLYBY_MIN: 0.004, FLYBY_MAX: 0.06,
   PICK_PX0: 2, PICK_PX_MAG: 2, DOLLY_S: 1.1, DOLLY_K: 1.6,
   // (RUTA, 4-nov-2026; docs/ruta-del-viaje-analisis.md; Nino: «una vez elegido, la camara hace cosas muy raras para llegar a el, cuando
   // deberia seguir una linea recta o una parabola») LA LEY NUEVA DEL VIAJE: recta (o UN arco si hay un choque de verdad), avance con la
   // escala de LO QUE SE VE, mirada resuelta en PANTALLA (el destino nunca sale del cuadro), campo como RITMO con el tope A exacto y B por
   // construccion, todo PLANIFICADO al arrancar (fvRoutePlan; sin muelle ni guardas fotograma a fotograma). Cada pieza con su bandera;
   // false = la ley de antes (ROJO):
   //   CINE    el viaje de cine (false = spline + grua + subida WWT + 3 esquives + muelle + guardas de B2)   -> R1–R5, R7, R11, R15
   //   HOME    la vuelta a casa: panoramica corta y retroceso recto (false = la de B2, con el latigazo de la mirada, R6)
   //   WARP    el warp: encuadre de la preparacion con A y campo planificado con B (false = R12 y R13 en rojo)
   //   BETA    (D1) ritmo del campo: tan(campo/2) se multiplica por (d_ant/d)^BETA en cada paso (0 si el destino esta delante de la
   //           nebulosa y dentro de la foto: la nebulosa de fondo no encoge); se llega con menos de 60° (C1: 0,65 -> 6–24°)
   //   VIS_TAU (D3) avance con la escala visible: la losa (114 a.l.) se cruza despacio, ~1,8 s; false = solo la distancia al destino (ROJO:
   //           la losa en 1 fotograma)
   //   FADE_K  el tramo del fundido de la foto en esa escala (0 = ROJO: el campo se cerraba ×2,5 en 0,4 s al salir de casa)
   //   AVOID_REAL (D5) solo un choque de verdad: una estrella a menos de AVOID_REAL_K × SU distancia de llegada (o de FREE.STANDOFF) de la
   //           recta -> un unico arco plano (parabola); false = recta siempre. (D4) Sin grua: se llega por la recta.
   //   PAN_DPS / PAN_MIN_S  la panoramica previa si el destino no esta en cuadro: pico ≤ 20 °/s; en casa ≤ HOME_PAN_DPS (10 °/s, R6) y
   //           nunca menos de 0,6 s. HOME_PAN_MAX_S: en casa, nunca mas de 5 s (tras «mirar a casa» se mira al Sol, 180° atras: a 10 °/s
   //           eran 34 s de panoramica quieta; con 5 s el pico es 68 °/s y la aceleracion ≤ 42 °/s², sin el latigazo de R6: 187 °/s y 628 °/s²)
   //           (K11b) con HOME_PAN_MOVE (abajo) ya no hay panoramica quieta en casa: HOME_PAN_DPS / HOME_PAN_MAX_S solo valen para el ROJO
   //   WARP_BETA  la ley de ritmo en el warp (R13): el tunel abre como mucho (d_ant/d)^0,85 por paso; con 1 seria un efecto vertigo
   //   FOV_RATE  ritmo maximo del campo (e/s) en el cine, en casa y en el editor, abriendo y (planificado hacia atras) cerrando; WARP_FOV_RATE
   //           el de cerrar en el warp (abrir lo limita B)
   //   THIRD_INSIDE  false: al llegar, el destino en el tercio IZQUIERDO (la ficha sale a la derecha, §10.5; fvArriveFrameDx); true: del
   //           lado de dentro de la foto (C3 del analisis)
   //   WARP_ZOOM_MAX  en la preparacion del warp con la foto pintada el campo se cierra como mucho ×4 para encarar el destino; si no basta
   //           (destino junto al borde), se encara menos y el destino queda desplazado hasta que la foto se apaga (R12)
   //   PATH_S  [minimo, s por decada de escala, maximo] de cada tramo entre pausas de fvPilotFlyPath (el editor de camaras)
   //   EDGE_FALLBACK  el borde de las capas que supone el piloto sin FV_PAINT (visor web): (D2) [0,10, 0,07]; ROJO [0,14, 0,12]
   ROUTE: { CINE: true, HOME: true, WARP: true, BETA: 0.65, VIS_TAU: true, FADE_K: 2, AVOID_REAL: true, AVOID_REAL_K: 0.03,
            PAN_DPS: 20, HOME_PAN_DPS: 10, HOME_PAN_MAX_S: 5, PAN_MIN_S: 0.6, FOV_RATE: 1.5, WARP_FOV_RATE: 3, WARP_BETA: 0.85, A_MARGIN: 0.97, SKY_CLAMP: 0.8, THIRD_INSIDE: false,
            WARP_ZOOM_MAX: 4, PLAN_DT: 1 / 60, PATH_S: [6, 4, 30], EDGE_FALLBACK: [0.10, 0.07],
            // (LLEGADA, 4-nov noche; Nino: «llega y la foto queda como un sello», 3 estrellas delante de IC 1848, en WARP) el tope A del warp solo
            // valia en la zona de la foto (|pos| < zPhoto, ~250 a.l.): pasada esa zona el tunel abria el campo hacia ARRIVE_FOV (60°) y 105° y se
            // llegaba con 5–59°, la nebulosa un sello (fuera 0,98–1,00 de la pantalla en 6 estrellas, tests/fv_llegada_node.js). Ahora, como el
            // cine (fvRouteCapA), con el destino en la parte LIMPIA el tope sigue hasta entrar en la losa: en el plan del warp y en el vertigo
            // del primer warp. false = ROJO (la ley de la ruta de la tarde)
            WARP_A_SLAB: true,
            // (K11b, revision adversarial de Codex sobre la ruta; false = ROJO, lo de antes) COVER_CORNERS: el tope A por los rayos de las 4
            // esquinas (fvRouteCoverCorners; antes suponia el plano de la foto perpendicular a la mirada) · CAP_SAFE: si la biseccion del tope no
            // encuentra campo, «sin solucion» (se baja el encuadre) y lo que quede fuera de A se avisa en fl.warnings (capFix) · AIM_POLE: la
            // mirada del tercio resuelta en forma cerrada cerca del polo (fvAimAt; antes la iteracion podia invertir el lado) · HOME_PAN_MOVE: en
            // la vuelta a casa el giro empieza A LA VEZ que el avance (sin panoramica quieta) con pico ≤ HOME_TURN_DPS; si no cabe en el viaje,
            // se alarga el viaje (fvRouteSetup)
            COVER_CORNERS: true, CAP_SAFE: true, AIM_POLE: true, HOME_PAN_MOVE: true, HOME_TURN_DPS: 25, HOME_TURN_DPS2: 30, HOME_TURN_MAX_S: 9,
            // (K11b, punto 5) el editor de camaras (fvPilotFlyPath): PATH_STOP_DEG para (sin pausa) donde el camino vuelve atras (0 = ROJO)
            PATH_STOP_DEG: 90,
            // (nF2, E3: «nos seguimos yendo fuera del campo») EDGE_WHOLE: con el destino FUERA de la parte limpia (junto al borde de la foto) el
            // tope A solo valia en la zona de la foto (~255 a.l.); pasada esa zona el tunel del warp abria el campo y se veia fuera de la foto
            // (warp a la estrella del borde de Collinder 34: 96 % de la pantalla fuera de la foto ENTERA). Ahora sigue, contra la foto entera,
            // hasta entrar en la losa (cine y warp). false = ROJO
            EDGE_WHOLE: true,
            // (nQ, 5-nov-2026; Nino: «Probamos tambien I6 porque hasta ahora las rutas no son un punto fuerte»; medido en
            // tests/fv_nQ_rutas_node.js, 8 rutas). Cada pieza con su bandera, false = la ley de antes (ROJO):
            //   SIGHT (I6, «subir, cruzar, bajar» de WWT ViewMoverSlew dentro de A y B): se llega por la LINEA DE VISION del destino (la recta
            //         Tierra-destino: el destino delante de su sitio en la foto, como lo pone fvRouteCamAt del editor). Si desde la salida el rayo
            //         al destino cae fuera de la parte limpia (A -> B al otro lado: medido, 30 s mirando el vacio con el campo ×20 mas cerrado),
            //         primero se CRUZA hasta esa linea (al pie de la perpendicular: la distancia al destino solo baja, B) y se BAJA por ella;
            //         si el destino queda DETRAS (B -> A hacia la Tierra: medido, giro de 180° en el sitio a 20 °/s con 0,03° de campo, 1 568
            //         medios anchos por segundo), se SUBE retrocediendo hacia casa por la propia linea de vision (mirando a la foto: el origen
            //         se ve encoger donde esta), se cruza en U hasta la del destino y se baja (WWT: subir hasta SIGHT_TOP_K × la separacion,
            //         acotado). La mirada es la LINEA DE VISION PROPIA (lo que la Tierra ve a traves de la nave) con el tercio: el eje cae
            //         siempre dentro de la foto (A) y en la bajada es el destino. Tiempos por las decadas de cada tramo (log de la razon de
            //         distancias, WWT) y velocidad ∝ escala visible (OpenSpace) con frenado en la U (la cima como foco)
            //   VIS_ONSCR (I9/I11) en la escala visible el origen y el destino solo cuentan si estan EN PANTALLA (medido: de la estrella central a
            //         la lejana, 16 s pasando a 2–8 a.l. del origen ya fuera de cuadro sin que cambiara nada). Peso CONTINUO tambien detras
            //   VIS_LIP (I11) la escala efectiva (escala / peso del ritmo) con pendiente ≤ VIS_LIP por a.l. de camino (fvRouteLipScale): es el
            //         ritmo al que se multiplica la velocidad. Medido (ln de la velocidad por segundo, R4 estrella -> nebulosa atravesando la
            //         estrella de salida): sin ella 2,1 (de arrastrarse 13 s a 1 400 a.l. en 1 s); 2,2 -> 1,34; 1,5 -> 1,07; 1 -> 0,87 pero R7
            //         gira a 2,8 °/s (19 °/s²). 1,5 (DECIDIDO SIN NINO). (Ensanchar la transicion del ritmo cerca -> vacio no cambiaba nada: ≤ 0,05)
            //   PACE  (I11, AMNH §15) ritmo variable: el peso del avance es CINE_VARY[0] (1,8) cerca de algo (escala visible pequeña: salida,
            //         llegada, la losa, una estrella que se pasa a menos de PACE_PASS_K × su distancia de llegada) y CINE_VARY[1] (0,45) en el vacio
            //   EVENTS (I9) en el cine, mientras el destino esta en pantalla, su escala en pantalla 1/(tan(campo/2)·d) DOBLA al menos cada EVENT_S
            //         segundos (si no lo hace el avance, el campo se cierra: el destino crece; nunca se inventan objetos)
            //   EDGE_FRAME (b) destino fuera de la parte limpia (junto al borde de la foto): se encuadra hacia DENTRO hasta EDGE_X medios anchos (en
            //         vez del tercio) para que el tope A de la foto entera deje mas campo y entre nebulosa limpia (antes: llegada a 0,17° con
            //         la pantalla entera en la franja oscura de las capas, 840 de 985 fotogramas)
            //   PATH_AIM (a) el editor: entre llaves se mira al PUNTO del plano de la foto que mira cada llave, interpolado: el eje no sale de
            //         la foto y A no cierra el campo a 0,001° (K5 A -> B -> A: 14,5 -> 1,6 medios anchos por fotograma). PATH_SWEEP > 0 alarga el
            //         tramo que barra mas de eso (medios anchos/s): APAGADO (0) porque con una llave que mira FUERA de la foto el tope A es
            //         singular (-> 0 junto al borde) y alargar solo lo muestrea mas fino: K5 con 30 -> 1 500 s y 12 medios anchos por fotograma
            //   FOV1_PLAN (encargo de Mirabilia) fl.fov1 = el campo de llegada que vuela el plan (fvRouteArriveTan); EDGE_NEAR: EDGE_FRAME
            //         tambien con el destino limpio a mas de EDGE_NEAR de su borde limpio, y en vertical. EVENT_ARRIVE_K: la llegada cuenta como
            //         evento desde ≤ EVENT_ARRIVE_K × la distancia de llegada. SIGHT_PRE: la quietud inicial al subir (destino detras)
            SIGHT: true, SIGHT_RAY_K: 0.15, SIGHT_TOP_K: 0.3, SIGHT_TOP_MIN: 6, SIGHT_TOP_FRAC: 0.6, SIGHT_U_K: 1.0, SIGHT_PRE: 0.8, SIGHT_X_EPS: 3,
            VIS_ONSCR: true, VIS_K: 2, VIS_LIP: 1.5, PACE: true, PACE_PASS: false, PACE_PASS_K: 3, PACE_PASS_SIG: 1.5, EVENTS: true, EVENT_S: 8, EVENT_RAMP: 2, EVENT_KEEP: 0.8, LT_SMOOTH: 0.25, EVENT_ARRIVE_K: 1.25, EDGE_FRAME: true, EDGE_X: 0.8, EDGE_NEAR: 0.8, FOV1_PLAN: true,
            PATH_AIM: true, PATH_SWEEP: 0,
            // (pasada S, 5-nov-2026; rojos f1 «Ir a» y f2 «B cine» de tests/BATERIA_5nov.md, medido en tests/fv_S_cine_llegada_node.js):
            //   SIGHT_U_FIT k  en la U del viaje I6 «subir» (modo R) el radio r = media separacion lateral de las dos lineas de vision podia
            //         pasar de dTop − dA: el final de la U (b = cima + r por la linea del destino) caia DETRAS del destino y la bajada volvia
            //         hacia la llegada ATRAVESANDO la estrella (f2, 521 -> 1301: lateral 32,1 a.l., dTop 14,0, dA 2,34 -> pasa a 0,049 a.l.)
            //         y, con B (beta 0: el destino no encoge), el campo de llegada caia a 0,00005°. Ahora r ≤ k × (dTop − dA): la bajada
            //         nunca llega mas cerca que (dTop + dA)/2 antes de la llegada. 0 = ROJO (lo de antes)
            //   EDGE_FRONT  EDGE_FRAME solo si la LLEGADA queda delante de la losa (p1 z < zIn), donde el tope A de la foto existe: detras
            //         de la nebulosa (f1, estrella 12 a 8 585 a.l.) la foto queda a la espalda, el campo de llegada era el mismo (20,97° con y
            //         sin el encuadre de borde) y la estrella acababa en la esquina (128, 72) en vez del tercio. false = ROJO (lo de antes)
            SIGHT_U_FIT: 0.5, EDGE_FRONT: true },
   // (nF2) el visor web no tiene FV_PAINT: aqui manda si solo se pinta (y se elige) la huella de la foto (FV_PAINT.PRINT_ONLY en PixInsight)
   PRINT_ONLY: true,
   ROLL_PROJ: true,      // (nQ, encargo de P) el roll de la camara en fvProjector (ver alli); false = lo gira el pintor
   SEC_PER_YEAR: 3.15576e7
};

// ---------------------------------------------------------------------------
// LA PROYECCION: camara { pos, look, fov } + lienzo VW × VH -> { project(p) → [sx, sy, zc] | null, B, f }
// ---------------------------------------------------------------------------
// (nQ, encargo de P) el ROLL de la camara (cam.roll, rad) lo lleva el proyector: la base gira alrededor de la mirada (r' = cos·r + sin·d,
// d' = −sin·r + cos·d; la misma formula que fvPaintRoll de fv_painter.js) y pr.roll queda definido, asi el pintor no gira otra vez
// (fvPaintRoll mira pr.roll !== undefined). FV_PILOT.ROLL_PROJ false = el proyector lo ignora y lo gira el pintor (lo de antes)
function fvProjector(cam, VW, VH) {
   if (cam.B && typeof fvLabProjector === "function") return fvLabProjector(cam, VW, VH);   // (8-nov, LABORATORIO) base completa y S (cam.B solo existe con FV_LAB.ON)
   var B = fvBasis(cam.look, [0, 1, 0]), f = (VW / 2) / Math.tan(cam.fov / 2), cx = VW / 2, cy = VH / 2, px = cam.pos;
   var rollP = (typeof FV_PILOT !== "undefined" && FV_PILOT.ROLL_PROJ) ? (+cam.roll || 0) : undefined;
   if (rollP) { var cR = Math.cos(rollP), sR = Math.sin(rollP), rB = B.r, dB = B.d; B = { r: [cR * rB[0] + sR * dB[0], cR * rB[1] + sR * dB[1], cR * rB[2] + sR * dB[2]], d: [-sR * rB[0] + cR * dB[0], -sR * rB[1] + cR * dB[1], -sR * rB[2] + cR * dB[2]], f: B.f }; }
   var r0 = B.r[0], r1 = B.r[1], r2 = B.r[2], d0 = B.d[0], d1 = B.d[1], d2 = B.d[2], f0 = B.f[0], f1 = B.f[1], f2 = B.f[2];
   return { B: B, f: f, cx: cx, cy: cy, W: VW, H: VH, pos: px, roll: rollP,
            r: [r0, r1, r2], d: [d0, d1, d2], fw: [f0, f1, f2],
            project: function(p, near) {
               var vx = p[0] - px[0], vy = p[1] - px[1], vz = p[2] - px[2];
               var zc = vx * f0 + vy * f1 + vz * f2;
               if (!(zc > (near || 1e-9))) return null;
               return [cx + f * (vx * r0 + vy * r1 + vz * r2) / zc, cy + f * (vx * d0 + vy * d1 + vz * d2) / zc, zc];
            } };
}
// el campo de vision horizontal con el que la foto CUBRE un lienzo VW × VH (sin bandas): f_lienzo = F · cubrir
function fvHomeFov(scene, VW, VH) {
   var fl = scene.field, cover = Math.max(VW / fl.width, VH / fl.height), f = fl.F * cover;
   return 2 * Math.atan((VW / 2) / f);
}

// ---------------------------------------------------------------------------
// EL PILOTO
// ---------------------------------------------------------------------------
// (nF2) ¿se pinta solo la huella de la foto? (el pintor de PixInsight manda con FV_PAINT.PRINT_ONLY; el visor web, con FV_PILOT.PRINT_ONLY)
function fvPrintOnly() { if (typeof fvPrintW !== "function") return false; return (typeof FV_PAINT !== "undefined" && FV_PAINT.PRINT_ONLY !== undefined) ? !!FV_PAINT.PRINT_ONLY : !!FV_PILOT.PRINT_ONLY; }
function fvPilotNew(scene, VW, VH) {
   // (nF2) la foto es el fondo: las distancias SUPUESTAS no pasan de la nebulosa (fv_scene.js, fvSceneTuckAssumed; una vez por escena)
   if (typeof fvSceneTuckAssumed === "function") { try { fvSceneTuckAssumed(scene); } catch (eT) {} }
   var P = { scene: scene, VW: VW, VH: VH, t: 0, cam: null, flight: null, orbit: null, sel: null, arrivedAt: null,
             vel: [0, 0, 0], speedC: 0, speedLyS: 0, warp: 0, flash: 0, trail: 0, mode: "home", homeFov: fvHomeFov(scene, VW, VH),
             wheel: 0, lookState: null, events: [], style: "cine", dollyDone: false, odo: 0, sunMark: false,
             free: null, coast: null, onFlightEnd: null, speed: 0.5 };
   P.cam = { pos: [0, 0, 0], look: [0, 0, 1], fov: P.homeFov };
   return P;
}
function fvPilotResize(P, VW, VH) {
   P.VW = VW; P.VH = VH; var hf = fvHomeFov(P.scene, VW, VH);
   if (P.mode === "home") P.cam.fov = hf;
   P.homeFov = hf;
}
function fvPilotSetStyle(P, style) { P.style = (style === "spectacular") ? "spectacular" : "cine"; }
// (B2) EL REGULADOR: s de 0 (lento) a 1 (rapido); 0,5 = lo de siempre. Vale para el PROXIMO viaje (el que esta en marcha no cambia).
function fvPilotSetSpeed(P, s) { var v = Number(s); P.speed = fvClamp(isFinite(v) ? v : 0.5, 0, 1); return P.speed; }
// el factor de duracion del avance: SPEED_SPAN^(1 − 2·speed) -> ×2 (s = 0) … ×1 (0,5) … ×0,5 (1)
function fvSpeedDurK(P) { var s = (P && P.speed !== undefined) ? P.speed : 0.5; return Math.pow(FV_PILOT.SPEED_SPAN, 1 - 2 * fvClamp(s, 0, 1)); }
// (20-nov-2026, V1b/V1-06; FV_V1.CURVE en fv_flightlab.js) EL PRESUPUESTO DE TIEMPO TOTAL de un viaje automatico (s): la palanca ya no es un factor sobre una duracion a la que luego se
// suman giro previo, media vuelta y asentamiento (SLOW: 32-42 s medidos), es el TIEMPO que el viaje entero (giro previo, camino, media vuelta y asentamiento) puede durar. Interpolacion
// logaritmica entre la palanca en SLOW (T_SLOW) y en FAST (T_FAST): cine 15 -> 10 (centro) -> 6,5 s; warp 6,5 -> 4,4 -> 3 s (decision D2, curva A). kind: "warp" o lo que sea (cine)
function fvV1Budget(P, kind) {
   var F = (typeof FV_V1 !== "undefined") ? FV_V1 : null, i = (kind === "warp") ? 1 : 0, ts = F ? F.T_SLOW[i] : 15, tf = F ? F.T_FAST[i] : 6.5;
   // (21-nov, N-galaxias-warp; FV_GWARP) el warp corto de las galaxias (P.gwPlan lo pone fvLabFly mientras planea) tiene su propio presupuesto
   if (kind === "warp" && P && P.gwPlan === true && typeof FV_GWARP !== "undefined") { ts = FV_GWARP.T_SLOW; tf = FV_GWARP.T_FAST; }
   var s = fvClamp((P && P.speed !== undefined) ? P.speed : 0.5, 0, 1);
   return ts * Math.pow(tf / ts, s);
}
// (21-nov, N-galaxias-warp; FV_GWARP, fv_objects.js) EL MODO DE UN VIAJE «travel»: el destino manda (fuera de la Via Lactea = warp corto, dentro = cine). P.style «spectacular» (solo pruebas / ajuste viejo) = warp de siempre.
// -> "warp" | "cine"; P.gwNow = true si es el warp corto de las galaxias (lo lee el planificador para el presupuesto)
function fvTravelKind(P, sel, classic) {
   P.gwNow = false;
   if (P.style === "spectacular") return "warp";
   // (21-nov, R8) classic = lo llama el planificador CLASICO de fvPilotFly (FV_LAB.ON false): sin FV_GWARP.CLASSIC no hace warp de galaxias (su warp no usa la ley de encuadre; ver FV_GWARP.CLASSIC). La v5 (fvLabFly) no pasa classic
   if (classic === true && typeof FV_GWARP !== "undefined" && FV_GWARP.CLASSIC !== true) return "cine";
   if (typeof FV_GWARP !== "undefined" && FV_GWARP.ON === true && typeof fvGwarpSelFar === "function" && fvGwarpSelFar(P, sel)) { P.gwNow = true; return "warp"; }
   return "cine";
}
// ¿las interfaces SIN selector cine/warp? (FV_GWARP.ON: cabina de PixInsight y web, tecla M, boton «otro modo» de la ficha)
function fvGwarpUi() { return typeof FV_GWARP !== "undefined" && FV_GWARP.ON === true; }
// ¿un vuelo con efecto de warp? (el warp, o la vuelta a casa de una galaxia en warp corto: fl.gwHome)
function fvIsWarpFl(fl) { return !!fl && (fl.kind === "warp" || fl.gwHome === true); }
// (6-nov, FAST_EASE) ¿la ley rapida? y el factor del regulador para lo que antes no escalaba (1 sin FAST_EASE: lo de antes)
function fvFastOn() { return FV_PILOT.FAST_EASE === true && !!FV_PILOT.FAST; }
// el factor de cada tramo de la ruta (motor y respaldo de src/ui/fv_route.js y web/fw_route.js): el regulador × PATH_K con FAST_EASE
function fvPathDurK(P) { return fvSpeedDurK(P) * (fvFastOn() ? FV_PILOT.FAST.PATH_K : 1); }
// la posicion del objeto elegido
function fvSelPos(P, sel) {
   if (!sel) return null;
   // (nQ, encargo de P) con la maquina del tiempo (AETAS) la estrella esta donde la pone fvTimeStars (fv_time.js), no en la de hoy
   if (sel.kind === "star") { var STm = (typeof fvTimeStars === "function") ? fvTimeStars(P.scene) : null; return (STm && STm !== P.scene.stars && sel.i < STm.n) ? [STm.x[sel.i], STm.y[sel.i], STm.z[sel.i]] : fvStarPos(P.scene, sel.i); }
   if (sel.kind === "nebula" && P.scene.nebula) {
      // (19-nov, N6; FV_N6.DIST) con el laboratorio la nebulosa elegida (Tour sin protagonista, clic, camara de ruta...) es SU fila principal: el centro de su contorno, como si se hubiese elegido en MIRABILIA
      var mN6 = (typeof FV_N6 !== "undefined" && FV_N6.DIST && typeof fvN6Main === "function") ? fvN6Main(P.scene) : -1;
      if (mN6 >= 0) { var otN = fvSelObjectTarget(P, { kind: "object", i: mN6 }); if (otN) return otN.pos.slice(); }
      return [0, 0, P.scene.nebula.distLy];
   }
   if (sel.kind === "object") { var ot = fvSelObjectTarget(P, sel); return ot ? ot.pos.slice() : null; }
   return null;
}
// (N, contrato con C) el destino de un objeto singular: fvObjectTarget(scene, i) -> { pos, arriveLy, lookAt } (si C lo ha cargado)
function fvSelObjectTarget(P, sel) {
   if (typeof fvObjectTarget !== "function") return null;
   try { var o = fvObjectTarget(P.scene, sel.i); return (o && o.pos) ? o : null; } catch (e) { return null; }
}
// a donde se mira al llegar (el objeto, o su lookAt si C lo da)
function fvSelLookAt(P, sel, T) {
   if (sel && sel.kind === "object") { var ot = fvSelObjectTarget(P, sel); if (ot && ot.lookAt) return ot.lookAt.slice(); }
   return T;
}
// a que distancia se llega
function fvArriveDist(P, sel) {
   if (sel.arriveLy > 0) return sel.arriveLy;                                       // (N) el destino manda (contrato con C)
   if (sel.kind === "object") { var ot = fvSelObjectTarget(P, sel); if (ot && ot.arriveLy > 0) return ot.arriveLy; return 1; }
   if (sel.kind === "star") {
      var S = P.scene.stars, g = S.g[sel.i], d0 = S.dEarth[sel.i];
      var d = d0 * Math.pow(10, (FV_PILOT.ARRIVE_MAG - g) / 5);
      return fvClamp(d, FV_PILOT.ARRIVE_MIN, Math.min(FV_PILOT.ARRIVE_MAX, 0.5 * d0));
   }
   if (sel.kind === "nebula") {
      // (19-nov, N6; FV_N6.DIST) la llegada de su fila principal (contorno entero, con S y a la izquierda de la ficha), no la de la foto ENTERA en 60° que no cuenta con S (fvSelPos: el mismo destino)
      var mN6 = (typeof FV_N6 !== "undefined" && FV_N6.DIST && typeof fvN6Main === "function") ? fvN6Main(P.scene) : -1;
      if (mN6 >= 0) { var otN = fvSelObjectTarget(P, { kind: "object", i: mN6 }); if (otN && otN.arriveLy > 0) return otN.arriveLy; }
      // sin fila principal con contorno (el protagonista es otro objeto): la lamina entera, pero con S (fvN6WholeDist, FV_N6.WHOLE)
      else if (typeof FV_N6 !== "undefined" && typeof fvN6WholeDist === "function") { var dW6 = fvN6WholeDist(P.scene); if (dW6 > 0) return dW6; }
      var n = P.scene.nebula, L = n.layers[0], halfW = (L.x1 - L.x0) / 2;
      return halfW / Math.tan(FV_PILOT.ARRIVE_FOV / 2) + n.thickLy / 2;          // la nebulosa llena la vista, delante de la primera capa
   }
   return 1;
}

// --- perfiles ---
// WARP (N6, el de TNG): { v (velocidad relativa), warp, trail (estela), flash, inhale, phase, end } en el instante t de un viaje con
// crucero `cruise` segundos. Fases: preparacion [0, PREP) · salto [PREP, PREP+JUMP) · crucero · salida EXIT.
// El pintor lee la fase de (warp, trail): en la preparacion trail > warp = 0 (temblor y estiramiento apenas); en la salida
// trail = warp^1,6 ≤ warp (las rayas se recogen antes de que la nave pare). Ver FVPainter.warpFx.
// (6-nov, FAST_EASE) kPh: las fases (no el crucero) × kPh (WARP_K × el regulador); 1 o nada = las de siempre (× 1 es exacto: lo de antes)
function fvWarpProfile(t, cruise, kPh) {
   // (§15, medido en las cabeceras de TNG y Voyager) orden: encarar + brillo (PREP) -> estiramiento (JUMP) -> PAUSA quieta (BREATH)
   // -> destello lejano en el punto de fuga mientras se entra en warp (FLASH_S, sube el 40 % y baja el 60 %) -> crucero -> salida
   var W0 = FV_PILOT.WARP, kp = (kPh > 0) ? kPh : 1, W = { PREP: W0.PREP * kp, GLOW: W0.GLOW * kp, JUMP: W0.JUMP * kp, BREATH: W0.BREATH * kp, FLASH_S: W0.FLASH_S * kp, EXIT: W0.EXIT * kp,
           EXIT_FLASH_S: W0.EXIT_FLASH_S * kp, EXIT_FLASH_K: W0.EXIT_FLASH_K, CREEP: W0.CREEP, STRETCH_V: W0.STRETCH_V, STRETCH_W: W0.STRETCH_W, STRETCH_TRAIL: W0.STRETCH_TRAIL,
           PREP_TRAIL: W0.PREP_TRAIL, FOV_BOUNCE: W0.FOV_BOUNCE, SHAKE_DEG: W0.SHAKE_DEG, EXIT_SHAKE_DEG: W0.EXIT_SHAKE_DEG, FLASH_EXP: W0.FLASH_EXP, FLASH_UP: W0.FLASH_UP, FLASH_UP2: W0.FLASH_UP2 };
   var tG = W.PREP - W.GLOW, tP = W.PREP, tS = tP + W.JUMP, tA = tS + W.BREATH, tF = tA + W.FLASH_S, tC = tF + cruise, tD = tC + W.EXIT;
   var v, w, tr, fl = 0, inh = 0, ph = "depart", wp, pt, bnc = 0, shk = 0, u;
   if (t < tP) { var a = t / tP; v = W.CREEP * fvSmooth(a); w = 0; tr = W.PREP_TRAIL * fvSmoother(fvClamp((t - tG) / W.GLOW, 0, 1)); inh = fvSmooth(a); wp = "prep"; pt = t; }
   else if (t < tS) { u = (t - tP) / W.JUMP; v = W.CREEP + (W.STRETCH_V - W.CREEP) * fvSmooth(u); w = W.STRETCH_W * fvSmoother(u); tr = W.PREP_TRAIL + (W.STRETCH_TRAIL - W.PREP_TRAIL) * fvSmoother(u); inh = 1; wp = "jump"; pt = t - tP; }
   else if (t < tA) { v = W.STRETCH_V; w = W.STRETCH_W; tr = W.STRETCH_TRAIL; inh = 1; wp = "breath"; pt = t - tS; }                // la pausa: todo quieto
   else if (t < tF) {
      u = (t - tA) / W.FLASH_S;
      v = W.STRETCH_V + (1 - W.STRETCH_V) * u * u * u; w = W.STRETCH_W + (1 - W.STRETCH_W) * fvSmoother(u);
      tr = W.STRETCH_TRAIL + (1 - W.STRETCH_TRAIL) * fvSmooth(1.6 * u); inh = 1 - fvSmooth(2 * u); wp = "flash"; pt = t - tA;
   }
   else if (t < tC) { v = 1; w = 1; tr = 1; ph = "cruise"; wp = "cruise"; pt = t - tF; shk = W.SHAKE_DEG; }
   else if (t < tD) {
      var b = (t - tC) / W.EXIT; v = (1 - b) * (1 - b) * (1 - b); w = 1 - fvSmooth(b / 0.6); tr = Math.pow(w, 1.6);   // frenazo; las rayas se recogen
      bnc = W.FOV_BOUNCE * Math.sin(Math.PI * fvClamp((b - 0.45) / 0.55, 0, 1));                                       // el campo se pasa un 3 % y vuelve
      shk = W.EXIT_SHAKE_DEG * Math.exp(-(t - tC) / (0.25 * kp)) + W.SHAKE_DEG * w;
      ph = "arrive"; wp = "exit"; pt = t - tC;
   }
   else { v = 0; w = 0; tr = 0; ph = "arrive"; wp = "exit"; pt = t - tC; }
   // dos destellos: el de entrada (FLASH_S) y uno menor al salir (EXIT_FLASH_S × EXIT_FLASH_K). Forma medida: sube el 40 %, baja el 60 %
   // (B2, Nino: «el destello poco natural») con FLASH_EXP > 0: subida rapida (FLASH_UP del tiempo) y bajada EXPONENCIAL (constante 1/FLASH_EXP
   // del resto) que llega a 0 justo al final (misma duracion FLASH_S de §15). FLASH_EXP 0 = sube 40 % / baja 60 % con smoothstep (ROJO)
   var EX = W.FLASH_EXP || 0, eEnd = EX > 0 ? Math.exp(-EX) : 0, up = EX > 0 ? W.FLASH_UP2 : W.FLASH_UP;
   function bump(x) {
      if (x < 0 || x >= 1) return 0;
      if (x < up) return fvSmooth(x / up);
      return EX > 0 ? (Math.exp(-EX * (x - up) / (1 - up)) - eEnd) / (1 - eEnd) : 1 - fvSmooth((x - up) / (1 - up));
   }
   fl = Math.max(bump((t - tA) / W.FLASH_S), W.EXIT_FLASH_K * bump((t - tC) / W.EXIT_FLASH_S));
   // phaseDur: lo que dura la fase en que se esta (para el visor web, fwWarpPhase: con FAST_EASE las fases ya no son las de la tabla)
   var pd = wp === "prep" ? W.PREP : (wp === "jump" ? W.JUMP : (wp === "breath" ? W.BREATH : (wp === "flash" ? W.FLASH_S : (wp === "cruise" ? cruise : W.EXIT))));
   return { v: v, warp: fvClamp(w, 0, 1), trail: fvClamp(tr, 0, 1), flash: fl, inhale: inh, phase: ph, warpPhase: wp, phaseT: pt, phaseDur: pd, bounce: bnc, shakeDeg: shk, end: tD + 0.15 * kp };
}
// (N5) CINE: velocidad relativa en la fraccion de tiempo u (arranque sin tiron, crucero, frenada gaussiana larga hasta CINE_VEND)
function fvCineVel(u) {
   var A = FV_PILOT.CINE_ACC, B = FV_PILOT.CINE_BRAKE, k = FV_PILOT.CINE_BRAKE_K, ve = FV_PILOT.CINE_VEND;
   u = fvClamp(u, 0, 1);
   // (6-nov, FAST_EASE) arranque smootherstep hasta FAST.ACC, crucero y frenada smootherstep desde FAST.BRAKE HASTA 0 (sin cola gaussiana
   // ni velocidad residual: la aceleracion es continua de punta a punta y no hay parada en seco)
   if (fvFastOn()) { var FA = FV_PILOT.FAST; if (u < FA.ACC) return fvSmoother(u / FA.ACC); if (u < FA.BRAKE) return 1; return 1 - fvSmoother((u - FA.BRAKE) / (1 - FA.BRAKE)); }
   if (u < A) return fvSmoother(u / A);
   if (u < B) return 1;
   var w = (u - B) / (1 - B), g = (Math.exp(-k * w * w) - Math.exp(-k)) / (1 - Math.exp(-k));
   return ve + (1 - ve) * g;
}
// la tabla del avance del cine: x(u) = ∫v / ∫v total (x es la fraccion de tau del camino)
function fvCineKey() { var k = FV_PILOT.CINE_ACC + ":" + FV_PILOT.CINE_BRAKE + ":" + FV_PILOT.CINE_BRAKE_K + ":" + FV_PILOT.CINE_VEND; return fvFastOn() ? k + ":F" + FV_PILOT.FAST.ACC + ":" + FV_PILOT.FAST.BRAKE : k; }
function fvCineTable() {
   if (FV_CINE_TAB && FV_CINE_TAB.key === fvCineKey()) return FV_CINE_TAB;
   var N = 600, acc = new Float64Array(N + 1), s = 0;
   for (var i = 1; i <= N; ++i) { s += fvCineVel((i - 0.5) / N) / N; acc[i] = s; }
   for (i = 1; i <= N; ++i) acc[i] /= s;
   FV_CINE_TAB = { N: N, acc: acc, mean: s, key: fvCineKey() };
   return FV_CINE_TAB;
}
var FV_CINE_TAB = null;
function fvCineX(u) {
   var T = fvCineTable();
   if (u <= 0) return 0; if (u >= 1) return 1;
   var x = u * T.N, i = Math.floor(x), f = x - i;
   return T.acc[i] + (T.acc[Math.min(T.N, i + 1)] - T.acc[i]) * f;
}
// (E) la mirada desviada `off` radianes a la DERECHA (alrededor del «abajo» de la camara: sin alabeo) -> el objeto de `dir` queda a la izquierda
// Se resuelve en la PANTALLA (4 iteraciones): el objeto debe proyectarse en (−tan off, 0) de la base sin alabeo. Girar alrededor del
// «abajo» de la camara no basta: al rehacer la base con el abajo del mundo, el objeto subia ~6 px si la mirada estaba inclinada.
function fvFrameDir(dir, off) {
   if (!off) return dir;
   var t = fvNorm(dir), f = fvNorm(fvRotate(t, fvBasis(t).d, off)), want = -Math.tan(off);
   for (var k = 0; k < 4; ++k) {
      var B = fvBasis(f), z = fvDot(t, B.f), ex = fvDot(t, B.r) / z - want, ey = fvDot(t, B.d) / z, yp = fvYawPitchOf(f);
      f = fvDirYawPitch(yp.yaw + Math.atan(ex), yp.pitch - Math.atan(ey));
   }
   return f;
}
// cuantos pixeles a la izquierda del centro queda el objeto al llegar con el encuadre del tercio (para las pruebas y para A: la ficha)
// (B2) con el campo que haya al llegar (el avance del cine puede llegar con menos de ARRIVE_FOV en un viaje corto); fuera de un viaje
// de cine recien llegado, el de llegada
function fvArriveFrameDx(P) { var F = (P.cam && P.cam.fov > 0 && P.cam.fov <= FV_PILOT.ARRIVE_FOV + 1e-9 && P.mode !== "home") ? P.cam.fov : FV_PILOT.ARRIVE_FOV, off = FV_PILOT.FRAME_THIRD * F, f = (P.VW / 2) / Math.tan(F / 2); return f * Math.tan(off); }
// (E) vibracion: la mirada movida `amp` radianes con dos senos de 11 y 13,7 Hz (guiñada y cabeceo desfasados); no se acumula
function fvLookJitter(dir, amp, t) {
   var yp = fvYawPitchOf(dir);
   return fvDirYawPitch(yp.yaw + amp * (0.6 * Math.sin(2 * Math.PI * 11 * t) + 0.4 * Math.sin(2 * Math.PI * 13.7 * t + 1.3)), yp.pitch + amp * (0.6 * Math.sin(2 * Math.PI * 12.3 * t + 0.7) + 0.4 * Math.sin(2 * Math.PI * 9.1 * t + 2.1)));
}
// (E) la DERIVA VIVA en reposo: desplazamiento (guiñada, cabeceo) en radianes en el instante t
function fvLiveDriftAt(t) {
   var D = FV_PILOT.LIVE_DRIFT, k = FV_DEG;
   return [k * (D[0] * Math.sin(2 * Math.PI * t / D[1]) + D[2] * Math.sin(2 * Math.PI * t / D[3] + 1.1)),
           0.5 * k * (D[0] * Math.sin(2 * Math.PI * t / D[1] + 2.0) + D[2] * Math.sin(2 * Math.PI * t / D[3] + 0.4))];
}
// la fase de un vuelo en la fraccion de tiempo u (para los que no son warp)
function fvFlightPhaseU(kind, u) {
   if (kind === "cine") { var FA = fvFastOn() ? FV_PILOT.FAST : null, cA = FA ? FA.ACC : FV_PILOT.CINE_ACC, cB = FA ? FA.BRAKE : FV_PILOT.CINE_BRAKE; return (u < cA) ? "depart" : (u < cB ? "cruise" : "arrive"); }
   return (u < 0.25) ? "depart" : (u < 0.75 ? "cruise" : "arrive");
}
// (F1) avance s(u) simetrico con rampa exponencial: se conserva para quien lo use
function fvGotoEase(u, k) {
   k = k || 7; u = fvClamp(u, 0, 1);
   var e = Math.expm1(k);
   return (u < 0.5) ? 0.5 * Math.expm1(2 * k * u) / e : 1 - 0.5 * Math.expm1(2 * k * (1 - u)) / e;
}
// tabla del avance del warp: la integral normalizada de la velocidad (con el rebote, pasa un poco de 1 y vuelve)
function fvWarpTable(cruise, kPh) {
   var e = fvWarpProfile(0, cruise, kPh).end, N = 400, acc = [0], s = 0, dt = e / N;
   for (var i = 1; i <= N; ++i) { s += Math.max(-1, fvWarpProfile((i - 0.5) * dt, cruise, kPh).v) * dt; acc.push(s); }
   return { end: e, N: N, dt: dt, acc: acc, total: acc[N], cruise: cruise, kPh: (kPh > 0) ? kPh : 1 };
}
function fvWarpS(tab, t) {
   if (t <= 0) return 0; if (t >= tab.end) return 1;
   var x = t / tab.dt, i = Math.floor(x), f = x - i;
   return (tab.acc[i] + (tab.acc[Math.min(tab.N, i + 1)] - tab.acc[i]) * f) / tab.total;
}

// ---------------------------------------------------------------------------
// EL CAMINO (F2): spline centripeta por los puntos de control, recorrida con velocidad ∝ ESCALA = distancia al foco mas cercano
// (el objeto de salida o el de llegada; idea de OpenSpace). tau(s) = ∫ ds / escala, normalizada: el reloj del viaje avanza en tau.
// foci: [[x,y,z]…]; minScale: suelo de la escala (la Tierra es un punto: sin suelo, salir de ella costaria un tiempo infinito).
// -> { at(x): punto para tau x ∈ [0, 1] (x > 1: el rebote, sigue la tangente final), length, ctrl }
// ---------------------------------------------------------------------------
function fvPathScale(q, foci, minScale) {
   var best = 1e30;
   for (var i = 0; i < foci.length; ++i) { var d = fvLen(fvSub(q, foci[i])); if (d < best) best = d; }
   return Math.max(minScale, best);
}
// vary (opcional, §15 «ritmo variable»): { lo, hi, near, far } -> el peso de cada tramo en tau se multiplica por mix(near, far, f), con f
// = smooth((ln escala − lo) / (hi − lo)): cerca de algo (escala pequeña) se pasa mas tiempo, en el vacio menos.
function fvPathMake(ctrl, foci, minScale, vary) {
   // (la escala SUAVE, (Σ d⁻²)^(−1/2): con el minimo de las distancias la velocidad percibida tenia un pico en punta a mitad de viaje)
   function gw(q) {
      if (!vary) return 1;
      var sInv = 0; for (var fi = 0; fi < foci.length; ++fi) { var dd = fvLen(fvSub(q, foci[fi])); sInv += 1 / Math.max(1e-30, dd * dd); }
      var sc = Math.max(minScale, 1 / Math.sqrt(sInv));
      return fvMix(vary.near, vary.far, fvSmooth((Math.log(sc) - vary.lo) / (vary.hi - vary.lo)));
   }
   // (N5) tabla ADAPTATIVA: el paso en arco es el menor entre 1/NMIN del camino y STEP_K × la escala local. Con 400 nodos uniformes
   // (F2–F4b) cerca de la Tierra cada nodo abarcaba ~4 % del viaje en tau y el arco de la grua (30 a.l. de 6 000) caia en pocos nodos: la
   // velocidad daba escalones en los nodos (tirones medidos en tests/fv_nB_engine_node.js N5b). Unos 1 500–3 000 nodos, una vez por viaje.
   // El arco se mide con la CUERDA real entre muestras de spl.at (no du·L): la tabla de longitud de arco de fvSplineMake (256 muestras,
   // fv_math.js) reparte mal el arco dentro de sus nodos y la velocidad daba dientes de sierra de ~15 % cada 0,35 s en la llegada.
   var spl = fvSplineMake(ctrl), L = Math.max(1e-12, spl.length), NMIN = 1000, STEP_K = 0.02, U = [0], TAU = [0], u = 0, acc = 0, guard = 0, q0 = spl.at(0);
   while (u < 1 && guard < 20000) {
      var sc = fvPathScale(q0, foci, minScale), du = Math.min(1 / NMIN, STEP_K * sc / L, 1 - u);
      var q1 = spl.at(u + du), scm = fvPathScale(fvLerp(q0, q1, 0.5), foci, minScale);
      acc += fvLen(fvSub(q1, q0)) / scm * gw(fvLerp(q0, q1, 0.5)); u += du; U.push(u); TAU.push(acc); q0 = q1; ++guard;
   }
   var N = U.length - 1, i;
   for (i = 1; i <= N; ++i) TAU[i] /= acc;
   var pEnd = spl.at(1), pPre = spl.at(U[N - 1]), dsdtEnd = (1 - U[N - 1]) / Math.max(1e-12, TAU[N] - TAU[N - 1]);   // arco (normalizado) por unidad de tau al final
   var tanEnd = fvMul(fvSub(pEnd, pPre), 1 / Math.max(1e-12, 1 - U[N - 1]));                                        // derivada del punto respecto al arco normalizado
   function look(x) { var lo = 0, hi = N; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (TAU[m] < x) lo = m; else hi = m; } return U[lo] + ((TAU[hi] > TAU[lo]) ? (x - TAU[lo]) / (TAU[hi] - TAU[lo]) : 0) * (U[hi] - U[lo]); }
   return { length: spl.length, ctrl: ctrl, N: N, tau: TAU,
            at: function(x) {
               if (x <= 0) return spl.at(0);
               if (x >= 1) return (x === 1) ? pEnd : fvAdd(pEnd, fvMul(tanEnd, (x - 1) * dsdtEnd));
               return spl.at(look(x));
            },
            sOf: function(x) {            // el avance en ARCO (0..1) que corresponde a tau x (para el giro de la mirada)
               if (x <= 0) return 0; if (x >= 1) return 1;
               return look(x);
            } };
}
// la estrella que el camino «atraviesa»: la de menor (distancia al camino / radio de peligro) por debajo de 1. skip: {i: true}
// (N, encargo B, 4-nov) BARATO: medido por D en el visor, la version de fuerza bruta (fvPathOffenderRef, abajo) tardaba 38 ms con 22 000
// estrellas al arrancar CADA viaje. Esta da EXACTAMENTE el mismo resultado (mismo orden de recorrido, misma comparacion estricta) pero
// descarta antes de calcular: cada tramo tiene una caja (sus dos extremos ± el radio de peligro maximo del tramo) y una estrella fuera
// de la caja no puede estar dentro del radio. Cota del radio: la escala es una distancia (1-lipschitziana), asi que en el tramo
// escala ≤ max(escala(a), escala(b)) + |ab| / 2. Ademas la escala se calcula sin crear arrays. Medida: tests/fv_nB_offender_node.js.
function fvPathOffender(P, ctrl, foci, minScale, skip, zoneR, tubeT) {
   var S = P.scene.stars;
   if (!S) return null;
   var zr2 = zoneR > 0 ? zoneR * zoneR : 0, tT = tubeT > 0 ? tubeT : 0, tK = FV_PILOT.AVOID_TUBE_K;   // (B2) dentro del tubo, radio × AVOID_TUBE_K
   var spl = fvSplineMake(ctrl), M = 48, K = FV_PILOT.AVOID_K, nf = foci.length, i, k, f;
   var PX = [], PY = [], PZ = [], X0 = [], X1 = [], Y0 = [], Y1 = [], Z0 = [], Z1 = [];
   for (k = 0; k <= M; ++k) { var p = spl.at(k / M); PX.push(p[0]); PY.push(p[1]); PZ.push(p[2]); }
   var gx0 = 1e300, gx1 = -1e300, gy0 = 1e300, gy1 = -1e300, gz0 = 1e300, gz1 = -1e300;
   for (k = 1; k < M; ++k) {
      var ax = PX[k - 1], ay = PY[k - 1], az = PZ[k - 1], bx = PX[k], by = PY[k], bz = PZ[k];
      var sa = fvPathScale([ax, ay, az], foci, minScale), sb = fvPathScale([bx, by, bz], foci, minScale);
      var rm = K * (Math.max(sa, sb) + 0.5 * Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay) + (bz - az) * (bz - az))) * (1 + 1e-9) + 1e-12;
      X0[k] = Math.min(ax, bx) - rm; X1[k] = Math.max(ax, bx) + rm; Y0[k] = Math.min(ay, by) - rm; Y1[k] = Math.max(ay, by) + rm;
      Z0[k] = Math.min(az, bz) - rm; Z1[k] = Math.max(az, bz) + rm;
      if (X0[k] < gx0) gx0 = X0[k]; if (X1[k] > gx1) gx1 = X1[k]; if (Y0[k] < gy0) gy0 = Y0[k]; if (Y1[k] > gy1) gy1 = Y1[k];
      if (Z0[k] < gz0) gz0 = Z0[k]; if (Z1[k] > gz1) gz1 = Z1[k];
   }
   var worst = null, wr = 1, SX = S.x, SY = S.y, SZ = S.z;
   for (i = 0; i < S.n; ++i) {
      var sx = SX[i], sy = SY[i], sz = SZ[i];
      if (sx < gx0 || sx > gx1 || sy < gy0 || sy > gy1 || sz < gz0 || sz > gz1) continue;
      if (skip[i]) continue;
      for (k = 1; k < M; ++k) {                 // (los extremos no: ahi estan la salida y la llegada)
         if (sz < Z0[k] || sz > Z1[k] || sx < X0[k] || sx > X1[k] || sy < Y0[k] || sy > Y1[k]) continue;
         var a0 = PX[k - 1], a1 = PY[k - 1], a2 = PZ[k - 1], abx = PX[k] - a0, aby = PY[k] - a1, abz = PZ[k] - a2, L2 = abx * abx + aby * aby + abz * abz;
         var t = L2 > 0 ? ((sx - a0) * abx + (sy - a1) * aby + (sz - a2) * abz) / L2 : 0; t = t < 0 ? 0 : (t > 1 ? 1 : t);
         var qx = a0 + abx * t, qy = a1 + aby * t, qz = a2 + abz * t, dx = sx - qx, dy = sy - qy, dz = sz - qz, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
         if (zr2 > 0 && qx * qx + qy * qy + qz * qz < zr2) continue;      // (zona de la foto: ver fvPilotFly)
         var best = 1e30;
         for (f = 0; f < nf; ++f) { var F = foci[f], ex = qx - F[0], ey = qy - F[1], ez = qz - F[2], e = Math.sqrt(ex * ex + ey * ey + ez * ez); if (e < best) best = e; }
         var r = K * Math.max(minScale, best), inT = tT > 0 && qz > 0 && qx * qx + qy * qy < qz * qz * tT * tT;
         if (inT) r *= tK;
         if (d < r * wr) { wr = d / r; worst = { i: i, q: [qx, qy, qz], d: d, r: r, seg: k / M, tube: inT }; }
      }
   }
   return worst;
}
// la version de fuerza bruta de F2–F4b, SOLO como referencia para las pruebas (tests/fv_nB_offender_node.js compara las dos)
function fvPathOffenderRef(P, ctrl, foci, minScale, skip, zoneR, tubeT) {
   var zr2 = zoneR > 0 ? zoneR * zoneR : 0, tT = tubeT > 0 ? tubeT : 0;
   var S = P.scene.stars;
   if (!S) return null;
   var spl = fvSplineMake(ctrl), M = 48, pts = [], i, k;
   for (k = 0; k <= M; ++k) pts.push(spl.at(k / M));
   var worst = null, wr = 1;
   for (i = 0; i < S.n; ++i) {
      if (skip[i]) continue;
      var sx = S.x[i], sy = S.y[i], sz = S.z[i];
      for (k = 1; k < M; ++k) {                 // (los extremos no: ahi estan la salida y la llegada)
         var a = pts[k - 1], b = pts[k], abx = b[0] - a[0], aby = b[1] - a[1], abz = b[2] - a[2], L2 = abx * abx + aby * aby + abz * abz;
         var t = L2 > 0 ? ((sx - a[0]) * abx + (sy - a[1]) * aby + (sz - a[2]) * abz) / L2 : 0; t = t < 0 ? 0 : (t > 1 ? 1 : t);
         var qx = a[0] + abx * t, qy = a[1] + aby * t, qz = a[2] + abz * t, dx = sx - qx, dy = sy - qy, dz = sz - qz, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
         if (zr2 > 0 && qx * qx + qy * qy + qz * qz < zr2) continue;
         var r = FV_PILOT.AVOID_K * fvPathScale([qx, qy, qz], foci, minScale), inT = tT > 0 && qz > 0 && qx * qx + qy * qy < qz * qz * tT * tT;
         if (inT) r *= FV_PILOT.AVOID_TUBE_K;
         if (d < r * wr) { wr = d / r; worst = { i: i, q: [qx, qy, qz], d: d, r: r, seg: k / M, tube: inT }; }
      }
   }
   return worst;
}
// inserta un punto de control (en el lugar que le toca por su posicion a lo largo del camino)
function fvCtrlInsert(ctrl, p, sAlong) {
   // por proyeccion: el primer punto de control cuya posicion a lo largo de la cuerda supera a p (sAlong: no hace falta)
   var n = ctrl.length, at, a = ctrl[0], b = ctrl[n - 1], ab = fvSub(b, a), L2 = fvDot(ab, ab), sp = L2 > 0 ? fvDot(fvSub(p, a), ab) / L2 : 0.5;
   for (at = 1; at < n - 1; ++at) if (L2 > 0 && fvDot(fvSub(ctrl[at], a), ab) / L2 > sp) break;
   ctrl.splice(at, 0, p);
   return ctrl;
}

// (4.ª corrida) ESCALERA: la spline centripeta dobla de golpe en un nudo cuyos dos tramos miden muy distinto (357 y 17 a.l. -> en un
// fotograma la camara cambiaba de rumbo: la velocidad caia un 70 % y volvia, tiron 0,77 en N5b). Mientras haya dos tramos vecinos con
// razon > EVEN_RATIO se parte el largo con un punto en su recta a 2 × el corto del nudo comun: los tramos crecen en progresion.
function fvCtrlEven(ctrl) {
   var R = FV_PILOT.EVEN_RATIO, added = 0;
   for (var guard = 0; guard < FV_PILOT.EVEN_MAX; ++guard) {
      var done = true;
      for (var k = 1; k < ctrl.length - 1; ++k) {
         var a = fvLen(fvSub(ctrl[k], ctrl[k - 1])), b = fvLen(fvSub(ctrl[k + 1], ctrl[k]));
         if (a > R * b && b > 0) { ctrl.splice(k, 0, fvAdd(ctrl[k], fvMul(fvNorm(fvSub(ctrl[k - 1], ctrl[k])), 2 * b))); done = false; ++added; break; }
         if (b > R * a && a > 0) { ctrl.splice(k + 1, 0, fvAdd(ctrl[k], fvMul(fvNorm(fvSub(ctrl[k + 1], ctrl[k])), 2 * a))); done = false; ++added; break; }
      }
      if (done) break;
   }
   return added;
}
// --- arrancar vuelos ---
// kind: "travel" (con el estilo del piloto), "warp" (espectacular), "goto" | "cine" (suave), "home"
function fvPilotFly(P, kind, sel) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabFly(P, kind, sel);           // (8-nov, LABORATORIO DE VUELO, src/engine/fv_flightlab.js)
   var gwFl = false;
   if (kind === "travel") { kind = fvTravelKind(P, sel, true); gwFl = (P.gwNow === true); P.gwNow = false; }      // (21-nov, N-galaxias-warp) el destino elige el modo (en el clasico, con FV_GWARP.CLASSIC, R8)
   if (kind === "goto") kind = "cine";
   var cam = P.cam, T = fvSelPos(P, sel);
   if (!T && kind !== "home") return false;
   // (nQ) un destino sin posicion valida (indice fuera de la escena: NaN) no arranca: antes el plan pedia un array de longitud NaN
   // (RangeError en fvRoutePlan) a mitad del primer paso
   if (T && kind !== "home" && !(isFinite(T[0]) && isFinite(T[1]) && isFinite(T[2]))) return false;
   P.coast = null; fvFreeHalt(P); P.brake = null;
   // (7-nov, Nino: «salto con fundido») a casa desde el ESPACIO: fundido dorado, salto a la pose de casa y fundido de vuelta (fvNmJumpStep)
   if (kind === "home" && fvNmJumpWanted(P)) { fvNmJumpStart(P); return true; }
   // (LOS DOS MODOS, D1; con HOME_JUMP false) la vuelta a casa desde detras de la nebulosa RODEA la losa (nunca la cruza)
   if (kind === "home" && !FV_NAV_MODES.HOME_JUMP && fvNmHomeAround(P)) return true;
   // (LOS DOS MODOS) a algo cuya llegada cae DENTRO de la losa o DETRAS de la nebulosa se va en ESPACIO (salvo el tour a lo de detras: se
   // mira a traves de la nebulosa desde Foto); desde el Espacio, a casa o a algo de delante se vuelve a Foto al llegar (fvNmStep: P.navPending)
   if (fvNmOn() && P.scene && P.scene.nebula) {
      P.navOrbit = false;
      var pastT = (kind !== "home") && fvNmPast(P, T), behindT = pastT && fvNmBehind(P, T), stayT = behindT && P.navStayFoto && FV_NAV_MODES.TOUR_STAYS;
      P.navReturn = null;
      if (pastT && !stayT) { if (P.navMode !== "space") { P.navMode = "space"; P.navEnterT = P.t; P.keepIn = null; } P.navPending = null; }
      else if (P.navMode === "space") P.navPending = "photo";
      // el tour a algo de detras: se mira A TRAVES de la foto desde la linea de vision Tierra -> destino (fvNmTourStay), no desde el punto
      // valido mas cercano a la llegada de siempre (a miles de a.l.: quedaba en una esquina de la piramide pegada a la losa, la estrella
      // fuera de la pantalla y la foto ampliada hasta ser un borron; fv_nav_fix_cdp N1 parada 3, montaje_dos_modos fila 7)
      if (stayT && fvNmTourStay(P, sel, T)) return true;
   }
   var fl = { kind: kind, t: 0, sel: sel, p0: cam.pos.slice(), look0: cam.look.slice(), fov0: cam.fov, pre: 0, flyby: -1, phase: "depart" };
   if (gwFl) fl.gw = true;      // (21-nov, N-galaxias-warp) el warp corto de una galaxia (el planificador clasico no usa el presupuesto: solo la marca)
   var skip = {}, startF = [0, 0, 0], atEarth = fvLen(cam.pos) < 1e-6;
   if (sel && sel.kind === "star") skip[sel.i] = true;
   if (P.arrivedAt && P.arrivedAt.kind === "star") skip[P.arrivedAt.i] = true;
   if (!atEarth) { var pa = P.arrivedAt ? fvSelPos(P, P.arrivedAt) : null; startF = pa || fvNearestPoint(P, cam.pos); }
   // (RUTA) la ley nueva del cine y de la vuelta a casa (FV_PILOT.ROUTE.CINE / HOME; false = lo de abajo, la ley de B2 = ROJO)
   if ((kind === "cine" && FV_PILOT.ROUTE.CINE) || (kind === "home" && FV_PILOT.ROUTE.HOME)) fvRouteSetup(P, fl, sel, startF, skip);
   else if (kind === "home") {
      fl.T = [0, 0, 0]; fl.p1 = [0, 0, 0]; fl.look1 = [0, 0, 1]; fl.fov1 = P.homeFov; fl.dur = FV_PILOT.HOME_S; fl.travelS = FV_PILOT.HOME_S; fl.closeS = 0;
      if ((FV_PILOT.CINE_REVEAL || FV_PILOT.HOME_ADVANCE) && fl.fov0 > 1.05 * P.homeFov) {          // (5.ª corrida) cerrar el campo ya en la Tierra, despues del viaje
         fl.closeS = fvClamp(FV_PILOT.HOME_CLOSE_DEC * Math.log(fl.fov0 / P.homeFov) / Math.LN10, 1.0, FV_PILOT.HOME_CLOSE_MAX); fl.dur = fl.travelS + fl.closeS;
      }
      // (B2) en UN gesto: el viaje ocupa toda la duracion y el campo se cierra mientras se vuelve (con el tope de la foto en el paso)
      if (FV_PILOT.HOME_ADVANCE) { fl.adv = true; fl.travelS = fl.dur; fl.zoneH = FV_PILOT.PHOTO_CAP1 * fvPhotoFadeK() * (P.scene.nebula ? P.scene.nebula.distLy : 1000); }
      var dH = fvLen(cam.pos);
      fl.path = fvPathMake([fl.p0, fl.p1], [startF, [0, 0, 0]], Math.max(1e-6, 0.004 * dH));
   } else {
      var dir = fvNorm(fvSub(T, cam.pos)), dA = fvArriveDist(P, sel), dist = fvLen(fvSub(T, cam.pos));
      if (typeof fvBoxArrive === "function") dA = fvBoxArrive(P, sel, T, dA);       // (14-nov, A) destino mas alla de la boca: se llega a la boca
      fl.T = T; fl.p1 = fvSub(T, fvMul(dir, dA)); fl.look1 = dir; fl.fov1 = FV_PILOT.ARRIVE_FOV; fl.arrive = dA;
      fl.Tlook = fvSelLookAt(P, sel, T);
      if (fl.Tlook !== T) fl.look1 = fvNorm(fvSub(fl.Tlook, fl.p1));
      // (6-nov, KEEP_IN.WARP_SIGHT) el warp que llegaria mirando FUERA de la foto (de lejos a cerca: por detras de la estrella, mirando a la
      // Tierra) llega por el lado de la Tierra, en la linea de vision del destino: la estrella delante y la foto detras
      if (kind === "warp" && fvKeepOn() && FV_PILOT.KEEP_IN.WARP_SIGHT && P.scene.nebula && !(fvNmOn() ? fvNmBehind(P, T) : fvKeepBeyond(P, T)) && !fvKeepOkAt(P, fl.p1, fl.look1)) {
         var ThW = fvSightDir(T);
         if (ThW) { fl.p1 = fvSub(T, fvMul(ThW, dA)); fl.look1 = fvNorm(fvSub(fl.Tlook, fl.p1)); fl.sightKeep = true; }
      }
      var minScale = Math.max(1e-4, 0.004 * dist), foci = [startF, T], ctrl, p0 = fl.p0;
      if (kind === "warp") {
         // efecto vertigo (E9): una sola vez por sesion, al fijar el primer objetivo
         fl.kPh = fvFastOn() ? FV_PILOT.FAST.WARP_K * fvSpeedDurK(P) : 1;          // (6-nov, FAST_EASE) las fases del salto × WARP_K × el regulador
         if (!P.dollyDone) { fl.pre = FV_PILOT.DOLLY_S * (fvFastOn() ? fl.kPh : 1); P.dollyDone = true; fl.dollyFrom = p0.slice(); fl.dollyDist = dist; fl.dollyDir = dir;
                             p0 = fvAdd(p0, fvMul(dir, dist * (1 - 1 / FV_PILOT.DOLLY_K))); fl.fovD = 2 * Math.atan(Math.tan(fl.fov0 / 2) * FV_PILOT.DOLLY_K); }
         fl.p0w = p0;
         ctrl = [p0, fl.p1];
         // (LLEGADA) sin PASO RASANTE si el destino cae en la parte limpia de la nebulosa (ROUTE.WARP_A_SLAB): el desvio (≈1 a.l. de lado a
         // 600–950 a.l.) giraba la mirada hasta sacar su eje de la parte limpia (eje a 31 a.l. del centro con 21,5 de margen); el tope A
         // llevaba el campo a 0,003° y se llegaba con 0,006° (tests/fv_llegada_node.js, estrella 4554). Como la grua del cine (fgFill)
         var fbOff = FV_PILOT.ROUTE.WARP && FV_PILOT.ROUTE.WARP_A_SLAB && P.scene.nebula && fvWarpCleanTarget(fvRouteGeo(P), fvSelLookAt(P, sel, T));
         // (nF2, E3 «nos seguimos yendo fuera del campo») tampoco con el destino en el BORDE de la foto (EDGE_WHOLE): el paso rasante apartaba la
         // camara de la recta Tierra-destino y, mirando al destino, el eje salia de la foto por detras de el (u −0,95 -> −1,17 en el crucero,
         // estrella 8528 de Collinder 34: 229 fotogramas con la pantalla entera fuera de la foto, fv_nF2_node warpB)
         if (!fbOff && FV_PILOT.ROUTE.WARP && FV_PILOT.ROUTE.EDGE_WHOLE && P.scene.nebula) {
            var Gw = fvRouteGeo(P), TLw = fvSelLookAt(P, sel, T);
            fbOff = TLw[2] > 0 && Math.abs(TLw[0] * Gw.D / TLw[2]) < Gw.HW && Math.abs(TLw[1] * Gw.D / TLw[2]) < Gw.HH;
         }
         // (6-nov, KEEP_IN.WARP_SIGHT) de lejos a cerca: la recta p0 -> llegada (en la linea de vision, lado de la Tierra) rozaria la estrella
         // (pasa a dA·lateral/distancia: ~0,05 a.l.); se pasa a su lado a 2·dA (punto a 3·dA hacia la Tierra y 2·dA de lado, hacia donde
         // se venia) y se sube a la llegada en la frenada del salto: una horquilla a poca velocidad. Sin paso rasante
         if (fl.sightKeep) {
            var ThS = fvSightDir(T), latS = fvSub(fvSub(p0, T), fvMul(ThS, fvDot(fvSub(p0, T), ThS)));
            latS = (fvLen(latS) > 1e-9) ? fvNorm(latS) : fvBasis(ThS).r;
            ctrl = [p0, fvAdd(fvSub(T, fvMul(ThS, 3 * dA)), fvMul(latS, 2 * dA)), fl.p1]; fbOff = true;
         }
         var fb = fbOff ? null : fvFlybyPoint(P, p0, fl.p1, foci, minScale, skip);
         fl.flybyOff = !!fbOff;
         if (fb) { fvCtrlInsert(ctrl, fb.p, fb.s); fl.flyby = fb.i; skip[fb.i] = true; }
         var WW = FV_PILOT.WARP;
         fl.cruise = fvClamp(WW.CRUISE_MIN + WW.CRUISE_DEC * Math.log(Math.max(1, dist / dA)) / Math.LN10, WW.CRUISE_MIN, WW.CRUISE_MAX) * fvSpeedDurK(P); fl.prof = fvWarpTable(fl.cruise, fl.kPh); fl.dur = fl.pre + fl.prof.end;   // (B2) el regulador cambia el crucero (y, con FAST_EASE, las fases: kPh)
         fl.speed = P.speed;
      } else {
         ctrl = [p0];
         // (N5) LA GRUA: el final rodea el objeto CRANE_DEG (eje casi vertical de la camara que se acerca, con algo de horizontal: gira y
         // sube un poco), entrando por un punto en la recta a CRANE_APP × dA y otro a mitad del arco. La llegada (p1) sigue a dA del objeto.
         var crane = (dist > FV_PILOT.CRANE_MIN * dA) ? FV_PILOT.CRANE_DEG * FV_DEG : 0, craneCtrl = [];
         // (B2) destino delante de la nebulosa con la nebulosa de fondo (fvFgFillTrip): sin grua — rodear 18° el destino deja la nebulosa
         // (a miles de a.l. detras) fuera de la vista; se llega por la linea de vision desde la Tierra
         fl.fgFill = fvFgFillTrip(P, T, fl.p0);
         if (fl.fgFill) crane = 0;
         if (crane > 0) {
            var Bc = fvBasis(dir), axC = fvNorm(fvAdd(fvMul(Bc.d, 1), fvMul(Bc.r, FV_PILOT.CRANE_TILT))), back = fvMul(dir, -1);
            var pA = fvAdd(T, fvMul(back, FV_PILOT.CRANE_APP * dA)), pM = fvAdd(T, fvMul(fvRotate(back, axC, crane / 2), 0.5 * (1 + FV_PILOT.CRANE_APP) * dA * 0.75));
            fl.p1 = fvAdd(T, fvMul(fvRotate(back, axC, crane), dA)); fl.look1 = fvNorm(fvSub(fl.Tlook, fl.p1));
            // (4.ª corrida) un escalon mas en la recta de entrada (a 5 × CRANE_APP × dA): un desvio inserto a cientos de a.l. justo antes
            // de pA (a 2,4 dA) dejaba tramos de 357 y 17 a.l. y la spline doblaba en pA en un fotograma (tiron 0,77 en N5b)
            var pB = fvAdd(T, fvMul(back, FV_PILOT.CRANE_LADDER * FV_PILOT.CRANE_APP * dA));
            craneCtrl = (dist > 2 * FV_PILOT.CRANE_LADDER * FV_PILOT.CRANE_APP * dA) ? [pB, pA, pM] : [pA, pM]; fl.crane = crane; fl.craneAxis = axC;
         }
         // WWT «sube – cruza – baja»: solo si salimos DE CERCA de un objeto hacia otro lejano (desde la Tierra ya se ve todo)
         var dS = atEarth ? 0 : fvLen(fvSub(p0, startF)), sepO = fvLen(fvSub(T, startF)), hTop = 0.7 * sepO;
         if (!atEarth && hTop > 2.5 * dS) {
            var mid = fvLerp(startF, T, 0.5), up = fvNorm(fvMul(mid, -1));                 // hacia la Tierra: fuera del campo, para ver los dos
            var ax = fvNorm(fvSub(T, startF)); up = fvNorm(fvSub(up, fvMul(ax, fvDot(up, ax))));   // perpendicular al viaje
            if (fvLen(up) < 1e-6) up = fvBasis(ax).d;
            ctrl.push(fvAdd(mid, fvMul(up, hTop))); fl.rise = hTop;
         }
         for (var cc = 0; cc < craneCtrl.length; ++cc) ctrl.push(craneCtrl[cc]);
         ctrl.push(fl.p1);
         // (4.ª corrida) ZONA DE LA FOTO: saliendo de casa, mientras se ve la foto (hasta PHOTO_CAP1 × PHOTO_FADE × D de la Tierra) no se
         // esquivan estrellas. Los desvios (a 3 radios = 0,18 × la distancia a la Tierra) sacaban la camara 19° del eje con la foto aun
         // al 50 %: la foto (un cono de ~1°) se veia por fuera, un rectangulo con su borde (nB_cine_tira.png col. 2). Mejor rozar una.
         var zoneR = (atEarth && FV_PILOT.AVOID_PHOTO_ZONE) ? FV_PILOT.PHOTO_CAP1 * fvPhotoFadeK() * (P.scene.nebula ? P.scene.nebula.distLy : 1000) : 0;
         // y la salida RECTA: un punto de control en la recta hacia el destino al final de la zona (los desvios de mas alla tiraban
         // del primer tramo de la spline y la camara salia 23° de lado; 4.ª corrida, C2)
         if (zoneR > 0 && dist > 4 * zoneR) { ctrl.splice(1, 0, fvAdd(p0, fvMul(dir, 1.3 * zoneR))); fl.straightOut = 1.3 * zoneR; }
         var tubeT = (atEarth && FV_PILOT.AVOID_TUBE) ? Math.tan(fvPhotoConeDeg(P) * FV_DEG) : 0;   // (B2) el tubo de la foto
         for (var it = 0; it < FV_PILOT.AVOID_ITERS; ++it) {             // no atravesar estrellas (OpenSpace: punto a 3 radios)
            var off = fvPathOffender(P, ctrl, foci, minScale, skip, zoneR, tubeT);
            if (!off) break;
            var away = fvSub(off.q, fvStarPos(P.scene, off.i)); if (fvLen(away) < 1e-9) away = fvBasis(fvSub(fl.p1, p0)).r;
            var pAv = fvAdd(fvStarPos(P.scene, off.i), fvMul(fvNorm(away), FV_PILOT.AVOID_PUSH * off.r));
            // (B2) el desvio no saca la camara del tubo (tampoco el de una estrella de fuera que la spline haya rozado al curvarse)
            if ((off.tube || (tubeT > 0 && Math.sqrt(T[0] * T[0] + T[1] * T[1]) < T[2] * tubeT)) && pAv[2] > 0) {
               var rT = FV_PILOT.TUBE_KEEP * pAv[2] * tubeT, lat = Math.sqrt(pAv[0] * pAv[0] + pAv[1] * pAv[1]);
               if (lat > rT) pAv = [pAv[0] * rT / lat, pAv[1] * rT / lat, pAv[2]];
            }
            // (B2, 2.ª corrida) destino delante con la nebulosa de fondo: lo que se ve DETRAS del destino se mueve en la nebulosa el
            // desvio × (D − zT) / (distancia al destino); a 400 a.l. de una estrella a 3 000, 10 a.l. de lado son 90 a.l. en la nebulosa
            // (fuera de su parte limpia: 7 % de pantalla sin nebulosa, fv_nB2_node). El desvio se acota a media holgura de ese fondo.
            if (fl.fgFill && pAv[2] > 0 && pAv[2] < T[2]) {
               var gF = fvFgRoom(P, T), sF = T[2] - pAv[2], oMax = 0.5 * gF * sF / Math.max(1e-9, P.scene.nebula.distLy - T[2]);
               var lx = pAv[0] - T[0] * pAv[2] / T[2], ly = pAv[1] - T[1] * pAv[2] / T[2], lo = Math.sqrt(lx * lx + ly * ly);
               if (lo > oMax) pAv = [T[0] * pAv[2] / T[2] + lx * oMax / lo, T[1] * pAv[2] / T[2] + ly * oMax / lo, pAv[2]];
            }
            fvCtrlInsert(ctrl, pAv, off.seg);
            skip[off.i] = true; fl.avoided = (fl.avoided || 0) + 1;
         }
         // (B2) dentro del tubo los desvios son casi colineales (pocos a.l. de lado en miles): la escalera metia nudos casi alineados en los
         // que la tabla de arco de la spline daba un tiron (0,18 en N5b de fv_nB_engine_node); sin ella, 0,04. Fuera del tubo, como antes.
         var tubeTrip = tubeT > 0 && Math.sqrt(T[0] * T[0] + T[1] * T[1]) < T[2] * tubeT;
         fl.tubeTrip = tubeTrip;
         if (FV_PILOT.EVEN_ON && !tubeTrip) fl.evened = fvCtrlEven(ctrl);
         fl.cinePre = FV_PILOT.CINE_PRE;
         if (FV_PILOT.CINE_ADVANCE) {
            // (B2) el avance que sale de la foto: beta del viaje para que tan(campo/2) llegue a la de llegada al CINE_BETA_AT de la escala
            // (log d0/dA); si el viaje es corto y ni con BETA_MAX llega, se llega con el campo que haya (fl.fov1 se fija al final)
            var dEnd = Math.max(1e-9, fvLen(fvSub(T, fl.p1))), avail = Math.log(Math.max(1.0001, dist / dEnd)), need = Math.log(Math.tan(fl.fov1 / 2) / Math.tan(fl.fov0 / 2));
            fl.adv = true; fl.dist0 = dist; fl.tan0 = Math.tan(fl.fov0 / 2);
            fl.beta = (need > 0) ? fvClamp(need / (FV_PILOT.CINE_BETA_AT * avail), FV_PILOT.CINE_BETA_MIN, FV_PILOT.CINE_BETA_MAX) : 0;
            fl.closeNeed = need < 0 ? -need : 0; fl.availLog = avail;     // si se sale con un campo MAYOR que el de llegada, se cierra con el avance
            // destino DENTRO o DETRAS de la nebulosa: la foto (luego las capas) llena la pantalla hasta entrar en la losa (A'); si esta
            // delante, solo mientras se pinta la foto (despues la nebulosa es, de verdad, un rectangulo al fondo)
            var Nb = P.scene.nebula; fl.slabZ = (Nb && T[2] >= Nb.distLy - Nb.thickLy / 2) ? Nb.distLy - Nb.thickLy / 2 : 0;
            // (B2, 2.ª corrida) destino DELANTE de la nebulosa, dentro de la foto y saliendo de la foto (casa o cerca): la nebulosa sigue
            // llenando la pantalla de fondo TODO el viaje (el campo no pasa de lo que cubre su parte limpia) y se llega con ese campo. Antes
            // el campo se abria a 60° al apagarse la foto y la nebulosa quedaba como un sello en el centro (nB2_cine_tira.png, 1.ª/2.ª
            // corrida, AHORA col. 5, estrella a 3 518 a.l.): la misma sensacion de «irse fuera» que la revelacion, solo que mas tarde.
            if (fl.fgFill) fl.slabZ = 1e30;
         } else if (FV_PILOT.CINE_REVEAL) {                                      // (5.ª corrida) la revelacion ocupa el plano quieto (y lo alarga si hace falta)
            fl.fovOpen = Math.max(FV_PILOT.CINE_FOV_OPEN, fl.fov1);
            fl.cinePre = fvClamp(FV_PILOT.REVEAL_DEC * Math.abs(Math.log(fl.fovOpen / fl.fov0)) / Math.LN10, FV_PILOT.CINE_PRE, FV_PILOT.REVEAL_MAX);
         }
         // (E) encuadre en el tercio: la mirada final se desvia a la derecha FRAME_THIRD × campo -> el objeto queda a la izquierda
         fl.frameOff = FV_PILOT.FRAME_THIRD * fl.fov1;
         fl.look1 = fvFrameDir(fvNorm(fvSub(fl.Tlook, fl.p1)), fl.frameOff);
         var spK = fvSpeedDurK(P), travelS = fvClamp(FV_PILOT.CINE_S_MIN + FV_PILOT.CINE_S_DEC * Math.log(Math.max(1, dist / dA)) / Math.LN10, FV_PILOT.CINE_S_MIN, FV_PILOT.CINE_S_MAX) * spK;   // (B2) × el regulador
         fl.speed = P.speed;
         // un giro grande alarga el viaje: el pico del smootherstep es 1,875 × angulo / ventana; se pide ≤ CINE_TURN_DPS (una vuelta de
         // 170° entre dos vecinas daba 32 °/s en 14 s; 2001/OpenSpace piden ≤ 8: inalcanzable sin viajes de un minuto, se toma 20)
         var turnDeg = fvAngle(fl.look0, fl.look1) / FV_DEG, needS = 1.875 * turnDeg / ((FV_PILOT.CINE_TURN1 - FV_PILOT.CINE_TURN0) * FV_PILOT.CINE_TURN_DPS);
         fl.turnDeg = turnDeg;
         fl.dur = fl.cinePre + Math.min(FV_PILOT.CINE_S_MAX * spK, Math.max(travelS, needS));
      }
      // (§15) ritmo variable solo en el cine: CINE_VARY = [cerca, vacio] (AMNH: ~30 s/decada cerca de la Tierra, 2–5 en el vacio; media 8,4)
      var vary = (kind === "cine" && FV_PILOT.CINE_VARY) ? { near: FV_PILOT.CINE_VARY[0], far: FV_PILOT.CINE_VARY[1], lo: Math.log(Math.max(minScale, FV_PILOT.CRANE_APP * dA)), hi: Math.log(Math.max(2 * minScale, 0.5 * dist)) } : null;
      if (vary && vary.hi <= vary.lo + 0.5) vary = null;
      fl.path = fvPathMake(ctrl, foci, minScale, vary);
   }
   P.flight = fl; P.orbit = null; P.mode = "flight"; P.sunMark = false;
   P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
   P.events.push({ t: P.t, what: "fly-" + kind });
   return true;
}
// el punto mas cercano de la escena a q (estrella o centro de la nebulosa) — el foco de salida si no se llego a nada
function fvNearestPoint(P, q) {
   var S = P.scene.stars, best = 1e30, bp = [0, 0, 0];
   if (S) for (var i = 0; i < S.n; ++i) { var dx = S.x[i] - q[0], dy = S.y[i] - q[1], dz = S.z[i] - q[2], d = dx * dx + dy * dy + dz * dz; if (d < best) { best = d; bp = [S.x[i], S.y[i], S.z[i]]; } }
   return bp;
}
// PASO RASANTE (E5): la estrella brillante (G < 14) mas a mano en el tramo central (25–75 %) del camino recto; se pasa a la distancia
// a la que brillaria como magnitud −2, acotada a 0,4–6 % de la escala local. -> { p (punto de control), s, i } | null
function fvFlybyPoint(P, a, b, foci, minScale, skip) {
   var S = P.scene.stars, ab = fvSub(b, a), L2 = fvDot(ab, ab), best = null, bs = 0.25;
   if (!S || L2 <= 0) return null;
   for (var i = 0; i < S.n; ++i) {
      if (skip[i] || S.g[i] > 14) continue;
      var p = [S.x[i], S.y[i], S.z[i]], t = fvDot(fvSub(p, a), ab) / L2;
      if (t < 0.25 || t > 0.75) continue;
      var q = fvAdd(a, fvMul(ab, t)), d = fvLen(fvSub(p, q)), sc = fvPathScale(q, foci, minScale), r = d / sc;
      if (r < bs) { bs = r; best = { i: i, q: q, d: d, sc: sc, t: t }; }
   }
   if (!best) return null;
   var g = S.g[best.i], dE = S.dEarth[best.i], dPass = dE * Math.pow(10, (FV_PILOT.FLYBY_MAG - g) / 5);
   dPass = fvClamp(dPass, FV_PILOT.FLYBY_MIN * best.sc, FV_PILOT.FLYBY_MAX * best.sc);
   var sp = fvStarPos(P.scene, best.i), side = fvSub(best.q, sp);
   if (fvLen(side) < 1e-9) side = fvBasis(ab).r;
   return { p: fvAdd(sp, fvMul(fvNorm(side), dPass)), s: best.t, i: best.i, dPass: dPass };
}

function fvPilotOrbit(P, sel) {
   var T = fvSelPos(P, sel || P.sel);
   if (!T) return false;
   var r = fvSub(P.cam.pos, T), up = [0, 1, 0], tiltAx = fvCross(up, fvNorm(r));
   if (fvLen(tiltAx) < 1e-6) tiltAx = [1, 0, 0];
   P.orbit = { P: T, r0: r, theta: 0, w: 0, t: 0, sel: sel || P.sel, tiltAx: fvNorm(tiltAx) };
   P.flight = null; P.mode = "orbit"; P.sunMark = false; P.coast = null; fvFreeHalt(P); P.brake = null;
   P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] };
   P.events.push({ t: P.t, what: "orbit" });
   return true;
}
function fvPilotStop(P) { P.flight = null; P.orbit = null; P.mode = "free"; P.coast = null; }
function fvPilotHomeNow(P) { P.navMode = "photo"; P.navPending = null; P.navReturn = null; P.navPrev = null; P.navOrbit = false; P.brake = null; P.flight = null; P.orbit = null; P.cam.pos = [0, 0, 0]; P.cam.look = [0, 0, 1]; P.cam.fov = P.homeFov; P.mode = "home"; P.warp = 0; P.flash = 0; P.trail = 0; P.arrivedAt = null; P.sunMark = false; P.coast = null; fvFreeHalt(P); }
// MIRAR A CASA (F2): girar la mirada hacia el Sol (la Tierra) desde donde se este, sin moverse. Desde la Tierra no hay giro posible.
function fvPilotLookHome(P) {
   var d = fvLen(P.cam.pos);
   if (d < 1e-6) return false;
   var fl = { kind: "look", t: 0, sel: null, p0: P.cam.pos.slice(), p1: P.cam.pos.slice(), look0: P.cam.look.slice(), look1: fvNorm(fvMul(P.cam.pos, -1)),
              fov0: P.cam.fov, fov1: Math.max(P.cam.fov, FV_PILOT.ARRIVE_FOV), dur: FV_PILOT.LOOKHOME_S[P.style] || 2.6, pre: 0, phase: "depart" };
   P.flight = fl; P.orbit = null; P.mode = "flight"; P.sunMark = true; P.coast = null; fvFreeHalt(P); P.brake = null;
   P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] };
   P.events.push({ t: P.t, what: "look-home" });
   return true;
}
// mirar alrededor (radianes de guiñada y cabeceo). (N10) Si habia un vuelo o una orbita, se toma el mando CON la inercia que llevaba
// (antes el vuelo se paraba en seco).
function fvPilotLook(P, dYaw, dPitch) {
   if (P.flight || P.orbit) fvFreeTakeControl(P);
   P.coast = null;
   P.cam.look = fvFreeTurn(P, dYaw, dPitch);
   if (P.mode === "home") P.mode = "free";
}
// (nF2) el tope A del VUELO LIBRE en (pos, look), en tan del medio campo: 1e9 = no aplica (sin nebulosa, ya en la losa, mirando de lado o
// hacia atras, A_GUARD apagado); ≤ 0: el eje ya cae fuera de la parte limpia
function fvFreeCapA(P, pos, look, withMargin) {
   if (!FV_PILOT.FREE.A_GUARD || !P.scene.nebula) return 1e9;
   var G = fvRouteGeo(P), lk = fvNorm(look);
   if (pos[2] >= G.zIn || !(lk[2] > 0.1)) return 1e9;
   // la parte limpia si FREE.CLEAN_CAP (la regla del campo del coordinador, 4-nov tarde); si no, la foto entera: asi cada mecanismo sigue
   // teniendo su propio control en rojo (R2/R3 de fv_nB2_node apagan CLEAN_CAP y miden sin el). SIN el margen A_MARGIN de la ruta: esto es
   // la pared (el limite exacto); el margen lo pone la regla del campo. Con el margen, la rueda en linea recta desde casa ya topaba (el
   // margen pasa de 1 a 0,97 antes de que la foto crezca un 3 %) y el campo se cerraba: R2 veia el 158 % del crecimiento real
   var c = fvRouteCover(P, G, pos, lk, !FV_PILOT.FREE.CLEAN_CAP);
   if (!(c > 0) || c >= 1e9 || withMargin) return c;
   return c / (1 - (1 - FV_PILOT.ROUTE.A_MARGIN) * fvSmooth(fvLen(pos) / (0.05 * G.fade)));
}
// (nF2, E3/E8) la mirada girada (guiñada, cabeceo) SIN salir de la foto: si el giro entero dejaria ver fuera (A), el mayor trozo que cabe;
// se prueba el giro entero y cada eje por separado (asi se desliza por el borde en vez de quedarse pegado). Si la mirada de partida ya
// incumplia (tras un vuelo que acabo de lado, por ejemplo), se deja girar mientras no empeore. -> la mirada nueva
function fvFreeTurn(P, dYaw, dPitch) {
   var look0 = P.cam.look, yp = fvYawPitchOf(look0);
   function rot(a, b) { return fvDirYawPitch(yp.yaw + a, fvClamp(yp.pitch + b, -85 * FV_DEG, 85 * FV_DEG)); }
   var full = rot(dYaw, dPitch);
   if (!FV_PILOT.FREE.A_GUARD || (!dYaw && !dPitch)) return full;
   // (desde donde no aplica —mirando atras tras «mirar a casa»— se puede volver hacia la foto: a partir de ahi, solo sin empeorar)
   // (2.ª corrida) el GIRO, CON el margen de la regla del campo (CLEAN_CAP): con el limite exacto, girar dejaba la mirada justo donde la regla
   // del campo (con margen) ya pedia cerrar; cerraba un 3 %, eso dejaba girar otro poco... trinquete: arrastre de 300 px a la deriva tras
   // soltar W -> campo de 0,70° a 0,11° en 1,5 s (un zoom ×6: «no solo gira sino que avanza mucho», E8)
   var tF = Math.tan(P.cam.fov / 2) * (1 - 1e-9), c0 = fvFreeCapA(P, P.cam.pos, look0, true), need = (c0 >= 1e9) ? -Infinity : ((c0 >= tF) ? tF : c0);
   function okL(l) { var c = fvFreeCapA(P, P.cam.pos, l, true); return c >= 1e9 || c >= need; }
   if (okL(full)) return full;
   var best = look0, bestA = 0, tries = [[dYaw, dPitch], [dYaw, 0], [0, dPitch]];
   for (var t = 0; t < tries.length; ++t) {
      var a = tries[t][0], b = tries[t][1];
      if (!a && !b) continue;
      var lo = 0, hi = 1;
      for (var it = 0; it < 24; ++it) { var m = 0.5 * (lo + hi); if (okL(rot(m * a, m * b))) lo = m; else hi = m; }
      if (lo > 0) { var cand = rot(lo * a, lo * b), ang = fvAngle(look0, cand); if (ang > bestA) { bestA = ang; best = cand; } }
   }
   return best;
}
// la rueda: muescas (+ adelante). (N10) Un IMPULSO que se desliza y se apaga (DAMP_S): cada muesca recorre ~WHEEL_FRAC de la distancia
// a lo mas cercano, como antes, pero flotando. Durante un vuelo no hace nada (como en F2).
// (N11, Nino: «un punto de rueda y toda la imagen se va para atras y aparece una bola») La «bola» era el CONO de estrellas Gaia de la
// foto (un circulo en el cielo) visto desde fuera: la rueda de F2 abria el campo de vision hacia 60° en cuanto la camara se movia
// (×7 por muesca: de 1,6° a ~11°), la foto se encogia al centro y alrededor salia el disco redondo del catalogo; hacia atras, ademas,
// la camara salia por detras de la Tierra. Ahora: (1) la muesca avanza WHEEL_FRAC de la distancia a LO QUE SE TIENE DELANTE (la
// estrella mas cercana dentro del campo, o la capa de nebulosa), deslizandose (DAMP_S), sin salto; (2) el campo de vision solo se abre
// con la DISTANCIA a casa (fvFreeFovTarget), no con el tiempo; (3) no se retrocede por detras de la Tierra (tope en z = 0).
// (5-nov) la ganancia por muesca segun el RITMO de la rueda (ver FREE.WHEEL_RATE): acumulador exponencial de |muescas| con constante WHEEL_TAU;
// R = acumulado / TAU (muescas por segundo). tSec = reloj de pared del evento (el dialogo y el navegador lo dan); sin el, el tiempo de escena P.t.
function fvWheelGain(P, n, tSec) {
   var FP = FV_PILOT.FREE, W = P.wheelRate || (P.wheelRate = { acc: 0, t: null, R: 0 });
   var t = (tSec === undefined || tSec === null || !isFinite(tSec)) ? P.t : tSec, dt = (W.t === null) ? 1e9 : Math.max(0, t - W.t);
   W.acc = W.acc * Math.exp(-dt / FP.WHEEL_TAU) + Math.abs(n); W.t = t; W.R = W.acc / FP.WHEEL_TAU;
   return fvClamp(Math.pow(Math.max(1e-9, W.R / FP.WHEEL_R0), FP.WHEEL_P), 1, FP.WHEEL_GMAX);
}
function fvPilotWheel(P, notches, tSec) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabWheel(P, notches);           // (8-nov, LABORATORIO)
   if (P.flight) return;
   P.brake = null;                                                           // (6-nov) la rueda manda sobre la frenada
   if (FV_PILOT.WHEEL_F2) { P.wheel += notches * FV_PILOT.WHEEL_FRAC * Math.max(1e-3, fvNearestDist(P)); if (P.mode === "home") P.mode = "free"; P.orbit = null; return; }   // ROJO (N11)
   var FPw = FV_PILOT.FREE, rate = FPw.WHEEL_RATE === true, g = 1;
   if (rate) { notches = fvClamp(notches, -FPw.WHEEL_MAXN, FPw.WHEEL_MAXN); if (!notches) return; g = fvWheelGain(P, notches, tSec); }
   // (I5) en orbita la rueda acerca/aleja del objeto enfocado (suave: el paso de la orbita lleva rK hacia rKT en ORBIT_ZOOM_S)
   if (P.orbit && FV_PILOT.FREE.GAIA_MOUSE === true) {
      var oW = P.orbit, FPo = FV_PILOT.FREE;
      oW.rKT = fvClamp((oW.rKT || oW.rK || 1) * Math.pow(FPo.ORBIT_ZOOM, notches * (rate ? Math.min(g, FPo.WHEEL_GMAX_ORBIT) : 1)), FPo.ORBIT_MIN_K, FPo.ORBIT_MAX_K);
      return;
   }
   if (P.orbit) fvFreeTakeControl(P);
   var F = fvFreeState(P), FP = FV_PILOT.FREE, dA = rate ? 0 : fvFreeAhead(P);
   if (rate) {
      // paso logaritmico sobre lo que queda DESPUES de lo que aun se desliza (simetrico: adelante ×e^−f, atras ×e^+f). La rueda lleva su propia
      // velocidad F.vW (deslizamiento WHEEL_GLIDE_S, fvFreeStep); lo que quede de la deriva de las teclas (F.v, DAMP_S) tambien cuenta.
      // La escala es una SESION (F.wS = { segs, u, S, exp, axis }): S = la distancia virtual a lo que habia delante cuando empezo la tanda
      // (fvFreeAhead: estrella casi en el eje, capa de nebulosa, el objeto al que se llego); cada muesca la multiplica por e^∓f (u = e-folds
      // acumulados: S = S0 · e^−u). Mientras la nave este donde la ultima muesca la dejo (exp: posicion final esperada) y la mirada no se haya
      // girado (WHEEL_AXIS_TOL × campo), la sesion se hereda: la vuelta deshace la ida exactamente aunque entre una estrella nueva en el cono
      // del eje o salga la de antes (con dA recalculada en cada muesca el paso daba saltos y la vuelta no volvia: 28–113 %). Si no (teclas,
      // arrastre, vuelo) se vuelve a medir. Adelante, si la escala cayo por debajo de WHEEL_REFRESH_K de lo que hay delante ahora (Zenon: se
      // agoto, y asi se puede pasar de la estrella a la que uno se acerca), se REFRESCA a lo que hay delante: otro tramo de la sesion (segs);
      // al volver atras por ese punto se recupera el tramo anterior, asi la vuelta tambien deshace los refrescos.
      var lk = fvNorm(P.cam.look), tW = FP.WHEEL_GLIDE_S, vW0 = F.vW || [0, 0, 0], pend = fvDot(vW0, lk) * tW + fvDot(F.v, lk) * FP.DAMP_S, W = F.wS;
      var posF = fvAdd(P.cam.pos, fvMul(lk, pend)), valid = !!(W && fvLen(fvSub(posF, W.exp)) <= 5e-3 * W.S + 1e-9 && fvAngle(lk, W.axis) <= FP.WHEEL_AXIS_TOL * P.cam.fov);
      if (!valid) W = { segs: [{ S0: Math.max(FP.MIN_D, fvFreeAhead(P) - pend), uEnd: 0 }], u: 0, S: 0, axis: lk, exp: null };
      else if (notches > 0) {
         var dF = fvFreeAhead(P) - pend;
         if (W.S < FP.WHEEL_REFRESH_K * dF) { W.segs[W.segs.length - 1].uEnd = W.u; W.segs.push({ S0: dF, uEnd: 0 }); W.u = 0; }
      }
      var fN = FP.WHEEL_FRAC * g * Math.abs(notches), du = (notches > 0) ? fN : -fN, dist = 0;
      P.wheelF = (P.wheelF || 0) + du;                                        // e-folds netos que ha pedido la rueda (adelante +): para las pruebas y la cabina
      for (var gs = 0; gs < 16; ++gs) {
         var sg = W.segs[W.segs.length - 1], uN = W.u + du;
         if (uN >= 0 || W.segs.length === 1) { dist += sg.S0 * (Math.exp(-W.u) - Math.exp(-uN)); W.u = uN; break; }
         dist += sg.S0 * (Math.exp(-W.u) - 1);                              // atras hasta el punto del refresco (alli S = S0)...
         W.segs.pop(); du = uN; W.u = W.segs[W.segs.length - 1].uEnd;        // ...y sigue por el tramo anterior
      }
      // (6-nov, KEEP_IN.WHEEL_BACK) hacia atras, no mas alla del plano de casa ni, desde detras de la foto, mas lejos de ella que D (la sesion
      // logaritmica, ×e^+f por muesca con ganancia ×6, mandaba la camara a 1e54 a.l.); si recorta, la siguiente muesca vuelve a medir
      var clampB = false;
      if (dist < 0 && fvKeepOn() && FV_PILOT.KEEP_IN.WHEEL_BACK) { var mB = fvKeepBackMax(P, posF, lk); if (-dist > mB) { dist = -mB; clampB = true; } }
      W.S = W.segs[W.segs.length - 1].S0 * Math.exp(-W.u); W.axis = lk; W.exp = fvAdd(posF, fvMul(lk, dist)); F.wS = W;
      if (clampB) F.wS = null;
      F.vW = fvAdd(vW0, fvMul(lk, dist / tW));
   } else F.v = fvAdd(F.v, fvMul(fvNorm(P.cam.look), notches * FP.WHEEL_FRAC * dA / FP.DAMP_S));
   P.coast = null;
   if (P.mode === "home" && notches > 0) P.mode = "free";
}
// la distancia a lo que se tiene delante: la estrella mas cercana dentro del campo de vision (con margen) o la primera capa de la nebulosa
// por delante; si no hay nada, la mas cercana a secas
// (1.ª corrida en PixInsight: con «la estrella mas cercana del campo» una muesca desde casa avanzaba 13 a.l. de 6 500: no se veia nada)
// Ahora cuentan solo las estrellas casi en el eje (10 % del campo) y, sobre todo, la capa de nebulosa que llena la vista.
function fvFreeAhead(P) { return fvFreeAheadPt(P).d; }
// (5-nov) lo mismo, y ademas el PUNTO de eso que se tiene delante: { d, p } (la rueda lo ancla: fvPilotWheel)
function fvFreeAheadPt(P) {
   var S = P.scene.stars, p = P.cam.pos, f = fvNorm(P.cam.look), c = Math.cos(Math.min(80 * FV_DEG, 0.1 * P.cam.fov)), best = 1e30, bp = null, bi = -1, i;
   if (S) for (i = 0; i < S.n; ++i) {
      var dx = S.x[i] - p[0], dy = S.y[i] - p[1], dz = S.z[i] - p[2], z = dx * f[0] + dy * f[1] + dz * f[2];
      if (z <= 0) continue;
      var d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (z >= c * d && d < best) { best = d; bi = i; bp = null; }
   }
   if (P.scene.nebula && f[2] > 0.05) { var L = P.scene.nebula.layers; for (i = 0; i < L.length; ++i) { var dl = (L[i].z - p[2]) / f[2]; if (dl > 0 && dl < best) { best = dl; bi = -1; bp = fvAdd(p, fvMul(f, dl)); } } }
   // (LLEGADA, 4-nov noche) y el objeto al que se acaba de llegar, si esta delante: se llega con el en el TERCIO (0,27 × el campo del eje),
   // fuera del cono del 10 % de arriba, y una muesca tomaba la escala de la nebulosa (5 500 a.l.: ~100 a.l./s a 17 a.l. de la estrella; la
   // camara la rozaba, resbalaba 34 a.l. de lado y el eje salia de la parte limpia: 72 % de pantalla sin nebulosa). FREE.AHEAD_ARRIVED false = ROJO
   if (P.arrivedAt && FV_PILOT.FREE.AHEAD_ARRIVED) { var pa = fvSelPos(P, P.arrivedAt); if (pa) { var va = fvSub(pa, p), da = fvLen(va); if (da > 0 && fvDot(va, f) > 0 && da < best) { best = da; bi = -1; bp = pa.slice(); } } }
   if (best >= 1e29) { var nrA = fvFreeNearest(P); best = nrA.d; bi = (nrA.star >= 0 && nrA.dStar <= nrA.d + 1e-9) ? nrA.star : -1; bp = null; if (bi < 0) bp = fvAdd(p, fvMul(f, best)); }
   if (!bp && bi >= 0) bp = [S.x[bi], S.y[bi], S.z[bi]];
   return { d: Math.max(FV_PILOT.FREE.MIN_D, best), p: bp };
}
// el campo de vision que corresponde a la distancia a casa: el de la foto en casa y 60° a FOV_AWAY × la distancia de referencia
// (la nebulosa); entre medias, smootherstep en logaritmo. Una muesca de rueda desde casa apenas lo toca (×1,0x)
// (1.ª corrida en PixInsight) La regla «por distancia a casa» seguia encogiendo la foto (el campo crecia mas deprisa que la foto al
// acercarse). Ahora es la regla de COBERTURA: el campo no pasa del angulo que ocupa la foto vista desde aqui (al acercarse la foto
// crece: un travelling hacia dentro, sin bordes ni bola); 60° como mucho, y 60° al llegar al plano de la nebulosa.
function fvFreeFovTarget(P) {
   var cov = fvPhotoCoverFov(P), b = FV_PILOT.FREE.FOV_BETA;
   if (b !== undefined && b < 1 && cov < Math.PI) cov = 2 * Math.atan(Math.tan(P.homeFov / 2) * Math.pow(Math.tan(cov / 2) / Math.tan(P.homeFov / 2), b));   // (B2) sin vertigo
   return Math.min(FV_PILOT.ARRIVE_FOV, cov);
}
// (coordinador, 4-nov tarde) el tope del vuelo libre FUERA del volumen de la nebulosa: lo que cubre la parte LIMPIA de la foto o de las
// capas (fvPhotoCoverFov con aware, la misma regla del cine), solo si la camara ya no esta en casa y mira hacia esa parte limpia. Mirando
// fuera de ella (girando a mano) no hay tope: se ve el borde, como es natural. Dentro de la losa, sin tope. -> radianes (1e9 = sin tope)
function fvFreeCleanCap(P) {
   var N = P.scene.nebula, c = P.cam.pos, lk = P.cam.look;
   if (!N || !FV_PILOT.FREE.CLEAN_CAP || !FV_PILOT.CINE_ADVANCE || fvLen(c) < 1e-9) return 1e9;
   var D = N.distLy, dz = D - c[2];
   if (c[2] >= D - N.thickLy / 2 || !(lk[2] > 0.05)) return 1e9;
   var f = P.scene.field, hw = Math.tan(P.homeFov / 2) * D, hh = hw * f.height / f.width, kc = fvLayerCleanK(P);
   var ox = c[0] + dz * lk[0] / lk[2], oy = c[1] + dz * lk[1] / lk[2];
   if (Math.abs(ox) >= kc[0] * hw || Math.abs(oy) >= kc[1] * hh) return 1e9;
   // (LLEGADA, 4-nov noche) el tope EXACTO de la ruta (fvRouteCover), sin el suelo de 0,3 de fvPhotoCoverFov: tras llegar a una estrella con
   // el eje cerca del borde de la parte limpia (v −0,59) el suelo dejaba 0,23° donde caben 0,12° y la rueda enseñaba el borde (22 %).
   // FREE.CLEAN_EXACT false = ROJO
   if (FV_PILOT.FREE.CLEAN_EXACT) { var cE = fvRouteCover(P, fvRouteGeo(P), c, fvNorm(lk), false); return (cE > 0 && cE < 1e9) ? 2 * Math.atan(cE) : 1e9; }
   return fvPhotoCoverFov(P, true);
}
// el campo horizontal que cubre la foto vista desde la camara (en el plano de la nebulosa); infinito pasado el plano
// (4.ª corrida) contando con que el centro de la vista puede no estar en el eje: la camara desplazada de lado y la mirada girada mueven
// el centro de la vista en el plano de la foto; la media anchura que queda hasta el borde mas cercano es la que cuenta (en vertical
// por el aspecto de la ventana). Con tope inferior de 0,3 × la media anchura: no se hace un zoom extremo si se ha salido mucho.
// aware = false (vuelo libre): solo el avance, como antes — al girar a mano se ve el borde, que es lo natural, y no se hace zoom.
function fvPhotoCoverFov(P, aware) {
   var N = P.scene.nebula, D = N ? N.distLy : 1000, c = P.cam.pos, z = c[2], lk = P.cam.look;
   if (z >= 0.999 * D) return 1e9;
   if (!aware) return 2 * Math.atan(Math.tan(P.homeFov / 2) * D / (D - z));
   var hw = Math.tan(P.homeFov / 2) * D, dz = D - z, asp = (P.VW && P.VH) ? P.VW / P.VH : 16 / 9;
   var ox = c[0], oy = c[1];
   if (lk[2] > 1e-6) { ox += dz * lk[0] / lk[2]; oy += dz * lk[1] / lk[2]; }
   if (FV_PILOT.CINE_ADVANCE) {
      // (B2) con la media altura de VERDAD de la foto (antes se suponia su aspecto igual al de la ventana) y, cuando el pintor ya pinta las
      // CAPAS en vez de la foto, solo su parte LIMPIA: las capas llevan un borde oscurecido y ondulado (FV_PAINT.EDGE_SOFT + EDGE_WOB del
      // lado mayor) que en pantalla se ve como otro borde, una nebulosa encogida con marco negro (nB2_cine_tira.png, 1.ª corrida, col. 4)
      var f = P.scene.field, hh = hw * f.height / f.width, kc = fvLayerCleanK(P);
      // el tope inferior (0,3) sobre la parte limpia: sobre hw entero se comia el margen vertical de las capas con la camara desviada
      // 14 a.l. por un esquive (A' 0,074 en 3 fotogramas, fv_nB2_node.js, 2.ª corrida)
      var roomC = Math.max(0.3 * Math.min(kc[0] * hw, kc[1] * hh * asp), Math.min(kc[0] * hw - Math.abs(ox), (kc[1] * hh - Math.abs(oy)) * asp));
      return 2 * Math.atan(roomC / dz);
   }
   var room = Math.max(0.3 * hw, Math.min(hw - Math.abs(ox), hw - Math.abs(oy) * asp));
   return 2 * Math.atan(room / dz);
}
// (B2) la fraccion LIMPIA (sin el borde oscurecido) de la media anchura y la media altura de lo que se pinta de la nebulosa: 1 con la
// foto (peso 1), la de las capas cuando la foto se ha apagado (peso 0), mezcla lineal entre medias. -> [kx, ky]
function fvLayerCleanK0(P) {
   // (RUTA, D2) sin FV_PAINT (visor web) se supone el borde estrecho de ROUTE.EDGE_FALLBACK (antes 0,14 / 0,12)
   var Fp = (typeof FV_PAINT !== "undefined") ? FV_PAINT : null, EF = FV_PILOT.ROUTE.EDGE_FALLBACK || [0.14, 0.12];
   var E = Fp && Fp.EDGE_MODE !== "off" ? (Fp.EDGE_SOFT || 0) : EF[0], A = Fp ? (Fp.EDGE_WOB || 0) : EF[1];
   // el borde a media luz: smooth(x)² = 0,5 en x ≈ 0,64 de EDGE_SOFT, mas 3/4 de la ondulacion maxima
   var f = P.scene.field, S = Math.max(f.width, f.height), band = 0.64 * E + 0.75 * A;
   return [Math.max(0.2, 1 - 2 * band * S / f.width), Math.max(0.2, 1 - 2 * band * S / f.height)];
}
function fvLayerCleanK(P) { return fvLayerCleanKAt(P, P.cam.pos); }
// (RUTA) la misma, para una posicion cualquiera (la planificacion del viaje la pide en cada punto del plan)
function fvLayerCleanKAt(P, pos) {
   var k0 = fvLayerCleanK0(P), kx = k0[0], ky = k0[1], N = P.scene.nebula, D = N ? N.distLy : 1000;
   var wP = 1 - fvSmooth(fvLen(pos) / (fvPhotoFadeK() * D));
   // (en la vuelta a casa tambien: sin esto, volviendo de una estrella delante de la nebulosa se veia el borde oscuro de las capas a la
   // derecha, nB2_casa_tira.png 3.ª corrida col. 3; el precio es que dentro de la zona de la foto el campo se abre un poco mientras la foto
   // reaparece —de la parte limpia de las capas a la foto entera—, medido en N5g de fv_nB_engine_node.js)
   return [fvMix(kx, 1, wP), fvMix(ky, 1, wP)];
}
// (1.ª corrida) en los VUELOS que salen de casa el campo tampoco pasa de la cobertura mientras se ve el plano de la foto (que tiene bordes
// rectos). (3.ª corrida) soltarlo entre 0 y 3,5 % de D dejaba a mitad de camino un campo 10 veces mayor que la foto con la foto aun al
// 50 % (nB_cine_tira.png, columna 2: un rectangulo). Ahora el tope aguanta hasta que el pintor ha apagado la foto (su peso es
// 1 − smooth(|pos| / (PHOTO_FADE × D)); a x = 0,8 queda ~0,1) y se suelta entre PHOTO_CAP0 y PHOTO_CAP1 de esa distancia.
// (B2) el radio del cono de la foto (grados, vista desde la Tierra): el del build (facts.coneDeg) o la semidiagonal de la foto
function fvPhotoConeDeg(P) {
   var Fc = P.scene.facts, f = P.scene.field;
   if (Fc && Fc.coneDeg > 0) return Fc.coneDeg;
   return Math.atan(0.5 * Math.sqrt(f.width * f.width + f.height * f.height) / f.F) / FV_DEG;
}
// (B2) ¿viaje de cine a un destino DELANTE de la nebulosa, dentro de la foto, saliendo de la foto (casa o su zona)? Entonces la nebulosa
// sigue de fondo llenando la pantalla todo el viaje (ver fl.slabZ en fvPilotFly)
function fvFgFillTrip(P, T, p0) {
   var Nb = P.scene.nebula;
   if (!Nb || !FV_PILOT.CINE_ADVANCE || !FV_PILOT.CINE_FG_FILL || !(T[2] > 0) || T[2] >= Nb.distLy - Nb.thickLy / 2) return false;
   if (fvLen(p0) >= FV_PILOT.PHOTO_CAP1 * fvPhotoFadeK() * Nb.distLy) return false;
   var hw = Math.tan(P.homeFov / 2) * Nb.distLy, f = P.scene.field, u = T[0] * Nb.distLy / T[2], v = T[1] * Nb.distLy / T[2];
   return Math.abs(u) < 0.9 * hw && Math.abs(v) < 0.9 * hw * f.height / f.width;
}
// (B2) la holgura (a.l., en el plano de la nebulosa) entre el punto de la nebulosa que queda detras del destino y el borde de su parte
// limpia (con las capas: fvLayerCleanK sin la foto), en el lado mas justo (el vertical en a.l. de la foto, sin el aspecto de la ventana)
function fvFgRoom(P, T) {
   var Nb = P.scene.nebula, D = Nb.distLy, f = P.scene.field, hw = Math.tan(P.homeFov / 2) * D, hh = hw * f.height / f.width, k0 = fvLayerCleanK0(P);
   return Math.max(0, Math.min(k0[0] * hw - Math.abs(T[0] * D / T[2]), k0[1] * hh - Math.abs(T[1] * D / T[2])));
}
function fvPhotoFadeK() { return (typeof FV_PAINT !== "undefined" && FV_PAINT.PHOTO_FADE) ? FV_PAINT.PHOTO_FADE : FV_PILOT.PHOTO_FADE; }
function fvPhotoFovCap(P) {
   var N = P.scene.nebula, D = N ? N.distLy : 1000, pf = fvPhotoFadeK();
   var k = fvSmooth((fvLen(P.cam.pos) / (pf * D) - FV_PILOT.PHOTO_CAP0) / (FV_PILOT.PHOTO_CAP1 - FV_PILOT.PHOTO_CAP0));
   if (k >= 0.999) return 1e9;
   return Math.exp(fvMix(Math.log(Math.min(FV_PILOT.MAX_FOV, fvPhotoCoverFov(P, true))), Math.log(4 * Math.PI), k));
}

// ===========================================================================
// (RUTA, 4-nov-2026) LA LEY NUEVA DEL VIAJE (FV_PILOT.ROUTE; medida y razonada en docs/ruta-del-viaje-analisis.md §3, prototipo
// protoTrip de tests/fv_ruta_probe_node.js). fvPilotFly solo fija el viaje y su duracion (barato: el editor, fvRouteTrip, lo llama
// cada 0,4 s sobre una copia para leer la duracion); el PLAN se hace en el primer paso (fvRoutePlan) sobre una rejilla de PLAN_DT y
// fvPilotStep solo lo muestrea. Lo que garantiza el plan, por construccion:
//   · camino: la recta salida -> llegada (llegada en la linea de vision al destino, sin grua ni subida); un solo arco plano si una
//     estrella queda de verdad en medio (fvRouteArc);
//   · avance: x = fvCineX(u) sobre tau = ∫ ds / escala VISIBLE (fvRouteVisScale): el destino, el objeto de salida si queda delante, la
//     losa de la nebulosa si se toca, el plano de la foto al volver, y el tramo del fundido de la foto;
//   · mirada: el destino va, EN PANTALLA, de donde esta al tercio de llegada (fvAimAt); si no esta en cuadro, antes una panoramica quieta;
//   · campo: tan(campo/2) ≤ tan(campo previo/2)·(d_ant/d)^beta (ritmo, no curva absoluta: tras un tope no se «recupera» campo), B
//     (tan·d no sube), ritmo ≤ FOV_RATE abriendo y cerrando (el cierre se planifica hacia atras: se cierra ANTES de llegar al tope), y el
//     tope A EXACTO (fvRouteCover: la vista dentro de la parte limpia de lo que se pinta, sin el suelo de 0,3 de fvPhotoCoverFov) iterado
//     con la mirada; si con el tercio pedido el eje sale de la parte limpia, se encuadra menos (w, que solo baja).
// ===========================================================================
// la foto en su plano: medias anchura/altura EXACTAS (a.l.), la losa, la zona en que se pinta la foto
function fvRouteGeo(P) {
   var N = P.scene.nebula, f = P.scene.field, D = N ? N.distLy : 1000, th = N ? N.thickLy : 0, pf = fvPhotoFadeK();
   return { D: D, HW: (f.width / 2) / f.F * D, HH: (f.height / 2) / f.F * D, hS: th / 2, zIn: D - th / 2, zOut: D + th / 2, neb: !!N,
            fade: pf * D, zPhoto: FV_PILOT.PHOTO_CAP1 * pf * D, asp: P.VW / P.VH, tanArr: Math.tan(FV_PILOT.ARRIVE_FOV / 2), kc0: fvLayerCleanK0(P) };
}
// el tope EXACTO de A, en tan del medio campo horizontal: lo que deja la vista dentro de la parte limpia de las capas (whole: de la foto
// entera) en el plano de la foto; −1 si el eje ya cae fuera; 1e9 si no aplica (pasado el plano o mirando hacia atras). Margen A_MARGIN
// (en casa, ninguno: la vista de casa es justo el borde de la foto)
function fvRouteCover(P, G, pos, look, whole) {
   var dz = G.D - pos[2];
   if (dz <= 0 || !(look[2] > 1e-6)) return 1e9;
   var kc = whole ? [1, 1] : fvLayerCleanKAt(P, pos);
   var m = 1 - (1 - FV_PILOT.ROUTE.A_MARGIN) * fvSmooth(fvLen(pos) / (0.05 * G.fade));
   if (FV_PILOT.ROUTE.COVER_CORNERS) return fvRouteCoverCorners(G, pos, look, kc, dz, m);
   var ox = pos[0] + dz * look[0] / look[2], oy = pos[1] + dz * look[1] / look[2];
   var room = Math.min(kc[0] * G.HW - Math.abs(ox), (kc[1] * G.HH - Math.abs(oy)) * G.asp);
   return room > 0 ? m * room / dz : -1;
}
// (K11b H-1, Codex) el tope por los RAYOS DE LAS 4 ESQUINAS de la pantalla: «m · room / dz» supone el plano de la foto perpendicular a la
// mirada; con la mirada oblicua (camara de lado mirando al centro, vuelo libre girado, camara manual) las esquinas caen a profundidades
// distintas y salian de la parte limpia (camara a 100 a.l. de lado y 150 delante de IC 1848: 30 % de pantalla fuera). La misma base que
// el proyector del pintor (fvBasis(look, [0, 1, 0])) y el mismo aspecto (vertical = horizontal · VH/VW). Cada esquina es el rayo
// f + t·(±r ± d/asp); su corte con el plano z = D cumple |x| ≤ kx·HW e |y| ≤ ky·HH si a + t·b ≥ 0 (lineal en t con rayo hacia delante):
// t ≤ −a/b para b < 0. Las 4 esquinas dentro -> todo el cuadro dentro (el cuadro es convexo en el plano). −1 si el eje ya sale.
function fvRouteCoverCorners(G, pos, look, kc, dz, m) {
   var B = fvBasis(look, [0, 1, 0]), f = B.f, h = [kc[0] * G.HW, kc[1] * G.HH], ky = 1 / G.asp, lim = 1e9, j, s, x, y;
   for (j = 0; j < 2; ++j) for (s = -1; s <= 1; s += 2) if ((h[j] - s * pos[j]) * f[2] - s * dz * f[j] <= 0) return -1;
   for (x = -1; x <= 1; x += 2) for (y = -1; y <= 1; y += 2) {
      var v = [x * B.r[0] + y * ky * B.d[0], x * B.r[1] + y * ky * B.d[1], x * B.r[2] + y * ky * B.d[2]];
      if (v[2] < 0) lim = Math.min(lim, -f[2] / v[2]);                       // el rayo sigue yendo hacia el plano
      for (j = 0; j < 2; ++j) for (s = -1; s <= 1; s += 2) {
         var q = h[j] - s * pos[j], a = q * f[2] - s * dz * f[j], b = q * v[2] - s * dz * v[j];
         if (b < 0) lim = Math.min(lim, -a / b);
      }
   }
   return m * lim;
}
// la mirada sin alabeo con la que el punto TL se ve en (sx, sy) de la pantalla, en unidades de la distancia focal (tan; el tercio de
// llegada es (−tan(FRAME_THIRD·campo), 0)). Generaliza fvFrameDir (la misma iteracion en pantalla, tambien en vertical)
// (K11b H-3, Codex) la iteracion de 6 vueltas no convergia lejos del ecuador (destino a 70° de cabeceo: 271 px en vez de 248) y cerca
// del polo invertia el lado (89°: 514 px, a la DERECHA, pedido a la izquierda); en un barrido de 86 400 casos, 16 528 mal y saltos de
// la mirada de 31° entre muestras vecinas. ROUTE.AIM_POLE: FORMA CERRADA (fvAimSolve) y, si el desplazamiento pedido no es realizable
// sin alabeo (el tercio exige cabeceo > AIM_MAX_PITCH), se reduce (sx, sy) × λ con λ por biseccion: el destino queda del lado pedido,
// mas cerca del centro. false = ROJO (la iteracion)
var FV_AIM_MAX_PITCH = 89.5 * FV_DEG;
// la guiñada y el cabeceo (sin alabeo) con los que la direccion de cabeceo/guiñada `yp` se ve en (sx, sy) de la pantalla, o null si no es
// realizable. Con la base de fvBasis (r = (cos ψ, 0, −sin ψ), d = (sin θ sin ψ, cos θ, sin θ cos ψ)) el destino es (f + sx·r + sy·d)/N:
//   componente y: sin(θ − atan sy)·√(1+sy²) = sin θt·N   ->  θ = atan sy + asin(sin θt · N / √(1+sy²))
//   en el plano horizontal: ψt = ψ + atan2(sx, cos θ + sy sin θ)
function fvAimSolve(yp, sx, sy) {
   var N = Math.sqrt(1 + sx * sx + sy * sy), a = Math.sin(yp.pitch) * N / Math.sqrt(1 + sy * sy);
   if (!(Math.abs(a) <= 1)) return null;
   var th = Math.atan(sy) + Math.asin(a);
   if (!(Math.abs(th) <= FV_AIM_MAX_PITCH)) return null;
   return { yaw: yp.yaw - Math.atan2(sx, Math.cos(th) + sy * Math.sin(th)), pitch: th };
}
function fvAimAt(pos, TL, sx, sy) {
   var t = fvNorm(fvSub(TL, pos)), yp = fvYawPitchOf(t);
   if (FV_PILOT.ROUTE.AIM_POLE) {
      var so = fvAimSolve(yp, sx, sy), lo = 0, hi = 1, b, m, sm;
      if (!so) {
         so = fvAimSolve(yp, 0, sy);
         if (so) { for (b = 0; b < 44; ++b) { m = 0.5 * (lo + hi); sm = fvAimSolve(yp, m * sx, sy); if (sm) { lo = m; so = sm; } else hi = m; } }
         else {
            so = fvAimSolve(yp, 0, 0);
            if (!so) return t;                                                        // el destino casi en la vertical: mirarlo de frente
            for (b = 0; b < 44; ++b) { m = 0.5 * (lo + hi); sm = fvAimSolve(yp, 0, m * sy); if (sm) { lo = m; so = sm; } else hi = m; }
         }
      }
      return fvDirYawPitch(so.yaw, so.pitch);
   }
   var f = fvDirYawPitch(yp.yaw - Math.atan(sx), yp.pitch + Math.atan(sy));
   for (var k = 0; k < 6; ++k) {
      var B = fvBasis(f), z = fvDot(t, B.f);
      if (!(z > 1e-9)) break;
      var ex = fvDot(t, B.r) / z - sx, ey = fvDot(t, B.d) / z - sy;
      if (Math.abs(ex) + Math.abs(ey) < 1e-14) break;
      var q = fvYawPitchOf(f); f = fvDirYawPitch(q.yaw + Math.atan(ex), q.pitch - Math.atan(ey));
   }
   return f;
}
// donde se ve TL desde (pos, look): [x, y] en unidades de la distancia focal (x a la derecha, y hacia abajo); null si queda detras
function fvScreenTan(pos, look, TL) { var B = fvBasis(look), v = fvSub(TL, pos), z = fvDot(v, B.f); return z > 1e-12 ? [fvDot(v, B.r) / z, fvDot(v, B.d) / z] : null; }
// el tercio de llegada en medios anchos de pantalla para un campo de medio-tan tanF (0,5 a 60°; 0,54 a 6°): el de fvArriveFrameDx
function fvRouteThird(tanF) { return Math.tan(FV_PILOT.FRAME_THIRD * 2 * Math.atan(tanF)) / Math.max(1e-12, tanF); }
// en casa se mira hacia delante (+z): al centro de la nebulosa, o mas alla si ya se ha pasado (se vuelve marcha atras a traves de ella)
function fvRouteHomeTL(G, p) { return [0, 0, Math.max(G.D, p[2] + 0.5 * fvLen(p))]; }
// (D5) ¿hay que rodear algo? La estrella que la recta p0 -> p1 roza a menos de AVOID_REAL_K × SU distancia de llegada (o de FREE.STANDOFF);
// -> el arco plano { n (unitario, hacia fuera de la estrella), h (flecha) } de la parabola p(λ) = recta + 4λ(1−λ)·h·n, con holgura 1,5 ×
// ese radio en el punto de la estrella | null. Un solo arco, sin eses (desde casa ninguno en IC 1848; ver el analisis, R1)
function fvRouteArc(P, p0, p1, skip) {
   var S = P.scene.stars, R = FV_PILOT.ROUTE;
   if (!S || !R.AVOID_REAL || !(R.AVOID_REAL_K > 0)) return null;
   var ab = fvSub(p1, p0), L2 = fvDot(ab, ab), so = FV_PILOT.FREE.STANDOFF, rMax = Math.max(so, R.AVOID_REAL_K * FV_PILOT.ARRIVE_MAX), worst = null, wr = 1;
   if (!(L2 > 0)) return null;
   for (var i = 0; i < S.n; ++i) {
      if (skip && skip[i]) continue;
      var sx = S.x[i] - p0[0], sy = S.y[i] - p0[1], sz = S.z[i] - p0[2], t = (sx * ab[0] + sy * ab[1] + sz * ab[2]) / L2;
      if (t <= 0.02 || t >= 0.98) continue;                        // (junto a la salida y a la llegada estan los extremos)
      var qx = sx - ab[0] * t, qy = sy - ab[1] * t, qz = sz - ab[2] * t, d2 = qx * qx + qy * qy + qz * qz;
      if (d2 >= rMax * rMax) continue;
      var r = Math.max(so, R.AVOID_REAL_K * fvArriveDist(P, { kind: "star", i: i })), d = Math.sqrt(d2);
      if (d < r * wr) { wr = d / r; worst = { i: i, t: t, d: d, r: r, q: [qx, qy, qz] }; }
   }
   if (!worst) return null;
   var n = worst.d > 1e-12 ? fvMul(worst.q, -1 / worst.d) : fvBasis(ab).r;
   return { n: n, h: Math.max(0, 1.5 * worst.r - worst.d) / (4 * worst.t * (1 - worst.t)), star: worst.i };
}
// (nQ, I6) la LINEA DE VISION de q (unitaria, de la Tierra a q); null en la Tierra o detras de ella
function fvSightDir(q) { var L = fvLen(q); return (L > 1e-9 && q[2] > 1e-6 * L) ? fvMul(q, 1 / L) : null; }
// (nQ) la mirada NOMINAL de un viaje en pm (sin el tercio): la linea de vision propia en un viaje I6; hacia el destino en la recta
function fvRouteNomLook(S, pm) { if (S.sight) return fvSightDir(pm) || S.dirv; var v = fvSub(S.TL, pm), L = fvLen(v); return L > 1e-12 ? fvMul(v, 1 / L) : S.dirv; }
// (nQ, VIS_ONSCR) ¿se ve X desde pm? con la mirada nominal y el medio campo nominal (el del tope A ahi; sin A, el de salida). Peso suave
// 1 (en cuadro, hasta 0,8 del medio campo) … 0 (a 1,3 o detras). P solo para el tope (fvRouteCapA)
function fvRouteVisW(P, S, G, pm, X) {
   var v = fvSub(X, pm), dX = fvLen(v);
   if (!(dX > 1e-12)) return 1;
   var lk = fvRouteNomLook(S, pm), c = fvDot(v, lk) / dX;
   if (!(c > 0)) return 0;
   var th = Math.atan2(Math.sqrt(Math.max(0, 1 - c * c)), c), cap = fvRouteCapA(P, S, pm, lk);
   var half = (cap > 0 && cap < 1e9) ? Math.atan(cap) : Math.atan(Math.max(S.tanS || 0, S.tan0 || 0, 1e-9));
   return 1 - fvSmooth((th / Math.max(1e-12, half) - 0.8) / 0.5);
}
// (nQ, VIS_ONSCR) el angulo de X desde pm, en medios campos nominales (como fvRouteVisW). CONTINUO tambien detras de la camara (hasta
// 180°): con un salto a «infinito» al pasar el origen por el lado, la nave pasaba de arrastrarse a 1 400 a.l. en un segundo (R4)
function fvRouteVisN(P, S, G, pm, X) {
   var v = fvSub(X, pm), dX = fvLen(v);
   if (!(dX > 1e-12)) return 0;
   var lk = fvRouteNomLook(S, pm), c = fvClamp(fvDot(v, lk) / dX, -1, 1);
   var th = Math.atan2(Math.sqrt(Math.max(0, 1 - c * c)), c), cap = fvRouteCapA(P, S, pm, lk);
   var half = (cap > 0 && cap < 1e9) ? Math.atan(cap) : Math.atan(Math.max(S.tanS || 0, S.tan0 || 0, 1e-9));
   return th / Math.max(1e-12, half);
}
// (nQ, VIS_ONSCR) la escala de algo a distancia d que se ve a q medios campos: d en cuadro (q ≤ 0,8) y, fuera, CRECE CONTINUA con lo que se
// aleja del borde (d·(1 + K·x²/(1+x)), x = q − 0,8; al pasar de lado ≈ d·K·q, que es su desplazamiento lateral sobre el medio campo).
// Antes era d / peso (peso 1 -> 0 entre 0,8 y 1,3 medios campos): al pasar junto al origen con 0,24° de campo la escala saltaba de 7 a
// 3 000 a.l. en dos fotogramas y la nave pasaba de parada a 1 000 a.l. por fotograma (R4 de fv_nQ_rutas_node)
function fvRouteVisS(d, q) { if (!(q < 1e8)) return 1e30; var x = Math.max(0, q - 0.8), K = FV_PILOT.ROUTE.VIS_K || 2; return d * (1 + K * x * x / (1 + x)); }
// (nQ, I6) una curva por TROZOS: pieces = [{ f(s ∈ [0, 1]) -> punto, len }] -> { at(λ), len }
function fvPieceCurve(pieces) {
   var cum = [0], tot = 0, i;
   for (i = 0; i < pieces.length; ++i) { tot += Math.max(1e-12, pieces[i].len); cum.push(tot); }
   return { len: tot, at: function(l) {
      var x = fvClamp(l, 0, 1) * tot, j = 0;
      while (j < pieces.length - 1 && x > cum[j + 1]) ++j;
      return pieces[j].f(fvClamp((x - cum[j]) / Math.max(1e-12, cum[j + 1] - cum[j]), 0, 1));
   } };
}
function fvHermite(a, ma, b, mb) {
   return function(s) {
      var s2 = s * s, s3 = s2 * s, h00 = 2 * s3 - 3 * s2 + 1, h10 = s3 - 2 * s2 + s, h01 = -2 * s3 + 3 * s2, h11 = s3 - s2;
      return [h00 * a[0] + h10 * ma[0] + h01 * b[0] + h11 * mb[0], h00 * a[1] + h10 * ma[1] + h01 * b[1] + h11 * mb[1], h00 * a[2] + h10 * ma[2] + h01 * b[2] + h11 * mb[2]];
   };
}
function fvSegFn(a, b) { return function(s) { return fvLerp(a, b, s); }; }
// (nQ, I6) EL VIAJE «SUBIR, CRUZAR, BAJAR» por la linea de vision del destino (ROUTE.SIGHT). Decide el caso y fija S.p1 y, si hace falta,
// S.sight = { mode "X" (cruzar) | "R" (subir hacia casa), curve, pTop, cU, uEps, dec (decadas de escala del recorrido) }. Sin estrellas: barato.
//   F  el rayo al destino ya cae dentro de la foto (con holgura SIGHT_RAY_K del campo): la recta de siempre, pero llegando por la linea
//      de vision (el destino delante de su sitio en la foto)
//   X  destino DELANTE con el rayo fuera de la foto: Hermite de la salida al pie de la perpendicular sobre la linea de vision (arranca de lado
//      y entra en ella ya avanzando: la distancia al destino solo baja) y luego la recta por ella
//   R  destino DETRAS o al lado: se retrocede por la linea de vision PROPIA hacia casa (la mirada no cambia: el origen encoge donde esta), U
//      en la cima (frenando: la cima es un foco de la escala) hasta la del destino, a SIGHT_TOP_K × la separacion origen-destino, y se baja
function fvSightSetup(P, S, G, T, TL, dA, startF) {
   var R = FV_PILOT.ROUTE, p0 = S.p0, Th = fvSightDir(T), ph0 = fvSightDir(p0), d0 = fvLen(fvSub(T, p0));
   S.sight = null;
   if (!R.SIGHT || !Th || !ph0 || !G.neb || fvLen(p0) < 1e-6) return;
   var p1 = fvSub(T, fvMul(Th, dA)), aheadZ = TL[2] - p0[2], ahead = aheadZ > Math.max(1.5 * dA, 0.02 * d0);
   var cvR = fvRouteCover(P, G, p0, fvNorm(fvSub(TL, p0)), !S.tClean);
   S.p1 = p1;
   if (ahead && cvR > R.SIGHT_RAY_K * S.tan0) return;                                       // F
   var lenT = fvLen(T), sp = { mode: ahead ? "X" : "R" }, pieces = [], dO0 = Math.max(1e-6, fvLen(fvSub(p0, startF))), pTop, dTop;
   if (ahead) {
      var sF = fvClamp(fvDot(p0, Th), 0.05 * lenT, lenT - 3 * dA); pTop = fvMul(Th, sF); dTop = fvLen(fvSub(T, pTop));
      var lh = fvLen(fvSub(pTop, p0));
      if (lh > 1e-9) {
         var Hx = fvHermite(p0, fvSub(pTop, p0), pTop, fvMul(Th, lh));
         pieces.push({ f: Hx, len: 1.2 * lh });
         // el CRUCE como foco de la escala (como la cima de la U): sin el, con el origen y el destino fuera de cuadro, los 15 a.l. de lado
         // se hacian en 0,1 s (la foto barria 10 medios anchos por segundo, R5 de fv_nQ_rutas_node)
         sp.cU = Hx(0.5); sp.uEps = R.SIGHT_X_EPS * lh;
      }
      pieces.push({ f: fvSegFn(pTop, p1), len: fvLen(fvSub(p1, pTop)) });
   } else {
      dTop = fvClamp(R.SIGHT_TOP_K * fvLen(fvSub(T, startF)), R.SIGHT_TOP_MIN * dA, Math.max(R.SIGHT_TOP_MIN * dA, R.SIGHT_TOP_FRAC * lenT));
      pTop = fvSub(T, fvMul(Th, dTop));
      if (!(pTop[2] > 0.02 * G.D) || !(pTop[2] < p0[2])) { S.sight = null; return; }     // sin sitio para subir: la recta de siempre
      var q1 = fvMul(ph0, pTop[2] / ph0[2]), lat = fvLen(fvSub(pTop, q1)), r = Math.max(0.5 * lat, 0.01 * dTop, 1e-6);
      // (pasada S, ROUTE.SIGHT_U_FIT) el final de la U no puede pasar de la llegada (si no, la bajada atraviesa el destino)
      if (R.SIGHT_U_FIT > 0) r = Math.min(r, Math.max(1e-6, R.SIGHT_U_FIT * (dTop - dA)));
      var a = fvAdd(q1, fvMul(ph0, r)), b = fvAdd(pTop, fvMul(Th, r));
      if (fvLen(fvSub(p0, a)) < 2 * r) a = p0;
      if (a !== p0) pieces.push({ f: fvSegFn(p0, a), len: fvLen(fvSub(a, p0)) });
      var Uf = fvHermite(a, fvMul(ph0, -4 * r), b, fvMul(Th, 4 * r));
      pieces.push({ f: Uf, len: 3 * r + fvLen(fvSub(b, a)) });
      pieces.push({ f: fvSegFn(b, p1), len: fvLen(fvSub(p1, b)) });
      sp.cU = Uf(0.5); sp.uEps = 0.3 * r; sp.q1 = q1;
   }
   sp.curve = fvPieceCurve(pieces); sp.pTop = pTop; sp.dTop = dTop;
   // las decadas de escala del recorrido (la duracion, WWT: por el log de la razon de distancias): subir desde el origen + bajar al destino
   var dRise = ahead ? fvLen(fvSub(pTop, startF)) : fvLen(fvSub(sp.q1, startF));
   sp.dec = Math.max(0, Math.log(Math.max(1, dRise / dO0)) / Math.LN10) + Math.log(Math.max(1, dTop / dA)) / Math.LN10;
   S.sight = sp;
}
// (nQ, I11/I9) las estrellas de la HUELLA de la foto que el camino curve(λ) pasa de verdad cerca (a ≤ PACE_PASS_K × su distancia de
// llegada; ni el origen ni el destino) -> [{ i, p (punto), w (radio del ritmo), k (fuerza), l (λ del paso) }], como mucho 24, las mas
// cercanas. Una pasada por las estrellas contra una polilinea de 96 trozos (~2 M operaciones, una vez por viaje)
function fvRoutePasses9(P, S, curve) {
   var ST = P.scene.stars, R = FV_PILOT.ROUTE, K = R.PACE_PASS_K, out = [];
   if (!ST || !(K > 0)) return out;
   var NS = 96, pl = [], j, i, rMax = K * FV_PILOT.ARRIVE_MAX, lo = [1e30, 1e30, 1e30], hi = [-1e30, -1e30, -1e30];
   for (j = 0; j <= NS; ++j) { var q = curve(j / NS); pl.push(q); for (var c = 0; c < 3; ++c) { lo[c] = Math.min(lo[c], q[c]); hi[c] = Math.max(hi[c], q[c]); } }
   var Tq = S.T, Oq = S.startF, eT = 1.5 * (S.dA || 0);
   for (i = 0; i < ST.n; ++i) {
      if (ST.inFrame && !ST.inFrame[i]) continue;
      if (S.skip && S.skip[i]) continue;
      var x = ST.x[i], y = ST.y[i], z = ST.z[i];
      if (x < lo[0] - rMax || x > hi[0] + rMax || y < lo[1] - rMax || y > hi[1] + rMax || z < lo[2] - rMax || z > hi[2] + rMax) continue;
      var tx = x - Tq[0], ty = y - Tq[1], tz = z - Tq[2];
      if (tx * tx + ty * ty + tz * tz < Math.max(1e-12, eT * eT)) continue;                 // el destino
      var ox = x - Oq[0], oy = y - Oq[1], oz = z - Oq[2];
      if (ox * ox + oy * oy + oz * oz < 1e-8) continue;                                       // el origen
      var best = 1e30, bl = 0;
      for (j = 0; j < NS; ++j) {
         var a = pl[j], b = pl[j + 1], ab0 = b[0] - a[0], ab1 = b[1] - a[1], ab2 = b[2] - a[2], L2 = ab0 * ab0 + ab1 * ab1 + ab2 * ab2;
         var t = L2 > 0 ? fvClamp(((x - a[0]) * ab0 + (y - a[1]) * ab1 + (z - a[2]) * ab2) / L2, 0, 1) : 0;
         var dx = x - a[0] - ab0 * t, dy = y - a[1] - ab1 * t, dz = z - a[2] - ab2 * t, d2 = dx * dx + dy * dy + dz * dz;
         if (d2 < best) { best = d2; bl = (j + t) / NS; }
      }
      if (best >= rMax * rMax) continue;
      var rA = K * fvArriveDist(P, { kind: "star", i: i }), d = Math.sqrt(best);
      if (d < rA) out.push({ i: i, p: [x, y, z], w: rA, k: 1, l: bl, d: d });
   }
   out.sort(function(u, v) { return u.d / u.w - v.d / v.w; });
   return out.slice(0, 24);
}
// (nQ, I11) la funcion del ritmo para fvRouteTau, con su tope de paso junto a las estrellas que se pasan (0,1 × la distancia a ellas)
function fvRoutePaceFn(S) {
   var fn = function(q, s) { return fvRoutePace(S, q, s); };
   if (FV_PILOT.ROUTE.PACE_PASS && S.passes && S.passes.length) fn.stepCap = function(q) {
      var m = 1e30, PS = S.passes, SIG = FV_PILOT.ROUTE.PACE_PASS_SIG || 1.5;
      for (var i = 0; i < PS.length; ++i) { var e = PS[i], dq = fvLen(fvSub(q, e.p)); if (dq < e.d * Math.exp(3 * SIG)) m = Math.min(m, 0.1 * Math.max(dq, e.d)); }
      return m;
   };
   return fn;
}
// (nQ, I11) el PESO del avance (tiempo por unidad de tau) en q con escala visible s: CINE_VARY[0] cerca de algo, CINE_VARY[1] en el vacio
// (la escala visible pequeña frente al viaje, en log: salida, llegada, la losa, la cima de la U) y cerca de las estrellas que se pasan
function fvRoutePace(S, q, s) {
   var V = FV_PILOT.CINE_VARY, R = FV_PILOT.ROUTE;
   if (V && fvFastOn()) V = [FV_PILOT.FAST.VARY_NEAR, V[1]];        // (6-nov, FAST_EASE) los extremos del viaje menos lentos (antes ×1,8)
   if (!R.PACE || !V || !S.paceLo) return 1;
   var f = (Math.log(Math.max(1e-30, s)) - S.paceLo) / Math.max(1e-9, S.paceHi - S.paceLo), w = fvMix(V[0], V[1], fvSmooth((f - 0.1) / 0.45));
   // (PACE_PASS, APAGADO) frenar junto a las estrellas que se pasan: a velocidad de crucero (1 800 a.l./s) una estrella a 1 a.l. se pasa
   // en un fotograma y la campana daba tirones de velocidad de fotograma a fotograma (N5b de fv_nB_engine_node: salto 0,96, tope 0,1).
   // Hacerlo bien es meterlas en la escala visible (OpenSpace) y eso se come el tiempo del viaje: queda para otra vuelta. Las pasadas
   // siguen contando como EVENTOS de I9
   var PS = R.PACE_PASS ? S.passes : null;
   if (PS) for (var i = 0; i < PS.length; ++i) {
      // (campana en ln de la distancia a la estrella, no en la distancia: el paso se acerca a ritmo ~constante en ln; en la distancia la
      // campana era un escalon de velocidad a toda marcha: salto de aceleracion 0,96 en N5b de fv_nB_engine_node, tope 0,1)
      var e = PS[i], dx = q[0] - e.p[0], dy = q[1] - e.p[1], dz = q[2] - e.p[2], dq = Math.sqrt(dx * dx + dy * dy + dz * dz);
      var lr = Math.log(Math.max(dq, e.d, 1e-12) / Math.max(e.d, 1e-12)) / Math.max(1e-3, R.PACE_PASS_SIG || 1.5), g = Math.exp(-lr * lr);
      if (g > 1e-4) w = Math.max(w, fvMix(w, V[0], g * e.k));
   }
   return w;
}
// la ESCALA VISIBLE en pm (a.l.): la distancia a lo que se ve. VIS_TAU false = la 1.ª version (solo el destino; en casa, la Tierra): ROJO
function fvRouteVisScale(S, G, pm) {
   var R = FV_PILOT.ROUTE, s;
   if (!R.VIS_TAU) s = S.home ? fvLen(pm) + 0.004 * S.d0 : fvLen(fvSub(S.T, pm));
   else if (S.visP && !S.home) {
      // (nQ, VIS_ONSCR) el destino y el origen solo cuentan EN PANTALLA (peso suave; fuera de cuadro, como si estuvieran lejos)
      s = fvRouteVisS(fvLen(fvSub(S.T, pm)), fvRouteVisN(S.visP, S, G, pm, S.TL));
      if (S.startOk) s = Math.min(s, fvRouteVisS(fvLen(fvSub(pm, S.startF)), fvRouteVisN(S.visP, S, G, pm, S.startF)));
      if (S.sight && S.sight.cU) s = Math.min(s, R.SIGHT_U_K * fvLen(fvSub(pm, S.sight.cU)) + S.sight.uEps);   // (I6) la cima de la U: se frena
      if (S.touchSlab) s = Math.min(s, Math.abs(pm[2] - G.D) + G.hS);
      if (G.neb && pm[2] < G.zIn) s = Math.min(s, Math.max(G.D - pm[2] + G.hS, fvLen(fvSub(S.T, pm))));   // la foto de fondo (nunca menos que el destino)
      if (R.FADE_K > 0) s = Math.min(s, R.FADE_K * G.fade + Math.max(0, fvLen(pm) - G.zPhoto));
      if (s >= 1e29) s = fvLen(fvSub(S.T, pm));
   }
   else {
      s = S.home ? 1e30 : fvLen(fvSub(S.T, pm));
      if (S.startVis) s = Math.min(s, fvLen(fvSub(pm, S.startF)));
      if (S.touchSlab) s = Math.min(s, Math.abs(pm[2] - G.D) + G.hS);                 // (D3) la losa: se cruza despacio
      if (S.home && G.neb && pm[2] < G.zIn) s = Math.min(s, G.D - pm[2] + G.hS);      // (+ media losa: continua con la de la losa)
      // el tramo en que la foto se funde con las capas: continuo (dentro, FADE_K × PHOTO_FADE × D; fuera crece con pendiente 1)
      if (R.FADE_K > 0) s = Math.min(s, R.FADE_K * G.fade + Math.max(0, fvLen(pm) - G.zPhoto));
      if (s >= 1e29) s = fvLen(pm) + 0.004 * S.d0;
   }
   return Math.max(S.sFloor, s);
}
// la tabla del avance a lo largo de una curva c(λ), λ ∈ [0, 1]: tau = ∫ ds / escala, con paso adaptativo (≤ 1/2000 del camino y ≤ 2 % de
// la escala local). -> { tauTot, at(x): punto con fraccion de tau x, xOfLam(λ): fraccion de tau en λ }
// (nQ, ROUTE.VIS_LIP = k > 0) la ESCALA EFECTIVA g = escala visible / peso del ritmo con PENDIENTE ACOTADA: g(λ) ≤ g(λ') + k × camino
// entre ambos (envolvente de Lipschitz, dos pasadas sobre una primera muestra). Por que g y no la escala: con tau_eff = ∫ dℓ / g recorrido a
// ritmo c (1/s), v = c·g y d ln v / dt = c · dg/dℓ: la PENDIENTE de g es el ritmo al que se multiplica la velocidad. En el vacio g = escala /
// 0,45 tiene pendiente 2,2 (alejarse de algo); k = 2,2 deja eso igual y solo recorta lo mas brusco. Sin ella, al ATRAVESAR una estrella (R4:
// la de salida esta en la linea de vision de la nebulosa) la escala pasaba de 3 a 2 600 a.l. en medio a.l. al quedar la estrella detras, y la
// nave de arrastrarse 13 s a cruzar 1 400 a.l. en un segundo. -> function(q, λ) -> { s: escala sin tocar, g: escala efectiva acotada }
function fvRouteLipScale(curve, scaleFn, Lc, k, paceFn) {
   function raw(q) { var sc = scaleFn(q), w = paceFn ? paceFn(q, sc) : 1; return { s: sc, g: sc / Math.max(1e-6, w) }; }
   var Ls = [0], As = [0], r0 = raw(curve(0)), Es = [r0.g], Ss = [r0.s], l = 0, q0 = curve(0), a = 0, guard = 0;
   while (l < 1 && guard < 80000) {
      var dl = Math.max(1e-7, Math.min(1 / 2000, 0.02 * Ss[Ss.length - 1] / Math.max(1e-12, Lc), 1 - l));
      if (l + dl > 1) dl = 1 - l;
      var q1 = curve(l + dl), r1 = raw(q1); a += fvLen(fvSub(q1, q0)); l += dl; Ls.push(l); As.push(a); Es.push(r1.g); Ss.push(r1.s); q0 = q1; ++guard;
   }
   var N = Ls.length - 1, i;
   for (i = 1; i <= N; ++i) Es[i] = Math.min(Es[i], Es[i - 1] + k * (As[i] - As[i - 1]));
   for (i = N - 1; i >= 0; --i) Es[i] = Math.min(Es[i], Es[i + 1] + k * (As[i + 1] - As[i]));
   function find(v) { var lo = 0, hi = N; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (Ls[m] < v) lo = m; else hi = m; } return lo; }
   return function(q, lam) {
      var r = raw(q); if (!(N > 0)) return r;
      var lo = find(fvClamp(lam, 0, 1)), hi = Math.min(N, lo + 1), f = (Ls[hi] > Ls[lo]) ? (lam - Ls[lo]) / (Ls[hi] - Ls[lo]) : 0, al = As[lo] + f * (As[hi] - As[lo]);
      r.g = Math.min(r.g, Es[lo] + k * Math.max(0, al - As[lo]), Es[hi] + k * Math.max(0, As[hi] - al));
      return r;
   };
}
function fvRouteTau(curve, scaleFn, Lc, paceFn, lipK) {
   var lipFn = (lipK > 0) ? fvRouteLipScale(curve, scaleFn, Lc, lipK, paceFn) : null;
   var Lm = [0], Tm = [0], l = 0, acc = 0, q0 = curve(0), guard = 0;
   while (l < 1 && guard < 80000) {
      var r0 = lipFn ? lipFn(q0, l) : null, sc = r0 ? Math.min(r0.s, r0.g) : scaleFn(q0), dl = Math.max(1e-7, Math.min(1 / 2000, 0.02 * sc / Math.max(1e-12, Lc), 1 - l));
      // (nQ, I11) junto a una estrella que se pasa, el paso tambien por su distancia (la campana del ritmo es mas estrecha que la escala)
      if (paceFn && paceFn.stepCap) dl = Math.max(1e-7, Math.min(dl, paceFn.stepCap(q0) / Math.max(1e-12, Lc)));
      if (l + dl > 1) dl = 1 - l;
      var q1 = curve(l + dl), qm = curve(l + 0.5 * dl);
      if (lipFn) { acc += fvLen(fvSub(q1, q0)) / lipFn(qm, l + 0.5 * dl).g; l += dl; Lm.push(l); Tm.push(acc); q0 = q1; ++guard; continue; }
      var sm = scaleFn(qm);
      // (nQ, I11) con el peso del ritmo (paceFn): mas tiempo por unidad de tau cerca de algo, menos en el vacio
      acc += fvLen(fvSub(q1, q0)) / sm * (paceFn ? paceFn(qm, sm) : 1); l += dl; Lm.push(l); Tm.push(acc); q0 = q1; ++guard;
   }
   var N = Lm.length - 1;
   function find(arr, v) { var lo = 0, hi = N; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (arr[m] < v) lo = m; else hi = m; } return lo; }
   return { tauTot: acc,
            at: function(x) {
               if (!(acc > 0) || x <= 0) return curve(x >= 1 ? 1 : 0);
               if (x >= 1) return curve(1);
               var tt = x * acc, lo = find(Tm, tt), hi = lo + 1, f = (Tm[hi] > Tm[lo]) ? (tt - Tm[lo]) / (Tm[hi] - Tm[lo]) : 0;
               return curve(Lm[lo] + f * (Lm[hi] - Lm[lo]));
            },
            xOfLam: function(lam) {
               if (!(acc > 0)) return fvClamp(lam, 0, 1);
               if (lam <= 0) return 0; if (lam >= 1) return 1;
               var lo = find(Lm, lam), hi = lo + 1, f = (Lm[hi] > Lm[lo]) ? (lam - Lm[lo]) / (Lm[hi] - Lm[lo]) : 0;
               return (Tm[lo] + f * (Tm[hi] - Tm[lo])) / acc;
            } };
}
// el tope A del viaje de cine o de la vuelta en (pos, look): mientras se pinta la foto, siempre; despues (las capas) hasta entrar en la
// losa, solo si el destino cae en la parte LIMPIA de las capas (si no, A' es imposible por geometria: R14). Destino en el borde
// oscurecido: contra la foto ENTERA mientras se pinta
function fvRouteCapA(P, S, pos, look) {
   var G = S.G;
   if (!(look[2] > 0.1)) return 1e9;
   if (fvLen(pos) < G.zPhoto || ((S.tClean || FV_PILOT.ROUTE.EDGE_WHOLE) && pos[2] < G.zIn)) return fvRouteCover(P, G, pos, look, !S.tClean);   // (nF2) EDGE_WHOLE
   return 1e9;
}
// (nQ, encargo de Mirabilia; ROUTE.FOV1_PLAN) EL CAMPO DE LLEGADA que vuela el plan, barato (sin estrellas ni tiempos): ~72 puntos del
// camino (apretados en la salida, donde la foto da los topes mas estrechos, y en la llegada); en cada uno el campo abre con beta (B: lo que
// se acerca al destino) y se queda en el tope A con la mirada del encuadre (biseccion, como capFix: la mirada depende del campo). Lo que no
// ve: el cierre de I9 (EVENTS; el plan vuelve despues al campo sin I9) y el ritmo FOV_RATE. -> tan del medio campo
function fvRouteArriveTan(P, S, G) {
   var N = 48, lt = Math.log(S.tanS), ltA = Math.log(G.tanArr), TL = S.TL, SG = S.sight, j, ls = [];
   var curveF = SG ? SG.curve.at : function(l) { return fvLerp(S.p0, S.p1, l); };
   var dPrev = Math.max(1e-12, fvLen(fvSub(TL, S.p0))), dS = dPrev, dE = Math.max(1e-12, fvLen(fvSub(TL, S.p1))), lnR = Math.log(Math.max(1.000001, dS / dE));
   // el encuadre va con la fraccion de tau del plan, que con escala ≈ distancia es la del ln de la distancia recorrida
   function lookAt(p, x, tf) {
      var oE = S.side * (S.edgeX ? S.edgeX : (S.centered ? 0 : fvRouteThird(tf))), sm = fvSmoother(x), ox = fvMix(S.o0c[0], oE, sm) * tf, oy = fvMix(S.o0c[1], S.edgeY || 0, sm) * tf;
      if (SG) { var ph = fvSightDir(p) || S.dirv; return fvAimAt(p, fvAdd(p, fvMul(ph, Math.max(1, fvLen(fvSub(TL, p))))), ox, oy); }
      return fvAimAt(p, TL, ox, oy);
   }
   // puntos igual de espaciados en ln d (la recta) o apretados hacia la llegada (la curva I6), y 24 en ln del camino desde la salida
   for (j = 1; j <= N; ++j) ls.push(SG ? 1 - Math.pow(1 - j / N, 4) : fvClamp((dS - dS * Math.pow(dE / dS, j / N)) / Math.max(1e-12, dS - dE), 0, 1));
   for (j = 0; j < 24; ++j) ls.push(Math.pow(1e-4, 1 - j / 24));
   ls.sort(function(a, b) { return a - b; });
   for (j = 0; j < ls.length; ++j) {
      var l = ls[j], p = curveF(l), d = Math.max(1e-12, fvLen(fvSub(TL, p))), r = Math.log(dPrev / d), xF = fvClamp(Math.log(Math.max(1, dS / d)) / lnR, 0, 1);
      if (SG) xF = Math.max(xF, l * l);
      if (r > 0) lt = Math.min(ltA, lt + S.beta * r);
      else if (!SG) lt += r;
      dPrev = d;
      var tf = Math.exp(lt), c = fvRouteCapA(P, S, p, lookAt(p, xF, tf));
      if (c < 1e9 && !(c > 0 && tf <= c * (1 + 1e-9))) {
         var lo = 0, hi = tf, okLo = false;
         for (var it = 0; it < 28; ++it) { var mid = 0.5 * (lo + hi), cm = fvRouteCapA(P, S, p, lookAt(p, xF, mid)); if (cm > 0 && mid <= cm) { lo = mid; okLo = true; } else hi = mid; }
         if (okLo) lt = Math.log(Math.max(1e-12, lo));
         else if (c > 0) lt = Math.log(c);
      }
   }
   return Math.exp(lt);
}
// (nQ, para Mirabilia: fv_objects.js fvObjArriveFit) EL CAMPO DE LLEGADA de un viaje a sel desde la camara de P (kind por defecto "travel").
// exact false: el estimado barato de fvRouteSetup (fl.fov1; ~3–5 ms; medido en 71 destinos de IC 1848 desde casa: estrellas ≤ ×1,011, la
// nebulosa ×1,06 sin I9 y ×1,32 con I9, que cierra en la llegada). exact true: PLANIFICA el viaje (fvRoutePlan, sin volarlo; 0,2–0,4 s en
// node) y devuelve el campo del ultimo fotograma: el que se vuela. Deja P sin vuelo (usar con un piloto de usar y tirar). -> rad (0 si no arranca)
function fvPilotArriveFov(P, sel, exact, kind) {
   if (!fvPilotFly(P, kind || "travel", sel) || !P.flight) { P.flight = null; return 0; }
   var fl = P.flight, f = fl.fov1 || 0;
   if (exact && fl.route && !fl.route.home) { var pl = fvRoutePlan(P, fl); if (pl && pl.n > 0) f = 2 * Math.atan(Math.exp(pl.lt[pl.n])); }
   else if (exact && fl.kind === "warp" && typeof fvRouteWarpPlan === "function" && FV_PILOT.ROUTE.WARP) { var pw = fvRouteWarpPlan(P, fl); if (pw && pw.n > 0) f = 2 * Math.atan(Math.exp(pw.lt[pw.n])); }
   P.flight = null;
   return f;
}
// el viaje de cine o la vuelta a casa con la ley nueva: fija fl.route (la especificacion) y fl.dur. Barato (sin plan ni estrellas).
function fvRouteSetup(P, fl, sel, startF, skip) {
   var R = FV_PILOT.ROUTE, G = fvRouteGeo(P), cam = P.cam, home = fl.kind === "home", ky = P.VH / P.VW;
   var p0 = cam.pos.slice(), look0 = fvNorm(cam.look), tan0 = Math.tan(cam.fov / 2);
   var S = { G: G, home: home, p0: p0, look0: look0, tan0: tan0, startF: startF.slice(), skip: skip };
   if (home) {
      S.T = [0, 0, 0]; S.p1 = [0, 0, 0]; S.d0 = fvLen(p0); S.dirv = S.d0 > 0 ? fvMul(p0, -1 / S.d0) : [0, 0, -1]; S.beta = 0; S.tClean = true;
      S.lookS = fvNorm(fvSub(fvRouteHomeTL(G, p0), p0)); S.tanS = tan0; S.panDeg = fvAngle(look0, S.lookS) / FV_DEG;
      // (la panoramica de la vuelta, nunca mas corta que PAN_MIN_S: con 0,85° en 0,08 s salia un tiron de 444 °/s²)
      S.pre = S.panDeg > 0.01 ? fvClamp(1.875 * S.panDeg / (R.HOME_PAN_DPS || R.PAN_DPS), R.PAN_MIN_S, R.HOME_PAN_MAX_S || 1e9) : 0;
      var cl = Math.max(0, Math.log(cam.fov / P.homeFov) / Math.LN10);
      S.travelS = FV_PILOT.HOME_S + fvClamp(FV_PILOT.HOME_CLOSE_DEC * cl, cl > 0.02 ? 1.0 : 0, FV_PILOT.HOME_CLOSE_MAX);
      // (K11b H-2, Codex; decision del coordinador) EL GIRO A LA VEZ QUE EL AVANCE: sin panoramica quieta; la mirada va de la de ahora a
      // la de casa (smootherstep) en turnS = 1,875·giro / HOME_TURN_DPS (pico ≤ 25 °/s), con aceleracion ≤ HOME_TURN_DPS2 (30 °/s², lo que
      // ya cumplia la vuelta, §7) y nunca menos de PAN_MIN_S; tope HOME_TURN_MAX_S 9 s (180° -> pico 37,5 °/s; con el tope de 5 s de la
      // panoramica quieta eran 67,5 °/s). El viaje dura al menos turnS. HOME_PAN_MOVE false = ROJO (panoramica quieta antes)
      if (R.HOME_PAN_MOVE) {
         S.turnS = S.panDeg > 0.01 ? fvClamp(Math.max(1.875 * S.panDeg / R.HOME_TURN_DPS, Math.sqrt(5.7735 * S.panDeg / R.HOME_TURN_DPS2)), R.PAN_MIN_S, R.HOME_TURN_MAX_S) : 0;
         S.pre = 0; S.travelS = Math.max(S.travelS, S.turnS);
      }
      fl.T = [0, 0, 0]; fl.p1 = [0, 0, 0]; fl.look1 = [0, 0, 1]; fl.fov1 = P.homeFov;
   } else {
      var T = fvSelPos(P, sel), TL = fvSelLookAt(P, sel, T), dA = (typeof fvBoxArrive === "function") ? fvBoxArrive(P, sel, T, fvArriveDist(P, sel)) : fvArriveDist(P, sel), d0 = fvLen(fvSub(T, p0));
      var dirv = d0 > 1e-12 ? fvMul(fvSub(T, p0), 1 / d0) : look0;
      S.T = T; S.TL = TL; S.dA = dA; S.d0 = d0; S.dirv = dirv; S.p1 = fvSub(T, fvMul(dirv, dA));
      // (R8, 12-nov) MIRABILIA: un objeto tan grande que con el tercio no cabe entero (nebulosa que llena la foto) se encuadra CENTRADO (fvObjectTarget.centered)
      S.centered = !!(sel && sel.kind === "object" && (function() { var ot = fvSelObjectTarget(P, sel); return ot && ot.centered; })());
      var u = T[2] > 0 ? T[0] * G.D / T[2] / G.HW : 9, v = T[2] > 0 ? T[1] * G.D / T[2] / G.HH : 9;
      S.uT = u; S.fgLike = G.neb && T[2] > 0 && T[2] < G.zIn && Math.abs(u) < 1 && Math.abs(v) < 1;
      S.tClean = T[2] > 0 && Math.abs(u) < G.kc0[0] && Math.abs(v) < G.kc0[1];
      // (nQ, I6) la linea de vision del destino: llegada en ella; cruzar o subir si hace falta (S.sight); en un viaje I6 lo que se lleva en
      // pantalla es la LINEA DE VISION PROPIA (aimPt: un punto de ella delante de la camara), no el destino
      fvSightSetup(P, S, G, T, TL, dA, startF);
      var aimPt = S.sight ? fvAdd(p0, fvMul(fvSightDir(p0), Math.max(1, fvLen(fvSub(TL, p0))))) : TL;
      // (nQ, EDGE_FRAME) destino fuera de la parte limpia: encuadre hacia DENTRO de la foto (EDGE_X medios anchos del lado de su borde)
      // (y, encargo de Mirabilia) tambien con el destino LIMPIO pero a mas de EDGE_NEAR del borde limpio (objetos de borde: llegaban a 0,08°),
      // y en vertical (edgeY, con signo, en medios anchos) si el borde cercano es el de arriba o abajo
      // SOLO ESTRELLAS (DECIDIDO SIN NINO): un objeto extenso a 0,8 medios altos del centro se sale de la pantalla (llega ocupando hasta 0,46
      // del campo, contrato de Mirabilia con el TERCIO); fv_nC2_mirabilia_test lo vio: C 0255+602 y LEDA 3086325 encuadrados 288 px fuera
      // del tercio. Los objetos siguen con el tercio
      var nXe = Math.abs(u) / G.kc0[0], nYe = Math.abs(v) / G.kc0[1], nearE = R.EDGE_FRAME && T[2] > 0 && G.neb && (!sel || sel.kind === "star") && (!S.tClean || nXe > R.EDGE_NEAR || nYe > R.EDGE_NEAR);
      if (nearE && R.EDGE_FRONT && !(S.p1[2] < G.zIn)) nearE = false;   // (pasada S) llegada detras de la losa: sin foto delante, el tercio
      S.edgeX = (nearE && (nXe > R.EDGE_NEAR || (!S.tClean && nXe >= nYe))) ? R.EDGE_X : 0;
      S.edgeY = (nearE && nYe > R.EDGE_NEAR) ? (v >= 0 ? 1 : -1) * R.EDGE_X * ky : 0;
      // (nQ, VIS_ONSCR) la escala visible pide P (el tope A) y si hay origen
      if (R.VIS_ONSCR) { S.visP = P; S.startOk = fvLen(fvSub(S.startF, p0)) > 1e-6 && fvLen(p0) > 1e-6; }
      // el plano de salida como PUNTO FIJO (mirada, campo): el destino se queda en su sitio del cielo mientras el campo se cierra lo que
      // pida A, y solo si se saldria del cuadro se le reencuadra (±SKY_CLAMP del medio ancho)
      var sky = fvScreenTan(p0, look0, aimPt);
      S.onScr = !!sky && Math.abs(sky[0]) <= tan0 && Math.abs(sky[1]) <= tan0 * ky;
      S.sky = sky || [0, 0];
      var tanS = tan0, o0c = [0, 0], lookS = look0;
      for (var it = 0; it < 200; ++it) {          // (punto fijo de razon ~SKY_CLAMP: 24 vueltas dejaban un 0,5 %; ver capFix)
         o0c = [fvClamp(S.sky[0] / tanS, -R.SKY_CLAMP, R.SKY_CLAMP), fvClamp(S.sky[1] / tanS, -R.SKY_CLAMP * ky, R.SKY_CLAMP * ky)];
         lookS = fvAimAt(p0, aimPt, o0c[0] * tanS, o0c[1] * tanS);
         var cS = fvRouteCapA(P, S, p0, lookS), tN = cS > 0 ? Math.min(tan0, cS) : tanS;
         if (tN >= tanS * (1 - 1e-9)) break;
         tanS = tN;
      }
      S.tanS = tanS; S.o0c = o0c; S.lookS = lookS; S.panDeg = fvAngle(look0, lookS) / FV_DEG; S.aimPt0 = aimPt;
      // (nQ, I6/I9) al SUBIR (destino detras) la mirada ya es la buena (la linea de vision propia): sin los 2,5 s quietos de la panoramica
      S.pre = Math.max((S.sight && S.sight.mode === "R") ? R.SIGHT_PRE : FV_PILOT.CINE_PRE, 1.875 * S.panDeg / R.PAN_DPS);
      // (6-nov, FAST_EASE) el plano quieto: FAST.PRE (o lo que pida la panoramica, como antes), × el regulador
      // y nunca menos de lo que tarda el campo en cerrarse al de salida (tanS, el tope A con la mirada de la panoramica) a FOV_RATE: con 0,5 s
      // (antes 2,5) un destino junto al borde de la foto dejaba ver fuera de ella 0,4 s al girar hacia el (fv_nF2_node «borde»: 5 % de pantalla)
      if (fvFastOn()) S.pre = Math.max(Math.max((S.sight && S.sight.mode === "R") ? Math.min(R.SIGHT_PRE, FV_PILOT.FAST.PRE) : FV_PILOT.FAST.PRE, 1.875 * S.panDeg / R.PAN_DPS) * fvSpeedDurK(P),
                                       1.875 * Math.abs(Math.log(tan0 / tanS)) / R.FOV_RATE);
      // (nQ, I6) la duracion por las decadas de escala del recorrido entero (subir + bajar: WWT), con el mismo minimo, pendiente y tope
      var decT = S.sight ? S.sight.dec : Math.log(Math.max(1, d0 / dA)) / Math.LN10;
      S.travelS = fvClamp(FV_PILOT.CINE_S_MIN + FV_PILOT.CINE_S_DEC * decT, FV_PILOT.CINE_S_MIN, FV_PILOT.CINE_S_MAX) * fvSpeedDurK(P) * (fvFastOn() ? FV_PILOT.FAST.DUR_K : 1);
      // beta efectivo: no mas del que hace falta para llegar a ARRIVE_FOV con toda la escala del viaje (C1); en un viaje I6, la de la bajada
      var dBeta = S.sight ? S.sight.dTop : d0;
      var beta = S.fgLike ? 0 : Math.max(0, R.BETA), need = Math.log(G.tanArr / tanS), avail = Math.log(Math.max(1.000001, dBeta / dA));
      S.beta = (beta > 0 && need > 0) ? Math.min(beta, need / avail) : 0;
      S.side = (R.THIRD_INSIDE && u >= 0) ? 1 : -1;
      if (S.edgeX) S.side = (u >= 0) ? 1 : -1;                     // (nQ, EDGE_FRAME) del lado de su borde: el centro de la pantalla, hacia dentro
      // (nQ, I11) el ritmo: escalas de referencia (en log) del viaje y las estrellas que se pasan de verdad cerca (PACE_PASS_K × su llegada)
      if (R.PACE && FV_PILOT.CINE_VARY) { S.paceLo = Math.log(Math.max(1e-9, 2 * dA)); S.paceHi = Math.log(Math.max(4 * dA, 0.5 * Math.max(d0, S.sight ? S.sight.dTop : 0))); }
      var tanE = Math.min(G.tanArr, tanS * Math.pow(Math.max(1, dBeta / dA), S.beta));
      // (nQ, encargo de Mirabilia) el campo de llegada como lo VUELA el plan: los topes A del camino (y el de la propia llegada) con el
      // ritmo de abrir beta (fvRouteArriveTan). Antes solo el de salida y beta: hasta ×10 por encima (fv_nQ_fov1_node.js). false = ROJO
      if (R.FOV1_PLAN) { S.beta0 = S.beta; tanE = Math.min(tanE, fvRouteArriveTan(P, S, G)); }
      fl.T = T; fl.Tlook = TL; fl.arrive = dA; fl.p1 = S.p1.slice(); fl.fov1 = 2 * Math.atan(tanE); fl.beta = S.beta;
      fl.look1 = fvAimAt(S.p1, TL, S.side * (S.edgeX ? S.edgeX * tanE : (S.centered ? 0 : Math.tan(FV_PILOT.FRAME_THIRD * fl.fov1))), (S.edgeY || 0) * tanE);   // (estimada; la de verdad sale del plan)
      fl.sight = S.sight ? S.sight.mode : (R.SIGHT ? "F" : "");
      fl.speed = P.speed;
   }
   fl.route = S; fl.cinePre = S.pre; fl.travelS = S.travelS; fl.turnDeg = S.panDeg; fl.dur = S.pre + S.travelS; fl.adv = false;
   return true;
}
// EL PLAN del viaje de cine o de la vuelta (en el primer paso): fl.plan = { dt, n, tEnd, pos[], look[], lt (ln tan del medio campo) }
function fvRoutePlan(P, fl) {
   var S = fl.route, R = FV_PILOT.ROUTE, G = S.G, dt = R.PLAN_DT, dur = fl.dur, n = Math.max(1, Math.ceil(dur / dt - 1e-9)), k, ky = P.VH / P.VW;
   if (S.arc === undefined) S.arc = (S.home || S.sight) ? null : fvRouteArc(P, S.p0, S.p1, S.skip);
   var arc = S.arc, p0 = S.p0, p1 = S.p1, SG = S.sight;
   if (arc) fl.avoided = 1;
   // (nQ, I6) el viaje por la linea de vision: su curva por trozos (cruzar o subir-U-bajar); si no, la recta (o el arco) de siempre
   function curve(l) { if (SG) return SG.curve.at(l); var p = fvLerp(p0, p1, l); return arc ? fvAdd(p, fvMul(arc.n, 4 * l * (1 - l) * arc.h)) : p; }
   var zLo = Math.min(p0[2], p1[2]), zHi = Math.max(p0[2], p1[2]);
   if (SG) for (k = 0; k <= 64; ++k) { var zq = curve(k / 64)[2]; zLo = Math.min(zLo, zq); zHi = Math.max(zHi, zq); }
   S.touchSlab = G.neb && zLo <= G.zOut && zHi >= G.zIn;
   var dirFwd = S.home ? S.lookS : S.dirv;
   S.startVis = fvLen(fvSub(S.startF, p0)) > 1e-6 && fvDot(fvSub(S.startF, p0), dirFwd) > 0;
   S.sFloor = 1e-3 * Math.max(1e-9, S.d0);
   // (nQ, I11) las estrellas que el camino pasa de verdad cerca (≤ PACE_PASS_K × su distancia de llegada): alli el ritmo baja (como cerca de algo)
   if (R.PACE && S.paceLo && !S.home && S.passes === undefined) S.passes = fvRoutePasses9(P, S, curve);
   var TT = fvRouteTau(curve, function(q) { return fvRouteVisScale(S, G, q); }, Math.max(1e-12, SG ? SG.curve.len : fvLen(fvSub(p1, p0))),
                       (R.PACE && S.paceLo && !S.home) ? fvRoutePaceFn(S) : null, (S.visP && !S.home) ? (R.VIS_LIP || 0) : 0);
   S.tauTot = TT.tauTot;
   var pos = new Array(n + 1), look = new Array(n + 1), LT = new Float64Array(n + 1), UB = new Float64Array(n + 1), AC = new Float64Array(n + 1);
   var W = new Float64Array(n + 1), X = new Float64Array(n + 1), PW = new Float64Array(n + 1), pre = new Uint8Array(n + 1), dTL = new Float64Array(n + 1);
   var lt0 = Math.log(S.tan0), ltS = Math.log(S.tanS), ltH = Math.log(Math.tan(P.homeFov / 2)), ltArr = Math.log(G.tanArr), RD = R.FOV_RATE * dt;
   for (k = 0; k <= n; ++k) {
      var t = (k === n) ? dur : k * dt;
      if (k === 0 || t < S.pre) {
         var w0 = S.pre > 0 ? fvSmoother(t / S.pre) : 1;
         pos[k] = p0; X[k] = 0; pre[k] = 1; PW[k] = w0; UB[k] = S.home ? lt0 : fvMix(lt0, ltS, w0);
      } else {
         var x = fvCineX(fvClamp((t - S.pre) / S.travelS, 0, 1));
         X[k] = x; pos[k] = TT.at(x); UB[k] = S.home ? fvMix(ltS, ltH, fvSmoother(x)) : ltArr;
      }
      dTL[k] = S.home ? 1 : Math.max(1e-12, fvLen(fvSub(S.TL, pos[k])));
      AC[k] = 1e9;
   }
   var lim0x = Math.max(R.SKY_CLAMP, Math.abs(S.sky ? S.sky[0] / S.tan0 : 0)), lim0y = Math.max(R.SKY_CLAMP * ky, Math.abs(S.sky ? S.sky[1] / S.tan0 : 0));
   var CAP_SAFE = !!R.CAP_SAFE;
   S.capN = 0; S.capMiss = 0; S.capResid = 0;
   function lookOf(k, tanF, w) {
      var p = pos[k];
      if (S.home) {
         if (pre[k]) return fvSlerpDir(S.look0, S.lookS, PW[k]);
         var hd = fvNorm(fvSub(fvRouteHomeTL(G, p), p));
         return S.turnS > 0 ? fvSlerpDir(S.look0, hd, fvSmoother(((k === n) ? dur : k * dt) / S.turnS)) : hd;   // (K11b H-2) giro durante el avance
      }
      if (pre[k]) {
         if (!S.onScr) return fvSlerpDir(S.look0, S.lookS, PW[k]);
         // destino ya en cuadro: se queda en su sitio del cielo; el limite del reencuadre pasa de donde esta a ±SKY_CLAMP (sin salto inicial)
         var Lx = fvMix(lim0x, R.SKY_CLAMP, PW[k]), Ly = fvMix(lim0y, R.SKY_CLAMP * ky, PW[k]);
         return fvAimAt(p, S.aimPt0 || S.TL, fvClamp(S.sky[0], -Lx * tanF, Lx * tanF), fvClamp(S.sky[1], -Ly * tanF, Ly * tanF));
      }
      // (nQ, EDGE_FRAME) el encuadre final: el tercio, o EDGE_X hacia dentro si el destino esta en el borde oscurecido
      var oE = S.side * (S.edgeX ? S.edgeX : (S.centered ? 0 : fvRouteThird(tanF)));
      if (SG) {
         // (nQ, I6) la LINEA DE VISION PROPIA en el sitio del encuadre (w = 0: al centro, lo mas seguro para A); en la bajada es el destino
         var phk = fvSightDir(p) || S.dirv, s3 = fvSmoother(X[k]), Lr = Math.max(1, fvLen(fvSub(S.TL, p)));
         return fvAimAt(p, fvAdd(p, fvMul(phk, Lr)), fvMix(S.o0c[0], oE, s3) * w * tanF, fvMix(S.o0c[1], S.edgeY || 0, s3) * w * tanF);
      }
      var s2 = fvSmoother(X[k]) * w;
      return fvAimAt(p, S.TL, fvMix(S.o0c[0], oE, s2) * tanF, fvMix(S.o0c[1], S.edgeY || 0, s2) * tanF);
   }
   // (nQ, I6) ¿el destino en cuadro? (para B y I9 en un viaje por la linea de vision: mientras no se ve, no puede encoger)
   var visT = null;
   if (SG) { visT = new Uint8Array(n + 1); for (k = 0; k <= n; ++k) visT[k] = fvRouteVisW(P, S, G, pos[k], S.TL) >= 0.5 ? 1 : 0; }
   // el paso maximo del ln tan de k−1 a k: ritmo de beta, B y el ritmo de abrir
   // (nQ, I9) LTref: el plan sin I9; tras un cierre de I9 el campo VUELVE hacia el (abriendo lo que deje crecer al destino ×2 cada
   // EVENT_S s, g9 por paso) en vez de quedarse por debajo con el ritmo beta: el cierre es local y el campo de llegada el de siempre
   var LTref = null, g9 = 1.05 * Math.LN2 / Math.max(1e-3, R.EVENT_S || 8) * dt;
   function inc(k) {
      if (S.home) return RD;
      if (visT && !(visT[k] && visT[k - 1])) return RD;
      var r = Math.log(dTL[k - 1] / dTL[k]), b = S.beta * r;
      if (LTref && S.beta > 0 && LT[k - 1] < LTref[k - 1] - 1e-9) b = Math.max(b, Math.min(r - g9, LTref[k] - LT[k - 1]));
      return Math.min(RD, b, r);
   }
   function capOf(k, lk) { var c = fvRouteCapA(P, S, pos[k], lk); return c > 0 ? Math.log(c) : (c === 1e9 ? 1e9 : -1e9); }
   // el mayor tan ≤ tf que cabe en el tope A con la mirada que le toca (la mirada depende del campo: el destino se encuadra en unidades
   // de la pantalla). El punto fijo «tf = tope(mirada(tf))» convergia despacio (razon ~ el encuadre, 0,8–0,95 en la panoramica con el
   // destino en cuadro): con 1–8 vueltas el plan quedaba hasta un 1,2 % por encima del tope (cine al borde: una columna de cielo fuera
   // de la foto en la panoramica). Biseccion: tope(mirada(tf)) − tf baja con tf. -> { tf, lk, cv } (cv ≤ 0: el eje sale; 1e9: no aplica)
   // (K11b, Codex) SIN SOLUCION (ningun tf de la biseccion cabe) se devolvia el campo PEDIDO con su tope (cv > 0, tf > cv) y el bucle
   // del encuadre lo daba por bueno. CAP_SAFE: devuelve «sin solucion» (cv −1, none) y el que llama baja el encuadre w como cuando el eje
   // sale (el camino seguro que ya existia). Medido en 156 viajes de la escena real (52 destinos en rejilla u,v hasta ±1,05; casa->,
   // ->siguiente, ->casa): 4 855 de 26 443 biseccciones sin solucion en 32 viajes, todos con el destino en el borde de la foto o fuera; los
   // fotogramas que acaban incumpliendo A (581, en 31 viajes) son los MISMOS con y sin esto: el campo ya se cierra a FOV_RATE detras de un
   // tope que huye (mirada del tercio ∝ campo -> tope ≈ c·campo, c < 1). Las «alternativas seguras» literales se midieron y EMPEORAN:
   // sostener la mirada y cerrar a su tope, 3 948 fotogramas fuera y campo hasta e^−25,8 (antes e^−15,6); deslizar la mirada hacia el
   // centro, el destino a 349 medios anchos fuera de cuadro. Un barrido geometrico del campo (por si lo factible no empieza en 0) no
   // encontro ni un caso. Lo que queda se AVISA en fl.warnings (abajo). false = ROJO (lo de antes)
   function capFix(k, tf, w) {
      var lq = lookOf(k, tf, w), cv = fvRouteCapA(P, S, pos[k], lq);
      if (cv >= 1e9 || (cv > 0 && tf <= cv * (1 + 1e-9))) return { tf: tf, lk: lq, cv: cv };
      ++S.capN;
      var lo = 0, hi = tf, lLo = null, cLo = -1;
      for (var it = 0; it < 48; ++it) {
         var mid = 0.5 * (lo + hi), lm = lookOf(k, mid, w), cm = fvRouteCapA(P, S, pos[k], lm);
         if (cm > 0 && mid <= cm) { lo = mid; lLo = lm; cLo = cm; } else hi = mid;
      }
      if (lLo) return { tf: lo, lk: lLo, cv: cLo };
      ++S.capMiss;
      return CAP_SAFE ? { tf: tf, lk: lq, cv: -1, none: true } : { tf: tf, lk: lq, cv: cv };
   }
   // 1. hacia delante: ley, tope A iterado con la mirada y el encuadre w (que solo baja)
   var preCap = fvRouteCapA(P, S, p0, S.look0) > 0, wCur = 1, soft = true, noA = 0;
   LT[0] = lt0; look[0] = S.look0; W[0] = 1;
   for (k = 1; k <= n; ++k) {
      var Lk = Math.min(UB[k], LT[k - 1] + inc(k)), tanF = Math.exp(Lk), lk = null, capL = 1e9;
      if (pre[k]) {
         lk = lookOf(k, tanF, 1);
         // (en la panoramica, el tope de A solo si el plano de salida ya lo cumplia: si no —volver de una estrella del borde— el tope daba un
         // hueco de un fotograma al pasar el eje por el filo)
         if (preCap) { var tIn = tanF, cf0 = capFix(k, tanF, 1); if (cf0.cv > 0 && cf0.cv < 1e9) { tanF = cf0.tf; lk = cf0.lk; capL = Math.log(cf0.tf < tIn ? cf0.tf : cf0.cv); } }
         W[k] = 1;
      } else {
         var ok = false;
         for (var wT = wCur; wT >= -1e-9; wT -= 0.05) {
            var wq = Math.max(0, wT), tf = Math.exp(Lk), lq = lookOf(k, tf, wq), good = true, cv = fvRouteCapA(P, S, pos[k], lq);
            if (cv <= 0) good = false;
            else if (cv < 1e9 && tf > cv * (1 + 1e-9)) { var cfw = capFix(k, tf, wq); if (!(cfw.cv > 0) || !(cfw.tf > 0)) good = false; else { tf = cfw.tf; lq = cfw.lk; cv = cfw.cv; } }
            if (good) { wCur = wq; tanF = tf; lk = lq; capL = cv < 1e9 ? Math.log(cv) : 1e9; ok = true; break; }
         }
         if (!ok) { wCur = 0; lk = lookOf(k, tanF, 0); var c2 = fvRouteCapA(P, S, pos[k], lk); if (c2 > 0) { tanF = Math.min(tanF, c2); capL = c2 < 1e9 ? Math.log(c2) : 1e9; } ++noA; }
         W[k] = wCur;
      }
      var L2 = Math.log(tanF);
      // (K9 H-2) si se sale con un campo mayor que el tope (interrumpir algo con mucho campo), se cierra como mucho a FOV_RATE: sin salto
      if (soft && L2 < LT[k - 1] - RD) L2 = LT[k - 1] - RD; else soft = false;
      LT[k] = L2; look[k] = lk; AC[k] = capL;
   }
   if (S.home) UB[n] = ltH;
   // 2. el cierre planificado hacia atras (cerrar ANTES de llegar al tope, ≤ FOV_RATE) y otra vez hacia delante (B, ritmo, beta); la
   //    mirada se rehace con el campo final y se comprueba A otra vez (hasta 5 vueltas)
   function dn() { return RD; }
   for (var round = 0; round < 5; ++round) {
      fvRoutePasses(LT, UB, AC, inc, dn, n, S.home ? ltH : undefined);
      // (casa) desde su minimo el campo solo se abre hasta la vista de casa: sin el «respiro» abre–cierra–abre que dejaba el tope de la
      // parte limpia al cambiar la mezcla capas/foto (casa desde delante: 0,39 -> 0,68 -> 0,60 -> 0,76°). Solo baja valores: A, el
      // ritmo y el final fijo se siguen cumpliendo
      if (S.home) { var kMin = 1; for (k = 2; k < n; ++k) if (LT[k] < LT[kMin]) kMin = k; for (k = n - 1; k >= kMin; --k) if (LT[k] > LT[k + 1]) LT[k] = LT[k + 1]; }
      var bad = 0;
      for (k = 1; k <= n; ++k) {
         look[k] = lookOf(k, Math.exp(LT[k]), W[k]);
         if (pre[k] && !preCap) continue;
         var cN = capOf(k, look[k]);
         if (cN < 1e9 && cN > -1e9 && LT[k] > cN + 1e-9 && !(S.home && k === n)) {
            var cfv = capFix(k, Math.exp(LT[k]), W[k]);
            AC[k] = Math.min(AC[k], cfv.cv > 0 && cfv.tf > 0 ? Math.log(cfv.tf) : cN); ++bad;
         }
      }
      if (!bad) break;
   }
   // 2b. (nQ, I9) CADA ≤ EVENT_S s PASA ALGO (cine): si en EVENT_S s no se ha pasado junto a una estrella de la huella (S.passes, en cuadro)
   //     ni el destino EN CUADRO ha doblado su escala en pantalla 1/(tan·d), el campo se cierra lo justo para que la doble. Solo BAJA el
   //     campo (A y B se siguen cumpliendo; las pasadas reparten el cierre hacia atras a FOV_RATE); suelo: 4 × por debajo del campo mas
   //     estrecho del plan sin esto. Con el destino fuera de cuadro no se puede: el hueco que quede va a plan.gap9 (y a fl.warnings si > EVENT_S)
   var gap9 = 0, ev9N = 0;
   if (R.EVENTS && !S.home && R.EVENT_S > 0 && fl.kind === "cine") {
      var K8 = Math.max(1, Math.round(R.EVENT_S / dt)), vis9 = new Uint8Array(n + 1), ev9 = new Uint8Array(n + 1), lt9 = 1e9;
      LTref = Float64Array.from(LT);
      for (k = 0; k <= n; ++k) lt9 = Math.min(lt9, LT[k]);
      lt9 -= Math.log(4);
      // (nQ, ROUTE.EVENT_KEEP) destino EXTENSO (nebulosa, objetos; no estrellas): el cierre de I9 no puede dejar el campo de llegada por
      // debajo de EVENT_KEEP × el planeado. rec9[k] = lo que el campo puede reabrir de k al final por encima del plan sin I9 (la reapertura
      // de inc: hasta r − g9 por paso, frente a beta·r del plan). Medido en el montaje real (R4 estrella -> nebulosa): la llegada quedaba a
      // 1,6° frente a 4,1° antes (dos cierres ×2 que la llegada no podia deshacer) y la ultima toma era un parche cian sin estructura.
      // Con estrellas manda I9 (beta 0: un cierre es para siempre; la llegada mas cerrada es la estrella mas grande). DECIDIDO SIN NINO
      var rec9 = null, keep9 = (R.EVENT_KEEP > 0 && fl.sel && fl.sel.kind !== "star") ? Math.log(1 / R.EVENT_KEEP) : -1;
      if (keep9 >= 0) {
         rec9 = new Float64Array(n + 1);
         for (k = n; k >= 1; --k) { var rr9 = Math.log(dTL[k - 1] / dTL[k]), ex9 = (S.beta > 0 && (!visT || (visT[k] && visT[k - 1]))) ? Math.max(0, Math.min(RD, rr9 - g9) - (LTref[k] - LTref[k - 1])) : 0; rec9[k - 1] = rec9[k] + ex9; }
      }
      for (var it9 = 0; it9 < 8; ++it9) {
         for (k = 0; k <= n; ++k) {
            var tf9 = Math.exp(LT[k]), sc9 = fvScreenTan(pos[k], look[k], S.TL);
            vis9[k] = (sc9 && Math.abs(sc9[0]) <= tf9 && Math.abs(sc9[1]) <= tf9 * ky) ? 1 : 0; ev9[k] = 0;
         }
         var PS9 = S.passes || [];
         for (var e9 = 0; e9 < PS9.length; ++e9) {
            var bk = -1, bd = 1e30;
            for (k = 1; k <= n; ++k) {
               var tfe = Math.exp(LT[k]), sce = fvScreenTan(pos[k], look[k], PS9[e9].p);
               if (!sce || Math.abs(sce[0]) > tfe || Math.abs(sce[1]) > tfe * ky) continue;
               var de = fvLen(fvSub(PS9[e9].p, pos[k]));
               if (de < bd) { bd = de; bk = k; }
            }
            if (bk > 0 && bd < 2 * PS9[e9].w) ev9[bk] = 1;
         }
         var kE = 0, ref = -(LT[0] + Math.log(dTL[0])), chg = 0, dArr9 = R.EVENT_ARRIVE_K * S.dA;
         gap9 = 0;
         for (k = 1; k <= n; ++k) {
            // (DECIDIDO SIN NINO) LA LLEGADA es el ultimo evento: desde que el destino esta a ≤ EVENT_ARRIVE_K × su distancia de llegada (ya
            // tiene el 80 % de su tamaño final) lo que queda es el asentarse, no se le exige otro ×2 (cerrar ahi encogia el campo de llegada)
            if (dArr9 > 0 && fvLen(fvSub(S.T, pos[k])) <= dArr9) break;
            var sg = -(LT[k] + Math.log(dTL[k]));
            if (ev9[k]) { kE = k; continue; }
            if (vis9[k] && sg >= ref + Math.LN2 - 1e-9) { kE = k; ref = sg; continue; }
            if (k - kE >= K8) {
               var need9 = Math.max(lt9, -(ref + Math.LN2) - Math.log(dTL[k]));
               if (rec9) need9 = Math.max(need9, LTref[k] - rec9[k] - keep9);
               if (vis9[k] && !pre[k] && need9 < LT[k] - 1e-9) {
                  // (nQ, ROUTE.EVENT_RAMP) el cierre como RAMPA suave (smootherstep) que acaba en k, de EVENT_RAMP × la duracion minima a FOV_RATE:
                  // con el tope en un solo fotograma las pasadas lo cerraban a ritmo maximo con arranque y parada secos (zoom de golpe ×1,05
                  // por fotograma que empezaba y paraba en un fotograma, con su tiron de mirada: el encuadre depende del campo). 0 = ROJO
                  var D9 = LT[k] - need9, M9 = R.EVENT_RAMP > 0 ? Math.max(1, Math.ceil(R.EVENT_RAMP * 1.875 * D9 / Math.max(1e-9, RD))) : 0;
                  // con el campo ABRIENDOSE (llegada: beta abre segun se acerca) la rampa no lo invierte: se alarga (hasta EVENT_S) hasta que solo
                  // FRENA la apertura. Medido en R7 (escena del constructor actual): el campo pasaba de abrir a cerrar 6,4° -> 5,8° en 0,3 s con
                  // un tiron de mirada de 1,6 °/s (12 °/s²)
                  for (var g9t = 0; M9 > 0 && g9t < 12 && M9 < K8; ++g9t) {
                     var rev9 = false, pc9 = null;
                     for (var j8 = Math.max(1, k - M9); j8 <= k && !rev9; ++j8) { var cc9 = LT[j8] - D9 * fvSmoother((j8 - (k - M9)) / M9); if (pc9 !== null && LT[j8] > LT[j8 - 1] + 1e-12 && cc9 < pc9 - 1e-12) rev9 = true; pc9 = cc9; }
                     if (!rev9) break;
                     M9 = Math.min(K8, Math.ceil(M9 * 1.5));
                  }
                  // nunca dentro de la quietud inicial: alli la mirada es la de salida y, al acabar, saltaba a la del campo ya cerrado (R4: 0,75 °/s
                  // en un fotograma a los 2,5 s)
                  var kp9 = 1; while (kp9 < k && pre[kp9]) ++kp9;
                  if (M9 > k - kp9) M9 = Math.max(1, k - kp9);
                  if (need9 < AC[k]) { for (var j9 = Math.max(kp9, k - M9); j9 <= k; ++j9) { var c9r = LT[j9] - D9 * (M9 ? fvSmoother((j9 - (k - M9)) / M9) : 1); if (c9r < AC[j9]) AC[j9] = c9r; } ++chg; }
                  kE = k; ref = -(need9 + Math.log(dTL[k]));
               }
               else gap9 = Math.max(gap9, (k - kE) * dt);
            }
         }
         if (!chg) break;
         ev9N += chg;
         for (var r9 = 0; r9 < 3; ++r9) {
            // (desde el plan sin I9: la pasada hacia delante solo baja valores; sin volver a el, el campo no podria reabrir tras el cierre)
            for (k = 1; k <= n; ++k) LT[k] = LTref[k];
            fvRoutePasses(LT, UB, AC, inc, dn, n);
            var bad9 = 0;
            for (k = 1; k <= n; ++k) {
               look[k] = lookOf(k, Math.exp(LT[k]), W[k]);
               if (pre[k] && !preCap) continue;
               var c9 = capOf(k, look[k]);
               if (c9 < 1e9 && c9 > -1e9 && LT[k] > c9 + 1e-9) { var cf9 = capFix(k, Math.exp(LT[k]), W[k]); AC[k] = Math.min(AC[k], cf9.cv > 0 && cf9.tf > 0 ? Math.log(cf9.tf) : c9); ++bad9; }
            }
            if (!bad9) break;
         }
      }
      if (gap9 > R.EVENT_S + 1e-6) fl.gap9Warn = "I9: " + gap9.toFixed(1) + " s sin evento con el destino fuera de cuadro";
   }
   // 2c. (nQ, ROUTE.LT_SMOOTH s) EL CAMPO SIN CODOS: las pasadas (topes y ritmos maximos) dejan el ln tan con quiebros de pendiente: en R7
   //     (escena del constructor actual) el ritmo de zoom caia un 80 % de un fotograma al siguiente al chocar la reapertura tras un cierre
   //     de I9 con la rampa del siguiente. Media movil centrada de ±LT_SMOOTH s sobre σ = ln tan + ln d (si la escala del destino en pantalla
   //     no bajaba, la media tampoco: B se mantiene), con la ventana estrechada en los extremos (el campo de salida y el de llegada no se
   //     tocan) y sin tocar la quietud inicial; despues, por debajo de UB y AC (por su minimo acumulado en cada tramo con el destino en
   //     cuadro) y NUNCA por encima del de antes (solo redondea los codos de techo; los valles, los cierres de I9, ya van en rampa). 0 = ROJO
   if (R.LT_SMOOTH > 0 && !S.home && fl.kind === "cine") {
      var H8 = Math.max(1, Math.round(R.LT_SMOOTH / dt)), sg8 = new Float64Array(n + 1), LTo = Float64Array.from(LT), mU8 = 1e30, mA8 = 1e30;
      for (k = 0; k <= n; ++k) sg8[k] = LT[k] + Math.log(Math.max(1e-12, dTL[k]));
      for (k = 0; k <= n; ++k) {
         var ln8 = Math.log(Math.max(1e-12, dTL[k])), su8 = UB[k] + ln8, sa8 = AC[k] + ln8;
         if (!visT || (k > 0 && visT[k] && visT[k - 1])) { mU8 = Math.min(mU8, su8); mA8 = Math.min(mA8, sa8); } else { mU8 = su8; mA8 = sa8; }
         if (k === 0 || k === n || pre[k]) continue;
         // (con el destino fuera de cuadro en la ventana, la media del propio ln tan: B no aplica y la de σ metia la curvatura de ln d, que
         // cambia deprisa al subir en la U: R5, el campo de 0,87° a 0,75° y vuelta en 0,2 s)
         var h8 = Math.min(H8, k, n - k), a8 = 0, v8 = true, q8;
         if (visT) for (q8 = k - h8; q8 <= k + h8 && v8; ++q8) if (!visT[q8]) v8 = false;
         for (q8 = k - h8; q8 <= k + h8; ++q8) a8 += v8 ? sg8[q8] : LTo[q8];
         LT[k] = v8 ? Math.min(a8 / (2 * h8 + 1), mU8, mA8) - ln8 : Math.min(a8 / (2 * h8 + 1), UB[k], AC[k]);
         if (LT[k] > LTo[k]) LT[k] = LTo[k];   // solo BAJA (redondea los codos de techo; subir rompia A y obligaba a volver al valor de antes: saltos de ×1,12)
      }
      for (k = 1; k <= n; ++k) {
         if (LT[k] === LTo[k]) continue;
         var lk8 = lookOf(k, Math.exp(LT[k]), W[k]);
         if (!(pre[k] && !preCap)) { var c8 = capOf(k, lk8); if (c8 < 1e9 && c8 > -1e9 && LT[k] > c8 + 1e-9 && LT[k] > LTo[k]) { LT[k] = LTo[k]; continue; } }
         look[k] = lk8;
      }
   }
   // 3. (K11b, CAP_SAFE) lo que aun incumpla A tras las vueltas NO se calla: se cuenta y se avisa (fl.warnings, plan.capResid). Fuera de
   //    la cuenta, la panoramica cuyo plano de salida no cumplia A (por diseño) y la llegada fija de casa
   var warnings = [];
   if (CAP_SAFE) {
      for (k = 1; k <= n; ++k) {
         if ((pre[k] && !preCap) || (S.home && k === n)) continue;
         var cR = fvRouteCapA(P, S, pos[k], look[k]);
         if (cR > 0 && cR < 1e9 && LT[k] > Math.log(cR) + 1e-9) ++S.capResid;
      }
      if (S.capResid > 0) warnings.push("A: " + S.capResid + " fotogramas con parte de la pantalla fuera de la parte limpia (el campo se cierra a su ritmo maximo detras de un tope que baja: destino junto al borde de la foto)");
   }
   if (fl.gap9Warn) warnings.push(fl.gap9Warn);
   if (S.home) { pos[n] = [0, 0, 0]; look[n] = [0, 0, 1]; LT[n] = ltH; }
   fl.warnings = warnings;
   fl.plan = { dt: dt, n: n, tEnd: dur, pos: pos, look: look, lt: LT, x: X, w: W, noA: noA, warnings: warnings, capMiss: S.capMiss, capResid: S.capResid, gap9: gap9, ev9: ev9N };
   return fl.plan;
}
// las pasadas del campo en ln tan (LT): techo UB, tope AC, paso maximo hacia delante inc(k) (ritmo, beta, B) y cierre maximo dn(k)
// de k−1 a k. Primero los topes, luego hacia ATRAS (se cierra antes de llegar a un tope, no de golpe al tocarlo) y al final hacia
// DELANTE (la ultima: B y el ritmo de abrir siempre se cumplen). El fotograma 0 es la camara de ahora (fijo): si el plan pide cerrar mas
// deprisa que dn desde el, se cierra a dn hasta alcanzarlo (K9 H-2: sin salto aunque se empiece con un campo mayor que el tope).
// fixEnd: el ultimo fotograma fijo (la vista de casa).
function fvRoutePasses(LT, UB, AC, inc, dn, n, fixEnd) {
   var k, soft = true;
   for (k = 1; k <= n; ++k) LT[k] = Math.min(LT[k], UB[k], AC[k]);
   if (fixEnd !== undefined) LT[n] = fixEnd;
   for (k = n; k >= 2; --k) { var d = dn(k); if (LT[k - 1] > LT[k] + d) LT[k - 1] = LT[k] + d; }
   for (k = 1; k <= n; ++k) {
      var L = Math.min(LT[k], UB[k], AC[k], LT[k - 1] + inc(k)), d2 = dn(k);
      if (soft && L < LT[k - 1] - d2) L = LT[k - 1] - d2; else soft = false;
      LT[k] = L;
   }
   if (fixEnd !== undefined) LT[n] = fixEnd;
}
// muestrear un plan (cine, casa, editor) en el instante t: pone la camara
function fvRouteSample(P, pl, t) {
   t = fvClamp(t, 0, pl.tEnd);
   var k = Math.min(pl.n - 1, Math.floor(t / pl.dt)), t0 = k * pl.dt, t1 = (k + 1 === pl.n) ? pl.tEnd : (k + 1) * pl.dt, f = fvClamp((t - t0) / Math.max(1e-12, t1 - t0), 0, 1);
   P.cam.pos = fvLerp(pl.pos[k], pl.pos[k + 1], f);
   P.cam.look = fvNorm(fvLerp(pl.look[k], pl.look[k + 1], f));
   P.cam.fov = 2 * Math.atan(Math.exp(fvMix(pl.lt[k], pl.lt[k + 1], f)));
}
// un paso de un vuelo planificado (cine, casa, editor)
function fvRouteStep(P, fl) {
   if (!fl.plan) fvRoutePlan(P, fl);
   fvRouteSample(P, fl.plan, fl.t);
   if (fl.kind === "path") {
      var kt = fl.keyT, ki = kt.length - 1, j;
      for (j = 0; j < kt.length; ++j) if (fl.t < kt[j][1]) { ki = j; break; }
      fl.keyIdx = ki;
      var lg = fl.legT, ph = "arrive";
      for (j = 0; j < lg.length; ++j) if (fl.t < lg[j][1]) { ph = (fl.t < lg[j][0]) ? "arrive" : fvFlightPhaseU("cine", (fl.t - lg[j][0]) / Math.max(1e-9, lg[j][1] - lg[j][0])); break; }
      fl.phase = ph;
   } else {
      var pre = fl.route.pre;
      fl.phase = (fl.t < pre) ? "depart" : fvFlightPhaseU("cine", fvClamp((fl.t - pre) / Math.max(1e-9, fl.route.travelS), 0, 1));
   }
   P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] };
   P.trail = 0;
}
// (LLEGADA) ¿el destino TL cae, visto desde la Tierra, en la parte LIMPIA de las capas? (entonces A se puede cumplir hasta la losa: R14)
function fvWarpCleanTarget(G, TL) { return TL[2] > 0 && Math.abs(TL[0] * G.D / TL[2]) < G.kc0[0] * G.HW && Math.abs(TL[1] * G.D / TL[2]) < G.kc0[1] * G.HH; }
// (LLEGADA) el tope A del vertigo del primer warp (en radianes de campo; 1e9 = sin tope): con el destino en la parte limpia y antes de la
// losa, lo que cubre lo que se pinta (fvLayerCleanKAt: la foto en casa, la parte limpia de las capas al apagarse) con la mirada de ahora.
// Tambien dentro de la zona de la foto: fvPhotoFovCap se suelta hacia 4π entre PHOTO_CAP0 y PHOTO_CAP1 y este tope, sin hueco, sigue
function fvWarpSlabFovCap(P, fl) {
   var R = FV_PILOT.ROUTE, G = fvRouteGeo(P), TL = fl.Tlook || fl.T, pos = P.cam.pos;
   var clean = !!TL && fvWarpCleanTarget(G, TL);
   if (!R.WARP || !R.WARP_A_SLAB || !G.neb || !TL || pos[2] >= G.zIn || !(clean || R.EDGE_WHOLE)) return 1e9;   // (nF2) EDGE_WHOLE: tambien al borde
   var lk = fvNorm(P.cam.look);
   if (!(lk[2] > 0.1)) return 1e9;
   var c = fvRouteCover(P, G, pos, lk, !clean);
   return c > 0 && c < 1e9 ? 2 * Math.atan(c) : 1e9;
}
// (R12/R13) EL WARP con el campo y la mirada PLANIFICADOS (ROUTE.WARP), en el primer paso tras el vertigo: las fases, la velocidad y el
// camino son los de siempre (§15); cambian (1) el encuadre de la preparacion: se encara el destino tanto como deje A cerrando el campo
// como mucho WARP_ZOOM_MAX (si no basta —destino junto al borde de la foto— se queda desplazado en pantalla mientras se pinta la foto y
// se centra al salir de su zona); el destino va EN PANTALLA de donde esta a ese sitio (no sale del cuadro mientras el campo se cierra);
// y (2) el campo: el de siempre (60 -> 105°, inspiracion, rebote) como TECHO, con el tope A exacto mientras se pinta la foto, la ley de
// ritmo WARP_BETA (el destino crece siempre: B) y el cierre ≤ WARP_FOV_RATE planificado hacia atras. Sin el muelle de la mirada.
// -> fl.wplan = { dt, n, tEnd, pos[], look[], lt }
function fvRouteWarpPlan(P, fl) {
   var R = FV_PILOT.ROUTE, WW = FV_PILOT.WARP, G = fvRouteGeo(P), dt = R.PLAN_DT, E = fl.prof.end, n = Math.max(1, Math.ceil(E / dt - 1e-9)), k, ky = P.VH / P.VW;
   var TL = fl.Tlook || fl.T, p0 = P.cam.pos.slice(), lk0 = fvNorm(P.cam.look), tan0 = Math.tan(P.cam.fov / 2), lt0 = Math.log(tan0);
   // el tope A del warp, solo en la zona de la foto: la parte limpia de lo que se pinta (la foto en casa, las capas al apagarse); si el
   // destino cae en el borde oscurecido de las capas (R14), la foto entera (como el cine: cambiar de una a otra segun el eje daba topes
   // que tendian a 0 justo antes del cambio, un zoom ×160)
   var tClean = fvWarpCleanTarget(G, TL), slabA = !!(R.WARP_A_SLAB && tClean && G.neb);
   // (LLEGADA) con el destino en la parte limpia, el tope sigue fuera de la zona de la foto hasta entrar en la losa (como fvRouteCapA)
   // (nF2) EDGE_WHOLE: destino en el borde -> contra la foto entera hasta la losa (antes, nada pasada la zona de la foto)
   var edgeA = !!(R.EDGE_WHOLE && !tClean && G.neb);
   function capW(pos, look) { return ((fvLen(pos) < G.zPhoto || ((slabA || edgeA) && pos[2] < G.zIn)) && look[2] > 0.1) ? fvRouteCover(P, G, pos, look, !tClean) : 1e9; }
   var sky0 = fvScreenTan(p0, lk0, TL), onScr = !!sky0 && Math.abs(sky0[0]) <= tan0 && Math.abs(sky0[1]) <= tan0 * ky, sky = sky0 || [0, 0], best = null;
   for (var ci = 0; ci <= 10; ++ci) {
      var c = ci / 10, tW = tan0, oh = [0, 0], okc = true;
      for (var it = 0; it < 24; ++it) {
         oh = [fvClamp(c * sky[0] / tW, -R.SKY_CLAMP, R.SKY_CLAMP), fvClamp(c * sky[1] / tW, -R.SKY_CLAMP * ky, R.SKY_CLAMP * ky)];   // (medios anchos)
         var cv = capW(p0, fvAimAt(p0, TL, oh[0] * tW, oh[1] * tW));
         if (cv <= 0) { okc = false; break; }
         var tN = Math.min(tan0, cv); if (tN >= tW * (1 - 1e-9)) break; tW = tN;
      }
      if (!okc) continue;
      if (!best || tW > best.tan) best = { c: c, o: oh, tan: tW };
      if (tW >= tan0 / R.WARP_ZOOM_MAX) { best = { c: c, o: oh, tan: tW }; break; }
   }
   if (!best) best = { c: 0, o: [0, 0], tan: tan0 };
   fl.warpFrame = best;
   // (6-nov, FAST_EASE) el encarar de la preparacion dura 1,2 s × kPh, pero nunca menos de lo que tarda el campo en cerrarse al del encuadre
   // (best.tan) a WARP_FOV_RATE: con kPh 0,25 (regulador 1) un destino junto al borde de la foto dejaba ver fuera 0,2 s (4 % de pantalla)
   var tTurnW = 1.2 * (fl.kPh || 1);
   if (fvFastOn()) tTurnW = Math.max(tTurnW, 1.875 * Math.abs(Math.log(tan0 / best.tan)) / R.WARP_FOV_RATE);
   fl.turnW = tTurnW;
   var pos = new Array(n + 1), look = new Array(n + 1), LT = new Float64Array(n + 1), UB = new Float64Array(n + 1), AC = new Float64Array(n + 1), dT = new Float64Array(n + 1);
   var TR = new Float64Array(n + 1), GG = new Float64Array(n + 1), ltW = Math.log(best.tan), fov0 = 2 * Math.atan(tan0), RW = R.WARP_FOV_RATE * dt, oh0 = [sky[0] / tan0, sky[1] / tan0];
   for (k = 0; k <= n; ++k) {
      var tau = (k === n) ? E : k * dt, x = fvWarpS(fl.prof, tau), p = fl.path.at(x), s = fl.path.sOf(Math.min(1, x)), pr = fvWarpProfile(tau, fl.cruise, fl.kPh);
      // el encuadre de la preparacion entra con el giro (1,2 s) y se suelta al salir de la zona de la foto (de zPhoto a 2 × zPhoto)
      var turn = fvSmooth(fvClamp(tau / tTurnW, 0, 1)), g = 1 - fvSmooth((fvLen(p) - G.zPhoto) / G.zPhoto);
      pos[k] = p; TR[k] = turn; GG[k] = g;
      var fovB = Math.exp(fvMix(Math.log(fov0), Math.log(fl.fov1), fvClamp(s, 0, 1)));
      var fv = Math.min(FV_PILOT.MAX_FOV, fvMix(fovB, FV_PILOT.MAX_FOV, pr.warp)) * (1 - WW.INHALE * pr.inhale) * (1 - pr.bounce);
      UB[k] = Math.log(Math.tan(fv / 2)) + (ltW - lt0) * turn * g;
      dT[k] = Math.max(1e-12, fvLen(fvSub(TL, p)));
      AC[k] = 1e9;
   }
   // la mirada: destino en cuadro al salir -> EN PANTALLA (medios anchos) de donde esta al encuadre de la preparacion; si no, giro (slerp)
   function lookOf(k, tanF) {
      if (k === 0) return lk0;
      var o = [best.o[0] * GG[k], best.o[1] * GG[k]], s = TR[k];
      if (onScr) return fvAimAt(pos[k], TL, fvMix(oh0[0], o[0], s) * tanF, fvMix(oh0[1], o[1], s) * tanF);
      return fvSlerpDir(lk0, fvAimAt(pos[k], TL, o[0] * tanF, o[1] * tanF), s);
   }
   function inc(k) { var r = Math.log(dT[k - 1] / dT[k]); return Math.min(R.WARP_BETA * r, r); }
   function dn() { return RW; }
   LT[0] = lt0; look[0] = lk0;
   var soft = true;
   for (k = 1; k <= n; ++k) {
      var tf = Math.exp(Math.min(UB[k], LT[k - 1] + inc(k))), lq = lookOf(k, tf), cap = 1e9;
      for (var r = 0; r < 6; ++r) { var cv2 = capW(pos[k], lq); if (!(cv2 > 0) || cv2 >= 1e9) break; cap = cv2; if (tf <= cv2 * 1.0001) break; tf = cv2; lq = lookOf(k, tf); }
      AC[k] = cap < 1e9 ? Math.log(cap) : 1e9;
      var L1 = Math.log(tf);
      if (soft && L1 < LT[k - 1] - RW) L1 = LT[k - 1] - RW; else soft = false;
      LT[k] = L1; look[k] = lq;
   }
   for (var round = 0; round < 4; ++round) {
      fvRoutePasses(LT, UB, AC, inc, dn, n);
      var bad = 0;
      for (k = 1; k <= n; ++k) {
         look[k] = lookOf(k, Math.exp(LT[k]));
         var cN = capW(pos[k], look[k]);
         if (cN > 0 && cN < 1e9 && LT[k] > Math.log(cN) + 1e-9) { AC[k] = Math.min(AC[k], Math.log(cN)); ++bad; }
      }
      if (!bad) break;
   }
   // (6-nov, KEEP_IN.WARP_SIGHT) de lejos a cerca: la mirada va (con el giro de la preparacion) al punto de la foto que queda DETRAS del destino
   // visto desde la Tierra (al llegar, en su linea de vision, se mira justo a la estrella con la foto detras) y el campo no pasa de lo que cubre
   // la parte limpia con esa mirada, con ritmo ≤ WARP_FOV_RATE planificado hacia delante y hacia atras (cierra antes de hacer falta)
   if (fl.sightKeep && G.neb && TL[2] > 1e-9) {
      var QT = [TL[0] * G.D / TL[2], TL[1] * G.D / TL[2], G.D], CP = new Float64Array(n + 1), ltMax = Math.log(Math.tan(FV_PILOT.MAX_FOV / 2));
      for (k = 1; k <= n; ++k) {
         look[k] = fvSlerpDir(lk0, fvNorm(fvSub(QT, pos[k])), TR[k]);
         var cS = fvRouteCover(P, G, pos[k], look[k], true);
         CP[k] = (cS > 0 && cS < 1e9) ? Math.min(ltMax, Math.log(cS)) : LT[k];
      }
      // (la foto entera: con la parte limpia, la mirada de salida —en el tercio, junto al borde oscurecido— daba topes de 0,006° y un zoom
      // de golpe; y nunca se cierra mas deprisa que RW por paso: mejor un instante con el borde de la foto que un salto de campo)
      LT[0] = lt0;
      for (k = 1; k <= n; ++k) LT[k] = Math.max(LT[k - 1] - RW, Math.min(CP[k], LT[k - 1] + RW));
      for (k = n - 1; k >= 1; --k) LT[k] = Math.min(LT[k], LT[k + 1] + RW);
      for (k = 1; k <= n; ++k) LT[k] = Math.max(LT[k], LT[k - 1] - RW);
   }
   fl.wplan = { dt: dt, n: n, tEnd: E, pos: pos, look: look, lt: LT };
   return fl.wplan;
}

// ---------------------------------------------------------------------------
// (RUTA) EL EDITOR DE CAMARAS: fvPilotFlyPath(P, keys, opts) recorre una lista de camaras con la MISMA ley suave (plan en una rejilla,
// fvPilotStep solo muestrea). Contrato (docs/ruta-del-viaje-analisis.md §6, ajustado a como lo llama src/ui/fv_route.js):
//   keys[i] = { pos: [x, y, z] (a.l.), look: [dx, dy, dz] | lookAt: [x, y, z] | lookSel: { kind, i }, fov: rad, holdS: s ≥ 0 }
//   el recorrido SALE DE LA CAMARA ACTUAL (P.cam) y pasa por cada llave en orden; en una llave con holdS > 0 se para (posicion, mirada y
//   campo quietos) ese tiempo; en una sin pausa se pasa sin frenar (la frenada de fvCineX solo entre pausas).
//   opts = { speed: 0..1 (el regulador; si no, P.speed), durS: s (escala la duracion total de los tramos), respectA: true }
//   -> false si no hay llaves validas (P intacto) | { ok: true, dur, warnings: [] }
//   P.flight = { kind: "path", t, dur, keyIdx (la llave hacia la que se va o en la que se esta parado, 0…n−1) }; al acabar P.flight = null,
//   P.mode = "free" y P.onFlightEnd(P, fl); fvPilotStop lo corta como a cualquier vuelo.
//   Camino: Catmull-Rom centripeta (fvCrPoint) por las posiciones de cada tramo entre pausas (dos puntos = recta); tiempo con tau =
//   ∫ ds / escala visible (la siguiente pausa, la losa, el fundido de la foto; suelo 2 % del tramo); mirada slerp y campo en ln tan con
//   smootherstep entre llaves (sin sobrepasos); con respectA, el tope A exacto del eje de la mirada, planificado con ritmo ≤ FOV_RATE.
//   lookAt / lookSel fijan la mirada EN la llave (hacia ese punto); entre llaves se interpola la direccion (no el punto).
// ---------------------------------------------------------------------------
function fvPilotFlyPath(P, keys, opts) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabFlyPath(P, keys, opts);      // (8-nov, LABORATORIO)
   if (!P || !P.cam || !keys || !keys.length) return false;
   opts = opts || {};
   var R = FV_PILOT.ROUTE, G = fvRouteGeo(P), cam = P.cam, i, j, k, warnings = [];
   var outKey = false, Q = [cam.pos.slice()], LK = [fvNorm(cam.look)], LF = [Math.log(Math.tan(cam.fov / 2))], H = [0];
   var LP = [null];                // (D1) el punto al que mira cada llave (lookAt), para opts.trackLook
   for (i = 0; i < keys.length; ++i) {
      var kk = keys[i], p = kk && kk.pos;
      if (!p || p.length !== 3 || !isFinite(p[0]) || !isFinite(p[1]) || !isFinite(p[2])) return false;
      // (LOS DOS MODOS) una llave fuera de la piramide de la foto (o pasada la losa) es una camara que el usuario puso alli A PROPOSITO: la ruta
      // va en ESPACIO (rotulo, fantasma, marcadores), sin recortarla (recortada al volar, el campo de la ruta no casaba con donde estaba la
      // camara: fv_k11b_node K1b fuera 0,50; recortada al planear, la ruta no llegaba a su llave: fv_viaje_rapido_node V4 a 336 % de dA)
      if (fvNmOn() && P.scene && P.scene.nebula && P.scene.field && !fvNmInside(P, p, 1e-9)) outKey = true;
      var lt = null, lk = null;
      try { lt = kk.lookSel ? fvSelPos(P, kk.lookSel) : (kk.lookAt ? kk.lookAt : null); } catch (e) { lt = null; }
      if (lt && fvLen(fvSub(lt, p)) > 1e-12) lk = fvNorm(fvSub(lt, p));
      else if (kk.look && fvLen(kk.look) > 0) lk = fvNorm(kk.look);
      else lk = LK[LK.length - 1];
      var fv = (kk.fov > 0 && kk.fov < Math.PI) ? kk.fov : 2 * Math.atan(Math.exp(LF[LF.length - 1]));
      LP.push((lt && fvLen(fvSub(lt, p)) > 1e-12) ? lt.slice() : null);
      Q.push([+p[0], +p[1], +p[2]]); LK.push(lk); LF.push(Math.log(Math.tan(fv / 2))); H.push((isFinite(kk.holdS) && kk.holdS > 0) ? +kk.holdS : 0);
   }
   // (nQ, PATH_AIM) el PUNTO del plano de la foto al que mira cada llave (null si no mira hacia el o ya esta detras): entre llaves se mira
   // al punto interpolado (si las dos lo tienen), no a la direccion interpolada: el eje no sale de la foto (antes, A -> B -> A: el eje salia y
   // A cerraba el campo a 0,001°). En la llave la mirada es la de la llave (el punto esta en su eje)
   var AP = [];
   for (i = 0; i < Q.length; ++i) AP.push((R.PATH_AIM && G.neb && LK[i][2] > 0.1 && Q[i][2] < G.D - 1e-6) ? fvAdd(Q[i], fvMul(LK[i], (G.D - Q[i][2]) / LK[i][2])) : null);
   function lookBetween(pk, ia, ib, sq) {
      // (D1) opts.trackLook: entre dos llaves que miran a un punto se mira al punto interpolado desde donde este la camara (el rodeo de la
      // losa pasa el plano de la foto mirandola: la direccion interpolada la perdia de vista durante medio tramo)
      if (opts.trackLook && LP[ia] && LP[ib]) { var tp = fvSub(fvLerp(LP[ia], LP[ib], sq), pk); if (fvLen(tp) > 1e-9) return fvNorm(tp); }
      if (AP[ia] && AP[ib] && pk[2] < G.D - 1e-6) { var ap = fvLerp(AP[ia], AP[ib], sq), v = fvSub(ap, pk), Lv = fvLen(v); if (Lv > 1e-9 && v[2] / Lv > 0.1) return fvMul(v, 1 / Lv); }
      return fvSlerpDir(LK[ia], LK[ib], sq);
   }
   if (fvNmOn() && P.scene && P.scene.nebula && P.scene.field) {
      P.navReturn = null;
      if (outKey) { if (P.navMode !== "space") { P.navMode = "space"; P.navEnterT = P.t; } P.navPending = null; }
      else if (P.navMode === "space") P.navPending = "photo";
   }
   var m = Q.length - 1, spd = (opts.speed !== undefined && isFinite(opts.speed)) ? +opts.speed : P.speed;
   var spK = Math.pow(FV_PILOT.SPEED_SPAN, 1 - 2 * fvClamp(isFinite(spd) ? spd : 0.5, 0, 1)), PS = R.PATH_S;
   if (fvFastOn()) spK *= FV_PILOT.FAST.PATH_K;                    // (6-nov, FAST_EASE) los tramos × PATH_K (las paradas no)
   // (K11b) tambien se para (sin pausa) donde el camino VUELVE ATRAS (giro de la direccion de avance > PATH_STOP_DEG): por A -> B -> A la
   // Catmull-Rom hacia un pico en B y la camara invertia el sentido en un fotograma a 1 660 a.l./s (rapidez medida 1 658 -> 688 -> 1 666)
   var stops = [0];
   for (i = 1; i < m; ++i) {
      var dIn = fvSub(Q[i], Q[i - 1]), dOut = fvSub(Q[i + 1], Q[i]), sharp = R.PATH_STOP_DEG > 0 && fvLen(dIn) > 1e-12 && fvLen(dOut) > 1e-12 && fvAngle(dIn, dOut) > R.PATH_STOP_DEG * FV_DEG;
      if (H[i] > 0 || sharp) stops.push(i);
   }
   stops.push(m);
   // los tramos entre pausas: curva, tau, duracion
   var legs = [];
   for (var si = 0; si + 1 < stops.length; ++si) {
      var a = stops[si], b = stops[si + 1], pts = Q.slice(a, b + 1), nP = pts.length, Lc = 0, turn = 0, dLF = 0;
      for (j = 1; j < nP; ++j) { Lc += fvLen(fvSub(pts[j], pts[j - 1])); turn += fvAngle(LK[a + j - 1], LK[a + j]) / FV_DEG; dLF = Math.max(dLF, Math.abs(LF[a + j] - LF[a + j - 1])); }
      var ext = [fvSub(fvMul(pts[0], 2), pts[1])].concat(pts).concat([fvSub(fvMul(pts[nP - 1], 2), pts[nP - 2])]);
      var curve = (function(ext, nP, pts) { return function(l) {
         if (nP === 2) return fvLerp(pts[0], pts[1], l);
         var uu = fvClamp(l, 0, 1) * (nP - 1), s = Math.min(nP - 2, Math.floor(uu)), tt = uu - s;
         return fvCrPoint(ext[s], ext[s + 1], ext[s + 2], ext[s + 3], tt); }; })(ext, nP, pts);
      var Sx = { home: false, T: Q[b], startVis: false, touchSlab: false, sFloor: Math.max(1e-9, 0.02 * Lc), d0: Lc, startF: Q[a] };
      var zs = pts.map(function(q) { return q[2]; }); Sx.touchSlab = G.neb && Math.min.apply(null, zs) <= G.zOut && Math.max.apply(null, zs) >= G.zIn;
      var TT = (Lc > 0) ? fvRouteTau(curve, (function(Sx) { return function(q) { return fvRouteVisScale(Sx, G, q); }; })(Sx), Lc) : null;
      var dec = TT ? TT.tauTot / Math.LN10 : 0, travel = fvClamp(PS[0] + PS[1] * dec, PS[0], PS[2]) * spK;
      var needS = Math.max(1.875 * turn / R.PAN_DPS, 1.875 * dLF / R.FOV_RATE);
      if (needS > travel) { travel = needS; if (needS > PS[2] * spK) warnings.push("tramo " + (si + 1) + ": giro o zoom grandes, " + needS.toFixed(1) + " s"); }
      if (!(Lc > 0) && !(turn > 0.01) && !(dLF > 1e-4)) travel = Math.min(travel, 0.5);
      // cada llave en tau (xs) y en la fraccion de TIEMPO del tramo (us); el giro y el zoom entre dos llaves se hacen en su tiempo
      // (smootherstep en u) y ese tiempo tiene que bastar para ≤ PAN_DPS y ≤ FOV_RATE: si no, se alarga el tramo (hasta 4 × PATH_S max)
      var xs = [], us = [], needK = 0;
      for (j = 0; j < nP; ++j) { var xj = TT ? TT.xOfLam(j / (nP - 1)) : j / (nP - 1), lo = 0, hi = 1; for (var bi = 0; bi < 44; ++bi) { var mid = 0.5 * (lo + hi); if (fvCineX(mid) < xj) lo = mid; else hi = mid; } xs.push(xj); us.push(j === 0 ? 0 : (j === nP - 1 ? 1 : 0.5 * (lo + hi))); }
      for (j = 0; j + 1 < nP; ++j) {
         var du = us[j + 1] - us[j], nd = 1.875 * Math.max(fvAngle(LK[a + j], LK[a + j + 1]) / FV_DEG / R.PAN_DPS, Math.abs(LF[a + j + 1] - LF[a + j]) / R.FOV_RATE);
         if (du > 1e-9) needK = Math.max(needK, nd / du);
         if (du > 1e-9 && nd > du * travel) travel = Math.min(nd / du, 4 * PS[2] * spK);
         if (nd > du * travel * 1.001) warnings.push("llave " + (a + j + 1) + " -> " + (a + j + 2) + ": giro o zoom demasiado bruscos para el tramo");
      }
      legs.push({ a: a, b: b, curve: curve, TT: TT, xs: xs, us: us, travel: travel, need: Math.max(needS, needK) });
   }
   // (D1) durS reparte la duracion pedida, pero ningun tramo baja de lo que piden su giro y su zoom (PAN_DPS, FOV_RATE)
   if (opts.durS > 0) { var sumT = 0; for (i = 0; i < legs.length; ++i) sumT += legs[i].travel; if (sumT > 0) for (i = 0; i < legs.length; ++i) legs[i].travel = Math.max(legs[i].travel * opts.durS / sumT, Math.min(legs[i].need, 4 * PS[2] * spK)); }
   // (nQ, PATH_AIM, pendiente (a)) EL BARRIDO: si la mirada entre llaves barre mas de PATH_SWEEP medios anchos de pantalla por segundo
   // (con el campo que deja A), se ALARGA el tramo que lo hace (×hasta 4 por vuelta, 3 vueltas) y se rehace el plan. Antes, A -> B -> A
   // del editor: 14,5 medios anchos por fotograma. Repartir el giro segun el campo se probo otra vez (con el punto de mira): diverge, 274
   // medios anchos por fotograma (el tope A depende de la mirada). PATH_SWEEP 0 (por defecto) = sin alargar: con la llave mirando fuera de
   // la foto el tope es singular y alargar lo empeora (medido: 30 -> 1 500 s, 12 medios anchos por fotograma)
   for (var slowIt = 0; slowIt < 4; ++slowIt) {
      // la linea de tiempo: [salida, llegada] de cada tramo y [llegada, salida] de cada llave (1…m)
      var tAcc = 0, legT = [], keyT = [];
      for (i = 0; i < legs.length; ++i) {
         var L0 = legs[i], tl0 = tAcc, tl1 = tAcc + L0.travel; legT.push([tl0, tl1]);
         for (j = 1; j < L0.us.length - 1; ++j) { var tk = tl0 + L0.us[j] * L0.travel; keyT.push([tk, tk]); }   // llaves sin pausa: se pasa por ellas
         keyT.push([tl1, tl1 + H[L0.b]]); tAcc = tl1 + H[L0.b];
      }
      var dur = Math.max(1e-3, tAcc), dt = R.PLAN_DT, n = Math.max(1, Math.ceil(dur / dt - 1e-9));
      var pos = new Array(n + 1), look = new Array(n + 1), LT = new Float64Array(n + 1), UB = new Float64Array(n + 1), AC = new Float64Array(n + 1), RD = R.FOV_RATE * dt, li = 0;
      var acAt = function(k) {
         AC[k] = 1e9;
         if (opts.respectA !== false && look[k][2] > 0.1) {
            var pk = pos[k], cA = -1;
            if (fvLen(pk) < G.zPhoto) cA = fvRouteCover(P, G, pk, look[k], true);
            else if (pk[2] < G.zIn) cA = fvRouteCover(P, G, pk, look[k], false);
            if (cA > 0 && cA < 1e9) AC[k] = Math.log(cA);
         }
      };
      var segA = new Int32Array(n + 1), sqL = new Float64Array(n + 1);
      for (k = 0; k <= n; ++k) {
         var t = (k === n) ? dur : k * dt;
         segA[k] = -1;
         while (li < legs.length - 1 && t >= legT[li + 1][0]) ++li;
         var Lg = legs[li], T0 = legT[li][0], T1 = legT[li][1];
         if (t >= T1) { pos[k] = Q[Lg.b].slice(); look[k] = LK[Lg.b]; UB[k] = LF[Lg.b]; }
         else {
            var uq = fvClamp((t - T0) / Math.max(1e-9, Lg.travel), 0, 1), x = fvCineX(uq), pp = Lg.TT ? Lg.TT.at(x) : Q[Lg.a].slice(), us2 = Lg.us, q = 0;
            while (q < us2.length - 2 && uq > us2[q + 1]) ++q;
            var sq = fvSmoother((us2[q + 1] > us2[q]) ? (uq - us2[q]) / (us2[q + 1] - us2[q]) : 1);
            pos[k] = pp; look[k] = lookBetween(pp, Lg.a + q, Lg.a + q + 1, sq); UB[k] = fvMix(LF[Lg.a + q], LF[Lg.a + q + 1], sq);
            segA[k] = Lg.a + q; sqL[k] = sq;
         }
         acAt(k);
      }
      pos[0] = Q[0].slice(); look[0] = LK[0]; LT[0] = LF[0];
      // el campo de las llaves como techo; con el tope A, lo que se aparte del de las llaves se recupera o se adelanta a ≤ FOV_RATE
      var passes = function() {
         for (k = 1; k <= n; ++k) LT[k] = 1e9;
         fvRoutePasses(LT, UB, AC, function(k) { return Math.max(RD, UB[k] - UB[k - 1]); }, function(k) { return Math.max(RD, UB[k - 1] - UB[k]); }, n);
      };
      passes();
      var swLeg = [], swMax = 0;
      for (i = 0; i < legs.length; ++i) swLeg.push(0);
      if (R.PATH_AIM && R.PATH_SWEEP > 0) {
         var liS = 0;
         for (k = 1; k <= n; ++k) {
            var tS = (k === n) ? dur : k * dt;
            while (liS < legs.length - 1 && tS >= legT[liS + 1][0]) ++liS;
            if (segA[k] < 0) continue;
            var swk = Math.tan(Math.min(1.5, fvAngle(look[k - 1], look[k]))) / Math.max(1e-12, Math.exp(LT[k])) / dt;
            if (swk > swLeg[liS]) swLeg[liS] = swk;
            if (swk > swMax) swMax = swk;
         }
      }
      // (6-nov, FAST_EASE) EL GIRO DE LA MIRADA como lo vuela el plan: con los tramos mas cortos (PATH_K) el giro que no sale del slerp entre
      // llaves (mirar al punto de la foto mientras la camara se desplaza, PATH_AIM) pasaba de PAN_DPS (A -> B -> A de fv_k11b_node: 31,9 °/s
      // frente a 20). Si algun tramo pasa de PAN_DPS / el regulador (20 °/s a 0,5), se alarga ese tramo y se rehace (como el barrido)
      var twLeg = [], twBad = false, twLim = R.PAN_DPS / Math.pow(FV_PILOT.SPEED_SPAN, 1 - 2 * fvClamp(isFinite(spd) ? spd : 0.5, 0, 1));
      for (i = 0; i < legs.length; ++i) twLeg.push(0);
      if (fvFastOn()) {
         var liT = 0;
         for (k = 1; k <= n; ++k) {
            var tT = (k === n) ? dur : k * dt;
            while (liT < legs.length - 1 && tT >= legT[liT + 1][0]) ++liT;
            if (segA[k] < 0 && segA[k - 1] < 0) continue;
            var twk = fvAngle(look[k - 1], look[k]) / FV_DEG / dt;
            if (twk > twLeg[liT]) twLeg[liT] = twk;
         }
         for (i = 0; i < legs.length; ++i) if (twLeg[i] > twLim * 1.005) twBad = true;
      }
      if ((!(swMax > R.PATH_SWEEP * 1.02) && !twBad) || slowIt === 3) { if (swMax > R.PATH_SWEEP * 1.02) warnings.push("barrido de " + swMax.toFixed(1) + " medios anchos/s con el campo que deja A (tope del alargado)"); if (twBad) warnings.push("giro de la mirada por encima de " + twLim.toFixed(1) + " °/s (tope del alargado)"); break; }
      for (i = 0; i < legs.length; ++i) if (swLeg[i] > R.PATH_SWEEP * 1.02) legs[i].travel *= Math.min(4, swLeg[i] / R.PATH_SWEEP);
      for (i = 0; i < legs.length; ++i) if (twLeg[i] > twLim * 1.005) legs[i].travel *= Math.min(4, 1.02 * twLeg[i] / twLim);
   }
   // (K11b, MEDIDO, sin cambiar: decision para Nino) con respectA el tope A cierra el campo de las llaves (20–30°) a 0,001–0,02° y el giro
   // entre llaves (1–2°, en el tiempo) barre hasta 14 medios anchos de pantalla por fotograma (A -> B -> A en IC 1848: 316 fotogramas > 1).
   // Repartir el giro segun el campo (s = smootherstep(∫ tan / total)) se probo: baja a 8,8 pero concentra un giro de 180° donde el campo
   // es ancho (119 °/s). Queda en HANDOFF como pendiente.
   var fl = { kind: "path", t: 0, sel: null, T: null, p0: Q[0].slice(), look0: LK[0].slice(), fov0: cam.fov, pre: 0, flyby: -1, phase: "depart",
              dur: dur, keyIdx: 0, keyT: keyT, legT: legT, nKeys: m, p1: pos[n].slice(), look1: look[n].slice(), fov1: 2 * Math.atan(Math.exp(LT[n])),
              plan: { dt: dt, n: n, tEnd: dur, pos: pos, look: look, lt: LT }, route: { path: true }, speed: spd };
   P.coast = null; fvFreeHalt(P); P.brake = null;
   P.flight = fl; P.orbit = null; P.mode = "flight"; P.sunMark = false; P.arrivedAt = null;
   P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
   P.events.push({ t: P.t, what: "fly-path" });
   return { ok: true, dur: dur, warnings: warnings };
}

// ---------------------------------------------------------------------------
// (N10) EL VUELO LIBRE. Mapa de teclas (codigos de PJSR, pjsr/KeyCodes.jsh; en node, los mismos numeros):
//   W / ↑  empuje adelante        S / ↓  empuje atras (frena y retrocede)
//   A / ←  girar a la izquierda    D / →  girar a la derecha (guiñada)
//   Re Pag / Av Pag  cabeceo: morro arriba / abajo (con la guiñada se apunta a cualquier sitio; R y F no: R es REC en el dialogo)
//   Mayus  mas rapido (×BOOST) mientras se mantiene
// Raton (fvPilotMouse): arrastrar = mirar (la escena sigue al cursor, como en F2) y al SOLTAR sigue girando y se apaga (GLIDE_S).
// El dialogo llama fvPilotKey(P, key, true) al pulsar y fvPilotKey(P, key, false) al soltar; fvPilotMouse(P, dx, dy, botones) al
// arrastrar y fvPilotMouse(P, 0, 0, 0) al soltar el boton. fvPilotStep integra todo cada fotograma (no hay que llamar a nada mas).
// ---------------------------------------------------------------------------
var FV_FREE_KEYS = null;
function fvFreeKeyMap() {
   if (FV_FREE_KEYS) return FV_FREE_KEYS;
   // (21-nov-2026, PKG-FV, CPD 5.2/5.4) sin eval: cada constante de PJSR (pjsr/KeyCodes.jsh) se pregunta por su nombre escrito; fuera de PixInsight (node, visor) vale el numero
   function k(v, num) { return (v === null || v === undefined) ? num : v; }
   var M = {};
   M[k(typeof Key_W !== "undefined" ? Key_W : null, 0x57) >>> 0] = "fwd"; M[k(typeof Key_Up !== "undefined" ? Key_Up : null, 0x10000002) >>> 0] = "fwd";
   M[k(typeof Key_S !== "undefined" ? Key_S : null, 0x53) >>> 0] = "back"; M[k(typeof Key_Down !== "undefined" ? Key_Down : null, 0x10000004) >>> 0] = "back";
   M[k(typeof Key_A !== "undefined" ? Key_A : null, 0x41) >>> 0] = "left"; M[k(typeof Key_Left !== "undefined" ? Key_Left : null, 0x10000001) >>> 0] = "left";
   M[k(typeof Key_D !== "undefined" ? Key_D : null, 0x44) >>> 0] = "right"; M[k(typeof Key_Right !== "undefined" ? Key_Right : null, 0x10000003) >>> 0] = "right";
   M[k(typeof Key_PageUp !== "undefined" ? Key_PageUp : null, 0x10000300) >>> 0] = "up"; M[k(typeof Key_PageDown !== "undefined" ? Key_PageDown : null, 0x10000400) >>> 0] = "down";
   M[k(typeof Key_Shift !== "undefined" ? Key_Shift : null, 0x70000001) >>> 0] = "boost";
   FV_FREE_KEYS = M;
   return M;
}
function fvFreeState(P) {
   if (!P.free) P.free = { v: [0, 0, 0], yawW: 0, pitchW: 0, keys: {}, keyT: {}, mouseDown: false, accYaw: 0, accPitch: 0, rateYaw: 0, ratePitch: 0, glideYaw: 0, glidePitch: 0 };
   return P.free;
}
// parar en seco el vuelo libre (al empezar un vuelo, una orbita, volver a casa)
function fvFreeHalt(P) { if (!P.free) return; var F = P.free; F.v = [0, 0, 0]; F.vW = [0, 0, 0]; F.wS = null; F.yawW = F.pitchW = 0; F.glideYaw = F.glidePitch = 0; F.rateYaw = F.ratePitch = 0; F.accYaw = F.accPitch = 0; F.panRate = [0, 0, 0]; F.panAcc = [0, 0, 0]; P.wheel = 0; }
// tomar el mando a mitad de un vuelo u orbita: la velocidad que llevaba se conserva (con tope: del warp salen miles de a.l./s)
function fvFreeTakeControl(P) {
   var F = fvFreeState(P);
   if (FV_PILOT.FREE.TAKE_STOP && (P.flight || P.orbit)) { F.v = [0, 0, 0]; F.vW = [0, 0, 0]; }              // (nF2, E8 + K11b c) la nave se para en seco
   else { var dN = fvFreeNearest(P).d, vm = FV_PILOT.FREE.VMAX_K * dN, v = (P.flight || P.orbit) ? P.vel.slice() : F.v, L = fvLen(v); F.v = (L > vm) ? fvMul(v, vm / L) : v; }
   if (P.flight) { P.events.push({ t: P.t, what: "take-control" }); P.flight = null; P.warp = 0; P.trail = 0; P.flash = 0; }
   P.orbit = null; P.coast = null;
   P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] };
   if (P.mode !== "home" || fvLen(P.cam.pos) > 0) P.mode = "free";
}
// la tecla `key` (codigo PJSR) pulsada (down = true) o soltada. -> true si es del vuelo libre (consumida)
function fvPilotKey(P, key, down) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabKey(P, key, down);           // (8-nov, LABORATORIO) Q/Z = alabeo
   var act = fvFreeKeyMap()[key >>> 0];
   if (!act || !P) return false;
   var F = fvFreeState(P);
   if (down) {
      F.keys[act] = true; F.keyT[act] = P.t;
      if (act !== "boost") {
         P.brake = null;
         var homeT = (P.mode === "home" || fvLen(P.cam.pos) < 1e-6) && !P.flight && !P.orbit;
         if (P.flight || P.orbit) fvFreeTakeControl(P);
         P.coast = null; if (P.mode === "home") P.mode = "free";
         if (homeT && (act === "left" || act === "right" || act === "up" || act === "down")) fvFreeHomeZoom(P, F);          // (5-nov) como el arrastre
      }
   } else F.keys[act] = false;
   return true;
}
// (nQ, A2) en casa, con el campo de casa: un zoom suave hacia dentro para poder girar sin salir de la foto (fvFreeStep lo anima). Lo piden el
// primer arrastre (fvPilotMouse) y, desde el 5-nov, las teclas de giro y la cruceta (PAD_HOME_ZOOM; false = ROJO: en casa solo el arrastre)
function fvFreeHomeZoom(P, F, force) {
   var HZ = FV_PILOT.FREE.HOME_DRAG_ZOOM;
   if (!force && FV_PILOT.FREE.PAD_HOME_ZOOM !== true) return false;          // force: el arrastre (siempre, como antes)
   if (HZ > 1 && !P.flight && !P.orbit && fvLen(P.cam.pos) < 1e-6 && P.cam.fov >= 0.98 * P.homeFov && FV_PILOT.FREE.A_GUARD) { F.homeZoom = { t: 0, f0: P.cam.fov, f1: P.homeFov / HZ }; return true; }
   return false;
}
// (5-nov, Nino) LA CRUCETA: dir = "left" | "right" | "up" | "down" (la MIRADA gira a ese lado; avanzar despues va hacia donde se mira). down = true al
// pulsar, false al soltar. Es la tecla de giro del vuelo libre de siempre (←/A, →/D, RePag, AvPag), asi que hereda su inercia TURN_S, la pared
// de la foto (A_GUARD: fvFreeTurn) y TAKE_STOP; un clic dura al menos PAD_TAP_S. fvFreeStep la mantiene viva mientras el boton siga pulsado
// (no hay autorepeticion de raton que refresque keyT). -> true si dir es valida
function fvPilotLookPad(P, dir, down) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabPad(P, dir, down);           // (8-nov, LABORATORIO)
   if (!P || !(dir === "left" || dir === "right" || dir === "up" || dir === "down")) return false;
   var F = fvFreeState(P);
   if (!F.pad) F.pad = { down: {}, rel: {} };
   if (down) {
      var homeT = (P.mode === "home" || fvLen(P.cam.pos) < 1e-6) && !P.flight && !P.orbit;
      F.pad.down[dir] = true; F.pad.rel[dir] = P.t + FV_PILOT.FREE.PAD_TAP_S; P.brake = null;
      F.keys[dir] = true; F.keyT[dir] = P.t;
      if (P.flight || P.orbit) fvFreeTakeControl(P);
      P.coast = null; if (P.mode === "home") P.mode = "free";
      if (homeT) fvFreeHomeZoom(P, F);
   } else F.pad.down[dir] = false;
   return true;
}
// suelta la cruceta entera (ventana sin foco, vídeo, perder el raton)
function fvPilotLookPadRelease(P) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) { var LK = fvLabState(P).keys; LK.left = LK.right = LK.up = LK.down = false; return; }   // (8-nov, LABORATORIO)
   var F = P && P.free; if (!F || !F.pad) return;
   for (var d in F.pad.down) { F.pad.down[d] = false; F.pad.rel[d] = -1; F.keys[d] = false; }
}
// ¿puede girar la mirada hacia dir? (la pared de la foto, A_GUARD) -> { left, right, up, down: { ok, on } } (on = la tecla de ese lado esta pulsada).
// ok = girar un 2 % del campo mueve la mirada al menos la mitad; en casa, con A_GUARD, el primer giro cierra el campo (siempre ok). Cache 0,1 s
function fvPilotPadState(P) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLab4On === "function" && fvLab4On() && fvLabOn(P)) return fvLabPadState(P);   // (9-nov, LABORATORIO v4) sin pared: ninguna flecha apagada
   var F = P.free, key = P.cam.pos[0] + "|" + P.cam.pos[1] + "|" + P.cam.pos[2] + "|" + P.cam.look[0] + "|" + P.cam.look[1] + "|" + P.cam.look[2] + "|" + P.cam.fov;
   var C = P._padOk;
   if (!C || C.key !== key || Math.abs(P.t - C.t) > 0.1) {
      var e = 0.02 * P.cam.fov, hz = fvLen(P.cam.pos) < 1e-6 && !P.flight && !P.orbit && P.cam.fov >= 0.98 * P.homeFov && FV_PILOT.FREE.A_GUARD && FV_PILOT.FREE.HOME_DRAG_ZOOM > 1 && FV_PILOT.FREE.PAD_HOME_ZOOM === true;
      function can(dy, dp) { if (hz) return true; var l = fvFreeTurn(P, dy, dp); return fvAngle(P.cam.look, l) >= 0.5 * e; }
      C = P._padOk = { key: key, t: P.t, left: can(-e, 0), right: can(e, 0), up: can(0, e), down: can(0, -e) };
   }
   var K = (F && F.keys) || {};
   return { left: { ok: C.left, on: !!K.left }, right: { ok: C.right, on: !!K.right }, up: { ok: C.up, on: !!K.up }, down: { ok: C.down, on: !!K.down } };
}
// arrastre del raton: dx, dy en pixeles desde el ultimo evento; buttons = 0 al soltar. -> true si se uso
function fvPilotMouse(P, dx, dy, buttons) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabMouse(P, dx, dy, buttons);   // (8-nov, LABORATORIO) izquierdo = orbitar el foco (o mirar), derecho = desplazar
   if (!P) return false;
   var F = fvFreeState(P), gm = FV_PILOT.FREE.GAIA_MOUSE === true;
   if (!buttons) {
      if (!F.mouseDown && !F.panDown) return false;
      if (F.panDown) { F.panDown = false; F.v = fvAdd(F.v, fvMul(F.panRate || [0, 0, 0], FV_PILOT.FREE.PAN_GLIDE)); F.panRate = [0, 0, 0]; F.panAcc = [0, 0, 0]; }   // (I5) el pan se desliza
      if (F.mouseDown) {
         F.mouseDown = false;
         var oR = P.orbit;
         if (oR && oR.drag) { oR.drag = false; oR.gYaw = oR.rYaw || 0; oR.gPitch = oR.rPitch || 0; }      // (I5) la orbita a mano sigue girando y se apaga
         else { F.glideYaw = F.rateYaw; F.glidePitch = F.ratePitch; }                                 // al soltar, sigue girando y se apaga
      }
      return true;
   }
   P.brake = null;                                                           // (6-nov) arrastrar manda sobre la frenada
   // (I5) boton derecho (solo): pan · izquierdo en orbita: orbitar el objeto enfocado
   if (gm && (buttons & 2) && !(buttons & 1)) return fvFreePan(P, F, dx, dy);
   if (gm && P.orbit) return fvOrbitDrag(P, F, dx, dy);
   if (!F.mouseDown) {
      F.mouseDown = true; F.rateYaw = F.ratePitch = 0; F.accYaw = F.accPitch = 0; F.glideYaw = F.glidePitch = 0;
      // (nQ, A2) en casa, con el campo de casa: un zoom suave hacia dentro para poder girar sin salir de la foto (fvFreeStep lo anima)
      fvFreeHomeZoom(P, F, true);
   }
   if (!dx && !dy) return true;
   var k = P.cam.fov / P.VW;
   fvPilotLook(P, -dx * k, dy * k);
   F.accYaw += -dx * k; F.accPitch += dy * k;
   return true;
}
// (I5) PAN: boton derecho. Lo que se tiene delante (fvFreeAhead) sigue al cursor: la camara se mueve −dx, −dy pixeles de ese plano (velocidad
// ∝ distancia). La pared de la foto (A_GUARD): el mayor trozo del paso que no deja ver fuera (si ya se incumplia, mientras no empeore).
function fvFreePan(P, F, dx, dy) {
   if (P.flight || P.orbit) fvFreeTakeControl(P);
   P.coast = null;
   if (!F.panDown) { F.panDown = true; F.panAcc = [0, 0, 0]; F.panRate = [0, 0, 0]; }
   if (!dx && !dy) return true;
   var cam = P.cam, B = fvBasis(cam.look, [0, 1, 0]), dRef = Math.max(fvFreeAhead(P), FV_PILOT.FREE.MIN_D), k = 2 * dRef * Math.tan(cam.fov / 2) / P.VW;
   var mv = fvAdd(fvMul(B.r, -dx * k), fvMul(B.d, -dy * k)), p0 = cam.pos.slice(), f = 1;
   function at(t) { var q = fvAdd(p0, fvMul(mv, t)); if (FV_PILOT.FREE.HOME_FLOOR && q[2] < 0) q[2] = 0; return q; }
   if (FV_PILOT.FREE.A_GUARD) {
      var tF = Math.tan(cam.fov / 2) * (1 - 1e-9), c0 = fvFreeCapA(P, p0, cam.look), need = (c0 >= 1e9) ? -Infinity : Math.min(tF, c0);
      var okP = function(t) { var c = fvFreeCapA(P, at(t), cam.look); return c >= 1e9 || c >= need; };
      if (!okP(1)) { var lo = 0, hi = 1; for (var it = 0; it < 24; ++it) { var m = 0.5 * (lo + hi); if (okP(m)) lo = m; else hi = m; } f = lo; }
   }
   var q1 = at(f);
   F.panAcc = fvAdd(F.panAcc || [0, 0, 0], fvSub(q1, p0));
   cam.pos = q1;
   if (P.mode === "home" && fvLen(q1) > 0) P.mode = "free";
   return true;
}
// (I5) ORBITAR A MANO el objeto enfocado (boton izquierdo en orbita): guiñada alrededor del eje vertical del mundo y cabeceo alrededor del
// eje derecho de la camara, la distancia igual y la mirada clavada en el objeto. La orbita automatica se para (o.manual).
function fvOrbitDrag(P, F, dx, dy) {
   var o = P.orbit;
   if (!o.drag) { o.drag = true; o.manual = true; o.rYaw = o.rPitch = 0; o.accYaw = o.accPitch = 0; o.gYaw = o.gPitch = 0; }
   F.mouseDown = true;
   var k = FV_PILOT.FREE.ORBIT_DRAG_K / P.VW, a = -dx * k, b = dy * k;
   fvOrbitTurn(P, a, b); o.accYaw += a; o.accPitch += b;
   return true;
}
function fvOrbitTurn(P, a, b) {
   var o = P.orbit, cam = P.cam, r = fvSub(cam.pos, o.P), L = fvLen(r);
   if (!(L > 0)) return;
   var up = [0, 1, 0], r1 = fvRotate(r, up, a), rgt = fvBasis(fvMul(r1, -1), up).r, r2 = fvRotate(r1, rgt, b);
   // sin pasar por los polos (a 5° del eje vertical)
   var cU = fvDot(fvNorm(r2), up); if (Math.abs(cU) > Math.cos(5 * FV_DEG)) r2 = r1;
   // la base de la orbita automatica (cam.pos = P + rot(r0·rK, eje, theta)) se rehace para que el siguiente paso siga desde aqui
   var ax = o.axis || [0, 1, 0], rk = o.rK || 1;
   o.r0 = fvMul(fvRotate(r2, ax, -o.theta), 1 / rk);
   cam.pos = fvAdd(o.P, r2); cam.look = fvNorm(fvSub(o.P, cam.pos));
   P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
}
// (I5) lo que hay bajo el cursor (sx, sy en pixeles del lienzo del piloto): primero los objetos extensos (fvObjectHit, si estan), luego las
// estrellas (fvPick). -> { kind, i, sx, sy } | null (el vacio)
function fvPilotPickAt(P, sx, sy, radiusPx) {
   if (!P) return null;
   if (typeof fvObjectHit === "function" && P.scene.objects) {
      var oi = -1; try { oi = fvObjectHit(P.scene, fvProjector(P.cam, P.VW, P.VH), P, sx, sy); } catch (eO) { oi = -1; }
      if (oi >= 0) return { kind: "object", i: oi, sx: sx, sy: sy };
   }
   var hit = fvPick(P, sx, sy, radiusPx || 24);
   return hit ? { kind: hit.kind, i: hit.i, sx: hit.sx, sy: hit.sy } : null;
}
function fvFreeHeld(P, F, act) {
   if (!F.keys[act]) return false;
   var lim = (act === "boost") ? FV_PILOT.FREE.BOOST_HOLD_S : FV_PILOT.FREE.KEY_HOLD_S;
   if (P.t - (F.keyT[act] || 0) > lim) { F.keys[act] = false; return false; }
   return true;
}
// lo mas cercano: { d, star (indice o −1), p }. Estrellas y planos de la nebulosa (se pueden cruzar: no cuentan para el STANDOFF)
function fvFreeNearest(P) {
   var S = P.scene.stars, p = P.cam.pos, best = 1e30, bi = -1, i;
   if (S) for (i = 0; i < S.n; ++i) { var dx = S.x[i] - p[0], dy = S.y[i] - p[1], dz = S.z[i] - p[2], d = dx * dx + dy * dy + dz * dz; if (d < best) { best = d; bi = i; } }
   best = Math.sqrt(best);
   var dS = best;
   if (P.scene.nebula) { var L = P.scene.nebula.layers; for (i = 0; i < L.length; ++i) { var dz2 = Math.abs(L[i].z - p[2]); if (dz2 < best) best = dz2; } }
   return { d: Math.max(FV_PILOT.FREE.MIN_D, best), star: bi, dStar: dS };
}
// ¿se esta moviendo o girando la camara por su cuenta? (para que la cabina no ponga la aguja a 0 en una deriva)
function fvPilotMoving(P) {
   if (P.flight || P.orbit || P.coast) return true;
   var F = P.free;
   return !!(F && (fvLen(F.v) > 0 || (F.vW && fvLen(F.vW) > 0) || Math.abs(F.yawW) + Math.abs(F.pitchW) + Math.abs(F.glideYaw) + Math.abs(F.glidePitch) > 1e-4));
}
// (K9 H-3) la proteccion de las estrellas COMPROBANDO EL SEGMENTO que se va a recorrer en este fotograma. El freno de arriba solo actua a menos
// de 3 × STANDOFF del punto de partida y la velocidad escala con la nebulosa (lejos de la estrella): una estrella algo fuera del eje podia pasar
// de «delante» a «detras» dentro de UN paso (1,5 a.l. a 60 fps) atravesando su zona. Para cada estrella cuyo segmento (v · dt) pasa a menos de
// STANDOFF se quita SOLO la componente de la velocidad hacia ella que sobra (la camara queda a STANDOFF y resbala por la tangente); si el segmento
// pasa a STANDOFF o mas, no se toca nada (pasar al lado a velocidad normal no frena). Devuelve la velocidad corregida (v no se modifica).
function fvFreeStandoff(P, v, dt) {
   var S = P.scene.stars, so = FV_PILOT.FREE.STANDOFF;
   if (!S || !(so > 0) || !(dt > 0)) return v;
   var p = P.cam.pos, out = v, pass, i;
   for (pass = 0; pass < 3; ++pass) {                       // quitar el empuje hacia una estrella puede acercar a otra: se repite (3 pasadas bastan)
      var sx = out[0] * dt, sy = out[1] * dt, sz = out[2] * dt, L2 = sx * sx + sy * sy + sz * sz, changed = false;
      if (L2 <= 0) break;
      var reach = Math.sqrt(L2) + so;
      for (i = 0; i < S.n; ++i) {
         var dx = S.x[i] - p[0], dy = S.y[i] - p[1], dz = S.z[i] - p[2];
         if (dx > reach || dx < -reach || dy > reach || dy < -reach || dz > reach || dz < -reach) continue;
         var d2 = dx * dx + dy * dy + dz * dz;
         if (d2 > reach * reach) continue;
         var dS = Math.sqrt(d2), vin = (out[0] * dx + out[1] * dy + out[2] * dz) / Math.max(1e-12, dS);
         if (vin <= 0) continue;                              // se aleja o va de lado: no hay nada que proteger
         var u = fvClamp((dx * sx + dy * sy + dz * sz) / L2, 0, 1), ex = dx - sx * u, ey = dy - sy * u, ez = dz - sz * u;
         if (ex * ex + ey * ey + ez * ez >= so * so) continue;   // el segmento pasa a STANDOFF o mas: libre
         var allow = Math.max(0, dS - so) / dt;                // lo que se puede acercar sin pasar de STANDOFF en este paso
         if (vin <= allow) continue;
         var k = (vin - allow) / Math.max(1e-12, dS);
         out = [out[0] - dx * k, out[1] - dy * k, out[2] - dz * k]; changed = true;
         sx = out[0] * dt; sy = out[1] * dt; sz = out[2] * dt; L2 = sx * sx + sy * sy + sz * sz;
      }
      if (!changed) break;
   }
   return out;
}
// un paso del vuelo libre (sin vuelo ni orbita)
function fvFreeStep(P, dt) {
   var F = P.free, FP = FV_PILOT.FREE, cam = P.cam;
   if (!F || dt <= 0) return;
   // (nQ, A2) el zoom de casa del primer arrastre (cerrar solo agranda la foto: A se sigue cumpliendo)
   if (F.homeZoom) {
      var HZo = F.homeZoom; HZo.t += dt;
      if (P.flight || P.orbit || fvLen(cam.pos) > 1e-6) F.homeZoom = null;
      else { var uH = fvClamp(HZo.t / Math.max(1e-6, FP.HOME_DRAG_ZOOM_S), 0, 1); cam.fov = Math.min(cam.fov, Math.exp(fvMix(Math.log(HZo.f0), Math.log(HZo.f1), fvSmoother(uH)))); if (uH >= 1) F.homeZoom = null; if (P.mode === "home") P.mode = "free"; }
   }
   // (5-nov) la cruceta: la tecla sigue viva mientras el boton este pulsado y al menos hasta PAD_TAP_S despues de pulsar (un clic = un paso)
   if (F.pad) for (var pd in F.pad.down) {
      if (F.pad.down[pd] || P.t < (F.pad.rel[pd] || -1)) { F.keys[pd] = true; F.keyT[pd] = P.t; }
      else if (F.pad.rel[pd] !== undefined && F.pad.rel[pd] !== null) { F.keys[pd] = false; F.pad.rel[pd] = null; }
   }
   var boost = fvFreeHeld(P, F, "boost"), fwd = fvFreeHeld(P, F, "fwd"), bk = fvFreeHeld(P, F, "back"), lf = fvFreeHeld(P, F, "left"), rt = fvFreeHeld(P, F, "right"), up = fvFreeHeld(P, F, "up"), dn = fvFreeHeld(P, F, "down");
   // 1. el giro: teclas (con inercia TURN_S, en proporcion al campo de vision) + arrastre que se desliza al soltar
   var turn = FP.TURN_K * cam.fov * (boost ? 1.6 : 1), aT = 1 - Math.exp(-dt / FP.TURN_S);
   F.yawW += (((rt ? 1 : 0) - (lf ? 1 : 0)) * turn - F.yawW) * aT;
   F.pitchW += (((up ? 1 : 0) - (dn ? 1 : 0)) * turn - F.pitchW) * aT;
   if (F.mouseDown) {
      // la velocidad del arrastre (suavizada): si el raton se queda quieto con el boton pulsado, se va a 0 enseguida
      var aM = 1 - Math.exp(-dt / 0.08);
      F.rateYaw += (F.accYaw / dt - F.rateYaw) * aM; F.ratePitch += (F.accPitch / dt - F.ratePitch) * aM;
      F.accYaw = F.accPitch = 0;
   } else {
      var gk = Math.exp(-dt / FP.GLIDE_S);
      F.glideYaw *= gk; F.glidePitch *= gk;
      if (Math.abs(F.glideYaw) + Math.abs(F.glidePitch) < 1e-5) F.glideYaw = F.glidePitch = 0;
   }
   // (I5) el pan con el boton derecho: su velocidad suavizada (al soltar, PAN_GLIDE de ella pasa a la deriva y se apaga con DAMP_S)
   if (F.panDown) { var aPn = 1 - Math.exp(-dt / 0.08), pr0 = F.panRate || [0, 0, 0]; F.panRate = fvAdd(pr0, fvMul(fvSub(fvMul(F.panAcc || [0, 0, 0], 1 / dt), pr0), aPn)); F.panAcc = [0, 0, 0]; }
   var dYaw = (F.yawW + (F.mouseDown ? 0 : F.glideYaw)) * dt, dPitch = (F.pitchW + (F.mouseDown ? 0 : F.glidePitch)) * dt;
   if (Math.abs(F.yawW) < 1e-6 && !lf && !rt) F.yawW = 0;
   if (Math.abs(F.pitchW) < 1e-6 && !up && !dn) F.pitchW = 0;
   if (dYaw || dPitch) {
      cam.look = fvFreeTurn(P, dYaw, dPitch);                        // (nF2) sin salir de la foto (A_GUARD)
      if (P.mode === "home") P.mode = "free";
   }
   // 2. el empuje: velocidad objetivo a lo largo de la mirada, ∝ distancia a lo mas cercano; inercia ACC_S, deriva DAMP_S
   var thr = (fwd ? 1 : 0) - (bk ? 1 : 0), movingW = !!(F.vW && fvLen(F.vW) > 0), moving = fvLen(F.v) > 0 || movingW;
   if (thr === 0 && !moving) { P.wheel = 0; return; }
   // la escala: la distancia a lo mas cercano, pero no menos de 1/4 de lo que se tiene delante (desde casa, la estrella mas cercana
   // del catalogo esta a pocos años luz y de lado: con ella sola, avanzar hacia la foto de 6 500 a.l. no se notaria nunca)
   var nr = fvFreeNearest(P), dN = Math.max(nr.d, 0.25 * fvFreeAhead(P)), kB = boost ? FP.BOOST : 1;
   var vT = fvMul(fvNorm(cam.look), thr * FP.THRUST_K * dN * kB), a = 1 - Math.exp(-dt / (thr !== 0 ? FP.ACC_S : FP.DAMP_S));
   F.v = fvAdd(F.v, fvMul(fvSub(vT, F.v), a));
   var vm = FP.VMAX_K * dN * kB, L = fvLen(F.v);
   if (L > vm) F.v = fvMul(F.v, vm / L);
   // no entrar a menos de STANDOFF de una estrella: se quita la componente que va hacia ella
   if (nr.star >= 0 && nr.dStar < 3 * FP.STANDOFF) {
      var toS = fvSub(fvStarPos(P.scene, nr.star), cam.pos), dS = fvLen(toS), nS = fvMul(toS, 1 / Math.max(1e-12, dS)), vin = fvDot(F.v, nS);
      if (vin > 0) { var allow = vin * fvSmooth((dS - FP.STANDOFF) / (2 * FP.STANDOFF)); F.v = fvSub(F.v, fvMul(nS, vin - allow)); }
   }
   if (thr === 0 && fvLen(F.v) < 1e-4 * dN) F.v = [0, 0, 0];
   F.v = fvFreeStandoff(P, F.v, dt);                       // (K9 H-3) y que el SEGMENTO de este fotograma tampoco entre en la proteccion
   // (5-nov) la velocidad de la RUEDA (F.vW, decae con WHEEL_GLIDE_S): sin el tope VMAX_K (el paso logaritmico nunca pasa de lo que queda por
   // delante), con las mismas protecciones de las estrellas que F.v (lo que quite la proteccion se descuenta de F.vW)
   var tW = FP.WHEEL_GLIDE_S, vWav = [0, 0, 0];
   if (movingW) {
      if (nr.star >= 0 && nr.dStar < 3 * FP.STANDOFF) {
         var toW = fvSub(fvStarPos(P.scene, nr.star), cam.pos), dW = fvLen(toW), nW = fvMul(toW, 1 / Math.max(1e-12, dW)), vinW = fvDot(F.vW, nW);
         if (vinW > 0) F.vW = fvSub(F.vW, fvMul(nW, vinW - vinW * fvSmooth((dW - FP.STANDOFF) / (2 * FP.STANDOFF))));
      }
      var vA = fvAdd(F.v, F.vW), vB = fvFreeStandoff(P, vA, dt);
      F.vW = fvAdd(F.vW, fvSub(vB, vA));
      vWav = fvMul(F.vW, tW * (1 - Math.exp(-dt / tW)) / dt);        // la velocidad media del fotograma (la integral exacta del decaimiento)
   }
   var posPrev = cam.pos.slice();
   cam.pos = fvAdd(cam.pos, fvMul(fvAdd(F.v, vWav), dt));
   if (movingW) { F.vW = fvMul(F.vW, Math.exp(-dt / tW)); if (fvLen(F.vW) < 1e-4 * dN) F.vW = [0, 0, 0]; }
   // (N11) por detras de la Tierra no: tope en el plano de casa (z = 0) y fuera la velocidad hacia atras
   if (FP.HOME_FLOOR && cam.pos[2] < 0 && fvKeepOn() && FV_PILOT.KEEP_IN.FLOOR_STOP) { cam.pos = [cam.pos[0], cam.pos[1], 0]; F.v = [0, 0, 0]; F.vW = [0, 0, 0]; F.wS = null; }   // (6-nov) se para del todo (antes resbalaba de lado)
   if (FP.HOME_FLOOR && cam.pos[2] < 0) { cam.pos = [cam.pos[0], cam.pos[1], 0]; if (F.v[2] < 0) F.v = [F.v[0], F.v[1], 0]; if (F.vW && F.vW[2] < 0) F.vW = [F.vW[0], F.vW[1], 0]; if (fvLen(F.v) < 1e-4 * dN) F.v = [0, 0, 0]; if (F.vW && fvLen(F.vW) < 1e-4 * dN) F.vW = [0, 0, 0]; }
   // (nF2, A_GUARD) la traslacion no deja ver fuera de la foto: si este paso lo exigiria, la nave no pasa (la pared de la foto). Desde una
   // vista que ya incumplia (tras interrumpir un warp) se deja mover si no empeora; el campo se cierra abajo a CLEAN_RATE
   if (FP.A_GUARD) {
      var cA = fvFreeCapA(P, cam.pos, cam.look), tF0 = Math.tan(cam.fov / 2);
      if (cA < 1e9 && cA < tF0 * (1 - 1e-9)) {
         // (nF2, 2.ª corrida) sin cerrar el campo: cerrarlo de golpe era un ZOOM (arrastre 300 px a la deriva tras soltar W: campo ×0,157, se
         // ve como avanzar mucho, lo mismo que E8). El campo lo cierra, despacio, la regla de siempre (CLEAN_CAP); aqui solo la pared
         var cP = fvFreeCapA(P, posPrev, cam.look);
         if (cP >= tF0 * (1 - 1e-9) || cA < cP) {
            // (5-nov, rueda por ritmo) la pared DESLIZA: la nave avanza lo que la pared deja en este fotograma (biseccion, como el pan) y conserva su
            // velocidad. Con la rueda rapida el paso por fotograma supera lo que el campo puede cerrar (CLEAN_RATE: la foto se apaga y el tope
            // baja hasta 21 % en 190 a.l.) y parar en seco cada vez la dejaba a tirones y sin lo que le quedaba por recorrer. WALL_SLIDE false = ROJO
            var tOk = 0;
            if (FP.WALL_SLIDE) {
               var pE = cam.pos, lo = 0, hi = 1, it;
               for (it = 0; it < 14; ++it) {
                  var tm = 0.5 * (lo + hi), cm = fvFreeCapA(P, fvAdd(posPrev, fvMul(fvSub(pE, posPrev), tm)), cam.look);
                  if (cm >= 1e9 || cm >= tF0 * (1 - 1e-9) || (cP < tF0 * (1 - 1e-9) && cm >= cP)) lo = tm; else hi = tm;
               }
               tOk = lo;
            }
            if (tOk > 0.01) cam.pos = fvAdd(posPrev, fvMul(fvSub(cam.pos, posPrev), tOk));
            else { cam.pos = posPrev; F.v = [0, 0, 0]; F.vW = [0, 0, 0]; }
         }
      }
   }
   P.wheel = fvLen(F.v) + (F.vW ? fvLen(F.vW) : 0);          // (F2) la cabina lee P.wheel ≠ 0 como «se mueve»
   if (fvLen(cam.pos) > 1e-9) { if (P.mode === "home") P.mode = "free"; }
   else if (P.mode === "free" && Math.abs(cam.fov - P.homeFov) < 1e-9) P.mode = "home";
   // (N11) el campo de vision se abre con la DISTANCIA a casa (no con el tiempo de movimiento: eso encogia la foto y salia la «bola»)
   var fT = fvFreeFovTarget(P), capC = fvFreeCleanCap(P);   // (coordinador) y no mas de lo que cubre la parte limpia de la foto/capas
   // (LLEGADA, 4-nov noche) el campo se ABRE como mucho hasta ese tope: abriendo hacia 60° (×e^0,12 por fotograma con 0,45°) y cerrando al
   // tope solo a CLEAN_RATE (e^0,05) el campo se escapaba del tope en cada fotograma: la rueda tras llegar a una estrella delante de la
   // nebulosa dejaba 24–72 % de pantalla sin nebulosa. El cierre lento queda para cuando el TOPE baja (volver a mirar hacia la foto).
   // FREE.CLEAN_OPEN false = ROJO
   if (FP.CLEAN_OPEN && capC < fT) fT = Math.max(Math.min(cam.fov, fT), capC);
   // (nF2, FLOW_FOV) avanzando (o quieta) el campo se abre COMO MUCHO lo que manda la ley sin vertigo (FOV_BETA × lo que crece la foto en
   // este paso): desde casa es la ley de siempre (R2 de fv_nB2_node); tras llegar con el campo estrecho, relajarse hacia el de casa mientras
   // se avanza era un zoom hacia atras (el 2,18 % de las estrellas pintadas convergian al punto de fuga, llegadaW de fv_nF2_node). Al
   // retroceder, libre (lo lejano se encoge por las dos cosas: coherente)
   var advF = fvDot(fvSub(cam.pos, posPrev), fvNorm(cam.look));
   if (cam.fov < fT) {
      var fNew = Math.exp(fvMix(Math.log(cam.fov), Math.log(fT), 1 - Math.exp(-dt / FP.FOV_S)));
      if (FP.FLOW_FOV && advF >= 0) {
         // el tope solo cuando el campo esta LEJOS de su objetivo (tras llegar: 0,04° frente a 0,76°); cerca (≥ 0,95 × el objetivo, la rueda
         // desde casa) la relajacion de siempre, y entre medias se mezcla (sin tiron en la velocidad del zoom)
         var NnF = P.scene.nebula, DnF = NnF ? NnF.distLy : 0, zA = posPrev[2], zB = cam.pos[2], bF = (FP.FOV_BETA !== undefined) ? FP.FOV_BETA : 1;
         var growF = (DnF > 0 && zB < 0.999 * DnF && zA < zB) ? Math.log((DnF - zA) / (DnF - zB)) : 0;
         var sFree = Math.log(fNew / cam.fov), wF = fvSmooth((cam.fov / fT - 0.6) / 0.35);
         fNew = cam.fov * Math.exp(Math.min(sFree, bF * growF + wF * sFree));
      }
      cam.fov = Math.max(cam.fov, fNew);
   }
   if (cam.fov > capC) cam.fov = Math.max(capC, cam.fov * Math.exp(-(FP.CLEAN_RATE || 1.5) * dt));
   // lejos de donde se llego: ya no se esta «en» ese objeto (el siguiente viaje sale de aqui)
   // (LOS DOS MODOS) salvo en Foto con el destino DETRAS de la nebulosa (el tour): se llega al punto valido mas cercano, a miles de a.l.,
   // y se sigue «en» ella mientras se la mire (eje a menos de 10°); sin esto la ficha del tour no salia (fv_nav_fix_cdp N1, parada 3)
   if (P.arrivedAt) { var pa = fvSelPos(P, P.arrivedAt); if (pa && fvLen(fvSub(pa, cam.pos)) > 4 * fvArriveDist(P, P.arrivedAt)) {
      var seen = fvNmOn() && fvNmMode(P) === "photo" && fvNmBehind(P, pa) && fvDot(fvNorm(fvSub(pa, cam.pos)), cam.look) > Math.cos(10 * FV_DEG);
      if (!seen) P.arrivedAt = null; } }
}
// la distancia al objeto mas cercano (estrella o capa de nebulosa) — la escala de la rueda
function fvNearestDist(P) {
   var S = P.scene.stars, p = P.cam.pos, best = 1e30, i;
   if (S) for (i = 0; i < S.n; ++i) { var dx = S.x[i] - p[0], dy = S.y[i] - p[1], dz = S.z[i] - p[2], d = dx * dx + dy * dy + dz * dz; if (d < best) best = d; }
   best = Math.sqrt(best);
   if (P.scene.nebula) { var L = P.scene.nebula.layers; for (i = 0; i < L.length; ++i) { var dz2 = Math.abs(L[i].z - p[2]); if (dz2 < best) best = dz2; } }
   return best;
}
// el muelle de la mirada hacia `target` (unitario) con el periodo del estilo
function fvLookSpring(P, target, dt) {
   if (!P.lookState) P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] };
   var per = FV_PILOT.LOOK_PERIOD[P.style] || 1.6;
   fvSpringVec(P.lookState, target, 2 * Math.PI / per, dt);
   return fvNorm(P.lookState.x);
}

// ---------------------------------------------------------------------------
// (6-nov-2026) KEEP_IN: LA NAVE SIEMPRE MIRA DENTRO DE LA FOTO (ver FV_PILOT.KEEP_IN)
// ---------------------------------------------------------------------------
function fvKeepOn() { var K = FV_PILOT.KEEP_IN; return !!(K && K.ON === true); }
function fvKeepIsIn(q, R) { return Math.abs(q[0]) <= R[0] && Math.abs(q[1]) <= R[1]; }
// el punto del rectangulo R (centrado en el eje) en la semirrecta c + s·(dx, dy), s ≥ 0, lo mas lejos que no sale (c dentro de R)
function fvKeepRadial(c, dx, dy, R) {
   var s = 1e30;
   if (dx > 1e-15) s = Math.min(s, (R[0] - c[0]) / dx); else if (dx < -1e-15) s = Math.min(s, (-R[0] - c[0]) / dx);
   if (dy > 1e-15) s = Math.min(s, (R[1] - c[1]) / dy); else if (dy < -1e-15) s = Math.min(s, (-R[1] - c[1]) / dy);
   if (!(s < 1e29)) return [c[0], c[1]];
   s = Math.max(0, s);
   return [c[0] + s * dx, c[1] + s * dy];
}
// el eje (pos, look) frente a la foto: { skip } dentro de la losa y de la huella; si no { ok, p (corte con el plano z = D o null), pc (el punto
// bueno mas cercano: recorte radial desde la proyeccion de la camara sobre el rectangulo) }
function fvKeepAim(G, pos, look, R) {
   var dz = G.D - pos[2];
   if (Math.abs(dz) <= G.hS && Math.abs(pos[0]) <= G.HW && Math.abs(pos[1]) <= G.HH) return { skip: true };
   var c = [fvClamp(pos[0], -R[0], R[0]), fvClamp(pos[1], -R[1], R[1])];
   if (look[2] * dz > 0 && Math.abs(look[2]) > 1e-12) {
      var t = dz / look[2], q = [pos[0] + t * look[0], pos[1] + t * look[1]];
      if (fvKeepIsIn(q, R)) return { ok: true, p: q };
      return { ok: false, p: q, pc: fvKeepRadial(c, q[0] - c[0], q[1] - c[1], R) };
   }
   return { ok: false, p: null, pc: fvKeepRadial(c, look[0], look[1], R) };
}
// (6-nov, WHEEL_BACK) cuanto puede retroceder la camara desde pos a lo largo de −look: hasta el plano de casa (z = 0) o, si retroceder la aleja
// de la Tierra (mirando hacia ella, detras de la foto), hasta z = 2·D (el simetrico de casa respecto a la foto)
function fvKeepBackMax(P, pos, look) {
   var D = P.scene.nebula ? P.scene.nebula.distLy : 1000, lz = look[2];
   if (lz > 1e-6) return Math.max(0, pos[2] / lz * (1 - 1e-6));
   if (lz < -1e-6) return Math.max(0, (2 * D - pos[2]) / (-lz));
   return 0.1 * D;
}
// ¿la mirada look desde pos corta la foto (con la pared K)? (lo usa el warp para elegir llegada)
function fvKeepOkAt(P, pos, look) {
   if (!fvKeepOn() || !P.scene.nebula || fvNmFreeLook(P)) return true;
   var G = fvRouteGeo(P), K = FV_PILOT.KEEP_IN.K, a = fvKeepAim(G, pos, fvNorm(look), [K * G.HW, K * G.HH]);
   return !!(a.skip || a.ok);
}
// (6-nov, BEYOND_FREE) un destino MAS ALLA de la nebulosa (z > zOut: 597 de las 2550 estrellas de Sh 2-199): desde el lado de la Tierra la
// estrella y la foto quedan en lados opuestos, no se pueden ver las dos; manda la estrella (la ficha del tour la necesita en pantalla).
// Mientras se va a ella, se orbita, deriva o se esta junto a ella (P.arrivedAt, que se suelta a 4 distancias de llegada), KEEP_IN no corrige
function fvKeepBeyond(P, E) {
   var KI = FV_PILOT.KEEP_IN; if (!KI || KI.BEYOND_FREE !== true || !E || !P.scene || !P.scene.nebula) return false;
   return E[2] > fvRouteGeo(P).zOut;
}
function fvKeepExemptPt(P) {
   var fl = P.flight;
   if (fl) return (fl.kind === "home" || fl.kind === "look" || fl.kind === "path") ? null : (fl.Tlook || fl.T || null);
   if (P.orbit) return P.orbit.P;
   if (P.coast) return P.coast.T;
   return P.arrivedAt ? fvSelPos(P, P.arrivedAt) : null;
}
// el destino de la maniobra en curso (vuelo que no es a casa, orbita, deriva de llegada, el objeto al que se llego): su punto o null
function fvKeepTarget(P) {
   var fl = P.flight;
   if (fl) { if (fl.kind === "home") return [0, 0, 1]; if (fl.kind === "look" || fl.kind === "path") return null; return fl.Tlook || fl.T || null; }
   if (P.orbit) return P.orbit.P;
   if (P.coast) return P.coast.T;
   return null;
}
// (sin latigazos) la mirada de salida va de prevL hacia want girando con aceleracion acotada (TURN_ACC °/s²) y como mucho FLIP_DPS °/s, frenando
// para llegar sin pasarse (perfil trapecio): un ajuste pequeño se hace en el acto; un giro grande (volverse hacia la foto, 180° al salir por
// detras de la losa) tarda ~2 s y empieza y acaba suave. P.keepW = la velocidad angular de la correccion (rad/s)
function fvKeepTurn(P, prevL, want, dt) {
   var KI = FV_PILOT.KEEP_IN, A = fvAngle(prevL, want);
   if (!(dt > 0) || A < 1e-12) { P.keepW = 0; return want; }
   // la ruta de camaras (vuelo «path») tiene su propio tope de giro (FV_ROUTE.PAN_DPS, el editor lo promete): ahi no hay giro acelerado
   var acc = KI.TURN_ACC * FV_DEG, wMax = ((P.flight && P.flight.kind === "path") ? KI.MAX_DPS : KI.FLIP_DPS) * FV_DEG, w0 = P.keepW || 0;
   // MAX_DPS se permite siempre (los ajustes normales, sin esperar a acelerar); por encima, acelera a TURN_ACC hasta FLIP_DPS y frena a tiempo
   var w = Math.max(Math.min(wMax, Math.sqrt(2 * acc * A), w0 + acc * dt), KI.MAX_DPS * FV_DEG);
   var st = Math.min(A, w * dt); P.keepW = st / dt;
   return (st >= A) ? want : fvSlerpDir(prevL, want, st / A);
}
// el paso: al FINAL de fvPilotStep (la maniobra ya puso su mirada); corrige cam.look (y, con FOV, cam.fov) solo si hace falta
function fvKeepInStep(P, dt) {
   var KI = FV_PILOT.KEEP_IN, cam = P.cam;
   if (!fvKeepOn() || !P.scene || !P.scene.nebula || !P.scene.field) { P.keepIn = null; return; }
   // con destino (vuelo, orbita, deriva) el invariante exacto (K: el eje dentro de la foto); en vuelo libre la pared algo antes (K_WALL)
   // (LOS DOS MODOS) en el modo Foto, la pared K_WALL siempre: con el eje en el borde exacto (K = 1) la foto no puede cubrir COVER_MIN ni cerrando el campo
   var Tq = fvKeepTarget(P), Kr = (fvNmOn() || !(P.flight || P.orbit || P.coast)) ? KI.K_WALL : KI.K;
   var G = fvRouteGeo(P), R = [Kr * G.HW, Kr * G.HH], lk = fvNorm(cam.look), a = fvKeepAim(G, cam.pos, lk, R), S = P.keepIn, prevL = P.keepLookPrev || null;
   if (!fvNmOn() && fvKeepBeyond(P, fvKeepExemptPt(P))) a = { skip: true };   // (BEYOND_FREE, solo con FV_NAV_MODES.ON false: lo de antes)
   P.keepRaw = { ok: !!(a.skip || a.ok), look: lk, fov: cam.fov };            // (para las pruebas y la cabina: lo que pedia la maniobra)
   // sin corregir (dentro de la losa, rodeada de nebulosa; o la mirada pedida ya corta la foto): la de la maniobra; si el fotograma anterior
   // estaba corregido, se vuelve a ella girando como mucho MAX_DPS (al entrar en la losa con la correccion puesta saltaba 1,4° en un paso)
   if (a.skip || (a.ok && !S)) {
      var lOut = lk, fOut = cam.fov;
      if (P.keepBlend && prevL && dt > 0) {
         var fP = P.keepFovPrev || fOut;
         lOut = fvKeepTurn(P, prevL, lk, dt); var aB = fvAngle(lOut, lk), mB = 1e-9;
         if (KI.FOV && fP < fOut * (1 - 1e-9)) fOut = Math.min(fOut, fP * Math.exp(KI.FOV_RATE * dt));
         if (aB <= mB && fOut >= cam.fov * (1 - 1e-9)) P.keepBlend = false;
      } else P.keepBlend = false;
      cam.look = lOut; cam.fov = fOut; P.keepIn = null; P.keepAimLast = a.skip ? null : a.p; P.keepLookPrev = lOut; P.keepFovPrev = fOut; return;
   }
   var pT;
   if (a.ok) pT = a.p;
   else {
      var RA = [KI.K_AIM * G.HW, KI.K_AIM * G.HH];
      if (Tq && Tq[2] > 1e-9) { var qT = [Tq[0] * G.D / Tq[2], Tq[1] * G.D / Tq[2]]; pT = fvKeepIsIn(qT, RA) ? qT : fvKeepRadial([0, 0], qT[0], qT[1], RA); }
      else if (Kr > KI.K_WALL) { var RW2 = [KI.K_WALL * G.HW, KI.K_WALL * G.HH], aW = fvKeepAim(G, cam.pos, lk, RW2); pT = aW.pc || a.pc; }   // (sin destino: no en el borde exacto)
      else pT = a.pc;
   }
   if (!S) {
      // arranca desde donde miraba el fotograma anterior (si cortaba la foto) o desde el punto bueno mas cercano a la mirada pedida
      var p0 = (P.keepAimLast && fvKeepIsIn(P.keepAimLast, R)) ? P.keepAimLast : a.pc;
      S = P.keepIn = { p: [p0[0], p0[1]], t: 0 };
   }
   var tau = a.ok ? KI.TAU_BACK : KI.TAU, k = (dt > 0) ? 1 - Math.exp(-dt / tau) : 0;
   S.p = [S.p[0] + (pT[0] - S.p[0]) * k, S.p[1] + (pT[1] - S.p[1]) * k]; S.t += dt;
   var lN = fvNorm([S.p[0] - cam.pos[0], S.p[1] - cam.pos[1], G.D - cam.pos[2]]);
   // sin latigazos: la mirada corregida no gira mas de MAX_DPS °/s respecto a la del fotograma anterior (solo se nota si se parte de una mirada
   // que no cortaba la foto —una pose puesta a mano, salir de la losa—: entonces vuelve a la foto girando, no de golpe)
   if (!prevL) prevL = lk;                                              // (sin fotograma anterior: desde la mirada pedida)
   lN = fvKeepTurn(P, prevL, lN, dt);
   // el campo: mientras la mirada esta corregida, no mas de lo que cubre la foto ENTERA con este eje (la foto llena la pantalla), cerrandose
   // como mucho FOV_RATE e-folds/s sobre el campo corregido del fotograma anterior (S.fov: la maniobra vuelve a pedir el suyo en cada paso);
   // cuando la mirada pedida vuelve a cortar la foto, se abre hacia el de la maniobra al mismo ritmo (sin salto al soltar)
   var fRaw = cam.fov, fNew = fRaw;
   if (KI.FOV) {
      var fPrev = (S.fov > 0) ? S.fov : fRaw, rt = KI.FOV_RATE * Math.max(0, dt);
      // (suelo FOV_FLOOR × la media altura de la foto a esa distancia: con el eje cerca del borde la cobertura tiende a 0 y era un zoom sin fin)
      if (!a.ok) { var cv = fvRouteCover(P, G, cam.pos, lN, true), cF = KI.FOV_FLOOR * Math.min(G.HW, G.HH) / Math.max(1e-9, Math.abs(G.D - cam.pos[2])); if (cv > 0 && cv < 1e9) cv = Math.max(cv, cF);
         fNew = (cv > 0 && cv < 1e9) ? Math.min(fRaw, Math.max(2 * Math.atan(cv), fPrev * Math.exp(-rt))) : Math.min(fRaw, fPrev * Math.exp(rt)); }
      else fNew = Math.min(fRaw, fPrev * Math.exp(rt));
   }
   if (a.ok && fvAngle(lN, lk) <= KI.TOL * fRaw && fNew >= fRaw * (1 - 1e-9)) { P.keepIn = null; P.keepAimLast = a.p; P.keepLookPrev = lk; P.keepFovPrev = fRaw; P.keepBlend = false; return; }
   cam.look = lN; cam.fov = fNew; S.fov = fNew; P.keepAimLast = S.p.slice(); P.keepLookPrev = lN; P.keepFovPrev = fNew; P.keepBlend = true;
}

// ---------------------------------------------------------------------------
// (6-nov-2026, opcion C de docs/investigacion-navegar-dentro-de-la-foto.md, elegida por Nino) LOS DOS MODOS: FOTO y ESPACIO
// Una sola regla por la que pasan TODAS las maniobras (fvNmStep, al final de fvPilotStep: mano, rueda, cruceta, cine, warp, ruta, orbita,
// tour, llegada); nada de parches por maniobra.
//   FOTO (al arrancar y tras CASA): la camara vive en la PIRAMIDE de la foto (Tierra -> marco de la imagen), sin cruzar la losa de la
//     nebulosa (margen: zMax = zIn − max(MARGIN_HS·medio grosor, MARGIN_D·D)); a lo de dentro de la losa o detras se va en Espacio, con paredes BLANDAS (el paso hacia una pared se frena con un
//     smoothstep de lo que queda: nunca un tope seco ni un salto) y mirando siempre a la foto (KEEP_IN: el eje corta el rectangulo) con la
//     foto cubriendo al menos COVER_MIN de la pantalla (el campo se cierra lo que haga falta). Las estrellas de delante: como siempre.
//   ESPACIO: se entra a proposito, al VIAJAR a algo de DETRAS de la nebulosa (z > zOut), salvo en el tour (TOUR_STAYS: se mira a traves de
//     la nebulosa desde el modo Foto, con una nota de profundidad). Vuelo libre como antes, pero nunca «niebla del desierto»: la foto como
//     PIRAMIDE FANTASMA en su sitio (aristas doradas y la foto translucida; por detras, al reves y atenuada), marcadores en el borde de la
//     pantalla (foto, casa, destino), una brujula pequeña (Tierra y foto) y el rotulo «ESPACIO · fuera de tu foto — H para volver» (lo pintan
//     src/ui/fv_navmodes.js y web/fw_navmodes.js con fvNmHud). CASA (H, doble clic en el cielo, el boton) vuelve al modo Foto.
// FV_NAV_MODES.ON = false: lo de antes (KEEP_IN con su excepcion de mas alla de la nebulosa).
// ---------------------------------------------------------------------------
var FV_NAV_MODES = { ON: true, COVER_MIN: 0.5, MARGIN_HS: 2.0, MARGIN_D: 0.02, BAND_W: 0.15, BAND_Z: 0.06, BAND_HOME: 0.04,
                     GLIDE_S: 0.8, TOUR_STAYS: true, TOUR_Z: 0.005, TOUR_PATCH: 0.35, HOME_OUT: 1.35, HOME_FOV: 50, HOME_AROUND_S: 10, HOME_JUMP: true, JUMP_OUT_S: 0.6, JUMP_IN_S: 0.9, ORBIT_LOOK_S: 3.0, SLAB_FADE: 0.85, GHOST_A: 0.30, LINE_A: 0.85, GHOST_MIN: 0.09, GRID: [16, 9], FOV_MIN_DEG: 0.02 };
// (20-nov-2026, E-nav; Nino, con captura: «Deben servir para ayudar pero a mi no me sirven de nada. No hacen nada si les hago doble clic»)
// LAS AYUDAS DE NAVEGACION EN ESPACIO, una por una (opcion 1 de Nino): la BRUJULA redonda EARTH/PHOTO y el marcador CASA se quitan (el boton
// Home de la barra izquierda ya vuelve a la Tierra: dos caminos a lo mismo es un defecto); el marcador TU FOTO se queda y ahora SIRVE:
// clic o doble clic sobre su placa, su flecha del borde o su rotulo = la nave vuelve volando a la foto (fvNmPhotoSel: el protagonista, como
// IR ALLI de AENIGMATA). COMPASS / HOME_MARK true = lo de antes (la brujula y el marcador CASA); PHOTO_GO false = el marcador es solo un dibujo.
// Web: ?nmcompass=1 ?nmhome=1 ?nmgo=0 (web/fw_navmodes.js). Prueba: tests/_nmx/
// (20-nov-2026, O1; Nino eligio solo la opcion O1 del informe J-desorientacion) THUMB: el marcador TU FOTO (la placa del borde con su flecha, el rotulo de la mira y la
// foto minima) ENSEÑA UNA MINIATURA DE LA PROPIA FOTO (la de trabajo ya estirada, a su proporcion, con marco dorado fino y «TU FOTO · n a.l.» debajo): un astrofotografo
// reconoce su imagen de un vistazo, un rotulo es un texto. THUMB false = lo de antes (placa con icono y texto); THUMB_W = el lado mayor de la miniatura en unidades de HUD
// (× fvHudK = ancho / 1280: 88 → 87 px en la vista de 1271 px de PixInsight y 119 en la web de 1725, ~7 % del ancho en las dos). Se genera UNA vez al construir (FVPainter.nmThumbBuild; web: fwNmThumbBuild), nunca al pintar. Web: ?nmthumb=0
var FV_NMX = { COMPASS: false, HOME_MARK: false, PHOTO_GO: true, THUMB: true, THUMB_W: 88 };
// la geometria de la tarjeta de la miniatura (la comparten el pintor de PixInsight y el web; k = escala de HUD, aspect = alto/ancho de la foto, textW = ancho del rotulo, en px; longest = el lado mayor si no es el de siempre)
// -> { tw, th: la miniatura · cw, ch: la tarjeta entera · pad · tx, ty: donde empieza la miniatura DENTRO de la tarjeta · ly: la linea base del rotulo, desde arriba de la tarjeta }
function fvNmThumbCard(k, aspect, textW, textH, longest) {
   var L = (longest > 0) ? longest : FV_NMX.THUMB_W * k, asp = (aspect > 0) ? aspect : 0.667, tw = asp <= 1 ? L : L / asp, th = asp <= 1 ? L * asp : L, pad = 5 * k, gap = 5 * k;
   var cw = Math.max(tw, textW) + 2 * pad, ch = pad + th + gap + textH + pad;
   return { tw: tw, th: th, cw: cw, ch: ch, pad: pad, tx: (cw - tw) / 2, ty: pad, ly: pad + th + gap + textH * 0.8 };
}
// la seleccion del viaje «volver a la foto»: el protagonista (fvE1cHero: el objeto «hero», la fila principal o la nebulosa); sin el, la nebulosa.
// -> { kind: "star"|"object"|"nebula", i? } | null (escena sin nebulosa: no hay foto a la que volver)
function fvNmPhotoSel(scene) {
   if (!scene || !scene.nebula) return null;
   var h = null; try { h = (typeof fvE1cHero === "function") ? fvE1cHero(scene, "en") : null; } catch (e) { h = null; }
   if (h && h.sel && h.sel.kind === "object" && scene.objects && scene.objects[h.sel.i]) return { kind: "object", i: h.sel.i };
   return { kind: "nebula" };
}
// (los dos modos se apoyan en KEEP_IN: con KEEP_IN apagado es el vuelo libre de antes, y las pruebas que lo apagan para medir las leyes de
// antes siguen midiendo lo mismo)
function fvNmOn() { return typeof FV_NAV_MODES !== "undefined" && FV_NAV_MODES.ON === true && !!FV_PILOT.KEEP_IN && FV_PILOT.KEEP_IN.ON === true; }
function fvNmMode(P) { return (fvNmOn() && P && P.navMode === "space") ? "space" : "photo"; }
function fvNmGeo(P) {
   var G = fvRouteGeo(P), M = FV_NAV_MODES;
   return { G: G, zMax: Math.max(0.05 * G.D, G.zIn - Math.max(M.MARGIN_HS * G.hS, M.MARGIN_D * G.D)), kx: G.HW / G.D, ky: G.HH / G.D };
}
// ¿detras de la nebulosa? (el destino T queda mas alla de la cara trasera de la losa)
// a ESPACIO se va con un destino mas alla de lo que el modo Foto deja (dentro de la losa o detras de la nebulosa)
// (lo de DELANTE de la losa, aunque caiga en el margen, se visita en Foto desde el punto valido mas cercano: fv_nav_fix_pi_test P2)
function fvNmPast(P, T) { return !!(T && P.scene && P.scene.nebula && T[2] > fvRouteGeo(P).zIn); }
// en ESPACIO la mirada es libre salvo yendo (o junto) a algo DENTRO de la nebulosa: ahi sigue KEEP_IN (lo de antes con BEYOND_FREE: la
// mirada solo quedaba libre con un destino detras de la losa; sin esto «fuera» 0,71 al llegar a las estrellas de la losa, fv_llegada_node L1)
function fvNmFreeLook(P) {
   if (fvNmMode(P) !== "space") return false;
   var fl = P.flight;
   // (casa, mirar y las rutas: KEEP_IN como antes; con la camara detras del plano de la foto fvKeepAim ya no la toca)
   if (fl && (fl.kind === "home" || fl.kind === "look" || fl.kind === "path")) return false;
   var t = fl ? (fl.Tlook || fl.T || null) : (P.arrivedAt ? fvSelPos(P, P.arrivedAt) : null);
   return !(t && !fvNmBehind(P, t));
}
function fvNmBehind(P, T) { return !!(T && P.scene && P.scene.nebula && T[2] > fvRouteGeo(P).zOut); }
// coordenadas de la piramide: u = x / (kx·z), v = y / (ky·z) (|u|, |v| ≤ 1 dentro), z
function fvNmToU(N, p) { var z = p[2], e = 1e-9 * N.G.D; if (z <= e) return [0, 0, z]; return [p[0] / (N.kx * z), p[1] / (N.ky * z), z]; }
function fvNmFromU(N, u) { var z = Math.max(0, u[2]); return [u[0] * N.kx * z, u[1] * N.ky * z, u[2]]; }
function fvNmProject(P, p, N, k) {
   N = N || fvNmGeo(P); k = k || 1; var z = fvClamp(p[2], 0, N.zMax), hx = k * N.kx * z, hy = k * N.ky * z;
   return [fvClamp(p[0], -hx, hx), fvClamp(p[1], -hy, hy), z];
}
function fvNmInside(P, p, tol, N) {
   N = N || fvNmGeo(P); tol = tol || 0; var z = p[2], e = tol * N.G.D;
   return z >= -e && z <= N.zMax + e && Math.abs(p[0]) <= N.kx * Math.max(0, z) + e && Math.abs(p[1]) <= N.ky * Math.max(0, z) + e;
}
// la pared blanda: el paso de prev (dentro) a want (dentro, ya proyectado) con la componente hacia cada pared escalada por smoothstep(lo que
// queda / banda): se acerca cada vez mas despacio y no la cruza (como boundaryFriction de camera-controls, o la repulsion de McCrae 2009)
function fvNmSoft(P, prev, want, N) {
   var M = FV_NAV_MODES, a = fvNmToU(N, prev), b = fvNmToU(N, want), o = a.slice();
   function lat(c, d) {
      if (d === 0) return 0;
      var room = (d > 0) ? 1 - c : 1 + c; if (room <= 0) return 0;
      return (d > 0 ? 1 : -1) * Math.min(Math.abs(d) * fvSmooth(room / M.BAND_W), room);
   }
   o[0] = a[0] + lat(a[0], b[0] - a[0]); o[1] = a[1] + lat(a[1], b[1] - a[1]);
   var dz = b[2] - a[2];
   if (dz > 0) { var rU = N.zMax - a[2]; o[2] = a[2] + (rU > 0 ? Math.min(dz * fvSmooth(rU / (M.BAND_Z * N.G.D)), rU) : 0); }
   else if (dz < 0) { var rD = a[2]; o[2] = a[2] - (rD > 0 ? Math.min(-dz * fvSmooth(rD / (M.BAND_HOME * N.G.D)), rD) : 0); }
   if (a[2] <= 1e-9 * N.G.D) { o[0] = b[0]; o[1] = b[1]; }               // en casa (el vertice) la direccion lateral es la del destino
   return fvNmFromU(N, o);
}
// la fraccion de la pantalla (rejilla GRID) cuyos rayos cortan la foto por delante
function fvNmCover(P, pos, look, fov, G) {
   G = G || fvRouteGeo(P); var M = FV_NAV_MODES, nx = M.GRID[0], ny = M.GRID[1], B = fvBasis(fvNorm(look), [0, 1, 0]);
   var tH = Math.tan(fov / 2), tV = tH * (P.VH || 9) / (P.VW || 16), n = 0, hit = 0;
   for (var a = 0; a < nx; ++a) for (var b = 0; b < ny; ++b) {
      var x = ((a + 0.5) / nx * 2 - 1) * tH, y = ((b + 0.5) / ny * 2 - 1) * tV, dz = B.f[2] + x * B.r[2] + y * B.d[2]; ++n;
      if (Math.abs(dz) < 1e-12) continue; var t = (G.D - pos[2]) / dz; if (!(t > 0)) continue;
      if (Math.abs(pos[0] + t * (B.f[0] + x * B.r[0] + y * B.d[0])) <= G.HW && Math.abs(pos[1] + t * (B.f[1] + x * B.r[1] + y * B.d[1])) <= G.HH) ++hit;
   }
   return hit / Math.max(1, n);
}
// el campo mas abierto (≤ fov) con el que la foto cubre COVER_MIN (busqueda binaria: la cobertura baja al abrir el campo)
function fvNmFovCap(P, pos, look, fov, G) {
   var M = FV_NAV_MODES; if (fvNmCover(P, pos, look, fov, G) >= M.COVER_MIN) return fov;
   var lo = M.FOV_MIN_DEG * FV_DEG, hi = fov;
   if (fvNmCover(P, pos, look, lo, G) < M.COVER_MIN) return fov;      // ni cerrando: el eje no esta en la foto (lo arregla KEEP_IN girando)
   for (var i = 0; i < 18; ++i) { var m = Math.sqrt(lo * hi); if (fvNmCover(P, pos, look, m, G) >= M.COVER_MIN) lo = m; else hi = m; }
   return lo;
}
// el tour a un destino DETRAS de la nebulosa, sin salir de Foto: un vuelo de ruta a la linea de vision Tierra -> destino a TOUR_Z × D (casi en
// casa: la FOTO plana solo se pinta hasta PHOTO_FADE × D = 0,03·D; a 0,6·D se veian las capas, en PixInsight casi negro y en la web un velo
// magenta, montaje_dos_modos fila 7), con el campo que deja ver TOUR_PATCH de la foto: la estrella en el eje, la foto nitida alrededor
function fvNmTourStay(P, sel, T) {
   var G = fvRouteGeo(P), M = FV_NAV_MODES, TL = fvSelLookAt(P, sel, T);
   if (!TL || !(TL[2] > 0)) return false;
   var zS = M.TOUR_Z * G.D, pos = fvNmProject(P, fvMul(TL, zS / TL[2]));
   var fov = 2 * Math.atan(M.TOUR_PATCH * G.HW / Math.max(1e-9, G.D - zS));
   if (!fvPilotFlyPath(P, [{ pos: pos, lookAt: TL, fov: fov }], {}) || !P.flight) return false;
   P.flight.sel = sel; P.flight.arriveSel = sel; P.flight.T = T; P.flight.Tlook = TL; P.flight.tourStay = true;
   return true;
}
// (D1) EL RODEO: la recta de casa desde C corta la losa si C esta mas alla de la entrada de la losa y dentro de la piramide infinita (la recta
// pasa por la Tierra: su u y su v no cambian). Entonces: de lado hasta HOME_OUT × la anchura de la piramide (por el eje mas cercano a su
// borde), luego hacia la Tierra hasta delante de la losa (mirandola siempre), en ESPACIO; de ahi,
// casa. Rutas de camaras (fvPilotFlyPath): llaves fuera de la piramide -> Espacio.
function fvNmHomeAround(P) {
   if (!fvNmOn() || !P.scene || !P.scene.nebula || !P.scene.field) return false;
   var N = fvNmGeo(P), G = N.G, C = P.cam.pos, zSafe = G.zIn - Math.max(G.hS, FV_NAV_MODES.MARGIN_D * G.D);
   if (!(C[2] > zSafe)) return false;
   var u = fvNmToU(N, C);
   if (Math.abs(u[0]) > 1 || Math.abs(u[1]) > 1) return false;               // fuera de la huella: la recta de casa ya no toca la losa
   var ax = (Math.abs(u[0]) >= Math.abs(u[1])) ? 0 : 1, sg = (u[ax] < 0) ? -1 : 1, k = ax ? N.ky : N.kx;
   var lat = sg * FV_NAV_MODES.HOME_OUT * k * Math.max(C[2], G.zOut);
   var P1 = C.slice(); P1[ax] = lat;
   var P2 = P1.slice(); P2[2] = zSafe;
   var fv = FV_NAV_MODES.HOME_FOV * FV_DEG, ph = [0, 0, G.D];
   // (la ley de duracion de las rutas es para camaras cercanas: miles de a.l. salian a 200 s; el rodeo dura HOME_AROUND_S × el regulador)
   // (P1 es una parada, sin pausa: si no, el giro de la mirada cabia en la fraccion de tau del tramo de lado y el plan lo estiraba al tope)
   // (las llaves miran a la FOTO y entre ellas se sigue mirandola, trackLook: con la direccion interpolada se perdia de vista al pasar su plano)
   if (!fvPilotFlyPath(P, [{ pos: P1, lookAt: ph, fov: fv, holdS: 0.01 }, { pos: P2, lookAt: ph, fov: fv }], { durS: FV_NAV_MODES.HOME_AROUND_S * fvSpeedDurK(P), trackLook: true }) || !P.flight) return false;
   P.flight.thenHome = true; P.flight.homeAround = true;
   return true;
}
// (7-nov, Nino eligio «salto con fundido») EL SALTO A CASA: desde el Espacio (o con la camara fuera de la piramide) la vuelta a casa no
// vuela: fundido a oro (JUMP_OUT_S, la vista se queda quieta), salto a la pose de casa en modo Foto bajo el oro opaco y fundido de vuelta
// (JUMP_IN_S). Sin giro, sin cruzar la losa, sin negro. Desde FOTO se sigue volando (cine): dentro de la piramide la vuelta normal nunca
// cruza la losa ni pierde la foto y dura 3,4–5,9 s (medido en Sh 2-199 desde 0,001·D hasta zMax: el «salto corto»). HOME_JUMP false = el
// rodeo de la losa (fvNmHomeAround, ~50 s a velocidad 0,5)
function fvNmJumpWanted(P) {
   if (!FV_NAV_MODES.HOME_JUMP || !fvNmOn() || !P.scene || !P.scene.nebula || !P.scene.field) return false;
   if (fvLen(P.cam.pos) < 1e-9 && P.navMode !== "space") return false;
   return P.navMode === "space" || !!P.navPending || !!P.navReturn || !fvNmInside(P, P.cam.pos, 1e-6);
}
function fvNmJumpStart(P) {
   var M = FV_NAV_MODES;
   P.flight = { kind: "jump", t: 0, dur: M.JUMP_OUT_S + M.JUMP_IN_S, sel: null, T: null, phase: "fade-out", jumped: false,
                p0: P.cam.pos.slice(), look0: P.cam.look.slice(), fov0: P.cam.fov, pre: 0 };
   P.orbit = null; P.mode = "flight"; P.arrivedAt = null; P.sunMark = false; P.warp = 0; P.trail = 0; P.flash = 0;
   P.events.push({ t: P.t, what: "home-jump" });
}
function fvNmJumpStep(P, dt) {
   var fl = P.flight, M = FV_NAV_MODES; fl.t += dt;
   if (!fl.jumped && fl.t >= M.JUMP_OUT_S) {
      // el salto, bajo el oro opaco (fvNmJumpFade = 1 en este fotograma): la pose de casa y el estado de Foto limpio (sin giro que deshacer)
      fvPilotHomeNow(P); P.flight = fl; P.mode = "flight"; fl.jumped = true; fl.jumpT = P.t; fl.phase = "fade-in";
      P.keepIn = null; P.keepBlend = false; P.keepLookPrev = P.cam.look.slice(); P.keepFovPrev = P.cam.fov; P.keepAimLast = null;
      P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] }; P.navPrev = [0, 0, 0]; P.navLag = false; P.navOrbitEnt = null; P.restT = 0; P.driftApplied = [0, 0];
      P.events.push({ t: P.t, what: "home-jump-teleport" });
   }
   P.vel = [0, 0, 0]; P.speedLyS = 0; P.speedC = 0;
   if (fl.t >= fl.dur) {
      P.flight = null; P.mode = "home"; P.events.push({ t: P.t, what: "arrive", kind: "jump" });
      if (typeof P.onFlightEnd === "function") { try { P.onFlightEnd(P, fl); } catch (eJ) {} }
   }
}
// la opacidad del oro (0…1) y el destello (0…1, centro mas claro alrededor del salto): lo que pintan las dos cabinas
function fvNmJumpFade(P) {
   var fl = P && P.flight;
   if (!fl || fl.kind !== "jump") return { a: 0, flash: 0 };
   var M = FV_NAV_MODES, t = fl.t, a;
   if (t < M.JUMP_OUT_S) a = fvSmoother(fvClamp(t / (0.9 * M.JUMP_OUT_S), 0, 1));
   else a = 1 - fvSmoother(fvClamp((t - M.JUMP_OUT_S - 0.08) / (M.JUMP_IN_S - 0.08), 0, 1));
   return { a: a, flash: fvClamp(1 - Math.abs(t - M.JUMP_OUT_S) / 0.35, 0, 1) };
}
// (F3) la losa se aclara mientras la camara esta DENTRO de ella en el Espacio (nunca un campo de color uniforme): 1 − SLAB_FADE × dentro
function fvNmSlabFade(P) {
   if (!fvNmOn() || fvNmMode(P) !== "space" || !P.scene || !P.scene.nebula || !P.scene.field) return 1;
   var N = fvNmGeo(P), G = N.G, c = P.cam.pos, th = Math.max(1e-9, G.zOut - G.zIn);
   var outZ = Math.max(0, G.zIn - c[2], c[2] - G.zOut), inW = 1 - fvSmooth(outZ / (0.5 * th));
   var u = fvNmToU(N, c), inF = 1 - fvSmooth((Math.max(Math.abs(u[0]), Math.abs(u[1])) - 1) / 0.1);
   return 1 - FV_NAV_MODES.SLAB_FADE * inW * inF;
}
// el peso de la foto «de verdad» (1 dentro de la piramide, 0 detras de la losa o muy fuera): el pintor funde la foto con su fantasma con 1 − v
function fvNmValid(P, p) {
   if (!P.scene || !P.scene.nebula) return 1;
   var N = fvNmGeo(P), G = N.G, u = fvNmToU(N, p), z = p[2];
   var sL = 1 - fvSmooth((Math.max(Math.abs(u[0]), Math.abs(u[1])) - 1) / 0.5);
   var sZ = 1 - fvSmooth((z - N.zMax) / Math.max(1e-9, G.zOut + G.hS - N.zMax)), sB = 1 - fvSmooth(-z / (0.05 * G.D));
   return Math.min(sL, sZ, sB);
}
// LA REGLA, en cada paso (prev = la posicion antes de la maniobra de este paso)
function fvNmStep(P, dt, prev) {
   if (!fvNmOn() || !P.scene || !P.scene.nebula || !P.scene.field) { P.navPrev = null; fvKeepInStep(P, dt); return; }
   var cam = P.cam;
   var N = fvNmGeo(P);
   if (P.navPending === "photo" && !P.flight) {
      P.navPending = null;
      var a0 = fvKeepAim(N.G, cam.pos, fvNorm(cam.look), [N.G.HW, N.G.HH]);
      if (fvNmInside(P, cam.pos, 1e-6, N) && a0.ok) { P.navMode = "photo"; P.navPrev = cam.pos.slice(); }
      else P.navReturn = { t0: P.t };                                   // llego fuera: la vuelta a la piramide, todavia en Espacio (rotulo y fantasma)
   }
   // una camara PUESTA fuera de la piramide desde fuera del piloto (una prueba, un estado guardado; no una maniobra desde dentro): no se
   // la arrastra de golpe a la pared, se pasa al Espacio y vuelve sola (al acabar el vuelo, o con la vuelta suave)
   if (P.navMode !== "space" && !(P.navPrev && fvNmInside(P, P.navPrev, 1e-6, N)) && !fvNmInside(P, cam.pos, 1e-6, N)) {
      P.navMode = "space"; P.navEnterT = P.t; P.navPending = "photo"; P.navReturn = null;
   }
   if (P.navMode === "space" && P.navReturn && !P.flight) {
      // LA VUELTA (cine corto): la camara se desliza al punto bueno mas cercano, la mirada gira a la foto sin latigazo y el campo se cierra
      // hasta el de la foto; cuando todo esta en su sitio, modo Foto (sin ningun salto al cambiar)
      var kR = (dt > 0) ? 1 - Math.exp(-dt / FV_NAV_MODES.GLIDE_S) : 0, wR = fvNmProject(P, cam.pos, N);
      cam.pos = fvAdd(cam.pos, fvMul(fvSub(wR, cam.pos), kR));
      var lW = fvNorm(fvSub([0, 0, N.G.D], cam.pos)), lP = P.keepLookPrev || cam.look;
      cam.look = fvKeepTurn(P, lP, lW, dt);
      var fW = fvNmFovCap(P, cam.pos, lW, cam.fov, N.G); cam.fov = Math.exp(Math.log(cam.fov) + (Math.log(fW) - Math.log(cam.fov)) * kR);
      P.keepLookPrev = cam.look.slice(); P.keepFovPrev = cam.fov;
      if (fvLen(fvSub(cam.pos, wR)) < 1e-4 * N.G.D && fvAngle(cam.look, lW) < 0.2 * FV_DEG && cam.fov <= fW * 1.02) {
         cam.pos = wR; P.navReturn = null; P.navMode = "photo"; P.navPrev = cam.pos.slice(); P.keepBlend = false;   // (el ultimo 1e-4·D: invisible)
      }
      return;
   }
   if (P.navMode === "space") {
      P.navPrev = cam.pos.slice();
      // (D2) la orbita (o su arrastre) que salio de la piramide vuelve a Foto al volver a entrar (con margen: sin parpadeo en la pared)
      // con keepBlend: la mirada vuelve a la de la maniobra girando ≤ MAX_DPS desde la anterior (sin el, latigazo de 53° medido en la sonda)
      if (P.navOrbit && !P.flight) {
         var uO = fvNmToU(N, cam.pos);
         if (cam.pos[2] > 0 && cam.pos[2] <= N.zMax * 0.995 && Math.abs(uO[0]) <= 0.97 && Math.abs(uO[1]) <= 0.97) { P.navOrbit = false; P.navMode = "photo"; P.navLag = false; P.keepBlend = true; cam.look = fvKeepTurn(P, P.keepLookPrev || cam.look, cam.look, dt); P.keepLookPrev = cam.look.slice(); return; }
      }
      // (D2) la orbita en el Espacio lleva SU mirada (a su centro), sin KEEP_IN: con KEEP_IN la mirada se clavaba en la foto y al volver a
      // entrar la orbita la devolvia a la estrella de golpe (latigazo de 176–179°, banco y sonda). La diferencia de la ENTRADA (la mirada de
      // Foto, en la foto, frente a la de la orbita, a la estrella: hasta 173°) se apaga en ORBIT_LOOK_S y viaja con la orbita (cada fotograma
      // se gira con ella). Probado y descartado: seguirla con tope MAX_DPS o con un filtro (el arrastre gira igual de deprisa: 30–50° atras)
      if (P.navOrbit && P.orbit && !P.flight) {
         var raw0 = fvNorm(cam.look), Oe = P.navOrbitEnt;
         if (!Oe) Oe = P.navOrbitEnt = { from: fvNorm(P.keepLookPrev || raw0), raw: raw0, t0: P.t };
         var axO = fvCross(Oe.raw, raw0), sA = fvLen(axO), fr = Oe.from;
         if (sA > 1e-12) { var kO = fvMul(axO, 1 / sA), aO = Math.atan2(sA, fvDot(Oe.raw, raw0)), cs = Math.cos(aO), sn = Math.sin(aO);  // Rodrigues: el giro de este fotograma
            fr = fvAdd(fvAdd(fvMul(fr, cs), fvMul(fvCross(kO, fr), sn)), fvMul(kO, fvDot(kO, fr) * (1 - cs))); }
         Oe.from = fvNorm(fr); Oe.raw = raw0;
         cam.look = fvSlerpDir(Oe.from, raw0, fvSmoother(fvClamp((P.t - Oe.t0) / FV_NAV_MODES.ORBIT_LOOK_S, 0, 1)));
         P.keepIn = null; P.keepBlend = false; P.keepLookPrev = cam.look.slice(); P.keepFovPrev = cam.fov; return;
      }
      if (!fvNmFreeLook(P)) { fvKeepInStep(P, dt); return; }                 // a algo de dentro de la losa: la mirada sigue en la foto
      P.keepIn = null; P.keepBlend = false; P.keepLookPrev = cam.look.slice(); P.keepFovPrev = cam.fov; return;
   }
   // la posicion: un VUELO (cine, warp, ruta, orbita, casa) que no sale de la piramide pasa tal cual (bit a bit: sus pruebas de antes siguen
   // valiendo); si se sale, roza la pared (la proyeccion, continua) y, al volver a entrar, se reengancha con una vuelta suave (GLIDE_S), sin
   // salto. Lo MANUAL (teclas, rueda, cruceta, inercia) frena en la banda de la pared: se acerca cada vez mas despacio y no la cruza
   var raw = cam.pos.slice(), auto = !!(P.flight || P.orbit), pc = P.navPrev || prev || raw;
   if (!fvNmInside(P, pc, 1e-9, N)) pc = fvNmProject(P, pc, N);
   if (auto) {
      if (fvNmInside(P, raw, 0, N)) {
         if (P.navLag) { var kL = (dt > 0) ? 1 - Math.exp(-dt / (0.25 * FV_NAV_MODES.GLIDE_S)) : 1; cam.pos = fvAdd(pc, fvMul(fvSub(raw, pc), kL)); }
         P.navLag = fvLen(fvSub(cam.pos, raw)) > 1e-6 * N.G.D; if (!P.navLag) cam.pos = raw;
      } else if (P.orbit && !P.flight) {
         // (D2) una ORBITA (o su arrastre) que saldria de la piramide pasa al ESPACIO en vez de deformarse contra la pared: el radio a la
         // estrella se conserva (fv_nF2_node E8); al volver a entrar, Foto otra vez (arriba, en el Espacio)
         P.navMode = "space"; P.navEnterT = P.t; P.navOrbit = true; P.navOrbitEnt = null; P.navPending = null; P.navReturn = null; P.navLag = false; P.navPrev = raw;
         fvKeepInStep(P, dt); return;
      } else { cam.pos = fvNmProject(P, raw, N); P.navLag = true; }
      // la ORBITA que roza la pared sigue mirando a su centro desde donde de verdad esta la camara (sin esto la elegida se iba de la
      // pantalla: fv_f1_test C4, (9919, −405) px)
      if (P.orbit && P.navLag && P.orbit.P) { var dO = fvSub(P.orbit.P, cam.pos); if (fvLen(dO) > 1e-9) cam.look = fvNorm(dO); }
   } else { cam.pos = fvNmSoft(P, pc, fvNmProject(P, raw, N), N); P.navLag = false; }
   P.navPrev = cam.pos.slice();
   fvKeepInStep(P, dt);                                                // la mirada en la foto (eje dentro del rectangulo, giro sin latigazos)
   var fC = fvNmFovCap(P, cam.pos, cam.look, cam.fov, N.G);           // y la foto cubre COVER_MIN de la pantalla
   if (fC < cam.fov) { cam.fov = fC; P.keepFovPrev = fC; if (P.keepIn) P.keepIn.fov = fC; }
}
// lo que dibujan las dos cabinas (PixInsight y web) y lo que mide el banco: rotulo, fantasma, marcadores y brujula, en pixeles W × H
function fvNmHud(P, W, H) {
   var out = { mode: fvNmMode(P), banner: false, ghost: 0, lines: [], ghostOnScreen: false, markers: [], compass: null, note: null, valid: 1 };
   if (!fvNmOn() || !P.scene || !P.scene.nebula) return out;
   var G = fvRouteGeo(P), cam = P.cam, pr = fvProjector(cam, W, H), f = pr.fw, v = fvNmValid(P, cam.pos), Snm = pr.S || 1;   // Snm: el estirado lateral del laboratorio (1 sin el)
   out.valid = v;
   var labA = !!(P.lab && P.lab.anchorOn && typeof FV_LAB !== "undefined" && FV_LAB.ON === true);   // (8-nov, LABORATORIO, D10) el ancla: piramide y marcadores sin paisaje
   if (out.mode === "space" || labA) {
      out.banner = out.mode === "space"; out.ghost = Math.max(0.35, 1 - v);
      // la piramide: Tierra -> 4 esquinas y el marco, recortadas en el plano cercano (tipo 0 = arista, 1 = marco)
      var C = [[-G.HW, -G.HH, G.D], [G.HW, -G.HH, G.D], [G.HW, G.HH, G.D], [-G.HW, G.HH, G.D]], E = [0, 0, 0], segs = [];
      for (var i = 0; i < 4; ++i) { segs.push([E, C[i], 0]); segs.push([C[i], C[(i + 1) % 4], 1]); }
      var nearZ = 1e-6 * G.D;
      for (var s = 0; s < segs.length; ++s) {
         // (11-nov, NV-17) con la navegacion v5 el proyector trabaja en el espacio de vuelo (x, y × S): la profundidad de cada extremo tambien
         var A = segs[s][0], Bp = segs[s][1], rA = fvSub(A, cam.pos), rB = fvSub(Bp, cam.pos), dA = Snm * (rA[0] * f[0] + rA[1] * f[1]) + rA[2] * f[2], dB = Snm * (rB[0] * f[0] + rB[1] * f[1]) + rB[2] * f[2];
         if (dA <= nearZ && dB <= nearZ) continue;
         if (dA <= nearZ) A = fvAdd(A, fvMul(fvSub(Bp, A), (nearZ - dA) / (dB - dA)));
         else if (dB <= nearZ) Bp = fvAdd(Bp, fvMul(fvSub(A, Bp), (nearZ - dB) / (dA - dB)));
         var qa = pr.project(A, nearZ * 0.5), qb = pr.project(Bp, nearZ * 0.5); if (!qa || !qb) continue;
         out.lines.push([qa[0], qa[1], qb[0], qb[1], segs[s][2]]);
         for (var q = 0; q <= 16 && !out.ghostOnScreen; ++q) { var x = qa[0] + (qb[0] - qa[0]) * q / 16, y = qa[1] + (qb[1] - qa[1]) * q / 16; if (x >= 0 && x <= W && y >= 0 && y <= H) out.ghostOnScreen = true; }
      }
   }
   // los marcadores: la foto (su centro), casa (la Tierra) y el destino; en pantalla, una mira; fuera (o detras), una flecha en el borde
   var tgt = P.flight ? (P.flight.Tlook || P.flight.T || null) : (P.sel ? fvSelPos(P, P.sel) : (P.arrivedAt ? fvSelPos(P, P.arrivedAt) : null));
   var list = [["photo", [0, 0, G.D]]]; if (FV_NMX.HOME_MARK === true) list.push(["home", [0, 0, 0]]);   // (20-nov, E-nav) sin el marcador CASA: el boton Home ya vuelve
   if (tgt && fvLen(fvSub(tgt, [0, 0, G.D])) > 1e-6) list.push(["target", tgt]);
   var inset = 0.045 * Math.min(W, H) + 18;
   // (20-nov, V1a, V1-10) «la foto esta detras»: con el laboratorio y la foto fuera de pantalla, el marcador TU FOTO sale en el borde aunque se vean estrellas (antes: solo sin paisaje)
   var aidPh = !labA && typeof fvV1PhotoAid === "function" && fvV1PhotoAid(P, W, H, pr);
   for (var m = 0; m < list.length; ++m) {
      if (aidPh && out.mode !== "space" && list[m][0] !== "photo") continue;      // en Espacio ya salen todos los marcadores (solo no se pintaban sin el ancla)
      if (out.mode !== "space" && !labA && !aidPh) break;
      var Pm = list[m][1], vx = Pm[0] - cam.pos[0], vy = Pm[1] - cam.pos[1], vz = Pm[2] - cam.pos[2], d = Math.sqrt(vx * vx + vy * vy + vz * vz);
      if (!(d > 1e-9)) continue;
      // (11-nov, NV-17) la direccion en el espacio de VUELO (la distancia d de arriba, la real): sin S los marcadores caian donde no era — con la
      // estrella centrada en pantalla el destino salia como flecha en el borde (6 de 9 mal en tests/_nav11/nav_default_probe.js)
      if (Snm !== 1) { vx *= Snm; vy *= Snm; }
      var zc = (vx * f[0] + vy * f[1] + vz * f[2]), xc = (vx * pr.r[0] + vy * pr.r[1] + vz * pr.r[2]), yc = (vx * pr.d[0] + vy * pr.d[1] + vz * pr.d[2]);
      var on = false, sx = 0, sy = 0;
      if (zc > 1e-9 * d) { sx = pr.cx + pr.f * xc / zc; sy = pr.cy + pr.f * yc / zc; on = sx >= inset && sx <= W - inset && sy >= inset && sy <= H - inset; }
      var mk = { kind: list[m][0], on: on, x: sx, y: sy, dist: d, behind: zc <= 0 };
      if (!on) {
         var ax = xc, ay = yc; if (Math.abs(ax) + Math.abs(ay) < 1e-12) { ax = 0; ay = 1; }
         var an = Math.atan2(ay, ax), cs = Math.cos(an), sn = Math.sin(an), hw = W / 2 - inset, hh = H / 2 - inset;
         var sc = Math.min(hw / Math.max(1e-9, Math.abs(cs)), hh / Math.max(1e-9, Math.abs(sn)));
         mk.x = W / 2 + cs * sc; mk.y = H / 2 + sn * sc; mk.ang = an;
      }
      if (aidPh && list[m][0] === "photo") out.aidPhoto = true;
      out.markers.push(mk);
   }
   if (out.mode === "space" || labA) {
      // (F2) la foto fantasma PEQUEÑA en pantalla (desde detras, de lejos): se dibuja a un tamaño minimo (GHOST_MIN del ancho de la pantalla),
      // con su marco luminoso, las aristas de la piramide mas fuertes y el rotulo «TU FOTO · x a.l.»
      var qs = [[-G.HW, -G.HH, G.D], [G.HW, -G.HH, G.D], [G.HW, G.HH, G.D], [-G.HW, G.HH, G.D]].map(function(c) { return pr.project(c); });
      var dPh = fvLen(fvSub([0, 0, G.D], cam.pos));
      if (qs[0] && qs[1] && qs[2] && qs[3]) {
         var x0 = Math.min(qs[0][0], qs[1][0], qs[2][0], qs[3][0]), x1 = Math.max(qs[0][0], qs[1][0], qs[2][0], qs[3][0]);
         var y0 = Math.min(qs[0][1], qs[1][1], qs[2][1], qs[3][1]), y1 = Math.max(qs[0][1], qs[1][1], qs[2][1], qs[3][1]);
         var gcx = 0.5 * (x0 + x1), gcy = 0.5 * (y0 + y1), gw = x1 - x0, gh = y1 - y0, wMin = FV_NAV_MODES.GHOST_MIN * W;
         out.ghostRect = { cx: gcx, cy: gcy, w: gw, h: gh, dist: dPh, behind: cam.pos[2] > G.D };
         if (gcx > 0 && gcx < W && gcy > 0 && gcy < H && gw < wMin) {
            var asp = G.HH / G.HW;
            out.ghostMin = { cx: gcx, cy: gcy, w: wMin, h: wMin * asp, dist: dPh, behind: cam.pos[2] > G.D, k: fvClamp(1 - gw / wMin, 0, 1) };
         }
      }
      // (F1) de espaldas a la foto: un halo dorado tenue en el borde de la pantalla hacia ella (donde esta su flecha)
      for (var mg = 0; mg < out.markers.length; ++mg) if (out.markers[mg].kind === "photo" && !out.markers[mg].on) out.glow = { x: out.markers[mg].x, y: out.markers[mg].y, ang: out.markers[mg].ang, behind: out.markers[mg].behind };
      // la brujula: las direcciones a la Tierra y a la foto en el marco de la camara (x a la derecha, y abajo, z delante)
      var dirC = function(p) { var w = fvNorm(fvSub(p, cam.pos)); return [fvDot(w, pr.r), fvDot(w, pr.d), fvDot(w, f)]; };
      if (FV_NMX.COMPASS === true) out.compass = { earth: dirC([0, 0, 0]), photo: dirC([0, 0, G.D]) };   // (20-nov, E-nav) sin la brujula redonda EARTH/PHOTO (COMPASS false)
   }
   // la nota de profundidad: en el modo Foto, junto a (o yendo a) una estrella de detras de la nebulosa
   var sNote = P.flight ? P.flight.sel : (P.arrivedAt || P.sel);
   if (out.mode === "photo" && sNote) { var Tn = fvSelPos(P, sNote); if (Tn && fvNmBehind(P, Tn)) out.note = { beyondLy: Tn[2] - G.zOut, distLy: fvLen(Tn) }; }
   return out;
}
// el invariante del banco: en todo fotograma hay una referencia (Foto: la foto cubre COVER_MIN; Espacio: rotulo + piramide o marcador de la foto)
function fvNmRefOk(P, W, H, hud) {
   hud = hud || fvNmHud(P, W, H);
   if (hud.mode === "space") { if (!hud.banner) return false; if (hud.ghostOnScreen) return true; for (var i = 0; i < hud.markers.length; ++i) if (hud.markers[i].kind === "photo") return true; return false; }
   return fvNmCover(P, P.cam.pos, P.cam.look, P.cam.fov) >= FV_NAV_MODES.COVER_MIN - 0.02;
}
// (6-nov-2026) LA FRENADA del centro de la cruceta (FV_PILOT.BRAKE): ∫ (1 − smootherstep) de 0 a u (lo recorrido, en unidades de v0 · dur)
function fvBrakeI(u) { u = fvClamp(u, 0, 1); return u - (u * u * u * u * (2.5 + u * (-3 + u))); }
function fvPilotBrake(P) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabBrake(P);                    // (8-nov, LABORATORIO)
   if (!P || !P.cam || !FV_PILOT.BRAKE || FV_PILOT.BRAKE.ON !== true) return false;
   // (LOS DOS MODOS) frenar es pararse AQUI: en el Espacio se cancela la vuelta pendiente a Foto (H vuelve); sin esto, al parar empezaba el
   // deslizamiento de vuelta y la nave seguia moviendose (fv_nav_fix_cdp N3: v 2,8 a.l./s 3 s despues)
   P.navPending = null; P.navReturn = null;
   var cam = P.cam, v = (P.vel && isFinite(P.vel[0])) ? P.vel.slice() : [0, 0, 0], L = fvLen(v);
   if (P.flight && P.flight.kind === "look") v = [0, 0, 0];
   // el tope de velocidad de tomar el mando (VMAX_K × lo mas cercano, no menos de 1/4 de lo de delante): del warp salen miles de a.l./s
   var nr = fvFreeNearest(P), dN = Math.max(nr.d, 0.25 * fvFreeAhead(P)), vm = FV_PILOT.FREE.VMAX_K * dN;
   if (L > vm) { v = fvMul(v, vm / L); L = vm; }
   var dur = Math.max(0.05, FV_PILOT.BRAKE.S * fvSpeedDurK(P));
   var had = !!(P.flight || P.orbit || P.coast);
   P.events.push({ t: P.t, what: "brake", from: P.flight ? P.flight.kind : (P.orbit ? "orbit" : (P.coast ? "coast" : "free")), v0: L });
   fvFreeState(P); fvFreeHalt(P); fvPilotLookPadRelease(P);
   P.brake = { v0: v, t: 0, dur: dur, w0: P.warp || 0, tr0: P.trail || 0, fov0: cam.fov, had: had };
   P.flight = null; P.orbit = null; P.coast = null; P.flash = 0;
   if (P.mode !== "home" || fvLen(cam.pos) > 1e-9) P.mode = "free";
   P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
   return true;
}
function fvBrakeStep(P, dt) {
   var B = P.brake, cam = P.cam;
   var u0 = B.t / B.dur; B.t += dt; var u1 = Math.min(1, B.t / B.dur), e = fvSmoother(u1);
   cam.pos = fvAdd(cam.pos, fvMul(B.v0, B.dur * (fvBrakeI(u1) - fvBrakeI(u0))));
   P.warp = B.w0 * (1 - e); P.trail = B.tr0 * (1 - e);
   // el campo del warp (o de la maniobra) vuelve al del vuelo libre aqui (sin abrir mas de lo que habia)
   var fT = Math.min(B.fov0, fvFreeFovTarget(P), fvFreeCleanCap(P));
   if (fT > 0 && fT < B.fov0) cam.fov = Math.exp(fvMix(Math.log(B.fov0), Math.log(fT), e));
   if (u1 >= 1) { P.brake = null; P.warp = 0; P.trail = 0; P.events.push({ t: P.t, what: "brake-stop" }); }
}

// ---------------------------------------------------------------------------
// UN PASO DE RELOJ (dt en segundos de escena)
// ---------------------------------------------------------------------------
function fvPilotStep(P, dt) {
   if (typeof FV_LAB !== "undefined" && FV_LAB.ON === true && typeof fvLabOn === "function" && fvLabOn(P)) return fvLabStep(P, dt);                 // (8-nov, LABORATORIO DE VUELO: una ley, sin correcciones posteriores)
   var cam = P.cam, prev = cam.pos.slice(), prevFov = cam.fov;
   P.t += dt; P.flash = 0;
   if (P.flight && P.flight.kind === "jump") { fvNmJumpStep(P, dt); return P; }          // (7-nov) el salto a casa con fundido
   if (P.flight) {
      var fl = P.flight; fl.t += dt;
      var w = 0, x, s, u = fvClamp(fl.t / fl.dur, 0, 1), lt;
      if (fl.kind === "look") {
         var e = Math.sin(Math.PI / 2 * u); e *= e;
         cam.look = fvSlerpDir(fl.look0, fl.look1, e);
         cam.fov = Math.exp(fvMix(Math.log(fl.fov0), Math.log(fl.fov1), e));
      } else if (fl.route) {
         fvRouteStep(P, fl);                                         // (RUTA) cine, casa y editor: el plan, muestreado
      } else if (fl.kind === "warp" && fl.t < fl.pre) {
         // el efecto vertigo: la camara avanza hacia el objetivo y el campo se abre lo justo para que el objetivo no cambie de tamaño
         var kz = 1 + (FV_PILOT.DOLLY_K - 1) * fvSmoother(fl.t / fl.pre);
         cam.pos = fvAdd(fl.dollyFrom, fvMul(fl.dollyDir, fl.dollyDist * (1 - 1 / kz)));
         cam.fov = Math.min(FV_PILOT.MAX_FOV, 2 * Math.atan(Math.tan(fl.fov0 / 2) * kz));
         cam.look = fvSlerpDir(fl.look0, fl.dollyDir, fvSmooth(fl.t / fl.pre));
         if (FV_PILOT.CINE_ADVANCE) cam.fov = Math.min(cam.fov, fvPhotoFovCap(P));      // (B2) el vertigo tampoco enseña el borde de la foto (destino delante de ella)
         cam.fov = Math.min(cam.fov, fvWarpSlabFovCap(P, fl));                            // (LLEGADA) ni pasada la zona de la foto, hasta la losa
         P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
      } else {
         var trailW = 0, inhale = 0, fovP, bounce = 0, shakeDeg = 0, uc = u;
         if (fl.kind === "warp") {
            var tw = fl.t - fl.pre, pr = fvWarpProfile(tw, fl.cruise, fl.kPh);
            fl.phaseDur = pr.phaseDur;
            x = fvWarpS(fl.prof, tw); w = pr.warp; P.flash = pr.flash; trailW = pr.trail; inhale = pr.inhale; fl.phase = pr.phase;
            fl.warpPhase = pr.warpPhase; fl.phaseT = pr.phaseT; bounce = pr.bounce; shakeDeg = pr.shakeDeg;
         } else if (fl.kind === "home") {
            var uH = fvClamp(fl.t / (fl.travelS || fl.dur), 0, 1);       // (5.ª corrida) el viaje; despues (closeS) se cierra el campo quieta
            x = fvSmoother(uH); fl.phase = fvFlightPhaseU("home", u); u = uH;                                // (N5) sin tiron de aceleracion
         }
         else {
            // (N5) cine: CINE_PRE s de plano quieto, despues arranque suave y frenada larga sobre el resto (uc = fraccion del viaje en si)
            var pre = fl.cinePre || 0; uc = fvClamp((fl.t - pre) / Math.max(1e-6, fl.dur - pre), 0, 1);
            x = fvCineX(uc); fl.phase = (fl.t < pre) ? "depart" : fvFlightPhaseU("cine", uc);
         }
         cam.pos = fl.path.at(x);
         s = fl.path.sOf(Math.min(1, x));
         // (RUTA, R12/R13) el warp con mirada y campo planificados (fvRouteWarpPlan); lo de abajo (muelle, topes y guardas) = ROJO
         var wpl = (fl.kind === "warp" && FV_PILOT.ROUTE.WARP) ? (fl.wplan || fvRouteWarpPlan(P, fl)) : null;
         if (wpl) {
            var pAt = cam.pos; fvRouteSample(P, wpl, fl.t - fl.pre); cam.pos = pAt;
            P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
         } else {
         if (fl.kind === "home") lt = fl.look1;
         else lt = fvNorm(fvSub(fl.Tlook || fl.T, cam.pos));
         var look0 = (fl.kind === "warp" && fl.pre > 0) ? fl.dollyDir : fl.look0, turn;
         // (B2, 3.ª corrida) vuelta a casa desde delante de la nebulosa (o desde dentro) mirando hacia ella: se mira a su CENTRO desde el
         // principio (en casa es la mirada de casa). Mirando al destino la linea de vision caia junto al borde de la parte limpia y el
         // tope de cobertura tocaba su minimo (0,3): 4 % de pantalla sin nebulosa y un zoom hasta 0,18° (nB2_casa_tira.png, col. 3)
         var homeNeb = fl.kind === "home" && fl.adv && FV_PILOT.CINE_FG_FILL && P.scene.nebula && fl.p0[2] > 0 && fl.p0[2] < P.scene.nebula.distLy && fl.look0[2] > 0.5;
         if (homeNeb) lt = fvNorm(fvSub([0, 0, P.scene.nebula.distLy], cam.pos));
         if (homeNeb) turn = fvSmoother(fvClamp(fl.t / (0.3 * fl.dur), 0, 1));
         else if (fl.kind === "warp") turn = fvSmooth(fvClamp((fl.t - fl.pre) / (1.2 * (fl.kPh || 1)), 0, 1));                         // en el warp se encara en los primeros 1,2 s de la preparacion
         else if (fl.kind === "home" && fl.adv && fvLen(fl.p0) > 1.01 * fl.zoneH * 2) {
            // (B2) la mirada ya esta en la foto ANTES de entrar en su zona (con el arco giraba en el ultimo 3 % de la escala y llegaba torcida:
            // el tope de la foto con la mirada fuera de ella no puede tapar el borde)
            turn = fvSmoother(fvClamp(Math.log(fvLen(fl.p0) / Math.max(1e-9, fvLen(cam.pos))) / Math.log(fvLen(fl.p0) / (2 * fl.zoneH)), 0, 1));
         }
         else if (fl.kind === "home") { turn = Math.sin(Math.PI / 2 * fvClamp((s - 0.25) / 0.5, 0, 1)); turn *= turn; }
         else {
            turn = fvSmoother((uc - FV_PILOT.CINE_TURN0) / (FV_PILOT.CINE_TURN1 - FV_PILOT.CINE_TURN0));       // (N5) cine: solo en el tramo central del TIEMPO
            // (B2) con el avance el campo cambia por el camino: el desvio del tercio es FRAME_THIRD × el campo que hay (el del fotograma previo)
            lt = fvFrameDir(lt, (fl.adv ? FV_PILOT.FRAME_THIRD * prevFov : fl.frameOff) * fvSmoother((uc - 0.55) / 0.40));   // (E) el tercio entra durante la frenada
         }
         var want = fvSlerpDir(look0, lt, turn), sp = fvLookSpring(P, want, dt);
         // al final, exacta (el muelle se queda atras unos grados): se funde en el ultimo 12 %
         cam.look = fvSlerpDir(sp, want, fvSmooth((u - 0.88) / 0.12));
         // (B2) en la vuelta a casa, sin el retraso del muelle al acercarse a la zona de la foto (exacta a menos de 2 × su radio)
         if (fl.kind === "home" && fl.adv) cam.look = fvSlerpDir(cam.look, want, 1 - fvSmooth((fvLen(cam.pos) - 2 * fl.zoneH) / (2 * fl.zoneH)));
         if (homeNeb) cam.look = want;                                                                          // (B2) sin el retraso del muelle
         if (shakeDeg > 0) cam.look = fvLookJitter(cam.look, shakeDeg * FV_DEG, P.t);                       // (E) vibracion del crucero / sacudida de salida
         var fov0 = (fl.kind === "warp" && fl.pre > 0) ? fl.fovD : fl.fov0;
         // (N5) en el cine el campo se abre con el avance en tau (repartido por todo el viaje); antes con el arco, que se recorre casi
         // entero en el centro del viaje y abria el campo de golpe
         fovP = (fl.kind === "cine") ? fvSmoother(fvClamp(x / 0.85, 0, 1)) : fvClamp(s, 0, 1);
         var fovB = Math.exp(fvMix(Math.log(fov0), Math.log(fl.fov1), fovP));
         // (5.ª corrida) DOS GESTOS: revelacion quieta (fov0 -> abierto en el plano quieto) y avance con el campo fijo que solo se cierra
         if (fl.kind === "cine" && fl.fovOpen) {
            var pre2 = fl.cinePre || 0;
            fovB = (fl.t < pre2) ? Math.exp(fvMix(Math.log(fov0), Math.log(fl.fovOpen), fvSmoother(fl.t / Math.max(1e-6, pre2))))
                                 : Math.exp(fvMix(Math.log(fl.fovOpen), Math.log(fl.fov1), fvSmoother((uc - FV_PILOT.CINE_CLOSE0) / (1 - FV_PILOT.CINE_CLOSE0))));
         } else if (fl.kind === "cine" && fl.adv) {
            // (B2) EL AVANCE QUE SALE DE LA FOTO: tan(campo/2) = tan0 · (d0/d)^beta (ver FV_PILOT.CINE_ADVANCE); si se sale con un campo
            // mayor que el de llegada, se cierra en log con lo recorrido de la escala (cerrar solo agranda el destino)
            var dNow = Math.max(1e-9, fvLen(fvSub(fl.T, cam.pos))), gLog = Math.max(0, Math.log(fl.dist0 / dNow));
            if (fl.closeNeed > 0) fovB = 2 * Math.atan(fl.tan0 * Math.exp(-fl.closeNeed * fvSmoother(gLog / Math.max(1e-6, FV_PILOT.CINE_BETA_AT * fl.availLog))));
            else fovB = Math.min(fl.fov1, 2 * Math.atan(fl.tan0 * Math.exp(fl.beta * gLog)));
            if (fl.slabZ > 0 && cam.pos[2] < fl.slabZ && fl.t >= (fl.cinePre || 0)) fovB = Math.min(fovB, fvPhotoCoverFov(P, true));   // (B2) A' (cam.look es la de este fotograma)
         } else if (fl.kind === "home" && fl.adv) {
            // (B2) la vuelta en un gesto: el campo se cierra con la ESCALA recorrida (log de la distancia a casa) hasta el de casa justo al
            // entrar en la zona de la foto (dZ); dentro, el tope de la foto (abajo) lo lleva a la cobertura. Desde cerca de casa, con x.
            var dH0 = fvLen(fl.p0), dHn = fvLen(cam.pos), dZ = fl.zoneH;
            fovB = (dH0 > 1.01 * dZ) ? Math.exp(fvMix(Math.log(fov0), Math.log(fl.fov1), fvSmoother(fvClamp(Math.log(dH0 / Math.max(1e-9, dHn)) / Math.log(dH0 / dZ), 0, 1))))
                                     : Math.exp(fvMix(Math.log(fov0), Math.log(fl.fov1), fvSmoother(fvClamp(x, 0, 1))));
         } else if (fl.kind === "home" && fl.closeS > 0) {
            fovB = (fl.t < fl.travelS) ? fov0 : Math.exp(fvMix(Math.log(fov0), Math.log(fl.fov1), fvSmoother((fl.t - fl.travelS) / fl.closeS)));
         }
         cam.fov = Math.min(FV_PILOT.MAX_FOV, fvMix(fovB, FV_PILOT.MAX_FOV, w)) * (1 - FV_PILOT.WARP.INHALE * inhale) * (1 - bounce);   // 105° a fondo; «inspira»; rebote
         // sin encoger la foto de bordes rectos al salir de casa — salvo en la revelacion, cuyo sentido es ver la foto dentro del cielo
         // (B2) y ahora tambien en la vuelta a casa en un gesto (fl.adv)
         if ((fl.kind !== "home" || fl.adv) && !(fl.kind === "cine" && fl.fovOpen)) {
            // (K9 H-2) si el vuelo SE EMPIEZA con un campo ya mayor que el tope (interrumpir la revelacion del cine con un warp: la revelacion
            // evita el tope y el warp lo aplicaba de golpe, ×9 de zoom en un paso, aun con dt = 0), el tope se suelta DESDE el campo que hay:
            // baja como mucho a CINE_FOV_RATE e-folds por segundo hasta alcanzar el tope. Si el campo de salida cabe en el tope (el warp
            // normal desde casa), capSoft queda en false y nada cambia.
            var capK = fvPhotoFovCap(P);
            if (fl.capSoft === undefined) fl.capSoft = (prevFov > capK * (1 + 1e-6));
            if (fl.capSoft) { var capS = prevFov * Math.exp(-FV_PILOT.CINE_FOV_RATE * dt); if (capS > capK) capK = capS; else fl.capSoft = false; }
            cam.fov = Math.min(cam.fov, capK);
            // (B2, 3.ª corrida) en la vuelta a casa desde DELANTE de la nebulosa (o de dentro, mirando a ella) tambien fuera de la zona de la
            // foto: al alejarse la nebulosa encoge de verdad y con el campo abriendose a la ley de casa quedaba un sello con bordes (54 % de
            // pantalla sin nebulosa, nB2_test). El campo sigue a lo que cubre su parte limpia: un zoom hacia dentro mientras se retrocede.
            if (fl.kind === "home" && fl.adv && FV_PILOT.CINE_FG_FILL && cam.pos[2] > 0 && cam.pos[2] < 0.999 * (P.scene.nebula ? P.scene.nebula.distLy : 0) && cam.look[2] > 0.5)
               cam.fov = Math.min(cam.fov, fvPhotoCoverFov(P, true));
         }
         // (3.ª corrida) en el cine, al soltarse el tope el campo saltaba de 0,9° a 2,4° en 0,1 s (ritmo 9,5/s en log): se limita lo que
         // puede ABRIRSE por segundo (cerrarse no). El warp no: su salto de campo es el efecto.
         if (fl.kind === "cine" && !fl.fovOpen && fl.fovPrev) cam.fov = Math.min(cam.fov, fl.fovPrev * Math.exp(FV_PILOT.CINE_FOV_RATE * dt));
         // (B2) guarda de B: el destino no encoge nunca en pantalla (tan(campo/2) · distancia no sube de un fotograma al siguiente)
         if (fl.kind === "cine" && fl.adv) {
            var dB = Math.max(1e-9, fvLen(fvSub(fl.T, cam.pos))), bNow = Math.tan(cam.fov / 2) * dB;
            if (fl.bPrev !== undefined && bNow > fl.bPrev) { cam.fov = 2 * Math.atan(fl.bPrev / dB); bNow = fl.bPrev; }
            fl.bPrev = bNow;
            // (B2, 3.ª corrida) y la NEBULOSA de delante tampoco (tan(campo/2) · (D − z) no sube) mientras no se ha entrado en ella: con
            // un destino delante de la nebulosa la ley del avance abria el campo y la nebulosa de fondo encogia un 26 % (fv_nB_test C3,
            // 67 fotogramas; node: peor paso ×0,969). Dentro de la losa ya no (alli el campo se abre a la vista de llegada).
            var NbG = P.scene.nebula;
            if (NbG && FV_PILOT.CINE_FG_FILL && cam.pos[2] < NbG.distLy - NbG.thickLy / 2 && fl.t >= (fl.cinePre || 0)) {
               var dN = NbG.distLy - cam.pos[2], nNow = Math.tan(cam.fov / 2) * dN;
               if (fl.nPrev !== undefined && nNow > fl.nPrev) { cam.fov = 2 * Math.atan(fl.nPrev / dN); nNow = fl.nPrev; fl.bPrev = Math.tan(cam.fov / 2) * dB; }
               fl.nPrev = nNow;
            }
         }
         }                                                           // (RUTA) fin de la ley de antes (sin plan)
         fl.fovPrev = cam.fov;
         P.trail = trailW;
      }
      if (fl.kind === "look") fl.phase = fvFlightPhaseU("look", u);
      P.warp = w;
      if (fl.kind !== "warp") P.trail = w;
      fl.prevPos = prev;
      if (fl.t >= fl.dur) {
         // (B2) el avance del cine llega con el campo que lleva (si el viaje es corto puede ser menor que ARRIVE_FOV): sin salto final
         if (fl.kind === "cine" && fl.adv) { fl.fov1 = cam.fov; fl.frameOff = FV_PILOT.FRAME_THIRD * fl.fov1; fl.look1 = fvFrameDir(fvNorm(fvSub(fl.Tlook || fl.T, fl.p1)), fl.frameOff); }
         // (RUTA) un vuelo planificado llega a su ultimo punto del plan (sin salto); el warp planificado, con su mirada y su campo
         var plE = fl.plan || fl.wplan;
         if (plE) { if (fl.plan) fl.p1 = plE.pos[plE.n].slice(); fl.look1 = plE.look[plE.n].slice(); fl.fov1 = 2 * Math.atan(Math.exp(plE.lt[plE.n])); }
         cam.pos = fl.p1.slice(); cam.look = fl.look1.slice(); cam.fov = fl.fov1; P.warp = 0; P.trail = 0;
         P.flight = null; fl.phase = null;
         if (fl.kind === "path") fl.keyIdx = fl.nKeys - 1;
         if (fl.kind === "home") { P.mode = "home"; P.arrivedAt = null; }
         else if (fl.kind === "look" || fl.kind === "path") { P.mode = "free"; if (fl.arriveSel) P.arrivedAt = fl.arriveSel; }
         else { P.mode = "free"; P.arrivedAt = fl.sel; }
         // (LOS DOS MODOS, D1) el rodeo de la losa acaba delante de ella, fuera de la piramide: de ahi, la vuelta a casa de siempre (sin aviso
         // de llegada intermedio: para la cabina es un solo viaje)
         var thenHome = (fl.kind === "path" && fl.thenHome);
         P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
         P.events.push({ t: P.t, what: "arrive-" + fl.kind });
         // (N5) la DERIVA de llegada del cine: sigue rodeando el objeto con la velocidad angular del final del camino, apagandose
         if (fl.kind === "cine" && dt > 0) {
            var cT = fl.Tlook || fl.T, rp = fvSub(prev, cT), rn = fvSub(cam.pos, cT), ax = fvCross(rp, rn), wA = fvAngle(rp, rn) / dt;
            if (fvLen(ax) > 1e-15 && wA > 0) {
               var cTau = FV_PILOT.COAST_S * (fvFastOn() ? FV_PILOT.FAST.COAST_K * fvSpeedDurK(P) : 1);     // (6-nov, FAST_EASE) × COAST_K × el regulador
               var wMax = FV_PILOT.COAST_MAX_DEG * FV_DEG / cTau;
               P.coast = { T: cT, axis: fvNorm(ax), w0: Math.min(wA, wMax), t: 0, tau: cTau, total: 0, frameOff: fl.frameOff || 0,
                           aim: fl.route ? fvScreenTan(cam.pos, cam.look, cT) : null };   // (RUTA) el destino se queda donde llego en pantalla
            }
         }
         if (thenHome) fvPilotFly(P, "home", null);
         else if (typeof P.onFlightEnd === "function") { try { P.onFlightEnd(P, fl); } catch (eEnd) {} }
      }
   } else if (P.orbit) {
      var o = P.orbit; o.t += dt;
      var FPo = FV_PILOT.FREE, rkOld = o.rK || 1;
      // (I5) la rueda en orbita: la distancia al objeto va hacia rKT (× la de partida) en ORBIT_ZOOM_S, sin saltos
      if (FPo.GAIA_MOUSE === true && o.rKT && Math.abs(o.rKT - rkOld) > 1e-9 * o.rKT) o.rK = Math.exp(fvMix(Math.log(rkOld), Math.log(o.rKT), 1 - Math.exp(-dt / FPo.ORBIT_ZOOM_S)));
      if (FPo.GAIA_MOUSE === true && o.manual) {
         // (I5) A MANO (se toco con el raton): sin orbita automatica. Arrastrando, la velocidad suavizada (para el planeo); suelto, el planeo
         if (o.drag) { var aMo = 1 - Math.exp(-dt / 0.08); o.rYaw += (o.accYaw / dt - o.rYaw) * aMo; o.rPitch += (o.accPitch / dt - o.rPitch) * aMo; o.accYaw = o.accPitch = 0; }
         else if (o.gYaw || o.gPitch) { fvOrbitTurn(P, o.gYaw * dt, o.gPitch * dt); var gkO = Math.exp(-dt / FPo.GLIDE_S); o.gYaw *= gkO; o.gPitch *= gkO; if (Math.abs(o.gYaw) + Math.abs(o.gPitch) < 1e-5) o.gYaw = o.gPitch = 0; }
         if (o.rK && o.rK !== rkOld) cam.pos = fvAdd(o.P, fvMul(fvSub(cam.pos, o.P), o.rK / rkOld));
         cam.look = fvNorm(fvSub(o.P, cam.pos));
      } else {
         o.w = (FV_PILOT.ORBIT_DEG_S[P.style] || 8) * FV_DEG * fvSmooth(o.t / 2.0);   // arranque suave
         o.theta += o.w * dt;
         // la inclinacion del plano de la orbita cambia despacio: el eje vertical se inclina ±22° en un ciclo de 40 s
         var tilt = FV_PILOT.ORBIT_TILT_DEG * FV_DEG * Math.sin(2 * Math.PI * o.t / FV_PILOT.ORBIT_TILT_S) * fvSmooth(o.t / 3.0);
         var axis = fvRotate([0, 1, 0], o.tiltAx, tilt);
         o.axis = axis;
         cam.pos = fvAdd(o.P, fvMul(fvRotate(o.r0, axis, o.theta), o.rK || 1));
         var target = fvNorm(fvSub(o.P, cam.pos)), spO = fvLookSpring(P, target, dt);
         // el muelle suaviza la ENTRADA; despues la mirada va clavada al objeto (con el muelle solo se quedaba ~4° atras)
         cam.look = fvSlerpDir(spO, target, fvSmooth(o.t / 2.0));
      }
      P.warp = 0; P.trail = 0;
   } else if (FV_PILOT.WHEEL_F2 && P.wheel !== 0) {
      // (N11) ROJO: la rueda de F2 (paso ∝ objeto mas cercano en 0,18 s y el campo abriendose ×(1+2k) en CADA fotograma hasta 60°)
      var k = 1 - Math.exp(-dt / 0.18), step = P.wheel * k;
      cam.pos = fvAdd(cam.pos, fvMul(fvNorm(cam.look), step));
      P.wheel -= step; if (Math.abs(P.wheel) < 1e-9) P.wheel = 0;
      if (P.mode === "free" && cam.fov < FV_PILOT.ARRIVE_FOV) cam.fov = Math.min(FV_PILOT.ARRIVE_FOV, cam.fov * (1 + 2 * k));
      P.warp = 0; P.trail = 0;
   } else {
      P.warp = 0; P.trail = 0;
      if (P.coast) {
         // (N5) la deriva de llegada: girar alrededor del objeto con w0·e^(−t/tau), mirada clavada en el; se acaba sola
         // (K11b) la integral EXACTA de w0·e^(−t/tau) en el paso (antes w(t+dt)·dt: con un paso de 30 s giraba 0,02° de los 6° que da con
         // pasos de 1/60 s); el total ya no depende del paso. COAST_EXACT false = ROJO
         var C = P.coast, cT0 = C.t; C.t += dt;
         var dth = FV_PILOT.COAST_EXACT ? C.w0 * C.tau * (Math.exp(-cT0 / C.tau) - Math.exp(-C.t / C.tau)) : C.w0 * Math.exp(-C.t / C.tau) * dt;
         cam.pos = fvAdd(C.T, fvRotate(fvSub(cam.pos, C.T), C.axis, dth)); C.total += dth;
         cam.look = C.aim ? fvAimAt(cam.pos, C.T, C.aim[0], C.aim[1]) : fvFrameDir(fvNorm(fvSub(C.T, cam.pos)), C.frameOff);
         P.lookState = { x: cam.look.slice(), v: [0, 0, 0] };
         if (C.t > 5 * C.tau) P.coast = null;
      }
      if (P.brake) fvBrakeStep(P, dt);                            // (6-nov) la frenada del centro de la cruceta
      else if (P.free) fvFreeStep(P, dt);
   }
   // (E) DERIVA VIVA: quieta fuera de casa, la mirada respira (dos senos). Se aplica la DIFERENCIA con lo ya aplicado (no se acumula); al
   // dejar de estar quieta se olvida (el siguiente movimiento sale de la mirada que haya: sin salto)
   var Fz = P.free, rest = !P.flight && !P.orbit && !P.coast && P.mode === "free" && !(Fz && (Fz.mouseDown || fvLen(Fz.v) > 0 || (Fz.vW && fvLen(Fz.vW) > 0) || Fz.yawW || Fz.pitchW || Fz.glideYaw || Fz.glidePitch));
   if (rest && dt > 0 && FV_PILOT.LIVE_DRIFT_ON) {                // (B2) apagada por defecto: en reposo, quieta
      P.restT = (P.restT || 0) + dt;
      // (4.ª corrida) la amplitud va con el campo (la de E es para 60°): con el campo de casa (0,76°) 0,12° eran el 16 % del cuadro y
      // dejaban ver el borde de la foto
      var wD = fvSmooth((P.restT - 0.3) / FV_PILOT.LIVE_DRIFT_IN) * Math.min(1, cam.fov / FV_PILOT.ARRIVE_FOV), oD = fvLiveDriftAt(P.t), prevD = P.driftApplied || [0, 0];
      var dy = wD * oD[0] - prevD[0], dp = wD * oD[1] - prevD[1];
      if (dy || dp) { var ypD = fvYawPitchOf(cam.look); cam.look = fvDirYawPitch(ypD.yaw + dy, ypD.pitch + dp); }
      P.driftApplied = [wD * oD[0], wD * oD[1]];
   } else { P.restT = 0; P.driftApplied = [0, 0]; }
   fvNmStep(P, dt, prev);                                         // (6-nov, LOS DOS MODOS: la regla unica; KEEP_IN va dentro) (6-nov, KEEP_IN) la mirada siempre corta la foto, en todas las maniobras
   if (dt > 0) {
      P.vel = fvMul(fvSub(cam.pos, prev), 1 / dt); P.speedLyS = fvLen(P.vel); P.speedC = P.speedLyS * FV_PILOT.SEC_PER_YEAR;
      P.odo += fvLen(fvSub(cam.pos, prev));
   }
   return P;
}

// ---------------------------------------------------------------------------
// LO QUE LEEN LOS RELOJES DE LA CABINA (F2, con sentido fisico en todos los modos):
//   VELOCITAS  la velocidad de la camara en AÑOS LUZ POR SEGUNDO de tu tiempo (el viaje va comprimido: 6 500 años luz en 4 s son
//              5·10¹⁰ c, una cifra que no dice nada; «1 600 a.l./s» dice lo deprisa que pasa el paisaje). Escala log 10⁻³ … 10⁴ a.l./s.
//   DISTANTIA  la distancia a la TIERRA (siempre la misma referencia: «lo lejos que estas de casa»), rotulada «a Terra».
//   CHRONOMETRUM el reloj de a bordo (tiempo de escena desde que se encendio la nave).
//   REGULATOR  la potencia del warp (o el empuje del viaje de cine).
// ---------------------------------------------------------------------------
function fvPilotGauges(P) {
   var T = fvSelPos(P, P.sel);
   return { speedLyS: P.speedLyS, speedC: P.speedC, warp: P.warp, dist: fvLen(P.cam.pos), distTo: "earth", distTarget: T ? fvLen(fvSub(T, P.cam.pos)) : null,
            clock: P.t, fovDeg: P.cam.fov / FV_DEG, odo: P.odo, style: P.style, pad: fvPilotPadState(P),
            brake: P.brake ? fvClamp(1 - P.brake.t / P.brake.dur, 0, 1) : fvLabHubBrake(P) };   // (6-nov) lo que queda de frenada (el cubo de la cruceta se enciende)
}
// (17-nov, P35) la frenada de la v5 (P.lab.brake, no P.brake): el cubo luce mientras quede mas del 1 % de la velocidad de al pulsar (FV_LAB.HUB_BRAKE; false = 0)
function fvLabHubBrake(P) {
   if (typeof FV_LAB === "undefined" || FV_LAB.HUB_BRAKE !== true || !P || !P.lab || !P.lab.brake || !(P.lab.brakeV0 > 0)) return 0;
   var vRel = fvLen((P.vel && isFinite(P.vel[0])) ? P.vel : [0, 0, 0]) / P.lab.brakeV0;
   return vRel > 0.01 ? Math.min(1, vRel) : 0;
}

// ---------------------------------------------------------------------------
// ELEGIR CON EL RATON: la estrella mas cercana al cursor (en pantalla, con ventaja para las brillantes); si no hay, la nebulosa
// si el cursor cae dentro de alguna capa. -> { kind: "star", i, sx, sy } | { kind: "nebula", sx, sy } | null
// ---------------------------------------------------------------------------
function fvPick(P, sx, sy, radiusPx, magOf) {
   var S = P.scene.stars, pr = fvProjector(P.cam, P.VW, P.VH), best = null, bs = 1e30, i;
   // (F2) el alcance del clic crece con el brillo (como el disco dibujado): una debil hay que tocarla; una brillante, cerca basta.
   // Sin esto, con 8000 estrellas en la foto siempre habia una a < 24 px y la nebulosa no se podia elegir nunca (fv_f2_test, 4-nov).
   var lim = fvLookLimits(P.cam.fov, P.homeFov || P.cam.fov), onlyPrint = fvPrintOnly();
   if (S) for (i = 0; i < S.n; ++i) {
      if (onlyPrint && fvPrintW(P.scene, i, 0) < 1) continue;               // (nF2) las de fuera de la huella no se pintan: tampoco se eligen
      var q = pr.project([S.x[i], S.y[i], S.z[i]]);
      if (!q) continue;
      var dx = q[0] - sx, dy = q[1] - sy, d = Math.sqrt(dx * dx + dy * dy);
      if (d > radiusPx) continue;
      var mA = fvApparentMag(S.g[i], S.dEarth[i], fvLen(fvSub([S.x[i], S.y[i], S.z[i]], P.cam.pos))), reach = Math.min(radiusPx, FV_PILOT.PICK_PX0 + FV_PILOT.PICK_PX_MAG * (lim.magLim - 2 - mA));
      if (d > reach) continue;
      var m = magOf ? magOf(i, q[2]) : S.g[i], score = d + 2.0 * m;               // 1 magnitud vale 2 px
      if (score < bs) { bs = score; best = { kind: "star", i: i, sx: q[0], sy: q[1] }; }
   }
   if (best) return best;
   var N = P.scene.nebula;
   if (N) for (var k = 0; k < N.layers.length; ++k) {
      var L = N.layers[k], c = pr.project([0, 0, L.z]);
      if (!c) continue;
      var a = pr.project([L.x0, L.y0, L.z]), b = pr.project([L.x1, L.y1, L.z]);
      if (a && b && sx >= Math.min(a[0], b[0]) && sx <= Math.max(a[0], b[0]) && sy >= Math.min(a[1], b[1]) && sy <= Math.max(a[1], b[1])) {
         // (N13, 20-nov; FV_OBJ.BG_HERO) sin nebulosa de catalogo la capa es «Background nebulosity»: lo que hay ahi es el protagonista dibujado (Caldwell 5 = IC 342), que es lo que el Tour y MIRABILIA ya rotulan
         var bg = (typeof fvNebBgHero === "function") ? fvNebBgHero(P.scene) : -1;
         if (bg >= 0) return { kind: "object", i: bg, sx: sx, sy: sy };
         return { kind: "nebula", sx: sx, sy: sy };
      }
   }
   return null;
}

// ---------------------------------------------------------------------------
// EL TOUR (F2): los objetos mas interesantes del campo, en orden de viaje. info(i) -> { radius, teff, lum } (de src/science, si esta).
// Criterios (uno por parada, sin repetir): la MAS BRILLANTE de la foto, la MAYOR (radio), la MAS CALIENTE, la MAS CERCANA, la que
// tiene EXOPLANETA (si hay) y la NEBULOSA. Solo estrellas MEDIDAS de la foto. -> [{ kind, i?, why }]
// ---------------------------------------------------------------------------
function fvTourPick(scene, info, exoHosts, max) {
   var S = scene.stars, out = [], used = {}, i, n = max || 5;
   if (!S) return out;
   var c = { bright: -1, big: -1, hot: -1, near: -1 }, v = { bright: 99, big: -1, hot: -1, near: 1e30 };
   var dMaxBox = (typeof FV_BOX !== "undefined" && FV_BOX.ON && FV_BOX.TOUR && typeof fvBoxDMax === "function") ? fvBoxDMax(scene) : 0;
   for (i = 0; i < S.n; ++i) {
      if (S.q[i] !== 0 || !S.inFrame[i]) continue;
      if (dMaxBox > 0 && S.x[i] * S.x[i] + S.y[i] * S.y[i] + S.z[i] * S.z[i] > dMaxBox * dMaxBox) continue;    // (14-nov, A) el tour solo visita lo que cabe en la caja 3D (FV_BOX.TOUR)
      if (S.g[i] < v.bright) { v.bright = S.g[i]; c.bright = i; }
      if (S.dEarth[i] < v.near) { v.near = S.dEarth[i]; c.near = i; }
      var inf = info ? info(i) : null;
      if (inf && inf.radius > v.big && S.g[i] < 15) { v.big = inf.radius; c.big = i; }
      if (inf && inf.teff > v.hot && S.g[i] < 15) { v.hot = inf.teff; c.hot = i; }
   }
   // (E2b, 17-nov; FV_HERO.TOUR) la ULTIMA parada es el protagonista de la foto (el objeto dibujado, o la nebulosa principal si el protagonista es ella) y su hueco esta RESERVADO: las estrellas
   // (exoplaneta incluido) se quedan con n − 1. Sin protagonista (o con la bandera a false) lo de siempre: estrellas y, si queda hueco, la nebulosa.
   var heroStop = null;
   if (typeof FV_HERO !== "undefined" && FV_HERO.ON && FV_HERO.TOUR && scene.hero && n > 1) {
      if (scene.hero.src === "object" && scene.objects) { for (i = 0; i < scene.objects.length; ++i) if (scene.objects[i].id === scene.hero.id) { heroStop = { kind: "object", i: i, why: "hero" }; break; } }
      // una nebulosa de la lista PROMOVIDA a principal (IC 2118 en Witch, src «neb»): se llega por su fila de MIRABILIA (la principal, objeto «main»: encuadra su CONTORNO de la lista, fvObjFinalList) y no por la
      // parada «nebula» de siempre, que llena la vista con la lamina entera (toda la foto: en Witch, un campo de estrellas con la nebulosa en una esquina). La principal de siempre (src «main»: Rosette, Soul...) sigue como hoy.
      else if (scene.hero.src === "neb" && scene.objects) { for (i = 0; i < scene.objects.length; ++i) if (scene.objects[i].main === true) { heroStop = { kind: "object", i: i, why: "hero" }; break; } }
      // (17-nov, F9; FV_F9.MAIN) la principal de siempre (src «main»: Rosette, Soul, IC 1396, Pleiades) con CONTORNO medido tampoco llega por la parada «nebula»: con el laboratorio esa distancia (la de la foto
      // ENTERA en 60°) no cuenta con el estiramiento lateral S y la pantalla ve un parche gris de la lamina (docs/encargos-17nov/F9.md): se llega por su fila de MIRABILIA y su contorno, como la promovida de Witch
      else if (!heroStop && scene.hero.src === "main" && scene.objects && typeof FV_F9 !== "undefined" && FV_F9.ON && FV_F9.MAIN) { for (i = 0; i < scene.objects.length; ++i) if (fvF9Main(scene, scene.objects[i])) { heroStop = { kind: "object", i: i, why: "hero" }; break; } }
      if (!heroStop && scene.hero.src !== "object" && scene.nebula) heroStop = { kind: "nebula", why: "nebula" };
   }
   var nStars = heroStop ? n - 1 : n;
   function add(i2, why) { if (i2 >= 0 && !used[i2] && out.length < nStars) { used[i2] = true; out.push({ kind: "star", i: i2, why: why }); } }
   if (exoHosts && exoHosts.length && !(dMaxBox > 0 && exoHosts[0] >= 0 && S.x[exoHosts[0]] * S.x[exoHosts[0]] + S.y[exoHosts[0]] * S.y[exoHosts[0]] + S.z[exoHosts[0]] * S.z[exoHosts[0]] > dMaxBox * dMaxBox)) add(exoHosts[0], "exoplanet");   // (14-nov, A) tampoco un anfitrion fuera de la caja
   add(c.bright, "brightest"); add(c.big, "largest"); add(c.hot, "hottest"); add(c.near, "nearest");
   if (heroStop) out.push(heroStop);
   else if (scene.nebula && out.length < n) out.push({ kind: "nebula", why: "nebula" });
   return out;
}
