// ============================================================================
// FieldVoyager/src/engine/fv_look.js — COMO SE VE UNA ESTRELLA desde la camara (pura) (3-nov-2026, F1)
// ----------------------------------------------------------------------------
// Magnitud aparente desde la camara: m' = G + 5·log10(d_camara / d_Tierra) (sin extincion nueva: el polvo de delante ya esta en G).
// Idea de Celestia (solo la idea): alfa ∝ (magLimite − m') y el radio SOLO crece al saturar (2^(0,3·(sat − m'))), con halo; y
// una magnitud limite que se ajusta al campo de vision para que no desaparezcan ni parpadeen (sin umbrales duros: hay un suelo).
// Niveles cuantizados (el pintor tiene un sprite por nivel y color):
//   0 … FV_LOOK.DIM−1           debiles: radio minimo (FWHM ≈ 1,8 px, nunca menos de 1,5 px), intensidad del suelo a 1
//   DIM … DIM+SAT−1            saturadas: intensidad 1,6 (nucleo quemado, blanco) y radio que crece en pasos de 2^0,4
// ES5. Sin PixInsight.
// ============================================================================

var FV_LOOK = { DIM: 8, SAT: 10, FLOOR: 0.22, SIGMA0: 0.75, SAT_STEP: 0.4,
                MAGLIM_HOME: 19.6, SATMAG_HOME: 10.5, FOV_SHIFT: 1.2,
                // (nP, I1, 5-nov; Nino: si) BRILLO AUTOMATICO SEGUN EL CAMPO, la idea de Celestia (solo la idea, sin su codigo GPL):
                // faintest = f45 · √fieldCorr con fieldCorr = 2·45° / (campo + 45°). Aqui el campo de referencia es el de CASA (la foto
                // llenando la vista) y la ley se aplica como DESPLAZAMIENTO en magnitudes: off = AUTO_K · (√(2h / (campo + h)) − 1).
                // Al cerrar el campo (zoom) off > 0: las debiles suben de nivel (la pantalla no se vacia; tope +0,41·K con campo → 0);
                // al abrirlo off < 0 (tope −K): las debiles se apagan con el fundido (no satura de polvo blanco). En casa off = 0.
                // AUTO_K 4: medido en tests/fv_nP_i12_node.js (Collinder 34). AUTO_ON false = la ley de antes (FOV_SHIFT · log10, solo
                // al abrir) = ROJO
                AUTO_ON: true, AUTO_K: 4, WIDE_DIST: true,
                // (nP, I2) FUNDIDO SUAVE: ninguna estrella aparece o desaparece de golpe. El alfa baja de 1 a 0 con smoothstep entre
                // magLim + FADE_AT − FADE_W/2 y + FADE_W/2 (centrado en el corte duro de antes, magLim + 0,5). Por debajo de A_MIN no se
                // pinta. El pintor de PixInsight lo cuantiza a A_Q pasos (un sprite por paso: 1/16 por fotograma como mucho).
                // FADE_ON false = el corte duro de antes (ROJO)
                FADE_ON: true, FADE_AT: 0.5, FADE_W: 1.0, A_MIN: 1 / 32, A_Q: 16 };

// magnitudes limite y de saturacion para un campo de vision (las de casa, desplazadas segun el campo: I1)
// -> { magLim, satMag, off, fadeLo, fadeW }
function fvLookLimits(fov, homeFov) {
   var shift;
   if (FV_LOOK.AUTO_ON && homeFov > 0 && fov > 0) {
      // (nP-2) al ABRIR el campo: como si la camara estuviera fov/home veces mas lejos (5·log10): cada estrella mas tenue y mas pequeña
      // que en casa (nunca mas gorda); el resto lo cierra el presupuesto de luz por area de foto (fvStarBudget). WIDE_DIST false = ROJO
      if (FV_LOOK.WIDE_DIST && fov > homeFov) shift = 5 * Math.log(fov / homeFov) / Math.LN10;
      else shift = -FV_LOOK.AUTO_K * (Math.sqrt(2 * homeFov / (fov + homeFov)) - 1);
   }
   else shift = FV_LOOK.FOV_SHIFT * Math.log(Math.max(1, fov / homeFov)) / Math.LN10;
   var ml = FV_LOOK.MAGLIM_HOME - shift;
   return { magLim: ml, satMag: FV_LOOK.SATMAG_HOME - shift, off: -shift, fadeLo: ml + FV_LOOK.FADE_AT - 0.5 * FV_LOOK.FADE_W, fadeW: FV_LOOK.FADE_W };
}
// (nP, I2) el alfa de fundido de una estrella de magnitud aparente m (ya con las reglas del cono): 1 … 0, continuo.
// Con FADE_ON false: el corte duro de antes (0 por encima de magLim + 0,5)
function fvLookAlpha(m, lim) {
   if (!FV_LOOK.FADE_ON) return (m > lim.magLim + 0.5) ? 0 : 1;
   var lo = (lim.fadeLo !== undefined) ? lim.fadeLo : lim.magLim + FV_LOOK.FADE_AT - 0.5 * FV_LOOK.FADE_W, t = (m - lo) / FV_LOOK.FADE_W;
   if (t <= 0) return 1;
   if (t >= 1) return 0;
   return 1 - t * t * (3 - 2 * t);
}
// el nivel (0 … DIM+SAT−1) de una estrella de magnitud aparente m
function fvLookLevel(m, lim) {
   if (m >= lim.satMag) {
      var fr = (lim.magLim - m) / (lim.magLim - lim.satMag);
      if (fr < 0) fr = 0;
      var I = FV_LOOK.FLOOR + (1 - FV_LOOK.FLOOR) * fr;
      var j = Math.floor((I - FV_LOOK.FLOOR) / (1 - FV_LOOK.FLOOR) * FV_LOOK.DIM);
      return j < 0 ? 0 : (j > FV_LOOK.DIM - 1 ? FV_LOOK.DIM - 1 : j);
   }
   var e = 0.3 * (lim.satMag - m), s = Math.floor(e / FV_LOOK.SAT_STEP);
   return FV_LOOK.DIM + (s > FV_LOOK.SAT - 1 ? FV_LOOK.SAT - 1 : s);
}
// los parametros del sprite de un nivel: { I (intensidad), sigma (px) }
function fvLookParams(lev) {
   if (lev < FV_LOOK.DIM) return { I: FV_LOOK.FLOOR + (1 - FV_LOOK.FLOOR) * (lev + 0.5) / FV_LOOK.DIM, sigma: FV_LOOK.SIGMA0 };
   var s = lev - FV_LOOK.DIM;
   return { I: 1.6, sigma: FV_LOOK.SIGMA0 * Math.pow(2, (s + 0.5) * FV_LOOK.SAT_STEP) };
}
// magnitud aparente
function fvApparentMag(g, dEarth, dCam) { return g + 5 * Math.log(Math.max(1e-6, dCam) / Math.max(1e-6, dEarth)) / Math.LN10; }
// color cuantizado (6 niveles por canal, relativo al canal mayor) -> clave 0 … 215
function fvColKey(rgb) {
   var r = (rgb >>> 16) & 255, g = (rgb >>> 8) & 255, b = rgb & 255, m = Math.max(r, g, b, 1);
   return Math.round(5 * r / m) * 36 + Math.round(5 * g / m) * 6 + Math.round(5 * b / m);
}
function fvColOfKey(k) { var r = Math.floor(k / 36), g = Math.floor(k / 6) % 6, b = k % 6; return [r * 51, g * 51, b * 51]; }
