// ============================================================================
// FieldVoyager/src/engine/fv_runaway.js — LA ESTRELLA FUGITIVA con criterio de la literatura (investigacion F-fugitivas, 20-nov-2026; ENCENDIDA en F2, 20-nov).
// PURO (PixInsight y navegador), ES5, sin DOM. ENCENDIDO (F2: «Quiero que aparezcan las fugitivas»): FV_RUNAWAY.ON = true y sustituye a la fugitiva de fv_time.js
// (FV_TRAILS.RUN_ON, criterio viejo de I3: apagado, solo lo usan sus pruebas). Lo usa: fv_time.js (estela dorada y modo GALAXIA), fv_aenigma.js («La fugitiva»),
// la ficha («¿por que?») y los dos pintores (src/ui/fv_trails.js y web/fw_time.js). FV_RUNAWAY.ON = false: la escena de antes (ni estela, ni ficha, ni AENIGMA).
// Las banderas de F2: FV_RUNAWAY.ON (todo), FV_TIME.GAL_ON (el interruptor SOL | GALAXIA del mando AETAS), FV_E1C.FAST_OLD (el misterio viejo de AENIGMATA).
//
// POR QUE OTRO CRITERIO. El de I3 (fv_time.js, «paralaje compatible con la del cumulo y la traza hacia atras pasa por el nucleo») no mide si la estrella
// ES rapida: mide si apunta al cumulo. Una estrella de campo cualquiera apunta a un cumulo del tamaño de la foto con probabilidad ~ 1 (10 casualidades por
// 1 candidata, I3.md §4.4b). El criterio de la literatura va al reves y en este orden:
//   1. VELOCIDAD PECULIAR: la velocidad de la estrella MENOS la de una orbita circular en SU sitio de la Galaxia (rotacion galactica) y el
//      movimiento del Sol (Blaauw 1961; Tetzlaff+ 2011; Carretero-Castrillo+ 2023). Umbral 30 km/s (Renzo+ 2019; Hoogerwerf+ 2001 usa lo mismo).
//   2. SIN VELOCIDAD RADIAL (la mayoria): solo las dos componentes tangenciales (V_TAN y W_RSR de Carretero-Castrillo+ 2023): es una COTA INFERIOR
//      de la velocidad peculiar 3D (lo que no se ve solo puede sumar), asi que no inventa fugitivas.
//   3. ERROR: Monte Carlo sobre paralaje (cero de Lindegren+ 2021 y error externo de Maiz Apellaniz 2022), movimiento propio, velocidad radial,
//      movimiento solar y curva de rotacion. Se pide que el PERCENTIL 5 de la velocidad supere el umbral (no el valor nominal).
//   4. POBLACION: solo estrellas calientes y luminosas (B tempranas y O: Teff ≥ 10 000 K, M_G ≤ 1). Entre las viejas del disco grueso y del halo
//      hay muchas >30 km/s que NO son fugitivas; las OB jovenes del disco tienen dispersion ~ 10 km/s, y ahi 30 km/s es de verdad un valor raro.
//   5. ORIGEN (opcional, solo de decoracion): traza hacia atras, en Monte Carlo, hasta los cumulos de la escena; se pide probabilidad, no un solo paso.
// PROCEDENCIA: formulas de movimiento propio -> UVW estandar (Johnson & Soderblom 1987, ESA 1997 vol. 1 §1.5.5 igual que fv_time.js); matriz ICRS ->
// galactica de Hipparcos (ESA 1997 vol. 1 §1.5.3). Las constantes tienen fuente en FV_RUNAWAY (abajo).
// ============================================================================

var FV_RUNAWAY = {
   ON: true,                           // F2: ENCENDIDO. false = la escena de antes (ni estela dorada, ni ficha, ni AENIGMA de la fugitiva)
   SKIP_CLUSTER: true,                 // una estrella de un cumulo confirmado de la escena (meta.cluster) no es candidata: se mueve con su cumulo (si el cumulo entero corre, no es una fugitiva suya)
   MAX_CAND: 3,                        // candidatas que se ensenan como mucho (las de mayor percentil 5)
   // --- el marco galactico ---
   R0_KPC: 8.15, THETA0: 236, DTHETA_DR: -0.4,         // Reid+ 2019, ApJ 885, 131 (arXiv:1910.03357): R0, Θ0 y dΘ/dR (ajuste A5) — los usa Carretero-Castrillo+ 2023
   SUN_UVW: [11.1, 12.24, 7.25],                       // Schönrich, Binney & Dehnen 2010, MNRAS 403, 1829 (arXiv:0912.3693): movimiento del Sol respecto al reposo local
   SUN_UVW_SD: [0.7, 0.47, 0.37], THETA0_SD: 7, R0_SD_KPC: 0.15,
   // --- Gaia DR3 ---
   PLX_ZP: -0.017,                     // mas: mediana de los cuasares de EDR3 (Lindegren+ 2021, A&A 649, A4, arXiv:2012.01742); el cero fino (G, color, latitud) pide columnas que la escena no guarda
   PLX_K: 1.3, PLX_SYS: 0.0103,        // error externo: sqrt((K sigma)^2 + SYS^2): Maiz Apellaniz 2022, A&A 657, A130 (arXiv:2110.01475); SYS = 10,3 μas (ahi) y K = 1,3 es una cota ALTA puesta aqui: NO VERIFICADO su valor por magnitud
   TIER_PLX_ERR: { gold: 0.13, silver: 0.86, bronze: 1.38 },     // mas: cota SUPERIOR del error de paralaje por tramo de la base local (copia de CabraShared CP_SF.PLX_ERR_MAX: sin red es lo unico que hay)
   TIER_PM_ERR: { gold: 0.14, silver: 0.97, bronze: 1.58 },      // mas/año: idem para el movimiento propio (CP_SF.PM_ERR_MAX; el tramo del pm es el de la paralaje: la escena no guarda el suyo)
   RV_SD_FLOOR: 2,                     // km/s: error supuesto de la velocidad radial de Gaia DR3 (la escena no guarda su error): NO VERIFICADO
   // --- el criterio ---
   KMS: 30,                            // umbral de «fugitiva» (Blaauw 1961; Renzo+ 2019, arXiv:1804.09164; Hoogerwerf+ 2001)
   CONF: 0.05,                         // percentil que debe superar el umbral (0,05 = 95 % de confianza unilateral)
   MAX_FRAC_ERR: 0.2, RUWE_MAX: 1.4,   // calidad: error de paralaje/paralaje ≤ 0,2 (Carretero-Castrillo+ 2023) y RUWE < 1,4
   TEFF_MIN: 10000, MG_MAX: 0.0,       // poblacion: B tempranas/medias y O (Teff ≥ 10 000 K, M_G ≤ 0: ≤ B8). Con M_G ≤ 1 entraban las BHB (M_G ≈ +0,5…+1, halo) y las A: se apreto tras ver 3 candidatas de Orion (F-fugitivas.md §5)
   Z_DISC_PC: 400,                     // |z| (altura sobre el plano) por encima de la cual la candidata se rotula «alta latitud: ¿halo o disco grueso?» (no es un filtro: una fugitiva de verdad llega lejos)
   N_MC: 300,                          // sorteos por estrella
   // --- origen ---
   BACK_MAX_YR: 1.5e7,                 // hasta donde se traza hacia atras (15 Ma)
   ORIGIN_MIN_YR: 2e5, ORIGIN_MIN_PC: 2   // no antes de 0,2 Ma (si no, «sigue dentro») y radio de nucleo de al menos 2 pc
};
var FV_RUNAWAY_BREAK = "";             // CONTROLES EN ROJO (pruebas): "nozp" sin cero de paralaje · "nopop" sin la puerta de poblacion · "noerr" sin errores (valor nominal)

// ICRS -> galactico (ESA 1997, vol. 1, ec. 1.5.11; filas = ejes X (centro), Y (rotacion), Z (polo))
var FV_RUN_AG = [[-0.0548755604162154, -0.8734370902348850, -0.4838350155487132],
                 [ 0.4941094278755837, -0.4448296299600112,  0.7469822444972189],
                 [-0.8676661490190047, -0.1980763734312015,  0.4559837761750669]];
var FV_RUN_K = 4.740470446;            // km/s por (mas/año · kpc)
function fvRunMul(M, v) { return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2], M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2], M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]]; }
// generador determinista (mulberry32) y normal (Box-Muller)
function fvRunRng(seed) {
   var s = seed >>> 0;
   function u() { s = (s + 0x6D2B79F5) >>> 0; var t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
   var spare = null;
   return { u: u, n: function() { if (spare !== null) { var r = spare; spare = null; return r; } var a = Math.max(1e-12, u()), b = u(), m = Math.sqrt(-2 * Math.log(a)); spare = m * Math.sin(2 * Math.PI * b); return m * Math.cos(2 * Math.PI * b); } };
}
// la base local del cielo en una direccion (ra, dec en grados) llevada a ejes GALACTICOS: r (radial), p (hacia el este), q (hacia el norte)
function fvRunBasis(ra, dec) {
   var D = Math.PI / 180, a = ra * D, d = dec * D, ca = Math.cos(a), sa = Math.sin(a), cd = Math.cos(d), sd = Math.sin(d), G = FV_RUN_AG;
   return { r: fvRunMul(G, [cd * ca, cd * sa, sd]), p: fvRunMul(G, [-sa, ca, 0]), q: fvRunMul(G, [-sd * ca, -sd * sa, cd]) };
}
// velocidad ESPERADA (km/s, en ejes galacticos, respecto al Sol) de una estrella con vector posicion helio-galactico X (kpc) si fuese en orbita circular:
//   v_circ(estrella) − v_Sol, con v_Sol = (U, Θ0 + V, W) y el Sol en (−R0, 0, 0)
function fvRunExpected(X, P) {
   var gx = X[0] - P.R0, gy = X[1], R = Math.sqrt(gx * gx + gy * gy), th = P.TH0 + P.DTH * (R - P.R0), c = R > 0 ? th / R : 0;
   return [c * gy - P.U, -c * gx - (P.TH0 + P.V), -P.W];
}
// UNA realizacion: devuelve la velocidad peculiar { vt (|tangencial|), pa (angulo N hacia E del movimiento peculiar en el cielo, grados), v3 (|3D| con v. r. o NaN), cmp [vp, vq] (km/s) }
//   s = { ra, dec, plx (corregida), pmRa, pmDec, rv (o null) } ; P = parametros del Sol y la rotacion de ESE sorteo
function fvRunPecOnce(s, B, P) {
   var d = 1 / s.plx;                                              // kpc
   var X = [d * B.r[0], d * B.r[1], d * B.r[2]], ex = fvRunExpected(X, P);
   var kd = FV_RUN_K * d, vp = kd * s.pmRa, vq = kd * s.pmDec;     // km/s: lo observado en el cielo (E, N)
   var ep = ex[0] * B.p[0] + ex[1] * B.p[1] + ex[2] * B.p[2], eq = ex[0] * B.q[0] + ex[1] * B.q[1] + ex[2] * B.q[2];
   var dp = vp - ep, dq = vq - eq, out = { vt: Math.sqrt(dp * dp + dq * dq), pa: (Math.atan2(dp, dq) * 180 / Math.PI + 360) % 360, v3: NaN, cmp: [dp, dq], dr: NaN };
   if (s.rv !== null && s.rv !== undefined && isFinite(s.rv)) { var er = ex[0] * B.r[0] + ex[1] * B.r[1] + ex[2] * B.r[2], dr = s.rv - er; out.dr = dr; out.v3 = Math.sqrt(dp * dp + dq * dq + dr * dr); }
   return out;
}
function fvRunParams(rng, sd) {                                    // los parametros del Sol y la rotacion, nominales o sorteados
   var F = FV_RUNAWAY, z = sd ? 1 : 0;
   return { U: F.SUN_UVW[0] + z * F.SUN_UVW_SD[0] * rng.n(), V: F.SUN_UVW[1] + z * F.SUN_UVW_SD[1] * rng.n(), W: F.SUN_UVW[2] + z * F.SUN_UVW_SD[2] * rng.n(),
            TH0: F.THETA0 + z * F.THETA0_SD * rng.n(), R0: F.R0_KPC + z * F.R0_SD_KPC * rng.n(), DTH: F.DTHETA_DR };
}
// el error externo de la paralaje (mas)
function fvRunPlxSigma(plxErr) { var F = FV_RUNAWAY; return Math.sqrt(F.PLX_K * F.PLX_K * plxErr * plxErr + F.PLX_SYS * F.PLX_SYS); }
// los errores de ESTA estrella: los de VizieR si el refinado los dio (plxErr, pmErr) y, si no, la COTA del tramo de la base local (tierStr/tier): mayor que el error
// verdadero, asi que solo puede quitar candidatas, nunca inventarlas -> { plxErr, pmErr, src: "vizier" | "tier-cap" | "" }
function fvRunErrors(m) {
   var F = FV_RUNAWAY;
   if (m.plxErr > 0 && m.pmErr > 0) return { plxErr: m.plxErr, pmErr: m.pmErr, src: "vizier" };
   var t = m.tierStr || ((typeof m.tier === "string") ? m.tier : "");
   if (t && F.TIER_PLX_ERR[t] > 0) return { plxErr: (m.plxErr > 0) ? m.plxErr : F.TIER_PLX_ERR[t], pmErr: (m.pmErr > 0) ? m.pmErr : F.TIER_PM_ERR[t], src: "tier-cap" };
   return { plxErr: (m.plxErr > 0) ? m.plxErr : 0, pmErr: (m.pmErr > 0) ? m.pmErr : 0, src: "" };
}
// ¿puede evaluarse esta estrella? -> "" si si; si no, el motivo (para las cuentas)
function fvRunWhyNot(m) {
   var F = FV_RUNAWAY;
   var er = fvRunErrors(m);
   if (!(m.plx > 0) || !(er.plxErr > 0)) return "plx";
   if (!isFinite(m.pmRa) || !isFinite(m.pmDec) || m.pmRa === null || m.pmDec === null || m.pmRa === undefined || m.pmDec === undefined) return "pm";
   if (!(er.pmErr > 0)) return "pmErr";
   if (!isFinite(m.ra) || !isFinite(m.dec) || m.ra === undefined || m.dec === undefined) return "pos";
   if (isFinite(m.ruwe) && m.ruwe !== null && m.ruwe !== undefined && m.ruwe >= F.RUWE_MAX) return "ruwe";
   var zp = (FV_RUNAWAY_BREAK === "nozp") ? 0 : F.PLX_ZP, p = m.plx - zp, sg = fvRunPlxSigma(er.plxErr);
   if (!(p > 0) || sg / p > F.MAX_FRAC_ERR) return "plxSnr";
   return "";
}
// M_G absoluta con el polvo de la escena (A_G, si lo hay) y la distancia de la paralaje corregida
function fvRunAbsG(g, plxCorr, ag) { return g - 5 * Math.log(1000 / plxCorr / 10) / Math.LN10 - (ag > 0 ? ag : 0); }
// ¿es una estrella joven, caliente y luminosa (OB)? -> { ok, teff, mg, why }
function fvRunPopulation(m, g, plxCorr) {
   var F = FV_RUNAWAY, teff = (m.teff > 0) ? m.teff : NaN, mg = fvRunAbsG(g, plxCorr, (m.dust && m.dust.ag > 0) ? m.dust.ag : 0);
   if (FV_RUNAWAY_BREAK === "nopop") return { ok: true, teff: teff, mg: mg, why: "" };
   if (!(teff >= F.TEFF_MIN)) return { ok: false, teff: teff, mg: mg, why: "teff" };
   if (!(mg <= F.MG_MAX)) return { ok: false, teff: teff, mg: mg, why: "mg" };
   return { ok: true, teff: teff, mg: mg, why: "" };
}
function fvRunQuantiles(a, qs) { var b = a.slice().sort(function(x, y) { return x - y; }), o = [], i; for (i = 0; i < qs.length; ++i) { var k = Math.min(b.length - 1, Math.max(0, Math.round(qs[i] * (b.length - 1)))); o.push(b[k]); } return o; }
// LA VELOCIDAD PECULIAR de una estrella con su error (Monte Carlo) -> { vt (nominal), q05, q50, q95, pa (nominal), v3 (nominal | NaN), v3q05, pAbove (fraccion de sorteos ≥ KMS en 2D), hasRv }
//   m = meta de la escena ({ ra, dec, plx, plxErr, pmRa, pmDec, pmErr, rv }), opts = { inflate (× los errores, control), seed, nMc, errScale }
function fvRunPeculiar(m, opts) {
   opts = opts || {};
   var F = FV_RUNAWAY, infl = opts.inflate || 1, N = opts.nMc || F.N_MC, rng = fvRunRng(opts.seed || 12345), zp = (FV_RUNAWAY_BREAK === "nozp") ? 0 : F.PLX_ZP;
   var B = fvRunBasis(m.ra, m.dec), hasRv = (m.rv !== null && m.rv !== undefined && isFinite(m.rv));
   var er = fvRunErrors(m), plx0 = m.plx - zp, sg = fvRunPlxSigma(er.plxErr) * infl, pe = er.pmErr * infl, re = F.RV_SD_FLOOR * infl;
   var nom = fvRunPecOnce({ ra: m.ra, dec: m.dec, plx: plx0, pmRa: m.pmRa, pmDec: m.pmDec, rv: hasRv ? m.rv : null }, B, fvRunParams(rng, false));
   var out = { vt: nom.vt, pa: nom.pa, v3: nom.v3, hasRv: hasRv, q05: nom.vt, q50: nom.vt, q95: nom.vt, v3q05: nom.v3, pAbove: nom.vt >= F.KMS ? 1 : 0, dpdq: nom.cmp };
   if (FV_RUNAWAY_BREAK === "noerr") return out;
   var vts = [], v3s = [], above = 0, i;
   for (i = 0; i < N; ++i) {
      var p = plx0 + sg * rng.n(); if (!(p > 0.02 * plx0)) { p = 0.02 * plx0; }                // paralaje sorteada (corta en 2 % para no dividir por ~0)
      var r = fvRunPecOnce({ ra: m.ra, dec: m.dec, plx: p, pmRa: m.pmRa + pe * rng.n(), pmDec: m.pmDec + pe * rng.n(), rv: hasRv ? m.rv + re * rng.n() : null }, B, fvRunParams(rng, true));
      vts.push(r.vt); if (hasRv) v3s.push(r.v3); if (r.vt >= F.KMS) ++above;
   }
   var q = fvRunQuantiles(vts, [F.CONF, 0.5, 1 - F.CONF]);
   out.q05 = q[0]; out.q50 = q[1]; out.q95 = q[2]; out.pAbove = above / N;
   if (hasRv) out.v3q05 = fvRunQuantiles(v3s, [F.CONF])[0];
   return out;
}
// ESCANEO de una escena -> { cand: [{ i, vt, q05, q50, q95, v3, v3q05, hasRv, pa, teff, mg, g, plx, plxErr, ... }], counts: {...} }
//   scene = { stars: { n, g, inFrame, meta } } (la de fv_scene.js o la volcada); opts = { inflate, seed, nMc, onlyFrame (true), metaOf (i -> meta; para los controles) }
function fvRunScan(scene, opts) {
   opts = opts || {};
   var F = FV_RUNAWAY, S = scene.stars, n = S.n, out = { cand: [], top: [], counts: { n: 0, inFrame: 0, withPm: 0, quality: 0, hot: 0, fast: 0, cand: 0, inCluster: 0, err: {}, why: {}, popWhy: {} } }, C = out.counts, i;
   for (i = 0; i < n; ++i) {
      if (opts.onlyFrame !== false && !S.inFrame[i]) continue;
      var m = opts.metaOf ? opts.metaOf(i) : S.meta[i]; if (!m) continue;
      ++C.inFrame;
      if (opts.skipCluster === true && m.cluster !== undefined && m.cluster !== null && m.cluster >= 0) { ++C.inCluster; continue; }          // F2: miembro de un cumulo confirmado de la escena: se mueve con el
      if (isFinite(m.pmRa) && m.pmRa !== null && m.pmRa !== undefined) ++C.withPm;
      var why = fvRunWhyNot(m); if (why) { C.why[why] = (C.why[why] || 0) + 1; continue; }
      ++C.quality;
      var zp = (FV_RUNAWAY_BREAK === "nozp") ? 0 : F.PLX_ZP, pop = fvRunPopulation(m, S.g[i], m.plx - zp);
      if (!pop.ok) { C.popWhy[pop.why] = (C.popWhy[pop.why] || 0) + 1; continue; }
      ++C.hot; var esrc = fvRunErrors(m).src; C.err[esrc] = (C.err[esrc] || 0) + 1;
      var pec = fvRunPeculiar(m, { inflate: opts.inflate, seed: (opts.seed || 1) * 100003 + i, nMc: opts.nMc });
      var Bq = fvRunBasis(m.ra, m.dec), dKpc = 1 / (m.plx - zp), zPc = 1000 * dKpc * Bq.r[2];                 // altura sobre el plano galactico (pc, con el Sol en z = 0)
      var rKpc = Math.sqrt(Math.pow(dKpc * Bq.r[0] - F.R0_KPC, 2) + Math.pow(dKpc * Bq.r[1], 2));       // distancia al centro de la Galaxia (kpc, plano)
      if (pec.vt >= F.KMS) ++C.fast;
      out.top.push({ i: i, zPc: zPc, vt: pec.vt, q05: pec.q05, q95: pec.q95, teff: pop.teff, mg: pop.mg, g: S.g[i], plx: m.plx, plxErr: fvRunErrors(m).plxErr, sourceId: m.sourceId || "", hasRv: pec.hasRv, v3: pec.v3 });
      if (pec.q05 >= F.KMS) { ++C.cand; out.cand.push({ i: i, zPc: zPc, rKpc: rKpc, highLat: Math.abs(zPc) > F.Z_DISC_PC, vt: pec.vt, q05: pec.q05, q50: pec.q50, q95: pec.q95, v3: pec.v3, v3q05: pec.v3q05, hasRv: pec.hasRv, pa: pec.pa, teff: pop.teff, mg: pop.mg, g: S.g[i], plx: m.plx, plxErr: fvRunErrors(m).plxErr, pmErr: fvRunErrors(m).pmErr, errSrc: fvRunErrors(m).src, ruwe: m.ruwe, pmRa: m.pmRa, pmDec: m.pmDec, rv: m.rv, sourceId: m.sourceId || "", cluster: m.cluster }); }
   }
   out.cand.sort(function(a, b) { return b.q05 - a.q05; });
   out.top.sort(function(a, b) { return b.vt - a.vt; }); out.top = out.top.slice(0, 5);          // las 5 OB que mas corren (candidatas o no)
   return out;
}

// EL ORIGEN (decoracion, solo si hay un cumulo en la escena): ¿pasaria esta estrella por el NUCLEO del cumulo G hace entre ORIGIN_MIN_YR y BACK_MAX_YR años?
// En Monte Carlo y con la distancia de la PARALAJE (cielo + profundidad), no solo en el cielo: la profundidad es lo que quita de en medio las casualidades de I3
// (a kiloparsecs la paralaje no resuelve el fondo y P sale ~0: no avala a nadie que no pueda avalar).
//   G = { ra, dec, pmRa, pmDec, plx, plxSd, r50as } -> { p, tMed (años atras, mediana de los sorteos que aciertan), bMedPc, relKms, dzPc, rPc }
//   opts.fut = true es el CONTROL: el mismo calculo hacia el FUTURO (por simetria, las casualidades son igual de probables que hacia atras)
function fvRunOrigin(m, G, opts) {
   opts = opts || {};
   var F = FV_RUNAWAY, er = fvRunErrors(m), N = opts.nMc || F.N_MC, rng = fvRunRng((opts.seed || 777) + 31), infl = opts.inflate || 1, zp = F.PLX_ZP, i, hit = 0, ts = [], bs = [];
   var cd = Math.cos(G.dec * Math.PI / 180), rx = ((m.ra - G.ra + 540) % 360 - 180) * cd * 3600, ry = (m.dec - G.dec) * 3600;       // arcsec, hoy
   var sg = fvRunPlxSigma(er.plxErr) * infl, plxG = G.plx - zp, sdG = isFinite(G.plxSd) ? G.plxSd : 0.03 * G.plx, sgG = Math.sqrt(sdG * sdG / Math.max(1, G.n || 1) + F.PLX_SYS * F.PLX_SYS),   // error del CENTRO del cumulo: dispersion de sus miembros / √n y el suelo sistematico (la extension del cumulo ya entra en rPc)
        rPc = Math.max(F.ORIGIN_MIN_PC, G.r50as / 206264.806 * 1000 / plxG);
   var dzNom = Math.abs(1000 / (m.plx - zp) - 1000 / plxG), relNom = FV_RUN_K * Math.sqrt(Math.pow(m.pmRa - G.pmRa, 2) + Math.pow(m.pmDec - G.pmDec, 2)) / plxG;
   for (i = 0; i < N; ++i) {
      var p = m.plx - zp + sg * rng.n(); if (!(p > 0.02 * m.plx)) p = 0.02 * m.plx;
      var pg = plxG + sgG * rng.n(); if (!(pg > 0)) continue;
      var dx = (m.pmRa + er.pmErr * infl * rng.n()) - G.pmRa, dy = (m.pmDec + er.pmErr * infl * rng.n()) - G.pmDec, dm2 = dx * dx + dy * dy; if (!(dm2 > 0)) continue;
      var tAny = -(rx * dx + ry * dy) / dm2 * 1000;                           // años hasta el acercamiento maximo (negativo = ya pasó): dm en mas/año, r en arcsec
      var age = opts.fut ? tAny : -tAny;                                      // hacia atras: la edad es −t ; control hacia el futuro: t
      if (!(age >= F.ORIGIN_MIN_YR && age <= F.BACK_MAX_YR)) continue;
      var bx = rx + dx / 1000 * tAny, by = ry + dy / 1000 * tAny, bPc = Math.sqrt(bx * bx + by * by) / 206264.806 * 1000 / pg, dz = Math.abs(1000 / p - 1000 / pg);
      var b3 = Math.sqrt(bPc * bPc + dz * dz);
      if (b3 <= rPc) { ++hit; ts.push(age); bs.push(b3); }
   }
   return { p: hit / N, tMed: ts.length ? fvRunQuantiles(ts, [0.5])[0] : NaN, bMedPc: bs.length ? fvRunQuantiles(bs, [0.5])[0] : NaN, relKms: relNom, dzPc: dzNom, rPc: rPc };
}

// ============================================================================
// F2 (20-nov-2026) — LAS CANDIDATAS DE LA ESCENA, SU VELOCIDAD PECULIAR POR ESTRELLA Y SUS TEXTOS (EN/ES)
// ----------------------------------------------------------------------------
// Nino: «Quiero que aparezcan las fugitivas». Se enciende el criterio honesto de arriba (0 falsas en el control: tests/_ffug), SIN relajarlo. Los errores son los
// que ya trae la escena (meta.plxErr y meta.pmErr: el refinado de VizieR que hace el script al construirla, https con plazos y espejos; src/build/fv_build.js,
// CabraShared cpStarfieldRefine) y, donde VizieR no contesto, la COTA del tramo de la base local (que solo puede quitar candidatas). No se pide NADA a la red aqui.
// ============================================================================
// las candidatas de la escena -> { src, key, pre, list: [cand…] (como mucho MAX_CAND, las de mayor percentil 5), counts, err: "vizier" | "tier-cap" | "none" }
//   "pre" = viene ya calculada en el paquete del visor web (scene.runaway de fvRunExport); el visor la lee y no la recalcula
function fvRunBuild(scene) {
   var S = scene && scene.stars; if (!S || !S.meta) return null;
   if (scene.runaway && scene.runaway.pre === true) return scene.runaway;
   var key = (FV_RUNAWAY.ON === true ? "on" : "off") + "|" + FV_RUNAWAY_BREAK;
   if (scene.runaway && scene.runaway.src === S && scene.runaway.key === key) return scene.runaway;
   var out = { src: S, key: key, pre: false, list: [], counts: null, err: "none" };
   if (FV_RUNAWAY.ON !== true) { scene.runaway = out; return out; }
   var sc = fvRunScan(scene, { seed: 1, skipCluster: FV_RUNAWAY.SKIP_CLUSTER === true });
   out.counts = sc.counts; out.list = sc.cand.slice(0, FV_RUNAWAY.MAX_CAND);
   out.err = (sc.counts.err.vizier > 0) ? "vizier" : ((sc.counts.err["tier-cap"] > 0) ? "tier-cap" : "none");
   scene.runaway = out;
   return out;
}
// la parte del resultado que viaja al paquete del navegador (sin la referencia a las estrellas)
function fvRunExport(scene) {
   var R = fvRunBuild(scene); if (!R) return null;
   return { pre: true, key: R.key, list: JSON.parse(JSON.stringify(R.list)), counts: JSON.parse(JSON.stringify(R.counts || {})), err: R.err };
}
function fvRunList(scene) { if (FV_RUNAWAY.ON !== true || !scene) return []; var R = fvRunBuild(scene); return R ? R.list : []; }
// la candidata que es la estrella i (indice de scene.stars) | null
function fvRunOf(scene, i) { var L = fvRunList(scene); for (var k = 0; k < L.length; ++k) if (L[k].i === i) return L[k]; return null; }

// ---- los textos ----
var FV_RUN_TX = {
   en: {
      "name": "The runaway", "nameHL": "The fast hot star",
      "label": "Runaway candidate · {v} km/s relative to the Galaxy", "labelHL": "Fast hot star · {v} km/s relative to the Galaxy · high latitude: halo?",
      "s": "a hot star at {v} km/s", "sHL": "hot, fast and far from the plane",
      "q": "One hot, young-looking star in this photo moves at about {v} km/s relative to its place in the Galaxy, far more than the stars around it. Which one?",
      "o": "{v} km/s",
      "p": "AENIGMA · the runaway: this hot star moves at {v} km/s relative to the Galaxy{atleast}.{hl1}",
      "p2": "The runaway: Gaia measures it moving at {v} km/s across the sky relative to the Galaxy (between {q05} and {q95} km/s; 19 times out of 20 at least {q05}). " +
            "Taken off what Gaia sees: the Sun's own motion and the rotation of the Galaxy at its place ({R} kpc from the centre). {rv}" +
            "It is hot and luminous (about {teff} K, absolute magnitude G {mg}): a young massive star is the kind that gets thrown out of the place where it was born " +
            "(a runaway is a massive young star moving at 30 km/s or more: Blaauw 1961). Parallax {plx} ± {e} mas ({src}), RUWE {ruwe}. {hl2}" +
            "It runs towards position angle {pa}° (north through east). Where it comes from is not said: Gaia only says that it does not travel with the rest.",
      "atleast": " (at least: Gaia has no radial velocity for it)",
      "hl1": " High latitude: runaway or halo star?",
      "hl2": "High latitude ({z} pc from the Galactic plane): either a runaway thrown out of the disc or a hot evolved star of the halo; one colour cannot tell them apart.",
      "rv0": "It has no radial velocity, so this is a minimum: the true speed can only be higher. ",
      "rv1": "Radial velocity {rv} km/s (shown, not used to decide: the radial velocities of hot stars are not reliable). ",
      "src.vizier": "real Gaia error, from VizieR", "src.cap": "upper bound of the local Gaia base: no network answered",
      "mode": "GALAXY", "modeTip": "stars moving relative to the Galaxy"
   },
   es: {
      "name": "La fugitiva", "nameHL": "La estrella caliente veloz",
      "label": "Candidata a fugitiva · {v} km/s respecto a la Galaxia", "labelHL": "Estrella caliente veloz · {v} km/s respecto a la Galaxia · alta latitud: ¿halo?",
      "s": "una estrella caliente a {v} km/s", "sHL": "caliente, veloz y lejos del plano",
      "q": "Una estrella caliente y de aspecto joven de esta foto se mueve a unos {v} km/s respecto a su sitio en la Galaxia, mucho más que las estrellas de su alrededor. ¿Cuál?",
      "o": "{v} km/s",
      "p": "AENIGMA · la fugitiva: esta estrella caliente se mueve a {v} km/s respecto a la Galaxia{atleast}.{hl1}",
      "p2": "La fugitiva: Gaia la mide moviéndose a {v} km/s por el cielo respecto a la Galaxia (entre {q05} y {q95} km/s; 19 veces de cada 20, al menos {q05}). " +
            "Descontado de lo que ve Gaia: el movimiento del propio Sol y la rotación de la Galaxia en su sitio (a {R} kpc del centro). {rv}" +
            "Es caliente y luminosa (unos {teff} K, magnitud absoluta G {mg}): una estrella joven y masiva es de las que salen despedidas del lugar donde nacieron " +
            "(una fugitiva es una estrella masiva y joven que va a 30 km/s o más: Blaauw 1961). Paralaje {plx} ± {e} mas ({src}), RUWE {ruwe}. {hl2}" +
            "Corre hacia el ángulo de posición {pa}° (norte hacia el este). De dónde viene no se dice: Gaia solo dice que no viaja con las demás.",
      "atleast": " (como mínimo: Gaia no tiene su velocidad radial)",
      "hl1": " Alta latitud: ¿fugitiva o estrella del halo?",
      "hl2": "Alta latitud (a {z} pc del plano de la Galaxia): o una fugitiva expulsada del disco o una estrella caliente evolucionada del halo; con un solo color no se distinguen.",
      "rv0": "No tiene velocidad radial, así que esto es un mínimo: la velocidad real solo puede ser mayor. ",
      "rv1": "Velocidad radial {rv} km/s (se muestra, no se usa para decidir: las velocidades radiales de las estrellas calientes no son fiables). ",
      "src.vizier": "error real de Gaia, de VizieR", "src.cap": "cota de la base local de Gaia: ninguna red contestó",
      "mode": "GALAXIA", "modeTip": "estrellas moviéndose respecto a la Galaxia"
   }
};
function fvRunFill(s, p) { if (p) for (var k in p) if (Object.prototype.hasOwnProperty.call(p, k)) s = s.split("{" + k + "}").join(String(p[k])); return s; }
function fvRunNum(x, dec, L) { var t = Number(x).toFixed(dec).replace("-", "−"); return L === "es" ? t.replace(".", ",") : t; }
function fvRunT(key, p, lang) { var L = (lang === "es") ? "es" : "en", s = FV_RUN_TX[L][key]; if (s === undefined) s = FV_RUN_TX.en[key]; return fvRunFill(s === undefined ? key : s, p); }
// el texto de una candidata. part = "name" | "label" | "s" | "q" | "o" | "p" | "p2"
function fvRunText(c, part, lang) {
   var L = (lang === "es") ? "es" : "en", hl = !!c.highLat, key = part, zTxt = String(Math.round(Math.abs(c.zPc)));
   if (hl && (part === "name" || part === "label" || part === "s")) key = part + "HL";
   var teff = (c.teff > 0) ? String(Math.round(c.teff / 10) * 10) : "?", rvTxt = c.hasRv ? fvRunT("rv1", { rv: fvRunNum(c.rv, 1, L) }, L) : fvRunT("rv0", null, L);
   var p = { v: String(Math.round(c.vt)), q05: String(Math.round(c.q05)), q95: String(Math.round(c.q95)), R: fvRunNum(c.rKpc, 1, L), rv: rvTxt, teff: teff, mg: fvRunNum(c.mg, 1, L),
             plx: fvRunNum(c.plx, 3, L), e: fvRunNum(c.plxErr, 3, L), src: fvRunT(c.errSrc === "vizier" ? "src.vizier" : "src.cap", null, L), ruwe: (c.ruwe > 0) ? fvRunNum(c.ruwe, 2, L) : "—",
             pa: String(Math.round(c.pa)), z: zTxt, atleast: c.hasRv ? "" : fvRunT("atleast", null, L), hl1: hl ? fvRunT("hl1", null, L) : "", hl2: hl ? (fvRunT("hl2", { z: zTxt }, L) + " ") : "" };
   return fvRunT(key, p, L);
}
