// ============================================================================
// FieldVoyager/src/engine/fv_flightlab.js — LABORATORIO DE VUELO (8-nov-2026)
// ----------------------------------------------------------------------------
// La navegacion nueva del diseño v2 (docs/navegacion/02-diseno.md §4–§9) para que Nino la PILOTE en PixInsight y decida mirando la
// dinamica (05-respuestas-nino.md: con imagenes fijas no puede juzgar giros, inercia ni encadenados). Interruptor FV_LAB.ON, APAGADO por
// defecto: apagado, ninguna funcion de aqui se llama y el motor es el de antes BIT A BIT (las ganchos de fv_pilot.js, fv_painter.js y
// fv_navmodes.js preguntan por FV_LAB / P.lab / cam.B, que solo existen con el laboratorio encendido).
//
// Encendido, UNA SOLA LEY para todo lo que mueve la camara (vuelo libre, cine, warp, casa, ruta, MIRABILIA): un integrador con subpasos
// fijos de 1/240 s (fvLabStep) que lleva la NAVE:
//   · posicion y velocidad en el espacio REAL (P.cam.pos real, como pide B1). DESVIO del §5.1, a proposito: S es lineal, asi que una recta,
//     una curva de Hermite o la superposicion de la frenada son las mismas en los dos espacios; todas las leyes de distancia ya van en real (B15)
//   · orientacion como BASE COMPLETA cam.B = { f, r, d } en el espacio de VUELO (lo que se ve), con velocidad angular P.lab.w. Sin fvBasis
//     al girar: no hay singularidad en el polo (K5). cam.look = B.f (vuelo) y cam.roll = 0 para los lectores antiguos.
//   · ningun corrector despues (KEEP_IN, fvNmStep, tTurnW): fvNmStep no se llama; navMode se asigna aqui solo como rotulo (D8).
// Los viajes automaticos (fvLabFly) dan OBJETIVOS: una trayectoria de posicion (camino alrededor del destino, §7.4.1, con avance por escala
// visible, §7.3) y una mirada objetivo por fase (§7.4.2); la orientacion la integra la nave con los topes del §5.3. Encadenar (§7.6) parte
// de la velocidad y la rotacion actuales: la velocidad que se lleva se frena SUPERPUESTA al viaje nuevo (sin salto de pose ni de velocidad).
//
// D1 · espacio de vuelo S: x, y × S; z igual. Tecla V: S = 1 · ~15° · ~40° de foto en casa. El brillo de las estrellas usa la distancia REAL.
// D2 · lente fija de LENS_DEG fuera de casa; TELESCOPIO (tecla O o el panel) para el aumento, hasta el limite de resolucion (§6.2).
// D3 · alabeo Q / Z; al soltar se endereza solo (~3 s). Guiñada y cabeceo con inercia.
// D4 · borde blando: frena en la banda, deja asomarse hasta OUT semianchuras y enseña la caja dorada (ancla).
// D5 · lo lateral es la ORBITA (boton izquierdo) alrededor del foco (regla del §6.3); sin foco, el boton izquierdo mira alrededor.
// D7 · llegada con la nebulosa detras del destino, en arco mirando al destino (sin volteo de espaldas). Se puede apagar en el panel.
// D10 · ancla (foto fantasma, piramide y marcadores) cuando no hay paisaje o fuera de la piramide.
// ES5. Sin PixInsight (lo usan el script y las pruebas de node). Sin #engine: se incluye.
// ============================================================================

var FV_LAB = {
   ON: false,                       // EL INTERRUPTOR (tecla L en el script). false = el motor de antes, bit a bit
   // (11-nov-2026, decision de Nino, NV-1) EL LABORATORIO ES LA NAVEGACION POR DEFECTO: al encender la nave el dialogo lo enciende (fv_dialog.js, tras
   // fvPilotNew); la tecla L vuelve al motor de antes. DEFAULT_ON false = como hasta el 10-nov (lo ponen las pruebas en tests/fv_test_lib.jsh: la
   // bateria de siempre mide el motor de antes; el laboratorio tiene las suyas en tests/_egm/lab y tests/_nav11)
   DEFAULT_ON: true,
   // (17-nov, P35) HUB_BRAKE: el cubo de la cruceta luce MIENTRAS la nave frena en la v5 (fvPilotGauges.brake = v / v al pulsar; la v5 frena con P.lab.brake y
   // no con P.brake, que valia siempre 0: solo hacia el destello de 350 ms). false = lo de antes. Gemelo de FW_LAB.HUB_BRAKE de la web (fw_viewer.js, mismo calculo)
   HUB_BRAKE: true,
   S_MODE: 2, S_DEG: [0, 15, 40], S_MAX: 60,       // D1: 0 = sin estirar; si no, campo de casa en grados (S = tan(deg/2) / tan(casa/2))
   LENS_DEG: 50, FOV_RATE: 0.5,     // D2: lente fija y ritmo maximo del campo (e/s)
   TELE: false, TELE_K: 8, TELE_MAX_K: 256, TELE_MAG: 3,    // telescopio: ×8 al encender; la rueda lo cambia; tope: 3 px por texel de capa
   ANCHOR: true, ANCHOR_STARS: 12, ANCHOR_COVER: 0.05, ANCHOR_FADE_S: 0.5,
   D7: true,
   SUB: 1 / 240,                    // subpaso fijo del integrador (s)
   TURN: { free: [30, 60], cine: [28, 55], warp: [56, 110], home: [28, 55], path: [28, 55] },   // °/s y °/s² (§5.3; un poco por debajo del tope K4)
   LIN_K: 3.0,                      // zona lineal del muelle de giro (1/s): sin vaiven en errores pequeños
   ROLL: { W: 45, A: 90, LEVEL_DPS: 50, LEVEL_K: 3.0, POLE_DEG: 80, AUTO_DPS: 2, AUTO_MAX_DPS: 6, AUTO_K: 1.0, FLAT: true, FLAT_LO: 12, FLAT_HI: 30 },   // AUTO_*: sin Q/Z el horizonte se endereza a <= 2 °/s (v2, K5: el apuntado no lleva giro de pantalla)   // alabeo Q/Z; enderezado ~3 s desde 90° (lab_kmisc K12: 35/2 daba 5,1 s desde 124°); se anula a > 80° del plano (polo)
   TURN_DECAY_S: 0.6,               // guiñada y cabeceo: al soltar la tecla, la velocidad de giro se apaga con esta constante (inercia)
   MOUSE_GLIDE_S: 1.0,              // al soltar el arrastre (mirar u orbitar), sigue girando y se apaga
   EDGE: { BAND: 0.10, OUT: 1.5, MIN_D: 0.005, LOOK_DPS: 5, LOOK_ON: true, FLOOR_D: 0.02 },
   ORBIT: { DRAG_K: Math.PI, SEL_K: 20, CONE_DEG: 10, NEAR_D: 0.2 },
   ARC: { R_FAR: 10, R_NEAR: 3, CHECK_N: 32, TANG_K: 0.35, RATE_FRAC: 0.5, PROFILE_K: 1.5, DUR_MAX_K: 1.15 },   // DUR_MAX_K (v2): el arco alarga el viaje como mucho un 15 %   // TANG_K: el barrido alrededor del destino cuenta 1/0,35 en el avance; RATE_FRAC: la direccion al destino gira a <= 0,5 del tope de giro (K8: en c5 HB el destino salia de cuadro en el arco)
   LOOK: { K_IN: 75, K_OUT: 60, BLEND_S: 2, DOLLY: true, DOLLY_IN: 100, DOLLY_OUT: 60, BIAS_K: 0.75, K_IN_BLACK: 40, K_OUT_BLACK: 30, K_VF_BLACK: 88, ZONE_BLACK_K: 0.4 },   // BIAS_K (v2, K1): mirando al destino, la mirada se inclina hacia la nebulosa hasta 0,6 x medio campo (el destino sigue en cuadro)   // DOLLY (v2, K1): si el destino queda hacia la Tierra (> 100° de la nebulosa) se mira a la nebulosa aunque quede detras del movimiento (travelling hacia atras)
   // (v3, propuesta de Nino 8-nov) MIRADA AL CONTENIDO: en los viajes el morro apunta al centro de lo VISIBLE (estrellas que se pintarian y la
   // nebulosa pesada por su luz real y su angulo solido en vuelo), aunque se viaje de espaldas. Dentro de la losa y en la llegada, al destino.
   // Tecla K (de «K», el punto de contenido del diseño) y fila del panel. ON = encendido por defecto con el laboratorio.
   CONTENT: { ON: true, MAG_LIM: 9, STAR_K: 1, NEB_K: 60, OM_CELL: 0.05, MIN_R: 0.15, MIN_STARS: 18, MIN_NEB: 0.05, LUM_SEEN: 0.12, BEHIND_K: 0.6, FWD: 0.35, SLAB_K: 2.0, GRID_X: 16, GRID_Y: 12 },
   DUR_CAP_K: 1.15,                 // (v3, 6) el viaje entero (giro previo incluido) dura como mucho 1,15 x la duracion base (la de hoy)
   SPEED_SHOW_S: 0.3,               // (v3, 8) VELOCITAS muestra la velocidad VISTA (en el espacio de vuelo), suavizada 0,3 s
   PERF_LAYERS_MS: 7,              // (v2, p95) si las capas pasan de 12 ms en un fotograma, las siguientes van sin suavizado hasta bajar de 6
   SLAB_VIS_K: 1.0, BRAKE_S: 1.2, BRAKE_MAX_FRAC: 0.2,
   WARP: { PREP: 0.18, DUR0: 3.0, DUR_DEC: 0.8, DUR_MIN: 3.5, DUR_MAX: 7.5, TRAIL: 0.55, WARP: 0.25, FLASH_S: 0.15 },
   PAN_K: 1.0, WHEEL_FRAC: 0.06, NPATH: 200,
   // (R1 y R2, 11-nov-2026, Nino: «que la aceleracion sea menos reactiva a la rueda y que cueste mas coger velocidad; si cojo velocidad y despues la
   // bajo, ayuda a estabilizar la nave y reducir la velocidad porque seguramente quiero parar») LA RUEDA ES UN ACELERADOR CON CONSIGNA, como en los
   // programas a los que la gente esta acostumbrada (docs/navegacion/07-estudio-control-de-nave-en-juegos.md: la rueda fija una velocidad objetivo que
   // la nave alcanza sola; bajarla frena de verdad; hay parada; la velocidad depende de la distancia a lo que hay delante). ON false = el impulso por
   // muesca de antes (el ROJO de tests/_nav11/nav_wheel_probe.js; medido: 20 muescas rapidas = 30 %/s y la nave se pasaba de largo, 112 %).
   //   consigna L.thr en muescas (con signo). Velocidad objetivo = SMAX·(1 − e^(−|thr|/N0)) × lo que hay delante, por segundo: 1 muesca 1,1 %/s,
   //     5 muescas 4,7 %/s, 20 muescas 10,4 %/s (nunca mas de SMAX: cruzar lo que hay delante cuesta ≥ 8 s, y al acercarse baja sola)
   //   RATE / BURST  la rueda rapida cuenta menos: como mucho RATE muescas por segundo (deposito de BURST)
   //   TAU_UP        cuesta coger velocidad: la nave persigue la consigna con este tiempo al acelerar · TAU_DOWN al bajar
   //   HOLD_S, DECAY_S  sin tocar la rueda la consigna se mantiene HOLD_S y luego se apaga sola con DECAY_S (un visor, no un simulador: la nave no
   //     se va sola al borde; HOLD_S = 1e9 seria un acelerador puro)
   //   R2 · una muesca EN CONTRA de la marcha = «quiero parar»: quita max(1, BRAKE_FRAC·|consigna|) y enciende el frenado asistido (TAU_BRAKE para
   //     la velocidad, TAU_SPIN para el giro residual y la inercia del raton); la segunda en contra en menos de STOP_S = parada total. Al llegar a
   //     cero hay un TOPE: durante DETENT_S las muescas en contra no cuentan (frenar no acaba en marcha atras sin querer)
   THROTTLE: { ON: true, SMAX: 0.12, N0: 10, NMAX: 30, RATE: 6, BURST: 3, TAU_UP: 2.0, TAU_DOWN: 0.8, HOLD_S: 2.5, DECAY_S: 3.0,
               BRAKE_FRAC: 0.5, STOP_S: 0.6, TAU_BRAKE: 0.45, TAU_SPIN: 0.35, DETENT_S: 0.45 },
   // (R6, 12-nov-2026, Nino tras probarlo con su raton: «si hace giros demasiado bruscos [...] a velocidad alta o baja, la vista se desmadra y pierde la
   // orientacion; quiero que los giros sean SIEMPRE muy graduales, independientemente de la velocidad») GIROS GRADUALES. Valen para TODO giro que
   // manda la persona (arrastre del raton al mirar y al orbitar, teclas A/D y cruceta, alabeo Q/Z, inercia al soltar, mirada que sigue al destino
   // tras llegar) y NO dependen de la velocidad de vuelo: son grados, no distancias. ON false = lo de antes (el ROJO de tests/_nav11/nav_giro_probe.js:
   // el raton giraba la camara tantos grados como pixeles, de golpe; las teclas llegaban a 30 °/s en 0,5 s y a 48 con impulso).
   //   W_MAX, A_MAX   topes DUROS de la velocidad (°/s) y la aceleracion (°/s²) angulares de la mirada; acelerar y frenar. 36 °/s = 90° en 2,5 s;
   //                  45 °/s² = 0,8 s para llegar al tope
   //   MOUSE_TAU      el arrastre ya no gira la camara: suma un angulo PENDIENTE (L.glide.pend) y la camara lo recorre con esta constante de tiempo
   //                  (velocidad objetivo = pendiente / MOUSE_TAU, con tope W_MAX y con perfil de frenada sqrt(2·BRAKE_K·A_MAX·pendiente) para
   //                  parar sin pasarse). Un tiron grande es un giro largo y suave, y al soltar termina de recorrer lo pendiente (sin oscilar)
   //   PEND_MAX       tope del angulo pendiente (°): un tiron enorme no se acumula (al soltar, no sigue girando varios segundos)
   //   KEY_DPS        velocidad objetivo de las teclas (°/s; con impulso x1,6 y tope W_MAX) · TAU_UP / TAU_DOWN: la velocidad angular persigue
   //                  la objetivo con esta constante al acelerar / al soltar (ademas del tope A_MAX)
   //   ROLL_W         tope del alabeo Q/Z y de su enderezado (°/s); la aceleracion del alabeo, A_MAX
   //   ENDP_DEG       por debajo de este angulo pendiente (y casi sin velocidad) el arrastre acaba y se aplica lo que quedaba
   //   RC_DPS, RC_A, RC_TAU   al ORBITAR, la mirada se endereza hacia el foco (antes saltaba a mirarlo en el primer fotograma: un foco a 90° eran 90° de
   //                  golpe): tope de velocidad (°/s) y de aceleracion (°/s²) de ese enderezado y su constante de tiempo (s). Se SUMA al giro del arrastre: al orbitar
   //                  el giro de la mirada es <= W_MAX + RC_DPS y la aceleracion <= A_MAX + RC_A (con el foco centrado y la nave quieta, el enderezado es 0 y
   //                  valen W_MAX y A_MAX; la nave en marcha descentra el foco y el enderezado trabaja)
   // NO tocados: los viajes automaticos (cine/warp/home, FV_LAB.TURN) llevan sus propios topes de estilo (28–56 °/s); ver el informe R6
   GIRO: { ON: true, W_MAX: 36, A_MAX: 45, MOUSE_TAU: 0.35, BRAKE_K: 0.8, PEND_MAX: 120, ENDP_DEG: 0.003, KEY_DPS: 24, TAU_UP: 0.30, TAU_DOWN: 0.60, ROLL_W: 24,
          RC_DPS: 12, RC_A: 20, RC_TAU: 0.35 },
   // (v4, 9-nov-2026, lo que dijo Nino pilotando la v3) VUELO v4. ON = false: la v3 tal cual (control). Con ON:
   //  · viaje casi RECTO con una comba suave (BOW_K x la longitud vista, perfil 16 s²(1-s)², sin cambiar de lado), llegada del lado por donde se
   //    viene: la distancia al destino solo baja (R2; fuera el arco D7 que rodeaba la estrella y se pasaba ~1 100 a.l.: N12/N5)
   //  · el destino SIEMPRE en el recuadro central (MARGIN de la pantalla): giro previo sin avanzar hasta tenerlo dentro (el reloj espera) y
   //    correa (LEASH) que no lo deja salir; la mirada al contenido (K) solo inclina el encuadre hasta KEEP x el margen, y se apaga en BIAS_END
   //  · apuntar nivelado: giro por el circulo maximo + enderezado del horizonte a <= ROLL_DPS; llegada parada y derecha (SETTLE: el viaje
   //    acaba cuando la mirada, el alabeo y el giro estan a cero; tope SETTLE_MAX_S y ajuste final invisible)
   //  · salida sin «congelarse» (N7): el avance no frena por la estrella que se deja detras (VIS0_K x la longitud de suelo de la escala)
   //  · duracion: la de hoy; giro previo + camino <= DUR_CAP_K x la de hoy, quitando del camino (suelo MOVE_MIN_K x la de hoy)
   V4: { ON: true, MARGIN: 0.8, MARGIN_IN: 0.7, KEEP: 0.6, BIAS_S: 1.0, BIAS_END: [0.65, 0.85], BOW_K: 0.06, VIS0_K: 0.25,
         ROLL_DPS: 10, ROLL_K: 1.5, SETTLE_MAX_S: 2.5, SETTLE_DEG: 0.05, SETTLE_W_DPS: 0.1, SETTLE_ROLL_DEG: 0.2, PRE_MAX_S: 8, LEASH: true, MOVE_MIN_K: 0.7 },
   // (v5, 9-nov-2026 ronda 2; Nino eligio «C + D» para el negro de la v4) Encima de la v4; ON = false: la v4 tal cual. Con ON:
   //  · ORBIT (C): al final del camino, si detras de la estrella no hay foto con luz (rejilla de luz >= LUM_MIN), media vuelta a DISTANCIA
   //    CONSTANTE o bajando (la del camino, sin rebote) hasta dejarla delante de la foto: la celda con luz que pide menos giro (LUM_W rad de giro valen
   //    una celda entera de luz; la foto se tiene que ver de frente: |z| de la mirada >= FACE_MIN, y FACE_W rad de premio por verla de cara).
   //    No hay vuelta si el pintor ya ve foto (>= ANCHOR_COVER). Giro <= ORBIT_W_K x el tope del estilo, aceleracion la del estilo, duracion
   //    <= ORBIT_MAX_S [cine, warp] (v5b, 9-nov, V1: en warp 3,5 s, antes 4; el tope de tiempo a la MISMA velocidad de giro es un tope del angulo, W (t - W/A) = 153° a 50 °/s:
   //    sin media vuelta las de mas de 153° (las de detras de la foto piden 170-180°), el giro de pantalla no sube y el warp pasa de 144,8 a 127,3 % de HOY.
   //    Barrido en el informe). En cine empieza OVL_S antes de acabar el camino (la nave entra girando y la distancia sigue bajando): lo
   //    que se espera YA LLEGADO es <= ORBIT_MAX_S - OVL_S (6 s); asi caben las de detras de la foto, que piden 150-180° (medido el 9-nov).
   //    La vuelta va en RUMBO y ELEVACION (alrededor de la vertical, N3; no por encima) y acaba a <= EL_MAX grados de elevacion (una vuelta por
   //    encima dejaba la mirada a 50-60° y el horizonte torcido 41° que la llegada enderezaba de golpe, medido el 9-nov)
   //  · FAST (D, solo cine): cuando el pintor dice que no hay paisaje (P.lab.land false: < 12 estrellas y < 5 % de foto), el reloj del camino
   //    corre hasta FAST_K veces; la marcha se suaviza (BLK_S el aviso, RATE_S el reloj) y se apaga al final (FAST_END del camino)
   //  · CREEP (solo cine): durante el giro previo el camino avanza a CREEP_K (sin la imagen congelada de N7)
   V5: { ON: true, ORBIT: true, ORBIT_W_K: 0.9, ORBIT_MAX_S: [8, 3.5], OVL_S: 2, EL_MAX: 35, LUM_MIN: 0.25, LUM_W: 0.5, FACE_MIN: 0.5, FACE_W: 0.5,
         FAST: true, FAST_K: 2.5, BLK_S: 0.6, RATE_S: 0.8, FAST_END: [0.85, 0.97], CREEP: true, CREEP_K: 0.4,
         // (v5b, V2 del informe, solo cine) ORBIT_FAST: sin paisaje la media vuelta corre ORBIT_FAST_K veces y el tope de giro sube igual (nada que se vea girar). Apagado: ver informe
         ORBIT_FAST: false, ORBIT_FAST_K: 2,
         // (v5c, 9-nov, V1b) vuelta PARCIAL [cine, warp]: si lo que piden las celdas con luz pasa del tope de tiempo, se gira hasta el tope (no se salta). [false, false] = v5b (d421a81)
         ORBIT_PARTIAL: [false, true],
         // (v5d, 9-nov, V1c) rescate de las llegadas SIN celda elegible (18 %, todas a negro y a negro tambien en HOY): vuelta de cara a la foto por la perpendicular de la estrella. [false, false] = f34f3bd
         ORBIT_RESCUE: [false, false],
         // (v5d) BEHIND_STRICT: la foto «detras de la estrella» exige que la placa quede mas alla de la estrella (t > 1). false = f34f3bd
         BEHIND_STRICT: false },
   // (v4, R1) MIRAR 360°: la cruceta y las flechas del teclado giran la mirada sin avanzar (W/S empujan); la guiñada da la vuelta entera (alrededor
   // de la vertical: el horizonte no se tuerce) y el cabeceo llega a PITCH_MAX. WIDE: el espacio estirado S se relaja con el angulo de la mirada
   // al eje de la foto (A0 -> A1 grados): mirando a la foto, S entero (lo de la v3); de lado, el espacio real (S = 1). Con S fijo, de lado la
   // profundidad se veia S veces comprimida (las estrellas apretadas en una franja: compresion = cos del angulo al eje, 1/S a 90°)
   // (9-nov, medido con lab_look360.js) APAGADO: quita la compresion pero las estrellas «nadan» al girar (29 °/s a 45° y 97 °/s a 60° de mas,
   // con la cruceta a 30 °/s) y de lado, con S = 1, no queda ninguna estrella pintada en IC 1848. Queda como opcion
   WIDE: { ON: false, A0: 35, A1: 75 },
   LOOK360: { ARROWS: true, FLAT_YAW: true, PITCH_MAX: 85, PITCH_SOFT: 10, EDGE_LOOK: false },
   // (v4, R1) EL CIELO DE FONDO (Via Lactea simulada: brillo y grano) en direcciones REALES: S estira el volumen de tu foto, no la boveda. Con S
   // la Via Lactea entera se apretaba en una franja estrecha al mirar de lado (5 000 granos de estrella comprimidos). Solo cambia el proyector
   // que recibe paintMilkyWay (fv_painter.js render); su codigo no se toca
   SKY: { REAL: true },
   // (v4, R1) las estrellas de la foto que se verian aplastadas (compresion A = |v real| / |v vuelo| < HI) se apagan hasta LO: de lado no queda
   // la franja apretada (a 90° de la foto A = 1/S = 0,02: una raya vertical). ON = false: se pintan aplastadas (lo de la v3)
   SIDE_FADE: { ON: true, LO: 0.12, HI: 0.3 }   // (9-nov) solo las muy aplastadas (A < 0,3: mas de ~72° del eje); a 45–60° (A 0,45–0,7) se quedan
};

function fvLabOn(P) { return typeof FV_LAB !== "undefined" && FV_LAB.ON === true && !!P && !!P.cam && !!P.scene; }
function fvLab4On() { return !!(FV_LAB.V4 && FV_LAB.V4.ON); }
function fvLab5On() { return fvLab4On() && !!(FV_LAB.V5 && FV_LAB.V5.ON); }
// (v4, R1) el S que se ve con la mirada f (vuelo): entero hasta A0 grados del eje de la foto (±z), real (1) desde A1; L.S0 = el de la tecla V
function fvLabSEff(L, f) {
   var S0 = (L && L.S0 > 0) ? L.S0 : (L ? L.S : 1), Wd = FV_LAB.WIDE;
   if (!fvLab4On() || !Wd || !Wd.ON || !(S0 > 1) || !f) return S0;
   var a = Math.acos(Math.min(1, Math.abs(f[2]) / Math.max(1e-12, fvLen(f)))) / FV_DEG;
   return 1 + (S0 - 1) * (1 - fvSmooth((a - Wd.A0) / Math.max(1e-6, Wd.A1 - Wd.A0)));
}
// (v4, R1) el proyector del cielo de fondo: el mismo con S = 1 (direcciones reales = direcciones de pantalla). Sin v4 o sin SKY.REAL, el de siempre
function fvLabSkyPr(pr) {
   if (!fvLab4On() || !FV_LAB.SKY || !FV_LAB.SKY.REAL || !pr || !(pr.S > 1)) return pr;
   var o = {}; for (var k in pr) if (Object.prototype.hasOwnProperty.call(pr, k)) o[k] = pr[k];
   var px = pr.pos, f = pr.f, cx = pr.cx, cy = pr.cy, r = pr.r, d = pr.d, fw = pr.fw;
   o.S = 1;
   o.project = function(p, near) {
      var vx = p[0] - px[0], vy = p[1] - px[1], vz = p[2] - px[2], zc = vx * fw[0] + vy * fw[1] + vz * fw[2];
      if (!(zc > (near || 1e-9))) return null;
      return [cx + f * (vx * r[0] + vy * r[1] + vz * r[2]) / zc, cy + f * (vx * d[0] + vy * d[1] + vz * d[2]) / zc, zc];
   };
   return o;
}
// (v4, R1) el peso de una estrella de la foto segun lo aplastada que se veria (A = distancia real / distancia de vuelo): 1 sin apagar
function fvLabSideFadeK(dReal, dFly) {
   var SF = FV_LAB.SIDE_FADE; if (!fvLab4On() || !SF || !SF.ON || !(dFly > 0)) return 1;
   return fvSmooth((dReal / dFly - SF.LO) / Math.max(1e-6, SF.HI - SF.LO));
}
// la mirada de vuelo que corresponde a la direccion REAL fr con el S que esa misma mirada pide (punto fijo; 6 pasadas sobran)
function fvLabFlyOfReal(L, fr) {
   var s = (L.S0 > 0) ? L.S0 : L.S, f = fvNorm(fvLabRelFly(fr, s));
   for (var k = 0; k < 6; ++k) { var s1 = fvLabSEff(L, f); if (Math.abs(s1 - s) < 1e-9 * s) break; s = s1; f = fvNorm(fvLabRelFly(fr, s)); }
   return { f: f, S: fvLabSEff(L, f) };
}

// ---------------------------------------------------------------------------
// D1 · S y los dos espacios
// ---------------------------------------------------------------------------
function fvLabSFor(P, mode) {
   var deg = FV_LAB.S_DEG[mode | 0] || 0;
   if (!(deg > 0)) return 1;
   var hf = fvHomeFov(P.scene, P.VW, P.VH);
   return fvClamp(Math.tan(deg * FV_DEG / 2) / Math.tan(hf / 2), 1, FV_LAB.S_MAX);
}
function fvLabRelFly(v, S) { return [S * v[0], S * v[1], v[2]]; }
function fvLabRelReal(v, S) { return [v[0] / S, v[1] / S, v[2]]; }
function fvLabDirFly(P, p) { return fvNorm(fvLabRelFly(fvSub(p, P.cam.pos), P.lab.S)); }     // direccion (vuelo) de la nave a un punto real
function fvLabFwdReal(P) { return fvNorm(fvLabRelReal(P.cam.B.f, P.lab.S)); }               // hacia donde se avanza, en real
function fvLabHomeFovS(P, S) { return 2 * Math.atan(S * Math.tan(fvHomeFov(P.scene, P.VW, P.VH) / 2)); }

// la base nivelada (abajo de la foto = +Y) de una mirada; junto al polo, la de giro minimo desde ref (sin salto)
function fvLabLevel(f, ref) {
   f = fvNorm(f);
   if (Math.abs(f[1]) < 0.995 || !ref) return fvBasis(f, [0, 1, 0]);
   var r = fvSub(ref.r, fvMul(f, fvDot(ref.r, f))); if (fvLen(r) < 1e-9) return fvBasis(f, [0, 1, 0]);
   r = fvNorm(r); return { f: f, r: r, d: fvNorm(fvCross(f, r)) };
}
function fvLabOrtho(B) { var f = fvNorm(B.f), r = fvSub(B.r, fvMul(f, fvDot(B.r, f))); r = fvNorm(r); return { f: f, r: r, d: fvNorm(fvCross(f, r)) }; }
function fvLabRotB(B, axis, ang) { if (!(Math.abs(ang) > 0)) return B; return { f: fvRotate(B.f, axis, ang), r: fvRotate(B.r, axis, ang), d: fvRotate(B.d, axis, ang) }; }
// rotacion (eje · angulo, vector) que lleva la base A a la base B
function fvLabRotErr(A, B) {
   var M = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], Ls = [[B.f, A.f], [B.r, A.r], [B.d, A.d]];
   for (var k = 0; k < 3; ++k) for (var i = 0; i < 3; ++i) for (var j = 0; j < 3; ++j) M[i][j] += Ls[k][0][i] * Ls[k][1][j];
   var tr = M[0][0] + M[1][1] + M[2][2], c = fvClamp((tr - 1) / 2, -1, 1), ang = Math.acos(c);
   if (ang < 1e-9) return [0, 0, 0];
   var ax = [M[2][1] - M[1][2], M[0][2] - M[2][0], M[1][0] - M[0][1]], s = fvLen(ax);
   if (s < 1e-9) {          // ~180°: el eje es la columna de mayor diagonal de (M + I)/2
      var bi = 0; for (var q = 1; q < 3; ++q) if (M[q][q] > M[bi][bi]) bi = q;
      ax = [(M[0][bi] + (bi === 0 ? 1 : 0)), (M[1][bi] + (bi === 1 ? 1 : 0)), (M[2][bi] + (bi === 2 ? 1 : 0))]; s = fvLen(ax);
      if (s < 1e-9) ax = A.d.slice(), s = 1;
   }
   return fvMul(ax, ang / s);
}
// el angulo de alabeo (con signo) de la base respecto a la nivelada, y si tiene sentido (lejos del polo)
function fvLabRollOf(B) {
   var lv = fvBasis(B.f, [0, 1, 0]), s = fvDot(fvCross(lv.r, B.r), B.f), c = fvDot(lv.r, B.r);
   return { a: Math.atan2(s, c), ok: Math.abs(B.f[1]) < Math.sin(FV_LAB.ROLL.POLE_DEG * FV_DEG) };
}

// ---------------------------------------------------------------------------
// ESTADO
// ---------------------------------------------------------------------------
function fvLabState(P) {
   var L = P.lab;
   if (L) return L;
   L = P.lab = { S: 1, sMode: -1, w: [0, 0, 0], v: [0, 0, 0], keys: {}, keyT: {}, fovT: null, tele: FV_LAB.TELE_K, teleOn: !!FV_LAB.TELE,
                 hold: null, wr: null, anchor: 0, anchorOn: false, drag: null, glide: null, panV: [0, 0, 0], look: null, homeSettle: false, lastIn: null };
   var cam = P.cam, hf0 = fvHomeFov(P.scene, P.VW, P.VH), atHome = fvLen(cam.pos) < 1e-9;
   var S = fvLabSFor(P, FV_LAB.S_MODE); L.S = S; L.S0 = S; L.sMode = FV_LAB.S_MODE;
   var f = fvNorm(fvLabRelFly(fvNorm(cam.look || [0, 0, 1]), S));
   if (fvLab4On()) { var fq = fvLabFlyOfReal(L, fvNorm(cam.look || [0, 0, 1])); f = fq.f; L.S = fq.S; }   // (v4, R1) S de la mirada
   cam.B = fvLabLevel(f, null);
   if (cam.roll) cam.B = fvLabRotB(cam.B, cam.B.f, -cam.roll);
   cam.S = L.S; cam.roll = 0; cam.look = cam.B.f.slice();
   P.homeFov = fvLabHomeFovS(P, S);
   if (P.mode === "home" || (atHome && Math.abs(cam.fov - hf0) < 1e-6 * hf0)) cam.fov = P.homeFov;
   else cam.fov = 2 * Math.atan(Math.min(Math.tan(80 * FV_DEG), L.S * Math.tan(cam.fov / 2)));
   fvLabMark(P);
   return L;
}
// lo que el laboratorio dejo escrito (para notar que alguien de fuera movio la camara: ruta del editor, lookStep, casa de golpe)
function fvLabMark(P) { var c = P.cam; P.lab.wr = { p: c.pos.slice(), l: c.look.slice(), fov: c.fov }; }
function fvLabExternal(P) {
   var L = P.lab, c = P.cam, w = L.wr; if (!w) return true;
   return c.pos[0] !== w.p[0] || c.pos[1] !== w.p[1] || c.pos[2] !== w.p[2] || c.look[0] !== w.l[0] || c.look[1] !== w.l[1] || c.look[2] !== w.l[2] || c.fov !== w.fov || !c.B;
}
// alguien escribio la camara por su cuenta: la nave se pone ahi, quieta (fvShipSync del §5.2). Los escritores de fuera (ruta del editor,
// lookStep de TABULA, fvPilotHomeNow) piensan en direcciones REALES: si cambiaron la mirada, se pasa al espacio de vuelo
function fvLabSync(P) {
   var L = P.lab, c = P.cam, w = L.wr;
   var B0 = c.B, lk = fvNorm(c.look || [0, 0, 1]), same = w && c.look && c.look[0] === w.l[0] && c.look[1] === w.l[1] && c.look[2] === w.l[2];
   var f = (same && B0) ? B0.f : fvNorm(fvLabRelFly(lk, L.S));
   if (fvLab4On() && !(same && B0)) { var fq = fvLabFlyOfReal(L, lk); f = fq.f; L.S = fq.S; }   // (v4, R1)
   c.B = B0 ? fvLabOrtho({ f: f, r: B0.r, d: B0.d }) : fvLabLevel(f, null);
   if (c.roll) { c.B = fvLabRotB(c.B, c.B.f, -c.roll); c.roll = 0; }
   c.look = c.B.f.slice(); c.S = L.S;
   L.v = [0, 0, 0]; L.w = [0, 0, 0]; L.glide = null; L.hold = null; L.fovT = null;
   fvLabMark(P);
}
// encender / apagar en caliente (tecla L). Apagar deja la camara como la de antes la entenderia (mirada real, campo real, sin base)
function fvLabSetOn(P, on) {
   if (on) { FV_LAB.ON = true; if (P) { P.lab = null; P.flight = null; P.orbit = null; P.coast = null; P.brake = null; if (P.mode === "flight") P.mode = "free"; fvLabState(P); } return true; }
   if (P && P.lab) {
      var c = P.cam, S = P.lab.S, hf0 = fvHomeFov(P.scene, P.VW, P.VH), atHome = fvLen(c.pos) < 1e-9;
      var fr = fvNorm(fvLabRelReal(c.B ? c.B.f : c.look, S));
      c.look = fr; c.fov = (atHome && (P.mode === "home" || Math.abs(c.fov - P.homeFov) < 1e-6)) ? hf0 : Math.max(1e-6, Math.min(FV_PILOT.MAX_FOV, 2 * Math.atan(Math.tan(c.fov / 2) / S)));
      delete c.B; delete c.S; c.roll = 0;
      P.homeFov = hf0; P.flight = null; P.orbit = null; P.coast = null; P.brake = null; if (P.mode === "flight") P.mode = "free";
      if (atHome && Math.abs(c.fov - hf0) < 1e-9) P.mode = "home";
      P.lookState = { x: c.look.slice(), v: [0, 0, 0] }; P.lab = null; P.warp = 0; P.trail = 0; P.flash = 0;
      if (P.free) fvFreeHalt(P);
   }
   FV_LAB.ON = false;
   return false;
}
// D1 · cambiar S en caliente (tecla V): la mirada REAL se conserva; en casa, la foto vuelve a llenar el cuadro
function fvLabSetS(P, mode) {
   FV_LAB.S_MODE = ((mode | 0) % FV_LAB.S_DEG.length + FV_LAB.S_DEG.length) % FV_LAB.S_DEG.length;
   if (!P || !P.lab) return FV_LAB.S_MODE;
   var L = P.lab, c = P.cam, S0 = L.S, S1 = fvLabSFor(P, FV_LAB.S_MODE), ro = fvLabRollOf(c.B);
   var fr = fvNorm(fvLabRelReal(c.B.f, S0)), f1 = fvNorm(fvLabRelFly(fr, S1));
   var atHome = P.mode === "home" || (fvLen(c.pos) < 1e-9 && Math.abs(c.fov - P.homeFov) < 1e-6 * P.homeFov);
   var Se = S1; if (fvLab4On()) { L.S0 = S1; var fq = fvLabFlyOfReal(L, fr); f1 = fq.f; Se = fq.S; }   // (v4, R1) S0 = el de la tecla; el que se ve, el de la mirada
   c.B = fvLabLevel(f1, c.B); if (ro.ok && Math.abs(ro.a) > 1e-9) c.B = fvLabRotB(c.B, c.B.f, ro.a);
   c.look = c.B.f.slice(); c.S = Se; L.S = Se; L.S0 = S1; L.sMode = FV_LAB.S_MODE;
   P.homeFov = fvLabHomeFovS(P, S1);
   if (atHome) c.fov = P.homeFov;
   L.w = [0, 0, 0]; fvLabMark(P);
   return FV_LAB.S_MODE;
}

// ---------------------------------------------------------------------------
// GEOMETRIA: piramide, losa, lo que hay delante
// ---------------------------------------------------------------------------
function fvLabGeo(P) {
   var G = fvRouteGeo(P), S = P.scene.stars, far = G.D;
   if (P.scene._labFar === undefined) { var m = 0; if (S) for (var i = 0; i < S.n; ++i) if (S.z[i] > m && S.inFrame[i]) m = S.z[i]; P.scene._labFar = m; }
   far = Math.max(G.D, P.scene._labFar || 0);
   return { G: G, D: G.D, kx: G.HW / G.D, ky: G.HH / G.D, zMin: -FV_LAB.EDGE.FLOOR_D * G.D, zMax: Math.max(2 * G.D, 1.1 * far), hMin: FV_LAB.EDGE.MIN_D * G.D };
}
// coordenadas de la piramide con banda minima junto al vertice: |u|, |v| ≤ 1 dentro
function fvLabU(Q, p) { var z = Math.max(0, p[2]); return [p[0] / Math.max(Q.kx * z, Q.hMin), p[1] / Math.max(Q.ky * z, Q.hMin)]; }
function fvLabInside(Q, p, k) { var u = fvLabU(Q, p); k = k || 1; return Math.abs(u[0]) <= k && Math.abs(u[1]) <= k && p[2] >= Q.zMin && p[2] <= Q.zMax; }
function fvLabClampIn(Q, p, k) {
   var z = fvClamp(p[2], Q.zMin, Q.zMax), hx = k * Math.max(Q.kx * Math.max(0, z), Q.hMin), hy = k * Math.max(Q.ky * Math.max(0, z), Q.hMin);
   return [fvClamp(p[0], -hx, hx), fvClamp(p[1], -hy, hy), z];
}
// lo que se tiene delante (real): la losa a lo largo de la mirada, o lo mas cercano
// (v2, defecto 5) lo que hay delante medido en el ESPACIO DE VUELO a lo largo de la mirada de vuelo: continuo al inclinar la mirada (en real, una
// inclinacion minima hacia el fondo pasaba de «nada delante» a «la losa a 6 000 a.l.» y el empuje saltaba de 0,2 a 200 a.l./s). Tope: D
function fvLabAheadFly(P, nr) {
   var c = P.cam, f = c.B ? c.B.f : fvNorm(c.look), N = P.scene.nebula, dn = (nr || fvFreeNearest(P)).d, d = 1e30;
   if (N) { var D = N.distLy; d = D; if (f[2] > 1e-9 && c.pos[2] < D) d = Math.min(D, (D - c.pos[2]) / f[2]); else if (f[2] < -1e-9 && c.pos[2] > D) d = Math.min(D, (c.pos[2] - D) / -f[2]); }
   else d = 4 * dn;
   return Math.max(FV_PILOT.FREE.MIN_D, d);
}
function fvLabAhead(P, nr) {
   var c = P.cam, fr = fvLabFwdReal(P), N = P.scene.nebula, d = 1e30;
   if (N) { var D = N.distLy; if (fr[2] > 1e-6 && c.pos[2] < D) d = (D - c.pos[2]) / fr[2]; else if (fr[2] < -1e-6 && c.pos[2] > D) d = (c.pos[2] - D) / -fr[2]; }
   var dn = (nr || fvFreeNearest(P)).d;
   if (d > 1e29) d = 4 * dn;
   return Math.max(FV_PILOT.FREE.MIN_D, Math.min(d, 1e9));
}

// ---------------------------------------------------------------------------
// (20-nov-2026, V1a) LA VELOCIDAD DEL VUELO A MANO. Pedido de Nino (19-nov): «hay un problema de navegacion cuando vamos demasiado rapido y hay
// nebulosas: las pasamos y despues nos desorientamos. Debe haber una velocidad maxima de avance lineal, que tarde 30 segundos en recorrer el cono 3D
// de la imagen de punta (Tierra) a punta (plano final). Y se tiene que limitar de alguna manera cuando lo combinas con giro porque si no la nave se
// desmadra». Estudio: docs/estudio-velocidad-navegacion-19nov.md (V1-01 … V1-05, V1-10). Informe: docs/encargos-19nov/V1a.md.
// Solo el vuelo libre (teclas W/S, rueda): los viajes (TRAVEL, Tour, warp) NO llevan este tope (V1b/V1c). ON false = el motor de antes, bit a bit.
//   CAP    V1-01 · velocidad VISTA (espacio de vuelo) <= V_TOPE = L / T_CONE, con L = fvBoxDMax (la boca de la caja). Consigna theta x V_TOPE: la rueda
//          1 - e^(-muescas/N0) (como hoy), W = TH_KEY, W + Mayus = TH_BOOST (Mayus ya no multiplica x4). Sustituye a THRUST_K x dNf y a SMAX x delante
//   ETA    V1-02 · frenada por TIEMPO DE LLEGADA hacia lo que queda en la direccion del MOVIMIENTO (rayo, no «lo mas cercano»): v <= max(V_APROX, d / T_ETA);
//          STOP: a la distancia de parada la nave se detiene (los ultimos STOP_S s) y hace falta un segundo empujon pasados DETENT_S para pasar
//   CROSS  V1-03 · dentro de un volumen (la losa, un objeto): v <= recorrido a lo largo del rayo / T_CROSS. Cuentan la losa (capa gemela incluida) y los objetos
//   TURN   V1-04 · la direccion de la velocidad sigue al morro (TAU_DIR); el avance cede al giro k = 1 / sqrt(1 + (w / W0)^2); Mayus ya no sube el giro
//   BOX    V1-05 · el vuelo a mano acaba en la boca de la caja (techo L) y en las paredes |u| = 1 (antes zMax y 1,5 semianchuras), con frenada por tiempo de llegada
//   AIDS   V1-10 · aguja del REGULATOR = fraccion del tope, flecha «la foto esta detras» y reticula de la foto (los dibuja la interfaz con lo que sale de fvV1Aids)
// (20-nov-2026, V1b + V1c) LOS VIAJES AUTOMATICOS (MIRABILIA, doble clic, Tour, casa) RESPETAN EL REGULADOR COMO PRESUPUESTO DE TIEMPO TOTAL. Nino: «cuando pongo el regulador en slow o cerca
// todo va imposiblemente lento; no puede tardar 30 segundos en llegar». Estudio V1-06…V1-11; decision D2 (curva A): SLOW <= 15 s, centro <= 10 s, FAST <= 6,5 s de viaje TOTAL en cine
// (giro previo, camino, media vuelta y asentamiento incluidos; warp 6,5 / 4,8 / 3,5 s: en FAST 3,5 y no los 3 del estudio, el asentamiento invisible ya come 1,5). Informe: docs/encargos-19nov/V1bc.md. Cada bandera a false = lo de antes (con ON false, trayectorias iguales)
//   CURVE    V1-06 · el presupuesto fvV1Budget (fv_pilot.js) reparte el tiempo: asentamiento y media vuelta (si la geometria la pide) se reservan y el camino lleva lo que queda;
//            el giro previo se acelera si no cabe. El warp (W1) conserva su ley y sus fases: solo se le recorta la duracion hasta que el total entre. Casa (sin media vuelta) igual
//   TAIL     V1-07 · suelo a la marcha por escala visible en el ultimo tramo (como OpenSpace, que suma 0,01 para que nunca sea 0): el ultimo 10 % de la distancia en <= 30 % del tiempo
//   ORBIT_K  V1-08 · ORBIT_MAX_S y SETTLE_MAX_S escalan con la palanca (hoy la media vuelta dura lo mismo en SLOW y en FAST) y nunca pasan de lo que queda del presupuesto
//   DWELL    V1-09 · al atravesar la losa en un viaje: >= DWELL_S s dentro [cine, warp] con cualquier palanca (se redistribuye el tiempo del camino, no se alarga el total)
//   CLOCK    V1-11 · el reloj de PixInsight recorta el paso a DT_MAX s (0,1) en vez de 0,05: entre 10 y 20 fps el vuelo dejaba de ir a camara lenta (src/ui/fv_dialog.js)
// ---------------------------------------------------------------------------
var FV_V1 = {
   ON: true, CAP: true, ETA: true, STOP: true, CROSS: true, TURN: true, BOX: true, AIDS: true, CURVE: true, TAIL: true, ORBIT_K: true, DWELL: true, CLOCK: true,
   T_CONE: 30,               // s: Tierra -> boca de la caja a la marcha maxima (numero de Nino)
   TH_KEY: 0.6, TH_BOOST: 1, // consigna de W y de W + Mayus (fraccion del tope)
   T_ETA: 1.5, APROX_K: 0.25, STOP_S: 0.4, DETENT_S: 0.45, HALT_K: 0.02, EPS_K: 0.01,   // frenada: tiempo de llegada, suelo (x V_TOPE), tiempo de la parada, tope del segundo empujon, umbrales de «parado» y de cero
   T_CROSS: 4.2, CHORD_K: 3, // cruzar un volumen cuesta >= 4 s (4,2 de tope: la inercia deja entrar un poco por encima del tope); el recorrido por una losa nunca cuenta mas de CHORD_K grosores (pasar de lado no la frena)
   TAU_DIR: 0.30, W0: 18,    // la velocidad sigue al morro con esta constante (s); el avance cae a 1/sqrt(2) con W0 °/s de giro
   TAU_OVER: 0.10,           // s: lo que sobra de velocidad sobre el tope del momento se quita con esta constante
   SAMPLES: 48,              // muestras del rayo contra las paredes
   // ---- V1b / V1c: los viajes automaticos
   T_SLOW: [15, 9], T_FAST: [6.5, 5],   // (20-nov, coordinador, D5: el warp conserva su sensacion de salto de W1 a pedido de Nino; antes [.., 6.5] y [.., 3.5]) presupuesto de tiempo total [cine, warp] con la palanca en SLOW y en FAST (D2, curva A; el warp en FAST 3,5 y no los 3 del estudio: el asentamiento invisible, 1,4-1,8 s, ya se come la mitad); entre medias, interpolacion logaritmica (fvV1Budget)
   PLAN_K: 0.96,             // el plan apunta a este tanto del presupuesto (margen para lo que solo se sabe al correr: el asentamiento y el reloj suavizado)
   MOVE_MIN_K: 0.35,         // el camino dura al menos este tanto del presupuesto: si la media vuelta no cabe se acorta ella
   DEC_REF: 2.5, DEC_MIN_K: 0.7,   // el termino por decadas: un viaje corto (poca distancia / llegada) dura DEC_MIN_K…1 de lo que da el presupuesto, nunca mas
   SETTLE_EST: [1.6, 1.8],   // s [cine, warp]: lo que se reserva para el asentamiento (medido: 0,9-1,1 con SLOW, 1,3-1,6 con FAST y tras la media vuelta, 1,5-1,8 en warp)
   K_ORB: 0.5, K_SET: 0.7,   // ORBIT_K: ORBIT_MAX_S x k (k = presupuesto / presupuesto del centro, entre K_ORB y 1) y SETTLE_MAX_S x k (entre K_SET y 1)
   PRE_FRAC: 0.3, KT_MAX: 1.8, // el giro previo cabe en PRE_FRAC del presupuesto: si no, los topes de giro del estilo suben hasta KT_MAX veces (solo ese viaje)
   TAIL_K: 0.12,             // TAIL: suelo de la marcha por escala visible = TAIL_K x la longitud del camino (el ultimo tramo ya no es asintotico)
   DWELL_S: [1.5, 0.6], DWELL_K: 1.06, DWELL_K_MIN: 0.0005, DWELL_RAMP: 0.25, DWELL_N_K: 6, DWELL_N_MAX: 6000,   // DWELL: segundos minimos dentro de la losa [cine, warp]; margen sobre el minimo; el SLAB_VIS_K mas bajo que se prueba
   ORB_UP: 0.75,             // la media vuelta de un viaje con presupuesto se decide cuando el camino lleva al menos este tanto (con caminos de 2-3 s en FAST se decidia al salir, con la foto aun en pantalla)
   DT_MAX: 0.1               // CLOCK: recorte del paso del reloj de PixInsight (s)
};
function fvV1On(sub) { return typeof FV_V1 !== "undefined" && FV_V1.ON === true && (sub === undefined || FV_V1[sub] === true); }
// L: de la Tierra a la boca de la caja que se dibuja (fvBoxDMax, fv_objects.js; sin el: 1,35 D)
function fvV1L(P) {
   if (typeof fvBoxDMax === "function") return fvBoxDMax(P.scene);
   var N = P.scene.nebula; return Math.max(100, N ? 1.35 * N.distLy : 0);
}
function fvV1Top(P) { return fvV1L(P) / FV_V1.T_CONE; }
function fvV1State(P) {
   var L = P.lab;
   if (!L.v1) L.v1 = { halt: null, pass: {}, cap: 0, why: "", frac: 0, fracS: 0, stopCap: 1e30, stopId: "", ret: 0, arrow: null };
   return L.v1;
}
// ---------------------------------------------------------------------------
// (20-nov-2026, V1b + V1c) LOS VIAJES AUTOMATICOS CON PRESUPUESTO DE TIEMPO TOTAL (ver arriba CURVE, TAIL, ORBIT_K, DWELL). fvV1Budget (fv_pilot.js) da los segundos
// ---------------------------------------------------------------------------
// k (kmin…1) = presupuesto / presupuesto del centro de la palanca: SLOW 1 (no se alarga lo de siempre), FAST < 1
function fvV1KOf(P, kind, kmin) {
   var i = (kind === "warp") ? 1 : 0, tm = Math.sqrt(FV_V1.T_SLOW[i] * FV_V1.T_FAST[i]);
   if (kind === "warp" && P && P.gwPlan === true && typeof FV_GWARP !== "undefined") tm = Math.sqrt(FV_GWARP.T_SLOW * FV_GWARP.T_FAST);      // (N-galaxias-warp) el centro de la palanca del warp corto
   return fvClamp(fvV1Budget(P, kind) / tm, kmin, 1);
}
// la media vuelta que haria el viaje, sin lanzarla: manda la geometria (cover se ignora: el pintor lo decide al llegar; reservar de mas solo hace que acabe antes), con el tope de tiempo tMax.
// Con un P.flight de mentira (lo que lee fvLab5OrbitPlan: destino, punto de llegada, t0). Devuelve el plan de la vuelta o null
function fvV1OrbitPeek(P, X, kind, T, A, tMax) {
   var keep = P.flight, need = X.orbNeed, o = null;
   P.flight = { T: T, p1: A, t: 0 };
   try { o = fvLab5OrbitPlan(P, X, kind, { tMax: tMax, noCover: true, partial: true }); } finally { P.flight = keep; X.orbNeed = need; }
   return o;
}
// el reparto del presupuesto de un viaje de cine / warp con destino (fvLab4Plan). turnA: lo que hay que girar hasta tener el destino en el recuadro (rad; < 0 = ya esta dentro).
// Devuelve { dur: el camino (s), pre0: el giro previo (s), info: lo que el viaje consulta al correr (X.bud) }
function fvV1Plan(P, X, kind, dec, turnA, tc, T, A, onlyTurn) {
   var F = FV_V1, V4 = FV_LAB.V4, V5 = FV_LAB.V5, WARP = (kind === "warp"), i = WARP ? 1 : 0, PREP = FV_LAB.WARP.PREP;
   var Tb = fvV1Budget(P, kind), Tp = Tb * F.PLAN_K, v5 = fvLab5On(), clk = v5 && !WARP;
   var kO = F.ORBIT_K ? fvV1KOf(P, kind, F.K_ORB) : 1, kS = F.ORBIT_K ? fvV1KOf(P, kind, F.K_SET) : 1;
   var settleCap = V4.SETTLE_MAX_S * kS, settleEst = Math.min(settleCap, F.SETTLE_EST[i]);
   // el giro previo (s) con los topes del estilo x kT; si pasa de PRE_FRAC del presupuesto, kT sube hasta KT_MAX (la suma W/A del arranque no cambia: A sube igual que W)
   var Wd = tc[0] * FV_DEG, Ad = tc[1] * FV_DEG, preMax = F.PRE_FRAC * Tp, kT = 1;
   var preOf = function(k) { return turnA < 0 ? 0 : Math.max(0, turnA) / (k * Wd) + Wd / Ad + 0.3; };
   if (preOf(1) > preMax) { var room = preMax - Wd / Ad - 0.3; kT = (room > 0.05) ? Math.min(F.KT_MAX, Math.max(1, Math.max(0, turnA) / (Wd * room))) : F.KT_MAX; }
   var pre = preOf(kT);
   // lo que ocupa el camino x con un giro previo pre: cine (reloj propio): el giro previo avanza a CREEP_K; warp: el giro cabe en la preparacion. solve: la inversa (R -> camino)
   var cr = V5.CREEP ? V5.CREEP_K : 0;
   var solve = function(R) { if (clk) return R - (1 - cr) * pre - (pre > 0 ? 0.5 : 0); return (pre <= PREP * R) ? R : (R - pre) / (1 - PREP); };
   var back = function(x) { if (clk) return x + (1 - cr) * pre + (pre > 0 ? 0.5 : 0); return (pre <= PREP * x) ? x : x * (1 - PREP) + pre; };
   var peek = function(tm) { return (v5 && V5.ORBIT) ? fvV1OrbitPeek(P, X, kind, T, A, tm) : null; };
   // lo que la vuelta se alarga mas alla del camino: en cine empieza al faltar OVL_S s, pero no antes de ORB_UP del camino (solape = min(OVL_S, (1 - ORB_UP) x)); en warp, al acabar el camino
   var tailOf = function(o, xx) { return o ? (clk ? Math.max(0, o.dur - Math.min(V5.OVL_S, (1 - F.ORB_UP) * xx)) : o.dur) : 0; };
   var fix = function(o) { var xx = 8, k; for (k = 0; k < 5; ++k) xx = solve(Tp - settleEst - tailOf(o, Math.max(0.5, xx))); return xx; };      // el camino y la cola de la vuelta dependen uno de otro: punto fijo
   var tMaxO = V5.ORBIT_MAX_S[i] * kO, orb = peek(tMaxO), capUsed = tMaxO;
   var xMin = F.MOVE_MIN_K * Tp, x = fix(orb), tail = tailOf(orb, x);
   if (x < xMin && orb) {                                   // la media vuelta no cabe con el camino que se le debe: se acorta ella (parcial en warp; en cine, fuera si ya no cabe)
      var tailAllow = Math.max(0, Tp - settleEst - back(xMin));
      capUsed = clk ? tailAllow + Math.min(V5.OVL_S, (1 - F.ORB_UP) * xMin) : tailAllow;
      orb = (tailAllow > 0.5) ? peek(capUsed) : null; x = fix(orb); tail = tailOf(orb, x);
   }
   x = Math.max(x, xMin);
   // el termino por decadas: un viaje corto dura DEC_MIN_K…1 de lo que da el presupuesto
   var base = function(d) { return WARP ? fvLabWarpDur(d) : fvClamp(FV_PILOT.CINE_S_MIN + FV_PILOT.CINE_S_DEC * d, FV_PILOT.CINE_S_MIN, FV_PILOT.CINE_S_MAX) * ((FV_PILOT.FAST && FV_PILOT.FAST.DUR_K) || 0.6); };
   var fdec = fvClamp(base(dec) / base(F.DEC_REF), F.DEC_MIN_K, 1);
   if (onlyTurn) x = Math.min(3.0, 0.5 * Tp); else x *= fdec;      // ya esta alli: solo se gira (los 3 s de siempre, nunca mas de media presupuesto)
   return { dur: x, pre0: pre, info: { Tb: Tb, Tp: Tp, kT: kT, settleCap: settleCap, settleEst: settleEst, orbCap: capUsed, orbTail: tail, orbPeek: orb ? orb.dur : 0, kO: kO, kS: kS, fdec: fdec, move: x } };
}
// casa: dura PLAN_K x el presupuesto del cine x el termino por decadas (misma cuenta que fvV1Plan; llegar no tiene asentamiento ni media vuelta)
function fvV1HomeDur(P, dec) {
   var F = FV_V1, base = function(d) { return fvClamp(FV_PILOT.CINE_S_MIN + FV_PILOT.CINE_S_DEC * d, FV_PILOT.CINE_S_MIN, FV_PILOT.CINE_S_MAX) * ((FV_PILOT.FAST && FV_PILOT.FAST.DUR_K) || 0.6); };
   return F.PLAN_K * fvV1Budget(P, (P && P.gwPlan === true) ? "warp" : "cine") * fvClamp(base(dec) / base(F.DEC_REF), F.DEC_MIN_K, 1);      // (N-galaxias-warp) P.gwPlan: la vuelta desde una galaxia, con el presupuesto del warp corto
}
// DWELL: el tiempo que el viaje pasa DENTRO de la losa al atravesarla (de la Tierra hacia detras o al reves) es >= DWELL_S: la constante del cruce de la losa (SLAB_VIS_K: la marcha
// dentro y al acercarse es <= distancia a la cara + k x grosor) pasa de constante a «la que haga falta» (biseccion en k, hasta DWELL_K_MIN); el camino se rehace con ella y el total no cambia
// (el tiempo se reparte). Sigue siendo la misma ley continua (sin escalon al entrar). dur: lo que dura el camino (s). Con la losa ya lenta de siempre, k no cambia
function fvV1Dwell(P, X, kind, dur, pS, T, S0) {
   var F = FV_V1, N = P.scene.nebula, pc = X.pc; X.dwell = null;
   if (!fvV1On("DWELL") || !N || !pc || !(dur > 0)) return;
   var WARP = (kind === "warp"), need = F.DWELL_S[WARP ? 1 : 0] * F.DWELL_K, zA = N.distLy - N.thickLy / 2, zB = N.distLy + N.thickLy / 2, i;
   var z0 = pc.fn(0)[2], z1 = pc.fn(1)[2], up = (z0 < zA && z1 > zB), dn = (z0 > zB && z1 < zA);
   if (!up && !dn) return;
   // el camino se muestrea mas fino que la losa (con 200 puntos una losa de 41 a.l. en 8 000 caia entre dos muestras)
   var nD = Math.min(F.DWELL_N_MAX, Math.max(pc.n, Math.ceil(F.DWELL_N_K * pc.len / Math.max(1e-6, N.thickLy)))), i0 = -1, i1 = -1;
   for (i = 0; i <= nD; ++i) { var z = pc.fn(i / nD)[2], inn = up ? z >= zA : z <= zB, out = up ? z >= zB : z <= zA; if (i0 < 0 && inn) i0 = i; if (i1 < 0 && out) { i1 = i; break; } }
   if (i0 < 0 || i1 <= i0) return;
   var span = WARP ? (1 - FV_LAB.WARP.PREP) * dur : dur;
   var invX = function(x) { var lo = 0, hi = 1, k; for (k = 0; k < 40; ++k) { var mid = 0.5 * (lo + hi); if (fvCineX(mid) < x) lo = mid; else hi = mid; } return 0.5 * (lo + hi); };
   var timeIn = function(q) { return (invX(q.tau[i1]) - invX(q.tau[i0])) * span; };
   var ramp = 0, pace = function(k) { return fvLab4Pace(P, pc.fn, pS, T, S0, k, nD, ramp); };
   var k0 = FV_LAB.SLAB_VIS_K, q0 = pace(k0), s0 = timeIn(q0), k = k0, lo = F.DWELL_K_MIN, hi = k0, it, qk = q0;
   if (s0 < need) {
      ramp = F.DWELL_RAMP;                                                      // hay que frenar mucho antes de la losa: la frenada se alarga (sin ella, de 3 000 a.l./s a 70 en 3 fotogramas: cociente de marcha 1,8 entre fotogramas)
      if (timeIn(pace(lo)) >= need) {                                             // el tiempo dentro baja al subir k: el k mas alto que aun da el minimo
         for (it = 0; it < 36; ++it) { var mid = Math.sqrt(lo * hi); if (timeIn(pace(mid)) >= need) lo = mid; else hi = mid; }
      }
      k = lo; qk = pace(k);
   }
   X.pc = qk;
   X.dwell = { k: k, ramp: ramp, before: s0, after: timeIn(qk), need: need, i0: i0, i1: i1, n: nD };
}
// la consigna de la rueda como fraccion del tope (con signo): 1 - e^(-muescas/N0)
function fvV1Theta(thr) { var T = FV_LAB.THROTTLE; return (thr < 0 ? -1 : 1) * (1 - Math.exp(-Math.abs(thr) / T.N0)); }
// los objetos que cuentan como volumen (no estrellas: esas siguen con su STANDOFF; no la principal: es la losa). Cache por escena
function fvV1Obstacles(P) {
   var sc = P.scene, O = sc.objects, N = sc.nebula;
   if (!O || !O.length || typeof fvObjBoxK !== "function" || typeof fvObjScaled !== "function") return [];
   var key = O.length + "|" + fvV1L(P) + "|" + (N ? N.distLy + "|" + N.thickLy : "") + "|" + (typeof FV_BOX !== "undefined" && FV_BOX.ON ? 1 : 0), c = sc._v1Obs;
   if (c && c.key === key) return c.list;
   var list = [], i, zIn = N ? N.distLy - N.thickLy / 2 : 0, zOut = N ? N.distLy + N.thickLy / 2 : 0;
   for (i = 0; i < O.length; ++i) {
      var o = O[i]; if (!o || o.main || o.type === "star" || o.type === "exoplanet" || !o.pos) continue;
      var kb = fvObjBoxK(sc, o), useF = (typeof FV_OBJ !== "undefined" && FV_OBJ.FRAME && o.frame && o.frame.pos), p0 = useF ? o.frame.pos : o.pos;
      var R = ((useF && o.frame.rLy > 0) ? o.frame.rLy : o.radiusLy) * kb, A = (o.arriveLy > 0 ? o.arriveLy : 0) * kb;
      if (!(R > 0) || !isFinite(R)) continue;
      var cc = fvObjScaled(p0, kb), Rh = 1.5 * R, Rs = Math.max(A, 2 * R);      // casco 1,5 R (lo que cuenta como «ir hacia el»); parada a su distancia de llegada
      list.push({ id: "o" + i, c: cc, R: R, Rh: Rh, Rs: Rs, inSlab: !!(N && cc[2] > zIn - R && cc[2] < zOut + R) });
   }
   try { Object.defineProperty(sc, "_v1Obs", { value: { key: key, list: list }, enumerable: false, writable: true, configurable: true }); } catch (e) { sc._v1Obs = { key: key, list: list }; }
   return list;
}
// rayo p + t r (r unitario, real) contra la esfera (c, rad): { tIn, tOut } con tIn < 0 si p esta dentro; null si no la toca por delante
function fvV1RaySphere(p, r, c, rad) {
   var ox = c[0] - p[0], oy = c[1] - p[1], oz = c[2] - p[2], tca = ox * r[0] + oy * r[1] + oz * r[2], d2 = ox * ox + oy * oy + oz * oz - tca * tca, r2 = rad * rad;
   if (d2 >= r2) return null;
   var th = Math.sqrt(r2 - d2); if (tca + th <= 0) return null;
   return { tIn: tca - th, tOut: tca + th, b2: d2 };
}
// distancia (real, a lo largo de r) hasta salir de la caja por las paredes, el techo o el suelo; 1e30 si no sale. Marcha por muestras y afina
function fvV1WallDist(Q, p, r, Lm) {
   var tMax = 1e30;
   if (r[2] > 1e-9) tMax = Math.min(tMax, Math.max(0, Lm - p[2]) / r[2]); else if (r[2] < -1e-9) tMax = Math.min(tMax, Math.max(0, p[2] - Q.zMin) / -r[2]);
   var tLim = Math.min(tMax, 4 * Lm), n = FV_V1.SAMPLES, i;
   var marg = function(t) {
      var z = Math.max(0, p[2] + r[2] * t), hx = Math.max(Q.kx * z, Q.hMin), hy = Math.max(Q.ky * z, Q.hMin);
      return Math.min(hx - Math.abs(p[0] + r[0] * t), hy - Math.abs(p[1] + r[1] * t));
   };
   var m0 = marg(0);
   if (m0 <= 0) { return (marg(1e-6 * Lm + 1e-9) < m0 - 1e-12 || tMax <= 0) ? 0 : tMax; }
   var tPrev = 0;
   for (i = 1; i <= n; ++i) {
      var t = tLim * (i / n) * (i / n);
      if (marg(t) <= 0) {
         var lo = tPrev, hi = t; for (var k = 0; k < 14; ++k) { var mid = 0.5 * (lo + hi); if (marg(mid) <= 0) hi = mid; else lo = mid; }
         return Math.min(hi, tMax);
      }
      tPrev = t;
   }
   return tMax;
}
// el tope de velocidad VISTA en la direccion real r desde la posicion p. g = longitud de vuelo de un metro real a lo largo de r (el estirado lateral):
// todo tiempo de llegada se cuenta con la distancia VISTA (g d) porque la velocidad que se limita es la vista. Devuelve
// { cap, why, stopCap, stopId, stops: [{ id, cap }] }; cap <= V_TOPE. Sin estado: lo de pasar / parar viene de st (L.v1.pass)
function fvV1Caps(P, Q, r, Vtop, st) {
   var F = FV_V1, L = P.lab, p = P.cam.pos, N = P.scene.nebula, Lm = Vtop * F.T_CONE, g = fvLen(fvLabRelFly(r, L.S)), Vap = F.APROX_K * Vtop;
   var res = { cap: Vtop, why: "tope", stopCap: 1e30, stopId: "", stops: [] };
   var take = function(c, why) { if (c < res.cap) { res.cap = c; res.why = why; } };
   var vols = [];
   // la losa de la nebulosa principal (con la capa gemela: la principal es la capa gemela cuando el protagonista es un objeto dibujado)
   if (N && N.thickLy > 0) {
      var th = N.thickLy, zIn = Q.G.zIn, zOut = Q.G.zOut, rz = r[2], inL = function(q) { var u = fvLabU(Q, q); return Math.abs(u[0]) <= 1 && Math.abs(u[1]) <= 1; };
      var ccap = th / Math.max(Math.abs(rz), 1 / F.CHORD_K), v = { id: "slab", chord: ccap, near: 0, delta: th / 2, dIn: -1, dStop: 1e30 };
      if (p[2] >= zIn && p[2] <= zOut) { if (!inL(p)) v = null; }
      else if (rz > 1e-9 && p[2] < zIn) {
         var tI = (zIn - p[2]) / rz, qI = [p[0] + r[0] * tI, p[1] + r[1] * tI, zIn];
         if (inL(qI)) { v.dIn = tI; v.dStop = (zIn - th / 2 - p[2]) / rz; v.near = zIn - p[2]; } else v = null;
      } else if (rz < -1e-9 && p[2] > zOut) {
         var tO = (zOut - p[2]) / rz, qO = [p[0] + r[0] * tO, p[1] + r[1] * tO, zOut];
         if (inL(qO)) { v.dIn = tO; v.dStop = (zOut + th / 2 - p[2]) / rz; v.near = p[2] - zOut; } else v = null;
      } else v = null;
      // el estado «paso dado» de la losa se limpia al alejarse (por posicion, no por el rayo: girar un momento no lo rearma)
      var nearS = p[2] < zIn ? zIn - p[2] : (p[2] > zOut ? p[2] - zOut : 0);
      if (st.pass.slab && nearS > th) delete st.pass.slab;
      if (v) vols.push(v);
   }
   var obs = fvV1Obstacles(P), i;
   for (i = 0; i < obs.length; ++i) {
      var ob = obs[i], dC = Math.sqrt((ob.c[0] - p[0]) * (ob.c[0] - p[0]) + (ob.c[1] - p[1]) * (ob.c[1] - p[1]) + (ob.c[2] - p[2]) * (ob.c[2] - p[2]));
      if (st.pass[ob.id] && dC - ob.Rh > 2 * (ob.Rs - ob.Rh)) delete st.pass[ob.id];
      var rsB = fvV1RaySphere(p, r, ob.c, ob.Rh), rsS = rsB ? fvV1RaySphere(p, r, ob.c, ob.Rs) : null;       // solo cuenta lo que el rayo va a TOCAR (casco Rh); la parada es a Rs del centro
      if (!rsB || !rsS) continue;
      vols.push({ id: ob.id, chord: rsB.tOut - rsB.tIn, dIn: rsB.tIn, dStop: ob.inSlab ? 1e30 : rsS.tIn });
   }
   for (i = 0; i < vols.length; ++i) {
      var vo = vols[i], vc = F.CROSS ? Math.min(Vtop, g * vo.chord / F.T_CROSS) : Vtop, inside = vo.dIn <= 0 && vo.chord > 0;
      if (inside) { if (F.CROSS) take(vc, "cruce"); continue; }
      if (!F.ETA) continue;
      var passed = !!st.pass[vo.id], floorV = F.CROSS ? vc : Vap;      // sin parada: se llega a la cara del volumen con la velocidad de cruce (o la de aproximacion)
      if (F.STOP && !passed && vo.dStop < 1e29) {
         var ds = g * vo.dStop, cs = ds <= 0 ? 0 : Math.min(Math.max(Vap, ds / F.T_ETA), ds / F.STOP_S);
         take(cs, "parada"); res.stops.push({ id: vo.id, cap: cs }); if (cs < res.stopCap) { res.stopCap = cs; res.stopId = vo.id; }
      } else if (vo.dIn < 1e29) take(floorV + g * Math.max(0, vo.dIn) / F.T_ETA, "llegada");      // v = v_cruce + d / T_ETA: baja a la de cruce justo en la cara (sin latigazo y sin arrastrarse)
   }
   if (F.BOX && F.ETA) { var dW = fvV1WallDist(Q, p, r, Lm); if (dW < 1e29) take(g * dW / F.T_ETA, "pared"); }
   return res;
}
// un empujon nuevo (tecla de avance recien pulsada, o muesca de la rueda hacia delante): si la nave esta parada delante de algo, pasa. Pasados DETENT_S de la parada
function fvV1Push(P) {
   if (!fvV1On("ETA") || !FV_V1.STOP || !P.lab || !P.cam.B) return;
   var st = fvV1State(P), Q = fvLabGeo(P), Vtop = fvV1Top(P), r = fvLabFwdReal(P), cs = fvV1Caps(P, Q, r, Vtop, st), k, any = false;
   var still = fvLen(fvLabRelFly(P.lab.v, P.lab.S)) < 0.05 * Vtop;      // sin parada registrada: solo vale una nave quieta (llego de otra forma: un viaje)
   for (k = 0; k < cs.stops.length; ++k) {
      var sp = cs.stops[k]; if (!(sp.cap < FV_V1.HALT_K * Vtop)) continue;
      if (st.halt && st.halt.id === sp.id) { if ((P.t - st.halt.t) < FV_V1.DETENT_S) continue; }
      else if (!still) continue;
      st.pass[sp.id] = true; any = true; if (st.halt && st.halt.id === sp.id) st.halt = null;
   }
   return any;
}
// V1-01/02/03/04: el empuje del vuelo libre (sustituye al de fvLabFreeSub). Todo en el espacio de VUELO (lo que se ve); L.v sigue siendo real
function fvV1Thrust(P, h, Q, o) {
   var F = FV_V1, L = P.lab, c = P.cam, B = c.B, S = L.S, TH = FV_LAB.THROTTLE, FP = FV_PILOT.FREE, st = fvV1State(P), Vtop = fvV1Top(P);
   var thOn = !!(TH && TH.ON && L.thr !== undefined);
   if (thOn && o.thr !== 0) { L.thr = 0; L.thrAssist = false; }
   var th = 0, wheel = false, assist = false;
   if (o.thr !== 0) th = o.thr * (o.boost ? F.TH_BOOST : F.TH_KEY);
   else if (thOn && (L.thr !== 0 || L.thrAssist)) {
      var tq = (P.t || 0) - L.thrT;
      if (L.thr !== 0 && tq > TH.HOLD_S) { L.thr *= Math.exp(-h / TH.DECAY_S); if (Math.abs(L.thr) < 0.05) L.thr = 0; }
      wheel = true; assist = !!L.thrAssist; th = assist ? 0 : fvV1Theta(L.thr);
   }
   var vF = fvLabRelFly(L.v, S), m = fvLen(vF), sg = th > 0 ? 1 : (th < 0 ? -1 : 0);
   // los topes del momento (llegada, parada, cruce, paredes), en la direccion del MOVIMIENTO (la del morro si casi no se mueve). Primero: la consigna se recorta
   // ANTES de empujar (si no, el empuje y el recorte se igualaban en una marcha de equilibrio, ~15 % del tope, y la nave no se paraba)
   var rd = null, cs = null, mc = Vtop;
   if (m > 0.02 * Vtop) rd = fvNorm(fvLabRelReal(vF, S)); else if (sg !== 0) rd = fvNorm(fvLabRelReal(fvMul(B.f, sg), S));
   if (rd) { cs = fvV1Caps(P, Q, rd, Vtop, st); mc = cs.cap; st.cap = mc; st.why = cs.why; st.stopCap = cs.stopCap; st.stopId = cs.stopId; }
   else { st.cap = Vtop; st.why = "tope"; st.stopCap = 1e30; st.stopId = ""; }
   // V1-04: el avance cede al giro (w = velocidad angular de la mirada, sin el alabeo)
   var kT = 1;
   if (F.TURN) { var wv = L.w, wf = fvSub(wv, fvMul(B.f, fvDot(wv, B.f))), wDeg = fvLen(wf) / FV_DEG; kT = 1 / Math.sqrt(1 + (wDeg / F.W0) * (wDeg / F.W0)); }
   var mT = Math.min(Math.abs(th) * Vtop * kT, mc);
   var tau = assist ? TH.TAU_BRAKE : (sg !== 0 ? (mT < m ? TH.TAU_DOWN : (wheel ? TH.TAU_UP : FP.ACC_S)) : FP.DAMP_S);
   var a = 1 - Math.exp(-h / tau);
   if (sg !== 0) {
      var td = fvMul(B.f, sg), vd = m > 1e-9 * Vtop ? fvMul(vF, 1 / m) : null;
      if (F.TURN && vd && fvAngle(vd, td) < 0.5 * Math.PI) {
         var ang = fvAngle(vd, td), nd = ang > 1e-9 ? fvSlerpDir(vd, td, 1 - Math.exp(-h / F.TAU_DIR)) : vd;
         m = Math.max(0, m + (mT - m) * a); vF = fvMul(nd, m);
      } else vF = fvAdd(vF, fvMul(fvSub(fvMul(td, mT), vF), a));
   } else vF = fvMul(vF, 1 - a);
   if (assist) { L.w = fvMul(L.w, Math.exp(-h / TH.TAU_SPIN)); }
   m = fvLen(vF);
   // lo que sobre del tope del momento (venia mas rapido, o la direccion cambio) se quita con TAU_OVER
   if (m > mc) { var e = mc + (m - mc) * Math.exp(-h / F.TAU_OVER); vF = fvMul(vF, e / m); m = e; }
   if (cs) {
      if (mc < F.EPS_K * Vtop && (cs.why === "parada" || cs.why === "pared") && m < 4 * F.EPS_K * Vtop) { vF = [0, 0, 0]; m = 0; }      // el final asintotico de una parada o de una pared (no un cruce lento de verdad)
      // ¿parada? (el segundo empujon la levanta, fvV1Push)
      if (cs.stopCap < F.HALT_K * Vtop) { if (!st.halt || st.halt.id !== cs.stopId) st.halt = { id: cs.stopId, t: P.t }; }      // la nave llega a la parada: desde aqui cuentan los DETENT_S del segundo empujon
      else if (st.halt && cs.stopCap > 1.5 * F.HALT_K * Vtop) st.halt = null;
   } else if (m < 1e-9) st.halt = null;
   L.v = fvLabRelReal(vF, S);
   if (assist && L.thr === 0 && m < 1e-5 * Vtop) { L.v = [0, 0, 0]; if ((P.t || 0) - L.thrBrakeT > TH.DETENT_S) L.thrAssist = false; }
   if (o.thr === 0 && !wheel && m < 2e-4 * Vtop) L.v = [0, 0, 0];
   st.frac = m / Math.max(1e-9, Vtop);
   fvLabMove(P, h, Q, o.nr);
}
// V1-05: techo en la boca y paredes en |u| = 1. Lo que ya esta fuera (llegada de un viaje) puede volver pero no ir mas lejos
function fvV1BoxClamp(P, Q, c0, np, v) {
   var top = Math.max(Q.zMin, Math.min(Q.zMax, fvV1L(P))), z = np[2];
   if (z > top) { z = Math.max(top, Math.min(c0[2], z)); if (v[2] > 0) v[2] = 0; }
   else if (z < Q.zMin) { z = Q.zMin; if (v[2] < 0) v[2] = 0; }
   var zz = Math.max(0, z), hx = Math.max(Q.kx * zz, Q.hMin), hy = Math.max(Q.ky * zz, Q.hMin);
   // por eje lateral: dentro, hasta la pared; si ya estaba fuera (llegada de un viaje), puede volver hacia dentro pero no irse mas lejos
   var lat = function(n, o, hh, vv) {
      var an = Math.abs(n); if (an <= hh) return [n, vv];
      var s = n < 0 ? -1 : 1, ao = Math.abs(o), nn = ao <= hh ? hh : Math.max(hh, Math.min(ao, an));
      return [s * nn, ((an > ao || ao <= hh) && s * vv > 0) ? 0 : vv];
   };
   var lx = lat(np[0], c0[0], hx, v[0]), ly = lat(np[1], c0[1], hy, v[1]);
   v[0] = lx[1]; v[1] = ly[1];
   return [lx[0], ly[0], z];
}
// V1-10: lo que dibuja la interfaz. frac = marcha / V_TOPE (suavizada) para la aguja del REGULATOR; arrow = el marcador «la foto esta detras» cuando el
// rectangulo de la foto no toca la pantalla; ret = 0..1 la retıcula de la foto (gira a mas de 6 °/s o avanza a mas de la mitad del tope)
function fvV1Aids(P, dt) {
   if (!fvV1On("AIDS") || !P.lab) return null;
   var L = P.lab, st = fvV1State(P), F = FV_V1, Vtop = fvV1Top(P), vSee = (L.vShow !== undefined && isFinite(L.vShow)) ? L.vShow : 0;
   var fr = fvClamp(vSee / Math.max(1e-9, Vtop), 0, 1.2);
   st.fracS = fr;
   var wDeg = fvLen(L.w) / FV_DEG, want = (wDeg > 6 || fr > 0.5) ? 1 : 0;
   st.ret += (want - st.ret) * (1 - Math.exp(-Math.max(0, dt) / (want ? 0.15 : 0.6)));
   return st;
}

// V1-10 (1): «la foto esta detras». true si el rectangulo de la foto (plano de la nebulosa, el recuadro de la piramide) no toca la pantalla: ninguna de sus 9 muestras
// (esquinas, medios, centro) cae en la vista y el eje de la mirada no corta el rectangulo. Lo usa fvNmHud para dibujar el marcador TU FOTO en el borde sin pedir que ademas no se vea nada
function fvV1PhotoAid(P, W, H, pr) {
   if (!fvV1On("AIDS") || !P.lab || typeof FV_LAB === "undefined" || FV_LAB.ON !== true || !P.scene.nebula) return false;
   var G = fvRouteGeo(P), hw = G.HW, hh = G.HH, D = G.D, pts = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh], [0, -hh], [hw, 0], [0, hh], [-hw, 0], [0, 0]], i;
   for (i = 0; i < pts.length; ++i) { var q = pr.project([pts[i][0], pts[i][1], D]); if (q && q[0] >= 0 && q[0] <= W && q[1] >= 0 && q[1] <= H) return false; }
   var f = P.cam.B ? P.cam.B.f : fvNorm(P.cam.look), fr = fvNorm(fvLabRelReal(f, P.lab.S));
   if (fr[2] > 1e-9) { var t = (D - P.cam.pos[2]) / fr[2]; if (t > 0) { var x = P.cam.pos[0] + fr[0] * t, y = P.cam.pos[1] + fr[1] * t; if (Math.abs(x) <= hw && Math.abs(y) <= hh) return false; } }
   return true;
}
// V1-10 (2): la reticula de la foto. { a: angulo en pantalla del «arriba» de la foto (rad, x a la derecha, y abajo), k: 0..1 } o null
function fvV1Reticle(P) {
   if (!fvV1On("AIDS") || !P.lab || !P.lab.v1 || !P.cam.B) return null;
   var k = P.lab.v1.ret; if (!(k > 0.02)) return null;
   var B = P.cam.B, up = [0, -1, 0];
   return { a: Math.atan2(fvDot(up, B.d), fvDot(up, B.r)), k: k };
}
// V1-10 (3): la aguja del REGULATOR en vuelo a mano = la fraccion del tope que lleva la nave (0..1); null fuera del vuelo a mano o con AIDS apagada
function fvV1RegHand(P) {
   if (!fvV1On("AIDS") || !P || !P.lab || P.flight || !P.lab.v1) return null;
   return fvClamp(P.lab.v1.fracS, 0, 1);
}

// ---------------------------------------------------------------------------
// MANDOS (los visores solo traducen la tecla; aqui, acciones con nombre: B20)
// ---------------------------------------------------------------------------
function fvLabKeyMap() {
   if (P_LAB_KEYS) return P_LAB_KEYS;
   var M = {}, F = fvFreeKeyMap(), kq = (typeof Key_Q !== "undefined") ? Key_Q : 0x51, kz = (typeof Key_Z !== "undefined") ? Key_Z : 0x5a;   // sin eval (CPD)
   for (var c in F) M[c] = F[c];
   M[kq >>> 0] = "roll-"; M[kz >>> 0] = "roll+";
   // (v4, R1) las flechas ↑ ↓ del teclado miran arriba / abajo (antes empujaban); empujar queda en W / S
   if (fvLab4On() && FV_LAB.LOOK360 && FV_LAB.LOOK360.ARROWS) { M[((typeof Key_Up !== "undefined") ? Key_Up : 0x10000002) >>> 0] = "up"; M[((typeof Key_Down !== "undefined") ? Key_Down : 0x10000004) >>> 0] = "down"; }
   P_LAB_KEYS = M;
   return M;
}
var P_LAB_KEYS = null;
// cortar un viaje: la nave sigue con la velocidad y la rotacion que tenia (§7.7)
function fvLabTake(P) {
   var L = P.lab;
   if (P.flight) { P.events.push({ t: P.t, what: "take-control" }); P.flight = null; P.warp = 0; P.trail = 0; P.flash = 0; }
   P.orbit = null; P.coast = null; P.brake = null; L.hold = null; L.homeSettle = false;
   if (P.mode !== "home" || fvLen(P.cam.pos) > 0) P.mode = "free";
}
function fvLabKey(P, key, down) {
   var act = fvLabKeyMap()[key >>> 0];
   if (!act) return false;
   var L = fvLabState(P);
   if (down) {
      if (act === "fwd" && !L.keys[act]) fvV1Push(P);        // (V1a, V1-02) un empujon NUEVO (no la repeticion de la tecla): si la nave esta parada delante de algo, pasa
      L.keys[act] = true; L.keyT[act] = P.t;
      if (act !== "boost") { if (P.flight && P.flight.kind === "jump") return true; fvLabTake(P); if (!L.drag && L.glide && L.glide.chase) fvLabGlideDrop(P); }   // (R6) una tecla manda sobre el arrastre pendiente (su velocidad angular pasa a la nave: sin salto)
   } else L.keys[act] = false;
   return true;
}
function fvLabHeld(P, act) {
   var L = P.lab; if (!L.keys[act]) return false;
   var lim = (act === "boost") ? FV_PILOT.FREE.BOOST_HOLD_S : FV_PILOT.FREE.KEY_HOLD_S;
   if (P.t - (L.keyT[act] || 0) > lim) { L.keys[act] = false; return false; }
   return true;
}
function fvLabPad(P, dir, down) {
   if (!(dir === "left" || dir === "right" || dir === "up" || dir === "down")) return false;
   var L = fvLabState(P);
   L.keys[dir] = !!down; L.keyT[dir] = P.t + (down ? 1e6 : 0);
   if (down) { fvLabTake(P); if (!L.drag && L.glide && L.glide.chase) fvLabGlideDrop(P); }
   return true;
}
// (v4, R1) la cruceta con el laboratorio: ninguna flecha se apaga (sin la pared A_GUARD de hoy). Lo pide fvPilotPadState
function fvLabPadState(P) {
   var K = (P && P.lab && P.lab.keys) || {};
   return { left: { ok: true, on: !!K.left }, right: { ok: true, on: !!K.right }, up: { ok: true, on: !!K.up }, down: { ok: true, on: !!K.down } };
}
// el centro de la cruceta: frenar = velocidad y giro a cero, suave (objetivo del integrador)
// (17-nov, P35) brakeV0 = la velocidad al pulsar: fvPilotGauges(P).brake (el cubo de la cruceta) vale v / brakeV0 mientras quede > 1 % (FV_LAB.HUB_BRAKE)
function fvLabBrake(P) { var L = fvLabState(P); L.brakeV0 = fvLen((P && P.vel && isFinite(P.vel[0])) ? P.vel : [0, 0, 0]); fvLabTake(P); L.brake = true; fvLabGlideDrop(P); return true; }
// D2 · TELESCOPIO
function fvLabTele(P, on) { var L = fvLabState(P); L.teleOn = (on === undefined) ? !L.teleOn : !!on; FV_LAB.TELE = L.teleOn; L.fovT = null; return L.teleOn; }
function fvLabWheel(P, notches) {
   var L = fvLabState(P);
   if (L.teleOn) { L.tele = fvClamp(L.tele * Math.pow(1.25, notches), 1, FV_LAB.TELE_MAX_K); return true; }
   if (P.flight && P.flight.kind === "jump") return true;
   if (notches > 0) fvV1Push(P);                            // (V1a, V1-02) una muesca hacia delante es un empujon
   fvLabTake(P);
   if (FV_LAB.THROTTLE && FV_LAB.THROTTLE.ON) return fvLabThrottle(P, notches);
   var dA = fvLabAhead(P);
   L.v = fvAdd(L.v, fvMul(fvLabFwdReal(P), notches * FV_LAB.WHEEL_FRAC * dA / FV_PILOT.FREE.DAMP_S));
   return true;
}
// (R1, R2) la rueda como acelerador con consigna: ver FV_LAB.THROTTLE. Reloj de escena (P.t): en vivo y en las pruebas da lo mismo
function fvLabThrottle(P, notches) {
   var L = P.lab, T = FV_LAB.THROTTLE, t = P.t || 0, n = notches, sg = n > 0 ? 1 : -1;
   if (!n) return true;
   if (L.thr === undefined) { L.thr = 0; L.thrT = -1e9; L.thrBucket = T.BURST; L.thrBrakeT = -1e9; L.thrZeroT = -1e9; L.thrAssist = false; }
   // ¿en contra de la marcha? La marcha es la consigna si la hay; si no, la velocidad que aun lleve a lo largo de la mirada
   var along = fvDot(L.v, fvLabFwdReal(P)), dA = fvLabAhead(P), dir = L.thr !== 0 ? (L.thr > 0 ? 1 : -1) : (Math.abs(along) > 0.002 * dA ? (along > 0 ? 1 : -1) : 0);
   if (dir !== 0 && sg !== dir) {
      // R2 · FRENAR: no pasa por el deposito (frenar nunca se raciona)
      // «la segunda en contra» = 1,5 muescas o mas acumuladas en STOP_S (un panel tactil manda fracciones: un roce no para la nave)
      L.thrBrakeAcc = ((t - L.thrBrakeT) < T.STOP_S ? (L.thrBrakeAcc || 0) : 0) + Math.abs(n);
      var twice = L.thrBrakeAcc >= 1.5, cut = Math.max(1, T.BRAKE_FRAC * Math.abs(L.thr)) * Math.abs(n);
      L.thr = (twice || Math.abs(L.thr) - cut < 0.75) ? 0 : dir * (Math.abs(L.thr) - cut);
      L.thrBrakeT = t; L.thrAssist = true; fvLabGlideDrop(P); L.thrT = t;
      if (L.thr === 0) L.thrZeroT = t;
      return true;
   }
   if (dir === 0 && L.thrAssist && (t - L.thrZeroT) < T.DETENT_S) { L.thrBrakeT = t; return true; }      // el TOPE del cero: sigue siendo «frenar»
   if (dir === 0 && (t - L.thrZeroT) < T.DETENT_S) return true;
   // R1 · ACELERAR: la rueda rapida cuenta menos (deposito)
   L.thrBucket = Math.min(T.BURST, L.thrBucket + Math.max(0, t - L.thrT) * T.RATE);
   var take = Math.min(Math.abs(n), L.thrBucket); L.thrBucket -= take; L.thrT = t;
   if (take <= 0) return true;
   L.thr = fvClamp(L.thr + sg * take, -T.NMAX, T.NMAX); L.thrAssist = false; L.brake = false;
   return true;
}
// la velocidad objetivo de la consigna, como fraccion de lo que hay delante por segundo (con signo)
function fvLabThrottleFrac(thr) { var T = FV_LAB.THROTTLE; return (thr < 0 ? -1 : 1) * T.SMAX * (1 - Math.exp(-Math.abs(thr) / T.N0)); }
// D5 · el foco de la orbita (§6.3): seleccion ≤ 20 dA · ultimo destino ≤ 20 dA · estrella en el cono de 10° de la mirada ≤ 0,2 D · nada
function fvLabFocus(P) {
   var c = P.cam, K = FV_LAB.ORBIT, cand = [P.sel, P.arrivedAt];
   for (var q = 0; q < 2; ++q) {
      var s = cand[q]; if (!s || (s.kind !== "star" && s.kind !== "object")) continue;
      var p = fvSelPos(P, s); if (!p) continue;
      var dA = fvArriveDist(P, s), d = fvLen(fvSub(p, c.pos));
      if (d <= K.SEL_K * dA && d > 1e-9) return { p: p, d: d, why: q === 0 ? "sel" : "arrived" };
   }
   if (fvLen(c.pos) < 1e-9) return null;
   var S = P.scene.stars, D = P.scene.nebula ? P.scene.nebula.distLy : 1000, cosC = Math.cos(K.CONE_DEG * FV_DEG), best = null, bc = -2, f = c.B.f, Sx = P.lab.S;
   if (S) for (var i = 0; i < S.n; ++i) {
      var vx = S.x[i] - c.pos[0], vy = S.y[i] - c.pos[1], vz = S.z[i] - c.pos[2], dr = Math.sqrt(vx * vx + vy * vy + vz * vz);
      if (!(dr > 1e-9) || dr > K.NEAR_D * D) continue;
      var fx = Sx * vx, fy = Sx * vy, fl = Math.sqrt(fx * fx + fy * fy + vz * vz), cs = (fx * f[0] + fy * f[1] + vz * f[2]) / fl;
      if (cs >= cosC && cs - 0.002 * dr / D > bc) { bc = cs - 0.002 * dr / D; best = { p: [S.x[i], S.y[i], S.z[i]], d: dr, why: "cone", i: i }; }
   }
   return best;
}
// raton: buttons = 0 al soltar. Izquierdo: orbitar el foco (o mirar sin foco). Derecho: desplazar en linea (encuadrar)
function fvLabMouse(P, dx, dy, buttons) {
   var L = fvLabState(P), c = P.cam;
   if (!buttons) {
      if (!L.drag) return false;
      var dg = L.drag; L.drag = null;
      if (dg.kind === "pan") { L.v = fvAdd(L.v, fvMul(dg.rate || [0, 0, 0], FV_PILOT.FREE.PAN_GLIDE)); }
      else if (L.glide && L.glide.chase) { /* (R6) al soltar sigue recorriendo lo pendiente con los mismos topes: ver fvLabGiroChase */ }
      else L.glide = { kind: dg.kind, rate: dg.rate || [0, 0], focus: dg.focus, t: 0 };
      return true;
   }
   if (P.flight && P.flight.kind === "jump") return true;
   var kind = ((buttons & 2) && !(buttons & 1)) ? "pan" : null;
   if (!L.drag || (kind === "pan") !== (L.drag.kind === "pan")) {
      fvLabTake(P);
      var Gm = fvLabGiroOn(), cg = (Gm && L.glide && L.glide.chase) ? L.glide : null; L.glide = null;
      var fo = kind ? null : fvLabFocus(P);
      L.drag = { kind: kind || (fo ? "orbit" : "look"), focus: fo, rate: kind ? [0, 0, 0] : [0, 0], acc: [0, 0, 0], t: P.t };
      if (Gm) {
         // (R6) sin saltos de velocidad angular: lo que girase la nave (L.w) o el arrastre anterior pasa a ser la velocidad de partida del nuevo
         if (kind) { if (cg) L.w = fvAdd(L.w, fvAdd(fvMul(c.B.d, cg.mw[0]), fvMul(c.B.r, cg.mw[1]))); }
         else {
            L.glide = { kind: L.drag.kind, focus: fo, chase: true, pend: cg ? cg.pend.slice() : [0, 0], mw: cg ? cg.mw.slice() : [fvDot(L.w, c.B.d), fvDot(L.w, c.B.r)], rate: [0, 0], t: 0 };
            L.w = fvMul(c.B.f, fvDot(L.w, c.B.f));      // queda solo el alabeo
         }
      } else L.w = [0, 0, 0];
   }
   var dg2 = L.drag; if (!dx && !dy) return true;
   if ((dg2.kind === "look" || dg2.kind === "orbit") && fvLabGiroOn()) {
      if (!(L.glide && L.glide.chase)) L.glide = { kind: dg2.kind, focus: dg2.focus, chase: true, pend: [0, 0], mw: [0, 0], rate: [0, 0], t: 0 };   // (algo la solto a mitad de arrastre: frenada asistida, viaje)
      // (R6) el arrastre FIJA UN OBJETIVO (angulo pendiente); la camara lo persigue en fvLabGiroChase, con tope de velocidad y de aceleracion
      var gc = L.glide, G6 = FV_LAB.GIRO, kk = (dg2.kind === "look") ? c.fov / P.VW : FV_LAB.ORBIT.DRAG_K / P.VW;
      if (dg2.kind === "look") { gc.pend[0] += -dx * kk; gc.pend[1] += dy * kk; } else { gc.pend[0] += dx * kk; gc.pend[1] += -dy * kk; }
      var pmx = Math.sqrt(gc.pend[0] * gc.pend[0] + gc.pend[1] * gc.pend[1]), pcap = G6.PEND_MAX * FV_DEG;
      if (pmx > pcap) { gc.pend[0] *= pcap / pmx; gc.pend[1] *= pcap / pmx; }
      fvLabMark(P);
      return true;
   }
   if (dg2.kind === "look") {
      var k = c.fov / P.VW, ay = -dx * k, ap = dy * k;
      fvLabLookTurn(P, ay, ap); dg2.acc[0] += ay; dg2.acc[1] += ap;
   } else if (dg2.kind === "orbit") {
      var ko = FV_LAB.ORBIT.DRAG_K / P.VW; fvLabOrbitTurn(P, dg2.focus, dx * ko, -dy * ko); dg2.acc[0] += dx * ko; dg2.acc[1] += -dy * ko;
   } else {
      var dRef = fvLabAhead(P), kp = 2 * dRef * Math.tan(c.fov / 2) / P.VW * FV_LAB.PAN_K;
      var mv = fvLabRelReal(fvAdd(fvMul(c.B.r, -dx * kp), fvMul(c.B.d, -dy * kp)), L.S), Q = fvLabGeo(P), np = fvAdd(c.pos, mv);
      if (fvLabInside(Q, np, FV_LAB.EDGE.OUT)) { c.pos = np; dg2.acc = fvAdd(dg2.acc, mv); }
   }
   if (fvLab4On()) { L.S = fvLabSEff(L, c.B.f); c.S = L.S; }   // (v4, R1)
   fvLabMark(P);
   return true;
}
// (R6) GIROS GRADUALES: ver FV_LAB.GIRO
function fvLabGiroOn() { var G = FV_LAB.GIRO; return !!(G && G.ON); }
// la velocidad angular `cur` persigue la objetivo `des`: constante de tiempo tau (0 = sin ella) y tope de aceleracion aMax (rad/s²)
function fvLabApproach(cur, des, h, aMax, tau) {
   var d = des - cur; if (tau > 0) d *= 1 - Math.exp(-h / tau);
   var cap = aMax * h; return cur + fvClamp(d, -cap, cap);
}
// un subpaso del arrastre: el angulo pendiente (L.glide.pend, rad: guiñada y cabeceo) se recorre con velocidad objetivo = pendiente / MOUSE_TAU,
// tope W_MAX y perfil de frenada sqrt(2·BRAKE_K·A_MAX·pendiente) (frenar a menos de A_MAX: no se pasa), y la velocidad angular real (g.mw, rad/s)
// persigue esa objetivo con tope A_MAX sobre el VECTOR (guiñada y cabeceo juntos: la diagonal no gira mas rapido)
function fvLabGiroChase(P, h) {
   var L = P.lab, g = L.glide, G = FV_LAB.GIRO, W = G.W_MAX * FV_DEG, A = G.A_MAX * FV_DEG, p = g.pend, w = g.mw;
   var pm = Math.sqrt(p[0] * p[0] + p[1] * p[1]), s = 0, wd0 = 0, wd1 = 0;
   if (pm > 1e-12) { s = Math.min(W, pm / G.MOUSE_TAU, Math.sqrt(2 * G.BRAKE_K * A * pm)); wd0 = p[0] * s / pm; wd1 = p[1] * s / pm; }
   var dx = wd0 - w[0], dy = wd1 - w[1], dm = Math.sqrt(dx * dx + dy * dy), cap = A * h;
   if (dm > cap) { dx *= cap / dm; dy *= cap / dm; }
   w[0] += dx; w[1] += dy;
   var s0 = w[0] * h, s1 = w[1] * h;
   if (s0 * p[0] + s1 * p[1] > 0 && s0 * s0 + s1 * s1 > pm * pm) { s0 = p[0]; s1 = p[1]; w[0] = s0 / h; w[1] = s1 / h; }      // no pasarse de lo pendiente
   var fo = g.focus, wm = Math.sqrt(w[0] * w[0] + w[1] * w[1]);
   var done = (pm < G.ENDP_DEG * FV_DEG && wm < 0.01 * FV_DEG && (g.kind !== "orbit" || !fo || ((fo.eLast || 0) < G.ENDP_DEG * FV_DEG && (fo.rc || 0) < 0.01 * FV_DEG)));
   if (done) { s0 = p[0]; s1 = p[1]; w[0] = w[1] = 0; }                                                                    // acabado: se aplica lo que quedaba
   var ok = true;
   if (s0 || s1 || (g.kind === "orbit" && fo && ((fo.eLast || 0) > 1e-9 || (fo.rc || 0) > 0))) ok = (g.kind === "orbit") ? (fo ? fvLabOrbitTurn(P, fo, s0, s1, h) : false) : (fvLabLookTurn(P, s0, s1), true);
   if (!ok) {                                                                                                              // el arco se para en el borde (§6.3): el giro que llevaba pasa a la nave y se apaga con sus topes
      L.w = fvAdd(L.w, fvAdd(fvMul(P.cam.B.d, w[0]), fvMul(P.cam.B.r, w[1]))); p[0] = p[1] = 0; w[0] = w[1] = 0;
   }
   else if (done) p[0] = p[1] = 0;
   else { p[0] -= s0; p[1] -= s1; }
   if (!L.drag && p[0] === 0 && p[1] === 0 && w[0] === 0 && w[1] === 0) L.glide = null;
}
// (R6) soltar el arrastre pendiente (un viaje, el freno, una tecla): su velocidad angular pasa a la nave (L.w) y se apaga con sus propias reglas, sin salto
function fvLabGlideDrop(P) {
   var L = P.lab, g = L.glide; if (!g) return;
   if (g.chase) { var B = P.cam.B; if (B) L.w = fvAdd(L.w, fvAdd(fvMul(B.d, g.mw[0]), fvMul(B.r, g.mw[1]))); }
   L.glide = null;
}
// mirar alrededor (giro directo de la base: guiñada alrededor de su «abajo», cabeceo alrededor de su «derecha»)
function fvLabLookTurn(P, ay, ap) { var c = P.cam; c.B = fvLabOrtho(fvLabRotB(fvLabRotB(c.B, c.B.d, ay), c.B.r, ap)); c.look = c.B.f.slice(); }
// orbitar el foco: el vector foco->nave gira en el espacio de vuelo; su longitud REAL se conserva; la base gira con el y vuelve a mirar al foco
// (R6) con h (el chasquido del arrastre ya con topes) la base NO salta a mirar al foco: se endereza hacia el con RC_DPS / RC_A / RC_TAU (un foco a 90° de la
// mirada era un giro de 90° en un fotograma al empezar a orbitar). Sin h, como antes
function fvLabOrbitTurn(P, fo, ay, ap, h) {
   if (!fo) return false;
   var c = P.cam, S = P.lab.S, rel = fvSub(c.pos, fo.p), dR = fvLen(rel); if (!(dR > 1e-12)) return false;
   var rf = fvLabRelFly(rel, S), B1 = fvLabRotB(fvLabRotB(c.B, c.B.d, ay), c.B.r, ap);
   rf = fvRotate(fvRotate(rf, c.B.d, ay), c.B.r, ap);
   var rr = fvLabRelReal(rf, S), np = fvAdd(fo.p, fvMul(fvNorm(rr), dR)), Q = fvLabGeo(P);
   if (!fvLabInside(Q, np, FV_LAB.EDGE.OUT)) return false;                  // el arco se para en el borde (§6.3)
   c.pos = np;
   var fT = fvNorm(fvLabRelFly(fvSub(fo.p, np), S));
   if (h > 0 && fvLabGiroOn()) {
      var Gx = FV_LAB.GIRO, e = fvAngle(B1.f, fT), RA = Gx.RC_A * FV_DEG; fo.eLast = e;
      if (e > 1e-9) {
         var tg = Math.min(Gx.RC_DPS * FV_DEG, e / Gx.RC_TAU, Math.sqrt(2 * Gx.BRAKE_K * RA * e));
         fo.rc = fvLabApproach(fo.rc || 0, tg, h, RA, 0);
         var st = Math.min(e, fo.rc * h), ax = fvCross(B1.f, fT), al = fvLen(ax);
         if (al > 1e-12 && st > 0) { B1 = fvLabRotB(B1, fvMul(ax, 1 / al), st); fo.eLast = e - st; }
      } else fo.rc = 0;
      c.B = fvLabOrtho(B1);
   } else c.B = fvLabOrtho({ f: fT, r: B1.r, d: B1.d });
   c.look = c.B.f.slice();
   return true;
}

// ---------------------------------------------------------------------------
// EL PILOTO AUTOMATICO: una ley para todos los viajes (§7)
// ---------------------------------------------------------------------------
// el punto K (contenido): donde el rayo Tierra -> destino corta el plano de la losa
// ¿la visual desde p (real) en la direccion de vuelo d corta la losa (z = D) dentro de la piramide? (hay foto detras de lo que se mira)
function fvLabSeesSlab(P, p, d, S) {
   var N = P.scene.nebula; if (!N) return true;
   var dr = fvLabRelReal(d, S), D = N.distLy;
   if (p[2] >= D - 0.5 * N.thickLy) return true;                 // dentro o detras de la losa la prueba no dice nada (K quedaria de lado: K2)
   if (Math.abs(dr[2]) < 1e-12) return false;
   var t = (D - p[2]) / dr[2]; if (!(t > 0)) return false;
   var Q = fvLabGeo(P), x = p[0] + t * dr[0], y = p[1] + t * dr[1];
   return Math.abs(x) <= 1.05 * Q.kx * D && Math.abs(y) <= 1.05 * Q.ky * D;
}
function fvLabK(P, T) { var N = P.scene.nebula; if (!N || !(T[2] > 1e-9)) return T.slice(); return fvMul(T, N.distLy / T[2]); }
// el camino alrededor del destino: radio del destino de r0 a dA (en log) y direccion de u0 a u1 SOLO en la zona cercana (R_FAR..R_NEAR dA)
// (8-nov, tras lab_dbg c5) el arco se traza en el ESPACIO DE VUELO (x, y × S): es donde mira la camara. Trazado en real, 1 a.l. de lado junto a
// la estrella eran S a.l. vistos y la direccion al destino saltaba 55° en medio segundo (el destino salia de cuadro; K8)
function fvLabPathFn(T, p0, A, rFar, rNear, S) {
   S = S || 1;
   if (S !== 1) { var fR = fvLabPathFn(fvLabRelFly(T, S), fvLabRelFly(p0, S), fvLabRelFly(A, S), rFar, rNear, 1); return function(s) { return fvLabRelReal(fR(s), S); }; }
   var rel0 = fvSub(p0, T), r0 = fvLen(rel0), rel1 = fvSub(A, T), r1 = Math.max(1e-12, fvLen(rel1));
   var u0 = r0 > 1e-12 ? fvMul(rel0, 1 / r0) : fvMul(rel1, 1 / r1), u1 = fvMul(rel1, 1 / r1), ang = fvAngle(u0, u1);
   r0 = Math.max(r0, 1e-12);
   function wS(r) { if (ang < 1e-6) return 1; return fvSmoother(Math.log(rFar * r1 / r) / Math.log(rFar / rNear)); }
   var w0 = wS(r0);
   return function(s) {
      var r = Math.exp(fvMix(Math.log(r0), Math.log(r1), s)), w = (w0 < 0.999) ? fvClamp((wS(r) - w0) / (1 - w0), 0, 1) : fvSmoother(s);
      if (s >= 1) w = 1;
      return fvAdd(T, fvMul(fvSlerpDir(u0, u1, w), r));
   };
}
function fvLabStraightFn(p0, A) { return function(s) { return fvLerp(p0, A, s); }; }
// tabla del avance por escala visible: tau = ∫ |dp| / vis (§7.3, como VIS_TAU)
function fvLabPace(P, pathFn, p0, T, Q, S) {
   var n = FV_LAB.NPATH, pts = [], tau = [0], L = 0, i, N = P.scene.nebula, zA = N ? N.distLy - N.thickLy / 2 : 0, zB = N ? N.distLy + N.thickLy / 2 : 0;
   // todo en el espacio de VUELO (lo que ve la camara); z no cambia, asi que la losa se mide igual
   S = S || 1; p0 = fvLabRelFly(p0, S); if (T) T = fvLabRelFly(T, S);
   for (i = 0; i <= n; ++i) pts.push(fvLabRelFly(pathFn(i / n), S));
   for (i = 1; i <= n; ++i) L += fvLen(fvSub(pts[i], pts[i - 1]));
   var floor = Math.max(1e-9, 0.002 * L, T ? 0 : 1e-9), vis0 = Math.max(0.02 * L, Math.min(fvFreeNearest(P).d, 0.2 * L));
   var angs = [0];
   for (i = 1; i <= n; ++i) {
      var pm = fvLerp(pts[i - 1], pts[i], 0.5), v = fvLen(fvSub(pm, p0)) + vis0, dp = fvLen(fvSub(pts[i], pts[i - 1])), dl = dp, ang = 0;
      if (T) {
         v = Math.min(v, fvLen(fvSub(pm, T)));
         // el barrido (lo tangencial alrededor del destino) pesa 1/TANG_K: se recorre despacio y la mirada lo sigue
         var dr = Math.abs(fvLen(fvSub(pts[i], T)) - fvLen(fvSub(pts[i - 1], T))), tg = Math.sqrt(Math.max(0, dp * dp - dr * dr));
         dl = dr + tg / FV_LAB.ARC.TANG_K; ang = tg / Math.max(1e-12, fvLen(fvSub(pm, T)));
      }
      if (N) { var dSl = (pm[2] < zA) ? zA - pm[2] : (pm[2] > zB ? pm[2] - zB : 0); v = Math.min(v, dSl + FV_LAB.SLAB_VIS_K * N.thickLy); }   // la losa se cruza despacio (v2: 1 grosor; con 0,25 el cruce, negro por dentro, era un tercio del viaje BF)
      tau.push(tau[i - 1] + dl / Math.max(floor, v)); angs.push(ang);
   }
   var tot = tau[n] || 1, angK = 0;
   for (i = 0; i <= n; ++i) tau[i] /= tot;
   for (i = 1; i <= n; ++i) if (tau[i] > tau[i - 1]) angK = Math.max(angK, angs[i] / (tau[i] - tau[i - 1]));   // rad de direccion al destino por unidad de tau
   return { n: n, tau: tau, len: L, fn: pathFn, angK: angK };
}
function fvLabSOfTau(pc, x) {
   var t = pc.tau, n = pc.n; if (x <= 0) return 0; if (x >= 1) return 1;
   var lo = 0, hi = n; while (hi - lo > 1) { var m = (lo + hi) >> 1; if (t[m] <= x) lo = m; else hi = m; }
   var a = t[lo], b = t[hi]; return (lo + (b > a ? (x - a) / (b - a) : 0)) / n;
}
// ¿cabe el camino en la piramide de la foto? 32 puntos (§7.2). Con la piramide ESTRICTA (sin la banda minima de junto a casa): fuera del cono
// de la foto el catalogo no tiene estrellas debiles y un arco por fuera se ve negro
function fvLabPathOk(Q, fn) {
   for (var i = 1; i < FV_LAB.ARC.CHECK_N; ++i) { var p = fn(i / FV_LAB.ARC.CHECK_N), z = Math.max(1e-9, p[2]); if (Math.abs(p[0]) > Q.kx * z || Math.abs(p[1]) > Q.ky * z || p[2] < Q.zMin || p[2] > Q.zMax) return false; }
   return true;
}
// el perfil de velocidad del cine (fvCineX: arranque y frenada suaves) y su velocidad relativa (para las estelas del warp)
function fvLabSpeedFrac(u) { return fvSmooth(u / 0.12) * (1 - fvSmooth((u - 0.74) / 0.26)); }

// (21-nov-2026, N-galaxias-warp; FV_GWARP, fv_objects.js) el MODO de un viaje «travel» lo elige el destino (fvTravelKind: fuera de la Via Lactea = warp CORTO con su propio presupuesto, dentro = cine) y la vuelta a casa
// desde una galaxia (fvGwarpHomeFar) es un warp corto con los mismos efectos. P.gwPlan = el presupuesto de fvV1Budget es el del warp corto solo mientras se planea este viaje
function fvLabFly(P, kind, sel) {
   var gw = false, gwHome = false;
   if (kind === "travel") { kind = fvTravelKind(P, sel); gw = (P.gwNow === true); P.gwNow = false; }
   if (kind === "goto") kind = "cine";
   gwHome = (kind === "home") && typeof fvGwarpHomeFar === "function" && fvGwarpHomeFar(P);
   P.gwPlan = !!(gw || gwHome);
   try { return fvLabFlyIn(P, kind, sel, gw, gwHome); } finally { P.gwPlan = false; }
}
function fvLabFlyIn(P, kind, sel, gw, gwHome) {
   var L = fvLabState(P), c = P.cam;
   if (fvLabExternal(P)) fvLabSync(P);
   var Q = fvLabGeo(P), N = P.scene.nebula, T = (kind === "home") ? [0, 0, 0] : (kind === "look" ? null : fvSelPos(P, sel));
   if (kind !== "home" && kind !== "look" && (!T || !(isFinite(T[0]) && isFinite(T[1]) && isFinite(T[2])))) return false;
   P.orbit = null; P.coast = null; P.brake = null; L.drag = null; fvLabGlideDrop(P); L.hold = null; L.homeSettle = false;
   // casa desde dentro o detras de la losa (o desde fuera de la piramide): el salto con fundido, automatico (§7.7). (N-galaxias-warp) desde una galaxia: el warp corto, no el fundido
   if (kind === "home" && N && !gwHome && (c.pos[2] > Q.G.zIn || !fvLabInside(Q, c.pos, 1.0)) && fvLen(c.pos) > 1e-9) {
      fvNmJumpStart(P); P.flight.lab = { jump: true }; L.v = [0, 0, 0]; return true;
   }
   var p0 = c.pos.slice(), v0 = L.v.slice(), spK = fvSpeedDurK(P), sp0 = fvLen(v0);
   var fl = { kind: kind, t: 0, sel: sel || null, p0: p0, look0: c.B.f.slice(), fov0: c.fov, pre: 0, phase: "depart", lab: {} };
   if (gw) fl.gw = true;               // (21-nov, N-galaxias-warp) el warp corto de una galaxia
   if (gwHome) fl.gwHome = true;       // la vuelta a casa desde una galaxia en warp corto (el vuelo sigue siendo «home»; los efectos los da fvIsWarpFl)
   var X = fl.lab;
   if (kind === "look") {
      var dir = sel && sel.dir ? sel.dir : [0, 0, 1];
      X.lookT = fvNorm(dir); fl.T = null; fl.dur = 2.0; fl.fov1 = c.fov; X.pc = null;
   } else {
      // 1. la velocidad que se lleva se frena SUPERPUESTA (§7.6): b(t) con v(t) = v0 (1 − t/tb)², B = v0·tb/3; sobrepaso ≤ 20 % de la distancia
      // (v4, R2) la distancia al destino solo baja: de la velocidad que se lleva se quita lo que se ALEJA del destino (lo de lado se frena superpuesto)
      if (fvLab4On() && kind !== "home" && sp0 > 0) { var uT0 = fvSub(T, p0), lT0 = fvLen(uT0); if (lT0 > 1e-12) { uT0 = fvMul(uT0, 1 / lT0); var aw0 = fvDot(v0, uT0); if (aw0 < 0) { v0 = fvSub(v0, fvMul(uT0, aw0)); sp0 = fvLen(v0); } } }
      var dist0 = fvLen(fvSub(T, p0)), tb = FV_LAB.BRAKE_S * spK, Bv = fvMul(v0, tb / 3);
      if (fvLen(Bv) > FV_LAB.BRAKE_MAX_FRAC * dist0 && sp0 > 0) { tb = 3 * FV_LAB.BRAKE_MAX_FRAC * dist0 / sp0; Bv = fvMul(v0, tb / 3); }
      if (!(sp0 > 1e-12)) { tb = 0; Bv = [0, 0, 0]; }
      X.v0 = v0; X.tb = tb; X.Bv = Bv;
      var pS = fvAdd(p0, Bv);
      if (fvLab4On() && kind !== "home") fvLab4Plan(P, fl, X, kind, sel, T, pS, Q, spK, dist0);   // (v4) viaje casi recto con el destino en pantalla
      else {
         var A, dA = 0, Tl = T;
         if (kind === "home") { A = [0, 0, 0]; X.pc = fvLabPace(P, fvLabStraightFn(pS, A), pS, null, Q, L.S0 || L.S); X.lookT = null; }
         else {
            dA = fvArriveDist(P, sel); if (typeof fvBoxArrive === "function") dA = fvBoxArrive(P, sel, T, dA); Tl = fvSelLookAt(P, sel, T) || T;
            var uE = fvNorm(T), behind = N && T[2] > Q.G.zOut, fromHere = fvSub(T, pS);
            // 2. el punto de llegada (§7.4.1): con D7, en la recta destino–K (la losa detras del destino); sin D7, viniendo de donde se esta.
            //    (v2) En el warp no hay arco: en 6 s el barrido iba mas rapido que el giro y el destino salia de cuadro (K2 warp HB/FB)
            X.d7 = !!(FV_LAB.D7 && N && T[2] > 1e-9 && kind !== "warp");
            if (X.d7) A = behind ? fvAdd(T, fvMul(uE, dA)) : fvSub(T, fvMul(uE, dA));
            else A = (fvLen(fromHere) > 1e-9) ? fvSub(T, fvMul(fvNorm(fromHere), dA)) : fvSub(T, fvMul(uE, dA));
            A = fvLabClampIn(Q, A, FV_LAB.EDGE.OUT);
            // (v2, defecto 4) el barrido pasa de lado a >= dA REAL de la estrella: en vuelo eso son S·dA (antes cruzaba a 0,4–0,8 a.l. y el brillo, con la distancia real, se disparaba)
            var rN = Math.max(FV_LAB.ARC.R_NEAR, 1.2 * L.S), rF = Math.max(FV_LAB.ARC.R_FAR, 2 * rN), fn = null;   // zona del barrido rN..2 rN (con 10/3 x rN el barrido ocupaba casi todo el viaje y se volaba de lado)
            for (var tr = 0; tr < 3 && !fn; ++tr) { var f2 = fvLabPathFn(T, pS, A, rF, rN, L.S); if (fvLabPathOk(Q, f2)) { fn = f2; X.rFar = rF; } else { rF *= 0.5; rN = Math.max(1.5, rN * 0.7); } }
            if (!fn) { var Ad = (fvLen(fromHere) > 1e-9) ? fvSub(T, fvMul(fvNorm(fromHere), dA)) : A; A = fvLabClampIn(Q, Ad, FV_LAB.EDGE.OUT); fn = fvLabPathFn(T, pS, A, FV_LAB.ARC.R_FAR, FV_LAB.ARC.R_NEAR, L.S); X.arcFallback = true; }
            X.pc = fvLabPace(P, fn, pS, T, Q, L.S);
            X.K = fvLabK(P, Tl); X.lookOnK = false; X.blend = null;
         }
         X.A = A; X.dA = dA; X.Tl = Tl; X.pS = pS;
         // el giro previo: si la nave mira a mas de 60° de hacia donde va a salir, primero gira (sin avanzar; la frenada superpuesta sigue). Asi no
         // sale volando de espaldas (K9)
         var p1s = X.pc.fn(0.02), dirOut = fvLen(fvSub(p1s, pS)) > 1e-12 ? fvNorm(fvLabRelFly(fvSub(p1s, pS), L.S)) : c.B.f, tcP = FV_LAB.TURN[kind] || FV_LAB.TURN.cine;
         var a0 = fvAngle(c.B.f, dirOut) / FV_DEG; X.pre = (a0 > 60) ? (a0 - 45) / tcP[0] + tcP[0] / tcP[1] : 0; X.dirOut = dirOut;
         // (v2) con el destino hacia la Tierra (travelling hacia atras, LOOK.DOLLY) no hay giro previo: girar hacia la salida era mirar al negro
         if (FV_LAB.LOOK.DOLLY && N) { var dT0 = fvNorm(fvLabRelFly(fvSub(Tl, pS), L.S)), K0 = fvLabK(P, Tl), dK0 = fvNorm(fvLabRelFly(fvSub(K0, pS), L.S)); if (dT0[2] < 0 && fvAngle(dT0, dK0) / FV_DEG > FV_LAB.LOOK.DOLLY_IN) X.pre = 0; }
         if (fvLabContentOn()) X.pre = 0;                                   // (v3) con la mirada al contenido no hay giro previo: se mira al contenido desde ya
         fl.T = T; fl.Tlook = Tl; fl.p1 = A.slice();
         // 3. la duracion (§7.3): la de hoy en cine (14 + 7 s por decada, × FAST.DUR_K × regulador); el warp comprimido
         var dec = Math.max(0, Math.log(Math.max(1, dist0 / Math.max(1e-9, dA || 0.01 * dist0))) / Math.LN10), dur;
         if (kind === "warp") dur = fvLabWarpDur(dec) * spK;                                              // (W1) la duracion del warp, en un sitio (fvLabWarpDur)
         else dur = fvClamp(FV_PILOT.CINE_S_MIN + FV_PILOT.CINE_S_DEC * dec, FV_PILOT.CINE_S_MIN, FV_PILOT.CINE_S_MAX) * ((FV_PILOT.FAST && FV_PILOT.FAST.DUR_K) || 0.6) * spK;
         if (dist0 < 0.5 * Math.max(dA, 1e-9) && kind !== "home") dur = 3.0;                                      // ya esta alli: solo girar
         var dur0 = dur;
         // (20-nov, V1b; FV_V1.CURVE) casa: el presupuesto de la palanca (sin media vuelta ni asentamiento: acaba al llegar la duracion)
         var v1h = (kind === "home" && (fvV1On("CURVE") || gwHome)) ? fvV1HomeDur(P, dec) : 0;
         if (v1h > 0) { dur = v1h; dur0 = v1h; }
         // el giro que hace falta cabe en el viaje (si no, se alarga hasta el tope de 45 s × 0,6 × regulador)
         var lookEnd = (kind === "home") ? [0, 0, 1] : fvNorm(fvLabRelFly(fvSub(Tl, A), L.S)), tc = FV_LAB.TURN[kind] || FV_LAB.TURN.cine;
         var tNeed = fvAngle(c.B.f, lookEnd) / (tc[0] * FV_DEG) + tc[0] / tc[1] + 1.0;
         dur = Math.max(dur, Math.min(tNeed, v1h > 0 ? v1h : 45 * 0.6 * spK));
         // el barrido del arco a <= RATE_FRAC del tope de giro (la mirada lo sigue sin perder el destino); tope: 1,6 x la duracion de antes
         if (X.pc && X.pc.angK > 0 && kind !== "home") { var tArc = FV_LAB.ARC.PROFILE_K * X.pc.angK / (FV_LAB.ARC.RATE_FRAC * tc[0] * FV_DEG); dur = Math.max(dur, Math.min(tArc, FV_LAB.ARC.DUR_MAX_K * dur)); }
         // (v3, 6) tope de la duracion entera: 1,15 x la base (giro previo incluido; si no cabe, el giro previo se recorta antes que el viaje)
         var capT = FV_LAB.DUR_CAP_K * dur0; if (kind !== "home" && dur + (X.pre || 0) > capT) { X.pre = Math.max(0, Math.min(X.pre || 0, capT - dur)); dur = Math.max(dur0, capT - X.pre); }
         X.durMove = dur; dur += X.pre || 0;
         // (N-galaxias-warp) la vuelta a casa en warp corto: la carga (PREP) con la nave quieta, el salto y la salida de W1 acortados por el presupuesto (X.bud: FV_W1.SCALE_ON), sin el giro previo dentro de la carga
         if (gwHome) { X.prepS = FV_LAB.WARP.PREP * X.durMove; X.bud = { gw: true, Tb: fvV1Budget(P, "warp") }; fl.warpPhase = "prep"; fl.phaseT = 0; fl.phaseDur = 0.1 * dur; fl.cruise = 0.62 * dur; }
         fl.dur = dur; fl.fov1 = (kind === "home") ? P.homeFov : FV_LAB.LENS_DEG * FV_DEG;
         X.lookEnd = lookEnd;
         if (kind === "warp") { fl.cruise = 0.62 * dur; fl.warpPhase = "prep"; fl.phaseT = 0; fl.phaseDur = 0.1 * dur; fl.kPh = 1; }
         if (kind === "home") X.fovH0 = c.fov;
      }
   }
   P.flight = fl; P.mode = "flight"; P.sunMark = false;
   if (kind !== "look") P.arrivedAt = null;
   if (P.free) fvFreeHalt(P);
   P.events.push({ t: P.t, what: "fly-" + kind });
   fvLabNavMode(P, Q);
   return true;
}
// fvPilotFlyPath con el laboratorio: las llaves del editor como tramos de la misma ley (objetivos de posicion, mirada y campo)
function fvLabFlyPath(P, keys, opts) {
   if (!keys || keys.length < 1) return false;
   var L = fvLabState(P); if (fvLabExternal(P)) fvLabSync(P);
   opts = opts || {};
   var legs = [], prev = P.cam.pos.slice(), spK = fvSpeedDurK(P), Tt = 0;
   for (var i = 0; i < keys.length; ++i) {
      var k = keys[i], d = fvLen(fvSub(k.pos, prev)), ref = Math.max(1e-6, Math.min(fvLen(k.pos), fvLen(prev)) * 0.05 + 1e-3);
      var dur = (opts.durS > 0) ? opts.durS / keys.length : fvClamp(4 + 2.5 * Math.log(1 + d / ref) / Math.LN10, 3, 20) * 0.7 * spK;
      legs.push({ p0: prev, p1: k.pos.slice(), look: fvNorm(fvLabRelFly(fvNorm(k.look), L.S)), fov: k.fov, dur: dur, hold: k.holdS || 0, t0: Tt });
      Tt += dur + (k.holdS || 0); prev = k.pos.slice();
   }
   P.flight = { kind: "path", t: 0, dur: Tt, sel: null, T: keys[keys.length - 1].pos.slice(), keyIdx: 0, nKeys: keys.length, phase: "depart", pre: 0, lab: { legs: legs, path: true }, fov1: keys[keys.length - 1].fov };
   P.mode = "flight"; P.orbit = null; P.coast = null; P.arrivedAt = null; L.v = [0, 0, 0]; L.hold = null;
   P.events.push({ t: P.t, what: "fly-path" });
   return true;
}

// ---------------------------------------------------------------------------
// (v4, 9-nov-2026) EL VIAJE v4: casi recto, el destino siempre en pantalla, llegada parada y derecha (R2, R3, R4, R5 del encargo A)
// ---------------------------------------------------------------------------
// medio angulo (rad) del recuadro central: el lado corto de la pantalla manda
function fvLab4HalfIn(P, k) { var tH = Math.tan(P.cam.fov / 2) * Math.min(1, P.VH / Math.max(1, P.VW)); return Math.atan((k || FV_LAB.V4.MARGIN) * tH); }
// donde cae la direccion de vuelo d en la pantalla, en unidades de tan (el semiancho de la pantalla es tan(campo / 2))
function fvLab4Scr(B, d) { var z = fvDot(d, B.f); return { z: z, x: fvDot(d, B.r) / Math.max(1e-12, z), y: fvDot(d, B.d) / Math.max(1e-12, z) }; }
function fvLab4InBox(P, d, k) {
   var q = fvLab4Scr(P.cam.B, d), tx = Math.tan(P.cam.fov / 2), ty = tx * P.VH / Math.max(1, P.VW); k = k || FV_LAB.V4.MARGIN;
   return q.z > 1e-6 && Math.abs(q.x) <= k * tx && Math.abs(q.y) <= k * ty;
}
// ¿la distancia REAL al destino solo baja por el camino (64 puntos) y el camino cabe en la caja de vuelo (OUT)?
function fvLab4PathOk(Q, fn, T) {
   var n = 64, dPrev = fvLen(fvSub(fn(0), T));
   for (var i = 1; i <= n; ++i) { var p = fn(i / n), d = fvLen(fvSub(p, T)); if (d > dPrev * (1 + 1e-9) + 1e-12 || !fvLabInside(Q, p, FV_LAB.EDGE.OUT)) return false; dPrev = d; }
   return true;
}
// (17-nov, P33, FV_BOX.BOW) lo mas fuera de las paredes laterales de la caja 3D que llega el camino (64 puntos, a.l.; positivo = fuera)
function fvLab4BoxMax(scene, fn) {
   var m = -1e30, i, v;
   for (i = 1; i <= 64; ++i) { v = fvBoxLat(scene, fn(i / 64)); if (v > m) m = v; }
   return m;
}
// el avance por escala visible (como fvLabPace, en el espacio de vuelo) SIN frenar por la estrella de salida, que queda detras (N7: la v3 apenas
// avanzaba los primeros ~7 s): escala de salida = lo recorrido + VIS0_K x la longitud; de llegada, la distancia al destino; la losa, despacio
function fvLab4Pace(P, pathFn, p0, T, S, slabK, nOv, ramp) {      // slabK (V1c, DWELL): la constante del cruce de la losa de este viaje; sin ella FV_LAB.SLAB_VIS_K. nOv: muestras del camino (DWELL: mas finas que la losa)
   var n = nOv > 0 ? nOv : FV_LAB.NPATH, pts = [], tau = [0], Lt = 0, i, N = P.scene.nebula, zA = N ? N.distLy - N.thickLy / 2 : 0, zB = N ? N.distLy + N.thickLy / 2 : 0;
   S = S || 1; var p0f = fvLabRelFly(p0, S), Tf = fvLabRelFly(T, S);
   for (i = 0; i <= n; ++i) pts.push(fvLabRelFly(pathFn(i / n), S));
   for (i = 1; i <= n; ++i) Lt += fvLen(fvSub(pts[i], pts[i - 1]));
   var floor = Math.max(1e-9, 0.002 * Lt), floorU = (slabK > 0 && N) ? Math.min(floor, 0.2 * slabK * N.thickLy) : floor, vis0 = FV_LAB.V4.VIS0_K * Lt, tailK = fvV1On("TAIL") ? FV_V1.TAIL_K * Lt : 0;      // (V1c, TAIL) suelo de la marcha: el ultimo tramo no es asintotico
   for (i = 1; i <= n; ++i) {
      var pm = fvLerp(pts[i - 1], pts[i], 0.5), dl = fvLen(fvSub(pts[i], pts[i - 1])), v = Math.min(fvLen(fvSub(pm, p0f)) + vis0, fvLen(fvSub(pm, Tf)));
      if (tailK > 0) v = Math.max(v, tailK);
      if (N) { var dSl = (pm[2] < zA) ? zA - pm[2] : (pm[2] > zB ? pm[2] - zB : 0); v = Math.min(v, (ramp > 0 ? ramp : 1) * dSl + (slabK > 0 ? slabK : FV_LAB.SLAB_VIS_K) * N.thickLy); }      // ramp (V1c, DWELL): la frenada al acercarse a la losa, mas larga que la de siempre (v <= ramp x distancia)
      tau.push(tau[i - 1] + dl / Math.max(floorU, v));
   }
   var tot = tau[n] || 1; for (i = 0; i <= n; ++i) tau[i] /= tot;
   return { n: n, tau: tau, len: Lt, fn: pathFn, angK: 0 };
}
// (17-nov, F34) el desplazamiento lateral REAL d (horizontal, a la derecha de la linea de vision A -> Tl) con el que, desde A + d mirando a Tl + d, el destino cae a fx · medio campo a la izquierda del centro de la pantalla.
// En espacio de vuelo (x, y por S) el desvio es fx · tan(lente/2) · distancia de vuelo; S0 = el S con que se llegara (el de la pantalla; con la lente ancha puede ser menor al llegar mirando de lado: el objeto cae algo menos a la izquierda, no mas)
function fvLab34Shift(S0, A, Tl, fx) {
   var v = fvLabRelFly(fvSub(Tl, A), S0), dist = fvLen(v); if (!(dist > 1e-12)) return [0, 0, 0];
   var r = fvLabLevel(fvMul(v, 1 / dist), null).r;
   return fvLabRelReal(fvMul(r, fx * Math.tan(FV_LAB.LENS_DEG * FV_DEG / 2) * dist), S0);
}
// (19-nov-2026, N8b; docs/encargos-19nov/N8b.md) EL GIRO DE MIRADA COMPLETA EL DESPLAZAMIENTO QUE LAS PAREDES RECORTAN. F34 aparta el protagonista de la ficha desplazando la nave de lado (A + d) y mirando a Tl + d; las paredes
//   de la caja (FV_BOX.WALLS, decision de Nino) reducen d a la mitad hasta 6 veces (Caldwell 5: d 27,8 de 55,5 a.l., 14 px entre la galaxia y la ficha en el Tour). Con ON, lo que las paredes recortan (dFull − d usado) se completa
//   GIRANDO LA MIRADA: la nave llega donde F34 la deja y MIRA a Tl + dFull (el objeto cae a 0,296 del ancho como si se hubiera desplazado todo: el angulo objeto-eje es dFull / distancia, venga de donde venga). Si F34 cabe entera
//   (sin recorte) NO hay giro: la llegada es la de F34 (bit a bit). GUARD: F34 refuto el giro como solucion general (Tulipan: una esquina de la foto pasaba a quedar detras de la nave, photoQuad daba null, la cobertura 0 y el
//   ancla del laboratorio encendia «YOUR PHOTO / TARGET»): el giro se reduce (1, 1/2, 1/4, 1/8, 0 del recorte) hasta que las cuatro esquinas de la foto sigan por delante de la camara (el mismo criterio que photoQuad), con
//   un margen MIN_DEPTH (coseno del angulo; 0,02 = 88,9°) por la inclinacion del plano que aqui no se calcula. MODE «residual» = lo dicho; «all» = no se desplaza de lado: todo el giro (medido, no activado).
//   ON = false: exactamente lo de antes (bit a bit). Se usa tambien en el visor web (el motor es el mismo fichero).
var FV_N8B = { ON: true, MODE: "residual", GUARD: true, MIN_DEPTH: 0.02, FRACS: [1, 0.5, 0.25, 0.125, 0] };
// ¿las cuatro esquinas de la foto (la capa 0 llevada a la distancia de la nebulosa, como photoQuad) quedan por delante de la camara en A mirando a look? Espacio de vuelo (S0 estira lo lateral)
function fvN8bPhotoAhead(scene, A, look, S0) {
   var N = scene ? scene.nebula : null; if (!N || !N.layers || !N.layers.length || !(N.distLy > 0)) return true;      // sin foto no hay ancla que se encienda
   var L0 = N.layers[0], d0 = N.distLy, x0 = L0.x0 / L0.z * d0, x1 = L0.x1 / L0.z * d0, y0 = L0.y0 / L0.z * d0, y1 = L0.y1 / L0.z * d0, f = fvNorm(fvLabRelFly(fvSub(look, A), S0)), cs = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]];
   for (var i = 0; i < 4; ++i) { var v = fvLabRelFly(fvSub([cs[i][0], cs[i][1], d0], A), S0), l = fvLen(v); if (!(l > 1e-12) || fvDot(v, f) <= FV_N8B.MIN_DEPTH * l) return false; }
   return true;
}
// el punto que se mira = Tl + look: lo que se desplazo la nave (d34) mas la parte del recorte (dFull − d34) que el giro puede completar sin sacar las esquinas de la foto de delante (GUARD). A = donde llega la nave (ya con d34)
function fvN8bLook(scene, A, Tl, d34, dFull, S0) {
   var dRes = fvSub(dFull, d34), fr = FV_N8B.FRACS, fi = 0, frac;
   if (FV_N8B.GUARD) { for (fi = 0; fi < fr.length - 1; ++fi) if (fvN8bPhotoAhead(scene, A, fvAdd(Tl, fvAdd(d34, fvMul(dRes, fr[fi]))), S0)) break; frac = fr[fi]; } else frac = 1;
   var look = fvAdd(d34, fvMul(dRes, frac));
   return { look: look, gz: { mode: FV_N8B.MODE, frac: frac, dRes: fvLen(dRes), deg: fvAngle(fvLabRelFly(fvSub(Tl, A), S0), fvLabRelFly(fvSub(fvAdd(Tl, look), A), S0)) / FV_DEG } };
}
// la llegada desplazada de F34 con las paredes de la caja y (N8b) el giro que completa lo que recortan -> { A: donde llega la nave, Tl: el punto que mira, d34: lo que se desplazo la nave, cut: mitades por las paredes (-1 = MODE «all»), gz: el giro o null }
function fvLab34Arrive(scene, S0, A, Tl, fx34, gaze34) {
   // el desvio no puede sacar la llegada de las paredes de la caja (fvBoxLat, la misma cuenta que FV_BOX.WALLS / BOW): si la deja mas fuera que estaba, se reduce a la mitad hasta que no (o a 0)
   var d34 = fvLab34Shift(S0, A, Tl, fx34), cut34 = 0, lat0 = (typeof fvBoxLat === "function" && FV_BOX.ON) ? Math.max(0, fvBoxLat(scene, A)) : -1, dFull = d34, gz = null;
   var n8b = (!gaze34 && typeof FV_N8B !== "undefined" && FV_N8B.ON);      // (19-nov, N8b) el recorte de las paredes se completa con el giro de la mirada
   if (!gaze34) {
      if (n8b && FV_N8B.MODE === "all") { d34 = [0, 0, 0]; cut34 = -1; }     // (medido, no activado) todo el giro, nada de desplazamiento
      else {
         while (lat0 >= 0 && cut34 < 6 && fvBoxLat(scene, fvAdd(A, d34)) > lat0 + 1e-9) { d34 = fvMul(d34, 0.5); ++cut34; }
         if (lat0 >= 0 && cut34 >= 6) d34 = [0, 0, 0];
      }
      A = fvAdd(A, d34);
   }
   var look34 = d34;                                                       // lo que se suma al punto que se mira (F34: lo mismo que se desplazo la nave)
   if (n8b && cut34 !== 0) { var g8 = fvN8bLook(scene, A, Tl, d34, dFull, S0); look34 = g8.look; gz = g8.gz; }
   return { A: A, Tl: fvAdd(Tl, look34), d34: d34, cut: cut34, gz: gz };
}
// el plan: llegada del lado por donde se viene (A = T − u·dA, u = hacia el destino), recta con comba suave hacia el centro de la losa (vista),
// duracion de hoy, giro previo hasta tener el destino en el recuadro
function fvLab4Plan(P, fl, X, kind, sel, T, pS, Q, spK, dist0) {
   var L = P.lab, c = P.cam, V = FV_LAB.V4, N = P.scene.nebula, S0 = L.S0 || L.S;
   var dA = fvArriveDist(P, sel), Tl = fvSelLookAt(P, sel, T) || T;
   if (typeof fvBoxArrive === "function") dA = fvBoxArrive(P, sel, T, dA);       // (14-nov, A) destino mas alla de la boca: se llega a la boca
   var u0 = fvSub(T, pS), l0 = fvLen(u0); u0 = (l0 > 1e-12) ? fvMul(u0, 1 / l0) : fvNorm(T);
   var A = (l0 > dA) ? fvSub(T, fvMul(u0, dA)) : pS.slice();           // ya a la distancia de llegada: no se acerca mas (solo gira)
   // (17-nov, F34; FV_F34.FIT) el protagonista se encuadra en el centro de la zona que la ficha no tapa: la nave llega DESPLAZADA a un lado (A + d) y mira a un punto desplazado lo mismo (Tl + d), asi la mirada
   // es paralela a la de antes y el objeto cae a la izquierda del centro (a fx · medio campo); la foto sigue por delante (la profundidad es la misma: con un giro de la mirada, las esquinas de la foto de
   // un lado pasaban a quedar detras de la nave y el ancla del laboratorio, que no ve la foto, encendia «YOUR PHOTO / TARGET» en Tulip). A lo lejos el desvio angular es pequeno y crece al acercarse: entra durante la frenada.
   // Sin fx (o ya en el sitio) nada cambia: lo de antes.
   var fx34 = (sel && sel.kind === "object" && P.scene.objects) ? fvF34Aim(P.scene, P.scene.objects[sel.i], P.VW) : 0;
   // (19-nov, N2b) gaze34 = la nebulosa «whole» (o la lamina entera) se encuadra GIRANDO LA MIRADA unos grados (la nave no se mueve: las paredes de la caja no dejan desplazarla de lado cerca de casa: Soul 5,6 a.l. de 94
   // que hacen falta, «halved 6x»). A 5 000 a.l. de una lamina que lo llena todo el giro es de ~1° y toda la foto sigue por delante (sin las esquinas detras de la nave que encendian el ancla en F34 con Tulip)
   var gaze34 = !!(fx34 > 0 && sel && sel.kind === "object" && P.scene.objects && P.scene.objects[sel.i] && P.scene.objects[sel.i].frame && P.scene.objects[sel.i].frame.whole);
   // (19-nov, N6; FV_N6.DIST) la seleccion «nebula» (Tour sin protagonista, clic, ruta, MIRABILIA sin objetos) apunta a la fila principal (fvSelPos): se encuadra igual que ella, junto a la ficha
   if (sel && sel.kind === "nebula" && typeof fvN6Main === "function" && typeof FV_N6 !== "undefined" && FV_N6.DIST) { var mN6 = fvN6Main(P.scene); if (mN6 >= 0) { fx34 = fvF34Aim(P.scene, P.scene.objects[mN6], P.VW); gaze34 = !!(fx34 > 0 && P.scene.objects[mN6].frame && P.scene.objects[mN6].frame.whole); }
      // (19-nov, N2b; FV_N2B.WHOLE) sin fila principal con contorno la nebulosa es la lamina entera (fvN6WholeDist): tambien se encuadra entera junto a la ficha (fvN2bShift), girando la mirada
      else if (typeof fvN2bShift === "function" && !FV_OBJ_FITTING) { fx34 = fvN2bShift(P.scene); gaze34 = fx34 > 0; } }
   if (fx34 > 0 && l0 > dA) {
      var a34 = fvLab34Arrive(P.scene, S0, A, Tl, fx34, gaze34); A = a34.A; Tl = a34.Tl; var d34 = a34.d34, cut34 = a34.cut, gz = a34.gz; X.f34 = { fx: fx34, d: fvLen(d34), cut: cut34, S0: S0, gaze: gaze34, gz: gz };
      if (!FV_OBJ_FITTING && typeof fvLog === "function") fvLog("F34 arrival offset: fx " + fx34.toFixed(4) + " · " + (gaze34 ? "gaze turned by a shift of " : "shift ") + fvLen(d34).toFixed(3) + " ly · halved " + cut34 + "x (the box walls)" + (gz ? " · N8b gaze " + gz.deg.toFixed(2) + " deg (" + gz.frac + " of " + gz.dRes.toFixed(2) + " ly)" : ""));
   }
   var pSf = fvLabRelFly(pS, S0), Af = fvLabRelFly(A, S0), Lf = fvLen(fvSub(Af, pSf)), h = V.BOW_K * Lf, nB = null;
   if (Lf > 1e-9) {
      var dF = fvMul(fvSub(Af, pSf), 1 / Lf), ref = fvSub(fvLabRelFly([0, 0, N ? N.distLy : Math.max(1e-9, fvLen(T))], S0), fvLerp(pSf, Af, 0.5));
      ref = fvSub(ref, fvMul(dF, fvDot(ref, dF)));
      if (fvLen(ref) < 1e-6 * Lf) ref = fvSub([0, -1, 0], fvMul(dF, fvDot([0, -1, 0], dF)));
      nB = (fvLen(ref) > 1e-9) ? fvNorm(ref) : null;
   }
   var mk = function(hh) { return function(s) { var p = fvLerp(pS, A, s); if (nB && hh > 0) p = fvAdd(p, fvLabRelReal(fvMul(nB, 16 * s * s * (1 - s) * (1 - s) * hh), S0)); return p; }; };
   // (9-nov, refutado) una espiral que gira 45–90° hacia el lado que deja la nebulosa detras del destino (distancia aun monotona) NO quita el
   // negro de los viajes delante -> delante / detras -> delante (IC 1848, K = 4: FF 76 -> 77 %, BF 100 -> 100 % en los dos ultimos tercios):
   // mirando al destino se ve el vacio que hay detras de el; haria falta media vuelta. Retirada (no dejar opciones muertas)
   var fn = null;
   // (17-nov, P33) con FV_BOX.BOW la comba tiene que caber tambien en las paredes de la caja (fvLab4BoxMax): si no, se reduce a la mitad hasta que quepa (FV_BOX.BOW false = lo de antes)
   var bxB = (typeof FV_BOX !== "undefined" && FV_BOX.ON && FV_BOX.BOW && typeof fvBoxLat === "function"), bxLim = bxB ? Math.max(0, fvBoxLat(P.scene, pS)) : 0;
   // (solo medida) FV_BOX.BOW_LOG = [] apunta los intentos de comba que se salen de las paredes, con la bandera apagada tambien (no cambia ninguna decision)
   var bxLog = (typeof FV_BOX !== "undefined" && FV_BOX.BOW_LOG && typeof fvBoxLat === "function");
   for (var tr = 0; tr < 7 && !fn && h > 0; ++tr) {
      var f2 = mk(h), okP = fvLab4PathOk(Q, f2, T), mxB = (bxB || bxLog) ? fvLab4BoxMax(P.scene, f2) : -1e30;
      if (bxLog && mxB > Math.max(0, fvBoxLat(P.scene, pS)) + 1e-9) FV_BOX.BOW_LOG.push({ tr: tr, h: h, mx: mxB, lim: Math.max(0, fvBoxLat(P.scene, pS)), okP: okP, latS: fvBoxLat(P.scene, pS), latT: fvBoxLat(P.scene, T), zS: pS[2], zT: T[2], Lf: Lf, tb: X.tb, bv: fvLen(X.Bv), p0: c.pos.slice(), pS: pS.slice() });
      if (okP && (!bxB || mxB <= bxLim + 1e-9)) fn = f2; else h *= 0.5;
   }
   if (!fn) { h = 0; fn = mk(0); }
   X.v4 = true; X.bow = h; X.bowLen = Lf; X.d7 = false; X.A = A; X.dA = dA; X.Tl = Tl; X.pS = pS; X.K = fvLabK(P, Tl);
   X.pc = fvLab4Pace(P, fn, pS, T, S0);
   var dec = Math.max(0, Math.log(Math.max(1, dist0 / Math.max(1e-9, dA || 0.01 * dist0))) / Math.LN10), dur;
   if (kind === "warp") dur = fvLabWarpDur(dec) * spK;                                                  // (W1) la duracion del warp, en un sitio (fvLabWarpDur)
   else dur = fvClamp(FV_PILOT.CINE_S_MIN + FV_PILOT.CINE_S_DEC * dec, FV_PILOT.CINE_S_MIN, FV_PILOT.CINE_S_MAX) * ((FV_PILOT.FAST && FV_PILOT.FAST.DUR_K) || 0.6) * spK;
   if (dist0 < 0.5 * Math.max(dA, 1e-9)) dur = 3.0;
   var tc = FV_LAB.TURN[kind] || FV_LAB.TURN.cine, dT0 = fvLabDirFly(P, Tl), a0 = fvAngle(c.B.f, dT0), aIn = fvLab4HalfIn(P, V.MARGIN_IN);
   X.inBox = fvLab4InBox(P, dT0, V.MARGIN_IN);
   var pre0 = X.inBox ? 0 : Math.max(0, a0 - aIn) / (tc[0] * FV_DEG) + tc[0] / tc[1] + 0.3;   // el giro previo a la velocidad de siempre (K4: < 30 °/s en cine)
   // (20-nov, V1b/V1-06; FV_V1.CURVE) el presupuesto de tiempo TOTAL de la palanca reparte giro previo, camino, media vuelta y asentamiento (fvV1Plan); sin la bandera, lo de antes
   var v1c = fvV1On("CURVE") ? fvV1Plan(P, X, kind, dec, X.inBox ? -1 : Math.max(0, a0 - aIn), tc, T, A, dist0 < 0.5 * Math.max(dA, 1e-9)) : null;
   if (v1c) { dur = v1c.dur; pre0 = v1c.pre0; }
   X.prepS = (kind === "warp") ? FV_LAB.WARP.PREP * dur : 0;                  // en el warp la nave ya esta quieta la preparacion: el giro previo cabe en ella
   X.pre = Math.max(0, pre0 - X.prepS);
   // como la v3 (DUR_CAP_K): giro previo + camino <= 1,15 x la duracion de hoy; lo que sobra se quita del CAMINO (no del giro: sin giro el destino
   // no estaria en pantalla), con suelo MOVE_MIN_K x la duracion de hoy
   var capT = FV_LAB.DUR_CAP_K * dur;
   if (!v1c && X.pre > 0 && dur + X.pre > capT) { dur = Math.max(V.MOVE_MIN_K * dur, capT - X.pre); X.prepS = (kind === "warp") ? FV_LAB.WARP.PREP * dur : 0; X.pre = Math.max(0, pre0 - X.prepS); }
   X.preExt = 0; X.dirOut = dT0; X.lookEnd = fvNorm(fvLabRelFly(fvSub(Tl, A), L.S)); X.bias = [0, 0, 0]; X.leashN = 0; X.dPrev = fvLen(fvSub(c.pos, T)); X.settle = 0;
   X.durMove = dur; fl.dur = dur + X.pre; fl.T = T; fl.Tlook = Tl; fl.p1 = A.slice(); fl.fov1 = FV_LAB.LENS_DEG * FV_DEG;
   if (kind === "warp") { fl.cruise = 0.62 * fl.dur; fl.warpPhase = "prep"; fl.phaseT = 0; fl.phaseDur = 0.1 * fl.dur; fl.kPh = 1; }
   // (v5) reloj propio del camino en cine (CREEP / FAST); X.pre pasa a ser el giro previo REAL (se apunta al entrar el destino en el recuadro)
   X.v5 = fvLab5On(); X.clk = X.v5 && kind !== "warp"; X.orb = null; X.orbDone = false; X.pathDone = false; X.orate = 1; X.otau = 0;
   if (X.clk) { var V5 = FV_LAB.V5; X.preEst = X.pre; X.pre = 0; X.uP = 0; X.blk = 0; X.rate = X.inBox ? 1 : (V5.CREEP ? V5.CREEP_K : 0); }
   if (v1c) { X.bud = v1c.info; fvV1Dwell(P, X, kind, dur, pS, T, S0); }      // (V1c) lo que consulta el viaje al correr; DWELL: tiempo minimo dentro de la losa
}
// (v5, C) ¿hay foto con luz DETRAS del destino T mirando desde pos? El rayo pos -> T hasta el plano de la foto (z = distancia de la nebulosa);
// el espacio de vuelo es una escala de x, y: el mismo rayo y el mismo punto que en el real. Luz = la rejilla de la foto (P.lab.lum)
function fvLab5Behind(P, pos, T) {
   var N = P.scene.nebula, no = { ok: false, lum: 0, hit: false };
   if (!N || !N.layers || !N.layers.length) return no;
   var L0 = N.layers[0], D = N.distLy, k = D / L0.z, dz = T[2] - pos[2]; if (Math.abs(dz) < 1e-9) return no;
   // (v5d, BEHIND_STRICT, apagado) la placa tiene que quedar MAS ALLA de la estrella (t > 1): con 0 < t < 1 la placa esta entre la nave y la estrella (una estrella de la losa vista desde el otro lado) y no es «detras»
   var t = (D - pos[2]) / dz; if (!(t > (FV_LAB.V5.BEHIND_STRICT ? 1 : 0))) return no;
   var q = fvAdd(pos, fvMul(fvSub(T, pos), t)), G = (P.lab && P.lab.lum) || P.scene._labLum;
   var fx = (q[0] / k - L0.x0) / (L0.x1 - L0.x0), fy = (q[1] / k - L0.y0) / (L0.y1 - L0.y0);
   if (!(fx >= 0 && fx < 1 && fy >= 0 && fy < 1)) return no;
   var lum = G ? G.v[Math.floor(fy * G.ny) * G.nx + Math.floor(fx * G.nx)] : 0.5;
   return { ok: lum >= FV_LAB.V5.LUM_MIN, lum: lum, hit: true };
}
// (v5, C) la media vuelta: null si ya hay luz detras o si ninguna celda con luz cabe en ORBIT_MAX_S. Se gira en direcciones del espacio de VUELO
// (lo que se ve: velocidad de giro pareja), en RUMBO y ELEVACION (alrededor de la vertical), a distancia REAL la del camino; perfil trapecio
// (acelera, crucero <= W, frena) sobre la longitud de arco
function fvLab5OrbitPlan(P, X, kind, ov) {      // ov (V1c): { tMax: tope de tiempo de la vuelta (s), noCover: no mirar lo que ve el pintor (reserva del presupuesto) }; sin ov = lo de siempre
   var V5 = FV_LAB.V5, c = P.cam, T = P.flight.T, L = P.lab, S = L.S0 || L.S, N = P.scene.nebula, pA = X.pathDone ? c.pos : (P.flight.p1 || c.pos);   // desde donde acabara el camino
   var b0 = fvLab5Behind(P, pA, T); X.behind0 = b0.lum; X.cover0 = L.cover;
   // (v5d) CODIGO DE MOTIVO de por que no hay vuelta (X.orbWhy), solo para medir: no cambia ninguna decision. luz = ya hay luz detras · foto = el pintor ya ve foto ·
   // sinfoto = la escena no tiene capas · polo = llega por la vertical · sinluz = ninguna celda con luz · cara = las celdas con luz se verian de canto ·
   // elev = acabarian mirando a mas de EL_MAX · tope = caben 0 celdas y no hay parcial · corta = menos de 1° · parcial / completa = hubo vuelta
   X.orbWhy = null; X.orbCnt = null;
   if (b0.ok) { X.orbWhy = "luz"; return null; }
   if (!(L.cover < FV_LAB.ANCHOR_COVER) && !(ov && ov.noCover)) { X.orbWhy = "foto"; return null; }
   if (!N || !N.layers || !N.layers.length) { X.orbWhy = "sinfoto"; return null; }                  // ya hay foto detras o en pantalla (dice el pintor)
   // (14-nov, encargo A «la caja») la media vuelta rodea el destino a la distancia de llegada: con el destino junto a la boca (o mas alla) la vuelta sacaba la camara de la
   // caja (estrella a 30 821 a.l. con la boca a 8 076: la vuelta la llevaba a 53 971 a.l. de la Tierra). Sin vuelta si |T| + r no cabe en la boca (FV_BOX.ORBIT false = lo de antes)
   if (typeof FV_BOX !== "undefined" && FV_BOX.ON && FV_BOX.ORBIT && typeof fvBoxDMax === "function" && fvLen(T) + fvLen(fvSub(pA, T)) > fvBoxDMax(P.scene)) { X.orbWhy = "caja"; return null; }
   // (16-nov, P23-web) y por las paredes: la esfera de radio r alrededor del destino tiene que caber en la caja (fvBoxRoom, fv_objects.js; FV_BOX.WALLS false = lo de antes)
   if (typeof FV_BOX !== "undefined" && FV_BOX.ON && FV_BOX.ORBIT && FV_BOX.WALLS && typeof fvBoxRoom === "function" && fvLen(fvSub(pA, T)) > fvBoxRoom(P.scene, T)) { X.orbWhy = "caja"; return null; }
   var G = L.lum || P.scene._labLum, nx = G ? G.nx : 8, ny = G ? G.ny : 6, L0 = N.layers[0], D = N.distLy, k = D / L0.z;
   var Tf = fvLabRelFly(T, S), r = fvLen(fvSub(pA, T)); if (!(r > 1e-12)) return null;
   var w0 = fvNorm(fvLabRelFly(fvSub(pA, T), S)), tc = FV_LAB.TURN[kind] || FV_LAB.TURN.cine, ae0 = fvLab5AzEl(w0), elM = V5.EL_MAX * FV_DEG;
   X.orbGeo = { az: ae0[0] / FV_DEG, el: ae0[1] / FV_DEG, r: r, T: T.slice(), pA: pA.slice() };
   if (Math.abs(w0[1]) > 0.97) { X.orbWhy = "polo"; return null; }                             // llegando por el polo no hay rumbo (raro)
   var W = V5.ORBIT_W_K * tc[0] * FV_DEG, Ac = tc[1] * FV_DEG, tMax = (ov && ov.tMax !== undefined) ? ov.tMax : V5.ORBIT_MAX_S[kind === "warp" ? 1 : 0], phiMax = W * Math.max(0, tMax - W / Ac);
   var best = null, bs = 1e9, near = null, cnt = { cells: nx * ny, lum: 0, face: 0, el: 0, fit: 0, phiMax: phiMax / FV_DEG }, dbg = V5.DBG ? [] : null;
   for (var j = 0; j < ny; ++j) for (var i = 0; i < nx; ++i) {
      var lum = G ? G.v[j * nx + i] : 0.5; if (!(lum >= V5.LUM_MIN)) { if (dbg) dbg.push([i, j, +lum.toFixed(3), "sinluz"]); continue; }
      ++cnt.lum;
      var qr = [(L0.x0 + (i + 0.5) * (L0.x1 - L0.x0) / nx) * k, (L0.y0 + (j + 0.5) * (L0.y1 - L0.y0) / ny) * k, D];
      var wc = fvSub(Tf, fvLabRelFly(qr, S)); if (!(fvLen(wc) > 1e-9)) continue; wc = fvNorm(wc);
      if (Math.abs(wc[2]) < V5.FACE_MIN) { if (dbg) dbg.push([i, j, +lum.toFixed(3), "cara", +Math.abs(wc[2]).toFixed(3), +(Math.asin(fvClamp(wc[1], -1, 1)) / FV_DEG).toFixed(1)]); continue; }                    // la foto vista de canto (rasante) no se pinta: hace falta verla de frente
      ++cnt.face;
      var ae1 = fvLab5AzEl(wc); if (Math.abs(ae1[1]) > elM) { if (dbg) dbg.push([i, j, +lum.toFixed(3), "elev", +Math.abs(wc[2]).toFixed(3), +(ae1[1] / FV_DEG).toFixed(1)]); continue; }   // acabar mirando muy arriba o muy abajo: no
      ++cnt.el;
      var daz = ae1[0] - ae0[0]; while (daz > Math.PI) daz -= 2 * Math.PI; while (daz <= -Math.PI) daz += 2 * Math.PI;
      var sw = fvLab5ArcLen(ae0, daz, ae1[1] - ae0[1], 1); X.orbNeed = Math.min(X.orbNeed === undefined ? 1e9 : X.orbNeed, sw);
      if (dbg) dbg.push([i, j, +lum.toFixed(3), sw > phiMax ? "tope" : "ok", +Math.abs(wc[2]).toFixed(3), +(ae1[1] / FV_DEG).toFixed(1), +(sw / FV_DEG).toFixed(1)]);
      if (sw <= phiMax) ++cnt.fit;
      if (sw > phiMax) { if (!near || sw < near.phi) near = { w1: wc, phi: sw, lum: lum, daz: daz, del: ae1[1] - ae0[1] }; continue; }   // (v5c) la mas cercana de las que no caben: para la vuelta parcial
      var sc = sw - V5.LUM_W * lum - V5.FACE_W * Math.abs(wc[2]); if (sc < bs) { bs = sc; best = { w1: wc, phi: sw, lum: lum, daz: daz, del: ae1[1] - ae0[1] }; }
   }
   // (v5c, ORBIT_PARTIAL [cine, warp]) si ninguna celda con luz cabe en el tope, vuelta PARCIAL: hasta donde llega el tope, a la misma velocidad de giro, hacia la
   // celda que pide menos giro (la foto queda a rem grados de estar justo detras, dentro del cuadro si rem < ~medio campo). Apagado = saltar la vuelta (v5b)
   var part = false, rem = 0, PP = V5.ORBIT_PARTIAL;
   if (!best && near && ((ov && ov.partial) || (PP && PP[kind === "warp" ? 1 : 0]))) {      // (V1c) con el presupuesto, la vuelta que no cabe es PARCIAL tambien en cine
      var lo = 0, hi = 1, fr;                                            // fraccion del arco cuya longitud (rumbo y elevacion) es phiMax
      for (var it = 0; it < 24; ++it) { fr = 0.5 * (lo + hi); if (fvLab5ArcLen(ae0, near.daz * fr, near.del * fr, 1) > phiMax) hi = fr; else lo = fr; }
      best = { w1: near.w1, phi: near.phi, lum: near.lum, daz: near.daz * lo, del: near.del * lo }; part = true; rem = near.phi - phiMax;
   }
   // (v5d, ORBIT_RESCUE [cine, warp], APAGADO) rescate cuando NINGUNA celda con luz es elegible (cara / elevacion; medido: el 18 % de las llegadas): la nave se pone DE FRENTE a la
   // foto por la perpendicular que pasa por la estrella (la foto queda detras de la estrella, o delante si la estrella esta detras de la foto), a elevacion 0. Si no cabe, parcial
   var resc = false, RS = V5.ORBIT_RESCUE;
   if (!best && !near && RS && RS[kind === "warp" ? 1 : 0]) {
      var sgn = (T[2] - D) >= 0 ? 1 : -1, aer = fvLab5AzEl([0, 0, sgn]), dzr = aer[0] - ae0[0]; while (dzr > Math.PI) dzr -= 2 * Math.PI; while (dzr <= -Math.PI) dzr += 2 * Math.PI;
      var cand = { w1: [0, 0, sgn], phi: fvLab5ArcLen(ae0, dzr, aer[1] - ae0[1], 1), lum: 0, daz: dzr, del: aer[1] - ae0[1] };
      if (cand.phi <= phiMax) best = cand; else near = cand;
      resc = true;
      if (!best && near && PP && PP[kind === "warp" ? 1 : 0]) {            // parcial hacia el frente de la foto (misma biseccion que la parcial normal)
         var lo2 = 0, hi2 = 1, fr2; for (var it2 = 0; it2 < 24; ++it2) { fr2 = 0.5 * (lo2 + hi2); if (fvLab5ArcLen(ae0, near.daz * fr2, near.del * fr2, 1) > phiMax) hi2 = fr2; else lo2 = fr2; }
         best = { w1: near.w1, phi: near.phi, lum: 0, daz: near.daz * lo2, del: near.del * lo2 }; part = true; rem = near.phi - phiMax;
      }
   }
   X.orbCnt = cnt; if (dbg) X.orbCells = dbg;
   if (!best) { X.orbWhy = cnt.lum === 0 ? "sinluz" : (cnt.face === 0 ? "cara" : (cnt.el === 0 ? "elev" : "tope")); return null; }
   if (best.phi < 1 * FV_DEG) { X.orbWhy = "corta"; return null; }
   X.orbWhy = resc ? (part ? "rescateparcial" : "rescate") : (part ? "parcial" : "completa");
   var tab = [0]; for (var q = 1; q <= 16; ++q) tab.push(tab[q - 1] + fvLab5ArcLen([ae0[0] + best.daz * (q - 1) / 16, ae0[1] + best.del * (q - 1) / 16], best.daz / 16, best.del / 16, 1));   // longitud de arco acumulada (s -> angulo)
   best.phi = tab[16];
   var dur = best.phi / W + W / Ac;
   if (best.phi < W * W / Ac) { W = Math.sqrt(best.phi * Ac); dur = 2 * W / Ac; }   // vuelta corta: triangulo (no llega al crucero)
   return { w0: w0, w1: best.w1, daz: best.daz, del: best.del, tab: tab, phi: best.phi, W: W, A: Ac, t0: P.flight.t, dur: dur, lum: best.lum, S: S, r: r, partial: part, rem: rem, rescue: resc };
}
// rumbo y elevacion de una direccion del espacio de vuelo (y arriba) y vuelta atras
function fvLab5AzEl(w) { return [Math.atan2(w[0], w[2]), Math.asin(fvClamp(w[1], -1, 1))]; }
function fvLab5Dir(az, el) { var ce = Math.cos(el); return [ce * Math.sin(az), Math.sin(el), ce * Math.cos(az)]; }
// longitud (rad) del camino en rumbo y elevacion desde ae, con incrementos daz y del, en n tramos
function fvLab5ArcLen(ae, daz, del, n) { var s = 0, m = Math.max(8, 8 * n); for (var i = 0; i < m; ++i) { var el = ae[1] + del * (i + 0.5) / m; s += Math.sqrt(Math.pow(Math.cos(el) * daz / m, 2) + Math.pow(del / m, 2)); } return s; }
// fraccion s del camino (0..1) para un angulo recorrido ph (tabla de la vuelta)
function fvLab5SOf(o, ph) { var t = o.tab, n = t.length - 1; if (ph <= 0) return 0; if (ph >= t[n]) return 1; for (var i = 1; i <= n; ++i) if (t[i] >= ph) return (i - 1 + (ph - t[i - 1]) / Math.max(1e-12, t[i] - t[i - 1])) / n; return 1; }
function fvLab5OrbitAng(o, tau) {
   var t = fvClamp(tau, 0, o.dur), ta = o.W / o.A, tc = Math.max(0, o.dur - 2 * ta);
   if (t < ta) return 0.5 * o.A * t * t;
   if (t < ta + tc) return 0.5 * o.A * ta * ta + o.W * (t - ta);
   var td = o.dur - t; return Math.max(0, o.phi - 0.5 * o.A * td * td);
}
// apuntar NIVELADO: el giro que lleva la base a la base nivelada de want (para mirar a un destino de detras, media vuelta alrededor de la VERTICAL,
// no por encima: el horizonte no se tuerce, N3); lo que ese giro tiene de alabeo (sobre la mirada) va aparte, a <= ROLL_DPS. Junto al polo
// (mirada a < 10° de la vertical) no hay horizonte: circulo maximo sin alabeo
function fvLab4AimW(B, want, W, A, hz) {
   var f = B.f, wn = fvNorm(want), V = FV_LAB.V4, ro = fvLabRollOf(B), e;
   if (ro.ok && Math.abs(wn[1]) < Math.sin(FV_LAB.ROLL.POLE_DEG * FV_DEG) && hz) {
      // (v5, solo con la media vuelta: hz) lo que se limita a ROLL_DPS es el alabeo del HORIZONTE (la base frente a su nivelada), no la parte sobre
      // la mirada que trae girar alrededor de la vertical con la mirada inclinada (w x sen(elevacion): a 25 °/s y 30° ya pasa de ROLL_DPS y el
      // horizonte se quedaba torcido hasta 41°, enderezado de golpe al llegar). Fuera de la media vuelta, lo de la v4: con el horizonte torcido al
      // salir (35°) y la mirada subiendo a 75°, esta forma lo torcia mas (52°) y la de la v4 lo endereza (medido el 9-nov, FS 116 -> 117 warp)
      var Bl = fvLabLevel(f, B), er = fvDot(fvLabRotErr(B, Bl), f), eD = fvLabRotErr(Bl, fvLabLevel(wn, Bl));
      var w5 = fvAdd(fvLabSpringW(eD, W, A), fvMul(f, fvClamp(V.ROLL_K * er, -V.ROLL_DPS * FV_DEG, V.ROLL_DPS * FV_DEG))), l5 = fvLen(w5);
      return (l5 > W) ? fvMul(w5, W / l5) : w5;                         // el giro total, dentro del tope del estilo
   }
   if (ro.ok && Math.abs(wn[1]) < Math.sin(FV_LAB.ROLL.POLE_DEG * FV_DEG)) {
      e = fvLabRotErr(B, fvLabLevel(wn, B));
      var ep = fvDot(e, f), eA = fvSub(e, fvMul(f, ep));
      return fvAdd(fvLabSpringW(eA, W, A), fvMul(f, fvClamp(V.ROLL_K * ep, -V.ROLL_DPS * FV_DEG, V.ROLL_DPS * FV_DEG)));
   }
   var ax = fvCross(f, wn), s = fvLen(ax), cth = fvDot(f, wn);
   if (s > 1e-12) e = fvMul(ax, Math.atan2(s, cth) / s); else e = (cth < 0) ? fvMul(B.d, Math.PI) : [0, 0, 0];
   return fvLabSpringW(e, W, A);
}
function fvLab4AutoSub(P, h, Q) {
   var fl = P.flight, X = fl.lab, L = P.lab, c = P.cam, V = FV_LAB.V4, V5 = X.v5 ? FV_LAB.V5 : null;
   var dT = fvLabDirFly(P, X.Tl);
   if (X.clk) {
      // (v5, cine) reloj propio: durante el giro previo avanza a CREEP_K; despues, sin paisaje segun el pintor, hasta FAST_K veces (suavizado)
      if (!X.inBox && (fvLab4InBox(P, dT, V.MARGIN_IN) || fl.t >= X.preEst + V.PRE_MAX_S)) { X.inBox = true; X.pre = fl.t; }
      X.blk += (((L.land === false) ? 1 : 0) - X.blk) * (1 - Math.exp(-h / V5.BLK_S));
      var endK = 1 - fvSmooth((X.uP - V5.FAST_END[0]) / (V5.FAST_END[1] - V5.FAST_END[0]));
      var rT = !X.inBox ? (V5.CREEP ? V5.CREEP_K : 0) : 1 + ((V5.FAST && !X.dwell) ? (V5.FAST_K - 1) * X.blk * endK : 0);      // (V1c, DWELL) un viaje que cruza la losa no acelera el reloj sin paisaje: el tiempo minimo dentro valdria menos
      X.rate += (rT - X.rate) * (1 - Math.exp(-h / V5.RATE_S));
      X.uP = Math.min(1, X.uP + h * X.rate / Math.max(1e-6, X.durMove));
      if (X.uP < 1) fl.dur = fl.t + h + (1 - X.uP) * X.durMove / Math.max(0.2, X.rate);
   } else if (!X.inBox) {
      // el reloj del camino espera mientras el destino no entra en el recuadro (giro previo dinamico; tope PRE_MAX_S, luego la correa)
      if (fvLab4InBox(P, dT, V.MARGIN_IN)) X.inBox = true;
      else if (fl.t >= X.pre + (X.prepS || 0) && X.preExt < V.PRE_MAX_S) { X.pre += h; fl.dur += h; X.preExt += h; }
      else if (fl.t >= X.pre + (X.prepS || 0)) X.inBox = true;
   }
   var pre = X.pre, u = X.clk ? X.uP : ((X.durMove > 0) ? fvClamp((fl.t - pre) / X.durMove, 0, 1) : 1), pOld = c.pos.slice();
   var uw = (fl.kind === "warp") ? fvClamp((u - FV_LAB.WARP.PREP) / (1 - FV_LAB.WARP.PREP), 0, 1) : u;
   var p = X.pc.fn(fvLabSOfTau(X.pc, fvCineX(uw)));
   if (X.tb > 0 && fl.t < X.tb) { var q = fl.t / X.tb, bt = fvMul(X.v0, X.tb / 3 * (1 - Math.pow(1 - q, 3))); p = fvAdd(p, fvSub(bt, X.Bv)); }
   if (!(isFinite(p[0]) && isFinite(p[1]) && isFinite(p[2]))) p = c.pos.slice();
   // (v5, C) la media vuelta si detras de la estrella no hay foto con luz: en cine empieza OVL_S antes de acabar el camino; el punto del camino
   // se GIRA alrededor de la estrella (direccion en el espacio de vuelo, distancia REAL la del camino: sigue bajando y luego queda constante)
   if (V5) {
      if (!X.pathDone && (X.clk ? X.uP >= 1 : fl.t >= fl.dur)) X.pathDone = true;
      // (V1c) con camino corto (FAST: 2-3 s) la vuelta no se decide en el primer segundo, con la foto aun llenando la pantalla («foto» = no hay vuelta): no antes de ORB_UP del camino
      var left = X.pathDone ? 0 : (X.clk ? (1 - X.uP) * X.durMove / Math.max(0.2, X.rate) : 1e9);
      if (!X.orbDone && !X.orb && (X.pathDone || (left <= V5.OVL_S && (!X.bud || X.uP >= FV_V1.ORB_UP)))) { X.orb = V5.ORBIT ? fvLab5OrbitPlan(P, X, fl.kind, X.bud ? { partial: true, tMax: Math.max(0, Math.min(X.bud.orbCap, X.bud.Tp - fl.t - X.bud.settleEst)) } : undefined) : null; if (!X.orb) X.orbDone = true; }
      if (X.orb && !X.orbDone) {
         var o = X.orb, tau = fl.t - o.t0, ph, rel = fvSub(p, fl.T), rl = fvLen(rel);
         // (v5b, ORBIT_FAST, solo cine, apagado por defecto) sin paisaje la vuelta corre ORBIT_FAST_K veces (reloj propio de la vuelta, suavizado como FAST)
         if (V5.ORBIT_FAST && X.clk) { var oT = 1 + (V5.ORBIT_FAST_K - 1) * X.blk; X.orate += (oT - X.orate) * (1 - Math.exp(-h / V5.RATE_S)); X.otau += h * X.orate; tau = X.otau; }
         ph = fvLab5OrbitAng(o, tau);
         if (rl > 1e-12) { var aeP = fvLab5AzEl(fvNorm(fvLabRelFly(rel, o.S))), sF = fvLab5SOf(o, ph), wr = fvLab5Dir(aeP[0] + o.daz * sF, aeP[1] + o.del * sF); p = fvAdd(fl.T, fvMul(fvNorm(fvLabRelReal(wr, o.S)), rl)); }
         X.orbP = p.slice();
         if (tau >= o.dur && X.pathDone) { X.orbDone = true; X.A = X.orbP.slice(); fl.p1 = X.A.slice(); } else fl.dur = (V5.ORBIT_FAST && X.clk) ? Math.max(fl.dur, fl.t + (o.dur - tau) / Math.max(0.2, X.orate) + h) : Math.max(fl.dur, o.t0 + o.dur + h);   // la llegada (fvLabArrive) deja la nave en X.A
      }
      if (X.orbDone && X.orbP) p = X.orbP.slice();               // acabada la media vuelta, la nave se queda donde la dejo (no vuelve al punto del camino)
   }
   var eT = fvSub(p, fl.T), lT = fvLen(eT);
   if (X.dA > 0 && lT < X.dA && lT > 1e-12) { p = fvAdd(fl.T, fvMul(eT, X.dA / lT)); eT = fvSub(p, fl.T); lT = X.dA; }
   if (lT > X.dPrev && lT > 1e-12) { p = fvAdd(fl.T, fvMul(eT, X.dPrev / lT)); lT = X.dPrev; }      // (R2) la distancia NUNCA sube
   X.dPrev = Math.min(X.dPrev, lT);
   c.pos = p; L.v = fvMul(fvSub(p, pOld), 1 / h);
   fl.phase = (u < 0.12) ? "depart" : (u < 0.74 ? "cruise" : "arrive");
   if (fl.kind === "warp" && !(V5 && X.pathDone)) fvLabWarpFx(P, fl, pre, uw);
   else if (fl.kind === "warp") { P.trail = 0; P.warp = 0; fl.warpPhase = "exit"; }   // (v5) la media vuelta tras el warp: sin estelas ni destellos
   // la mirada: al destino; la mirada al contenido (K) solo inclina el encuadre hasta KEEP x el recuadro, suavizada BIAS_S, y se apaga en BIAS_END
   var tc = FV_LAB.TURN[fl.kind] || FV_LAB.TURN.cine, kTx = (X.bud && X.bud.kT) || 1, W = tc[0] * FV_DEG * kTx, A = tc[1] * FV_DEG * kTx, want = dT, half = fvLab4HalfIn(P, V.MARGIN), bT = [0, 0, 0];   // (V1c) kTx: el giro previo largo sube los topes del estilo solo en ese viaje
   dT = fvLabDirFly(P, X.Tl);
   if (X.inBox && fl.t >= pre && fvLabContentOn() && u < V.BIAS_END[1]) {
      var cd = fvLabContentDir(P), fade = 1 - fvSmooth((u - V.BIAS_END[0]) / (V.BIAS_END[1] - V.BIAS_END[0]));
      if (cd && L.cdOk) { var aC = fvAngle(dT, cd); if (aC > 1e-6) bT = fvSub(fvSlerpDir(dT, cd, Math.min(aC, V.KEEP * half) * fade / aC), dT); }
   }
   X.bias = fvAdd(X.bias, fvMul(fvSub(bT, X.bias), 1 - Math.exp(-h / V.BIAS_S)));
   want = dT;
   if (u < 1 && fvLen(X.bias) > 1e-9) { want = fvNorm(fvAdd(dT, X.bias)); var aW = fvAngle(dT, want), aM = V.KEEP * half; if (aW > aM) want = fvSlerpDir(dT, want, aM / aW); }
   X.wantPrev = want;
   var ofk = (V5 && V5.ORBIT_FAST && X.clk && X.orb && !X.orbDone) ? X.orate : 1;   // (v5b) el tope de giro sube con la vuelta rapida (sin paisaje: nada que se vea girar)
   var wd = fvLab4AimW(c.B, want, W * ofk, A * ofk, !!(V5 && X.orb)), dw = fvSub(wd, L.w), dl = fvLen(dw), cap = A * ofk * h;
   L.w = (dl > cap) ? fvAdd(L.w, fvMul(dw, cap / dl)) : wd;
   // la llegada (R3): acabado el camino, el viaje sigue hasta que mirada, alabeo y giro esten a cero (tope SETTLE_MAX_S); el ultimo ajuste
   // (< SETTLE_DEG) es invisible. Despues no hay «giro final»: la imagen queda quieta y derecha
   if (V5 ? (X.pathDone && X.orbDone) : fl.t >= fl.dur) {
      X.settle += h;
      var ro = fvLabRollOf(c.B), aE = fvAngle(c.B.f, dT);
      if ((aE < V.SETTLE_DEG * FV_DEG && fvLen(L.w) < V.SETTLE_W_DPS * FV_DEG && (!ro.ok || Math.abs(ro.a) < V.SETTLE_ROLL_DEG * FV_DEG)) || X.settle >= (X.bud ? X.bud.settleCap : V.SETTLE_MAX_S)) {
         X.snapDeg = aE / FV_DEG; X.snapRollDeg = ro.ok ? ro.a / FV_DEG : 0; X.snapWdps = fvLen(L.w) / FV_DEG;
         c.B = ro.ok ? fvLabLevel(dT, c.B) : fvLabOrtho({ f: dT, r: c.B.r, d: c.B.d }); c.look = c.B.f.slice(); L.w = [0, 0, 0]; L.v = [0, 0, 0];
         if (fvLab4On()) L.S = fvLabSEff(L, c.B.f);
         fvLabArrive(P);
      }
   }
}
// la correa (R2): si el destino se sale del recuadro (MARGIN), la base gira lo justo para dejarlo en el borde (X.leashN cuenta las veces)
function fvLab4Leash(P) {
   var fl = P.flight, X = fl && fl.lab, c = P.cam, V = FV_LAB.V4; if (!X || !X.v4 || !V.LEASH || !X.inBox || fl.t < X.pre) return false;
   var d = fvLabDirFly(P, X.Tl), q = fvLab4Scr(c.B, d), tx = V.MARGIN * Math.tan(c.fov / 2), ty = tx * P.VH / Math.max(1, P.VW);
   if (q.z > 1e-6 && Math.abs(q.x) <= tx && Math.abs(q.y) <= ty) return false;
   var x = 0, y = 0; if (q.z > 1e-6) { x = fvClamp(q.x, -tx, tx); y = fvClamp(q.y, -ty, ty); }
   var pt = fvNorm(fvAdd(fvAdd(c.B.f, fvMul(c.B.r, x)), fvMul(c.B.d, y))), ax = fvCross(pt, d), s = fvLen(ax);
   if (s < 1e-12) return false;
   c.B = fvLabOrtho(fvLabRotB(c.B, fvMul(ax, 1 / s), Math.atan2(s, fvDot(pt, d)))); c.look = c.B.f.slice();
   if (fvLab4On()) P.lab.S = fvLabSEff(P.lab, c.B.f);
   X.leashN = (X.leashN || 0) + 1;
   return true;
}

// ---------------------------------------------------------------------------
// EL PASO (reloj): integrador con subpasos fijos
// ---------------------------------------------------------------------------
function fvLabStep(P, dt) {
   var L = fvLabState(P), c = P.cam, prev = c.pos.slice();
   P.t += dt; P.flash = 0;
   if (fvLabExternal(P)) fvLabSync(P);
   if (P.flight && P.flight.kind === "jump") {
      fvNmJumpStep(P, dt);
      if (fvLabExternal(P)) { c.fov = P.homeFov; fvLabSync(P); }
      // (11-nov, NV-1) EN CASA, DERECHA: el salto a casa deja la posicion y la mirada, pero fvLabSync rehace la base con el «abajo» que traia la nave.
      // Tras una media vuelta (v5) eso era llegar a casa con la foto BOCA ABAJO y 6° torcida, y ahi se quedaba (medido en el dialogo real,
      // tests/_nav11/nav_default_probe.js: abajo = (-0,104, -0,995, 0) en vez de (0, 1, 0), 2 198 estrellas en vez de 2 545)
      if (fvLen(c.pos) < 1e-9) { c.B = fvLabLevel([0, 0, 1], null); c.look = c.B.f.slice(); fvLabMark(P); }
      L.v = [0, 0, 0]; L.w = [0, 0, 0];
      fvLabFinish(P, dt, prev);
      return P;
   }
   if (!(dt > 0)) { fvLabFinish(P, dt, prev); return P; }
   var Q = fvLabGeo(P), fl = P.flight, X = fl ? fl.lab : null, n = Math.max(1, Math.ceil(dt / FV_LAB.SUB - 1e-9)), h = dt / n, i;
   // lo que vale para todo el fotograma (las cuentas caras, una vez)
   var nr = fvFreeNearest(P), ctl = fvLabControls(P, nr, Q);
   // la velocidad del arrastre (suavizada, para el planeo al soltar): lo girado en este fotograma / dt
   if (L.drag) { var aM = 1 - Math.exp(-dt / 0.08), dg = L.drag; if (dg.kind === "pan") { dg.rate = fvAdd(dg.rate, fvMul(fvSub(fvMul(dg.acc, 1 / dt), dg.rate), aM)); dg.acc = [0, 0, 0]; }
                 else { dg.rate = [dg.rate[0] + (dg.acc[0] / dt - dg.rate[0]) * aM, dg.rate[1] + (dg.acc[1] / dt - dg.rate[1]) * aM]; dg.acc = [0, 0, 0]; } }
   if (P.flight && L.thr) { L.thr = 0; L.thrAssist = false; }      // (R1) un viaje manda: la consigna de la rueda se suelta
   for (i = 0; i < n; ++i) {
      if (P.flight && P.flight.lab) fvLabAutoSub(P, h, Q);
      else fvLabFreeSub(P, h, Q, ctl);
      fvLabRotSub(P, h);
      if (P.flight && P.flight.lab && P.flight.lab.v4) fvLab4Leash(P);   // (v4, R2) la correa: el destino no sale del recuadro
   }
   // el campo (D2): lente fija fuera de casa, casa con su campo, telescopio con su aumento; ritmo ≤ FOV_RATE e/s
   fvLabFovStep(P, dt, Q);
   fvLabFinish(P, dt, prev);
   return P;
}
// lo de cada fotograma del vuelo libre: teclas, escala de la velocidad
function fvLabControls(P, nr, Q) {
   var L = P.lab, FP = FV_PILOT.FREE, o = {};
   o.boost = fvLabHeld(P, "boost"); o.fwd = fvLabHeld(P, "fwd"); o.bk = fvLabHeld(P, "back");
   o.lf = fvLabHeld(P, "left"); o.rt = fvLabHeld(P, "right"); o.up = fvLabHeld(P, "up"); o.dn = fvLabHeld(P, "down");
   o.rl = fvLabHeld(P, "roll-"); o.rr = fvLabHeld(P, "roll+");
   o.dN = Math.max(nr.d, 0.25 * fvLabAhead(P, nr)); o.nr = nr; o.dNf = Math.max(nr.d, 0.25 * fvLabAheadFly(P, nr));
   o.thr = (o.fwd ? 1 : 0) - (o.bk ? 1 : 0);
   o.yaw = (o.rt ? 1 : 0) - (o.lf ? 1 : 0); o.pitch = (o.up ? 1 : 0) - (o.dn ? 1 : 0); o.roll = (o.rr ? 1 : 0) - (o.rl ? 1 : 0);
   // D4 · la ayuda de mirada hacia dentro, solo fuera de la piramide y en vuelo libre (≤ LOOK_DPS)
   o.inside = fvLabInside(Q, P.cam.pos, 1.0);
   return o;
}
// un subpaso del vuelo libre: empuje con inercia (ACC_S / DAMP_S), velocidad ∝ distancia real a lo mas cercano, giro con inercia
function fvLabFreeSub(P, h, Q, o) {
   var L = P.lab, c = P.cam, FP = FV_PILOT.FREE, Ttc = FV_LAB.TURN.free, W = Ttc[0] * FV_DEG, A = Ttc[1] * FV_DEG, B = c.B, kB = o.boost ? FP.BOOST : 1;
   // GIRO: cuerpo — guiñada alrededor de d, cabeceo alrededor de r, alabeo alrededor de f
   var wb = [fvDot(L.w, B.d), fvDot(L.w, B.r), fvDot(L.w, B.f)];            // (guiñada, cabeceo, alabeo) actuales
   var des = wb.slice(), aCap = [A, A, FV_LAB.ROLL.A * FV_DEG];
   var dk = Math.exp(-h / FV_LAB.TURN_DECAY_S);
   // (R6) GIROS GRADUALES (FV_LAB.GIRO): topes de °/s y °/s² que no dependen de la velocidad de vuelo; las teclas fijan una velocidad objetivo que la
   // velocidad angular persigue con una constante de tiempo (tk: 0 = solo el tope de aceleracion); el arrastre, en fvLabGiroChase
   var G6 = fvLabGiroOn() ? FV_LAB.GIRO : null, tk = [0, 0, 0], wCap = 1e30, rollW = FV_LAB.ROLL.W * FV_DEG, Wk = W;
   if (G6) {
      wCap = G6.W_MAX * FV_DEG; W = Math.min(W, wCap); A = Math.min(A, G6.A_MAX * FV_DEG); aCap = [A, A, Math.min(FV_LAB.ROLL.A * FV_DEG, G6.A_MAX * FV_DEG)];
      rollW = Math.min(rollW, G6.ROLL_W * FV_DEG); Wk = G6.KEY_DPS * FV_DEG;
      if (L.glide && L.glide.chase) { fvLabGiroChase(P, h); B = c.B; }
   }
   var tUp = G6 ? G6.TAU_UP : 0, tDn = G6 ? G6.TAU_DOWN : 0, kbk = (o.boost && !fvV1On("TURN")) ? 1.6 : 1;      // (V1a, V1-04) con FV_V1.TURN Mayus ya no sube el giro
   if (L.drag && L.drag.kind !== "pan") { des = [0, 0, wb[2]]; }
   else if (L.glide && L.glide.chase) { des = [0, 0, wb[2]]; }
   else if (L.glide) {
      var gk = Math.exp(-h / FV_LAB.MOUSE_GLIDE_S), g = L.glide; g.rate = [g.rate[0] * gk, g.rate[1] * gk]; g.t += h;
      if (g.kind === "orbit" && g.focus) fvLabOrbitTurn(P, g.focus, g.rate[0] * h, g.rate[1] * h);
      else if (g.kind === "look") fvLabLookTurn(P, g.rate[0] * h, g.rate[1] * h);
      if (Math.abs(g.rate[0]) + Math.abs(g.rate[1]) < 1e-5) L.glide = null;
      B = c.B; des = [0, 0, wb[2]];
   }
   else if (G6 && L.drag) { des[0] = 0; des[1] = 0; tk[0] = tk[1] = tDn; }      // (R6) con el boton derecho (desplazar) la nave deja de girar sin salto
   if (o.yaw) { des[0] = o.yaw * Math.min(Wk * kbk, wCap); tk[0] = tUp; } else if (!L.drag && !L.glide) { des[0] = G6 ? 0 : wb[0] * dk; tk[0] = tDn; }
   if (o.pitch) { des[1] = o.pitch * Math.min(Wk * kbk, wCap); tk[1] = tUp; } else if (!L.drag && !L.glide) { des[1] = G6 ? 0 : wb[1] * dk; tk[1] = tDn; }
   if (o.roll) { des[2] = o.roll * rollW; tk[2] = tUp; }
   else {
      var ro = fvLabRollOf(B), fastL = !!L.userRoll, capL = (fastL ? FV_LAB.ROLL.LEVEL_DPS : FV_LAB.ROLL.AUTO_DPS) * FV_DEG, kL = fastL ? FV_LAB.ROLL.LEVEL_K : FV_LAB.ROLL.AUTO_K;
      if (G6) capL = Math.min(capL, G6.ROLL_W * FV_DEG);
      des[2] = ro.ok ? fvClamp(-kL * ro.a, -capL, capL) : 0;
      if (Math.abs(ro.a) < 1 * FV_DEG) L.userRoll = false;          // ya derecho: lo que venga despues (giro inducido) se endereza lento
   }
   if (o.roll) L.userRoll = true;
   // (v4, R1) MIRAR 360°: la guiñada de las flechas / la cruceta gira alrededor de la VERTICAL del mundo (el horizonte no se tuerce al mirar
   // arriba y girar) y el cabeceo se frena suave al llegar a PITCH_MAX (sin dar la vuelta por el polo)
   // El giro se lleva en la base {vertical del mundo, derecha, mirada}: guiñada yY alrededor de Y, cabeceo pP alrededor de r, alabeo qR
   // alrededor de f (L.w = yY·Y + pP·r + qR·f; como d ⟂ r y d ⟂ f, yY = (L.w·d)/(Y·d)). Cada uno decae y acelera por separado: sumar la
   // parte de la guiñada a des[1] cada subpaso la INTEGRABA (la elevacion caia de 4° a -34° en 12 s de cruceta; dbg_yaw, 9-nov)
   var flat = false;
   if (fvLab4On() && FV_LAB.LOOK360) {
      var LK3 = FV_LAB.LOOK360, Yw = [0, 1, 0], yd = fvDot(Yw, B.d);
      var el = Math.asin(fvClamp(-B.f[1], -1, 1)) / FV_DEG, pLo = LK3.PITCH_MAX - LK3.PITCH_SOFT;
      var edgeL = LK3.EDGE_LOOK && FV_LAB.EDGE.LOOK_ON && !o.inside && !o.yaw && !o.pitch;
      flat = !!LK3.FLAT_YAW && !L.drag && !L.glide && !(L.hold && !o.yaw && !o.pitch) && !edgeL && yd > 0.05;
      if (flat) {
         var yr = fvDot(Yw, B.r), yf = fvDot(Yw, B.f), yY = wb[0] / yd, pP = wb[1] - yY * yr, qR = wb[2] - yY * yf, kb = (o.boost && !fvV1On("TURN")) ? 1.6 : 1;
         var yD = o.yaw ? o.yaw * (G6 ? Math.min(Wk * kb, wCap) : W * kb) : (G6 ? 0 : yY * dk), pD = o.pitch ? o.pitch * (G6 ? Math.min(Wk * kb, wCap) : W * kb) : (G6 ? 0 : pP * dk), qD = des[2];
         if (pD > 0 && el > pLo) pD *= Math.max(0, 1 - (el - pLo) / LK3.PITCH_SOFT);
         if (pD < 0 && el < -pLo) pD *= Math.max(0, 1 - (-el - pLo) / LK3.PITCH_SOFT);
         if (G6) { yY = fvLabApproach(yY, yD, h, A, o.yaw ? tUp : tDn); pP = fvLabApproach(pP, pD, h, A, o.pitch ? tUp : tDn); qR = fvLabApproach(qR, qD, h, aCap[2], o.roll ? tUp : 0); }
         else { yY += fvClamp(yD - yY, -A * h, A * h); pP += fvClamp(pD - pP, -A * h, A * h); qR += fvClamp(qD - qR, -aCap[2] * h, aCap[2] * h); }
         L.w = fvAdd(fvAdd(fvMul(Yw, yY), fvMul(B.r, pP)), fvMul(B.f, qR));
      } else {
         if (des[1] > 0 && el > pLo) des[1] *= Math.max(0, 1 - (el - pLo) / LK3.PITCH_SOFT);
         if (des[1] < 0 && el < -pLo) des[1] *= Math.max(0, 1 - (-el - pLo) / LK3.PITCH_SOFT);
      }
   }
   // tras llegar, la mirada sigue al destino hasta que se toque un mando (el giro final sigue tras llegar, §7.4.2)
   if (L.hold && !o.yaw && !o.pitch && !L.drag && !L.glide) {
      var fH = L.hold.home ? [0, 0, 1] : fvNorm(fvLabRelFly(fvSub(L.hold.p, c.pos), L.S)), e = fvLabRotErr(B, fvLabLevel(fH, B));
      var we = fvLabAimW(B, fH, W, A, !!L.userRoll); des[0] = fvDot(we, B.d); des[1] = fvDot(we, B.r); if (!o.roll) des[2] = fvDot(we, B.f); tk[0] = tk[1] = 0; if (!o.roll) tk[2] = 0;
      if (fvAngle(B.f, fH) < 0.01 * FV_DEG && fvLen(L.w) < 0.02 * FV_DEG && (!L.hold.home || fvLen(e) < 0.5 * FV_DEG)) {
         if (L.hold.home && fvLen(c.pos) < 1e-9) { c.B = fvLabLevel([0, 0, 1], null); c.look = c.B.f.slice(); L.w = [0, 0, 0]; P.mode = "home"; c.fov = P.homeFov; }
         L.hold = null;
      }
   }
   // D4 · fuera de la piramide, la mirada se inclina hacia dentro (≤ 5 °/s): un empujon suave hacia el centro de la foto
   if (FV_LAB.EDGE.LOOK_ON && !o.inside && !o.yaw && !o.pitch && !L.drag && !L.hold && !(fvLab4On() && FV_LAB.LOOK360 && !FV_LAB.LOOK360.EDGE_LOOK)) {   // (v4) sin el empujon: mirar a 360° no vuelve sola a la foto
      var fC = fvNorm(fvLabRelFly(fvSub([0, 0, Q.D], c.pos), L.S)), ax = fvCross(B.f, fC), sa = fvLen(ax);
      if (sa > 1e-6) { var wi = fvMul(ax, Math.min(FV_LAB.EDGE.LOOK_DPS * FV_DEG, 2 * Math.asin(Math.min(1, sa))) / sa); des[0] = fvDot(wi, B.d); des[1] = fvDot(wi, B.r); tk[0] = tk[1] = 0; }   // = (velocidad objetivo), no += : sumado a la deriva se integraba (hasta ~140 x 5 °/s; lab_dbg_edge, 8-nov)
   }
   if (!flat) {
      for (var k = 0; k < 3; ++k) { if (G6) wb[k] = fvLabApproach(wb[k], des[k], h, aCap[k], tk[k]); else { var dw = des[k] - wb[k], cap = aCap[k] * h; wb[k] += fvClamp(dw, -cap, cap); } }
      L.w = fvAdd(fvAdd(fvMul(B.d, wb[0]), fvMul(B.r, wb[1])), fvMul(B.f, wb[2]));
   }
   // EMPUJE: a lo largo de la mirada (en real); inercia ACC_S, deriva DAMP_S; tope VMAX_K × la distancia a lo mas cercano
   // (v2) el empuje se da en el espacio de vuelo (velocidad vista ∝ lo que hay delante visto) y se pasa a real
   var vT = fvLabRelReal(fvMul(c.B.f, o.thr * FP.THRUST_K * o.dNf * kB), L.S), a = 1 - Math.exp(-h / (o.thr !== 0 ? FP.ACC_S : FP.DAMP_S));
   if (o.thr !== 0 || o.yaw || o.pitch || o.roll) L.brake = false;
   if (L.brake && L.thr) { L.thr = 0; L.thrAssist = false; }
   if (L.brake) { var bk = Math.exp(-h / 0.5); L.v = fvMul(L.v, bk); L.w = fvMul(L.w, bk); if (fvLen(L.v) < 1e-5 * o.dN && fvLen(L.w) < 1e-4) { L.brake = false; L.v = [0, 0, 0]; } fvLabMove(P, h, Q, o.nr); return; }
   if (fvV1On("CAP")) { fvV1Thrust(P, h, Q, o); return; }      // (V1a, V1-01..04) el empuje con tope L / 30 s, frenada por tiempo de llegada, cruce y giro
   // (R1, R2) la consigna de la rueda: la nave la persigue (despacio al acelerar, antes al bajar); frenado asistido = mas rapido y sin giro residual.
   // Las teclas de empuje mandan sobre ella y la sueltan
   var TH = FV_LAB.THROTTLE, thOn = !!(TH && TH.ON && L.thr !== undefined);
   if (thOn && o.thr !== 0) { L.thr = 0; L.thrAssist = false; }
   if (thOn && o.thr === 0 && (L.thr !== 0 || L.thrAssist)) {
      var tq = (P.t || 0) - L.thrT;
      if (L.thr !== 0 && tq > TH.HOLD_S) { L.thr *= Math.exp(-h / TH.DECAY_S); if (Math.abs(L.thr) < 0.05) L.thr = 0; }
      var vG = fvMul(fvLabFwdReal(P), fvLabThrottleFrac(L.thr) * fvLabAhead(P, o.nr)), up = fvLen(vG) > fvLen(L.v);
      var aT = 1 - Math.exp(-h / (L.thrAssist ? TH.TAU_BRAKE : (up ? TH.TAU_UP : TH.TAU_DOWN)));
      L.v = fvAdd(L.v, fvMul(fvSub(vG, L.v), aT));
      if (L.thrAssist) { L.w = fvMul(L.w, Math.exp(-h / TH.TAU_SPIN)); if (L.thr === 0 && fvLen(L.v) < 1e-5 * o.dN) { L.v = [0, 0, 0]; if ((P.t || 0) - L.thrBrakeT > TH.DETENT_S) L.thrAssist = false; } }
   }
   else if (o.thr !== 0) L.v = fvAdd(L.v, fvMul(fvSub(vT, L.v), a));
   else L.v = fvMul(L.v, 1 - a);
   var vm = FP.VMAX_K * o.dNf * kB, Lv = fvLen(fvLabRelFly(L.v, L.S)); if (o.thr !== 0 && Lv > vm) L.v = fvMul(L.v, vm / Lv);
   if (o.thr === 0 && fvLen(L.v) < 1e-5 * o.dN) L.v = [0, 0, 0];
   fvLabMove(P, h, Q, o.nr);
}
// mover la nave con la velocidad real L.v: estrellas protegidas (STANDOFF), borde blando (D4) y topes duros (§6.1)
function fvLabMove(P, h, Q, nr) {
   var L = P.lab, c = P.cam, FP = FV_PILOT.FREE, v = L.v;
   if (!(fvLen(v) > 0)) return;
   if (nr && nr.star >= 0 && nr.dStar < 3 * FP.STANDOFF) {
      var toS = fvSub(fvStarPos(P.scene, nr.star), c.pos), dS = fvLen(toS), nS = fvMul(toS, 1 / Math.max(1e-12, dS)), vin = fvDot(v, nS);
      if (vin > 0) v = fvSub(v, fvMul(nS, vin - vin * fvSmooth((dS - FP.STANDOFF) / (2 * FP.STANDOFF))));
   }
   // borde blando: en cada eje lateral, la componente hacia fuera se escala con smoothstep(lo que queda hasta OUT / banda); se frena de 0,9 a 1,5
   // (V1a, V1-05) con FV_V1.BOX las paredes estan en |u| = 1 (no a 1,5 semianchuras) y el techo en la boca de la caja
   var E = FV_LAB.EDGE, boxV1 = fvV1On("BOX"), OUTe = boxV1 ? 1 : E.OUT, u = fvLabU(Q, c.pos), z = Math.max(0, c.pos[2]), hx = Math.max(Q.kx * z, Q.hMin), hy = Math.max(Q.ky * z, Q.hMin), band = OUTe - (1 - E.BAND);
   var vx = v[0], vy = v[1];
   if (u[0] * vx > 0) { var rx = OUTe - Math.abs(u[0]); vx *= fvSmooth(rx / band); }
   if (u[1] * vy > 0) { var ry = OUTe - Math.abs(u[1]); vy *= fvSmooth(ry / band); }
   v = [vx, vy, v[2]];
   var np = fvAdd(c.pos, fvMul(v, h));
   // topes duros: suelo, fondo y OUT semianchuras (sin NaN)
   if (!(isFinite(np[0]) && isFinite(np[1]) && isFinite(np[2]))) { L.v = [0, 0, 0]; return; }
   if (boxV1) { c.pos = fvV1BoxClamp(P, Q, c.pos, np, v); L.v = v; return; }
   if (np[2] < Q.zMin) { np[2] = Q.zMin; if (v[2] < 0) v[2] = 0; }
   if (np[2] > Q.zMax) { np[2] = Q.zMax; if (v[2] > 0) v[2] = 0; }
   var cl = fvLabClampIn(Q, np, E.OUT); if (cl[0] !== np[0]) v[0] = 0; if (cl[1] !== np[1]) v[1] = 0;
   c.pos = cl; L.v = v;
}
// el muelle de giro: velocidad deseada hacia el error e (vector), con tope de velocidad y frenada a aceleracion A (sin pasarse)
// (v2, K5) APUNTAR SIN GIRAR LA PANTALLA: la velocidad angular deseada para llevar la mirada a want por el circulo maximo (sin componente sobre
// la mirada: cero alabeo inducido) mas el enderezado lento del horizonte (<= AUTO_DPS, o LEVEL_DPS si el alabeo lo pidio Q/Z). La v1 apuntaba
// con la base NIVELADA objetivo: cerca del cenit/nadir eso es girar la pantalla (K5 hasta 54 °/s en warp)
// (v3) rejilla de luminancia de la foto (nx x ny, 0 = fondo de cielo (percentil 20), 1 = lo mas brillante). La calcula la interfaz (o la prueba)
// con el bitmap de la foto y la deja en P.lab.lum; sin ella la nebulosa cuenta uniforme
function fvLabLumGrid(bmp, nx, ny) {
   try {
      var s = (bmp && bmp.scaledTo) ? bmp.scaledTo(nx, ny) : null; if (!s) return null;
      var L = (typeof s.__lum === "function") ? s.__lum() : null, v = [], i, j;
      for (j = 0; j < ny; ++j) for (i = 0; i < nx; ++i) {
         var lum; if (L) lum = L[j * nx + i] / 255; else { var p = s.pixel(i, j); lum = (0.2126 * ((p >>> 16) & 255) + 0.7152 * ((p >>> 8) & 255) + 0.0722 * (p & 255)) / 255; }
         v.push(lum);
      }
      var srt = v.slice().sort(function(a, b) { return a - b; }), bg = srt[Math.floor(0.2 * srt.length)], mx = srt[srt.length - 1] - bg, raw = v.slice();
      for (i = 0; i < v.length; ++i) v[i] = (mx > 1e-6) ? Math.max(0, v[i] - bg) / mx : 0;
      return { nx: nx, ny: ny, v: v, raw: raw };
   } catch (e) { return null; }
}
// (v3) MIRADA AL CONTENIDO: direccion (en VUELO) al centro de lo visible desde la nave, o null si lo visible rodea la nave (resultante < MIN_R).
// Estrellas: las que se pintarian (magnitud aparente < MAG_LIM), peso 0..1 por su brillo. Nebulosa: celdas de la foto en la losa, peso = su luz
// sobre el fondo x su angulo solido en vuelo (tope OM_CELL por celda). Todo pesa un poco mas cerca de donde ya se mira (FWD: continuidad).
// Una vez por fotograma (cache por P.t)
function fvLabContentDir(P) {
   var L = P.lab, c = P.cam; if (L.cdT === P.t) return L.cd;
   var CF = FV_LAB.CONTENT, S = P.scene.stars, N = P.scene.nebula, f = c.B.f, R = [0, 0, 0], Wt = 0, i, j;
   var IT = [];   // (u, estrella?, angulo solido x luz) para saber si mirando a cd se veria algo
   var add = function(d, w, om) { var n = fvLen(d); if (!(n > 1e-9) || !(w > 0)) return; var u = fvMul(d, 1 / n); IT.push([u, om === undefined, om || 0]); w *= CF.FWD + (1 - CF.FWD) * 0.5 * (1 + fvDot(u, f)); R = fvAdd(R, fvMul(u, w)); Wt += w; };
   for (i = 0; i < S.n; ++i) {
      var p = [S.x[i], S.y[i], S.z[i]], e = fvSub(p, c.pos), dc = fvLen(e); if (!(dc > 1e-9)) continue;
      var m = fvApparentMag(S.g[i], S.dEarth[i], dc); if (m < CF.MAG_LIM) add(fvLabRelFly(e, L.S), CF.STAR_K * Math.min(1, (CF.MAG_LIM - m) / 3));
   }
   if (N && N.layers && N.layers.length) {
      var L0 = N.layers[0], D = N.distLy, G = L.lum || P.scene._labLum, nx = G ? G.nx : 8, ny = G ? G.ny : 6, k = D / L0.z, dx = (L0.x1 - L0.x0) / nx * k, dy = (L0.y1 - L0.y0) / ny * k;
      for (j = 0; j < ny; ++j) for (i = 0; i < nx; ++i) {
         var lum = G ? G.v[j * nx + i] : 0.5; if (!(lum > 0.02)) continue;
         var q = [(L0.x0 + (i + 0.5) * (L0.x1 - L0.x0) / nx) * k, (L0.y0 + (j + 0.5) * (L0.y1 - L0.y0) / ny) * k, D];
         var dq = fvLabRelFly(fvSub(q, c.pos), L.S), dd = fvLen(dq); if (!(dd > 1e-9)) continue;
         var om = dx * dy * L.S * L.S * Math.abs(dq[2]) / (dd * dd * dd);
         var lr = (G && G.raw) ? G.raw[j * nx + i] * (c.pos[2] > D ? CF.BEHIND_K : 1) : 0.5;   // luz PINTADA (absoluta; desde detras, la foto se pinta mas tenue)
         add(dq, CF.NEB_K * lum * Math.min(om, CF.OM_CELL) / CF.OM_CELL, om * (lr >= CF.LUM_SEEN ? 1 : 0));
      }
   }
   var r = fvLen(R); L.cdT = P.t; L.cdR = Wt > 0 ? r / Wt : 0;
   L.cd = (Wt > 0 && r / Wt >= CF.MIN_R) ? fvMul(R, 1 / r) : null;
   // ¿se veria algo mirando a cd? (lo que cuenta el instrumento: >= 12 estrellas o >= 5 % de nebulosa en la vista); si no, se mira al destino
   // (el destino en cuadro es referencia: K2)
   L.cdOk = false;
   if (L.cd) {
      var cosH = Math.cos(Math.min(1.45, 0.6 * c.fov)), nS = 0, om = 0, omF = 2 * Math.PI * (1 - Math.cos(0.5 * c.fov));
      for (i = 0; i < IT.length; ++i) if (fvDot(IT[i][0], L.cd) > cosH) { if (IT[i][1]) ++nS; else om += IT[i][2]; }
      L.cdOk = nS >= CF.MIN_STARS || om / omF >= CF.MIN_NEB; L.cdN = nS; L.cdNeb = om / omF;
   }
   return L.cd;
}
function fvLabContentOn() { return !!(FV_LAB.CONTENT && FV_LAB.CONTENT.ON); }
function fvLabAimW(B, want, W, A, fast) {
   var f = B.f, wn = fvNorm(want), ax = fvCross(f, wn), s = fvLen(ax), c = fvDot(f, wn), th = Math.atan2(s, c), e;
   if (s > 1e-12) e = fvMul(ax, th / s); else e = (c < 0) ? fvMul(B.d, Math.PI) : [0, 0, 0];
   // (v3) GIRO PLANO: fuera de los polos, el giro se reparte en guiñada alrededor de la vertical del mundo y cabeceo alrededor de la derecha
   // horizontal: ninguno de los dos inclina el horizonte. El circulo maximo de la v2 no giraba la pantalla, pero en las medias vueltas de la
   // mirada al contenido dejaba el horizonte a 40–53° (tira H, 8-nov) y el enderezado a 2 °/s tardaba medio minuto
   var hf = Math.sqrt(f[0] * f[0] + f[2] * f[2]), hw = Math.sqrt(wn[0] * wn[0] + wn[2] * wn[2]), sp = Math.sin(FV_LAB.ROLL.POLE_DEG * FV_DEG);
   // Solo cerca del horizonte (las dos miradas por debajo de FLAT_LO..FLAT_HI de altura, con mezcla): ahi guiñar no gira la pantalla, y la media
   // vuelta casi opuesta del circulo maximo (eje mal definido) podia pasar por encima y volcar el horizonte
   var wF = FV_LAB.ROLL.FLAT ? fvSmooth((Math.sin(FV_LAB.ROLL.FLAT_HI * FV_DEG) - Math.max(Math.abs(f[1]), Math.abs(wn[1]))) / (Math.sin(FV_LAB.ROLL.FLAT_HI * FV_DEG) - Math.sin(FV_LAB.ROLL.FLAT_LO * FV_DEG))) : 0;
   if (wF > 0 && hf > 1e-9 && hw > 1e-9) {
      var dAz = Math.atan2(wn[0], wn[2]) - Math.atan2(f[0], f[2]); dAz = Math.atan2(Math.sin(dAz), Math.cos(dAz));
      var dEl = Math.asin(fvClamp(wn[1], -1, 1)) - Math.asin(fvClamp(f[1], -1, 1)), hz = [f[0] / hf, 0, f[2] / hf];
      e = fvAdd(fvMul(e, 1 - wF), fvMul(fvAdd([0, dAz, 0], fvMul(fvCross(hz, [0, 1, 0]), dEl)), wF));
   }
   var wd = fvLabSpringW(e, W, A), ro = fvLabRollOf(B);
   // (v3) en automatico el enderezado sube de 2 a AUTO_MAX_DPS (6 °/s) cuando el horizonte esta muy inclinado (> 10–30°): tras las medias vueltas
   // de la mirada al contenido quedaba a 40–53° y a 2 °/s tardaba medio minuto. El giro plano (FLAT) queda como opcion: endereza del todo pero
   // gira la pantalla al guiñar mirando alto (K5 hasta 55 °/s, 8-nov)
   if (ro.ok) { var cap = (fast ? FV_LAB.ROLL.LEVEL_DPS : FV_LAB.ROLL.AUTO_DPS + (FV_LAB.ROLL.AUTO_MAX_DPS - FV_LAB.ROLL.AUTO_DPS) * fvSmooth((Math.abs(ro.a) / FV_DEG - 10) / 20)) * FV_DEG, k = fast ? FV_LAB.ROLL.LEVEL_K : FV_LAB.ROLL.AUTO_K; wd = fvAdd(wd, fvMul(f, fvClamp(-k * ro.a, -cap, cap))); }
   return wd;
}
function fvLabSpringW(e, W, A) {
   var th = fvLen(e); if (th < 1e-12) return [0, 0, 0];
   var w = Math.min(W, Math.sqrt(2 * A * th) * 0.92, FV_LAB.LIN_K * th);
   return fvMul(e, w / th);
}
// integrar la rotacion un subpaso
function fvLabRotSub(P, h) {
   var L = P.lab, c = P.cam, wl = fvLen(L.w);
   if (wl > 1e-12) { c.B = fvLabOrtho(fvLabRotB(c.B, fvMul(L.w, 1 / wl), wl * h)); }
   c.look = c.B.f.slice();
   if (fvLab4On()) L.S = fvLabSEff(L, c.B.f);                  // (v4, R1) el S de la mirada nueva
}
// (v3) estelas, destello y fases del warp con el reloj de la PREPARACION (uw): con u las estelas subian con la nave aun quieta y el pintor trataba
// la vista como «fuera de casa» (trailAway): en M 82 apagaba 640 de 651 estrellas en casa (K1 warp 95 % frente a 86 % hoy). (v4) Comun a v3 y v4
// ---------------------------------------------------------------------------
// (19-nov-2026, W1; Nino: «el Warp va demasiado rapido y no da mucha sensacion de warp») EL WARP DEL LABORATORIO, MAS LENTO Y CON MAS SALTO.
// Medido (tests/_w1/fv_w1_measure.js, IC 1848, viajes de 1 300 a 8 600 a.l.): el vuelo duraba 4,8–5,3 s (6,5–6,9 s con el frenado); el efecto subia de 0 al
// maximo en 0,35 s (el 12 % del avance), con estelas 0,55 y warp 0,25 de un maximo de 1 (los efectos del pintor y del visor estan calibrados para
// 1: sin Doppler —se enciende con estela > 0,5—, polvo de warp a w² = 0,06, desenfoque radial a la mitad), campo fijo a 50° y destellos de 0,15 s.
// Ahora, con FV_W1.ON (de fabrica):
//   CARGA  (la parada de siempre, PREP = 18 % del viaje, ~1,2 s): las estrellas empiezan a estirarse (estela 0 → CH_TRAIL = 0,14: por encima el pintor
//          trata la vista como «fuera de casa», trailAway > 0,16, y vacia la foto) y un brillo crece en el punto de fuga (GLOW)
//   SALTO  (JUMP_S = 0,8 s, mientras la nave coge velocidad): estela 0,14 → TRAIL 0,95, warp → WARP 0,40, el campo se abre un 30 % (FOV_K: tunel), pulso de luz
//   CRUCERO estelas largas, Doppler (azul delante / rojo en los bordes: lo da el pintor con estela > 0,5), polvo de warp
//   SALIDA (desde el 74 % del avance, ~1,4 s): las rayas se recogen ANTES de que la nave pare (estela = fraccion^1,6, como el warp clasico), el campo vuelve,
//          pulso menor; las estrellas quedan en puntos al llegar
// y el viaje dura DUR_K × lo de antes (la distancia recorrida no cambia: la nave va mas despacio). FV_W1.ON = false = lo de antes (el ROJO de tests/_w1).
// Para PixInsight y para el visor web igual: ambos leen P.trail, P.warp, P.flash y cam.fov del motor.
// ---------------------------------------------------------------------------
var FV_W1 = { ON: true, DUR_K: 1.3, CH_TRAIL: 0.14, GLOW: 0.30, GLOW_S: 0.5, JUMP_S: 1.0, TRAIL: 0.95, WARP: 0.40, FOV_K: 0.26, EXIT_K: 1.6, EXIT_AT: 0.45,
              FLASH_JUMP: 1.0, FLASH_JUMP_S: 0.8, FLASH_EXIT: 0.55, FLASH_EXIT_S: 0.6, FLASH_UP: 0.3, FLASH_EXP: 3.5,
              // (20-nov, W1b) los defectos que vio el coordinador en W1-montaje.png; cada subbandera false = lo de W1
              //   FADE_ON  durante la CARGA la foto (capas, plano de foto, niebla, volumen web) se apaga con fadeW (0 → FADE_LOAD al final de la carga; el wFade del warp
              //            = 1 − 0,9·suave(fadeW / 0,6)): deja de verse como un recuadro flotante sobre el negro; en el salto cede a P.warp (fvWarpFadeW)
              //   DOP_ON   Doppler de PixInsight: mezcla DOP_A (0,22 → 0,75; FV_PAINT.WARP_DOPPLER) en las estelas de estrellas Y bandas azul/calido por radio en el polvo de warp (antes de colores al azar); solo PixInsight
              //   HALO_ON  el destello de la salida: mas bajo y mas corto (FLASH_EXIT_B / FLASH_EXIT_S_B), sin halo sobre la estrella al llegar
              //   SCALE_ON (20-nov, W1b con V1bc; solo cuando el viaje lleva presupuesto de V1: FV_V1.ON y CURVE) las fases escalan con la duracion REAL del warp tras el
              //            presupuesto. Con un warp corto (avance de 1,4 a 3,7 s en vez de los 3,7–8,6 s de W1) los tiempos fijos de W1 (salto 1 s, destello 0,8 s, brillo de carga
              //            0,5 s) se montaban unos sobre otros: la carga subia fadeW de 0 a 0,5 en 0,3 s (salto de 0,08 por fotograma) y el destello de la salida seguia en 0,23–0,28
              //            con las rayas ya recogidas. k = avance / SEC_REF (tope 1, suelo K_MIN) encoge el salto, el destello del salto y el brillo; el apagado de la foto NO se
              //            encoge (es lo que se ve a saltos): dura al menos FADE_MIN_S empezando antes en el giro previo (suave en vez de suavizado: pendiente 1,5); la recogida de las
              //            rayas de la salida dura al menos EXIT_MIN_S (empieza antes del 74 % del avance si hace falta: warp y fadeW bajan de 0,4 a 0 sin saltar); el destello de la
              //            salida dura como mucho EXIT_FLASH_K de esa recogida (acaba donde la estela baja de 0,1). Sin presupuesto de V1 (ON o CURVE a false) todo es lo de W1b de antes.
              FADE_ON: true, FADE_LOAD: 0.4, DOP_ON: true, DOP_A: 0.75, HALO_ON: true, FLASH_EXIT_B: 0.28, FLASH_EXIT_S_B: 0.35,
              SCALE_ON: true, SEC_REF: 3.7, K_MIN: 0.35, FADE_MIN_S: 0.7, EXIT_MIN_S: 0.5, EXIT_FLASH_K: 0.2,
              // (20-nov, H6) FADE_LOAD 0,5 → 0,4 (Nino: «la foto casi desaparece en la carga»): luz de la foto (wFade = 1 − 0,9·suave(fadeW / 0,6)) 17 % → 33 %; MEDIDO en fotogramas de PixInsight
              // (tests/_h20/h6_measure.py, luz media del fotograma al acabar la carga / en casa): Collinder 34 9,6 % → 18,5 %, M 82 6,0 % → 11,9 % (para el 33 % del fotograma haria falta 0,27 / 0,18:
              // depende de la foto, y con la foto al 60 % de luz vuelve el recuadro flotante de W1b #3)
              // el pintor de PixInsight pinta el nucleo del destello como el visor web (fw_viewer.js FW_W1.BALL_*): k·suave((k − BALL_LO) / (BALL_HI − BALL_LO)); BALL_ON false = el disco gris de la carga
              BALL_ON: true, BALL_LO: 0.25, BALL_HI: 0.75 };
// (W1b) la «velocidad de warp» con la que se calcula el apagado de la nebulosa (wFade = 1 − 0,9·suave(w / 0,6)): P.warp, y durante la carga y el salto el fadeW del vuelo
// (lo pone fvLabWarpFxW1). Sin vuelo de warp del laboratorio, o con FADE_ON false, es P.warp
function fvWarpFadeW(P) {
   var w = P.warp || 0, fl = P.flight;
   if (FV_W1.ON && FV_W1.FADE_ON && fl && fvIsWarpFl(fl) && fl.fadeW !== undefined && fl.fadeW > w) return fl.fadeW;
   return w;
}
// la duracion del movimiento de un warp (s, antes del regulador): la de siempre × DUR_K
function fvLabWarpDur(dec) {
   var Wd = FV_LAB.WARP, d = fvClamp(Wd.DUR0 + Wd.DUR_DEC * dec, Wd.DUR_MIN, Wd.DUR_MAX);
   return FV_W1.ON ? d * FV_W1.DUR_K : d;
}
// campana del destello (la forma de FVPilot: sube rapido el FLASH_UP, baja exponencial hasta 0 al final)
function fvLabW1Bump(x) {
   var W = FV_W1, up = W.FLASH_UP, e = Math.exp(-W.FLASH_EXP);
   if (x <= 0 || x >= 1) return 0;
   return (x < up) ? fvSmooth(x / up) : (Math.exp(-W.FLASH_EXP * (x - up) / (1 - up)) - e) / (1 - e);
}
// estela, warp, destello y fase del warp con W1 (P.trail, P.warp, P.flash los lee el pintor; cam.fov lo sigue fvLabFovStep)
function fvLabWarpFxW1(P, fl, pre, uw) {
   var W = FV_W1, X = fl.lab || {}, ps = X.prepS || 0, tm = fl.t - pre, dm = X.durMove || fl.dur, sec = (1 - FV_LAB.WARP.PREP) * dm;   // sec: segundos de avance (uw 0 → 1)
   // (W1b + V1bc) k: cuanto se encogen las fases fijas de W1 con un warp corto (1 sin presupuesto de V1: lo de siempre). SEC_REF = lo que dura el avance de un warp de W1 mas corto (DUR_MIN 3,5 × DUR_K 1,3 × 0,82)
   var kS = (W.SCALE_ON && X.bud) ? fvClamp(sec / W.SEC_REF, W.K_MIN, 1) : 1, scl = (W.SCALE_ON && X.bud), jumpS = W.JUMP_S * kS;
   var uwx = scl ? Math.min(0.74, 1 - W.EXIT_MIN_S / Math.max(sec, 1e-6)) : 0.74, xw = scl ? 1 - uwx : 0.26;       // donde empieza a recogerse la estela (el reparto del avance es el de siempre)
   var c = ps > 0 ? fvClamp(tm / ps, 0, 1) : 1, jj = fvSmoother(fvClamp((tm - ps) / jumpS, 0, 1)), ex = (uw > uwx) ? 1 - fvSmooth((uw - uwx) / xw) : 1;
   var tr, w;
   if (uw <= 0) { tr = W.CH_TRAIL * fvSmoother(c); w = 0; }
   else { tr = (W.CH_TRAIL + (W.TRAIL - W.CH_TRAIL) * jj) * Math.pow(ex, W.EXIT_K); w = W.WARP * jj * ex; }
   P.trail = tr; P.warp = w;
   // (W1b) el apagado de la foto en la carga: fadeW sube a FADE_LOAD con la carga, se mantiene en el salto y cede a P.warp al acabarlo (monotono: FADE_LOAD − (FADE_LOAD − P.warp)·s)
   // con presupuesto de V1 (scl) la subida no dura menos de FADE_MIN_S: empieza antes (durante el giro previo, desde el fotograma 0 como pronto) y es suave (pendiente 1,5, no 1,875)
   if (W.FADE_ON) {
      var lk;
      if (uw > 0) lk = 1 - jj;
      else if (!scl) lk = fvSmoother(c);
      else { var ce = (X.pre || 0) + ps, t0 = Math.max(0, ce - Math.max(ps, W.FADE_MIN_S)); lk = (ce > t0) ? fvSmooth((fl.t - t0) / (ce - t0)) : 1; }
      fl.fadeW = w * (1 - lk) + W.FADE_LOAD * lk;
   } else fl.fadeW = undefined;
   // el destello: brillo al final de la carga que se queda hasta el pulso del salto; pulso menor a mitad de la salida
   var gS = Math.min(W.GLOW_S * kS, Math.max(ps, 1e-6)), eS = W.HALO_ON ? W.FLASH_EXIT_S_B : W.FLASH_EXIT_S;
   if (scl && W.HALO_ON) eS = Math.min(eS, W.EXIT_FLASH_K * xw * sec);          // el destello de la salida acaba donde la estela baja de 0,1 (uw ~ 0,91): con un avance corto, mas estrecho
   var glow = W.GLOW * fvSmooth((tm - (ps - gS)) / gS) * (1 - fvSmooth((tm - ps) / (0.4 * kS))),
       fJ = W.FLASH_JUMP * fvLabW1Bump((tm - ps) / (W.FLASH_JUMP_S * kS)),
       fE = (W.HALO_ON ? W.FLASH_EXIT_B : W.FLASH_EXIT) * fvLabW1Bump(((uw - (uwx + xw * W.EXIT_AT)) * sec) / eS);
   P.flash = Math.max(P.flash, glow, fJ, fE);
   fl.warpPhase = (uw <= 0) ? "prep" : (jj < 1 ? "jump" : (uw < 0.74 ? "cruise" : "exit")); fl.phaseT = fl.t; fl.phaseDur = fl.dur;
}
function fvLabWarpFx(P, fl, pre, uw) {
   if (FV_W1.ON) return fvLabWarpFxW1(P, fl, pre, uw);
   var sf = fvLabSpeedFrac(uw); P.trail = FV_LAB.WARP.TRAIL * sf; P.warp = FV_LAB.WARP.WARP * sf;
   var uOf = function(x) { return FV_LAB.WARP.PREP + x * (1 - FV_LAB.WARP.PREP); };
   var tj = pre + uOf(0.12) * (fl.dur - pre), te = pre + uOf(0.74) * (fl.dur - pre), fs = FV_LAB.WARP.FLASH_S;
   if (Math.abs(fl.t - tj) < fs / 2 || Math.abs(fl.t - te) < fs / 2) P.flash = Math.max(P.flash, 1 - Math.min(Math.abs(fl.t - tj), Math.abs(fl.t - te)) / (fs / 2));
   fl.warpPhase = (uw <= 0) ? "prep" : (uw < 0.04 ? "jump" : (uw < 0.74 ? "cruise" : "exit")); fl.phaseT = fl.t; fl.phaseDur = fl.dur;
}
// un subpaso de un viaje automatico: posicion por la trayectoria objetivo; orientacion hacia la mirada objetivo con los topes
function fvLabAutoSub(P, h, Q) {
   var fl = P.flight, X = fl.lab, L = P.lab, c = P.cam;
   fl.t += h;
   if (X.legs) return fvLabPathSub(P, h, Q);
   if (X.v4) return fvLab4AutoSub(P, h, Q);                         // (v4) viaje casi recto con el destino en pantalla
   var pre = X.pre || 0, u = (fl.dur > pre) ? fvClamp((fl.t - pre) / (fl.dur - pre), 0, 1) : 1, pOld = c.pos.slice();
   if (X.pc) {
      // (v2, K1 warp) el warp se queda quieto la preparacion (PREP del viaje, como el de hoy: el paisaje de salida sigue en pantalla) y luego salta
      var uw = fvIsWarpFl(fl) ? fvClamp((u - FV_LAB.WARP.PREP) / (1 - FV_LAB.WARP.PREP), 0, 1) : u;      // (N-galaxias-warp) fvIsWarpFl: tambien la vuelta a casa desde una galaxia (fl.gwHome)
      var x = fvCineX(uw), s = fvLabSOfTau(X.pc, x), p = X.pc.fn(s);
      if (X.tb > 0 && fl.t < X.tb) { var q = fl.t / X.tb, bt = fvMul(X.v0, X.tb / 3 * (1 - Math.pow(1 - q, 3))); p = fvAdd(p, fvSub(bt, X.Bv)); }
      if (!(isFinite(p[0]) && isFinite(p[1]) && isFinite(p[2]))) p = c.pos.slice();
      // (v3, 7) nunca mas cerca del destino que la distancia de llegada (el arco y la frenada podian rozarlo: 11 de 704 viajes en la v2)
      if (fl.T && X.dA > 0 && fl.kind !== "home") { var eT = fvSub(p, fl.T), lT = fvLen(eT); if (lT < X.dA && lT > 1e-12) p = fvAdd(fl.T, fvMul(eT, X.dA / lT)); }
      c.pos = p;
      L.v = fvMul(fvSub(c.pos, pOld), 1 / h);
      fl.phase = (u < 0.12) ? "depart" : (u < 0.74 ? "cruise" : "arrive");
      if (fvIsWarpFl(fl)) fvLabWarpFx(P, fl, pre, uw);
   }
   // la mirada objetivo (§7.4.2): el destino; si destino y K se separan > 75° vistos desde la nave, K (vuelve por debajo de 60°); mezcla de 2 s
   var tc = FV_LAB.TURN[fl.kind] || FV_LAB.TURN.cine, W = tc[0] * FV_DEG, A = tc[1] * FV_DEG, want;
   if (fl.kind === "look") want = X.lookT;
   else if (fl.kind === "home") want = [0, 0, 1];
   else if (fl.t < pre) {                                      // el giro previo: hacia donde se va a salir
      want = X.dirOut;
      // (v2, K1 FF) si hacia la salida no hay foto (con S alto, salir de lado es mirar fuera de la piramide), se gira hacia K hasta
      // K_VF_BLACK de la salida como mucho (mirar por la ventanilla, no de espaldas)
      if (X.K && fvLen(fvSub(X.K, c.pos)) > 1e-9 && !fvLabSeesSlab(P, c.pos, X.dirOut, L.S)) {
         var dK0 = fvNorm(fvLabRelFly(fvSub(X.K, c.pos), L.S)), aK0 = fvAngle(X.dirOut, dK0) / FV_DEG;
         if (aK0 > 1) want = fvSlerpDir(X.dirOut, dK0, Math.min(1, FV_LAB.LOOK.K_VF_BLACK / aK0));
      }
   }
   else {
      var dT = fvNorm(fvLabRelFly(fvSub(X.Tl, c.pos), L.S)), dK = fvLen(fvSub(X.K, c.pos)) > 1e-9 ? fvNorm(fvLabRelFly(fvSub(X.K, c.pos), L.S)) : dT;
      // (v2, K1) si mirando al destino no hay foto detras (la visual no corta la losa dentro de la piramide), K entra antes (40°, sale a 30°)
      var blackT = !fvLabSeesSlab(P, c.pos, dT, L.S), kIn = blackT ? FV_LAB.LOOK.K_IN_BLACK : FV_LAB.LOOK.K_IN, kOut = blackT ? FV_LAB.LOOK.K_OUT_BLACK : FV_LAB.LOOK.K_OUT;
      var aTK = fvAngle(dT, dK) / FV_DEG, onK = X.lookOnK ? aTK > kOut : aTK > kIn;
      if (P.scene.nebula && Math.abs(c.pos[2] - P.scene.nebula.distLy) < 1.5 * P.scene.nebula.thickLy) onK = false;   // cruzando la losa K queda de lado (K2)
      // (laboratorio) K solo si queda por delante del movimiento: mirar a la losa que se deja atras es volar de espaldas (K9; §7.4.3 lo daba por dudoso)
      var vF = fvLen(L.v) > 0 ? fvNorm(fvLabRelFly(L.v, L.S)) : null;
      var dolly = FV_LAB.LOOK.DOLLY && dT[2] < 0 && (X.lookOnK ? aTK > FV_LAB.LOOK.DOLLY_OUT : aTK > FV_LAB.LOOK.DOLLY_IN);   // solo con el destino hacia la Tierra (hacia fuera, mirar al destino deja el destino en cuadro: K2)
      if (onK && !dolly && vF && fvAngle(dK, vF) / FV_DEG > (blackT ? FV_LAB.LOOK.K_VF_BLACK : FV_LAB.LOOK.K_IN)) onK = false;   // (v2, K1 FF) con negro hacia el destino se admite mirar de lado (ventanilla), no de espaldas
      // giro final: cuando queda el tiempo justo para girar a la mirada final, se mira al destino pase lo que pase
      var tLeft = fl.dur - fl.t, need = fvAngle(c.B.f, dT) / W + W / A;
      var dollyEnd = dolly && X.d7 && !X.arcFallback;               // con la llegada D7 la nave acaba del lado de la Tierra mirando hacia fuera: no hace falta el giro final
      if (!dollyEnd && (tLeft < need + 0.5 || u > 0.8)) onK = false;
      // D7: en la zona del arco se mira al destino (con K el destino salia de cuadro en el barrido: K8, c5 HB 25 %), salvo con el destino hacia la Tierra
      if (!dollyEnd && fvLen(fvSub(X.Tl, c.pos)) < (blackT ? FV_LAB.LOOK.ZONE_BLACK_K : 1) * 1.2 * (X.rFar || FV_LAB.ARC.R_FAR) * X.dA) onK = false;
      if (onK !== X.lookOnK) { X.blend = { t: 0, from: X.wantPrev || c.B.f.slice() }; X.lookOnK = onK; }
      want = onK ? dK : dT;
      // (v2, K1) con S alto, el destino de al lado se mira de canto y se ve el negro de fuera del cono: se inclina hacia K sin sacar el destino del cuadro
      if (!onK && FV_LAB.LOOK.BIAS_K > 0 && aTK > 1) { var bA = Math.min(aTK * FV_DEG, FV_LAB.LOOK.BIAS_K * 0.5 * c.fov); want = fvSlerpDir(dT, dK, bA / (aTK * FV_DEG)); }
      // (v3) MIRADA AL CONTENIDO: el morro al centro de lo visible (aunque sea de espaldas); dentro de la losa (SLAB_K grosores) y en el giro final, al
      // destino. El cambio de una mirada a otra pasa por la mezcla de 2 s y los topes de giro y de aceleracion angular (sin medias vueltas de golpe)
      if (fvLabContentOn() && fl.kind !== "home") {
         var Nn = P.scene.nebula, cd = fvLabContentDir(P), inSlab = !!(Nn && Math.abs(c.pos[2] - Nn.distLy) < FV_LAB.CONTENT.SLAB_K * Nn.thickLy);
         var cMode = (!cd || !L.cdOk || inSlab || tLeft < need + 0.5 || u > 0.8) ? "dest" : "content";
         if (cMode !== X.cMode) { if (X.cMode !== undefined) X.blend = { t: 0, from: X.wantPrev || c.B.f.slice() }; X.cMode = cMode; }
         want = (cMode === "content") ? cd : dT;
      }
      if (X.blend) { X.blend.t += h; var bw = fvSmooth(X.blend.t / FV_LAB.LOOK.BLEND_S); want = fvSlerpDir(X.blend.from, want, bw); if (bw >= 1) X.blend = null; }
   }
   X.wantPrev = want;
   var wd = fvLabAimW(c.B, want, W, A, false), dw = fvSub(wd, L.w), dl = fvLen(dw), cap = A * h;
   L.w = (dl > cap) ? fvAdd(L.w, fvMul(dw, cap / dl)) : wd;
   if (fl.t >= fl.dur) fvLabArrive(P);
}
// un subpaso de la ruta del editor (tramos de la misma ley)
function fvLabPathSub(P, h, Q) {
   var fl = P.flight, X = fl.lab, L = P.lab, c = P.cam, legs = X.legs, k = 0;
   while (k < legs.length - 1 && fl.t > legs[k].t0 + legs[k].dur + legs[k].hold) ++k;
   var lg = legs[k], u = fvClamp((fl.t - lg.t0) / lg.dur, 0, 1), pOld = c.pos.slice();
   fl.keyIdx = k; fl.phase = u < 1 ? (u < 0.12 ? "depart" : (u < 0.74 ? "cruise" : "arrive")) : "hold";
   c.pos = fvLerp(lg.p0, lg.p1, fvSmoother(u));
   L.v = fvMul(fvSub(c.pos, pOld), 1 / h);
   var tc = FV_LAB.TURN.path, W = tc[0] * FV_DEG, A = tc[1] * FV_DEG;
   var lk = lg.look;
   if (fvLabContentOn() && u < 0.8) { var cdP = fvLabContentDir(P), Np = P.scene.nebula; if (cdP && L.cdOk && !(Np && Math.abs(c.pos[2] - Np.distLy) < FV_LAB.CONTENT.SLAB_K * Np.thickLy)) lk = cdP; }   // (v3) la ruta tambien mira al contenido mientras se mueve; la toma de la llave al llegar
   var wd = fvLabAimW(c.B, lk, W, A, false), dw = fvSub(wd, L.w), dl = fvLen(dw), cap = A * h;
   L.w = (dl > cap) ? fvAdd(L.w, fvMul(dw, cap / dl)) : wd;
   X.fovKey = lg.fov;
   if (fl.t >= fl.dur) fvLabArrive(P);
}
// llegar: sin pose de golpe (§13 «se tira» la de :3389). La nave queda donde la trayectoria acaba (A) y la mirada sigue al destino
function fvLabArrive(P) {
   var fl = P.flight, X = fl.lab, L = P.lab, c = P.cam;
   if (X && X.A && !X.legs) c.pos = X.A.slice();
   L.v = [0, 0, 0]; P.warp = 0; P.trail = 0;
   P.flight = null; fl.phase = null;
   if (fl.kind === "path") fl.keyIdx = fl.nKeys - 1;
   if (fl.kind === "home") { P.arrivedAt = null; c.pos = [0, 0, 0]; L.hold = { home: true }; P.mode = "free"; }
   else if (fl.kind === "look" || fl.kind === "path") { P.mode = "free"; }
   else { P.mode = "free"; P.arrivedAt = fl.sel; if (X && X.Tl && !X.v4) L.hold = { p: X.Tl.slice() }; }   // (v4) sin «giro final tras llegar»: se llega parado
   P.lookState = { x: c.look.slice(), v: [0, 0, 0] };
   P.events.push({ t: P.t, what: "arrive-" + fl.kind });
   if (typeof P.onFlightEnd === "function") { try { P.onFlightEnd(P, fl); } catch (eEnd) {} }
}
// el campo de la lente (D2 / §8)
function fvLabFovStep(P, dt, Q) {
   var L = P.lab, c = P.cam, fl = P.flight, lens = FV_LAB.LENS_DEG * FV_DEG, tgt;
   var atHome = fvLen(c.pos) < 1e-9 && (!fl || fl.kind === "home");
   if (fl && fl.kind === "home" && fl.lab && fl.lab.pc) {
      // la vuelta a casa: el campo vuelve al de casa con el avance (en log), exacto al llegar
      var u = fvClamp(fl.t / fl.dur, 0, 1); c.fov = Math.exp(fvMix(Math.log(fl.lab.fovH0), Math.log(P.homeFov), fvSmoother(fvCineX(u)))); return;
   }
   if (fl && fl.lab && fl.lab.legs && fl.lab.fovKey) tgt = fl.lab.fovKey;
   else if (P.mode === "home" || (atHome && L.hold && L.hold.home)) tgt = P.homeFov;
   else tgt = lens;
   // (W1) en el warp el campo se abre hasta FOV_K e-folds (+30 %) con el efecto (P.warp / WARP): vision de tunel; ritmo maximo FOV_RATE como siempre
   if (FV_W1.ON && fl && fl.kind === "warp" && P.warp > 0) tgt = Math.min(FV_PILOT.MAX_FOV, tgt * Math.exp(FV_W1.FOV_K * fvClamp(P.warp / FV_W1.WARP, 0, 1)));
   if (L.teleOn) {
      // TELESCOPIO: lente / aumento, sin pasar del limite de resolucion (3 px de pantalla por texel de capa, §6.2)
      var N = P.scene.nebula, fT = lens / L.tele;
      if (N && N.layers && N.layers.length) {
         var L0 = N.layers[0], tex = (L0.x1 - L0.x0) / L0.z * N.distLy / 2048, dz = Math.max(1e-6, Math.abs(N.distLy - c.pos[2]));
         var fMin = 2 * Math.atan(P.VW * L.S * tex / dz / (2 * FV_LAB.TELE_MAG)); fT = Math.max(fT, fMin);
      }
      tgt = Math.min(tgt, fT);
   }
   var lnF = Math.log(c.fov), lnT = Math.log(tgt), d = lnT - lnF;
   if (Math.abs(d) < 1e-9) { c.fov = tgt; return; }
   var step = fvClamp(d / 0.8, -FV_LAB.FOV_RATE, FV_LAB.FOV_RATE) * dt;
   if (Math.abs(step) >= Math.abs(d)) c.fov = tgt; else c.fov = Math.exp(lnF + step);
}
// lo comun al final de cada paso: rotulo de modo, medidas de la cabina, ancla, marca de lo escrito
function fvLabFinish(P, dt, prev) {
   var c = P.cam, L = P.lab;
   if (fvLab4On()) L.S = fvLabSEff(L, c.B.f);                  // (v4, R1) tras el raton (mirar u orbitar) tambien
   c.look = c.B.f.slice(); c.roll = 0; c.S = L.S;
   if (!P.flight && P.mode === "flight") P.mode = "free";
   if (!P.flight && P.mode === "home" && fvLen(c.pos) > 1e-9) P.mode = "free";
   fvLabNavMode(P);
   if (dt > 0) {
      P.vel = fvMul(fvSub(c.pos, prev), 1 / dt); P.speedLyS = fvLen(P.vel);
      // (v3, 8) VELOCITAS muestra la velocidad VISTA (la del espacio de vuelo, la que corre la imagen), suavizada: con S alto la real cambia hasta x S al
      // girar de lado sin que la imagen cambie (el estiramiento lateral), y la cifra saltaba. P.speedLyS sigue siendo la real
      var vSee = fvLen(fvLabRelFly(P.vel, L.S)); L.vShow = (L.vShow === undefined || !isFinite(L.vShow)) ? vSee : L.vShow + (vSee - L.vShow) * (1 - Math.exp(-dt / FV_LAB.SPEED_SHOW_S));
      P.speedC = L.vShow * FV_PILOT.SEC_PER_YEAR;
      P.odo += fvLen(fvSub(c.pos, prev));
      var at = L.anchorOn ? 1 : 0; L.anchor += (at - L.anchor) * (1 - Math.exp(-dt / FV_LAB.ANCHOR_FADE_S));
   }
   if (P.wheel !== undefined) P.wheel = fvLen(L.v);
   if (fvV1On("AIDS")) fvV1Aids(P, dt);                       // (V1a, V1-10) fraccion del tope para la aguja y la reticula
   if (P.arrivedAt) { var pa = fvSelPos(P, P.arrivedAt); if (pa && fvLen(fvSub(pa, c.pos)) > 4 * fvArriveDist(P, P.arrivedAt) && !P.flight) P.arrivedAt = null; }
   fvLabMark(P);
}
// D8 · Foto / Espacio solo como rotulo: Espacio = mas alla de la cara delantera de la losa o fuera de la piramide
function fvLabNavMode(P, Q) {
   if (!P.scene.nebula) return;
   Q = Q || fvLabGeo(P);
   var c = P.cam, sp = c.pos[2] > Q.G.zIn || !fvLabInside(Q, c.pos, 1.0) || (P.flight && P.flight.T && P.flight.T[2] > Q.G.zIn);
   if (P.flight && P.flight.kind === "home") sp = c.pos[2] > Q.G.zIn || !fvLabInside(Q, c.pos, 1.0);
   P.navMode = sp ? "space" : "photo"; P.navPending = null; P.navReturn = null;
}
// D10 · el ancla: la pide la cabina cuando el ultimo fotograma no tenia paisaje (estrellas pintadas, nebulosa en pantalla) o fuera de la piramide
function fvLabAnchorWant(P, st, cover) {
   if (!P.lab) return false;
   var Q = fvLabGeo(P), out = !fvLabInside(Q, P.cam.pos, 1.0) && fvLen(P.cam.pos) > 1e-9;
   var land = (st && st.stars >= FV_LAB.ANCHOR_STARS) || cover >= FV_LAB.ANCHOR_COVER;
   P.lab.anchorOn = FV_LAB.ANCHOR && P.mode !== "home" && !land;     // (v2) con paisaje el ancla se apaga siempre (v1: tambien fuera de la caja, y tapaba el paisaje al llegar)
   P.lab.land = land; P.lab.out = out; P.lab.cover = cover;   // (v5) cover: la foto en pantalla (para la media vuelta)
   return P.lab.anchorOn;
}

// ---------------------------------------------------------------------------
// EL PROYECTOR con la base completa y S (lo llama fvProjector cuando cam.B existe)
// ---------------------------------------------------------------------------
function fvLabProjector(cam, VW, VH) {
   var B = cam.B, f = (VW / 2) / Math.tan(cam.fov / 2), cx = VW / 2, cy = VH / 2, px = cam.pos, S = cam.S || 1;
   var r0 = B.r[0], r1 = B.r[1], r2 = B.r[2], d0 = B.d[0], d1 = B.d[1], d2 = B.d[2], f0 = B.f[0], f1 = B.f[1], f2 = B.f[2];
   return { B: { f: B.f.slice(), r: B.r.slice(), d: B.d.slice() }, f: f, cx: cx, cy: cy, W: VW, H: VH, pos: px, roll: 0, S: S,
            r: [r0, r1, r2], d: [d0, d1, d2], fw: [f0, f1, f2],
            project: function(p, near) {
               var vx = S * (p[0] - px[0]), vy = S * (p[1] - px[1]), vz = p[2] - px[2];
               var zc = vx * f0 + vy * f1 + vz * f2;
               if (!(zc > (near || 1e-9))) return null;
               return [cx + f * (vx * r0 + vy * r1 + vz * r2) / zc, cy + f * (vx * d0 + vy * d1 + vz * d2) / zc, zc];
            } };
}
