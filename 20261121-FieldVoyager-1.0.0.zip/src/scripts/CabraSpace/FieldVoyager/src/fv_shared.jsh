// ============================================================================
// FieldVoyager/src/fv_shared.jsh — LO QUE SE REUTILIZA: cabeceras de PJSR, ImageSolver en modo libreria y CabraShared
// ----------------------------------------------------------------------------
// CabraShared se INCLUYE (no se copia): Gaia local o por red, astrometria, campo de estrellas con distancias, nebulosas
// de Sharpless con su distancia de catalogo. Mismo orden que Cabra3D.js (README de CabraShared). FieldVoyager no edita
// nada de CabraShared. ES5.
// ============================================================================
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/PenStyle.jsh>
#include <pjsr/PenCap.jsh>
#include <pjsr/RBFType.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/CompositionOp.jsh>
#include <pjsr/KeyCodes.jsh>

// ImageSolver en modo LIBRERIA (AstrometricMetadata, ImageSolver), como Cabra3D.js. SETTINGS_MODULE tiene que ser un LITERAL.
// (21-nov-2026, PKG-FV, revision PTeam CPD punto 3) SETTINGS_MODULE propio del producto: con «ImageSolver» a secas el boton de reset del
// dialogo de la libreria BORRARIA los ajustes del ImageSolver del usuario (medido con centinela, CabraBase/pjsr/lo-que-el-pteam-rechazo-en-pi-workflow.md).
// La configuracion del solver sigue siendo la de ImageSolver (SOLVER_SETTINGS_MODULE, la fija ImageSolver.js). STAR_CSV_FILE ya no se define
// (ImageSolver 6.6 no usa esa macro: ImageSolverEngine.js pone su propio fichero temporal; igual que Cabra3D.js).
#define SETTINGS_MODULE "FieldVoyager_ImageSolver"
#define USE_SOLVER_LIBRARY
#include <../src/scripts/ImageSolver/ImageSolver.js>
#undef USE_SOLVER_LIBRARY

#include "host/fv_host.js"
#include "../CabraShared/csh_i18n.js"
#include "../CabraShared/csh_atlas.js"
#include "../CabraShared/csh_net.js"
#include "../CabraShared/csh_vizier.js"
#include "../CabraShared/csh_batch.js"
#include "../CabraShared/csh_netfail.js"
#include "../CabraShared/csh_astrometry.js"
#include "../CabraShared/csh_starfield.js"
#include "../CabraShared/csh_gaia.js"
#include "../CabraShared/csh_thirdparty.js"
#include "../CabraShared/csh_starfield_run.js"
// (21-nov-2026, P7, decision de Nino) el catalogo de regiones HII WISE (Anderson et al. 2014, VizieR J/ApJS/212/1) NO se baja en FieldVoyager: su licencia
// de redistribucion no esta verificada (docs/auditoria-reglas-cpd.md 13.2). cshTpNebulaeText (CabraShared, que no se edita) arma el catalogo de
// nebulosas con tres tablas; quitando «wise» de CSH_TP, cshTpFetch("wise") contesta «unknown» SIN tocar la red y el catalogo sale «partial»
// (Sharpless + Foster-Brunt; la distancia de WISE no entra en la cadena de candidatas de cpSfNebulaPick). Los demas scripts de CabraScripts no cambian.
if (typeof CSH_TP !== "undefined" && CSH_TP.wise) delete CSH_TP.wise;
// (21-nov-2026, PKG-final) el aviso de la consola «** Emission nebulae without some distances: wise: unknown» salia en CADA escena: esa ausencia es intencionada (arriba) y el usuario no puede
// hacer nada con ella. fvTpSayFilter quita SOLO «wise: unknown» de la lista del aviso (el aviso entero si era lo unico) y deja pasar tal cual todo lo demas: cualquier otro catalogo que falte
// (Sharpless, Foster-Brunt…) y cualquier otro mensaje de CabraShared siguen avisando. CabraShared no se toca: se envuelve cshTpSay (se llama por su nombre global en cada aviso).
function fvTpSayFilter(s) {
   var m = /^(Emission nebulae without some distances: )(.*)$/.exec(String(s));
   if (!m) return s;
   var keep = m[2].split(" · ").filter(function(x) { return x !== "wise: unknown"; });
   return keep.length === 0 ? null : m[1] + keep.join(" · ");
}
if (typeof cshTpSay === "function" && typeof FV_TPSAY_ORIG === "undefined") {
   var FV_TPSAY_ORIG = cshTpSay;
   cshTpSay = function(s) { var f = fvTpSayFilter(s); if (f !== null) FV_TPSAY_ORIG(f); };
}
// (3b, 20-nov) el catalogo Hipparcos y sus nombres (los usa src/build/fv_hipdist.js: la distancia de las brillantes que Gaia no mide y el rotulo de la estrella)
#include "../CabraShared/csh_hipnames.js"
// (nF2, decision de Nino 4-nov: «solo pintar las estrellas de la imagen») el Bloque G: poda las estrellas Gaia que la foto no detecta
#include "../CabraShared/csh_depth.js"
#include "../CabraShared/csh_depth_run.js"
#include "../CabraShared/csh_dust.js"
// (F2) el modulo cientifico (puro, EN/ES): src/science/README.md
#include "science/fv_science.jsh"
