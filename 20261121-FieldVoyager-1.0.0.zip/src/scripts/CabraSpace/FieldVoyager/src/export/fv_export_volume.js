// ============================================================================
// FieldVoyager/src/export/fv_export_volume.js — EL VOLUMEN D9 de la nebulosa (puro: sin PixInsight) (4-nov-2026, F3)
// ----------------------------------------------------------------------------
// De la foto SIN estrellas a una textura 3D de EMISION (nx × ny × nz) que el visor WebGL2 recorre por raymarching.
//
// GEOMETRIA (la de las capas de F1, en continuo): el volumen es el TRONCO DE PIRAMIDE que desde la Tierra cubre la foto entre
// z0 = d − grosor/2 y z1 = d + grosor/2 (años luz). Un punto del mundo (x, y, z) cae en el voxel
//     u = (x/z)·F/W + 0,5      v = (y/z)·F/H + 0,5      w = (z − z0)/(z1 − z0)
// (F = focal de la foto en pixeles). Asi cada rayo que sale de la Tierra es UNA columna (u, v) fija del volumen: desde casa,
// la integral de la emision a lo largo de la columna ES el pixel de la foto sin estrellas (se normaliza para que lo sea).
//
// EL RELIEVE ES SUPUESTO (dicho en la escena y en pantalla). Lo que se inventa, y de donde sale cada cosa:
//   · profundidad del centro de la emision en cada columna, c(u, v) ∈ [0,2; 0,8]: la puntuacion de banda de F1 (0,65·brillo +
//     0,35·rojez, lo brillante y rojo —Hα— delante, lo azul —OIII— detras) suavizada a DOS escalas sacadas de la propia imagen
//     (gran escala ≈ 1/14 del ancho y escala media de 3 voxeles). NADA de ruido inventado: el «ruido de baja frecuencia» es la
//     propia imagen suavizada;
//   · grosor del perfil en profundidad, s(u, v) = 0,05–0,18 del grosor total: lo brillante (frentes de ionizacion) delgado, lo
//     tenue y difuso ancho;
//   · perfil gaussiano en w, entero dentro del tronco (sin cortes en las caras de delante y detras: no se ven los bordes de la caja);
//   · en el nucleo del perfil la emision lleva el detalle de la foto; en las colas, la foto suavizada (de canto se ve volumen, no
//     laminas);
//   · absorcion: densidad = SIGMA · luminancia de la emision; la emision se precompensa columna a columna para que desde la Tierra,
//     con la absorcion, salga exactamente la foto (L' = −ln(1 − σL)/σ);
//   · borde suave del 2 % en u y v (el mismo de las capas de F1).
// CODIFICACION: atlas 2D de cortes (corte k en la baldosa (k mod tilesX, k div tilesX)), RGB de 8 bits con raiz cuadrada
// (v = 255·√(e/EMAX)): mas niveles en lo tenue, donde estarian las bandas. El visor la sube como TEXTURE_3D.
// ES5. La prueba en node: tests/web/fv_f3_volume_node.js.
// ============================================================================

var FV_VOL = {
   NX: 192, NZ: 128,          // voxeles a lo ancho y en profundidad (ny sale del aspecto de la foto)
   SIGMA: 0.30,               // absorcion por unidad de luminancia y de grosor (adimensional; con L ≤ 1, τ ≤ 0,3)
   C_LF: 0.22, C_MF: 0.08,    // relieve: amplitud del centro por la escala grande y por la media (en fraccion del grosor)
   S_MIN: 0.05, S_MAX: 0.18,  // ancho del perfil (sigma, fraccion del grosor)
   EDGE: 0.02,                // borde suave en u, v (fraccion del lado)
   TAPER: 0.08,               // y en w: el perfil se apaga del todo en las caras de delante y detras (no se ve la caja)
   CLIP_PCT: 0.9995           // EMAX = este percentil de la emision (lo de encima se recorta: se cuenta en stats)
};

function fvxClamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fvxSmooth(t) { t = fvxClamp(t, 0, 1); return t * t * (3 - 2 * t); }
function fvxSmoothstep(a, b, x) { return fvxSmooth((x - a) / (b - a)); }

// suavizado de caja separable, tres pasadas (≈ gaussiana de sigma ≈ r)
function fvxBlur(a, W, H, r) {
   if (r < 1) return Float32Array.from(a);
   var src = Float32Array.from(a), tmp = new Float32Array(W * H), x, y, s, n = 2 * r + 1;
   for (var pass = 0; pass < 3; ++pass) {
      for (y = 0; y < H; ++y) { var o = y * W; s = 0; for (x = -r; x <= r; ++x) s += src[o + fvxClamp(x, 0, W - 1)]; for (x = 0; x < W; ++x) { tmp[o + x] = s / n; s += src[o + Math.min(W - 1, x + r + 1)] - src[o + Math.max(0, x - r)]; } }
      for (x = 0; x < W; ++x) { s = 0; for (y = -r; y <= r; ++y) s += tmp[fvxClamp(y, 0, H - 1) * W + x]; for (y = 0; y < H; ++y) { src[y * W + x] = s / n; s += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x]; } }
   }
   return src;
}
// rango (0..1) de cada valor dentro de la distribucion (cuantil empirico con 1024 cubos)
function fvxRank(a) {
   var n = a.length, s = [], i;
   for (i = 0; i < n; i += Math.max(1, Math.floor(n / 20000))) s.push(a[i]);
   s.sort(function(p, q) { return p - q; });
   var out = new Float32Array(n), m = s.length;
   for (i = 0; i < n; ++i) {
      var lo = 0, hi = m; while (lo < hi) { var mid = (lo + hi) >> 1; if (s[mid] < a[i]) lo = mid + 1; else hi = mid; }
      out[i] = lo / m;
   }
   return out;
}

// px: Uint32Array ARGB (la foto sin estrellas) W × H. o: { nx, nz, spoil: "mirror" (control EN ROJO: el volumen en espejo) }
// -> { nx, ny, nz, tilesX, tilesY, atlasW, atlasH, atlas (Uint32Array ARGB del atlas), emax, sigma, params, stats }
function fvVolumeBuild(px, W, H, o) {
   o = o || {};
   var t0 = Date.now(), nx = o.nx || FV_VOL.NX, ny = Math.max(8, Math.round(nx * H / W)), nz = o.nz || FV_VOL.NZ, N2 = nx * ny, i, x, y, k;
   // 1. la foto sin estrellas reducida por promedio de area (0..1)
   var R = new Float32Array(N2), G = new Float32Array(N2), B = new Float32Array(N2), cnt = new Float32Array(N2);
   for (y = 0; y < H; ++y) {
      var vy = Math.min(ny - 1, Math.floor(y * ny / H)), row = y * W;
      for (x = 0; x < W; ++x) {
         var vx = Math.min(nx - 1, Math.floor(x * nx / W)), j = vy * nx + vx, p = px[row + x];
         R[j] += ((p >>> 16) & 255) / 255; G[j] += ((p >>> 8) & 255) / 255; B[j] += (p & 255) / 255; cnt[j] += 1;
      }
   }
   for (i = 0; i < N2; ++i) { var c0 = cnt[i] || 1; R[i] /= c0; G[i] /= c0; B[i] /= c0; }
   if (o.spoil === "mirror") {          // CONTROL EN ROJO: la imagen en espejo horizontal antes de construir
      for (y = 0; y < ny; ++y) for (x = 0; x < nx >> 1; ++x) { var a1 = y * nx + x, a2 = y * nx + (nx - 1 - x), tt;
         tt = R[a1]; R[a1] = R[a2]; R[a2] = tt; tt = G[a1]; G[a1] = G[a2]; G[a2] = tt; tt = B[a1]; B[a1] = B[a2]; B[a2] = tt; }
   }
   // 2. puntuacion de banda (la de F1) a dos escalas y brillo
   var L = new Float32Array(N2), Rd = new Float32Array(N2);
   for (i = 0; i < N2; ++i) { L[i] = 0.2126 * R[i] + 0.7152 * G[i] + 0.0722 * B[i]; Rd[i] = 0.5 + 0.5 * (R[i] - B[i]) / (R[i] + G[i] + B[i] + 1e-3); }
   var rLF = Math.max(3, Math.round(nx / 14)), rMF = 3;
   var LLF = fvxBlur(L, nx, ny, rLF), RLF = fvxBlur(Rd, nx, ny, rLF), LMF = fvxBlur(L, nx, ny, rMF), RMF = fvxBlur(Rd, nx, ny, rMF);
   var scLF = new Float32Array(N2), scMF = new Float32Array(N2);
   for (i = 0; i < N2; ++i) { scLF[i] = 0.65 * LLF[i] + 0.35 * RLF[i]; scMF[i] = 0.65 * LMF[i] + 0.35 * RMF[i]; }
   var qLF = fvxRank(scLF), qMF = fvxRank(scMF), qL = fvxRank(fvxBlur(L, nx, ny, 1));
   // la foto suavizada (para las colas del perfil)
   var Rb = fvxBlur(R, nx, ny, 3), Gb = fvxBlur(G, nx, ny, 3), Bb = fvxBlur(B, nx, ny, 3);
   // 3. columna a columna: perfil, normalizacion exacta desde la Tierra, precompensacion de la absorcion, borde suave
   var E = new Float32Array(N2 * nz * 3), sig = FV_VOL.SIGMA, edge = FV_VOL.EDGE, ex = Math.max(1, edge * nx), ey = Math.max(1, edge * ny);
   var g = new Float32Array(nz), m = new Float32Array(nz), cMap = new Float32Array(N2), sMap = new Float32Array(N2);
   for (y = 0; y < ny; ++y) for (x = 0; x < nx; ++x) {
      i = y * nx + x;
      var s = FV_VOL.S_MIN + (FV_VOL.S_MAX - FV_VOL.S_MIN) * (1 - qL[i]);
      var c = 0.5 - FV_VOL.C_LF * (2 * qLF[i] - 1) - FV_VOL.C_MF * (2 * qMF[i] - 1);
      c = fvxClamp(c, 2.6 * s, 1 - 2.6 * s);
      cMap[i] = c; sMap[i] = s;
      var sumG = 0;
      for (k = 0; k < nz; ++k) { var w = (k + 0.5) / nz, d = (w - c) / s; g[k] = Math.exp(-0.5 * d * d) * fvxSmooth(w / FV_VOL.TAPER) * fvxSmooth((1 - w) / FV_VOL.TAPER); m[k] = fvxSmoothstep(0.7, 2.2, Math.abs(d)); sumG += g[k]; }
      var sr = 0, sg = 0, sb = 0;
      for (k = 0; k < nz; ++k) {
         var gk = g[k] / (sumG / nz), mk = m[k], b0 = (i * nz + k) * 3;
         E[b0] = gk * (R[i] * (1 - mk) + Rb[i] * mk); E[b0 + 1] = gk * (G[i] * (1 - mk) + Gb[i] * mk); E[b0 + 2] = gk * (B[i] * (1 - mk) + Bb[i] * mk);
         sr += E[b0]; sg += E[b0 + 1]; sb += E[b0 + 2];
      }
      // normalizacion exacta (Σ e·dw = la foto) y precompensacion de la absorcion (gris): L' = −ln(1 − σL)/σ
      var Lc = 0.2126 * R[i] + 0.7152 * G[i] + 0.0722 * B[i], comp = 1;
      if (Lc > 1e-4) { var sl = Math.min(0.95, sig * Lc); comp = (-Math.log(1 - sl) / sig) / Lc; }
      var fade = fvxSmooth(Math.min(x + 0.5, nx - 0.5 - x) / ex) * fvxSmooth(Math.min(y + 0.5, ny - 0.5 - y) / ey);
      var kr = (sr > 0 ? R[i] * nz / sr : 0) * comp * fade, kg = (sg > 0 ? G[i] * nz / sg : 0) * comp * fade, kb = (sb > 0 ? B[i] * nz / sb : 0) * comp * fade;
      for (k = 0; k < nz; ++k) { var b1 = (i * nz + k) * 3; E[b1] *= kr; E[b1 + 1] *= kg; E[b1 + 2] *= kb; }
   }
   // 4. EMAX (percentil) y atlas con raiz cuadrada
   var smp = []; for (i = 0; i < E.length; i += 37) if (E[i] > 0) smp.push(E[i]);
   smp.sort(function(p, q) { return p - q; });
   var emax = smp.length ? Math.max(1e-3, smp[Math.min(smp.length - 1, Math.floor(FV_VOL.CLIP_PCT * smp.length))]) : 1;
   var tilesX = Math.ceil(Math.sqrt(nz * ny / nx)), tilesY = Math.ceil(nz / tilesX);
   var AW = tilesX * nx, AH = tilesY * ny, atlas = new Uint32Array(AW * AH), clipped = 0, nonzero = 0;
   for (i = 0; i < atlas.length; ++i) atlas[i] = 0xff000000;
   for (k = 0; k < nz; ++k) {
      var ox = (k % tilesX) * nx, oy = Math.floor(k / tilesX) * ny;
      for (y = 0; y < ny; ++y) for (x = 0; x < nx; ++x) {
         var b2 = ((y * nx + x) * nz + k) * 3, rgb = [E[b2], E[b2 + 1], E[b2 + 2]], q = [0, 0, 0];
         for (var ch = 0; ch < 3; ++ch) { var v = rgb[ch] / emax; if (v > 1) { v = 1; ++clipped; } q[ch] = Math.round(255 * Math.sqrt(Math.max(0, v))); }
         if (q[0] | q[1] | q[2]) ++nonzero;
         atlas[(oy + y) * AW + ox + x] = (0xff000000 | (q[0] << 16) | (q[1] << 8) | q[2]) >>> 0;
      }
   }
   // 5. comprobacion: desde la Tierra, la integral (con absorcion, decodificada) frente a la foto reducida
   var err = 0, nErr = 0, ref = 0;
   for (y = Math.round(ny * 0.1); y < ny * 0.9; y += 3) for (x = Math.round(nx * 0.1); x < nx * 0.9; x += 3) {
      i = y * nx + x; var T = 1, acc = 0, ox2, oy2, pxv, lum;
      for (k = 0; k < nz; ++k) {
         ox2 = (k % tilesX) * nx; oy2 = Math.floor(k / tilesX) * ny; pxv = atlas[(oy2 + y) * AW + ox2 + x];
         var er = Math.pow(((pxv >>> 16) & 255) / 255, 2) * emax, eg = Math.pow(((pxv >>> 8) & 255) / 255, 2) * emax, eb = Math.pow((pxv & 255) / 255, 2) * emax;
         lum = 0.2126 * er + 0.7152 * eg + 0.0722 * eb;
         acc += T * eg / nz; T *= Math.exp(-sig * lum / nz);
      }
      err += Math.abs(acc - G[i]); ref += G[i]; ++nErr;
   }
   return { nx: nx, ny: ny, nz: nz, tilesX: tilesX, tilesY: tilesY, atlasW: AW, atlasH: AH, atlas: atlas, emax: emax, sigma: sig,
            params: { cLF: FV_VOL.C_LF, cMF: FV_VOL.C_MF, sMin: FV_VOL.S_MIN, sMax: FV_VOL.S_MAX, edge: edge, rLF: rLF, rMF: rMF, encoding: "sqrt", spoil: o.spoil || "" },
            stats: { ms: Date.now() - t0, clippedFrac: clipped / (nx * ny * nz * 3), nonzeroFrac: nonzero / (nx * ny * nz),
                     homeErrMean: nErr ? err / nErr : 0, homeRefMean: nErr ? ref / nErr : 0} };
}
