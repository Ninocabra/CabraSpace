// ============================================================================
// FieldVoyager/src/export/fv_export.js — EL PAQUETE DE ESCENA y «Abrir en el navegador» (4-nov-2026, F3; D1 «los dos», D9)
// ----------------------------------------------------------------------------
// fvExportScene(sceneOrBuilt, dir, opts) escribe en `dir` un visor completo y autonomo que se abre con doble clic (file://):
//   index.html, fw_*.js, fw_viewer.css, lib/three.min.js (r159, MIT)   copiados de FieldVoyager/web/ (van DENTRO del paquete firmado)
//   science/fv_sci_*.js   el modulo cientifico puro de src/science (color de cuerpo negro, ficha, frases EN/ES, transitos)
//   engine/fv_*.js                                                      el MISMO motor puro de src/engine (camara, warp, ir a, orbita):
//                                                                        los dos pintores vuelan igual (D1); se quitan las directivas «#»
//   scene/scene.js        window.FV_SCENE = { estrellas en doble precision, color, G, medida/dudosa/supuesta, ficha; nebulosa con
//                         centro/normal/grosor/distancia/fuente y su volumen; camara inicial = la de la foto desde la Tierra; rutas;
//                         reloj; notas de lo supuesto }
//   scene/img_*.js        window.FV_IMG[clave] = "data:image/…;base64,…"  (la foto, la foto sin estrellas, las capas, el atlas del volumen)
//   scene/<x>.png|jpg      las mismas imagenes sueltas (para mirarlas; el visor no las lee)
// POR QUE .js Y data: — Chrome trata cada fichero file:// como de otro origen: bloquea fetch() y XHR, y una imagen file:// cargada
// en WebGL o leida con getImageData da error de seguridad. Un <script> clasico si se carga, y una imagen data: no «contamina».
// fvOpenInBrowser(sceneOrBuilt, opts): exporta a <temporal del sistema>/FieldVoyager_view/ (se reescribe cada vez) y abre index.html
// con el navegador del sistema (cshSystemBrowser de CabraShared: rundll32 / open / xdg-open, sin shell; regla CPD 5.3(c), F0c
// pendiente). Sin servidor, sin red: el visor no descarga nada (CPD 5.1: todo el codigo viaja en el paquete).
// sceneOrBuilt: la salida de fvBuildScene ({ scene, bmps }) o una escena sola con opts.bmps.
// ES5. Usa fv_export_volume.js (puro) y, si estan, fvLog / cshSystemBrowser / FV_VERSION.
// ============================================================================

#include "fv_export_volume.js"
// abrir el navegador del sistema (rundll32 / open / xdg-open, sin shell): CabraShared, con su propia guarda de inclusion
#include "../../CabraShared/csh_web.js"

// (nA2, E1, 4-nov-2026; Nino: «cuando pasa al browser la imagen es de peor calidad») CALIDAD DE LA FOTO QUE VA AL NAVEGADOR. Antes: el Bitmap de
// trabajo de 2048 px (la foto de 5262 px a la mitad y un poco mas) en JPEG 92 y las capas a 1024. Ahora, con opts.view (la vista de PixInsight):
//   FULL            true = la foto y la foto sin estrellas a RESOLUCION COMPLETA (o, si pasa de MAX_SIDE, la reduccion por bloques mas pequeña que quepa:
//                   la GPU de quien lo abra lo recorta aun a su MAX_TEXTURE_SIZE en el visor); false = lo de antes (CONTROL EN ROJO de las pruebas)
//   MAX_SIDE        lado mayor maximo exportado (8192: las GPU de hoy dan 16384; un 8192 × 6000 RGBA son 190 MB con mipmaps)
//   PHOTO_Q         calidad JPEG de la foto, la foto sin estrellas y las capas (medida: ver tests/out/nA2_q y el HANDOFF)
//   STARLESS_FULL   true = la foto sin estrellas se rehace A RESOLUCION COMPLETA con el mismo motor (StarXTerminator / StarNet2); con el
//                   metodo propio (posiciones de Gaia) o si falla, se queda la de trabajo
//   LOSSLESS        true = PNG sin perdidas en vez de JPEG (la foto de 5262 px: 28 MB frente a 5 MB; el JPEG de PixInsight submuestrea el color 4:2:0)
//   LAYER_W         ancho maximo de las capas de la nebulosa (salen de la foto de trabajo de 2048: no hay mas que exportar)
var FV_EXPORT = { JPEG_Q: 92, PHOTO_Q: 97, LOSSLESS: false, LAYER_W: 2048, MAX_SIDE: 8192, FULL: true, STARLESS_FULL: true, DIRNAME: "FieldVoyager_view", FPS: 30 };
// el modulo cientifico de src/science (4-nov), en el orden de science/fv_science.jsh; el visor los carga con <script> en este orden
// (nP, 5-nov) + fv_sci_xp y fv_sci_chem: index.html los pide (I12/I13) y el paquete no los llevaba (404 en el visor; si faltan en src/science se dice y se sigue)
var FV_EXPORT_SCI = ["fv_sci_const", "fv_sci_tables", "fv_sci_i18n", "fv_sci_colour", "fv_sci_star", "fv_sci_dist", "fv_sci_transit", "fv_sci_planet", "fv_sci_travel", "fv_sci_scale", "fv_sci_phrases", "fv_sci_xp", "fv_sci_chem", "fv_sci_metal"];
// (W1, 6-nov) la ficha de PixInsight para el visor (index.html pide ui/fv_text.js y ui/fv_hud.js; solo se usan sus funciones de texto)
var FV_EXPORT_UI = ["fv_text", "fv_hud"];
// la carpeta de FieldVoyager (src/export/ -> ../../); web/ y src/engine/ cuelgan de ahi
var FV_EXPORT_ROOT = (function() {
   var d = (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/");
   return d.replace(/\/src\/export\/?$/, "");
})();

function fvxLog(s) { try { if (typeof fvLog === "function") fvLog("[export] " + s); else console.writeln("FieldVoyager [export] " + s); } catch (e) {} }
function fvxMkdir(d) { if (!File.directoryExists(d)) { try { File.createDirectory(d, true); } catch (e) { if (!File.directoryExists(d)) throw e; } } }
function fvxR(x, k) { if (x === null || x === undefined || !isFinite(x)) return null; var m = Math.pow(10, k); return Math.round(x * m) / m; }
// copia los ficheros de una carpeta (no recursiva) -> n
function fvxCopyDir(src, dst, filter) {
   fvxMkdir(dst);
   var ff = new FileFind, n = 0, names = [];
   if (ff.begin(src + "/" + "*")) { do { if (!ff.isDirectory && ff.name !== "." && ff.name !== "..") names.push(ff.name); } while (ff.next()); }
   for (var i = 0; i < names.length; ++i) {
      if (filter && !filter(names[i])) continue;
      var t = dst + "/" + names[i];
      if (File.exists(t)) File.remove(t);
      File.copyFile(t, src + "/" + names[i]); ++n;
   }
   return n;
}
// un fichero de imagen -> scene/img_<clave>.js con su data: URL
function fvxImgJs(dir, key, file, mime) {
   var b64 = File.readFile(dir + "/scene/" + file).toBase64();
   File.writeTextFile(dir + "/scene/img_" + key + ".js", "(window.FV_IMG = window.FV_IMG || {})[" + JSON.stringify(key) + "] = \"data:" + mime + ";base64," + b64 + "\";\n");
   return b64.length;
}
// (nA2, E1) la foto de la vista a resolucion completa tal y como la pinta PixInsight (misma funcion y estirado que el Bitmap de trabajo de
// fvBuildScene, pero sin reducir), o la reduccion por bloques entera mas pequeña que quepa en FV_EXPORT.MAX_SIDE. -> Bitmap | null
// (E2, 11-nov) con estirado (built.stf: foto lineal o con STF en PixInsight), la foto completa sale con LA MISMA curva que la de trabajo (fvStfRenderFull,
// src/build/fv_stf.js); ya estirada ("none"), tal cual, como antes
function fvxFullBitmap(view, stf) {
   try {
      var img = view.image, red = Math.max(1, Math.ceil(Math.max(img.width, img.height) / FV_EXPORT.MAX_SIDE));
      if (stf && stf.S && stf.S.on && stf.applied && typeof fvStfRenderFull === "function") return fvStfRenderFull(view, red, stf.applied.rows);
      return img.render(red > 1 ? -red : 1, true, false);
   } catch (e) { fvxLog("full-resolution photo failed: " + e); return null; }
}
// la calidad con la que se guarda una imagen: en PixInsight, Bitmap.save(ruta, calidad) escribe JPEG (extension .jpg) y PNG sin perdidas (.png)

// ---------------------------------------------------------------------------
// LA ESCENA A JSON (doble precision en las posiciones: 17 cifras; lo demas redondeado a lo que tiene sentido)
// ---------------------------------------------------------------------------
function fvxSceneObject(scene, files, vol, opts) {
   var S = scene.stars, st = null, i;
   if (S) {
      st = { n: S.n, x: [], y: [], z: [], g: [], dEarth: [], col: [], colSrc: [], q: [], inFrame: [], meta: [] };
      // (F3c) el color SIN polvo de F4b (el que se ve junto a la estrella), si la escena lo trae
      if (S.colTrue) st.colTrue = [];
      // (B1, 5-nov) STELLAE «GAIA» = el color de la TEMPERATURA (colG) y el de la temperatura sin polvo (colGT): el visor los usa como aspecto GAIA y deja
      // `col`/`colTrue` (el de la foto, verde recortado) para COLOR. Solo con FV_PS.GAIA_TEMP; sin la bandera el paquete es el de antes
      if (S.colG && typeof FV_PS !== "undefined" && FV_PS.ON && FV_PS.GAIA_TEMP === true) { st.colG = []; st.colGT = []; }
      for (i = 0; i < S.n; ++i) {
         st.x.push(S.x[i]); st.y.push(S.y[i]); st.z.push(S.z[i]);
         st.g.push(fvxR(S.g[i], 3)); st.dEarth.push(fvxR(S.dEarth[i], 3)); st.col.push(S.col[i] >>> 0); st.colSrc.push(S.colSrc[i]); st.q.push(S.q[i]); st.inFrame.push(S.inFrame[i]);
         if (st.colTrue) st.colTrue.push(S.colTrue[i] >>> 0);
         if (st.colG) { st.colG.push(S.colG[i] >>> 0); st.colGT.push(S.colGT[i] >>> 0); }
         var m = S.meta[i] || {}, o = {};
         if (m.ra !== undefined && m.ra !== null) o.ra = fvxR(m.ra, 6);
         if (m.dec !== undefined && m.dec !== null) o.dec = fvxR(m.dec, 6);
         // (nP, AETAS) pmRa (mas/año, ya por cos dec), pmDec y rv (km/s): la maquina del tiempo del visor (engine/fv_time.js)
         var keys3 = ["bpRp", "plx", "distPc", "lo", "hi", "ruwe", "pmRa", "pmDec", "rv", "plxErr", "pmErr"];      // (F2) + los errores de Gaia: la fugitiva y el modo GALAXIA del visor los leen
         for (var k = 0; k < keys3.length; ++k) { var v = m[keys3[k]]; if (v !== null && v !== undefined && isFinite(v)) o[keys3[k]] = fvxR(v, 3); }
         if (m.teff) o.teff = Math.round(m.teff);
         if (m.src) o.src = m.src;
         if (m.hip > 0) { o.hip = m.hip; if (m.hipName) o.hipName = String(m.hipName); }      // (3b, 20-nov) numero y nombre de Hipparcos: el rotulo de la ficha y del diagrama HR
         if (m.teffSrc) o.teffSrc = m.teffSrc;
         if (m.teffObs && Math.round(m.teffObs) !== Math.round(m.teff || 0)) o.teffObs = Math.round(m.teffObs);
         if (m.cluster !== undefined && m.cluster !== null && m.cluster >= 0) o.cluster = m.cluster;
         if (m.sourceId) o.sourceId = String(m.sourceId);
         if (m.wide) o.wide = 1;
         // marcas de F2 (4-nov): estrellas fuera de la foto (cielo de alrededor / anillo); el visor las pinta igual y la ficha lo dice
         if (m.ring) o.ring = 1;
         if (m.outside) o.outside = 1;
         if (m.tier !== undefined && m.tier !== null) o.tier = m.tier;
         // (N, D) el polvo de delante de la estrella (F4b): la ficha dice cuanto enrojece; el visor pasa del color de la foto al verdadero
         if (m.dust && isFinite(m.dust.ag)) { o.dust = { ag: fvxR(m.dust.ag, 3), ebr: fvxR(m.dust.ebr, 3), av: fvxR(m.dust.av, 3) }; if (m.dust.beyond) o.dust.beyond = 1; }
         // (nP, 5-nov, encargo de I12) el espectro XP y la quimica de la ficha viajan en el paquete (fv_card_sci.js); sin fvCsciField (35 s)
         if (typeof fvCsciExport === "function") { var cx = fvCsciExport(m); if (cx) o.sci = cx; }
         // (metalicidad, 5-nov) el [M/H] de GSP-Phot del refinado, solo si vale (fvsMetalPhotOk: Teff validada); la ficha web lo usa de reserva
         // como la de PixInsight: fvsMetalBuild(chem, { v: mhP, teff: 5000 }, meta.teff) (src/science/fv_sci_metal.js). Con FV_METAL.ON = false no viaja
         if (typeof FV_METAL !== "undefined" && FV_METAL.ON === true && typeof fvsMetalPhotOk === "function" && fvsMetalPhotOk(m.mhPhot, m.mhPhotT)) o.mhP = fvxR(m.mhPhot, 3);
         st.meta.push(o);
      }
   }
   var neb = null;
   if (scene.nebula) {
      neb = JSON.parse(JSON.stringify(scene.nebula));
      for (i = 0; i < neb.layers.length; ++i) neb.layers[i].img = files.layers[i] || "";
      var z0 = neb.distLy - neb.thickLy / 2, z1 = neb.distLy + neb.thickLy / 2;
      if (vol) neb.volume = { status: "built", res: [vol.nx, vol.ny, vol.nz], img: "volume", file: "scene/volume_atlas.png", tiles: [vol.tilesX, vol.tilesY],
                              atlas: [vol.atlasW, vol.atlasH], emax: vol.emax, sigma: vol.sigma, encoding: "sqrt (v = 255·sqrt(e/emax))", z0: z0, z1: z1,
                              mapping: "u = (x/z)·F/W + 0.5 · v = (y/z)·F/H + 0.5 · w = (z − z0)/(z1 − z0)",
                              relief: "ASSUMED: depth of the emission per column from the photo's own band score (bright and red in front, blue behind) at two scales; Gaussian depth profile 5–18 % of the thickness; no invented noise",
                              params: vol.params, stats: { ms: vol.stats.ms, clippedFrac: vol.stats.clippedFrac, homeErrMean: vol.stats.homeErrMean } };
      else if (files.starless) neb.volume = { status: "built", model: "v2 (F3b): body + three thin sheets + dust, computed by the viewer (web/fw_relief.js) from the starless photo", z0: z0, z1: z1,
                              mapping: "u = (x/z)·F/W + 0.5 · v = (y/z)·F/H + 0.5 · w = (z − z0)/(z1 − z0)",
                              relief: "ASSUMED: depth of body and sheets per column from the photo's own band score (bright and red in front) and scale (fine structure in thin sheets); dark structure absorbs; no invented noise" };
      else neb.volume = { status: "not built (" + ((opts && opts.whyNoVolume) || "no starless image") + ")", res: null, file: null };
   }
   var notes = (scene.notes || []).slice();
   if (vol || files.starless) notes.push("Nebula volume: relief ASSUMED (depth from the photo's colour, brightness and scale, not measured)");
   return {
      format: "FieldVoyager scene package", version: 1, generator: (typeof FV_VERSION !== "undefined" ? FV_VERSION : "?"), created: (new Date).toISOString(),
      units: "light-year", axes: "Earth at origin; +Z to photo centre; +X photo right; +Y photo down",
      field: scene.field, stars: st, nebula: neb, notes: notes,
      // (F3c) lo que el visor necesita para pintar igual que PixInsight: hasta donde llega el cielo completo (el «cono», F2/F4b) y el
      // marco galactico de la Via Lactea simulada (F4b, fv_milkyway.js); null si la escena no lo trae
      facts: scene.facts ? JSON.parse(JSON.stringify(scene.facts)) : null, galaxy: scene.galaxy || null,
      camera: { home: { pos: [0, 0, 0], look: [0, 0, 1], fov: "photo (fvHomeFov: the photo covers the canvas)" } },
      clock: { fps: FV_EXPORT.FPS, rule: "scene time t = n/fps when recording; real time when flying live" },
      routes: (opts && opts.routes) || [],
      // (N, D) los objetos singulares de C (N1/N8/N12): solo lo que el visor lee (el _gfx con los Bitmap no es enumerable y no entra)
      objects: fvxObjects(scene, files), music: (opts && opts.music) || [],
      // (21-nov, T1-A) las filas «sin datos» de MIRABILIA (scene.noData, fvObjFinalList): no son objetos (no hay a donde ir); null si no hay o con FV_NOTABLE.NODATA_ROW = false
      noData: fvxNoData(scene),
      // (I1, 19-nov) los misterios de la foto ya calculados (src/engine/fv_aenigma.js): el visor los LEE (el paquete no lleva los errores de paralaje ni de movimiento propio); null con la bandera apagada
      aenigma: (typeof fvE1cGet === "function" && fvE1cOn()) ? JSON.parse(JSON.stringify(fvE1cGet(scene))) : null,
      // (F2, 20-nov) las candidatas a fugitiva ya calculadas (src/engine/fv_runaway.js, con los errores reales de Gaia que trajo el refinado de VizieR o la cota de la base local): el visor las LEE
      // (el mismo calculo con la meta redondeada del paquete podria dar otro percentil en el limite); null con FV_RUNAWAY.ON = false
      runaway: (typeof fvRunExport === "function" && typeof FV_RUNAWAY !== "undefined" && FV_RUNAWAY.ON === true) ? fvRunExport(scene) : null,
      // (F8, 17-nov; E2b) el protagonista de la foto (scene.hero, src/build/fv_build.js): de donde sale y como se llama; null sin protagonista. El visor (web/fw_nav.js, FW_HERO) lo pone el 1.º de MIRABILIA y la ultima parada del Tour
      hero: fvxHero(scene),
      // (5-nov) EL ASPECTO DE LAS ESTRELLAS (STELLAE): colores de la foto y recortes en un atlas (fvxPhotoStars); null sin medida
      photoStars: (opts && opts._ps) || null,
      images: files
   };
}
// (F8, 17-nov) scene.hero -> lo justo para el visor (sin el ranking de candidatos): null si la foto no tiene protagonista
function fvxHero(scene) {
   var H = scene && scene.hero; if (!H) return null;
   return { id: String(H.id), src: String(H.src || ""), name: String(H.name || ""), type: String(H.type || ""), promoted: !!H.promoted, sameAsMain: !!H.sameAsMain,
            sizeArcmin: isFinite(H.sizeArcmin) ? fvxR(H.sizeArcmin, 2) : null, f: isFinite(H.f) ? fvxR(H.f, 3) : null, q: isFinite(H.q) ? fvxR(H.q, 3) : null };
}
// (21-nov, T1-A) scene.noData -> [{ id, why, reason, score, label }] (los rotulos en los dos idiomas, como los de scene.objects); null si no hay
function fvxNoData(scene) {
   var N = scene && scene.noData;
   if (!N || !N.length || (typeof FV_NOTABLE !== "undefined" && FV_NOTABLE.NODATA_ROW === false)) return null;
   var out = [], i;
   for (i = 0; i < N.length; ++i) {
      var n = N[i], lb = n && n.label; if (!lb || !lb.en || !lb.es) continue;
      var cp = function(x) { return { t: String(x.t), v: String(x.v), d: String(x.d), s: x.s ? String(x.s) : undefined }; };
      out.push({ id: String(n.id), why: String(n.why), reason: String(n.reason), score: isFinite(n.score) ? n.score : 0, label: { crit: String(lb.crit || n.why), en: cp(lb.en), es: cp(lb.es) } });
   }
   return out.length ? out : null;
}
// (N, D) scene.objects -> lo justo para el visor: numeros, textos y el rectangulo del recorte (si C lo dio y se exporto su imagen)
function fvxObjects(scene, files) {
   var O = scene.objects;
   if (!O || !O.length) return null;
   var keep = ["id", "name", "otype", "type", "subtype", "distLy", "distErrLy", "distSrc", "distRef", "distFromStar", "assWhy", "radiusLy", "mag", "z", "lookbackYr", "src", "star", "hostStar",
               "sizeArcmin", "sizeCatArcmin", "sizeSrc", "members", "workK", "score", "arriveLy", "why", "main", "hero", "match", "colAvg", "ofName"], out = [];   // (F8, 17-nov) hero: el protagonista de la foto (E2b), para MIRABILIA y el Tour del visor
   var pk = ["pl_name", "hostname", "pl_orbper", "pl_rade", "pl_eqt", "pl_orbsmax", "pl_trandep", "pl_trandur", "pl_bmasse", "disc_year", "discoverymethod"];
   // (Blender 1) el visor pinta el planeta (fw_pl_view.js) con la geometria del transito y la estrella: solo con la bandera encendida (apagada,
   // la escena exportada es la de hoy, byte a byte)
   if (typeof FV_PL3D !== "undefined" && FV_PL3D.ON) pk = pk.concat(["st_teff", "st_rad", "st_mass", "pl_ratror", "pl_imppar", "pl_orbincl", "sy_dist"]);   // (Blender 5 · H4) sy_dist: la ficha de un planeta de DEMOSTRACION dice la distancia de SU estrella
   for (var i = 0; i < O.length; ++i) {
      var o = O[i], e = {};
      for (var k = 0; k < keep.length; ++k) { var v = o[keep[k]]; if (v === undefined || v === null) continue; if (typeof v === "number") { if (isFinite(v)) e[keep[k]] = v; } else if (typeof v === "string" || typeof v === "boolean") e[keep[k]] = v; }
      if (o.typeLabel) e.typeLabel = { en: String(o.typeLabel.en || ""), es: String(o.typeLabel.es || "") };
      // (B, 14-nov) el rotulo de MIRABILIA (criterio, valor y su explicacion, en los dos idiomas): el visor lee las mismas cadenas que PixInsight
      if (o.label) e.label = { crit: String(o.label.crit || ""), en: { t: String(o.label.en.t), v: String(o.label.en.v), d: String(o.label.en.d) }, es: { t: String(o.label.es.t), v: String(o.label.es.v), d: String(o.label.es.d) } };
      if (o.px) e.px = { x: isFinite(o.px.x) ? o.px.x : null, y: isFinite(o.px.y) ? o.px.y : null, r: isFinite(o.px.r) ? o.px.r : 0 };
      if (o.pos) e.pos = [o.pos[0], o.pos[1], o.pos[2]];
      // (R8) el contorno que se encuadra (centro 3D, radio, si es la foto entera): el visor llega al mismo sitio con fvObjectTarget
      if (o.frame && o.frame.pos) e.frame = { pos: [o.frame.pos[0], o.frame.pos[1], o.frame.pos[2]], rLy: fvxR(o.frame.rLy, 6), rPx: fvxR(o.frame.rPx, 2), x: fvxR(o.frame.x, 2), y: fvxR(o.frame.y, 2), whole: !!o.frame.whole };
      if (o.seg) e.seg = { ok: !!o.seg.ok, why: String(o.seg.why || ""), snr: fvxR(o.seg.snr, 2), rEq: fvxR(o.seg.rEq, 2), rMax: fvxR(o.seg.rMax, 2) };
      if (o.planet) { e.planet = {}; for (k = 0; k < pk.length; ++k) { var pv = o.planet[pk[k]]; if (pv !== undefined && pv !== null && (typeof pv === "string" || isFinite(pv))) e.planet[pk[k]] = pv; } }
      var cut = files && files.objCuts ? files.objCuts[i] : null;
      if (cut) e.cut = cut;
      // (V2, 5-nov) el volumen por familias: la decision (o.vol: familia, confianza, por que, medidas) y las pilas de cortes (fvxObjVolumes)
      var vv = files && files.objVols ? files.objVols[i] : null;
      if (vv) { e.vol3 = vv; if (o.vol) e.vol = JSON.parse(JSON.stringify(o.vol)); }
      out.push(e);
   }
   if (files && files.objVols) delete files.objVols;   // (V2) ya va en cada objeto (vol3): no repetirlo en images
   return out;
}
// (N, D) los recortes de los objetos compactos que hizo C (o._gfx.cutBmp: la foto sin estrellas del objeto menos el fondo, con borde suave)
// -> files.objCuts[i] = { img: "obj<i>", x0, y0, w, h, cx, cy, rMax, K, t } (px de trabajo); el visor tambien sabe recortar sin ellos
function fvxObjectCuts(scene, dir, files) {
   var O = scene.objects, n = 0, b64 = 0;
   files.objCuts = [];
   if (!O) return 0;
   for (var i = 0; i < O.length; ++i) {
      var o = O[i], G = o._gfx, sg = o._seg;
      if (!G || !G.cutBmp) { files.objCuts.push(null); continue; }
      var name = "obj" + i;
      G.cutBmp.save(dir + "/scene/" + name + ".png");
      b64 += fvxImgJs(dir, name, name + ".png", "image/png");
      // (D, rev. 3) C hace ahora el recorte a RESOLUCION COMPLETA (fv_build cutOne -> fvObjHiCut): G.x0/G.y0 son 0 (del recorte) y su sitio
      // va en G.photo = { x0, y0, x1, y1 } en px de la FOTO. Al visor van px de trabajo (foto × workK, como fv_objects_paint); sin esto el
      // recorte caia en la esquina de arriba a la izquierda y NGC 2392 desaparecia (T8 del 4-nov, rev. 3)
      var kk = o.workK > 0 ? o.workK : 1, R = G.photo ? { x0: G.photo.x0 * kk, y0: G.photo.y0 * kk, w: (G.photo.x1 - G.photo.x0) * kk, h: (G.photo.y1 - G.photo.y0) * kk } : { x0: G.x0, y0: G.y0, w: G.w, h: G.h };
      files.objCuts.push({ img: name, x0: R.x0, y0: R.y0, w: R.w, h: R.h, cx: sg ? sg.cx : (o.px ? o.px.x : R.x0 + R.w / 2), cy: sg ? sg.cy : (o.px ? o.px.y : R.y0 + R.h / 2),
                           rMax: sg ? sg.rMax : (o.px ? o.px.r : Math.min(G.w, G.h) / 2), K: G.K, t: G.t ? G.t.slice() : null });
      ++n;
   }
   files.objBytes = b64;
   return n;
}
// (V2, 5-nov) EL VOLUMEN POR FAMILIAS de los objetos (o._vol de src/ui/fv_volume_paint.js; solo con FV_VOLM.ON, sin la bandera no se escribe
// nada y el paquete es el de siempre). Las tres pilas de cortes de cada objeto van en UN atlas PNG (sin perdidas: los cortes llevan la difusion
// de ±1 nivel que conserva la luz debil, un JPEG la romperia) empaquetado por estantes con 1 px de negro entre cortes, y su geometria: el marco
// del objeto en el mundo y el rectangulo de cada corte. web/fw_gl.js (buildObjVolumes) los pinta con la misma regla que PixInsight (las dos
// pilas mas alineadas, cos², fundido al rozar un corte). -> files.objVols[i] = { atlas, aw, ah, family, head, N, w, h, D, cx, cy,
// fr: { o0, e1, e2, ez, ex, ey, ez1, center, s }, gs: [ { name, group, nrm, sp, N, c: [[u0, v0, bw, bh, ax, ay, P0x, P0y, P0z, Ux, Uy, Uz, Vx, Vy, Vz,
// pcx, pcy, pcz] | null] } ] } y bytes base64. (V3, ronda 3) `gs` = pilas GENERICAS (las del disco alineadas con el disco, la cascara y el resto
// en Z/X/Y): cada corte trae su geometria en px del modelo (P0 + U·u + V·v) y su centro pc; el visor da la opacidad por grupo (fwVol3Op) con la
// misma regla que PixInsight (fv3StackOpacity). El formato `st` de la fase 2 ya no se escribe
var FV_EXPORT_VOL = { ATLAS_W: [2048, 4096], ATLAS_HMAX: 8192 };
function fvxObjVolumes(scene, dir, files) {
   files.objVols = [];
   var O = scene.objects, b64 = 0, n = 0;
   if (typeof FV_VOLM === "undefined" || !FV_VOLM.ON || !O) { files.volBytes = 0; return 0; }
   var r3 = function(v) { return [v[0], v[1], v[2]]; };
   for (var i = 0; i < O.length; ++i) {
      var o = O[i], V = o._vol;
      if (!V || !V.m || !V.stacks || !V.fr) { files.objVols.push(null); continue; }
      var items = [];
      // (V3) pilas genericas (array; cada corte con P0, U, V, pc en coordenadas del modelo)
      V.stacks.forEach(function(st, si) { for (var j = 0; j < st.cuts.length; ++j) if (st.cuts[j] && st.cuts[j].bmp) items.push({ si: si, j: j, C: st.cuts[j] }); });
      items.sort(function(a, b) { return b.C.bh - a.C.bh; });
      var aw = 0, ah = 0;
      for (var t = 0; t < FV_EXPORT_VOL.ATLAS_W.length; ++t) {   // estantes: de izquierda a derecha, fila nueva cuando no cabe
         aw = FV_EXPORT_VOL.ATLAS_W[t]; var x = 1, y = 1, rowH = 0, fits = true;
         for (var k = 0; k < items.length; ++k) {
            var C = items[k].C; if (C.bw + 2 > aw) { fits = false; break; }
            if (x + C.bw + 1 > aw) { x = 1; y += rowH + 1; rowH = 0; }
            items[k].x = x; items[k].y = y; x += C.bw + 1; rowH = Math.max(rowH, C.bh);
         }
         ah = y + rowH + 1;
         if (fits && ah <= FV_EXPORT_VOL.ATLAS_HMAX) break;
         ah = 0;
      }
      if (!ah) { fvxLog("object volume " + o.name + ": the slices do not fit in an atlas (the viewer keeps the planes)"); files.objVols.push(null); continue; }
      var atlas = new Bitmap(aw, ah, BitmapFormat.RGB32); atlas.fill(0xff000000);
      var g = new Graphics(atlas);
      try { g.compositionOperator = CompositionOp_SourceOver; g.smoothInterpolation = false; for (k = 0; k < items.length; ++k) g.drawBitmap(items[k].x, items[k].y, items[k].C.bmp); } finally { g.end(); }
      var name = "objvol" + i;
      atlas.save(dir + "/scene/" + name + ".png"); b64 += fvxImgJs(dir, name, name + ".png", "image/png");
      // (V3) gs: [{ name, group, nrm, sp, N, c: [[u0, v0, bw, bh, ax, ay, P0x, P0y, P0z, Ux, Uy, Uz, Vx, Vy, Vz, pcx, pcy, pcz] | null] }]
      var gs = V.stacks.map(function(S) { var c = []; for (var j = 0; j < S.cuts.length; ++j) c.push(null); return { name: S.name, group: S.group, nrm: r3(S.nrm), sp: S.sp, N: S.N, c: c }; });
      var r6 = function(v) { return Math.round(v * 1e4) / 1e4; };
      for (k = 0; k < items.length; ++k) { var it = items[k], Cc = it.C; gs[it.si].c[it.j] = [Cc.u0, Cc.v0, Cc.bw, Cc.bh, it.x, it.y, r6(Cc.P0[0]), r6(Cc.P0[1]), r6(Cc.P0[2]), r6(Cc.U[0]), r6(Cc.U[1]), r6(Cc.U[2]), r6(Cc.V[0]), r6(Cc.V[1]), r6(Cc.V[2]), r6(Cc.pc[0]), r6(Cc.pc[1]), r6(Cc.pc[2])]; }
      var m = V.m, fr = V.fr;
      files.objVols.push({ atlas: name, aw: aw, ah: ah, family: m.family, head: m.head || 1, N: (o.vol && o.vol.N) || 0, w: m.w, h: m.h, D: m.D, cx: m.cx, cy: m.cy,
                           fr: { o0: r3(fr.o0), e1: r3(fr.e1), e2: r3(fr.e2), ez: r3(fr.ez), ex: r3(fr.ex), ey: r3(fr.ey), ez1: r3(fr.ez1), center: r3(fr.center), s: fr.s }, gs: gs });
      ++n;
   }
   files.volBytes = b64;
   return n;
}
// (5-nov) LAS ESTRELLAS DE LA FOTO para el visor (STELLAE: GAIA · COLOR · FOTO, src/engine/fv_photostars.js). La medida es la de PixInsight
// (fvPsEnsure: se hace aqui si aun no estaba, para que el navegador tenga las tres opciones). Los recortes van PREMULTIPLICADOS sobre negro en un
// atlas PNG (sin perdidas: un JPEG dejaria bloques grises alrededor de cada estrella = cuadros) empaquetado por estantes, con 1 px de negro entre
// recortes (el filtrado bilineal de la GPU no mezcla vecinos). -> files.photoStars = { look, k, fwhm, engine, rgb[], spr (planos de 7: i, ax, ay, w, h,
// cx, cy), atlas, atlasSize, law } y bytes base64 del atlas
var FV_EXPORT_PS = { ON: true, ATLAS_W: 2048 };
function fvxPhotoStars(sceneOrBuilt, dir, files, opts) {
   var built = (sceneOrBuilt && sceneOrBuilt.scene) ? sceneOrBuilt : null, rm = function() { ["img_psatlas.js", "psatlas.png"].forEach(function(f) { if (File.exists(dir + "/scene/" + f)) File.remove(dir + "/scene/" + f); }); };
   if (FV_EXPORT_PS.ON === false || opts.photoStars === false || typeof FV_PS === "undefined" || !FV_PS.ON || typeof fvPsEnsure !== "function" || !built || !built.bmps || !built.bmps.photo) { rm(); return 0; }
   var ps = fvPsEnsure(built);
   if (!ps || !ps.ok) { rm(); fvxLog("stars of the photo: not measured (" + (ps ? ps.why : "?") + "): the browser offers only GAIA"); return 0; }
   var ids = [], i; for (i = 0; i < ps.spr.length; ++i) if (ps.spr[i]) ids.push(i);
   ids.sort(function(a, b) { return ps.spr[b].h - ps.spr[a].h; });
   var AW = FV_EXPORT_PS.ATLAS_W, x = 1, y = 1, rowH = 0, pos = {};
   for (var q = 0; q < ids.length; ++q) { var sp = ps.spr[ids[q]]; if (x + sp.w + 1 > AW) { x = 1; y += rowH + 1; rowH = 0; } pos[ids[q]] = [x, y]; x += sp.w + 1; if (sp.h > rowH) rowH = sp.h; }
   var AH = Math.max(1, y + rowH + 1), px = new Uint32Array(AW * AH), flat = [];
   for (i = 0; i < px.length; ++i) px[i] = 0xff000000;
   for (q = 0; q < ids.length; ++q) {
      var j = ids[q], s2 = ps.spr[j], p0 = pos[j];
      for (var yy = 0; yy < s2.h; ++yy) for (var xx = 0; xx < s2.w; ++xx) px[(p0[1] + yy) * AW + p0[0] + xx] = s2.px[yy * s2.w + xx];
      flat.push(j, p0[0], p0[1], s2.w, s2.h, Math.round(s2.cx * 1000) / 1000, Math.round(s2.cy * 1000) / 1000);
   }
   var ab = new Bitmap(AW, AH, BitmapFormat.RGB32); new Uint32Array(ab.pixelData()).set(px);
   ab.save(dir + "/scene/psatlas.png");
   var b64 = fvxImgJs(dir, "psatlas", "psatlas.png", "image/png"), rgb = [];
   // (B1) COLOR ya no usa la medida phcol (rgb): es el `col` de la escena. Con FV_PS.GAIA_TEMP el paquete no la lleva (opts.psLegacy la pide: pruebas del STELLAE de antes)
   var withRgb = !(FV_PS.GAIA_TEMP === true) || opts.psLegacy === true;
   if (withRgb) for (i = 0; i < ps.rgb.length; ++i) rgb.push(ps.rgb[i]);
   files.photoStars = { look: (opts.starLook && fvPsIsLook(opts.starLook)) ? opts.starLook : "gaia", k: ps.k, w: ps.w, h: ps.h, fwhm: Math.round(ps.fwhm * 1000) / 1000,
                        engine: ps.engine ? { label: ps.engine.label, why: ps.engine.why } : null, nCol: ps.nCol, nSpr: ids.length, rgb: withRgb ? rgb : undefined, spr: flat, atlas: "psatlas", atlasSize: [AW, AH],
                        law: { magLo: FV_PS.MAG_LO, magHi: FV_PS.MAG_HI, trailLo: FV_PS.TRAIL_LO, trailHi: FV_PS.TRAIL_HI, scaleMin: FV_PS.SCALE_MIN, sigmaCap: FV_LOOK.SAT * FV_LOOK.SAT_STEP } };
   fvxLog("stars of the photo: " + ps.nCol + " photo colours, " + ids.length + " cut-outs in a " + AW + "x" + AH + " atlas (" + Math.round(b64 * 3 / 4 / 1024) + " KiB PNG, " + Math.round(b64 / 1024) + " KiB as base64) · " + ps.engine.label);
   return b64;
}
// (4-nov) LA MUSICA del visor: las diez emisoras generativas de a bordo (src/radio/fv_music.js, obra propia, CC0) viajan en el paquete
// como fv_music.js; ya no hay pistas de terceros ni cache que enlazar (scene.music queda vacio).

// ---------------------------------------------------------------------------
// EXPORTAR
// ---------------------------------------------------------------------------
function fvExportScene(sceneOrBuilt, dir, opts) {
   opts = opts || {};
   var t0 = Date.now(), out = { ok: false, why: "", dir: dir, index: "", files: [], bytes: 0, ms: 0, volume: null, steps: [] };
   var scene = (sceneOrBuilt && sceneOrBuilt.scene) ? sceneOrBuilt.scene : sceneOrBuilt, bmps = opts.bmps || (sceneOrBuilt && sceneOrBuilt.bmps) || null;
   function step(name, t) { out.steps.push(name + " " + (Date.now() - t) + " ms"); fvxLog(name + " · " + (Date.now() - t) + " ms"); }
   try {
      if (!scene || !scene.stars) throw new Error("no scene");
      dir = String(dir).split("\\").join("/").replace(/\/$/, ""); out.dir = dir;
      fvxMkdir(dir); fvxMkdir(dir + "/scene"); fvxMkdir(dir + "/engine"); fvxMkdir(dir + "/lib");
      // 1. el visor y el motor
      var t = Date.now(), web = FV_EXPORT_ROOT + "/web";
      if (!File.exists(web + "/index.html")) throw new Error("viewer not found: " + web + "/index.html");
      // (Blender 1) los sprites de los planetas (fw_pl_s*.js, 2,5 MB) solo van si los exoplanetas como mundos estan encendidos
      var nW = fvxCopyDir(web, dir, function(n) { return /\.(html|js|css|txt)$/i.test(n) && !/^README/i.test(n) && !(/^fw_pl_s\d+\.js$/i.test(n) && !(typeof FV_PL3D !== "undefined" && FV_PL3D.ON)); }) + fvxCopyDir(web + "/lib", dir + "/lib");
      // (F3c) fv_dust.js y fv_milkyway.js (F4b) son opcionales: el visor los usa si estan (Via Lactea de fondo)
      // (N, D) fv_objects.js (C: clic, ficha y destino de los objetos singulares) y fv_epoch.js: opcionales, el visor los usa si estan
      // (pasada M) fv_tour_plan.js (la ruta propuesta, boton PROPONER del mapa grande): opcional
      // (11-nov, NV-13) fv_flightlab.js: el laboratorio de vuelo v5, la navegacion de PixInsight; el visor lo enciende con FW_LAB.ON (fw_viewer.js). Opcional:
      // sin el, el visor navega con el motor de antes
      // (11-nov, NV-16) fv_ambient.js: el campo de estrellas de fondo simulado (lo pinta web/fw_amb.js con el laboratorio). Opcional: sin el, sin campo
      // (I2, 19-nov) fv_hr.js: el diagrama HR animado (lo pinta web/fw_hr.js). Opcional: sin el, el visor no pone el boton
      var eng = ["fv_math.js", "fv_scene.js", "fv_look.js", "fv_pilot.js", "fv_flightlab.js", "fv_dust.js", "fv_milkyway.js", "fv_ambient.js", "fv_objects.js", "fv_epoch.js", "fv_tour_plan.js", "fv_time.js", "fv_runaway.js", "fv_skyov.js", "fv_e1a.js", "fv_e1.js", "fv_hr.js", "fv_aenigma.js"], engOpt = { "fv_runaway.js": 1, "fv_aenigma.js": 1, "fv_e1a.js": 1, "fv_e1.js": 1, "fv_hr.js": 1,"fv_flightlab.js": 1, "fv_ambient.js": 1, "fv_dust.js": 1, "fv_milkyway.js": 1, "fv_objects.js": 1, "fv_epoch.js": 1, "fv_tour_plan.js": 1, "fv_time.js": 1, "fv_skyov.js": 1 };   // (nP) fv_time.js: AETAS, opcional
      for (var i = 0; i < eng.length; ++i) {
         var src = FV_EXPORT_ROOT + "/src/engine/" + eng[i];
         if (!File.exists(src)) { if (engOpt[eng[i]]) { if (File.exists(dir + "/engine/" + eng[i])) File.remove(dir + "/engine/" + eng[i]); continue; } throw new Error("engine file missing: " + src); }
         var txt = File.readTextFile(src).split("\n").filter(function(l) { return !/^\s*#/.test(l); }).join("\n");
         File.writeTextFile(dir + "/engine/" + eng[i], txt);
      }
      // el modulo cientifico (puro, sin directivas; mismo orden que science/fv_science.jsh): si falta, el visor sigue sin frases
      var nS = 0;
      fvxMkdir(dir + "/science");
      for (i = 0; i < FV_EXPORT_SCI.length; ++i) {
         var ss = FV_EXPORT_ROOT + "/src/science/" + FV_EXPORT_SCI[i] + ".js";
         if (!File.exists(ss)) { fvxLog("science file missing (the card goes without phrases): " + ss); continue; }
         File.writeTextFile(dir + "/science/" + FV_EXPORT_SCI[i] + ".js", File.readTextFile(ss).split("\n").filter(function(l) { return !/^\s*#/.test(l); }).join("\n")); ++nS;
      }
      // (W1, 6-nov) los textos y la ficha de PixInsight (fvCardContent): la ficha web dice LO MISMO (web/fw_card_pi.js); si faltan, la de antes
      fvxMkdir(dir + "/ui");
      for (i = 0; i < FV_EXPORT_UI.length; ++i) {
         var su = FV_EXPORT_ROOT + "/src/ui/" + FV_EXPORT_UI[i] + ".js";
         if (!File.exists(su)) { fvxLog("ui file missing (the web card goes as before): " + su); continue; }
         File.writeTextFile(dir + "/ui/" + FV_EXPORT_UI[i] + ".js", File.readTextFile(su).split("\n").filter(function(l) { return !/^\s*#/.test(l); }).join("\n")); ++nS;
      }
      // la radio: el motor de las emisoras generativas (el mismo que la radio de PixInsight), junto a index.html
      var mus = FV_EXPORT_ROOT + "/src/radio/fv_music.js";
      if (File.exists(mus)) { File.writeTextFile(dir + "/fv_music.js", File.readTextFile(mus)); ++nW; } else fvxLog("radio engine missing (the viewer radio plays only your files): " + mus);
      step("viewer + engine + science copied (" + nW + " + " + eng.length + " + " + nS + " files)", t);
      // 2. imagenes
      t = Date.now();
      var files = { photo: "", starless: "", layers: [], volume: "" }, bytes64 = 0;
      // (nA2, E1) resolucion completa de la foto (y de la foto sin estrellas) si se da la vista; FV_EXPORT.FULL = false = lo de antes (ROJO)
      var full = (FV_EXPORT.FULL !== false && opts.fullRes !== false && opts.view) ? fvxFullBitmap(opts.view, opts.stf || (sceneOrBuilt && sceneOrBuilt.stf) || null) : null;
      var Q = full ? (opts.photoQ || FV_EXPORT.PHOTO_Q) : FV_EXPORT.JPEG_Q, layerW = full ? FV_EXPORT.LAYER_W : 1024;
      var phBmp = full || (bmps ? bmps.photo : null), slBmp = bmps ? bmps.starless : null, slHow = "work bitmap";
      files.meta = { fullRes: !!full, quality: Q, photo: phBmp ? [phBmp.width, phBmp.height] : null, starless: null, starlessHow: "", layerW: layerW };
      if (full && FV_EXPORT.STARLESS_FULL !== false && opts.starlessFull !== false && typeof fvStarlessEngine === "function" && typeof fvStarlessProcess === "function") {
         // la foto sin estrellas a resolucion completa con el mismo motor que la de trabajo (StarXTerminator / StarNet2 sobre el estirado de 8 bits)
         var eng = fvStarlessEngine();
         if (eng && eng.id !== "own") {
            var sl = fvStarlessProcess(full, eng.id);
            if (sl.ok) { slBmp = (sl.bmp.width === full.width && sl.bmp.height === full.height) ? sl.bmp : sl.bmp.scaledTo(full.width, full.height); slHow = eng.label + " at full resolution (" + sl.ms + " ms)"; }
            else fvxLog("starless at full resolution failed (" + sl.why + "): the work-size one is exported");
         } else fvxLog("starless: own method (Gaia positions) has no full-resolution version: the work-size one is exported");
      }
      var png = (full && (opts.lossless === true || FV_EXPORT.LOSSLESS === true)), ext = png ? "png" : "jpg", mime = png ? "image/png" : "image/jpeg";
      files.meta.format = ext;
      var saveImg = function(b, path) { if (png) b.save(path); else b.save(path, Q); };
      if (phBmp) { saveImg(phBmp, dir + "/scene/photo." + ext); files.photo = "photo"; bytes64 += fvxImgJs(dir, "photo", "photo." + ext, mime); }
      if (slBmp) { saveImg(slBmp, dir + "/scene/starless." + ext); files.starless = "starless"; files.meta.starless = [slBmp.width, slBmp.height]; files.meta.starlessHow = slHow; bytes64 += fvxImgJs(dir, "starless", "starless." + ext, mime); }
      if (full) { try { full.clear(); } catch (eC) {} }
      if (bmps && bmps.layers) for (i = 0; i < bmps.layers.length; ++i) {
         var lb = bmps.layers[i], lw = Math.min(layerW, lb.width), lh = Math.round(lb.height * lw / lb.width), sb = (lw === lb.width) ? lb : lb.scaledTo(lw, lh);
         sb.save(dir + "/scene/layer" + i + ".jpg", Q); files.layers.push("layer" + i); bytes64 += fvxImgJs(dir, "layer" + i, "layer" + i + ".jpg", "image/jpeg");
      }
      // (N, D) los recortes de los objetos compactos (C)
      var nCut = (bmps && scene.objects) ? fvxObjectCuts(scene, dir, files) : 0; bytes64 += files.objBytes || 0; delete files.objBytes;
      // (V2, 5-nov) el volumen por familias de los objetos (solo con FV_VOLM.ON); sin bandera se borran los atlas que quedaran de otra exportacion
      var nVol = scene.objects ? fvxObjVolumes(scene, dir, files) : 0; bytes64 += files.volBytes || 0; out.volBytes = files.volBytes || 0; delete files.volBytes;
      { var ffV = new FileFind; if (ffV.begin(dir + "/scene/*objvol*")) { var rmV = []; do { var mV = /^(img_)?objvol(\d+)\.(js|png)$/.exec(ffV.name); if (mV && !(files.objVols && files.objVols[+mV[2]])) rmV.push(ffV.name); } while (ffV.next()); rmV.forEach(function(f) { File.remove(dir + "/scene/" + f); }); } }
      if (!nVol) delete files.objVols;
      // (5-nov) STELLAE: las estrellas de la foto (colores y atlas de recortes)
      var tPs = Date.now(), bPs = fvxPhotoStars(sceneOrBuilt, dir, files, opts); bytes64 += bPs; opts._ps = files.photoStars || null; delete files.photoStars; out.psBytes = bPs; step("photo stars (" + Math.round(bPs / 1024) + " KiB base64)", tPs);
      ["img_obj", "obj"].forEach(function(pre) { var ff = new FileFind; if (ff.begin(dir + "/scene/" + pre + "*")) { var rm = []; do { var mm = /^(img_)?obj(\d+)\.(js|png)$/.exec(ff.name); if (mm && !(files.objCuts && files.objCuts[+mm[2]])) rm.push(ff.name); } while (ff.next()); rm.forEach(function(f) { File.remove(dir + "/scene/" + f); }); } });
      step("images (photo " + (files.meta.photo ? files.meta.photo.join("x") : "-") + " q" + files.meta.quality + ", starless " + (files.meta.starless ? files.meta.starless.join("x") + " " + files.meta.starlessHow : "-") + ", " + files.layers.length + " layers, " + nCut + " object cuts)", t);
      // 3. el volumen D9
      var vol = null;
      // (F3b) el visor calcula el relieve v2 de la foto sin estrellas: el atlas 3D de F3 ya no se usa; solo con opts.volumeAtlas
      // el paquete se reescribe cada vez: el atlas de una exportacion anterior se quita (3,5 MiB que ya nadie lee)
      if (opts.volumeAtlas !== true) ["img_volume.js", "volume_atlas.png"].forEach(function(f) { if (File.exists(dir + "/scene/" + f)) File.remove(dir + "/scene/" + f); });
      if (bmps && bmps.starless && scene.nebula && opts.volume !== false && opts.volumeAtlas === true) {
         t = Date.now();
         var spx = new Uint32Array(bmps.starless.pixelData());
         vol = fvVolumeBuild(spx, bmps.starless.width, bmps.starless.height, { nx: opts.volNx, nz: opts.volNz, spoil: opts.spoilVolume || "" });
         var ab = new Bitmap(vol.atlasW, vol.atlasH, BitmapFormat.RGB32);
         new Uint32Array(ab.pixelData()).set(vol.atlas);
         ab.save(dir + "/scene/volume_atlas.png");
         files.volume = "volume"; bytes64 += fvxImgJs(dir, "volume", "volume_atlas.png", "image/png");
         out.volume = { res: [vol.nx, vol.ny, vol.nz], atlas: [vol.atlasW, vol.atlasH], emax: vol.emax, ms: vol.stats.ms, clippedFrac: vol.stats.clippedFrac, homeErrMean: vol.stats.homeErrMean, homeRefMean: vol.stats.homeRefMean, nonzeroFrac: vol.stats.nonzeroFrac };
         vol.atlas = null;
         step("volume " + vol.nx + "x" + vol.ny + "x" + vol.nz + " (build " + vol.stats.ms + " ms, home error " + vol.stats.homeErrMean.toFixed(4) + " / " + vol.stats.homeRefMean.toFixed(4) + ")", t);
      }
      // 4. la escena
      t = Date.now();
      var obj = fvxSceneObject(scene, files, vol, opts);
      // (11-nov-2026, NV-13) la rejilla de luz del laboratorio de vuelo (fvLabLumGrid) de la MISMA foto que lee el pintor de PixInsight (photoPlane =
      // bmps.starless, la de trabajo al ancho de las capas; la del paquete puede ser otra: StarXTerminator a resolucion completa). El visor la toma de
      // aqui y el viaje sale igual que en PixInsight; sin ella la calcula de la foto del paquete (diferencia medida: 0,008, tests/web/fv_nv13_lum_cdp.js)
      if (bmps && bmps.starless && typeof fvLabLumGrid === "function" && typeof FV_LAB !== "undefined" && FV_LAB.CONTENT) {
         var lg = fvLabLumGrid(bmps.starless, FV_LAB.CONTENT.GRID_X, FV_LAB.CONTENT.GRID_Y);
         if (lg) obj.labLum = { nx: lg.nx, ny: lg.ny, v: lg.v, raw: lg.raw, src: "photoPlane " + bmps.starless.width + "x" + bmps.starless.height };
      }
      var js = "window.FV_SCENE = " + JSON.stringify(obj) + ";\n";
      File.writeTextFile(dir + "/scene/scene.js", js);
      out.bytes = js.length + bytes64;
      step("scene.js " + Math.round(js.length / 1024) + " KiB (" + scene.stars.n + " stars)", t);
      out.index = dir + "/index.html"; out.ok = true;
   } catch (e) { out.why = String((e && e.message) ? e.message : e); fvxLog("FAILED: " + out.why); }
   out.ms = Date.now() - t0;
   return out;
}

// la carpeta temporal del sistema para el visor (se reescribe cada vez; no se acumula)
function fvExportDefaultDir() { return String(File.systemTempDirectory).split("\\").join("/") + "/" + FV_EXPORT.DIRNAME; }
// file:///… de una ruta (con «/» y los espacios y signos escapados)
function fvFileUrl(path) {
   var p = String(path).split("\\").join("/");
   // (sin barras dobles ni barra-asterisco en cadenas o regex: el preprocesador de PixInsight las toma por comentarios)
   var sl = "/";
   if (p.charAt(0) !== sl) p = sl + p;
   return "file:" + sl + sl + p.split(sl).map(function(s) { return encodeURIComponent(s).replace(/%3A/g, ":"); }).join("/");
}
// EXPORTA Y ABRE en el navegador del sistema. opts.dry: no abre (pruebas) -> { ok, why, export, url, exe, args }
function fvOpenInBrowser(sceneOrBuilt, opts) {
   opts = opts || {};
   var dir = opts.dir || fvExportDefaultDir(), ex = fvExportScene(sceneOrBuilt, dir, opts), out = { ok: false, why: "", export: ex, url: "", exe: "", args: [] };
   if (!ex.ok) { out.why = ex.why; return out; }
   out.url = fvFileUrl(ex.index);
   if (typeof cshSystemBrowser !== "function") { out.why = "cshSystemBrowser not available (CabraShared/csh_web.js)"; return out; }
   // la ruta del fichero (no la URL): el manejador de cada sistema la abre con el navegador por defecto
   var r = cshSystemBrowser(ex.index, { dry: opts.dry === true });
   out.ok = r.ok; out.exe = r.exe; out.args = r.args; out.why = r.why || "";
   fvxLog((opts.dry ? "(dry) " : "") + "open " + ex.index + " with " + r.exe + " → " + (r.ok ? "ok" : "FAILED " + r.why));
   return out;
}
