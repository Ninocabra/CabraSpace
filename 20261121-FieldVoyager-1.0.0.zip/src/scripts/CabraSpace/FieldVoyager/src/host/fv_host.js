// ============================================================================
// FieldVoyager/src/host/fv_host.js — EL ANFITRION: lo que CabraShared espera del script (3-nov-2026, F1)
// ----------------------------------------------------------------------------
// CabraShared llama a un puñado de funciones que pone cada script (optT, optProcessEvents, cpProcessAvailable…).
// Aqui van con la MISMA firma, en version minima. PROCEDENCIA: Cabra3D/src/host/host.js:14-55 y host_copied.js:98-100
// (copiado y recortado; Cabra3D no se toca).
// Idioma: la interfaz en ingles con el castellano en paralelo (FV_ES); los tooltips llevan los dos.
// ES5.
// ============================================================================

var CP_SETTINGS_PREFIX = "FieldVoyager";
var CP_GLOBAL = (typeof globalThis !== "undefined") ? globalThis : this;
var FV_LANG = "en";            // "en" | "es" (lo recordado: Settings FieldVoyager/lang)
var FV_LOG_HOOK = null;        // pruebas: function(s) recibe cada linea de fvLog
if (typeof Bitmap.prototype.clear === "undefined") Bitmap.prototype.clear = function() {};
if (typeof Image.prototype.free === "undefined") Image.prototype.free = function() {};

// el bombeo de eventos: nunca con un pintado abierto (CabraBase pjsr/atender-eventos-dentro-de-onpaint-mata-el-pintor.md)
var FV_PAINTING = 0;
function optProcessEvents() {
   if (FV_PAINTING > 0) return;
   if (typeof CSH_PAINTING === "number" && CSH_PAINTING > 0) return;
   try { CoreApplication.processEvents(); } catch (e) {}
}
function cpProcessAvailable(name) { try { return (typeof CP_GLOBAL[name] === "function"); } catch (e) { return false; } }

// castellano de los textos propios
var FV_ES = {
   "Info": "Info",
   "Warp": "Warp",
   "Go to": "Ir a",
   "Exoplanet": "Exoplaneta",
   "Home": "Inicio",
   "measured": "medido",
   "assumed": "supuesto",
   "doubtful": "dudoso",
   "light years": "años luz"
};
function optT(s) {
   if (FV_LANG === "es" && Object.prototype.hasOwnProperty.call(FV_ES, s)) return FV_ES[s];
   return s;
}
function fvLoadLang() { try { var v = Settings.read(CP_SETTINGS_PREFIX + "/lang", DataType_String); if (v === "es" || v === "en") FV_LANG = v; } catch (e) {} }

// el registro: a la consola (y a quien escuche, en pruebas)
function fvLog(s) {
   // (21-nov, PKG-final) la consola de PixInsight toma «<» por el inicio de una etiqueta y se lo come («u < 0.5» salia «u  0.5»; medido con tests/_pkg_final/fv_console_enc_probe.js): se escapa solo aqui, el gancho de pruebas recibe el texto tal cual
   try { console.writeln("<end><cbr>FieldVoyager: " + String(s).replace(/</g, "&lt;")); } catch (e) {}
   if (typeof FV_LOG_HOOK === "function") { try { FV_LOG_HOOK(String(s)); } catch (e2) {} }
}
// reloj de alta resolucion en ms (ElapsedTime: validado en la sonda F0a, V0)
var FV_CLOCK = new ElapsedTime;
function fvNowMs() { return FV_CLOCK.value * 1000; }
