// ============================================================================
// FieldVoyager/src/radio/fv_music.js — EL MOTOR DE MUSICA GENERATIVA de RADIOPHONIA (4-nov-2026)
// ----------------------------------------------------------------------------
// Diez emisoras PROPIAS que se componen solas con WebAudio: ningun fichero de audio, ninguna descarga, ningun tercero.
// Obra propia del proyecto (CC0 / la licencia de FieldVoyager). La usan:
//   · src/radio/fv_radio.html  (la radio de la cabina de PixInsight, en un WebView)
//   · web/fw_radio.js           (el visor del navegador; fv_export.js copia este fichero al paquete)
//   · tests/radio/fv_music_render.html (render sin tiempo real con OfflineAudioContext para la escucha y las medidas)
// Como suena: cada emisora es un preset (tonalidad, tempo, progresiones, instrumentos, estructura). Un secuenciador de semicorcheas
// programa notas por delante del reloj de audio; cada paso sabe su lugar en un CICLO de 2-2,5 min con su curva de intensidad
// (intro → subida lenta y continua → climax → bajada) y los instrumentos entran, se abren o se espesan segun esa intensidad.
// Semilla fija por emisora y por paso: el mismo instante de la emisora suena siempre igual (como una emision de verdad).
// Cadena: canales (filtro, vibrato, panorama) → envio a reverb por convolucion (impulso generado) y a eco ping-pong → compresor
// suave («glue») → paso bajo (la atenuacion de la cabina) → limitador → recorte suave de seguridad → salida.
// Opcional: setLevel(0-1) — la nave pide mas o menos intensidad (warp, crucero, llegada); null = solo la composicion.
// ES5 (sin «barra asterisco»: mismas reglas que los .js de PJSR, aunque este no lo incluye PJSR).
// ============================================================================

var FVMusic = (function() {
   var VERSION = "M2-2";   // (R4, 12-nov) LITE: el motor sin RICH desconecta las notas muertas (ver this.lite); (M2, 5-nov) sintesis ENRIQUECIDA (RICH); M1-4 = K14: anticipacion 1 s, reconstruccion sin corte, medida del secuenciador
   // (M2) LA BANDERA. Nino (5-nov): «muy poco elaborada, suena a sintetizador de los 80; mas sutil, compleja y suave». Con RICH la MISMA
   // partitura (play() de cada emisora no cambia: mismas notas en el mismo paso) suena con otros instrumentos y se le añaden capas:
   //   · timbre: sierras con armonicos que caen mas deprisa (1/n^1,45), filtro por nota que respira, resonancias bajas (nada de «squelch»),
   //     ataques mas lentos y colas naturales; las FM (piano electrico, campana, marimba, kalimba) pasan a sintesis MODAL (parciales con su
   //     propia caida); el organo gana un registro celeste; los metales, triangulo y menos brillo; la percusion, mucho mas discreta.
   //   · matices: velocidad y tiempo humanizados por nota (0-8 ms, ±11 %), acento del pulso y respiracion de cada acorde.
   //   · capas nuevas (P.rich): cuerdas en ensemble con voicing de novena, contramelodia (flauta o violonchelo) y arpa/celesta.
   //   · espacio: ensemble/chorus estereo en los canales sostenidos, sala mas grande y calida, eco mas oscuro, estante de agudos −4 dB y
   //     paso bajo a 11 kHz en el conjunto.
   // false = el motor M1-4 IDENTICO (muestra a muestra: tests/radio/fv_music_rich.mjs, prueba R0). Por motor: create(ctx, dest, { rich: false }).
   var RICH = true;
   function clamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
   function sstep(u) { u = clamp(u, 0, 1); return u * u * (3 - 2 * u); }
   function hz(m) { return 440 * Math.pow(2, (m - 69) / 12); }
   function rngOf(seed) {
      var a = (seed >>> 0) || 1;
      return function() { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
   }
   // acordes: semitonos sobre su raiz
   var QUAL = { M: [0, 4, 7], m: [0, 3, 7], M7: [0, 4, 7, 11], m7: [0, 3, 7, 10], d7: [0, 4, 7, 10], sus2: [0, 2, 7], sus4: [0, 5, 7],
                add9: [0, 2, 4, 7], madd9: [0, 2, 3, 7], M9: [0, 2, 4, 7, 11], m9: [0, 2, 3, 7, 10], five: [0, 7] };
   function pc(m) { return ((m % 12) + 12) % 12; }
   // las notas del acorde ch = [raiz en semitonos sobre la tonica, calidad] que caen en [lo, lo+span): conduccion de voces por registro
   function chordIn(key, ch, lo, span) {
      var iv = QUAL[ch[1]] || QUAL.M, want = {}, out = [], i, m;
      for (i = 0; i < iv.length; ++i) want[pc(key + ch[0] + iv[i])] = true;
      for (m = lo; m < lo + span; ++m) if (want[pc(m)]) out.push(m);
      return out;
   }
   function rootIn(key, ch, lo) { var r = key + ch[0]; while (r < lo) r += 12; while (r >= lo + 12) r -= 12; return r; }
   function scaleNote(key, scale, d) { var n = scale.length, o = Math.floor(d / n), i = d - o * n; return key + 12 * o + scale[i]; }
   // la curva de intensidad del ciclo: A = [fin intro, fin subida, fin climax, nivel bajo]
   function shape(P, p, cyc) {
      var A = P.shape, lo = A[3], pk = 1 - 0.05 * (cyc % 2);
      if (p < A[0]) return lo + 0.06 * (p / A[0]);
      if (p < A[1]) { var u = (p - A[0]) / (A[1] - A[0]); return lo + 0.06 + (pk - lo - 0.06) * (0.45 * u + 0.55 * sstep(u)); }
      if (p < A[2]) return pk;
      return pk + (lo - pk) * sstep((p - A[2]) / (1 - A[2]));
   }

   // ---------------- envolventes (siempre empiezan y acaban en 0: sin clics) ----------------
   function adsr(p, t, a, d, s, hold, r, v) {   // (R4) deja en p._end el instante en que la ganancia queda en 0: el motor LITE desconecta la nota ahi (E_._sweep)
      v = Math.max(v, 2e-4);
      var tA = t + a, tH = Math.max(t + hold, tA + 0.005), lev = v;
      p.setValueAtTime(0, t); p.linearRampToValueAtTime(v, tA);
      if (s < 0.999 && d > 0) {
         var tD = Math.min(tA + d, tH), u = (tD - tA) / d;
         lev = Math.max(v * Math.pow(Math.max(s, 1e-3), u), 2e-4);
         if (tD > tA + 1e-4) p.exponentialRampToValueAtTime(lev, tD);
      }
      p.setValueAtTime(lev, tH);
      p.exponentialRampToValueAtTime(2e-4, tH + r);
      p.linearRampToValueAtTime(0, tH + r + 0.015);
      p._end = tH + r + 0.015;
      return tH + r + 0.03;
   }
   function perc(p, t, a, dec, v) {
      v = Math.max(v, 2e-4);
      p.setValueAtTime(0, t); p.linearRampToValueAtTime(v, t + a); p.exponentialRampToValueAtTime(2e-4, t + a + dec); p.linearRampToValueAtTime(0, t + a + dec + 0.015);
      p._end = t + a + dec + 0.015;
      return t + a + dec + 0.03;
   }

   // ---------------- recursos generados (ningun fichero) ----------------
   function noiseBuf(c, secs, R) {
      var n = Math.floor(c.sampleRate * secs), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
      for (var i = 0; i < n; ++i) d[i] = R() * 2 - 1;
      return b;
   }
   // respuesta al impulso de una sala grande: ruido estereo decorrelado con caida exponencial que se oscurece con el tiempo y
   // energia normalizada a 1 (el envio de cada canal fija cuanta reverb lleva). (M1-2) Sin reflexiones tempranas de una sola muestra:
   // daban copias metalicas de cada ataque (medido: transitorios sin nota que los explique a 60-150 ms, solo en un canal)
   // (M2) warm: sala mas calida (los agudos mueren antes: a cae con 0,45 s) y una nube de primeras reflexiones DIFUSA entre 10 y 80 ms
   // (ruido, nunca muestras sueltas: ver M1-2), que da cuerpo de sala sin eco discreto
   // (R4, 12-nov-2026) el nucleo (identico al de antes: mismo algoritmo, mismo generador de numeros) devuelve las dos Float32Array normalizadas; makeIR las vuelca al buffer.
   // A 24 kHz (la radio de PixInsight, ver fv_radio.html) la MISMA sala se genera a 48 kHz y se pliega sumando de k en k muestras: ninguna ganancia que ajustar (a graves
   // la suma de k muestras seguidas conserva la respuesta de la sala de 48 kHz) y los mismos picos de graves de ese impulso de ruido; generarla directamente a 24 kHz daba
   // otra realizacion del ruido, 4 dB mas baja a 30-60 Hz y 1,7 LU menos en la emisora 5 (medido, tests/radio/r4_sr_probe_chrome.mjs)
   function irCore(sr, secs, pre, R, warm) {
      var n = Math.floor(sr * secs), np = Math.floor(pre * sr), e = 0, ch, i, D = [new Float32Array(n), new Float32Array(n)];
      for (ch = 0; ch < 2; ++ch) {
         var d = D[ch], y = 0;
         for (i = np; i < n; ++i) {
            var t = (i - np) / sr, env = Math.exp(-6.9 * t / secs) * (t < 0.006 ? t / 0.006 : 1), a = warm ? 0.05 + 0.6 * Math.exp(-t / 0.45) : 0.1 + 0.75 * Math.exp(-t / 0.8);
            if (warm) { if (t < 0.12) { var q = (t - 0.035) / 0.025; env *= 1 + 1.1 * Math.exp(-q * q); } }
            y += a * ((R() * 2 - 1) - y); d[i] = y * env;
         }
         for (i = 0; i < n; ++i) e += d[i] * d[i];
      }
      var s = 1 / Math.sqrt(e / 2 + 1e-12);
      for (ch = 0; ch < 2; ++ch) { var dd = D[ch]; for (i = 0; i < n; ++i) dd[i] *= s; }
      return D;
   }
   function makeIR(c, secs, pre, R, warm) {
      var sr = c.sampleRate, k = (sr < 48000 && 48000 % sr === 0) ? 48000 / sr : 1, n = Math.floor(sr * secs), b = c.createBuffer(2, n, sr), D = irCore(k > 1 ? 48000 : sr, secs, pre, R, warm), ch, i, j;
      for (ch = 0; ch < 2; ++ch) {
         var dst = b.getChannelData(ch), src = D[ch];
         if (k === 1) dst.set(src.subarray(0, n));
         else for (i = 0; i < n; ++i) { var acc = 0; for (j = 0; j < k; ++j) acc += src[i * k + j] || 0; dst[i] = acc; }
      }
      return b;
   }
   function softCurve() {
      var n = 4096, cv = new Float32Array(n);
      for (var i = 0; i < n; ++i) { var x = i * 2 / (n - 1) - 1, ax = Math.abs(x), y = ax <= 0.8 ? ax : 0.8 + 0.18 * Math.tanh((ax - 0.8) / 0.18); cv[i] = x < 0 ? -y : y; }
      return cv;
   }
   function pwave(c, amps) {
      var n = amps.length + 1, re = new Float32Array(n), im = new Float32Array(n);
      for (var i = 0; i < amps.length; ++i) im[i + 1] = amps[i];
      return c.createPeriodicWave(re, im);
   }
   function comp(c, th, knee, ratio, att, rel) {
      var k = c.createDynamicsCompressor();
      k.threshold.value = th; k.knee.value = knee; k.ratio.value = ratio; k.attack.value = att; k.release.value = rel;
      return k;
   }

   // ---------------- el motor ----------------
   // (K14) la anticipacion del secuenciador: lo que tiene programado por delante del reloj de audio. Un parón del hilo principal MAS LARGO que
   // ella se come pulsos (arpegios, percusion: los colchones y bajos de cada acorde ya estan programados enteros). 0,4 s (K13) cubria la marcha
   // normal; el primer parón largo perdia pulsos. AHEAD_ROBUST cubre el fotograma mas lento medido (ver tests/radio/k14_*): el nivel del viaje
   // (setLevel) responde ese tiempo mas tarde, pero ya va suavizado con una constante de 2,5 s (lvSm) y la ganancia del conjunto cambia por compas.
   var AHEAD_OLD = 0.4, AHEAD_ROBUST = 1.0;
   function Engine(ctx, dest, opts) {
      opts = opts || {};
      var c = ctx;
      // (K13 H-1) `ahead` es la anticipacion MINIMA (0,4 s: con el llamador a ~33 ms); tick() la sube sola si el llamador se espacia (aeff)
      // (K14, E2 «entrecortada») robust (por defecto): anticipacion minima AHEAD_ROBUST en vez de 0,4 s y la reconstruccion tras un hueco sin
      // bajar la ganancia a 0. robust = false es el motor de antes (el CONTROL de las pruebas).
      this.ctx = c; this.offline = !!opts.offline; this.robust = (opts.robust !== false); this.aheadUser = opts.ahead || 0;
      this.ahead = this.aheadUser || (this.robust ? AHEAD_ROBUST : AHEAD_OLD); this.aeff = this.ahead; this.gapEst = 0; this.lastTick = null;
      this.rnd = rngOf(opts.seed || 20261104);
      this.rich = (opts.rich === undefined) ? RICH : !!opts.rich;
      // (R4, 12-nov-2026) LITE = el motor que corre en PixInsight (sin RICH): su WebAudio es ~8x mas lento que el de Chrome (R3) y cada nodo cuesta aunque ya no suene.
      // Medido (tests/radio/r4_*): el coste NO esta en la sala ni en la cadena (la convolucion de 4,6 s es el 2 %), esta en los nodos de las notas. Lite: las notas
      // terminadas se desconectan del canal (E_._sweep) en vez de quedarse en el grafo hasta que el recolector de la pagina las suelte. Mismas notas, mismo sonido.
      // lite:false = el motor de antes de R4 (el CONTROL de las pruebas). El camino RICH (el visor web) no se toca.
      this.lite = !this.rich && opts.lite !== false; this.live = [];
      this.mix = c.createGain();
      this.glue = comp(c, -20, 10, 2.5, 0.03, 0.3);
      this.lp = c.createBiquadFilter(); this.lp.type = "lowpass"; this.lp.frequency.value = 18000; this.lp.Q.value = 0.5;
      this.lim = comp(c, -6, 2, 12, 0.002, 0.12);
      this.clip = c.createWaveShaper(); this.clip.curve = softCurve(); this.clip.oversample = "2x";
      this.out = c.createGain(); this.out.gain.value = (opts.gain === undefined) ? 1 : opts.gain;
      if (this.rich) {
         // (M2) el tono del conjunto: estante de agudos −4 dB desde 4,5 kHz y paso bajo suave a 11 kHz (lo chillon de las ondas desnudas).
         // Fijo y aparte de this.lp (que es la atenuacion de la cabina, setLowpass)
         this.shelf = c.createBiquadFilter(); this.shelf.type = "highshelf"; this.shelf.frequency.value = 4500; this.shelf.gain.value = -4;
         this.soft = c.createBiquadFilter(); this.soft.type = "lowpass"; this.soft.frequency.value = 11000; this.soft.Q.value = 0.5;
         this.mix.connect(this.glue); this.glue.connect(this.shelf); this.shelf.connect(this.soft); this.soft.connect(this.lp);
      } else { this.mix.connect(this.glue); this.glue.connect(this.lp); }
      this.lp.connect(this.lim); this.lim.connect(this.clip); this.clip.connect(this.out); this.out.connect(dest);
      this.revIn = c.createGain(); this.conv = c.createConvolver(); this.conv.normalize = false;
      this.conv.buffer = this.rich ? makeIR(c, 5.2, 0.022, rngOf(77), true) : makeIR(c, 4.6, 0.014, rngOf(77));
      this.revIn.connect(this.conv); this.conv.connect(this.mix);
      // eco ping-pong: izquierda → derecha → realimentacion oscurecida
      this.dlyIn = c.createGain();
      var dL = c.createDelay(4), dR = c.createDelay(4), fb = c.createGain(), fl = c.createBiquadFilter(), mg = c.createChannelMerger(2), toRev = c.createGain();
      fb.gain.value = this.rich ? 0.3 : 0.36; fl.type = "lowpass"; fl.frequency.value = this.rich ? 2200 : 3000; toRev.gain.value = 0.35;
      dL.delayTime.value = 0.375; dR.delayTime.value = 0.375;
      this.dlyIn.connect(dL); dL.connect(mg, 0, 0); dL.connect(dR); dR.connect(mg, 0, 1); dR.connect(fl); fl.connect(fb); fb.connect(dL);
      mg.connect(this.mix); mg.connect(toRev); toRev.connect(this.revIn);
      this.dL = dL; this.dR = dR;
      this.noise = noiseBuf(c, 2, rngOf(99));
      // (M1-2) registros del organo con los armonicos 8.º-16.º bajados: medido, el 8.º de un Do sostenido 15 s quedaba a -23 dB de la mezcla (pitido)
      this.waves = { soft: pwave(c, [1, 0.55, 0.12, 0.2, 0, 0.05, 0, 0.05]), med: pwave(c, [1, 0.7, 0.35, 0.32, 0.1, 0.18, 0, 0.1, 0, 0.03]),
                     full: pwave(c, [1, 0.8, 0.55, 0.6, 0.25, 0.35, 0.08, 0.18, 0.05, 0.08, 0, 0.05]) };
      // (M2) la «sierra suave» que sustituye a la sierra desnuda: armonicos 1/n^1,45 (la de serie es 1/n) y caida extra por encima del 14.º
      if (this.rich) { var sa = []; for (var hi = 1; hi <= 40; ++hi) sa.push(Math.pow(hi, -1.45) * (hi > 14 ? Math.exp(-(hi - 14) / 6) : 1)); this.waves.ssaw = pwave(c, sa); }
      this.st = null; this.lvTo = null; this.lvSm = 0.45; this.fixedI = null; this.notes = 0; this.steps = 0;
      this.lastWall = null; this.statReset();
   }
   var E_ = Engine.prototype;

   // un canal de instrumento: [formantes] → [paso bajo] → [paso alto] → [vibrato] → panorama → volumen → seco / reverb / eco
   E_._chan = function(S, o) {
      var c = this.ctx, C = { in: c.createGain() }, node = C.in, i;
      if (o.formant) {
         var sum = c.createGain();
         for (i = 0; i < o.formant.length; ++i) { var F = o.formant[i], bp = c.createBiquadFilter(), g = c.createGain(); bp.type = "bandpass"; bp.frequency.value = F[0]; bp.Q.value = F[1]; g.gain.value = F[2]; node.connect(bp); bp.connect(g); g.connect(sum); }
         node = sum;
      }
      if (o.lp) { C.lpf = c.createBiquadFilter(); C.lpf.type = "lowpass"; C.lpf.frequency.value = o.lp; C.lpf.Q.value = (this.rich ? Math.min(o.lq || 0.6, 0.7) : (o.lq || 0.6)); node.connect(C.lpf); node = C.lpf;
         // (M2) el filtro RESPIRA: un LFO lentisimo (11-20 s) mueve el corte ±15 % sobre lo que pida sweep()
         if (this.rich) { var bl = c.createOscillator(), bg = c.createGain(); bl.frequency.value = 0.05 + 0.04 * this.rnd(); bg.gain.value = 0.15 * o.lp; bl.connect(bg); bg.connect(C.lpf.frequency); bl.start(); S.lfos.push(bl); }
      }
      if (o.hp) { var h = c.createBiquadFilter(); h.type = "highpass"; h.frequency.value = o.hp; h.Q.value = 0.6; node.connect(h); node = h; }
      if (o.vib) {
         var dl = c.createDelay(0.05), lfo = c.createOscillator(), lg = c.createGain();
         dl.delayTime.value = 0.008; lfo.frequency.value = o.vib[0]; lg.gain.value = o.vib[1];
         lfo.connect(lg); lg.connect(dl.delayTime); lfo.start(); S.lfos.push(lfo);
         node.connect(dl); node = dl;
      }
      if (this.rich && (o.vib || o.formant || o.ens)) node = this._ens(S, node);
      if (c.createStereoPanner) { var pn = c.createStereoPanner(); pn.pan.value = o.pan || 0; node.connect(pn); node = pn; }
      C.vol = c.createGain(); C.vol.gain.value = (o.gain === undefined) ? 1 : o.gain; node.connect(C.vol);
      C.vol.connect(S.dry);
      if (o.rev) { var r = c.createGain(); r.gain.value = this.rich ? o.rev * 1.2 : o.rev; C.vol.connect(r); r.connect(S.rev); }
      if (o.dly) { var e = c.createGain(); e.gain.value = this.rich ? o.dly * 0.85 : o.dly; C.vol.connect(e); e.connect(S.dly); }
      return C;
   };
   // (M2) ENSEMBLE: tres copias con retardos de 12-23 ms modulados por LFO lentos (0,47-1,07 Hz) y abiertas en estereo (izquierda, centro,
   // derecha) mas la señal seca: lo que convierte «dos sierras» en una seccion de cuerdas o un coro que ocupa el panorama
   E_._ens = function(S, node) {
      var c = this.ctx, sum = c.createGain(), dry = c.createGain(), D = [0.012, 0.0175, 0.023], F = [0.47, 0.71, 1.07], A = [0.0016, 0.0021, 0.0013], PN = [-0.7, 0.05, 0.7];
      dry.gain.value = 0.45; node.connect(dry); dry.connect(sum);
      for (var i = 0; i < 3; ++i) {
         var d = c.createDelay(0.06), l = c.createOscillator(), lg = c.createGain(), g = c.createGain();
         d.delayTime.value = D[i]; l.frequency.value = F[i]; lg.gain.value = A[i]; l.connect(lg); lg.connect(d.delayTime); l.start(); S.lfos.push(l);
         g.gain.value = 0.3; node.connect(d); d.connect(g);
         if (c.createStereoPanner) { var p = c.createStereoPanner(); p.pan.value = PN[i]; g.connect(p); p.connect(sum); } else g.connect(sum);
      }
      return sum;
   };
   E_.sweep = function(C, t, f, tau) { if (C.lpf) C.lpf.frequency.setTargetAtTime(Math.max(40, f), t, tau || 0.5); };

   // ---------------- arranque, cambio y parada de emisora ----------------
   E_.start = function(idx, offset, when) {
      var c = this.ctx, P = PRESETS[clamp(idx | 0, 0, PRESETS.length - 1)], t0 = Math.max(when || 0, c.currentTime + 0.03);
      if (this.st) this._fade(this.st, t0, 0.35);
      var S = { P: P, idx: PRESETS.indexOf(P), t0: t0, off: Math.max(0, offset || 0), dt: 60 / P.bpm / 4, step: 0, lfos: [], dead: false };
      S.dry = c.createGain(); S.rev = c.createGain(); S.dly = c.createGain();
      var gs = [S.dry, S.rev, S.dly];
      for (var i = 0; i < 3; ++i) { gs[i].gain.setValueAtTime(0, t0); gs[i].gain.linearRampToValueAtTime(this._trim(P), t0 + 0.25); }
      S.dry.connect(this.mix); S.rev.connect(this.revIn); S.dly.connect(this.dlyIn);
      var beat = S.dt * 4;
      this.dL.delayTime.setTargetAtTime(beat * P.echo, t0, 0.02); this.dR.delayTime.setTargetAtTime(beat * P.echo, t0, 0.02);
      S.C = P.chans(this, S);
      if (this.rich && P.rich) S.X = this._xchans(S, P);   // (M2) los canales de las capas nuevas
      S.step = Math.ceil(S.off / S.dt - 1e-9);
      this.lastTick = null;   // (K13) el hueco entre llamadas se mide desde la primera de esta emisora
      S.join = true;          // al sintonizar a mitad de acorde, las notas largas del acorde en curso suenan ya (no hay que esperar al siguiente)
      this.st = S;
      return S;
   };
   E_._fade = function(S, t, secs) {
      if (S.dead) return; S.dead = true;
      var gs = [S.dry, S.rev, S.dly], i;
      // (K13 H-3) cancelScheduledValues(t) borra tambien el FINAL de la rampa de entrada si aun esta en curso y el parametro cae al evento anterior
      // (el 0 del arranque): un salto de la ganancia que ya sonaba. cancelAndHoldAtTime la deja donde iba. Sin esa funcion (Firefox antiguo,
      // Safari): se fija el valor de AHORA (gain.value) desde ahora y se mantiene hasta t, que en la practica esta a 10-30 ms.
      for (i = 0; i < 3; ++i) {
         var pr = gs[i].gain;
         if (typeof pr.cancelAndHoldAtTime === "function") pr.cancelAndHoldAtTime(t);
         else { var now0 = this.ctx.currentTime, v0 = pr.value; pr.cancelScheduledValues(now0); pr.setValueAtTime(isFinite(v0) ? v0 : 0, now0); }
         pr.setTargetAtTime(0, t, secs / 4);
      }
      for (i = 0; i < S.lfos.length; ++i) { try { S.lfos[i].stop(t + secs + 8); } catch (e) {} }
      if (!this.offline && typeof setTimeout === "function") setTimeout(function() { for (var j = 0; j < 3; ++j) { try { gs[j].disconnect(); } catch (e2) {} } }, (secs + 9) * 1000);
   };
   E_.stop = function(secs) { if (this.st) { this._fade(this.st, this.ctx.currentTime + 0.01, secs || 0.3); this.st = null; } };
   E_.station = function() { return this.st ? this.st.idx : -1; };
   // la intensidad que pide la nave (0-1); null = solo la composicion
   E_.setLevel = function(v, now) { if (v === null || v === undefined || !isFinite(v)) { this.lvTo = null; return; } this.lvTo = clamp(Number(v), 0, 1); if (now) this.lvSm = this.lvTo; };
   // (K14, pruebas) false = el motor de antes (anticipacion 0,4 s y reconstruccion que baja a 0): el control en rojo
   E_.setRobust = function(b) { this.robust = !!b; if (!this.aheadUser) this.ahead = this.robust ? AHEAD_ROBUST : AHEAD_OLD; return this.robust; };
   E_.setLowpass = function(f, tau) { this.lp.frequency.setTargetAtTime(clamp(f, 200, 20000), this.ctx.currentTime, tau || 0.08); };
   // programa los pasos hasta el instante `until` (tiempo del contexto de audio)
   E_.pump = function(until) {
      var S = this.st; if (!S) return 0;
      if (this.lite) this._sweep();
      var n = 0, now = this.ctx.currentTime;
      for (;;) {
         var t = S.t0 + S.step * S.dt - S.off;
         if (t >= until) break;
         // en tiempo real, si el reloj se adelanto (pestaña dormida), los pasos ya pasados se saltan: nada de rafagas
         if (t >= S.t0 - 1e-6) {
            if (this.offline || t >= now - 0.02) { this._step(S, t); ++n; if (!this.offline && t < now) ++this.stat.late; }
            // (K13 H-2) el paso saltado era el comienzo de un acorde: sus notas largas (colchon, bajo, drone) no nacerian nunca y no suenan hasta el
            // acorde siguiente (hasta 12 s). Se pide la reconstruccion de la sintonia a mitad de acorde (join) al primer paso que SI se programe.
            // Saltar solo pasos de en medio no la pide: el acorde ya sonaba y se doblaria (y la ganancia general caeria a 0 y volveria a subir).
            else {
               ++this.stat.lost;
               if (this._chordStart(S, S.step)) { S.join = true; S.rejoin = true; ++this.stat.lostChord; }
            }
         }
         ++S.step;
         if (n > 2000) break;
      }
      this.steps += n;
      return n;
   };
   // ¿el paso k es el comienzo de un acorde? (la misma cuenta que _step: chPos === 0)
   E_._chordStart = function(S, k) {
      var P = S.P, bar = Math.floor(k / 16), sib = k - bar * 16, bic = bar - Math.floor(bar / P.bars) * P.bars;
      return sib === 0 && (bic % P.cb) === 0;
   };
   // (K13 H-1) el secuenciador programa por delante del reloj de audio: lo que el llamador no alcance a programar entre dos llamadas se pierde
   // (pump salta los pasos ya pasados). Con el llamador a ~33 ms bastan 0,4 s; si se espacia (pestaña o ventana en segundo plano: el navegador
   // frena los temporizadores a 1 s) la anticipacion tiene que cubrir el hueco. Se mide el hueco ENTRE LLAMADAS en el reloj de audio, sube de
   // golpe a lo que haga falta (+25 % y 0,1 s de margen, tope 3 s) y baja despacio (0,05 s por segundo de audio): el 0,4 s de siempre en
   // marcha normal (la respuesta al nivel del vuelo no se retrasa) y solo se paga la anticipacion cuando hace falta. El primer hueco largo
   // SI pierde pulsos (no se puede programar lo que aun no se sabe que hara falta): despues de el, no.
   E_.tick = function() {
      if (!this.st) { this.lastTick = null; this.lastWall = null; return 0; }
      var now = this.ctx.currentTime, gap = (this.lastTick === null) ? 0 : Math.min(2.5, Math.max(0, now - this.lastTick));   // (un parón de minutos no deja 3 s para siempre)
      this._measure(now);
      this.lastTick = now;
      this.gapEst = Math.max(gap, this.gapEst - 0.05 * gap);
      this.aeff = Math.min(3, Math.max(this.ahead, 1.25 * this.gapEst + 0.1));
      return this.pump(now + this.aeff);
   };
   // ---------------- (K14, E2 «entrecortada») LA MEDIDA: huecos entre llamadas, pasos perdidos y margen de programacion ----------------
   // margen = instante del primer paso AUN SIN programar − currentTime, justo al llegar la llamada: cuanta musica quedaba en cola. < 0 = el
   // secuenciador llego tarde y pump() se salta esos pasos (stat.lost; los comienzos de acorde, stat.lostChord). stat.late = pasos programados
   // con su instante ya pasado (< 20 ms: el ataque se come). Hueco = tiempo de pared entre dos llamadas (el hilo principal ocupado o un
   // temporizador frenado). deriva = pared − reloj de audio desde statReset (el hilo de audio que no llega a tiempo la hace crecer).
   function wallS() { return (typeof performance !== "undefined" && performance.now) ? performance.now() / 1000 : Date.now() / 1000; }
   E_.statReset = function() {
      var c = this.ctx;
      this.stat = { ticks: 0, gapMax: 0, gapAudioMax: 0, gaps: [0, 0, 0, 0, 0], lost: 0, lostChord: 0, late: 0, marginMin: 99, marginLow: [0, 0, 0],
                    aeffMax: 0, wall0: wallS(), ctx0: c ? c.currentTime : 0, ev: [] };
      if (c && c.playoutStats) { try { this.stat.po0 = { ev: c.playoutStats.fallbackFramesEvents, dur: c.playoutStats.fallbackFramesDuration }; } catch (e) {} }
      return true;
   };
   var GAPS = [0.1, 0.25, 0.5, 1, 2];
   E_._measure = function(now) {
      var st = this.stat, S = this.st, w = wallS(); if (!st || !S) return;
      var wg = (this.lastWall === null) ? 0 : w - this.lastWall, ag = (this.lastTick === null) ? 0 : now - this.lastTick;
      this.lastWall = w; ++st.ticks;
      if (wg > st.gapMax) st.gapMax = wg;
      if (ag > st.gapAudioMax) st.gapAudioMax = ag;
      for (var i = 0; i < GAPS.length; ++i) if (wg > GAPS[i]) ++st.gaps[i];
      var margin = (S.t0 + S.step * S.dt - S.off) - now;
      if (st.ticks > 1) {
         if (margin < st.marginMin) st.marginMin = margin;
         if (margin < 0.2) ++st.marginLow[0]; if (margin < 0.1) ++st.marginLow[1]; if (margin < 0) ++st.marginLow[2];
      }
      if (this.aeff > st.aeffMax) st.aeffMax = this.aeff;
      if (wg > 0.25 && st.ev.length < 60) st.ev.push({ at: Math.round((w - st.wall0) * 100) / 100, gap: Math.round(wg * 1000), margin: Math.round(margin * 1000), lost0: st.lost });
   };
   // un resumen para las pruebas (JSON plano)
   E_.statGet = function() {
      var st = this.stat, c = this.ctx, w = wallS(), o = {}; if (!st) return null;
      for (var k in st) o[k] = st[k];
      o.wallS = Math.round((w - st.wall0) * 1000) / 1000; o.ctxS = Math.round((c.currentTime - st.ctx0) * 1000) / 1000; o.drift = Math.round((o.wallS - o.ctxS) * 1000) / 1000;
      o.ahead = this.ahead; o.aeff = this.aeff; o.robust = this.robust; o.state = c.state; o.steps = this.steps; o.notes = this.notes;
      if (c.playoutStats && st.po0) { try { o.fallbackEv = c.playoutStats.fallbackFramesEvents - st.po0.ev; o.fallbackS = c.playoutStats.fallbackFramesDuration - st.po0.dur; } catch (e) {} }
      return o;
   };
   E_._step = function(S, t) {
      var P = S.P, k = S.step, spb = 16, bar = Math.floor(k / spb), sib = k - bar * spb, cyc = Math.floor(bar / P.bars), bic = bar - cyc * P.bars;
      var p = (bic * spb + sib) / (P.bars * spb), e = (this.fixedI !== null) ? this.fixedI : shape(P, p, cyc), I = e;
      if (this.lvTo !== null) { this.lvSm += (this.lvTo - this.lvSm) * (1 - Math.exp(-S.dt / 2.5)); I = clamp(e + 0.55 * (this.lvSm - 0.45), 0, 1); }
      var prog = P.progs[cyc % P.progs.length], cb = P.cb, ci = Math.floor(bic / cb) % prog.length, chPos = (bic % cb) * spb + sib, join = S.join, rejoin = !!S.rejoin;
      S.join = false; S.rejoin = false;
      var x = { k: k, sib: sib, bar: bar, bic: bic, cyc: cyc, p: p, e: e, I: I, t: t, dt: S.dt, beatS: S.dt * 4, barS: S.dt * spb,
                ch: prog[ci], chNext: prog[(ci + 1) % prog.length], cs: (chPos === 0) || join, chDur: (cb * spb - (join ? chPos : 0)) * S.dt, chPos: chPos,
                key: P.key, R: rngOf((P.seed * 1000003 + k * 7919) >>> 0) };
      x.lv = function(th, w) { return sstep((x.I - th) / (w || 0.15)); };
      S.lastE = e; S.lastI = I; S.lastT = t;
      // (M1-2) el DIRECTOR: ademas de las capas que entran, el conjunto crece con la intensidad (P.dyn dB entre I = 0 e I = 1).
      // Medido: solo con las capas el fragmento de subida crecia +1 a +2 dB; el compresor se lo comia.
      if (sib === 0 || join) {
         var gv = this._trim(P) * Math.pow(10, (I - 1) * (P.dyn || 9) / 20), gs = [S.dry, S.rev, S.dly];
         // (K14) al sintonizar, la entrada sube de 0 en 0,25 s. Pero la reconstruccion tras un HUECO (rejoin: se perdio un comienzo de acorde)
         // NO baja a 0: lo que aun sonaba (las colas del acorde anterior) se cortaba en seco (medido: tests/radio/k14_music.mjs, R2). Solo va a su nivel.
         for (var gi = 0; gi < 3; ++gi) {
            if (join && rejoin && this.robust) gs[gi].gain.setTargetAtTime(gv, t, 0.08);
            else if (join) { gs[gi].gain.cancelScheduledValues(t); gs[gi].gain.setValueAtTime(0, t); gs[gi].gain.linearRampToValueAtTime(gv, t + 0.25); }
            else gs[gi].gain.setTargetAtTime(gv, t, x.barS * 0.4);
         }
      }
      if (this.rich) { this.hR = rngOf((P.seed * 7919 + k * 104729 + 13) >>> 0); this.cx = x; this.cxS = S; }   // (M2) humanizacion: su PROPIA semilla (x.R no se toca: las notas al azar de cada emisora no cambian)
      if (!this.onlyLayers) P.play(this, S, x);
      if (this.rich && P.rich) this._enrich(S, x);
      this.cx = null;
   };
   // (M2) el nivel de la emisora: con RICH, el medido para la sintesis enriquecida (trimR; las capas nuevas suman sonoridad)
   E_._trim = function(P) { return (this.rich && P.trimR) ? P.trimR : P.trim; };
   // (M2) HUMANIZAR una nota: retraso de 0 a `ms` ms (nunca adelanto: en tiempo real el instante ya podria haber pasado), velocidad ±11 %,
   // acento del pulso (tiempo > corchea > semicorchea) y la RESPIRACION del acorde (cada acorde crece hacia su mitad y se recoge)
   E_._hu = function(t, v, ms) {
      var R = this.hR, x = this.cx; if (!R || !x) return [t, v];
      var span = this.cxS.P.cb * 16, sw = 0.9 + 0.1 * Math.sin(Math.PI * x.chPos / span), acc = (x.sib % 4 === 0) ? 1.04 : (x.sib % 2 === 0 ? 0.97 : 0.92);
      return [t + R() * (ms === undefined ? 8 : ms) / 1000, v * sw * acc * (0.89 + 0.22 * R())];
   };
   // el golpe del climax: subida de ruido en las RB barras anteriores, y bombo profundo con platillo al llegar
   E_.fxPeak = function(S, x, C, v) {
      if (x.sib !== 0) return;
      var P = S.P, b1 = Math.round(P.shape[1] * P.bars), rb = P.riserBars || 4;
      if (x.bic === b1 - rb) this.riser(C, x.t, rb * x.barS, v);
      if (x.bic === b1) { this.boom(C, x.t, v); this.crash(C, x.t, v * 0.6); }
   };
   E_.inRiser = function(S, x) { var P = S.P, b1 = Math.round(P.shape[1] * P.bars), rb = P.riserBars || 4; return x.bic >= b1 - rb && x.bic < b1; };

   // ---------------- (M2) LAS CAPAS NUEVAS (solo con RICH; la partitura de cada emisora, play(), no cambia) ----------------
   // P.rich = { ens: [registro bajo, ancho, umbral de I, volumen], cm: [bajo, alto, umbral, volumen, "fl" flauta | "vc" violonchelo],
   //            harp: [bajo, ancho, umbral, volumen] }; cada capa falta si la emisora no la pide.
   // la novena: el voicing abierto de las cuerdas (mayor → add9, menor → madd9, M7 → M9, m7 → m9)
   var NINTH = { M: "add9", m: "madd9", M7: "M9", m7: "m9" };
   function ninth(ch) { return [ch[0], NINTH[ch[1]] || ch[1]]; }
   E_._xchans = function(S, P) {
      var R = P.rich, vc = R.cm && R.cm[4] === "vc";
      return { ens: this._chan(S, { lp: 2400, vib: [4.7, 0.00013], rev: 0.65, gain: 0.5, pan: -0.05 }),
               cm: this._chan(S, vc ? { lp: 1500, vib: [5.0, 0.00018], rev: 0.5, gain: 0.6, pan: -0.25 } : { lp: 5200, rev: 0.55, dly: 0.1, gain: 0.5, pan: -0.25 }),
               harp: this._chan(S, { rev: 0.55, dly: 0.12, pan: 0.3, gain: 0.45 }) };
   };
   // la nota de la contramelodia: un tono del acorde en [lo, hi] lo mas cerca posible de la anterior pero distinto (se mueve por grados
   // cortos, nunca salta mas de una sexta salvo que no haya otra)
   function cmNote(key, ch, lo, hi, prev) {
      var c = chordIn(key, ch, lo, hi - lo + 1), best = null, bd = 99, i;
      if (!c.length) return null;
      for (i = 0; i < c.length; ++i) { var d = Math.abs(c[i] - prev); if (c[i] !== prev && d < bd && d <= 9) { bd = d; best = c[i]; } }
      return best === null ? c[(c.length / 2) | 0] : best;
   }
   E_._enrich = function(S, x) {
      var P = S.P, R = P.rich, X = S.X, I = x.I, half = P.cb * 8, i;
      this._lay = 1;
      // 1) cuerdas en ensemble con voicing de novena, entrada lenta, por debajo de todo
      if (R.ens && x.cs && I > R.ens[2]) this.pad(X.ens, x.t, chordIn(x.key, ninth(x.ch), R.ens[0], R.ens[1]), x.chDur, R.ens[3] * x.lv(R.ens[2], 0.25), { a: 2.4, r: 2.8, det: 6 });
      // 2) contramelodia: dos notas largas por acorde (en el acorde y a su mitad), legato
      if (R.cm && I > R.cm[2] && (x.chPos === 0 || x.chPos === half)) {
         if (S.cmPrev === undefined) S.cmPrev = (R.cm[0] + R.cm[1]) >> 1;
         var cn = cmNote(x.key, x.ch, R.cm[0], R.cm[1], S.cmPrev), dur = half * x.dt;
         if (cn !== null) {
            S.cmPrev = cn;
            var cv = R.cm[3] * x.lv(R.cm[2], 0.2) * (x.chPos === 0 ? 1 : 0.85);
            if (R.cm[4] === "vc") this.pad(X.cm, x.t, [cn], dur - 0.05, cv, { a: 0.45, r: 0.9, det: 4 });
            else this.flute(X.cm, x.t, cn, dur - 0.08, cv);
         }
      }
      // 3) arpa / celesta: un acorde quebrado hacia arriba (fusas) al empezar el compas; por encima de I = 0,7, tambien a la mitad
      if (R.harp && I > R.harp[2] && (x.sib === 0 || (x.sib === 8 && I > 0.7))) {
         var hn = chordIn(x.key, x.ch, R.harp[0], R.harp[1]), n = Math.min(hn.length, 2 + Math.round(3 * I)), up = (x.bar % 2 === 0), hv = R.harp[3] * x.lv(R.harp[2], 0.2);
         for (i = 0; i < n; ++i) this.harp(X.harp, x.t + i * x.dt * 0.5, hn[up ? i : hn.length - 1 - i], hv * (1 - 0.12 * i));
      }
      this._lay = 0;
   };

   // ---------------- instrumentos ----------------
   E_._g = function(C, t) { var g = this.ctx.createGain(); g.gain.setValueAtTime(0, t); g.connect(C.in); ++this.notes; if (this.onsets) this.onsets.push(t); if (this.lite) this.live.push(g); return g; };
   // (R4) LITE: desconecta las notas cuya envolvente ya cerro (p._end, 0,1 s de margen). Lo que cuelga de una ganancia desconectada deja de procesarse (WebAudio solo
   // procesa lo que llega a la salida) y se puede recoger. Se llama al programar (pump), tanto en tiempo real como sin el.
   E_._sweep = function() {
      var L = this.live, n = L.length, now = this.ctx.currentTime, k = 0, i;
      for (i = 0; i < n; ++i) {
         var g = L[i], e = g.gain._end;
         if (e !== undefined && e + 0.1 < now) { try { g.disconnect(); } catch (er) {} } else L[k++] = g;
      }
      L.length = k;
   };
   E_._o = function(type, f, t, end, det) {
      var o = this.ctx.createOscillator();
      if (this.testSine) o.type = "sine";                  // (pruebas) todo seno: un transitorio aislado solo puede venir de una envolvente
      else if (typeof type === "string") { if (this.rich && type === "sawtooth") o.setPeriodicWave(this.waves.ssaw); else o.type = type; }   // (M2) sierra suave
      else o.setPeriodicWave(type);
      o.frequency.setValueAtTime(f, t); if (det) o.detune.setValueAtTime(det, t);
      o.start(t); o.stop(end); return o;
   };
   E_._n = function(t, end) { var s = this.ctx.createBufferSource(); s.buffer = this.noise; s.loop = true; s.start(t, this.rnd() * 1.5); s.stop(end); return s; };
   E_._f = function(type, f, q) { var b = this.ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q || 0.7; return b; };
   // organo de tubos (forma de onda aditiva: suave, media, llena)
   E_.organ = function(C, t, ms, hold, v, wave) {
      if (this.rich) return this._organR(C, t, ms, hold, v, wave);
      var vv = v / Math.sqrt(ms.length);
      for (var i = 0; i < ms.length; ++i) { var g = this._g(C, t), end = adsr(g.gain, t, 0.05, 0.25, 0.85, hold, 0.45, vv); this._o(wave, hz(ms[i]), t, end).connect(g); }
   };
   // (M2) organo: los tubos hablan mas despacio (85 ms), el registro lleno baja a medio (el climax ya crece con las capas), un registro
   // celeste (+5,5 cents, el batido lento) y un paso bajo por nota
   E_._organR = function(C, t, ms, hold, v, wave) {
      var vv = v / Math.sqrt(ms.length) * 0.8;
      if (wave === this.waves.full) wave = this.waves.med;
      for (var i = 0; i < ms.length; ++i) {
         var h = this._hu(t, vv, 6), f = hz(ms[i]), g = this._g(C, h[0]), end = adsr(g.gain, h[0], 0.085, 0.3, 0.85, hold, 0.6, h[1]), fl = this._f("lowpass", Math.min(8000, f * 5 + 500), 0.5);
         fl.connect(g); this._o(wave, f, h[0], end).connect(fl); this._o(this.waves.soft, f, h[0], end, 5.5).connect(fl);
      }
   };
   // colchon / cuerdas / coro: dos dientes de sierra desafinados por nota (el filtro y el vibrato van en el canal)
   E_.pad = function(C, t, ms, hold, v, o) {
      if (this.rich) return this._padR(C, t, ms, hold, v, o || {});
      o = o || {}; var vv = v / Math.sqrt(ms.length), w = o.wave || "sawtooth", det = o.det || 7;
      for (var i = 0; i < ms.length; ++i) {
         var g = this._g(C, t), end = adsr(g.gain, t, o.a || 1.2, 0.5, o.s || 1, hold, o.r || 1.6, vv), f = hz(ms[i]);
         this._o(w, f, t, end, -det).connect(g); this._o(w, f, t, end, det).connect(g);
      }
   };
   // (M2) colchon / cuerdas / coro: dos sierras suaves desafinadas que se asientan (llegan 4 cents fuera y se afinan durante el ataque, como
   // un arco), un triangulo a la fundamental (cuerpo) y un paso bajo POR NOTA que se abre con el ataque y se cierra en la caida
   E_._padR = function(C, t, ms, hold, v, o) {
      var vv = v / Math.sqrt(ms.length) * 0.8, w = o.wave || "sawtooth", det = (o.det || 7) * 1.15, a = Math.max(o.a || 1.2, 0.3) * 1.2, r = (o.r || 1.6) * 1.25;
      for (var i = 0; i < ms.length; ++i) {
         var h = this._hu(t, vv, 25), t1 = h[0], f = hz(ms[i]), g = this._g(C, t1), end = adsr(g.gain, t1, a, 0.5, o.s || 1, hold, r, h[1]);
         var top = Math.min(9000, f * (w === "sawtooth" ? 6 : 10) + 500), fl = this._f("lowpass", top * 0.45, 0.5);
         fl.frequency.setValueAtTime(top * 0.45, t1); fl.frequency.linearRampToValueAtTime(top, t1 + a * 1.2); fl.frequency.setTargetAtTime(top * 0.5, t1 + Math.max(hold, a * 1.2), r * 0.4);
         fl.connect(g);
         var o1 = this._o(w, f, t1, end, -det - 4), o2 = this._o(w, f, t1, end, det + 4);
         o1.detune.linearRampToValueAtTime(-det, t1 + a); o2.detune.linearRampToValueAtTime(det, t1 + a);
         o1.connect(fl); o2.connect(fl); this._o("triangle", f, t1, end).connect(fl);
      }
   };
   // pulsacion con filtro que se cierra (arpegios, cuerdas en staccato, bajo)
   E_.pluck = function(C, t, m, v, o) {
      if (this.rich) { var h = this._hu(t, v, 7); return this._pluckR(C, h[0], m, h[1], o); }
      var g = this._g(C, t), f = this._f("lowpass", o.cut, o.q || 1.5), dec = o.dec || 0.25;
      f.frequency.setValueAtTime(o.cut, t); f.frequency.exponentialRampToValueAtTime(Math.max(o.cut2 || o.cut * 0.25, 60), t + (o.fdec || dec * 0.7));
      f.connect(g);
      var end = adsr(g.gain, t, o.a || 0.004, dec, o.s || 0, o.hold || dec, o.r || 0.08, v), w = o.wave || "sawtooth";
      this._o(w, hz(m), t, end, o.det || 0).connect(f);
      if (o.det) this._o(w, hz(m), t, end, -o.det).connect(f);
      if (o.sub) { var gs = this.ctx.createGain(); gs.gain.value = o.sub; gs.connect(g); this._o("sine", hz(m), t, end).connect(gs); }
   };
   // (M2) pulsacion: corte mas bajo, resonancia ≤ 1,1 (la resonancia alta del filtro que se cierra ES el «squelch» de los 80), ataque de 7 ms,
   // cola el doble de larga y un triangulo a la fundamental (cuerda pulsada con cuerpo en vez de zumbido)
   E_._pluckR = function(C, t, m, v, o) {
      var cut = o.cut * 0.62, cut2 = Math.max((o.cut2 || o.cut * 0.25) * 0.8, 60), dec = (o.dec || 0.25) * 1.25;
      var g = this._g(C, t), f = this._f("lowpass", cut, Math.min(o.q || 1.5, 1.1));
      f.frequency.setValueAtTime(cut, t); f.frequency.exponentialRampToValueAtTime(cut2, t + (o.fdec || dec * 0.7) * 1.2);
      f.connect(g);
      var end = adsr(g.gain, t, Math.max(o.a || 0.004, 0.007), dec, o.s || 0, o.hold || dec, (o.r || 0.08) * 2.2, v * 0.9), w = o.wave || "sawtooth";
      this._o(w, hz(m), t, end, o.det || 0).connect(f);
      if (o.det) this._o(w, hz(m), t, end, -o.det).connect(f);
      this._o("triangle", hz(m), t, end).connect(f);
      if (o.sub) { var gs = this.ctx.createGain(); gs.gain.value = o.sub; gs.connect(g); this._o("sine", hz(m), t, end).connect(gs); }
   };
   // (M2) SINTESIS MODAL: cada parcial [razon, amplitud, tau de caida en s, suelo sostenido] es un seno con su propia caida exponencial (los
   // agudos mueren antes, como en una barra, una cuerda o una campana de verdad); `sum` es el apagador (hold, r). mallet: golpe de ruido
   // filtrado de 12 ms (macillo / martillo) a ese nivel relativo
   E_._modal = function(C, t, m, v, parts, a, hold, r, mallet) {
      var c = this.ctx, f = hz(m), sum = this._g(C, t), end = adsr(sum.gain, t, Math.max(a, 0.002), 0, 1, hold, r, v);
      for (var i = 0; i < parts.length; ++i) {
         var Q = parts[i], fq = f * Q[0]; if (fq > 15000) continue;
         var pg = c.createGain(); pg.gain.setValueAtTime(0, t); pg.gain.linearRampToValueAtTime(Q[1], t + Math.max(a, 0.002)); pg.gain.setTargetAtTime(Q[1] * (Q[3] || 0), t + Math.max(a, 0.002), Q[2]);
         this._o("sine", fq, t, end).connect(pg); pg.connect(sum);
      }
      if (mallet) { var mg = c.createGain(), e2 = perc(mg.gain, t, 0.001, 0.012, mallet), bp = this._f("bandpass", Math.min(f * 2.5, 6000), 0.8); this._n(t, e2).connect(bp); bp.connect(mg); mg.connect(sum); }
      return end;
   };
   // FM de dos operadores (piano electrico, campana, marimba, kalimba)
   E_.fm = function(C, t, m, v, o) {
      if (this.rich) {   // (M2) la FM generica (pulsar, melodias) pasa a modal: la fundamental y un parcial en la razon del modulador, que cae antes
         var h = this._hu(t, v, 7), dc = o.dec || 1;
         return this._modal(C, h[0], m, h[1], [[1, 1, dc * 0.45, o.s || 0], [o.ratio, 0.22 * Math.min(1, o.index), Math.max(o.idec * 0.6, 0.03), 0]], Math.max(o.a || 0.003, 0.004), o.hold || dc * 1.1, o.r || 0.3, 0);
      }
      var f = hz(m), g = this._g(C, t), end = adsr(g.gain, t, o.a || 0.003, o.dec || 1, o.s || 0, o.hold || o.dec || 1, o.r || 0.3, v);
      var car = this._o("sine", f, t, end), mod = this._o("sine", f * o.ratio, t, end), mg = this.ctx.createGain();
      mg.gain.setValueAtTime(f * o.index, t); mg.gain.exponentialRampToValueAtTime(Math.max(f * o.index * 0.04, 0.5), t + o.idec);
      mod.connect(mg); mg.connect(car.frequency); car.connect(g);
   };
   // (M2) campana → celesta de cristal; marimba de barra afinada (1 : 3,93 : 9,2); kalimba de lengüeta; piano electrico → piano de fieltro
   // (parciales casi armonicos, la caida depende de la altura: los graves duran mas, martillo suave)
   E_.bell = function(C, t, m, v) {
      if (this.rich) { var h = this._hu(t, v, 8); return this._modal(C, h[0], m, h[1] * 0.9, [[1, 1, 0.95, 0], [2.0, 0.3, 0.5, 0], [3.01, 0.1, 0.28, 0], [4.2, 0.05, 0.16, 0]], 0.004, 4.0, 0.6, 0); }
      this.fm(C, t, m, v, { ratio: 3.5, index: 1.6, idec: 1.4, dec: 4.0, r: 0.5 });
   };
   E_.marimba = function(C, t, m, v) {
      if (this.rich) { var h = this._hu(t, v, 6); return this._modal(C, h[0], m, h[1], [[1, 1, 0.17, 0], [3.93, 0.16, 0.035, 0], [9.2, 0.035, 0.012, 0]], 0.003, 0.75, 0.08, 0.05); }
      this.fm(C, t, m, v, { ratio: 4, index: 1.1, idec: 0.05, dec: 0.5, r: 0.1 });
   };
   E_.kalimba = function(C, t, m, v) {
      if (this.rich) { var h = this._hu(t, v, 6); return this._modal(C, h[0], m, h[1], [[1, 1, 0.36, 0], [2.0, 0.06, 0.12, 0], [5.4, 0.1, 0.05, 0]], 0.003, 1.3, 0.15, 0.03); }
      this.fm(C, t, m, v, { ratio: 3, index: 0.7, idec: 0.12, dec: 1.1, r: 0.2 });
   };
   E_.epiano = function(C, t, m, hold, v) {
      if (this.rich) {
         var h = this._hu(t, v, 9), tau = clamp(1.1 * Math.pow(440 / hz(m), 0.4), 0.4, 2.2);
         return this._modal(C, h[0], m, h[1], [[1, 1, tau, 0.22], [2.0, 0.3, tau * 0.45, 0], [3.0, 0.11, tau * 0.3, 0], [4.01, 0.05, tau * 0.2, 0]], 0.004, hold, 0.45, 0.03);
      }
      this.fm(C, t, m, v, { ratio: 1, index: 1.3, idec: 0.8, dec: 1.4, s: 0.3, hold: hold, r: 0.35 });
   };
   // (M2) instrumentos de las capas nuevas
   // flauta: triangulo + 2.º armonico tenue, soplo (ruido estrecho en el 2.º armonico) y vibrato que llega tarde (como un instrumentista)
   E_.flute = function(C, t, m, hold, v) {
      var c = this.ctx, h = this._hu(t, v, 15), f = hz(m); t = h[0];
      var g = this._g(C, t), end = adsr(g.gain, t, 0.14, 0.3, 0.8, hold, 0.4, h[1]);
      var o1 = this._o("triangle", f, t, end), o2 = this._o("sine", f * 2, t, end), g2 = c.createGain(); g2.gain.value = 0.16;
      o1.connect(g); o2.connect(g2); g2.connect(g);
      var lfo = this._o("sine", 4.7 + 0.6 * this.rnd(), t, end), lg = c.createGain();
      lg.gain.setValueAtTime(0, t); lg.gain.setValueAtTime(0, t + Math.min(hold * 0.35, 0.6)); lg.gain.linearRampToValueAtTime(10, t + Math.min(hold * 0.8, 1.6));
      lfo.connect(lg); lg.connect(o1.detune); lg.connect(o2.detune);
      var nb = this._n(t, end), bp = this._f("bandpass", f * 2, 3), gn = c.createGain(); gn.gain.value = 0.07; nb.connect(bp); bp.connect(gn); gn.connect(g);
   };
   // arpa: cuerda pulsada modal (armonicos que caen cada vez antes)
   E_.harp = function(C, t, m, v) {
      var h = this._hu(t, v, 5);
      return this._modal(C, h[0], m, h[1], [[1, 1, 0.9, 0], [2.0, 0.35, 0.45, 0], [3.0, 0.13, 0.25, 0], [4.0, 0.05, 0.15, 0]], 0.003, 3.0, 0.4, 0);
   };
   // metales: sierra con filtro que se abre (hinchado) y entrada con un pequeño portamento
   E_.brass = function(C, t, ms, hold, v, o) {
      if (this.rich) return this._brassR(C, t, ms, hold, v, o || {});
      o = o || {}; var vv = v / Math.sqrt(ms.length), a = o.a || 0.14, br = o.bright || 0.6;
      for (var i = 0; i < ms.length; ++i) {
         var g = this._g(C, t), f = this._f("lowpass", 250, 1.1), end = adsr(g.gain, t, a, 0.3, 0.8, hold, o.r || 0.45, vv), fq = hz(ms[i]);
         f.frequency.setValueAtTime(220, t); f.frequency.linearRampToValueAtTime(260 + 2600 * br, t + a * 1.3);
         f.frequency.setValueAtTime(260 + 2600 * br, Math.max(t + a * 1.3, t + hold)); f.frequency.exponentialRampToValueAtTime(280, t + hold + (o.r || 0.45));
         f.connect(g);
         for (var j = -1; j <= 1; j += 2) { var os = this._o("sawtooth", fq, t, end, j * 5); os.detune.setValueAtTime(-35 + j * 5, t); os.detune.linearRampToValueAtTime(j * 5, t + 0.07); os.connect(f); }
      }
   };
   // (M2) metales → seccion de trompas: ataque 1,6 veces mas lento, mitad de brillo, resonancia 0,7, un triangulo de cuerpo y un portamento
   // de entrada mas corto (−20 cents)
   E_._brassR = function(C, t, ms, hold, v, o) {
      var vv = v / Math.sqrt(ms.length) * 0.85, a = (o.a || 0.14) * 1.6, br = (o.bright || 0.6) * 0.55, r = (o.r || 0.45) * 1.3;
      for (var i = 0; i < ms.length; ++i) {
         var h = this._hu(t, vv, 12), t1 = h[0], g = this._g(C, t1), f = this._f("lowpass", 220, 0.7), end = adsr(g.gain, t1, a, 0.3, 0.8, hold, r, h[1]), fq = hz(ms[i]), top = 260 + 2600 * br;
         f.frequency.setValueAtTime(200, t1); f.frequency.linearRampToValueAtTime(top, t1 + a * 1.3);
         f.frequency.setValueAtTime(top, Math.max(t1 + a * 1.3, t1 + hold)); f.frequency.exponentialRampToValueAtTime(240, t1 + hold + r);
         f.connect(g);
         for (var j = -1; j <= 1; j += 2) { var os = this._o("sawtooth", fq, t1, end, j * 5); os.detune.setValueAtTime(-20 + j * 5, t1); os.detune.linearRampToValueAtTime(j * 5, t1 + 0.09); os.connect(f); }
         this._o("triangle", fq, t1, end).connect(f);
      }
   };
   E_.bass = function(C, t, m, hold, v, cut) {
      this.pluck(C, t, m, v, { cut: (cut || 600) * 2.5, cut2: cut || 600, fdec: 0.15, dec: 0.3, s: 0.65, hold: hold, r: 0.12, wave: "sawtooth", sub: 0.8, q: 1 });
   };
   E_.sub = function(C, t, m, hold, v) { var g = this._g(C, t), end = adsr(g.gain, t, 0.08, 0, 1, hold, 0.6, v); this._o("sine", hz(m), t, end).connect(g); };
   // ---- percusion ----
   // (M2) la percusion, DISCRETA: cada golpe a una fraccion (PK) de su nivel, con 0-3 ms de holgura y su velocidad humanizada
   var PK = { kick: 0.6, snare: 0.5, hat: 0.45, shaker: 0.55, clock: 0.65, tom: 0.7, timp: 0.85, taiko: 0.7, crash: 0.45, riser: 0.55, boom: 0.7 };
   E_._pk = function(t, v, k) { var h = this._hu(t, v * PK[k], 3); return h; };
   E_.kick = function(C, t, v) {
      var R = this.rich; if (R) { var h = this._pk(t, v, "kick"); t = h[0]; v = h[1]; }   // (M2) bombo blando: arranca mas grave, ataque de 5 ms
      var g = this._g(C, t), end = perc(g.gain, t, R ? 0.005 : 0.002, R ? 0.5 : 0.42, v), o = this._o("sine", R ? 105 : 150, t, end);
      o.frequency.exponentialRampToValueAtTime(46, t + 0.11); o.connect(g);
   };
   E_.snare = function(C, t, v, brush) {
      var R = this.rich; if (R) { var h = this._pk(t, v, "snare"); t = h[0]; v = h[1]; }
      var g = this._g(C, t), end = perc(g.gain, t, brush ? 0.012 : 0.001, brush ? 0.24 : (R ? 0.2 : 0.17), v), f = this._f("bandpass", brush ? 3200 : (R ? 1500 : 1800), brush ? 0.5 : (R ? 0.6 : 0.8));
      this._n(t, end).connect(f); f.connect(g);
      if (!brush) { var gb = this._g(C, t), e2 = perc(gb.gain, t, 0.001, 0.08, v * 0.5), o = this._o("triangle", 190, t, e2); o.frequency.exponentialRampToValueAtTime(165, t + 0.06); o.connect(gb); }
   };
   E_.hat = function(C, t, v, open) {
      var R = this.rich; if (R) { var h = this._pk(t, v, "hat"); t = h[0]; v = h[1]; }
      var g = this._g(C, t), end = perc(g.gain, t, R ? 0.002 : 0.001, open ? 0.22 : (R ? 0.03 : 0.04), v), f = this._f("highpass", R ? 8500 : 7000, R ? 0.5 : 0.7); this._n(t, end).connect(f); f.connect(g);
   };
   E_.shaker = function(C, t, v) {
      if (this.rich) { var h = this._pk(t, v, "shaker"); t = h[0]; v = h[1]; }
      var g = this._g(C, t), end = perc(g.gain, t, 0.014, 0.06, v), f = this._f("bandpass", 5500, 1.5); this._n(t, end).connect(f); f.connect(g);
   };
   // el tic de reloj (Interstellar, Miller: 1,25 s)
   // (M1-3) se llamaba «tick» y PISABA E_.tick, el secuenciador en tiempo real: la radio no sonaba (el render sin tiempo real usa pump y si)
   E_.clockTick = function(C, t, v) {
      var R = this.rich; if (R) { var h = this._pk(t, v, "clock"); t = h[0]; v = h[1]; }
      var g = this._g(C, t), end = perc(g.gain, t, 0.0006, 0.02, v * 3), f = this._f("bandpass", 3400, R ? 5 : 7); this._n(t, end).connect(f); f.connect(g);
   };
   E_.tom = function(C, t, m, v, dec) {
      if (this.rich) { var h = this._pk(t, v, "tom"); t = h[0]; v = h[1]; }
      var g = this._g(C, t), end = perc(g.gain, t, 0.002, dec || 0.5, v), f0 = hz(m), o = this._o("sine", f0 * 1.6, t, end);
      o.frequency.exponentialRampToValueAtTime(f0, t + 0.04); o.connect(g);
      var gn = this._g(C, t), e2 = perc(gn.gain, t, 0.001, 0.05, v * 0.3), fl = this._f("lowpass", 900, 0.7); this._n(t, e2).connect(fl); fl.connect(gn);
   };
   E_.timp = function(C, t, m, v) {
      if (this.rich) { var h = this._pk(t, v, "timp"); t = h[0]; v = h[1]; }
      var f0 = hz(m), parts = [[1, 1], [1.5, 0.35], [1.98, 0.18]];
      for (var i = 0; i < parts.length; ++i) {
         var g = this._g(C, t), end = perc(g.gain, t, 0.004, 1.6 - 0.4 * i, v * parts[i][1]), o = this._o("sine", f0 * parts[i][0] * 1.04, t, end);
         o.frequency.exponentialRampToValueAtTime(f0 * parts[i][0], t + 0.08); o.connect(g);
      }
      var gn = this._g(C, t), e2 = perc(gn.gain, t, 0.002, 0.1, v * 0.35), fl = this._f("lowpass", 500, 0.7); this._n(t, e2).connect(fl); fl.connect(gn);
   };
   E_.taiko = function(C, t, v) {
      if (this.rich) { var h = this._pk(t, v, "taiko"); t = h[0]; v = h[1]; }
      var g = this._g(C, t), end = perc(g.gain, t, 0.002, 0.65, v), o = this._o("sine", 96, t, end);
      o.frequency.exponentialRampToValueAtTime(57, t + 0.08); o.connect(g);
      var gn = this._g(C, t), e2 = perc(gn.gain, t, 0.002, 0.15, v * 0.5), fl = this._f("lowpass", 600, 0.7); this._n(t, e2).connect(fl); fl.connect(gn);
   };
   // ---- efectos de transicion ----
   E_.riser = function(C, t, dur, v) {
      if (this.rich) v *= PK.riser;
      var g = this._g(C, t), f = this._f("bandpass", 250, 3), end = t + dur + 0.1;
      g.gain._end = t + dur + 0.07;
      f.frequency.setValueAtTime(250, t); f.frequency.exponentialRampToValueAtTime(5000, t + dur);
      g.gain.linearRampToValueAtTime(v * 0.25, t + dur * 0.6); g.gain.linearRampToValueAtTime(v, t + dur); g.gain.linearRampToValueAtTime(0, t + dur + 0.07);
      this._n(t, end).connect(f); f.connect(g);
   };
   E_.boom = function(C, t, v) {
      if (this.rich) v *= PK.boom;
      var g = this._g(C, t), end = perc(g.gain, t, 0.006, 2.4, v), o = this._o("sine", 75, t, end);
      o.frequency.exponentialRampToValueAtTime(30, t + 1.6); o.connect(g);
      var gn = this._g(C, t), e2 = perc(gn.gain, t, 0.004, 0.9, v * 0.5), fl = this._f("lowpass", 180, 0.7); this._n(t, e2).connect(fl); fl.connect(gn);
   };
   E_.crash = function(C, t, v) {
      var R = this.rich; if (R) v *= PK.crash;   // (M2) platillo suspendido: mas largo, mas bajo
      var g = this._g(C, t), end = perc(g.gain, t, R ? 0.004 : 0.002, R ? 2.6 : 2.0, v), f = this._f("highpass", R ? 2500 : 3000, 0.7); this._n(t, end).connect(f); f.connect(g);
      var g2 = this._g(C, t), e2 = perc(g2.gain, t, 0.002, 1.0, v * 0.5), f2 = this._f("bandpass", 6000, 1); this._n(t, e2).connect(f2); f2.connect(g2);
   };

   // ---------------- LAS DIEZ EMISORAS ----------------
   // Comun: key = tonica (MIDI), bpm, bars = compases del ciclo, cb = compases por acorde, shape = curva de intensidad, echo = eco en
   // pulsos, trim = nivel (medido: tests/out/radio/LEEME.md), progs = progresiones (una por ciclo, alternando), chans = canales, play = cada
   // semicorchea. x.I = intensidad 0-1; x.lv(umbral, ancho) = cuanto ha entrado una capa.
   var MIN = [0, 2, 3, 5, 7, 8, 10], MAJ = [0, 2, 4, 5, 7, 9, 11], PENTA = [0, 2, 4, 7, 9], PENTM = [0, 3, 5, 7, 10], LYD = [0, 2, 4, 6, 7, 9, 11];
   var PRESETS = [
   // 1 · EVENT HORIZON — organo de iglesia, ostinato que se espesa de negras a semicorcheas, el tic de 1,25 s
   { id: "S1", name: "Event Horizon", es: "Horizonte de sucesos", key: 57, keyName: ["A minor", "La menor"], bpm: 96, bars: 48, cb: 2, seed: 101,
     shape: [0.10, 0.70, 0.88, 0.18], echo: 0.75, trim: 0.235,
     chars: ["Pipe organ chords, an ostinato that thickens from quarters to sixteenths, the 1.25 s clock tick and timpani at the climax", "Órgano de tubos, ostinato que se espesa de negras a semicorcheas, el tic de reloj de 1,25 s y timbales en el clímax"],
     progs: [[[0, "m"], [8, "M"], [3, "M"], [10, "M"]], [[0, "m"], [8, "M7"], [5, "m"], [7, "sus4"]]],
     chans: function(E, S) { return { org: E._chan(S, { lp: 4200, rev: 0.5, gain: 0.9 }), ped: E._chan(S, { rev: 0.35, lp: 700, gain: 1.0 }), ost: E._chan(S, { lp: 5000, rev: 0.55, dly: 0.12, pan: 0.2, gain: 0.6 }),
                                      tick: E._chan(S, { pan: -0.3, rev: 0.15, gain: 0.5 }), drum: E._chan(S, { rev: 0.4, gain: 0.9 }), fx: E._chan(S, { rev: 0.6, gain: 0.5 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I, w = I < 0.42 ? E.waves.soft : (I < 0.74 ? E.waves.med : E.waves.full);
        if (x.cs) {
           E.organ(C.org, x.t, chordIn(x.key, x.ch, 52, 15), x.chDur - 0.05, 0.16 + 0.22 * I, w);
           if (I > 0.72) E.organ(C.org, x.t, chordIn(x.key, x.ch, 69, 12), x.chDur - 0.05, 0.13 * x.lv(0.72), E.waves.soft);
           if (I > 0.28) E.organ(C.ped, x.t, [rootIn(x.key, x.ch, 33)], x.chDur - 0.05, 0.34 * x.lv(0.28, 0.2), E.waves.soft);
        }
        var div = I < 0.3 ? 4 : (I < 0.66 ? 2 : 1);
        if (x.sib % div === 0) {
           var tn = chordIn(x.key, x.ch, 64, 13), pat = [0, 2, 1, 2], j = (x.chPos / div) | 0, m = tn[pat[j % 4] % tn.length];
           if (x.chPos >= 16) m = tn[(pat[j % 4] + 1) % tn.length];
           E.organ(C.ost, x.t, [m], x.dt * div * 0.85, 0.1 + 0.08 * I, I < 0.66 ? E.waves.soft : E.waves.med);
        }
        if (I > 0.12 && x.sib % 8 === 0) E.clockTick(C.tick, x.t, 0.22 + 0.3 * x.lv(0.12, 0.3));
        if (I > 0.6 && x.sib === 0) E.timp(C.drum, x.t, rootIn(x.key, x.ch, 40), 0.5 * x.lv(0.6, 0.2));
        if (I > 0.86 && (x.sib === 8 || x.sib === 12 || x.sib === 14)) E.timp(C.drum, x.t, rootIn(x.key, x.ch, 40) + 7, 0.3 * x.lv(0.86, 0.1));
        E.fxPeak(S, x, C.fx, 0.45);
     } },
   // 2 · DEEP FIELD — colchones que evolucionan, campanas, latido suave
   { id: "S2", name: "Deep Field", es: "Campo profundo", key: 62, keyName: ["D Lydian", "Re lidio"], bpm: 72, bars: 40, cb: 2, seed: 202,
     shape: [0.12, 0.68, 0.86, 0.20], echo: 0.75, trim: 0.249,
     chars: ["Evolving pads that open with the climb, FM bells, a soft pulse and a heartbeat kick", "Colchones que se abren con la subida, campanas FM, un pulso suave y un latido de bombo"],
     progs: [[[0, "M9"], [2, "M"], [9, "m7"], [7, "M"]], [[0, "M7"], [4, "m7"], [2, "M"], [9, "m"]]],
     chans: function(E, S) { return { pad: E._chan(S, { lp: 700, lq: 0.8, vib: [0.25, 0.0015], rev: 0.55, gain: 0.9 }), air: E._chan(S, { hp: 1200, rev: 0.85, gain: 0.35, pan: -0.15 }),
                                      sub: E._chan(S, { lp: 260, gain: 0.8 }), pulse: E._chan(S, { rev: 0.4, dly: 0.35, pan: -0.25, gain: 0.5 }), bell: E._chan(S, { rev: 0.7, dly: 0.25, pan: 0.3, gain: 0.5 }),
                                      perc: E._chan(S, { rev: 0.25, gain: 0.7 }), fx: E._chan(S, { rev: 0.6, gain: 0.4 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I;
        if (x.sib === 0) E.sweep(C.pad, x.t, 450 + 4200 * Math.pow(I, 1.5), 1.5);
        if (x.cs) {
           E.pad(C.pad, x.t, chordIn(x.key, x.ch, 50, 16), x.chDur, 0.22, { a: 2.2, r: 2.6 });
           E.sub(C.sub, x.t, rootIn(x.key, x.ch, 38), x.chDur - 0.3, 0.32 * x.lv(0.18, 0.2));
           if (I > 0.5) E.pad(C.air, x.t, chordIn(x.key, x.ch, 74, 12), x.chDur, 0.12 * x.lv(0.5, 0.2), { a: 3, r: 3, wave: "triangle" });
        }
        if (I > 0.28 && x.sib % 2 === 0) { var r = rootIn(x.key, x.ch, 50), m = (x.sib % 8 === 4) ? r + 7 : (x.sib % 8 === 6 ? r + 12 : r);
           E.pluck(C.pulse, x.t, m, (x.sib % 4 === 0 ? 0.2 : 0.13) * x.lv(0.28, 0.2), { wave: "triangle", cut: 2400, cut2: 500, dec: 0.3 }); }
        if (x.sib % 2 === 0 && x.R() < 0.1 + 0.32 * I) E.bell(C.bell, x.t, scaleNote(x.key, PENTA, 7 + Math.floor(x.R() * 7)), 0.16);
        if (I > 0.55 && (x.sib === 0 || x.sib === 3)) E.kick(C.perc, x.t, (x.sib === 0 ? 0.45 : 0.3) * x.lv(0.55, 0.15));
        if (I > 0.72) E.shaker(C.perc, x.t, (x.sib % 4 === 2 ? 0.12 : 0.06) * x.lv(0.72, 0.1));
        E.fxPeak(S, x, C.fx, 0.35);
     } },
   // 3 · WARP DRIVE — arpegios de sintetizador en semicorcheas, bajo pulsante, el bombo a negras entra con la subida
   { id: "S3", name: "Warp Drive", es: "Motor de curvatura", key: 52, keyName: ["E minor", "Mi menor"], bpm: 120, bars: 64, cb: 2, seed: 303,
     shape: [0.08, 0.66, 0.86, 0.15], echo: 0.75, trim: 0.252,
     chars: ["Synth arpeggios in sixteenths, a pulsing octave bass, four-on-the-floor kick that arrives with the climb", "Arpegios de sintetizador en semicorcheas, bajo de octavas que pulsa y bombo a negras que llega con la subida"],
     progs: [[[0, "m"], [8, "M"], [3, "M"], [10, "M"]], [[0, "m"], [8, "M"], [5, "m"], [7, "M"]]],
     chans: function(E, S) { return { arp: E._chan(S, { rev: 0.25, dly: 0.3, pan: 0.12, gain: 0.55 }), bass: E._chan(S, { gain: 0.75 }), pad: E._chan(S, { lp: 2200, vib: [0.3, 0.0012], rev: 0.5, gain: 0.45 }),
                                      kick: E._chan(S, { gain: 0.85 }), snare: E._chan(S, { rev: 0.2, gain: 0.5 }), hat: E._chan(S, { pan: 0.25, gain: 0.35 }), lead: E._chan(S, { rev: 0.45, dly: 0.25, pan: -0.1, gain: 0.4 }),
                                      fx: E._chan(S, { rev: 0.5, gain: 0.45 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I, tn = chordIn(x.key, x.ch, 64, 24), n = tn.length, per = 2 * n - 2, j = x.k % per, idx = j < n ? j : per - j;
        if (I >= 0.2 || x.sib % 2 === 0) E.pluck(C.arp, x.t, tn[idx], (0.1 + 0.11 * I) * (x.sib % 4 === 0 ? 1.25 : 1), { wave: "sawtooth", cut: 900 + 3600 * I, cut2: 300, dec: 0.17, det: 6, q: 3 });
        if (x.cs) E.pad(C.pad, x.t, chordIn(x.key, x.ch, 55, 14), x.chDur, 0.14 + 0.1 * I, { a: 1.0, r: 1.5 });
        if (I > 0.24 && x.sib % 2 === 0) { var r = rootIn(x.key, x.ch, 40); E.bass(C.bass, x.t, x.sib % 4 === 2 ? r + 12 : r, x.dt * 1.6, 0.34 * x.lv(0.24), 500 + 500 * I); }
        if (I > 0.42 && x.sib % 4 === 0) E.kick(C.kick, x.t, 0.7 * x.lv(0.42, 0.1));
        if (I > 0.52 && x.sib % 4 === 2) E.hat(C.hat, x.t, 0.25 * x.lv(0.52, 0.1), x.sib === 14);
        if (I > 0.68 && (x.sib === 4 || x.sib === 12)) E.snare(C.snare, x.t, 0.42 * x.lv(0.68, 0.1));
        if (E.inRiser(S, x) && x.bic % 1 === 0 && x.sib % 2 === 0 && x.bic >= Math.round(S.P.shape[1] * S.P.bars) - 1) E.snare(C.snare, x.t, 0.15 + 0.25 * (x.sib / 16));
        if (I > 0.82 && (x.chPos === 0 || x.chPos === 6 || x.chPos === 12 || x.chPos === 16)) {
           var hi = chordIn(x.key, x.ch, 71, 12), mi = hi[[0, 1, 2, 1][(x.chPos / 4 | 0) % 4] % hi.length];
           E.pad(C.lead, x.t, [mi], x.dt * (x.chPos === 16 ? 14 : 5), 0.2 * x.lv(0.82, 0.1), { a: 0.04, r: 0.5, det: 9 });
        }
        E.fxPeak(S, x, C.fx, 0.5);
     } },
   // 4 · CRUISING ALTITUDE — ritmo de crucero: piano electrico sincopado, bajo y bateria suaves, cuerdas en el climax
   { id: "S4", name: "Cruising Altitude", es: "Velocidad de crucero", key: 53, keyName: ["F major", "Fa mayor"], bpm: 100, bars: 56, cb: 2, seed: 404,
     shape: [0.10, 0.68, 0.88, 0.22], echo: 0.75, trim: 0.31,
     chars: ["Cruise groove: syncopated electric piano, round bass, brushed drums and shaker; marimba and strings at the top", "Ritmo de crucero: piano eléctrico sincopado, bajo redondo, batería suave y shaker; marimba y cuerdas arriba"],
     progs: [[[0, "M7"], [9, "m7"], [5, "M7"], [7, "sus4"]], [[0, "M7"], [4, "m7"], [2, "m7"], [7, "d7"]]],
     chans: function(E, S) { return { ep: E._chan(S, { rev: 0.3, dly: 0.12, gain: 0.75 }), bass: E._chan(S, { gain: 0.75 }), kick: E._chan(S, { gain: 0.7 }), snare: E._chan(S, { rev: 0.25, gain: 0.45 }),
                                      hat: E._chan(S, { pan: 0.3, gain: 0.3 }), shk: E._chan(S, { pan: -0.3, gain: 0.35 }), mar: E._chan(S, { rev: 0.35, dly: 0.2, pan: 0.25, gain: 0.5 }),
                                      str: E._chan(S, { lp: 3200, vib: [5.2, 0.00016], rev: 0.55, gain: 0.45 }), fx: E._chan(S, { rev: 0.5, gain: 0.3 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I, two = x.chPos >= 16, hits = two ? [0, 3, 8, 14] : [0, 6, 10];
        if (hits.indexOf(x.sib) >= 0) { var ms = chordIn(x.key, x.ch, 57, 14); for (var i = 0; i < ms.length; ++i) E.epiano(C.ep, x.t + i * 0.008, ms[i], x.dt * (x.sib === 0 ? 5 : 3), (0.13 + 0.08 * I) / Math.sqrt(ms.length) * (x.sib === 0 ? 1.1 : 0.85)); }
        if (I > 0.15) { var r = rootIn(x.key, x.ch, 41), bp = { 0: [r, 3], 6: [r + 7, 2], 10: [r, 2], 14: [r + 12, 2] }[x.sib]; if (bp) E.bass(C.bass, x.t, bp[0], x.dt * bp[1], 0.36 * x.lv(0.15), 700); }
        if (I > 0.3 && (x.sib === 0 || x.sib === 10)) E.kick(C.kick, x.t, 0.5 * x.lv(0.3));
        if (I > 0.38 && (x.sib === 4 || x.sib === 12)) E.snare(C.snare, x.t, 0.3 * x.lv(0.38), true);
        if (I > 0.22 && x.sib % 2 === 0) E.hat(C.hat, x.t, (x.sib % 4 === 2 ? 0.16 : 0.09) * x.lv(0.22), false);
        if (I > 0.6) E.shaker(C.shk, x.t, [0.1, 0.04, 0.07, 0.04][x.sib % 4] * x.lv(0.6, 0.1));
        if (I > 0.55 && x.sib % 2 === 0) { var tm = chordIn(x.key, x.ch, 72, 14); E.marimba(C.mar, x.t, tm[[0, 1, 2, 1, 3, 2, 1, 2][(x.sib / 2) % 8] % tm.length], 0.14 * x.lv(0.55, 0.15)); }
        if (I > 0.7 && x.cs) E.pad(C.str, x.t, chordIn(x.key, x.ch, 65, 14), x.chDur, 0.2 * x.lv(0.7, 0.1), { a: 1.4, r: 1.6 });
        E.fxPeak(S, x, C.fx, 0.3);
     } },
   // 5 · CHOIR OF PULSARS — coro sintetico (formantes «a» y «u»), cuerdas graves, pulsar en corcheas, latido de timbal
   { id: "S5", name: "Choir of Pulsars", es: "Coro de púlsares", key: 60, keyName: ["C minor", "Do menor"], bpm: 76, bars: 40, cb: 2, seed: 505,
     shape: [0.12, 0.70, 0.88, 0.20], echo: 0.5, trim: 0.173,
     chars: ["Synthetic choir (ah and oo vowels), low strings, a pulsar ping in eighths and a timpani heartbeat; toms at the climax", "Coro sintético (vocales a y u), cuerdas graves, un púlsar en corcheas y latido de timbal; toms en el clímax"],
     progs: [[[0, "m"], [8, "M"], [3, "M"], [10, "M"]], [[0, "m"], [5, "m"], [8, "M"], [7, "M"]]],
     chans: function(E, S) { return { choir: E._chan(S, { formant: [[700, 6, 1], [1220, 7, 0.55], [2600, 9, 0.25]], vib: [5.1, 0.00017], rev: 0.75, gain: 2.2 }),
                                      hi: E._chan(S, { formant: [[350, 7, 1], [800, 8, 0.4], [2400, 10, 0.12]], vib: [5.4, 0.00015], rev: 0.85, gain: 2.0, pan: 0.15 }),
                                      low: E._chan(S, { lp: 1100, vib: [4.8, 0.0002], rev: 0.45, gain: 0.7 }), pul: E._chan(S, { rev: 0.5, dly: 0.35, pan: -0.25, gain: 0.45 }),
                                      drum: E._chan(S, { rev: 0.4, gain: 0.9 }), fx: E._chan(S, { rev: 0.6, gain: 0.45 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I;
        if (x.cs) {
           E.pad(C.choir, x.t, chordIn(x.key, x.ch, 55, 15), x.chDur, 0.26 + 0.22 * I, { a: 1.6, r: 2.2, det: 9 });
           var r = rootIn(x.key, x.ch, 36); E.pad(C.low, x.t, [r, r + 7], x.chDur, 0.3 * x.lv(0.15, 0.2), { a: 1.0, r: 1.5, det: 5 });
           if (I > 0.6) E.pad(C.hi, x.t, chordIn(x.key, x.ch, 72, 12), x.chDur, 0.22 * x.lv(0.6, 0.2), { a: 2.0, r: 2.4, det: 8 });
        }
        if (x.sib % 2 === 0 || I > 0.45) {
           var tn = chordIn(x.key, x.ch, 79, 12), m = tn[((x.k / (I > 0.45 ? 1 : 2)) | 0) % tn.length];
           E.fm(C.pul, x.t, m, (0.07 + 0.07 * I) * (1 - (x.sib % 8) / 12), { ratio: 2, index: 0.8, idec: 0.15, dec: 0.5, r: 0.1 });
        }
        if (I > 0.32 && (x.sib === 0 || x.sib === 3)) E.timp(C.drum, x.t, rootIn(x.key, x.ch, 40), (x.sib === 0 ? 0.42 : 0.28) * x.lv(0.32, 0.2));
        if (I > 0.75 && (x.bic % 2 === 1) && x.sib >= 8) E.tom(C.drum, x.t, rootIn(x.key, x.ch, 43) + (x.sib % 4 === 0 ? 0 : -5), (0.12 + 0.2 * (x.sib - 8) / 8) * x.lv(0.75, 0.1), 0.35);
        E.fxPeak(S, x, C.fx, 0.4);
     } },
   // 6 · SILENT NEBULA — drones que respiran, campanas dispersas, el reloj a 60 por minuto
   { id: "S6", name: "Silent Nebula", es: "Nebulosa silenciosa", key: 47, keyName: ["B Dorian", "Si dórico"], bpm: 60, bars: 32, cb: 4, seed: 606,
     shape: [0.12, 0.68, 0.86, 0.20], echo: 0.75, trim: 0.242,
     chars: ["Breathing drones, scattered glass bells, a 60 bpm clock tick and a low pulse that grows into a shimmering climax", "Drones que respiran, campanas de cristal dispersas, el tic de un reloj a 60 por minuto y un pulso grave que crece hasta un clímax brillante"],
     progs: [[[0, "five"], [0, "m7"], [10, "M"], [5, "sus2"]]],
     chans: function(E, S) { return { drone: E._chan(S, { lp: 300, lq: 1.2, rev: 0.6, gain: 0.9 }), drone2: E._chan(S, { lp: 1600, vib: [0.2, 0.002], rev: 0.7, gain: 0.45, pan: 0.15 }),
                                      bell: E._chan(S, { rev: 0.85, dly: 0.3, pan: -0.2, gain: 0.5 }), tick: E._chan(S, { pan: 0.25, rev: 0.1, gain: 0.45 }), pulse: E._chan(S, { gain: 0.75 }),
                                      glass: E._chan(S, { hp: 1800, rev: 0.9, gain: 0.3 }), fx: E._chan(S, { rev: 0.7, gain: 0.45 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I;
        if (x.sib % 4 === 0) E.sweep(C.drone, x.t, 260 + 1500 * I + 260 * Math.sin(2 * Math.PI * x.k / 128), 2.0);
        if (x.cs) {
           var r = rootIn(x.key, x.ch, 35); E.pad(C.drone, x.t, [r, r + 7, r + 12], x.chDur, 0.32, { a: 3.5, r: 3.5, det: 6 });
           if (I > 0.35) E.pad(C.drone2, x.t, chordIn(x.key, x.ch, 50, 14), x.chDur, 0.2 * x.lv(0.35, 0.2), { a: 3, r: 3 });
           if (I > 0.7) E.pad(C.glass, x.t, chordIn(x.key, x.ch, 83, 12), x.chDur, 0.09 * x.lv(0.7, 0.15), { a: 2.2, r: 3, wave: "triangle", det: 4 });
        }
        if (x.sib % 2 === 0 && x.R() < 0.08 + 0.3 * I) { E.bell(C.bell, x.t, scaleNote(x.key, PENTM, 10 + Math.floor(x.R() * 8)), 0.15); if (x.R() < 0.3) E.bell(C.bell, x.t + x.dt * 3, scaleNote(x.key, PENTM, 12 + Math.floor(x.R() * 6)), 0.1); }
        if (I > 0.1 && x.sib % 4 === 0) E.clockTick(C.tick, x.t, (x.sib % 8 === 0 ? 0.26 : 0.18) * x.lv(0.1, 0.25));
        if (I > 0.48 && (x.sib === 0 || x.sib === 8)) E.kick(C.pulse, x.t, 0.45 * x.lv(0.48, 0.15));
        if (I > 0.8 && x.sib % 2 === 1) E.hat(C.tick, x.t, 0.08 * x.lv(0.8, 0.1), false);
        E.fxPeak(S, x, C.fx, 0.4);
     } },
   // 7 · FINAL FRONTIER — epica heroica: cuerdas en ostinato, metales, un tema de trompas propio, timbales y taikos
   { id: "S7", name: "Final Frontier", es: "La última frontera", key: 50, keyName: ["D major", "Re mayor"], bpm: 92, bars: 48, cb: 2, seed: 707,
     shape: [0.08, 0.70, 0.88, 0.16], echo: 0.5, trim: 0.256,
     chars: ["Heroic epic: string ostinato, brass chords, an original horn theme, timpani and taiko build into a big crescendo", "Épica heroica: ostinato de cuerdas, acordes de metales, un tema de trompas propio, timbales y taikos hasta un gran crescendo"],
     progs: [[[0, "M"], [10, "M"], [5, "M"], [0, "M"]], [[9, "m"], [5, "M"], [0, "M"], [7, "M"]]],
     chans: function(E, S) { return { ost: E._chan(S, { lp: 1400, vib: [5.6, 0.00012], rev: 0.35, gain: 0.6 }), low: E._chan(S, { lp: 900, vib: [5, 0.00015], rev: 0.4, gain: 0.6 }),
                                      brass: E._chan(S, { rev: 0.5, gain: 0.55, pan: -0.12 }), horn: E._chan(S, { rev: 0.55, dly: 0.1, gain: 0.55, pan: 0.12 }), drum: E._chan(S, { rev: 0.35, gain: 0.9 }),
                                      snare: E._chan(S, { rev: 0.3, gain: 0.4 }), fx: E._chan(S, { rev: 0.5, gain: 0.55 }) }; },
     // el tema (posicion en el acorde de 2 compases, semitonos sobre la raiz, duracion en semicorcheas)
     theme: [[0, 0, 4], [4, 7, 2], [6, 12, 10], [16, 14, 4], [20, 12, 4], [24, 7, 8]],
     play: function(E, S, x) {
        var C = S.C, I = x.I, P = S.P, i;
        if (x.sib === 0) E.sweep(C.ost, x.t, 900 + 3000 * I, 1.0);
        var div = I < 0.6 ? 2 : 1;
        if (x.sib % div === 0) { var r0 = rootIn(x.key, x.ch, 50), pat = [0, 7, 12, 7], m = r0 + pat[(x.k / div | 0) % 4]; E.pluck(C.ost, x.t, m, (0.11 + 0.12 * I) * (x.sib % 4 === 0 ? 1.2 : 1), { wave: "sawtooth", cut: 4000, cut2: 1500, dec: 0.14, det: 7, q: 0.7 }); }
        if (x.cs) { var rl = rootIn(x.key, x.ch, 38); E.pad(C.low, x.t, [rl, rl + 7], x.chDur, 0.24 + 0.18 * I, { a: 0.6, r: 1.2, det: 6 }); }
        if (I > 0.35 && (x.chPos === 0 || x.chPos === 16)) E.brass(C.brass, x.t, chordIn(x.key, x.ch, 55, 13), x.barS - 0.1, 0.24 * x.lv(0.35, 0.2), { a: 0.25, bright: 0.3 + 0.5 * I });
        if (I > 0.55) for (i = 0; i < P.theme.length; ++i) if (P.theme[i][0] === x.chPos) { var hm = rootIn(x.key, x.ch, 62) + P.theme[i][1]; E.brass(C.horn, x.t, [hm], x.dt * P.theme[i][2] - 0.04, 0.26 * x.lv(0.55, 0.15), { a: 0.06, bright: 0.55 + 0.3 * I }); }
        if (I > 0.22 && x.sib === 0) E.timp(C.drum, x.t, rootIn(x.key, x.ch, 40), 0.4 * x.lv(0.22, 0.2));
        if (I > 0.6 && (x.sib === 6 || x.sib === 10)) E.taiko(C.drum, x.t, 0.4 * x.lv(0.6, 0.15));
        if (E.inRiser(S, x)) { var b1 = Math.round(P.shape[1] * P.bars), u = ((x.bic - (b1 - (P.riserBars || 4))) * 16 + x.sib) / ((P.riserBars || 4) * 16); if (x.sib % (u > 0.5 ? 1 : 2) === 0) E.taiko(C.drum, x.t, 0.12 + 0.35 * u); if (u > 0.75) E.snare(C.snare, x.t, 0.1 + 0.3 * u); }
        if (I > 0.8 && (x.sib === 4 || x.sib === 12)) E.snare(C.snare, x.t, 0.35 * x.lv(0.8, 0.1));
        E.fxPeak(S, x, C.fx, 0.55);
     } },
   // 8 · SOLAR WIND — marimbas en polirritmo 3 contra 4, percusion suave, kalimba en lo alto
   { id: "S8", name: "Solar Wind", es: "Viento solar", key: 55, keyName: ["G major pentatonic", "Sol mayor pentatónica"], bpm: 112, bars: 56, cb: 2, seed: 808,
     shape: [0.10, 0.68, 0.86, 0.22], echo: 0.75, trim: 0.398,
     chars: ["Two marimbas in a 3-against-4 polyrhythm, shaker and soft toms, round bass; kalimba sparks and strings at the climax", "Dos marimbas en polirritmo 3 contra 4, shaker y toms suaves, bajo redondo; chispas de kalimba y cuerdas en el clímax"],
     progs: [[[0, "add9"], [7, "M"], [9, "m7"], [5, "M7"]], [[0, "M"], [4, "m"], [5, "M"], [2, "sus4"]]],
     chans: function(E, S) { return { marA: E._chan(S, { pan: -0.3, rev: 0.3, gain: 0.6 }), marB: E._chan(S, { pan: 0.35, rev: 0.35, dly: 0.18, gain: 0.5 }), kal: E._chan(S, { rev: 0.5, dly: 0.3, gain: 0.4, pan: 0.1 }),
                                      pad: E._chan(S, { lp: 1800, vib: [5, 0.00015], rev: 0.6, gain: 0.4 }), bass: E._chan(S, { gain: 0.7 }), shk: E._chan(S, { pan: 0.2, gain: 0.4 }),
                                      tom: E._chan(S, { rev: 0.3, gain: 0.6 }), kick: E._chan(S, { gain: 0.6 }), rim: E._chan(S, { rev: 0.2, gain: 0.35, pan: -0.15 }), fx: E._chan(S, { rev: 0.5, gain: 0.3 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I, sh = [0, 2, 3, 1][Math.floor(x.bic / S.P.cb) % 4];
        if (x.k % 3 === 0) { var d = ((x.k / 3) | 0) % 5; E.marimba(C.marA, x.t, scaleNote(x.key + 12, PENTA, d + sh), (0.13 + 0.09 * I) * (d === 0 ? 1.2 : 1)); }
        if (I > 0.3 && x.sib % 2 === 0) { var tn = chordIn(x.key, x.ch, 67, 13); E.marimba(C.marB, x.t, tn[(tn.length - 1) - ((x.sib / 2) % tn.length)], 0.12 * x.lv(0.3)); }
        if (I > 0.2 && (x.sib === 0 || x.sib === 7 || x.sib === 10)) E.bass(C.bass, x.t, rootIn(x.key, x.ch, 43) + (x.sib === 7 ? 7 : 0), x.dt * 2.5, 0.32 * x.lv(0.2), 450);
        if (I > 0.14) E.shaker(C.shk, x.t, [0.1, 0.04, 0.07, 0.04][x.sib % 4] * (0.6 + 0.6 * I) * x.lv(0.14, 0.1));
        if (I > 0.45 && (x.sib === 0 || x.sib === 6 || x.sib === 12)) E.tom(C.tom, x.t, 45 + (x.sib === 6 ? 5 : 0), 0.24 * x.lv(0.45), 0.4);
        if (I > 0.62 && (x.sib === 0 || x.sib === 8)) E.kick(C.kick, x.t, 0.45 * x.lv(0.62, 0.1));
        if (I > 0.7 && (x.sib === 4 || x.sib === 12)) E.snare(C.rim, x.t, 0.22 * x.lv(0.7, 0.1), true);
        if (x.cs) E.pad(C.pad, x.t, chordIn(x.key, x.ch, 55, 14), x.chDur, 0.12 + 0.12 * I, { a: 1.2, r: 1.8 });
        if (I > 0.78 && x.R() < 0.3) E.kalimba(C.kal, x.t, scaleNote(x.key + 24, PENTA, Math.floor(x.R() * 7)), 0.1 * x.lv(0.78, 0.1));
        E.fxPeak(S, x, C.fx, 0.3);
     } },
   // 9 · GRAVITY WELL — oscuro: ostinato grave en semicorcheas, «braams» de metales, taikos
   { id: "S9", name: "Gravity Well", es: "Pozo gravitatorio", key: 50, keyName: ["D minor (Phrygian colour)", "Re menor (color frigio)"], bpm: 84, bars: 48, cb: 2, seed: 909,
     shape: [0.10, 0.70, 0.88, 0.15], echo: 0.5, trim: 0.391,
     chars: ["Dark tension: low sixteenth ostinato, brass braams on the chord changes, taiko patterns and a half-time backbeat", "Tensión oscura: ostinato grave en semicorcheas, «braams» de metales en los cambios de acorde, taikos y contratiempo a medio tiempo"],
     progs: [[[0, "m"], [1, "M"], [0, "m"], [8, "M"]], [[0, "m"], [8, "M"], [5, "m"], [7, "M"]]],
     chans: function(E, S) { return { ost: E._chan(S, { lp: 500, lq: 1, rev: 0.25, gain: 0.75 }), pad: E._chan(S, { lp: 1200, vib: [0.2, 0.0015], rev: 0.6, gain: 0.45 }), braam: E._chan(S, { rev: 0.5, gain: 0.6 }),
                                      tick: E._chan(S, { pan: 0.3, gain: 0.3 }), drum: E._chan(S, { rev: 0.35, gain: 0.9 }), snare: E._chan(S, { rev: 0.45, gain: 0.45 }), sub: E._chan(S, { gain: 0.6 }),
                                      fx: E._chan(S, { rev: 0.55, gain: 0.55 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I, acc = [1, 0.5, 0.65, 0.5, 0.9, 0.5, 0.7, 0.5][x.sib % 8];
        if (x.sib === 0) E.sweep(C.ost, x.t, 450 + 2400 * I, 1.0);
        var r = rootIn(x.key, x.ch, 38), pat = [0, 0, 12, 0, 0, 7, 0, 12];
        E.pluck(C.ost, x.t, r + pat[x.sib % 8], (0.11 + 0.13 * I) * acc, { wave: "sawtooth", cut: 3000, cut2: 600, dec: 0.12, det: 6, q: 1 });
        if (x.cs) { E.pad(C.pad, x.t, chordIn(x.key, x.ch, 50, 14), x.chDur, 0.16, { a: 2.0, r: 2.2 }); E.sub(C.sub, x.t, rootIn(x.key, x.ch, 26), x.chDur - 0.3, 0.3 * x.lv(0.2, 0.2)); }
        if (I > 0.3) E.hat(C.tick, x.t, (0.035 + 0.04 * I) * acc, false);
        if (I > 0.45 && [0, 3, 8, 11].indexOf(x.sib) >= 0) E.taiko(C.drum, x.t, 0.38 * x.lv(0.45) * (x.sib === 0 ? 1.2 : 1));
        if (I > 0.85 && x.sib >= 12) E.taiko(C.drum, x.t, 0.25 * x.lv(0.85, 0.1));
        if (I > 0.6 && x.cs) { var rb = rootIn(x.key, x.ch, 38); E.brass(C.braam, x.t, [rb, rb + 7, rb + 12], x.barS * 1.3, 0.32 * x.lv(0.6, 0.15), { a: 0.35, bright: 0.45 + 0.4 * I, r: 1.0 }); }
        if (I > 0.78 && x.sib === 8) E.snare(C.snare, x.t, 0.45 * x.lv(0.78, 0.1));
        E.fxPeak(S, x, C.fx, 0.55);
     } },
   // 10 · AURORA STATION — esperanzada: piano FM en arpegios con eco, cuerdas, bateria de escobillas, melodia lidia
   { id: "S10", name: "Aurora Station", es: "Estación Aurora", key: 51, keyName: ["E-flat major (Lydian)", "Mi bemol mayor (lidio)"], bpm: 88, bars: 48, cb: 2, seed: 1010,
     shape: [0.12, 0.70, 0.88, 0.22], echo: 0.75, trim: 0.326,
     chars: ["Hopeful: arpeggiated FM piano with echoes, warm strings, brushed drums and a Lydian melody at the climax", "Esperanzada: piano FM en arpegios con eco, cuerdas cálidas, batería de escobillas y una melodía lidia en el clímax"],
     progs: [[[0, "add9"], [7, "M"], [9, "m7"], [5, "M7"]], [[5, "M7"], [7, "sus4"], [4, "m7"], [9, "m"]]],
     chans: function(E, S) { return { pno: E._chan(S, { rev: 0.45, dly: 0.28, pan: 0.1, gain: 0.75 }), str: E._chan(S, { lp: 3000, vib: [5.2, 0.00016], rev: 0.6, gain: 0.45 }), bass: E._chan(S, { gain: 0.6 }),
                                      kick: E._chan(S, { gain: 0.55 }), snare: E._chan(S, { rev: 0.3, gain: 0.35 }), hat: E._chan(S, { pan: 0.3, gain: 0.25 }), mel: E._chan(S, { rev: 0.55, dly: 0.25, pan: -0.1, gain: 0.45 }),
                                      fx: E._chan(S, { rev: 0.5, gain: 0.3 }) }; },
     play: function(E, S, x) {
        var C = S.C, I = x.I;
        if (x.sib % 2 === 0) { var tn = chordIn(x.key, x.ch, 58, 19), pat = [0, 2, 1, 3, 2, 1, 3, 2]; E.epiano(C.pno, x.t, tn[pat[(x.sib / 2) % 8] % tn.length], x.dt * 3, (0.12 + 0.08 * I) * (x.sib % 8 === 0 ? 1.15 : 1)); }
        if (I > 0.25 && x.cs) E.bass(C.bass, x.t, rootIn(x.key, x.ch, 39), x.chDur - 0.2, 0.3 * x.lv(0.25), 450);
        if (I > 0.4 && x.cs) E.pad(C.str, x.t, chordIn(x.key, x.ch, 63, 14), x.chDur, 0.2 * x.lv(0.4, 0.2), { a: 1.5, r: 1.8 });
        if (I > 0.55 && (x.sib === 0 || x.sib === 10)) E.kick(C.kick, x.t, 0.45 * x.lv(0.55, 0.1));
        if (I > 0.55 && (x.sib === 4 || x.sib === 12)) E.snare(C.snare, x.t, 0.3 * x.lv(0.55, 0.1), true);
        if (I > 0.65 && x.sib % 2 === 0) E.hat(C.hat, x.t, (x.sib % 4 === 2 ? 0.12 : 0.07) * x.lv(0.65, 0.1), false);
        if (I > 0.72) { var mp = { 0: 0, 6: 1, 12: 2, 16: 3, 24: 2 }[x.chPos]; if (mp !== undefined) { var hi = chordIn(x.key, x.ch, 75, 12).concat([rootIn(x.key, [x.ch[0] + 2, "M"], 75)]); E.fm(C.mel, x.t, hi[mp % hi.length], 0.16 * x.lv(0.72, 0.1), { ratio: 2, index: 0.9, idec: 0.4, dec: 1.6, r: 0.4 }); } }
        E.fxPeak(S, x, C.fx, 0.3);
     } }
   ];
   // (M2) las capas nuevas de cada emisora (E_._enrich): registros elegidos para NO pisar la linea principal (la contramelodia va por
   // debajo o por encima de ella), y el nivel medido con RICH (trimR: tests/radio/fv_music_rich.mjs, −18 LUFS como el resto)
   var LAYERS = {
      S1:  { ens: [57, 14, 0.25, 0.10], cm: [45, 57, 0.30, 0.14, "vc"], harp: [81, 12, 0.60, 0.05] },     // organo + cuerdas + violonchelo + celesta
      S2:  { cm: [67, 79, 0.30, 0.10, "fl"], harp: [62, 19, 0.45, 0.06] },                                 // colchones + flauta + arpa
      S3:  { ens: [55, 15, 0.20, 0.08], cm: [45, 59, 0.30, 0.13, "vc"] },                                  // arpegios + cuerdas + violonchelo
      S4:  { ens: [53, 14, 0.25, 0.07], cm: [72, 84, 0.45, 0.09, "fl"] },                                  // piano + cuerdas + flauta
      S5:  { cm: [48, 60, 0.35, 0.12, "vc"], harp: [67, 17, 0.40, 0.05] },                                 // coro + violonchelo + arpa
      S6:  { ens: [59, 14, 0.20, 0.06], cm: [66, 78, 0.50, 0.08, "fl"], harp: [71, 14, 0.35, 0.04] },      // drones + cuerdas + flauta + arpa
      S7:  { ens: [62, 15, 0.30, 0.09], cm: [76, 88, 0.45, 0.08, "fl"], harp: [62, 19, 0.50, 0.05] },      // epica + cuerdas altas + flauta + arpa
      S8:  { cm: [74, 86, 0.40, 0.08, "fl"] },                                                             // marimbas + flauta
      S9:  { ens: [57, 12, 0.35, 0.06], cm: [45, 57, 0.30, 0.13, "vc"] },                                  // oscuro + cuerdas + violonchelo
      S10: { ens: [51, 14, 0.15, 0.07], cm: [70, 82, 0.30, 0.09, "fl"], harp: [70, 17, 0.55, 0.05] }       // piano + cuerdas + flauta + arpa
   };
   var TRIM_RICH = { S1: 0.1662, S2: 0.2156, S3: 0.1644, S4: 0.2150, S5: 0.1613, S6: 0.1586, S7: 0.1844, S8: 0.2602, S9: 0.3046, S10: 0.2319 };
   for (var pi = 0; pi < PRESETS.length; ++pi) { PRESETS[pi].rich = LAYERS[PRESETS[pi].id] || null; if (TRIM_RICH[PRESETS[pi].id]) PRESETS[pi].trimR = TRIM_RICH[PRESETS[pi].id]; }

   // ====================================================================================================================
   // (19-nov-2026, I5; E1-18 «sonido que informa» y E1-19 «motivo al descubrir») LA RADIO TAMBIEN INFORMA. Bandera E1A.ON (false = lo de antes: el motor
   // ni crea nodos ni responde a inform()). Todo sale por la misma cadena que la musica (mezcla → glue → paso bajo de la atenuacion → limitador), de modo
   // que respeta el volumen, la emisora que suena (sin emisora de a bordo no hay nada), la atenuacion de la cabina y la radio apagada (el motor se para).
   //
   // E1-18 · TEMPERATURA → NOTA (convencion declarada, no «el sonido de la estrella»). Continua, monotona y FIJA (la misma temperatura suena igual
   //   siempre y en cualquier emisora, para que se aprenda; no se ajusta a la tonalidad de la emisora):
   //     u  = clamp( ln(Teff / 2500 K) / ln(30000 K / 2500 K), 0, 1 )          escala logaritmica en temperatura
   //     f  = 110 Hz · 2^(3·u)                                                  A2 (2500 K) … A5 (30 000 K): tres octavas, sin cuantizar
   //   Mas caliente = mas agudo Y mas brillante (mas parciales, paso bajo mas abierto, ataque mas seco, caida mas corta); mas fria = mas grave y mas
   //   calida (casi solo la fundamental y el 2.º armonico, paso bajo cerrado, ataque blando, cola larga). Sin dato de Teff (o un valor que no es una
   //   temperatura estelar: fuera de 1500–100 000 K) NO suena nada: no se inventa ninguna.
   // E1-19 · MOTIVO al cerrar o descubrir algo («arrive» al llegar a un objeto principal, «resolve» una pregunta o misterio resuelto, «chain» el final de
   //   una cadena). Cuatro notas como mucho (el acorde de «chain» es la quinta), arpa de sintesis modal, EN LA TONALIDAD DE LA EMISORA (tonica y tercera de
   //   su modo; el 5.º y la octava), empezando en el siguiente octavo de su rejilla rítmica y con la separacion de ese pulso: suena de la emisora, no
   //   encima. Dura como mucho 2 compases de la emisora mas lenta. Nada de «ding» de videojuego: ni brillo agudo ni subida, sino lo que ya suena en la sala.
   // ENFRIAMIENTO (e1aGate, puro): una nota cada ≥ 1,2 s, como mucho 6 en 20 s (3 de «paso cerca»); un motivo cada ≥ 30 s y el mismo motivo en la misma
   //   emisora cada ≥ 90 s; durante un motivo (y 1 s despues) no suena ninguna nota. La razon del silencio queda en infoLog[].why.
   // ====================================================================================================================
   var E1A = {
      ON: true,
      T_LO: 2500, T_HI: 30000, T_MIN: 1500, T_MAX: 100000, F_LO: 110, OCT: 3,
      V_STAR: 0.07, V_PASS_K: 0.5, V_MOTIF: 0.08,                        // niveles en la mezcla del motor (medidos: tests/_e1a/fv_e1a_level_cdp.js)
      STAR_GAP: 1.2, WIN_S: 20, WIN_N: 6, WIN_PASS: 3, MOTIF_GAP: 30, MOTIF_SAME: 90, MOTIF_AFTER: 1.0,
      I_LO: 0.35,                                                        // el aviso al 35 % en los pasajes mas finos (I = 0) y al 100 % con la emisora a tope (I = 1)
      NOTE_S: 0.30,                                                      // separacion minima entre notas de un motivo (s), redondeada a semicorcheas de la emisora
      DUCK_MIN: 0.12                                                     // con la radio atenuada por debajo de esto (silencio de llegada, salto del warp) no se suena
   };
   var NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
   function e1aTeffMap(teff) {
      var T = (typeof teff === "number") ? teff : ((typeof teff === "string" && teff !== "") ? Number(teff) : NaN);
      if (!(T >= E1A.T_MIN && T <= E1A.T_MAX)) return null;               // NaN, null, 0, negativo, absurdo: sin dato = sin nota
      var u = clamp(Math.log(T / E1A.T_LO) / Math.log(E1A.T_HI / E1A.T_LO), 0, 1);
      var hz = E1A.F_LO * Math.pow(2, E1A.OCT * u), midi = 69 + 12 * Math.log(hz / 440) / Math.LN2, nr = Math.round(midi), cents = Math.round((midi - nr) * 100);
      return { teff: T, u: u, hz: hz, midi: midi, note: NOTE_NAMES[((nr % 12) + 12) % 12] + (Math.floor(nr / 12) - 1) + (cents >= 0 ? "+" : "") + cents + "c",
               cutoff: hz * (2.2 + 9 * u), attack: 0.030 - 0.026 * u, tau: 1.5 - 0.9 * u, amps: [1, 0.18 + 0.42 * u, 0.04 + 0.40 * u, 0.02 + 0.30 * Math.pow(u, 1.5)],
               saturated: (T < E1A.T_LO || T > E1A.T_HI) };
   }
   // el modo de cada emisora para el motivo: intervalo de su tercera (3 menor, 4 mayor) y la tonica dentro de C4–B4. Tonalidades de la ficha de cada preset
   var MOTIF_THIRD = { S1: 3, S2: 4, S3: 3, S4: 4, S5: 3, S6: 3, S7: 4, S8: 4, S9: 3, S10: 4 };
   // el plan de un motivo (puro): notas en unidades de separacion («at»), semitonos sobre la tonica («s»), nivel relativo («v») y si es la larga
   function e1aMotif(name, idx) {
      var P = PRESETS[clamp(idx | 0, 0, PRESETS.length - 1)], th = MOTIF_THIRD[P.id] || 4, root = P.key;
      while (root < 60) root += 12; while (root >= 72) root -= 12;
      var N;
      if (name === "arrive") N = [{ at: 0, s: 0, v: 0.80 }, { at: 1, s: th, v: 0.85 }, { at: 2, s: 7, v: 0.90 }, { at: 3, s: 12, v: 1.0, long: true }];
      else if (name === "resolve") N = [{ at: 0, s: 19, v: 0.80 }, { at: 1, s: 12 + th, v: 0.85 }, { at: 2.5, s: 12, v: 1.0, long: true }];
      else if (name === "chain") N = [{ at: 0, s: 0, v: 0.75 }, { at: 1, s: th, v: 0.8 }, { at: 2, s: 7, v: 0.85 }, { at: 3, s: 12, v: 0.9 }, { at: 4.2, s: 12, v: 0.7, long: true }, { at: 4.2, s: 12 + th, v: 0.6, long: true }, { at: 4.2, s: 19, v: 0.6, long: true }];
      else return null;
      return { name: name, id: P.id, idx: idx, root: root, third: th, notes: N, span: N[N.length - 1].at };
   }
   // el enfriamiento (puro: se prueba en node sin WebAudio)
   function e1aGate() { return { lastStar: -1e9, lastMotif: -1e9, motifAt: {}, busyUntil: -1e9, win: [], winPass: [] }; }
   function e1aGateWhy(g, kind, key, now) {
      if (kind === "motif") {
         if (now - g.lastMotif < E1A.MOTIF_GAP) return "motif-gap";
         if (g.motifAt[key] !== undefined && now - g.motifAt[key] < E1A.MOTIF_SAME) return "motif-same";
         return "";
      }
      if (now < g.busyUntil) return "busy";
      if (now - g.lastStar < E1A.STAR_GAP) return "gap";
      var k = 0, i; for (i = 0; i < g.win.length; ++i) if (now - g.win[i] < E1A.WIN_S) g.win[k++] = g.win[i]; g.win.length = k;
      k = 0; for (i = 0; i < g.winPass.length; ++i) if (now - g.winPass[i] < E1A.WIN_S) g.winPass[k++] = g.winPass[i]; g.winPass.length = k;
      if (g.win.length >= E1A.WIN_N) return "rate";
      if (kind === "pass" && g.winPass.length >= E1A.WIN_PASS) return "rate-pass";
      return "";
   }
   function e1aGateCommit(g, kind, key, now, busyUntil) {
      if (kind === "motif") { g.lastMotif = now; g.motifAt[key] = now; if (busyUntil > g.busyUntil) g.busyUntil = busyUntil; return; }
      g.lastStar = now; g.win.push(now); if (kind === "pass") g.winPass.push(now);
   }
   // la puerta de la PAGINA (la misma en PixInsight y en el visor): s = { on (radio encendida), sw (interruptor «sonido que informa»), gen (suena una emisora de a bordo),
   // ctx (estado del contexto de audio), duck (factor de atenuacion de la cabina 0…1), force (pruebas: el contexto suspendido cuenta como sonando) }
   function e1aPageWhy(s) {
      if (!E1A.ON) return "off";
      if (!s.on) return "radio-off";
      if (s.sw === false) return "switch-off";
      if (!s.gen) return "not-generative";
      if (s.ctx !== "running" && !s.force) return "suspended";
      if (typeof s.duck === "number" && s.duck < E1A.DUCK_MIN) return "ducked";
      return "";
   }
   // la nota entra por los MISMOS canales de la emisora que suena (seco y envio a la sala: S.dry y S.rev, que ya llevan el nivel medido de la emisora y su «director»), asi su
   // volumen sigue al de la musica en todo el ciclo (medido: tests/_e1a/fv_e1a_level_cdp.js) y, si se cambia de emisora, se apaga con ella
   E_._infoNote = function(t, midi, v, parts, a, hold, rel, cutoff, wet) {
      var c = this.ctx, S = this.st, lp = this._f("lowpass", Math.min(cutoff, 0.4 * c.sampleRate), 0.6), sd = c.createGain(), C = { in: lp };
      sd.gain.value = wet; lp.connect(S.dry); lp.connect(sd); sd.connect(S.rev);
      var end = this._modal(C, t, midi, v, parts, a, hold, rel, 0);
      this.infoNotes = (this.infoNotes || 0) + 1;                       // las notas del sonido que informa (this.notes cuenta tambien las de la musica)
      if (!this.offline && typeof setTimeout === "function") setTimeout(function() { try { lp.disconnect(); sd.disconnect(); } catch (e) {} }, Math.max(1000, (end - c.currentTime + 1) * 1000));
      return end;
   };
   // la intensidad (0-1) de la emisora en el instante t del contexto: la misma cuenta que _step (curva de la emisora + lo que pide el viaje). El aviso es mas bajo en los
   // pasajes finos (introduccion, bajada): medido, con el mismo nivel en todo el ciclo las notas igualaban a la musica de una introduccion de colchon solo
   E_._intensityAt = function(S, t) {
      var P = S.P, k = Math.max(0, Math.floor((t - S.t0 + S.off) / S.dt + 1e-9)), bar = Math.floor(k / 16), sib = k - bar * 16, cyc = Math.floor(bar / P.bars), bic = bar - cyc * P.bars;
      var e = (this.fixedI !== null) ? this.fixedI : shape(P, (bic * 16 + sib) / (P.bars * 16), cyc);
      return (this.lvTo !== null) ? clamp(e + 0.55 * (this.lvSm - 0.45), 0, 1) : e;
   };
   E_.setInform = function(b) { this.infoOff = !b; return !this.infoOff; };
   // ev = { kind: "star" | "pass", teff } | { kind: "motif", name }; ev.at = instante del contexto (pruebas; por defecto «ya»). -> { played, why, ... }
   E_.inform = function(ev) {
      var c = this.ctx, S = this.st, r = { played: false, why: "", kind: ev ? ev.kind : "" };
      if (!this.ig) this.ig = e1aGate();
      if (!this.infoLog) this.infoLog = [];
      var self = this, fin = function() { self.infoLog.push(r); if (self.infoLog.length > 200) self.infoLog.shift(); return r; };
      if (!E1A.ON || this.infoOff) { r.why = "off"; return fin(); }
      if (!ev || !S || S.dead) { r.why = "no-station"; return fin(); }
      var now = (ev.at !== undefined) ? ev.at : c.currentTime; r.t = now; r.station = S.P.id;
      var kind = ev.kind, why, t0;
      if (kind === "star" || kind === "pass") {
         var m = e1aTeffMap(ev.teff);
         if (!m) { r.why = "no-teff"; return fin(); }
         why = e1aGateWhy(this.ig, kind, "", now); if (why) { r.why = why; return fin(); }
         var pass = (kind === "pass"), w = m.amps, nrm = Math.sqrt(w[0] * w[0] + w[1] * w[1] + w[2] * w[2] + w[3] * w[3]), tau = m.tau * (pass ? 0.45 : 1);
         t0 = (ev.at !== undefined) ? ev.at : c.currentTime + 0.03;
         var kI = E1A.I_LO + (1 - E1A.I_LO) * this._intensityAt(S, t0);
         var v = E1A.V_STAR * kI * Math.pow(440 / m.hz, 0.25) * (pass ? E1A.V_PASS_K : 1) / nrm;           // compensa lo grave y la suma de parciales: parecida sonoridad en toda la escala
         var parts = [[1, w[0], tau, 0], [2, w[1], tau * 0.6, 0], [3, w[2], tau * 0.4, 0], [4.01, w[3], tau * 0.25, 0]];
         var rel = 0.25 + 0.35 * (1 - m.u), end = this._infoNote(t0, m.midi, v, parts, m.attack, tau * 1.3, rel, m.cutoff, pass ? 0.3 : 0.45);
         e1aGateCommit(this.ig, kind, "", now, 0);
         r.played = true; r.hz = m.hz; r.midi = m.midi; r.note = m.note; r.teff = m.teff; r.v = v; r.endsAt = end; r.t0 = t0; r.cutoff = m.cutoff; r.u = m.u; r.kI = kI;
         return fin();
      }
      if (kind === "motif") {
         var plan = e1aMotif(ev.name, S.idx);
         if (!plan) { r.why = "unknown-motif"; return fin(); }
         var key = ev.name + "|" + S.P.id;
         why = e1aGateWhy(this.ig, "motif", key, now); if (why) { r.why = why; return fin(); }
         // el comienzo: el siguiente octavo de la rejilla de la emisora (a como mucho un octavo de ahora); la separacion, semicorcheas de la emisora ≥ NOTE_S
         var base = (ev.at !== undefined) ? ev.at : c.currentTime + 0.04, grid = 2 * S.dt, spc = S.dt * Math.max(1, Math.ceil(E1A.NOTE_S / S.dt - 1e-9));
         t0 = (ev.at !== undefined) ? ev.at : (S.t0 - S.off + Math.ceil((base - (S.t0 - S.off)) / grid - 1e-9) * grid);
         var fr = [], last = 0, i, nt, kM = E1A.I_LO + (1 - E1A.I_LO) * this._intensityAt(S, t0);
         for (i = 0; i < plan.notes.length; ++i) {
            nt = plan.notes[i]; var tt = t0 + nt.at * spc, vv = E1A.V_MOTIF * kM * nt.v * Math.pow(440 / (440 * Math.pow(2, (plan.root + nt.s - 69) / 12)), 0.2);
            var pp = nt.long ? [[1, 1, 1.8, 0], [2.0, 0.3, 0.9, 0], [3.01, 0.1, 0.5, 0], [4.2, 0.05, 0.3, 0]] : [[1, 1, 0.9, 0], [2.0, 0.35, 0.45, 0], [3.0, 0.13, 0.25, 0], [4.0, 0.05, 0.15, 0]];
            var ee = this._infoNote(tt, plan.root + nt.s, vv, pp, 0.004, nt.long ? 3.0 : 1.4, nt.long ? 0.9 : 0.5, 4200, 0.6);
            fr.push({ t: tt, midi: plan.root + nt.s, hz: 440 * Math.pow(2, (plan.root + nt.s - 69) / 12) }); if (ee > last) last = ee;
         }
         e1aGateCommit(this.ig, "motif", key, now, t0 + plan.span * spc + E1A.MOTIF_AFTER + 1.2);
         r.played = true; r.name = ev.name; r.t0 = t0; r.notes = fr; r.endsAt = last; r.root = plan.root; r.kI = kM; r.third = plan.third; r.spacing = spc;
         return fin();
      }
      r.why = "unknown-kind"; return fin();
   };

   function cycleSec(idx) { var P = PRESETS[idx]; return P.bars * 16 * 60 / P.bpm / 4; }
   // «en antena»: cada emisora sigue sonando aunque no la escuches; al sintonizarla entras por donde va (reloj del sistema)
   function onAir(idx, nowMs) { var c = cycleSec(idx); return ((((nowMs === undefined ? Date.now() : nowMs) / 1000) + idx * 41.7) % c + c) % c; }
   // donde empieza el fragmento de escucha: los ultimos `before` s de la subida (y lo que siga del climax)
   function excerptStart(idx, before) { var P = PRESETS[idx]; return Math.max(0, P.shape[1] * cycleSec(idx) - (before === undefined ? 45 : before)); }
   // render sin tiempo real (las pruebas y la escucha): -> Promise<AudioBuffer>
   function render(idx, seconds, opts) {
      opts = opts || {};
      var sr = opts.sr || 48000, OAC = (typeof OfflineAudioContext !== "undefined") ? OfflineAudioContext : webkitOfflineAudioContext;
      var oc = new OAC(2, Math.ceil(seconds * sr), sr), E = new Engine(oc, oc.destination, { offline: true, rich: opts.rich, lite: opts.lite });
      if (opts.onsets) E.onsets = [];
      if (opts.onlyLayers) E.onlyLayers = true;   // (M2, pruebas) solo las capas nuevas: su peso en la mezcla
      if (opts.testSine) E.testSine = true;
      if (opts.fixedI !== undefined && opts.fixedI !== null) E.fixedI = opts.fixedI;
      if (opts.level !== undefined && opts.level !== null) E.setLevel(opts.level, true);
      if (opts.trim !== undefined) { var keep = PRESETS[idx].trim; PRESETS[idx].trim = opts.trim; E.start(idx, opts.offset || 0, 0); PRESETS[idx].trim = keep; }
      else E.start(idx, opts.offset || 0, 0);
      var chunk = 1.0;
      E.pump(chunk + 0.6);
      for (var tt = chunk; tt < seconds; tt += chunk) (function(t1) { oc.suspend(t1).then(function() { E.pump(t1 + chunk + 0.6); oc.resume(); }); })(tt);
      render.last = E;
      return oc.startRendering();
   }
   var STATIONS = PRESETS.map(function(P, i) { return { id: P.id, name: P.name, es: P.es, key: P.keyName, bpm: P.bpm, cycle: Math.round(cycleSec(i)), echoS: 60 / P.bpm * P.echo, chars: P.chars }; });
   return { VERSION: VERSION, RICH: RICH, STATIONS: STATIONS, n: PRESETS.length, create: function(ctx, dest, opts) { return new Engine(ctx, dest, opts); },
            onAir: onAir, cycleSec: cycleSec, excerptStart: excerptStart, render: render,
            E1A: E1A, e1aTeffMap: e1aTeffMap, e1aMotif: e1aMotif, e1aGate: e1aGate, e1aGateWhy: e1aGateWhy, e1aGateCommit: e1aGateCommit, e1aPageWhy: e1aPageWhy,   // (I5, 19-nov) sonido que informa
            _t: { chordIn: chordIn, rootIn: rootIn, shape: shape, presets: PRESETS } };
})();
if (typeof window !== "undefined") window.FVMusic = FVMusic;
