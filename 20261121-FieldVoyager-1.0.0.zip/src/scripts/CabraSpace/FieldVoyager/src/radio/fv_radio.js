// ============================================================================
// FieldVoyager/src/radio/fv_radio.js — LA RADIO DE A BORDO («RADIOPHONIA») para PixInsight (4-nov-2026: emisoras generativas)
// ----------------------------------------------------------------------------
// Un componente que la cabina integra: `new FVRadio(parentControl, opts)` crea un WebView pequeño con la pagina fv_radio.html (dial
// redondo de escala fija con aguja, mando moleteado, lampara, estatica de WebAudio) y expone
//   play() · stop() · tune(posicion 0-100 | id) · volume(0-1) · level(0-1 | null) · duck(f, s, hz) · setMusicFolder(ruta) · chooseFolder()
//   onStationTuned(info) — «emisora sintonizada»: { id, kind, station, title, author, license, position }
// Ver src/radio/README.md.
//
// DE DONDE SALE LA MUSICA: DIEZ EMISORAS PROPIAS que la pagina compone en directo con el motor src/radio/fv_music.js (WebAudio):
// ningun fichero de audio, ninguna descarga, ninguna red, obra propia (CC0). fv_music.js y fv_radio.html viajan junto a este fichero.
// Ademas, «Mi musica» (guino: «Awesome Mix»): si el usuario elige una carpeta (recordada con Settings), sus MP3/OGG son una emisora mas,
// detras de las diez.
// (4-nov) Se quito el catalogo de pistas de terceros (R1-R10), la descarga con curl, las huellas SHA-256 y la cache: R6-R10 no tenian
// enlace y la radio no era ni dinamica ni facil (Nino).
//
// POLITICA DE AUTOPLAY (F0b, tests/fv_audio_probe*.log): el WebView solo reproduce tras un clic DENTRO de la pagina. Por eso play()
// desde PJSR no arranca el audio si el usuario aun no ha hecho ese primer gesto: `armed` lo dice. Encender es la lampara del dial
// (y, en el panel EMISORAS, el boton ⏻); despues del primer gesto, play() desde PJSR si enciende.
// (R5, 12-nov) opts.autostart: AL ABRIR queda ENCENDIDA y sintonizada (S2 de fabrica, o lo que dejo el usuario: startPower / startStation) pero muda hasta
// el primer clic o tecla DENTRO del dial. Medido que sin gesto no hay audio posible (tests/radio/r5_autostart_pi.js): README «Autoplay».
// ES5. Sin «barra asterisco» ni «asterisco barra» en el fichero (el preprocesador de PJSR).
// ============================================================================

#include <pjsr/DataType.jsh>

var FV_RADIO_VERSION = "G1";
var FV_RADIO_GEN = 10;                             // emisoras de a bordo (FVMusic.n; la pagina lo confirma al cargar)
var FV_RADIO_EXT = ["mp3", "ogg", "oga", "opus", "wav", "flac"];       // lo que lista «Mi musica» (MEDIDO solo mp3; el resto, Chromium)
var FV_RADIO_SETTINGS = "FieldVoyager/radio/";
var FV_RADIO_DEFAULT = "S2";                       // (R5) la emisora de fabrica al abrir: Campo profundo / Deep Field
// (19-nov, M1; Nino: «haz que la musica empiece cuando se pulsa el mando de Potentia») ON: con autostart, la radio NO se enciende al abrir la nave
// sino al tirar de POTENTIA (fvdialog.power() -> radio.startNow()): la de antes nacia encendida y muda, de modo que un clic en el dial ANTES de
// POTENTIA la hacia sonar con la nave aun apagada. El primer gesto dentro del dial sigue siendo imprescindible en PixInsight (el motor web no deja
// sonar sin el: README «Autoplay», medido en R5), asi que el tiron de POTENTIA, que cae en la vista 3D, solo puede encenderla; suena en ese instante
// si el dial ya recibio un gesto, y si no, en el primer clic o tecla en el dial (el aviso de la franja lo pide, P14). startPower «off» (apagada
// por ella) se respeta. false = lo de antes (encendida y muda desde que abre la nave)
var FV_M1 = { ON: true };

// ---------------------------------------------------------------------------
// utilidades puras
// ---------------------------------------------------------------------------
function fvRadioNorm(p) { return String(p || "").split("\\").join("/"); }
function fvRadioExt(name) { var m = String(name).lastIndexOf("."); return m < 0 ? "" : String(name).substring(m + 1).toLowerCase(); }
function fvRadioBase(name) { var n = String(name), s = n.lastIndexOf("/"); if (s >= 0) n = n.substring(s + 1); var d = n.lastIndexOf("."); return d > 0 ? n.substring(0, d) : n; }
function fvRadioIsAudio(name) { var e = fvRadioExt(name); for (var i = 0; i < FV_RADIO_EXT.length; ++i) if (FV_RADIO_EXT[i] === e) return true; return false; }
// ruta del disco -> URL file:///... (cada tramo con encodeURIComponent; la «C:» no)
function fvRadioFileUrl(path) {
   var p = fvRadioNorm(path), seg = p.split("/"), out = [];
   for (var i = 0; i < seg.length; ++i) out.push((i === 0 && /^[A-Za-z]:$/.test(seg[i])) ? seg[i] : encodeURIComponent(seg[i]));
   var s = out.join("/");
   return "file:" + "//" + (s.charAt(0) === "/" ? "" : "/") + s;
}
function fvRadioThisDir() {
   try { return (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/"); } catch (e) { return ""; }
}
function fvRadioListAudio(dir) {
   var out = [], d = fvRadioNorm(dir).replace(/[/]+$/, ""), ff = new FileFind;
   try {
      if (ff.begin(d + "/" + "*")) { do { if (ff.isDirectory !== true && fvRadioIsAudio(ff.name)) out.push(ff.name); } while (ff.next()); }
      try { ff.end(); } catch (e2) {}
   } catch (e) {}
   out.sort(function(a, b) { var x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : x > y ? 1 : 0; });
   return out;
}
// LA INTENSIDAD QUE PIDE EL VIAJE (0-1) a las emisoras de a bordo, del estado del piloto P (fv_pilot.js); la usa la cabina con
// radio.level(). Mas en el warp y el crucero, calma al llegar y en casa. Pura: la prueban tests/radio sin PixInsight.
//   warp: prep 0,7 · salto/aliento/destello 0,9 · crucero 1 · salida 0,75 · cine/ir a: arranque 0,55 · crucero 0,75 · ultimo 25 % de 0,75 a 0,35
//   parado: en casa o con ficha 0,35 · vuelo libre 0,5
function fvRadioLevelFor(P, cardOpen) {
   if (!P) return 0.35;
   var fl = P.flight;
   if (fl && (fl.kind === "warp" || fl.gwHome === true)) {
      var wp = fl.warpPhase || fl.phase || "";
      if (wp === "prep" || wp === "depart") return 0.7;
      if (wp === "jump" || wp === "breath" || wp === "flash") return 0.9;
      if (wp === "cruise") return 1.0;
      return 0.75;
   }
   if (fl) {
      var u = Math.max(0, Math.min(1, fl.t / Math.max(0.01, fl.dur || 1)));
      if (u >= 0.75) return 0.75 - 0.4 * (u - 0.75) / 0.25;
      return u < 0.2 ? 0.55 : 0.75;
   }
   var home = !!(P.cam && P.cam.pos && Math.abs(P.cam.pos[0]) + Math.abs(P.cam.pos[1]) + Math.abs(P.cam.pos[2]) < 1e-6);
   return (home || cardOpen) ? 0.35 : 0.5;
}

// ---------------------------------------------------------------------------
// FVRadio
// ---------------------------------------------------------------------------
function FVRadio(parent, opts) {
   var self = this;
   opts = opts || {};
   this.opts = opts;
   this.lang = (opts.lang === "es") ? "es" : "en";
   this.key = opts.settingsKey || FV_RADIO_SETTINGS;
   this.vol = (typeof opts.volume === "number") ? opts.volume : this._readNum("volume", 0.7);
   // opts.mute: la radio no suena pero el mando de volumen se queda donde diga opts.volume (las capturas de prueba)
   this.mute = opts.mute === true;
   this.folder = (typeof opts.folder === "string") ? fvRadioNorm(opts.folder) : this._readStr("folder", "");
   this.station = (typeof opts.station === "string") ? opts.station : this._readStr("station", "");
   // (R5, 12-nov) AL ABRIR: opts.autostart = true deja la radio ENCENDIDA y sintonizada (de fabrica, la emisora FV_RADIO_DEFAULT = S2) sin que el
   // usuario haga nada; el sonido empieza con el primer gesto DENTRO de su pagina (el motor web no deja antes: README). La memoria de arranque
   // son dos claves PROPIAS que solo escribe una persona (lampara, ⏻, Espacio, dial, rueda, tecla, nombre del cajon), no PJSR:
   //   startPower   «on» | «off»   (apagarla la deja apagada al reabrir; encenderla, encendida)
   //   startStation  S1…S10 | mine  (la ultima emisora que ELIGIO; si ya no existe, la de fabrica)
   // `station` (la de siempre, la escribe cada sintonia) ya no decide el arranque: estaba sucia de pruebas y de la S1 automatica de antes.
   this.autostart = opts.autostart === true;
   this.holdStart = this.autostart && opts.holdStart === true;                       // (M1) el autostart espera a startNow() (el tiron de POTENTIA)
   this.pageLoaded = false; this.startedAt = null;
   // (19-nov, I5; E1-18 y E1-19) «sonido que informa»: el interruptor del cajon de la radio (Settings .../radio/inform: on|off; de fabrica encendido con FV_E1A.ON). La pagina lo recuerda
   // y avisa de los cambios de una persona (evento "inform"); inform() NO hace nada con la radio apagada o muda, sin FV_E1A o con el interruptor en off
   this.e1a = (typeof FV_E1A !== "undefined" && FV_E1A.ON === true && opts.e1a !== false);
   this.informOn = this._readStr("inform", "") !== "off"; this.informLog = []; this.informSent = 0;
   this._dst = (typeof fvE1aNew === "function") ? fvE1aNew() : null;                  // solo para los reintentos de fvE1aDefer / fvE1aRetry
   this.startPower = (typeof opts.startPower === "string") ? opts.startPower : this._readStr("startPower", "");
   this.startStation = (typeof opts.startStation === "string") ? opts.startStation : this._readStr("startStation", "");
   this.folderFiles = []; this.folderErr = "";
   this.genCount = FV_RADIO_GEN; this.engine = "";
   this.onStationTuned = null; this.onStationLost = null; this.onStatus = null; this.onError = null; this.onPower = null; this.onReady = null; this.onClosePanel = null;
   this.onArmChange = null; this.onNudgeCancel = null;                   // (R3-arreglos) el audio dejo de sonar / volvio; el aviso pedido ya no cabe (la pagina lo rechazo tras recargarse)
   this._nudgeUntil = 0;                                                 // (R3-arreglos H6) hasta cuando (Date.now) dura el aviso pedido: si la pagina se recarga, se le reenvia lo que quede
   this.armed = false; this.on = false; this.ready = false; this.current = null; this.failed = ""; this.disposed = false; this.lvl = null;
   this.log = (typeof opts.log === "function") ? opts.log : function() {};
   this._tag = 0; this._pend = {}; this._polling = false; this._events = [];
   this.dir = opts.dir ? fvRadioNorm(opts.dir) : fvRadioThisDir();
   this.pagePath = this._findPage();
   this.view = new WebView(parent);
   this.control = this.view;                                 // el control que la cabina mete en su layout
   try { this.view.setScaledMinSize(opts.minWidth || 420, opts.minHeight || 250); } catch (eS) { try { this.view.setMinSize(opts.minWidth || 420, opts.minHeight || 250); } catch (eS2) {} }
   this.view.onScriptResultAvailable = function(v) { self._onResult(v); };
   this.view.onLoadFinished = function(ok) { self._onLoaded(ok); };
   this.timer = new Timer; this.timer.interval = 0.2; this.timer.periodic = true;
   this.timer.onTimeout = function() { self._poll(); };
   this.refresh(true);
   if (this.pagePath.length === 0) { this.failed = "page fv_radio.html not found (looked in " + this.dir + ")"; this._fail(this.failed); }
   else {
      if (!File.exists(this.pagePath.replace(/fv_radio\.html$/, "fv_music.js"))) this.log("radio: fv_music.js is missing next to the page: only «My music» can play");
      this.view.loadContent(fvRadioFileUrl(this.pagePath)); this.timer.start();
   }
}

FVRadio.prototype._findPage = function() {
   var c = [this.opts.pageFile, this.dir + "/fv_radio.html", this.dir + "/radio/fv_radio.html", this.dir + "/src/radio/fv_radio.html"];
   for (var i = 0; i < c.length; ++i) { if (!c[i]) continue; var p = fvRadioNorm(c[i]); try { if (File.exists(p)) return p; } catch (e) {} }
   return "";
};
// la emisora con la que se abre: la que ELIGIO la ultima vez si sigue en el dial, y si no, la de fabrica
FVRadio.prototype._startId = function() {
   var id = this.startStation;
   if (id.length > 0) { var l = this.stationList(); for (var i = 0; i < l.length; ++i) if (l[i].id === id) return id; }
   return FV_RADIO_DEFAULT;
};
FVRadio.prototype._readStr = function(name, dflt) {
   try { var v = Settings.read(this.key + name, DataType_String); if (Settings.lastReadOK !== false && v !== null && v !== undefined) return String(v); } catch (e) {}
   return dflt;
};
FVRadio.prototype._readNum = function(name, dflt) { var s = this._readStr(name, ""); var n = parseFloat(s); return (s.length > 0 && isFinite(n)) ? n : dflt; };
FVRadio.prototype._write = function(name, value) { try { Settings.write(this.key + name, DataType_String, String(value)); return true; } catch (e) { return false; } };
FVRadio.prototype._say = function(text, kind) {
   this.log("radio: " + text);
   if (this.ready) this._eval("__fvr.notify(" + this._js(text) + "," + this._js(kind || "") + ")");
   if (typeof this.onStatus === "function") { try { this.onStatus(text, kind || ""); } catch (e) {} }
};
FVRadio.prototype._fail = function(text) {
   this.log("radio ERROR: " + text);
   if (typeof this.onError === "function") { try { this.onError(text); } catch (e) {} }
};
FVRadio.prototype._js = function(v) { return JSON.stringify(v).split("\u2028").join("\\u2028").split("\u2029").join("\\u2029"); };

// --- el canal con la pagina: cada llamada lleva una etiqueta y su respuesta vuelve en onScriptResultAvailable ---
FVRadio.prototype._eval = function(code, cb) {
   if (this.disposed) return;
   var tag = ++this._tag; this._pend[tag] = cb || null;
   var js = "(function(){var r;try{r=(" + code + ");}catch(e){r={__err:String(e)};}return JSON.stringify({t:" + tag + ",r:(r===undefined?null:r)});})()";
   try { this.view.evaluateScript(js); } catch (e) { delete this._pend[tag]; this._fail("evaluateScript: " + e); }
};
FVRadio.prototype._onResult = function(v) {
   var o = null;
   try { o = JSON.parse(String(v)); } catch (e) { return; }
   if (!o || o.t === undefined) return;
   var cb = this._pend[o.t]; delete this._pend[o.t];
   // (R5) si falla el sondeo de la cola (p. ej. la pagina recargandose: «__fvr is not defined»), se libera: antes quedaba _polling = true y la radio dejaba de oir a la pagina
   if (o.r && o.r.__err) { if (o.t === this._pollTag) { this._polling = false; this._pollTag = 0; } this._fail("page: " + o.r.__err); return; }
   if (typeof cb === "function") { try { cb(o.r); } catch (e2) { this._fail("callback: " + e2); } }
};
FVRadio.prototype._onLoaded = function(ok) {
   if (this.disposed) return;
   if (!ok) { this.failed = "the radio page did not load: " + this.pagePath; this._fail(this.failed); return; }
   var self = this;
   this.armed = false;                                       // (R3-arreglos H6) una pagina recien cargada nace muda, sea lo que fuere lo que decia la anterior
   this.pageLoaded = true;
   var go = this.autostart && this.startPower !== "off" && !this.holdStart;
   var st0 = this.autostart ? this._startId() : this.station;
   this._eval("__fvr.init({lang:" + this._js(this.lang) + ",volume:" + this.vol + ",mute:" + (this.mute ? "true" : "false") + ",station:" + this._js(st0) + ",autostart:" + (go ? "true" : "false") + ",e1a:" + (this.e1a ? "true" : "false") + ",inform:" + (this.informOn ? "true" : "false") + "})", function(r) {
      self.ready = true;
      if (r && r.n > 0) self.genCount = r.n;
      self.engine = (r && r.engine) ? r.engine : "";
      if (!self.engine) self._fail("the music engine (fv_music.js) did not load in the page");
      self._pushAll();
      if (self.lvl !== null) self._eval("__fvr.setLevel(" + self.lvl + ")");
      // (R3-arreglos H6, 14-nov) recarga EN MITAD del aviso: la pagina nace sin el (nudgeUntil 0) pero la franja sigue avisando; se le reenvia lo que quede, y si ya no cabe
      // (apagada, o sonando) se cancela tambien en la franja: los dos lados dicen siempre lo mismo
      var rem = (self._nudgeUntil - Date.now()) / 1000;
      if (rem > 0.2) self._eval("__fvr.nudge(" + rem.toFixed(2) + ")", function(okN) { if (okN !== true) self.cancelNudge(); });
      else if (self._nudgeUntil) self.cancelNudge();
      self.log("radio: page ready (" + self.pagePath + ") · engine " + (self.engine || "none") + " · " + self.genCount + " stations");
      if (typeof self.onReady === "function") { try { self.onReady(); } catch (e) {} }
   });
};
// lo que la pagina deja en su cola (sintonias, errores, mandos, ordenes de los botones)
FVRadio.prototype._poll = function() {
   if (this._dst && typeof fvE1aRetry === "function") { var dEv = fvE1aRetry(this._dst, Date.now() / 1000); if (dEv) this.inform(dEv); }      // (I5) reintento de un motivo atenuado
   if (!this.ready || this._polling || this.disposed) return;
   var self = this; this._polling = true;
   this._eval("__fvr.drain()", function(list) {
      self._polling = false; self._pollTag = 0;
      if (!list) return;
      for (var i = 0; i < list.length; ++i) self._handle(list[i]);
   });
   this._pollTag = this._tag;
};
FVRadio.prototype._handle = function(e) {
   this._events.push(e); if (this._events.length > 200) this._events.shift();
   if (e.type === "tuned") {
      this.current = { id: e.id, kind: e.kind, station: e.station, title: e.title, author: e.author, license: e.license, position: e.position, key: e.key, bpm: e.bpm, user: e.user === true };    // user: la eligio una persona (rueda, mando, tecla), no PJSR ni el autostart
      if (e.kind === "gen") { this.station = e.id; this._write("station", e.id); }
      if (e.user === true) { this.startStation = e.id; this._write("startStation", e.id); }          // (R5) solo lo que elige una persona
      this.log("radio: tuned " + e.id + " · " + e.title + " · " + e.author + " · " + e.license);
      if (typeof this.onStationTuned === "function") { try { this.onStationTuned(this.current); } catch (e1) {} }
   } else if (e.type === "detuned") {
      this.current = null; if (typeof this.onStationLost === "function") { try { this.onStationLost(); } catch (e2) {} }
   } else if (e.type === "power") {
      this.on = !!e.on; this.armed = !!e.armed;
      if (!this.on) this.current = null;
      if (this.armed || !this.on) this.cancelNudge();            // (R3-arreglos H6) suena o apagada: el aviso pedido ya no procede, ni aqui ni en la franja
      this.log("radio: power " + (e.on ? "on" : "off") + " (armed " + e.armed + (e.user ? ", by the user" : "") + ")");
      if (e.user === true) { this.startPower = e.on ? "on" : "off"; this._write("startPower", this.startPower); }       // (R5) la radio se abre como la dejo
      if (typeof this.onPower === "function") { try { this.onPower(this.on); } catch (e3) {} }
   } else if (e.type === "armed") {
      this.armed = true; this.cancelNudge(); this.log("radio: armed (" + (e.back ? "the audio is running again" : "first gesture inside the page") + ")");
      if (typeof this.onArmChange === "function") { try { this.onArmChange(true); } catch (e6) {} }
   } else if (e.type === "disarmed") {            // (R3-arreglos H2) el contexto de audio se suspendio tras sonar: vuelve a estar «encendida y muda»
      this.armed = false; this.log("radio: DISARMED (the audio context went " + e.ctx + "; a click on the dial resumes it)");
      if (typeof this.onArmChange === "function") { try { this.onArmChange(false); } catch (e7) {} }
   } else if (e.type === "inform") {
      this.informOn = !!e.on; this._write("inform", e.on ? "on" : "off"); this.log("radio: sound that informs " + (e.on ? "on" : "off"));
   } else if (e.type === "volume") {
      this.vol = e.v; this._write("volume", e.v);
   } else if (e.type === "error") {
      this.log("radio page error: " + e.code + " " + (e.msg || ""));
      if (typeof this.onError === "function") { try { this.onError(e.code + ": " + (e.msg || "")); } catch (e4) {} }
   } else if (e.type === "command") {
      if (e.name === "chooseFolder") this.chooseFolder();
      else if (e.name === "closePanel" && typeof this.onClosePanel === "function") { try { this.onClosePanel(); } catch (e5) {} }      // el aspa del panel
   }
};

// --- lo que ve la pagina: las emisoras de a bordo las pone ella; desde aqui solo «Mi musica» ---
FVRadio.prototype._es = function(en, es) { return this.lang === "es" ? es : en; };
FVRadio.prototype._extraStations = function() {
   var out = [];
   if (this.folder.length > 0 && this.folderFiles.length > 0) {
      var tracks = [], base = this.folder.replace(/[/]+$/, "");
      for (var i = 0; i < this.folderFiles.length; ++i) tracks.push({ title: fvRadioBase(this.folderFiles[i]), url: fvRadioFileUrl(base + "/" + this.folderFiles[i]) });
      out.push({ id: "mine", kind: "list", title: this._es("My music", "Mi música"), author: fvRadioBase(base) || base, license: this._es("your own music", "tu propia música"), tracks: tracks });
   }
   return out;
};
// todas las emisoras del dial: { id, kind } (las de a bordo: S1…S10, kind "gen")
FVRadio.prototype.stationList = function() {
   var out = [];
   for (var i = 0; i < this.genCount; ++i) out.push({ id: "S" + (i + 1), kind: "gen" });
   return out.concat(this._extraStations());
};
FVRadio.prototype._pushAll = function() {
   if (!this.ready) return;
   this._eval("__fvr.setFolder(" + this._js(this.folder) + "," + this._js(this.folderFiles) + "," + this._js(this.folderErr) + ")");
   this._eval("__fvr.setStations(" + this._js(this._extraStations()) + ")");
};

// --- «Mi musica»: la carpeta del usuario ---
FVRadio.prototype.setMusicFolder = function(path) {
   var p = fvRadioNorm(path).replace(/[/]+$/, "");
   this.folderErr = "";
   if (p.length === 0) { this.folder = ""; this.folderFiles = []; this._write("folder", ""); this._pushAll(); return true; }
   if (!File.directoryExists(p)) { this.folderErr = this._es("that folder does not exist", "esa carpeta no existe"); this._say(this.folderErr + ": " + p, "bad"); this._pushAll(); return false; }
   this.folder = p; this.folderFiles = fvRadioListAudio(p); this._write("folder", p);
   this.log("radio: folder " + p + " · " + this.folderFiles.length + " audio files");
   this._pushAll();
   return true;
};
FVRadio.prototype.chooseFolder = function() {
   try { if (typeof cshInteractive === "function" && !cshInteractive()) { this._say("no folder dialog in non-interactive mode", "bad"); return false; } } catch (e0) {}
   var gdd = new GetDirectoryDialog;
   gdd.caption = this._es("FieldVoyager radio: choose your music folder", "Radio de FieldVoyager: elige tu carpeta de música");
   try { if (this.folder.length > 0) gdd.initialPath = this.folder; } catch (e) {}
   if (!gdd.execute()) return false;
   return this.setMusicFolder(String(gdd.directoryPath));
};
FVRadio.prototype.refresh = function(quiet) {
   if (this.folder.length > 0) { this.folderFiles = File.directoryExists(this.folder) ? fvRadioListAudio(this.folder) : []; if (!File.directoryExists(this.folder)) this.folderErr = this._es("that folder does not exist", "esa carpeta no existe"); }
   if (!quiet) this._pushAll();
};

// --- el mando a distancia desde PJSR ---
FVRadio.prototype.play = function() { this._eval("__fvr.power(true)"); return this.armed; };     // false mientras no haya habido el primer clic en la pagina
FVRadio.prototype.stop = function() { this._eval("__fvr.power(false)"); };
// (M1) el tiron de POTENTIA: suelta el autostart retenido (enciende y sintoniza lo que ella dejo, o la S2). Una sola vez. -> true si lo solto ahora
FVRadio.prototype.startNow = function() {
   if (!this.holdStart) return false;
   this.holdStart = false; this.startedAt = Date.now();
   if (this.startPower === "off") { this.log("radio: POTENTIA pulled, the radio was left off by the user: stays off"); return false; }
   if (this.pageLoaded) this._eval("__fvr.init({lang:" + this._js(this.lang) + ",volume:" + this.vol + ",mute:" + (this.mute ? "true" : "false") + ",station:" + this._js(this._startId()) + ",autostart:true})");
   this.log("radio: POTENTIA pulled: radio on" + (this.pageLoaded ? "" : " (as soon as the page loads)") + ", station " + this._startId() + (this.armed ? ", sounds now" : ", mute until the first gesture inside the dial"));
   return true;
};
// (P14, 14-nov) aviso «pulsa el dial»: la lampara respira mas y el bisel brilla `sec` s (la pagina solo lo hace si esta encendida y muda). Cuenta los avisos en this.nudges (pruebas)
FVRadio.prototype.nudge = function(sec) { this.nudges = (this.nudges || 0) + 1; this._nudgeUntil = Date.now() + 1000 * (Number(sec) || 0); this._eval("__fvr.nudge(" + (Number(sec) || 0) + ")"); };
// (R3-arreglos H6) el aviso ya no procede (la pagina lo rechazo): se olvida aqui y se avisa a quien pinta el rotulo
FVRadio.prototype.cancelNudge = function() { this._nudgeUntil = 0; if (typeof this.onNudgeCancel === "function") { try { this.onNudgeCancel(); } catch (e) {} } };
// (19-nov, I5; E1-18 y E1-19) le dice a la pagina un hecho que suena: ev = { kind: "star" | "pass", teff } o { kind: "motif", name }. No hace nada (y lo dice en informLog) con
// FV_E1A apagada, la radio apagada o muda (aun sin el primer gesto en el dial), o el interruptor en off. La pagina decide el resto (emisora de a bordo, atenuacion,
// enfriamiento) y devuelve { played, why }. -> true si se envio a la pagina
FVRadio.prototype.inform = function(ev) {
   var self = this, why = "";
   if (!this.e1a) why = "off"; else if (!this.ready) why = "not-ready"; else if (!this.on) why = "radio-off"; else if (!this.informOn) why = "switch-off"; else if (!this.armed) why = "muted";
   if (why) { this._informNote({ kind: ev ? ev.kind : "", played: false, why: why }); return false; }
   ++this.informSent;
   this._eval("__fvr.inform(" + this._js(ev) + ")", function(r) {
      r = r || { kind: ev.kind, played: false, why: "no-answer" }; self._informNote(r);
      if (typeof fvE1aDefer === "function" && self._dst) fvE1aDefer(self._dst, ev, r, Date.now() / 1000);          // un motivo atenuado (silencio de llegada) se reintenta
   });
   return true;
};
FVRadio.prototype._informNote = function(r) { this.informLog.push(r); if (this.informLog.length > 100) this.informLog.shift(); if (r.played) this.log("radio: inform " + r.kind + (r.note ? " " + r.note : "") + (r.name ? " " + r.name : "")); };
// el interruptor desde PJSR (la persona lo cambia en el cajon de la radio; esto es para pruebas y ajustes)
FVRadio.prototype.setInform = function(b) { this.informOn = !!b; this._write("inform", this.informOn ? "on" : "off"); this._eval("__fvr.setInform(" + (this.informOn ? "true" : "false") + ")"); return this.informOn; };
FVRadio.prototype.tune = function(x) { this._eval("__fvr.tune(" + this._js(x) + ")"); };
FVRadio.prototype.volume = function(v) { v = Math.max(0, Math.min(1, Number(v))); this.vol = v; this._write("volume", v); this._eval("__fvr.setVolume(" + v + ")"); };
// la intensidad que pide el viaje (0-1) a las emisoras de a bordo; null = solo la composicion. Temporal (no se guarda).
FVRadio.prototype.level = function(v) {
   this.lvl = (v === null || v === undefined || !isFinite(v)) ? null : Math.max(0, Math.min(1, Number(v)));
   if (this.ready) this._eval("__fvr.setLevel(" + (this.lvl === null ? "null" : this.lvl) + ")");
   return this.lvl;
};
FVRadio.prototype.setLang = function(l) { this.lang = (l === "es") ? "es" : "en"; this._eval("__fvr.setLang(" + this._js(this.lang) + ")"); this._pushAll(); };
FVRadio.prototype.openList = function(b) { this._eval("__fvr.openDrawer(" + (b ? "true" : "false") + ")"); };
FVRadio.prototype.snapshot = function(cb) { this._eval("__fvr.snap()", cb); };
FVRadio.prototype.query = function(code, cb) { this._eval(code, cb); };                 // (pruebas)
// (pasada N, cine §10.4) atenuacion TEMPORAL (no se guarda en Settings, a diferencia de volume): factor f en `seconds` s y paso bajo a
// `lowpassHz` (por defecto 18 kHz = abierto) sobre la estatica y la musica de a bordo. Se apunta en this.duckLog (las pruebas lo leen).
FVRadio.prototype.duck = function(f, seconds, lowpassHz) {
   f = Math.max(0, Math.min(1, Number(f))); var s = Math.max(0, Number(seconds) || 0), hz = (lowpassHz > 0) ? Number(lowpassHz) : 18000;
   this.duckF = f; this.duckLp = hz;
   if (!this.duckLog) this.duckLog = [];
   this.duckLog.push({ t: Date.now(), f: f, s: s, hz: hz }); if (this.duckLog.length > 400) this.duckLog.shift();
   this._eval("__fvr.duck(" + f + "," + s + "," + hz + ")");
   return f;
};
FVRadio.prototype.dispose = function() {
   this.disposed = true;
   try { this.timer.stop(); } catch (e) {}
   try { this.view.onScriptResultAvailable = null; this.view.onLoadFinished = null; } catch (e2) {}
   try { this.view.stop(); } catch (e3) {}
};
