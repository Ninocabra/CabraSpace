// ============================================================================
// FieldVoyager/src/science/fv_sci_scale.js — CUMULOS Y NEBULOSAS: TAMAÑO FISICO Y FRASES DE ESCALA (3-nov-2026)
// ----------------------------------------------------------------------------
// Unidades: angulos en minutos de arco; distancias en años luz; tamaños en al, pc y au.
//   · Tamaño fisico desde el angular: D = 2·d·tan(θ/2) (geometria; para θ pequeño, D ≈ d·θ).
//   · «Sistemas Solares que caben»: el Sistema Solar se toma hasta la ORBITA DE NEPTUNO (diametro 2 × 30,07 au, semieje
//     del JPL) — es el que cualquiera tiene en la cabeza. Tambien se da con la heliopausa (Voyager 1 la cruzo a 121,6 au
//     del Sol en agosto de 2012, NASA/JPL: diametro ~243 au). Caben N en fila (cociente de diametros) y N³ en volumen
//     (cociente de volumenes de esferas).
//   · Modo realista, el Sol como un grano de ARENA de 1 mm (arena: granos de 0,0625 a 2 mm, escala de Wentworth 1922):
//     factor = 1 mm / diametro del Sol (2·R☉ nominal IAU 2015). La estrella mas cercana, Proxima Centauri (Gaia DR3,
//     ϖ = 768,0665 mas → 4,2465 al), queda a ~29 km. Todo se calcula con las constantes de fv_sci_const.js.
// ES5. Sin PixInsight.
// ============================================================================

var FVS_SAND_GRAIN_M = 1e-3;                                         // 1 mm
var FVS_SS_DIAM_AU = 2 * 30.07;                                      // hasta la orbita de Neptuno
var FVS_HELIOPAUSE_DIAM_AU = 2 * 121.6;                              // heliopausa (cruce de la Voyager 1)

// Diametro fisico (al) desde el diametro angular (arcmin) y la distancia (al)
function fvsPhysSizeLy(angArcmin, dLy) { return 2 * dLy * Math.tan(angArcmin / 60 * Math.PI / 180 / 2); }
// Diametro angular (arcmin) que tendria un objeto de D al visto a d al
function fvsAngSizeArcmin(sizeLy, dLy) { return 2 * Math.atan(sizeLy / (2 * dLy)) * 180 / Math.PI * 60; }

// Escala de un objeto extenso. → { diamLy, diamPc, diamAU, solarSystemsAcross, solarSystemsVolume, heliosAcross,
//                                   lightCrossYears, voyagerCrossYears }
function fvsObjectScale(angArcmin, dLy) {
   var D = fvsPhysSizeLy(angArcmin, dLy), au = D * FVS.LY_AU, nss = au / FVS_SS_DIAM_AU;
   var vVoy = FVS.VOYAGER1_KMS * 1000 / FVS.C_MS;                    // β de la Voyager 1
   return { diamLy: D, diamPc: D / FVS.PC_LY, diamAU: au, solarSystemsAcross: nss, solarSystemsVolume: nss * nss * nss,
            heliosAcross: au / FVS_HELIOPAUSE_DIAM_AU, lightCrossYears: D, voyagerCrossYears: D / vVoy };
}

// El Sol como un grano de arena: → { factor, sunMm, earthOrbitM, neptuneOrbitM, proximaKm, objectKm (si se da dLy),
//                                    objectSizeKm (si se da sizeLy) }
function fvsSandScale(dLy, sizeLy) {
   var f = FVS_SAND_GRAIN_M / (2 * FVS.RSUN_M);
   var o = { factor: f, sunMm: 1, earthOrbitM: FVS.AU_M * f, neptuneOrbitM: 30.07 * FVS.AU_M * f,
             proximaKm: FVS.PROXIMA_LY * FVS.LY_M * f / 1000 };
   if (dLy > 0) o.objectKm = dLy * FVS.LY_M * f / 1000;
   if (sizeLy > 0) o.objectSizeKm = sizeLy * FVS.LY_M * f / 1000;
   return o;
}
