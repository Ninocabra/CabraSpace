// ============================================================================
// FieldVoyager/src/science/fv_sci_travel.js — EL VIAJE: RELATIVIDAD, COHETE A 1 g, ESCALA WARP Y EL FACTOR DE
// IMPROBABILIDAD (3-nov-2026)
// ----------------------------------------------------------------------------
// Unidades: distancias en años luz; velocidades como β = v/c; tiempos en años (julianos).
// Fisica real:
//   · Velocidad constante: t_Tierra = d/β; t_a_bordo = t_Tierra/γ, γ = 1/√(1 − β²) (relatividad especial; Einstein 1905).
//   · Cohete con aceleracion PROPIA constante a, acelerando media ruta y frenando la otra media (formulas de «The
//     Relativistic Rocket», P. Gibbs 1996-1998 / D. Koks 2004, FAQ de fisica de Usenet en math.ucr.edu/home/baez):
//     por cada mitad x = d/2: τ = (c/a)·arccosh(a·x/c² + 1) a bordo, t = √((x/c)² + 2x/a) en la Tierra,
//     β_max = tanh(a·τ/c). Su tabla a 1 g: 4,3 al → 3,6 años; 27 al → 6,6; 30 000 al → 20; 2 000 000 al → 28 (la prueba
//     la reproduce).
// FICCION (se dice en la interfaz; nada de esto es fisica):
//   · Escala WARP de Star Trek: La Nueva Generacion (TNG): v/c = w^(10/3) para w ≤ 9, y tiende a infinito en w = 10
//     («warp 10 = velocidad infinita»). Fuente de la regla y de los puntos: Okuda & Okuda, «Star Trek Encyclopedia», p. 413
//     (warp 9,9 = 3053 c; warp 9,99 = 7912 c) y Okuda & Okuda, «Star Trek Technical Manual», p. 55, tal como las cita
//     Wikipedia «Warp drive» (leida el 3-nov-2026). El manual NO da formula entre 9 y 10, solo la curva: aqui se usa un
//     AJUSTE NUESTRO que empalma en w = 9 y pasa EXACTAMENTE por los dos puntos citados:
//         v/c = w^(10/3 + A·(−ln(10 − w))^N),   A = 0,0382…, N = log2(3,4) = 1,7655…  (A y N se calculan abajo)
//     (los exponentes de los dos puntos salen 3,5000 y 3,9000: de ahi el 2^N = 3,4). Warp 9 = 9^(10/3) = 1516,4 c.
//   · Escala de La Serie Original (TOS): v/c = w³ (la «progresion cubica» de Franz Joseph; sin limite).
//   · Factor de improbabilidad (guiño a la «Guía del autoestopista galáctico» de Douglas Adams): SOLO texto de humor,
//     un numero sin significado fisico. Ver fvsImprobability.
// ES5. Sin PixInsight.
// ============================================================================

function fvsAcosh_(x) { return Math.log(x + Math.sqrt(x * x - 1)); }
function fvsTanh_(x) { var e = Math.exp(2 * x); return (e === Infinity) ? 1 : (e - 1) / (e + 1); }

// Viaje a velocidad constante β: → { earthYears, shipYears, gamma }
function fvsTravelConstant(dLy, beta) {
   if (!(beta > 0 && beta < 1)) return { earthYears: NaN, shipYears: NaN, gamma: NaN };
   var g = 1 / Math.sqrt(1 - beta * beta), te = dLy / beta;
   return { earthYears: te, shipYears: te / g, gamma: g };
}
// Cohete con aceleracion propia constante (m/s², por defecto 1 g = 9,80665), acelerando y frenando:
// → { shipYears, earthYears, betaMax, gammaMax, accel }
function fvsTravelAccel(dLy, accel) {
   var a = (accel > 0) ? accel : FVS.G0_MS2, cOverA = FVS.C_MS / a / FVS.JYEAR_S;    // c/a en años
   var x = dLy / 2;                                                                   // al: x/c en años = x
   var aXc2 = x / cOverA;                                                             // a·x/c² (adimensional)
   var tauHalf = cOverA * fvsAcosh_(aXc2 + 1), tHalf = Math.sqrt(x * x + 2 * x * cOverA);
   var bmax = fvsTanh_(tauHalf / cOverA);
   return { shipYears: 2 * tauHalf, earthYears: 2 * tHalf, betaMax: bmax, gammaMax: aXc2 + 1, accel: a };
}

// ---------------- la escala warp (FICCION) ----------------
var FVS_WARP_REF = [[9.9, 3053], [9.99, 7912]];          // Star Trek Encyclopedia (Okuda), via Wikipedia «Warp drive»
var FVS_WARP_N = 0, FVS_WARP_A = 0;
(function () {
   // exceso de exponente sobre 10/3 en cada punto: e = ln(v)/ln(w) − 10/3 ; e = A·L^N con L = −ln(10 − w)
   var p = FVS_WARP_REF, e1 = Math.log(p[0][1]) / Math.log(p[0][0]) - 10 / 3, e2 = Math.log(p[1][1]) / Math.log(p[1][0]) - 10 / 3;
   var L1 = -Math.log(10 - p[0][0]), L2 = -Math.log(10 - p[1][0]);
   FVS_WARP_N = Math.log(e2 / e1) / Math.log(L2 / L1);
   FVS_WARP_A = e1 / Math.pow(L1, FVS_WARP_N);
})();
// v/c en la escala TNG. w ≥ 10 → Infinity; w ≤ 0 → 0.
function fvsWarpToC(w) {
   if (!(w > 0)) return 0;
   if (w >= 10) return Infinity;
   if (w <= 9) return Math.pow(w, 10 / 3);
   return Math.pow(w, 10 / 3 + FVS_WARP_A * Math.pow(-Math.log(10 - w), FVS_WARP_N));
}
// Factor warp TNG que da v/c (inversa por biseccion; v ≤ 1 → ≤ 1)
function fvsCToWarp(vc) {
   if (!(vc > 0)) return 0;
   var lo = 0, hi = 10;
   for (var i = 0; i < 80; ++i) { var m = 0.5 * (lo + hi); if (fvsWarpToC(m) < vc) lo = m; else hi = m; }
   return 0.5 * (lo + hi);
}
// Tiempo de viaje a warp w (años; sin dilatacion: en la ficcion el subespacio no la tiene)
function fvsWarpTravelYears(dLy, w) { var v = fvsWarpToC(w); return (v > 0) ? dLy / v : NaN; }

// ---------------- factor de improbabilidad (HUMOR, sin fisica) ----------------
// Un «2 elevado a N contra 1» que crece con la distancia, deterministico (el mismo destino da siempre el mismo numero).
// N = 276 709 · log10(1 + d)/log10(1 + 2 500 000) redondeado (el 276 709 es el guiño al libro; 2,5 millones de al ~ Andromeda).
function fvsImprobability(dLy) {
   var n = Math.round(276709 * Math.log(1 + Math.max(0, dLy)) / Math.log(1 + 2.5e6));
   return { power: Math.max(1, n), joke: true };
}
