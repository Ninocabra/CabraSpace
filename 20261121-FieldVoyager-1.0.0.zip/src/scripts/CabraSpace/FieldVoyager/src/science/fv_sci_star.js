// ============================================================================
// FieldVoyager/src/science/fv_sci_star.js — UNA ESTRELLA: TIPO, CLASE, MAGNITUD ABSOLUTA, LUMINOSIDAD, RADIO, MASA,
// VIDA EN LA SECUENCIA PRINCIPAL Y ZONA HABITABLE (3-nov-2026)
// ----------------------------------------------------------------------------
// Unidades: Teff en K; magnitudes en mag; paralaje en mas; L en L☉ (nominal IAU 2015, 3,828e26 W); R en R☉ (6,957e8 m);
// M en M☉; tiempos en años; distancias de la zona habitable en au.
// Fuentes (todas leidas el 3-nov-2026 salvo donde se diga):
//   · Tipo espectral de ENANAS: tabla de Mamajek 2022.04.16 (fv_sci_tables.js). De GIGANTES frias (clase III):
//     Dyck et al. 1998 (AJ 116, 981) Teff = −109·ST + 4570 K; de GIGANTES BRILLANTES Y SUPERGIGANTES frias (II, I):
//     van Belle, Creech-Eakman & Hart 2009 (MNRAS 394, 1925) ec. 2: Teff = −123·ST + 4724 K, con ST = −2…0…5, 6…14 para
//     G8…K0…K5, M0…M8 (las dos leidas en arXiv:0811.4239, §4.2). A una misma Teff, una gigante M es de un tipo mas TARDIO
//     que una enana: por eso el tipo depende de la clase.
//   · Clase de luminosidad: ESTIMACION NUESTRA desde la posicion en el diagrama HR (no es una clasificacion MK, que es
//     espectroscopica). Umbrales en FVS_LC con su porque. Las estrellas de la prueba se miraron al elegirlos: la prueba es
//     de coherencia, no una validacion independiente (ver README).
//   · Correccion bolometrica BC_G: Andrae et al. 2018 (A&A 616, A8, «Gaia DR2: first stellar parameters from Apsis»),
//     ec. 7 y Tabla 4, polinomio en (Teff − 5772 K), validos 4000-8000 K y 3300-4000 K, con su modelo de incertidumbre σ(BC)
//     y BC_G☉ = +0,06, M_bol☉ = 4,74 (Tabla 3). Leido en el PDF. Gaia DR3 (Creevey et al. 2023, A&A 674, A26, FLAME) usa
//     en cambio una REJILLA en Teff, log g, [M/H] y [α/Fe] (herramienta de ESA «Gaia DR3 G-band bolometric correction»);
//     aqui solo tenemos Teff, asi que se usa el polinomio de DR2. Fuera de 3300-8000 K: BC_G = BCv − (G−V) de Mamajek,
//     desplazada para empalmar sin salto con Andrae en 3300 y 8000 K (EXTRAPOLACION NUESTRA, se marca).
//   · Radio: Stefan-Boltzmann, L = 4πR²σT⁴ → R/R☉ = √(L/L☉)·(T☉/T)², con T☉ = 5772 K (IAU 2015 B3).
//   · Masa en secuencia principal: relacion masa-luminosidad por tramos (Salaris & Cassisi 2005, «Evolution of stars and
//     stellar populations», pp. 138-140; Duric 2004, «Advanced Astrophysics», p. 19; tal como la resume Wikipedia
//     «Mass–luminosity relation», leida el 3-nov-2026): L = 0,23·M^2,3 (M < 0,43) · M^4 (0,43-2) · 1,4·M^3,5 (2-55) ·
//     32 000·M (> 55). Validez practica medida en la prueba contra las masas de Mamajek: ±25 % de B0 a M5.
//   · Vida en la secuencia principal: t ≈ 10^10 años · (M/M☉)/(L/L☉) (escala de libro de texto: el combustible es ∝ M y se
//     gasta ∝ L; el Sol, ~10^10 años). Orden de magnitud: con un suelo de 3 Ma para las mas masivas (los modelos de Ginebra,
//     Ekström et al. 2012, dan ~3 Ma a 120 M☉; NO VERIFICADO en la fuente, por eso es solo un suelo).
//   · Zona habitable: Kopparapu et al. 2014 (ApJL 787, L29), ec. 4-5 y Tabla 1 para 1 M⊕ (leidos en el PDF de
//     arXiv:1404.5292): S_eff = S☉ + a·T★ + b·T★² + c·T★³ + d·T★⁴, T★ = Teff − 5780 K, d = √(L/S_eff) au,
//     valida 2600-7200 K. Conservadora: efecto invernadero desbocado → invernadero maximo. Optimista: Venus reciente →
//     Marte primitivo. Fuera de 2600-7200 K se calcula en el borde y se marca valid = false.
// ES5. Sin PixInsight.
// ============================================================================

// ---------------- tabla de Mamajek: interpolacion ----------------
// Columna: 1 Teff, 2 logL, 3 R, 4 M, 5 BCv, 6 G−V, 7 M_G. La tabla va de caliente a fria.
function fvsMamajekAt(teff, col) {
   var T = FVS_MAMAJEK, n = T.length;
   if (teff >= T[0][1]) return T[0][col];
   if (teff <= T[n - 1][1]) return T[n - 1][col];
   for (var i = 1; i < n; ++i) {
      if (teff >= T[i][1]) {
         var a = T[i - 1], b = T[i], va = a[col], vb = b[col];
         if (va === null || vb === null) return (va === null) ? vb : va;
         return vb + (teff - b[1]) / (a[1] - b[1]) * (va - vb);
      }
   }
   return T[n - 1][col];
}

// ---------------- correccion bolometrica BC_G ----------------
var FVS_BCG_ANDRAE = {
   hi: { bc: [6.000e-02, 6.731e-05, -6.647e-08, 2.859e-11, -7.197e-15], sd: [2.634e-02, 2.438e-05, -1.129e-09, -6.722e-12, 1.635e-15] },  // 4000-8000 K
   lo: { bc: [1.749e+00, 1.977e-03, 3.737e-07, -8.966e-11, -4.183e-14], sd: [-2.487e+00, -1.876e-03, 2.128e-07, 3.807e-10, 6.570e-14] }  // 3300-4000 K
};
function fvsPoly_(c, x) { return c[0] + x * (c[1] + x * (c[2] + x * (c[3] + x * c[4]))); }
// Andrae et al. 2018: { bc, sigma } o null fuera de 3300-8000 K
function fvsBcGAndrae(teff) {
   if (!(teff >= 3300 && teff <= 8000)) return null;
   var s = (teff >= 4000) ? FVS_BCG_ANDRAE.hi : FVS_BCG_ANDRAE.lo, x = teff - FVS.TSUN_K;
   return { bc: fvsPoly_(s.bc, x), sigma: Math.abs(fvsPoly_(s.sd, x)) };
}
// BC_G de la tabla de Mamajek = BCv − (G−V), interpolada en Teff (para las O3-B1, G−V = la de B1.5V: fv_sci_tables.js)
function fvsBcGMamajek(teff) {
   var T = FVS_MAMAJEK, n = T.length, rows = [];
   for (var i = 0; i < n; ++i) rows.push([T[i][1], T[i][5] - (T[i][6] === null ? FVS_MAMAJEK_HOT_GV : T[i][6])]);
   if (teff >= rows[0][0]) return rows[0][1];
   if (teff <= rows[n - 1][0]) return rows[n - 1][1];
   for (var j = 1; j < n; ++j) if (teff >= rows[j][0]) return rows[j][1] + (teff - rows[j][0]) / (rows[j - 1][0] - rows[j][0]) * (rows[j - 1][1] - rows[j][1]);
   return rows[n - 1][1];
}
// LA BC_G que se usa: Andrae dentro de 3300-8000 K; fuera, Mamajek empalmada. → { bc, sigma, src, extrapolated }
// σ fuera del polinomio: 0,10 mag en las calientes y 0,30 en las frias (cota NUESTRA; Andrae da hasta ±0,3 bajo 4000 K).
function fvsBcG(teff) {
   if (!(teff > 0)) return { bc: NaN, sigma: NaN, src: "none", extrapolated: true };
   var a = fvsBcGAndrae(teff);
   if (a) return { bc: a.bc, sigma: a.sigma, src: "andrae2018", extrapolated: false };
   var edge = (teff > 8000) ? 8000 : 3300, off = fvsBcGAndrae(edge).bc - fvsBcGMamajek(edge);
   var out = (teff > FVS_MAMAJEK[0][1]) || (teff < FVS_MAMAJEK[FVS_MAMAJEK.length - 1][1]);
   return { bc: fvsBcGMamajek(teff) + off, sigma: (teff > 8000) ? 0.10 : 0.30, src: (teff > 8000) ? "mamajek-hot" : "mamajek-cool", extrapolated: true, outOfTable: out };
}

// ---------------- magnitudes, luminosidad, radio ----------------
// Magnitud absoluta desde la aparente m, la paralaje (mas) y la extincion A (mag): M = m − A + 5·log10(ϖ) − 10
function fvsAbsMagFromPlx(m, plxMas, A) { return (plxMas > 0) ? m - (A || 0) + 5 * Math.log(plxMas) / Math.LN10 - 10 : NaN; }
// … y desde la distancia en pc: M = m − A − 5·log10(d/10 pc)
function fvsAbsMagFromPc(m, pc, A) { return (pc > 0) ? m - (A || 0) - 5 * Math.log(pc / 10) / Math.LN10 : NaN; }
// L (L☉) desde M_G y Teff: log L = (M_bol☉ − M_G − BC_G)/2,5 (Andrae et al. 2018, ec. 4) → { lum, logL, bc, sigmaBc, src, extrapolated }
function fvsLumFromAbsG(absG, teff) {
   var b = fvsBcG(teff), mbol = absG + b.bc, logL = (FVS.MBOL_SUN - mbol) / 2.5;
   return { lum: Math.pow(10, logL), logL: logL, mbol: mbol, bc: b.bc, sigmaBc: b.sigma, src: b.src, extrapolated: b.extrapolated };
}
// Stefan-Boltzmann en unidades solares
function fvsRadiusFromLT(lum, teff) { return Math.sqrt(lum) / Math.pow(teff / FVS.TSUN_K, 2); }
// … y en SI (para la prueba con las constantes: el Sol nominal tiene que dar 3,828e26 W)
function fvsLumWatts(radM, teff) { return 4 * Math.PI * radM * radM * FVS.SIGMA_SB * Math.pow(teff, 4); }

// ---------------- clase de luminosidad (ESTIMADA) ----------------
// Δ = log L − log L_MS(Teff) (la altura sobre la secuencia principal de Mamajek a la misma Teff).
//   Δ < 0,5 dex → V (la anchura de la secuencia principal, de la ZAMS al agotamiento del H central, es ~0,3-0,5 dex, mas
//                  binarias sin resolver hasta +0,3: cota NUESTRA)
//   0,5-1,0     → IV (subgigante)
//   ≥ 1,0       → evolucionada; la clase la decide la luminosidad absoluta, con cortes en numeros redondos de M_bol
//                 tipicos de cada clase en las estrellas frias (III hasta M_bol ≈ −2,8; II hasta ≈ −4,3; Ib, Iab, Ia):
//                 log L < 3,0 III · < 3,6 II · < 4,3 Ib · < 4,9 Iab · ≥ 4,9 Ia. Cortes NUESTROS, no publicados.
// Limitacion conocida: en las calientes (O-B) las gigantes estan solo 0,5-1 dex sobre la secuencia y salen IV.
var FVS_LC = { V_MAX_DELTA: 0.5, IV_MAX_DELTA: 1.0, III_MAX_LOGL: 3.0, II_MAX_LOGL: 3.6, IB_MAX_LOGL: 4.3, IAB_MAX_LOGL: 4.9 };
function fvsLumClass(teff, logL) {
   var ms = fvsMamajekAt(teff, 2), d = logL - ms, c;
   if (!isFinite(d)) return { cls: "", delta: NaN, logLms: ms, family: "" };
   if (d < FVS_LC.V_MAX_DELTA) c = "V";
   else if (d < FVS_LC.IV_MAX_DELTA) c = "IV";
   else if (logL < FVS_LC.III_MAX_LOGL) c = "III";
   else if (logL < FVS_LC.II_MAX_LOGL) c = "II";
   else if (logL < FVS_LC.IB_MAX_LOGL) c = "Ib";
   else if (logL < FVS_LC.IAB_MAX_LOGL) c = "Iab";
   else c = "Ia";
   return { cls: c, delta: d, logLms: ms, family: (c.charAt(0) === "I" && c !== "IV" && c !== "III" && c !== "II") ? "I" : c };
}

// ---------------- tipo espectral ----------------
var FVS_SPT_LETTERS = "OBAFGKM";
// "M5.5V" / "K5" / "G2 V" → { letter, sub, code } con code = 10·indice + subtipo (O0 = 0, B0 = 10, … G2 = 42, M5.5 = 65.5)
function fvsSptParse(s) {
   var m = new RegExp("^\\s*([OBAFGKM])\\s*([0-9]+(\\.[0-9]+)?)").exec(String(s || ""));
   if (!m) return null;
   var sub = parseFloat(m[2]);
   return { letter: m[1], sub: sub, code: 10 * FVS_SPT_LETTERS.indexOf(m[1]) + sub };
}
function fvsSptFromCode_(code) {
   var i = Math.max(0, Math.min(6, Math.floor(code / 10 + 1e-9))), sub = Math.round((code - 10 * i) * 2) / 2;
   return FVS_SPT_LETTERS.charAt(i) + String(sub);
}
// Escala de gigantes/supergigantes frias: ST (G8 = −2 … K5 = 5, M0 = 6 … M8 = 14) → codigo espectral
function fvsGiantStToCode_(st) { return (st < 0) ? 40 + 10 + st : (st <= 5 ? 50 + st : 60 + (st - 6)); }
// Tipo espectral desde Teff (y la clase, si se sabe). → { spt, letter, sub, code, scale, flag }
//   scale: "mamajek2022" (enanas, y todas las que no son frias y evolucionadas) · "dyck1998" (III frias) · "vanbelle2009" (II, I frias)
//   flag: "" · "hotter-than-O3" · "cooler-than-M9.5" · "cooler-than-M8"
function fvsSpectralType(teff, cls) {
   var evolved = (cls === "III" || cls === "II" || cls === "Ib" || cls === "Iab" || cls === "Ia" || cls === "I"), flag = "", code, scale;
   if (evolved) {
      var sg = (cls !== "III"), t0 = sg ? 4724 : 4570, k = sg ? 123 : 109, tG8 = t0 + 2 * k;
      if (teff <= tG8) {
         var st = Math.round((t0 - teff) / k);
         if (st > 14) { st = 14; flag = "cooler-than-M8"; }
         code = fvsGiantStToCode_(st); scale = sg ? "vanbelle2009" : "dyck1998";
         var p = fvsSptParse(fvsSptFromCode_(code));
         return { spt: fvsSptFromCode_(code), letter: p.letter, sub: p.sub, code: code, scale: scale, flag: flag, st: (t0 - teff) / k };
      }
   }
   var T = FVS_MAMAJEK, best = 0, bd = 1e30;
   for (var i = 0; i < T.length; ++i) { var d = Math.abs(T[i][1] - teff); if (d < bd) { bd = d; best = i; } }
   if (teff > T[0][1]) flag = "hotter-than-O3";
   if (teff < T[T.length - 1][1]) flag = "cooler-than-M9.5";
   var s = T[best][0].replace("V", ""), q = fvsSptParse(s);
   return { spt: s, letter: q.letter, sub: q.sub, code: q.code, scale: "mamajek2022", flag: flag };
}

// ---------------- masa y vida en la secuencia principal ----------------
// L (L☉) desde M (M☉), relacion por tramos
function fvsLumFromMass(M) {
   if (M < 0.43) return 0.23 * Math.pow(M, 2.3);
   if (M < 2) return Math.pow(M, 4);
   if (M < 55) return 1.4 * Math.pow(M, 3.5);
   return 32000 * M;
}
// M (M☉) desde L (L☉): se invierte cada tramo y se queda el que cae dentro de su propio intervalo.
// → { mass, branch (1-4), valid } — valid = false fuera de 0,1-55 M☉ (fuera de lo comprobado contra Mamajek)
function fvsMassFromLum(L) {
   if (!(L > 0)) return { mass: NaN, branch: 0, valid: false };
   var c = [Math.pow(L / 0.23, 1 / 2.3), Math.pow(L, 0.25), Math.pow(L / 1.4, 1 / 3.5), L / 32000], m, b;
   if (c[0] < 0.43) { m = c[0]; b = 1; }
   else if (c[1] < 2) { m = Math.max(0.43, c[1]); b = 2; }
   else if (c[2] < 55) { m = Math.max(2, c[2]); b = 3; }
   else { m = Math.max(55, c[3]); b = 4; }
   return { mass: m, branch: b, valid: (m >= 0.1 && m <= 55) };
}
// Vida en la secuencia principal (años): 10^10·(M/L), con suelo de 3 Ma
var FVS_MS_LIFE_SUN_YR = 1e10, FVS_MS_LIFE_FLOOR_YR = 3e6;
function fvsMsLifetime(M, L) {
   if (!(M > 0 && L > 0)) return NaN;
   return Math.max(FVS_MS_LIFE_FLOOR_YR, FVS_MS_LIFE_SUN_YR * M / L);
}

// ---------------- zona habitable (Kopparapu et al. 2014, 1 M⊕) ----------------
var FVS_KOPP14 = {
   recentVenus: [1.776, 2.136e-4, 2.533e-8, -1.332e-11, -3.097e-15],
   runaway:     [1.107, 1.332e-4, 1.58e-8,  -8.308e-12, -1.931e-15],
   maxGreen:    [0.356, 6.171e-5, 1.698e-9, -3.198e-12, -5.575e-16],
   earlyMars:   [0.32,  5.547e-5, 1.526e-9, -2.874e-12, -5.011e-16]
};
function fvsHzSeff(teff, c) {
   var t = Math.max(2600, Math.min(7200, teff)) - FVS.KOPP_TSUN;
   return c[0] + t * (c[1] + t * (c[2] + t * (c[3] + t * c[4])));
}
// → { innerOpt, innerCons, outerCons, outerOpt (au), earthEq (au, donde llega lo mismo que a la Tierra), valid }
function fvsHabitableZone(teff, L) {
   if (!(L > 0 && teff > 0)) return null;
   function d(c) { return Math.sqrt(L / fvsHzSeff(teff, c)); }
   return { innerOpt: d(FVS_KOPP14.recentVenus), innerCons: d(FVS_KOPP14.runaway), outerCons: d(FVS_KOPP14.maxGreen),
            outerOpt: d(FVS_KOPP14.earlyMars), earthEq: Math.sqrt(L), valid: (teff >= 2600 && teff <= 7200) };
}
// Temperatura de equilibrio de un planeta (K): T_eq = Teff·√(R★/2a)·(1 − A)^(1/4) (redistribucion completa; libro de
// texto, p. ej. Seager 2010 «Exoplanet Atmospheres» cap. 3). R★ en R☉, a en au, A = albedo de Bond.
function fvsEqTemp(teff, rStar, aAU, albedo) {
   return teff * Math.sqrt(rStar / (2 * aAU * FVS.AU_RSUN)) * Math.pow(1 - (albedo || 0), 0.25);
}

// ---------------- la ficha completa ----------------
// inp = { teff, G, sigmaG, AG, sigmaAG, plx, plxErr, ruwe, zp (true: corregir el cero de Gaia), rgeo: { pc, lo, hi },
//         lum, radius, cls, spt (si vienen de catalogo, mandan), name }
// → todo lo de la ficha; cada campo NaN/null si no se puede. `notes`: lo que hay que avisar (extrapolado, dudoso…).
function fvsStar(inp) {
   var o = { name: inp.name || "", teff: inp.teff, notes: [] }, teff = inp.teff;
   o.dist = (typeof fvsDistance === "function") ? fvsDistance(inp) : null;
   if (o.dist && o.dist.quality === "doubtful") o.notes.push("distance-doubtful");
   o.absG = (inp.G !== undefined && o.dist && o.dist.pc > 0) ? fvsAbsMagFromPc(inp.G, o.dist.pc, inp.AG) : NaN;
   if (inp.lum > 0) { o.lum = inp.lum; o.logL = Math.log(inp.lum) / Math.LN10; o.lumSrc = "catalogue"; }
   else if (isFinite(o.absG) && teff > 0) {
      var l = fvsLumFromAbsG(o.absG, teff);
      o.lum = l.lum; o.logL = l.logL; o.bc = l.bc; o.lumSrc = "G+BC(" + l.src + ")";
      if (l.extrapolated) o.notes.push("bc-extrapolated");
      // incertidumbre de log L: G, A_G, BC y distancia (simetrizada en magnitudes), sumadas en cuadratura
      var sd = (o.dist.lo > 0 && o.dist.hi > 0 && isFinite(o.dist.hi)) ? 2.5 * Math.log(o.dist.hi / o.dist.lo) / Math.LN10 / 2 : 0.75;
      var sm = Math.sqrt(Math.pow(inp.sigmaG || 0.003, 2) + Math.pow(inp.sigmaAG || 0, 2) + l.sigmaBc * l.sigmaBc + sd * sd);
      o.logLsigma = sm / 2.5; o.lumLo = Math.pow(10, o.logL - o.logLsigma); o.lumHi = Math.pow(10, o.logL + o.logLsigma);
   } else { o.lum = NaN; o.logL = NaN; }
   o.radius = (inp.radius > 0) ? inp.radius : ((o.lum > 0 && teff > 0) ? fvsRadiusFromLT(o.lum, teff) : NaN);
   var lc = fvsLumClass(teff, o.logL);
   o.cls = inp.cls || lc.cls; o.clsEstimated = !inp.cls; o.lcDelta = lc.delta;
   var sp = fvsSpectralType(teff, o.cls);
   o.spt = inp.spt || (sp.spt + (o.cls ? (sp.scale === "mamajek2022" ? "" : " ") + o.cls : "")); o.sptInfo = sp;
   o.colour = (teff > 0) ? fvsBlackbodyColour(teff) : null;
   o.colourExag = o.colour ? fvsExaggerateColour(o.colour) : null;
   var onMs = (o.cls === "V" || o.cls === "IV");
   if (onMs && o.lum > 0) {
      var mm = fvsMassFromLum(o.lum);
      o.mass = mm.mass; o.massValid = mm.valid; o.msLifetime = fvsMsLifetime(mm.mass, o.lum);
      if (!mm.valid) o.notes.push("mass-out-of-range");
   } else { o.mass = NaN; o.massValid = false; o.msLifetime = NaN; if (o.cls) o.notes.push("evolved"); }
   o.hz = (o.lum > 0 && teff > 0) ? fvsHabitableZone(teff, o.lum) : null;
   if (o.hz && !o.hz.valid) o.notes.push("hz-out-of-range");
   return o;
}
