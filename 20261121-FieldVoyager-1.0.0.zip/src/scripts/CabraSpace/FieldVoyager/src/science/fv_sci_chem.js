// ============================================================================
// FieldVoyager/src/science/fv_sci_chem.js — LA COMPOSICION QUIMICA DE UNA ESTRELLA PARA LA FICHA (I13, 4-nov-2026)
// ----------------------------------------------------------------------------
// Puro (sin PixInsight, sin red): lo cargan PixInsight (#include) y el visor web (<script>).
//   fvsChemParse(survey, row)  -> registro de un survey (filas de VizieR por su nombre de columna; ver FVS_CHEM_COLS)
//   fvsChemBuild(recs, flame)  -> el resultado COMPACTO (lo que guarda la escena y viaja a la web): [Fe/H], [α/Fe], edad, poblacion, fuentes
//   fvsChemSummary(C, lang)    -> UNA frase para la ficha resumida ("" si no hay datos)
//   fvsChemDetails(C, lang)    -> las lineas de «MÁS» (o «sin datos de composición»)
//
// PROCEDENCIA (copiado y adaptado; CabraComposition no se toca):
//   · lectura de filas GALAH / APOGEE / LAMOST / GSP-Spec  <- CabraComposition/src/cc_catalogs.js:376-470 (CC_PARSE, ccAlphaFromEl, ccVE)
//   · banderas y calibracion de GSP-Spec                   <- CabraComposition/src/cc_science.js:381-401 (ccGspSpecGood, ccGspCalMh, ccGspCalAfe)
//   · adopcion por prioridad de survey y discrepancias      <- cc_science.js:418-454 (ccAdoptChem; CC_CHEM_PRIORITY, CC_DISCREPANT_DEX)
//   · clase quimica con la frontera de Weinberg (DR17)      <- cc_science.js:407-417 y 456-490 (ccAlphaLine, ccAlphaSlopeApplies, ccChemClass)
//   · edad de FLAME con sus guardas y niveles A/B/C         <- cc_science.js:534-640 (ccFlameFlag, ccAdoptAge, ccAgeTier; CC_SCI.FLAME_*)
//   · rangos de edad tipicos de cada poblacion              <- cc_science.js (CC_POP_AGES, Xiang & Rix 2022)
// QUE SE HA QUITADO (y por que): la cinematica (la poblacion sale SOLO de la quimica: la ficha lo dice), las familias acretadas, Xiang+19,
// Andrae+23 y las edades de Xiang & Rix, Anders+23, Boin y Kordopatis (seis consultas mas por estrella). Lo que queda se dice con su fuente.
// RIGOR: [Fe/H] y [α/Fe] son MEDIDAS espectroscopicas de un catalogo (se dice cual); la edad es una ESTIMACION de isocronas (FLAME); la poblacion
// es una INFERENCIA («probablemente» si la probabilidad no pasa de 0,84). Nada se inventa: sin datos, nada en el resumen.
// ES5.
// ============================================================================

var FVS_CHEM = {
   PRIORITY: ["galah", "apogee", "lamost", "gspspec"],     // como CC_CHEM_PRIORITY (sin Xiang+19 ni Andrae+23)
   DISCREPANT_DEX: 0.25,                                   // CC_DISCREPANT_DEX: se enseña, no se promedia
   GSP_FLOOR: 0.05,                                        // CC_GSP_FLOOR: suelo del error de [M/H] y [α/Fe] de GSP-Spec (diseño de CabraComposition)
   GSP_MH_P: [0.274, -0.1373, -0.0050, 0.0048],            // Recio-Blanco et al. 2023 (A&A 674, A29), ec. 2
   GSP_AFE_P: [-0.5809, 0.7018, -0.2402, 0.0239, 0.0],     // idem, tabla 4 (extrapol = 0), valido en logg 1,01–4,85
   GSP_AFE_LOGG: [1.01, 4.85],
   ALPHA_LINE_A: 0.16, ALPHA_LINE_B: -0.13,                // Weinberg et al. 2019 (ApJ 874, 102) llevada a DR17 (+0,04, Roberts et al. 2024)
   ALPHA_ZP_SIGMA: 0.04,                                   // incertidumbre del cero de la frontera (diseño de CabraComposition)
   HALO_FEH: -1.0,                                         // por debajo la quimica no separa disco grueso de halo (uso comun, Bensby et al. 2014)
   FLAME_FEH: [-0.5, 0.5],                                 // FLAME supone metalicidad solar (Creevey et al. 2023, A&A 674, A26)
   FLAME_GIANT_MASS: [1.0, 2.0], FLAME_GIANT_MIN_GA: 1.0, FLAME_GIANT_EREL: 0.30,   // nota 4 de VizieR I/355; Creevey et al. 2023 §6.4.1 y §8
   UNIVERSE_GA: 13.8,                                      // Planck 2018
   AGE_DWARF_LOGG: 3.8, AGE_FLOOR: 0.10,                   // diseño de CabraComposition: enana / subgigante; error relativo minimo de una isocrona
   POP_AGES: { thin: [0, 8], thick: [8, 13], halo: [10, 13.5] },   // Xiang & Rix 2022 (Nature 603, 599): rangos TIPICOS, no la edad de la estrella
   SOLAR_DEX: 0.15                                          // |[Fe/H]| <= 0,15: «parecida al Sol» (eleccion nuestra para la frase)
};
var FVS_CHEM_LABEL = { galah: "GALAH DR4", apogee: "APOGEE DR17", lamost: "LAMOST DR11", gspspec: "Gaia DR3 GSP-Spec", flame: "Gaia DR3 FLAME" };
var FVS_CHEM_REF = { galah: "Buder et al. 2025, PASA 42, e051", apogee: "Abdurro'uf et al. 2022, ApJS 259, 35", lamost: "Luo et al. 2015, RAA 15, 1095",
                     gspspec: "Recio-Blanco et al. 2023, A&A 674, A29", flame: "Creevey et al. 2023, A&A 674, A26", weinberg: "Weinberg et al. 2019, ApJ 874, 102" };
// las tablas de VizieR (el modulo de red las pide por su identificador de Gaia DR3; APOGEE trae el de EDR3, que es el mismo)
var FVS_CHEM_TAB = {
   apogee: { table: "III/286/catalog", id: "GaiaEDR3", cols: ["APOGEE", "GaiaEDR3", "SNR", "EFlag", "AFlag", "Teff", "logg", "[M/H]", "e_[M/H]", "[a/M]", "e_[a/M]", "[Fe/H]", "e_[Fe/H]", "f_[Fe/H]", "[Mg/Fe]", "e_[Mg/Fe]", "f_[Mg/Fe]"] },
   galah: { table: "J/other/PASA/42.51/allstar", id: "GaiaDR3", cols: ["GALAH", "GaiaDR3", "flagSp", "SNRpxCCD3", "Teff", "logg", "[Fe/H]", "e_[Fe/H]", "f_[Fe/H]", "[Mg/Fe]", "e_[Mg/Fe]", "f_[Mg/Fe]", "[Si/Fe]", "e_[Si/Fe]", "f_[Si/Fe]", "[Ca/Fe]", "e_[Ca/Fe]", "f_[Ca/Fe]", "[Ti/Fe]", "e_[Ti/Fe]", "f_[Ti/Fe]"] },
   lamost: { table: "V/162/dr11sl", id: "GaiaDR3", cols: ["ObsID", "GaiaDR3", "snrg", "Teff", "logg", "[Fe/H]", "e_[Fe/H]", "alpha", "e_alpha"] }
};

function fvsChemNum(v) {
   if (v === null || v === undefined) return null;
   if (typeof v === "number") return isFinite(v) ? v : null;
   var s = String(v).replace(/^\s+|\s+$/g, "").replace(/^"|"$/g, "");
   if (!s.length) return null;
   var x = Number(s);
   return isFinite(x) ? x : null;
}
function fvsChemIsNum(v) { return typeof v === "number" && isFinite(v); }
function fvsChemVE(row, vk, ek) { var v = fvsChemNum(row[vk]); return (v === null) ? null : { v: v, e: fvsChemNum(row[ek]) }; }
function fvsChemPoly(p, x) { var s = 0, xn = 1; for (var i = 0; i < p.length; ++i) { s += p[i] * xn; xn *= x; } return s; }
function fvsChemClamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function fvsChemPhi(z) {
   if (!fvsChemIsNum(z)) return 0.5;
   var t = 1 / (1 + 0.2316419 * Math.abs(z)), d = 0.3989422804014327 * Math.exp(-z * z / 2);
   var p = d * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
   return z > 0 ? 1 - p : p;
}
// banderas de GSP-Spec (cc_science.js:381): los 13 primeros caracteres <= 1, salvo fluxNoise (7.º) <= 3 y KMgiantPar (13.º) = 0
function fvsChemGspGood(flags) {
   var f = String(flags || "").replace(/^\s+|\s+$/g, "").replace(/^"|"$/g, "");
   if (f.length < 13) return false;
   for (var i = 0; i < 13; ++i) { var c = f.charCodeAt(i) - 48, lim = (i === 6) ? 3 : (i === 12) ? 0 : 1; if (!(c >= 0 && c <= lim)) return false; }
   return true;
}
// [Mg/Fe] si esta; si no, la media pesada de Si, Ca, Ti (ccAlphaFromEl)
function fvsChemAlphaFromEl(el) {
   if (el.Mg && fvsChemIsNum(el.Mg.v)) return { v: el.Mg.v, e: el.Mg.e, tracer: "Mg" };
   var sw = 0, s = 0, used = [], list = ["Si", "Ca", "Ti"];
   for (var i = 0; i < list.length; ++i) { var x = el[list[i]]; if (x && fvsChemIsNum(x.v)) { var e = fvsChemIsNum(x.e) && x.e > 0 ? x.e : 0.1, w = 1 / (e * e); s += w * x.v; sw += w; used.push(list[i]); } }
   return sw ? { v: s / sw, e: Math.sqrt(1 / sw), tracer: used.join("+") } : null;
}
// UNA fila -> registro { survey, feh: {v,e,proxy}, alpha: {v,e,tracer}, teff, logg, snr } | null (fila mala por sus banderas)
function fvsChemParse(survey, r) {
   var el = {}, i, X;
   if (survey === "galah") {
      if (fvsChemNum(r.flagSp) !== 0) return null;                                   // flag_sp = 0: espectro sin problemas
      var ffe = fvsChemNum(r["f_[Fe/H]"]);                                            // bits 0 y 1 (el «limite superior» es un fallo de DR4: §8.8.1)
      var lst = ["Mg", "Si", "Ca", "Ti"];
      for (i = 0; i < lst.length; ++i) { X = lst[i]; if (fvsChemNum(r["f_[" + X + "/Fe]"]) === 0) { var q = fvsChemVE(r, "[" + X + "/Fe]", "e_[" + X + "/Fe]"); if (q) el[X] = q; } }
      return { survey: "galah", feh: (ffe === 0 || ffe === 1) ? fvsChemVE(r, "[Fe/H]", "e_[Fe/H]") : null, alpha: fvsChemAlphaFromEl(el), teff: fvsChemNum(r.Teff), logg: fvsChemNum(r.logg), snr: fvsChemNum(r.SNRpxCCD3) };
   }
   if (survey === "apogee") {
      var af = fvsChemNum(r.AFlag), ef = fvsChemNum(r.EFlag);
      if (af !== null && Math.floor(af / 8388608) % 2 === 1) return null;            // ASPCAPFLAG bit 23 STAR_BAD
      var feh = (fvsChemNum(r["f_[Fe/H]"]) === 0) ? fvsChemVE(r, "[Fe/H]", "e_[Fe/H]") : null, alpha = null;
      if (fvsChemNum(r["f_[Mg/Fe]"]) === 0) { var mg = fvsChemVE(r, "[Mg/Fe]", "e_[Mg/Fe]"); if (mg) alpha = { v: mg.v, e: mg.e, tracer: "Mg" }; }
      if (!alpha) { var am = fvsChemNum(r["[a/M]"]), mh = fvsChemNum(r["[M/H]"]); if (am !== null && mh !== null && feh) alpha = { v: am + mh - feh.v, e: fvsChemNum(r["e_[a/M]"]), tracer: "[α/M]" }; }
      return { survey: "apogee", feh: feh, alpha: alpha, teff: fvsChemNum(r.Teff), logg: fvsChemNum(r.logg), snr: fvsChemNum(r.SNR), dup: (ef !== null && Math.floor(ef / 16) % 2 === 1) };
   }
   if (survey === "lamost") {
      var a = fvsChemNum(r.alpha);
      return { survey: "lamost", feh: fvsChemVE(r, "[Fe/H]", "e_[Fe/H]"), alpha: (a !== null) ? { v: a, e: fvsChemNum(r.e_alpha), tracer: "[α/M]" } : null, teff: fvsChemNum(r.Teff), logg: fvsChemNum(r.logg), snr: fvsChemNum(r.snrg) };
   }
   if (survey === "gspspec") {
      if (!fvsChemGspGood(r.Flags)) return null;
      var logg = fvsChemNum(r["logg-S"]), mh2 = fvsChemNum(r["[M/H]-S"]);
      if (mh2 === null) return null;
      var lo = fvsChemNum(r["b_[M/H]-S"]), hi = fvsChemNum(r["B_[M/H]-S"]), mhc = (logg !== null) ? mh2 + fvsChemPoly(FVS_CHEM.GSP_MH_P, logg) : null;
      var afe = fvsChemNum(r["[alpha/Fe]-S"]), al = fvsChemNum(r["b_[alpha/Fe]-S"]), ah = fvsChemNum(r["B_[alpha/Fe]-S"]);
      var afc = (afe !== null && logg !== null) ? afe + fvsChemPoly(FVS_CHEM.GSP_AFE_P, fvsChemClamp(logg, FVS_CHEM.GSP_AFE_LOGG[0], FVS_CHEM.GSP_AFE_LOGG[1])) : null;
      return { survey: "gspspec", feh: { v: (mhc !== null) ? mhc : mh2, e: Math.max(FVS_CHEM.GSP_FLOOR, (lo !== null && hi !== null) ? 0.5 * (hi - lo) : 0), proxy: "[M/H]" + (mhc !== null ? " cal." : "") },
               alpha: (afe !== null) ? { v: (afc !== null) ? afc : afe, e: Math.max(FVS_CHEM.GSP_FLOOR, (al !== null && ah !== null) ? 0.5 * (ah - al) : 0), tracer: "α" + (afc !== null ? " cal." : "") } : null,
               teff: fvsChemNum(r["Teff-S"]), logg: logg };
   }
   return null;
}
// la edad de FLAME de la fila de Gaia (Age-Flame, b_/B_Age-Flame, Flags-Flame, Mass-Flame) -> { v, lo, hi, flags, mass } | null
function fvsChemFlameRow(r) {
   var v = fvsChemNum(r["Age-Flame"]);
   if (v === null) return null;
   return { v: v, lo: fvsChemNum(r["b_Age-Flame"]), hi: fvsChemNum(r["B_Age-Flame"]), flags: fvsChemNum(r["Flags-Flame"]), mass: fvsChemNum(r["Mass-Flame"]) };
}

// ---------------------------------------------------------------------------
// ADOPCION, CLASE Y EDAD
// ---------------------------------------------------------------------------
function fvsChemAlphaLine(feh) { return FVS_CHEM.ALPHA_LINE_A + FVS_CHEM.ALPHA_LINE_B * Math.min(0, Math.max(FVS_CHEM.HALO_FEH, feh)); }
// recs = { survey: registro }; flame = fvsChemFlameRow(…) | null; logg0 = gravedad de Gaia (GSP-Phot) si ningun survey la da. -> compacto | null
//   { v: 1, feh: { v, e, s (survey), px (proxy) }, afe: { v, e, tr, s } | null, srcs: [surveys con [Fe/H]], disc: { dex, a, b } | null,
//     cls: { c: "thin"|"thick"|"halo"|"disc"|"disc-poor", p (P de α alto o null), z, conf (bool), basis: "feh+alpha"|"feh" },
//     age: { v, lo, hi, e, tier: "A"|"B"|"C", why: "dwarf"|"giant"|"", s: "flame" } | null, ageRej: motivo | null, logg }
function fvsChemBuild(recs, flame, logg0) {
   var feh = null, pair = null, srcs = [], logg = null, i, k;
   for (i = 0; i < FVS_CHEM.PRIORITY.length; ++i) {
      k = FVS_CHEM.PRIORITY[i]; var r = recs ? recs[k] : null;
      if (!r || !r.feh || !fvsChemIsNum(r.feh.v)) continue;
      srcs.push(k);
      if (!feh) feh = { v: r.feh.v, e: fvsChemIsNum(r.feh.e) ? r.feh.e : null, s: k, px: r.feh.proxy || "" };
      if (!pair && r.alpha && fvsChemIsNum(r.alpha.v)) pair = { feh: r.feh.v, efeh: r.feh.e, v: r.alpha.v, e: r.alpha.e, tr: r.alpha.tracer || "α", s: k };
      if (logg === null && fvsChemIsNum(r.logg)) logg = r.logg;
   }
   if (!feh) return null;
   if (logg === null && fvsChemIsNum(logg0)) logg = logg0;
   var out = { v: 1, feh: feh, afe: pair ? { v: pair.v, e: fvsChemIsNum(pair.e) ? pair.e : null, tr: pair.tr, s: pair.s } : null, srcs: srcs, disc: null, logg: logg };
   // ¿discrepan los surveys? (> 0,25 dex y > 3 σ): se enseña, no se promedia
   var vals = [];
   for (i = 0; i < FVS_CHEM.PRIORITY.length; ++i) { var rr = recs[FVS_CHEM.PRIORITY[i]]; if (rr && rr.feh && fvsChemIsNum(rr.feh.v)) vals.push({ k: FVS_CHEM.PRIORITY[i], v: rr.feh.v, e: fvsChemIsNum(rr.feh.e) ? rr.feh.e : 0.1 }); }
   for (i = 0; i < vals.length; ++i) for (var j = i + 1; j < vals.length; ++j) {
      var d = Math.abs(vals[i].v - vals[j].v), sg = Math.sqrt(vals[i].e * vals[i].e + vals[j].e * vals[j].e);
      if (d > FVS_CHEM.DISCREPANT_DEX && d > 3 * sg && (!out.disc || d > out.disc.dex)) out.disc = { dex: Math.round(d * 100) / 100, a: vals[i].k, b: vals[j].k };
   }
   // la clase quimica (ccChemClass)
   var f = pair ? pair.feh : feh.v, cls = { c: "", p: null, z: null, conf: false, basis: pair ? "feh+alpha" : "feh" };
   if (pair) {
      var ea = fvsChemIsNum(pair.e) ? pair.e : 0.05, ef = fvsChemIsNum(pair.efeh) ? pair.efeh : 0.05, line = fvsChemAlphaLine(f);
      var slope = (f > FVS_CHEM.HALO_FEH && f < 0) ? 0.0169 * ef * ef : 0;
      var sig = Math.sqrt(ea * ea + FVS_CHEM.ALPHA_ZP_SIGMA * FVS_CHEM.ALPHA_ZP_SIGMA + slope);
      cls.z = Math.round(100 * (pair.v - line) / sig) / 100; cls.p = Math.round(1000 * fvsChemPhi((pair.v - line) / sig)) / 1000; cls.line = Math.round(1000 * line) / 1000;
   }
   if (f <= FVS_CHEM.HALO_FEH) cls.c = "halo";
   else if (cls.p === null) cls.c = (feh.v < -0.6) ? "disc-poor" : "disc";
   else cls.c = (cls.p >= 0.5) ? "thick" : "thin";
   cls.conf = (cls.c === "halo") ? true : ((cls.p === null) ? false : (cls.p >= 0.84 || cls.p <= 0.16));
   out.cls = cls;
   // la edad de FLAME (ccFlameFlag + ccAdoptAge, solo esa fuente)
   out.age = null; out.ageRej = null;
   if (flame && fvsChemIsNum(flame.v) && flame.v > 0) {
      var why = "", giant = false, n = flame.flags;
      if (!(feh.v > FVS_CHEM.FLAME_FEH[0] && feh.v < FVS_CHEM.FLAME_FEH[1])) why = "flame-metallicity";
      else if (n !== null && n !== undefined) {
         var A = Math.floor(n / 10);
         if (A === 1) { giant = true; if (!fvsChemIsNum(flame.mass) || flame.mass < FVS_CHEM.FLAME_GIANT_MASS[0] || flame.mass > FVS_CHEM.FLAME_GIANT_MASS[1]) why = "flame-giant-mass"; else if (!(flame.v > FVS_CHEM.FLAME_GIANT_MIN_GA)) why = "flame-giant-young"; }
         else if (A !== 0) why = "flagged";
      }
      if (!why && !fvsChemIsNum(flame.lo) && !fvsChemIsNum(flame.hi)) why = "no-error";
      if (!why && flame.v > FVS_CHEM.UNIVERSE_GA) why = "older-than-universe";
      if (why) out.ageRej = why;
      else {
         var lo = fvsChemIsNum(flame.lo) ? flame.lo : flame.v, hi = fvsChemIsNum(flame.hi) ? flame.hi : flame.v, e;
         if (typeof FVS_RANGE !== "undefined" && FVS_RANGE.SORT === true && lo > hi) { var tSw = lo; lo = hi; hi = tSw; }      // (10, 20-nov) el menor primero: «(10,2–4,1 Ga)» al reves
         e = 0.5 * (hi - lo);
         var tier = (giant || !(fvsChemIsNum(logg) && logg <= FVS_CHEM.AGE_DWARF_LOGG)) ? "C" : "B", floorRel = giant ? FVS_CHEM.FLAME_GIANT_EREL : FVS_CHEM.AGE_FLOOR;
         if (e < floorRel * flame.v) { e = floorRel * flame.v; lo = Math.min(lo, flame.v - e); hi = Math.max(hi, flame.v + e); }
         lo = Math.max(0, lo); hi = Math.min(hi, FVS_CHEM.UNIVERSE_GA);
         out.age = { v: Math.round(flame.v * 100) / 100, lo: Math.round(lo * 100) / 100, hi: Math.round(hi * 100) / 100, e: Math.round(e * 100) / 100, tier: tier, why: tier === "C" ? (giant ? "giant" : "dwarf") : "", s: "flame" };
      }
   }
   // redondeo (lo que viaja)
   out.feh.v = Math.round(out.feh.v * 1000) / 1000; if (out.feh.e !== null) out.feh.e = Math.round(out.feh.e * 1000) / 1000;
   if (out.afe) { out.afe.v = Math.round(out.afe.v * 1000) / 1000; if (out.afe.e !== null) out.afe.e = Math.round(out.afe.e * 1000) / 1000; }
   if (out.logg !== null) out.logg = Math.round(out.logg * 100) / 100;
   return out;
}

// ---------------------------------------------------------------------------
// LAS FRASES (EN/ES)
// ---------------------------------------------------------------------------
var FVS_CHEM_TX = {
   en: {
      "s.halo": "Metal-poor ([Fe/H] {feh}): {prob}an old star of the Galactic halo{age}",
      "s.thick": "Rich in α elements ([α/Fe] {afe}): {prob}thick disc, an old generation{age}",
      "s.thinSun": "Composition like the Sun's ([Fe/H] {feh}): {prob}thin disc{age}",
      "s.thinRich": "Richer in metals than the Sun ([Fe/H] {feh}): {prob}thin disc{age}",
      "s.thinPoor": "Somewhat poorer in metals than the Sun ([Fe/H] {feh}): {prob}thin disc{age}",
      "s.disc": "[Fe/H] {feh}: a star of the Galactic disc (without [α/Fe] thin and thick cannot be told apart){age}",
      "s.discPoor": "Metal-poor ([Fe/H] {feh}): disc, perhaps the thick one (without [α/Fe] it cannot be told){age}",
      "prob": "probably ", "age": ", ~{a} years old",
      "d.feh": "[Fe/H] = {v} ± {e} · measured · {src}", "d.fehNoE": "[Fe/H] = {v} · measured · {src}",
      "d.fehProxy": " ([M/H] calibrated, used as [Fe/H])",
      "d.afe": "[α/Fe] = {v} ± {e} · measured (tracer {tr}) · {src}", "d.afeNoE": "[α/Fe] = {v} · measured (tracer {tr}) · {src}", "d.afeNo": "[α/Fe]: not measured",
      "d.age": "Age ≈ {v} Gyr ({lo}–{hi}) · estimated from isochrones (Gaia DR3 FLAME){tier}",
      "d.ageC.dwarf": " · indicative only: on the main sequence an isochrone barely moves with age",
      "d.ageC.giant": " · indicative only: FLAME on a giant (20–30 % uncertainty, VizieR I/355 note 4)",
      "d.ageNo": "Age: no reliable estimate",
      "d.ageRej.flame-metallicity": "Age: FLAME discarded (it assumes solar metallicity, valid only for −0.5 < [Fe/H] < 0.5)",
      "d.ageRej.flame-giant-mass": "Age: FLAME discarded (giant outside 1–2 solar masses)",
      "d.ageRej.flame-giant-young": "Age: FLAME discarded (giant younger than 1 Gyr: not reliable)",
      "d.ageRej.flagged": "Age: FLAME discarded by its own quality flag",
      "d.ageRej.no-error": "Age: FLAME without uncertainty, not used",
      "d.ageRej.older-than-universe": "Age: FLAME gives more than the age of the Universe, not used",
      "d.pop.thin": "Population: thin disc", "d.pop.thick": "Population: thick disc", "d.pop.halo": "Population: halo", "d.pop.disc": "Population: disc (thin or thick: unknown)", "d.pop.disc-poor": "Population: disc, metal-poor (thin or thick: unknown)",
      "d.crit.alpha": " · from chemistry only: [α/Fe] {z} σ {side} the high/low-α boundary of {wref}, P(high α) = {p}",
      "d.crit.halo": " · from chemistry only: [Fe/H] ≤ −1.0, where it no longer separates thick disc from halo",
      "d.crit.feh": " · from [Fe/H] only (no [α/Fe])",
      "d.crit.chemOnly": "; the orbit is not used",
      "d.typAge": "; typical age of that population {a}–{b} Gyr (Xiang & Rix 2022), not measured on this star",
      "d.above": "above", "d.below": "below",
      "d.srcs": "Sources: {list}",
      "d.disc": "Warning: the catalogues disagree on [Fe/H] by {dex} dex ({a} vs {b}); the one shown is the higher-priority survey",
      "d.none": "no composition data (neither Gaia GSP-Spec, APOGEE, GALAH nor LAMOST has this star)",
      "d.off": "composition: the catalogues did not answer (no network)",
      "d.fetch": "composition: asking the catalogues…",
      "ga": "Gyr", "bn": "billion", "mn": "million", "tr.cal": "calibrated α"
   },
   es: {
      "s.halo": "Pobre en metales ([Fe/H] {feh}): {prob}una estrella vieja del halo{age}",
      "s.thick": "Rica en elementos α ([α/Fe] {afe}): {prob}disco grueso, una generación antigua{age}",
      "s.thinSun": "Composición parecida al Sol ([Fe/H] {feh}): {prob}disco fino{age}",
      "s.thinRich": "Más rica en metales que el Sol ([Fe/H] {feh}): {prob}disco fino{age}",
      "s.thinPoor": "Algo más pobre en metales que el Sol ([Fe/H] {feh}): {prob}disco fino{age}",
      "s.disc": "[Fe/H] {feh}: una estrella del disco de la Galaxia (sin [α/Fe] no se distingue fino de grueso){age}",
      "s.discPoor": "Pobre en metales ([Fe/H] {feh}): del disco, quizá el grueso (sin [α/Fe] no se sabe){age}",
      "prob": "probablemente ", "age": ", ~{a} años",
      "d.feh": "[Fe/H] = {v} ± {e} · medido · {src}", "d.fehNoE": "[Fe/H] = {v} · medido · {src}",
      "d.fehProxy": " ([M/H] calibrado, usado como [Fe/H])",
      "d.afe": "[α/Fe] = {v} ± {e} · medido (trazador {tr}) · {src}", "d.afeNoE": "[α/Fe] = {v} · medido (trazador {tr}) · {src}", "d.afeNo": "[α/Fe]: sin medir",
      "d.age": "Edad ≈ {v} Ga ({lo}–{hi}) · estimada con isócronas (Gaia DR3 FLAME){tier}",
      "d.ageC.dwarf": " · solo orientativa: en la secuencia principal la isócrona apenas cambia con la edad",
      "d.ageC.giant": " · solo orientativa: FLAME en una gigante (20–30 % de incertidumbre, nota 4 de VizieR I/355)",
      "d.ageNo": "Edad: sin estimación fiable",
      "d.ageRej.flame-metallicity": "Edad: FLAME descartada (supone metalicidad solar; solo vale con −0,5 < [Fe/H] < 0,5)",
      "d.ageRej.flame-giant-mass": "Edad: FLAME descartada (gigante fuera de 1–2 masas solares)",
      "d.ageRej.flame-giant-young": "Edad: FLAME descartada (gigante de menos de 1 Ga: no es fiable)",
      "d.ageRej.flagged": "Edad: FLAME descartada por su propia bandera de calidad",
      "d.ageRej.no-error": "Edad: FLAME sin incertidumbre, no se usa",
      "d.ageRej.older-than-universe": "Edad: FLAME da más que la edad del Universo, no se usa",
      "d.pop.thin": "Población: disco fino", "d.pop.thick": "Población: disco grueso", "d.pop.halo": "Población: halo", "d.pop.disc": "Población: disco (fino o grueso: no se sabe)", "d.pop.disc-poor": "Población: disco, pobre en metales (fino o grueso: no se sabe)",
      "d.crit.alpha": " · solo por la química: [α/Fe] a {z} σ {side} de la frontera α alto / α bajo de {wref}, P(α alto) = {p}",
      "d.crit.halo": " · solo por la química: [Fe/H] ≤ −1,0, donde ya no separa disco grueso de halo",
      "d.crit.feh": " · solo por [Fe/H] (sin [α/Fe])",
      "d.crit.chemOnly": "; sin la órbita",
      "d.typAge": "; edad típica de esa población {a}–{b} Ga (Xiang & Rix 2022), no medida en esta estrella",
      "d.above": "por encima", "d.below": "por debajo",
      "d.srcs": "Fuentes: {list}",
      "d.disc": "Aviso: los catálogos discrepan en [Fe/H] en {dex} dex ({a} frente a {b}); se enseña el del survey de más prioridad",
      "d.none": "sin datos de composición (ni Gaia GSP-Spec, ni APOGEE, ni GALAH, ni LAMOST tienen esta estrella)",
      "d.off": "composición: los catálogos no contestaron (sin red)",
      "d.fetch": "composición: consultando los catálogos…",
      "ga": "Ga", "bn": "mil millones", "mn": "millones", "tr.cal": "α calibrado"
   }
};
function fvsChemT(lang, key, params) {
   var tab = FVS_CHEM_TX[(lang === "es") ? "es" : "en"], s = tab.hasOwnProperty(key) ? tab[key] : (FVS_CHEM_TX.en[key] || key);
   if (params) for (var k in params) if (params.hasOwnProperty(k)) s = s.split("{" + k + "}").join(String(params[k]));
   return s;
}
// numero con signo y coma/punto del idioma (−0,45 · +0,21)
function fvsChemSgn(x, d, lang) { var s = Math.abs(x).toFixed(d); if (lang === "es") s = s.replace(".", ","); return (x < 0 && Number(s.replace(",", ".")) !== 0 ? "−" : "+") + s; }
function fvsChemDec(x, d, lang) { var s = x.toFixed(d); return lang === "es" ? s.replace(".", ",") : s; }
// la edad en años para la frase: «~11 000 millones de años» (ES) / «~11 billion years old» (EN), redondeada a 2 cifras
function fvsChemAgeWords(ga, lang) {
   var r = (ga >= 1) ? Math.round(ga * 10) / 10 : Math.round(ga * 100) / 100;
   if (lang === "es") {
      var m = Math.round(r * 1000), s = String(m); if (m >= 10000) s = s.substring(0, s.length - 3) + " " + s.substring(s.length - 3); else if (m >= 1000) s = s.substring(0, s.length - 3) + " " + s.substring(s.length - 3);
      return s + " " + fvsChemT(lang, "mn") + " de";
   }
   return (r >= 1 ? fvsChemDec(r, (r % 1 === 0) ? 0 : 1, lang) + " " + fvsChemT(lang, "bn") : Math.round(r * 1000) + " " + fvsChemT(lang, "mn"));
}
// LA FRASE de la ficha resumida ("" sin datos)
function fvsChemSummary(C, lang) {
   if (!C || !C.feh) return "";
   var L = (lang === "es") ? "es" : "en", c = C.cls ? C.cls.c : "disc", f = C.feh.v, key;
   if (c === "halo") key = "s.halo";
   else if (c === "thick") key = "s.thick";
   else if (c === "thin") key = (Math.abs(f) <= FVS_CHEM.SOLAR_DEX) ? "s.thinSun" : (f > 0 ? "s.thinRich" : "s.thinPoor");
   else key = (c === "disc-poor") ? "s.discPoor" : "s.disc";
   // la edad solo en la frase si no es «orientativa» (nivel C): en «MÁS» va siempre
   var age = (C.age && C.age.tier !== "C") ? fvsChemT(L, "age", { a: fvsChemAgeWords(C.age.v, L) }) : "";
   return fvsChemT(L, key, { feh: fvsChemSgn(f, 2, L), afe: C.afe ? fvsChemSgn(C.afe.v, 2, L) : "", prob: (C.cls && !C.cls.conf) ? fvsChemT(L, "prob") : "", age: age });
}
// LAS LINEAS DE «MÁS» (state: "fetch" | "off" | undefined)
function fvsChemDetails(C, lang, state) {
   var L = (lang === "es") ? "es" : "en", out = [];
   if (!C || !C.feh) { out.push(fvsChemT(L, state === "fetch" ? "d.fetch" : (state === "off" ? "d.off" : "d.none"))); return out; }
   var lab = function(s) { return FVS_CHEM_LABEL[s] || s; };
   // (compacto, 4-nov: con MÁS abierto la ficha no cabia en 930 px) [Fe/H] · [α/Fe] · edad · poblacion con su criterio · fuentes · aviso
   out.push(fvsChemT(L, C.feh.e !== null ? "d.feh" : "d.fehNoE", { v: fvsChemSgn(C.feh.v, 2, L), e: C.feh.e !== null ? fvsChemDec(C.feh.e, 2, L) : "", src: lab(C.feh.s) }) + (C.feh.s === "gspspec" ? fvsChemT(L, "d.fehProxy") : ""));
   var tr = C.afe ? (/cal\./.test(C.afe.tr) ? fvsChemT(L, "tr.cal") : C.afe.tr) : "";
   if (C.afe) out.push(fvsChemT(L, C.afe.e !== null ? "d.afe" : "d.afeNoE", { v: fvsChemSgn(C.afe.v, 2, L), e: C.afe.e !== null ? fvsChemDec(C.afe.e, 2, L) : "", tr: tr, src: lab(C.afe.s) }));
   else out.push(fvsChemT(L, "d.afeNo"));
   if (C.age) out.push(fvsChemT(L, "d.age", (function(a) { var r = (typeof fvsOrderPair === "function") ? fvsOrderPair(a.lo, a.hi) : [a.lo, a.hi]; return { v: fvsChemDec(a.v, 1, L), lo: fvsChemDec(r[0], 1, L), hi: fvsChemDec(r[1], 1, L), tier: C.age.tier === "C" ? fvsChemT(L, "d.ageC." + (C.age.why || "dwarf")) : "" }; })(C.age)));
   else out.push(C.ageRej ? fvsChemT(L, "d.ageRej." + C.ageRej) : fvsChemT(L, "d.ageNo"));
   var c = C.cls ? C.cls.c : "disc", pop = fvsChemT(L, "d.pop." + c);
   if (c === "halo") pop += fvsChemT(L, "d.crit.halo");
   else if (C.cls && C.cls.p !== null) pop += fvsChemT(L, "d.crit.alpha", { side: fvsChemT(L, C.cls.z >= 0 ? "d.above" : "d.below"), wref: "Weinberg et al. 2019", z: fvsChemDec(Math.abs(C.cls.z), 1, L), p: fvsChemDec(C.cls.p, 2, L) });
   else pop += fvsChemT(L, "d.crit.feh");
   pop += fvsChemT(L, "d.crit.chemOnly");
   var ta = FVS_CHEM.POP_AGES[c];
   if (ta) pop += fvsChemT(L, "d.typAge", { a: fvsChemDec(ta[0], 0, L), b: fvsChemDec(ta[1], ta[1] % 1 ? 1 : 0, L) });
   out.push(pop);
   var list = [], seen = {};
   var add = function(s) { if (s && !seen[s]) { seen[s] = 1; list.push(lab(s) + " (" + (FVS_CHEM_REF[s] || "") + ")"); } };
   add(C.feh.s); if (C.afe) add(C.afe.s); for (var i = 0; i < (C.srcs || []).length; ++i) add(C.srcs[i]); if (C.age) add("flame");
   if (C.cls && C.cls.p !== null && c !== "halo") list.push(FVS_CHEM_REF.weinberg);
   out.push(fvsChemT(L, "d.srcs", { list: list.join(" · ") }));
   if (C.disc) out.push(fvsChemT(L, "d.disc", { dex: fvsChemDec(C.disc.dex, 2, L), a: lab(C.disc.a), b: lab(C.disc.b) }));
   return out;
}
