// ============================================================================
// FieldVoyager/src/science/fv_sci_const.js — CONSTANTES FISICAS Y ASTRONOMICAS (3-nov-2026)
// ----------------------------------------------------------------------------
// Modulo cientifico de FieldVoyager: funciones PURAS (ES5, sin PixInsight) que usan el pintor de PJSR y el visor del
// navegador. Este fichero solo guarda constantes, cada una con su FUENTE y su FECHA (pregunta 4 del metodo: ¿de donde
// sale y sigue valiendo?). Unidades SI salvo que el nombre diga otra cosa (_AU, _LY, _PC, _YR...).
// Orden de carga: fv_sci_const.js → fv_sci_tables.js → fv_sci_i18n.js → fv_sci_colour.js → fv_sci_star.js →
// fv_sci_dist.js → fv_sci_transit.js → fv_sci_travel.js → fv_sci_scale.js → fv_sci_phrases.js (fv_science.jsh en PJSR).
// Prefijo de todo el modulo: fvs / FVS_ (no choca con el motor, que usa fv*).
// ============================================================================

var FVS = {
   // --- exactas del SI (redefinicion de 2019; c desde 1983) ---
   C_MS: 299792458,                  // m/s, exacta
   H_JS: 6.62607015e-34,             // J s, exacta (SI 2019)
   KB_JK: 1.380649e-23,              // J/K, exacta (SI 2019)
   SIGMA_SB: 5.670374419e-8,         // W m^-2 K^-4, CODATA 2018 (derivada de h, k, c; valor truncado de CODATA)
   G_SI: 6.67430e-11,                // m^3 kg^-1 s^-2, CODATA 2018
   G0_MS2: 9.80665,                  // m/s^2, gravedad estandar (3.ª CGPM, 1901): la «1 g» de los viajes

   // --- unidades astronomicas (resoluciones de la IAU) ---
   AU_M: 149597870700,               // m, IAU 2012 Resolucion B2 (exacta por definicion)
   PC_M: 149597870700 * 648000 / Math.PI,   // m, IAU 2015 Resolucion B2: 1 pc = 648000/π au
   JYEAR_S: 365.25 * 86400,          // s, año juliano (IAU): el del año luz
   LY_M: 299792458 * 365.25 * 86400, // m, año luz de la IAU (c × año juliano) = 9,4607e15 m

   // --- el Sol: valores NOMINALES de la IAU 2015 Resolucion B3 (no son medidas: son las unidades de conversion) ---
   RSUN_M: 6.957e8,                  // m, radio solar nominal
   LSUN_W: 3.828e26,                 // W, luminosidad solar nominal
   TSUN_K: 5772,                     // K, temperatura efectiva nominal
   GMSUN: 1.3271244e20,              // m^3/s^2, parametro gravitatorio solar nominal
   MBOL_SUN: 4.74,                   // mag, IAU 2015 Resolucion B2 (M_bol = 0 ↔ L0 = 3,0128e28 W) → Sol 4,74
   BCG_SUN: 0.06,                    // mag, Andrae et al. 2018 (A&A 616, A8), Tabla 3: BC_G del Sol (cero del polinomio)
   // M_G del Sol coherente con lo anterior: 4,74 − 0,06 = 4,68 (Casagrande & VandenBerg 2018 dan 4,67; DR3 usa 4,66:
   // la diferencia, 0,01-0,02 mag, es menor que la incertidumbre de BC_G).
   MG_SUN: 4.68,
   AGE_SUN_YR: 4.568e9,              // años, edad del Sistema Solar (Bouvier & Wadhwa 2010, Nature Geosci. 3, 637: 4568,2 Ma)

   // --- planetas: valores NOMINALES de la IAU 2015 Resolucion B3 (ecuatoriales) ---
   REARTH_M: 6.3781e6,               // m
   RJUP_M: 7.1492e7,                 // m
   // Semiejes mayores (au), JPL «Approximate Positions of the Planets» (elementos J2000, Standish): redondeados a 3 cifras
   // decimales; solo se usan para frases («llegaria mas alla de la orbita de Marte»).
   ORBIT_AU: { mercury: 0.387, venus: 0.723, earth: 1.000, mars: 1.524, jupiter: 5.203, saturn: 9.537, uranus: 19.19, neptune: 30.07 },

   // --- calidad de la paralaje: MISMOS umbrales que FieldDepth3D (CabraShared/csh_starfield.js, CP_SF) ---
   PLX_MAX_FRAC: 0.20,               // error relativo maximo para invertir la paralaje (Bailer-Jones 2015, PASP 127, 994)
   RUWE_MAX: 1.4,                    // documentacion de Gaia DR2 (tabla ruwe del archivo de ESA): > 1,4 = astrometria sospechosa
   PLX_ZERO_POINT_MAS: -0.017,       // mas, cero de la paralaje de Gaia EDR3/DR3 (Lindegren et al. 2021, A&A 649, A4)

   // --- velocidades de referencia para las frases de viaje ---
   VOYAGER1_KMS: 17.0,               // km/s respecto al Sol, NASA/JPL (estado de la mision Voyager, ~17 km/s). Redondeado.
   PROXIMA_PLX_MAS: 768.0665,        // mas, Gaia DR3 (Proxima Cen, ± 0,0499): la estrella mas cercana → 4,2465 al

   // --- zona habitable ---
   KOPP_TSUN: 5780                   // K, el T☉ que usa Kopparapu et al. 2014 en T★ = Teff − 5780 (ec. 4, leido en el PDF)
};

// Derivadas (se calculan, no se copian: si una de arriba cambia, estas la siguen)
FVS.PC_LY = FVS.PC_M / FVS.LY_M;                 // 3,26156 al por pc
FVS.AU_RSUN = FVS.AU_M / FVS.RSUN_M;             // 215,032 R☉ por au
FVS.RSUN_REARTH = FVS.RSUN_M / FVS.REARTH_M;     // 109,076 R⊕ por R☉
FVS.RJUP_REARTH = FVS.RJUP_M / FVS.REARTH_M;     // 11,209 R⊕ por R_J
FVS.RSUN_RJUP = FVS.RSUN_M / FVS.RJUP_M;         // 9,731 R_J por R☉
FVS.C2_MK = FVS.H_JS * FVS.C_MS / FVS.KB_JK;     // 1,438777e-2 m K, segunda constante de radiacion
FVS.LY_AU = FVS.LY_M / FVS.AU_M;                 // 63 241 au por al
FVS.PROXIMA_LY = (1000 / FVS.PROXIMA_PLX_MAS) * FVS.PC_LY;   // 4,2465 al
