// ============================================================================
// FieldVoyager/src/science/fv_sci_phrases.js — LAS FRASES DE LA FICHA DE CINE Y DE LA CABINA, EN + ES (3-nov-2026)
// ----------------------------------------------------------------------------
// Une los calculos (fv_sci_star/dist/transit/travel/scale) con los textos (fv_sci_i18n). Cada funcion devuelve un objeto
// de frases sueltas (sin punto final salvo las del tiempo de luz, que son oraciones completas); "" = no hay dato.
// El que pinta decide el orden y la tipografia. Nada aqui calcula fisica nueva.
// ES5. Sin PixInsight.
// ============================================================================

// La orbita mas grande que quedaria DENTRO de una estrella de radio R (R☉) puesta en el lugar del Sol → clave de planeta o ""
function fvsOrbitInside_(radius) {
   var rAU = radius / FVS.AU_RSUN, names = ["mercury", "venus", "earth", "mars", "jupiter", "saturn", "uranus", "neptune"], best = "";
   for (var i = 0; i < names.length; ++i) if (rAU > FVS.ORBIT_AU[names[i]]) best = names[i];
   return best;
}

// Frases de una estrella (o = fvsStar(...)). obsYear: el año de la foto (para el tiempo de luz).
// (10, 20-nov) un intervalo [a, b] con el menor primero (NaN/infinito se quedan donde estan: solo se cambia si los dos son numeros y a > b)
var FVS_RANGE = { SORT: true };
function fvsOrderPair(a, b) {
   if (FVS_RANGE.SORT === true && typeof a === "number" && typeof b === "number" && isFinite(a) && isFinite(b) && a > b) return [b, a];
   return [a, b];
}
function fvsStarPhrases(o, lang, obsYear) {
   var L = lang, P = { spt: "", cls: "", lum: "", radius: "", radiusOrbit: "", temp: "", mass: "", life: "", hz: "", dist: "", distRange: "", light: "", notes: [] };
   if (o.spt) P.spt = fvsT(L, "spt", { s: o.spt });
   if (o.cls) {
      var fam = (o.cls === "Ia" || o.cls === "Iab" || o.cls === "Ib") ? "I" : o.cls;
      P.cls = fvsT(L, "cls." + fam) + (o.clsEstimated ? " (" + fvsT(L, "cls.estimated") + ")" : "");
   }
   if (o.lum > 0) {
      if (o.lum >= 1.15) P.lum = fvsT(L, "lum.more", { x: fvsFmtTimes(o.lum, L) });
      else if (o.lum <= 0.87) P.lum = fvsT(L, "lum.less", { x: fvsFmtTimes(1 / o.lum, L) });
      else P.lum = fvsT(L, "lum.same");
   }
   if (o.radius > 0) {
      if (o.radius >= 1.15) P.radius = fvsT(L, "rad.more", { x: fvsFmtTimes(o.radius, L) });
      else if (o.radius <= 0.87) P.radius = fvsT(L, "rad.less", { x: fvsFmtTimes(1 / o.radius, L) });
      else P.radius = fvsT(L, "rad.same");
      var pl = fvsOrbitInside_(o.radius);
      if (pl) P.radiusOrbit = fvsT(L, "rad.orbit", { planet: fvsT(L, "planet." + pl) });
   }
   if (o.teff > 0) {
      var dt = o.teff - FVS.TSUN_K, tt = fvsFmtTemp(o.teff, L);
      P.temp = fvsT(L, "temp", { t: tt }) + ", " + (Math.abs(dt) < 100 ? fvsT(L, "temp.same")
               : fvsT(L, dt > 0 ? "temp.hotter" : "temp.cooler", { dt: fvsT(L, "u.K", { x: fvsFmtSig(Math.abs(dt), 2, L) }) }));
   }
   if (o.mass > 0) P.mass = (Math.abs(o.mass - 1) < 0.1) ? fvsT(L, "mass.sun") : fvsT(L, "mass", { m: fvsFmtSig(o.mass, 2, L) });
   if (o.msLifetime > 0) P.life = fvsT(L, "life", { t: fvsFmtDuration(o.msLifetime, L), s: fvsFmtDuration(FVS_MS_LIFE_SUN_YR, L) });
   else if (o.cls && o.cls !== "V" && o.cls !== "IV") P.life = fvsT(L, "life.evolved", { cls: fvsT(L, "cls." + ((o.cls.charAt(0) === "I" && o.cls.length > 1 && o.cls !== "II" && o.cls !== "III") ? "I" : o.cls)) });
   if (o.hz && (o.cls === "V" || o.cls === "IV")) {
      P.hz = fvsT(L, "hz", { a: fvsFmtSig(o.hz.innerCons, 2, L), b: fvsFmtSig(o.hz.outerCons, 2, L), c: fvsFmtSig(o.hz.innerOpt, 2, L), d: fvsFmtSig(o.hz.outerOpt, 2, L) });
      if (!o.hz.valid) P.hz += " " + fvsT(L, "hz.invalid");
   }
   var d = o.dist;
   if (d && d.ly > 0) {
      P.dist = fvsT(L, "dist", { ly: fvsFmtSig(d.ly, 3, L), pc: fvsFmtSig(d.pc, 3, L) });
      // intervalo de 1σ: solo si es apreciable (> 1 %); con las cifras justas para que los dos extremos se distingan
      // (10, 20-nov) SIEMPRE el menor primero: con los extremos al reves (lo > hi, de un catalogo o de un refinado) la frase decia «entre 8 816 y 5 214» o,
      // peor, se perdia la horquilla. FVS_RANGE.SORT false = lo de antes. fvsOrderPair (abajo) es la misma regla para cualquier intervalo de una ficha.
      var rg = fvsOrderPair(d.loLy, d.hiLy), rLo = rg[0], rHi = rg[1];
      if (rLo > 0 && isFinite(rHi) && (rHi - rLo) / d.ly > 0.02) {
         var sg = 2; while (sg < 4 && fvsFmtSig(rLo, sg, L) === fvsFmtSig(rHi, sg, L)) ++sg;
         P.distRange = fvsT(L, "dist.range", { lo: fvsFmtSig(rLo, sg, L), hi: fvsFmtSig(rHi, sg, L) });
      } else if (d.loLy > 0 && !isFinite(d.hiLy)) P.distRange = fvsT(L, "dist.far", { lo: fvsFmtSig(d.loLy, 2, L) });
      if (d.quality === "doubtful") P.distRange = (P.distRange ? P.distRange + " · " : "") + fvsT(L, "dist.doubtful");
      // (Codex K3 H-3, 4-nov) el error de la distancia llega a la frase: semianchura mayor del intervalo de 1σ (conservador si
      // es asimétrico); sin extremo lejano, el error es la propia distancia; sin intervalo, la frase supone su 5 %
      var eLy = (d.loLy > 0 && isFinite(d.hiLy)) ? Math.max(d.hiLy - d.ly, d.ly - d.loLy) : ((d.loLy > 0) ? d.ly : 0);
      P.light = fvsLightPhrase(d.ly, L, obsYear, eLy);
   } else P.dist = fvsT(L, "dist.none");
   for (var i = 0; i < o.notes.length; ++i) P.notes.push(fvsT(L, "note." + o.notes[i]));
   return P;
}

// «La luz que ves salio de alli en el año …» (oracion completa, con punto)
// errLy (opcional, 4-nov-2026): error de la distancia en años luz (semianchura del intervalo). Sin él se supone el 5 %
// (paralajes de Gaia buenos). Con un error de ≥ 1 año el año se redondea a su orden de magnitud y la comparación con la
// efeméride se hace con ese margen: nunca «6,2 años antes» cuando la distancia tiene ± 230 años (revisión visual del 4-nov).
function fvsLightPhrase(dLy, lang, obsYear, errLy) {
   var L = lang, e = fvsLightEpoch(dLy, obsYear), lk = (fvsLang_(L) === "es") ? "es" : "en";
   if (e.mode === "now") return fvsT(L, "light.now", { t: fvsFmtDuration(dLy, L) });
   if (e.mode === "year") {
      if (!e.event) return fvsT(L, "light.now", { t: fvsFmtDuration(dLy, L) });
      var ey = e.event.approx ? fvsT(L, "year.c", { y: fvsFmtYear(e.event.year, L) }) : fvsFmtYear(e.event.year, L);
      var u = (errLy > 0) ? errLy : 0.05 * dLy;
      if (u >= 2) {
         // el ± se redondea HACIA ARRIBA (nunca prometer menos error del que hay); el año, en su calendario histórico
         var step = Math.pow(10, Math.floor(Math.log(u) / Math.LN10)), um = Math.ceil(u / step - 1e-9) * step;
         var yAst = Math.round((obsYear > 0 ? obsYear : (new Date()).getFullYear()) - dLy), yr0 = Math.round(fvsAstroToHist(yAst) / step) * step;
         if (yr0 === 0) yr0 = 1;
         // (Codex K3 H-5) la comparación con la efeméride usa el año SIN redondear: el redondeo no mete en «su época» lo que cae fuera
         var eya = fvsHistToAstro(e.event.year), gap = eya - ((obsYear > 0 ? obsYear : (new Date()).getFullYear()) - dLy);
         if (Math.abs(gap) <= u) return fvsT(L, "light.u.era", { y: fvsFmtYear(yr0, L), u: fvsFmtNum(um, 0, L), e: e.event[lk], ey: ey });
         var gn = fvsFmtNum(Math.max(step, Math.round(Math.abs(gap) / step) * step), 0, L);
         return fvsT(L, gap > 0 ? "light.u.before" : "light.u.after", { y: fvsFmtYear(yr0, L), u: fvsFmtNum(um, 0, L), n: gn, e: e.event[lk], ey: ey });
      }
      // (Codex K3 H-1) con el año exacto, la separación se cuenta entre el año MOSTRADO y el de la efeméride (antes, 1994,6
      // contra 1995 salía «el año de…» con 1994 en pantalla); (H-2) «1 año», no «1 años»
      var dR = fvsHistToAstro(e.event.year) - fvsHistToAstro(e.yearHist), gapR = Math.abs(dR), relR = (gapR === 0) ? "same" : (dR > 0 ? "before" : "after");
      var n = e.event.approx || gapR >= 1000 ? fvsT(L, "approx", { n: fvsFmtSig(gapR, gapR >= 100 ? 1 : 2, L) }) : fvsFmtNum(gapR, 0, L);
      var yr = fvsFmtYear(e.yearHist, L);
      if (relR === "same") return fvsT(L, "light.same", { y: yr, e: e.event[lk] });
      return fvsT(L, (relR === "before" ? "light.before" : "light.after") + (gapR === 1 && !e.event.approx ? ".1" : ""), { y: yr, n: n, e: e.event[lk], ey: ey });
   }
   // (Codex K3 H-6) en tiempo profundo, si la efeméride cae dentro del error, «en la época de…» y no «mucho antes»
   var p = { t: fvsFmtDuration(dLy, L), e: e.event[lk], et: fvsFmtDuration(e.event.ago, L) };
   var relD = (errLy > 0 && Math.abs(dLy - e.event.ago) <= errLy) ? "same" : e.rel;
   return fvsT(L, relD === "same" ? "light.deep.same" : (relD === "before" ? "light.deep.before" : "light.deep.after"), p);
}

// Frases del transito (tr = fvsTransitSetup(...))
function fvsTransitPhrases(tr, lang) {
   var L = lang, s = fvsSolarSystemDepths(), P = {};
   // (Blender 4 · defecto 8) {p} es el cociente de AREAS (k², lo que tapa del disco) y {q} lo que baja la LUZ en el centro del transito con el
   // oscurecimiento del limbo (depthLD = 1 − fvsTransitFluxZ(|b|), el MISMO modelo que la curva del panel, fvsTransitCurve): antes decia
   // «tapa el 2,41 % de la luz» y la curva bajaba al 2,56 %. Una cifra decimal: la diferencia se lee y no aparenta mas precision
   var dLD = (tr.depthLD > 0) ? tr.depthLD : tr.depth;
   P.depth = fvsT(L, "tr.depth", { p: fvsFmtPct(tr.depth, L, tr.depth < 0.01 ? 2 : 1), q: fvsFmtPct(dLD, L, dLD < 0.01 ? 2 : 1) });
   P.duration = fvsT(L, "tr.dur", { t: fvsFmtDuration(tr.t14 / 24 / 365.25, L) });
   P.year = fvsT(L, "tr.year", { t: fvsFmtDuration(tr.P / 365.25, L) });
   P.size = (tr.rpJup >= 0.5) ? fvsT(L, "tr.size.jup", { x: fvsFmtNum(tr.rpJup, 2, L), y: fvsFmtSig(tr.rpEarth, 3, L) })
                              : fvsT(L, "tr.size.earth", { x: fvsFmtNum(tr.rpEarth, 2, L) });
   P.compare = fvsT(L, "tr.cmp", { e: fvsFmtPct(s.earth, L), j: fvsFmtPct(s.jupiter, L) });
   P.speed = fvsT(L, "tr.speed", { v: fvsFmtSig(tr.vOrbKms, 3, L) });
   P.teq = (tr.teq > 0) ? fvsT(L, "tr.teq", { t: fvsFmtTemp(tr.teq, L) }) : "";
   P.check = (tr.t14Table > 0) ? fvsT(L, "tr.check", { a: fvsFmtDuration(tr.t14 / 24 / 365.25, L), b: fvsFmtDuration(tr.t14Table / 24 / 365.25, L) }) : "";
   P.omega = fvsT(L, "tr.omega");
   return P;
}

// Frases de viaje a una distancia de dLy años luz. opts = { beta (0,99 por defecto), warp (9,975 por defecto) }
function fvsTravelPhrases(dLy, lang, opts) {
   var L = lang, op = opts || {}, beta = (op.beta > 0 && op.beta < 1) ? op.beta : 0.99, w = (op.warp > 0) ? op.warp : 9.975, P = {};
   P.light = fvsT(L, "tv.light", { t: fvsFmtDuration(dLy, L) });
   var c = fvsTravelConstant(dLy, beta);
   P.beta = fvsT(L, "tv.beta", { b: fvsFmtPct(beta, L, beta >= 0.999 ? 2 : 0), te: fvsFmtDuration(c.earthYears, L), ts: fvsFmtDuration(c.shipYears, L) });
   var a = fvsTravelAccel(dLy);
   P.accel = fvsT(L, "tv.accel", { ts: fvsFmtDuration(a.shipYears, L), te: fvsFmtDuration(a.earthYears, L), b: fvsFmtPct(a.betaMax, L, a.betaMax > 0.999 ? 3 : 1) });
   P.warp = fvsT(L, "tv.warp", { w: fvsFmtNum(w, (Math.round(w) === w) ? 0 : (Math.round(w * 10) === w * 10 ? 1 : 3), L), v: fvsFmtTimes(fvsWarpToC(w), L), t: fvsFmtDuration(fvsWarpTravelYears(dLy, w), L) });
   P.warpNote = fvsT(L, "tv.warp.note");
   P.voyager = fvsT(L, "tv.voyager", { t: fvsFmtDuration(dLy / (FVS.VOYAGER1_KMS * 1000 / FVS.C_MS), L) });
   P.improbability = fvsT(L, "tv.improb", { n: fvsFmtNum(fvsImprobability(dLy).power, 0, L) }) + " " + fvsT(L, "tv.improb.note");
   return P;
}

// Frases de escala de un objeto extenso (diametro angular en arcmin, distancia en al)
function fvsScalePhrases(angArcmin, dLy, lang) {
   var L = lang, s = fvsObjectScale(angArcmin, dLy), g = fvsSandScale(dLy, s.diamLy), P = {};
   P.size = fvsT(L, "sc.size", { d: fvsFmtSig(s.diamLy, 2, L), pc: fvsFmtSig(s.diamPc, 2, L) });
   P.solarSystems = fvsT(L, "sc.ss", { n: fvsFmtBig(s.solarSystemsAcross, L, 2) }) + " " + fvsT(L, "sc.ssvol", { n: fvsFmtBig(s.solarSystemsVolume, L, 2) });
   P.lightCross = fvsT(L, "sc.lightcross", { t: fvsFmtDuration(s.lightCrossYears, L) });
   P.sand = fvsT(L, "sc.sand", { e: fvsFmtLength(g.earthOrbitM, L), p: fvsFmtLength(g.proximaKm * 1000, L) });
   P.sandObject = fvsT(L, "sc.sand.obj", { d: fvsFmtLength(g.objectKm * 1000, L) }) + " " + fvsT(L, "sc.sand.size", { s: fvsFmtLength(g.objectSizeKm * 1000, L) });
   return P;
}
