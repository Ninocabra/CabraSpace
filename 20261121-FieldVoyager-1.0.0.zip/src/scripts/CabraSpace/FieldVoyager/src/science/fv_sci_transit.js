// ============================================================================
// FieldVoyager/src/science/fv_sci_transit.js — EXOPLANETA EN TRANSITO: PROFUNDIDAD, DURACION, CURVA DE LUZ Y GEOMETRIA
// (3-nov-2026)
// ----------------------------------------------------------------------------
// Entrada: una fila de NASA Exoplanet Archive, tabla pscomppars (nombres de columna tal cual): pl_orbper [d],
// pl_ratror [Rp/R★], pl_trandur [h], pl_orbsmax [au], pl_imppar [b, en R★], pl_orbincl [°], st_rad [R☉], st_teff [K],
// st_mass [M☉], pl_rade [R⊕], pl_eqt [K]. Si falta pl_ratror: k = pl_rade/(109,076·st_rad) (R☉/R⊕ de la IAU 2015 B3).
// Unidades de salida: tiempos en HORAS (P tambien en dias), longitudes en radios de la estrella (R★) salvo que diga otra cosa.
// Fuentes:
//   · Orbita CIRCULAR (pscomppars no da lo necesario para dibujar la excentrica): a/R★ = 215,032·a[au]/R★[R☉];
//     b = (a/R★)·cos i; si falta i, i = acos(b/(a/R★)) (referentes-2-arquitectura-y-datos.md §D.2).
//   · Duracion total T14 = (P/π)·asin[ √((1+k)² − b²) / ((a/R★)·sin i) ] y T23 con (1−k): Seager & Mallén-Ornelas 2003
//     (ApJ 585, 1038), ec. 3 (forma general, orbita circular); igual que Winn 2010 («Transits and Occultations», ec. 14).
//   · Profundidad de disco uniforme δ = k² (si el planeta entra entero).
//   · Curva de luz: el flujo tapado se integra en anillos concentricos de la estrella (I constante en cada anillo) usando
//     el AREA EXACTA de solape de dos circulos (la funcion λ^e de Mandel & Agol 2002, ApJ 580, L171, ec. 1) para cada
//     anillo: es el esquema de «batman» (Kreidberg 2015, PASP 127, 1161). Con oscurecimiento nulo es exactamente la
//     formula analitica de Mandel & Agol; con oscurecimiento cuadratico I(μ)/I(1) = 1 − u1(1−μ) − u2(1−μ)² el error baja
//     como 1/N² con los N anillos (N = 400 por defecto: < 1e-6 de flujo).
//   · Oscurecimiento por defecto (si no se dan u1, u2): ATMOSFERA GRIS de Eddington, T⁴(τ) = ¾·Teff⁴·(τ + 2/3), con la
//     intensidad monocromatica I_λ(μ) = ∫ B_λ(T(τ))·e^(−τ/μ) dτ/μ a 600 nm, ajustada a la ley cuadratica. Es una
//     APROXIMACION FISICA documentada (no las tablas de Claret): en bolometrico reproduce I(μ) ∝ (2 + 3μ)/5 (la prueba lo
//     comprueba). NO VERIFICADO contra Claret & Bloemen 2011: para algo mas fino, pasar u1, u2 de catalogo.
//   · Orientacion de la orbita en el cielo (Ω): pscomppars no la da → ILUSTRATIVA (se declara en la ficha).
// ES5. Sin PixInsight.
// ============================================================================

// ---------------- oscurecimiento del limbo ----------------
// Intensidad I(μ) de una atmosfera gris de Eddington a λ (nm); lambdaNm <= 0 → bolometrica (∝ T⁴, para la prueba).
// t = τ/μ y u = 1 − e^(−t): I(μ) = ∫₀¹ B(T(μ·t(u))) du (regla del punto medio, 400 puntos).
function fvsGrayIntensity_(teff, mu, lambdaNm) {
   var n = 400, s = 0, lam = lambdaNm * 1e-9;
   for (var i = 0; i < n; ++i) {
      var u = (i + 0.5) / n, t = -Math.log(1 - u), tau = mu * t;
      var T = teff * Math.pow(0.75 * (tau + 2 / 3), 0.25);
      s += (lambdaNm > 0) ? fvsPlanck(lam, T) : Math.pow(T, 4);
   }
   return s / n;
}
// Perfil normalizado I(μ)/I(1) de la atmosfera gris
function fvsGrayProfile(teff, mu, lambdaNm) { return fvsGrayIntensity_(teff, mu, lambdaNm) / fvsGrayIntensity_(teff, 1, lambdaNm); }
// Ajuste por minimos cuadrados de la ley cuadratica (con I(1) = 1) al perfil gris: → { u1, u2, lambdaNm, src }
function fvsLimbDarkGray(teff, lambdaNm) {
   var lam = (lambdaNm > 0) ? lambdaNm : 600, i1 = fvsGrayIntensity_(teff, 1, lam), s11 = 0, s12 = 0, s22 = 0, r1 = 0, r2 = 0;
   for (var j = 0; j < 20; ++j) {
      var mu = (j + 0.5) / 20, x = 1 - mu, y = 1 - fvsGrayIntensity_(teff, mu, lam) / i1;   // y = u1·x + u2·x²
      s11 += x * x; s12 += x * x * x; s22 += x * x * x * x; r1 += x * y; r2 += x * x * y;
   }
   var det = s11 * s22 - s12 * s12;
   return { u1: (r1 * s22 - r2 * s12) / det, u2: (s11 * r2 - s12 * r1) / det, lambdaNm: lam, src: "gray-eddington" };
}

// ---------------- geometria de dos discos ----------------
// Area de solape de un circulo de radio R centrado en la estrella y el disco del planeta (radio k) a distancia z
function fvsOverlapArea(R, k, z) {
   if (R <= 0 || k <= 0) return 0;
   if (z >= R + k) return 0;
   if (z <= Math.abs(R - k)) { var m = Math.min(R, k); return Math.PI * m * m; }
   var c1 = (z * z + R * R - k * k) / (2 * z * R), c2 = (z * z + k * k - R * R) / (2 * z * k);
   c1 = Math.max(-1, Math.min(1, c1)); c2 = Math.max(-1, Math.min(1, c2));
   var q = (-z + R + k) * (z + R - k) * (z - R + k) * (z + R + k);
   return R * R * Math.acos(c1) + k * k * Math.acos(c2) - 0.5 * Math.sqrt(Math.max(0, q));
}
// Primitiva F(μ) = ∫₀^μ m·I(m) dm de la ley cuadratica: como r·dr = −μ·dμ, el flujo de un anillo [ra, rb] es
// 2π·(F(μa) − F(μb)) EXACTO (y el del disco entero, 2π·F(1) = π(1 − u1/3 − u2/6)).
function fvsLdPrim_(mu, a1, a2) { var m2 = mu * mu, m3 = m2 * mu; return m2 / 2 - a1 * (m2 / 2 - m3 / 3) - a2 * (m2 / 2 - 2 * m3 / 3 + m2 * m2 / 4); }
// Flujo relativo (1 = sin transito) con el planeta a distancia z (en R★) del centro; oscurecimiento cuadratico u1, u2.
// En cada anillo se usa la intensidad MEDIA exacta del anillo (no la del radio medio): con el planeta tapando anillos
// enteros el resultado es exacto (ocultacion total → 0), y el resto converge como 1/N².
function fvsTransitFluxZ(z, k, u1, u2, nRings) {
   if (z >= 1 + k) return 1;
   var a1 = u1 || 0, a2 = u2 || 0;
   if (a1 === 0 && a2 === 0) return 1 - fvsOverlapArea(1, k, z) / Math.PI;      // Mandel & Agol 2002, disco uniforme
   var n = nRings || 400, r0 = Math.max(0, z - k), r1 = Math.min(1, z + k), blocked = 0, prev = fvsOverlapArea(r0, k, z);
   var fPrev = fvsLdPrim_(Math.sqrt(Math.max(0, 1 - r0 * r0)), a1, a2);
   for (var i = 1; i <= n; ++i) {
      var r = r0 + (r1 - r0) * i / n, ra = r0 + (r1 - r0) * (i - 1) / n, A = fvsOverlapArea(r, k, z);
      var f = fvsLdPrim_(Math.sqrt(Math.max(0, 1 - r * r)), a1, a2), dA = Math.PI * (r * r - ra * ra);
      if (dA > 0) blocked += (2 * Math.PI * (fPrev - f) / dA) * (A - prev);
      prev = A; fPrev = f;
   }
   return 1 - blocked / (Math.PI * (1 - a1 / 3 - a2 / 6));
}

// ---------------- el sistema desde pscomppars ----------------
// p = fila de pscomppars; opts = { u1, u2 } (opcional). → objeto con todo lo de la ficha y lo que necesita la animacion.
function fvsTransitSetup(p, opts) {
   var o = { name: p.pl_name || "", flags: [] }, op = opts || {};
   o.P = p.pl_orbper; o.Ph = p.pl_orbper * 24;
   o.rStar = p.st_rad; o.teff = p.st_teff;
   if (p.pl_ratror > 0) o.k = p.pl_ratror;
   else if (p.pl_rade > 0 && p.st_rad > 0) { o.k = p.pl_rade / (FVS.RSUN_REARTH * p.st_rad); o.flags.push("k-from-rade"); }
   else { o.k = NaN; o.flags.push("no-k"); }
   if (p.pl_orbsmax > 0 && p.st_rad > 0) o.aR = FVS.AU_RSUN * p.pl_orbsmax / p.st_rad;
   else if (p.st_mass > 0 && p.st_rad > 0 && p.pl_orbper > 0) {          // tercera ley de Kepler con la masa de la estrella
      var Ps = p.pl_orbper * 86400, aM = Math.pow(FVS.GMSUN * p.st_mass * Ps * Ps / (4 * Math.PI * Math.PI), 1 / 3);
      o.aR = aM / (p.st_rad * FVS.RSUN_M); o.flags.push("a-from-kepler");
   } else { o.aR = NaN; o.flags.push("no-a"); }
   var hasB = (p.pl_imppar !== undefined && p.pl_imppar !== null && isFinite(p.pl_imppar));
   var hasI = (p.pl_orbincl !== undefined && p.pl_orbincl !== null && isFinite(p.pl_orbincl));
   if (hasB) o.b = p.pl_imppar;
   if (hasI) o.inc = p.pl_orbincl * Math.PI / 180;
   if (hasB && !hasI) o.inc = Math.acos(Math.min(1, o.b / o.aR));
   if (!hasB && hasI) o.b = o.aR * Math.cos(o.inc);
   if (!hasB && !hasI) { o.b = 0; o.inc = Math.PI / 2; o.flags.push("b-assumed-0"); }
   o.incDeg = o.inc * 180 / Math.PI;
   o.depth = o.k * o.k;
   var si = Math.sin(o.inc), w14 = (1 + o.k) * (1 + o.k) - o.b * o.b, w23 = (1 - o.k) * (1 - o.k) - o.b * o.b;
   o.t14 = (w14 > 0) ? (o.P / Math.PI) * Math.asin(Math.min(1, Math.sqrt(w14) / (o.aR * si))) * 24 : 0;
   o.t23 = (w23 > 0) ? (o.P / Math.PI) * Math.asin(Math.min(1, Math.sqrt(w23) / (o.aR * si))) * 24 : 0;
   if (w14 <= 0) o.flags.push("no-transit"); else if (w23 <= 0) o.flags.push("grazing");
   o.t14Table = (p.pl_trandur > 0) ? p.pl_trandur : NaN;
   o.t14Diff = (o.t14Table > 0) ? (o.t14 - o.t14Table) / o.t14Table : NaN;
   var ld = (op.u1 !== undefined) ? { u1: op.u1, u2: op.u2 || 0, src: "given" } : (o.teff > 0 ? fvsLimbDarkGray(o.teff, 600) : { u1: 0, u2: 0, src: "none" });
   o.u1 = ld.u1; o.u2 = ld.u2; o.ldSrc = ld.src;
   o.depthLD = 1 - fvsTransitFluxZ(Math.abs(o.b), o.k, o.u1, o.u2);     // profundidad en el centro del transito, con limbo (|b|: Codex K7 H-4)
   o.rpEarth = (p.pl_rade > 0) ? p.pl_rade : o.k * o.rStar * FVS.RSUN_REARTH;
   o.rpJup = o.rpEarth / FVS.RJUP_REARTH;
   o.aAU = (p.pl_orbsmax > 0) ? p.pl_orbsmax : o.aR * o.rStar / FVS.AU_RSUN;
   o.vOrbKms = 2 * Math.PI * o.aAU * FVS.AU_M / (o.P * 86400) / 1000;
   o.teq = (p.pl_eqt > 0) ? p.pl_eqt : ((o.teff > 0 && o.rStar > 0 && o.aAU > 0) ? fvsEqTemp(o.teff, o.rStar, o.aAU, 0) : NaN);
   o.teqSrc = (p.pl_eqt > 0) ? "catalogue" : "computed(A=0)";
   o.omegaIllustrative = true;
   return o;
}

// Posicion del planeta a t horas del centro del transito (orbita circular), en R★, observador en −Z mirando a +Z:
// X a lo largo del transito, Y altura sobre el centro del disco (= b en el centro), Z > 0 delante de la estrella.
// → { x, y, z, sep (distancia proyectada al centro), front, flux, phase }
function fvsTransitPos(tr, tHours) {
   var ph = 2 * Math.PI * tHours / tr.Ph, cp = Math.cos(ph);
   var x = tr.aR * Math.sin(ph), y = tr.b * cp, zz = tr.aR * cp * Math.sin(tr.inc), sep = Math.sqrt(x * x + y * y);
   var front = zz > 0, f = front ? fvsTransitFluxZ(sep, tr.k, tr.u1, tr.u2) : 1;
   return { x: x, y: y, z: zz, sep: sep, front: front, flux: f, phase: ph };
}
// Curva de luz muestreada para dibujar: n puntos entre −half y +half horas (por defecto ±0,75·T14, minimo ±1 h)
// → { t: [h], f: [flujo], depthMax, t14 }
function fvsTransitCurve(tr, n, halfHours) {
   // (Codex K7 H-2) N impar = muestra en el centro, y sin ventana minima de 1 h: un transito de minutos no cae entre muestras
   var N = (n > 1) ? n : 201, h = (halfHours > 0) ? halfHours : (tr.t14 > 0 ? 0.75 * tr.t14 : 1), t = [], f = [], dmax = 0;
   for (var i = 0; i < N; ++i) {
      var ti = -h + 2 * h * i / (N - 1), q = fvsTransitPos(tr, ti);
      t.push(ti); f.push(q.flux); dmax = Math.max(dmax, 1 - q.flux);
   }
   return { t: t, f: f, depthMax: dmax, t14: tr.t14 };
}
// Comparaciones fijas (calculadas, no copiadas): profundidad del transito de la Tierra y de Jupiter por delante del Sol
function fvsSolarSystemDepths() {
   return { earth: Math.pow(1 / FVS.RSUN_REARTH, 2), jupiter: Math.pow(1 / FVS.RSUN_RJUP, 2) };
}
