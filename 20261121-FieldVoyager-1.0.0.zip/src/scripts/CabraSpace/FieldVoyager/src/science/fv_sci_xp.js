// ============================================================================
// FieldVoyager/src/science/fv_sci_xp.js — EL ESPECTRO XP DE GAIA (BP/RP) PARA LA FICHA (I12, 4-nov-2026)
// ----------------------------------------------------------------------------
// Puro (sin PixInsight, sin red): lo cargan PixInsight (#include) y el visor web (<script>). Hace tres cosas:
//   1. fvsXpCompact(lam, flux, err, src)  -> el espectro de 343 puntos (336–1020 nm cada 2 nm) en ~60 puntos para la ficha y el paquete web,
//      con el ajuste de cuerpo negro y las LINEAS MEDIDAS sobre el espectro completo (antes de reducirlo).
//   2. fvsXpBbCurve(X, teff)              -> el cuerpo negro de una temperatura, escalado al espectro (minimos cuadrados), en los mismos puntos.
//   3. fvsXpWaveRgb(nm)                   -> el color de una longitud de onda visible (la tira del espectro); null fuera del visible.
// Textos EN/ES del panel: FVS_XP_TX (viajan con el modulo a la web; fv_text.js no se exporta).
//
// PROCEDENCIA (copiado y adaptado; CabraStars no se toca):
//   · fvsXpPlanck, fvsXpPlanckScale, fvsXpBbTeff  <- CabraStars/lib/cs_astro.js:252-333 (csPlanck, csPlanckScale, csXpBlackbodyTeff)
//   · fvsXpCmf                                    <- CabraStars/lib/cs_astro.js:258-263 (csCmf: CIE 1931 2°, Wyman, Sloan y Shirley 2013)
//   · fvsXpWaveRgb                                <- CabraStars/lib/cs_ui_draw.js:559-567 (csWavelengthRgb)
//   · la rejilla de Gaia (336 + 2k nm, 343 puntos) <- CabraStars/lib/cs_engine.js:376 (CS_XP_GRID, comprobado el 22-oct-2026 con 51 Peg)
//   · el limite de publicacion G < 17,65             <- CabraStars/lib/cs_engine.js:300 (CS_XP_GMAX)
// NUEVO: la reduccion a ~60 puntos (medias por tramos), la medida de las lineas y el formato compacto.
//
// LAS LINEAS (rigor): las posiciones son de laboratorio (aire, nm). La PROFUNDIDAD se mide sobre el espectro de 2 nm: 1 − (media en el nucleo) /
// (continuo interpolado entre dos ventanas a los lados). El XP de Gaia tiene una resolucion de ~10–30 nm (BP) y ~15–25 nm (RP): las lineas se ven
// muy anchas y poco profundas; el triplete del Ca II sale como UNA depresion. Una linea cuenta como «vista» si su profundidad pasa a la vez del 2 %
// y de 3 σ (σ de los errores publicados, que en el XP muestreado estan CORRELACIONADOS entre puntos vecinos: el 3 σ es optimista; por eso el
// suelo del 2 %, eleccion nuestra). La banda de TiO no se mide: se marca la zona solo en estrellas frias (< 4 000 K) como «esperada».
// ES5.
// ============================================================================

var FVS_XP = {
   L0: 336, STEP: 2, N: 343,           // la rejilla del XP muestreado de Gaia DR3 (ESA y ARI dan la misma; la base local DR3/SP la suya)
   VIEW0: 330, VIEW1: 1050,            // el eje del panel (nm)
   NC: 60,                             // puntos del espectro compacto (encargo: «muestreado a ~60 puntos»)
   GMAX: 17.65,                        // Gaia DR3 publica XP muestreado solo de G < 17,65 (De Angeli et al. 2023, A&A 674, A2; Montegriffo et al. 2023)
   FIT0: 400, FIT1: 950,               // el ajuste de Planck solo en 400–950 nm (los extremos de BP y RP son los mas ruidosos; como CabraStars)
   DEPTH_MIN: 0.02, DEPTH_SIG: 3,      // una linea «vista»: profundidad > 2 % y > 3 σ (ver arriba: eleccion nuestra)
   TIO_TEFF: 4000,                     // por debajo, la zona de bandas de TiO se marca como esperada (tipos K tardios y M)
   // las lineas: centro (nm), semianchura del nucleo y las dos ventanas de continuo [a, b] (nm); diseño, a la resolucion del XP
   LINES: [
      { k: "hb", nm: 486.1, core: 6, cl: [455, 468], cr: [505, 520], label: "Hβ" },
      { k: "ha", nm: 656.3, core: 7, cl: [620, 635], cr: [675, 690], label: "Hα" },
      { k: "ca", nm: 858.0, core: 10, cl: [815, 832], cr: [880, 895], label: "Ca II", span: [849.8, 866.2] }
   ],
   TIO: [705, 760]
};

// ---------------------------------------------------------------------------
// PLANCK Y AJUSTE (copiado de cs_astro.js)
// ---------------------------------------------------------------------------
// Ley de Planck B_λ(T) en unidades relativas (λ en nm). c2 = hc/k = 1,438777e7 nm·K.
function fvsXpPlanck(lamNm, T) {
   var x = 1.438777e7 / (lamNm * T);
   if (x > 700) return 0;
   return 1 / (Math.pow(lamNm, 5) * (Math.exp(x) - 1));
}
// La escala de Planck que mejor casa con el espectro (minimos cuadrados con pesos 1/σ²; sin errores, pesos 1), en FIT0–FIT1. -> { k, chi2, n }
function fvsXpPlanckScale(lam, flux, err, T) {
   var sww = 0, swy = 0, n = 0, i;
   for (i = 0; i < lam.length; ++i) {
      if (lam[i] < FVS_XP.FIT0 || lam[i] > FVS_XP.FIT1 || !isFinite(flux[i])) continue;
      var b = fvsXpPlanck(lam[i], T), w = (err && err[i] > 0) ? 1 / (err[i] * err[i]) : 1;
      swy += w * b * flux[i]; sww += w * b * b; ++n;
   }
   if (!(sww > 0)) return { k: 0, chi2: Infinity, n: 0 };
   var k = swy / sww, chi = 0;
   for (i = 0; i < lam.length; ++i) {
      if (lam[i] < FVS_XP.FIT0 || lam[i] > FVS_XP.FIT1 || !isFinite(flux[i])) continue;
      var wi = (err && err[i] > 0) ? 1 / (err[i] * err[i]) : 1, r = flux[i] - k * fvsXpPlanck(lam[i], T);
      chi += wi * r * r;
   }
   return { k: k, chi2: chi, n: n };
}
// La temperatura del cuerpo negro que MEJOR casa con el espectro (rejilla logaritmica 2500–40 000 K y afinado). Es una «temperatura de
// color»: el polvo la enfria y las lineas la mueven. -> { teff, k, chi2, n, edge } | null
function fvsXpBbTeff(lam, flux, err) {
   var best = null, T;
   for (T = 2500; T <= 40000; T *= 1.03) { var f = fvsXpPlanckScale(lam, flux, err, T); if (best === null || f.chi2 < best.chi2) best = { T: T, k: f.k, chi2: f.chi2, n: f.n }; }
   if (best === null || !(best.k > 0)) return null;
   var lo = best.T / 1.03, hi = best.T * 1.03;
   for (var it = 0; it < 30; ++it) {
      var m1 = lo + (hi - lo) / 3, m2 = hi - (hi - lo) / 3;
      if (fvsXpPlanckScale(lam, flux, err, m1).chi2 < fvsXpPlanckScale(lam, flux, err, m2).chi2) hi = m2; else lo = m1;
   }
   var Tb = (lo + hi) / 2, fb = fvsXpPlanckScale(lam, flux, err, Tb);
   return { teff: Tb, k: fb.k, chi2: fb.chi2, n: fb.n, edge: (Tb < 2600 || Tb > 38000) };
}

// ---------------------------------------------------------------------------
// EL COLOR DE UNA LONGITUD DE ONDA (copiado de cs_ui_draw.js / cs_astro.js)
// ---------------------------------------------------------------------------
function fvsXpCmf(l) {
   function g(x, mu, s1, s2) { var t = (x - mu) / ((x < mu) ? s1 : s2); return Math.exp(-0.5 * t * t); }
   return [1.056 * g(l, 599.8, 37.9, 31.0) + 0.362 * g(l, 442.0, 16.0, 26.7) - 0.065 * g(l, 501.1, 20.4, 26.2),
           0.821 * g(l, 568.8, 46.9, 40.5) + 0.286 * g(l, 530.9, 16.3, 31.1),
           1.217 * g(l, 437.0, 11.8, 36.0) + 0.681 * g(l, 459.0, 26.0, 13.8)];
}
// sRGB [r, g, b] (0–255) de una longitud de onda visible, saturado al maximo y apagado hacia los bordes del visible; null fuera de 380–750 nm.
// (mas alla de 645 nm las colas de la aproximacion de la CMF dan verdes falsos: alli es rojo — nota de CabraStars)
function fvsXpWaveRgb(l) {
   if (!(l >= 380 && l <= 750)) return null;
   var c = fvsXpCmf(Math.min(l, 645)), r = 3.2406 * c[0] - 1.5372 * c[1] - 0.4986 * c[2], g = -0.9689 * c[0] + 1.8758 * c[1] + 0.0415 * c[2], b = 0.0557 * c[0] - 0.2040 * c[1] + 1.0570 * c[2];
   var v = [Math.max(0, r), Math.max(0, g), Math.max(0, b)], m = Math.max(v[0], v[1], v[2], 1e-9), fade = (l < 420) ? 0.3 + 0.7 * (l - 380) / 40 : (l > 700) ? 0.3 + 0.7 * (750 - l) / 50 : 1;
   for (var k = 0; k < 3; ++k) { var x = v[k] / m; v[k] = Math.round(255 * fade * ((x <= 0.0031308) ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055)); }
   return v;
}

// ---------------------------------------------------------------------------
// LAS LINEAS, MEDIDAS SOBRE EL ESPECTRO COMPLETO
// ---------------------------------------------------------------------------
function fvsXpMeanIn_(lam, flux, err, a, b) {
   var s = 0, se = 0, n = 0, ne = 0;
   for (var i = 0; i < lam.length; ++i) if (lam[i] >= a && lam[i] <= b && isFinite(flux[i])) { s += flux[i]; ++n; if (err && isFinite(err[i]) && err[i] > 0) { se += err[i] * err[i]; ++ne; } }
   if (!n) return null;
   // σ de la media: con los errores publicados (correlacionados: optimista, ver cabecera); sin errores, null
   return { m: s / n, s: ne ? Math.sqrt(se / ne) / Math.sqrt(n) : null, x: 0.5 * (a + b) };
}
// -> [{ k, nm, d (profundidad, 0–1; negativa = el nucleo sale POR ENCIMA del continuo), sig (σ de d o null), seen (bool) }]
function fvsXpMeasureLines(lam, flux, err) {
   var out = [];
   for (var i = 0; i < FVS_XP.LINES.length; ++i) {
      var Ln = FVS_XP.LINES[i], A = fvsXpMeanIn_(lam, flux, err, Ln.cl[0], Ln.cl[1]), B = fvsXpMeanIn_(lam, flux, err, Ln.cr[0], Ln.cr[1]), C = fvsXpMeanIn_(lam, flux, err, Ln.nm - Ln.core, Ln.nm + Ln.core);
      if (!A || !B || !C) continue;
      var cont = A.m + (B.m - A.m) * (Ln.nm - A.x) / (B.x - A.x);
      if (!(cont > 0)) continue;
      var d = 1 - C.m / cont, sig = (C.s !== null && A.s !== null && B.s !== null) ? Math.sqrt(C.s * C.s + 0.25 * (A.s * A.s + B.s * B.s)) / cont : null;
      out.push({ k: Ln.k, nm: Ln.nm, d: d, sig: sig, seen: (d > FVS_XP.DEPTH_MIN && (sig === null || d > FVS_XP.DEPTH_SIG * sig)) });
   }
   return out;
}

// ---------------------------------------------------------------------------
// EL ESPECTRO COMPACTO (lo que guarda la escena y viaja al visor web)
// ---------------------------------------------------------------------------
// lam, flux, err: el espectro de Gaia (nm, W m⁻² nm⁻¹); src: "local" | "esa" | "ari" (de donde vino). ->
//   { v: 1, l0, l1, n, f: [enteros 0–1000, el tramo mas alto = 1000], e: [enteros, misma escala] | null, fmax (W m⁻² nm⁻¹),
//     fitT (K, cuerpo negro que mejor casa: temperatura de COLOR), lines: [{ k, d (milesimas), s (milesimas o -1), v (1 vista / 0) }], src }
// null si no hay espectro util (menos de 50 puntos).
function fvsXpCompact(lam, flux, err, src) {
   if (!lam || !flux || lam.length < 50) return null;
   var NC = FVS_XP.NC, a = Math.max(FVS_XP.L0, lam[0]), b = Math.min(FVS_XP.L0 + FVS_XP.STEP * (FVS_XP.N - 1), lam[lam.length - 1]), w = (b - a) / NC, i, j;
   // medias por tramo; la escala: el tramo mas alto = 1000 (en una caliente es el extremo azul)
   var fr = [], er = [], hasE = (err && err.length === lam.length), mx = 0;
   for (j = 0; j < NC; ++j) {
      var x0 = a + j * w, x1 = x0 + w, s = 0, se = 0, n = 0;
      for (i = 0; i < lam.length; ++i) if (lam[i] >= x0 && (lam[i] < x1 || (j === NC - 1 && lam[i] <= x1)) && isFinite(flux[i])) { s += flux[i]; if (hasE && isFinite(err[i])) se += err[i] * err[i]; ++n; }
      fr.push(n ? s / n : 0); er.push(n ? Math.sqrt(se / n) : 0);
      if (n && s / n > mx) mx = s / n;
   }
   if (!(mx > 0)) return null;
   var f = [], e = hasE ? [] : null;
   for (j = 0; j < NC; ++j) { f.push(Math.max(0, Math.round(1000 * fr[j] / mx))); if (e) e.push(Math.round(1000 * er[j] / mx)); }
   var fit = fvsXpBbTeff(lam, flux, err), L = fvsXpMeasureLines(lam, flux, err), lines = [];
   for (i = 0; i < L.length; ++i) lines.push({ k: L[i].k, d: Math.round(1000 * L[i].d), s: (L[i].sig !== null && isFinite(L[i].sig)) ? Math.round(1000 * L[i].sig) : -1, v: L[i].seen ? 1 : 0 });
   return { v: 1, l0: Math.round(a * 10) / 10, l1: Math.round(b * 10) / 10, n: NC, f: f, e: e, fmax: Number(mx.toPrecision(4)), fitT: fit ? Math.round(fit.teff) : 0,
            fitEdge: fit && fit.edge ? 1 : 0, lines: lines, src: src || "" };
}
// la longitud de onda (nm) del centro del punto j del compacto
function fvsXpLam(X, j) { return X.l0 + (j + 0.5) * (X.l1 - X.l0) / X.n; }
// el cuerpo negro de `teff` escalado al compacto (minimos cuadrados en FIT0–FIT1, sin pesos), en sus mismos puntos (escala 0–1000). -> [n] | null
function fvsXpBbCurve(X, teff) {
   if (!X || !(teff > 0)) return null;
   var lam = [], fl = [], j;
   for (j = 0; j < X.n; ++j) { lam.push(fvsXpLam(X, j)); fl.push(X.f[j]); }
   var sc = fvsXpPlanckScale(lam, fl, null, teff);
   if (!(sc.k > 0)) return null;
   var out = [];
   for (j = 0; j < X.n; ++j) out.push(sc.k * fvsXpPlanck(lam[j], teff));
   return out;
}
// ¿se marca la zona de TiO? (solo «esperada», en frias)
function fvsXpTioExpected(teff) { return teff > 0 && teff < FVS_XP.TIO_TEFF; }
// la definicion de una linea por su clave
function fvsXpLineDef(k) { for (var i = 0; i < FVS_XP.LINES.length; ++i) if (FVS_XP.LINES[i].k === k) return FVS_XP.LINES[i]; return null; }

// ---------------------------------------------------------------------------
// TEXTOS DEL PANEL (EN/ES): viajan con el modulo a la web
// ---------------------------------------------------------------------------
var FVS_XP_TX = {
   en: { "xp.title": "GAIA DR3 · XP SPECTRUM", "xp.scan": "ANALYSING  {nm} nm", "xp.fetch": "XP SPECTRUM · asking Gaia…",
         "xp.none": "no XP spectrum in Gaia DR3", "xp.faint": "no XP spectrum in Gaia DR3 (G {g}: published only for G < 17.65)",
         "xp.off": "XP spectrum: Gaia did not answer (no network)", "xp.read": "T ≈ {t} · {spt}", "xp.readNoT": "colour temperature ≈ {t}",
         "xp.bb": "black body {t}", "xp.fit": "best-fit black body {t} (colour temperature: dust reddens it)", "xp.tio": "TiO (expected)",
         "xp.src.local": "Gaia DR3/SP (local)", "xp.src.esa": "ESA Gaia archive", "xp.src.ari": "Gaia archive ARI", "xp.seen": "{l} −{d} %", "xp.notSeen": "{l}" },
   es: { "xp.title": "GAIA DR3 · ESPECTRO XP", "xp.scan": "ANALIZANDO  {nm} nm", "xp.fetch": "ESPECTRO XP · consultando Gaia…",
         "xp.none": "sin espectro XP en Gaia DR3", "xp.faint": "sin espectro XP en Gaia DR3 (G {g}: solo se publica para G < 17,65)",
         "xp.off": "espectro XP: Gaia no contestó (sin red)", "xp.read": "T ≈ {t} · {spt}", "xp.readNoT": "temperatura de color ≈ {t}",
         "xp.bb": "cuerpo negro {t}", "xp.fit": "el cuerpo negro que mejor casa: {t} (temperatura de color: el polvo la enrojece)", "xp.tio": "TiO (esperada)",
         "xp.src.local": "Gaia DR3/SP (local)", "xp.src.esa": "archivo Gaia de la ESA", "xp.src.ari": "archivo Gaia ARI", "xp.seen": "{l} −{d} %", "xp.notSeen": "{l}" }
};
function fvsXpT(lang, key, params) {
   var tab = FVS_XP_TX[(lang === "es") ? "es" : "en"], s = tab.hasOwnProperty(key) ? tab[key] : (FVS_XP_TX.en[key] || key);
   if (params) for (var k in params) if (params.hasOwnProperty(k)) s = s.split("{" + k + "}").join(String(params[k]));
   return s;
}
