// ============================================================================
// FieldVoyager/src/science/fv_sci_colour.js — EL COLOR DE UNA ESTRELLA: CUERPO NEGRO → OJO (CIE 1931) → PANTALLA (sRGB)
// ----------------------------------------------------------------------------
// Calculado aqui, no copiado de ninguna tabla (ni la de Celestia ni la de M. Charity):
//   1. Ley de Planck B_λ(T) = 2hc²/λ⁵ / (exp(c2/λT) − 1), c2 = hc/k (constantes exactas del SI 2019, fv_sci_const.js).
//   2. Funciones de igualacion de color del OBSERVADOR PATRON CIE 1931 2° con el ajuste analitico «multi-lobe» de
//      Wyman, Sloan & Shirley 2013, «Simple Analytic Approximations to the CIE XYZ Color Matching Functions»,
//      JCGT 2(2), 1-11, ec. 4 y Tabla 1 (coeficientes leidos en el PDF el 3-nov-2026). Su error frente a la tabla de la
//      CIE es menor que la dispersion entre observadores del propio patron (su Tabla 2). Se integra de 360 a 830 nm cada 5 nm
//      (el paso de las sumas de la norma ASTM E308; con 1 nm la cromaticidad cambia < 1e-4 y la tabla tarda 5 veces mas).
//      LIMITE MEDIDO: el ajuste se queda corto en la cola roja (x̄(700 nm) = 0,0056 frente a 0,0114 de la CIE), y por debajo
//      de ~2500 K el color se desvia hasta 0,005 en xy (1700 K) del lugar de Planck: algo menos rojo. Visualmente minimo.
//   3. XYZ → sRGB lineal con la matriz de la norma IEC 61966-2-1:1999 (blanco D65) y la curva de transferencia de sRGB
//      (lineal por debajo de 0,0031308; 1,055·x^(1/2,4) − 0,055 por encima).
// Decisiones (documentadas porque cambian lo que se ve):
//   · SIN adaptacion cromatica: el blanco de la pantalla es D65 (~6500 K). Asi el Sol (5772 K) sale algo calido y una
//     estrella de 6500 K sale casi blanca, como en la tabla de Charity con blanco D65. Es la convencion fisica honesta.
//   · Se normaliza para que el canal mayor valga 1 (el brillo lo pone el pintor por la magnitud, no el color).
//   · Fuera del gamut (componentes negativas, p. ej. por debajo de ~1900 K el azul): se desatura hacia el blanco sumando
//     lo que falta a los tres canales (conserva el tono dominante). Se marca `clipped`.
//   · Color «exagerado» para la ficha de cine: se multiplica la saturacion HSV por FVS_COLOUR_EXAG (tope 1), sin tocar
//     tono ni valor. Es un efecto ESTETICO (no entra en ninguna medida). Una estrella de ~6500 K sigue casi blanca.
// Validado en la prueba contra el Iluminante A de la CIE (cuerpo negro a 2856 K: x = 0,44757, y = 0,40745, CIE 15:2004)
// y contra el ajuste del lugar de Planck de Kim et al. (US 7 024 034, 2006) de 1667 a 25 000 K.
// ES5. Sin PixInsight.
// ============================================================================

var FVS_COLOUR_EXAG = 2.5;          // factor de saturacion HSV de la ficha (eleccion estetica nuestra; 1 = sin exagerar)

// Gaussiana a trozos de Wyman et al. 2013: sigmas inversas (izquierda, derecha) de su Tabla 1
function fvsCmfG_(lam, mu, invL, invR) { var t = (lam - mu) * (lam < mu ? invL : invR); return Math.exp(-0.5 * t * t); }
// x̄, ȳ, z̄ del observador CIE 1931 2° (λ en nm) → [x̄, ȳ, z̄]
function fvsCmf1931(lam) {
   return [
      0.362 * fvsCmfG_(lam, 442.0, 0.0624, 0.0374) + 1.056 * fvsCmfG_(lam, 599.8, 0.0264, 0.0323) - 0.065 * fvsCmfG_(lam, 501.1, 0.0490, 0.0382),
      0.821 * fvsCmfG_(lam, 568.8, 0.0213, 0.0247) + 0.286 * fvsCmfG_(lam, 530.9, 0.0613, 0.0322),
      1.217 * fvsCmfG_(lam, 437.0, 0.0845, 0.0278) + 0.681 * fvsCmfG_(lam, 459.0, 0.0385, 0.0725)
   ];
}

// Radiancia espectral de Planck B_λ(T) en W m^-2 sr^-1 m^-1 (λ en metros, T en K)
function fvsPlanck(lamM, tK) {
   var x = FVS.C2_MK / (lamM * tK);
   if (x > 700) return 0;
   return 2 * FVS.H_JS * FVS.C_MS * FVS.C_MS / Math.pow(lamM, 5) / (Math.exp(x) - 1);
}

// XYZ de un cuerpo negro (escala arbitraria: Y relativo) y su cromaticidad x, y
function fvsBlackbodyXYZ(tK) {
   var X = 0, Y = 0, Z = 0;
   for (var lam = 360; lam <= 830; lam += 5) {
      var b = fvsPlanck(lam * 1e-9, tK), c = fvsCmf1931(lam);
      X += b * c[0]; Y += b * c[1]; Z += b * c[2];
   }
   var s = X + Y + Z;
   return { X: X / Y, Y: 1, Z: Z / Y, x: X / s, y: Y / s };
}

// XYZ → sRGB lineal (IEC 61966-2-1, D65)
function fvsXyzToLinearSrgb(X, Y, Z) {
   return [ 3.2406 * X - 1.5372 * Y - 0.4986 * Z,
           -0.9689 * X + 1.8758 * Y + 0.0415 * Z,
            0.0557 * X - 0.2040 * Y + 1.0570 * Z];
}
function fvsSrgbGamma(v) { return (v <= 0.0031308) ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055; }
function fvsSrgbLinear(v) { return (v <= 0.04045) ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
function fvsHex2_(v) { var s = Math.round(Math.max(0, Math.min(255, v))).toString(16); return s.length < 2 ? "0" + s : s; }
function fvsRgbHex(r, g, b) { return "#" + fvsHex2_(r) + fvsHex2_(g) + fvsHex2_(b); }

// Color de cuerpo negro EXACTO (integra el espectro: ~470 longitudes de onda). → { r, g, b (0-255), hex, lin:[...], x, y, clipped }
function fvsBlackbodyColourExact(tK) {
   var xyz = fvsBlackbodyXYZ(tK), lin = fvsXyzToLinearSrgb(xyz.X, xyz.Y, xyz.Z), clipped = false;
   var mn = Math.min(lin[0], lin[1], lin[2]);
   if (mn < 0) { clipped = true; lin = [lin[0] - mn, lin[1] - mn, lin[2] - mn]; }
   var mx = Math.max(lin[0], lin[1], lin[2]);
   lin = [lin[0] / mx, lin[1] / mx, lin[2] / mx];
   var r = 255 * fvsSrgbGamma(lin[0]), g = 255 * fvsSrgbGamma(lin[1]), b = 255 * fvsSrgbGamma(lin[2]);
   return { r: Math.round(r), g: Math.round(g), b: Math.round(b), hex: fvsRgbHex(r, g, b), lin: lin, x: xyz.x, y: xyz.y, clipped: clipped };
}

// Tabla perezosa: 1000-50 000 K en pasos de 0,5 % de log T (≈ 790 entradas, se calcula UNA vez la primera vez que se pide).
// Para pintar miles de estrellas sin integrar el espectro cada vez. La prueba comprueba que difiere de la exacta < 1/255.
var FVS_BB_LUT_ = null, FVS_BB_T0 = 1000, FVS_BB_T1 = 50000, FVS_BB_STEP = 0.005;
function fvsBbLut_() {
   if (FVS_BB_LUT_) return FVS_BB_LUT_;
   var n = Math.ceil(Math.log(FVS_BB_T1 / FVS_BB_T0) / FVS_BB_STEP) + 1, a = [];
   for (var i = 0; i < n; ++i) a.push(fvsBlackbodyColourExact(FVS_BB_T0 * Math.exp(i * FVS_BB_STEP)).lin);
   FVS_BB_LUT_ = a;
   return a;
}
// Color de cuerpo negro RAPIDO (interpolado en la tabla, en sRGB lineal). Fuera de 1000-50 000 K, el borde (`clamped`).
function fvsBlackbodyColour(tK) {
   var a = fvsBbLut_(), clamped = false;
   if (!(tK >= FVS_BB_T0)) { tK = FVS_BB_T0; clamped = true; }
   if (tK > FVS_BB_T1) { tK = FVS_BB_T1; clamped = true; }
   var f = Math.log(tK / FVS_BB_T0) / FVS_BB_STEP, i = Math.min(a.length - 2, Math.floor(f)), w = f - i;
   var lin = [a[i][0] + w * (a[i + 1][0] - a[i][0]), a[i][1] + w * (a[i + 1][1] - a[i][1]), a[i][2] + w * (a[i + 1][2] - a[i][2])];
   var mx = Math.max(lin[0], lin[1], lin[2]);
   lin = [lin[0] / mx, lin[1] / mx, lin[2] / mx];
   var r = 255 * fvsSrgbGamma(lin[0]), g = 255 * fvsSrgbGamma(lin[1]), b = 255 * fvsSrgbGamma(lin[2]);
   return { r: Math.round(r), g: Math.round(g), b: Math.round(b), hex: fvsRgbHex(r, g, b), lin: lin, clamped: clamped };
}

// RGB (0-255) ↔ HSV (h en grados, s y v de 0 a 1)
function fvsRgbToHsv(r, g, b) {
   r /= 255; g /= 255; b /= 255;
   var mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn, h = 0;
   if (d > 0) {
      if (mx === r) h = 60 * (((g - b) / d) % 6);
      else if (mx === g) h = 60 * ((b - r) / d + 2);
      else h = 60 * ((r - g) / d + 4);
   }
   if (h < 0) h += 360;
   return { h: h, s: mx > 0 ? d / mx : 0, v: mx };
}
function fvsHsvToRgb(h, s, v) {
   var c = v * s, hp = (h % 360) / 60, x = c * (1 - Math.abs(hp % 2 - 1)), m = v - c, r = 0, g = 0, b = 0;
   if (hp < 1) { r = c; g = x; } else if (hp < 2) { r = x; g = c; } else if (hp < 3) { g = c; b = x; }
   else if (hp < 4) { g = x; b = c; } else if (hp < 5) { r = x; b = c; } else { r = c; b = x; }
   return [Math.round(255 * (r + m)), Math.round(255 * (g + m)), Math.round(255 * (b + m))];
}
// Color EXAGERADO de la ficha: saturacion HSV × k (FVS_COLOUR_EXAG por defecto), tope 1; tono y valor intactos.
function fvsExaggerateColour(c, k) {
   var hsv = fvsRgbToHsv(c.r, c.g, c.b), kk = (k > 0) ? k : FVS_COLOUR_EXAG;
   var s = Math.min(1, hsv.s * kk), rgb = fvsHsvToRgb(hsv.h, s, hsv.v);
   return { r: rgb[0], g: rgb[1], b: rgb[2], hex: fvsRgbHex(rgb[0], rgb[1], rgb[2]), sat0: hsv.s, sat: s, hue: hsv.h, k: kk };
}

// Lugar de Planck aproximado de Kim et al. (US 7 024 034, 2006; tambien Kang et al. 2002, J. Korean Phys. Soc. 41, 865):
// SOLO para la prueba (referencia independiente del integrador de arriba). Valido 1667-25 000 K.
function fvsKimLocus(tK) {
   var T = tK, x, y;
   if (T <= 4000) x = -0.2661239e9 / (T * T * T) - 0.2343589e6 / (T * T) + 0.8776956e3 / T + 0.179910;
   else x = -3.0258469e9 / (T * T * T) + 2.1070379e6 / (T * T) + 0.2226347e3 / T + 0.240390;
   if (T <= 2222) y = -1.1063814 * x * x * x - 1.34811020 * x * x + 2.18555832 * x - 0.20219683;
   else if (T <= 4000) y = -0.9549476 * x * x * x - 1.37418593 * x * x + 2.09137015 * x - 0.16748867;
   else y = 3.0817580 * x * x * x - 5.87338670 * x * x + 3.75112997 * x - 0.37001483;
   return { x: x, y: y };
}
