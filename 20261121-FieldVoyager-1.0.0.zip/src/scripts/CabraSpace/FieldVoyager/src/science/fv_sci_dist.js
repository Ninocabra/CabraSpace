// ============================================================================
// FieldVoyager/src/science/fv_sci_dist.js — DISTANCIA CON SU INCERTIDUMBRE, CONVERSIONES Y TIEMPO DE LUZ (3-nov-2026)
// ----------------------------------------------------------------------------
// Unidades: paralaje en mas; distancias en pc y en años luz (al); tiempos en años.
// Reglas de calidad = las de FieldDepth3D (CabraShared/csh_starfield.js):
//   · Paralaje con error relativo σϖ/ϖ > 20 % → NO se invierte con confianza (Bailer-Jones 2015, PASP 127, 994: por encima
//     de ~20 % la inversa es un estimador sesgado y su intervalo deja de ser simetrico): quality = "doubtful".
//   · RUWE ≥ 1,4 → astrometria sospechosa (documentacion de Gaia DR2): quality = "doubtful", why = "ruwe". La distancia
//     NO se borra: se marca.
//   · Cero de la paralaje de Gaia DR3: −0,017 mas (Lindegren et al. 2021, A&A 649, A4), SOLO si inp.zp === true
//     (ϖ_corregida = ϖ − (−0,017)). Quien llama decide, igual que csh_starfield con los datos de red.
//   · Si viene la distancia de Bailer-Jones et al. 2021 (rgeo, con su 16-84 %), manda sobre la inversa de la paralaje.
// Intervalo de 1σ desde la paralaje: [1000/(ϖ+σ), 1000/(ϖ−σ)] pc (si ϖ ≤ σ, el extremo lejano es infinito).
// Tiempo de luz: una distancia de d al es, por definicion del año luz, d años de viaje de la luz (año juliano).
// ES5. Sin PixInsight.
// ============================================================================

function fvsPcToLy(pc) { return pc * FVS.PC_LY; }

// inp = { plx, plxErr (mas), ruwe, zp (true = corregir el cero), rgeo: { pc, lo, hi } }
// → { pc, ly, lo, hi (pc, 1σ), loLy, hiLy, frac, quality: "good" | "doubtful" | "none", why: [...], src }
function fvsDistance(inp) {
   var o = { pc: NaN, ly: NaN, lo: NaN, hi: NaN, loLy: NaN, hiLy: NaN, frac: NaN, quality: "none", why: [], src: "" };
   if (inp && inp.rgeo && inp.rgeo.pc > 0) {
      o.pc = inp.rgeo.pc; o.lo = inp.rgeo.lo > 0 ? inp.rgeo.lo : NaN; o.hi = inp.rgeo.hi > 0 ? inp.rgeo.hi : NaN;
      o.src = "bailer-jones2021"; o.quality = "good";
      if (o.lo > 0 && o.hi > 0) o.frac = (o.hi - o.lo) / (2 * o.pc);
   } else if (inp && inp.plx !== undefined && inp.plx !== null) {
      var p = inp.plx - ((inp.zp === true) ? FVS.PLX_ZERO_POINT_MAS : 0), s = inp.plxErr;
      if (!(p > 0)) { o.why.push("parallax<=0"); return o; }
      o.pc = 1000 / p; o.src = (inp.zp === true) ? "parallax-zp" : "parallax"; o.quality = "good";
      if (s > 0) {
         o.frac = s / p;
         o.lo = 1000 / (p + s);
         o.hi = (p > s) ? 1000 / (p - s) : Infinity;
         if (o.frac > FVS.PLX_MAX_FRAC) { o.quality = "doubtful"; o.why.push("error>20%"); }
      } else o.why.push("no-error");
   } else { o.why.push("no-parallax"); return o; }
   if (inp.ruwe !== undefined && inp.ruwe !== null && isFinite(inp.ruwe) && inp.ruwe >= FVS.RUWE_MAX) { o.quality = "doubtful"; o.why.push("ruwe"); }
   o.ly = fvsPcToLy(o.pc); o.loLy = fvsPcToLy(o.lo); o.hiLy = fvsPcToLy(o.hi);
   return o;
}

// ---------------- tiempo de luz y la efemeride de esa epoca ----------------
// año historico (negativo = a. C., sin año 0) ↔ año astronomico (0 = 1 a. C.)
function fvsHistToAstro(y) { return (y < 0) ? y + 1 : y; }
function fvsAstroToHist(y) { return (y < 1) ? y - 1 : y; }

// La luz que vemos hoy (año obsYear, el de la foto) salio hace dLy años. → {
//   mode: "now" (< 1 año) | "year" (< 15 000 años: con año y efemeride historica) | "deep" (tiempo profundo),
//   ago (años), year (astronomico, decimal), yearHist (entero, historico), event: { year | ago, en, es, approx },
//   rel: "same" | "before" | "after" (la luz salio antes/despues de la efemeride), gap (años entre las dos, > 0) }
var FVS_DEEP_YEARS = 15000;
function fvsLightEpoch(dLy, obsYear) {
   var now = (obsYear > 0) ? obsYear : (new Date()).getFullYear(), o = { ago: dLy, mode: "now" };
   if (!(dLy >= 1)) return o;
   if (dLy < FVS_DEEP_YEARS) {
      var y = now - dLy, best = null, bd = 1e30, H = FVS_HISTORY.years;
      for (var i = 0; i < H.length; ++i) {
         var ey = fvsHistToAstro(H[i][0]);
         if (ey > now - 1) continue;
         var d = Math.abs(ey - y);
         if (d < bd) { bd = d; best = H[i]; }
      }
      o.mode = "year"; o.year = y; o.yearHist = fvsAstroToHist(Math.round(y));
      if (best) {
         var eya = fvsHistToAstro(best[0]);
         o.event = { year: best[0], approx: best[1], en: best[2], es: best[3] };
         o.gap = Math.abs(eya - y);
         o.rel = (o.gap < 1) ? "same" : (y < eya ? "before" : "after");
      }
      return o;
   }
   var A = FVS_HISTORY.ago, b2 = null, bl = 1e30;
   for (var j = 0; j < A.length; ++j) { var dl = Math.abs(Math.log(A[j][0] / dLy)); if (dl < bl) { bl = dl; b2 = A[j]; } }
   o.mode = "deep";
   o.event = { ago: b2[0], approx: true, en: b2[1], es: b2[2] };
   o.gap = Math.abs(dLy - b2[0]);
   o.rel = (bl < Math.log(1.15)) ? "same" : (dLy > b2[0] ? "before" : "after");
   return o;
}
