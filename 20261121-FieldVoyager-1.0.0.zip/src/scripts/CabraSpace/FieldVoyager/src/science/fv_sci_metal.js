// ============================================================================
// FieldVoyager/src/science/fv_sci_metal.js — LA METALICIDAD EN LA FICHA (Nino, 5-nov-2026: «en el resumen, algo de su metalicidad si es
// posible, y en la ficha extendida algo mas»)
// ----------------------------------------------------------------------------
// Puro (sin PixInsight, sin red): lo cargan PixInsight (#include) y el visor web (<script>, despues de fv_sci_chem.js).
//   fvsMetalPhotOk(v, teff)        ¿se puede usar el [M/H] de GSP-Phot de esta estrella? (rango de Teff validado, abajo)
//   fvsMetalBuild(chem, phot)      -> el registro compacto (lo que viaja en sci.metal) | null sin dato
//        chem = el compacto de fvsChemBuild (GALAH > APOGEE > LAMOST > GSP-Spec con sus banderas y calibracion) | null
//        phot = { v: [M/H] de GSP-Phot, teff: Teff de GSP-Phot } | null
//        teff = la Teff de la ficha (meta.teff; opcional): con GSP-Spec por encima de SPEC_TEFF_MAX, DUDOSO «estrella caliente»
//   fvsMetalSummary(M, lang)       -> UNA linea corta para el resumen («Metales: como el Sol · [M/H] −0,04»)
//   fvsMetalDetails(M, lang)       -> las lineas de «MÁS» (lo que NO dicen ya las de fvsChemDetails: la comparacion con el Sol, que
//                                     significa [α/Fe] y, sin espectro, el valor fotometrico con su fuente y su aviso)
// FIABILIDAD (como el sello de la ficha): q 0 = MEDIDO (espectroscopia que pasa sus banderas, error <= E_DOUBT) · q 1 = DUDOSO (GSP-Phot,
// error grande o catalogos que discrepan). No hay SUPUESTO: sin dato no se dice nada (la ficha no cambia ni deja hueco).
// PROCEDENCIA: la prioridad de catalogos, las banderas y la calibracion de GSP-Spec son las de fv_sci_chem.js (copiadas de
// CabraComposition/src/cc_science.js:381-454); lo nuevo aqui es GSP-Phot como reserva y las frases. ES5.
// ============================================================================

var FV_METAL = {
   ON: true,                 // false = la ficha de antes, pixel a pixel (el ROJO de tests/fv_metal_test.js)
   E_DOUBT: 0.20,            // espectroscopia con error > 0,20 dex o catalogos que discrepan: DUDOSO (eleccion nuestra)
   // GSP-Phot (Andrae et al. 2023, A&A 674, A27): sus horquillas de [M/H] son de ±0,01 dex, irreales. MEDIDO el 5-nov en Collinder 34
   // (archivo de Gaia, ARI; 105 estrellas con GSP-Spec que pasa sus banderas, calibrada): GSP-Phot − GSP-Spec = mediana −0,14 dex,
   // dispersion robusta 0,26 dex (3 810–7 435 K). Suelo del error: 0,25 dex. Fuera de ese rango de Teff no se ha validado: no se usa.
   PHOT_FLOOR: 0.25,
   PHOT_TEFF: [3800, 7500],
   // GSP-Spec en estrellas calientes: su rejilla de espectros sinteticos llega hasta 8 000 K (Recio-Blanco et al. 2023, A&A 674, A29, §2;
   // NO VERIFICADO contra el texto). MEDIDO el 5-nov en Collinder 34: una B9.5V a 10 180 K pasa las 13 banderas con [M/H] −3,77 ± 0,56 y la
   // frase de I13 la llamaba «una estrella vieja del halo». Por encima de este limite (Teff de la ficha) la cifra no se da por buena.
   SPEC_TEFF_MAX: 8000,
   SUN_DEX: 0.15,            // |[M/H]| <= 0,15: «como el Sol» (= FVS_CHEM.SOLAR_DEX)
   POOR_DEX: -0.5,           // por debajo: «pobre en metales»
   VPOOR_DEX: -1.0           // por debajo: «muy pobre: estrella vieja» (= FVS_CHEM.HALO_FEH, Bensby et al. 2014)
};
var FVS_METAL_REF = { gspphot: "Andrae et al. 2023, A&A 674, A27" };

function fvsMetalPhotOk(v, teff) { return typeof v === "number" && isFinite(v) && typeof teff === "number" && isFinite(teff) && teff >= FV_METAL.PHOT_TEFF[0] && teff <= FV_METAL.PHOT_TEFF[1]; }
function fvsMetalRel(v) { return v > FV_METAL.SUN_DEX ? "rich" : (v >= -FV_METAL.SUN_DEX ? "sun" : (v > FV_METAL.POOR_DEX ? "slpoor" : (v > FV_METAL.VPOOR_DEX ? "poor" : "vpoor"))); }
// -> { v, e, s (catalogo), px ("[M/H]" | "[Fe/H]"), q (0 MEDIDO | 1 DUDOSO), why ("" | "phot" | "err" | "disc"), rel, x (veces el Sol),
//      afe: { v, e, hi (bool: por encima de la frontera de Weinberg) } | null, pop ("thin" | "thick" | "halo" | "") }
function fvsMetalBuild(chem, phot, teff) {
   var M = null;
   if (chem && chem.feh && typeof chem.feh.v === "number" && isFinite(chem.feh.v)) {
      var e = (typeof chem.feh.e === "number" && isFinite(chem.feh.e)) ? chem.feh.e : null, why = chem.disc ? "disc" : ((e !== null && e > FV_METAL.E_DOUBT) ? "err" : "");
      M = { v: chem.feh.v, e: e, s: chem.feh.s, px: (chem.feh.s === "gspspec") ? "[M/H]" : "[Fe/H]", q: why ? 1 : 0, why: why, afe: null, pop: "" };
      if (chem.afe && typeof chem.afe.v === "number") M.afe = { v: chem.afe.v, e: chem.afe.e, hi: !!(chem.cls && chem.cls.p !== null && chem.cls.p >= 0.5) };
      if (chem.cls && chem.cls.conf && (chem.cls.c === "thin" || chem.cls.c === "thick" || chem.cls.c === "halo")) M.pop = chem.cls.c;
      if (M.s === "gspspec" && typeof teff === "number" && teff > FV_METAL.SPEC_TEFF_MAX) { M.q = 1; M.why = "hot"; M.pop = ""; M.afe = null; M.teff = Math.round(teff); }
   } else if (phot && fvsMetalPhotOk(phot.v, phot.teff)) {
      M = { v: phot.v, e: FV_METAL.PHOT_FLOOR, s: "gspphot", px: "[M/H]", q: 1, why: "phot", afe: null, pop: "" };
   }
   if (!M) return null;
   M.v = Math.round(M.v * 1000) / 1000; if (M.e !== null) M.e = Math.round(M.e * 1000) / 1000;
   M.rel = fvsMetalRel(M.v);
   var x = Math.pow(10, M.v); M.x = (x >= 1) ? Math.round(x * 10) / 10 : Number(x.toPrecision(2));
   return M;
}

var FVS_METAL_TX = {
   en: {
      "s.rich": "Metals: more than the Sun", "s.sun": "Metals: like the Sun", "s.slpoor": "Metals: a little fewer than the Sun",
      "s.poor": "Metal-poor", "s.vpoor": "Very metal-poor: an old star", "s.vpoorPhot": "Metals: very few",
      "s.est": " (estimated)", "s.hot": "Metals: no reliable figure (hot star)", "lt": "less than 0.01",
      "d.hot": "[M/H] = {v} from Gaia DR3 GSP-Spec, not reliable: at {t} K the star lies outside the GSP-Spec grid (up to 8 000 K); no population is inferred", "pop.thin": "thin disc", "pop.thick": "thick disc, old",
      "d.sun": "Compared with the Sun: {x} times its share of metals (everything heavier than helium){alpha}",
      "d.sunPhot": "Compared with the Sun: about {x} times its share of metals (everything heavier than helium)",
      "d.alphaLo": "; low [α/Fe], like the Sun: a recent generation of the disc",
      "d.alphaHi": "; high [α/Fe]: born early and fast, like the thick disc and the halo",
      "d.phot": "[M/H] ≈ {v} ± {e} · photometric estimate · Gaia DR3 GSP-Phot ({ref})",
      "d.photWhy": "No spectrum: the figure comes from Gaia's BP/RP colours and can be off by ~{e} dex; no population is inferred from it",
      "d.doubt.err": "Doubtful: the uncertainty ({e} dex) is large", "d.doubt.disc": "Doubtful: the catalogues disagree (see the warning below)"
   },
   es: {
      "s.rich": "Metales: más que el Sol", "s.sun": "Metales: como el Sol", "s.slpoor": "Metales: algo menos que el Sol",
      "s.poor": "Pobre en metales", "s.vpoor": "Muy pobre en metales: estrella vieja", "s.vpoorPhot": "Metales: muy pocos",
      "s.est": " (estimados)", "s.hot": "Metales: sin cifra fiable (estrella caliente)", "lt": "menos de 0,01",
      "d.hot": "[M/H] = {v} de Gaia DR3 GSP-Spec, no fiable: a {t} K la estrella queda fuera de la rejilla de GSP-Spec (hasta 8 000 K); no se deduce la población", "pop.thin": "disco fino", "pop.thick": "disco grueso, antigua",
      "d.sun": "Comparada con el Sol: {x} veces su proporción de metales (todo lo más pesado que el helio){alpha}",
      "d.sunPhot": "Comparada con el Sol: unas {x} veces su proporción de metales (todo lo más pesado que el helio)",
      "d.alphaLo": "; [α/Fe] bajo, como el Sol: una generación reciente del disco",
      "d.alphaHi": "; [α/Fe] alto: nació pronto y deprisa, como el disco grueso y el halo",
      "d.phot": "[M/H] ≈ {v} ± {e} · estimación fotométrica · Gaia DR3 GSP-Phot ({ref})",
      "d.photWhy": "Sin espectro: la cifra sale de los colores BP/RP de Gaia y puede errar ~{e} dex; de ella no se deduce la población",
      "d.doubt.err": "Dudosa: la incertidumbre ({e} dex) es grande", "d.doubt.disc": "Dudosa: los catálogos discrepan (ver el aviso de abajo)"
   }
};
function fvsMetalT(lang, key, p) {
   var tab = FVS_METAL_TX[(lang === "es") ? "es" : "en"], s = tab.hasOwnProperty(key) ? tab[key] : (FVS_METAL_TX.en[key] || key);
   if (p) for (var k in p) if (p.hasOwnProperty(k)) s = s.split("{" + k + "}").join(String(p[k]));
   return s;
}
function fvsMetalNum(x, d, lang) { var s = x.toFixed(d); return (lang === "es") ? s.replace(".", ",") : s; }
// numero con signo y coma del idioma (como fvsChemSgn, sin depender de que este cargado)
function fvsMetalSgn(x, d, lang) { var s = Math.abs(x).toFixed(d); if (lang === "es") s = s.replace(".", ","); return (x < 0 && Number(s.replace(",", ".")) !== 0 ? "−" : "+") + s; }
// LA LINEA DEL RESUMEN ("" sin dato)
function fvsMetalSummary(M, lang) {
   if (!M) return "";
   var L = (lang === "es") ? "es" : "en", phot = (M.s === "gspphot"), key = "s." + M.rel;
   if (M.why === "hot") return fvsMetalT(L, "s.hot");
   if (phot && M.rel === "vpoor") key = "s.vpoorPhot";                       // de una cifra fotometrica no se dice «vieja»
   var s = fvsMetalT(L, key) + (phot ? fvsMetalT(L, "s.est") : "");
   s += " · " + M.px + (M.q ? " ≈ " : " ") + fvsMetalSgn(M.v, 2, L);     // (espacios duros: «[M/H] ≈ −0,43» no se parte al ajustar la linea)
   if (!phot && M.q === 0 && (M.pop === "thin" || M.pop === "thick")) s += " · " + fvsMetalT(L, "pop." + M.pop);
   return s;
}
// LAS LINEAS DE «MÁS» (las de fvsChemDetails siguen debajo cuando hay espectroscopia)
function fvsMetalDetails(M, lang) {
   var L = (lang === "es") ? "es" : "en", out = [];
   if (!M) return out;
   if (M.why === "hot") { out.push(fvsMetalT(L, "d.hot", { v: fvsMetalSgn(M.v, 2, L), t: String(M.teff).replace(/\B(?=(\d{3})+(?!\d))/g, " ") })); return out; }
   var xs = (M.x < 0.01) ? fvsMetalT(L, "lt") : fvsMetalNum(M.x, M.x >= 1 ? 1 : 2, L);
   if (M.s === "gspphot") {
      out.push(fvsMetalT(L, "d.phot", { v: fvsMetalSgn(M.v, 2, L), e: fvsMetalNum(M.e, 2, L), ref: FVS_METAL_REF.gspphot }));
      out.push(fvsMetalT(L, "d.sunPhot", { x: xs }));
      out.push(fvsMetalT(L, "d.photWhy", { e: fvsMetalNum(M.e, 2, L) }));
      return out;
   }
   out.push(fvsMetalT(L, "d.sun", { x: xs, alpha: M.afe ? fvsMetalT(L, M.afe.hi ? "d.alphaHi" : "d.alphaLo") : "" }));
   if (M.why === "err") out.push(fvsMetalT(L, "d.doubt.err", { e: fvsMetalNum(M.e, 2, L) }));
   else if (M.why === "disc") out.push(fvsMetalT(L, "d.doubt.disc"));
   return out;
}
