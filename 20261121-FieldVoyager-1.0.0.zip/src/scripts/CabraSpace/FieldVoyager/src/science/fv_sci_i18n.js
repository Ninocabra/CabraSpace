// ============================================================================
// FieldVoyager/src/science/fv_sci_i18n.js — TEXTOS EN + ES DEL MODULO CIENTIFICO Y FORMATO DE NUMEROS (3-nov-2026)
// ----------------------------------------------------------------------------
// FVS_I18N.en / FVS_I18N.es: las MISMAS claves en los dos idiomas (la prueba lo comprueba). Plantillas con {nombre}.
// fvsT(lang, clave, { nombre: valor }) → texto. Clave inexistente → la propia clave (y la prueba falla).
// Formato: ES con coma decimal y espacio fino duro (U+00A0) para los millares desde 4 cifras (como los informes de Nino:
// «6 451»); EN con punto decimal y coma de millares. Los años no se agrupan («1683»).
// ES5. Sin PixInsight.
// ============================================================================

var FVS_I18N = {
   en: {
      // --- unidades y piezas ---
      "u.ly1": "light-year", "u.ly": "light-years", "u.pc": "pc", "u.au": "au", "u.km": "km", "u.m": "m", "u.cm": "cm", "u.mm": "mm",
      "u.yr1": "year", "u.yr": "years", "u.day1": "day", "u.day": "days", "u.h": "h", "u.min": "min", "u.s": "s", "u.and": "and",
      "u.thousand": "thousand", "u.million1": "million", "u.million": "million", "u.billion": "billion", "u.trillion1": "trillion", "u.trillion": "trillion",
      "u.of": "", "u.bc": "BC", "u.pct": "{x}%", "u.ppm": "{x} ppm", "u.K": "{x} K", "u.c": "{x} c", "approx": "about {n}", "year.c": "c. {y}",
      // --- estrella ---
      "lum.more": "{x} times as luminous as the Sun", "lum.less": "{x} times fainter than the Sun", "lum.same": "about as luminous as the Sun",
      "rad.more": "{x} times the radius of the Sun", "rad.less": "{x} times smaller than the Sun", "rad.same": "about the size of the Sun",
      "rad.orbit": "in the Sun's place it would reach beyond the orbit of {planet}", "rad.orbit.in": "in the Sun's place it would swallow {planet}",
      "planet.mercury": "Mercury", "planet.venus": "Venus", "planet.earth": "the Earth", "planet.mars": "Mars", "planet.jupiter": "Jupiter",
      "planet.saturn": "Saturn", "planet.uranus": "Uranus", "planet.neptune": "Neptune",
      "temp": "surface at {t}", "temp.hotter": "{dt} hotter than the Sun", "temp.cooler": "{dt} cooler than the Sun", "temp.same": "as hot as the Sun",
      "mass": "about {m} solar masses", "mass.sun": "about the mass of the Sun",
      "life": "it will spend about {t} on the main sequence (the Sun, about {s})",
      "life.evolved": "it has already left the main sequence: it is a {cls}",
      "cls.V": "main-sequence (dwarf) star", "cls.IV": "subgiant", "cls.III": "giant", "cls.II": "bright giant", "cls.I": "supergiant",
      "cls.estimated": "class estimated from its place in the HR diagram",
      "spt": "spectral type {s}",
      "hz": "a habitable planet would orbit between {a} and {b} au (conservative; optimistic {c}–{d} au)",
      "hz.invalid": "(outside the validity of the model, 2 600–7 200 K)",
      "dist": "{ly} light-years away ({pc} pc)", "dist.range": "between {lo} and {hi} light-years", "dist.far": "more than {lo} light-years away",
      "dist.doubtful": "uncertain distance", "dist.none": "no reliable distance",
      // --- tiempo de luz ---
      "light.now": "The light you see left it {t} ago.",
      "light.same": "The light you see left it in {y}, the year of {e}.",
      "light.before": "The light you see left it in {y}, {n} years before {e} ({ey}).",
      "light.after": "The light you see left it in {y}, {n} years after {e} ({ey}).",
      "light.before.1": "The light you see left it in {y}, 1 year before {e} ({ey}).",
      "light.after.1": "The light you see left it in {y}, 1 year after {e} ({ey}).",
      "light.u.era": "The light you see left it around {y} (± {u} years), in the time of {e} ({ey}).",
      "light.u.before": "The light you see left it around {y} (± {u} years), some {n} years before {e} ({ey}).",
      "light.u.after": "The light you see left it around {y} (± {u} years), some {n} years after {e} ({ey}).",
      "light.deep.same": "The light you see left it {t} ago, in the time of {e}.",
      "light.deep.before": "The light you see left it {t} ago, long before {e} ({et} ago).",
      "light.deep.after": "The light you see left it {t} ago, after {e} ({et} ago).",
      // --- transito ---
      "tr.depth": "the planet covers {p} of the star's disc; the light dips {q} (the centre of the disc is brighter: limb darkening)", "tr.dur": "the transit lasts {t}", "tr.year": "its year lasts {t}",
      "tr.size.jup": "{x} times the size of Jupiter ({y} Earths)", "tr.size.earth": "{x} times the size of the Earth",
      "tr.cmp": "seen from afar, the Earth crossing the Sun dims it by only {e}; Jupiter, by {j}",
      "tr.speed": "it races around its star at {v} km/s", "tr.teq": "equilibrium temperature {t}",
      "tr.check": "duration: {a} computed, {b} in the NASA table", "tr.omega": "orbit orientation on the sky: illustrative",
      // --- viaje ---
      "tv.light": "at the speed of light: {t}", "tv.beta": "at {b} of the speed of light: {te} on Earth, {ts} on board",
      "tv.accel": "at a constant 1 g (accelerating half way, braking the other half): {ts} on board, {te} on Earth; top speed {b} of c",
      "tv.warp": "at warp {w} ({v} times the speed of light) you would arrive in {t}",
      "tv.warp.note": "warp is fiction: Star Trek: The Next Generation scale, v = w^(10/3) c up to warp 9",
      "tv.voyager": "Voyager 1 (17 km/s) would take {t}",
      "tv.improb": "improbability factor: 2 to the power of {n} to one against. Don't panic.",
      "tv.improb.note": "(a joke for hitchhikers, not physics)",
      // --- escala ---
      "sc.size": "it measures {d} light-years across ({pc} pc)", "sc.ss": "{n} Solar Systems (out to Neptune) would fit across it in a row",
      "sc.ssvol": "and {n} of them inside it", "sc.lightcross": "light takes {t} to cross it",
      "sc.sand": "if the Sun were a grain of sand 1 mm wide, the Earth would circle it {e} away, and the nearest star would be {p} away",
      "sc.sand.obj": "at that scale this object would be {d} away", "sc.sand.size": "and {s} across",
      // --- avisos ---
      "note.recreation": "recreation", "note.estimated": "estimated", "note.bc-extrapolated": "bolometric correction extrapolated",
      "note.distance-doubtful": "uncertain distance", "note.hz-out-of-range": "habitable zone outside the model's range",
      "note.evolved": "evolved star", "note.mass-out-of-range": "mass outside the relation's range"
   },
   es: {
      "u.ly1": "año luz", "u.ly": "años luz", "u.pc": "pc", "u.au": "UA", "u.km": "km", "u.m": "m", "u.cm": "cm", "u.mm": "mm",
      "u.yr1": "año", "u.yr": "años", "u.day1": "día", "u.day": "días", "u.h": "h", "u.min": "min", "u.s": "s", "u.and": "y",
      "u.thousand": "mil", "u.million1": "millón", "u.million": "millones", "u.billion": "mil millones", "u.trillion1": "billón", "u.trillion": "billones",
      "u.of": "de", "u.bc": "a. C.", "u.pct": "{x} %", "u.ppm": "{x} ppm", "u.K": "{x} K", "u.c": "{x} c", "approx": "unos {n}", "year.c": "hacia {y}",
      "lum.more": "{x} veces más luminosa que el Sol", "lum.less": "brilla {x} veces menos que el Sol", "lum.same": "casi tan luminosa como el Sol",
      "rad.more": "{x} veces el radio del Sol", "rad.less": "{x} veces más pequeña que el Sol", "rad.same": "casi del tamaño del Sol",
      "rad.orbit": "en el lugar del Sol llegaría más allá de la órbita de {planet}", "rad.orbit.in": "en el lugar del Sol se tragaría a {planet}",
      "planet.mercury": "Mercurio", "planet.venus": "Venus", "planet.earth": "la Tierra", "planet.mars": "Marte", "planet.jupiter": "Júpiter",
      "planet.saturn": "Saturno", "planet.uranus": "Urano", "planet.neptune": "Neptuno",
      "temp": "superficie a {t}", "temp.hotter": "{dt} más caliente que el Sol", "temp.cooler": "{dt} más fría que el Sol", "temp.same": "tan caliente como el Sol",
      "mass": "unas {m} masas solares", "mass.sun": "más o menos la masa del Sol",
      "life": "pasará unos {t} en la secuencia principal (el Sol, unos {s})",
      "life.evolved": "ya ha dejado la secuencia principal: es una {cls}",
      "cls.V": "estrella de la secuencia principal (enana)", "cls.IV": "subgigante", "cls.III": "gigante", "cls.II": "gigante luminosa", "cls.I": "supergigante",
      "cls.estimated": "clase estimada por su lugar en el diagrama HR",
      "spt": "tipo espectral {s}",
      "hz": "un planeta habitable tendría que orbitar entre {a} y {b} UA (conservador; optimista, {c}–{d} UA)",
      "hz.invalid": "(fuera de la validez del modelo, 2 600–7 200 K)",
      "dist": "a {ly} años luz ({pc} pc)", "dist.range": "entre {lo} y {hi} años luz", "dist.far": "a más de {lo} años luz",
      "dist.doubtful": "distancia dudosa", "dist.none": "sin distancia fiable",
      "light.now": "La luz que ves salió de allí hace {t}.",
      "light.same": "La luz que ves salió de allí en el año {y}, el año de {e}.",
      "light.before": "La luz que ves salió de allí en el año {y}, {n} años antes de {e} ({ey}).",
      "light.after": "La luz que ves salió de allí en el año {y}, {n} años después de {e} ({ey}).",
      "light.before.1": "La luz que ves salió de allí en el año {y}, 1 año antes de {e} ({ey}).",
      "light.after.1": "La luz que ves salió de allí en el año {y}, 1 año después de {e} ({ey}).",
      "light.u.era": "La luz que ves salió de allí hacia el año {y} (± {u} años), por la época de {e} ({ey}).",
      "light.u.before": "La luz que ves salió de allí hacia el año {y} (± {u} años), unos {n} años antes de {e} ({ey}).",
      "light.u.after": "La luz que ves salió de allí hacia el año {y} (± {u} años), unos {n} años después de {e} ({ey}).",
      "light.deep.same": "La luz que ves salió de allí hace {t}, en la época de {e}.",
      "light.deep.before": "La luz que ves salió de allí hace {t}, mucho antes de {e} (hace {et}).",
      "light.deep.after": "La luz que ves salió de allí hace {t}, después de {e} (hace {et}).",
      "tr.depth": "el planeta tapa el {p} del disco de la estrella; la luz baja un {q} (el centro del disco brilla más: oscurecimiento del limbo)", "tr.dur": "el tránsito dura {t}", "tr.year": "su año dura {t}",
      "tr.size.jup": "{x} veces el tamaño de Júpiter ({y} Tierras)", "tr.size.earth": "{x} veces el tamaño de la Tierra",
      "tr.cmp": "vista desde lejos, la Tierra al pasar por delante del Sol solo lo atenúa un {e}; Júpiter, un {j}",
      "tr.speed": "da vueltas a su estrella a {v} km/s", "tr.teq": "temperatura de equilibrio {t}",
      "tr.check": "duración: {a} calculada, {b} en la tabla de la NASA", "tr.omega": "orientación de la órbita en el cielo: ilustrativa",
      "tv.light": "a la velocidad de la luz: {t}", "tv.beta": "al {b} de la velocidad de la luz: {te} en la Tierra, {ts} a bordo",
      "tv.accel": "a 1 g constante (acelerando media ruta y frenando la otra): {ts} a bordo, {te} en la Tierra; velocidad máxima, el {b} de c",
      "tv.warp": "a warp {w} ({v} veces la velocidad de la luz) llegarías en {t}",
      "tv.warp.note": "el warp es ficción: escala de Star Trek: La nueva generación, v = w^(10/3) c hasta warp 9",
      "tv.voyager": "la Voyager 1 (17 km/s) tardaría {t}",
      "tv.improb": "factor de improbabilidad: 2 elevado a {n} contra uno. No te asustes.",
      "tv.improb.note": "(un chiste para autoestopistas, no es física)",
      "sc.size": "mide {d} años luz de lado a lado ({pc} pc)", "sc.ss": "cabrían {n} sistemas solares (hasta Neptuno) en fila de un lado a otro",
      "sc.ssvol": "y {n} dentro de ella", "sc.lightcross": "la luz tarda {t} en cruzarla",
      "sc.sand": "si el Sol fuera un grano de arena de 1 mm, la Tierra giraría a {e} de él y la estrella más cercana estaría a {p}",
      "sc.sand.obj": "a esa escala, este objeto estaría a {d}", "sc.sand.size": "y mediría {s}",
      "note.recreation": "recreación", "note.estimated": "estimado", "note.bc-extrapolated": "corrección bolométrica extrapolada",
      "note.distance-doubtful": "distancia dudosa", "note.hz-out-of-range": "zona habitable fuera del rango del modelo",
      "note.evolved": "estrella evolucionada", "note.mass-out-of-range": "masa fuera del rango de la relación"
   }
};

function fvsLang_(lang) { return (lang === "es") ? "es" : "en"; }
// Texto de la clave con sus {parametros}
function fvsT(lang, key, params) {
   var tab = FVS_I18N[fvsLang_(lang)], s = (tab && tab.hasOwnProperty(key)) ? tab[key] : key;
   if (params) for (var k in params) if (params.hasOwnProperty(k)) s = s.split("{" + k + "}").join(String(params[k]));
   return (fvsLang_(lang) === "es") ? fvsEsContract(s) : s;
}
// Contracciones del castellano tras rellenar la plantilla: «de el» → «del», «a el» → «al» (en minuscula: «de El origen…»,
// titulo, se queda como esta, que es lo correcto)
function fvsEsContract(s) { return String(s).split(" de el ").join(" del ").split(" a el ").join(" al "); }
// Primera letra en mayuscula (para empezar frase con una pieza)
function fvsCap(s) { s = String(s || ""); return s.length ? s.charAt(0).toUpperCase() + s.slice(1) : s; }

// ---------------- numeros ----------------
function fvsGroup_(ip, sep) { var out = ""; while (ip.length > 3) { out = sep + ip.slice(-3) + out; ip = ip.slice(0, -3); } return ip + out; }
// Numero con dec decimales y los separadores del idioma
function fvsFmtNum(x, dec, lang) {
   if (!isFinite(x)) return "—";
   var es = fvsLang_(lang) === "es", d = Math.max(0, dec | 0), s = Math.abs(x).toFixed(d), p = s.split("."), ip = p[0];
   if (ip.length >= 4) ip = fvsGroup_(ip, es ? " " : ",");
   var r = ip + (p.length > 1 ? (es ? "," : ".") + p[1] : "");
   return (x < 0 && Number(s) !== 0) ? "−" + r : r;
}
// Con sig cifras significativas (enteros grandes redondeados: 312 456 → «312 000» con sig = 3). Se redondea ANTES de
// contar las cifras (9,996 con 3 cifras → «10,0», no «10,00»).
function fvsLog10_(x) { return Math.log(Math.abs(x)) / Math.LN10; }
function fvsFmtSig(x, sig, lang) {
   if (!isFinite(x)) return "—";
   if (x === 0) return "0";
   var sg = sig || 3, e = Math.floor(fvsLog10_(x) + 1e-9), q = Math.pow(10, e - sg + 1), xr = Math.round(x / q) * q;
   e = Math.floor(fvsLog10_(xr) + 1e-9);
   return fvsFmtNum(xr, Math.max(0, sg - 1 - e), lang);
}
// Quita los ceros decimales de sobra: «12,0» → «12», «2,50» → «2,5»
function fvsStripZeros(s, lang) {
   var dp = (fvsLang_(lang) === "es") ? "," : ".";
   if (s.indexOf(dp) < 0) return s;
   while (s.charAt(s.length - 1) === "0") s = s.slice(0, -1);
   if (s.charAt(s.length - 1) === dp) s = s.slice(0, -1);
   return s;
}
// Numeros grandes en palabras: 1,2 millones · 3,4 mil millones / 1.2 million · 3.4 billion. nounEs = true añade el «de»
// del castellano («12 millones de años») cuando hace falta.
function fvsFmtBig(x, lang, sig, nounEs) {
   if (!isFinite(x)) return "—";
   var L = fvsLang_(lang), a = Math.abs(x), sg = sig || 3, of = (L === "es" && nounEs) ? " " + fvsT(L, "u.of") : "";
   function w(v, key1, key) { var t = fvsStripZeros(fvsFmtSig(v, sg, L), L); return t + " " + fvsT(L, (t === "1" && key1) ? key1 : key) + of; }
   if (a >= 1e18) return fvsStripZeros(fvsFmtSig(x / 1e18, sg, L), L) + " × 10¹⁸";
   if (a >= 1e12) return w(x / 1e12, "u.trillion1", "u.trillion");
   if (a >= 1e9 && L === "en") return w(x / 1e9, null, "u.billion");
   if (a >= 1e6) return w(x / 1e6, "u.million1", "u.million");      // ES: «13 800 millones», como se dice en castellano
   return fvsFmtSig(x, sg, L);
}
// Cociente «N veces»: < 10 con un decimal; 10-1e6 con 3 cifras; mas, en palabras
function fvsFmtTimes(x, lang) {
   if (!isFinite(x)) return "—";
   if (x >= 1e6) return fvsFmtBig(x, lang, 3, false);
   if (x >= 10) return fvsFmtSig(Math.round(x), Math.min(3, Math.floor(Math.log(x) / Math.LN10) + 1), lang);
   return fvsFmtNum(x, 1, lang);
}
function fvsFmtPct(frac, lang, dec) {
   if (frac < 0.001) return fvsT(lang, "u.ppm", { x: fvsFmtSig(frac * 1e6, 2, lang) });
   return fvsT(lang, "u.pct", { x: fvsFmtNum(frac * 100, (dec === undefined) ? (frac < 0.1 ? 2 : 1) : dec, lang) });
}
function fvsFmtTemp(k, lang) { return fvsT(lang, "u.K", { x: fvsFmtSig(k, Math.max(2, Math.min(4, Math.floor(Math.log(k) / Math.LN10) + 1)), lang) }); }
// Año historico para leer: 1683 · 5475 a. C. / 5475 BC (los años no se agrupan hasta 5 cifras)
function fvsFmtYear(yHist, lang) {
   var a = Math.abs(Math.round(yHist)), s = (a >= 10000) ? fvsFmtNum(a, 0, lang) : String(a);
   return (yHist < 1) ? s + " " + fvsT(lang, "u.bc") : s;
}
// Duracion en años → texto con la unidad que se lee mejor (s, min, h, dias, años, millones de años…)
function fvsFmtDuration(years, lang) {
   if (!isFinite(years)) return "—";
   var L = fvsLang_(lang), s = years * FVS.JYEAR_S, T = function (k) { return fvsT(L, k); };
   if (s < 60) return fvsFmtNum(s, s < 10 ? 1 : 0, L) + " " + T("u.s");
   if (s < 3600) { var mi = Math.floor(s / 60), se = Math.round(s - 60 * mi); if (se === 60) { mi += 1; se = 0; } return mi + " " + T("u.min") + (mi < 10 && se > 0 ? " " + se + " " + T("u.s") : ""); }
   if (s < 86400) { var h = Math.floor(s / 3600), m = Math.round((s - 3600 * h) / 60); if (m === 60) { h += 1; m = 0; } return h + " " + T("u.h") + (m > 0 ? " " + m + " " + T("u.min") : ""); }
   var days = s / 86400;
   if (days < 10) { var dd = Math.floor(days), hh = Math.round((days - dd) * 24); if (hh === 24) { dd += 1; hh = 0; } return dd + " " + T(dd === 1 ? "u.day1" : "u.day") + (hh > 0 ? " " + T("u.and") + " " + hh + " " + T("u.h") : ""); }
   if (years < 1) return fvsFmtNum(Math.round(days), 0, L) + " " + T("u.day");
   if (years < 10) { var y1 = fvsFmtNum(years, 1, L); return y1 + " " + T((y1 === "1.0" || y1 === "1,0") ? "u.yr1" : "u.yr"); }
   if (years < 1e6) return fvsFmtSig(years, years < 1e4 ? Math.floor(Math.log(years) / Math.LN10) + 1 : 3, L) + " " + T("u.yr");
   return fvsFmtBig(years, L, 3, true) + " " + T("u.yr");
}
// Distancia en km / m / cm para las frases de escala
function fvsFmtLength(m, lang) {
   if (m >= 1000) return fvsFmtSig(m / 1000, 3, lang) + " " + fvsT(lang, "u.km");
   if (m >= 1) return fvsFmtSig(m, 3, lang) + " " + fvsT(lang, "u.m");
   if (m >= 0.01) return fvsFmtSig(m * 100, 2, lang) + " " + fvsT(lang, "u.cm");
   return fvsFmtSig(m * 1000, 2, lang) + " " + fvsT(lang, "u.mm");
}
