// ============================================================================
// FieldVoyager/src/science/fv_sci_planet.js — COMO SE VE UN EXOPLANETA: FAMILIA, COLOR, BRILLO TERMICO Y FASE (Blender 1, 5-nov-2026)
// ----------------------------------------------------------------------------
// Puro (sin PixInsight ni navegador): lo usan src/ui/fv_planets3d.js (PixInsight) y web/fw_pl_view.js (visor). Entrada: la fila de
// pscomppars (NASA Exoplanet Archive) que ya trae FieldVoyager (pl_rade, pl_eqt, st_teff…) o el objeto de fvsTransitSetup.
//
// 1. FAMILIA por radio y temperatura de equilibrio (umbrales con su fuente; los sprites de Blender son uno por familia):
//      rocoso       R < 1,23 R⊕     Chen & Kipping 2017, ApJ 834, 17: transicion Terran -> Neptunian a 2,0 (+0,7 −0,6) M⊕ (abstract,
//                                   leido el 5-nov-2026); en radio, con su ley Terran R ∝ M^0,279 -> 2,0^0,279 ≈ 1,21–1,23 R⊕
//                                   (exponente de memoria: NO VERIFICADO en el texto del articulo)
//      supertierra  1,23 – 1,75     Fulton et al. 2017, AJ 154, 109: el valle de radios entre 1,5 y 2,0 R⊕ (centro 1,75) separa las
//                                   supertierras rocosas de los subneptunos con envoltura
//      neptuno      1,75 – 6        Borucki et al. 2011, ApJ 736, 19: clase «tamaño Neptuno» 2–6 R⊕; «tamaño Jupiter» desde 6 R⊕
//                                   (la ficha ya usa 6 R⊕ para pasar a radios de Jupiter: fv_objects.js)
//      gigante      R ≥ 6, Teq < 1000 K
//      jupcaliente  R ≥ 6, Teq ≥ 1000 K   umbral de los «hot Jupiters» inflados: Demory & Seager 2011, ApJS 197, 12 (flujo ~2·10^8
//                                   erg s⁻¹ cm⁻² ≈ Teq 970 K con A = 0 y redistribucion total; la cifra del flujo es de memoria: NO
//                                   VERIFICADA en el texto). Convencion habitual: 1000 K.
// 2. COLOR (albedo en sRGB lineal) por temperatura de equilibrio, interpolado en log Teq entre anclas con base fisica:
//      gigantes: las CLASES de Sudarsky, Burrows & Pinto 2000 (ApJ 538, 885) y Sudarsky et al. 2003 (ApJ 588, 1121): I nubes de
//      amoniaco (~Jupiter, crema), II nubes de agua (blanco, albedo ~0,8), III sin nubes (azul por Rayleigh y alcalinos, albedo ~0,1),
//      IV absorcion de Na y K (muy oscuro, albedo ~0,03), V nubes de silicatos (gris claro, albedo ~0,5). Las cifras RGB son una
//      LECTURA APROXIMADA nuestra de esas clases (y del espectro de albedo de Jupiter de Karkoschka 1994): NO son una medida.
//      hielo/neptuno: metano (Urano/Neptuno, cian palido) -> nubes de agua -> neblina fotoquimica de los subneptunos templados
//      (GJ 1214 b, Kreidberg et al. 2014; color de la neblina NO VERIFICADO) -> oscuro en caliente.
//      rocosos: superficie basaltica oscura (LHS 3844 b, Kreidberg et al. 2019, Nature 573, 87: compatible con basalto; Luna/Mercurio
//      ~0,1). SUPUESTO: de los rocosos no conocemos el color; se pinta roca desnuda.
// 3. LUZ DE LA ESTRELLA: el planeta se ilumina con el color de cuerpo negro de su estrella (fvsBlackbodyColour).
// 4. BRILLO TERMICO (incandescencia), FISICO: por canal sRGB lineal, la radiancia de cuerpo negro del planeta frente a la de una
//    superficie blanca (albedo 1) iluminada por la estrella:
//        reflejado_c = B★_c · (R★/a)²       termico_c = B_c(T_planeta)       (R★/a)² = 4 (Teq/T★)⁴   (Teq con redistribucion total)
//    (B_c = integral de Planck con las funciones CIE 1931 -> sRGB lineal, como fv_sci_colour.js). Temperaturas del lado de dia y de
//    noche con la redistribucion ε de Cowan & Agol 2011 (ApJ 729, 54, ec. 4): T_dia = T0 (2/3 − 5ε/12)^¼, T_noche = T0 (ε/4)^¼,
//    T0 = √2 · Teq. ε por familia (ELECCION nuestra, documentada en FVS_PL.EPS): rocoso sin aire 0; jupiter caliente 0,3 (Cowan & Agol
//    2011: los mas calientes redistribuyen poco); el resto 1 (uniforme). Resultado: un jupiter caliente tipico (Teq 1500 K) apenas
//    brilla de noche (T_noche ~ 1000 K: invisible); uno ultracaliente (Teq ≥ 2200 K) si se ve incandescente. Es la fisica; no se exagera.
// 5. EXPOSICION: automatica como una camara (el planeta se ve solo en su portilla): ganancia = OBJ / max(albedo × luz + termico de dia), tope GAIN_MAX
//    (un planeta negro como el carbon sigue viendose oscuro). La misma ganancia para lo reflejado y lo termico (la razon se conserva).
// 6. FASE: angulo estrella-planeta-camara con la orbita de fvsTransitPos (circular; el NODO de la orbita en el cielo no se conoce:
//    SUPUESTO, eje x̂ perpendicular a la visual y al eje z de la escena).
// ES5. Sin PixInsight.
// ============================================================================

var FVS_PL = {
   R_TERRAN: 1.23, R_VALLEY: 1.75, R_GIANT: 6.0, TEQ_HOT: 1000,
   EPS: { rocky: 0.0, superearth: 0.0, neptune: 1.0, giant: 1.0, hotjupiter: 0.3 },
   OBJ: 0.80, GAIN_MAX: 6.0,
   PEAK_EXPO: true,        // (PL-4, 10-nov) la exposicion mira el PICO del resplandor de dia, no su media. false = lo de antes (el ROJO de la prueba)
   OBJ_S: 0.92,            // (PL-4) tope de la suma en sRGB (reflejado + resplandor) en el pico: 235 de 255, deja sitio a la atmosfera
   // anclas [Teq K, r, g, b] (albedo, sRGB lineal); fuera de rango, la del extremo
   COL: {
      rocky:      [[100, 0.13, 0.12, 0.11], [3000, 0.13, 0.12, 0.11]],
      superearth: [[100, 0.16, 0.14, 0.12], [3000, 0.16, 0.14, 0.12]],
      neptune:    [[70, 0.35, 0.55, 0.60], [300, 0.60, 0.60, 0.60], [600, 0.36, 0.29, 0.20], [1200, 0.06, 0.06, 0.07]],
      giant:      [[120, 0.52, 0.46, 0.36], [250, 0.75, 0.75, 0.74], [500, 0.10, 0.18, 0.45], [900, 0.05, 0.07, 0.14]],
      // (PL-2, 5-nov) clase IV (1000-1400 K): azul/verde 3,25. Mecanismo de clase: la absorcion de Na y K domina (Sudarsky, Burrows & Pinto
      // 2000, arXiv:astro-ph/9910504) y se come la luz por encima de ~450 nm; medida: el unico espectro de albedo visible de un planeta de
      // esta clase, HD 189733 b, Ag 0,40 ± 0,12 en 290-450 nm y < 0,12 en 450-570 nm (Evans et al. 2013, ApJL 772, L16, arXiv:1307.3239)
      // -> razon azul/verde ≥ 3,3 (se toma 3,25). El rojo ≤ verde es SUPUESTO (Na D 589 nm y K 770 nm). Antes: lectura propia 2,2 / 1,6
      // (Blender 3 · D2, 10-nov) los ULTRACALIENTES (Teq ≳ 2200 K) no tienen nubes de silicatos en el lado de dia y son muy oscuros: WASP-12 b
      // (Teq ~2580 K) Ag < 0,064 en 290-570 nm, 97,5 % (Bell et al. 2017, ApJL 847, L2, arXiv:1709.04461; leido el resumen el 10-nov-2026)
      // -> ancla gris 0,06 a 2500 K (rojo = azul SUPUESTO: la cota es de 290-570 nm). La forma del paso de la clase V (1700 K) a 2500 K es
      // SUPUESTA (interpolacion en log Teq). Con la clase V hasta 3000 K, el ultracaliente salia beis palido aun sumando bien (C* 18): lo
      // reflejado tapaba su incandescencia. Antes: [3000, 0.45, 0.42, 0.40]. FVS_PL.UHJ_DARK = false vuelve a eso (el ROJO de la prueba)
      hotjupiter: [[1000, 0.03, 0.04, 0.13], [1400, 0.03, 0.04, 0.13], [1700, 0.45, 0.42, 0.40], [2500, 0.06, 0.06, 0.06], [3000, 0.06, 0.06, 0.06]]
   },
   UHJ_DARK: true,
   COL_HJ_OLD: [[1000, 0.03, 0.04, 0.13], [1400, 0.03, 0.04, 0.13], [1700, 0.45, 0.42, 0.40], [3000, 0.45, 0.42, 0.40]],
   // (Blender 3 · D2) los mundos CALIENTES (con resplandor de dia que pesa) se componen en LUZ LINEAL (reflejado + atmosfera + resplandor) y se
   // llevan a la pantalla con un tono que CONSERVA el tono: el mismo factor en R, G y B, hombro suave arcsinh (como ArcsinhStretch):
   //   m = max(R, G, B) · (ganancia: el pico del lado de dia = 1);  T(m) = TONE_MAX · asinh(TONE_B · m) / asinh(TONE_B);  salida = lineal · T(m) / m
   // Antes (Blender 2, PL-4) se sumaban en sRGB (Add de Qt) y la ganancia se bajaba hasta que la suma cupiera: lo calido se apagaba en beis
   // (D2) y la noche del ultracaliente quedaba negra (D8). LIN_SUM false = lo de Blender 2 (el ROJO de la prueba). Los mundos sin resplandor
   // de dia (rocoso templado, neptuno, gigante, caliente tipico) siguen el camino de siempre.
   LIN_SUM: true, TONE_B: 3.0, TONE_MAX: 0.90,
   SRC: "Chen & Kipping 2017; Fulton et al. 2017; Borucki et al. 2011; Demory & Seager 2011; Sudarsky et al. 2000/2003; Cowan & Agol 2011"
};

// familia por radio (R⊕) y Teq (K). -> { fam, why }
function fvsPlanetFamily(rE, teq) {
   var T = (teq > 0) ? teq : NaN;
   if (!(rE > 0)) return { fam: (T >= FVS_PL.TEQ_HOT) ? "hotjupiter" : "giant", why: "no-radius" };
   if (rE < FVS_PL.R_TERRAN) return { fam: "rocky", why: "R<" + FVS_PL.R_TERRAN };
   if (rE < FVS_PL.R_VALLEY) return { fam: "superearth", why: "R<" + FVS_PL.R_VALLEY };
   if (rE < FVS_PL.R_GIANT) return { fam: "neptune", why: "R<" + FVS_PL.R_GIANT };
   if (T >= FVS_PL.TEQ_HOT) return { fam: "hotjupiter", why: "R>=6,Teq>=" + FVS_PL.TEQ_HOT };
   return { fam: "giant", why: isFinite(T) ? "R>=6,Teq<" + FVS_PL.TEQ_HOT : "R>=6,no-Teq" };
}

// albedo (sRGB lineal) de la familia a esa Teq: interpolacion en log Teq entre anclas
function fvsPlanetAlbedo(fam, teq) {
   var A = (fam === "hotjupiter" && !FVS_PL.UHJ_DARK) ? FVS_PL.COL_HJ_OLD : (FVS_PL.COL[fam] || FVS_PL.COL.giant), T = (teq > 0) ? teq : A[0][0];
   if (T <= A[0][0]) return [A[0][1], A[0][2], A[0][3]];
   var n = A.length;
   if (T >= A[n - 1][0]) return [A[n - 1][1], A[n - 1][2], A[n - 1][3]];
   for (var i = 0; i < n - 1; ++i) if (T < A[i + 1][0]) {
      var w = Math.log(T / A[i][0]) / Math.log(A[i + 1][0] / A[i][0]);
      return [A[i][1] + w * (A[i + 1][1] - A[i][1]), A[i][2] + w * (A[i + 1][2] - A[i][2]), A[i][3] + w * (A[i + 1][3] - A[i][3])];
   }
   return [A[n - 1][1], A[n - 1][2], A[n - 1][3]];
}

// radiancia de cuerpo negro integrada con CIE 1931 -> sRGB LINEAL ABSOLUTO (sin normalizar; puede tener componentes < 0 fuera del gamut)
function fvsPlanckLinSrgb(tK) {
   if (!(tK > 0)) return [0, 0, 0];
   var X = 0, Y = 0, Z = 0;
   for (var lam = 360; lam <= 830; lam += 5) {
      var b = fvsPlanck(lam * 1e-9, tK), c = fvsCmf1931(lam);
      X += b * c[0]; Y += b * c[1]; Z += b * c[2];
   }
   return fvsXyzToLinearSrgb(X, Y, Z);
}
// fuera del gamut: se desatura hacia el blanco conservando la luminancia aproximada (como fvsBlackbodyColourExact) y nunca < 0
function fvsPlGamut(c) { var mn = Math.min(c[0], c[1], c[2]); return mn < 0 ? [c[0] - mn, c[1] - mn, c[2] - mn] : c; }

// temperaturas de dia y de noche (Cowan & Agol 2011, ec. 4) con la ε de la familia
function fvsPlanetDayNight(teq, fam) {
   var e = FVS_PL.EPS[fam]; if (e === undefined) e = 1;
   var T0 = Math.SQRT2 * teq;
   return { eps: e, day: T0 * Math.pow(2 / 3 - 5 * e / 12, 0.25), night: T0 * Math.pow(e / 4, 0.25) };
}

// TODO lo que hace falta para pintar un planeta. p = fila de pscomppars (o { pl_rade, pl_eqt, st_teff }).
// -> { fam, why, teq, teff, albedo[3], star[3] (lineal, max 1), gain, lit[3] (lineal, color del lado de dia de un albedo 1 ya con la
//     ganancia aplicada a albedo×luz), glowDay[3], glowNight[3] (lineal, mismas unidades), tDay, tNight, assumed: [..] }
// o (opcional, Blender 2 · PL-4, 10-nov) = { glowP }: la forma del resplandor de dia de la familia (manifiesto, cos^p θ). Su PICO en el punto
// subestelar es (p + 1) veces su media; la exposicion lo cuenta (FVS_PL.PEAK_EXPO): con solo la media, la lava (p 2) y el ultracaliente
// saturaban el lado de dia (canal rojo 1,49 en la lava de prueba) y salian casi blancos y sin textura a 1920. La misma ganancia para todo:
// la razon reflejado / termico y el color no cambian; sin resplandor de dia (rocosos frios, neptunos, gigantes) el resultado es el de antes.
function fvsPlanetLook(p, tr, o) {
   var rE = Number(p && p.pl_rade) || (tr && tr.rpEarth) || NaN, teq = Number(p && p.pl_eqt) || (tr && tr.teq) || NaN;
   var teff = Number(p && p.st_teff) || (tr && tr.teff) || NaN, assumed = [];
   if (!(teff > 0)) { teff = 5772; assumed.push("teff=5772(Sun)"); }
   var F = fvsPlanetFamily(rE, teq), fam = F.fam;
   if (!(teq > 0)) { teq = { rocky: 300, superearth: 400, neptune: 500, giant: 150, hotjupiter: 1500 }[fam]; assumed.push("teq=" + teq); }
   var alb = fvsPlanetAlbedo(fam, teq);
   var s = fvsPlGamut(fvsPlanckLinSrgb(teff)), sMax = Math.max(s[0], s[1], s[2]), star = [s[0] / sMax, s[1] / sMax, s[2] / sMax];
   var refl = [alb[0] * star[0], alb[1] * star[1], alb[2] * star[2]];
   // termico: B(T)/(B★max · 4 (Teq/T★)⁴), en las unidades de «superficie blanca bajo la estrella = star (max 1)»
   var DN = fvsPlanetDayNight(teq, fam), N = sMax * 4 * Math.pow(teq / teff, 4);
   function th0(T) { var b = fvsPlGamut(fvsPlanckLinSrgb(T)); return [b[0] / N, b[1] / N, b[2] / N]; }
   var tD = th0(DN.day), tN = th0(DN.night);
   // la exposicion mira lo MAS BRILLANTE del lado de dia: reflejado + termico (con solo lo reflejado, la lava y el ultracaliente salian
   // blancos sin textura: montaje del 5-nov)
   // (PL-4) con resplandor de dia concentrado (p > 0) cuenta su pico y el de la textura del albedo (normalizada a maximo 1: pico = 1/alb_mean
   // veces la media), que se suman en el mismo punto. Sin el (p = 0: neptunos, gigantes, frios) la regla es la de antes
   // (solo si el calor de dia pesa: ≥ 5 % de lo reflejado; un rocoso templado tiene glow_p 2 pero ningun brillo termico y queda como antes)
   var hot = Math.max(tD[0], tD[1], tD[2]) >= 0.05 * Math.max(refl[0], refl[1], refl[2]);
   var pk = (FVS_PL.PEAK_EXPO && hot && o && o.glowP > 0) ? 1 + o.glowP : 1, ap = (pk > 1 && o.albMean > 0.2) ? 1 / o.albMean : 1;
   var rMax = Math.max(ap * refl[0] + pk * tD[0], ap * refl[1] + pk * tD[1], ap * refl[2] + pk * tD[2]);
   var gain = Math.min(FVS_PL.GAIN_MAX, FVS_PL.OBJ / Math.max(1e-6, rMax)), tone = null;
   // (Blender 3 · D2) con resplandor de dia que pesa: la suma va en LUZ LINEAL (la compone fv_planets3d.js / fw_pl_view.js pixel a pixel) y el
   // pico del lado de dia (textura en su maximo + resplandor en el punto subestelar) se lleva a 1 antes del tono arcsinh (look.tone)
   // (la textura se aplica DESPUES del tono, multiplicando, con media alb_mean: por eso todo, tambien el resplandor, va × ap = 1/alb_mean)
   if (pk > 1 && FVS_PL.LIN_SUM) {
      var rT = Math.max(ap * (refl[0] + pk * tD[0]), ap * (refl[1] + pk * tD[1]), ap * (refl[2] + pk * tD[2]));
      gain = Math.min(FVS_PL.GAIN_MAX / FVS_PL.OBJ, 1 / Math.max(1e-6, rT)); tone = { b: FVS_PL.TONE_B, max: FVS_PL.TONE_MAX, ap: ap };
   }
   // (PL-4) la pantalla SUMA lo reflejado y el resplandor en sRGB (Add de Qt / «lighter» del lienzo: fv_planets3d.js), no en luz lineal:
   // 0,4 + 0,4 en lineal son 0,8 (231), pero sumados en sRGB dan 170 + 170 = 340 -> blanco. Con resplandor de dia que pesa, la ganancia se
   // baja (biseccion) hasta que la SUMA EN sRGB de los dos picos quepa en FVS_PL.OBJ_S. Misma ganancia para los dos: la razon se conserva
   if (pk > 1 && !tone) {
      var sumS = function(gn) { var m = 0; for (var c = 0; c < 3; ++c) m = Math.max(m, fvsSrgbGamma(Math.min(1, gn * ap * refl[c])) + fvsSrgbGamma(Math.min(1, gn * pk * tD[c]))); return m; };
      if (sumS(gain) > FVS_PL.OBJ_S) { var lo = 0, hi = gain; for (var it = 0; it < 30; ++it) { var md = 0.5 * (lo + hi); if (sumS(md) > FVS_PL.OBJ_S) hi = md; else lo = md; } gain = lo; }
   }
   function th(t) { return [gain * t[0], gain * t[1], gain * t[2]]; }
   return { fam: fam, why: F.why, rE: rE, teq: teq, teff: teff, albedo: alb, star: star, gain: gain,
            lit: [gain * refl[0], gain * refl[1], gain * refl[2]], tint: [Math.min(1, gain * alb[0] * star[0]), Math.min(1, gain * alb[1] * star[1]), Math.min(1, gain * alb[2] * star[2])],
            glowDay: th(tD), glowNight: th(tN), tDay: DN.day, tNight: DN.night, eps: DN.eps, assumed: assumed, tone: tone };
}
// (Blender 3 · D2) el tono que conserva el tono: m (lineal, pico del dia = 1) -> factor por el que se multiplican R, G y B
function fvsPlanetToneK(m, tone) {
   if (!(m > 1e-9)) return 0;
   return tone.max * (Math.log(tone.b * m + Math.sqrt(tone.b * tone.b * m * m + 1)) / Math.log(tone.b + Math.sqrt(tone.b * tone.b + 1))) / m;
}
// (Blender 3 · D2, ancla) el color de cuerpo negro a la temperatura T (Planck × CIE 1931 -> sRGB lineal, maximo 1): con el que se compara el
// lado de dia de un mundo caliente en la prueba
function fvsPlanetBlackbodyLin(tK) { var b = fvsPlGamut(fvsPlanckLinSrgb(tK)), m = Math.max(b[0], b[1], b[2]); return m > 0 ? [b[0] / m, b[1] / m, b[2] / m] : [0, 0, 0]; }

// (Blender 3 · D3) LAS BANDAS van con el EJE DE GIRO, que no se mueve: un planeta en rotacion sincronica y sin oblicuidad (SUPUESTO: lo habitual
// en los cercanos a su estrella; de los demas no se sabe) tiene el ecuador en el plano de su orbita. Su eje en PANTALLA es la normal de la orbita
// proyectada; las bandas (el ecuador) van a 90° de el. -> angulo en pantalla de la direccion de las BANDAS (radianes, y hacia abajo; el +x del
// sprite: sus bandas son horizontales) o null si la orbita se ve de cara (eje hacia la camara: las bandas serian circulos; se deja la de antes).
// Vista desde la nave: basis = { r, d } de la camara y frame (fvsPlanetFrame). Vista desde la Tierra (el transito): basis null y la pantalla
// del panel (x = X, y = −Y de fvsTransitPos).
function fvsPlanetBandAngle(tr, starPos, basis, frame) {
   var n;
   if (basis) {
      var F = frame || fvsPlanetFrame(starPos), a = fvsPlanetOffset(tr, 0, F).off, b = fvsPlanetOffset(tr, Math.PI / 2, F).off;
      n = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
      var nl = Math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2]) || 1, nr = (n[0] * basis.r[0] + n[1] * basis.r[1] + n[2] * basis.r[2]) / nl, nd = (n[0] * basis.d[0] + n[1] * basis.d[1] + n[2] * basis.d[2]) / nl;
      if (Math.sqrt(nr * nr + nd * nd) < 0.05) return null;
      return Math.atan2(nd, nr) + Math.PI / 2;
   }
   var q0 = fvsTransitPos(tr, 0), q1 = fvsTransitPos(tr, tr.Ph / 4), A = [q0.x, -q0.y, -q0.z], B = [q1.x, -q1.y, -q1.z];     // pantalla del panel: x, y abajo, z hacia dentro
   n = [A[1] * B[2] - A[2] * B[1], A[2] * B[0] - A[0] * B[2], A[0] * B[1] - A[1] * B[0]];
   if (Math.sqrt(n[0] * n[0] + n[1] * n[1]) < 0.05 * Math.sqrt(n[0] * n[0] + n[1] * n[1] + n[2] * n[2])) return null;
   return Math.atan2(n[1], n[0]) + Math.PI / 2;
}
// (Blender 3 · D1) EL RESPLANDOR DE LA ESTRELLA en la portilla: a fase alta la estrella esta a γ = 180° − α de la linea de mirada (la nave mira
// desde lejos: el angulo en la estrella es ~0). La portilla es una camara con el planeta de radio angular FVS_PL.GLARE_RHO (ELECCION: con ella
// la estrella queda justo fuera del cristal a 165°, γ 15°, y su luz entra por ese lado); la estrella mide asin(1/aR). El perfil de la luz
// dispersa en la optica, I0 / (1 + (d/w)²), es ELECCION (como el halo de una lente); su POSICION y su TAMAÑO son la geometria.
// -> { d: centro de la estrella a d radios del planeta, rs: su radio (radios del planeta), on: si se dibuja } (rot da la direccion)
// GLARE_CORE (Blender 3, tras mirar B3_familias.png): el DISCO de la estrella, cuando entra en el cristal (planetas pegados a su estrella a
// 165°: aR ~3, la estrella mide ~19°), se pinta a 0,55 del blanco con su color y un limbo mas oscuro (0,82 del centro), no a 255: a 255 salia
// una media luna blanca quemada que tapaba el rotulo (3 770 px ≥ 250; con 0,80 quedaban 66 y con 0,60 uno, donde el aro de atmosfera cruza
// la estrella: P18b). ELECCION de presentacion (no fisica: la estrella real deslumbraria)
// (Blender 4 · PL-23) a 0,55 y con el color mezclado al 30 % con blanco, el disco de una estrella F (6300 K) salia GRIS (R≈G≈B 91–148,
// croma ~0): un aro de metal alrededor del planeta, no su estrella. Ahora: el color es el de la estrella por el MISMO camino que el panel
// y la vista principal (fvsBlackbodyColour(Teff), fvsPlanetGlareCol) y el disco a 0,92 (canal mayor 235 < 250: sigue sin quemar, P18b);
// la estrella es lo mas brillante del cristal, como en el panel del transito (226). ELECCION de presentacion; el ROJO de P23 es 0,55 + mezcla
FVS_PL.GLARE_RHO = Math.atan(0.1445); FVS_PL.GLARE_W = 1.2; FVS_PL.GLARE_I0 = 120; FVS_PL.GLARE_DMAX = 9; FVS_PL.GLARE_ON = true; FVS_PL.GLARE_CORE = 0.92; FVS_PL.GLARE_MIX = 0; FVS_PL.GLARE_UNDER = 0.55;   // UNDER: la pasada sumada de debajo (fv_planets3d.js fvPl3dGlare)
// el color del resplandor (sRGB 0..1, canal mayor 1): el cuerpo negro de la Teff de la estrella (look.teff) por fvsBlackbodyColour, mezclado
// con blanco a GLARE_MIX (Blender 3: 0,3 sobre look.star; ROJO de P23). Sin Teff ni tabla: blanco calido
function fvsPlanetGlareCol(look) {
   var c = null;
   if (look && look.teff > 0 && typeof fvsBlackbodyColour === "function") { var b = fvsBlackbodyColour(look.teff); c = [b.r / 255, b.g / 255, b.b / 255]; }
   else if (look && look.star) c = look.star.map(function(v) { return fvsSrgbGamma(Math.max(0, Math.min(1, v))); });
   else c = [1, 0.92, 0.82];
   var m = FVS_PL.GLARE_MIX || 0;
   return [c[0] * (1 - m) + m, c[1] * (1 - m) + m, c[2] * (1 - m) + m];
}
function fvsPlanetGlare(alphaDeg, aR) {
   var g = Math.max(0, 180 - alphaDeg) * Math.PI / 180, tr = Math.tan(FVS_PL.GLARE_RHO), d = Math.tan(Math.min(g, 1.5)) / tr;
   var rs = (aR > 1) ? Math.tan(Math.asin(1 / aR)) / tr : 0.5;
   return { d: d, rs: rs, on: !!FVS_PL.GLARE_ON && d < FVS_PL.GLARE_DMAX, w: FVS_PL.GLARE_W, i0: FVS_PL.GLARE_I0, core: 255 * FVS_PL.GLARE_CORE };
}

// el color lineal (0..∞) -> { col: [r,g,b] 0..255 sRGB del TONO (canal mayor = 255), op: opacidad 0..1 en sRGB } para pintar una capa gris
// codificada en sRGB multiplicada por un color: gamma(k·c·g) = gamma(k·c)·gamma(g) con la ley de potencia (el tramo lineal de sRGB se ignora)
function fvsPlanetPaint(lin) {
   var m = Math.max(lin[0], lin[1], lin[2]);
   if (!(m > 1e-7)) return { col: [0, 0, 0], op: 0 };
   var c = [lin[0] / m, lin[1] / m, lin[2] / m], k = Math.min(1, m);
   return { col: [Math.round(255 * fvsSrgbGamma(c[0])), Math.round(255 * fvsSrgbGamma(c[1])), Math.round(255 * fvsSrgbGamma(c[2]))], op: fvsSrgbGamma(k), sat: m > 1 };
}

// ---------------- geometria: donde esta el planeta y con que fase se ve ----------------
// base de la visual de la Tierra a la estrella (escena con la Tierra en el origen): z = Tierra -> estrella; x = SUPUESTO (nodo desconocido)
// (Blender 4 · defecto 1, 10-nov) EL NODO SE ELIGE para que la cuerda del transito salga HORIZONTAL, como la dibujan la vista principal
// (fvExoOnStar) y el panel (fvsTransitPos: X a lo largo, Y arriba): x = la DERECHA de una camara en la Tierra que mira a la estrella con el
// abajo de referencia +Y del mundo (fvBasis(z, [0, 1, 0]) de fv_math.js, la misma de fvProjector: r = d × f) e y = ARRIBA en esa pantalla
// (−d). Asi la normal de la orbita (el eje de giro, D3) queda vertical en pantalla y las bandas paralelas a la cuerda. Antes: up = [1, 0, 0]
// para z[2] > 0,9 (toda estrella de la foto: z es el eje optico, fv_scene.js fvPixelRay) daba la cuerda VERTICAL y las bandas a 90° del
// transito dibujado (revision-visual-Blender3-PL20.md, defecto 1: 89,9° / 90,1° / 94°). Si la estrella esta justo encima o debajo (z ∥ Y)
// se cae en el abajo de referencia [0, 0, 1], como fvBasis.
// (y = x × z: la base es de la otra mano que z × x; fvsPlanetOffset y fvsPlanetBandAngle no dependen de la mano, solo el sentido de giro
// de la orbita, que no se conoce)
function fvsPlanetFrame(starPos) {
   var l = Math.sqrt(starPos[0] * starPos[0] + starPos[1] * starPos[1] + starPos[2] * starPos[2]) || 1, z = [starPos[0] / l, starPos[1] / l, starPos[2] / l];
   var dr = [0, 1, 0], x = [dr[1] * z[2] - dr[2] * z[1], dr[2] * z[0] - dr[0] * z[2], dr[0] * z[1] - dr[1] * z[0]], lx = Math.sqrt(x[0] * x[0] + x[1] * x[1] + x[2] * x[2]);
   if (lx < 1e-6) { dr = [0, 0, 1]; x = [dr[1] * z[2] - dr[2] * z[1], dr[2] * z[0] - dr[0] * z[2], dr[0] * z[1] - dr[1] * z[0]]; lx = Math.sqrt(x[0] * x[0] + x[1] * x[1] + x[2] * x[2]) || 1; }
   x = [x[0] / lx, x[1] / lx, x[2] / lx];
   var y = [x[1] * z[2] - x[2] * z[1], x[2] * z[0] - x[0] * z[2], x[0] * z[1] - x[1] * z[0]];
   return { x: x, y: y, z: z };
}
// (Blender 4) el marco de antes (cuerda vertical en la foto), solo para el ROJO de la prueba de orientacion (fv_pl3d_test P22)
function fvsPlanetFrameOld(starPos) {
   var l = Math.sqrt(starPos[0] * starPos[0] + starPos[1] * starPos[1] + starPos[2] * starPos[2]) || 1, z = [starPos[0] / l, starPos[1] / l, starPos[2] / l];
   var up = Math.abs(z[2]) < 0.9 ? [0, 0, 1] : [1, 0, 0];
   var x = [z[1] * up[2] - z[2] * up[1], z[2] * up[0] - z[0] * up[2], z[0] * up[1] - z[1] * up[0]], lx = Math.sqrt(x[0] * x[0] + x[1] * x[1] + x[2] * x[2]);
   x = [x[0] / lx, x[1] / lx, x[2] / lx];
   var y = [z[1] * x[2] - z[2] * x[1], z[2] * x[0] - z[0] * x[2], z[0] * x[1] - z[1] * x[0]];
   return { x: x, y: y, z: z };
}
// el planeta a la fase orbital phi (radianes; 0 = centro del transito visto desde la Tierra), con la orbita de fvsTransitPos.
// -> offset del planeta respecto a la estrella en R★ (escena), y el vector unitario planeta -> estrella
function fvsPlanetOffset(tr, phi, frame) {
   var q = fvsTransitPos(tr, phi / (2 * Math.PI) * tr.Ph), F = frame;
   // fvsTransitPos: X a lo largo del transito, Y altura, Z > 0 hacia el observador (la Tierra) -> escena: −z
   var o = [q.x * F.x[0] + q.y * F.y[0] - q.z * F.z[0], q.x * F.x[1] + q.y * F.y[1] - q.z * F.z[1], q.x * F.x[2] + q.y * F.y[2] - q.z * F.z[2]];
   var l = Math.sqrt(o[0] * o[0] + o[1] * o[1] + o[2] * o[2]) || 1;
   return { off: o, toStar: [-o[0] / l, -o[1] / l, -o[2] / l], q: q };
}
// fase vista desde la camara: alpha = angulo estrella-planeta-camara (0 lleno, 180 nuevo); rot = angulo en PANTALLA de la direccion
// hacia la estrella (radianes, y hacia abajo; 0 = la estrella a la derecha). basis = { r, d } de la camara (fvProjector) o null.
// starPos, camPos en las unidades de la escena; rStarU = radio de la estrella en esas unidades (para colocar el planeta).
function fvsPlanetPhase(tr, phi, starPos, camPos, rStarU, basis, frame) {
   var F = frame || fvsPlanetFrame(starPos), P = fvsPlanetOffset(tr, phi, F), u = rStarU > 0 ? rStarU : 0;
   var pp = [starPos[0] + P.off[0] * u, starPos[1] + P.off[1] * u, starPos[2] + P.off[2] * u];
   var v = [camPos[0] - pp[0], camPos[1] - pp[1], camPos[2] - pp[2]], lv = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) || 1;
   v = [v[0] / lv, v[1] / lv, v[2] / lv];
   var L = P.toStar, c = Math.max(-1, Math.min(1, L[0] * v[0] + L[1] * v[1] + L[2] * v[2]));
   var rot = 0;
   if (basis) { var lr = L[0] * basis.r[0] + L[1] * basis.r[1] + L[2] * basis.r[2], ld = L[0] * basis.d[0] + L[1] * basis.d[1] + L[2] * basis.d[2]; rot = (Math.abs(lr) + Math.abs(ld) > 1e-9) ? Math.atan2(ld, lr) : 0; }
   return { alpha: Math.acos(c) * 180 / Math.PI, rot: rot, pos: pp, q: P.q, front: P.q.front };
}
// fraccion iluminada del disco a la fase alpha (grados): (1 + cos α) / 2 (esfera de Lambert; la prueba la usa de referencia)
function fvsPlanetLitFraction(alphaDeg) { return (1 + Math.cos(alphaDeg * Math.PI / 180)) / 2; }
