// ============================================================================
// FieldVoyager/src/science/fv_science.jsh — EL MODULO CIENTIFICO PARA PJSR (un solo #include, en este orden)
// ----------------------------------------------------------------------------
// En el navegador, los mismos ficheros con <script src> en el mismo orden. Ninguno lleva directivas: son ES5 puro.
// ============================================================================
#include "fv_sci_const.js"
#include "fv_sci_tables.js"
#include "fv_sci_i18n.js"
#include "fv_sci_colour.js"
#include "fv_sci_star.js"
#include "fv_sci_dist.js"
#include "fv_sci_transit.js"
#include "fv_sci_planet.js"
#include "fv_sci_travel.js"
#include "fv_sci_scale.js"
#include "fv_sci_phrases.js"
// (I12/I13, 4-nov) el espectro XP de Gaia y la composicion quimica de la ficha
#include "fv_sci_xp.js"
#include "fv_sci_chem.js"
#include "fv_sci_metal.js"
