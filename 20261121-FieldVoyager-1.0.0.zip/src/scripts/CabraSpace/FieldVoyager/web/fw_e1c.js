// ============================================================================
// FieldVoyager/web/fw_e1c.js — (I1, 19-nov-2026) AENIGMATA y la cadena de «¿por que?» EN EL VISOR WEB (gemelo de src/ui/fv_aenigma_ui.js)
// ----------------------------------------------------------------------------
// El calculo y los textos son los de PixInsight: engine/fv_aenigma.js (el mismo fichero) y scene.aenigma (los misterios YA calculados, que el paquete trae
// en scene.json: el visor no los recalcula, no tiene los errores de paralaje ni de movimiento propio). Aqui, solo lo que se ve y se pulsa:
//   · el REVERSO de la placa MIRABILIA: un clic en su rotulo (#navListCap) la gira; las filas son los sobres, con los gestos de siempre (clic = elegir,
//     doble clic o flecha = viajar). Sin misterios en la foto el rotulo no se pulsa ni lleva marca.
//   · la FICHA: la respuesta del eslabon y la prueba del misterio, en oro, delante del resumen; sus numeros en MÁS; y al pie UNA pregunta que se pulsa.
//   · con la ficha de una estrella de la pareja abierta, un rombo marca a la otra y un hilo las une.
// Ganchos de una linea: fw_viewer.js (fwShowCard, tras drawHud) y fw_nav.js (buildList, fwNavIconSvg). FW_E1C = false (o ?e1c=0): lo de antes.
// ES5.
// ============================================================================

var FW_E1C = true;
(function() { try { var q = /[?&]e1c=([01])/.exec(location.search); if (q) FW_E1C = q[1] === "1"; } catch (e) {} })();
var FW_E1C_S = { face: 0, init: false, card: null, sel: null, ver: -1 };

function fwE1cOn() {
   if (FW_E1C !== true || typeof fvE1cCard !== "function" || typeof FV_E1C === "undefined" || typeof FW === "undefined" || !FW.scene) { if (typeof FV_E1C !== "undefined") FV_E1C.ON = false; return false; }
   FV_E1C.ON = true;
   // los misterios vienen en el paquete; un paquete anterior a I1 no los trae: ninguno (no se recalculan con menos datos que PixInsight)
   if (!FW.scene.aenigma || !FW.scene.aenigma.list) FW.scene.aenigma = (FW.json && FW.json.aenigma && FW.json.aenigma.list) ? FW.json.aenigma : { v: 1, n: 0, list: [], why: { all: "package without AENIGMATA (exported before I1)" } };
   return true;
}
// la seleccion del motor -> la del visor (como fwNavSel)
function fwE1cSel(to) {
   var sc = FW.scene;
   if (to.kind === "star") return { kind: "star", i: to.i };
   if (to.kind === "object" && sc.objects && sc.objects[to.i]) { var o = sc.objects[to.i]; if (o.main) return { kind: "nebula", sx: 0, sy: 0, obj: to.i }; return { kind: "object", i: to.i }; }
   return { kind: "nebula", sx: 0, sy: 0, obj: -1 };
}
function fwE1cCss() {
   if (document.getElementById("fwE1cCss")) return;
   var st = document.createElement("style"); st.id = "fwE1cCss";
   st.textContent = "#cardText .cl.e1c-a{color:#F3D27E}#cardText .cl.e1c-q{color:#F3D27E;cursor:pointer;margin-top:.6em;font-style:italic}#cardText .cl.e1c-q:hover{text-decoration:underline}" +
                    "#navListCap.e1c-flip{cursor:pointer;pointer-events:auto}#navListCap.e1c-flip:hover{color:#FFE9A8}#navListCap.e1c-flip::after{content:'\\21C4';font-family:sans-serif;letter-spacing:0;margin-left:.5em;opacity:.8}";
   document.head.appendChild(st);
}
// ---------------------------------------------------------------------------
// LA FICHA: las lineas que añade la cadena. s = la seleccion del visor, L = las lineas de fwCardLines / fwObjCardLines. -> L
// ---------------------------------------------------------------------------
function fwE1cLines(s, L) {
   FW_E1C_S.card = null; FW_E1C_S.sel = s;
   if (!fwE1cOn() || !s || !L) return L;
   var R; try { R = fvE1cCard(FW.scene, s, FW_LANG); } catch (e) { if (window.console) console.warn("fw_e1c: " + e); return L; }
   FW_E1C_S.card = R; fwE1cCss(); fwE1cInit();
   if (R.opened) { if (FV_E1C_ST) FV_E1C_ST.resolved = false; if (typeof fvE1aPost === "function") fvE1aPost(FW.radio ? FW.radio.e1a : null, "resolve"); }      // (I5) el sonido que informa: un AENIGMA resuelto
   var at = 2, i;
   for (i = 0; i < L.length && i < 4; ++i) if (/\b(ok|warn|bad)\b/.test(L[i].c || "")) { at = i + 1; break; }
   at = Math.min(at, L.length);
   var ins = [];
   if (R.ans) ins.push({ t: R.ans, c: "pl e1c-a" });
   if (R.proof) ins.push({ t: R.proof, c: "pl e1c-a" });
   L = L.slice(0, at).concat(ins).concat(L.slice(at));
   // los numeros: en MÁS (C.l2 de la ficha comun) si la ficha lo tiene; si no (objetos), una linea mas al final del resumen
   var more = [R.proof2, R.ans2].filter(function(x) { return !!x; });
   if (more.length) {
      var C = (typeof FW_CARD_PI_C !== "undefined" && FW_CARD_PI_C.C && (s.kind === "star" || s.kind === "nebula") && FW_CARD_PI_C.key === s.kind + ":" + s.i) ? FW_CARD_PI_C.C : null;
      if (C && C.l2) { for (i = more.length - 1; i >= 0; --i) if (C.l2.indexOf(more[i]) < 0) C.l2.unshift(more[i]); }
      else for (i = 0; i < more.length; ++i) L.push({ t: more[i], c: "pl" });
   }
   if (R.link) L.push({ t: R.link.q, c: "pl e1c-q" });
   // un sobre recien abierto: la placa girada lo enseña abierto
   var v = fvE1cVer(FW.scene); if (v !== FW_E1C_S.ver) { FW_E1C_S.ver = v; if (FW.nav && FW_E1C_S.face === 1 && !FW.nav.shown) FW.nav.buildList(); }
   return L;
}
// seguir el eslabon de la ficha a la vista
function fwE1cFollow() {
   var R = FW_E1C_S.card, lk = R ? R.link : null;
   if (!lk || !fwE1cOn()) return false;
   var to = fvE1cFollow(FW.scene, lk); if (!to) return false;
   if (typeof fvE1aPost === "function") fvE1aPost(FW.radio ? FW.radio.e1a : null, "chain");      // (I5) el sonido que informa: un eslabon de la cadena
   var sel = fwE1cSel(to);
   if (typeof fwUserAct === "function") fwUserAct();
   if (FW.tour && typeof fwTourStop === "function") { try { fwTourStop(); } catch (eT) {} }
   fwSelectSel(sel);
   var ok = false; try { ok = fwTravel(sel); } catch (e) { ok = false; }
   if (!ok) fwShowCard(sel);      // ya se esta alli: la ficha, sin vuelo
   return true;
}
// ---------------------------------------------------------------------------
// LA PLACA
// ---------------------------------------------------------------------------
function fwE1cFace() { return FW_E1C_S.face === 1 && fwE1cOn() && FV_E1C.AENIG && fvE1cList(FW.scene).length > 0; }
// las filas que la placa enseña si esta girada; null = las de MIRABILIA. (gancho de FWNav.buildList)
function fwE1cFaceItems(nav) {
   fwE1cInit();
   if (!fwE1cFace()) return null;
   return fvE1cItems(FW.scene, FW_LANG);
}
function fwE1cCap() {
   var cap = document.getElementById("navListCap"), wrap = document.getElementById("navListWrap"); if (!cap) return;
   var has = fwE1cOn() && FV_E1C.AENIG && fvE1cList(FW.scene).length > 0;
   cap.classList.toggle("e1c-flip", has);
   cap.title = has ? fvE1cT("flip", null, FW_LANG) : "";
   if (FW.nav && !FW.nav.shown && !(FW.route && FW.route.bigOpen)) cap.textContent = fwNavT("mir");
   if (wrap && typeof fwNavT === "function") wrap.title = fwE1cFace() ? "" : fwNavT("mirTip");      // girada, la ayuda es la de cada sobre
}
function fwE1cFlip() {
   if (!fwE1cOn() || !FV_E1C.AENIG || !fvE1cList(FW.scene).length || !FW.nav) return false;
   if (FW.nav.listEl && FW.nav.listEl.style.display === "none") return false;      // con el mapa grande abierto la lista de ruta ocupa el hueco: la placa no se gira
   if (FW.nav.search && FW.nav.shown && typeof FW.nav.search.clear === "function") FW.nav.search.clear(true);
   FW_E1C_S.face = FW_E1C_S.face === 1 ? 0 : 1;
   FW.nav.buildList(); fwE1cCap();
   if (FW.P && typeof FW.nav.markSel === "function") FW.nav.markSel(FW.P.sel);
   return true;
}
function fwE1cInit() {
   if (FW_E1C_S.init || !fwE1cOn()) return;
   var cap = document.getElementById("navListCap"), tx = document.getElementById("cardText"); if (!cap || !tx) return;
   FW_E1C_S.init = true; fwE1cCss();
   cap.addEventListener("click", function(e) { if (cap.classList.contains("e1c-flip")) { e.stopPropagation(); fwE1cFlip(); } });
   ["pointerdown", "dblclick"].forEach(function(t) { cap.addEventListener(t, function(ev) { if (cap.classList.contains("e1c-flip")) ev.stopPropagation(); }); });
   tx.addEventListener("click", function(e) { var el = e.target; while (el && el !== tx) { if (el.classList && el.classList.contains("e1c-q")) { e.stopPropagation(); fwE1cFollow(); return; } el = el.parentNode; } });
   // el rotulo de la placa dice la cara que se ve (lo escriben fw_nav.js, fw_search.js y fw_route.js con fwNavT("mir"))
   if (typeof fwNavT === "function" && !fwNavT._e1c) { var t0 = fwNavT; fwNavT = function(k) { var s = t0.apply(this, arguments); return (k === "mir" && fwE1cFace() && !(FW.nav && FW.nav.shown)) ? fvE1cT("hd", null, FW_LANG) : s; }; fwNavT._e1c = true; }
   setTimeout(fwE1cCap, 0);
}
// los iconos de los sobres (gancho de fwNavIconSvg). -> true si lo ha pintado. el(t, a) = el constructor de trazos del llamador
function fwE1cIconSvg(type, el, c) {
   if (type !== "seal" && type !== "sealOpen") return false;
   el("rect", { x: -8, y: -5.5, width: 16, height: 11 });
   if (type === "seal") { el("path", { d: "M-8 -5.5 L0 0.6 L8 -5.5" }); el("circle", { cy: 0.6, r: 2.2, fill: c, stroke: "none" }); }
   else el("path", { d: "M-8 -5.5 L0 -10 L8 -5.5" });
   return true;
}
// la compañera de la pareja, marcada (tras FW.ck.drawHud). sx, sy = el objeto elegido en pantalla (CSS px) o null
function fwE1cHud(sx, sy) {
   if (sx === null || sx === undefined || !fwE1cOn() || !FV_E1C.AENIG || !FW.ck || !FW.ck.cardSel || FW.ck.cardHidden) return;
   var my = fvE1cOf(FW.scene, FW.ck.cardSel); if (!my || my.k !== "pair") return;
   var c = fvE1cCanon(FW.scene, FW.ck.cardSel), other = (my.sel.i === c.i) ? my.also : my.sel.i, p = fvProjector(FW.P.cam, FW.VW, FW.VH).project(fvStarPos(FW.scene, other));
   if (!p) return;
   var g = FW.ck.hctx, r = 7; if (!g) return;
   g.strokeStyle = "rgba(243,210,126,.82)"; g.lineWidth = 1; g.beginPath(); g.moveTo(p[0], p[1] - r); g.lineTo(p[0] + r, p[1]); g.lineTo(p[0], p[1] + r); g.lineTo(p[0] - r, p[1]); g.closePath(); g.stroke();
   var dx = p[0] - sx, dy = p[1] - sy, l = Math.sqrt(dx * dx + dy * dy);
   if (l > 3 * r) { g.strokeStyle = "rgba(243,210,126,.5)"; g.lineWidth = 0.8; g.beginPath(); g.moveTo(sx + dx / l * 2 * r, sy + dy / l * 2 * r); g.lineTo(p[0] - dx / l * 1.4 * r, p[1] - dy / l * 1.4 * r); g.stroke(); }
}
// (pruebas) el estado de la cadena y de la placa
function fwE1cTestState() {
   var on = fwE1cOn(), R = FW_E1C_S.card, cap = document.getElementById("navListCap"), rows = [].slice.call(document.querySelectorAll("#navList .nv-row")), tx = document.getElementById("cardText");
   return { on: on, flag: FW_E1C, face: on ? (fwE1cFace() ? 1 : 0) : 0, cap: cap ? cap.textContent : "", flip: !!(cap && cap.classList.contains("e1c-flip")), list: on ? fvE1cList(FW.scene).map(function(y) { return y.k; }) : [],
            rows: rows.map(function(r) { return (r.querySelector(".nv-nm") || {}).textContent + " | " + (r.querySelector(".nv-sb") || {}).textContent; }),
            items: on ? fvE1cItems(FW.scene, FW_LANG) : [], proof: R ? R.proof : null, ans: R ? R.ans : null, link: (R && R.link) ? { q: R.link.q, rule: R.link.rule, to: R.link.to, key: R.link.key } : null,
            gold: tx ? [].slice.call(tx.querySelectorAll(".e1c-a")).map(function(d) { return d.textContent; }) : [], qEl: tx ? [].slice.call(tx.querySelectorAll(".e1c-q")).length : 0,
            sel: (FW.P && FW.P.sel) ? { kind: FW.P.sel.kind, i: FW.P.sel.i } : null, selKey: (on && FW.P && FW.P.sel) ? fvE1cKey(FW.scene, FW.P.sel) : "", flying: !!(FW.P && FW.P.flight), cardShown: !!(FW.ck && FW.ck.cardSel && !FW.ck.cardHidden) };
}
