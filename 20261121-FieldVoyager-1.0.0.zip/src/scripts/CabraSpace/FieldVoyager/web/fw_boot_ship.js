// ============================================================================
// FieldVoyager/web/fw_boot_ship.js — LA NAVE DEL ARRANQUE en el visor del navegador (6-nov-2026), gemela de src/ui/fv_boot.js
// (FV_BOOT_SHIP) de PixInsight.
// ----------------------------------------------------------------------------
// Mientras el visor se arma (fwBoot / fwStart de fw_viewer.js), en vez del rotulo y la barra: la nave FieldVoyager girando despacio
// (72 fotogramas WebP con alfa de fw_nave_data.js, hecho por tools/build_nave_rsc.py) y, segun arranca cada paso REAL del visor, una
// flecha fina de laton desde el rotulo del sistema (a los lados, huecos fijos: no se pisan) hasta su pieza, con un halo ambar
// mientras calienta; al terminar, ✓ y el rotulo se apaga. Al final, los casquetes de las gondolas y los ojos de la cabra se
// encienden y la pantalla de arranque se funde (la transicion de siempre de #boot).
// La animacion NUNCA retrasa el arranque: lee el estado de verdad (fwShipSet) y, si varios pasos acaban casi a la vez, los enseña en
// cola con un minimo de MIN_S cada uno; esa cola solo alarga el final, y como mucho MAX_EXTRA_S (+ FINAL_S de brillo: ≤ 1 s).
// fw_nave_data.js (≈ 5 MB) se pide DESPUES de arrancar (no retrasa la carga de la pagina); hasta que llega, se ven la placa y los
// rotulos, y la nave entra con un fundido corto. Si no llega (paquete viejo), el arranque sigue igual sin nave.
// Los pasos del visor → sistemas: la foto = navegacion · los recortes y la foto sin estrellas = filtros · la escena del paquete =
// cartas (estrellas) y telescopio de largo alcance (distancias) · el pintor WebGL = cupula · la leyenda = atlas · la lista y el buscador = sensores ·
// objetos y piloto = escudos · los sombreadores de la nebulosa = proyector.
// FW_BOOT_SHIP.ON = false: el rotulo y la barra de antes.
// (7-nov, Nino) LOS PLANOS FIJOS, como en PixInsight (FV_BOOT_SHIP.STILLS de src/ui/fv_boot.js): cada sistema que arranca, un fundido a
// SU plano fijo (otra perspectiva, la pieza señalada por su flecha y su halo); al final, el plano de los casquetes y los ojos de la cabra
// y la partida. El visor web no tiene interruptor (arranca solo, sin espera), asi que aqui no hay giro: fw_nave_data.js solo lleva el
// giro si el paquete lo trae (tools/build_nave_rsc.py, WEB_TT_FRAMES). Un plano no entra hasta que su imagen esta descodificada.
// ?bootstills=0 (pruebas): sin planos fijos (ROJO).
// ES5.
// ============================================================================
// SMOOTH (6-nov, Nino: «totalmente fluido»): angulo continuo, fotograma i y el i+1 fundido con la parte fraccionaria; anclas interpoladas
var FW_BOOT_SHIP = { ON: true, TURN_S: 30, START_DEG: 315, SMOOTH: true, MIN_S: 0.30, LAG_MAX: 0.8, FINAL_S: 0.4, MAX_EXTRA_S: 0.6, OUT_S: 0.6, SHIP_IN_S: 0.3, HALO: 70, HALO_END: 120,
                     STILLS: true, STOP_S: 0.4, XF: 0.5, HOLD: 0.35, XF_OK: 0.45, END_CAP_S: 6,         // END_CAP_S: lo mas que la presentacion puede quedarse sin avanzar (seguro)
                     // (7-nov, Nino: «los 9 siempre») como en PixInsight (FV_BOOT_SHIP.QUEUE): los 9 planos en cola, Q_HOLD s cada uno
                     // (8-nov, Nino: «cambia a 2 segundos») como en PixInsight: Q_HOLD 1,2 → 2 y el plano final ≥ OK_HOLD s
                     QUEUE: true, Q_HOLD: 2.0, WARM_MIN: 0.6, OK_HOLD: 2.0, BLEND_W: 0.5,          // BLEND_W: como en PixInsight (medido en tests/fv_boot_ship_nitidez.py)
                     // (9-nov, Nino viendo el arranque en PixInsight: «cuando algo tarda mas de dos segundos parece que pasa por encima de las imagenes
                     // siguientes. Cada imagen tiene que tardar un minimo de 2 segundos y un maximo de lo que tarde en cargar el tema») como en
                     // PixInsight (FV_BOOT_SHIP.HOLD_TASK): cada plano se VE entero ≥ Q_HOLD / OK_HOLD s y el siguiente no sale hasta que acaba
                     // la tarea del que se ve; un hueco largo entre dos pintadas (el hilo ocupado) con un fundido a medias lo PAUSA y sigue donde iba.
                     // El plano final cuenta OK_HOLD quieto (el fundido aparte). false (?boothold=0) = lo de antes (el ROJO de tests/web/fv_boot_hold_cdp.js)
                     HOLD_TASK: true, GAP_S: 0.15,
                     // (7-nov) EL INTERRUPTOR en la web: la placa sale con la nave girando y POTENTIA; el arranque de verdad va por detras desde
                     // el principio (no espera a nadie) y la presentacion de los 9 planos empieza al tirar. Si nadie tira, se tira solo a los
                     // AUTO_S s (un vuelo exportado se abre tambien sin nadie delante: grabaciones, pruebas, una pantalla de exposicion).
                     // ?bootswitch=0: sin interruptor (tirado al empezar, como antes) · ?bootauto=0: no se tira solo · ?bootauto=N: a los N s
                     SWITCH: true, AUTO_S: 2.5 };
try { if (/[?&]bootswitch=0/.test(location.search)) FW_BOOT_SHIP.SWITCH = false; var qa = /[?&]bootauto=(\d+(\.\d+)?)/.exec(location.search); if (qa) FW_BOOT_SHIP.AUTO_S = +qa[1] > 0 ? +qa[1] : Infinity;
      if (/[?&]bootqueue=0/.test(location.search)) FW_BOOT_SHIP.QUEUE = false; if (/[?&]boothold=0/.test(location.search)) FW_BOOT_SHIP.HOLD_TASK = false; } catch (e) {}
try { if (/[?&]bootship=0/.test(location.search)) FW_BOOT_SHIP.ON = false; if (/[?&]bootsmooth=0/.test(location.search)) FW_BOOT_SHIP.SMOOTH = false; if (/[?&]bootstills=0/.test(location.search)) FW_BOOT_SHIP.STILLS = false; } catch (e) {}      // pruebas: los ROJOS (?bootship=0, ?bootsmooth=0, ?bootstills=0)
var FW_BOOT_ORDER = ["nav", "charts", "range", "filters", "atlas", "shields", "sensors", "dome", "holo"];
var FW_BOOT_SIDE = { nav: 0, charts: 1, range: 0, filters: 1, atlas: 0, shields: 1, sensors: 0, dome: 1, holo: 0 };
// los nombres si el paquete no trae ui/fv_text.js (los mismos que FV_TX)
var FW_BOOT_TX = {
   en: { nav: ["Navigation computer", "astrometric solution"], charts: ["Star charts", "Gaia DR3 (local)"], range: ["Long range telescope", "VizieR: RUWE + Bailer-Jones"],
         filters: ["Optical filters", "stars removed from the photo"], atlas: ["Nebula atlas", "Sharpless + SIMBAD distance"], shields: ["Deflector shields", "3D dust map (Edenhofer 2024)"],
         sensors: ["Long-range sensors", "NASA Exoplanet Archive"], dome: ["Celestial dome", "stars in 3D and the sky around"], holo: ["Nebula projector", "nebula layers"] },
   es: { nav: ["Ordenador de navegación", "solución astrométrica"], charts: ["Cartas estelares", "Gaia DR3 (local)"], range: ["Telescopio de largo alcance", "VizieR: RUWE + Bailer-Jones"],
         filters: ["Filtros ópticos", "estrellas quitadas de la foto"], atlas: ["Atlas de nebulosas", "Sharpless + distancia de SIMBAD"], shields: ["Escudos deflectores", "mapa 3D del polvo (Edenhofer 2024)"],
         sensors: ["Sensores de largo alcance", "NASA Exoplanet Archive"], dome: ["Cúpula celeste", "estrellas en 3D y el cielo de alrededor"], holo: ["Proyector de nebulosas", "capas de la nebulosa"] }
};
var FW_BOOT_COL = { ivory: "#F4ECDC", ivory2: "#D9CDB4", gold: "#C99A3A", goldL: "#E9C97A", goldT: "#9C8358", dim: "#6E604A", ok: "#9CC48E", warm: "#E5B53F", local: "#D9A441", fail: "#D0603F" };
var FW_BOOT_FONT = { display: "\"Bodoni Moda\",\"Bodoni 72\",\"Bodoni MT\",Didot,\"Palatino Linotype\",Georgia,serif",
                     text: "\"Palatino Linotype\",\"Book Antiqua\",Palatino,\"Iowan Old Style\",Georgia,serif" };
var FW_SHIP = { nScaled: 0, nPx: 0, on: false, t0: 0, sys: {}, done: false, tDone: undefined, data: null, imgs: [], ready: [], halo: null, haloOk: false, cv: null, raf: 0,
                doing: "", gone: false, loadedAt: null, nDecoded: 0, drawn: 0, lastFrame: -1, stalls: 0 };

function fwShipNow() { return (typeof FW_SHIP.tFix === "number") ? FW_SHIP.tFix : (performance.now() - FW_SHIP.t0) / 1000; }      // tFix: pruebas (reloj fijo)
function fwShipName(id, what) {
   if (typeof fvTx === "function") { try { var s = fvTx("sys." + id + (what ? ".what" : ""), null, FW_LANG); if (s && s.indexOf("sys.") !== 0) return s; } catch (e) {} }
   var T = FW_BOOT_TX[FW_LANG === "es" ? "es" : "en"][id]; return T ? T[what ? 1 : 0] : id;
}
// arranca la pantalla de la nave (fwBoot) → true si esta encendida
function fwShipStart() {
   if (!FW_BOOT_SHIP.ON || FW_SHIP.on) return FW_SHIP.on;
   var boot = document.getElementById("boot");
   if (!boot) return false;
   FW_SHIP.on = true; FW_SHIP.t0 = performance.now(); FW_SHIP.tSwitch = FW_BOOT_SHIP.SWITCH ? undefined : 0;          // sin interruptor: «tirado» al empezar
   for (var i = 0; i < FW_BOOT_ORDER.length; ++i) FW_SHIP.sys[FW_BOOT_ORDER[i]] = { st: "off", t: undefined, tOk: undefined };
   if (!FW_BOOT_SHIP.SWITCH && typeof fwRadioM1 === "function") fwRadioM1("start");          // (M1) sin interruptor no hay clic: la musica empieza al arrancar (sin gesto)
   var cv = document.createElement("canvas"); cv.id = "bootShip"; cv.setAttribute("aria-hidden", "true");
   boot.appendChild(cv); boot.classList.add("ship"); FW_SHIP.cv = cv;
   // el interruptor (clic) y saltar la presentacion (clic fuera de el o Esc) en cuanto el visor esta listo
   cv.style.pointerEvents = "auto";
   // pointerdown, y sin dejarlo subir: #win captura el puntero al pulsar (fw_viewer.js) y el «click» le llegaba a el, no al lienzo (medido 7-nov)
   cv.addEventListener("pointerdown", function(ev) { if (ev.button !== 0 || FW_SHIP.gone) return; ev.stopPropagation(); ev.preventDefault(); fwShipClick(ev.offsetX, ev.offsetY); });
   cv.addEventListener("mousemove", function(ev) { var r = FW_SHIP.leverCss; cv.style.cursor = (r && FW_SHIP.tSwitch === undefined && ev.offsetX >= r[0] && ev.offsetX <= r[2] && ev.offsetY >= r[1] && ev.offsetY <= r[3]) ? "pointer" : "default"; });
   document.addEventListener("keydown", function(ev) { if ((ev.key === "Escape" || ev.key === "Esc") && FW_SHIP.endCb) fwShipEndNow(); });
   // los fotogramas, cuando la pagina ya ha arrancado (un .js para que funcione con file://)
   var sc = document.createElement("script"); sc.src = "fw_nave_data.js"; sc.async = true;
   sc.onerror = function() { console.warn("boot ship: fw_nave_data.js not found (boot without the ship)"); };
   document.body.appendChild(sc);
   FW_SHIP.raf = requestAnimationFrame(fwShipLoop);
   return true;
}
// tira del interruptor (clic en la palanca o solo, a los AUTO_S s)
function fwShipThrow(why) {
   if (FW_SHIP.tSwitch !== undefined || !FW_SHIP.on) return; FW_SHIP.tSwitch = fwShipNow(); FW_SHIP.thrownBy = why; FW_SHIP.lastProg = FW_SHIP.tSwitch;
   if (typeof fwRadioM1 === "function") fwRadioM1(why);          // (19-nov, M1) la musica empieza aqui; con el clic, dentro del gesto de usuario
}
function fwShipClick(x, y) {
   var r = FW_SHIP.leverCss;
   if (FW_SHIP.tSwitch === undefined) { if (r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) fwShipThrow("click"); return; }
   if (FW_SHIP.endCb) fwShipEndNow();          // ya tirado y el visor listo: un clic salta la presentacion (directo a la cabina)
}
// fw_nave_data.js llama aqui al cargarse: las imagenes se descodifican fuera del hilo (img.decode) y solo se pintan las ya listas
function fwShipLoaded() {
   var D = window.FW_NAVE_DATA; if (!D || !D.img || !D.anchors) return;
   FW_SHIP.data = D; FW_SHIP.loadedAt = fwShipNow();
   var n = D.img.length;
   FW_SHIP.imgs = new Array(n); FW_SHIP.ready = new Array(n);
   function dec(i) {
      var im = new Image(); FW_SHIP.imgs[i] = im;
      var done = function() { FW_SHIP.ready[i] = true; ++FW_SHIP.nDecoded; };
      im.src = D.img[i];
      if (im.decode) im.decode().then(done, function() { im.onload = done; });
      else im.onload = done;
   }
   // (7-nov) los planos fijos primero, en el orden del arranque (el que va a salir antes, antes)
   // (en cadena: uno detras de otro, para no competir todos a la vez con el arranque de verdad; medido 7-nov: a la vez, visor listo +0,5 s)
   FW_SHIP.shotImg = {}; FW_SHIP.shotReady = {}; FW_SHIP.shotPx = {};
   var SK = (D.shots && D.shots.list) ? FW_BOOT_ORDER.concat(["ok"]).filter(function(k) { return D.shots.list[k] && D.shots.list[k].img; }) : [];
   (function next(j) {
      if (j >= SK.length || FW_SHIP.gone) return;
      var k = SK[j], im = new Image(), fired = false; FW_SHIP.shotImg[k] = im;
      var ok = function() { if (fired) return; fired = true; FW_SHIP.shotReady[k] = true; setTimeout(function() { next(j + 1); }, 0); };
      im.src = D.shots.list[k].img;
      if (im.decode) im.decode().then(ok, function() { if (im.complete) ok(); else im.onload = ok; }); else im.onload = ok;
   })(0);
   // primero los que van a salir enseguida, luego el resto
   var f0 = n ? fwShipFrameAt(fwShipNow() + 0.2) : 0;
   for (var k = 0; k < n; ++k) dec((f0 + k) % n);
   // la partida de Blender, si el paquete la trae
   if (D.dep && D.dep.img) { FW_SHIP.depImgs = new Array(D.dep.img.length); FW_SHIP.depReady = new Array(D.dep.img.length);
      D.dep.img.forEach(function(src, i) { var im = new Image(); FW_SHIP.depImgs[i] = im; var ok = function() { FW_SHIP.depReady[i] = true; }; im.src = src; if (im.decode) im.decode().then(ok, function() { im.onload = ok; }); else im.onload = ok; }); }
   var h = new Image(); h.src = D.halo; if (h.decode) h.decode().then(function() { FW_SHIP.haloOk = true; }, function() { h.onload = function() { FW_SHIP.haloOk = true; }; }); else h.onload = function() { FW_SHIP.haloOk = true; };
   FW_SHIP.halo = h;
}
function fwShipAngle(t) {
   var C = FW_BOOT_SHIP, v = 360 / C.TURN_S, go;
   if (fwShotsOn() && FW_SHIP.tSwitch !== undefined && t > FW_SHIP.tSwitch) { var u = Math.min(1, (t - FW_SHIP.tSwitch) / C.STOP_S); go = v * Math.max(0, FW_SHIP.tSwitch) + v * C.STOP_S * (u - u * u / 2); }
   else go = v * Math.max(0, t);
   // (7-nov) la web lleva solo un ARCO del giro (build_nave_rsc.py WEB_TT_ARC_DEG): si se acaba (nadie tira), la nave va y vuelve dentro de el
   var A = FW_SHIP.data && FW_SHIP.data.arc;
   if (A) { var span = Math.max(1e-3, (FW_SHIP.data.frames - 1) * A.deg_per_frame), m = go % (2 * span); return A.deg0 + (m <= span ? m : 2 * span - m); }
   return C.START_DEG + go;
}
// ---- (7-nov) LOS PLANOS FIJOS (gemelo de fvBootShotUpdate / fvBootShotView de PixInsight) ----
function fwShotsOn() { var D = FW_SHIP.data; return !!(FW_BOOT_SHIP.STILLS && D && D.shots && D.shots.list); }
// la caja del plano: el fotograma entero del giro a la escala del giro (el plano final casa con d_000 de la partida)
function fwShotBox(L) { var D = FW_SHIP.data, r = D.src_res || [960, 540]; return { x: L.sx - D.crop[0] * L.s, y: L.sy - D.crop[1] * L.s, w: r[0] * L.s, h: r[1] * L.s }; }
function fwShotUpdate(SC, t) {
   var C = FW_BOOT_SHIP, list = FW_SHIP.data.shots.list, R = FW_SHIP.shotReady || {}, i, id;
   if (FW_SHIP.tSwitch === undefined) return;                       // aun sin tirar: la nave gira esperando
   var S = FW_SHIP.shot || (FW_SHIP.shot = { ch: [], seen: {}, nxt: FW_SHIP.tSwitch + (FW_SHIP.data.frames ? C.STOP_S : 0), okT: undefined });
   var last = S.ch.length ? S.ch[S.ch.length - 1] : null;
   // (9-nov) el reloj de pintado: un hueco largo entre dos pintadas con un fundido a medias lo PAUSA (ver HOLD_TASK); se descuenta GAP_S (ver PixInsight)
   if (C.HOLD_TASK) {
      if (S.pt !== undefined && last && t - S.pt > C.GAP_S && S.pt < last.t + ((last.key === "ok") ? C.XF_OK : C.XF)) {
         var sh = t - S.pt - C.GAP_S; last.t += sh; S.nxt += sh; if (S.okT !== undefined) S.okT = last.t;
      }
      S.pt = t;
   }
   if (S.okT !== undefined) return;
   if (C.QUEUE) {
      if (t < S.nxt) return;
      // (9-nov) y el siguiente no sale hasta que acabe de verdad la tarea del plano que se ve
      if (C.HOLD_TASK && last && last.key !== "ok" && !FW_SHIP.done) { var ps = FW_SHIP.sys[last.key]; if (ps && ps.tOk === undefined) return; }
      var nx = null, nt = Infinity, ni = Infinity, left = 0;
      for (i = 0; i < FW_BOOT_ORDER.length; ++i) {
         id = FW_BOOT_ORDER[i]; if (!list[id] || S.seen[id]) continue;
         ++left;
         var sy = FW_SHIP.sys[id], st0 = (sy.st !== "off") ? (typeof sy.t === "number" ? sy.t : 0) : (FW_SHIP.done ? 1e9 : Infinity);
         if (st0 === Infinity) continue;
         if (st0 < nt || (st0 === nt && i < ni)) { nt = st0; ni = i; nx = id; }
      }
      if (nx) { if (R[nx]) { S.ch.push({ t: t, key: nx, p: t }); S.seen[nx] = true; S.nxt = t + C.XF + C.Q_HOLD; FW_SHIP.lastProg = t; } return; }
      if (left === 0 && FW_SHIP.done && list.ok && R.ok) { S.ch.push({ t: t, key: "ok" }); S.okT = t; FW_SHIP.lastProg = t; }
      return;
   }
   if (SC.ready !== Infinity && t >= SC.ready && list.ok) {
      if (R.ok && t >= (last ? last.t + C.XF : S.nxt)) { S.ch.push({ t: t, key: "ok" }); S.okT = t; }
      return;
   }
   if (t < S.nxt) return;
   var pick = null, pw = -Infinity;
   for (i = 0; i < FW_BOOT_ORDER.length; ++i) { id = FW_BOOT_ORDER[i]; var sc = SC[id]; if (!sc || S.seen[id] || !(sc.w <= t) || !list[id] || !R[id]) continue; if (sc.w >= pw) { pw = sc.w; pick = id; } }
   if (!pick) return;
   for (i = 0; i < FW_BOOT_ORDER.length; ++i) { id = FW_BOOT_ORDER[i]; if (SC[id] && SC[id].w <= t && R[id]) S.seen[id] = true; }
   S.ch.push({ t: t, key: pick }); S.nxt = t + C.XF + C.HOLD;
}
// la PRESENTACION con la cola (gemela de fvBootPresSched): calentando desde su plano hasta max(cuando acabo, w + WARM_MIN)
function fwPresSched() {
   var C = FW_BOOT_SHIP, out = {}, w = {}, ch = (FW_SHIP.shot && FW_SHIP.shot.ch) || [], i;
   for (i = 0; i < ch.length; ++i) w[ch[i].key] = ch[i].t;
   for (i = 0; i < FW_BOOT_ORDER.length; ++i) {
      var id = FW_BOOT_ORDER[i], s = FW_SHIP.sys[id], st = s.st;
      if (st === "off" && FW_SHIP.done) st = "skip";
      var wi = (w[id] !== undefined) ? w[id] : Infinity, k = Infinity;
      if (wi !== Infinity && st !== "warm" && st !== "off") { var tOk = (s.tOk !== undefined) ? s.tOk : (FW_SHIP.tDone !== undefined ? FW_SHIP.tDone : wi); k = Math.max(tOk, wi + C.WARM_MIN); }
      out[id] = { w: wi, k: k, st: st };
   }
   out.ready = (FW_SHIP.shot && FW_SHIP.shot.okT !== undefined) ? FW_SHIP.shot.okT : Infinity; out.extra = 0;
   return out;
}
function fwShotView(t) {
   var ch = (FW_SHIP.shot && FW_SHIP.shot.ch) || [], k = ch.length - 1;
   while (k >= 0 && ch[k].t > t) --k;
   if (k < 0) return { from: null, to: "tt", f: 1 };
   var cur = ch[k], xf = (cur.key === "ok") ? FW_BOOT_SHIP.XF_OK : FW_BOOT_SHIP.XF;
   return { from: k > 0 ? ch[k - 1].key : "tt", to: cur.key, f: fwShipSmooth((t - cur.t) / xf) };
}
// el plano «k» escalado a pw x ph pixeles de pantalla (una vez; el escalado de alta calidad de 1920 x 1080 en cada pintada costaba)
function fwShotPx(k, pw, ph) {
   var key = pw + "x" + ph, C = FW_SHIP.shotPx;
   if (C._k !== key) { FW_SHIP.shotPx = C = { _k: key }; }
   if (C[k]) return C[k];
   var im = FW_SHIP.shotImg[k]; if (!im || !FW_SHIP.shotReady[k]) return null;
   var cv = document.createElement("canvas"); cv.width = pw; cv.height = ph;
   var o = cv.getContext("2d"); o.imageSmoothingEnabled = true; o.imageSmoothingQuality = "high"; o.drawImage(im, 0, 0, pw, ph);
   C[k] = cv; ++FW_SHIP.nScaled;
   return cv;
}
// (7-nov) la franja bajo los rotulos (gemela de fvBootShotBand): color de la placa a los lados, desvaneciendose hacia la nave, y un
// fundido corto arriba y abajo (los planos de cerca llenan los tercios y pasaban por debajo de los rotulos)
function fwShotBand(c, L, BX, w) {
   if (w <= 0.004) return;
   // 2 px mas por cada lado: el borde de la imagen escalada cae a medio pixel y su ultima fila asomaba como una raya clara (web_sistema3, 7-nov)
   BX = { x: BX.x - 2, y: BX.y - 2, w: BX.w + 4, h: BX.h + 4 };
   var P = "13,10,7", x2 = L.sx + 40, x1 = L.sx - 30, k = Math.max(0.01, Math.min(0.99, (x1 - BX.x) / (x2 - BX.x)));
   function grad(xa, xb) { var g = c.createLinearGradient(xa, 0, xb, 0); g.addColorStop(0, "rgba(" + P + ",1)"); g.addColorStop(k, "rgba(" + P + ",.88)"); g.addColorStop(1, "rgba(" + P + ",0)"); return g; }
   c.save(); c.globalAlpha = Math.min(1, w);
   c.fillStyle = grad(BX.x, x2); c.fillRect(BX.x, BX.y, x2 - BX.x, BX.h);
   var rx = BX.x + BX.w, rx2 = L.sx + L.sw - 40; c.fillStyle = grad(rx, rx2); c.fillRect(rx2, BX.y, rx - rx2, BX.h);
   var gt = c.createLinearGradient(0, BX.y, 0, BX.y + 36); gt.addColorStop(0, "rgba(" + P + ",1)"); gt.addColorStop(1, "rgba(" + P + ",0)"); c.fillStyle = gt; c.fillRect(BX.x, BX.y, BX.w, 36);
   var gb = c.createLinearGradient(0, BX.y + BX.h, 0, BX.y + BX.h - 36); gb.addColorStop(0, "rgba(" + P + ",1)"); gb.addColorStop(1, "rgba(" + P + ",0)"); c.fillStyle = gb; c.fillRect(BX.x, BX.y + BX.h - 36, BX.w, 36);
   c.restore();
}
// fundido EXACTO de dos imagenes con alfa (o una sola si b es null) en un lienzo aparte con «lighter» (como el del giro)
function fwDrawPx(c, im, x, y, w, h) {
   var tr = c.getTransform(), pw = Math.round(w * tr.a), ph = Math.round(h * tr.d);
   if (im.width === pw && im.height === ph && !tr.b && !tr.c) {
      c.save(); c.setTransform(1, 0, 0, 1, 0, 0); c.drawImage(im, Math.round(x * tr.a + tr.e), Math.round(y * tr.d + tr.f)); c.restore(); ++FW_SHIP.nPx;
   } else c.drawImage(im, x, y, w, h);
}
function fwShipBlend(c, a, b, f, x, y, w, h, alpha) {
   if (!b || f >= 0.996) { if (b || a) { c.globalAlpha = alpha; fwDrawPx(c, b || a, x, y, w, h); c.globalAlpha = 1; } return; }
   if (!a) { c.globalAlpha = alpha * f; fwDrawPx(c, b, x, y, w, h); c.globalAlpha = 1; return; }
   var tr = c.getTransform(), pw = Math.max(1, Math.round(w * tr.a)), ph = Math.max(1, Math.round(h * tr.d));
   var oc = FW_SHIP.oc2 || (FW_SHIP.oc2 = document.createElement("canvas")); if (oc.width !== pw || oc.height !== ph) { oc.width = pw; oc.height = ph; }
   var o = oc.getContext("2d"); o.setTransform(1, 0, 0, 1, 0, 0); o.globalCompositeOperation = "source-over"; o.globalAlpha = 1; o.clearRect(0, 0, pw, ph);
   o.imageSmoothingEnabled = true; o.imageSmoothingQuality = "high"; o.globalCompositeOperation = "lighter";
   o.globalAlpha = 1 - f; o.drawImage(a, 0, 0, pw, ph); o.globalAlpha = f; o.drawImage(b, 0, 0, pw, ph);
   c.globalAlpha = alpha; fwDrawPx(c, oc, x, y, w, h); c.globalAlpha = 1;
}
// el angulo -> { i0, i1, f } (como fvBootShipPosAt de PixInsight; deg_per_frame del paquete: la web puede llevar menos fotogramas)
function fwShipPosAt(deg) {
   var D = FW_SHIP.data, n = D ? D.frames : 72, dpf = (D && D.deg_per_frame) || 360 / n, fp, fl, i0;
   if (D && D.arc) {                                                   // el arco: del fotograma 0 (deg0) al n − 1, sin dar la vuelta
      fp = Math.max(0, Math.min(n - 1, (((deg - D.arc.deg0) % 360 + 360) % 360) / dpf)); if (fp > n - 1 - 1e-6) return { i0: n - 1, i1: n - 1, f: 0 };
      fl = Math.floor(fp); i0 = fl;
      if (!FW_BOOT_SHIP.SMOOTH) return { i0: Math.round(fp), i1: Math.round(fp), f: 0 };
   } else {
      fp = deg / dpf; fl = Math.floor(fp); i0 = ((fl % n) + n) % n;
      if (!FW_BOOT_SHIP.SMOOTH) return { i0: ((Math.round(fp) % n) + n) % n, i1: i0, f: 0 };
   }
   var f = fp - fl, bw = FW_BOOT_SHIP.BLEND_W;
   if (bw < 0.999) f = fwShipSmooth((f - (1 - bw) / 2) / Math.max(1e-3, bw));
   return { i0: i0, i1: (D && D.arc) ? Math.min(n - 1, i0 + 1) : (i0 + 1) % n, f: f };
}
function fwShipFrameAt(t) { return fwShipPosAt(fwShipAngle(t)).i0; }
function fwShipLerp(a0, a1, f) {
   if (!a0 && !a1) return null;
   if (!a1 || f <= 0) return a0 ? [a0[0], a0[1], (a0[2] ? 1 : 0) * (a1 ? 1 - f : 1)] : null;
   if (!a0) return [a1[0], a1[1], (a1[2] ? 1 : 0) * f];
   return [a0[0] + (a1[0] - a0[0]) * f, a0[1] + (a1[1] - a0[1]) * f, (a0[2] ? 1 : 0) * (1 - f) + (a1[2] ? 1 : 0) * f];
}
function fwShipReadyAt(D, P) {
   var R0 = D.ready[P.i0] || [], R1 = (P.f > 0 ? D.ready[P.i1] : null) || [], out = [], i, j, by = {};
   for (j = 0; j < R1.length; ++j) by[R1[j][2]] = R1[j];
   for (i = 0; i < R0.length; ++i) { var b = by[R0[i][2]]; if (b) { out.push([R0[i][0] + (b[0] - R0[i][0]) * P.f, R0[i][1] + (b[1] - R0[i][1]) * P.f, 1]); delete by[R0[i][2]]; } else out.push([R0[i][0], R0[i][1], 1 - P.f]); }
   for (var k in by) out.push([by[k][0], by[k][1], P.f]);
   return out;
}
// la nave en P: i0 y, encima, i1 con opacidad f; si un fotograma aun no esta descodificado, el ultimo que si (sin fundido) -> P usado
function fwShipDrawAt(c, L, P, alpha) {
   var D = FW_SHIP.data, n = D.frames, f = P.i0;
   if (!n) return null;
   for (var b = 0; b < n && !FW_SHIP.ready[f]; ++b) f = (f - 1 + n) % n;
   if (!FW_SHIP.ready[f]) return null;
   var use = (f === P.i0) ? P : { i0: f, i1: f, f: 0 };
   if (use.f > 0.004 && FW_SHIP.ready[use.i1]) {
      // fundido EXACTO (1 − f)·A + f·B en un lienzo aparte con «lighter» (alfa premultiplicado: la suma no pasa de 255). Con SourceOver
      // directo asomaba el fotograma de debajo por el contorno del de encima y saltaba al cambiar de fotograma (medido: paso 2,4 veces mayor)
      var tr = c.getTransform(), w = Math.max(1, Math.round(L.sw * tr.a)), h = Math.max(1, Math.round(L.sh * tr.d));
      var oc = FW_SHIP.oc || (FW_SHIP.oc = document.createElement("canvas")); if (oc.width !== w || oc.height !== h) { oc.width = w; oc.height = h; }
      var o = oc.getContext("2d"); o.setTransform(1, 0, 0, 1, 0, 0); o.globalCompositeOperation = "source-over"; o.globalAlpha = 1; o.clearRect(0, 0, w, h);
      o.imageSmoothingEnabled = true; o.imageSmoothingQuality = "high"; o.globalCompositeOperation = "lighter";
      o.globalAlpha = 1 - use.f; o.drawImage(FW_SHIP.imgs[use.i0], 0, 0, w, h);
      o.globalAlpha = use.f; o.drawImage(FW_SHIP.imgs[use.i1], 0, 0, w, h);
      c.globalAlpha = alpha; fwDrawPx(c, oc, L.sx, L.sy, L.sw, L.sh);
   } else {
      if (use.f > 0.004) use = { i0: f, i1: f, f: 0 };
      c.globalAlpha = alpha; c.drawImage(FW_SHIP.imgs[f], L.sx, L.sy, L.sw, L.sh);
   }
   c.globalAlpha = 1;
   return use;
}
// el estado de un sistema (lo llaman los pasos de fw_viewer.js)
function fwShipSet(id, st) {
   var s = FW_SHIP.sys[id]; if (!FW_SHIP.on || !s) return;
   var t = fwShipNow();
   if (st === "warm" && s.st !== "warm") s.t = t;
   if (st !== "warm" && st !== "off" && s.tOk === undefined) { s.tOk = t; if (s.st === "off") s.t = t; }
   s.st = st;
}
function fwShipDoing(txt) { FW_SHIP.doing = txt || ""; }
// la cola (igual que fvBootShipSched de PixInsight): en el orden en que empezaron, cada uno al menos MIN_S
function fwShipSched() {
   var C = FW_BOOT_SHIP, S = FW_SHIP.sys, cur = 0, out = {}, i, ord = FW_BOOT_ORDER.slice();
   ord.sort(function(x, y) {
      var ox = S[x].st === "off" ? 1 : 0, oy = S[y].st === "off" ? 1 : 0;
      if (ox !== oy) return ox - oy;
      var tx = (typeof S[x].t === "number") ? S[x].t : 0, ty = (typeof S[y].t === "number") ? S[y].t : 0;
      return (tx !== ty) ? tx - ty : FW_BOOT_ORDER.indexOf(x) - FW_BOOT_ORDER.indexOf(y);
   });
   for (i = 0; i < ord.length; ++i) {
      var id = ord[i], s = S[id], st = s.st;
      if (st === "off" && FW_SHIP.done) st = "skip";
      if (st === "off" || cur === Infinity) { out[id] = { w: Infinity, k: Infinity, st: st }; if (st !== "off") cur = Infinity; continue; }
      var t0 = (typeof s.t === "number") ? s.t : 0, w = Math.max(t0, cur), k = Infinity;
      if (st !== "warm") {
         var tOk = (s.tOk !== undefined) ? s.tOk : (FW_SHIP.done ? FW_SHIP.tDone : t0);
         var lag = w - t0, minD = C.MIN_S * Math.max(0.25, Math.min(1, 1 - lag / C.LAG_MAX));
         k = Math.max(tOk, w + minD);
      }
      out[id] = { w: w, k: k, st: st }; cur = k;
   }
   var td = FW_SHIP.done ? FW_SHIP.tDone : Infinity;
   out.ready = (td === Infinity || cur === Infinity) ? Infinity : Math.max(td, cur);
   out.extra = (td === Infinity) ? 0 : Math.min(C.MAX_EXTRA_S, Math.max(0, out.ready - td));
   return out;
}
// todo listo: el brillo final y, despues, cb() (quita la pantalla de arranque). Sin nave cargada, cb() enseguida
function fwShipFinish(cb) {
   if (!FW_SHIP.on) { cb(); return; }
   FW_SHIP.done = true; FW_SHIP.tDone = fwShipNow();
   for (var id in FW_SHIP.sys) if (FW_SHIP.sys[id].st === "warm") fwShipSet(id, "ok");
   if (!FW_SHIP.data) { fwShipEnd(cb); return; }
   // (7-nov) el final lo marca la pintura (fwShipEndCheck: la partida llega al destello); el tope END_CAP_S por si algo no se descodifica
   FW_SHIP.endCb = cb;
   if (FW_SHIP.lastProg === undefined) FW_SHIP.lastProg = FW_SHIP.tDone;
}
function fwShipEndNow() { var cb = FW_SHIP.endCb; if (!cb) return; FW_SHIP.endCb = null; clearTimeout(FW_SHIP.endCap); FW_SHIP.finishAt = fwShipNow(); fwShipEnd(cb); }
function fwShipEndCheck(SC, t) {
   if (!FW_SHIP.endCb) return;
   // seguro: con el interruptor tirado (o sin interruptor) y la presentacion sin avanzar END_CAP_S (una imagen que no se descodifica)
   if (FW_SHIP.tSwitch !== undefined && t - Math.max(FW_SHIP.lastProg || 0, FW_SHIP.tDone || 0) > FW_BOOT_SHIP.END_CAP_S + (FW_BOOT_SHIP.QUEUE ? FW_BOOT_SHIP.XF + FW_BOOT_SHIP.Q_HOLD : 0) && !(FW_SHIP.shot && FW_SHIP.shot.okT !== undefined)) { fwShipEndNow(); return; }
   var DP = FW_BOOT_DEP, d0 = fwShipDepStart(SC);
   if (d0 !== Infinity && t >= d0 + (FW_BOOT_SHIP.DEPART ? DP.TURN + DP.RECEDE + DP.FLASH : 0)) fwShipEndNow();
}
function fwShipEnd(cb) {
   if (FW_SHIP.cv) { FW_SHIP.cv.style.pointerEvents = "none"; FW_SHIP.cv.style.cursor = "default"; }          // el visor recibe ya los clics
   try { cb(); } finally {
      // la transicion de #boot dura 0,5 s: se sigue pintando hasta que acaba y luego se suelta todo
      setTimeout(function() { FW_SHIP.gone = true; cancelAnimationFrame(FW_SHIP.raf); FW_SHIP.imgs = []; FW_SHIP.depImgs = null; FW_SHIP.halo = null; if (FW_SHIP.cv) { FW_SHIP.cv.width = 1; FW_SHIP.cv.height = 1; } }, 650);
   }
}
function fwShipLoop() {
   if (FW_SHIP.gone) return;
   try { fwShipDraw(); } catch (e) { console.warn("boot ship: " + e); }
   FW_SHIP.raf = requestAnimationFrame(fwShipLoop);
}
function fwShipA(hex, a) { var n = parseInt(hex.slice(1), 16); return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + Math.max(0, Math.min(1, a)).toFixed(3) + ")"; }
function fwShipElide(ctx, s, w) { if (ctx.measureText(s).width <= w) return s; var lo = 0, hi = s.length; while (lo < hi) { var m = (lo + hi + 1) >> 1; if (ctx.measureText(s.slice(0, m) + "…").width <= w) lo = m; else hi = m - 1; } return s.slice(0, lo) + "…"; }

// LA GEOMETRIA, en las unidades de PixInsight (1280 de ancho de referencia): la misma que fvBootShipLayout
function fwShipLayout(W, H, cw, ch) {
   var pw = Math.min(W - 48, 1180), ph = Math.min(H - 36, 640), x0 = Math.round((W - pw) / 2), y0 = Math.round((H - ph) / 2), x1 = x0 + pw, y1 = y0 + ph;
   // (columnas algo mas anchas que en PixInsight: sin Bodoni Moda instalada el navegador cae a una letra mas ancha y el rotulo largo del sistema 3 se cortaba)
   var sy0 = y0 + 98, sy1 = y1 - 50, colW = Math.max(200, Math.min(235, pw * 0.19));
   var s = Math.min(1.0, (sy1 - sy0) / ch, (pw - 2 * colW - 40) / cw), sw = cw * s, sh = ch * s, sx = x0 + (pw - sw) / 2, syy = sy0 + (sy1 - sy0 - sh) / 2;
   var L = { x0: x0, y0: y0, x1: x1, y1: y1, pw: pw, ph: ph, s: s, sx: sx, sy: syy, sw: sw, sh: sh, slots: {} };
   var ya = syy + 26, yb = syy + sh - 26, nL = 0, i, id;
   for (i = 0; i < FW_BOOT_ORDER.length; ++i) if (!FW_BOOT_SIDE[FW_BOOT_ORDER[i]]) ++nL;
   var kL = 0, kR = 0, stepL = (yb - ya) / Math.max(1, nL - 1);
   for (i = 0; i < FW_BOOT_ORDER.length; ++i) {
      id = FW_BOOT_ORDER[i];
      if (FW_BOOT_SIDE[id]) { L.slots[id] = { side: 1, x: sx + sw + 12, y: ya + stepL * (kR + 0.5), wMax: x1 - 30 - (sx + sw + 24) }; ++kR; }
      else { L.slots[id] = { side: 0, x: sx - 12, y: ya + stepL * kL, wMax: (sx - 24) - (x0 + 30) }; ++kL; }
   }
   return L;
}
function fwShipPanel(c, x0, y0, x1, y1) {
   var C = FW_BOOT_COL;
   c.fillStyle = "#0D0A07"; c.fillRect(x0, y0, x1 - x0, y1 - y0);          // opaca (como PixInsight)
   if (!(FW_SHIP.data && FW_SHIP.data.opaque)) {
      c.strokeStyle = "rgba(201,154,58,.086)"; c.lineWidth = 1; c.beginPath();
      c.moveTo(x0 + (x1 - x0) * 0.08, y0); c.lineTo(x0 + (x1 - x0) * 0.62, y1); c.moveTo(x1, y0 + (y1 - y0) * 0.30); c.lineTo(x0 + (x1 - x0) * 0.55, y1); c.stroke();
   }
   c.strokeStyle = C.gold; c.lineWidth = 1; c.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0 - 1, y1 - y0 - 1);
   c.strokeStyle = "rgba(201,154,58,.56)"; c.lineWidth = 0.6; c.strokeRect(x0 + 5.5, y0 + 5.5, x1 - x0 - 11, y1 - y0 - 11);
   var K = [[x0 + 5.5, y0 + 5.5, 1, 1], [x1 - 5.5, y0 + 5.5, -1, 1], [x1 - 5.5, y1 - 5.5, -1, -1], [x0 + 5.5, y1 - 5.5, 1, -1]];
   for (var i = 0; i < 4; ++i) {
      var x = K[i][0], y = K[i][1], sx = K[i][2], sy = K[i][3];
      c.strokeStyle = "rgba(201,154,58,.69)"; c.beginPath();
      for (var k = 0; k <= 10; ++k) { var b = (Math.PI / 2) * k / 10, px = x + sx * 12 * Math.sin(b), py = y + sy * 12 * Math.cos(b); if (k) c.lineTo(px, py); else c.moveTo(px, py); }
      c.stroke(); c.fillStyle = "rgba(201,154,58,.75)"; c.beginPath(); c.arc(x + sx * 4.2, y + sy * 4.2, 1.1, 0, 7); c.fill();
   }
}
function fwShipRule(c, xa, xb, y) {
   var xm = (xa + xb) / 2, d = 3.2; c.strokeStyle = FW_BOOT_COL.gold; c.lineWidth = 0.8; c.beginPath();
   c.moveTo(xa, y); c.lineTo(xm - 3 * d, y); c.moveTo(xm + 3 * d, y); c.lineTo(xb, y);
   c.moveTo(xm - d * 1.6, y); c.lineTo(xm, y - d); c.lineTo(xm + d * 1.6, y); c.lineTo(xm, y + d); c.closePath(); c.stroke();
   c.fillStyle = FW_BOOT_COL.gold; c.beginPath(); c.arc(xm - 2.3 * d, y, 0.9, 0, 7); c.arc(xm + 2.3 * d, y, 0.9, 0, 7); c.fill();
}
function fwShipArrow(c, sx, sy, tx, ty, side, a, hidden) {
   var C = FW_BOOT_COL, ex = sx + (side ? -16 : 16), dx = tx - ex, dy = ty - sy, d = Math.sqrt(dx * dx + dy * dy);
   if (d < 1) return;
   var ux = dx / d, uy = dy / d, px = tx - ux * 7, py = ty - uy * 7;
   c.strokeStyle = fwShipA(C.goldL, hidden ? a * 0.75 : a); c.lineWidth = 1; c.setLineDash(hidden ? [4, 3] : []);
   c.beginPath(); c.moveTo(sx, sy); c.lineTo(ex, sy); c.lineTo(px, py); c.stroke(); c.setLineDash([]);
   var ca = Math.cos(0.42), sa = Math.sin(0.42), hl = 7; c.strokeStyle = fwShipA(C.goldL, a); c.lineWidth = 1.1; c.beginPath();
   c.moveTo(px - hl * (ux * ca - uy * sa), py - hl * (uy * ca + ux * sa)); c.lineTo(px, py); c.lineTo(px - hl * (ux * ca + uy * sa), py - hl * (uy * ca - ux * sa)); c.stroke();
   c.strokeStyle = fwShipA(C.ivory, a * (hidden ? 0.6 : 1)); c.lineWidth = 0.9; c.beginPath(); c.arc(tx, ty, 3.4, 0, 7); c.stroke();
   c.fillStyle = fwShipA(C.goldL, a); c.beginPath(); c.arc(sx, sy, 1.6, 0, 7); c.fill();
}
// el interruptor de cuchilla a linea (gemelo de fvKnifeSwitchFine de PixInsight). on: 0 (arriba) … 1 (cerrado)
function fwKnife(c, cx, cy, on) {
   var C = FW_BOOT_COL;
   c.lineWidth = 1; c.strokeStyle = C.gold; c.strokeRect(cx - 44, cy - 20, 88, 50);
   c.lineWidth = 0.6; c.strokeStyle = "rgba(201,154,58,.56)"; c.strokeRect(cx - 40, cy - 16, 80, 42);
   c.lineWidth = 0.9; c.strokeStyle = C.gold; c.strokeRect(cx + 14, cy + 2, 12, 16);
   c.beginPath(); c.moveTo(cx + 17, cy + 2); c.lineTo(cx + 17, cy + 18); c.moveTo(cx + 23, cy + 2); c.lineTo(cx + 23, cy + 18); c.stroke();
   var px = cx - 22, py = cy + 10, ang = (-70 + 70 * on) * Math.PI / 180, Ln = 44, ca = Math.cos(ang), sa = Math.sin(ang), nx = -sa * 2, ny = ca * 2, ex = px + ca * Ln, ey = py + sa * Ln;
   c.lineWidth = 1; c.strokeStyle = C.goldL; c.beginPath(); c.moveTo(px + nx, py + ny); c.lineTo(ex + nx, ey + ny); c.moveTo(px - nx, py - ny); c.lineTo(ex - nx, ey - ny); c.stroke();
   c.strokeStyle = C.gold; c.beginPath(); c.arc(px, py, 5.5, 0, 7); c.stroke(); c.fillStyle = C.goldL; c.beginPath(); c.arc(px, py, 1.6, 0, 7); c.fill();
   var hx = px + ca * (Ln + 9), hy = py + sa * (Ln + 9);
   c.strokeStyle = C.ivory2; c.beginPath(); c.moveTo(ex, ey); c.lineTo(hx, hy); c.stroke(); c.beginPath(); c.arc(hx, hy, 4.2, 0, 7); c.stroke();
   c.font = "400 8px " + FW_BOOT_FONT.display; if ("letterSpacing" in c) c.letterSpacing = "3px"; c.fillStyle = C.goldT;
   c.fillText("POTENTIA", cx - c.measureText("POTENTIA").width / 2, cy + 44); if ("letterSpacing" in c) c.letterSpacing = "0px";
}
function fwShipTick(c, x, y, col) { c.strokeStyle = col; c.lineWidth = 1.4; c.beginPath(); c.moveTo(x - 3.2, y + 0.2); c.lineTo(x - 1, y + 2.6); c.lineTo(x + 3.6, y - 3); c.stroke(); }

// (6-nov, Nino) LA PARTIDA, gemela de la de PixInsight (FV_BOOT_DEP de src/ui/fv_boot.js): gira a popa con los casquetes encendidos, se
// aleja hacia el centro de la foto encogiendo (la foto se acerca un poco), estela calida, destello en el punto de fuga, la foto vuelve
// a su encuadre y la pantalla de arranque se funde (la transicion de 0,5 s de #boot). FW_BOOT_SHIP.DEPART = false: sin partida.
// (7-nov, Nino) como en PixInsight (FV_BOOT_DEP): mas despacio, encoge parejo y la foto CRECE desde Z0 hasta su encuadre (ya no va y vuelve)
var FW_BOOT_DEP = { TURN: 0.6, RECEDE: 1.8, FLASH: 0.32, Z0: 0.6, EASE: 1.25, STERN: 270, SHRINK: 14, TRAIL: 6, TRAIL_S: 0.03 };   // STERN en grados (popa franca)
FW_BOOT_SHIP.DEPART = true;
// la foto en la partida (gemela de fvBootDepPhoto): { z, g (0 → 1) }; antes de la partida, Z0
function fwShipDepPhoto(ud) {
   var D = FW_BOOT_DEP, g = (ud === undefined || ud < 0) ? 0 : fwShipSmooth((ud - D.TURN * 0.3) / (D.TURN * 0.7 + D.RECEDE));
   return { z: D.Z0 + (1 - D.Z0) * g, g: g };
}
function fwShipSmooth(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
function fwShipDepStart(SC) {
   if (fwShotsOn() && FW_SHIP.data.shots.list.ok) return (FW_SHIP.shot && FW_SHIP.shot.okT !== undefined) ? FW_SHIP.shot.okT + (FW_BOOT_SHIP.HOLD_TASK ? FW_BOOT_SHIP.XF_OK + Math.max(FW_BOOT_SHIP.FINAL_S, FW_BOOT_SHIP.OK_HOLD) : Math.max(FW_BOOT_SHIP.XF_OK + FW_BOOT_SHIP.FINAL_S, FW_BOOT_SHIP.OK_HOLD)) : Infinity;
   return (SC.ready === Infinity) ? Infinity : SC.ready + FW_BOOT_SHIP.FINAL_S;
}
// el fotograma de popa: { img (o null si aun no esta), caps [[x, y]] en px del recorte del giro, ox, oy, w, h }
function fwShipDepFrame(D, u) {
   var dep = D.dep;
   if (dep && dep.frames > 0 && FW_SHIP.depImgs) {
      var i = Math.max(0, Math.min(dep.frames - 1, Math.round(u * (dep.frames - 1)))), ox = dep.crop[0] - D.crop[0], oy = dep.crop[1] - D.crop[1], C = (dep.caps && dep.caps[i]) || [], cs = [];
      for (var k = 0; k < C.length; ++k) cs.push([C[k][0] + ox, C[k][1] + oy]);
      return { img: FW_SHIP.depReady[i] ? FW_SHIP.depImgs[i] : null, caps: cs, ox: ox, oy: oy, w: dep.crop[2], h: dep.crop[3] };
   }
   var st = fwShipPosAt(FW_BOOT_DEP.STERN).i0, R = D.ready[st] || [], c2 = [];
   for (var j = 0; j < R.length; ++j) if (String(R[j][2]).indexOf("nac") === 0) c2.push([R[j][0], R[j][1]]);
   return { img: FW_SHIP.ready[st] ? FW_SHIP.imgs[st] : null, caps: c2, ox: 0, oy: 0, w: D.crop[2], h: D.crop[3] };
}

function fwShipChromeBack(c, L, a) {
   var C = FW_BOOT_COL;
   c.globalAlpha = a;
   fwShipPanel(c, L.x0, L.y0, L.x1, L.y1);
   c.textBaseline = "alphabetic"; c.textAlign = "left";
   var title = (typeof fvTx === "function") ? fvTx("boot.title", null, FW_LANG) : "FIELD VOYAGER", sub = (typeof fvTx === "function") ? fvTx("boot.sub", null, FW_LANG) : fwTr("FieldVoyager · ship's systems", "FieldVoyager · sistemas de la nave");
   c.font = "400 33px " + FW_BOOT_FONT.display; if ("letterSpacing" in c) c.letterSpacing = "9px";
   c.fillStyle = C.ivory; c.fillText(title, L.x0 + (L.pw - c.measureText(title).width) / 2, L.y0 + 56);
   c.font = "italic 12px " + FW_BOOT_FONT.display; if ("letterSpacing" in c) c.letterSpacing = "2px";
   c.fillStyle = C.goldT; c.fillText(sub, L.x0 + (L.pw - c.measureText(sub).width) / 2, L.y0 + 76);
   if ("letterSpacing" in c) c.letterSpacing = "0px";
   fwShipRule(c, L.x0 + L.pw * 0.28, L.x1 - L.pw * 0.28, L.y0 + 88);
   c.globalAlpha = 1;
}
function fwShipChromeFront(c, L, SC, t, a) {
   var C = FW_BOOT_COL, i, id;
   c.globalAlpha = a;
   for (i = 0; i < FW_BOOT_ORDER.length; ++i) {
      id = FW_BOOT_ORDER[i]; var sc2 = SC[id], sl = L.slots[id], st = sc2 ? sc2.st : "off", shown = !!sc2 && t >= sc2.w, isWarm = shown && t < sc2.k, isDone = shown && !isWarm;
      var lx = sl.x, ly = sl.y, tx0 = sl.side ? lx + 12 : lx - 12;
      c.font = "400 12px " + FW_BOOT_FONT.display; if ("letterSpacing" in c) c.letterSpacing = "1px";
      var nm = fwShipElide(c, fwShipName(id, false), sl.wMax - 8);
      c.fillStyle = isWarm ? C.ivory : (isDone ? C.ivory2 : fwShipA(C.ivory2, 0.38)); c.fillText(nm, sl.side ? tx0 : tx0 - c.measureText(nm).width, ly + 4);
      if ("letterSpacing" in c) c.letterSpacing = "0px";
      c.font = "italic 9.5px " + FW_BOOT_FONT.text;
      var wh = fwShipElide(c, fwShipName(id, true), sl.wMax - 8);
      c.fillStyle = isWarm ? C.goldL : (isDone ? fwShipA(C.goldT, 0.75) : fwShipA(C.goldT, 0.35)); c.fillText(wh, sl.side ? tx0 : tx0 - c.measureText(wh).width, ly + 18);
      c.strokeStyle = shown ? C.gold : fwShipA(C.gold, 0.45); c.lineWidth = 0.9; c.beginPath(); c.arc(lx, ly, 5.2, 0, 7); c.stroke();
      if (isWarm) { c.fillStyle = fwShipA(C.warm, 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(t * 7))); c.beginPath(); c.arc(lx, ly, 2.8, 0, 7); c.fill(); }
      else if (isDone) {
         if (st === "ok") fwShipTick(c, lx, ly, C.ok);
         else if (st === "local") fwShipTick(c, lx, ly, C.local);
         else { c.strokeStyle = st === "fail" ? C.fail : C.dim; c.lineWidth = 1.2; c.beginPath(); c.moveTo(lx - 2.8, ly); c.lineTo(lx + 2.8, ly); c.stroke(); }
      }
   }
   // abajo: lo que se hace y el interruptor de cuchilla (POTENTIA), como en PixInsight
   var kx = L.x1 - 92, ky = L.y1 - 64, xr = kx - 70;
   fwShipRule(c, L.x0 + 40, xr, L.y1 - 44);
   var V0 = FW_SHIP.view, ready = (typeof fvTx === "function") ? fvTx("boot.ready", null, FW_LANG) : fwTr("All systems ready.", "Todos los sistemas listos."), doing;
   if (FW_SHIP.tSwitch === undefined) doing = (typeof fvTx === "function" && fvTx("boot.pull", null, FW_LANG).indexOf("boot.") !== 0) ? fvTx("boot.pull", null, FW_LANG) : fwTr("Pull the lever to power the ship", "Tira de la palanca para encender la nave");
   else if (FW_SHIP.done && FW_BOOT_SHIP.QUEUE && V0 && V0.to && V0.to !== "tt" && V0.to !== "ok") doing = fwShipName(V0.to, false) + " · " + fwShipName(V0.to, true);     // acabado el arranque de verdad: el sistema que se ENSEÑA
   else doing = FW_SHIP.done ? ready : FW_SHIP.doing;
   c.font = "italic 12px " + FW_BOOT_FONT.text; c.fillStyle = C.ivory2;
   if (doing) { var wD = xr - (L.x0 + 40); c.fillText(fwShipElide(c, doing, wD), L.x0 + 40 + (wD - Math.min(wD, c.measureText(doing).width)) / 2, L.y1 - 20); }
   if (FW_BOOT_SHIP.SWITCH) fwKnife(c, kx, ky, FW_SHIP.tSwitch === undefined ? 0 : 1);
   FW_SHIP.leverRect = [kx - 58, ky - 46, kx + 62, ky + 50];
   var trL = c.getTransform(), kL = trL.a / (window.devicePixelRatio || 1);
   FW_SHIP.leverCss = [FW_SHIP.leverRect[0] * kL, FW_SHIP.leverRect[1] * kL, FW_SHIP.leverRect[2] * kL, FW_SHIP.leverRect[3] * kL];
   c.globalAlpha = 1;
}

function fwShipDraw() {
   var cv = FW_SHIP.cv, boot = cv && cv.parentNode; if (!boot) return;
   var dpr = window.devicePixelRatio || 1, cssW = boot.clientWidth, cssH = boot.clientHeight;
   if (cssW < 2 || cssH < 2) return;
   var pw = Math.round(cssW * dpr), ph = Math.round(cssH * dpr);
   if (cv.width !== pw || cv.height !== ph) { cv.width = pw; cv.height = ph; }
   var c = cv.getContext("2d"), k = Math.max(0.62, Math.min(4, cssW / 1280)), W = cssW / k, H = cssH / k, t = fwShipNow(), C = FW_BOOT_COL, i, id, DP = FW_BOOT_DEP;
   c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, pw, ph);
   c.setTransform(k * dpr, 0, 0, k * dpr, 0, 0);
   if (FW_SHIP.tSwitch === undefined && t >= FW_BOOT_SHIP.AUTO_S && typeof FW_SHIP.tFix !== "number") fwShipThrow("auto");
   var D = FW_SHIP.data, SC = fwShipSched();
   if (D && fwShotsOn() && typeof FW_SHIP.tFixShot !== "number") fwShotUpdate(SC, t);          // tFixShot: pruebas (no decidir cambios)
   if (D && fwShotsOn() && FW_BOOT_SHIP.QUEUE) SC = fwPresSched();
   var d0 = (FW_SHIP.done && FW_BOOT_SHIP.DEPART && D) ? fwShipDepStart(SC) : Infinity, ud = t - d0, dep = ud >= 0;
   fwShipEndCheck(SC, t);
   // la foto de fondo (#bootPhoto), en penumbra (se aclara segun arrancan los sistemas); con la nave, mas pequeña (Z0) y en la partida
   // crece y se aclara hasta su encuadre (el de la cabina). Fuera de ella, el fondo de #boot.ship
   var nOk = 0; for (id in FW_SHIP.sys) if (FW_SHIP.sys[id].st !== "off" && FW_SHIP.sys[id].st !== "warm") ++nOk;
   var dim = 0.78 - 0.45 * nOk / FW_BOOT_ORDER.length, z = 1;
   if (D && FW_BOOT_SHIP.DEPART) { var PH = fwShipDepPhoto(dep ? ud : undefined); z = PH.z; dim *= 1 - PH.g; }
   var ph0 = document.getElementById("bootPhoto"); if (ph0) { var tf = Math.abs(z - 1) > 0.0005 ? "scale(" + z.toFixed(4) + ")" : ""; if (ph0.style.transform !== tf) ph0.style.transform = tf; }
   if (dim > 0.004) { c.fillStyle = "rgba(7,6,10," + dim.toFixed(3) + ")"; c.fillRect(0, 0, W, H); }
   var cw = D ? D.crop[2] : 760, ch = D ? D.crop[3] : 486, L = fwShipLayout(W, H, cw, ch), s = L.s;
   function at(r) { return r ? [L.sx + r[0] * s, L.sy + r[1] * s, r[2]] : null; }
   function halo(x, y, al, d) { if (!FW_SHIP.haloOk || al <= 0.01 || d < 1) return; var g0 = c.globalAlpha; c.globalAlpha = g0 * Math.min(1, al); c.drawImage(FW_SHIP.halo, x - d / 2, y - d / 2, d, d); c.globalAlpha = g0; }
   c.imageSmoothingEnabled = true; c.imageSmoothingQuality = "high";
   var shots = D && fwShotsOn(), BX = shots ? fwShotBox(L) : null;
   function anc(r) { var rs = D.shots.res; return r ? [BX.x + r[0] * BX.w / rs[0], BX.y + r[1] * BX.h / rs[1]] : null; }
   if (!dep && shots) {
      fwShipChromeBack(c, L, 1);
      var V = fwShotView(t), LS = D.shots.list, shipA2 = Math.min(1, (t - FW_SHIP.loadedAt) / FW_BOOT_SHIP.SHIP_IN_S), IM = FW_SHIP.shotImg;
      FW_SHIP.view = V;
      // el giro (si lo hay) parado de fondo mientras llega el primer plano
      if (V.to === "tt" || (V.from === "tt" && V.f < 1)) { var PT = fwShipPosAt(fwShipAngle(t)), PTu = fwShipDrawAt(c, L, PT, shipA2 * (V.to === "tt" ? 1 : 1 - V.f)); if (PTu && PTu.i0 !== FW_SHIP.lastFrame) { FW_SHIP.lastFrame = PTu.i0; ++FW_SHIP.drawn; } }
      var trS = c.getTransform(), spw = Math.max(1, Math.round(BX.w * trS.a)), sph = Math.max(1, Math.round(BX.h * trS.d));
      var ia = (V.from && V.from !== "tt" && V.f < 1) ? fwShotPx(V.from, spw, sph) : null, ib = (V.to !== "tt") ? fwShotPx(V.to, spw, sph) : null;
      // los que van a salir, escalados de antemano en un rato libre (uno por pintada, cuando no hay fundido)
      if (V.f >= 1) for (var kq in IM) if (FW_SHIP.shotReady[kq] && !(FW_SHIP.shotPx._k === spw + "x" + sph && FW_SHIP.shotPx[kq])) { fwShotPx(kq, spw, sph); break; }
      if (ia || ib) fwShipBlend(c, ia, ib, ia ? V.f : V.f, BX.x, BX.y, BX.w, BX.h, shipA2);
      var isSys = function(k3) { return !!k3 && k3 !== "tt" && k3 !== "ok"; };
      fwShotBand(c, L, BX, shipA2 * ((isSys(V.to) ? V.f : 0) + (isSys(V.from) && V.f < 1 ? 1 - V.f : 0)));
      var arr2 = [], VV = [[V.from, V.f < 1 ? 1 - V.f : 0], [V.to, V.f]];
      for (i = 0; i < VV.length; ++i) {
         var kk = VV[i][0], wv = VV[i][1] * shipA2;
         if (!kk || kk === "tt" || wv <= 0.01) continue;
         if (kk === "ok") {
            var RR = LS.ok.ready || [];
            for (var r2 = 0; r2 < RR.length; ++r2) { var q2 = anc(RR[r2]); if (String(RR[r2][2]).indexOf("nac") === 0) { halo(q2[0], q2[1], wv, FW_BOOT_SHIP.HALO_END * 1.1); halo(q2[0], q2[1], wv, FW_BOOT_SHIP.HALO_END * 0.5); } else halo(q2[0], q2[1], wv * 0.8, FW_BOOT_SHIP.HALO); }
            continue;
         }
         var sc3 = SC[kk], p3 = anc(LS[kk] && LS[kk].a);
         if (!sc3 || !p3) continue;
         var warm3 = t < sc3.k, hk = warm3 ? 0.55 + 0.4 * (0.5 + 0.5 * Math.sin((t - sc3.w) * 6.5)) : 0.95 * Math.max(0, Math.min(1, 1 - (t - sc3.k) / FW_BOOT_SHIP.OUT_S));
         halo(p3[0], p3[1], wv * hk, FW_BOOT_SHIP.HALO);
         arr2.push([kk, p3, wv]);
      }
      fwShipChromeFront(c, L, SC, t, 1);
      for (i = 0; i < arr2.length; ++i) { var A2 = arr2[i], so2 = L.slots[A2[0]]; fwShipArrow(c, so2.x + (so2.side ? -6 : 6), so2.y, A2[1][0], A2[1][1], so2.side, A2[2], false); }
      return;
   }
   if (!dep) {
      fwShipChromeBack(c, L, 1);
      // la nave: el fotograma que toca (si aun no esta descodificado, el ultimo que si: nunca se para la pagina)
      var PP = fwShipPosAt(fwShipAngle(t)), shipA = D ? Math.min(1, (t - FW_SHIP.loadedAt) / FW_BOOT_SHIP.SHIP_IN_S) : 0, PU = null;
      if (D) {
         PU = fwShipDrawAt(c, L, PP, shipA);
         if (!PU || PU.i0 !== PP.i0) ++FW_SHIP.stalls;
         if (PU && PU.i0 !== FW_SHIP.lastFrame) { FW_SHIP.lastFrame = PU.i0; ++FW_SHIP.drawn; }
      }
      var AP = PU || PP, arrows = [];
      if (D && shipA > 0) {
         c.globalAlpha = shipA;
         for (i = 0; i < FW_BOOT_ORDER.length; ++i) {
            id = FW_BOOT_ORDER[i]; var sc = SC[id], p = at(D.anchors[id] ? fwShipLerp(D.anchors[id][AP.i0], D.anchors[id][AP.i1], AP.f) : null);
            if (!sc || !p || t < sc.w) continue;
            var warm = t < sc.k, fin = warm ? 1 : 1 - (t - sc.k) / FW_BOOT_SHIP.OUT_S;
            if (fin <= 0) continue;
            var fadeIn = Math.max(0, Math.min(1, (t - sc.w) / 0.15));
            if (p[2] > 0.01) halo(p[0], p[1], p[2] * fadeIn * (warm ? 0.55 + 0.4 * (0.5 + 0.5 * Math.sin((t - sc.w) * 6.5)) : 0.95 * fin), FW_BOOT_SHIP.HALO);
            arrows.push([id, [p[0], p[1], p[2] >= 0.5], fadeIn * fin * shipA]);
         }
         var rdy = SC.ready, rk = (rdy !== Infinity && t >= rdy) ? Math.max(0, Math.min(1, (t - rdy) / 0.35)) : 0;
         if (rk > 0) { var R = fwShipReadyAt(D, AP); for (i = 0; i < R.length; ++i) { var q = at(R[i]); halo(q[0], q[1], q[2] * rk * (0.85 + 0.15 * Math.sin((t - rdy) * 5)), FW_BOOT_SHIP.HALO_END); } }
         c.globalAlpha = 1;
      }
      fwShipChromeFront(c, L, SC, t, 1);
      for (i = 0; i < arrows.length; ++i) { var A = arrows[i], so = L.slots[A[0]]; fwShipArrow(c, so.x + (so.side ? -6 : 6), so.y, A[1][0], A[1][1], so.side, A[2], !A[1][2]); }
      return;
   }
   // ---- LA PARTIDA ----
   // (7-nov) con los planos fijos: el plano final se funde con d_000 en XO s con la placa entera; luego se va la placa y gira a popa
   var shotsDep = shots && !!D.dep && !!FW_SHIP.shot && FW_SHIP.shot.okT !== undefined && !!FW_SHIP.depImgs, XO = shotsDep ? 0.15 : 0;
   var pA = 1 - fwShipSmooth((ud - XO) / (DP.TURN * 0.9 - XO));
   if (pA > 0.01) { fwShipChromeBack(c, L, pA); fwShipChromeFront(c, L, SC, t, pA); }
   var cx0 = L.sx + L.sw / 2, cy0 = L.sy + L.sh / 2, tx = W / 2, ty = H / 2, HD2 = FW_BOOT_SHIP.HALO_END;
   FW_SHIP.depPhase = ud < DP.TURN ? "turn" : (ud < DP.TURN + DP.RECEDE ? "recede" : (ud < DP.TURN + DP.RECEDE + DP.FLASH ? "flash" : "fade"));
   if (ud < DP.TURN) {
      var u1 = ud / DP.TURN, a0 = fwShipAngle(d0) % 360, goal = !D.dep ? DP.STERN : (typeof D.dep.from_deg === "number" ? D.dep.from_deg : (typeof D.dep.from_frame === "number" ? D.dep.from_frame * 5 : DP.STERN));
      var uSpin = D.dep ? Math.min(1, u1 / 0.45) : u1, dl = ((goal - a0) % 360 + 360) % 360; if (dl > 180) dl -= 360;
      var cap = null;
      if (shotsDep) {
         var DFs = fwShipDepFrame(D, Math.max(0, Math.min(1, (ud - XO) / (DP.TURN - XO)))), ko = 1 - fwShipSmooth(ud / XO);
         var trO = c.getTransform(), iok = (ko > 0.004 && FW_SHIP.shotReady.ok) ? fwShotPx("ok", Math.max(1, Math.round(BX.w * trO.a)), Math.max(1, Math.round(BX.h * trO.d))) : null;
         if (DFs.img && iok) {
            // d_000 en la caja del plano: el fundido exacto se hace con las dos en la caja entera (d_000 recortado va en su sitio dentro)
            var oc3 = FW_SHIP.oc3 || (FW_SHIP.oc3 = document.createElement("canvas")), rr = D.src_res || [960, 540];
            if (oc3.width !== rr[0] || oc3.height !== rr[1]) { oc3.width = rr[0]; oc3.height = rr[1]; }
            var o3 = oc3.getContext("2d"); o3.clearRect(0, 0, rr[0], rr[1]); o3.drawImage(DFs.img, D.dep.crop[0], D.dep.crop[1], DFs.w, DFs.h);
            fwShipBlend(c, iok, oc3, 1 - ko, BX.x, BX.y, BX.w, BX.h, 1);
            var RO = D.shots.list.ok.ready || []; for (i = 0; i < RO.length; ++i) if (String(RO[i][2]).indexOf("nac") !== 0) { var qo = anc(RO[i]); halo(qo[0], qo[1], ko * 0.8, FW_BOOT_SHIP.HALO); }
         } else if (DFs.img) c.drawImage(DFs.img, L.sx + DFs.ox * s, L.sy + DFs.oy * s, DFs.w * s, DFs.h * s);
         else if (iok) { c.globalAlpha = ko; c.drawImage(iok, BX.x, BX.y, BX.w, BX.h); c.globalAlpha = 1; }
         cap = DFs.caps;
      } else if (!D.dep || u1 < 0.45) {
         fwShipDrawAt(c, L, fwShipPosAt(a0 + dl * fwShipSmooth(uSpin)), 1);
         if (!D.dep && uSpin > 0.97) cap = fwShipDepFrame(D, 1).caps;
      } else {
         var DF = fwShipDepFrame(D, (u1 - 0.45) / 0.55);
         if (DF.img) c.drawImage(DF.img, L.sx + DF.ox * s, L.sy + DF.oy * s, DF.w * s, DF.h * s);
         cap = DF.caps;
      }
      var ck = shotsDep ? 1 : fwShipSmooth((u1 - 0.5) / 0.5);
      if (cap && ck > 0) for (i = 0; i < cap.length; ++i) { var q1 = at(cap[i]); halo(q1[0], q1[1], ck, HD2 * 1.1); halo(q1[0], q1[1], ck, HD2 * 0.5); }
   } else if (ud < DP.TURN + DP.RECEDE) {
      var ur2 = (ud - DP.TURN) / DP.RECEDE, DFr = fwShipDepFrame(D, 1);
      var place = function(u) { var e = Math.pow(u, DP.EASE), kk = 1 / (1 + DP.SHRINK * e), e2 = fwShipSmooth(u); return { k: kk, x: cx0 + (tx - cx0) * e2, y: cy0 + (ty - cy0) * e2 }; };
      for (var tr = DP.TRAIL; tr >= 1; --tr) {
         var uu = ur2 - tr * DP.TRAIL_S / DP.RECEDE; if (uu < 0) continue;
         var P2 = place(uu);
         for (i = 0; i < DFr.caps.length; ++i) { var c0 = DFr.caps[i]; halo(P2.x + (c0[0] * s - L.sw / 2) * P2.k, P2.y + (c0[1] * s - L.sh / 2) * P2.k, 0.45 * (1 - tr / (DP.TRAIL + 1)), Math.max(8, HD2 * 0.7 * P2.k + 6)); }
      }
      var P1 = place(ur2), fadeShip = 1 - fwShipSmooth((ur2 - 0.82) / 0.18);
      if (DFr.img) { c.globalAlpha = fadeShip; c.drawImage(DFr.img, P1.x + (DFr.ox * s - L.sw / 2) * P1.k, P1.y + (DFr.oy * s - L.sh / 2) * P1.k, DFr.w * s * P1.k, DFr.h * s * P1.k); c.globalAlpha = 1; }
      for (i = 0; i < DFr.caps.length; ++i) { var c1 = DFr.caps[i]; var hx = P1.x + (c1[0] * s - L.sw / 2) * P1.k, hy = P1.y + (c1[1] * s - L.sh / 2) * P1.k; halo(hx, hy, 1, Math.max(10, HD2 * 1.1 * P1.k + 8)); halo(hx, hy, 1, Math.max(6, HD2 * 0.5 * P1.k + 4)); }
   } else if (ud < DP.TURN + DP.RECEDE + DP.FLASH) {
      var u3 = (ud - DP.TURN - DP.RECEDE) / DP.FLASH, fl = u3 < 0.3 ? u3 / 0.3 : 1 - (u3 - 0.3) / 0.7;
      halo(tx, ty, fl, HD2 * (0.6 + 1.6 * u3));
      var ln = 70 * (0.4 + u3) * fl;
      c.strokeStyle = fwShipA(C.ivory, 0.85 * fl); c.lineWidth = 1; c.beginPath(); c.moveTo(tx - ln, ty); c.lineTo(tx + ln, ty); c.moveTo(tx, ty - ln * 0.6); c.lineTo(tx, ty + ln * 0.6); c.stroke();
   }
}
// pruebas (tests/web/fv_boot_ship_cdp.js)
function fwShipState() {
   if (!FW_SHIP.on) return { on: false };                       // sin nave (FW_BOOT_SHIP.ON false): no hay sistemas que contar
   var SC = fwShipSched(), o = { on: FW_SHIP.on, loaded: !!FW_SHIP.data, decoded: FW_SHIP.nDecoded, t: fwShipNow(), done: FW_SHIP.done, tDone: FW_SHIP.tDone, finishAt: FW_SHIP.finishAt,
                                  depStart: fwShipDepStart(SC), depPhase: FW_SHIP.depPhase || "", frame: (FW_SHIP.data && FW_SHIP.data.frames) ? fwShipFrameAt(fwShipNow()) : -1,
                                  stills: fwShotsOn(), tSwitch: FW_SHIP.tSwitch, thrownBy: FW_SHIP.thrownBy || null, lever: FW_SHIP.leverCss || null, nPx: FW_SHIP.nPx, queue: FW_BOOT_SHIP.QUEUE, shots: (FW_SHIP.shot ? FW_SHIP.shot.ch.slice() : []), view: FW_SHIP.view || null, shotsDecoded: Object.keys(FW_SHIP.shotReady || {}).length, drawnFrames: FW_SHIP.drawn, stalls: FW_SHIP.stalls, gone: FW_SHIP.gone, ready: SC.ready, extra: SC.extra, sys: {} };
   for (var id in FW_SHIP.sys) o.sys[id] = { st: FW_SHIP.sys[id].st, t: FW_SHIP.sys[id].t, tOk: FW_SHIP.sys[id].tOk, w: SC[id].w, k: SC[id].k };
   return o;
}
