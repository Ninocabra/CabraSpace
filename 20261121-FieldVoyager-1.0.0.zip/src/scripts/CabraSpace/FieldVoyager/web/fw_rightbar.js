// ============================================================================
// FieldVoyager/web/fw_rightbar.js — LA COLUMNA DERECHA del visor del navegador (gemela de src/ui/fv_rightbar.js de PixInsight; 5-nov-2026)
// ----------------------------------------------------------------------------
// Cinco botones de laton a la derecha de la vista, simetricos a los de la izquierda (mismo boton, mismo grabado, mismo rotulo):
//   FOTO (P)        la vista de ahora en PNG a la resolucion de la imagen (lado mayor ≤ PHOTO_MAX), con nombres, constelaciones y escala si
//                   estan encendidos; sin cabina, marco, viñeta, grano ni ventana de la nave. Chrome/Edge: en una carpeta que se elige UNA vez
//                   (File System Access, recordada en IndexedDB; Mayus+P la cambia). Sin esa API (Firefox, Safari): descarga normal.
//   NOMBRES (N)     los objetos de la foto y las estrellas con nombre IAU donde se ven desde la nave (recordado)
//   CONSTEL. (C)    las figuras de Stellarium «modern» vistas DESDE LA NAVE (se deforman al viajar; se apagan cuando ya no se reconocen)
//   ESCALA (E)      la regla y el ancho de la vista a la distancia de lo que se mira, en años luz y en Sistemas Solares
//   COMPLETA (F)    pantalla completa (Fullscreen API) sin la cabina ni la botonera izquierda; Esc, F o F11 vuelven
// El calculo es el MISMO que el de PixInsight (engine/fv_skyov.js, puro); aqui solo se dibuja en el lienzo del HUD y en el de la foto.
// Ganchos en ficheros compartidos (una linea cada uno): fw_viewer.js fwOverlay -> fwRbOverlay(now); index.html carga este fichero,
// engine/fv_skyov.js y fw_const_data.js. La columna se construye sola (DOMContentLoaded) y se mete junto a #win (envoltorio #winrow).
// FW_RB.ON = false: ni columna ni envoltorio ni dibujo (el visor de antes, sin Orbitar ni Mirar al Sol).
// ES5.
// ============================================================================
"use strict";

var FW_RB = { ON: true, PHOTO: true, NAMES: true, CONST: true, SCALE: true, FULL: true,
              PHOTO_MAX: 8192,     // lado mayor maximo de la foto (y nunca mas que lo que admita la GPU)
              NAMES_MAX: 24,       // rotulos como mucho a la vez
              FSA: true,           // carpeta elegida con File System Access (Chrome/Edge); false = descarga normal
              PHOTO_HOOK: null };  // pruebas: function(res, blob) en vez de guardar (sin dialogos)
var FW_RB_ST = { built: false, btn: {}, names: false, cons: false, scale: false, fs: false, busy: false, last: null, stats: null, sync: "" };

var FW_RB_TX = {
   en: { "lab.photo": "Photo", "lab.names": "Names", "lab.const": "Constel.", "lab.scale": "Scale", "lab.full": "Full",
         "tip.photo": "Photo: saves what you are seeing now as a PNG at the resolution of your image (names, constellations and scale go in if they are on; the cockpit and the window frame do not). Chrome and Edge ask for a folder once and remember it (Shift+P or Shift+click to change it); other browsers download it. Key: P.",
         "tip.names": "Names: shows or hides the names of the objects of your photo and of the stars with an IAU-approved proper name, where they are seen from the ship. Key: N.",
         "tip.const": "Constellations: the figures of the constellations (Stellarium's modern sky culture) drawn as they would be seen FROM THE SHIP: each star at its Hipparcos distance, so they deform as you travel and fade away when they can no longer be recognised. From home they look as always. Key: C.",
         "tip.scale": "Scale: a ruler and the width of the view at the distance of what you are looking at (the selected object, or else the nebula), in light years and in Solar Systems (out to Neptune's orbit, 60 au across). Key: E.",
         "tip.full": "Full screen: the view fills the screen and the cockpit and the left buttons hide, so the photo is as large as it can be. Again, F11 or Esc to come back. Key: F or F11.",
         nodir: "PHOTO NOT SAVED: NO FOLDER CHOSEN", saved: "PHOTO SAVED · {w} × {h} px · {where}", fail: "PHOTO NOT SAVED: {why}", busy: "SAVING THE PHOTO ({w} × {h})…",
         fsHint: "F11 or Esc: leave full screen", scaleW: "VIEW WIDTH {w} {u} ≈ {n} SOLAR SYSTEMS", scaleAt: "at {d} {u} · {name}", selStar: "selected star", au: "au", ly: "ly", dl: "Downloads" },
   es: { "lab.photo": "Foto", "lab.names": "Nombres", "lab.const": "Constel.", "lab.scale": "Escala", "lab.full": "Completa",
         "tip.photo": "Foto: guarda lo que estás viendo como PNG a la resolución de tu imagen (con nombres, constelaciones y escala si están encendidos; sin la cabina ni el marco). Chrome y Edge piden una carpeta una vez y la recuerdan (Mayús+P o Mayús+clic para cambiarla); los demás navegadores la descargan. Tecla: P.",
         "tip.names": "Nombres: enseña u oculta los nombres de los objetos de tu foto y de las estrellas con nombre propio aprobado por la IAU, donde se ven desde la nave. Tecla: N.",
         "tip.const": "Constelaciones: las figuras de las constelaciones (cultura del cielo moderna de Stellarium) dibujadas como se verían DESDE LA NAVE: cada estrella a su distancia de Hipparcos, así que se deforman al viajar y se apagan cuando ya no se reconocen. Desde casa se ven como siempre. Tecla: C.",
         "tip.scale": "Escala: una regla y el ancho de la vista a la distancia de lo que miras (el objeto elegido o, si no hay, la nebulosa), en años luz y en Sistemas Solares (hasta la órbita de Neptuno, 60 ua de lado a lado). Tecla: E.",
         "tip.full": "Pantalla completa: la vista ocupa la pantalla y se esconden la cabina y los botones de la izquierda, para que la foto se vea lo más grande posible. Otra vez, F11 o Esc para volver. Tecla: F o F11.",
         nodir: "FOTO SIN GUARDAR: NO SE ELIGIÓ CARPETA", saved: "FOTO GUARDADA · {w} × {h} px · {where}", fail: "FOTO SIN GUARDAR: {why}", busy: "GUARDANDO LA FOTO ({w} × {h})…",
         fsHint: "F11 o Esc: salir de pantalla completa", scaleW: "ANCHO DE LA VISTA {w} {u} ≈ {n} SISTEMAS SOLARES", scaleAt: "a {d} {u} · {name}", selStar: "estrella elegida", au: "ua", ly: "a.l.", dl: "Descargas" }
};
function fwRbT(k, a) { var L = (typeof FW_LANG !== "undefined" && FW_LANG === "es") ? "es" : "en", s = FW_RB_TX[L][k]; if (s === undefined) s = FW_RB_TX.en[k] || k; if (a) for (var x in a) s = s.split("{" + x + "}").join(a[x]); return s; }
function fwRbLang() { return (typeof FW_LANG !== "undefined" && FW_LANG === "es") ? "es" : "en"; }
function fwRbNum(x, dec) { return (typeof fvsFmtNum === "function") ? fvsFmtNum(x, dec || 0, fwRbLang()) : (dec ? x.toFixed(dec) : String(Math.round(x))); }
function fwRbGet(k) { try { return localStorage.getItem("fv.rb." + k) === "1"; } catch (e) { return false; } }
function fwRbSet(k, on) { try { localStorage.setItem("fv.rb." + k, on ? "1" : "0"); } catch (e) {} }
function fwRbIds() { var o = []; if (!FW_RB.ON) return o; if (FW_RB.PHOTO) o.push("photo"); if (FW_RB.NAMES) o.push("names"); if (FW_RB.CONST) o.push("const"); if (FW_RB.SCALE) o.push("scale"); if (FW_RB.FULL) o.push("full"); return o; }

// ---------------------------------------------------------------------------
// LA COLUMNA: el envoltorio #winrow (la vista y la columna en fila; la franja de abajo no cambia) y los botones (el mismo laton que
// FWCockpit: bisel estriado, esfera, halo; las clases de fw_viewer.css)
// ---------------------------------------------------------------------------
var FW_RB_CSS = "#winrow{flex:1;min-height:0;display:flex;margin-right:calc(var(--u)*-.45)}#winrow>#win{flex:1;min-width:0}" +
   "#rcol{width:calc(var(--u)*5.6);flex:none;display:flex;flex-direction:column;align-items:center;gap:calc(var(--u)*.55);padding-top:calc(var(--u)*.45)}" +
   "body.rbfs #left,body.rbfs #strip{display:none}body.rbfs #right{padding-top:0}body.rbfs #rcol{padding-top:calc(var(--u)*.9)}" +
   "body.clean #rcol{display:none}body.clean #winrow{margin-right:0}";
function fwRbBuild() {
   if (FW_RB_ST.built || !FW_RB.ON) return false;
   var right = document.getElementById("right"), win = document.getElementById("win"), ids = fwRbIds();
   if (!right || !win || !ids.length || typeof fwEl !== "function") return false;
   var cs = document.createElement("style"); cs.id = "rbCss"; cs.textContent = FW_RB_CSS; document.head.appendChild(cs);
   var row = document.createElement("div"); row.id = "winrow"; right.insertBefore(row, win); row.appendChild(win);
   var col = document.createElement("div"); col.id = "rcol"; row.appendChild(col);
   FW_RB_ST.names = fwRbGet("names"); FW_RB_ST.cons = fwRbGet("const"); FW_RB_ST.scale = fwRbGet("scale");
   ids.forEach(function(id) {
      var b = document.createElement("button"); b.className = "brassbtn"; b.id = "btn-" + id; b.disabled = (id !== "full");
      b.title = fwRbT("tip." + id); b.setAttribute("aria-label", fwRbT("lab." + id));
      var s = fwEl("svg", { viewBox: "-30 -30 60 60" }, b);
      fwEl("circle", { r: 28.5, class: "bezel" }, s);
      for (var k = 0; k < 72; ++k) { var p = fwPol(28.3, k * 5), q = fwPol(27.1, k * 5); fwEl("line", { x1: p[0].toFixed(2), y1: p[1].toFixed(2), x2: q[0].toFixed(2), y2: q[1].toFixed(2), class: "tick" }, s); }
      fwEl("circle", { r: 28.4, class: "ring" }, s); fwEl("circle", { r: 26, class: "face" }, s); fwEl("circle", { r: 26, class: "ring" }, s);
      fwEl("circle", { r: 24.4, class: "ring2" }, s); fwEl("circle", { r: 29.3, class: "halo" }, s);
      var ic = fwEl("g", { class: "icon", fill: "none", stroke: "currentColor", "stroke-linecap": "round", "stroke-linejoin": "round", transform: "scale(1.04)" }, s);
      fwRbIcon(ic, id);
      var lab = document.createElement("div"); lab.className = "btnlab"; lab.textContent = fwRbT("lab." + id); if (typeof fwBtnLabel === "function") fwBtnLabel(lab);
      var wrap = document.createElement("div"); wrap.className = "btnwrap"; wrap.appendChild(b); wrap.appendChild(lab); col.appendChild(wrap);
      b.addEventListener("click", function(ev) { ev.stopPropagation(); if (!b.disabled) fwRbButton(id, { shift: ev.shiftKey }); });
      ["pointerdown", "dblclick", "wheel"].forEach(function(t) { b.addEventListener(t, function(ev) { ev.stopPropagation(); }, { passive: true }); });
      FW_RB_ST.btn[id] = b;
   });
   document.addEventListener("fullscreenchange", function() { if (!document.fullscreenElement && FW_RB_ST.fs && !FW_RB_ST.pseudo) fwRbFull(false); });
   window.addEventListener("keydown", fwRbKeyDown);
   FW_RB_ST.built = true;
   return true;
}
// los iconos: los MISMOS que PixInsight (fvRbEngrave de src/ui/fv_rightbar.js), con el buril de fwIcon (st: surco con filo de luz; hair: fino)
function fwRbIcon(g, id) {
   function st(d) { fwEl("path", { d: d, class: "edge", fill: "none", "stroke-width": 0.42, transform: "translate(.38,.38)" }, g); fwEl("path", { d: d, stroke: "currentColor", fill: "none", "stroke-width": 0.72 }, g); }
   function hair(d) { fwEl("path", { d: d, stroke: "currentColor", fill: "none", "stroke-width": 0.4 }, g); }
   function dot(x, y, r) { fwEl("circle", { cx: x, cy: y, r: r, fill: "currentColor", stroke: "none" }, g); }
   function circ(x, y, r) { return "M " + (x - r) + " " + y + " A " + r + " " + r + " 0 1 0 " + (x + r) + " " + y + " A " + r + " " + r + " 0 1 0 " + (x - r) + " " + y + " "; }
   function ln(a, b, c, d) { return "M " + a + " " + b + " L " + c + " " + d + " "; }
   function rect(a, b, c, d) { return "M " + a + " " + b + " L " + c + " " + b + " L " + c + " " + d + " L " + a + " " + d + " Z "; }
   var i;
   if (id === "photo") {
      st(rect(-14, -7, 14, 10) + "M -6 -7 L -3.5 -11 L 3.5 -11 L 6 -7 " + circ(0, 1.5, 6.2));
      hair(circ(0, 1.5, 3.6) + ln(-14, -3.5, -7.5, -3.5) + ln(7.5, -3.5, 14, -3.5) + rect(9, -5.6, 12, -4.2)); dot(0, 1.5, 1.2);
   } else if (id === "names") {
      st(ln(-11, 1, -11, 13) + ln(-17, 7, -5, 7) + "M -6.5 2.5 L -1 -5 L 15 -5 ");
      hair(ln(-13.4, 4.6, -8.6, 9.4) + ln(-8.6, 4.6, -13.4, 9.4) + ln(1, -9.5, 14, -9.5) + ln(1, -1, 10, -1)); dot(-11, 7, 1.5);
   } else if (id === "const") {
      var T = [[-15, -6], [-7, 6], [0, -2], [7, 7], [15, -7]], d = "", h = "";
      for (i = 1; i < T.length; ++i) { var a = T[i - 1], b = T[i], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.sqrt(dx * dx + dy * dy), k = 2.6 / l; d += ln((a[0] + dx * k).toFixed(2), (a[1] + dy * k).toFixed(2), (b[0] - dx * k).toFixed(2), (b[1] - dy * k).toFixed(2)); }
      st(d); for (i = 0; i < T.length; ++i) h += circ(T[i][0], T[i][1], 2.2); hair(h);
      for (i = 0; i < T.length; ++i) dot(T[i][0], T[i][1], i === 2 ? 1.5 : 1.15);
   } else if (id === "scale") {
      var s = ln(-15, 5, 15, 5), hh = "";
      for (i = 0; i <= 6; ++i) { var x = -15 + 5 * i; s += ln(x, 5, x, 5 - ((i % 3 === 0) ? 8 : 4.5)); }
      for (i = 0; i < 6; ++i) { var x2 = -12.5 + 5 * i; hh += ln(x2, 5, x2, 2.8); }
      st(s); hair(hh + ln(-15, 9, 15, 9) + ln(-15, 7.5, -15, 10.5) + ln(15, 7.5, 15, 10.5));
   } else if (id === "full") {
      var C = [[-1, -1], [1, -1], [1, 1], [-1, 1]], f = "";
      for (i = 0; i < 4; ++i) { var sx = C[i][0], sy = C[i][1]; f += "M " + (8 * sx) + " " + (11 * sy) + " L " + (15 * sx) + " " + (11 * sy) + " L " + (15 * sx) + " " + (5 * sy) + " "; }
      st(f); hair(rect(-9, -6, 9, 6) + "M -6 3 L -2 -2 L 2 3 ");
   }
}

// ---------------------------------------------------------------------------
// LOS MANDOS
// ---------------------------------------------------------------------------
function fwRbReady() { return typeof FW !== "undefined" && !!(FW.ready && FW.P && FW.R); }
function fwRbRecOn() { return typeof FW !== "undefined" && !!(FW.rec && FW.rec.on); }
function fwRbButton(id, o) {
   o = o || {};
   if (fwRbRecOn() && id !== "full") return false;
   if (id === "full") { fwRbFull(!FW_RB_ST.fs); return true; }
   if (!fwRbReady()) return false;
   if (id === "photo") { fwRbPhoto({ ask: !!o.shift }); }
   else if (id === "names" || id === "const" || id === "scale") {
      var k = id === "const" ? "cons" : id; FW_RB_ST[k] = !FW_RB_ST[k]; fwRbSet(id, FW_RB_ST[k]);
   } else return false;
   var b = FW_RB_ST.btn[id]; if (b) { b.classList.add("pressed"); setTimeout(function() { b.classList.remove("pressed"); }, 140); }
   fwRbSync(true);
   return true;
}
// teclas: P foto (Mayus+P cambia la carpeta) · N nombres · C constelaciones · E escala · F / F11 pantalla completa · Esc sale de la completa
function fwRbKeyDown(e) {
   if (!FW_RB_ST.built || (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) || e.ctrlKey || e.metaKey || e.altKey) return;
   var k = (e.key || "").toLowerCase(), id = null;
   if (k === "escape" && FW_RB_ST.fs) { e.preventDefault(); e.stopImmediatePropagation(); fwRbFull(false); return; }
   if (e.repeat) return;
   if (e.key === "F11") id = "full";
   else if (k === "p") id = "photo"; else if (k === "n") id = "names"; else if (k === "c") id = "const"; else if (k === "e") id = "scale"; else if (k === "f") id = "full";
   if (!id || !FW_RB_ST.btn[id]) return;
   e.preventDefault();
   fwRbButton(id, { shift: e.shiftKey });
}
// el estado de los botones (cada fotograma; solo toca el DOM si algo cambia)
function fwRbSync(force) {
   if (!FW_RB_ST.built) return;
   var rd = fwRbReady() && !fwRbRecOn(), key = [rd, FW_RB_ST.names, FW_RB_ST.cons, FW_RB_ST.scale, FW_RB_ST.fs, FW_RB_ST.busy].join(",");
   if (!force && key === FW_RB_ST.sync) return;
   FW_RB_ST.sync = key;
   var B = FW_RB_ST.btn, st = { photo: [rd && !FW_RB_ST.busy, false], names: [rd, FW_RB_ST.names], "const": [rd && typeof FV_CONST_DATA !== "undefined", FW_RB_ST.cons], scale: [rd, FW_RB_ST.scale], full: [true, FW_RB_ST.fs] };
   for (var id in st) if (B[id]) { var b = B[id]; if (b.disabled !== !st[id][0]) b.disabled = !st[id][0]; if (b.classList.contains("on") !== st[id][1]) b.classList.toggle("on", st[id][1]); }
}

// ---------------------------------------------------------------------------
// D6 · PANTALLA COMPLETA: la Fullscreen API (si el navegador la niega, la vista llena la ventana igual: «pseudo») y fuera la franja y la botonera
// izquierda. Esc, F o F11 salen.
// ---------------------------------------------------------------------------
function fwRbFull(on) {
   on = !!on;
   if (on === FW_RB_ST.fs) return on;
   FW_RB_ST.fs = on; FW_RB_ST.pseudo = false;
   document.body.classList.toggle("rbfs", on);
   if (on) {
      if (FW.route && FW.route.big && typeof FW.route.esc === "function") { try { FW.route.esc(); } catch (eR) {} }
      var el = document.documentElement;
      if (el.requestFullscreen) { try { var pr = el.requestFullscreen(); if (pr && pr.catch) pr.catch(function() { FW_RB_ST.pseudo = true; }); } catch (e) { FW_RB_ST.pseudo = true; } }
      else FW_RB_ST.pseudo = true;
      if (fwRbReady() && typeof fwCaption === "function") fwCaption(fwRbT("fsHint"), 2.6);
   } else if (document.fullscreenElement && document.exitFullscreen) { try { var px = document.exitFullscreen(); if (px && px.catch) px.catch(function() {}); } catch (e2) {} }
   if (typeof fwResize === "function" && fwRbReady()) fwResize();
   fwRbSync(true);
   return on;
}

// ---------------------------------------------------------------------------
// EL DIBUJO: encima del HUD (lo llama fwOverlay despues de drawHud) y en el lienzo de la foto. Sin nada encendido no toca el lienzo.
// ---------------------------------------------------------------------------
var FW_RB_COL = { line: [229, 181, 63, 0.55], dot: [255, 243, 196, 0.784], cname: [229, 181, 63, 0.659], ink: [251, 242, 224, 1], gold: [243, 210, 126, 1],
                  dim: [201, 180, 138, 1], casing: [0, 0, 0, 0.69], plate: [7, 6, 10, 0.55] };
function fwRbCol(c, a) { return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + (Math.max(0, Math.min(1, a === undefined ? 1 : a)) * c[3]).toFixed(3) + ")"; }
function fwRbFont(kind, px, ls) {
   var cs = getComputedStyle(document.documentElement), fam = (cs.getPropertyValue(kind === "display" ? "--display" : "--serif") || "Georgia,serif").trim();
   return { css: (kind === "display" ? "500 " : "") + px.toFixed(1) + "px " + fam, px: px, ls: ls || 0 };
}
function fwRbUseFont(g, f) { g.font = f.css; if ("letterSpacing" in g) g.letterSpacing = (f.ls || 0) + "px"; }
// el proyector de lo que se ve: la camara del render (con su deriva) y el giro (fvProjector lo trae con FV_PILOT.ROLL_PROJ)
function fwRbProj(W, H) {
   var P = FW.P, rc = (typeof fwRenderCam === "function") ? fwRenderCam(P) : null, cam = (rc && rc.cam) ? rc.cam : P.cam, pr = fvProjector(cam, W, H);   // fwRenderCam -> { cam, VW, VH } (o P)
   if (pr.roll === undefined && cam.roll) {
      var c = Math.cos(cam.roll), s = Math.sin(cam.roll), r = pr.r, d = pr.d;
      pr.r = [c * r[0] + s * d[0], c * r[1] + s * d[1], c * r[2] + s * d[2]]; pr.d = [-s * r[0] + c * d[0], -s * r[1] + c * d[1], -s * r[2] + c * d[2]]; pr.roll = cam.roll;
   }
   return pr;
}
function fwRbOverlay(now) {
   if (!FW_RB_ST.built) return;
   fwRbSync(false);
   if (!(FW_RB_ST.names || FW_RB_ST.cons || FW_RB_ST.scale) || !fwRbReady()) { FW_RB_ST.stats = null; return; }
   var hud = document.getElementById("hud"); if (!hud) return;
   var g = hud.getContext("2d"), W = FW.VW, H = FW.VH, dpr = hud.width / Math.max(1, W);
   g.save(); g.setTransform(dpr, 0, 0, dpr, 0, 0);
   FW_RB_ST.stats = fwRbPaint(g, fwRbProj(W, H), W, H, { names: FW_RB_ST.names, cons: FW_RB_ST.cons, scale: FW_RB_ST.scale });
   g.restore();
}
// -> { cons, names, scale, ms }
function fwRbPaint(g, pr, W, H, on) {
   var t0 = performance.now(), sc = FW.scene, u = W / 1280, prep = (on.names || on.cons) ? fvSkyovPrep(sc) : null, r = { cons: null, names: 0, scale: null };
   g.lineCap = "round";
   if (on.cons && prep) r.cons = fwRbPaintConst(g, prep, pr, W, H, u);
   if (on.names) r.names = fwRbPaintNames(g, sc, prep, pr, W, H, u);
   if (on.scale) r.scale = fwRbPaintScale(g, sc, W, H, u);
   r.ms = performance.now() - t0;
   return r;
}
function fwRbPaintConst(g, prep, pr, W, H, u) {
   var C = fvSkyovConst(prep, pr, W, H, u), i, lw = Math.max(0.8, 0.85 * u), lastA = -1, idx = [];
   for (i = 0; i < C.segs.length; ++i) idx.push(i);
   idx.sort(function(x, y) { return C.segs[x][4] - C.segs[y][4]; });
   g.lineWidth = lw;
   // por niveles de opacidad (1/16): un trazo por nivel, no por segmento
   for (i = 0; i < idx.length; ++i) {
      var s = C.segs[idx[i]], aq = Math.round(s[4] * 16) / 16;
      if (aq !== lastA) { if (lastA >= 0) g.stroke(); g.strokeStyle = fwRbCol(FW_RB_COL.line, aq); g.beginPath(); lastA = aq; }
      g.moveTo(s[0], s[1]); g.lineTo(s[2], s[3]);
   }
   if (lastA >= 0) g.stroke();
   for (i = 0; i < C.dots.length; ++i) { var d = C.dots[i]; g.fillStyle = fwRbCol(FW_RB_COL.dot, d[3]); g.beginPath(); g.arc(d[0], d[1], Math.max(0.9, (1.9 - 0.22 * Math.min(6, Math.max(-1, d[2]))) * u), 0, 2 * Math.PI); g.fill(); }
   var f = fwRbFont("display", Math.max(9, 10.5 * u), Math.max(1, Math.round(1.6 * u))), placed = [], asc = f.px * 0.78, hh = f.px * 1.2;
   fwRbUseFont(g, f); g.textBaseline = "alphabetic";
   for (i = 0; i < C.labels.length; ++i) {
      var l = C.labels[i], t = String(l.text).toUpperCase(), w = g.measureText(t).width, R = [l.x - w / 2 - 4 * u, l.y - asc - 2 * u, l.x + w / 2 + 4 * u, l.y - asc + hh + 2 * u], clash = false;
      if (l.x - w / 2 < 0 || l.x + w / 2 > W) continue;
      for (var j = 0; j < placed.length && !clash; ++j) { var Q = placed[j]; clash = R[0] < Q[2] && R[2] > Q[0] && R[1] < Q[3] && R[3] > Q[1]; }
      if (clash) continue;
      placed.push(R);
      g.fillStyle = fwRbCol(FW_RB_COL.casing, l.alpha); g.fillText(t, l.x - w / 2 + 1, l.y + 1);
      g.fillStyle = fwRbCol(FW_RB_COL.cname, l.alpha); g.fillText(t, l.x - w / 2, l.y);
   }
   if ("letterSpacing" in g) g.letterSpacing = "0px";
   return { nSeg: C.segs.length, nDots: C.dots.length, nFig: C.nFig, nFaded: C.nFaded, cached: C.cached, labels: C.labels.map(function(x) { return x.abbr; }) };
}
function fwRbPaintNames(g, sc, prep, pr, W, H, u) {
   var cand = fvSkyovNames(sc, prep, pr, W, H, fwRbLang()), placed = [], f = fwRbFont("text", Math.max(9, 11 * u)), asc = f.px * 0.75, des = f.px * 0.25, n = 0;
   fwRbUseFont(g, f); g.textBaseline = "alphabetic";
   function free(r) { if (r[0] < 2 || r[2] > W - 2 || r[1] < 2 || r[3] > H - 2) return false; for (var j = 0; j < placed.length; ++j) { var q = placed[j]; if (r[0] < q[2] && r[2] > q[0] && r[1] < q[3] && r[3] > q[1]) return false; } return true; }
   function mark(c) { g.beginPath(); if (c.kind === "object") g.arc(c.x, c.y, 4.2 * u, 0, 2 * Math.PI); else { g.moveTo(c.x - 4.5 * u, c.y); g.lineTo(c.x - 2 * u, c.y); g.moveTo(c.x + 2 * u, c.y); g.lineTo(c.x + 4.5 * u, c.y); } g.stroke(); }
   for (var i = 0; i < cand.length && n < FW_RB.NAMES_MAX; ++i) {
      var c = cand[i], w = g.measureText(c.text).width, off = (c.kind === "object" ? 7 : 5) * u, rr = null;
      var R1 = [c.x + off, c.y - off - asc, c.x + off + w, c.y - off + des], R2 = [c.x - off - w, c.y - off - asc, c.x - off, c.y - off + des];
      if (free(R1)) rr = R1; else if (free(R2)) rr = R2;
      if (!rr) continue;
      placed.push([rr[0] - 2 * u, rr[1] - u, rr[2] + 2 * u, rr[3] + u]); ++n;
      g.strokeStyle = fwRbCol(FW_RB_COL.casing); g.lineWidth = Math.max(1.6, 2.0 * u); mark(c);
      g.strokeStyle = fwRbCol(FW_RB_COL.gold); g.lineWidth = Math.max(0.8, 0.9 * u); mark(c);
      var tx = rr[0], ty = c.y - off;
      g.fillStyle = fwRbCol(FW_RB_COL.casing); g.fillText(c.text, tx + 1, ty + 1);
      g.fillStyle = fwRbCol(c.kind === "object" ? FW_RB_COL.ink : FW_RB_COL.dim); g.fillText(c.text, tx, ty);
   }
   return n;
}
function fwRbPaintScale(g, sc, W, H, u) {
   var S = fvSkyovScale(FW.P, sc, fwRbLang());
   if (!S) return null;
   var ly = fwRbT("ly"), inAu = S.bar.unit === "au", unit = inAu ? fwRbT("au") : ly;
   var x0 = Math.round(64 * u), yb = Math.round(H - 72 * u), len = S.bar.frac * W;
   var lab = fwRbNum(S.bar.len, S.bar.len < 1 ? (S.bar.len < 0.1 ? 2 : 1) : 0) + " " + unit;
   var wv = inAu ? S.widthLy * ((typeof FVS !== "undefined" && FVS.LY_AU) ? FVS.LY_AU : 63241.077) : S.widthLy;
   var l2 = fwRbT("scaleW", { w: fwRbNum(fvSkyovRound2(wv), wv < 10 ? 1 : 0), u: unit, n: fwRbNum(fvSkyovRound2(S.solarSystems), S.solarSystems < 10 ? 1 : 0) });
   var nm = S.refName || (S.refKind === "star" ? fwRbT("selStar") : "");
   var l3 = fwRbT("scaleAt", { d: fwRbNum(fvSkyovRound2(S.dRef), S.dRef < 10 ? 1 : 0), u: ly, name: nm }).replace(/ · $/, "");
   var f1 = fwRbFont("display", Math.max(9, 11 * u), Math.max(1, Math.round(1.4 * u))), f2 = fwRbFont("text", Math.max(8, 9.5 * u));
   fwRbUseFont(g, f2); var w2 = Math.max(g.measureText(l2).width, g.measureText(l3).width);
   var wBox = Math.max(len, w2) + 16 * u;
   g.fillStyle = fwRbCol(FW_RB_COL.plate); g.fillRect(x0 - 8 * u, yb - 22 * u, wBox, 52 * u);
   g.strokeStyle = fwRbCol(FW_RB_COL.gold); g.lineWidth = Math.max(1, 1.2 * u); g.beginPath();
   g.moveTo(x0, yb); g.lineTo(x0 + len, yb); g.moveTo(x0, yb - 5 * u); g.lineTo(x0, yb + 5 * u); g.moveTo(x0 + len, yb - 5 * u); g.lineTo(x0 + len, yb + 5 * u); g.stroke();
   g.lineWidth = Math.max(0.7, 0.7 * u); g.beginPath();
   for (var q = 1; q < 4; ++q) { g.moveTo(x0 + len * q / 4, yb - (q === 2 ? 3.5 : 2.2) * u); g.lineTo(x0 + len * q / 4, yb); }
   g.stroke();
   g.textBaseline = "alphabetic";
   fwRbUseFont(g, f1); g.fillStyle = fwRbCol(FW_RB_COL.ink); g.fillText(lab, x0 + (len - g.measureText(lab).width) / 2, yb - 7 * u);
   fwRbUseFont(g, f2); g.fillStyle = fwRbCol(FW_RB_COL.gold); g.fillText(l2, x0, yb + 14 * u);
   g.fillStyle = fwRbCol(FW_RB_COL.dim); g.fillText(l3, x0, yb + 25 * u);
   if ("letterSpacing" in g) g.letterSpacing = "0px";
   return { len: len, lab: lab, l2: l2, l3: l3, x0: x0, yb: yb, widthLy: S.widthLy, dRef: S.dRef, ss: S.solarSystems };
}

// ---------------------------------------------------------------------------
// D1 · LA FOTO. El renderizador se lleva un momento a la resolucion de la foto (mismo aspecto que la vista: misma proyeccion), se pinta
// REST_FRAMES + 1 veces (el volumen a resolucion completa, como en reposo), se copia a un lienzo 2D con lo encendido de la columna encima y se
// vuelve al tamaño de la pantalla en la MISMA tarea (la pantalla nunca ve el lienzo grande). Sin viñeta, grano ni ventana de la nave.
// o = { W (pruebas), ask (cambiar carpeta) } -> promesa de { ok, why, w, h, ms, tRender, tPng, tSave, where, name }
// ---------------------------------------------------------------------------
function fwRbPhotoSize(Wwant) {
   var f = FW.scene.field || {}, a = FW.VW / FW.VH, gl = FW.R && FW.R.r && FW.R.r.capabilities ? FW.R.r.capabilities.maxTextureSize : 8192;
   var W = Wwant || Math.round(f.width || FW.VW * FW.dpr), H = Math.round(W / a), s = Math.min(1, Math.min(FW_RB.PHOTO_MAX, gl || 8192) / Math.max(W, H));
   W = Math.max(64, Math.round(W * s)); H = Math.max(64, Math.round(W / a));
   return [W, H];
}
function fwRbPhotoRender(W, H) {
   var R = FW.R, o = R.opt, keep = { vig: o.vig, grain: o.grain }, fgv = (typeof FW_FG_ST !== "undefined") ? FW_FG_ST.variant : undefined, t = {};
   var VW = FW.VW, VH = FW.VH, dpr = FW.dpr || 1, cv = document.createElement("canvas"), stats = null;
   cv.width = W; cv.height = H;
   var g = cv.getContext("2d");
   try {
      o.vig = 0; o.grain = 0; if (fgv !== undefined) FW_FG_ST.variant = "off";
      var t0 = performance.now(); R.resize(W, H);
      var n = ((typeof FW_GL !== "undefined" && FW_GL.REST_FRAMES) || 3) + 1;
      for (var i = 0; i < n; ++i) fwRenderFrame(0);
      g.drawImage(document.getElementById("gl"), 0, 0, W, H);
      t.tRender = performance.now() - t0;
      if (FW_RB_ST.names || FW_RB_ST.cons || FW_RB_ST.scale) stats = fwRbPaint(g, fwRbProj(W, H), W, H, { names: FW_RB_ST.names, cons: FW_RB_ST.cons, scale: FW_RB_ST.scale });
   } finally {
      o.vig = keep.vig; o.grain = keep.grain; if (fgv !== undefined) FW_FG_ST.variant = fgv;
      R.resize(Math.round(VW * dpr), Math.round(VH * dpr)); fwRenderFrame(0);
   }
   t.stats = stats;
   return { cv: cv, t: t };
}
// (9-nov, encargo E · P6) EL REC LLEVA LO MISMO QUE SE VE: fw_mp4.js codificaba solo el lienzo GL, y los nombres, las constelaciones y la escala
// van en el lienzo del HUD (encima, 2D), asi que el video salia sin ellos. Con alguno encendido, cada fotograma del video es el GL con esos tres
// dibujados encima (el mismo fwRbPaint de la pantalla y de la FOTO, a la resolucion del video; la camara es la del fotograma que se acaba de
// pintar). Con ninguno encendido devuelve null y el REC codifica el lienzo GL tal cual (el de antes). Los botones se bloquean mientras se graba
// (fwRbButton), asi que lo encendido al empezar es lo que sale en todo el video. -> lienzo 2D (rec.W × rec.H) | null
function fwRbRecSource(rec) {
   var on = { names: FW_RB_ST.names, cons: FW_RB_ST.cons, scale: FW_RB_ST.scale };
   if (!FW_RB.ON || !(on.names || on.cons || on.scale) || !fwRbReady()) return null;
   var W = rec.W, H = rec.H, cv = rec.composeCv;
   if (!cv || cv.width !== W || cv.height !== H) { cv = rec.composeCv = document.createElement("canvas"); cv.width = W; cv.height = H; rec.composeG = cv.getContext("2d"); }
   var g = rec.composeG; g.setTransform(1, 0, 0, 1, 0, 0);
   g.drawImage(rec.canvas, 0, 0, W, H, 0, 0, W, H);
   rec.composeStats = fwRbPaint(g, fwRbProj(W, H), W, H, on);
   return cv;
}
function fwRbPhotoName() {
   var N = FW.scene.nebula, nm = String((N && (N.id || N.name)) || "scene").replace(/[^A-Za-z0-9_-]+/g, "_").replace(/^_+|_+$/g, "") || "scene";
   var d = new Date(), p2 = function(v) { return (v < 10 ? "0" : "") + v; };
   return "FieldVoyager_" + nm + "_" + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + "_" + p2(d.getHours()) + p2(d.getMinutes()) + p2(d.getSeconds()) + ".png";
}
// la carpeta recordada (IndexedDB: un FileSystemDirectoryHandle no cabe en localStorage)
function fwRbIdb(mode, val) {
   return new Promise(function(res) {
      try {
         var rq = indexedDB.open("fieldvoyager", 1);
         rq.onupgradeneeded = function() { rq.result.createObjectStore("kv"); };
         rq.onerror = function() { res(null); };
         rq.onsuccess = function() {
            try { var db = rq.result, tx = db.transaction("kv", mode === "set" ? "readwrite" : "readonly"), st = tx.objectStore("kv"), r2 = mode === "set" ? st.put(val, "photoDir") : st.get("photoDir");
                  r2.onsuccess = function() { res(mode === "set" ? true : (r2.result || null)); }; r2.onerror = function() { res(null); }; } catch (e) { res(null); }
         };
      } catch (e) { res(null); }
   });
}
// -> promesa de un FileSystemDirectoryHandle, null (cancelado) o «dl» (sin la API: descarga)
function fwRbDir(ask) {
   if (!FW_RB.FSA || typeof window.showDirectoryPicker !== "function") return Promise.resolve("dl");
   return (ask ? Promise.resolve(null) : fwRbIdb("get")).then(function(h) {
      if (!h) return null;
      return h.queryPermission({ mode: "readwrite" }).then(function(p) { return p === "granted" ? p : h.requestPermission({ mode: "readwrite" }); })
              .then(function(p) { return p === "granted" ? h : null; }, function() { return null; });
   }).then(function(h) {
      if (h) return h;
      return window.showDirectoryPicker({ id: "fvphoto", mode: "readwrite", startIn: "pictures" }).then(function(d) { return fwRbIdb("set", d).then(function() { return d; }); }, function() { return null; });
   });
}
function fwRbPhoto(o) {
   o = o || {};
   var res = { ok: false, why: "", w: 0, h: 0, ms: 0, where: "", name: "" };
   if (!fwRbReady() || FW_RB_ST.busy) { res.why = "busy"; return Promise.resolve(res); }
   var t0 = performance.now(), sz = fwRbPhotoSize(o.W), W = sz[0], H = sz[1], hook = FW_RB.PHOTO_HOOK;
   res.w = W; res.h = H; res.name = fwRbPhotoName();
   FW_RB_ST.busy = true; fwRbSync(true);
   // la carpeta PRIMERO, con el clic aun fresco (el permiso y el selector piden un gesto del usuario)
   var dirP = (typeof hook === "function") ? Promise.resolve("hook") : fwRbDir(!!o.ask);
   return dirP.then(function(dir) {
      if (!dir) { res.why = "no folder"; if (typeof fwCaption === "function") fwCaption(fwRbT("nodir"), 2.4); return res; }
      if (typeof fwCaption === "function") fwCaption(fwRbT("busy", { w: W, h: H }), 30);
      // dos fotogramas para que se vea el aviso; luego el render grande (sincrono) y el PNG
      return new Promise(function(r) { requestAnimationFrame(function() { requestAnimationFrame(r); }); }).then(function() {
         var out = fwRbPhotoRender(W, H); res.tRender = Math.round(out.t.tRender); res.paint = out.t.stats;
         var tp = performance.now();
         return new Promise(function(r) { out.cv.toBlob(r, "image/png"); }).then(function(blob) {
            res.tPng = Math.round(performance.now() - tp);
            if (!blob) throw new Error("PNG");
            res.bytes = blob.size;
            var ts = performance.now();
            var save = (dir === "hook") ? Promise.resolve(hook(res, blob, out.cv)).then(function() { return "(test)"; })
                     : (dir === "dl") ? Promise.resolve().then(function() { fwDownload(blob, res.name); return fwRbT("dl") + "/" + res.name; })
                     : dir.getFileHandle(res.name, { create: true }).then(function(fh) { return fh.createWritable(); }).then(function(w) { return w.write(blob).then(function() { return w.close(); }); }).then(function() { return dir.name + "/" + res.name; });
            return save.then(function(where) { res.tSave = Math.round(performance.now() - ts); res.where = where; res.ok = true; return res; });
         });
      });
   }).catch(function(e) { res.ok = false; res.why = String((e && e.message) || e); return res; })
     .then(function(r) {
      FW_RB_ST.busy = false; r.ms = Math.round(performance.now() - t0); FW_RB_ST.last = r; fwRbSync(true);
      if (typeof fwCaption === "function" && r.why !== "no folder") fwCaption(r.ok ? fwRbT("saved", { w: r.w, h: r.h, where: r.where }) : fwRbT("fail", { why: r.why }), r.ok ? 4 : 3);
      try { console.log("[rb] photo " + (r.ok ? r.w + "x" + r.h + " → " + r.where + " in " + r.ms + " ms (render " + r.tRender + ", PNG " + r.tPng + ", save " + r.tSave + ")" : "FAILED " + r.why)); } catch (e3) {}
      return r;
   });
}

// ---------------------------------------------------------------------------
// PRUEBAS (tests/web/fv_rb_cdp.js)
// ---------------------------------------------------------------------------
function fwRbTestApi() {
   if (typeof FW === "undefined" || !FW.test) return;
   FW.test.rb = function() {
      var col = document.getElementById("rcol"), win = document.getElementById("win"), r = function(e) { if (!e) return null; var b = e.getBoundingClientRect(); return [Math.round(b.left), Math.round(b.top), Math.round(b.width), Math.round(b.height)]; };
      var btns = {}; for (var id in FW_RB_ST.btn) { var b = FW_RB_ST.btn[id]; btns[id] = { box: r(b), on: b.classList.contains("on"), en: !b.disabled, lab: b.parentNode.querySelector(".btnlab").textContent, tip: b.title }; }
      var lb = []; Array.prototype.forEach.call(document.querySelectorAll("#left .brassbtn"), function(b) { lb.push({ id: b.id, box: r(b) }); });
      return { built: FW_RB_ST.built, on: FW_RB.ON, names: FW_RB_ST.names, cons: FW_RB_ST.cons, scale: FW_RB_ST.scale, fs: FW_RB_ST.fs, pseudo: !!FW_RB_ST.pseudo, fsEl: !!document.fullscreenElement,
               win: r(win), col: r(col), VW: FW.VW, VH: FW.VH, btns: btns, left: lb, stats: FW_RB_ST.stats, last: FW_RB_ST.last };
   };
   FW.test.rbSet = function(o) { for (var k in o) { if (k === "fs") fwRbFull(!!o[k]); else FW_RB_ST[k] = !!o[k]; } fwRbSync(true); return FW.test.render(); };
   FW.test.rbButton = function(id, shift) { return fwRbButton(id, { shift: !!shift }); };
   // la foto sin dialogos: el gancho recibe el PNG; devuelve el resultado y una miniatura para comparar con la vista
   FW.test.rbPhoto = function(W) {
      FW_RB.PHOTO_HOOK = function(res, blob, cv) { FW_RB_ST.testPng = { size: blob.size, w: cv.width, h: cv.height }; FW_RB_ST.testCv = cv; };
      return fwRbPhoto({ W: W }).then(function(r) { FW_RB.PHOTO_HOOK = null; return r; });
   };
   // correlacion de luminancia entre la foto guardada (reducida) y la vista de ahora (gl) pintada SIN lo que la foto no lleva (ventana de la
   // nave, viñeta, grano), a 320 px de ancho
   FW.test.rbPhotoCorr = function() {
      var cv = FW_RB_ST.testCv; if (!cv) return null;
      var o = FW.R.opt, kv = o.vig, kg = o.grain, fgv = (typeof FW_FG_ST !== "undefined") ? FW_FG_ST.variant : undefined;
      o.vig = 0; o.grain = 0; if (fgv !== undefined) FW_FG_ST.variant = "off";
      fwRenderFrame(0);
      var w = 320, h = Math.round(320 * cv.height / cv.width);
      function lum(src) { var c = document.createElement("canvas"); c.width = w; c.height = h; var x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(src, 0, 0, w, h); var d = x.getImageData(0, 0, w, h).data, L = new Float64Array(w * h); for (var i = 0; i < w * h; ++i) L[i] = 0.2126 * d[4 * i] + 0.7152 * d[4 * i + 1] + 0.0722 * d[4 * i + 2]; return L; }
      var A = lum(cv), B = lum(document.getElementById("gl")), n = w * h, ma = 0, mb = 0, i;
      o.vig = kv; o.grain = kg; if (fgv !== undefined) FW_FG_ST.variant = fgv; fwRenderFrame(0); for (i = 0; i < n; ++i) { ma += A[i]; mb += B[i]; } ma /= n; mb /= n;
      var sab = 0, saa = 0, sbb = 0; for (i = 0; i < n; ++i) { var x = A[i] - ma, y = B[i] - mb; sab += x * y; saa += x * x; sbb += y * y; }
      return { r: sab / Math.sqrt(saa * sbb), meanPhoto: ma, meanView: mb };
   };
   // la foto guardada (reducida) como data URL para mirarla
   FW.test.rbPhotoUrl = function(wMax) { var cv = FW_RB_ST.testCv; if (!cv) return null; var s = Math.min(1, (wMax || 1600) / cv.width), c = document.createElement("canvas"); c.width = Math.round(cv.width * s); c.height = Math.round(cv.height * s); c.getContext("2d").drawImage(cv, 0, 0, c.width, c.height); return c.toDataURL("image/png"); };
   // pixeles del HUD con algo pintado (alfa > 0)
   FW.test.rbHudInk = function() { var h = document.getElementById("hud"), d = h.getContext("2d").getImageData(0, 0, h.width, h.height).data, n = 0; for (var i = 3; i < d.length; i += 4) if (d[i] > 0) ++n; return n; };
   // el coste del dibujo SIN cache (peor caso) y con ella, en ms, repitiendo n veces
   FW.test.rbCost = function(n) {
      var hud = document.getElementById("hud"), g = hud.getContext("2d"), W = FW.VW, H = FW.VH, pr = fwRbProj(W, H), on = { names: FW_RB_ST.names, cons: FW_RB_ST.cons, scale: FW_RB_ST.scale }, a = [], b = [], k, st = null;
      var keep = FV_SKYOV.CACHE;
      for (k = 0; k < n; ++k) { FV_SKYOV.CACHE = false; var prep = fvSkyovPrep(FW.scene); if (prep) { prep.fadeKey = null; prep.cc = null; } g.save(); var t = performance.now(); st = fwRbPaint(g, pr, W, H, on); a.push(performance.now() - t); g.restore(); }
      FV_SKYOV.CACHE = keep;
      for (k = 0; k < n; ++k) { g.save(); var t2 = performance.now(); fwRbPaint(g, pr, W, H, on); b.push(performance.now() - t2); g.restore(); }
      a.sort(function(x, y) { return x - y; }); b.sort(function(x, y) { return x - y; });
      return { uncachedMed: a[a.length >> 1], uncachedMax: a[a.length - 1], cachedMed: b[b.length >> 1], stats: st };
   };
}

if (typeof document !== "undefined") document.addEventListener("DOMContentLoaded", function() { try { fwRbBuild(); fwRbTestApi(); } catch (e) { try { console.warn("[rb] " + e); } catch (e2) {} } });
