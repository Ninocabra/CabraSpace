// ============================================================================
// FieldVoyager/web/fw_gpu_note.js — AVISO DE LA GRAFICA (W4, 6-nov-2026)
// ----------------------------------------------------------------------------
// Medido el 5-nov (tests/web/fv_nD_perf.js --gpu=default): Chrome en este portatil dibuja por defecto con la grafica INTEGRADA (Intel) y no
// con la NVIDIA; a 5K el volumen pasa de 20 ms a 110 ms por fotograma. PixInsight si usa la NVIDIA. El navegador no puede elegir la grafica:
// lo decide el sistema. Por eso, si el visor no esta en una grafica dedicada (FW.R.info.gpuClass, fw_gl.js), sale UNA linea discreta
// ENTRE la imagen y la cabina (no tapa la imagen: la ventana se encoge esa linea), en EN/ES, que dice como arreglarlo en ESTE sistema
// (Windows / macOS / Linux) y se puede cerrar; el cierre se recuerda (localStorage, si el navegador lo deja; si no, vuelve a salir).
// El texto entero va en el tooltip. FW_GPU_NOTE = false: nunca sale.
// ES5.
// ============================================================================

var FW_GPU_NOTE = true;
var FW_GPU_NOTE_KEY = "fieldvoyager.gpuNote.closed";

function fwGpuNoteClosed() { try { return window.localStorage && localStorage.getItem(FW_GPU_NOTE_KEY) === "1"; } catch (e) { return false; } }
function fwGpuNoteRemember() { try { if (window.localStorage) localStorage.setItem(FW_GPU_NOTE_KEY, "1"); } catch (e) {} }

// el texto: { line (una linea), tip (entero) } para la clase de grafica y el sistema
function fwGpuNoteText(cls, renderer) {
   var es = (typeof FW_LANG !== "undefined" && FW_LANG === "es"), ua = (navigator.userAgent || ""), how;
   var win = /Windows/i.test(ua), mac = /Mac OS X|Macintosh/i.test(ua);
   if (cls === "software") {
      how = es ? "activa «Usar aceleración gráfica cuando esté disponible» en la configuración del navegador (Sistema) y reinícialo"
               : "turn on “Use graphics acceleration when available” in the browser settings (System) and restart it";
      return { line: (es ? "Sin aceleración gráfica: irá muy lento · " : "No graphics acceleration: it will be very slow · ") + how,
               tip: (es ? "El navegador dibuja sin la tarjeta gráfica (" : "The browser draws without the graphics card (") + renderer + "). " + how + "." };
   }
   if (win) how = es ? "Configuración de Windows › Sistema › Pantalla › Gráficos › tu navegador › Alto rendimiento, y reinícialo"
                     : "Windows Settings › System › Display › Graphics › your browser › High performance, then restart it";
   else if (mac) how = es ? "Ajustes del Sistema › Batería › Opciones: desactiva el cambio automático de gráficos"
                          : "System Settings › Battery › Options: turn off automatic graphics switching";
   else how = es ? "lanza el navegador en la gráfica dedicada (por ejemplo prime-run o DRI_PRIME=1)"
                 : "start the browser on the dedicated graphics card (for example prime-run or DRI_PRIME=1)";
   var what = (cls === "integrated") ? (es ? "Dibujando con la gráfica integrada: irá más lento que en PixInsight" : "Drawing on the integrated graphics: slower than in PixInsight")
                                     : (es ? "No se reconoce la gráfica: si va lento" : "Unrecognised graphics: if it is slow");
   return { line: what + " · " + how,
            tip: what + " (" + renderer + "). " + (es ? "Para usar la tarjeta dedicada: " : "To use the dedicated card: ") + how + "." };
}

// mira la grafica y pone (o no) el aviso; devuelve lo que hizo (para las pruebas)
function fwGpuNoteCheck() {
   var old = document.getElementById("gpuNote");
   if (!FW_GPU_NOTE || typeof FW === "undefined" || !FW.R || !FW.R.info) return "sin-visor";
   var cls = FW.R.info.gpuClass || "unknown";
   if (cls === "discrete" || fwGpuNoteClosed()) { if (old) { old.parentNode.removeChild(old); if (typeof fwResize === "function") fwResize(); } return cls === "discrete" ? "dedicada" : "cerrado"; }
   var right = document.getElementById("right"), strip = document.getElementById("strip");
   if (!right || !strip) return "sin-sitio";
   var T = fwGpuNoteText(cls, String(FW.R.info.renderer || "?")), d = old;
   if (!d) {
      d = document.createElement("div"); d.id = "gpuNote"; d.setAttribute("role", "status");
      d.innerHTML = "<svg viewBox='0 0 16 16' aria-hidden='true'><rect x='3.5' y='3.5' width='9' height='9' rx='1'/><path d='M6 1.5v2M10 1.5v2M6 12.5v2M10 12.5v2M1.5 6h2M1.5 10h2M12.5 6h2M12.5 10h2'/></svg><span></span><button type='button' aria-label='Close'>×</button>";
      right.insertBefore(d, strip);
      d.querySelector("button").addEventListener("click", function(e) { e.stopPropagation(); fwGpuNoteRemember(); if (d.parentNode) d.parentNode.removeChild(d); if (typeof fwResize === "function") fwResize(); });
   }
   d.querySelector("span").textContent = T.line; d.title = T.tip;
   if (!old && typeof fwResize === "function") fwResize();
   return "aviso:" + cls;
}

// al arrancar: espera al visor (el renderizador lo crea fw_viewer.js al cargar el paquete) y mira una vez
(function() {
   var n = 0;
   function poll() { if (typeof FW !== "undefined" && FW.R && FW.R.info && FW.R.info.gpuClass) { fwGpuNoteCheck(); return; } if (++n < 240) setTimeout(poll, 500); }
   if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", poll); else poll();
})();
