// ============================================================================
// FieldVoyager/web/fw_cockpit.js — LA CABINA RETRO del visor del navegador (4-nov-2026, F3)
// ----------------------------------------------------------------------------
// La MISMA cabina que la maqueta §10 de docs/vuelo-3d-analisis.html y que el pintor de PixInsight (src/ui/fv_cockpit.js, D6):
// la foto manda; franja baja con VELOCITAS (c, logaritmica de 10⁻³ a 10, «∞» por encima), DISTANTIA (años luz, logaritmica de 1 a
// 10 000), CHRONOMETRUM (reloj de escena, con segundero pequeño), placa del fabricante remachada, REGULATOR (cuadrante de vapor:
// la palanca lee el warp) y RADIOPHONIA (disco numerado bajo un indice fijo, mando moleteado que se arrastra para sintonizar).
// Esfera de esmalte crema, bisel de laton estriado, aro de capitulos doble, numeros romanos, agujas Breguet pavonadas, cristal.
// Botonera de laton a la izquierda (D7): Info, Warp, Ir a, Orbitar, Exoplaneta (apagado: F2). Ficha retro (§06): esquinas que
// convergen, linea con codo, panel con el objeto en grande, barrido de pelicula, texto que se escribe solo y cifras que giran.
// Todo en SVG/HTML por encima del lienzo WebGL: no entra en el video (el video es la vista limpia; ver fw_mp4.js).
// ES5.
// ============================================================================

var FW_NS = "http://www.w3.org/2000/svg";
function fwEl(t, a, p) { var e = document.createElementNS(FW_NS, t); for (var k in a) e.setAttribute(k, a[k]); if (p) p.appendChild(e); return e; }
function fwPol(r, deg) { var a = deg * Math.PI / 180; return [Math.sin(a) * r, -Math.cos(a) * r]; }
var FW_LANG = (function() { try { var q = /[?&]lang=(en|es)/.exec(location.search); if (q) return q[1]; return /^es/i.test(navigator.language || "") ? "es" : "en"; } catch (e) { return "en"; } })();
function fwTr(en, es) { return FW_LANG === "es" ? es : en; }
// (Blender 5b · R5-11) el separador de miles del idioma (EN: «6,517 ly»; antes siempre un espacio fino, mientras PROFUNDITAS decia «6,520 ly»)
function fwFmtInt(x) { var sep = ((typeof FV_B5B === "undefined" || FV_B5B.FMT) && FW_LANG !== "es") ? "," : " ", s = String(Math.round(x)), out = ""; while (s.length > 3) { out = sep + s.substring(s.length - 3) + out; s = s.substring(0, s.length - 3); } return s + out; }
function fwFmtLy(ly) { return (ly >= 100) ? fwFmtInt(ly) : (ly >= 10 ? ly.toFixed(1) : ly.toFixed(2)).replace(".", FW_LANG === "es" ? "," : "."); }
function fwSup(n) { var d = "⁰¹²³⁴⁵⁶⁷⁸⁹", s = String(n), o = ""; for (var i = 0; i < s.length; ++i) o += (s.charAt(i) === "-") ? "⁻" : d.charAt(Number(s.charAt(i))); return o; }
// (F3c) VELOCITAS en MULTIPLOS DE c (las mismas reglas para F4b): 0 parado; «< 1 c»; hasta 999 entero; despues m·10ⁿ c
var FW_C = { REST_C: 1e-3, LOG_MAX: 12 };
// (E9, Nino 4-nov: «haz más claro dónde está la velocidad de la luz») la MISMA esfera que PixInsight (fvSpeedCAngle, src/ui/fv_cockpit.js):
// 0 parado en −120°, lineal hasta c en −60° (la marca bermellon «c»), logaritmica de c a 10¹² c en +120°; el tramo superluminico con una banda
// bermellon tenue; la lectura en tinta por debajo de c (con su cifra: «0,30 c», antes «< 1 c» con la aguja clavada en el tope) y en bermellon
// por encima. FW_E9 = false: la escala de antes (logaritmica desde 1 c; por debajo, aguja en el tope) — el ROJO de fv_nE2_cdp.js.
var FW_E9 = true;
function fwSpeedCAngle(c) {
   if (!FW_E9) return (c > FW_C.REST_C) ? -120 + 240 * fvClamp(Math.log(Math.max(1, c)) / Math.LN10 / FW_C.LOG_MAX, 0, 1) : -124;
   if (!(c > FW_C.REST_C)) return -120;
   if (c < 1) return -120 + 60 * c;
   return -60 + 15 * Math.min(FW_C.LOG_MAX, Math.log(c) / Math.LN10);
}
function fwSpeedCText(c) {
   var dec = FW_LANG === "es" ? "," : ".";
   if (!(c > FW_C.REST_C)) return "0";
   if (c < 1) return FW_E9 ? (c < 0.01 ? "< 0" + dec + "01 c" : c.toFixed(2).replace(".", dec) + " c") : "< 1 c";
   if (c < 1000) return Math.round(c) + " c";
   var e = Math.floor(Math.log(c) / Math.LN10 + 1e-9), m = c / Math.pow(10, e);
   if (m >= 9.95) { m /= 10; ++e; }
   return m.toFixed(1).replace(".", dec) + "·10" + fwSup(e) + " c";
}

// (pasada N) la MISMA botonera que la de PixInsight (src/ui/fv_buttons.js de A): Vista inicial arriba (N3), Info, Viajar (MODUS elige
// CINE o WARP), Orbitar, Mirar al Sol y Tour. El boton Exoplaneta se quita (N12: los planetas van a la lista MIRABILIA de abajo).
// (5-nov, Nino) fuera Orbitar y Mirar al Sol (el motor sigue: fvPilotOrbit, fvPilotLookHome); la columna derecha va en fw_rightbar.js.
var FW_BTNS = [
   { id: "start", en: "Home", es: "Inicio", tip: ["Home: fly back smoothly to where you began, the Earth, seeing your photo as you took it. Also double-click on the scene or key H. Key U (no button): turns the ship toward the Sun from where you are, without flying, and shows how bright the Sun would look from there.", "Inicio: vuelve volando suave a donde empezaste, la Tierra, viendo tu foto como la hiciste. También doble clic en la escena o tecla H. Tecla U (sin botón): gira la nave hacia el Sol desde donde estés, sin volar, y enseña cuánto brillaría el Sol visto desde allí."] },
   { id: "info", en: "Info", es: "Info", tip: ["Info: opens the card of the object you have selected (click an object first, or pick it in MIRABILIA): distance, temperature, and whether each figure is measured, doubtful or assumed. The card also opens by itself when you arrive at a destination. Press again to close it. Key: I.", "Info: abre la ficha del objeto que has elegido (haz clic en un objeto antes, o elígelo en MIRABILIA): distancia, temperatura, y si cada dato es medido, dudoso o supuesto. La ficha también se abre sola al llegar a un destino. Otra pulsación la cierra. Tecla: I."] },
   { id: "travel", en: "Travel", es: "Viajar", tip: ["Travel to the selected object. MODUS on the dashboard chooses how: CINEMA (slow, cinematic) or WARP (Star Trek). Key: Space.", "Viajar al objeto elegido. MODUS, en el cuadro de mandos, elige cómo: CINE (lento, de cine) o WARP (Star Trek). Tecla: espacio."] },
   { id: "tour", en: "Tour", es: "Tour", tip: ["Tour: an automatic trip through the most singular objects of the field, with their cards. Again to stop. Key: T.", "Tour: un viaje automático por lo más singular del campo, con sus fichas. Otra vez, para. Tecla: T."] }
];
// (21-nov, N-galaxias-warp; FV_GWARP) sin selector MODUS: el texto de VIAJAR dice como se elige el modo
if (typeof fvGwarpUi === "function" && fvGwarpUi()) FW_BTNS[2].tip = ["Travel to the selected object. Inside the Milky Way the ship flies a cinematic trip; to another galaxy it makes a short warp jump. Key: Space.", "Viajar al objeto elegido. Dentro de la Vía Láctea la nave hace un viaje de cine; a otra galaxia, un salto warp corto. Tecla: espacio."];

// (I2, 19-nov) el boton DIAGRAMA HR (web/fw_hr.js, cargado antes; motor engine/fv_hr.js): FW_HR.ON false, o sin el motor en el paquete, = sin boton
if (typeof FW_HR !== "undefined" && FW_HR.ON !== false && typeof fwHrBtn === "function" && typeof fvHrBuild === "function") FW_BTNS.push(fwHrBtn());

// ---------------------------------------------------------------------------
// (1c, Nino 5-nov: «mejórala ... pantallas de distintas resoluciones ... las letras más claras y legibles») LA CABINA 3D, gemela de la de
// PixInsight (src/ui/fv_cockpit.js, FV_CK3D): las piezas fisicas (biseles, esmaltes, placas, teclas, palancas, cristales) son sprites
// renderizados en Blender (blender/cabina3d_v3.py -> blender/build_cabina_rsc.py -> web/fw_ck3d_s<nivel>.js, PNG de 256 colores en base64);
// la TINTA (cifras, rotulos, lecturas, agujas) sigue siendo SVG, encima: mas oscura y con filo de sombra en los rotulos claros.
// Nivel: el menor que cubra los px de pantalla por unidad de la franja (× devicePixelRatio) entre 1,2 · 2,0 · 3,0; se carga UN fichero
// (77-134 KB) y, si la ventana crece, el siguiente. Mientras no llega (o si falta), la cabina dibujada.
// FW_CK3D = false: la cabina dibujada con el DOM de siempre (fv_ck3d_cdp K1: pixel identica).
// ---------------------------------------------------------------------------
// (9-nov, encargo E · P7) el rotulo mas largo de la botonera («VISTA INICIAL», 13 letras) llenaba la columna y quedaba a 6,7 px del borde de la ventana
// (1920 × 1080; los demas, a 18 px o mas): los rotulos de 12 letras o mas se componen mas cerrados (clase «long», fw_viewer.css) y dejan holgura a los
// dos lados. false = ROJO: el rotulo de antes
var FW_BTN_LABEL_FIT = true, FW_BTN_LABEL_LONG = 12;
function fwBtnLabel(lab) { if (FW_BTN_LABEL_FIT !== false && lab.textContent.length >= FW_BTN_LABEL_LONG) lab.className += " long"; return lab; }
var FW_CK_GW_W = 880;           // (21-nov, N-galaxias-warp) ancho del viewBox del cuadro de mandos sin la placa MODUS (con ella 960)
var FW_CK3D = true;              // (5-nov, Nino: «Sí, enciéndela») la cabina de Blender por defecto
var FW_CK3D_LV = ["1.2", "2.0", "3.0"];
// el centro de cada pieza en la rejilla de PixInsight (1440 × 156): una unidad de rejilla = una unidad del SVG (los relojes miden r 38 en las dos)
var FW_CK3D_C = { V: [505, 70], T: [695, 70], plate: [850, 66], aetas: [763, 66], reg: [990, 95], radio: [1112, 64], modus: [1200, 66], rec: [425, 58] };
var FW_CK3D_IMGS = [], FW_CK3D_CUR = null, FW_CK3D_ASKED = {};
var FW_CK3D_CSS = "#ck:not(.ck3d-on) .ck3dimg{display:none}#ck.ck3d-on .ck2d{display:none}" +
   "#ck .padkey .k3s{display:none}#ck.ck3d-on .padkey{opacity:1}" +
   "#ck.ck3d-on .padkey[data-state=idle] .k3-rest,#ck.ck3d-on .padkey[data-state=on] .k3-lit,#ck.ck3d-on .padkey[data-state=off] .k3-off{display:inline}" +
   "#ck.ck3d-on #modeSwitch[data-up='1'] .k3-down,#ck.ck3d-on #modeSwitch[data-up='0'] .k3-up{display:none}" +
   "#ck.ck3d-on #recBtn[data-on='0'] .k3-gem{display:none}" +
   // la tinta: cifras y lecturas casi negras (#17100A), titulos sepia oscuro, la «c» bermellon oscuro; marcas del esmalte igual de oscuras
   "#ck.ck3d-on .dialnum{fill:#17100A;font-weight:700}#ck.ck3d-on .dialtitle{fill:#4A3410}#ck.ck3d-on .dialread{fill:#17100A}" +
   "#ck.ck3d-on .dialnum.lux{fill:#9C2716}#ck.ck3d-on line[stroke='#2A1F15'],#ck.ck3d-on circle[stroke='#2A1F15']{stroke:#17100A}" +
   // los rotulos de oro sobre la chapa: filo de sombra abajo-derecha (luz de arriba-izquierda, como el render); Nº XLII en laton claro
   "#ck.ck3d-on .eng{text-shadow:.55px .55px 0 rgba(0,0,0,.6)}#ck.ck3d-on #serialTxt{fill:#C99A3A !important}" +
   "#ck.ck3d-on use{filter:drop-shadow(.9px 1.1px 0 rgba(0,0,0,.27))}" +
   // LENTO · RAPIDO 4 unidades mas abajo: el arco renderizado (el de PixInsight, centrado en el eje) acaba donde hoy caen las letras
   "#ck.ck3d-on .k3-dn4{transform:translate(0,4px)}";
// una pieza: <image> vacio (se rellena al llegar los datos) en el grupo de la pieza (origen = el centro de «piece»). sx, sy: escala
// (la radio de la web es la de PixInsight a 1/0,85; la placa de la cruceta, ±56 frente a ±54)
function fwK3(name, parent, piece, sx, sy, cls, glass) {
   if (!FW_CK3D) return null;
   var a = { "class": "ck3dimg" + (cls ? " " + cls : ""), "data-k3": name, "data-c": piece, "data-sx": sx || 1, "data-sy": sy || sx || 1, preserveAspectRatio: "none" };
   if (glass) a["pointer-events"] = "none";
   var im = fwEl("image", a, parent); FW_CK3D_IMGS.push(im); return im;
}
// la geometria dibujada que la cabina 3D sustituye (se oculta cuando llegan los sprites)
function fw2d(a) { if (FW_CK3D) a["class"] = (a["class"] ? a["class"] + " " : "") + "ck2d"; return a; }
function fwCk3dNeed() { var s = document.getElementById("ck"); if (!s) return 1; var r = s.getBoundingClientRect(); return Math.min(r.width / (typeof fvGwarpUi === "function" && fvGwarpUi() ? FW_CK_GW_W : 960), r.height / 124) * (window.devicePixelRatio || 1); }
function fwCk3dPick(need) { for (var i = 0; i < FW_CK3D_LV.length; ++i) if (parseFloat(FW_CK3D_LV[i]) >= need - 1e-6) return FW_CK3D_LV[i]; return FW_CK3D_LV[FW_CK3D_LV.length - 1]; }
function fwCk3dAsk(lv) {
   if (FW_CK3D_CUR && parseFloat(FW_CK3D_CUR) >= parseFloat(lv)) return;
   if (typeof FW_CK3D_DATA === "object" && FW_CK3D_DATA && FW_CK3D_DATA[lv]) { fwCk3dLoaded(lv); return; }
   if (FW_CK3D_ASKED[lv]) return; FW_CK3D_ASKED[lv] = true;
   var s = document.createElement("script"); s.src = "fw_ck3d_s" + lv + ".js"; s.async = true;
   s.onerror = function() { try { console.warn("[ck3d] no se pudo cargar fw_ck3d_s" + lv + ".js: queda la cabina dibujada"); } catch (e) {} };
   document.head.appendChild(s);
}
// lo llama cada fw_ck3d_s<nivel>.js al cargarse: coloca los sprites y enciende la cabina 3D
function fwCk3dLoaded(lv) {
   var D = (typeof FW_CK3D_DATA === "object" && FW_CK3D_DATA) ? FW_CK3D_DATA[lv] : null;
   if (!D || !FW_CK3D || (FW_CK3D_CUR && parseFloat(FW_CK3D_CUR) >= parseFloat(lv))) return;
   for (var i = 0; i < FW_CK3D_IMGS.length; ++i) {
      var im = FW_CK3D_IMGS[i], m = D.sprites[im.getAttribute("data-k3")]; if (!m) continue;
      var C = FW_CK3D_C[im.getAttribute("data-c")], sx = +im.getAttribute("data-sx"), sy = +im.getAttribute("data-sy"), s = D.scale;
      im.setAttribute("x", ((m.g[0] - C[0] - m.a[0] / s) * sx).toFixed(3)); im.setAttribute("y", ((m.g[1] - C[1] - m.a[1] / s) * sy).toFixed(3));
      im.setAttribute("width", (m.w / s * sx).toFixed(3)); im.setAttribute("height", (m.h / s * sy).toFixed(3));
      im.setAttribute("href", m.src);
   }
   FW_CK3D_CUR = lv;
   var svg = document.getElementById("ck"); if (svg) { svg.classList.add("ck3d-on"); svg.setAttribute("data-ck3d", lv); }
}

function FWCockpit(root, scene, hooks) {
   this.scene = scene; this.hooks = hooks || {}; var self = this;
   this.root = root;
   if (FW_CK3D && !document.getElementById("ck3dCss")) { var cs = document.createElement("style"); cs.id = "ck3dCss"; cs.textContent = FW_CK3D_CSS; document.head.appendChild(cs); }
   // ---------------- la botonera ----------------
   var left = document.getElementById("left"); this.btn = {};
   for (var i = 0; i < FW_BTNS.length; ++i) (function(d) {
      var b = document.createElement("button"); b.className = "brassbtn" + (d.off ? " off" : ""); b.id = "btn-" + d.id;
      b.title = fwTr(d.tip[0], d.tip[1]);
      b.setAttribute("aria-label", fwTr(d.en, d.es));
      // (S1) laton claro: bisel estriado (72 marcas finas), filete oscuro, esfera de laton pulido con filete grabado interior; el aro «halo»
      // solo se ve al pasar (oro claro) y encendido. Los colores y degradados en fw_viewer.css / index.html (g-btnBezel, g-btnFace)
      var s = fwEl("svg", { viewBox: "-30 -30 60 60" }, b);
      fwEl("circle", { r: 28.5, class: "bezel" }, s);
      for (var k = 0; k < 72; ++k) { var p = fwPol(28.3, k * 5), q = fwPol(27.1, k * 5); fwEl("line", { x1: p[0].toFixed(2), y1: p[1].toFixed(2), x2: q[0].toFixed(2), y2: q[1].toFixed(2), class: "tick" }, s); }
      fwEl("circle", { r: 28.4, class: "ring" }, s);
      fwEl("circle", { r: 26, class: "face" }, s);
      fwEl("circle", { r: 26, class: "ring" }, s);
      fwEl("circle", { r: 24.4, class: "ring2" }, s);
      fwEl("circle", { r: 29.3, class: "halo" }, s);
      var ic = fwEl("g", { class: "icon", fill: "none", stroke: "currentColor", "stroke-linecap": "round", "stroke-linejoin": "round", transform: "scale(1.04)" }, s);
      fwIcon(ic, d.id);
      var lab = document.createElement("div"); lab.className = "btnlab"; lab.textContent = fwTr(d.en, d.es); fwBtnLabel(lab);
      var wrap = document.createElement("div"); wrap.className = "btnwrap"; wrap.appendChild(b); wrap.appendChild(lab); left.appendChild(wrap);
      b.addEventListener("click", function(ev) { ev.stopPropagation(); if (!b.classList.contains("off") && !b.disabled && self.hooks.button) self.hooks.button(d.id); });
      ["pointerdown", "dblclick", "wheel"].forEach(function(t) { b.addEventListener(t, function(ev) { ev.stopPropagation(); }, { passive: true }); });
      self.btn[d.id] = b;
   })(FW_BTNS[i]);
   // ---------------- la franja ----------------
   var svg = document.getElementById("ck"); this.svg = svg;
   // (21-nov, N-galaxias-warp; FV_GWARP) sin la placa MODUS (centro 906, ±26) el cuadro de mandos acaba en la radio (846): el viewBox se estrecha a FW_CK_GW_W y MIRABILIA gana ese hueco (body.gw, fw_viewer.css: 17 -> 22 unidades de ancho)
   if (typeof fvGwarpUi === "function" && fvGwarpUi()) { svg.setAttribute("viewBox", "0 0 " + FW_CK_GW_W + " 124"); document.body.classList.add("gw"); }
   var gV = fwEl("g", { transform: "translate(110,58)" }, svg), gD = fwEl("g", { transform: "translate(220,58)" }, svg), gT = fwEl("g", { transform: "translate(330,58)" }, svg);
   // (F3c) VELOCITAS en multiplos de c (logaritmica, 0 parado); CHRONOMETRUM = el año en que salio la luz que ves (anno lucis): la aguja
   // corta da los milenios (XII = 12 000 años), la larga los siglos, el segundero pequeño el tiempo de a bordo
   this.gV = fwWatch(gV, FW_E9 ? { r: 38, a0: -120, a1: 120, labels: ["0", "c", "10⁴", "10⁸", "10¹²"], minor: 48, title: "× c", caption: "VELOCITAS", lux: true }
                               : { r: 38, a0: -120, a1: 120, labels: ["1", "10³", "10⁶", "10⁹", "10¹²"], minor: 48, title: "× c", caption: "VELOCITAS" });
   this.gD = fwWatch(gD, { r: 38, a0: -120, a1: 120, labels: ["I", "X", "C", "M", "X̅"], minor: 40, title: "a Terra", caption: "DISTANTIA" });
   this.gT = fwWatch(gT, { r: 38, a0: 0, a1: 360, full: true, labels: ["XII", "", "", "III", "", "", "", "", "", "IX", "", ""], minor: 60, hands: [20, 30], sub: true, crown: true, title: "anno lucis", caption: "CHRONOMETRUM" });
   fwTip(gV, fwTr("VELOCITAS: the camera's speed in multiples of the speed of light (logarithmic; 0 when still). The trip is compressed: a fiction for the eye.", "VELOCITAS: la velocidad de la cámara en múltiplos de la velocidad de la luz (escala logarítmica; 0 parada). El viaje va comprimido: es ficción para el ojo."));
   fwTip(gD, fwTr("DISTANTIA: the camera's distance to the Earth, in light years (logarithmic: I, X, C, M, X̅ = 1 to 10 000).", "DISTANTIA: la distancia de la cámara a la Tierra en años luz (logarítmica: I, X, C, M, X̅ = de 1 a 10 000)."));
   fwTip(gT, fwTr("CHRONOMETRUM: the year in which the light you are seeing now left the object you are travelling to (or the nebula), from where the camera is. It runs as you travel; rounded to the error of the distance. Short hand: millennia (XII = 12 000 years); long hand: centuries.", "CHRONOMETRUM: el año en que salió la luz que ves ahora del objeto al que viajas (o de la nebulosa), desde donde está la cámara. Corre durante el viaje; redondeado al error de la distancia. Aguja corta: milenios (XII = 12 000 años); larga: siglos."));
   // placa (I4: con el mando AETAS a su izquierda la placa se estrecha a ±80 y se corre a 491 (a ±70 el subtitulo en mayusculas pisaba los remaches, visto en nI4_web_menos50000.png); FW_I4 = false: la de antes)
   var PX = FW_I4 ? 491 : 480, PW = FW_PAD ? FW_PAD_HW : (FW_I4 ? 80 : 92);
   var pl = fwEl("g", { transform: "translate(" + PX + ",54)", id: "plateG" }, svg);
   fwK3("pad_plate", pl, "plate", PW / 54, 1);                                  // (1c) placa, remaches y cubo: sprite (la de PixInsight mide ±54)
   fwEl("rect", fw2d({ x: -PW, y: -24, width: 2 * PW, height: 48, rx: 4, fill: "#1B140E", stroke: "url(#g-brass)", "stroke-width": 1.2 }), pl);
   fwEl("rect", fw2d({ x: -(PW - 6), y: -18, width: 2 * (PW - 6), height: 36, rx: 2, fill: "none", stroke: "#5E4214", "stroke-width": 0.8 }), pl);
   [[-(PW - 12), -12], [PW - 12, -12], [-(PW - 12), 12], [PW - 12, 12]].forEach(function(c) { fwEl("circle", fw2d({ cx: c[0], cy: c[1], r: 2, fill: "url(#g-crown)" }), pl); });
   if (FW_PAD) this.padBuild(pl);                  // (5-nov) la cruceta ocupa el hueco del rotulo
   else {
      // (21-nov, P5) sin subtitulo de marca: solo el nombre del script, centrado en la placa
      var t1 = fwEl("text", { y: 3, "text-anchor": "middle", class: "eng", style: "font-size:" + (FW_I4 ? 10.5 : 12) + "px;letter-spacing:" + (FW_I4 ? ".16em" : ".18em") }, pl); t1.textContent = "FIELDVOYAGER";
   }
   // numero de serie (guiño: 42) y la pestaña de idioma EN · ES bajo la placa, como en PixInsight (F2)
   var ser = fwEl("text", { x: FW_I4 ? PX - PW + 2 : 390, y: 89, class: "eng", style: "font-size:6.4px;letter-spacing:.2em;fill:#9C7325", id: "serialTxt" }, svg); ser.textContent = "Nº XLII";
   var lg = fwEl("text", { x: FW_I4 ? PX + PW - 22 : 550, y: 89, "text-anchor": "middle", class: "eng", style: "font-size:6.6px;letter-spacing:.2em;cursor:pointer", id: "langTab" }, svg);
   var tEN = fwEl("tspan", { fill: FW_LANG === "es" ? "#9C7325" : "#E5B53F" }, lg); tEN.textContent = "EN";
   var tDot = fwEl("tspan", { fill: "#9C7325" }, lg); tDot.textContent = " · ";
   var tES = fwEl("tspan", { fill: FW_LANG === "es" ? "#E5B53F" : "#9C7325" }, lg); tES.textContent = "ES";
   var lt = fwEl("title", {}, lg); lt.textContent = fwTr("Language: English · Español", "Idioma: English · Español");
   lg.addEventListener("click", function() { var to = FW_LANG === "es" ? "en" : "es", u = location.href.replace(/([?&])lang=(en|es)&?/, "$1").replace(/[?&]$/, ""); location.href = u + (u.indexOf("?") >= 0 ? "&" : "?") + "lang=" + to; });
   if (FW_I4) this.aetasBuild(svg);
   if (FW_PS_ON) this.lookBuild(svg, PX);          // (5-nov) STELLAE: GAIA · COLOR · FOTO bajo la placa
   this.station = fwEl("text", { x: PX, y: 104, "text-anchor": "middle", class: "read", style: "font-size:9px" }, svg);
   // regulador
   var rg = fwEl("g", { transform: "translate(640,83)" }, svg);
   fwK3("reg_face", rg, "reg");                                                 // (1c) arco y marcas en relieve: sprite (eje en el pivote)
   fwEl("path", fw2d({ d: "M -46 -6 A 48 48 0 0 1 46 -6", fill: "none", stroke: "url(#g-brass)", "stroke-width": 6 }), rg);
   fwEl("path", fw2d({ d: "M -46 -6 A 48 48 0 0 1 46 -6", fill: "none", stroke: "#3B2A0C", "stroke-width": 0.6 }), rg);
   // (N2, punto 8 de Nino) la palanca es la VELOCIDAD DEL VIAJE (cine y warp): marcas LENTO · RAPIDO y una marca larga en el centro (la de
   // siempre). Se arrastra (como en PixInsight, fv_cockpit.js); la aguja roja fina lee lo que da el motor ahora. Lo recordado: FW.speed
   [0, 1, 2, 3, 4, 5, 6].forEach(function(i) { var a = -62 + 124 * i / 6, p = fwPol(48, a), q = fwPol(i === 3 ? 61 : (i % 3 === 0 ? 59 : 56), a); fwEl("line", fw2d({ x1: p[0], y1: p[1] - 4, x2: q[0], y2: q[1] - 4, stroke: i === 3 ? "#E5B53F" : "#C99A3A", "stroke-width": i === 3 ? 1.3 : 0.8 }), rg); });
   [["SLOW", "LENTO", -62], ["FAST", "RÁPIDO", 62]].forEach(function(m) { var p = fwPol(48, m[2]), t = fwEl("text", { x: p[0] + (m[2] < 0 ? -1 : 1), y: p[1] + 7, "text-anchor": "middle", class: "eng" + (FW_CK3D ? " k3-dn4" : ""), style: "font-size:6.2px;letter-spacing:.1em" }, rg); t.textContent = fwTr(m[0], m[1]); });
   this.regNeedle = fwEl("line", { x1: 0, y1: 0, x2: 0, y2: -47, stroke: "#E0603F", "stroke-width": 1.2, "stroke-linecap": "round", opacity: 0 }, rg);
   this.lever = fwEl("g", { style: "cursor:grab" }, rg);
   fwEl("line", { x1: 0, y1: 0, x2: 0, y2: -50, stroke: "#C99A3A", "stroke-width": 3.5, "stroke-linecap": "round" }, this.lever);
   fwEl("circle", fw2d({ cy: -53, r: 5.5, fill: "url(#g-crown)" }), this.lever); fwEl("rect", fw2d({ x: -2, y: -48, width: 4, height: 6, fill: "#3B2A0C" }), this.lever);
   fwK3("reg_knob", this.lever, "reg");                                         // (1c) el pomo renderizado gira con la palanca
   fwEl("circle", fw2d({ r: 6, fill: "url(#g-crown)" }), rg); fwK3("reg_hub", rg, "reg");
   // (F3c) «REGULATOR» se leia como ingles: IMPETUS (latin, como VELOCITAS o DISTANTIA)
   var rc = fwEl("text", { y: 20, "text-anchor": "middle", class: "eng", style: "font-size:7.5px;letter-spacing:.24em" }, rg); rc.textContent = "IMPETUS";
   fwTip(rg, fwTr("IMPETUS: travel speed, for CINEMA, WARP and the camera route: the whole trip (setting off, cruise, braking and the warp jump). Drag the lever from SLOW to FAST (the middle is the default speed; it is remembered). The thin red needle shows what the engine is giving now.", "IMPETUS: velocidad del viaje, para CINE, WARP y la ruta de cámaras: todo el viaje (arranque, crucero, frenada y el salto del warp). Arrastra la palanca de LENTO a RÁPIDO (el centro es la velocidad por defecto; se recuerda). La aguja roja fina marca lo que da el motor ahora."));
   // arrastrar la palanca: el angulo del puntero respecto al eje (0, 0) del cuadrante, en coordenadas del propio grupo
   this.speed = 0.5; this.speedDrag = false;
   var svgEl = svg, speedFrom = function(e) {
      var m = rg.getScreenCTM(); if (!m) return null; var pt = svgEl.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; var q = pt.matrixTransform(m.inverse());
      return fvClamp((Math.atan2(q.x, -q.y) * 180 / Math.PI + 62) / 124, 0, 1);
   };
   rg.addEventListener("pointerdown", function(e) { if (e.button !== 0) return; var s = speedFrom(e); if (s === null) return; self.speedDrag = true; try { rg.setPointerCapture(e.pointerId); } catch (x) {} e.stopPropagation(); self.setSpeed(s, true); });
   rg.addEventListener("pointermove", function(e) { if (!self.speedDrag) return; var s = speedFrom(e); if (s !== null) self.setSpeed(s, true); });
   rg.addEventListener("pointerup", function(e) { if (!self.speedDrag) return; self.speedDrag = false; try { rg.releasePointerCapture(e.pointerId); } catch (x) {} self.setSpeed(self.speed, true, true); });
   // radio
   var ra = fwEl("g", { transform: "translate(800,56)" }, svg); this.radioG = ra;
   fwK3("radio_face", ra, "radio", 1 / 0.85);                                   // (1c) bisel moleteado y esmalte: sprite (PixInsight la pinta a 0,85)
   fwEl("circle", fw2d({ r: 43, fill: "url(#g-brass)" }), ra);
   for (var k2 = 0; k2 < 90; k2++) { var p2 = fwPol(43, k2 * 4), q2 = fwPol(40.5, k2 * 4); fwEl("line", fw2d({ x1: p2[0], y1: p2[1], x2: q2[0], y2: q2[1], stroke: "#5E4214", "stroke-width": 0.8 }), ra); }
   fwEl("circle", fw2d({ r: 38, fill: "url(#g-enamel)" }), ra);
   // (F3c) ESCALA FIJA y AGUJA que la recorre (en una radio antigua gira la aguja, no los numeros: la escala que giraba dejaba cifras boca abajo)
   this.disk = fwEl("g", {}, ra);
   for (var f = 0; f <= 100; f += 2) { var a = -150 + f * 3, pp = fwPol(36, a), qq = fwPol(f % 10 ? 33.5 : 31, a); fwEl("line", { x1: pp[0], y1: pp[1], x2: qq[0], y2: qq[1], stroke: "#2A1F15", "stroke-width": f % 10 ? 0.4 : 0.9 }, this.disk); if (f % 20 === 0) { var pt = fwPol(24, a), tt = fwEl("text", { x: pt[0], y: pt[1] + 2.5, "text-anchor": "middle", class: "dialnum", style: "font-size:7px" }, this.disk); tt.textContent = f; } }
   this.stationDots = fwEl("g", {}, this.disk);
   this.needle = fwEl("g", {}, ra);
   fwEl("line", { x1: 0, y1: 4, x2: 0, y2: -35, stroke: "#B8401F", "stroke-width": 1.1, "stroke-linecap": "round" }, this.needle);
   fwEl("path", { d: "M 0 -36.5 L -1.6 -31 L 1.6 -31 Z", fill: "#B8401F" }, this.needle);
   // (1c) el mando renderizado queda QUIETO, como en PixInsight: girado, su luz y su sombra daban vueltas (la aguja ya dice la sintonia).
   // El grupo que gira conserva un circulo invisible para que se pueda seguir arrastrando
   fwK3("radio_knob", ra, "radio", 1 / 0.85);
   this.knob = fwEl("g", { style: "cursor:grab" }, ra);
   if (FW_CK3D) fwEl("circle", { r: 13, fill: "none", "pointer-events": "all", "class": "k3-hit" }, this.knob);
   fwTip(this.knob, fwTr("Turn the knob to tune: each of your tracks is a station on the scale.", "Gira el mando para sintonizar: cada pista tuya es una emisora de la escala."));
   fwEl("circle", fw2d({ r: 13, fill: "url(#g-brass)" }), this.knob);
   for (var k3 = 0; k3 < 24; k3++) { var p3 = fwPol(13, k3 * 15), q3 = fwPol(10.5, k3 * 15); fwEl("line", fw2d({ x1: p3[0], y1: p3[1], x2: q3[0], y2: q3[1], stroke: "#3B2A0C", "stroke-width": 1 }), this.knob); }
   fwEl("circle", fw2d({ r: 9, fill: "url(#g-crown)" }), this.knob);
   fwEl("circle", fw2d({ r: 38, fill: "url(#g-glass)", "pointer-events": "none" }), ra); fwK3("radio_glass", ra, "radio", 1 / 0.85, 0, "", true);
   // (F3c) el UNICO interruptor de la radio: la lampara con su engaste (un solo camino para encender, §11.5)
   this.lampSw = fwEl("g", { style: "cursor:pointer", id: "radioPower" }, ra);
   fwEl("circle", fw2d({ cx: -50, cy: -30, r: 6.2, fill: "url(#g-brass)" }), this.lampSw); fwEl("circle", fw2d({ cx: -50, cy: -30, r: 4.8, fill: "#2A1D08" }), this.lampSw);
   fwK3("radio_lamp_off", this.lampSw, "radio", 1 / 0.85);
   if (FW_CK3D) { this.lamp = fwEl("g", { opacity: 0.16 }, this.lampSw); fwEl("circle", fw2d({ cx: -50, cy: -30, r: 4, fill: "#E5B53F" }), this.lamp); fwK3("radio_lamp_on", this.lamp, "radio", 1 / 0.85); }   // (1c) fw_radio.js gradua la opacidad del grupo
   else this.lamp = fwEl("circle", { cx: -50, cy: -30, r: 4, fill: "#E5B53F", opacity: 0.16 }, this.lampSw);
   this.lampHalo = fwEl("circle", { cx: -50, cy: -30, r: 11, fill: "#E5B53F", opacity: 0, "pointer-events": "none" }, ra);
   this.lampTip = fwTip(this.lampSw, fwTr("Switch the radio on or off", "Encender o apagar la radio"));
   var c2 = fwEl("text", { y: 56, "text-anchor": "middle", class: "eng", style: "font-size:7.5px;letter-spacing:.24em;cursor:pointer" }, ra); c2.textContent = "RADIOPHONIA"; this.radioCap = c2;
   fwTip(c2, fwTr("Stations: the ten on-board stations, volume and your own tracks · wheel on the knob: volume", "Emisoras: las diez de a bordo, el volumen y tus pistas · rueda sobre el mando: volumen"));
   // MODUS (F2): placa con ranura, CINE arriba y WARP abajo; la palanca dice el estilo de camara del motor (fvPilotSetStyle)
   // (21-nov, N-galaxias-warp; FV_GWARP) sin selector: el modo lo elige el destino (fvTravelKind); ni placa MODUS ni palanca ni clic
   if (!fvGwarpUi()) {
   var md = fwEl("g", { transform: "translate(906,52)", style: "cursor:pointer", id: "modeSwitch" }, svg); this.modeG = md;
   fwK3("modus_plate", md, "modus");                                            // (1c) placa y ranura: sprite
   fwEl("rect", fw2d({ x: -22, y: -34, width: 44, height: 68, fill: "#1B140E", stroke: "url(#g-brass)", "stroke-width": 1.2 }), md);
   fwEl("rect", fw2d({ x: -18, y: -30, width: 36, height: 60, fill: "none", stroke: "#5E4214", "stroke-width": 0.7 }), md);
   fwEl("rect", fw2d({ x: -2.5, y: -20, width: 5, height: 40, fill: "#07060A" }), md);
   var mc = fwEl("text", { y: -23, "text-anchor": "middle", class: "eng", style: "font-size:6.6px;letter-spacing:.2em" }, md); mc.textContent = fwTr("CINEMA", "CINE");
   var mw = fwEl("text", { y: 31, "text-anchor": "middle", class: "eng", style: "font-size:6.6px;letter-spacing:.2em" }, md); mw.textContent = "WARP";
   this.modeLever = fwEl("line", fw2d({ x1: 0, y1: 0, x2: 0, y2: -13, stroke: "#C99A3A", "stroke-width": 3, "stroke-linecap": "round" }), md);
   fwEl("circle", fw2d({ r: 4, fill: "url(#g-crown)" }), md);
   this.modeKnob = fwEl("circle", fw2d({ cy: -13, r: 5.5, fill: "url(#g-crown)" }), md);
   fwK3("modus_lever_up", md, "modus", 1, 1, "k3-up"); fwK3("modus_lever_down", md, "modus", 1, 1, "k3-down"); if (FW_CK3D) md.setAttribute("data-up", "1");   // (1c) la palanca renderizada
   var mcap = fwEl("text", { y: 50, "text-anchor": "middle", class: "eng", style: "font-size:7.5px;letter-spacing:.24em" }, md); mcap.textContent = "MODUS";
   var mt = fwEl("title", {}, md); mt.textContent = fwTr("CINEMA: smooth cinematic camera (slow ease, rise-cross-descend path, soft effects) · WARP: spectacular (snap, streaks, flash, 105°, vertigo, close fly-by)", "CINE: cámara suave de cine (aceleración lenta, camino sube-cruza-baja, efectos discretos) · WARP: espectacular (arranque brusco, estelas, destello, 105°, vértigo, paso rasante)");
   md.addEventListener("click", function() { if (self.hooks.mode) self.hooks.mode(); });
   }
   // grabar (a la izquierda de VELOCITAS): reloj fijo t = n/fps
   var rec = fwEl("g", { transform: "translate(36,52)", style: "cursor:pointer", id: "recBtn" }, svg); this.recG = rec;
   fwK3("rec_face", rec, "rec"); fwK3("rec_gem_red", rec, "rec", 1, 1, "k3-gem"); if (FW_CK3D) rec.setAttribute("data-on", "0");   // (1c) engaste y cabujon renderizados
   fwEl("circle", fw2d({ r: 12, fill: "url(#g-brass)" }), rec); this.recLamp = fwEl("circle", fw2d({ r: 7, fill: "#5A1E12" }), rec);
   this.recLabel = fwTr("REC", "GRABAR");
   this.recTxt = fwEl("text", { y: 26, "text-anchor": "middle", class: "eng", style: "font-size:6.6px;letter-spacing:.16em" }, rec); this.recTxt.textContent = this.recLabel;
   var rt = fwEl("title", {}, rec); rt.textContent = fwTr("Record a video with a fixed clock (t = n/fps): frames are never dropped. Click again to stop and save the MP4.", "Grabar vídeo con reloj fijo (t = n/fps): no se pierde ningún fotograma. Otro clic para y guarda el MP4.");
   rec.addEventListener("click", function() { if (self.hooks.rec) self.hooks.rec(); });
   // ---------------- la ficha y la leyenda ----------------
   this.card = document.getElementById("card"); this.cardCanvas = document.getElementById("cardStar"); this.cardText = document.getElementById("cardText");
   this.legend = document.getElementById("legend");
   this.hud = document.getElementById("hud"); this.hctx = this.hud.getContext("2d");
   this.cardLines = null; this.cardSel = null; this.cardHidden = false;
   // (6-nov, FV_TOUR_READ) el cursor sobre la ficha para la espera del TOUR (fw_viewer.js fwTourStep)
   this.card.addEventListener("pointerenter", function() { if (typeof FW !== "undefined") FW.cardHover = true; });
   this.card.addEventListener("pointerleave", function() { if (typeof FW !== "undefined") FW.cardHover = false; });
   var cc = document.getElementById("cardClose");
   if (cc) { cc.title = fwTr("Close the card", "Cerrar la ficha"); cc.setAttribute("aria-label", cc.title); cc.addEventListener("click", function(e) { e.stopPropagation(); if (self.hooks.cardClose) self.hooks.cardClose(); });
             ["pointerdown", "pointerup", "dblclick"].forEach(function(t) { cc.addEventListener(t, function(e) { e.stopPropagation(); }); }); }
   // (1c) el nivel de sprites que pide esta pantalla; si la ventana crece (o pasa a otra pantalla), el siguiente
   if (FW_CK3D) { fwCk3dAsk(fwCk3dPick(fwCk3dNeed())); window.addEventListener("resize", function() { fwCk3dAsk(fwCk3dPick(fwCk3dNeed())); }); }
}

// ---------------------------------------------------------------------------
// (I4, Nino 4-nov: «máquina del tiempo, al lado de CHRONOMETRUM») EL MANDO AETAS, gemelo del de PixInsight (src/ui/fv_cockpit.js): placa de
// laton con ranura, palanca deslizante (arriba + = futuro, abajo − = pasado, muesca dorada = hoy), lectura del año debajo (clic = hoy)
// y el rotulo a la altura del de los relojes. El motor es engine/fv_time.js (fvTimeApply) a traves de fw_time.js (fwTimeSet). La lectura
// vive SOLO aqui: CHRONOMETRUM sigue diciendo el año de la luz que ves. FW_I4 = false: la cabina de antes (el ROJO de fv_nI4_cdp).
// ---------------------------------------------------------------------------
var FW_I4 = true;
// (5-nov, Nino: «elimina el letrero de Field Voyager y añade en su lugar 4 flechas: mueven la vista arriba, abajo, izquierda y derecha») LA CRUCETA,
// gemela de la de PixInsight (src/ui/fv_cockpit.js, padFace/padPaint): cuatro teclas de laton con su flecha grabada y un cubo de brujula, en el
// hueco de la placa (que se estrecha de ±80 a ±FW_PAD_HW y pierde su rotulo). Giran la MIRADA sin avanzar (clic = un paso, mantener = giro
// continuo; motor: fvPilotLookPad); la flecha se apaga cuando la pared de la foto no deja girar a ese lado. FW_PAD = false: el rotulo de antes.
var FW_PAD = true, FW_PAD_HW = 56;
var FW_PAD_K = { up: [-7, -16, 7, -8], down: [-7, 8, 7, 16], left: [-32, -4.5, -18, 4.5], right: [18, -4.5, 32, 4.5] };
var FW_PAD_TIP = {
   left: ["VIEW · left: turn the camera's view to the left without moving. One click = one step; hold = keep turning. The same as the ← key (or A). If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
          "VISTA · izquierda: gira la mirada a la izquierda sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla ← (o A). Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella."],
   right: ["VIEW · right: turn the camera's view to the right without moving. One click = one step; hold = keep turning. The same as the → key (or D). If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
           "VISTA · derecha: gira la mirada a la derecha sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla → (o D). Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella."],
   up: ["VIEW · up: turn the camera's view up without moving. One click = one step; hold = keep turning. The same as the Page Up key. If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
        "VISTA · arriba: gira la mirada hacia arriba sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla RePág. Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella."],
   down: ["VIEW · down: turn the camera's view down without moving. One click = one step; hold = keep turning. The same as the Page Down key. If you move forward afterwards (wheel forward, W, ↑) you go where you are looking. The arrow dims when you have reached the edge of your photo on that side: the ship never shows what lies outside it.",
          "VISTA · abajo: gira la mirada hacia abajo sin moverte. Un clic = un paso; mantén pulsado = giro continuo. Es lo mismo que la tecla AvPág. Si avanzas después (rueda hacia delante, W, ↑), vas hacia donde miras. La flecha se apaga cuando has llegado al borde de tu foto por ese lado: la nave nunca enseña lo que hay fuera de ella."]
};
// el cubo de brujula y las cuatro teclas, dentro del grupo de la placa (centro = 0, 0)
FWCockpit.prototype.padBuild = function(pl) {
   var self = this, i, h = 5.2; this.padKeys = {};
   fwEl("circle", fw2d({ r: h, fill: "url(#g-brass)", stroke: "#3B2A0C", "stroke-width": 0.8 }), pl);       // (1c) el cubo va en el sprite de la placa
   fwEl("circle", fw2d({ r: h - 1.4, fill: "none", stroke: "#5E4214", "stroke-width": 0.5 }), pl);
   fwEl("circle", fw2d({ r: 1.5, fill: "url(#g-crown)" }), pl);
   for (i = 0; i < 4; ++i) { var p = fwPol(h - 0.6, i * 90), q = fwPol(h - 2.4, i * 90); fwEl("line", fw2d({ x1: p[0].toFixed(2), y1: p[1].toFixed(2), x2: q[0].toFixed(2), y2: q[1].toFixed(2), stroke: "#3B2A0C", "stroke-width": 0.6 }), pl); }
   ["up", "down", "left", "right"].forEach(function(d) {
      var r = FW_PAD_K[d], cx = (r[0] + r[2]) / 2, cy = (r[1] + r[3]) / 2, g = fwEl("g", { id: "pad" + d.charAt(0).toUpperCase() + d.substring(1), class: "padkey", style: "cursor:pointer;touch-action:none" }, pl);
      var rc = fwEl("rect", fw2d({ x: r[0], y: r[1], width: r[2] - r[0], height: r[3] - r[1], fill: "url(#g-brass)", stroke: "#3B2A0C", "stroke-width": 0.9 }), g);
      fwEl("line", fw2d({ x1: r[0] + 0.9, y1: r[1] + 0.9, x2: r[2] - 0.9, y2: r[1] + 0.9, stroke: "#F3D27E", "stroke-width": 0.5, opacity: 0.55 }), g);
      ["rest", "lit", "off"].forEach(function(s) { fwK3("pad_" + d + "_" + s, g, "plate", 1, 1, "k3s k3-" + s); });   // (1c) la tecla por estado (data-state la elige)
      var T = d === "up" ? [[0, -3.4], [-3.8, 2.2], [3.8, 2.2]] : d === "down" ? [[0, 3.4], [-3.8, -2.2], [3.8, -2.2]] : d === "left" ? [[-3.6, 0], [2.0, -3.1], [2.0, 3.1]] : [[3.6, 0], [-2.0, -3.1], [-2.0, 3.1]];
      function pts(dx, dy) { return T.map(function(t) { return (cx + t[0] + dx).toFixed(2) + "," + (cy + t[1] + dy).toFixed(2); }).join(" "); }
      fwEl("polygon", fw2d({ points: pts(0.4, 0.4), fill: "#FFF3C4", opacity: 0.56 }), g);
      fwEl("polygon", fw2d({ points: pts(0, 0), fill: "#3B2A0C" }), g);
      var ring = fwEl("rect", { x: r[0] - 1, y: r[1] - 1, width: r[2] - r[0] + 2, height: r[3] - r[1] + 2, fill: "none", stroke: "#F3D27E", "stroke-width": 1.3, opacity: 0, "pointer-events": "none" }, g);
      var tip = fwTip(g, fwTr(FW_PAD_TIP[d][0], FW_PAD_TIP[d][1]));
      self.padKeys[d] = { g: g, rect: rc, ring: ring, down: false, hover: false, on: false, ok: true };
      g.setAttribute("data-state", "idle");
      function press(e) { if (e.button !== undefined && e.button !== 0) return; e.stopPropagation(); e.preventDefault(); var k = self.padKeys[d]; if (k.down) return; k.down = true; try { g.setPointerCapture(e.pointerId); } catch (x) {} if (self.hooks.pad) self.hooks.pad(d, true); }
      function lift(e) { var k = self.padKeys[d]; if (!k.down) return; k.down = false; try { g.releasePointerCapture(e.pointerId); } catch (x) {} if (self.hooks.pad) self.hooks.pad(d, false); }
      g.addEventListener("pointerdown", press); g.addEventListener("pointerup", lift); g.addEventListener("pointercancel", lift);
      g.addEventListener("pointerenter", function() { self.padKeys[d].hover = true; self.padShow(d); }); g.addEventListener("pointerleave", function() { self.padKeys[d].hover = false; self.padShow(d); });
      ["dblclick", "wheel", "click"].forEach(function(t) { g.addEventListener(t, function(ev) { ev.stopPropagation(); }, { passive: true }); });
   });
   if (FW_PAD_BRAKE) this.hubBuild(pl, h);
};
// (6-nov, Nino: «el botón entre las flechas debe frenar la nave») EL FRENO en el cubo de brujula: pulsarlo para la nave con suavidad (motor:
// fvPilotBrake, escalado por el REGULATOR) y cancela cine, warp, ruta y tour. Mientras frena (gauges.brake > 0) el cubo se hunde y luce en oro.
// Gemelo de padHubPaint en src/ui/fv_cockpit.js. FW_PAD_BRAKE = false: el cubo vuelve a ser solo adorno.
var FW_PAD_BRAKE = true, FW_HUB_FLASH_MS = 350;
var FW_HUB_TIP = ["BRAKE: brings the ship smoothly to a stop and cancels any trip in progress (CINEMA, WARP, the camera route or the tour). The REGULATOR sets how long the braking takes: slow = gentle, fast = short.",
                  "FRENO: para la nave con suavidad y cancela el viaje en curso (CINE, WARP, la ruta de cámaras o el tour). El REGULATOR fija cuánto dura la frenada: lento = suave, rápido = corta."];
FWCockpit.prototype.hubBuild = function(pl, h) {
   var self = this, g = fwEl("g", { id: "padHub", class: "padhub", style: "cursor:pointer;touch-action:none" }, pl);
   fwEl("circle", { r: h + 1.2, fill: "#000", "fill-opacity": 0.001 }, g);                 // la zona de clic (algo mayor que el cubo)
   var lit = fwEl("g", { opacity: 0, "pointer-events": "none" }, g);
   fwEl("circle", { cx: 0.4, cy: 0.5, r: h - 0.6, fill: "url(#g-crown)", opacity: 0.9 }, lit);   // el cubo hundido medio punto, en oro
   fwEl("circle", { r: h + 0.4, fill: "none", stroke: "#FFF3C4", "stroke-width": 0.7, opacity: 0.85 }, lit);
   var ring = fwEl("circle", { r: h + 1.1, fill: "none", stroke: "#F3D27E", "stroke-width": 1.3, opacity: 0, "pointer-events": "none" }, g);
   fwTip(g, fwTr(FW_HUB_TIP[0], FW_HUB_TIP[1]));
   this.hub = { g: g, lit: lit, ring: ring, t: -1e9, b: 0, hover: false };
   g.setAttribute("data-state", "idle");
   g.addEventListener("pointerdown", function(e) { if (e.button !== undefined && e.button !== 0) return; e.stopPropagation(); e.preventDefault(); self.hub.t = fwCkNow(); self.hubShow(); if (self.hooks.pad) self.hooks.pad("brake", true); });
   g.addEventListener("pointerenter", function() { self.hub.hover = true; self.hubShow(); }); g.addEventListener("pointerleave", function() { self.hub.hover = false; self.hubShow(); });
   ["dblclick", "wheel", "click", "pointerup"].forEach(function(t) { g.addEventListener(t, function(ev) { ev.stopPropagation(); }, { passive: true }); });
};
FWCockpit.prototype.hubShow = function() {
   var H = this.hub; if (!H) return;
   var on = H.b > 0 || (fwCkNow() - H.t) < FW_HUB_FLASH_MS;
   fwSetA(H.lit, "opacity", on ? 1 : 0); fwSetA(H.ring, "opacity", (H.hover && !on) ? 1 : 0);
   H.g.setAttribute("data-state", on ? "on" : "idle");
};
// b = fvPilotGauges(P).brake (1 al pulsar, 0 parada)
FWCockpit.prototype.setHub = function(b) { if (!this.hub) return; this.hub.b = b || 0; this.hubShow(); };
FWCockpit.prototype.padShow = function(d) {
   var k = this.padKeys[d]; if (!k) return;
   fwSetA(k.rect, "fill", (k.on && k.ok) ? "#F3D27E" : "url(#g-brass)");
   fwSetA(k.g, "opacity", k.ok ? 1 : 0.38);
   fwSetA(k.ring, "opacity", (k.hover && k.ok) ? 1 : 0);
   k.g.setAttribute("data-state", !k.ok ? "off" : (k.on ? "on" : "idle"));
};
// st = fvPilotGauges(P).pad = { left, right, up, down: { ok, on } }
FWCockpit.prototype.setPad = function(st) {
   if (!this.padKeys || !st) return;
   for (var d in this.padKeys) { var k = this.padKeys[d], s = st[d]; if (!s) continue; if (k.on !== !!s.on || k.ok !== (s.ok !== false)) { k.on = !!s.on; k.ok = (s.ok !== false); this.padShow(d); } }
};
// (5-nov, Nino: «que las estrellas se vean como Gaia o como están en la imagen, como en los otros scripts») STELLAE: el aspecto de las estrellas,
// el mismo selector que la cabina de PixInsight (src/ui/fv_cockpit.js, lookGeom): una linea bajo la placa (y = 116, bajo la emisora), STELLAE en oro y
// GAIA · COLOR · FOTO (la puesta en oro, las que el paquete no trae apagadas). Un solo camino (§11.5). FW_PS_ON = false: la cabina de antes
var FW_PS_ON = true;
var FW_LOOK_TXT = [["gaia", "GAIA", "GAIA",
                   "STELLAE · GAIA: every star in the colour of its real TEMPERATURE, from Gaia (BP−RP / Teff), the same rule for all: blue-white the hot ones, orange-red the cool ones. Close to a star you see its colour without the dust. Not the colour of your photo (that is COLOUR). Remembered.",
                   "STELLAE · GAIA: todas las estrellas con el color de su TEMPERATURA real, la de Gaia (BP−RP / Teff), con la misma regla para todas: blanco azuladas las calientes, naranja rojizas las frías. Junto a una estrella ves su color sin el polvo. No es el color de tu foto (ese es COLOR). Se recuerda."],
                  ["phcol", "COLOUR", "COLOR",
                   "STELLAE · COLOUR: each star in the colour it has in YOUR photo (its core, sky subtracted, green removed). Stars the photo cannot measure take their Gaia temperature colour. The drawn star of the ship. Remembered.",
                   "STELLAE · COLOR: cada estrella con el color que tiene en TU foto (su núcleo, cielo restado, sin el verde). Las que la foto no deja medir toman el color de su temperatura de Gaia. La estrella dibujada de la nave. Se recuerda."],
                  ["phstar", "PHOTO", "FOTO",
                   "STELLAE · PHOTO: each star as it looks in YOUR photo (its own cut-out). Flying, it grows and dims like the drawn star and blends into the drawn star (COLOUR) when it would look magnified. Remembered.",
                   "STELLAE · FOTO: cada estrella como se ve en TU foto (su propio recorte). Al volar crece y se apaga como la estrella dibujada y se funde con la estrella dibujada (COLOR) cuando se vería ampliada. Se recuerda."]];
FWCockpit.prototype.lookBuild = function(svg, PX) {
   var self = this, t = fwEl("text", { x: PX, y: 116, "text-anchor": "middle", class: "eng", style: "font-size:6.2px;letter-spacing:.12em", id: "lookTab" }, svg);
   var cap = fwEl("tspan", { fill: "#E5B53F" }, t); cap.textContent = "STELLAE   ";
   this.lookSpans = {}; this.lookAvail = { gaia: true, phcol: false, phstar: false };
   FW_LOOK_TXT.forEach(function(o, i) {
      if (i) { var d = fwEl("tspan", { fill: "#9C7325" }, t); d.textContent = " · "; }
      var s = fwEl("tspan", { fill: "#9C7325", id: "look_" + o[0] }, t); s.textContent = fwTr(o[1], o[2]);
      var tt = fwEl("title", {}, s); tt.textContent = fwTr(o[3], o[4]); s._tip = tt;
      s.addEventListener("click", function(e) { e.stopPropagation(); if (self.lookAvail[o[0]] && self.hooks.look) self.hooks.look(o[0]); });
      self.lookSpans[o[0]] = s;
   });
};
// cur = el aspecto puesto; avail = { gaia, phcol, phstar } (lo que trae el paquete)
FWCockpit.prototype.setLook = function(cur, avail) {
   if (!this.lookSpans) return;
   if (avail) this.lookAvail = avail;
   for (var k in this.lookSpans) if (this.lookSpans.hasOwnProperty(k)) {
      var s = this.lookSpans[k], on = (k === cur), av = !!this.lookAvail[k];
      s.setAttribute("fill", on ? "#E5B53F" : (av ? "#9C7325" : "#4A3A20")); s.style.cursor = av ? "pointer" : "default";
      if (!av && s._tip && !s._tipNo) { s._tip.textContent += fwTr(" — not in this package (export it again from PixInsight).", " — no viene en este paquete (vuelve a exportarlo desde PixInsight)."); s._tipNo = true; }
   }
};
var FW_I4G = { X: 394, Y: 52, HW: 12, HH: 34, TRAVEL: 17 };
// (I3, 19-nov-2026, Nino: «El botón que hace mover las estrellas para delante y para atrás debe estar más visible y tiene que tener al lado una
// flecha play para arriba y otra play para abajo…») EL MANDO DEL TIEMPO VISIBLE, gemelo del de PixInsight (src/ui/fv_cockpit.js, FV_E1T): a la
// derecha de la ranura, dos botones redondos de laton (▲ reproduce hacia el futuro, ▼ hacia el pasado) que se encienden en oro y pasan a
// «pausa» mientras corren y se apagan en el tope; la ranura se llena de oro entre «hoy» y la palanca; la lectura crece (6,4 -> 7) y se
// centra en el conjunto. La ranura NO se mueve (AX = la X de I4: aqui hay 62 unidades entre CHRONOMETRUM y la cruceta, y correrla 3 hacia la esfera
// dejaba la sombra de su sprite a −0,4 px del bisel: tests/_e1t/fv_e1t_cdp.js W2). La reproduccion y las estelas: fw_time.js (FW_E1T; false = lo de antes).
var FW_E1TG = { AX: 394, KDX: 26.5, KR: 9, KY: 17, RDX: 10.5, READ_PX: 7, FR: 5.8 };      // (F2) FR: el radio del boton SOL | GALAXIA, entre ▲ y ▼
FWCockpit.prototype.aetasBuild = function(svg) {
   var self = this, G = FW_I4G, e1 = (typeof fwE1tOn === "function") && fwE1tOn(), rdx = e1 ? FW_E1TG.RDX : 0;
   var ae = fwEl("g", { transform: "translate(" + (e1 ? FW_E1TG.AX : G.X) + "," + G.Y + ")", id: "aetasG" }, svg);
   this.aetasG = ae; this.epoch = 0; this.epochDrag = false; this.e1t = e1;
   var box = fwEl("g", { id: "aetasLever", style: "cursor:grab" }, ae); this.aetasBox = box;
   fwK3("aetas_plate", box, "aetas");                                           // (1c) placa y ranura: sprite (las marcas, grabadas, siguen en SVG)
   fwEl("rect", fw2d({ x: -G.HW, y: -G.HH, width: 2 * G.HW, height: 2 * G.HH, fill: "#1B140E", stroke: "url(#g-brass)", "stroke-width": 1.2 }), box);
   fwEl("rect", fw2d({ x: -(G.HW - 4), y: -(G.HH - 4), width: 2 * (G.HW - 4), height: 2 * (G.HH - 4), fill: "none", stroke: "#5E4214", "stroke-width": 0.7 }), box);
   fwEl("rect", fw2d({ x: -2, y: -(G.TRAVEL + 1.5), width: 4, height: 2 * G.TRAVEL + 3, fill: "#07060A" }), box);
   var toS = (typeof fvTimeToS === "function") ? fvTimeToS : function(y) { return y / 1e5; };
   [1e3, 1e4, 1e5].forEach(function(m, k) { [-1, 1].forEach(function(sg) { var yy = (-sg * G.TRAVEL * toS(sg * m)).toFixed(2);
      fwEl("path", { d: "M -7 " + yy + " L -3.5 " + yy + " M 3.5 " + yy + " L 7 " + yy, stroke: "#C99A3A", "stroke-width": k === 2 ? 0.9 : 0.6 }, box); }); });
   fwEl("path", { d: "M -8.5 0 L -3 0 M 3 0 L 8.5 0", stroke: "#E5B53F", "stroke-width": 1.2 }, box);
   var tp = fwEl("text", { y: -(G.TRAVEL + 4), "text-anchor": "middle", class: "eng", style: "font-size:8px" }, box); tp.textContent = "+";
   var ta = fwEl("text", { y: G.TRAVEL + 11, "text-anchor": "middle", class: "eng", style: "font-size:8px" }, box); ta.textContent = "−";
   this.aetasFill = e1 ? fwEl("rect", { x: -1.5, y: 0, width: 3, height: 0, fill: "#E5B53F", "pointer-events": "none", id: "aetasFill" }, box) : null;      // (I3) la ranura, llena de oro entre «hoy» y la palanca
   this.aetasKnob = fwEl("g", { "pointer-events": "none" }, box);
   this.aetasGlow = e1 ? fwEl("rect", { x: -8, y: -3.8, width: 16, height: 7.6, fill: "none", stroke: "#FFF3C4", "stroke-width": 1, opacity: 0 }, this.aetasKnob) : null;      // (I3) el filo de luz de la palanca fuera de «hoy»
   this.aetasKnobR =fwEl("rect", fw2d({ x: -6.5, y: -2.4, width: 13, height: 4.8, fill: "url(#g-crown)", stroke: "#3B2A0C", "stroke-width": 0.6 }), this.aetasKnob);
   fwEl("line", fw2d({ x1: -4, y1: 0, x2: 4, y2: 0, stroke: "#3B2A0C", "stroke-width": 0.6 }), this.aetasKnob);
   this.aetasK3 = fwK3("aetas_lever", this.aetasKnob, "aetas");                 // (1c) la palanca renderizada; sin datos, velada
   this.aetasRead = fwEl("text", { x: rdx, y: 48, "text-anchor": "middle", class: "dialread", style: "font-size:" + (e1 ? FW_E1TG.READ_PX : 6.4) + "px;cursor:pointer", id: "aetasRead" }, ae);
   var cap = fwEl("text", { x: rdx, y: 60, "text-anchor": "middle", class: "eng", style: "font-size:7.5px;letter-spacing:.14em" }, ae); cap.textContent = "AETAS";      // (.14em: a .24em tocaba CHRONOMETRUM)
   this.aetasTip = fwTip(box, ""); this.aetasReadTip = fwTip(this.aetasRead, "");
   var yearsFrom = function(e) {
      var m = box.getScreenCTM(); if (!m) return null; var pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; var q = pt.matrixTransform(m.inverse());
      return (typeof fvTimeFromS === "function") ? fvTimeFromS(-q.y / G.TRAVEL) : 0;
   };
   box.addEventListener("pointerdown", function(e) { if (e.button !== 0 || !self.epochOk) return; var y = yearsFrom(e); if (y === null) return; if (typeof fwTimePlayStop === "function") fwTimePlayStop(); self.epochDrag = true; box.style.cursor = "grabbing"; try { box.setPointerCapture(e.pointerId); } catch (x) {} e.stopPropagation(); self.setEpoch(y, true); });
   box.addEventListener("pointermove", function(e) { if (!self.epochDrag) return; var y = yearsFrom(e); if (y !== null) self.setEpoch(y, true); });
   box.addEventListener("pointerup", function(e) { if (!self.epochDrag) return; self.epochDrag = false; box.style.cursor = "grab"; try { box.releasePointerCapture(e.pointerId); } catch (x) {} self.setEpoch(self.epoch, true, true); });
   this.aetasRead.addEventListener("click", function(e) { e.stopPropagation(); if (typeof fwTimePlayStop === "function") fwTimePlayStop(); if (self.epochOk) self.setEpoch(0, true, true); });
   if (e1) this.aetasKeysBuild(ae);                                              // (I3) los botones ▲ ▼
   ["pointerdown", "dblclick", "wheel"].forEach(function(t) { ae.addEventListener(t, function(ev) { ev.stopPropagation(); }, { passive: true }); });
   var gz = (typeof fvTimeGauge === "function" && this.scene) ? fvTimeGauge(this.scene) : { ok: false, years: 0 };
   this.epochOk = !!gz.ok; this.setEpoch(gz.years || 0, false);
};
// (I3) los dos botones redondos de reproduccion (▲ futuro arriba, ▼ pasado abajo): aro de laton, disco y su icono (triangulo; «pausa» mientras corre)
FWCockpit.prototype.aetasKeysBuild = function(ae) {
   var self = this, E = FW_E1TG, r = E.KR, ri = E.KR - 2.3; this.aetasKeys = {};
   var body = [" years (about 10 seconds from today), starting and stopping gently. Click again to pause; touching the lever also stops it. While the lever is away from today, the stars that matter leave their trail of ±100,000 years: in gold the ones that cross your photo (the nearby ones) and in ivory the members of a star cluster, which travel together with parallel trails of the same length. Everything comes from Gaia DR3 proper motions and radial velocities.",
               " años (unos 10 segundos desde hoy), arrancando y frenando con suavidad. Vuelve a pulsar para pausar; tocar la palanca también lo para. Mientras la palanca no esté en hoy, las estrellas que importan dejan su estela de ±100 000 años: en oro las que cruzan tu foto (las cercanas) y en marfil los miembros de un cúmulo, que viajan juntos con estelas paralelas y del mismo largo. Todo sale de los movimientos propios y las velocidades radiales de Gaia DR3."];
   [1, -1].forEach(function(dir) {
      var id = dir > 0 ? "aetasFwd" : "aetasBack", g = fwEl("g", { transform: "translate(" + E.KDX + "," + (-dir * E.KY) + ")", id: id, style: "cursor:pointer", "data-state": "idle" }, ae);
      fwEl("circle", { cx: 0.7, cy: 0.9, r: r, fill: "rgba(0,0,0,.44)" }, g);
      var ring = fwEl("circle", { r: r, fill: "url(#g-brass)", stroke: "#3B2A0C", "stroke-width": 0.8 }, g);
      var face = fwEl("circle", { r: ri, fill: "#1B140E", stroke: "#3B2A0C", "stroke-width": 0.6 }, g);
      var s = dir > 0 ? -1 : 1, oy = -s * 0.5;
      var tri = fwEl("path", { d: "M 0 " + (oy + s * 3.9) + " L -3.8 " + (oy - s * 2.6) + " L 3.8 " + (oy - s * 2.6) + " Z", fill: "#E5B53F" }, g);
      var pause = fwEl("path", { d: "M -3 -3.2 H -0.9 V 3.2 H -3 Z M 0.9 -3.2 H 3 V 3.2 H 0.9 Z", fill: "#3B2A0C", style: "display:none" }, g);
      var halo = fwEl("circle", { r: r + 1.1, fill: "none", stroke: "#F3D27E", "stroke-width": 1.2, opacity: 0, "pointer-events": "none" }, g);
      var tip = fwTip(g, dir > 0 ? fwTr("AETAS ▲ — play towards the future: time runs by itself up to +100,000" + body[0], "AETAS ▲ — reproducir hacia el futuro: el tiempo corre solo hasta +100 000" + body[1])
                                 : fwTr("AETAS ▼ — play towards the past: time runs by itself down to −100,000" + body[0], "AETAS ▼ — reproducir hacia el pasado: el tiempo corre solo hasta −100 000" + body[1]));
      g.addEventListener("click", function(e) { e.stopPropagation(); if (!self.epochOk) return; if (typeof fwTimePlayPress === "function") fwTimePlayPress(dir); });
      g.addEventListener("mouseenter", function() { self.aetasKeys[id].hover = true; self.aetasKeysSync(); });
      g.addEventListener("mouseleave", function() { self.aetasKeys[id].hover = false; self.aetasKeysSync(); });
      self.aetasKeys[id] = { g: g, ring: ring, face: face, tri: tri, pause: pause, halo: halo, tip: tip, dir: dir, hover: false };
   });
   // (F2, 20-nov) el interruptor SOL | GALAXIA, entre ▲ y ▼: un sol con sus rayos = el movimiento visto desde el Sol (lo de siempre); una espiral sobre el disco encendido = GALAXIA
   // (cada estrella con su velocidad peculiar, sin el Sol ni la rotacion: casi todas se quedan quietas y la que corre salta a la vista). ?gal=0 lo quita.
   if (typeof FV_TIME !== "undefined" && FV_TIME.GAL_ON === true && typeof fvTimeSetMode === "function") {
      var FR = E.FR, fg = fwEl("g", { transform: "translate(" + E.KDX + ",0)", id: "aetasFrame", style: "cursor:pointer", "data-state": "idle" }, ae), i, a, rays = "", sp = ["", ""];
      fwEl("circle", { cx: 0.6, cy: 0.8, r: FR, fill: "rgba(0,0,0,.44)" }, fg);
      var fring = fwEl("circle", { r: FR, fill: "url(#g-brass)", stroke: "#3B2A0C", "stroke-width": 0.8 }, fg);
      var fface = fwEl("circle", { r: FR - 1.7, fill: "#1B140E", stroke: "#3B2A0C", "stroke-width": 0.6 }, fg);
      for (i = 0; i < 8; ++i) { a = i * Math.PI / 4; rays += "M " + (2.4 * Math.cos(a)).toFixed(2) + " " + (2.4 * Math.sin(a)).toFixed(2) + " L " + (3.5 * Math.cos(a)).toFixed(2) + " " + (3.5 * Math.sin(a)).toFixed(2) + " "; }
      var sun = fwEl("g", {}, fg); fwEl("circle", { r: 1.5, fill: "#E5B53F" }, sun); var sunR = fwEl("path", { d: rays, stroke: "#E5B53F", "stroke-width": 0.7, fill: "none" }, sun);
      for (var arm = 0; arm < 2; ++arm) for (i = 0; i <= 12; ++i) { a = arm * Math.PI + i * 0.36; var rr = 0.9 + 0.2 * i; sp[arm] += (i ? "L " : "M ") + (rr * Math.cos(a)).toFixed(2) + " " + (rr * Math.sin(a)).toFixed(2) + " "; }
      var gal = fwEl("g", { style: "display:none" }, fg), galP = fwEl("path", { d: sp[0] + sp[1], stroke: "#3B2A0C", "stroke-width": 0.8, fill: "none" }, gal), galC = fwEl("circle", { r: 1.0, fill: "#3B2A0C" }, gal);
      var fhalo = fwEl("circle", { r: FR + 1.1, fill: "none", stroke: "#F3D27E", "stroke-width": 1.2, opacity: 0, "pointer-events": "none" }, fg);
      var ftip = fwTip(fg, fwTr("AETAS · SUN | GALAXY — what the stars move against. SUN (the sun glyph): the motion you see from the Sun, as always: it carries the reflection of the Sun's own motion and of the rotation of the Galaxy, mixed with each star's own. GALAXY (the spiral, lit): every star moves with its PECULIAR velocity, the one it has relative to the circular orbit at its own place in the Galaxy (the Sun's motion and the Galaxy's rotation taken off, Reid et al. 2019): most stars stay almost still and the ones that really run stand out. Without radial velocity, only the sideways part is moved. Click to switch.",
                                  "AETAS · SOL | GALAXIA — respecto a qué se mueven las estrellas. SOL (el dibujo del sol): el movimiento visto desde el Sol, como siempre: lleva el reflejo del movimiento del propio Sol y de la rotación de la Galaxia mezclado con lo de cada estrella. GALAXIA (la espiral, encendida): cada estrella se mueve con su velocidad PECULIAR, la que tiene respecto a la órbita circular de su propio sitio de la Galaxia (descontados el movimiento del Sol y la rotación de la Galaxia, Reid et al. 2019): casi todas se quedan quietas y las que de verdad corren saltan a la vista. Sin velocidad radial, solo se mueve la parte de lado. Pulsa para cambiar."));
      fg.addEventListener("click", function(e) { e.stopPropagation(); if (self.epochOk) self.toggleFrame(); });
      fg.addEventListener("mouseenter", function() { self.aetasFrameUi.hover = true; self.aetasKeysSync(); });
      fg.addEventListener("mouseleave", function() { self.aetasFrameUi.hover = false; self.aetasKeysSync(); });
      this.aetasFrameUi = { g: fg, ring: fring, face: fface, sun: sun, sunR: sunR, gal: gal, galP: galP, galC: galC, halo: fhalo, tip: ftip, hover: false };
   }
};
// (F2) pulsar el interruptor: SOL <-> GALAXIA; la escena se vuelve a aplicar en el mismo año (el motor cambia la velocidad de cada estrella, fvTimeSetMode)
FWCockpit.prototype.toggleFrame = function() {
   if (!this.scene || typeof fvTimeSetMode !== "function") return false;
   var to = (fvTimeMode(this.scene) === "gal") ? "sun" : "gal";
   if (!fvTimeSetMode(this.scene, to)) return false;
   this.setEpoch(this.epoch, true, true);
   return true;
};
// el estado de los dos botones: «off» (en el tope o sin datos), «idle», «hover», «on» (corriendo hacia su lado)
FWCockpit.prototype.aetasKeysSync = function() {
   if (!this.aetasKeys) return;
   var st = (typeof fwTimePlayState === "function") ? fwTimePlayState() : null, playing = !!(st && st.on), stopping = playing && st.phase === "stop";
   for (var id in this.aetasKeys) {
      var K = this.aetasKeys[id], can = (typeof fvTplayCan === "function") ? fvTplayCan(this.epoch, K.dir) : true;
      var s = !this.epochOk ? "off" : ((playing && st.dir === K.dir && !stopping) ? "on" : (!can ? "off" : (K.hover ? "hover" : "idle")));
      fwSetA(K.g, "data-state", s);
      fwSetA(K.ring, "fill", s === "off" ? "#5E4214" : "url(#g-brass)");
      fwSetA(K.face, "fill", s === "on" ? "url(#g-crownBtn)" : (s === "off" ? "#16110B" : "#1B140E"));
      fwSetA(K.tri, "fill", s === "off" ? "#5E4214" : (s === "hover" ? "#FFF3C4" : "#E5B53F"));
      fwSetCss(K.tri, "display", s === "on" ? "none" : "inline"); fwSetCss(K.pause, "display", s === "on" ? "inline" : "none");
      fwSetA(K.halo, "opacity", (s === "on" || s === "hover") ? (s === "on" ? "0.75" : "1") : "0");
      fwSetCss(K.g, "cursor", s === "off" ? "default" : "pointer");
   }
   // (F2) el interruptor SOL | GALAXIA: apagado sin datos (o sin motor de la fugitiva); en GALAXIA, el disco encendido y la espiral
   var F = this.aetasFrameUi;
   if (F) {
      var canG = !!(this.epochOk && this.scene && typeof fvTimeCanGal === "function" && fvTimeCanGal(this.scene)), gal = canG && fvTimeMode(this.scene) === "gal", fs = !canG ? "off" : (F.hover ? "hover" : "idle");
      fwSetA(F.g, "data-state", (gal ? "gal-" : "sun-") + fs);
      fwSetA(F.ring, "fill", fs === "off" ? "#5E4214" : "url(#g-brass)");
      fwSetA(F.face, "fill", gal ? "url(#g-crownBtn)" : (fs === "off" ? "#16110B" : "#1B140E"));
      fwSetCss(F.sun, "display", gal ? "none" : "inline"); fwSetCss(F.gal, "display", gal ? "inline" : "none");
      var ink = fs === "off" ? "#5E4214" : (fs === "hover" ? "#FFF3C4" : "#E5B53F");
      fwSetA(F.sunR, "stroke", ink); F.sun.firstChild.setAttribute("fill", ink);
      fwSetA(F.halo, "opacity", fs === "hover" ? "1" : "0");
      fwSetCss(F.g, "cursor", fs === "off" ? "default" : "pointer");
   }
};
// la epoca (años desde la foto). user = la ha movido el usuario (se aplica a la escena); done = soltada
FWCockpit.prototype.setEpoch = function(years, user, done) {
   if (!this.aetasG) return;
   this.epoch = years || 0;
   if (user && typeof fwTimeSet === "function") fwTimeSet(this.scene, this.epoch, !!done);
   var s = (typeof fvTimeToS === "function") ? fvTimeToS(this.epoch) : 0, ok = this.epochOk;
   fwSetA(this.aetasKnob, "transform", "translate(0," + (-FW_I4G.TRAVEL * s).toFixed(2) + ")");
   fwSetA(this.aetasKnobR, "fill", ok ? "url(#g-crown)" : "#4A3A20");
   if (this.aetasFill) { var ykF = -FW_I4G.TRAVEL * s; fwSetA(this.aetasFill, "y", Math.min(0, ykF).toFixed(2)); fwSetA(this.aetasFill, "height", (ok ? Math.abs(ykF) : 0).toFixed(2)); }
   if (this.aetasGlow) fwSetA(this.aetasGlow, "opacity", (ok && this.epoch !== 0) ? "1" : "0");
   if (this.e1t) this.aetasKeysSync();
   if (this.aetasK3) fwSetA(this.aetasK3, "opacity", ok ? "1" : "0.45");
   fwSetT(this.aetasRead, ok ? ((typeof fvTimeText === "function") ? fvTimeText(this.epoch, FW_LANG) : "") : fwTr("no data", "sin datos"));
   fwSetCss(this.aetasRead, "fill", !ok ? "#5E4214" : (this.epoch === 0 ? "#E5B53F" : "#E0603F"));
   var tip = ok ? fwTr("AETAS — time machine: drag the lever up to go into the future, down into the past (up to 100,000 years; the notch in the middle is today). The stars of your photo move with their Gaia proper motion and, where Gaia measured it, their radial velocity: straight-line motion, which at this range differs from the real orbit by less than 0.1 %. Stars without radial velocity move only across the sky (their distance hardly changes). Stars without proper motion stay put.",
                      "AETAS — máquina del tiempo: arrastra la palanca hacia arriba para ir al futuro y hacia abajo al pasado (hasta 100 000 años; la muesca del centro es hoy). Las estrellas de tu foto se mueven con su movimiento propio de Gaia y, donde Gaia la midió, su velocidad radial: movimiento en línea recta, que a esta escala se separa de la órbita real menos de un 0,1 %. Las que no tienen velocidad radial solo se mueven por el cielo (su distancia apenas cambia). Las que no tienen movimiento propio se quedan quietas.")
                : fwTr("AETAS — time machine: this scene has no proper motions (built without them). Rebuild the scene to move the stars in time.", "AETAS — máquina del tiempo: esta escena no trae movimientos propios (se construyó sin ellos). Vuelve a construir la escena para mover las estrellas en el tiempo.");
   fwSetT(this.aetasTip, tip);
   fwSetT(this.aetasReadTip, ok ? fwTr("The chosen epoch, from the date of your photo. Click to come back to today.", "La época elegida, contada desde la fecha de tu foto. Clic para volver a hoy.") : tip);
};

// (F3c) ayuda emergente de un grupo SVG (un <title>), en el idioma de la cabina
function fwTip(g, text) { var t = fwEl("title", {}, g); t.textContent = text; return t; }
function fwIcon(g, id) {
   // (E6 + S1) los MISMOS dibujos que PixInsight (src/ui/fv_buttons.js, fvEngrave): surco fino (0,72) con filo de luz de medio trazo debajo
   // (clase «edge», que la ficha oscura esconde), y un trazo aun mas fino (0,4) para el detalle de grabado; puntos macizos pequeños
   function st(d) { fwEl("path", { d: d, class: "edge", fill: "none", "stroke-width": 0.42, transform: "translate(.38,.38)" }, g); fwEl("path", { d: d, stroke: "currentColor", fill: "none", "stroke-width": 0.72 }, g); }
   function hair(d) { fwEl("path", { d: d, stroke: "currentColor", fill: "none", "stroke-width": 0.4 }, g); }
   function dot(x, y, r) { fwEl("circle", { cx: x, cy: y, r: r, fill: "currentColor", stroke: "none" }, g); }
   function circ(x, y, r) { return "M " + (x - r) + " " + y + " A " + r + " " + r + " 0 1 0 " + (x + r) + " " + y + " A " + r + " " + r + " 0 1 0 " + (x - r) + " " + y + " "; }
   function ell(rx, ry) { return "M " + (-rx) + " 0 A " + rx + " " + ry + " 0 1 0 " + rx + " 0 A " + rx + " " + ry + " 0 1 0 " + (-rx) + " 0 "; }
   function arc(cx, cy, rx, ry, a0, a1, n) { var d = ""; for (var k = 0; k <= n; ++k) { var b = a0 + (a1 - a0) * k / n; d += (k ? " L " : "M ") + (cx + Math.cos(b) * rx).toFixed(2) + " " + (cy + Math.sin(b) * ry).toFixed(2); } return d; }
   function ticks(cx, cy, r0, r1, n, off) { var d = ""; for (var k = 0; k < n; ++k) { var a = (off + k * 360 / n) * Math.PI / 180; d += "M " + (cx + Math.cos(a) * r0).toFixed(2) + " " + (cy + Math.sin(a) * r0).toFixed(2) + " L " + (cx + Math.cos(a) * r1).toFixed(2) + " " + (cy + Math.sin(a) * r1).toFixed(2) + " "; } return d; }
   if (id === "start") {
      // (B2, 20-nov, Nino: «que el dibujo parezca más Home») UNA CASA: tejado a dos aguas con chimenea, paredes, puerta y ojo de buey en el hastial. El MISMO dibujo que
      // PixInsight (src/ui/fv_buttons.js, fvEngrave «start»); el filete fino repite el alero y marca el suelo.
      st("M -15 0 L 0 -13 L 15 0 M -11 -3.5 L -11 12 L 11 12 L 11 -3.5 M -3 12 L -3 4 L 3 4 L 3 12 M 7 -6.9 L 7 -12.5 L 10.5 -12.5 L 10.5 -3.9");
      hair("M -9.5 -2.4 L 0 -10.6 L 9.5 -2.4 M -15 12 L 15 12 " + circ(0, -4.4, 2.4)); dot(0, -4.4, 0.9); dot(1.6, 8.6, 0.7);
   }
   else if (id === "travel") {
      // (N2, punto 3 de Nino) VIAJAR: flecha CURVA hacia un PUNTO REDONDO (Bezier (-15,9) (-9,-15) (3.5,-2.5), cabeza sobre la tangente)
      var P0 = [-15, 9], C0 = [-9, -15], P1 = [3.5, -2.5], tx = P1[0] - C0[0], ty = P1[1] - C0[1], tl = Math.hypot(tx, ty), d = "M " + P0[0] + " " + P0[1] + " Q " + C0[0] + " " + C0[1] + " " + P1[0] + " " + P1[1];
      tx /= tl; ty /= tl;
      [-1, 1].forEach(function(k) { var ca = Math.cos(0.45), sa = Math.sin(k * 0.45), rx = -tx * ca + ty * sa, ry = -tx * sa - ty * ca; d += " M " + P1[0] + " " + P1[1] + " L " + (P1[0] + rx * 5.5).toFixed(2) + " " + (P1[1] + ry * 5.5).toFixed(2); });
      st(d + " " + circ(11.5, 4.5, 3.8)); hair(circ(11.5, 4.5, 6.2) + ticks(11.5, 4.5, 6.2, 7.8, 4, 45)); dot(11.5, 4.5, 1.3);
   }
   else if (id === "tour") {
      var T = [[-14, 8], [-6, -6], [3, 6], [10, -8], [15, 2]];
      st("M -14 8 L -6 -6 L 3 6 L 10 -8 L 15 2"); hair(T.map(function(p) { return circ(p[0], p[1], 2.9); }).join(""));
      T.forEach(function(p) { dot(p[0], p[1], 1.25); });
   }
   else if (id === "info") { st(circ(0, 0, 11.5) + "M 0 -1.5 L 0 6 M -2.5 6 L 2.5 6 M -1.6 -1.5 L 0 -1.5"); hair(circ(0, 0, 13.6) + ticks(0, 0, 13.6, 15.4, 4, 0)); dot(0, -5.2, 1.35); }
   else if (id === "warp") st("M -16 -8 L 2 -2 M -17 0 L 4 0 M -16 8 L 2 2 M -12 -14 L 0 -5 M -12 14 L 0 5 " + circ(12, 0, 4));
   else if (id === "goto") st("M -15 0 L 7 0 M 1 -6 L 7 0 L 1 6 " + circ(14.5, 0, 3.5));
   else if (id === "web") { st(circ(0, 0, 12) + ell(5, 12) + "M -12 0 L 12 0"); hair(ell(9.4, 12) + "M 0 -12 L 0 12 M -10.4 -6 L 10.4 -6 M -10.4 6 L 10.4 6"); }
   else if (id === "exo") { st(circ(-2, 0, 11) + "M -16 13 L 16 -9"); dot(6, -3.5, 3.2); }
   else if (id === "hr" && typeof fwHrIcon === "function") fwHrIcon(st, hair, dot);   // (I2, 19-nov) el diagrama HR: el mismo dibujo que fvHrEngrave
}

// un reloj de esfera esmaltada (maqueta §10)
function fwWatch(g, o) {
   var R = o.r || 40;
   if (o.crown) fwK3("dial_face_T", g, "T"); else fwK3("dial_face", g, "V");   // (1c) corona, bisel moleteado y esmalte: sprite
   fwEl("circle", fw2d({ r: R + 5, fill: "url(#g-brass)" }), g);
   for (var k = 0; k < 90; k++) { var p = fwPol(R + 5, k * 4), q = fwPol(R + 2.5, k * 4); fwEl("line", fw2d({ x1: p[0], y1: p[1], x2: q[0], y2: q[1], stroke: "#5E4214", "stroke-width": 0.8 }), g); }
   fwEl("circle", fw2d({ r: R + 0.5, fill: "none", stroke: "#3B2A0C", "stroke-width": 1 }), g);
   fwEl("circle", fw2d({ r: R, fill: "url(#g-enamel)" }), g);
   fwEl("circle", { r: R - 3, fill: "none", stroke: "#2A1F15", "stroke-width": 0.5 }, g); fwEl("circle", { r: R - 6, fill: "none", stroke: "#2A1F15", "stroke-width": 0.5 }, g);
   var n = o.minor || 60, nl = o.labels.length - (o.full ? 0 : 1);
   for (var m = 0; m <= n; m++) { if (o.full && m === n) break; var a = o.a0 + (o.a1 - o.a0) * m / n, p1 = fwPol(R - 3, a), p2 = fwPol(R - 6, a); fwEl("line", { x1: p1[0], y1: p1[1], x2: p2[0], y2: p2[1], stroke: "#2A1F15", "stroke-width": (m % (n / nl) === 0) ? 1.1 : 0.4 }, g); }
   o.labels.forEach(function(L, i) { if (o.lux && L === "c") return; var a = o.a0 + (o.a1 - o.a0) * i / nl, p = fwPol(o.full ? R - 11.5 : R - 13, a); var t = fwEl("text", { x: p[0], y: p[1] + (o.full ? 2.3 : 3), "text-anchor": "middle", class: "dialnum", style: o.full ? "font-size:6px" : "" }, g); t.textContent = L; });
   if (o.lux) {
      // (E9) el tramo superluminico (banda bermellon tenue en el aro de capitulos), la marca de la LUZ (filete + triangulito + «c» bermellon)
      // y la del warp 9,975 (5 160 c) en azul pavonado
      var b0 = fwPol(R - 4.5, -60), b1 = fwPol(R - 4.5, 120);
      fwEl("path", { d: "M " + b0[0].toFixed(2) + " " + b0[1].toFixed(2) + " A " + (R - 4.5) + " " + (R - 4.5) + " 0 0 1 " + b1[0].toFixed(2) + " " + b1[1].toFixed(2), fill: "none", stroke: "rgba(176,48,30,.17)", "stroke-width": 2.6 }, g);
      var c0 = fwPol(R - 0.5, -60), c1 = fwPol(R - 10.5, -60), t0 = fwPol(R - 3.2, -60), t1 = fwPol(R - 0.4, -62.6), t2 = fwPol(R - 0.4, -57.4), cl = fwPol(R - 15.5, -60);
      fwEl("line", { x1: c0[0], y1: c0[1], x2: c1[0], y2: c1[1], stroke: "#B0301E", "stroke-width": 1.3, class: "luxmark" }, g);
      fwEl("path", { d: "M " + t0.join(" ") + " L " + t1.join(" ") + " L " + t2.join(" ") + " Z", fill: "#B0301E" }, g);
      var lc = fwEl("text", { x: cl[0], y: cl[1] + 3.4, "text-anchor": "middle", class: "dialnum lux" }, g); lc.textContent = "c";
      var aw = -60 + 15 * Math.log(5160) / Math.LN10, w0 = fwPol(R - 2, aw), w1 = fwPol(R - 8, aw);
      fwEl("line", { x1: w0[0], y1: w0[1], x2: w1[0], y2: w1[1], stroke: "#3A5AA0", "stroke-width": 1 }, g);
   }
   if (o.title) { var t = fwEl("text", { y: o.full ? -R * 0.32 : -R * 0.3, "text-anchor": "middle", class: "dialtitle" }, g); t.textContent = o.title; }
   var ro = fwEl("text", { y: o.full ? R * 0.5 : R * 0.7, "text-anchor": "middle", class: "dialread" }, g), sub = null;
   if (o.sub) { var sg = fwEl("g", { transform: "translate(0," + (R * 0.30) + ")" }, g); fwEl("circle", { r: 7.5, fill: "none", stroke: "#2A1F15", "stroke-width": 0.5 }, sg); for (var u = 0; u < 12; u++) { var a1 = fwPol(7.5, u * 30), a2 = fwPol(6.2, u * 30); fwEl("line", { x1: a1[0], y1: a1[1], x2: a2[0], y2: a2[1], stroke: "#2A1F15", "stroke-width": 0.5 }, sg); }
      sub = fwEl("line", { x1: 0, y1: 1.5, x2: 0, y2: -6.5, stroke: "#1B2C55", "stroke-width": 0.8 }, sg); ro.setAttribute("y", R * 0.68); ro.setAttribute("style", "font-size:6.8px"); }
   // (F3c) el reloj con segundero solo lleva XII, III y IX: la lectura del año («4500 a. C.») va abajo, donde estarian V, VI y VII
   var hands = []; (o.hands || [R - 8]).forEach(function(len) { hands.push(fwEl("use", { href: "#g-hand", width: 12 * len / 38, height: 48 * len / 38, x: -6 * len / 38, y: -40 * len / 38 }, g)); });
   fwEl("circle", fw2d({ r: 2.4, fill: "url(#g-crown)" }), g); fwK3("dial_cap", g, "V");
   fwEl("circle", fw2d({ r: R, fill: "url(#g-glass)" }), g); fwK3("dial_glass", g, "V", 1, 1, "", true);   // (1c) pivote y cristal renderizados
   if (o.crown) { fwEl("rect", fw2d({ x: -3, y: -R - 12, width: 6, height: 6, fill: "url(#g-brass)" }), g); fwEl("ellipse", fw2d({ cx: 0, cy: -R - 15, rx: 6.5, ry: 4, fill: "url(#g-crown)" }), g); }
   var cap = fwEl("text", { y: R + 16, "text-anchor": "middle", class: "eng", style: "font-size:7.5px;letter-spacing:.24em" }, g); cap.textContent = o.caption;
   return { hands: hands, read: ro, sub: sub };
}

// ---- un fotograma: gz = fvPilotGauges(P) + { reg } ----
// (N13) escribir en el DOM solo lo que cambia: cada setAttribute/textContent repetido costaba estilo y composicion en cada fotograma
function fwSetA(el, k, v) { var c = el.__fw || (el.__fw = {}); if (c[k] !== v) { c[k] = v; el.setAttribute(k, v); } }
function fwSetT(el, v) { if (el.__fwT !== v) { el.__fwT = v; el.textContent = v; } }
function fwSetCss(el, k, v) { if (el.style[k] !== v) el.style[k] = v; }
FWCockpit.prototype.update = function(gz, P) {
   if (gz.pad) this.setPad(gz.pad);                 // (5-nov) la cruceta
   if (this.hub) this.setHub(gz.brake);             // (6-nov) el freno del cubo
   // VELOCITAS (F2): años luz por SEGUNDO de tu tiempo, logaritmica de 10⁻² a 10⁴; DISTANTIA: a la Tierra, logaritmica de 1 a 10 000 a.l.
   var c = (gz.speedLyS || 0) * 3.15576e7, av = fwSpeedCAngle(c), vSup = FW_E9 && c >= 0.995;
   fwSetA(this.gV.hands[0], "transform", "rotate(" + av.toFixed(1) + ")");
   fwSetT(this.gV.read, fwSpeedCText(c)); fwSetA(this.gV.read, "class", vSup ? "dialread sup" : "dialread");
   var ad = -120 + 60 * fvClamp(Math.log(Math.max(1, gz.dist)) / Math.LN10, 0, 4);
   fwSetA(this.gD.hands[0], "transform", "rotate(" + ad.toFixed(1) + ")");
   fwSetT(this.gD.read, (gz.dist < 0.01 ? "0" : fwFmtLy(gz.dist)) + " " + fwTr("ly", "a.l."));
   var sec = gz.clock || 0, ch = gz.chrono, yr = (ch && ch.known) ? ch.year : null;
   var ah = (yr !== null) ? (((yr % 12000) + 12000) % 12000) / 12000 * 360 : 0, am = (yr !== null) ? (((yr % 1000) + 1000) % 1000) / 1000 * 360 : 0;
   fwSetA(this.gT.hands[0], "transform", "rotate(" + ah.toFixed(1) + ")"); fwSetA(this.gT.hands[1], "transform", "rotate(" + am.toFixed(1) + ")");
   fwSetA(this.gT.sub, "transform", "rotate(" + (Math.floor(sec % 60) * 6) + ")");
   fwSetT(this.gT.read, (yr !== null) ? ch.txt : "—");
   this.gaugeState = { c: c, vRead: this.gV.read.textContent, vAngle: av, vSuper: vSup, dRead: this.gD.read.textContent, tRead: this.gT.read.textContent, year: yr, chrono: ch || null };
   // (punto 8) la palanca es lo que ELIGE el usuario (this.speed); la aguja roja fina, lo que da el motor (gz.reg: el warp en curso o el empuje del cine)
   fwSetA(this.lever, "transform", "rotate(" + (-62 + 124 * this.speed).toFixed(1) + ")");
   var rv = fvClamp(gz.reg || 0, 0, 1);
   fwSetA(this.regNeedle, "transform", "rotate(" + (-62 + 124 * rv).toFixed(1) + ")"); fwSetA(this.regNeedle, "opacity", rv > 0.005 ? "0.85" : "0");
};
// la velocidad del viaje (0…1; 0,5 = la de siempre). done = soltada (se avisa para recordarla)
FWCockpit.prototype.setSpeed = function(s, user, done) {
   this.speed = fvClamp(s, 0, 1);
   fwSetA(this.lever, "transform", "rotate(" + (-62 + 124 * this.speed).toFixed(1) + ")");
   if (user && this.hooks.speed) this.hooks.speed(this.speed, !!done);
};
FWCockpit.prototype.setButtons = function(st) {
   for (var id in st) if (this.btn[id]) { var b = this.btn[id], en = !!st[id].enabled, on = !!st[id].on; if (b.disabled !== !en) b.disabled = !en; if (b.classList.contains("on") !== on) b.classList.toggle("on", on); }
};
FWCockpit.prototype.setMode = function(spect) {
   if (!this.modeKnob) return;      // (N-galaxias-warp) sin selector
   this.modeKnob.setAttribute("cy", spect ? 13 : -13); this.modeLever.setAttribute("y2", spect ? 13 : -13);
   if (FW_CK3D) this.modeG.setAttribute("data-up", spect ? "0" : "1");          // (1c) el sprite de la palanca: arriba CINE, abajo WARP
};
FWCockpit.prototype.setRec = function(on, txt) { this.recLamp.setAttribute("fill", on ? "#FF3B1F" : "#5A1E12"); this.recTxt.textContent = txt || this.recLabel; if (FW_CK3D) fwSetA(this.recG, "data-on", on ? "1" : "0"); };
// LA LEYENDA (F3b): placa retro plegable (plegada al abrir, §11.2) en el idioma de la cabina. Se arma con los DATOS de la escena
// (cuentas de estrellas por calidad, nebulosa, motor que quito las estrellas), no con las notas de PixInsight (vienen en ingles y
// pueden cambiar de redaccion): las notas originales quedan en la descripcion emergente. Plegada sigue diciendo lo esencial:
// el relieve 3D es SUPUESTO. extra: [texto] lineas que añade el visor (p. ej. «nebulosa en capas»).
FWCockpit.prototype.setLegend = function(scene, notes, extra) {
   var lg = this.legend, S = scene.stars, N = scene.nebula, n = [0, 0, 0], nWide = 0, nRing = 0, i;
   for (i = 0; i < S.n; ++i) { var m = S.meta[i] || {}; if (m.wide || m.outside) { ++nWide; if (m.ring) ++nRing; } else if (S.q[i] <= 2) ++n[S.q[i]]; }
   var all = (notes || []).join(" · "), rel = /Gaia\s+(DR\d|EDR\d)/.exec(all), gaia = "Gaia" + (rel ? " " + rel[1] : "");
   var rows = [];
   rows.push(["ok", fwTr("Measured distance", "Distancia medida"), fwFmtInt(n[0]) + fwTr(" stars", " estrellas")]);
   if (n[1]) rows.push(["warn", fwTr("Doubtful distance (high RUWE)", "Distancia dudosa (RUWE alto)"), fwFmtInt(n[1])]);
   rows.push(["bad", fwTr("Assumed distance", "Distancia supuesta"), fwFmtInt(n[2])]);
   if (/RUWE NOT checked/i.test(all)) rows.push(["warn", fwTr("RUWE not checked", "RUWE sin comprobar"), fwTr("VizieR did not answer", "VizieR no respondió")]);
   if (nWide) rows.push(["dim", fwTr("Sky around the photo", "Cielo alrededor de la foto"), fwFmtInt(nWide) + (nRing ? " (" + fwFmtInt(nRing) + fwTr(" ring", " anillo") + ")" : "")]);
   if (N) {
      rows.push([N.measured ? "ok" : "bad", fwTr("Nebula ", "Nebulosa ") + (typeof fwNameOf === "function" ? fwNameOf(N.names || N.name, "") : (N.name || "")), fwFmtLy(N.distLy) + " " + fwTr("ly", "a.l.") + " · " + (N.measured ? fwTr("measured", "medida") : fwTr("ASSUMED", "SUPUESTA")) + (N.distRef ? " (" + N.distRef.replace(/mesDistance\s*/i, "") + ")" : "")]);
      rows.push(["warn", fwTr("Thickness and 3-D relief", "Grosor y relieve 3D"), fwTr("ASSUMED: drawn from the photo's light and colour", "SUPUESTOS: sacados de la luz y el color de la foto")]);
      if (N.engine) rows.push(["dim", fwTr("Stars removed with", "Estrellas quitadas con"), N.engine]);
   }
   for (i = 0; i < (extra || []).length; ++i) rows.push(["warn", extra[i], ""]);
   // (11-nov, NV-16) con el laboratorio: la Via Lactea de fondo y el campo de estrellas son SIMULADOS (los textos de PixInsight, leg.mw / leg.mwOff de
   // src/ui/fv_text.js) y un clic en la fila los apaga o enciende (FWCockpit.onMilkyWay, lo pone el visor). Sin el laboratorio, la leyenda de antes
   var self = this, mwRow = null, mwKey = function() { return self.mwOn === false ? "leg.mwOff" : "leg.mw"; };
   var mwOk = !!(scene.galaxy && typeof FW_LAB !== "undefined" && FW_LAB.ON && typeof fvTx === "function");
   if (mwOk) rows.push(["bad mw", fvTx(mwKey(), null, FW_LANG === "es" ? "es" : "en"), ""]);
   lg.innerHTML = "";
   var tab = document.createElement("button"); tab.className = "lg-tab"; tab.type = "button";
   tab.innerHTML = "<span class='lg-t'></span><span class='lg-sub'></span><span class='lg-chev'>▸</span>";
   tab.querySelector(".lg-t").textContent = fwTr("LEGEND", "LEYENDA");
   tab.querySelector(".lg-sub").textContent = fwTr("3-D relief ASSUMED", "relieve 3D SUPUESTO");
   var body = document.createElement("div"); body.className = "lg-body";
   var hd = document.createElement("div"); hd.className = "lg-src"; hd.textContent = gaia + fwTr(" · what is measured and what is assumed", " · lo medido y lo supuesto"); body.appendChild(hd);
   rows.forEach(function(r) {
      var d = document.createElement("div"); d.className = "lg-row " + r[0];
      d.innerHTML = "<i></i><span class='lg-k'></span><span class='lg-v'></span>";
      d.querySelector(".lg-k").textContent = r[1]; d.querySelector(".lg-v").textContent = r[2];
      if (/\bmw\b/.test(r[0])) mwRow = d;
      body.appendChild(d);
   });
   if (mwRow) {
      mwRow.style.cursor = "pointer"; mwRow.setAttribute("role", "button");
      mwRow.addEventListener("click", function(e) {
         e.stopPropagation(); self.mwOn = self.mwOn === false;
         mwRow.querySelector(".lg-k").textContent = fvTx(mwKey(), null, FW_LANG === "es" ? "es" : "en");
         if (typeof self.onMilkyWay === "function") self.onMilkyWay(self.mwOn !== false);
      });
   }
   this.legendMwRow = mwRow;
   lg.appendChild(tab); lg.appendChild(body);
   lg.title = fwTr("Notes from PixInsight (in English):\n", "Notas de PixInsight (en inglés):\n") + (notes || []).join("\n");
   var open = false; try { open = window.localStorage.getItem("fvLegendOpen") === "1"; } catch (e) {}
   function set(o) { open = o; lg.classList.toggle("open", o); tab.setAttribute("aria-expanded", o ? "true" : "false"); if (typeof fwE1qDraw === "function") { try { fwE1qDraw(); } catch (e0) {} } try { window.localStorage.setItem("fvLegendOpen", o ? "1" : "0"); } catch (e) {} }      // (21-nov, PKG-final) la tira de QUAESTIO se aparta de la placa abierta
   set(open);
   tab.addEventListener("click", function(e) { e.stopPropagation(); set(!open); });
   ["pointerdown", "pointerup", "dblclick", "wheel"].forEach(function(t) { lg.addEventListener(t, function(e) { e.stopPropagation(); }); });
   this.legendSet = set;
};

// ---------------- LA FICHA ----------------
// lineas: [{ t: texto, c: clase (title|mono|ok|warn|bad|phrase) }]
// (F3c) LA FICHA es una lamina de papel crema grabada, como la de PixInsight (src/ui/fv_hud.js): titulo, subtitulo en cursiva, portilla con
// el objeto, SELLO de goma MEDIDO / DUDOSO / SUPUESTO con su fuente debajo, y las frases. Las lineas siguen siendo las mismas (las pruebas
// las leen): la de calidad (ok|warn|bad) va al sello; el titulo y la primera «dim» a la cabecera; el resto al cuerpo.
FWCockpit.prototype.showCard = function(sel, lines, rgb, P) {
   this.cardSel = sel; this.cardLines = lines; this.cardT0 = fwCkNow(); this.cardRgb = rgb;
   var ttl = document.getElementById("cardTitle"), sub = document.getElementById("cardSub"), stamp = document.getElementById("cardStamp"), src = document.getElementById("cardSrc");
   this.cardText.innerHTML = ""; ttl.textContent = ""; sub.textContent = ""; stamp.textContent = ""; src.textContent = ""; stamp.className = "";
   this.cardSpans = [];
   var gotSub = false;
   for (var i = 0; i < lines.length; ++i) {
      var c = lines[i].c || "mono", d;
      if (c === "title") d = ttl;
      else if (!gotSub && /\bdim\b/.test(c)) { d = sub; gotSub = true; }
      else if (/\b(ok|warn|bad)\b/.test(c) && !stamp.textContent) {
         var k = /\bok\b/.test(c) ? "ok" : (/\bwarn\b/.test(c) ? "warn" : "bad");
         var t = lines[i].t, cut = t.indexOf(" · ");
         // (Blender 5 · H4) el sello de un planeta de DEMOSTRACION dice DEMO (la palabra la da la ficha comun: C.stamp.word), no DUDOSO
         stamp.textContent = (cut >= 0 && t.substring(0, cut) === "DEMO") ? "DEMO" : (k === "ok" ? fwTr("MEASURED", "MEDIDO") : (k === "warn" ? fwTr("DOUBTFUL", "DUDOSO") : fwTr("ASSUMED", "SUPUESTO"))); stamp.className = k;
         this.cardSpans.push({ el: src, line: { t: cut >= 0 ? t.substring(cut + 3) : "", c: c } });
         continue;
      } else { d = document.createElement("div"); d.className = "cl " + c; this.cardText.appendChild(d); }
      this.cardSpans.push({ el: d, line: lines[i] });
   }
   this.card.style.display = "none";
};
// (6-nov) el reloj de la ficha: el de la pagina, o el de la prueba (FW.testNow, ms) cuando la prueba lleva el tiempo (tour a paso fijo)
function fwCkNow() { return (typeof FW !== "undefined" && FW.testNow !== undefined && FW.testNow !== null) ? FW.testNow : performance.now(); }
FWCockpit.prototype.hideCard = function() { this.cardSel = null; this.cardHidden = false; this.card.style.display = "none"; };
// pinta la reticula, la linea de llamada y hace avanzar el texto. sx, sy: el objeto en pantalla (CSS px) o null
FWCockpit.prototype.drawHud = function(sx, sy, rr, W, H, now) {
   var g = this.hctx, dpr = this.hud.width / Math.max(1, W);
   g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
   // (6-nov, FV_TOUR_READ) lo que lee la espera del TOUR: la ficha escrita entera y sus palabras (se rehace en cada pintada; sin pintar, «no»)
   this.cardReadSt = { sel: this.cardSel ? this.cardSel.kind + ":" + this.cardSel.i : "", typed: false, started: false, words: 0 };
   if (!this.cardSel || sx === null || this.cardHidden) { fwSetCss(this.card, "display", "none"); return; }
   var t = (now - this.cardT0) / 1000;
   function eob(x) { var c1 = 1.70158, c3 = c1 + 1; x = fvClamp(x, 0, 1); return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); }
   var k = eob(t / 0.4), R = rr * (1 + 2.2 * (1 - k)), a = Math.max(6, R * 0.45);
   g.strokeStyle = "#E5B53F"; g.lineWidth = 1.6; g.beginPath();
   [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(function(C) { var x0 = sx + C[0] * R, y0 = sy + C[1] * R; g.moveTo(x0 - C[0] * a, y0); g.lineTo(x0, y0); g.lineTo(x0, y0 - C[1] * a); });
   g.stroke();
   if (t < 0.25) { fwSetCss(this.card, "display", "none"); return; }
   var z = (typeof FW !== "undefined" && FW.uiK) ? FW.uiK : 1, cw = (this.card.offsetWidth || 480) * z, ch = (this.card.offsetHeight || 200) * z, right = sx < W * 0.55, x0 = right ? W - cw - 24 : 24, yMin = 70 * z;
   if (typeof fwE1qCardMinY === "function") yMin = fwE1qCardMinY(W, x0, x0 + cw, yMin);      // (M) la ficha no se coloca bajo la tira de QUAESTIO
   var y0 = Math.round(fvClamp(sy - ch / 2, yMin, Math.max(yMin, H - ch - 24)));
   var ax = sx + (right ? R : -R), ay = sy - R, ex = right ? x0 : x0 + cw, mx = ax + (ex - ax) * 0.35, grow = fvClamp((t - 0.25) / 0.3, 0, 1);
   var pts = [[ax, ay], [mx, y0 + 18], [ex, y0 + 18]], seg = [], tot = 0, i;
   for (i = 1; i < 3; ++i) { var l = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(l); tot += l; }
   var left = tot * grow; g.strokeStyle = "rgba(229,181,63,.75)"; g.lineWidth = 1; g.beginPath(); g.moveTo(ax, ay);
   for (i = 1; i < 3 && left > 0; ++i) { var u = Math.min(1, left / seg[i - 1]); g.lineTo(pts[i - 1][0] + (pts[i][0] - pts[i - 1][0]) * u, pts[i - 1][1] + (pts[i][1] - pts[i - 1][1]) * u); left -= seg[i - 1]; }
   g.stroke();
   if (grow < 1) { fwSetCss(this.card, "display", "none"); return; }
   fwSetCss(this.card, "display", "block"); fwSetCss(this.card, "left", x0 + "px"); fwSetCss(this.card, "top", y0 + "px");
   // el texto se escribe solo (60 caracteres/s o mas); las cifras «giran» antes de fijarse
   var sp = this.cardSpans, tot2 = 0; for (i = 0; i < sp.length; ++i) tot2 += sp[i].line.t.length;
   var nC = Math.floor((t - 0.55) * Math.max(60, tot2 / 1.6));
   this.cardReadSt.started = (t - 0.55) >= 0.4;     // (14-nov, P11a) como painter.cardRead.started de PixInsight (fv_hud.js): el texto ya empezo a escribirse = arranca el reloj de lectura del tour
   this.cardReadSt.typed = nC >= tot2; this.cardReadSt.words = (typeof fvTourWords === "function") ? fvTourWords(sp.map(function(o) { return o.line.t; })) : Math.round(tot2 / 6);
   for (i = 0; i < sp.length; ++i) {
      var s = sp[i].line.t, shown = s.substring(0, Math.max(0, nC)), out = "";
      for (var j = 0; j < shown.length; ++j) { var ch2 = shown.charAt(j); out += (/[0-9]/.test(ch2) && j > nC - 7) ? String(Math.floor(Math.random() * 10)) : ch2; }
      if (sp[i].el.textContent !== out) sp[i].el.textContent = out;
      nC -= s.length;
   }
   this.drawCardStar(t);
};
// la portilla: el objeto sobre negro, en un circulo con aro de laton (CSS), retícula fina dorada. (F3c) Sin lineas de barrido ni barra que
// cruza (se leian como pantalla de ordenador, no como instrumento del XIX). La estrella crece con un pulso suave al abrirse la ficha.
FWCockpit.prototype.drawCardStar = function(t) {
   var cv = this.cardCanvas, g = cv.getContext("2d"), W = cv.width, H = cv.height, c = this.cardRgb || [255, 240, 220];
   g.clearRect(0, 0, W, H);
   g.save(); g.beginPath(); g.arc(W / 2, H / 2, W / 2, 0, 2 * Math.PI); g.clip();
   var bg = g.createRadialGradient(W * 0.45, H * 0.4, 0, W / 2, H / 2, W * 0.6); bg.addColorStop(0, "#1a1410"); bg.addColorStop(1, "#050403");
   g.fillStyle = bg; g.fillRect(0, 0, W, H);
   if (this.cardSel && this.cardSel.kind === "nebula" && this.cardNebImg) { var im = this.cardNebImg, sc = Math.max(W / im.width, H / im.height); g.drawImage(im, (W - im.width * sc) / 2, (H - im.height * sc) / 2, im.width * sc, im.height * sc); }
   // (Blender 1, 5-nov) un EXOPLANETA: su mundo a la fase vista desde la nave (web/fw_pl_view.js); con FW_PL3D.ON false no entra
   // (Blender 3 · D7) con el mundo, la cruz es la de PixInsight: brazos cortos por fuera del planeta, sin los que ocupa un rotulo (fwPlCross)
   else if (typeof fwPlCardPlanet === "function" && fwPlCardPlanet(g, this.cardSel, W, H, t)) { fwPlCross(g, W, H, FW_PL_CARD.last && FW_PL_CARD.last.skip); g.restore(); return; }
   // (W1, 6-nov) la portilla de PixInsight (web/fw_card_pi.js: sprite de la protagonista, barrido, grano y marcas); si no, la de antes
   // (Blender 3 · D4) la de una estrella con planeta: su estrella y, encima, el mundo en un recuadro (fwPlCardInset; apagado no pinta nada)
   else if (this.cardSel && this.cardSel.kind === "star" && typeof fwCardPiPorthole === "function" && fwCardPiPorthole(g, W, H, this.cardRgb, t)) { if (typeof fwPlCardInset === "function") fwPlCardInset(g, this.cardSel, W, H, t); g.restore(); return; }
   else {
      var k = 0.85 + 0.15 * fvSmooth(t / 0.8), gr = g.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, W * 0.46 * k), cs = "rgba(" + c[0] + "," + c[1] + "," + c[2] + ",";
      gr.addColorStop(0, "rgba(255,255,250,1)"); gr.addColorStop(0.08, cs + "1)"); gr.addColorStop(0.3, cs + ".42)"); gr.addColorStop(1, cs + "0)");
      g.fillStyle = gr; g.fillRect(0, 0, W, H);
   }
   g.strokeStyle = "rgba(229,181,63,.55)"; g.lineWidth = 0.8; g.beginPath(); g.moveTo(W / 2, 4); g.lineTo(W / 2, H * 0.36); g.moveTo(W / 2, H * 0.64); g.lineTo(W / 2, H - 4); g.moveTo(4, H / 2); g.lineTo(W * 0.36, H / 2); g.moveTo(W * 0.64, H / 2); g.lineTo(W - 4, H / 2); g.stroke();
   if (this.cardSel && this.cardSel.kind === "star" && typeof fwPlCardInset === "function") fwPlCardInset(g, this.cardSel, W, H, t);
   g.restore();
};
