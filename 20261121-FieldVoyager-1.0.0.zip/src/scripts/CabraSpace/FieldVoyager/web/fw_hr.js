// ============================================================================
// FieldVoyager/web/fw_hr.js — (I2, 19-nov-2026) EL BOTON «DIAGRAMA HR» EN EL VISOR DEL NAVEGADOR
// ----------------------------------------------------------------------------
// Nino: «Un botón diagrama HR que, al pulsarlo, las estrellas se muevan a un diagrama HR que aparezca en la pantalla, de forma dinámica.»
// Gemelo de src/ui/fv_hr_ui.js (PixInsight). El motor es el MISMO: engine/fv_hr.js (que estrella entra, donde cae, ejes, rotulos, escalonado,
// trayectoria, textos EN/ES). Aqui solo lo del navegador:
//   · el boton de la botonera (fwHrBtn, fwHrIcon: el mismo dibujo que fvHrEngrave) — fw_cockpit.js lo añade si FW_HR.ON;
//   · el estado (FW_HR_ST) y su reloj (fwHrStep, lo llama fwStep: tambien grabando video, a reloj fijo);
//   · la GPU: cada estrella lleva su punto del diagrama en el atributo aHr (fwHrUpload) y el sombreador de estrellas de fw_gl.js la mueve con el
//     avance uHrK (fwHrPre lo pone antes de cada fotograma); el velo sobre la foto (fwHrVeilGl) va debajo de las estrellas;
//   · los ejes y rotulos en el lienzo 2D de la pantalla (fwHrOverlay) y el raton (fwHrMove, fwHrClick: la ficha de siempre).
// FW_HR.ON = false (o ?hr=0 en la direccion): sin boton y sin nada (uHrK se queda en 0 y el sombreador no cambia nada). ES5.
// ============================================================================

var FW_HR = { ON: (function() { try { return !/[?&]hr=0/.test(location.search); } catch (e) { return true; } })() };
// (11b, 20-nov) ?hrveil=0 en la direccion (NO ?veil=: ya es el velo de la llegada, fw_box.js): el velo de antes (0,72) en vez del aligerado (FV_HR.VEIL_LIGHT)
try { if (/[?&]hrveil=0/.test(location.search)) FV_HR.VEIL_FIX = false; } catch (eVeil) {}
var FW_HR_ST = null;       // el diagrama vivo: { k, dir, t, model, vis, nVis, hover, rect, … } | null

function fwHrOn() { return FW_HR.ON !== false && typeof fvHrBuild === "function" && typeof FV_HR !== "undefined" && FV_HR.ON && typeof FW !== "undefined" && !!FW.scene && !!FW.scene.stars; }
function fwHrTx(key, params) {
   var L = (typeof FW_LANG !== "undefined" && FW_LANG === "es") ? "es" : "en", s = (typeof FV_HR_TX !== "undefined" && FV_HR_TX[L][key]) || key;
   if (params) for (var k in params) if (params.hasOwnProperty(k)) s = s.split("{" + k + "}").join(String(params[k]));
   return s;
}
// la entrada de la botonera (fw_cockpit.js, FW_BTNS) y su icono: los dos ejes, la secuencia principal en diagonal, las gigantes y dos enanas blancas
function fwHrBtn() {
   var T = (typeof FV_HR_TX !== "undefined") ? FV_HR_TX : { en: {}, es: {} };
   return { id: "hr", en: T.en["lab.hr"] || "HR", es: T.es["lab.hr"] || "HR", tip: [T.en["tip.hr"] || "HR diagram", T.es["tip.hr"] || "Diagrama HR"] };
}
function fwHrIcon(st, hair, dot) {
   st("M -12 -13 L -12 11 L 14 11");
   var d = "", k;
   for (k = 0; k < 4; ++k) d += "M -12 " + (-9 + 6 * k) + " L -14 " + (-9 + 6 * k) + " M " + (-6 + 6 * k) + " 11 L " + (-6 + 6 * k) + " 13 ";
   for (k = 0; k <= 12; ++k) { var t = k / 12; d += (k ? "L " : "M ") + (-8.5 + 20 * t).toFixed(2) + " " + (-10 + 17.5 * t + 2.2 * Math.sin(Math.PI * t)).toFixed(2) + " "; }
   hair(d);
   var P = [[-8.5, -10, 1.5], [-5, -6.3, 1.25], [-1.5, -2.6, 1.15], [2, 0.9, 1.05], [5.5, 4.2, 0.95], [9, 6.4, 0.85], [11.5, 7.5, 0.8], [4, -8.5, 1.5], [8, -10.5, 1.7], [11.5, -8, 1.3], [-7.5, 6.5, 0.8], [-4.5, 8, 0.75]];
   for (k = 0; k < P.length; ++k) dot(P[k][0], P[k][1], P[k][2]);
}

function fwHrModel() {
   var sc = FW.scene, key = sc.stars.n + "|" + (FV_HR.DEREDDEN ? 1 : 0);
   if (!sc._hr || sc._hrKey !== key) { sc._hr = fvHrBuild(sc.stars); sc._hrKey = key; sc._hrUp = false; }
   return sc._hr;
}
// el punto de cada estrella a la GPU: (u, v, orden de salida, brillo en el diagrama; −1 = no va)
function fwHrUpload(R, M) {
   if (!R || !R.aHr) return false;
   var a = R.aHr.array, n = Math.min(M.n, a.length / 4);
   for (var i = 0; i < n; ++i) { a[4 * i] = M.ok[i] ? M.u[i] : 0; a[4 * i + 1] = M.ok[i] ? M.v[i] : 0; a[4 * i + 2] = M.delay[i]; a[4 * i + 3] = M.ok[i] ? M.alpha[i] : -1; }
   R.aHr.needsUpdate = true;
   return true;
}
function fwHrToggle() {
   if (!fwHrOn() || !FW.P) return false;
   if (FW_HR_ST) { FW_HR_ST.dir = -1; FW_HR_ST.done = false; return true; }
   if (FW.P.flight) return false;
   var st = fvHrStateNew(); st.model = fwHrModel(); st.vis = []; st.nVis = 0; st.hover = -1; st.visKey = "";
   if (!FW.scene._hrUp) FW.scene._hrUp = fwHrUpload(FW.R, st.model);
   FW_HR_ST = st;
   if (st.model.nOk === 0 && typeof fwCaption === "function") fwCaption(fwHrTx("hr.none"), 3.2);
   return true;
}
function fwHrEnd() { FW_HR_ST = null; if (FW.R && FW.R.uStar && FW.R.uStar.uHrK) { FW.R.uStar.uHrK.value = 0; FW.R.uStar.uHrA.value = 0; } }
// el reloj (fwStep): un viaje en marcha saca del diagrama
function fwHrStep(dt) {
   var st = FW_HR_ST; if (!st) return;
   if (FW.P && FW.P.flight) { fwHrEnd(); return; }
   fvHrStateStep(st, dt);
   if (st.done) fwHrEnd();
}
function fwHrHold() { return !!FW_HR_ST; }
function fwHrEsc() { if (!FW_HR_ST) return false; if (FW_HR_ST.dir >= 0) fwHrToggle(); return true; }
// antes de cada fotograma: el avance y el recuadro, en px del destino de la GPU (origen en el centro, y hacia arriba)
function fwHrPre() {
   var R = FW.R; if (!R || !R.uStar || !R.uStar.uHrK) return;
   var U = R.uStar, st = FW_HR_ST;
   if (!st || !(st.k > 0)) { U.uHrK.value = 0; U.uHrA.value = 0; return; }
   var r = fvHrRect(FW.VW, FW.VH), kx = R.W / FW.VW, ky = R.H / FW.VH, s = st.k;
   st.rect = r;
   U.uHrK.value = st.k; U.uHrA.value = s * s * (3 - 2 * s);
   U.uHrStag.value = FV_HR.STAGGER; U.uHrArc.value = FV_HR.ARC; U.uHrDim.value = FV_HR.DIM;
   // los mismos topes que PixInsight (fvLookParams): nivel LEV_CAP -> sigma, nivel LEV_FLOOR -> intensidad, nivel LEV_REST -> sigma de las que se quedan
   var cap = fvLookParams(FV_HR.LEV_CAP), fl = fvLookParams(FV_HR.LEV_FLOOR), rest = fvLookParams(FV_HR.LEV_REST);
   U.uHrSig.value = cap.sigma / FV_LOOK.SIGMA0; U.uHrFloor.value = fl.I; U.uHrRest.value = rest.sigma / FV_LOOK.SIGMA0;
   U.uHrO.value.set((r.x - FW.VW / 2) * kx, (FW.VH / 2 - r.y) * ky); U.uHrS.value.set(r.w * kx, -r.h * ky);
}
// el velo sobre la foto (debajo de las estrellas): un cuadro negro con alfa sobre el destino principal
function fwHrVeilGl(R) {
   var st = FW_HR_ST; if (!st || !(st.k > 0) || !(fvHrVeilK() > 0)) return;
   var T = THREE;
   if (!R.hrVeilMat) R.hrVeilMat = new T.RawShaderMaterial({ vertexShader: FW_SH_QUAD_V, fragmentShader: "precision highp float;\nin vec2 vUv;\nuniform float uA;\nlayout(location = 0) out vec4 oC;\nvoid main() { oC = vec4(0.0235, 0.0196, 0.0314, uA); }",
      uniforms: { uA: { value: 0 } }, glslVersion: T.GLSL3, depthTest: false, depthWrite: false, transparent: true, blending: T.NormalBlending });
   R.hrVeilMat.uniforms.uA.value = fvHrVeilK() * fvHrAxesAlpha(st.k);
   R.pass(R.hrVeilMat, R.rt.main);
}

// LAS ESTRELLAS DEL DIAGRAMA y donde estan (para el cursor): las de la vista (± 80 px, delante de la camara) que se ven (fundido por magnitud)
function fwHrVisible() {
   var st = FW_HR_ST, P = FW.P; if (!st || !st.rect) return;
   var c = P.cam, key = FW.VW + "|" + FW.VH + "|" + c.pos.join(",") + "|" + c.look.join(",") + "|" + c.fov;
   if (st.visKey === key) return;
   st.visKey = key; st.nVis = 0;
   var M = st.model, S = (typeof fwTimeStars === "function") ? fwTimeStars(FW.scene) : FW.scene.stars, pr = fvProjector(c, FW.VW, FW.VH), lim = fvLookLimits(c.fov, P.homeFov || c.fov), aMin = FV_LOOK.A_MIN || 1 / 32, r = st.rect;
   for (var i = 0; i < M.n; ++i) {
      if (!M.ok[i]) continue;
      var q = pr.project([S.x[i], S.y[i], S.z[i]]);
      if (!q || q[0] < -80 || q[1] < -80 || q[0] > FW.VW + 80 || q[1] > FW.VH + 80) continue;
      var dc = Math.sqrt(Math.pow(S.x[i] - c.pos[0], 2) + Math.pow(S.y[i] - c.pos[1], 2) + Math.pow(S.z[i] - c.pos[2], 2));
      if (fvLookAlpha(fvApparentMag(S.g[i], S.dEarth[i], dc), lim) < aMin) continue;
      var n = st.nVis; st.vis[n] = i; st.vis[n + 1] = r.x + M.u[i] * r.w; st.vis[n + 2] = r.y + M.v[i] * r.h; st.nVis = n + 3;
   }
}
function fwHrAnchor(i) {
   var st = FW_HR_ST; if (!st || !(st.k >= 1) || !st.model.ok[i] || !st.rect) return null;
   return [st.rect.x + st.model.u[i] * st.rect.w, st.rect.y + st.model.v[i] * st.rect.h];
}
// el cursor sobre la pantalla (px de la vista): apunta la estrella de debajo
function fwHrMove(x, y) {
   var st = FW_HR_ST; if (!st) return;
   if (!(st.k >= 1) || st.dir !== 0) { st.hover = -1; return; }
   fwHrVisible();
   st.hover = fvHrPickIn(st.vis, st.nVis, x, y, FV_HR.PICK_PX * FW.VW / 1280);
   st.mx = x; st.my = y;
}
// un clic con el diagrama puesto: sobre un punto, su ficha (la de siempre); en el resto, nada. -> true = el clic es del diagrama
function fwHrClick(x, y) {
   var st = FW_HR_ST; if (!st) return false;
   if (st.k >= 1 && st.dir === 0) { fwHrVisible(); var i = fvHrPickIn(st.vis, st.nVis, x, y, FV_HR.PICK_PX * FW.VW / 1280); if (i >= 0 && typeof fwSelectSel === "function") fwSelectSel({ kind: "star", i: i }, true); }
   return true;
}
function fwHrNum(x, dec) { var s = x.toFixed(dec); if (x < 0) s = "−" + s.substring(1); return (FW_LANG === "es") ? s.replace(".", ",") : s; }
function fwHrThousands(n) { var s = String(Math.round(n)), o = ""; while (s.length > 3) { o = (FW_LANG === "es" ? " " : ",") + s.substring(s.length - 3) + o; s = s.substring(0, s.length - 3); } return s + o; }
function fwHrRgba(rgb, a) { return "rgba(" + ((rgb >> 16) & 255) + "," + ((rgb >> 8) & 255) + "," + (rgb & 255) + "," + Math.max(0, Math.min(1, a)).toFixed(3) + ")"; }

// LOS EJES Y ROTULOS en el lienzo de la pantalla (despues de fw_cockpit drawHud, que lo limpia): el mismo dibujo que fvHrPaint de PixInsight
function fwHrOverlay(now) {
   var st = FW_HR_ST; if (!st || !(st.k > 0) || !st.rect) { if (FW_HR.tipEl && FW_HR.tipEl.title) FW_HR.tipEl.title = ""; return; }
   var hud = document.getElementById("hud"); if (!hud) return;
   var a = fvHrAxesAlpha(st.k); if (a < 0.01) return;
   var g = hud.getContext("2d"), W = FW.VW, H = FW.VH, dpr = hud.width / Math.max(1, W), M = st.model, R = M.range, r = st.rect, u = W / 1280, x0 = r.x, y0 = r.y, x1 = r.x + r.w, y1 = r.y + r.h, i;
   var GOLD = 0xE5B53F, PALE = 0xFFF3C4, IVORY = 0xF4ECDC, DARK = 0x110D09, SERIF = "'Cormorant Garamond', Georgia, serif";
   function tx(c) { return x0 + fvHrNorm(R, c, R.m0)[0] * r.w; }
   function ty(m) { return y0 + fvHrNorm(R, R.c0, m)[1] * r.h; }
   function line(xa, ya, xb, yb) { g.beginPath(); g.moveTo(xa, ya); g.lineTo(xb, yb); g.stroke(); }
   function font(px, style, ls) { g.font = (style ? style + " " : "") + Math.max(9, Math.round(px)) + "px " + SERIF; if ("letterSpacing" in g) g.letterSpacing = (ls || 0) + "px"; }
   g.save(); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.lineCap = "butt"; g.textBaseline = "alphabetic";
   st.tips = [];
   g.strokeStyle = fwHrRgba(GOLD, 0.85 * a); g.lineWidth = Math.max(1, 1.1 * u); g.strokeRect(x0, y0, r.w, r.h);
   g.strokeStyle = fwHrRgba(GOLD, 0.30 * a); g.lineWidth = Math.max(0.6, 0.6 * u); g.strokeRect(x0 - 4 * u, y0 - 4 * u, r.w + 8 * u, r.h + 8 * u);
   var T = fvHrTicks(R), tl = 5 * u, fpx = 11.5 * u;
   g.strokeStyle = fwHrRgba(GOLD, 0.10 * a);
   for (i = 0; i < T.c.length; ++i) if (Math.abs(T.c[i] - Math.round(T.c[i])) < 1e-6 && T.c[i] > R.c0 && T.c[i] < R.c1) line(tx(T.c[i]), y0, tx(T.c[i]), y1);
   for (i = 0; i < T.m.length; ++i) if (T.m[i] % 4 === 0 && T.m[i] > R.m0 && T.m[i] < R.m1) line(x0, ty(T.m[i]), x1, ty(T.m[i]));
   font(fpx); g.textAlign = "center";
   for (i = 0; i < T.c.length; ++i) {
      var X = tx(T.c[i]), whole = Math.abs(T.c[i] - Math.round(T.c[i])) < 1e-6;
      g.strokeStyle = fwHrRgba(GOLD, 0.85 * a); g.lineWidth = Math.max(0.8, 0.9 * u); line(X, y1, X, y1 + (whole ? tl : 0.55 * tl));
      if (whole) { g.fillStyle = fwHrRgba(PALE, 0.9 * a); g.fillText(fwHrNum(T.c[i], 0), X, y1 + tl + 0.8 * fpx + 2 * u); }
   }
   g.textAlign = "right";
   for (i = 0; i < T.m.length; ++i) {
      var Y = ty(T.m[i]), big = (T.m[i] % 4 === 0);
      g.strokeStyle = fwHrRgba(GOLD, 0.85 * a); line(x0 - (big ? tl : 0.55 * tl), Y, x0, Y);
      if (big) { g.fillStyle = fwHrRgba(PALE, 0.9 * a); g.fillText(fwHrNum(T.m[i], 0), x0 - tl - 4 * u, Y + 0.3 * fpx); }
   }
   g.textAlign = "center";
   var lastX = -1e9;
   for (i = 0; i < T.teff.length; ++i) {
      var Xt = tx(T.teff[i].c), s2 = fwHrThousands(T.teff[i].teff), w2 = g.measureText(s2).width;
      g.strokeStyle = fwHrRgba(GOLD, 0.85 * a); line(Xt, y0 - tl, Xt, y0);
      if (Xt - w2 / 2 < lastX + 6 * u) continue;
      g.fillStyle = fwHrRgba(PALE, 0.9 * a); g.fillText(s2, Xt, y0 - tl - 3 * u); lastX = Xt + w2 / 2;
   }
   // titulos de los ejes y extremos
   var hT = 11 * u, yX = y1 + tl + 0.8 * fpx + 2 * u + hT + 8 * u, yT = y0 - tl - 3 * u - 0.8 * fpx - 7 * u;
   font(11 * u, "600", 1.6 * u); g.fillStyle = fwHrRgba(GOLD, a);
   g.fillText(fwHrTx("hr.x"), (x0 + x1) / 2, yX); g.fillText(fwHrTx("hr.t"), (x0 + x1) / 2, yT);
   st.tips.push({ id: "hr-t", x0: x0, y0: yT - hT - 2 * u, x1: x1, y1: y0 - 1 });
   font(9.5 * u, "600", 1.4 * u); g.fillStyle = fwHrRgba(GOLD, 0.62 * a);
   g.textAlign = "left"; g.fillText(fwHrTx("hr.hot"), x0, yX); g.textAlign = "right"; g.fillText(fwHrTx("hr.cool"), x1, yX);
   var xL = x0 - tl - 4 * u - 2.2 * fpx - 10 * u;
   g.save(); g.translate(xL, (y0 + y1) / 2); g.rotate(-Math.PI / 2);
   font(11 * u, "600", 1.6 * u); g.fillStyle = fwHrRgba(GOLD, a); g.textAlign = "center"; g.fillText(fwHrTx("hr.y"), 0, 0);
   font(9.5 * u, "600", 1.4 * u); g.fillStyle = fwHrRgba(GOLD, 0.62 * a); g.textAlign = "right"; g.fillText(fwHrTx("hr.bright"), r.h / 2, 0); g.textAlign = "left"; g.fillText(fwHrTx("hr.faint"), -r.h / 2, 0);
   g.restore();
   // el titulo y la cuenta
   var ttl = fwHrTx("hr.title"), cnt = fwHrTx("hr.count", { n: fwHrThousands(M.nOk), N: fwHrThousands(M.n) }), yH = yT - hT - 12 * u, yC = yX + fpx + 9 * u;
   font(16 * u, "600", 3.2 * u); g.textAlign = "center"; g.fillStyle = fwHrRgba(PALE, a); g.fillText(ttl, (x0 + x1) / 2, yH);
   var wT = g.measureText(ttl).width;
   font(fpx); g.fillStyle = fwHrRgba(IVORY, 0.72 * a); g.fillText(cnt, (x0 + x1) / 2, yC);
   st.tips.push({ id: "hr-title", x0: (x0 + x1) / 2 - wT / 2 - 8 * u, y0: yH - 16 * u, x1: (x0 + x1) / 2 + wT / 2 + 8 * u, y1: yH + 6 * u });
   st.tips.push({ id: "hr-title", x0: x0, y0: y1 + 2, x1: x1, y1: yC + 5 * u });
   // rotulos de region y el Sol, con el diagrama casi entero
   var aL = a * fvSmooth((st.k - 0.7) / 0.3);
   if (aL > 0.02) {
      font(12.5 * u, "italic"); g.textAlign = "left";
      var lk = r.x + "|" + r.y + "|" + r.w + "|" + r.h + "|" + FW_LANG;
      if (st.labKey !== lk) { st.labels = fvHrPlaceLabels(M, r, function(key) { return { w: g.measureText(fwHrTx("hr." + key)).width + 6 * u, h: 15 * u }; }, 3 * u); st.labKey = lk; }
      for (i = 0; i < st.labels.length; ++i) {
         var lb = st.labels[i], sL = fwHrTx("hr." + lb.key);
         g.fillStyle = fwHrRgba(DARK, 0.9 * aL); g.fillText(sL, lb.x + 3 * u + 1, lb.y + 11 * u + 1);
         g.fillStyle = fwHrRgba(IVORY, 0.82 * aL); g.fillText(sL, lb.x + 3 * u, lb.y + 11 * u);
      }
      var su = fvHrNorm(R, FV_HR.SUN[0], FV_HR.SUN[1]);
      if (su[0] > 0.02 && su[0] < 0.98 && su[1] > 0.02 && su[1] < 0.98) {
         var sxp = x0 + su[0] * r.w, syp = y0 + su[1] * r.h, rs = 5.5 * u, sS = fwHrTx("hr.sun");
         g.beginPath(); g.arc(sxp, syp, rs, 0, 2 * Math.PI); g.strokeStyle = fwHrRgba(DARK, 0.9 * aL); g.lineWidth = Math.max(2.2, 2.6 * u); g.stroke();
         g.strokeStyle = fwHrRgba(PALE, 0.95 * aL); g.lineWidth = Math.max(1, 1.1 * u); g.stroke();
         g.beginPath(); g.arc(sxp, syp, Math.max(1, 1.3 * u), 0, 2 * Math.PI); g.fillStyle = fwHrRgba(PALE, 0.95 * aL); g.fill();
         g.textAlign = "right"; g.fillStyle = fwHrRgba(DARK, 0.9 * aL); g.fillText(sS, sxp - rs - 5 * u + 1, syp + 4 * u + 1); g.fillStyle = fwHrRgba(PALE, 0.9 * aL); g.fillText(sS, sxp - rs - 5 * u, syp + 4 * u);
         st.tips.push({ id: "hr-sun", x0: sxp - rs - 6 * u - g.measureText(sS).width, y0: syp - rs - 2 * u, x1: sxp + rs + 2 * u, y1: syp + rs + 2 * u });
      }
   }
   // la estrella bajo el cursor: anillo y su nombre con sus dos numeros (si su ficha ya esta abierta, no: diria lo mismo dos veces)
   var hovCard = !!(FW.ck && FW.ck.cardSel && FW.ck.cardSel.kind === "star" && FW.ck.cardSel.i === st.hover && !FW.ck.cardHidden);
   if (st.hover >= 0 && M.ok[st.hover] && !hovCard) {
      var hx = r.x + M.u[st.hover] * r.w, hy = r.y + M.v[st.hover] * r.h;
      g.beginPath(); g.arc(hx, hy, 8 * u, 0, 2 * Math.PI); g.strokeStyle = fwHrRgba(DARK, 0.9 * a); g.lineWidth = Math.max(2.4, 3 * u); g.stroke();
      g.strokeStyle = fwHrRgba(PALE, a); g.lineWidth = Math.max(1.1, 1.3 * u); g.stroke();
      if (st.hoverI !== st.hover) { st.hoverI = st.hover; st.hoverTxt = fwHrHoverText(M, st.hover); }
      font(13 * u); g.textAlign = "left";
      var wC = g.measureText(st.hoverTxt).width + 14 * u, hC = 22 * u, bx = hx + 13 * u, by = hy - hC - 6 * u;
      if (bx + wC > W - 6) bx = hx - 13 * u - wC; if (by < 6) by = hy + 12 * u;
      g.fillStyle = fwHrRgba(DARK, 0.88 * a); g.fillRect(bx, by, wC, hC);
      g.strokeStyle = fwHrRgba(GOLD, 0.8 * a); g.lineWidth = Math.max(0.8, 0.9 * u); g.strokeRect(bx, by, wC, hC);
      g.fillStyle = fwHrRgba(IVORY, a); g.fillText(st.hoverTxt, bx + 7 * u, by + 15 * u);
   }
   g.restore();
   // tooltips (texto largo): el titulo del lienzo de la pantalla segun donde este el cursor
   var tipEl = FW_HR.tipEl || (FW_HR.tipEl = document.getElementById("win")), tip = "";
   if (tipEl && st.hover < 0 && st.mx !== undefined) for (i = 0; i < st.tips.length; ++i) if (st.mx >= st.tips[i].x0 && st.mx <= st.tips[i].x1 && st.my >= st.tips[i].y0 && st.my <= st.tips[i].y1) { tip = fwHrTipText(st.tips[i].id, M); break; }
   if (tipEl && tipEl.title !== tip) tipEl.title = tip;
   st.stats = { k: st.k, nOk: M.nOk, n: M.n, rect: [r.x, r.y, r.w, r.h], labels: (st.labels || []).map(function(l) { return l.key; }) };
}
function fwHrTipText(id, M) { return id === "hr-title" ? fwHrTx("hr.tipTitle") + (M.dereddened ? fwHrTx("hr.tipDust") : "") : fwHrTx(id === "hr-t" ? "hr.tipT" : "hr.tipSun"); }
// el rotulo de la estrella bajo el cursor: su nombre (el de la ficha), M y BP−RP
function fwHrHoverText(M, i) {
   var name = "";
   try { var C = (typeof fvCardContent === "function") ? fvCardContent(FW.scene, { kind: "star", i: i }, FW_LANG) : null; if (C && C.title) name = String(C.title); } catch (e) { name = ""; }
   return (name ? name + "  ·  " : "") + "M " + fwHrNum(M.absMag[i], 1) + "  ·  BP − RP " + fwHrNum(M.color[i], 2);
}
// el raton sobre la pantalla (sin arrastrar): lo engancha una vez
function fwHrBind(win) {
   if (!win || FW_HR.bound) return; FW_HR.bound = true;
   win.addEventListener("pointermove", function(e) { if (!FW_HR_ST) return; var b = win.getBoundingClientRect(); fwHrMove(e.clientX - b.left, e.clientY - b.top); });
   win.addEventListener("pointerleave", function() { if (FW_HR_ST) { FW_HR_ST.hover = -1; FW_HR_ST.mx = undefined; } });
}
