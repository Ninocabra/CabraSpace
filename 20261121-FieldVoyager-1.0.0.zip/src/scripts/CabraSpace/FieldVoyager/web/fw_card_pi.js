// ============================================================================
// FieldVoyager/web/fw_card_pi.js — LA FICHA DEL VISOR WEB = LA DE PIXINSIGHT (W1, 6-nov-2026)
// ----------------------------------------------------------------------------
// Nino: «al pulsar una estrella en la web no sale la misma ficha que en PixInsight». La web tenia su propio texto (fwCardLines: distancia,
// Teff, fuente de la Teff, linea de calidad, frases sueltas) y PixInsight otro (fvCardContent de src/ui/fv_hud.js: tipo, distancia con su
// horquilla, temperatura, polvo, fecha de la luz con su error, metalicidad; MÁS con luminosidad, radio, masa, vida, color verdadero,
// composicion, viaje y notas). Ahora el texto sale de la MISMA funcion: el paquete lleva ui/fv_text.js y ui/fv_hud.js (fvExportScene;
// refreshPackage en las pruebas) y aqui solo se traduce su resultado a las lineas que pinta FWCockpit.showCard:
//   titulo · subtitulo · sello (palabra · fuente) · l1 (el resumen, la linea de metalicidad en el color de su fiabilidad) · l2 en MÁS
// El paquete trae la metalicidad como meta.sci.metal (la ficha de PixInsight) o meta.mhP (GSP-Phot del refinado): fvCardMetal lee
// m.mhPhot / m.mhPhotT, asi que se le da { mhPhot: mhP, mhPhotT: 5000 } (la regla del encargo: fvsMetalBuild(chem, { v: mhP, teff: 5000 }, teff)).
// Precarga (Nino: «al empezar el viaje ve pidiendo toda la informacion de la estrella; al llegar la muestras sin esperar»): el visor NO
// pide nada a la red, todo viaja en el paquete; lo unico que cuesta es componer el texto (fvsStar + frases, ~1 ms) y se hace al empezar el
// viaje (fwCardPiPrefetch, cache por estrella e idioma), de modo que al llegar la ficha sale ya hecha.
// FW_CARD_PI = false: la ficha web de antes (el ROJO de tests/web/fv_W1_ficha_cdp.js).
// ES5.
// ============================================================================

var FW_CARD_PI = true;
// (3b, 20-nov) ?hip=0 en la direccion: el rotulo de la estrella sin su nombre de Hipparcos (lo de antes: «Gaia DR3 J…»)
try { if (/[?&]hip=0/.test(location.search) && typeof FV_HIPD_CARD !== "undefined") FV_HIPD_CARD = false; } catch (eHip) {}
var FW_CARD_PI_C = { key: "", C: null, cache: {} };

function fwCardPiOn() { return FW_CARD_PI === true && typeof fvCardContent === "function" && typeof fvTx === "function" && typeof FV_TX !== "undefined"; }

// el contenido de PixInsight para s ({ kind: "star", i } o { kind: "nebula" }); null si no se puede (sin ui/ en el paquete).
// La cache SOLO la llena la precarga (store) y se gasta una vez (take): una ficha que se vuelve a abrir se compone de nuevo (~1 ms) con lo
// que haya entonces en la escena (idioma, nombres, datos)
function fwCardPiContent(s, lang, store, take) {
   if (!fwCardPiOn() || !s || !FW.scene) return null;
   var L = lang || FW_LANG, sc = FW.scene, key = s.kind + ":" + (s.i === undefined ? "" : s.i) + ":" + L;
   if (take && FW_CARD_PI_C.cache[key]) { var Cc = FW_CARD_PI_C.cache[key]; delete FW_CARD_PI_C.cache[key]; FW_CARD_PI_C.fromCache = true; return Cc; }
   FW_CARD_PI_C.fromCache = false;
   if (s.kind !== "star" && !(s.kind === "nebula" && sc.nebula)) return null;
   // el idioma de la nave (fvTx/fvNum lo toman de FV_LANG si no se les pasa)
   window.FV_LANG = L;
   if (s.kind === "star") {
      var m = sc.stars.meta[s.i];
      if (!m) return null;
      if (m.mhP !== undefined && m.mhP !== null && m.mhPhot === undefined) { m.mhPhot = m.mhP; m.mhPhotT = 5000; }
   }
   if (!sc.field) sc.field = {};
   var C = null;
   try { C = fvCardContent(sc, s, L, null); } catch (e) { if (window.console) console.warn("fw_card_pi: " + e); C = null; }
   if (C && store) FW_CARD_PI_C.cache[key] = C;
   return C;
}

// las lineas para FWCockpit.showCard (mismas clases que fwCardLines: «title», el primer «dim» = subtitulo, el primer ok/warn/bad = sello)
function fwCardPiLines(s) {
   var C = fwCardPiContent(s, FW_LANG, false, true);
   if (!C) { FW_CARD_PI_C.C = null; return null; }
   FW_CARD_PI_C.C = C; FW_CARD_PI_C.key = s.kind + ":" + s.i;
   var out = [{ t: C.title, c: "title" }, { t: C.sub, c: "mono dim" }];
   if (C.stamp && C.stamp.word) {
      var g = C.stamp.col === FV_HUD_COL.stampOk ? "ok" : (C.stamp.col === FV_HUD_COL.stampWarn ? "warn" : "bad");
      out.push({ t: C.stamp.word + " · " + (C.stamp.src || ""), c: "mono " + g });
   }
   for (var i = 0; i < C.l1.length; ++i) {
      var isM = C.metalLine && C.l1[i] === C.metalLine;
      out.push({ t: C.l1[i], c: "pl" + (isM ? (C.metalQ === 0 ? " pl-mq0" : " pl-mq1") : "") });
   }
   return out;
}

// los detalles de MÁS (C.l2 de PixInsight) de la ficha a la vista; [] si no hay
function fwCardPiMore(sel) {
   var C = FW_CARD_PI_C.C;
   if (!C || !sel || FW_CARD_PI_C.key !== sel.kind + ":" + sel.i) return [];
   return C.l2 || [];
}

// (precarga) al empezar el viaje: el texto de la ficha de destino en los dos idiomas, a la cache
function fwCardPiPrefetch(s) {
   if (!fwCardPiOn() || !s || (s.kind !== "star" && s.kind !== "nebula")) return false;
   var t0 = performance.now(), Lk = FW_LANG;
   FW_CARD_PI_C.cache = {};
   fwCardPiContent(s, Lk, true); fwCardPiContent(s, Lk === "es" ? "en" : "es", true); window.FV_LANG = Lk;
   FW_CARD_PI_C.prefetchMs = performance.now() - t0;
   return true;
}

// el color de la portilla: el de PixInsight (fvPorthole: fvsExaggerateColour del color de la ficha C.col, el verdadero sin polvo si hay mapa,
// si no el de la foto); antes la web pintaba el cuerpo negro de la Teff (otra estrella en la portilla). null = el de antes
function fwCardPiRgb(s) {
   if (!s || s.kind !== "star") return null;
   var C = (FW_CARD_PI_C.C && FW_CARD_PI_C.key === s.kind + ":" + s.i) ? FW_CARD_PI_C.C : fwCardPiContent(s);
   if (!C || C.col === undefined || typeof fvRgbOf !== "function") return null;
   var c = fvRgbOf(C.col), ex = (typeof fvsExaggerateColour === "function") ? fvsExaggerateColour(c) : c;
   return [ex.r, ex.g, ex.b];
}

// (W1, 6-nov) LA PORTILLA COMO EN PIXINSIGHT (fvPorthole + FVPainter.heroSpriteCol): el sprite de la protagonista (disco de radio 0,16·R con el
// limbo oscurecido, brillo e^(−(ρ−1)/0,45) y e^(−(ρ−1)/2,6), espigas finas en cruz) del color de la ficha, a 1,25 veces el radio de la
// portilla y en suma; encima las lineas de barrido cada 3 px, el grano, la barra del escaner que baja y las cuatro marcas de la reticula.
// Devuelve true si la ha pintado (si no, la portilla de antes). FW_CARD_PI_PORT = false: la de antes
var FW_CARD_PI_PORT = true, FW_CARD_PI_SPR = {};
function fwCardPiSprite(rgb) {
   var key = rgb.join(","); if (FW_CARD_PI_SPR[key]) return FW_CARD_PI_SPR[key];
   var R = 128, sz = 2 * R + 1, cv = document.createElement("canvas"); cv.width = sz; cv.height = sz;
   var g = cv.getContext("2d"), im = g.createImageData(sz, sz), px = im.data, mc = Math.max(rgb[0], rgb[1], rgb[2], 1) / 255, RC = 0.16 * R;
   var c = [rgb[0] / 255 / mc, rgb[1] / 255 / mc, rgb[2] / 255 / mc];
   for (var y = 0; y < sz; ++y) for (var x = 0; x < sz; ++x) {
      var dx = x - R, dy = y - R, r = Math.sqrt(dx * dx + dy * dy), rho = r / RC, v = [0, 0, 0], q;
      if (rho < 1) { var mu = Math.sqrt(1 - rho * rho), I = 1 - 0.55 * (1 - mu); for (q = 0; q < 3; ++q) v[q] = I * (0.6 + 0.4 * c[q]) * 1.15; }
      else { var e1 = Math.exp(-(rho - 1) / 0.45), e2 = Math.exp(-(rho - 1) / 2.6), fall = Math.max(0, 1 - r / R), sp = (Math.exp(-Math.abs(dy) / 0.9) + Math.exp(-Math.abs(dx) / 0.9)) * 0.55 * fall * fall;
             for (q = 0; q < 3; ++q) v[q] = (0.95 * e1 + 0.28 * e2) * c[q] + sp * (0.5 + 0.5 * c[q]); }
      var e = fvSmooth((R - r) / (0.12 * R)), o = 4 * (y * sz + x);
      px[o] = Math.min(255, Math.round(255 * v[0] * e)); px[o + 1] = Math.min(255, Math.round(255 * v[1] * e)); px[o + 2] = Math.min(255, Math.round(255 * v[2] * e)); px[o + 3] = 255;
   }
   g.putImageData(im, 0, 0); FW_CARD_PI_SPR[key] = cv; return cv;
}
function fwCardPiHash(a, b) { var x = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453; return x - Math.floor(x); }
function fwCardPiPorthole(g, W, H, rgb, t) {
   if (!FW_CARD_PI_PORT || !fwCardPiOn() || !rgb) return false;
   var r = W / 2, cx = W / 2, cy = H / 2, k = W / 116, tc = t - 0.55, rev = fvClamp(tc / 0.9, 0, 1), scanY = 2 * r * rev, zr = r * 1.25;
   g.fillStyle = "#07060A"; g.fillRect(0, 0, W, H);
   g.globalCompositeOperation = "lighter"; g.drawImage(fwCardPiSprite(rgb), cx - zr, cy - zr, 2 * zr, 2 * zr); g.globalCompositeOperation = "source-over";
   if (rev < 1) { g.fillStyle = "rgba(7,6,10,.94)"; g.fillRect(0, scanY, W, H - scanY); }
   g.fillStyle = "rgba(0,0,0,.22)"; for (var yy = k; yy < H; yy += 3 * k) g.fillRect(0, yy, W, k);
   var seed = Math.floor(tc * 18);
   for (var n = 0; n < 90; ++n) { g.fillStyle = fwCardPiHash(n, seed + 7) > 0.5 ? "rgba(255,255,255,.19)" : "rgba(0,0,0,.25)"; g.fillRect(fwCardPiHash(n, seed) * W, fwCardPiHash(n + 300, seed) * H, k, k); }
   var sw = rev < 1 ? scanY : ((tc * 0.6) % 1) * H; g.fillStyle = "rgba(243,210,126,.5)"; g.fillRect(0, sw - k, W, 2.5 * k);
   g.strokeStyle = "rgba(229,181,63,.5)"; g.lineWidth = k; g.beginPath();
   g.moveTo(cx, 4 * k); g.lineTo(cx, 13 * k); g.moveTo(cx, H - 13 * k); g.lineTo(cx, H - 4 * k); g.moveTo(4 * k, cy); g.lineTo(13 * k, cy); g.moveTo(W - 13 * k, cy); g.lineTo(W - 4 * k, cy); g.stroke();
   return true;
}
