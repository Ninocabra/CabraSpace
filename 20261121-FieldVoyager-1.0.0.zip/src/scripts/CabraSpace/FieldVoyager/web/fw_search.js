// ============================================================================
// FieldVoyager/web/fw_search.js — EL BUSCADOR DE MIRABILIA del visor (encargo I3 de Nino, 5-nov-2026)
// ----------------------------------------------------------------------------
// Gemelo de src/ui/fv_search.js (PixInsight): MISMO nucleo (plegado de acentos y mayusculas, trozos, sin espacios, id Gaia, tipo en dos
// idiomas, orden de MIRABILIA y luego estrellas por brillo); tests/fv_nI3_node.js carga los dos y comprueba que dan lo mismo. Aqui el campo
// es un <input> de verdad (acentos, ñ, pegar, deshacer los pone el navegador) al pie de la caja MIRABILIA.
//   · al escribir, los resultados SUSTITUYEN la lista mientras hay texto (FWNav.shown; FWNav.items —la lista de verdad, que usa el TOUR— no se toca)
//   · Intro = viajar al primero · Esc o vaciar el campo = vuelve la lista · la × lo vacia · la tecla «/» lleva al campo
//   · cada resultado es una fila de la lista de siempre: clic = elegir, doble clic o la flecha = viajar (nada de caminos duplicados)
// BUSCA EN: los objetos de MIRABILIA (todos), la nebulosa y las estrellas de la foto (designacion Gaia). Nada de catalogos externos. ES5.
// ============================================================================

var FW_SEARCH = {
   MAX: 40, MAX_CHARS: 48, FOLD: true,
   TW: { pn: "nebulosa planetaria planetaria planetary nebula pn", galaxy: "galaxia galaxy", cluster: "cumulo de estrellas cumulo star cluster cluster open cluster",
         nebula: "nebulosa nebula", quasar: "cuasar quasar", star: "estrella star", exoplanet: "exoplaneta planeta exoplanet planet",
         other: "objeto object resto de supernova supernova remnant" },
   TX: { en: { ph: "search by name…", none: "No results for “{q}”", tip: "Search in MIRABILIA: a name or part of it (no capitals or accents needed: «coll», «ngc», «J0259»), a Gaia id or part of it, or a kind («cluster», «galaxy»). The results replace the list while you type; Enter travels to the first; Esc (or clearing the field) brings the list back. Key: /", clear: "Clear", star: "star" },
         es: { ph: "buscar por nombre…", none: "Sin resultados para «{q}»", tip: "Buscador de MIRABILIA: un nombre o parte de él (sin mayúsculas ni acentos: «coll», «ngc», «J0259»), un id de Gaia o parte de él, o un tipo («cúmulo», «galaxia»). Los resultados sustituyen la lista mientras escribes; Intro viaja al primero; Esc (o vaciar el campo) devuelve la lista. Tecla: /", clear: "Vaciar", star: "estrella" } }
};
function fwSearchT(k) { return FW_SEARCH.TX[(typeof FW_LANG !== "undefined" && FW_LANG === "es") ? "es" : "en"][k]; }

var FW_SEARCH_FOLD = (function() {
   var m = {}, P = ["a:àáâãäåāăą", "c:çćĉċč", "d:ďđ", "e:èéêëēĕėęě", "g:ĝğġģ", "h:ĥħ", "i:ìíîïĩīĭįı", "j:ĵ", "k:ķ", "l:ĺļľŀł", "n:ñńņňŉ", "o:òóôõöøōŏő",
                    "r:ŕŗř", "s:śŝşš", "t:ţťŧ", "u:ùúûüũūŭůűų", "w:ŵ", "y:ýÿŷ", "z:źżž"], i, j;
   for (i = 0; i < P.length; ++i) for (j = 2; j < P[i].length; ++j) m[P[i].charAt(j)] = P[i].charAt(0);
   m["ß"] = "ss"; m["æ"] = "ae"; m["œ"] = "oe";
   return m;
})();
function fwSearchFold(s) {
   var t = String(s === null || s === undefined ? "" : s).toLowerCase(), out = "", i, c, k, m, n = t.length;
   if (FW_SEARCH.FOLD === false) return t;
   for (i = 0; i < n; ++i) {
      c = t.charAt(i);
      k = t.charCodeAt(i);
      if (k < 768 || k > 879) { c = t.charAt(i); m = FW_SEARCH_FOLD[c]; out += (m !== undefined) ? m : c; }          // (los combinantes U+0300…036F se quitan)
   }
   return out;
}
function fwSearchNorm(s) { return fwSearchFold(s).replace(/\s+/g, " ").replace(/^ | $/g, ""); }
function fwSearchComp(s) {
   var t = fwSearchFold(s), out = "", i, k;
   for (i = 0; i < t.length; ++i) { k = t.charCodeAt(i); if ((k >= 48 && k <= 57) || (k >= 97 && k <= 122) || k >= 192) out += t.charAt(i); }
   return out;
}
function fwSearchClock() { return (typeof performance !== "undefined" && performance.now) ? performance.now() : (new Date).getTime(); }

// el indice (o: { lang, exo, objItem(scene, i, lang), nebItem(scene, lang) })
function fwSearchBuild(scene, o) {
   var t0 = fwSearchClock(), L = (o && o.lang === "es") ? "es" : "en", A = [], B = [], S = scene ? scene.stars : null, covered = {}, i, j, it, ob;
   if (!scene) return { ents: [], nObj: 0, nStar: 0, ms: 0, lang: L };
   function twOf(type, tl) { return fwSearchNorm((FW_SEARCH.TW[type] || FW_SEARCH.TW.other) + " " + (tl && typeof tl === "object" ? (tl.en || "") + " " + (tl.es || "") : "")); }
   function addFields(raw, list) { for (var q = 0; q < raw.length; ++q) if (raw[q] !== null && raw[q] !== undefined && raw[q] !== false && String(raw[q]).length) list.push(String(raw[q])); }
   function starFields(k, list) {
      var m = S.meta[k] || {}, ds = (isFinite(m.ra) && isFinite(m.dec) && typeof fvDesignation === "function") ? fvDesignation(m.ra, m.dec) : "";
      if (m.sourceId) list.push("Gaia DR3 " + m.sourceId); else if (ds) list.push("Gaia DR3 " + ds);
      if (ds) list.push(ds);
      if (m.name) list.push(m.name);
   }
   function mkEnt(item, rawFields, tw) {
      var f = [], c = [], q, nf;
      for (q = 0; q < rawFields.length; ++q) { nf = fwSearchNorm(rawFields[q]); if (nf.length) { f.push(nf); c.push(fwSearchComp(rawFields[q])); } }
      return { f: f, c: c, tw: tw, item: item, rank: (item.main ? 0 : (item.type === "exoplanet" ? 3 : (item.type === "star" ? 2 : 1))), score: item.score || 0, k: A.length };
   }
   if (scene.objects && scene.objects.length) {
      for (i = 0; i < scene.objects.length; ++i) {
         ob = scene.objects[i]; it = o.objItem(scene, i, L);
         var raw = [it.name], nm = ob.names;
         addFields([ob.name, ob.id && String(ob.id).replace(/^[a-z]+:/i, ""), nm && typeof nm === "object" ? nm.en : nm, nm && typeof nm === "object" ? nm.es : null], raw);
         if (ob.main && scene.nebula) { var N = scene.nebula, nn = N.names; addFields([N.name, N.id, nn && typeof nn === "object" ? nn.en : nn, nn && typeof nn === "object" ? nn.es : null], raw); }
         if (ob.planets && ob.planets.length) addFields(ob.planets, raw);
         if (ob.label) addFields([ob.label.en && ob.label.en.t, ob.label.es && ob.label.es.t, ob.label.crit], raw);      // (B, 14-nov) el rotulo («estrella mas caliente») tambien se busca, en los dos idiomas (como fv_search.js)
         if (ob.star >= 0 && S && ob.star < S.n) { var sf = []; starFields(ob.star, sf); addFields(sf, raw); if (ob.type === "star" || ob.type === "exoplanet") covered[ob.star] = true; }
         A.push(mkEnt(it, raw, twOf(it.type, ob.typeLabel)));
      }
   } else if (o.nebItem) {
      it = o.nebItem(scene, L);
      if (it) A.push(mkEnt(it, [it.name, scene.nebula && scene.nebula.name, scene.nebula && scene.nebula.id], twOf("nebula", scene.nebula && scene.nebula.typeLabel)));
   }
   var ex = o.exo || [];
   for (i = 0; i < ex.length; ++i) { var raw2 = [ex[i].name]; if (ex[i].star >= 0 && S) starFields(ex[i].star, raw2); A.push(mkEnt(ex[i], raw2, twOf("exoplanet"))); }
   A.sort(function(a, b) { return (a.rank - b.rank) || (b.score - a.score) || (a.k - b.k); });
   var twStar = twOf("star"), list = [];
   if (S) for (i = 0; i < S.n; ++i) {
      var m = S.meta[i] || {};
      if (!S.inFrame[i] || m.wide || m.outside || m.ring || covered[i]) continue;
      list.push(i);
   }
   list.sort(function(a, b) { return (S.g[a] - S.g[b]) || (a - b); });
   for (j = 0; j < list.length; ++j) {
      i = list[j]; var fl = [], f2 = [];
      starFields(i, fl);
      for (var q2 = 0; q2 < fl.length; ++q2) f2.push(fwSearchNorm(fl[q2]));
      B.push({ f: f2, c: null, tw: twStar, item: null, star: i, rank: 2, score: 0 });
   }
   return { ents: A.concat(B), nObj: A.length, nStar: B.length, ms: fwSearchClock() - t0, lang: L };
}
function fwSearchScoreField(f, q, toks) {
   var p = f.indexOf(q);
   if (p === 0) return f.length === q.length ? 100 : 90;
   if (p > 0 && f.charAt(p - 1) === " ") return 75;
   if (toks.length > 1) {
      var allWord = true, k, tp;
      for (k = 0; k < toks.length; ++k) {
         tp = f.indexOf(toks[k]);
         if (tp < 0) return p > 0 ? 50 : 0;
         if (!(tp === 0 || f.charAt(tp - 1) === " ")) allWord = false;
      }
      return allWord ? 70 : 45;
   }
   return p > 0 ? 50 : 0;
}
function fwSearchScoreEnt(e, q, qc, toks, twOk) {
   var best = 0, F = e.f, C = e.c, j, s, p;
   for (j = 0; j < F.length; ++j) { s = fwSearchScoreField(F[j], q, toks); if (s > best) best = s; }
   if (best === 0 && C && qc.length >= 2) {
      for (j = 0; j < C.length; ++j) { p = C[j].indexOf(qc); if (p >= 0) { s = (p === 0) ? 85 : 45; if (s > best) best = s; } }
   }
   if (best === 0) {
      if (twOk[e.tw] === undefined) { var ok = true, w = " " + e.tw, k; for (k = 0; k < toks.length; ++k) if (w.indexOf(" " + toks[k]) < 0) { ok = false; break; } twOk[e.tw] = ok; }
      if (twOk[e.tw]) best = 30;
      else if (C) {
         var all = F.join(" ") + " " + e.tw, ok2 = true;
         for (j = 0; j < toks.length; ++j) if (all.indexOf(toks[j]) < 0) { ok2 = false; break; }
         if (ok2) best = 20;
      }
   }
   return best;
}
// -> { q, n, items, ms } (o.starItem(k) hace el elemento de una estrella)
function fwSearchRun(idx, text, max, o) {
   var t0 = fwSearchClock(), q = fwSearchNorm(text), out = { q: q, n: 0, items: [], ms: 0 };
   if (!q || !idx) { out.ms = fwSearchClock() - t0; return out; }
   var qc = fwSearchComp(q), toks = q.split(" "), E = idx.ents, keys = [], twOk = {}, i, s, big = 1e7;
   for (i = 0; i < E.length; ++i) { s = fwSearchScoreEnt(E[i], q, qc, toks, twOk); if (s > 0) keys.push(s * big + (big - 1 - i)); }
   keys.sort(function(a, b) { return b - a; });
   out.n = keys.length;
   var mx = Math.min(keys.length, max || FW_SEARCH.MAX);
   for (i = 0; i < mx; ++i) {
      var e = E[big - 1 - (keys[i] % big)];
      out.items.push(e.item ? e.item : (o && o.starItem ? o.starItem(e.star) : { kind: "star", i: e.star, name: "?", type: "star", sub: "" }));
   }
   out.ms = fwSearchClock() - t0;
   return out;
}

// ---------------------------------------------------------------------------
// EL CAMPO (DOM): #navSearch dentro de la caja MIRABILIA, bajo la lista
// ---------------------------------------------------------------------------
function FWSearch(nav, scene) {
   var self = this;
   this.nav = nav; this.scene = scene; this.last = null; this.queryMs = [];
   this.wrap = document.getElementById("navSearch"); this.inp = document.getElementById("navSearchIn"); this.clr = document.getElementById("navSearchClr");
   if (!this.wrap || !this.inp) return;
   this.reindex();
   this.inp.placeholder = fwSearchT("ph"); this.inp.setAttribute("aria-label", fwSearchT("ph")); this.inp.maxLength = FW_SEARCH.MAX_CHARS;
   this.wrap.title = fwSearchT("tip"); this.clr.title = fwSearchT("clear"); this.clr.setAttribute("aria-label", fwSearchT("clear"));
   this.inp.addEventListener("input", function() { self.apply(); });
   this.inp.addEventListener("keydown", function(e) {
      e.stopPropagation();                                              // los mandos de vuelo no oyen lo que se escribe
      if (e.key === "Enter") { e.preventDefault(); self.enter(); }
      else if (e.key === "Escape") { e.preventDefault(); self.clear(true); }
   });
   this.inp.addEventListener("keyup", function(e) { e.stopPropagation(); });
   this.clr.addEventListener("click", function() { self.clear(false); self.inp.focus(); });
   ["pointerdown", "wheel", "dblclick"].forEach(function(t) { self.wrap.addEventListener(t, function(ev) { ev.stopPropagation(); }, { passive: true }); });
   // «/» lleva al campo (como en casi todas las webs); Esc con resultados a la vista y el campo suelto tambien los quita
   window.addEventListener("keydown", function(e) {
      if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
      if (e.key === "/" && !e.ctrlKey && !e.metaKey && !e.altKey) { e.preventDefault(); e.stopImmediatePropagation(); self.inp.focus(); }
      else if (e.key === "Escape" && self.inp.value) { e.stopImmediatePropagation(); self.clear(true); }          // (antes que el Esc de la cabina: no cierra tambien la ficha)
   }, true);
}
FWSearch.prototype.reindex = function() {
   var self = this;
   this.idx = fwSearchBuild(this.scene, { lang: (typeof FW_LANG !== "undefined" && FW_LANG === "es") ? "es" : "en", exo: [],
      objItem: function(sc, i) { return fwNavObjItem(sc, i); },
      nebItem: function(sc) { return sc.nebula ? { kind: "nebula", name: fwNameOf(sc.nebula.names || sc.nebula.name, fwNavT("neb")), type: "nebula", icon: (typeof fwNavIconKind === "function" ? fwNavIconKind("nebula", sc.nebula.typeLabel) : "nebula"), dist: sc.nebula.distLy, sub: fwNameOf(sc.nebula.typeLabel, fwNavT("neb")) + " · " + fwNavDist(sc.nebula.distLy, sc.nebula.measured ? "measured" : "assumed") } : null; } });
};
FWSearch.prototype.starItem = function(k) {
   var S = this.scene.stars, m = S.meta[k] || {};
   return { kind: "star", i: k, name: "Gaia DR3 " + (m.sourceId ? m.sourceId : fvDesignation(m.ra, m.dec)), type: "star", dist: S.dEarth[k],
            sub: fwSearchT("star") + " · G " + S.g[k].toFixed(1).replace(".", FW_LANG === "es" ? "," : ".") + " · " + fwNavDist(S.dEarth[k], S.q[k] === 0 ? "measured" : "assumed") };
};
// lo escrito → resultados (o la lista de siempre)
FWSearch.prototype.apply = function() {
   var self = this, t = this.inp.value, nav = this.nav, cap = document.getElementById("navListCap");
   this.clr.style.visibility = t ? "visible" : "hidden";
   if (!fwSearchNorm(t)) { this.last = null; nav.shown = null; nav.emptyMsg = ""; nav.buildList(); if (cap) cap.textContent = fwNavT("mir"); this.wrap.classList.remove("on"); return; }
   var r = fwSearchRun(this.idx, t, FW_SEARCH.MAX, { starItem: function(k) { return self.starItem(k); } });
   this.last = r; this.queryMs.push(r.ms); if (this.queryMs.length > 400) this.queryMs.shift();
   nav.shown = r.items; nav.emptyMsg = r.items.length ? "" : fwSearchT("none").split("{q}").join(t.trim());
   nav.buildList(); nav.listEl.scrollTop = 0;
   if (cap) cap.textContent = fwNavT("mir") + (r.items.length ? " · " + (r.n > r.items.length ? r.items.length + "+" : r.n) : "");
   this.wrap.classList.add("on");
   if (FW.P) nav.markSel(FW.P.sel);
};
FWSearch.prototype.clear = function(blur) { this.inp.value = ""; this.apply(); if (blur) this.inp.blur(); };
// Intro: viajar al primero (como su flecha)
FWSearch.prototype.enter = function() {
   var items = this.nav.shown;
   if (!this.inp.value.trim() || !items || !items.length) return false;
   var it = items[0]; this.inp.blur();
   if (this.nav.hooks.travel) this.nav.hooks.travel(fwNavSel(this.scene, it), it);
   return true;
};
