// ============================================================================
// fw_navmodes.js — LOS DOS MODOS en el visor web (6-nov-2026), gemelo de src/ui/fv_navmodes.js de PixInsight. La regla y lo que se dibuja
// salen del motor compartido (fvNmStep / fvNmHud, engine/fv_pilot.js). En ESPACIO, sobre el lienzo de la cabina (#hud):
//   · la foto FANTASMA en su plano (afin de tres esquinas: desde el Espacio la foto se ve pequeña y casi sin perspectiva), translucida,
//     y vista por detras al reves y mas apagada; nunca opacidad 0
//   · la piramide: aristas doradas finas de la Tierra al marco
//   · marcadores en el borde (TU FOTO, CASA, DESTINO), la brujula (arriba a la derecha) y el rotulo «ESPACIO · fuera de tu foto — H para volver»
//     (pulsarlo = casa, como H, el doble clic en el cielo o VISTA INICIAL)
//   (20-nov-2026, E-nav) la brujula y el marcador CASA ya NO salen de fabrica (FV_NMX, engine/fv_pilot.js; ?nmcompass=1 ?nmhome=1 los devuelven); el marcador TU FOTO se
//   PULSA: clic o doble clic en su placa, flecha o rotulo = la nave vuelve volando a la foto (fwNmGoPhoto; ?nmgo=0 = solo dibujo). Gemelo de src/ui/fv_navmodes.js
//   (20-nov-2026, O1) el marcador TU FOTO ENSEÑA UNA MINIATURA de la propia foto (la imagen «photo» que ya viaja en el paquete, reducida UNA vez al arrancar: fwNmThumbBuild) con marco
//   dorado fino y «TU FOTO · n a.l.» debajo: en la placa del borde, en la mira y como POSTAL de la foto minima (la foto fantasma a tamaño minimo pasa a ser esa tarjeta, nitida y del derecho; ?nmthumb=0 = la placa con icono y texto de antes; FV_NMX.THUMB)
// En FOTO, con una estrella de detras de la nebulosa (tour), una nota de profundidad.
// ============================================================================
var FW_NMP = { GOLD: "229,181,63", GOLDL: "243,210,126", TEXT: "251,242,224", TEXT2: "208,193,165", INK: "11,9,6", EARTH: "156,195,230" };
(function() { try {
   if (typeof FV_NMX === "undefined") return;
   var q = /[?&]nmcompass=([01])/.exec(location.search); if (q) FV_NMX.COMPASS = q[1] === "1";
   q = /[?&]nmhome=([01])/.exec(location.search); if (q) FV_NMX.HOME_MARK = q[1] === "1";
   q = /[?&]nmgo=([01])/.exec(location.search); if (q) FV_NMX.PHOTO_GO = q[1] === "1";
   q = /[?&]nmthumb=([01])/.exec(location.search); if (q) FV_NMX.THUMB = q[1] === "1";
} catch (e) {} })();
// (E-nav) las zonas pulsables del marcador TU FOTO (px de la pantalla = los de fwSelect), rehechas en cada fwNmDraw
function fwNmHitAdd(x0, y0, x1, y1) {
   if (typeof FV_NMX === "undefined" || FV_NMX.PHOTO_GO !== true || (FW.nmOp !== undefined && FW.nmOp < 0.35)) return;      // FW.nmOp: el fundido del ancla; casi invisible = no se pulsa
   FW.nmHits.push({ x0: Math.min(x0, x1), y0: Math.min(y0, y1), x1: Math.max(x0, x1), y1: Math.max(y0, y1) });
}
function fwNmHitAt(x, y) {
   var H = FW.nmHits || [];
   for (var i = 0; i < H.length; ++i) if (x >= H[i].x0 && x <= H[i].x1 && y >= H[i].y0 && y <= H[i].y1) return true;
   return false;
}
// volver volando a la foto: el protagonista (fvNmPhotoSel del motor) con el viaje de siempre; en pleno vuelo no relanza. -> true si arranco
function fwNmGoPhoto() {
   var P = FW.P, sc = FW.scene;
   if (!P || !sc || P.flight || typeof fvNmPhotoSel !== "function" || typeof FV_NMX === "undefined" || FV_NMX.PHOTO_GO !== true) return false;
   var to = fvNmPhotoSel(sc); if (!to) return false;
   var s = (to.kind === "object" && sc.objects && sc.objects[to.i]) ? (sc.objects[to.i].main ? { kind: "nebula", sx: 0, sy: 0, obj: to.i } : { kind: "object", i: to.i }) : { kind: "nebula", sx: 0, sy: 0, obj: -1 };
   fwUserAct(); fwSelectSel(s);
   var ok = fwTravel(s); fwButtonsState();
   if (window.console) console.log("nav: TU FOTO marker -> fly to " + s.kind + (s.i !== undefined ? " " + s.i : "") + (s.obj >= 0 ? " obj " + s.obj : "") + ": " + (ok ? "started" : "not started"));
   return ok;
}
// el clic (pointerup) y el doble clic de fwInput: true = era el marcador y se atendio
function fwNmClick(x, y) { if (!fwNmHitAt(x, y)) return false; fwNmGoPhoto(); return true; }
// la mano y el tooltip EN/ES sobre las zonas (win = el elemento de la escena)
function fwNmBind(win) {
   if (!win || FW.nmBound) return; FW.nmBound = true;
   var hand = false, oldCur = "", oldTit = "";
   win.addEventListener("pointermove", function(e) {
      var b = win.getBoundingClientRect(), on = !e.buttons && fwNmHitAt(e.clientX - b.left, e.clientY - b.top);
      if (on === hand) return; hand = on;
      if (on) { oldCur = win.style.cursor; oldTit = win.title; win.style.cursor = "pointer"; win.title = fwTr("Click to fly back to your photo (the arrow shows which way it is)", "Clic para volver volando a tu foto (la flecha dice hacia dónde queda)"); }
      else { win.style.cursor = oldCur; win.title = oldTit; }
   });
   win.addEventListener("pointerleave", function() { if (hand) { hand = false; win.style.cursor = oldCur; win.title = oldTit; } });
}
// (20-nov, O1) LA MINIATURA: la foto del paquete (FW.imgs.photo, ya estirada) reducida una sola vez a 3 × THUMB_W de lado mayor (el doble de lo que se ve a 1920: nitida), en un
// lienzo aparte. Se llama al arrancar (fw_viewer.js, fwStart), nunca al pintar; null sin foto o con THUMB false. Rehacer (p. ej. si cambia FV_NMX.THUMB) = llamarla otra vez
function fwNmThumbBuild() {
   FW.nmThumb = null;
   try {
      if (typeof FV_NMX === "undefined" || FV_NMX.THUMB !== true) return null;
      var im = FW.imgs && FW.imgs.photo; if (!im || !(im.width > 0) || !(im.height > 0)) return null;
      var Lm = Math.round(3 * FV_NMX.THUMB_W), asp = im.height / im.width, w = asp <= 1 ? Lm : Math.max(2, Math.round(Lm / asp)), h = asp <= 1 ? Math.max(2, Math.round(Lm * asp)) : Lm;
      var c = document.createElement("canvas"); c.width = w; c.height = h; var g = c.getContext("2d");
      g.imageSmoothingEnabled = true; g.imageSmoothingQuality = "high";
      var cur = im, cw = im.width, ch = im.height;      // reduccion por mitades hasta el doble del destino y el paso final: sin dientes
      while (cw > 2 * w) { var t = document.createElement("canvas"); cw = Math.max(w, Math.ceil(cw / 2)); ch = Math.max(h, Math.ceil(ch / 2)); t.width = cw; t.height = ch; var tg = t.getContext("2d"); tg.imageSmoothingEnabled = true; tg.imageSmoothingQuality = "high"; tg.drawImage(cur, 0, 0, cw, ch); cur = t; }
      g.drawImage(cur, 0, 0, w, h);
      FW.nmThumb = c;
   } catch (e) { FW.nmThumb = null; if (window.console) console.log("nmThumb: " + e); }
   return FW.nmThumb;
}
// la escala de la tarjeta: la misma que la de HUD de PixInsight (ancho / 1280), no la del resto del visor
function fwNmThumbK() { return Math.max(0.62, Math.min(4, FW.VW / 1280)); }
function fwNmThumbOn() { return typeof FV_NMX !== "undefined" && FV_NMX.THUMB === true && !!FW.nmThumb; }
// la tarjeta de TU FOTO: placa oscura con el marco fino, la miniatura con su marco dorado y «TU FOTO · n a.l.» debajo. (x, y) = su esquina superior izquierda; cd = fvNmThumbCard (motor)
function fwNmThumbPaint(g, kind, cd, x, y, k, tT, col) {
   var C = FW_NMP, ix = x + cd.tx, iy = y + cd.ty;
   g.fillStyle = fwNmRgba(C.INK, 0.72); g.fillRect(x, y, cd.cw, cd.ch); g.strokeStyle = fwNmRgba(col, 0.6); g.lineWidth = k; g.strokeRect(x + 0.5, y + 0.5, cd.cw - 1, cd.ch - 1);
   g.save(); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = "high"; g.drawImage(FW.nmThumb, ix, iy, cd.tw, cd.th); g.restore();
   g.strokeStyle = fwNmRgba(C.GOLDL, 0.95); g.lineWidth = 1.2 * k; g.strokeRect(ix, iy, cd.tw, cd.th);
   g.font = "600 " + Math.round(9 * k) + "px 'Cormorant Garamond', Georgia, serif"; g.textBaseline = "alphabetic"; g.textAlign = "center"; g.fillStyle = fwNmRgba(col, 0.97);
   g.fillText(tT, x + cd.cw / 2, y + cd.ly); g.textAlign = "left";
   FW.nmThumbRect = { kind: kind, x0: x, y0: y, x1: x + cd.cw, y1: y + cd.ch, tx0: ix, ty0: iy, tx1: ix + cd.tw, ty1: iy + cd.th };
}
// donde va la tarjeta de la mira sin pisar lo ocupado (derecha, izquierda, abajo, arriba o junto a lo que lo tapa, con linea guia); occ null = a la derecha. -> { x, y (esquina), lead }
function fwNmBoxPlace(mk, w, h, k, W, H, occ) {
   var s = 11 * k, c = [[mk.x + s + 5 * k, mk.y - h / 2], [mk.x - s - 5 * k - w, mk.y - h / 2], [mk.x - w / 2, mk.y + s + 6 * k], [mk.x - w / 2, mk.y - s - 6 * k - h]], i, j;
   if (!occ) return { x: fvClamp(c[0][0], 2, W - w - 2), y: fvClamp(c[0][1], 2, H - h - 2), lead: false };
   for (i = 0; i < occ.length; ++i) { var o = occ[i]; c.push([o[2] + 6 * k, mk.y - h / 2], [o[0] - 6 * k - w, mk.y - h / 2], [mk.x - w / 2, o[3] + 6 * k], [mk.x - w / 2, o[1] - 6 * k - h]); }
   function hit(b) { if (b[0] < 2 || b[1] < 2 || b[2] > W - 2 || b[3] > H - 2) return true; for (var q = 0; q < occ.length; ++q) { var o2 = occ[q]; if (b[0] < o2[2] && b[2] > o2[0] && b[1] < o2[3] && b[3] > o2[1]) return true; } return false; }
   for (j = 0; j < c.length; ++j) { var b = [c[j][0], c[j][1], c[j][0] + w, c[j][1] + h]; if (!hit(b)) { occ.push(b); return { x: c[j][0], y: c[j][1], lead: j >= 4 }; } }
   occ.push([c[0][0], c[0][1], c[0][0] + w, c[0][1] + h]); return { x: c[0][0], y: c[0][1], lead: false };
}
function fwNmRgba(c, a) { return "rgba(" + c + "," + Math.max(0, Math.min(1, a)).toFixed(3) + ")"; }
function fwNmLy(d) { return Math.round(d).toLocaleString(FW_LANG === "es" ? "es-ES" : "en-GB") + " " + fwTr("ly", "a.l."); }
// (20-nov-2026, V1a, V1-10) AYUDAS DE ORIENTACION del vuelo a mano, gemelo de fvV1AidPaint (src/ui/fv_navmodes.js); los datos salen del motor (fvNmHud.aidPhoto, fvV1Reticle)
function fwNmAid(g, P, W, H, hud, C, k) {
   if (typeof fvV1Reticle !== "function") return;
   var i, rt = fvV1Reticle(P);
   if (hud.aidPhoto) { g.save(); g.globalAlpha = 1; for (i = 0; i < hud.markers.length; ++i) if (hud.markers[i].kind === "photo" && !hud.markers[i].on) fwNmMark(g, hud.markers[i], k, []); g.restore(); }
   if (rt) {
      var cx = W / 2, cy = H / 2, R = 14 * k, a = rt.a;
      g.save(); g.lineCap = "round"; g.strokeStyle = fwNmRgba(C.GOLDL, 0.55 * rt.k); g.lineWidth = 1 * k;
      g.beginPath(); g.moveTo(cx - R, cy); g.lineTo(cx - 0.35 * R, cy); g.moveTo(cx + 0.35 * R, cy); g.lineTo(cx + R, cy); g.moveTo(cx, cy - R); g.lineTo(cx, cy - 0.35 * R); g.moveTo(cx, cy + 0.35 * R); g.lineTo(cx, cy + R); g.stroke();
      g.strokeStyle = fwNmRgba(C.GOLD, 0.95 * rt.k); g.lineWidth = 1.8 * k; g.beginPath(); g.moveTo(cx + Math.cos(a) * R * 0.5, cy + Math.sin(a) * R * 0.5); g.lineTo(cx + Math.cos(a) * R * 1.7, cy + Math.sin(a) * R * 1.7); g.stroke(); g.restore();
   }
}
function fwNmDraw(now) {
   FW.nmHits = []; FW.nmOp = 1; FW.nmThumbRect = null;
   if (typeof fvNmHud !== "function" || !fvNmOn() || !FW.P || !FW.ck || !FW.ck.hctx) { var eb = document.getElementById("navBanner"); if (eb) eb.style.display = "none"; FW.navHud = null; return null; }
   var P = FW.P, W = FW.VW, H = FW.VH, hud = fvNmHud(P, W, H), g = FW.ck.hctx, C = FW_NMP, k = Math.max(0.75, Math.min(2, W / 1600));
   FW.navHud = hud;
   fwNmAid(g, P, W, H, hud, C, k);                                   // (20-nov, V1a, V1-10) la flecha «la foto esta detras» y la reticula de la foto (gemelo de fvV1AidPaint)
   // (11-nov-2026, NV-13) con el laboratorio de vuelo, como fvNmPaint de PixInsight (src/ui/fv_navmodes.js): sin rotulo de Espacio; piramide,
   // marcadores y foto minima solo como ANCLA (P.lab.anchor: con paisaje se apaga y no tapa nada) y con su fundido. La foto fantasma grande no:
   // la foto ya la pinta el renderizador. Sin laboratorio, lo de antes tal cual
   var labOn = !!(P.lab && typeof FV_LAB !== "undefined" && FV_LAB.ON === true), labF = labOn ? (P.lab.anchor || 0) : 1, labA = false;
   if (labOn) {
      fwNmBanner({ mode: "photo", note: hud.note });
      if (labF < 0.01 && !hud.note) return hud;
      labA = labF >= 0.01; if (!labA) hud.mode = "photo";
      if (hud.mode !== "space" && !hud.note && !labA) return hud;
      g.save(); g.globalAlpha = labF;
      try { return fwNmDrawHud(g, P, W, H, hud, C, k, labA, labF); } finally { g.restore(); }
   }
   fwNmBanner(hud);
   if (hud.mode !== "space" && !hud.note) return hud;
   return fwNmDrawHud(g, P, W, H, hud, C, k);                         // (el fundido del salto a casa lo pinta fwOverlay al final: fwNmJumpPaint)
}
function fwNmDrawHud(g, P, W, H, hud, C, k, labA, labF) {
   g.save();
   if (labF === undefined) labF = 1;
   FW.nmOp = labF;
   if (hud.mode === "space" || labA) {
      // la foto fantasma
      var ph = FW.imgs && FW.imgs.photo, G = fvRouteGeo(P), pr = fvProjector(P.cam, W, H);
      if (ph && ph.width && !labA) {
         var q0 = pr.project([-G.HW, -G.HH, G.D]), q1 = pr.project([G.HW, -G.HH, G.D]), q3 = pr.project([-G.HW, G.HH, G.D]);
         if (q0 && q1 && q3 && Math.abs(q1[0] - q0[0]) + Math.abs(q3[1] - q0[1]) < 4 * (W + H)) {
            var behind = P.cam.pos[2] > G.D, op = FV_NAV_MODES.GHOST_A * hud.ghost * (behind ? 0.6 : 1) * (1 - 0.8 * fvSmooth((P.warp || 0) / 0.6));
            if (op > 0.01) {
               var pw = ph.width, phh = ph.height;
               g.globalAlpha = op;
               g.setTransform(g.getTransform().multiply(new DOMMatrix([(q1[0] - q0[0]) / pw, (q1[1] - q0[1]) / pw, (q3[0] - q0[0]) / phh, (q3[1] - q0[1]) / phh, q0[0], q0[1]])));
               g.drawImage(ph, 0, 0, pw, phh);
               g.restore(); g.save(); g.globalAlpha = 1;
            }
         }
      }
      // (F1) el halo dorado del borde hacia la foto (de espaldas a ella): tenue, debajo de todo lo demas
      if (hud.glow) {
         var gr = 0.42 * Math.min(W, H), grd = g.createRadialGradient(hud.glow.x, hud.glow.y, 0, hud.glow.x, hud.glow.y, gr);
         grd.addColorStop(0, fwNmRgba(C.GOLD, 0.26)); grd.addColorStop(0.45, fwNmRgba(C.GOLD, 0.09)); grd.addColorStop(1, fwNmRgba(C.GOLD, 0));
         g.fillStyle = grd; g.fillRect(hud.glow.x - gr, hud.glow.y - gr, 2 * gr, 2 * gr);
      }
      // (F2) la foto fantasma a su tamaño minimo (de lejos, desde detras: no un rectangulo diminuto), con su marco luminoso y su rotulo
      var gm = hud.ghostMin;
      if (gm && fwNmThumbOn()) {
         // (O1) la POSTAL: la foto a tamaño minimo como la tarjeta de TU FOTO (placa, miniatura con su marco dorado fino y el rotulo debajo), nitida y del derecho (la «espalda» al reves
         // de antes no se reconocia); toda ella se pulsa. La tarjeta centra la miniatura en el centro de la foto
         var kc = fwNmThumbK(), tGp = fwTr("YOUR PHOTO", "TU FOTO") + " · " + fwNmLy(gm.dist);
         g.font = "600 " + Math.round(9 * kc) + "px 'Cormorant Garamond', Georgia, serif";
         var cdp = fvNmThumbCard(kc, FW.nmThumb.height / FW.nmThumb.width, g.measureText(tGp).width, 10 * kc, Math.max(gm.w, gm.h)), pxp = gm.cx - cdp.cw / 2, pyp = gm.cy - gm.h / 2 - cdp.ty;
         fwNmThumbPaint(g, "postal", cdp, pxp, pyp, kc, tGp, FW_NMP.GOLDL);
         fwNmHitAdd(pxp, pyp, pxp + cdp.cw, pyp + cdp.ch);
      } else if (gm && ph && ph.width) {
         g.save(); g.globalAlpha = Math.min(1, 0.55 * hud.ghost + 0.25) * (gm.behind ? 0.7 : 1) * labF;
         if (gm.behind) { g.translate(gm.cx, gm.cy); g.scale(-1, 1); g.translate(-gm.cx, -gm.cy); }       // por detras: al reves
         g.drawImage(ph, gm.cx - gm.w / 2, gm.cy - gm.h / 2, gm.w, gm.h); g.restore();
         g.save(); g.shadowColor = fwNmRgba(C.GOLDL, 0.9); g.shadowBlur = 14 * k; g.strokeStyle = fwNmRgba(C.GOLDL, 0.95); g.lineWidth = 1.6 * k;
         g.strokeRect(gm.cx - gm.w / 2, gm.cy - gm.h / 2, gm.w, gm.h); g.restore();
         g.font = "600 " + Math.round(12 * k) + "px 'Cormorant Garamond', Georgia, serif"; g.textBaseline = "top"; g.textAlign = "center";
         g.fillStyle = fwNmRgba(C.GOLDL, 0.95); var tG = fwTr("YOUR PHOTO", "TU FOTO") + " · " + fwNmLy(gm.dist); g.fillText(tG, gm.cx, gm.cy + gm.h / 2 + 6 * k);
         var wG = g.measureText(tG).width; fwNmHitAdd(gm.cx - wG / 2 - 4 * k, gm.cy + gm.h / 2 + 2 * k, gm.cx + wG / 2 + 4 * k, gm.cy + gm.h / 2 + 22 * k);      // (E-nav) el rotulo de la foto minima
      }
      // la piramide (mas fuerte cuando la foto es pequeña en pantalla)
      var aL = FV_NAV_MODES.LINE_A * hud.ghost * (gm ? 1.6 : 1), wL = gm ? 1.7 : 1;
      for (var i = 0; i < hud.lines.length; ++i) {
         var L = hud.lines[i]; g.strokeStyle = fwNmRgba(L[4] ? C.GOLDL : C.GOLD, L[4] ? aL : 0.7 * aL); g.lineWidth = (L[4] ? 1.6 : 1.0) * k * wL;
         g.beginPath(); g.moveTo(L[0], L[1]); g.lineTo(L[2], L[3]); g.stroke();
      }
      // (7-nov) los rotulos no se montan: zonas ocupadas (la foto a tamaño minimo con su halo y su rotulo) y cada rotulo puesto
      var occ = []; if (gm) occ.push([gm.cx - gm.w / 2 - 8 * k, gm.cy - gm.h / 2 - 8 * k, gm.cx + gm.w / 2 + 8 * k, gm.cy + gm.h / 2 + 22 * k]);
      for (var m = 0; m < hud.markers.length; ++m) if (!(gm && hud.markers[m].kind === "photo" && hud.markers[m].on)) fwNmMark(g, hud.markers[m], k, occ);
      // la brujula (mas grande; la direccion de la foto, resaltada)
      if (hud.compass) {
         var R = 44 * k, cx = W - 96 * k, cy = 120 * k;
         g.fillStyle = fwNmRgba(C.INK, 0.6); g.beginPath(); g.arc(cx, cy, R + 10 * k, 0, 2 * Math.PI); g.fill();
         g.strokeStyle = fwNmRgba(C.GOLD, 0.9); g.lineWidth = 1.6 * k; g.beginPath(); g.arc(cx, cy, R, 0, 2 * Math.PI); g.stroke();
         g.strokeStyle = fwNmRgba(C.GOLD, 0.3); g.lineWidth = k; g.beginPath(); g.moveTo(cx - R, cy); g.lineTo(cx + R, cy); g.moveTo(cx, cy - R); g.lineTo(cx, cy + R); g.stroke();
         [[hud.compass.earth, C.EARTH, 1.6, 3.6], [hud.compass.photo, C.GOLDL, 3.0, 5.2]].forEach(function(e) {
            var d = e[0], n = Math.hypot(d[0], d[1]), rr = R * Math.min(1, n), ex = cx + (n > 1e-9 ? d[0] / n : 0) * rr, ey = cy + (n > 1e-9 ? d[1] / n : 0) * rr;
            g.strokeStyle = fwNmRgba(e[1], 0.95); g.lineWidth = e[2] * k; g.beginPath(); g.moveTo(cx, cy); g.lineTo(ex, ey); g.stroke();
            g.beginPath(); g.arc(ex, ey, e[3] * k, 0, 2 * Math.PI); if (d[2] >= 0) { g.fillStyle = fwNmRgba(e[1], 1); g.fill(); } else { g.lineWidth = 1.4 * k; g.stroke(); }
         });
         g.font = Math.round(11 * k) + "px 'Cormorant Garamond', Georgia, serif"; g.textBaseline = "alphabetic";
         g.fillStyle = fwNmRgba(C.TEXT2, 0.9); g.textAlign = "left"; g.fillText(fwTr("EARTH", "TIERRA"), cx - R - 8 * k, cy + R + 26 * k);
         g.fillStyle = fwNmRgba(C.GOLDL, 1); g.textAlign = "right"; g.font = "600 " + Math.round(11 * k) + "px 'Cormorant Garamond', Georgia, serif"; g.fillText(fwTr("PHOTO", "FOTO"), cx + R + 8 * k, cy + R + 26 * k);
      }
   }
   g.restore();
   return hud;
}
function fwNmIcon(g, kind, x, y, r, col) {
   // (F1) el icono de cada marcador: la foto = un marco; casa = el Sol (disco y rayos); el destino = un anillo con cruz
   g.strokeStyle = col; g.fillStyle = col; g.lineWidth = Math.max(1, r / 4);
   if (kind === "photo") { g.strokeRect(x - r, y - 0.7 * r, 2 * r, 1.4 * r); var a0 = g.globalAlpha; g.globalAlpha = a0 * 0.5; g.fillRect(x - 0.6 * r, y - 0.35 * r, 1.2 * r, 0.7 * r); g.globalAlpha = a0; }
   else if (kind === "home") { g.beginPath(); g.arc(x, y, 0.5 * r, 0, 2 * Math.PI); g.fill(); g.beginPath(); for (var a = 0; a < 8; ++a) { var t = a * Math.PI / 4; g.moveTo(x + 0.75 * r * Math.cos(t), y + 0.75 * r * Math.sin(t)); g.lineTo(x + 1.1 * r * Math.cos(t), y + 1.1 * r * Math.sin(t)); } g.stroke(); }
   else { g.beginPath(); g.arc(x, y, 0.8 * r, 0, 2 * Math.PI); g.stroke(); g.beginPath(); g.moveTo(x - 1.1 * r, y); g.lineTo(x - 0.4 * r, y); g.moveTo(x + 0.4 * r, y); g.lineTo(x + 1.1 * r, y); g.moveTo(x, y - 1.1 * r); g.lineTo(x, y - 0.4 * r); g.moveTo(x, y + 0.4 * r); g.lineTo(x, y + 1.1 * r); g.stroke(); }
}
// (7-nov) donde va el rotulo de una mira en pantalla sin pisar lo ocupado (derecha, izquierda, abajo, arriba o fuera de lo que lo tapa,
// con linea guia); y = centro del texto; añade su caja a occ
function fwNmLabelPlace(mk, w, k, W, H, occ) {
   var s = 11 * k, h = 7 * k, c = [[mk.x + s + 5 * k, mk.y - s], [mk.x - s - 5 * k - w, mk.y - s], [mk.x - w / 2, mk.y + s + 9 * k], [mk.x - w / 2, mk.y - s - 9 * k]], i, j;
   for (i = 0; i < occ.length; ++i) { var o = occ[i]; c.push([o[2] + 6 * k, mk.y], [o[0] - 6 * k - w, mk.y], [mk.x - w / 2, o[3] + 9 * k], [mk.x - w / 2, o[1] - 9 * k]); }
   function hit(b) { if (b[0] < 2 || b[1] < 2 || b[2] > W - 2 || b[3] > H - 2) return true; for (var q = 0; q < occ.length; ++q) { var o = occ[q]; if (b[0] < o[2] && b[2] > o[0] && b[1] < o[3] && b[3] > o[1]) return true; } return false; }
   for (j = 0; j < c.length; ++j) { var b = [c[j][0], c[j][1] - h, c[j][0] + w, c[j][1] + h]; if (!hit(b)) { occ.push(b); return { x: c[j][0], y: c[j][1], lead: j >= 4 }; } }
   occ.push([c[0][0], c[0][1] - h, c[0][0] + w, c[0][1] + h]); return { x: c[0][0], y: c[0][1], lead: false };
}
function fwNmMark(g, mk, k, occ) {
   var C = FW_NMP, col = mk.kind === "photo" ? C.GOLDL : (mk.kind === "home" ? C.EARTH : C.TEXT);
   var lab = mk.kind === "photo" ? fwTr("YOUR PHOTO", "TU FOTO") : (mk.kind === "home" ? fwTr("HOME", "CASA") : fwTr("TARGET", "DESTINO"));
   var dl = fwNmLy(mk.dist);
   g.textBaseline = "middle";
   if (mk.on) {
      var s = 11 * k; g.strokeStyle = fwNmRgba(col, 0.95); g.lineWidth = 1.5 * k; g.beginPath();
      g.moveTo(mk.x - s / 2, mk.y - s); g.lineTo(mk.x - s, mk.y - s); g.lineTo(mk.x - s, mk.y - s / 2);
      g.moveTo(mk.x + s / 2, mk.y + s); g.lineTo(mk.x + s, mk.y + s); g.lineTo(mk.x + s, mk.y + s / 2); g.stroke();
      g.font = "600 " + Math.round(11 * k) + "px 'Cormorant Garamond', Georgia, serif"; g.fillStyle = fwNmRgba(col, 0.95); g.textAlign = "left";
      var tL = lab + " · " + dl, wL = g.measureText(tL).width;
      if (mk.kind === "photo" && fwNmThumbOn()) {      // (O1) la mira de la foto: su miniatura con marco y el rotulo debajo, sin pisar lo ocupado
         var kc = fwNmThumbK(); g.font = "600 " + Math.round(9 * kc) + "px 'Cormorant Garamond', Georgia, serif";
         var cdm = fvNmThumbCard(kc, FW.nmThumb.height / FW.nmThumb.width, g.measureText(tL).width, 10 * kc), plm = fwNmBoxPlace(mk, cdm.cw, cdm.ch, kc, FW.VW, FW.VH, occ);
         if (plm.lead) { g.strokeStyle = fwNmRgba(col, 0.55); g.lineWidth = k; g.beginPath(); g.moveTo(mk.x, mk.y); g.lineTo(plm.x + (plm.x < mk.x ? cdm.cw : 0), plm.y + cdm.ch / 2); g.stroke(); }
         fwNmThumbPaint(g, "mira", cdm, plm.x, plm.y, kc, tL, col);
         fwNmHitAdd(plm.x, plm.y, plm.x + cdm.cw, plm.y + cdm.ch); fwNmHitAdd(mk.x - s, mk.y - s, mk.x + s, mk.y + s);
         return;
      }
      var pl = occ ? fwNmLabelPlace(mk, wL, k, FW.VW, FW.VH, occ) : { x: mk.x + s + 5 * k, y: mk.y - s, lead: false };
      if (pl.lead) { g.strokeStyle = fwNmRgba(col, 0.55); g.lineWidth = k; g.beginPath(); g.moveTo(mk.x, mk.y); g.lineTo(pl.x + (pl.x < mk.x ? wL : 0), pl.y); g.stroke(); }
      g.fillText(tL, pl.x, pl.y);
      if (mk.kind === "photo") { fwNmHitAdd(pl.x - 3 * k, pl.y - 9 * k, pl.x + wL + 3 * k, pl.y + 9 * k); fwNmHitAdd(mk.x - s, mk.y - s, mk.x + s, mk.y + s); }   // (E-nav) el rotulo y la mira
      return;
   }
   // fuera: flecha grande en el borde + placa con icono, rotulo y distancia (se lee de un vistazo)
   var c = Math.cos(mk.ang), sn = Math.sin(mk.ang), L = 22 * k, Wd = 13 * k;
   g.fillStyle = fwNmRgba(col, 0.97); g.strokeStyle = fwNmRgba(C.INK, 0.9); g.lineWidth = 1.2 * k;
   g.beginPath(); g.moveTo(mk.x + c * L, mk.y + sn * L); g.lineTo(mk.x - sn * Wd, mk.y + c * Wd); g.lineTo(mk.x + sn * Wd, mk.y - c * Wd); g.closePath(); g.fill(); g.stroke();
   if (mk.kind === "photo" && fwNmThumbOn()) {      // (O1) el borde: la flecha y, hacia dentro, la tarjeta con la miniatura de la foto (en vez de la placa con icono y texto)
      var kc = fwNmThumbK(); g.font = "600 " + Math.round(9 * kc) + "px 'Cormorant Garamond', Georgia, serif"; var tT = lab + " · " + dl, cd = fvNmThumbCard(kc, FW.nmThumb.height / FW.nmThumb.width, g.measureText(tT).width, 10 * kc);
      var off = 6 * kc + Math.abs(c) * cd.cw / 2 + Math.abs(sn) * cd.ch / 2, cx0 = fvClamp(mk.x - c * off - cd.cw / 2, 4, FW.VW - cd.cw - 4), cy0 = fvClamp(mk.y - sn * off - cd.ch / 2, 4, FW.VH - cd.ch - 4);
      fwNmThumbPaint(g, "edge", cd, cx0, cy0, kc, tT, col);
      var tx2 = mk.x + c * L, ty2 = mk.y + sn * L, x1c = mk.x - sn * Wd, y1c = mk.y + c * Wd, x2c = mk.x + sn * Wd, y2c = mk.y - c * Wd;
      fwNmHitAdd(Math.min(cx0, tx2, x1c, x2c) - 3 * k, Math.min(cy0, ty2, y1c, y2c) - 3 * k, Math.max(cx0 + cd.cw, tx2, x1c, x2c) + 3 * k, Math.max(cy0 + cd.ch, ty2, y1c, y2c) + 3 * k);
      return;
   }
   var bx = mk.x - c * 52 * k, by = mk.y - sn * 52 * k;
   g.font = "600 " + Math.round(12 * k) + "px 'Cormorant Garamond', Georgia, serif"; var w1 = g.measureText(lab).width;
   g.font = Math.round(10 * k) + "px 'Cormorant Garamond', Georgia, serif"; var w2 = g.measureText(dl).width, pw = Math.max(w1, w2) + 34 * k, phh = 34 * k;
   var px = fvClamp(bx - pw / 2, 4, FW.VW - pw - 4), py = fvClamp(by - phh / 2, 4, FW.VH - phh - 4);
   g.fillStyle = fwNmRgba(C.INK, 0.62); g.fillRect(px, py, pw, phh); g.strokeStyle = fwNmRgba(col, 0.6); g.lineWidth = k; g.strokeRect(px + 0.5, py + 0.5, pw - 1, phh - 1);
   if (mk.kind === "photo") {      // (E-nav) la placa y la flecha del borde: una zona que cubre las dos
      var tx = mk.x + c * L, ty = mk.y + sn * L, x1b = mk.x - sn * Wd, y1b = mk.y + c * Wd, x2b = mk.x + sn * Wd, y2b = mk.y - c * Wd;
      fwNmHitAdd(Math.min(px, tx, x1b, x2b) - 3 * k, Math.min(py, ty, y1b, y2b) - 3 * k, Math.max(px + pw, tx, x1b, x2b) + 3 * k, Math.max(py + phh, ty, y1b, y2b) + 3 * k);
   }
   fwNmIcon(g, mk.kind, px + 13 * k, py + phh / 2, 6 * k, fwNmRgba(col, 0.95));
   g.textAlign = "left"; g.fillStyle = fwNmRgba(col, 0.97); g.font = "600 " + Math.round(12 * k) + "px 'Cormorant Garamond', Georgia, serif"; g.fillText(lab, px + 25 * k, py + 11 * k);
   g.fillStyle = fwNmRgba(C.TEXT2, 0.92); g.font = Math.round(10 * k) + "px 'Cormorant Garamond', Georgia, serif"; g.fillText(dl, px + 25 * k, py + 24 * k);
}
// el rotulo (HTML, pulsable): ESPACIO, o la nota de profundidad en Foto
function fwNmBanner(hud) {
   var el = document.getElementById("navBanner");
   if (!el) {
      el = document.createElement("div"); el.id = "navBanner";
      el.style.cssText = "position:fixed;left:50%;top:18px;transform:translateX(-50%);z-index:30;display:none;padding:6px 18px;border:1px solid rgba(229,181,63,.95);" +
                         "background:rgba(11,9,6,.78);color:#F3D27E;font:600 14px 'Cormorant Garamond',Georgia,serif;letter-spacing:.12em;cursor:pointer;white-space:nowrap";
      el.addEventListener("click", function(e) { e.stopPropagation(); if (FW.P && fvNmMode(FW.P) === "space") fwButton("start"); });
      document.body.appendChild(el);
   }
   var txt = "", show = false, cur = "default";
   if (hud.mode === "space") { txt = fwTr("SPACE · outside your photo — H to return", "ESPACIO · fuera de tu foto — H para volver"); show = true; cur = "pointer"; }
   else if (hud.note) { txt = fwTr("Behind the nebula: " + fwNmLy(hud.note.beyondLy) + " beyond it · TRAVEL to go there (Space mode)", "Detrás de la nebulosa: " + fwNmLy(hud.note.beyondLy) + " más allá · VIAJAR para ir (modo Espacio)"); show = true; }
   if (el.__t !== txt) { el.textContent = txt; el.__t = txt; el.title = hud.mode === "space" ? fwTr("Back to your photo (H)", "Volver a tu foto (H)") : ""; }
   el.style.display = show ? "block" : "none"; el.style.cursor = cur;
   el.style.fontWeight = hud.mode === "space" ? "600" : "400";
}

// (7-nov) EL SALTO A CASA: el fundido dorado (color de placa, nunca negro) con un destello mas claro en el centro alrededor del salto
function fwNmJumpPaint(g, P, W, H) {
   if (typeof fvNmJumpFade !== "function") return 0;
   var f = fvNmJumpFade(P); FW.jumpFade = f.a;
   if (f.a < 0.003) return 0;
   var C = FW_NMP, cw = g.canvas.width, ch = g.canvas.height, R = 0.75 * Math.hypot(cw, ch), grd = g.createRadialGradient(cw / 2, ch / 2, 0, cw / 2, ch / 2, R);
   g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = "source-over";
   g.fillStyle = fwNmRgba("90,68,34", f.a); g.fillRect(0, 0, cw, ch);
   grd.addColorStop(0, fwNmRgba(f.flash > 0 ? C.GOLDL : C.GOLD, f.a * (0.85 + 0.15 * f.flash))); grd.addColorStop(0.45, fwNmRgba("138,106,53", f.a * 0.9)); grd.addColorStop(1, fwNmRgba("90,68,34", 0));
   g.fillStyle = grd; g.fillRect(0, 0, cw, ch); g.restore();
   return f.a;
}
