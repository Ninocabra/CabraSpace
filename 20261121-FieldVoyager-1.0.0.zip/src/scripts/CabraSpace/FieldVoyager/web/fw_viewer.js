// ============================================================================
// FieldVoyager/web/fw_viewer.js — EL VISOR DEL NAVEGADOR: arranque, bucle, raton, teclado, modos y pruebas (4-nov-2026, F3; pasada N)
// ----------------------------------------------------------------------------
// Lee el paquete de escena (scene/scene.js → window.FV_SCENE; scene/img_*.js → window.FV_IMG) que escribe PixInsight
// (src/export/fv_export.js), reconstruye la escena con el MISMO motor (engine/fv_*.js: piloto, warp, cine, orbita, vuelo libre,
// rueda, eleccion con el raton, objetos de C) y la pinta con fw_gl.js. Cabina y ficha: fw_cockpit.js. Navegacion: fw_nav.js.
// Radio: fw_radio.js. Video: fw_mp4.js.
// PASADA N (encargo D, N13: «mucho mas fluido y a la par de PixInsight»):
//   · CARGA SIN CONGELAR: la foto sale enseguida; la escena se arma por pasos (cada uno deja pintar), los shaders se compilan en paralelo
//     (compileAsync) y el relieve de la nebulosa va en un Worker. Antes: un bloque de 530 ms al cargar y 480–900 ms a mitad del primer
//     viaje (el shader de la Via Lactea compilandose). Medido en tests/web/fv_nD_perf.js.
//   · N1 franja de navegacion (fw_nav.js) · N2 mandos que responden · N3 «Vista inicial» arriba a la izquierda · N4 la ficha se cierra con
//     su aspa, se oculta al viajar y se reabre 2 s despues de llegar · N5/N6 la camara la lleva el motor (fv_pilot.js de B, mismas cifras
//     que PixInsight); aqui el warp de TNG en la imagen (rayas al punto de fuga, tunel, destello azul-blanco, temblor) · N7 todo
//     proporcional a la ventana · N8 objetos compactos con volumen y clic (fv_objects.js de C) · N10/N11 vuelo libre con W/S/A/D, raton y
//     rueda (fvPilotKey/fvPilotMouse/fvPilotWheel del motor) · N12 exoplanetas en la lista, sin boton · N14 deriva viva, radio que respira.
// PRUEBAS: window.FW.test (tests/web/fv_nD_cdp.js y fv_f3_cdp.js por el protocolo de depuracion de Chrome).
// ES5.
// ============================================================================

// los EFECTOS de cada estilo (la camara la lleva el motor: fvPilotSetStyle, «cine» | «spectacular»)
var FW_PROFILE = {
   cine:        { trail: 0.45, flash: 0.35, aberr: 0, bloomK: 0.16, grain: 0.010, vig: 0.20, shake: 0, steps: 64, halo: 0.04 },
   spectacular: { trail: 1.0, flash: 1.0, aberr: 1, bloomK: 0.30, grain: 0.016, vig: 0.26, shake: 1, steps: 80, halo: 0.07 }
};
// (N6/N14) lo que el visor añade a la imagen del warp (docs/cine-scifi-camara-y-musica.md §10.2, §11): rayas hasta RADIAL_MAX de la
// distancia al punto de fuga; temblor de crucero ≤ 0,15° a 9–14 Hz; sacudida de salida ≤ 0,4° que se apaga en 0,5 s; destello
// azul-blanco con resplandor de 0,25 s; deriva viva en reposo (dos senos: ±0,12° en 9,3 s y ±0,08° en 14,1 s, a 60° de campo).
var FW_WARPFX = { RADIAL_MAX: 0.55, RADIAL_POW: 1.3, ZOOM: 0.10, TUNNEL: 1.0, SHAKE_DEG: 0.15, SHAKE_HZ: [9.0, 14.0], EXIT_DEG: 0.4, EXIT_S: 0.5,
                  ZOOM_EXIT_U: 0.2, DRIFT: [[0.12, 9.3], [0.08, 14.1]], CARD_DELAY_S: 2.0,
                  // (D, §15 del documento de cine: medido en las cabeceras de TNG y Voyager) el destello lejano dura 0,5–1,0 s (sube el 40 %, baja
                  // el 60 %), esta en el punto de fuga, ocupa < 5 % de la pantalla, con una espiga vertical hasta ~0,9 del alto, blanco con tinte
                  // azul-violeta. FLASH_S solo se usa si el motor da un destello corto (< 0,4 s): si B lo alarga, manda el suyo (P.flash).
                  // FLASH_R: radio del nucleo (fraccion del alto); SPIKE_W/SPIKE_L: ancho y alcance de la espiga; FLASH_GAIN: brillo del pico.
                  // PULSE: sin temblor de camara, las rayas laten a ~1 Hz (±10 %) en el crucero (Contact, §15.2).
                  FLASH_S: 0.8, FLASH_RISE: 0.4, FLASH_R: 0.05, SPIKE_W: 0.004, SPIKE_L: 0.45, FLASH_GAIN: 2.2, FLASH_COL: [0.88, 0.86, 1.0],
                  PULSE_HZ: 1.0, PULSE_K: 0.10,
                  LAB_ENV: true };   // (11-nov, NV-16) con el laboratorio, tunel y desenfoque siguen a P.trail / P.warp del motor (fwFx); false = ROJO
// las teclas del vuelo libre: codigo del navegador -> codigo de PJSR que entiende fvPilotKey (los numeros de fvFreeKeyMap del motor)
var FW_KEYS = { KeyW: 0x57, ArrowUp: 0x10000002, KeyS: 0x53, ArrowDown: 0x10000004, KeyA: 0x41, ArrowLeft: 0x10000001, KeyD: 0x44, ArrowRight: 0x10000003,
                PageUp: 0x10000300, PageDown: 0x10000400, ShiftLeft: 0x70000001, ShiftRight: 0x70000001 };
// (11-nov, NV-13) las del laboratorio de vuelo (fvLabKeyMap): Q alabeo a un lado, Z al otro (los codigos Key_Q / Key_Z de PJSR)
var FW_LAB_KEYS = { KeyQ: 0x51, KeyZ: 0x5a };

var FW = { ready: false, err: "", test: {}, uiK: 1 };

// (11-nov-2026, NV-13) LA NAVEGACION DE PIXINSIGHT: el laboratorio de vuelo v5 (engine/fv_flightlab.js, el mismo fichero que el script; en
// PixInsight es la navegacion por defecto desde NV-1). ON true = el visor lo enciende al crear el piloto (como fv_dialog.js tras fvPilotNew) y el
// mismo viaje da la misma camara en los dos. ON false (o sin fv_flightlab.js en el paquete) = el visor de antes, bit a bit. ?lab=0 / ?lab=1 lo cambian
// (pruebas). La tecla L lo apaga y enciende en caliente, como en PixInsight.
// FEED: lo que el laboratorio lee del pintor en cada fotograma (fvLabAnchorWant: estrellas pintadas y foto en pantalla; fvLabLumGrid: la luz de la foto),
// con el criterio de fvLabUiAnchorFrame de PixInsight. "own" = lo calcula el visor; "none" = no se le da (CONTROL EN ROJO de la prueba de paridad);
// "inject" = lo pone la prueba (tests/web/fv_nv13_parity_cdp.js: aisla el motor del criterio)
// (11-nov, al integrar NV-13) ON = false DE FABRICA: la navegacion es la misma que en PixInsight (paridad 12/12), pero al visor le faltan tres cosas
// que con ella puesta se notan: el campo de estrellas de fondo (a mitad de viaje la pantalla queda negra), la estrella de llegada grande y los
// efectos del warp (tunel, rayas y destellos se pierden). Hasta portarlas, la web sigue con la navegacion clasica; ?lab=1 en la URL la enciende
// (11-nov, NV-16) ON = true DE FABRICA: las tres ya estan. El campo de fondo (fw_amb.js) pinta lo mismo que fvAmbPaint de PixInsight (puntos y
// trazos iguales en 1 819 fotogramas de tres viajes; rojo sin la mascara de la foto: 303 distintos), la protagonista crece como alli (HERO_NEAR,
// radio igual en todos los fotogramas) y los efectos del warp siguen a P.trail / P.warp del motor sin cortarse en la salida (FW_WARPFX.LAB_ENV).
// Paridad de la navegacion 12/12 con todo encendido (tests/web/fv_nv16_*_cdp.js; docs/encargos-11nov/NV13-web.md §NV-16). ?lab=0 = la clasica
// (16-nov, P16) HUB_BRAKE: el cubo de la cruceta luce MIENTRAS la nave frena tambien con el laboratorio. El motor v5 frena con P.lab.brake (fvLabBrake) y no
// con P.brake, asi que fvPilotGauges(P).brake valia siempre 0 y el cubo solo hacia el destello de 350 ms al pulsar (medido: 0,3 s de ~2,6 s de frenada).
// false = lo de antes (solo el destello).
var FW_LAB = { ON: true, FEED: "own", KEY_L: true, HUB_BRAKE: true };
(function() { try { var q = /[?&]lab=([01])/.exec(location.search); if (q) FW_LAB.ON = q[1] === "1"; } catch (e) {} })();
// (19-nov, W1; Nino: «el Warp va demasiado rapido y no da mucha sensacion de warp») EL WARP del laboratorio, mas lento y con mas salto: lo calcula el motor
// (FV_W1 en src/engine/fv_flightlab.js: duracion ×1,3, carga, salto de 1 s con el campo +30 %, estelas 0,95, destellos largos) y las dos vistas lo leen
// (P.trail, P.warp, P.flash, cam.fov); aqui solo el DOPPLER de las estrellas (azul hacia el punto de fuga, rojizo en los bordes; el pintor de PixInsight ya
// lo tenia con estela > 0,5, que el laboratorio no alcanzaba). ?w1=0 / FW_W1.ON = false = el warp de antes.
// (20-nov, W1b) los defectos que vio el coordinador (docs/encargos-19nov/W1b.md); cada subbandera false = lo de W1; ?w1b=0 apaga todas (tambien las del motor, FV_W1.*_ON):
//   BALL_ON    sin la «bola gris» en el punto de fuga: el nucleo del destello solo se pinta con destello alto (fx.flashBall = f · suave((f − LO) / (HI − LO))); el brillo de la carga
//              (0,30) y la cola del pulso ya no son un disco gris flotando sobre el negro (en las llegadas con la foto desplazada, el punto de fuga queda a un lado)
//   STREAK_ON  las rayas se notan como en PixInsight (estela 0,95 y warp 0,40 de un maximo de 1: las rayas de luz del tunel iban a 0,40 de su fuerza): fx.tunnel × TUNNEL_K, rayas de las
//              estrellas RADIAL_K veces mas largas, GAIN_K veces mas brillantes y WIDTH_K mas anchas (fx.radial / fx.gainK / fx.widthK, solo con estela alta). El desenfoque radial no se toca
//              (probado normalizado a warp 1: lavaba la nebulosa en luz: L 87 -> 92, rayas de color en vez de lineas)
var FW_W1 = { ON: true, DOPPLER: 0.22, BALL_ON: true, BALL_LO: 0.25, BALL_HI: 0.75, STREAK_ON: true, RADIAL_K: 1.4, GAIN_K: 1.7, WIDTH_K: 1.35, TUNNEL_K: 1.6 };
(function() { try { var q = /[?&]w1=([01])/.exec(location.search); if (q) FW_W1.ON = q[1] === "1"; if (typeof FV_W1 !== "undefined") FV_W1.ON = FW_W1.ON;
   var b = /[?&]w1b=([01])/.exec(location.search);
   if (b) { var on = b[1] === "1"; FW_W1.BALL_ON = FW_W1.STREAK_ON = on; if (typeof FV_W1 !== "undefined") FV_W1.FADE_ON = FV_W1.DOP_ON = FV_W1.HALO_ON = FV_W1.SCALE_ON = on; } } catch (e) {} })();
function fwLabOn() { return typeof FV_LAB !== "undefined" && FV_LAB.ON === true && !!(FW.P && FW.P.lab && FW.P.cam && FW.P.cam.B); }
// encender el laboratorio en el piloto recien creado (FW_LAB.ON) -> encendido?
function fwLabInit(P) {
   if (!FW_LAB.ON || typeof fvLabSetOn !== "function" || !P) return false;
   fvLabSetOn(P, true);
   return true;
}
// la tecla L: como fvLabUiToggle de PixInsight (suelta las teclas, para el tour, cambia y lo dice)
function fwLabToggle() {
   var P = FW.P; if (!P || typeof fvLabSetOn !== "function") return false;
   var on = !(FV_LAB.ON === true);
   fwReleaseKeys(); FW.tour = null;
   fvLabSetOn(P, on);
   fwCaption(on ? fwTr("FLIGHT LAB on — the navigation of PixInsight (L to switch off)", "LABORATORIO DE VUELO encendido — la navegación de PixInsight (L para apagar)")
                : fwTr("Flight lab off — the navigation of before", "Laboratorio apagado — la navegación de antes"), 2.6);
   return on;
}

// el nombre que llegue del constructor, tal cual; si viene por idiomas ({ en, es }), el de la cabina; si no hay, el generico
function fwNameOf(n, fallback) { if (n && typeof n === "object") n = n[FW_LANG] || n.en || n.es; return (n && String(n).trim()) ? String(n) : fallback; }
// (D, rev. 3, nota de C) la nebulosa trae names {en, es} y typeLabel {en, es} («Background nebulosity» / «Nebulosidad de fondo»)
function fwNebName(N, fallback) { return N ? fwNameOf(N.names || N.name, fallback) : fallback; }
// (N3, 19-nov; FW_NAMEDEDUP, espejo de FV_OBJ.NAME_DEDUP en src/engine/fv_objects.js: fvObjTitle) el titulo de la ficha de la nebulosa «nombre  ·  id»: dos designaciones que solo difieren en mayusculas o espacios
// («SH 2-131» de SIMBAD / «Sh 2-131» de la lista del campo) son una y se escribe una vez, con la grafia del id si es de catalogo (NGC, IC, Caldwell, Sharpless). false = la comparacion letra a letra de antes
var FW_NAMEDEDUP = true;
function fwDesigKey(s) { var t = String(s || "").replace(/\s+/g, " ").trim(); if (/^NAME\s/i.test(t)) t = t.replace(/^NAME\s+/i, "").replace(/^the\s+/i, ""); return t.toUpperCase().replace(/^SHARPLESS\s*/, "SH").replace(/\s+/g, ""); }
function fwSameDesig(a, b) { return FW_NAMEDEDUP === false ? a === b : (a === b || (!!a && !!b && fwDesigKey(a) === fwDesigKey(b))); }
// (N3c, 20-nov; FW_TITLENGCIC, espejo de FV_OBJ.TITLE_NGCIC: fvObjTitleAlias) la designacion que NO va en el titulo: el id (Sharpless) de una nebulosa cuyo titulo es una NGC / IC. "" = nada que mover
var FW_TITLENGCIC = true;
// URL: ?n3c=0 = el titulo «IC 1396  ·  Sh 2-131» de antes (FW_TITLENGCIC y FV_OBJ.TITLE_NGCIC: la ficha del paquete la compone fvCardContent) · ?n13=0 = FV_OBJ.BG_HERO false (N13: el clic en la capa de una foto sin nebulosa de catalogo elige «Background nebulosity», no el protagonista dibujado)
(function() { try { var q = /[?&]n3c=([01])/.exec(location.search); if (q) { FW_TITLENGCIC = q[1] === "1"; if (typeof FV_OBJ !== "undefined") FV_OBJ.TITLE_NGCIC = FW_TITLENGCIC; } var r = /[?&]n13=([01])/.exec(location.search); if (r && typeof FV_OBJ !== "undefined") FV_OBJ.BG_HERO = r[1] === "1"; } catch (e) {} })();
function fwTitleAlias(N, nT) {
   if (FW_TITLENGCIC === false || FW_NAMEDEDUP === false || !N || !N.id || !nT) return "";
   var id = String(N.id).replace(/\s+/g, " ").trim();
   return (/^(NGC|IC) \d+[A-Z]?$/i.test(String(nT).replace(/\s+/g, " ").trim()) && /^Sh ?2-\d+$/i.test(id) && fwDesigKey(id) !== fwDesigKey(nT)) ? id : "";
}
function fwNebTitle(N, nT) {
   if (FW_NAMEDEDUP === false) return nT + (N.id && N.id !== N.name && N.id !== nT ? "  ·  " + N.id : "");
   if (fwTitleAlias(N, nT).length > 0) return nT;      // (N3c) solo la NGC / IC; la Sharpless, en la linea pequena
   var id = N.id, shown = nT;
   if (id && nT !== id && /^(NGC \d+[A-Z]?|IC \d+[A-Z]?|(C|Caldwell) \d+|Sh ?2-\d+)$/i.test(String(id).replace(/\s+/g, " ").trim()) && fwDesigKey(nT) === fwDesigKey(id)) shown = String(id).replace(/\s+/g, " ").trim();
   return shown + (id && !fwSameDesig(id, N.name) && !fwSameDesig(id, nT) ? "  ·  " + id : "");
}
function fwNebType(N, fallback) { return N ? fwNameOf(N.typeLabel, fallback) : fallback; }
function fwFatal(e) { FW.err = String(e && e.message ? e.message : e); var d = document.getElementById("fatal"); d.textContent = FW.err; d.style.display = "block"; console.error(e); }
function fwBootBar(f, txt) { var b = document.querySelector("#bootBar i"); if (b) b.style.width = Math.round(100 * f) + "%"; if (txt) { var t = document.getElementById("bootTxt"); if (t) t.textContent = txt; if (typeof fwShipDoing === "function") fwShipDoing(txt.replace(/^FIELD VOYAGER · /, "")); } }
// (6-nov) la nave del arranque (fw_boot_ship.js): el estado de cada sistema segun los pasos de verdad; sin ese fichero, nada
function fwShip(id, st) { if (typeof fwShipSet === "function") fwShipSet(id, st); }
// pruebas: ?bootstep=<ms> espera eso en cada paso del arranque (para fotografiar la nave a media cola); 0 = lo de siempre
var FW_BOOT_STEP_MS = (function() { try { var q = /[?&]bootstep=(\d+)/.exec(location.search); return q ? Math.min(5000, +q[1]) : 0; } catch (e) { return 0; } })();
// un paso del arranque, dejando pintar entre medias (setTimeout 0 tras un fotograma)
function fwNext(fn) { requestAnimationFrame(function() { setTimeout(function() { try { fn(); } catch (e) { fwFatal(e); } }, FW_BOOT_STEP_MS); }); }

// ---------------------------------------------------------------------------
// ARRANQUE POR PASOS (N13)
// ---------------------------------------------------------------------------
function fwBoot() {
   FW.t0 = performance.now();
   if (typeof fwShipStart === "function") fwShipStart();
   fwShip("nav", "warm");
   try {
      if (!window.FV_SCENE) throw new Error(fwTr("No scene: export the flight from PixInsight (FieldVoyager > Export flight for the browser) and open its index.html.", "No hay escena: exporta el vuelo desde PixInsight (FieldVoyager > Exportar vuelo para el navegador) y abre su index.html."));
      var J = window.FV_SCENE, imgs = window.FV_IMG || {};
      // 1. la foto ya, de fondo (como se vera en casa): nada de pantalla negra mientras se arma la escena
      if (imgs.photo) { document.getElementById("bootPhoto").style.backgroundImage = "url(" + imgs.photo + ")"; FW.firstPaintMs = performance.now() - FW.t0; }
      fwBootBar(0.08, "FIELD VOYAGER · " + fwTr("loading", "cargando"));
      fwShip("nav", "ok"); fwShip("filters", "warm");
      // 2. los recortes de los objetos de C van en ficheros aparte (scene/img_obj<i>.js): se cargan ahora
      var cuts = (J.objects || []).filter(function(o) { return o && o.cut && o.cut.img && !imgs[o.cut.img]; }).map(function(o) { return o.cut.img; });
      if (J.photoStars && J.photoStars.atlas && !imgs[J.photoStars.atlas]) cuts.push(J.photoStars.atlas);   // (5-nov) STELLAE: el atlas de recortes (scene/img_psatlas.js)
      var pendS = cuts.length;
      function afterScripts() {
         imgs = window.FV_IMG || {};
         var keys = Object.keys(imgs), loaded = {}, pend = keys.length;
         if (!pend) return fwNext(function() { fwStart(J, loaded); });
         keys.forEach(function(k) {
            var im = new Image(); im.src = imgs[k];
            var fin = function() { if (--pend === 0) fwNext(function() { fwStart(J, loaded); }); };
            (im.decode ? im.decode() : Promise.reject()).then(function() { loaded[k] = im; fin(); }, function() { im.onload = function() { loaded[k] = im; fin(); }; im.onerror = fin; if (im.complete && im.naturalWidth) { loaded[k] = im; fin(); } });
         });
      }
      if (!pendS) afterScripts();
      else cuts.forEach(function(nm) { var s = document.createElement("script"); s.src = "scene/img_" + nm + ".js"; s.onload = s.onerror = function() { if (--pendS === 0) afterScripts(); }; document.body.appendChild(s); });
   } catch (e) { fwFatal(e); }
}

// la escena del paquete -> la del motor (typed arrays en doble)
function fwSceneFromJson(J) {
   var s = J.stars, S = { n: s.n, x: Float64Array.from(s.x), y: Float64Array.from(s.y), z: Float64Array.from(s.z), g: Float32Array.from(s.g), dEarth: Float32Array.from(s.dEarth),
                         col: Uint32Array.from(s.col), colSrc: Uint8Array.from(s.colSrc), q: Uint8Array.from(s.q), inFrame: Uint8Array.from(s.inFrame), meta: s.meta };
   if (s.colTrue) S.colTrue = Uint32Array.from(s.colTrue);
   if (s.colG && s.colGT) { S.colG = Uint32Array.from(s.colG); S.colGT = Uint32Array.from(s.colGT); }      // (B1) GAIA = la temperatura
   var sc = { version: J.version, field: J.field, stars: S, nebula: J.nebula, notes: J.notes || [], routes: J.routes || [], facts: J.facts || null, galaxy: J.galaxy || null,
              objects: (J.objects && J.objects.length) ? J.objects : null, music: J.music || [], hero: J.hero || null, noData: J.noData || null,      // (21-nov, T1-A) las filas «sin datos» de MIRABILIA (fw_nav.js)
              // (F2, 20-nov) las candidatas a fugitiva ya calculadas por PixInsight (engine/fv_runaway.js, fvRunExport); un paquete anterior no las trae: ninguna (no se recalculan con menos datos)
              runaway: (J.runaway && J.runaway.list) ? J.runaway : { pre: true, key: "old-package", list: [], counts: {}, err: "none" } };      // (17-nov, F8) hero: el protagonista de la foto (fw_nav.js, FW_HERO)
   // color: el de la foto si lo hay (colSrc 1); si no, el de cuerpo negro de su Teff (modulo cientifico, el mismo que PixInsight); si no, el del paquete
   // (N13) cache por Teff redondeada a 10 K: 18 000 llamadas a fvsBlackbodyColour eran ~25 ms; con cache, unas 600
   sc.starRgb = new Array(S.n);
   var bb = 0, memo = {};
   for (var i = 0; i < S.n; ++i) {
      var m = S.meta[i] || {};
      if (S.colSrc[i] !== 1 && m.teff > 0 && typeof fvsBlackbodyColour === "function") {
         var kT = Math.round(m.teff / 10), c = memo[kT]; if (!c) { var b = fvsBlackbodyColour(kT * 10); c = memo[kT] = [b.r / 255, b.g / 255, b.b / 255]; }
         sc.starRgb[i] = c; ++bb;
      } else sc.starRgb[i] = fwHexToRgb(S.col[i]);
   }
   sc.nBlackbody = bb;
   return sc;
}

function fwStart(J, imgs) {
   fwShip("filters", "ok"); fwShip("charts", "warm");
   var scene = fwSceneFromJson(J), canvas = document.getElementById("gl"), win = document.getElementById("win");
   // (nF2) la foto es el fondo: las distancias SUPUESTAS no pasan de la nebulosa, ANTES de subir las estrellas a la GPU (el piloto lo haria
   // despues; con un paquete ya recolocado no cambia nada)
   if (typeof fvSceneTuckAssumed === "function") { try { fvSceneTuckAssumed(scene); } catch (eTk) {} }
   FW.scene = scene; FW.json = J; FW.imgs = imgs;
   fwShip("charts", "ok"); fwShip("range", "warm");
   fwBootBar(0.3);
   fwNext(function() {
      fwShip("range", "ok"); fwShip("dome", "warm");
      var R = new FWRenderer(canvas, scene, imgs); FW.R = R;
      fwShip("dome", "ok");
      if (!R.webgl2) throw new Error(fwTr("This browser has no WebGL2: use a recent Chrome, Edge or Firefox.", "Este navegador no tiene WebGL2: usa un Chrome, Edge o Firefox recientes."));
      var ck = new FWCockpit(document.body, scene, { button: fwButton, mode: function() { fwSetMode(FW.mode === "spectacular" ? "cine" : "spectacular"); }, rec: fwRecToggle, cardClose: fwCardClose, speed: fwSetSpeed, look: function(l) { fwSetLook(l, true); }, pad: fwPadHook }); FW.ck = ck;
      if (imgs.layer0 || imgs.starless) ck.cardNebImg = imgs.starless || imgs.layer0;
      FW.radio = new FWRadio(ck); FW.radio.setPackaged(scene.music);
      if (typeof FW_M1 !== "undefined" && FW_M1.pending) FW.radio.m1Start();         // (19-nov, M1) POTENTIA se tiro antes de que el visor tuviera radio
      FW.rec = new FWRecorder(canvas, { fps: (J.clock && J.clock.fps) || 30 });
      fwShip("sensors", "warm");
      FW.nav = new FWNav(scene, imgs.photo, { select: function(sel) { fwUserAct(); fwSelectSel(sel); }, travel: function(sel) { fwUserAct(); fwSelectSel(sel); fwTravel(sel); }, lookAt: fwLookAtUV, travelNear: fwTravelNear,
                                                     open: (typeof FWRoute === "function") ? function(w) { if (FW.route) FW.route.toggle(w); } : undefined });   // (pasada M) clic = el mapa en grande
      fwShip("sensors", "ok"); fwShip("atlas", "warm");
      ck.onMilkyWay = function(on) { FW.R.opt.milkyway = on; };   // (11-nov, NV-16) la fila de la leyenda: Via Lactea de fondo y campo simulado (fw_amb.js)
      ck.setLegend(scene, scene.notes, []);
      fwShip("atlas", "ok"); fwShip("shields", "warm");
      fwBootBar(0.5);
      fwNext(function() {
         // (N8) los objetos compactos: recortes y foto sin estrellas SIN ellos (para el relieve)
         var src = fwObjectCuts(scene, imgs, R); FW.srcCanvas = src;
         fwResize();
         FW.P = fvPilotNew(scene, FW.VW, FW.VH);
         fwLabInit(FW.P);                                // (11-nov, NV-13) la navegacion de PixInsight (FW_LAB.ON)
         fwSpeedInit();
         fwLookInit();                                   // (5-nov) STELLAE
         FW.P.onFlightEnd = fwOnArrive;
         fwSetMode("cine");
         fwInput(win);
         if (typeof fwNmThumbBuild === "function") fwNmThumbBuild();      // (20-nov, O1) la miniatura de TU FOTO, una sola vez aqui (nunca al pintar)
         if (typeof fwNmBind === "function") fwNmBind(win);   // (20-nov, E-nav) la mano y el tooltip sobre el marcador TU FOTO
         if (typeof fwHrBind === "function") fwHrBind(win);   // (I2, 19-nov) el cursor sobre los puntos del diagrama HR
         // (pasada M) ITINERARIUM: el mapa en grande, las camaras de la ruta y la fila de viaje de la ficha (fw_route.js)
         if (typeof FWRoute === "function") { try { FW.route = new FWRoute(win); } catch (eR) { FW.route = null; console.warn("route: " + eR); } }
         window.addEventListener("resize", fwResize);
         window.addEventListener("blur", fwReleaseKeys);
         fwShip("shields", "ok"); fwShip("holo", "warm");
         fwBootBar(0.7, "FIELD VOYAGER · " + fwTr("warming up the instruments", "calentando los instrumentos"));
         // los shaders en paralelo, sin bloquear; despues se arranca el bucle
         R.precompile().then(function(ms) {
            FW.last = performance.now(); FW.ready = true; FW.bootMs = performance.now() - FW.t0;
            FW.info = { renderer: R.info.renderer, volume: R.info.volume, layers: R.info.layers, stars: R.info.stars, blackbody: scene.nBlackbody, bootMs: Math.round(FW.bootMs), compileMs: ms,
                        webcodecs: FW.rec.webcodecs, objects: R.info.objects || 0, trueColour: R.info.trueColour || 0, engine: { key: typeof fvPilotKey === "function", objects: typeof fvObjectHit === "function" }, music: scene.music.length };
            requestAnimationFrame(fwLoop);
            fwShip("holo", "ok");
            fwBootBar(1);
            // el volumen llega del Worker; mientras, capas (la foto exacta en casa en los dos casos)
            if (src) R.prepareNebula(src, function(v) { FW.info.volume = v; FW.volReady = !!R.vol; FW.volMs = Math.round(performance.now() - FW.t0); if (!R.vol) ck.setLegend(scene, scene.notes, [fwTr("Nebula drawn as layers (no volume)", "Nebulosa en capas (sin volumen)")]); });
            else { FW.volReady = false; ck.setLegend(scene, scene.notes, [fwTr("Nebula drawn as layers (no volume)", "Nebulosa en capas (sin volumen)")]); }
            // (6-nov) con la nave del arranque, su brillo final (≤ 1 s mas si la cola de flechas iba atrasada) y luego se funde
            fwWarmCard(function() { var gone = function() { FW.bootGoneMs = performance.now() - FW.t0; document.getElementById("boot").classList.add("gone"); };
                                    if (typeof fwShipFinish === "function") fwShipFinish(gone); else gone(); });
         }).catch(fwFatal);
      });
   });
}

// (N13) la PRIMERA ficha costaba ~90 ms de fotograma (medido 4-nov: 4 fotogramas > 25 ms la primera vez, 0 las siguientes; sin
// guion > 5 ms en long-animation-frame: es el primer rasterizado de la ficha). Se abre una vez detras de la pantalla de arranque,
// unos fotogramas, y se cierra: la ficha de verdad (2 s despues de llegar) ya no da el tiron. done() quita la pantalla de arranque.
function fwWarmCard(done) {
   var S = FW.scene.stars, best = -1, g = 99, i, n = 0;
   try {
      for (i = 0; i < S.n; ++i) if (S.inFrame[i] && S.g[i] < g) { g = S.g[i]; best = i; }
      if (best < 0 || !FW.P) { setTimeout(done, 60); return; }
      var q = fvProjector(FW.P.cam, FW.VW, FW.VH).project(fvStarPos(FW.scene, best));
      var s = { kind: "star", i: best, sx: q ? q[0] : FW.VW / 2, sy: q ? q[1] : FW.VH / 2, t0: FW.P.t, warm: true };
      // la ficha sale a los 0,55 s (anillo, linea y maquina de escribir): se adelanta su reloj para que salga ENTERA ya
      FW.P.sel = s; fwShowCard(s); FW.ck.cardT0 = performance.now() - 10000;
      // el texto ENTERO de la ficha (la maquina de escribir solo pinta unas letras en 6 fotogramas) en las mismas letras, fuera de la
      // pantalla: la primera vez que aparece un simbolo que la Palatino no tiene (☉, ⁻¹, ≈…) Windows busca otra letra y eso es lo caro
      var txt = fwCardLines(s).map(function(l) { return l.t; });
      if (FW.scene.objects && FW.scene.objects.length) { try { txt = txt.concat(fwObjCardLines(0).map(function(l) { return l.t; })); } catch (eO) {} }
      txt.push("☉ ⊙ ≈ ± − × · ° ′ ″ µ ² ³ ⁻¹ ₀ ₁ ₂ Å λ Δ α β γ → ← ↑ ↓ … — – « » ‰ ≤ ≥ √ ∞");
      var wd = document.createElement("div"); wd.setAttribute("aria-hidden", "true");
      wd.style.cssText = "position:fixed;left:-20000px;top:0;white-space:pre;pointer-events:none";
      ["14px var(--serif)", "italic 14px var(--serif)", "500 19px var(--serif)", "700 13px var(--display)", "600 11px var(--display)"].forEach(function(f) {
         var d = document.createElement("div"); d.style.font = f; d.textContent = txt.join("\n"); wd.appendChild(d);
      });
      // (N13) el PRIMER boton encendido costaba 40–100 ms de fotograma (medido 4-nov con probe_btn: «on info» 42 ms la primera vez, 9 ms
      // despues, y 9 ms siempre sin filtros CSS): el primer uso de los filtros de .on (brillo + resplandor) compila sus sombreadores en la
      // GPU. Un boton encendido clonado, casi transparente (1 %: con 0 el navegador no lo pinta) y DENTRO de la pantalla, los compila ya.
      var bw = document.createElement("div"); bw.style.cssText = "position:fixed;left:2px;top:2px;opacity:.01;pointer-events:none;z-index:50";
      if (FW.ck.btn && FW.ck.btn.info) { var cb = FW.ck.btn.info.cloneNode(true); cb.removeAttribute("id"); cb.disabled = false; cb.classList.add("on"); cb.tabIndex = -1; bw.appendChild(cb);
         var ch = FW.ck.btn.info.cloneNode(true); ch.removeAttribute("id"); ch.disabled = true; ch.tabIndex = -1; bw.appendChild(ch); }
      wd.appendChild(bw); wd.style.left = "0"; wd.style.opacity = ".01"; wd.style.zIndex = "50";
      document.body.appendChild(wd); FW.warmDiv = wd;
   } catch (e) { setTimeout(done, 60); return; }
   (function tick() {
      if (++n < 6) { requestAnimationFrame(tick); return; }
      if (FW.P.sel && FW.P.sel.warm) { FW.P.sel = null; FW.ck.hideCard(); fwHeroUpdate(); }
      if (FW.warmDiv) { FW.warmDiv.remove(); FW.warmDiv = null; }
      done();
   })();
}

// ---------------------------------------------------------------------------
// (N8) LOS RECORTES DE LOS OBJETOS COMPACTOS y la foto sin estrellas sin ellos. Con el recorte de C (o.cut: imagen + rectangulo en px de
// trabajo) se usa ese; si no, se recorta aqui de la foto sin estrellas: disco suave de 1,25 radios (o.px.r) menos el fondo (mediana del
// anillo de 1,3 a 1,7 radios). En los dos casos la foto sin estrellas que va al relieve es la de antes MENOS el recorte: desde la Tierra
// la suma vuelve a ser la foto exacta (el objeto en sus capas + el resto en el volumen). -> el lienzo de la foto sin estrellas a usar
// ---------------------------------------------------------------------------
var FW_OBJCUT = { R_K: 1.25, BG0: 1.3, BG1: 1.7, TYPES: { pn: 1, galaxy: 1, nebula: 1, other: 1 } };
function fwObjectCuts(scene, imgs, R) {
   var st = imgs.starless; if (!st) return null;
   var cv = document.createElement("canvas"); cv.width = st.width; cv.height = st.height;
   var g = cv.getContext("2d", { willReadFrequently: true }); g.drawImage(st, 0, 0);
   var O = scene.objects, list = [];
   if (!O) return cv;
   var f = scene.field;
   for (var i = 0; i < O.length; ++i) {
      var o = O[i];
      if (!o || o.main || !FW_OBJCUT.TYPES[o.type] || !o.pos || !o.px || !(o.px.x >= 0) || !(o.px.r > 0)) continue;
      if (o.seg && o.seg.ok === false) continue;
      var wk = o.workK > 0 ? o.workK : st.width / f.width, s = st.width / (f.width * wk);     // px de trabajo -> px de la foto sin estrellas (≈ 1)
      var it = { o: o, i: i, kPhoto: 1 / (wk * s) };
      if (o.cut && imgs[o.cut.img]) {
         var c = o.cut, im = imgs[o.cut.img], cc = document.createElement("canvas"); cc.width = im.width; cc.height = im.height; cc.getContext("2d").drawImage(im, 0, 0);
         it.canvas = cc; it.x0 = c.x0 * s; it.y0 = c.y0 * s; it.w = c.w * s; it.h = c.h * s; it.cx = c.cx * s; it.cy = c.cy * s; it.rMax = (c.rMax || o.px.r) * s; it.K = c.K;
         g.globalCompositeOperation = "difference"; g.drawImage(cc, it.x0, it.y0, it.w, it.h); g.globalCompositeOperation = "source-over";
         it.how = "C";
      } else {
         var cx = o.px.x * s, cy = o.px.y * s, r = Math.max(2, o.px.r * s), half = Math.ceil(FW_OBJCUT.BG1 * r * FW_OBJCUT.R_K) + 2;
         var x0 = Math.max(0, Math.floor(cx - half)), y0 = Math.max(0, Math.floor(cy - half)), x1 = Math.min(st.width, Math.ceil(cx + half)), y1 = Math.min(st.height, Math.ceil(cy + half)), w = x1 - x0, h = y1 - y0;
         if (w < 4 || h < 4) continue;
         var D = g.getImageData(x0, y0, w, h), d = D.data, ring = [[], [], []], rr = r * FW_OBJCUT.R_K, xx, yy;
         for (yy = 0; yy < h; ++yy) for (xx = 0; xx < w; ++xx) { var q = Math.hypot(x0 + xx + 0.5 - cx, y0 + yy + 0.5 - cy) / rr; if (q >= FW_OBJCUT.BG0 && q <= FW_OBJCUT.BG1) { var k4 = 4 * (yy * w + xx); ring[0].push(d[k4]); ring[1].push(d[k4 + 1]); ring[2].push(d[k4 + 2]); } }
         var bg = ring.map(function(a) { if (!a.length) return 0; a.sort(function(p, q2) { return p - q2; }); return a[a.length >> 1]; });
         var cc2 = document.createElement("canvas"); cc2.width = w; cc2.height = h; var g2 = cc2.getContext("2d"), C = g2.createImageData(w, h), cd = C.data;
         for (yy = 0; yy < h; ++yy) for (xx = 0; xx < w; ++xx) {
            var k = 4 * (yy * w + xx), qq = Math.hypot(x0 + xx + 0.5 - cx, y0 + yy + 0.5 - cy) / rr, al = 1 - fvSmooth((qq - 0.75) / 0.4);
            for (var ch = 0; ch < 3; ++ch) { var v = Math.max(0, d[k + ch] - bg[ch]) * al; cd[k + ch] = Math.round(v); d[k + ch] = Math.max(0, d[k + ch] - cd[k + ch]); }
            cd[k + 3] = 255;
         }
         g2.putImageData(C, 0, 0); g.putImageData(D, x0, y0);
         it.canvas = cc2; it.x0 = x0; it.y0 = y0; it.w = w; it.h = h; it.cx = cx; it.cy = cy; it.rMax = rr; it.how = "viewer";
      }
      list.push(it);
   }
   if (list.length) R.buildObjects(list);
   FW.objCuts = list.map(function(it) { return { i: it.i, name: it.o.name, how: it.how, w: Math.round(it.w), h: Math.round(it.h) }; });
   return cv;
}

function fwResize() {
   var win = document.getElementById("win"), cv = document.getElementById("gl"), hud = document.getElementById("hud");
   var VW = Math.max(64, win.clientWidth), VH = Math.max(64, win.clientHeight), dpr = Math.min(2, window.devicePixelRatio || 1);
   FW.VW = VW; FW.VH = VH; FW.dpr = dpr;
   // (N7) la escala de la cabina, la ficha y la leyenda (la misma --u del CSS)
   FW.uiK = Math.min(window.innerWidth * 0.01, window.innerHeight * 0.016) / 17.28;
   cv.style.width = VW + "px"; cv.style.height = VH + "px";
   hud.width = Math.round(VW * dpr); hud.height = Math.round(VH * dpr); hud.style.width = VW + "px"; hud.style.height = VH + "px";
   if (FW.R) FW.R.resize(Math.round(VW * dpr), Math.round(VH * dpr));
   if (FW.P) fvPilotResize(FW.P, VW, VH);
   // (11-nov, NV-13) fvPilotResize no sabe del laboratorio: deja el campo de casa del motor de antes (0,76° en IC 1848) con la S del laboratorio
   // (×55) y en casa se veia un trozo de la foto (vista limpia: r −0,07 frente a 0,93; tests/web/fv_nD_cdp.js T1 con la bandera puesta). El
   // laboratorio rehace su S y su campo de casa para la vista nueva conservando la mirada real (lo de la tecla V con el mismo modo)
   if (FW.P && fwLabOn() && typeof fvLabSetS === "function") fvLabSetS(FW.P, FV_LAB.S_MODE);
   if (FW.nav) FW.nav.resize();
   if (FW.route) FW.route.resize();
}

function fwSetMode(m) {
   if (m === "smooth") m = "cine"; if (m === "spect") m = "spectacular";
   FW.mode = m;
   if (FW.P) fvPilotSetStyle(FW.P, m);
   fwApplyProfile(m);
   FW.ck.setMode(m === "spectacular");
}
// los efectos de un perfil (bloom, grano, vineta, halo, pasos) en las opciones del render
function fwApplyProfile(m) {
   var pr = FW_PROFILE[m]; FW.prof = pr;
   var o = FW.R.opt; o.bloomK = pr.bloomK; o.grain = pr.grain; o.vig = pr.vig; o.aberr = pr.aberr; o.steps = pr.steps; o.halo = pr.halo;
   if (FW.cleanOn) { o.grain = 0; o.vig = 0; }
}
// (21-nov, N-galaxias-warp; FV_GWARP) sin selector MODUS el estilo del piloto es siempre «cine» (el destino elige el modo de viaje) y el perfil de EFECTOS de WARP (destello, estelas, bloom, temblor)
// entra solo mientras corre un vuelo con efecto de warp (el salto a una galaxia o la vuelta desde una galaxia): lo que antes daba la palanca, ahora lo da el vuelo. false = el perfil del MODUS
function fwProfSync() {
   if (!fvGwarpUi() || !FW.P || !FW.R) return;
   var want = fvIsWarpFl(FW.P.flight) ? "spectacular" : "cine";
   if (FW.profNow === want) return;
   FW.profNow = want; fwApplyProfile(want);
}

// arrancar un vuelo (el motor decide camino y perfil: «warp», «cine», «home»)
// (W1, precarga) al empezar el viaje se compone ya la ficha de destino (fw_card_pi.js): al llegar sale sin esperar
// (P11b, 14-nov) R8 en la web: el encuadre del contorno (fvObjectTarget.frame, fvObjFrameFit) lo aplica el piloto solo a una seleccion kind "object" (fv_pilot.js: S.centered);
// el elemento de la nebulosa principal de MIRABILIA es kind "nebula" (la ficha y el reloj del visor cuelgan de eso), asi que VOLABA a la distancia de antes de R8
// (IC 1848: 131 a.l., 50°, contorno 0 % en pantalla; PixInsight: 6 340 a.l., 0,58°, 100 %). Solo el VUELO usa la seleccion del objeto principal (sel.obj, de fwNavSel en fw_nav.js);
// P.sel y la ficha siguen siendo los de la nebulosa. FV_OBJ.FRAME = false o sin contorno en el paquete: como antes
function fwFlySel(sel) {
   if (!sel || sel.kind !== "nebula" || !(sel.obj >= 0) || !FW.scene.objects || typeof FV_OBJ === "undefined" || !FV_OBJ.FRAME) return sel;
   var o = FW.scene.objects[sel.obj]; return (o && o.main && o.frame && o.frame.pos) ? { kind: "object", i: sel.obj, t0: sel.t0 } : sel;
}
function fwFly(kind, sel) { if (kind === "goto") kind = "cine"; FW.flyFrom = FW.P.t; if (typeof fwCardPiPrefetch === "function") fwCardPiPrefetch(sel || FW.P.sel); return fvPilotFly(FW.P, kind, fwFlySel(sel)); }
// VIAJAR al objeto elegido con el estilo del MODUS; (N4) si su ficha estaba abierta, se oculta y se reabrira al llegar
// (pasada M) kind: "cine" | "warp" para viajar en el OTRO modo (boton de la ficha); sin el, el del MODUS
function fwTravel(sel, kind) {
   var P = FW.P; sel = sel || P.sel; if (!sel) return false;
   var wasOpen = !!(FW.ck.cardSel && !FW.ck.cardHidden);
   // (N2, punto 2 de Nino) la ficha del destino se abre SIEMPRE al llegar (la hubiese abierto el usuario o no); durante el viaje esta
   // oculta. Si la cierra con × en pleno viaje, no vuelve (fwCardClose). FW.legacyCardOnlyIfOpen = lo de antes: solo si ya estaba abierta
   // (control en rojo de las pruebas; con FW.legacyK4 tambien el de la revision 3, que perdia la intencion al sustituir un viaje)
   if (!P.sel || P.sel.kind !== sel.kind || P.sel.i !== sel.i) { sel.t0 = P.t; P.sel = sel; fwHeroUpdate(); }
   var reopenWanted = (FW.legacyCardOnlyIfOpen || FW.legacyK4) ? (FW.legacyK4 ? wasOpen : (wasOpen || FW.arriveReopen || FW.reopenAt != null)) : true;
   var ok = fwFly(kind || (fvGwarpUi() ? "travel" : (FW.mode === "spectacular" ? "warp" : "cine")), sel);      // (21-nov, N-galaxias-warp) con FV_GWARP el destino elige: «travel» (fvTravelKind)
   if (ok) { FW.cardClosedByUser = false; FW.arriveReopen = reopenWanted; if (wasOpen) FW.ck.cardHidden = true; FW.reopenAt = null; }
   return ok;
}
// (N4) al llegar (P.onFlightEnd del motor): la ficha que se oculto al salir se reabre CARD_DELAY_S despues (el plano «respira», §10.5)
function fwOnArrive(P, fl) {
   if (fl && fl.kind !== "home" && fl.kind !== "look" && FW.arriveReopen && P.sel) FW.reopenAt = P.t + FW_WARPFX.CARD_DELAY_S;
   FW.arriveReopen = false; FW.arrivedAt = P.t; FW.lastArrive = fl ? fl.kind : null;
   // (14-nov, P11a) la llegada del TOUR ya no se toma aqui: la ve fwTourStep (estado «fly» -> «hold», como tourStep de PixInsight), asi vale igual
   // para un viaje que sustituye a otro (SIGUIENTE / ANTERIOR en pleno vuelo) y hay un solo sitio donde empieza la espera de leer
}
// (punto 8 de Nino) REGULATOR = la velocidad del viaje (cine, warp y ruta; con FAST_EASE todo el viaje: arranque, frenada y fases del salto),
// 0…1 (0,5 = la de por defecto) -> fvPilotSetSpeed del motor de B (si lo hay);
// recordada entre sesiones en localStorage (por navegador y carpeta: un convenio de comodidad, no un dato que haya que conservar)
function fwSetSpeed(s, done) {
   FW.speed = s;
   if (typeof fvPilotSetSpeed === "function" && FW.P) { try { fvPilotSetSpeed(FW.P, s); } catch (e) {} }
   if (done) { try { localStorage.setItem("fv.travelSpeed", s.toFixed(2)); } catch (e) {} }
}
function fwSpeedInit() {
   var s = 0.5; try { var v = parseFloat(localStorage.getItem("fv.travelSpeed")); if (!isNaN(v)) s = fvClamp(v, 0, 1); } catch (e) {}
   FW.speed = s; if (FW.ck) FW.ck.setSpeed(s, false);
   if (typeof fvPilotSetSpeed === "function" && FW.P) { try { fvPilotSetSpeed(FW.P, s); } catch (e2) {} }
}
// (5-nov) STELLAE: el aspecto de las estrellas, "gaia" | "phcol" | "phstar", con lo que exporto PixInsight (J.photoStars + la imagen psatlas).
// Recordado en localStorage (comodidad por navegador y carpeta); sin nada recordado, el que tenia PixInsight al exportar. -> el aspecto puesto
var FW_PS_B1 = true;      // (B1, 5-nov) true: GAIA = color de la temperatura (colG), COLOR = el de la foto con el verde recortado; false = el STELLAE de antes (ROJO)
function fwSetLook(look, save) {
   var ps = (FW.json && FW.json.photoStars) || null, img = FW.imgs ? FW.imgs.psatlas : null;
   var got = FW.R ? FW.R.setStarLook(look, ps, img) : "gaia";
   FW.look = got;
   if (FW.ck) FW.ck.setLook(got, { gaia: true, phcol: !!(FW.R && FW.R.starB1()) || !!(ps && ps.rgb), phstar: !!(ps && ps.spr && img) });
   if (save) { try { localStorage.setItem("fv.starLook", got); } catch (e) {} }
   return got;
}
function fwLookInit() {
   var ps = (FW.json && FW.json.photoStars) || null, lk = ps && ps.look ? ps.look : "gaia";
   try { var v = localStorage.getItem("fv.starLook"); if (v === "gaia" || v === "phcol" || v === "phstar") lk = v; } catch (e) {}
   return fwSetLook(lk, false);
}
// (14-nov, R3 H3) al cerrar la ficha el cursor deja de estar «sobre ella»: una ficha oculta no manda pointerleave y FW.cardHover se quedaba en true (el tour
// seguia «EN ESPERA MIENTRAS LEES» con la ficha cerrada)
function fwCardClose() { if (!FW.ck.cardSel) return; FW.ck.cardHidden = true; FW.cardClosedByUser = true; FW.cardHover = false; FW.reopenAt = null; FW.arriveReopen = false; fwTourCardClosed(); }
// (16-nov, P17; FV_TOUR_READ.CLOSE_NOW, DECISION DE NINO, apagada de fabrica; gemela de tourCardClosed de fv_dialog.js) con el tour esperando en una parada, cerrar la ficha
// (× o Esc o INFO) pasa ya a la siguiente. En pausa del usuario, en vuelo o con la barra del tour apagada no
function fwTourCardClosed() {
   var T = FW.tour;
   if (typeof FV_TOUR_READ === "undefined" || !FV_TOUR_READ.CLOSE_NOW || !T || !FW.P || !FW_TOUR_BAR.ON || T.state !== "hold" || FW.P.flight || T.paused) return false;
   fwTourGoTo(T.k + 1); fwTourBarSync(); fwButtonsState();
   return true;
}
function fwCardReopen() {
   var P = FW.P; FW.reopenAt = null; if (!P.sel || FW.cardClosedByUser) return;
   FW.ck.cardHidden = false; fwShowCard(P.sel);
}

// mirar a un punto de la foto (clic en TABULA): un giro suave sin moverse (el vuelo «look» del motor, como «mirar al Sol»)
function fwLookAtUV(uv) {
   fwUserAct();
   var P = FW.P, sc = FW.scene, f = sc.field, d = sc.nebula ? sc.nebula.distLy : 1000, p = fvPixelPoint(sc, uv[0] * f.width, uv[1] * f.height, d);
   var to = fvNorm(fvSub(p, P.cam.pos));
   if (P.flight) return false;
   // (11-nov, NV-13) con el laboratorio, su propio giro «look» (la mirada objetivo va en el espacio de VUELO: x, y × S); un vuelo hecho a mano no lo entiende
   if (fwLabOn()) return fvPilotFly(P, "look", { dir: fvNorm(fvLabRelFly(to, P.lab.S)) }) === true;
   P.orbit = null; P.coast = null; if (P.free && typeof fvFreeHalt === "function") fvFreeHalt(P);
   P.flight = { kind: "look", t: 0, sel: null, p0: P.cam.pos.slice(), p1: P.cam.pos.slice(), look0: P.cam.look.slice(), look1: to, fov0: P.cam.fov, fov1: P.cam.fov,
                dur: Math.max(1.2, Math.min(4, fvAngle(P.cam.look, to) / FV_DEG / 6)), pre: 0, phase: "depart" };
   P.mode = "flight"; P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] };
   return true;
}
// viajar a lo mas cercano de un punto de la foto (doble clic en TABULA): objeto de C o estrella brillante y medida
function fwTravelNear(uv) {
   fwUserAct();
   var sc = FW.scene, S = sc.stars, best = null, bs = 1e9, i;
   if (sc.objects) for (i = 0; i < sc.objects.length; ++i) { var o = sc.objects[i]; if (!o.pos || o.main) continue; var u = fwNavPhotoUV(sc, o.pos); if (!u) continue; var d = Math.hypot(u[0] - uv[0], u[1] - uv[1]); if (d < 0.03 && d < bs) { bs = d; best = fwNavSel(sc, { kind: "object", i: i }); } }
   if (!best) for (i = 0; i < S.n; ++i) { if (!S.inFrame[i] || S.q[i] > 1 || S.g[i] > 13) continue; var u2 = fwNavPhotoUV(sc, fvStarPos(sc, i)); if (!u2) continue; var sco = Math.hypot(u2[0] - uv[0], u2[1] - uv[1]) * 60 + 0.25 * S.g[i]; if (sco < bs) { bs = sco; best = { kind: "star", i: i }; } }
   if (best) { fwSelectSel(best); fwTravel(best); }
   return best;
}

// (F3c) LAS FECHAS DE LA LUZ, con la precision que da la distancia (las mismas reglas para F4b en PixInsight):
//   σ = semi-anchura del intervalo de la distancia (Bailer-Jones, o el de la nebulosa); sin intervalo y MEDIDA: 10 % (NO VERIFICADO:
//   eleccion nuestra); SUPUESTA: sin fecha. El año se redondea a la potencia de 10 de σ (σ 230 → centenas: «hacia el 4500 a. C.»);
//   «N años antes de X» se redondea igual, y si N < σ se dice «en la época de X».
function fwRoundStep(sig) { return Math.pow(10, Math.max(0, Math.floor(Math.log(Math.max(1, sig)) / Math.LN10))); }
function fwObsYear() { var f = FW.scene.field || {}; return (f.obsYear > 1800) ? f.obsYear : new Date().getFullYear(); }
// año (historico, sin año 0) en que salio la luz que llega a la camara desde dLy, redondeado al paso -> { y, txt }
function fwLightYear(dLy, step, epoch) {
   var now = fwObsYear() + (epoch || 0), y = now - dLy, yr = (step <= 1) ? Math.round(y) : Math.round(y / step) * step, yh;
   if (step > 1) yh = (yr <= 0) ? yr : yr;      // redondeado a decenas o mas: «4500 a. C.» (no «4501»): el año 0 no importa a esa escala
   else yh = (yr < 1) ? yr - 1 : yr;            // astronomico -> historico
   if (yh === 0) yh = 1;
   return { y: yh, txt: fvsFmtYear(yh, FW_LANG) };
}
function fwLightPhrase(dLy, sig) {
   var es = FW_LANG === "es";
   if (!(sig > 0)) return es ? "Distancia supuesta: no se sabe cuándo salió la luz que ves." : "Assumed distance: there is no telling when the light you see left it.";
   if (dLy < 1) return es ? "La luz que ves salió hace menos de un año." : "The light you see left it less than a year ago.";
   var step = fwRoundStep(sig), now = fwObsYear();
   var e = fvsLightEpoch(dLy, now), Y = fwLightYear(dLy, step), pm = fvsFmtNum(Math.max(step, Math.round(sig / step) * step), 0, FW_LANG);
   if (e.mode !== "year" || !e.event) {
      return es ? "La luz que ves salió hace unos " + fvsFmtSig(dLy, 2, FW_LANG) + " años (± " + pm + ")." : "The light you see left about " + fvsFmtSig(dLy, 2, FW_LANG) + " years ago (± " + pm + ").";
   }
   var ev = es ? e.event.es : e.event.en, ey = fvsFmtYear(e.event.year, FW_LANG);
   var head = es ? "La luz que ves salió hacia el " + Y.txt + " (± " + pm + " años)" : "The light you see left around " + Y.txt + " (± " + pm + " years)";
   if (e.gap < sig) return head + (es ? ", en la época de " + ev + " (" + ey + ")." : ", in the time of " + ev + " (" + ey + ").");
   var n = fvsFmtNum(Math.max(step, Math.round(e.gap / step) * step), 0, FW_LANG), before = e.rel === "before";
   return head + (es ? ", unos " + n + " años " + (before ? "antes" : "después") + " de " + ev + " (" + ey + ")." : ", some " + n + " years " + (before ? "before" : "after") + " " + ev + " (" + ey + ").");
}
// el objeto de la luz del CHRONOMETRUM: el destino del viaje, la estrella elegida o a la que se llego; si no, la nebulosa
var FW_CHRONO_AETAS = true;
function fwChrono() {
   var o = fwChronoObject(); if (!o) return null;
   var d = fvLen(fvSub(o.pos, FW.P.cam.pos)), sig = fwDistSigma(o.sel);
   if (!(sig > 0)) return { known: false, d: d, kind: o.sel.kind };
   // (5-nov, Nino) con AETAS el «hoy» de la escena es el año elegido: CHRONOMETRUM se mueve con la palanca (FW_CHRONO_AETAS = false: ROJO)
   var ep = (FW_CHRONO_AETAS && FW.scene.time && FW.scene.time.years) ? FW.scene.time.years : 0;
   var Y = fwLightYear(d, fwRoundStep(sig), ep);
   return { known: true, d: d, year: Y.y, txt: Y.txt, sig: sig, kind: o.sel.kind };
}


function fwCardRgb(s) {
   if (s.kind !== "star") return null;
   var pc = (typeof fwCardPiRgb === "function") ? fwCardPiRgb(s) : null; if (pc) return pc;   // (W1) el color de la portilla de PixInsight
   var m = FW.scene.stars.meta[s.i] || {};
   if (m.teff > 0 && typeof fvsBlackbodyColour === "function") { var c = fvsExaggerateColour(fvsBlackbodyColour(m.teff), 1.8); return [c.r, c.g, c.b]; }
   var h = FW.scene.stars.col[s.i]; return [(h >>> 16) & 255, (h >>> 8) & 255, h & 255];
}
// (F3c) la fuente de la temperatura que trae PixInsight (en ingles) en el idioma de la cabina
function fwTeffSrc(t) {
   if (FW_LANG !== "es") return t;
   return String(t).replace(/BP−RP dereddened/i, "BP−RP sin el polvo").replace(/BP−RP, reddened/i, "BP−RP con el polvo de delante").replace(/dereddened/i, "sin el polvo").replace(/reddened/i, "enrojecido por el polvo");
}
// las lineas de la ficha (como fv_hud.js de PixInsight + las frases del modulo cientifico)
function fwCardLines(s) {
   // (W1, 6-nov) la ficha de PixInsight (fvCardContent, ui/fv_hud.js en el paquete; web/fw_card_pi.js); sin ella, la de antes
   var Lpi = (typeof fwCardPiLines === "function" && (s.kind === "star" || s.kind === "nebula")) ? fwCardPiLines(s) : null;
   if (Lpi) return Lpi;
   var sc = FW.scene, L = [], es = FW_LANG === "es", dec = function(x, k) { return x.toFixed(k).replace(".", es ? "," : "."); };
   if (s.kind === "star") {
      var S = sc.stars, m = S.meta[s.i] || {}, q = S.q[s.i], d = S.dEarth[s.i];
      L.push({ t: (m.hip > 0 && typeof fvStarTitle === "function") ? fvStarTitle(m) : "Gaia DR3 " + (m.sourceId ? m.sourceId : (m.ra !== undefined ? fvDesignation(m.ra, m.dec) : "#" + s.i)), c: "title" });      // (3b) con numero HIP: su nombre
      L.push({ t: fwTr("STAR", "ESTRELLA") + " · G " + dec(S.g[s.i], 2) + (m.bpRp !== undefined ? " · BP−RP " + dec(m.bpRp, 2) : ""), c: "mono dim" });
      var dl = fwTr("Distance ", "Distancia ") + fwFmtLy(d) + " " + fwTr("ly", "a.l.");
      if (q < 2 && m.lo && m.hi) dl += " (" + fwFmtLy(Math.min(m.lo, m.hi) * FV_LY_PER_PC) + "–" + fwFmtLy(Math.max(m.lo, m.hi) * FV_LY_PER_PC) + ")";      // (10) el menor primero
      L.push({ t: dl, c: "mono" });
      var st = null, ph = null;
      if (typeof fvsStar === "function" && m.teff > 0) {
         try {
            st = fvsStar({ teff: m.teff, G: S.g[s.i], ruwe: m.ruwe, rgeo: (q < 2 && m.distPc > 0) ? { pc: m.distPc, lo: m.lo, hi: m.hi } : undefined });
            ph = fvsStarPhrases(st, FW_LANG, new Date().getFullYear());
         } catch (eS) { st = null; ph = null; }
      }
      L.push({ t: (m.teff ? "Teff ≈ " + fwFmtInt(m.teff) + " K" + (st && st.spt ? " · " + st.spt : "") : "Teff: —"), c: "mono" });
      if (m.teff && m.teffSrc) L.push({ t: fwTr("temperature from ", "temperatura de ") + fwTeffSrc(m.teffSrc), c: "mono dim small" });
      var qt = (q === 0) ? [fwTr("MEASURED", "MEDIDA") + " · " + (m.src === "cluster-catalog" ? fwTr("cluster distance", "distancia del cúmulo") : (m.src === "bailer-jones" ? "Bailer-Jones 2021" : m.src === "hipparcos-2007" ? fwTr("distance: Hipparcos 2007 (not Gaia)", "distancia: Hipparcos 2007 (no Gaia)") : fwTr("Gaia DR3 parallax", "paralaje Gaia DR3"))), "ok"]
             : (q === 1) ? [fwTr("DOUBTFUL", "DUDOSA") + " · RUWE " + (m.ruwe ? dec(m.ruwe, 2) : "≥ 1.4"), "warn"]
             : [fwTr("ASSUMED · no reliable parallax", "SUPUESTA · sin paralaje de fiar"), "bad"];
      L.push({ t: qt[0], c: "mono " + qt[1] });
      // estrellas que F2 añade fuera de la foto (cielo de alrededor, anillo): se pintan igual; la ficha lo dice
      if (m.wide || m.outside || m.ring) L.push({ t: (m.ring ? fwTr("RING around the photo", "ANILLO alrededor de la foto") : fwTr("SKY AROUND · outside the photo", "CIELO DE ALREDEDOR · fuera de la foto")), c: "mono dim" });
      if (ph) { if (ph.lum && q < 2) L.push({ t: ph.lum, c: "phrase" }); if (ph.temp) L.push({ t: ph.temp, c: "phrase" }); }
      // (F3c) la fecha de la luz redondeada al error de la distancia (fvsLightPhrase daba «6,2 años antes» con ±230 años)
      L.push({ t: fwLightPhrase(d, fwDistSigma(s)), c: "phrase" });
      // (I13) la frase de la composicion (fw_card_xp.js; los datos viajan en el paquete: meta.sci)
      if (typeof fwCardSciLines === "function") L = L.concat(fwCardSciLines(s));
   } else {
      var N = sc.nebula;
      var nT = fwNebName(N, fwTr("Nebula", "Nebulosa"));
      L.push({ t: fwNebTitle(N, nT), c: "title" });
      L.push({ t: fwNebType(N, fwTr("Emission nebula", "Nebulosa de emisión")).toUpperCase() + " · " + Math.round(N.sizeArcmin) + "′" + (fwTitleAlias(N, nT) ? " · " + fwTitleAlias(N, nT).toUpperCase() : ""), c: "mono dim" });
      L.push({ t: fwTr("Distance ", "Distancia ") + fwFmtLy(N.distLy) + " " + fwTr("ly", "a.l.") + (N.measured && N.distLoLy ? " (" + fwFmtLy(Math.min(N.distLoLy, N.distHiLy)) + "–" + fwFmtLy(Math.max(N.distLoLy, N.distHiLy)) + ")" : ""), c: "mono" });
      L.push({ t: (N.measured ? fwTr("MEASURED · ", "MEDIDA · ") : fwTr("ASSUMED · ", "SUPUESTA · ")) + N.distRef, c: "mono " + (N.measured ? "ok" : "bad") });
      L.push({ t: fwTr("Thickness ", "Grosor ") + fwFmtLy(N.thickLy) + " " + fwTr("ly ASSUMED · 3-D relief ASSUMED", "a.l. SUPUESTO · relieve 3D SUPUESTO"), c: "mono warn" });
      L.push({ t: fwLightPhrase(N.distLy, fwDistSigma({ kind: "nebula" })), c: "phrase" });
   }
   return L;
}






// (F3c) UN PASO DEL VUELO: el motor (fvPilotStep) y, encima, dos cosas del visor:
//  (1) EL ENCUADRE NUNCA QUEDA VACIO: el destino no se sale de un cono de LOOK_K × el campo de vision alrededor del centro.
//      (pasada N) Solo en el tramo central del viaje de cine: la grua de llegada y el encuadre de B mandan al final (u > 0,8).
//  (2) LA PROTAGONISTA: la estrella a la que se va (o la elegida) se pinta con su color real y crece al acercarse (fwHeroUpdate).
var FW_FLY = { LOOK_K: 0.30, HERO_MAG: 3.5, HERO_SPAN: 2.5 };
function fwStep(P, dt) {
   fvPilotStep(P, dt);
   if (typeof fwHrStep === "function") fwHrStep(dt);   // (I2, 19-nov) el reloj del diagrama HR (web/fw_hr.js)
   if (FW.route) FW.route.step(P, dt);                // (pasada M) el recorrido de la ruta (respaldo) o el del motor
   var fl = P.flight, lab = fwLabOn();
   // (11-nov, NV-13) con el laboratorio NO hay corrector del encuadre: la nave lleva su base (cam.B) y escribir cam.look desde fuera es «alguien movio la
   // camara» (fvLabExternal -> fvLabSync: la nave se para). El destino en cuadro ya lo garantiza su correa (V4.LEASH). Y lo que lee del pintor, aqui
   if (lab) fwLabFeed(P);
   else if (fl && fl.T && fl.kind !== "home" && fl.kind !== "look" && fl.t < 0.8 * fl.dur) {
      var dT = fvNorm(fvSub(fl.Tlook || fl.T, P.cam.pos)), a = fvAngle(P.cam.look, dT), lim = FW_FLY.LOOK_K * P.cam.fov;
      // (6-nov, punto 2 de Nino) con KEEP_IN el morro no se tuerce hacia el destino si eso saca el eje de la foto (p. ej. de lejos a cerca: el destino queda atras)
      if (a > lim) { var lC = fvSlerpDir(P.cam.look, dT, 1 - lim / a); if (typeof fvKeepOkAt !== "function" || fvKeepOkAt(P, P.cam.pos, lC) || (typeof fvNmFreeLook === "function" ? fvNmFreeLook(P) : fvKeepBeyond(P, fl.Tlook || fl.T))) P.cam.look = lC; }
   }
   if (FW.reopenAt !== null && FW.reopenAt !== undefined && P.t >= FW.reopenAt && !P.flight) fwCardReopen();
   fwHeroUpdate();
}
// (11-nov, NV-13) LO QUE EL LABORATORIO LEE DEL PINTOR, una vez por paso (en PixInsight, fvLabUiAnchorFrame tras pintar cada fotograma):
//  · «hay paisaje»: estrellas que pintaria el pintor de PixInsight (FWRenderer.labLandFrame: sus reglas de paintStars, en la CPU y para ESTA camara,
//    sin esperar al fotograma; con las del sombreador del visor, 11 de 12 viajes salian distintos) y la foto en pantalla (su cuadrilatero recortado a la vista, si la foto o las capas se pintan) -> fvLabAnchorWant.
//    Sin esto la v5 no hace la media vuelta (lee P.lab.cover) ni acelera en los tramos sin paisaje (P.lab.land) y el viaje no es el de PixInsight
//  · la luz de la foto (fvLabLumGrid, 16 x 12): una vez por escena, de la foto sin estrellas
// FW_LAB.FEED "none" no da nada (ROJO de la paridad); "inject" toma lo que deja la prueba en FW.labInject ({ lum, q: [{ stars, cover }, …] });
// "ownlum" (prueba) da lo propio salvo la rejilla de luz, que toma de FW.labInject.lum: separa las dos fuentes de diferencia
function fwLabFeed(P) {
   var L = P.lab; if (!L || !FW.R) return;
   var md = FW_LAB.FEED, I = FW.labInject;
   if (md === "none") return;
   var fr = FW.R.labLandFrame(P);      // la protagonista y la elegida las decide dentro, como FVPainter.paintStars
   FW.labLast = fr;
   if (md === "inject" && I) {         // lo de la prueba manda; lo propio queda en FW.labLast para compararlo en la misma pose
      if (I.lum && L.lumFor !== "inject") { L.lum = I.lum; L.lumFor = "inject"; }
      var e = I.q && I.q.length ? I.q.shift() : null;
      if (e && typeof fvLabAnchorWant === "function") fvLabAnchorWant(P, { stars: e.stars }, e.cover);
      return;
   }
   if (typeof fvLabAnchorWant === "function") fvLabAnchorWant(P, { stars: fr.stars }, fr.cover);
   if (md === "ownlum" && I && I.lum) { if (L.lumFor !== "inject") { L.lum = I.lum; L.lumFor = "inject"; } return; }   // prueba: lo propio salvo la luz de la foto
   if (L.lumFor !== FW.scene && typeof fvLabLumGrid === "function" && FV_LAB.CONTENT) { L.lum = fwLabLum(FV_LAB.CONTENT.GRID_X, FV_LAB.CONTENT.GRID_Y); L.lumFor = FW.scene; }
}
// la rejilla de luz de la foto sin estrellas (fvLabLumGrid del motor sobre un «bitmap» del navegador). El pintor de PixInsight la saca de photoPlane
// (la foto sin estrellas al ancho de las capas) con Bitmap.scaledTo, que PROMEDIA la celda (medido: tablero de 1 de cada 4 -> 63 de 64,
// tests/web/fv_nv13_lum_pi.js). Aqui: la foto al ancho de las capas y la media de la luminancia de cada celda, pixel a pixel. Medido contra
// PixInsight real en IC 1848: max 0,008, ninguna celda cruza LUM_MIN (tests/web/fv_nv13_lum_cdp.js); la reduccion por mitades del lienzo daba
// 0,135 y 3 celdas cruzadas, y con ello hasta 0,6° de otra mirada en los viajes. Cacheada por escena (~40 ms una vez)
function fwLabLum(nx, ny) {
   if (FW.labLum && FW.labLum.nx === nx && FW.labLum.ny === ny) return FW.labLum;
   // la que escribio PixInsight al exportar (fv_export.js, scene.labLum: la de SU photoPlane) manda; los paquetes de antes no la traen
   var JL = FW.json && FW.json.labLum;
   if (JL && JL.nx === nx && JL.ny === ny && JL.v && JL.v.length === nx * ny) { FW.labLum = { nx: nx, ny: ny, v: JL.v.slice(), raw: (JL.raw || JL.v).slice(), src: "package" }; return FW.labLum; }
   var im = FW.imgs && (FW.imgs.starless || FW.imgs.photo); if (!im || !(im.width > 0)) return null;
   var mt = FW.json && FW.json.images && FW.json.images.meta, lw = (mt && mt.layerW > 0) ? mt.layerW : 2048;
   var w = Math.min(im.width, lw), h = Math.max(1, Math.round(w * im.height / im.width));
   var bmp = { scaledTo: function(gx, gy) {
      var c = document.createElement("canvas"); c.width = w; c.height = h;
      var g = c.getContext("2d", { willReadFrequently: true }); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = "high"; g.drawImage(im, 0, 0, w, h);
      var d = g.getImageData(0, 0, w, h).data, R = new Uint8Array(gx * gy), i, j, x, y;
      for (j = 0; j < gy; ++j) for (i = 0; i < gx; ++i) {
         var x0 = Math.floor(i * w / gx), x1 = Math.floor((i + 1) * w / gx), y0 = Math.floor(j * h / gy), y1 = Math.floor((j + 1) * h / gy), s = 0;
         for (y = y0; y < y1; ++y) for (x = x0; x < x1; ++x) { var k = 4 * (y * w + x); s += Math.round(0.2126 * d[k] + 0.7152 * d[k + 1] + 0.0722 * d[k + 2]); }
         R[j * gx + i] = Math.round(s / Math.max(1, (x1 - x0) * (y1 - y0)));
      }
      return { __lum: function() { return R; } };      // fvLabLumGrid lee __lum (0..255 por celda) si esta
   } };
   FW.labLum = fvLabLumGrid(bmp, nx, ny);
   return FW.labLum;
}
// la estrella protagonista: la del viaje, la elegida o a la que se llego (un objeto «estrella» o «planeta» de C cuenta por su estrella)
function fwSelStar(s) { if (!s) return -1; if (s.kind === "star" && s.i >= 0) return s.i; if (s.kind === "object" && FW.scene.objects) { var o = FW.scene.objects[s.i]; if (o && o.star >= 0 && (o.type === "star" || o.type === "exoplanet" || o.type === "pn")) return o.type === "pn" ? -1 : o.star; } return -1; }
function fwHeroIndex() { var P = FW.P, s = (P.flight && P.flight.sel) ? P.flight.sel : (P.sel || P.arrivedAt); return fwSelStar(s); }
function fwHeroUpdate() {
   var R = FW.R, i = fwHeroIndex(); if (!R) return;
   // (11-nov, NV-16) con el laboratorio, la protagonista de PixInsight (FVPainter.heroOf: su orden de eleccion y su crecimiento antes de llegar; fw_amb.js)
   if (fwLabOn() && typeof fwHeroPi === "function") {
      var hL = fwHeroPi(FW.scene, FW.P, fvProjector(FW.P.cam, R.W, R.H));
      if (!hL) { R.setHero(-1, null, 0); FW.hero = null; return; }
      var cL = fwRealRgb(hL.i); R.setHero(hL.i, cL, hL.w); FW.hero = { i: hL.i, k: hL.w, mag: hL.m, rgb: cL, lab: true }; return;
   }
   if (i < 0) { R.setHero(-1, null, 0); FW.hero = null; return; }
   var S = FW.scene.stars, P = FW.P, d = fvLen(fvSub(fvStarPos(FW.scene, i), P.cam.pos)), m = fvApparentMag(S.g[i], S.dEarth[i], d);
   var k = fvSmooth((FW_FLY.HERO_MAG - m) / FW_FLY.HERO_SPAN), c = fwRealRgb(i);
   R.setHero(i, c, k); FW.hero = { i: i, k: k, mag: m, rgb: c };
}
function fwRealRgb(i) {
   var m = FW.scene.stars.meta[i] || {};
   if (m.teff > 0 && typeof fvsBlackbodyColour === "function") { var c = fvsBlackbodyColour(m.teff), mx = Math.max(c.r, c.g, c.b, 1); return [c.r / mx, c.g / mx, c.b / mx]; }
   var b = FW.scene.starRgb[i], mb = Math.max(b[0], b[1], b[2], 1e-3); return [b[0] / mb, b[1] / mb, b[2] / mb];
}

// el margen de la distancia de lo elegido (objetos de C: su error; supuesta: sin fecha)
function fwDistSigma(sel) {
   var sc = FW.scene;
   if (!sel) return null;
   if (sel.kind === "object" && sc.objects) { var o = sc.objects[sel.i]; if (!o || o.distSrc === "assumed") return null; if (o.star >= 0 && (o.type === "star" || o.type === "exoplanet")) return fwDistSigma({ kind: "star", i: o.star }); return o.distErrLy > 0 ? Math.max(1, o.distErrLy) : 0.1 * o.distLy; }
   if (sel.kind === "star") {
      var S = sc.stars, m = S.meta[sel.i] || {}, q = S.q[sel.i];
      if (q >= 2) return null;
      if (m.lo > 0 && m.hi > 0) return Math.max(1, 0.5 * Math.abs(m.hi - m.lo) * FV_LY_PER_PC);      // (10) abs: extremos al reves
      return 0.1 * S.dEarth[sel.i];
   }
   var N = sc.nebula; if (!N || !N.measured) return null;
   if (N.distLoLy > 0 && N.distHiLy > N.distLoLy) return Math.max(1, 0.5 * (N.distHiLy - N.distLoLy));
   return 0.1 * N.distLy;
}
function fwChronoObject() {
   var P = FW.P, s = (P.flight && P.flight.sel) ? P.flight.sel : (P.sel || P.arrivedAt);
   if (s && s.kind === "star") return { sel: s, pos: fvStarPos(FW.scene, s.i) };
   if (s && s.kind === "object" && FW.scene.objects && FW.scene.objects[s.i]) return { sel: s, pos: FW.scene.objects[s.i].pos };
   var N = FW.scene.nebula; return N ? { sel: { kind: "nebula" }, pos: N.center } : null;
}

// ---------------------------------------------------------------------------
// BOTONES, ELEGIR Y LA FICHA
// ---------------------------------------------------------------------------
function fwButton(id) {
   var P = FW.P; fwUserAct(id === "tour");
   fwPress(id);
   if (id !== "hr" && id !== "info" && typeof fwHrEnd === "function" && typeof FW_HR_ST !== "undefined" && FW_HR_ST) fwHrEnd();   // (I2, 19-nov) otro boton (menos INFO): fuera del diagrama HR
   if (id === "hr") { if (typeof fwHrToggle === "function") fwHrToggle(); fwButtonsState(); return; }
   if (id === "start") { P.sel = null; FW.ck.hideCard(); FW.reopenAt = null; FW.arriveReopen = false; fwFly("home", null); }
   else if (id === "info") fwInfoToggle();
   else if (id === "travel" && P.sel) fwTravel(P.sel);
   else if (id === "warp" && P.sel) { fwSetMode("spectacular"); fwTravel(P.sel); }
   else if (id === "goto" && P.sel) { fwSetMode("cine"); fwTravel(P.sel); }
   else if (id === "tour") fwTourToggle();
   fwButtonsState();
}
// (N2) que se vea que el mando se acciona (tambien con el teclado)
function fwPress(id) { var b = FW.ck.btn[id]; if (!b) return; b.classList.add("pressed"); setTimeout(function() { b.classList.remove("pressed"); }, 140); }
function fwButtonsState() {
   var P = FW.P;
   FW.ck.setButtons({ start: { enabled: true, on: !!(P.flight && P.flight.kind === "home") }, info: { enabled: true, on: !!(FW.ck.cardSel && !FW.ck.cardHidden) }, travel: { enabled: !!P.sel && !P.flight, on: !!(P.flight && P.flight.kind !== "home" && P.flight.kind !== "look") },
                      tour: { enabled: !!(FW.nav && FW.nav.items.length), on: !!FW.tour },
                      hr: { enabled: (typeof FW_HR_ST !== "undefined" && !!FW_HR_ST) || !P.flight, on: typeof FW_HR_ST !== "undefined" && !!FW_HR_ST } });   // (I2) el diagrama HR
}
function fwMagOf(i, zc) { var S = FW.scene.stars; return fvApparentMag(S.g[i], S.dEarth[i], zc); }
// el clic en la escena: primero un objeto extenso de C (fvObjectHit, con prioridad sobre su estrella central salvo en ella), luego la estrella
function fwPickAt(sx, sy) {
   var P = FW.P, sc = FW.scene;
   if (sc.objects && typeof fvObjectHit === "function") {
      var pr = fvProjector(P.cam, FW.VW, FW.VH), k = -1;
      try { k = fvObjectHit(sc, pr, P, sx, sy); } catch (e) { k = -1; }
      if (k >= 0) return { kind: "object", i: k, sx: sx, sy: sy };
   }
   return fvPick(P, sx, sy, 14, fwMagOf);
}
function fwSelect(sx, sy) {
   var s = fwPickAt(sx, sy);
   if (!s) { FW.P.sel = null; FW.ck.hideCard(); return null; }
   return fwSelectSel(s);
}
// (N2, punto 2 de Nino) elegir = la RETICULA y nada mas: la ficha sale con INFO o al llegar a un destino (open = true la abre: pruebas)
function fwSelectSel(s, open) {
   var P = FW.P; s.t0 = P.t; P.sel = s; FW.cardClosedByUser = false; FW.reopenAt = null; FW.arriveReopen = false;
   fwHeroUpdate();
   if (open === true || FW.legacyCardOnSelect) fwShowCard(s); else FW.ck.hideCard();
   fwButtonsState();
   return s;
}
// el boton INFO (tecla I): abre la ficha del objeto elegido o, si ya esta a la vista, la cierra; sin elegir nada, lo dice
function fwInfoToggle() {
   var P = FW.P;
   if (FW.ck.cardSel && !FW.ck.cardHidden) { fwCardClose(); return; }
   if (!P.sel) { fwCaption(fwTr("SELECT AN OBJECT FIRST (CLICK IT, OR PICK IT IN MIRABILIA)", "ELIGE UN OBJETO PRIMERO (CLIC EN ÉL, O ELÍGELO EN MIRABILIA)"), 2.6); return; }
   FW.cardClosedByUser = false; FW.reopenAt = null; fwShowCard(P.sel);
}
function fwShowCard(s) {
   var L = (s.kind === "object") ? fwObjCardLines(s.i) : fwCardLines(s), rgb = fwCardRgb(s.kind === "object" && fwSelStar(s) >= 0 ? { kind: "star", i: fwSelStar(s) } : s);
   if (typeof fwE1cLines === "function") L = fwE1cLines(s, L);      // (19-nov, I1; FW_E1C) la prueba del misterio, la respuesta del eslabon y la pregunta al pie (web/fw_e1c.js)
   FW.ck.cardHidden = false; FW.ck.showCard(s, L, rgb, FW.P);
   // (I12/I13) el panel del espectro XP y «MÁS» de la composicion (fw_card_xp.js): solo estrellas que traen los datos en el paquete
   if (typeof fwCardSciShow === "function") fwCardSciShow(s.kind === "object" && fwSelStar(s) >= 0 ? { kind: "star", i: fwSelStar(s) } : s);
}
// (N8/N12) la ficha de un objeto de C: fvObjectCard (mismas frases que PixInsight) si esta; si no, una basica con sus datos
function fwObjCardLines(i) {
   var sc = FW.scene, o = sc.objects[i], L = [], es = FW_LANG === "es", C = null;
   if ((o.type === "star") && o.star >= 0) { L = fwCardLines({ kind: "star", i: o.star }); if (o.why) L.splice(2, 0, { t: fwNavT(o.why) !== o.why ? fwNavT(o.why) : String(o.why), c: "phrase" }); return L; }
   if (typeof fvObjectCard === "function") { try { C = fvObjectCard(sc, i, FW_LANG); } catch (e) { C = null; } }
   L.push({ t: (C && C.title) || o.name, c: "title" });
   var tl = o.typeLabel ? (o.typeLabel[es ? "es" : "en"] || o.type) : o.type;
   L.push({ t: (C && C.sub) || (tl.toUpperCase() + (o.sizeArcmin > 0 ? " · " + o.sizeArcmin.toFixed(1).replace(".", es ? "," : ".") + "′" : "")), c: "mono dim" });
   var cls = o.distSrc === "measured" ? "ok" : (o.distSrc === "catalog" ? "warn" : "bad");
   var wd = o.distSrc === "measured" ? fwTr("MEASURED", "MEDIDA") : (o.distSrc === "catalog" ? fwTr("CATALOGUE", "DE CATÁLOGO") : fwTr("ASSUMED", "SUPUESTA"));
   // (PL-7, 5-nov) el grado del sello lo da la ficha comun (src/engine/fv_objects.js, C.stamp.grade), como en PixInsight: en un exoplaneta
   // califica el cruce con la estrella, no la distancia (antes: MEDIDO en la web y DUDOSO en PixInsight para el mismo planeta cruzado por posicion)
   if (C && C.stamp && C.stamp.grade && C.stamp.grade !== cls) { cls = C.stamp.grade; wd = C.stamp.word; }
   L.push({ t: wd + " · " + ((C && C.stamp && C.stamp.src) || o.distRef || o.src || ""), c: "mono " + cls });
   if (C) { (C.l1 || []).forEach(function(x) { L.push({ t: x, c: "phrase" }); }); (C.l2 || []).slice(0, 3).forEach(function(x) { L.push({ t: x, c: "mono dim small" }); }); }
   else {
      L.push({ t: fwTr("Distance ", "Distancia ") + fwFmtLy(o.distLy) + " " + fwTr("ly", "a.l.") + (o.distErrLy > 0 ? " (± " + fwFmtLy(o.distErrLy) + ")" : ""), c: "mono" });
      if (o.type !== "exoplanet") L.push({ t: fwTr("3-D shape ASSUMED: the photo shows one face", "Forma 3D SUPUESTA: la foto solo da una cara"), c: "mono warn" });
      L.push({ t: fwLightPhrase(o.distLy, fwDistSigma({ kind: "object", i: i })), c: "phrase" });
   }
   return L;
}

// ---------------------------------------------------------------------------
// RATON Y TECLADO (N10/N11): el vuelo libre lo lleva el motor (fvPilotKey/fvPilotMouse/fvPilotWheel); si el motor es anterior, F3
// ---------------------------------------------------------------------------
function fwUserAct(keepTour) { if (FW.tour && !keepTour) fwTourStop(); }
// (5-nov) la cruceta de la cabina: pulsar una flecha gira la mirada hacia ese lado (motor: fvPilotLookPad); soltar la suelta
function fwPadHook(dir, down) {
   var P = FW.P; if (!P) return;
   // (6-nov, punto 3 de Nino) el centro de la cruceta FRENA (gemelo de padPress en src/ui/fv_dialog.js): para el tour, la ruta y el vuelo
   if (dir === "brake") {
      if (!down || typeof fvPilotBrake !== "function" || !(FV_PILOT.BRAKE && FV_PILOT.BRAKE.ON)) return;
      fwUserAct(); if (typeof fvPilotLookPadRelease === "function") fvPilotLookPadRelease(P);
      if (FW.route && FW.route.play) { try { FW.route.stopFly("brake"); } catch (e) { console.warn("route.stopFly: " + e); } }
      // (16-nov, P16) la velocidad al pulsar: el cubo luce mientras quede mas del 1 % de ella (fwOverlay, FW_LAB.HUB_BRAKE)
      FW.brakeV0 = fvLen(P.vel || [0, 0, 0]);
      fvPilotBrake(P); return;
   }
   if (typeof fvPilotLookPad !== "function") return; if (down) fwUserAct(); fvPilotLookPad(P, dir, down);
}
function fwReleaseKeys() { var P = FW.P; if (!P || typeof fvPilotKey !== "function") return; for (var k in FW_KEYS) fvPilotKey(P, FW_KEYS[k], false); if (fwLabOn()) for (var kq in FW_LAB_KEYS) fvPilotKey(P, FW_LAB_KEYS[kq], false); if (typeof fvPilotLookPadRelease === "function") fvPilotLookPadRelease(P); }
function fwInput(win) {
   var P = function() { return FW.P; }, drag = null, moved = 0, hasKey = typeof fvPilotKey === "function", hasMouse = typeof fvPilotMouse === "function";
   // (I5, Gaia Sky) izquierdo = girar la mirada / orbitar el objeto enfocado; DERECHO = pan (motor: fvPilotMouse con buttons = 2)
   var gaia = function() { return typeof FV_PILOT !== "undefined" && FV_PILOT.FREE && FV_PILOT.FREE.GAIA_MOUSE === true; };
   win.addEventListener("contextmenu", function(e) { if (gaia()) e.preventDefault(); });
   win.addEventListener("pointerdown", function(e) {
      // (M, R3-H1) el primer clic durante el balanceo de paralaje SOLO lo para (fw_e1.js pone FW.e1sSwallow en la captura): el fotograma visto iba desplazado y fwPickAt proyecta con la camara de casa. Sin arrastre ni clic
      var swallow = FW.e1sSwallow === true; FW.e1sSwallow = false;
      if (e.button !== 0 && !(e.button === 2 && gaia())) return;
      if (swallow) { drag = null; return; }
      drag = { x: e.clientX, y: e.clientY, btn: e.button === 2 ? 2 : 1 }; moved = 0; win.setPointerCapture(e.pointerId);
   });
   win.addEventListener("pointermove", function(e) {
      if (!drag) return; var dx = e.clientX - drag.x, dy = e.clientY - drag.y; moved += Math.abs(dx) + Math.abs(dy); drag.x = e.clientX; drag.y = e.clientY;
      if (moved > 3 && typeof fwHrHold === "function" && fwHrHold()) return;   // (I2) con el diagrama HR la mirada no se arrastra
      if (moved > 3) { fwUserAct(); if (hasMouse) fvPilotMouse(P(), dx, dy, drag.btn || 1); else if (drag.btn !== 2) { var k = P().cam.fov / FW.VW; fvPilotLook(P(), -dx * k, dy * k); } }
   });
   win.addEventListener("pointerup", function(e) {
      if (drag && moved <= 3 && drag.btn !== 2) {
         var b = win.getBoundingClientRect();
         if (typeof fwHrClick === "function" && fwHrClick(e.clientX - b.left, e.clientY - b.top)) { fwButtonsState(); drag = null; return; }   // (I2) con el diagrama HR: clic en un punto = su ficha
         if (typeof fwNmClick === "function" && fwNmClick(e.clientX - b.left, e.clientY - b.top)) { drag = null; return; }   // (20-nov, E-nav) el rotulo TU FOTO: volver volando a la foto
         fwSelect(e.clientX - b.left, e.clientY - b.top);
         // (14-nov, R3 H1) como en PixInsight (fv_dialog.js click -> select): elegir con el tour en marcha NO lo para, pero deja la ficha CERRADA (select pone cardClosed = true):
         // la parada sigue con la regla de «ficha cerrada» de R7 (fwTourStep). Sin esto la ficha oculta por el clic no volvia y la parada se congelaba hasta HARD_S
         if (FW.tour) FW.cardClosedByUser = true;
         fwButtonsState();
      }
      if (drag && hasMouse) fvPilotMouse(P(), 0, 0, 0);
      drag = null;
   });
   // (N11) la rueda: una muesca = un paso del motor (avanza una fraccion de lo que hay DELANTE, deslizandose); los paneles tactiles mandan
   // muchos eventos pequeños: se acumulan y salen como mucho 12 muescas por segundo
   var wAcc = 0, wLast = 0;
   win.addEventListener("wheel", function(e) {
      e.preventDefault();
      if (typeof fwHrHold === "function" && fwHrHold()) return;   // (I2) ni la rueda
      fwUserAct();
      var d = e.deltaMode === 1 ? e.deltaY * 33 : (e.deltaMode === 2 ? e.deltaY * 400 : e.deltaY);
      // (5-nov, rueda por ritmo) con WHEEL_RATE el motor recibe TODAS las muescas, tal cual y con su hora (100 px = una muesca; los paneles tactiles
      // mandan fracciones): el ritmo de la rueda decide cuanto avanza cada una. Antes: como mucho 12 muescas por segundo, de una en una
      if (typeof FV_PILOT !== "undefined" && FV_PILOT.FREE && FV_PILOT.FREE.WHEEL_RATE === true) { if (d) fvPilotWheel(P(), -d / 100, (e.timeStamp || performance.now()) / 1000); return; }
      wAcc += d;
      var now = performance.now();
      if (Math.abs(wAcc) >= 50 && now - wLast > 80) { fvPilotWheel(P(), wAcc < 0 ? 1 : -1); wAcc = 0; wLast = now; }
   }, { passive: false });
   // (I5) doble clic sobre una estrella u objeto = viajar alli (como VIAJAR); en el vacio, nada. GAIA_MOUSE false = a casa (lo de antes)
   win.addEventListener("dblclick", function(e) {
      if (typeof fwHrHold === "function" && fwHrHold()) return;   // (I2) con el diagrama HR no se viaja con doble clic
      if (typeof fwNmHitAt === "function" && fwNmHitAt(e.clientX - win.getBoundingClientRect().left, e.clientY - win.getBoundingClientRect().top)) { if (typeof fwNmGoPhoto === "function") fwNmGoPhoto(); return; }   // (20-nov, E-nav) el rotulo TU FOTO (el clic ya lo habra lanzado)
      fwUserAct();
      if (!gaia()) { fwButton("start"); return; }
      if (FW.P && FW.P.flight) return;
      var b = win.getBoundingClientRect(), s = fwPickAt(e.clientX - b.left, e.clientY - b.top);
      if (s) { fwSelectSel(s); fwTravel(s); fwButtonsState(); }
      else if (typeof fvNmMode === "function" && fvNmMode(FW.P) === "space") fwButton("start");   // (6-nov) en el Espacio, doble clic en el cielo = casa
   });
   window.addEventListener("keydown", function(e) {
      if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
      if (hasKey && FW_KEYS[e.code] !== undefined) { fwUserAct(); fvPilotKey(P(), FW_KEYS[e.code], true); e.preventDefault(); return; }
      // (11-nov, NV-13) Q / Z = alabeo, solo con el laboratorio (fvLabKeyMap; sin el, esas teclas no hacen nada, como antes)
      if (hasKey && fwLabOn() && FW_LAB_KEYS[e.code] !== undefined) { fwUserAct(); fvPilotKey(P(), FW_LAB_KEYS[e.code], true); e.preventDefault(); return; }
      if (e.repeat) return;
      var k = e.key.toLowerCase();
      if (k === "l" && FW_LAB.KEY_L && typeof fvLabSetOn === "function") { fwLabToggle(); return; }   // (11-nov, NV-13) L: laboratorio, como en PixInsight
      if (k === "h") fwButton("start");
      // (D, rev. 3, Codex K4 H-2) Espacio sigue al boton VIAJAR: deshabilitado en vuelo (antes relanzaba el viaje a mitad de camino)
      else if (k === " " || e.code === "Space") { e.preventDefault(); if (!FW.P.flight || FW.legacyK4) fwButton("travel"); }
      else if (k === "v") { var o = FW.R.opt; if (FW.R.vol) { o.volume = !o.volume; o.layers = !o.volume; o.layersForced = !o.volume; } }
      else if (k === "m" && !fvGwarpUi()) fwSetMode(FW.mode === "spectacular" ? "cine" : "spectacular");      // (21-nov, N-galaxias-warp) la tecla M del selector desaparece con el selector
      else if (k === "r") fwRecToggle();
      else if (k === "i") fwButton("info");
      else if (k === "t") fwButton("tour");
      // (14-nov, P11a) los mandos del tour, como en PixInsight (fv_dialog.js key): «.» siguiente parada · «,» anterior · B pausa o sigue. Solo con tour en marcha; no paran el tour
      else if (FW.tour && FW_TOUR_BAR.ON && (e.code === "Period" || k === "." || k === ">")) { e.preventDefault(); fwTourNext(); }
      else if (FW.tour && FW_TOUR_BAR.ON && (e.code === "Comma" || k === "," || k === "<")) { e.preventDefault(); fwTourPrev(); }
      else if (FW.tour && FW_TOUR_BAR.ON && (e.code === "KeyB" || k === "b")) { e.preventDefault(); fwTourPause(); }
      // (D, rev. 3, Codex K4 H-1) Esc es un mando: tambien para el TOUR (antes cerraba la ficha y el tour seguia con la siguiente)
      // (pasada M) Esc primero cierra el mapa grande, luego para el recorrido de la ruta; despues, lo de antes
      else if (k === "escape") { if (typeof fwHrEsc === "function" && fwHrEsc()) return;   // (I2) Esc devuelve las estrellas del diagrama HR
         if (FW.route && FW.route.esc()) return; if (!FW.legacyK4) fwUserAct(); fwCardClose(); }
   });
   window.addEventListener("keyup", function(e) { if (hasKey && FW_KEYS[e.code] !== undefined) fvPilotKey(P(), FW_KEYS[e.code], false); else if (hasKey && FW_LAB_KEYS[e.code] !== undefined && fwLabOn()) fvPilotKey(P(), FW_LAB_KEYS[e.code], false); });
}

// ---------------------------------------------------------------------------
// (N6) LA FASE DEL WARP: la que dice el motor (P.flight.warpPhase y phaseT de fvWarpProfile de B) con la duracion de su tabla FV_PILOT.WARP
// (la fase en mayusculas: PREP, BREATH, JUMP, EXIT…; el crucero, fl.cruise). Asi el visor sigue cualquier fase nueva que B anada (§15: pausa
// a oscuras antes del destello, etc.). Si el motor no da la fase (anterior), se calcula con la secuencia de su tabla.
// -> null | { name, t (s desde el inicio de la fase), u (0–1), dur }
// ---------------------------------------------------------------------------
function fwWarpPhase(P) {
   var fl = P.flight; if (!fl || !(fl.kind === "warp" || fl.gwHome === true)) return null;
   var W = FV_PILOT.WARP, t = fl.t - (fl.pre || 0);
   if (t < 0) return { name: "dolly", t: fl.t, u: fl.t / Math.max(1e-6, fl.pre), dur: fl.pre };
   if (fl.warpPhase && fl.phaseT !== undefined) {
      var nm = fl.warpPhase, NM = nm.toUpperCase(), dd = (nm === "cruise") ? (fl.cruise || 0) : (W[NM] || W[NM + "_S"] || 0);   // «flash» -> FLASH_S
      if (fl.phaseDur > 0) dd = fl.phaseDur;                     // (6-nov, FAST_EASE) la del motor: las fases escalan con WARP_K × el regulador
      return { name: nm, t: fl.phaseT, u: dd > 0 ? fvClamp(fl.phaseT / dd, 0, 1) : 1, dur: dd };
   }
   // (D, rev. 3, nota de B) el mismo orden que el motor: prep (total, 1,6 s) -> jump -> breath -> flash (FLASH_S, si es el largo) -> crucero -> salida
   var seq = [["prep", W.PREP], ["jump", W.JUMP], ["breath", W.BREATH || W.HOLD || 0], ["flash", (W.FLASH_S || 0) >= 0.4 ? W.FLASH_S : 0], ["cruise", fl.cruise || 0], ["exit", W.EXIT], ["rest", W.REST || 0]], a = 0;
   for (var i = 0; i < seq.length; ++i) { var d = seq[i][1]; if (d > 0 && t < a + d) return { name: seq[i][0], t: t - a, u: (t - a) / d, dur: d }; a += d; }
   return { name: "rest", t: t - a, u: 1, dur: 0 };
}
// los efectos del fotograma: rayas, tunel, destello, punto de fuga, temblor
function fwFx(dt) {
   fwProfSync();
   var P = FW.P, pr = FW.prof, w = P.warp || 0, fl = P.flight, ph = fwWarpPhase(P), fx = { warp: w, flash: 0, trailSec: 0, vel: P.vel, radial: 0, zoom: 0, tunnel: 0, vp: [0, 0], time: P.t, flashCol: FW_WARPFX.FLASH_COL, phase: ph ? ph.name : null };
   fx.fadeW = (typeof fvWarpFadeW === "function") ? fvWarpFadeW(P) : w;   // (W1b) la «velocidad» con la que se apaga la nebulosa: P.warp o el apagado de la carga
   fx.flash = fwFlashEnv(P) * pr.flash * (FW.flashMul === undefined ? 1 : FW.flashMul); fx.flashR = FW_WARPFX.FLASH_R;
   // (W1b) el nucleo del destello (la bola de luz en el punto de fuga) solo con destello alto: el brillo de la carga y la cola del pulso no pintan un disco gris
   fx.flashBall = (FW_W1.ON && FW_W1.BALL_ON) ? fx.flash * fvSmooth((fx.flash - FW_W1.BALL_LO) / (FW_W1.BALL_HI - FW_W1.BALL_LO)) : fx.flash;
   if (ph) {
      var tr = Math.max(0, P.trail || 0);
      var sk = FW_W1.ON && FW_W1.STREAK_ON && typeof FV_W1 !== "undefined";   // (W1b)
      fx.radial = FW_WARPFX.RADIAL_MAX * Math.pow(tr, FW_WARPFX.RADIAL_POW) * pr.trail * (sk ? 1 + (FW_W1.RADIAL_K - 1) * fvSmooth((tr - 0.2) / 0.5) : 1);
      if (sk) { var sA = fvSmooth((tr - 0.2) / 0.5); fx.gainK = 1 + (FW_W1.GAIN_K - 1) * sA; fx.widthK = 1 + (FW_W1.WIDTH_K - 1) * sA; }
      // (§15, orden de B: preparacion -> estiramiento «jump» -> pausa «breath» -> destello y entrada «flash» -> crucero -> salida) el tunel
      // empieza con el estiramiento, se queda quieto en la pausa (con el warp del motor, que alli es solo STRETCH_W) y se abre en la entrada
      var on = (ph.name === "jump") ? fvSmooth(ph.u / 0.6) : ((ph.name === "breath" || ph.name === "flash" || ph.name === "cruise") ? 1 : (ph.name === "exit" ? 1 - fvSmooth(ph.u / 0.45) : 0));
      // el desenfoque radial se recoge antes en la salida (20 % de la fase) para que el destino se vea nitido al llegar
      var onZ = (ph.name === "exit") ? 1 - fvSmooth(ph.u / FW_WARPFX.ZOOM_EXIT_U) : on;
      // (11-nov, NV-16) CON EL LABORATORIO (fvLabWarpFx) la fase la da el motor con phaseT = el reloj del VUELO y phaseDur = el vuelo entero, no los de la fase:
      // ph.u no es «cuanto va de la fase» y en la salida (u ≥ 0,74) el tunel y el desenfoque se cortaban de golpe con P.trail aun en 0,33 (medido: 0,255 -> 0
      // en un fotograma), mientras PixInsight sigue pintando estelas hasta que la nave frena. Alli la envolvente es P.trail / P.warp (suben y bajan con la
      // velocidad, fvLabSpeedFrac): aqui igual, sin la rampa propia de cada fase. FW_WARPFX.LAB_ENV false = como antes (ROJO)
      if (fwLabOn() && FW_WARPFX.LAB_ENV !== false && fl.phaseDur === fl.dur) { on = (ph.name === "prep" || ph.name === "dolly") ? 0 : 1; onZ = on; }
      // sin temblor de camara (§15): en el crucero las rayas laten a ~1 Hz
      var pulse = (ph.name === "cruise") ? 1 + FW_WARPFX.PULSE_K * Math.sin(2 * Math.PI * FW_WARPFX.PULSE_HZ * ph.t) : 1;
      fx.zoom = FW_WARPFX.ZOOM * onZ * w; fx.tunnel = FW_WARPFX.TUNNEL * on * w * pulse * (sk ? FW_W1.TUNNEL_K : 1);   // (W1b) el desenfoque radial se queda (con el normalizado a 1 lavaba la nebulosa en luz); el tunel de rayas × TUNNEL_K fx.pulse = pulse;
      fx.doppler = FW_W1.ON ? FW_W1.DOPPLER * fvSmooth((tr - 0.5) / 0.4) : 0;           // (W1) como FVPainter.warpFx: solo con estela > 0,5
      // el punto de fuga: el destino en pantalla (dentro de la pantalla)
      var T = fl.Tlook || fl.T; if (T) { var q = fvProjector(P.cam, FW.VW, FW.VH).project(T); if (q) fx.vp = [fvClamp(q[0] - FW.VW / 2, -0.45 * FW.VW, 0.45 * FW.VW), fvClamp(q[1] - FW.VH / 2, -0.45 * FW.VH, 0.45 * FW.VH)]; }
   }
   FW.fxNow = fx;
   return fx;
}
// (§15) la envolvente del destello: si el motor da uno largo (FV_PILOT.WARP.FLASH_S ≥ 0,4 s) se usa tal cual; si da el corto de antes
// (≤ 0,12 s), cada vez que se enciende arranca aqui una campana de FLASH_S: sube en el 40 % (suave) y baja en el 60 % restante, con la altura
// del destello del motor (1 al saltar, 0,8 al salir). Va con el reloj del piloto (P.t): igual en vivo, en las pruebas y en el video.
function fwFlashEnv(P) {
   var W = FV_PILOT.WARP || {}, f = P.flash || 0, X = FW_WARPFX;
   if ((W.FLASH_S || 0) >= 0.4) { FW.flPrev = f; return f; }
   if (f > 0 && !(FW.flPrev > 0)) { FW.flT0 = P.t; FW.flAmp = f; }
   FW.flPrev = f;
   if (FW.flT0 === null || FW.flT0 === undefined) return 0;
   var a = (P.t - FW.flT0) / X.FLASH_S;
   if (a < 0 || a > 1) return 0;
   return (FW.flAmp || 1) * (a < X.FLASH_RISE ? fvSmooth(a / X.FLASH_RISE) : 1 - fvSmooth((a - X.FLASH_RISE) / (1 - X.FLASH_RISE)));
}
// la camara que se pinta: la del motor + temblor del warp + deriva viva (sobre una COPIA: el motor no se toca y el video sale igual)
function fwRenderCam(P) {
   // (11-nov, NV-13) con el laboratorio la camara que se pinta es la del motor TAL CUAL (base cam.B y S): sin temblor ni deriva del visor, como en
   // PixInsight (fvLabStep no los mete). La copia de abajo no lleva la base y pintaria otra camara
   if (fwLabOn()) return P;
   fwProfSync();
   var pr = FW.prof, ph = fwWarpPhase(P), yaw = 0, pitch = 0, t = P.t, D = FV_DEG;
   // el temblor del crucero y la sacudida de salida: si el motor ya los mete en cam.look (fvLookJitter de B, pasada N), no se duplican
   if (pr.shake && ph && typeof fvLookJitter !== "function") {
      var a = 0;
      if (ph.name === "prep") a = FW_WARPFX.SHAKE_DEG * fvSmooth(ph.u);
      else if (ph.name === "jump" || ph.name === "cruise") a = FW_WARPFX.SHAKE_DEG;
      if (a > 0) { yaw += a * D * Math.sin(2 * Math.PI * FW_WARPFX.SHAKE_HZ[1] * t) * 0.7; pitch += a * D * Math.sin(2 * Math.PI * FW_WARPFX.SHAKE_HZ[0] * t + 1.3) * 0.7; }
      if (ph.name === "exit" && ph.t < 3 * FW_WARPFX.EXIT_S) { var e = FW_WARPFX.EXIT_DEG * D * Math.exp(-ph.t / FW_WARPFX.EXIT_S); yaw += e * Math.sin(2 * Math.PI * 7.0 * ph.t); pitch += e * Math.sin(2 * Math.PI * 5.3 * ph.t + 0.7); }
   }
   // (N14) deriva viva: proporcional al campo de vision (a 60°, ±0,12° y ±0,08°) y nula en casa (la foto exacta); si el motor ya la trae, no
   if (!(FV_PILOT.DRIFT || FV_PILOT.LIVE_DRIFT) && FW.R.opt.drift !== false) {
      var dRef = FW.scene.nebula ? FW.scene.nebula.distLy : 1000, kH = fvSmooth(fvLen(P.cam.pos) / (0.002 * dRef)) * (P.cam.fov / (60 * D));
      if (kH > 1e-6) { var Dr = FW_WARPFX.DRIFT; yaw += kH * Dr[0][0] * D * Math.sin(2 * Math.PI * t / Dr[0][1]); pitch += kH * Dr[1][0] * D * Math.sin(2 * Math.PI * t / Dr[1][1] + 0.9); }
   }
   if (!yaw && !pitch) return P;
   var yp = fvYawPitchOf(P.cam.look), look = fvDirYawPitch(yp.yaw + yaw, fvClamp(yp.pitch + pitch, -89 * D, 89 * D));
   return { cam: { pos: P.cam.pos, look: look, fov: P.cam.fov, roll: P.cam.roll || 0 }, VW: P.VW, VH: P.VH, homeFov: P.homeFov };   // (nP) el roll de la camara viaja con la deriva
}
function fwRenderFrame(dt) { var P = FW.P, fx = fwFx(dt); if (typeof fwHrPre === "function") fwHrPre(); FW.R.render(fwRenderCam(P), fx); }   // (I2) fwHrPre: el avance del diagrama HR a la GPU

// (N14) LA RADIO RESPIRA CON EL VIAJE (§10.4 y tablas de §10.1/§10.2): factor objetivo, constante de tiempo y paso bajo por fase
function fwRadioDuck() {
   var P = FW.P, fl = P.flight, ph = fwWarpPhase(P), f = 1, tau = 0.8, lp = 18000;
   if (ph) {
      if (ph.name === "dolly" || ph.name === "prep") { f = 0.35; tau = 0.5; lp = 1200; }
      else if (ph.name === "breath" || ph.name === "flash" || /^(dark|pause|hold|gap)/.test(ph.name)) { f = 0; tau = 0.04; lp = 1200; }   // (§15) pausa y destello: silencio
      else if (ph.name === "jump") { f = 0; tau = 0.04; lp = 1200; }
      else if (ph.name === "cruise") { f = 0.8; tau = 0.4; lp = 18000; }
      else if (ph.name === "exit") { f = ph.u < 0.25 ? 1.0 : 0.85; tau = 0.12; }
      else { f = 0.85; tau = 0.6; }
   } else if (fl && (fl.kind === "cine" || fl.kind === "goto")) {
      var u = fl.t / Math.max(1e-6, fl.dur);
      if (u < 0.75) { f = (fl.t < 1.2) ? 0.7 + 0.3 * (1 - fl.t / 1.2) : 0.7 + 0.15 * fvSmooth((u - 0.2) / 0.55); tau = 0.6; }
      else { f = 0.85 + 0.15 * fvSmooth((u - 0.75) / 0.25); tau = 0.5; }
   } else {
      // (N14, §10.4) fuera de un viaje: 0,85 en vuelo libre tranquilo; 1 en casa y con la ficha abierta; y el VACIO (Contact): lejos de
      // toda estrella la radio baja hasta 0,4, con suavizado de 3 s
      if (P.free && typeof fvPilotMoving === "function" && fvPilotMoving(P)) { f = 0.85; tau = 1.2; }
      var v = fwVacuum(P), card = FW.ck.cardSel && !FW.ck.cardHidden;
      FW.vac = v;
      if (v.away && !card && FW.R.opt.vacuum !== false && v.f < f) { f = v.f; tau = 3.0; }
   }
   FW.radio.duck(f, tau, lp);
}
// el factor de vacio: r = distancia a la estrella mas cercana / separacion media de las estrellas del campo. r < 0,5 -> 1; r > 5 -> 0,4;
// entre medias lineal en log r (§10.4). La separacion media sale una vez del volumen del cono de la foto entre los percentiles 5 y 95 de
// distancia y del numero de estrellas que caen dentro. La estrella mas cercana se busca cada 6 fotogramas (22 000 estrellas: ~0,1 ms).
var FW_VAC = { R0: 0.5, R1: 5, FMIN: 0.4, EVERY: 6, HOME_K: 0.002 };
function fwVacuum(P) {
   var sc = FW.scene, S = sc.stars, V = FW.vacState;
   if (!V) {
      var ds = [], i; for (i = 0; i < S.n; ++i) if (S.inFrame[i] && S.dEarth[i] > 0) ds.push(S.dEarth[i]);
      ds.sort(function(a, b) { return a - b; });
      var d0 = ds[Math.floor(0.05 * ds.length)] || 1, d1 = ds[Math.floor(0.95 * ds.length)] || 1000, n = 0;
      for (i = 0; i < ds.length; ++i) if (ds[i] >= d0 && ds[i] <= d1) ++n;
      var f = sc.field, om = (f.width / f.F) * (f.height / f.F), vol = om / 3 * (d1 * d1 * d1 - d0 * d0 * d0);
      V = FW.vacState = { sep: Math.cbrt(vol / Math.max(1, n)), near: 1e30, k: 0, f: 1 };
   }
   if ((V.k++ % FW_VAC.EVERY) === 0) {
      var p = P.cam.pos, best = 1e30; for (var j = 0; j < S.n; ++j) { var dx = S.x[j] - p[0], dy = S.y[j] - p[1], dz = S.z[j] - p[2], dd = dx * dx + dy * dy + dz * dz; if (dd < best) best = dd; }
      V.near = Math.sqrt(best);
   }
   var r = V.near / V.sep, t = fvClamp(Math.log(r / FW_VAC.R0) / Math.log(FW_VAC.R1 / FW_VAC.R0), 0, 1);
   var dRef = sc.nebula ? sc.nebula.distLy : 1000;
   V.f = 1 - (1 - FW_VAC.FMIN) * t; V.r = r; V.away = fvLen(P.cam.pos) > FW_VAC.HOME_K * dRef;
   return V;
}

function fwOverlay(now) {
   var P = FW.P, gz = fvPilotGauges(P), fl = P.flight;
   gz.reg = P.warp > 0 ? P.warp : (fl && fl.kind !== "home" && fl.kind !== "look" ? Math.sin(Math.PI * fvClamp(fl.t / fl.dur, 0, 1)) * 0.5 : 0);
   if (!fl && typeof fvV1RegHand === "function") { var rh = fvV1RegHand(P); if (rh !== null) gz.reg = 0.5 * rh; }      // (20-nov, V1a, V1-10) en vuelo a mano la aguja roja = la fraccion del tope (FV_V1.AIDS)
   gz.chrono = fwChrono();
   // (16-nov, P16) frenando con el laboratorio v5 (P.lab.brake): el cubo luce mientras quede mas del 1 % de la velocidad de al pulsar
   if (FW_LAB.HUB_BRAKE && !(gz.brake > 0) && fwLabOn() && P.lab.brake && FW.brakeV0 > 0) {
      var vRel = fvLen(P.vel || [0, 0, 0]) / FW.brakeV0;
      if (vRel > 0.01) gz.brake = Math.min(1, vRel);
   }
   FW.ck.update(gz, P);
   fwRadioDuck();
   FW.radio.update();
   if (FW.nav) FW.nav.update(P, P.sel, now);
   var sx = null, sy = null, rr = 26;
   if (P.sel && FW.ck.cardSel) {
      var pos = P.sel.kind === "star" ? fvStarPos(FW.scene, P.sel.i) : (P.sel.kind === "object" && FW.scene.objects ? fwBoxPaintPos(FW.scene, FW.scene.objects[P.sel.i]) : null);
      // (19-nov, N2; FW_F9.MARK, fw_nav.js) el marcador cae en el CENTRO DEL CONTORNO que mira la camara (gemelo de FV_F34.MARK / fvCardAnchor): con la nebulosa principal elegida (kind «nebula») el marcador iba a (0, 0), la esquina
      // de la ventana, y el hilo de la ficha salia de alli. Solo si el centro cae en pantalla; si no, lo de antes
      var mo = (typeof fwF9MarkObj === "function") ? fwF9MarkObj(P.sel, FW.scene) : null, mq = null;
      if (mo) {
         var kM = fwBoxPaintK(FW.scene, mo), prM = fvProjector(P.cam, FW.VW, FW.VH); mq = prM.project([mo.frame.pos[0] * kM, mo.frame.pos[1] * kM, mo.frame.pos[2] * kM]);
         if (mq && mq[0] > -50 && mq[0] < FW.VW + 50 && mq[1] > -50 && mq[1] < FW.VH + 50) {
            var rpM = (mo.radiusLy > 0) ? prM.f * mo.radiusLy * kM / mq[2] : 0;
            sx = mq[0]; sy = mq[1]; rr = fvClamp(rpM || 18, 14, (P.sel.kind === "object") ? 0.35 * FW.VH : 90);
         } else mq = null;
      }
      if (mq) { /* marcador en el contorno */ }
      else if (pos) {
         var q = fvProjector(P.cam, FW.VW, FW.VH).project(pos);
         if (q && q[0] > -50 && q[0] < FW.VW + 50 && q[1] > -50 && q[1] < FW.VH + 50) { sx = q[0]; sy = q[1]; rr = 14; if (P.sel.kind === "object") { var o = FW.scene.objects[P.sel.i], rp = fvProjector(P.cam, FW.VW, FW.VH).f * (o.radiusLy || 0) * fwBoxPaintK(FW.scene, o) / q[2]; rr = fvClamp(rp, 14, 0.35 * FW.VH); } }
      } else { sx = P.sel.sx; sy = P.sel.sy; }
   }
   if (typeof fwHrAnchor === "function" && P.sel && P.sel.kind === "star" && FW.ck.cardSel) { var hrA = fwHrAnchor(P.sel.i); if (hrA) { sx = hrA[0]; sy = hrA[1]; rr = 14; } }   // (I2, 19-nov) con el diagrama HR la reticula cae en su punto del diagrama
   FW.ck.drawHud(sx, sy, rr, FW.VW, FW.VH, now);
   if (typeof fwHrOverlay === "function") fwHrOverlay(now);     // (I2) los ejes y rotulos del diagrama HR (web/fw_hr.js)
   if (typeof fwE1cHud === "function") fwE1cHud(sx, sy);      // (19-nov, I1) la compañera de la pareja que viaja junta, marcada
   if (typeof fwNmDraw === "function") fwNmDraw(now);      // (6-nov, LOS DOS MODOS) Espacio: foto fantasma, piramide, marcadores, brujula y rotulo (fw_navmodes.js)
   if (typeof fwRbOverlay === "function") fwRbOverlay(now);     // (5-nov) la columna derecha: nombres, constelaciones y escala (fw_rightbar.js)
   if (typeof fwTimeFrame === "function") fwTimeFrame(now);     // (I3, 19-nov) AETAS: la reproduccion automatica (▲ ▼), las estelas de ±100 000 años, la placa del año y los rotulos (fw_time.js; FW_E1T false = nada)
   if (FW.route) FW.route.overlay(now);               // (pasada M) la nave en el hueco del mapa grande, el mapa y la fila de la ficha
   if (typeof fwNmJumpPaint === "function" && FW.ck && FW.ck.hctx) fwNmJumpPaint(FW.ck.hctx, P, FW.VW, FW.VH);   // (7-nov) el salto a casa: fundido dorado, lo ultimo
   if (FW.captionUntil && P.t > FW.captionUntil) { document.getElementById("caption").classList.remove("on"); FW.captionUntil = 0; }
   fwTourBarSync();            // (14-nov, P11a) la barra del tour (DOM); cada fotograma, solo toca el DOM si algo cambia
}
// (E10, Nino 4-nov: «elimina las frases que aparecen en medio de la imagen, menos en el caso del Tour») el rotulo va a la LINEA DE ESTADO
// de arriba a la derecha (clase «side», fw_viewer.css) salvo el del tour (tour = true), que sigue centrado. FW_SIDE_CAPTIONS = false:
// todo centrado como antes (el ROJO de tests/web/fv_nE2_cdp.js).
// (S5, Nino 4-nov) los rotulos de la ruta ITINERARIUM («RUTA · CÁMARA 2 / 5», «RUTA COMPLETA», fw_route.js) van al centro como el tour: se
// reconocen por el comienzo de su plantilla (fwRtT), sin tocar fw_route.js. FW_CENTRE_RT = [] los manda al lateral (el ROJO de fv_nE2_cdp.js).
var FW_SIDE_CAPTIONS = true, FW_CENTRE_RT = ["flying", "done"];
function fwCaptionIsRoute(txt) {
   if (typeof fwRtT !== "function") return false;
   for (var i = 0; i < FW_CENTRE_RT.length; ++i) { var pre = fwRtT(FW_CENTRE_RT[i]).split("{")[0]; if (pre.length >= 3 && String(txt).indexOf(pre) === 0) return true; }
   return false;
}
function fwCaption(txt, sec, tour) { var c = document.getElementById("caption"); c.textContent = txt; c.classList.toggle("side", FW_SIDE_CAPTIONS && !tour && !fwCaptionIsRoute(txt)); c.classList.add("on"); FW.captionUntil = FW.P.t + (sec || 2.5); }

// ---------------------------------------------------------------------------
// EL TOUR: lo de MIRABILIA uno tras otro (viaje con el MODUS, la ficha, una pausa) — se para con cualquier mando
// ---------------------------------------------------------------------------
// (14-nov-2026, P11a; docs/encargos-14nov/P11a-tour-web.md) EL TOUR DEL NAVEGADOR AL DIA CON R7 DE PIXINSIGHT (src/ui/fv_dialog.js tourStep / tourGoTo /
// tourNext / tourPrev / tourPause / tourBarSync; src/ui/fv_hud.js fvTourBarPaint). Las constantes de espera son las MISMAS (FV_TOUR_READ, src/engine/
// fv_tour_plan.js: el paquete ya lo trae) y los rotulos y tooltips tambien (fvTx «tour.*» / «tip.tour_*», src/ui/fv_text.js): aqui no se repite ninguno.
//   · el reloj de lectura EMPIEZA cuando la ficha empieza a escribirse (FWCockpit.cardReadSt.started), no cuando termina;
//   · con el cursor sobre la ficha o MÁS abierto el tour NO se va (ese tiempo cuenta como lectura) y al soltarlos quedan GRACE_S; la pausa del usuario para el reloj;
//   · barra abajo en el centro (#tourBar, DOM encima de la foto: no la desplaza): «TOUR i / n», la fase (EN RUTA · ESCANEANDO · SIGUIENTE PARADA EN n s ·
//     EN ESPERA MIENTRAS LEES · EN PAUSA), barra de cuenta atras y anterior · pausa · siguiente (teclas «,» «B» «.»); parar el tour sigue siendo TOUR / T;
//   · fwTourGoTo(idx) es el UNICO camino a una parada (paso natural, siguiente y anterior; vale en pleno vuelo).
// FW_TOUR_BAR.ON = false: lo de antes (la espera cuenta desde la ficha COMPLETA, sin barra ni mandos): el ROJO de tests/web/fv_R7web_tour_cdp.js.
var FW_TOUR_BAR = { ON: true };
function fwTourToggle() { if (FW.tour) fwTourStop(); else fwTourStart(); }
function fwTourStart() {
   var it = (FW.nav ? FW.nav.items : []).filter(function(x) { return !x.noData; });      // (21-nov, T1-A) la fila «sin datos» de MIRABILIA no es una parada
   if (!it.length) return; var P = FW.P, R = (typeof FV_TOUR_READ !== "undefined" && FV_TOUR_READ.ON);
   // (16-nov, P23-web; fw_box.js) el Tour no visita estrellas de mas alla de la boca de la caja 3D (FW_BOX.TOUR; como fvTourPick de PixInsight)
   it = fwBoxTourItems(it);
   it = fwHeroTourItems(it, FW.scene);      // (17-nov, F8; FW_HERO.TOUR, fw_nav.js) el Tour acaba en el protagonista de la foto, como el de PixInsight
   FW.tour = { items: it, k: -1, state: "next", since: 0, dwell: 7, paused: false, busy: false, dwellD: null, lastT: P.t, R: !!(R && typeof fvTourDwellNew === "function") };
   fwCaption(fwTr("TOUR", "TOUR"), 2, true);
}
function fwTourStop() { FW.tour = null; fwTourBarSync(); }
// ir a la parada idx (0-based) YA: el paso natural del tour, SIGUIENTE y ANTERIOR pasan por aqui (no hay dos caminos). Pasada la ultima el tour acaba
// y la nave vuelve a casa (como siempre en el navegador). En pleno vuelo tambien vale: el viaje nuevo sustituye al que llevaba la nave
function fwTourGoTo(idx) {
   var T = FW.tour, P = FW.P; if (!T || !P) return false;
   if (idx >= T.items.length) { fwTourStop(); fwFly("home", null); return false; }
   idx = Math.max(0, idx);
   T.k = idx; T.paused = false; T.busy = false; T.dwellD = null; FW.cardHover = false;
   var sel = fwNavSel(FW.scene, T.items[T.k]); fwSelectSel(sel);
   if (typeof FW_XP !== "undefined") FW_XP.more = false;
   P.navStayFoto = true; var okT = fwTravel(sel); P.navStayFoto = false;     // (6-nov) el tour se queda en el modo Foto (mira a traves de la nebulosa)
   if (okT) T.state = "fly";
   else { T.state = "hold"; T.since = P.t - T.dwell + 1; T.lastT = P.t; T.dwellD = T.R ? fvTourDwellNew() : null; if (T.dwellD) T.dwellD.done = true; }    // no se pudo viajar: a la siguiente
   return okT;
}
// los mandos (la barra y las teclas , . B) -> true si hubo tour. En una grabacion (REC) el reloj es fijo y el recorrido no se toca
function fwTourCtlOk() { var T = FW.tour; return !!(T && FW.P && FW_TOUR_BAR.ON && !(FW.rec && FW.rec.on)); }
function fwTourNext() { if (!fwTourCtlOk()) return false; fwTourGoTo(FW.tour.k + 1); fwTourBarSync(); fwButtonsState(); return true; }
function fwTourPrev() { if (!fwTourCtlOk()) return false; fwTourGoTo(Math.max(0, FW.tour.k - 1)); fwTourBarSync(); return true; }
function fwTourPause() { if (!fwTourCtlOk()) return false; FW.tour.paused = !FW.tour.paused; fwTourBarSync(); return true; }
function fwTourStep() {
   var T = FW.tour, P = FW.P; if (!T || P.flight) return;
   if (T.state === "fly") { T.state = "hold"; T.since = P.t; T.lastT = P.t; T.arriveT = P.t; T.dwellD = T.R ? fvTourDwellNew() : null; return; }       // llego: empieza la espera de leer
   if (T.state === "hold") {
      // (6-nov, FV_TOUR_READ; Nino: «justo al desplegarse la informacion de la estrella esta desaparece y el tour continua») la espera dura lo que se tarda en
      // leer lo que se ve; (12-nov, R7) y su reloj empieza cuando la ficha EMPIEZA a escribirse. Sin FV_TOUR_READ (ON false): 7 s desde la llegada
      if (T.dwellD && T.R) {
         var dtT = Math.max(0, P.t - T.lastT), cr = FW.ck.cardReadSt || null; T.lastT = P.t;
         var crOk = !!(cr && P.sel && cr.sel === P.sel.kind + ":" + P.sel.i), closed = !!FW.cardClosedByUser, onCard = !!FW.cardHover && !closed, stR;      // (14-nov, R3 H3) la ficha cerrada no esta «en uso»: onCard exige !closed, como MÁS
         if (FW_TOUR_BAR.ON) {
            var more = !!(typeof FW_XP !== "undefined" && FW_XP.more && !closed);
            stR = { complete: closed || (crOk && cr.typed), words: (crOk && !closed) ? cr.words : 0, paused: onCard || !!T.paused, hold: !!T.paused,
                    started: closed || (crOk && !!cr.started), busy: onCard || more, more: more };
            T.busy = onCard || more;
         } else stR = { complete: closed || (crOk && cr.typed), words: (crOk && !closed) ? cr.words : 0, paused: onCard };       // lo de antes: sin started, sin busy
         if (!fvTourDwellStep(T.dwellD, dtT, stR)) return;
         var D = T.dwellD;
         T.log = T.log || []; T.log.push({ k: T.k, arriveT: T.arriveT, readyT: T.arriveT + D.waitS, waitS: D.waitS, readS: D.readS, needS: D.needS, pausedS: D.pausedS, words: D.words, why: D.readyWhy, leaveT: P.t });
      }
      else if (T.paused) return;
      else if (P.t - T.since < T.dwell) return;
   }
   fwTourGoTo(T.k + 1);
}
// ---- la barra del tour (DOM): la misma que fvTourBarPaint (src/ui/fv_hud.js), en dorado y latón, abajo en el centro de la ventana ----
var FW_TOUR_GLYPH = {      // los tres mandos (la misma silueta que fvTourGlyph de PixInsight)
   prev: '<path d="M4 4.5v13M18 4.5 8 11l10 6.5z"/>', next: '<path d="M18 4.5v13M4 4.5 14 11 4 17.5z"/>',
   pause: '<path d="M7.5 4.5v13M14.5 4.5v13"/>', play: '<path d="M7 4 18 11 7 18z"/>'
};
function fwTourTx(key, params) { return (typeof fvTx === "function") ? fvTx(key, params || null, FW_LANG) : key; }
function fwTourBarEl() {
   var el = document.getElementById("tourBar"); if (el) return el;
   var win = document.getElementById("win"); if (!win) return null;
   el = document.createElement("div"); el.id = "tourBar"; el.setAttribute("role", "status");
   el.innerHTML = '<div class="tb-main"><div class="tb-row"><span class="tb-lab"></span><span class="tb-st"></span></div><div class="tb-track"><i class="tb-fill"></i></div></div><div class="tb-btns"></div>';
   var bt = el.querySelector(".tb-btns"), acts = [["tour-prev", "prev", fwTourPrev], ["tour-pause", "pause", fwTourPause], ["tour-next", "next", fwTourNext]];
   acts.forEach(function(a) {
      var b = document.createElement("button"); b.type = "button"; b.id = a[0]; b.className = "tb-btn"; b.innerHTML = '<svg viewBox="0 0 22 22" aria-hidden="true">' + FW_TOUR_GLYPH[a[1]] + '</svg>';
      b.addEventListener("click", function(e) { e.stopPropagation(); a[2](); });
      b.addEventListener("mousedown", function(e) { e.preventDefault(); });      // el clic no le da el foco: Espacio sigue siendo VIAJAR (y no pulsa el boton otra vez)
      ["pointerdown", "pointerup", "dblclick", "wheel"].forEach(function(t) { b.addEventListener(t, function(e) { e.stopPropagation(); }); });     // la barra no es la escena: ni gira, ni elige
      bt.appendChild(b);
   });
   ["pointerdown", "pointerup", "dblclick", "wheel"].forEach(function(t) { el.addEventListener(t, function(e) { e.stopPropagation(); }); });
   win.appendChild(el); return el;
}
// lo que dice la barra: { i, n, phase, left, frac, paused, last, t } (fvTourBarSync de PixInsight); null sin tour (o con FW_TOUR_BAR.ON false)
function fwTourBarState() {
   var T = FW.tour, P = FW.P; if (!FW_TOUR_BAR.ON || !T || !P) return null;
   var B = { i: Math.max(1, T.k + 1), n: T.items.length, phase: "fly", left: null, frac: 0, paused: !!T.paused, last: (T.k >= T.items.length - 1), t: P.t }, D = T.dwellD;
   if (P.flight || T.state !== "hold") B.phase = "fly";
   else if (T.paused) B.phase = "paused";
   else if (T.busy) B.phase = "busy";
   else if (D && D.ready && D.left !== null) B.phase = "read";
   else B.phase = "scan";
   if (D && D.ready) { B.left = D.left; B.frac = D.frac; }
   else if (T.state === "hold" && !D) { B.frac = fvClamp((P.t - T.since) / T.dwell, 0, 1); B.left = Math.max(0, T.dwell - (P.t - T.since)); if (!T.paused) B.phase = "read"; }
   return B;
}
function fwTourBarSync() {
   var el = fwTourBarEl(), B = fwTourBarState(), win = document.getElementById("win"); FW.tourBar = B; if (!el) return;
   if (!B) { if (el.classList.contains("on")) { el.classList.remove("on"); if (win) win.classList.remove("tourbar"); } return; }
   var st = { fly: "tour.fly", scan: "tour.scan", busy: "tour.busy", paused: "tour.paused" }[B.phase], lab = fwTourTx("tour.label", { i: B.i, n: B.n }), txt;
   if (st) txt = fwTourTx(st);
   else txt = fwTourTx(B.last ? "tour.endIn" : "tour.nextIn", { s: Math.max(1, Math.ceil(B.left === null ? 0 : B.left - 1e-6)) });
   var q = function(s) { return el.querySelector(s); }, labE = q(".tb-lab"), stE = q(".tb-st"), fill = q(".tb-fill");
   if (labE.textContent !== lab) labE.textContent = lab;
   if (stE.textContent !== txt) stE.textContent = txt;
   var tips = { "tour-prev": "tip.tour_prev", "tour-pause": "tip.tour_pause", "tour-next": "tip.tour_next" };
   for (var id in tips) { var b = document.getElementById(id), tt = fwTourTx(tips[id]); if (b.title !== tt) { b.title = tt; b.setAttribute("aria-label", tt); } }
   var pb = document.getElementById("tour-pause"), want = B.paused ? "play" : "pause"; if (pb.getAttribute("data-g") !== want) { pb.setAttribute("data-g", want); pb.querySelector("svg").innerHTML = FW_TOUR_GLYPH[want]; }
   var bt = fwTourTx("tip.tour_bar"); if (el.title !== bt) el.title = bt;
   el.setAttribute("data-phase", B.phase); el.setAttribute("data-i", B.i); el.setAttribute("data-n", B.n); el.setAttribute("data-left", B.left === null ? "" : B.left.toFixed(2));
   // la barra: cuenta atras (frac) o un tramo que se desliza cuando no hay cuenta (en ruta, escaneando)
   var slide = (B.phase === "fly" || B.phase === "scan"), seg = 0.22, u = (B.t * 0.7) % 2, pos = (u <= 1 ? u : 2 - u) * (1 - seg);
   fill.style.left = slide ? (100 * pos).toFixed(1) + "%" : "0%";
   fill.style.width = slide ? (100 * seg).toFixed(1) + "%" : (100 * fvClamp(B.frac, 0, 1)).toFixed(1) + "%";
   fill.style.opacity = slide ? (B.phase === "fly" ? "1" : ".69") : (B.phase === "busy" ? (0.62 + 0.38 * Math.sin(B.t * 5)).toFixed(2) : "1");
   fill.className = "tb-fill" + (B.phase === "paused" ? " dim" : "");
   if (!el.classList.contains("on")) { el.classList.add("on"); if (win) win.classList.add("tourbar"); }
   // la ficha cae encima: la barra se aparta al lado libre (la ficha esta siempre en un borde), como fvTourBarPaint
   var wr = win.getBoundingClientRect(), br = el.getBoundingClientRect(), bw = el.offsetWidth, x0 = Math.round((wr.width - bw) / 2), cd = FW.ck && FW.ck.card;
   if (cd && cd.style.display === "block") {
      var cr = cd.getBoundingClientRect(), cl = cr.left - wr.left, cx = cr.right - wr.left, yT = br.top - wr.top, yB = br.bottom - wr.top;
      if (cx > x0 - 8 && cl < x0 + bw + 8 && cr.bottom - wr.top > yT - 6 && cr.top - wr.top < yB + 6) x0 = cl > wr.width / 2 ? Math.max(12, Math.round(cl - 12 - bw)) : Math.min(wr.width - 12 - bw, Math.round(cx + 12));
   }
   if (el.getAttribute("data-x") !== String(x0)) { el.setAttribute("data-x", String(x0)); el.style.left = x0 + "px"; el.style.transform = "none"; }
}

function fwLoop(now) {
   requestAnimationFrame(fwLoop);
   if (FW.testHold) return;                       // las pruebas llevan el reloj
   var P = FW.P, dt;
   if (FW.rec && FW.rec.on && FW.rec.mode === "webcodecs") {
      // GRABACION: reloj fijo t = n/fps; si el codificador va lleno, este fotograma se salta (se espera, no se pierde)
      if (FW.rec.enc.encodeQueueSize > 2) return;
      dt = 1 / FW.rec.fps;
      fwStep(P, dt); fwRenderFrame(dt); FW.rec.frame();
      FW.ck.setRec(true, (FW.rec.n / FW.rec.fps).toFixed(1).replace(".", FW_LANG === "es" ? "," : ".") + " s");
   } else {
      dt = Math.min(0.1, Math.max(0, (now - FW.last) / 1000));
      fwStep(P, dt);
      if (FW.route) FW.route.preRender();          // (pasada M) una miniatura de camara, antes del fotograma de verdad (que la tapa)
      fwRenderFrame(dt);
   }
   FW.last = now;
   fwTourStep();
   fwOverlay(now);
   fwButtonsState();
   FW.fpsAcc = (FW.fpsAcc || 0) * 0.95 + (dt > 0 ? 1 / dt : 0) * 0.05;
}

function fwRecToggle() {
   var r = FW.rec;
   if (!r.on) { r.start().then(function(ok) { FW.ck.setRec(ok, ok ? "" : "—"); if (!ok) fwFatal("Video: " + r.err); }); }
   else r.stop().then(function(res) { FW.lastRecording = res; FW.ck.setRec(false, ""); if (!FW.testHold && !FW.noDownload) fwDownload(res.blob, res.name); })
          .catch(function(e) { fwFatal("Video: " + e); });
}

// ---------------------------------------------------------------------------
// PRUEBAS (tests/web/fv_nD_cdp.js, fv_f3_cdp.js): reloj en manos de la prueba, fotogramas deterministas
// ---------------------------------------------------------------------------
FW.test.look = function(l) { var got = fwSetLook(l, false); return { look: got, info: FW.R ? FW.R.info.look : null, ps: !!(FW.json && FW.json.photoStars), atlas: !!(FW.imgs && FW.imgs.psatlas) }; };
FW.test.hold = function(on) { FW.testHold = !!on; return true; };
FW.test.ready = function() { return { ready: FW.ready, vol: !!FW.volReady, volume: FW.R ? FW.R.info.volume : "", objects: FW.R ? (FW.R.info.objects || 0) : 0, err: FW.err, bootMs: FW.bootMs, volMs: FW.volMs, firstPaintMs: FW.firstPaintMs }; };
FW.test.clean = function(on) {
   FW.cleanOn = !!on; document.body.classList.toggle("clean", !!on); fwResize(); fwSetMode(FW.mode); if (on) { FW.R.opt.bloomK = 0; FW.R.opt.grain = 0; FW.R.opt.vig = 0; } return true;
};
// (pasada M) con el mapa en grande, la nave vuelve a su hueco DESPUES del repintado forzado de la franja (como en fwLoop)
FW.test.render = function() { fwRenderFrame(0); fwOverlay(performance.now() + 5000); if (FW.nav) FW.nav.update(FW.P, FW.P.sel, performance.now() + 9999, true); if (FW.route && FW.route.big) FW.route.overlay(performance.now() + 9999); return true; };
FW.test.home = function() { fvPilotHomeNow(FW.P); FW.P.sel = null; FW.P.vel = [0, 0, 0]; FW.P.speedLyS = 0; FW.P.speedC = 0; FW.ck.hideCard(); FW.reopenAt = null; FW.arriveReopen = false; FW.glow = 0; FW.flT0 = null; FW.flPrev = 0; fwHeroUpdate(); return FW.test.render(); };
FW.test.step = function(dt, n) { for (var i = 0; i < n; ++i) fwStep(FW.P, dt); return FW.test.render(); };
FW.test.state = function() { var P = FW.P; return { pos: P.cam.pos, look: P.cam.look, fovDeg: P.cam.fov / FV_DEG, mode: P.mode, warp: P.warp, trail: P.trail, flight: P.flight ? { kind: P.flight.kind, t: P.flight.t, dur: P.flight.dur, phase: P.flight.phase } : null, sel: P.sel, arrivedAt: P.arrivedAt, VW: FW.VW, VH: FW.VH, info: FW.info, profile: FW.mode, opt: FW.R.opt, t: P.t, speedC: P.speedC }; };
FW.test.pickStar = function(lo, hi, gmax, qmax) {
   var sc = FW.scene, S = sc.stars, N = sc.nebula, P = FW.P, pr = fvProjector(P.cam, FW.VW, FW.VH), best = -1, bd = 1e9;
   lo = lo || 0.80; hi = hi || 1.02; gmax = gmax || 14; qmax = qmax || 0;
   for (var i = 0; i < S.n; ++i) {
      if (S.q[i] > qmax || !S.inFrame[i] || S.g[i] > gmax || S.dEarth[i] < lo * N.distLy || S.dEarth[i] > hi * N.distLy) continue;
      var q = pr.project(fvStarPos(sc, i)); if (!q) continue;
      var dd = Math.abs(q[0] - FW.VW / 2) + Math.abs(q[1] - FW.VH / 2);
      if (dd < bd && q[0] > 0.15 * FW.VW && q[0] < 0.85 * FW.VW && q[1] > 0.15 * FW.VH && q[1] < 0.85 * FW.VH) { bd = dd; best = i; }
   }
   return best;
};
// elegir una estrella con un clic y (por defecto) pulsar INFO: asi la ficha queda abierta como antes de que el clic solo eligiera; noCard = solo el clic
FW.test.select = function(i, noCard) {
   var P = FW.P, pr = fvProjector(P.cam, FW.VW, FW.VH), q = pr.project(fvStarPos(FW.scene, i));
   var s = fwSelect(q[0] + 2, q[1] - 2); if (s && !noCard) fwInfoToggle(); fwButtonsState();
   return { want: i, got: s ? s.i : null, kind: s ? s.kind : null, sx: q[0], sy: q[1], lines: FW.ck.cardLines ? FW.ck.cardLines.map(function(l) { return l.t; }) : [] };
};
FW.test.selectNebula = function() { var P = FW.P; P.sel = { kind: "nebula", sx: FW.VW * 0.5, sy: FW.VH * 0.5, t0: P.t }; FW.ck.showCard(P.sel, fwCardLines(P.sel), null, P); return true; };
FW.test.fly = function(kind) { var k = kind === "travel" ? (FW.mode === "spectacular" ? "warp" : "cine") : kind; var ok = (k === "warp" || k === "cine" || k === "goto") ? fwTravel(FW.P.sel) : fwFly(k, FW.P.sel); if (k === "warp" && FW.mode !== "spectacular") ok = fwFly("warp", FW.P.sel); return { ok: ok, dur: FW.P.flight ? FW.P.flight.dur : 0, kind: FW.P.flight ? FW.P.flight.kind : null }; };
FW.test.flyKind = function(k) { return k === "cine" ? "goto" : k; };
FW.test.flyTo = function(f, dt) {
   var P = FW.P; dt = dt || 1 / 30; var n = 0, maxW = 0, maxFov = 0, flashN = 0, fxN = 0, fxMax = 0, wasWarp = !!(P.flight && P.flight.kind === "warp");
   function one() { fwStep(P, dt); var x = fwFx(dt); ++n; maxW = Math.max(maxW, P.warp); maxFov = Math.max(maxFov, P.cam.fov / FV_DEG); if (P.flash > 0) ++flashN; if (x.flash > 0.02) ++fxN; fxMax = Math.max(fxMax, x.flash); }
   while (P.flight && P.flight.t < f * P.flight.dur && n < 5000) one();
   if (f > 1) while (P.flight && n < 5000) one();
   for (var k = 0; f > 1 && wasWarp && k < 45; ++k) one();      // warp: la cola del ultimo destello sigue tras parar la nave
   FW.test.render();
   return { steps: n, warp: P.warp, maxWarp: maxW, maxFovDeg: maxFov, flashFrames: flashN, flashFxFrames: fxN, flashFxMax: fxMax, mode: P.mode, t: P.flight ? P.flight.t : null, phase: FW.fxNow ? FW.fxNow.phase : null };
};
// (§15) avanza el warp hasta el PICO del primer destello del visor (sube y empieza a bajar) y pinta -> { t, flash, phase, steps }
FW.test.flashPeak = function(dt) {
   var P = FW.P; dt = dt || 1 / 60; var n = 0, prev = 0, x = null;
   while (P.flight && n < 8000) { fwStep(P, dt); x = fwFx(dt); ++n; if (prev > 0.05 && x.flash < prev) break; prev = x.flash; }
   FW.test.render(); return { t: P.t, flash: FW.fxNow ? FW.fxNow.flash : 0, phase: FW.fxNow ? FW.fxNow.phase : null, steps: n };
};
// avanza el warp hasta que entra en la fase `name` (+ frac de su duracion) y pinta -> { phase, fx }
FW.test.warpTo = function(name, frac, dt) {
   var P = FW.P; dt = dt || 1 / 30; var n = 0, ph = fwWarpPhase(P);
   while (P.flight && n < 5000) { ph = fwWarpPhase(P); if (ph && ph.name === name && ph.u >= (frac || 0)) break; fwStep(P, dt); fwFx(dt); ++n; }
   FW.test.render(); var fx = FW.fxNow || {};
   return { steps: n, phase: ph ? ph.name : null, u: ph ? ph.u : null, warp: P.warp, trail: P.trail, flash: fx.flash, radial: fx.radial, zoom: fx.zoom, tunnel: fx.tunnel, fovDeg: P.cam.fov / FV_DEG, radio: FW.radio ? FW.radio.duckTo : null };
};
FW.test.orbit = function(sec, dt) { var P = FW.P; dt = dt || 1 / 30; if (!P.orbit) fvPilotOrbit(P, P.arrivedAt || P.sel); for (var i = 0; i < Math.round(sec / dt); ++i) fwStep(P, dt); FW.test.render(); return { theta: P.orbit ? P.orbit.theta / FV_DEG : null }; };
FW.test.pose = function(pos, look, fovDeg) { var P = FW.P; fvPilotStop(P); if (P.free && typeof fvFreeHalt === "function") fvFreeHalt(P); P.cam.pos = pos.slice(); P.cam.look = fvNorm(look); P.cam.fov = fovDeg * FV_DEG; P.mode = "free"; P.vel = [0, 0, 0]; P.speedLyS = 0; P.speedC = 0; fwHeroUpdate(); return FW.test.render(); };
FW.test.gauges = function() { return JSON.parse(JSON.stringify(FW.ck.gaugeState || {})); };
FW.test.chrono = function() { return fwChrono(); };
FW.test.hero = function() { return FW.hero; };
// (D, rev. 3) la niebla de dentro y el punto de fuga negro: lo que se aplico en el ultimo fotograma
FW.test.fog = function() { var R = FW.R; return { k: R.fogK || 0, inW: R.fogInW || 0, hole: R.uStar ? R.uStar.uHole.value : 0 }; };
FW.test.starScreen = function(i) { var P = FW.P, q = fvProjector(P.cam, FW.VW, FW.VH).project(fvStarPos(FW.scene, i)); return q ? [q[0], q[1], q[2]] : null; };
FW.test.spoil = function(on) { FW.R.spoil(on, 11); return FW.test.render(); };
FW.test.setOpt = function(o) { for (var k in o) FW.R.opt[k] = o[k]; return FW.R.opt; };
FW.test.mode = function(m) { fwSetMode(m); return FW.mode; };
// (N4) estado de la ficha · (N1) estado de la franja · (N8) objetos · (N10) teclas por la API · (N14) radio
FW.test.card = function() { var c = FW.ck.card; return { sel: FW.ck.cardSel ? { kind: FW.ck.cardSel.kind, i: FW.ck.cardSel.i } : null, hidden: !!FW.ck.cardHidden, shown: c.style.display === "block", closedByUser: !!FW.cardClosedByUser, reopenAt: FW.reopenAt, t: FW.P.t, title: document.getElementById("cardTitle").textContent }; };
FW.test.closeCard = function() { var b = document.getElementById("cardClose"); b.click(); return FW.test.card(); };
FW.test.nav = function() { var N = FW.nav; return { items: N.items.map(function(it) { return it.kind + ":" + it.name; }), fovPts: N.fov ? N.fov.poly.length : 0, away: N.fov ? N.fov.away : null, ship: N.fov ? N.fov.ship : null, look: N.fov ? N.fov.look : null, rect2: N.rect2, c2: [N.c2.width, N.c2.height], c3: [N.c3.width, N.c3.height], cover: N.fov ? N.fov.cover : null, big: N.fov ? N.fov.big : null, drawn: N.fov ? N.fov.drawn : null, lum2: fwCanvasLum(N.c2), lum3: fwCanvasLum(N.c3) }; };
// luminancia media (0–255) de un lienzo 2D: ¿se ha pintado algo? (TABULA/PROFUNDITAS negras = 0)
function fwCanvasLum(c) { try { var w = c.width, h = c.height, d = c.getContext("2d").getImageData(0, 0, w, h).data, s = 0; for (var i = 0; i < d.length; i += 4) s += 0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]; return s / (w * h); } catch (e) { return -1; } }
FW.test.navSelect = function(k, travel) { var N = FW.nav, it = N.items[k]; if (!it) return null; var s = fwNavSel(FW.scene, it); if (!s) return null; fwSelectSel(s); if (travel) fwTravel(s); return s; };
FW.test.objects = function() { var R = FW.R; return { n: R.objs.length, cuts: FW.objCuts || [], visible: R.objVisible || 0, list: (FW.scene.objects || []).map(function(o) { return o.type + ":" + o.name; }) }; };
FW.test.objScreen = function(i) { var o = FW.scene.objects[i], pr = fvProjector(FW.P.cam, FW.VW, FW.VH), q = pr.project(fwBoxPaintPos(FW.scene, o)); return q ? { x: q[0], y: q[1], z: q[2], r: pr.f * (o.radiusLy || 0) * fwBoxPaintK(FW.scene, o) / q[2] } : null; };
FW.test.clickAt = function(x, y) { var s = fwSelect(x, y); return s ? { kind: s.kind, i: s.i } : null; };
FW.test.info = function() { fwInfoToggle(); fwButtonsState(); return FW.test.card(); };
FW.test.key = function(code, down) { return typeof fvPilotKey === "function" ? fvPilotKey(FW.P, FW_KEYS[code], !!down) : false; };
FW.test.radio = function() { var r = FW.radio, v = FW.vac || {}; return { vacR: v.r, vacF: v.f, vacSep: v.sep, vacNear: v.near, vacAway: v.away, duckTo: r.duckTo, duckF: r.duckF, lpTo: r.lpTo, lpHz: r.lpHz, stations: r.stations.length, packaged: (r.packaged || []).length }; };
FW.test.fx = function() { return FW.fxNow || null; };
FW.test.phase = function() { var p = fwWarpPhase(FW.P); return p ? p.name : null; };
// (11-nov, NV-13) EL LABORATORIO EN EL VISOR (tests/web/fv_nv13_parity_cdp.js)
FW.test.lab = function() {
   var P = FW.P, L = P.lab, B = P.cam.B;
   return { on: fwLabOn(), FW_LAB: FW_LAB, loaded: typeof FV_LAB !== "undefined", S: L ? L.S : null, S0: L ? L.S0 : null, land: L ? L.land : null, cover: L ? L.cover : null, anchorOn: L ? L.anchorOn : null,
            B: B ? { f: B.f.slice(), r: B.r.slice(), d: B.d.slice() } : null, pos: P.cam.pos.slice(), fovDeg: P.cam.fov / FV_DEG, last: FW.labLast || null, lum: L && L.lum ? { nx: L.lum.nx, ny: L.lum.ny, v: L.lum.v.slice() } : null };
};
// (11-nov, NV-16) EL CAMPO DE FONDO (fw_amb.js) para tests/web/fv_nv16_amb_cdp.js: borrar su estado (y apuntar la pose de cada fotograma pintado),
// la lista del ultimo fotograma, un viaje PINTANDO cada paso y la diferencia de pixeles con el campo y sin el en la pose de ahora
FW.test.ambReset = function(rec) { if (FW.R) { FW.R.amb = null; FW.R.ambLast = null; } FW.ambRec = rec ? [] : null; return true; };
FW.test.ambRec = function() { return FW.ambRec || null; };
FW.test.ambList = function(full) {
   var L = FW.R && FW.R.ambLast; if (!L) return null;
   var o = { amb: L.amb, ambStreak: L.ambStreak, ambMasked: L.ambMasked, ambW: L.ambW, kq: L.kq === undefined ? null : L.kq, nPts: L.nPts, nSeg: L.nSeg, ms: FW.R.info.ambMs };
   if (full && L.pts) { o.pts = Array.from(L.pts.subarray(0, 3 * L.nPts)); o.segs = Array.from(L.segs.subarray(0, 5 * L.nSeg)); }
   return o;
};
// o: { a, b, style, vw, vh, park (pasos parado al llegar), dumpEvery } -> { steps: [[k, t, nPts, nSeg, amb, ambStreak, ambMasked, kq, ambW, vuelo]], dumps: { k: lista }, arr }
FW.test.ambTrip = function(o) {
   var P = FW.test.labNew(o.vw, o.vh) && FW.P, dt = 1 / 30, m, k = 0, t = 0, out = { steps: [], dumps: {}, a: o.a, b: o.b, style: o.style }, every = o.dumpEvery || 10;
   if (o.a >= 0) {
      fvPilotSetStyle(P, "spectacular"); P.dollyDone = true; P.sel = { kind: "star", i: o.a }; fvPilotSetSpeed(P, 1); fvPilotFly(P, "travel", P.sel);
      for (m = 0; P.flight && m < 30 * 120; ++m) fwStep(P, dt);
      for (m = 0; (P.coast || P.navReturn || (P.lab && P.lab.hold)) && m < 30 * 30; ++m) fwStep(P, dt);
      for (m = 0; m < 15; ++m) fwStep(P, dt);
      fvPilotSetSpeed(P, 0.5);
   } else for (m = 0; m < 10; ++m) fwStep(P, dt);
   FW.test.ambReset(true);
   out.hero = [];
   var snap = function() { var L = FW.test.ambList(k % every === 0 || (o.dumpAt && o.dumpAt.indexOf(k) >= 0)), hg = FW.R.info.heroGl, hl = FW.R.info.heroLab;
      out.hero.push(hg ? [hg.i, hg.w, hg.rpx, hg.soft, hl ? hl.rr : null, hl ? hl.kN : null, hl ? hl.kPh : null] : null);
      if (!L) { out.steps.push([k, +P.t.toFixed(5), -1, -1, 0, 0, 0, null, 0, P.flight ? 1 : 0]); return; }
      out.steps.push([k, +P.t.toFixed(5), L.nPts, L.nSeg, L.amb, L.ambStreak, L.ambMasked, L.kq, L.ambW, P.flight ? 1 : 0]); if (L.pts) out.dumps[k] = { pts: L.pts, segs: L.segs }; };
   fwRenderFrame(dt); snap();                                     // en casa (o junto a la estrella de salida)
   fvPilotSetStyle(P, o.style); P.dollyDone = true; P.sel = { kind: "star", i: o.b };
   if (!fvPilotFly(P, "travel", P.sel)) { out.fail = true; return out; }
   out.dur = P.flight.dur; var park = 0;
   while ((P.flight || P.coast || (P.lab && P.lab.hold) || park < (o.park || 30)) && t < 120) {
      fwStep(P, dt); ++k; t += dt; if (!P.flight && !P.coast) ++park;
      if (out.arr === undefined && !P.flight) out.arr = +t.toFixed(5);
      fwRenderFrame(dt); snap();
   }
   out.n = k; out.W = FW.R.W; out.H = FW.R.H; out.recs = FW.ambRec; FW.ambRec = null;   // las poses, aqui mismo (un fotograma del bucle vivo entre dos llamadas no se cuela)
   return out;
};
FW.test.ambDiff = function() {
   var R = FW.R, f0 = R.frame, on = FW_AMB.ON, rf = R.opt.restFull, cv = document.getElementById("gl"), W = cv.width, H = cv.height;
   var shot = function() { R.frame = f0; fwRenderFrame(0); var c = document.createElement("canvas"); c.width = W; c.height = H; var x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(cv, 0, 0); return x.getImageData(0, 0, W, H).data; };
   var cmp = function(a, b) { var n = 0, s = 0; for (var i = 0; i < a.length; i += 4) { var d = Math.abs(a[i] - b[i]) + Math.abs(a[i + 1] - b[i + 1]) + Math.abs(a[i + 2] - b[i + 2]); if (d > 0) { ++n; s += d; } } return { n: n, sum: s }; };
   R.opt.restFull = false;
   // los pixeles cambiados FUERA de lo que dice la lista (5 × 5 alrededor de cada punto, 2,5 px alrededor de cada trazo): tiene que ser 0 (el campo no toca nada mas)
   var outside = function(a, b, Lf) {
      var M = new Uint8Array(W * H), i, x, y;
      if (Lf && Lf.pts) for (i = 0; i < Lf.pts.length; i += 3) for (y = Lf.pts[i + 1] - 2; y <= Lf.pts[i + 1] + 2; ++y) for (x = Lf.pts[i] - 2; x <= Lf.pts[i] + 2; ++x) if (x >= 0 && y >= 0 && x < W && y < H) M[y * W + x] = 1;
      if (Lf && Lf.segs) for (i = 0; i < Lf.segs.length; i += 5) {
         var x0 = Lf.segs[i], y0 = Lf.segs[i + 1], x1 = Lf.segs[i + 2], y1 = Lf.segs[i + 3], dx = x1 - x0, dy = y1 - y0, l2 = Math.max(1e-9, dx * dx + dy * dy);
         for (y = Math.floor(Math.min(y0, y1) - 3); y <= Math.ceil(Math.max(y0, y1) + 3); ++y) for (x = Math.floor(Math.min(x0, x1) - 3); x <= Math.ceil(Math.max(x0, x1) + 3); ++x) {
            if (x < 0 || y < 0 || x >= W || y >= H) continue; var px = x + 0.5, py = y + 0.5, h = Math.max(0, Math.min(1, ((px - x0) * dx + (py - y0) * dy) / l2)), ex = px - x0 - h * dx, ey = py - y0 - h * dy;
            if (ex * ex + ey * ey <= 6.25) M[y * W + x] = 1;
         }
      }
      var n = 0; for (i = 0; i < W * H; ++i) if (!M[i] && (a[4 * i] !== b[4 * i] || a[4 * i + 1] !== b[4 * i + 1] || a[4 * i + 2] !== b[4 * i + 2])) ++n;
      return n;
   };
   try { FW_AMB.ON = false; var a = shot(), a2 = shot(); FW_AMB.ON = on; var b = shot(), L = FW.test.ambList(true), f1 = cmp(a, b), f2 = cmp(a2, b);
         // (dos pintadas iguales seguidas pueden diferir en unos pocos pixeles —32 medidos con la Via Lactea apagada—: se toma la menor de las dos diferencias)
         var r = { field: f1.n <= f2.n ? f1 : f2, noise: cmp(a, a2), outside: Math.min(outside(a, b, L), outside(a2, b, L)), W: W, H: H };
         if (L) { delete L.pts; delete L.segs; } r.list = L; return r; }
   finally { FW_AMB.ON = on; R.opt.restFull = rf; }
};
FW.test.labFeed = function(mode, inject) { FW_LAB.FEED = mode || "own"; FW.labInject = inject || null; return FW_LAB.FEED; };
FW.test.labToggle = function() { return fwLabToggle(); };
// un piloto NUEVO como el de fwStart (fvPilotNew + laboratorio + regulador + fin de vuelo + estilo), con la vista vw x vh (la de PixInsight en las pruebas):
// cada viaje de la prueba de paridad sale de un piloto recien hecho, como los de lab_trips.js en node
FW.test.labNew = function(vw, vh) {
   var P = fvPilotNew(FW.scene, vw || FW.VW, vh || FW.VH); FW.P = P;
   fwLabInit(P); fvPilotSetSpeed(P, 0.5); P.onFlightEnd = fwOnArrive; fvPilotSetStyle(P, FW.mode || "cine");
   FW.reopenAt = null; FW.arriveReopen = false; FW.tour = null; FW.labLast = null;
   return FW.test.lab();
};
// UN VIAJE con paso fijo de 1/30 s y EL MISMO GUION que tests/_egm/lab/lab_trips.js (trip y arriveAt): desde casa (a < 0) o desde la estrella a
// (llegada de salida en warp a regulador 1), a la estrella b con el estilo dado. Cada paso por fwStep (el del visor: motor + lo que lee del pintor).
// -> { dur, steps: [[t, flight, x, y, z, fx, fy, fz, rx, ry, rz, stars, cover, land]], arr (t de llegada) }; o.every = cada cuantos pasos se apunta
FW.test.labTrip = function(o) {
   var P = FW.test.labNew(o.vw, o.vh) && FW.P, sc = FW.scene, S = sc.stars, every = o.every || 1, out = { a: o.a, b: o.b, style: o.style, steps: [], pre: [] };
   var dt = 1 / 30, pos = function(i) { return [S.x[i], S.y[i], S.z[i]]; };
   var rec = function(arr, t) { var c = P.cam, B = c.B || { f: c.look, r: [0, 0, 0], d: [0, 0, 0] }, L = P.lab || {}, fr = FW.labLast || {};
      arr.push([+t.toFixed(5), P.flight ? 1 : 0, c.pos[0], c.pos[1], c.pos[2], B.f[0], B.f[1], B.f[2], B.r[0], B.r[1], B.r[2], fr.stars === undefined ? -1 : fr.stars, fr.cover === undefined ? -1 : fr.cover, L.land === true ? 1 : (L.land === false ? 0 : -1)]); };
   var m, k = 0, t = 0, tHold = 0;
   if (o.a >= 0) {
      fvPilotSetStyle(P, "spectacular"); P.dollyDone = true; P.sel = { kind: "star", i: o.a }; fvPilotSetSpeed(P, 1);
      fvPilotFly(P, "travel", P.sel);
      for (m = 0; P.flight && m < 30 * 120; ++m) { fwStep(P, dt); if (o.recPre) rec(out.pre, P.t); }
      for (m = 0; (P.coast || P.navReturn || (P.lab && P.lab.hold)) && m < 30 * 30; ++m) { fwStep(P, dt); if (o.recPre) rec(out.pre, P.t); }
      for (m = 0; m < 15; ++m) { fwStep(P, dt); if (o.recPre) rec(out.pre, P.t); }
      fvPilotSetSpeed(P, 0.5);
   } else for (m = 0; m < 10; ++m) fwStep(P, dt);
   out.start = { pos: P.cam.pos.slice(), f: P.cam.B ? P.cam.B.f.slice() : P.cam.look.slice(), t: P.t };
   fvPilotSetStyle(P, o.style); P.dollyDone = true; P.sel = { kind: "star", i: o.b };
   if (!fvPilotFly(P, "travel", P.sel)) { out.fail = true; return out; }
   out.dur = P.flight.dur; var wasFly = true;
   while ((P.flight || P.coast || (P.lab && P.lab.hold && tHold < 3)) && t < 120) {
      fwStep(P, dt); ++k; t += dt; if (!P.flight) tHold += dt;
      if (k % every === 0 || !P.flight) rec(out.steps, t);
      if (wasFly && !P.flight && out.arr === undefined) out.arr = +t.toFixed(5);
      if (!P.flight) wasFly = false;
   }
   out.t = t; out.posEnd = P.cam.pos.slice(); out.d = fvLen(fvSub(pos(o.b), out.start.pos));
   out.orb = P.flight === null && P.events ? P.events.filter(function(e) { return /orbit|arrive/.test(e.what); }).map(function(e) { return e.what; }) : null;
   return out;
};

// correlacion de luminancia entre lo que se ve (pintado AHORA) y la foto recortada como la cubre el lienzo (320 de ancho)
FW.test.corr = function() {
   fwRenderFrame();
   var cv = document.getElementById("gl"), w = 320, h = Math.round(320 * FW.VH / FW.VW);
   var a = document.createElement("canvas"); a.width = w; a.height = h; var ga = a.getContext("2d", { willReadFrequently: true }); ga.drawImage(cv, 0, 0, w, h);
   var ph = FW.imgs.photo, b = document.createElement("canvas"); b.width = w; b.height = h; var gb = b.getContext("2d", { willReadFrequently: true });
   var cov = Math.max(FW.VW / ph.width, FW.VH / ph.height), cw = FW.VW / cov, ch = FW.VH / cov;
   gb.drawImage(ph, (ph.width - cw) / 2, (ph.height - ch) / 2, cw, ch, 0, 0, w, h);
   var A = ga.getImageData(0, 0, w, h).data, B = gb.getImageData(0, 0, w, h).data, n = w * h, ma = 0, mb = 0, i, la = new Float64Array(n), lb = new Float64Array(n);
   for (i = 0; i < n; ++i) { la[i] = 0.2126 * A[4 * i] + 0.7152 * A[4 * i + 1] + 0.0722 * A[4 * i + 2]; lb[i] = 0.2126 * B[4 * i] + 0.7152 * B[4 * i + 1] + 0.0722 * B[4 * i + 2]; ma += la[i]; mb += lb[i]; }
   ma /= n; mb /= n; var sab = 0, saa = 0, sbb = 0, md = 0;
   for (i = 0; i < n; ++i) { var x = la[i] - ma, y = lb[i] - mb; sab += x * y; saa += x * x; sbb += y * y; md += Math.abs(la[i] - lb[i]); }
   // color medio por canal (¿cambia el color?)
   var cA = [0, 0, 0], cB = [0, 0, 0]; for (i = 0; i < n; ++i) for (var c = 0; c < 3; ++c) { cA[c] += A[4 * i + c] / n; cB[c] += B[4 * i + c] / n; }
   return { r: sab / Math.sqrt(saa * sbb), mad: md / n, meanView: ma, meanPhoto: mb, rgbView: cA.map(Math.round), rgbPhoto: cB.map(Math.round), w: w, h: h };
};
// (F3c) LA «BOLA»: solo las estrellas (sin nebulosa), el bloque de 32 × 32 px mas brillante (luminancia media) y los pixeles > 180.
// La bola cometa melocoton de F3b eran miles de estrellas del cono apiladas en el punto de fuga: un bloque casi blanco.
FW.test.blob = function() {
   var o = FW.R.opt, v = o.volume, l = o.layers, mw = o.milkyway; o.volume = false; o.layers = false; o.milkyway = false; fwRenderFrame();
   var cv = document.getElementById("gl"), W = cv.width, H = cv.height, c = document.createElement("canvas"); c.width = W; c.height = H;
   var x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(cv, 0, 0); o.volume = v; o.layers = l; o.milkyway = mw;
   var d = x.getImageData(0, 0, W, H).data, B = 32, bw = Math.floor(W / B), bh = Math.floor(H / B), best = 0, nB = 0, bx = 0, by = 0;
   for (var Y = 0; Y < bh; ++Y) for (var X = 0; X < bw; ++X) {
      var s = 0; for (var yy = 0; yy < B; ++yy) for (var xx = 0; xx < B; ++xx) { var k = 4 * ((Y * B + yy) * W + X * B + xx); s += 0.2126 * d[k] + 0.7152 * d[k + 1] + 0.0722 * d[k + 2]; }
      s /= B * B; if (s > best) { best = s; bx = X * B; by = Y * B; }
   }
   for (var i = 0; i < W * H; ++i) if (0.2126 * d[4 * i] + 0.7152 * d[4 * i + 1] + 0.0722 * d[4 * i + 2] > 180) ++nB;
   return { maxBlock: best, at: [bx, by], nBright: nB, W: W, H: H };
};
// (F3c) ¿hay algo en el encuadre? media de luminancia y fraccion de pixeles > 12 de la vista limpia
FW.test.filled = function() {
   fwRenderFrame();
   var cv = document.getElementById("gl"), w = 320, h = Math.round(320 * cv.height / cv.width), c = document.createElement("canvas"); c.width = w; c.height = h;
   var x = c.getContext("2d", { willReadFrequently: true }); x.drawImage(cv, 0, 0, w, h);
   var d = x.getImageData(0, 0, w, h).data, s = 0, n = 0;
   for (var i = 0; i < w * h; ++i) { var L = 0.2126 * d[4 * i] + 0.7152 * d[4 * i + 1] + 0.0722 * d[4 * i + 2]; s += L; if (L > 12) ++n; }
   return { mean: s / (w * h), frac: n / (w * h) };
};
// (F3c) textos visibles de la cabina, la leyenda y la ficha (para buscar ingles en ES y al reves) y las fuentes que usan
FW.test.texts = function() {
   var t = [document.getElementById("ck").textContent, document.getElementById("left").innerText, document.getElementById("legend").innerText, document.getElementById("card").innerText, document.getElementById("radioPanel").innerText].join(" | ");
   var fonts = ["#cardText", "#cardTitle", "#legend", "#radioPanel", "#ck"].map(function(s) { var e = document.querySelector(s); return s + "=" + (e ? getComputedStyle(e).fontFamily : "?"); });
   var bg = getComputedStyle(document.getElementById("card")).backgroundImage;
   return { text: t, fonts: fonts, cardBg: bg, needle: !!FW.ck.needle, disk: FW.ck.disk.getAttribute("transform") };
};
FW.test.lightPhrase = function(d, sig) { return fwLightPhrase(d, sig); };
// ms por fotograma (no depende del vsync): tras pintar se lee UN pixel de la pantalla, que obliga a esperar a que la GPU acabe
// (gl.finish NO espera en Chrome: medido el 4-nov, daba 0,1 ms con 1600×900 y el volumen). n fotogramas del estado actual.
FW.test.bench = function(n, dt, rep) {
   var gl = FW.R.gl, a = [], P = FW.P, px = new Uint8Array(4); rep = rep || 1;
   for (var i = 0; i < n; ++i) { var t = performance.now(); for (var r = 0; r < rep; ++r) { if (dt) fwStep(P, dt); fwRenderFrame(dt || 0); } gl.readPixels(0, 0, 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px); a.push(performance.now() - t); }
   a.sort(function(x, y) { return x - y; });
   var med = a[Math.floor(a.length / 2)], p95 = a[Math.min(a.length - 1, Math.ceil(0.95 * a.length) - 1)];
   return { n: n, medianMs: med, p95Ms: p95, maxMs: a[a.length - 1], fpsMedian: 1000 / med, fpsP95: 1000 / p95, W: FW.R.W, H: FW.R.H };
};
// graba sec segundos con el reloj fijo desde el estado actual (la prueba espera la promesa) -> { frames, seconds, bytes (base64), mode }
FW.test.record = function(sec, kind) {
   var r = FW.rec; FW.noDownload = true; FW.recDiag = { stage: "start" };
   return r.start().then(function(ok) {
      FW.recDiag = { stage: "started", ok: ok, mode: r.mode, codec: r.codec, err: r.err };
      if (!ok) return { ok: false, err: r.err };
      if (kind) fwFly(kind, FW.P.sel);
      var N = Math.round(sec * r.fps), n = 0;
      return new Promise(function(res) {
         function pump() {
            while (n < N && (r.mode !== "webcodecs" || r.enc.encodeQueueSize < 3)) { fwStep(FW.P, 1 / r.fps); fwRenderFrame(1 / r.fps); r.frame(); ++n; }
            FW.recDiag = { stage: "pump", n: n, N: N, queue: r.enc ? r.enc.encodeQueueSize : -1, state: r.enc ? r.enc.state : "", chunks: r.samples.length, err: r.err };
            if (n < N) setTimeout(pump, 2); else res(true);
         }
         pump();
      }).then(function() { FW.recDiag.stage = "stopping"; return r.stop(); }).then(function(out) {
         FW.recDiag.stage = "stopped";
         var b = out.bytes, s = ""; if (b) { for (var i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); }
         return { ok: true, frames: out.frames, seconds: out.seconds, mode: out.mode, size: b ? b.length : out.blob.size, b64: b ? btoa(s) : "" };
      });
   });
};

// la misma grabacion sin esperar la promesa (la prueba sondea FW.recDiag y FW.recResult)
FW.test.recordStart = function(sec, kind) { FW.recResult = null; FW.test.record(sec, kind).then(function(r) { FW.recResult = r; }, function(e) { FW.recResult = { ok: false, err: String(e), diag: FW.recDiag }; }); return true; };

window.addEventListener("load", fwBoot);
