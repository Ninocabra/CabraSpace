// ============================================================================
// FieldVoyager/web/fw_mp4.js — GRABAR VIDEO CON RELOJ FIJO (4-nov-2026, F3; I5)
// ----------------------------------------------------------------------------
// Cada fotograma n se calcula con el reloj de escena t = n/fps (el piloto avanza 1/fps exacto) y se codifica con WebCodecs
// (VideoEncoder, H.264); los trozos se meten en un MP4 escrito aqui mismo (sin bibliotecas: ftyp + mdat + moov con stts/stss/
// stsc/stsz/stco y la caja avcC que da el codificador). Aunque el ordenador vaya justo, no se pierde ni se repite ningun
// fotograma: el video dura exactamente n/fps. Sin WebCodecs (navegadores viejos): MediaRecorder en tiempo REAL (WebM) y se dice.
// Lo que se graba es el lienzo WebGL (la vista limpia, con efectos), no la cabina HTML de encima.
// ES5 (promesas, sin async).
// ============================================================================

function fwBox(type, parts) {
   var n = 8, i; for (i = 0; i < parts.length; ++i) n += parts[i].length;
   var b = new Uint8Array(n), dv = new DataView(b.buffer); dv.setUint32(0, n);
   for (i = 0; i < 4; ++i) b[4 + i] = type.charCodeAt(i);
   var o = 8; for (i = 0; i < parts.length; ++i) { b.set(parts[i], o); o += parts[i].length; }
   return b;
}
function fwU(bytes, vals) { var b = new Uint8Array(bytes.reduce(function(a, c) { return a + c; }, 0)), dv = new DataView(b.buffer), o = 0; for (var i = 0; i < bytes.length; ++i) { var v = vals[i]; if (bytes[i] === 1) dv.setUint8(o, v); else if (bytes[i] === 2) dv.setUint16(o, v); else if (bytes[i] === 4) dv.setUint32(o, v >>> 0); o += bytes[i]; } return b; }
function fwStr(s) { var b = new Uint8Array(s.length); for (var i = 0; i < s.length; ++i) b[i] = s.charCodeAt(i) & 255; return b; }
var FW_MATRIX = fwU([4, 4, 4, 4, 4, 4, 4, 4, 4], [0x00010000, 0, 0, 0, 0x00010000, 0, 0, 0, 0x40000000]);

// samples: [{ data: Uint8Array (AVCC), key }], avcC: Uint8Array, W, H, fps -> Uint8Array (el .mp4)
function fwMp4Mux(samples, avcC, W, H, fps) {
   var ts = fps * 1000, delta = 1000, N = samples.length, dur = N * delta, durMs = Math.round(N * 1000 / fps), i;
   var ftyp = fwBox("ftyp", [fwStr("isom"), fwU([4], [0x200]), fwStr("isomiso2avc1mp41")]);
   var total = 0; for (i = 0; i < N; ++i) total += samples[i].data.length;
   var mdatHead = fwU([4], [total + 8]), mdat = new Uint8Array(total + 8); mdat.set(mdatHead, 0); mdat.set(fwStr("mdat"), 4);
   var o = 8; for (i = 0; i < N; ++i) { mdat.set(samples[i].data, o); o += samples[i].data.length; }
   var chunkOff = ftyp.length + 8;
   var mvhd = fwBox("mvhd", [fwU([4, 4, 4, 4, 4, 4, 2, 2, 4, 4], [0, 0, 0, 1000, durMs, 0x00010000, 0x0100, 0, 0, 0]), FW_MATRIX, new Uint8Array(24), fwU([4], [2])]);
   var tkhd = fwBox("tkhd", [fwU([4, 4, 4, 4, 4, 4, 4, 4, 2, 2, 2, 2], [3, 0, 0, 1, 0, durMs, 0, 0, 0, 0, 0, 0]), FW_MATRIX, fwU([4, 4], [W * 65536, H * 65536])]);
   var mdhd = fwBox("mdhd", [fwU([4, 4, 4, 4, 4, 2, 2], [0, 0, 0, ts, dur, 0x55c4, 0])]);
   var hdlr = fwBox("hdlr", [fwU([4, 4], [0, 0]), fwStr("vide"), new Uint8Array(12), fwStr("VideoHandler\0")]);
   var vmhd = fwBox("vmhd", [fwU([4, 2, 2, 2, 2], [1, 0, 0, 0, 0])]);
   var dinf = fwBox("dinf", [fwBox("dref", [fwU([4, 4], [0, 1]), fwBox("url ", [fwU([4], [1])])])]);
   var comp = new Uint8Array(32); var nm = "FieldVoyager"; comp[0] = nm.length; comp.set(fwStr(nm), 1);
   var avc1 = fwBox("avc1", [new Uint8Array(6), fwU([2, 2, 2, 4, 4, 4, 2, 2, 4, 4, 4, 2], [1, 0, 0, 0, 0, 0, W, H, 0x00480000, 0x00480000, 0, 1]), comp, fwU([2, 2], [0x18, 0xffff]), fwBox("avcC", [avcC])]);
   var stsd = fwBox("stsd", [fwU([4, 4], [0, 1]), avc1]);
   var stts = fwBox("stts", [fwU([4, 4, 4, 4], [0, 1, N, delta])]);
   var keys = []; for (i = 0; i < N; ++i) if (samples[i].key) keys.push(i + 1);
   var stssB = new Uint8Array(8 + 4 * keys.length), dvS = new DataView(stssB.buffer); dvS.setUint32(4, keys.length); for (i = 0; i < keys.length; ++i) dvS.setUint32(8 + 4 * i, keys[i]);
   var stss = fwBox("stss", [stssB]);
   var stsc = fwBox("stsc", [fwU([4, 4, 4, 4, 4], [0, 1, 1, N, 1])]);
   var stszB = new Uint8Array(12 + 4 * N), dvZ = new DataView(stszB.buffer); dvZ.setUint32(8, N); for (i = 0; i < N; ++i) dvZ.setUint32(12 + 4 * i, samples[i].data.length);
   var stsz = fwBox("stsz", [stszB]);
   var stco = fwBox("stco", [fwU([4, 4, 4], [0, 1, chunkOff])]);
   var moov = fwBox("moov", [mvhd, fwBox("trak", [tkhd, fwBox("mdia", [mdhd, hdlr, fwBox("minf", [vmhd, dinf, fwBox("stbl", [stsd, stts, stss, stsc, stsz, stco])])])])]);
   var out = new Uint8Array(ftyp.length + mdat.length + moov.length);
   out.set(ftyp, 0); out.set(mdat, ftyp.length); out.set(moov, ftyp.length + mdat.length);
   return out;
}

// (nA2, E7; Nino: «cuando este renderizando el video que no se pueda hacer nada mas») AL CERRAR EL VIDEO (vaciar el codificador y escribir el MP4)
// la pagina queda inerte: raton, rueda, teclas y toques no llegan a nadie (escuchas en captura sobre window) y una placa dorada fija abajo, siempre en
// el mismo sitio y sin mover la imagen, lo dice. Durante la grabacion el vuelo ES el contenido del video (el visor graba lo que vuelas, a reloj
// fijo): ahi los mandos tienen que seguir vivos. FW_REC_LOCK = false es el CONTROL EN ROJO de las pruebas.
var FW_REC_LOCK = true;
// (9-nov, encargo E · P6) el video lleva los nombres, las constelaciones y la escala que estan encendidos (ver FWRecorder.frame y fwRbRecSource).
// false = ROJO: el video de antes, solo el lienzo GL
var FW_REC_OVERLAY = true;
var FW_REC_LOCK_EVENTS = ["mousedown", "mouseup", "mousemove", "click", "dblclick", "contextmenu", "wheel", "keydown", "keyup", "keypress", "pointerdown", "pointerup", "pointermove", "touchstart", "touchmove", "touchend"];
function fwRecLockInstall(rec) {
   if (rec.lockInstalled || typeof window === "undefined") return;
   rec.lockInstalled = true;
   var swallow = function(e) { if (rec.finalizing && FW_REC_LOCK !== false) { e.stopImmediatePropagation(); if (e.cancelable) e.preventDefault(); rec.swallowed = (rec.swallowed || 0) + 1; } };
   for (var i = 0; i < FW_REC_LOCK_EVENTS.length; ++i) window.addEventListener(FW_REC_LOCK_EVENTS[i], swallow, { capture: true, passive: false });
}
// la placa «codificando el video»: dorada, abajo en el centro (como el aviso de la nave de PixInsight), con una barra que va y viene
function fwRecPlate(on) {
   if (typeof document === "undefined") return;
   var el = document.getElementById("fwRecPlate");
   if (on && !el) {
      el = document.createElement("div"); el.id = "fwRecPlate";
      el.style.cssText = "position:fixed;left:50%;bottom:20px;transform:translateX(-50%);z-index:99999;min-width:min(520px,88vw);padding:12px 22px 14px;background:linear-gradient(135deg,#F3E7C7,#E5D3A3);border:3px solid #B8862E;color:#2A1F15;font:600 13px Georgia,serif;letter-spacing:.08em;text-align:center;pointer-events:none;box-shadow:0 0 0 1px #5E4214 inset,0 6px 24px rgba(0,0,0,.6)";
      var es = (typeof FW_LANG !== "undefined" && FW_LANG === "es");
      el.innerHTML = "<div>" + (es ? "REC · CODIFICANDO EL VÍDEO" : "REC · ENCODING THE VIDEO") + "</div><div style=\"margin:8px 0 2px;height:8px;background:#2A1F15;position:relative;overflow:hidden\"><div id=\"fwRecPlateBar\" style=\"position:absolute;top:1px;bottom:1px;width:30%;background:linear-gradient(#F3D27E,#B8862E)\"></div></div><div style=\"font-weight:400;font-size:11px\">" + (es ? "mandos bloqueados un momento" : "controls locked for a moment") + "</div>";
      document.body.appendChild(el);
      var x = 0, dir = 1; el.tick = setInterval(function() { x += dir * 3; if (x > 70 || x < 0) dir = -dir; var b = document.getElementById("fwRecPlateBar"); if (b) b.style.left = x + "%"; }, 40);
      document.body.style.cursor = "wait";
   } else if (!on && el) { clearInterval(el.tick); el.remove(); document.body.style.cursor = ""; }
}

// EL GRABADOR. canvas: el lienzo WebGL. o: { fps, bitrate }
function FWRecorder(canvas, o) {
   fwRecLockInstall(this); this.finalizing = false; this.swallowed = 0;
   this.canvas = canvas; this.fps = (o && o.fps) || 30; this.bitrate = (o && o.bitrate) || 24e6;
   this.on = false; this.n = 0; this.samples = []; this.avcC = null; this.enc = null; this.mode = ""; this.err = "";
   this.webcodecs = (typeof VideoEncoder === "function" && typeof VideoFrame === "function");
}
// -> Promise(ok)
FWRecorder.prototype.start = function() {
   var self = this; this.n = 0; this.samples = []; this.avcC = null; this.err = "";
   this.W = this.canvas.width & ~1; this.H = this.canvas.height & ~1;
   if (!this.webcodecs) return this.startRealtime();
   var cands = ["avc1.640034", "avc1.4d0034", "avc1.640028", "avc1.42001f"], i = 0;
   function tryNext() {
      if (i >= cands.length) return self.startRealtime();
      var cfg = { codec: cands[i++], width: self.W, height: self.H, bitrate: self.bitrate, framerate: self.fps, avc: { format: "avc" }, latencyMode: "quality" };
      return VideoEncoder.isConfigSupported(cfg).then(function(r) {
         if (!r.supported) return tryNext();
         self.enc = new VideoEncoder({ output: function(chunk, meta) {
               if (meta && meta.decoderConfig && meta.decoderConfig.description && !self.avcC) self.avcC = new Uint8Array(meta.decoderConfig.description.buffer ? meta.decoderConfig.description.buffer.slice(meta.decoderConfig.description.byteOffset || 0, (meta.decoderConfig.description.byteOffset || 0) + meta.decoderConfig.description.byteLength) : meta.decoderConfig.description);
               var b = new Uint8Array(chunk.byteLength); chunk.copyTo(b); self.samples.push({ data: b, key: chunk.type === "key" });
            }, error: function(e) { self.err = String(e); } });
         self.enc.configure(cfg); self.codec = cfg.codec; self.mode = "webcodecs"; self.on = true; return true;
      });
   }
   return tryNext();
};
FWRecorder.prototype.startRealtime = function() {
   var self = this;
   if (typeof MediaRecorder !== "function" || !this.canvas.captureStream) { this.err = "no WebCodecs and no MediaRecorder"; return Promise.resolve(false); }
   this.chunks = []; var st = this.canvas.captureStream(this.fps);
   var mt = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"].filter(function(m) { return MediaRecorder.isTypeSupported(m); })[0] || "";
   this.mr = new MediaRecorder(st, mt ? { mimeType: mt, videoBitsPerSecond: this.bitrate } : {});
   this.mr.ondataavailable = function(e) { if (e.data && e.data.size) self.chunks.push(e.data); };
   this.mr.start(); this.mode = "mediarecorder (real time, frames may drop)"; this.on = true;
   return Promise.resolve(true);
};
// tras pintar el fotograma n (con t = n/fps): lo codifica. Devuelve true si el codificador puede con otro ya
FWRecorder.prototype.frame = function() {
   if (!this.on || this.mode !== "webcodecs") return true;
   // (9-nov, encargo E · P6) con NOMBRES / CONSTEL. / ESCALA encendidos (fw_rightbar.js) el fotograma lleva esos rotulos dibujados encima del GL;
   // FW_REC_OVERLAY = false (o nada encendido) = el lienzo GL tal cual, como antes
   var src = this.canvas;
   if (FW_REC_OVERLAY !== false && typeof fwRbRecSource === "function") src = fwRbRecSource(this) || src;
   var us = Math.round(this.n * 1e6 / this.fps), f = new VideoFrame(src, { timestamp: us, duration: Math.round(1e6 / this.fps) });
   this.enc.encode(f, { keyFrame: this.n % (this.fps * 2) === 0 }); f.close(); ++this.n;
   return this.enc.encodeQueueSize < 3;
};
// -> Promise({ blob, name, mime, frames, seconds, mode })
FWRecorder.prototype.stop = function() {
   var self = this; this.on = false;
   if (FW_REC_LOCK !== false) { this.finalizing = true; fwRecPlate(true); }
   var done = function() { self.finalizing = false; fwRecPlate(false); };
   return this.stop0().then(function(r) { done(); return r; }, function(e) { done(); throw e; });
};
FWRecorder.prototype.stop0 = function() {
   var self = this;
   var stamp = (new Date()).toISOString().replace(/[-:]/g, "").replace("T", "_").substring(0, 15);
   if (this.mode === "webcodecs") return this.enc.flush().then(function() {
      self.enc.close();
      if (!self.avcC) throw new Error("the encoder gave no avcC");
      var mp4 = fwMp4Mux(self.samples, self.avcC, self.W, self.H, self.fps);
      return { blob: new Blob([mp4], { type: "video/mp4" }), bytes: mp4, name: "FieldVoyager_" + stamp + ".mp4", mime: "video/mp4", frames: self.samples.length, seconds: self.samples.length / self.fps, mode: self.mode + " " + self.codec };
   });
   return new Promise(function(res) { self.mr.onstop = function() { var b = new Blob(self.chunks, { type: "video/webm" }); res({ blob: b, name: "FieldVoyager_" + stamp + ".webm", mime: "video/webm", frames: -1, seconds: -1, mode: self.mode }); }; self.mr.stop(); });
};
function fwDownload(blob, name) { var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function() { URL.revokeObjectURL(a.href); a.remove(); }, 4000); }
