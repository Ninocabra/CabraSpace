// ============================================================================
// FieldVoyager/web/fw_amb.js — EL CAMPO DE ESTRELLAS DE FONDO SIMULADO y LA PROTAGONISTA QUE CRECE en el visor (NV-16, 11-nov-2026)
// ----------------------------------------------------------------------------
// El campo es el de PixInsight (src/engine/fv_ambient.js, que va en el paquete): la parte pura (fvAmbBuild, fvAmbVisible, fvAmbRho, fvAmbInQuad,
// fvAmbPhotoPoly) es LA MISMA; lo que hace fvAmbPaint (peso de casa, apagado en el warp, velocidad del fotograma anterior con el reloj de escena,
// mascara de la foto, apagado dentro de la losa con paso bajo MASK_S, reparto de luz de los trazos largos, cabeza un nivel por debajo, 6 colores
// × 6 niveles) se repite aqui regla a regla y se pinta en WebGL, en Add, dentro del destino principal (rt.main) despues de las estrellas: asi lo
// graba REC (fw_mp4.js graba el lienzo WebGL) y queda debajo de la ventana de la nave, del destello y del viñeteado, como en PixInsight.
// Los numeros de lo que pinta (puntos, trazos, posiciones) los compara tests/web/fv_nv16_amb_cdp.js con fvAmbPaint de verdad en node.
// Solo con el laboratorio encendido (FW_LAB.ON / ?lab=1): con ?lab=0 el visor es el de antes, sin campo.
// Se apaga con el mismo interruptor que la Via Lactea de fondo (FW.R.opt.milkyway; en la leyenda, un clic en su fila).
// Diferencias con PixInsight que se saben: el destino es de media precision y pasa por el hombro de tonos del pase final (un punto a tope se
// queda en ~0,9 en vez de 1); las lineas se pintan como tiras con borde suave de 1 px (Qt: antialiasing de su pluma).
// ES5.
// ============================================================================

var FW_AMB = { ON: true, REC_MAX: 900 };
var FW_AMB_BREAK = "";      // control en ROJO de las pruebas: "nomask" = sin la mascara de la foto (SOLO en el visor; la referencia de node la aplica)

// lo que FVPainter.paintLayers deja en stats y leen el campo y la protagonista: wPhoto (peso de la foto como plano), nebOp (opacidad de la nebulosa,
// con el fundido del warp y el de la losa en Espacio) e inSlab (dentro de la losa). Mismas formulas y cifras (FW_GL.PHOTO_FADE, LAB_EDGE_*)
function fwAmbNebStats(sc, P) {
   var N = sc.nebula, o = { wPhoto: 0, nebOp: 0, inSlab: 0 };
   if (!N || !N.layers || !N.layers.length) return o;
   var cam = P.cam, T = fwTiltOf(sc), lk = fvNorm(cam.look), cL = T ? fwTiltInv(cam.pos, T.D, T.t) : cam.pos;
   var wP = 1 - fvSmooth(fvLen(cam.pos) / (FW_GL.PHOTO_FADE * N.distLy));
   var ce = Math.abs(T ? fvDot(lk, T.n) : lk[2]), edge = fvSmooth((ce - FW_GL.LAB_EDGE_LO) / (FW_GL.LAB_EDGE_HI - FW_GL.LAB_EDGE_LO));
   var zA = N.layers[0].z, zB = N.layers[N.layers.length - 1].z, outZ = Math.max(0, zA - cL[2], cL[2] - zB), inW = 1 - fvSmooth(outZ / Math.max(1, N.thickLy));
   edge = Math.max(edge, FW_GL.LAB_EDGE_IN * inW);
   var wFade = 1 - 0.9 * fvSmooth(((typeof fvWarpFadeW === "function") ? fvWarpFadeW(P) : (P.warp || 0)) / 0.6); /* (W1b) */ if (wFade < 0.999) edge *= wFade;
   var nmF = (typeof fvNmSlabFade === "function") ? fvNmSlabFade(P) : 1;
   o.wPhoto = wP; o.inSlab = inW; o.nebOp = (1 - wP) * edge * nmF;
   return o;
}
// lo que fvAmbPhotoPoly pide al pintor (la escena, su inclinacion y el punto en el plano inclinado): las funciones del visor, que son las mismas
function fwAmbPainter(sc) { return { scene: sc, tiltOf: function() { return fwTiltOf(sc); }, planePt: function(L, x, y, T) { return fwTiltPlanePt(L, x, y, T); } }; }

// UN FOTOGRAMA DEL CAMPO (fvAmbPaint sin pintar). W, H = el lienzo en px. -> null | { nPts, pts (x, y redondeados, clave), nSeg, segs (x0, y0, x1, y1,
// clave), amb, ambStreak, ambMasked, w, kq }. clave = color · 6 + nivel. R.amb guarda el estado entre fotogramas (como painter.amb)
function fwAmbFrame(R, P, W, H) {
   var st = { amb: 0, ambStreak: 0, ambMasked: 0, ambW: 0, nPts: 0, nSeg: 0 };
   R.ambLast = st;
   if (!FW_AMB.ON || typeof FV_AMB === "undefined" || !FV_AMB.ON || typeof fvAmbVisible !== "function" || R.opt.milkyway === false || !P || !P.cam || !P.lab || !P.cam.B) return null;
   var A = FV_AMB, sc = R.scene, pr = fvProjector(P.cam, W, H), S = pr.S || 1, c = P.cam.pos, q = [S * c[0], S * c[1], c[2]], t = P.t || 0;
   var a = R.amb; if (!a) a = R.amb = { F: fvAmbBuild(A.N, A.SEED), out: new Float32Array(6 * 4000), pts: new Float32Array(3 * 8000), segs: new Float32Array(5 * 4000), q: null, t: 0, v: [0, 0, 0] };
   if (typeof FW !== "undefined" && FW.ambRec && FW.ambRec.length < FW_AMB.REC_MAX) {   // (pruebas) la pose de cada fotograma, para repetirlo en node
      var B = P.cam.B, sl = function(s) { return s ? { kind: s.kind, i: s.i, arriveLy: s.arriveLy } : null; };
      FW.ambRec.push({ t: t, pos: c.slice(), look: P.cam.look.slice(), fov: P.cam.fov, roll: P.cam.roll || 0, B: { r: B.r.slice(), d: B.d.slice(), f: B.f.slice() }, S: P.cam.S || 1,
                       trail: P.trail || 0, warp: P.warp || 0, flight: P.flight ? { kind: P.flight.kind, sel: sl(P.flight.sel) } : null, sel: sl(P.sel), arrivedAt: sl(P.arrivedAt), navMode: P.navMode || null, W: W, H: H });
   }
   // la velocidad de la camara en vuelo, del fotograma anterior (reloj de escena)
   var vel = null;
   // (E1, 11-nov) como fvAmbPaint: el desplazamiento REAL de la camara con el estirado de ahora, y girar alrededor de una estrella no es viajar
   var oldV = (typeof FV_AMB_BREAK !== "undefined" && FV_AMB_BREAK === "turn");
   if (a.c) { var dt = t - a.t; if (dt > 1e-4 && dt < 0.25) { vel = oldV ? [(q[0] - a.q[0]) / dt, (q[1] - a.q[1]) / dt, (q[2] - a.q[2]) / dt] : [S * (c[0] - a.c[0]) / dt, S * (c[1] - a.c[1]) / dt, (c[2] - a.c[2]) / dt]; a.v = vel; } else if (dt === 0) vel = a.v; }
   a.q = q; a.c = c.slice(); a.t = t;
   if (!oldV && typeof fvAmbTurning === "function" && fvAmbTurning(P)) { vel = null; a.v = [0, 0, 0]; }
   // peso de casa = el de la Via Lactea de fondo (FVPainter.mwWeight; FW_GL.MW_AWAY = FV_PAINT.MW_AWAY) y apagado en el warp
   var dRef = sc.nebula ? sc.nebula.distLy : 1000, w = fvSmooth(fvLen(c) / (FW_GL.MW_AWAY * dRef));
   if (!(P.flight && P.flight.kind !== "warp" && !(typeof fvIsWarpFl === "function" && fvIsWarpFl(P.flight)))) w *= 1 - fvSmooth(((P.trail || 0) - A.WARP_OFF[0]) / (A.WARP_OFF[1] - A.WARP_OFF[0]));
   st.ambW = w;
   if (w < 0.02) return null;
   var rho = fvAmbRho(sc.galaxy, c), o = a.out;
   var n = fvAmbVisible(a.F, q, pr.r, pr.d, pr.fw, pr.f, pr.cx, pr.cy, pr.W, pr.H, vel, rho, w * A.GAIN, o);
   // la foto en pantalla (si se pinta: foto como plano o nebulosa): dentro no hay campo
   var ns = fwAmbNebStats(sc, P), PQ = null, mPx = A.PHOTO_MASK * pr.W, nebOn = ns.nebOp > 0.01 || ns.wPhoto > 0.02;
   if (A.PHOTO_MASK > 0 && nebOn && FW_AMB_BREAK !== "nomask") { try { PQ = fvAmbPhotoPoly(fwAmbPainter(sc), pr); } catch (eQ) { PQ = null; } }
   // dentro de la losa se apaga entero, con paso bajo de MASK_S s
   var tq = (A.PHOTO_MASK > 0) ? 1 - fvClamp(ns.inSlab || 0, 0, 1) : 1, dtq = a.tq === undefined ? 0 : t - a.tq;
   if (a.kq === undefined || !(dtq >= 0 && dtq < 0.5)) a.kq = tq; else if (dtq > 0) a.kq += (tq - a.kq) * (1 - Math.exp(-dtq / A.MASK_S));
   a.tq = t; st.kq = a.kq;
   var kq = a.kq, nP = 0, nS = 0, nMask = 0, np = 0, pts = a.pts, segs = a.segs;
   if (kq < 0.02) { st.ambMasked = n; return st; }
   for (var i = 0; i < n; ++i) {
      var j = 6 * i, sx = o[j], sy = o[j + 1], lx = o[j + 2] - sx, ly = o[j + 3] - sy, ll = Math.sqrt(lx * lx + ly * ly), Ii = o[j + 4] * kq;
      if (Ii < A.I_MIN) continue;
      if (PQ) { var km = fvAmbInQuad(PQ, sx, sy, mPx); if (km > 0) { Ii *= 1 - km; ++nMask; if (Ii < A.I_MIN) continue; } }
      if (ll > A.STREAK_DIM) Ii *= Math.sqrt(A.STREAK_DIM / ll);
      var lev = Math.min(5, Math.floor(Ii * 6)), cl = o[j + 5], key = cl * 6 + lev;
      if (ll >= A.STREAK_MIN) {
         var m5 = 5 * nS; segs[m5] = sx; segs[m5 + 1] = sy; segs[m5 + 2] = o[j + 2]; segs[m5 + 3] = o[j + 3]; segs[m5 + 4] = key; ++nS;
         pts[3 * np] = Math.round(sx); pts[3 * np + 1] = Math.round(sy); pts[3 * np + 2] = cl * 6 + Math.max(0, lev - 1); ++np;   // la cabeza, un nivel por debajo
      } else { pts[3 * np] = Math.round(sx); pts[3 * np + 1] = Math.round(sy); pts[3 * np + 2] = key; ++np; ++nP; }
   }
   st.amb = nP; st.ambStreak = nS; st.ambMasked = nMask; st.nPts = np; st.nSeg = nS; st.pts = pts; st.segs = segs;
   return st;
}

// ---------------------------------------------------------------------------
// EL PINTOR EN WebGL: los 36 puntos de fvAmbPaint en un atlas (mismos pixeles: min(255, round(color · I · gauss))) pintados como puntos de 3 o 5 px
// centrados en el pixel (round(x), round(y)), y los trazos como tiras con su pluma (color · Ip, ancho 1 o 1,3) y borde suave. Todo en Add
// ---------------------------------------------------------------------------
var FW_SH_AMB_PV = [
"precision highp float;",
"in vec3 position;",
"uniform vec2 uRes;",
"flat out float vKey; flat out float vSz;",
"void main() {",
"  vKey = position.z; float lev = mod(position.z, 6.0); vSz = lev > 2.5 ? 5.0 : 3.0; gl_PointSize = vSz;",
"  gl_Position = vec4((position.x + 0.5) / uRes.x * 2.0 - 1.0, 1.0 - (position.y + 0.5) / uRes.y * 2.0, 0.0, 1.0);",
"}"].join("\n");
var FW_SH_AMB_PF = [
"precision highp float;",
"flat in float vKey; flat in float vSz;",
"uniform sampler2D uAtlas;",
"layout(location = 0) out vec4 oC;",
"void main() {",
"  vec2 pc = min(floor(gl_PointCoord * vSz), vec2(vSz - 1.0));",
"  oC = vec4(texture(uAtlas, (vec2(vKey * 5.0 + pc.x, pc.y) + 0.5) / vec2(180.0, 5.0)).rgb, 1.0);",
"}"].join("\n");
var FW_SH_AMB_LV = [
"precision highp float;",
"in vec3 position; in vec4 aSeg; in vec4 aCol;",
"uniform vec2 uRes;",
"out vec4 vSeg; out vec4 vCol;",
"void main() { vSeg = aSeg; vCol = aCol; gl_Position = vec4(position.x / uRes.x * 2.0 - 1.0, 1.0 - position.y / uRes.y * 2.0, 0.0, 1.0); }"].join("\n");
var FW_SH_AMB_LF = [
"precision highp float;",
"in vec4 vSeg; in vec4 vCol;",
"uniform vec2 uRes;",
"layout(location = 0) out vec4 oC;",
"void main() {",
"  vec2 p = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y), a = vSeg.xy, ab = vSeg.zw - vSeg.xy;",
"  float h = clamp(dot(p - a, ab) / max(dot(ab, ab), 1e-6), 0.0, 1.0), d = length(p - a - ab * h);",
"  oC = vec4(vCol.rgb * clamp(vCol.w + 0.5 - d, 0.0, 1.0), 1.0);",
"}"].join("\n");
function fwAmbGlInit(R) {
   var T = THREE, g = {}, A = FV_AMB;
   // el atlas: 36 celdas de 5 × 5 (los de 3 × 3 arriba a la izquierda de su celda)
   var at = new Uint8Array(4 * 180 * 5); g.pen = new Float32Array(4 * 36);
   for (var ci = 0; ci < 6; ++ci) for (var lv = 0; lv < 6; ++lv) {
      var key = ci * 6 + lv, big = lv >= 3, sz = big ? 5 : 3, h = (sz - 1) / 2, I = [0.2, 0.32, 0.48, 0.5, 0.72, 1][lv], sg = big ? [0.95, 1.1, 1.3][lv - 3] : 0.62, cc = FV_AMB_COL[ci];
      for (var y = 0; y < sz; ++y) for (var x = 0; x < sz; ++x) {
         var v = I * Math.exp(-((x - h) * (x - h) + (y - h) * (y - h)) / (2 * sg * sg)), k = 4 * (y * 180 + key * 5 + x);
         at[k] = Math.min(255, Math.round(cc[0] * v)); at[k + 1] = Math.min(255, Math.round(cc[1] * v)); at[k + 2] = Math.min(255, Math.round(cc[2] * v)); at[k + 3] = 255;
      }
      var Ip = [0.1, 0.15, 0.21, 0.28, 0.36, 0.45][lv];
      g.pen[4 * key] = Math.round(cc[0] * Ip) / 255; g.pen[4 * key + 1] = Math.round(cc[1] * Ip) / 255; g.pen[4 * key + 2] = Math.round(cc[2] * Ip) / 255; g.pen[4 * key + 3] = 0.5 * (lv >= 4 ? 1.3 : 1);
   }
   var tex = new T.DataTexture(at, 180, 5, T.RGBAFormat, T.UnsignedByteType); tex.magFilter = tex.minFilter = T.NearestFilter; tex.generateMipmaps = false; tex.flipY = false; tex.needsUpdate = true;
   g.uRes = { value: new T.Vector2(R.W, R.H) };
   var common = { glslVersion: T.GLSL3, depthTest: false, depthWrite: false, blending: T.AdditiveBlending, transparent: true };
   g.pGeo = new T.BufferGeometry(); g.pPos = new T.BufferAttribute(new Float32Array(3 * 8000), 3); g.pPos.setUsage(T.DynamicDrawUsage); g.pGeo.setAttribute("position", g.pPos);
   g.points = new T.Points(g.pGeo, new T.RawShaderMaterial(Object.assign({ vertexShader: FW_SH_AMB_PV, fragmentShader: FW_SH_AMB_PF, uniforms: { uRes: g.uRes, uAtlas: { value: tex } } }, common)));
   g.points.frustumCulled = false;
   var NV = 6 * 4000;
   g.lGeo = new T.BufferGeometry(); g.lPos = new T.BufferAttribute(new Float32Array(3 * NV), 3); g.lSeg = new T.BufferAttribute(new Float32Array(4 * NV), 4); g.lCol = new T.BufferAttribute(new Float32Array(4 * NV), 4);
   [g.lPos, g.lSeg, g.lCol].forEach(function(b) { b.setUsage(T.DynamicDrawUsage); });
   g.lGeo.setAttribute("position", g.lPos); g.lGeo.setAttribute("aSeg", g.lSeg); g.lGeo.setAttribute("aCol", g.lCol);
   g.lines = new T.Mesh(g.lGeo, new T.RawShaderMaterial(Object.assign({ vertexShader: FW_SH_AMB_LV, fragmentShader: FW_SH_AMB_LF, uniforms: { uRes: g.uRes } }, common)));
   g.lines.frustumCulled = false;
   g.scene = new T.Scene(); g.scene.add(g.lines); g.scene.add(g.points);
   return g;
}
// lo llama FWRenderer.render despues de las estrellas cercanas, con rt.main de destino
function fwAmbGl(R, P) {
   var L = fwAmbFrame(R, P, R.W, R.H);
   if (!L || !(L.nPts + L.nSeg)) return;
   var g = R.ambG || (R.ambG = fwAmbGlInit(R)), i;
   g.uRes.value.set(R.W, R.H);
   var pa = g.pPos.array; for (i = 0; i < 3 * L.nPts; ++i) pa[i] = L.pts[i];
   g.pPos.needsUpdate = true; g.pGeo.setDrawRange(0, L.nPts);
   var la = g.lPos.array, ls = g.lSeg.array, lc = g.lCol.array, s = L.segs, PN = g.pen;
   for (i = 0; i < L.nSeg; ++i) {
      var x0 = s[5 * i], y0 = s[5 * i + 1], x1 = s[5 * i + 2], y1 = s[5 * i + 3], key = s[5 * i + 4], hw = PN[4 * key + 3], dx = x1 - x0, dy = y1 - y0, ln = Math.sqrt(dx * dx + dy * dy) || 1;
      var ux = dx / ln, uy = dy / ln, e = hw + 1, nx = -uy * e, ny = ux * e, ax = x0 - ux * e, ay = y0 - uy * e, bx = x1 + ux * e, by = y1 + uy * e;
      var C = [ax + nx, ay + ny, bx + nx, by + ny, bx - nx, by - ny, ax + nx, ay + ny, bx - nx, by - ny, ax - nx, ay - ny];
      for (var v = 0; v < 6; ++v) {
         var o3 = 3 * (6 * i + v), o4 = 4 * (6 * i + v);
         la[o3] = C[2 * v]; la[o3 + 1] = C[2 * v + 1]; la[o3 + 2] = 0;
         ls[o4] = x0; ls[o4 + 1] = y0; ls[o4 + 2] = x1; ls[o4 + 3] = y1;
         lc[o4] = PN[4 * key]; lc[o4 + 1] = PN[4 * key + 1]; lc[o4 + 2] = PN[4 * key + 2]; lc[o4 + 3] = hw;
      }
   }
   g.lPos.needsUpdate = g.lSeg.needsUpdate = g.lCol.needsUpdate = true; g.lGeo.setDrawRange(0, 6 * L.nSeg);
   R.r.setRenderTarget(R.rt.main); R.r.render(g.scene, R.cam);
}

// ---------------------------------------------------------------------------
// LA PROTAGONISTA DE PixInsight con el laboratorio: FVPainter.heroOf (crece antes de llegar: magnitud ≤ HERO_MAG − 1,5·(1 − pr0)) y paintHero con
// HERO_NEAR (× K desde FROM veces la distancia de llegada, menos sobre la foto: ON_PHOTO; variante «suave» del sprite). Cifras: FW_GL.HERO_NEAR
// (copia de FV_PAINT.HERO_NEAR; la prueba fv_nv16_amb_cdp.js comprueba que no se separan). -> null | { i, m, w, rr (px de PixInsight a 1080 de
// alto), soft, kN, kPh }
// ---------------------------------------------------------------------------
function fwHeroPi(sc, P, pr) {
   var sel = (P.flight && P.flight.sel && P.flight.sel.kind === "star") ? P.flight.sel : ((P.arrivedAt && P.arrivedAt.kind === "star") ? P.arrivedAt : ((P.sel && P.sel.kind === "star") ? P.sel : null));
   if (!sel && P.lab) {
      var so = (P.flight && P.flight.sel) || P.arrivedAt || P.sel, Ob = so && so.kind === "object" && sc.objects ? sc.objects[so.i] : null;
      if (Ob && Ob.star >= 0) sel = { kind: "star", i: Ob.star, arriveLy: (typeof fvObjectTarget === "function" && fvObjectTarget(sc, so.i)) ? fvObjectTarget(sc, so.i).arriveLy : 0 };
   }
   if (!sel) return null;
   var S = sc.stars, i = sel.i, G = FW_GL, dc = fvLen(fvSub(fvStarPos(sc, i), P.cam.pos)), m = fvApparentMag(S.g[i], S.dEarth[i], dc);
   if (P.lab && typeof fvArriveDist === "function") { var dA = fvArriveDist(P, sel), pr0 = fvClamp(Math.log(Math.max(dc, 1e-9) / Math.max(dA, 1e-9)) / Math.log(300), 0, 1); m = Math.min(m, G.HERO_MAG - 1.5 * (1 - pr0)); }
   if (m >= G.HERO_MAG) return null;
   var w = fvSmooth((G.HERO_MAG - m) / 1.5), p = pr.project(fvStarPos(sc, i));
   if (!p) return null;
   var rr = Math.min(G.HERO_MAX, G.HERO_R0 * Math.pow(2, 0.4 * (G.HERO_MAG - m))) * (0.35 + 0.65 * w), HN = G.HERO_NEAR, kN = 0, kPh = 0;
   if (HN && HN.ON && HN.K > 1 && typeof fvArriveDist === "function") {
      var selH = (P.flight && P.flight.sel && P.flight.sel.kind === "star" && P.flight.sel.i === i) ? P.flight.sel : ((P.arrivedAt && P.arrivedAt.kind === "star" && P.arrivedAt.i === i) ? P.arrivedAt : { kind: "star", i: i });
      var dAh = fvArriveDist(P, selH);
      kN = fvSmooth(1 - Math.log(Math.max(dc, 1e-9) / Math.max(dAh, 1e-9)) / Math.log(HN.FROM));
      var ns = fwAmbNebStats(sc, P);
      if (typeof fvAmbInQuad === "function" && (ns.nebOp > 0.01 || ns.wPhoto > 0.02)) { var pq = fvAmbPhotoPoly(fwAmbPainter(sc), pr); if (pq) kPh = fvAmbInQuad(pq, p[0], p[1], 0.05 * pr.W); }
      rr = Math.min(HN.MAX, rr * (1 + (HN.K - 1) * kN * (1 - HN.ON_PHOTO * kPh)));
   }
   return { i: i, m: m, w: w, rr: rr, soft: kN > 0, kN: kN, kPh: kPh, x: p[0], y: p[1] };
}
