// ============================================================================
// FieldVoyager/web/fw_time.js — LA MAQUINA DEL TIEMPO en el visor del navegador (encargo I4, 4-nov-2026)
// ----------------------------------------------------------------------------
// El motor es el MISMO que el de PixInsight: engine/fv_time.js (copiado al paquete con el resto de engine/; puro, sin DOM). Aqui solo
// lo que es del navegador: el estado (el año elegido), el enlace con el mando AETAS de la cabina (fw_cockpit.js llama a fwTimeSet) y el
// aviso a quien tenga que volver a pintar (fwTimeOn). Sin el motor cargado no hace nada (el mando sale «sin datos»).
//
// PARA EL PINTOR (lo engancha el dueño de fw_gl.js / fw_viewer.js; NO se hace aqui):
//   · donde se leen las posiciones de las estrellas para cada fotograma (S.x[i], S.y[i], S.z[i] de scene.stars), usar
//         var S = fwTimeStars(scene);
//     g y dEarth NO cambian (fvApparentMag con la distancia de la camara a la posicion nueva ya da el brillo bueno).
//   · y, si las posiciones se suben a la GPU una sola vez, volver a subirlas al cambiar de año:
//         fwTimeOn(function() { <rehacer el buffer de posiciones>; <pedir un fotograma> });
// ES5.
// ============================================================================

var FW_TIME = { years: 0, listeners: [], last: null };

// el año elegido (desde la fecha de la foto). done = el usuario ha soltado la palanca. -> la vista de estrellas de ese año
function fwTimeSet(scene, years, done) {
   FW_TIME.years = years || 0;
   var V = (typeof fvTimeApply === "function" && scene) ? fvTimeApply(scene, FW_TIME.years) : (scene ? scene.stars : null);
   FW_TIME.last = { years: FW_TIME.years, done: !!done, t: (typeof performance !== "undefined") ? performance.now() : Date.now() };
   for (var i = 0; i < FW_TIME.listeners.length; ++i) { try { FW_TIME.listeners[i](FW_TIME.years, V, !!done); } catch (e) { if (typeof console !== "undefined") console.error("fwTimeOn: " + e); } }
   return V;
}
// las estrellas que hay que pintar (las de hoy si no hay motor o el año es 0)
function fwTimeStars(scene) { return (typeof fvTimeStars === "function") ? fvTimeStars(scene) : (scene ? scene.stars : null); }
// avisar cuando cambie el año: fn(years, vista, soltada)
function fwTimeOn(fn) { if (typeof fn === "function") FW_TIME.listeners.push(fn); }

// ============================================================================
// (I3, 19-nov-2026) EL MANDO DEL TIEMPO VISIBLE Y AETAS CON PROPOSITO en el navegador, gemelo de PixInsight (src/ui/fv_cockpit.js y
// src/ui/fv_trails.js). Nino: «El botón que hace mover las estrellas para delante y para atrás debe estar más visible y tiene que tener al
// lado una flecha play para arriba y otra play para abajo que recorra hacia el futuro y hacia el pasado de forma automática y visualmente
// agradable.»
//   · la REPRODUCCION: el estado es fvTplay* del motor (engine/fv_time.js); los botones ▲ ▼ de la cabina (fw_cockpit.js) llaman a
//     fwTimePlayPress(dir) y cada fotograma fwTimeFrame() la avanza con el reloj de la escena (P.t: en una grabacion sale igual);
//   · las ESTELAS de ±100 000 años, la PLACA del año y los ROTULOS de lo notable, en el lienzo del HUD (#hud), con los mismos criterios,
//     colores, grosores y textos que PixInsight (fvTrailsBuild, fvTrailsLabel… del motor).
// FW_E1T = false: el visor de antes (sin botones, sin estelas, sin placa).
// (F2, 20-nov) ?run=0 apaga la estrella fugitiva (estela dorada, flecha, rotulo, ficha, AENIGMA: engine/fv_runaway.js) y ?gal=0 el interruptor SOL | GALAXIA del mando AETAS.
// ============================================================================
var FW_E1T = true;
(function() { try { var q = /[?&]run=([01])/.exec(location.search), g = /[?&]gal=([01])/.exec(location.search); if (q && typeof FV_RUNAWAY !== "undefined") FV_RUNAWAY.ON = q[1] === "1"; if (g && typeof FV_TIME !== "undefined") FV_TIME.GAL_ON = g[1] === "1"; } catch (e) {} })();
var FW_TRAILS_UI = { COL: { cross: [229, 181, 63], group: [244, 234, 210], run: [255, 210, 90] }, SEGS: 8, W_WAKE: 1.5, W_GROUP: 1.15, W_RUN: 2.4, W_AHEAD: 0.85, RING: 3.4, HEAD: 1.8, ARROW: 28, MARGIN: 60,
                     PLATE_Y: 18, LABEL_PX: 11, LABEL_MAX: 4 };
function fwE1tOn() { return FW_E1T === true && typeof fvTplayNew === "function" && typeof fvTrailsBuild === "function"; }
function fwTimePlayState() { if (!FW_TIME.play && fwE1tOn()) FW_TIME.play = fvTplayNew(); return FW_TIME.play || null; }
// pulsar ▲ (dir +1) o ▼ (dir −1) -> "start" | "pause" | "none"
function fwTimePlayPress(dir) {
   var st = fwTimePlayState(); if (!st) return "none";
   var r = fvTplayPress(st, dir, FW_TIME.years); FW_TIME.playT = null;
   if (typeof FW !== "undefined" && FW.ck && FW.ck.aetasKeysSync) FW.ck.aetasKeysSync();
   return r;
}
// cortar en seco (la palanca o la lectura mandan)
function fwTimePlayStop() { var st = FW_TIME.play; if (st && st.on) { fvTplayHardStop(st, FW_TIME.years); if (typeof FW !== "undefined" && FW.ck && FW.ck.aetasKeysSync) FW.ck.aetasKeysSync(); } }
// un paso de la reproduccion (dt en segundos) -> true si movio la escena. Lo llama fwTimeFrame; las pruebas, a mano
function fwTimePlayStep(dt) {
   var st = FW_TIME.play; if (!st || !st.on || typeof FW === "undefined" || !FW.ck) return false;
   var y = fvTplayStep(st, dt);
   FW.ck.setEpoch(y, true, !st.on);
   return true;
}
function fwTimeRgba(c, a) { return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + Math.max(0, Math.min(1, a)).toFixed(3) + ")"; }
// recorte de un segmento a la vista con margen (Liang–Barsky), como fvTrailsClip de PixInsight
function fwTimeClip(x0, y0, x1, y1, W, H, m) {
   var t0 = 0, t1 = 1, dx = x1 - x0, dy = y1 - y0, p = [-dx, dx, -dy, dy], q = [x0 + m, W + m - x0, y0 + m, H + m - y0];
   for (var i = 0; i < 4; ++i) {
      if (p[i] === 0) { if (q[i] < 0) return null; }
      else { var r = q[i] / p[i]; if (p[i] < 0) { if (r > t1) return null; if (r > t0) t0 = r; } else { if (r < t0) return null; if (r < t1) t1 = r; } }
   }
   return [x0 + t0 * dx, y0 + t0 * dy, x0 + t1 * dx, y0 + t1 * dy];
}
function fwTimeProj(W, H) {
   if (typeof fwRbProj === "function") return fwRbProj(W, H);
   var P = FW.P, rc = (typeof fwRenderCam === "function") ? fwRenderCam(P) : null;
   return fvProjector((rc && rc.cam) ? rc.cam : P.cam, W, H);
}
// CADA FOTOGRAMA (lo llama fwOverlay, despues de limpiar el HUD): avanza la reproduccion y pinta estelas, placa y rotulos
function fwTimeFrame(now) {
   FW_TIME.stats = null;
   if (!fwE1tOn() || typeof FW === "undefined" || !FW.P || !FW.scene || !FW.scene.stars) return;
   var P = FW.P, sc = FW.scene, st = fwTimePlayState();
   if (st && st.on) {
      var tNow = (typeof P.t === "number") ? P.t : now / 1000, dt = (FW_TIME.playT === null || FW_TIME.playT === undefined) ? 1 / 60 : tNow - FW_TIME.playT;
      FW_TIME.playT = tNow;
      if (dt > 0) fwTimePlayStep(dt);
      if (!st.on && FW.ck && FW.ck.aetasKeysSync) FW.ck.aetasKeysSync();
   } else FW_TIME.playT = null;
   var T = sc.time; if (!T || !T.years) return;
   var years = T.years, aT = fvTrailsAlpha(years); if (aT < 0.01) return;
   var hud = document.getElementById("hud"); if (!hud) return;
   var g = hud.getContext("2d"), W = FW.VW, H = FW.VH, dpr = hud.width / Math.max(1, W), U = FW_TRAILS_UI, k = Math.max(0.62, Math.min(4, W / 1280)), pr = fwTimeProj(W, H);
   var Tr = fvTrailsBuild(sc), S = sc.stars, R = FV_TIME.RANGE_YR, m = U.MARGIN, nLines = 0, nHeads = 0, nRings = 0, nItems = 0, nArrows = 0, i, s;
   var a0 = aT * (1 - fvSmooth((P.trail || 0) / 0.2));
   g.save(); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.lineCap = "butt";
   // ---- las estelas ----
   if (Tr && a0 >= 0.01) for (i = 0; i < Tr.items.length; ++i) {
      var it = Tr.items[i], col = U.COL[it.cls], grp = (it.cls === "group"), run = (it.cls === "run"), j = it.i, path = [], done = false, any = false, kk;
      var at = function(t, isNow) { path.push({ t: t, q: pr.project([S.x[j] + T.vx[j] * t, S.y[j] + T.vy[j] * t, S.z[j] + T.vz[j] * t]), now: !!isNow }); };
      for (kk = 0; kk <= U.SEGS; ++kk) {
         var t = -R + 2 * R * kk / U.SEGS;
         if (!done && years < t - 1e-6) { at(years, true); done = true; }
         if (!done && Math.abs(years - t) <= 1e-6) { at(t, true); done = true; continue; }
         at(t, false);
      }
      for (s = 0; s + 1 < path.length; ++s) {
         var A = path[s], B = path[s + 1]; if (!A.q || !B.q) continue;
         var c = fwTimeClip(A.q[0], A.q[1], B.q[0], B.q[1], W, H, m); if (!c) continue;
         var tm = 0.5 * (A.t + B.t), wake = fvTrailsInWake(tm, years), al = a0 * fvTrailsSegAlpha(tm, years) * (grp ? 0.85 : 1);
         g.strokeStyle = fwTimeRgba(col, run ? Math.min(1, al * 1.15) : al); g.lineWidth = Math.max(1, (wake ? (grp ? U.W_GROUP : (run ? U.W_RUN : U.W_WAKE)) : U.W_AHEAD) * k);
         g.beginPath(); g.moveTo(c[0], c[1]); g.lineTo(c[2], c[3]); g.stroke(); ++nLines; any = true;
      }
      if (any) ++nItems;
      for (s = 0; s < path.length; ++s) {
         var q = path[s].q; if (!q || q[0] < -m || q[1] < -m || q[0] > W + m || q[1] > H + m) continue;
         if (path[s].now) { g.fillStyle = fwTimeRgba(col, 0.95 * a0); g.beginPath(); g.arc(q[0], q[1], Math.max(1.4, U.HEAD * k), 0, 2 * Math.PI); g.fill(); ++nHeads; }
         else if (path[s].t === 0 && !grp) { g.strokeStyle = fwTimeRgba(col, 0.7 * a0); g.lineWidth = Math.max(1, 0.9 * k); g.beginPath(); g.arc(q[0], q[1], U.RING * k, 0, 2 * Math.PI); g.stroke(); ++nRings; }   // el aro de HOY
      }
      if (run) {                                                                         // (F2) la flecha de velocidad peculiar: hacia donde corre respecto a la Galaxia, con la cabeza en el año elegido
         var ar = fvTrailsRunDir(sc, T, pr, j, years);
         if (ar && ar.q[0] > -m && ar.q[1] > -m && ar.q[0] < W + m && ar.q[1] < H + m) {
            var a1x = ar.q[0] + ar.d[0] * 8 * k, a1y = ar.q[1] + ar.d[1] * 8 * k, a2x = ar.q[0] + ar.d[0] * (8 + U.ARROW) * k, a2y = ar.q[1] + ar.d[1] * (8 + U.ARROW) * k, hl = 6.5 * k, hw = 3.4 * k;
            g.strokeStyle = fwTimeRgba(col, a0); g.lineWidth = Math.max(1.2, 1.7 * k); g.beginPath(); g.moveTo(a1x, a1y); g.lineTo(a2x, a2y); g.stroke();
            g.fillStyle = fwTimeRgba(col, a0); g.beginPath(); g.moveTo(a2x + ar.d[0] * hl * 0.55, a2y + ar.d[1] * hl * 0.55);
            g.lineTo(a2x - ar.d[0] * hl * 0.45 - ar.d[1] * hw, a2y - ar.d[1] * hl * 0.45 + ar.d[0] * hw); g.lineTo(a2x - ar.d[0] * hl * 0.45 + ar.d[1] * hw, a2y - ar.d[1] * hl * 0.45 - ar.d[0] * hw); g.closePath(); g.fill(); ++nArrows;
         }
      }
   }
   // ---- la placa del año y los rotulos (en unidades del HUD: 1280 de ancho de referencia) ----
   g.scale(k, k); g.globalAlpha = aT;
   var Wk = W / k, Hk = H / k, L = (typeof FW_LANG !== "undefined") ? FW_LANG : "en";
   var font = function(kind, px, ls) { return (typeof fwRbFont === "function") ? fwRbFont(kind, px, ls) : { css: px + "px Georgia,serif", px: px, ls: ls || 0 }; };
   var use = function(f) { if (typeof fwRbUseFont === "function") fwRbUseFont(g, f); else g.font = f.css; };
   var wid = function(f, tx) { use(f); return g.measureText(tx).width; };
   var fA = font("display", 11, 3), fY = font("display", 19, 1), fL = font("serif", 10.5, 0), txt = fvTimeText(years, L), leg = fvTrailsLegend(sc, L);
   var tagM = fvTimeModeTag(sc, L), wA = wid(fA, "AETAS"), wY = Math.max(wid(fY, fvTimeText(-1e5, L)), wid(fY, fvTimeText(1e5, L))), wM = tagM ? 16 + wid(fA, tagM) : 0, row1 = wA + 14 + wY + wM, row2 = 0, lw = [];
   for (i = 0; i < leg.length; ++i) { lw.push(22 + wid(fL, leg[i].text)); row2 += lw[i] + (i ? 14 : 0); }
   var w = Math.round(Math.max(row1, row2) + 36), h = leg.length ? 54 : 36, x0 = Math.round((Wk - w) / 2), y0 = U.PLATE_Y, x1 = x0 + w, y1 = y0 + h;
   g.fillStyle = "rgba(17,13,9,0.816)"; g.fillRect(x0, y0, w, h);
   g.strokeStyle = "#C99A3A"; g.lineWidth = 1; g.strokeRect(x0 + 0.5, y0 + 0.5, w - 1, h - 1);
   g.strokeStyle = "rgba(201,154,58,0.44)"; g.lineWidth = 0.6; g.strokeRect(x0 + 3.5, y0 + 3.5, w - 7, h - 7);
   var xr = x0 + (w - row1) / 2;
   g.textBaseline = "alphabetic"; g.textAlign = "left";
   use(fA); g.fillStyle = "#E5B53F"; g.fillText("AETAS", xr, y0 + 24);
   use(fY); g.fillStyle = "#FBF2E0"; g.fillText(txt, xr + wA + 14 + (wY - g.measureText(txt).width) / 2, y0 + 26);
   if (tagM) { use(fA); g.fillStyle = "#E5B53F"; g.fillText(tagM, xr + wA + 14 + wY + 16, y0 + 24); }      // (F2) «GALAXY»: las estrellas se mueven respecto a la Galaxia
   if (leg.length) {
      var xl = x0 + (w - row2) / 2;
      for (i = 0; i < leg.length; ++i) {
         g.strokeStyle = fwTimeRgba(U.COL[leg[i].cls], 1); g.lineWidth = 1.6; g.beginPath(); g.moveTo(xl, y0 + 41.5); g.lineTo(xl + 16, y0 + 41.5); g.stroke();
         use(fL); g.fillStyle = "#D0C1A5"; g.fillText(leg[i].text, xl + 22, y0 + 45);
         xl += lw[i] + 14;
      }
   }
   var plate = [x0 * k, y0 * k, x1 * k, y1 * k], labels = [], notes = fvTrailsNotes(sc), fN = font("serif", U.LABEL_PX, 0), used = [[x0 - 6, y0 - 6, x1 + 6, y1 + 6]];
   // la ficha (DOM) tapa: los rotulos la esquivan
   try {
      var cd = FW.ck && FW.ck.card;
      if (cd && cd.style.display === "block") { var hr = hud.getBoundingClientRect(), cr = cd.getBoundingClientRect(), sx = W / Math.max(1, hr.width) / k; used.push([(cr.left - hr.left) * sx, (cr.top - hr.top) * sx, (cr.right - hr.left) * sx, (cr.bottom - hr.top) * sx]); }
   } catch (eC) {}
   var hit = function(r) { for (var u2 = 0; u2 < used.length; ++u2) { var o = used[u2]; if (!(r[2] <= o[0] || o[2] <= r[0] || r[3] <= o[1] || o[3] <= r[1])) return true; } return false; };
   var inV = function(q2) { return !!(q2 && q2[0] > 8 && q2[1] > 8 && q2[0] < Wk - 8 && q2[1] < Hk - 8); };
   for (i = 0; i < notes.length && i < U.LABEL_MAX; ++i) {
      var nt = notes[i], jn = nt.i, ncol = U.COL[nt.kind];
      var qh = pr.project([S.x[jn] + T.vx[jn] * years, S.y[jn] + T.vy[jn] * years, S.z[jn] + T.vz[jn] * years]), qn = qh ? [qh[0] / k, qh[1] / k] : null, onHead = inV(qn);
      if (!onHead) {
         qh = pr.project([S.x[jn], S.y[jn], S.z[jn]]); qn = qh ? [qh[0] / k, qh[1] / k] : null;
         if (!inV(qn)) {
            // ni la estrella ni su aro de hoy estan a la vista: el punto de su estela que se ve mas cercano al año elegido
            var bestT = 1e30; qn = null;
            for (var ts = 0; ts <= 64; ++ts) { var tt = -R + 2 * R * ts / 64, qq = pr.project([S.x[jn] + T.vx[jn] * tt, S.y[jn] + T.vy[jn] * tt, S.z[jn] + T.vz[jn] * tt]), qk = qq ? [qq[0] / k, qq[1] / k] : null; if (inV(qk) && Math.abs(tt - years) < bestT) { bestT = Math.abs(tt - years); qn = qk; } }
            if (!qn) continue;
         }
      }
      var full = fvTrailsLabel(nt, L), maxW = Math.max(120, Wk * 0.42), sTx = full; use(fN);
      if (g.measureText(sTx).width > maxW) { while (sTx.length > 4 && g.measureText(sTx + "…").width > maxW) sTx = sTx.substring(0, sTx.length - 1); sTx += "…"; }
      var tw = g.measureText(sTx).width, th = 16, right = (qn[0] + 16 + tw + 10 < Wk), lx = right ? qn[0] + 16 : qn[0] - 16 - tw, ly = qn[1] - 22, tries = 0;
      if (ly < 6) ly = qn[1] + 10;
      while (hit([lx - 5, ly - 2, lx + tw + 5, ly + th]) && tries < 12) { ly += th + 4; ++tries; }
      if (ly + th > Hk - 6) continue;
      used.push([lx - 5, ly - 2, lx + tw + 5, ly + th]);
      g.fillStyle = "rgba(13,10,7,0.722)"; g.fillRect(lx - 5, ly - 2, tw + 10, th + 2);
      g.strokeStyle = fwTimeRgba(ncol, 0.75); g.lineWidth = 0.8; g.beginPath(); g.moveTo(lx - 5, ly + th - 0.5); g.lineTo(lx + tw + 5, ly + th - 0.5);
      g.moveTo(qn[0] + (right ? 4 : -4), qn[1] - (ly < qn[1] ? 4 : -4)); g.lineTo(right ? lx - 5 : lx + tw + 5, ly + th - 0.5); g.stroke();
      use(fN); g.fillStyle = "#FBF2E0"; g.fillText(sTx, lx, ly + 12);
      labels.push({ kind: nt.kind, text: sTx, full: full, rect: [(lx - 5) * k, (ly - 2) * k, (lx + tw + 5) * k, (ly + th) * k], onHead: onHead });
   }
   g.restore();
   FW_TIME.stats = { years: years, alpha: Math.round(a0 * 1000) / 1000, mode: fvTimeMode(sc), arrows: nArrows, items: Tr ? Tr.items.length : 0, drawn: nItems, lines: nLines, heads: nHeads, rings: nRings,
                     cross: Tr ? Tr.nCross : 0, group: Tr ? Tr.nGroup : 0, run: Tr ? Tr.nRun : 0, groups: Tr ? Tr.groups.length : 0, plate: plate, labels: labels };
}
