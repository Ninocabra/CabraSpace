// ============================================================================
// FieldVoyager/web/fw_pl_view.js — BLENDER 1: LOS EXOPLANETAS COMO MUNDOS en el visor (5-nov-2026)
// ----------------------------------------------------------------------------
// El gemelo de src/ui/fv_planets3d.js (PixInsight), con la MISMA regla de composicion sobre lienzos 2D:
//     P_α = tinte LISO × sombreado_α (multiply) + atmosfera_α (lighter) + resplandor_dia_α × color (lighter, alfa) + noche (idem)
// y en cada fotograma: silueta (source-over) + las dos fases vecinas fundidas (lighter, globalAlpha 1 − w y w), giradas para poner la
// estrella donde este, y (Blender 3 · D3) la TEXTURA del albedo multiplicada con el EJE DE GIRO FIJO (o.band). Los mundos CALIENTES
// (Blender 3 · D2) se componen pixel a pixel en luz LINEAL con el tono que conserva el tono (fvsPlanetToneK). Datos: web/fw_pl_s<N>.js
// (FW_PL_DATA[N], PNG en base64; los genera blender/build_planetas_rsc.py) y la fisica de science/fv_sci_planet.js (fvsPlanetLook…).
// FW_PL3D.ON = false: no se carga nada y no se pinta nada.
// ES5.
// ============================================================================

var FW_PL3D = { ON: true, RINGS: false, ORBIT_S: 24, PORT_R: 0.62, UPSCALE_MAX: 1.25, LEVELS: [64, 160, 384], SETS_MAX: 4, INSET: { d: 0.62, k: 0.30, pl: 0.78 } };      // (Blender 4 · PL-22) como FV_PL3D.INSET
var FW_PL_DATA = (typeof FW_PL_DATA === "object" && FW_PL_DATA) ? FW_PL_DATA : {};
var FW_PL_ST = { asked: {}, imgs: {}, sets: {}, setKeys: [], albW: {} };

// lo llama cada fw_pl_s<N>.js al cargarse: decodifica los PNG (asincrono)
function fwPlLoaded(lv) {
   var D = FW_PL_DATA[lv]; if (!D || FW_PL_ST.imgs[lv]) return;
   var I = FW_PL_ST.imgs[lv] = { n: 0, done: 0, img: {} };
   for (var fam in D.L) for (var lay in D.L[fam]) {
      (function(fam, lay) {
         var im = new Image(); ++I.n;
         im.onload = function() { ++I.done; };
         im.onerror = function() { ++I.done; try { console.warn("[pl3d] PNG roto: " + fam + "/" + lay); } catch (e) {} };
         im.src = D.L[fam][lay].src; I.img[fam + "/" + lay] = im;
      })(fam, lay);
   }
}
// ¿esta el nivel listo? (si no, lo pide: un <script> por nivel)
function fwPlReady(lv) {
   var I = FW_PL_ST.imgs[lv];
   if (I) return I.done >= I.n;
   if (!FW_PL_ST.asked[lv]) {
      FW_PL_ST.asked[lv] = true;
      if (FW_PL_DATA[lv]) fwPlLoaded(lv);
      else if (typeof document !== "undefined") { var s = document.createElement("script"); s.src = "fw_pl_s" + lv + ".js"; s.async = true; s.onerror = function() { try { console.warn("[pl3d] no se pudo cargar fw_pl_s" + lv + ".js"); } catch (e) {} }; document.head.appendChild(s); }
   }
   return false;
}
function fwPlLevel(rPx) {
   var L = FW_PL3D.LEVELS, fr = 1.15;
   for (var i = 0; i < L.length; ++i) { var D = FW_PL_DATA[L[i]]; fr = D ? D.frame : fr; if (L[i] / 2 / fr >= rPx / FW_PL3D.UPSCALE_MAX) return L[i]; }
   return L[L.length - 1];
}
function fwPlLook(row, tr) {
   var D = FW_PL_DATA[FW_PL3D.LEVELS[0]] || FW_PL_DATA[FW_PL3D.LEVELS[1]] || FW_PL_DATA[FW_PL3D.LEVELS[2]];
   // (PL-4, 10-nov) como src/ui/fv_planets3d.js fvPl3dLook: la forma del resplandor y la media del albedo entran en la exposicion
   var fam0 = fvsPlanetLook(row || {}, tr || null).fam, fm0 = D && D.fam ? D.fam[fam0] : null;
   var L = fvsPlanetLook(row || {}, tr || null, fm0 ? { glowP: fm0.glow_p, albMean: fm0.alb_mean } : null);
   var fm = D && D.fam ? D.fam[L.fam] : null, p1 = 1 + (fm ? fm.glow_p : 0);
   L.noFam = !fm;
   L.paint = { day: fvsPlanetPaint([L.glowDay[0] * p1, L.glowDay[1] * p1, L.glowDay[2] * p1]), night: fvsPlanetPaint(L.glowNight) };
   L.key = L.fam + ":" + L.tint.map(function(v) { return v.toFixed(3); }).join(",") + ":" + L.paint.day.col.join(",") + ":" + L.paint.day.op.toFixed(3) + ":" + L.paint.night.col.join(",") + ":" + L.paint.night.op.toFixed(3) + (L.tone ? ":T" : "");
   return L;
}
function fwPlCanvas(w, h) { var c = document.createElement("canvas"); c.width = w; c.height = h || w; return c; }
function fwPlCss(c) { return "rgb(" + c[0] + "," + c[1] + "," + c[2] + ")"; }
function fwPlTinted(img, col, n) {
   var c = fwPlCanvas(n), g = c.getContext("2d");
   g.fillStyle = fwPlCss(col); g.fillRect(0, 0, n, n);
   g.globalCompositeOperation = "multiply"; g.imageSmoothingEnabled = true; g.drawImage(img, 0, 0, n, n);
   return c;
}
// (Blender 3 · D3) la textura para multiplicar en la pantalla: el albedo dentro del disco, blanco fuera (como fvPl3dAlbW)
function fwPlAlbW(lv, fam, img, n, frame) {
   var id = lv + "/" + fam; if (FW_PL_ST.albW[id]) return FW_PL_ST.albW[id];
   var c = fwPlCanvas(n), g = c.getContext("2d"); g.fillStyle = "#000"; g.fillRect(0, 0, n, n); g.imageSmoothingEnabled = true; g.drawImage(img, 0, 0, n, n);
   var D = g.getImageData(0, 0, n, n), A = D.data, R = n / 2 / (frame || 1.15), h = n / 2;
   for (var y = 0; y < n; ++y) for (var x = 0; x < n; ++x) {
      var dx = x + 0.5 - h, dy = y + 0.5 - h, m = Math.max(0, Math.min(1, R - Math.sqrt(dx * dx + dy * dy) + 0.5)), i = 4 * (y * n + x), v = Math.round(A[i] * m + 255 * (1 - m));
      A[i] = A[i + 1] = A[i + 2] = v; A[i + 3] = 255;
   }
   g.putImageData(D, 0, 0);
   return (FW_PL_ST.albW[id] = c);
}
// (Blender 3 · D2) una fase de un mundo CALIENTE en luz lineal + tono que conserva el tono (como fvPl3dComposeLin)
var FW_PL_LUT = null;
function fwPlLuts() {
   if (FW_PL_LUT) return FW_PL_LUT;
   var lin = new Float64Array(256), enc = new Uint8Array(4097), e06 = new Float64Array(256), dec = new Float64Array(2049), i;
   for (i = 0; i < 256; ++i) { lin[i] = fvsSrgbLinear(i / 255); e06[i] = fvsSrgbGamma(0.6 * lin[i]); }
   for (i = 0; i <= 4096; ++i) enc[i] = Math.round(255 * fvsSrgbGamma(i / 4096));
   for (i = 0; i <= 2048; ++i) dec[i] = fvsSrgbLinear(i / 2048);
   return (FW_PL_LUT = { lin: lin, enc: enc, e06: e06, dec: dec });
}
function fwPlPx(img, n) { if (!img) return null; var c = fwPlCanvas(n), g = c.getContext("2d"); g.fillStyle = "#000"; g.fillRect(0, 0, n, n); g.imageSmoothingEnabled = true; g.drawImage(img, 0, 0, n, n); return g.getImageData(0, 0, n, n).data; }
function fwPlComposeLin(look, im, a, n, tl, fm) {
   var LU = fwPlLuts(), LIN = LU.lin, ENC = LU.enc, DC = LU.dec, ap = look.tone.ap || 1, p1 = 1 + (fm ? fm.glow_p : 0);
   var SH = fwPlPx(im("sh_a" + a), n), AT = fwPlPx(im("at_a" + a), n), GD = fwPlPx(im("gd_a" + a), n), GN = fwPlPx(im("gn_a" + a), n);
   var D = [0, 1, 2].map(function(c) { return look.glowDay[c] * p1 * ap; }), N = [0, 1, 2].map(function(c) { return look.glowNight[c] * ap; });
   var AS = [tl[0] / 0.6, tl[1] / 0.6, tl[2] / 0.6];     // la atmosfera escala con el tinte de este mundo (como fvPl3dComposeLin)
   var c = fwPlCanvas(n), g = c.getContext("2d"), O = g.createImageData(n, n), A = O.data, A0 = 0.6;
   for (var i = 0; i < n * n; ++i) {
      var j = 4 * i, s = SH ? LIN[SH[j]] : 0, gd = GD ? LIN[GD[j]] : 0, gn = GN ? LIN[GN[j]] : 0;
      var r = tl[0] * s + D[0] * gd + N[0] * gn, gg = tl[1] * s + D[1] * gd + N[1] * gn, bb = tl[2] * s + D[2] * gd + N[2] * gn;
      if (AT) { var e0 = LU.e06[SH ? SH[j] : 0], as = A0 * s;
         r += AS[0] * Math.max(0, DC[Math.min(2048, Math.round(2048 * (AT[j] / 255 + e0)))] - as); gg += AS[1] * Math.max(0, DC[Math.min(2048, Math.round(2048 * (AT[j + 1] / 255 + e0)))] - as); bb += AS[2] * Math.max(0, DC[Math.min(2048, Math.round(2048 * (AT[j + 2] / 255 + e0)))] - as); }
      var m = Math.max(r, gg, bb); A[j + 3] = 255;
      if (!(m > 1e-7)) continue;
      var k = fvsPlanetToneK(m, look.tone) * 4096;
      A[j] = ENC[Math.min(4096, Math.round(r * k))]; A[j + 1] = ENC[Math.min(4096, Math.round(gg * k))]; A[j + 2] = ENC[Math.min(4096, Math.round(bb * k))];
   }
   g.putImageData(O, 0, 0);
   return c;
}
function fwPlSet(look, lv) {
   var key = look.key + "@" + lv; if (FW_PL_ST.sets[key]) return FW_PL_ST.sets[key];
   if (!fwPlReady(lv)) return null;
   while (FW_PL_ST.setKeys.length >= FW_PL3D.SETS_MAX) delete FW_PL_ST.sets[FW_PL_ST.setKeys.shift()];
   var t0 = performance.now(), D = FW_PL_DATA[lv], I = FW_PL_ST.imgs[lv].img, fam = look.fam, n = D.size, ph = D.phases, P = look.paint, out = [];
   function im(lay) { return I[fam + "/" + lay] || null; }
   var fm = D.fam[fam], k = 1 / Math.max(0.2, fm.alb_mean), tl = [look.tint[0] * k, look.tint[1] * k, look.tint[2] * k];
   var mx = Math.max(tl[0], tl[1], tl[2]), sc = mx > 1 ? 1 / mx : 1, tint = [0, 1, 2].map(function(i) { return Math.round(255 * fvsSrgbGamma(tl[i] * sc)); });
   // (Blender 3 · D3) las fases con el tinte LISO; la textura (albW) se multiplica en la pantalla con el eje de giro fijo
   var albW = fwPlAlbW(lv, fam, im("alb"), n, D.frame);
   for (var i = 0; i < ph.length; ++i) {
      var a = ("00" + ph[i]).slice(-3);
      if (look.tone) { out.push(fwPlComposeLin(look, im, a, n, [tl[0] * sc, tl[1] * sc, tl[2] * sc], fm)); continue; }
      var c = fwPlCanvas(n), g = c.getContext("2d");
      g.imageSmoothingEnabled = true; g.fillStyle = fwPlCss(tint); g.fillRect(0, 0, n, n);
      if (im("sh_a" + a)) { g.globalCompositeOperation = "multiply"; g.drawImage(im("sh_a" + a), 0, 0, n, n); }
      g.globalCompositeOperation = "lighter";
      if (im("at_a" + a)) g.drawImage(im("at_a" + a), 0, 0, n, n);
      if (P.day.op > 1 / 512 && im("gd_a" + a)) { g.globalAlpha = P.day.op; g.drawImage(fwPlTinted(im("gd_a" + a), P.day.col, im("gd_a" + a).width), 0, 0, n, n); }
      if (P.night.op > 1 / 512 && im("gn_a" + a)) { g.globalAlpha = P.night.op; g.drawImage(fwPlTinted(im("gn_a" + a), P.night.col, im("gn_a" + a).width), 0, 0, n, n); }
      g.globalAlpha = 1; g.globalCompositeOperation = "source-over";
      out.push(c);
   }
   var set = { key: key, lv: lv, n: n, rpx: n / 2 / D.frame, phases: ph, P: out, sil: im("sil"), ring: fm.ring ? im("ring") : null, ms: performance.now() - t0, tint: tint, albW: albW, atm: !!fm.atm };
   FW_PL_ST.sets[key] = set; FW_PL_ST.setKeys.push(key);
   return set;
}
// pinta el planeta: centro, radio del disco, fase (grados), rot = angulo en pantalla hacia la estrella (rad, y abajo). -> stats o null
// o.band (Blender 3 · D3): angulo en pantalla de las bandas (eje de giro fijo); sin el, la textura gira con la estrella como antes
function fwPlDraw(g, cx, cy, rPx, look, alphaDeg, rot, o) {
   if (!FW_PL3D.ON || !look || !(rPx > 0) || typeof fvsPlanetLook !== "function") return null;
   var t0 = performance.now(), lv = fwPlLevel(rPx), set = fwPlSet(look, lv);
   if (!set) return null;
   var ph = set.phases, a = Math.max(0, Math.min(180, alphaDeg)), i0 = 0;
   while (i0 < ph.length - 2 && a > ph[i0 + 1]) ++i0;
   var w = Math.max(0, Math.min(1, (a - ph[i0]) / (ph[i0 + 1] - ph[i0]))), s = rPx / set.rpx, h = set.n / 2, nb = (o && o.nightBoost) ? fwPlNightBoost(look, a) : 0;
   var band = (o && o.band !== undefined && o.band !== null) ? o.band : rot;
   g.save();
   try {
      g.translate(cx, cy); g.rotate(rot); g.scale(s, s); g.imageSmoothingEnabled = true;
      g.globalCompositeOperation = "source-over"; g.globalAlpha = 1; g.drawImage(set.sil, -h, -h);
      g.globalCompositeOperation = "lighter";
      if (w < 1 - 1 / 256) { g.globalAlpha = 1 - w; g.drawImage(set.P[i0], -h, -h); }
      if (w > 1 / 256) { g.globalAlpha = w; g.drawImage(set.P[i0 + 1], -h, -h); }
      // (PL-5) la misma imagen sumada otra vez con peso nb (×2 en sRGB): el lado nocturno de un mundo sin aire, con rotulo en la portilla
      for (var nr = nb; nr > 0; nr -= 1) { var na = Math.min(1, nr); if (w < 1 - 1 / 256) { g.globalAlpha = (1 - w) * na; g.drawImage(set.P[i0], -h, -h); } if (w > 1 / 256) { g.globalAlpha = w * na; g.drawImage(set.P[i0 + 1], -h, -h); } }
      // (Blender 3 · D3) la textura con el eje de giro fijo (blanco fuera del disco: no toca lo de detras)
      if (set.albW && rPx >= 4) { g.setTransform(1, 0, 0, 1, 0, 0); g.restore(); g.save(); g.translate(cx, cy); g.rotate(band); g.scale(s, s); g.imageSmoothingEnabled = true; g.globalAlpha = 1; g.globalCompositeOperation = "multiply"; g.drawImage(set.albW, -h, -h); }
      if (FW_PL3D.RINGS && !(o && o.rings === false) && set.ring && look.fam === "giant") {
         g.restore(); g.save(); g.translate(cx, cy); g.rotate(rot); g.scale(s, s);
         g.globalCompositeOperation = "source-over"; g.globalAlpha = 0.35 + 0.65 * fvsPlanetLitFraction(a);
         g.drawImage(set.ring, -set.ring.width / 2, -set.ring.height / 2);
      }
   } finally { g.restore(); }
   return { lv: lv, ms: performance.now() - t0, i0: i0, w: w, alpha: a, rot: rot, band: band, boost: nb, night: nb > 0.02 || a >= 172 };
}
// en el transito (fvsTransitPos: X a lo largo, Y arriba, Z hacia el observador; pantalla y = −Y)
function fwPlTransitPhase(q) {
   var l = Math.sqrt(q.x * q.x + q.y * q.y + q.z * q.z) || 1;
   return { alpha: Math.acos(Math.max(-1, Math.min(1, -q.z / l))) * 180 / Math.PI, rot: Math.atan2(q.y / l, -q.x / l) };
}
// el gancho de la ficha (fw_cockpit.js drawCardStar): sel = la seleccion; un objeto «exoplanet» de la escena (FW.scene.objects, con su fila
// en o.planet: el exportador añade st_teff/st_rad/st_mass/pl_ratror/pl_imppar/pl_orbincl si la bandera esta encendida). W, H = el lienzo de
// la portilla; t = segundos desde que se abrio. -> true si pinto (mientras no esten los sprites, false: la estrella de siempre)
var FW_PL_CARD = { o: null, tr: null, look: null };
// (PL-6, 10-nov) como src/ui/fv_planets3d.js fvPl3dHostObj: la portilla enseña el planeta de un objeto «exoplaneta» y el de una ESTRELLA que
// tiene uno (MIRABILIA y el buscador eligen la estrella: fwNavSel -> { kind: "star", i, obj }; un clic en la estrella, igual)
function fwPlHostObj(sel) {
   var ob = FW.scene.objects, i;
   if (sel.kind === "object") return ob[sel.i] || null;
   if (sel.kind !== "star" || !(sel.i >= 0)) return null;
   if (sel.obj >= 0 && ob[sel.obj] && ob[sel.obj].type === "exoplanet" && ob[sel.obj].star === sel.i) return ob[sel.obj];
   for (i = 0; i < ob.length; ++i) if (ob[i] && ob[i].type === "exoplanet" && ob[i].planet && ob[i].star === sel.i) return ob[i];
   return null;
}
function fwPlCardSetup(sel) {
   if (!FW_PL3D.ON || !sel || typeof FW === "undefined" || !FW.scene || !FW.scene.objects || !FW.P || typeof fvsPlanetLook !== "function") return null;
   var o = fwPlHostObj(sel);
   if (!o || o.type !== "exoplanet" || !o.planet || !(o.star >= 0)) return null;
   if (FW_PL_CARD.o !== o) {
      var tr = fvsTransitSetup(o.planet);
      FW_PL_CARD.o = o; FW_PL_CARD.tr = (tr.aR > 0 && tr.Ph > 0) ? tr : null; FW_PL_CARD.look = FW_PL_CARD.tr ? fwPlLook(o.planet, tr) : null;
   }
   if (!FW_PL_CARD.tr) return null;
   // el aspecto se calculo antes de que llegaran los datos (sin la forma del resplandor): se rehace una vez
   if (FW_PL_CARD.look && FW_PL_CARD.look.noFam && (FW_PL_DATA[64] || FW_PL_DATA[160] || FW_PL_DATA[384])) FW_PL_CARD.look = fwPlLook(o.planet, FW_PL_CARD.tr);
   var pr = fvProjector(FW.P.cam, FW.VW, FW.VH);
   return { o: o, G: { tr: FW_PL_CARD.tr, starPos: fvStarPos(FW.scene, o.star), camPos: FW.P.cam.pos, rStarU: (Number(o.planet.st_rad) || 1) * 6.957e8 / 9.4607e15, basis: pr } };
}
// la ficha de un OBJETO «exoplaneta»: el mundo llena la portilla (la de una estrella va por fwPlCardInset)
function fwPlCardPlanet(g, sel, W, H, t) {
   if (!sel || sel.kind === "star") return false;
   var S = fwPlCardSetup(sel); if (!S) return false;
   var st = fwPlPorthole(g, FW_PL_CARD.look, S.G, W / 2, H / 2, W / 2, t);
   FW_PL_CARD.last = st;
   return !!st;
}
// (Blender 3 · D4) la ficha de la ESTRELLA: su estrella (lo de siempre, ya pintado) y el mundo en un recuadro abajo a la derecha, con el nombre
// del planeta curvado abajo a la izquierda (como fvPl3dInsetObj). -> stats o null
function fwPlCardInset(g, sel, W, H, t) {
   if (!sel || sel.kind !== "star") return null;
   var S = fwPlCardSetup(sel); if (!S) return null;
   var I = FW_PL3D.INSET, r = W / 2, cx = W / 2, cy = H / 2, ix = cx + I.d * r * Math.SQRT1_2, iy = cy + I.d * r * Math.SQRT1_2, ir = I.k * r, k = W / 116;
   g.save();
   g.globalCompositeOperation = "source-over"; g.globalAlpha = 1;
   g.fillStyle = "#2A1F15"; g.beginPath(); g.arc(ix, iy, ir + 1.6 * k, 0, 2 * Math.PI); g.fill();
   g.fillStyle = "#07060A"; g.beginPath(); g.arc(ix, iy, ir, 0, 2 * Math.PI); g.fill();
   g.save(); g.beginPath(); g.arc(ix, iy, ir, 0, 2 * Math.PI); g.clip();
   S.G.kPl = I.pl; S.G.nightBoost = false; S.G.noLabels = true;
   var st = fwPlPorthole(g, FW_PL_CARD.look, S.G, ix, iy, ir, t);
   g.restore();
   g.strokeStyle = "#7A5A1E"; g.lineWidth = 1.2 * k; g.beginPath(); g.arc(ix, iy, ir + 1.6 * k, 0, 2 * Math.PI); g.stroke();
   g.strokeStyle = "rgba(201,154,58,.9)"; g.lineWidth = 0.8 * k; g.beginPath(); g.arc(ix, iy, ir + 0.4 * k, 0, 2 * Math.PI); g.stroke();
   var nm = String(S.o.planet.pl_name || S.o.name || ""), fs = Math.max(6, Math.round(0.15 * 58)) * k, rb = 0.90 * r, maxA = 66 * Math.PI / 180;
   // (Blender 5 · H4) un planeta de DEMOSTRACION (la fila inyectada: ni «gaia-id» ni «position») lleva «DEMO» en el recuadro, como en PixInsight (fv_hud.js fvPorthole)
   if (typeof FV_EXO_DEMO_CARD !== "undefined" && FV_EXO_DEMO_CARD && S.o.match !== undefined && S.o.match !== "gaia-id" && S.o.match !== "position" && typeof fvTx === "function") nm = fvTx("b5.demoWord");
   g.font = "italic " + fs + "px Georgia, serif";
   while (fs > 6 * k && g.measureText(nm).width / rb > maxA) { fs -= k; g.font = "italic " + fs + "px Georgia, serif"; }
   // (Blender 4 · PL-22) la cartela oscura bajo el nombre (como fvPl3dCartouche): la barra dorada del escaner ya no cruza las letras
   var cw0 = Math.max(fs, g.measureText(nm).width - 0.6 * fs), cth = cw0 / rb, crm = rb - 0.32 * fs;
   if (FW_PL3D.CARTOUCHE !== false) { g.save(); g.strokeStyle = "rgba(7,6,8,.78)"; g.lineWidth = 1.25 * fs; g.lineCap = "square"; g.beginPath(); g.arc(cx, cy, crm, 133 * Math.PI / 180 - cth / 2, 133 * Math.PI / 180 + cth / 2); g.stroke(); g.restore(); }
   fwPlArcText(g, cx, cy, rb, nm, "rgba(242,213,140,.95)", false, 133 * Math.PI / 180);
   g.restore();
   if (st) st.inset = { x: ix, y: iy, r: ir, name: nm };
   FW_PL_CARD.last = st;
   return st;
}
// la portilla de la ficha: G = { tr, starPos, camPos, rStarU, basis: { r, d } }, t en segundos. (Blender 3) resplandor de la estrella (D1), eje fijo
// (D3) y rotulos curvados (D6); G.kPl: radio del planeta / r
function fwPlPorthole(g, look, G, cx, cy, r, t) {
   if (!FW_PL3D.ON || !G || !G.tr) return null;
   var phi = 2 * Math.PI * ((t || 0) / FW_PL3D.ORBIT_S) + Math.PI / 2;
   var F = fvsPlanetPhase(G.tr, phi, G.starPos, G.camPos, G.rStarU || 0, G.basis || null, G.frame || null);
   if (G.band === undefined) G.band = (G.basis && typeof fvsPlanetBandAngle === "function") ? fvsPlanetBandAngle(G.tr, G.starPos, G.basis, G.frame || null) : null;
   var rPl = (G.kPl || FW_PL3D.PORT_R) * r, gl = fwPlGlare(g, cx, cy, r, rPl, look, F.alpha, F.rot, G.tr.aR);
   var st = fwPlDraw(g, cx, cy, rPl, look, F.alpha, F.rot, { nightBoost: G.nightBoost !== false, band: G.band });
   if (gl) fwPlGlare(g, cx, cy, r, rPl, look, F.alpha, F.rot, G.tr.aR, true);      // (Blender 4 · PL-23) la segunda pasada, como fvPl3dGlareOver
   if (st) { st.phi = phi; st.front = F.front; st.glare = gl; st.skip = G.noLabels ? { top: false, bottom: false } : fwPlLabels(g, cx, cy, r, st); }
   return st;
}
// (Blender 3 · D1) el resplandor de la estrella (como fvPl3dGlare): degradado radial donde esta la estrella, sumado al cristal (lighter)
// (Blender 4 · PL-23) dos pasadas como fvPl3dGlare / fvPl3dGlareOver: debajo, sumada, con el disco a GLARE_UNDER; encima (over), en «lighten»
// (max) y solo en el anillo cristal − planeta, con el disco a GLARE_CORE
function fwPlGlare(g, cx, cy, rPort, rPl, look, alphaDeg, rot, aR, over) {
   if (typeof fvsPlanetGlare !== "function") return null;
   var G = fvsPlanetGlare(alphaDeg, aR); if (!G.on) return null;
   var two = FVS_PL.GLARE_UNDER > 0 && FVS_PL.GLARE_UNDER < FVS_PL.GLARE_CORE;
   if (over && (!two || (G.d - G.rs) * rPl > rPort)) return null;
   if (!over && two) G.core = 255 * FVS_PL.GLARE_UNDER;
   var sx = cx + G.d * rPl * Math.cos(rot), sy = cy + G.d * rPl * Math.sin(rot), rc = Math.max(0.6, G.rs * rPl), wv = G.w * rPl, Rg = rc + 7 * wv;
   var col = (typeof fvsPlanetGlareCol === "function") ? fvsPlanetGlareCol(look) : [1, 1, 1];      // (Blender 4 · PL-23) como fvPl3dGlare
   function css(I) { I = Math.max(0, Math.min(255, I)); return "rgb(" + Math.round(col[0] * I) + "," + Math.round(col[1] * I) + "," + Math.round(col[2] * I) + ")"; }
   var gr = g.createRadialGradient(sx, sy, 0, sx, sy, Rg);
   var C0 = G.core || 255;      // el disco de la estrella con limbo (FVS_PL.GLARE_CORE, como src/ui/fv_planets3d.js)
   gr.addColorStop(0, css(C0)); gr.addColorStop(0.6 * rc / Rg, css(0.96 * C0)); gr.addColorStop(rc / Rg, css(0.82 * C0));
   [0.15, 0.35, 0.6, 1, 1.5, 2.2, 3, 4.2, 5.6].forEach(function(u) { gr.addColorStop((rc + u * wv) / Rg, css(Math.min(0.82 * C0, G.i0 / (1 + u * u)))); });
   gr.addColorStop(1, "rgb(0,0,0)");
   if (!over) { g.save(); g.globalCompositeOperation = "lighter"; g.globalAlpha = 1; g.fillStyle = gr; g.beginPath(); g.arc(cx, cy, rPort, 0, 2 * Math.PI); g.fill(); g.restore(); }
   else { g.save(); g.globalCompositeOperation = "lighten"; g.globalAlpha = 1; g.fillStyle = gr; g.beginPath(); g.arc(cx, cy, rPort, 0, 2 * Math.PI); g.arc(cx, cy, rPl + 0.5, 0, 2 * Math.PI, true); g.fill("evenodd"); g.restore(); }
   return { d: G.d, rs: G.rs, sx: sx, sy: sy };
}
// (PL-5, 10-nov) el lado nocturno de un mundo sin aire: misma regla que src/ui/fv_planets3d.js (fvPl3dNightBoost)
FW_PL3D.NIGHT_A0 = 140; FW_PL3D.NIGHT_A1 = 160; FW_PL3D.NIGHT_MAX = 2.7; FW_PL3D.NIGHT_FAM = { rocky: true, superearth: true };
function fwPlNightBoost(look, a) {
   if (!look || !FW_PL3D.NIGHT_FAM[look.fam] || !(FW_PL3D.NIGHT_A1 > FW_PL3D.NIGHT_A0)) return 0;
   var x = Math.max(0, Math.min(1, (a - FW_PL3D.NIGHT_A0) / (FW_PL3D.NIGHT_A1 - FW_PL3D.NIGHT_A0)));
   return FW_PL3D.NIGHT_MAX * x * x * (3 - 2 * x);
}
// (Blender 3 · D6) texto curvado por dentro del cristal (como fvPl3dArcText): top = letras hacia fuera por arriba; si no, de pie por abajo
function fwPlArcText(g, cx, cy, rb, s, fill, top, thC) {
   var w = g.measureText(s).width, th = w / rb, dir = top ? 1 : -1, c = (thC !== undefined) ? thC : (top ? -Math.PI / 2 : Math.PI / 2), a = c - dir * th / 2;
   g.save(); var M0 = g.getTransform(); g.fillStyle = fill; g.textAlign = "center"; g.textBaseline = "alphabetic";
   for (var i = 0; i < s.length; ++i) {
      var ch = s.charAt(i), cw = g.measureText(ch).width, am = a + dir * (cw / 2) / rb;
      g.setTransform(M0);
      g.translate(cx + rb * Math.cos(am), cy + rb * Math.sin(am)); g.rotate(am + dir * Math.PI / 2); g.fillText(ch, 0, 0);
      a += dir * cw / rb;
   }
   g.restore();
}
function fwPlTx(k, en, esS, p) {
   var es = (typeof FW_LANG !== "undefined" && FW_LANG === "es");
   if (typeof fvTx === "function" && typeof FV_TX !== "undefined" && FV_TX.en[k]) return fvTx(k, p || null, es ? "es" : "en");
   return (es ? esS : en).replace("{x}", p ? p.x : "");
}
// los rotulos de la portilla (curvados, como fvPl3dLabels) -> { top, bottom }: los brazos de la cruz que no se pintan
function fwPlLabels(g, cx, cy, r, st) {
   var R = { top: false, bottom: false }; if (!st) return R;
   var es = (typeof FW_LANG !== "undefined" && FW_LANG === "es"), fs = Math.max(6, Math.round(r * 0.15));
   g.save(); g.font = "italic " + fs + "px Georgia, serif";
   if (st.night) { fwPlArcText(g, cx, cy, 0.78 * r, fwPlTx("pl3.night", "night side", "lado nocturno"), "rgba(233,201,122,.85)", true); R.top = true; }
   if (st.boost > 0.02) { var fx = Math.pow(1 + st.boost, 2.2).toFixed(1).replace(".", es ? "," : "."); fwPlArcText(g, cx, cy, 0.90 * r, fwPlTx("pl3.expo", "exposure ×{x}", "exposición ×{x}", { x: fx }), "rgba(191,160,106,.80)", false); R.bottom = true; }
   g.restore();
   return R;
}
// (Blender 3 · D7) la cruz de la portilla del planeta: brazos CORTOS por fuera del planeta, como en PixInsight (de 4 a 13 unidades del borde
// con r = 58), sin los que ocupa un rotulo
function fwPlCross(g, W, H, skip) {
   var k = W / 116, cx = W / 2, cy = H / 2;
   g.save(); g.strokeStyle = "rgba(229,181,63,.5)"; g.lineWidth = k; g.beginPath();
   if (!skip || !skip.top) { g.moveTo(cx, 4 * k); g.lineTo(cx, 13 * k); }
   if (!skip || !skip.bottom) { g.moveTo(cx, H - 13 * k); g.lineTo(cx, H - 4 * k); }
   g.moveTo(4 * k, cy); g.lineTo(13 * k, cy); g.moveTo(W - 13 * k, cy); g.lineTo(W - 4 * k, cy); g.stroke(); g.restore();
}
