// ============================================================================
// FieldVoyager/web/fw_route.js — ITINERARIUM en el visor: TABULA / PROFUNDITAS en grande, las camaras de la ruta y la fila de viaje de la
// ficha (pasada M, 4-nov-2026). Gemelo de src/ui/fv_route.js de PixInsight (de ahi salen el contrato, los numeros y los textos; aqui en
// lienzo 2D y HTML, copiado y adaptado).
// ----------------------------------------------------------------------------
// (a) Clic en TABULA o PROFUNDITAS (la franja): ese mapa ocupa la pantalla grande y la nave, en vivo, pasa a su hueco pequeño. Clic en la
//     nave (el hueco) o Esc: vuelve. Clic en el otro mapa pequeño: cambia de mapa grande.
// (b) TABULA grande: clic = camara mirando ahi (la estrella u objeto mas cercano a PICK_PX, o la nebulosa) · arrastrar desde el punto = su
//     distancia (log) · arrastrar una camara numerada = moverla por la foto. PROFUNDITAS grande: clic en una estrella u objeto = su camara ·
//     arrastrar una camara de lado = mas lejos / cerca de la Tierra. «＋ VISTA ACTUAL» = la camara de la nave. Cono, numero y la ruta en curva.
// (c) La lista ITINERARIUM ocupa el hueco de MIRABILIA mientras el mapa esta en grande: numero, miniatura real (un fotograma del render hecho
//     antes del fotograma de verdad), nombre (doble clic o ✎: renombrar), parada (chip), ▲ ▼ ⟳ ✎ ✕, clic en la fila = ir alli, «Borrar todo»
//     con confirmacion. Se guarda en localStorage por imagen (centro y tamaño de la foto: la misma firma que PixInsight).
// (d) RECORRER: fvPilotFlyPath(P, keys, opts) del motor si existe; si no, el respaldo de aqui (Catmull-Rom, slerp, campo en log, paradas).
// (e) REC graba la ruta como cualquier vuelo (graba el lienzo).
// (f) La ficha: VIAJAR (flecha curva) con el MODUS y el otro modo al lado, cada uno con su duracion (fvPilotFly sobre una COPIA del piloto),
//     y la distancia desde la nave.
// ES5.
// ============================================================================

var FW_ROUTE = { HOLDS: [0, 2, 3, 5, 8], HOLD0: 3, MAX: 24, PICK_PX: 18, DRAG_PX: 6, STAND_LO: 1e-3, STAND_HI: 1.0, STAND_NEB: 0.25, NEB_VIEW: 0.35, FOV_DEG: 40,
                 LEG: { MIN: 5, DEC: 4, MAX: 24, TURN_DPS: 25 }, FORCE_FALLBACK: false, TRIP_EVERY_S: 0.4, KB: 1.9, HZ: 30, TAN_MAX: 2,
                 // (nD2, encargo E5) PROFUNDITAS: orbitar / clic; la animacion de llegada de cada camara (copia de src/ui/fv_route.js)
                 ORBIT_PX: 4, ANIMS: ["none", "orbit", "dolly", "pull", "pan", "roll", "parallax"], ANIM_S: [4, 6, 8, 12, 16],
                 ANIM_S0: { orbit: 12, dolly: 8, pull: 8, pan: 8, roll: 6, parallax: 8 },
                 ANIM: { ORBIT_DEG: 90, DOLLY_K: 0.5, PULL_K: 1.5, PAN_DEG: 20, ROLL_DEG: 12, PARALLAX_K: 0.25 } };
var FW_RT_TX = {
   en: { ship: "NAVIS", add: "CURRENT VIEW", play: "FLY THE ROUTE", stop: "STOP", suggest: "SUGGEST", title: "ITINERARIUM",
         hint2: "Click: a camera looking there · drag: its distance · drag a camera: move it", hint3: "Drag: turn the 3D · wheel: zoom · click a star or object: its camera · drag a camera: its depth · round handle: tilt the planes",
         tipBig2: "TABULA, large: click a point of the photo = a camera looking there (if there is a star or object next to the click, it takes it and its distance; otherwise the nebula). Drag from the point = how far from it the camera stays. Drag a numbered camera = move it over the photo. Each camera shows its cone; the gold curve is the route. «＋ CURRENT VIEW» saves the ship's camera; «▶ FLY THE ROUTE» flies through them in order (REC records it). Esc or a click on the little ship window: back to the ship.",
         tipBig3: "PROFUNDITAS, large. LEFT button: drag on the map (not on a camera) = turn the 3D view around the field (sideways = around, up/down = from above or below) · wheel = zoom · double-click on empty space = the starting view. Click without moving (less than 4 px) on a star or object = a camera for it. Drag a numbered camera = its depth: along the distance axis, farther from or nearer to the Earth (it keeps its direction). The round handle over the nebula slab tilts the planes of the nebula (drag; double-click on it = untilted). The gold curve is the route. «▶ FLY THE ROUTE» flies through the cameras in order. Esc or a click on the little ship window: back to the ship.",
         tipTilt: "Tilt the planes of the nebula: drag up / down = around the horizontal axis, left / right = around the vertical axis (up to 60°). Double-click = untilted. It is saved with the route of this photo. The map shows it now; the flight will show it when the viewer reads it (pending).",
         tiltLab: "TILT {x}° · {y}°", animTip: "Arrival animation: what the ship does when it reaches this camera, before its stop. Click = next one: none · orbit · dolly in · pull back · pan · roll · parallax. It plays when flying the route, when you click the row, and REC records it.",
         adurTip: "How long the arrival animation lasts (click to change: 4, 6, 8, 12, 16 s).",
         an_none: "No animation: the ship arrives and stays still (its stop).", an_orbit: "Orbit: the ship circles 90° around what it is looking at, keeping its distance (the background turns by parallax).",
         an_dolly: "Dolly in: the ship slowly moves in towards the target, down to half the distance.", an_pull: "Pull back: the ship slowly moves away from the target, out to 2.5 times the distance.",
         an_pan: "Pan: the ship stays put and the gaze sweeps 20° to one side, to the other and back.", an_roll: "Roll: a gentle tilt of up to 12° around the line of sight and back. (The viewer does not apply it yet: pending.)",
         an_parallax: "Parallax: the ship slides sideways and back with its gaze fixed: the near stars move more than the far ones, so you see the depth.",
         tipShip: "The ship, live: click to bring it back to the big screen (or press Esc).",
         dragLab: "{t} · camera {d} away", cam: "Camera {n}", hold: "{s} s", noHold: "+ stop", clear: "CLEAR ALL", sure: "SURE?",
         empty2: "No cameras yet. Click the large photo: a camera looking there. Drag: its distance. ＋ CURRENT VIEW saves the ship's.",
         empty3: "No cameras yet. Click a star or object in the large map: a camera for it. ＋ CURRENT VIEW saves the ship's.",
         up: "Move up", down: "Move down", replace: "Replace with the ship's camera now", rename: "Rename (also double-click the name)", del: "Delete this camera",
         holdTip: "Stop: how long the ship stays on this camera (click to change: none, 2, 3, 5, 8 s)", clearTip: "Delete ALL the cameras of this photo: a second click confirms.",
         rowTip: "Click = the ship goes to this camera.", flying: "ROUTE · CAMERA {i} / {n}", done: "ROUTE COMPLETE", full: "AT MOST {n} CAMERAS", noSuggest: "NOTHING TO SUGGEST IN THIS FIELD",
         go: "TRAVEL", cine: "CINEMA", warp: "WARP", from: "{d} from the ship", here: "YOU ARE HERE", tipGo: "Travel there now", tipAlt: "Travel there in the other mode",
         tab2: "TABULA: your photo. CLICK = open it large in place of the ship view, to place the cameras of a route (the ship goes to this little window; click it or press Esc to come back).",
         tab3: "PROFUNDITAS: the field in 3D (log depth). CLICK = open it large in place of the ship view, to place cameras and adjust their depth (click the little ship window or press Esc to come back)." },
   es: { ship: "NAVIS", add: "VISTA ACTUAL", play: "RECORRER LA RUTA", stop: "PARAR", suggest: "PROPONER", title: "ITINERARIUM",
         hint2: "Clic: cámara mirando ahí · arrastrar: su distancia · arrastrar una cámara: moverla", hint3: "Arrastrar: girar el 3D · rueda: zoom · clic en estrella u objeto: su cámara · arrastrar una cámara: su profundidad · asa redonda: inclinar los planos",
         tipBig2: "TABULA en grande: clic en un punto de la foto = una cámara mirando ahí (si hay una estrella u objeto junto al clic, lo toma con su distancia; si no, la nebulosa). Arrastrar desde el punto = a qué distancia de él se queda la cámara. Arrastrar una cámara numerada = moverla por la foto. Cada cámara lleva su cono; la curva dorada es la ruta. «＋ VISTA ACTUAL» guarda la cámara de la nave; «▶ RECORRER LA RUTA» las recorre en orden (REC lo graba). Esc o clic en la ventanita de la nave: volver a la nave.",
         tipBig3: "PROFUNDITAS en grande. Botón IZQUIERDO: arrastrar sobre el mapa (no sobre una cámara) = girar la vista 3D alrededor del campo (de lado = rodear, arriba/abajo = verlo desde encima o desde debajo) · rueda = zoom · doble clic en el vacío = la vista de partida. Clic sin mover (menos de 4 px) en una estrella u objeto = una cámara para él. Arrastrar una cámara numerada = su profundidad: a lo largo del eje de distancias, más lejos o más cerca de la Tierra (conserva su dirección). El asa redonda sobre la losa de la nebulosa inclina sus planos (arrastrar; doble clic en ella = sin inclinar). La curva dorada es la ruta. «▶ RECORRER LA RUTA» recorre las cámaras en orden. Esc o clic en la ventanita de la nave: volver a la nave.",
         tipTilt: "Inclinar los planos de la nebulosa: arrastrar arriba / abajo = alrededor del eje horizontal, izquierda / derecha = alrededor del vertical (hasta 60°). Doble clic = sin inclinar. Se guarda con la ruta de esta foto. El mapa ya lo enseña; el vuelo lo enseñará cuando el visor lo lea (pendiente).",
         tiltLab: "INCLINACIÓN {x}° · {y}°", animTip: "Animación de llegada: lo que hace la nave al llegar a esta cámara, antes de su parada. Clic = la siguiente: ninguna · órbita · acercamiento · alejamiento · barrido · balanceo · paralaje. Se ejecuta al recorrer la ruta, al hacer clic en la fila, y REC la graba.",
         adurTip: "Cuánto dura la animación de llegada (clic para cambiar: 4, 6, 8, 12, 16 s).",
         an_none: "Sin animación: la nave llega y se queda quieta (su parada).", an_orbit: "Órbita: la nave da un cuarto de vuelta (90°) alrededor de lo que mira, sin cambiar la distancia (el fondo gira por paralaje).",
         an_dolly: "Acercamiento: la nave se acerca despacio al objetivo, hasta la mitad de la distancia.", an_pull: "Alejamiento: la nave se aleja despacio del objetivo, hasta 2,5 veces la distancia.",
         an_pan: "Barrido: la nave no se mueve y la mirada recorre 20° a un lado, al otro y vuelve.", an_roll: "Balanceo: un giro suave de hasta 12° alrededor de la línea de mirada y vuelta. (El visor aún no lo aplica: pendiente.)",
         an_parallax: "Paralaje: la nave se desliza de lado y vuelve con la mirada fija: las estrellas cercanas se mueven más que las lejanas y se ve la profundidad.",
         tipShip: "La nave, en vivo: clic para devolverla a la pantalla grande (o Esc).",
         dragLab: "{t} · cámara a {d}", cam: "Cámara {n}", hold: "{s} s", noHold: "+ parada", clear: "BORRAR TODO", sure: "¿SEGURO?",
         empty2: "Aún no hay cámaras. Clic en la foto grande: una cámara mirando ahí. Arrastrar: su distancia. ＋ VISTA ACTUAL guarda la de la nave.",
         empty3: "Aún no hay cámaras. Clic en una estrella u objeto del mapa grande: su cámara. ＋ VISTA ACTUAL guarda la de la nave.",
         up: "Subir", down: "Bajar", replace: "Sustituir por la cámara de la nave ahora", rename: "Renombrar (también doble clic en el nombre)", del: "Borrar esta cámara",
         holdTip: "Parada: cuánto se queda la nave en esta cámara (clic para cambiar: sin parada, 2, 3, 5, 8 s)", clearTip: "Borra TODAS las cámaras de esta foto: un segundo clic lo confirma.",
         rowTip: "Clic = la nave va a esta cámara.", flying: "RUTA · CÁMARA {i} / {n}", done: "RUTA COMPLETA", full: "COMO MUCHO {n} CÁMARAS", noSuggest: "NADA QUE PROPONER EN ESTE CAMPO",
         go: "VIAJAR", cine: "CINE", warp: "WARP", from: "a {d} de la nave", here: "ESTÁS AQUÍ", tipGo: "Viajar allí ahora", tipAlt: "Viajar allí en el otro modo",
         tab2: "TABULA: tu foto. CLIC = abrirla en grande en lugar de la vista de la nave, para poner las cámaras de una ruta (la nave pasa a esta ventanita; clic en ella o Esc para volver).",
         tab3: "PROFUNDITAS: el campo en 3D (profundidad logarítmica). CLIC = abrirla en grande en lugar de la vista de la nave, para poner cámaras y ajustar su profundidad (clic en la ventanita de la nave o Esc para volver)." }
};
function fwRtT(k, o) { var s = FW_RT_TX[FW_LANG === "es" ? "es" : "en"][k] || k; if (o) for (var q in o) s = s.split("{" + q + "}").join(o[q]); return s; }

// ---------------------------------------------------------------------------
// PURO (copia de src/ui/fv_route.js): firma, JSON, camaras, duracion de un viaje, respaldo del recorrido
// ---------------------------------------------------------------------------
// (K12 H-4) firma antigua (sin escala, para recuperar las rutas ya guardadas) y nueva (con ln(F) × 100: 1 % de escala por escalon)
function fwRouteSigOld(scene) { var f = scene && scene.field; if (!f || !isFinite(f.ra) || !isFinite(f.dec)) return ""; return "r" + Math.round(f.ra * 1e4) + "_" + Math.round((f.dec + 90) * 1e4) + "_" + Math.round(f.width) + "x" + Math.round(f.height); }
function fwRouteSig(scene) { var s = fwRouteSigOld(scene), f = scene && scene.field; if (!s || !f || typeof f.F !== "number" || !isFinite(f.F) || !(f.F > 1)) return s; return s + "_s" + Math.round(100 * Math.log(f.F)); }
function fwRouteR(x) { return (isFinite(x) && x !== 0) ? Number(x.toPrecision(10)) : 0; }
// (nD2) «a»/«as» (animacion de llegada) solo si la hay y «tilt» solo si no es cero: una ruta sin nada de eso se escribe exactamente como antes
function fwRouteToJson(cams, tilt) {
   var J = { v: 1, cams: cams.map(function(c) { var o = { n: c.name || "", p: c.pos.map(fwRouteR), l: c.look.map(fwRouteR), f: fwRouteR(c.fov), h: c.holdS, t: (c.tgt || fvAdd(c.pos, c.look)).map(fwRouteR) }, an = fwRouteAnimOf(c); if (an) { o.a = an.k; o.as = an.s; } return o; }) };
   if (tilt && (tilt[0] || tilt[1])) J.tilt = [fwRouteR(tilt[0]), fwRouteR(tilt[1])];
   return JSON.stringify(J);
}
function fwRouteAnimOf(c) { var a = c && c.anim; return (a && a.k && a.k !== "none" && FW_ROUTE.ANIMS.indexOf(a.k) > 0 && a.s > 0) ? a : null; }
function fwRouteTiltFromJson(s) {
   var J = null; try { J = JSON.parse(s); } catch (e) { return [0, 0]; }
   if (!J || J.v !== 1 || !(J.tilt instanceof Array) || J.tilt.length !== 2) return [0, 0];
   var x = J.tilt[0], y = J.tilt[1], M = FW_NAV_ORBIT.TILT_MAX;
   if (typeof x !== "number" || typeof y !== "number" || !isFinite(x) || !isFinite(y)) return [0, 0];
   return [fvClamp(x, -M, M), fvClamp(y, -M, M)];
}
function fwRouteFromJson(s) {
   var out = [], J = null; try { J = JSON.parse(s); } catch (e) { return out; }
   // (K12 H-5) solo la version 1 y solo NUMEROS (un «0.7» entre comillas pasaba por coercion y reventaba despues en toFixed)
   if (!J || J.v !== 1 || !(J.cams instanceof Array)) return out;
   function num(x) { return typeof x === "number" && isFinite(x); }
   function v3(a) { return (a instanceof Array) && a.length === 3 && num(a[0]) && num(a[1]) && num(a[2]); }
   for (var i = 0; i < J.cams.length && out.length < FW_ROUTE.MAX; ++i) { var c = J.cams[i]; if (!c || !v3(c.p) || !v3(c.l) || !v3(c.t) || !num(c.f) || !(c.f > 1e-5 && c.f < 3.1)) continue;
      var cam = { name: String(c.n || ""), pos: c.p.slice(), look: fvNorm(c.l), fov: c.f, holdS: (num(c.h) && c.h >= 0) ? c.h : FW_ROUTE.HOLD0, tgt: c.t.slice() };
      if (typeof c.a === "string" && FW_ROUTE.ANIMS.indexOf(c.a) > 0) cam.anim = { k: c.a, s: (num(c.as) && c.as > 0 && c.as <= 120) ? c.as : FW_ROUTE.ANIM_S0[c.a] };   // (nD2) ruta antigua: sin animacion
      out.push(cam); }
   return out;
}
// (localStorage: por navegador y carpeta; si no hay, la ruta vive solo mientras la pagina esta abierta)
function fwRouteRead(sig) { var s = null; try { s = localStorage.getItem("fv.route." + sig); } catch (e) { s = null; } return s ? String(s) : null; }
function fwRouteWrite(sig, js) { try { localStorage.setItem("fv.route." + sig, js); return true; } catch (e) { return false; } }
// carga: la clave nueva; si no hay, la antigua y SE MIGRA (se copia a la nueva; la antigua no se borra: otra foto con el mismo centro y tamaño tambien la migra)
function fwRouteLoad(scene) {
   var sig = fwRouteSig(scene), old = fwRouteSigOld(scene), s; if (!sig) return [];
   s = fwRouteRead(sig); if (s) return fwRouteFromJson(s);
   if (old && old !== sig && (s = fwRouteRead(old))) { var cams = fwRouteFromJson(s); if (cams.length) fwRouteWrite(sig, fwRouteToJson(cams)); return cams; }
   return [];
}
function fwRouteSave(scene, cams, tilt) { var sig = fwRouteSig(scene); if (!sig) return false; return fwRouteWrite(sig, fwRouteToJson(cams, tilt)); }
// (nD2) la inclinacion: la guardada con la ruta (localStorage) o, si no hay ruta, la que trae la escena exportada por PixInsight
function fwRouteLoadTilt(scene) {
   var sig = fwRouteSig(scene), old = fwRouteSigOld(scene), s = sig ? fwRouteRead(sig) : null;
   if (!s && old && old !== sig) s = fwRouteRead(old);
   if (s) return fwRouteTiltFromJson(s);
   var t = scene && scene.nebula && scene.nebula.tilt; return (t instanceof Array && t.length === 2 && isFinite(t[0]) && isFinite(t[1])) ? [+t[0], +t[1]] : [0, 0];
}
function fwRouteApplyTilt(sc, t) { if (!sc || !sc.nebula) return; sc.nebula.tilt = [t[0], t[1]]; sc.nebula.normal = fwNavTiltNormal(t); }
function fwRouteFov() { return FW_ROUTE.FOV_DEG * FV_DEG; }
function fwRouteCamOfShip(P, name) {
   var c = P.cam, D = (P.scene && P.scene.nebula) ? P.scene.nebula.distLy : 1000, lk = fvNorm(c.look), d = 0.25 * D;
   if (lk[2] > 0.05 && c.pos[2] < D) d = fvClamp((D - c.pos[2]) / lk[2], 0.01 * D, 2 * D);
   return { name: name || "", pos: c.pos.slice(), look: lk, fov: c.fov, holdS: FW_ROUTE.HOLD0, tgt: fvAdd(c.pos, fvMul(lk, d)) };
}
function fwRouteCamAt(tgt, stand, name, fov) { var dir = fvLen(tgt) > 1e-9 ? fvNorm(tgt) : [0, 0, 1]; return { name: name || "", pos: fvSub(tgt, fvMul(dir, stand)), look: dir, fov: fov || fwRouteFov(), holdS: FW_ROUTE.HOLD0, tgt: tgt.slice() }; }
function fwRouteSelName(scene, sel) {
   if (!sel) return "";
   if (sel.kind === "object" && scene.objects && scene.objects[sel.i]) return scene.objects[sel.i].name || "";
   if (sel.kind === "nebula") return fwNebName(scene.nebula, "");
   if (sel.kind === "star") return "★ G " + scene.stars.g[sel.i].toFixed(1).replace(".", FW_LANG === "es" ? "," : ".");
   return "";
}
function fwRouteCamForSel(P, sel, stand) {
   var T = null; try { T = fvSelPos(P, sel); } catch (e) { T = null; } if (!T) return null;
   var dA = stand; if (!(dA > 0)) { try { dA = fvArriveDist(P, sel); } catch (e2) { dA = 0.05 * fvLen(T); } }
   dA = Math.min(dA, 0.95 * fvLen(T));
   var c = fwRouteCamAt(T, dA, fwRouteSelName(P.scene, sel), sel.kind === "nebula" ? FV_PILOT.ARRIVE_FOV : fwRouteFov()); c.sel = { kind: sel.kind, i: sel.i };
   return c;
}
function fwRouteNebStand(sc) { var f = sc.field, Dn = sc.nebula ? sc.nebula.distLy : 1000; if (!f || !(f.F > 0)) return FW_ROUTE.STAND_NEB * Dn; return fvClamp(0.5 * FW_ROUTE.NEB_VIEW * (f.width / f.F) * Dn / Math.tan(fwRouteFov() / 2), 1e-3 * Dn, FW_ROUTE.STAND_NEB * Dn); }
function fwRouteKeys(cams) { return cams.map(function(c) { return { pos: c.pos.slice(), look: c.look.slice(), fov: c.fov, holdS: c.holdS }; }); }
function fwRouteSamePose(P, c) { var d = fvLen(fvSub(P.cam.pos, c.pos)), ref = Math.max(1e-3, 0.002 * fvLen(c.tgt)); return d < ref && fvDot(fvNorm(P.cam.look), c.look) > Math.cos(0.5 * FV_DEG) && Math.abs(Math.log(P.cam.fov / c.fov)) < 0.02; }
// la duracion de un viaje: fvPilotFly sobre una COPIA del piloto (kind "cine" | "warp") -> { ok, s, d, kind }
function fwRouteTrip(P, sel, kind) {
   if (!P || !sel) return null; var T = null; try { T = fvSelPos(P, sel); } catch (e) { T = null; } if (!T) return null;
   var Q = {}, k; for (k in P) Q[k] = P[k];
   Q.cam = { pos: P.cam.pos.slice(), look: P.cam.look.slice(), fov: P.cam.fov }; Q.events = []; Q.free = null; Q.flight = null; Q.orbit = null; Q.coast = null; Q.lookState = null; Q.onFlightEnd = null;
   // (11-nov, NV-13) CON EL LABORATORIO la copia lleva SU estado (como fvRouteTrip de src/ui/fv_route.js tras NV-1): Q.lab era el mismo objeto que P.lab
   // y la camara copiada no traia la base (cam.B) ni S; el ensayo (fvLabFly sobre Q, cada fotograma con la ficha abierta) le quitaba a la nave de verdad el
   // «seguir mirando al destino» (L.hold) y la estrella se iba de la pantalla con su ficha abierta
   if (P.cam.B) Q.cam.B = { f: P.cam.B.f.slice(), r: P.cam.B.r.slice(), d: P.cam.B.d.slice() };
   if (P.cam.S !== undefined) Q.cam.S = P.cam.S;
   if (P.cam.roll !== undefined) Q.cam.roll = P.cam.roll;
   if (P.lab) {
      var Lc = {}, kl, vl;
      for (kl in P.lab) { vl = P.lab[kl]; Lc[kl] = Array.isArray(vl) ? vl.slice() : ((vl && typeof vl === "object" && vl.constructor === Object) ? (function(o) { var c = {}; for (var q in o) c[q] = Array.isArray(o[q]) ? o[q].slice() : o[q]; return c; })(vl) : vl); }
      Q.lab = Lc;
   }
   var ok = false; try { ok = fvPilotFly(Q, kind, sel) === true; } catch (e2) { ok = false; }
   return { ok: ok, s: (ok && Q.flight) ? Q.flight.dur : 0, d: fvLen(fvSub(T, P.cam.pos)), kind: (ok && Q.flight) ? Q.flight.kind : "" };
}
function fwRouteDur(s) { if (!(s > 0)) return "—"; if (s < 59.5) return Math.round(s) + " s"; var m = Math.floor(Math.round(s) / 60), r = Math.round(s) - 60 * m; return m + " min" + (r ? " " + r + " s" : ""); }
function fwRouteCR(p0, p1, p2, p3, t) { var t2 = t * t, t3 = t2 * t, o = [0, 0, 0]; for (var i = 0; i < 3; ++i) o[i] = 0.5 * ((2 * p1[i]) + (-p0[i] + p2[i]) * t + (2 * p0[i] - 5 * p1[i] + 4 * p2[i] - p3[i]) * t2 + (-p0[i] + 3 * p1[i] - 3 * p2[i] + p3[i]) * t3); return o; }
// (K12 H-2) la posicion del tramo p1 -> p2: la curva de fwRouteCR (Hermite con tangentes de Catmull-Rom) con cada tangente de largo <= TAN_MAX ×
// el del tramo (ver fvRouteLeg de src/ui/fv_route.js: con p1 == p2 el vecino sacaba la camara un 7 % de la distancia y la devolvia)
function fwRouteLeg(p0, p1, p2, p3, t) {
   var L = fvLen(fvSub(p2, p1)), cap = FW_ROUTE.TAN_MAX * L, m1 = [0, 0, 0], m2 = [0, 0, 0], o = [0, 0, 0], i, n1, n2;
   for (i = 0; i < 3; ++i) { m1[i] = 0.5 * (p2[i] - p0[i]); m2[i] = 0.5 * (p3[i] - p1[i]); }
   n1 = fvLen(m1); n2 = fvLen(m2);
   if (n1 > cap) m1 = fvMul(m1, cap / n1);
   if (n2 > cap) m2 = fvMul(m2, cap / n2);
   var t2 = t * t, t3 = t2 * t, h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
   for (i = 0; i < 3; ++i) o[i] = h00 * p1[i] + h10 * m1[i] + h01 * p2[i] + h11 * m2[i];
   return o;
}
function FWRoutePlay(P, keys) {
   var L = FW_ROUTE.LEG, k = (typeof fvPathDurK === "function") ? fvPathDurK(P) : ((typeof fvSpeedDurK === "function") ? fvSpeedDurK(P) : 1), i;   // (6-nov) como el motor
   this.pts = [P.cam.pos.slice()]; this.looks = [fvNorm(P.cam.look)]; this.fovs = [P.cam.fov]; this.holds = [0];
   for (i = 0; i < keys.length; ++i) { this.pts.push(keys[i].pos.slice()); this.looks.push(fvNorm(keys[i].look)); this.fovs.push(keys[i].fov); this.holds.push(keys[i].holdS || 0); }
   this.dur = [];
   for (i = 1; i < this.pts.length; ++i) {
      var d = fvLen(fvSub(this.pts[i], this.pts[i - 1])), near = Math.max(1e-3, 0.05 * Math.min(fvLen(this.pts[i]) || 1, fvLen(this.pts[i - 1]) || 1));
      var s = fvClamp(L.MIN + L.DEC * Math.log(Math.max(1, d / near)) / Math.LN10, L.MIN, L.MAX) * k;
      this.dur.push(Math.max(s, 1.875 * (fvAngle(this.looks[i - 1], this.looks[i]) / FV_DEG) / L.TURN_DPS));
   }
   this.leg = 0; this.t = 0; this.hold = false; this.done = this.dur.length === 0; this.visited = [];
}
FWRoutePlay.prototype.total = function() { var s = 0; for (var i = 0; i < this.dur.length; ++i) s += this.dur[i] + this.holds[i + 1]; return s; };
FWRoutePlay.prototype.step = function(P, dt) {
   if (this.done) return -1;
   this.t += dt; var n = this.pts.length, i = this.leg;
   while (!this.done) {
      if (!this.hold) { if (this.t < this.dur[i]) break; this.t -= this.dur[i]; this.hold = true; this.visited.push(i); }
      if (this.hold) { if (this.t < this.holds[i + 1]) break; this.t -= this.holds[i + 1]; this.hold = false; ++i; this.leg = i; if (i >= this.dur.length) { this.done = true; i = this.dur.length - 1; } }
   }
   if (this.done || this.hold) { var e = i + 1; P.cam.pos = this.pts[e].slice(); P.cam.look = this.looks[e].slice(); P.cam.fov = this.fovs[e]; return i; }
   var u = fvClamp(this.t / this.dur[i], 0, 1), x = fvSmoother(u);
   P.cam.pos = fwRouteLeg(this.pts[Math.max(0, i - 1)], this.pts[i], this.pts[i + 1], this.pts[Math.min(n - 1, i + 2)], x);
   P.cam.look = fvSlerpDir(this.looks[i], this.looks[i + 1], fvSmoother(fvClamp((u - 0.08) / 0.84, 0, 1)));
   P.cam.fov = Math.exp(Math.log(this.fovs[i]) + (Math.log(this.fovs[i + 1]) - Math.log(this.fovs[i])) * x);
   return i;
};
// (nD2, encargo E5) LA ANIMACION DE LLEGADA: copia de FVRouteAnim de src/ui/fv_route.js (misma ley, mismas constantes; ver alli el detalle)
function FWRouteAnim(P, c, a) {
   this.k = a.k; this.dur = a.s; this.t = 0; this.done = !(this.dur > 0) || FW_ROUTE.ANIMS.indexOf(a.k) <= 0;
   this.p0 = P.cam.pos.slice(); this.l0 = fvNorm(P.cam.look); this.fov = P.cam.fov;
   var T = c && c.tgt ? c.tgt.slice() : null, R = T ? fvLen(fvSub(T, this.p0)) : 0;
   if (!T || !(R > 1e-9) || fvDot(fvNorm(fvSub(T, this.p0)), this.l0) < 0.5) { R = Math.max(1e-3, 0.05 * fvLen(this.p0)); T = fvAdd(this.p0, fvMul(this.l0, R)); }
   this.T = T; this.R = R; this.B = fvBasis(this.l0, [0, 1, 0]); this.A = FW_ROUTE.ANIM;
}
FWRouteAnim.prototype.pose = function(u) {
   var e = fvSmoother(fvClamp(u, 0, 1)), A = this.A, p0 = this.p0, l0 = this.l0, T = this.T, B = this.B, k = this.k;
   if (k === "orbit") { var ang = A.ORBIT_DEG * FV_DEG * e, v = fvRotate(fvSub(p0, T), B.d, ang); return { pos: fvAdd(T, v), look: fvNorm(fvRotate(l0, B.d, ang)), roll: 0 }; }
   if (k === "dolly" || k === "pull") { var s = (k === "dolly") ? 1 - A.DOLLY_K * e : 1 + A.PULL_K * e; return { pos: fvSub(T, fvMul(fvSub(T, p0), s)), look: l0.slice(), roll: 0 }; }
   if (k === "pan") return { pos: p0.slice(), look: fvNorm(fvRotate(l0, B.d, A.PAN_DEG * FV_DEG * Math.sin(2 * Math.PI * e))), roll: 0 };
   if (k === "roll") return { pos: p0.slice(), look: l0.slice(), roll: A.ROLL_DEG * FV_DEG * Math.sin(Math.PI * e) };
   if (k === "parallax") return { pos: fvAdd(p0, fvMul(B.r, A.PARALLAX_K * this.R * Math.sin(2 * Math.PI * e))), look: l0.slice(), roll: 0 };
   return { pos: p0.slice(), look: l0.slice(), roll: 0 };
};
FWRouteAnim.prototype.step = function(P, dt) {
   if (this.done) return;
   this.t += dt;
   var u = this.t / this.dur, q = this.pose(u);
   P.cam.pos = q.pos; P.cam.look = q.look; P.cam.fov = this.fov;
   if (q.roll) P.cam.roll = q.roll; else if (P.cam.roll) P.cam.roll = 0;
   if (u >= 1) { this.done = true; P.cam.roll = 0; }
};
function fwRouteSegs(cams) {
   var segs = [], a = 0;
   for (var i = 0; i < cams.length; ++i) { var an = fwRouteAnimOf(cams[i]); if (an || i === cams.length - 1) { segs.push({ a: a, b: i, anim: an }); a = i + 1; } }
   return segs;
}
// (nD2) los iconos de las animaciones (el mismo dibujo que fvRtAnimGlyph de PixInsight) en SVG con currentColor, viewBox -6..6
function fwRtAnimSvg(kind) {
   var p = "", sw = "stroke='currentColor' stroke-width='1.3' fill='none' stroke-linecap='round'";
   function head(x, y, ux, uy, L) { var nx = -uy, ny = ux; return "<path d='M" + (x + ux * L).toFixed(2) + " " + (y + uy * L).toFixed(2) + " L" + (x - ux * L * 0.4 + nx * L * 0.75).toFixed(2) + " " + (y - uy * L * 0.4 + ny * L * 0.75).toFixed(2) + " L" + (x - ux * L * 0.4 - nx * L * 0.75).toFixed(2) + " " + (y - uy * L * 0.4 - ny * L * 0.75).toFixed(2) + " Z' fill='currentColor'/>"; }
   var S = 12, K = Math.PI / 180, i, d;
   if (kind === "orbit") { d = ""; for (i = 0; i <= 300; i += 15) d += (i ? " L" : "M") + (0.44 * S * Math.cos(i * K)).toFixed(2) + " " + (0.20 * S * Math.sin(i * K)).toFixed(2); p = "<path d='" + d + "' " + sw + "/>" + head(0.44 * S * Math.cos(300 * K), 0.20 * S * Math.sin(300 * K), 0.86, 0.5, 0.17 * S) + "<circle r='1.2' fill='currentColor'/>"; }
   else if (kind === "dolly") p = "<path d='M-5.5 0 L1 0' " + sw + "/>" + head(1.4, 0, 1, 0, 2) + "<circle cx='4.3' r='1.45' fill='currentColor'/>";
   else if (kind === "pull") p = "<circle cx='-4.3' r='1.45' fill='currentColor'/><path d='M-1.9 0 L4.3 0' " + sw + "/>" + head(4.6, 0, 1, 0, 2);
   else if (kind === "pan") p = "<path d='M-4.3 -1 L4.3 -1' " + sw + "/>" + head(4.8, -1, 1, 0, 1.9) + head(-4.8, -1, -1, 0, 1.9) + "<ellipse cx='0' cy='2.76' rx='1.92' ry='1.32' " + sw + "/><circle cx='0' cy='2.76' r='0.6' fill='currentColor'/>";
   else if (kind === "roll") { d = ""; for (i = -200; i <= 40; i += 15) d += (i > -200 ? " L" : "M") + (0.38 * S * Math.cos(i * K)).toFixed(2) + " " + (0.38 * S * Math.sin(i * K)).toFixed(2); p = "<path d='" + d + "' " + sw + "/>" + head(0.38 * S * Math.cos(40 * K), 0.38 * S * Math.sin(40 * K), -Math.sin(40 * K), Math.cos(40 * K), 2) + "<path d='M-3.1 1.2 L3.1 -1.2' " + sw + "/>"; }
   else if (kind === "parallax") p = "<circle cx='0' cy='-2.9' r='0.85' fill='currentColor'/><path d='M-1.9 -2.9 L1.9 -2.9' " + sw + "/>" + head(2.4, -2.9, 1, 0, 1.3) + head(-2.4, -2.9, -1, 0, 1.3) + "<circle cx='0' cy='2.4' r='1.55' fill='currentColor'/><path d='M-4.3 2.4 L4.3 2.4' " + sw + "/>" + head(5, 2.4, 1, 0, 1.8) + head(-5, 2.4, -1, 0, 1.8);
   else p = "<rect x='-3.1' y='-3.6' width='1.9' height='7.2' fill='currentColor'/><rect x='1.2' y='-3.6' width='1.9' height='7.2' fill='currentColor'/>";
   return "<svg viewBox='-6 -6 12 12' aria-hidden='true'>" + p + "</svg>";
}
// (nD2) el asa de inclinacion de los planos (mismo dibujo que fvRtTiltGlyph): disco, aro y arco de doble flecha
function fwRtTiltGlyph(g, x, y, S, on) {
   var col = on ? "#FFF3C4" : "#F3D27E", K = Math.PI / 180, i;
   g.fillStyle = "rgba(17,13,9,.88)"; g.beginPath(); g.arc(x, y, S, 0, 6.2832); g.fill();
   g.strokeStyle = col; g.lineWidth = Math.max(1.2, 0.16 * S); g.stroke();
   g.lineWidth = Math.max(1.1, 0.12 * S); g.beginPath(); for (i = 200; i <= 340; i += 10) { var px = x + 0.55 * S * Math.cos(i * K), py = y + 0.2 * S + 0.55 * S * Math.sin(i * K); if (i === 200) g.moveTo(px, py); else g.lineTo(px, py); } g.stroke();
   g.fillStyle = col;
   [[200, -1], [340, 1]].forEach(function(q) { var a = q[0] * K, sg = q[1], ex = x + 0.55 * S * Math.cos(a), ey = y + 0.2 * S + 0.55 * S * Math.sin(a), tx = -Math.sin(a) * sg, ty = Math.cos(a) * sg, nx = Math.cos(a), ny = Math.sin(a), L = 0.3 * S;
      g.beginPath(); g.moveTo(ex + tx * L, ey + ty * L); g.lineTo(ex + nx * L * 0.6 - tx * L * 0.3, ey + ny * L * 0.6 - ty * L * 0.3); g.lineTo(ex - nx * L * 0.6 - tx * L * 0.3, ey - ny * L * 0.6 - ty * L * 0.3); g.closePath(); g.fill(); });
   g.beginPath(); g.moveTo(x - 0.45 * S, y + 0.35 * S); g.lineTo(x + 0.45 * S, y + 0.05 * S); g.stroke();
}
// (nD2) estilos de los chips nuevos de la lista (fw_viewer.css no es de este encargo: se inyectan aqui)
var FW_RT_CSS = ".rt-sub{display:flex;align-items:center;gap:3px;max-width:100%}" +
   ".rt-anim{display:flex;align-items:center;justify-content:center;height:calc(var(--u)*.72);width:calc(var(--u)*.9);padding:0;background:none;border:1px solid rgba(163,149,123,.6);color:var(--text3);cursor:pointer}" +
   ".rt-anim svg{width:86%;height:86%}.rt-anim.on{border-color:rgba(229,181,63,.7);color:var(--gold);background:rgba(229,181,63,.14)}.rt-anim:hover{border-color:var(--gold);color:var(--gold)}" +
   ".rt-adur{background:rgba(229,181,63,.14);border:1px solid rgba(229,181,63,.7);color:var(--gold);font:italic calc(var(--u)*.5) var(--serif);padding:0 calc(var(--u)*.22);cursor:pointer;line-height:1.35}.rt-adur:hover{border-color:var(--gold)}";
function fwRtCorners(c, VW, VH) {
   var B = fvBasis(c.look, [0, 1, 0]), d = fvLen(fvSub(c.tgt, c.pos)), tx = Math.tan(c.fov / 2), ty = tx * VH / VW, out = [], S = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
   for (var i = 0; i < 4; ++i) out.push(fvAdd(c.pos, fvMul(fvAdd(B.f, fvAdd(fvMul(B.r, S[i][0] * tx), fvMul(B.d, S[i][1] * ty))), d)));
   return out;
}
// los glifos (el mismo dibujo que PixInsight: triangulos, lapiz y ⟳ de Cabra3D) en SVG con currentColor
function fwRtGlyph(kind) {
   var p = "";
   if (kind === "up") p = "<path d='M0 -4.2 L4.6 3.4 L-4.6 3.4 Z' fill='currentColor'/>";
   else if (kind === "down") p = "<path d='M0 4.2 L4.6 -3.4 L-4.6 -3.4 Z' fill='currentColor'/>";
   else if (kind === "delete") p = "<path d='M-3.6 -3.6 L3.6 3.6 M-3.6 3.6 L3.6 -3.6' stroke='currentColor' stroke-width='1.7' stroke-linecap='round'/>";
   else if (kind === "rename") p = "<path d='M-5 5 L-1.64 3.76 L5.06 -2.94 L2.94 -5.06 L-3.76 1.64 Z' fill='currentColor'/>";
   else if (kind === "replace") p = "<path d='M2.9 -2.44 A3.8 3.8 0 1 1 -2.91 -2.44' fill='none' stroke='currentColor' stroke-width='1.7'/><path d='M-0.6 -4.9 L-1.07 -0.6 L-4.75 -4.28 Z' fill='currentColor'/>";
   else if (kind === "play") p = "<path d='M-3.2 -4 L4.2 0 L-3.2 4 Z' fill='currentColor'/>";
   else if (kind === "stop") p = "<rect x='-3.2' y='-3.2' width='6.4' height='6.4' fill='currentColor'/>";
   else if (kind === "add") p = "<path d='M-4 0 L4 0 M0 -4 L0 4' stroke='currentColor' stroke-width='1.7' stroke-linecap='round'/>";
   else if (kind === "suggest") p = "<path d='M0 -4.8 L1.13 -1.13 L4.8 0 L1.13 1.13 L0 4.8 L-1.13 1.13 L-4.8 0 L-1.13 -1.13 Z' fill='currentColor'/>";
   return "<svg viewBox='-6 -6 12 12' aria-hidden='true'>" + p + "</svg>";
}

// ---------------------------------------------------------------------------
// EL CONTROLADOR. win = #win
// ---------------------------------------------------------------------------
function FWRoute(win) {
   var self = this; this.win = win; this.scene = FW.scene; this.cams = fwRouteLoad(FW.scene); this.sel = -1; this.big = null; this.play = null; this.drag = null;
   this.thumbs = {}; this.clearAsk = false; this.lastPaint = 0; this.tripAt = -1e9; this.tripKey = ""; this.renaming = -1;
   // la pantalla grande: lienzo del mapa, placa del titulo y botonera
   var bg = this.el = document.createElement("div"); bg.id = "rtBig";
   bg.innerHTML = "<canvas id='rtMap'></canvas><div class='rt-title'><b></b><i></i></div><div class='rt-bar'></div>";
   win.insertBefore(bg, document.getElementById("frame"));
   this.cv = bg.querySelector("#rtMap"); this.g = this.cv.getContext("2d"); this.bar = bg.querySelector(".rt-bar");
   ["pointerdown", "pointerup", "pointermove", "wheel", "dblclick", "click"].forEach(function(t) { bg.addEventListener(t, function(e) { e.stopPropagation(); }, { passive: t !== "wheel" }); });
   this.cv.addEventListener("pointerdown", function(e) { if (e.button !== 0) return; self.cv.setPointerCapture(e.pointerId); var q = self.xy(e); self.press(q[0], q[1]); });
   this.cv.addEventListener("pointermove", function(e) { var q = self.xy(e); self.move(q[0], q[1], e.buttons); });
   this.cv.addEventListener("pointerup", function(e) { var q = self.xy(e); self.release(q[0], q[1]); });
   // (nD2) PROFUNDITAS: la rueda = zoom de la vista; doble clic = vista de partida (vacio) o planos sin inclinar (asa)
   this.cv.addEventListener("wheel", function(e) { e.preventDefault(); var q = self.xy(e); self.wheel(q[0], q[1], -e.deltaY / 100); }, { passive: false });
   this.cv.addEventListener("dblclick", function(e) { var q = self.xy(e); self.dbl(q[0], q[1]); });
   if (!document.getElementById("fwRtCss")) { var st = document.createElement("style"); st.id = "fwRtCss"; st.textContent = FW_RT_CSS; document.head.appendChild(st); }
   // los pintores del mapa grande: los de la franja (FWNav.prototype) sobre este lienzo, con la escala de los dibujos acotada
   this.p2 = this.painter(); this.p3 = this.painter();
   // (nD2) el mapa grande de PROFUNDITAS lleva su PROPIO modelo 3D (orbitable); la franja sigue con el de gabinete (FW.nav.map)
   this.p3.map = new FWMap3D(FW.nav.scene); this.p3.map.setView(fwNavViewHome());
   this.tilt = [0, 0]; this.setTilt(fwRouteLoadTilt(FW.scene));
   // la lista en el hueco de MIRABILIA
   var wrap = document.getElementById("navListWrap"), L = this.list = document.createElement("div"); L.id = "rtList"; wrap.appendChild(L);
   ["pointerdown", "pointerup", "dblclick", "wheel"].forEach(function(t) { L.addEventListener(t, function(e) { e.stopPropagation(); }, { passive: true }); });
   // la fila de viaje de la ficha
   var card = document.getElementById("card"), ft = this.foot = document.createElement("div"); ft.id = "cardTrip"; card.appendChild(ft);
   ft.innerHTML = "<button type='button' class='ct-go'><svg viewBox='-20 -20 40 40' class='ct-ic'><g fill='none' stroke-linecap='round'></g></svg><span></span></button><button type='button' class='ct-alt'><span></span></button><span class='ct-info'></span>";
   fwIcon(ft.querySelector(".ct-ic g"), "travel");
   ["pointerdown", "pointerup", "dblclick", "click"].forEach(function(t) { ft.addEventListener(t, function(e) { e.stopPropagation(); }); });
   ft.querySelector(".ct-go").addEventListener("click", function() { self.cardGo(false); });
   ft.querySelector(".ct-alt").addEventListener("click", function() { self.cardGo(true); });
   ft.querySelector(".ct-go").title = fwRtT("tipGo"); ft.querySelector(".ct-alt").title = fwRtT("tipAlt");
   document.getElementById("nav2dWrap").title = fwRtT("tab2"); document.getElementById("nav3dWrap").title = fwRtT("tab3");
   this.trip = null;
}
// (nD2) la inclinacion de los planos: el mapa grande, el de la franja y la escena (contrato con el visor, que aun no la lee)
FWRoute.prototype.setTilt = function(t) {
   var M = FW_NAV_ORBIT.TILT_MAX; this.tilt = [fvClamp(+t[0] || 0, -M, M), fvClamp(+t[1] || 0, -M, M)];
   if (this.p3 && this.p3.map) { this.p3.map.tilt = this.tilt.slice(); this.p3.stat3 = null; }
   if (FW.nav && FW.nav.map) { FW.nav.map.tilt = this.tilt.slice(); FW.nav.stat3 = null; FW.nav.dirty = true; FW.nav.key = ""; }
   fwRouteApplyTilt(this.scene, this.tilt);
   return this.tilt;
};
FWRoute.prototype.painter = function() {
   var N = FW.nav, o = Object.create(FWNav.prototype);
   o.scene = N.scene; o.photo = N.photo; o.map = N.map; o.hooks = {}; o.c2 = o.c3 = this.cv; o.g2 = o.g3 = this.g; o.trail = []; o.thumb = null; o.stat3 = null; o.dirty = true; o.dpr = 1; o.kMax = 2;
   return o;
};
FWRoute.prototype.xy = function(e) { var b = this.cv.getBoundingClientRect(); return [(e.clientX - b.left) * this.cv.width / Math.max(1, b.width), (e.clientY - b.top) * this.cv.height / Math.max(1, b.height)]; };
// (K12 H-1) guardar = la lista acaba de cambiar: el recorrido en marcha lleva una instantanea de las camaras y se para
FWRoute.prototype.save = function() { this.stopFly("edit"); fwRouteSave(this.scene, this.cams, this.tilt); this.buildList(); };
// ---- (a) el intercambio ----
FWRoute.prototype.toggle = function(which) { if (this.big === which) this.close(); else this.open(which); return this.big; };
FWRoute.prototype.open = function(which) {
   this.big = which === "map3d" ? "map3d" : "map2d"; this.drag = null; this.clearAsk = false;
   this.win.classList.add("rtbig"); this.el.style.display = "block";
   var N = FW.nav, other = this.big === "map2d" ? "map3d" : "map2d";
   document.getElementById(this.big === "map2d" ? "nav2dCap" : "nav3dCap").textContent = fwRtT("ship");
   document.getElementById(other === "map2d" ? "nav2dCap" : "nav3dCap").textContent = fwNavT(other === "map2d" ? "tabula" : "prof");
   document.getElementById(this.big === "map2d" ? "nav2dWrap" : "nav3dWrap").title = fwRtT("tipShip");
   document.getElementById(other === "map2d" ? "nav2dWrap" : "nav3dWrap").title = fwRtT(other === "map2d" ? "tab2" : "tab3");
   document.getElementById("navList").style.display = "none"; this.list.style.display = "flex"; document.getElementById("navListCap").textContent = fwRtT("title");
   this.el.title = fwRtT(this.big === "map2d" ? "tipBig2" : "tipBig3");
   var t = this.el.querySelector(".rt-title"); t.querySelector("b").textContent = (this.big === "map2d" ? "TABULA" : "PROFUNDITAS") + " · " + fwRtT("title"); t.querySelector("i").textContent = fwRtT(this.big === "map2d" ? "hint2" : "hint3");
   N.dirty = true; this.resize(); this.buildList(); this.paint(true);
   return true;
};
FWRoute.prototype.close = function() {
   this.renameEnd(true);
   this.big = null; this.drag = null; this.clearAsk = false; this.win.classList.remove("rtbig"); this.el.style.display = "none";
   document.getElementById("nav2dCap").textContent = fwNavT("tabula"); document.getElementById("nav3dCap").textContent = fwNavT("prof");
   document.getElementById("nav2dWrap").title = fwRtT("tab2"); document.getElementById("nav3dWrap").title = fwRtT("tab3");
   document.getElementById("navList").style.display = ""; this.list.style.display = "none"; document.getElementById("navListCap").textContent = fwNavT("mir");
   FW.nav.dirty = true; FW.nav.key = "";
};
FWRoute.prototype.esc = function() { if (this.renaming >= 0) { this.renameEnd(false); return true; } if (this.big) { this.close(); return true; } if (this.play) { this.stopFly("Esc"); return true; } return false; };
// el lienzo del mapa: TABULA ocupa toda la pantalla; PROFUNDITAS, una caja con el aspecto de la pequeña (su dibujo se hizo para ese aspecto)
FWRoute.prototype.resize = function() {
   if (!this.big) return;
   var W = this.win.clientWidth, H = this.win.clientHeight, dpr = Math.min(2, window.devicePixelRatio || 1), cw = W, ch = H;
   if (this.big === "map3d") { var c3 = FW.nav.c3, a = Math.max(1, c3.clientWidth) / Math.max(1, c3.clientHeight); cw = Math.min(W, H * a * 0.96); ch = cw / a; }
   var s = this.cv.style; s.width = Math.round(cw) + "px"; s.height = Math.round(ch) + "px"; s.left = Math.round((W - cw) / 2) + "px"; s.top = Math.round((H - ch) / 2) + "px";
   var w = Math.round(cw * dpr), h = Math.round(ch * dpr); if (this.cv.width !== w || this.cv.height !== h) { this.cv.width = w; this.cv.height = h; }
   this.kc = FW_ROUTE.KB * dpr * Math.max(0.6, FW.uiK || 1);
   [this.p2, this.p3].forEach(function(p) { p.dpr = dpr; p.kMax = 1.6 * dpr * Math.max(0.6, FW.uiK || 1); p.thumb = null; p.stat3 = null; });
   this.lastPaint = 0;
};
// un punto del mundo en el lienzo del mapa grande (o null)
FWRoute.prototype.at = function(p) {
   if (this.big === "map3d") return this.p3.map.pt(p, this.cv.width, this.cv.height);
   var R = this.p2.rect2, uv = R ? fwNavPhotoUV(this.scene, p) : null; return uv ? [R[0] + uv[0] * R[2], R[1] + uv[1] * R[3]] : null;
};
// ---- pintar (en el bucle, como mucho a HZ) ----
FWRoute.prototype.paint = function(force) {
   if (!this.big) return;
   var now = performance.now(); if (!force && now - this.lastPaint < 1000 / FW_ROUTE.HZ) return; this.lastPaint = now;
   var P = FW.P, g = this.g, p = this.big === "map2d" ? this.p2 : this.p3;
   p.trail = FW.nav.trail || [];
   g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, this.cv.width, this.cv.height);
   if (this.big === "map2d") p.paint2(P, P.sel); else p.paint3(P, P.sel);
   this.paintCams(g, this.cams, 0, "B");
   if (this.drag && this.drag.kind === "new" && this.drag.moved && this.drag.cam) this.paintPreview(g);
   if (this.big === "map3d") this.paintTilt(g);                     // (nD2) el asa de inclinacion de los planos
   this.buildBar();
};
FWRoute.prototype.paintCams = function(g, cams, base, tag) {
   var kc = this.kc || 2, S = Math.max(7, 6.5 * kc), pts = [], marks = [], i, j, VW = FW.VW, VH = FW.VH;
   for (i = 0; i < cams.length; ++i) {
      var c = cams[i], on = (tag === "P") || (base + i === this.sel), apex = this.at(c.pos), tg = this.at(c.tgt), cr = fwRtCorners(c, VW, VH), q = [];
      for (j = 0; j < 4; ++j) { var qq = this.at(cr[j]); if (qq) q.push(qq); }
      if (q.length === 4) {
         g.beginPath(); g.moveTo(q[0][0], q[0][1]); for (j = 1; j < 4; ++j) g.lineTo(q[j][0], q[j][1]); g.closePath();
         g.fillStyle = on ? "rgba(255,243,196,.25)" : "rgba(243,210,126,.22)"; g.fill(); g.strokeStyle = on ? "rgba(255,243,196,.88)" : "rgba(243,210,126,.63)"; g.lineWidth = Math.max(1, (on ? 1.4 : 1) * kc); g.stroke();
         if (this.big === "map3d" && apex) { g.strokeStyle = on ? "rgba(255,243,196,.75)" : "rgba(243,210,126,.44)"; g.lineWidth = Math.max(0.8, 0.8 * kc); for (j = 0; j < 4; ++j) fwNavLine(g, apex[0], apex[1], q[j][0], q[j][1]); }
      }
      if (apex && tg && Math.abs(apex[0] - tg[0]) + Math.abs(apex[1] - tg[1]) > 3) { g.strokeStyle = "rgba(243,210,126,.56)"; g.lineWidth = Math.max(1, 0.9 * kc); g.setLineDash([3 * kc, 2 * kc]); fwNavLine(g, apex[0], apex[1], tg[0], tg[1]); g.setLineDash([]); }
      var m = apex || tg; if (m) pts.push(m); marks.push(m);
   }
   // la ruta: Catmull-Rom en el plano del mapa, a trazos, con una flecha a mitad de cada tramo
   if (pts.length > 1) {
      var Q = [], n = pts.length;
      for (i = 0; i < n - 1; ++i) for (j = (i ? 1 : 0); j <= 16; ++j) { var cc = fwRouteCR([pts[Math.max(0, i - 1)][0], pts[Math.max(0, i - 1)][1], 0], [pts[i][0], pts[i][1], 0], [pts[i + 1][0], pts[i + 1][1], 0], [pts[Math.min(n - 1, i + 2)][0], pts[Math.min(n - 1, i + 2)][1], 0], j / 16); Q.push([cc[0], cc[1], j]); }
      g.strokeStyle = "rgba(0,0,0,.75)"; g.lineWidth = Math.max(2.2, 2.6 * kc); g.beginPath(); g.moveTo(Q[0][0], Q[0][1]); for (i = 1; i < Q.length; ++i) g.lineTo(Q[i][0], Q[i][1]); g.stroke();
      g.strokeStyle = "rgba(243,210,126,.82)"; g.lineWidth = Math.max(1.2, 1.3 * kc); g.beginPath(); for (i = 1; i < Q.length; ++i) if (Math.floor(i / 2) % 2 === 0) { g.moveTo(Q[i - 1][0], Q[i - 1][1]); g.lineTo(Q[i][0], Q[i][1]); } g.stroke();
      g.fillStyle = "rgba(243,210,126,.82)";
      for (i = 1; i < Q.length; ++i) if (Q[i][2] === 8) { var dx = Q[i][0] - Q[i - 1][0], dy = Q[i][1] - Q[i - 1][1], Ln = Math.hypot(dx, dy); if (Ln < 1e-6) continue; dx /= Ln; dy /= Ln; var A = 4.2 * kc, x = Q[i][0], y = Q[i][1];
         g.beginPath(); g.moveTo(x + dx * A, y + dy * A); g.lineTo(x - dx * A * 0.6 - dy * A * 0.7, y - dy * A * 0.6 + dx * A * 0.7); g.lineTo(x - dx * A * 0.6 + dy * A * 0.7, y - dy * A * 0.6 - dx * A * 0.7); g.closePath(); g.fill(); }
   }
   g.textAlign = "center"; g.font = "600 " + Math.round(0.95 * S) + "px " + getComputedStyle(document.body).getPropertyValue("--display");
   for (i = 0; i < marks.length; ++i) if (marks[i]) {
      var on2 = (tag === "P") || (base + i === this.sel), mx = marks[i][0], my = marks[i][1];
      g.fillStyle = "rgba(17,13,9,.88)"; g.beginPath(); g.arc(mx, my, S, 0, 6.2832); g.fill();
      g.strokeStyle = on2 ? "#FFF3C4" : "#F3D27E"; g.lineWidth = Math.max(1.2, 0.16 * S); g.stroke();
      g.fillStyle = on2 ? "#FFF3C4" : "#F3D27E"; g.fillText(String(base + i + 1), mx, my + 0.36 * S);
   }
   if (tag === "B") this.marks = { pts: marks, S: S };
};
// (nD2) el asa: sobre el borde de arriba de la losa (inclinada) -> [x, y, S] | null
FWRoute.prototype.tiltHandle = function() {
   var N = this.scene.nebula, mp = this.p3.map; if (!N || !mp) return null;
   var q = mp.slabPt(mp.depth(N.distLy), 0, -1.25, this.cv.width, this.cv.height);
   return q ? [q[0], q[1], Math.max(8, 7.5 * (this.kc || 2))] : null;
};
FWRoute.prototype.hitTilt = function(x, y) { if (this.big !== "map3d") return false; var h = this.tiltHandle(); return !!h && Math.hypot(x - h[0], y - h[1]) <= 1.35 * h[2]; };
FWRoute.prototype.paintTilt = function(g) {
   var h = this.tiltHandle(); if (!h) return;
   var on = (this.drag && this.drag.kind === "tilt") || this.hoverTilt, kc = this.kc || 2;
   fwRtTiltGlyph(g, h[0], h[1], h[2], on);
   if (on || this.tilt[0] || this.tilt[1]) {
      var es = FW_LANG === "es", f = function(v) { return String(Math.round(v)).replace("-", "−"); }, lab = fwRtT("tiltLab", { x: f(this.tilt[0]), y: f(this.tilt[1]) });
      g.font = "italic " + Math.round(6 * kc) + "px " + getComputedStyle(document.body).fontFamily; g.textAlign = "left";
      var w = g.measureText(lab).width + 10, x = h[0] + h[2] + 6, y = h[1] + 4; if (x + w > this.cv.width) x = h[0] - h[2] - 6 - w;
      g.fillStyle = "rgba(17,13,9,.82)"; g.fillRect(x, y - 6 * kc - 3, w, 6 * kc + 8); g.fillStyle = on ? "#FFF3C4" : "#F3D27E"; g.fillText(lab, x + 5, y);
   }
};
FWRoute.prototype.paintPreview = function(g) {
   var d = this.drag, c = d.cam, kc = this.kc || 2; this.paintCams(g, [c], this.cams.length, "P");
   var stand = fvLen(fvSub(c.tgt, c.pos)), lab = fwRtT("dragLab", { t: d.tName || fwNavDist(fvLen(c.tgt), "measured"), d: fwNavDist(stand, "measured") });
   g.font = "italic " + Math.round(6 * kc) + "px " + getComputedStyle(document.body).fontFamily; g.textAlign = "left";
   var w = g.measureText(lab).width + 12, x = d.x1 + 14, y = d.y1 - 10; if (x + w > this.cv.width) x = d.x1 - 14 - w;
   g.fillStyle = "rgba(17,13,9,.82)"; g.fillRect(x, y - 6 * kc - 4, w, 6 * kc + 10); g.fillStyle = "#FFF3C4"; g.fillText(lab, x + 6, y);
   g.strokeStyle = "rgba(255,243,196,.75)"; g.lineWidth = 1.2; g.setLineDash([5, 4]); fwNavLine(g, d.x0, d.y0, d.x1, d.y1); g.setLineDash([]);
};
// la botonera (HTML): ＋ VISTA ACTUAL · ▶ RECORRER LA RUTA (con su duracion) / ■ PARAR · ✦ PROPONER (si hay fvTourPlan y objetos)
FWRoute.prototype.buildBar = function() {
   var n = this.cams.length, playing = !!this.play, est = n ? fwRouteDur(this.estimate()) : "";
   var key = n + "|" + playing + "|" + est + "|" + FW_LANG; if (key === this.barKey) return; this.barKey = key;
   var self = this, B = [{ id: "add", g: "add", t: fwRtT("add"), on: n < FW_ROUTE.MAX }, { id: "play", g: playing ? "stop" : "play", t: playing ? fwRtT("stop") : fwRtT("play") + (n ? " · " + est : ""), on: n > 0 || playing }];
   if (typeof fvTourPlan === "function" && this.scene.objects && this.scene.objects.length) B.push({ id: "suggest", g: "suggest", t: fwRtT("suggest"), on: true });
   this.bar.innerHTML = "";
   B.forEach(function(b) { var e = document.createElement("button"); e.type = "button"; e.className = "rt-btn"; e.disabled = !b.on; e.setAttribute("data-id", b.id); e.innerHTML = fwRtGlyph(b.g) + "<span></span>"; e.querySelector("span").textContent = b.t; e.addEventListener("click", function() { self.button(b.id); }); self.bar.appendChild(e); });
};
FWRoute.prototype.button = function(id) {
   if (id === "add") this.addCam(fwRouteCamOfShip(FW.P, ""));
   else if (id === "play") { if (this.play) this.stopFly("button"); else this.fly(); }
   else if (id === "suggest") this.suggest();
   this.paint(true);
};
// ---- (b) el raton en el mapa grande (pixeles del lienzo) ----
FWRoute.prototype.hitMark = function(x, y) { var M = this.marks, best = -1, bd = 1e9; if (!M) return -1; for (var i = 0; i < M.pts.length; ++i) { var p = M.pts[i]; if (!p) continue; var d = Math.hypot(p[0] - x, p[1] - y); if (d <= 1.3 * M.S && d < bd) { bd = d; best = i; } } return best; };
FWRoute.prototype.pickAt = function(x, y) {
   var sc = this.scene, S = sc.stars, R = FW_ROUTE.PICK_PX * (this.kc || 2) / FW_ROUTE.KB, best = null, bs = 1e9, i, q;
   if (sc.objects) for (i = 0; i < sc.objects.length; ++i) { var o = sc.objects[i]; if (!o.pos || o.main) continue; q = this.at(fwBoxMapPos(sc, o)); if (!q) continue; var dd = Math.hypot(q[0] - x, q[1] - y); if (dd < R && dd < bs) { bs = dd; best = fwNavSel(sc, { kind: "object", i: i }); } }
   if (!best) for (i = 0; i < S.n; ++i) { if (!S.inFrame[i] || S.q[i] > 1 || S.g[i] > 13) continue; q = this.at(fvStarPos(sc, i)); if (!q) continue; var e = Math.hypot(q[0] - x, q[1] - y) * (1 + 0.06 * (S.g[i] - 6)); if (e < R && e < bs) { bs = e; best = { kind: "star", i: i }; } }
   return best;
};
FWRoute.prototype.targetAt = function(x, y) {
   var sc = this.scene, s = this.pickAt(x, y);
   if (s) { var c = fwRouteCamForSel(FW.P, s); if (c) return { tgt: c.tgt, name: c.name, sel: s, stand0: fvLen(fvSub(c.tgt, c.pos)) }; }
   if (this.big !== "map2d" || !this.p2.rect2) return null;
   var R = this.p2.rect2, u = (x - R[0]) / R[2], v = (y - R[1]) / R[3], f = sc.field, Dn = sc.nebula ? sc.nebula.distLy : 1000;
   if (u < 0 || u > 1 || v < 0 || v > 1) return null;
   return { tgt: fvPixelPoint(sc, u * f.width, v * f.height, Dn), name: "", sel: null, stand0: fwRouteNebStand(sc) };
};
FWRoute.prototype.standFromDrag = function(L, dT) { var a = fvClamp(L / (0.55 * this.cv.height), 0, 1); return dT * Math.exp(Math.log(FW_ROUTE.STAND_LO) + (Math.log(FW_ROUTE.STAND_HI) - Math.log(FW_ROUTE.STAND_LO)) * a); };
FWRoute.prototype.press = function(x, y) {
   if (!this.big) return;
   if (this.big === "map3d" && this.hitTilt(x, y)) { this.drag = { kind: "tilt", x0: x, y0: y, moved: false, t0: this.tilt.slice() }; return; }   // (nD2)
   var m = this.hitMark(x, y);
   if (m >= 0) { this.sel = m; var c = this.cams[m]; this.drag = { kind: "cam", i: m, x0: x, y0: y, moved: false, c0: { pos: c.pos.slice(), look: c.look.slice(), tgt: c.tgt.slice() } }; this.buildList(); return; }
   var T = this.targetAt(x, y); this.drag = { kind: "new", x0: x, y0: y, x1: x, y1: y, moved: false, T: T, cam: null, tName: T ? T.name : "" };
   // (nD2) PROFUNDITAS: arrastrar (> ORBIT_PX) = orbitar la vista, aunque se empiece sobre una estrella; sin mover, al soltar, su camara
   if (this.big === "map3d") { var v = this.p3.map.view || fwNavViewHome(); this.drag.v0 = { az: v.az, el: v.el, zoom: v.zoom }; }
};
FWRoute.prototype.setView = function(v) { this.p3.map.setView(v); this.p3.stat3 = null; this.paint(true); };
FWRoute.prototype.wheel = function(x, y, notches) { if (this.big !== "map3d") return; var v = this.p3.map.view || fwNavViewHome(); this.setView({ az: v.az, el: v.el, zoom: v.zoom * Math.pow(FW_NAV_ORBIT.WHEEL, notches) }); };
FWRoute.prototype.dbl = function(x, y) {
   if (this.big !== "map3d") return;
   if (this.hitTilt(x, y)) { this.setTilt([0, 0]); this.save(); this.paint(true); return; }
   if (this.hitMark(x, y) < 0 && !this.pickAt(x, y)) this.setView(fwNavViewHome());
};
FWRoute.prototype.move = function(x, y, buttons) {
   var d = this.drag;
   if (!d || !buttons) {
      var ht = this.hitTilt(x, y); if (ht !== !!this.hoverTilt) { this.hoverTilt = ht; this.el.title = fwRtT(ht ? "tipTilt" : (this.big === "map2d" ? "tipBig2" : "tipBig3")); this.paint(true); }
      this.cv.style.cursor = (ht || this.hitMark(x, y) >= 0) ? "pointer" : (this.big === "map3d" ? "grab" : "crosshair"); return;
   }
   d.x1 = x; d.y1 = y; if (Math.abs(x - d.x0) + Math.abs(y - d.y0) > (this.big === "map3d" ? FW_ROUTE.ORBIT_PX : FW_ROUTE.DRAG_PX)) d.moved = true; if (!d.moved) return;
   if (d.kind === "cam") this.stopFly("edit");                // (K12 H-1) arrastrar una camara la cambia: el recorrido en marcha ya no es el de la lista
   var sc = this.scene;
   if (d.kind === "new" && this.big === "map3d") {           // (nD2) ORBITAR
      this.p3.map.setView({ az: d.v0.az + (x - d.x0) / this.cv.width * FW_NAV_ORBIT.DEG_PER_W, el: d.v0.el + (y - d.y0) / this.cv.height * FW_NAV_ORBIT.DEG_PER_H, zoom: d.v0.zoom });
      this.p3.stat3 = null; d.orbit = true; this.cv.style.cursor = "grabbing";
   } else if (d.kind === "tilt") {                           // (nD2) INCLINAR los planos
      this.setTilt([d.t0[0] - (y - d.y0) * FW_NAV_ORBIT.TILT_DEG_PX, d.t0[1] + (x - d.x0) * FW_NAV_ORBIT.TILT_DEG_PX]);
   } else if (d.kind === "new" && d.T && this.big === "map2d") { var dT = fvLen(d.T.tgt); d.cam = fwRouteCamAt(d.T.tgt, Math.min(0.95 * dT, this.standFromDrag(Math.hypot(x - d.x0, y - d.y0), dT)), d.T.name); }
   else if (d.kind === "cam") {
      var c = this.cams[d.i];
      if (this.big === "map2d") {
         var R = this.p2.rect2, u = fvClamp((x - R[0]) / R[2], 0, 1), v = fvClamp((y - R[1]) / R[3], 0, 1), f = sc.field;
         var a = fvNorm(d.c0.tgt), b = fvNorm(fvPixelRay(sc, u * f.width, v * f.height)), ax = fvCross(a, b), ang = fvAngle(a, b);
         if (fvLen(ax) > 1e-12 && ang > 1e-9) { ax = fvNorm(ax); c.pos = fvRotate(d.c0.pos, ax, ang); c.look = fvNorm(fvRotate(d.c0.look, ax, ang)); c.tgt = fvRotate(d.c0.tgt, ax, ang); }
      } else {
         // (nD2) el arrastre se proyecta sobre el eje de distancias tal como se ve (con la vista orbitable puede apuntar a cualquier lado)
         var mp = this.p3.map, w3 = this.cv.width, h3 = this.cv.height, A0 = mp.screen([0, 0, 0], w3, h3), A1 = mp.screen([1, 0, 0], w3, h3), ax = A1[0] - A0[0], ay = A1[1] - A0[1], aa = Math.max(1e-9, ax * ax + ay * ay);
         var dt0 = fvLen(d.c0.tgt), s1 = fvClamp(mp.depth(dt0) + ((x - d.x0) * ax + (y - d.y0) * ay) / aa, 0.02, 0.995);
         var k = mp.d0 * (Math.exp(s1 * Math.log(1 + mp.dMax / mp.d0)) - 1) / Math.max(1e-9, dt0); c.pos = fvMul(d.c0.pos, k); c.tgt = fvMul(d.c0.tgt, k);
      }
   }
   this.paint(true);
};
FWRoute.prototype.release = function(x, y) {
   var d = this.drag; this.drag = null; if (!d || !this.big) return;
   if (d.kind === "cam") { if (d.moved) this.save(); this.paint(true); return; }
   if (d.kind === "tilt") { if (d.moved) this.save(); this.paint(true); return; }
   if (d.orbit) { this.cv.style.cursor = "grab"; this.paint(true); return; }          // (nD2) fue orbitar: no se pone camara
   var c = null;
   if (d.moved && d.cam) c = d.cam;
   else if (!d.moved && d.T) c = d.T.sel ? fwRouteCamForSel(FW.P, d.T.sel) : fwRouteCamAt(d.T.tgt, d.T.stand0, "");
   if (c) this.addCam(c);
   this.paint(true);
};
// ---- (c) las acciones de la lista ----
FWRoute.prototype.addCam = function(c) { if (this.cams.length >= FW_ROUTE.MAX) { fwCaption(fwRtT("full", { n: FW_ROUTE.MAX }), 2.2); return -1; } this.cams.push(c); this.sel = this.cams.length - 1; this.save(); return this.sel; };
FWRoute.prototype.moveCam = function(i, delta) { var j = i + delta, a = this.cams; if (!(i >= 0 && i < a.length && j >= 0 && j < a.length)) return false; var t = a[i]; a[i] = a[j]; a[j] = t; this.sel = j; this.save(); return true; };
FWRoute.prototype.remove = function(i) { if (!(i >= 0 && i < this.cams.length)) return false; if (this.sel > i) --this.sel; /* (K12 H-3) */ this.cams.splice(i, 1); if (this.sel >= this.cams.length) this.sel = this.cams.length - 1; this.save(); return true; };
FWRoute.prototype.replace = function(i) { if (!(i >= 0 && i < this.cams.length)) return false; var o = this.cams[i], c = fwRouteCamOfShip(FW.P, o.name); c.holdS = o.holdS; this.cams[i] = c; this.sel = i; this.save(); return true; };
FWRoute.prototype.rename = function(i, s) {
   if (!(i >= 0 && i < this.cams.length)) return false;
   var nm = String(s || "").trim().substring(0, 60);
   if (nm === (this.cams[i].name || "")) return true;         // (K12 H-1) sin cambio no se guarda: abrir el campo y salir sin tocar no para el recorrido
   this.cams[i].name = nm; this.save(); return true;
};
FWRoute.prototype.cycleHold = function(i) { if (!(i >= 0 && i < this.cams.length)) return false; var H = FW_ROUTE.HOLDS, at = 0; for (var q = 0; q < H.length; ++q) if (H[q] <= this.cams[i].holdS + 1e-9) at = q; this.cams[i].holdS = H[(at + 1) % H.length]; this.save(); return true; };
// (nD2) el chip de la animacion (clic = el tipo siguiente) y el de su duracion
FWRoute.prototype.setAnim = function(i, kind, sec) {
   if (!(i >= 0 && i < this.cams.length)) return false;
   if (!kind || kind === "none" || FW_ROUTE.ANIMS.indexOf(kind) <= 0) delete this.cams[i].anim; else this.cams[i].anim = { k: kind, s: (sec > 0) ? sec : FW_ROUTE.ANIM_S0[kind] };
   this.save(); return true;
};
FWRoute.prototype.cycleAnim = function(i) { if (!(i >= 0 && i < this.cams.length)) return false; var A = FW_ROUTE.ANIMS, an = fwRouteAnimOf(this.cams[i]), at = an ? A.indexOf(an.k) : 0, nk = A[(at + 1) % A.length]; return this.setAnim(i, nk, an && nk !== "none" ? an.s : 0); };
FWRoute.prototype.cycleAnimDur = function(i) { var an = (i >= 0 && i < this.cams.length) ? fwRouteAnimOf(this.cams[i]) : null; if (!an) return false; var S = FW_ROUTE.ANIM_S, at = -1; for (var q = 0; q < S.length; ++q) if (S[q] <= an.s + 1e-9) at = q; return this.setAnim(i, an.k, S[(at + 1) % S.length]); };
FWRoute.prototype.clearAll = function() { this.cams = []; this.sel = -1; this.save(); return true; };
FWRoute.prototype.name = function(i) { var c = this.cams[i]; return (c && c.name) ? c.name : fwRtT("cam", { n: i + 1 }); };
FWRoute.prototype.suggest = function() {
   var P = FW.P, sc = this.scene; if (typeof fvTourPlan !== "function" || !sc.objects) return 0;
   var L = FW_ROUTE.LEG, k = (typeof fvPathDurK === "function") ? fvPathDurK(P) : fvSpeedDurK(P), n = 0;
   var plan = fvTourPlan(sc.objects, P.cam.pos, { maxStops: Math.min(6, FW_ROUTE.MAX - this.cams.length), maxTotalS: 240, legS: function(a, b) { var d = fvLen(fvSub(b, a)); return fvClamp(L.MIN + L.DEC * Math.log(Math.max(1, d / Math.max(1e-3, 0.05 * fvLen(b)))) / Math.LN10, L.MIN, L.MAX) * k; } });
   for (var s = 0; s < plan.stops.length; ++s) {
      var st = plan.stops[s], o = sc.objects[st.i], sel = o.main ? { kind: "nebula" } : ((o.type === "star" || o.type === "exoplanet") && o.star >= 0 ? { kind: "star", i: o.star } : { kind: "object", i: st.i });
      var c = fwRouteCamForSel(P, sel); if (!c) continue; c.holdS = Math.min(8, st.holdS || FW_ROUTE.HOLD0); if (!c.name) c.name = o.name || "";
      if (this.cams.length < FW_ROUTE.MAX) { this.cams.push(c); ++n; }
   }
   if (n) this.save(); else fwCaption(fwRtT("noSuggest"), 2.4);
   return n;
};
// ---- (d) RECORRER ----
FWRoute.prototype.estimate = function() {
   if (!this.cams.length || !FW.P) return 0;
   var t = new FWRoutePlay(FW.P, fwRouteKeys(this.cams)).total(); this.cams.forEach(function(c) { var an = fwRouteAnimOf(c); if (an) t += an.s; }); return t;
};
// (nD2) por TRAMOS, como PixInsight (fvRouteSegs): motor o respaldo hasta cada camara animada, su animacion, su parada y el siguiente
FWRoute.prototype.fly = function(from, quiet) {
   var P = FW.P, i0 = from || 0; if (!P || this.cams.length <= i0) return false;
   if (this.renaming >= 0) this.renameEnd(true);              // (K12 H-1) el renombrado pendiente se guarda ANTES (guardar para el recorrido)
   var snap = this.cams.slice(i0).map(function(c) { return { name: c.name, pos: c.pos.slice(), look: c.look.slice(), fov: c.fov, holdS: c.holdS, tgt: c.tgt.slice(), anim: c.anim ? { k: c.anim.k, s: c.anim.s } : null }; });
   FW.tour = null; if (P.flight || P.orbit) fvPilotStop(P); P.coast = null; if (typeof fvFreeHalt === "function") fvFreeHalt(P);
   FW.ck.cardHidden = true; FW.reopenAt = null; FW.arriveReopen = false;
   this.play = { engine: (typeof fvPilotFlyPath === "function") && !FW_ROUTE.FORCE_FALLBACK, i0: i0, n: snap.length, at: -1, quiet: !!quiet, last: null, snap: snap, segs: fwRouteSegs(snap), si: -1, phase: "fly", fl: null, pl: null, an: null, holdT: 0 };
   this.nextSeg();
   if (!this.play) return false;
   if (this.big) this.close();
   if (!quiet) fwCaption(fwRtT("flying", { i: 1, n: snap.length }), 2.0);
   this.barKey = ""; this.buildList();
   return true;
};
FWRoute.prototype.nextSeg = function() {
   var p = this.play, P = FW.P; if (!p) return;
   p.si += 1; p.an = null; p.fl = null; p.pl = null; p.last = null;
   if (p.si >= p.segs.length) { this.finish(); return; }
   var sg = p.segs[p.si], keys = fwRouteKeys(p.snap.slice(sg.a, sg.b + 1)), ok = false;
   if (sg.anim) keys[keys.length - 1].holdS = 0;
   p.phase = "fly";
   if (p.engine) { try { ok = fvPilotFlyPath(P, keys, { speed: P.speed, style: P.style }) !== false; } catch (e) { ok = false; console.warn("fvPilotFlyPath: " + e); } }
   if (ok) p.fl = P.flight; else { p.pl = new FWRoutePlay(P, keys); P.mode = "route"; P.arrivedAt = null; }
};
FWRoute.prototype.segEnd = function() {
   var p = this.play, P = FW.P, sg = p.segs[p.si];
   if (sg.anim) { p.phase = "anim"; p.an = new FWRouteAnim(P, p.snap[sg.b], sg.anim); P.mode = "route"; P.arrivedAt = null; p.last = null; }
   else this.nextSeg();
};
FWRoute.prototype.finish = function() {
   var p = this.play, P = FW.P; this.play = null; FW.ck.cardHidden = false;
   if (P.mode === "route") P.mode = "free"; P.cam.roll = 0; P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] }; P.vel = [0, 0, 0]; P.speedLyS = 0; P.speedC = 0;
   if (p && !p.quiet) fwCaption(fwRtT("done"), 2.2);
   this.barKey = ""; this.buildList();
};
FWRoute.prototype.playAt = function() {
   var p = this.play; if (!p || p.si < 0 || p.si >= p.segs.length) return -1;
   var sg = p.segs[p.si], k = sg.b;
   if (p.phase === "fly") { if (p.fl) k = sg.a + Math.max(0, p.fl.keyIdx !== undefined ? p.fl.keyIdx : 0); else if (p.pl) k = sg.a + Math.min(p.pl.leg, p.pl.dur.length - 1); }
   return p.i0 + k;
};
FWRoute.prototype.stopFly = function(why) {
   var p = this.play, P = FW.P; if (!p) return false;
   this.play = null; FW.ck.cardHidden = false;
   if (p.fl && P.flight && P.flight === p.fl) fvPilotStop(P);
   if (P.mode === "route") P.mode = "free"; P.cam.roll = 0; P.lookState = { x: P.cam.look.slice(), v: [0, 0, 0] };
   this.why = why || "?"; this.barKey = ""; this.buildList();
   return true;
};
FWRoute.prototype.goTo = function(k) {
   var c = this.cams[k]; if (!c) return false;
   var keep = this.cams, big = this.big; this.cams = [{ name: c.name, pos: c.pos, look: c.look, fov: c.fov, holdS: 0, tgt: c.tgt, anim: c.anim || null }]; this.big = null;   // (nD2) con su animacion de llegada
   try { this.fly(0, true); } finally { this.cams = keep; this.big = big; }
   return true;
};
// un paso del reloj (en fwStep, despues de fvPilotStep). Lo que mueva la camara por otro lado (raton, teclas, un viaje) para el recorrido.
FWRoute.prototype.step = function(P, dt) {
   var p = this.play; if (!p) return;
   if (p.phase === "fly" && p.fl) {
      if (P.flight !== p.fl) { if (P.flight || P.orbit) { this.stopFly("user"); return; } this.segEnd(); }
   } else {
      var moved = p.last && (fvLen(fvSub(P.cam.pos, p.last.pos)) > 1e-9 * (1 + fvLen(p.last.pos)) || fvAngle(P.cam.look, p.last.look) > 1e-6);
      if (P.flight || P.orbit || moved) { this.stopFly("user"); return; }
      var prev = P.cam.pos.slice();
      if (p.phase === "fly") { p.pl.step(P, dt); if (p.pl.done) this.segEnd(); }
      else if (p.phase === "anim") { p.an.step(P, dt); if (p.an.done) { p.phase = "hold"; p.holdT = p.snap[p.segs[p.si].b].holdS || 0; if (!(p.holdT > 0)) this.nextSeg(); } }
      else if (p.phase === "hold") { p.holdT -= dt; if (p.holdT <= 1e-9) this.nextSeg(); }
      if (dt > 0) { P.vel = fvMul(fvSub(P.cam.pos, prev), 1 / dt); P.speedLyS = fvLen(P.vel); P.speedC = P.speedLyS * FV_PILOT.SEC_PER_YEAR; }
      if (this.play) this.play.last = { pos: P.cam.pos.slice(), look: P.cam.look.slice() };
   }
   if (!this.play) return;
   var at = this.playAt();
   if (at >= 0 && at !== this.play.at) { this.play.at = at; if (!this.play.quiet) fwCaption(fwRtT("flying", { i: at - this.play.i0 + 1, n: this.play.n }), 2.0); this.buildList(); }
};
// ---- cada fotograma (al final de fwOverlay): la nave en su hueco, el mapa grande y la fila de la ficha ----
FWRoute.prototype.overlay = function(now) {
   if (this.big) {
      // la nave EN VIVO en el hueco del mapa grande (el fotograma de WebGL de este mismo ciclo, reducido)
      var N = FW.nav, c = this.big === "map2d" ? N.c2 : N.c3, g = this.big === "map2d" ? N.g2 : N.g3, gl = document.getElementById("gl");
      var a = gl.width / Math.max(1, gl.height), w = Math.min(c.width, c.height * a), h = w / a;
      g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = "#07060A"; g.fillRect(0, 0, c.width, c.height);
      try { g.drawImage(gl, (c.width - w) / 2, (c.height - h) / 2, w, h); } catch (e) {}
      N.key = "";                                         // la franja repinta su mapa al volver
      this.paint(false);
   }
   this.tripStep();
};
// (f) la fila de la ficha: VIAJAR con el MODUS, el otro modo, la distancia desde la nave (como mucho cada TRIP_EVERY_S de reloj)
FWRoute.prototype.tripStep = function() {
   var P = FW.P, sel = P.sel, show = !!(sel && FW.ck.cardSel && !FW.ck.cardHidden && !P.flight && !this.play);
   if (!show) { if (this.trip) { this.trip = null; this.foot.style.display = "none"; } return; }
   var gwUi = fvGwarpUi();      // (21-nov, N-galaxias-warp) un solo boton VIAJAR: el destino elige el modo; sin «otro modo»
   var key = sel.kind + ":" + sel.i + ":" + FW.mode + ":" + (P.speed || 0).toFixed(3) + ":" + P.cam.pos.map(function(v) { return v.toPrecision(5); }).join(",");
   if (this.trip && key === this.tripKey) return;
   if (this.trip && P.t - this.tripAt < FW_ROUTE.TRIP_EVERY_S && key.split(":").slice(0, 4).join(":") === this.tripKey.split(":").slice(0, 4).join(":")) return;
   var main = gwUi ? "travel" : (FW.mode === "spectacular" ? "warp" : "cine"), alt = main === "warp" ? "cine" : "warp";
   var A = fwRouteTrip(P, sel, main), B = gwUi ? null : fwRouteTrip(P, sel, alt), here = false;
   if (fvSelSameArrival(P.scene, P.arrivedAt, sel)) { try { here = fvLen(fvSub(fvSelPos(P, sel), P.cam.pos)) < 1.6 * fvArriveDist(P, sel); } catch (e) { here = false; } }
   this.trip = { d: A ? A.d : 0, sMain: A && A.ok ? A.s : 0, sAlt: B && B.ok ? B.s : 0, main: main, alt: alt, okMain: !!(A && A.ok), okAlt: !!(B && B.ok), here: here };
   this.tripKey = key; this.tripAt = P.t;
   var T = this.trip, ft = this.foot, go = ft.querySelector(".ct-go"), al = ft.querySelector(".ct-alt");
   ft.style.display = "flex";
   go.querySelector("span").textContent = fwRtT("go") + (T.okMain && !T.here ? "  " + fwRouteDur(T.sMain) : ""); go.disabled = T.here || !T.okMain;
   al.style.display = gwUi ? "none" : "";      // (N-galaxias-warp) sin «otro modo»
   al.querySelector("span").textContent = fwRtT(alt) + (T.okAlt && !T.here ? "  " + fwRouteDur(T.sAlt) : ""); al.disabled = T.here || !T.okAlt;
   ft.querySelector(".ct-info").textContent = T.here ? ((typeof FV_B5B !== "undefined" && FV_B5B.HERE && T.d > 0 && typeof fvTx === "function") ? fvTx("b5b.hereD", { d: (typeof fwNmLy === "function" ? fwNmLy(T.d) : fwNavDist(T.d, "measured")) }, FW_LANG) : fwRtT("here")) : fwRtT("from", { d: fwNavDist(T.d, "measured") });   // (Blender 5b · R5-8) «ESTAS AQUI · a 14 a.l.», como PixInsight
};
FWRoute.prototype.cardGo = function(alt) {
   var P = FW.P; if (!P.sel || P.flight) return false;
   if (FW.tour) fwTourStop();
   var k = (alt && !fvGwarpUi()) ? (FW.mode === "spectacular" ? "cine" : "warp") : null;
   var ok = fwTravel(P.sel, k); this.trip = null; this.foot.style.display = "none";
   return ok;
};
// ---- las miniaturas: ANTES del fotograma de verdad (fwLoop), una por fotograma como mucho: render con la camara, copia y el de verdad encima ----
FWRoute.prototype.thumbSig = function(c) { return c.pos.concat(c.look).map(function(v) { return v.toPrecision(7); }).join(",") + "|" + c.fov.toFixed(5); };
FWRoute.prototype.preRender = function() {
   if (!this.big || !FW.R) return false;
   for (var k = 0; k < this.cams.length; ++k) {
      var c = this.cams[k], s = this.thumbSig(c); if (this.thumbs[s]) continue;
      var gl = document.getElementById("gl"), a = gl.width / Math.max(1, gl.height), th = document.createElement("canvas"); th.height = 72; th.width = Math.round(72 * a);
      var fx = { warp: 0, flash: 0, trailSec: 0, vel: [0, 0, 0], radial: 0, zoom: 0, tunnel: 0, vp: [0, 0], time: FW.P.t, flashCol: FW_WARPFX.FLASH_COL, flashR: FW_WARPFX.FLASH_R, phase: null };
      try { FW.R.render({ cam: { pos: c.pos.slice(), look: c.look.slice(), fov: c.fov }, VW: FW.P.VW, VH: FW.P.VH, homeFov: FW.P.homeFov }, fx); var tg = th.getContext("2d"); tg.imageSmoothingQuality = "high"; tg.drawImage(gl, 0, 0, th.width, th.height); }
      catch (e) { console.warn("route thumbnail: " + e); }
      this.thumbs[s] = th; this.buildList();
      return true;
   }
   return false;
};
// ---- la lista (HTML) ----
FWRoute.prototype.buildList = function() {
   var L = this.list, self = this, n = this.cams.length, i; if (!this.big) return;
   if (this.renaming >= 0) return;                           // no se rehace con el campo de texto abierto
   var top = L.scrollTop; L.innerHTML = "";
   var hd = document.createElement("div"); hd.className = "rt-hd";
   hd.innerHTML = "<span class='rt-info'></span><button type='button' class='rt-clear'></button>";
   hd.querySelector(".rt-info").textContent = n ? n + " · " + fwRouteDur(this.estimate()) : "";
   var cl = hd.querySelector(".rt-clear"); cl.textContent = this.clearAsk ? fwRtT("sure") : fwRtT("clear"); cl.classList.toggle("ask", this.clearAsk); cl.style.visibility = n ? "visible" : "hidden"; cl.title = fwRtT("clearTip");
   cl.addEventListener("click", function() { if (!self.clearAsk) { self.clearAsk = true; self.buildList(); } else { self.clearAsk = false; self.clearAll(); } });
   cl.addEventListener("mouseleave", function() { if (self.clearAsk) { self.clearAsk = false; self.buildList(); } });
   L.appendChild(hd);
   var box = document.createElement("div"); box.className = "rt-rows"; L.appendChild(box);
   if (!n) { var e0 = document.createElement("div"); e0.className = "nv-empty"; e0.textContent = fwRtT(this.big === "map3d" ? "empty3" : "empty2"); box.appendChild(e0); return; }
   var P = FW.P, playAt = this.play ? this.playAt() : -1;
   for (i = 0; i < n; ++i) (function(k) {
      var c = self.cams[k], r = document.createElement("div"); r.className = "rt-row" + (k === self.sel ? " on" : "") + ((fwRouteSamePose(P, c) || k === playAt) ? " here" : ""); r.title = fwRtT("rowTip"); r.setAttribute("data-k", k);
      r.innerHTML = "<span class='rt-n'></span><span class='rt-th'></span><span class='rt-tx'><span class='rt-nm'></span><span class='rt-sub'><button type='button' class='rt-hold'></button><button type='button' class='rt-anim'></button><button type='button' class='rt-adur'></button></span></span><span class='rt-bt'></span>";
      r.querySelector(".rt-n").textContent = String(k + 1);
      var th = self.thumbs[self.thumbSig(c)]; if (th) { var cv = document.createElement("canvas"); cv.width = th.width; cv.height = th.height; cv.getContext("2d").drawImage(th, 0, 0); r.querySelector(".rt-th").appendChild(cv); } else r.querySelector(".rt-th").textContent = "…";
      var nm = r.querySelector(".rt-nm"); nm.textContent = self.name(k); nm.addEventListener("dblclick", function(e) { e.stopPropagation(); self.renameStart(k); });
      var hb = r.querySelector(".rt-hold"); hb.textContent = c.holdS > 0 ? fwRtT("hold", { s: c.holdS }) : fwRtT("noHold"); hb.classList.toggle("on", c.holdS > 0); hb.title = fwRtT("holdTip");
      hb.addEventListener("click", function(e) { e.stopPropagation(); self.cycleHold(k); });
      // (nD2) la animacion de llegada: el chip del tipo (icono; su tooltip dice cual es y que hace) y el de la duracion (solo si la hay)
      var an = fwRouteAnimOf(c), ab = r.querySelector(".rt-anim"), ad = r.querySelector(".rt-adur");
      ab.innerHTML = fwRtAnimSvg(an ? an.k : "none"); ab.classList.toggle("on", !!an); ab.setAttribute("data-anim", an ? an.k : "none");
      ab.title = fwRtT("an_" + (an ? an.k : "none")) + "\n\n" + fwRtT("animTip");
      ab.addEventListener("click", function(e) { e.stopPropagation(); self.cycleAnim(k); });
      if (an) { ad.textContent = fwRtT("hold", { s: an.s }); ad.title = fwRtT("adurTip"); ad.addEventListener("click", function(e) { e.stopPropagation(); self.cycleAnimDur(k); }); } else ad.style.display = "none";
      var bt = r.querySelector(".rt-bt");
      [["up", "up"], ["down", "down"], ["replace", "replace"], ["rename", "rename"], ["delete", "del"]].forEach(function(q) {
         var b = document.createElement("button"); b.type = "button"; b.className = "rt-b rt-b-" + q[0]; b.innerHTML = fwRtGlyph(q[0]); b.title = fwRtT(q[1]); b.setAttribute("data-b", q[0]);
         b.disabled = (q[0] === "up" && k === 0) || (q[0] === "down" && k === n - 1);
         b.addEventListener("click", function(e) { e.stopPropagation(); if (q[0] === "up") self.moveCam(k, -1); else if (q[0] === "down") self.moveCam(k, 1); else if (q[0] === "replace") self.replace(k); else if (q[0] === "rename") self.renameStart(k); else if (q[0] === "delete") self.remove(k); });
         bt.appendChild(b);
      });
      r.addEventListener("click", function() { self.sel = k; self.goTo(k); });
      box.appendChild(r);
   })(i);
   box.scrollTop = top;
};
FWRoute.prototype.renameStart = function(k) {
   var self = this, r = this.list.querySelector(".rt-row[data-k='" + k + "'] .rt-nm"); if (!r) return false;
   this.renaming = k; var inp = document.createElement("input"); inp.type = "text"; inp.className = "rt-edit"; inp.value = this.cams[k].name || ""; inp.maxLength = 60;
   r.textContent = ""; r.appendChild(inp); inp.focus(); inp.select();
   inp.addEventListener("click", function(e) { e.stopPropagation(); });
   inp.addEventListener("keydown", function(e) { e.stopPropagation(); if (e.key === "Enter") self.renameEnd(true); else if (e.key === "Escape") self.renameEnd(false); });
   inp.addEventListener("blur", function() { self.renameEnd(true); });
   this.edit = inp; return true;
};
FWRoute.prototype.renameEnd = function(commit) {
   if (this.renaming < 0) return; var k = this.renaming, t = this.edit ? this.edit.value : ""; this.renaming = -1; this.edit = null;
   if (commit) this.rename(k, t); else this.buildList();
};
