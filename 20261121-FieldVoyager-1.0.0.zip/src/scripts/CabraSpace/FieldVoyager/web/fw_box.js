// ============================================================================
// FieldVoyager/web/fw_box.js — LOS VIAJES NO SALEN DE LA CAJA 3D, en el visor del navegador (16-nov-2026, P23-web; docs/encargos-16nov/P23-web.md)
// ----------------------------------------------------------------------------
// Gemelo web de FV_BOX de PixInsight (src/engine/fv_objects.js, encargo A del 14-nov; informe docs/encargos-14nov/A-caja-viajes.md). Nino: «cuando hago tours o uso
// Mirabilia, hay viajes que se van fuera del voxel 3D y eso no tiene sentido» (M 82: la galaxia esta a 12,2 millones de a.l.; la caja de la escena acaba en 5 798).
// El visor ya trae el MOTOR de PixInsight (engine/fv_objects.js, fv_pilot.js, fv_flightlab.js), asi que el DESTINO y la LLEGADA salen solos de FV_BOX (la camara
// llega a la losa de la foto, o a la boca si es una estrella de mas alla). Lo que faltaba es lo que el motor no hace por el visor:
//   · PAINT  el pintor de objetos (fw_gl.js: objectsUpdate / objVolUpdate) los pintaba en su sitio de catalogo: con la camara en la losa, M 82 quedaba a
//            12 millones de a.l. y se veia como en la foto (enano), no encuadrado. Pintar el objeto a escala k = pintarlo SIN escalar desde la camara en pos / k
//            (la proyeccion no cambia con la escala): lo mismo que src/ui/fv_objects_paint.js
//   · MAP    PROFUNDITAS (3D, tambien en grande en ITINERARIUM) dibujaba M 82 en su distancia de catalogo, fuera del cono: ahora el icono va a la losa (misma linea de
//            vision) con un trazo discontinuo y el rotulo dice que su distancia real es mayor. TABULA (2D, en la foto) no cambia: una posicion y su escalada caen
//            en el mismo punto de la foto
//   · TOUR   el Tour del visor recorre MIRABILIA: no visita estrellas mas alla de la boca (como fvTourPick de PixInsight con FV_BOX.TOUR)
//   · WALLS  la media vuelta v5 alrededor de una estrella junto a una pared del cono sacaba la camara por el lateral (medido en el visor, con el pintor dando la foto
//            de verdad: 8 fotogramas fuera en la cadena y el Tour de M 82); sin media vuelta si la esfera de radio r no cabe (FV_BOX.WALLS del motor, fv_objects.js)
// FW_BOX.ON = false (o ?box=0 en la URL): lo de antes, bit a bit (FV_BOX.ON del motor tambien se apaga: el viaje a M 82 vuelve a los 12 millones de a.l.).
// Sin FV_BOX en el motor del paquete (paquete anterior al 14-nov): no hace nada. ES5.
// ============================================================================
// (16-nov, P31a) LABEL_DODGE: el rotulo de lo lejano en PROFUNDITAS («M 82 »») cambia de lado del icono cuando la flecha de la nave lo taparia (fw_nav.js, paintFarLabels3).
// false = el rotulo de siempre, fijo a la derecha del icono.
var FW_BOX = { ON: true, PAINT: true, MAP: true, TOUR: true, WALLS: true, LABEL_DODGE: true, FAR_SIG: true };
(function() { try { var q = /[?&]box=([01])/.exec(location.search); if (q) FW_BOX.ON = q[1] === "1"; } catch (e) {} })();
// enciende o apaga la caja en el visor y en el motor (FV_BOX.ON); borra los encuadres guardados de los objetos (dependen de ella)
FW_BOX.set = function(on) {
   FW_BOX.ON = !!on; if (typeof FV_BOX !== "undefined") { FV_BOX.ON = FW_BOX.ON; FV_BOX.WALLS = !!FW_BOX.WALLS; }
   try { var O = (typeof FW !== "undefined" && FW.scene) ? FW.scene.objects : null; if (O) for (var i = 0; i < O.length; ++i) O[i]._arrFit = null; } catch (e) {}
   return FW_BOX.ON;
};
if (typeof FV_BOX !== "undefined") { FV_BOX.ON = FW_BOX.ON; FV_BOX.WALLS = !!FW_BOX.WALLS; }
// ¿la caja esta en marcha? (el motor del paquete la trae y nadie la apago)
function fwBoxOn() { return !!(FW_BOX.ON && typeof FV_BOX !== "undefined" && FV_BOX.ON && typeof fvObjBoxK === "function" && typeof fvBoxDMax === "function"); }
// k < 1 si el objeto de la escena (scene.objects[i]) cae mas alla de la boca y se enseña a escala en la losa (fvObjBoxK); 1 si cabe. Una estrella no se escala
// (el motor la visita desde la boca, fvBoxArrive: fvObjectTarget la devuelve antes de mirar la caja)
function fwBoxK(sc, o) {
   if (!fwBoxOn() || !sc || !o || !o.pos) return 1;
   if ((o.type === "star" || o.type === "exoplanet") && o.star >= 0) return 1;
   return fvObjBoxK(sc, o);
}
function fwBoxPaintK(sc, o) { return FW_BOX.PAINT ? fwBoxK(sc, o) : 1; }
function fwBoxMapK(sc, o) { return FW_BOX.MAP ? fwBoxK(sc, o) : 1; }
// la posicion de un objeto para los mapas 3D: la de catalogo si cabe; escalada a la losa si cae mas alla de la boca. -> [x, y, z]
function fwBoxMapPos(sc, o) { var k = fwBoxMapK(sc, o); return k < 1 ? [o.pos[0] * k, o.pos[1] * k, o.pos[2] * k] : o.pos; }
// la posicion de un objeto para el anillo de la ficha (misma regla que el pintor)
function fwBoxPaintPos(sc, o) { var k = fwBoxPaintK(sc, o); return k < 1 ? [o.pos[0] * k, o.pos[1] * k, o.pos[2] * k] : o.pos; }
// ¿esta estrella (o lo que sea con posicion p) mas alla de la boca? Para que el Tour no la visite
function fwBoxBeyond(sc, p) { if (!fwBoxOn() || !p) return false; var d = fvBoxDMax(sc); return d > 0 && p[0] * p[0] + p[1] * p[1] + p[2] * p[2] > d * d; }
// las paradas del Tour: MIRABILIA sin las estrellas (y exoplanetas) de mas alla de la boca; si no quedara ninguna, la lista entera
function fwBoxTourItems(items) {
   if (!FW_BOX.TOUR || !fwBoxOn() || !FW.scene) return items;
   var sc = FW.scene, keep = items.filter(function(it) {
      var p = null;
      if (it.kind === "star" && it.i >= 0) p = fvStarPos(sc, it.i);
      else if (it.kind === "object" && sc.objects && sc.objects[it.i]) { var o = sc.objects[it.i]; if ((o.type === "star" || o.type === "exoplanet") && o.pos) p = o.pos; }
      return !fwBoxBeyond(sc, p);
   });
   return keep.length ? keep : items;
}
// el rotulo de un objeto de mas alla de la boca en los mapas: «M 82 » 12,2 M ly» (compacto: millones; la ficha da la cifra entera)
function fwBoxFarTxt(d) {
   var es = FW_LANG === "es", dec = es ? "," : ".", ly = es ? "a.l." : "ly";
   // (16-nov, P31b) FAR_SIG: la cifra con 3 cifras significativas como fvsFmtSig (la de la ficha y la de PixInsight, fv_nav.js fvNavFarText): 12,2 · 122 · 2,55. false = toFixed(1): 122,0 · 2,6
   if (d >= 1e9) return (FW_BOX.FAR_SIG ? fvsFmtSig(d / 1e9, 3, FW_LANG) : (d / 1e9).toFixed(1).replace(".", dec)) + (es ? " G a.l." : " Gly");
   if (d >= 1e6) return (FW_BOX.FAR_SIG ? fvsFmtSig(d / 1e6, 3, FW_LANG) : (d / 1e6).toFixed(1).replace(".", dec)) + (es ? " M a.l." : " Mly");
   return fvsFmtSig(d, 3, FW_LANG) + " " + ly;
}
var FW_BOX_TX = {
   en: { tip: " A dashed ring marks something farther than the box: it is drawn on the slab, along its line of sight, and its label gives its real distance." },
   es: { tip: " Un anillo discontinuo marca lo que está más lejos que la caja: se dibuja en la losa, en su misma línea de visión, y su rótulo da la distancia real." }
};
function fwBoxTx(k) { return FW_BOX_TX[FW_LANG === "es" ? "es" : "en"][k] || ""; }

// ============================================================================
// (16-nov-2026, P22) EL VELO DE LA LLEGADA A M 82, en el visor. Gemelo de FV_VEIL de PixInsight (src/engine/fv_objects.js; docs/encargos-16nov/P22.md): al llegar a un objeto
// escalado a la losa, la nebulosa de la losa (en el visor, el volumen) enseña el pedestal de cielo de la foto como un velo rojizo y el borde del hueco del recorte como un anillo.
// MODE 0 = lo de antes (el uniforme uVeil de fw_gl.js queda a 0: el shader no resta nada). MODE 1 = se resta el pedestal de cielo (p25 por canal, el uFogPed de la niebla).
// MODE 2 = pedestal + MARGIN niveles/255. ?veil=1|2 en la URL. DE FABRICA 0 (decision de Nino). Solo actua si fvVeilActive(escena) (hay un objeto con k < 1).
// ============================================================================
// (D6, 17-nov, DECISION DE NINO) de fabrica MODE 2; ?veil=0 devuelve lo de antes
var FW_VEIL = { MODE: 2, MARGIN: 7 };
(function() { try { var q = /[?&]veil=([012])/.exec(location.search); if (q) FW_VEIL.MODE = +q[1]; } catch (e) {} })();
// escribe en out (THREE.Vector3) lo que resta el shader de composicion; ped = THREE.Vector3 con el pedestal 0..1 (uFogPed)
function fwVeilSub(sc, ped, out) {
   var on = FW_VEIL.MODE > 0 && fwBoxOn() && typeof fvVeilActive === "function" && fvVeilActive(sc), m = (FW_VEIL.MODE === 2) ? FW_VEIL.MARGIN / 255 : 0;
   if (!on) { out.set(0, 0, 0); return false; }
   out.set(ped.x + m, ped.y + m, ped.z + m);
   return true;
}
