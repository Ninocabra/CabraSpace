// ============================================================================
// FieldVoyager/web/fw_radio.js — RADIOPHONIA del visor del navegador (4-nov-2026: DIEZ EMISORAS GENERATIVAS PROPIAS)
// ----------------------------------------------------------------------------
// La musica sale del mismo motor que la radio de PixInsight: fv_music.js (src/radio/fv_music.js, que fv_export.js copia junto a
// index.html). Diez emisoras que se componen en directo con WebAudio: ningun fichero de audio, ninguna descarga, obra propia (CC0).
// Ademas, el usuario puede añadir sus propias pistas (carpeta o ficheros sueltos, <input type=file>, blob: URL: nada sale del
// ordenador); van detras de las diez, una emisora cada una.
// Se sintoniza ARRASTRANDO el mando moleteado (una AGUJA recorre la escala fija); entre emisoras suena un soplido de estatica suave
// (ruido rosa filtrado). UN SOLO INTERRUPTOR: la lampara con engaste. La rueda sobre el mando cambia el volumen; el panel (clic en el
// rotulo RADIOPHONIA) enseña las emisoras, el volumen y las pistas propias.
// (N2 + N14) LA RADIO RESPIRA CON EL VIAJE: duck(f, tau, lowpassHz) lo llama el visor cada fotograma (fwRadioDuck en fw_viewer.js): un
// factor TEMPORAL sobre el volumen y un paso bajo. (4-nov) Ademas, la INTENSIDAD de las emisoras de a bordo sigue al viaje
// (fwRadioLevelFor: mas en warp y crucero, calma al llegar), leida aqui del piloto FW.P: el visor no tiene que llamar a nada.
// ES5.
// ============================================================================

// la intensidad que pide el viaje (la misma ley que fvRadioLevelFor de src/radio/fv_radio.js)
function fwRadioLevelFor(P, cardOpen) {
   if (!P) return 0.35;
   var fl = P.flight;
   if (fl && (fl.kind === "warp" || fl.gwHome === true)) {
      var wp = fl.warpPhase || fl.phase || "";
      if (wp === "prep" || wp === "depart") return 0.7;
      if (wp === "jump" || wp === "breath" || wp === "flash") return 0.9;
      if (wp === "cruise") return 1.0;
      return 0.75;
   }
   if (fl) {
      var u = Math.max(0, Math.min(1, fl.t / Math.max(0.01, fl.dur || 1)));
      if (u >= 0.75) return 0.75 - 0.4 * (u - 0.75) / 0.25;
      return u < 0.2 ? 0.55 : 0.75;
   }
   var home = !!(P.cam && P.cam.pos && Math.abs(P.cam.pos[0]) + Math.abs(P.cam.pos[1]) + Math.abs(P.cam.pos[2]) < 1e-6);
   return (home || cardOpen) ? 0.35 : 0.5;
}

// ---------------------------------------------------------------------------
// (19-nov, M1; Nino: «haz que la musica empiece cuando se pulsa el mando de Potentia») LA MUSICA EMPIEZA AL TIRAR DE POTENTIA.
// Antes: la radio del visor nacia APAGADA y solo sonaba tras un clic en la lampara del dial (la de PixInsight, en cambio, nace encendida a la
// espera de un gesto: R5). Ahora el clic en POTENTIA (fw_boot_ship.js: fwShipThrow) enciende la radio y sintoniza la emisora: ese clic es el
// gesto de usuario que el navegador exige para el audio, asi que suena en ese mismo instante (si el visor aun se esta armando, en cuanto la radio
// existe: FW_M1.pending). Lo del usuario manda (comodidad del navegador, localStorage; sin el, la de fabrica S2 y volumen 0,7):
//   fv.radio.power  «on» | «off»   la ultima vez que ELLA la encendio o apago con la lampara: «off» = la radio se queda apagada al tirar de POTENTIA
//   fv.radio.station  S1…S10        la ultima emisora que ELIGIO (dial, rueda o cajon)
//   fv.radio.volume  0…1            el ultimo volumen que puso
// Si POTENTIA se tira sin clic (solo a los AUTO_S s, o ?bootswitch=0) no hay gesto: la radio queda encendida y muda y el primer clic o tecla en
// cualquier sitio la reanuda (FWRadio: «kick»). Nunca suena dos veces: m1Done. ?m1=0 / FW_M1.ON = false: la de antes (apagada hasta la lampara).
// ---------------------------------------------------------------------------
var FW_M1 = { ON: true, DEFAULT_ID: "S2", KEY: "fv.radio.", pending: false, thrown: null, startedAt: null, latencyMs: null, result: null };
try { if (/[?&]m1=0/.test(location.search)) FW_M1.ON = false; } catch (eM1) {}
function fwM1Get(k) { try { return window.localStorage.getItem(FW_M1.KEY + k); } catch (e) { return null; } }
function fwM1Set(k, v) { try { window.localStorage.setItem(FW_M1.KEY + k, String(v)); } catch (e) {} }
// el clic (o el tiron automatico) en POTENTIA: why = «click» (gesto de usuario) | «auto» | «start» (sin interruptor)
function fwRadioM1(why) {
   if (!FW_M1.ON) return false;
   FW_M1.thrown = { why: why, t: performance.now(), gesture: why === "click" };
   if (typeof FW !== "undefined" && FW.radio) return FW.radio.m1Start();
   FW_M1.pending = true;                                       // el visor aun se esta armando: m1Start() al crear la radio (fw_viewer.js)
   return false;
}

// ---------------------------------------------------------------------------
// (19-nov, I5; E1-18 «sonido que informa» y E1-19 «motivo al descubrir») LA RADIO TAMBIEN INFORMA. FW_E1A.ON (?e1a=0 = lo de antes): una nota afinada a la temperatura de
// cada estrella que se SELECCIONA, un tic suave al PASAR CERCA de una estrella en pleno viaje y un motivo corto, en la tonalidad de la emisora, al LLEGAR a un objeto. Lo que
// pasa lo vigila fvE1aStep (src/engine/fv_e1a.js: el mismo que la nave de PixInsight) cada fotograma; lo que suena es del motor de la radio (fv_music.js: E1A, inform).
// Con la radio apagada, sin una emisora de a bordo sintonizada, con el interruptor del panel («Sonido que informa») en off o con la radio atenuada, NO suena nada.
// El interruptor se recuerda en localStorage fv.radio.inform (on|off; de fabrica on). FWRadio.inform(ev) -> { played, why, ... } (las pruebas leen eng.infoLog).
// ---------------------------------------------------------------------------
var FW_E1A = { ON: true, KEY: "fv.radio.inform", force: false };
try { if (/[?&]e1a=0/.test(location.search)) FW_E1A.ON = false; } catch (eE1) {}
function fwE1aGet() { try { return window.localStorage.getItem(FW_E1A.KEY); } catch (e) { return null; } }
function fwE1aSet(v) { try { window.localStorage.setItem(FW_E1A.KEY, String(v)); } catch (e) {} }

var FW_RADIO_TAP = 5;              // px: lo que puede temblar un clic sobre el dial sin que cuente como arrastre
function FWRadio(cockpit) {
   var self = this; this.ck = cockpit; this.tune = 3; this.show = 3; this.stations = []; this.on = false; this.vol = 0.7;
   this.M = (typeof FVMusic === "object") ? FVMusic : null;
   this.audio = new Audio(); this.audio.loop = true; this.audio.preload = "auto"; this.cur = -1;
   this.ctx = null; this.noiseGain = null; this.musicGain = null; this.genGain = null; this.lp = null; this.eng = null;
   this.audioF = new Audio(); this.audioF.loop = true; this.audioF.preload = "none";
   this.duckF = 1; this.duckTo = 1; this.duckTau = 0.5; this.lpHz = 18000; this.lpTo = 18000; this.duckT = performance.now();
   this.level = null; this.quiet = 0; this.userFiles = [];
   // (I5) sonido que informa: el vigilante (fv_e1a.js) y el interruptor del panel (recordado)
   this.e1a = (FW_E1A.ON && typeof fvE1aNew === "function" && typeof FV_E1A !== "undefined" && FV_E1A.ON === true && this.M && this.M.E1A && this.M.E1A.ON) ? fvE1aNew() : null;
   this.informOn = fwE1aGet() !== "off"; this.informLog = [];
   var pn = document.getElementById("radioPanel"); this.panel = pn;
   var h = "<div class='rp-h'>RADIOPHONIA · " + fwTr("STATIONS", "EMISORAS") + "</div>" +
      "<div class='rp-sub' style='margin-top:0'>" + fwTr("Ten stations composed live by the ship (generative music, no audio files, no downloads). Own work of FieldVoyager, CC0.",
                                                      "Diez emisoras que compone la nave en directo (música generativa: ni ficheros de audio ni descargas). Obra propia de FieldVoyager, CC0.") + "</div>" +
      "<div class='rp-row'><span>" + fwTr("Volume", "Volumen") + "</span> <input id='rpVol' type='range' min='0' max='1' step='0.01' value='0.7'></div>" +
      (this.e1a ? "<div class='rp-row' title='" + fwTr("A note for each star you select, tuned to its temperature (hot: high and bright, cool: low and warm; a convention, always the same), a soft tick when the ship passes close to a star, and a short motif in the station's key when you arrive at an object. Nothing plays if the radio is off or the station is not one of the ten on board.",
                                                       "Una nota por cada estrella que seleccionas, afinada a su temperatura (caliente: aguda y brillante; fría: grave y cálida; es una convención, siempre la misma), un tic suave cuando la nave pasa cerca de una estrella y un motivo corto en la tonalidad de la emisora al llegar a un objeto. No suena nada con la radio apagada ni si la emisora no es una de las diez de a bordo.").replace(/'/g, "&#39;") + "'>" +
         "<label><input id='rpInf' type='checkbox'" + (this.informOn ? " checked" : "") + "> " + fwTr("Sound that informs", "Sonido que informa") + "</label></div>" : "") +
      "<div class='rp-list' id='rpList'></div>" +
      "<div class='rp-sub'>" + fwTr("Awesome Mix (my music): add your own tracks, one station each, after the ten.", "Awesome Mix (mi música): añade tus pistas, una emisora cada una, detrás de las diez.") + "</div>" +
      "<div class='rp-row'><label class='rp-btn'>" + fwTr("Choose a music folder", "Elegir carpeta de música") + "<input id='rpDir' type='file' webkitdirectory directory multiple hidden></label>" +
      "<label class='rp-btn'>" + fwTr("Choose files", "Elegir ficheros") + "<input id='rpFiles' type='file' accept='audio/*' multiple hidden></label></div>" +
      "<button class='rp-close' id='rpClose' title='" + fwTr("Close", "Cerrar") + "'>×</button>";
   pn.innerHTML = h;
   function files(list) {
      var a = []; for (var j = 0; j < list.length; ++j) if (/^audio\//.test(list[j].type) || /\.(mp3|ogg|oga|wav|flac|m4a|aac|opus|webm)$/i.test(list[j].name)) a.push(list[j]);
      a.sort(function(p, q) { return p.name.localeCompare(q.name); });
      self.setStations(a);
   }
   document.getElementById("rpDir").addEventListener("change", function(e) { files(e.target.files); });
   document.getElementById("rpFiles").addEventListener("change", function(e) { files(e.target.files); });
   document.getElementById("rpVol").addEventListener("input", function(e) { self.setVolume(Number(e.target.value)); });
   var infBox = document.getElementById("rpInf"); if (infBox) infBox.addEventListener("change", function(e) { self.setInform(!!e.target.checked, true); });
   document.getElementById("rpClose").addEventListener("click", function() { pn.style.display = "none"; });
   cockpit.radioCap.addEventListener("click", function() { pn.style.display = (pn.style.display === "block") ? "none" : "block"; });
   // el unico interruptor: la lampara
   cockpit.lampSw.addEventListener("click", function() { self.power(!self.on); if (FW_M1.ON) fwM1Set("power", self.on ? "on" : "off"); });      // (M1) lo que ELLA deja manda al tirar de POTENTIA
   // (M1) sin gesto (POTENTIA tirado solo) la radio queda encendida y el contexto suspendido: el primer clic o tecla, donde sea, lo reanuda
   var kick = function() { if (FW_M1.ON && self.on && self.ctx && self.ctx.state === "suspended") { try { self.ctx.resume(); } catch (e) {} } };
   document.addEventListener("pointerdown", kick, true); document.addEventListener("keydown", kick, true);
   // (5-nov, Nino: «no funciona cambiar de musica con el dial») SE SINTONIZA ARRASTRANDO TODO EL DIAL, como en PixInsight: antes solo el
   // mando (~34 px) tenia el arrastre y la escala numerada no respondia (tests/radio/fw_radio_dial_cdp.js D2 en rojo). El angulo se mide
   // alrededor del CENTRO DEL MANDO (antes, el de la caja de toda la radio, desplazado por la lampara y el rotulo). Un arrastre no empieza
   // hasta que el puntero se aleja FW_RADIO_TAP px (el temblor de un clic no mueve la sintonia). La rueda: sobre el mando = volumen; sobre
   // la escala = sintonizar (Mayus: fino). La lampara (interruptor) y el rotulo (panel) conservan su clic.
   var lastA = null, dragId = null, still = false, tapX = 0, tapY = 0, nearC = false;
   function knobC() { var k = cockpit.knob.getBoundingClientRect(); return { x: k.left + k.width / 2, y: k.top + k.height / 2, u: Math.min(k.width, k.height) / 26 }; }   // u = px por unidad (el mando: radio 13)
   function ang(ev) { var c = knobC(); return Math.atan2(ev.clientX - c.x, -(ev.clientY - c.y)) * 180 / Math.PI; }
   function onDial(ev) {
      var t = ev.target; if (cockpit.lampSw.contains(t) || cockpit.radioCap.contains(t)) return -1;
      var c = knobC(), dx = (ev.clientX - c.x) / c.u, dy = (ev.clientY - c.y) / c.u, r = Math.sqrt(dx * dx + dy * dy);
      return r <= 46 ? r : -1;                                                 // dentro del bisel (radio 46, como el dial de PixInsight)
   }
   var dialG = cockpit.radioG;
   dialG.addEventListener("pointerdown", function(ev) {
      if (onDial(ev) < 0 || ev.button !== 0) return;
      ev.preventDefault(); try { dialG.setPointerCapture(ev.pointerId); } catch (e) {}
      dragId = ev.pointerId; lastA = ang(ev); still = true; tapX = ev.clientX; tapY = ev.clientY; cockpit.knob.style.cursor = "grabbing";
      var c = knobC(); nearC = Math.sqrt((ev.clientX - c.x) * (ev.clientX - c.x) + (ev.clientY - c.y) * (ev.clientY - c.y)) < 2 * FW_RADIO_TAP;   // junto al centro (px) el angulo de partida no vale
   });
   dialG.addEventListener("pointermove", function(ev) {
      if (lastA === null || ev.pointerId !== dragId) return;
      var a = ang(ev);
      if (still) { var dx = ev.clientX - tapX, dy = ev.clientY - tapY; if (dx * dx + dy * dy <= FW_RADIO_TAP * FW_RADIO_TAP) { if (nearC) lastA = a; return; } still = false; }   // lejos del centro el giro del inicio no se pierde
      var d = a - lastA; if (d > 180) d -= 360; if (d < -180) d += 360; self.tune = fvClamp(self.tune + d * 0.12, 0, 100); lastA = a; self.userTune = true;
   });
   function endDrag(ev) { if (ev.pointerId !== dragId) return; lastA = null; dragId = null; still = false; cockpit.knob.style.cursor = "grab"; }
   dialG.addEventListener("pointerup", endDrag); dialG.addEventListener("pointercancel", endDrag);
   dialG.addEventListener("wheel", function(ev) {
      var r = onDial(ev); if (r < 0) return;
      ev.preventDefault(); var up = ev.deltaY < 0;
      if (r <= 17) self.setVolume(self.vol + (up ? 0.05 : -0.05));
      else { self.tune = fvClamp(self.tune + (up ? 1 : -1) * (ev.shiftKey ? 0.25 : 1), 0, 100); self.userTune = true; }
   }, { passive: false });
   // (5-nov, Nino) el panel EMISORAS: un clic en el NOMBRE de una emisora la sintoniza (y enciende la radio si estaba apagada)
   document.getElementById("rpList").addEventListener("click", function(ev) {
      var t = ev.target; while (t && t !== this && !(t.dataset && t.dataset.i !== undefined)) t = t.parentNode;
      if (!t || t === this) return;
      var st = self.stations[Number(t.dataset.i)]; if (!st) return;
      self.tune = st.f; self.userTune = true; if (!self.on) { self.power(true); if (FW_M1.ON) fwM1Set("power", "on"); }
   });
   this.setStations([]);
}
// la emisora que suena, resaltada en la lista del panel
FWRadio.prototype.markList = function() {
   var L = document.getElementById("rpList"); if (!L) return;
   for (var i = 0; i < L.children.length; ++i) L.children[i].classList.toggle("cur", this.on && i === this.cur);
};
FWRadio.prototype.setVolume = function(v, quiet) { this.vol = fvClamp(v, 0, 1); var r = document.getElementById("rpVol"); if (r) r.value = String(this.vol); if (FW_M1.ON && !quiet) fwM1Set("volume", this.vol.toFixed(3)); this.mix(); };
// (M1) POTENTIA tirada: enciende y sintoniza (lo que ELLA dejo: apagada, emisora, volumen; si no, S2 a 0,7) y arranca el motor YA, sin esperar al
// primer fotograma del visor (update() solo corre cuando el visor esta armado). Una sola vez: m1Done.
FWRadio.prototype.m1Start = function() {
   var T = FW_M1.thrown; if (!FW_M1.ON || !T || this.m1Done) return false;
   this.m1Done = true; FW_M1.pending = false;
   if (fwM1Get("power") === "off") { FW_M1.result = "off-remembered"; return false; }          // la dejo apagada: se respeta
   var vol = parseFloat(fwM1Get("volume")); if (isFinite(vol)) this.setVolume(vol, true);
   var want = [fwM1Get("station"), FW_M1.DEFAULT_ID], k = -1, i, j;
   for (j = 0; j < want.length && k < 0; ++j) for (i = 0; i < this.stations.length; ++i) if (this.stations[i].gen !== undefined && this.stations[i].key === want[j]) { k = i; break; }
   if (k < 0) k = 0;
   var s = this.stations[k]; if (!s) { FW_M1.result = "no-stations"; return false; }
   this.tune = this.show = s.f; this.userTune = false;
   this.power(true);                                           // contexto de audio + resume() (con POTENTIA por clic: dentro del gesto)
   this.lock = 1; this.duckF = 1;
   if (this.eng && s.gen !== undefined) { this.eng.start(s.gen, this.M.onAir(s.gen)); this.cur = k; this.markList(); }
   this.mix();
   FW_M1.startedAt = performance.now(); FW_M1.latencyMs = FW_M1.startedAt - T.t; FW_M1.result = T.gesture ? "started-by-click" : "started-no-gesture"; FW_M1.station = s.key;
   return true;
};
// las emisoras: las diez de a bordo y, detras, las pistas del usuario (y las «empaquetadas», hoy ninguna)
FWRadio.prototype.setStations = function(list) {
   var dots = this.ck.stationDots; while (dots.firstChild) dots.removeChild(dots.firstChild);
   var keep = (this.cur >= 0 && this.stations[this.cur]) ? this.stations[this.cur].key : null, all = [], i, M = this.M, es = (typeof FW_LANG !== "undefined" && FW_LANG === "es");
   if (list) this.userFiles = list;
   if (M) for (i = 0; i < M.n; ++i) { var s = M.STATIONS[i]; all.push({ key: s.id, gen: i, name: (fwTr(s.name, s.es)), sub: fwTr(s.key[0], s.key[1]) + " · " + s.bpm + " bpm", tip: fwTr(s.chars[0], s.chars[1]) }); }
   (this.packaged || []).forEach(function(p) { all.push({ key: p.url, name: p.name, url: p.url }); });
   this.userFiles.forEach(function(f) { all.push({ key: "file:" + f.name, name: f.name.replace(/\.[^.]+$/, ""), file: f }); });
   this.stations = []; var n = all.length, html = "";
   for (i = 0; i < n; ++i) {
      var f = (n === 1) ? 50 : 6 + 88 * i / (n - 1), a = -150 + f * 3, p = fwPol(36.5, a), e = all[i];
      fwEl("circle", { cx: p[0], cy: p[1], r: 1.1, fill: e.gen !== undefined ? "#E0603F" : "#C99A3A" }, dots);
      e.f = f; this.stations.push(e);
      html += "<div data-i='" + i + "' title='" + String(e.tip || "").replace(/'/g, "&#39;") + "'>" + (i + 1) + " · " + e.name.replace(/[<>&]/g, "") + (e.sub ? " · <i>" + e.sub + "</i>" : "") + "</div>";
   }
   document.getElementById("rpList").innerHTML = html;
   this.cur = -1;
   if (keep) for (i = 0; i < this.stations.length; ++i) if (this.stations[i].key === keep) this.cur = i;
   this.markList();
   if (n && this.tune === 3 && this.show === 3) { this.tune = this.show = this.stations[0].f; }
};
FWRadio.prototype.ensureCtx = function() {
   if (this.ctx) return;
   var AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
   var c = new AC(); this.ctx = c;
   // ruido rosa (Voss–McCartney simplificado), filtrado: la estatica entre emisoras
   var len = c.sampleRate * 2, buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0), b0 = 0, b1 = 0, b2 = 0;
   for (var i = 0; i < len; ++i) { var w = Math.random() * 2 - 1; b0 = 0.99765 * b0 + w * 0.0990460; b1 = 0.96300 * b1 + w * 0.2965164; b2 = 0.57000 * b2 + w * 1.0526913; d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.11; }
   var src = c.createBufferSource(); src.buffer = buf; src.loop = true;
   var bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 1400; bp.Q.value = 0.6;
   this.noiseGain = c.createGain(); this.noiseGain.gain.value = 0;
   src.connect(bp); bp.connect(this.noiseGain); this.noiseGain.connect(c.destination); src.start();
   // las pistas del usuario (blob:) pasan por WebAudio con su paso bajo
   var me = c.createMediaElementSource(this.audio); this.musicGain = c.createGain(); this.musicGain.gain.value = 0;
   this.lp = c.createBiquadFilter(); this.lp.type = "lowpass"; this.lp.frequency.value = 18000; this.lp.Q.value = 0.5;
   me.connect(this.lp); this.lp.connect(this.musicGain); this.musicGain.connect(c.destination);
   // las emisoras de a bordo: el motor -> su ganancia -> salida (el paso bajo de la atenuacion lo lleva el motor)
   this.genGain = c.createGain(); this.genGain.gain.value = 0; this.genGain.connect(c.destination);
   if (this.M) { try { this.eng = this.M.create(c, this.genGain, {}); if (this.level !== null) this.eng.setLevel(this.level, true); this.eng.setInform(this.informOn); } catch (e) { this.eng = null; } }
   // (K13 H-1) update() va por requestAnimationFrame y el navegador lo PARA en una pestaña oculta (medido: 0 pasos en 12 s): la radio callaba a los
   // 0,4 s. Con la pestaña oculta un temporizador sigue al secuenciador (si el navegador lo frena a 1 s, la anticipacion de tick() se adapta).
   // Visible no hace nada: update() ya llama a tick().
   // (K14, E2) y TAMBIEN con la pestaña visible si update() lleva > 150 ms sin llegar: el bucle del visor se salta fotogramas enteros sin llamar a
   // update() (REC con el codificador lleno: `return` antes de fwOverlay; las pruebas con testHold) y la musica perdia pulsos (medido:
   // tests/radio/k14_web_flight_cdp.mjs, fase F). No arregla un hilo principal BLOQUEADO (ahi nada de JS corre): eso lo cubre la anticipacion del motor.
   if (this.eng && !this.bgTimer && typeof setInterval === "function") {
      var self = this;
      this.bgTimer = setInterval(function() {
         if (!(self.on && self.eng && self.eng.st)) return;
         var stale = self.robust !== false && (performance.now() - (self.lastUpd || 0)) > 150;
         if (document.hidden || stale) { try { self.eng.tick(); } catch (e) {} }
      }, 100);
   }
};
// (K14, pruebas) false = la radio de antes (solo la pestaña oculta tiene temporizador; el motor con 0,4 s de anticipacion): el control en rojo
FWRadio.prototype.setRobust = function(b) { this.robust = !!b; if (this.eng && typeof this.eng.setRobust === "function") this.eng.setRobust(this.robust); return this.robust; };
FWRadio.prototype.power = function(on) {
   this.on = !!on;
   if (on) { this.ensureCtx(); if (this.ctx && this.ctx.state === "suspended") this.ctx.resume(); this.cur = -1; }
   else { try { this.audio.pause(); } catch (e) {} try { this.audioF.pause(); } catch (e2) {} if (this.eng) this.eng.stop(0.25); this.cur = -1; }
   this.markList();
   if (this.ck.lampTip) this.ck.lampTip.textContent = on ? fwTr("Switch the radio off", "Apagar la radio") : fwTr("Switch the radio on", "Encender la radio");
   this.mix();
};
FWRadio.prototype.mix = function() {
   var lock = this.lock || 0, f = this.duckF, st = this.cur >= 0 ? this.stations[this.cur] : null, isGen = !!(st && st.gen !== undefined), isFile = !!(st && st.url && !st.file), v = this.on ? this.vol * lock * f : 0;
   try { this.audioF.volume = fvClamp(isFile ? v : 0, 0, 1); } catch (e) {}
   this.musicVol = v;
   if (!this.ctx) return;
   var t = this.ctx.currentTime;
   this.musicGain.gain.setTargetAtTime(st && st.file ? v : 0, t, 0.05);
   this.genGain.gain.setTargetAtTime(isGen ? v : 0, t, 0.05);
   this.noiseGain.gain.setTargetAtTime(this.on ? this.vol * 0.10 * (1 - lock) * Math.min(1, 0.3 + f) : 0, t, 0.05);
   if (this.lp) this.lp.frequency.setTargetAtTime(this.lpHz, t, 0.05);
   if (this.eng && Math.abs((this.lpSent || 0) - this.lpHz) > 20) { this.eng.setLowpass(this.lpHz, 0.05); this.lpSent = this.lpHz; }
};
// (I5) el interruptor «Sonido que informa» (byUser: lo cambio una persona en el panel: se recuerda)
FWRadio.prototype.setInform = function(b, byUser) {
   this.informOn = !!b; if (this.eng && typeof this.eng.setInform === "function") this.eng.setInform(this.informOn);
   var c = document.getElementById("rpInf"); if (c) c.checked = this.informOn;
   if (byUser) fwE1aSet(this.informOn ? "on" : "off");
   return this.informOn;
};
// (I5) un hecho que suena: ev = { kind: "star" | "pass", teff } | { kind: "motif", name }. La puerta es la de fv_music.js (la misma en PixInsight): radio encendida, interruptor, emisora
// de a bordo sintonizada, contexto sonando, radio no atenuada; si pasa, el motor lo toca con su enfriamiento. -> { played, why, ... }
FWRadio.prototype.inform = function(ev) {
   var st = this.cur >= 0 ? this.stations[this.cur] : null, M = this.M, r;
   var why = !this.e1a ? "off" : ((M && M.e1aPageWhy) ? M.e1aPageWhy({ on: this.on, sw: this.informOn, gen: !!(st && st.gen !== undefined && (this.lock || 0) > 0.3 && this.eng && this.eng.st), ctx: this.ctx ? this.ctx.state : "none", duck: this.duckF, force: FW_E1A.force }) : "no-engine");
   if (why) r = { played: false, why: why, kind: ev ? ev.kind : "" }; else r = this.eng.inform(ev);
   this.informLog.push(r); if (this.informLog.length > 100) this.informLog.shift();
   return r;
};
// (I5) cada fotograma: lo que ha pasado en la nave (seleccion, paso cerca, llegada) -> lo que hay que decir
FWRadio.prototype.e1aStep = function() {
   if (!this.e1a || typeof FW === "undefined" || !FW.P) return;
   var now = performance.now() / 1000, ev = fvE1aStep(this.e1a, FW.P), d = (typeof fvE1aRetry === "function") ? fvE1aRetry(this.e1a, now) : null;
   if (d) ev.push(d);                                              // un motivo que la radio atenuada (silencio de llegada) no dejo sonar, otra vez (hasta FV_E1A.RETRY_S s)
   for (var i = 0; i < ev.length; ++i) { var r = this.inform(ev[i]); if (typeof fvE1aDefer === "function") fvE1aDefer(this.e1a, ev[i], r, now); }
};
// (N14) el factor temporal de la radio: f objetivo (0…1), constante de tiempo tau (s) y frecuencia del paso bajo (Hz); se suaviza aqui
FWRadio.prototype.duck = function(f, tau, lowpassHz) {
   this.duckTo = fvClamp(f, 0, 1.2); this.duckTau = Math.max(0.03, tau || 0.5); this.lpTo = lowpassHz || 18000;
};
// la intensidad de las emisoras de a bordo (0-1, null = solo la composicion)
FWRadio.prototype.setLevel = function(v) { this.level = (v === null || v === undefined || !isFinite(v)) ? null : fvClamp(v, 0, 1); if (this.eng) this.eng.setLevel(this.level); };
// (N2) pistas que trae el paquete (scene.music). Desde el 4-nov ninguna: las emisoras de a bordo no necesitan ficheros
FWRadio.prototype.setPackaged = function(music) {
   if (!music || !music.length) return 0;
   this.packaged = music.map(function(m) { return { name: m.title + " · " + m.author + " · " + m.license, url: m.url }; });
   this.setStations();
   return this.packaged.length;
};
// cada fotograma: aguja, lampara, cambio de emisora, intensidad del viaje, secuenciador y mezcla
FWRadio.prototype.update = function() {
   this.lastUpd = performance.now();
   this.show += (this.tune - this.show) * 0.3;
   if (Math.abs(this.tune - this.show) < 0.01) this.show = this.tune;
   fwSetA(this.ck.needle, "transform", "rotate(" + (-150 + this.show * 3).toFixed(1) + ")");
   fwSetA(this.ck.knob, "transform", "rotate(" + (this.show * 7).toFixed(1) + ")");
   var best = -1, bd = 99;
   for (var i = 0; i < this.stations.length; ++i) { var d = Math.abs(this.stations[i].f - this.show); if (d < bd) { bd = d; best = i; } }
   var lock = best >= 0 ? Math.max(0, 1 - bd / 2.5) : 0; this.lock = lock;
   // (R5, 12-nov) la lampara encendida se distingue de la apagada aunque no haya emisora: 0,80 + 0,20·lock (antes 0,25 + 0,75·max(lock; 0,15), o sea 0,36 entre
   // emisoras) frente a 0,16 apagada; halo 0,40·lock (antes 0,35·lock; en el visor es un disco plano, sin base entre emisoras para no ensuciar). Igual que la lampara de src/radio/fv_radio.html
   fwSetA(this.ck.lamp, "opacity", (this.on ? 0.8 + 0.2 * lock : 0.16).toFixed(2));
   fwSetA(this.ck.lampHalo, "opacity", (this.on ? 0.40 * lock : 0).toFixed(2));
   if (this.on && best >= 0 && lock > 0.05 && best !== this.cur) {
      var s = this.stations[best];
      try { this.audio.pause(); } catch (e0) {} try { this.audioF.pause(); } catch (e1) {}
      if (s.gen !== undefined) { if (this.eng) this.eng.start(s.gen, this.M.onAir(s.gen)); }
      else {
         if (this.eng) this.eng.stop(0.3);
         if (s.file) { if (!s.url) s.url = URL.createObjectURL(s.file); this.audio.src = s.url; var pr = this.audio.play(); if (pr && pr.catch) pr.catch(function() {}); }
         else { this.audioF.src = s.url; var pf = this.audioF.play(); if (pf && pf.catch) pf.catch(function() {}); }
      }
      this.cur = best; this.markList();
      if (FW_M1.ON && this.userTune && s.gen !== undefined) fwM1Set("station", s.key);          // (M1) la que ELIGIO ella (no la de fabrica ni la del arranque)
   }
   // (N14) el factor sigue a su objetivo con su constante de tiempo; el filtro, en escala logaritmica
   var now = performance.now(), dt = Math.min(0.2, (now - this.duckT) / 1000), a = 1 - Math.exp(-dt / this.duckTau); this.duckT = now;
   this.duckF += (this.duckTo - this.duckF) * a; this.lpHz = Math.exp(Math.log(this.lpHz) + (Math.log(this.lpTo) - Math.log(this.lpHz)) * a);
   // la intensidad que pide el viaje (cada 0,05) y el secuenciador del motor (se para tras 3 s sin oirse entre emisoras)
   if (typeof FW !== "undefined" && FW.P) {
      var card = !!(FW.P.sel && FW.ck && FW.ck.cardOpen), lv = Math.round(fwRadioLevelFor(FW.P, card) * 20) / 20;
      if (lv !== this.level) this.setLevel(lv);
   }
   if (this.eng && this.eng.st) {
      this.quiet = (this.musicVol > 1e-3) ? 0 : this.quiet + 1;
      if (this.quiet > 180 && lock < 0.05) { this.eng.stop(0.2); this.cur = -1; } else this.eng.tick();
   }
   this.e1aStep();                                                 // (I5) sonido que informa: despues del secuenciador (ya sabe en que compas esta)
   var stt = (this.on && best >= 0 && lock > 0.4) ? "♪ " + this.stations[best].name : "";
   if (this.ck.station.__fwT !== stt) { this.ck.station.__fwT = stt; this.ck.station.textContent = stt; }
   this.mix();
};
