// ============================================================================
// FieldVoyager/web/fw_card_xp.js — LA FICHA DEL VISOR WEB: ESPECTRO XP ANIMADO (I12) Y COMPOSICION (I13), 4-nov-2026
// ----------------------------------------------------------------------------
// Gemelo de src/ui/fv_hud_xp.js (PixInsight) en canvas. SIN RED: los datos viajan en el paquete (scene.stars.meta[i].sci, la misma forma que
// fv_card_sci.js deja en PixInsight: { st, xp (compacto de ~60 puntos), chem, xpWhy, chemWhy }). Si la estrella no los trae, no sale nada.
// Necesita science/fv_sci_xp.js y fv_sci_chem.js (si no estan, nada).
//   fwCardSciLines(sel)  -> lineas para fwCardLines (la frase de la composicion, clase «phrase»)
//   fwCardSciShow(sel)   -> el bloque #cardSci de la ficha: el panel del espectro (canvas) y «MÁS ▸» con los detalles de la composicion
// El panel se anima con requestAnimationFrame mientras la ficha esta a la vista; el reloj es el de la ficha (FW.ck.cardT0).
// FW_XP_PANEL = false: sin panel (el ROJO de la prueba web).
// ES5.
// ============================================================================

var FW_XP_PANEL = true;
var FW_XP = { SWEEP_S: 2.6, START_S: 1.45, RESOLVE_S: 0.5, W: 448, H: 132, raf: 0, sel: null, more: false, t0: 0, testT: null };

function fwCardSciData(sel) {
   if (!sel || sel.kind !== "star" || !FW.scene || !FW.scene.stars) return null;
   var m = FW.scene.stars.meta[sel.i];
   return (m && m.sci && m.sci.st === "done") ? m.sci : null;
}
function fwCardSciLines(sel) {
   var D = fwCardSciData(sel);
   if (!D || !D.chem || typeof fvsChemSummary !== "function") return [];
   return [{ t: fvsChemSummary(D.chem, FW_LANG), c: "phrase chem" }];
}
function fwXpRgba(c, a) { return "rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + a + ")"; }
function fwXpStrip(l, lit) {
   var c = fvsXpWaveRgb(l), k = 0.22 + 0.68 * lit;
   if (!c) { var d = Math.round(40 + 18 * lit); return "rgb(" + d + "," + Math.round(d * 0.82) + "," + Math.round(d * 0.62) + ")"; }
   return "rgb(" + Math.round(c[0] * k) + "," + Math.round(c[1] * k) + "," + Math.round(c[2] * k) + ")";
}
function fwXpSmooth(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
function fwXpUAt(l) { var tg = (l - FVS_XP.VIEW0) / (FVS_XP.VIEW1 - FVS_XP.VIEW0), a = 0, b = 1; for (var k = 0; k < 20; ++k) { var m = 0.5 * (a + b); if (fwXpSmooth(m) < tg) a = m; else b = m; } return 0.5 * (a + b); }
function fwXpFmtT(T) { return (typeof fvsFmtTemp === "function") ? fvsFmtTemp(T, FW_LANG) : Math.round(T) + " K"; }

// el bloque de la ficha (se rehace con cada ficha)
function fwCardSciShow(sel) {
   var card = document.getElementById("card"), box = document.getElementById("cardSci");
   var D = fwCardSciData(sel), L = FW_LANG;
   if (!box) {
      box = document.createElement("div"); box.id = "cardSci";
      box.innerHTML = "<canvas id='cardXp'></canvas><div id='cardXpMsg'></div><div id='cardSciMore'><button type='button' id='cardSciBtn'></button><div id='cardSciTxt'></div></div>";
      var trip = document.getElementById("cardTrip");
      if (trip) card.insertBefore(box, trip); else card.appendChild(box);
      ["pointerdown", "pointerup", "dblclick", "click"].forEach(function(t) { box.addEventListener(t, function(e) { e.stopPropagation(); }); });
      document.getElementById("cardSciBtn").addEventListener("click", function() { FW_XP.more = !FW_XP.more; fwCardSciMore(); });
   }
   FW_XP.sel = sel; FW_XP.ref = (FW.ck && FW.ck.cardSel) || sel; FW_XP.more = false; FW_XP.D = D; FW_XP.bb = null;
   // (W1, 6-nov) MÁS dice lo MISMO que en PixInsight (C.l2 de fvCardContent, web/fw_card_pi.js): luminosidad, radio, masa, vida, color,
   // composicion, viaje y notas; sin la ficha de PixInsight, la composicion sola de antes
   FW_XP.l2 = (typeof fwCardPiMore === "function") ? fwCardPiMore(sel) : [];
   var cv = document.getElementById("cardXp"), msg = document.getElementById("cardXpMsg"), mo = document.getElementById("cardSciMore");
   if ((!D || typeof fvsXpT !== "function") && FW_XP.l2.length) { box.style.display = "block"; cv.style.display = "none"; msg.style.display = "none"; FW_XP.D = null; mo.style.display = "flex"; fwCardSciMore(); return; }
   if (!D || typeof fvsXpT !== "function") { box.style.display = "none"; return; }
   box.style.display = "block";
   var m = FW.scene.stars.meta[sel.i], teff = m.teff || 0;
   FW_XP.teff = teff;
   FW_XP.spt = "";
   // (el tipo con su clase de luminosidad, como fwCardLines: con la distancia si es fiable)
   var q = FW.scene.stars.q[sel.i];
   // (Blender 5b · R5-8.3) con la extincion del polvo, como la ficha de PixInsight (fvStarInfo, src/ui/fv_hud.js): sin ella la estrella sale mas debil y «B9.5V» donde PixInsight dice «B9.5IV»
   // (Δ = 0,508 dex sobre la secuencia principal, a solo 0,008 del corte V/IV de FVS_LC). FV_B5B.SPT false = lo de antes
   if (teff > 0 && typeof FV_B5B !== "undefined" && FV_B5B.SPT && typeof fvStarInfo === "function") { try { FW_XP.spt = fvStarInfo(FW.scene, sel.i).spt || ""; } catch (e0) { FW_XP.spt = ""; } }
   else if (teff > 0 && typeof fvsStar === "function") { try { FW_XP.spt = fvsStar({ teff: teff, G: FW.scene.stars.g[sel.i], ruwe: m.ruwe, rgeo: (q < 2 && m.distPc > 0) ? { pc: m.distPc, lo: m.lo, hi: m.hi } : undefined }).spt || ""; } catch (e) { FW_XP.spt = ""; } }
   if (D.xp && FW_XP_PANEL) {
      FW_XP.bb = fvsXpBbCurve(D.xp, teff || D.xp.fitT);                // una vez por ficha (nunca al pintar)
      cv.style.display = "block"; msg.style.display = "none";
      var dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1)) * 1.5;
      cv.width = Math.round(FW_XP.W * dpr); cv.height = Math.round(FW_XP.H * dpr); cv.style.width = FW_XP.W + "px"; cv.style.height = FW_XP.H + "px"; FW_XP.dpr = dpr;
   } else {
      cv.style.display = "none";
      var g = FW.scene.stars.g[sel.i], why = D.xpWhy || "";
      var t = (why === "skip") ? "" : ((why === "no-network" || why === "offline") ? fvsXpT(L, "xp.off") : (g > FVS_XP.GMAX ? fvsXpT(L, "xp.faint", { g: (g.toFixed(1)).replace(".", L === "es" ? "," : ".") }) : fvsXpT(L, "xp.none")));
      msg.textContent = FW_XP_PANEL ? t : ""; msg.style.display = (t && FW_XP_PANEL) ? "block" : "none";
   }
   var hasMore = FW_XP.l2.length > 0 || !!D.chem || (D.chemWhy && D.chemWhy !== "skip");
   mo.style.display = hasMore ? "flex" : "none";
   fwCardSciMore();
   if (!FW_XP.raf) FW_XP.raf = requestAnimationFrame(fwCardSciTick);
}
function fwCardSciMore() {
   var b = document.getElementById("cardSciBtn"), tx = document.getElementById("cardSciTxt"), D = FW_XP.D, L = FW_LANG;
   if (!b) return;
   var pi = FW_XP.l2 && FW_XP.l2.length > 0;
   b.textContent = pi ? fvTx(FW_XP.more ? "card.less" : "card.more", null, L) : (FW_XP.more ? (L === "es" ? "◂ MENOS" : "◂ LESS") : (L === "es" ? "COMPOSICIÓN · MÁS ▸" : "COMPOSITION · MORE ▸"));
   tx.style.display = FW_XP.more ? "block" : "none"; tx.className = pi ? "pi" : "";
   if (FW_XP.more && (D || pi)) {
      var lines = pi ? FW_XP.l2.slice() : fvsChemDetails(D.chem, L, (D.chemWhy === "no-network" || D.chemWhy === "offline") ? "off" : "");
      if (!pi && D.xp && D.xp.fitT && FW_XP.teff && Math.abs(D.xp.fitT - FW_XP.teff) / FW_XP.teff > 0.03) lines.push(fvsXpT(L, "xp.fit", { t: fwXpFmtT(D.xp.fitT) }));
      tx.innerHTML = ""; for (var i = 0; i < lines.length; ++i) { var d = document.createElement("div"); d.className = /^\s/.test(lines[i]) ? "cs-l cs-sub" : "cs-l"; d.textContent = lines[i].replace(/^\s+/, ""); tx.appendChild(d); }
   }
   // (W1, como fvCardPaint de PixInsight) con MÁS abierto y una ficha que ya no cabe en la ventana, el panel del espectro cede su sitio a los
   // detalles; con MÁS cerrado vuelve
   var cv = document.getElementById("cardXp"), card = document.getElementById("card"), win = document.getElementById("win");
   if (cv && D && D.xp && FW_XP_PANEL) {
      cv.style.display = "block";
      if (FW_XP.more && card && win && card.offsetHeight > 0) { var z = (typeof FW !== "undefined" && FW.uiK) ? FW.uiK : 1; if (card.offsetHeight * z > win.clientHeight - 94 * z) cv.style.display = "none"; }
   }
}
// el reloj: mientras la ficha se ve; para solo cuando se cierra
function fwCardSciTick() {
   FW_XP.raf = 0;
   var card = document.getElementById("card"), cv = document.getElementById("cardXp");
   if (!card || !FW_XP.sel || !FW_XP.D || !FW_XP.D.xp || !FW_XP_PANEL) return;
   if (!(FW.ck && FW.ck.cardSel === FW_XP.ref)) return;                   // otra ficha (o ninguna)
   if (card.style.display === "block") {
      var tc = (FW_XP.testT !== null) ? FW_XP.testT : (performance.now() - FW.ck.cardT0) / 1000;
      fwXpPaint(cv, FW_XP.D.xp, FW_XP.bb, tc - FW_XP.START_S);
   }
   FW_XP.raf = requestAnimationFrame(fwCardSciTick);
}
// EL PANEL (t = segundos desde que empieza el barrido)
function fwXpPaint(cv, X, bb, t) {
   var g = cv.getContext("2d"), k = FW_XP.dpr || 1, w = FW_XP.W, h = FW_XP.H, L = FW_LANG;
   g.setTransform(k, 0, 0, k, 0, 0); g.clearRect(0, 0, w, h);
   var disp = getComputedStyle(document.documentElement).getPropertyValue("--display") || "Georgia, serif", ser = getComputedStyle(document.documentElement).getPropertyValue("--serif") || "Georgia, serif";
   var V0 = FVS_XP.VIEW0, V1 = FVS_XP.VIEW1, xa = 6, xb = w - 6, top = 20, bot = h - 26, sy0 = bot + 2, sy1 = bot + 8;
   function PX(l) { return xa + (l - V0) / (V1 - V0) * (xb - xa); }
   function PY(v) { return bot - Math.max(0, Math.min(1.08, v / 1000)) * (bot - top - 22) / 1.08; }
   var u = Math.max(0, Math.min(1, t / FW_XP.SWEEP_S)), lc = V0 + (V1 - V0) * fwXpSmooth(u), going = (t >= 0 && u < 1);
   g.strokeStyle = "rgba(201,154,58,.56)"; g.lineWidth = 0.8; g.strokeRect(0.5, 0.5, w - 1, h - 1);
   g.font = "400 10px " + disp; g.fillStyle = "#BFA06A"; if ("letterSpacing" in g) g.letterSpacing = "2px";
   g.fillText(fvsXpT(L, "xp.title"), 8, 13); if ("letterSpacing" in g) g.letterSpacing = "0px";
   for (var l = 336; l < 1020; l += 4) { g.fillStyle = fwXpStrip(l + 2, (t >= 0 && l <= lc) ? 1 : 0); g.fillRect(PX(l), sy0, PX(l + 4) - PX(l) + 0.6, sy1 - sy0); }
   g.strokeStyle = "rgba(201,154,58,.44)"; g.lineWidth = 0.6; g.beginPath(); g.moveTo(xa, sy1 + 0.5); g.lineTo(xb, sy1 + 0.5); g.stroke();
   g.font = "9px ui-monospace, Consolas, monospace"; g.fillStyle = "rgba(191,160,106,.63)"; g.strokeStyle = "rgba(191,160,106,.63)";
   for (var tk = 400; tk <= 1000; tk += 100) { var tx = PX(tk); g.beginPath(); g.moveTo(tx, sy1); g.lineTo(tx, sy1 + 3); g.stroke(); var s = String(tk); g.fillText(s + (tk === 1000 ? " nm" : ""), tx - g.measureText(s).width / 2, sy1 + 13); }
   var teff = FW_XP.teff || X.fitT;
   if (fvsXpTioExpected(teff)) {
      var t0 = PX(FVS_XP.TIO[0]), t1 = PX(FVS_XP.TIO[1]), on = (t >= 0 && lc >= FVS_XP.TIO[0]);
      g.fillStyle = on ? "rgba(229,181,63,.08)" : "rgba(229,181,63,.03)"; g.fillRect(t0, top, t1 - t0, bot - top);
      g.strokeStyle = on ? "rgba(201,154,58,.38)" : "rgba(201,154,58,.19)"; g.lineWidth = 0.6; g.beginPath(); for (var hx = t0; hx < t1; hx += 5) { g.moveTo(hx, bot); g.lineTo(Math.min(t1, hx + 6), bot - 6); } g.stroke();
      g.font = "9px " + disp; g.fillStyle = on ? "rgba(191,160,106,.75)" : "rgba(191,160,106,.31)"; g.fillText(fvsXpT(L, "xp.tio"), t0 + 2, top + 9);
   }
   if (t < 0) return;
   var pts = [], j, lam;
   for (j = 0; j < X.n; ++j) { lam = fvsXpLam(X, j); if (lam > lc) break; pts.push([PX(lam), PY(X.f[j]), lam]); }
   if (j < X.n && j > 0) { var la = fvsXpLam(X, j - 1), lb = fvsXpLam(X, j), q = (lc - la) / (lb - la); pts.push([PX(lc), PY(X.f[j - 1] + (X.f[j] - X.f[j - 1]) * q), lc]); }
   if (pts.length > 1) {
      var gr = g.createLinearGradient(xa, 0, xb, 0);
      for (var sl = 340; sl <= 1040; sl += 20) { var cc = fvsXpWaveRgb(sl); gr.addColorStop((sl - V0) / (V1 - V0), cc ? fwXpRgba(cc, 0.21) : "rgba(110,90,64,.11)"); }
      g.fillStyle = gr; g.beginPath(); g.moveTo(pts[0][0], bot); for (j = 0; j < pts.length; ++j) g.lineTo(pts[j][0], pts[j][1]); g.lineTo(pts[pts.length - 1][0], bot); g.closePath(); g.fill();
      g.lineJoin = "round";
      g.strokeStyle = "rgba(217,205,180,.56)"; g.lineWidth = 1; g.beginPath(); var st = false; for (j = 0; j < pts.length; ++j) if (pts[j][2] <= 400) { if (!st) { g.moveTo(pts[j][0], pts[j][1]); st = true; } else g.lineTo(pts[j][0], pts[j][1]); } g.stroke();
      g.strokeStyle = "#F4ECDC"; g.lineWidth = 1.3; g.beginPath(); st = false; for (j = 0; j < pts.length; ++j) if (pts[j][2] >= 400) { if (!st) { g.moveTo(pts[j][0], pts[j][1]); st = true; } else g.lineTo(pts[j][0], pts[j][1]); } g.stroke();
   }
   if (bb) {
      g.setLineDash([4, 3]); g.strokeStyle = "rgba(229,181,63,.56)"; g.lineWidth = 0.9; g.beginPath();
      for (j = 0; j < X.n; ++j) { lam = fvsXpLam(X, j); if (lam > lc) break; if (j === 0) g.moveTo(PX(lam), PY(bb[j])); else g.lineTo(PX(lam), PY(bb[j])); }
      g.stroke(); g.setLineDash([]);
   }
   for (var li = 0; li < FVS_XP.LINES.length; ++li) {
      var D = FVS_XP.LINES[li], meas = null;
      for (var mi = 0; mi < (X.lines || []).length; ++mi) if (X.lines[mi].k === D.k) meas = X.lines[mi];
      var passed = lc >= D.nm, age = passed ? (t - FW_XP.SWEEP_S * fwXpUAt(D.nm)) : -1, seen = meas && meas.v === 1, a2 = !passed ? 0.22 : (age < 0.35 ? 1 : (seen ? 0.92 : 0.51)), lx = PX(D.nm);
      g.strokeStyle = "rgba(229,181,63," + a2 + ")"; g.lineWidth = (passed && age < 0.35) ? 1.4 : 0.9; g.beginPath();
      if (D.span) { var s0 = PX(D.span[0]), s1 = PX(D.span[1]); g.moveTo(s0, top + 6); g.lineTo(s0, top + 2); g.lineTo(s1, top + 2); g.lineTo(s1, top + 6); g.moveTo(PX(854.2), top + 2); g.lineTo(PX(854.2), top + 6); g.moveTo(PX(864.2), top + 2); g.lineTo(PX(864.2), top + 6); }
      else { g.moveTo(lx, top + 1); g.lineTo(lx, top + 7); }
      g.stroke();
      g.setLineDash([1, 2]); g.strokeStyle = "rgba(229,181,63," + (a2 * 0.35) + ")"; g.lineWidth = 0.6; g.beginPath(); g.moveTo(lx, top + 8); g.lineTo(lx, bot); g.stroke(); g.setLineDash([]);
      g.font = "9px " + disp; g.fillStyle = "rgba(244,236,220," + a2 + ")";
      var lbl = (seen && passed) ? fvsXpT(L, "xp.seen", { l: D.label, d: String(Math.round(meas.d / 10)) }) : D.label, lw = g.measureText(lbl).width;
      g.fillText(lbl, Math.min(xb - lw, Math.max(xa, lx - lw / 2)), top + 17);
   }
   if (going) {
      var cx = PX(lc), c0 = fvsXpWaveRgb(lc) || [229, 181, 63];
      g.fillStyle = fwXpRgba(c0, 0.06); g.fillRect(cx - 7, top, 14, sy1 - top);
      g.fillStyle = fwXpRgba(c0, 0.16); g.fillRect(cx - 2.5, top, 5, sy1 - top);
      g.strokeStyle = "rgba(243,210,126,.88)"; g.lineWidth = 1.1; g.beginPath(); g.moveTo(cx, top - 2); g.lineTo(cx, sy1 + 1); g.stroke();
      g.fillStyle = "rgba(243,210,126,.88)"; g.beginPath(); g.moveTo(cx - 3, top - 5); g.lineTo(cx + 3, top - 5); g.lineTo(cx, top - 1); g.closePath(); g.fill();
      var rd = fvsXpT(L, "xp.scan", { nm: String(Math.round(lc)) });
      g.font = "9px ui-monospace, Consolas, monospace"; g.fillStyle = "#E5B53F"; g.fillText(rd, w - 8 - g.measureText(rd).width, 13);
   } else if (u >= 1) {
      var tr = t - FW_XP.SWEEP_S, T = FW_XP.teff || X.fitT, rdS = (FW_XP.teff && FW_XP.spt) ? fvsXpT(L, "xp.read", { t: fwXpFmtT(T), spt: FW_XP.spt }) : fvsXpT(L, "xp.readNoT", { t: fwXpFmtT(X.fitT) });
      var sh = Math.max(0, Math.min(1, tr / FW_XP.RESOLVE_S)), txt = "", seed = Math.floor(t * 24);
      for (var ci = 0; ci < rdS.length; ++ci) { var ch = rdS.charAt(ci); txt += (sh < 1 && ch >= "0" && ch <= "9" && ci / rdS.length > sh) ? String(Math.floor(((Math.sin(ci * 12.9898 + seed * 78.233) * 43758.5453) % 1 + 1) % 1 * 10)) : ch; }
      g.font = "400 11px " + disp; g.fillStyle = "rgba(244,236,220," + (0.43 + 0.57 * sh) + ")"; g.fillText(txt, w - 8 - g.measureText(rdS).width, 13);
      if (bb) { var lb = "- - " + fvsXpT(L, "xp.bb", { t: fwXpFmtT(FW_XP.teff || X.fitT) }); g.font = "italic 10px " + ser; var lbw = g.measureText(lb).width; g.fillStyle = "rgba(14,11,8," + (0.67 * sh) + ")"; g.fillRect(xa + 2, bot - 15, lbw + 8, 13); g.fillStyle = "rgba(229,181,63," + (0.59 * sh) + ")"; g.fillText(lb, xa + 6, bot - 5); }
   }
}
