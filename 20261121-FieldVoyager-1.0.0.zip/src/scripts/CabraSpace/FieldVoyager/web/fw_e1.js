// ============================================================================
// FieldVoyager/web/fw_e1.js — I4 (20-nov-2026): E1-01 QUAESTIO, E1-12 balanceo de paralaje, E1-13 mirar a casa y E1-14 silencio de llegada en el visor del
// navegador, gemelo de src/ui/fv_e1_ui.js de PixInsight. El calculo es el MISMO (engine/fv_e1.js, puro); aqui solo hay lienzo, DOM y enganches.
// ----------------------------------------------------------------------------
// Va el ULTIMO en index.html (despues de fw_viewer.js) y se engancha ENVOLVIENDO funciones del visor (fwSceneFromJson, fwRenderFrame, fwOnArrive, fwOverlay,
// fwRadioDuck, fwRadioLevelFor, fwRbIds, fwRbIcon, fwRbButton, fwRbKeyDown, fwRbSync): el visor las llama por su nombre, asi que no hace falta tocar sus ficheros.
// Sin engine/fv_e1.js (un paquete viejo) no hace nada. Banderas de fabrica TRUE (las del motor: FV_E1Q, FV_E1S, FV_E1H, FV_E1Z; aqui sus alias FW_E1S…);
// ?e1q=0 ?e1s=0 ?e1h=0 ?e1z=0 las apagan (lo de antes). ?e1sforce=1: el balanceo aunque ya se hiciera con esta foto (pruebas).
//  E1-01  placa QUAESTIO en un lienzo (DOM, encima de la foto: no la desplaza): bajo la placa del arranque o, si no cabe, sobre su fila de abajo; al acabar la
//         placa del arranque (#boot.gone) revela la medida de Gaia con «IR ALLI» (viaja con fwTravel) y queda arriba al centro HUD_S s.
//  E1-12  el balanceo, solo al pintar (P.cam.pos se pone y se quita alrededor de fwRenderFrame), una vez por foto (localStorage), cualquier tecla o clic lo salta, Y lo repite.
//  E1-13  boton CASA (catalejo) en la columna derecha + tecla U: fvPilotLookHome del motor + la placa del Sol (la web no la tenia).
//  E1-14  silencio de llegada: al llegar a un objeto principal, DUR_S s con la radio atenuada y a una capa.
// ============================================================================
var FW_E1_OK = (typeof FV_E1Q !== "undefined" && typeof fvE1qPick === "function" && typeof fvE1Tx === "function");
var FW_E1S = FW_E1_OK ? FV_E1S : { ON: false }, FW_E1H = FW_E1_OK ? FV_E1H : { ON: false }, FW_E1Z = FW_E1_OK ? FV_E1Z : { ON: false };
(function() {
   if (!FW_E1_OK) return;
   try {
      var q = location.search;
      if (/[?&]e1q=0/.test(q)) FV_E1Q.ON = false; if (/[?&]e1s=0/.test(q)) FV_E1S.ON = false; if (/[?&]e1h=0/.test(q)) FV_E1H.ON = false; if (/[?&]e1z=0/.test(q)) FV_E1Z.ON = false;
      // (20-nov) ?e1v=0: la pregunta de siempre (sin variedad); ?e1top=0: la placa abajo como antes; ?e1qkind=centre…: fuerza el tipo (pruebas)
      if (/[?&]e1v=0/.test(q)) FV_E1Q.VARY = false; if (/[?&]e1top=0/.test(q)) FV_E1Q.TOP = false;
      var mk = /[?&]e1qkind=([a-z]+)/.exec(q); if (mk) FV_E1Q.FORCE = mk[1];
   } catch (e) {}
})();
var FW_E1_ST = { q: null, cv: null, c: null, mode: "off", guess: null, drag: false, hit: null, idx: -1, state: "none", tGone: 0, closed: false, flown: false, hudUntil: 0, sway: null, swayTried: false, hush: null, k: 1, box: null };
var FW_E1_COL = { ivory: "#F4ECDC", ivory2: "#D9CDB4", gold: "#C99A3A", goldL: "#E9C97A", goldT: "#9C8358", dim: "#6E604A", ver: "#E08A6F", verL: "#D0603F" };

// el tipo de la ultima pregunta (localStorage; sin el, no se recuerda) para no repetirlo
function fwE1Last() { try { return localStorage.getItem("fv.e1q.last") || ""; } catch (e) { return ""; } }
function fwE1LastSet(k) { try { localStorage.setItem("fv.e1q.last", k); } catch (e) {} }
function fwE1Lang() { return (typeof FW_LANG !== "undefined" && FW_LANG === "es") ? "es" : "en"; }
function fwE1Log(s) { try { console.log("E1: " + s); } catch (e) {} }
function fwE1Font(role, px, italic, sp) { return (italic ? "italic " : "") + px + "px " + (role === "display" ? FW_BOOT_FONT.display : FW_BOOT_FONT.text); }
function fwE1Elide(c, s, w) { if (c.measureText(s).width <= w) return s; var lo = 0, hi = s.length; while (lo < hi) { var m = (lo + hi + 1) >> 1; if (c.measureText(s.slice(0, m) + "…").width <= w) lo = m; else hi = m - 1; } return s.slice(0, lo) + "…"; }
function fwE1Txt(c, font, col, x, y, s, sp) { c.font = font; c.fillStyle = col; if ("letterSpacing" in c) c.letterSpacing = (sp || 0) + "px"; c.fillText(s, x, y); if ("letterSpacing" in c) c.letterSpacing = "0px"; }
function fwE1Panel(c, x0, y0, x1, y1) {
   var C = FW_E1_COL;
   c.fillStyle = "#0D0A07"; c.fillRect(x0, y0, x1 - x0, y1 - y0);
   c.strokeStyle = C.gold; c.lineWidth = 1; c.strokeRect(x0 + 0.5, y0 + 0.5, x1 - x0 - 1, y1 - y0 - 1);
   c.strokeStyle = "rgba(201,154,58,.56)"; c.lineWidth = 0.6; c.strokeRect(x0 + 5.5, y0 + 5.5, x1 - x0 - 11, y1 - y0 - 11);
   var K = [[x0 + 5.5, y0 + 5.5, 1, 1], [x1 - 5.5, y0 + 5.5, -1, 1], [x1 - 5.5, y1 - 5.5, -1, -1], [x0 + 5.5, y1 - 5.5, 1, -1]];
   for (var i = 0; i < 4; ++i) {
      var x = K[i][0], y = K[i][1], sx = K[i][2], sy = K[i][3];
      c.strokeStyle = "rgba(201,154,58,.69)"; c.beginPath();
      for (var k = 0; k <= 10; ++k) { var b = (Math.PI / 2) * k / 10, px = x + sx * 12 * Math.sin(b), py = y + sy * 12 * Math.cos(b); if (k) c.lineTo(px, py); else c.moveTo(px, py); }
      c.stroke(); c.fillStyle = "rgba(201,154,58,.75)"; c.beginPath(); c.arc(x + sx * 4.2, y + sy * 4.2, 1.1, 0, 7); c.fill();
   }
}
function fwE1Rule(c, xa, xb, y) {
   var xm = (xa + xb) / 2, d = 3.2 * 0.8; c.strokeStyle = FW_E1_COL.gold; c.lineWidth = 0.8; c.beginPath();
   c.moveTo(xa, y); c.lineTo(xm - 3 * d, y); c.moveTo(xm + 3 * d, y); c.lineTo(xb, y);
   c.moveTo(xm - d * 1.6, y); c.lineTo(xm, y - d); c.lineTo(xm + d * 1.6, y); c.lineTo(xm, y + d); c.closePath(); c.stroke();
   c.fillStyle = FW_E1_COL.gold; c.beginPath(); c.arc(xm - 2.3 * d, y, 0.9, 0, 7); c.arc(xm + 2.3 * d, y, 0.9, 0, 7); c.fill();
}

// ---------------------------------------------------------------------------
// E1-01 · la placa
// ---------------------------------------------------------------------------
function fwE1qInit(scene) {
   var S = FW_E1_ST;
   if (!FW_E1_OK || !FV_E1Q.ON || S.cv) return;
   var last = fwE1Last(), pk = fvE1qPick(fvE1qFromScene(scene), fvE1qOpts(last));
   if (!pk.ok) { S.state = "none"; fwE1Log("no question (" + pk.why + ")"); return; }
   if (FV_E1Q.VARY) fwE1LastSet(pk.kind);
   S.q = pk; S.state = "ask"; S.mode = "boot"; S.idx = pk.target.idx; S.guess = null;
   fwE1Log("question " + pk.kind + " (last " + (last || "-") + ", fits " + (pk.fits ? pk.fits.join("/") : "-") + ") · answer " + Math.round(pk.answerLy) + " ly (± " + Math.round(pk.rel * 100) + " %) · " + pk.n + " measured stars · star " + S.idx);
   var win = document.getElementById("win"), cv = document.createElement("canvas");
   cv.id = "e1q"; cv.style.cssText = "position:absolute;z-index:6;display:none;touch-action:none;cursor:crosshair";
   cv.title = fvE1Tx("q.tip", { mr: Math.round(FV_E1Q.MAX_REL * 100) }, "en") + "\n" + fvE1Tx("q.tip", { mr: Math.round(FV_E1Q.MAX_REL * 100) }, "es");
   win.appendChild(cv); S.cv = cv; S.c = cv.getContext("2d");
   ["pointerdown", "pointerup", "click", "dblclick", "wheel", "contextmenu"].forEach(function(t) { cv.addEventListener(t, function(ev) { ev.stopPropagation(); }); });
   cv.addEventListener("pointerdown", function(ev) { if (ev.button !== 0) return; fwE1qPointer(ev, "down"); });
   cv.addEventListener("pointermove", function(ev) { fwE1qPointer(ev, "move"); });
   cv.addEventListener("pointerup", function(ev) { fwE1qPointer(ev, "up"); });
   window.addEventListener("resize", function() { fwE1qDraw(); });
   fwE1qDraw();
}
// (21-nov, PKG-final) la placa DATA ABIERTA (#legend) en unidades de la cabina, para que la tira de QUAESTIO no la tape (fvE1qHudBox(W, avoid)); plegada no hace falta: la tira va debajo de la cinta
function fwE1qAvoid(k) {
   var lg = document.getElementById("legend"), win = document.getElementById("win");
   if (!lg || !win || !lg.classList.contains("open")) return null;
   var r = lg.getBoundingClientRect(), wr = win.getBoundingClientRect();
   return { x1: (r.right - wr.left) / k, y1: (r.bottom - wr.top) / k };
}
// la geometria en unidades de la cabina (las de PixInsight, 1280 de ancho de referencia): bajo la placa del arranque o sobre su fila de abajo; en la cabina, arriba al centro
function fwE1qBox() {
   var S = FW_E1_ST, win = document.getElementById("win"), cssW = win.clientWidth, cssH = win.clientHeight, k = Math.max(0.62, Math.min(4, cssW / 1280)), W = cssW / k, H = cssH / k, b;
   if (S.mode === "hud") { var HB = fvE1qHudBox(W, fwE1qAvoid(k)); b = { x0: HB.x0, y0: HB.y0, w: HB.w, h: HB.h }; }      // (M) la geometria de la tira, una sola (engine/fv_e1.js)
   else {
      var pw0 = Math.min(W - 48, 1180), ph0 = Math.min(H - 36, 640), x0p = Math.round((W - pw0) / 2), y0p = Math.round((H - ph0) / 2);
      b = fvE1qBox(W, H, { x0: x0p, y0: y0p, x1: x0p + pw0, y1: y0p + ph0 });     // la misma geometria que PixInsight (engine/fv_e1.js)
   }
   b.k = k; return b;
}
// (M) la y minima (px CSS) de la ficha de una estrella [cx0, cx1] de ancho W (CSS px): con la tira de QUAESTIO arriba (modo hud, visible) y solapando en x, justo debajo de ella; si no, baseMin
function fwE1qCardMinY(W, cx0, cx1, baseMin) {
   var S = FW_E1_ST;
   if (!FW_E1_OK || !S.cv || S.mode !== "hud" || S.cv.style.display !== "block" || typeof fvE1qHudBox !== "function") return baseMin;
   var k = Math.max(0.62, Math.min(4, W / 1280)), b = fvE1qHudBox(W / k, fwE1qAvoid(k));
   return (cx1 <= b.x0 * k || cx0 >= b.x1 * k) ? baseMin : Math.max(baseMin, (b.y1 + FV_E1Q_HUD.GAP) * k);
}
function fwE1qDraw() {
   var S = FW_E1_ST, cv = S.cv;
   if (!cv) return;
   if (S.state !== "ask" && S.state !== "reveal" || S.closed || S.flown || S.mode === "off") { cv.style.display = "none"; return; }
   var B = fwE1qBox(), dpr = window.devicePixelRatio || 1, wp = Math.round(B.w * B.k * dpr), hp = Math.round(B.h * B.k * dpr);
   S.box = B; S.k = B.k;
   cv.style.left = (B.x0 * B.k) + "px"; cv.style.top = (B.y0 * B.k) + "px"; cv.style.width = (B.w * B.k) + "px"; cv.style.height = (B.h * B.k) + "px"; cv.style.display = "block";
   if (cv.width !== wp || cv.height !== hp) { cv.width = wp; cv.height = hp; }
   var c = S.c, C = FW_E1_COL, L = fwE1Lang(), Q = S.q, rev = (S.state === "reveal");
   c.setTransform(1, 0, 0, 1, 0, 0); c.clearRect(0, 0, wp, hp); c.setTransform(B.k * dpr, 0, 0, B.k * dpr, 0, 0);
   c.textBaseline = "alphabetic";
   var w = B.w, h = B.h, hud = (S.mode === "hud");
   fwE1Panel(c, 0, 0, w, h);
   var tt = fvE1Tx("q.title", null, L), fT = fwE1Font("display", 10), fQ = fwE1Font("text", 12, true), fS = fwE1Font("text", 9), fR = fwE1Font("text", 12, true), ls = fvE1qRevealLines(Q, S.guess, L), wT;
   c.font = fT; if ("letterSpacing" in c) c.letterSpacing = "3px"; wT = c.measureText(tt).width; if ("letterSpacing" in c) c.letterSpacing = "0px";
   fwE1Txt(c, fT, C.gold, 22, 24, tt, 3);
   c.font = fQ;
   if (!hud) fwE1Txt(c, fQ, C.ivory, 22 + wT + 16, 24, fwE1Elide(c, fvE1qQuestion(Q, L), w - 44 - wT - 16));
   else fwE1Txt(c, fQ, C.ver, 22 + wT + 14, 24, fwE1Elide(c, fvE1Tx("q.what." + Q.kind, null, L) + ": " + ls[0], w - 44 - wT - 14 - 24));
   fwE1Rule(c, 22, w - 22, hud ? 34 : 32);
   var hit = { all: [0, 0, w, h], scale: null, btn: null, close: null, tx0: 0, tx1: 0 };
   if (!hud) {
      var tx0 = 40, tx1 = w - 40, ty = 58, ticks = [10, 100, 1000, 10000, 100000], i, m;
      c.strokeStyle = C.gold; c.lineWidth = 1; c.beginPath(); c.moveTo(tx0, ty); c.lineTo(tx1, ty); c.stroke();
      function X(ly) { return tx0 + (tx1 - tx0) * fvE1qPos(ly); }
      for (i = 0; i < ticks.length; ++i) {
         var tx = X(ticks[i]); c.strokeStyle = C.gold; c.lineWidth = 1; c.beginPath(); c.moveTo(tx, ty - 6); c.lineTo(tx, ty + 6); c.stroke();
         var tl = fvE1Num(ticks[i], 0, L); c.font = fS; var tw = c.measureText(tl).width; fwE1Txt(c, fS, C.goldT, Math.min(tx1 + 14 - tw, Math.max(tx0 - 14, tx - tw / 2)), ty + 19, tl);
      }
      c.strokeStyle = "rgba(201,154,58,.5)"; c.lineWidth = 0.7; c.beginPath();
      for (i = 1; i < 5; ++i) for (m = 2; m <= 9; ++m) { var v = Math.pow(10, i) * m / 10; if (v < 10 || v > 100000) continue; var x2 = X(v); c.moveTo(x2, ty - 2.5); c.lineTo(x2, ty + 2.5); }
      c.stroke();
      var un = fvE1Tx("q.axisNote", null, L).toUpperCase(); c.font = fwE1Font("display", 8); if ("letterSpacing" in c) c.letterSpacing = "2px"; var uw = c.measureText(un).width; if ("letterSpacing" in c) c.letterSpacing = "0px"; fwE1Txt(c, fwE1Font("display", 8), C.dim, tx1 - uw, ty - 12, un, 2);
      if (S.guess) {
         var gx = X(S.guess); c.strokeStyle = C.ivory; c.fillStyle = C.ivory; c.lineWidth = 1.2; c.beginPath(); c.moveTo(gx, ty - 14); c.lineTo(gx, ty); c.stroke();
         c.beginPath(); c.moveTo(gx - 4, ty - 14); c.lineTo(gx + 4, ty - 14); c.lineTo(gx, ty - 7); c.closePath(); c.stroke();
         var gl = fvE1LyText(S.guess, L); c.font = fS; var gw = c.measureText(gl).width; fwE1Txt(c, fS, C.ivory, Math.min(tx1 - gw, Math.max(tx0, gx - gw / 2)), ty - 18, gl);
      }
      if (rev) {
         var rx = X(Q.answerLy), x1r = X(Q.loLy || Q.answerLy), x2r = X(Q.hiLy || Q.answerLy);
         c.strokeStyle = "rgba(208,96,63,.69)"; c.lineWidth = 2.2; c.beginPath(); c.moveTo(x1r, ty + 3); c.lineTo(x2r, ty + 3); c.stroke();
         c.strokeStyle = C.verL; c.fillStyle = C.verL; c.lineWidth = 1.6; c.beginPath(); c.moveTo(rx, ty - 9); c.lineTo(rx, ty + 9); c.stroke();
         c.beginPath(); c.moveTo(rx - 4, ty + 15); c.lineTo(rx + 4, ty + 15); c.lineTo(rx, ty + 8); c.closePath(); c.stroke();
      }
      hit.scale = [tx0 - 12, ty - 20, tx1 + 12, ty + 18]; hit.tx0 = tx0; hit.tx1 = tx1;
      var yb = 104;
      if (!rev) {
         var txt = S.guess ? fvE1Tx("q.set", { v: fvE1LyText(S.guess, L) + " " + (L === "es" ? "a. l." : "ly") }, L) : fvE1Tx("q.hint", null, L);
         c.font = fR; fwE1Txt(c, fR, S.guess ? C.ivory2 : C.goldT, 22, yb - 6, fwE1Elide(c, txt, w - 44));
      } else {
         var canFly = FV_E1Q.FLY && S.idx >= 0 && !S.flown, bx0 = w - 22;
         if (canFly) {
            var lab = fvE1Tx("q.fly", null, L), fB = fwE1Font("display", 10); c.font = fB; if ("letterSpacing" in c) c.letterSpacing = "2px"; var bw = c.measureText(lab).width + 28; if ("letterSpacing" in c) c.letterSpacing = "0px";
            bx0 = w - 22 - bw; hit.btn = [bx0, yb - 18, w - 22, yb + 10];
            c.fillStyle = "rgba(201,154,58,.25)"; c.fillRect(bx0, yb - 18, bw, 28); c.strokeStyle = C.gold; c.lineWidth = 1; c.strokeRect(bx0 + 0.5, yb - 17.5, bw - 1, 27);
            fwE1Txt(c, fB, C.ivory, bx0 + 14, yb + 1, lab, 2);
         }
         c.font = fR; fwE1Txt(c, fR, C.ver, 22, yb - 6, fwE1Elide(c, ls[0], bx0 - 44)); fwE1Txt(c, fR, C.ivory2, 22, yb + 12, fwE1Elide(c, ls[1], bx0 - 44));
      }
   } else {
      var canFly2 = FV_E1Q.FLY && S.idx >= 0 && !S.flown, bx = w - 22;
      if (canFly2) {
         var lab2 = fvE1Tx("q.fly", null, L), fB2 = fwE1Font("display", 10); c.font = fB2; if ("letterSpacing" in c) c.letterSpacing = "2px"; var bw2 = c.measureText(lab2).width + 28; if ("letterSpacing" in c) c.letterSpacing = "0px";
         bx = w - 22 - bw2; hit.btn = [bx, 44, w - 22, 68];
         c.fillStyle = "rgba(201,154,58,.25)"; c.fillRect(bx, 44, bw2, 24); c.strokeStyle = C.gold; c.lineWidth = 1; c.strokeRect(bx + 0.5, 44.5, bw2 - 1, 23);
         fwE1Txt(c, fB2, C.ivory, bx + 14, 61, lab2, 2);
      }
      c.font = fR; fwE1Txt(c, fR, C.ivory2, 22, 60, fwE1Elide(c, ls[1], bx - 40));
      c.strokeStyle = C.goldT; c.lineWidth = 1.2; c.beginPath(); c.moveTo(w - 22, 14); c.lineTo(w - 14, 22); c.moveTo(w - 22, 22); c.lineTo(w - 14, 14); c.stroke();
      hit.close = [w - 28, 8, w - 8, 28];
   }
   S.hit = hit;
   var tip = function(key, extra) { return fvE1Tx(key, extra("en"), "en") + String.fromCharCode(10) + fvE1Tx(key, extra("es"), "es"); };
   S.cv.title = hud ? tip("q.tipHud", function(l) { return { what: fvE1Tx("q.what." + Q.kind, null, l) }; }) : tip("q.tip", function() { return { mr: Math.round(FV_E1Q.MAX_REL * 100) }; });
}
function fwE1In(r, x, y) { return !!r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]; }
function fwE1qPointer(ev, what) {
   var S = FW_E1_ST, cv = S.cv;
   if (!S.hit || !cv) return;
   var b = cv.getBoundingClientRect(), x = (ev.clientX - b.left) / S.k, y = (ev.clientY - b.top) / S.k;
   if (what === "down") {
      if (typeof fwE1sCancel === "function") fwE1sCancel();
      if (S.state === "ask" && fwE1In(S.hit.scale, x, y)) { S.drag = true; try { cv.setPointerCapture(ev.pointerId); } catch (e) {} fwE1qSetGuess(x); }
      else if (S.state === "reveal" && fwE1In(S.hit.btn, x, y)) fwE1qFly();
      else if (fwE1In(S.hit.close, x, y)) { S.closed = true; fwE1qDraw(); }
   } else if (what === "move") { if (S.drag) fwE1qSetGuess(x); }
   else if (what === "up") { S.drag = false; }
}
function fwE1qSetGuess(x) { var S = FW_E1_ST, u = (x - S.hit.tx0) / Math.max(1, S.hit.tx1 - S.hit.tx0); S.guess = fvE1qVal(u); fwE1qDraw(); }
// IR ALLI: elige la estrella y viaja con el MODUS actual (como el doble clic)
function fwE1qFly() {
   var S = FW_E1_ST, P = FW.P;
   if (!S.q || S.idx < 0 || !P || !FW.ready) return false;
   var sel = { kind: "star", i: S.idx, t0: P.t };
   fwUserAct(); fwSelectSel(sel); fwTravel(sel); fwButtonsState();
   S.flown = true; fwE1Log("fly to star " + S.idx + " (" + S.q.kind + ", " + Math.round(S.q.answerLy) + " ly) -> " + !!P.flight);
   fwE1qDraw();
   return true;
}
// al acabar la placa del arranque: se revela (la misma pregunta sobre la escena final: el dato no cambia) y pasa a la cabina
function fwE1Gone() {
   var S = FW_E1_ST;
   if (S.gone) return; S.gone = true; S.tGone = performance.now();
   if (S.state === "ask" && FW.scene) {
      var pk = fvE1qPick(fvE1qFromScene(FW.scene), { kind: S.q.kind });
      if (pk.ok && Math.abs(pk.answerLy - S.q.answerLy) <= 0.002 * S.q.answerLy) { S.q = pk; S.idx = pk.target.idx; S.state = "reveal"; fwE1Log("reveal · " + pk.kind + " " + Math.round(pk.answerLy) + " ly · star " + S.idx + " · you said " + (S.guess ? Math.round(S.guess) + " ly" : "nothing")); }
      else { S.state = "none"; fwE1Log("the final scene does not give the asked answer: no reveal"); }
   }
   S.mode = "hud"; S.hudUntil = performance.now() + FV_E1Q.HUD_S * 1000;
   fwE1qDraw();
   setTimeout(function() { if (FW_E1_ST.mode === "hud") { FW_E1_ST.closed = true; fwE1qDraw(); } }, FV_E1Q.HUD_S * 1000);
   // el balanceo: pasada la transicion de la placa (0,5 s)
   setTimeout(function() { fwE1sMaybe(); }, 650);
}

// ---------------------------------------------------------------------------
// E1-12 · el balanceo
// ---------------------------------------------------------------------------
function fwE1sSig(sc) { var f = sc.field; return Math.round(f.ra * 1e4) + "_" + Math.round(f.dec * 1e4) + "_" + Math.round(f.scaleArcsec * 1e3) + "_" + f.width + "x" + f.height; }
function fwE1sMaybe() {
   var S = FW_E1_ST;
   if (S.swayTried || !FW_E1_OK || !FV_E1S.ON || !FW.ready || !FW.P || FW.P.flight) return;
   S.swayTried = true;
   var force = /[?&]e1sforce=1/.test(location.search), key = "fv.e1s." + fwE1sSig(FW.scene), seen = false;
   try { seen = FV_E1S.ONCE && !force && localStorage.getItem(key) === "1"; } catch (e) {}
   if (seen) { fwE1Log("sway already shown for this photo (key " + FV_E1S.KEY + " repeats it)"); return; }
   if (fwE1sStart(false)) { try { localStorage.setItem(key, "1"); } catch (e2) {} }
}
function fwE1sStart(forced) {
   var S = FW_E1_ST, P = FW.P;
   if (!FW_E1_OK || !FV_E1S.ON || !P || !FW.ready || P.flight || (S.sway && S.sway.on)) return false;
   if (fvLen(P.cam.pos) > 1e-6) { if (forced) fwCaption(fvE1Tx("s.needHome", null, fwE1Lang()), 2.6); return false; }
   var plan = fvE1sPlan(FW.scene.stars, fvE1sFov(P), FW.scene.nebula ? FW.scene.nebula.distLy : 0);
   if (!plan.ok) { fwE1Log("no sway (" + plan.why + ")"); return false; }
   S.sway = { plan: plan, t0: performance.now(), on: true, u: 0 };
   fwCaption(fvE1sText(plan, fwE1Lang()), plan.durS + 1.4);
   fwE1Log("sway · amplitude " + plan.ampLy.toFixed(2) + " ly · span " + Math.round(plan.spanLy) + " ly · " + plan.n + " stars");
   return true;
}
function fwE1sCancel() { var S = FW_E1_ST; if (S.sway && S.sway.on) { S.sway.on = false; S.sway.u = 0; fwE1Log("sway skipped"); return true; } return false; }
function fwE1sOff() {
   var S = FW_E1_ST.sway;
   if (!S || !S.on) return 0;
   S.u = (performance.now() - S.t0) / 1000 / S.plan.durS;
   if (S.u >= 1) { S.on = false; S.u = 1; return 0; }
   return fvE1sOffset(S.plan, S.u);
}
// ---------------------------------------------------------------------------
// E1-13 · mirar a casa
// ---------------------------------------------------------------------------
function fwE1hGo() {
   var P = FW.P;
   if (!P || !FW.ready || (P.flight && P.flight.kind === "look")) return false;
   if (fvLen(P.cam.pos) < 1e-6) { fwCaption(fvE1Tx("h.athome", null, fwE1Lang()), 3.0); return true; }
   if (FW.tour && typeof fwTourStop === "function") fwTourStop();
   var ok = fvE1hFly(P);
   if (ok) { var r = fvE1hSun(P.cam.pos, fwE1Lang()); fwE1Log("look home from " + Math.round(r.dLy) + " ly · m(V) = " + r.m.toFixed(2)); }
   return ok;
}
// la placa del Sol (la de fvSunPaint de PixInsight): el aro en su sitio y las lineas de fvE1hSun
function fwE1hPaint() {
   var P = FW.P, g = FW.ck && FW.ck.hctx;
   if (!FW_E1_OK || !FV_E1H.ON || !P || !P.sunMark || !g) return;
   var L = fwE1Lang(), W = FW.VW, H = FW.VH, d = fvLen(P.cam.pos), p = fvProjector(P.cam, W, H).project([0, 0, 0]);
   if (!p || d < 1e-6) { FW_E1_ST.sunInfo = null; return; }
   var sE = fvE1hSun(P.cam.pos, L), u = Math.max(0.62, Math.min(4, W / 1280)), x = p[0], y = p[1], r = 16 * u, C = FW_E1_COL;
   var rows = sE.lines.concat([fvE1Tx("h.dist", { d: fvE1Num(d, 0, L) }, L)]), l1 = fvE1Tx("h.label", null, L);
   g.save(); g.globalAlpha = 1;
   g.strokeStyle = "#F3D27E"; g.lineWidth = 1.4; g.beginPath(); g.arc(x, y, r, 0, 7); g.stroke(); g.beginPath(); g.arc(x, y, 2.2 * u, 0, 7); g.stroke();
   g.strokeStyle = "rgba(243,210,126,.56)"; g.lineWidth = 1; g.beginPath(); g.arc(x, y, r + 5 * u, 0, 7); g.stroke();
   g.beginPath(); for (var k = 0; k < 4; ++k) { var a = k * Math.PI / 2; g.moveTo(x + Math.cos(a) * (r + 7 * u), y + Math.sin(a) * (r + 7 * u)); g.lineTo(x + Math.cos(a) * (r + 14 * u), y + Math.sin(a) * (r + 14 * u)); } g.stroke();
   var f1 = "400 " + (14 * u) + "px " + FW_BOOT_FONT.display, f2 = "400 " + (11 * u) + "px " + FW_BOOT_FONT.text, w1, w2 = 0, i;
   g.font = f1; if ("letterSpacing" in g) g.letterSpacing = (2 * u) + "px"; w1 = g.measureText(l1).width; if ("letterSpacing" in g) g.letterSpacing = "0px";
   g.font = f2; for (i = 0; i < rows.length; ++i) w2 = Math.max(w2, g.measureText(rows[i]).width);
   var ww = Math.max(w1, w2) + 16 * u, right = x < W * 0.6, tx = right ? x + r + 20 * u : x - r - 20 * u, bx = right ? tx : tx - ww, by = y - 26 * u, bh = (20 + 15 * rows.length + 4) * u;
   if (bx + ww > W - 6) bx = W - 6 - ww; if (bx < 6) bx = 6;
   g.fillStyle = "rgba(17,13,9,.82)"; g.fillRect(bx, by, ww, bh); g.strokeStyle = "#C99A3A"; g.lineWidth = 1; g.strokeRect(bx + 0.5, by + 0.5, ww - 1, bh - 1);
   g.fillStyle = "#F3D27E"; g.font = f1; if ("letterSpacing" in g) g.letterSpacing = (2 * u) + "px"; g.fillText(l1, bx + 8 * u, by + 17 * u); if ("letterSpacing" in g) g.letterSpacing = "0px";
   g.font = f2; for (i = 0; i < rows.length; ++i) { g.fillStyle = (i === rows.length - 1) ? "#D0C1A5" : "#FBF2E0"; g.fillText(rows[i], bx + 8 * u, by + (33 + 15 * i) * u); }
   g.restore();
   FW_E1_ST.sunInfo = { m: sE.m, x: x, y: y, d: d, rows: rows };
}

// ---------------------------------------------------------------------------
// los enganches (envolver, sin tocar fw_viewer.js ni fw_rightbar.js)
// ---------------------------------------------------------------------------
if (FW_E1_OK) {
   // la escena ya construida -> QUAESTIO puede preguntar (con la placa del arranque aun en pantalla)
   var fwSceneFromJson_e1 = fwSceneFromJson;
   fwSceneFromJson = function(J) { var sc = fwSceneFromJson_e1(J); try { fwE1qInit(sc); } catch (e) { fwE1Log("init error " + e); } return sc; };
   // E1-12: el balanceo solo al pintar
   var fwRenderFrame_e1 = fwRenderFrame;
   fwRenderFrame = function(dt) {
      var off = fwE1sOff(), P = FW.P, sv = null, svF = null;
      if (off && P) {
         sv = P.cam.pos;
         // (H7) el borde de la foto no asoma: la vista se acerca lo justo mientras la camara va de lado (fvE1sZoomK; 1 en casa)
         var zk = FW_E1_ST.sway ? fvE1sZoomK(P.cam, FW.scene, off, FW_E1_ST.sway.plan.ampLy, FW.VW, FW.VH) : 1;
         if (zk > 1) { svF = P.cam.fov; P.cam.fov = fvE1sFovK(svF, zk); }
         FW_E1_ST.zk = zk;
         P.cam.pos = fvE1sShift(P.cam, off);
      }
      try { fwRenderFrame_e1(dt); } finally { if (sv) P.cam.pos = sv; if (svF !== null) P.cam.fov = svF; }
   };
   // E1-14: silencio de llegada (la llegada la avisa el motor: P.onFlightEnd = fwOnArrive, ya con P.arrivedAt)
   var fwOnArrive_e1 = fwOnArrive;
   fwOnArrive = function(P, fl) {
      fwOnArrive_e1(P, fl);
      if (fl && fl.kind !== "home" && fl.kind !== "look" && P.arrivedAt) {
         var pl = fvE1tPlan(FW.scene, P.arrivedAt, P.t);
         if (pl) { FW_E1_ST.hush = pl; fwE1Log("arrival silence (" + P.arrivedAt.kind + ") for " + FV_E1Z.DUR_S + " s"); }
      }
   };
   var fwRadioDuck_e1 = fwRadioDuck;
   fwRadioDuck = function() {
      var h = FW_E1_ST.hush, P = FW.P;
      if (h && P.t >= h.until) FW_E1_ST.hush = h = null;
      if (h && !P.flight) { FW.radio.duck(h.f, h.s, h.hz); return; }
      fwRadioDuck_e1();
   };
   var fwRadioLevelFor_e1 = fwRadioLevelFor;
   fwRadioLevelFor = function(P, cardOpen) { var h = FW_E1_ST.hush; return (h && P.t < h.until && !P.flight) ? h.level : fwRadioLevelFor_e1(P, cardOpen); };
   // la placa de la cabina (se esconde en pleno vuelo) y la del Sol
   var fwOverlay_e1 = fwOverlay;
   fwOverlay = function(now) {
      fwOverlay_e1(now);
      try {
         var S = FW_E1_ST, P = FW.P;
         if (S.cv && S.mode === "hud" && S.state === "reveal" && !S.closed && !S.flown) { var want = !P.flight; if (want !== (S.cv.style.display !== "none")) { if (want) fwE1qDraw(); else S.cv.style.display = "none"; } }
         fwE1hPaint();
      } catch (e) {}
   };
   // el gancho del fin de la placa del arranque: #boot.gone (la clase la pone fw_viewer.js al acabar la presentacion)
   (function() {
      var boot = document.getElementById("boot");
      if (!boot) return;
      if (boot.classList.contains("gone")) { fwE1Gone(); return; }
      var mo = new MutationObserver(function() { if (boot.classList.contains("gone")) { mo.disconnect(); fwE1Gone(); } });
      mo.observe(boot, { attributes: true, attributeFilter: ["class"] });
   })();
   // teclas: cualquier tecla salta el balanceo (en captura, antes que el visor); Y lo repite
   window.addEventListener("keydown", function(e) {
      if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
      if (fwE1sCancel()) return;
      if ((e.key || "").toLowerCase() === FV_E1S.KEY.toLowerCase() && !e.repeat && !e.ctrlKey && !e.metaKey && !e.altKey && FW.ready && FW.P) fwE1sStart(true);
   }, true);
   document.getElementById("win").addEventListener("pointerdown", function() { if (fwE1sCancel()) FW.e1sSwallow = true; }, true);      // (M, R3-H1) ese clic solo para el balanceo: fw_viewer.js no lo convierte en seleccion

   // E1-13: el boton CASA de la columna derecha
   var fwRbIds_e1 = fwRbIds;
   fwRbIds = function() { var o = fwRbIds_e1(), i = o.indexOf("scale"); if (FV_E1H.ON && FV_E1H.BUTTON && o.length) o.splice(i < 0 ? o.length : i + 1, 0, "home"); return o; };
   FW_RB_TX.en["lab.home"] = fvE1Tx("h.btn", null, "en"); FW_RB_TX.es["lab.home"] = fvE1Tx("h.btn", null, "es");
   FW_RB_TX.en["tip.home"] = fvE1Tx("h.tip", { mv: "4.81", key: FV_E1H.KEY }, "en"); FW_RB_TX.es["tip.home"] = fvE1Tx("h.tip", { mv: "4,81", key: FV_E1H.KEY }, "es");
   var fwRbIcon_e1 = fwRbIcon;
   fwRbIcon = function(g, id) {
      if (id !== "home") return fwRbIcon_e1(g, id);
      function st(d) { fwEl("path", { d: d, class: "edge", fill: "none", "stroke-width": 0.42, transform: "translate(.38,.38)" }, g); fwEl("path", { d: d, stroke: "currentColor", fill: "none", "stroke-width": 0.72 }, g); }
      function hair(d) { fwEl("path", { d: d, stroke: "currentColor", fill: "none", "stroke-width": 0.4 }, g); }
      var n = [7.7 / 17.2, 14.5 / 17.2], tubes = [[-14, 10, -7, 5.8, 1.7], [-7, 5.8, 0, 1.6, 2.7], [0, 1.6, 8, -3.2, 3.8]], d = "", k;
      for (k = 0; k < tubes.length; ++k) {
         var t = tubes[k], px = n[0] * t[4], py = n[1] * t[4];
         d += "M " + (t[0] - px) + " " + (t[1] - py) + " L " + (t[2] - px) + " " + (t[3] - py) + " M " + (t[0] + px) + " " + (t[1] + py) + " L " + (t[2] + px) + " " + (t[3] + py) + " M " + (t[2] - px) + " " + (t[3] - py) + " L " + (t[2] + px) + " " + (t[3] + py) + " ";
      }
      d += "M " + (8 - n[0] * 3.8) + " " + (-3.2 - n[1] * 3.8) + " L " + (8 + n[0] * 3.8) + " " + (-3.2 + n[1] * 3.8) + " ";
      st(d); hair("M 5.1 -2.2 A 2.3 2.3 0 1 0 9.7 -2.2 A 2.3 2.3 0 1 0 5.1 -2.2 M -14 10 L -16 11.6");
      fwEl("circle", { cx: 13.5, cy: -9.5, r: 1.7, fill: "currentColor", stroke: "none" }, g);
   };
   var fwRbButton_e1 = fwRbButton;
   fwRbButton = function(id, o) {
      if (id !== "home") return fwRbButton_e1(id, o);
      if (!fwRbReady() || fwRbRecOn()) return false;
      var ok = fwE1hGo(), b = FW_RB_ST.btn.home; if (b) { b.classList.add("pressed"); setTimeout(function() { b.classList.remove("pressed"); }, 140); }
      fwRbSync(true);
      return ok;
   };
   var fwRbKeyDown_e1 = fwRbKeyDown;
   fwRbKeyDown = function(e) {
      if (FW_RB_ST.built && (FW_RB_ST.btn.home || (FV_E1H.ON && !FV_E1H.BUTTON)) && !(e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) && !e.ctrlKey && !e.metaKey && !e.altKey && !e.repeat && (e.key || "").toLowerCase() === FV_E1H.KEY.toLowerCase()) { e.preventDefault(); fwRbButton("home"); return; }
      fwRbKeyDown_e1(e);
   };
   var fwRbSync_e1 = fwRbSync;
   fwRbSync = function(force) {
      fwRbSync_e1(force);
      var b = FW_RB_ST.btn && FW_RB_ST.btn.home;
      if (b) { var rd = fwRbReady() && !fwRbRecOn(), on = !!(FW.P && FW.P.sunMark); if (b.disabled !== !rd) b.disabled = !rd; if (b.classList.contains("on") !== on) b.classList.toggle("on", on); }
   };
}
// pruebas (CDP): estado y mandos sin esperar al reloj
FW.test = FW.test || {};
FW.test.e1 = function() { var S = FW_E1_ST; return { q: S.q ? { kind: S.q.kind, answerLy: S.q.answerLy, rel: S.q.rel, n: S.q.n } : null, state: S.state, mode: S.mode, guess: S.guess, idx: S.idx, closed: S.closed, flown: S.flown, hit: S.hit, box: S.box, k: S.k,
   shown: !!(S.cv && S.cv.style.display !== "none"), sway: S.sway ? { on: S.sway.on, u: S.sway.u, amp: S.sway.plan.ampLy } : null, hush: S.hush, sun: S.sunInfo || null, gone: S.gone, off: fwE1sOff() }; };
FW.test.e1swayAt = function(u) { var S = FW_E1_ST; if (!S.sway) return null; S.sway.on = true; S.sway.t0 = performance.now() - u * S.sway.plan.durS * 1000 - 1; return fwE1sOff(); };
