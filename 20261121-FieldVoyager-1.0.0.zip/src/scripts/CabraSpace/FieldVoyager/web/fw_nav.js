// ============================================================================
// FieldVoyager/web/fw_nav.js — LOS INSTRUMENTOS DE NAVEGACION del visor (pasada N, N1; 4-nov-2026, encargo D)
// ----------------------------------------------------------------------------
// La misma franja que la de PixInsight (src/ui/fv_nav.js de A: de ahi salen la proyeccion del mapa 3D, el campo de vision sobre la foto y la
// lista; aqui en lienzo 2D y HTML, copiado y adaptado):
//   TABULA       miniatura 2D de la foto con lo que mira la camara (el borde de la pantalla llevado al plano de la nebulosa) y la nave.
//                Clic = mirar alli (giro suave, sin moverse) · doble clic = viajar a lo mas cercano a ese punto.
//   PROFUNDITAS  mapa 3D del campo en vista oblicua: el cono de la foto con la Tierra en el vertice, las estrellas a su distancia (profundidad
//                logaritmica), la nebulosa como losa, los objetos singulares y la NAVE con su mirada, en vivo. Clic = elegir lo mas cercano.
//   MIRABILIA    la lista de lo mas singular: scene.objects de C (planetarias, galaxias, exoplanetas, estrellas notables) por singularidad;
//                sin ellos, la nebulosa y las estrellas notables (la mas brillante, la mayor, la mas caliente, la mas cercana).
//                Clic = elegir (ficha) · doble clic o la flecha = viajar.
// Los dibujos solo se rehacen cuando cambia algo (pose de la camara, seleccion, tamaño), como mucho a 30 Hz: no cuestan fotogramas.
// ES5.
// ============================================================================

// (B, 14-nov) MIRABILIA mas clara y con mas filas (como fv_nav.js, FV_NAV.LABELS / LIST_V2): LABELS = la estrella elegida por un superlativo se llama por el
// (o.label, horneado al armar la lista y exportado: las mismas cadenas que PixInsight); false = ROJO, el nombre de catalogo. LIST_V2 = filas de dos renglones
// apretados (letra minima 7,5 / 7 px, la fila lo que miden + 1,2 px) y, si asi no salen ROW2_MIN filas (ventana pequeña), de UN renglon (el titulo y, si cabe entera,
// la primera parte del subtitulo): seis en 1920×1080 y seis en 1280×800, antes cuatro; false = ROJO, las cuatro de antes
// (P27c, 16-nov) ICON_BY_TYPE: el icono de la fila de la nebulosa principal sale de su tipo real (la etiqueta de la escena: cumulo, planetaria, galaxia...), no siempre «nebula» (gemelo de
// FV_MIRA.ICON_BY_TYPE, src/build/fv_mira.js); false = ROJO, icono de nebulosa como antes. Con una nebulosa Sharpless el icono es el mismo de antes.
// (P24, 16-nov; DECISION DE NINO, de fabrica 0 = lo de hoy) LIST_FIT, gemelo de FV_MIRA.LIST_FIT: 0 hoy · 1 = letra mayor (titulo FIT1_T px, subtitulo FIT1_S px) en todas las ventanas, siempre dos renglones,
// misma caja, la rueda para el resto; si un titulo no cabe se baja 0,5 px cada vez hasta la letra de hoy (nunca se corta con «…» lo que hoy no se corta) · 2 = la letra de hoy con SIEMPRE dos renglones (rotulo y valor
// debajo) y las filas repartidas por toda la caja (holgadas); a 1280×800, 4 filas en vez de 6 de un renglon
var FW_NAV = { MAP_STARS: 700, LIST_MAX: 16, HZ: 30, LABELS: true, LIST_V2: true, ROW_T: 0.60, ROW_S: 0.50, ROW_TMIN: 7.5, ROW_SMIN: 7, ROW_PAD: 1.2, ROW2_MIN: 5, ROW1_PAD: 4.5,
               ICON_BY_TYPE: true, LIST_FIT: 3, FIT1_T: 9, FIT1_S: 8, NODATA_ROW: true };
// (21-nov-2026, T1-A) NODATA_ROW, gemelo de FV_NOTABLE.NODATA_ROW (src/engine/fv_objects.js): la fila «metalpoor» sin [M/H] de GSP-Phot se queda en MIRABILIA y dice «no data» / «sin datos» (scene.noData, exportado por
// el motor; la fila no es un destino: sin flecha ni viaje ni parada del Tour). false (o ?ndrow=0 en la URL) = lo de antes: la fila no sale.
(function() { try { var q = /[?&]ndrow=([01])/.exec(location.search); if (q) FW_NAV.NODATA_ROW = q[1] === "1"; } catch (e) {} })();
var FW_NAV_TX = {
   en: { tabula: "TABULA", tabulaTip: "Your photo: the gold outline is what the camera sees. Click to look there; double-click to travel to what is nearest.",
         prof: "PROFUNDITAS", profTip: "The field in depth (logarithmic): the Earth at the tip of the cone, the stars at their distance, the nebula as a slab, and your ship with where it looks. Click to choose.",
         mir: "MIRABILIA", mirTip: "The most singular things in the photo. Click to see its card; double-click or the arrow to travel.", go: "Travel", away: "looking away from the photo",
         empty: "Nothing singular found in this field.", neb: "nebula", ly: "ly", brightest: "Brightest star in the sky", metalpoor: "Possibly the most metal-poor", largest: "Largest star", hottest: "Hottest star", nearest: "Nearest star", exoplanet: "Star with a planet" },
   es: { tabula: "TABULA", tabulaTip: "Tu foto: el contorno dorado es lo que ve la cámara. Clic para mirar allí; doble clic para viajar a lo más cercano.",
         prof: "PROFUNDITAS", profTip: "El campo en profundidad (logarítmica): la Tierra en la punta del cono, las estrellas a su distancia, la nebulosa como losa y tu nave con hacia dónde mira. Clic para elegir.",
         mir: "MIRABILIA", mirTip: "Lo más singular de la foto. Clic para ver su ficha; doble clic o la flecha para viajar.", go: "Viajar", away: "mirando fuera de la foto",
         empty: "No se encontró nada singular en este campo.", neb: "nebulosa", ly: "a.l.", brightest: "La estrella más brillante en el cielo", metalpoor: "Posiblemente la más pobre en metales", largest: "La estrella mayor", hottest: "La estrella más caliente", nearest: "La estrella más cercana", exoplanet: "Estrella con planeta" }
};
// (N2, puntos 1, 2 y 5 de Nino) textos de TABULA / PROFUNDITAS / MIRABILIA con la nave, la estela, el destino y la ficha solo con INFO o al llegar
(function() {
   var add = {
      en: { ship: "FROM EARTH", dest: "TO GO", out: "SHIP OUTSIDE THE PHOTO",
            tabulaTip: "Your photo. Gold outline = what the camera sees · large arrow = your ship and where it looks · faint trail = where you have been · red target and dashed line = where you are going. If the ship leaves the photo, an arrow on the edge says where it is. Click to look there; double-click to travel to what is nearest.",
            profTip: "The field in depth (log scale): the Earth at the tip of the cone, the stars at their distance, the nebula as a slab. Large arrow = your ship and where it looks · line Earth → ship (FROM EARTH = its distance) · dashed red line to the target (TO GO = what is left). The tick on the axis is the ship's depth. Click to choose.",
            mirTip: "The most singular things in the photo (nebula, clusters, planetary nebulae and galaxies first; then notable stars and known planets). A notable star is named by what makes it notable («Hottest star», «Nearest star»…): hover its row for the exact criterion and its catalogue name. Click to select it (its card appears with INFO or when you arrive); double-click or the arrow to travel." },
      es: { ship: "DESDE LA TIERRA", dest: "FALTAN", out: "NAVE FUERA DE LA FOTO",
            tabulaTip: "Tu foto. Contorno dorado = lo que ve la cámara · flecha grande = tu nave y hacia dónde mira · estela tenue = por dónde has ido · mira roja y línea a trazos = adónde vas. Si la nave sale de la foto, una flecha en el borde dice dónde está. Clic para mirar allí; doble clic para viajar a lo más cercano.",
            profTip: "El campo en profundidad (escala logarítmica): la Tierra en la punta del cono, las estrellas a su distancia, la nebulosa como losa. Flecha grande = tu nave y hacia dónde mira · línea Tierra → nave (DESDE LA TIERRA = su distancia) · línea roja a trazos hasta el destino (FALTAN = lo que queda). La marca del eje es la profundidad de la nave. Clic para elegir.",
            mirTip: "Lo más singular de la foto (primero nebulosa, cúmulos, planetarias y galaxias; luego estrellas notables y planetas conocidos). Una estrella notable se llama por lo que la hace notable («La estrella más caliente», «La más cercana»…): pon el ratón sobre su fila para ver el criterio exacto y su nombre de catálogo. Clic para elegirlo (su ficha sale con INFO o al llegar); doble clic o la flecha para viajar." }
   };
   for (var L in add) for (var k in add[L]) FW_NAV_TX[L][k] = add[L][k];
})();
function fwNavT(k) { var t = FW_NAV_TX[FW_LANG === "es" ? "es" : "en"]; return t[k] || k; }
// 3 cifras significativas desde 100 a.l., como la ficha (fvsFmtSig): «6 540», no «6 536»
function fwNavNum(x) { return (x >= 100 ? fvsFmtSig(x, 3, FW_LANG) : x.toFixed(1).replace(".", FW_LANG === "es" ? "," : ".")); }

// ---------------------------------------------------------------------------
// LOS ELEMENTOS DE LA LISTA -> [{ kind: "object"|"star"|"nebula", i, name, type, sub, dist }]
// ---------------------------------------------------------------------------
// (N2, punto 5 de Nino: «en Mirabilia solo veo exoplanetas») la misma CAUSA y el mismo arreglo que en PixInsight (src/ui/fv_nav.js,
// fvNavOrder): scene.objects viene por `score` y cada exoplaneta cruzado puntua 8 (7 por posicion), por encima de cualquier objeto del
// cielo profundo (≤ 5) y de las estrellas notables (2 + bonus), con la lista cortada a LIST_MAX. Ahora el orden es por CATEGORIA (0 nebulosa
// principal · 1 cielo profundo · 2 estrellas notables · 3 exoplanetas) y por score dentro de cada una; exoplanetas: como mucho un tercio.
FW_NAV.EXO_FRAC = 1 / 3; FW_NAV.ORDER_OLD = false;
// (17-nov-2026, F8; docs/encargos-17nov/F8.md) EL PROTAGONISTA DE LA FOTO en el visor web: gemelo de FV_HERO.FIRST / FV_HERO.TOUR de PixInsight (E2b, src/engine/fv_objects.js; src/ui/fv_nav.js fvNavHero;
// src/engine/fv_pilot.js fvTourPick). La exportacion (src/export/fv_export.js) lleva `hero` en el objeto dibujado que es el protagonista (M 42, IC 342...) y `scene.hero` ({ id, src, name... }).
//   FIRST   el protagonista es la 1.a fila de MIRABILIA: categoria 0 (la de la nebulosa principal) y el primero de ella
//   TOUR    el Tour (que en el visor recorre MIRABILIA) acaba en el protagonista, como el de PixInsight (fvTourPick reserva la ultima parada)
// ON = false (o ?hero=0 en la URL) = lo de antes: sin protagonista. Un paquete sin `hero` (anterior al 17-nov) no cambia nada con ninguna bandera.
var FW_HERO = { ON: true, FIRST: true, TOUR: true };
(function() { try { var q = /[?&]hero=([01])/.exec(location.search); if (q) FW_HERO.ON = q[1] === "1"; } catch (e) {} })();
// (19-nov-2026, N2; docs/encargos-19nov/N2.md) F9 / F34 EN EL VISOR. MEDIDO: la llegada final del Tour a la nebulosa principal ya era la de PixInsight tras F9 (fwFlySel, fw_viewer.js, vuela la fila principal por su contorno medido,
// fvObjFrameFit con S y F34 en el motor copiado: Rosette 2 474 a.l., IC 1396 1 937, Soul 3 801, Pleiades 248, las mismas que PixInsight, 100 % de la huella en pantalla). Lo que le faltaba era F34.MARK: con la principal elegida
// (kind «nebula») el marcador iba a la esquina (0, 0) y el hilo de la ficha salia de alli.
//   MARK   el marcador de seleccion cae en el centro del contorno (o.frame.pos) de un objeto con contorno (kind object) o de la nebulosa principal (kind nebula con obj), como fvCardAnchor con FV_F34.MARK
// ON = false (o ?f9=0 en la URL) = lo de antes. Un paquete sin contorno (o.frame) no cambia con ninguna bandera.
var FW_F9 = { ON: true, MARK: true };
(function() { try { var q = /[?&]f9=([01])/.exec(location.search); if (q) FW_F9.ON = q[1] === "1"; } catch (e) {} })();
function fwF9MarkObj(sel, scene) {
   if (!FW_F9.ON || !FW_F9.MARK || !sel || !scene || !scene.objects || typeof FV_OBJ === "undefined" || !FV_OBJ.FRAME) return null;
   var i = sel.kind === "object" ? sel.i : ((sel.kind === "nebula" && sel.obj >= 0) ? sel.obj : -1), o = i >= 0 ? scene.objects[i] : null;
   if (!o || !o.frame || !o.frame.pos || o.type === "star" || o.type === "exoplanet") return null;
   if (sel.kind === "nebula" && !o.main) return null;
   return o;
}
// ¿es el protagonista dibujado (scene.objects[i].hero)? La MARCA de la fila solo depende de ON; FIRST decide si se ordena la primera y TOUR si el Tour acaba en ella (tres decisiones independientes)
function fwNavHero(o) { return !!(o && o.hero === true && FW_HERO.ON); }
// (F8; FW_HERO.TOUR) las paradas del Tour con el protagonista de la foto la ULTIMA (fvTourPick de PixInsight: «su hueco esta reservado»). El protagonista es la fila con `hero` (el objeto dibujado) o, si es la
// nebulosa principal (IC 2118 promovida, o la de siempre), la fila `main`; sin scene.hero (paquete anterior, foto sin protagonista) o con la bandera a false, la lista tal cual. Las demas paradas, en su orden.
function fwHeroTourItems(items, scene) {
   if (!FW_HERO.ON || !FW_HERO.TOUR || !scene || !scene.hero || !items || items.length < 2) return items;
   var h = -1, i;
   for (i = 0; i < items.length && h < 0; ++i) if (items[i].hero) h = i;
   if (h < 0) for (i = 0; i < items.length && h < 0; ++i) if (items[i].main) h = i;
   if (h < 0 || h === items.length - 1) return items;
   var out = items.slice(); out.push(out.splice(h, 1)[0]); return out;
}
function fwNavRank(it) { if (it.main || (it.hero && FW_HERO.FIRST)) return 0; if (it.type === "exoplanet") return 3; if (it.type === "star") return 2; return 1; }
function fwNavOrder(items, max) {
   if (FW_NAV.ORDER_OLD) return items.slice().sort(function(a, b) { return (b.score || 0) - (a.score || 0); }).slice(0, max);
   var g = [[], [], [], []], i, capExo = Math.max(1, Math.floor(max * FW_NAV.EXO_FRAC)), out = [];
   for (i = 0; i < items.length; ++i) g[fwNavRank(items[i])].push({ it: items[i], k: i });
   for (i = 0; i < 4; ++i) g[i].sort(function(a, b) { return (((b.it.hero && FW_HERO.FIRST) ? 1 : 0) - ((a.it.hero && FW_HERO.FIRST) ? 1 : 0)) || ((b.it.score || 0) - (a.it.score || 0)) || (a.k - b.k); });      // (F8) el protagonista primero (con FW_HERO.FIRST)
   if (g[3].length > capExo) g[3] = g[3].slice(0, capExo);
   var all = g[0].concat(g[1], g[2], g[3]);
   for (i = 0; i < all.length && out.length < max; ++i) out.push(all[i].it);
   return out;
}
// (I3) el elemento de la lista de UN objeto de la escena (la lista y el buscador de fw_search.js comparten esta funcion)
function fwNavCap(t) { t = String(t || ""); return t.length ? t.charAt(0).toUpperCase() + t.substring(1) : t; }
// (P27c) el icono de la nebulosa PRINCIPAL: la clave de FV_OBJ_LABEL (engine/fv_objects.js, la misma tabla que PixInsight) cuya etiqueta es la de la escena; sin ella, `type`
function fwNavIconKind(type, typeLabel) {
   if (FW_NAV.ICON_BY_TYPE === false || !typeLabel || typeof typeLabel !== "object" || typeof FV_OBJ_LABEL === "undefined") return type;
   for (var k in FV_OBJ_LABEL) if (FV_OBJ_LABEL.hasOwnProperty(k) && FV_OBJ_LABEL[k].en === typeLabel.en && FV_OBJ_LABEL[k].es === typeLabel.es) return (k === "rne" ? "nebula" : k);
   return type;
}
// (P32, 17-nov) el tipo CORTO de la fila de un renglon (gemelo de fvNavSubShort, src/ui/fv_nav.js): «Nebulosa de reflexion» no cabe donde cabia «Nebulosa»
function fwNavSubShort(o) {
   if (typeof FV_OBJ === "undefined" || FV_OBJ.RNE_LABEL === false || !o.typeLabel || typeof FV_OBJ_LABEL === "undefined" || !FV_OBJ_LABEL.rne || o.typeLabel.en !== FV_OBJ_LABEL.rne.en) return "";
   return fwNavCap(fwNameOf(FV_OBJ_LABEL.nebula, ""));
}
function fwNavObjItem(scene, i) {
   var L = FW_LANG === "es" ? "es" : "en", o = scene.objects[i], tl = o.typeLabel ? (o.typeLabel[L] || o.typeLabel.en || o.type) : o.type;
   if (o.main && scene.nebula) return { kind: "nebula", i: i, main: true, score: o.score || 0, name: fwNameOf(scene.nebula.names || o.name || scene.nebula.name, fwNavT("neb")), type: "nebula", icon: fwNavIconKind("nebula", scene.nebula.typeLabel || o.typeLabel), dist: o.distLy, sub: (FW_NAV.LABELS !== false ? fwNavCap(fwNameOf(scene.nebula.typeLabel || o.typeLabel, fwNavT("neb"))) : fwNameOf(scene.nebula.typeLabel || o.typeLabel, fwNavT("neb"))) + " · " + fwNavDist(o.distLy, o.distSrc) };
   // (Blender 5b · R5-1) el planeta de DEMOSTRACION (fvObjIsDemo, src/engine/fv_objects.js): «DEMO ·» y no la distancia de la estrella del campo como suya; como PixInsight (fvNavObjItem)
   if (typeof fvObjIsDemo === "function" && fvObjIsDemo(o) && typeof fvTx === "function") return { kind: "object", i: i, score: o.score || 0, name: "DEMO · " + (o.name || o.id || "?"), type: "exoplanet", dist: o.distLy, sub: fvTx("b5.navDemo", { d: fwNavDist(o.distLy, o.distSrc) }, L) };
   var nm = o.name || o.id || "?", dt = (o.distLy > 0 ? fwNavDist(o.distLy, o.distSrc) : "");
   // (B, 14-nov) la estrella elegida por un criterio: el titulo ES el criterio (o.label, exportado), su valor y la distancia debajo; el nombre de catalogo, en la ayuda
   var lb = (FW_NAV.LABELS !== false && o.label && o.label[L]) ? o.label : null;
   if (lb) {
      var lt = lb[L], lo = lb[L === "es" ? "en" : "es"];
      return { kind: "object", i: i, hero: fwNavHero(o), score: o.score || 0, name: lt.t, cat: nm, crit: lb.crit, type: o.type || "other", dist: o.distLy, sub: (lt.v ? lt.v + (dt ? " · " : "") : "") + dt, tip: lt.t + (lt.v ? " · " + lt.v : "") + "\n" + nm + "\n" + lt.d + "\n" + lo.d };
   }
   return { kind: "object", i: i, hero: fwNavHero(o), score: o.score || 0, name: nm, type: o.type || "other", dist: o.distLy, sub: (FW_NAV.LABELS !== false ? fwNavCap(tl) : tl) + (dt ? " · " + dt : ""), subShort: fwNavSubShort(o) };
}
// (21-nov, T1-A) la fila «sin datos» (scene.noData): gemelo de fvNavNoDataItem (src/ui/fv_nav.js); no es un destino (kind «nodata»)
function fwNavNoDataItem(nd) {
   var L = FW_LANG === "es" ? "es" : "en", lb = nd.label, lt = lb[L], lo = lb[L === "es" ? "en" : "es"];
   return { kind: "nodata", noData: true, i: -1, score: nd.score || 0, name: lt.t, cat: "", crit: lb.crit, type: "star", icon: "star", dist: 0, sub: lt.v, tip: lt.t + " · " + lt.v + "\n" + lt.d + "\n" + lo.d };
}
function fwNavItems(scene) {
   var out = [], i, L = FW_LANG === "es" ? "es" : "en";
   if (scene.objects && scene.objects.length) {
      for (i = 0; i < scene.objects.length; ++i) out.push(fwNavObjItem(scene, i));
      if (FW_NAV.NODATA_ROW !== false && FW_NAV.LABELS !== false && scene.noData) for (i = 0; i < scene.noData.length; ++i) if (scene.noData[i] && scene.noData[i].label && scene.noData[i].label[L]) out.push(fwNavNoDataItem(scene.noData[i]));
      return fwNavOrder(out, FW_NAV.LIST_MAX);
   }
   // sin objetos de C: la nebulosa y las estrellas notables (fvTourPick del motor, con el radio de src/science)
   var S = scene.stars;
   if (scene.nebula) out.push({ kind: "nebula", name: fwNameOf(scene.nebula.names || scene.nebula.name, fwNavT("neb")), type: "nebula", icon: fwNavIconKind("nebula", scene.nebula.typeLabel), dist: scene.nebula.distLy, sub: fwNameOf(scene.nebula.typeLabel, fwNavT("neb")) + " · " + fwNavDist(scene.nebula.distLy, scene.nebula.measured ? "measured" : "assumed") });
   if (typeof fvTourPick === "function") {
      var info = function(k) { var m = S.meta[k] || {}; if (!(m.teff > 0) || typeof fvsStar !== "function") return null; try { var st = fvsStar({ teff: m.teff, G: S.g[k], ruwe: m.ruwe, rgeo: (S.q[k] < 2 && m.distPc > 0) ? { pc: m.distPc, lo: m.lo, hi: m.hi } : undefined }); return { radius: st.radius, teff: m.teff }; } catch (e) { return null; } };
      var list = fvTourPick(scene, info, [], 6);
      for (i = 0; i < list.length; ++i) if (list[i].kind === "star") { var k = list[i].i; out.push({ kind: "star", i: k, name: fwNavT(list[i].why), type: "star", dist: S.dEarth[k], sub: "G " + S.g[k].toFixed(1).replace(".", FW_LANG === "es" ? "," : ".") + " · " + fwNavDist(S.dEarth[k], S.q[k] === 0 ? "measured" : "assumed") }); }
   }
   return out;
}
function fwNavDist(d, src) { return (src === "assumed" ? "~" : "") + fwNavNum(d) + " " + fwNavT("ly"); }
// la seleccion del piloto de un elemento de la lista
function fwNavSel(scene, it) {
   if (it.noData) return null;      // (21-nov, T1-A) la fila «sin datos» no es un destino
   if (it.kind === "nebula") return { kind: "nebula", sx: 0, sy: 0, obj: (it.i >= 0 ? it.i : -1) };   // (P11b) obj: el objeto principal de la escena, para que el VUELO use el encuadre de R8 (fwFlySel, fw_viewer.js)
   if (it.kind === "star") return { kind: "star", i: it.i };
   var o = scene.objects[it.i];
   if ((o.type === "star" || o.type === "exoplanet") && o.star >= 0) return { kind: "star", i: o.star, obj: it.i };
   return { kind: "object", i: it.i };
}

// ---------------------------------------------------------------------------
// el campo de vision sobre la foto (fvNavFov de src/ui/fv_nav.js): el borde de la pantalla, 32 puntos, al plano de referencia
// ---------------------------------------------------------------------------
function fwNavPhotoUV(scene, p) { if (!(p[2] > 1e-9)) return null; var f = scene.field; return [(f.width / 2 + f.F * p[0] / p[2]) / f.width, (f.height / 2 + f.F * p[1] / p[2]) / f.height]; }
// la fraccion de la foto (0…1 en u, v) que queda dentro del poligono (rejilla de 16 × 10 puntos, par-impar)
function fwNavCover(poly) {
   if (!poly || poly.length < 3) return 0;
   var n = 0, tot = 0, i, j, a, b;
   for (var y = 0; y < 10; ++y) for (var x = 0; x < 16; ++x) {
      var u = (x + 0.5) / 16, v = (y + 0.5) / 10, inside = false; ++tot;
      for (i = 0, j = poly.length - 1; i < poly.length; j = i++) { a = poly[i]; b = poly[j]; if (((a[1] > v) !== (b[1] > v)) && (u < (b[0] - a[0]) * (v - a[1]) / (b[1] - a[1]) + a[0])) inside = !inside; }
      if (inside) ++n;
   }
   return n / tot;
}
function fwNavBoxArea(poly) { var a = 1e9, b = -1e9, c = 1e9, d = -1e9; for (var i = 0; i < poly.length; ++i) { a = Math.min(a, poly[i][0]); b = Math.max(b, poly[i][0]); c = Math.min(c, poly[i][1]); d = Math.max(d, poly[i][1]); } return poly.length ? (b - a) * (d - c) : 0; }
function fwNavFov(scene, P) {
   var out = { poly: [], away: false, ship: null, look: null }, cam = P.cam, pr = fvProjector(cam, P.VW, P.VH), N = scene.nebula, pos = cam.pos, dRef = N ? N.distLy : 1000;
   var zRef = (pos[2] < 0.85 * dRef) ? dRef : pos[2] + 0.6 * dRef;
   function ray(sx, sy) { var u = (sx - pr.cx) / pr.f, v = (sy - pr.cy) / pr.f; return [pr.fw[0] + u * pr.r[0] + v * pr.d[0], pr.fw[1] + u * pr.r[1] + v * pr.d[1], pr.fw[2] + u * pr.r[2] + v * pr.d[2]]; }
   function hit(d) { if (!(d[2] > 1e-9)) return null; var t = (zRef - pos[2]) / d[2]; if (!(t > 0)) return null; return fwNavPhotoUV(scene, [pos[0] + t * d[0], pos[1] + t * d[1], zRef]); }
   var W = P.VW, H = P.VH, n = 8, pts = [], k;
   for (k = 0; k < n; ++k) pts.push([W * k / n, 0]); for (k = 0; k < n; ++k) pts.push([W, H * k / n]);
   for (k = 0; k < n; ++k) pts.push([W - W * k / n, H]); for (k = 0; k < n; ++k) pts.push([0, H - H * k / n]);
   for (k = 0; k < pts.length; ++k) { var q = hit(ray(pts[k][0], pts[k][1])); if (q) out.poly.push(q); }
   out.look = hit(ray(W / 2, H / 2)); out.away = out.poly.length < 3 || !out.look;
   if (fvLen(pos) > 1e-6) out.ship = fwNavPhotoUV(scene, pos);
   return out;
}

// ---------------------------------------------------------------------------
// el mapa 3D (FVNavMap3D de src/ui/fv_nav.js): profundidad logaritmica, cono exagerado a lo ancho, proyeccion de gabinete
// ---------------------------------------------------------------------------
function FWMap3D(scene) {
   this.scene = scene; var S = scene.stars, N = scene.nebula, ds = [], i;
   for (i = 0; i < S.n; ++i) if (S.inFrame[i]) ds.push(S.dEarth[i]);
   ds.sort(function(a, b) { return a - b; });
   var p97 = ds.length ? ds[Math.min(ds.length - 1, Math.floor(0.97 * ds.length))] : 1000;
   this.dMax = Math.max(100, N ? 1.35 * N.distLy : 0, p97); this.d0 = this.dMax / 250;
   var f = scene.field; this.hx = (f.width / 2) / f.F; this.hy = (f.height / 2) / f.F;
   this.view = null;                  // (nD2) null = gabinete (la franja); { az, el, zoom } = vista orbitable (el mapa grande de fw_route.js)
   this.tilt = [0, 0];                // (nD2) inclinacion de los planos de la nebulosa (grados, X luego Y)
}
// (nD2, encargo E5) LA VISTA ORBITABLE Y LOS PLANOS INCLINADOS: copia de src/ui/fv_nav.js (FV_NAV_ORBIT, fvNavTiltPt, setView, slabWorld, slabPt)
var FW_NAV_ORBIT = { AZ0: 27, EL0: 21, EL_MIN: -85, EL_MAX: 85, Z_MIN: 0.5, Z_MAX: 8, L: 0.86, DEG_PER_W: 200, DEG_PER_H: 140, WHEEL: 1.15, TILT_MAX: 60, TILT_DEG_PX: 0.35 };
function fwNavViewHome() { return { az: FW_NAV_ORBIT.AZ0, el: FW_NAV_ORBIT.EL0, zoom: 1 }; }
function fwNavTiltPt(p, D, tilt) {
   if (!tilt || (!tilt[0] && !tilt[1])) return p.slice();
   var q = [p[0], p[1], p[2] - D];
   q = fvRotate(q, [1, 0, 0], tilt[0] * FV_DEG); q = fvRotate(q, [0, 1, 0], tilt[1] * FV_DEG);
   return [q[0], q[1], q[2] + D];
}
function fwNavTiltNormal(tilt) { return fvNorm(fwNavTiltPt([0, 0, 1], 0, tilt)); }
FWMap3D.prototype.setView = function(v) { this.view = v ? { az: +v.az, el: fvClamp(+v.el, FW_NAV_ORBIT.EL_MIN, FW_NAV_ORBIT.EL_MAX), zoom: fvClamp(+v.zoom || 1, FW_NAV_ORBIT.Z_MIN, FW_NAV_ORBIT.Z_MAX) } : null; };
FWMap3D.prototype.slabWorld = function(D) {
   var hx = this.hx * D, hy = this.hy * D, C = [[-hx, -hy], [hx, -hy], [hx, hy], [-hx, hy]], out = [];
   for (var i = 0; i < 4; ++i) out.push(fwNavTiltPt([C[i][0], C[i][1], D], D, this.tilt));
   return out;
};
// la losa en el mapa: el ANGULO elegido, girado en el espacio del mapa (ver slabLocal en src/ui/fv_nav.js: en el mundo apenas cambia la profundidad)
FWMap3D.prototype.slabLocal = function(s, lx, ly) { var q = fwNavTiltPt([lx * 0.30 * s, ly * 0.30 * s * (this.hy / this.hx), 0], 0, this.tilt); return [s + q[2], q[0], -q[1]]; };
FWMap3D.prototype.slabPt = function(s, lx, ly, w, h) { return this.screen(this.slabLocal(s, lx, ly), w, h); };
FWMap3D.prototype.depth = function(d) { return Math.log(1 + Math.max(0, d) / this.d0) / Math.log(1 + this.dMax / this.d0); };
FWMap3D.prototype.model = function(p) {
   var d = fvLen(p); if (d < 1e-9) return [0, 0, 0];
   var z = Math.max(p[2], 1e-9 * d), s = this.depth(d), a = fvClamp((p[0] / z) / this.hx, -1.8, 1.8), b = fvClamp((p[1] / z) / this.hy, -1.8, 1.8);
   if (p[2] <= 0) { a = fvClamp(p[0] / d * 4, -1.8, 1.8); b = fvClamp(p[1] / d * 4, -1.8, 1.8); }
   return [s, a * 0.30 * s, -b * 0.30 * s * (this.hy / this.hx)];
};
FWMap3D.prototype.screen = function(m, w, h) {
   var v = this.view;
   if (v) { var az = v.az * FV_DEG, el = v.el * FV_DEG, d0 = m[0] - 0.5, xr = d0 * Math.cos(az) + m[1] * Math.sin(az), yd = -d0 * Math.sin(az) + m[1] * Math.cos(az), up = m[2] * Math.cos(el) + yd * Math.sin(el), Lv = Math.min(FW_NAV_DET.BIG_L * w, FW_NAV_DET.BIG_LH * h) * v.zoom;   // (nD3) cabe entero
            return [FW_NAV_DET.BIG_CX * w + Lv * xr, FW_NAV_DET.BIG_CY * h - Lv * up]; }
   var L = w * 0.80, ca = Math.cos(0.62), sa = Math.sin(0.62); return [0.07 * w + L * (m[0] + 0.55 * m[1] * ca), 0.56 * h - L * (m[2] + 0.55 * m[1] * sa)]; };
FWMap3D.prototype.pt = function(p, w, h) { return this.screen(this.model(p), w, h); };
FWMap3D.prototype.M = function(s, a, b, w, h) { return this.screen([s, a * 0.30 * s, -b * 0.30 * s * (this.hy / this.hx)], w, h); };

// ---------------------------------------------------------------------------
// LA FRANJA DE NAVEGACION. root: el contenedor (#nav). hooks: { look(dir), travel(sel), select(sel) }
// ---------------------------------------------------------------------------
function FWNav(scene, photoImg, hooks) {
   var self = this; this.scene = scene; this.hooks = hooks || {}; this.photo = photoImg; this.map = new FWMap3D(scene);
   this.c2 = document.getElementById("nav2d"); this.c3 = document.getElementById("nav3d"); this.listEl = document.getElementById("navList");
   this.g2 = this.c2.getContext("2d"); this.g3 = this.c3.getContext("2d");
   this.key = ""; this.last = 0; this.stat3 = null; this.thumb = null; this.dirty = true;
   document.getElementById("nav2dCap").textContent = fwNavT("tabula"); document.getElementById("nav2dWrap").title = fwNavT("tabulaTip");
   document.getElementById("nav3dCap").textContent = fwNavT("prof"); document.getElementById("nav3dWrap").title = fwNavT("profTip");
   document.getElementById("navListCap").textContent = fwNavT("mir"); document.getElementById("navListWrap").title = fwNavT("mirTip");
   this.items = fwNavItems(scene); this.shown = null; this.emptyMsg = ""; this.buildList();
   // (I3) el buscador de MIRABILIA (fw_search.js): sus resultados sustituyen lo que se ve de la lista (this.shown), no la lista (this.items)
   this.search = (typeof FWSearch === "function") ? new FWSearch(this, scene) : null;
   // clics en la miniatura 2D: mirar alli (clic) o viajar a lo mas cercano (doble clic)
   var clickT = null;
   // (pasada M) con hooks.open (fw_route.js) un clic en TABULA o PROFUNDITAS la abre en grande; lo de antes queda sin él
   this.c2.addEventListener("click", function(e) {
      if (self.hooks.open) { self.hooks.open("map2d"); return; }
      var uv = self.uv2(e); if (!uv) return;
      if (clickT) clearTimeout(clickT);
      clickT = setTimeout(function() { clickT = null; if (self.hooks.lookAt) self.hooks.lookAt(uv); }, 240);
   });
   this.c2.addEventListener("dblclick", function(e) { if (self.hooks.open) return; if (clickT) { clearTimeout(clickT); clickT = null; } var uv = self.uv2(e); if (uv && self.hooks.travelNear) self.hooks.travelNear(uv); });
   this.c3.addEventListener("click", function(e) { if (self.hooks.open) { self.hooks.open("map3d"); return; } var s = self.pick3(e); if (s && self.hooks.select) self.hooks.select(s); });
   [this.c2, this.c3, this.listEl].forEach(function(el) { ["pointerdown", "wheel", "dblclick"].forEach(function(t) { el.addEventListener(t, function(ev) { ev.stopPropagation(); }, { passive: true }); }); });
}
FWNav.prototype.buildList = function() {
   var el = this.listEl, self = this, list = this.shown || this.items; el.innerHTML = "";
   if (!this.shown && typeof fwE1cFaceItems === "function") { var aen = fwE1cFaceItems(this); if (aen) list = aen; }      // (19-nov, I1; FW_E1C) la placa girada enseña los sobres de AENIGMATA (web/fw_e1c.js)
   if (!list.length) { var e0 = document.createElement("div"); e0.className = "nv-empty"; e0.textContent = this.emptyMsg || fwNavT("empty"); el.appendChild(e0); this.rows = []; return; }
   this.rows = [];
   list.forEach(function(it, k) {
      var r = document.createElement("div"); r.className = "nv-row"; r.setAttribute("data-k", k); r.tabIndex = 0;
      r.innerHTML = "<span class='nv-ic'></span><span class='nv-tx'><span class='nv-nm'></span><span class='nv-sb'></span><span class='nv-s1'></span></span><button class='nv-go' type='button'>➤</button>";
      r.querySelector(".nv-nm").textContent = it.name; r.querySelector(".nv-sb").textContent = it.sub || ""; r.querySelector(".nv-go").title = fwNavT("go");
      var sg1 = String(it.sub || "").split(" · ")[0]; var s1e = r.querySelector(".nv-s1"); s1e.textContent = sg1 ? "· " + sg1 : ""; s1e.setAttribute("data-lg", s1e.textContent); s1e.setAttribute("data-sh", it.subShort ? "· " + it.subShort : "");       // (B) la primera parte del subtitulo, para la fila de un renglon
      if (it.tip) r.title = it.tip;                       // (B) la ayuda de una fila con rotulo: titulo, nombre de catalogo y el criterio exacto
      fwNavIconSvg(r.querySelector(".nv-ic"), it.icon || it.type);      // (P27c) it.icon = el del tipo real de la principal
      if (it.noData) { r.classList.add("nd"); r.setAttribute("aria-disabled", "true"); r.querySelector(".nv-go").style.display = "none"; el.appendChild(r); self.rows.push(r); return; }      // (21-nov, T1-A) «sin datos»: apagada, sin flecha ni clics (no es un destino); la ayuda se queda
      r.addEventListener("click",function(e) { if (e.target.classList.contains("nv-go")) return; if (self.hooks.select) self.hooks.select(fwNavSel(self.scene, it), it); });
      r.addEventListener("dblclick", function() { if (self.hooks.travel) self.hooks.travel(fwNavSel(self.scene, it), it); });
      r.querySelector(".nv-go").addEventListener("click", function(e) { e.stopPropagation(); if (self.hooks.travel) self.hooks.travel(fwNavSel(self.scene, it), it); });
      el.appendChild(r); self.rows.push(r);
   });
   this.layoutList();
};
// (B, 14-nov) cuantas filas caben. Letra minima: titulo 7,5 px y subtitulo 7 px (la de la cabina). Modo 2 = dos renglones, la fila lo que miden (1,02·(t + s) + ROW_PAD);
// si asi no salen ROW2_MIN filas en la caja (ventana pequeña), modo 1 = un renglon de t + ROW1_PAD (el subtitulo, si cabe ENTERO, detras: .nv-s1). La fila = 1/n de la caja
// (CSS --nvN; #navList.v2 y .c1). LIST_V2 false = ROJO: sin las clases, las cuatro filas de antes (25 % cada una)
FWNav.prototype.layoutList = function() {
   var el = this.listEl, wrap = document.getElementById("navListWrap");
   if (!el || !wrap) return;
   el.classList.toggle("v2", FW_NAV.LIST_V2 !== false);
   if (FW_NAV.LIST_V2 === false) { el.classList.remove("c1"); el.style.removeProperty("--nvN"); this.nRows = 4; this.mode = 0; return; }
   var u = wrap.clientWidth / 17, H = el.clientHeight;
   if (!(u > 0) || !(H > 0)) return;
   var tPx = Math.max(FW_NAV.ROW_TMIN, FW_NAV.ROW_T * u), sPx = Math.max(FW_NAV.ROW_SMIN, FW_NAV.ROW_S * u), need2 = 1.02 * (tPx + sPx) + FW_NAV.ROW_PAD;
   var tMin = tPx, sMin = sPx, fit = FW_NAV.LIST_FIT | 0;
   // (P24) LIST_FIT 1 · 2: siempre dos renglones; la 1 con la letra mayor (--nvT / --nvS, CSS #navList.fit1); la 2 con la de hoy y las filas = 1/n de la caja (holgadas, el texto centrado)
   // (D2, 16-nov, decision de Nino) LIST_FIT 3 = la variante 1 SOLO donde hoy la lista caia a un renglon (no caben ROW2_MIN filas de dos renglones); si caben, lo de hoy
   // y solo si la letra de hoy es MENOR que la de la variante (a 1920x1080 el titulo ya mide 10,3 px: ahi la variante solo quitaba una fila)
   if (fit === 3) fit = (Math.floor(H / need2 + 1e-6) >= FW_NAV.ROW2_MIN || tPx >= FW_NAV.FIT1_T) ? 0 : 1;
   if (fit === 1) { tPx = Math.max(tPx, FW_NAV.FIT1_T); sPx = Math.max(sPx, FW_NAV.FIT1_S); need2 = 1.02 * (tPx + sPx); }      // (variante 1: sin la holgura ROW_PAD de hoy; con ella 1280×800 daba 3 filas por 0,5 px: 73,5 / 18,5 = 3,96)
   var n2 = Math.max(1, Math.floor(H / need2 + 1e-6)), mode = (n2 >= FW_NAV.ROW2_MIN || fit === 1 || fit === 2) ? 2 : 1, n = (mode === 2) ? n2 : Math.max(1, Math.floor(H / (tPx + FW_NAV.ROW1_PAD) + 1e-6));
   this.nRows = n; this.mode = mode; el.classList.toggle("c1", mode === 1); el.style.setProperty("--nvN", String(n));
   el.classList.toggle("fit1", fit === 1);
   if (fit === 1) {
      el.style.setProperty("--nvT", tPx + "px"); el.style.setProperty("--nvS", sPx + "px");
      // el titulo y el subtitulo que no caben a esa letra bajan 0,5 px cada vez hasta la de hoy (tMin / sMin); a esa, el «…» de siempre
      Array.prototype.forEach.call(el.querySelectorAll(".nv-row"), function(r) {
         var nm = r.querySelector(".nv-nm"), sb = r.querySelector(".nv-sb"), p;
         nm.style.fontSize = ""; sb.style.fontSize = "";
         for (p = tPx; nm.scrollWidth > nm.clientWidth + 1 && p > tMin; ) { p = Math.max(tMin, p - 0.5); nm.style.fontSize = p + "px"; }
         for (p = sPx; sb.scrollWidth > sb.clientWidth + 1 && p > sMin; ) { p = Math.max(sMin, p - 0.5); sb.style.fontSize = p + "px"; }
      });
   } else {
      el.style.removeProperty("--nvT"); el.style.removeProperty("--nvS");
      Array.prototype.forEach.call(el.querySelectorAll(".nv-nm,.nv-sb"), function(x) { x.style.fontSize = ""; });
   }
   if (mode === 1) Array.prototype.forEach.call(el.querySelectorAll(".nv-row"), function(r) {      // la primera parte del subtitulo solo si cabe entera
      var tx = r.querySelector(".nv-tx").getBoundingClientRect(), s1 = r.querySelector(".nv-s1"), b;
      s1.textContent = s1.getAttribute("data-lg") || s1.textContent; b = s1.getBoundingClientRect();
      if (s1.getAttribute("data-sh") && !(b.width > 0 && b.right <= tx.right + 0.5)) { s1.textContent = s1.getAttribute("data-sh"); b = s1.getBoundingClientRect(); }
      s1.style.visibility = (b.width > 0 && b.right <= tx.right + 0.5) ? "visible" : "hidden";
   });
};
// marca en la lista lo elegido
FWNav.prototype.markSel = function(sel) {
   if (!this.rows) return;
   var list = this.shown || this.items;
   for (var k = 0; k < list.length && k < this.rows.length; ++k) {
      var it = list[k]; if (it.noData) continue;      // (21-nov, T1-A) la fila «sin datos» no se elige
      var s = fwNavSel(this.scene, it), on = !!sel && sel.kind === s.kind && (s.kind === "nebula" || sel.i === s.i);
      if (this.rows[k].classList.contains("on") !== on) this.rows[k].classList.toggle("on", on);
   }
};
FWNav.prototype.uv2 = function(e) {
   var b = this.c2.getBoundingClientRect(), R = this.rect2; if (!R) return null;
   var x = (e.clientX - b.left) * this.c2.width / b.width, y = (e.clientY - b.top) * this.c2.height / b.height;
   var u = (x - R[0]) / R[2], v = (y - R[1]) / R[3]; return (u >= 0 && u <= 1 && v >= 0 && v <= 1) ? [u, v] : null;
};
FWNav.prototype.pick3 = function(e) {
   var b = this.c3.getBoundingClientRect(), x = (e.clientX - b.left) * this.c3.width / b.width, y = (e.clientY - b.top) * this.c3.height / b.height, w = this.c3.width, h = this.c3.height, best = null, bd = 14 * (this.dpr || 1);
   var sc = this.scene, i;
   if (sc.objects) for (i = 0; i < sc.objects.length; ++i) { var o = sc.objects[i]; if (!o.pos) continue; var q = this.map.pt(fwBoxMapPos(sc, o), w, h), d = Math.hypot(q[0] - x, q[1] - y); if (d < bd) { bd = d; best = fwNavSel(sc, { kind: o.main ? "nebula" : "object", i: i }); } }
   if (!best && this.idx3) for (i = 0; i < this.idx3.length; ++i) { var k = this.idx3[i], q2 = this.map.pt(fvStarPos(sc, k), w, h), d2 = Math.hypot(q2[0] - x, q2[1] - y); if (d2 < bd * 0.6) { bd = d2 / 0.6; best = { kind: "star", i: k }; } }
   return best;
};
// el tamaño en pixeles reales de los dos lienzos (proporcional a la ventana: N7)
FWNav.prototype.resize = function() {
   var dpr = Math.min(2, window.devicePixelRatio || 1); this.dpr = dpr;
   [this.c2, this.c3].forEach(function(c) { var w = Math.max(16, Math.round(c.clientWidth * dpr)), h = Math.max(16, Math.round(c.clientHeight * dpr)); if (c.width !== w || c.height !== h) { c.width = w; c.height = h; } });
   this.stat3 = null; this.thumb = null; this.dirty = true;
   this.layoutList();
   // (D, rev. 1) al cambiar de tamaño el lienzo se borra: se repinta YA (antes esperaba al siguiente fotograma del bucle y, con el reloj
   // parado o el bucle sin cambios, TABULA y PROFUNDITAS se quedaban negras)
   if (this.lastP && this.c2.clientWidth > 0) { try { this.paint2(this.lastP, this.lastSel); this.paint3(this.lastP, this.lastSel); this.key = ""; } catch (e) {} }
};
// (nD3, 4-nov-2026; Nino: «PROFUNDITAS debe tener mayor resolucion y detalle») gemelo de FVNavMap3D.buildStatic de src/ui/fv_nav.js:
// estrellas de la escena por superficie (tamaño y opacidad por magnitud G, color de la escena), la losa con la miniatura de la foto (afin),
// regla de distancias grabada (marcas 2…9 de cada decada, decadas rotuladas, corte del cono en cada decada), rotulos de MIRABILIA sin pisarse
var FW_NAV_DET = { STRIP_STARS: 1600, BIG_STARS: 4000, STRIP_PX: 12, BIG_PX: 110, STRIP_LAB: 2, CONE_DEG: 16, CONE_L: 4.2, BIG_LAB: 10, LAB_CH: 20,
                   THUMBS: [192, 384, 768, 1536], SLAB_OP: 0.88, BIG_L: 0.80, BIG_CX: 0.45, BIG_CY: 0.52, BIG_LH: 1.0 };
// la miniatura de la foto con el lado largo >= px (escalones fijos, cacheados en el mapa)
FWMap3D.prototype.photoThumb = function(img, px) {
   if (!img) return null;
   var iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height; if (!(iw > 0 && ih > 0)) return null;
   if (this.thumbImg !== img) { this.thumbImg = img; this.thumbs = {}; }
   var L = FW_NAV_DET.THUMBS, want = L[L.length - 1], i;
   for (i = 0; i < L.length; ++i) if (L[i] >= px) { want = L[i]; break; }
   if (this.thumbs[want] !== undefined) return this.thumbs[want];
   var s = Math.min(1, want / Math.max(iw, ih)), src = img;
   if (want < L[L.length - 1]) { var m = this.photoThumb(img, L[L.length - 1]); if (m) src = m; }
   var cv = document.createElement("canvas"); cv.width = Math.max(2, Math.round(iw * s)); cv.height = Math.max(2, Math.round(ih * s));
   var g = cv.getContext("2d"); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = "high";
   try { g.drawImage(src, 0, 0, cv.width, cv.height); } catch (e) { cv = null; }
   this.thumbs[want] = cv;
   return cv;
};
// la losa con la foto: Q = esquinas en pantalla (arriba-izq, arriba-der, abajo-der, abajo-izq de la foto) -> true si la pinto
FWMap3D.prototype.photoSlab = function(g, img, Q, op) {
   var ax = Q[1][0] - Q[0][0], ay = Q[1][1] - Q[0][1], bx = Q[3][0] - Q[0][0], by = Q[3][1] - Q[0][1];
   if (Math.abs(ax * by - ay * bx) < 4) return false;
   var tb = this.photoThumb(img, Math.max(Math.hypot(ax, ay), Math.hypot(bx, by))); if (!tb) return false;
   g.save(); g.globalAlpha = op; g.imageSmoothingEnabled = true; g.imageSmoothingQuality = "high";
   g.setTransform(ax / tb.width, ay / tb.width, bx / tb.height, by / tb.height, Q[0][0], Q[0][1]);
   g.drawImage(tb, 0, 0); g.restore();
   return true;
};
function fwNavFree(occ, R, box) {
   if (box && (R[0] < box[0] || R[1] < box[1] || R[2] > box[2] || R[3] > box[3])) return false;
   for (var i = 0; i < occ.length; ++i) { var o = occ[i]; if (R[0] < o[2] && R[2] > o[0] && R[1] < o[3] && R[3] > o[1]) return false; }
   return true;
}
// (16-nov, P31a) ¿la caja R = [x0, y0, x1, y1] toca lo que tapa la nave (obs = { arrow: caja, tri: [3 puntos], seg: [x0, y0, x1, y1] })?
function fwNavInTri(t, x, y) {
   var d1 = (x - t[1][0]) * (t[0][1] - t[1][1]) - (t[0][0] - t[1][0]) * (y - t[1][1]), d2 = (x - t[2][0]) * (t[1][1] - t[2][1]) - (t[1][0] - t[2][0]) * (y - t[2][1]), d3 = (x - t[0][0]) * (t[2][1] - t[0][1]) - (t[2][0] - t[0][0]) * (y - t[0][1]);
   return !((d1 < 0 || d2 < 0 || d3 < 0) && (d1 > 0 || d2 > 0 || d3 > 0));
}
function fwNavShipHit(R, obs) {
   if (!obs) return false;
   var A = obs.arrow, t = obs.tri, i, c = [[R[0], R[1]], [R[2], R[1]], [R[2], R[3]], [R[0], R[3]]];
   if (A && R[0] < A[2] && R[2] > A[0] && R[1] < A[3] && R[3] > A[1]) return true;
   if (obs.seg && fwNavClip(obs.seg[0], obs.seg[1], obs.seg[2], obs.seg[3], R)) return true;
   if (t) {
      for (i = 0; i < 3; ++i) { var p = t[i], q = t[(i + 1) % 3]; if (p[0] >= R[0] && p[0] <= R[2] && p[1] >= R[1] && p[1] <= R[3]) return true; if (fwNavClip(p[0], p[1], q[0], q[1], R)) return true; }
      for (i = 0; i < 4; ++i) if (fwNavInTri(t, c[i][0], c[i][1])) return true;
   }
   return false;
}
// la parte de la caja R tapada por la nave (muestreo 32 x 5), para medir
function fwNavShipCover(R, obs) {
   var nx = 32, ny = 5, n = 0, hit = 0, a, b;
   for (a = 0; a < nx; ++a) for (b = 0; b < ny; ++b) {
      var x = R[0] + (a + 0.5) / nx * (R[2] - R[0]), y = R[1] + (b + 0.5) / ny * (R[3] - R[1]); ++n;
      if (obs.arrow && x >= obs.arrow[0] && x <= obs.arrow[2] && y >= obs.arrow[1] && y <= obs.arrow[3]) { ++hit; continue; }
      if (obs.tri && fwNavInTri(obs.tri, x, y)) ++hit;
   }
   return hit / n;
}
function fwNavObjName(sc, o) {
   var n = o.main && sc.nebula ? fwNameOf(sc.nebula.names || sc.nebula.name, "") : "";
   if (!n) n = fwNameOf(o.names || o.name || o.id, "");
   return n.length > FW_NAV_DET.LAB_CH ? n.substr(0, FW_NAV_DET.LAB_CH - 1) + "…" : n;
}
// (16-nov, P23-web) el chevron «sigue mas alla» junto al anillo de un objeto que esta mas lejos que la boca de la caja
function fwNavFarMark(g, x, y, d) { var a = 1.7 * d; g.save(); g.lineWidth = Math.max(1, d); g.lineCap = "round"; g.beginPath(); g.moveTo(x - a, y - a); g.lineTo(x, y); g.lineTo(x - a, y + a); g.moveTo(x, y - a); g.lineTo(x + a, y); g.lineTo(x, y + a); g.stroke(); g.restore(); }
// lo fijo del mapa 3D (cono, regla, losa con la foto, estrellas, rotulos, Tierra) en un lienzo aparte
FWNav.prototype.buildStat3 = function() {
   var w = this.c3.width, h = this.c3.height, d = this.dpr || 1, k = Math.min(this.kMax || 1e9, Math.max(d, w / 184)), cv = document.createElement("canvas"); cv.width = w; cv.height = h;
   var g = cv.getContext("2d"), sc = this.scene, S = sc.stars, N = sc.nebula, mp = this.map, big = !!mp.view, i, j, occ = [];
   var ff = getComputedStyle(document.body).fontFamily, lw = Math.max(1, Math.round(big ? 0.6 * k : d));
   function M(s, a, b) { return mp.M(s, a, b, w, h); }
   function px(v) { return Math.floor(v) + (lw % 2 ? 0.5 : 0); }
   function poly(Q) { g.beginPath(); g.moveTo(Q[0][0], Q[0][1]); for (var n = 1; n < Q.length; ++n) g.lineTo(Q[n][0], Q[n][1]); g.closePath(); }
   var fN = "italic " + Math.round(big ? Math.max(9 * d, 6.6 * k) : Math.max(8 * d, 7.2 * k)) + "px " + ff, fO = "italic " + Math.round(big ? Math.max(10 * d, 7.2 * k) : Math.max(8 * d, 7.2 * k)) + "px " + ff;
   g.font = fN; var aN = Math.round(parseFloat(fN.split(" ")[1]) * 0.72);
   if (big) { occ.push([0, 0, 0.62 * w, 0.09 * h]); occ.push([0.25 * w, 0.88 * h, 0.75 * w, h]); occ.push([0, 0.86 * h, 0.30 * w, h]); }
   else { occ.push([0, 0, 0.75 * w, 22 * k]); }
   // 1. el cono (1 px nitido) y su corte en cada decada, muy tenue
   var E = M(0, 0, 0), C = [M(1, -1, -1), M(1, 1, -1), M(1, 1, 1), M(1, -1, 1)];
   var dec = []; for (var t = 1; t <= 1e6; t *= 10) if (t >= mp.d0 * 1.5 && t <= mp.dMax * 1.02) dec.push(t);
   g.lineWidth = lw; g.strokeStyle = big ? "rgba(201,154,58,.2)" : "rgba(201,154,58,.17)";
   dec.forEach(function(t) { var s = mp.depth(t); poly([M(s, -1, -1), M(s, 1, -1), M(s, 1, 1), M(s, -1, 1)]); g.stroke(); });
   g.strokeStyle = "rgba(201,154,58,.56)"; g.beginPath();
   for (i = 0; i < 4; ++i) { g.moveTo(E[0], E[1]); g.lineTo(C[i][0], C[i][1]); }
   g.moveTo(C[0][0], C[0][1]); for (i = 1; i <= 4; ++i) g.lineTo(C[i % 4][0], C[i % 4][1]); g.stroke();
   // 2. la losa de la nebulosa con la foto
   if (N) {
      var sN = mp.depth(N.distLy), Q = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(function(c) { return mp.slabPt(sN, c[0], c[1], w, h); });
      g.fillStyle = "rgba(176,80,106,.25)"; poly(Q); g.fill();
      this.slabPhoto = mp.photoSlab(g, this.photo, Q, FW_NAV_DET.SLAB_OP);
      g.strokeStyle = "rgba(224,138,160,.7)"; g.lineWidth = lw; poly(Q); g.stroke();
   }
   // 3. las estrellas: las de la escena, tantas como quepan por superficie; tamaño y opacidad por magnitud, color de la escena
   var idx = []; for (i = 0; i < S.n; ++i) if (S.inFrame[i]) idx.push(i);
   idx.sort(function(a, b) { return S.g[a] - S.g[b]; });
   var nMax = big ? Math.min(FW_NAV_DET.BIG_STARS, Math.round(w * h / (FW_NAV_DET.BIG_PX * d * d))) : Math.min(FW_NAV_DET.STRIP_STARS, Math.round(w * h / (FW_NAV_DET.STRIP_PX * d * d)));
   idx = idx.slice(0, Math.max(FW_NAV.MAP_STARS, nMax)); this.idx3 = idx; this.nStars = idx.length;
   var gB = idx.length ? S.g[idx[0]] : 6, gF = idx.length ? S.g[idx[idx.length - 1]] : 16, gR = Math.max(1, gF - gB);
   var rMax = big ? 2.6 * k : 1.6 * k, rMin = (big ? 0.6 : 0.42) * d;
   for (j = idx.length - 1; j >= 0; --j) {
      var s = idx[j], q = mp.pt(fvStarPos(sc, s), w, h), c = S.col[s] >>> 0, u = 1 - fvClamp((S.g[s] - gB) / gR, 0, 1);
      var rr = rMin + (rMax - rMin) * u * u, al = (0.30 + 0.70 * Math.pow(u, 1.2)) * (S.q[s] === 2 ? 0.55 : 1), rgb = ((c >>> 16) & 255) + "," + ((c >>> 8) & 255) + "," + (c & 255);
      if (big && u > 0.82) { var gr = g.createRadialGradient(q[0], q[1], 0, q[0], q[1], rr * 3); gr.addColorStop(0, "rgba(" + rgb + "," + (0.32 * al).toFixed(3) + ")"); gr.addColorStop(1, "rgba(" + rgb + ",0)"); g.fillStyle = gr; g.beginPath(); g.arc(q[0], q[1], rr * 3, 0, 6.2832); g.fill(); }
      g.fillStyle = "rgba(" + rgb + "," + al.toFixed(3) + ")"; g.beginPath(); g.arc(q[0], q[1], rr, 0, 6.2832); g.fill();
   }
   // 4. la regla de distancias, por debajo del cono: marcas finas 2…9 y las decadas mas largas y rotuladas
   var R0 = M(mp.depth(mp.d0 * 1.5), 0, 1.15), R1 = M(1.0, 0, 1.15);
   g.strokeStyle = "rgba(229,181,63,.44)"; g.lineWidth = lw; fwNavLine(g, R0[0], R0[1], R1[0], R1[1]);
   g.font = fN; g.textAlign = "left";
   dec.forEach(function(t) {
      for (var m = 1; m <= 9; ++m) {
         var dt = t * m; if (dt > mp.dMax || dt < mp.d0 * 1.5) continue;
         var tq = M(mp.depth(dt), 0, 1.15), tl = (m === 1 ? 3.6 : (m === 5 ? 2.4 : 1.6)) * (big ? 0.75 * k : k), xx = px(tq[0]);
         g.strokeStyle = m === 1 ? "rgba(229,181,63,.82)" : "rgba(229,181,63,.5)"; g.lineWidth = lw; fwNavLine(g, xx, tq[1] - tl, xx, tq[1] + tl);
      }
      var tk = M(mp.depth(t), 0, 1.15), lab = fwFmtInt(t), lwd = g.measureText(lab).width, tkM = Math.ceil(3.6 * (big ? 0.75 * k : k)) + 2 * d, LR = [tk[0] - lwd / 2 - 1, tk[1] + tkM, tk[0] + lwd / 2 + 1, tk[1] + tkM + d + aN];
      if (fwNavFree(occ, LR, [0, 0, w, h])) { g.fillStyle = "rgba(208,193,165,.85)"; g.fillText(lab, Math.round(tk[0] - lwd / 2), Math.round(tk[1] + tkM + aN)); occ.push(LR); }
   });
   if (N) {
      var tn = M(mp.depth(N.distLy), 1.05, -1.05), nl = fvsFmtSig(N.distLy, 3, FW_LANG) + " " + fwNavT("ly"), nw = g.measureText(nl).width;
      var nx = Math.round(Math.min(w - nw - 2 * d, tn[0] - nw / 2)), ny = Math.round(Math.max(aN + d, tn[1] - 3 * d));
      g.fillStyle = "rgba(232,160,180,.94)"; g.fillText(nl, nx, ny); occ.push([nx - 1, ny - aN - 1, nx + nw + 1, ny + 2 * d]);
   }
   // 5. la Tierra
   var rE = 2.8 * (big ? 0.7 * k : k);
   g.fillStyle = "#6FA8DC"; g.beginPath(); g.arc(E[0], E[1], rE, 0, 6.2832); g.fill(); g.strokeStyle = "#2A4A6A"; g.lineWidth = 0.8 * d; g.stroke();
   var tE = [Math.round(E[0] - 2 * d), Math.round(E[1] + 5 * d + aN)]; g.fillStyle = "rgba(111,168,220,.88)"; g.fillText("TERRA", tE[0], tE[1]); occ.push([tE[0] - 1, tE[1] - aN - 1, tE[0] + g.measureText("TERRA").width + 1, tE[1] + 2 * d]);
   // 6. los iconos de los objetos (antes en cada fotograma: ahora en lo fijo; el elegido se repinta claro encima) y sus rotulos
   g.strokeStyle = "rgba(229,181,63,.85)"; g.lineWidth = d; this.iconLog = [];
   // (16-nov, P23-web; fw_box.js) un objeto de MAS ALLA de la boca (M 82 a 12 millones de a.l.) va en la losa, en su linea de vision (fwBoxMapPos), con el anillo a trazos y un chevron hacia fuera
   if (sc.objects) for (i = 0; i < Math.min(sc.objects.length, FW_NAV.LIST_MAX); ++i) {
      var oi = sc.objects[i]; if (!oi.pos || oi.main) continue;
      var kF = fwBoxMapK(sc, oi), qi = mp.pt(kF < 1 ? fwBoxMapPos(sc, oi) : oi.pos, w, h); this.iconLog.push({ i: i, x: qi[0], y: qi[1], beyond: kF < 1, depth: mp.depth(fvLen(kF < 1 ? fwBoxMapPos(sc, oi) : oi.pos)) });
      if (kF < 1) { g.setLineDash([2 * d, 1.5 * d]); g.beginPath(); g.arc(qi[0], qi[1], 3 * d, 0, 6.2832); g.stroke(); g.setLineDash([]); fwNavFarMark(g, qi[0] + 4.6 * d, qi[1], d); }
      else { g.beginPath(); g.arc(qi[0], qi[1], 3 * d, 0, 6.2832); g.stroke(); }
   }
   // (16-nov, P23-web) con algo de mas alla de la boca en el mapa, su ayuda lo explica (solo la franja: el mapa grande tiene la suya, fw_route.js)
   var wrap3 = document.getElementById("nav3dWrap"); if (wrap3 && !big) wrap3.title = fwNavT("profTip") + (this.iconLog.some(function(q) { return q.beyond; }) ? fwBoxTx("tip") : "");
   var nL = 0, farLab = [], farLog = [];
   if (sc.objects && sc.objects.length) {
      var maxL = big ? FW_NAV_DET.BIG_LAB : FW_NAV_DET.STRIP_LAB, ic = 3 * d + 2 * d; g.font = fO; var aO = Math.round(parseFloat(fO.split(" ")[1]) * 0.72);
      for (i = 0; i < sc.objects.length && nL < maxL; ++i) {
         var o = sc.objects[i]; if (!o.pos || (!big && (o.type === "exoplanet" || o.type === "star"))) continue;
         var kO = fwBoxMapK(sc, o), qo = mp.pt(kO < 1 ? fwBoxMapPos(sc, o) : o.pos, w, h), nm = fwNavObjName(sc, o); if (!qo || !nm) continue;
         if (kO < 1) nm += big ? "  »  " + fwBoxFarTxt(fvLen(o.pos)) : " »";
         var ow = g.measureText(nm).width, cand = [[qo[0] + ic, qo[1] + aO / 2 - 1], [qo[0] - ic - ow, qo[1] + aO / 2 - 1], [qo[0] - ow / 2, qo[1] - ic - 1], [qo[0] - ow / 2, qo[1] + ic + aO]];
         // (16-nov, P31a) a la derecha del icono lejano va el chevron «»» (fwNavFarMark, hasta 6,8 d): el rotulo empieza pasado el chevron, no encima (antes en 5 d)
         if (kO < 1 && FW_BOX.LABEL_DODGE) cand[0][0] += 2.6 * d;
         for (j = 0; j < cand.length; ++j) {
            var cx0 = Math.round(cand[j][0]), cy0 = Math.round(cand[j][1]), RR = [cx0 - 1, cy0 - aO - 1, cx0 + ow + 1, cy0 + 2 * d];
            if (!fwNavFree(occ, RR, [1, 1, w - 1, h - 1])) continue;
            // (16-nov, P31a) el rotulo de lo de mas alla de la boca se pinta con la nave (paintFarLabels3), que puede taparlo; aqui solo se le guarda el sitio
            if (kO < 1 && FW_BOX.LABEL_DODGE) { farLab.push({ nm: nm, cand: cand, j0: j, ri: occ.length, ow: ow, aO: aO, fo: fO, main: !!o.main, qo: qo, ic: ic }); occ.push(RR); ++nL; break; }
            if (kO < 1) farLog.push({ nm: nm, rect: RR, j: j, dodged: false });
            g.fillStyle = "rgba(0,0,0,.8)"; g.fillText(nm, cx0 + d, cy0 + d); g.fillStyle = o.main ? "#F0B8C8" : "#F3D27E"; g.fillText(nm, cx0, cy0);
            occ.push(RR); ++nL; break;
         }
      }
   }
   this.nLabels = nL;
   this.farLab3 = farLab; this.farLog = farLog; this.occ3 = occ;
   this.stat3 = cv;
};
// (16-nov, P31a) los rotulos de lo de mas alla de la boca («M 82 »»), pintados con la nave: el primero de los sitios que no choca con lo fijo ni con lo que tapa la nave (obs:
// flecha, cuna del cono, raya de la mirada). Primero los cuatro de siempre (derecha pasado el chevron, izquierda, encima, debajo del icono); si la nave esta encima del icono,
// los mismos alejados 1,6 · 3,2 · 4,8 tamanos de flecha (obs.S). Si ninguno, el de lo fijo. farLog = lo pintado, para medir el solape.
FWNav.prototype.paintFarLabels3 = function(g, obs) {
   var L = this.farLab3, occ = this.occ3, d = this.dpr || 1, i, j, m, n, log = [];
   if (!L || !L.length) { this.farLog = log; return; }
   for (i = 0; i < L.length; ++i) {
      var f = L[i], cand = f.cand.slice(), pick = f.j0, q = f.qo, S = obs && obs.S ? obs.S : 8 * d;
      for (m = 1; m <= 3; ++m) {
         var e = 1.6 * m * S;
         cand.push([f.cand[0][0] + e, f.cand[0][1]], [q[0] - f.ic - f.ow - e, f.cand[0][1]], [q[0] - f.ow / 2, q[1] - f.ic - 1 - 0.8 * e], [q[0] - f.ow / 2, q[1] + f.ic + f.aO + 0.8 * e]);
      }
      for (j = 0; j < cand.length; ++j) {
         var cx = Math.round(cand[j][0]), cy = Math.round(cand[j][1]), RR = [cx - 1, cy - f.aO - 1, cx + f.ow + 1, cy + 2 * d], free = RR[0] >= 1 && RR[1] >= 1 && RR[2] <= this.c3.width - 1 && RR[3] <= this.c3.height - 1;
         for (n = 0; free && n < occ.length; ++n) { if (n === f.ri) continue; var o = occ[n]; if (RR[0] < o[2] && RR[2] > o[0] && RR[1] < o[3] && RR[3] > o[1]) free = false; }
         if (!free) continue;
         if (fwNavShipHit(RR, obs)) continue;
         pick = j; break;
      }
      var px = Math.round(cand[pick][0]), py = Math.round(cand[pick][1]);
      g.font = f.fo; g.textAlign = "left"; g.fillStyle = "rgba(0,0,0,.8)"; g.fillText(f.nm, px + d, py + d); g.fillStyle = f.main ? "#F0B8C8" : "#F3D27E"; g.fillText(f.nm, px, py);
      log.push({ nm: f.nm, rect: [px - 1, py - f.aO - 1, px + f.ow + 1, py + 2 * d], j: pick, dodged: pick !== f.j0 });
   }
   this.farLog = log;
};
// un fotograma de la franja (solo si cambio algo y como mucho a FW_NAV.HZ)
// (N2, punto 1 de Nino) la ESTELA: cada ~0,1 s de reloj de escena, si la nave se ha movido, un punto (posicion del mundo); caduca a 10 s o 48 puntos
FWNav.prototype.pushTrail = function(P) {
   var tr = this.trail || (this.trail = []), pos = P.cam.pos, t = P.t, n = tr.length, N = this.scene.nebula, dRef = N ? N.distLy : 1000;
   if (n && t < tr[n - 1].t) { tr.length = 0; n = 0; }
   if (!n || (t - tr[n - 1].t >= 0.1 && fvLen(fvSub(pos, tr[n - 1].p)) > 0.0002 * dRef)) tr.push({ p: pos.slice(), t: t });
   while (tr.length && (t - tr[0].t > 10 || tr.length > 48)) tr.shift();
};
// el destino de un viaje en curso (posicion del objeto elegido) o null
FWNav.prototype.dest = function(P) {
   var fl = P.flight; if (!fl || !fl.sel || fl.kind === "home" || fl.kind === "look") return null;
   try { return fvSelPos(P, fl.sel); } catch (e) { return null; }
};
// un fotograma de la franja (solo si cambio algo y como mucho a FW_NAV.HZ)
FWNav.prototype.update = function(P, sel, now, force) {
   this.pushTrail(P);
   var fl = P.flight, cam = P.cam, key = (fl ? "f" : "") + this.trail.length + ":" + (this.trail.length ? this.trail[this.trail.length - 1].t.toFixed(1) : "") + "|" + cam.pos.map(function(v) { return v.toPrecision(6); }).join() + "|" + cam.look.map(function(v) { return v.toFixed(4); }).join() + "|" + cam.fov.toFixed(4) + "|" + (sel ? sel.kind + (sel.i === undefined ? "" : sel.i) : "-");
   if (!force && !this.dirty && key === this.key) return false;
   if (!force && now - this.last < 1000 / FW_NAV.HZ) return false;
   this.key = key; this.last = now; this.dirty = false; this.lastP = P; this.lastSel = sel;
   this.paint2(P, sel); this.paint3(P, sel); this.markSel(sel);
   return true;
};

// ---------------------------------------------------------------------------
// (N2, punto 1 de Nino: «no se ve bien por donde vas») la nave, su estela y su destino en TABULA y en PROFUNDITAS — la misma lectura que la
// de PixInsight (src/ui/fv_nav.js): huella con relleno, estela, destino (mira + linea a trazos), objeto elegido, la nave como punta de flecha
// grande hacia donde mira (en casa, un anillo), flecha en el borde cuando sale de la foto, y en PROFUNDITAS la linea Tierra → nave → destino
// con sus distancias y la marca de profundidad en el eje (la escala)
// ---------------------------------------------------------------------------
var FW_NAV_COL = { ship: "#FFF3C4", gold: "#F3D27E", dest: "#FF8A5A", ink: "#2A1F15", casing: "rgba(0,0,0,.75)" };
function fwNavClip(ax, ay, bx, by, r) {         // Liang-Barsky: el segmento recortado a r = [x0, y0, x1, y1]
   var t0 = 0, t1 = 1, dx = bx - ax, dy = by - ay, p = [-dx, dx, -dy, dy], q = [ax - r[0], r[2] - ax, ay - r[1], r[3] - ay];
   for (var i = 0; i < 4; ++i) {
      if (Math.abs(p[i]) < 1e-12) { if (q[i] < 0) return null; continue; }
      var u = q[i] / p[i];
      if (p[i] < 0) { if (u > t1) return null; if (u > t0) t0 = u; } else { if (u < t0) return null; if (u < t1) t1 = u; }
   }
   return [ax + t0 * dx, ay + t0 * dy, ax + t1 * dx, ay + t1 * dy];
}
function fwNavLine(g, ax, ay, bx, by) { g.beginPath(); g.moveTo(ax, ay); g.lineTo(bx, by); g.stroke(); }
function fwNavShipGlyph(g, x, y, ux, uy, S) {    // punta de flecha clara con filo oscuro y halo; (ux, uy) = hacia donde mira
   var nx = -uy, ny = ux, gr = g.createRadialGradient(x, y, 0, x, y, S * 2); gr.addColorStop(0, "rgba(255,243,196,.55)"); gr.addColorStop(1, "rgba(255,243,196,0)");
   g.fillStyle = gr; g.beginPath(); g.arc(x, y, S * 2, 0, 6.2832); g.fill();
   g.beginPath(); g.moveTo(x + ux * S * 1.5, y + uy * S * 1.5); g.lineTo(x - ux * S * 0.9 + nx * S * 0.9, y - uy * S * 0.9 + ny * S * 0.9); g.lineTo(x - ux * S * 0.35, y - uy * S * 0.35); g.lineTo(x - ux * S * 0.9 - nx * S * 0.9, y - uy * S * 0.9 - ny * S * 0.9); g.closePath();
   g.fillStyle = FW_NAV_COL.ship; g.fill(); g.strokeStyle = FW_NAV_COL.ink; g.lineWidth = Math.max(1, S * 0.24); g.stroke();
}
function fwNavRing(g, x, y, S, k) {              // «mira justo hacia el fondo» / «estas aqui»: anillo con punto
   g.lineWidth = Math.max(2.4, 3 * k); g.strokeStyle = FW_NAV_COL.casing; g.beginPath(); g.arc(x, y, S, 0, 6.2832); g.stroke();
   g.lineWidth = Math.max(1.4, 1.6 * k); g.strokeStyle = FW_NAV_COL.ship; g.beginPath(); g.arc(x, y, S, 0, 6.2832); g.stroke();
   g.fillStyle = FW_NAV_COL.ship; g.beginPath(); g.arc(x, y, S * 0.36, 0, 6.2832); g.fill();
}
function fwNavDestGlyph(g, x, y, S) {            // el destino: anillo con cuatro marcas, bermellon claro con filo oscuro
   for (var pass = 0; pass < 2; ++pass) {
      g.strokeStyle = pass === 0 ? FW_NAV_COL.casing : FW_NAV_COL.dest; g.lineWidth = Math.max(1, S * (pass === 0 ? 0.55 : 0.3));
      g.beginPath(); g.arc(x, y, S, 0, 6.2832); g.stroke();
      for (var i = 0; i < 4; ++i) { var a = i * Math.PI / 2; fwNavLine(g, x + Math.cos(a) * S * 0.6, y + Math.sin(a) * S * 0.6, x + Math.cos(a) * S * 1.7, y + Math.sin(a) * S * 1.7); }
   }
}
function fwNavEdgeMark(g, r, px, py, S, col) {   // flecha en el borde del panel r hacia un punto de fuera -> [x, y]
   var cx = (r[0] + r[2]) / 2, cy = (r[1] + r[3]) / 2, dx = px - cx, dy = py - cy, L = Math.sqrt(dx * dx + dy * dy) || 1;
   var hw = (r[2] - r[0]) / 2 - S * 1.5, hh = (r[3] - r[1]) / 2 - S * 1.5, t = Math.min(hw / Math.max(1e-6, Math.abs(dx)), hh / Math.max(1e-6, Math.abs(dy)));
   var x = cx + dx * t, y = cy + dy * t, ux = dx / L, uy = dy / L, nx = -uy, ny = ux;
   g.beginPath(); g.moveTo(x + ux * S * 1.5, y + uy * S * 1.5); g.lineTo(x - ux * S * 0.7 + nx * S * 1.1, y - uy * S * 0.7 + ny * S * 1.1); g.lineTo(x - ux * S * 0.7 - nx * S * 1.1, y - uy * S * 0.7 - ny * S * 1.1); g.closePath();
   g.fillStyle = col; g.fill(); g.strokeStyle = FW_NAV_COL.ink; g.lineWidth = Math.max(1, S * 0.24); g.stroke();
   return [x, y];
}
FWNav.prototype.paint2 = function(P, sel) {
   // (pasada M) kMax: el mapa en grande (fw_route.js) reutiliza este dibujo; sin tope, a 1900 px los trazos saldrian 11 veces mas gruesos
   var c = this.c2, g = this.g2, w = c.width, h = c.height, k = Math.min(this.kMax || 1e9, Math.max(this.dpr, w / 165)), im = this.photo, sc = this.scene, f = sc.field, n, i;
   g.clearRect(0, 0, w, h);
   var a = f.width / f.height, rw = Math.min(w - 4 * this.dpr, (h - 4 * this.dpr) * a), rh = rw / a, R = [(w - rw) / 2, (h - rh) / 2, rw, rh]; this.rect2 = R;
   if (!this.thumb && im) { var t = document.createElement("canvas"); t.width = Math.round(rw); t.height = Math.round(rh); var tg = t.getContext("2d"); tg.imageSmoothingQuality = "high"; tg.drawImage(im, 0, 0, t.width, t.height); this.thumb = t; }
   if (this.thumb) g.drawImage(this.thumb, R[0], R[1], R[2], R[3]);
   g.strokeStyle = "rgba(201,154,58,.7)"; g.lineWidth = 1 * this.dpr; g.strokeRect(R[0] - 0.5, R[1] - 0.5, R[2] + 1, R[3] + 1);
   var F = fwNavFov(sc, P), panel = [R[0], R[1], R[0] + R[2], R[1] + R[3]], pos = P.cam.pos, home = fvLen(pos) < 1e-6, S = Math.max(8 * this.dpr, 9 * k);
   this.fov = F;
   function X(u) { return R[0] + u[0] * R[2]; } function Y(u) { return R[1] + u[1] * R[3]; }
   function inside(uv) { return !!uv && uv[0] >= 0 && uv[0] <= 1 && uv[1] >= 0 && uv[1] <= 1; }
   g.save(); g.beginPath(); g.rect(R[0] - 3 * k, R[1] - 3 * k, R[2] + 6 * k, R[3] + 6 * k); g.clip();
   // 1. la huella de lo que ve la camara. (D, rev. 3) si cubre casi toda la foto (≥ 97 %, o ≥ 85 % con un contorno varias veces mayor que
   // la foto) el contorno caeria fuera y solo quedaria una raya en un borde: entonces no hay contorno y el marco de la miniatura se enciende
   F.cover = F.away ? 0 : fwNavCover(F.poly); F.big = F.away ? 0 : fwNavBoxArea(F.poly);
   F.drawn = !F.away && F.cover < 0.97 && F.big < 3;
   if (!F.away && !F.drawn && F.cover >= 0.85) { g.strokeStyle = FW_NAV_COL.casing; g.lineWidth = 3.6 * k; g.strokeRect(R[0] + 1.5 * k, R[1] + 1.5 * k, R[2] - 3 * k, R[3] - 3 * k); g.strokeStyle = "#F3D27E"; g.lineWidth = 2 * k; g.strokeRect(R[0] + 1.5 * k, R[1] + 1.5 * k, R[2] - 3 * k, R[3] - 3 * k); }
   if (F.drawn) {
      g.beginPath(); g.moveTo(X(F.poly[0]), Y(F.poly[0])); for (i = 1; i < F.poly.length; ++i) g.lineTo(X(F.poly[i]), Y(F.poly[i])); g.closePath();
      g.fillStyle = "rgba(243,210,126,.17)"; g.fill();
      g.fillStyle = "rgba(0,0,0,.30)"; g.beginPath(); g.rect(R[0], R[1], R[2], R[3]); g.moveTo(X(F.poly[0]), Y(F.poly[0])); for (i = F.poly.length - 1; i >= 0; --i) g.lineTo(X(F.poly[i]), Y(F.poly[i])); g.closePath(); g.fill("evenodd");
      g.beginPath(); g.moveTo(X(F.poly[0]), Y(F.poly[0])); for (i = 1; i < F.poly.length; ++i) g.lineTo(X(F.poly[i]), Y(F.poly[i])); g.closePath();
      g.strokeStyle = FW_NAV_COL.casing; g.lineWidth = 3 * k; g.stroke(); g.strokeStyle = FW_NAV_COL.gold; g.lineWidth = 1.6 * k; g.stroke();
      if (F.look) { var lx = X(F.look), ly = Y(F.look), cc = 3.2 * k; g.lineWidth = 1.2 * k; fwNavLine(g, lx - cc, ly, lx + cc, ly); fwNavLine(g, lx, ly - cc, lx, ly + cc); }
   }
   // 2. la estela (recortada al panel, mas tenue cuanto mas vieja)
   var tr = this.trail || [], sUV = F.ship, dest = this.dest(P), dUV = dest ? fwNavPhotoUV(sc, dest) : null;
   if (tr.length > 1) {
      var tp = []; for (n = 0; n < tr.length; ++n) { var tu = fwNavPhotoUV(sc, tr[n].p); tp.push(tu ? [X(tu), Y(tu)] : null); }
      if (sUV) tp.push([X(sUV), Y(sUV)]);
      g.lineCap = "round"; g.lineWidth = Math.max(1.4, 1.7 * k);
      for (n = 1; n < tp.length; ++n) {
         if (!tp[n - 1] || !tp[n]) continue;
         var cs = fwNavClip(tp[n - 1][0], tp[n - 1][1], tp[n][0], tp[n][1], panel); if (!cs) continue;
         g.strokeStyle = "rgba(255,243,196," + (0.25 + 0.75 * n / (tp.length - 1)).toFixed(2) + ")"; fwNavLine(g, cs[0], cs[1], cs[2], cs[3]);
      }
   }
   // 3. el objeto elegido (anillo claro)
   var su = null; if (sel) { var sp = null; try { sp = (sel.kind === "nebula") ? null : fvSelPos(P, sel); } catch (eS) { sp = null; } su = sp ? fwNavPhotoUV(sc, sp) : null; }
   if (inside(su)) { g.lineWidth = 2.4 * k; g.strokeStyle = FW_NAV_COL.casing; g.beginPath(); g.arc(X(su), Y(su), 4.2 * k + 1, 0, 6.2832); g.stroke(); g.lineWidth = 1.2 * k; g.strokeStyle = "#FFE9A8"; g.beginPath(); g.arc(X(su), Y(su), 4.2 * k + 1, 0, 6.2832); g.stroke(); }
   // 4. el destino del viaje: linea a trazos desde la nave y su mira; fuera de la foto, una flecha bermellon en el borde
   if (dUV) {
      if (sUV) { var cd = fwNavClip(X(sUV), Y(sUV), X(dUV), Y(dUV), panel); if (cd) { g.strokeStyle = "rgba(255,138,90,.85)"; g.lineWidth = 1.3 * k; g.setLineDash([3 * k, 2.2 * k]); fwNavLine(g, cd[0], cd[1], cd[2], cd[3]); g.setLineDash([]); } }
      if (!inside(dUV)) fwNavEdgeMark(g, panel, X(dUV), Y(dUV), S * 0.75, FW_NAV_COL.dest);
   }
   // 5. la nave
   var out = false;
   if (home) { fwNavRing(g, F.look ? X(F.look) : R[0] + R[2] / 2, F.look ? Y(F.look) : R[1] + R[3] / 2, S * 1.1, k); }
   else if (inside(sUV)) {
      var sx = X(sUV), sy = Y(sUV), ux = 0, uy = 0, ul = 0;
      if (F.look) { ux = X(F.look) - sx; uy = Y(F.look) - sy; ul = Math.sqrt(ux * ux + uy * uy); }
      if (ul > 2 * this.dpr) fwNavShipGlyph(g, sx, sy, ux / ul, uy / ul, S);
      else fwNavRing(g, sx, sy, S * 0.9, k);
   } else {
      out = true;
      var ex, ey;
      if (sUV) { ex = X(sUV); ey = Y(sUV); } else { var ll = Math.sqrt(pos[0] * pos[0] + pos[1] * pos[1]) || 1; ex = R[0] + R[2] / 2 + pos[0] / ll * R[2] * 4; ey = R[1] + R[3] / 2 + pos[1] / ll * R[3] * 4; }
      var em = fwNavEdgeMark(g, panel, ex, ey, S * 1.15, FW_NAV_COL.ship), gr = g.createRadialGradient(em[0], em[1], 0, em[0], em[1], S * 2.2); gr.addColorStop(0, "rgba(255,243,196,.4)"); gr.addColorStop(1, "rgba(255,243,196,0)");
      g.fillStyle = gr; g.beginPath(); g.arc(em[0], em[1], S * 2.2, 0, 6.2832); g.fill();
   }
   // 5b. la mira del destino ENCIMA de la nave: en un vuelo recto nave y destino caen en el mismo punto de la foto (se ve desde la Tierra)
   if (dUV && inside(dUV)) fwNavDestGlyph(g, X(dUV), Y(dUV), Math.max(6 * this.dpr, 6.6 * k));
   g.restore();
   // 6. el aviso: nave fuera de la foto, o la camara no mira hacia ella
   if (out || F.away) {
      var txt = fwNavT(out ? "out" : "away"), by = out ? R[1] + 2 * k : R[1] + R[3] / 2 - 7 * k;
      g.font = "italic " + Math.round(6.8 * k) + "px " + getComputedStyle(document.body).fontFamily; g.textAlign = "center";
      g.fillStyle = "rgba(17,13,9,.82)"; g.fillRect(R[0] + 2, by, R[2] - 4, 11 * k); g.fillStyle = out ? FW_NAV_COL.ship : "#E5B53F"; g.fillText(txt, w / 2, by + 8.2 * k);
   }
};
FWNav.prototype.paint3 = function(P, sel) {
   var c = this.c3, g = this.g3, w = c.width, h = c.height, k = Math.min(this.kMax || 1e9, Math.max(this.dpr, w / 184)), mp = this.map, sc = this.scene, i, n;
   if (!this.stat3) this.buildStat3();
   g.clearRect(0, 0, w, h); g.drawImage(this.stat3, 0, 0);
   // (nD3) los iconos de los objetos van en lo fijo; aqui solo el elegido, claro, encima
   if (sel && sel.kind === "object" && sc.objects && sel.i < Math.min(sc.objects.length, FW_NAV.LIST_MAX) && sc.objects[sel.i].pos && !sc.objects[sel.i].main) { var qo = mp.pt(fwBoxMapPos(sc, sc.objects[sel.i]), w, h); g.strokeStyle = "#FFE9A8"; g.lineWidth = 1 * this.dpr; g.beginPath(); g.arc(qo[0], qo[1], 3 * this.dpr, 0, 6.2832); g.stroke(); }
   if (sel && sel.kind === "star") { var qs = mp.pt(fvStarPos(sc, sel.i), w, h); g.strokeStyle = "#F3D27E"; g.lineWidth = 1.1 * this.dpr; g.beginPath(); g.arc(qs[0], qs[1], 4 * this.dpr, 0, 6.2832); g.stroke(); }
   // la nave: punta de flecha grande hacia donde mira; la linea Tierra → nave → destino; la estela; su profundidad en el eje (la escala)
   var pos = P.cam.pos, E = mp.screen([0, 0, 0], w, h), q0 = mp.pt(pos, w, h) || E, d0 = fvLen(pos), step = Math.max(0.5, 0.25 * d0, 0.08 * mp.dMax);
   var dest = this.dest(P), qd = dest ? mp.pt(dest, w, h) : null, S = Math.max(7.5 * this.dpr, 8.2 * k);
   var q1 = mp.pt(fvAdd(pos, fvMul(fvNorm(P.cam.look), step)), w, h) || [q0[0] + 10, q0[1]];
   var dx = q1[0] - q0[0], dy = q1[1] - q0[1], dl = Math.sqrt(dx * dx + dy * dy) || 1, ux = dx / dl, uy = dy / dl;
   g.lineCap = "round";
   if (d0 > 1e-3) {
      g.strokeStyle = "rgba(229,181,63,.38)"; g.lineWidth = 1.1 * k; fwNavLine(g, E[0], E[1], q0[0], q0[1]);
      var ax = mp.screen([mp.depth(d0), 0, 0], w, h);
      g.strokeStyle = FW_NAV_COL.gold; g.lineWidth = 1.2 * k; fwNavLine(g, ax[0], ax[1] - 4 * k, ax[0], ax[1] + 4 * k);
      g.fillStyle = FW_NAV_COL.gold; g.beginPath(); g.moveTo(ax[0], ax[1] - 1); g.lineTo(ax[0] - 3 * k, ax[1] - 6 * k); g.lineTo(ax[0] + 3 * k, ax[1] - 6 * k); g.closePath(); g.fill();
   }
   // (nD3) el cono de vision de la nave, nitido: una cuña de 1 px hacia donde mira (su piramide real, 40°, llenaba el panel: ver fv_nav.js)
   var wa = FW_NAV_DET.CONE_DEG * FV_DEG, wl = S * FW_NAV_DET.CONE_L, cwa = Math.cos(wa), swa = Math.sin(wa);
   var Wd = [[q0[0], q0[1]], [q0[0] + (ux * cwa - uy * swa) * wl, q0[1] + (uy * cwa + ux * swa) * wl], [q0[0] + (ux * cwa + uy * swa) * wl, q0[1] + (uy * cwa - ux * swa) * wl]];
   // (16-nov, P31a) lo que tapa la nave: la caja de la flecha (con el filo), la cuna del cono de vision y la raya de la mirada. Con LABEL_DODGE los rotulos de lo lejano se pintan
   // ya esquivandolo (debajo de la nave, como siempre); shipObs3 queda para medir el solape (tests/web/fv_P31_cdp.js)
   var shAx = [q0[0] + ux * S * 1.5, q0[0] - ux * S * 0.9 - uy * S * 0.9, q0[0] - ux * S * 0.9 + uy * S * 0.9], shAy = [q0[1] + uy * S * 1.5, q0[1] - uy * S * 0.9 + ux * S * 0.9, q0[1] - uy * S * 0.9 - ux * S * 0.9], mg = Math.max(1, S * 0.12);
   this.shipObs3 = { arrow: [Math.min(shAx[0], shAx[1], shAx[2]) - mg, Math.min(shAy[0], shAy[1], shAy[2]) - mg, Math.max(shAx[0], shAx[1], shAx[2]) + mg, Math.max(shAy[0], shAy[1], shAy[2]) + mg], tri: Wd, seg: [q0[0], q0[1], q0[0] + ux * S * 3.4, q0[1] + uy * S * 3.4], S: S };
   this.shipR3 = this.shipObs3.arrow;
   if (FW_BOX.LABEL_DODGE) this.paintFarLabels3(g, this.shipObs3);
   g.beginPath(); g.moveTo(Wd[0][0], Wd[0][1]); g.lineTo(Wd[1][0], Wd[1][1]); g.lineTo(Wd[2][0], Wd[2][1]); g.closePath();
   g.fillStyle = "rgba(243,210,126,.17)"; g.fill(); g.strokeStyle = "rgba(243,210,126,.66)"; g.lineWidth = this.dpr || 1; g.stroke(); this.lastCone = Wd;
   var tr = this.trail || [];
   if (tr.length > 1) {
      var pts = []; for (n = 0; n < tr.length; ++n) { var qt = mp.pt(tr[n].p, w, h); if (qt) pts.push(qt); }
      pts.push(q0); g.lineWidth = Math.max(1.6, 2.2 * k);
      for (n = 1; n < pts.length; ++n) { g.strokeStyle = "rgba(255,243,196," + (0.22 + 0.78 * n / (pts.length - 1)).toFixed(2) + ")"; fwNavLine(g, pts[n - 1][0], pts[n - 1][1], pts[n][0], pts[n][1]); }
   }
   if (qd) { g.strokeStyle = "rgba(255,138,90,.85)"; g.lineWidth = 1.2 * k; g.setLineDash([3 * k, 2.4 * k]); fwNavLine(g, q0[0], q0[1], qd[0], qd[1]); g.setLineDash([]); }
   g.strokeStyle = FW_NAV_COL.gold; g.lineWidth = 1.2 * k; fwNavLine(g, q0[0], q0[1], q0[0] + ux * S * 3.4, q0[1] + uy * S * 3.4);
   fwNavShipGlyph(g, q0[0], q0[1], ux, uy, S);
   if (qd) fwNavDestGlyph(g, qd[0], qd[1], Math.max(5 * this.dpr, 5.6 * k));        // encima de la nave: cerca del destino se taparia
   // las distancias (arriba a la izquierda)
   var rows = [], yy = 3 * k; g.font = "italic " + Math.round(Math.max(8 * (this.dpr || 1), 7.6 * k)) + "px " + (this.ff || (this.ff = getComputedStyle(document.body).fontFamily)); g.textAlign = "left";   // (nD3) la familia, cacheada: getComputedStyle en cada fotograma costaba
   if (d0 > 0.01) rows.push([fwNavT("ship") + " " + ((typeof FV_B5B !== "undefined" && FV_B5B.DIST && typeof fwFmtLy === "function") ? fwFmtLy(d0) + " " + fwNavT("ly") : fwNavDist(d0, "measured")), FW_NAV_COL.gold]);   // (Blender 5b · R5-8.6) la misma cifra que DISTANTIA
   if (dest) rows.push([fwNavT("dest") + " " + fwNavDist(fvLen(fvSub(dest, pos)), "measured"), "#FF9A7A"]);
   if (mp.view) yy = h - 3 * k - rows.length * 10.4 * k - 0.12 * h;          // (nD3) en el grande, abajo a la izquierda (arriba la tapaba el titulo)
   yy = Math.round(yy);
   for (n = 0; n < rows.length; ++n) { g.fillStyle = "rgba(17,13,9,.78)"; g.fillRect(2 * k, yy, g.measureText(rows[n][0]).width + 4 * k, 9.4 * k); g.fillStyle = rows[n][1]; g.fillText(rows[n][0], 4 * k, yy + 7.4 * k); yy += 10.4 * k; }
};

// los iconos de tipo (grabados, como los botones): pn · galaxy · cluster · nebula · quasar · star · exoplanet · other
function fwNavIconSvg(host, type) {
   var s = fwEl("svg", { viewBox: "-10 -10 20 20", width: "100%", height: "100%" }), c = "#E5B53F", st = { fill: "none", stroke: c, "stroke-width": 1.3, "stroke-linecap": "round" };
   function el(t, a) { var o = {}; for (var k in st) o[k] = st[k]; for (k in a) o[k] = a[k]; return fwEl(t, o, s); }
   if (typeof fwE1cIconSvg === "function" && fwE1cIconSvg(type, el, c)) { host.appendChild(s); return; }      // (19-nov, I1) los sobres de AENIGMATA
   if (type === "pn") { el("circle", { r: 7 }); el("circle", { r: 2, fill: c }); }
   else if (type === "galaxy") { el("ellipse", { rx: 8, ry: 3.4 }); el("ellipse", { rx: 2.6, ry: 1.3, fill: c }); }
   else if (type === "cluster") { [[0, -5], [-5, 1], [4.5, 0.5], [-1.5, 5], [3, 5], [0.5, -0.5]].forEach(function(p) { el("circle", { cx: p[0], cy: p[1], r: 1.5, fill: c, stroke: "none" }); }); }
   else if (type === "nebula") { el("ellipse", { cx: -3, cy: 1.5, rx: 6, ry: 3.8 }); el("ellipse", { cx: 3, cy: -2, rx: 5.5, ry: 3.4 }); }
   else if (type === "quasar") { el("circle", { r: 2.4, fill: c }); el("line", { x1: -8, y1: 4, x2: 8, y2: -4 }); }
   else if (type === "exoplanet") { el("circle", { r: 4.5 }); el("ellipse", { rx: 8.5, ry: 2.6, transform: "rotate(-18)" }); el("circle", { cx: 7, cy: -3, r: 1.4, fill: c }); }
   else if (type === "star") { for (var i = 0; i < 4; ++i) { var a = i * Math.PI / 4, L = i % 2 ? 4.5 : 8; el("line", { x1: -Math.cos(a) * L, y1: -Math.sin(a) * L, x2: Math.cos(a) * L, y2: Math.sin(a) * L }); } el("circle", { r: 2.2, fill: c }); }
   else el("path", { d: "M0 -8 L8 0 L0 8 L-8 0 Z" });
   host.appendChild(s);
}
