// ============================================================================
// FieldVoyager/web/fw_gl.js — EL PINTOR WebGL2 del visor del navegador (4-nov-2026, F3; volumen v2 en F3b)
// ----------------------------------------------------------------------------
// three.js r159 (lib/three.min.js, MIT) solo como envoltorio de WebGL2: render targets, texturas, RawShaderMaterial. La camara de
// three.js NO se usa: la proyeccion es la de src/engine/fv_pilot.js (campo de vision HORIZONTAL, ejes +X derecha, +Y abajo, +Z
// adelante), escrita en los shaders, para que un pixel salga en el mismo sitio que en el pintor de PixInsight.
//
// RENDER RELATIVO A LA CAMARA (I9; referentes-2-arquitectura §B): las posiciones viven en doble precision en JS (Float64Array
// del motor) y en cada fotograma se sube SOLO p − camara en float32 (17 000 estrellas: 0,2 MB). Asi se puede orbitar una estrella
// a 0,05 años luz estando a 6 500 de la Tierra (en float32 absoluto la resta daria 0). El volumen usa la camara absoluta en
// float32: su lamina mas fina mide 0,15 años luz y el paso de float32 a 6 500 años luz es 0,0005 (300 veces menor): no se nota.
// PROFUNDIDAD EN DOS PASADAS: no hay objetos opacos (todo es luz aditiva o emision-absorcion), asi que no hace falta z-buffer;
// las dos pasadas son de ORDEN: estrellas del lado lejano del plano de la nebulosa → volumen (emision + absorcion de lo de detras)
// → estrellas del lado cercano. (Con el exoplaneta de F2 la pasada cercana llevara z-buffer.)
// Cadena: estrellas lejanas (HDR, media coma flotante) → volumen v2 a media resolucion (cuerpo + tres laminas + polvo, relieve de
// fw_relief.js; 64–80 pasos gruesos con desfase por pixel y paso adaptativo junto a las laminas) → composicion → estrellas cercanas → bloom (cadena de reducciones) → final: hombro de tonos que deja la foto IGUAL por
// debajo de 0,8 (la foto ya viene estirada: un ACES le cambiaria el color), destello, aberracion cromatica (solo ESPECTACULAR),
// viñeta y grano (con semilla = numero de fotograma: el video sale igual cada vez).
// ES5 (salvo los shaders, GLSL ES 3.0).
// ============================================================================

// (19-nov-2026, N2c) fundir el borde de la foto en el volumen (espejo web de FV_N2C de src/engine/fv_objects.js, que da R0 y SKY): ON = false (o ?n2c=0 en la URL) = lo de antes
var FW_N2C = { ON: true };
(function() { try { var q = /[?&]n2c=([01])/.exec(location.search); if (q) FW_N2C.ON = q[1] === "1"; } catch (e) {} })();
var FW_GL = { NEAR: 1e-7,
   // (K10 H-1) bajada adaptativa de la resolucion del volumen: si el p95 del intervalo entre fotogramas de los ultimos ADAPT.WIN pasa de
   // max(LIMIT_MS (16 ms de Nino + un vsync de 60 Hz de tolerancia: a 120 Hz un fotograma perdido da 16,7 y eso son 60 fps, no tirones), 1,3 × el periodo del monitor, con el periodo ≤ 16,7 ms: un monitor de 60 Hz da 21,7) se baja de volScale (0,5 por defecto desde el 4-nov, decision de Nino; antes 0,75) a LOW (0,35); se vuelve a subir solo si el p95 de 4·WIN fotogramas
   // queda por debajo de UP × el limite; tras DROPS_LOCK bajadas ya no sube mas (evita el vaiven)
   ADAPT: { LOW: 0.35, LIMIT_MS: 17.5, PERIOD_K: 1.3, PERIOD_MAX: 16.7, WIN: 60, EVERY: 30, BAD_N: 3, SETTLE: 120, UP: 0.6, DROPS_LOCK: 2 },
   // (F3c) las reglas del cono de PixInsight (src/ui/fv_painter.js, FV_PAINT): mismas cifras para que los dos pintores vean lo mismo
   ASSUMED_DM: 2.0, ASSUMED_AWAY: 0.02, CONE_GC: 11.5, CONE_DM: 8, CONE_SOFT: 1.5, CONE_TUBE: 1, WIDE_MAG: 9.5, RING_MAG: 12.5,
   CONE_BY_VIEW: true, TUBE_SOFT: 0.5,   // (B2) FV_PAINT.CONE_BY_VIEW / TUBE_SOFT: las reglas del cono segun lo que se ve
   // (B2, Nino: «las estelas son muy brillantes, el destello poco natural») ESTELAS V2: finas (sigma ≤ STREAK_W px), tenues (STREAK_GAIN), cola
   // al STREAK_TAIL, iluminadas por el destello cerca del punto de fuga (STREAK_LIT); STREAK_V2 false = ROJO. DESTELLO V2: pulso suave sin
   // espigas (FLASH_SPIKE_K 0; las de §15 = 1), nucleo FLASH_R2 del alto, halo FLASH_HALO, brillo FLASH_GAIN2, color FLASH_COL2 (azulado-blanco)
   STREAK_V2: true, STREAK_GAIN: 0.38, STREAK_TAIL: 0.12, STREAK_W: 0.8, STREAK_LIT: 0.8,
   FLASH_V2: true, FLASH_SPIKE_K: 0, FLASH_R2: 0.035, FLASH_HALO: 0.35, FLASH_GAIN2: 1.25, FLASH_COL2: [0.78, 0.86, 1.0],
   // (F3c) Via Lactea de fondo (FV_PAINT.MW_*): plena al alejarse MW_AWAY × la distancia de la nebulosa; brillo del p99,5 visto desde el Sol
   MW_AWAY: 0.03, MW_PEAK: 0.24,
   // (F3c) el volumen se funde hacia los bordes de la foto en cuanto la camara deja casa (OFF_LY × distancia) o el campo se abre (×1,03–1,25)
   OFF_LY: 0.004,
   // (D, rev. 3) el punto de fuga negro del salto: radio sin estrellas y radio de estrellas plenas, en fraccion del alto de la pantalla
   // (barrido del 4-nov en el estado de la bola: 0,16 lineal dejaba el disco 0,08·alto con el 66 % de pixeles > 150, frente al 100 % sin
   // agujero; 0,45 al cuadrado, el 0,1 %)
   HOLE_R0: 0.02, HOLE_R1: 0.45, HOLE_POW: 2,
   // (D, rev. 3) LA NIEBLA DE DENTRO (la misma idea y cifras que FV_PAINT.FOG_* de PixInsight, src/ui/fv_painter.js): con la camara dentro
   // de la losa de la nebulosa (o a menos de un grosor) se suma en Screen el trozo de foto sin estrellas de alrededor (FOG_SPAN del ancho),
   // sin el fondo de cielo (p25), con contraste FOG_GAMMA, mezcla de bruma ancha (48 px) y detalle (FOG_DET px) FOG_MIX. Producto ESTETICO.
   FOG_K: 0.3, FOG_SPAN: 0.3, FOG_GAMMA: 1.7, FOG_DET: 640, FOG_MIX: 0.65, FOG_BASE: 48,
   // (D, rev. 3) «apagandose despacio» (coordinador): al llegar de un salto la niebla empieza FOG_GLOW veces mas fuerte y baja a FOG_K con
   // constante FOG_TAU s (reloj del piloto); asi el anillo de gas que se sale del encuadre al cerrarse el campo no deja la pantalla en negro de golpe
   FOG_GLOW: 0.8, FOG_TAU: 2.5,
   // (F3c) exposicion: media de luminancia a la que se baja la escena cuando brilla mas (la de la foto de Collinder 34 en casa es ≈ 0,27)
   EXP_TARGET: 0.34, EXP_MIN: 0.3,
   // (F3c) contraste local del volumen fuera de casa (estetico; ver FW_SH_COMP_F)
   LOCAL_K: 0.8,
   // (nA2, E1; Nino: «cuando pasa al browser la imagen es de peor calidad») CALIDAD DE LA IMAGEN EN EL NAVEGADOR:
   //   ANISO       filtrado anisotropico (EXT_texture_filter_anisotropic) en las texturas que se muestrean con texture() (las capas): false = 1x (ROJO)
   //   MAX_TEX     false = no se ajusta la foto al MAX_TEXTURE_SIZE de la GPU (ROJO: una foto mayor que el limite no se carga)
   //   REST_FULL   el volumen se calcula a MEDIA resolucion (volScale 0,5: el presupuesto de 16 ms al volar) pero, con la camara quieta
   //               REST_FRAMES fotogramas seguidos (o grabando, que va a reloj fijo), a RESOLUCION COMPLETA: sin ello, aun con la foto de 5262 px
   //               la nebulosa se veia a 960 x 540 estirada a 1920 x 1080 (medido 4-nov). false = ROJO (siempre media resolucion)
   ANISO: true, MAX_TEX: true, REST_FULL: true, REST_FRAMES: 3,
   // (W6, 5-nov; Nino: «al acelerar desde la imagen 2D aparece un viñeteado oscuro fuerte a los lados; tambien al pulsar viajar») LA CAIDA DEL
   // BORDE DE LA FOTO (volumen y estrellas) SOLO CUANDO ESE BORDE ESTA EN PANTALLA, como el pintor de PixInsight (photoQuad().kE, FV_PAINT.PHOTO_EDGE):
   // antes se encendia entera con solo separarse de casa un 0,4 % del camino (uOffHome) y, como en casa la foto llena el ancho, la banda de
   // 2,2·edge = 37 % del ancho caia DENTRO de la pantalla (medido: lados al 60 % de su luz a 1,5 s de pulsar W). Ahora se multiplica por kShow:
   // 0 con los cuatro bordes de la foto fuera de la pantalla, 1 en cuanto uno entra EDGE_SHOW_RAMP del ancho (la rampa de PixInsight); con
   // alguna esquina detras de la camara, 1 (lo de antes: dentro de la losa). EDGE_SHOW false = ROJO
   EDGE_SHOW: true, EDGE_SHOW_RAMP: 0.04,
   // (W5, 5-nov; Nino: «cuando cambio la palanca de cine a warp, la iluminacion de la imagen varia») LA PALANCA ELIGE COMO SE VIAJA, NO LA LUZ:
   // el perfil de WARP (fw_viewer.js, FW_PROFILE.spectacular) subia el bloom 0,16 -> 0,30, la viñeta 0,20 -> 0,26, el halo y el grano con la nave
   // QUIETA. Fuera del salto se usan siempre los de LOOK_REST (los de CINE) y los del perfil entran con el warp del fotograma (fx.warp 0 -> 1).
   // Un 0 del perfil (modo limpio) se respeta. LOOK_FIXED false = ROJO (lo de antes)
   LOOK_FIXED: true, LOOK_REST: { bloomK: 0.16, vig: 0.20, halo: 0.04, grain: 0.010 },
   // (W3, 5-nov; Nino: «la imagen es de baja resolucion, se ve peor que PixInsight») LA FOTO COMO PLANO cerca de casa (ver FW_SH_COMP_F): medido a
   // 1920 x 1080 en casa, nitidez frente a la foto ideal 0,33 quieta y 0,08 al moverse (el volumen a media resolucion estirado), PixInsight 0,18.
   // PHOTO_FADE = FV_PAINT.PHOTO_FADE (el mismo 3 % del camino que PixInsight); PHOTO_SKIP: por encima, el plano solo. PHOTO_PLANE false = ROJO
   // PHOTO_BIAS: sesgo del LOD de los mipmaps (barrido tests/fv_W3_bias.py, 1920 x 1080: 0 -> nitidez 0,33 y temblor 0,27; −0,5 -> 0,59 / 0,35;
   // −1 -> 0,83 / 0,50; la foto por vecino mas proximo, con aliasing, tiembla 0,76). −0,5: casi el doble de nitidez sin acercarse al aliasing
   PHOTO_PLANE: true, PHOTO_FADE: 0.03, PHOTO_SKIP: 0.98, PHOTO_BIAS: -0.5,
   // (9-nov, encargo E · P2; «la foto de casa en la web gana nitidez de golpe al cargar el relieve») MIENTRAS LLEGA EL RELIEVE la nebulosa se pinta con
   // las capas (2048 px) y, al llegar (un Worker, 0,3–0,5 s despues de arrancar), pasaba de golpe al volumen con la foto como plano (la foto entera,
   // 5262 px con mipmaps): un escalon de nitidez en UN fotograma (medido en casa: laplaciano robusto 4,60 -> 4,90, +6,6 %, tests/web/fv_E_cdp.js).
   // RELIEF_FADE_S: segundos del fundido capas -> volumen (las capas bajan con su ganancia, el volumen sube con uNebK). El estado final es el de
   // siempre (solo volumen). 0 = ROJO (el salto de antes, bit a bit)
   RELIEF_FADE_S: 0.6,
   // (W7c, Nino 5-nov) el tunel negro del warp, con las cifras de PixInsight (FVPainter.paintLayers: wFade = 1 − 0,9·suave(warp / 0,6)). Medido en el
   // crucero del warp (tests/out/web_calidad): luz media PixInsight 20,5 frente a la web 84 antes de esto. WARP_NEB_DIM 0 = ROJO
   WARP_NEB_DIM: 0.9, WARP_NEB_W: 0.6,
   // (W7d, Nino 5-nov: «la protagonista al llegar, un punto como en PixInsight») las cifras de FV_PAINT (HERO_MAG, HERO_R0, HERO_MAX). HERO_PI false = ROJO
   HERO_PI: true, HERO_MAG: 3.5, HERO_R0: 14, HERO_MAX: 120,
   // (11-nov, NV-16) LA LLEGADA con el laboratorio: la protagonista crece en el ultimo tramo como en PixInsight (copia de FV_PAINT.HERO_NEAR; la usa
   // fwHeroPi de fw_amb.js; tests/web/fv_nv16_amb_cdp.js comprueba que las dos copias son iguales). ON false = sin crecer (ROJO)
   HERO_NEAR: { ON: true, K: 2.0, FROM: 8, MAX: 150, ON_PHOTO: 0.85 },
   // (11-nov, NV-13) el canto de las capas de FVPainter.paintLayers (FV_PAINT.EDGE_LO / EDGE_HI / EDGE_IN, copiadas): solo para saber si PixInsight
   // pintaria las capas (la foto en pantalla que lee el laboratorio, labLandFrame); el visor no pinta capas de canto
   LAB_EDGE_LO: 0.15, LAB_EDGE_HI: 0.55, LAB_EDGE_IN: 0.35 };
// (11-nov-2026, NV-13) las cifras de FV_PAINT (src/ui/fv_painter.js, 11-nov) con que el pintor de PixInsight decide QUE estrellas pinta: el recuento
// que lee el laboratorio («hay paisaje», labLandFrame) se hace con ellas para que el viaje sea el mismo en los dos sitios. Si cambian alli, aqui.
// DEPTH_BY_FOV "auto" no se copia: con PRINT_ONLY esta apagada en PixInsight
var FW_LAB_PI = { HERO_MAG: 3.5, ASSUMED_DM: 2.0, ASSUMED_AWAY: 0.02, CONE_GC: 11.5, CONE_DM: 8, CONE_SOFT: 1.5, CONE_TUBE: 1, CONE_NEAR: 0.02,
   CONE_NEAR_ON: true, CONE_BY_VIEW: true, TUBE_SOFT: 0.5, PRINT_ONLY: true, PRINT_SOFT: 0.03, STAR_EDGE: true, STAR_EDGE_RAMP: 0.15, PHOTO_EDGE: [0.12, 0.06] };
// (W5) el valor de un parametro de luz del perfil: el de reposo fuera del salto, el del perfil con el warp (0 del perfil = apagado)
function fwLookVal(o, k, fx) {
   var v = o[k];
   if (FW_GL.LOOK_FIXED === false || o.lookFixed === false || !(v > 0) || !FW_GL.LOOK_REST || FW_GL.LOOK_REST[k] === undefined) return v;
   var w = fx ? Math.max(0, Math.min(1, fx.warp || 0)) : 0, r = FW_GL.LOOK_REST[k];
   return r + (v - r) * w;
}

// (nA2, E1) la imagen ajustada al MAX_TEXTURE_SIZE de la GPU: si cabe, la misma; si no, un lienzo reducido a mitades sucesivas (cada mitad
// promedia 2 × 2: sin el aliasing de una sola reduccion grande) y un ultimo paso al tamaño justo. -> imagen | lienzo
function fwFitTex(src, maxSide) {
   var w = src.width, h = src.height;
   if (!(maxSide > 0) || (w <= maxSide && h <= maxSide)) return src;
   var k = Math.min(maxSide / w, maxSide / h), tw = Math.max(1, Math.floor(w * k)), th = Math.max(1, Math.floor(h * k)), cur = src, cw = w, ch = h;
   while (cw > 2 * tw || ch > 2 * th) {
      var nw = Math.max(tw, Math.ceil(cw / 2)), nh = Math.max(th, Math.ceil(ch / 2)), c = document.createElement("canvas"); c.width = nw; c.height = nh;
      var g = c.getContext("2d"); g.imageSmoothingEnabled = true; g.imageSmoothingQuality = "high"; g.drawImage(cur, 0, 0, nw, nh); cur = c; cw = nw; ch = nh;
   }
   var f = document.createElement("canvas"); f.width = tw; f.height = th; var gf = f.getContext("2d"); gf.imageSmoothingEnabled = true; gf.imageSmoothingQuality = "high"; gf.drawImage(cur, 0, 0, tw, th);
   return f;
}
// (W4) la clase de la GPU por el nombre del renderer de WebGL (WEBGL_debug_renderer_info). Apple M* cuenta como integrada (lo es, aunque rapida)
function fwGpuClass(r) {
   r = String(r || "");
   if (/SwiftShader|llvmpipe|softpipe|Software|Basic Render|Microsoft Basic/i.test(r)) return "software";
   if (/NVIDIA|GeForce|RTX|Quadro|Radeon RX|Radeon Pro|Arc\(TM\) A|Intel\(R\) Arc A/i.test(r)) return "discrete";
   if (/Intel|UHD|Iris|Radeon\(TM\) Graphics|Radeon Graphics|Vega \d|Apple|Mali|Adreno/i.test(r)) return "integrated";
   return "unknown";
}
function fwHexToRgb(c) { return [((c >>> 16) & 255) / 255, ((c >>> 8) & 255) / 255, (c & 255) / 255]; }

// (F3c) LAS REGLAS DEL CONO de PixInsight (src/ui/fv_painter.js, F2/F4b), en el shader: fuera de casa (uAway 0 → 1 al alejarse un 2 %
// de la distancia de la nebulosa) (1) las de distancia SUPUESTA se atenuan uDmAss magnitudes; (2) EL TUBO: las que el catalogo solo trae
// en el cono de la foto (aInfo.z = 1: mas debiles que el cielo completo) y quedan lejos de la camara (mas de aInfo.y × su distancia a la
// Tierra) se apagan uConeDm magnitudes; (3) EL CONO: las que se ven mas debiles que uConeGc se apagan tambien. Apagadas por debajo del
// limite, NO se pintan (el suelo de brillo las dejaba como polvo: miles de ellas apiladas en el punto de fuga = la «bola cometa
// melocoton» de F3b). La PROTAGONISTA (uHero: la estrella elegida o a la que se viaja) queda fuera de las reglas, con su color real
// (uHeroCol: cuerpo negro de su Teff, el mismo de la ficha) y un disco que puede crecer mas. Las supuestas no saturan (tamaño acotado).
var FW_SH_STAR_V = [
"precision highp float;",
"in vec2 position; in vec3 aRel; in vec3 aCol; in vec3 aColT; in vec2 aMag; in vec3 aInfo; in vec2 aUv; in vec4 aSpr; in vec2 aSprC;",
// (I2, 19-nov) EL DIAGRAMA HR ANIMADO (web/fw_hr.js, motor engine/fv_hr.js; gemelo de fvHrStar / fvHrLev de PixInsight): aHr = (u, v dentro de los ejes, orden de
// salida, brillo en el diagrama; < 0 = sin distancia de fiar: no va). uHrK = avance de la animacion (0 = sin diagrama: nada de esto actua), uHrA = cuanto se ven
// los ejes, uHrO / uHrS = esquina y tamaño del recuadro en px del destino (y hacia arriba), uHrStag / uHrArc / uHrDim / uHrSig / uHrFloor / uHrRest = FV_HR
"in vec4 aHr; uniform float uHrK, uHrA, uHrStag, uHrArc, uHrDim, uHrSig, uHrFloor, uHrRest; uniform vec2 uHrO, uHrS;",
// (5-nov) STELLAE «como en la foto» (src/engine/fv_photostars.js, fvPsWeights en GLSL): aSpr = recorte en el atlas (x, y, ancho, alto; ancho 0 = sin
// recorte), aSprC = su centro; uPsOn 1 = aspecto FOTO; uPsHome = px de pantalla por px de recorte en casa; uMagLimH / uSatMagH = los limites de casa
"uniform float uPsOn, uPsHome, uPsMagLo, uPsMagHi, uPsTrailK, uPsScaleMin, uPsSigCap, uMagLimH, uSatMagH;",
"uniform vec3 uR, uD, uF, uTrail, uSplitN, uHeroCol; uniform float uTanH, uTanV, uMagLim, uSatMag, uFloor, uSigma0, uPass, uSplitD, uMaxSat;",
"uniform float uAway, uDmAss, uConeGc, uConeDm, uConeSoft, uHeroK; uniform int uHero;",
// (W7d) la protagonista como en PixInsight (FVPainter.heroSpriteCol/paintHero): uHeroPi 1 = disco con limbo + brillo corto, de radio uHeroRpx·0,16
"uniform float uHeroPi, uHeroRpx, uHeroW;",
"uniform float uFadeOn, uFadeLo, uFadeW, uAMin, uEdgeK, uEbx, uEby, uBudK;",
"uniform vec3 uCamW; uniform float uByView, uTanHd, uConeTube, uTubeSoft;",
// (11-nov, NV-13) EL ESPACIO DE VUELO del laboratorio (engine/fv_flightlab.js): se proyecta (S·x, S·y, z) con la base de la nave. uR/uD/uF ya llegan
// multiplicados (x, y × S: FWRenderer.render), asi que la proyeccion no cambia aqui; el brillo sigue con la distancia REAL (length(rel)). uSS = S (1 sin
// laboratorio: todo como antes) para el cono segun lo que se ve (FVPainter.paintStars con SS) y uSideOn/Lo/Hi = FV_LAB.SIDE_FADE (fvLabSideFadeK)
"uniform float uSS, uSideOn, uSideLo, uSideHi;",
"uniform vec2 uRes, uVp; uniform float uRadial, uTrueOn, uHole, uHoleR0, uHoleR1, uHolePow, uDop;",
"out vec2 vP; flat out vec2 vA; flat out vec2 vB; flat out float vI; flat out float vSig; flat out vec3 vCol; flat out float vLen; flat out float vHero; flat out float vHeroPi;",
"flat out vec4 vSprR; flat out vec2 vSprC; flat out float vSprK; flat out float vSprA;",
"float sm(float x) { x = clamp(x, 0.0, 1.0); return x * x * (3.0 - 2.0 * x); }",
// (nP, I2) EL FUNDIDO de fv_look.js (fvLookAlpha): alfa continuo por magnitud; uFadeOn 0 = el corte duro de antes (m > magLim + 0,5)
"float fadeA(float m) { if (uFadeOn < 0.5) return m > uMagLim + 0.5 ? 0.0 : 1.0; return 1.0 - sm((m - uFadeLo) / uFadeW); }",
"void main() {",
"  vec3 rel = aRel;",
"  float side = dot(rel, uSplitN) - uSplitD;",
"  if (uHrK > 0.0) side = -1.0;",      // (I2) con el diagrama HR todas van en la pasada de delante (encima del velo)
"  vec3 c = vec3(dot(rel, uR), dot(rel, uD), dot(rel, uF));",
"  if (uPass * side < 0.0 || c.z <= 1e-9) { gl_Position = vec4(3.0, 3.0, 3.0, 1.0); return; }",
"  float dCam = length(rel), hero = (gl_InstanceID == uHero) ? 1.0 : 0.0;",
"  float m = aMag.x + 5.0 * log(max(dCam, 1e-12) / max(aMag.y, 1e-12)) / log(10.0);",
// (B2) EL CONO SEGUN LO QUE SE VE (FVPainter.paintStars, FV_PAINT.CONE_BY_VIEW): a la profundidad de la estrella, si el corte de la vista
// cabe en el cono del catalogo (radio aInfo.y / uConeTube × z) la regla no se aplica: avanzar por dentro de la foto no apaga sus estrellas
"  float aw = uAway, kS = 1.0;",
"  if (uByView > 0.5 && uAway > 0.001) {",
"    if (uF.z > 0.05) { float sZ = rel.z / uF.z; if (sZ > 0.0) { vec2 q = uSS * uCamW.xy + sZ * uF.xy / uSS; float rhoV = length(q) + sZ * uTanHd / uF.z, rC = uSS * (rel.z + uCamW.z) * aInfo.y / uConeTube; kS = rC > 0.0 ? sm((rhoV / rC - 1.0) / uTubeSoft) : 1.0; } }",
"    aw = uAway * kS;",
"  }",
"  if (hero < 0.5 && aw > 0.001) {",
"    m += aInfo.x * uDmAss * aw;",
"    if (aInfo.z > 0.5) { float nk = dCam / max(aMag.y, 1e-9), cn = aInfo.y; if (nk > cn) m += aw * uConeDm * sm((nk - cn) / cn); }",
"    if (m > uConeGc - uConeSoft) m += aw * uConeDm * sm((m - uConeGc + uConeSoft) / uConeSoft);",
"    if (fadeA(m) < uAMin) { gl_Position = vec4(3.0, 3.0, 3.0, 1.0); return; }",
"  }",
"  float fa = (hero > 0.5 || uFadeOn < 0.5) ? 1.0 : fadeA(m);",
// (nP-2) la foto pequeña al alejarse: presupuesto de luz por area de foto (uBudK, fvStarBudget) y apagado con el borde de la foto
// (uEdgeK: aUv = coordenadas en la foto por eje, 1 = el borde; la misma franja que deja ver el volumen, 2,2·uEdge + ruido)
"  if (hero < 0.5) { fa *= uBudK; if (uEdgeK > 0.0) fa *= 1.0 - uEdgeK * (1.0 - sm((1.0 - aUv.x) / uEbx) * sm((1.0 - aUv.y) / uEby)); }",
// (NV-13) las que se verian aplastadas de lado (distancia real / distancia de vuelo < uSideHi) se apagan hasta uSideLo (fvLabSideFadeK)
"  if (uSideOn > 0.5 && hero < 0.5) { float dF = length(vec3(uSS * rel.xy, rel.z)); fa *= sm((dCam / max(dF, 1e-30) - uSideLo) / max(uSideHi - uSideLo, 1e-6)); }",
// (I2) el avance de ESTA estrella hacia el diagrama (fvHrProgress: espera su turno y viaja con arranque y frenada suaves); la que no va, se atenua
"  float hrT = 0.0, hrOk = step(0.0, aHr.w);",
"  if (uHrK > 0.0) {",
"    if (hrOk > 0.5) { float hq = clamp((uHrK - aHr.z * uHrStag) / (1.0 - uHrStag), 0.0, 1.0); hrT = hq * hq * hq * (hq * (hq * 6.0 - 15.0) + 10.0); }",
"    else if (hero < 0.5) fa *= 1.0 - (1.0 - uHrDim) * uHrA;",
"  }",
"  if (fa < uAMin) { gl_Position = vec4(3.0, 3.0, 3.0, 1.0); return; }",
"  float I, sig, maxS = hero > 0.5 ? uMaxSat + 1.6 : (aInfo.x > 0.5 ? min(uMaxSat, 1.2) : uMaxSat);",
"  if (m >= uSatMag) { float fr = clamp((uMagLim - m) / (uMagLim - uSatMag), 0.0, 1.0); I = uFloor + (1.0 - uFloor) * fr; sig = uSigma0; }",
"  else { float e = 0.3 * (uSatMag - m); I = 1.6; sig = uSigma0 * pow(2.0, min(e, maxS)); }",
// (I2) en el diagrama las brillantes encogen (no tapan a sus vecinas), las muy debiles suben al suelo y las apelotonadas bajan (aHr.w); la que se queda, pequeña
"  if (uHrK > 0.0) {",
"    if (hrOk > 0.5) { sig = mix(sig, min(sig, uSigma0 * uHrSig), hrT); I = mix(I, max(I, uHrFloor), hrT) * mix(1.0, aHr.w, hrT); }",
"    else sig = mix(sig, min(sig, uSigma0 * uHrRest), uHrA);",
"  }",
"  float sprA = 0.0, sprK = 0.0, wGs = 1.0;",
"  if (uPsOn > 0.5 && aSpr.z > 0.0 && hero < 0.5) {",
"    float mH = aMag.x, gS = pow(2.0, clamp(0.3 * (uSatMag - m), 0.0, uPsSigCap)) / pow(2.0, clamp(0.3 * (uSatMagH - mH), 0.0, uPsSigCap));",
"    sprK = uPsHome * max(uPsScaleMin, gS);",
"    float iN = m < uSatMag ? 1.0 : uFloor + (1.0 - uFloor) * clamp((uMagLim - m) / (uMagLim - uSatMag), 0.0, 1.0);",
"    float iH = mH < uSatMagH ? 1.0 : uFloor + (1.0 - uFloor) * clamp((uMagLimH - mH) / (uMagLimH - uSatMagH), 0.0, 1.0);",
"    wGs = max(sm((sprK - uPsMagLo) / (uPsMagHi - uPsMagLo)), uPsTrailK);",
"    sprA = fa * min(1.0, iN / max(iH, 1e-6)) * (1.0 - wGs);",
"  }",
"  if (hrT > 0.0) { sprA *= 1.0 - hrT; wGs = mix(wGs, 1.0, hrT); }",      // (I2) camino del diagrama el recorte de la foto se funde al punto
"  I *= fa * wGs;",
"  vec2 p0 = vec2(c.x / (c.z * uTanH), -c.y / (c.z * uTanV)) * uRes * 0.5;",
// (I2) la trayectoria (fvHrPath): de su sitio en la vista a su punto del diagrama, con una comba que se anula en los extremos. Solo las de la vista (± 80 px)
"  if (hrT > 0.0) {",
"    if (abs(p0.x) > 0.5 * uRes.x + 80.0 || abs(p0.y) > 0.5 * uRes.y + 80.0) { gl_Position = vec4(3.0, 3.0, 3.0, 1.0); return; }",
"    vec2 hd = uHrO + aHr.xy * uHrS - p0; p0 += hd * hrT + vec2(hd.y, -hd.x) * (uHrArc * sin(3.14159265 * hrT));",
"  }",
// (D, rev. 3) EL PUNTO DE FUGA NEGRO (§15, Trek): en el salto las estrellas que caen junto al punto de fuga (todo el campo de la foto, que
// esta delante) se apilaban en una bola crema del 25-30 % de la pantalla (fila 2-3 de nD_warp_tira, coordinador). Con las rayas puestas
// (uHole = cuanto estan puestas) cada estrella se apaga segun su distancia en pantalla al punto de fuga: nada por debajo de uHoleR0 del
// alto, plena desde uHoleR1. Las rayas nacen asi de un centro oscuro. La protagonista (el destino) no se apaga.
"  if (hero < 0.5 && uHole > 0.001) { float hk = mix(1.0, pow(sm((length(p0 - uVp) / uRes.y - uHoleR0) / max(uHoleR1 - uHoleR0, 1e-4)), uHolePow), uHole); if (hk < 0.002) { gl_Position = vec4(3.0, 3.0, 3.0, 1.0); return; } I *= hk; sprA *= hk; }",
// (N6) LAS RAYAS DEL WARP (TNG): cada estrella se estira hacia el punto de fuga (uVp, el destino en pantalla) una fraccion uRadial de su
// distancia a el: casi nada en la preparacion, de golpe en el salto, estables en el crucero, y se recogen a puntos en la salida.
"  vec2 p1 = p0 - (p0 - uVp) * uRadial;",
"  vec2 dv = p0 - p1; float len = length(dv);",
"  if (len > 0.5 * length(uRes)) { p1 = p0 - dv / len * 0.5 * length(uRes); dv = p0 - p1; len = length(dv); }",
"  vec2 ax = len > 1e-3 ? dv / len : vec2(1.0, 0.0), ay = vec2(-ax.y, ax.x);",
"  float R = sig * 4.0 + 3.0 + sig * 6.0 * step(1.05, I) + hero * sig * 20.0 * uHeroK;",
"  if (sprA > 0.0) R = max(R, 0.55 * sprK * max(aSpr.z, aSpr.w) + 1.5);",
"  vHeroPi = hero * uHeroPi; if (vHeroPi > 0.5) R = max(sig * 4.0 + 3.0, uHeroRpx + 2.0);",
"  vec2 pp = mix(p1, p0, step(0.0, position.x)) + ax * position.x * R + ay * position.y * R;",
"  gl_Position = vec4(pp / (uRes * 0.5), 0.5, 1.0);",
"  vSprR = aSpr; vSprC = aSprC; vSprK = max(sprK, 1e-6); vSprA = sprA;",
"  vP = pp; vA = p1; vB = p0; vI = I; vSig = sig; vec3 cS = mix(aColT, aCol, uTrueOn > 0.5 ? clamp(dCam / max(aMag.y, 1e-9), 0.0, 1.0) : 1.0); vCol = mix(cS, uHeroCol, hero * uHeroK); vLen = len; vHero = hero * uHeroK;",
// (19-nov, W1) el DOPPLER del warp, como FVPainter.tintKey: azul hacia el punto de fuga y rojizo en los bordes (uDop = 0 fuera del warp; mezcla maxima del 22 %)
"  if (uDop > 0.001) { float rr = length(p0 - uVp) / (0.5 * length(uRes)); vCol = mix(vCol, vec3(0.588, 0.745, 1.0), uDop * (1.0 - smoothstep(0.0, 0.4, rr))); vCol = mix(vCol, vec3(1.0, 0.627, 0.47), uDop * smoothstep(0.55, 1.0, rr)); }",
"}"].join("\n");
var FW_SH_STAR_F = [
"precision highp float;",
"in vec2 vP; flat in vec2 vA; flat in vec2 vB; flat in float vI; flat in float vSig; flat in vec3 vCol; flat in float vLen; flat in float vHero; flat in float vHeroPi;",
"uniform float uHeroRpx, uHeroW, uHeroSoft;",
"flat in vec4 vSprR; flat in vec2 vSprC; flat in float vSprK; flat in float vSprA;",
"uniform float uGain, uHalo, uStreakV2, uStreakGain, uStreakTail, uStreakW, uFlashS, uStreakLit; uniform vec2 uVp, uRes;",
"uniform sampler2D uPsTex; uniform vec2 uPsAtlas;",
"layout(location = 0) out vec4 oC;",
"void main() {",
// (5-nov) el recorte de la foto: premultiplicado sobre negro, se suma tal cual (sin uGain: la luz es la de la foto)
"  vec3 sprC = vec3(0.0);",
"  if (vSprA > 0.0) { vec2 q = vec2(vP.x - vB.x, vB.y - vP.y) / vSprK + vSprC; if (q.x >= 0.0 && q.y >= 0.0 && q.x <= vSprR.z && q.y <= vSprR.w) sprC = texture(uPsTex, (vSprR.xy + q) / uPsAtlas).rgb * vSprA; }",
"  vec2 ab = vB - vA; float L2 = dot(ab, ab);",
"  float t = L2 > 1e-6 ? clamp(dot(vP - vA, ab) / L2, 0.0, 1.0) : 1.0;",
"  float d = length(vP - (vA + ab * t));",
// (B2, Nino: «las estelas son muy brillantes») ESTELAS V2 (FVPainter: STREAK_*): la raya es fina (sigma ≤ uStreakW px) y tenue (uStreakGain),
// se apaga hacia atras (cola uStreakTail, en exponencial) y la estrella (el nucleo en vB) sigue siendo lo mas brillante; el destello las
// ilumina un poco cerca del punto de fuga (uStreakLit · uFlashS en 0,3 del alto). uStreakV2 = 0 = la de antes (ROJO)
"  if (uStreakV2 > 0.5 && vLen > 0.75) {",
"    float sW = min(vSig, uStreakW), dl = length(vP - vB), head = exp(-0.5 * dl * dl / (vSig * vSig));",
"    float ln = exp(-0.5 * d * d / (sW * sW)) * uStreakGain * mix(uStreakTail, 1.0, t * t);",
"    vec2 rv = (vP - uVp) / uRes.y; float lit = 1.0 + uStreakLit * uFlashS * exp(-dot(rv, rv) / 0.09);",
"    float cc = max(head, ln * lit);",
"    vec3 colS = mix(vCol, vec3(1.0), clamp((vI - 1.0) * head, 0.0, 1.0) * 0.45);",
"    oC = vec4(colS * min(vI, 1.25) * cc * uGain + sprC, 1.0); return;",
"  }",
"  float core = exp(-0.5 * d * d / (vSig * vSig));",
"  float halo = uHalo * step(1.05, vI) / (1.0 + d * d / (9.0 * vSig * vSig)) * (1.0 - smoothstep(vSig * 4.0, vSig * 10.0, d));",
// la protagonista: una corona ancha de su color (el «resplandor» de la llegada), con caida suave y acotada
"  float corona = vHero * (0.7 / (1.0 + d * d / (25.0 * vSig * vSig)) + 0.12 / (1.0 + d * d / (196.0 * vSig * vSig))) * (1.0 - smoothstep(vSig * 9.0, vSig * 24.0, d));",
"  float streak = vSig * 2.5 / (vSig * 2.5 + vLen);",
"  float k = mix(1.0, streak, 0.55) * mix(0.25, 1.0, t);",
"  vec3 col = mix(vCol, vec3(1.0), clamp((vI - 1.0) * core, 0.0, 1.0) * mix(0.7, 0.45, vHero));",
"  if (vHeroPi > 0.5) {",
// (W7d) el sprite de la protagonista de PixInsight: disco de radio RC = 0,16·rr con limbo oscurecido (u 0,55), brillo e^(−(ρ−1)/0,45) y e^(−(ρ−1)/2,6),
// espigas finas en cruz y corte suave en rr; opacidad uHeroW (fvSmooth((3,5 − m)/1,5)); por debajo, la estrella normal sin la corona ancha
"    float RC = max(0.16 * uHeroRpx, 0.5), rho = d / RC; vec3 cN = vCol / max(max(vCol.r, vCol.g), max(vCol.b, 1e-3)), v;",
// el disco va en HDR (x2,5): PixInsight lo suma en 8 bits y satura a blanco; aqui el hombro de tonos del pase final (uKnee) lo dejaba gris
// (NV-16) uHeroSoft 1 = la variante de la llegada de PixInsight (heroSpriteCol(col, true)): nucleo mas teñido y borde que cae en 0,6·rr
"    if (rho < 1.0) { float mu = sqrt(1.0 - rho * rho), Ii = 1.0 - 0.55 * (1.0 - mu); v = Ii * (uHeroSoft > 0.5 ? (0.3 + 0.7 * cN) * 1.2 : (0.6 + 0.4 * cN) * 1.15) * 2.5; }",
"    else { vec2 dd = abs(vP - vB); float fall = max(0.0, 1.0 - d / uHeroRpx), sp = (exp(-dd.y / 0.9) + exp(-dd.x / 0.9)) * 0.55 * fall * fall;",
"      v = (0.95 * exp(-(rho - 1.0) / 0.45) + 0.28 * exp(-(rho - 1.0) / 2.6)) * cN + sp * (0.5 + 0.5 * cN); }",
"    v *= smoothstep(0.0, (uHeroSoft > 0.5 ? 0.6 : 0.12) * uHeroRpx, uHeroRpx - d);",
"    oC = vec4(col * vI * (core + halo) * k * uGain * (1.0 - uHeroW) + v * uHeroW, 1.0); return;",
"  }",
"  oC = vec4((col * vI * (core + halo) + vCol * corona) * k * uGain + sprC, 1.0);",
"}"].join("\n");

// (F3c) LA VIA LACTEA SIMULADA de fondo (F4b, src/engine/fv_milkyway.js, la MISMA que pinta PixInsight): mapa (l, b) visto desde la
// camara en una textura; brillo uPeak·(I/ref)^0,6 con el color del disco o del bulbo; se enciende al alejarse de casa (en casa ya esta en
// la foto). Grano de estrellas no resueltas anclado a las direcciones del mundo (no «nada» al girar). TODO SUPUESTO (lo dice la leyenda).
var FW_SH_MW_F = [
"precision highp float;",
"in vec2 vUv;",
"uniform sampler2D uMap; uniform vec3 uR, uD, uF, uEx, uEy, uEz, uCD, uCB; uniform float uTanH, uTanV, uK, uNL, uGrainK;",
"layout(location = 0) out vec4 oC;",
"float h3(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }",
"void main() {",
"  vec2 ndc = vUv * 2.0 - 1.0;",
"  vec3 d = normalize(uF + ndc.x * uTanH * uR - ndc.y * uTanV * uD);",
"  float gx = dot(d, uEx), gy = dot(d, uEy), gz = clamp(dot(d, uEz), -1.0, 1.0);",
"  float l = atan(gy, gx) / 6.2831853; if (l < 0.0) l += 1.0;",
"  vec2 q = vec2(l + 0.5 / uNL, asin(gz) / 3.1415927 + 0.5);",
"  vec4 mw = texture(uMap, q);",
"  float v = uK * pow(clamp(mw.r, 0.0, 1.6), 0.6);",
"  vec3 g = floor(d * 900.0); float n = h3(g), s = step(0.9965, n) * (n - 0.9965) / 0.0035;",
"  vec3 col = mix(uCD, uCB, clamp(mw.g, 0.0, 1.0)) * (v * (0.82 + 2.6 * s * uGrainK));",
"  oC = vec4(col, 1.0);",
"}"].join("\n");

var FW_SH_QUAD_V = "precision highp float;\nin vec3 position;\nout vec2 vUv;\nvoid main() { vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }";

// la nebulosa como VOLUMEN v2 (F3b): CUERPO grueso + LAMINA fina con el detalle de la foto + POLVO que absorbe (fw_relief.js).
// Cada tramo del rayo entre dos muestras se integra de forma EXACTA para perfiles gaussianos con g = (w − c)/s lineal en el tramo:
// ∫φ(g) dt = (Φ(g_b) − Φ(g_a))/g'. CUERPO grueso: paso grueso. LAMINAS (0,15–0,5 a.l., mas finas que el paso grueso): PASO ADAPTATIVO
// (como el «sphere tracing»): cerca de una lamina el paso se acorta a una fraccion de su anchura, asi el cruce nunca se salta aunque la
// lamina este arrugada y se vea de refilon, y la integral del tramo es exacta (sin granulado). El detalle se lee a resolucion completa
// en el punto donde el rayo cruza la lamina (proyectado desde la Tierra: desde casa sale la foto exacta). Vista de canto, el brillo
// crece con 1/cos hasta uSecMax (no estalla). (Probado y descartado el 4-nov: lamina como superficie de grosor cero evaluada una vez
// por cruce con el paso fijo -> agujeros y muaré de refilon: un paso cruzaba la lamina dos veces.) Caida hacia los bordes de la foto (uEdge del lado,
// ondulada por el brillo de la propia imagen) solo cuando se mira desde fuera del eje de la Tierra (en casa, la foto exacta).
var FW_SH_VOL_F = [
"precision highp float;",
"in vec2 vUv;",
"uniform sampler2D uDet, uRel, uShe, uBody;",
"uniform vec3 uCam, uR, uD, uF, uWt, uMul; uniform float uTanH, uTanV, uZ0, uZ1, uKx, uKy, uSteps, uFrame, uMirror, uGain, uTexW, uPixAng, uSecMax, uEdge, uWob, uSheet, uDust, uKB, uOffHome, uEdgeOld, uEdgeRamp, uBudget, uBudgetK, uEdgeShow, uN2c, uN2cDB, uN2cSky, uN2cCont; uniform vec2 uN2cA; uniform vec3 uN2cPed;",
// (nP, PROFUNDITAS) LA LOSA INCLINADA: uTiltOn 1 -> la profundidad dentro de la losa se mide a lo largo de la normal uTN desde el centro uTC
// (el contrato scene.nebula.tilt, como fvNavTiltPt); el color/detalle se sigue leyendo por el rayo desde la Tierra (colUv): desde casa, la
// foto exacta. La caja de recorte crece uTPad en z (lo que se sale la losa girada dentro del haz de la foto). uTiltOn 0 = lo de antes, identico
"uniform vec3 uTN, uTC; uniform float uTiltOn, uTPad;",
"const vec3 LW = vec3(0.2126, 0.7152, 0.0722);",
"layout(location = 0) out vec4 oC;",
"float hash(vec2 p) { p = fract(p * vec2(443.897, 441.423)); p += dot(p, p.yx + 19.19); return fract((p.x + p.y) * p.x); }",
"float Phi(float x) { x = clamp(x, -6.0, 6.0); return 0.5 + 0.5 * tanh(0.7978845608 * (x + 0.044715 * x * x * x)); }",
"float phi(float x) { return 0.3989422804 * exp(-0.5 * x * x); }",
"float Jg(float a, float b) { float d = b - a; return abs(d) > 1e-3 ? (Phi(b) - Phi(a)) / d : phi(0.5 * (a + b)); }",
"vec2 colUv(vec3 p) { vec2 q = vec2(p.x / p.z * uKx + 0.5, p.y / p.z * uKy + 0.5); if (uMirror > 0.5) q.x = 1.0 - q.x; return q; }",
// (D, rev. 2) caida de los bordes SIN cantos: rectangulo de esquinas redondas (superelipse p = 4) + ruido de dos octavas fijo en la foto, con
// una banda el doble de ancha. La de antes (uEdgeOld = 1, control en rojo) era min(x, y) por un factor del brillo: donde el borde de la foto
// es brillante el factor no cambia y el canto salia recto (fila 6a del montaje de la pasada N). En casa no se usa (off = 0).
"float fvHash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }",
"float fvNoise(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f); return mix(mix(fvHash(i), fvHash(i + vec2(1.0, 0.0)), f.x), mix(fvHash(i + vec2(0.0, 1.0)), fvHash(i + vec2(1.0, 1.0)), f.x), f.y); }",
// (19-nov, N2c; FW_N2C, espejo de FV_N2C en src/engine/fv_objects.js: fvN2cRem) FUNDIR EL BORDE DE LA FOTO: rem = SKY · (1 − suave(d / DB)), d = distancia al canto mas cercano en fracciones del lado mayor de la foto (min suave de orden 4;
// uN2cA = (ancho, alto) / lado mayor). Del cuerpo y del detalle se resta el pedestal de cielo (uN2cPed, 0..1: el p25 de la foto sin estrellas, el de uFogPed) × rem y el resto se atenua (1 − CONT · rem), ANTES del borde suave (fade): como las capas de PixInsight
"float n2cRem(vec2 q) { float dx = max(min(q.x, 1.0 - q.x) * uN2cA.x, 1e-4), dy = max(min(q.y, 1.0 - q.y) * uN2cA.y, 1e-4), a2 = dx * dx, b2 = dy * dy, d = 1.0 / sqrt(sqrt(1.0 / (a2 * a2) + 1.0 / (b2 * b2))); return uN2cSky * (1.0 - smoothstep(0.0, 1.0, d / max(uN2cDB, 1e-6))); }",
"vec3 n2cApply(vec3 c, vec2 q, float k) { float rem = n2cRem(q) * k; return max(c - uN2cPed * rem, vec3(0.0)) * (1.0 - uN2cCont * rem); }",
"float edgeFade(vec2 q, float wob) {",
"  if (uEdgeOld > 0.5) { float k = 1.0 + uWob * (wob - 0.5); return smoothstep(0.0, uEdge, min(q.x, 1.0 - q.x) * k) * smoothstep(0.0, uEdge, min(q.y, 1.0 - q.y) * k); }",
"  vec2 a = clamp(abs(2.0 * q - 1.0), 0.0, 1.0); float d = 1.0 - sqrt(sqrt(a.x * a.x * a.x * a.x + a.y * a.y * a.y * a.y));",
"  float n = 0.65 * fvNoise(q * 6.0) + 0.35 * fvNoise(q * 17.0 + 3.1);",
"  d = d * (1.0 + 0.2 * uWob * (wob - 0.5)) + 0.34 * (n - 0.5);",
// (K10 H-4, Codex) el ruido (+0,34·(n−0,5)) puede dejar d > 0 justo en q = 1 y el corte de abajo es un escalon: quedaba un resto de emision
// (hasta 5/255 con blanco unitario) en el filo del recorte. La rampa de 0,02 no depende del ruido y lo lleva a 0 EN el borde (uEdgeRamp = 0: control en rojo).
"  float e = smoothstep(0.0, 2.2 * uEdge, d), ramp = mix(1.0, smoothstep(0.0, 0.02, min(min(q.x, 1.0 - q.x), min(q.y, 1.0 - q.y))), uEdgeRamp);",
"  return e * e * ramp * step(0.0, q.x) * step(q.x, 1.0) * step(0.0, q.y) * step(q.y, 1.0); }",
"void main() {",
"  vec2 ndc = vUv * 2.0 - 1.0;",
"  vec3 d = normalize(uF + ndc.x * uTanH * uR - ndc.y * uTanV * uD);",
"  vec3 bmax = vec3(0.5 * (uZ1 + uTPad) / uKx, 0.5 * (uZ1 + uTPad) / uKy, uZ1 + uTPad), bmin = vec3(-bmax.x, -bmax.y, uZ0 - uTPad);",
"  float dn = uTiltOn > 0.5 ? dot(d, uTN) : d.z;",
"  vec3 inv = 1.0 / d, t0 = (bmin - uCam) * inv, t1 = (bmax - uCam) * inv, tlo = min(t0, t1), thi = max(t0, t1);",
"  float tn = max(max(max(tlo.x, tlo.y), tlo.z), 0.0), tf = min(min(thi.x, thi.y), thi.z);",
"  if (tf <= tn) { oC = vec4(0.0, 0.0, 0.0, 1.0); return; }",
"  float th = uZ1 - uZ0, dtMax = (tf - tn) / uSteps, dtMin = 0.02 * dtMax, j = hash(gl_FragCoord.xy + vec2(uFrame * 0.618, uFrame * 0.414));",
"  vec3 L = vec3(0.0), T = vec3(1.0);",
"  bool okA = false; vec3 pA = vec3(0.0); vec2 qA = vec2(0.0); vec4 rA = vec4(0.0); vec3 gSA = vec3(0.0); float gDA = 0.0, tA = 0.0;",
"  float t = tn + j * dtMax;",
"  for (int k = 0; k < 240; ++k) {",
"    t = min(t, tf);",
"    vec3 p = uCam + d * t;",
"    bool okB = p.z > 0.0;",
"    vec2 qB = vec2(0.0); vec4 rB = vec4(0.0); vec3 gSB = vec3(0.0); float gDB = 0.0, step = dtMax;",
"    if (okB) {",
"      qB = colUv(p); float w = uTiltOn > 0.5 ? dot(p - uTC, uTN) / th + 0.5 : (p.z - uZ0) / th;",
"      okB = all(greaterThanEqual(vec3(qB, w), vec3(0.0))) && all(lessThanEqual(vec3(qB, w), vec3(1.0)));",
"      if (okB) {",
"        rB = texture(uRel, qB); gDB = (w - rB.x) / rB.y; gSB = vec3(w) - texture(uShe, qB).xyz;",
"        if (uSheet > 0.5) {",
"          // paso adaptativo: lejos de las laminas, el grueso; cerca, la distancia en profundidad partida por (|d.z| + 1,5·|d lateral|)",
"          // (pendiente de la arruga ≤ 1,5); dentro del perfil, 0,6 σ igual partido: el cruce no se salta y g es casi lineal en el tramo",
"          vec3 s3 = rB.z * uMul * th, dz = abs(gSB) * th;",
"          vec3 st = max(0.6 * s3, 0.8 * (dz - 2.5 * s3)) / (abs(dn) + 1.5 * sqrt(max(0.0, 1.0 - dn * dn)));",
"          step = clamp(min(min(st.x, st.y), st.z), dtMin, dtMax);",
// (K10 H-3, Codex) PRESUPUESTO DE PASOS: el bucle tiene 240 vueltas y el paso adaptativo puede ser 50 veces menor que el grueso; en un rayo casi
// paralelo a una lamina se agotaba antes de llegar a tf y el volumen salia a medio integrar (medido 4-nov: dentro de la losa, de canto, hasta el 21 %
// de los pixeles). El paso nunca baja de «lo que queda / vueltas que quedan»: el rayo SIEMPRE llega a tf (uBudget = 0: el de antes, control en rojo).
"        }",
"      }",
"    }",
"    if (float(k) >= uBudgetK) step = max(step, uBudget * (tf - t) / float(max(239 - k, 1)));",
"    if (okA && okB) {",
"      float h = t - tA; vec2 qm = 0.5 * (qA + qB); vec3 pm = 0.5 * (pA + p);",
"      float off = max(uOffHome, 1.0 - smoothstep(0.99966, 0.9999966, dot(normalize(pm), d)));",
"      float fade = mix(1.0, edgeFade(qm, 0.5 * (rA.w + rB.w)), off * uEdgeShow);",   // (W6) uEdgeShow: el borde de la foto esta en pantalla
"      float k2c = off * uEdgeShow * uN2c;",   // (N2c) 0 con el borde de la foto fuera de pantalla (o FW_N2C apagado): el cuerpo y el detalle de siempre
"      L += T * (uKB * fade * Jg(gDA, gDB) * h / (0.5 * (rA.y + rB.y) * th)) * n2cApply(texture(uBody, qm).rgb, qm, k2c);",
"      if (uSheet > 0.5) for (int i = 0; i < 3; ++i) {",
"        float sS = 0.5 * (rA.z + rB.z) * uMul[i], ga = gSA[i] / sS, gb = gSB[i] / sS;",
"        bool cr = ga * gb <= 0.0;",
"        if (!cr && min(abs(ga), abs(gb)) > 4.0) continue;",
"        float cs = abs(gb - ga) / max(h, 1e-6) * sS * th, graze = min(1.0, uSecMax * cs);",
"        float a = cr ? clamp(-ga / (gb - ga + 1e-9), 0.0, 1.0) : (abs(ga) < abs(gb) ? 0.0 : 1.0);",
"        vec3 ps = mix(pA, p, a); vec2 qs = mix(qA, qB, a); float ts = tA + a * h;",
"        float lod = clamp(log2(max(ts * uPixAng * uKx * uTexW / ps.z, 1e-3) * clamp(1.0 / max(cs, 1e-3), 1.0, 8.0)), 0.0, 8.0);",
"        vec3 H = n2cApply(textureLod(uDet, qs, lod).rgb, qs, k2c), Bk = uKB * n2cApply(texture(uBody, qs).rgb, qs, k2c);",
"        float kk = Jg(ga, gb) * h / (sS * th) * graze * fade;",
"        float lH = dot(H, LW), lB = dot(Bk, LW);",
// (F3c) SIN DESPLAZAMIENTO DE TONO: la lamina emite el detalle CON EL COLOR DE LA FOTO (H escalado), no la resta canal a canal
// max(H − B, 0), que en el Hα (verde y azul por debajo del cuerpo) se quedaba solo con el rojo y viraba a magenta. En luminancia la
// suma desde casa es la misma (lum(H)·(1 − lB/lH) = lH − lB).
"        L += T * (uWt[i] * kk * max(1.0 - lB / max(lH, 1e-4), 0.0)) * H;",
"        if (i == 0 && uDust > 0.5) {",
"          vec4 rs = texture(uRel, qs); float fb = 1.0 - Phi((texture(uShe, qs).x - rs.x) / rs.y);",
// el polvo absorbe GRIS (en luminancia): una absorcion por canal tambien teñia
"          float x = clamp(lH / max(lB, 0.002), 0.0, 1.0);",
"          float xp = clamp((x - (1.0 - fb)) / max(fb, 0.05), 0.003, 1.0);",
"          T *= exp(log(xp) * kk);",
"        }",
"      }",
"      if (max(T.r, max(T.g, T.b)) < 0.003) break;",
"    }",
"    okA = okB; pA = p; qA = qB; rA = rB; gDA = gDB; gSA = gSB; tA = t;",
"    if (t >= tf) break;",
"    t += step;",
"  }",
"  oC = vec4(L * uGain, dot(T, vec3(0.2126, 0.7152, 0.0722)));",
"}"].join("\n");

// composicion: lo de detras atenuado por el volumen + la emision
// (F3c) CONTRASTE LOCAL del volumen fuera de casa (uLocal, 0 en casa: la foto exacta): la emision se escala por su luminancia frente a la
// media de un anillo de 8 muestras (radio uRad texeles), sin tocar el tono (r, g y b por el mismo factor). Es un producto ESTETICO (da la
// «fibrilla» y el punch que el relieve suavizado perdia: f3b_dentro_capas «niebla plana»); no entra en ninguna medida.
var FW_SH_COMP_F = [
"precision highp float;",
"in vec2 vUv;",
"uniform sampler2D uFar, uVol, uFogTex; uniform float uVolOn, uLocal, uRad, uFogK, uFogLodB, uFogLodD, uFogGam, uFogMix, uFogMirror; uniform vec2 uVolTexel, uFogC, uFogS; uniform vec3 uFogPed;",
// (16-nov, P22; fw_box.js FW_VEIL) EL VELO: lo que se le resta a la emision del volumen (pedestal de cielo + margen, 0..1) antes de mezclarla con la foto del plano; 0 = lo de antes
"uniform vec3 uVeil;",
// (W3) LA FOTO COMO PLANO cerca de casa (FVPainter.paintLayers de PixInsight: photoPlane con peso wP = 1 − suave(|camara| / (PHOTO_FADE × d))): la
// foto sin estrellas a resolucion completa, leida POR PIXEL de pantalla con texture() (mipmaps trilineales + anisotropia por las derivadas) en el
// punto del rayo a la distancia de la nebulosa, proyectado desde la Tierra (colUv del volumen: desde casa, la foto exacta). uPhK = su peso; el
// volumen pesa 1 − uPhK y su absorcion tambien (la foto ya trae el polvo delante de cada estrella, como en PixInsight). uPhK 0 = lo de antes
"uniform sampler2D uDet; uniform vec3 uR, uD, uF, uCam; uniform float uTanH, uTanV, uKx, uKy, uMirror, uGain, uPhK, uPhDist, uPhBias, uNebK;",
"vec3 photoAt() {",
"  vec2 n = vUv * 2.0 - 1.0; vec3 d = normalize(uF + n.x * uTanH * uR - n.y * uTanV * uD);",
"  if (d.z < 1e-6) return vec3(0.0);",
"  vec3 p = uCam + d * ((uPhDist - uCam.z) / d.z); vec2 q = vec2(p.x / p.z * uKx + 0.5, p.y / p.z * uKy + 0.5); if (uMirror > 0.5) q.x = 1.0 - q.x;",
"  if (any(lessThan(q, vec2(0.0))) || any(greaterThan(q, vec2(1.0)))) return vec3(0.0);",
"  return texture(uDet, q, uPhBias).rgb * uGain; }",
"layout(location = 0) out vec4 oC;",
"void main() {",
"  vec3 f = texture(uFar, vUv).rgb;",
"  if (uVolOn > 0.5) {",
"    vec4 v = texture(uVol, vUv); vec3 e = v.rgb;",
"    if (uLocal > 0.001) {",
"      const vec3 LW = vec3(0.2126, 0.7152, 0.0722); float m = 0.0;",
"      for (int i = 0; i < 8; ++i) { float a = float(i) * 0.7853982; m += dot(texture(uVol, vUv + uVolTexel * uRad * vec2(cos(a), sin(a))).rgb, LW); }",
"      m *= 0.125; float l = dot(e, LW);",
"      e *= clamp(1.0 + uLocal * (l - m) / max(m, 0.01), 0.45, 2.2);",
"    }",
"    if (uVeil.x + uVeil.y + uVeil.z > 0.0) e = max(e - uVeil, vec3(0.0));",
"    if (uPhK > 0.001) { e = mix(e, photoAt(), uPhK); v.a = mix(v.a, 1.0, uPhK); }",
// (W7c, Nino 5-nov: «tunel negro como en PixInsight») en el salto la nebulosa se apaga al 10 % (uNebK, el wFade de FVPainter.paintLayers) y su polvo tambien
"    e *= uNebK; v.a = mix(1.0, v.a, uNebK);",
"    f = f * v.a + e;",
"  }",
// (D, rev. 3) la niebla de dentro: fija en la pantalla (como en PixInsight), Screen con opacidad uFogK
"  if (uFogK > 0.001) {",
"    vec2 q = uFogC + (vUv - 0.5) * uFogS; if (uFogMirror > 0.5) q.x = 1.0 - q.x;",
"    vec3 b = textureLod(uFogTex, q, uFogLodB).rgb, d = textureLod(uFogTex, q, uFogLodD).rgb;",
"    vec3 gb = pow(max(b - uFogPed, 0.0) / max(1.0 - uFogPed, 0.004), vec3(uFogGam)), gd = pow(max(d - uFogPed, 0.0) / max(1.0 - uFogPed, 0.004), vec3(uFogGam));",
"    vec3 g = mix(gb, gd, uFogMix);",
"    f = f + uFogK * g * max(1.0 - f, 0.0);",
"  }",
"  oC = vec4(f, 1.0);",
"}"].join("\n");
// capas (reserva): cuadrilatero con las esquinas relativas a la camara
var FW_SH_LAYER_V = [
"precision highp float;",
"in vec3 position; in vec2 uv;",
"uniform vec3 uR, uD, uF; uniform float uTanH, uTanV;",
"out vec2 vUv;",
"void main() { vec3 c = vec3(dot(position, uR), dot(position, uD), dot(position, uF)); float n = 1e-6;",
"  vUv = uv; gl_Position = vec4(c.x / uTanH, -c.y / uTanV, c.z - 2.0 * n, c.z); }"].join("\n");
var FW_SH_LAYER_F = "precision highp float;\nin vec2 vUv;\nuniform sampler2D uTex; uniform float uGain, uMirror;\nlayout(location = 0) out vec4 oC;\nvoid main() { vec2 q = vUv; if (uMirror > 0.5) q.x = 1.0 - q.x; vec2 e = smoothstep(vec2(0.0), vec2(0.02), q) * smoothstep(vec2(0.0), vec2(0.02), 1.0 - q); oC = vec4(texture(uTex, q).rgb * uGain * e.x * e.y, 1.0); }";
// (N8) LOS OBJETOS COMPACTOS (planetarias, galaxias, nebulosas pequeñas: scene.objects de C): K capas DE CARA A LA CAMARA a ±0,85 de su
// semiprofundidad, cada una con el recorte de la foto sin estrellas por el peso de su capa (los pesos SUMAN 1 por pixel: desde la Tierra se ve
// exactamente el recorte). Pesos = los de fvObjShellWeights de src/engine/fv_objects.js (C): capa k en t_k = 0,85(−1 + 2k/(K−1)), cubre los
// radios ρ < √(1 − t_k²) con borde suave de 0,25; una galaxia es un disco (todas igual). El volumen es ESTETICO (la foto da una cara): lo dice la ficha.
var FW_SH_OBJ_F = [
"precision highp float;",
"in vec2 vUv;",
"uniform sampler2D uTex; uniform float uOp, uK, uIdx, uFlat, uGain; uniform vec2 uC, uRr;",
"layout(location = 0) out vec4 oC;",
"float sm(float x) { x = clamp(x, 0.0, 1.0); return x * x * (3.0 - 2.0 * x); }",
"void main() {",
"  float rho = length((vUv - uC) / uRr), w;",
"  if (uFlat > 0.5) w = 1.0 / uK;",
"  else { float s = 0.0, wi = 0.0; for (int k = 0; k < 9; ++k) { float fk = float(k); if (fk >= uK) break; float t = uK > 1.5 ? 0.85 * (-1.0 + 2.0 * fk / (uK - 1.0)) : 0.0; float v = sm((sqrt(max(0.0, 1.0 - t * t)) - rho) / 0.25 + 0.5); s += v; if (fk == uIdx) wi = v; }",
"    w = s > 1e-6 ? wi / s : (uIdx == floor(uK / 2.0) ? 1.0 : 0.0); }",
"  vec2 e = smoothstep(vec2(0.0), vec2(0.03), vUv) * smoothstep(vec2(0.0), vec2(0.03), 1.0 - vUv);",
"  oC = vec4(texture(uTex, vUv).rgb * w * uOp * uGain * e.x * e.y, 1.0);",
"}"].join("\n");
// bloom: brillo por encima del umbral (rodilla suave), reducciones de 4 muestras y subidas en tienda
var FW_SH_BRIGHT_F = "precision highp float;\nin vec2 vUv;\nuniform sampler2D uTex; uniform vec2 uTexel; uniform float uThr;\nlayout(location = 0) out vec4 oC;\nvoid main() { vec3 c = 0.25 * (texture(uTex, vUv + uTexel * vec2(-1.0, -1.0)).rgb + texture(uTex, vUv + uTexel * vec2(1.0, -1.0)).rgb + texture(uTex, vUv + uTexel * vec2(-1.0, 1.0)).rgb + texture(uTex, vUv + uTexel * vec2(1.0, 1.0)).rgb); float b = max(c.r, max(c.g, c.b)); float k = 0.5; float s = clamp(b - uThr + k, 0.0, 2.0 * k); s = s * s / (4.0 * k + 1e-5); oC = vec4(c * max(s, b - uThr) / max(b, 1e-5), 1.0); }";
var FW_SH_DOWN_F = "precision highp float;\nin vec2 vUv;\nuniform sampler2D uTex; uniform vec2 uTexel;\nlayout(location = 0) out vec4 oC;\nvoid main() { vec3 c = texture(uTex, vUv).rgb * 4.0 + texture(uTex, vUv + uTexel * vec2(-1.0, -1.0)).rgb + texture(uTex, vUv + uTexel * vec2(1.0, -1.0)).rgb + texture(uTex, vUv + uTexel * vec2(-1.0, 1.0)).rgb + texture(uTex, vUv + uTexel * vec2(1.0, 1.0)).rgb; oC = vec4(c / 8.0, 1.0); }";
var FW_SH_UP_F = "precision highp float;\nin vec2 vUv;\nuniform sampler2D uTex, uBase; uniform vec2 uTexel;\nlayout(location = 0) out vec4 oC;\nvoid main() { vec3 s = vec3(0.0); s += texture(uTex, vUv + uTexel * vec2(-1.0, 0.0)).rgb * 2.0 + texture(uTex, vUv + uTexel * vec2(1.0, 0.0)).rgb * 2.0 + texture(uTex, vUv + uTexel * vec2(0.0, -1.0)).rgb * 2.0 + texture(uTex, vUv + uTexel * vec2(0.0, 1.0)).rgb * 2.0; s += texture(uTex, vUv + uTexel * vec2(-1.0, -1.0)).rgb + texture(uTex, vUv + uTexel * vec2(1.0, -1.0)).rgb + texture(uTex, vUv + uTexel * vec2(-1.0, 1.0)).rgb + texture(uTex, vUv + uTexel * vec2(1.0, 1.0)).rgb; s += texture(uTex, vUv).rgb * 4.0; oC = vec4(s / 16.0 + texture(uBase, vUv).rgb, 1.0); }";
var FW_SH_FINAL_F = [
"precision highp float;",
"in vec2 vUv;",
"uniform sampler2D uMain, uBloom, uAvg; uniform float uBloomK, uFlash, uAberr, uVig, uGrain, uFrame, uKnee, uExpTarget, uExpMin, uExpOn, uZoom, uTunnel, uTime, uFlashR, uFlashRad, uSpikeW, uSpikeL, uFlashGain, uSpikeK, uFlashHalo; uniform vec2 uRes, uVpUv; uniform vec3 uFlashCol;",
"layout(location = 0) out vec4 oC;",
"float hash(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }",
"vec3 shoulder(vec3 x) { float m = max(x.r, max(x.g, x.b)), k = uKnee; if (m <= k) return x; float t = k + (1.0 - k) * (1.0 - exp(-(m - k) / (1.0 - k))); return x * (t / m); }",
"void main() {",
"  vec2 q = vUv, c = q - 0.5;",
"  vec3 col;",
"  if (uAberr > 0.0) { vec2 o = c * uAberr; col = vec3(texture(uMain, q + o).r, texture(uMain, q).g, texture(uMain, q - o).b); }",
"  else col = texture(uMain, q).rgb;",
// (N6) EL TUNEL DEL WARP: desenfoque radial hacia el punto de fuga (todo -estrellas y nebulosa- se estira hacia fuera) y rayas de luz
// azul-blanca que nacen cerca del centro y salen hacia los bordes (coordenadas polares; el reloj de escena uTime las mueve: el video
// sale igual cada vez). uZoom y uTunnel los da la fase del warp (fwWarpFx).
"  if (uZoom > 0.002) { vec2 dv = q - uVpUv; vec3 acc = col; float ws = 1.0; for (int i = 1; i < 12; ++i) { float s = float(i) / 11.0, w = 1.0 - 0.75 * s; acc += texture(uMain, q - dv * s * uZoom).rgb * w; ws += w; } col = acc / ws * (1.0 + 0.5 * uZoom); }",
"  if (uTunnel > 0.002) { vec2 dv = (q - uVpUv) * vec2(uRes.x / uRes.y, 1.0); float r = length(dv), an = atan(dv.y, dv.x) / 6.2831853 + 0.5, cell = floor(an * 240.0), h = hash(vec2(cell, 7.0)), h2 = hash(vec2(cell, 19.0));",
"    float x = fract(h2 + uTime * (0.35 + 0.9 * h) - 0.55 * log(max(r, 0.01))), seg = smoothstep(0.0, 0.08, x) * (1.0 - smoothstep(0.18, 0.42, x)), edge = 1.0 - abs(fract(an * 240.0) - 0.5) * 2.0;",
"    col += vec3(0.62, 0.78, 1.0) * uTunnel * seg * smoothstep(0.3, 0.9, edge) * smoothstep(0.04, 0.5, r) * step(0.55, h) * 0.55; }",
"  col += texture(uBloom, q).rgb * uBloomK;",
// (F3c) EXPOSICION: si la escena entera brilla mas que la foto (dentro del gas, de canto: la luz de muchas columnas se suma) se baja la
// exposicion hasta la media de la foto, nunca se sube (en casa = 1: la foto exacta). Media de 9 muestras de la escena reducida a ~12 px,
// con mas peso en el centro. Sin memoria entre fotogramas: el video sale igual cada vez.
"  if (uExpOn > 0.5) { float a = 0.0, wsum = 0.0; for (int j = -1; j <= 1; ++j) for (int i = -1; i <= 1; ++i) { float w = (i == 0 && j == 0) ? 4.0 : ((i == 0 || j == 0) ? 2.0 : 1.0); a += w * dot(texture(uAvg, vec2(0.5) + vec2(float(i), float(j)) * 0.3).rgb, vec3(0.2126, 0.7152, 0.0722)); wsum += w; }",
"    a /= wsum; col *= clamp(uExpTarget / max(a, 1e-4), uExpMin, 1.0); }",
// (D, §15) el destello lejano de Trek: un nucleo en el punto de fuga (radio uFlashR del alto), un halo tenue y una espiga vertical fina que
// llega a ~0,9 del alto, mas una horizontal corta; nada en el resto de la pantalla (< 5 % de pixeles muy brillantes en el pico, medido en
// fv_nD_cdp.js). uFlashRad = 0 es el de antes (pantalla entera tenida: control en rojo de las pruebas)
"  { vec2 fv = (q - uVpUv) * vec2(uRes.x / uRes.y, 1.0); float r2 = dot(fv, fv);",
// (B2) con uSpikeK = 0 (destello V2): sin espigas; nucleo gaussiano, halo gaussiano 3,5 veces mayor (uFlashHalo) y resplandor exponencial
"    float shp = exp(-r2 / (uFlashR * uFlashR)) + mix(0.25 * exp(-sqrt(r2) / (2.5 * uFlashR)), uFlashHalo * exp(-r2 / (12.25 * uFlashR * uFlashR)) + 0.08 * exp(-sqrt(r2) / (9.0 * uFlashR)), 1.0 - uSpikeK)",
"              + uSpikeK * (0.8 * exp(-fv.x * fv.x / (uSpikeW * uSpikeW)) * exp(-abs(fv.y) / uSpikeL) + 0.35 * exp(-fv.y * fv.y / (uSpikeW * uSpikeW)) * exp(-abs(fv.x) / (0.4 * uSpikeL)));",
"    col += uFlashCol * uFlash * mix(1.0, uFlashGain * shp, uFlashRad); }",
"  col = shoulder(max(col, vec3(0.0)));",
"  float v = 1.0 - uVig * smoothstep(0.35, 0.85, length(c * vec2(uRes.x / uRes.y, 1.0)) / (0.5 * uRes.x / uRes.y));",
"  col *= v;",
"  float g = hash(gl_FragCoord.xy + vec2(uFrame * 17.0, uFrame * 31.0)) + hash(gl_FragCoord.xy * 1.37 + vec2(uFrame * 7.0, 3.0)) - 1.0;",
"  col += g * uGrain;",
"  oC = vec4(clamp(col, 0.0, 1.0), 1.0);",
"}"].join("\n");

// ---------------------------------------------------------------------------
// (Blender 2, 5-nov) LA VENTANA DE LA NAVE: el primer plano renderizado en Blender (blender/primerplano.py -> build_primerplano_rsc.py ->
// web/fw_fg_s<nivel>.js), la misma ventana que PixInsight (src/ui/fv_foreground.js): marco de laton con su sombra y el reflejo de la lampara
// (over), la luz de fuera en el labio (rim) y, en la variante b, la suciedad del cristal (dirt). Los trozos se componen UNA vez por tamaño en
// dos texturas del tamaño del lienzo (over RGBA; luz: R = rim, G = suciedad) y el pase final las aplica tras el viñeteado. La luz de la escena:
// global (warp, destello, la media de la escena —uAvg— como «foto en casa») y LOCAL (el bloom mas fuerte de 3 puntos hacia dentro desde cada pixel del borde: la estrella
// brillante enciende el marco y el polvo de su lado). FW_FG.ON = false: el pase final de siempre (ni se carga nada). Con REC (que graba el
// lienzo «solo foto», sin la cabina HTML) la ventana no se pinta, como en PixInsight con REC «solo foto» (REC_PHOTO_ONLY true = si).
// Variante recordada en localStorage «fv.window» (comodidad del navegador).
// ---------------------------------------------------------------------------
var FW_FG = { ON: true, DEFAULT: "a", VARIANTS: ["off", "a", "b", "c"], CYCLE: ["a", "c"], REC_PHOTO_ONLY: false, LEVELS: ["1.6", "3.2", "4.8"],
              RIM_BASE: 0.06, RIM_PHOTO: 0.45, RIM_WARP: 0.70, RIM_FLASH: 0.55, DIRT_WARP: 0.30, LOC_K: 2.2, LOC_IN: 0.06 };
var FW_FG_DATA = (typeof FW_FG_DATA === "object" && FW_FG_DATA) ? FW_FG_DATA : {};
var FW_FG_ST = { variant: null, asked: {}, imgs: {} };
function fwFgVariant() {
   if (FW_FG_ST.variant === null) { var v = FW_FG.DEFAULT; try { var r = localStorage.getItem("fv.window"); if (r && FW_FG.CYCLE.indexOf(r) >= 0) v = r; } catch (e) {} FW_FG_ST.variant = v; }
   return FW_FG_ST.variant;
}
// la siguiente del ciclo (a -> c -> a), como el clic de la placa en PixInsight (el visor aun no lo ofrece: sin otro camino)
function fwFgCycle(save) { var L = FW_FG.CYCLE, i = L.indexOf(fwFgVariant()); return fwFgSetVariant(L[(i + 1) % L.length], save); }
function fwFgSetVariant(v, save) { if (FW_FG.VARIANTS.indexOf(v) < 0) return fwFgVariant(); FW_FG_ST.variant = v; if (save) { try { localStorage.setItem("fv.window", v); } catch (e) {} } return v; }
function fwFgLevel(k) { var L = FW_FG.LEVELS; for (var i = 0; i < L.length; ++i) if (parseFloat(L[i]) >= k - 1e-6) return L[i]; return L[L.length - 1]; }
// lo llama cada fw_fg_s<nivel>.js al cargarse: decodifica los PNG (asincrono) y marca el nivel listo
function fwFgLoaded(lv) {
   var D = FW_FG_DATA[lv]; if (!D || FW_FG_ST.imgs[lv]) return;
   var I = FW_FG_ST.imgs[lv] = { n: 0, done: 0, img: {} };
   for (var p in D.pieces) for (var l in D.pieces[p]) {
      ++I.n; var im = new Image(); im.onload = im.onerror = function() { ++I.done; };
      im.src = D.pieces[p][l].src; I.img[p + "/" + l] = im;
   }
}
function fwFgReadyLv(lv) {
   var I = FW_FG_ST.imgs[lv];
   if (I) return I.done >= I.n;
   if (!FW_FG_ST.asked[lv]) {
      FW_FG_ST.asked[lv] = true;
      if (FW_FG_DATA[lv]) fwFgLoaded(lv);
      else { var s = document.createElement("script"); s.src = "fw_fg_s" + lv + ".js"; s.async = true; s.onerror = function() { try { console.warn("[fg] no se pudo cargar fw_fg_s" + lv + ".js: queda la vista sin ventana"); } catch (e) {} }; document.head.appendChild(s); }
   }
   return false;
}
// la composicion de un tamaño (la misma regla que fvFgSet y que compose() de build_primerplano_rsc.py) -> { over: ImageData, light (Uint8 RGBA), rimCol }
function fwFgCompose(lv, W, H, v) {
   var D = FW_FG_DATA[lv], I = FW_FG_ST.imgs[lv].img, k = W / 1280, f = k / D.scale, c = Math.round(50 * k), tl = Math.max(8, Math.round(250 * k));
   function cv() { var e = document.createElement("canvas"); e.width = W; e.height = H; var x = e.getContext("2d", { willReadFrequently: true }); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = "high"; return x; }
   var X = { over: cv(), rim: cv(), dirt: cv() }, G = v === "c";
   var corners = [["c_tl", 0, 0], ["c_tr", W - c, 0], ["c_bl", 0, H - c], ["c_br", W - c, H - c]], i, j;
   for (i = 0; i < 4; ++i) {
      var cp = corners[i], lo = G ? "over_g" : "over", lr = G ? "rim_g" : "rim";
      if (I[cp[0] + "/" + lo]) X.over.drawImage(I[cp[0] + "/" + lo], cp[1], cp[2], c, c);
      if (I[cp[0] + "/" + lr]) X.rim.drawImage(I[cp[0] + "/" + lr], cp[1], cp[2], c, c);
      if (v === "b" && I[cp[0] + "/dirt"]) X.dirt.drawImage(I[cp[0] + "/dirt"], cp[1], cp[2], c, c);
   }
   var edges = [["e_top", true], ["e_bottom", true], ["e_left", false], ["e_right", false]];
   for (i = 0; i < 4; ++i) {
      var e = edges[i], hz = e[1], span = (hz ? W : H) - 2 * c; if (span <= 0) continue;
      var lays = ["over", "rim"]; if (v === "b") lays.push("dirt");
      for (j = 0; j < lays.length; ++j) {
         var im = I[e[0] + "/" + lays[j]], md = D.pieces[e[0]][lays[j]]; if (!im || !md) continue;
         var dep = Math.max(1, Math.round((hz ? md.h : md.w) * f)), nr = Math.round((md.n || 0) * f), x0 = hz ? c : (e[0] === "e_left" ? nr : W - nr - dep), y0 = hz ? (e[0] === "e_top" ? nr : H - nr - dep) : c;
         if (lays[j] !== "dirt") { X[lays[j]].drawImage(im, x0, y0, hz ? span : dep, hz ? dep : span); continue; }
         for (var o = 0; o < span; o += tl) {
            var n = Math.min(tl, span - o), sl = (hz ? md.w : md.h) * n / tl;
            if (hz) X.dirt.drawImage(im, 0, 0, sl, md.h, x0 + o, y0, n, dep); else X.dirt.drawImage(im, 0, 0, md.w, sl, x0, y0 + o, dep, n);
         }
      }
   }
   var over = X.over.getImageData(0, 0, W, H), r = X.rim.getImageData(0, 0, W, H).data, d = X.dirt.getImageData(0, 0, W, H).data;
   var lt = new Uint8Array(4 * W * H), sw = 0, sc = [0, 0, 0];
   for (i = 0; i < W * H; ++i) {
      var a = r[4 * i + 3]; lt[4 * i] = a; lt[4 * i + 1] = d[4 * i + 3]; lt[4 * i + 3] = 255;
      if (a > 8) { sw += a; sc[0] += a * r[4 * i]; sc[1] += a * r[4 * i + 1]; sc[2] += a * r[4 * i + 2]; }
   }
   return { over: over, light: lt, rimCol: sw > 0 ? [sc[0] / sw / 255, sc[1] / sw / 255, sc[2] / sw / 255] : [0.8, 0.6, 0.3] };
}
function fwFgShader() {
   var s = FW_SH_FINAL_F.replace("uniform vec3 uFlashCol;", "uniform vec3 uFlashCol; uniform sampler2D uFgOver, uFgLight; uniform float uFgRim, uFgDirt, uFgLocK, uFgPhK, uFgIn; uniform vec3 uFgRimCol;");
   return s.replace("  oC = vec4(clamp(col, 0.0, 1.0), 1.0);",
      "  { vec2 fq = vec2(q.x, 1.0 - q.y); vec4 fo = texture(uFgOver, fq); vec2 fl = texture(uFgLight, fq).rg;\n" +
      "    if (fo.a + fl.r + fl.g > 0.0) { vec3 lw = vec3(0.2126, 0.7152, 0.0722); vec2 tc = vec2(0.5) - q; float loc = max(dot(texture(uBloom, q + tc * uFgIn).rgb, lw), max(dot(texture(uBloom, q + tc * (2.0 * uFgIn)).rgb, lw), dot(texture(uBloom, q + tc * (3.5 * uFgIn)).rgb, lw))), aL = dot(texture(uAvg, vec2(0.5)).rgb, lw);\n" +
      "      float lr = clamp(uFgRim + uFgPhK * aL + uFgLocK * loc, 0.0, 1.0), ld = clamp(uFgDirt + uFgLocK * loc, 0.0, 1.0);\n" +
      "      col = mix(col, fo.rgb, fo.a) + uFgRimCol * fl.r * lr + vec3(fl.g * ld); } }\n" +
      "  oC = vec4(clamp(col, 0.0, 1.0), 1.0);");
}
// el material del pase final con la ventana (o el de siempre si no toca o aun no esta listo). Gancho de una linea en render()
FWRenderer.prototype.fgFinal = function(fx) {
   this.fgInfo = null;
   var v = fwFgVariant(), recOn = typeof FW !== "undefined" && FW.rec && FW.rec.on;
   if (!FW_FG.ON || v === "off" || (recOn && !FW_FG.REC_PHOTO_ONLY)) return this.finalMat;
   var T = THREE, W = this.W, H = this.H, lv = fwFgLevel(W / 1280);
   if (!fwFgReadyLv(lv)) return this.finalMat;
   var key = W + "x" + H + ":" + v + ":" + lv;
   if (this.fgKey !== key) {
      var t0 = performance.now(), C = fwFgCompose(lv, W, H, v);
      var dt = function(arr) { var t = new T.DataTexture(arr, W, H, T.RGBAFormat, T.UnsignedByteType); t.minFilter = T.LinearFilter; t.magFilter = T.LinearFilter; t.generateMipmaps = false; t.flipY = false; t.wrapS = t.wrapT = T.ClampToEdgeWrapping; t.needsUpdate = true; return t; };
      if (this.fgTex) { this.fgTex.over.dispose(); this.fgTex.light.dispose(); }
      this.fgTex = { over: dt(new Uint8Array(C.over.data.buffer)), light: dt(C.light) };
      if (!this.fgMat) {
         this.uFg = { uFgOver: { value: null }, uFgLight: { value: null }, uFgRim: { value: 0 }, uFgDirt: { value: 0 }, uFgLocK: { value: FW_FG.LOC_K }, uFgPhK: { value: FW_FG.RIM_PHOTO }, uFgIn: { value: FW_FG.LOC_IN }, uFgRimCol: { value: new T.Vector3(0.8, 0.6, 0.3) } };
         this.fgMat = new T.RawShaderMaterial({ vertexShader: FW_SH_QUAD_V, fragmentShader: fwFgShader(), uniforms: Object.assign({}, this.uFinal, this.uFg), glslVersion: T.GLSL3, depthTest: false, depthWrite: false });
      }
      this.uFg.uFgOver.value = this.fgTex.over; this.uFg.uFgLight.value = this.fgTex.light; this.uFg.uFgRimCol.value.set(C.rimCol[0], C.rimCol[1], C.rimCol[2]);
      this.fgKey = key; this.fgBuildMs = performance.now() - t0;
   }
   var w = fx ? (fx.warp || 0) : 0, fl = fx ? (fx.flash || 0) : 0, ws = fvSmooth((w - 0.05) / 0.6), U = this.uFg;
   U.uFgRim.value = FW_FG.RIM_BASE + FW_FG.RIM_WARP * ws + FW_FG.RIM_FLASH * fl; U.uFgDirt.value = FW_FG.DIRT_WARP * ws;
   U.uFgLocK.value = FW_FG.LOC_K; U.uFgPhK.value = FW_FG.RIM_PHOTO; U.uFgIn.value = FW_FG.LOC_IN;
   this.fgInfo = { v: v, lv: lv, rim: U.uFgRim.value, dirt: U.uFgDirt.value, buildMs: this.fgBuildMs };
   return this.fgMat;
};

// ---------------------------------------------------------------------------
// (nP, PROFUNDITAS) LA INCLINACION DE LAS CAPAS (contrato scene.nebula.tilt = [X, Y] grados alrededor de [0, 0, distLy], X y luego Y; la
// misma ley que fvNavTiltPt / fwNavTiltPt y que el pintor de PixInsight, src/ui/fv_painter.js fvPaintTiltPt). FW_GL.TILT_ON false = ROJO
function fwTiltPt(p, D, t) { if (!t || (!t[0] && !t[1])) return p.slice(); var q = [p[0], p[1], p[2] - D]; q = fvRotate(q, [1, 0, 0], t[0] * FV_DEG); q = fvRotate(q, [0, 1, 0], t[1] * FV_DEG); return [q[0], q[1], q[2] + D]; }
function fwTiltInv(p, D, t) { var q = [p[0], p[1], p[2] - D]; q = fvRotate(q, [0, 1, 0], -t[1] * FV_DEG); q = fvRotate(q, [1, 0, 0], -t[0] * FV_DEG); return [q[0], q[1], q[2] + D]; }
function fwTiltOf(scene) {
   var N = scene && scene.nebula, t = N && N.tilt;
   if (FW_GL.TILT_ON === false || !t || (!(Math.abs(t[0]) > 1e-9) && !(Math.abs(t[1]) > 1e-9))) return null;
   return { t: t, D: N.distLy, n: fvNorm(fwTiltPt([0, 0, 1], 0, t)) };   // la normal sale de tilt (scene.nebula.normal puede venir sin actualizar)
}
// el punto (wx, wy) de la capa L en su plano inclinado: el rayo desde la Tierra cortado con el plano (desde casa, la foto exacta)
function fwTiltPlanePt(L, wx, wy, T) {
   if (!T) return [wx, wy, L.z];
   var c = fwTiltPt([0, 0, L.z], T.D, T.t), dx = wx / L.z, dy = wy / L.z, den = T.n[0] * dx + T.n[1] * dy + T.n[2], sN = (T.n[0] * c[0] + T.n[1] * c[1] + T.n[2] * c[2]) / (Math.abs(den) > 1e-12 ? den : 1e-12);
   return [sN * dx, sN * dy, sN];
}
function FWRenderer(canvas, scene, imgs) {
   var T = THREE, self = this;
   this.canvas = canvas; this.scene = scene; this.imgs = imgs || {};
   this.r = new T.WebGLRenderer({ canvas: canvas, antialias: false, alpha: false, depth: false, stencil: false, powerPreference: "high-performance", preserveDrawingBuffer: false });
   this.gl = this.r.getContext();
   this.webgl2 = !!this.r.capabilities.isWebGL2;
   this.r.autoClear = false;
   this.r.setClearColor(0x000000, 1);
   this.cam = new T.OrthographicCamera(-1, 1, 1, -1, 0, 1);
   this.quad = new T.Mesh(new T.PlaneGeometry(2, 2), null); this.quad.frustumCulled = false;
   this.qScene = new T.Scene(); this.qScene.add(this.quad);
   this.frame = 0;
   // (RUTA, D2, 4-nov) edge 0,30 -> 0,17: la media luz del borde a ~0,12 del ancho, la misma franja que el pintor de PixInsight (FV_PAINT
   // EDGE_SOFT/WOB 0,10/0,07) y que supone el piloto (FV_PILOT.ROUTE.EDGE_FALLBACK). ROJO: setOpt({ edge: 0.30 }) (y edgeOld, la formula de antes)
   this.opt = { volume: true, layers: false, steps: 64, bloomK: 0.22, bloomThr: 0.95, vig: 0.22, grain: 0.012, aberr: 0, gain: 1, halo: 0.05, maxSat: 3.2, volHalf: true, volScale: 0.5, sheet: true, dust: true, secMax: 2.5, edge: 0.17, wob: 1.4, mirror: false, knee: 0.8 };
   this.info = { renderer: "", volume: "not built", layers: 0, stars: 0 };
   try { var dbg = this.gl.getExtension("WEBGL_debug_renderer_info"); this.info.renderer = dbg ? String(this.gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)) : String(this.gl.getParameter(this.gl.RENDERER)); } catch (e) {}
   // (W4, 5-nov) ¿que GPU pinta? En el portatil de Nino Chrome usa por defecto la Intel integrada (medido: 5120 x 2160 a 7-20 fps; con la RTX 5080, 60-120).
   // La pagina no puede elegir la GPU (powerPreference no basta en Windows): lo decide Windows por programa. info.gpuClass para avisar: "software" |
   // "integrated" | "discrete" | "unknown"
   this.info.gpuClass = fwGpuClass(this.info.renderer);
   function mat(vs, fs, uni, extra) { var m = new T.RawShaderMaterial(Object.assign({ vertexShader: vs, fragmentShader: fs, uniforms: uni, glslVersion: T.GLSL3, depthTest: false, depthWrite: false }, extra || {})); return m; }
   this.mat = mat;
   // ---- estrellas: cuadrilateros instanciados ----
   var S = scene.stars, n = S.n;
   var g = new T.InstancedBufferGeometry();
   g.setAttribute("position", new T.BufferAttribute(new Float32Array([-1, -1, 1, -1, 1, 1, -1, 1]), 2));
   g.setIndex([0, 1, 2, 0, 2, 3]);
   this.rel = new Float32Array(3 * n);
   this.aRel = new T.InstancedBufferAttribute(this.rel, 3); this.aRel.setUsage(T.DynamicDrawUsage);
   var col = new Float32Array(3 * n), mg = new Float32Array(2 * n);
   // (nF2, E3) SOLO LA HUELLA DE LA FOTO (la misma regla que FV_PAINT.PRINT_ONLY del pintor de PixInsight, con FV_PILOT.PRINT_ONLY): las
   // estrellas cuya direccion desde la Tierra cae fuera del rectangulo de la foto no se pintan (paquetes viejos con el cielo de alrededor;
   // los nuevos ya no las traen), y en la franja suave del 3 % se apagan con su peso
   var printOn = (typeof fvPrintW === "function") && (typeof FV_PILOT !== "undefined") && FV_PILOT.PRINT_ONLY === true, nHid = 0, nEdge = 0;
   for (var i = 0; i < n; ++i) {
      var c = scene.starRgb ? scene.starRgb[i] : fwHexToRgb(S.col[i]), mx = Math.max(c[0], c[1], c[2], 1e-3);
      col[3 * i] = c[0] / mx; col[3 * i + 1] = c[1] / mx; col[3 * i + 2] = c[2] / mx;
      mg[2 * i] = S.g[i]; mg[2 * i + 1] = S.dEarth[i];
      // (nP-2) con la franja hacia dentro (FV_PRINT_IN) las que caen a pocos pixeles del borde se apagan sin estar fuera: printHid cuenta
      // solo las de FUERA del rectangulo (lo que mide nF2); las apagadas en el borde, printEdge
      if (printOn) { var pw = fvPrintW(scene, i, 0.03); if (pw <= 0.01) { mg[2 * i] = 99; var uvH = (typeof fvPrintUV === "function") ? fvPrintUV(scene, i) : [2, 2]; if (Math.max(uvH[0], uvH[1]) >= 1) ++nHid; else ++nEdge; } else if (pw < 0.999) mg[2 * i] = S.g[i] - 2.5 * Math.log(pw) / Math.LN10; }
   }
   this.info.printHid = nHid; this.info.printEdge = nEdge;
   // (nP-2) coordenadas de cada estrella en la foto (|u|, |v| por eje, 1 = el borde) para apagarlas con el borde, y los pesos de la huella
   var uvA = new Float32Array(2 * n); this.uvArr = uvA; this.printWArr = printOn ? new Float32Array(n) : null;
   for (i = 0; i < n; ++i) { var uv = (typeof fvPrintUV === "function") ? fvPrintUV(scene, i) : [0, 0]; uvA[2 * i] = uv[0]; uvA[2 * i + 1] = uv[1]; if (printOn) this.printWArr[i] = fvPrintW(scene, i, 0.03); }
   this.colBase = col.slice(); this.magBase = mg.slice();
   this.aCol = new T.InstancedBufferAttribute(col, 3); this.aMag = new T.InstancedBufferAttribute(mg, 2);
   // (N, D) el color SIN polvo (F4b, colTrue): junto a la estrella se ve el verdadero; desde la Tierra, el de la foto (mezcla por la fraccion
   // del camino que queda entre camara y estrella: el polvo se supone repartido a lo largo de la visual)
   var colT = new Float32Array(3 * n), nT = 0;
   for (i = 0; i < n; ++i) {
      if (S.colTrue && S.colTrue[i] && S.colTrue[i] !== S.col[i]) { var ct = fwHexToRgb(S.colTrue[i]), mt = Math.max(ct[0], ct[1], ct[2], 1e-3); colT[3 * i] = ct[0] / mt; colT[3 * i + 1] = ct[1] / mt; colT[3 * i + 2] = ct[2] / mt; ++nT; }
      else { colT[3 * i] = col[3 * i]; colT[3 * i + 1] = col[3 * i + 1]; colT[3 * i + 2] = col[3 * i + 2]; }
   }
   this.aColT = new T.InstancedBufferAttribute(colT, 3); this.info.trueColour = nT;
   // (F3c) aInfo = [supuesta, radio del tubo (fraccion de su distancia), del cono (mas debil que el cielo completo)]: las reglas del cono
   var Fc = scene.facts || {}, coneGc = Fc.coneGc > 0 ? Fc.coneGc : FW_GL.CONE_GC, wideG = Fc.wideMag > 0 ? Fc.wideMag : coneGc - 2, ringG = Fc.ringMag || FW_GL.RING_MAG;
   var coneDeg = Fc.coneDeg > 0 ? Fc.coneDeg : Math.atan(0.5 * Math.sqrt(scene.field.width * scene.field.width + scene.field.height * scene.field.height) / scene.field.F) * 180 / Math.PI;
   var nearPhoto = FW_GL.CONE_TUBE * Math.tan(coneDeg * Math.PI / 180), nearRing = (Fc.ringDeg > 0 && Fc.nRing > 0) ? FW_GL.CONE_TUBE * Math.tan(Fc.ringDeg * Math.PI / 180) : nearPhoto;
   var inf = new Float32Array(3 * n);
   for (i = 0; i < n; ++i) { var gi = S.g[i]; inf[3 * i] = S.q[i] === 2 ? 1 : 0; inf[3 * i + 1] = (S.inFrame[i] && gi > ringG) ? nearPhoto : nearRing; inf[3 * i + 2] = gi > wideG ? 1 : 0; }
   this.cone = { coneGc: coneGc, wideG: wideG, ringG: ringG, coneDeg: coneDeg, nearPhoto: nearPhoto, nearRing: nearRing, fromScene: !!scene.facts };
   this.aInfo = new T.InstancedBufferAttribute(inf, 3); this.infBase = inf.slice();
   g.setAttribute("aRel", this.aRel); g.setAttribute("aCol", this.aCol); g.setAttribute("aColT", this.aColT); g.setAttribute("aMag", this.aMag); g.setAttribute("aInfo", this.aInfo); g.setAttribute("aUv", new T.InstancedBufferAttribute(uvA, 2));
   // (5-nov) STELLAE: el recorte de cada estrella en el atlas (setStarLook lo rellena; ceros = sin recorte)
   this.aSpr = new T.InstancedBufferAttribute(new Float32Array(4 * n), 4); this.aSprC = new T.InstancedBufferAttribute(new Float32Array(2 * n), 2);
   var hr0 = new Float32Array(4 * n); for (var ih = 0; ih < n; ++ih) hr0[4 * ih + 3] = -1; this.aHr = new T.InstancedBufferAttribute(hr0, 4); g.setAttribute("aHr", this.aHr);   // (I2, 19-nov) el diagrama HR: lo rellena fw_hr.js (−1 = no va)
   g.setAttribute("aSpr", this.aSpr); g.setAttribute("aSprC", this.aSprC);
   this.colTBase = colT.slice(); this.hasTrue = new Uint8Array(n); for (i = 0; i < n; ++i) this.hasTrue[i] = (S.colTrue && S.colTrue[i] && S.colTrue[i] !== S.col[i]) ? 1 : 0;
   // (B1, 5-nov) STELLAE «GAIA» = el color de la TEMPERATURA (S.colG) y, junto a la estrella, el de la temperatura sin polvo (S.colGT); COLOR y FOTO
   // usan colBase/colTBase (el de la foto, verde recortado: el «GAIA» de antes). Sin S.colG (paquete viejo) todo como antes
   this.colGBase = null; this.colGTBase = null;
   if (S.colG && S.colGT) {
      var cG = new Float32Array(3 * n), cGT = new Float32Array(3 * n);
      for (i = 0; i < n; ++i) {
         var qg = fwHexToRgb(S.colG[i]), mg2 = Math.max(qg[0], qg[1], qg[2], 1e-3), qt = fwHexToRgb(S.colGT[i]), mt2 = Math.max(qt[0], qt[1], qt[2], 1e-3);
         cG[3 * i] = qg[0] / mg2; cG[3 * i + 1] = qg[1] / mg2; cG[3 * i + 2] = qg[2] / mg2; cGT[3 * i] = qt[0] / mt2; cGT[3 * i + 1] = qt[1] / mt2; cGT[3 * i + 2] = qt[2] / mt2;
      }
      this.colGBase = cG; this.colGTBase = cGT;
   }
   this.look = "gaia";
   g.instanceCount = n; g.boundingSphere = new T.Sphere(new T.Vector3(), 1e30);
   this.uStar = { uR: { value: new T.Vector3() }, uD: { value: new T.Vector3() }, uF: { value: new T.Vector3() }, uTrail: { value: new T.Vector3() }, uSplitN: { value: new T.Vector3() },
                  uTanH: { value: 1 }, uTanV: { value: 1 }, uMagLim: { value: 19.6 }, uSatMag: { value: 10.5 }, uFloor: { value: 0.22 }, uSigma0: { value: 0.75 }, uPass: { value: 0 }, uSplitD: { value: 0 },
                  uRes: { value: new T.Vector2(1, 1) }, uGain: { value: 1 }, uHalo: { value: 0.05 }, uMaxSat: { value: 3.2 },
                  uAway: { value: 0 }, uCamW: { value: new T.Vector3() }, uByView: { value: 1 }, uTanHd: { value: 1 }, uConeTube: { value: FW_GL.CONE_TUBE }, uTubeSoft: { value: FW_GL.TUBE_SOFT }, uStreakV2: { value: 1 }, uStreakGain: { value: FW_GL.STREAK_GAIN }, uStreakTail: { value: FW_GL.STREAK_TAIL }, uStreakW: { value: FW_GL.STREAK_W }, uFlashS: { value: 0 }, uStreakLit: { value: FW_GL.STREAK_LIT }, uDmAss: { value: FW_GL.ASSUMED_DM }, uConeGc: { value: coneGc }, uConeDm: { value: FW_GL.CONE_DM }, uConeSoft: { value: FW_GL.CONE_SOFT },
                  uHero: { value: -1 }, uHeroCol: { value: new T.Vector3(1, 1, 1) }, uHeroK: { value: 0 }, uHeroPi: { value: 1 }, uHeroRpx: { value: 0 }, uHeroW: { value: 0 }, uHeroSoft: { value: 0 }, uVp: { value: new T.Vector2(0, 0) }, uRadial: { value: 0 }, uTrueOn: { value: 1 }, uDop: { value: 0 }, uHole: { value: 0 }, uHoleR0: { value: 0.02 }, uHoleR1: { value: 0.16 }, uHolePow: { value: 1 },
                  uFadeOn: { value: 1 }, uFadeLo: { value: 19.6 }, uFadeW: { value: 1 }, uAMin: { value: 1 / 32 }, uEdgeK: { value: 0 }, uEbx: { value: 0.544 }, uEby: { value: 0.544 }, uBudK: { value: 1 },
                  uPsOn: { value: 0 }, uPsHome: { value: 1 }, uPsMagLo: { value: 2 }, uPsMagHi: { value: 3 }, uPsTrailK: { value: 0 }, uPsScaleMin: { value: 0.25 }, uPsSigCap: { value: 4 }, uMagLimH: { value: 19.6 }, uSatMagH: { value: 10.5 },
                  uPsTex: { value: null }, uPsAtlas: { value: new T.Vector2(1, 1) },
                  uSS: { value: 1 }, uSideOn: { value: 0 }, uSideLo: { value: 0.12 }, uSideHi: { value: 0.3 },     // (NV-13) espacio de vuelo
                  // (I2, 19-nov) el diagrama HR (los pone fwHrPre de fw_hr.js antes de cada fotograma; uHrK 0 = nada)
                  uHrK: { value: 0 }, uHrA: { value: 0 }, uHrStag: { value: 0.5 }, uHrArc: { value: 0.1 }, uHrDim: { value: 0.16 }, uHrSig: { value: 2.64 }, uHrFloor: { value: 0.56 }, uHrRest: { value: 1 },
                  uHrO: { value: new T.Vector2(0, 0) }, uHrS: { value: new T.Vector2(1, 1) } };
   // (11-nov, NV-13) TRES BASES DE CAMARA. Sin laboratorio son la misma (la de siempre) y nada cambia. Con el laboratorio (base cam.B y S):
   //   uStar.uR/uD/uF  PROYECTAR puntos (estrellas, capas, objetos): la base con x, y × S  -> (S·x, S·y, z)·r, como fvLabProjector
   //   uRay            RAYOS por pixel (volumen, foto como plano): la direccion REAL del rayo de vuelo f + x·r − y·d es (·/S, ·/S, ·): base con x, y / S
   //   uSky            el CIELO de fondo (Via Lactea simulada) en direcciones reales = las de pantalla (fvLabSkyPr: la base de vuelo sin S)
   this.uRay = { uR: { value: new T.Vector3() }, uD: { value: new T.Vector3() }, uF: { value: new T.Vector3() } };
   this.uSky = { uR: { value: new T.Vector3() }, uD: { value: new T.Vector3() }, uF: { value: new T.Vector3() } };
   this.starMat = mat(FW_SH_STAR_V, FW_SH_STAR_F, this.uStar, { blending: T.AdditiveBlending, transparent: true });
   this.stars = new T.Mesh(g, this.starMat); this.stars.frustumCulled = false;
   this.sScene = new T.Scene(); this.sScene.add(this.stars);
   this.info.stars = n;
   // ---- texturas de la nebulosa ----
   // (nA2, E1) cada textura: ajustada al limite de la GPU (fwFitTex), con mipmaps y con el filtrado anisotropico maximo de la GPU (las que se
   // muestrean con textureLod, como la de detalle del volumen, no lo usan: el LOD lo elige el sombreador)
   this.maxTex = self.r.capabilities.maxTextureSize; this.maxAniso = self.r.capabilities.getMaxAnisotropy();
   // (pruebas) ?maxtex=N simula una GPU de menos MAX_TEXTURE_SIZE; ?noaniso=1 · ?nomax=1 · ?norest=1 son los CONTROLES EN ROJO de ANISO, MAX_TEX y REST_FULL
   try { var qs = String(location.search || ""), mq = /[?&]maxtex=(\d+)/.exec(qs); if (mq) this.maxTex = Math.min(this.maxTex, +mq[1]);
         if (/[?&]noaniso=1/.test(qs)) FW_GL.ANISO = false; if (/[?&]nomax=1/.test(qs)) FW_GL.MAX_TEX = false; if (/[?&]norest=1/.test(qs)) FW_GL.REST_FULL = false; } catch (eQ) {}
   function tex(img0, mip) { var img = FW_GL.MAX_TEX === false ? img0 : fwFitTex(img0, self.maxTex), t = new T.Texture(img); t.anisotropy = (FW_GL.ANISO === false) ? 1 : self.maxAniso; t.flipY = false; t.generateMipmaps = !!mip; t.minFilter = mip ? T.LinearMipmapLinearFilter : T.LinearFilter; t.magFilter = T.LinearFilter; t.wrapS = t.wrapT = T.ClampToEdgeWrapping; t.needsUpdate = true; return t; }
   this.texDet = imgs.starless ? tex(imgs.starless, true) : null;
   // capas (reserva)
   this.layerScene = new T.Scene(); this.layerMeshes = [];
   var N = scene.nebula;
   this.uLayer = { uR: this.uStar.uR, uD: this.uStar.uD, uF: this.uStar.uF, uTanH: this.uStar.uTanH, uTanV: this.uStar.uTanV };
   if (N && N.layers) for (var k = 0; k < N.layers.length; ++k) {
      var im = imgs["layer" + k]; if (!im) continue;
      var lg = new T.BufferGeometry(), pos = new Float32Array(12);
      lg.setAttribute("position", new T.BufferAttribute(pos, 3).setUsage(T.DynamicDrawUsage));
      lg.setAttribute("uv", new T.BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), 2));
      lg.setIndex([0, 1, 2, 0, 2, 3]);
      var lm = mat(FW_SH_LAYER_V, FW_SH_LAYER_F, Object.assign({ uTex: { value: tex(im, true) }, uGain: { value: 1 }, uMirror: { value: 0 } }, this.uLayer), { blending: T.AdditiveBlending, transparent: true, side: T.DoubleSide });
      var me = new T.Mesh(lg, lm); me.frustumCulled = false; me.userData = N.layers[k];
      this.layerScene.add(me); this.layerMeshes.push(me);
   }
   this.info.layers = this.layerMeshes.length;
   // volumen v2 (F3b): relieve calculado aqui de la foto sin estrellas (fw_relief.js) -> dos texturas 2D de media coma flotante.
   // (El atlas 3D de F3, si el paquete aun lo trae, ya no se usa.)
   // (N13) CARGA SIN CONGELAR: el relieve ya NO se calcula aqui (210–240 ms de hilo bloqueado, mas 50 de medias coma flotante): lo hace
   // prepareNebula() en un Worker (fwReliefRun) despues de quitar los objetos compactos de la foto (N8). Mientras, se pinta con las capas.
   this.vol = null;
   this.canRelief = !!(N && imgs.starless && this.webgl2 && typeof fwReliefBuild === "function");
   this.info.volume = this.canRelief ? "pending" : "not built (" + (!imgs.starless ? "no starless image" : (!this.webgl2 ? "no WebGL2" : "no fw_relief.js")) + ")";
   this.opt.volume = false; this.opt.layers = true;
   var vw = this.vol ? this.vol : { rel: null, she: null, body: null }, SH = typeof FW_RELIEF !== "undefined" ? FW_RELIEF.SHEETS : [{}, {}, {}];
   this.uVol = { uDet: { value: this.texDet }, uRel: { value: vw.rel }, uShe: { value: vw.she }, uBody: { value: vw.body }, uKB: { value: typeof FW_RELIEF !== "undefined" ? FW_RELIEF.KB : 0.4 },
                 uWt: { value: new T.Vector3(SH[0].wt || 0.5, SH[1].wt || 0.3, SH[2].wt || 0.2) }, uMul: { value: new T.Vector3(SH[0].mul || 1, SH[1].mul || 1.6, SH[2].mul || 2.2) }, uWob: { value: 1.1 }, uCam: { value: new T.Vector3() }, uR: this.uRay.uR, uD: this.uRay.uD, uF: this.uRay.uF, uTanH: this.uStar.uTanH, uTanV: this.uStar.uTanV,
                 uZ0: { value: N ? N.distLy - N.thickLy / 2 : 1 }, uZ1: { value: N ? N.distLy + N.thickLy / 2 : 2 },
                 uKx: { value: scene.field.F / scene.field.width }, uKy: { value: scene.field.F / scene.field.height }, uSteps: { value: 64 }, uFrame: { value: 0 },
                 uTN: { value: new T.Vector3(0, 0, 1) }, uTC: { value: new T.Vector3(0, 0, N ? N.distLy : 1) }, uTiltOn: { value: 0 }, uTPad: { value: 0 },
                 uMirror: { value: 0 }, uGain: { value: 1 }, uTexW: { value: imgs.starless ? imgs.starless.width : 2048 }, uPixAng: { value: 0.001 },
                 uSecMax: { value: 4 }, uEdge: { value: 0.09 }, uSheet: { value: 1 }, uDust: { value: 1 }, uOffHome: { value: 0 }, uEdgeOld: { value: 0 }, uEdgeRamp: { value: 1 }, uBudget: { value: 1 }, uBudgetK: { value: 160 }, uEdgeShow: { value: 1 },
                 uN2c: { value: 0 }, uN2cDB: { value: 0.28 }, uN2cSky: { value: 1 }, uN2cCont: { value: 0 }, uN2cA: { value: new T.Vector2(1, 1) }, uN2cPed: { value: new T.Vector3(0, 0, 0) } };
   this.volMat = mat(FW_SH_QUAD_V, FW_SH_VOL_F, this.uVol);
   this.uComp = { uFar: { value: null }, uVol: { value: null }, uVolOn: { value: 0 }, uLocal: { value: 0 }, uRad: { value: 5 }, uVolTexel: { value: new T.Vector2(1, 1) },
                 uFogTex: { value: null }, uFogK: { value: 0 }, uFogLodB: { value: 5 }, uFogLodD: { value: 1 }, uFogGam: { value: 1.7 }, uFogMix: { value: 0.65 }, uFogMirror: { value: 0 },
                 uFogC: { value: new T.Vector2(0.5, 0.5) }, uFogS: { value: new T.Vector2(0.3, 0.3) }, uFogPed: { value: new T.Vector3(0, 0, 0) },
                 // (W3) la foto como plano: los uniformes del volumen y de las estrellas, compartidos (mismos objetos)
                 uDet: this.uVol.uDet, uR: this.uRay.uR, uD: this.uRay.uD, uF: this.uRay.uF, uCam: this.uVol.uCam, uTanH: this.uStar.uTanH, uTanV: this.uStar.uTanV,
                 uKx: this.uVol.uKx, uKy: this.uVol.uKy, uMirror: this.uVol.uMirror, uGain: this.uVol.uGain, uPhK: { value: 0 }, uPhDist: { value: N ? N.distLy : 1 }, uPhBias: { value: 0 }, uNebK: { value: 1 }, uVeil: { value: new T.Vector3(0, 0, 0) } };
   this.compMat = mat(FW_SH_QUAD_V, FW_SH_COMP_F, this.uComp);
   this.brightMat = mat(FW_SH_QUAD_V, FW_SH_BRIGHT_F, { uTex: { value: null }, uTexel: { value: new T.Vector2() }, uThr: { value: 1 } });
   this.downMat = mat(FW_SH_QUAD_V, FW_SH_DOWN_F, { uTex: { value: null }, uTexel: { value: new T.Vector2() } });
   this.upMat = mat(FW_SH_QUAD_V, FW_SH_UP_F, { uTex: { value: null }, uBase: { value: null }, uTexel: { value: new T.Vector2() } });
   this.uFinal = { uMain: { value: null }, uBloom: { value: null }, uBloomK: { value: 0.2 }, uFlash: { value: 0 }, uAberr: { value: 0 }, uVig: { value: 0.2 }, uGrain: { value: 0.01 }, uFrame: { value: 0 }, uRes: { value: new T.Vector2(1, 1) }, uKnee: { value: 0.8 },
                   uAvg: { value: null }, uExpTarget: { value: FW_GL.EXP_TARGET }, uExpMin: { value: FW_GL.EXP_MIN }, uExpOn: { value: 1 },
                   uZoom: { value: 0 }, uTunnel: { value: 0 }, uTime: { value: 0 }, uVpUv: { value: new T.Vector2(0.5, 0.5) }, uFlashCol: { value: new T.Vector3(1.0, 0.97, 0.9) }, uFlashR: { value: 0.05 }, uFlashRad: { value: 1 }, uSpikeW: { value: 0.004 }, uSpikeL: { value: 0.45 }, uFlashGain: { value: 2.2 }, uSpikeK: { value: 1 }, uFlashHalo: { value: 0.35 } };
   this.finalMat = mat(FW_SH_QUAD_V, FW_SH_FINAL_F, this.uFinal);
   // (F3c) la Via Lactea simulada (si el paquete trae el marco galactico y el motor de F4b)
   this.mw = null;
   var GF = scene.galaxy;
   if (GF && GF.ex && typeof fvMwMap === "function" && typeof FV_MW !== "undefined") {
      try {
         var m0 = fvMwMap(GF, [0, 0, 0]), ref = fvMwRef(m0), NL = FV_MW.NL, NB = FV_MW.NB;
         var mt = new T.DataTexture(new Uint16Array(4 * NL * NB), NL, NB, T.RGBAFormat, T.HalfFloatType);
         mt.minFilter = T.LinearFilter; mt.magFilter = T.LinearFilter; mt.wrapS = T.RepeatWrapping; mt.wrapT = T.ClampToEdgeWrapping; mt.generateMipmaps = false; mt.flipY = false;
         this.mw = { frame: GF, ref: ref, tex: mt, at: null, remaps: 0, ms: 0 };
         this.mwFill(m0, [0, 0, 0]);
         var cd = FV_MW.COL_DISC, cb = FV_MW.COL_BULGE;
         this.uMw = { uMap: { value: mt }, uR: this.uSky.uR, uD: this.uSky.uD, uF: this.uSky.uF, uTanH: this.uStar.uTanH, uTanV: this.uStar.uTanV,
                      uEx: { value: new T.Vector3(GF.ex[0], GF.ex[1], GF.ex[2]) }, uEy: { value: new T.Vector3(GF.ey[0], GF.ey[1], GF.ey[2]) }, uEz: { value: new T.Vector3(GF.ez[0], GF.ez[1], GF.ez[2]) },
                      uCD: { value: new T.Vector3(cd[0] / 255, cd[1] / 255, cd[2] / 255) }, uCB: { value: new T.Vector3(cb[0] / 255, cb[1] / 255, cb[2] / 255) }, uK: { value: 0 }, uNL: { value: NL }, uGrainK: { value: 1 } };
         this.mwMat = mat(FW_SH_QUAD_V, FW_SH_MW_F, this.uMw);
         this.info.milkyway = "simulated (F4b model), ref " + ref.toPrecision(3);
      } catch (eM) { this.mw = null; this.info.milkyway = "FAILED: " + eM; }
   } else this.info.milkyway = "none (" + (!GF ? "no galactic frame in the package" : "no fv_milkyway.js") + ")";
   this.rt = null; this.W = 0; this.H = 0;
   // (N8) los objetos compactos: las mallas se arman en buildObjects (cuando ya hay recortes)
   this.objScene = new T.Scene(); this.objs = [];
}

// ---------------------------------------------------------------------------
// (N13) EL RELIEVE EN UN WORKER. file:// no deja cargar un Worker de un fichero, pero si de un Blob: el codigo es el de fw_relief.js
// (sus cuatro funciones y FW_RELIEF, por toString) mas la conversion a media coma flotante. Si el navegador no lo deja, se calcula en el
// hilo principal (como en F3c). -> cb({ w, h, rel, she, body (Uint16Array, medias), ms, worker })
// ---------------------------------------------------------------------------
function fwHalfSrc() {
   return "function fwHalf(){var b=new Float32Array(1),i=new Int32Array(b.buffer);return function(v){b[0]=v;var x=i[0],s=(x>>>16)&0x8000,m=(x>>>12)&0x07ff,e=(x>>>23)&0xff;if(e<103)return s;if(e>142){s|=0x7c00;s|=((e==255)?0:1)&&(x&0x007fffff);return s;}if(e<113){m|=0x0800;s|=(m>>(114-e))+((m>>(113-e))&1);return s;}s|=((e-112)<<10)|(m>>1);s+=m&1;return s;};}" +
          "function fwHalfArr(a){var h=fwHalf(),u=new Uint16Array(a.length);for(var k=0;k<a.length;++k)u[k]=h(a[k]);return u;}";
}
function fwReliefRun(rgba, w, h, cb) {
   var src = "var FW_RELIEF = " + JSON.stringify(FW_RELIEF) + ";\n" + fwrClamp.toString() + "\n" + fwrBlur.toString() + "\n" + fwrRank.toString() + "\n" + fwReliefBuild.toString() + "\n" + fwHalfSrc() +
             "\nonmessage = function(e) { var d = e.data, R = fwReliefBuild(new Uint8ClampedArray(d.buf), d.w, d.h); var o = { w: R.w, h: R.h, ms: R.ms, rel: fwHalfArr(R.rel), she: fwHalfArr(R.sheets), body: fwHalfArr(R.body) }; postMessage(o, [o.rel.buffer, o.she.buffer, o.body.buffer]); };";
   var done = false;
   function main() {
      if (done) return; done = true;
      var t0 = performance.now(), R = fwReliefBuild(rgba, w, h), H = THREE.DataUtils.toHalfFloat;
      function half(f) { var u = new Uint16Array(f.length); for (var i = 0; i < f.length; ++i) u[i] = H(f[i]); return u; }
      cb({ w: R.w, h: R.h, ms: Math.round(performance.now() - t0), rel: half(R.rel), she: half(R.sheets), body: half(R.body), worker: false });
   }
   if (FW_GL.NO_WORKER) { setTimeout(main, 0); return; }
   try {
      var url = URL.createObjectURL(new Blob([src], { type: "text/javascript" })), wk = new Worker(url), t1 = performance.now();
      wk.onmessage = function(e) { if (done) return; done = true; var o = e.data; o.worker = true; o.wall = Math.round(performance.now() - t1); wk.terminate(); URL.revokeObjectURL(url); cb(o); };
      wk.onerror = function(e) { if (e && e.preventDefault) e.preventDefault(); try { wk.terminate(); } catch (eT) {} setTimeout(main, 0); };
      var buf = new Uint8ClampedArray(rgba).buffer;
      wk.postMessage({ buf: buf, w: w, h: h }, [buf]);
   } catch (eW) { setTimeout(main, 0); }
}

// (N8 + N13) prepara la nebulosa con la foto sin estrellas YA SIN los objetos compactos (srcCanvas: van en sus capas, buildObjects):
// textura de detalle y relieve en el Worker. Mientras tanto se pinta con las capas; al llegar el relieve se pasa al volumen. cb(info).
FWRenderer.prototype.prepareNebula = function(srcCanvas, cb) {
   var T = THREE, self = this;
   if (!this.canRelief) { if (cb) cb(this.info.volume); return; }
   // (nA2, E1) la textura de detalle va a la MAYOR resolucion que admite la GPU (MAX_TEXTURE_SIZE; la foto exportada es la completa, hasta 8192 px)
   // con mipmaps (trilineal) y anisotropia; el relieve y la niebla se calculan de una copia de 2048 px de ancho como antes (el relieve es un mapa de
   // profundidad de 512 px: lo mismo con cualquier resolucion de la foto, y el reparto de la profundidad no cambia)
   var texSrc = FW_GL.MAX_TEX === false ? srcCanvas : fwFitTex(srcCanvas, this.maxTex), small = fwFitTex(srcCanvas, 2048);
   var t = new T.CanvasTexture(texSrc); t.anisotropy = (FW_GL.ANISO === false) ? 1 : this.maxAniso; t.flipY = false; t.generateMipmaps = true; t.minFilter = T.LinearMipmapLinearFilter; t.magFilter = T.LinearFilter; t.wrapS = t.wrapT = T.ClampToEdgeWrapping; t.needsUpdate = true;
   if (this.texDet && this.texDet !== t) { try { this.texDet.dispose(); } catch (eD) {} }
   this.texDet = t; this.uVol.uDet.value = t; this.uVol.uTexW.value = texSrc.width;
   this.info.detailTex = texSrc.width + "x" + texSrc.height + (texSrc !== srcCanvas ? " (fitted from " + srcCanvas.width + "x" + srcCanvas.height + " to the GPU limit " + this.maxTex + ")" : "");
   this.fogPrep(small); this.fogTexW = texSrc.width; this.fogTexH = texSrc.height;     // el pedestal de la niebla de la copia pequeña; el ancho en texeles, el de la textura de verdad (los LOD de la niebla son relativos a el)
   var w = FW_RELIEF.NX, h = Math.max(8, Math.round(w * small.height / small.width));
   var cv = document.createElement("canvas"); cv.width = w; cv.height = h;
   var cx = cv.getContext("2d", { willReadFrequently: true }); cx.imageSmoothingEnabled = true; cx.imageSmoothingQuality = "high"; cx.drawImage(small, 0, 0, w, h);
   var px = cx.getImageData(0, 0, w, h).data;
   fwReliefRun(px, w, h, function(R) {
      try {
         function dtex(u) { var d = new T.DataTexture(u, R.w, R.h, T.RGBAFormat, T.HalfFloatType); d.minFilter = T.LinearFilter; d.magFilter = T.LinearFilter; d.wrapS = d.wrapT = T.ClampToEdgeWrapping; d.generateMipmaps = false; d.flipY = false; d.needsUpdate = true; return d; }
         self.relief = { w: R.w, h: R.h, ms: R.ms, worker: R.worker, wall: R.wall };
         self.vol = { rel: dtex(R.rel), she: dtex(R.she), body: dtex(R.body) };
         var U = self.uVol; U.uRel.value = self.vol.rel; U.uShe.value = self.vol.she; U.uBody.value = self.vol.body;
         self.info.volume = "relief v2 " + R.w + "×" + R.h + " (" + R.ms + " ms" + (R.worker ? " in a worker" : " on the main thread") + ")";
         if (self.opt.layersForced !== true) {
            self.opt.volume = true;
            // (encargo E · P2) las capas siguen un momento y se funden con el volumen (render: reliefFadeK); sin fundido, el salto de antes
            if (FW_GL.RELIEF_FADE_S > 0 && self.layerMeshes.length) { self.opt.layers = true; self.fadeT0 = performance.now(); } else { self.opt.layers = false; self.fadeT0 = undefined; }
         }
      } catch (e) { self.info.volume = "FAILED: " + e; self.vol = null; }
      if (cb) cb(self.info.volume);
   });
};

// (N13) LOS SHADERS SE COMPILAN AL ARRANCAR, EN PARALELO (KHR_parallel_shader_compile, renderer.compileAsync de three r158+): antes el de la
// Via Lactea se compilaba la primera vez que hacia falta, a mitad del primer viaje: 480–900 ms de fotograma congelado (medido 4-nov).
FWRenderer.prototype.precompile = function() {
   var self = this, r = this.r, t0 = performance.now(), ps = [];
   var list = [this.volMat, this.compMat, this.brightMat, this.downMat, this.upMat, this.finalMat, this.objMat0, this.mwMat];
   for (var i = 0; i < list.length; ++i) {
      if (!list[i]) continue;
      var sc = new THREE.Scene(), q = new THREE.Mesh(this.quad.geometry, list[i]); q.frustumCulled = false; sc.add(q);
      if (r.compileAsync) ps.push(r.compileAsync(sc, this.cam)); else r.compile(sc, this.cam);
   }
   if (r.compileAsync) { ps.push(r.compileAsync(this.sScene, this.cam)); ps.push(r.compileAsync(this.layerScene, this.cam)); if (this.objs.length) ps.push(r.compileAsync(this.objScene, this.cam)); }
   return Promise.all(ps).then(function() { self.info.compileMs = Math.round(performance.now() - t0); return self.info.compileMs; });
};

// ---------------------------------------------------------------------------
// (N8) LOS OBJETOS COMPACTOS. list: [{ o (de scene.objects), i, canvas (el recorte), x0, y0, w, h (px de la foto sin estrellas),
// cx, cy, rMax, K, kPhoto (px de la foto completa por px de la foto sin estrellas) }]
// ---------------------------------------------------------------------------
var FW_OBJ_GL = { SHELLS: { pn: 7, galaxy: 3, nebula: 5, other: 3 }, DEPTH: { pn: 0.9, galaxy: 0.08, nebula: 0.6, other: 0.5 }, NEAR_K: 0.6, EDGE_MIN: 0.35 };
FWRenderer.prototype.buildObjects = function(list) {
   var T = THREE, sc = this.scene;
   for (var a = 0; a < list.length; ++a) {
      var it = list[a], o = it.o, K = Math.min(9, it.K || FW_OBJ_GL.SHELLS[o.type] || 3);
      var tx = new T.CanvasTexture(it.canvas); tx.flipY = false; tx.generateMipmaps = true; tx.minFilter = T.LinearMipmapLinearFilter; tx.magFilter = T.LinearFilter; tx.wrapS = tx.wrapT = T.ClampToEdgeWrapping;
      var meshes = [];
      for (var k = 0; k < K; ++k) {
         var g = new T.BufferGeometry();
         g.setAttribute("position", new T.BufferAttribute(new Float32Array(12), 3).setUsage(T.DynamicDrawUsage));
         g.setAttribute("uv", new T.BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), 2)); g.setIndex([0, 1, 2, 0, 2, 3]);
         var m = this.mat(FW_SH_LAYER_V, FW_SH_OBJ_F, Object.assign({ uTex: { value: tx }, uOp: { value: 1 }, uK: { value: K }, uIdx: { value: k }, uFlat: { value: o.type === "galaxy" ? 1 : 0 }, uGain: { value: 1 },
                           uC: { value: new T.Vector2((it.cx - it.x0) / it.w, (it.cy - it.y0) / it.h) }, uRr: { value: new T.Vector2(Math.max(2, it.rMax) / it.w, Math.max(2, it.rMax) / it.h) } }, this.uLayer),
                           { blending: T.AdditiveBlending, transparent: true, side: T.DoubleSide });
         var me = new T.Mesh(g, m); me.frustumCulled = false; this.objScene.add(me); meshes.push(me);
      }
      // las esquinas del recorte vistas desde la Tierra a la distancia del centro (px de la foto completa)
      var dC = fvLen(o.pos), off = [], X = [it.x0 * it.kPhoto, (it.x0 + it.w) * it.kPhoto], Y = [it.y0 * it.kPhoto, (it.y0 + it.h) * it.kPhoto], cs = [[X[0], Y[0]], [X[1], Y[0]], [X[1], Y[1]], [X[0], Y[1]]];
      for (var j = 0; j < 4; ++j) off.push(fvSub(fvPixelPoint(sc, cs[j][0], cs[j][1], dC), o.pos));
      this.objs.push({ o: o, i: it.i, K: K, meshes: meshes, off: off, tex: tx, R: Math.max(1e-9, o.radiusLy || 1e-3), dC: dC });
      if (!this.objMat0) this.objMat0 = meshes[0].material;
   }
   this.info.objects = this.objs.length;
   this.buildObjVolumes(list);   // (V2) el volumen por familias, si el paquete lo trae
};
function fwRotFn(a, b) {
   var ax = fvCross(a, b), s = fvLen(ax), c = fvDot(a, b);
   if (s < 1e-9) { if (c > 0) return function(v) { return v; }; var pp = fvNorm(Math.abs(a[0]) < 0.9 ? fvCross(a, [1, 0, 0]) : fvCross(a, [0, 1, 0])); return function(v) { return fvSub(fvMul(pp, 2 * fvDot(pp, v)), v); }; }
   var k = fvMul(ax, 1 / s);
   return function(v) { return fvAdd(fvAdd(fvMul(v, c), fvMul(fvCross(k, v), s)), fvMul(k, fvDot(k, v) * (1 - c))); };
}
// las capas de cada objeto relativas a la camara (cara a la camara; la galaxia fija), apagandose al rozarlas. -> capas visibles
FWRenderer.prototype.objectsUpdate = function(cam) {
   var n = 0, cam0 = cam;
   for (var a = 0; a < this.objs.length; ++a) {
      var ob = this.objs[a], o = ob.o, c = o.pos;
      // (16-nov, P23-web; fw_box.js) un objeto MAS ALLA de la boca de la caja (M 82: 12 millones de a.l.) se enseña a escala k en la losa de la foto (fvObjBoxK): pintarlo a escala k
      // desde la camara en pos es pintarlo SIN escalar desde pos / k (la proyeccion no cambia con la escala); asi sus capas y su volumen se usan tal cual (como src/ui/fv_objects_paint.js)
      var kb = fwBoxPaintK(FW.scene, o); cam = kb < 1 ? { pos: [cam0.pos[0] / kb, cam0.pos[1] / kb, cam0.pos[2] / kb] } : cam0;
      var toCam = fvSub(cam.pos, c), dCam = fvLen(toCam);
      if (ob.vol && ob.vol.ready && FW_VOL_GL.ON) { for (var k0 = 0; k0 < ob.K; ++k0) ob.meshes[k0].visible = false; n += this.objVolUpdate(ob, cam); continue; }   // (V2)
      if (dCam < 1e-12) continue;
      var u0 = fvMul(c, 1 / ob.dC), tc = fvMul(toCam, 1 / dCam), fixed = (o.type === "galaxy"), rot = fixed ? function(v) { return v; } : fwRotFn(fvMul(u0, -1), tc);
      var depth = (FW_OBJ_GL.DEPTH[o.type] || 0.5) * ob.R, dirZ = rot(u0), spacing = Math.max(1e-9, 2 * depth / Math.max(1, ob.K - 1), 0.15 * ob.R), edge = 1;
      if (fixed) edge = Math.max(FW_OBJ_GL.EDGE_MIN, fvSmooth((Math.abs(fvDot(tc, u0)) - 0.05) / 0.4));
      for (var k = 0; k < ob.K; ++k) {
         var t = ob.K > 1 ? 0.85 * (-1 + 2 * k / (ob.K - 1)) : 0, pc = fvAdd(c, fvMul(dirZ, t * depth)), me = ob.meshes[k], A = me.geometry.attributes.position.array;
         var dPl = Math.abs(fvDot(fvSub(cam.pos, pc), fixed ? u0 : tc)), op = edge * fvSmooth(dPl / (FW_OBJ_GL.NEAR_K * spacing));
         me.visible = op > 0.005 && this.opt.objects !== false; me.material.uniforms.uOp.value = op;
         for (var j = 0; j < 4; ++j) { var w3 = fvAdd(pc, rot(ob.off[j])); A[3 * j] = w3[0] - cam.pos[0]; A[3 * j + 1] = w3[1] - cam.pos[1]; A[3 * j + 2] = w3[2] - cam.pos[2]; }
         me.geometry.attributes.position.needsUpdate = true; if (me.visible) ++n;
      }
   }
   return n;
};

// ---------------------------------------------------------------------------
// (V2, 5-nov-2026) EL VOLUMEN POR FAMILIAS (cascara / disco) en el navegador: las tres pilas de cortes que hizo PixInsight
// (src/ui/fv_volume_paint.js) en su atlas (scene/img_objvol<i>.js, fvxObjVolumes de src/export/fv_export.js), FIJAS en el mundo y con la MISMA
// regla: las dos pilas mas alineadas con la vista (cos²: fwVolStackOp = fvVolStackOpacity de src/engine/fv_volume.js, copiada), fundido al
// rozar un corte (NEAR_K × su separacion) y los cortes a 1/HEAD (aqui ×HEAD: el destino es de coma flotante y el hombro final -uKnee- no deja
// quemar; en PixInsight lo hace la tabla del hombro del lienzo). Solo si el paquete trae o.vol3 (FV_VOLM.ON al exportar); si el atlas no
// llega, el objeto sigue con sus capas de hoy. Mientras carga, tambien.
// ---------------------------------------------------------------------------
var FW_VOL_GL = { ON: true, NEAR_K: 0.6 };
var FW_SH_OBJVOL_F = [   // (nombre propio: FW_SH_VOL_F es el del volumen D9 de la nebulosa)
"precision highp float;",
"in vec2 vUv;",
"uniform sampler2D uTex; uniform float uOp, uHead; uniform vec4 uRect;",
"layout(location = 0) out vec4 oC;",
"void main() { oC = vec4(texture(uTex, uRect.xy + vUv * uRect.zw).rgb * uHead * uOp, 1.0); }"].join("\n");
function fwVolStackOp(d, ex, ey, ez) {
   var c = { X: Math.abs(fvDot(d, ex)), Y: Math.abs(fvDot(d, ey)), Z: Math.abs(fvDot(d, ez)) };
   var ks = ["X", "Y", "Z"].sort(function(a, b) { return c[b] - c[a]; }), a = ks[0], b = ks[1], s = c[a] * c[a] + c[b] * c[b], out = { X: 0, Y: 0, Z: 0 };
   if (c[b] * c[b] / s < 0.04) { out[a] = Math.min(1, 1 / Math.max(1e-6, c[a])); return out; }
   out[a] = Math.min(1, c[a] / s); out[b] = Math.min(1, c[b] / s);
   return out;
}
FWRenderer.prototype.buildObjVolumes = function(list) {
   var self = this, st = this.info.objVol = { want: 0, ready: 0, fail: 0, slices: 0, err: "" };
   if (!FW_VOL_GL.ON) return;
   list.forEach(function(it) {
      var V = it.o.vol3, ob = null;
      for (var a = 0; a < self.objs.length; ++a) if (self.objs[a].i === it.i) ob = self.objs[a];
      if (!V || !V.atlas || !ob) return;
      ++st.want;
      var go = function(src) {
         var im = new Image();
         im.onload = function() { try { self.objVolMake(ob, V, im); ++st.ready; } catch (e) { ++st.fail; st.err = String(e); } };
         im.onerror = function() { ++st.fail; st.err = "atlas " + V.atlas + " did not decode"; };
         im.src = src;
      };
      var I = window.FV_IMG || {};
      if (I[V.atlas]) go(I[V.atlas]);
      else {
         var sc = document.createElement("script"); sc.src = "scene/img_" + V.atlas + ".js";
         sc.onload = function() { var J = window.FV_IMG || {}; if (J[V.atlas]) go(J[V.atlas]); else { ++st.fail; st.err = "no " + V.atlas; } };
         sc.onerror = function() { ++st.fail; st.err = "no scene/img_" + V.atlas + ".js"; };
         document.body.appendChild(sc);
      }
   });
};
// las mallas de los cortes de un objeto (una por corte, como los Bitmap de PixInsight) con su sitio en el mundo
FWRenderer.prototype.objVolMake = function(ob, V, im) {
   var T = THREE, tx = new T.Texture(im), fr = V.fr, D = V.D, sz = fvLen(fr.ez), sl = [], self = this;
   tx.flipY = false; tx.generateMipmaps = false; tx.minFilter = T.LinearFilter; tx.magFilter = T.LinearFilter; tx.wrapS = tx.wrapT = T.ClampToEdgeWrapping; tx.needsUpdate = true;
   var W = function(x, y, z) { return fvAdd(fvAdd(fvAdd(fr.o0, fvMul(fr.e1, x)), fvMul(fr.e2, y)), fvMul(fr.ez, z)); };
   // (V3, ronda 3) pilas GENERICAS (V.gs): cada corte trae su esquina P0, sus pasos U, V y su centro pc en coordenadas del modelo, y cada pila su
   // normal y su paso; las mismas que pinta PixInsight (src/ui/fv_volume_paint.js, fvVolDrawCut). El reparto entre pilas, por grupo (fwVol3Op)
   if (V.gs) {
      var Vw = function(v) { return fvAdd(fvAdd(fvMul(fr.e1, v[0]), fvMul(fr.e2, v[1])), fvMul(fr.ez, v[2])); };
      V.gs.forEach(function(S, si) {
         var nW = fvNorm(Vw(S.nrm)), spW = S.sp * fr.s;
         for (var j = 0; j < S.N; ++j) {
            var c = S.c[j]; if (!c) continue;
            var bw = c[2], bh = c[3], P0 = [c[6], c[7], c[8]], U = [c[9], c[10], c[11]], Vv = [c[12], c[13], c[14]];
            var Pm = function(u, v) { return W(P0[0] + U[0] * u + Vv[0] * v, P0[1] + U[1] * u + Vv[1] * v, P0[2] + U[2] * u + Vv[2] * v); };
            var P4 = [Pm(0, 0), Pm(bw, 0), Pm(bw, bh), Pm(0, bh)], g = new T.BufferGeometry();
            g.setAttribute("position", new T.BufferAttribute(new Float32Array(12), 3).setUsage(T.DynamicDrawUsage));
            g.setAttribute("uv", new T.BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), 2)); g.setIndex([0, 1, 2, 0, 2, 3]);
            var mt = self.mat(FW_SH_LAYER_V, FW_SH_OBJVOL_F, Object.assign({ uTex: { value: tx }, uOp: { value: 0 }, uHead: { value: V.head || 1 }, uRect: { value: new T.Vector4(c[4] / V.aw, c[5] / V.ah, bw / V.aw, bh / V.ah) } }, self.uLayer),
                              { blending: T.AdditiveBlending, transparent: true, side: T.DoubleSide });
            var me = new T.Mesh(g, mt); me.frustumCulled = false; me.visible = false; self.objScene.add(me);
            sl.push({ si: si, group: S.group, me: me, P4: P4, n: nW, sp: spW, pc: W(c[15], c[16], c[17]) });
         }
         S.nW = nW;
      });
      ob.vol = { V: V, sl: sl, tex: tx, ready: true, gen: true };
      this.info.objVol.slices += sl.length;
      return;
   }
   ["Z", "X", "Y"].forEach(function(ax) {
      var S = V.st[ax]; if (!S) return;
      var N = S.N, zs = D / S.Dz;
      for (var j = 0; j < N; ++j) {
         var c = S.c[j]; if (!c) continue;
         var u0 = c[0], v0 = c[1], bw = c[2], bh = c[3], P4, n, sp, pc;
         if (ax === "Z") { var zc = (j + 0.5) * D / N - D / 2; P4 = [W(u0, v0, zc), W(u0 + bw, v0, zc), W(u0 + bw, v0 + bh, zc), W(u0, v0 + bh, zc)]; n = fr.ez1; sp = D / N * sz; pc = W(V.cx, V.cy, zc); }
         else if (ax === "X") { var xc = (j + 0.5) * V.w / N, zA = u0 * zs - D / 2, zB = (u0 + bw) * zs - D / 2; P4 = [W(xc, v0, zA), W(xc, v0, zB), W(xc, v0 + bh, zB), W(xc, v0 + bh, zA)]; n = fr.ex; sp = V.w / N * fvLen(fr.e1); pc = W(xc, V.cy, 0); }
         else { var yc = (j + 0.5) * V.h / N, zA2 = v0 * zs - D / 2, zB2 = (v0 + bh) * zs - D / 2; P4 = [W(u0, yc, zA2), W(u0 + bw, yc, zA2), W(u0 + bw, yc, zB2), W(u0, yc, zB2)]; n = fr.ey; sp = V.h / N * fvLen(fr.e2); pc = W(V.cx, yc, 0); }
         var g = new T.BufferGeometry();
         g.setAttribute("position", new T.BufferAttribute(new Float32Array(12), 3).setUsage(T.DynamicDrawUsage));
         g.setAttribute("uv", new T.BufferAttribute(new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), 2)); g.setIndex([0, 1, 2, 0, 2, 3]);
         var mt = self.mat(FW_SH_LAYER_V, FW_SH_OBJVOL_F, Object.assign({ uTex: { value: tx }, uOp: { value: 0 }, uHead: { value: V.head || 1 }, uRect: { value: new T.Vector4(c[4] / V.aw, c[5] / V.ah, bw / V.aw, bh / V.ah) } }, self.uLayer),
                           { blending: T.AdditiveBlending, transparent: true, side: T.DoubleSide });
         var me = new T.Mesh(g, mt); me.frustumCulled = false; me.visible = false; self.objScene.add(me);
         sl.push({ ax: ax, me: me, P4: P4, n: n, sp: sp, pc: pc });
      }
   });
   ob.vol = { V: V, sl: sl, tex: tx, ready: true };
   this.info.objVol.slices += sl.length;
};
// los cortes visibles de un objeto con volumen (opacidad de su pila y fundido al rozarlos) -> cuantos
// (V3) el reparto de un grupo de pilas de normales cualesquiera: las DOS mas alineadas, cos² y opacidad w/cos (= fv3StackOpacity de
// src/engine/fv_volume3.js, copiada)
function fwVol3Op(d, nrms) {
   var c = nrms.map(function(v) { return Math.abs(fvDot(d, v)); }), idx = c.map(function(v, k) { return k; }).sort(function(p, q) { return c[q] - c[p]; });
   var out = c.map(function() { return 0; }), a = idx[0], b = idx.length > 1 ? idx[1] : -1;
   if (b < 0) { out[a] = Math.min(1, 1 / Math.max(1e-6, c[a])); return out; }
   var s = c[a] * c[a] + c[b] * c[b];
   if (c[b] * c[b] / s < 0.04) { out[a] = Math.min(1, 1 / Math.max(1e-6, c[a])); return out; }
   out[a] = Math.min(1, c[a] / s); out[b] = Math.min(1, c[b] / s);
   return out;
}
FWRenderer.prototype.objVolUpdate = function(ob, cam) {
   var VV = ob.vol, fr = VV.V.fr, d = fvNorm(fvSub(fr.center, cam.pos)), opS = VV.gen ? null : fwVolStackOp(d, fr.ex, fr.ey, fr.ez1), n = 0, show = this.opt.objects !== false, opG = null;
   if (VV.gen) {   // (V3) por grupo
      var gs = VV.V.gs, groups = {}; opG = [];
      gs.forEach(function(S, si) { (groups[S.group] = groups[S.group] || []).push(si); });
      for (var gk in groups) { var ks = groups[gk], o2 = fwVol3Op(d, ks.map(function(si) { return gs[si].nW; })); for (var ii = 0; ii < ks.length; ++ii) opG[ks[ii]] = o2[ii]; }
   }
   for (var s = 0; s < VV.sl.length; ++s) {
      var q = VV.sl[s], a = VV.gen ? opG[q.si] : opS[q.ax], me = q.me, op = a > 0.003 ? a * fvSmooth(Math.abs(fvDot(fvSub(cam.pos, q.pc), q.n)) / (FW_VOL_GL.NEAR_K * q.sp)) : 0;
      me.visible = show && op > 0.004; if (!me.visible) continue;
      me.material.uniforms.uOp.value = Math.min(1, op);
      var A = me.geometry.attributes.position.array;
      for (var j = 0; j < 4; ++j) { A[3 * j] = q.P4[j][0] - cam.pos[0]; A[3 * j + 1] = q.P4[j][1] - cam.pos[1]; A[3 * j + 2] = q.P4[j][2] - cam.pos[2]; }
      me.geometry.attributes.position.needsUpdate = true; ++n;
   }
   return n;
};

// (F3c) el mapa de la Via Lactea desde la camara -> textura (I/ref, fraccion del bulbo)
FWRenderer.prototype.mwFill = function(map, pos) {
   var M = this.mw, a = M.tex.image.data, T = THREE, n = map.I.length;
   for (var i = 0; i < n; ++i) { a[4 * i] = T.DataUtils.toHalfFloat(map.I[i] / M.ref); a[4 * i + 1] = T.DataUtils.toHalfFloat(map.B[i]); a[4 * i + 2] = 0; a[4 * i + 3] = T.DataUtils.toHalfFloat(1); }
   M.tex.needsUpdate = true; M.at = pos.slice();
};
// (F3c) la protagonista: indice (o −1), color 0–1 y peso 0–1 (crece al acercarse)
FWRenderer.prototype.setHero = function(i, rgb, k) {
   var U = this.uStar; U.uHero.value = (i >= 0 && k > 0) ? i : -1; U.uHeroK.value = k || 0;
   if (rgb) U.uHeroCol.value.set(rgb[0], rgb[1], rgb[2]);
};

// el relieve v2: la foto sin estrellas reducida a FW_RELIEF.NX de ancho -> fwReliefBuild -> dos DataTexture RGBA de media coma flotante
FWRenderer.prototype.buildRelief = function(img) {
   var T = THREE, w = FW_RELIEF.NX, h = Math.max(8, Math.round(w * img.height / img.width));
   var cv = document.createElement("canvas"); cv.width = w; cv.height = h;
   var cx = cv.getContext("2d", { willReadFrequently: true }); cx.imageSmoothingEnabled = true; cx.imageSmoothingQuality = "high"; cx.drawImage(img, 0, 0, w, h);
   var R = fwReliefBuild(cx.getImageData(0, 0, w, h).data, w, h);
   this.relief = R;
   function half(f) { var u = new Uint16Array(f.length); for (var i = 0; i < f.length; ++i) u[i] = T.DataUtils.toHalfFloat(f[i]); return u; }
   function dtex(f) {
      var t = new T.DataTexture(half(f), w, h, T.RGBAFormat, T.HalfFloatType);
      t.minFilter = T.LinearFilter; t.magFilter = T.LinearFilter; t.wrapS = t.wrapT = T.ClampToEdgeWrapping; t.generateMipmaps = false; t.flipY = false; t.needsUpdate = true;
      return t;
   }
   return { rel: dtex(R.rel), she: dtex(R.sheets), body: dtex(R.body) };
};

// (pruebas) rehace el relieve con los FW_RELIEF actuales y lo pone en el pintor
FWRenderer.prototype.rebuildRelief = function() {
   if (!this.imgs.starless) return null;
   var v = this.buildRelief(this.imgs.starless), U = this.uVol, SH = FW_RELIEF.SHEETS;
   if (this.vol) { this.vol.rel.dispose(); this.vol.she.dispose(); this.vol.body.dispose(); }
   this.vol = v; U.uRel.value = v.rel; U.uShe.value = v.she; U.uBody.value = v.body; U.uKB.value = FW_RELIEF.KB;
   U.uWt.value.set(SH[0].wt, SH[1].wt, SH[2].wt); U.uMul.value.set(SH[0].mul, SH[1].mul, SH[2].mul);
   return this.relief.ms;
};

function fwRT(w, h) { var T = THREE; return new T.WebGLRenderTarget(Math.max(1, w), Math.max(1, h), { type: T.HalfFloatType, format: T.RGBAFormat, depthBuffer: false, stencilBuffer: false, minFilter: T.LinearFilter, magFilter: T.LinearFilter, generateMipmaps: false }); }
// firma de lo que determina el fotograma del volumen: todos sus uniformes menos el desfase por fotograma (numeros, vectores y el id de las texturas)
FWRenderer.prototype.volSig = function() {
   var U = this.uVol, s = "", k, v;
   for (k in U) { if (k === "uFrame") continue; v = U[k].value; if (v === null || v === undefined) s += "n|"; else if (typeof v === "number") s += v + "|"; else if (v.isTexture) s += v.uuid + "|"; else if (v.toArray) s += v.toArray().join(",") + "|"; else s += "?|"; }
   return s;
};
// (K10 H-1) escala del volumen: opt.volScale es el techo (0,75); volScaleCur la de ahora (la baja el control adaptativo). Solo rehace el destino del volumen.
FWRenderer.prototype.setVolScale = function(s, keepCeiling) {
   if (!keepCeiling) this.opt.volScale = s;
   this.volScaleCur = s;
   if (!this.rt || !this.opt.volHalf) return;
   this.rt.vol.dispose(); this.rt.vol = fwRT(Math.round(this.W * s), Math.round(this.H * s));
   if (this.info) this.info.volScale = s;
};
// (K10 H-1) El controlador: su propio bucle de rAF (el intervalo entre fotogramas es lo que ve el usuario) que NO cuenta pausas (> 250 ms, pestaña
// oculta), la grabacion (reloj fijo) ni las pruebas con el reloj parado (FW.testHold). opt.adaptVol = false lo apaga (las pruebas de pixeles).
FWRenderer.prototype.adaptStart = function() {
   var self = this, C = FW_GL.ADAPT, A = this.adapt = { dts: [], last: 0, n: 0, hold: C.SETTLE, period: 1e9, bad: 0, drops: 0, ups: 0, sinceChange: 0, limit: C.LIMIT_MS, lastP: 0, log: [] };
   function q(a, p) { var s = a.slice().sort(function(x, y) { return x - y; }); return s[Math.min(s.length - 1, Math.max(0, Math.ceil(p * s.length) - 1))]; }
   A.eval = function() {
      var d = A.dts; if (d.length < C.WIN) return;
      var w = d.slice(-C.WIN), p95 = q(w, 0.95), p10 = q(w, 0.1);
      if (p10 >= 4 && p10 < A.period) A.period = p10;
      A.limit = Math.max(C.LIMIT_MS, C.PERIOD_K * Math.min(A.period, C.PERIOD_MAX)); A.lastP = p95;
      var cur = self.volScaleCur, ceil = self.opt.volScale;
      if (cur > C.LOW + 1e-6 && cur >= ceil - 1e-6) {
         A.bad = p95 > A.limit ? A.bad + 1 : 0;
         if (A.bad >= C.BAD_N) { self.setVolScale(C.LOW, true); ++A.drops; A.bad = 0; A.hold = C.SETTLE / 4; A.dts = []; A.sinceChange = 0; A.log.push("down p95=" + p95.toFixed(1) + " lim=" + A.limit.toFixed(1)); }
      } else if (cur < ceil - 1e-6 && A.drops < C.DROPS_LOCK && d.length >= 4 * C.WIN && A.sinceChange >= 10 * C.WIN) {
         if (q(d, 0.95) <= C.UP * A.limit) { self.setVolScale(ceil, true); ++A.ups; A.hold = C.SETTLE / 4; A.dts = []; A.sinceChange = 0; A.log.push("up"); }
      }
   };
   function tick(t) {
      requestAnimationFrame(tick);
      var dt = A.last ? t - A.last : 0; A.last = t;
      var skip = self.opt.adaptVol === false || document.hidden || self.restFull || (typeof FW !== "undefined" && (FW.testHold || (FW.rec && FW.rec.on)));
      if (skip || dt <= 0 || dt > 250) return;
      if (A.hold > 0) { --A.hold; return; }
      A.dts.push(dt); if (A.dts.length > 4 * C.WIN) A.dts.shift();
      ++A.sinceChange;
      if (++A.n % C.EVERY === 0) A.eval();
   }
   requestAnimationFrame(tick);
};
FWRenderer.prototype.resize = function(W, H) {
   if (W === this.W && H === this.H && this.rt) return;
   var T = THREE; this.W = W; this.H = H;
   this.r.setSize(W, H, false);
   var rt = fwRT;
   if (this.volScaleCur === undefined) this.volScaleCur = this.opt.volScale;
   if (this.rt) { this.rt.far.dispose(); this.rt.main.dispose(); this.rt.vol.dispose(); if (this.rt.volFull) this.rt.volFull.dispose(); for (var i = 0; i < this.rt.bl.length; ++i) this.rt.bl[i].dispose(); for (i = 0; i < this.rt.up.length; ++i) this.rt.up[i].dispose(); for (i = 0; i < this.rt.avg.length; ++i) this.rt.avg[i].dispose(); }
   var bl = [], up = [], w = W >> 1, h = H >> 1;
   for (var k = 0; k < 6 && w > 8 && h > 8; ++k) { bl.push(rt(w, h)); w >>= 1; h >>= 1; }
   for (k = 0; k < bl.length - 1; ++k) up.push(rt(bl[k].width, bl[k].height));
   // (F3c) cadena de reducciones para la media de la escena (exposicion)
   var avg = [], aw = W >> 1, ah = H >> 1;
   while (aw > 12 && ah > 6) { avg.push(rt(aw, ah)); aw >>= 1; ah >>= 1; }
   this.rt = { far: rt(W, H), main: rt(W, H), vol: this.opt.volHalf ? rt(Math.round(W * this.volScaleCur), Math.round(H * this.volScaleCur)) : rt(W, H), bl: bl, up: up, avg: avg };
   this.bloomTex = null; this.info.volScale = this.volScaleCur; this.restKey = ""; this.restN = 0;
};

FWRenderer.prototype.pass = function(m, target) { this.quad.material = m; this.r.setRenderTarget(target || null); this.r.render(this.qScene, this.cam); };

// P: piloto del motor (cam en doble). fx: { warp, flash, trailSec, vel (a.l./s) }. VW, VH: tamaño CSS (el del piloto)
// (D, rev. 3) LA NIEBLA DE DENTRO, preparacion: el fondo de cielo de la foto sin estrellas (p25 por canal sobre una copia de 64 px de ancho),
// que se resta para que la niebla no levante los negros (igual que FVPainter.paintFog). La textura es la de detalle (con mipmaps).
FWRenderer.prototype.fogPrep = function(srcCanvas) {
   var w = 64, h = Math.max(2, Math.round(64 * srcCanvas.height / srcCanvas.width)), cv = document.createElement("canvas"); cv.width = w; cv.height = h;
   var cx = cv.getContext("2d", { willReadFrequently: true }); cx.imageSmoothingEnabled = true; cx.imageSmoothingQuality = "high"; cx.drawImage(srcCanvas, 0, 0, w, h);
   var px = cx.getImageData(0, 0, w, h).data, ch = [[], [], []];
   for (var i = 0; i < px.length; i += 4) { ch[0].push(px[i]); ch[1].push(px[i + 1]); ch[2].push(px[i + 2]); }
   var ped = ch.map(function(a) { a.sort(function(p, q) { return p - q; }); return a[Math.floor(0.25 * (a.length - 1))] / 255; });
   this.uComp.uFogTex.value = this.texDet; this.uComp.uFogPed.value.set(ped[0], ped[1], ped[2]);
   if (this.uVol && this.uVol.uN2cPed) this.uVol.uN2cPed.value.set(ped[0], ped[1], ped[2]);   // (N2c) el mismo pedestal para fundir el borde de la foto
   this.fogTexW = srcCanvas.width; this.fogTexH = srcCanvas.height;
};
// (D, rev. 3) LA NIEBLA DE DENTRO, por fotograma (FVPainter.paintLayers/paintFog): peso dentro de la losa inW (1 dentro, 0 a un grosor
// de las caras), dentro del recuadro de la foto (rampa del 8 % en los lados), apagada al 10 % en el salto como las capas de PixInsight
// (1 − 0,9·suave(warp/0,6)). El trozo de foto es el de alrededor de la camara proyectada desde la Tierra, FOG_SPAN del ancho, con el
// aspecto de la pantalla. opt.fog === false la quita (control en rojo de la prueba).
FWRenderer.prototype.fogSet = function(P, cam, fx, o) {
   var U = this.uComp, N = this.scene.nebula, G = FW_GL, V = this.uVol;
   this.fogK = 0;
   if (!N || !this.texDet || !this.fogTexW || o.fog === false || !this.uVol.uOffHome.value) { U.uFogK.value = 0; return; }
   var Tl = fwTiltOf(this.scene), c = Tl ? fwTiltInv(cam.pos, Tl.D, Tl.t) : cam.pos, z0 = V.uZ0.value, z1 = V.uZ1.value, outZ = Math.max(0, z0 - c[2], c[2] - z1), inW = 1 - fvSmooth(outZ / Math.max(1e-9, N.thickLy));   // (nP) la camara en el marco de la losa sin inclinar
   var zc = Math.max(1e-9, c[2]), u = c[0] / zc * V.uKx.value + 0.5, v = c[1] / zc * V.uKy.value + 0.5;
   var inside = fvSmooth(Math.min(u, 1 - u, v, 1 - v) / 0.08), wFade = 1 - 0.9 * fvSmooth(((fx && fx.fadeW !== undefined) ? fx.fadeW : ((fx && fx.warp) || 0)) / 0.6);   // (W1b) fx.fadeW: el apagado de la carga del warp
   var ph = fx && fx.phase, tP = P.t || 0, dtP = Math.max(0, tP - (this.fogT === undefined ? tP : this.fogT)); this.fogT = tP;
   if (ph === "exit" || ph === "cruise") this.fogGlow = 1; else this.fogGlow = (this.fogGlow || 0) * Math.exp(-dtP / G.FOG_TAU);
   var k = G.FOG_K * (1 + G.FOG_GLOW * (this.fogGlow || 0)) * inW * inside * wFade * V.uOffHome.value;
   if (typeof fvNmSlabFade === "function" && P && P.cam) k *= fvNmSlabFade(P);   // (6-nov, F3) idem la niebla
   this.fogK = k; this.fogInW = inW;
   U.uFogK.value = k; if (k <= 0.001) return;
   var sx = G.FOG_SPAN, sy = G.FOG_SPAN * (this.fogTexW / this.fogTexH) * (this.H / this.W);
   U.uFogS.value.set(sx, sy); U.uFogC.value.set(fvClamp(u, sx / 2, 1 - sx / 2), fvClamp(v, Math.min(0.5, sy / 2), Math.max(0.5, 1 - sy / 2)));
   var span = G.FOG_SPAN * this.fogTexW;
   U.uFogLodB.value = Math.max(0, Math.log(span / G.FOG_BASE) / Math.LN2); U.uFogLodD.value = Math.max(0, Math.log(span / G.FOG_DET) / Math.LN2);
   U.uFogGam.value = G.FOG_GAMMA; U.uFogMix.value = G.FOG_MIX; U.uFogMirror.value = o.mirror ? 1 : 0;
};
// (W6) 0..1: cuanto ha entrado en pantalla el borde de la foto (el rectangulo de la capa 0 llevado a la cara delantera, central y trasera de
// la losa, con la inclinacion). Como FVPainter.photoQuad de PixInsight: mIn = lo que el lado mas metido entra en el cuadro (px), rampa de
// EDGE_SHOW_RAMP del ancho; se toma el mayor de las tres caras. Una esquina detras de la camara = 1 (la caida de siempre: dentro de la losa
// o mirando hacia atras). Sin nebulosa o con EDGE_SHOW false = 1 (ROJO: lo de antes)
FWRenderer.prototype.edgeShow = function(P, cam) {
   var N = this.scene.nebula; this.edgePen = 1;   // (N2c) por defecto «el borde entra del todo» (esquina detras de la camara = dentro de la losa: lo de antes)
   if (FW_GL.EDGE_SHOW === false || this.opt.edgeShow === false || !N || !N.layers || !N.layers.length || !(N.distLy > 0)) return 1;
   var L0 = N.layers[0], pr = fvProjector(cam, P.VW, P.VH), TL = fwTiltOf(this.scene), best = 0, pen = -1, ds = [N.distLy - N.thickLy / 2, N.distLy, N.distLy + N.thickLy / 2];
   for (var j = 0; j < ds.length; ++j) {
      var d0 = ds[j], Lp = { z: d0 }, q = [], cs = [[L0.x0, L0.y0], [L0.x1, L0.y0], [L0.x1, L0.y1], [L0.x0, L0.y1]];
      for (var c = 0; c < 4; ++c) { var qq = pr.project(fwTiltPlanePt(Lp, cs[c][0] / L0.z * d0, cs[c][1] / L0.z * d0, TL)); if (!qq) return 1; q.push(qq); }
      var mL = -Math.max(q[0][0], q[3][0]), mR = Math.min(q[1][0], q[2][0]) - P.VW, mT = -Math.max(q[0][1], q[1][1]), mB = Math.min(q[2][1], q[3][1]) - P.VH;
      best = Math.max(best, fvSmooth(-Math.min(mL, mR, mT, mB) / ((FW_GL.EDGE_SHOW_RAMP || 0.04) * P.VW)));
      pen = Math.max(pen, -Math.min(mL, mR, mT, mB) / P.VW);   // (N2c) lo que entra el canto que mas entra, fraccion del ancho
   }
   this.edgePen = pen;
   return best;
};
// (11-nov-2026, NV-13) «HAY PAISAJE» PARA EL LABORATORIO DE VUELO, con el criterio de fvLabUiAnchorFrame de PixInsight, para la camara de AHORA (sin
// esperar a pintar: el visor lo pide en cada paso, PixInsight tras pintar cada fotograma):
//   stars  las estrellas que PINTARIA EL PINTOR DE PIXINSIGHT (painter.stats.stars de FVPainter.paintStars, src/ui/fv_painter.js, con sus cifras de
//          FV_PAINT copiadas en FW_LAB_PI): huella de la foto, cono segun lo que se ve, supuestas, cono cercano, cono del cielo completo, fundido,
//          presupuesto de luz y borde de la foto (photoQuad().kS), apagado de lado del laboratorio; delante de la camara y a menos de 80 px de la vista;
//          sprite con aq >= 1 de A_Q; la protagonista entera no cuenta (se pinta aparte). NO es lo que pinta el sombreador del visor: su borde de la
//          foto y su huella son otros (W6: el borde entero con la foto detras; huella previa en aMag) y con ellos el visor contaba un 15–30 % menos en el
//          tramo lejano y la v5 aceleraba en otros sitios (medido: 11 de 12 viajes fuera de tolerancia, tests/web/fv_nv13_parity_cdp.js). El laboratorio
//          decide la NAVEGACION: se le da lo que veria PixInsight para que el viaje sea el mismo. Sin el polvo, los recortes de FOTO ni el temblor del warp
//   cover  la foto en pantalla: su cuadrilatero (capa 0 a la distancia de la nebulosa, inclinada) recortado a la vista / el area de la vista, si la foto
//          o las capas se pintan (stats.wPhoto + stats.layers de PixInsight: peso de la foto como plano > 0, o la opacidad de las capas de paintLayers
//          (1 − wP)·canto·losa > 0,01); 0 si alguna esquina queda detras de la camara (photoQuad null)
// la protagonista (heroOf de PixInsight, con su crecimiento del laboratorio) y la elegida, fuera de las reglas. -> { stars, cover, hid: { … } }
FWRenderer.prototype.labLandFrame = function(P) {
   var cam = P.cam, VW = P.VW, VH = P.VH, X5 = FW_LAB_PI, sc = this.scene, S = (typeof fvTimeStars === "function") ? fvTimeStars(sc) : sc.stars, n = S.n, i;
   var B, SS = 1;
   if (cam.B) { B = cam.B; SS = cam.S || 1; } else B = fvBasis(cam.look, [0, 1, 0]);
   var pr = fvProjector(cam, VW, VH), f = pr.f, cx = pr.cx, cy = pr.cy, r = pr.r, d = pr.d, fw = pr.fw;
   var N = sc.nebula, dRef = N ? N.distLy : 1000, px = cam.pos[0], py = cam.pos[1], pz = cam.pos[2], camD = Math.sqrt(px * px + py * py + pz * pz);
   var lim = fvLookLimits(cam.fov, P.homeFov), fadeOn = !!FV_LOOK.FADE_ON, aMin = FV_LOOK.A_MIN || 1 / 32, AQ = FV_LOOK.A_Q || 16;
   // la protagonista (FVPainter.heroOf: con el laboratorio crece antes de llegar) y la elegida: fuera de las reglas
   var hs = (P.flight && P.flight.sel && P.flight.sel.kind === "star") ? P.flight.sel : ((P.arrivedAt && P.arrivedAt.kind === "star") ? P.arrivedAt : ((P.sel && P.sel.kind === "star") ? P.sel : null)), heroI = -1, heroW = 0;
   if (!hs && P.lab) { var so = (P.flight && P.flight.sel) || P.arrivedAt || P.sel, Ob = so && so.kind === "object" && sc.objects ? sc.objects[so.i] : null; if (Ob && Ob.star >= 0) hs = { kind: "star", i: Ob.star, arriveLy: (typeof fvObjectTarget === "function" && fvObjectTarget(sc, so.i)) ? fvObjectTarget(sc, so.i).arriveLy : 0 }; }
   if (hs) {
      var hdc = fvLen(fvSub(fvStarPos(sc, hs.i), cam.pos)), hm = fvApparentMag(S.g[hs.i], S.dEarth[hs.i], hdc);
      if (P.lab && typeof fvArriveDist === "function") { var hdA = fvArriveDist(P, hs), hp = fvClamp(Math.log(Math.max(hdc, 1e-9) / Math.max(hdA, 1e-9)) / Math.log(300), 0, 1); hm = Math.min(hm, X5.HERO_MAG - 1.5 * (1 - hp)); }
      if (hm < X5.HERO_MAG) { heroI = hs.i; heroW = fvSmooth((X5.HERO_MAG - hm) / 1.5); }
   }
   var selI = (P.sel && P.sel.kind === "star") ? P.sel.i : ((P.flight && P.flight.sel && P.flight.sel.kind === "star") ? P.flight.sel.i : -1);
   var dmAss = X5.ASSUMED_DM * fvSmooth(camD / (X5.ASSUMED_AWAY * dRef)), distAway = fvSmooth(camD / (X5.ASSUMED_AWAY * dRef)), trailAway = fvSmooth(((P.trail || 0) - 0.16) / 0.3);
   var away = Math.max(distAway, trailAway), Fc = sc.facts || {}, coneGc = Fc.coneGc || X5.CONE_GC, wideG = (Fc.wideMag > 0) ? Fc.wideMag : coneGc - 2, ringG = Fc.ringMag || 12.5;
   var byView = X5.CONE_BY_VIEW && distAway > 0.001, tanHd = Math.sqrt(VW * VW + VH * VH) / (2 * f), fz = fw[2];
   var cDeg = Fc.coneDeg > 0 ? Fc.coneDeg : 0.6, tanCp = Math.tan(cDeg * FV_DEG), tanCr = Math.tan((Fc.ringDeg > 0 ? Fc.ringDeg : 2 * cDeg) * FV_DEG), tSoft = X5.TUBE_SOFT;
   var nearPhoto = (Fc.coneDeg > 0) ? X5.CONE_TUBE * Math.tan(Fc.coneDeg * FV_DEG) : X5.CONE_NEAR, nearRing = (Fc.ringDeg > 0 && Fc.nRing > 0) ? X5.CONE_TUBE * Math.tan(Fc.ringDeg * FV_DEG) : nearPhoto;
   // la huella de la foto (PRINT_ONLY, PRINT_SOFT) y la regla de profundidad (DEPTH_BY_FOV "auto": apagada con la huella)
   var pw = null;
   if (X5.PRINT_ONLY && typeof fvPrintW === "function") { if (!this.labPw || this.labPw.length !== S.n) { this.labPw = new Float32Array(S.n); for (i = 0; i < S.n; ++i) this.labPw[i] = fvPrintW(sc, i, X5.PRINT_SOFT); } pw = this.labPw; }
   // la foto en pantalla (FVPainter.photoQuad) y, con ella, el borde de la foto para las estrellas (kS, rampa STAR_EDGE_RAMP) y el presupuesto de luz
   var TB = fwTiltOf(sc), quad = null, kE = 0, pe = null, ebx = 1, eby = 1, kA = 1;
   if (N && N.layers && N.layers.length && N.distLy > 0) {
      var L0 = N.layers[0], d0 = N.distLy, Lb = { z: d0 }; quad = [];
      [[L0.x0, L0.y0], [L0.x1, L0.y0], [L0.x1, L0.y1], [L0.x0, L0.y1]].forEach(function(c) { if (!quad) return; var qq = pr.project(fwTiltPlanePt(Lb, c[0] / L0.z * d0, c[1] / L0.z * d0, TB)); if (!qq) quad = null; else quad.push(qq); });
      if (quad) { var mIn = -Math.min(-Math.max(quad[0][0], quad[3][0]), Math.min(quad[1][0], quad[2][0]) - VW, -Math.max(quad[0][1], quad[1][1]), Math.min(quad[2][1], quad[3][1]) - VH); kE = X5.STAR_EDGE ? fvSmooth(mIn / (X5.STAR_EDGE_RAMP * VW)) : 0; }
   }
   if (kE > 0.002 && typeof fvPrintUV === "function") {
      if (!this.labUv || this.labUv.length !== 2 * S.n) { this.labUv = new Float32Array(2 * S.n); for (i = 0; i < S.n; ++i) { var uv0 = fvPrintUV(sc, i); this.labUv[2 * i] = uv0[0]; this.labUv[2 * i + 1] = uv0[1]; } }
      pe = this.labUv; var fld = sc.field, lng = Math.max(fld.width, fld.height), eb = X5.PHOTO_EDGE[0] + X5.PHOTO_EDGE[1]; ebx = 2 * eb * lng / fld.width; eby = 2 * eb * lng / fld.height;
   }
   if (typeof fvStarBudget === "function" && quad) { var bud = fvStarBudget(sc, cam, P.homeFov, pr, lim, pw, quad, VW, VH, pe ? { uv: pe, k: kE, bx: ebx, by: eby } : null); kA = bud.k; lim = bud.lim; }
   var sideF = !!(P.lab && typeof fvLabSideFadeK === "function");
   var cnt = 0, hidOff = 0, hidCone = 0, hidFade = 0, X = S.x, Y = S.y, Z = S.z;
   for (i = 0; i < n; ++i) {
      var ex = (i === heroI || i === selI);
      if (pw && pw[i] < 0.999 && !ex && pw[i] <= 0.01) continue;
      var vx = X[i] - px, vy = Y[i] - py, vz = Z[i] - pz, fqx = SS * vx, fqy = SS * vy, zc = fqx * fw[0] + fqy * fw[1] + vz * fw[2];
      if (!(zc > 1e-7)) continue;
      var sx = cx + f * (fqx * r[0] + fqy * r[1] + vz * r[2]) / zc, sy = cy + f * (fqx * d[0] + fqy * d[1] + vz * d[2]) / zc;
      if (sx < -80 || sy < -80 || sx > VW + 80 || sy > VH + 80) { ++hidOff; continue; }
      var aw = away, kS = 1;
      if (byView) {
         if (fz > 0.05) { var sZ = (Z[i] - pz) / fz; if (sZ > 0) { var qx = SS * px + sZ * fw[0], qy = SS * py + sZ * fw[1], rhoV = Math.sqrt(qx * qx + qy * qy) + sZ * tanHd / fz, rC = SS * Z[i] * ((S.inFrame[i] && S.g[i] > ringG) ? tanCp : tanCr); kS = rC > 0 ? fvSmooth((rhoV / rC - 1) / tSoft) : 1; } }
         aw = Math.max(distAway * kS, trailAway);
      }
      var dc = Math.sqrt(vx * vx + vy * vy + vz * vz), m = fvApparentMag(S.g[i], S.dEarth[i], dc) + (S.q[i] === 2 ? dmAss * (byView ? kS : 1) : 0);
      if (pw && pw[i] < 0.999 && !ex) { m -= 2.5 * Math.log(pw[i]) / Math.LN10; if (fvLookAlpha(m, lim) < aMin) continue; }
      if (X5.CONE_NEAR_ON && aw > 0.001 && !ex && S.g[i] > wideG) {
         var nk = dc / S.dEarth[i], coneNear = (S.inFrame[i] && S.g[i] > ringG) ? nearPhoto : nearRing;
         if (nk > coneNear) { m += aw * X5.CONE_DM * fvSmooth((nk - coneNear) / coneNear); if (fvLookAlpha(m, lim) < aMin) { ++hidCone; continue; } }
      }
      if (aw > 0.001 && !ex && m > coneGc - X5.CONE_SOFT) { m += aw * X5.CONE_DM * fvSmooth((m - coneGc + X5.CONE_SOFT) / X5.CONE_SOFT); if (fvLookAlpha(m, lim) < aMin) { ++hidCone; continue; } }
      var fa = (!fadeOn || ex) ? 1 : fvLookAlpha(m, lim);
      if (!ex) { fa *= kA; if (pe) fa *= 1 - kE * (1 - fvPrintEdgeW(pe[2 * i], pe[2 * i + 1], ebx, eby)); }
      if (SS !== 1 && sideF && !ex) fa *= fvLabSideFadeK(dc, Math.sqrt(fqx * fqx + fqy * fqy + vz * vz));
      if (Math.round(fa * AQ) < 1) { ++hidFade; continue; }
      if (i === heroI && heroW >= 0.999) continue;          // la protagonista entera se pinta aparte (no suma en stats.stars)
      ++cnt;
   }
   // la foto en pantalla (si la foto como plano o las capas se pintan: los mismos pesos que FVPainter.paintLayers, cifras de FV_PAINT copiadas)
   var cover = 0, wP0 = 0, opL = 0;
   if (quad && typeof fvPolyAreaClip === "function") {
      wP0 = 1 - fvSmooth(camD / (FW_GL.PHOTO_FADE * N.distLy));
      var lk = fvNorm(cam.look), cL = TB ? fwTiltInv(cam.pos, TB.D, TB.t) : cam.pos, ce = Math.abs(TB ? fvDot(lk, TB.n) : lk[2]);
      var zA = N.layers[0].z, zB = N.layers[N.layers.length - 1].z, outZ = Math.max(0, zA - cL[2], cL[2] - zB), inW = 1 - fvSmooth(outZ / Math.max(1, N.thickLy));
      var edge = Math.max(fvSmooth((ce - FW_GL.LAB_EDGE_LO) / (FW_GL.LAB_EDGE_HI - FW_GL.LAB_EDGE_LO)), FW_GL.LAB_EDGE_IN * inW), wFade = 1 - 0.9 * fvSmooth(((typeof fvWarpFadeW === "function") ? fvWarpFadeW(P) : (P.warp || 0)) / 0.6);   // (W1b)
      if (wFade < 0.999) edge *= wFade;
      opL = (1 - wP0) * edge * ((typeof fvNmSlabFade === "function") ? fvNmSlabFade(P) : 1);
      if (wP0 > 0 || opL > 0.01) cover = fvPolyAreaClip(quad, VW, VH) / (VW * VH);
   }
   return { stars: cnt, cover: cover, wP: wP0, opL: opL, kB: kA, kE: kE, heroI: heroI, hid: { off: hidOff, cone: hidCone, fade: hidFade } };
};
FWRenderer.prototype.render = function(P, fx) {
   // (nP, AETAS) las estrellas del año elegido en la maquina del tiempo (fw_time.js -> engine/fv_time.js): las posiciones se suben CADA
   // fotograma (rel, relativas a la camara), asi que basta con leerlas de la vista del año; el bucle del visor pinta siempre
   var T = THREE, o = this.opt, S = (typeof fwTimeStars === "function") ? fwTimeStars(this.scene) : this.scene.stars, n = S.n, cam = P.cam, i;
   ++this.frame; if (!this.adapt) this.adaptStart();
   var B, SS = 1, tanH = Math.tan(cam.fov / 2), tanV = tanH * P.VH / P.VW;
   if (cam.B) { B = cam.B; SS = cam.S || 1; }          // (11-nov, NV-13) el laboratorio: la base completa de la nave (en el espacio de vuelo) y S
   else {
      B = fvBasis(cam.look, [0, 1, 0]);
      // (nP) ROLL de la camara: la base gira alrededor de la mirada (como fvPaintRoll del pintor de PixInsight: r' = cos·r + sin·d)
      if (cam.roll) { var cR = Math.cos(cam.roll), sR = Math.sin(cam.roll), r0 = B.r, d0 = B.d; B = { f: B.f, r: [cR * r0[0] + sR * d0[0], cR * r0[1] + sR * d0[1], cR * r0[2] + sR * d0[2]], d: [-sR * r0[0] + cR * d0[0], -sR * r0[1] + cR * d0[1], -sR * r0[2] + cR * d0[2]] }; }
   }
   // (NV-13) las tres bases (ver el constructor). Con SS = 1 las tres son B tal cual (x·1 y x/1 son exactos): lo de antes, bit a bit
   this.uStar.uR.value.set(SS * B.r[0], SS * B.r[1], B.r[2]); this.uStar.uD.value.set(SS * B.d[0], SS * B.d[1], B.d[2]); this.uStar.uF.value.set(SS * B.f[0], SS * B.f[1], B.f[2]);
   this.uRay.uR.value.set(B.r[0] / SS, B.r[1] / SS, B.r[2]); this.uRay.uD.value.set(B.d[0] / SS, B.d[1] / SS, B.d[2]); this.uRay.uF.value.set(B.f[0] / SS, B.f[1] / SS, B.f[2]);
   var skyReal = SS !== 1 && typeof fvLab4On === "function" && fvLab4On() && typeof FV_LAB !== "undefined" && FV_LAB.SKY && FV_LAB.SKY.REAL, KB = skyReal ? B : { r: this.uRay.uR.value.toArray(), d: this.uRay.uD.value.toArray(), f: this.uRay.uF.value.toArray() };
   this.uSky.uR.value.set(KB.r[0], KB.r[1], KB.r[2]); this.uSky.uD.value.set(KB.d[0], KB.d[1], KB.d[2]); this.uSky.uF.value.set(KB.f[0], KB.f[1], KB.f[2]);
   var SF = (SS !== 1 && typeof FV_LAB !== "undefined" && typeof fvLab4On === "function" && fvLab4On()) ? FV_LAB.SIDE_FADE : null;
   this.uStar.uSS.value = SS; this.uStar.uSideOn.value = (SF && SF.ON) ? 1 : 0; if (SF) { this.uStar.uSideLo.value = SF.LO; this.uStar.uSideHi.value = SF.HI; }
   this.info.labS = SS;
   this.uStar.uTanH.value = tanH; this.uStar.uTanV.value = tanV;
   this.uStar.uRes.value.set(this.W, this.H);
   var lim = fvLookLimits(cam.fov, P.homeFov);
   // (F3c) lejos de casa: 0 en la Tierra, 1 a un 2 % de la distancia de la nebulosa (la rampa de PixInsight)
   var dRef = this.scene.nebula ? this.scene.nebula.distLy : 1000, camD = Math.sqrt(cam.pos[0] * cam.pos[0] + cam.pos[1] * cam.pos[1] + cam.pos[2] * cam.pos[2]);
   this.uStar.uAway.value = o.coneRules === false ? 0 : fvSmooth(camD / (FW_GL.ASSUMED_AWAY * dRef));
   // (B2) el cono segun lo que se ve: posicion de la camara en el mundo y semidiagonal de la vista (o.coneByView === false = ROJO)
   this.uStar.uCamW.value.set(cam.pos[0], cam.pos[1], cam.pos[2]); this.uStar.uTanHd.value = Math.sqrt(tanH * tanH + tanV * tanV); this.uStar.uByView.value = (o.coneByView === false || FW_GL.CONE_BY_VIEW === false) ? 0 : 1;
   this.uStar.uMagLim.value = lim.magLim; this.uStar.uSatMag.value = lim.satMag; this.uStar.uFloor.value = FV_LOOK.FLOOR;
   // (5-nov) STELLAE «como en la foto»: la escala de casa (px de pantalla por px de recorte), los limites de casa y la fase del warp
   if (this.look === "phstar" && this.psData) {
      var limH = fvLookLimits(P.homeFov, P.homeFov), lw = this.psData.law || {}, trK = (P.trail || 0);
      this.uStar.uPsOn.value = 1; this.uStar.uPsHome.value = (this.W / 2) / Math.tan(P.homeFov / 2) / (this.scene.field.F * this.psData.k);
      this.uStar.uMagLimH.value = limH.magLim; this.uStar.uSatMagH.value = limH.satMag;
      this.uStar.uPsTrailK.value = fvSmooth((trK - (lw.trailLo || 0.04)) / ((lw.trailHi || 0.2) - (lw.trailLo || 0.04)));
   } else this.uStar.uPsOn.value = 0;
   // (nP, I1 + I2) brillo automatico (lim ya trae el desplazamiento por campo de fvLookLimits) y fundido suave; o.fade === false = ROJO
   var fadeOn = FV_LOOK.FADE_ON !== false && o.fade !== false;
   this.uStar.uFadeOn.value = fadeOn ? 1 : 0; this.uStar.uFadeLo.value = (lim.fadeLo !== undefined) ? lim.fadeLo : lim.magLim; this.uStar.uFadeW.value = FV_LOOK.FADE_W || 1; this.uStar.uAMin.value = FV_LOOK.A_MIN || 1 / 32; this.info.lookOff = lim.off || 0;
   // (nP-2) AL ALEJARSE, LA FOTO PEQUEÑA (como el pintor de PixInsight): estrellas apagadas con el borde de la foto cuando el volumen apaga el
   // suyo (la misma rampa que uOffHome; o.starEdge === false o FW_GL.STAR_EDGE === false = ROJO) y presupuesto de luz por area de foto
   // (fvStarBudget; FV_BUDGET.ON false = ROJO)
   var kOff = Math.max(fvSmooth(camD / (FW_GL.OFF_LY * dRef)), fvSmooth((cam.fov / P.homeFov - 1.03) / 0.22));
   // (W6) ¿esta el borde de la foto en pantalla? (photoQuad().kE de PixInsight, en las caras delantera, central y trasera de la losa)
   var kShow = this.edgeShow(P, cam); this.info.kEdgeShow = kShow; this.uVol.uEdgeShow.value = kShow; kOff *= kShow;
   // (W3) el peso de la foto como plano: el de PixInsight (1 − suave(|camara| / (PHOTO_FADE × d))), salvo donde el borde de la foto se ve (ahi el
   // volumen trae su caida suave): × (1 − kOff). ≥ PHOTO_SKIP cuenta como 1 (el 2 % de volumen que faltaria no se ve y cuesta el volumen entero)
   var wPh = (FW_GL.PHOTO_PLANE === false || o.photoPlane === false || !this.texDet) ? 0 : (1 - fvSmooth(camD / (FW_GL.PHOTO_FADE * dRef))) * (1 - kOff);
   if (wPh >= FW_GL.PHOTO_SKIP) wPh = 1;
   // (W7c) el tunel negro del salto: la nebulosa (volumen, foto y su polvo) al 1 − WARP_NEB_DIM·suave(warp / WARP_NEB_W), como PixInsight (FVPainter.paintLayers,
   // wFade = 1 − 0,9·suave(warp / 0,6)); la niebla ya lo hacia (fogSet). WARP_NEB_DIM 0 = ROJO (la nebulosa a plena luz detras de las estelas)
   // (encargo E · P2) el fundido capas -> volumen: fadeK 0 (solo capas) .. 1 (solo volumen); sin fundido en curso, 1. Se corta si el usuario cambia
   // de capas a volumen a mano (tecla V: layersForced) o apaga el volumen
   var fadeK = 1, layerG = 1;
   if (this.fadeT0 !== undefined) {
      if (!(o.volume && this.vol) || o.layersForced === true) { this.fadeT0 = undefined; }
      else {
         fadeK = fvSmooth((performance.now() - this.fadeT0) / (1000 * FW_GL.RELIEF_FADE_S));
         if (fadeK >= 1) { this.fadeT0 = undefined; fadeK = 1; o.layers = false; } else layerG = 1 - fadeK;
      }
   }
   this.info.reliefFade = fadeK;
   var nebK = 1 - (FW_GL.WARP_NEB_DIM || 0) * fvSmooth(((fx && fx.fadeW !== undefined) ? fx.fadeW : ((fx && fx.warp) || 0)) / (FW_GL.WARP_NEB_W || 0.6)); /* (W1b) fx.fadeW */ if (typeof fvNmSlabFade === "function" && P && P.cam) nebK *= fvNmSlabFade(P); this.uComp.uNebK.value = nebK * fadeK; this.info.nebK = nebK;   // (encargo E · P2) × fadeK: el volumen entra con el fundido de las capas   // (6-nov, F3) en el Espacio, dentro de la losa, se aclara
   // (16-nov, P22; fw_box.js) el velo: con FW_VEIL.MODE > 0 y un objeto escalado a la losa, el volumen pierde el pedestal de cielo de la foto (+ margen en MODE 2; la misma cuenta que FV_VEIL de PixInsight)
   if (typeof fwVeilSub === "function") fwVeilSub(this.scene, this.uComp.uFogPed.value, this.uComp.uVeil.value);
   this.uComp.uPhK.value = wPh; this.info.photoK = wPh; this.uComp.uPhBias.value = o.photoBias !== undefined ? o.photoBias : (FW_GL.PHOTO_BIAS || 0);
   this.uStar.uEdgeK.value = (o.starEdge === false || FW_GL.STAR_EDGE === false) ? 0 : kOff; this.uStar.uEbx.value = this.uStar.uEby.value = 2.2 * (o.edge || 0.17) + 0.17;
   var kB = 1, Nb = this.scene.nebula;
   if (typeof fvStarBudget === "function" && Nb && Nb.layers && Nb.layers.length) {
      var L0 = Nb.layers[0], d0 = Nb.distLy, TB = fwTiltOf(this.scene), Lb = { z: d0 }, prB = fvProjector(cam, P.VW, P.VH), qB = [], okB = true;
      [[L0.x0, L0.y0], [L0.x1, L0.y0], [L0.x1, L0.y1], [L0.x0, L0.y1]].forEach(function(c) { if (!okB) return; var qq = prB.project(fwTiltPlanePt(Lb, c[0] / L0.z * d0, c[1] / L0.z * d0, TB)); if (!qq) okB = false; else qB.push(qq); });
      if (okB) { var bud = fvStarBudget(this.scene, cam, P.homeFov, prB, lim, this.printWArr, qB, P.VW, P.VH, this.uStar.uEdgeK.value > 0.002 ? { uv: this.uvArr, k: this.uStar.uEdgeK.value, bx: this.uStar.uEbx.value, by: this.uStar.uEby.value } : null); kB = bud.k; this.info.budget = { k: bud.k, dLim: bud.dLim, area: bud.area, vis: bud.vis, S: bud.S, B0: bud.B0 };
         this.uStar.uMagLim.value = bud.lim.magLim; this.uStar.uFadeLo.value = (bud.lim.fadeLo !== undefined) ? bud.lim.fadeLo : bud.lim.magLim; }
   }
   this.uStar.uBudK.value = kB; this.info.kB = kB; this.info.kEdge = this.uStar.uEdgeK.value;
   // el tamaño minimo de la estrella ligado a la resolucion: FWHM ≈ 1,8 px a 720 px de alto (F1), proporcional al alto de la pantalla
   this.uStar.uSigma0.value = FV_LOOK.SIGMA0 * Math.max(1, this.H / 720);
   // (W7d) la protagonista como PixInsight: rr = min(HERO_MAX, HERO_R0·2^(0,4·(HERO_MAG − m)))·(0,35 + 0,65·w), w = suave((HERO_MAG − m)/1,5), en px de un
   // fotograma de 1080 de alto (PixInsight a 1920 × 1080), escalado al lienzo. FW_GL.HERO_PI false = ROJO (la corona ancha de antes)
   var hI = this.uStar.uHero.value, HP = FW_GL.HERO_PI !== false && o.heroPi !== false;
   this.uStar.uHeroPi.value = HP ? 1 : 0; this.uStar.uHeroRpx.value = 0; this.uStar.uHeroW.value = 0; this.uStar.uHeroSoft.value = 0; this.info.heroLab = null; this.info.heroGl = null;
   if (HP && hI >= 0 && hI < n) {
      var hx = S.x[hI] - cam.pos[0], hy = S.y[hI] - cam.pos[1], hz = S.z[hI] - cam.pos[2], hm = fvApparentMag(S.g[hI], S.dEarth[hI], Math.sqrt(hx * hx + hy * hy + hz * hz));
      var hw = fvSmooth((FW_GL.HERO_MAG - hm) / 1.5), hr = Math.min(FW_GL.HERO_MAX, FW_GL.HERO_R0 * Math.pow(2, 0.4 * (FW_GL.HERO_MAG - hm))) * (0.35 + 0.65 * hw) * this.H / 1080, hS = 0;
      // (11-nov, NV-16) con el laboratorio, la de PixInsight entera (fw_amb.js, fwHeroPi): crece antes de llegar (heroOf) y en el ultimo tramo (HERO_NEAR)
      if (cam.B && P.lab && typeof fwHeroPi === "function") {
         var hL = fwHeroPi(this.scene, P, fvProjector(cam, this.W, this.H));
         if (hL && hL.i === hI) { hm = hL.m; hw = hL.w; hr = hL.rr * this.H / 1080; hS = hL.soft ? 1 : 0; } else { hw = 0; hr = 0; }
         this.info.heroLab = hL;
      }
      this.uStar.uHeroRpx.value = hr; this.uStar.uHeroW.value = hw; this.uStar.uHeroSoft.value = hS; this.info.heroPi = { m: hm, w: hw, rpx: hr, soft: hS }; this.info.heroGl = { i: hI, m: hm, w: hw, rpx: hr, soft: hS };
   }
   this.uStar.uGain.value = o.gain; this.uStar.uHalo.value = fwLookVal(o, "halo", fx); this.uStar.uMaxSat.value = o.maxSat;   // (W5) halo fuera del salto: el de reposo
   // (B2) estelas V2 (o.streakV2 === false o FW_GL.STREAK_V2 false = las de antes, ROJO) e iluminadas por el destello
   this.uStar.uStreakV2.value = (FW_GL.STREAK_V2 !== false && o.streakV2 !== false) ? 1 : 0; this.uStar.uFlashS.value = fx ? (fx.flash || 0) : 0;
   this.uStar.uStreakGain.value = FW_GL.STREAK_GAIN * ((fx && fx.gainK) || 1); this.uStar.uStreakTail.value = FW_GL.STREAK_TAIL; this.uStar.uStreakW.value = FW_GL.STREAK_W * ((fx && fx.widthK) || 1); this.uStar.uStreakLit.value = FW_GL.STREAK_LIT;
   // RELATIVO A LA CAMARA: p − cam en doble, y solo entonces a float32
   var px = cam.pos[0], py = cam.pos[1], pz = cam.pos[2], X = S.x, Y = S.y, Z = S.z, rel = this.rel;
   for (i = 0; i < n; ++i) { rel[3 * i] = X[i] - px; rel[3 * i + 1] = Y[i] - py; rel[3 * i + 2] = Z[i] - pz; }
   this.aRel.needsUpdate = true;
   // estelas del warp: donde estaba cada estrella (relativa) hace trailSec segundos
   var tr = (fx && fx.trailSec > 0 && fx.vel) ? fx.vel : [0, 0, 0], ts = fx ? (fx.trailSec || 0) : 0;
   this.uStar.uTrail.value.set(tr[0] * ts, tr[1] * ts, tr[2] * ts);
   // (N6) rayas hacia el punto de fuga (px del lienzo desde el centro, +y arriba como en el shader) y color verdadero (F4b)
   var vp = (fx && fx.vp) ? fx.vp : [0, 0];
   this.uStar.uVp.value.set(vp[0] * this.W / P.VW, -vp[1] * this.H / P.VH); this.uStar.uRadial.value = fx ? (fx.radial || 0) : 0; this.uStar.uDop.value = fx ? (fx.doppler || 0) : 0; this.uStar.uHole.value = (fx && o.vpHole !== false && typeof FW_WARPFX !== "undefined") ? fvSmooth((fx.radial || 0) / (0.5 * FW_WARPFX.RADIAL_MAX)) : 0; this.uStar.uHoleR0.value = FW_GL.HOLE_R0; this.uStar.uHoleR1.value = FW_GL.HOLE_R1; this.uStar.uHolePow.value = FW_GL.HOLE_POW; this.uStar.uTrueOn.value = o.trueColour === false ? 0 : 1;
   // plano que separa las dos pasadas: por el centro de la nebulosa, perpendicular a la linea camara → nebulosa
   var N = this.scene.nebula, useVol = o.volume && !!this.vol && !!N;
   if (N) {
      var cN = [N.center[0] - px, N.center[1] - py, N.center[2] - pz], ln = Math.sqrt(cN[0] * cN[0] + cN[1] * cN[1] + cN[2] * cN[2]) || 1;
      this.uStar.uSplitN.value.set(cN[0] / ln, cN[1] / ln, cN[2] / ln); this.uStar.uSplitD.value = ln;
   }
   var r = this.r;
   // 1. estrellas lejanas (todas si no hay volumen)
   var mwW = (this.mw && o.milkyway !== false) ? fvSmooth(camD / (FW_GL.MW_AWAY * dRef)) : 0;
   if (mwW > 0.002) {
      // el mapa se rehace al moverse mas de REMAP_LY (o un 20 % de la distancia a casa), no en pleno warp (como PixInsight)
      var at = this.mw.at, mv = Math.sqrt(Math.pow(px - at[0], 2) + Math.pow(py - at[1], 2) + Math.pow(pz - at[2], 2));
      if (mv > Math.max(FV_MW.REMAP_LY, 0.2 * camD) && !(fx && fx.warp > 0.3)) { var tq = performance.now(); this.mwFill(fvMwMap(this.mw.frame, cam.pos), cam.pos); this.mw.ms = performance.now() - tq; ++this.mw.remaps; }
      this.uMw.uK.value = FW_GL.MW_PEAK * mwW;
      // el grano esta anclado a direcciones del mundo en celdas de ~0,06°: con el campo por debajo de ~25° cada celda ocupa muchos pixeles
      this.uMw.uGrainK.value = fvSmooth((cam.fov / FV_DEG - 20) / 25);
      this.pass(this.mwMat, this.rt.far);
   } else { r.setRenderTarget(this.rt.far); r.setClearColor(0x000000, 1); r.clear(true, false, false); }
   var hrOn = this.uStar.uHrK.value > 0;      // (I2, 19-nov) con el diagrama HR las estrellas se pintan todas despues (encima del velo), tambien sin volumen
   this.uStar.uPass.value = (useVol || hrOn) ? 1 : 0;
   r.render(this.sScene, this.cam);
   if (o.layers && this.layerMeshes.length) {
      var TL = fwTiltOf(this.scene);
      for (i = 0; i < this.layerMeshes.length; ++i) {
         var me = this.layerMeshes[i], L = me.userData, a = me.geometry.attributes.position.array, zz = L.z - pz;
         a[0] = L.x0 - px; a[1] = L.y0 - py; a[2] = zz; a[3] = L.x1 - px; a[4] = L.y0 - py; a[5] = zz; a[6] = L.x1 - px; a[7] = L.y1 - py; a[8] = zz; a[9] = L.x0 - px; a[10] = L.y1 - py; a[11] = zz;
         if (TL) { var cq = [[L.x0, L.y0], [L.x1, L.y0], [L.x1, L.y1], [L.x0, L.y1]]; for (var qi = 0; qi < 4; ++qi) { var wq = fwTiltPlanePt(L, cq[qi][0], cq[qi][1], TL); a[3 * qi] = wq[0] - px; a[3 * qi + 1] = wq[1] - py; a[3 * qi + 2] = wq[2] - pz; } }   // (nP) inclinadas
         me.geometry.attributes.position.needsUpdate = true; me.material.uniforms.uMirror.value = o.mirror ? 1 : 0; me.material.uniforms.uGain.value = layerG;   // (encargo E · P2) las capas bajan mientras el volumen sube
      }
      r.render(this.layerScene, this.cam);
   }
   // 2. volumen
   // (nA2, E1) EN REPOSO, A RESOLUCION COMPLETA: con la camara quieta REST_FRAMES fotogramas (o grabando video, que va a reloj fijo) el volumen se
   // calcula a W × H en vez de a volScale × (0,5 al volar: el presupuesto de 16 ms). Antes la nebulosa se veia siempre a 960 × 540 estirada a
   // 1920 × 1080. Al moverse vuelve al destino pequeño (los dos viven a la vez: sin crearlos ni destruirlos en pleno gesto)
   var vrt = this.rt.vol; this.restFull = false;
   if (useVol && o.restFull !== false && FW_GL.REST_FULL !== false && this.opt.volHalf && this.volScaleCur < 0.999) {
      var pk = cam.pos[0] + "|" + cam.pos[1] + "|" + cam.pos[2] + "|" + cam.look[0] + "|" + cam.look[1] + "|" + cam.look[2] + "|" + cam.fov + "|" + ((fx && fx.warp) || 0) + "|" + ((fx && fx.trailSec) || 0) + (cam.B ? "|" + B.r.join(",") + "|" + SS : "");   // (NV-13) con el laboratorio el alabeo y S tambien
      this.restN = (pk === this.restKey) ? (this.restN || 0) + 1 : 0; this.restKey = pk;
      var recOn = (typeof FW !== "undefined" && FW.rec && FW.rec.on);
      if (this.restN >= FW_GL.REST_FRAMES || recOn) {
         if (!this.rt.volFull || this.rt.volFull.width !== this.W || this.rt.volFull.height !== this.H) { if (this.rt.volFull) this.rt.volFull.dispose(); this.rt.volFull = fwRT(this.W, this.H); }
         vrt = this.rt.volFull; this.restFull = true;
      }
   } else this.restN = 0;
   if (useVol) {
      var U = this.uVol, Wv = vrt.width; U.uCam.value.set(px, py, pz);
      var TV = fwTiltOf(this.scene); U.uTiltOn.value = TV ? 1 : 0;
      if (TV) { var tc = fwTiltPt([0, 0, N.distLy], TV.D, TV.t); U.uTN.value.set(TV.n[0], TV.n[1], TV.n[2]); U.uTC.value.set(tc[0], tc[1], tc[2]); U.uTPad.value = 0.5 * Math.max(N.distLy / U.uKx.value, N.distLy / U.uKy.value) * Math.sqrt(1 - TV.n[2] * TV.n[2]) / Math.max(0.2, Math.abs(TV.n[2])) + 0.5 * N.thickLy * (1 / Math.max(0.2, Math.abs(TV.n[2])) - 1); }
      else { U.uTPad.value = 0; } U.uSteps.value = o.steps; U.uFrame.value = this.frame % 64; U.uMirror.value = o.mirror ? 1 : 0;
      // (19-nov, N2c) FW_N2C (?n2c=0 = lo de antes) y FV_N2C (src/engine/fv_objects.js: ON, R0, SKY): fundir el borde de la foto cuando se ve (k2c del shader = off × uEdgeShow × uN2c)
      U.uN2c.value = (typeof FW_N2C !== "undefined" && FW_N2C.ON && typeof FV_N2C !== "undefined" && FV_N2C.ON && o.n2c !== false) ? fvN2cShowK(this.edgePen === undefined ? 1 : this.edgePen) : 0;   // el peso por cuanto entra el canto (FV_N2C.SHOW), como FVPainter.paintLayers
      if (typeof FV_N2C !== "undefined") { var fN2 = this.scene.field, sN2 = Math.max(fN2.width, fN2.height); U.uN2cDB.value = FV_N2C.DB; U.uN2cSky.value = FV_N2C.SKY; U.uN2cCont.value = FV_N2C.CONT; U.uN2cA.value.set(fN2.width / sN2, fN2.height / sN2); }
      U.uPixAng.value = 2 * tanH / Wv / SS;            // (NV-13) con S el pixel abarca S veces menos angulo REAL de lado (el detalle de la lamina se lee mas fino)
      U.uOffHome.value = Math.max(fvSmooth(camD / (FW_GL.OFF_LY * dRef)), fvSmooth((cam.fov / P.homeFov - 1.03) / 0.22)); U.uSheet.value = o.sheet === false ? 0 : 1; U.uDust.value = o.dust === false ? 0 : 1; U.uSecMax.value = o.secMax || 2.5; U.uEdge.value = o.edgeOld ? 0.12 : (o.edge || 0.17);
      // (D, rev. 2) 0,12 era la banda de antes (rojo con edgeOld). (D, rev. 3) estas dos asignaciones estaban DETRAS del comentario de la
      // linea anterior y no se ejecutaban: uEdgeOld se quedaba en 0 y el control en rojo de T11 solo estrechaba la banda, sin la formula vieja
      U.uWob.value = o.wob === undefined ? 2.2 : o.wob; U.uEdgeOld.value = o.edgeOld ? 1 : 0; U.uEdgeRamp.value = o.edgeRamp === false ? 0 : 1; U.uBudget.value = o.capFix === false ? 0 : 1; U.uBudgetK.value = o.capK === undefined ? 160 : o.capK;   // (F3c) 0,12/1,4 dejaba el rectangulo de la foto visible desde lejos
      // (nA2, E1) en reposo el volumen a resolucion completa se pinta UNA vez: con la misma camara y los mismos parametros (firma de los uniformes del
      // volumen, sin el desfase por fotograma) el resultado seria el mismo, asi que se reutiliza el destino (medido: a 120 Hz, repintarlo cada
      // fotograma subia el p95 del intervalo de 8,4 a 16,7 ms) y la nebulosa queda sin el parpadeo del ruido de muestreo
      var skipVol = false;
      // (W3) cerca de casa la foto como plano pesa uPhK; con uPhK = 1 (≥ PHOTO_SKIP) el volumen no se ve: no se calcula (casa a 5K con la GPU integrada)
      if (this.uComp.uPhK.value >= 1) skipVol = true;
      else if (this.restFull) { var sg = this.volSig(); if (sg === this.volFullSig && this.rt.volFullOk === vrt) skipVol = true; else { this.volFullSig = sg; this.rt.volFullOk = vrt; } }
      if (!skipVol) this.pass(this.volMat, vrt);
      this.info.volSkipped = skipVol;
   }
   // 3. composicion + estrellas cercanas
   if (!useVol) this.uComp.uPhK.value = 0;
   this.uComp.uFar.value = this.rt.far.texture; this.uComp.uVol.value = vrt.texture; this.uComp.uVolOn.value = useVol ? 1 : 0;
   this.uComp.uLocal.value = useVol ? (o.localK === undefined ? FW_GL.LOCAL_K : o.localK) * this.uVol.uOffHome.value : 0; this.uComp.uVolTexel.value.set(1 / vrt.width, 1 / vrt.height); this.uComp.uRad.value = 5 * vrt.width / this.rt.vol.width;   // (el radio del contraste local en texeles del destino pequeño: el mismo angulo a cualquier resolucion)
   this.fogSet(P, cam, fx, o);
   this.pass(this.compMat, this.rt.main);
   // (N8) los objetos compactos, en capas, sobre lo de detras
   if (this.objs.length && o.objects !== false) { this.objVisible = this.objectsUpdate(cam); if (this.objVisible) { r.setRenderTarget(this.rt.main); r.render(this.objScene, this.cam); } }
   if (hrOn && typeof fwHrVeilGl === "function") fwHrVeilGl(this);      // (I2) el velo del diagrama HR sobre la foto, debajo de las estrellas (web/fw_hr.js)
   if (useVol || hrOn) { this.uStar.uPass.value = -1; r.setRenderTarget(this.rt.main); r.render(this.sScene, this.cam); }
   // 4. bloom
   var bl = this.rt.bl, src = this.rt.main;
   if (o.bloomK > 0 && bl.length) {
      this.brightMat.uniforms.uTex.value = src.texture; this.brightMat.uniforms.uTexel.value.set(0.5 / src.width, 0.5 / src.height); this.brightMat.uniforms.uThr.value = o.bloomThr;
      this.pass(this.brightMat, bl[0]);
      for (i = 1; i < bl.length; ++i) { this.downMat.uniforms.uTex.value = bl[i - 1].texture; this.downMat.uniforms.uTexel.value.set(1 / bl[i - 1].width, 1 / bl[i - 1].height); this.pass(this.downMat, bl[i]); }
      // subida en tienda: up[i−1] = tienda(nivel de abajo ya sumado) + reduccion i−1
      var cur = bl[bl.length - 1];
      for (i = bl.length - 1; i > 0; --i) {
         this.upMat.uniforms.uTex.value = cur.texture; this.upMat.uniforms.uBase.value = bl[i - 1].texture; this.upMat.uniforms.uTexel.value.set(1 / cur.width, 1 / cur.height);
         this.pass(this.upMat, this.rt.up[i - 1]); cur = this.rt.up[i - 1];
      }
      this.bloomTex = cur.texture;
   }
   // 4b. media de la escena (exposicion)
   var av = this.rt.avg, asrc = this.rt.main;
   if (o.exposure !== false && av.length) {
      for (i = 0; i < av.length; ++i) { this.downMat.uniforms.uTex.value = asrc.texture; this.downMat.uniforms.uTexel.value.set(1 / asrc.width, 1 / asrc.height); this.pass(this.downMat, av[i]); asrc = av[i]; }
   }
   // (11-nov, NV-16) el campo de estrellas de fondo SIMULADO (web/fw_amb.js, el de PixInsight: src/engine/fv_ambient.js), en Add sobre la escena, DESPUES
   // del bloom y de la media de la exposicion (en PixInsight ni brilla ni cambia la exposicion: medido, pintado antes cambiaba 85 000 pixeles por 100
   // puntos) y antes del pase final (destello, tunel, viñeteado y la ventana de la nave van encima, como alli). Solo con el laboratorio y la Via Lactea encendida
   if (typeof fwAmbGl === "function") { var tA = performance.now(); fwAmbGl(this, P); this.info.ambMs = performance.now() - tA; this.info.amb = this.ambLast || null; }
   // 5. final a la pantalla
   var F = this.uFinal;
   F.uAvg.value = av.length ? av[av.length - 1].texture : this.rt.main.texture; F.uExpOn.value = (o.exposure !== false && av.length) ? 1 : 0; F.uExpTarget.value = o.expTarget || FW_GL.EXP_TARGET;
   F.uMain.value = this.rt.main.texture; F.uBloom.value = (bl.length && this.bloomTex) ? this.bloomTex : this.rt.main.texture; F.uBloomK.value = (bl.length && o.bloomK > 0) ? fwLookVal(o, "bloomK", fx) : 0;   // (W5)
   F.uFlash.value = fx ? (fx.flashBall !== undefined ? fx.flashBall : (fx.flash || 0)) : 0; F.uAberr.value = o.aberr * (fx ? (fx.warp || 0) : 0) * 0.012; F.uVig.value = fwLookVal(o, "vig", fx); F.uGrain.value = fwLookVal(o, "grain", fx); F.uFrame.value = this.frame % 997;
   F.uRes.value.set(this.W, this.H); F.uKnee.value = o.knee;
   // (N6) tunel y desenfoque radial del warp, destello azul-blanco
   F.uZoom.value = fx ? (fx.zoom || 0) : 0; F.uTunnel.value = fx ? (fx.tunnel || 0) : 0; F.uTime.value = fx ? (fx.time || 0) : 0;
   F.uVpUv.value.set(0.5 + vp[0] / P.VW, 0.5 - vp[1] / P.VH);
   if (fx && fx.flashCol) F.uFlashCol.value.set(fx.flashCol[0], fx.flashCol[1], fx.flashCol[2]);
   var X = (typeof FW_WARPFX !== "undefined") ? FW_WARPFX : {};
   F.uFlashR.value = (fx && fx.flashR) || X.FLASH_R || 0.05; F.uFlashRad.value = o.flashRadial === false ? 0 : 1;
   F.uSpikeW.value = X.SPIKE_W || 0.004; F.uSpikeL.value = X.SPIKE_L || 0.45; F.uFlashGain.value = X.FLASH_GAIN || 2.2;
   // (B2) el destello V2: pulso suave sin espigas, azulado-blanco (o.flashV2 === false o FW_GL.FLASH_V2 false = el de §15, ROJO)
   var fv2 = FW_GL.FLASH_V2 !== false && o.flashV2 !== false;
   F.uSpikeK.value = fv2 ? FW_GL.FLASH_SPIKE_K : 1; F.uFlashHalo.value = FW_GL.FLASH_HALO;
   if (fv2) { F.uFlashR.value = FW_GL.FLASH_R2; F.uFlashGain.value = FW_GL.FLASH_GAIN2; F.uFlashCol.value.set(FW_GL.FLASH_COL2[0], FW_GL.FLASH_COL2[1], FW_GL.FLASH_COL2[2]); }
   this.pass((FW_FG.ON && typeof this.fgFinal === "function") ? this.fgFinal(fx) : this.finalMat, null);   // (Blender 2) la ventana de la nave (FW_FG.ON false = el de siempre)
};

// (5-nov) STELLAE: el aspecto de las estrellas, "gaia" | "phcol" | "phstar", con lo que exporto PixInsight (J.photoStars: colores medidos en la
// foto y recortes en un atlas; img = la imagen del atlas). Sin datos, "gaia". Con "gaia" los colores vuelven a los de siempre. -> el aspecto puesto
// (B1) ¿GAIA es la temperatura (y COLOR la foto)? El paquete trae colG y FW_PS_B1 no es false (false = el STELLAE de antes: ROJO)
FWRenderer.prototype.starB1 = function() { return !!this.colGBase && (typeof FW_PS_B1 === "undefined" || FW_PS_B1 !== false); };
FWRenderer.prototype.setStarLook = function(look, ps, img) {
   var T = THREE, n = this.scene.stars.n, col = this.aCol.array, colT = this.aColT.array, i;
   var b1 = this.starB1();
   if (b1) { if (look !== "gaia" && look !== "phcol" && look !== "phstar") look = "gaia"; if (look === "phstar" && !(ps && ps.spr && img)) look = "phcol"; }       // (B1) COLOR no necesita nada del paquete
   else if (!ps || !ps.rgb || (look !== "phcol" && look !== "phstar") || (look === "phstar" && !img)) look = (look === "phcol" && ps && ps.rgb) ? "phcol" : "gaia";
   if (b1 && look === "gaia") { col.set(this.colGBase); colT.set(this.colGTBase); } else { col.set(this.colBase); colT.set(this.colTBase); }
   if (!b1 && look !== "gaia") for (i = 0; i < n; ++i) {
      var v = ps.rgb[i]; if (!(v >= 0)) continue;
      var c = fwHexToRgb(v), mx = Math.max(c[0], c[1], c[2], 1e-3);
      col[3 * i] = c[0] / mx; col[3 * i + 1] = c[1] / mx; col[3 * i + 2] = c[2] / mx;
      if (!this.hasTrue[i]) { colT[3 * i] = col[3 * i]; colT[3 * i + 1] = col[3 * i + 1]; colT[3 * i + 2] = col[3 * i + 2]; }
   }
   this.aCol.needsUpdate = true; this.aColT.needsUpdate = true;
   var sp = this.aSpr.array, sc = this.aSprC.array; sp.fill(0); sc.fill(0);
   if (look === "phstar") {
      var F = ps.spr;
      for (i = 0; i + 6 < F.length; i += 7) { var j = F[i]; if (!(j >= 0 && j < n)) continue; sp[4 * j] = F[i + 1]; sp[4 * j + 1] = F[i + 2]; sp[4 * j + 2] = F[i + 3]; sp[4 * j + 3] = F[i + 4]; sc[2 * j] = F[i + 5]; sc[2 * j + 1] = F[i + 6]; }
      if (!this.psTex) { var t = new T.Texture(img); t.flipY = false; t.generateMipmaps = false; t.minFilter = T.LinearFilter; t.magFilter = T.LinearFilter; t.wrapS = t.wrapT = T.ClampToEdgeWrapping; t.needsUpdate = true; this.psTex = t; }
      this.uStar.uPsTex.value = this.psTex; this.uStar.uPsAtlas.value.set(ps.atlasSize[0], ps.atlasSize[1]);
      var lw = ps.law || {}; this.uStar.uPsMagLo.value = lw.magLo || 2; this.uStar.uPsMagHi.value = lw.magHi || 3; this.uStar.uPsScaleMin.value = lw.scaleMin || 0.25; this.uStar.uPsSigCap.value = lw.sigmaCap || 4;
   }
   this.aSpr.needsUpdate = true; this.aSprC.needsUpdate = true;
   this.psData = ps || null; this.look = look; this.info.look = look;
   return look;
};
// CONTROL EN ROJO (pruebas): baraja el color y la magnitud de las estrellas entre si (= cada estrella en el rayo de otra) y pone la
// nebulosa en espejo. on = false lo deshace.
FWRenderer.prototype.spoil = function(on, seed) {
   var n = this.scene.stars.n, col = this.aCol.array, mg = this.aMag.array, i;
   col.set(this.colBase); mg.set(this.magBase);
   if (on) {
      var R = fvRng(seed || 11), perm = []; for (i = 0; i < n; ++i) perm.push(i);
      for (i = n - 1; i > 0; --i) { var j = Math.floor(R() * (i + 1)), t = perm[i]; perm[i] = perm[j]; perm[j] = t; }
      for (i = 0; i < n; ++i) { var p = perm[i]; col[3 * i] = this.colBase[3 * p]; col[3 * i + 1] = this.colBase[3 * p + 1]; col[3 * i + 2] = this.colBase[3 * p + 2]; mg[2 * i] = this.magBase[2 * p]; mg[2 * i + 1] = this.magBase[2 * i + 1]; }
   }
   this.aCol.needsUpdate = true; this.aMag.needsUpdate = true;
   this.opt.mirror = !!on;
};
