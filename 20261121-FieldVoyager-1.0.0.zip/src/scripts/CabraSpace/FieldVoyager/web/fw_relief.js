// ============================================================================
// FieldVoyager/web/fw_relief.js — EL RELIEVE de la nebulosa en volumen, v2 «cuerpo + lamina» (4-nov-2026, F3b)
// ----------------------------------------------------------------------------
// Puro (sin DOM ni WebGL): de la foto sin estrellas reducida (RGBA de 8 bits, w × h) a dos mapas 2D que el pintor (fw_gl.js) lee
// en cada paso del raymarching. Sustituye al volumen 3D de baja resolucion de F3 (src/export/fv_export_volume.js): aquel era una
// columna por voxel de 192 de ancho -> dentro, bruma sin detalle; de lado, estrias (cada columna, un perfil estirado).
//
// GEOMETRIA (la de F3): cada rayo que sale de la Tierra es UNA columna (u, v) del tronco de piramide que cubre la foto entre
// z0 = d − grosor/2 y z1 = d + grosor/2; w = (z − z0)/grosor. Desde casa, la suma de la columna ES el pixel de la foto sin estrellas.
//
// EL MODELO (todo el relieve es SUPUESTO y se dice en pantalla; lo que se inventa y de donde sale):
//   1. CUERPO: la foto muy suavizada B (σ ≈ 2,7 a.l. en el cielo) emite en un perfil gaussiano GRUESO en profundidad, centro cD(u, v)
//      y anchura sD(u, v) = 4,5–9,5 % del grosor (lo tenue y difuso, mas grueso). Es la nube con cuerpo.
//   2. LAMINA: lo que la foto tiene POR ENCIMA de B (filamentos, frentes brillantes) emite en una lamina FINA, centro cS(u, v) y anchura
//      sS(u, v) = 0,6–3 % del grosor segun la escala de la estructura (filamentos finos -> lamina fina; nubes -> gruesa). El detalle se
//      lee de la foto a resolucion completa en el punto exacto del rayo (proyectado desde la Tierra): nitido a cualquier distancia.
//   3. POLVO: lo que la foto tiene POR DEBAJO de B (bordes oscuros, cabezas de los pilares) ABSORBE en esa misma lamina (extincion por
//      canal: T *= x', con x' calculado para que desde la Tierra salga la foto exacta aunque parte del cuerpo quede delante).
//   La lamina va S_FRONT anchuras del cuerpo POR DELANTE de su centro (los frentes de ionizacion y el polvo, de cara a nosotros) y se
//   arruga con la escala media de la propia imagen (C_S). Profundidad del cuerpo: la puntuacion de banda de F1 (0,65·brillo + 0,35·
//   rojez; brillante y rojo —Hα— delante) a dos escalas. NADA de ruido inventado: toda variacion sale de la imagen suavizada.
// SALIDA: rel = [cD, cS, sD, sS] y body = [B.r, B.g, B.b, wob] por pixel (Float32Array, 4 canales; el pintor los sube como media
// coma flotante). wob (0..1) es el rango del brillo a escala media: ondula la caida hacia los bordes de la foto para que nada
// termine en linea recta.
// Procedencia: fvxBlur / fvxRank adaptados de src/export/fv_export_volume.js (F3, mismo autor).
// ES5. Prueba: tests/web/fv_f3_cdp.js (C1 desde casa r ≥ 0,95 con su control en rojo; detalle dentro con su control).
// ============================================================================

var FW_RELIEF = {
   NX: 512,                   // ancho de los mapas (el alto sale del aspecto)
   R_BODY: 24,                // suavizado del cuerpo (pixeles del mapa; 1 px ≈ 4 px de la foto de trabajo de 2048; 24 px ≈ 4 a.l.)
   KB: 0.30,                  // parte de la luz suavizada que va en el cuerpo (el resto, y todo el detalle, en las laminas). (F3c) 0,40 -> 0,30: mas peso a la fibrilla
   R_CHROMA: 2,               // (F3c) el COLOR del cuerpo sale de la foto apenas suavizada (r = 2 px del mapa ≈ 8 px de la foto); su BRILLO, del suavizado grande.
                              // En F3b el cuerpo era la foto suavizada a 24 px en los tres canales: el rojo del Hα y el azul del OIII se mezclaban en un
                              // rosa chicle de aerografo (f3b_dentro_pilares, f3b_lado_limpia)
   C_LF: 0.15, C_MF: 0.06,    // centro del cuerpo: amplitud por la escala grande (ancho/14) y la media (r = 10), fraccion del grosor
   SD_MIN: 0.03, SD_MAX: 0.065,   // anchura del cuerpo (3,4–7,4 a.l. con 114 de grosor): compacto, casi tan hondo como ancho
   // tres laminas a distinta profundidad (en anchuras del cuerpo respecto a su centro), cada una con su parte del detalle, su
   // grosor (multiplo de sS) y su arruga sacada de una banda distinta de la imagen. Solo la de delante lleva el polvo.
   SHEETS: [ { off: -1.3, wt: 0.50, mul: 1.0, band: [3, 12], sign: 1 },
             { off: 0.0, wt: 0.30, mul: 1.5, band: [8, 24], sign: -1 },
             { off: 1.2, wt: 0.20, mul: 2.0, band: [4, 16], sign: 1 } ],
   C_S: 0.008,                // amplitud de la arruga de las laminas (fraccion del grosor, ≈ ±0,9 a.l.). (F3c) 0,012 -> 0,008: los pliegues mas empinados, vistos
                              // de refilon, dejaban arcos finos y brillantes como costuras (f3b_dentro_pilares) y cortinas regulares
   SS_MIN: 0.0013, SS_MAX: 0.0045   // 0,15–0,5 a.l.: el detalle fino solo puede vivir en una lamina asi de fina (si no, se estira en estrias)
};

function fwrClamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
// suavizado de caja separable, tres pasadas (≈ gaussiana de sigma ≈ r)
function fwrBlur(a, W, H, r) {
   if (r < 1) return Float32Array.from(a);
   var src = Float32Array.from(a), tmp = new Float32Array(W * H), x, y, s, n = 2 * r + 1;
   for (var pass = 0; pass < 3; ++pass) {
      for (y = 0; y < H; ++y) { var o = y * W; s = 0; for (x = -r; x <= r; ++x) s += src[o + fwrClamp(x, 0, W - 1)]; for (x = 0; x < W; ++x) { tmp[o + x] = s / n; s += src[o + Math.min(W - 1, x + r + 1)] - src[o + Math.max(0, x - r)]; } }
      for (x = 0; x < W; ++x) { s = 0; for (y = -r; y <= r; ++y) s += tmp[fwrClamp(y, 0, H - 1) * W + x]; for (y = 0; y < H; ++y) { src[y * W + x] = s / n; s += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x]; } }
   }
   return src;
}
// rango (0..1) de cada valor dentro de su distribucion
function fwrRank(a) {
   var n = a.length, s = [], i;
   for (i = 0; i < n; i += Math.max(1, Math.floor(n / 20000))) s.push(a[i]);
   s.sort(function(p, q) { return p - q; });
   var out = new Float32Array(n), m = s.length;
   for (i = 0; i < n; ++i) { var lo = 0, hi = m; while (lo < hi) { var mid = (lo + hi) >> 1; if (s[mid] < a[i]) lo = mid + 1; else hi = mid; } out[i] = lo / m; }
   return out;
}

// rgba: Uint8(Clamped)Array w × h × 4 (la foto sin estrellas ya reducida)
// -> { w, h, rel: [cD, sD, sS, wob], sheets: [cS0, cS1, cS2, 0], body: [B.r, B.g, B.b, 1], ms, params }
function fwReliefBuild(rgba, w, h, o) {
   o = o || {};
   var t0 = Date.now(), K = FW_RELIEF, N = w * h, i, j;
   var R = new Float32Array(N), G = new Float32Array(N), B = new Float32Array(N), L = new Float32Array(N), Rd = new Float32Array(N);
   for (i = 0; i < N; ++i) {
      R[i] = rgba[4 * i] / 255; G[i] = rgba[4 * i + 1] / 255; B[i] = rgba[4 * i + 2] / 255;
      L[i] = 0.2126 * R[i] + 0.7152 * G[i] + 0.0722 * B[i];
      Rd[i] = 0.5 + 0.5 * (R[i] - B[i]) / (R[i] + G[i] + B[i] + 1e-3);
   }
   var sc = new Float32Array(N); for (i = 0; i < N; ++i) sc[i] = 0.65 * L[i] + 0.35 * Rd[i];
   // cuerpo: la foto muy suavizada
   var Lb = fwrBlur(L, w, h, K.R_BODY), Rc = fwrBlur(R, w, h, K.R_CHROMA), Gc = fwrBlur(G, w, h, K.R_CHROMA), Bc = fwrBlur(B, w, h, K.R_CHROMA);
   var Rb = new Float32Array(N), Gb = new Float32Array(N), Bb = new Float32Array(N);
   for (i = 0; i < N; ++i) {
      // brillo grande × cromaticidad local (rgb / luminancia, a escala fina): el cuerpo conserva el tono de la foto
      var lc = 0.2126 * Rc[i] + 0.7152 * Gc[i] + 0.0722 * Bc[i], kk = Lb[i] / Math.max(lc, 0.004);
      Rb[i] = Math.min(1, Rc[i] * kk); Gb[i] = Math.min(1, Gc[i] * kk); Bb[i] = Math.min(1, Bc[i] * kk);
   }
   // profundidad del cuerpo: puntuacion de banda a dos escalas
   var rLF = Math.max(3, Math.round(w / 14)), qLF = fwrRank(fwrBlur(sc, w, h, rLF)), qMF = fwrRank(fwrBlur(sc, w, h, 10));
   // arruga de cada lamina: una banda de la puntuacion (suavizado r1 menos r2), en rango
   var blurC = {}; function bl(r) { if (!blurC[r]) blurC[r] = fwrBlur(sc, w, h, r); return blurC[r]; }
   var qS = [];
   for (j = 0; j < K.SHEETS.length; ++j) { var bd = K.SHEETS[j].band, a1 = bl(bd[0]), a2 = bl(bd[1]), bF = new Float32Array(N); for (i = 0; i < N; ++i) bF[i] = a1[i] - a2[i]; qS.push(fwrRank(bF)); }
   // brillo (lo brillante, mas delgado) y finura de la estructura (energia de la banda fina frente a la media)
   var L2 = fwrBlur(L, w, h, 2), L10 = fwrBlur(L, w, h, 10), ef = new Float32Array(N), em = new Float32Array(N);
   for (i = 0; i < N; ++i) { ef[i] = Math.abs(L[i] - L2[i]); em[i] = Math.abs(L2[i] - L10[i]); }
   ef = fwrBlur(ef, w, h, 6); em = fwrBlur(em, w, h, 6);
   var fin = new Float32Array(N); for (i = 0; i < N; ++i) fin[i] = ef[i] / (ef[i] + em[i] + 1e-4);
   var qL = fwrRank(fwrBlur(L, w, h, 4)), qFin = fwrRank(fin), w4 = fwrRank(fwrBlur(L, w, h, 4)), w16 = fwrRank(fwrBlur(L, w, h, 16)), wob = new Float32Array(N);
   for (i = 0; i < N; ++i) wob[i] = 0.5 * (w4[i] + w16[i]);       // ondulacion del borde: brillo a dos escalas (lo brillante llega mas cerca del borde)
   var rel = new Float32Array(4 * N), she = new Float32Array(4 * N), body = new Float32Array(4 * N);
   for (i = 0; i < N; ++i) {
      var sD = K.SD_MIN + (K.SD_MAX - K.SD_MIN) * (1 - qL[i]);
      var cD = fwrClamp(0.5 - K.C_LF * (2 * qLF[i] - 1) - K.C_MF * (2 * qMF[i] - 1), 3 * sD + 0.02, 1 - 3 * sD - 0.02);
      var sS = K.SS_MAX + (K.SS_MIN - K.SS_MAX) * fwrClamp(0.5 * qFin[i] + 0.5 * qL[i], 0, 1);
      rel[4 * i] = cD; rel[4 * i + 1] = sD; rel[4 * i + 2] = sS; rel[4 * i + 3] = wob[i];
      for (j = 0; j < K.SHEETS.length && j < 3; ++j) {
         var S = K.SHEETS[j], m = 3 * sS * S.mul + 0.01;
         she[4 * i + j] = fwrClamp(cD + S.off * sD - S.sign * K.C_S * (2 * qS[j][i] - 1), m, 1 - m);
      }
      body[4 * i] = Rb[i]; body[4 * i + 1] = Gb[i]; body[4 * i + 2] = Bb[i]; body[4 * i + 3] = 1;
   }
   return { w: w, h: h, rel: rel, sheets: she, body: body, ms: Date.now() - t0,
            params: { model: "body + 3 sheets + dust (v2)", rBody: K.R_BODY, kB: K.KB, rLF: rLF, cLF: K.C_LF, cMF: K.C_MF, sD: [K.SD_MIN, K.SD_MAX], sheets: K.SHEETS, cS: K.C_S, sS: [K.SS_MIN, K.SS_MAX] } };
}
