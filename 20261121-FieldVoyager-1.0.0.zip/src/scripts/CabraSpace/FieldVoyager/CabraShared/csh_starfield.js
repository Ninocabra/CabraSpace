// [CabraShared, 15-oct-2026] UNA sola copia para CabraStars, Cabra3D y CabraStarAnalysis. Base: la copia de Cabra3D de
// CabraPilot integracion-1410c (097fba6) CabraCore/src/engine/starfield.js, con el afinado AMPLIO de CabraStars
// (cpSfRefineAdql/Rows/Apply: id de Gaia, RV, GSP-Phot, XP) y los puntos del HR (cpSfHrPoints). Costuras marcadas
// «Cabra3D:» y «(CabraStars)». La cabecera original sigue.
// ============================================================================
// engine/starfield.js — EL CAMPO DE ESTRELLAS CON DISTANCIAS: la parte PURA
// ----------------------------------------------------------------------------
// Motor de datos de la vista de distancias de ANNOTATIONS (Cabra3D: sin el diagrama HR, que vive en CabraStars)
// (fase 1, 13-oct-2026). Este fichero es la ARITMETICA: no toca PixInsight, ni
// el disco, ni la red, ni la consola, ni `optT` — por eso node lo ejecuta entero
// y el nivel 0 le pasa sus casos con verdad (`_tests/cp_starfield_cases.js`). Lo
// que si toca todo eso (el proceso Gaia, los catalogos del disco, SIMBAD, VizieR,
// los pixeles de la imagen) vive en `engine/starfield_run.js`, que es quien da la
// API de una sola llamada, `cpStarfieldBuild( view, opts )`. EL CONTRATO PARA LA
// INTERFAZ ESTA EN LA CABECERA DE ESE FICHERO.
//
// DE DONDE SALE CADA NUMERO (regla: ninguno de memoria). La tabla `CP_SF` de
// abajo es la UNICA de constantes del modulo; cada una lleva su fuente, leida el
// 13-oct-2026:
//   · Tramos de error de las banderas Gold / Silver / Bronze del proceso Gaia:
//     `include/pcl/GaiaDatabaseFile.h` de PixInsight 1.9.5 (paralaje < 0,13 ·
//     [0,13, 0,86) · [0,86, 1,38) mas; movimiento propio en AR < 0,14 ·
//     [0,14, 0,97) · [0,97, 1,58) mas/año). Validados contra el archivo de ESA en
//     la investigacion (F8) y otra vez en la sonda de este modulo.
//   · «Paralaje / error > 5»: Bailer-Jones 2015 (PASP 127, 994; arXiv:1507.02105),
//     resumen: invertir la paralaje deja de ser trivial «once the fractional
//     parallax error is larger than about 20%». 20 % = 1/5.
//   · RUWE < 1,4: documentacion de Gaia DR2, tabla `ruwe` del archivo de ESA: «A
//     value significantly greater than 1.0 (say, >1.4) could indicate that the
//     source is non-single or otherwise problematic for the astrometric solution».
//   · Punto cero de la paralaje, -0,017 mas: Lindegren et al. 2021 (A&A 649, A4),
//     §1 y §4.1: mediana de los cuasares de EDR3 (la media ponderada es -0,021).
//   · Suelo sistematico de una paralaje MEDIA, 0,01 mas: Vasiliev y Baumgardt 2021
//     (MNRAS 505, 5978), resumen.
//   · Cosmologia: Planck 2018 (A&A 641, A6; arXiv:1807.06209), resumen: H0 = 67,4
//     ± 0,5 km/s/Mpc y Omega_m = 0,315 ± 0,007, LCDM plano.
//   · Velocidad peculiar, 240 km/s: Brout et al. 2022 (Pantheon+, arXiv:2202.04077),
//     §3.1.3. Es la dispersion que queda DESPUES de corregir por un modelo de
//     flujo; aqui no se corrige nada, asi que es una cota POR DEBAJO del error.
//   · Unidades: definiciones exactas (UA, IAU 2012 B2; parsec = 648000/pi UA, IAU
//     2015 B2; c; año juliano). El año luz sale de ellas, no de un numero copiado.
//   · Epoca de Gaia DR3, J2016,0 = DJ 2457389,0: `catalogEpoch` de la clase
//     `GaiaDR3XPSDCatalog` de la libreria de PixInsight (leido en la sonda).
// Lo que es DECISION DE DISEÑO y no sale de la literatura va marcado «diseño» en
// la tabla, y los tests lo ejercitan por los dos lados.
//
// TODO INTERNO EN PARSECS. La conversion a años luz es UNA funcion, `cpSfLy`.
// ES5 puro. Sin efectos: ninguna funcion de aqui modifica lo que recibe salvo las
// que lo dicen en su nombre (`…Apply`, `…Assign`).
// ============================================================================

// OJO CON LOS NOMBRES: `VERSION` y `TITLE` NO se pueden usar como identificadores
// en este programa. La libreria ImageSolver, que CabraPilot.js incluye, los define
// como macros (`#define VERSION "6.x"`), el preprocesador de PixInsight las
// sustituye en TODO lo que venga detras, y `CP_SF.VERSION` se convierte en
// `CP_SF."6.x"`: el fichero deja de compilar SIN UNA LINEA en ningun log (y una
// clave `VERSION: 1` de un literal compila… con otro nombre). Medido el 13-oct-2026;
// el guardian L0-91 lo vigila en todo `src/`.
var CP_SF = {
   RESULT_FORMAT: 1,             // la version de la forma del resultado (ver starfield_run.js)
   // --- unidades (exactas por definicion) -----------------------------------
   AU_M: 149597870700,           // UA en metros (IAU 2012 B2)
   C_M_S: 299792458,             // velocidad de la luz
   JULIAN_YEAR_S: 31557600,      // 365,25 dias de 86400 s
   GAIA_EPOCH_JD: 2457389.0,     // J2016,0, la epoca de las posiciones de Gaia DR3
   // --- banderas del proceso Gaia (pcl/GaiaDatabaseFile.h) ------------------
   FLAG_NO_PM: 0x00000001, FLAG_NO_BP: 0x00000002, FLAG_NO_RP: 0x00000004,
   FLAG_GOLD_PMRA: 0x00000040, FLAG_GOLD_PMDEC: 0x00000080,
   FLAG_SILVER_PMRA: 0x00000400, FLAG_SILVER_PMDEC: 0x00000800,
   FLAG_BRONZE_PMRA: 0x00004000, FLAG_BRONZE_PMDEC: 0x00008000,
   FLAG_GOLD_PARX: 0x00080000, FLAG_SILVER_PARX: 0x00800000, FLAG_BRONZE_PARX: 0x08000000,
   FLAG_BPRP_EXCESS: 0x10000000, FLAG_BPRP_EXCESS_HIGH: 0x20000000,
   PLX_ERR_MAX: { gold: 0.13, silver: 0.86, bronze: 1.38 },      // mas: cota SUPERIOR del error del tramo
   PM_ERR_MAX: { gold: 0.14, silver: 0.97, bronze: 1.58 },       // mas/año (la de AR, la mayor de las dos)
   // --- calidad de una distancia ---------------------------------------------
   MIN_PLX_SNR: 5,               // Bailer-Jones 2015: error relativo < 20 %
   MAX_FRACTION: 0.2,            // lo mismo, dicho como fraccion (para Bailer-Jones y para el corrimiento al rojo)
   MAX_RUWE: 1.4,                // documentacion de Gaia DR2
   PLX_ZERO_POINT: -0.017,       // mas, Lindegren et al. 2021
   PLX_MEAN_FLOOR: 0.01,         // mas, Vasiliev y Baumgardt 2021
   // --- cumulos (diseño, ejercitado en los tests) ---------------------------
   CL_MIN_MEMBERS: 10,           // diseño: el tamaño minimo de cumulo de Hunt y Reffert (su columna N es [10, …])
   CL_MIN_SIGNIFICANCE: 5,       // diseño: exceso sobre el fondo, en sigmas de Poisson
   CL_MIN_PURITY: 0.75,          // diseño: un tramo de calidad cuyo fondo pasa del 25 % no da miembros
   CL_PM_SIGMAS: 2.5,            // diseño: radio de aceptacion en movimiento propio (95,6 % de una gaussiana 2D)
   CL_CORE_MIN: 30,              // diseño: estrellas del nucleo para MEDIR la dispersion de un tramo
   CL_PLX_SIGMAS: 3,             // diseño: una paralaje a mas de 3 cotas de la del cumulo no es miembro
   // --- cosmologia (Planck 2018, LCDM plano) ---------------------------------
   H0: 67.4, OMEGA_M: 0.315,
   COSMOLOGY: "flat LCDM, H0 = 67.4 km/s/Mpc, Omega_m = 0.315 (Planck 2018, A&A 641, A6)",
   VPEC_KMS: 240,                // Brout et al. 2022: cota por debajo del error de un corrimiento al rojo sin corregir
   MAX_BAR_RATIO: 10,            // (26-oct-2026, F1b de Nino) un corrimiento cuyo extremo alto de distancia pasa de 10 veces el bajo (hi/lo) NO da distancia: la barra no dice nada
   // --- fotometria en la imagen (diseño, medido en la sonda) ----------------
   PHOT_MIN_CAL: 20,             // diseño: estrellas minimas para calibrar
   PHOT_MIN_SNR: 20,             // diseño: señal / ruido minima de una estrella de calibracion (en el canal mas debil)
   PHOT_SLOPE_TOL: 0.05,         // diseño: una imagen LINEAL da pendiente 1 de magnitud medida frente a G (ver la sonda)
   PHOT_MAX_COLOR_SIGMA: 0.15,   // diseño: dispersion maxima de BP-RP recuperado para dar el color por bueno (mag)
   // El sesgo maximo de un tramo de color (0,5 mag de BP-RP) para que el color de la foto valga en el. Diseño: dos
   // veces la dispersion tipica de una estrella (0,05, medida). Medido en cuatro imagenes reales (sonda del
   // 13-oct-2026): donde la recta vale el sesgo es de 0,043 o menos; donde deja de valer, de 0,127 a 0,67.
   PHOT_MAX_COLOR_BIAS: 0.1,
   // Diseño: cuantas sigmas puede irse la magnitud medida en la foto de la G de Gaia antes de dar la medida por
   // MALA (apertura descolocada, saturada sin llegar al tope, una vecina que Gaia no tiene). La sigma de cada
   // estrella es la del ajuste de la magnitud mas su ruido (2,5 / ln 10 / señal-ruido). Medido en la sonda del
   // 13-oct-2026 (RGB de tres masteres): de los 10 puntos con señal a mas de 1 mag por debajo de la secuencia
   // principal, 8 tenian la magnitud de 0,5 a 5,2 mag mas debil que la de Gaia; los otros 2 casaban a 0,02.
   PHOT_MAG_SIGMAS: 5,
   // (29-oct, Codex R3 H-1) Lo mismo con el COLOR: una estrella cuyo color medido se aparta del BP-RP de Gaia mas de
   // PHOT_MAG_SIGMAS por la dispersion de la recta de color y el ruido del color no se usa ("colour-mismatch"). false = el
   // comportamiento de antes (solo para el control en rojo de las pruebas).
   PHOT_COLOUR_CHECK: true,
   PHOT_CLIP: 3                 // diseño: recorte de la regresion robusta, en sigmas
};

// ---------------------------------------------------------------------------
// UNIDADES. Todo el modulo trabaja en parsecs; esto es lo UNICO que convierte.
// ---------------------------------------------------------------------------
function cpSfParsecMetres() { return CP_SF.AU_M * 648000 / Math.PI; }
function cpSfLightYearMetres() { return CP_SF.C_M_S * CP_SF.JULIAN_YEAR_S; }

// Parsecs -> años luz.
function cpSfLy(pc) { return pc * cpSfParsecMetres() / cpSfLightYearMetres(); }

// Una distancia en la unidad pedida ("pc" o "ly"). Cualquier otra cosa, parsecs.
function cpSfDistanceIn(pc, unit) { return (unit === "ly") ? cpSfLy(pc) : pc; }

// Magnitud absoluta a partir de la aparente y la distancia. SIN extincion.
function cpSfAbsMag(mag, pc) {
   if (!isFinite(mag) || !(pc > 0)) return null;
   return mag - 5 * (Math.log(pc / 10) / Math.LN10);
}

// ---------------------------------------------------------------------------
// LAS BANDERAS -> en que tramo cae el error
// ---------------------------------------------------------------------------
function cpSfPlxTier(flags) {
   var f = flags >>> 0;
   if (f & CP_SF.FLAG_NO_PM) return "";
   if (f & CP_SF.FLAG_GOLD_PARX) return "gold";
   if (f & CP_SF.FLAG_SILVER_PARX) return "silver";
   if (f & CP_SF.FLAG_BRONZE_PARX) return "bronze";
   return "";
}

// El tramo del movimiento propio: el PEOR de los dos ejes.
function cpSfPmTier(flags) {
   var f = flags >>> 0;
   if (f & CP_SF.FLAG_NO_PM) return "";
   var ra = (f & CP_SF.FLAG_GOLD_PMRA) ? 1 : (f & CP_SF.FLAG_SILVER_PMRA) ? 2 : (f & CP_SF.FLAG_BRONZE_PMRA) ? 3 : 0;
   var de = (f & CP_SF.FLAG_GOLD_PMDEC) ? 1 : (f & CP_SF.FLAG_SILVER_PMDEC) ? 2 : (f & CP_SF.FLAG_BRONZE_PMDEC) ? 3 : 0;
   if (ra === 0 || de === 0) return "";
   var worst = Math.max(ra, de);
   return (worst === 1) ? "gold" : (worst === 2) ? "silver" : "bronze";
}

// ---------------------------------------------------------------------------
// UNA FILA DEL PROCESO Gaia -> una estrella del motor
// ----------------------------------------------------------------------------
// `row` = [ra, dec, paralaje, pmra, pmdec, G, BP, RP, banderas] (la salida
// binaria del proceso; del CSV salen las mismas nueve). Lo que el catalogo no
// tiene llega como null, NUNCA como 0: una paralaje 0 pintaria una estrella en
// el infinito y un BP 0 una estrella azulisima.
// `years` = años desde J2016,0 hasta la fecha de la imagen (0 = no mover).
// ---------------------------------------------------------------------------
function cpSfStarFromRow(row, years) {
   var f = Number(row[8]) >>> 0;
   var noPm = (f & CP_SF.FLAG_NO_PM) !== 0;
   function val(v, missing) { var n = Number(v); return (missing || v === null || v === undefined || v === "" || !isFinite(n)) ? null : n; }
   var s = {
      ra0: Number(row[0]), dec0: Number(row[1]), ra: Number(row[0]), dec: Number(row[1]),
      x: null, y: null, inFrame: false,
      g: val(row[5], false), bp: val(row[6], (f & CP_SF.FLAG_NO_BP) !== 0), rp: val(row[7], (f & CP_SF.FLAG_NO_RP) !== 0), bpRp: null,
      plx: val(row[2], noPm), pmRa: val(row[3], noPm), pmDec: val(row[4], noPm),
      flags: f, plxTier: cpSfPlxTier(f), pmTier: cpSfPmTier(f), plxErrMax: null,
      colorSuspect: (f & (CP_SF.FLAG_BPRP_EXCESS | CP_SF.FLAG_BPRP_EXCESS_HIGH)) !== 0,
      plxErr: null, ruwe: null,
      dist: null, cluster: -1, absG: null, phot: null
   };
   if (s.bp !== null && s.rp !== null) s.bpRp = s.bp - s.rp;
   if (s.plxTier !== "") s.plxErrMax = CP_SF.PLX_ERR_MAX[s.plxTier];
   if (years && s.pmRa !== null && s.pmDec !== null) {
      var p = cpSfPropagate(s.ra0, s.dec0, s.pmRa, s.pmDec, years);
      s.ra = p.ra; s.dec = p.dec;
   }
   return s;
}

// La posicion `years` años despues, con el movimiento propio (mas/año; el de AR
// ya viene multiplicado por cos(dec), como lo da Gaia). Lineal: vale para ICRS.
// (27-oct-2026, T2 H-1 de Codex) Por VECTOR UNITARIO: la direccion + el desplazamiento en las bases tangentes de Gaia (este, norte), normalizada
// y vuelta a AR/Dec. La version anterior sumaba pm/cos(dec) a la AR y pm a la Dec POR SEPARADO: en el polo (cos = 0) perdia todo el movimiento y
// cerca de el (dec 89,9999) dejaba la AR fuera de dominio (1241°). Para una estrella normal (pm de decenas de mas/año) la diferencia es < 1e-6″.
// Sin movimiento (o sin tiempo) devuelve la misma posicion, solo con la AR en [0,360).
function cpSfPropagate(ra, dec, pmRa, pmDec, years) {
   var r0 = ra % 360; if (r0 < 0) r0 += 360;
   if (!years || (!pmRa && !pmDec)) return { ra: r0, dec: dec };
   var k = Math.PI / 180, a = r0 * k, d = dec * k, t = years * k / 3.6e6;
   var sa = Math.sin(a), ca = Math.cos(a), sd = Math.sin(d), cd = Math.cos(d);
   var pe = pmRa * t, pn = pmDec * t;
   var wx = cd * ca + pe * (-sa) + pn * (-sd * ca), wy = cd * sa + pe * ca + pn * (-sd * sa), wz = sd + pn * cd;
   var r = Math.atan2(wy, wx) / k; if (r < 0) r += 360; if (r >= 360) r -= 360;
   return { ra: r, dec: Math.atan2(wz, Math.sqrt(wx * wx + wy * wy)) / k };
}

// Separacion angular en grados (haversine: vale junto al polo y con campos grandes).
function cpSfSeparation(ra1, dec1, ra2, dec2) {
   var k = Math.PI / 180;
   var sd = Math.sin((dec2 - dec1) * k / 2), sa = Math.sin((ra2 - ra1) * k / 2);
   var h = sd * sd + Math.cos(dec1 * k) * Math.cos(dec2 * k) * sa * sa;
   return 2 * Math.asin(Math.min(1, Math.sqrt(h))) / k;
}

// ---------------------------------------------------------------------------
// LA DISTANCIA DE UNA ESTRELLA SUELTA
// ----------------------------------------------------------------------------
// CON LO LOCAL (sin red): la regla GARANTIZADA. La base local no trae el error
// de la paralaje, solo en que tramo cae; se exige paralaje / COTA SUPERIOR del
// tramo > 5, que implica paralaje / error real > 5. Medido en el campo de M 13
// (investigacion, F9): pasan 879 y las 879 son correctas; una regla con el error
// «tipico» del tramo pasaba 3079 con un 58 % de acierto. El intervalo usa la
// misma cota: es un intervalo de MAS de 1 sigma, y se dice (`interval`).
// El punto cero de la paralaje NO se aplica aqui: a 0,65 mas (lo mas lejano que
// deja pasar el tramo Gold) son 0,017 / 0,65 = 2,6 % de la distancia, muy por
// debajo de la cota del error (20 %). `zeroPoint: false` lo deja escrito.
// ---------------------------------------------------------------------------
function cpSfLocalDistance(plx, tier) {
   var errMax = CP_SF.PLX_ERR_MAX[tier];
   if (!(errMax > 0) || !(plx > 0))
      return null;
   if (!(plx / errMax > CP_SF.MIN_PLX_SNR))
      return null;
   return { pc: 1000 / plx, lo: 1000 / (plx + errMax), hi: 1000 / (plx - errMax),
            source: "parallax-local", quality: "good", interval: "bound", fraction: errMax / plx, zeroPoint: false, ref: "Gaia DR3" };
}

// CON LA RED (VizieR): el error REAL, RUWE y la distancia de Bailer-Jones et al.
// 2021 (`rgeo` con su intervalo del 16 al 84 %). `r` = { plx, plxErr, ruwe, rgeo,
// rgeoLo, rgeoHi }. Devuelve null si ni asi hay una distancia de fiar.
// Bailer-Jones manda cuando su intervalo es mas estrecho que el 20 %: lleva
// dentro el punto cero y no esta sesgada; si no viene, 1 / paralaje con su error.
// RUWE >= 1,4 NO borra la distancia: la marca («suspect»), porque el dato sigue
// siendo lo mejor que hay de esa estrella y quien pinta decide si la enseña.
function cpSfRefinedDistance(r) {
   if (!r) return null;
   var d = null;
   if (r.rgeo > 0 && r.rgeoLo > 0 && r.rgeoHi >= r.rgeoLo && (r.rgeoHi - r.rgeoLo) / (2 * r.rgeo) < CP_SF.MAX_FRACTION)
      d = { pc: r.rgeo, lo: r.rgeoLo, hi: r.rgeoHi, source: "bailer-jones", interval: "16-84", fraction: (r.rgeoHi - r.rgeoLo) / (2 * r.rgeo),
            zeroPoint: true, ref: "Bailer-Jones et al. 2021 (rgeo)" };
   else if (r.plx > 0 && r.plxErr > 0 && (r.plx - CP_SF.PLX_ZERO_POINT) / r.plxErr > CP_SF.MIN_PLX_SNR) {
      // (27-oct-2026, R4: T2 H-4 de Codex) CON el punto cero de Lindegren (-0,017 mas): sin el sesgaba +1,7 % a 1 kpc y +3,5 % a 2 kpc. Es lo mismo
      // que hace la paralaje media de los grupos (csh_starfield_run.js). lo/hi: a MAS paralaje, MENOS distancia (lo con pz + err, hi con pz - err).
      var pz = r.plx - CP_SF.PLX_ZERO_POINT;
      d = { pc: 1000 / pz, lo: 1000 / (pz + r.plxErr), hi: 1000 / (pz - r.plxErr), source: "parallax-online", interval: "1-sigma",
            fraction: r.plxErr / pz, zeroPoint: true, ref: "Gaia DR3 (zero point -0.017 mas, Lindegren et al. 2021)" };
   }
   if (d === null) return null;
   d.quality = (isFinite(r.ruwe) && r.ruwe !== null && r.ruwe >= CP_SF.MAX_RUWE) ? "suspect" : "good";
   return d;
}

// ---------------------------------------------------------------------------
// TEXTO TABULADO: los catalogos empaquetados (separados por «;», con cabecera de
// comentarios «# …») y las respuestas CSV de los servicios (separadas por «,»,
// con comillas). Devuelve { cols, rows, meta }: cada fila es un objeto por nombre
// de columna con el TEXTO tal cual; `meta` son los «clave=valor» de los comentarios.
// ---------------------------------------------------------------------------
function cpSfSplitCsvLine(line, sep) {
   var out = [], cur = "", inQ = false;
   for (var i = 0; i < line.length; ++i) {
      var ch = line.charAt(i);
      if (inQ) {
         if (ch === "\"") {
            if (line.charAt(i + 1) === "\"") { cur += "\""; ++i; }
            else inQ = false;
         } else cur += ch;
      } else if (ch === "\"") inQ = true;
      else if (ch === sep) { out.push(cur); cur = ""; }
      else cur += ch;
   }
   out.push(cur);
   return out;
}

function cpSfParseTable(text, sep) {
   var out = { cols: [], rows: [], meta: {} };
   if (typeof text !== "string" || text.length === 0) return out;
   var lines = text.split("\n"), delim = sep || ";", yieldOk = (typeof cshYield === "function");
   for (var i = 0; i < lines.length; ++i) {
      if (yieldOk && (i & 31) === 31) cshYield();               // (Cabra3D, 22-oct: la interfaz, atendida en las tablas largas: csh_net.js)
      var line = lines[i];
      if (line.length > 0 && line.charAt(line.length - 1) === "\r") line = line.substring(0, line.length - 1);
      if (line.length === 0) continue;
      if (line.charAt(0) === "#") {
         var m = /^#\s*([A-Za-z][A-Za-z0-9_]*)=([^\s]+)/.exec(line);
         if (m) out.meta[m[1]] = m[2];
         continue;
      }
      // (sin comillas en la linea, partirla por el separador da EXACTAMENTE lo mismo que el recorrido caracter a caracter, y
      // 5-10 veces mas deprisa: las filas de numeros de VizieR y SIMBAD no llevan comillas)
      var cells = (line.indexOf("\"") < 0) ? line.split(delim) : cpSfSplitCsvLine(line, delim);
      if (out.cols.length === 0) { out.cols = cells; continue; }
      var row = {};
      for (var c = 0; c < out.cols.length; ++c) row[out.cols[c]] = (c < cells.length) ? cells[c] : "";
      out.rows.push(row);
   }
   return out;
}

// Un numero de una celda, o null si esta vacia o no es un numero.
function cpSfNum(text) {
   if (text === null || text === undefined) return null;
   var s = String(text).replace(/^\s+|\s+$/g, "");
   if (s.length === 0) return null;
   var v = Number(s);
   return isFinite(v) ? v : null;
}

// ---------------------------------------------------------------------------
// LOS CATALOGOS DE CUMULOS, ya leidos (ver `src/data/starfield/PROVENANCE.txt`)
// ----------------------------------------------------------------------------
// De cada fila sale un cumulo con la MISMA forma, venga de donde venga:
//   { id, name, kind, catalog, ra, dec, pmRa, pmDec, pmSigma, coreRadius,
//     selRadius, dist: { pc, lo, hi, source, ref, interval }, aliases, extra }
// GLOBULARES: la distancia es la de Baumgardt y Vasiliev 2021 con su error; si el
// cumulo solo esta en Harris (2010), la de Harris, y como Harris NO da errores el
// intervalo es la dispersion MEDIDA entre las dos listas en los 151 comunes
// (`harrisSigma` de la cabecera del fichero: 6,9 %), y se dice (`interval`).
// ABIERTOS: Hunt y Reffert 2023, percentiles 16-50-84 de su distancia de maxima
// verosimilitud. Ese intervalo es SOLO ESTADISTICO (las Pleyades salen a ±0,02
// pc): se le suma en cuadratura el suelo sistematico de una paralaje media, 0,01
// mas (Vasiliev y Baumgardt 2021), que a 135 pc son 0,2 pc y a 4 kpc un 4 %.
// ---------------------------------------------------------------------------
function cpSfGlobularFromRow(r, harrisSigma) {
   var ra = cpSfNum(r.ra), dec = cpSfNum(r.dec);
   if (ra === null || dec === null) return null;
   var dB = cpSfNum(r.rsunB), eB = cpSfNum(r.eRsunB), dH = cpSfNum(r.rsunH);
   var dist = null;
   if (dB !== null && dB > 0)
      dist = { pc: dB * 1000, lo: (dB - (eB || 0)) * 1000, hi: (dB + (eB || 0)) * 1000, source: "cluster-catalog", interval: "1-sigma",
               ref: "Baumgardt & Vasiliev 2021" };
   else if (dH !== null && dH > 0) {
      var k = (harrisSigma > 0) ? harrisSigma : 0;
      dist = { pc: dH * 1000, lo: dH * 1000 * Math.exp(-k), hi: dH * 1000 * Math.exp(k), source: "cluster-catalog",
               interval: (k > 0) ? "catalogue scatter" : "none", ref: "Harris 1996 (2010 edition)" };
   }
   var rc = cpSfNum(r.rc), rh = cpSfNum(r.rh), c = cpSfNum(r.c), r50 = cpSfNum(r.r50), rt = cpSfNum(r.rt);
   // El radio de marea de King: r_t = r_c · 10^c (Harris, columna 7 de la parte III).
   var tidal = (rt !== null && rt > 0) ? rt : (rc !== null && c !== null) ? (rc * Math.pow(10, c)) / 60 : null;
   var core = (r50 !== null && r50 > 0) ? r50 : (rh !== null && rh > 0) ? rh / 60 : null;
   var name = String(r.name || "");
   return { id: String(r.id), name: (name.length > 0) ? name : String(r.id), kind: "globular", catalog: "globulars", ra: ra, dec: dec,
            pmRa: cpSfNum(r.pmra), pmDec: cpSfNum(r.pmdec), pmSigma: cpSfNum(r.spm), coreRadius: core, selRadius: tidal, dist: dist,
            aliases: (name.length > 0) ? [String(r.id)] : [],
            extra: { harrisPc: (dH !== null) ? dH * 1000 : null, ebv: cpSfNum(r.ebv) } };
}

function cpSfOpenFromRow(r) {
   var ra = cpSfNum(r.ra), dec = cpSfNum(r.dec), d50 = cpSfNum(r.d50);
   if (ra === null || dec === null) return null;
   var dist = null;
   if (d50 !== null && d50 > 0) {
      var d16 = cpSfNum(r.d16), d84 = cpSfNum(r.d84);
      var sys = d50 * (CP_SF.PLX_MEAN_FLOOR * d50 / 1000);      // 0,01 mas a la distancia d50: sigma_d = d^2 · sigma_plx
      var lo = (d16 !== null) ? d50 - d16 : 0, hi = (d84 !== null) ? d84 - d50 : 0;
      dist = { pc: d50, lo: d50 - Math.sqrt(lo * lo + sys * sys), hi: d50 + Math.sqrt(hi * hi + sys * sys), source: "cluster-catalog",
               interval: "16-84 + 0.01 mas systematic", ref: "Hunt & Reffert 2023" };
   }
   var spa = cpSfNum(r.spmra), spd = cpSfNum(r.spmdec);
   var names = String(r.aliases || "").split(","), aliases = [];
   for (var i = 0; i < names.length; ++i) if (names[i].length > 0) aliases.push(names[i].replace(/_/g, " "));
   var t = String(r.type || "o");
   return { id: String(r.name).replace(/_/g, " "), name: cpSfClusterNiceName(String(r.name).replace(/_/g, " "), aliases),
            kind: (t === "g") ? "globular" : (t === "m") ? "moving-group" : "open", catalog: "hunt-reffert-2023", ra: ra, dec: dec,
            pmRa: cpSfNum(r.pmra), pmDec: cpSfNum(r.pmdec),
            pmSigma: (spa !== null && spd !== null) ? Math.sqrt((spa * spa + spd * spd) / 2) : null,
            coreRadius: cpSfNum(r.r50), selRadius: cpSfNum(r.rt), dist: dist, aliases: aliases,
            extra: { members: cpSfNum(r.n), cst: cpSfNum(r.cst), cmdClass: cpSfNum(r.cmd), av: cpSfNum(r.av), logAge: cpSfNum(r.age),
                     plx: cpSfNum(r.plx) } };
}

// El nombre que se enseña: Messier si lo tiene, si no el nombre propio, si no el del catalogo.
function cpSfClusterNiceName(id, aliases) {
   var i;
   for (i = 0; i < aliases.length; ++i) if (/^M\d+$/.test(aliases[i])) return "M " + aliases[i].substring(1);
   for (i = 0; i < aliases.length; ++i) if (/^[A-Za-z][A-Za-z ]+$/.test(aliases[i])) return aliases[i];
   return id;
}

// Las dos tablas (texto) -> la lista de cumulos del motor.
function cpSfClusterCatalog(globularsText, openText) {
   var out = [], i, cl;
   var g = cpSfParseTable(globularsText, ";"), o = cpSfParseTable(openText, ";");
   var hs = cpSfNum(g.meta.harrisSigma);
   for (i = 0; i < g.rows.length; ++i) { cl = cpSfGlobularFromRow(g.rows[i], hs); if (cl) out.push(cl); }
   for (i = 0; i < o.rows.length; ++i) { cl = cpSfOpenFromRow(o.rows[i]); if (cl) out.push(cl); }
   return out;
}

// Los cumulos del catalogo que PUEDEN tener estrellas en un campo circular: el
// centro a menos de (radio del campo + radio de seleccion del cumulo). Que
// esten DE VERDAD lo decide `cpSfClusterMembers` con las estrellas delante.
function cpSfClustersNear(catalog, ra, dec, radiusDeg) {
   var out = [];
   for (var i = 0; i < catalog.length; ++i) {
      var c = catalog[i];
      var reach = radiusDeg + ((c.selRadius > 0) ? c.selRadius : (c.coreRadius > 0) ? 3 * c.coreRadius : 0.25);
      if (Math.abs(c.dec - dec) > reach) continue;
      if (cpSfSeparation(ra, dec, c.ra, c.dec) <= reach) out.push(c);
   }
   return out;
}

// ---------------------------------------------------------------------------
// ESTADISTICA ROBUSTA, la justa
// ---------------------------------------------------------------------------
// (F2, 22-oct-2026) MAS DEPRISA, EL MISMO NUMERO: la mediana ya no ordena una copia con un comparador (`slice().sort(fn)`,
// lo que mas pesaba en los cumulos de un campo denso) sino que copia a un Float64Array y SELECCIONA el elemento central
// (quickselect de Hoare, sin ordenar el resto). Con numeros finitos el valor es EXACTAMENTE el mismo (el k-esimo de un
// conjunto no depende de como se busque; para n par, el mayor de la mitad baja). Con cualquier cosa que no sea un numero
// finito (NaN, null, texto, ±Infinity) se usa el camino de antes, tal cual: alli el orden con NaN no esta definido y no se
// toca. Medido y comprobado en CabraStars/tests/cs_test_f2.js (huella del campo identica; rojo CS_BREAK=median).
var CSH_MEDIAN_FAST = true;              // false: el camino de antes siempre (las pruebas lo comparan)
function cpSfMedianSlow(values) {
   var a = values.slice().sort(function(p, q) { return p - q; });
   var m = a.length >> 1;
   return (a.length % 2) ? a[m] : (a[m - 1] + a[m]) / 2;
}
// El k-esimo menor (0 = el menor) de `a` (Float64Array), reordenandolo en su sitio.
function cshSelectK(a, k) {
   var lo = 0, hi = a.length - 1;
   while (hi > lo) {
      var pv = a[(lo + hi) >> 1], i = lo, j = hi;
      while (i <= j) {
         while (a[i] < pv) ++i;
         while (a[j] > pv) --j;
         if (i <= j) { var t = a[i]; a[i] = a[j]; a[j] = t; ++i; --j; }
      }
      if (k <= j) hi = j; else if (k >= i) lo = i; else return a[k];
   }
   return a[k];
}
// Mediana de un Float64Array de numeros finitos (lo reordena)
function cshMedianF64(a) {
   var n = a.length, m = n >> 1, hi = cshSelectK(a, m);
   if (n % 2) return hi;
   var lo = a[0];
   for (var i = 1; i < m; ++i) if (a[i] > lo) lo = a[i];                 // (tras seleccionar, a[0..m-1] <= a[m]: el mayor de la mitad baja)
   return (lo + hi) / 2;
}
// -> Float64Array con los valores, o null si alguno no es un numero finito
function cshFiniteF64(values) {
   var n = values.length, a = new Float64Array(n);
   for (var i = 0; i < n; ++i) {
      var v = values[i];
      if (typeof v !== "number" || !isFinite(v)) return null;
      if (v === 0 && 1 / v < 0) return null;                          // (un −0: el orden de antes conservaba su sitio; por el camino de antes)
      a[i] = v;
   }
   return a;
}
function cpSfMedian(values) {
   if (!values || values.length === 0) return NaN;
   if (CSH_MEDIAN_FAST === true) { var a = cshFiniteF64(values); if (a !== null) return cshMedianF64(a); }
   return cpSfMedianSlow(values);
}

// Sigma robusta: 1,4826 · MAD respecto a `center` (o a la mediana).
function cpSfRobustSigma(values, center) {
   if (!values || values.length === 0) return NaN;
   var c = (center === undefined) ? cpSfMedian(values) : center;
   if (CSH_MEDIAN_FAST === true && typeof c === "number" && isFinite(c)) {
      var a = cshFiniteF64(values);
      if (a !== null) { for (var k = 0; k < a.length; ++k) a[k] = Math.abs(a[k] - c); return 1.4826 * cshMedianF64(a); }
   }
   var d = [];
   for (var i = 0; i < values.length; ++i) d.push(Math.abs(values[i] - c));
   return 1.4826 * cpSfMedian(d);
}

// Recta robusta y = a + b·x: minimos cuadrados con recorte iterado a `clip`
// sigmas robustas. Con `fixedSlope` (un numero) solo ajusta el termino a.
// Devuelve { ok, a, b, sigma, n, used: [indices] }.
function cpSfRobustLine(xs, ys, clip, fixedSlope) {
   var out = { ok: false, a: 0, b: (fixedSlope !== undefined) ? fixedSlope : 0, sigma: NaN, n: 0, used: [] };
   var n = Math.min(xs.length, ys.length), use = [], i;
   for (i = 0; i < n; ++i) if (isFinite(xs[i]) && isFinite(ys[i])) use.push(i);
   var k = (clip > 0) ? clip : 3;
   for (var it = 0; it < 8; ++it) {
      if (use.length < 3) return out;
      var a, b;
      if (fixedSlope !== undefined) {
         var res0 = [];
         for (i = 0; i < use.length; ++i) res0.push(ys[use[i]] - fixedSlope * xs[use[i]]);
         b = fixedSlope; a = cpSfMedian(res0);
      } else {
         var sx = 0, sy = 0, sxx = 0, sxy = 0, m = use.length;
         for (i = 0; i < m; ++i) { var x = xs[use[i]], y = ys[use[i]]; sx += x; sy += y; sxx += x * x; sxy += x * y; }
         var den = m * sxx - sx * sx;
         if (!(Math.abs(den) > 1e-12)) return out;
         b = (m * sxy - sx * sy) / den; a = (sy - b * sx) / m;
      }
      var res = [];
      for (i = 0; i < use.length; ++i) res.push(ys[use[i]] - a - b * xs[use[i]]);
      var sigma = cpSfRobustSigma(res, 0);
      out.a = a; out.b = b; out.sigma = sigma; out.n = use.length; out.used = use.slice(); out.ok = true;
      if (!(sigma > 0)) return out;
      var keep = [];
      for (i = 0; i < use.length; ++i) if (Math.abs(res[i]) <= k * sigma) keep.push(use[i]);
      if (keep.length === use.length) return out;
      use = keep;
   }
   return out;
}

// Plano robusto y = a + b1·x1 + b2·x2: minimos cuadrados (ecuaciones normales
// 3x3, regla de Cramer) con recorte iterado a `clip` sigmas robustas.
// Devuelve { ok, a, b1, b2, sigma, n }.
function cpSfRobustPlane(x1, x2, ys, clip) {
   var out = { ok: false, a: 0, b1: 0, b2: 0, sigma: NaN, n: 0 };
   var n = Math.min(x1.length, x2.length, ys.length), use = [], i;
   for (i = 0; i < n; ++i) if (isFinite(x1[i]) && isFinite(x2[i]) && isFinite(ys[i])) use.push(i);
   var k = (clip > 0) ? clip : 3;
   function det3(m) {
      return m[0] * (m[4] * m[8] - m[5] * m[7]) - m[1] * (m[3] * m[8] - m[5] * m[6]) + m[2] * (m[3] * m[7] - m[4] * m[6]);
   }
   for (var it = 0; it < 8; ++it) {
      if (use.length < 5) return out;
      var S = [0, 0, 0, 0, 0, 0, 0, 0, 0], T = [0, 0, 0], m = use.length;
      for (i = 0; i < m; ++i) {
         var p = x1[use[i]], q = x2[use[i]], y = ys[use[i]];
         S[0] += 1; S[1] += p; S[2] += q; S[4] += p * p; S[5] += p * q; S[8] += q * q;
         T[0] += y; T[1] += p * y; T[2] += q * y;
      }
      S[3] = S[1]; S[6] = S[2]; S[7] = S[5];
      var D = det3(S);
      if (!(Math.abs(D) > 1e-12 * m * m * m)) return out;
      var a = det3([T[0], S[1], S[2], T[1], S[4], S[5], T[2], S[7], S[8]]) / D;
      var b1 = det3([S[0], T[0], S[2], S[3], T[1], S[5], S[6], T[2], S[8]]) / D;
      var b2 = det3([S[0], S[1], T[0], S[3], S[4], T[1], S[6], S[7], T[2]]) / D;
      var res = [];
      for (i = 0; i < m; ++i) res.push(ys[use[i]] - a - b1 * x1[use[i]] - b2 * x2[use[i]]);
      var sigma = cpSfRobustSigma(res, 0);
      out.ok = true; out.a = a; out.b1 = b1; out.b2 = b2; out.sigma = sigma; out.n = m;
      if (!(sigma > 0)) return out;
      var keep = [];
      for (i = 0; i < m; ++i) if (Math.abs(res[i]) <= k * sigma) keep.push(use[i]);
      if (keep.length === m) return out;
      use = keep;
   }
   return out;
}

// ---------------------------------------------------------------------------
// LOS MIEMBROS DE UN CUMULO DEL CATALOGO, por movimiento propio comun
// ----------------------------------------------------------------------------
// POR QUE NO POR PARALAJE. En M 13 solo el 4,8 % de las estrellas tiene paralaje
// fiable y casi ninguna es del cumulo; la paralaje MEDIA de sus miembros da un 21
// % de mas (9012 pc frente a 7420; medido). El movimiento propio si separa: los
// miembros comparten el del cumulo y las estrellas del campo no.
//
// COMO (todo sale de las estrellas que se le dan, mas la fila del catalogo):
//   1. EL CENTRO en movimiento propio es el DEL CATALOGO, y no se mueve. (La
//      primera version lo «afinaba» con la mediana de lo que caia cerca: en el
//      campo de M 13 el grupo movil HSC 453, catalogado a (-41,6; +4,3), acabo
//      sobre el movimiento propio de M 13 y se confirmo con sus estrellas.) El
//      medido con los miembros se da aparte, como contraste (`pm.ra`, `pm.dec`).
//   2. LA TOLERANCIA, POR TRAMO de calidad del movimiento propio (Gold / Silver /
//      Bronze): 2,5 sigmas, con la sigma MEDIDA en el nucleo del cumulo cuando hay
//      30 estrellas del tramo, y si no la cota del tramo sumada a la dispersion del
//      catalogo. Asi las estrellas debiles no entran con la vara de las brillantes
//      ni al reves, y no hace falta ninguna tabla de errores escrita a mano.
//   3. LA PARALAJE COMO VETO, no como criterio: una estrella cuya paralaje esta a
//      mas de 3 cotas de la del cumulo (mas el fondo del propio cumulo) es del
//      campo aunque comparta movimiento propio. Se aplica igual al fondo.
//   4. EL FONDO, MEDIDO, de dos maneras; cada una da una cota POR ARRIBA y vale
//      la menor de las que se puedan calcular (`tiers.<tramo>.mode` dice cual):
//      · "sky": con las estrellas del mismo tramo que quedan FUERA del cumulo en
//        el cielo (mas alla de su radio de seleccion, o el tercio mas alejado si
//        el encuadre no llega): la fraccion f de ellas que pasa el corte de
//        movimiento propio es la del campo, y de las que NO lo pasan dentro del
//        cumulo se deduce cuantas del campo si lo pasan, f / (1 - f). Si en esa
//        zona quedan miembros f sale alta (M 67 en un campo de 0,6 grados: su
//        radio de marea llega al borde, y esta sola cuenta lo dejaba sin confirmar).
//      · "ring": el anillo de IGUAL AREA justo fuera del circulo de tolerancia; se
//        lleva la cola de los miembros (el 4 %). SOLO vale si el circulo es
//        pequeño frente al grueso del campo (`cpSfRingIsFair`, mas abajo). Sin esa
//        condicion el anillo MIENTE: un circulo tan ancho como el grueso del campo
//        se queda con su maximo y el anillo con su falda, y cualquier campo parece
//        un cumulo (asi se «confirmaron» NGC 6996, Teutsch 22, UPK 127 y CWNU 2619
//        en Cygnus con 2823, 370, 271 y 99 estrellas de tramo Bronze, y el grupo
//        movil HSC 453 en el campo de M 92; medido).
//      · "none": ni lo uno ni lo otro (un cumulo que llena el encuadre y es casi
//        todo lo que hay en el). El tramo no da miembros.
//      La pureza que sale es, por tanto, una cota POR ABAJO. Un tramo cuya pureza
//      no llega al 75 % no da miembros.
//   5. EL VEREDICTO: confirmado con 10 miembros o mas y un exceso sobre el fondo
//      de 5 sigmas de Poisson. Un cumulo del catalogo que no se confirma NO da
//      distancia a ninguna estrella.
//
// `stars`: las del motor (necesita ra, dec, pmRa, pmDec, pmTier, plx, plxErrMax).
// `cl`: un cumulo de `cpSfClusterCatalog`. Devuelve
//   { confirmed, code, members: [indices], n, background, purity, significance,
//     region, pm: { ra, dec, catalogRa, catalogDec }, tiers: { gold: {…}, … },
//     plxVetoed, parallax: { n, mean, error, pc, pcZeroPoint } }
// `code` cuando no se confirma: "no-catalog-pm" · "no-stars" · "no-control" (ningun
// tramo tiene con que medir su fondo) · "too-few" · "not-significant".
// ---------------------------------------------------------------------------
function cpSfClusterMembers(stars, cl, opts) {
   var o = opts || {};
   var out = { confirmed: false, code: "", members: [], n: 0, background: 0, purity: 0, significance: 0, region: 0,
               pm: { ra: null, dec: null, catalogRa: cl.pmRa, catalogDec: cl.pmDec }, tiers: {}, plxVetoed: 0, parallax: null };
   if (cl.pmRa === null || cl.pmDec === null || !isFinite(cl.pmRa) || !isFinite(cl.pmDec)) { out.code = "no-catalog-pm"; return out; }
   var sel = (cl.selRadius > 0) ? cl.selRadius : (cl.coreRadius > 0) ? 3 * cl.coreRadius : 0.25;
   var core = (cl.coreRadius > 0) ? Math.min(cl.coreRadius, sel) : sel / 3;
   var minMembers = (o.minMembers > 0) ? o.minMembers : CP_SF.CL_MIN_MEMBERS;
   var minSig = (o.minSignificance > 0) ? o.minSignificance : CP_SF.CL_MIN_SIGNIFICANCE;
   var minPurity = (o.minPurity > 0) ? o.minPurity : CP_SF.CL_MIN_PURITY;
   var kSig = CP_SF.CL_PM_SIGMAS, TIERS = ["gold", "silver", "bronze"];
   var cRa = cl.pmRa, cDec = cl.pmDec;
   var intrinsic = (cl.pmSigma > 0) ? cl.pmSigma : 0;
   var plxCl = (cl.dist && cl.dist.pc > 0) ? 1000 / cl.dist.pc : null;
   var depth = (plxCl !== null) ? plxCl * sel * Math.PI / 180 : 0;
   var i, t, s;

   // Por tramo: [indice, separacion al centro, desvio en movimiento propio] de las NO vetadas por la paralaje,
   // y cuantas hay del tramo en total (con veto o sin el).
   var per = { gold: [], silver: [], bronze: [] }, total = { gold: 0, silver: 0, bronze: 0 }, vetoed = { gold: [], silver: [], bronze: [] }, yieldOk = (typeof cshYield === "function");
   for (i = 0; i < stars.length; ++i) {
      if (yieldOk && (i & 2047) === 2047) cshYield();             // (cshYield: Cabra3D, 22-oct; csh_net.js)
      s = stars[i];
      if (s.pmRa === null || s.pmDec === null || !per[s.pmTier]) continue;
      ++total[s.pmTier];
      var a1 = s.pmRa - cRa, a2 = s.pmDec - cDec, r = Math.sqrt(a1 * a1 + a2 * a2);
      var sp = cpSfSeparation(cl.ra, cl.dec, s.ra, s.dec);
      if (sp <= sel) ++out.region;
      if (plxCl !== null && s.plx !== null && s.plxErrMax > 0 && Math.abs(s.plx - plxCl) > CP_SF.CL_PLX_SIGMAS * s.plxErrMax + depth) {
         if (sp <= sel && r <= kSig * Math.sqrt(Math.pow(CP_SF.PM_ERR_MAX[s.pmTier], 2) + intrinsic * intrinsic)) ++out.plxVetoed;
         vetoed[s.pmTier].push(r);
         continue;
      }
      per[s.pmTier].push([i, sp, r]);
   }
   if (out.region < minMembers) { out.code = "no-stars"; return out; }

   var nIn = 0, nBg = 0, usable = 0;
   for (t = 0; t < TIERS.length; ++t) {
      if (yieldOk) cshYield();
      var tier = TIERS[t], list = per[tier];
      var bnd = Math.sqrt(Math.pow(CP_SF.PM_ERR_MAX[tier], 2) + intrinsic * intrinsic);
      // 2 · la sigma del tramo, medida en el nucleo
      var off = [], k;
      for (k = 0; k < list.length; ++k) if (list[k][1] <= core) off.push(list[k][2]);
      var sigma = null, measured = false;
      if (off.length >= CP_SF.CL_CORE_MIN) {
         // Mediana de |desvio| de una gaussiana 2D = sigma · sqrt(2 ln 2). Se itera recortando a 3 sigmas.
         var cut = 3 * bnd, sg = null;
         for (var it = 0; it < 6; ++it) {
            var inside = [];
            for (k = 0; k < off.length; ++k) if (off[k] <= cut) inside.push(off[k]);
            if (inside.length < CP_SF.CL_CORE_MIN / 2) { sg = null; break; }
            sg = cpSfMedian(inside) / Math.sqrt(2 * Math.LN2);
            cut = Math.min(3 * bnd, 3 * sg);
         }
         if (sg !== null && sg > 0) { sigma = Math.min(sg, bnd); measured = true; }
      }
      if (sigma === null) sigma = bnd;
      var radius = kSig * sigma;
      var Q = { sigma: sigma, radius: radius, measured: measured, coreStars: off.length, mode: "none", inside: 0, background: 0, purity: 0,
                accepted: false, control: 0, controlPass: 0, bgSky: null, bgRing: null, bulkSigma: null };
      // 4 · el fondo
      var seps = [], cand = [], notIn = 0, ring = 0;
      for (k = 0; k < list.length; ++k) {
         seps.push(list[k][1]);
         if (list[k][1] > sel) continue;
         if (list[k][2] <= radius) cand.push(list[k][0]);
         else {
            ++notIn;
            if (list[k][2] <= radius * Math.SQRT2) ++ring;
         }
      }
      Q.inside = cand.length;
      // "sky" · el cielo de control: fuera del radio de seleccion si hay 150 estrellas alli; si no, el tercio mas alejado
      var outside = 0;
      for (k = 0; k < seps.length; ++k) if (seps[k] > sel) ++outside;
      var rCtrl = -1;
      if (outside >= 150) rCtrl = sel;
      else if (seps.length >= 450) {
         var sorted = seps.slice().sort(function(p, q) { return p - q; });
         var q23 = sorted[Math.floor(2 * sorted.length / 3)];
         if (q23 > core) rCtrl = q23;
      }
      if (rCtrl >= 0) {
         for (k = 0; k < list.length; ++k)
            if (list[k][1] > rCtrl) { ++Q.control; if (list[k][2] <= radius) ++Q.controlPass; }
         var f = (Q.control > 0) ? Q.controlPass / Q.control : 1;
         Q.bgSky = (f < 1) ? notIn * f / (1 - f) : Q.inside;
      }
      // "ring" · el anillo de igual area, SOLO si el circulo es pequeño frente al grueso del campo (ver la cabecera)
      // cuantas del tramo ENTERO (con veto o sin el) caen en el circulo: dice si el circulo selecciona algo
      var inCircle = 0;
      for (k = 0; k < list.length; ++k) if (list[k][2] <= radius) ++inCircle;
      for (k = 0; k < vetoed[tier].length; ++k) if (vetoed[tier][k] <= radius) ++inCircle;
      Q.selective = (total[tier] > 0) ? inCircle / total[tier] : 1;
      if (cpSfRingIsFair(stars, list, radius, Q)) Q.bgRing = ring;
      // Cada una es una cota POR ARRIBA del fondo (ver la cabecera): vale la menor de las que haya.
      if (Q.bgSky !== null && (Q.bgRing === null || Q.bgSky <= Q.bgRing)) { Q.background = Q.bgSky; Q.mode = "sky"; }
      else if (Q.bgRing !== null) { Q.background = Q.bgRing; Q.mode = "ring"; }
      if (Q.mode !== "none") {
         ++usable;
         Q.purity = (Q.inside > 0) ? Math.max(0, 1 - Q.background / Q.inside) : 0;
         Q.accepted = (Q.inside >= 5 && Q.purity >= minPurity);
         if (Q.accepted) { nIn += Q.inside; nBg += Q.background; out.members = out.members.concat(cand); }
      }
      out.tiers[tier] = Q;
   }
   out.n = out.members.length;
   out.background = nBg;
   out.purity = (nIn > 0) ? Math.max(0, 1 - nBg / nIn) : 0;
   out.significance = (nIn - nBg) / Math.sqrt(Math.max(nBg, 1));

   // 5 · el veredicto
   function no(code) { out.code = code; out.members = []; out.n = 0; return out; }
   if (usable === 0) return no("no-control");
   if (out.n < minMembers) return no("too-few");
   if (out.significance < minSig) return no("not-significant");
   out.confirmed = true;
   out.members.sort(function(p, q) { return p - q; });
   var mr = [], md = [];
   for (i = 0; i < out.members.length; ++i) {
      s = stars[out.members[i]];
      if (s.pmTier !== "bronze") { mr.push(s.pmRa); md.push(s.pmDec); }
   }
   if (mr.length >= 5) { out.pm.ra = cpSfMedian(mr); out.pm.dec = cpSfMedian(md); }
   out.parallax = cpSfMeanParallax(stars, out.members);
   return out;
}

// ¿VALE EL ANILLO como medida del fondo de un tramo? El anillo de igual area
// subestima el fondo cuando el circulo de tolerancia se ha quedado con el
// maximo del grueso del campo. Tres casos, los tres medidos:
//   A) el circulo es pequeño frente a TODAS las estrellas del tramo que quedan
//      tras el veto de la paralaje (radio <= la mitad de su sigma robusta): el
//      campo es liso a esa escala. VALE.
//   B) el circulo ES SELECTIVO: del tramo ENTERO (con veto o sin el) cae dentro
//      menos del 10 % (`Q.selective`). El cumulo es una minoria en movimiento
//      propio y el grueso del campo esta en otra parte (las Pleyades: el 5,6 %).
//      VALE, salvo que queden bastantes estrellas fuera (20) para comparar y el
//      circulo no sea pequeño frente a ellas. (Si tras el veto no queda casi
//      nadie fuera, es que el veto ha limpiado el campo: no hay grueso que temer.)
//   C) el circulo NO es selectivo: o el cumulo domina el tramo (M 67: 892 de sus
//      1500 estrellas Gold), o el circulo es tan ancho que no selecciona nada (el
//      grupo movil HSC 453: dispersion de catalogo de 16 mas/año, circulo de 41,
//      el plano entero; se «confirmo» en el campo de M 92 con 43 estrellas Bronze
//      mientras esto decia «vale si son pocas»). Lo que los separa es EL CIELO:
//      VALE solo si el circulo es pequeño frente a las de fuera Y las de dentro
//      estan AGRUPADAS hacia el centro del cumulo (separacion mediana <= 70 % de
//      la de las demas). El grueso de un campo esta repartido por igual.
// `list` = [indice, separacion, desvio] de las no vetadas. Apunta en
// `Q.bulkSigma` la anchura con la que ha comparado.
function cpSfRingIsFair(stars, list, radius, Q) {
   var k, ax = [], ay = [], ox = [], oy = [], sepIn = [], sepOut = [];
   for (k = 0; k < list.length; ++k) {
      var st = stars[list[k][0]];
      ax.push(st.pmRa); ay.push(st.pmDec);
      if (list[k][2] > radius) { ox.push(st.pmRa); oy.push(st.pmDec); sepOut.push(list[k][1]); }
      else sepIn.push(list[k][1]);
   }
   function width(x, y) { return Math.sqrt((Math.pow(cpSfRobustSigma(x), 2) + Math.pow(cpSfRobustSigma(y), 2)) / 2); }
   if (ax.length >= 50) {
      Q.bulkSigma = width(ax, ay);
      if (radius <= 0.5 * Q.bulkSigma) return true;                     // A
   }
   var selective = (Q.selective <= 0.10);
   if (ox.length < 20)
      return selective;                                                 // B, sin nadie fuera con quien comparar
   Q.bulkSigma = width(ox, oy);
   if (!(radius <= 0.5 * Q.bulkSigma)) return false;
   if (selective) return true;                                          // B
   return (sepIn.length >= 5 && cpSfMedian(sepIn) <= 0.7 * cpSfMedian(sepOut));   // C
}

// La paralaje MEDIA de unas estrellas (solo las de tramo Gold: las demas meten
// ruido y no informacion) y la distancia que saldria de ella, sin y con el punto
// cero. Es lo que el motor NO usa cuando hay catalogo, y lo enseña para que se
// vea por que: en M 13 sale un 12-37 % larga.
function cpSfMeanParallax(stars, indices) {
   var v = [];
   for (var i = 0; i < indices.length; ++i) {
      var s = stars[indices[i]];
      if (s.plx !== null && s.plxTier === "gold") v.push(s.plx);
   }
   if (v.length < 5) return { n: v.length, mean: null, error: null, pc: null, pcZeroPoint: null };
   var sum = 0, i2;
   for (i2 = 0; i2 < v.length; ++i2) sum += v[i2];
   var mean = sum / v.length, ss = 0;
   for (i2 = 0; i2 < v.length; ++i2) ss += (v[i2] - mean) * (v[i2] - mean);
   // (27-oct-2026, T2 H-3 de Codex) El error de la media INCLUYE ya el suelo sistematico de una paralaje media (PLX_MEAN_FLOOR, Vasiliev y Baumgardt
   // 2021) en cuadratura: con las paralajes casi iguales la dispersion daba 0 mas ("10 000 pc ± 0"). Quien la use NO debe sumarlo otra vez.
   var err = Math.sqrt(ss / (v.length - 1) / v.length + CP_SF.PLX_MEAN_FLOOR * CP_SF.PLX_MEAN_FLOOR);
   var zp = mean - CP_SF.PLX_ZERO_POINT;
   return { n: v.length, mean: mean, error: err, pc: (mean > 0) ? 1000 / mean : null, pcZeroPoint: (zp > 0) ? 1000 / zp : null };
}

// ---------------------------------------------------------------------------
// UN GRUPO DE MOVIMIENTO PROPIO QUE NO ESTA EN EL CATALOGO (busqueda a ciegas)
// ----------------------------------------------------------------------------
// Para lo que el catalogo no trae, y como CONTRASTE del propio motor: el grumo
// que se encuentra a ciegas en un campo con cumulo tiene que caer sobre el
// movimiento propio del catalogo. Lo dificil no es encontrar un maximo (el
// campo siempre tiene uno: las estrellas lejanas del disco comparten el reflejo
// del movimiento del Sol) sino NO tomarlo por un cumulo. Tres exigencias, las
// tres medidas sobre las estrellas:
//   a) COMPACTO: en tres zonas de IGUAL AREA alrededor del maximo (disco y dos
//      anillos), el disco tiene el doble que el primer anillo. Una distribucion
//      suave decae poco a poco (1 : 0,95 : 0,90); un cumulo cae de golpe.
//   b) SIGNIFICATIVO: la segunda diferencia n0 - 2·n1 + n2 (que anula un fondo
//      con pendiente) vale 8 sigmas de Poisson, y sobran 20 estrellas.
//   c) Y ADEMAS, UNA DE DOS: las estrellas del grumo estan AGRUPADAS EN EL CIELO
//      (su radio mediano es el 70 % o menos del de LAS DEMAS), o el grumo esta
//      AISLADO: casi sin nada alrededor (los dos anillos suman menos de la quinta
//      parte del disco), es una MINORIA (menos de un cuarto de las estrellas: el
//      grueso del campo no puede serlo) y no es compatible con movimiento propio
//      cero (lo que no se mueve son las galaxias y los cuasares que Gaia ve como
//      puntos, no un cumulo). Lo primero es M 13; lo segundo, las Pleyades
//      llenando el encuadre. (Con «a mas de 4 sigmas del grueso», la primera
//      version, las Pleyades no salian: estan a 2,9, porque hacia Tauro las
//      estrellas cercanas ensanchan el grueso a 15 mas/año.)
// Se compara siempre con LAS DEMAS estrellas, no con todas: en el campo de M 13
// el cumulo es el 60 % de las estrellas y «todas» es el cumulo.
// Se prueba a cuatro escalas (0,4 · 0,8 · 1,6 · 3,2 mas/año): un cumulo cercano
// es ancho en movimiento propio (las Pleyades, 1 mas/año) y uno lejano, estrecho.
// Los candidatos de cada escala son las casillas que SOBRESALEN de las de
// alrededor (no las mas llenas: el grueso del campo llena mas que las Pleyades).
// Devuelve la lista de grupos (puede ser vacia), de mas a menos estrellas:
//   { pmRa, pmDec, scale, n, excess, contrast, significance, concentration,
//     offsetSigmas, isolated, ra, dec, radius, stars: [indices] }
// Solo usa estrellas con movimiento propio Gold o Silver.
// ---------------------------------------------------------------------------
function cpSfFindPmGroups(stars, opts) {
   var o = opts || {};
   var SCALES = [0.4, 0.8, 1.6, 3.2];
   var idx = [], pr = [], pd = [], i;
   for (i = 0; i < stars.length; ++i) {
      var s = stars[i];
      if (s.pmRa === null || s.pmDec === null) continue;
      if (s.pmTier !== "gold" && s.pmTier !== "silver") continue;
      if (o.magLimit > 0 && !(s.g <= o.magLimit)) continue;
      idx.push(i); pr.push(s.pmRa); pd.push(s.pmDec);
   }
   var groups = [];
   if (idx.length < 100) return groups;
   // El radio mediano en el cielo de una lista (posiciones en `idx`), respecto a su centroide mediano.
   function skyRadius(list) {
      var ra = [], de = [], k;
      for (k = 0; k < list.length; ++k) { ra.push(stars[idx[list[k]]].ra); de.push(stars[idx[list[k]]].dec); }
      // (27-oct-2026, R5: T2 H-2 de Codex) Las AR se DESENVUELVEN alrededor de la de la primera (cada una a ±180° de ella) antes de la mediana: la
      // mediana de [359,99; 0,01] es 180, y un grupo partido por AR 0 acababa con radio ~180° y se perdia (11 de 20 pruebas). El centro vuelve a [0,360).
      if (ra.length) {
         var ref = ra[0];
         for (k = 0; k < ra.length; ++k) { var dr = ra[k] - ref; dr -= 360 * Math.round(dr / 360); ra[k] = ref + dr; }
      }
      var cr = cpSfMedian(ra), cd = cpSfMedian(de), r = [];
      cr = cr % 360; if (cr < 0) cr += 360;
      for (k = 0; k < list.length; ++k) r.push(cpSfSeparation(cr, cd, ra[k], de[k]));
      return { ra: cr, dec: cd, radius: cpSfMedian(r) };
   }
   for (var sc = 0; sc < SCALES.length; ++sc) {
      if (typeof cshYield === "function") cshYield();
      var a = SCALES[sc], bin = a / 2, grid = {}, key;
      for (i = 0; i < idx.length; ++i) {
         if ((i & 8191) === 8191) if (typeof cshYield === "function") cshYield();
         key = Math.floor(pr[i] / bin) + "," + Math.floor(pd[i] / bin);
         grid[key] = (grid[key] || 0) + 1;
      }
      var cells = [], nCell = 0;
      for (key in grid) {
         if (!Object.prototype.hasOwnProperty.call(grid, key)) continue;
         if ((++nCell & 255) === 0) if (typeof cshYield === "function") cshYield();
         var parts = key.split(","), gx = parseInt(parts[0], 10), gy = parseInt(parts[1], 10), sum3 = 0, sum5 = 0;
         for (var dx = -2; dx <= 2; ++dx)
            for (var dy = -2; dy <= 2; ++dy) {
               var v = grid[(gx + dx) + "," + (gy + dy)] || 0;
               sum5 += v;
               if (dx >= -1 && dx <= 1 && dy >= -1 && dy <= 1) sum3 += v;
            }
         var expected = (sum5 - sum3) * 9 / 16;
         if (sum3 >= 20 && sum3 >= 1.5 * expected)
            cells.push({ x: (gx + 0.5) * bin, y: (gy + 0.5) * bin, over: sum3 - expected });
      }
      cells.sort(function(p, q) { return q.over - p.over; });
      // Ocho candidatos DISTINTOS: una casilla pegada a otra ya probada es el mismo maximo (sin esto, las ocho
      // eran casillas vecinas del grueso del campo y las Pleyades no llegaban a mirarse).
      var tried = [];
      for (var c = 0; c < cells.length && tried.length < 8; ++c) {
         if (typeof cshYield === "function") cshYield();
         var cx = cells[c].x, cy = cells[c].y, k2, near = false;
         for (k2 = 0; k2 < tried.length; ++k2)
            if (Math.abs(tried[k2][0] - cx) <= 3 * bin && Math.abs(tried[k2][1] - cy) <= 3 * bin) { near = true; break; }
         if (near) continue;
         tried.push([cx, cy]);
         // afinar el centro con la mediana de lo que cae dentro (dos pasadas)
         for (var pass = 0; pass < 2; ++pass) {
            if (typeof cshYield === "function") cshYield();
            var qx = [], qy = [];
            for (i = 0; i < idx.length; ++i) {
               var ex = pr[i] - cx, ey = pd[i] - cy;
               if (ex * ex + ey * ey <= a * a) { qx.push(pr[i]); qy.push(pd[i]); }
            }
            if (qx.length < 5) break;
            cx = cpSfMedian(qx); cy = cpSfMedian(qy);
         }
         var dup = false;
         for (k2 = 0; k2 < groups.length; ++k2)
            if (Math.sqrt(Math.pow(groups[k2].pmRa - cx, 2) + Math.pow(groups[k2].pmDec - cy, 2)) <= Math.max(a, groups[k2].scale) * Math.sqrt(3)) { dup = true; break; }
         if (dup) continue;
         var n0 = 0, n1 = 0, n2 = 0, inList = [], rest = [], rx = [], ry = [];
         if (typeof cshYield === "function") cshYield();
         for (i = 0; i < idx.length; ++i) {
            var fx = pr[i] - cx, fy = pd[i] - cy, r2 = fx * fx + fy * fy;
            if (r2 <= a * a) { ++n0; inList.push(i); }
            else {
               if (r2 <= 2 * a * a) ++n1;
               else if (r2 <= 3 * a * a) ++n2;
               else { rest.push(i); rx.push(pr[i]); ry.push(pd[i]); }
            }
         }
         var excess = n0 - n1;
         var second = n0 - 2 * n1 + n2;
         var sig = second / Math.sqrt(Math.max(1, n0 + 4 * n1 + n2));
         var contrast = n0 / Math.max(1, n1);
         if (excess < 20 || contrast < 2 || sig < 8) continue;
         var sky = skyRadius(inList), conc = 1, offset = 0;
         if (rest.length >= 50) {
            var other = skyRadius(rest);
            conc = (other.radius > 0) ? sky.radius / other.radius : 1;
            var bulk = Math.sqrt((Math.pow(cpSfRobustSigma(rx), 2) + Math.pow(cpSfRobustSigma(ry), 2)) / 2);
            offset = (bulk > 0) ? Math.sqrt(Math.pow(cx - cpSfMedian(rx), 2) + Math.pow(cy - cpSfMedian(ry), 2)) / bulk : 0;
         }
         var isolated = ((n1 + n2) <= 0.2 * n0 && n0 <= 0.25 * idx.length && Math.sqrt(cx * cx + cy * cy) > 2 * a);
         if (!(conc <= 0.7 || isolated)) continue;
         var members = [];
         for (k2 = 0; k2 < inList.length; ++k2) members.push(idx[inList[k2]]);
         groups.push({ pmRa: cx, pmDec: cy, scale: a, n: n0, excess: excess, contrast: contrast, significance: sig, concentration: conc,
                       offsetSigmas: offset, isolated: isolated, ra: sky.ra, dec: sky.dec, radius: sky.radius, stars: members });
      }
   }
   groups.sort(function(p, q) { return q.excess - p.excess; });
   return groups;
}

// ---------------------------------------------------------------------------
// DAR DISTANCIA A CADA ESTRELLA (modifica `stars`)
// ----------------------------------------------------------------------------
// Orden de preferencia, de mas a menos fiable PARA ESA ESTRELLA:
//   1. miembro de un cumulo confirmado con distancia de catalogo -> la del cumulo;
//   2. distancia afinada en red (Bailer-Jones o paralaje con su error real);
//   3. la regla garantizada con lo local.
// Lo que no llega a ninguna se queda con `dist: null`: NO se pinta
// en la vista de distancias. `clusters` son los de `cpStarfield…`, cada uno con
// `members` y `dist`. Devuelve las cuentas por procedencia.
// ---------------------------------------------------------------------------
// ¿Esta la estrella DENTRO DEL RADIO DEL NUCLEO de un cumulo confirmado (sin ser miembro)?
// POR QUE IMPORTA (visto al PINTAR el HR de M 13 con todos los tests en verde: una columna de
// puntos en BP-RP 0,7 y M_G de 10 a 14, donde no hay estrellas). MEDIDO con el extracto real
// de M 13 (`cp_starfield_fx_gaia_m13.csv`, que trae el RUWE de ESA): de las 156 estrellas del
// campo que pasan la regla garantizada, las 11 de tramo Silver o Bronze tienen TODAS RUWE >= 1,4
// (de 1,6 a 6,7) y 10 de las 11 caen dentro del radio del nucleo (0,095 grados): son estrellas
// DEL CUMULO (G de 17,7 a 19,8, el color de su punto de giro) con una paralaje de 4 a 9 mas que
// no es suya: en un nucleo apiñado la solucion astrometrica de una debil se contamina con las
// vecinas, y la cota del tramo —que es su error FORMAL— no lo sabe. Las de tramo Gold dentro
// del nucleo son otra cosa (brillantes; 2 de 6 con RUWE bueno) y no se tocan. La regla marca
// 10, las 10 con RUWE malo, y ninguna con RUWE bueno (caso C30 de L0-91).
// Diseño: «dentro del radio del nucleo» y «tramo que no es Gold». `clusters` = los de
// `cpStarfieldBuild` (necesita ra, dec, coreRadiusDeg); sin esos campos no marca nada.
function cpSfInCrowdedCore(st, clusters) {
   for (var c = 0; clusters && c < clusters.length; ++c) {
      var cl = clusters[c];
      if (!cl || !cl.confirmed || !(cl.coreRadiusDeg > 0) || !isFinite(cl.ra) || !isFinite(cl.dec)) continue;
      if (cpSfSeparation(cl.ra, cl.dec, st.ra, st.dec) <= cl.coreRadiusDeg) return true;
   }
   return false;
}

function cpSfAssignDistances(stars, clusters) {
   var count = { cluster: 0, bailerJones: 0, parallaxOnline: 0, parallaxLocal: 0, none: 0, suspect: 0 };
   var i, c;
   for (i = 0; i < stars.length; ++i) { stars[i].cluster = -1; stars[i].dist = null; stars[i].absG = null; }
   for (c = 0; clusters && c < clusters.length; ++c) {
      var cl = clusters[c];
      if (!cl.confirmed || !cl.dist || !(cl.dist.pc > 0)) continue;
      for (var m = 0; m < cl.members.length; ++m) {
         var s = stars[cl.members[m]];
         if (s.cluster >= 0) continue;                 // el primero que la reclamo (los cumulos llegan ordenados por miembros)
         s.cluster = c;
         s.dist = { pc: cl.dist.pc, lo: cl.dist.lo, hi: cl.dist.hi, source: (cl.dist.source === "cluster-parallax") ? "cluster-parallax" : "cluster-catalog",
                    quality: "good", interval: cl.dist.interval, ref: cl.dist.ref, zeroPoint: null };
      }
   }
   var yieldOk = (typeof cshYield === "function");
   if (yieldOk) cshYield();
   for (i = 0; i < stars.length; ++i) {
      if (yieldOk && (i & 127) === 127) cshYield();
      var st = stars[i];
      if (st.dist === null) {
         var d = null;
         if (st.refined) d = cpSfRefinedDistance(st.refined);
         if (d === null && st.plx !== null) d = cpSfLocalDistance(st.plx, st.plxTier);
         if (d !== null && st.refined && d.source === "parallax-local" && isFinite(st.refined.ruwe) && st.refined.ruwe !== null &&
             st.refined.ruwe >= CP_SF.MAX_RUWE)
            d.quality = "suspect";
         if (d !== null && d.quality === "suspect") d.suspectWhy = "ruwe";
         // EL NUCLEO APIÑADO DE UN CUMULO (13-oct-2026; ver `cpSfInCrowdedCore`): sin red no hay RUWE, y ahi la
         // paralaje de una estrella debil es una solucion astrometrica falsa. La distancia no se borra: se marca.
         if (d !== null && d.quality !== "suspect" && d.source === "parallax-local" && st.plxTier !== "gold" && cpSfInCrowdedCore(st, clusters)) {
            d.quality = "suspect";
            d.suspectWhy = "crowded";
         }
         st.dist = d;
      }
      if (st.dist === null) { ++count.none; continue; }
      if (st.g !== null) st.absG = cpSfAbsMag(st.g, st.dist.pc);
      if (st.dist.quality === "suspect") ++count.suspect;
      if (st.dist.source === "cluster-catalog" || st.dist.source === "cluster-parallax") ++count.cluster;
      else if (st.dist.source === "bailer-jones") ++count.bailerJones;
      else if (st.dist.source === "parallax-online") ++count.parallaxOnline;
      else ++count.parallaxLocal;
   }
   return count;
}

// ---------------------------------------------------------------------------
// AFINAR EN RED: casar la respuesta de VizieR con las estrellas locales
// ----------------------------------------------------------------------------
// La base local no trae `source_id`: se casa por POSICION en la epoca del
// catalogo (las dos son J2016,0), a menos de `tolArcsec` (0,1 segundos por defecto), y se
// comprueba ademas que la paralaje coincide (difieren como mucho 0,00005 mas,
// medido): asi una estrella no se queda con el error de la vecina en un nucleo
// apiñado. `rows` = [{ ra, dec, plx, plxErr, ruwe, rgeo, rgeoLo, rgeoHi, pmRaErr, pmDecErr }].
// Modifica `stars` (les pone `refined`, `plxErr`, `ruwe` y, si vienen, `pmErr`, `pmErrRa`, `pmErrDec`). Devuelve
//   { rows, matched, unmatched, plxMismatch }
// ---------------------------------------------------------------------------
var CSH_REFINE_PMERR = true;          // (2-nov-2026, Q4) false = como antes: el afinado no deja los errores del movimiento propio en la estrella
function cpSfRefineApply(stars, rows, tolArcsec) {
   var tol = ((tolArcsec > 0) ? tolArcsec : 0.1) / 3600, cell = 2 / 3600;
   var out = { rows: rows.length, matched: 0, unmatched: 0, plxMismatch: 0 };
   var grid = {}, i, key, yieldOk = (typeof cshYield === "function");
   for (i = 0; i < stars.length; ++i) {
      if (yieldOk && (i & 1023) === 1023) cshYield();
      key = Math.floor(stars[i].dec0 / cell) + "," + Math.floor(stars[i].ra0 * Math.cos(stars[i].dec0 * Math.PI / 180) / cell);
      (grid[key] || (grid[key] = [])).push(i);
   }
   for (var r = 0; r < rows.length; ++r) {
      if (yieldOk && (r & 255) === 255) cshYield();
      var q = rows[r];
      if (!isFinite(q.ra) || !isFinite(q.dec)) { ++out.unmatched; continue; }
      var gy = Math.floor(q.dec / cell), gx = Math.floor(q.ra * Math.cos(q.dec * Math.PI / 180) / cell), best = -1, bd = tol;
      for (var dy = -1; dy <= 1; ++dy)
         for (var dx = -1; dx <= 1; ++dx) {
            var list = grid[(gy + dy) + "," + (gx + dx)];
            if (!list) continue;
            for (var k = 0; k < list.length; ++k) {
               var s = stars[list[k]];
               var d = cpSfSeparation(q.ra, q.dec, s.ra0, s.dec0);
               if (d <= bd) { bd = d; best = list[k]; }
            }
         }
      if (best < 0) { ++out.unmatched; continue; }
      var st = stars[best];
      if (st.plx !== null && isFinite(q.plx) && Math.abs(st.plx - q.plx) > 0.001) { ++out.plxMismatch; continue; }
      st.refined = { plx: q.plx, plxErr: q.plxErr, ruwe: q.ruwe, rgeo: q.rgeo, rgeoLo: q.rgeoLo, rgeoHi: q.rgeoHi };
      st.plxErr = (isFinite(q.plxErr)) ? q.plxErr : null;
      st.ruwe = (isFinite(q.ruwe)) ? q.ruwe : null;
      // (CabraStars) lo que ademas trae la consulta: el identificador de Gaia (TEXTO: 19 cifras no caben en un
      // double), la velocidad radial y los parametros de GSP-Phot. null = Gaia no lo tiene.
      if (q.sourceId) st.sourceId = q.sourceId;
      st.rv = (q.rv !== null && isFinite(q.rv)) ? q.rv : null; st.rvErr = (q.rvErr !== null && isFinite(q.rvErr)) ? q.rvErr : null;
      // (30-oct, decision D de Nino) la RV con el sesgo de magnitud corregido, la MISMA receta en todos (cshRvCorrect, csh_net.js). `rvCat` = la del catalogo; `rvCorr` lo dice la ficha.
      if (st.rv !== null && typeof cshRvCorrect === "function") { var rvC = cshRvCorrect(st.rv, q.grvs, q.tteff); st.rv = rvC.v; st.rvCat = rvC.cat; st.rvCorr = rvC.kind; }
      st.gsp =(q.teff !== null && isFinite(q.teff)) ? { teff: q.teff, logg: q.logg, feh: q.feh, ag: q.ag, ebr: q.ebr, a0: (q.a0 !== undefined) ? q.a0 : null } : null;
      st.nss = (q.nss > 0) ? q.nss : 0;
      st.xpSampled = (q.xp === 1);
      // (2-nov-2026, Q4 del coordinador) LOS ERRORES DEL MOVIMIENTO PROPIO DE ESTA ESTRELLA (e_pmRA, e_pmDE de Gaia DR3; la base local no los
      // trae, solo el tramo oro/plata/bronce). `pmErr` = la media cuadrática de los dos (mas/año): el error de UNA componente, el que usan el
      // cono, la nube y la deconvolución de los cúmulos de Cabra3D (tm/timemachine.js c3TmErrOf). Sin ellos (caché vieja, servidor que no
      // los da) no se toca: quien lo usa cae en el error típico de Gaia para su G, y lo dice. Rojo: CSH_REFINE_PMERR = false.
      if ((typeof CSH_REFINE_PMERR === "undefined" || CSH_REFINE_PMERR === true) && q.pmRaErr !== null && q.pmDecErr !== null && q.pmRaErr > 0 && q.pmDecErr > 0 && isFinite(q.pmRaErr) && isFinite(q.pmDecErr)) {
         st.pmErrRa = q.pmRaErr; st.pmErrDec = q.pmDecErr; st.pmErr = Math.sqrt((q.pmRaErr * q.pmRaErr + q.pmDecErr * q.pmDecErr) / 2);
         st.refined.pmErrRa = q.pmRaErr; st.refined.pmErrDec = q.pmDecErr;
      }
      ++out.matched;
   }
   return out;
}

// La consulta ADQL de afinado (TAPVizieR): Gaia DR3 (I/355) con las distancias de
// Bailer-Jones et al. 2021 (I/352), SOLO las estrellas con paralaje / error > 5.
// Medido el 13-oct-2026 en el campo de M 13 (0,5 grados): 2489 filas en 6,3 s. El
// mismo cruce sin el corte tarda 60 s, y en el archivo de ESA 41-55 s ese dia.
// OJO: `b_rgeo` y `B_rgeo` van entre comillas dobles o el servicio da error 400.
function cpSfRefineAdql(ra, dec, radiusDeg) {
   // (CabraStars: + Source, RV, GSP-Phot y la bandera de espectro XP muestreado; medido el 14-oct-2026: M 13 a 0,1°, 817 filas en 2,0 s)
   // (30-oct, decision D: GRVSmag y RVtempTeff en esta misma consulta, para la correccion de la RV: cshRvCorrect, csh_net.js)
   // (2-nov-2026, Q4: + e_pmRA y e_pmDE, los errores del movimiento propio de cada estrella: ver cpSfRefineApply)
   return "SELECT g.RA_ICRS,g.DE_ICRS,g.Plx,g.e_Plx,g.RUWE,d.rgeo,d.\"b_rgeo\",d.\"B_rgeo\",g.Source,g.RV,g.e_RV," + ((typeof cshRvColsSql === "function") ? cshRvColsSql("g.", ",") : "") + "g.Teff,g.logg,g.\"[Fe/H]\",g.AG,g.\"E(BP-RP)\",g.XPsamp,g.A0,g.NSS,g.e_pmRA,g.e_pmDE FROM \"I/355/gaiadr3\" AS g " +
          "LEFT JOIN \"I/352/gedr3dis\" AS d ON g.Source=d.Source WHERE 1=CONTAINS(POINT('ICRS',g.RA_ICRS,g.DE_ICRS),CIRCLE('ICRS'," +
          ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND g.RPlx>" + CP_SF.MIN_PLX_SNR;
}

// La respuesta CSV de esa consulta -> filas para `cpSfRefineApply`.
function cpSfRefineRows(csvText) {
   var t = cpSfParseTable(csvText, ","), out = [], yieldOk = (typeof cshYield === "function");
   for (var i = 0; i < t.rows.length; ++i) {
      if (yieldOk && (i & 255) === 255) cshYield();
      var r = t.rows[i];
      var ra = cpSfNum(r.RA_ICRS), dec = cpSfNum(r.DE_ICRS);
      if (ra === null || dec === null) continue;
      out.push({ ra: ra, dec: dec, plx: cpSfNum(r.Plx), plxErr: cpSfNum(r.e_Plx), ruwe: cpSfNum(r.RUWE),
                 rgeo: cpSfNum(r.rgeo), rgeoLo: cpSfNum(r.b_rgeo), rgeoHi: cpSfNum(r.B_rgeo),
                 sourceId: (/^\d{6,20}$/.test(String(r.Source || "").replace(/\s+/g, ""))) ? String(r.Source).replace(/\s+/g, "") : "",
                 rv: cpSfNum(r.RV), rvErr: cpSfNum(r.e_RV), grvs: cpSfNum(r.GRVSmag), tteff: cpSfNum(r.RVtempTeff), teff: cpSfNum(r.Teff), logg: cpSfNum(r.logg), feh: cpSfNum(r["[Fe/H]"]),
                 ag: cpSfNum(r.AG), ebr: cpSfNum(r["E(BP-RP)"]), xp: cpSfNum(r.XPsamp), a0: cpSfNum(r.A0), nss: cpSfNum(r.NSS),
                 pmRaErr: cpSfNum(r.e_pmRA), pmDecErr: cpSfNum(r.e_pmDE) });
   }
   return out;
}

// ---------------------------------------------------------------------------
// COSMOLOGIA: del corrimiento al rojo a las DOS cifras que pidio Nino
// ----------------------------------------------------------------------------
// LCDM plano con materia y constante cosmologica (sin radiacion: por debajo de
// z = 10 cambia el tiempo en menos del 0,1 %). Parametros de `CP_SF`.
//   · `lookbackYr`: cuanto hace que salio la luz (el «su luz salio hace X años»).
//     Forma CERRADA: t(a) = 2 / (3 H0 sqrt(OL)) · asinh( sqrt(OL/Om) · a^1,5 ).
//   · `comovingPc`: a que distancia esta HOY (distancia comovil = propia actual).
//     Integral numerica de da / sqrt(Om·a + OL·a^4), por Simpson.
//   · `luminosityPc`: la de luminosidad, (1+z) veces la comovil, por si hace falta.
// Los tests la comprueban contra las dos soluciones exactas (Einstein-de Sitter
// y de Sitter) y contra la serie a z pequeño; no contra otra copia de si misma.
// `cosmo` (opcional) = { H0, Om } para esos tests.
// ---------------------------------------------------------------------------
function cpSfHubbleTimeYr(H0) {
   var mpcKm = cpSfParsecMetres() * 1e6 / 1000;
   return (mpcKm / H0) / CP_SF.JULIAN_YEAR_S;
}

function cpSfCosmo(z, cosmo) {
   var H0 = (cosmo && cosmo.H0 > 0) ? cosmo.H0 : CP_SF.H0;
   var Om = (cosmo && cosmo.Om > 0) ? cosmo.Om : CP_SF.OMEGA_M;
   if (!(z > 0) || !isFinite(z)) return null;
   var OL = 1 - Om, a = 1 / (1 + z), tH = cpSfHubbleTimeYr(H0);
   // comovil: (c/H0) · integral de a a 1 de da / sqrt(Om·a + OL·a^4)
   var n = 512, h = (1 - a) / n, sum = 0;
   function f(x) { return 1 / Math.sqrt(Om * x + OL * x * x * x * x); }
   for (var i = 0; i <= n; ++i) sum += f(a + i * h) * ((i === 0 || i === n) ? 1 : (i % 2) ? 4 : 2);
   var dcHubble = sum * h / 3;                                  // en unidades de c/H0
   var hubblePc = (CP_SF.C_M_S / 1000 / H0) * 1e6;              // c/H0 en parsecs
   var lookback = null, age = null;
   if (OL > 1e-9) {
      var k = Math.sqrt(OL / Om);
      var asinh = function(x) { return Math.log(x + Math.sqrt(x * x + 1)); };
      var t0 = 2 / (3 * Math.sqrt(OL)) * asinh(k), ta = 2 / (3 * Math.sqrt(OL)) * asinh(k * Math.pow(a, 1.5));
      lookback = (t0 - ta) * tH; age = t0 * tH;
   } else {
      lookback = (2 / 3) * (1 - Math.pow(a, 1.5)) * tH; age = (2 / 3) * tH;   // Einstein-de Sitter
   }
   return { z: z, comovingPc: dcHubble * hubblePc, luminosityPc: dcHubble * hubblePc * (1 + z), lookbackYr: lookback, ageYr: age };
}

// La distancia que da un corrimiento al rojo, con su intervalo y su aviso.
// El intervalo es z ± v_pec / c (240 km/s, cota por debajo: ver la cabecera). Si
// esa fraccion pasa del 20 %, el corrimiento NO vale como distancia (`quality:
// "unreliable"`): es la misma vara que la de la paralaje, aplicada aqui por
// analogia (diseño). z <= 0 no es cosmologico (NGC 1560 se ACERCA): null.
function cpSfRedshiftDistance(z) {
   if (!(z > 0) || !isFinite(z)) return null;
   var dz = CP_SF.VPEC_KMS / (CP_SF.C_M_S / 1000);
   // (27-oct-2026, T2 H-5 de Codex) La velocidad peculiar compone con el corrimiento cosmologico: (1+z_obs) = (1+z_cos)(1+v/c), asi que
   // sigma_z = (1+z)·v/c, no v/c. Sin el factor la barra salia la mitad de ancha a z = 1 (3,98 en vez de 7,96 Mpc).
   dz *= (1 + z);
   // (24-oct-2026) z DENTRO DEL RUIDO DE LA VELOCIDAD PECULIAR (z <= 240 km/s / c = 8e-4): el corrimiento no dice a que distancia esta, solo
   // que no es lejana; su intervalo llega hasta 0 y la «distancia» sale de ruido (SDSS J162733.43+275317.4 de Abell 39: z = 1e-5 -> «44 000 pc»
   // con una barra de 4 pc a 3,6 Mpc, la barra larga de «tambien lo que no se ve»). Sin distancia, como con z <= 0: no se inventa.
   // (H8 de Gemini, decision de Nino) El mismo criterio que cshRedshiftDistanceErr: SIN DISTANCIA SI EL INTERVALO LLEGA A z <= 0 (z - dz <= 0). Antes
   // `z <= dz` dejaba pasar z = 8,01e-4 con lo = 1 985 pc y hi = 7,1 Mpc (factor 3 588).
   if (z - dz <= 0) return null;
   var mid = cpSfCosmo(z), lo = cpSfCosmo(z - dz), hi = cpSfCosmo(z + dz);
   // (26-oct-2026, F1b de Nino) SEGUNDO CORTE, del mismo criterio: tampoco hay distancia si la barra de error pasa de ×10 (hi/lo > MAX_BAR_RATIO). Antes
   // z - dz <= 0 solo quitaba lo que llegaba a cero y dejaba lo de justo encima (z = 8,01e-4: lo 1 985 pc, hi 7,1 Mpc, ×3 588; Abell 39: ×92, ×22, ×11).
   if (hi.comovingPc / lo.comovingPc > CP_SF.MAX_BAR_RATIO) return null;
   var frac = dz / z;
   return { pc: mid.comovingPc, lo: lo.comovingPc, hi: hi.comovingPc, source: "redshift", kind: "redshift",
            quality: (frac > CP_SF.MAX_FRACTION) ? "unreliable" : "good", fraction: frac, interval: "peculiar velocity 240 km/s (lower bound)",
            z: z, lookbackYr: mid.lookbackYr, lookbackLoYr: lo.lookbackYr, lookbackHiYr: hi.lookbackYr,
            comovingPc: mid.comovingPc, luminosityPc: mid.luminosityPc, ref: CP_SF.COSMOLOGY };
}

// ---------------------------------------------------------------------------
// SIMBAD: galaxias, cuasares, nebulosas y lo demas del campo
// ----------------------------------------------------------------------------
// UNA consulta TAP por cono trae, de cada objeto con corrimiento al rojo o con
// alguna distancia medida: su tipo (con la RUTA en la jerarquia de tipos de
// SIMBAD, que evita llevar aqui una tabla de 200 codigos), su z y TODAS sus
// medidas de distancia (`mesDistance`: una fila por medida).
// Lo que se aprendio mirando campos reales (M 13, NGC 1560, M 51, 3C 273):
//   · `unit` viene con espacios («Mpc », «kpc », «pc  »);
//   · `method` «redshift» NO es una medida directa: es una distancia sacada de la
//     velocidad con un modelo de flujo. Va aparte;
//   · «T-RDB» es una errata de SIMBAD por «T-RGB»; el metodo vacio es lo normal;
//   · un objeto trae hasta diez medidas que difieren el doble (NGC 6207: de 11,4
//     a 21,4 Mpc): se da la MEDIANA y, como intervalo, el RANGO entero con los
//     errores que cada una declara. No se elige «la buena» por metodo: no hay con
//     que justificarlo desde aqui, y el rango dice la verdad de lo que se sabe;
//   · z puede ser negativo (NGC 1560, M 13): no es cosmologico.
// ---------------------------------------------------------------------------
// (Block G, 20-oct-2026) `withMags`: tambien el eje menor y las magnitudes de `allfluxes` (B, V, G, R, g, r), para decidir
// si el objeto se ve en la foto (CabraShared/csh_depth.js). Sin el, la consulta de siempre.
function cpSfSimbadAdql(ra, dec, radiusDeg, withMags) {
   var mags = withMags ? ",b.galdim_minaxis,f.B,f.V,f.G,f.R,f.g_,f.r_" : "", join = withMags ? " LEFT JOIN allfluxes AS f ON f.oidref=b.oid" : "";
   return "SELECT b.oid,b.main_id,b.ra,b.dec,b.otype,t.path,b.rvz_redshift,b.rvz_type,b.galdim_majaxis" + mags + ",d.dist,d.unit,d.minus_err,d.plus_err,d.method,d.bibcode " +
          "FROM basic AS b JOIN otypedef AS t ON t.otype=b.otype LEFT JOIN mesDistance AS d ON d.oidref=b.oid" + join + " " +
          "WHERE CONTAINS(POINT('ICRS',b.ra,b.dec),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + "))=1 " +
          "AND (b.rvz_redshift IS NOT NULL OR d.dist IS NOT NULL) " +
          // Las estrellas sueltas no se piden (de esas se ocupa Gaia): en el campo de M 13 eran 1150 de las 1311
          // filas, y en uno de Cygnus 452 de 457 (3,9 s frente a 0,2 s; medido). Las planetarias y las
          // supernovas cuelgan de «*» en la jerarquia de SIMBAD y SI se piden.
          "AND (t.path NOT LIKE '*%' OR b.otype IN ('PN','PN?','SN*','SN?'))";
}

// La clase del motor a partir de la ruta de SIMBAD («G > AGN > QSO > Bla»).
// Devuelve { cls, extragalactic, candidate }. Las estrellas sueltas dan "star".
function cpSfSimbadClass(otype, path) {
   var p = String(path || "").replace(/^\s+|\s+$/g, ""), code = String(otype || "");
   var cand = (code.charAt(code.length - 1) === "?");
   var parts = (p.length > 0) ? p.split(/\s*>\s*/) : [code.replace(/\?$/, "")];
   var root = parts[0];
   function has(x) { for (var i = 0; i < parts.length; ++i) if (parts[i] === x) return true; return false; }
   var cls = "other", ext = false;
   if (root === "G") { ext = true; cls = has("QSO") ? "quasar" : "galaxy"; }
   else if (has("LeQ")) { ext = true; cls = "quasar"; }
   else if (has("LeG")) { ext = true; cls = "galaxy"; }
   else if (root === "ClG" || root === "GrG" || root === "PCG" || root === "SCG" || root === "PaG" || root === "IG") { ext = true; cls = "galaxy-group"; }
   else if (root === "PoG") { ext = true; cls = "galaxy-part"; }
   else if (root === "Cl*") cls = "star-cluster";
   else if (root === "As*") cls = "association";
   else if (has("PN")) cls = "planetary-nebula";
   else if (has("SN*")) { ext = true; cls = "supernova"; }
   else if (root === "ISM" || root === "PoC") cls = "nebula";
   else if (root === "*") cls = "star";
   return { cls: cls, extragalactic: ext, candidate: cand, agn: has("AGN") };
}

// Una medida de `mesDistance` en parsecs: { pc, lo, hi, method, bibcode, modelled }.
function cpSfSimbadMeasure(row) {
   var v = cpSfNum(row.dist);
   if (v === null || !(v > 0)) return null;
   var unit = String(row.unit || "").replace(/\s+/g, "").toLowerCase();
   var k = (unit === "mpc") ? 1e6 : (unit === "kpc") ? 1e3 : (unit === "pc") ? 1 : 0;
   if (k === 0) return null;
   var minus = cpSfNum(row.minus_err), plus = cpSfNum(row.plus_err);
   var method = String(row.method || "").replace(/\s+/g, "");
   if (method === "T-RDB") method = "T-RGB";
   return { pc: v * k, lo: (v - Math.abs(minus || 0)) * k, hi: (v + Math.abs(plus || 0)) * k, method: method, bibcode: String(row.bibcode || ""),
            modelled: (method.toLowerCase() === "redshift") };
}

// La respuesta CSV de SIMBAD -> la lista de objetos del motor.
//   { name, ra, dec, otype, cls, extragalactic, candidate, agn, sizeArcmin, z,
//     dist, direct, redshift, measures: […] }
// `dist` es la que se enseña: la DIRECTA si la hay (la PARALAJE mas reciente si
// alguna medida lo es —`cpSfLatestParallax`—; si no, la mediana de las medidas que
// no son «redshift», rango entero como intervalo); si no, la del corrimiento al
// rojo con la cosmologia declarada (solo para lo extragalactico); si no, la
// mediana de las distancias «redshift» de la literatura (modelo de flujo). `direct`
// y `redshift` van SIEMPRE que existan, para que quien pinte pueda enseñar las dos.
// Las estrellas sueltas no salen (de esas se ocupa Gaia) salvo con `opts.stars`.
function cpSfSimbadObjects(csvText, opts) {
   var t = cpSfParseTable(csvText, ","), byOid = {}, order = [], i;
   for (i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], oid = String(r.oid);
      if (oid.length === 0) continue;
      var o = byOid[oid];
      if (!o) {
         var k = cpSfSimbadClass(r.otype, r.path);
         var ra = cpSfNum(r.ra), dec = cpSfNum(r.dec);
         if (ra === null || dec === null) continue;
         o = byOid[oid] = { name: String(r.main_id).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""), ra: ra, dec: dec, x: null, y: null,
                            otype: String(r.otype), cls: k.cls, extragalactic: k.extragalactic, candidate: k.candidate, agn: k.agn,
                            sizeArcmin: cpSfNum(r.galdim_majaxis), z: cpSfNum(r.rvz_redshift), zKind: String(r.rvz_type || ""),
                            dist: null, direct: null, redshift: null, measures: [],
                            // (Block G) el eje menor y las magnitudes, si la consulta las trajo (`withMags`); si no, null
                            minArcmin: cpSfNum(r.galdim_minaxis), mags: (typeof cshSimbadMags === "function") ? cshSimbadMags(r) : null };
         // (28-oct-2026, A) de donde sale el tamaño: «SIMBAD» si trae galdim; si no, "" (y `cshSizeFallback` puede poner «OpenNGC»)
         o.sizeSource = (o.sizeArcmin !== null && o.sizeArcmin > 0) ? "SIMBAD" : "";
         order.push(oid);
      }
      var m = cpSfSimbadMeasure(r);
      if (m) o.measures.push(m);
   }
   var out = [];
   for (i = 0; i < order.length; ++i) {
      var ob = byOid[order[i]];
      if (ob.cls === "star" && !(opts && opts.stars)) continue;
      var dir = [], mod = [], j;
      for (j = 0; j < ob.measures.length; ++j) (ob.measures[j].modelled ? mod : dir).push(ob.measures[j]);
      ob.direct = cpSfSummarise(dir, "direct");
      // N1 (decision de Nino, 13-oct-2026): con alguna medida por PARALAJE, la que se enseña es la paralaje mas
      // RECIENTE, no la mediana de todas (que queda en `median`). Para lo extragalactico no: una paralaje no mide una galaxia.
      ob.median = ob.direct;
      var par = ob.extragalactic ? null : cpSfLatestParallax(dir);
      if (par !== null) ob.direct = par;
      if (ob.extragalactic && ob.z !== null) ob.redshift = cpSfRedshiftDistance(ob.z);
      var modelled = cpSfSummarise(mod, "redshift-model");
      ob.dist = cpSfPickDistance(ob.direct, ob.redshift, modelled);
      out.push(ob);
   }
   return out;
}

// ---------------------------------------------------------------------------
// EL TAMAÑO DE RESERVA: OpenNGC (28-oct-2026, decision A de Nino). PURA (node la ejecuta).
// POR QUE: SIMBAD no tiene el tamaño de M 82 (`galdim_majaxis` vacio; medido el 28-oct en el espejo de Harvard, TAP y ficha web
// «Angular size: ~»; de 30 galaxias brillantes consultadas, la unica). Sin tamaño el 3D no le hace recorte (`ext` 0,
// Cabra3D/src/ui/starfield_view.js) y la galaxia del motivo salia como un punto dorado.
// QUE HACE: a un objeto de SIMBAD SIN tamaño cuyo nombre principal es de catalogo M / NGC / IC («M 82», «NGC 3034», «IC 342»;
// SIMBAD da prioridad a esos nombres como identificador principal) se le pone el eje mayor y menor de OpenNGC
// (CabraShared/data/galaxy_sizes_openngc.csv, CC-BY-SA-4.0, Mattia Verga), con `sizeSource: "OpenNGC"`. SOLO si la posicion de
// SIMBAD cae dentro del radio de catalogo de esa fila (o a menos de CSH_SIZE_MATCH_MIN_ARCMIN): un nombre que casa con otra cosa
// (OpenNGC trata «M 102» como M 101) no se lleva un tamaño ajeno. Lo que SIMBAD SI mide no se toca: SIMBAD manda.
// Por que el nombre principal y no `ids` (todos los identificadores): pedir `ids` duplicaba la respuesta del campo de M 82
// (25 → 50 kB, medido el 28-oct) para un caso que el nombre principal ya cubre.
// Costura del rojo: CSH_SIZE_FALLBACK = false (como antes: sin tamaño, sin recorte).
// ---------------------------------------------------------------------------
var CSH_SIZE_FALLBACK = true;
var CSH_SIZE_MATCH_MIN_ARCMIN = 1;      // diseño: tolerancia minima de posicion (un objeto de catalogo pequeño con su centro en otra placa)
// «M  82» / «NGC 3034» / «IC 342» / «NGC 2523A» -> la clave del catalogo («M 82», «NGC 3034»…); null si no es de esos catalogos.
function cshSizeKey(name) {
   var m = /^(M|NGC|IC)\s*0*(\d+)\s*([A-Za-z]?)$/.exec(String(name || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""));
   return m ? m[1] + " " + m[2] + m[3].toUpperCase() : null;
}
// El fichero empaquetado -> { byKey: { "NGC 3034": fila, "M 82": fila }, rows, meta }. fila = { id, m, ra, dec, maj, min, pa }.
function cshOpenNgcSizes(text) {
   var t = cpSfParseTable(text, ","), out = { byKey: {}, rows: 0, meta: t.meta };
   for (var i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], maj = cpSfNum(r.maj), ra = cpSfNum(r.ra), dec = cpSfNum(r.dec);
      if (!(maj > 0) || ra === null || dec === null) continue;
      var row = { id: String(r.id || ""), m: String(r.m || ""), ra: ra, dec: dec, maj: maj, min: cpSfNum(r.min), pa: cpSfNum(r.pa) };
      if (row.id.length > 0) out.byKey[row.id] = row;
      if (row.m.length > 0) out.byKey["M " + row.m] = row;
      ++out.rows;
   }
   return out;
}
// ¿Hay alguno que la necesite? (para no leer el fichero en los campos donde SIMBAD ya trae todos los tamaños)
function cshSizeNeeds(objs) {
   for (var i = 0; objs && i < objs.length; ++i) if (!(objs[i].sizeArcmin > 0) && cshSizeKey(objs[i].name) !== null) return true;
   return false;
}
// A los objetos SIN tamaño, el de OpenNGC. -> { applied: [ «M 82 11.0'» ], rejected: [ «nombre: por que» ] }
function cshSizeFallback(objs, cat) {
   var out = { applied: [], rejected: [] };
   if (CSH_SIZE_FALLBACK !== true || !cat || !cat.byKey) return out;
   for (var i = 0; objs && i < objs.length; ++i) {
      var ob = objs[i];
      if (ob.sizeArcmin > 0) continue;                                   // SIMBAD manda
      if (ob.cls === "star" || ob.cls === "star-cluster" || ob.cls === "planetary-nebula" || ob.cls === "nebula") continue;
      var key = cshSizeKey(ob.name), row = (key !== null) ? cat.byKey[key] : null;
      if (!row) continue;
      var sepArcmin = 60 * cpSfSeparation(ob.ra, ob.dec, row.ra, row.dec), lim = Math.max(row.maj / 2, CSH_SIZE_MATCH_MIN_ARCMIN);
      if (!(sepArcmin <= lim)) { out.rejected.push(ob.name + ": " + (row.id || key) + " of OpenNGC is " + sepArcmin.toFixed(1) + "' away (limit " + lim.toFixed(1) + "')"); continue; }
      ob.sizeArcmin = row.maj;
      if (!(ob.minArcmin > 0) && row.min > 0) ob.minArcmin = row.min;
      ob.sizePa = row.pa; ob.sizeSource = "OpenNGC"; ob.sizeRef = row.id || key;
      out.applied.push(ob.name + " " + row.maj + "'");
   }
   return out;
}

// ---------------------------------------------------------------------------
// (15-nov-2026, P3 de la build 1718) TAMAÑO (EJES Y ANGULO) Y z DE LAS GALAXIAS DE LAS BASES LOCALES DE PIXINSIGHT: SGA-2020 → PGC.
// Son bases de la DISTRIBUCION de ExtendedSources (PixInsight 1.9.6 b1718; no hay que instalar nada, sin red): SGA-2020 (383 620 galaxias, isofota
// 26 mag/arcsec² en la banda r, con z) y PGC (983 261, D25 de HyperLEDA, sin z). DECISION DE NINO (15-nov-2026): «SGA y si no hay, PGC»: el tamaño que
// se enseña es el de la isofota 26 de SGA-2020 cuando la galaxia esta en SGA; si no, el D25 de PGC. Son DEFINICIONES DISTINTAS (M 82: 13,7′ frente a 11,0′,
// ×1,25), asi que cada galaxia lleva cual se uso (`sizeSource`, `sizeDef` «isophote-26» | «d25», `sizeRef`) y se ENSEÑA (ficha de Cabra3D, FieldVoyager).
// ORDEN DE AUTORIDAD (antes: SIMBAD y luego OpenNGC): TAMAÑO = SGA-2020 → PGC → (SIMBAD) → OpenNGC empaquetado. El de SIMBAD (`galdim`, el D25 de
// HyperLEDA) se guarda en `sizePrev` si lo habia. z = el de SIMBAD si lo tiene (como siempre); el de SGA-2020 SOLO rellena la galaxia sin z propio
// y sustituye al FOTOMETRICO de GLADE+ (que no dice nada a z > 0,1); un z espectroscopico o una distancia medida de GLADE+ se quedan (y la diferencia con SGA
// se anota en `zAlt`). Las galaxias de SGA-2020 que ni SIMBAD ni GLADE+ traen entran como objetos nuevos (`cshGalaxyLocalObjects`, csh_depth.js).
// Sin las bases (1.9.5, build < 1718) o con CSH_GAL_LOCAL = false: exactamente lo de antes. Costura del rojo: CSH_GAL_LOCAL = false.
// `local` = { ok, sga: [fila], pgc: [fila] } de `cshGalaxyLocal` (csh_starfield_run.js); fila = { db, name, names[], ra, dec, major, minor (′, diametros),
// pa (° o null si es un circulo), circle, z, morph, mag, g26, r26, group }. PURA (node la ejecuta).
// ---------------------------------------------------------------------------
var CSH_GAL_LOCAL = true;
var CSH_GAL_MATCH_FRAC = 0.05;        // diseño: una galaxia de SIMBAD / GLADE+ es la de la base local si cae a menos del 5 % de su diametro...
var CSH_GAL_MATCH_MIN_ARCSEC = 4;     // ...con un minimo de 4″ y un maximo de 15″ (medido el 15-nov: los desfases de posicion de SGA frente a HyperLEDA son de 1-10″, mas en las grandes)
var CSH_GAL_MATCH_MAX_ARCSEC = 15;
var CSH_GAL_ZCONFLICT = 0.01;         // diseño: |z de SIMBAD - z de SGA| mayor que esto = otro objeto (el mas lejano o el de delante)
var CSH_GAL_SGA_REF = "SGA-2020 (Moustakas et al. 2023): redshift from HyperLEDA";
function cshGalNameKey(s) {
   var t = String(s || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "").toUpperCase();
   var m = /^(NGC|IC|UGC|PGC|MCG|CGCG|ESO|UGCA|M)\s*0*([0-9+\-A-Z.]+)$/.exec(t);
   return m ? m[1] + " " + m[2] : t;
}
// el indice: las filas por declinacion (para no recorrerlas todas con cada galaxia)
function cshGalIndex(rows) {
   var a = (rows || []).slice(0);
   a.sort(function(x, y) { return x.dec - y.dec; });
   return a;
}
function cshGalTol(row) { return Math.min(CSH_GAL_MATCH_MAX_ARCSEC, Math.max(CSH_GAL_MATCH_MIN_ARCSEC, CSH_GAL_MATCH_FRAC * row.major * 60)); }
// la fila del indice que es la galaxia (ra, dec): la de menor separacion / tolerancia entre las que caen dentro. null si ninguna.
function cshGalFind(idx, ra, dec) {
   if (!idx || idx.length === 0) return null;
   var lo = 0, hi = idx.length, win = CSH_GAL_MATCH_MAX_ARCSEC / 3600 + 1e-6, best = null, bs = 1e9;
   while (lo < hi) { var mid = (lo + hi) >> 1; if (idx[mid].dec < dec - win) lo = mid + 1; else hi = mid; }
   for (var i = lo; i < idx.length && idx[i].dec <= dec + win; ++i) {
      var r = idx[i], sep = cpSfSeparation(ra, dec, r.ra, r.dec) * 3600, tol = cshGalTol(r);
      if (sep <= tol && sep / tol < bs) { bs = sep / tol; best = r; best.sep = sep; }
   }
   return best;
}
// ¿Dice el nombre de la galaxia lo mismo que la fila? true / false / null (la galaxia no lleva nombre de catalogo reconocible)
function cshGalNameAgree(name, row) {
   var k = cshGalNameKey(name);
   if (!/^(NGC|IC|UGC|PGC|MCG|CGCG|ESO|UGCA) /.test(k)) return null;
   if (cshGalNameKey(row.name) === k) return true;
   for (var i = 0; row.names && i < row.names.length; ++i) if (cshGalNameKey(row.names[i]) === k) return true;
   return false;
}
// la distancia de un z de SGA-2020 (sin error de z: solo la velocidad peculiar, una cota inferior de la barra, como Milliquas). null si el z no da distancia.
function cshGalZDist(z) {
   var d = (typeof cshRedshiftDistanceErr === "function") ? cshRedshiftDistanceErr(z, 0, CSH_GAL_SGA_REF, "redshift") : cpSfRedshiftDistance(z);
   if (d === null) return null;
   d.source = "sga"; d.zNoError = true;
   d.interval = "no redshift error in SGA-2020 · peculiar velocity 240 km/s (lower bound)";
   d.ref = CSH_GAL_SGA_REF + " · " + CP_SF.COSMOLOGY;
   return d;
}
function cshGalHasZ(ob) { return ob.z !== null && ob.z !== undefined && isFinite(ob.z); }
// -> { matched, sga, pgc, sizeNew (sin tamaño antes), sizeReplaced (SIMBAD lo tenia), zFilled, zReplaced, zKept (z propio distinto), nameAgree, nameDisagree,
//      pairs: [{ name, sga (′), pgc (′), prev (′), prevSrc, z, zSga, zKind }], applied: [«M 82 13.7′ SGA-2020»] }
// Marca `row.used = true` en las que casa (las no usadas de SGA-2020 son objetos nuevos: cshGalaxyLocalObjects).
function cshGalaxyLocalApply(objs, local) {
   var out = { matched: 0, sga: 0, pgc: 0, sizeNew: 0, sizeReplaced: 0, zFilled: 0, zReplaced: 0, zKept: 0, zConflict: 0, nameAgree: 0, nameDisagree: 0, pairs: [], applied: [] };
   if (CSH_GAL_LOCAL === false || !local || local.ok !== true) return out;
   var iS = cshGalIndex(local.sga), iP = cshGalIndex(local.pgc);
   for (var i = 0; objs && i < objs.length; ++i) {
      var ob = objs[i];
      if (ob.cls !== "galaxy") continue;
      var rs = cshGalFind(iS, ob.ra, ob.dec), rp = cshGalFind(iP, ob.ra, ob.dec);
      // (medido en Coma: una galaxia de SIMBAD con z 1,09 a < 15″ de una de z 0,02 —una lejana DETRAS de otra— se llevaba el tamaño de la de delante.) Si los dos z se conocen y
      // difieren en mas de CSH_GAL_ZCONFLICT (3 000 km/s: mas que cualquier velocidad peculiar o cambio de sistema), no son el mismo objeto (salvo si el z de la galaxia es el FOTOMETRICO de GLADE+, que se equivoca mucho: ese es justo el que SGA corrige): ni su fila de SGA ni la de PGC en ese sitio.
      if (rs && rs.z > 0 && cshGalHasZ(ob) && ob.z > 0 && !(ob.dist && ob.dist.kind === "photo-z") && Math.abs(ob.z - rs.z) > CSH_GAL_ZCONFLICT) {
         if (rp && cpSfSeparation(rp.ra, rp.dec, rs.ra, rs.dec) * 3600 < 3) rp = null;
         rs = null; ++out.zConflict;
      }
      var row = rs || rp;
      if (rs) rs.used = true;
      if (rp) rp.used = true;
      if (!row) continue;
      var pair = { name: ob.name, sga: rs ? rs.major : null, pgc: rp ? rp.major : null, prev: (ob.sizeArcmin > 0) ? ob.sizeArcmin : null, prevSrc: ob.sizeSource || "",
                   z: cshGalHasZ(ob) ? ob.z : null, zKind: ob.zKind || "", zSga: rs && rs.z > 0 ? rs.z : null, catalog: ob.catalog || "SIMBAD",
                   sgaName: rs ? rs.name + (rs.names.length ? " (" + rs.names.join(", ") + ")" : "") : null, pgcName: rp ? rp.name + (rp.names.length ? " (" + rp.names.join(", ") + ")" : "") : null, sep: row.sep };
      var ag = cshGalNameAgree(ob.name, row);
      if (ag === false && rs && rp && row === rs) { var ag2 = cshGalNameAgree(ob.name, rp); if (ag2 === true) ag = true; }   // (el nombre puede estar solo en la fila de la otra base: IC 3582 esta en PGC, no en SGA)
      if (ag === true) ++out.nameAgree; else if (ag === false) ++out.nameDisagree;
      pair.nameAgree = ag;
      // --- el tamaño (una sola vez: SGA-2020 → PGC; lo aplicado ya no se vuelve a tocar)
      if (ob.sizeLocal !== true) {
         // (el TAMAÑO DE LAS PRUEBAS de la profundidad —brillo superficial, «extensa», aperturas, casado entre catalogos— NO cambia: el de antes (SIMBAD / OpenNGC) o, si no habia,
         // el D25 de PGC (y si no, el de SGA). Medido el 15-nov: la isofota 26 de SGA-2020 es ×1,3-1,7 el D25 y, usada en el brillo superficial medio, ESCONDE galaxias que se veian.
         // Lo que cambia es lo que se DIBUJA y se ENSEÑA: `sizeArcmin`.)
         if (ob.sizeArcmin > 0) {
            ob.sizePrev = { arcmin: ob.sizeArcmin, min: (ob.minArcmin > 0) ? ob.minArcmin : null, source: ob.sizeSource || "SIMBAD" }; ++out.sizeReplaced;
            ob.testSizeArcmin = ob.sizeArcmin; ob.testMinArcmin = (ob.minArcmin > 0) ? ob.minArcmin : null;
         } else {
            var tr = rp || row; ++out.sizeNew;
            ob.testSizeArcmin = tr.major; ob.testMinArcmin = (tr.circle || !(tr.minor > 0)) ? null : tr.minor;
         }
         ob.sizeArcmin = row.major; ob.minArcmin = (row.circle || !(row.minor > 0)) ? null : row.minor; ob.sizePa = row.circle ? null : row.pa;
         ob.sizeSource = row.db; ob.sizeRef = row.name; ob.sizeDef = (row.db === "SGA-2020") ? "isophote-26" : "d25"; ob.sizeLocal = true;
         if (rs && rp) ob.sizeD25 = rp.major;
         if (row.db === "SGA-2020") ++out.sga; else ++out.pgc;
         ++out.matched;
         out.applied.push(ob.name + " " + row.major.toFixed(1) + "′ " + row.db);
      }
      // --- el z (solo SGA-2020 lo trae)
      if (rs && rs.z > 0 && isFinite(rs.z)) {
         if (!cshGalHasZ(ob)) {
            var d0 = cshGalZDist(rs.z);
            if (d0 !== null && ob.extragalactic !== false) {
               ob.z = rs.z; ob.zKind = "SGA-2020"; ob.zSource = "SGA-2020"; ob.redshift = d0; ++out.zFilled;
               var mod = [];
               for (var j = 0; ob.measures && j < ob.measures.length; ++j) if (ob.measures[j].modelled) mod.push(ob.measures[j]);
               ob.dist = cpSfPickDistance(ob.direct || null, ob.redshift, cpSfSummarise(mod, "redshift-model"));
               pair.zFill = true;
            }
         } else if (ob.catalog === "GLADE+" && ob.dist && ob.dist.kind === "photo-z") {
            var d1 = cshGalZDist(rs.z);
            if (d1 !== null) {
               ob.zAlt = { source: "GLADE+ photo-z", z: ob.z }; ob.z = rs.z; ob.zKind = "SGA-2020"; ob.zSource = "SGA-2020"; ob.dist = d1; ob.redshift = d1; ++out.zReplaced; pair.zReplaced = true;
            }
         } else { ob.zAlt = { source: "SGA-2020", z: rs.z }; ++out.zKept; }
      }
      out.pairs.push(pair);
   }
   return out;
}

// CUAL DE LAS DISTANCIAS DE UN OBJETO SE ENSEÑA (diseño; las demas siguen en el
// objeto). La DIRECTA, salvo que el corrimiento al rojo sea de fiar (su error por
// velocidad peculiar no llega al 20 %) Y mas preciso que ella: o no declara error
// ninguno (una sola medida sin error: 3C 273 trae un «T-F» de 657,8 Mpc, que para
// un cuasar no es una medida), o su rango es mas ancho que el del corrimiento. Un
// corrimiento que NO es de fiar nunca tapa a nada: ni a la directa, ni a una
// distancia de modelo de flujo de la literatura.
function cpSfPickDistance(direct, redshift, modelled) {
   var zGood = (redshift !== null && redshift.quality === "good");
   if (direct !== null) {
      if (zGood && !(direct.fraction > 0 && direct.fraction <= redshift.fraction)) return redshift;
      return direct;
   }
   if (zGood) return redshift;
   return modelled || redshift;
}

// La mediana y el rango de unas medidas. null si no hay ninguna.
function cpSfSummarise(list, kind) {
   if (!list || list.length === 0) return null;
   var v = [], lo = Infinity, hi = -Infinity, methods = [], seen = {};
   for (var i = 0; i < list.length; ++i) {
      v.push(list[i].pc);
      if (list[i].lo < lo) lo = list[i].lo;
      if (list[i].hi > hi) hi = list[i].hi;
      var m = list[i].method || "";
      if (m.length > 0 && !seen[m]) { seen[m] = true; methods.push(m); }
   }
   var pc = cpSfMedian(v);
   return { pc: pc, lo: Math.max(lo, 0), hi: hi, source: "simbad", kind: kind, quality: "good", n: list.length, methods: methods,
            interval: (list.length > 1) ? "range of the measurements" : "error of the measurement",
            fraction: (pc > 0) ? (hi - Math.max(lo, 0)) / (2 * pc) : null, ref: "SIMBAD mesDistance" };
}

// LA PARALAJE MAS RECIENTE (N1, decision de Nino, 13-oct-2026). Si entre las medidas directas de un
// objeto hay alguna por paralaje (`method` «paral»), la distancia que se enseña es ESA —la del año mas
// alto segun su bibcode; hoy, Gaia DR3 = 2020yCat.1350....0G—, con su error declarado como intervalo.
// POR QUE (medido en SIMBAD el 13-oct-2026): M 27 tiene 242, 259, 264, 376 y 389 pc; la mediana daba
// 264 pc y la paralaje de DR3 dice 389 (la mediana la ponia un 30 % mas cerca de lo que esta). Las
// demas medidas siguen en `measures` y la mediana de todas en `median`. A igual año, la de menor error.
// Devuelve un resumen como el de cpSfSummarise, con kind "parallax", o null si no hay ninguna.
function cpSfBibYear(bibcode) {
   var y = parseInt(String(bibcode || "").substring(0, 4), 10);
   return (y >= 1900 && y <= 2100) ? y : 0;
}
// De que catalogo es una paralaje, por su bibcode (para decirlo en la ficha). "" si no se conoce.
function cpSfParallaxCatalog(bibcode) {
   var b = String(bibcode || "");
   if (b.indexOf("2020yCat.1350") === 0 || b.indexOf("2022yCat.1355") === 0) return "Gaia DR3";
   if (b.indexOf("2018yCat.1345") === 0) return "Gaia DR2";
   if (b.indexOf("2016yCat.1337") === 0) return "Gaia DR1";
   if (b.indexOf("2007A&A...474..653V") === 0 || b.indexOf("1997A&A...323L..49P") === 0) return "Hipparcos";
   return "";
}
function cpSfLatestParallax(list) {
   var best = null, by = -1, n = 0;
   for (var i = 0; list && i < list.length; ++i) {
      var m = list[i];
      if (String(m.method || "").toLowerCase() !== "paral") continue;
      ++n;
      var y = cpSfBibYear(m.bibcode);
      if (best === null || y > by || (y === by && (m.hi - m.lo) > 0 && ((best.hi - best.lo) <= 0 || (m.hi - m.lo) / m.pc < (best.hi - best.lo) / best.pc))) { best = m; by = y; }
   }
   if (best === null) return null;
   var lo = Math.max(best.lo, 0);
   return { pc: best.pc, lo: lo, hi: best.hi, source: "simbad", kind: "parallax", quality: "good", n: 1, methods: ["paral"],
            interval: (best.hi > best.lo) ? "error of the measurement" : "no error declared", fraction: (best.pc > 0) ? (best.hi - lo) / (2 * best.pc) : null,
            ref: "SIMBAD mesDistance", bibcode: best.bibcode, year: by, catalog: cpSfParallaxCatalog(best.bibcode), parallaxes: n, others: list.length - 1 };
}

// ---------------------------------------------------------------------------
// FOTOMETRIA EN LA IMAGEN: la calibracion (pura; quien lee los pixeles es
// `cpSfMeasureStars`, en starfield_run.js)
// ----------------------------------------------------------------------------
// `samples` = una por estrella medida:
//   { r, g, b }        flujos de apertura (cuentas, ya sin fondo) en los tres canales
//   { snr }            señal / ruido del canal mas debil
//   { saturated, blended }
//   { G, bpRp }        de Gaia (bpRp null si Gaia no lo tiene)
//   { colorSuspect }   bandera de exceso BP/RP de Gaia
// QUE SE CALIBRA, Y CONTRA QUE. El color instrumental es -2,5·log10(b/r); se
// ajusta la RECTA que lo lleva al BP-RP de Gaia (punto cero y termino de color:
// los filtros del usuario no son los de Gaia). La magnitud instrumental
// -2,5·log10(g) se lleva a la G de Gaia con un punto cero y un termino de color.
// Lo que se pinta es, por tanto, BP-RP y G «como los habria medido Gaia», pero
// SALIDOS DE LA FOTO: valen tambien para las estrellas a las que Gaia no les da
// color (un tercio de las debiles de M 13), y las secuencias de referencia (que
// estan en BP-RP / M_G) siguen sirviendo.
// EL BALANCE DE BLANCOS NO HACE FALTA: una ganancia por canal es un sumando en
// magnitudes y se lo lleva el punto cero. Lo que SI hace falta, y se MIDE aqui:
//   · LINEAL: la pendiente de G frente a la magnitud medida vale 1 (ajustada
//     JUNTO con el termino de color: ver `fit`). Un estirado comprime las
//     brillantes y la sube (1,07 con una MTF de 0,02, medido). Fuera de 1 ± 0,05
//     -> `code: "nonlinear"`. Un estirado suave puede pasar: por eso quien llama
//     pregunta ANTES al detector del programa (`cpViewIsLinear`).
//   · QUE EL COLOR DE LA FOTO SIGA AL DE LAS ESTRELLAS: dispersion robusta de
//     BP-RP recuperado menor de 0,15 mag en las estrellas de calibracion. Si no
//     (banda estrecha, canales cambiados) -> `code: "colour-mismatch"`.
//   · ESTRELLAS: 20 de calibracion sin saturar, sin vecina y con señal.
// VALIDACION DENTRO: se ajusta con las de indice par y se mide en las de impar
// (`holdout`), y la dispersion y el sesgo se dan POR MAGNITUD (`byMag`) y POR
// COLOR (`byColor`, cada 0,5 mag del BP-RP de Gaia). De ese ultimo sale el TRAMO
// DE COLOR en que la recta vale (`color.range`): fuera de el el color de la foto
// no se usa (`stars[i].inRange` false), porque en las enanas M se queda corto
// hasta 0,7 mag (medido; el porque, donde se calcula).
// Devuelve
//   { ok, code, n, slope, mag: { zp, k, sigma, n },
//     color: { a, b, sigma, n, range: { min, max, minWhy, maxWhy, minMeasured, maxMeasured } },
//     holdout: { n, sigma, bias }, byMag: [ { mag, n, sigma, bias } ],
//     byColor: [ { color, n, sigma, bias } ], flagged: { faint, outOfRange, magMismatch, colourMismatch },
//     stars: [ { color, mag, inRange, use, why } | null ] }   (una por muestra, null si no medible)
// CADA MEDIDA DICE SI SE USA (`use`) y, si no, por que (`why`), en este orden:
//   "faint"         señal / ruido menor que la de calibrar: la precision que se da (`byMag`) no se ha medido ahi
//   "colour-range"  fuera del tramo de color en que la recta vale (`inRange` false)
//   "mag-mismatch"  la magnitud medida no casa con la G de Gaia (PHOT_MAG_SIGMAS): la medida esta mal
//   "colour-mismatch" el color medido no casa con el BP-RP de Gaia (PHOT_MAG_SIGMAS, PHOT_COLOUR_CHECK): el ajuste
//                   robusto ya la habia descartado y no debe volver como buena (29-oct, Codex R3 H-1)
// `flagged` las cuenta. El color y la magnitud se dan igual: quien los use sabe lo que valen.
// ---------------------------------------------------------------------------
function cpSfPhotCalibrate(samples) {
   var out = { ok: false, code: "", n: 0, slope: null, color: null, mag: null, holdout: null, byMag: [], byColor: [], stars: [],
               flagged: { faint: 0, outOfRange: 0, magMismatch: 0, colourMismatch: 0 }, rejected: { saturated: 0, blended: 0, faint: 0 } };
   var cal = [], i, s;
   var LOG = -2.5 / Math.LN10;
   function inst(q) { return (q.r > 0 && q.g > 0 && q.b > 0) ? { c: LOG * Math.log(q.b / q.r), m: LOG * Math.log(q.g) } : null; }
   for (i = 0; i < samples.length; ++i) {
      s = samples[i];
      if (s.saturated) { ++out.rejected.saturated; continue; }
      if (s.blended) { ++out.rejected.blended; continue; }
      if (!(s.snr >= CP_SF.PHOT_MIN_SNR)) { ++out.rejected.faint; continue; }
      if (s.bpRp === null || s.bpRp === undefined || !isFinite(s.G) || s.colorSuspect) continue;
      if (inst(s) !== null) cal.push(i);
   }
   out.n = cal.length;
   if (cal.length < CP_SF.PHOT_MIN_CAL) { out.code = "few-stars"; return out; }

   function fit(list) {
      var xc = [], yc = [], xm = [], ym = [], k;
      for (k = 0; k < list.length; ++k) {
         var q = samples[list[k]], v = inst(q);
         xc.push(v.c); yc.push(q.bpRp); xm.push(v.m); ym.push(q.G);
      }
      // G = a + s·m_inst + k·(BP-RP): la pendiente s dice si es lineal. CON el color dentro del ajuste: sin el,
      // la pendiente se lleva la correlacion entre color y magnitud del campo (las debiles son mas rojas) y una
      // imagen lineal de Cygnus daba 0,88 (el termino de color, -0,77, por 0,15 mag de color por magnitud).
      var plane = cpSfRobustPlane(xm, yc, ym, CP_SF.PHOT_CLIP);
      var slope = { ok: plane.ok, b: plane.b1 };
      var col = cpSfRobustLine(xc, yc, CP_SF.PHOT_CLIP);                   // BP-RP = a + b·c_inst
      // G - m_inst = zp + k·(BP-RP)
      var dm = [], bc = [];
      for (k = 0; k < list.length; ++k) { dm.push(ym[k] - xm[k]); bc.push(yc[k]); }
      var mag = cpSfRobustLine(bc, dm, CP_SF.PHOT_CLIP);
      return { slope: slope, col: col, mag: mag };
   }
   var all = fit(cal);
   if (!all.slope.ok || !all.col.ok || !all.mag.ok) { out.code = "few-stars"; return out; }
   out.slope = all.slope.b;
   out.color = { a: all.col.a, b: all.col.b, sigma: all.col.sigma, n: all.col.n };
   out.mag = { zp: all.mag.a, k: all.mag.b, sigma: all.mag.sigma, n: all.mag.n };

   // La validacion: ajustar con las pares, medir en las impares.
   var even = [], odd = [];
   for (i = 0; i < cal.length; ++i) ((i % 2) ? odd : even).push(cal[i]);
   var half = fit(even), res = [];
   if (half.col.ok)
      for (i = 0; i < odd.length; ++i) {
         var qo = samples[odd[i]], vo = inst(qo);
         res.push(half.col.a + half.col.b * vo.c - qo.bpRp);
      }
   if (res.length >= 5) out.holdout = { n: res.length, bias: cpSfMedian(res), sigma: cpSfRobustSigma(res) };

   // Por magnitud (cada magnitud entera de G), con TODAS las de calibracion.
   var bins = {};
   for (i = 0; i < cal.length; ++i) {
      var qb = samples[cal[i]], vb = inst(qb), key = Math.floor(qb.G);
      (bins[key] || (bins[key] = [])).push(all.col.a + all.col.b * vb.c - qb.bpRp);
   }
   for (var kb in bins)
      if (Object.prototype.hasOwnProperty.call(bins, kb) && bins[kb].length >= 5)
         out.byMag.push({ mag: Number(kb), n: bins[kb].length, bias: cpSfMedian(bins[kb]), sigma: cpSfRobustSigma(bins[kb]) });
   out.byMag.sort(function(p, q) { return p.mag - q.mag; });
   // Y por COLOR (cada 0,5 mag del BP-RP de Gaia): donde la recta deja de valer se ve aqui, no en la media.
   var cbins = {};
   for (i = 0; i < cal.length; ++i) {
      var qc = samples[cal[i]], vc = inst(qc), kc = Math.floor(qc.bpRp * 2);
      (cbins[kc] || (cbins[kc] = [])).push(all.col.a + all.col.b * vc.c - qc.bpRp);
   }
   for (var kk in cbins)
      if (Object.prototype.hasOwnProperty.call(cbins, kk) && cbins[kk].length >= 5)
         out.byColor.push({ color: Number(kk) / 2, n: cbins[kk].length, bias: cpSfMedian(cbins[kk]), sigma: cpSfRobustSigma(cbins[kk]) });
   out.byColor.sort(function(p, q) { return p.color - q.color; });

   // EL TRAMO DE COLOR EN QUE LA RECTA VALE (medido en la sonda, 13-oct-2026). El color b - r de unos filtros RGB
   // SE SATURA en las enanas M: su BP-RP sigue creciendo por el rojo lejano que RP ve y el filtro R no. En tres de
   // cuatro imagenes reales el sesgo pasa de -0,02 (BP-RP 1,5 a 2,0) a -0,23 / -0,30 (2,0 a 2,5) y a -0,40 / -0,67
   // (2,5 a 3,0); en la cuarta (campo ENROJECIDO de Cygnus: rojas por el polvo, no enanas M) la recta vale hasta
   // 3,0. No lo arregla un polinomio: una magnitud entera de color de verdad cabe en 0,15 de color medido. Asi que
   // se MIDE hasta donde vale -los tramos seguidos, desde el mas poblado, con un sesgo de PHOT_MAX_COLOR_BIAS o
   // menos- y FUERA de ahi el color de la foto NO se usa (`inRange` false). `minWhy` / `maxWhy`: "bias" (se ha
   // VISTO que deja de valer) o "no-stars" (no hay cinco estrellas de calibracion mas alla: no se sabe, y tampoco
   // se usa). LIMITE CONOCIDO (sintetico): la recta aguanta hasta un 20 % de estrellas de calibracion mas alla del
   // codo; con un 30 % se tuerce (termino de color 0,85 -> 0,93, sesgos de 0,07 dentro) y con un 40 % se niega.
   var range = null;
   if (out.byColor.length) {
      var top = 0, lo, hi, last = out.byColor.length - 1;
      for (i = 1; i <= last; ++i) if (out.byColor[i].n > out.byColor[top].n) top = i;
      var fits = function(e) { return Math.abs(e.bias) <= CP_SF.PHOT_MAX_COLOR_BIAS; };
      var joined = function(p, q) { return Math.abs(out.byColor[q].color - out.byColor[p].color - 0.5) < 1e-9; };
      if (fits(out.byColor[top])) {
         lo = hi = top;
         while (lo > 0 && joined(lo - 1, lo) && fits(out.byColor[lo - 1])) --lo;
         while (hi < last && joined(hi, hi + 1) && fits(out.byColor[hi + 1])) ++hi;
         range = { min: out.byColor[lo].color, max: out.byColor[hi].color + 0.5,
                   minWhy: (lo > 0 && joined(lo - 1, lo)) ? "bias" : "no-stars",
                   maxWhy: (hi < last && joined(hi, hi + 1)) ? "bias" : "no-stars" };
         // Para las estrellas SIN color en Gaia solo queda su color medido, y ese engaña justo aqui: una enana M
         // de BP-RP 2,6 se mide en 1,9. El limite en color MEDIDO es lo mas azul (o lo mas rojo, por el otro lado)
         // que ha medido una de calibracion que se sabe que esta fuera, quitando una de cada diez.
         var above = [], below = [];
         for (i = 0; i < cal.length; ++i) {
            var qr = samples[cal[i]], mr = all.col.a + all.col.b * inst(qr).c;
            if (qr.bpRp >= range.max) above.push(mr);
            else if (qr.bpRp < range.min) below.push(mr);
         }
         above.sort(function(p, q) { return p - q; });
         below.sort(function(p, q) { return q - p; });
         // (solo por el lado en que se ha VISTO que deja de valer: por el otro hay menos de cinco y una sola rara
         // se llevaria el limite; medido en NGC 1560, donde una azul medida en 0,70 lo subia de 0,5 a 0,70)
         range.maxMeasured = (range.maxWhy === "bias" && above.length) ? Math.min(range.max, above[Math.floor(above.length / 10)]) : range.max;
         range.minMeasured = (range.minWhy === "bias" && below.length) ? Math.max(range.min, below[Math.floor(below.length / 10)]) : range.min;
      }
   }
   out.color.range = range;

   if (Math.abs(all.slope.b - 1) > CP_SF.PHOT_SLOPE_TOL) { out.code = "nonlinear"; return out; }
   if (!(all.col.sigma <= CP_SF.PHOT_MAX_COLOR_SIGMA) || !(all.col.b > 0)) { out.code = "colour-mismatch"; return out; }
   // Sin tramo: o no hay cinco estrellas de calibracion juntas en ningun medio de magnitud de color (no hay con que
   // saberlo), o la recta no vale ni donde mas estrellas hay (en la practica la dispersion ya lo ha dicho antes).
   if (range === null) {
      out.code = out.byColor.length ? "colour-mismatch" : "few-stars";
      return out;
   }

   // Aplicar a TODAS las medibles (tambien a las que Gaia no les da color).
   for (i = 0; i < samples.length; ++i) {
      s = samples[i];
      var v2 = (s.saturated || s.blended) ? null : inst(s);
      if (v2 === null) { out.stars.push(null); continue; }
      var color = all.col.a + all.col.b * v2.c;
      // dentro del tramo: por el color de Gaia si lo tiene y es de fiar; si no, por el medido y su limite
      var known = (s.bpRp !== null && s.bpRp !== undefined && isFinite(s.bpRp) && !s.colorSuspect);
      var inRange = known ? (s.bpRp >= range.min && s.bpRp < range.max) : (color >= range.minMeasured && color <= range.maxMeasured);
      var mag = v2.m + all.mag.a + all.mag.b * color, why = "";
      if (!(s.snr >= CP_SF.PHOT_MIN_SNR)) { why = "faint"; ++out.flagged.faint; }
      else if (!inRange) { why = "colour-range"; ++out.flagged.outOfRange; }
      else if (isFinite(s.G) && Math.abs(mag - s.G) > CP_SF.PHOT_MAG_SIGMAS * Math.sqrt(all.mag.sigma * all.mag.sigma + (LOG / s.snr) * (LOG / s.snr))) { why = "mag-mismatch"; ++out.flagged.magMismatch; }
      else if (known && CP_SF.PHOT_COLOUR_CHECK && Math.abs(color - s.bpRp) > CP_SF.PHOT_MAG_SIGMAS * Math.sqrt(all.col.sigma * all.col.sigma + 2 * (LOG / s.snr) * (LOG / s.snr))) { why = "colour-mismatch"; ++out.flagged.colourMismatch; }
      out.stars.push({ color: color, mag: mag, inRange: inRange, use: (why === ""), why: why });
   }
   out.ok = true;
   return out;
}

// La secuencia principal de referencia (tabla de Mamajek empaquetada), ya leida:
// [{ spt, teff, bpRp, absG }], de caliente a fria.
function cpSfMainSequence(text) {
   var t = cpSfParseTable(text, ";"), out = [];
   for (var i = 0; i < t.rows.length; ++i) {
      var c = cpSfNum(t.rows[i].bprp), m = cpSfNum(t.rows[i].mg);
      if (c === null || m === null) continue;
      out.push({ spt: String(t.rows[i].spt), teff: cpSfNum(t.rows[i].teff), bpRp: c, absG: m });
   }
   return out;
}

// ---------------------------------------------------------------------------
// LAS NEBULOSAS: A QUE DISTANCIA ESTA LA NEBULOSIDAD DE LA FOTO (14-oct-2026)
// ----------------------------------------------------------------------------
// Peticion de Nino: «en la representacion 3D / Distances, en el caso de la nebulosidad, ¿puedes tambien
// asignarle una distancia y ponerla en ese punto?». Una nebulosa difusa casi nunca tiene tamaño en SIMBAD y
// muchas tampoco distancia: por eso la LISTA sale del catalogo de Sharpless (empaquetado: `nebulae.csv`, ver
// `src/data/starfield/PROVENANCE_NEBULAE.txt`), que dice donde esta cada region HII y cuanto mide, y la
// DISTANCIA se busca en este orden (el de Nino), diciendo SIEMPRE de donde sale y con que error:
//   1. "simbad"   la de SIMBAD para LA PROPIA NEBULOSA (su identificador «Sh 2-NNN»; la regla N1: la paralaje
//                 mas reciente si alguna medida lo es; si no, la mediana con el rango). OJO, MEDIDO el 14-oct-2026:
//                 SIMBAD da las de Foster y Brunt 2015 con el metodo «kin», y son espectrofotometricas; y a veces
//                 el objeto de SIMBAD de esa Sharpless es el CUMULO que la ilumina (Sh 2-199 = IC 1848, «OpC»):
//                 la distancia es la de ese objeto, y se dice cual es (`simbadName`, `simbadType`).
//   2. "foster-brunt"  Foster y Brunt 2015 (AJ 150, 147): distancia espectrofotometrica a sus estrellas ionizantes.
//      "wise"          Anderson et al. 2014 (WISE HII): casi siempre CINEMATICA (el metodo va en `method`).
//   3. "members-parallax"  las estrellas que SIMBAD cuelga de la nebulosa (su jerarquia, `h_link`) con paralaje
//                 de Gaia DR3 de fiar (paralaje / error >= 5): la MEDIANA, corregida del punto cero, con su error
//                 (`cpSfNebulaMembersParallax`). Solo si su error no pasa del 20 %.
//      "cluster-inside"    un cumulo CONFIRMADO en la foto (con su distancia de catalogo) cuyo centro cae dentro de
//                 la nebulosa. Es una asociacion SOLO POR POSICION, y se dice.
//   4. "manual"   la que escriba el usuario. Si la ha escrito, MANDA (es una orden suya; se dice «escrita a mano»).
// Si no hay ninguna, la nebulosa no se coloca y se dice. Todo en parsecs.
// ---------------------------------------------------------------------------
// El numero de Sharpless de un identificador («SH  2-132», «Sh 2-132», «Sh2-132»), o 0.
function cpSfSharplessNumber(id) {
   var m = /^\s*sh\s*2\s*-\s*0*(\d{1,3})\s*$/i.exec(String(id || ""));
   return m ? parseInt(m[1], 10) : 0;
}
function cpSfSharplessId(n) { return "Sh 2-" + n; }

// `nebulae.csv` -> [ { sh2, id, ra, dec, diamArcmin, radiusDeg, fb, wise } ]. `fb` y `wise` = null o
// { pc, lo, hi, source, kind, ref, interval, … } (un error de 0 o vacio = «no declarado»: lo = hi = pc).
function cpSfNebulaCatalog(text) {
   var t = cpSfParseTable(text, ","), out = [];
   function kpc(v, e, source, ref, extra) {
      if (v === null || !(v > 0)) return null;
      var err = (e !== null && e > 0) ? e : 0, d = { pc: v * 1000, lo: Math.max(0, v - err) * 1000, hi: (v + err) * 1000, source: source, ref: ref,
                                                    interval: (err > 0) ? "1-sigma" : "no error declared", fraction: err / v, quality: "good" };
      for (var k in extra) if (Object.prototype.hasOwnProperty.call(extra, k)) d[k] = extra[k];
      return d;
   }
   for (var i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], n = parseInt(r.sh2, 10), ra = cpSfNum(r.ra), dec = cpSfNum(r.dec), diam = cpSfNum(r.diam_arcmin);
      if (!(n > 0) || ra === null || dec === null) continue;
      out.push({ sh2: n, id: cpSfSharplessId(n), ra: ra, dec: dec, diamArcmin: (diam !== null && diam > 0) ? diam : 0, radiusDeg: (diam !== null && diam > 0) ? diam / 120 : 0,
                 fb: kpc(cpSfNum(r.fb_kpc), cpSfNum(r.fb_err_kpc), "foster-brunt", "Foster & Brunt 2015, AJ 150, 147 (stellar distance)", { kind: "stellar", n: cpSfNum(r.fb_n) || 0 }),
                 wise: kpc(cpSfNum(r.wise_kpc), cpSfNum(r.wise_err_kpc), "wise", "Anderson et al. 2014, ApJS 212, 1 (WISE HII)",
                           { kind: /kin/i.test(String(r.wise_method || "")) ? "kinematic" : /parallax/i.test(String(r.wise_method || "")) ? "parallax" : "other",
                             method: String(r.wise_method || ""), regionId: String(r.wise_id || ""), kda: String(r.wise_kda || "") }) });
   }
   return out;
}

// Las nebulosas del catalogo cuyo disco toca el circulo del campo.
function cpSfNebulaeNear(catalog, ra, dec, radiusDeg) {
   var out = [];
   for (var i = 0; catalog && i < catalog.length; ++i) {
      var c = catalog[i], reach = radiusDeg + c.radiusDeg;
      if (Math.abs(c.dec - dec) > reach) continue;
      if (cpSfSeparation(ra, dec, c.ra, c.dec) <= reach) out.push(c);
   }
   return out;
}

// LA HUELLA DE UNA NEBULOSA EN LA FOTO. `grid` = { nx, ny, width, height, ra: [], dec: [] }: el cielo de los
// centros de una rejilla de nx × ny celdas sobre la foto (fila a fila). Lo que cae dentro del disco de la
// nebulosa (radio `radiusDeg` alrededor de su centro) es su huella: devuelve { cells, frac (la fraccion de la
// foto que cubre), x0, y0, x1, y1 (su caja en pixeles, recortada a la foto), cx, cy (su centro de masas) } o null
// si no cae ninguna celda. Va por la rejilla, y no proyectando el disco, porque el centro de una nebulosa grande
// puede quedar FUERA de la foto (Sh 2-199 en el campo de Collinder 34), y proyectar desde ahi es extrapolar.
function cpSfNebulaFootprint(ra, dec, radiusDeg, grid) {
   if (!grid || !(grid.nx > 0) || !(grid.ny > 0) || !(radiusDeg > 0)) return null;
   var cw = grid.width / grid.nx, ch = grid.height / grid.ny, n = 0, sx = 0, sy = 0, x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
   for (var j = 0; j < grid.ny; ++j)
      for (var i = 0; i < grid.nx; ++i) {
         var k = j * grid.nx + i, r = grid.ra[k], d = grid.dec[k];
         if (r === null || d === null || !isFinite(r) || !isFinite(d)) continue;
         if (cpSfSeparation(ra, dec, r, d) > radiusDeg) continue;
         var cx = (i + 0.5) * cw, cy = (j + 0.5) * ch;
         ++n; sx += cx; sy += cy;
         if (cx - cw / 2 < x0) x0 = cx - cw / 2;
         if (cy - ch / 2 < y0) y0 = cy - ch / 2;
         if (cx + cw / 2 > x1) x1 = cx + cw / 2;
         if (cy + ch / 2 > y1) y1 = cy + ch / 2;
      }
   if (n === 0) return null;
   return { cells: n, frac: n / (grid.nx * grid.ny), x0: Math.max(0, x0), y0: Math.max(0, y0), x1: Math.min(grid.width, x1), y1: Math.min(grid.height, y1), cx: sx / n, cy: sy / n };
}

// ---------------------------------------------------------------------------
// (15-nov-2026, N1-A de docs/investigacion-pixinsight-196-b1718-catalogos.md §7.2) LA HUELLA POR CONTORNO. PURA (node la ejecuta).
// PixInsight 1.9.6 build 1718 trae, en ExtendedSources y SIN instalar nada, los CONTORNOS poligonales de las nebulosas: `Nebula-Outlines` (Sharpless,
// LBN, LDN y Barnard, sobre el mapa de H-alfa de Finkbeiner y los recuentos de estrellas de Gaia; clave exacta «Sh2-199») y `OpenNGC-Outlines`
// (nebulosas NGC/IC de OpenNGC, M. Verga, CC BY-SA 4.0; clave NGC/IC: el cruce con Sharpless NO esta en la base). Cuando hay contorno, la huella de la
// nebulosa en la foto (`foot`) sale de el en vez del disco de `cpSfNebulaFootprint`; sin contorno, sin la base o con cualquier error, es EXACTAMENTE el
// disco de siempre (ni un campo mas) y `foot.source` no existe (ausente = disco). La consulta a PixInsight (`cshNebOutlinesLocal`) vive en
// csh_starfield_run.js; aqui solo hay aritmetica.
//   fila (la da la consulta) = { db, key, level, ra, dec, outline }  ·  outline = «ra,dec ra,dec ...|ra,dec ...» (anillos separados por «|», grados
//   ICRS, regla PAR-IMPAR: un anillo dentro de otro es un agujero; MEDIDO el 15-nov en tests/_b1718/n1).
// REGLA DE ELECCION (todo aqui, en CSH_NEB_OUTLINE: UN solo sitio). AJUSTADA A OJO SOBRE 6 FOTOS, 15-nov-2026, PENDIENTE DEL JUICIO DE NINO
// (tests/_b1718/n1/b1718_n1_outlines.log; no hay una medida contra una verdad: solo lo que se ve en el montaje n1_disco_vs_contorno.png):
//   · base de PixInsight (Nebula-Outlines, mapa de H-alfa): clave de Sharpless EXACTA, nivel PI_LEVEL = 2 (40 % del contraste) o, si no lo hay, el mas alto por debajo;
//   · OpenNGC: por POSICION (criterio geometrico de `cshNebMatchOpenNgc`), el nivel mas alto de los que haya (NGC_LEVEL = 0);
//   · si el nivel elegido no toca la foto (ninguna celda de la rejilla gruesa cae dentro), o no hay contorno, el disco: no se salta a otro nivel (seria otra definicion del contorno).
//   · (N1-B, decision de Nino 15-nov) una Sharpless con diametro de catalogo >= GIANT_DIAM_ARCMIN (600′) usa SIEMPRE el disco.
// Costura del rojo: CSH_NEB_OUTLINE.ON = false (el disco de antes).
// ---------------------------------------------------------------------------
var CSH_NEB_OUTLINE = {
   ON: true,
   PI_DB: "Nebula-Outlines",        // base de PixInsight: clave Sharpless exacta
   NGC_DB: "OpenNGC-Outlines",      // base de OpenNGC: casado por posicion
   PI_LEVEL: 2,                     // nivel preferido en Nebula-Outlines (1 = 20 %, 2 = 40 %, 3 = 70 % del contraste); si falta, el mas alto por debajo
   NGC_LEVEL: 0,                    // OpenNGC: 0 = el nivel mas alto que haya; N = ese como mucho
   CONE_SLACK: 1,                   // grados que se añaden al cono de la consulta (el centro de un contorno puede estar fuera de la foto)
   MAX_ROWS: 20000,                 // mas filas que esto en el cono: la base no se usa (no se trunca)
   // (15-nov-2026, N1-B, ENCARGO NUEVO) LAS SHARPLESS GIGANTES VUELVEN AL DISCO. Decision de Nino 15-nov-2026 («Sí, con disco»): el contorno de Sh2-276 (Lazo de Barnard, poligono tosco) dejaba un
   // borde dentado en la capa de Orion y el disco se veia mejor. Una Sharpless con diametro de catalogo >= GIANT_DIAM_ARCMIN NO usa contorno: su `foot` es EXACTAMENTE el del disco (como cualquier
   // otra sin contorno). Umbral puesto entre Sh2-264 (390') y Sh2-109 (1080'), PENDIENTE DEL JUICIO DE NINO. Por encima, en nebulae.csv (medido): Sh2-276 (1200'), Sh2-109 (1080'), Sh2-312 (720'), Sh2-245 (720').
   // 0 o menos = sin umbral (el contorno de N1-A para todas). No afecta a las nebulosas nuevas de N1-B (no son Sharpless).
   GIANT_DIAM_ARCMIN: 600,
   // (15-nov-2026, N1-B) LAS NEBULOSAS QUE NO SON SHARPLESS: las de OpenNGC-Outlines cuyo contorno toca la foto y que ninguna Sharpless de la lista tiene por suya entran en
   // `result.nebulae.objects` (DETRAS de las Sharpless) con su huella de contorno (`cshNebExtraSelect`, mas abajo). EXTRA = false: exactamente lo de N1-A (la costura para comparar A frente a A+B).
   EXTRA: true,
   // Que claves de OpenNGC-Outlines valen: NGC/IC (con letra opcional), Messier y Caldwell. Quedan FUERA, por la regla 1 del encargo y MEDIDO el 15-nov (sonda
   // tests/_b1718/n1/b1718_n1b_ngcdb_probe_239.log, 193 claves): LBN 1032 y 1037 (las LBN, toscas y sin correspondencia visible en la fase 1) y las «regiones» de constelacion
   // (Cepheus, Orion, Cygnus, Vela, Puppis, Scorpius, Antlia, Corona Australis: tipo null, cubren media foto) y la LMC: no son nebulosas, son fronteras de zona.
   EXTRA_KEY_RX: /^(NGC|IC|M|C)\d+[A-Z]?$/i,
   // PENDIENTE DEL JUICIO DE NINO (se proponen con la medida de tests/_b1718/n1/n1B_*.log, 7 fotos del 15-nov): cuantas nebulosas nuevas como mucho por foto y la huella minima
   // (fraccion de la FOTO, de la rejilla gruesa de 48 x 32 = 1536 celdas: 0,005 son 8 celdas). Lo que no pasa se cuenta en `extra.left` y se lista en `extra.rejected`.
   EXTRA_MAX: 6,
   EXTRA_MIN_FRAC: 0.004,
   // Regla 3 (cielo profundo con recorte propio): el objeto de SIMBAD tiene que ser TAN GRANDE como la nebulosa: su radio (tamaño / 2) al menos esta fraccion del radio equivalente del contorno. MEDIDO el
   // 15-nov (csh_neb_extra_test_239_rojo_notwins.log): sin esto, una region WISE o una fuente IRAS pequeña dentro del contorno (IC 1848 → «IRAS 02531+6032», NGC 2237 y NGC 1976 → «[ABB2014] WISE …»)
   // se llevaba la nebulosa entera, y su recorte propio es solo ese trocito. PENDIENTE DEL JUICIO DE NINO.
   EXTRA_DS_RATIO: 0.5
};
// Las 11 clases de objeto de SIMBAD que NO son luz de la foto (supercascaras de HI, nubes moleculares, nubes oscuras, glóbulos, radio/submilimétrico…) y por tanto no llevan recorte propio en
// el 3D. COPIA de CP_SV_NOT_PHOTO_OTYPES de Cabra3D/src/ui/starfield_view.js (las mismas claves; la prueba csh_neb_outline_node.js H0 las compara).
var CSH_NEB_NOT_PHOTO_OTYPES = { sh: 1, MoC: 1, cor: 1, glb: 1, DNe: 1, HVC: 1, smm: 1, mm: 1, out: 1, Cld: 1, HI: 1 };
var CSH_NEB_D2R = Math.PI / 180;

// «Sh 2-199», «Sh2-199», «SH2-199» -> «SH2-199» (la clave de la base y la de nuestro catalogo se comparan sin espacios ni mayusculas)
function cshNebKeyNorm(s) { return String(s || "").replace(/\s+/g, "").toUpperCase(); }

// Proyeccion gnomonica alrededor de (ra0, dec0): [x, y] en grados, o null si el punto esta en el hemisferio opuesto (o casi: cos < 0,05).
function cshNebTan(ra0, dec0, ra, dec) {
   var k = CSH_NEB_D2R, d0 = dec0 * k, d = dec * k, da = (ra - ra0) * k;
   var cc = Math.sin(d0) * Math.sin(d) + Math.cos(d0) * Math.cos(d) * Math.cos(da);
   if (!(cc > 0.05)) return null;
   return [Math.cos(d) * Math.sin(da) / cc / k, (Math.cos(d0) * Math.sin(d) - Math.sin(d0) * Math.cos(d) * Math.cos(da)) / cc / k];
}
// La inversa: (x, y) en grados sobre el plano tangente en (ra0, dec0) -> { ra, dec }.
function cshNebUntan(ra0, dec0, x, y) {
   var k = CSH_NEB_D2R, xr = x * k, yr = y * k, d0 = dec0 * k, rho = Math.sqrt(xr * xr + yr * yr);
   if (!(rho > 0)) return { ra: ra0, dec: dec0 };
   var c = Math.atan(rho), sc = Math.sin(c), cc = Math.cos(c);
   var dec = Math.asin(cc * Math.sin(d0) + yr * sc * Math.cos(d0) / rho);
   var ra = ra0 * k + Math.atan2(xr * sc, rho * Math.cos(d0) * cc - yr * Math.sin(d0) * sc);
   ra = (ra / k) % 360; if (ra < 0) ra += 360;
   return { ra: ra, dec: dec / k };
}

// «ra,dec ra,dec|ra,dec ...» -> [ [ [ra, dec], ... ], ... ]. Anillos de menos de 3 vertices o con numeros que no lo son se descartan.
function cshNebParseOutline(s) {
   var rings = [], parts = String(s || "").split("|"), i, j;
   for (i = 0; i < parts.length; ++i) {
      var vs = parts[i].replace(/^\s+|\s+$/g, "").split(/\s+/), ring = [];
      for (j = 0; j < vs.length; ++j) {
         var q = vs[j].split(",");
         if (q.length !== 2) continue;
         var a = parseFloat(q[0]), b = parseFloat(q[1]);
         if (isFinite(a) && isFinite(b)) ring.push([a, b]);
      }
      if (ring.length >= 3) rings.push(ring);
   }
   return rings;
}

// Los anillos proyectados sobre el plano tangente de (ra0, dec0): [ { P: [[x, y], ...], x0, y0, x1, y1 } ]; un anillo con un vertice en el hemisferio opuesto no entra.
function cshNebTanRings(rings, ra0, dec0) {
   var R = [], i, j;
   for (i = 0; i < rings.length; ++i) {
      var P = [], x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, ok = true;
      for (j = 0; j < rings[i].length; ++j) {
         var t = cshNebTan(ra0, dec0, rings[i][j][0], rings[i][j][1]);
         if (t === null) { ok = false; break; }
         P.push(t);
         if (t[0] < x0) x0 = t[0]; if (t[0] > x1) x1 = t[0]; if (t[1] < y0) y0 = t[1]; if (t[1] > y1) y1 = t[1];
      }
      if (ok) R.push({ P: P, x0: x0, y0: y0, x1: x1, y1: y1 });
   }
   return R;
}
// Punto (x, y) dentro de los anillos proyectados, regla PAR-IMPAR (cada anillo que lo contiene conmuta el estado). `evenOdd === false`: el control en rojo
// (basta estar dentro de un anillo: los agujeros se pierden).
function cshNebInTanRings(R, x, y, evenOdd) {
   var inside = false, any = false;
   for (var i = 0; i < R.length; ++i) {
      var Q = R[i];
      if (x < Q.x0 || x > Q.x1 || y < Q.y0 || y > Q.y1) continue;
      var P = Q.P, n = P.length, ins = false;
      for (var a = 0, b = n - 1; a < n; b = a++) {
         var xa = P[a][0], ya = P[a][1], xb = P[b][0], yb = P[b][1];
         if ((ya > y) !== (yb > y) && x < (xb - xa) * (y - ya) / (yb - ya) + xa) ins = !ins;
      }
      if (ins) { inside = !inside; any = true; }
   }
   return (evenOdd === false) ? any : inside;
}
// ¿Cae (ra, dec) dentro de los anillos? (los anillos se proyectan sobre el plano tangente de (ra0, dec0))
function cshNebPointInRings(rings, ra, dec, ra0, dec0) {
   var c = cshNebTan(ra0, dec0, ra, dec);
   if (c === null) return false;
   return cshNebInTanRings(cshNebTanRings(rings, ra0, dec0), c[0], c[1], true);
}
// El centroide (de area) del anillo MAYOR de un contorno -> { ra, dec } o null.
function cshNebCentroid(rings, ra0, dec0) {
   var R = cshNebTanRings(rings, ra0, dec0), best = null, bestA = 0, i, j;
   for (i = 0; i < R.length; ++i) {
      var P = R[i].P, n = P.length, A = 0, cx = 0, cy = 0;
      for (j = 0; j < n; ++j) {
         var p = P[j], q = P[(j + 1) % n], cr = p[0] * q[1] - q[0] * p[1];
         A += cr; cx += (p[0] + q[0]) * cr; cy += (p[1] + q[1]) * cr;
      }
      if (Math.abs(A) > bestA) { bestA = Math.abs(A); best = { A: A, cx: cx, cy: cy }; }
   }
   if (best === null || !(bestA > 0)) return null;
   return cshNebUntan(ra0, dec0, best.cx / (3 * best.A), best.cy / (3 * best.A));
}

// Las filas de la consulta -> un indice. { rows, skipped, entries: [ { db, key, norm, ra, dec, levels: { "<n>": { level, rings } }, avail: [n ascendente] } ], by: { "<db>|<NORM>": entry } }
function cshNebPrepare(rows) {
   var P = { rows: 0, skipped: 0, entries: [], by: {} }, i;
   for (i = 0; rows && i < rows.length; ++i) {
      var r = rows[i], lv = r.level | 0, rings = cshNebParseOutline(r.outline), nk = cshNebKeyNorm(r.key);
      if (!r.db || nk.length === 0 || lv < 1 || rings.length === 0 || !isFinite(r.ra) || !isFinite(r.dec)) { ++P.skipped; continue; }
      ++P.rows;
      var id = r.db + "|" + nk, e = P.by[id];
      if (!e) { e = P.by[id] = { db: r.db, key: String(r.key), norm: nk, ra: r.ra, dec: r.dec, levels: {}, avail: [], name: String(r.name || ""), ntype: String(r.ntype || "") }; P.entries.push(e); }
      if (!e.levels[lv]) { e.levels[lv] = { level: lv, rings: rings }; e.avail.push(lv); }
   }
   for (i = 0; i < P.entries.length; ++i) P.entries[i].avail.sort(function(a, b) { return a - b; });
   return P;
}

// El CRITERIO DE CASADO con OpenNGC, por posicion (la base no dice a que Sharpless corresponde cada NGC/IC y no hay tabla de alias). Un contorno de OpenNGC es la
// nebulosa Sharpless `neb` = { ra, dec, radiusDeg } si se cumplen las DOS:
//   (1) el centro de Sharpless cae DENTRO de su contorno (el del nivel mas bajo que tenga: el mas amplio), y
//   (2) el centroide de ese contorno (area del anillo mayor) cae DENTRO del disco de Sharpless (a menos de su radio del centro).
// (2) evita que una Sharpless pequeña dentro de una nebulosa grande se lleve el contorno de esta (Sh2-198, 9′, dentro de IC 1848: su centro cae en el contorno
// pero el centroide de IC 1848 esta a 0,45° de ella). Si hay varios contornos que cumplen, el de centroide MAS CERCANO al centro de Sharpless.
// -> { entry, centroid: { ra, dec }, sep (grados, centroide - centro de Sharpless) } o null.
function cshNebMatchOpenNgc(neb, prep) {
   var best = null;
   if (!prep || !(neb.radiusDeg > 0)) return null;
   for (var i = 0; i < prep.entries.length; ++i) {
      var e = prep.entries[i];
      if (e.db !== CSH_NEB_OUTLINE.NGC_DB || e.avail.length === 0) continue;
      var L = e.levels[e.avail[0]];
      if (!cshNebPointInRings(L.rings, neb.ra, neb.dec, e.ra, e.dec)) continue;
      var c = cshNebCentroid(L.rings, e.ra, e.dec);
      if (c === null) continue;
      var s = cpSfSeparation(neb.ra, neb.dec, c.ra, c.dec);
      if (s > neb.radiusDeg) continue;
      if (best === null || s < best.sep) best = { entry: e, centroid: c, sep: s };
   }
   return best;
}

// El contorno de una nebulosa de Sharpless `neb` = { sh2, id, ra, dec, radiusDeg }: primero la clave exacta en la base de PixInsight, si no OpenNGC por posicion.
// -> { entry, how: "key" | "position", levels: [el nivel elegido (una lista de uno)], sep } o null.
function cshNebFindOutline(neb, prep) {
   if (!prep || prep.entries.length === 0) return null;
   var C = CSH_NEB_OUTLINE, i, lv = [], e = prep.by[C.PI_DB + "|" + cshNebKeyNorm("Sh2-" + neb.sh2)];
   if (e) {
      for (i = e.avail.length - 1; i >= 0; --i) if (e.avail[i] <= C.PI_LEVEL) lv.push(e.avail[i]);
      lv.length = Math.min(lv.length, 1);          // SOLO el nivel elegido: si ese no toca la foto, el disco (no se salta a otro nivel: seria otra definicion del contorno)
      if (lv.length > 0) return { entry: e, how: "key", levels: lv, sep: null };
   }
   var m = cshNebMatchOpenNgc(neb, prep);
   if (m !== null) {
      for (i = m.entry.avail.length - 1; i >= 0; --i) if (!(C.NGC_LEVEL > 0) || m.entry.avail[i] <= C.NGC_LEVEL) lv.push(m.entry.avail[i]);
      lv.length = Math.min(lv.length, 1);          // (igual: solo el elegido)
      if (lv.length > 0) return { entry: m.entry, how: "position", levels: lv, sep: m.sep };
   }
   return null;
}

// La mascara de la rejilla (`grid`, como en cpSfNebulaFootprint) dentro de unos anillos (regla par-impar, plano tangente de (ra0, dec0)): { mask: [0|1 ...], n }.
function cshNebMaskGrid(grid, rings, ra0, dec0, evenOdd) {
   var N = grid.nx * grid.ny, mask = new Array(N), n = 0, k, R = cshNebTanRings(rings, ra0, dec0);
   var gx0 = Infinity, gy0 = Infinity, gx1 = -Infinity, gy1 = -Infinity, i;
   for (i = 0; i < R.length; ++i) { gx0 = Math.min(gx0, R[i].x0); gy0 = Math.min(gy0, R[i].y0); gx1 = Math.max(gx1, R[i].x1); gy1 = Math.max(gy1, R[i].y1); }
   for (k = 0; k < N; ++k) {
      mask[k] = 0;
      if (R.length === 0) continue;
      var r = grid.ra[k], d = grid.dec[k];
      if (r === null || d === null || r === undefined || d === undefined || !isFinite(r) || !isFinite(d)) continue;
      var c = cshNebTan(ra0, dec0, r, d);
      if (c === null || c[0] < gx0 || c[0] > gx1 || c[1] < gy0 || c[1] > gy1) continue;
      if (cshNebInTanRings(R, c[0], c[1], evenOdd)) { mask[k] = 1; ++n; }
   }
   return { mask: mask, n: n };
}
// De una mascara de celdas a la huella, con la MISMA forma que `cpSfNebulaFootprint` ({ cells, frac, x0, y0, x1, y1, cx, cy }) o null si no cae ninguna celda.
function cshNebFootFromMask(mask, grid) {
   var cw = grid.width / grid.nx, ch = grid.height / grid.ny, n = 0, sx = 0, sy = 0, x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
   for (var j = 0; j < grid.ny; ++j)
      for (var i = 0; i < grid.nx; ++i) {
         if (!mask[j * grid.nx + i]) continue;
         var cx = (i + 0.5) * cw, cy = (j + 0.5) * ch;
         ++n; sx += cx; sy += cy;
         if (cx - cw / 2 < x0) x0 = cx - cw / 2;
         if (cy - ch / 2 < y0) y0 = cy - ch / 2;
         if (cx + cw / 2 > x1) x1 = cx + cw / 2;
         if (cy + ch / 2 > y1) y1 = cy + ch / 2;
      }
   if (n === 0) return null;
   return { cells: n, frac: n / (grid.nx * grid.ny), x0: Math.max(0, x0), y0: Math.max(0, y0), x1: Math.min(grid.width, x1), y1: Math.min(grid.height, y1), cx: sx / n, cy: sy / n };
}

// LA HUELLA DE UNA NEBULOSA DE SHARPLESS: la de su contorno si lo hay y toca la foto; si no, `cpSfNebulaFootprint` TAL CUAL (el mismo objeto de siempre: ningun campo nuevo).
//   neb = { sh2, ra, dec, radiusDeg } (una del catalogo, `cpSfNebulaCatalog`) · grid como en `cpSfNebulaFootprint` · prep = `cshNebPrepare(filas)` o null
//   o.project(ra, dec) -> { x, y } | null (el cielo de la foto a pixeles: `result._project`); sin ella no se calcula `rings` y el recorte se queda en la caja.
// La del contorno añade a { cells, frac, x0, y0, x1, y1, cx, cy }: source "outline", db, key, level, how ("key" | "position"), sep (grados; solo por posicion), discFrac (la fraccion
// que habria cubierto el disco), rings ([ [ [x, y] ... ] ... ] en pixeles de la foto, o null si algun vertice no se proyecta).
function cshNebFootprint(neb, grid, prep, o) {
   var disc = cpSfNebulaFootprint(neb.ra, neb.dec, neb.radiusDeg, grid);
   if (disc === null || CSH_NEB_OUTLINE.ON !== true || !prep) return disc;
   if (CSH_NEB_OUTLINE.GIANT_DIAM_ARCMIN > 0 && neb.diamArcmin >= CSH_NEB_OUTLINE.GIANT_DIAM_ARCMIN) return disc;      // (N1-B) las gigantes, con disco
   var f = null;
   try { f = cshNebFindOutline(neb, prep); } catch (eF) { f = null; }
   if (f === null) return disc;
   for (var li = 0; li < f.levels.length; ++li) {
      var L = f.entry.levels[f.levels[li]], M, foot;
      try { M = cshNebMaskGrid(grid, L.rings, f.entry.ra, f.entry.dec, true); foot = cshNebFootFromMask(M.mask, grid); } catch (eM) { foot = null; }
      if (foot === null) continue;
      foot.source = "outline"; foot.db = f.entry.db; foot.key = f.entry.key; foot.level = L.level; foot.how = f.how; foot.sep = f.sep; foot.discFrac = disc.frac;
      foot.rings = (o && typeof o.project === "function") ? cshNebRingsPx(L.rings, o.project) : null;
      return foot;
   }
   return disc;
}
// Los anillos en pixeles de la foto; null si algun vertice no se proyecta (la nebulosa grande con el cielo del lado opuesto) o hay menos de un anillo.
function cshNebRingsPx(rings, project) {
   var out = [], i, j;
   for (i = 0; i < rings.length; ++i) {
      var ring = [];
      for (j = 0; j < rings[i].length; ++j) {
         var p = null;
         try { p = project(rings[i][j][0], rings[i][j][1]); } catch (eP) { p = null; }
         if (!p || !isFinite(p.x) || !isFinite(p.y)) return null;
         ring.push([p.x, p.y]);
      }
      out.push(ring);
   }
   return out.length > 0 ? out : null;
}
// Los creditos de los contornos que se USAN en el campo (`result.nebulae.objects[i].foot.source === "outline"`), para la linea «Data:» del pie: las bases de PixInsight que
// de verdad han dado un contorno. [] si ninguno. (OpenNGC-Outlines: M. Verga, CC BY-SA 4.0; Nebula-Outlines: contornos sobre el mapa de H-alfa de Finkbeiner 2003 y los recuentos de Gaia DR3.)
function cshNebCredits(nebulae) {
   var used = {}, out = [], objs = (nebulae && nebulae.objects) ? nebulae.objects : [];
   for (var i = 0; i < objs.length; ++i) if (objs[i].foot && objs[i].foot.source === "outline") used[objs[i].foot.db] = true;
   if (used[CSH_NEB_OUTLINE.PI_DB]) out.push("Nebula-Outlines (PixInsight; Finkbeiner 2003, Gaia DR3)");
   if (used[CSH_NEB_OUTLINE.NGC_DB]) out.push("OpenNGC-Outlines (M. Verga, CC BY-SA 4.0)");
   return out;
}
// El texto corto de la fuente de una huella («Nebula-Outlines», «OpenNGC-Outlines (IC1805)»): sin contorno, "" (la ficha no dice nada).
function cshNebFootSource(foot) {
   if (!foot || foot.source !== "outline") return "";
   return String(foot.db) + (foot.how === "position" ? " (" + String(foot.key) + ")" : "");
}

// ---------------------------------------------------------------------------
// (15-nov-2026, N1-B) LAS NEBULOSAS QUE NO SON SHARPLESS. PURA (node la ejecuta).
// La lista de nebulosas del campo la decide el disco de Sharpless: la Cabeza de Bruja (IC 2118 = clave NGC1909 de OpenNGC-Outlines) no sale. Aqui se eligen, de OpenNGC-Outlines, las
// que SI se ven y ninguna Sharpless de la lista tiene ya por suya, para que entren en `result.nebulae.objects` DETRAS de las Sharpless (nunca cambian cual es la primera ni el orden de
// las Sharpless entre si) con su huella de contorno. La distancia sale del mismo camino que la de una Sharpless (SIMBAD por identificador, estrellas hijas, cumulo de dentro,
// distancia a mano); Foster-Brunt y WISE estan indexados por Sharpless y no aplican. Sin distancia: listada y no colocada, como una Sharpless sin distancia.
// REGLAS (cada una cuenta lo que deja fuera en `extra.left`, y `extra.rejected` lo lista con su motivo):
//   1. «key»      la clave de OpenNGC-Outlines no es NGC/IC/M/C (CSH_NEB_OUTLINE.EXTRA_KEY_RX): LBN y «regiones» de zona. Las LDN/Barnard y todo `Nebula-Outlines` sin Sharpless no se miran
//                 (`left.piOnly` cuenta los de Nebula-Outlines que tocan la foto y no son la clave de una Sharpless de la lista).
//   2. «matched»  una Sharpless de la lista ya la tiene por suya: el criterio de `cshNebMatchOpenNgc` (el centro de Sharpless dentro del contorno Y el centroide del contorno dentro del
//                 disco de Sharpless), mirado para TODAS las Sharpless del campo —tengan o no un contorno de Nebula-Outlines por clave— y para TODOS los contornos que lo cumplen, no solo el mas cercano.
//   3. «deepSky»  ya es un objeto de cielo profundo con recorte propio (`result.deepSky`: nebulosa o planetaria de SIMBAD con tamaño, que no sea luz de otra cosa —CSH_NEB_NOT_PHOTO_OTYPES—,
//                 en el encuadre y no «unseen») que es TAN GRANDE como la nebulosa (radio >= EXTRA_DS_RATIO por el radio equivalente del contorno) y coincide por POSICION: su posicion cae dentro
//                 del contorno del candidato, o el centroide del contorno cae dentro de su radio (tamaño / 2). Una galaxia, un cuasar o una fuente pequeña dentro del contorno no cuentan: no son esa nebulosa.
//   4. «small»    la huella (fraccion de la foto, rejilla gruesa) no llega a CSH_NEB_OUTLINE.EXTRA_MIN_FRAC.
//   5. «cap»      van las CSH_NEB_OUTLINE.EXTRA_MAX de mayor huella; el resto, fuera.
// El nivel es el de las Sharpless por posicion (NGC_LEVEL: el mas alto que haya); si ese no toca la foto, el candidato no toca la foto (no se salta a otro nivel: seria otra definicion).
// ---------------------------------------------------------------------------

// El identificador que SIMBAD entiende, de la clave de OpenNGC-Outlines: «NGC1909» -> «NGC 1909», «IC0434» -> «IC 434», «M45» -> «M 45», «IC359A» -> «IC 359A».
function cshNebExtraId(e) {
   var m = /^([A-Za-z]+)0*(\d+)([A-Za-z]?)$/.exec(String(e.key || ""));
   return m ? (m[1].toUpperCase() + " " + m[2] + m[3].toUpperCase()) : String(e.name || e.key || "");
}
// El nivel que se usa de un contorno: el mas alto de los que hay y no pasan de `maxLevel` (0 = sin tope). 0 si no hay ninguno.
function cshNebPickLevel(e, maxLevel) {
   for (var i = e.avail.length - 1; i >= 0; --i) if (!(maxLevel > 0) || e.avail[i] <= maxLevel) return e.avail[i];
   return 0;
}
// Area (grados cuadrados, regla PAR-IMPAR: un anillo dentro de otro resta), centroide, radio equivalente (el del circulo de esa area) y la mayor extension (lado mayor de la caja de los
// anillos, grados) de un contorno, sobre el plano tangente de (ra0, dec0). null si no se puede proyectar o el area es 0.
function cshNebRingStats(rings, ra0, dec0) {
   var R = cshNebTanRings(rings, ra0, dec0), A = 0, cx = 0, cy = 0, x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, i, j, k;
   for (i = 0; i < R.length; ++i) {
      var P = R[i].P, n = P.length, a = 0, sx = 0, sy = 0, depth = 0;
      for (j = 0; j < n; ++j) { var p = P[j], q = P[(j + 1) % n], cr = p[0] * q[1] - q[0] * p[1]; a += cr; sx += (p[0] + q[0]) * cr; sy += (p[1] + q[1]) * cr; }
      a /= 2;
      if (a === 0) continue;
      for (k = 0; k < R.length; ++k) if (k !== i && cshNebInTanRings([R[k]], P[0][0], P[0][1], true)) ++depth;
      var sg = (depth % 2 === 0) ? 1 : -1, aa = Math.abs(a);
      A += sg * aa; cx += sg * aa * (sx / (6 * a)); cy += sg * aa * (sy / (6 * a));
      x0 = Math.min(x0, R[i].x0); y0 = Math.min(y0, R[i].y0); x1 = Math.max(x1, R[i].x1); y1 = Math.max(y1, R[i].y1);
   }
   if (!(A > 0)) return null;
   var c = cshNebUntan(ra0, dec0, cx / A, cy / A);
   return { areaDeg2: A, ra: c.ra, dec: c.dec, eqRadiusDeg: Math.sqrt(A / Math.PI), majorDeg: Math.max(x1 - x0, y1 - y0) };
}
// Todos los contornos de OpenNGC que son la nebulosa de Sharpless `neb` por el criterio de `cshNebMatchOpenNgc` (la MISMA regla; aquella se queda con el de centroide mas cercano, esta los da todos,
// del mas cercano al mas lejano): [ { entry, centroid, sep } ]. csh_neb_outline_node.js H1 comprueba que el primero es el de `cshNebMatchOpenNgc`.
function cshNebMatchOpenNgcAll(neb, prep) {
   var out = [];
   if (!prep || !(neb.radiusDeg > 0)) return out;
   for (var i = 0; i < prep.entries.length; ++i) {
      var e = prep.entries[i];
      if (e.db !== CSH_NEB_OUTLINE.NGC_DB || e.avail.length === 0) continue;
      var L = e.levels[e.avail[0]];
      if (!cshNebPointInRings(L.rings, neb.ra, neb.dec, e.ra, e.dec)) continue;
      var c = cshNebCentroid(L.rings, e.ra, e.dec);
      if (c === null) continue;
      var s = cpSfSeparation(neb.ra, neb.dec, c.ra, c.dec);
      if (s > neb.radiusDeg) continue;
      out.push({ entry: e, centroid: c, sep: s });
   }
   out.sort(function(a, b) { return a.sep - b.sep; });
   return out;
}
// (N3b, 19-nov-2026) LAS DESIGNACIONES NGC / IC / Messier / Caldwell QUE SON ESTA SHARPLESS, de OpenNGC-Outlines y por posicion (el criterio de `cshNebMatchOpenNgcAll`, el mismo con que `cshNebExtraSelect` las
// declara «matched»: no entran como nebulosa aparte). Es la tabla de alias LOCAL (sin red) de FieldVoyager para rotular una Sharpless con su NGC / IC («Sh 2-131» = «IC 1396»). Solo claves que valen
// (CSH_NEB_OUTLINE.EXTRA_KEY_RX). -> [ { id: «IC 1396», key: «IC1396», sep (grados, centroide - centro de Sharpless) } ] del mas cercano al mas lejano; [] si ninguna o sin base.
function cshNebLocalAliases(neb, prep) {
   var all = cshNebMatchOpenNgcAll(neb, prep), out = [], i;
   for (i = 0; i < all.length; ++i) if (CSH_NEB_OUTLINE.EXTRA_KEY_RX.test(String(all[i].entry.key))) out.push({ id: cshNebExtraId(all[i].entry), key: String(all[i].entry.key), sep: all[i].sep });
   return out;
}
// Regla 3: ¿tiene este objeto de cielo profundo recorte propio en el 3D? (el criterio de `cpSvDistModel`: en el encuadre, con tamaño y no es luz de otra cosa)
function cshNebExtraOwnCutout(d) {
   if (!d || d.inFrame !== true || d.unseen === true || !(d.sizeArcmin > 0)) return false;
   if (d.cls !== "nebula" && d.cls !== "planetary-nebula") return false;
   return CSH_NEB_NOT_PHOTO_OTYPES[String(d.otype || "").replace(/\?$/, "")] !== 1;
}
// Regla 3: el objeto de cielo profundo con recorte propio que coincide con el contorno `rings` (ref. ra0, dec0; `cen` = { ra, dec, eqRadiusDeg } del contorno), o null. Coincide si es TAN GRANDE como la
// nebulosa (radio >= EXTRA_DS_RATIO por el radio equivalente: una fuente pequeña DENTRO no es esa nebulosa) Y por posicion: cae dentro del contorno, o el centroide cae dentro de su radio.
function cshNebExtraDeepSkyTwin(rings, ra0, dec0, cen, deepSky) {
   for (var i = 0; deepSky && i < deepSky.length; ++i) {
      var d = deepSky[i];
      if (!cshNebExtraOwnCutout(d) || !isFinite(d.ra) || !isFinite(d.dec)) continue;
      if (d.sizeArcmin / 120 < CSH_NEB_OUTLINE.EXTRA_DS_RATIO * cen.eqRadiusDeg) continue;
      if (cshNebPointInRings(rings, d.ra, d.dec, ra0, dec0) || cpSfSeparation(cen.ra, cen.dec, d.ra, d.dec) <= d.sizeArcmin / 120) return d;
   }
   return null;
}
// LA ELECCION. prep = `cshNebPrepare(filas)` · grid como en `cpSfNebulaFootprint` · near = las Sharpless del campo (`cpSfNebulaeNear`) · deepSky = `result.deepSky.objects` (o null) ·
// o.project(ra, dec) -> { x, y } | null (para los anillos en pixeles de la huella).
// -> { picks: [ { id, entry, level, foot, ra, dec, radiusDeg, sizeArcmin, areaDeg2 } ] (de mayor a menor huella), rejected: [ { key, id, frac, level, reason, by } ], touching (contornos de OpenNGC que tocan la foto),
//      left: { key, matched, deepSky, small, cap, piOnly } }. Con EXTRA apagado, sin base o sin rejilla: vacio.
function cshNebExtraSelect(prep, grid, near, deepSky, o) {
   var C = CSH_NEB_OUTLINE, out = { picks: [], rejected: [], touching: 0, left: { key: 0, matched: 0, deepSky: 0, small: 0, cap: 0, piOnly: 0 } }, i, j;
   if (C.EXTRA !== true || C.ON !== true || !prep || !grid) return out;
   var twins = {}, sharp = {}, list = [];
   for (i = 0; near && i < near.length; ++i) {
      sharp[cshNebKeyNorm("Sh2-" + near[i].sh2)] = true;
      var all = cshNebMatchOpenNgcAll(near[i], prep);
      for (j = 0; j < all.length; ++j) if (!twins[all[j].entry.norm]) twins[all[j].entry.norm] = near[i].id;
   }
   for (i = 0; i < prep.entries.length; ++i) {
      var e = prep.entries[i], lv, L, M, foot;
      if (e.avail.length === 0) continue;
      if (e.db === C.PI_DB) {                                   // regla 1, solo para contar: Nebula-Outlines que tocan la foto y no son una Sharpless de la lista
         if (sharp[e.norm]) continue;
         lv = cshNebPickLevel(e, C.PI_LEVEL);
         if (lv === 0) continue;
         M = cshNebMaskGrid(grid, e.levels[lv].rings, e.ra, e.dec, true);
         if (M.n > 0) ++out.left.piOnly;
         continue;
      }
      if (e.db !== C.NGC_DB) continue;
      lv = cshNebPickLevel(e, C.NGC_LEVEL);
      if (lv === 0) continue;
      L = e.levels[lv];
      M = cshNebMaskGrid(grid, L.rings, e.ra, e.dec, true);
      foot = cshNebFootFromMask(M.mask, grid);
      if (foot === null) continue;                              // no toca la foto
      ++out.touching;
      var id = cshNebExtraId(e), rj = { key: e.key, id: id, frac: foot.frac, level: lv, reason: "", by: "" };
      if (!C.EXTRA_KEY_RX.test(String(e.key))) { rj.reason = "key"; ++out.left.key; out.rejected.push(rj); continue; }
      if (twins[e.norm]) { rj.reason = "matched"; rj.by = twins[e.norm]; ++out.left.matched; out.rejected.push(rj); continue; }
      var st = cshNebRingStats(L.rings, e.ra, e.dec);
      if (st === null) { rj.reason = "geometry"; out.rejected.push(rj); continue; }
      var dup = cshNebExtraDeepSkyTwin(L.rings, e.ra, e.dec, st, deepSky);
      if (dup !== null) { rj.reason = "deepSky"; rj.by = String(dup.name || "") + " (" + Math.round(dup.sizeArcmin) + "′ frente a " + Math.round(st.eqRadiusDeg * 120) + "′ de la nebulosa)"; ++out.left.deepSky; out.rejected.push(rj); continue; }
      if (!(foot.frac >= C.EXTRA_MIN_FRAC)) { rj.reason = "small"; ++out.left.small; out.rejected.push(rj); continue; }
      foot.source = "outline"; foot.db = e.db; foot.key = e.key; foot.level = lv; foot.how = "catalog"; foot.sep = null; foot.discFrac = null;
      foot.rings = (o && typeof o.project === "function") ? cshNebRingsPx(L.rings, o.project) : null;
      list.push({ id: id, entry: e, level: lv, foot: foot, ra: st.ra, dec: st.dec, radiusDeg: st.eqRadiusDeg, sizeArcmin: st.majorDeg * 60, areaDeg2: st.areaDeg2, rj: rj });
   }
   list.sort(function(a, b) { return (b.foot.frac - a.foot.frac) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0); });
   var cap = Math.max(0, C.EXTRA_MAX | 0);
   for (i = 0; i < list.length; ++i) {
      if (i < cap) { var p = list[i]; delete p.rj; out.picks.push(p); }
      else { list[i].rj.reason = "cap"; ++out.left.cap; out.rejected.push(list[i].rj); }
   }
   return out;
}
// El objeto `nebula` de una elegida, con los MISMOS campos que el de una Sharpless (`sh2` nulo). `sm` = lo de SIMBAD de esa nebulosa (`cpSfNebulaSimbad`) o null, `kids` = sus estrellas
// hijas (`cpSfNebulaChildren`) o null, `manual` = { "<id>": { pc, err } }, `clusters` = `result.clusters`. La distancia por `cpSfNebulaPick` sin Foster-Brunt ni WISE (indexados por Sharpless).
function cshNebExtraObject(p, sm, kids, manual, clusters) {
   var nb = { id: p.id, sh2: null, ra: p.ra, dec: p.dec, radiusDeg: p.radiusDeg, diamArcmin: p.sizeArcmin, fb: null, wise: null };
   var pick = cpSfNebulaPick({ manual: cpSfNebulaManualDistance(manual ? manual[p.id] : null), simbad: sm ? sm.dist : null, fb: null, wise: null,
                               members: cpSfNebulaMembersParallax(kids || []), cluster: cpSfNebulaClusterInside(nb, clusters) });
   return { id: p.id, sh2: null, name: (sm && sm.name.length > 0) ? sm.name : p.id, simbadType: sm ? sm.otype : "", ra: p.ra, dec: p.dec, sizeArcmin: p.sizeArcmin, radiusDeg: p.radiusDeg,
            foot: p.foot, inFrame: true, dist: pick.dist, candidates: pick.list, members: (kids || []).length };
}
// El orden de `result.nebulae.objects`: las de Sharpless PRIMERO, como siempre (mayor huella, y a igual huella el numero de Sharpless); detras las otras (mayor huella, y a igual huella el identificador).
function cshNebOrder(a, b) {
   var sa = (a.sh2 > 0), sb = (b.sh2 > 0);
   if (sa !== sb) return sa ? -1 : 1;
   if (sa) return (b.foot.frac - a.foot.frac) || (a.sh2 - b.sh2);
   return (b.foot.frac - a.foot.frac) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
}

// LAS CONSULTAS A SIMBAD (por identificador; `ids` = [ "Sh 2-132", … ]). La primera: el objeto de SIMBAD de cada
// una, su tipo, su tamaño y sus distancias medidas. La segunda: las estrellas que cuelgan de ella (jerarquia) con
// su paralaje.
function cpSfNebulaInList(ids) {
   var q = [];
   for (var i = 0; i < ids.length; ++i) q.push("'" + String(ids[i]).replace(/'/g, "''") + "'");
   return q.join(",");
}
function cpSfNebulaAdql(ids) {
   return "SELECT i.id,b.oid,b.main_id,b.ra,b.dec,b.otype,t.path,b.galdim_majaxis,d.dist,d.unit,d.minus_err,d.plus_err,d.method,d.bibcode " +
          "FROM ident AS i JOIN basic AS b ON b.oid=i.oidref JOIN otypedef AS t ON t.otype=b.otype LEFT JOIN mesDistance AS d ON d.oidref=b.oid " +
          "WHERE i.id IN (" + cpSfNebulaInList(ids) + ")";
}
function cpSfNebulaChildrenAdql(ids) {
   return "SELECT i.id,c.main_id,c.otype,c.plx_value,c.plx_err,c.plx_bibcode " +
          "FROM ident AS i JOIN h_link AS h ON h.parent=i.oidref JOIN basic AS c ON c.oid=h.child " +
          "WHERE i.id IN (" + cpSfNebulaInList(ids) + ") AND c.plx_value IS NOT NULL";
}
// La respuesta de la primera -> { <numero de Sharpless>: { name, otype, cls, ra, dec, sizeArcmin, measures, dist } }.
// `dist`: la paralaje mas reciente si alguna medida lo es (N1), si no la mediana de las directas con su rango.
function cpSfNebulaSimbad(csvText, keyOf) {
   var t = cpSfParseTable(csvText, ","), out = {}, i, kf = (typeof keyOf === "function") ? keyOf : cpSfSharplessNumber;      // (N1-B) keyOf: otra clave que el numero de Sharpless (por defecto, ese)
   for (i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], n = kf(r.id);
      if (!n) continue;
      var o = out[n];
      if (!o) {
         var k = cpSfSimbadClass(r.otype, r.path);
         o = out[n] = { name: String(r.main_id || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""), otype: String(r.otype || ""), cls: k.cls,
                        ra: cpSfNum(r.ra), dec: cpSfNum(r.dec), sizeArcmin: cpSfNum(r.galdim_majaxis), measures: [], dist: null };
      }
      var m = cpSfSimbadMeasure(r);
      if (m && !m.modelled) o.measures.push(m);
   }
   for (var key in out) {
      if (!Object.prototype.hasOwnProperty.call(out, key)) continue;
      var ob = out[key], d = cpSfLatestParallax(ob.measures) || cpSfSummarise(ob.measures, "direct");
      if (d !== null) {
         d.simbadName = ob.name; d.simbadType = ob.otype; d.bibcodes = [];
         // (de donde sale la medida, para decirlo: la de Sh 2-132 en SIMBAD es la de Foster y Brunt, 2015AJ....150..147F)
         if (d.kind === "parallax") d.bibcodes.push(d.bibcode);
         else for (var mi = 0; mi < ob.measures.length; ++mi) if (ob.measures[mi].bibcode && d.bibcodes.indexOf(ob.measures[mi].bibcode) < 0) d.bibcodes.push(ob.measures[mi].bibcode);
      }
      ob.dist = d;
   }
   return out;
}
// La respuesta de la segunda -> { <numero>: [ { name, otype, plx, err, bibcode } ] }.
function cpSfNebulaChildren(csvText, keyOf) {
   var t = cpSfParseTable(csvText, ","), out = {}, kf = (typeof keyOf === "function") ? keyOf : cpSfSharplessNumber;
   for (var i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], n = kf(r.id), p = cpSfNum(r.plx_value), e = cpSfNum(r.plx_err);
      if (!n || p === null) continue;
      (out[n] = out[n] || []).push({ name: String(r.main_id || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""), otype: String(r.otype || ""), plx: p, err: e, bibcode: String(r.plx_bibcode || "") });
   }
   return out;
}

// LA DISTANCIA DE LAS ESTRELLAS DE LA NEBULOSA. De `list` (las de `cpSfNebulaChildren`) solo valen las paralajes de
// Gaia DR3 (el punto cero de Lindegren es el de DR3; DR2 tiene otro) con paralaje / error >= MIN_PLX_SNR. Se corrige el
// punto cero, se quitan las que se van mas de 3 sigmas de la mediana (una estrella de primer plano mal colgada; con 3
// o mas) y se da la MEDIANA con su error: el de la estrella si es una sola; si no, el error de una mediana
// (1,2533 · sigma robusta / raiz de n), nunca menos que el error tipico partido por raiz de n, y con el suelo
// sistematico de una paralaje media (PLX_MEAN_FLOOR) en cuadratura. null si no queda ninguna.
// `quality` "good" si el error no pasa de MAX_FRACTION; si no, "poor" (y no se usa: `cpSfNebulaPick`).
function cpSfNebulaMembersParallax(list) {
   var use = [], i;
   for (i = 0; list && i < list.length; ++i) {
      var s = list[i];
      if (cpSfParallaxCatalog(s.bibcode) !== "Gaia DR3" || !(s.err > 0) || !(s.plx / s.err >= CP_SF.MIN_PLX_SNR)) continue;
      use.push({ p: s.plx - CP_SF.PLX_ZERO_POINT, e: s.err, name: s.name });
   }
   if (use.length === 0) return null;
   var rejected = 0;
   for (var pass = 0; pass < 2 && use.length >= 3; ++pass) {
      var vals = [], keep = [];
      for (i = 0; i < use.length; ++i) vals.push(use[i].p);
      var med = cpSfMedian(vals), rs = cpSfRobustSigma(vals, med);
      for (i = 0; i < use.length; ++i) if (Math.abs(use[i].p - med) <= 3 * Math.sqrt(rs * rs + use[i].e * use[i].e)) keep.push(use[i]);
      rejected += use.length - keep.length;
      if (keep.length === use.length) break;
      use = keep;
   }
   var pv = [], ev = [];
   for (i = 0; i < use.length; ++i) { pv.push(use[i].p); ev.push(use[i].e); }
   var m = cpSfMedian(pv), n = use.length, err;
   if (n === 1) err = use[0].e;
   else err = Math.max(1.2533 * cpSfRobustSigma(pv, m) / Math.sqrt(n), cpSfMedian(ev) / Math.sqrt(n));
   err = Math.sqrt(err * err + CP_SF.PLX_MEAN_FLOOR * CP_SF.PLX_MEAN_FLOOR);
   if (!(m > 0)) return null;
   var frac = err / m;
   return { pc: 1000 / m, lo: 1000 / (m + err), hi: (m - err > 0) ? 1000 / (m - err) : Infinity, source: "members-parallax", kind: "parallax", catalog: "Gaia DR3",
            n: n, rejected: rejected, plx: m, plxErr: err, fraction: frac, quality: (frac <= CP_SF.MAX_FRACTION) ? "good" : "poor", interval: "1-sigma", zeroPoint: true,
            ref: "SIMBAD hierarchy: median Gaia DR3 parallax of the stars of the nebula" };
}

// EL CUMULO DE DENTRO: de los cumulos confirmados en la foto (`clusters`, los de `result.clusters`), el que tiene
// distancia y cuyo centro cae dentro del disco de la nebulosa, el mas cercano a su centro. null si ninguno.
// (29-oct-2026, barrido 3D de Cabra3D, S3) SI DENTRO HAY VARIOS CUMULOS QUE NO CASAN, LA ASOCIACION NO DICE NADA. Antes se tomaba
// el mas cercano al centro con SU error de catalogo, y una nebulosa enorme (Sh 2-109, 18°; Sh 2-276, el Lazo de Barnard) recibia
// la distancia de cualquier cumulo del encuadre con un error de un 1-3 %: la MISMA nebulosa salia a 2,70 kpc en el Tulipan
// (Dolidze 1) y a 3,22 kpc en LDu 2 (Berkeley 89); Sh 2-276 a 378 pc ±4,8 ly en Orion (NGC 1980) y a 155 pc ±1 ly en la
// Bruja (HSC 1667). Ahora, con CP_SF_NEB_CLUSTER_SPREAD, el intervalo es el RANGO de los cumulos de dentro (sus lo..hi): si no
// casan, la fraccion pasa del 20 % (CP_SF.MAX_FRACTION, la vara de siempre) y la candidata es «poor» (no se usa; se dice en la
// ficha). Con uno solo dentro, o varios que casan (un complejo: Orion), nada cambia. false = como antes.
var CP_SF_NEB_CLUSTER_SPREAD = true;
function cpSfNebulaClusterInside(neb, clusters) {
   var best = null, bd = Infinity, n = 0, lo = Infinity, hi = -Infinity;
   for (var i = 0; clusters && i < clusters.length; ++i) {
      var c = clusters[i];
      if (!c || !c.dist || !(c.dist.pc > 0)) continue;
      var d = cpSfSeparation(neb.ra, neb.dec, c.ra, c.dec);
      if (d > neb.radiusDeg) continue;
      ++n;
      var cl = (c.dist.lo > 0) ? c.dist.lo : c.dist.pc, ch = (c.dist.hi > 0 && isFinite(c.dist.hi)) ? c.dist.hi : c.dist.pc;
      if (cl < lo) lo = cl;
      if (ch > hi) hi = ch;
      if (d < bd) { bd = d; best = c; }
   }
   if (best === null) return null;
   var out = { pc: best.dist.pc, lo: best.dist.lo, hi: best.dist.hi, source: "cluster-inside", kind: "position", quality: "good", clusterName: String(best.name || best.id || ""),
               interval: best.dist.interval || "", fraction: (best.dist.hi - best.dist.lo) / (2 * best.dist.pc), ref: String(best.dist.ref || "") + " (association by position only)",
               clustersInside: n };
   if (CP_SF_NEB_CLUSTER_SPREAD === true && n > 1 && (lo < out.lo || hi > out.hi)) {
      out.lo = lo; out.hi = hi; out.fraction = (hi - lo) / (2 * out.pc); out.interval = "range of the " + n + " clusters inside";
      if (out.fraction > CP_SF.MAX_FRACTION) out.quality = "poor";
   }
   return out;
}

// LA DISTANCIA ESCRITA A MANO: lo que se guarda en la imagen es un JSON { "<id>": { pc, err } }. Ni negativa ni cero;
// un error que falta o no es un numero positivo, 0 («sin error»).
function cpSfNebulaManualParse(text) {
   var out = {}, o = null;
   try { o = JSON.parse(String(text || "")); } catch (e) { o = null; }
   if (!o || typeof o !== "object") return out;
   for (var k in o) {
      if (!Object.prototype.hasOwnProperty.call(o, k)) continue;
      var v = o[k], pc = (v && typeof v.pc === "number") ? v.pc : NaN, err = (v && typeof v.err === "number" && v.err > 0) ? v.err : 0;
      if (pc > 0 && isFinite(pc)) out[k] = { pc: pc, err: err };
   }
   return out;
}
function cpSfNebulaManualDistance(entry) {
   if (!entry || !(entry.pc > 0)) return null;
   var e = (entry.err > 0) ? entry.err : 0;
   return { pc: entry.pc, lo: Math.max(0, entry.pc - e), hi: entry.pc + e, source: "manual", kind: "manual", quality: "good", interval: (e > 0) ? "given by the user" : "no error given",
            fraction: e / entry.pc, ref: "entered by hand" };
}

// CUAL SE USA. `c` = { manual, simbad, fb, wise, members, cluster } (cada una null o una distancia). Devuelve
// { dist (la elegida o null), list: [ { source, dist, used, why } ] } con TODAS las que hay, en el orden de
// preferencia, para que la ficha las pueda enseñar. `why` de las que no se usan: "superseded" (habia otra antes) |
// "poor" (error de mas del 20 %).
function cpSfNebulaPick(c) {
   var order = [["manual", c.manual], ["simbad", c.simbad], ["foster-brunt", c.fb], ["wise", c.wise], ["members-parallax", c.members], ["cluster-inside", c.cluster]];
   var out = { dist: null, list: [] };
   for (var i = 0; i < order.length; ++i) {
      var d = order[i][1];
      if (!d || !(d.pc > 0) || !isFinite(d.pc)) continue;
      var why = "";
      if (d.quality === "poor") why = "poor";
      else if (out.dist !== null) why = "superseded";
      if (why === "") out.dist = d;
      out.list.push({ source: order[i][0], dist: d, used: (why === ""), why: why });
   }
   return out;
}
// LA MISMA ELECCION, OTRA VEZ, con otra distancia escrita a mano (o ninguna: null) y las candidatas que ya se tenian
// (`list` de `cpSfNebulaPick`): cambiar lo escrito a mano no vuelve a preguntar a la red.
function cpSfNebulaRepick(list, manual) {
   var c = { manual: manual, simbad: null, fb: null, wise: null, members: null, cluster: null }, key = { "simbad": "simbad", "foster-brunt": "fb", "wise": "wise", "members-parallax": "members", "cluster-inside": "cluster" };
   for (var i = 0; list && i < list.length; ++i) { var k = key[list[i].source]; if (k) c[k] = list[i].dist; }
   return cpSfNebulaPick(c);
}

// ---- (de CabraStars: los puntos del HR; Cabra3D no los pinta, pero el motor comun los da) ----
// ---- desde engine/starfield.js:1440 ----
// ---------------------------------------------------------------------------
// LOS PUNTOS DEL DIAGRAMA HR
// ----------------------------------------------------------------------------
// Uno por estrella con distancia. `source`:
//   "image"  el color y la magnitud MEDIDOS EN LA FOTO (`star.phot`), y nada mas;
//   "gaia"   los del catalogo;
//   "mixed"  los de la foto donde se han podido medir y los de Gaia en las demas
//            (las saturadas y las que tienen una vecina encima): cada punto dice
//            de donde sale (`from`).
// La extincion NO se corrige (fase 1): cada punto esta desplazado hacia abajo y a
// la derecha lo que le toque, y el resultado lo lleva escrito
// (`extinctionCorrected: false`).
// Las medidas de la foto que NO SE USAN (`phot.use` false: debiles, fuera del
// tramo de color en que la calibracion vale -las enanas M, casi siempre-, o con
// una magnitud que no casa con la de Gaia) no se pintan con el color de la foto:
// en "mixed" van con el de Gaia y en "image" se quedan fuera (`skipped.flagged`).
// `flagged` las cuenta, por motivo, en los dos casos.
// Devuelve { source, colorIndex, magnitude, extinctionCorrected, points: [
//   { star, color, absMag, cluster, quality, from, colorSuspect } ],
//   fromImage, fromGaia, colorSuspect, flagged: { faint, outOfRange, magMismatch, colourMismatch },
//   skipped: { noDistance, noColour, flagged } }
// `colorSuspect` (solo con color de Gaia): la bandera de exceso BP/RP, color
// contaminado por una vecina. En el nucleo de M 13 son el 15 % de las estrellas y
// salen desperdigadas por el diagrama: quien pinta decide si las enseña.
// ---------------------------------------------------------------------------
function cpSfHrPoints(stars, source) {
   var img = (source === "image" || source === "mixed"), mixed = (source === "mixed");
   var out = { source: mixed ? "mixed" : img ? "image" : "gaia",
               colorIndex: img ? "BP-RP (measured in the image, calibrated on Gaia)" : "BP-RP (Gaia DR3)",
               magnitude: img ? "M_G (measured in the image, calibrated on Gaia)" : "M_G (Gaia DR3)", extinctionCorrected: false,
               points: [], fromImage: 0, fromGaia: 0, colorSuspect: 0, flagged: { faint: 0, outOfRange: 0, magMismatch: 0, colourMismatch: 0 },
               skipped: { noDistance: 0, noColour: 0, flagged: 0 } };
   for (var i = 0; i < stars.length; ++i) {
      var s = stars[i];
      if (!s.dist || !(s.dist.pc > 0)) { ++out.skipped.noDistance; continue; }
      var color = null, mag = null, from = "";
      var measured = (img && s.phot && s.phot.ok && isFinite(s.phot.color) && isFinite(s.phot.mag));
      var why = (measured && s.phot.use === false) ? String(s.phot.why) : "";        // medida, pero la medida no se usa
      if (why === "faint") ++out.flagged.faint;
      else if (why === "mag-mismatch") ++out.flagged.magMismatch;
      else if (why === "colour-mismatch") ++out.flagged.colourMismatch;
      else if (why !== "") ++out.flagged.outOfRange;
      if (measured && why === "") { color = s.phot.color; mag = s.phot.mag; from = "image"; }
      else if ((!img || mixed) && s.bpRp !== null && s.g !== null) { color = s.bpRp; mag = s.g; from = "gaia"; }
      if (from === "" || !isFinite(color) || !isFinite(mag)) {
         if (why !== "") ++out.skipped.flagged; else ++out.skipped.noColour;
         continue;
      }
      var suspect = (from === "gaia" && s.colorSuspect === true);
      if (from === "image") ++out.fromImage; else ++out.fromGaia;
      if (suspect) ++out.colorSuspect;
      out.points.push({ star: i, color: color, absMag: cpSfAbsMag(mag, s.dist.pc), cluster: s.cluster, quality: s.dist.quality, from: from, colorSuspect: suspect });
   }
   return out;
}
