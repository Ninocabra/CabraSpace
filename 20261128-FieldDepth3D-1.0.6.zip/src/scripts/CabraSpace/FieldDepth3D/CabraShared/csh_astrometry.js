// ============================================================================
// CabraShared/csh_astrometry.js — LA IMAGEN Y SU SOLUCION: ¿tiene WCS?, leerla, y resolverla SOLO si hace falta
// ----------------------------------------------------------------------------
// Peticion de Nino (14-oct): «si la imagen se puede resolver (WCS ya presente) NO se llama a ImageSolver; si no, se
// resuelve». Habia tres versiones (CabraStars `csSolveIfNeeded`, Cabra3D `c3EnsureSolved`, CabraComposition
// `ccSolveView`) con la misma receta de CabraPilot (engine/astrometry.js `cpSolveAstrometry`). Esta es la UNION de lo
// mejor de cada una:
//   · de Cabra3D: dar J2000 si no hay fecha (sin ella la base Gaia local no carga: «Missing observation time metadata»,
//     c3_probe_solve.log), RBF de placa delgada, costura de pruebas y contador de llamadas («una imagen resuelta NO llama
//     a ImageSolver»);
// (6-nov-2026, revision PTeam CPD) Las propiedades de la solucion astrometrica (PCL:AstrometricSolution:*) son SOLO de
// ImageSolver: aqui no se borra ni se escribe ninguna antes ni despues de resolver (antes se borraban dos de una solucion vieja).
// Y de las ventanas de diagnostico de ImageSolver solo se cierran las que el propio ImageSolver abrio en esa llamada
// (foto de las ventanas abiertas antes de cada solveImage: cshSolverWindowSnapshot / cshKillSolverDiagnostics).
//   · de CabraStars: la semilla explicita (pruebas) y el aviso de progreso;
//   · de las tres: si el intento automatico falla y hay PANTALLA, el dialogo de ImageSolver (centro y escala a mano).
// `cshEnsureSolved( view, o )` -> { ok, state ("already" | "solved" | "failed" | "cancelled" | "disabled"), why, ms, blind (lo identifico el solver ciego de 1.9.6), noIndex }
//   o = { onProgress(text), hint: { ra, dec, resolution }, dialog (bool; por defecto: solo con pantalla), allow (bool) }
// COSTURA DE PRUEBAS: CSH_SOLVE_HOOK( window ) -> { ok, why } EN VEZ de ImageSolver; CSH_SOLVE_CALLS cuenta las llamadas.
// La libreria ImageSolver la incluye el script principal (modo libreria). ES5.
// ============================================================================

var CP_ANNOT_DEFAULT_EPOCH = 2451545.0;        // J2000: lo que se pone cuando la imagen no dice cuando se tomo
var CSH_SOLVE_HOOK = null;
var CSH_SOLVE_CALLS = 0;

// (17-nov-2026) optSafeView, la regla de «¿lineal?» y del estirado automático (cpViewIsLinear, cshViewStf, cshPhotoStretchMode, cshAutoStfRows, cshMtf…)
// y cshColorStatus viven ahora en csh_stf.js (el estirado regulable y común a la familia): mismos nombres, mismo código; se incluyen aquí para que
// los scripts que ya incluían csh_astrometry.js no cambien.
#include "csh_stf.js"

// ¿Tiene la vista una solucion astrometrica? El indicador del nucleo, la propiedad de la proyeccion, o claves WCS.
function cpHasAstrometricSolution(view) {
   if (!optSafeView(view)) return false;
   try { if (view.window && view.window.hasAstrometricSolution) return true; } catch (eAuth) {}
   try { var projection = view.propertyValue("PCL:AstrometricSolution:ProjectionSystem"); if (projection !== null && projection !== undefined && String(projection).length > 0) return true; } catch (e0) {}
   try {
      var kw = view.window.keywords;
      for (var i = 0; i < kw.length; ++i) { var name = (kw[i].name || "").toUpperCase(); if (name === "CTYPE1" || name === "CRVAL1" || name === "CD1_1" || name === "PC1_1") return true; }
   } catch (e1) {}
   return false;
}
function cshHasSolution(view) { return cpHasAstrometricSolution(view); }

// (30-oct-2026) LA SOLUCION SE LEE UNA VEZ. Medido en Pleyades con CJ_PROFILE: ExtractMetadata tarda 4 s (el modelo de splines) y se llamaba al previsualizar y otra vez al analizar: dos huecos de 4 s
// con la ventana parada antes de que hubiera nada que tocar. Se recuerda la ultima, por una huella de la solucion: si se vuelve a resolver la imagen en la misma ventana, cambia (csh_mdmemo_pi.js C3).
// Sin propiedades de la solucion (solo cabecera FITS), sin huella: se lee cada vez, como antes. Nadie escribe en el objeto salvo observationTime, con el mismo J2000 en los dos sitios. Rojo: CSH_NET_BREAK=nomdmemo.
var CSH_MD_MEMO = null;
function cshSolutionStamp(view) {
   try {
      var P = ["ReferenceCelestialCoordinates", "ReferenceImageCoordinates", "LinearTransformationMatrix", "ProjectionSystem", "CreationTime"], s = [view.fullId, view.image.width, view.image.height], got = false;
      for (var i = 0; i < P.length; ++i) {
         var v = view.propertyValue("AstrometricSolution:" + P[i]);                  // (ImageSolver 6.5; hasta 6.3, con PCL: delante. Medido: Pleyades y Abell 39, csh_mdmemo_sonda.js)
         if (v === null || v === undefined) v = view.propertyValue("PCL:AstrometricSolution:" + P[i]);
         var t = (v === null || v === undefined) ? "" : ((typeof v.toArray === "function") ? v.toArray().join(",") : String(v));
         if (i === 0 && t !== "") got = true;
         s.push(t);
      }
      return got ? s.join("|") : "";
   } catch (e) { return ""; }
}
function cshMetadataRead(view) {
   var stamp = (typeof cshNetBrk === "function" && cshNetBrk("nomdmemo")) ? "" : cshSolutionStamp(view);
   if (stamp !== "" && CSH_MD_MEMO && CSH_MD_MEMO.stamp === stamp) return CSH_MD_MEMO.md;
   var md = new AstrometricMetadata;
   md.ExtractMetadata(view.window);
   if (stamp !== "" && md && md.projection) CSH_MD_MEMO = { stamp: stamp, md: md };
   return md;
}
// La solucion leida con la libreria de ImageSolver (`AstrometricMetadata`). null si no hay.
function cpAnnotMetadata(view) {
   if (!optSafeView(view) || !cpHasAstrometricSolution(view) || typeof AstrometricMetadata !== "function") return null;
   var md = null;
   try { md = cshMetadataRead(view); }
   catch (e) { try { console.warningln(cshT("could not read the astrometric solution: ") + (e.message || e)); } catch (eW) {} return null; }
   if (!md || !md.projection) return null;
   if (!md.observationTime) md.observationTime = CP_ANNOT_DEFAULT_EPOCH;   // (sin esto, Load LANZA con una imagen sin DATE-OBS)
   return md;
}

// (la regla de «¿lineal?», el STF de la vista y el estirado automático: csh_stf.js)

// (F2, 22-oct-2026) Los espejos de VizieR para ImageSolver, en orden: CfA y NAO, los de la lista de PixInsight
// (pjsr/astrometry/AstronomicalCatalogs.js, «VizieR mirrors») PERO SIN su «/vizier/» final: ImageSolver pide
// <servidor> + "viz-bin/asu-tsv?…" y, MEDIDO el 22-oct, https://vizier.cfa.harvard.edu/vizier/viz-bin/asu-tsv y
// el de NAO (vizier.nao.ac.jp/vizier/viz-bin/asu-tsv, solo http) dan HTTP 404; en la raiz (…/viz-bin/asu-tsv) contestan 200 con la tabla.
// (La primera version con la lista tal cual fallo asi: cs_test_f2_pi.js P4, «Catalog error: GaiaDR2» en los dos espejos.)
// NAO por http (por https no contesto: 21 s y nada). COSTURA: CSH_SOLVE_CFG_HOOK(solver, servidor) tras montar cada solver
// (las pruebas fuerzan el catalogo en linea y un servidor que no contesta).
// (31-oct-2026) PixInsight 1.9.6 solo admite los espejos HTTPS de su lista (CDS, CfA, IUCAA, INASAN, IDIA) y convierte el resto a CDS: pedir NAO acababa en CDS, ya caido (MEDIDO: cs_test_f2_pi P4b, «Failed to connect to
// vizier.cds.unistra.fr» con el servidor NAO). Alli se salta NAO y queda IDIA, el de la lista que contesto el dia que los demas callaban (csh_net.js).
// (3-nov-2026, CPD C1) Sin NAO: solo por http (reglas CPD 6.3: todo por https). Quedan CfA e IDIA, los dos por https.
var CSH_SOLVE_MIRRORS = [["https://vizier.cfa.harvard.edu/", "VizieR CfA (Harvard)"], ["https://vizier.idia.ac.za/", "VizieR IDIA (Cape Town)"]];
var CSH_SOLVE_CFG_HOOK = null;
// ¿Fallo ImageSolver por la DESCARGA del catalogo de VizieR? El motor lanza «Catalog error: <catalogo>» cuando el catalogo
// queda sin objetos (la descarga no llego o no se pudo leer); solo cuenta si el catalogo es de VizieR (los de VizieR
// construyen una URL: UrlBuilder; el Gaia local XPSD no).
function cshSolverVizierFailed(solver, why) {
   if (!/Catalog error/i.test(String(why || ""))) return false;
   try { var c = solver ? solver.catalog : null; return !!(c && typeof c.UrlBuilder === "function"); } catch (e) { return false; }
}

// ¿Hay pantalla? Ningun dialogo modal cuando CUALQUIERA de estas tres cosas dice que no (M8, 31-oct-2026, PixInsight 1.9.6):
//   · el parametro non_interactive de los scripts (lo ponen las pruebas y el Event Script de WBPP);
//   · CoreApplication.automationMode: PixInsight arrancado con --automation-mode (no abre cuadros modales; un dialogo nuestro cuelga);
//   · CoreApplication.nonInteractive: hay abierta una seccion no interactiva (beginNonInteractive sin su endNonInteractive).
// Cada una solo cuenta si existe y vale true (en 1.9.5 o sin ella: lo de siempre). En un PixInsight normal las tres son false.
function cshAutomationReason() {
   try { if (Parameters.getBoolean("non_interactive")) return "non_interactive"; } catch (e0) {}
   try { if (typeof CoreApplication !== "undefined" && CoreApplication.automationMode === true) return "automationMode"; } catch (e1) {}
   try { if (typeof CoreApplication !== "undefined" && CoreApplication.nonInteractive === true) return "nonInteractive"; } catch (e2) {}
   return "";
}
function cshInteractive() { return cshAutomationReason() === ""; }
function cshImageSolverAvailable() { try { return (typeof ImageSolver === "function"); } catch (e) { return false; } }
// VENTANAS DE DIAGNOSTICO DE ImageSolver (6-nov-2026, revision PTeam CPD): antes se cerraba a la fuerza CUALQUIER ventana
// llamada "stars", "matches" o "distortion", aunque fuera del usuario. Ahora: foto de las ventanas abiertas justo antes de
// cada solveImage (cshSolverWindowSnapshot) y, despues, se cierran solo las NUEVAS cuyo id es de diagnostico. Nombres:
//   · los historicos "stars" / "matches" / "distortion" (con el sufijo numerico que PixInsight pone si el id ya existe: "stars1");
//   · los de ImageSolver 6.6 (ImageSolverEngine.js, generateStarMap / generateErrorMap / generateDistortionMap /
//     #drawSimplifiedSurfaceMap): <id de la imagen> + "_stars" | "_errors" | "_distortions" | "_matched" | "_simplified" | "_is_working".
// Una ventana que ya estaba abierta antes de la llamada NUNCA se cierra, se llame como se llame. Sin foto, no se cierra nada.
var CSH_SOLVER_DIAG_RE = /^(stars|matches|distortion)\d*$/;
var CSH_SOLVER_DIAG_SUFFIX_RE = /_(stars|errors|distortions|matched|simplified|is_working)\d*$/;
function cshSolverWindowSnapshot() {
   var ids = {};
   try {
      var ws = ImageWindow.windows;
      for (var i = 0; i < ws.length; ++i) { try { ids["#" + ws[i].mainView.id] = true; } catch (e0) {} }
   } catch (e) {}
   return ids;
}
function cshIsSolverDiagnosticId(id, targetId) {
   id = String(id || "");
   if (CSH_SOLVER_DIAG_RE.test(id)) return true;
   targetId = String(targetId || "");
   return targetId.length > 0 && id.indexOf(targetId + "_") === 0 && CSH_SOLVER_DIAG_SUFFIX_RE.test(id.substring(targetId.length));
}
// before = cshSolverWindowSnapshot() tomada justo antes de solveImage; targetId = id de la imagen resuelta. -> ventanas cerradas
function cshKillSolverDiagnostics(before, targetId) {
   if (!before || typeof before !== "object") return 0;
   var n = 0, ws = [];
   try { ws = ImageWindow.windows; } catch (e0) { return 0; }
   for (var i = 0; i < ws.length; ++i) {
      try {
         var w = ws[i], id = w.mainView.id;
         if (before["#" + id] === true) continue;              // ya estaba antes: no es de ImageSolver (puede ser del usuario)
         if (!cshIsSolverDiagnosticId(id, targetId)) continue;
         w.forceClose(); ++n;
      } catch (e) {}
   }
   return n;
}
// solveImage con limpieza: foto, resolver, cerrar solo lo nuevo de diagnostico (tambien si solveImage lanza)
function cshSolveImageClean(solver, win) {
   var before = cshSolverWindowSnapshot(), tid = "";
   try { tid = win.mainView.id; } catch (e0) {}
   try { solver.solveImage(win); }
   finally { cshKillSolverDiagnostics(before, tid); }
}

function cshEnsureSolved(view, o) {
   o = o || {};
   var t0 = Date.now(), out = { ok: false, state: "failed", why: "", ms: 0 };
   if (!optSafeView(view)) { out.why = cshT("no image is selected."); return out; }
   if (cpHasAstrometricSolution(view)) { out.ok = true; out.state = "already"; out.ms = Date.now() - t0; return out; }
   if (o.allow === false) { out.state = "disabled"; out.why = "solving disabled"; return out; }
   ++CSH_SOLVE_CALLS;
   var win = view.window;
   if (typeof CSH_SOLVE_HOOK === "function") {
      var h = CSH_SOLVE_HOOK(win) || {};
      out.ok = (h.ok === true) && cpHasAstrometricSolution(view); out.state = out.ok ? "solved" : "failed"; out.why = String(h.why || "");
      out.ms = Date.now() - t0;
      return out;
   }
   if (!cshImageSolverAvailable()) { out.why = cshT("The ImageSolver library is not loaded: run Script > Astrometry > ImageSolver on the image and try again."); return out; }
   if (typeof o.onProgress === "function") { try { o.onProgress(cshT("Solving the image with ImageSolver…")); } catch (eP0) {} }
   try { win.show(); win.bringToFront(); win.currentView = win.mainView; } catch (eP) {}
   var solver = null, first = "";
   // (F2) el solver, montado igual cada vez (la segunda, para un espejo de VizieR: `server`)
   function makeSolver(server) {
      var sv = new ImageSolver();
      sv.initialize(win, false);
      try { if (!sv.metadata.observationTime) sv.metadata.observationTime = CP_ANNOT_DEFAULT_EPOCH; } catch (eT) {}
      try { sv.solverCfg.distortionCorrection = true; } catch (e0) {}
      try { sv.solverCfg.rbfType = RBFType_DDMThinPlateSpline; } catch (e1) {}
      if (o.hint) {
         try { if (isFinite(o.hint.ra)) sv.metadata.ra = o.hint.ra; if (isFinite(o.hint.dec)) sv.metadata.dec = o.hint.dec; if (o.hint.resolution > 0) sv.metadata.resolution = o.hint.resolution; } catch (eH) {}
         try { sv.userSeed = { coordinates: isFinite(o.hint.ra) && isFinite(o.hint.dec), scale: o.hint.resolution > 0 }; } catch (eU) {}   // (1.9.6) sin esto, ImageSolver no se fia de la semilla y va directo al ciego
      }
      // (31-oct-2026) SOLVER CIEGO DE PIXINSIGHT 1.9.6: ImageSolver 6.6 identifica el campo sin coordenadas, o si las de la cabecera son malas, y sigue con su proceso completo (Gaia y distorsion).
      // Automatic es su valor de fabrica; se fija porque el modo guardado en el dialogo podria ser Disabled. Sin indice astrometrico, o en 1.9.5 (sin BlindSolverMode), la ruta de siempre.
      try { if (typeof BlindSolverMode !== "undefined") sv.solverCfg.blindSolver = BlindSolverMode.Automatic; } catch (eB) {}
      if (typeof CSH_SOLVE_CFG_HOOK === "function") { try { CSH_SOLVE_CFG_HOOK(sv, server || ""); } catch (eK) {} }
      if (server) { try { sv.solverCfg.vizierServer = server; } catch (eS) {} }
      return sv;
   }
   try { solver = makeSolver(""); } catch (eInit) { out.why = cshT("ImageSolver could not start: ") + (eInit.message || eInit); out.ms = Date.now() - t0; return out; }
   try { cshSolveImageClean(solver, win); } catch (eAuto) { first = String(eAuto.message || eAuto); try { console.warningln("CabraShared: automatic ImageSolver attempt failed: " + first); } catch (eW) {} }
   if (cpHasAstrometricSolution(view)) { out.ok = true; out.state = "solved"; try { out.blind = !!solver.blindSolution; } catch (eBS) {} out.ms = Date.now() - t0; return out; }
   // (F2, 22-oct-2026) SI FALLO POR VizieR (la descarga del catalogo: «Catalog error» con un catalogo de VizieR, no el Gaia
   // local), otra vez con los ESPEJOS de VizieR de la lista de PixInsight (pjsr/astrometry/AstronomicalCatalogs.js): CfA y
   // luego NAO. Solo en ese caso: un fallo por pocas estrellas o por la semilla no se repite (no lo arreglaria un espejo).
   out.mirrors = [];
   var why0 = first;
   for (var mi = 0; mi < CSH_SOLVE_MIRRORS.length && cshSolverVizierFailed(solver, why0); ++mi) {
      var mr = CSH_SOLVE_MIRRORS[mi], cur = "";
      try { cur = String(solver.solverCfg.vizierServer || ""); } catch (eC) {}
      if (cur === mr[0]) continue;
      if (!/^https:/.test(mr[0])) continue;      // (3-nov-2026, CPD C1) nunca un servidor que no sea https, aunque alguien lo meta en la lista
      try { console.warningln("CabraShared: VizieR failed for ImageSolver (" + why0 + "): trying the mirror " + mr[1] + " <raw>" + mr[0] + "</raw>"); } catch (eW3) {}
      if (typeof o.onProgress === "function") { try { o.onProgress(cshT("Solving the image with ImageSolver…") + " (" + mr[1] + ")"); } catch (eP2) {} }
      why0 = "";
      try { solver = makeSolver(mr[0]); cshSolveImageClean(solver, win); } catch (eM) { why0 = String(eM.message || eM); }
      out.mirrors.push({ server: mr[0], name: mr[1], why: why0 });
      if (cpHasAstrometricSolution(view)) { out.ok = true; out.state = "solved"; out.mirror = mr[1]; try { out.blind = !!solver.blindSolution; } catch (eBS3) {} out.ms = Date.now() - t0; return out; }
   }
   // segunda pasada: el dialogo de ImageSolver (centro y escala a mano). Solo con pantalla.
   var dialog = ((o.dialog === undefined) ? true : (o.dialog === true)) && cshInteractive();      // (M8) pedirlo no basta: en automatizacion nunca
   if (dialog && typeof ImageSolverDialog === "function") {
      try {
         var metadata = null;
         try { metadata = solver.metadata; } catch (eM) {}
         if (metadata != null) {
            var dlg = new ImageSolverDialog(solver.solverCfg, metadata, true);
            if (!dlg.execute()) { out.state = "cancelled"; out.why = cshT("ImageSolver cancelled by the user"); out.ms = Date.now() - t0; return out; }
            try { solver.solverCfg = dlg.solverCfg; solver.metadata = dlg.metadata; solver.userSeed = { coordinates: true, scale: true }; } catch (eCfg) {}
            if (typeof o.onProgress === "function") { try { o.onProgress(cshT("Solving the image with ImageSolver…")); } catch (eP1) {} }
            cshSolveImageClean(solver, win);      // (la foto se toma DESPUES del dialogo: lo que el usuario abra mientras tanto es suyo)
         }
      } catch (eSolve) { first = String(eSolve.message || eSolve); try { console.warningln("CabraShared: ImageSolver failed: " + first); } catch (eW2) {} }
   }
   out.ok = cpHasAstrometricSolution(view);
   out.state = out.ok ? "solved" : "failed";
   if (!out.ok) {
      out.why = cshT("ImageSolver did not get a valid solution (give it the centre and the pixel scale in its dialog)."); out.first = first;
      try { if (typeof BlindSolverMode !== "undefined" && solver.astrometricIndexFilePath().length === 0) { out.noIndex = true; out.why += " " + cshT("To solve without coordinates, choose an astrometric index file in the preferences of the Gaia process."); } } catch (eNI) {}
   }
   try { if (out.ok) out.blind = !!solver.blindSolution; } catch (eBS2) {}
   out.ms = Date.now() - t0;
   return out;
}

// (cshColorStatus: csh_stf.js)
