#ifndef __CSH_STF_PANEL
#define __CSH_STF_PANEL
// ============================================================================
// CabraShared/csh_stf_panel.js — EL BOTÓN STF Y SU PANEL, COMUNES A LA FAMILIA (17-nov-2026)
// ----------------------------------------------------------------------------
// Petición de Nino (17-nov): «Cuando cojo una imagen no lineal, aplica un stretch y queda rara. Haz una opción para poner y quitar stretch tipo STF y regularlo.
// Detecta si una imagen es lineal o no y aplícalo de forma automática, siempre dejando la opción de cambiarlo en manual… debería ser una opción existente en todos
// y común a todos.» El cálculo y lo recordado están en csh_stf.js (CshStf); aquí solo la interfaz, derivada de FVStfPanel (FieldVoyager/src/ui/fv_stf_panel.js).
//   · UN BOTÓN pintado (icono de histograma con su curva de medios tonos, en oro): la mitad izquierda pone / quita el estirado; la derecha (la flecha) abre el panel.
//     Encendido = oro (como los conmutadores de la familia). Su tooltip dice POR QUÉ está como está («Linear image: auto stretch applied» · «Non-linear image: shown
//     as is» · «Using the window's STF» · «Set by you for this image»).
//   · UN PANEL pequeño, plegado de fábrica: deslizador de INTENSIDAD (fondo objetivo del cielo, 0,05-0,50), de SOMBRAS (recorte en σ de MAD, −5…−1), «Linked»
//     (canales enlazados o cada uno el suyo; gris en una imagen monocroma) y «Auto» (vuelve a lo automático y olvida lo recordado). Mover un deslizador repinta
//     EN VIVO (cada CSH_STFUI.LIVE s) y, al soltar, lo deja fijo y lo recuerda.
// Quien lo usa pone el CONTROLADOR: `new CshStfControl({ parent, panelParent, h, r, place(panel, button), onApply(model, state, phase), onOpen() })` y le da su modelo
// con `ctl.setModel(new CshStf(view))`; añade `ctl.button` donde quiera y `ctl.panel` queda como hijo de `panelParent` (flota sobre él). onApply recibe el modelo
// (`model.render()` da el Bitmap; la imagen del usuario no se toca) y la fase: «live» (arrastrando: hacer solo lo barato), «commit» (soltado el deslizador, o un clic de
// ratón en el botón / en Auto: todo, pero pudiendo hacerlo en trozos) o «click» (por programa: `button.onClick()`, `setOn(b)`, `auto()`: todo, ahora, antes de volver).
// Depende de csh_atlas.js, csh_i18n.js (los trae el script que lo incluye) y csh_stf.js. ES5 salvo las dos clases de widget. Textos EN / ES en CSH_ES.
// Rojos de pruebas: CSH_STFUI.BREAK = "nolive" (mover el deslizador no repinta) · "noauto" (Auto no vuelve a la regla).
// ============================================================================
#include "csh_stf.js"

var CSH_STFUI = { W: 268, H: 176, ICON_W: 34, CHEV_W: 20, LIVE: 0.06, SETTLE: 0.4, BREAK: "" };
(function () {
   if (typeof CSH_ES === "undefined") return;
   var T = {
      "STF": "STF",
      "Intensity": "Intensidad", "Shadows": "Sombras", "Linked": "Enlazado", "Auto": "Auto",
      "Linear image: auto stretch applied": "Imagen lineal: estirado automático aplicado",
      "Non-linear image: shown as is": "Imagen no lineal: se muestra tal cual",
      "Using the window's STF": "Usando el STF de la ventana",
      "Set by you for this image": "Fijado por ti para esta imagen",
      "Stretch off, as you set it for this image": "Estirado quitado, como lo fijaste para esta imagen",
      "Click to turn the stretch on or off. The arrow opens the controls. Your image is never modified.":
         "Pulsa para poner o quitar el estirado. La flecha abre los mandos. Tu imagen no se modifica nunca.",
      "Open the stretch controls": "Abrir los mandos del estirado",
      "Close": "Cerrar",
      "How strong the stretch is: the brightness the sky background gets on screen (0.05 dark … 0.50 bright). The family default is 0.12.":
         "Cuánto estira: el brillo que toma el fondo del cielo en pantalla (0,05 oscuro … 0,50 claro). El de la familia es 0,12.",
      "Where the darkest tones are cut, in noise units (σ) below the sky level. More negative keeps more shadow detail; less negative gives a blacker sky.":
         "Dónde se cortan los tonos más oscuros, en unidades de ruido (σ) por debajo del cielo. Más negativo conserva más detalle en sombras; menos negativo da un cielo más negro.",
      "One stretch for the three colour channels (keeps the colour balance) or one for each channel (evens out a colour cast). A grey image has nothing to link.":
         "Un solo estirado para los tres canales de color (conserva el equilibrio de color) o uno para cada canal (compensa una dominante). Una imagen gris no tiene nada que enlazar.",
      "Back to the automatic choice for this image, and forget what you set.": "Vuelve a lo automático para esta imagen y olvida lo que fijaste.",
      "automatic": "automático", "set by you": "fijado por ti", "window's STF": "STF de la ventana", "off": "apagado"
   };
   for (var k in T) if (Object.prototype.hasOwnProperty.call(T, k) && CSH_ES[k] === undefined) CSH_ES[k] = T[k];
})();

// ---- el icono (rejilla de 24, como los de la familia: M L H V C Z) y su pintor --------------------------------------------------------------
// PROCEDENCIA del pintor: CabraStars/lib/cs_atlas.js:116-191 (csPathToPolys, csPaintIcon), igual que lib/sl_ui.js de SurveyLens.
// Un histograma con su pico de cielo a la izquierda sobre los ejes, y la curva de medios tonos que lo levanta: eso es un estirado.
var CSH_STF_ICON = "M3 3 V21 H21 M6 20 V15 M9 20 V9 M12 20 V14 M15 20 V17.5 M4 19 C8 17 8.5 7 12.5 5.8 C15 5.1 18 4.6 21 4.2";
var CSH_STF_ICON_POLYS = null;
function cshStfPathToPolys(path) {
   var tok = String(path).match(/[MLHVCZ]|-?\d+(?:\.\d+)?/g) || [], polys = [], cur = null, i = 0, cx = 0, cy = 0, sx = 0, sy = 0, cmd = "";
   function num() { return parseFloat(tok[i++]); }
   while (i < tok.length) {
      if (/^[MLHVCZ]$/.test(tok[i])) cmd = tok[i++];
      if (cmd === "Z") { if (cur) { cur.push([sx, sy]); cx = sx; cy = sy; } cmd = ""; continue; }
      if (cmd === "M") { cx = num(); cy = num(); sx = cx; sy = cy; cur = [[cx, cy]]; polys.push(cur); cmd = "L"; }
      else if (cmd === "L") { cx = num(); cy = num(); if (!cur) { cur = [[cx, cy]]; polys.push(cur); } else cur.push([cx, cy]); }
      else if (cmd === "H") { cx = num(); cur.push([cx, cy]); }
      else if (cmd === "V") { cy = num(); cur.push([cx, cy]); }
      else if (cmd === "C") {
         var x1 = num(), y1 = num(), x2 = num(), y2 = num(), x3 = num(), y3 = num();
         for (var k = 1; k <= 12; ++k) { var t = k / 12, u = 1 - t; cur.push([u * u * u * cx + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3, u * u * u * cy + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3]); }
         cx = x3; cy = y3;
      } else break;
   }
   return polys;
}
function cshStfPaintIcon(g, x, y, px, color) {
   if (!CSH_STF_ICON_POLYS) CSH_STF_ICON_POLYS = cshStfPathToPolys(CSH_STF_ICON);
   var k = px / 24, polys = CSH_STF_ICON_POLYS, a, b;
   g.pen = new Pen(color, Math.max(1, 1.8 * k));
   for (a = 0; a < polys.length; ++a) { var Q = polys[a]; for (b = 1; b < Q.length; ++b) g.drawLine(x + Q[b - 1][0] * k, y + Q[b - 1][1] * k, x + Q[b][0] * k, y + Q[b][1] * k); }
}
// rectángulo de esquinas de radio ABSOLUTO (px físicos): drawRoundedRect da el radio en PORCENTAJE de la mitad de cada lado (lib/sl_ui.js slRoundRect)
function cshStfRoundRect(g, x0, y0, x1, y1, rAbs) {
   var hw = Math.max(1, (x1 - x0) / 2), hh = Math.max(1, (y1 - y0) / 2), xp = Math.min(99, 100 * rAbs / hw), yp = Math.min(99, 100 * rAbs / hh);
   g.drawRoundedRect(x0, y0, x1, y1, xp, yp);
}
function cshStfScaleOf(c) { var k = 0; try { k = c.logicalPixelsToPhysical(1000) / 1000; } catch (e) { k = 0; } return (k > 0) ? k : 1; }
function cshStfNum(v, d) { var s = Number(v).toFixed(d); return cshLangIsEs() ? s.split(".").join(",") : s; }
// el texto que dice POR QUÉ está como está (primera línea del tooltip del botón)
function cshStfWhy(st) {
   if (st.why === "user") return st.on ? cshT("Set by you for this image") : cshT("Stretch off, as you set it for this image");
   if (st.why === "window") return cshT("Using the window's STF");
   if (st.why === "linear") return cshT("Linear image: auto stretch applied");
   return cshT("Non-linear image: shown as is");
}
function cshStfStatusWord(st) {
   if (st.why === "user") return st.on ? cshT("set by you") : cshT("off");
   if (st.why === "window") return cshT("window's STF");
   return st.on ? cshT("automatic") : cshT("off");
}

// ---------------------------------------------------------------------------
// EL BOTÓN: [icono | flecha], pintado. Alto y esquina los da quien lo instala (en SurveyLens 28 y 13, como sus demás botones)
// ---------------------------------------------------------------------------
class CshStfButton extends Control {
   constructor(parent, o) {
      super(parent);
      var self = this;
      this.ctl = o.ctl; this.hot = null; this.on = false; this.panelOpen = false; this.rAbs = (o.r !== undefined) ? o.r : 13;
      this.onClick = null;                                  // (se llama al pulsar la mitad del icono; el controlador lo pone)
      this.setScaledFixedSize(CSH_STFUI.ICON_W + CSH_STFUI.CHEV_W, o.h || 28);
      this.cursor = new Cursor(StdCursor_PointingHand);
      try { this.mouseTracking = true; } catch (e0) {}
      // (17-nov-2026) TRANSPARENTE fuera de la esquina redondeada: sobre una foto (CabraStars, Cabra3D, CabraComposition) el fondo rectangular asomaba como cuatro esquinas
      // oscuras. Ni la hoja heredada del dialogo ni el pintor rellenan el rectangulo: lo de detras se ve a traves de las esquinas.
      try { this.styleSheet = "background: transparent; border: none;"; } catch (e1) {}
      this.onPaint = function () { var g = new Graphics(self); try { self.paintBtn(g); } finally { g.end(); } };
      this.onMouseMove = function (x, y) { var z = self.zoneAt(x); if (z !== self.hot) { self.hot = z; self.updateTip(); self.repaint(); } };
      this.onLeave = function () { if (self.hot !== null) { self.hot = null; self.repaint(); } };
      this.onMousePress = function (x, y) {
         if (!self.enabled) return;
         if (self.zoneAt(x) === "chev") self.ctl.togglePanel(); else self.ctl.toggle(true);          // (un clic de ratón: por trozos; `onClick()` a secas es el alias síncrono para scripts y pruebas)
      };
   }
   zoneAt(x) { return (x >= this.logicalPixelsToPhysical(CSH_STFUI.ICON_W)) ? "chev" : "icon"; }
   updateTip() {
      var st = this.ctl.model ? this.ctl.model.state() : null;
      if (!st) { this.toolTip = ""; return; }
      this.toolTip = (this.hot === "chev") ? cshTipWrap(cshT("Open the stretch controls")) : cshTipWrap(cshStfWhy(st) + "\n" + cshT("Click to turn the stretch on or off. The arrow opens the controls. Your image is never modified."));
   }
   paintBtn(g) {
      var A = CSH_ATLAS, W = this.width, H = this.height, k = cshStfScaleOf(this), on = this.on, en = this.enabled, hot = this.hot !== null && en;
      var iw = Math.round(CSH_STFUI.ICON_W * k), inset = cpInt(cpMix(A.bg, "#000000", 0.35)), ring = cpInt(cpMix(A.surface, A.gold, 0.45)), gold = cpInt(A.gold), line = cpInt(A.line);
      g.antialiasing = true; g.textAntialiasing = true;
      var bg = on ? cpInt(A.surface2) : inset, bd = on ? gold : (hot ? ring : line);
      if (!en) { bg = inset; bd = ring; }
      g.pen = new Pen(bd, 1); g.brush = new Brush(bg);
      cshStfRoundRect(g, 0.5, 0.5, W - 0.5, H - 0.5, this.rAbs * k);
      // la raya entre el icono y la flecha
      g.pen = new Pen(on ? cpInt(cpMix(A.gold, A.bg, 0.55)) : line, 1); g.drawLine(iw, Math.round(H * 0.24), iw, Math.round(H * 0.76));
      var px = Math.round(18 * k), col = !en ? cpInt(cpMix(A.text3, A.bg, 0.45)) : (on ? gold : (this.hot === "icon" ? cpInt(A.text) : cpInt(A.text3)));
      cshStfPaintIcon(g, Math.round((iw - px) / 2) + Math.round(1 * k), Math.round((H - px) / 2), px, col);
      // la flecha (abierto: apunta arriba)
      var cx = iw + Math.round((W - iw) / 2), cy = Math.round(H / 2), s = Math.round(3.4 * k);
      g.pen = new Pen(!en ? cpInt(cpMix(A.text3, A.bg, 0.45)) : (this.panelOpen || this.hot === "chev" ? cpInt(A.goldLight) : (on ? gold : cpInt(A.text3))), Math.max(1.3, 1.3 * k));
      if (this.panelOpen) { g.drawLine(cx - s, cy + s * 0.5, cx, cy - s * 0.6); g.drawLine(cx, cy - s * 0.6, cx + s, cy + s * 0.5); }
      else { g.drawLine(cx - s, cy - s * 0.5, cx, cy + s * 0.6); g.drawLine(cx, cy + s * 0.6, cx + s, cy - s * 0.5); }
   }
}

// ---------------------------------------------------------------------------
// EL PANEL (hijo flotante de `panelParent`, pintado como FVStfPanel; plegado de fábrica)
// ---------------------------------------------------------------------------
class CshStfPanel extends Control {
   constructor(parent, o) {
      super(parent);
      var self = this;
      this.ctl = o.ctl; this.drag = null; this.hot = null; this.rects = {}; this.k = 1; this.st = null; this.p = { clip: CSH_STF.CLIP0, bkg: CSH_STF_BKG, linked: true };
      try { this.mouseTracking = true; } catch (e0) {}
      this.cursor = new Cursor(StdCursor_PointingHand);
      this.onPaint = function () { var g = new Graphics(self); try { self.paintPanel(g); } finally { g.end(); } };
      this.onMousePress = function (x, y) { self.press(x, y); };
      this.onMouseMove = function (x, y, buttons) { self.moveM(x, y, buttons); };
      this.onMouseRelease = function () { self.release(); };
      this.onMouseWheel = function (x, y, delta) { self.wheelM(x, y, delta); };
      this.onLeave = function () { if (!self.drag && self.hot) { self.hot = null; self.repaint(); } };
      this.hide();
   }
   // lo que enseña: el estado del modelo (lo aplicado) — cuando lo fija la regla, las cifras de la regla en tenue
   syncFrom(st) {
      this.st = st;
      this.p = { clip: cshStfClamp(st.clip, CSH_STF.CLIP_MIN, CSH_STF.CLIP_MAX), bkg: cshStfClamp(st.bkg, CSH_STF.BKG_MIN, CSH_STF.BKG_MAX), linked: !!st.linked };
      this.repaint();
   }
   place(x, y) {
      var k = cshStfScaleOf(this); this.k = k;
      var w = Math.round(CSH_STFUI.W * k), h = Math.round(CSH_STFUI.H * k);
      if (this.width !== w || this.height !== h) this.setFixedSize(w, h);
      this.move(Math.round(x), Math.round(y));
   }
   paintPanel(g) {
      var A = CSH_ATLAS, k = cshStfScaleOf(this), W = this.width, H = this.height, st = this.st, p = this.p, y, pad = 12 * k;
      this.k = k;
      var fCaps = cpFont("text", CSH_ATLAS.size.label * k, true, false, cpCapsSpacing(CSH_ATLAS.size.label * k)), fS = cpFont("text", 10.5 * k), fM = cpFont("mono", 9.5 * k), fB = cpFont("text", 10.5 * k, true);
      g.antialiasing = true; g.textAntialiasing = true;
      g.fillRect(0, 0, W, H, new Brush(cpInt(A.surface, 0.97)));
      g.pen = new Pen(cpInt(cpMix(A.surface, A.gold, 0.45)), 1); g.brush = new Brush(0x00000000); g.drawRect(0.5, 0.5, W - 0.5, H - 0.5);
      this.rects = {};
      // cabecera: «STF» en versalitas, de dónde sale lo que se ve (corto; el porqué va en el tooltip del botón), y el aspa
      g.font = fCaps; g.pen = new Pen(cpInt(A.goldLight)); g.drawText(pad, 20 * k, cshT("STF"));
      var xs = W - 24 * k; g.pen = new Pen(this.hot === "close" ? cpInt(A.text) : cpInt(A.gold, 0.95), 1.3 * k);
      g.drawLine(xs, 9 * k, xs + 9 * k, 18 * k); g.drawLine(xs + 9 * k, 9 * k, xs, 18 * k);
      this.rects.close = [W - 32 * k, 2 * k, W - 2 * k, 28 * k];
      var word = st ? cshStfStatusWord(st) : "";
      g.font = fM; g.pen = new Pen(cpInt(st && st.changed ? A.gold : A.text2)); g.drawText(pad + 34 * k, 20 * k, "· " + word);
      this.rects.status = [0, 0, W - 32 * k, 28 * k];
      var dim = !!(st && !st.changed);          // los mandos enseñan la regla hasta que se tocan
      var off = !!(st && !st.on);
      y = 36 * k;
      this.slider(g, "bkg", y, cshT("Intensity"), cshStfNum(p.bkg, 2), (p.bkg - CSH_STF.BKG_MIN) / (CSH_STF.BKG_MAX - CSH_STF.BKG_MIN), dim || off, fS, fM); y += 44 * k;
      this.slider(g, "clip", y, cshT("Shadows"), cshStfNum(p.clip, 1) + " σ", (p.clip - CSH_STF.CLIP_MIN) / (CSH_STF.CLIP_MAX - CSH_STF.CLIP_MIN), dim || off, fS, fM); y += 46 * k;
      // la casilla «Linked» (gris: sin canales que enlazar) y «Auto»
      var mono = !!(st && st.mono), bx = pad, by = y + 4 * k, bs = 12 * k, on = mono ? true : !!p.linked, cc = mono ? cpInt(A.text2, 0.45) : cpInt(A.gold, 0.95);
      g.pen = new Pen(cc, 1.2 * k); g.brush = new Brush(0x00000000); cshStfRoundRect(g, bx, by, bx + bs, by + bs, 3 * k);
      if (on) g.fillRect(bx + 3 * k, by + 3 * k, bx + bs - 3 * k, by + bs - 3 * k, new Brush(cc));
      g.font = fS; g.pen = new Pen(mono ? cpInt(A.text2, 0.45) : cpInt(A.text, this.hot === "linked" ? 1 : 0.92)); g.drawText(bx + bs + 8 * k, by + bs - 1 * k, cshT("Linked"));
      this.rects.linked = [0, y, W * 0.55, y + 24 * k];
      var aw = 68 * k, ah = 24 * k, ax = W - pad - aw, ay = y - 1 * k, aOn = !!(st && st.changed);
      g.pen = new Pen(cpInt(A.gold, aOn ? 0.95 : 0.35), 1.2 * k); g.brush = new Brush(aOn && this.hot === "auto" ? cpInt(A.gold, 0.22) : 0x00000000);
      cshStfRoundRect(g, ax, ay, ax + aw, ay + ah, 9 * k);
      g.font = fB; var at = cshT("Auto"); g.pen = new Pen(aOn ? cpInt(A.goldLight) : cpInt(A.text2, 0.5)); g.drawText(ax + (aw - fB.width(at)) / 2, ay + 16 * k, at);
      this.rects.auto = [ax, ay, ax + aw, ay + ah];
   }
   slider(g, id, y, label, val, f, dim, fS, fM) {
      var A = CSH_ATLAS, k = this.k, W = this.width, pad = 12 * k, x0 = pad + 4 * k, x1 = W - pad - 4 * k, ty = y + 28 * k, fr = cshStfClamp(f, 0, 1), hot = (this.hot === id || (this.drag && this.drag.id === id));
      g.font = fS; g.pen = new Pen(cpInt(A.text, 0.95)); g.drawText(pad, y + 12 * k, label);
      g.font = fM; g.pen = new Pen(dim ? cpInt(A.text2, 0.7) : cpInt(A.goldLight)); g.drawText(W - pad - fM.width(val), y + 12 * k, val);
      g.pen = new Pen(cpInt(A.line), 3 * k); g.drawLine(x0, ty, x1, ty);
      g.pen = new Pen(cpInt(cpMix(A.surface, A.gold, 0.45)), 3 * k); g.drawLine(x0, ty, x0 + fr * (x1 - x0), ty);
      var kx = x0 + fr * (x1 - x0), r = (hot ? 6.5 : 5.5) * k, hc = dim ? cpInt(A.gold, 0.65) : (hot ? cpInt(A.goldLight) : cpInt(A.gold));
      g.pen = new Pen(cpInt(A.goldLight, dim ? 0.6 : 1), 1.2 * k); g.brush = new Brush(hc); g.drawCircle(kx, ty, r); g.fillCircle(kx, ty, r - 1, new Brush(hc));
      this.rects[id] = [0, y, W, y + 38 * k, x0, x1];
   }
   hitM(x, y) {
      var order = ["close", "bkg", "clip", "linked", "auto", "status"];
      for (var i = 0; i < order.length; ++i) { var r = this.rects[order[i]]; if (r && x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) return order[i]; }
      return null;
   }
   valueAt(id, x) {
      var r = this.rects[id], f = cshStfClamp((x - r[4]) / Math.max(1, r[5] - r[4]), 0, 1);
      if (id === "clip") return Math.round(100 * (CSH_STF.CLIP_MIN + f * (CSH_STF.CLIP_MAX - CSH_STF.CLIP_MIN))) / 100;
      return Math.round(100 * (CSH_STF.BKG_MIN + f * (CSH_STF.BKG_MAX - CSH_STF.BKG_MIN))) / 100;
   }
   press(x, y) {
      var h = this.hitM(x, y), mono = !!(this.st && this.st.mono);
      if (h === "close") { this.ctl.closePanel(); return; }
      if (h === "clip" || h === "bkg") { this.drag = { id: h }; this.setVal(h, this.valueAt(h, x)); return; }
      if (h === "linked" && !mono) { this.p.linked = !this.p.linked; this.repaint(); this.ctl.commitParams(this.p); return; }
      if (h === "auto") { this.ctl.auto(true); return; }
   }
   moveM(x, y, buttons) {
      if (this.drag && buttons) { this.setVal(this.drag.id, this.valueAt(this.drag.id, x)); return; }
      var h = this.hitM(x, y);
      if (h !== this.hot) {
         this.hot = h;
         var tips = { bkg: "How strong the stretch is: the brightness the sky background gets on screen (0.05 dark … 0.50 bright). The family default is 0.12.",
                      clip: "Where the darkest tones are cut, in noise units (σ) below the sky level. More negative keeps more shadow detail; less negative gives a blacker sky.",
                      linked: "One stretch for the three colour channels (keeps the colour balance) or one for each channel (evens out a colour cast). A grey image has nothing to link.",
                      auto: "Back to the automatic choice for this image, and forget what you set.", close: "Close", status: "" };
         this.toolTip = (h && tips[h]) ? cshTipWrap(cshT(tips[h])) : "";
         this.repaint();
      }
   }
   release() { if (this.drag) { this.drag = null; this.repaint(); this.ctl.commitParams(this.p); } }
   wheelM(x, y, delta) {
      var h = this.hitM(x, y); if (h !== "clip" && h !== "bkg") return;
      var st = (delta > 0 ? 1 : -1) * (h === "clip" ? 0.1 : 0.01);
      this.setVal(h, Math.round(100 * ((h === "clip" ? this.p.clip : this.p.bkg) + st)) / 100);
      this.ctl.settleSoon(this.p);
   }
   setVal(id, v) {
      v = (id === "clip") ? cshStfClamp(v, CSH_STF.CLIP_MIN, CSH_STF.CLIP_MAX) : cshStfClamp(v, CSH_STF.BKG_MIN, CSH_STF.BKG_MAX);
      if (this.p[id] === v) return;
      this.p[id] = v; this.repaint();
      this.ctl.live(this.p);
   }
}

// ---------------------------------------------------------------------------
// EL CONTROLADOR: une el modelo (CshStf), el botón y el panel; el que lo instala solo aplica lo que sale
// o = { parent, panelParent, h, r, place(panel, button) -> {x, y} en coordenadas de panelParent, onApply(model, state, phase), onOpen() }
// ---------------------------------------------------------------------------
function CshStfControl(o) {
   var self = this;
   this.o = o; this.model = null; this.panelOpen = false; this.pending = null; this.settleP = null;
   this.button = new CshStfButton(o.parent, { ctl: this, h: o.h, r: o.r });
   this.panel = new CshStfPanel(o.panelParent || o.parent, { ctl: this });
   this.liveTimer = new Timer; this.liveTimer.periodic = false; this.liveTimer.interval = CSH_STFUI.LIVE;
   this.liveTimer.onTimeout = function () { self._tick(); };
   this.settleTimer = new Timer; this.settleTimer.periodic = false; this.settleTimer.interval = CSH_STFUI.SETTLE;
   this.settleTimer.onTimeout = function () { if (self.settleP) { var p = self.settleP; self.settleP = null; self.commitParams(p); } };
   this.button.onClick = function () { self.toggle(false); };
   this.button.enabled = false;
}
CshStfControl.prototype.setModel = function (model) {
   this.model = model; this.button.enabled = !!model; this.refresh();
};
CshStfControl.prototype.state = function () { return this.model ? this.model.state() : null; };
// repinta botón y panel con el estado del modelo
CshStfControl.prototype.refresh = function () {
   var st = this.state();
   this.button.on = !!(st && st.on); this.button.panelOpen = this.panelOpen;
   this.button.updateTip(); try { this.button.repaint(); } catch (e0) {}
   if (st) this.panel.syncFrom(st);
};
CshStfControl.prototype._apply = function (phase) {
   if (!this.model) return;
   this.refresh();
   if (this.o.onApply) this.o.onApply(this.model, this.model.state(), phase);
};
// el botón: pone o quita el estirado
// staged = true (un clic de ratón): la fase «commit», que el que instala puede hacer en trozos para no dejar la interfaz parada (PR-5); false (por programa): «click», todo ahora y antes de volver
CshStfControl.prototype.toggle = function (staged) {
   if (!this.model) return;
   this.setOn(!this.model.state().on, staged);
};
CshStfControl.prototype.setOn = function (on, staged) {
   if (!this.model) return;
   this._cancelPending();
   this.model.setOn(on); this._apply(staged ? "commit" : "click");
};
// un mando se mueve: repintado rápido cada CSH_STFUI.LIVE s (solo lo barato) y, al soltar, todo
CshStfControl.prototype.live = function (p) {
   if (!this.model || CSH_STFUI.BREAK === "nolive") return;
   this.pending = { clip: p.clip, bkg: p.bkg, linked: p.linked };
   if (!this.liveTimer.isRunning) this.liveTimer.start();
};
CshStfControl.prototype._tick = function () {
   if (!this.pending || !this.model) return;
   var p = this.pending; this.pending = null;
   this.model.setParams(p, true);
   this._apply("live");
};
CshStfControl.prototype._cancelPending = function () { this.pending = null; this.settleP = null; try { this.liveTimer.stop(); this.settleTimer.stop(); } catch (e) {} };
// la rueda: no hay «soltar», así que se espera a que pare
CshStfControl.prototype.settleSoon = function (p) {
   this.settleP = { clip: p.clip, bkg: p.bkg, linked: p.linked };
   this.settleTimer.stop(); this.settleTimer.start();
};
// soltado (o «Linked» pulsado): fija, recuerda y aplica todo
CshStfControl.prototype.commitParams = function (p) {
   if (!this.model) return;
   this._cancelPending();
   this.model.setParams({ clip: p.clip, bkg: p.bkg, linked: p.linked });
   this._apply("commit");
};
CshStfControl.prototype.auto = function (staged) {
   if (!this.model) return;
   this._cancelPending();
   if (CSH_STFUI.BREAK !== "noauto") this.model.auto();
   this._apply(staged ? "commit" : "click");
};
CshStfControl.prototype.openPanel = function () {
   if (!this.model) return;
   if (this.o.onOpen) this.o.onOpen();                                  // quien lo instala cierra lo demás (un menú a la vez)
   this.panelOpen = true; this.refresh();
   var pos = this.o.place ? this.o.place(this.panel, this.button) : { x: 0, y: 0 };
   this.panel.place(pos.x, pos.y); this.panel.show(); try { this.panel.bringToFront(); } catch (e) {}
   this.button.panelOpen = true; this.button.repaint();
};
CshStfControl.prototype.closePanel = function () {
   if (!this.panelOpen) return;
   this.panelOpen = false; this.panel.hide(); this.button.panelOpen = false; this.button.repaint();
};
CshStfControl.prototype.togglePanel = function () { if (this.panelOpen) this.closePanel(); else this.openPanel(); };
CshStfControl.prototype.dispose = function () { this._cancelPending(); try { this.panel.hide(); } catch (e) {} };
#endif
