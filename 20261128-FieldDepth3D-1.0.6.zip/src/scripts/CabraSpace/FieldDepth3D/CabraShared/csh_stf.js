#ifndef __CSH_STF
#define __CSH_STF
#include <pjsr/DataType.jsh>
#include "csh_web.js"      // solo cshWebPlatform (108 lineas, sin dependencias): la plataforma para decidir si la clave de un fichero distingue mayusculas (H-6)
// ============================================================================
// CabraShared/csh_stf.js — LA IMAGEN Y SU ESTIRADO: ¿lineal o ya estirada?, el STF de la vista, el estirado automático y el REGULABLE (17-nov-2026)
// ----------------------------------------------------------------------------
// Dos mitades en un fichero, sin interfaz:
//   1. LA REGLA COMÚN DE LA FAMILIA, movida aquí TAL CUAL desde csh_astrometry.js (que ahora lo incluye; mismos nombres, mismo comportamiento): optSafeView, cshMtf,
//      cshViewStf, cshStfValue, cshLinearStats, cpViewIsLinear, cshPhotoStretchMode, cshAutoStfRows (con un 4.º argumento opcional), cshColorStatus. La usan CabraStars,
//      CabraComposition, Cabra3D, CabraStarAnalysis y FieldVoyager (y ahora SurveyLens) sin cargar el resto de csh_astrometry.js.
//   2. LO NUEVO: estadísticas, filas con recorte y fondo a elección, render sobre una copia, el modelo CshStf (decisión al abrir + lo que el usuario cambia + lo
//      recordado por imagen). La interfaz común (botón y panel) está en csh_stf_panel.js.
// Depende solo de PixInsight (View, Image, Settings); no necesita csh_i18n.js ni csh_atlas.js. ES5.
// ============================================================================

// ---- (movido tal cual de csh_astrometry.js) ----
// Una vista utilizable: existe, no es nula, tiene imagen y ventana (CabraPilot engine/inherited.js + CabraStars).
function optSafeView(view) {
   try {
      var notNull = true;
      try { if (typeof view.isNull !== "undefined") notNull = (view.isNull === false); } catch (e0) { notNull = true; }
      if (!(view && typeof view === "object" && notNull && view.image && view.window)) return false;
      try { if (!(view.image.width > 0)) return false; } catch (e1) {}
      return true;
   } catch (e) { return false; }
}

// La función de transferencia de medios tonos de PixInsight (la de su STF y su HistogramTransformation). (El comentario de aquí hablaba de la regla de
// «¿lineal?» de antes —mediana, MAD y MTF—, que ya no existe: la vigente es la de «(31-oct-2026) ¿LINEAL O YA ESTIRADA?», más abajo.)
function cshMtf(m, x) {
   if (x <= 0) return 0; if (x >= 1) return 1; if (m === x) return 0.5;
   return (m - 1) * x / ((2 * m - 1) * x - m);
}
// (30-oct-2026) EL STF DE LA VISTA (Nino: «cuando cargo la imagen, tengo un color diferente que la imagen que veo en el Workspace»):
// la foto de los paneles se pinta con el MISMO STF que la vista tiene en PixInsight; el estirado automático propio queda solo
// para cuando la vista no tiene ninguno. `view.stf` (medido, CabraStars/tests/cs_probe_stf.log): por canal R, G, B, L
// [m, c0, c1, r0, r1]; recién abierta, la identidad [0.5, 0, 1, 0, 1] en los cuatro. En gris PixInsight usa la fila 0 (R/K).
// Devuelve [{ m, c0, c1, r0, r1 }] (3 filas en color, 1 en gris) o null si es la identidad o no se puede leer.
// Rojo: CSH_STF_BREAK = "noview" (se ignora el STF de la vista, como antes).
var CSH_STF_BREAK = "";
function cshViewStf(view, nc) {
   if (CSH_STF_BREAK === "noview") return null;
   var s = null;
   try { s = view.stf; } catch (e) { return null; }
   if (!s || !s.length) return null;
   var n = (nc >= 3) ? 3 : 1, out = [], any = false;
   for (var c = 0; c < n; ++c) {
      var r = s[c];
      if (!r || r.length < 3) return null;
      var o = { m: +r[0], c0: +r[1], c1: +r[2], r0: (r.length > 3) ? +r[3] : 0, r1: (r.length > 4) ? +r[4] : 1 };
      if (!(isFinite(o.m) && isFinite(o.c0) && isFinite(o.c1) && o.c1 > o.c0)) return null;
      if (Math.abs(o.m - 0.5) > 1e-6 || o.c0 > 1e-9 || o.c1 < 1 - 1e-9 || Math.abs(o.r0) > 1e-9 || Math.abs(o.r1 - 1) > 1e-9) any = true;
      out.push(o);
   }
   return any ? out : null;
}
// Un valor a través de una fila de STF (como lo hace PixInsight: recorte c0-c1, MTF, expansión r0-r1)
function cshStfValue(o, v) {
   var x = (v - o.c0) / (o.c1 - o.c0);
   x = (x <= 0) ? 0 : (x >= 1) ? 1 : cshMtf(o.m, x);
   return o.r0 + x * (o.r1 - o.r0);
}
// (31-oct-2026) ¿LINEAL O YA ESTIRADA? La regla de arriba (mediana, MAD y MTF) fallaba en los dos sentidos: la MAD de `view.image.MAD()` mezcla los tres
// canales, y una foto lineal con fondos distintos por canal salía «no lineal» (Soul Nebula, 0,0134). Y era una regla sobre el FONDO: no dice nada de una imagen
// terminada con el cielo oscuro. Lo que separa las dos familias es LA COLA: en una lineal el 1 % más brillante apenas se separa del cielo, en una estirada sí.
//   Es NO lineal si mediana > 0,20, o si p99 − mediana > 0,035 Y p99,9 − mediana > 0,30 (sobre la media de los canales nominales; unas 400 000 muestras, ~60 ms).
//   Medido (CabraStars/docs/lineal_vs_no_lineal_31oct.md): 16 de 16 lineales reales bien (la mayor cola, Orion: 0,0218 / 0,272) y los 5 finales reales bien
//   (la menor cola, NGC 3184: 0,0515 / 0,401). Estirados fuertes de otras curvas, bien. Se escapan estirados suaves (gamma 0,7; arcsinh 20): salen «lineales»
//   y reciben el estirado automático; quien lo vea mal pone un STF en PixInsight y manda ese (cshViewStf).
// Rojo: CSH_LIN_BREAK = "old" (la regla de antes).
var CSH_LIN = { MED_HI: 0.20, TAIL99: 0.035, TAIL999: 0.30, SAMPLES: 400000 };
var CSH_LIN_BREAK = "";
function cshLinearStats(view) {
   var img = view.image, nc = 1;
   try { nc = Math.min(3, img.numberOfNominalChannels); } catch (eN) { nc = img.isColor ? 3 : 1; }
   var W = img.width, H = img.height, st = Math.max(1, Math.floor(Math.sqrt(W * H / CSH_LIN.SAMPLES))), nr = Math.floor(H / st), nw = Math.floor(W / st);
   var S = new Float32Array(nr * nw), row = new Float32Array(W), k;
   for (var c = 0; c < nc; ++c) {
      k = 0;
      for (var y = 0; y < nr; ++y) {
         img.getSamples(row, new Rect(0, y * st, W, y * st + 1), c);
         for (var x = 0; x < nw; ++x) S[k++] += row[x * st] / nc;
      }
   }
   S.sort();
   var N = S.length, med = S[N >> 1];
   return { med: med, tail99: S[Math.min(N - 1, Math.floor(0.99 * N))] - med, tail999: S[Math.min(N - 1, Math.floor(0.999 * N))] - med };
}
function cpViewIsLinear(view) {
   if (!optSafeView(view)) return false;
   try { if (view.image && ("isLinear" in view.image)) { var p = view.image["isLinear"]; if (p === true || p === false) return p; } } catch (eP) {}
   if (CSH_LIN_BREAK === "old") {
      var med0, mad0;
      try { med0 = view.image.median(); mad0 = view.image.MAD(); } catch (e0) { return false; }
      if (med0 === 0 && mad0 === 0) return true;
      var c00 = Math.max(0, med0 - 2.8 * mad0), m0 = cshMtf(0.25, med0 - c00);
      if (!isFinite(m0)) m0 = 0.5;
      return (med0 < 0.10) && (mad0 < 0.008) && (m0 < 0.15);
   }
   var s;
   try { s = cshLinearStats(view); } catch (e) { return false; }
   return !(s.med > CSH_LIN.MED_HI || (s.tail99 > CSH_LIN.TAIL99 && s.tail999 > CSH_LIN.TAIL999));
}
// (31-oct-2026) CÓMO SE PINTA LA FOTO, UNA SOLA REGLA PARA TODOS (Nino: «las que ya están estiradas no tenemos que estirarlas»; antes cada script tenía la suya:
// CabraStars estiraba canal a canal todo canal con mediana < 0,2, y CabraComposition, si la media de medianas < 0,08):
//   "view"  la vista tiene STF en PixInsight: ese, sea lineal o no · "none" ya estirada: tal cual ·
//   "mad-linked" lineal con el color calibrado o gris (conserva el equilibrio de SPCC) · "mad-unlinked" lineal sin calibrar (cada canal el suyo).
// Fondo del cielo del estirado automático: el 12 % que pidió Nino el 20-oct (con el 0,25 del AutoSTF salía lavada), ahora en los cuatro.
var CSH_STF_BKG = 0.12;
function cshPhotoStretchMode(view) {
   if (!optSafeView(view)) return "none";
   var nc = 1;
   try { nc = view.image.numberOfChannels; } catch (e) {}
   if (cshViewStf(view, nc)) return "view";
   if (!cpViewIsLinear(view)) return "none";
   var c = cshColorStatus(view);
   return (c.mono || c.calibrated) ? "mad-linked" : "mad-unlinked";
}
// Las filas del estirado automático: medianas y MAD NORMALIZADAS (×1,4826) por canal → [{ c0, m }], enlazadas si `linked`. El MTF es el de PixInsight.
// (17-nov-2026) 4.º argumento OPCIONAL p = { clip, bkg }: el recorte de sombras (σ, negativo; por defecto −2,8) y el fondo objetivo (por defecto CSH_STF_BKG). Sin él, el
// resultado es el de siempre, bit a bit (med + (−2,8)·mad es exactamente med − 2,8·mad). Lo usa el estirado regulable de abajo (cshStfRows).
function cshAutoStfRows(meds, mads, linked, p) {
   var out = [], n = meds.length, a = 0, b = 0, c;
   var clip = (p && typeof p.clip === "number") ? p.clip : -2.8, bkg = (p && typeof p.bkg === "number") ? p.bkg : CSH_STF_BKG;
   for (c = 0; c < n; ++c) { a += meds[c]; b += mads[c]; }
   a /= n; b /= n;
   for (c = 0; c < n; ++c) {
      var med = linked ? a : meds[c], mad = linked ? b : mads[c], c0 = Math.max(0, Math.min(1, med + clip * mad));
      out.push({ c0: c0, m: cshMtf(bkg, Math.max(1e-6, med - c0)) });
   }
   return out;
}

// ¿Color, calibrado? (consejo, no bloqueo). La lista de CabraPilot (engine/image_manager.js) en el historial de la sesion y
// en el guardado en el fichero (propiedad PixInsight:ProcessingHistory, que vio CabraComposition). -> { mono, calibrated, how }
var CSH_COLOR_CAL_PROCESSES = ["SpectrophotometricColorCalibration", "PhotometricColorCalibration", "ColorCalibration"];
function cshColorStatus(view) {
   var out = { mono: false, calibrated: false, how: "" };
   if (!optSafeView(view)) return out;
   try { out.mono = (view.image.numberOfChannels < 3); } catch (e0) {}
   if (out.mono) return out;
   function scan(container) {
      var n = 0;
      try { n = container.length; } catch (e) { return ""; }
      for (var i = 0; i < n; ++i) {
         var pid = "";
         // (17-nov-2026, RED-4) primero el subindice: en PixInsight 1.9.6 build 1718 `ProcessContainer.at()` esta obsoleto y avisa en la consola.
         // `at()` queda solo como respaldo si el subindice no da un proceso (versiones antiguas).
         try { var pi = container[i]; pid = String((pi !== undefined && pi !== null) ? pi.processId() : container.at(i).processId()); } catch (e1) { continue; }
         if (CSH_COLOR_CAL_PROCESSES.indexOf(pid) >= 0) return pid;
      }
      return "";
   }
   var how = "";
   try { how = scan(view.initialProcessing); } catch (e2) {}
   if (!how) try { how = scan(view.processing); } catch (e3) {}
   if (!how) try { var ph = String(view.propertyValue("PixInsight:ProcessingHistory") || ""); for (var k = 0; k < CSH_COLOR_CAL_PROCESSES.length && !how; ++k) if (ph.indexOf(CSH_COLOR_CAL_PROCESSES[k]) >= 0) how = CSH_COLOR_CAL_PROCESSES[k]; } catch (e4) {}
   out.calibrated = how.length > 0; out.how = how;
   return out;
}

// ============================================================================
// LO NUEVO (17-nov-2026, «STF común y automático», petición de Nino): el estirado regulable, la decisión al abrir y lo recordado por imagen.
// Todo se apoya en la regla de arriba (cpViewIsLinear, cshViewStf, cshAutoStfRows, cshPhotoStretchMode): no hay una segunda regla.
// ----------------------------------------------------------------------------
//   cshStfStats(img)                    -> { nc, med[], mad[] } mediana y MAD NORMALIZADA (× 1,4826) por canal, imagen entera (57-290 ms en 21 Mpx)
//   cshStfRows(stats, p)                -> [{ c0, m, c1, r0, r1 }] una fila por canal; p = { clip (σ, negativo), bkg (fondo objetivo), linked }
//   cshStfDisplayArgs(rows)             -> las 4 filas [m, c0, c1, r0, r1] que entiende Image.applyDisplayFunction (R, G, B y L)
//   cshStfRender(img, args)             -> Bitmap RGB32 de una COPIA de la imagen con ese estirado (args null = tal cual). La imagen NO se toca nunca.
//   new CshStf(view, o)                 -> el MODELO de una imagen: la decisión al abrir, lo que el usuario cambia y lo recordado (sin interfaz)
//        .state()    { on, src ("view" | "auto" | "manual" | "none"), why ("window" | "linear" | "nonlinear" | "user"), clip, bkg, linked, mono, changed }
//        .args()     las 4 filas para aplicar, o null (apagado)         .setOn(b)   .setParams({ clip, bkg, linked })   .auto()   .render()
// ORDEN DE DECISIÓN AL ABRIR (Nino, 17-nov): 1 ¿la ventana tiene un STF activo? se usa ESE (lo que ve en PixInsight) · 2 si no, lineal → estirado automático
// (cshPhotoStretchMode: enlazado si es gris o está calibrada, por canal si no; fondo CSH_STF_BKG 0,12, sombras −2,8 MAD) · 3 no lineal → tal cual.
// Siempre cambiable a mano. LO RECORDADO: solo lo que el usuario cambió, POR IMAGEN (clave = ruta del fichero + tamaño, o el id de la vista si no tiene
// fichero): { on, clip, bkg, linked } en los ajustes de PixInsight (CabraShared/stf/<huella>), con un índice de hasta CSH_STF.KEEP imágenes; «Auto» lo borra.
// (H-6) Solo las imágenes CON fichero van a Settings (y la ruta se pasa a minúsculas solo en Windows); las SIN GUARDAR viven en CSH_STF_SESSION, solo mientras corre el script.
// La decisión automática NO se guarda: se recalcula al abrir cada imagen. (Settings.write no llega a disco hasta cerrar PixInsight: pjsr/settings-write-no-llega-...)
// Rojos de pruebas: CSH_STF.BREAK = "noapply" (el estirado no se aplica: la foto sale tal cual) · "nowrite" (no se escribe lo recordado) · "flipsign" (sombras con el signo cambiado).
// ES5.
// ============================================================================
var CSH_STF = {
   CLIP0: -2.8,                         // sombras de la regla: −2,8 MAD normalizadas (el AutoSTF de PixInsight)
   CLIP_MIN: -5.0, CLIP_MAX: -1.0,      // el recorrido ÚTIL del mando de sombras (CabraPilot stf_popup.js, medido en cp_stf_probe.log; el mismo que FieldVoyager)
   BKG_MIN: 0.05, BKG_MAX: 0.50,        // y el del fondo objetivo (la «intensidad»)
   KEEP: 60,                            // imágenes cuyo ajuste se recuerda (las más recientes)
   STORE: null,                         // pruebas: un objeto en vez de Settings
   ROOT: "",                            // raiz de Settings de lo recordado: CADA SCRIPT pone la suya al cargar («SurveyLens/stf», «CabraStars/stf»...), para que todos sus ajustes
                                        // cuelguen de su propia raiz (regla CPD 4.4, comprobada por csa_cpd_node N2; 17-nov-2026). Vacia = «CabraShared/stf», la de antes.
   PLATFORM: "",                        // pruebas: "windows" | "macos" | "linux" simulada para la clave de fichero ("" = la real, cshWebPlatform())
   BREAK: ""                            // rojos
};
// (17-nov-2026, revision externa H-6) Lo recordado de las imagenes SIN GUARDAR (sin ruta de fichero) NO va a Settings: vive en este mapa, que dura lo que dure la ejecucion
// del script (su motor), no mas. Su clave es el id de la vista + tamano: dos imagenes sin guardar de sesiones distintas que reusen «Image01» del mismo tamano ya no se heredan.
var CSH_STF_SESSION = {};
function cshStfClamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

// ---- el cálculo ----------------------------------------------------------------------------------------------------------------------
function cshStfStats(img) {
   var nc = 1, med = [], mad = [], c, t0 = Date.now();
   try { nc = img.isColor ? 3 : 1; } catch (e0) { nc = 1; }
   try { for (c = 0; c < nc; ++c) { img.selectedChannel = c; med.push(img.median()); mad.push(1.4826 * img.MAD()); } }
   finally { try { img.resetSelections(); } catch (e1) {} }
   return { nc: nc, med: med, mad: mad, ms: Date.now() - t0 };
}
// las filas del estirado automático con recorte y fondo a elección. p = { clip, bkg, linked }
function cshStfRows(stats, p) {
   var clip = (CSH_STF.BREAK === "flipsign") ? -p.clip : p.clip;
   var rows = cshAutoStfRows(stats.med, stats.mad, !!p.linked, { clip: clip, bkg: p.bkg }), i;
   for (i = 0; i < rows.length; ++i) { rows[i].c1 = 1; rows[i].r0 = 0; rows[i].r1 = 1; }
   return rows;
}
// [m, c0, c1, r0, r1] x 4 (R, G, B, L). En una imagen gris PixInsight usa la fila 0 (medido: sl_stf_probe_timing.log, computeAutoStretch() da 4 filas con la 0 propia).
function cshStfDisplayArgs(rows) {
   var out = [], i, r;
   for (i = 0; i < 3; ++i) { r = rows[Math.min(i, rows.length - 1)]; out.push([r.m, r.c0, r.c1, r.r0, r.r1]); }
   out.push([0.5, 0, 1, 0, 1]);
   return out;
}
// Bitmap RGB32 de una COPIA de la imagen (coste medido en 21 Mpx: copia 20-30 ms + aplicar 20-60 ms + render 25 ms). `args` = las 4 filas (o null = sin estirar).
function cshStfRender(img, args) {
   if (CSH_STF.BREAK === "noapply") args = null;
   var work = new Image(img), bmp = null;
   try { work.resetSelections(); if (args) work.applyDisplayFunction(args); bmp = work.render(1, false, false); }
   finally { try { work.free(); } catch (e) {} }
   return bmp;
}

// ---- lo recordado por imagen ---------------------------------------------------------------------------------------------------------
// (17-nov-2026, H-6) Las minusculas SOLO en Windows (el unico sistema de ficheros de los tres donde «A.xisf» y «a.xisf» son el mismo fichero; en macOS y Linux son dos y
// compartian clave). En Windows la clave es la de siempre (ruta con «/» y en minusculas), asi que lo ya escrito en Settings se sigue leyendo. La barra invertida se
// convierte tambien solo en Windows (en Linux es un caracter legal del nombre). cshWebPlatform viene de csh_web.js (CoreApplication.platform).
function cshStfPlatform() { return (typeof CSH_STF.PLATFORM === "string" && CSH_STF.PLATFORM.length) ? CSH_STF.PLATFORM : cshWebPlatform(); }
// ¿Tiene la imagen un fichero? Sin el, su ajuste manual no se guarda en Settings (vive solo en CSH_STF_SESSION).
function cshStfIsSaved(view) { try { return String(view.window.filePath || "").length > 0; } catch (e) { return false; } }
function cshStfImageKey(view) {
   var fp = "", id = "", dims = "";
   try { fp = String(view.window.filePath || ""); } catch (e0) {}
   try { id = String(view.id || ""); } catch (e1) {}
   try { dims = view.image.width + "x" + view.image.height + "x" + (view.image.isColor ? 3 : 1); } catch (e2) {}
   if (fp) { if (cshStfPlatform() === "windows") fp = fp.split("\\").join("/").toLowerCase(); return fp + "|" + dims; }
   return "id:" + id + "|" + dims;
}
function cshStfHash(s) {
   var h = 5381, i;
   for (i = 0; i < s.length; ++i) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0;
   var h2 = 0; for (i = s.length - 1; i >= 0; --i) h2 = ((h2 * 31) + s.charCodeAt(i)) >>> 0;
   return ("00000000" + h.toString(16)).slice(-8) + ("00000000" + h2.toString(16)).slice(-8);
}
function cshStfRoot() { return (typeof CSH_STF.ROOT === "string" && CSH_STF.ROOT.length) ? CSH_STF.ROOT : "CabraShared/stf"; }
function cshStfRawRead(k) {
   if (CSH_STF.STORE) return CSH_STF.STORE[k] || "";
   try { var v = Settings.read(cshStfRoot() + "/" + k, DataType_String); return (Settings.lastReadOK !== false && v) ? String(v) : ""; } catch (e) { return ""; }
}
function cshStfRawWrite(k, v) {
   if (CSH_STF.STORE) { if (v) CSH_STF.STORE[k] = v; else delete CSH_STF.STORE[k]; return; }
   try { Settings.write(cshStfRoot() + "/" + k, DataType_String, v); } catch (e) {}
}
// -> null o { on, p: null | { clip, bkg, linked } }.  mem = true: imagen sin guardar, se lee de CSH_STF_SESSION y NUNCA de Settings (una clave «id:...» escrita antes de H-6 se ignora)
function cshStfLoad(key, mem) {
   var s;
   if (mem) s = CSH_STF_SESSION.hasOwnProperty(key) ? CSH_STF_SESSION[key] : "";
   else s = cshStfRawRead(cshStfHash(key));
   if (!s) return null;
   var J = null; try { J = JSON.parse(s); } catch (e) { return null; }
   if (!J || J.v !== 1 || J.k !== key) return null;                 // (la clave completa dentro: una colisión de huella no se hereda)
   var u = { on: J.on !== false, p: null };
   if (J.p && typeof J.p.clip === "number" && typeof J.p.bkg === "number" && isFinite(J.p.clip) && isFinite(J.p.bkg))
      u.p = { clip: cshStfClamp(J.p.clip, CSH_STF.CLIP_MIN, CSH_STF.CLIP_MAX), bkg: cshStfClamp(J.p.bkg, CSH_STF.BKG_MIN, CSH_STF.BKG_MAX), linked: J.p.linked === true };
   return u;
}
function cshStfSave(key, user, mem) {
   if (CSH_STF.BREAK === "nowrite") return;
   if (mem) {                                                       // sin guardar: solo en memoria, sin tocar Settings ni su indice
      if (!user) { delete CSH_STF_SESSION[key]; return; }
      var M = { v: 1, k: key, on: user.on !== false };
      if (user.p) M.p = { clip: Math.round(user.p.clip * 1000) / 1000, bkg: Math.round(user.p.bkg * 1000) / 1000, linked: !!user.p.linked };
      CSH_STF_SESSION[key] = JSON.stringify(M);
      return;
   }
   var h = cshStfHash(key), idx = [], s = cshStfRawRead("index"), i;
   try { idx = s ? JSON.parse(s) : []; } catch (e) { idx = []; }
   if (!(idx instanceof Array)) idx = [];
   for (i = idx.length - 1; i >= 0; --i) if (idx[i] === h) idx.splice(i, 1);
   if (!user) { cshStfRawWrite(h, ""); cshStfRawWrite("index", JSON.stringify(idx)); return; }
   var J = { v: 1, k: key, on: user.on !== false };
   if (user.p) J.p = { clip: Math.round(user.p.clip * 1000) / 1000, bkg: Math.round(user.p.bkg * 1000) / 1000, linked: !!user.p.linked };
   cshStfRawWrite(h, JSON.stringify(J));
   idx.unshift(h);
   while (idx.length > CSH_STF.KEEP) cshStfRawWrite(idx.pop(), "");
   cshStfRawWrite("index", JSON.stringify(idx));
}

// ---- el modelo de una imagen ---------------------------------------------------------------------------------------------------------
// o = { noMemory: bool (ni leer ni escribir lo recordado) }
function CshStf(view, o) {
   o = o || {};
   this.view = view; this.noMemory = (o.noMemory === true);
   var img = view.image;
   this.mono = !img.isColor; this.W = img.width; this.H = img.height;
   this.key = cshStfImageKey(view); this.saved = cshStfIsSaved(view);   // saved = false: lo recordado vive solo en CSH_STF_SESSION (H-6)
   this.rawStf = null; try { this.rawStf = view.stf; } catch (e) { this.rawStf = null; }
   var mode = cshPhotoStretchMode(view);                            // "view" | "none" | "mad-linked" | "mad-unlinked" — la regla común
   this.mode = mode;
   this.linearKnown = (mode !== "view");                            // con STF en la ventana no se mira si es lineal (la regla no lo pide)
   this.linear = (mode === "mad-linked" || mode === "mad-unlinked");
   this.dec = { src: (mode === "view") ? "view" : (this.linear ? "auto" : "none"),
                why: (mode === "view") ? "window" : (this.linear ? "linear" : "nonlinear"),
                linked: (mode === "mad-unlinked") ? false : true };
   if (mode === "view") { var vr = cshViewStf(view, img.numberOfChannels); this.dec.linked = !!(vr && cshStfRowsEqualCheck(vr)); }
   this._stats = null; this.statsMs = 0;
   this.user = null;                                                // null = lo que decide la regla; { on, p } = lo que el usuario cambió
   if (!this.noMemory) { var m = cshStfLoad(this.key, !this.saved); if (m) this.user = m; }
}
function cshStfRowsEqualCheck(rows) {
   for (var c = 1; c < rows.length; ++c) { var a = rows[0], b = rows[c]; if (Math.abs(a.c0 - b.c0) > 1e-7 || Math.abs(a.m - b.m) > 1e-7 || Math.abs(a.c1 - b.c1) > 1e-7 || Math.abs(a.r0 - b.r0) > 1e-7 || Math.abs(a.r1 - b.r1) > 1e-7) return false; }
   return true;
}
CshStf.prototype.stats = function () {
   if (!this._stats) { this._stats = cshStfStats(this.view.image); this.statsMs = this._stats.ms; }
   return this._stats;
};
CshStf.prototype.state = function () {
   var d = this.dec, u = this.user, s;
   if (!u) s = { on: d.src !== "none", src: d.src, why: d.why, clip: CSH_STF.CLIP0, bkg: CSH_STF_BKG, linked: d.linked, changed: false };
   else if (u.p) s = { on: u.on, src: u.on ? "manual" : "none", why: "user", clip: u.p.clip, bkg: u.p.bkg, linked: u.p.linked, changed: true };
   else s = { on: u.on, src: u.on ? (d.src === "view" ? "view" : "auto") : "none", why: "user", clip: CSH_STF.CLIP0, bkg: CSH_STF_BKG, linked: d.linked, changed: true };
   if (this.mono) s.linked = true;
   s.mono = this.mono; s.decision = d.src; s.decisionWhy = d.why;
   return s;
};
// las 4 filas para aplicar (o null = tal cual)
CshStf.prototype.args = function () {
   var s = this.state();
   if (!s.on) return null;
   if (s.src === "view" && this.rawStf) return this.rawStf;         // el STF de la ventana, TAL CUAL (como lo ve el usuario en PixInsight)
   return cshStfDisplayArgs(cshStfRows(this.stats(), { clip: s.clip, bkg: s.bkg, linked: s.linked }));
};
CshStf.prototype._persist = function () { if (!this.noMemory) cshStfSave(this.key, this.user, !this.saved); };
CshStf.prototype.setOn = function (on) {
   this.user = { on: !!on, p: this.user ? this.user.p : null };
   this._persist();
};
CshStf.prototype.setParams = function (p, defer) {
   var s = this.state();
   this.user = { on: true, p: { clip: cshStfClamp(+p.clip, CSH_STF.CLIP_MIN, CSH_STF.CLIP_MAX), bkg: cshStfClamp(+p.bkg, CSH_STF.BKG_MIN, CSH_STF.BKG_MAX), linked: this.mono ? true : (p.linked === undefined ? s.linked : !!p.linked) } };
   if (!defer) this._persist();                                    // (mientras se arrastra no se escribe: se escribe al soltar)
};
// volver a lo automático (borra lo recordado de esta imagen)
CshStf.prototype.auto = function () { this.user = null; this._persist(); };
CshStf.prototype.render = function () { return cshStfRender(this.view.image, this.args()); };
#endif
