// ============================================================================
// CabraShared/help/csh_help.js — EL BOTON DE AYUDA «?» DE LOS SCRIPTS CabraSpace (2-nov-2026)
// ----------------------------------------------------------------------------
// Abre la ayuda PIDoc del script (la que compila tools/help/build_help.js) en el idioma de la interfaz.
// Ids: inglés = <NombrePublico> (FieldDepth3D), castellano = <NombrePublico>_es (FieldDepth3D_es).
//
// QUÉ ABRE, en este orden (el primero que exista):
//   1. la instalada en PixInsight, idioma vigente:  <PXI_DOCDIR>/scripts/<Id>/<Id>.html
//   2. la instalada, el otro idioma
//   3. la compilada en el repositorio, idioma vigente:  <repo>/_help/scripts/<Id>/<Id>.html
//   4. la compilada, el otro idioma
//   Ninguna: aviso en la consola (nunca un MessageBox: en pruebas colgaría la instancia).
// CÓMO LO ABRE (17-nov-2026; antes: las instaladas en el visor de PixInsight y las compiladas con rundll32.exe FIJO de Windows, que en
// macOS y Linux no existe): UNA sola vía para las cuatro, la misma en Windows, macOS y Linux —
//   a) el navegador que trae PixInsight: Dialog.openBrowser(ruta, título) (modal; acepta una ruta local, doc/pjsr/objects/Dialog, 1.9.6;
//      medido el 3-nov que pinta la ayuda local entera). No lanza ningún programa externo (reglas CPD 5.3/6.1). No se usa
//      Dialog.browseScriptDocumentation(Id): busca por el nombre REGISTRADO en el menú Script, y «FieldDepth3D_es» no es un script.
//   b) la RESERVA, si no hay Dialog.openBrowser, si lanza una excepción o con CSH_WEB_BREAK = "system": el navegador del sistema de la
//      plataforma, sin shell (programa + lista de argumentos), el de CabraShared/csh_web.js (cshSystemBrowser, que este fichero incluye):
//      Windows rundll32.exe url.dll,FileProtocolHandler <ruta de Windows con barras invertidas> (la URL file:/// con «%C3%B1» no abre
//      nada: medido el 2-nov) · macOS /usr/bin/open <ruta> · Linux xdg-open <ruta>. La plataforma sale de CoreApplication.platform.
//
// API
//   cshHelpCandidates(name, opt) → [{ id, lang, where: "installed"|"local", path }] en el orden de arriba
//   cshHelpResolve(name, opt)    → el primero que existe, o null
//   cshHelpOpen(name, opt)       → { ok, via: "pixinsight"|"browser"|"logged:…"|"hook:…"|"none", path, id, why, platform, arg, exe, args }
//        (exe/args: lo que se lanza si la vía es el navegador del sistema; con hook, lo que se lanzaría)
//   cshHelpButton(parent, name, opt) → PushButton con el icono «?» dorado; btn.cshHelpRetranslate() repone el tooltip
// opt (todo opcional): es (forzar idioma) · docDir (otra carpeta doc de PixInsight) · repo (otra raíz del repositorio)
//   · matchHeightOf (botón de texto de la misma fila: el «?» toma su alto) · exists(path) (pruebas) · hook(entry) (lo recoge en vez de abrir) · noMain (prueba: NO abre, solo apunta en
//   CSH_HELP_LOG) · style(btn) (estilo del botón; por defecto cpStyleToggle si existe) · title (título de la ventana)
//   · system (true: va directo al navegador del sistema) · platform ("windows"|"macos"|"linux": simula la plataforma; pruebas).
// Incluye CabraShared/csh_web.js (con guarda: si el script ya lo incluía no se duplica) y NO necesita csh_net.js.
// Requiere (si están): cshLangIsEs (csh_i18n.js), cpStyleToggle/cpPx/CP_ATLAS o CSH_ATLAS, cpWrapTooltip.
// ES5. OJO: ninguna barra-asterisco en comentarios (el preprocesador de PJSR se come el resto del fichero).
// ============================================================================

#include "../csh_web.js"      // cshSystemBrowser / cshWebRoute / cshWebPlatform (la reserva del sistema, igual en todos los scripts)

var CSH_HELP_LOG = [];
var CSH_HELP_HERE = (File.extractDrive(#__FILE__) + File.extractDirectory(#__FILE__)).split("\\").join("/") + "/";   // .../CabraShared/help/
var CSH_HELP_TIP = {
   en: "Help: open the %s documentation (installed in PixInsight, or the local build in the browser).",
   es: "Ayuda: abre la documentación de %s (la instalada en PixInsight o, si no, la compilada en el navegador)."
};

function cshHelpRepo(opt) {
   if (opt && typeof opt.repo === "string" && opt.repo.length) return opt.repo.split("\\").join("/").replace(/\/?$/, "/");
   var r = CSH_HELP_HERE + "../../";
   try { r = File.fullPath(r).split("\\").join("/").replace(/\/?$/, "/"); } catch (e) {}
   return r;
}
function cshHelpDocDir(opt) {
   if (opt && typeof opt.docDir === "string") return opt.docDir.split("\\").join("/").replace(/\/$/, "");
   var d = "";
   try { d = String(System.getEnvironmentVariable("PXI_DOCDIR") || ""); } catch (e) {}
   return d.trim().split("\\").join("/").replace(/\/$/, "");
}
function cshHelpIsEs(opt) {
   if (opt && typeof opt.es === "boolean") return opt.es;
   try { if (typeof cshLangIsEs === "function") return cshLangIsEs(); } catch (e) {}
   return false;
}

function cshHelpCandidates(name, opt) {
   var o = opt || {}, es = cshHelpIsEs(o);
   var ids = es ? [{ id: name + "_es", lang: "es" }, { id: name, lang: "en" }] : [{ id: name, lang: "en" }, { id: name + "_es", lang: "es" }];
   var out = [], doc = cshHelpDocDir(o), repo = cshHelpRepo(o), i;
   if (doc.length) for (i = 0; i < ids.length; ++i) out.push({ id: ids[i].id, lang: ids[i].lang, where: "installed", path: doc + "/scripts/" + ids[i].id + "/" + ids[i].id + ".html" });
   for (i = 0; i < ids.length; ++i) out.push({ id: ids[i].id, lang: ids[i].lang, where: "local", path: repo + "_help/scripts/" + ids[i].id + "/" + ids[i].id + ".html" });
   return out;
}
function cshHelpResolve(name, opt) {
   var o = opt || {}, c = cshHelpCandidates(name, o);
   for (var i = 0; i < c.length; ++i) {
      var ex = false;
      try { ex = (typeof o.exists === "function") ? !!o.exists(c[i].path) : File.exists(c[i].path); } catch (e) { ex = false; }
      if (ex) return c[i];
   }
   return null;
}

// file:///C:/... con los caracteres que lo necesitan codificados (espacios de «Program Files», acentos)
function cshHelpFileUrl(path) {
   var p = String(path).split("\\").join("/");
   var parts = p.split("/");
   for (var i = 0; i < parts.length; ++i) if (!(i === 0 && /^[A-Za-z]:$/.test(parts[i]))) parts[i] = encodeURIComponent(parts[i]);
   return "file:///" + parts.join("/");
}
function cshHelpOpen(name, opt) {
   var o = opt || {}, out = { ok: false, via: "none", path: "", id: "", why: "" };
   var c = cshHelpResolve(name, o);
   if (!c) {
      out.why = "no help found for " + name + " (neither installed in PixInsight nor built in _help/; run tools/help/build_help.js)";
      try { console.warningln("<end><cbr>** " + name + " help: " + out.why); } catch (eC) {}
      CSH_HELP_LOG.push(out);
      return out;
   }
   out.path = c.path; out.id = c.id; out.where = c.where; out.lang = c.lang;
   // la vía: el navegador de PixInsight (la misma en las tres plataformas) o, sin él, el del sistema (csh_web.js: cshWebRoute)
   var route = cshWebRoute({ system: o.system === true });
   out.via = (route === "pixinsight") ? "pixinsight" : "browser";
   if (c.where === "local") out.url = cshHelpFileUrl(c.path);
   // lo que lanzaría el navegador del sistema (la reserva, y la vía si es la del sistema). SIN shell: un programa y UN argumento (la ruta
   // tal cual: con espacios o «ñ» no hay nada que citar). En Windows la RUTA con barras invertidas, NO la URL file:///: con «%C3%B1» (ñ)
   // FileProtocolHandler no abre nada (medido el 2-nov con baliza: la URL codificada no llega; la ruta con ñ y espacios, sí)
   var pf = (typeof o.platform === "string" && o.platform.length) ? o.platform : cshWebPlatform();
   out.platform = pf;
   out.arg = (pf === "windows") ? c.path.split("/").join("\\") : c.path;
   var sb = cshSystemBrowser(out.arg, { platform: pf, exists: o.exists, dry: true });
   if (route === "system") { out.exe = sb.exe; out.args = sb.args; }
   if (typeof o.hook === "function") { try { o.hook(out); out.ok = true; } catch (eH) { out.why = String(eH); } out.via = "hook:" + out.via; CSH_HELP_LOG.push(out); return out; }
   var noMain = (o.noMain === true) || (o.noMain !== false && typeof CP_NO_MAIN !== "undefined" && !!CP_NO_MAIN);
   if (noMain) { out.ok = true; out.via = "logged:" + out.via; CSH_HELP_LOG.push(out); return out; }
   try {
      if (route === "pixinsight") {
         try {
            Dialog.openBrowser(c.path, (typeof o.title === "string" && o.title.length) ? o.title : (name + " — CabraSpace"));
            out.ok = true;
         } catch (eB) { out.why = "Dialog.openBrowser: " + String((eB && eB.message) ? eB.message : eB); route = "system"; out.via = "browser"; }
      }
      if (route === "system") {
         var r = cshSystemBrowser(out.arg, { platform: pf, exists: o.exists });      // (las mismas opciones que arriba: lo dicho es lo lanzado)
         out.ok = r.ok; out.exe = r.exe; out.args = r.args;
         if (!r.ok) out.why = (out.why ? out.why + " · " : "") + (r.why || "startDetached returned false");
         else out.why = "";
      }
   } catch (e) { out.ok = false; out.why = String((e && e.message) ? e.message : e); }
   if (!out.ok) { try { console.warningln("<end><cbr>** " + name + " help: could not open " + out.path + ": " + out.why); } catch (eW) {} }
   CSH_HELP_LOG.push(out);
   return out;
}

// EL ICONO: un «?» dentro de un círculo, trazo del oro de Atlas. Lado space[2] = 12 px lógicos a la escala de la interfaz (18 px a 1,5):
// con 16 (el de pantalla completa) el botón salía 44x32 frente a 35x28 de «ES»/«Cerrar» (medido, tests/c3_shot_help.js H1).
function cshHelpIcon(control) {
   var A = (typeof CP_ATLAS !== "undefined") ? CP_ATLAS : ((typeof CSH_ATLAS !== "undefined") ? CSH_ATLAS : { gold: "#E5B53F", space: [4, 8, 12, 16] });
   var px = 18;
   try { px = Math.max(10, (typeof cpPx === "function") ? cpPx(A.space[2], control) : Math.round(A.space[2] * 1.5)); } catch (eP) {}
   var key = "help_" + px, cache = cshHelpIcon.cache || (cshHelpIcon.cache = {});
   if (cache[key] !== undefined) return cache[key];
   try {
      var dir = File.systemTempDirectory.split("\\").join("/") + "/CabraHelpAtlas";
      if (!File.directoryExists(dir)) File.createDirectory(dir, true);
      var f = dir + "/" + key + ".svg";
      File.writeTextFile(f, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + px + "\" height=\"" + px + "\" viewBox=\"0 0 24 24\">" +
         "<circle cx=\"12\" cy=\"12\" r=\"9.5\" fill=\"none\" stroke=\"" + A.gold + "\" stroke-width=\"2\"/>" +
         "<path d=\"M9.1 9.3a3 3 0 1 1 4.3 2.7c-0.9 0.45-1.4 1.1-1.4 2.1v0.6\" fill=\"none\" stroke=\"" + A.gold + "\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>" +
         "<circle cx=\"12\" cy=\"17.6\" r=\"1.3\" fill=\"" + A.gold + "\"/></svg>");
      cache[key] = new Bitmap(f);
   } catch (e) { cache[key] = null; }
   return cache[key];
}

function cshHelpButton(parent, name, opt) {
   var o = opt || {};
   var b = new PushButton(parent);
   b.text = "";
   var ic = cshHelpIcon(b);
   if (ic) { b.icon = ic; try { b.iconWidth = ic.width; b.iconHeight = ic.height; } catch (eIc) {} } else b.text = "?";
   try {
      if (typeof o.style === "function") o.style(b);
      else if (typeof cpStyleToggle === "function") cpStyleToggle(b, false);
   } catch (eS) {}
   // Un PushButton solo con icono pide más alto que uno con texto (44x32 frente a 35x28 de «ES», medido): con matchHeightOf
   // (un botón de texto de la misma fila) se le fija ese alto y un ancho de 1,25 veces, para que la fila quede pareja.
   if (o.matchHeightOf) {
      try {
         var m = o.matchHeightOf; if (!m.text || String(m.text).length === 0) m.text = "Xg";
         m.adjustToContents(); var h = m.height;
         if (h > 0) b.setFixedSize(Math.round(h * 1.25), h);
      } catch (eM) {}
   }
   b.cshHelpName = name;
   b.cshHelpRetranslate = function() {
      var t = (cshHelpIsEs(o) ? CSH_HELP_TIP.es : CSH_HELP_TIP.en).replace("%s", name);
      try { this.toolTip = (typeof cpWrapTooltip === "function") ? cpWrapTooltip(t) : ((typeof cshTipWrap === "function") ? cshTipWrap(t) : t); } catch (eT) { this.toolTip = t; }      // (5-nov: sin cpWrapTooltip —StellarChemistry— el comun de csh_i18n.js)
   };
   b.cshHelpRetranslate();
   b.onClick = function() { b.cshHelpLast = cshHelpOpen(name, o); };
   return b;
}
