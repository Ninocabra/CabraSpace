// ============================================================================
// host/host.js — EL ANFITRION: lo que en CabraPilot ponia el programa entero y
// aqui pone Cabra3D, mas sencillo (14-oct-2026)
// ----------------------------------------------------------------------------
// Los modulos de starfield copiados de CabraPilot (src/engine, src/ui) llaman a un
// puñado de funciones del resto de CabraPilot. Lo que se pudo copiar tal cual esta
// en host/host_copied.js; aqui van las que alli arrastraban medio programa, con la
// MISMA firma y una version minima (anotado en cada una que hacia alli y que hace
// aqui). Cabra3D no depende de CabraPilot en tiempo de ejecucion.
// ES5.
// ============================================================================

// --- constantes del programa -------------------------------------------------
var CP_SETTINGS_PREFIX = "Cabra3D";
var CP_GLOBAL = (typeof globalSelf !== "undefined") ? globalSelf : ((typeof globalThis !== "undefined") ? globalThis : this);
var OPT_MOUSE_LEFT  = (typeof MouseButton_Left  !== "undefined") ? MouseButton_Left  : 0x01;
var OPT_MOUSE_RIGHT = (typeof MouseButton_Right !== "undefined") ? MouseButton_Right : 0x02;
// (V8: Image.free / Bitmap.clear existen por instancia; la red de CabraPilot, por si no)
if (typeof Image.prototype.free === "undefined") Image.prototype.free = function() {};
if (typeof Bitmap.prototype.clear === "undefined") Bitmap.prototype.clear = function() {};

// processEvents portable (CabraPilot.js)
function optProcessEvents() {
   if (typeof CSH_PAINTING === "number" && CSH_PAINTING > 0) return;      // (26-oct-2026: nunca con un pintado abierto; CabraShared/csh_net.js, CSH_PAINTING)
   try { if (typeof CoreApplication !== "undefined" && typeof CoreApplication["processEvents"] === "function") { CoreApplication["processEvents"](); return; } } catch (e0) {}
   try { if (typeof processEvents === "function") { processEvents(); return; } } catch (e1) {}
}

// --- el idioma (CabraPilot.js / CabraPilot_resources.jsh, mismo mecanismo) ---
var CP_LANG = "en";
var CP_LANGUAGES = [
   { code: "en", tooltips: C3_TOOLTIPS_EN, strings: null },
   { code: "es", tooltips: C3_TOOLTIPS_ES, strings: C3_I18N_ES }
];
function cpLangEntry() {
   for (var i = 0; i < CP_LANGUAGES.length; ++i) if (CP_LANGUAGES[i].code === CP_LANG) return CP_LANGUAGES[i];
   return CP_LANGUAGES[0];
}
function cpLoadLang() {
   try {
      var v = Settings.read(CP_SETTINGS_PREFIX + "/lang", DataType_String);
      for (var i = 0; i < CP_LANGUAGES.length; ++i) if (CP_LANGUAGES[i].code === v) { CP_LANG = v; break; }
   } catch (e) {}
}
function cpSaveLang() { if (CP_NO_MAIN) return; try { Settings.write(CP_SETTINGS_PREFIX + "/lang", DataType_String, CP_LANG); } catch (e) {} }
function optT(s) {
   try {
      var L = cpLangEntry();
      if (L && L.strings && Object.prototype.hasOwnProperty.call(L.strings, s) && L.strings[s]) return L.strings[s];
   } catch (e) {}
   return s;
}
function cpTooltipText(key) {
   var L = cpLangEntry();
   if (L.tooltips && Object.prototype.hasOwnProperty.call(L.tooltips, key) && L.tooltips[key]) return L.tooltips[key];
   if (Object.prototype.hasOwnProperty.call(C3_TOOLTIPS_EN, key)) return C3_TOOLTIPS_EN[key];
   return "";
}

// --- la «zona tranquila» y el trabajo de fondo (engine/inherited.js) ---------
// Alli protegian de ejecutar procesos mientras otro dialogo de CabraPilot medía; aqui
// no hay nada que proteger: Cabra3D no aplica procesos a la imagen del usuario.
function cpQuiet() { return false; }
// UN PROCESO EN MARCHA (20-oct-2026, fallo de Nino: «Access violation … QRasterPaintEngine::drawImage» al repintarse una cabecera
// de grupo dentro del bucle de eventos de HistogramTransformation). Todo proceso que Cabra3D lanza con el dialogo en pantalla
// pasa por `c3ProcRun`: mientras corre, `c3ProcBusy()` es verdadero y las cabeceras de grupo no pintan (ui/groups.js). Al terminar
// se repintan una vez. No es `cpQuiet()` a proposito: ese afecta tambien al lienzo 3D y a los temporizadores, que no necesitan
// callar (y un lienzo que se salta un pintado queda en blanco hasta el siguiente).
var C3_PROC_DEPTH = 0;
function c3ProcBusy() { return C3_PROC_DEPTH > 0; }
function c3ProcRun(fn) {
   ++C3_PROC_DEPTH;
   try { return fn(); }
   finally {
      --C3_PROC_DEPTH;
      if (C3_PROC_DEPTH === 0) { try { if (typeof c3GroupsRepaintAll === "function") c3GroupsRepaintAll(); } catch (eR) {} }
   }
}
function cpBackgroundRun(fn) { return fn(); }

// --- la identidad del contenido de una imagen (engine/image_manager.js) ------
// Alli llevaba el historial de CabraPilot; aqui, el del propio PixInsight.
var CP_CONTENT_EPOCH = 0;
function cpHistoryIndex(view) { try { return view.historyIndex; } catch (e) { return 0; } }
function cpViewContentToken(viewId) { return 0; }

// ¿LINEAL? y el STF: comunes de la familia (../CabraShared/csh_astrometry.js y csh_stf.js: cpViewIsLinear, cshMtf, CshStf…). (17-nov-2026) Aqui estaba c3Mtf, copia
// de la funcion de medios tonos: fuera, es cshMtf. cpHasAstrometricSolution tambien viene de csh_astrometry.js.

// ¿BANDA ESTRECHA? (engine/color.js: alli lo elegido en COLOR, el historial o el nombre). Aqui: el nombre de la vista y las
// palabras clave FILTER, con las mismas pistas (Ha, OIII, SII, HOO, SHO, palette). Devuelve { mode, palette }.
function cpColorModeResolve(view) {
   var txt = "";
   try { txt += " " + String(view.id); } catch (e0) {}
   try { var kw = view.window.keywords; for (var i = 0; i < kw.length; ++i) if (/^FILTER/i.test(kw[i].name)) txt += " " + String(kw[i].strippedValue || kw[i].value); } catch (e1) {}
   var s = txt.toUpperCase(), pal = "";
   if (/\bSHO\b/.test(s)) pal = "SHO"; else if (/\bHOO\b/.test(s)) pal = "HOO"; else if (/\bHSO\b/.test(s)) pal = "HSO";
   else if (/(H[-_ ]?A(LPHA)?\b|\bOIII\b|\bO3\b|\bSII\b|\bS2\b)/.test(s) && /(OIII|O3|SII|S2)/.test(s)) pal = "NB";
   return { mode: pal.length ? "nb-rgb" : "bb-rgb", palette: pal };
}

// --- ¿RESUELTA? (engine/astrometry.js, copiada tal cual) ---------------------

// (6-nov-2026, revision PTeam CPD) Aqui estaba cpSurveyHttpGet (con cpSurveyNetLogTally y cpSurveyNetLogRecord vacias): nadie la
// llamaba (grep). La red de verdad va por ../CabraShared/csh_net.js.

// --- PINTAR UNA IMAGEN (engine/inherited.js: alli con Auto GHS, STF propio por imagen, mascaras…) ----------------------
// ESTIRADO DE LA FOTO (17-nov-2026, decision 14B de Nino: el STF comun de la familia). `stf` es el MODELO de la imagen (CshStf, csh_stf.js: lo decide al abrir —el STF de la ventana
// manda; lineal, estirado automatico; no lineal, tal cual— y recuerda lo que el usuario cambia con el boton STF, ui/photo_stf.js) y su `args()` son las cuatro filas del STF
// (o null = tal cual). El estirado se aplica a una COPIA con Image.applyDisplayFunction (nativo, sin proceso ni ventana temporal: antes HistogramTransformation en una ventana
// oculta): la imagen del usuario no se toca nunca. CabraStarAnalysis, que comparte este fichero, aun pasa una CADENA ("none" | "mad-linked" | "mad-unlinked" | "view"): se traduce a
// las mismas filas del modelo comun (el STF de la vista manda siempre, como antes; el automatico, al fondo CSH_STF_BKG y sombras -2,8 MAD).
var OPT_RENDER_MAX_REDUCTION = 64;
function optRenderDirect(image, reduction, opaque) {
   var n = Math.max(1, Math.min(OPT_RENDER_MAX_REDUCTION, Math.floor(reduction)));
   return image.render(n > 1 ? -n : 1, opaque !== true, false);
}
// las 4 filas [m, c0, c1, r0, r1] (R, G, B, L) que pide `stf` para esta vista, o null = tal cual
function optStfArgs(view, stf) {
   var img = view.image, nc = img.numberOfChannels;
   if (stf && typeof stf === "object" && typeof stf.args === "function") return stf.args();
   var vs = null;
   try { vs = cshViewStf(view, nc); } catch (eV) { vs = null; }
   if (vs) return cshStfDisplayArgs(vs);
   if (stf !== "mad-linked" && stf !== "mad-unlinked") return null;
   return cshStfDisplayArgs(cshStfRows(cshStfStats(img), { clip: CSH_STF.CLIP0, bkg: CSH_STF_BKG, linked: (stf === "mad-linked") }));
}
function optRenderPreviewBitmap(view, reductionFactor, stf) {
   if (!optSafeView(view) || !view.image) return null;
   var n = Math.max(1, Math.min(OPT_RENDER_MAX_REDUCTION, Math.floor(reductionFactor || 1))), args = null;
   try { args = optStfArgs(view, stf); } catch (eA) { args = null; try { console.warningln("Cabra3D: STF — " + (eA.message || eA)); } catch (eW0) {} }
   if (!args || CSH_STF.BREAK === "noapply") return optRenderDirect(view.image, n);
   var work = null;
   try {
      work = new Image(view.image);
      work.resetSelections();
      work.applyDisplayFunction(args);
      return optRenderDirect(work, n);
   } catch (e) {
      try { console.warningln("Cabra3D: render — " + (e.message || e)); } catch (eW) {}
      return optRenderDirect(view.image, n);
   } finally {
      try { if (work) work.free(); } catch (eC) {}
   }
}

// --- QUITAR ESTRELLAS (engine/starless.js: alli una tabla de motores con todos sus parametros) -----------------------
// Lo unico que usa la capa de nebulosas: StarXTerminator o StarNet2, sin imagen de estrellas.
var CP_STAR_IMAGE_NONE = 0, CP_STAR_IMAGE_SUBTRACT = 1, CP_STAR_IMAGE_UNSCREEN = 2;
function cpStarAvailableEngines() {
   var out = [];
   if (cpProcessAvailable("StarXTerminator")) out.push({ id: "SXT", process: "StarXTerminator", label: "StarXTerminator" });
   if (cpProcessAvailable("StarNet2")) out.push({ id: "SN2", process: "StarNet2", label: "StarNet2" });
   return out;
}
function cpStarDefaults(engine) { return { starsImage: CP_STAR_IMAGE_NONE, linear: 0 }; }
function c3SetParam(P, names, value) {
   for (var i = 0; i < names.length; ++i) { try { if (names[i] in P) { P[names[i]] = value; return true; } } catch (e) {} }
   return false;
}
function cpStarRunOnView(engineId, values, view) {
   var v = values || {}, P = null;
   try {
      if (engineId === "SXT") { P = new StarXTerminator; c3SetParam(P, ["stars", "output_stars"], false); c3SetParam(P, ["unscreen", "unscreen_stars"], false); }
      else if (engineId === "SN2") { P = new StarNet2; c3SetParam(P, ["mask"], false); c3SetParam(P, ["unscreen"], false); if (v.linear === 2) c3SetParam(P, ["linear"], false); }
      else return { ok: false, message: "unknown star removal engine: " + engineId };
      var ok = c3ProcRun(function() { return P.executeOn(view); });
      return { ok: ok !== false, message: (ok === false) ? engineId + " did not finish" : "" };
   } catch (e) { return { ok: false, message: String(e.message || e) }; }
}

// Los datos PROPIOS de Cabra3D (constelaciones, curva de extincion): src/data/. Los del motor comun (cumulos, secuencia
// principal, nebulosas, Babusiaux 2018) estan en ../CabraShared/data/ (cpSfDataDir).
var C3_FILE = #__FILE__;
function c3DataDir() {
   var here = (File.extractDrive(C3_FILE) + File.extractDirectory(C3_FILE)).split("\\").join("/");
   return here.substring(0, here.lastIndexOf("/")) + "/data/";
}
