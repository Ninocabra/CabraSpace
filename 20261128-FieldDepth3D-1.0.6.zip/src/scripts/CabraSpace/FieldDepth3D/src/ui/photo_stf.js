// ============================================================================
// ui/photo_stf.js — EL ESTIRADO DE LA FOTO: el STF COMUN de la familia en Cabra3D (17-nov-2026, decision 14B de Nino)
// ----------------------------------------------------------------------------
// Nino (17-nov): «Cuando cojo una imagen no lineal, aplica un stretch y queda rara. Haz una opcion para poner y quitar stretch tipo STF y regularlo. Detecta si una imagen
// es lineal o no y aplicalo de forma automatica, siempre dejando la opcion de cambiarlo en manual… comun a todos.» Plan: SurveyLens/tests/ESTIRADO_STF.md §9 punto 2.
//   · EL MODELO (CabraShared/csh_stf.js, CshStf): uno por imagen, creado al elegirla (`selectImage`). Decide al abrir —el STF de la ventana manda; lineal → estirado automatico
//     (fondo CSH_STF_BKG 0,12); no lineal → tal cual— y recuerda por imagen lo que el usuario cambia. Es la UNICA fuente del estirado: la foto del visor (`photo_view.js`), la foto
//     grande del 3D y del video (`_renderFull`, starfield_panel.js) y sus recortes salen de `model.args()` (host.js `optRenderPreviewBitmap`). Cero rama propia: se acabo
//     c3Mtf, c3AutoStf y el HistogramTransformation en una ventana temporal.
//   · EL BOTON (CabraShared/csh_stf_panel.js, CshStfControl): DENTRO del visor de la foto, arriba a la derecha, pegado A LA IZQUIERDA del conmutador «Real photo | Stars»
//     (ui/photo_overlay_toggle.js) y centrado con el en vertical. Pone / quita el estirado; la flecha abre el panel (intensidad, sombras, Enlazado, Auto), que flota bajo el
//     boton sobre la foto. No cambia el tamano del visor: ni el encuadre ni el zoom se mueven al estirar (`C3PhotoView.restretch` solo cambia los pixeles del bitmap).
//   · AL ESTIRAR: mientras se arrastra un mando («live») solo se repinta la foto del visor; al soltar, o con un clic en el boton («commit» / «click»), ademas se rehace lo que
//     sale de los pixeles de la foto en el panel 3D (`CPStarfieldDock.c3PhotoRestretched`): la copia pequena, la grande —la del video—, su piramide, los recortes de los objetos,
//     los sprites de las estrellas, la foto sin estrellas y la foto de detras. Las medidas (estrellas, distancias) no dependen del estirado y se conservan.
// CabraStarAnalysis comparte host.js, photo_view.js y starfield_panel.js con este script pero NO este fichero: sigue pasando una cadena de modo a `optRenderPreviewBitmap`.
// ES5 salvo lo que trae csh_stf_panel.js (clases de widget).
// ============================================================================

var C3_STF_UI = { H: 22, R: 11, GAP: 6, PANEL_GAP: 6, MARGIN: 6 };
var C3_STF_NOBTN = false;            // la costura del rojo: sin el boton (el modelo y el estirado siguen)
var C3_STF_CORNERS = true;           // el boton con las esquinas TRANSPARENTES (false = el rojo: el cuadrado de fondo asoma por las esquinas redondeadas, como en SurveyLens)

// --- el modelo de la imagen ---------------------------------------------------------------------------------------------------------------
// Crea el modelo de la imagen elegida (y se lo da al boton). rec = null: sin imagen, el boton queda apagado.
C3MainDialog.prototype._stfSelect = function(rec) {
   var model = null;
   try { if (this.stf) this.stf.closePanel(); } catch (eC) {}
   if (rec && optSafeView(rec.view)) {
      try { model = new CshStf(rec.view); }
      catch (e) { model = null; try { console.warningln("Cabra3D: STF — " + (e.message || e)); } catch (eW) {} }
   }
   this._stfCur = model ? { id: rec.id, model: model } : null;
   try { if (this.stf) this.stf.setModel(model); } catch (eM) {}
   return model;
};
// (el nombre viene de cuando era una cadena; `optRenderPreviewBitmap` acepta las dos —starfield_panel.js, que comparte CabraStarAnalysis, lo sigue llamando asi—.) Devuelve el MODELO
// de estirado de la imagen: el de la elegida si es ella; si no (el 3D de otra imagen), uno nuevo para esa, con lo recordado.
C3MainDialog.prototype.stretchModeForRec = function(rec) {
   if (!rec || !optSafeView(rec.view)) return null;
   var cur = this._stfCur;
   if (cur && cur.id === rec.id) return cur.model;
   try { return new CshStf(rec.view); } catch (e) { return null; }
};

// --- el boton, en el visor ------------------------------------------------------------------------------------------------------------------
C3MainDialog.prototype._stfBuild = function() {
   if (C3_STF_NOBTN === true) { this.stf = null; return; }
   var self = this, vp = this.preview.viewport;
   this.stf = new CshStfControl({
      parent: vp, panelParent: vp, h: C3_STF_UI.H, r: C3_STF_UI.R,
      place: function(panel, button) { return self._stfPanelPos(panel, button); },
      onApply: function(model, st, phase) { self._stfApply(model, st, phase); }
   });
   this.stfButton = this.stf.button;
   // (sin esto el visor, que lleva «border: 1px solid» sin selector, le pasa su marco al boton y al panel: el mismo caso que las pildoras, csh_pills.js)
   try { this.stf.button.styleSheet = "background: transparent; border: none;"; } catch (e0) {}
   try { this.stf.panel.styleSheet = "background: transparent; border: none;"; } catch (e1) {}
   // LAS ESQUINAS: el boton comun se pinta sobre una barra, con un rectangulo de fondo detras; aqui va SOBRE LA FOTO y ese fondo asomaba como cuatro esquinas cuadradas oscuras
   // (visto el 17-nov en tests/c3_stf_ui.js). Se pinta el boton en un Bitmap y se tiran las esquinas de fuera del arco (alfa 0) antes de ponerlo: lo de detras, a traves.
   var btn = this.stf.button;
   btn.onPaint = function() {
      if (C3_STF_CORNERS !== true) { var g0 = new Graphics(btn); try { btn.paintBtn(g0); } finally { g0.end(); } return; }
      var W = btn.width, H = btn.height, bmp = new Bitmap(W, H);
      bmp.fill(0x00000000);
      var g2 = new Graphics(bmp); try { btn.paintBtn(g2); } finally { g2.end(); }
      c3StfRoundCorners(bmp, btn.rAbs * cshStfScaleOf(btn));
      var g = new Graphics(btn); try { g.drawBitmap(0, 0, bmp); } finally { g.end(); }
      bmp.clear();
   };
   var prevResize = vp.onResize;
   vp.onResize = function() { if (typeof prevResize === "function") prevResize.apply(vp, arguments); try { self._stfPlace(); } catch (eP) {} };
   this._stfPlace();
};
// alfa 0 fuera del arco de cada esquina (radio r en px fisicos, el trazo de 1 px va en r ± 0,5) y un filo de 1 px de transicion
function c3StfRoundCorners(bmp, r) {
   var W = bmp.width, H = bmp.height, R = Math.min(Math.ceil(r) + 1, W >> 1, H >> 1), x, y, i;
   for (i = 0; i < 4; ++i) {
      var right = (i & 1) === 1, bottom = (i & 2) === 2, cx = right ? W - 0.5 - r : 0.5 + r, cy = bottom ? H - 0.5 - r : 0.5 + r;
      for (y = 0; y < R; ++y) for (x = 0; x < R; ++x) {
         var px = right ? W - 1 - x : x, py = bottom ? H - 1 - y : y, dx = (px + 0.5) - cx, dy = (py + 0.5) - cy;
         if (!(right ? dx > 0 : dx < 0) || !(bottom ? dy > 0 : dy < 0)) continue;       // (solo el cuarto de circulo de la esquina; el resto del borde es recto)
         var d = Math.sqrt(dx * dx + dy * dy), a = (d <= r + 0.5) ? 1 : Math.max(0, 1 - (d - (r + 0.5)));
         if (a >= 1) continue;
         var c = bmp.pixel(px, py) >>> 0, al = Math.round(((c >>> 24) & 255) * a);
         bmp.setPixel(px, py, ((al << 24) | (c & 0xffffff)) >>> 0);
      }
   }
}
// pegado a la izquierda del conmutador de las estrellas, centrado con el en vertical
C3MainDialog.prototype._stfPlace = function() {
   var b = this.stf ? this.stf.button : null, o = this.ovToggle, vp = this.preview.viewport;
   if (!b || !o) return;
   try { if (this.ovSw) this.ovSw.place(); } catch (eO) {}
   var sc = cpUiScale(vp), x = o.position.x - Math.round(C3_STF_UI.GAP * sc) - b.width, y = o.position.y + Math.round((o.height - b.height) / 2);
   x = Math.max(0, x); y = Math.max(0, y);
   try { var p = b.position; if (!p || p.x !== x || p.y !== y) b.position = new Point(x, y); } catch (e) { try { b.position = new Point(x, y); } catch (e2) {} }
   try { if (this.stf.panelOpen) { var pos = this._stfPanelPos(this.stf.panel, b); this.stf.panel.place(pos.x, pos.y); } } catch (eQ) {}
};
// el panel flota sobre la foto, justo debajo del boton y alineado con su borde derecho (sin salirse del visor)
C3MainDialog.prototype._stfPanelPos = function(panel, button) {
   var vp = this.preview.viewport, sc = cpUiScale(vp), w = Math.round(CSH_STFUI.W * sc), m = Math.round(C3_STF_UI.MARGIN * sc);
   var x = button.position.x + button.width - w;
   x = Math.max(m, Math.min(x, vp.width - w - m));
   return { x: x, y: button.position.y + button.height + Math.round(C3_STF_UI.PANEL_GAP * sc) };
};
// el modelo cambio (boton, deslizador, Auto): la foto del visor se repinta; al soltar, ademas lo que sale de ella en el panel 3D
C3MainDialog.prototype._stfApply = function(model, st, phase) {
   var cur = this._stfCur;
   if (!cur || cur.model !== model || !this.currentRec) return;
   this.preview.restretch(model);
   if (phase !== "live") { try { this.starfieldDock.c3PhotoRestretched(this.currentRec); } catch (e) { try { console.warningln("Cabra3D: STF en el 3D — " + (e.message || e)); } catch (eW) {} } }
};

// --- el visor: cambiar solo los pixeles de la foto (el encuadre, el zoom y el tamano no se tocan) ------------------------------------------------
C3PhotoView.prototype.restretch = function(stf) {
   if (!this.view || !this.bitmap || !optSafeView(this.view)) return false;
   var old = this.bitmap, b = optRenderPreviewBitmap(this.view, this.reduction || 1, stf);
   if (!b) return false;
   if (b.width !== old.width || b.height !== old.height) { cpSfUiFree(b); return false; }     // (mismo tamano o nada: lo demas del visor cuenta con el)
   this.bitmap = b;
   cpSfUiFree(old);
   try { this.viewport.repaint(); } catch (e) {}
   return true;
};

// --- el panel 3D: lo que sale de los pixeles de la foto se rehace ------------------------------------------------------------------------------------
// `rec` = la imagen elegida. Si el panel tiene esa imagen en su memoria (abierta o no), se invalida lo derivado de sus pixeles; si esta ABIERTA se rehace ya (la foto grande, que
// es la del video, y los sprites de las estrellas) y se repinta; si no, `open()` las rehace al abrirla (`if (!st.photoFull)`).
CPStarfieldDock.prototype.c3PhotoRestretched = function(rec) {
   if (!rec || !optSafeView(rec.view)) return false;
   var st = this._find(cpSfUiKey(rec.view));
   if (!st) return false;
   // la foto sin estrellas del tiempo puede ser LA MISMA del bitmap de las nebulosas: se libera una vez
   var sl = st.starless ? st.starless.bmp : null;
   if (st.tmStarless && st.tmStarless !== sl) cpSfUiFree(st.tmStarless);
   st.tmStarless = undefined; st.tmStarlessHow = undefined; st.tmStarlessKind = undefined; st.tmStarlessMs = undefined;
   this._freeFull(st);                                         // la grande y su piramide
   if (st.ps) this._psFreeBitmaps(st.ps);                      // los sprites de las estrellas (la medida se queda: no depende del estirado)
   var sets = [st.cuts || {}, st.cutsHi || {}], k, s;
   for (s = 0; s < sets.length; ++s) for (k in sets[s]) if (Object.prototype.hasOwnProperty.call(sets[s], k)) { var c = sets[s][k]; cpSfUiFree(c.front); cpSfUiFree(c.hole); cpSfUiFree(c.shade); }
   st.cuts = {}; st.cutsHi = {};
   if (st.starless) { cpSfUiFree(st.starless.bmp); st.starless = null; }
   cpSfUiFree(st.photoBack); st.photoBack = null;
   cpSfUiFree(st.photo); st.photo = this._grabPhoto();         // la copia pequena, de lo que enseña el visor AHORA
   if (this.state === st && this.mode !== "") {
      var pv = this.dialog.preview;
      pv.setBusy(true, optT("Preparing the photo…"), false);
      try {
         st.photoFull = this._renderFull(rec);
         if (this.starsMode !== "gaia") this._psPrepare(st);
      } finally { pv.setBusy(false); }
      try { this._render(); } catch (eR) {}
   }
   return true;
};
