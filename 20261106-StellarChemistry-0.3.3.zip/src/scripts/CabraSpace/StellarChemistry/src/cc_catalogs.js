// ============================================================================
// src/cc_catalogs.js — LOS CATÁLOGOS: consultas ADQL y lectura de filas (puro)
// ----------------------------------------------------------------------------
// TODO va por UN servicio: TAPVizieR (CDS), ADQL -> CSV. Medido el 14-oct-2026
// (docs/catalogos.md): una consulta por polígono en M 67 tarda 0,3-2,7 s; un
// IN de ids sobre Gaia DR3 con dos JOIN, 1,4 s.
//
// Lo que sabe este fichero de cada tabla está en CC_CAT (nombre exacto en
// VizieR, columnas, cómo se lee cada fila). Las trampas de TAPVizieR medidas:
//   · los nombres de tabla van entre comillas dobles: FROM "III/286/catalog";
//   · las columnas con corchetes o guiones también: "[Fe/H]", "Age-Flame";
//   · el ADQL de VizieR NO distingue mayúsculas: b_rgeo y B_rgeo chocan
//     («Ambiguous table reference») si no van entre comillas — siempre se citan;
//   · los source_id de Gaia pasan de 2^53: se guardan como CADENA, nunca Number.
//
// Procedencia: código NUEVO. La consulta TAP por CSV con tope de tiempo sigue
// la de CabraPilot `engine/starfield_run.js` (cpSfTapUrl, cpSfLooksLikeCsv).
// ES5 puro.
// ============================================================================

var CC_TAP_URL = "https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync";
var CC_IN_CHUNK = 300;     // ids por consulta IN (diseño: cabe de sobra en un POST)
var CC_GSP_FLOOR = 0.05;   // dex: suelo de error de [M/H] y [α/Fe] de GSP-Spec (diseño; ver CC_PARSE.gspspec)
var CC_XPG_MAX_FEH = -1.5; // las metalicidades XP solo se usan por debajo (medido: ver CC_PARSE.xpg)

// ---------------------------------------------------------------------------
// CSV de TAPVizieR (RFC 4180: comillas dobles, "" dentro de comillas)
// ---------------------------------------------------------------------------
function ccParseCsv(text) {
   var rows = [], row = [], f = "", q = false, s = String(text || ""), i = 0, n = s.length;
   while (i < n) {
      var ch = s.charAt(i);
      if (q) {
         if (ch === "\"") {
            if (i + 1 < n && s.charAt(i + 1) === "\"") { f += "\""; i += 2; continue; }
            q = false; ++i; continue;
         }
         f += ch; ++i; continue;
      }
      if (ch === "\"") { q = true; ++i; continue; }
      if (ch === ",") { row.push(f); f = ""; ++i; continue; }
      if (ch === "\r") { ++i; continue; }
      if (ch === "\n") { row.push(f); rows.push(row); row = []; f = ""; ++i; continue; }
      f += ch; ++i;
   }
   if (f.length > 0 || row.length > 0) { row.push(f); rows.push(row); }
   if (rows.length === 0) return { header: [], rows: [] };
   var header = rows[0], out = [];
   for (var r = 1; r < rows.length; ++r) {
      if (rows[r].length === 1 && rows[r][0] === "") continue;
      var o = {};
      for (var c = 0; c < header.length; ++c) o[header[c]] = (c < rows[r].length) ? rows[r][c] : "";
      out.push(o);
   }
   return { header: header, rows: out };
}
// ¿Es una tabla lo que ha llegado? (un error de TAP llega como VOTable XML).
function ccLooksLikeCsv(text, column) {
   var head = String(text || "").substring(0, 600);
   if (head.indexOf("<") >= 0 && head.indexOf("VOTABLE") >= 0) return false;
   return head.split("\n")[0].indexOf(column) >= 0;
}
// El mensaje de error de un VOTable de TAP (para el log y la interfaz).
function ccTapError(text) {
   var m = /<INFO name="QUERY_STATUS" value="ERROR">([\s\S]*?)<\/INFO>/.exec(String(text || ""));
   return m ? m[1].replace(/\s+/g, " ").substring(0, 300) : "";
}

// ---------------------------------------------------------------------------
// GEOMETRÍA ADQL
// ---------------------------------------------------------------------------
// poly = [ [ra, dec], ... ] (las esquinas del encuadre, en orden).
function ccAdqlPolygon(poly) {
   var p = [];
   for (var i = 0; i < poly.length; ++i) p.push(poly[i][0].toFixed(6) + "," + poly[i][1].toFixed(6));
   return "POLYGON('ICRS'," + p.join(",") + ")";
}
function ccInside(raCol, decCol, poly) {
   return "1=CONTAINS(POINT('ICRS'," + raCol + "," + decCol + ")," + ccAdqlPolygon(poly) + ")";
}
function ccQ(name) { return "\"" + name + "\""; }
function ccCols(prefix, names) {
   var o = [];
   for (var i = 0; i < names.length; ++i) o.push(prefix + ccQ(names[i]));
   return o.join(", ");
}
// Las columnas [X/Fe], e_[X/Fe] y f_/q_ de una lista de elementos.
function ccElemCols(prefix, elems, flagPrefix) {
   var o = [];
   for (var i = 0; i < elems.length; ++i) {
      o.push(prefix + ccQ("[" + elems[i] + "/Fe]"));
      o.push(prefix + ccQ("e_[" + elems[i] + "/Fe]"));
      if (flagPrefix) o.push(prefix + ccQ(flagPrefix + "[" + elems[i] + "/Fe]"));
   }
   return o.join(", ");
}

// Listas de elementos por tabla (las columnas que EXISTEN, vistas en TAP_SCHEMA el 14-oct-2026).
var CC_GALAH_EL = ["C", "N", "O", "Na", "Mg", "Al", "Si", "K", "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Co", "Ni", "Cu", "Zn",
                   "Rb", "Sr", "Y", "Zr", "Mo", "Ru", "Ba", "La", "Ce", "Nd", "Sm", "Eu"];
var CC_APOGEE_EL = ["C", "N", "O", "Na", "Mg", "Al", "Si", "S", "K", "Ca", "Ti", "V", "Cr", "Mn", "Co", "Ni", "Ce"];
var CC_X19_EL = ["C", "N", "O", "Na", "Mg", "Al", "Si", "Ca", "Ti", "Cr", "Mn", "Co", "Ni", "Cu", "Ba"];
var CC_GSP_EL = ["Mg", "Si", "Ca", "Ti", "S", "Cr", "Ni", "Zr", "Ce", "Nd", "N"];
// EL LITIO de GALAH DR4 (23-oct-2026): NO es un [X/Fe] más. Se pide la abundancia ABSOLUTA A(Li) en 3D NLTE del catálogo de valor
// añadido de DR4 (Buder et al. 2025, sec. 7.2.3: perfil 3D NLTE de Breidablik, anchura equivalente con UltraNest; método de Wang et
// al. 2024, arXiv:2402.02669), que VizieR sirve dentro de `allstar`: ALi, su límite superior ALiul, los errores inferior/superior
// e_ALi / E_ALi, el error que arrastra la Teff e_ALiTeff y la bandera f_ALi (nota G2 del ReadMe de VizieR: 1 = límite superior; los
// autores recomiendan f_ALi < 2). NO se usa la columna [Li/Fe] (la red neuronal 1D NLTE: los autores dicen que la 3D NLTE es mejor).
// Visto en TAP_SCHEMA el 23-oct-2026; APOGEE DR17, LAMOST DR11 y Xiang+19 NO traen litio (ver docs/litio_y_mg_xiang.md).
// (Van AL FINAL de la consulta: cambia su huella —caché y respuestas grabadas de tests/fx regrabadas con tests/cc_li_record.js—, no
//  el orden de las columnas de antes.)
var CC_GALAH_LI = ["ALi", "ALiul", "e_ALi", "E_ALi", "e_ALiTeff", "f_ALi"];

// ---------------------------------------------------------------------------
// LAS CONSULTAS
// ---------------------------------------------------------------------------
var CC_CAT = {
   count: {
      label: "Gaia DR3 (count)", table: "I/355/gaiadr3", key: "gbin",
      adql: function(poly) {
         return "SELECT FLOOR(Gmag) AS gbin, COUNT(*) AS n FROM " + ccQ("I/355/gaiadr3") + " WHERE " + ccInside("RA_ICRS", "DE_ICRS", poly) +
                " AND Gmag < 19 GROUP BY gbin";   // (GROUP BY FLOOR(...) no lo acepta TAPVizieR: medido)
      }
   },
   galah: {
      label: "GALAH DR4", table: "J/other/PASA/42.51/allstar", key: "GALAH", ref: "Buder et al. 2025, PASA 42, e051",
      adql: function(poly) {
         return "SELECT GALAH, GaiaDR3, RAJ2000, DEJ2000, flagSp, " + ccCols("", ["SNRpxCCD3", "Teff", "e_Teff", "logg", "e_logg", "[Fe/H]", "e_[Fe/H]", "f_[Fe/H]",
                "RVcomp1", "e_RVcomp1", "Mass", "Age", "rmed"]) + ", " + ccQ("b_rmed") + ", " + ccQ("B_rmed") + ", " + ccElemCols("", CC_GALAH_EL, "f_") +
                ", " + ccCols("", CC_GALAH_LI) + " FROM " + ccQ("J/other/PASA/42.51/allstar") + " WHERE " + ccInside("RAJ2000", "DEJ2000", poly);
      }
   },
   apogee: {
      label: "APOGEE DR17", table: "III/286/catalog", key: "APOGEE", ref: "Abdurro'uf et al. 2022, ApJS 259, 35",
      adql: function(poly) {
         return "SELECT APOGEE, GaiaEDR3, RAJ2000, DEJ2000, SNR, EFlag, AFlag, " + ccCols("", ["Teff", "e_Teff", "logg", "e_logg", "[M/H]", "e_[M/H]", "[a/M]", "e_[a/M]",
                "[Fe/H]", "e_[Fe/H]", "f_[Fe/H]", "HRV", "e_HRV", "s_HRV", "Nvis", "rgeo"]) + ", " + ccQ("b_rgeo") + ", " + ccQ("B_rgeo") + ", " +
                ccElemCols("", CC_APOGEE_EL, "f_") + " FROM " + ccQ("III/286/catalog") + " WHERE " + ccInside("RAJ2000", "DEJ2000", poly);
      }
   },
   lamost: {
      label: "LAMOST DR11 LRS", table: "V/162/dr11sl", key: "ObsID", ref: "Luo et al. 2015 (LAMOST); DR11 v1",
      adql: function(poly) {
         return "SELECT ObsID, GaiaDR3, RAJ2000, DEJ2000, snrg, snri, " + ccCols("", ["Teff", "e_Teff", "logg", "e_logg", "[Fe/H]", "e_[Fe/H]", "RV", "e_RV", "alpha", "e_alpha"]) +
                " FROM " + ccQ("V/162/dr11sl") + " WHERE " + ccInside("RAJ2000", "DEJ2000", poly);
      }
   },
   x19: {
      label: "LAMOST DR5 abundances (Xiang+19)", table: "J/ApJS/245/34/catalog", key: "Name", ref: "Xiang et al. 2019, ApJS 245, 34",
      adql: function(poly) {
         var el = [];
         for (var i = 0; i < CC_X19_EL.length; ++i) el.push(CC_X19_EL[i]);
         return "SELECT Name, RAJ2000, DEJ2000, snrg, Teff, logg, " + ccCols("", ["q_logg", "[Fe/H]", "e_[Fe/H]", "q_[Fe/H]", "[a/Fe]", "e_[a/Fe]", "q_Chi2"]) + ", " +
                ccElemCols("", el, "q_") + " FROM " + ccQ("J/ApJS/245/34/catalog") + " WHERE " + ccInside("RAJ2000", "DEJ2000", poly);
      }
   },
   gspspec: {
      label: "Gaia DR3 GSP-Spec", table: "I/355/paramp", key: "Source", ref: "Recio-Blanco et al. 2023, A&A 674, A29",
      adql: function(poly) {
         var el = [];
         for (var i = 0; i < CC_GSP_EL.length; ++i) { el.push("p." + ccQ("[" + CC_GSP_EL[i] + "/Fe]-S")); el.push("p." + ccQ("b_[" + CC_GSP_EL[i] + "/Fe]-S")); el.push("p." + ccQ("B_[" + CC_GSP_EL[i] + "/Fe]-S")); }
         return "SELECT p.Source, p.RA_ICRS, p.DE_ICRS, " + ccCols("p.", ["Teff-S", "logg-S", "[M/H]-S", "b_[M/H]-S", "B_[M/H]-S", "[alpha/Fe]-S", "b_[alpha/Fe]-S", "B_[alpha/Fe]-S", "Flags"]) + ", " +
                el.join(", ") + " FROM " + ccQ("I/355/paramp") + " AS p WHERE " + ccInside("p.RA_ICRS", "p.DE_ICRS", poly) + " AND p." + ccQ("[M/H]-S") + " IS NOT NULL";
      }
   },
   xpg: {
      label: "Gaia XP giants (Andrae+23)", table: "J/MNRAS/537/1984/a23", key: "GaiaDR3", ref: "Andrae, Rix & Chandra 2023, ApJS 267, 8 (vetted giants as served by Ardern-Arentsen et al. 2025)",
      adql: function(poly) {
         return "SELECT GaiaDR3, RA_ICRS, DE_ICRS, Gmag, " + ccCols("", ["[Fe/H]", "e_[Fe/H]", "[C/Fe]", "e_[C/Fe]", "Teff", "logg", "Lz", "Energy"]) +
                " FROM " + ccQ("J/MNRAS/537/1984/a23") + " WHERE " + ccInside("RA_ICRS", "DE_ICRS", poly);
      }
   },
   xr22: {
      label: "Subgiant ages (Xiang & Rix 22)", table: "J/other/Nat/603.599/table1", key: "Id", ref: "Xiang & Rix 2022, Nature 603, 599",
      adql: function(poly) {
         return "SELECT Id, RAJ2000, DEJ2000, Age, " + ccCols("", ["e_Age", "[Fe/H]", "e_[Fe/H]", "[alpha/Fe]", "e_[alpha/Fe]", "JR", "JPHI", "JZ", "Teff", "logg"]) +
                " FROM " + ccQ("J/other/Nat/603.599/table1") + " WHERE " + ccInside("RAJ2000", "DEJ2000", poly);
      }
   },
   anders: {
      label: "APOGEE spectroscopic ages (Anders+23)", table: "J/A+A/678/A158/catalog", key: "APOGEE", ref: "Anders et al. 2023, A&A 678, A158",
      adql: function(poly) {
         return "SELECT APOGEE, " + ccCols("", ["spAgeCal", "e_spAge", "f_spAge", "_RA", "_DE"]) + " FROM " + ccQ("J/A+A/678/A158/catalog") +
                " WHERE " + ccInside(ccQ("_RA"), ccQ("_DE"), poly);
      }
   }
};

// Las rejillas de Boin et al. (A&A 708, A215): cinco modelos de isocronas.
var CC_BOIN_GRIDS = ["BaSTI", "MIST", "PARSEC", "Dartmouth", "Geneva"];
var CC_BOIN_TABLES = { galah: "J/A+A/708/A215/galah4", apogee: "J/A+A/708/A215/apogee", lamost: "J/A+A/708/A215/lamostl" };
function ccBoinAdql(table, ids) {
   var cols = ["GaiaDR3"];
   for (var i = 0; i < CC_BOIN_GRIDS.length; ++i) {
      var g = CC_BOIN_GRIDS[i];
      // (la columna de Dartmouth se llama «AgeDartmouth_mean» con guion bajo; la mediana, sin él: TAP_SCHEMA)
      cols.push(ccQ("Age" + g + "median")); cols.push(ccQ("Age" + g + "std")); cols.push(ccQ("inDomain" + g));
   }
   return "SELECT " + cols.join(", ") + " FROM " + ccQ(table) + " WHERE GaiaDR3 IN (" + ids.join(",") + ")";
}
// Gaia DR3 + Bailer-Jones + FLAME, por ids.
function ccGaiaAdql(ids) {
   // (30-oct, decisión D: GRVSmag y RVtempTeff, las dos columnas de la corrección de Katz/Blomme, en esta misma consulta: cshRvCorrect, CabraShared/csh_net.js)
   return "SELECT g.Source, g.RA_ICRS, g.DE_ICRS, g.pmRA, g.e_pmRA, g.pmDE, g.e_pmDE, g.Plx, g.e_Plx, g.RV, g.e_RV, g.Gmag, g." + ccQ("BP-RP") + ", g.RUWE, " +
          ((typeof cshRvColsSql === "function") ? cshRvColsSql("g.", ", ") : "") +
          "d." + ccQ("rgeo") + ", d." + ccQ("b_rgeo") + ", d." + ccQ("B_rgeo") + ", d." + ccQ("rpgeo") + ", d." + ccQ("b_rpgeo") + ", d." + ccQ("B_rpgeo") + ", " +
          "p." + ccQ("Age-Flame") + ", p." + ccQ("b_Age-Flame") + ", p." + ccQ("B_Age-Flame") + ", p." + ccQ("Flags-Flame") + ", p." + ccQ("Mass-Flame") +
          " FROM " + ccQ("I/355/gaiadr3") + " AS g LEFT OUTER JOIN " + ccQ("I/352/gedr3dis") + " AS d ON d.Source = g.Source" +
          " LEFT OUTER JOIN " + ccQ("I/355/paramp") + " AS p ON p.Source = g.Source WHERE g.Source IN (" + ids.join(",") + ")";
}
// Kordopatis et al. 2023 (GSP-Spec + órbitas + edades), por ids.
function ccKordAdql(ids) {
   return "SELECT GaiaDR3, age, e_age, " + ccCols("", ["Lzdgeo", "edgeo", "Zmaxdgeo", "Jrdgeo"]) + " FROM " + ccQ("J/A+A/669/A104/catalog") +
          " WHERE GaiaDR3 IN (" + ids.join(",") + ")";
}
function ccChunks(list, n) {
   var out = [];
   for (var i = 0; i < list.length; i += n) out.push(list.slice(i, i + n));
   return out;
}

// ---------------------------------------------------------------------------
// EL RESPALDO: los ESPEJOS de VizieR por ASU (F2, 22-oct-2026) — puro, sin red
// ---------------------------------------------------------------------------
// Si TAPVizieR (CDS) no contesta, las MISMAS consultas se piden al servicio ASU de un espejo (CfA, NAO): los espejos no tienen
// TAP en la ruta de CDS (HTTP 404 medido el 22-oct-2026), pero sí `viz-bin/asu-tsv`, con las mismas tablas y columnas. ASU no
// entiende ADQL ni polígonos: aquí la consulta ADQL de CC_CAT se LEE (columnas, tablas, polígono, lista de ids) y se traduce:
//   · por polígono: un CÍRCULO que lo envuelve (-c, -c.rd) y el recorte al polígono se hace aquí (ccAsuInside: aristas de círculo máximo, como el CONTAINS de VizieR);
//   · por ids: `Columna=id1,id2,...` (ASU acepta la lista SOLO en columnas de texto: las tablas de Boin+26; se parte en trozos de
//     CC_ASU_IDS). En las de ids ENTEROS (Gaia Source, Kordopatis+23) la lista no devuelve nada (medido el 22-oct): se pide el
//     CONO del campo entero (el polígono de la última consulta por polígono, `ctx.poly`) y se filtra aquí por los ids;
//   · el JOIN de Gaia (gaiadr3 + gedr3dis + paramp) son tres peticiones (conos) unidas aquí por Source;
//   · el recuento por magnitud (GROUP BY) se calcula aquí con las Gmag de todo el cono (CC_ASU_MAX filas como mucho).
// La salida es el MISMO texto CSV que daría TAPVizieR (misma cabecera, mismo orden de columnas): el resto del motor no se entera.
// (29-oct-2026) IDIA primero: con el CDS caido era el unico espejo que contestaba; CfA conectaba y callaba hasta el plazo.
// GALAH DR4 no esta en IDIA: cae al siguiente.
// (3-nov-2026, CPD SC1, reglas 4.6/6.3: solo espejos https) FUERA el tercero, NAO Japon (`vizier.nao.ac.jp`), que solo servia sin cifrar
// (https no conecta: docs/auditoria-reglas-cpd.md). Era un respaldo PARCIAL (sin GALAH DR4, LAMOST DR11 ni Boin: docs/catalogos.md); quedan
// IDIA y CfA, los dos por https. ccMirrorLacks indexa por POSICION: los indices 0 (IDIA) y 1 (CfA) no cambian.
var CC_ASU_MIRRORS = [["https://vizier.idia.ac.za/viz-bin/asu-tsv", "VizieR (IDIA mirror)", ["J/A+A/669/A104/"]], ["https://vizier.cfa.harvard.edu/viz-bin/asu-tsv", "VizieR (CfA mirror)"]];
// (el control en rojo de que no quede ninguno http lo inyecta la prueba en su copia en memoria: tests/cc_cpd_node.js, CC_CPD_BREAK=http)
// (CfA sigue el segundo: Kordopatis+23 lo servia CfA el 27-oct; el 29-oct IDIA no devolvio filas)
// El tercer elemento: tablas que ese espejo NO sirve bien y que se saltan sin preguntarle (medido el 29-oct con cc_node_asu m67:
// en IDIA, Kordopatis+23 da una tabla VACIA —0 filas frente a 121-242 del TAP—, y una tabla vacia es «la respuesta»: no caeria al
// siguiente espejo). GALAH DR4 no hace falta: IDIA contesta «Table not found» y ya cae solo.
function ccMirrorLacks(m, adql) {
   var skip = CC_ASU_MIRRORS[m][2] || [], s = String(adql);
   for (var i = 0; i < skip.length; ++i) if (s.indexOf(skip[i]) >= 0) return true;
   return false;
}
// (29-oct-2026, motor unico) EL PLANIFICADOR ASU (leer el ADQL, partirlo en peticiones, leer cada respuesta, volver a montar el CSV de TAP)
// SE MUDO a ../../CabraShared/csh_vizier.js (cshVz*): uno para todos los scripts, con la regla del vacio escrita una sola vez
// (docs/motor-vizier-unico.md). Aqui quedan los nombres de siempre como ADAPTADORES de una linea (los usan cc_pixinsight.js y las pruebas).
// Requiere ../CabraShared/csh_net.js y csh_vizier.js incluidos antes (CabraComposition.js, CabraStarAnalysis.js, tests/cc_node_lib.js).
var CC_ASU_MAX = CSH_VZ_MAX;                    // filas como mucho por peticion (el tope de TAPVizieR)
var CC_ASU_IDS = CSH_VZ_IDS;                    // ids por peticion
var CC_ASU_LIST_TABLES = CSH_VZ_LIST_TABLES;    // las tablas cuya columna de ids es TEXTO: ahi ASU acepta la lista de ids
function ccAsuSelect(adql) { return cshVzSelect(adql); }
function ccAsuTables(adql) { return cshVzTables(adql); }
function ccAsuPlan(adql, key, ctx) { return cshVzPlan(adql, key, ctx); }
function ccAsuCircle(poly) { return cshVzCircle(poly); }
function ccAsuInside(poly) { return cshVzInside(poly); }
function ccAsuEnc(s) { return cshVzEnc(s); }
function ccAsuRequests(plan) { return cshVzRequests(plan); }
// (las costuras rojas emptyloose y missingok: CC_BREAK o ccBroken, como antes; ahora las lee cshVzBrk)
function ccAsuBrk(k) { return cshVzBrk(k); }
function ccAsuQsOf(qs) { return cshVzQsOf(qs); }
function ccAsuRead(text, table, cols) { return cshVzRead(text, table, cols); }
function ccCsvCell(v) { return cshVzCsvCell(v); }
function ccAsuBuild(plan, reqs, texts) { return cshVzBuild(plan, reqs, texts); }

// ---------------------------------------------------------------------------
// LECTURA DE FILAS -> registros de survey
// ----------------------------------------------------------------------------
// rec = { survey, id (gaia, cadena o ""), ra, dec, feh: {v,e,proxy}, alpha: {v,e,tracer},
//         el: { X: {v,e} }, teff, logg, rv: {v,e,scatter}, dist: {pc,lo,hi}, snr, raw }
// ---------------------------------------------------------------------------
function ccStr(v) { var s = String(v === undefined || v === null ? "" : v).replace(/^\s+|\s+$/g, ""); return s; }
function ccGaiaId(v) { var s = ccStr(v); return /^\d{6,20}$/.test(s) ? s : ""; }
function ccVE(row, vk, ek) { var v = ccNum(row[vk]); return (v === null) ? null : { v: v, e: ccNum(row[ek]) }; }
// [Mg/Fe] si está; si no, la media pesada de Mg, Si, Ca, Ti disponibles (como el alpha_fe de GALAH DR3).
function ccAlphaFromEl(el) {
   if (el.Mg && ccIsNum(el.Mg.v)) return { v: el.Mg.v, e: el.Mg.e, tracer: "Mg" };
   var sw = 0, s = 0, used = [];
   var list = ["Si", "Ca", "Ti"];
   for (var i = 0; i < list.length; ++i) {
      var x = el[list[i]];
      if (x && ccIsNum(x.v)) { var e = ccIsNum(x.e) && x.e > 0 ? x.e : 0.1, w = 1 / (e * e); s += w * x.v; sw += w; used.push(list[i]); }
   }
   if (sw === 0) return null;
   return { v: s / sw, e: Math.sqrt(1 / sw), tracer: used.join("+") };
}

// El litio de una fila de GALAH DR4 -> { v: A(Li), e, ul, flag, src, method } o null. Lo que trae VizieR (medido en M 67 el 23-oct-2026,
// 390 filas): f_ALi = 0 -> ALi lleno y ALiul vacío (DETECCIÓN); f_ALi = 1 -> ALi vacío y ALiul lleno (LÍMITE SUPERIOR: «A(Li) ≤ v»);
// f_ALi >= 2 (Teff fuera de la rejilla 3D, etc.) o vacío -> nada. Un límite NO lleva error ni se mezcla con las detecciones (ul = true).
//   e = media de e_ALi/E_ALi (el muestreo de la anchura equivalente) sumada en cuadratura con e_ALiTeff (lo que arrastra la Teff),
//       con suelo CC_SCI.LI_FLOOR (diseño, como CC_GSP_FLOOR). Por debajo de CC_SCI.LI_TEFF_MIN la rejilla 3D no llega: fuera.
function ccGalahLi(r) {
   var f = ccNum(r.f_ALi), T = ccNum(r.Teff);
   if (f === null || f >= 2) return null;
   if (T !== null && T < CC_SCI.LI_TEFF_MIN) return null;
   if (f === 1) { var u = ccNum(r.ALiul); return (u === null) ? null : { v: u, e: null, ul: true, flag: 1, src: "galah", method: "3D NLTE" }; }
   var a = ccNum(r.ALi);
   if (a === null) return null;
   var lo = ccNum(r["e_ALi"]), hi = ccNum(r["E_ALi"]), et = ccNum(r["e_ALiTeff"]);
   var es = (lo !== null && hi !== null) ? 0.5 * (lo + hi) : (lo !== null ? lo : hi);
   var e = Math.sqrt((es !== null ? es * es : 0) + (et !== null ? et * et : 0));
   return { v: a, e: Math.max(CC_SCI.LI_FLOOR, e), ul: false, flag: 0, src: "galah", method: "3D NLTE" };
}

var CC_PARSE = {
   galah: function(r) {
      if (ccNum(r.flagSp) !== 0) return null;                  // flag_sp = 0: espectro sin problemas
      // f_[Fe/H] (flag_fe_h, L3 del 23-oct-2026): su bit 1 («límite superior») es un FALLO de DR4 (Buder et al. 2025, PASA 42, e051,
      // §8.8.1: el [Fe/H] se comparó con el valor más bajo de la subrejilla de la red, a ~0,01 dex, «we therefore do not recommend the
      // use of this flag at all»; hasta el 34 % de las estrellas, y más en las pobres en metales). MEDIDO frente a APOGEE DR17 en las
      // mismas estrellas (docs/potencial_g1.md §L3, tests/cc_node_galah_feflag.js): con f = 1 el desplazamiento es el de f = 0 a ≤ 0,03
      // dex (enanas [Fe/H] < −0,4: −0,04 frente a −0,06, n 426/1 911; gigantes [Fe/H] < −1: igual en los tres tramos, n 251) y sus
      // errores son realistas (σ de Δ/e 1,09 frente a 1,04). Se acepta el bit 1; los demás bits (2 sin medida, 4 sin convergencia, 8/16
      // fuera de rango, 64 atascado) siguen fuera. Con flag_sp = 0 (arriba) ya van el χ² y la S/N.
      var ffe = ccNum(r["f_[Fe/H]"]), feOk = (ffe === 0 || ffe === 1);
      if (typeof ccSciBroken === "function" && ccSciBroken("cat-oldfeflag")) feOk = (ffe === 0);                    // (ROJO: el corte de antes, solo f = 0)
      if (typeof ccSciBroken === "function" && ccSciBroken("cat-allfeflags")) feOk = (ffe !== null);                // (ROJO: cualquier bandera, también sin convergencia)
      var feh = feOk ? ccVE(r, "[Fe/H]", "e_[Fe/H]") : null;
      var el = {};
      for (var i = 0; i < CC_GALAH_EL.length; ++i) {
         var X = CC_GALAH_EL[i];
         if (ccNum(r["f_[" + X + "/Fe]"]) === 0) { var q = ccVE(r, "[" + X + "/Fe]", "e_[" + X + "/Fe]"); if (q) el[X] = q; }
      }
      var rec = { survey: "galah", id: ccGaiaId(r.GaiaDR3), name: ccStr(r.GALAH), ra: ccNum(r.RAJ2000), dec: ccNum(r.DEJ2000), feh: feh, el: el,
                  alpha: ccAlphaFromEl(el), teff: ccNum(r.Teff), logg: ccNum(r.logg), snr: ccNum(r.SNRpxCCD3) };
      var rv = ccNum(r.RVcomp1);
      if (rv !== null) rec.rv = { v: rv, e: ccNum(r["e_RVcomp1"]), src: "galah" };
      var rm = ccNum(r.rmed);
      if (rm !== null) rec.dist = { pc: rm, lo: ccNum(r["b_rmed"]), hi: ccNum(r["B_rmed"]), src: "galah" };
      var age = ccNum(r.Age);
      if (age !== null) rec.isoAge = { src: "galah-iso", v: age, e: null };
      var li = ccGalahLi(r);
      if (li) rec.li = li;
      return rec;
   },
   apogee: function(r) {
      var af = ccNum(r.AFlag), ef = ccNum(r.EFlag);
      if (af !== null && Math.floor(af / 8388608) % 2 === 1) return null;   // ASPCAPFLAG bit 23 STAR_BAD
      var dup = (ef !== null && Math.floor(ef / 16) % 2 === 1);              // EXTRATARG bit 4: duplicado (peor S/N)
      var feh = (ccNum(r["f_[Fe/H]"]) === 0) ? ccVE(r, "[Fe/H]", "e_[Fe/H]") : null;
      var el = {};
      for (var i = 0; i < CC_APOGEE_EL.length; ++i) {
         var X = CC_APOGEE_EL[i];
         if (ccNum(r["f_[" + X + "/Fe]"]) === 0) { var q = ccVE(r, "[" + X + "/Fe]", "e_[" + X + "/Fe]"); if (q) el[X] = q; }
      }
      var alpha = null;
      if (el.Mg) alpha = { v: el.Mg.v, e: el.Mg.e, tracer: "Mg" };
      else {
         var am = ccNum(r["[a/M]"]), mh = ccNum(r["[M/H]"]);
         if (am !== null && mh !== null && feh) alpha = { v: am + mh - feh.v, e: ccNum(r["e_[a/M]"]), tracer: "[α/M]" };
      }
      var rec = { survey: "apogee", id: ccGaiaId(r.GaiaEDR3), name: ccStr(r.APOGEE), ra: ccNum(r.RAJ2000), dec: ccNum(r.DEJ2000), feh: feh, el: el,
                  alpha: alpha, teff: ccNum(r.Teff), logg: ccNum(r.logg), snr: ccNum(r.SNR), dup: dup };
      var rv = ccNum(r.HRV);
      if (rv !== null) rec.rv = { v: rv, e: ccNum(r["e_HRV"]), scatter: ccNum(r["s_HRV"]), nvis: ccNum(r.Nvis), src: "apogee" };
      var d = ccNum(r.rgeo);
      if (d !== null) rec.dist = { pc: d, lo: ccNum(r["b_rgeo"]), hi: ccNum(r["B_rgeo"]), src: "bj21" };
      return rec;
   },
   lamost: function(r) {
      var feh = ccVE(r, "[Fe/H]", "e_[Fe/H]");
      var a = ccNum(r.alpha);
      var rec = { survey: "lamost", id: ccGaiaId(r.GaiaDR3), name: ccStr(r.ObsID), ra: ccNum(r.RAJ2000), dec: ccNum(r.DEJ2000), feh: feh, el: {},
                  alpha: (a !== null) ? { v: a, e: ccNum(r["e_alpha"]), tracer: "[α/M]" } : null, teff: ccNum(r.Teff), logg: ccNum(r.logg), snr: ccNum(r.snrg) };
      var rv = ccNum(r.RV);
      if (rv !== null) rec.rv = { v: rv, e: ccNum(r["e_RV"]), src: "lamost" };
      return rec;
   },
   x19: function(r) {
      if (ccStr(r["q_Chi2"]).toLowerCase() !== "good") return null;
      var feh = (ccNum(r["q_[Fe/H]"]) === 1) ? ccVE(r, "[Fe/H]", "e_[Fe/H]") : null;
      var el = {};
      for (var i = 0; i < CC_X19_EL.length; ++i) {
         var X = CC_X19_EL[i];
         if (ccNum(r["q_[" + X + "/Fe]"]) === 1) { var q = ccVE(r, "[" + X + "/Fe]", "e_[" + X + "/Fe]"); if (q && ccIsNum(q.e) && q.e < 0.3) el[X] = q; }
      }
      // el cero del [Mg/Fe] de Xiang en ENANAS, llevado a la escala de APOGEE DR17 (la de la frontera de Weinberg): CC_SCI.X19_MG_DWARF_*
      // (medido el 23-oct-2026; fuente y control en CC_SCI). Se guarda el valor del catálogo (raw) y la corrección aplicada (zp).
      var lgX = ccNum(r.logg), zpX = CC_SCI.X19_MG_DWARF_ZP;
      if (el.Mg && ccIsNum(zpX) && zpX !== 0 && lgX !== null && lgX >= CC_SCI.X19_MG_DWARF_LOGG) {
         var eMg = ccIsNum(el.Mg.e) ? el.Mg.e : 0;
         el.Mg = { v: el.Mg.v + zpX, e: Math.sqrt(eMg * eMg + CC_SCI.X19_MG_DWARF_ZP_E * CC_SCI.X19_MG_DWARF_ZP_E), raw: el.Mg.v, zp: zpX };
      }
      var alpha = null;
      if (el.Mg) { alpha = { v: el.Mg.v, e: el.Mg.e, tracer: "Mg" }; if (el.Mg.zp) alpha.zp = el.Mg.zp; }
      else { var af = ccVE(r, "[a/Fe]", "e_[a/Fe]"); if (af) alpha = { v: af.v, e: af.e, tracer: "α" }; }
      return { survey: "x19", id: "", name: ccStr(r.Name), ra: ccNum(r.RAJ2000), dec: ccNum(r.DEJ2000), feh: feh, el: el, alpha: alpha,
               teff: ccNum(r.Teff), logg: ccNum(r.logg), snr: ccNum(r.snrg) };
   },
   gspspec: function(r) {
      if (!ccGspSpecGood(r.Flags)) return null;
      var logg = ccNum(r["logg-S"]), mh = ccNum(r["[M/H]-S"]);
      if (mh === null) return null;
      var lo = ccNum(r["b_[M/H]-S"]), hi = ccNum(r["B_[M/H]-S"]);
      var mhc = ccGspCalMh(mh, logg);
      // (los percentiles 16-84 de GSP-Spec salen del Monte Carlo del RUIDO de flujo: ±0,005 dex en una
      //  gigante brillante de M 67, que no es la exactitud. Suelo de 0,05 dex: diseño, CC_GSP_FLOOR.)
      var feh = { v: (mhc !== null) ? mhc : mh, e: Math.max(CC_GSP_FLOOR, (lo !== null && hi !== null) ? 0.5 * (hi - lo) : 0), proxy: "[M/H]" + (mhc !== null ? " cal." : "") };
      var el = {};
      for (var i = 0; i < CC_GSP_EL.length; ++i) {
         var X = CC_GSP_EL[i], v = ccNum(r["[" + X + "/Fe]-S"]), l = ccNum(r["b_[" + X + "/Fe]-S"]), h = ccNum(r["B_[" + X + "/Fe]-S"]);
         if (v !== null) el[X] = { v: v, e: (l !== null && h !== null) ? 0.5 * (h - l) : null };
      }
      var afe = ccNum(r["[alpha/Fe]-S"]), al = ccNum(r["b_[alpha/Fe]-S"]), ah = ccNum(r["B_[alpha/Fe]-S"]);
      var afc = ccGspCalAfe(afe, logg);
      return { survey: "gspspec", id: ccGaiaId(r.Source), ra: ccNum(r.RA_ICRS), dec: ccNum(r.DE_ICRS), feh: feh, el: el,
               alpha: (afe !== null) ? { v: (afc !== null) ? afc : afe, e: Math.max(CC_GSP_FLOOR, (al !== null && ah !== null) ? 0.5 * (ah - al) : 0), tracer: "α (cal.)" } : null,
               teff: ccNum(r["Teff-S"]), logg: logg };
   },
   xpg: function(r) {
      // SOLO en su dominio: estrellas pobres en metales. MEDIDO el 14-oct-2026 (tests/cc_node_compare.js,
      // 117 estrellas en común con APOGEE en los campos grabados): XP − APOGEE = −0,56 dex de mediana,
      // −0,62 a metalicidad solar y −0,11 por debajo de −1. Es un modelo para el halo; en el disco engaña.
      var feh = ccVE(r, "[Fe/H]", "e_[Fe/H]");
      if (feh && feh.v > CC_XPG_MAX_FEH) feh = null;
      else if (feh) feh.e = Math.max(ccIsNum(feh.e) ? feh.e : 0, 0.2);
      var el = {};
      var c = ccVE(r, "[C/Fe]", "e_[C/Fe]");
      if (c) el.C = c;
      return { survey: "xpg", id: ccGaiaId(r.GaiaDR3), ra: ccNum(r.RA_ICRS), dec: ccNum(r.DE_ICRS), feh: feh, el: el, alpha: null,
               teff: ccNum(r.Teff), logg: ccNum(r.logg), orbit: { Lz: ccNum(r.Lz), E: ccNum(r.Energy), src: "xpg" } };
   }
};

// Elige UNA fila por estrella (la de más S/N; las no duplicadas antes).
function ccBestPerStar(recs) {
   var best = {}, order = [];
   for (var i = 0; i < recs.length; ++i) {
      var r = recs[i];
      if (!r) continue;
      var k = r.id || ("pos:" + (r.ra || 0).toFixed(5) + "," + (r.dec || 0).toFixed(5));
      var b = best[k];
      if (!b) { best[k] = r; order.push(k); continue; }
      var better = false;
      if (b.dup && !r.dup) better = true;
      else if (!!b.dup === !!r.dup) {
         if (!b.feh && r.feh) better = true;
         else if (!!b.feh === !!r.feh && (r.snr || 0) > (b.snr || 0)) better = true;
      }
      if (better) best[k] = r;
   }
   var out = [];
   for (i = 0; i < order.length; ++i) out.push(best[order[i]]);
   return out;
}

// Distancia angular en segundos de arco (aproximación plana: vale para < 1').
function ccSepArcsec(ra1, de1, ra2, de2) {
   var c = Math.cos(0.5 * (de1 + de2) * Math.PI / 180);
   var dx = (ra1 - ra2) * c, dy = de1 - de2;
   return Math.sqrt(dx * dx + dy * dy) * 3600;
}
// Índice por celdas para emparejar por posición.
function ccPosIndex(items, cellArcsec) {
   var cell = cellArcsec / 3600, map = {};
   for (var i = 0; i < items.length; ++i) {
      var it = items[i];
      if (!ccIsNum(it.ra) || !ccIsNum(it.dec)) continue;
      var k = Math.floor(it.ra / cell) + ":" + Math.floor(it.dec / cell);
      (map[k] = map[k] || []).push(it);
   }
   return {
      near: function(ra, dec, tolArcsec) {
         var cx = Math.floor(ra / cell), cy = Math.floor(dec / cell), best = null, bd = tolArcsec;
         for (var dx = -1; dx <= 1; ++dx) for (var dy = -1; dy <= 1; ++dy) {
            var L = map[(cx + dx) + ":" + (cy + dy)];
            if (!L) continue;
            for (var j = 0; j < L.length; ++j) { var d = ccSepArcsec(ra, dec, L[j].ra, L[j].dec); if (d <= bd) { bd = d; best = L[j]; } }
         }
         return best ? { item: best, sep: bd } : null;
      }
   };
}
