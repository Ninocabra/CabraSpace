// ============================================================================
// src/cc_engine.js — EL MOTOR: del encuadre a las biografías (sin PixInsight)
// ----------------------------------------------------------------------------
// ccRun( field, opts ) -> result
//   field = { ok, ra, dec, width, height, polygon: [[ra,dec] x4],
//             project(ra, dec) -> {x, y} | null, epochYears }
//   opts  = { http( adql, key ) -> { ok, text, ms, message, cached },
//             onStep( i, n, key, label, info ), surveys: { galah: true, ... } }
// La red entra SOLO por opts.http (en PixInsight, curl con caché en disco;
// en node, curl síncrono): así el motor se prueba igual en los dos sitios.
//
//   result = {
//     ok, code, why, field,
//     queries: [ { key, label, ok, rows, used, ms, message, cached } ],
//     stars:   [ star ]   (solo las que tienen algún dato químico o de edad)
//     coverage: { gaiaG17, gaiaG15, gaiaG19, inFrame, chem, alpha, age, kin,
//                 bySurvey: { galah: n, ... }, byPop: { thin: n, ... }, ageBySrc }
//     tagging: [ ccTagging(...) por survey ], timings: { totalMs, netMs }
//   }
//   star = { idx, id, name, ra, dec, x, y, inFrame, g, bpRp, plx, ePlx, pmra, pmdec,
//            ruwe, dist: {pc,lo,hi,src}, rv: {v,e,src,scatter}, recs: { survey: rec },
//            chem (ccAdoptChem), chemClass, kin, pop, age (ccAdoptAge), fp, twin,
//            bio: { en, es } }
// ES5 puro.
// ============================================================================

var CC_STEPS = ["count", "galah", "apogee", "lamost", "x19", "gspspec", "xpg", "gaia", "xr22", "anders", "boin", "kord"];

function ccEmptyResult(field) {
   return { ok: false, code: "", why: "", field: field || null, queries: [], stars: [], gaiaField: [], gaiaLocal: null, status: null,
            coverage: null, tagging: [], timings: { totalMs: 0, netMs: 0 } };
}

// ¿Ha servido ya algún espejo en este análisis? (solo dentro de PixInsight, cc_pixinsight.js; en node no hay espejos)
function ccEngineMirrorUp() { try { return typeof ccNetStatus === "function" && ccNetStatus().viaMirror > 0; } catch (e) { return false; } }
function ccEngineBreak(k) { try { return (typeof ccBroken === "function" && ccBroken(k)) || (typeof ccBreak === "function" && ccBreak(k)); } catch (e) { return false; } }
function ccRun(field, opts) {
   var o = opts || {};
   var res = ccEmptyResult(field);
   var t0 = Date.now();
   if (!field || !field.ok || !field.polygon) { res.code = "no-field"; res.why = "no astrometric field"; return res; }
   if (typeof o.http !== "function") { res.code = "no-http"; res.why = "no network function"; return res; }
   var poly = field.polygon, want = o.surveys || {};
   var nSteps = CC_STEPS.length, step = 0;
   var surveys = ["galah", "apogee", "lamost", "x19", "gspspec", "xpg"];
   var mustCol = { galah: "GALAH", apogee: "APOGEE", lamost: "ObsID", x19: "Name", gspspec: "Source", xpg: "GaiaDR3" };
   // EL LOTE (22-oct-2026, noche; opts.batch = ccHttpBatch en PixInsight): las consultas que NO dependen de otras (los 6 surveys y las
   // edades de Xiang & Rix y Anders, todas por el polígono) se lanzan A LA VEZ aquí, ANTES de la base Gaia local (que tarda lo suyo la
   // primera vez); las que piden por id de Gaia (Gaia, Boin, Kordopatis), en cuanto están los surveys (paso 4). El código de abajo
   // sigue siendo el de siempre, en el mismo orden: `fetch` solo espera a la respuesta que ya está en camino (o pregunta, si no lo está).
   // Sin opts.batch (node, CabraStarAnalysis, las pruebas con respuestas grabadas), en serie, como antes.
   var H = null;
   if (typeof o.batch === "function") {
      try { H = o.batch(ccFirstItems(field, want, typeof o.gaiaLocal === "function")); } catch (eB) { H = null; }
   }
   try { return ccRunSteps(); } finally { if (H) { try { H.close(); } catch (eC) {} } }

   function ccRunSteps() {
   function fetch(adql, key) { var r = H ? H.take(adql, key) : null; return r ? r : o.http(adql, key); }
   // LO QUE YA SE SABE, mientras llega el resto (opts.onPartial): un resultado con `partial: true`, sin estado (no dice «no hay
   // estrellas» a medias) y con las estrellas terminadas en COPIAS (las de verdad siguen recibiendo Gaia y edades). Como mucho uno
   // cada CC_PARTIAL_GAP_MS (o 4 veces lo que tardó el anterior: en un campo denso, el cálculo no se come la espera).
   var lastPart = 0, partCost = 0;
   function partial(src, clone, force) {
      if (typeof o.onPartial !== "function" || ccEngineBreak("nopartial")) return;
      var now = Date.now();
      if (!force && now - lastPart < Math.max(CC_PARTIAL_GAP_MS, 4 * partCost)) return;
      try { o.onPartial(ccPartialResult(res, field, src, gHist, locIdx, clone, t0, o.pulse)); } catch (eP) { res.partialError = String(eP); }
      lastPart = Date.now(); partCost = lastPart - now;
   }
   function tell(key, info) { if (typeof o.onStep === "function") { try { o.onStep(step, nSteps, key, (CC_CAT[key] && CC_CAT[key].label) || key, info || {}); } catch (e) {} } }
   function ask(key, label, adql, mustHave) {
      var q = { key: key, label: label, ok: false, rows: 0, used: 0, ms: 0, message: "", cached: false, net: false, code: 0, host: "" };
      // el servidor ya no contestó (tras su reintento): las demás consultas a él NO se lanzan (minutos de espera)
      if (res.netDown) { q.net = true; q.code = res.netDown.code; q.host = res.netDown.host; q.netWhy = res.netDown.why; q.message = "skipped (server down)"; res.queries.push(q); return { q: q, rows: [] }; }
      var r = null;
      try { r = fetch(adql, key) || {}; } catch (eH) { r = { ok: false, message: String(eH.message || eH), netFail: true }; }
      q.net = !!r.netFail; q.code = r.code || 0; q.host = r.host || ""; q.netWhy = r.netWhy || "";
      // 19 (22-oct): con el principal caído y un ESPEJO respondiendo, un fallo de esa consulta en el espejo (NAO no tiene GALAH DR4,
      // LAMOST DR11 ni Boin: «Table or Catalog not found») no es «servidor caído»: las demás consultas siguen (el espejo contesta).
      var viaMirror = /mirrors?:/i.test(String(r.message || "")) && (/not found/i.test(String(r.message || "")) || ccEngineMirrorUp());
      if (q.net && !r.cached && !(viaMirror && !ccEngineBreak("mirrornetdown"))) res.netDown = { host: q.host, code: q.code, why: q.netWhy, label: label };
      q.ms = r.ms || 0; q.cached = !!r.cached;
      res.timings.netMs += q.ms;
      var parsed = null;
      if (r.ok && ccLooksLikeCsv(r.text, mustHave)) {
         parsed = ccParseCsv(r.text);
         q.ok = true; q.rows = parsed.rows.length;
      } else {
         q.message = r.message || ccTapError(r.text) || (r.ok ? "not a table" : "no answer");
      }
      res.queries.push(q);
      return { q: q, rows: parsed ? parsed.rows : [] };
   }

   // 1 · cuántas estrellas Gaia hay en el encuadre (el denominador de la cobertura)
   step = 1; tell("count");
   var gHist = {}, i, GL = null, locIdx = null;
   if (typeof o.gaiaLocal === "function") { try { GL = o.gaiaLocal(field); } catch (eL) { GL = null; } }
   if (GL && GL.ok && typeof field.project === "function") {
      // la base local: el recuento por magnitud y las estrellas del encuadre (para la foto, sin red) — ccGaiaFieldStars, la misma
      // cuenta que hace la vista previa del diálogo al abrir
      var GF = ccGaiaFieldStars(GL, field, o.pulse);
      gHist = GF.gHist; res.gaiaField = GF.gaiaField;
      res.gaiaLocal = { name: GL.release || GL.name || "DR3", rows: GL.rows.length, inFrame: GF.nIn, ms: GL.ms, truncated: !!GL.truncated };
      res.queries.push({ key: "count", label: "Gaia " + res.gaiaLocal.name + " (local)", ok: true, rows: GL.rows.length, used: GF.nIn, ms: GL.ms, message: "", cached: false, local: true });
      locIdx = ccPosIndex(GL.rows, 2);
   } else {
      var cnt = ask("count", "Gaia DR3 (count)", CC_CAT.count.adql(poly), "gbin");
      for (i = 0; i < cnt.rows.length; ++i) { var gb = ccNum(cnt.rows[i].gbin), nn = ccNum(cnt.rows[i].n); if (gb !== null && nn !== null) gHist[gb] = nn; }
      if (GL && !GL.ok) res.gaiaLocal = { name: "", missing: true, why: GL.why || "" };
   }
   partial([], false, true);                     // (la foto con las estrellas de Gaia, antes que ningún survey)

   // (30-oct-2026) LO QUE LLEGA PRIMERO SE ENSEÑA PRIMERO. Abajo los surveys se leen en orden fijo y GALAH va delante: medido en Abell 39 (StellarChemistry, en frío, 30-oct), los otros
   // cinco estaban a los 15 s y no se veía nada hasta los 40,3 s, los que tardaba GALAH en quedarse sin servidor (IDIA y NAO no la tienen; CfA calla 21 s). Aquí, con el lote, se
   // espera a TODOS pero cada survey que llega ya se pinta (parciales de siempre, sin estado). `peek` no gasta la respuesta: el bucle de abajo la lee igual que antes (el resultado
   // final no cambia). Costura roja: CC_BREAK=fixedorder (o ccBroken), en orden fijo como hasta hoy.
   var drained = false;
   if (H && typeof H.peek === "function" && typeof o.onPartial === "function" && !ccEngineBreak("fixedorder")) {
      var early = {}, seen = {}, left = 0, s1, sk, fresh = false, lastArr = Date.now(), goneAhead = false, anyRows = false;
      for (s1 = 0; s1 < surveys.length; ++s1) { early[surveys[s1]] = []; if (want[surveys[s1]] !== false) ++left; }
      drained = true;
      while (left > 0) {
         var firstLeft = -1;
         for (s1 = 0; s1 < surveys.length; ++s1) {
            sk = surveys[s1];
            if (seen[sk] || want[sk] === false) continue;
            var ad1 = CC_CAT[sk].adql(poly), got1 = H.peek(ad1, sk);
            if (!got1 && H.waiting(ad1, sk)) { if (firstLeft < 0) firstLeft = s1; continue; }
            seen[sk] = true; --left; lastArr = Date.now();
            if (got1 && got1.ok && ccLooksLikeCsv(got1.text, mustCol[sk])) {
               try {
                  var pr1 = ccParseCsv(got1.text), li1 = [];
                  for (var j1 = 0; j1 < pr1.rows.length; ++j1) { var re1 = CC_PARSE[sk](pr1.rows[j1]); if (re1) li1.push(re1); }
                  early[sk] = ccBestPerStar(li1);
                  if (early[sk].length) { fresh = true; anyRows = true; }
               } catch (eEarly) {}
            }
         }
         if (firstLeft >= 0) { step = 2 + firstLeft; tell(surveys[firstLeft]); }
         // (lo llegado se pinta en cuanto toca —el mismo limite que los parciales de siempre— aunque no llegue nada mas: `fresh` espera su turno)
         if (fresh && Date.now() - lastPart >= Math.max(CC_PARTIAL_GAP_MS, 4 * partCost)) { fresh = false; partial(ccBuildStars(early, surveys).stars, false, true); }
         // lo que pide por id (Gaia, Boin, Kordopatis) no espera al callado: a los CC_AHEAD_MS sin que llegue nada, sale con las estrellas que ya hay. Si despues llega el que faltaba
         // con estrellas nuevas, el paso de abajo pide lo que falte (mismas consultas -> el lote no las repite; ids nuevos -> otra consulta y, por los espejos, el mismo cono ya bajado).
         if (left > 0 && !goneAhead && anyRows && Date.now() - lastArr >= CC_AHEAD_MS) {
            goneAhead = true;
            try { H.add(ccSecondItems(ccBuildStars(early, surveys).stars)); } catch (eA1) {}
         }
         if (left > 0) H.wait(100);
      }
   }

   // 2 · los surveys (por polígono)
   var recs = {};
   for (i = 0; i < surveys.length; ++i) {
      var k = surveys[i];
      step = 2 + i; tell(k);
      if (want[k] === false) { res.queries.push({ key: k, label: CC_CAT[k].label, ok: false, rows: 0, used: 0, ms: 0, message: "off", cached: false }); recs[k] = []; continue; }
      var a = ask(k, CC_CAT[k].label, CC_CAT[k].adql(poly), mustCol[k]);
      var list = [];
      for (var j = 0; j < a.rows.length; ++j) { var rec = CC_PARSE[k](a.rows[j]); if (rec) list.push(rec); }
      list = ccBestPerStar(list);
      a.q.used = list.length;
      recs[k] = list;
      if (!drained && i < surveys.length - 1 && typeof o.onPartial === "function") {      // (con el lote ya se enseño todo arriba: aqui, en orden fijo, se volveria atras)
         var soFar = {}; for (var sf = 0; sf < surveys.length; ++sf) soFar[surveys[sf]] = recs[surveys[sf]] || [];
         if (Date.now() - lastPart >= Math.max(CC_PARTIAL_GAP_MS, 4 * partCost)) partial(ccBuildStars(soFar, surveys).stars, false, false);
      }
   }

   // 3 · LAMOST DR5 de Xiang (sin id de Gaia) con el id de DR11 y 4 · las estrellas (ccBuildStars: una por id de Gaia; las que no
   //     lo tienen, por posición, 1,5")
   var built = ccBuildStars(recs, surveys), stars = built.stars, byId = built.byId;

   // (22-oct, noche) lo que piden POR ID (Gaia, Boin, Kordopatis) sale ya, todo a la vez; los ids son los de estas estrellas, que
   // no cambian de aquí al final (las consultas, idénticas a las de la serie: misma caché, mismas respuestas grabadas)
   if (H && !res.netDown) {
      try { H.add(ccSecondItems(stars)); } catch (eA2) {}
   }
   partial(stars, true, true);                   // (la química de los surveys, ya en la foto y en el diagrama de química; falta Gaia y las edades)

   // 5 · Gaia DR3 (+ Bailer-Jones + FLAME) para todas las que tienen id
   step = 8; tell("gaia");
   var ids = [];
   for (i = 0; i < stars.length; ++i) if (stars[i].id) ids.push(stars[i].id);
   var chunks = ccChunks(ids, CC_IN_CHUNK), gq = { rows: 0, used: 0, ok: true, ms: 0, msg: "", cached: true };
   for (var c = 0; c < chunks.length; ++c) {
      tell("gaia", { chunk: c + 1, of: chunks.length });
      var ga = ask("gaia", "Gaia DR3 + Bailer-Jones + FLAME", ccGaiaAdql(chunks[c]), "Source");
      res.queries.pop();   // se resumen en una sola fila, abajo
      gq.ms += ga.q.ms; gq.rows += ga.q.rows; gq.cached = gq.cached && ga.q.cached;
      if (!ga.q.ok) { gq.ok = false; gq.msg = ga.q.message; }
      for (j = 0; j < ga.rows.length; ++j) {
         var gr = ga.rows[j], gs = byId[ccGaiaId(gr.Source)];
         if (!gs) continue;
         ++gq.used;
         gs.gaia = gr;
      }
   }
   // (sin ids no hay nada que preguntar: no es un fallo — el campo vacío de las pruebas lo marcaba en rojo)
   res.queries.push({ key: "gaia", label: "Gaia DR3 + Bailer-Jones + FLAME", ok: gq.ok, rows: gq.rows, used: gq.used, ms: gq.ms, message: gq.msg, cached: gq.cached });
   partial(stars, true, true);                   // (con Gaia: posiciones, distancias y cinemática; faltan las edades)

   // 6 · edades
   step = 9; tell("xr22");
   var xr = ask("xr22", CC_CAT.xr22.label, CC_CAT.xr22.adql(poly), "Age");
   var sIdx = ccPosIndex(stars, 3);
   for (i = 0; i < xr.rows.length; ++i) {
      var xa = xr.rows[i], xs = sIdx.near(ccNum(xa.RAJ2000), ccNum(xa.DEJ2000), 1.5);
      if (!xs) continue;
      ++xr.q.used;
      xs.item.ages.push({ src: "xr22", v: ccNum(xa.Age), e: ccNum(xa["e_Age"]), method: "subgiant isochrone" });
      xs.item.actions = { JR: ccNum(xa.JR), Jphi: ccNum(xa.JPHI), JZ: ccNum(xa.JZ), src: "xr22" };
   }
   step = 10; tell("anders");
   var byApogee = {};
   for (i = 0; i < stars.length; ++i) if (stars[i].recs.apogee && stars[i].recs.apogee.name) byApogee[stars[i].recs.apogee.name] = stars[i];
   var an = ask("anders", CC_CAT.anders.label, CC_CAT.anders.adql(poly), "spAgeCal");
   for (i = 0; i < an.rows.length; ++i) {
      var ar = an.rows[i], as = byApogee[ccStr(ar.APOGEE)];
      if (!as) continue;
      ++an.q.used;
      // (27-oct, E3) `f_spAge` es TEXTO (BLUER_THAN_TRAINING_SET…): ccAndersFlag decide qué lo descarta y qué solo lo marca (cc_science.js)
      var fl = ccAndersFlag(ar["f_spAge"]);
      as.ages.push({ src: "anders23", v: ccNum(ar.spAgeCal), e: ccNum(ar["e_spAge"]), flag: fl.reject, warn: fl.warn, flagText: ccStr(ar["f_spAge"]), method: "XGBoost on APOGEE spectra (C/N), asteroseismic training" });
   }
   step = 11; tell("boin");
   var bq = { rows: 0, used: 0, ok: true, ms: 0, msg: "", cached: true, n: 0 };
   for (var sv in CC_BOIN_TABLES) if (CC_BOIN_TABLES.hasOwnProperty(sv)) {
      var sids = [];
      for (i = 0; i < stars.length; ++i) if (stars[i].id && stars[i].recs[sv]) sids.push(stars[i].id);
      var bch = ccChunks(sids, CC_IN_CHUNK);
      for (c = 0; c < bch.length; ++c) {
         var bo = ask("boin-" + sv, "Boin+26 ages (" + sv + ")", ccBoinAdql(CC_BOIN_TABLES[sv], bch[c]), "GaiaDR3");
         res.queries.pop(); ++bq.n;
         bq.ms += bo.q.ms; bq.rows += bo.q.rows; bq.cached = bq.cached && bo.q.cached;
         if (!bo.q.ok) { bq.ok = false; bq.msg = bo.q.message; }
         for (j = 0; j < bo.rows.length; ++j) {
            var br = bo.rows[j], bs = byId[ccGaiaId(br.GaiaDR3)];
            if (!bs) continue;
            var grids = [];
            for (var gI = 0; gI < CC_BOIN_GRIDS.length; ++gI) {
               var G = CC_BOIN_GRIDS[gI];
               grids.push({ grid: G, median: ccNum(br["Age" + G + "median"]), std: ccNum(br["Age" + G + "std"]), inDomain: ccNum(br["inDomain" + G]) === 1 });
            }
            var cg = ccCombineGrids(grids);
            if (cg) { ++bq.used; bs.ages.push({ src: "boin", v: cg.v, e: cg.e, method: "isochrone NN, " + cg.n + " grids (" + sv + " parameters)", grids: grids, sys: cg.sys, stat: cg.stat, survey: sv }); }
         }
      }
   }
   res.queries.push({ key: "boin", label: "Boin+26 ages (GALAH/APOGEE/LAMOST)", ok: bq.ok, rows: bq.rows, used: bq.used, ms: bq.ms, message: bq.msg, cached: bq.cached });

   step = 12; tell("kord");
   var kids = [];
   for (i = 0; i < stars.length; ++i) if (stars[i].id) kids.push(stars[i].id);   // (Kordopatis tiene su propia selección de calidad)
   var kq = { rows: 0, used: 0, ok: true, ms: 0, msg: "", cached: true, n: 0 };
   var kch = ccChunks(kids, CC_IN_CHUNK);
   for (c = 0; c < kch.length; ++c) {
      var ko = ask("kord", "Kordopatis+23", ccKordAdql(kch[c]), "GaiaDR3");
      res.queries.pop(); ++kq.n;
      kq.ms += ko.q.ms; kq.rows += ko.q.rows; kq.cached = kq.cached && ko.q.cached;
      if (!ko.q.ok) { kq.ok = false; kq.msg = ko.q.message; }
      for (j = 0; j < ko.rows.length; ++j) {
         var kr = ko.rows[j], ks = byId[ccGaiaId(kr.GaiaDR3)];
         if (!ks) continue;
         ++kq.used;
         var kv = ccNum(kr.age);
         if (kv !== null) ks.ages.push({ src: "kord23", v: kv, e: ccNum(kr["e_age"]), method: "isochrone projection of calibrated GSP-Spec" });
         ks.orbit = { Lz: ccNum(kr.Lzdgeo), ecc: ccNum(kr.edgeo), zmax: ccNum(kr.Zmaxdgeo), JR: ccNum(kr.Jrdgeo), src: "kord23" };
      }
   }
   res.queries.push({ key: "kord", label: "Kordopatis+23 (orbits, ages)", ok: kq.ok, rows: kq.rows, used: kq.used, ms: kq.ms, message: kq.msg, cached: kq.cached });

   try { if (typeof cshVzReadMemoClear === "function") cshVzReadMemoClear(); } catch (eVzM) {}     // (ya no quedan montajes: las filas de las respuestas grandes se sueltan)
   // 7a · la base Gaia local no trae id: se casa por POSICIÓN (ccMatchLocal)
   ccMatchLocal(stars, locIdx);
   // 7 · cada estrella: posición, Gaia, distancia, RV, química, edad, cinemática, población
   for (i = 0; i < stars.length; ++i) { ccFinishStar(stars[i], field); ccFinishPulse(i, o.pulse); }

   // 8 · chemical tagging (dentro de cada survey)
   var tagStars = [];
   for (i = 0; i < stars.length; ++i) if (stars[i].inFrame) tagStars.push(stars[i]);
   // Solo alta resolución (GALAH R~28 000, APOGEE R~22 500). LAMOST (R~1 800) se probó en
   // los campos de prueba: 43 % de pares «compatibles» en Abell 39, sin co-movimiento:
   // con esa precisión la química no separa familias (tests/cc_node_run_live.log).
   var tsv = ["galah", "apogee"];
   for (i = 0; i < tsv.length; ++i) res.tagging.push(ccTagging(tagStars, tsv[i]));

   res.stars = stars;
   res.coverage = ccCoverage(stars, gHist, res.queries);
   res.status = ccFieldStatus(res);
   res.ok = true;
   res.timings.totalMs = Date.now() - t0;
   return res;
   }   // (ccRunSteps)
}
var CC_PARTIAL_GAP_MS = 600;      // diseño: como mucho un resultado parcial cada 0,6 s (la vista se repinta entera en cada uno)
var CC_AHEAD_MS = 2500;           // (30-oct-2026) sin que llegue ningun survey en este tiempo, lo que pide por id sale sin esperar al que falta (medido el 30-oct: IDIA sirve los suyos en < 3,7 s)
// Lo que pide POR ID (Gaia, Boin, Kordopatis) de estas estrellas: el segundo lote de ccRun (las consultas, identicas a las de la serie: misma cache, mismas respuestas grabadas).
function ccSecondItems(stars) {
   var ids = [], out = [], i, c, sv;
   for (i = 0; i < stars.length; ++i) if (stars[i].id) ids.push(stars[i].id);
   var ch = ccChunks(ids, CC_IN_CHUNK);
   for (c = 0; c < ch.length; ++c) out.push({ key: "gaia", adql: ccGaiaAdql(ch[c]) });
   for (sv in CC_BOIN_TABLES) if (CC_BOIN_TABLES.hasOwnProperty(sv)) {
      var bs = []; for (i = 0; i < stars.length; ++i) if (stars[i].id && stars[i].recs[sv]) bs.push(stars[i].id);
      var bc = ccChunks(bs, CC_IN_CHUNK);
      for (c = 0; c < bc.length; ++c) out.push({ key: "boin-" + sv, adql: ccBoinAdql(CC_BOIN_TABLES[sv], bc[c]) });
   }
   for (c = 0; c < ch.length; ++c) out.push({ key: "kord", adql: ccKordAdql(ch[c]) });
   return out;
}
// Las consultas que no dependen de ninguna otra (los surveys, las edades de Xiang & Rix y de Anders; el recuento si no hay Gaia local): el primer lote de ccRun.
// Fuera de ccRun para poder lanzarlas ANTES (CabraStarAnalysis, mientras la red del 3D: csa_dialog.js _chemAhead). hasLocal = hay base Gaia local.
function ccFirstItems(field, want, hasLocal) {
   var poly = field.polygon, W = want || {}, S = ["galah", "apogee", "lamost", "x19", "gspspec", "xpg"], first = [];
   if (!hasLocal) first.push({ key: "count", adql: CC_CAT.count.adql(poly) });
   for (var i = 0; i < S.length; ++i) if (W[S[i]] !== false) first.push({ key: S[i], adql: CC_CAT[S[i]].adql(poly) });
   first.push({ key: "xr22", adql: CC_CAT.xr22.adql(poly) }, { key: "anders", adql: CC_CAT.anders.adql(poly) });
   return first;
}

// Pasos 3 y 4 de ccRun (sacados a una función el 22-oct para los resultados parciales; el código es el de siempre):
// LAMOST DR5 de Xiang (sin id de Gaia) recibe el de la fila de DR11 que cae a menos de 2" (las fibras apuntan a las mismas
// coordenadas de entrada); después, una estrella por id de Gaia y las que no lo tienen, por posición (1,5"). -> { stars, byId }
function ccBuildStars(recs, surveys) {
   var i, j, lamIdx = ccPosIndex(recs.lamost || [], 4), x19 = recs.x19 || [];
   for (i = 0; i < x19.length; ++i) {
      var x = x19[i], m = lamIdx.near(x.ra, x.dec, 2.0);
      if (m && m.item.id) x.id = m.item.id;
   }
   var stars = [], byId = {}, all = [];
   for (i = 0; i < surveys.length; ++i) for (j = 0; j < (recs[surveys[i]] || []).length; ++j) all.push(recs[surveys[i]][j]);
   var posIdx = null, posPending = [];
   function newStar(r) {
      var s = { idx: stars.length, id: r.id || "", name: r.name || "", ra: r.ra, dec: r.dec, recs: {}, ages: [] };
      stars.push(s);
      if (s.id) byId[s.id] = s;
      return s;
   }
   for (i = 0; i < all.length; ++i) {
      var r0 = all[i];
      if (!r0.id) { posPending.push(r0); continue; }
      var s0 = byId[r0.id] || newStar(r0);
      if (!s0.recs[r0.survey]) s0.recs[r0.survey] = r0;
   }
   posIdx = ccPosIndex(stars, 3);
   for (i = 0; i < posPending.length; ++i) {
      var rp = posPending[i], mm = posIdx.near(rp.ra, rp.dec, 1.5);
      var sp = mm ? mm.item : newStar(rp);
      if (!sp.recs[rp.survey]) sp.recs[rp.survey] = rp;
   }
   return { stars: stars, byId: byId };
}
// Paso 7a: la base Gaia local no trae id: se casa por POSICIÓN (0,5" con la posición de Gaia por internet; 1,5" con la del survey).
function ccMatchLocal(stars, locIdx) {
   if (!locIdx) return;
   for (var i = 0; i < stars.length; ++i) {
      var st7 = stars[i], g7 = st7.gaia, ra7 = g7 ? ccNum(g7.RA_ICRS) : st7.ra, de7 = g7 ? ccNum(g7.DE_ICRS) : st7.dec;
      if (!ccIsNum(ra7) || !ccIsNum(de7)) continue;
      var m7 = locIdx.near(ra7, de7, g7 ? 0.5 : 1.5);
      if (m7) st7.gaiaLocal = m7.item;
   }
}
// Paso 1 con la base local: el recuento por magnitud y las estrellas G < 17 del encuadre, proyectadas en la foto. Dentro del
// encuadre: por el POLÍGONO (barato); proyectar con la solución de la foto es caro (10 s con 20 000 estrellas de Abell 39, medido
// en T9 el 15-oct): solo se proyectan las que se pintan (G < 17). Lo usan ccRun y la vista previa del diálogo (la foto al abrir).
function ccGaiaFieldStars(GL, field, pulse) {
   var out = { gHist: {}, gaiaField: [], nIn: 0 }, inPoly = ccPolyTest(field.polygon, field.ra, field.dec);
   for (var i = 0; i < GL.rows.length; ++i) {
      var lr = GL.rows[i];
      if (i % 2000 === 0 && typeof pulse === "function") { try { pulse(); } catch (eP) {} }
      if (!ccIsNum(lr.g) || !inPoly(lr.ra, lr.dec)) continue;
      ++out.nIn; var gbl = Math.floor(lr.g); out.gHist[gbl] = (out.gHist[gbl] || 0) + 1;
      if (lr.g < 17) { var pp = field.project(lr.ra, lr.dec); if (pp && ccIsNum(pp.x)) out.gaiaField.push({ x: pp.x, y: pp.y, g: lr.g, bpRp: (ccIsNum(lr.bp) && ccIsNum(lr.rp)) ? lr.bp - lr.rp : null }); }
   }
   return out;
}
// Un resultado PARCIAL (lo que ya se sabe): las estrellas `src` (copias si `clone`: las de ccRun siguen recibiendo datos) terminadas
// con ccFinishStar, su cobertura y las consultas hechas; sin estado (`status: null`: no es «no hay estrellas», es «aún no»).
// (30-oct-2026) Terminar las estrellas, cediendo a la interfaz. Medido en Pleyades con CJ_PROFILE: 10 788 estrellas, 4,2 s seguidos con la ventana parada, en el parcial grande y otra vez al final.
// Entre dos estrellas (nunca a media), como ccGaiaFieldStars. Rojo: CC_BREAK=nofinishpulse.
var CC_FINISH_PULSE_MASK = 511;
function ccFinishPulse(i, pulse) {
   if ((i & CC_FINISH_PULSE_MASK) !== CC_FINISH_PULSE_MASK || typeof pulse !== "function" || ccEngineBreak("nofinishpulse")) return;
   try { pulse(); } catch (eP) {}
}
function ccPartialResult(res, field, src, gHist, locIdx, clone, t0, pulse) {
   var stars = [], i;
   for (i = 0; i < src.length; ++i) {
      var s = src[i];
      stars.push(clone ? { idx: s.idx, id: s.id, name: s.name, ra: s.ra, dec: s.dec, recs: s.recs, ages: (s.ages || []).slice(), gaia: s.gaia, actions: s.actions, orbit: s.orbit } : s);
   }
   ccMatchLocal(stars, locIdx);
   for (i = 0; i < stars.length; ++i) { ccFinishStar(stars[i], field); ccFinishPulse(i, pulse); }
   var p = ccEmptyResult(field);
   p.ok = true; p.partial = true; p.status = null;
   p.queries = res.queries.slice(); p.stars = stars; p.gaiaField = res.gaiaField; p.gaiaLocal = res.gaiaLocal;
   p.coverage = ccCoverage(stars, gHist, p.queries);
   p.timings = { totalMs: Date.now() - t0, netMs: res.timings.netMs };
   return p;
}

// ¿ES ESTA ESTRELLA la fuente de Gaia que dice el survey? (C1, 23-oct-2026; docs/contradicciones_ficha.md)
// Compara la posición de los surveys que dan la de 2MASS (APOGEE, GALAH; época ~2000) con la de Gaia DR3 llevada a J2000 con su pm.
// Tolerancia CC_SCI.XMATCH_ARCSEC + |pm|·XMATCH_EPOCH_YR (medido: las buenas, ≤ 1,27"; la de C1, 2,55"). LAMOST y Xiang+19 no
// cuentan (posición de la fibra). -> null si no hay con qué comparar; si no { ok, bad: [survey], good: [survey], sep: {survey: "}, tol }
//   ok = false  -> TODOS los de 2MASS discrepan: el número de Gaia es de OTRA estrella (se descarta Gaia, no el espectro)
//   bad con ok  -> unos casan y otros no: los que no casan son de otra estrella (se descarta ESE registro)
function ccXmatchCheck(s, g) {
   if (!g || !s || !s.recs) return null;
   var ra = ccNum(g.RA_ICRS), de = ccNum(g.DE_ICRS), pa = ccNum(g.pmRA), pd = ccNum(g.pmDE);
   if (!ccIsNum(ra) || !ccIsNum(de)) return null;
   var pm = (ccIsNum(pa) && ccIsNum(pd)) ? Math.sqrt(pa * pa + pd * pd) : 0;
   if (ccIsNum(pa) && ccIsNum(pd)) { ra -= pa * 16 / 3.6e6 / Math.max(0.01, Math.cos(de * Math.PI / 180)); de -= pd * 16 / 3.6e6; }
   var tol = CC_SCI.XMATCH_ARCSEC + pm / 1000 * CC_SCI.XMATCH_EPOCH_YR, out = { ok: true, bad: [], good: [], sep: {}, tol: tol, id: s.id }, sv = ["apogee", "galah"];
   for (var i = 0; i < sv.length; ++i) {
      var r = s.recs[sv[i]];
      if (!r || !ccIsNum(r.ra) || !ccIsNum(r.dec)) continue;
      var d = ccSepArcsec(r.ra, r.dec, ra, de);
      out.sep[sv[i]] = d;
      (d > tol ? out.bad : out.good).push(sv[i]);
   }
   if (!out.bad.length && !out.good.length) return null;
   out.ok = out.good.length > 0;
   return out;
}
// (30-oct, decisión D de Nino) La RV de Gaia DR3 con el sesgo de magnitud corregido: la MISMA receta que CabraStars y Cabra3D (cshRvCorrect, CabraShared/csh_net.js; las columnas vienen en ccGaiaAdql).
// `vCat` = la del catálogo; `corr` = "katz" | "blomme" | "none" (no le toca) | "no-info" (sin datos: sin corregir, y la ficha lo dice). Las RV de APOGEE, GALAH y LAMOST no llevan esta corrección: es de Gaia.
function ccGaiaRv(g) {
   var cat = ccNum(g.RV), c = (typeof cshRvCorrect === "function") ? cshRvCorrect(cat, ccNum(g.GRVSmag), ccNum(g.RVtempTeff)) : { v: cat, cat: cat, kind: "no-info" };
   return { v: c.v, e: ccNum(g["e_RV"]), src: "Gaia DR3", vCat: c.cat, corr: c.kind };
}
// La velocidad radial de OTRO catálogo que no casa con la adoptada (C3, 23-oct-2026): > RV_DISC_SIG σ combinadas y > RV_DISC_KMS.
// -> null | { v, e, src, dv } (la más discrepante)
function ccRvAlt(s, g) {
   if (!s.rv || !ccIsNum(s.rv.v)) return null;
   var c = [], best = null, k;
   var lab = { apogee: "APOGEE DR17", galah: "GALAH DR4", lamost: "LAMOST DR11" };
   for (k in lab) if (lab.hasOwnProperty(k) && s.recs[k] && s.recs[k].rv && ccIsNum(s.recs[k].rv.v)) c.push({ v: s.recs[k].rv.v, e: s.recs[k].rv.e, src: lab[k] });
   if (g && ccNum(g.RV) !== null) c.push(ccGaiaRv(g));
   for (var i = 0; i < c.length; ++i) {
      if (c[i].src === s.rv.src) continue;
      var e1 = ccIsNum(s.rv.e) ? s.rv.e : 5, e2 = ccIsNum(c[i].e) ? c[i].e : 5, dv = c[i].v - s.rv.v, sg = Math.sqrt(e1 * e1 + e2 * e2);
      if (Math.abs(dv) > CC_SCI.RV_DISC_KMS && Math.abs(dv) > CC_SCI.RV_DISC_SIG * sg && (!best || Math.abs(dv) > Math.abs(best.dv))) best = { v: c[i].v, e: c[i].e, src: c[i].src, dv: dv };
   }
   return best;
}

// Completa una estrella (también se usa en los tests con estrellas hechas a mano).
function ccFinishStar(s, field) {
   var g = s.gaia || null;
   // (C1) el número de Gaia del survey, ¿es de esta estrella? Si no, su astrometría (distancia, pm, G, edades de Gaia) es de OTRA
   s.xmatch = ccEngineBreak("sci-noxmatch") ? null : ccXmatchCheck(s, g);
   var xbad = !!(s.xmatch && !s.xmatch.ok);
   // (una COPIA de los registros sin los que no son de esta estrella: las copias de los resultados parciales comparten `recs`)
   function ccXmDrop(keys) { var r2 = {}, out = []; for (var kx in s.recs) if (s.recs.hasOwnProperty(kx)) { if (keys.indexOf(kx) >= 0) out.push(kx); else r2[kx] = s.recs[kx]; } s.recs = r2; return out; }
   if (s.xmatch && s.xmatch.ok && s.xmatch.bad.length) {
      // unos casan y otros no: el registro que no casa es de otra estrella (lo trajo el mismo número de Gaia): fuera
      s.xmatch.dropped = ccXmDrop(s.xmatch.bad);
   }
   if (xbad) {
      // lo que viene POR el número de Gaia es de la otra estrella: GSP-Spec y XP (por Source), Kordopatis (edad y órbita), FLAME
      s.xmatch.dropped = ccXmDrop(["gspspec", "xpg"]);
      var keepAges = [];
      for (var xa = 0; xa < (s.ages || []).length; ++xa) if (s.ages[xa].src !== "kord23" && s.ages[xa].src !== "flame") keepAges.push(s.ages[xa]); else s.xmatch.dropped.push(s.ages[xa].src);
      s.ages = keepAges; s.orbit = null;
      var rx = s.recs[s.xmatch.bad[0]];
      g = null;
      s.ra = rx.ra; s.dec = rx.dec; s.g = null; s.bpRp = null; s.plx = null; s.ePlx = null;
      s.pmra = null; s.pmdec = null; s.epmra = null; s.epmdec = null; s.ruwe = null;
   }
   if (g) {
      s.ra = ccNum(g.RA_ICRS); s.dec = ccNum(g.DE_ICRS);
      s.g = ccNum(g.Gmag); s.bpRp = ccNum(g["BP-RP"]); s.plx = ccNum(g.Plx); s.ePlx = ccNum(g["e_Plx"]);
      s.pmra = ccNum(g.pmRA); s.pmdec = ccNum(g.pmDE); s.epmra = ccNum(g["e_pmRA"]); s.epmdec = ccNum(g["e_pmDE"]); s.ruwe = ccNum(g.RUWE);
   }
   var L = xbad ? null : (s.gaiaLocal || null);     // (la base local se casó con la posición de la OTRA estrella)
   if (L && !g) {
      s.ra = L.ra; s.dec = L.dec; s.g = L.g; s.bpRp = (ccIsNum(L.bp) && ccIsNum(L.rp)) ? L.bp - L.rp : null;
      s.plx = L.plx; s.pmra = L.pmra; s.pmdec = L.pmdec;     // (sin errores: la base local no los trae)
   }
   s.astroSrc = g ? (L ? "both" : "net") : (L ? "local" : "");
   // posición en la foto (con el movimiento propio llevado a la época de la imagen)
   s.x = null; s.y = null; s.inFrame = false;
   if (field && typeof field.project === "function" && ccIsNum(s.ra) && ccIsNum(s.dec)) {
      var ra = s.ra, dec = s.dec, yrs = ccIsNum(field.epochYears) ? field.epochYears : 0;
      if (ccIsNum(s.pmra) && ccIsNum(s.pmdec) && yrs !== 0) {
         ra += s.pmra * yrs / 3.6e6 / Math.max(0.01, Math.cos(dec * Math.PI / 180));
         dec += s.pmdec * yrs / 3.6e6;
      }
      var p = field.project(ra, dec);
      if (p && ccIsNum(p.x) && ccIsNum(p.y)) {
         s.x = p.x; s.y = p.y;
         s.inFrame = (p.x >= 0 && p.y >= 0 && p.x < field.width && p.y < field.height);
      }
   }
   // distancia: Bailer-Jones geométrica > la del survey > 1/paralaje si paralaje/error > 5
   s.dist = null;
   if (g && ccNum(g.rgeo) !== null) s.dist = { pc: ccNum(g.rgeo), lo: ccNum(g["b_rgeo"]), hi: ccNum(g["B_rgeo"]), src: "Bailer-Jones+21 (geo)" };
   // (las de los surveys salen del MISMO número de Gaia: APOGEE trae la de Bailer-Jones de su id; con el id equivocado, ninguna vale)
   if (!s.dist && !xbad) for (var k in s.recs) if (s.recs.hasOwnProperty(k) && s.recs[k].dist && !s.dist) s.dist = { pc: s.recs[k].dist.pc, lo: s.recs[k].dist.lo, hi: s.recs[k].dist.hi, src: CC_SURVEY_LABEL[k] };
   if (!s.dist && ccIsNum(s.plx) && ccIsNum(s.ePlx) && s.plx > 0 && s.plx / s.ePlx > 5)
      s.dist = { pc: 1000 / s.plx, lo: 1000 / (s.plx + s.ePlx), hi: 1000 / (s.plx - s.ePlx), src: "1/parallax" };
   // velocidad radial: APOGEE (multiépoca) > GALAH > Gaia > LAMOST
   s.rv = null;
   var rvOrder = ["apogee", "galah"];
   for (var r = 0; r < rvOrder.length && !s.rv; ++r) { var rr = s.recs[rvOrder[r]]; if (rr && rr.rv && ccIsNum(rr.rv.v)) s.rv = { v: rr.rv.v, e: rr.rv.e, scatter: rr.rv.scatter, src: CC_SURVEY_LABEL[rvOrder[r]] }; }
   if (!s.rv && g && ccNum(g.RV) !== null) s.rv = ccGaiaRv(g);
   if (!s.rv && s.recs.lamost && s.recs.lamost.rv && ccIsNum(s.recs.lamost.rv.v)) s.rv = { v: s.recs.lamost.rv.v, e: s.recs.lamost.rv.e, src: "LAMOST DR11" };
   if (s.rv && !ccIsNum(s.rv.e)) s.rv.e = 5;
   if (s.rv) s.rv.alt = ccEngineBreak("sci-norvdisc") ? null : ccRvAlt(s, g);     // (C3) otra RV que no casa con esta
   // (P6, 23-oct) si otro catálogo da una RV que no casa, la discrepancia entra en el ERROR con que se sortean la cinemática y la familia:
   //   e = sqrt(e_cat² + Δv²)   (Δv = la otra − la adoptada; así la otra queda a 1 σ: no se sabe cuál de las dos es la buena)
   // El centro sigue siendo la adoptada (la prioridad de RV no cambia: GALAH − APOGEE σ 0,32 km/s, medido). `eRaw` = el del catálogo.
   if (s.rv && s.rv.alt && !ccEngineBreak("sci-norvinfl")) { s.rv.eRaw = s.rv.e; s.rv.eDisc = Math.abs(s.rv.alt.dv); s.rv.e = Math.sqrt(s.rv.e * s.rv.e + s.rv.alt.dv * s.rv.alt.dv); }
   // química
   s.chem = ccAdoptChem(s.recs);
   s.chemClass = ccChemClass(s.chem);
   // edades: las de los surveys de edad + la isócrona de GALAH + FLAME
   s.ages = s.ages || [];
   if (s.recs.galah && s.recs.galah.isoAge) s.ages.push(s.recs.galah.isoAge);
   if (g && ccNum(g["Age-Flame"]) !== null) {
      // (28-oct, pendiente 8) la bandera por DÍGITOS (ccFlameFlag, cc_science.js): A=0 vale con cualquier B (antes, B = 1 o 2 la tumbaba),
      // A=1 gigante solo con 1–2 M☉ y > 1 Ga (y entonces orientativa), A=2 sin edad. Mass-Flame ya venía en la consulta (ccGaiaAdql).
      var flM = ccNum(g["Mass-Flame"]), flA = ccNum(g["Age-Flame"]), ff = ccFlameFlag(g["Flags-Flame"], flM, flA);
      s.ages.push({ src: "flame", v: flA, lo: ccNum(g["b_Age-Flame"]), hi: ccNum(g["B_Age-Flame"]), flag: ff.reject, flagWhy: ff.why, giant: ff.giant && !ff.reject,
                    mass: flM, flameA: ff.a, flameB: ff.b, method: "Gaia DR3 FLAME (solar metallicity)" });
   }
   s.age = ccAdoptAge(s.ages, s.chem.feh ? s.chem.feh.v : null, s.chem.logg);
   // cinemática
   // (30-oct, N1 + D1-H5, decisión B de Nino) LA PUERTA DE CALIDAD: RUWE ≥ 1,4 o distancia con más de un 20 % de error. La misma regla que CabraStars (cshAstroDoubt, CabraShared/csh_kinpop.js).
   // Sin población cinemática y sin familia; la órbita SE QUEDA, con su aviso (ccCardWarnings, ccStarStory). Costura roja «sci-noastrogate»: lo de antes.
   var noGate = ccEngineBreak("sci-noastrogate");
   s.astroDoubt = (!noGate && typeof cshAstroDoubt === "function") ? cshAstroDoubt(s.ruwe, s.dist) : null;
   s.kin = ccKinematics({ id: s.id || s.name, ra: s.ra, dec: s.dec, pmra: s.pmra, pmdec: s.pmdec, epmra: s.epmra, epmdec: s.epmdec, dist: s.dist, rv: s.rv, ruwe: noGate ? null : s.ruwe });
   if (s.kin && s.orbit && ccIsNum(s.orbit.Lz)) s.kin.gc.LzCat = s.orbit.Lz;
   // la familia cinemática (E, Lz, órbita; cc_dynamics.js) con su probabilidad
   s.fam = (typeof ccFamilies === "function") ? ccFamilies({ id: s.id || s.name, ra: s.ra, dec: s.dec, pmra: s.pmra, pmdec: s.pmdec, epmra: s.epmra, epmdec: s.epmdec, dist: s.dist, rv: s.rv },
                                                          s.chem.feh ? s.chem.feh.v : null, s.chem.pair ? s.chem.pair.alpha : null) : null;
   // Sin familia con astrometría dudosa: lo que dio el árbol se guarda aparte (bestRaw, pRaw: solo para las pruebas y el informe) y best se queda vacío. La no ligada no pasa por aquí:
   // ya dice que el dato puede ser malo, y es lo que debe enseñar la ficha.
   if (s.fam && s.astroDoubt && s.fam.best !== "unbound") { s.fam.bestRaw = s.fam.best; s.fam.pRaw = s.fam.p; s.fam.best = ""; s.fam.p = null; s.fam.accreted = false; s.fam.doubt = s.astroDoubt.why; }
   // Una no ligada tampoco da población por su movimiento: esa velocidad es lo que está en duda (N2). Sus velocidades (Toomre, Lz) se quedan; las probabilidades, no.
   if (s.fam && s.fam.best === "unbound" && s.kin && s.kin.probs) { s.kin.probs = null; s.kin.best = ""; s.kin.cls = ""; s.kin.verdict = "no-data"; s.kin.why = "unbound"; }
   // (C3) con otra RV que no casa, la órbita también con ella: si la Zmax cambia mucho, «no está bien medida» (HD 140283: 2,27 / 5,40)
   if (s.fam && s.fam.orbit && s.fam.orbit.bound && s.rv && s.rv.alt && typeof ccDynState === "function") {
      var dA = ccDynState(s.ra, s.dec, s.dist.pc, s.pmra, s.pmdec, s.rv.alt.v), oA = ccOrbit(dA);
      s.fam.orbitAlt = { rv: s.rv.alt.v, src: s.rv.alt.src, rperi: oA.rperi, rapo: oA.rapo, zmax: oA.zmax, ecc: oA.ecc, bound: oA.bound };
      var z0 = s.fam.orbit.zmax, z1 = oA.zmax;
      s.fam.zmaxUnstable = !!(oA.bound && ccIsNum(z0) && ccIsNum(z1) && Math.abs(z1 - z0) > CC_SCI.ZMAX_UNSTABLE_KPC && Math.abs(z1 - z0) > CC_SCI.ZMAX_UNSTABLE_FRAC * Math.max(z0, z1));
   }
   // (P7, 23-oct) la Zmax es solo aproximada si es inestable o si el pericentro pasa a < CC_SCI.ZMAX_PERI_KPC del centro (depende del potencial):
   // se marca en la familia y en la propia órbita (ccZmaxText de cc_story.js le pone «≈»)
   if (s.fam && s.fam.orbit && s.fam.orbit.bound) {
      // (27-oct, R2: y si la órbita entera es aproximada —`approx` de ccOrbit: la energía no se conservó ni partiendo el paso—)
      s.fam.zmaxApprox = !ccEngineBreak("sci-nozmaxapprox") && !!(s.fam.zmaxUnstable || s.fam.orbit.approx || (ccIsNum(s.fam.orbit.rperi) && s.fam.orbit.rperi < CC_SCI.ZMAX_PERI_KPC));
      s.fam.orbit.zmaxApprox = s.fam.zmaxApprox;
   }
   s.pop = ccPopulation(s.chemClass, s.kin, s.chem, s.fam);
   s.pop.ageTension = ccAgeFamTension(s.age.adopted, s.pop, s.fam);    // (C2) edad que choca con su familia
   s.fp = ccFingerprint(s.chem);
   s.twin = ccSolarTwin(s.chem);
   s.bio = { en: ccBiography(s, "en"), es: ccBiography(s, "es") };
   s.hasChem = !!s.chem.feh;
   return s;
}

// La tabla para exportar: una fila por estrella del encuadre con datos, con la
// fuente de cada valor (trazabilidad) y sus incertidumbres.
function ccCsv(res) {
   var cols = ["gaia_dr3", "name", "ra", "dec", "x", "y", "G", "bp_rp", "feh", "e_feh", "feh_src", "alpha", "e_alpha", "alpha_tracer", "alpha_src",
               "age_gyr", "e_age", "age_lo", "age_hi", "age_src", "age_tier", "population", "pop_basis", "chem_class", "p_high_alpha",
               "p_thin", "p_thick", "p_halo", "U_lsr", "V_lsr", "W_lsr", "Lz", "family", "p_family", "E_orbit", "Lz_orbit", "ecc", "r_peri", "r_apo", "z_max", "dist_pc", "dist_src", "rv", "e_rv", "rv_src", "tags", "surveys"];
   var el = [];
   for (var i = 0; i < CC_ELEMENTS.length; ++i) el.push(CC_ELEMENTS[i][0]);
   var head = cols.slice();
   for (i = 0; i < el.length; ++i) { head.push(el[i] + "_fe"); head.push("e_" + el[i] + "_fe"); head.push(el[i] + "_src"); }
   // el litio, AL FINAL (no mueve ninguna columna de antes): A(Li) absoluta, su error, 1 si es límite superior («A(Li) <= a_li»), fuente
   head.push("a_li"); head.push("e_a_li"); head.push("a_li_upper_limit"); head.push("a_li_src");
   // (P8, 23-oct) lo de C1-C3 y P2-P7, DETRÁS del litio (no mueve ninguna columna de antes):
   //   gaia_match_bad 1 = el número de Gaia del survey es de otra estrella (C1) · xmatch_sep_arcsec la mayor separación survey−Gaia comprobada
   //   kin_verdict agree / tension / undecided (P2) · age_fam_tension 1 = edad más joven que la caída de su familia (C2/P5) · age_fam_floor_gyr
   //   rv_alt, rv_alt_src la otra RV que no casa (C3) · e_rv_catalogue el error del catálogo (e_rv ya lleva la discrepancia, P6)
   //   z_max_alt la Zmax con la otra RV · z_max_approx 1 = Zmax aproximada (P7)
   //   (27-oct, E6) orbit_approx 1 = la integración no conservó la energía ni partiendo el paso (`approx` de ccOrbit): r_peri, r_apo, ecc y z_max
   //   son aproximadas (la ficha y el relato les ponen «≈»); 0 = conservó; vacío = sin órbita ligada. Al FINAL: no mueve ninguna columna.
   //   (30-oct) astro_doubt ruwe / dist / ruwe+dist = astrometría dudosa: sin población cinemática ni familia (`family` vacío); la órbita sigue, orientativa. `family` = unbound: E ≥ 0.
   //   rv_catalogue / rv_corr: la RV de Gaia DR3 antes de corregirla y con qué (katz, blomme, none = no toca, no-info = no se pudo). Al FINAL: no mueven ninguna columna.
   var extra = ["gaia_match_bad", "xmatch_sep_arcsec", "kin_verdict", "age_fam_tension", "age_fam_floor_gyr", "rv_alt", "rv_alt_src", "e_rv_catalogue", "z_max_alt", "z_max_approx", "orbit_approx", "astro_doubt", "rv_catalogue", "rv_corr"];
   for (i = 0; i < extra.length; ++i) head.push(extra[i]);
   var out = [head.join(",")];
   function q(v) { if (v === null || v === undefined) return ""; if (typeof v === "number") return isFinite(v) ? String(+v.toFixed(5)) : ""; var s = String(v); return /[",\n]/.test(s) ? "\"" + s.replace(/"/g, "\"\"") + "\"" : s; }
   for (i = 0; i < res.stars.length; ++i) {
      var s = res.stars[i];
      if (!s.inFrame) continue;
      var c = s.chem, a = s.age.adopted, k = s.kin, tags = s.fp.tags.slice(), sv = [];
      if (s.twin) tags.push("solar-twin");
      if (s.pop.accreted) tags.push("accreted-compatible");
      for (var r in s.recs) if (s.recs.hasOwnProperty(r)) sv.push(r);
      var row = [s.id, s.name, s.ra, s.dec, s.x, s.y, s.g, s.bpRp,
                 c.feh ? c.feh.v : null, c.feh ? c.feh.e : null, c.feh ? c.feh.src : "",
                 c.pair ? c.pair.alpha : null, c.pair ? c.pair.ealpha : null, c.pair ? c.pair.tracer : "", c.pair ? c.pair.src : "",
                 a ? a.v : null, a ? a.e : null, a ? a.lo : null, a ? a.hi : null, a ? a.src : "", a ? a.tier : "",
                 s.pop.label, s.pop.basis, s.chemClass ? s.chemClass.cls : "", s.chemClass ? s.chemClass.pHigh : null,
                 k && k.probs ? k.probs.thin : null, k && k.probs ? k.probs.thick : null, k && k.probs ? k.probs.halo : null,
                 k ? k.uvwLsr[0] : null, k ? k.uvwLsr[1] : null, k ? k.uvwLsr[2] : null, k ? k.gc.Lz : null,
                 s.fam ? s.fam.best : "", s.fam ? s.fam.p : null, s.fam ? s.fam.nominal.E : null, s.fam ? s.fam.nominal.Lz : null,
                 s.fam && s.fam.orbit ? s.fam.orbit.ecc : null, s.fam && s.fam.orbit ? s.fam.orbit.rperi : null, s.fam && s.fam.orbit ? s.fam.orbit.rapo : null, s.fam && s.fam.orbit ? s.fam.orbit.zmax : null,
                 s.dist ? s.dist.pc : null, s.dist ? s.dist.src : "", s.rv ? s.rv.v : null, s.rv ? s.rv.e : null, s.rv ? s.rv.src : "",
                 tags.join(" "), sv.join(" ")];
      for (var j = 0; j < el.length; ++j) { var x = c.el[el[j]]; row.push(x ? x.v : null); row.push(x ? x.e : null); row.push(x ? x.src : ""); }
      var li = c.li || null;
      row.push(li ? li.v : null); row.push(li ? li.e : null); row.push(li ? (li.ul ? 1 : 0) : null); row.push(li ? li.src : "");
      var xm = s.xmatch || null, xs = null, tn = s.pop.ageTension || null, ra = s.rv && s.rv.alt ? s.rv.alt : null, fo = s.fam && s.fam.orbitAlt ? s.fam.orbitAlt : null;
      if (xm) for (var kx in xm.sep) if (xm.sep.hasOwnProperty(kx) && (xs === null || xm.sep[kx] > xs)) xs = xm.sep[kx];
      row.push(xm ? (xm.ok ? 0 : 1) : null); row.push(xs);
      row.push(s.pop.kinVerdict || "");
      row.push(a ? (tn ? 1 : 0) : null); row.push(tn ? tn.floor : null);
      row.push(ra ? ra.v : null); row.push(ra ? ra.src : ""); row.push(s.rv ? (ccIsNum(s.rv.eRaw) ? s.rv.eRaw : s.rv.e) : null);
      row.push(fo ? fo.zmax : null); row.push(s.fam && s.fam.orbit && s.fam.orbit.bound ? (s.fam.zmaxApprox ? 1 : 0) : null);
      row.push(s.fam && s.fam.orbit && s.fam.orbit.bound ? (s.fam.orbit.approx && !ccEngineBreak("sci-noorbitapprox") ? 1 : 0) : null);
      row.push(s.astroDoubt ? s.astroDoubt.why : ""); row.push(s.rv && ccIsNum(s.rv.vCat) ? s.rv.vCat : (s.rv ? s.rv.v : null)); row.push(s.rv ? (s.rv.corr || "") : "");
      var line = [];
      for (j = 0; j < row.length; ++j) line.push(q(row[j]));
      out.push(line.join(","));
   }
   return out.join("\n") + "\n";
}

// ¿Está (ra, dec) dentro del polígono del encuadre? En el plano tangente en el centro (x = −Δα cos δ0, y = Δδ),
// por paridad de cruces. Para campos de pocos grados, igual que el CONTAINS de VizieR salvo en el borde mismo.
function ccPolyTest(poly, ra0, dec0) {
   var c = Math.cos(dec0 * Math.PI / 180), P = [];
   function X(ra) { var d = ra - ra0; if (d > 180) d -= 360; if (d < -180) d += 360; return -d * c; }
   for (var i = 0; i < poly.length; ++i) P.push([X(poly[i][0]), poly[i][1] - dec0]);
   return function(ra, dec) {
      var x = X(ra), y = dec - dec0, inside = false;
      for (var i = 0, j = P.length - 1; i < P.length; j = i++) {
         var yi = P[i][1], yj = P[j][1];
         if ((yi > y) !== (yj > y) && x < (P[j][0] - P[i][0]) * (y - yi) / (yj - yi) + P[i][0]) inside = !inside;
      }
      return inside;
   };
}

// QUÉ PASÓ, distinguiendo las causas (nunca un fallo de red acaba como «no hay estrellas»):
//   net      no se pudo preguntar (curl falló, tiempo agotado, HTTP 5xx) y no hay estrellas con datos
//   partial  alguno no contestó, pero hay estrellas con datos
//   nocover  todos contestaron; Gaia ve estrellas aquí pero ningún catálogo de espectros cubre el campo
//   empty    todos contestaron y de verdad no hay estrellas (Gaia no tiene ninguna, G < 19)
//   ok
function ccFieldStatus(res) {
   var st = { kind: "ok", host: "", code: 0, why: "", failed: [], nocover: [], gaiaN: res.coverage ? res.coverage.gaiaG19 : 0, inFrame: res.coverage ? res.coverage.inFrame : 0 };
   var spec = { galah: 1, apogee: 1, lamost: 1, x19: 1, gspspec: 1, xpg: 1 };
   for (var i = 0; i < res.queries.length; ++i) {
      var q = res.queries[i];
      if (!q.ok && q.message !== "off" && q.net) { st.failed.push(q.label); if (!st.host) { st.host = q.host; st.code = q.code; st.why = q.netWhy || ""; } }
      if (q.ok && spec[q.key] && q.used === 0) st.nocover.push(q.label);
   }
   if (st.failed.length && st.inFrame === 0) st.kind = "net";
   else if (st.failed.length) st.kind = "partial";
   else if (st.inFrame === 0 && st.gaiaN > 0) st.kind = "nocover";
   else if (st.inFrame === 0) st.kind = "empty";
   return st;
}

// La cobertura: cuántas estrellas del ENCUADRE tienen cada dato.
function ccCoverage(stars, gHist, queries) {
   var cov = { gaiaG13: 0, gaiaG15: 0, gaiaG17: 0, gaiaG19: 0, inFrame: 0, chem: 0, alpha: 0, age: 0, kin: 0, elems: 0, rProc: 0,
               li: 0, liUl: 0,     // (23-oct) A(Li): detecciones y límites superiores, por separado
               bySurvey: {}, byPop: {}, ageBySrc: {}, fehSrc: {}, brightG17: 0, brightG17chem: 0, astro: { local: 0, net: 0, both: 0 } };
   for (var b in gHist) if (gHist.hasOwnProperty(b)) {
      var gb = Number(b), n = gHist[b];
      if (gb < 13) cov.gaiaG13 += n;
      if (gb < 15) cov.gaiaG15 += n;
      if (gb < 17) cov.gaiaG17 += n;
      cov.gaiaG19 += n;
   }
   for (var i = 0; i < stars.length; ++i) {
      var s = stars[i];
      if (!s.inFrame) continue;
      ++cov.inFrame;
      if (s.astroSrc && cov.astro.hasOwnProperty(s.astroSrc)) ++cov.astro[s.astroSrc];
      for (var k in s.recs) if (s.recs.hasOwnProperty(k)) cov.bySurvey[k] = (cov.bySurvey[k] || 0) + 1;
      if (s.chem.feh) { ++cov.chem; cov.fehSrc[s.chem.feh.src] = (cov.fehSrc[s.chem.feh.src] || 0) + 1; }
      if (s.chem.pair) ++cov.alpha;
      var ne = 0; for (var e in s.chem.el) if (s.chem.el.hasOwnProperty(e)) ++ne;
      if (ne >= 5) ++cov.elems;
      if (s.chem.el.Eu || s.chem.el.Ba) ++cov.rProc;
      if (s.chem.li) { if (s.chem.li.ul) ++cov.liUl; else ++cov.li; }
      if (s.age.adopted) { ++cov.age; cov.ageBySrc[s.age.adopted.src] = (cov.ageBySrc[s.age.adopted.src] || 0) + 1; }
      if (s.kin) ++cov.kin;
      cov.byPop[s.pop.label] = (cov.byPop[s.pop.label] || 0) + 1;
      if (ccIsNum(s.g) && s.g < 17) { ++cov.brightG17; if (s.chem.feh) ++cov.brightG17chem; }
   }
   return cov;
}
