// ============================================================================
// src/ui/cc_dialog.js — EL DIÁLOGO: la foto, tres diagramas enlazados, la ficha y la línea de tiempo
// ----------------------------------------------------------------------------
// EL ARMAZÓN «como CabraStars / Cabra3D» (22-oct-2026; antes, cuatro columnas con el menú I–V a la derecha):
// ┌ CABRACOMPOSITION  the chemical history of the stars in your image ············· ES · ✕ Close ┐
// │ ▣ Image [▾] ↻ · (color SPCC) · ⌖ Astrometry (resuelta) · [Analyse] ··········· ⛶ · To view · To file… · Table CSV… │
// ├───────────────────────────────┬S1┬───────────────────────────────────────────────────────────┤
// │ LA FOTO (Foto real |          │  │ I · VIEW (con el elemento) · II · JOURNEY AND VIDEO · III · THE GALAXY (plegados, acordeón) │
// │   Composición), encajada a su │  │ ● línea de estado (qué se sabe y de dónde)                 │
// │   ancho, y su leyenda debajo  │  │ CABRACOMPOSITION · GALACTIC ARCHAEOLOGY / imagen · campo · cifras (?) = la cobertura │
// │                               │  │ QUÍMICA (α–Fe)    ┬S2┬ la ficha de la elegida (titular,      │
// ├───────────────────────────────┤  │ EDAD–METALICIDAD  │  │ relato, detalle técnico plegable;     │
// │ LA VÍA LÁCTEA EN EL TIEMPO    │  │ FAMILIAS CINEM.   │  │ plegada, «El campo, en llano»)        │
// │ (bajo la foto, 23-oct · R9)   │  │                   │  │                                       │
// ├───────────────────────────────┴──┴───────────────────────────────────────────────────────────┤
// │ ● píldora de estado con la barra de progreso DENTRO (alto fijo) ················ ↻ Retry │
// └──────────────────────────────────────────────────────────────────────────────────────────────┘
// (23-oct · R16: los paneles sin letras A–E en sus títulos, como CabraStars y Cabra3D; en el código siguen llamándose panelA…panelD,
//  timeline: son nombres internos, no se enseñan.)
// S1 (foto | panel) y S2 (diagramas | ficha) se recuerdan en Settings CabraComposition/Layout (no en pruebas).
// Clic en cualquier panel -> la estrella se señala en todos (anillo que se cierra, cruz hasta los ejes), la ficha
// aparece (fundido + subida) y el marcador de la línea de tiempo se desliza a su edad.
// Las piezas del armazón (píldoras, iconos, separador, barra de estado, cabecera de grupo) están en cc_frame.js,
// copiadas de CabraStars/Cabra3D. CabraStarAnalysis incluye ESTE fichero y usa ccNewState, ccCanvas, ccSimpleCanvas,
// ccTipMove, ccVisibleList y ccAutoPick: sus firmas no cambian (y no incluye cc_frame.js: solo ccBuildDialog lo usa).
//
// Reglas de PJSR que se respetan (CabraBase/pjsr/): nada de procesos en onPaint (el dibujo de base se hace en un
// bitmap, onPaint lo copia y pinta encima lo que se anima); la «zona tranquila» (CC_QUIET) mientras corre un proceso;
// el Timer se para al ocultar el diálogo; `mouseTracking` (no `trackMouse`) para el ratón sin botón.
// La subclase de Dialog es la única sintaxis de clase de este fichero (obligatoria bajo V8).
// ============================================================================

function ccNewState() {
   return { res: null, list: [], photo: null, sel: -1, hover: -1, group: null, groupKey: "",
            opts: { sizeByAge: false, contours: true, errors: false, backdrop: true },
            zoom: { k: 1, cx: 0, cy: 0 }, anim: { sel: 1, card: 1, pulse: 0, tlFrom: null }, viewId: "", info: null,
            prog: { text: "", frac: 0, busy: false, error: false, right: "" }, photoNote: "",
            hits: {}, tip: null, dView: "elz", aView: "comp", cardDetail: false, cardScroll: 0, cardContentH: 0,
            compact: false,       // compact: cabeceras de los diagramas más bajas (las pone CabraComposition; CabraStarAnalysis no)
            // (22-oct, noche) la VISTA PREVIA: la foto (y las estrellas de la base Gaia local) nada más abrir, sin analizar
            frame: null, gaiaPreview: null, photoViewId: "", photoAt: 0, gaiaPreviewAt: 0,
            // (22-oct, IV · Elementos) el elemento que colorea A y va en el eje Y de B ("Fe" = lo de siempre) y el que se pidió
            elem: "Fe", elemWant: "Fe" };
}
// Las estrellas que se pintan: en el encuadre y con química o edad.
function ccVisibleList(res) {
   var out = [];
   if (!res) return out;
   for (var i = 0; i < res.stars.length; ++i) { var s = res.stars[i]; if (s.inFrame && (s.chem.feh || s.age.adopted)) out.push(i); }
   // las brillantes encima: se pintan las últimas
   out.sort(function(a, b) { var ga = res.stars[a].g, gb = res.stars[b].g; return (ccIsNum(gb) ? gb : 99) - (ccIsNum(ga) ? ga : 99); });
   return out;
}
// La estrella que se elige sola al acabar: la que más cuenta (química + α + edad + cinemática), y la más brillante.
function ccAutoPick(res, list) {
   var best = -1, bs = -1, F = res.field;
   for (var i = 0; i < list.length; ++i) {
      var s = res.stars[list[i]], sc = (s.chem.feh ? 2 : 0) + (s.chem.pair ? 2 : 0) + (s.age.adopted ? (s.age.adopted.tier === "C" ? 1 : 3) : 0) + (s.kin ? 2 : 0) - (ccIsNum(s.g) ? s.g / 100 : 0.2);
      // (no una del borde: la primera captura eligió una a 10 px del canto y el anillo se salía)
      if (F && (s.x < 0.08 * F.width || s.x > 0.92 * F.width || s.y < 0.08 * F.height || s.y > 0.92 * F.height)) sc -= 5;
      if (sc > bs) { bs = sc; best = list[i]; }
   }
   return best;
}

// Un lienzo con su bitmap de base (lo caro) y su capa de encima (lo que se anima).
function ccCanvas(parent, D, painter, name) {
   var c = new Control(parent);
   c.ccName = name; c.base = null; c.stale = true;
   try { c.mouseTracking = true; } catch (e) {}
   c.renderBase = function() {
      var w = Math.max(8, this.width), h = Math.max(8, this.height), sc = ccScale(this);
      if (!this.base || this.base.width !== w || this.base.height !== h) this.base = new Bitmap(w, h);
      var g = new Graphics(this.base);
      try { g.antialiasing = true; g.textAntialiasing = true; painter(g, w, h, D.S, sc, "base"); } finally { g.end(); }
      this.stale = false;
   };
   c.onPaint = function(x0, y0, x1, y1) {
      if (CC_QUIET) return;
      ccPaintGuarded(this, function() {          // (26-oct: con el pintado abierto nadie bombea eventos; cc_paint.js ccPaintGuarded)
         if (ccCoverPaint(D, this)) return;
         if (this.stale || !this.base || this.base.width !== this.width || this.base.height !== this.height) this.renderBase();
         var g = new Graphics(this);
         try { g.drawBitmap(0, 0, this.base); g.antialiasing = true; g.textAntialiasing = true; painter(g, this.width, this.height, D.S, ccScale(this), "over"); } finally { g.end(); }
      });
   };
   c.onResize = function() { if (CC_QUIET) return; this.stale = true; };
   return c;
}
// (23-oct, revisor R15) Con la vista previa o la grabación de II en la foto (D.videoCovered, cc_journey_ui.js J.cover), B, C, D y E no se
// pintan dos veces: enseñan una nota (los marcados con `ccCoverable`). Devuelve true si pintó la nota.
function ccCoverPaint(D, c) {
   if (!D.videoCovered || !c.ccCoverable || typeof ccPaintVideoCover !== "function") return false;
   var g = new Graphics(c);
   try { ccPaintVideoCover(g, c.width, c.height, ccScale(c)); } finally { g.end(); }
   D.coverPaints = (D.coverPaints || 0) + 1;
   return true;
}
// Un lienzo sin capas (la ficha, la línea de tiempo).
// `key` = el nombre de sus zonas de ayuda (S.hits[key]): al pasar el ratón, la burbuja; al pulsar, su acción.
function ccSimpleCanvas(parent, D, painter, key) {
   var c = new Control(parent);
   c.needH = 0; c.ccKey = key || "";
   try { c.mouseTracking = true; } catch (e) {}
   c.onPaint = function() {
      if (CC_QUIET) return;
      ccPaintGuarded(this, function() {          // (26-oct: ccPaintGuarded)
         if (ccCoverPaint(D, this)) return;
         var g = new Graphics(this);
         try { g.antialiasing = true; g.textAntialiasing = true; this.needH = painter(g, this.width, this.height, D.S, ccScale(this)) || 0; } finally { g.end(); }
      });
   };
   if (key) {
      c.onMouseMove = function(x, y) { if (CC_QUIET) return; ccTipMove(D, this, this.ccKey, x, y); };
      c.onLeave = function() { if (CC_QUIET) return; if (D.S.tip && D.S.tip.panel === this.ccKey) { D.S.tip = null; this.update(); } };
   }
   return c;
}
// La burbuja de ayuda: si el ratón está sobre una zona con texto, se enseña. Devuelve la zona o null.
function ccTipMove(D, ctrl, key, x, y) {
   var h = ccHitAt(D.S, key, x, y), was = D.S.tip;
   if (h && h.text) {
      if (!was || was.panel !== key || was.text !== h.text) { D.S.tip = { panel: key, x: x, y: y, text: h.text }; ctrl.update(); }
      return h;
   }
   if (was && was.panel === key) { D.S.tip = null; ctrl.update(); }
   return h;
}
// Un lienzo CON RUEDA (hasta el 22-oct, los cuerpos de II · Cobertura y III · Familias; ahora, para los cuerpos de la integración de
// II y III que no siempre quepan, registrados en `hdr.ccFit`: ver los GANCHOS en ccBuildDialog): el contenido se pinta
// entero en un bitmap de su alto (needH) y se enseña la ventana [scroll, scroll + alto]. Las zonas de ayuda se apuntan
// en coordenadas del CONTENIDO: el ratón suma el desplazamiento; la burbuja se pinta encima, en las de la pantalla.
function ccScrollCanvas(parent, D, painter, key) {
   var c = new Control(parent);
   c.needH = 0; c.ccKey = key; c.ccScroll = 0;   // (NO «scroll»: es un método nativo de Control —T5 lo vio el 22-oct: la rueda no habría desplazado nada—) c.buf = null;
   try { c.mouseTracking = true; } catch (e) {}
   c.measure = function(w) {                                     // el alto que pide el contenido a este ancho
      var b = new Bitmap(Math.max(8, w), ccPx(2400)), g = new Graphics(b), tip = D.S.tip, n = 0;
      D.S.tip = null;
      try { g.antialiasing = true; g.textAntialiasing = true; n = painter(g, b.width, b.height, D.S, ccScale(this)) || 0; } finally { g.end(); D.S.tip = tip; }
      return Math.ceil(n);
   };
   c.onPaint = function() {
      if (CC_QUIET) return;
      var w = Math.max(8, this.width), h = Math.max(8, this.height), sc = ccScale(this), tip = D.S.tip, H, k;
      D.S.tip = null;
      try {
         for (k = 0; k < 2; ++k) {                                // (2.º pase solo si el contenido pide más alto)
            H = Math.max(h, Math.ceil(this.needH || 0));
            if (!this.buf || this.buf.width !== w || this.buf.height !== H) this.buf = new Bitmap(w, H);
            var gb = new Graphics(this.buf);
            CC_ROWS = ccBroken("cutrows") ? null : [];
            CC_ROW_COLS = null;
            try { gb.antialiasing = true; gb.textAntialiasing = true; this.needH = painter(gb, w, H, D.S, sc) || 0; } finally {
               gb.end();
               // a dos columnas, cada una con sus filas (la rueda salta por las de la izquierda); si no, todas juntas
               var RR = CC_ROWS;
               this.ccCols = CC_ROW_COLS ? CC_ROW_COLS.map(function(cl) { return { x0: cl[0], x1: cl[1], blocks: ccRowBlocksCol(RR, cl[0], cl[1]) }; }) : null;
               this.ccBlocks = this.ccCols ? this.ccCols[0].blocks : ccRowBlocks(RR);
               CC_ROWS = null; CC_ROW_COLS = null;
            }
            if (this.needH <= H + 1) break;
         }
      } finally { D.S.tip = tip; }
      this.ccScroll = ccClamp(this.ccScroll, 0, Math.max(0, Math.min(this.buf.height, Math.ceil(this.needH)) - h));
      var g = new Graphics(this);
      try {
         // (drawBitmap con y negativa: con drawBitmapRect el cuerpo salía VACÍO en el render del 22-oct)
         g.fillRect(0, 0, w, h, new Brush(ccInt(CC_ATLAS.surface)));
         g.drawBitmap(0, -Math.round(this.ccScroll), this.buf);
         g.antialiasing = true; g.textAntialiasing = true;
         if (this.needH > h + 2) {                               // hay más: solo FILAS ENTERAS, la barrita y el aviso en su franja
            // (22-oct, revisor: «…FLAME (modelos de» cortado a media línea y el número de «Gaia XP» tapado por el aviso)
            var hb = Math.round(18 * sc), cols = this.ccCols || [{ x0: 0, x1: w, blocks: this.ccBlocks || [] }], vy0 = 1e9, vy1 = -1e9;
            for (var ci = 0; ci < cols.length; ++ci) {
               var vis = ccWholeRows(cols[ci].blocks, this.ccScroll, this.ccScroll + h - hb - 1), cx0 = Math.round(cols[ci].x0), cx1 = Math.round(cols[ci].x1);
               if (vis.y0 > this.ccScroll) g.fillRect(cx0, 0, cx1, vis.y0 - this.ccScroll, new Brush(ccInt(CC_ATLAS.surface)));
               g.fillRect(cx0, vis.y1 - this.ccScroll, cx1, h, new Brush(ccInt(CC_ATLAS.surface)));
               vy0 = Math.min(vy0, vis.y0); vy1 = Math.max(vy1, vis.y1);
            }
            this.ccVis = { y0: vy0 - this.ccScroll, y1: vy1 - this.ccScroll, band: h - hb };
            g.pen = new Pen(ccInt(CC_ATLAS.line), 1); g.drawLine(14 * sc, h - hb, w - 14 * sc, h - hb);
            var sbX = w - 5 * sc, sb0 = 6 * sc, sb1 = h - hb - 4 * sc, sbL = Math.max(20 * sc, (sb1 - sb0) * (h - hb) / this.needH), sbP = Math.min(1, this.ccScroll / Math.max(1, this.needH - (h - hb))), sbY = sb0 + (sb1 - sb0 - sbL) * sbP;
            g.fillRect(sbX - 0.5 * sc, sb0, sbX + 0.5 * sc, sb1, new Brush(ccInt(CC_ATLAS.line)));
            g.fillRoundedRect(sbX - 2 * sc, sbY, sbX + 2 * sc, sbY + sbL, 50, 50, new Brush(ccInt(CC_ATLAS.gold, 0.75)));
            this.ccBar = ccBarMake(w, sc, sb0, sb1, sbY, sbL, Math.max(0, this.needH - (h - hb)));      // (5-nov) para atender el ratón sobre la barra
            var fSm = ccFont("text", 8.2 * sc, false, true), t = (this.ccScroll + h - hb < this.needH - 2) ? ccT("wheelMore") : "↑";
            ccTextAt(g, fSm, ccInt(CC_ATLAS.text3), w - 14 * sc - fSm.width(t), h - 5 * sc, t);
         } else { this.ccVis = null; this.ccBar = null; }
         if (tip && tip.panel === this.ccKey) ccTipBubble(g, w, h, { tip: { panel: tip.panel, x: tip.x, y: tip.y - this.ccScroll, text: tip.text } }, this.ccKey, sc);
      } finally { g.end(); }
   };
   c.onMouseMove = function(x, y, buttons) {
      if (CC_QUIET) return;
      if (this.ccBarDrag) {          // (5-nov) pulgar agarrado: la barra mueve el mismo ccScroll que la rueda
         if (buttons && this.ccBar) { this.ccScroll = ccBarDragTo(this.ccBar, y, this.ccBarDrag.grab); D.S.tip = null; this.update(); } else this.ccBarDrag = null;
         return;
      }
      ccTipMove(D, this, this.ccKey, x, y + this.ccScroll);
   };
   c.onMousePress = function(x, y) {
      if (CC_QUIET) return;
      var bp = ccBarPress(this.ccBar, x, y);
      if (!bp) return;
      this.ccBarDrag = bp.drag ? { grab: bp.grab } : null;
      if (!bp.drag) this.ccScroll = ccSnapRows(this.ccBlocks, this.ccScroll + bp.page * Math.max(ccPx(40), this.height - ccPx(60)), this.ccBar.maxS, ccPx(6));
      D.S.tip = null; this.update();
   };
   c.onMouseRelease = function() { this.ccBarDrag = null; };
   c.onLeave = function() { if (CC_QUIET) return; if (D.S.tip && D.S.tip.panel === this.ccKey) { D.S.tip = null; this.update(); } };
   c.onMouseWheel = function(x, y, delta) {
      if (CC_QUIET) return;
      var hb = Math.round(18 * ccScale(this)), maxS = Math.max(0, this.needH - (this.height - hb));
      this.ccScroll = ccSnapRows(this.ccBlocks, this.ccScroll - delta / 120 * ccPx(48), maxS, ccPx(6));
      D.S.tip = null; this.update();
   };
   // (26-oct) el pintado, dentro de ccPaintGuarded (cc_paint.js): con el pintado abierto nadie bombea eventos
   c.ccRawPaint = c.onPaint;
   c.onPaint = function(x0, y0, x1, y1) { var self = this; ccPaintGuarded(self, function() { self.ccRawPaint(x0, y0, x1, y1); }); };
   return c;
}

// La rueda salta de FILA en fila: el desplazamiento se ajusta al principio de la fila más cercana (menos `pad`), acotado.
function ccSnapRows(B, target, maxS, pad) {
   var t = ccClamp(target, 0, maxS), best = t, bd = 1e9;
   if (B && B.length) for (var i = 0; i < B.length; ++i) { var v = Math.max(0, B[i][0] - pad); if (Math.abs(v - t) < bd) { bd = Math.abs(v - t); best = v; } }
   return ccClamp(best, 0, maxS);
}
// LA BARRA PINTADA SE PUEDE USAR (5-nov-2026, Nino en StellarChemistry 0.3.0: «la barra de la ficha no funciona, solo la rueda»).
// La barrita dorada de la ficha y de los lienzos con rueda es un dibujo, no una ScrollBar: nadie atendía el ratón sobre ella.
// Quien la pinta apunta su geometría (ccBarMake: pista [y0,y1], pulgar [t0,t1], zona de pulsación de 11 px lógicos a la derecha,
// más ancha que el trazo para poder acertar) y quien atiende el ratón la consulta: arrastrar el pulgar, o pulsar la pista = una página.
// El desplazamiento es el MISMO que mueve la rueda (S.cardScroll / ccScroll): barra y rueda no pueden desincronizarse.
// CC_BREAK «nobar» = el rojo: la barra vuelve a ser solo un dibujo.
function ccBarMake(w, sc, sb0, sb1, sbY, sbL, maxS) { return { x0: w - 11 * sc, x1: w, y0: sb0, y1: sb1, t0: sbY, t1: sbY + sbL, maxS: maxS }; }
// → null si el clic no cae en la barra; si cae: { drag: se agarró el pulgar, grab: dónde, page: -1 | 0 | +1 (pista por encima / por debajo) }
function ccBarPress(bar, x, y) {
   if (ccBroken("nobar") || !bar || !(bar.maxS > 0) || x < bar.x0 || x > bar.x1 || y < bar.y0 || y > bar.y1) return null;
   if (y >= bar.t0 && y <= bar.t1) return { drag: true, grab: y - bar.t0, page: 0 };
   return { drag: false, grab: 0, page: y < bar.t0 ? -1 : 1 };
}
// El desplazamiento que corresponde a tener el pulgar agarrado en `grab` y el ratón en `y`.
function ccBarDragTo(bar, y, grab) {
   var span = Math.max(1, (bar.y1 - bar.y0) - (bar.t1 - bar.t0));
   return ccClamp((y - grab - bar.y0) / span, 0, 1) * bar.maxS;
}
// CC_BREAK (solo pruebas): un defecto inyectado a propósito para ver en ROJO las pruebas nuevas de la interfaz.
//   accordion = abrir un grupo no cierra los demás · barheight = la barra de estado crece con un error · groupfit = el
//   cuerpo de un grupo pide todo su alto (empuja la ventana y mueve la foto) · nomin = los separadores sin mínimo ·
//   wide = los botones con el mínimo de Windows (80 lógicos) · longpill = las píldoras con los textos largos ·
//   listcount = el título cuenta las pintadas, no las del catálogo · nomirrortext = la línea de estado calla el espejo ·
//   nonetreset = no se olvida el estado de la red al analizar · nobad = «respuesta no válida» se dice como «sin conexión» ·
//   cutrows = la ficha y los cuerpos con rueda dejan filas a medias · nohelp = la frase llana vuelve a pintarse · layoutio = lo recordado se lee también en pruebas · exporthalf = exportar a 1×
//   (22-oct, noche) nopreview = la foto no se pinta al abrir · nopartial = nada se enseña hasta el final · serial / nokill /
//   nomirrorcache (cc_pixinsight.js) = el lote de una en una / sin matar sus curl al cerrar / lo del espejo sin caché
//   (22-oct, cuatro grupos) nocovtip = el «?» del título sin la cobertura · noshift = Mayús + clic no salta la caché ·
//   nofamclick = la familia de la ficha no se resalta · noelem = el elemento de IV no cambia A ni B · elemio = el elemento se lee
//   también en pruebas · noelemsave = el elemento no se guarda · groupfit = (ahora) el cuerpo de II pide 520 px
//   (22-oct, II y III integrados) novideo = los fotogramas de un vídeo pintan «?», «…» y las píldoras de D · noshiftkey = la tecla Mayús
//   no cuenta (solo onMousePress) · closevideo = cerrar no espera al fotograma/ffmpeg en curso · (en cc_journey*/cc_galaxy*: jframes,
//   jcancelkeep, jnorestore…; CC_GX_BREAK «orbit420» = el rótulo del mapa con las cifras de solo 420 Myr)
//   (23-oct) noli = el litio no sale en el selector del elemento · tlright = la línea de tiempo en la columna derecha, como antes de R9
//   (T19; sustituye a «nostrip», que se fue con la franja de D1-A) · letters = los títulos vuelven a llevar letra (T19) · lettertxt = la
//   prueba de cadenas mira también cadenas de antes con letra (T19) · oldcounts / oldpopnote / zmaxplain / rvdisc / nomergers = las cifras
//   del título, la nota de población, la Zmax, el error de la RV y las fusiones de la línea de tiempo como antes de P1–P8 (T20) ·
//   handboxes = las cajas de Naidu del diagrama de familias a mano, en la energía de gala v1 (T20; CC_GX_BREAK «v1glow»: el resplandor de III con el disco de v1)
//   (24-oct, revisión de Gemini, ronda 1; T25 y sonda J14/J15) giantsempty = con 0 pintadas la nube de gigantes se oculta (H4) · giantsnolg = las sin
//   log g cuentan como no gigantes (H4) · liclock = el litio de B ignora el reloj (H4) · homefam = la galaxia natal se ilumina con famTension (H5) ·
//   todayold = «hoy» a 5 Ma, como el literal de antes en II (H7) · todayplate = la placa de II cambia a «ahora» solo en la fase final (H7) ·
//   gxtalsolang = la placa de III llama a ccJourneyAlso sin idioma (H7)
//   (29-oct, «La Galaxia en el tiempo» se muda a III; en cc_journey_ui.js / cc_galaxy_ui.js) jorbitsinII = II ofrece aún los tres modos y III
//   no monta su vídeo · gxvideorow = ▶ ● ▾ de III en su fila propia, no en la de «Tiempo» (el mapa, 46 px más bajo) · gxrulerfree = la regla «Tiempo» de III no sigue ni mueve la vista previa de su vídeo (dos relojes)
//   (24-oct, cuelgue de T17 X2) mp4lostexit = ccAviToMp4 solo mira waitForFinished y no se entera de un ffmpeg que acabó durante onTick
//   (sonda tests/cc_mp4_hang_probe.js M2/M3)
var CC_BREAK = "";
function ccBroken(k) { return (typeof CC_BREAK === "string") && CC_BREAK.indexOf(k) >= 0; }
function ccParLiveSafe() { try { return (typeof ccParLive === "function") ? ccParLive() : -1; } catch (e) { return -1; } }

class CCDialog extends Dialog {
   constructor() {
      super();
      ccBuildDialog(this);
   }
}

function ccBuildDialog(D) {
   var sc = ccScale(D), A = CC_ATLAS;
   D.S = ccNewState();
   D.S.compact = true;
   D.busy = false;
   D.windowTitle = CC_APP_NAME;                // (30-oct) el nombre nuevo (ui/cc_atlas.js)
   try { D.userResizable = true; } catch (eUR) {}
   CC_LANG = ccSettingRead("lang", DataType_UCString, "en") === "es" ? "es" : "en";
   var fs = Math.round(10 * sc);
   // (background-image:none y border-image:none en TODO: sin ellos el estilo nativo deja una textura de
   //  puntos en los botones — visto en la primera entrega; CabraPilot ui/theme.js lo aprendió antes)
   D.styleSheet =
      "QDialog, QWidget { background-color:" + A.bg + "; color:" + A.text + "; font-family:'" + ccFontFamily("text") + "'; font-size:" + fs + "px; background-image:none; }" +
      "QPushButton { background-color:" + A.surface2 + "; color:" + A.text + "; border:1px solid " + A.line + "; border-radius:" + Math.round(7 * sc) + "px; padding:" + Math.round(3 * sc) + "px " + Math.round(12 * sc) + "px; min-width:0px; background-image:none; border-image:none; }" +
      "QPushButton:hover { background-color:" + A.surface2 + "; border:1px solid " + ccMix(A.surface, A.gold, 0.45) + "; background-image:none; }" +
      "QPushButton:pressed { background-color:" + CC_INSET + "; color:" + A.goldLight + "; border:1px solid " + A.gold + "; background-image:none; }" +
      "QPushButton:disabled { background-color:" + A.bg + "; color:" + A.text3 + "; border:1px solid " + A.line + "; background-image:none; }" +
      "QComboBox { background-color:" + CC_INSET + "; color:" + A.text + "; border:1px solid " + A.line + "; border-radius:" + Math.round(6 * sc) + "px; padding:" + Math.round(2 * sc) + "px " + Math.round(8 * sc) + "px; background-image:none; border-image:none; }" +
      "QComboBox:on, QComboBox:off, QComboBox:!editable { background-color:" + CC_INSET + "; background-image:none; border-image:none; }" +
      "QComboBox:hover { border:1px solid " + ccMix(A.surface, A.gold, 0.45) + "; }" +
      "QComboBox QAbstractItemView { background-color:" + A.surface + " !important; color:" + A.text + " !important; selection-background-color:" + A.surface2 + " !important; selection-color:" + A.goldLight + " !important; border:1px solid " + A.line + "; outline:0px; }" +
      "QCheckBox { background-color:transparent; color:" + A.text2 + "; spacing:" + Math.round(8 * sc) + "px; }" +
      "QLabel { background-color:transparent; }" +
      "QLineEdit { background-image:none; border-image:none; }" +
      "QToolTip { background-color:" + A.surface2 + "; color:" + A.text + "; border:1px solid " + A.line + "; background-image:none; }" +
      "QSizeGrip { background-color:transparent; background-image:none; border-image:none; image:none; width:0px; height:0px; }" +
      "QPushButton:focus, QComboBox:focus, QCheckBox:focus { outline:none; }" +     // sin el marco punteado del foco (defensivo: no visto en la captura real)
      "QFrame, QPushButton, QLabel, QWidget { background-image:none; }" +
      ccGlyphCss(sc);

   // El tamaño de la ventana y su mínimo (px físicos), acotados a la pantalla disponible (CabraStars A10). `D._minK` (≤ 1) es
   // cuánto bajan los mínimos de los paneles si la pantalla no da para los de siempre (los usa `D.minOf`).
   D.screenFit = function() {
      var aw = 0, ah = 0;
      try { var r = D.availableScreenRect; aw = r.width; ah = r.height; } catch (e) { aw = 0; ah = 0; }
      if (!(aw > 200 && ah > 200)) { aw = 100000; ah = 100000; }
      var minW = Math.min(ccPx(CC_UI.MIN_W), Math.floor(aw - 16)), minH = Math.min(ccPx(CC_UI.MIN_H), Math.floor(ah - 40));
      D._minK = Math.max(0.55, Math.min(1, minW / ccPx(CC_UI.MIN_W), minH / ccPx(CC_UI.MIN_H)));
      return { minW: minW, minH: minH, w: Math.max(minW, Math.min(ccPx(CC_UI.W), Math.floor(aw - 16))), h: Math.max(minH, Math.min(ccPx(CC_UI.H), Math.floor(ah - 40))) };
   };
   D.minOf = function(v) { return Math.round(ccPx(v) * ((D._minK > 0) ? D._minK : 1)); };
   var fit = D.screenFit();

   // =====================================================================================================
   // 1 · CABECERA FINA: rótulo y subtítulo pintados; ES/EN y ✕ Close a la derecha
   // =====================================================================================================
   D.head = new Control(D);
   D.head.setFixedHeight(ccPx(CC_UI.HEAD_H));
   D.head.onPaint = function() {
      if (CC_QUIET) return;
      var g = new Graphics(this), s2 = ccScale(this), w = this.width, h = this.height;
      try {
         g.textAntialiasing = true; g.antialiasing = true;
         ccFillRect(g, 0, 0, w, h, ccInt(A.bg));
         g.pen = ccPen(ccInt(A.line), 1); g.drawLine(0, h - 1, w, h - 1);
         var fC = ccFont("text", 10 * s2, true, false, Math.round(3 * s2)), y = Math.round((h + fC.ascent - fC.descent) / 2);
         ccTextAt(g, fC, ccInt(A.gold), Math.round(12 * s2), y, CC_APP_CAPS);
         var fI = ccFont("display", 14 * s2, false, true), sx = Math.round(12 * s2) + fC.width(CC_APP_CAPS) + Math.round(14 * s2);
         ccTextAt(g, fI, ccInt(A.text2), sx, y, ccElide(fI, ccT("subtitle"), Math.max(10, w - sx - 190 * s2)));
      } finally { g.end(); }
   };
   D.langBtn = ccToggleButton(D.head, "ES", "", function() { CC_LANG = (CC_LANG === "es") ? "en" : "es"; ccSettingWrite("lang", DataType_UCString, CC_LANG); D.retranslate(); });
   // «Cerrar»: fijo, el último de la cabecera, junto a ES. El mismo cierre que el aspa y Esc (D.requestClose).
   D.closeBtn = ccToggleButton(D.head, "", "", function() { D.requestClose("button"); });
   // AYUDA (2-nov-2026): el «?» dorado abre la ayuda PIDoc en el idioma de la interfaz (StellarChemistry_es / StellarChemistry), la instalada
   // en PixInsight o, si no, la compilada en _help/ en el navegador (CabraShared/help/csh_help.js). Como en FieldDepth3D: ? · ES · Cerrar.
   // Su estilo, el de ES y Cerrar (ccCssToggle); su alto, el de ellos (D.fitButtons). En pruebas (CC_NO_MAIN) el clic solo se apunta.
   // (CabraStarAnalysis incluye este fichero sin csh_help.js, pero no llama a ccBuildDialog: el typeof es por si algún día lo hace.)
   D.helpBtn = null;
   if (typeof cshHelpButton === "function") {
      var ccHelpNoMain = false; try { ccHelpNoMain = !!CC_NO_MAIN; } catch (eNM) {}
      D.helpBtn = cshHelpButton(D.head, "StellarChemistry", { title: "StellarChemistry — CabraSpace", noMain: ccHelpNoMain,
                                                              style: function(b) { ccStyle(b, ccCssToggle(false)); try { b.focusStyle = 0; } catch (eHF) {} } });
   }
   D.head.sizer = new HorizontalSizer; D.head.sizer.margin = 0; D.head.sizer.spacing = 0;
   D.head.sizer.addStretch();
   if (D.helpBtn) { D.head.sizer.add(D.helpBtn); D.head.sizer.addSpacing(ccPx(6)); }
   D.head.sizer.add(D.langBtn); D.head.sizer.addSpacing(ccPx(6)); D.head.sizer.add(D.closeBtn); D.head.sizer.addSpacing(ccPx(12));

   // =====================================================================================================
   // 2 · BARRA DE IMAGEN: Image [▾] ↻ · color · astrometría · Analyse ··· ⛶ · To view · To file… · Table CSV…
   // =====================================================================================================
   D.bar = new Control(D);
   D.bar.setFixedHeight(ccPx(CC_UI.BAR_H));
   var bar = new HorizontalSizer; bar.margin = 0; bar.spacing = 0;
   bar.addSpacing(ccPx(12));
   D.icoImage = ccIconControl(D.bar, CC_ICON.image, ccInt(A.text3), 13); bar.add(D.icoImage); bar.addSpacing(ccPx(4));
   D.lblImage = new Label(D.bar); ccStyle(D.lblImage, ccCssBarLabel()); bar.add(D.lblImage); bar.addSpacing(ccPx(6));
   // El selector de imagen: un ComboBox NUESTRO (el ViewList nativo dejaba una trama de puntos que la hoja
   // no quita: visto en el render del 14-oct). Se rellena con las vistas principales abiertas al mostrarse
   // el diálogo, con ↻ y antes de cada análisis (la imagen elegida se conserva por su id).
   D.viewList = new ComboBox(D.bar);
   D.viewList.setMinWidth(ccPx(170)); D.viewList.setMaxWidth(ccPx(260));
   try { D.viewList.focusStyle = 0; } catch (eVF) {}
   D.viewIds = [];
   D.fillViews = function() {
      var keep = D.currentViewId(), act = "";
      try { var aw = ImageWindow.activeWindow; if (aw && !aw.isNull) act = aw.mainView.id; } catch (eA) {}
      D.viewList.clear(); D.viewIds = [];
      var ws = []; try { ws = ImageWindow.windows; } catch (eW) {}
      for (var i = 0; i < ws.length; ++i) { try { if (!ws[i].isNull) { D.viewIds.push(ws[i].mainView.id); D.viewList.addItem(ws[i].mainView.id); } } catch (eV) {} }
      if (D.viewIds.length === 0) { D.viewList.addItem(CC_LANG === "es" ? "(no hay imágenes abiertas)" : "(no open images)"); D.syncPills(); return; }
      var want = keep || act, idx = Math.max(0, D.viewIds.indexOf(want));
      D.viewList.currentItem = idx;
      D.syncPills();
   };
   D.currentViewId = function() { var i = D.viewList.currentItem; return (i >= 0 && i < D.viewIds.length) ? D.viewIds[i] : ""; };
   D.currentView = function() { var id = D.currentViewId(); if (!id) return null; try { var v = View.viewById(id); return (v && !v.isNull) ? v : null; } catch (eV) { return null; } };
   D.viewList.onItemSelected = function() { if (CC_QUIET) return; var v = D.currentView(); D.syncPills(); if (v) D.onViewChanged(v); };
   bar.add(D.viewList); bar.addSpacing(ccPx(4));
   D.imgRefreshBtn = ccIconButton(D.bar, CC_ICON.refresh, "", function() { if (D.busy) return; D.fillViews(); }, 24, 22);
   bar.add(D.imgRefreshBtn); bar.addSpacing(ccPx(10));
   D.noteColour = new Label(D.bar); try { D.noteColour.useRichText = false; } catch (eRT) {} ccFixSize(D.noteColour, 0, 22);
   bar.add(D.noteColour); bar.addSpacing(ccPx(12));
   D.icoAstro = ccIconControl(D.bar, CC_ICON.target, ccInt(A.text3), 13); bar.add(D.icoAstro); bar.addSpacing(ccPx(4));
   D.lblAstro = new Label(D.bar); ccStyle(D.lblAstro, ccCssBarLabel()); bar.add(D.lblAstro); bar.addSpacing(ccPx(6));
   D.noteSolve = new Label(D.bar); try { D.noteSolve.useRichText = false; } catch (eRT2) {} ccFixSize(D.noteSolve, 0, 22);
   bar.add(D.noteSolve); bar.addSpacing(ccPx(12));
   D.analyseBtn = new PushButton(D.bar);
   ccStyle(D.analyseBtn, ccCssPrimary());
   try { D.analyseBtn.focusStyle = 0; } catch (eAF) {}
   // (22-oct, fase 1) Mayús + clic = volver a preguntar a todos los catálogos SIN la caché (lo que hacía el botón de II; un solo camino).
   // El clic de PushButton no trae las teclas: se apuntan al pulsar (onMousePress, KeyModifier_Shift = 0x01) Y, por si PJSR no le da
   // a un PushButton su onMousePress con las teclas (E1, NO VERIFICADO con un clic de verdad: tests/cc_shift_probe.js), la tecla Mayús
   // misma: el diálogo recibe Key_Shift al pulsarla y al soltarla (MEDIDO con teclas de verdad en la sonda, 23-oct) y lo apunta en
   // D.shiftHeld. Mayús + clic = sin caché por cualquiera de los dos; el gesto es UNO (el tooltip de Analizar).
   D.analyseShift = false; D.shiftHeld = false;
   D.analyseBtn.onMousePress = function(x, y, button, buttons, modifiers) { D.analyseShift = !ccBroken("noshift") && (((modifiers || 0) & ((typeof KeyModifier_Shift !== "undefined") ? KeyModifier_Shift : 0x01)) !== 0); };
   D.analyseBtn.onClick = function() { var fresh = D.analyseShift === true || (D.shiftHeld === true && !ccBroken("noshift") && !ccBroken("noshiftkey")); D.analyseShift = false; D.analyse(fresh); };
   bar.add(D.analyseBtn);
   bar.addStretch();
   D.fullBtn = ccIconButton(D.bar, CC_ICON.full, "", function() { D.toggleFull(); }, 26, 22);
   bar.add(D.fullBtn); bar.addSpacing(ccPx(6));
   D.toViewBtn = ccToggleButton(D.bar, "", "", function() { D.exportTo("view"); });
   D.toFileBtn = ccToggleButton(D.bar, "", "", function() { D.exportTo("file"); });
   D.exportBtn = ccToggleButton(D.bar, "", "", function() { D.exportCsv(); });
   bar.add(D.toViewBtn); bar.addSpacing(ccPx(4)); bar.add(D.toFileBtn); bar.addSpacing(ccPx(4)); bar.add(D.exportBtn); bar.addSpacing(ccPx(12));
   D.bar.sizer = bar;
   // Las dos píldoras de la imagen: el color (SPCC) y la solución astrométrica, sin bloquear nada (los textos, los de CabraStars)
   D.syncPills = function() {
      var v = D.currentView(), E = CC_LANG === "es";
      if (!v) {
         ccStyle(D.noteColour, ccPillCss("pending")); D.noteColour.text = "● " + ccT("pillNoView"); D.noteColour.toolTip = "";
         ccStyle(D.noteSolve, ccPillCss("pending")); D.noteSolve.text = "●"; D.noteSolve.toolTip = "";
         return;
      }
      var solved = false; try { solved = ccHasSolution(v); } catch (eS) {}
      ccStyle(D.noteSolve, ccPillCss(solved ? "ok" : "pending"));
      D.noteSolve.text = solved ? "✓ " + ccT("pillSolved") : "● " + ccT("pillNotSolved");
      D.noteSolve.toolTip = ccWrapTip(ccT(solved ? "pillSolvedTip" : "pillNotSolvedTip"));
      // (lo de ccViewInfo, sin la mediana: la píldora no recorre la imagen)
      var mono = true, spcc = false;
      try { mono = v.image.numberOfChannels < 3; } catch (eM) {}
      try { spcc = ccHasSpcc(v); } catch (e1) {}   // (las tres señales, también el historial de una imagen reabierta)
      var kind = mono ? "ok" : (spcc ? "ok" : "warn");
      ccStyle(D.noteColour, ccPillCss(kind));
      D.noteColour.text = mono ? "✓ " + ccT("pillMono") : (spcc ? "✓ " + ccT("pillSpcc") : "⚠ " + ccT("pillNoSpcc"));
      D.noteColour.toolTip = ccWrapTip(ccT(mono ? "pillMonoTip" : spcc ? "pillSpccTip" : "pillNoSpccTip"));
      if (ccBroken("longpill")) { D.noteColour.text = "⚠ " + ccT("pillNoSpccTip").substring(0, 70); D.noteSolve.text = "● " + ccT("pillNotSolvedTip"); }   // (rojo de T13 U8)
   };

   // =====================================================================================================
   // 3 · CUERPO: la foto (ancho FIJO, lo manda S1) | S1 | el panel derecho
   // =====================================================================================================
   D.lay = { photo: ccLayoutRead("photoW") || null, col: ccLayoutRead("colW") || null };
   D.panelA = ccCanvas(D, D, ccPaintPhoto, "A");
   // (29-oct-2026, Nino) el reloj de «estoy pensando» sobre la foto mientras se analiza o se prepara la vista previa (CabraShared/csh_busy.js; sin el include, nada)
   // (30-oct) en el CENTRO de la caja de la foto (bajo el titulo; con la foto mas pequeña que el lienzo, el centro de la foto: ccPhotoXf(...).box) y mayor
   if (typeof cshBusyAttach === "function") cshBusyAttach(D.panelA, { quiet: function() { return CC_QUIET; }, area: function(c) {
      try { var X = ccPhotoXf(D.S, c.width, c.height, ccScale(c)); return { x0: 0, y0: X.box.y0, x1: c.width, y1: X.box.y1 }; } catch (eA) { return null; }
   } });
   D.panelA.setMinSize(D.minOf(CC_UI.PHOTO_MIN), D.minOf(300));
   D.S.dView = ccSettingRead("dView", DataType_UCString, "elz") === "toomre" ? "toomre" : "elz";
   // (30-oct-2026, Nino: los cuatro iguales) ARRANCA en «Real photo» y recuerda la ultima eleccion (Settings `aView`; la clave y sus valores "photo" / "comp"
   // son los de siempre: CabraShared/csh_viewpref.js con `stars: "comp"`). Una clave ya guardada con «comp» es una eleccion recordada y se respeta.
   // «Stars» recordado solo se pinta si hay resultados (ccAViewEff): sin ellos se ve la foto. En las pruebas (CC_NO_MAIN) no se lee ni se escribe.
   var aPref = cshVpRead(CC_SETTINGS, ccVpNoMain(), { stars: "comp" });
   D.S.aView = (aPref === "stars") ? "comp" : (aPref === "compare") ? "compare" : "photo"; D.S.aSplit = 0.5;
   D.S.anim.aMix = (ccAViewEff(D.S) === "photo") ? 0 : 1;
   // el conmutador del panel A: inmediato, con fundido cruzado; zoom, encuadre y elegida no se tocan
   D.setAView = function(v) {
      var S = D.S;
      S.aView = (v === "photo" || v === "compare") ? v : "comp";
      cshVpWrite(CC_SETTINGS, ccVpNoMain(), S.aView === "comp" ? "stars" : S.aView, { stars: "comp" });
      S.tip = null;
      D.panelA.stale = true; D.panelA.update();
      D.lastTick = 0;
      if (!D.closing && !D.timer.isRunning) D.timer.start();
   };
   D.split1 = new CCSplitter(D, { target: D.panelA, invert: false, min: function() { return D.layoutBounds().photo[0]; }, max: function() { return D.layoutBounds().photo[1]; },
      onResized: function(w, final) { D.onSplit("photo", w, final); }, onReset: function() { D.splitReset("photo"); } });

   D.rightBox = new Control(D);
   var R = new VerticalSizer; R.margin = 0; R.spacing = 0;
   D.rightBox.sizer = R;

   // --- los GRUPOS plegables (como CabraStars/Cabra3D): plegados de fábrica y en acordeón (§11) ---------------
   // (22-oct, noche · decisión de Nino, docs/plan_grupos_22oct.md: «cada grupo debe tener MANDOS». Fuera II «Cobertura y fuentes»
   //  —al «?» de las cifras del título; «volver a preguntar» = Mayús + clic en Analizar— y III «Familias químicas» —a la ficha—.
   //  Ahora: I · VISTA · II · VIAJE Y VÍDEO · III · LA GALAXIA; el elemento —lo que fue IV · ELEMENTOS— es una fila de I desde el 23-oct.)
   D.sections = [];
   // `subKey`: clave de su subtítulo, o una función que lo devuelve (I lo cambia con el elemento); `ccHelp`: [frase, explicación]
   function group(roman, titleKey, subKey, icon, body) {
      var hdr = new Control(D.rightBox);
      hdr.setFixedHeight(ccPx(CC_UI.GROUP_H));
      hdr.ccOpen = false; hdr.ccBody = body; hdr.ccKey = titleKey; hdr.ccNum = roman; hdr.ccSub = subKey; hdr.ccIcon = icon; hdr.ccHover = false;
      hdr.ccSubText = function() { return (typeof this.ccSub === "function") ? this.ccSub() : ccT(this.ccSub); };
      try { hdr.mouseTracking = true; } catch (e) {}
      hdr.cursor = new Cursor(StdCursor_PointingHand);
      hdr.onPaint = function() {
         if (CC_QUIET) return;
         var g = new Graphics(this);
         try { g.textAntialiasing = true; ccPaintGroupHead(g, this.width, this.height, ccScale(this), this.ccNum, ccT(this.ccKey), this.ccSubText(), this.ccIcon, this.ccOpen, D.sections[D.sections.length - 1] === this, this.ccHover, !!this.ccHelp); }
         finally { g.end(); }
      };
      hdr.onEnter = function() { if (CC_QUIET) return; this.ccHover = true; this.update(); };
      hdr.onLeave = function() { if (CC_QUIET) return; this.ccHover = false; this.update(); };
      hdr.onMousePress = function() { if (CC_QUIET) return; D.openSection(this.ccOpen ? null : this); };
      body.hide();
      D.sections.push(hdr);
      R.add(hdr); R.add(body);
      return hdr;
   }
   function row(parent, items) {
      var r = new HorizontalSizer; r.margin = 0; r.spacing = 0;
      r.addSpacing(ccPx(CC_UI.INDENT));
      for (var i = 0; i < items.length; ++i) { if (typeof items[i] === "number") r.addSpacing(ccPx(items[i])); else { r.add(items[i]); if (i + 1 < items.length && typeof items[i + 1] !== "number") r.addSpacing(ccPx(8)); } }
      r.addStretch();
      return r;
   }
   // I · VIEW: lo que se pinta sobre las estrellas y en los diagramas (casillas nativas, como antes en «IV. Visualización»)
   D.viewBox = new Control(D.rightBox);
   var vs = new VerticalSizer; vs.margin = 0; vs.spacing = 0;
   for (var ok in D.S.opts) if (D.S.opts.hasOwnProperty(ok)) D.S.opts[ok] = ccSettingRead("opt_" + ok, DataType_Boolean, D.S.opts[ok]);
   function check(key, opt) {
      var cb = new CheckBox(D.viewBox);
      cb.text = ccT(key); cb.checked = !!D.S.opts[opt]; cb.ccKey = key;
      try { cb.focusStyle = 0; } catch (eF) {}
      cb.onCheck = function(on) { D.S.opts[opt] = on; ccSettingWrite("opt_" + opt, DataType_Boolean, on); D.invalidate(); };
      return cb;
   }
   D.checks = [check("sizeByAge", "sizeByAge"), check("contours", "contours"), check("errors", "errors"), check("backdrop", "backdrop")];
   D.lblStars = new Label(D.viewBox); ccStyle(D.lblStars, ccCssBarLabel()); ccFixSize(D.lblStars, 82, 0);
   D.lblDiag = new Label(D.viewBox); ccStyle(D.lblDiag, ccCssBarLabel()); ccFixSize(D.lblDiag, 82, 0);
   vs.addSpacing(ccPx(6));
   vs.add(row(D.viewBox, [D.lblStars, D.checks[0], 12, D.checks[1]])); vs.addSpacing(ccPx(6));
   vs.add(row(D.viewBox, [D.lblDiag, D.checks[2], 12, D.checks[3]])); vs.addSpacing(ccPx(6));
   // EL ELEMENTO (fila de I · VISTA desde el 23-oct —Nino: «elimina el menú IV Elementos e intégralo dentro de Vista»—; antes, el grupo
   // IV): el elemento (los que haya en los datos, `s.chem.el`) cambia el color de las estrellas en la foto (A) y el eje Y de B. Fe = lo de fábrica ([Fe/H] en A, [α/Fe] en B). El selector es un ComboBox NUESTRO (el de la imagen: sin trama).
   // Se recuerda en Settings `CabraComposition/elem` (no en pruebas, salvo CC_LAYOUT_IO, como lo recordado de los paneles).
   D.elemIO = function() { return ccLayoutIO() || ccBroken("elemio"); };
   D.S.elemWant = D.elemIO() ? String(ccSettingRead("elem", DataType_UCString, "Fe") || "Fe") : "Fe";
   if (!/^[A-Z][a-z]?$/.test(D.S.elemWant)) D.S.elemWant = "Fe";
   D.S.elem = D.S.elemWant;
   D.elemBox = D.viewBox;      // (los mandos del elemento viven en el cuerpo de I)
   D.lblElem = new Label(D.elemBox); ccStyle(D.lblElem, ccCssBarLabel()); ccFixSize(D.lblElem, 82, 0);
   D.elemList = new ComboBox(D.elemBox);
   D.elemList.setMinWidth(ccPx(200)); D.elemList.setMaxWidth(ccPx(280));
   try { D.elemList.focusStyle = 0; } catch (eEF) {}
   D.elemKeys = ["Fe"];
   D.elemChan = new Label(D.elemBox);
   try { D.elemChan.useRichText = false; } catch (eRC) {}
   ccStyle(D.elemChan, "QLabel { color:" + A.text2 + "; font-size:" + ccPxs(9.4) + "; font-style:italic; background:transparent; border:none; }");
   // el «?» del canal: la frase llana entera, con su fuente, en su tooltip (y en el del texto corto)
   D.elemHelp = new Control(D.elemBox);
   D.elemHelp.setFixedSize(ccPx(16), ccPx(18));
   D.elemHelp.onPaint = function() { if (CC_QUIET) return; var g = new Graphics(this), s2 = ccScale(this); try { g.antialiasing = true; g.textAntialiasing = true; ccFillRect(g, 0, 0, this.width, this.height, ccInt(A.bg)); ccQMark(g, Math.round(1 * s2), Math.round(this.height / 2 + 5 * s2), s2); } finally { g.end(); } };
   vs.add(row(D.viewBox, [D.lblElem, D.elemList, 12, D.elemChan, 4, D.elemHelp])); vs.addSpacing(ccPx(8));
   D.elemSubtitle = function() {
      var S = D.S, X = S.elem || "Fe", W = S.elemWant || "Fe";
      if (!S.res) return ccT("elemSubNone");
      if (W !== X) return ccT("elemSubMissing").replace("%1", ccElLabel(W)).replace("%2", ccThou(ccElemCount(S, "Fe"), CC_LANG));
      return ccT("elemSub").replace("%1", ccElLabel(X)).replace("%2", ccThou(ccElemCount(S, X), CC_LANG));
   };
   // el subtítulo de I nombra el elemento (corto: «… · fondo · color: [Ba/Fe]»); lo largo (cuántas lo tienen, si falta) en el tooltip
   D.viewSubtitle = function() { var X = D.S.elem || "Fe"; return ccT("grpViewSub") + " · " + ccT("viewSubElem").replace("%1", ccElLabel(X)); };
   D.viewBox.sizer = vs;
   D.elemHdr = group("I", "grpView", function() { return D.viewSubtitle(); }, CC_ICON.eye, D.viewBox);
   D.elemHdr.ccHelp = ["viewHelp", ""];      // (23-oct, revisor R21: I · VISTA lleva su «?», como II y III)
   // Los elementos que hay en los datos (de las estrellas que se pintan), en el orden de CC_ELEMENTS, con cuántas lo tienen.
   // El elegido (`elemWant`) se conserva aunque este campo no lo tenga: entonces se enseña Fe y el subtítulo lo dice.
   D.syncElements = function() {
      var S = D.S, keys = ["Fe"], i;
      if (S.res) {
         for (i = 0; i < CC_ELEMENTS.length; ++i) if (ccElemCount(S, CC_ELEMENTS[i][0]) > 0) keys.push(CC_ELEMENTS[i][0]);
         // (23-oct) lo que traigan los datos y no esté en CC_ELEMENTS —el litio, cuando llegue de GALAH— sale también, solo, tras Fe
         var extra = {}, L0 = S.list || [];
         for (i = 0; i < L0.length; ++i) { var s0 = S.res.stars[L0[i]], el0 = (s0 && s0.chem && s0.chem.el) ? s0.chem.el : null; if (el0) for (var X0 in el0) if (el0.hasOwnProperty(X0) && keys.indexOf(X0) < 0 && /^[A-Z][a-z]?$/.test(X0) && ccElemOf(s0, X0)) extra[X0] = true; }
         var ex = Object.keys(extra).sort(); for (i = 0; i < ex.length; ++i) keys.splice(1 + i, 0, ex[i]);
         // (23-oct) el LITIO vive en s.chem.li (no en s.chem.el): sale, el primero tras Fe, si alguna pintada tiene A(Li) o su límite
         var liC = (typeof ccLiCounts === "function") ? ccLiCounts(S) : { det: 0, ul: 0 };
         if (liC.det + liC.ul > 0 && keys.indexOf("Li") < 0 && !ccBroken("noli")) keys.splice(1, 0, "Li");
      }
      else if (S.elemWant && S.elemWant !== "Fe") keys.push(S.elemWant);
      S.elem = (keys.indexOf(S.elemWant) >= 0) ? S.elemWant : "Fe";
      S._elR = null; S._elA = null;
      D.elemKeys = keys;
      D._elemSync = true;
      try {
         D.elemList.clear();
         for (i = 0; i < keys.length; ++i) {
            var X = keys[i], nm = ccElName(X, CC_LANG);
            D.elemList.addItem(X + " — " + nm + (S.res ? " · " + ccThou(ccElemCount(S, X), CC_LANG) : "") + (X === "Fe" ? " (" + (CC_LANG === "es" ? "de fábrica" : "default") + ")" : ""));
         }
         D.elemList.currentItem = Math.max(0, keys.indexOf(S.elem));
      } finally { D._elemSync = false; }
      var ch = ccElChannel(S.elem, CC_LANG), tip = ch.long + (S.elem === "Fe" ? "" : "\n\n" + ccT("elemGloss").replace("%1", ccElLabel(S.elem)).replace("%2", ccElName(S.elem, CC_LANG)));
      if (S.elem === "Li") { var liU = ccLiCounts(S).ul; tip = ch.long + "\n\n" + ccT("liGloss") + (liU ? "\n\n" + ccT("liUlTip").replace("%1", ccThou(liU, CC_LANG)) : ""); }
      D.elemChan.text = ch.short; D.elemChan.toolTip = ccWrapTip(tip); D.elemHelp.toolTip = ccWrapTip(tip);
      D.lblElem.text = ccT("rowElement");
      var et = D.elemSubtitle() + "\n\n" + ccT("capElem");
      D.lblElem.toolTip = ccWrapTip(et); D.elemList.toolTip = ccWrapTip(et);
      D.elemHdr.toolTip = ccWrapTip(D.viewSubtitle() + "\n\n" + ccT("viewHelp") + "\n\n" + D.elemSubtitle());
      D.elemHdr.update();
   };
   D.setElem = function(X) {
      var S = D.S;
      if (D.elemKeys.indexOf(X) < 0) return false;
      S.elemWant = X; S.elem = X; S._elR = null; S._elA = null; S.tip = null;
      if (D.elemIO() && !ccBroken("noelemsave")) ccSettingWrite("elem", DataType_UCString, X);
      D.syncElements();
      D.invalidate();
      return true;
   };
   D.elemList.onItemSelected = function() { if (CC_QUIET || D._elemSync) return; var k = D.elemKeys[D.elemList.currentItem]; if (k) D.setElem(k); };

   // =====================================================================================================
   // LOS GANCHOS DE II Y III (fase 2a / 2b del plan: SOLO ficheros nuevos src/ui/cc_journey*.js y src/ui/cc_galaxy*.js).
   // Para enchufarlos (la integración): incluir esos ficheros en CabraComposition.js ANTES de cc_dialog.js y que definan
   //    function ccJourneyMount(D, body) { … }     y     function ccGalaxyMount(D, body) { … }
   // Se llaman UNA vez, al construir el diálogo, con el cuerpo vacío del grupo (un Control con su VerticalSizer en `body.sizer`;
   // el rótulo «en construcción» es `body.ccWip`: el que monte su cuerpo lo esconde o lo quita del sizer). Si devuelven `true`, el
   // rótulo se esconde solo. Si su cuerpo puede no caber en la ventana, que lo registre en su cabecera: `hdr.ccFit = { canvas, extra }`
   // (`canvas` = un ccScrollCanvas: fitGroups le da el alto que quede, con rueda; `extra` = px de lo que tenga encima) — D.sections[1]
   // es II y D.sections[2] es III. Sin esos ficheros, D.mountJourney / D.mountGalaxy no hacen nada y queda el rótulo.
   // =====================================================================================================
   D.gxNoPersist = (typeof ccLayoutIO === "function") ? !ccLayoutIO() : false;      // (III: en pruebas no lee ni escribe lo recordado)
   D.mountJourney = function(body) { if (ccBroken("nohook")) return false; return (typeof ccJourneyMount === "function") ? ccJourneyMount(D, body) === true : false; };
   D.mountGalaxy = function(body) { if (ccBroken("nohook")) return false; return (typeof ccGalaxyMount === "function") ? ccGalaxyMount(D, body) === true : false; };
   function wipBody(textKey) {
      var b = new Control(D.rightBox), s0 = new VerticalSizer; s0.margin = 0; s0.spacing = 0;
      b.ccWip = new Label(b); b.ccWip.ccKey = textKey;
      try { b.ccWip.useRichText = false; b.ccWip.wordWrapping = true; } catch (eW) {}
      ccStyle(b.ccWip, "QLabel { color:" + A.text3 + "; font-size:" + ccPxs(9.4) + "; font-style:italic; background:transparent; border:none; }");
      var r0 = new HorizontalSizer; r0.margin = 0; r0.spacing = 0; r0.addSpacing(ccPx(CC_UI.INDENT)); r0.add(b.ccWip, 100); r0.addSpacing(ccPx(14));
      s0.addSpacing(ccPx(6)); s0.add(r0); s0.addSpacing(ccPx(8));
      b.sizer = s0;
      // (rojo de T13 U3: un cuerpo que pide más alto del que hay —como uno de la integración que no se registrara en ccFit—)
      if (ccBroken("groupfit") && textKey === "wipJourney") b.setFixedHeight(ccPx(520));
      return b;
   }
   // II · JOURNEY AND VIDEO / VIAJE Y VÍDEO (provisional: el motor es de la fase 2a)
   D.journeyBox = wipBody("wipJourney");
   group("II", "grpJourney", "grpJourneySub", CC_ICON.flight, D.journeyBox).ccHelp = ["wipJourney", ""];
   if (D.mountJourney(D.journeyBox)) { D.journeyBox.ccWip.hide(); D.journeyBox.ccMounted = true; D.sections[1].ccHelp = ["grpJourneyHelp", ""]; }
   // III · THE GALAXY / LA GALAXIA (provisional: el motor es de la fase 2b)
   D.galaxyBox = wipBody("wipGalaxy");
   group("III", "grpGalaxy", "grpGalaxySub", CC_ICON.galaxy, D.galaxyBox).ccHelp = ["wipGalaxy", ""];
   if (D.mountGalaxy(D.galaxyBox)) { D.galaxyBox.ccWip.hide(); D.galaxyBox.ccMounted = true; D.sections[2].ccHelp = ["grpGalaxyHelp", ""]; }

   R.addSpacing(ccPx(6));
   // --- la línea de estado (qué se sabe del análisis y de dónde sale), como la de CabraStars en su panel ---
   D.panelStatus = new Control(D.rightBox);
   D.panelStatus.setFixedHeight(ccPx(CC_UI.STATUS_H));
   D.panelStatus.onPaint = function() { if (CC_QUIET) return; var g = new Graphics(this); try { g.textAntialiasing = true; D.paintPanelStatus(g, this.width, this.height, ccScale(this)); } finally { g.end(); } };
   R.add(D.panelStatus);
   R.addSpacing(ccPx(4));
   // --- el título de la vista ---
   D.titleCtl = new Control(D.rightBox);
   D.titleCtl.setFixedHeight(ccPx(CC_UI.TITLE_H));
   D.titleCtl.onPaint = function() { if (CC_QUIET) return; var g = new Graphics(this); try { g.antialiasing = true; g.textAntialiasing = true; D.paintTitle(g, this.width, this.height, ccScale(this)); } finally { g.end(); } };
   // (22-oct, fase 1) el «?» junto a las cifras: su tooltip es la COBERTURA entera (lo que era el grupo II); fuera de él, el texto
   // entero del título si se cortó
   try { D.titleCtl.mouseTracking = true; } catch (eTM) {}
   D.titleTipAt = function(x, y) {
      var q = D.covQ, inQ = !!q && x >= q.x0 && x <= q.x1 && y >= q.y0 && y <= q.y1;
      return inQ ? ccCoverageHtml(D.S, CC_LANG) : (D.titleCutTip || "");
   };
   D.titleCtl.onMouseMove = function(x, y) { if (CC_QUIET) return; var tt = D.titleTipAt(x, y); if (this.ccTipNow !== tt) { this.ccTipNow = tt; try { this.toolTip = ccWrapTip(tt); } catch (e) {} } };
   D.titleCtl.onLeave = function() { if (CC_QUIET) return; var tt = D.titleCutTip || ""; if (this.ccTipNow !== tt) { this.ccTipNow = tt; try { this.toolTip = ccWrapTip(tt); } catch (e) {} } };
   R.add(D.titleCtl);
   // --- la columna de vistas (B, C, D: su ANCHO lo manda S2) | S2 | la ficha ---
   var lower = new HorizontalSizer; lower.margin = 0; lower.spacing = 0;
   D.colBox = new Control(D.rightBox);
   var col = new VerticalSizer; col.margin = 0; col.spacing = ccPx(6);
   D.panelB = ccCanvas(D.colBox, D, ccPaintAlpha, "B");
   D.panelC = ccCanvas(D.colBox, D, ccPaintAgeMet, "C");
   D.panelD = ccCanvas(D.colBox, D, ccPaintFamD, "D");
   D.panelB.setMinHeight(D.minOf(CC_UI.PLOT_MIN)); D.panelC.setMinHeight(D.minOf(CC_UI.PLOT_MIN)); D.panelD.setMinHeight(D.minOf(CC_UI.PLOT_MIN));
   D.panelB.ccCoverable = D.panelC.ccCoverable = D.panelD.ccCoverable = true;
   D.videoCovered = false;
   col.add(D.panelB, 100); col.add(D.panelC, 100); col.add(D.panelD, 100);
   D.colBox.sizer = col;
   lower.add(D.colBox);
   D.split2 = new CCSplitter(D.rightBox, { target: D.colBox, invert: false, min: function() { return D.layoutBounds().col[0]; }, max: function() { return D.layoutBounds().col[1]; },
      onResized: function(w, final) { D.onSplit("col", w, final); }, onReset: function() { D.splitReset("col"); } });
   lower.add(D.split2);
   D.card = ccSimpleCanvas(D.rightBox, D, ccPaintCard, "card");
   D.card.setMinWidth(D.minOf(CC_UI.CARD_MIN));
   lower.add(D.card, 100);
   R.add(lower, 100);
   // --- la línea de tiempo («La Vía Láctea en el tiempo») ---
   // (23-oct · R9, decisión de Nino: la foto apaisada dejaba negro el tercio de abajo de la mitad izquierda —37 % de sus filas, medido
   //  en T19—) va BAJO LA FOTO, a lo ancho de la mitad izquierda; la columna derecha gana su alto para los diagramas y el mapa de III.
   //  Ya no se pliega a franja al abrir un grupo (D1-A ya no hace falta). Su alto, el que deje la foto encajada: D.fitLeft.
   //  (CC_BREAK=tlright, rojo de T19: vuelve a la columna derecha, como antes)
   D.tlRight = ccBroken("tlright");
   D.timeline = ccSimpleCanvas(D.tlRight ? D.rightBox : D, D, function(g, w, h, S, s2) { ccPaintTimeline(g, w, h, S, s2); return 0; }, "T");
   D.timeline.setFixedHeight(ccPx(CC_UI.TIMELINE_H));
   D.timeline.ccCoverable = true;
   if (D.tlRight) { R.addSpacing(ccPx(6)); R.add(D.timeline); }
   D.S.cardDetail = ccSettingRead("cardDetail", DataType_Boolean, false);
   // la ficha: clic en «Detalle técnico» lo pliega o despliega (se recuerda); la rueda la desplaza
   D.card.onMousePress = function(x, y) {
      if (CC_QUIET) return;
      // (5-nov) la barra pintada: arrastrar el pulgar o pulsar la pista (una página); mueve el mismo cardScroll que la rueda
      var bp = ccBarPress(D.S.cardBar, x, y);
      if (bp) {
         D.card.ccBarDrag = bp.drag ? { grab: bp.grab } : null;
         if (!bp.drag) D.S.cardScroll = ccSnapRows(D.S.cardBlocks, (D.S.cardScroll || 0) + bp.page * Math.max(ccPx(40), D.card.height - ccPx(60)), D.S.cardBar.maxS, ccPx(14));
         D.S.tip = null; D.card.update(); return;
      }
      var hh = ccHitAt(D.S, "card", x, y);
      // (26-oct) un clic en el nombre abre SIMBAD (cc_paint.js ccLinkOfStar / ccOpenUrl, CabraShared/csh_link.js); no cambia lo elegido
      if (hh && hh.action === "simbad") { D.lastLinkOpen = (typeof ccOpenUrl === "function") ? ccOpenUrl(hh.value) : null; return; }
      if (hh && hh.action === "detail") { D.S.cardDetail = !!hh.value; ccSettingWrite("cardDetail", DataType_Boolean, D.S.cardDetail); if (!D.S.cardDetail) D.S.cardScroll = 0; D.S.tip = null; D.card.update(); }
      else if (hh && hh.action === "family" && !ccBroken("nofamclick")) D.toggleFamily(hh.value);
   };
   // (22-oct, fase 1: lo que hacía pulsar una familia en el grupo III) resaltar en todos los paneles las estrellas de la familia `key`
   D.toggleFamily = function(key) {
      var S = D.S, mem = (S.cardFamKeys && S.cardFamKeys[key]) || null;
      if (!mem || S.groupKey === key) { S.group = null; S.groupKey = ""; }
      else { var set = {}; for (var k = 0; k < mem.length; ++k) set[mem[k]] = true; S.group = set; S.groupKey = key; }
      S.tip = null;
      D.invalidate();
   };
   // (26-oct) el ratón sobre el nombre-enlace: mano y el nombre en oro claro (la burbuja «Open in SIMBAD: …» la pone ccTipMove con su zona)
   D.card.ccBaseMove = D.card.onMouseMove;
   D.card.onMouseMove = function(x, y, buttons) {
      // (5-nov) con el pulgar agarrado, el ratón arrastra la ficha; sin botón pulsado (soltó fuera) se suelta
      if (D.card.ccBarDrag) {
         if (buttons && D.S.cardBar) { D.S.cardScroll = ccBarDragTo(D.S.cardBar, y, D.card.ccBarDrag.grab); D.S.tip = null; D.card.update(); }
         else D.card.ccBarDrag = null;
         return;
      }
      if (D.card.ccBaseMove) D.card.ccBaseMove.call(this, x, y);
      if (CC_QUIET) return;
      var hh = ccHitAt(D.S, "card", x, y), hot = !!(hh && hh.action === "simbad");
      if (hot === (D.S.cardLinkHot === true)) return;
      D.S.cardLinkHot = hot;
      try { this.cursor = new Cursor(hot ? StdCursor_PointingHand : StdCursor_Arrow); } catch (eC) {}
      this.update();
   };
   D.card.ccBaseLeave = D.card.onLeave;
   D.card.onLeave = function() {
      if (D.card.ccBaseLeave) D.card.ccBaseLeave.call(this);
      if (D.S.cardLinkHot !== true) return;
      D.S.cardLinkHot = false;
      try { this.cursor = new Cursor(StdCursor_Arrow); } catch (eC) {}
      this.update();
   };
   D.card.onMouseRelease = function() { D.card.ccBarDrag = null; };
   D.card.onMouseWheel = function(x, y, delta) {
      if (CC_QUIET) return;
      var maxS = Math.max(0, (D.S.cardContentH || 0) - (D.card.height - ccPx(20)));
      D.S.cardScroll = ccSnapRows(D.S.cardBlocks, (D.S.cardScroll || 0) - delta / 120 * ccPx(48), maxS, ccPx(14));
      D.S.tip = null; D.card.update();
   };
   ccWirePanels(D);

   // la mitad izquierda: la foto y, debajo, la línea de tiempo (su ancho, el de la foto: lo manda S1)
   var left = new VerticalSizer; left.margin = 0; left.spacing = 0;
   left.add(D.panelA, 100);
   if (!D.tlRight) { left.addSpacing(ccPx(CC_UI.LEFT_GAP)); left.add(D.timeline); }
   var body = new HorizontalSizer; body.margin = 0; body.spacing = 0;
   body.addSpacing(ccPx(8)); body.add(left); body.add(D.split1); body.add(D.rightBox, 100); body.addSpacing(ccPx(8));

   // =====================================================================================================
   // 4 · BARRA DE ESTADO (píldora con la barra de progreso DENTRO, alto fijo) y «↻ Retry» a su derecha
   // =====================================================================================================
   D.progress = new Control(D);
   D.progress.setFixedHeight(ccPx(CC_UI.FOOT_H));
   D.progress.onPaint = function() { if (CC_QUIET) return; var g = new Graphics(this); try { g.antialiasing = true; g.textAntialiasing = true; ccPaintStatusBar(g, this.width, this.height, D.S.prog, ccScale(this)); } finally { g.end(); } };
   D.retryBtn = ccToggleButton(D, "", "", function() { D.netReset(); try { ccNetForget(); } catch (eF) {} D.analyse(false); });     // vuelve a preguntar lo que no contestó (también a quien calló: ccNetForget)
   // 18 (22-oct): el estado de la red (servidor caído, espejo en uso) se olvida al empezar cada análisis y en «Reintentar»; antes la red
   // lo adivinaba por una pausa de más de 6 s entre consultas (cc_pixinsight.js ccNetNote)
   D.netResets = 0;
   D.netReset = function() { if (ccBroken("nonetreset")) return; try { if (typeof ccNetReset === "function") { ccNetReset(); ++D.netResets; } } catch (e) {} };
   D.retryBtn.hide(); D.retryShown = false;
   var foot = new HorizontalSizer; foot.margin = 0; foot.spacing = 0;
   foot.addSpacing(ccPx(8)); foot.add(D.progress, 100); foot.addSpacing(ccPx(6)); foot.add(D.retryBtn); foot.addSpacing(ccPx(8));

   D.sizer = new VerticalSizer;
   D.sizer.margin = 0; D.sizer.spacing = 0;
   D.sizer.add(D.head); D.sizer.add(D.bar); D.sizer.add(body, 100); D.sizer.addSpacing(ccPx(6)); D.sizer.add(foot); D.sizer.addSpacing(ccPx(6));

   // --- el tamaño: el de CabraStars (1560 × 960 lógicos), acotado a la pantalla (CabraStars A10) ---------------
   D.setMinSize(fit.minW, fit.minH);
   D.resize(fit.w, fit.h);
   D.onResize = function() { D.fixHalves(); D.fitGroups(); };

   // --- la animación ---------------------------------------------------------------------
   D.timer = new Timer;
   D.timer.interval = 0.033;
   D.timer.periodic = true;
   D.lastTick = 0;
   D.timer.onTimeout = function() {
      if (CC_QUIET || D.busy || D.closing) return;
      var now = Date.now(), dt = D.lastTick ? Math.min(0.1, (now - D.lastTick) / 1000) : 0.033;
      D.lastTick = now;
      D.stepAnim(dt);
   };
   D.onHide = function() { try { D.timer.stop(); } catch (e) {} try { D.refitTimer.stop(); } catch (e2) {} };

   // --- CERRAR DE VERDAD: el aspa, Esc y «Cerrar» van por el MISMO camino -----------------------------
   // Causa del «el aspa no cierra» (medida en T9 el 15-oct, antes del arreglo): con un análisis en marcha, el
   // aspa escondía la ventana pero el manejador seguía con las 12 consultas (red colgada: 99 s hasta volver
   // execute()) y el resultado, la foto y el temporizador quedaban vivos; Esc ni pasa por onClose
   // (CabraBase/pjsr/esc-en-dialog-no-pasa-por-onclose.md). Ahora: CC_ABORT mata el curl en curso y no lanza
   // más; el temporizador se para; el análisis se suelta y, al soltarse, se cierra y se libera todo.
   D.closing = false; D.closedHow = "";
   // un rastro de tiempos (solo si CC_TRACE): para medir dónde se va el tiempo al cerrar
   D.trace = []; D.mark = function(t) { if (CC_TRACE) D.trace.push([Date.now(), t]); };
   // (29-oct) LOS DOS GRUPOS CON VÍDEO: II (D.journey: la historia del campo, el gran recorrido) y III (D.gxVideo: la Galaxia en el tiempo),
   // la misma máquina (cc_journey_ui.js). Todo lo que el diálogo hacía con D.journey lo hace ahora con los dos.
   D.videos = function() { var v = []; if (D.journey) v.push(D.journey); if (D.gxVideo && D.gxVideo !== D.journey) v.push(D.gxVideo); return v; };
   D.videoRec = function() { var v = D.videos(); for (var i = 0; i < v.length; ++i) if (v[i].rec) return v[i]; return null; };
   // II y III: lo que tengan vivo (vista previa, grabación —que se BORRA—, el vigía de III) se para. Idempotente.
   D.endVideo = function() {
      var vv = D.videos(); for (var iv = 0; iv < vv.length; ++iv) { try { vv[iv].cleanup(); } catch (eJ) {} }
      if (!ccBroken("noendvideo")) try { if (D.galaxy) { D.galaxy.stop(); D.galaxy.watchStop(); } } catch (eG) {}
   };
   // ¿hay un fotograma de II pintándose o ffmpeg codificando AHORA (dentro de un tic)? Entonces cerrar espera a que el tic acabe:
   // el codificador ve D.closing, se cancela y lo borra todo; al acabar, J.recordEnd llama a D.videoClosed.
   D.videoMidStep = function() { var J = D.videoRec(); return !!(J && J.rec && (J.rec.stepping || J.rec.encoding)); };
   D.waitVideo = false;
   // II y III, enterados de un resultado nuevo, de otra imagen o de un análisis que empieza / acaba (J.sync habilita y explica sus mandos;
   // III repinta su mapa con el modelo nuevo)
   D.videoSync = function(newRes) {
      var vv = D.videos(); for (var iv = 0; iv < vv.length; ++iv) { try { vv[iv].sync(); } catch (eJ) {} }
      try { if (D.galaxy && newRes) D.galaxy.refresh(); } catch (eG) {}
   };
   D.videoClosed = function() { if (!D.waitVideo) return; D.waitVideo = false; D.release(); D.closeLater(); };
   // EL RELOJ DEL DIÁLOGO (23-oct, opción (a) de Nino; los pintores en cc_paint.js, ccClockList / ccClockCursor). Dos fuentes:
   //   "video"  la vista previa o la grabación de II: { T (Ga atrás) } en la historia y en la Galaxia en el tiempo, { visit } en el recorrido
   //   "galaxy" la regla «Tiempo» de III: { T, photo: true, light (arrastrando) }
   // Manda el vídeo. La línea de tiempo y el frente de C se repintan a cada cambio (barato); B, C y D (y la foto con la regla de III) solo
   // cuando cambian las nacidas, y no mientras se arrastra la regla (al soltar).
   D.clockSrc = { video: null, galaxy: null }; D._clockKey = "";
   D.setClock = function(src, c) { D.clockSrc[src] = c || null; D.applyClock(); };
   D.applyClock = function() {
      var c = D.clockSrc.video || D.clockSrc.galaxy || null, S = D.S, fromVideo = !!D.clockSrc.video;
      var T = (c && ccIsNum(c.T)) ? Math.max(0, c.T) : null, photo = !!(c && c.photo && !fromVideo), visit = (c && ccIsNum(c.visit)) ? c.visit : null;
      var moved = (S.clockT !== T) || (S.clockVisit !== visit);
      S.clockT = T; S.clockPhoto = photo; S.clockVisit = visit;
      var on = ccClockOn(S), key = (on ? ccClockList(S).length : -1) + "|" + (photo ? 1 : 0) + "|" + (S.res ? S.res.stars.length : 0);
      if (moved) { try { D.timeline.update(); D.panelC.update(); } catch (eT) {} }
      if (c && c.light) return;
      if (key !== D._clockKey) {
         var wasPhoto = /\|1\|/.test(D._clockKey);
         D._clockKey = key;
         var P = [D.panelB, D.panelC, D.panelD];
         if (photo || wasPhoto) P.push(D.panelA);
         for (var i = 0; i < P.length; ++i) { try { P[i].stale = true; P[i].update(); } catch (eP) {} }
      }
   };
   D.release = function() {
      D.endVideo();
      if (typeof cshBusyOffAll === "function") cshBusyOffAll(D.panelA);          // (el relojito de la foto: fuera y su Timer parado)
      try { D.timer.stop(); } catch (e) {}
      try { D.refitTimer.stop(); } catch (eRT) {}
      try { D.previewTimer.stop(); } catch (ePT) {}
      var S = D.S;
      S.photo = null; S.res = null; S.list = []; S.sel = -1; S.hover = -1; S.group = null; S.groupKey = ""; S.tip = null; S.hits = {};
      S.frame = null; S.gaiaPreview = null; S.photoViewId = "";
      S.clockT = null; S.clockPhoto = false; S.clockVisit = null; D.clockSrc = { video: null, galaxy: null }; D._clockKey = "";
      var cs2 = [D.panelA, D.panelB, D.panelC, D.panelD];
      for (var i = 0; i < cs2.length; ++i) { try { cs2[i].base = null; cs2[i].stale = true; } catch (e2) {} }
      CC_GSE_BMP = null;
   };
   // cancel() DIFERIDO: llamado dentro del manejador anidado que lanzó el análisis, cortaba el script sin volver de
   // execute() (medido en CabraQuality, 15-oct): un temporizador corto lo saca de ahí.
   D.closeLater = function() { if (D.closeTimer) return; cshCloseLater(D, 0.03); D.closeTimer = D._cshCloseTimer; };   // (comun: csh_close.js)
   D.requestClose = function(how) {
      if (!D.closedHow) D.closedHow = how || "";
      D.closing = true; CC_ABORT = true;
      try { D.timer.stop(); } catch (e) {}
      try { D.previewTimer.stop(); } catch (ePT) {}
      if (D.closeLive < 0) D.closeLive = ccParLiveSafe();             // (pruebas: cuántos curl había vivos al cerrar)
      if (D.busy || D.previewing) { D.say(ccT("closing"), 0, true); return; }      // el análisis (o la vista previa) se suelta y cierra él (finally)
      if (D.videoMidStep() && !ccBroken("closevideo")) { D.waitVideo = true; try { D.videoRec().rec.encodeCancel = true; } catch (eEC) {} D.say(ccT("closing"), 0, true); return; }
      D.release();
      D.cancel();
   };
   D.onClose = function() {                                          // el aspa
      D.mark("onClose (busy " + D.busy + ")");
      if (!D.closedHow) D.closedHow = "aspa";
      D.closing = true; CC_ABORT = true;
      try { D.timer.stop(); } catch (e) {}
      try { D.previewTimer.stop(); } catch (ePT) {}
      if (D.closeLive < 0) D.closeLive = ccParLiveSafe();             // (pruebas: cuántos curl había vivos al cerrar)
      if (D.busy || D.previewing) { D.say(ccT("closing"), 0, true); return false; }  // ahora no: el análisis se suelta (ms) y cierra
      if (D.videoMidStep() && !ccBroken("closevideo")) { D.waitVideo = true; try { D.videoRec().rec.encodeCancel = true; } catch (eEC) {} D.say(ccT("closing"), 0, true); return false; }
      D.release();
      return true;
   };
   D.onKeyPress = function(key, modifiers) {                         // Esc no pasa por onClose: se coge aquí
      if (key === 0x1b) { D.requestClose("esc"); return true; }
      if ((key >>> 0) === 0x70000001) D.shiftHeld = true;             // Key_Shift (pjsr/KeyCodes.jsh): Mayús + clic en Analizar
      return false;
   };
   D.onKeyRelease = function(key, modifiers) { if ((key >>> 0) === 0x70000001) D.shiftHeld = false; return false; };

   // --- comportamiento ----------------------------------------------------------------
   D.say = function(text, frac, busy, error, right) {
      D.S.prog = { text: text || "", frac: frac || 0, busy: !!busy, error: !!error, right: right || "" };
      if (ccBroken("barheight")) D.progress.setFixedHeight(ccPx(error || busy ? CC_UI.FOOT_H + 12 : CC_UI.FOOT_H));
      D.progress.update();
      try { D.panelStatus.update(); } catch (eP) {}
   };
   // (2-nov, AY-7) Como D.say, pero para un estado QUE SE PUEDE RETRADUCIR: `fn()` da el texto con el idioma de ese momento (y `rightFn()` el de la
   // derecha). Se guarda en prog.re y D.retranslate lo vuelve a pintar al cambiar ES/EN; un D.say normal lo borra (textos sueltos: errores, motor).
   D.sayR = function(fn, frac, busy, error, rightFn) {
      D.say(fn(), frac, busy, error, rightFn ? rightFn() : "");
      D.S.prog.re = { fn: fn, right: rightFn || null };
   };
   // «↻ Retry»: solo cuando lo que pasó lo pide (sin conexión, o faltan consultas); el mismo sitio siempre
   // la barra de estado en reposo: lo que dijo el último análisis (o «elige una imagen»). La usa II al acabar una vista previa.
   D.sayIdle = function() {
      if (D.busy) return;
      var r = D.S.res;
      if (!r || !r.coverage) { D.sayR(function() { return ccT("noImage"); }, 0, false, false); return; }
      var T1 = ccStatusText(r, CC_LANG);
      if (T1 && T1.title && r.status && r.status.kind !== "ok") D.sayR(function() { var T = ccStatusText(r, CC_LANG); return T.title + " — " + T.body; }, r.status.kind === "net" ? 0 : 1, false, T1.error);
      else D.sayR(function() { return ccT("ready"); }, 1, false, false);
   };
   D.syncRetry = function() {
      var T = D.S.res ? ccStatusText(D.S.res, CC_LANG) : null, on = !!(T && T.retry) && !D.busy;
      D.retryShown = on;
      if (on) D.retryBtn.show(); else D.retryBtn.hide();
   };
   D.invalidate = function() {
      if (D.fitLeft) D.fitLeft();          // (otra foto u otro encuadre: otro alto para la línea de tiempo bajo la foto)
      D.panelA.stale = true; D.panelB.stale = true; D.panelC.stale = true; D.panelD.stale = true;
      D.panelA.update(); D.panelB.update(); D.panelC.update(); D.panelD.update();
      D.timeline.update(); D.card.update();
      // (30-oct) con «Stars» recordado, al llegar los resultados la foto pasa de limpia a «Stars» con el fundido de siempre
      try { if (!D.closing && D.timer && !D.timer.isRunning && ccIsNum(D.S.anim.aMix) && D.S.anim.aMix !== ((ccAViewEff(D.S) === "photo") ? 0 : 1)) { D.lastTick = 0; D.timer.start(); } } catch (eAV) {}
      try { for (var iS = 0; iS < D.sections.length; ++iS) D.sections[iS].update(); } catch (eS) {}
      try { D.panelStatus.update(); D.titleCtl.update(); } catch (e) {}
   };
   D.openSection = function(hdr) {
      for (var i = 0; i < D.sections.length; ++i) {
         var h = D.sections[i], on = (h === hdr);
         if (ccBroken("accordion") && !on && h.ccOpen) continue;    // (rojo: los demás no se cierran)
         if (h.ccOpen === on) { h.update(); continue; }
         h.ccOpen = on;
         if (on) h.ccBody.show(); else h.ccBody.hide();
         h.update();
      }
      // III: el mapa en la columna de B/C/D mientras está abierto (el cuerpo avisa solo con onShow/onHide en una ventana visible; aquí
      // también a mano —idempotente—: con la ventana aún sin enseñar, o maquetada sin mostrarse, Qt no manda esos avisos)
      try { if (D.galaxy) D.galaxy.setOpen(D.galaxyBox.ccMounted === true && D.sections[2].ccOpen === true); } catch (eGo) {}
      if (hdr && (hdr.ccBody === D.journeyBox || hdr.ccBody === D.galaxyBox)) D.videoSync(false);
      D.fitGroups();
      D.fitButtons();
      try { D.refitTimer.start(); } catch (eR) {}       // (y otra vez ya maquetado: lo que mida de verdad)
   };
   D.refitTimer = new Timer; D.refitTimer.interval = 0.06; D.refitTimer.periodic = false;
   D.refitTimer.onTimeout = function() { if (!D.closing) D.fitGroups(); };
   D.select = function(idx) {
      if (!D.S.res) return;
      var S = D.S, prev = (S.sel >= 0 && S.res.stars[S.sel] && S.res.stars[S.sel].age.adopted) ? S.res.stars[S.sel].age.adopted.v : null;
      if (idx === S.sel) return;
      S.sel = idx;
      S.anim.sel = 0; S.anim.card = 0;
      S.anim.tlFrom = prev;
      S.cardScroll = 0;
      D.lastTick = 0;
      if (!D.closing && !D.timer.isRunning) D.timer.start();
      D.panelA.update(); D.panelB.update(); D.panelC.update(); D.panelD.update(); D.timeline.update(); D.card.update();
   };
   D.stepAnim = function(dt) {
      var S = D.S, moving = false;
      if (S.anim.sel < 1) { S.anim.sel = Math.min(1, S.anim.sel + dt / (CC_ATLAS.motionMs / 1000)); moving = true; }
      if (S.anim.card < 1) { S.anim.card = Math.min(1, S.anim.card + dt / 0.45); moving = true; }
      var aT = (ccAViewEff(S) === "photo") ? 0 : 1;          // el fundido foto real <-> composición (350 ms); sin resultados, la foto
      if (!ccIsNum(S.anim.aMix)) S.anim.aMix = aT;
      if (S.anim.aMix !== aT) { var stA = dt / 0.35; S.anim.aMix = (S.anim.aMix < aT) ? Math.min(aT, S.anim.aMix + stA) : Math.max(aT, S.anim.aMix - stA); D.panelA.stale = true; moving = true; }
      if (S.sel >= 0) S.anim.pulse = (S.anim.pulse + dt / 2.4) % 1;    // tokens.json · motion.slow = 2 400 ms
      D.panelA.update(); D.panelB.update(); D.panelC.update(); D.panelD.update();
      if (moving) { D.timeline.update(); D.card.update(); }
      if (S.sel < 0 && !moving) D.timer.stop();
   };
   // Los textos del armazón (el idioma cambia en vivo) y los anchos de los botones al de su texto
   D.syncTexts = function() {
      D.langBtn.text = (CC_LANG === "es") ? "EN" : "ES"; D.langBtn.toolTip = ccWrapTip(ccT("langTip"));
      D.closeBtn.text = "✕ " + ccT("close"); D.closeBtn.toolTip = ccWrapTip(ccT("closeTip"));
      if (D.helpBtn) { try { D.helpBtn.cshHelpRetranslate(); } catch (eHelp) {} }
      D.lblImage.text = ccT("image"); D.lblAstro.text = ccT("astrometry");
      D.imgRefreshBtn.toolTip = ccWrapTip(ccT("imgRefreshTip")); D.fullBtn.toolTip = ccWrapTip(ccT("fullTip"));
      D.analyseBtn.text = ccT("analyse"); D.analyseBtn.toolTip = ccWrapTip(ccT("analyseTip"));
      D.toViewBtn.text = ccT("toView"); D.toViewBtn.toolTip = ccWrapTip(ccT("toViewTip"));
      D.toFileBtn.text = ccT("toFile"); D.toFileBtn.toolTip = ccWrapTip(ccT("toFileTip"));
      D.exportBtn.text = ccT("tableCsv"); D.exportBtn.toolTip = ccWrapTip(ccT("exportTip"));
      D.retryBtn.text = "↻ " + ccT("retry"); D.retryBtn.toolTip = ccWrapTip(ccT("retryTip"));
      D.lblStars.text = ccT("rowStars"); D.lblDiag.text = ccT("rowDiagrams");
      for (var i = 0; i < D.checks.length; ++i) D.checks[i].text = ccT(D.checks[i].ccKey);
      D.split1.toolTip = ccWrapTip(ccT("split1Tip")); D.split2.toolTip = ccWrapTip(ccT("split2Tip"));
      // las cabeceras de los grupos: su subtítulo entero y la frase llana (lo que antes iba en cursiva dentro del cuerpo)
      for (var sI = 0; sI < D.sections.length; ++sI) { var hS = D.sections[sI]; hS.toolTip = ccWrapTip(hS.ccSubText() + (hS.ccHelp ? "\n\n" + ccT(hS.ccHelp[0]) + (hS.ccHelp[1] ? " " + ccT(hS.ccHelp[1]) : "") : "")); }
      try { D.journeyBox.ccWip.text = ccT("wipJourney"); D.galaxyBox.ccWip.text = ccT("wipGalaxy"); } catch (eWp) {}
      var vt = D.videos(); for (var ivt = 0; ivt < vt.length; ++ivt) { try { vt[ivt].retranslate(); } catch (eJr) {} }
      try { if (D.galaxy) D.galaxy.retranslate(); } catch (eGr) {}
      D.syncElements();
      D.panelA.toolTip = "";
      D.syncPills();
      D.fitButtons();
   };
   D.fitButtons = function() {
      var fit = [D.langBtn, D.closeBtn, D.toViewBtn, D.toFileBtn, D.exportBtn, D.retryBtn];
      for (var f = 0; f < fit.length; ++f) ccFitButton(fit[f]);
      if (D.helpBtn) ccFixSize(D.helpBtn, 28, 22);         // (el alto de ES y Cerrar —22 lógicos, ccFitButton— y 1,25 veces de ancho, como csh_help.js matchHeightOf)
      ccFitButton(D.analyseBtn, 36, 0, 11, 26);
      var vf = D.videos(); for (var ivf = 0; ivf < vf.length; ++ivf) { try { var jb = vf[ivf].buttons(); for (var jf = 0; jf < jb.length; ++jf) ccFitButton(jb[jf]); } catch (eJb) {} }
      var ready = !!(D.S.res && !D.busy);
      D.toViewBtn.enabled = ready; D.toFileBtn.enabled = ready; D.exportBtn.enabled = ready;
   };
   D.retranslate = function() {
      D.fillViews();                  // (el «(no hay imágenes abiertas)» del desplegable, en el idioma nuevo)
      D.syncTexts();
      for (var i = 0; i < D.sections.length; ++i) D.sections[i].update();
      if (D.S.res) for (i = 0; i < D.S.res.stars.length; ++i) { var s = D.S.res.stars[i]; s.bio = { en: ccBiography(s, "en"), es: ccBiography(s, "es") }; }
      D.head.update();
      // (2-nov, AY-7) la barra de estado repite el mensaje del estado ACTUAL en el idioma nuevo (antes: con análisis se quedaba en el viejo, y sin
      // él caía al «Abre una imagen…» genérico aunque dijera «Vista previa lista…»). CC_BREAK=statusrt = el defecto (rojo de la prueba).
      var P = D.S.prog;
      if (!D.busy && !ccBroken("statusrt")) {
         if (P && P.re) D.sayR(P.re.fn, P.frac, P.busy, P.error, P.re.right);
         else if (!P || !P.text) D.sayR(function() { return ccT("noImage"); }, 0, false, false);
      } else if (!D.S.res && !D.busy) D.say(ccT("noImage"), 0, false, false, "");
      D.syncRetry();
      D.fitGroups();
      D.invalidate();
   };
   // Otra imagen en el desplegable: su foto, ya (la vista previa); el análisis de la anterior deja de enseñarse.
   D.onViewChanged = function(view) {
      if (!view || view.isNull || D.busy) return;
      if (D.S.viewId !== view.id || !D.S.photo) {
         var S = D.S;
         var ve = D.videos(); for (var ive = 0; ive < ve.length; ++ive) { try { ve[ive].end(); } catch (eJe) {} }           // (una vista previa de la imagen de antes se para)
         try { if (D.galaxy) D.galaxy.stop(); } catch (eGs) {}
         S.res = null; S.list = []; S.sel = -1; S.hover = -1; S.group = null; S.groupKey = ""; S.tip = null;
         D.sayR(function() { return ccT("noImage"); }, 0, false, false);
         D.syncElements();
         D.videoSync(true);
         D.schedulePreview();
      }
      D.titleCtl.update(); D.panelStatus.update();
   };

   // --- LA VISTA PREVIA (22-oct, noche; queja de Nino: «al abrir no se carga la imagen hasta que se cargan todas las bases de datos»):
   // nada más mostrarse el diálogo (y al cambiar de imagen) la foto se pinta YA, con su STF, sin esperar a «Analizar»; y si la imagen
   // tiene solución astrométrica, las estrellas G<17 de la base Gaia local encima (anillos neutros: aún sin química). Con un Timer
   // tras mostrarse: la ventana aparece primero. Lo de la base Gaia local queda en la sesión (cshGaiaLocalField): «Analizar» lo
   // reutiliza sin volver a arrancar los .xpsd. Como CabraStars («se ve nada más elegir la imagen»).
   D.previewing = false; D.analyseQueued = null; D.previewAgain = false; D.closeLive = -1;
   D.previewTimer = new Timer; D.previewTimer.interval = 0.05; D.previewTimer.periodic = false;
   D.previewTimer.onTimeout = function() { if (!D.closing && !D.busy) D.previewNow(); };
   D.schedulePreview = function() { if (D.closing || D.busy) return; if (D.previewing) { D.previewAgain = true; return; } try { D.previewTimer.stop(); D.previewTimer.start(); } catch (e) {} };
   D.previewNow = function() {
      if (D.closing || D.busy || D.previewing || ccBroken("nopreview")) return;
      var v = D.currentView(), S = D.S;
      if (!v) return;
      D.previewing = true;
      if (typeof cshBusyOn === "function") cshBusyOn(D.panelA, "preview");
      try {
         if (!(S.photo && S.photoViewId === v.id)) {
            D.say(ccT("previewPhoto"), 0, true, false, "");
            var ph = null;
            CC_QUIET = true;
            try { ph = ccPhotoBitmap(v, 2000); } finally { CC_QUIET = false; }
            if (D.closing) return;
            S.photo = ph; S.photoViewId = v.id; S.viewId = v.id; S.photoAt = Date.now();
            S.frame = { width: v.image.width, height: v.image.height };
            S.gaiaPreview = null; S.gaiaPreviewAt = 0;
            S.zoom = { k: 1, cx: S.frame.width / 2, cy: S.frame.height / 2 };
            D.panelA.stale = true; D.invalidate();
            try { CoreApplication.processEvents(); } catch (eP) {}       // (que se vea ANTES de preguntar a la base local)
         }
         if (D.closing) return;
         var solved = false; try { solved = ccHasSolution(v); } catch (eS) {}
         if (solved && !S.gaiaPreview && !S.res) {
            var field = ccFieldFromView(v);
            if (field.ok && typeof ccGaiaLocalField === "function") {
               D.say(ccT("gaiaLocalAsk"), 0, true, false, "");
               try { CoreApplication.processEvents(); } catch (eP2) {}
               var gl = null; try { gl = ccGaiaLocalField(field); } catch (eG) { gl = null; }
               if (D.closing) return;
               if (gl && gl.ok) {
                  var GF = ccGaiaFieldStars(gl, field, null);
                  S.gaiaPreview = { pts: GF.gaiaField, inFrame: GF.nIn, name: gl.release || gl.name || "DR3", ms: gl.ms, reused: !!gl.reused };
                  S.gaiaPreviewAt = Date.now();
                  D.panelA.stale = true; D.panelA.update();
               }
            }
         }
         if (!S.res) {
            var GP = S.gaiaPreview;
            D.sayR(function() { return GP ? ccT("previewReady").replace("%1", ccThou(GP.pts.length, CC_LANG)).replace("%2", GP.name) : ccT(solved ? "previewReadyNoGaia" : "previewReadyNoSolution"); }, 0, false, false);
         }
      } catch (eX) {
         D.say("Preview: " + String(eX), 0, false, true, "");
      } finally {
         D.previewing = false;
         if (typeof cshBusyOff === "function") cshBusyOff(D.panelA, "preview");
         D.titleCtl.update(); D.panelStatus.update();
         if (D.closing) { D.release(); D.closeLater(); }
         else if (D.analyseQueued !== null) { var rq = D.analyseQueued; D.analyseQueued = null; D.analyse(rq); }
         else if (D.previewAgain) { D.previewAgain = false; D.schedulePreview(); }
      }
   };

   // --- LA CARGA GRADUAL: cada resultado parcial del motor (ccRun opts.onPartial) se enseña en cuanto llega: estrellas en la foto,
   // puntos en B/C/D, la cobertura. La elegida se conserva (por su id de Gaia o su nombre); el zoom no se toca.
   D.partials = 0;
   D.showPartial = function(res) {
      if (D.closing || !res || ccBroken("nopartial")) return;
      var S = D.S, keep = (S.sel >= 0 && S.res && S.res.stars[S.sel]) ? (S.res.stars[S.sel].id || S.res.stars[S.sel].name || "") : "";
      if (typeof ccHipFill === "function") { try { ccHipFill(res); } catch (eHip) {} }      // (27-oct, D4) los nombres de Hipparcos
      S.res = res; S.list = ccVisibleList(res); S.hover = -1; S.tip = null;
      S.sel = -1;
      if (keep) for (var i = 0; i < S.list.length; ++i) { var s = res.stars[S.list[i]]; if ((s.id || s.name) === keep) { S.sel = S.list[i]; break; } }
      if (S.group) { S.group = null; S.groupKey = ""; }
      ++D.partials;
      D.syncElements();
      D.invalidate();
      D.videoSync(true);
   };

   // --- LOS PANELES: límites de los separadores y lo recordado (CabraStars _layoutBounds/_fixHalves/_onSplit) -------
   D.layoutBounds = function() {
      var PM = D.minOf(CC_UI.PHOTO_MIN), RM = D.minOf(CC_UI.RIGHT_MIN), CM = D.minOf(CC_UI.COL_MIN), KM = D.minOf(CC_UI.CARD_MIN), SW = ccPx(CC_UI.SPLIT_W);
      if (ccBroken("nomin")) { PM = 1; CM = 1; }
      var room = Math.max(PM + RM, D.width - ccPx(16) - SW);                  // foto + panel derecho
      var pmin = PM, pmax = Math.max(pmin, room - RM);
      var pw = (D.lay.photo !== null) ? Math.max(pmin, Math.min(pmax, ccPx(D.lay.photo))) : Math.max(pmin, Math.min(pmax, Math.floor(room * 0.46)));
      var rightW = room - pw, cmin = CM, cmax = Math.max(cmin, rightW - SW - KM);
      return { room: room, photo: [pmin, pmax], photoW: pw, rightW: rightW, col: [cmin, cmax] };
   };
   // La foto y la columna, a su ancho: lo fijado con los separadores (acotado) o el de fábrica (la foto, la mitad de la
   // ventana —si no, abrir un grupo ancho podría ensanchar el panel y encoger la foto: CabraStars lo midió—; aquí el 46 %:
   // el panel derecho lleva tres diagramas, la ficha y la línea de tiempo; la columna, el 47 % del panel derecho).
   D.fixHalves = function() {
      try {
         var B = D.layoutBounds();
         if (D._photoW !== B.photoW) { D._photoW = B.photoW; D.panelA.setFixedWidth(B.photoW); }
         var cw = (D.lay.col !== null) ? ccPx(D.lay.col) : Math.round((B.rightW - ccPx(CC_UI.SPLIT_W)) * 0.47);
         cw = Math.max(B.col[0], Math.min(B.col[1], cw));
         if (D._colW !== cw) { D._colW = cw; D.colBox.setFixedWidth(cw); }
      } catch (e) {}
      D.fitLeft();
   };
   // (23-oct · R9) LA MITAD IZQUIERDA: la foto encajada a su ancho (con el título encima y la leyenda colgando debajo) y la línea de
   // tiempo en lo que quede, entre TIMELINE_H y TIMELINE_MAX. Así no queda hueco negro bajo la foto apaisada; una foto alta (o una
   // ventana baja) deja a la línea de tiempo en su mínimo y la foto encaja en lo demás. Depende solo del ancho de la foto (S1) y del
   // encuadre: abrir o cerrar grupos no la mueve.
   D.fitLeft = function() {
      if (D.tlRight) return;
      try {
         var H = (D.rightBox.height > ccPx(200)) ? D.rightBox.height : D.height - ccPx(CC_UI.HEAD_H + CC_UI.BAR_H + CC_UI.FOOT_H + 12);
         var w = D._photoW || D.panelA.width, gap = ccPx(CC_UI.LEFT_GAP), need = ccPhotoNeedH(D.S, w, ccScale(D));
         var eMin = ccPx(CC_UI.TIMELINE_H), eMax = ccPx(CC_UI.TIMELINE_MAX);
         var eh = need > 0 ? Math.max(eMin, Math.min(eMax, H - gap - need)) : eMin;
         eh = Math.max(Math.min(eMin, H - gap - D.minOf(300)), Math.min(eh, H - gap - D.minOf(300)));   // (la foto, nunca por debajo de su mínimo)
         if (D._tlH !== eh) { D._tlH = eh; D.timeline.setFixedHeight(eh); }
      } catch (eF) {}
   };
   D.onSplit = function(which, w, final) {
      var lg = Math.round(w / ccScale());
      if (which === "photo") { D.lay.photo = lg; D._photoW = w; } else { D.lay.col = lg; D._colW = w; }
      D.fixHalves();
      if (final) { ccLayoutWrite(which === "photo" ? "photoW" : "colW", lg); D.fitGroups(); D.invalidate(); }
   };
   D.splitReset = function(which) {
      if (which === "photo") D.lay.photo = null; else D.lay.col = null;
      D.fixHalves();
      ccLayoutWrite(which === "photo" ? "photoW" : "colW", 0);
      D.invalidate();
   };
   // El cuerpo de un grupo con rueda (registrado en `hdr.ccFit`): todo su contenido si cabe; si no, lo que deja libre el resto del panel
   // sin bajar los diagramas de su mínimo (la ventana NO crece al abrir un grupo, y la foto no se mueve).
   D.groupRoom = function() {
      // (el alto REAL del panel derecho si ya está maquetado: la cuenta desde la ventana se pasaba 10 px —medido en T13 U3—)
      var H = (D.rightBox.height > ccPx(200)) ? D.rightBox.height : D.height - ccPx(CC_UI.HEAD_H + CC_UI.BAR_H + CC_UI.FOOT_H + 12);
      // (con un grupo abierto, a cada diagrama se le guardan PLOT_OPEN; el cuerpo del grupo cede lo que falte y va con rueda. Desde el
      //  23-oct —R9— la línea de tiempo no está en esta columna: no cuenta; salvo en el rojo `tlright`)
      var open = D.anyOpen(), fixed = ccPx(D.sections.length * CC_UI.GROUP_H + 6 + CC_UI.STATUS_H + 4 + CC_UI.TITLE_H + (D.tlRight ? 6 + CC_UI.TIMELINE_H : 0)) +
                  3 * D.minOf(open && !D.tlRight ? CC_UI.PLOT_OPEN : CC_UI.PLOT_MIN) + 2 * ccPx(6);
      return H - fixed - ccPx(4) - (D._fitSlack || 0) - (open ? (D._fitSlackOpen || 0) : 0);      // (+ lo aprendido midiendo: ver fitGroups)
   };
   D.anyOpen = function() { for (var i = 0; i < D.sections.length; ++i) if (D.sections[i].ccOpen) return true; return false; };
   D.fitGroups = function() {
      var rw = (D.rightBox.width > ccPx(100)) ? D.rightBox.width : D.layoutBounds().rightW;
      var room = D.groupRoom();
      // (hasta el 22-oct, II · Cobertura y III · Familias; ahora, los que la integración registre: `hdr.ccFit = { canvas, extra }`)
      var bodies = [];
      for (var bI = 0; bI < D.sections.length; ++bI) { var fI0 = D.sections[bI].ccFit; if (fI0 && fI0.canvas) bodies.push([fI0.canvas, D.sections[bI], fI0.extra || 0]); }
      for (var i = 0; i < bodies.length; ++i) {
         var c = bodies[i][0], hdr = bodies[i][1];
         if (!hdr || !hdr.ccOpen) continue;
         var need = c.measure(rw);
         var hh = ccBroken("groupfit") ? need : Math.max(ccPx(CC_UI.GROUP_MIN) - bodies[i][2], Math.min(need, room - bodies[i][2]));
         // y lo que MIDE ya maquetado: si el panel D se sale por abajo de su columna, el cuerpo cede eso (la cuenta de arriba
         // se quedaba corta por unos píxeles que no se dejan predecir: T13 U3)
         if (!ccBroken("groupfit") && c._fitH > 0 && D.colBox.height > ccPx(100)) {
            var over = 0; try { over = D.panelD.position.y + D.panelD.height - D.colBox.height; } catch (eO) {}
            if (over > 0) { D._fitSlack = (D._fitSlack || 0) + over + 1; hh = Math.max(ccPx(CC_UI.GROUP_MIN) - bodies[i][2], Math.min(hh, c._fitH - over - 1)); }
         }
         // con un grupo abierto, B/C/D tienen que quedarse con PLOT_OPEN: lo que les falte YA maquetados lo cede el cuerpo, y se
         // aprende (`_fitSlackOpen`) para no oscilar entre una medida y la siguiente (T15 midió 145 de 150 con II abierto: la cuenta se quedaba corta)
         if (!ccBroken("groupfit") && !D.tlRight && c._fitH > 0 && D.colBox.height > ccPx(100)) {
            var mnP = Math.min(D.panelB.height, D.panelC.height, D.panelD.height), wantP = D.minOf(CC_UI.PLOT_OPEN);
            if (mnP > 0 && mnP < wantP && c._fitH > ccPx(CC_UI.GROUP_MIN) - bodies[i][2]) { var cut = 3 * (wantP - mnP); D._fitSlackOpen = Math.min(ccPx(60), (D._fitSlackOpen || 0) + cut); hh =Math.max(ccPx(CC_UI.GROUP_MIN) - bodies[i][2], Math.min(hh, c._fitH - cut)); }
         }
         if (c._fitH !== hh) { c._fitH = hh; c.setFixedHeight(hh); }
         c.ccScroll = 0;
      }
      D.fitLeft();
   };
   // PANTALLA COMPLETA: la ventana ocupa la pantalla disponible; otra vez, vuelve a su tamaño y sitio (CabraStars toggleFull)
   D.toggleFull = function() {
      try {
         if (!D._fullGeom) {
            D._fullGeom = { x: D.position.x, y: D.position.y, w: D.width, h: D.height };
            var r = D.availableScreenRect;
            D.position = new Point(r.x0, r.y0);
            D.resize(r.width, r.height);
         } else {
            var G = D._fullGeom; D._fullGeom = null;
            D.resize(G.w, G.h);
            D.position = new Point(G.x, G.y);
         }
      } catch (e) { D._fullGeom = null; }
      D.fixHalves(); D.fitGroups();
      D.fullBtn.ccOn = !!D._fullGeom; D.fullBtn.update();
   };

   // --- LO PINTADO del panel: la línea de estado y el título ------------------------------------------
   D.panelStatusText = function() {
      var E = CC_LANG === "es", r = D.S.res;
      if (D.busy) return { text: ccT("analysing"), kind: "busy" };
      if (!r) return D.currentView() ? { text: ccT("notAnalysed"), kind: "pending" } : { text: ccT("pillNoView"), kind: "pending" };
      var T = ccStatusText(r, CC_LANG);
      var Q = r.queries || [], nOk = 0, nCache = 0, nOn = 0;
      for (var i = 0; i < Q.length; ++i) { if (Q[i].message === "off") continue; ++nOn; if (Q[i].ok) ++nOk; if (Q[i].cached) ++nCache; }
      var parts = [];
      var c = r.coverage || {}, fs = c.fehSrc || {}, src = [];
      for (var k in fs) if (fs.hasOwnProperty(k)) src.push([k, fs[k]]);
      src.sort(function(a, b) { return b[1] - a[1]; });
      if (src.length) parts.push(ccT("fehFrom") + " " + src.map(function(p) { return (CC_SURVEY_LABEL[p[0]] || ccCatName(p[0])) + " " + ccThou(p[1], CC_LANG); }).join(" · "));
      if (nOn) parts.push(nCache === nOn ? ccT("allCached") : ccT("catsAnswered").replace("%1", nOk).replace("%2", nOn) + (nCache ? " (" + nCache + " " + ccT("cached") + ")" : ""));
      if (r.gaiaLocal && !r.gaiaLocal.missing) parts.push((E ? "Gaia local (" : "local Gaia (") + r.gaiaLocal.name + ")");
      // 17 (22-oct): si respondió un ESPEJO de VizieR (el principal cayó), se dice el primero (cc_pixinsight.js ccNetStatus)
      var NM = D.S.netMirror, mir = (NM && NM.mirror && NM.viaMirror > 0 && !ccBroken("nomirrortext")) ? D.mirrorText(NM) : "";
      if (mir) parts.unshift(mir);
      if (T) return { text: T.title + (parts.length ? " · " + parts.join(" · ") : ""), kind: T.error ? "error" : "warn" };
      return { text: parts.join(" · "), kind: (nOk < nOn || mir) ? "warn" : "ok" };
   };
   // (22-oct, revisor: textos cortados en la ventana de 1200 × 880) Lo que no cabe se corta con «…» y el texto ENTERO va al tooltip.
   D.tipIfCut = function(ctrl, full, shown) { var t = (shown !== full) ? String(full) : ""; if (ctrl && ctrl.ccTipNow !== t) { ctrl.ccTipNow = t; try { ctrl.toolTip = ccWrapTip(t); } catch (e) {} } };
   D.mirrorText = function(NM) {
      var m = /\(([^)]*?)\s*mirror\)/i.exec(String(NM.mirror)), who = m ? m[1] : String(NM.mirror);
      return ccT("mirrorUsed").replace("%1", who).replace("%2", ccThou(NM.viaMirror, CC_LANG));
   };
   D.paintPanelStatus = function(g, w, h, s2) {
      ccFillRect(g, 0, 0, w, h, ccInt(A.bg));
      var st = D.panelStatusText(), C = ccPillColors(st.kind), x = ccPaintPill(g, 0, 0, w, h, s2, st.kind), f = ccFont("text", 8.8 * s2);
      var shown = ccElide(f, st.text, Math.max(10, w - x - 8 * s2));
      ccTextAt(g, f, C.text, x, Math.round((h + f.ascent - f.descent) / 2), shown);
      if (w === D.panelStatus.width) D.tipIfCut(D.panelStatus, st.text, shown);
   };
   // (23-oct, noche, revisión visual 4) Las cifras de la cabecera: en la ventana, la frase entera si cabe; si no, su forma CORTA
   // (ccCountsText "short") y la entera en el tooltip; en la exportada (exp), la entera partida en las líneas que hagan falta
   // (D.titleLines). ROJO «exportcut»: la exportada vuelve a cortar con «…».
   D.titleSub = function(form) {
      var r = D.S.res, sub = "";
      if (r && r.field) {
         var F = r.field, sa = F.scaleArcsec, wd = F.width * sa / 3600, hd = F.height * sa / 3600, c0 = r.coverage || {};
         if (ccIsNum(sa) && sa > 0) sub = ccT("fieldOf").replace("%1", ccDec(wd, wd < 1 ? 2 : 1, CC_LANG)).replace("%2", ccDec(hd, hd < 1 ? 2 : 1, CC_LANG));
         else sub = ccFmtL(F.ra, 2) + " " + ccFmtSignedL(F.dec, 2);
         if (ccIsNum(c0.gaiaG17)) sub += " · " + (form === "short" && !ccBroken("oldcounts") ? ccCountsText(r, CC_LANG, ccBroken("listcount") ? (D.S.list || []).length : undefined, "short") : D.countsText(r));
      }
      return sub;
   };
   // Las líneas de la cabecera en la exportada: [primera (a la derecha del nombre), resto (bajo el nombre)] y el alto extra que piden
   // (2-nov-2026, S4a) El nombre que se ve: el id de la vista con su espacio («Collinder34» -> «Collinder 34»; ccViewObjectName, cc_field.js). Recordado por
   // (id, centro del campo): leer los catálogos de cúmulos cuesta decenas de ms. ROJO «oldtitle»: el id tal cual.
   D.viewName = function() {
      var r = D.S.res, raw = D.S.viewId || (r && r.field && r.field.synthetic ? (CC_LANG === "es" ? "campo sintético" : "synthetic field") : "") || D.currentViewId() || ccT("noImageName");
      if (ccBroken("oldtitle")) return raw;
      var f = (r && r.field) ? r.field : null, key = raw + "|" + (f ? ccFmt(f.ra, 3) + "," + ccFmt(f.dec, 3) : "");
      if (D._viewNameKey !== key) {
         D._viewNameKey = key;
         var tabs = ccClusterTables(), nm = "";
         try { nm = ccViewObjectName(raw, tabs, f); } catch (eN) {}
         D._viewNameVal = nm.length ? nm : raw;
      }
      return D._viewNameVal;
   };
   D.titleLines = function(w, s2) {
      var big = ccFont("display", 18 * s2), fI = ccFont("display", 10.6 * s2, false, true), r = D.S.res;
      var nm = D.viewName();
      var sx = Math.round(2 * s2) + big.width(nm) + Math.round(12 * s2), qW = Math.round(18 * s2), sub = D.titleSub("full");
      var w1 = Math.max(10, w - sx - 4 * s2 - qW), wN = Math.max(10, w - 4 * s2 - qW), words = sub.split(" "), first = "", k = 0;
      while (k < words.length && fI.width(first ? first + " " + words[k] : words[k]) <= w1) { first = first ? first + " " + words[k] : words[k]; ++k; }
      var rest = (k < words.length) ? ccWrap(fI, words.slice(k).join(" "), wN) : [];
      var lineH = Math.round(fI.ascent + fI.descent + 3 * s2);
      return { first: first, rest: rest, lineH: lineH, extra: rest.length * lineH, sx: sx };
   };
   D.paintTitle = function(g, w, h, s2, exp) {
      ccFillRect(g, 0, 0, w, h, ccInt(A.bg));
      var fC = ccFont("text", 9.6 * s2, true, false, Math.round(9.6 * s2 * CC_ATLAS.labelTracking)), y1 = Math.round(4 * s2) + fC.ascent;
      ccTextAt(g, fC, ccInt(A.gold), Math.round(2 * s2), y1, ccT("viewTitle"));
      var r = D.S.res, nm = D.viewName();
      var big = ccFont("display", 18 * s2), y2 = y1 + fC.descent + Math.round(4 * s2) + big.ascent, nmE = ccElide(big, nm, w * 0.45);
      ccTextAt(g, big, ccInt(A.text), Math.round(2 * s2), y2, nmE);
      var sx = Math.round(2 * s2) + big.width(nmE) + Math.round(12 * s2), sub = "", fI = ccFont("display", 10.6 * s2, false, true);
      if (r && r.field) sub = D.titleSub("full");
      else {
         var v = D.currentView();
         if (v) { try { sub = v.image.width + " × " + v.image.height + " px"; } catch (eS) {} }
      }
      var hasCov = !!(r && r.coverage), qW = hasCov ? Math.round(18 * s2) : 0, availS = Math.max(10, w - sx - 4 * s2 - qW), subE;
      if (exp && r && r.field && !ccBroken("exportcut")) {
         // la exportada: la frase ENTERA, en las líneas que pida (el alto ya lo dio D.titleLines a exportBitmap)
         var TLx = D.titleLines(w, s2);
         subE = TLx.first;
         ccTextAt(g, fI, ccInt(A.text3), sx, y2, TLx.first);
         for (var li = 0; li < TLx.rest.length; ++li) ccTextAt(g, fI, ccInt(A.text3), Math.round(2 * s2), y2 + (li + 1) * TLx.lineH, TLx.rest[li]);
         if (TLx.rest.length) { var lastL = TLx.rest[TLx.rest.length - 1]; if (hasCov) ccQMark(g, Math.round(2 * s2) + fI.width(lastL) + Math.round(6 * s2), y2 + TLx.rest.length * TLx.lineH + Math.round(1 * s2), s2); hasCov = false; }
      } else {
         if (r && r.field && fI.width(sub) > availS && !ccBroken("footdots") && !(exp && ccBroken("exportcut"))) sub = D.titleSub("short");     // (la forma corta; la entera, al tooltip)
         subE = ccElide(fI, sub, availS);
         ccTextAt(g, fI, ccInt(A.text3), sx, y2, subE);
      }
      // (22-oct, fase 1) el «?» de las cifras: su tooltip es la cobertura entera (lo que era el grupo II · Cobertura y fuentes)
      if (hasCov) {
         var qx = sx + fI.width(subE) + Math.round(6 * s2);
         ccQMark(g, qx, y2 + Math.round(1 * s2), s2);
         if (w === D.titleCtl.width) D.covQ = { x0: qx - Math.round(4 * s2), y0: y2 - Math.round(14 * s2), x1: qx + Math.round(16 * s2), y1: y2 + Math.round(5 * s2) };
      } else if (w === D.titleCtl.width) D.covQ = null;
      if (w === D.titleCtl.width) {
         var subFull = (r && r.field) ? D.titleSub("full") : sub, full = nm + " · " + subFull;
         D.titleCutTip = (nmE !== nm || subE !== subFull) ? full : "";
         D.titleShown = subE;          // (lo que se ve: las pruebas miran que no lleve «…»)
         if (!D.titleCtl.ccTipNow || D.titleCtl.ccTipNow.indexOf("<html>") !== 0) D.tipIfCut(D.titleCtl, full, D.titleCutTip ? "" : full);
      }
   };
   // 8 · LOS RECUENTOS, cada uno con lo que cuenta (22-oct, revisor: «152 con química» frente a «91 de 421» y «177 con datos»):
   // las del encuadre que están en ALGÚN catálogo (= «El campo, en llano» y la población de II), y de ellas las que tienen [Fe/H],
   // edad y cinemática. (Las G<17 con [Fe/H], el porcentaje, en II.)
   // (23-oct, P3 de docs/contradicciones_ficha.md: la frase es la de cc_story.js, ccCountsText —«177 en algún catálogo (de cualquier
   //  brillo; 95 con G<17): …»—; aquí solo el rojo `listcount` de T13 y `oldcounts` de T20, la frase de antes sin el brillo)
   D.countsText = function(r) {
      var t = ccCountsText(r, CC_LANG, ccBroken("listcount") ? (D.S.list || []).length : undefined);
      return ccBroken("oldcounts") ? t.replace(/ \([^()]*G<17\)/, "") : t;
   };

   // Cargar un resultado (lo usa el análisis y los tests).
   D.loadResult = function(res, photo, viewId) {
      if (D.closing) return;
      var S = D.S, sameImage = (viewId && viewId === S.viewId);
      if (res && typeof ccHipFill === "function") { try { ccHipFill(res); } catch (eHip) {} }      // (27-oct, D4) los nombres de Hipparcos («Alcyone»)
      S.res = res; S.photo = photo || null; S.viewId = viewId || "";
      S.list = ccVisibleList(res);
      S.group = null; S.groupKey = ""; S.hover = -1; S.sel = -1;
      if (!sameImage && res && res.field) S.zoom = { k: 1, cx: res.field.width / 2, cy: res.field.height / 2 };
      D.syncElements();
      D.invalidate();
      if (!D.busy && res && res.coverage) {
         var T1 = ccStatusText(res, CC_LANG);
         if (T1) D.sayR(function() { var T = ccStatusText(res, CC_LANG); return T.title + " — " + T.body; }, res.status.kind === "net" ? 0 : 1, false, T1.error);
         else D.sayR(function() { return ccT("ready"); }, 1, false, false);
      }
      D.syncRetry();
      D.fitGroups();
      D.fitButtons();
      var pick = ccAutoPick(res, S.list);
      if (pick >= 0) D.select(pick);
      D.videoSync(true);
   };
   D.analyse = function(refresh) {
      if (D.busy || D.closing) return;
      // (II · III) mientras se graba un vídeo no se analiza (el botón está apagado; esto es por si llega de otro sitio); una vista previa
      // o «▶ Animar» se paran: el análisis cambia lo que enseñan
      if (D.videoRec()) { D.say(ccT("videoBusy"), 0, false, true); return; }
      var va = D.videos(); for (var iva = 0; iva < va.length; ++iva) { try { va[iva].end(); } catch (eJe) {} }
      try { if (D.galaxy) D.galaxy.stop(); } catch (eGs) {}
      if (D.previewing) { D.analyseQueued = !!refresh; return; }      // (la vista previa está en la base Gaia local: al acabar, analiza)
      CC_ABORT = false;
      D.netReset();
      D.fillViews();
      var view = D.currentView();
      if (!view || view.isNull) { D.say(ccT("noImage"), 0, false, true); return; }
      D.busy = true;
      if (typeof cshBusyOn === "function") cshBusyOn(D.panelA, "analyse", { immediate: true });
      D.mark("analysis start");
      var locks = [D.analyseBtn, D.retryBtn, D.viewList, D.imgRefreshBtn];
      for (var lk = 0; lk < locks.length; ++lk) { try { locks[lk].enabled = false; } catch (eL) {} }
      D.syncRetry(); D.fitButtons(); D.panelStatus.update();
      D.videoSync(false);
      var res = null, photo = null;
      try {
         var info = ccViewInfo(view);
         D.S.info = info;
         if (!ccHasSolution(view)) {
            D.say(ccT("solving"), 0.02, true);
            CC_QUIET = true; D.enabled = false;
            var sv = null;
            try { sv = ccSolveView(view, true); } finally { CC_QUIET = false; D.enabled = true; }
            if (D.closing) return;
            if (!sv.ok) { D.say(sv.message, 0, false, true); return; }
            D.syncPills();
         }
         D.mark("solution ok");
         var field = ccFieldFromView(view);
         if (!field.ok) { D.say("No astrometric solution usable for this image.", 0, false, true); return; }
         // la foto: la de la vista previa si es esta imagen; si no, se hace y se ENSEÑA ya (antes que ningún catálogo)
         if (D.S.photo && D.S.photoViewId === view.id) photo = D.S.photo;
         else {
            D.say(ccT("photo"), 0.04, true);
            CC_QUIET = true;
            try { photo = ccPhotoBitmap(view, 2000); } finally { CC_QUIET = false; }
            if (D.closing) return;
            D.S.photo = photo; D.S.photoViewId = view.id; D.S.photoAt = Date.now(); D.S.gaiaPreview = null;
            D.S.frame = { width: field.width, height: field.height };
            if (D.S.viewId !== view.id) { D.S.res = null; D.S.list = []; D.S.sel = -1; D.S.zoom = { k: 1, cx: field.width / 2, cy: field.height / 2 }; }
            D.S.viewId = view.id;
            D.panelA.stale = true; D.invalidate();
            try { CoreApplication.processEvents(); } catch (ePE) {}
         }
         // (el aviso de B/N o sin SPCC lo dice ya la píldora de color de la barra: no se repite en la foto)
         D.S.photoNote = "";
         D.mark("photo done");
         var t0 = Date.now(), stepLabel = "";
         D.partials = 0;
         var tickBar = function(ms, inf) {
            // la barra FIJA dice qué falta: «Gaia DR3 + … · esperando a APOGEE, LAMOST (5/9)»
            if (!D.S.prog || !inf) return;
            var names = (inf.pending || []).map(function(k) {
               k = String(k); if (k.indexOf("boin") === 0) return "Boin+26"; if (k === "gaia") return "Gaia DR3"; if (k === "kord") return "Kordopatis+23";
               var c = CC_CAT[k]; return ccCatName(k, c && c.label ? c.label : k).split(" (")[0]; });
            var uniq = []; for (var u = 0; u < names.length; ++u) if (uniq.indexOf(names[u]) < 0) uniq.push(names[u]);
            // (en lote van varias a la vez: «el paso de ahora» sería solo la última lanzada; se dice cuántas han llegado)
            var head = inf.total ? ccT("fetchingN").replace("%d", inf.done).replace("%d", inf.total) : stepLabel;
            D.S.prog.text = head + (uniq.length ? " · " + ccT("waitingFor") + " " + uniq.slice(0, 4).join(", ") + (uniq.length > 4 ? "…" : "") : "");
            D.S.prog.frac = 0.05 + 0.95 * (inf.total ? inf.done / inf.total : 0);
            D.S.prog.right = (ms / 1000).toFixed(1) + " s" + (D.S.list && D.S.list.length ? " · " + ccThou(D.S.list.length, CC_LANG) + " " + ccT("starsSoFar") : "");
            D.progress.update();
         };
         res = ccRun(field, {
            batch: function(items) {
               return ccHttpBatch(items, { refresh: refresh, onTick: function(ms, inf) {
                  CoreApplication.processEvents();                  // (el aspa, Esc y el repintado de lo parcial)
                  if (CC_TRACE && D.trace.length < 200) D.mark("btick " + (inf && inf.pending ? inf.pending.join("+") : ""));
                  try { tickBar(ms, inf); } catch (eT) {}
               } });
            },
            onPartial: function(p) {
               D.mark("partial " + p.stars.length + " (" + ccVisibleList(p).length + " visibles)");
               D.showPartial(p);
               CoreApplication.processEvents();
            },
            gaiaLocal: function(f) {                                     // la base Gaia de este ordenador, ANTES que la red
               D.say(ccT("gaiaLocalAsk"), 0.03, true); CoreApplication.processEvents();
               D.mark("gaia local start"); var gl = ccGaiaLocalField(f); D.mark("gaia local end (" + (gl && gl.rows ? gl.rows.length : 0) + ")");
               return gl;
            },
            pulse: function() { CoreApplication.processEvents(); },        // (el aspa y Esc se atienden también aquí)
            http: function(adql, key) {
               return ccHttpTap(adql, key, { refresh: refresh, onTick: function(ms) {
                  // PRIMERO los eventos (el aspa, Esc): si lo de después lanzara, el aviso se tragaría la excepción y
                  // la ventana no atendería a nada hasta acabar la descarga
                  CoreApplication.processEvents();
                  if (CC_TRACE && D.trace.length < 200) D.mark("tick " + key);
                  try { if (D.S.prog) { D.S.prog.right = key + " · " + (ms / 1000).toFixed(1) + " s"; D.progress.update(); } } catch (eT) {}
               } });
            },
            onStep: function(i, n, key, label, inf) {
               stepLabel = ccCatName(key, label) + (inf && inf.chunk ? " (" + inf.chunk + "/" + inf.of + ")" : "") + "…";
               D.say(stepLabel, 0.05 + 0.95 * (i - 1) / n, true, false, ((Date.now() - t0) / 1000).toFixed(1) + " s");
               CoreApplication.processEvents();
            }
         });
         D.mark("engine done");
         try { D.S.netMirror = (typeof ccNetStatus === "function") ? ccNetStatus() : null; } catch (eNS) { D.S.netMirror = null; }
         if (D.closing) return;                       // cerrado a mitad: ni se pinta ni se guarda nada
         if (!res.ok) { D.say(res.why || res.code, 0, false, true); return; }
         var nFail = 0, nCache = 0;
         for (var i = 0; i < res.queries.length; ++i) { if (!res.queries[i].ok && res.queries[i].message !== "off") ++nFail; if (res.queries[i].cached) ++nCache; }
         var T0 = ccStatusText(res, CC_LANG), tRf = function() { return (res.timings.totalMs / 1000).toFixed(1) + " s" + (nCache ? " · " + nCache + " " + ccT("cached") : ""); };
         D.busy = false;                              // (para que loadResult diga su resultado y enseñe «Retry» si toca)
         if (typeof cshBusyOff === "function") cshBusyOff(D.panelA, "analyse");
         D.loadResult(res, photo, view.id);
         if (T0 && T0.title && (res.status.kind !== "ok")) D.sayR(function() { var T = ccStatusText(res, CC_LANG); return T.title + " — " + T.body; }, res.status.kind === "net" ? 0 : 1, false, T0.error, tRf);
         else D.sayR(function() { return ccT("ready") + (nFail ? " · " + nFail + " " + ccT("failedSee") : ""); }, 1, false, nFail > 0, tRf);
      } catch (e) {
         D.say("Error: " + String(e), 0, false, true);
      } finally {
         D.busy = false;
         if (typeof cshBusyOff === "function") cshBusyOff(D.panelA, "analyse");
         D.mark("analysis end");
         // a medias (error o cierre): lo parcial no se queda como si fuera el resultado; la foto sí
         if (D.S.res && D.S.res.partial) { D.S.res = null; D.S.list = []; D.S.sel = -1; try { D.invalidate(); } catch (eI) {} }
         for (var lk2 = 0; lk2 < locks.length; ++lk2) { try { locks[lk2].enabled = true; } catch (eL2) {} }
         D.syncRetry(); D.fitButtons(); D.panelStatus.update();
         if (!D.closing) D.videoSync(true);
         if (D.closing) { photo = null; res = null; D.release(); D.closeLater(); }
      }
   };
   D.exportCsv = function() {
      if (!D.S.res) return;
      var dir = ccSettingRead("exportDir", DataType_UCString, ccSlashes(File.homeDirectory) + "/Documents"), path = null;
      if (typeof CC_EXPORT_HOOK === "function") path = CC_EXPORT_HOOK("csv", CC_APP_NAME + "_" + (D.S.viewId || "field") + ".csv");
      else {
         var sfd = new SaveFileDialog;
         sfd.caption = ccT("exportCsv");
         sfd.initialPath = dir + "/" + CC_APP_NAME + "_" + (D.S.viewId || "field") + ".csv";
         sfd.filters = [["CSV", "*.csv"]];
         if (!sfd.execute()) return;
         path = sfd.fileName;
      }
      if (!path) return;
      path = ccSlashes(path);
      try {
         File.writeTextFile(path, ccCsv(D.S.res));
         ccSettingWrite("exportDir", DataType_UCString, path.substring(0, path.lastIndexOf("/")));
         D.say((CC_LANG === "es" ? "Tabla guardada: " : "Table saved: ") + path, 1, false, false, "");
      } catch (e) { D.say("CSV: " + String(e), 0, false, true); }
   };
   // EXPORTAR LA VISTA (lo que era «V. Exportar», ahora en la barra, como CabraStars): la foto, los tres diagramas, la ficha
   // y la línea de tiempo, pintados de nuevo a `k` veces la resolución de pantalla y colocados como en la ventana.
   D.exportBitmap = function(k) {
      var S = D.S, o = D.panelA.localToGlobal(new Point(0, 0)), s2 = ccScale(D) * k, items = [];
      function pos(c) { var p = c.localToGlobal(new Point(0, 0)); return { x: Math.round((p.x - o.x) * k), y: Math.round((p.y - o.y) * k), w: Math.round(c.width * k), h: Math.round(c.height * k) }; }
      items.push([D.panelA, function(g, w, h) { ccPaintPhoto(g, w, h, S, s2, "base"); ccPaintPhoto(g, w, h, S, s2, "over"); }]);
      items.push([D.titleCtl, function(g, w, h) { D.paintTitle(g, w, h, s2, true); }]);
      items.push([D.panelB, function(g, w, h) { ccPaintAlpha(g, w, h, S, s2, "base"); ccPaintAlpha(g, w, h, S, s2, "over"); }]);
      items.push([D.panelC, function(g, w, h) { ccPaintAgeMet(g, w, h, S, s2, "base"); ccPaintAgeMet(g, w, h, S, s2, "over"); }]);
      items.push([D.panelD, function(g, w, h) { ccPaintFamD(g, w, h, S, s2, "base"); ccPaintFamD(g, w, h, S, s2, "over"); }]);
      items.push([D.card, function(g, w, h) { D.exportCard(g, w, h, s2); }]);
      items.push([D.timeline, function(g, w, h) { ccPaintTimeline(g, w, h, S, s2); }]);
      // (23-oct, noche, revisión visual 4: en la exportada la cabecera lleva la frase ENTERA, en las líneas que pida: lo de debajo baja)
      var TLe = (S.res && S.res.field && !ccBroken("exportcut")) ? D.titleLines(Math.round(D.titleCtl.width * k), s2) : { extra: 0 };
      var W = 0, H = 0, P = [], tip = S.tip, i;
      // (el panel derecho sube hasta el título: sin los grupos ni la línea de estado, quedaba arriba una franja negra vacía)
      // (23-oct · R9) la mitad izquierda —la foto y, debajo, la línea de tiempo— va como en la ventana; lo que sube el panel derecho
      // (dyR) se reparte entre B, C, D (un tercio cada uno) y la ficha, que se pintan de nuevo a ese alto: sin franja vacía debajo
      var dyR = Math.max(0, pos(D.titleCtl).y), leftTl = !D.tlRight, inCol = [D.panelB, D.panelC, D.panelD], xT = TLe.extra || 0, ex = Math.max(0, dyR - xT) / 3;
      for (i = 0; i < items.length; ++i) {
         var c0 = items[i][0], q = pos(c0), k3 = inCol.indexOf(c0);
         if (c0 !== D.panelA && !(leftTl && c0 === D.timeline)) {
            q.y -= dyR;
            if (c0 === D.titleCtl) q.h += xT;
            else q.y += xT;
            if (k3 >= 0) { q.y += Math.round(k3 * ex); q.h += Math.round((k3 + 1) * ex) - Math.round(k3 * ex); }
            else if (c0 === D.card) q.h += Math.max(0, dyR - xT);
         }
         P.push(q); W = Math.max(W, q.x + q.w); H = Math.max(H, q.y + q.h);
      }
      if (D.tlRight) P[0].h = H;          // (el rojo de T19: como antes, la foto al alto de la columna)
      var out = new Bitmap(Math.max(8, W), Math.max(8, H)); out.fill(ccInt(A.bg));
      S.tip = null;
      var keepExp = CC_EXPORT_PAINT; CC_EXPORT_PAINT = true;
      D.exportGeom = P;          // (las pruebas: dónde quedó cada pieza en la exportada)
      try {
         var go = new Graphics(out);
         try {
            for (i = 0; i < items.length; ++i) {
               if (P[i].w < 8 || P[i].h < 8) continue;
               var b = new Bitmap(P[i].w, P[i].h); b.fill(ccInt(A.bg));
               var g = new Graphics(b);
               try { g.antialiasing = true; g.textAntialiasing = true; items[i][1](g, P[i].w, P[i].h); } finally { g.end(); }
               go.drawBitmap(P[i].x, P[i].y, b);
            }
         } finally { go.end(); }
      } finally { CC_EXPORT_PAINT = keepExp; S.tip = tip; D.invalidate(); }       // (las zonas de ayuda y la geometría vuelven a las de la pantalla)
      return out;
   };
   // (23-oct, noche, revisión visual 9: en la exportada quedaba vacío el tercio inferior de la columna de la ficha) La ficha exportada
   // REPARTE su alto: de lo más completo a lo menos —el detalle técnico Y «El campo, en llano»; solo el detalle; solo el campo—, la
   // primera que cabe entera (sin «↓ rueda»). Lo de la pantalla (plegado, desplazamiento) vuelve como estaba. ROJO «cardgap»: como antes.
   D.exportCard = function(g, w, h, s2) {
      var S = D.S, kd = S.cardDetail, ks = S.cardScroll, kb = S.cardBoth, choice = null;
      if (ccBroken("cardgap")) { ccPaintCard(g, w, h, S, s2); D.exportCardInfo = { variant: "pantalla", content: S.cardContentH, h: h }; return; }
      // (por orden de preferencia: [nombre, detalle, campo, escala de la letra]; la letra puede bajar hasta 0,82 —la exportada va al
      //  doble de resolución— para que el detalle técnico quepa entero; la primera que cabe y llena ≥ 85 % gana; si ninguna llena,
      //  la que cabe y más llena)
      var vars = [["detalle + campo", true, true, 1], ["detalle", true, false, 1], ["detalle + campo", true, true, 0.9], ["detalle", true, false, 0.9],
                  ["detalle", true, false, 0.82], ["campo", false, false, 1]], tries = [], best = null;
      try {
         S.cardScroll = 0;
         for (var v = 0; v < vars.length && !choice; ++v) {
            S.cardDetail = vars[v][1]; S.cardBoth = vars[v][2];
            var tb = new Bitmap(Math.max(8, w), Math.max(8, h)), tg = new Graphics(tb), ch = 0;
            try { ch = ccPaintCard(tg, w, h, S, s2 * vars[v][3]); } finally { tg.end(); }
            tries.push(vars[v][0] + " ×" + vars[v][3] + " " + Math.round(ch));
            if (ch <= h + 2) { if (ch >= 0.85 * h) choice = vars[v]; else if (!best || ch > best[1]) best = [vars[v], ch]; }
         }
         if (!choice) choice = best ? best[0] : vars[vars.length - 1];
         S.cardDetail = choice[1]; S.cardBoth = choice[2];
         var cH = ccPaintCard(g, w, h, S, s2 * choice[3]);
         D.exportCardInfo = { variant: choice[0] + (choice[3] !== 1 ? " (letra ×" + choice[3] + ")" : ""), content: cH, h: h, tries: tries };
      } finally { S.cardDetail = kd; S.cardScroll = ks; S.cardBoth = kb; }
   };
   D.exportTo = function(kind) {
      var out = { ok: false, where: "", why: "" };
      if (!D.S.res) { out.why = "nothing"; return out; }
      var base = CC_APP_NAME + "_" + String(D.S.viewId || "field").replace(/[^A-Za-z0-9]+/g, "_"), bmp = null;
      try {
         bmp = D.exportBitmap(ccBroken("exporthalf") ? 1 : 2);
         if (kind === "view") {
            var win = new ImageWindow(bmp.width, bmp.height, 3, 8, false, true, base);
            win.mainView.beginProcess(UndoFlag_NoSwapFile);
            try { win.mainView.image.blend(bmp); } finally { win.mainView.endProcess(); }
            if (typeof CC_NO_MAIN === "undefined" || !CC_NO_MAIN) win.show();
            out.ok = true; out.where = win.mainView.id; out.window = win;
         } else {
            var path = null;
            if (typeof CC_EXPORT_HOOK === "function") path = CC_EXPORT_HOOK("png", base + ".png");
            else {
               var sfd = new SaveFileDialog; sfd.caption = CC_APP_NAME + " — " + ccT("toFile");
               sfd.overwritePrompt = true; sfd.filters = [["PNG", "*.png"]];
               var dir = ccSettingRead("exportPngDir", DataType_UCString, ccSettingRead("exportDir", DataType_UCString, ""));
               sfd.initialPath = (dir ? dir + "/" : "") + base + ".png";
               path = sfd.execute() ? String(sfd.fileName) : null;
            }
            if (!path) { out.why = "cancelled"; return out; }
            path = ccSlashes(path);
            if (!/\.png$/i.test(path)) path += ".png";
            bmp.save(path);
            out.ok = File.exists(path); out.where = path; out.w = bmp.width; out.h = bmp.height;
            if (out.ok) ccSettingWrite("exportPngDir", DataType_UCString, path.substring(0, path.lastIndexOf("/")));
         }
      } catch (e) { out.why = String(e.message || e); }
      finally { try { if (bmp) bmp.clear(); } catch (e2) {} }
      if (out.ok) D.say(ccT("exported") + ": " + out.where, 1, false, false, "");
      else if (out.why !== "cancelled") D.say(ccT("exportFail") + ": " + out.why, 0, false, true, "");
      return out;
   };

   // al abrir: la lista de imágenes, con la activa elegida; los textos; los paneles a su ancho
   D.syncTexts();
   D.fillViews();
   D.fixHalves();
   // (22-oct, noche) al mostrarse: la foto de la imagen activa, ya (si no hay ya un resultado cargado: las pruebas cargan uno)
   D.onShow = function() { D.fillViews(); D.fixHalves(); D.fitGroups(); if (!D.S.res && !D.busy && !D.closing) D.schedulePreview(); };
   D.sayR(function() { return ccT("noImage"); }, 0, false, false);
}
var CC_EXPORT_HOOK = null;            // pruebas: (tipo, sugerido) -> ruta, en vez del cuadro de guardar

// El ratón en los paneles: elegir, pasar por encima (con la burbuja de ayuda de los «?»), zoom y
// arrastre en la foto, y el conmutador E–Lz | Toomre del panel D. La geometría de cada diagrama es
// la que se pintó (S.geomB/C/D): el ratón y el dibujo no pueden discrepar.
function ccWirePanels(D) {
   function nearestPhoto(x, y) {
      var S = D.S, X = ccPhotoXf(S, D.panelA.width, D.panelA.height), best = -1, bd = ccPx(14);
      if (!S.res) return -1;
      for (var i = 0; i < S.list.length; ++i) {
         var s = S.res.stars[S.list[i]], q = X.toScr(s.x, s.y), d = Math.sqrt((q.x - x) * (q.x - x) + (q.y - y) * (q.y - y));
         if (d < bd) { bd = d; best = S.list[i]; }
      }
      return best;
   }
   function nearestPlot(P, get, x, y) {
      var S = D.S, best = -1, bd = ccPx(12);
      if (!S.res || !P) return -1;
      for (var i = 0; i < S.list.length; ++i) {
         var v = get(S.res.stars[S.list[i]]);
         if (!v) continue;
         var X = P.X(ccClamp(v.x, Math.min(P.x0, P.x1), Math.max(P.x0, P.x1))), Y = P.Y(ccClamp(v.y, P.y0, P.y1));
         var d = Math.sqrt((X - x) * (X - x) + (Y - y) * (Y - y));
         if (d < bd) { bd = d; best = S.list[i]; }
      }
      return best;
   }
   var getB = function(s) { return ccBGet(s, D.S); };          // (IV · Elementos: [X/Fe] frente a [Fe/H]; con Fe, el par α de siempre)
   var getC = function(s) { return (s.age.adopted && s.chem.feh) ? { x: Math.min(s.age.adopted.v, CC_SCI.UNIVERSE_GA), y: s.chem.feh.v } : null; };
   var getD = function(s) { return D.S.dView === "toomre" ? ccToomreGet(s) : ccFamGet(s); };
   function hover(idx) { if (idx === D.S.hover) return; D.S.hover = idx; D.panelA.update(); D.panelB.update(); D.panelC.update(); D.panelD.update(); }
   function leave(ctrl, key) { if (CC_QUIET) return; hover(-1); if (D.S.tip && D.S.tip.panel === key) { D.S.tip = null; ctrl.update(); } }

   // A · la foto
   var A = D.panelA;
   A.drag = null;
   function hasFrame() { return !!(D.S.res || (D.S.frame && D.S.photo)); }   // (la vista previa: zoom y arrastre sin analizar)
   A.onMousePress = function(x, y, button) {
      if (CC_QUIET || !hasFrame()) return;
      var hA = ccHitAt(D.S, "A", x, y);
      if (hA && hA.action === "aview") { A.drag = null; D.setAView(hA.value); return; }
      // (31-oct) la linea de «Compare» se arrastra
      if (D.S.aCurtainX !== null && D.S.aCurtainX !== undefined && Math.abs(x - D.S.aCurtainX) <= CSH_CURTAIN.GRAB * ccScale(A)) { A.drag = { curtain: true, moved: true }; return; }
      A.drag = { x: x, y: y, cx: D.S.zoom.cx, cy: D.S.zoom.cy, moved: false };
   };
   A.onMouseMove = function(x, y, buttons) {
      if (CC_QUIET) return;
      if (A.drag && A.drag.curtain && buttons) { D.S.aSplit = cshCurtainClamp(x / Math.max(1, A.width)); A.stale = true; A.update(); return; }
      if (A.drag && buttons && hasFrame()) {
         var X = ccPhotoXf(D.S, A.width, A.height);
         if (Math.abs(x - A.drag.x) + Math.abs(y - A.drag.y) > 3) A.drag.moved = true;
         if (A.drag.moved) { D.S.zoom.cx = A.drag.cx - (x - A.drag.x) / X.s; D.S.zoom.cy = A.drag.cy - (y - A.drag.y) / X.s; A.stale = true; A.update(); }
         return;
      }
      // (30-oct) el resaltado dorado de la pildora «otra» al pasar el raton, como en los demas conmutadores (csh_pills.js): se repinta solo si cambia
      var hvA = ccHitAt(D.S, "A", x, y), kvA = (hvA && hvA.action === "aview") ? hvA.value : "";
      if (kvA !== (D.S.aHover || "")) { D.S.aHover = kvA; A.stale = true; A.update(); }
      if (ccTipMove(D, A, "A", x, y)) { hover(-1); return; }
      if (D.S.res) hover(nearestPhoto(x, y));
   };
   A.onMouseRelease = function(x, y) {
      if (CC_QUIET || !hasFrame()) return;
      var d = A.drag; A.drag = null;
      if (d && !d.moved) { var i = nearestPhoto(x, y); if (i >= 0) D.select(i); }
   };
   A.onMouseWheel = function(x, y, delta) {
      if (CC_QUIET || !hasFrame()) return;
      var X = ccPhotoXf(D.S, A.width, A.height), p = X.toImg(x, y), z = D.S.zoom;
      z.k = ccClamp(z.k * (delta > 0 ? 1.25 : 0.8), Math.min(1, X.kMin), 16);    // hasta ver el encuadre entero
      var q = ccPhotoXf(D.S, A.width, A.height).toImg(x, y);
      z.cx += p.x - q.x; z.cy += p.y - q.y;      // el punto bajo el cursor se queda quieto
      A.stale = true; A.update();
   };
   A.onMouseDoubleClick = function() {
      if (CC_QUIET || !hasFrame()) return;
      var F = ccPhotoField(D.S);
      D.S.zoom = { k: 1, cx: F.width / 2, cy: F.height / 2 };
      D.S.zoom.k = ccPhotoXf(D.S, A.width, A.height).kMin;      // doble clic = el encuadre ENTERO
      A.stale = true; A.update();
   };
   A.onLeave = function() { if (D.S.aHover) { D.S.aHover = ""; A.stale = true; A.update(); } leave(A, "A"); };
   // B, C y D · los diagramas
   function wire(ctrl, key, geom, get) {
      ctrl.onMouseMove = function(x, y) {
         if (CC_QUIET) return;
         if (ccTipMove(D, ctrl, key, x, y)) { hover(-1); return; }
         hover(nearestPlot(D.S[geom], get, x, y));
      };
      ctrl.onMousePress = function(x, y) {
         if (CC_QUIET) return;
         var hh = ccHitAt(D.S, key, x, y);
         if (hh && hh.action === "dview") { D.S.dView = hh.value; ccSettingWrite("dView", DataType_UCString, hh.value); D.S.tip = null; ctrl.stale = true; ctrl.update(); return; }
         var i = nearestPlot(D.S[geom], get, x, y);
         if (i >= 0) D.select(i);
      };
      ctrl.onLeave = function() { leave(ctrl, key); };
   }
   wire(D.panelB, "B", "geomB", getB);
   wire(D.panelC, "C", "geomC", getC);
   wire(D.panelD, "D", "geomD", getD);
}
