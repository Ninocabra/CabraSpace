#ifndef __CC_GALAXY_TIME_JS
#define __CC_GALAXY_TIME_JS
// ============================================================================
// src/ui/cc_galaxy_time.js — III · LA GALAXIA EN EL TIEMPO: el pasado de cada órbita, el reloj y sus placas
// (CabraComposition, 23-oct-2026). Puro salvo las dos funciones de placa (miden y pintan con ccFont).
// ----------------------------------------------------------------------------
// LO QUE HACE
//   · EL PASADO ENTERO de cada estrella con órbita: su estado de hoy (s.fam.nominal) integrado HACIA ATRÁS 13,8 Ga + 420 Ma
//     (lo que pide la estela más larga del vídeo) con el MISMO salto de rana de ccGxIntegrate (cc_galaxy.js) y la velocidad
//     invertida. El salto de rana es reversible: integrar hacia atrás y luego hacia delante devuelve el estado de hoy (lo mide
//     la sonda). LA ENERGÍA se mira a lo largo de todo el camino (cada 8 pasos): si max |ΔE/E| > DE_TOL, la estrella se repite
//     con el paso a la mitad (hasta 1/64 de 0,5 Ma). MEDIDO el 23-oct en node con los campos grabados: a 0,5 Ma, 10 de 131
//     estrellas de Abell 39 pasan de 1e-3 y una llega a 0,57 (una órbita que roza el núcleo, peri 0,13 kpc: el paso de 0,5 Ma
//     no la resuelve); en M 67, 1 de 828. Con el paso por estrella, todas por debajo de DE_TOL (la sonda da el máximo).
//     Se guarda un punto cada 2 Ma (como lo de hoy en adelante): `e.past` pasa de 60 Ma a todo el pasado.
//   · EL RELOJ (del vídeo y del mando de III, el MISMO): T (Ma atrás) no corre lineal. Lineal no se puede: a ~210 Ma por vuelta
//     del Sol, 13,8 Ga en 30 s son 15 Ma por fotograma (27° de giro por fotograma: estroboscopio) y en 60 s, 7,7 Ma (13,5°:
//     una vuelta entera en medio segundo, un borrón). «Órbitas» (aceptado) iba a 1 Ma por fotograma (420 Ma en 14 s).
//     DECISIÓN: el pasado lejano corre como «La historia del campo» (R_MAX = 575 Ma/s: 13,8 Ga en 24 s; los episodios duran lo
//     mismo en los dos vídeos) y al acercarse a hoy el reloj FRENA de forma suave hasta R_END = 35 Ma/s (1,2 Ma por fotograma,
//     2° de giro del Sol), velocidad que mantiene la última vuelta del Sol (TAIL_MYR = 210 Ma):
//        segundos que faltan hasta hoy  σ(T) = T / R_END                                         si T ≤ TAIL
//                                        σ(T) = TAIL/R_END + a (T − TAIL) + b ln(1 + (T − TAIL)/KNEE)  si no,
//        con a = 1/R_MAX y b = KNEE (1/R_END − a): el ritmo dT/ds es continuo en TAIL y tiende a R_MAX en el pasado lejano.
//     Con estas cifras: 40,7 s de recorrido (13,8 → 1 Ga en 31,8 s; el último Ga en 8,9 s; los últimos 210 Ma en 6 s).
//   · LAS ESTELAS que enseñan la órbita sin girar cada vuelta: su largo sigue al ritmo del reloj (40 Ma a R_END, como
//     «Órbitas»; 420 Ma —dos vueltas, el dibujo de «Órbitas» de III— a ≥ RATE_FAST) y, deprisa, sin fundido y con el punto
//     tenue: lo que se ve es el anillo que recorre cada estrella, no un punto saltando 30° por fotograma.
//   · LAS SIN EDAD no se pintan en el pasado (como en «La historia del campo»: no se sabe cuándo nacieron); con el mando en «hoy»
//     sí (el mapa de siempre). Su número va en la placa. EL SOL se enciende a los 4,57 Ga (CC_TIMELINE, «nace el Sol»).
// HONESTIDAD: el pasado se calcula con la Galaxia de HOY (potencial estático MilkyWayPotential2022): sin migración radial, sin
// calentamiento del disco, sin fusiones; con la barra de HOY girando hacia atrás (2-nov-2026, Q2b). Es ILUSTRATIVO: dónde estaría cada estrella en su órbita de hoy. Lo dicen
// la placa del vídeo y el «?» de III.
// ES5 puro.
// ============================================================================

var CC_GXT = {
   PAST_EXTRA_MYR: 420,      // lo integrado de más hacia atrás: la estela más larga (TRAIL_MAX) en T = 13,8 Ga
   DE_TOL: 1e-3,             // diseño: tope de max |ΔE/E| en el pasado de una estrella (el de hoy en adelante, a 0,5 Ma, llega a ~3e-4 en el disco)
   DE_EVERY: 8,              // cada cuántos pasos se mira la energía
   MAX_HALVE: 6,             // el paso, como mucho, 0,5 / 2^6 Ma
   // el reloj (ver la cabecera)
   R_MAX: 575, R_END: 35, TAIL_MYR: 210, KNEE_MYR: 80,
   INTRO_S: 2.5, HOLD_S: 3.5, NOAGE_FADE_S: 1.0, FLASH_S: 1.0,
   // las estelas
   TRAIL_MIN: 40, TRAIL_MAX: 420, RATE_SLOW: 40, RATE_FAST: 240, DOT_FAST: 0.4, SEG_SLOW: 6, SEG_FAST: 12,
   TURN_DEG: 120,            // la cámara 3D gira 120° en todo el vídeo («Órbitas»: 100° en 14 s)
   STEPS: 1000               // el mando de III: pasos de la regla
};
function ccGxtU() { return 1000 * ((typeof CC_SCI !== "undefined" && CC_SCI.UNIVERSE_GA > 0) ? CC_SCI.UNIVERSE_GA : 13.8); }
function ccGxtBroken(k) { return (typeof CC_GX_BREAK === "string" && CC_GX_BREAK.indexOf(k) >= 0) || (typeof CC_BREAK === "string" && CC_BREAK.indexOf(k) >= 0); }

// ---------------------------------------------------------------------------
// EL RELOJ
// ---------------------------------------------------------------------------
function ccGxtA() { return 1 / CC_GXT.R_MAX; }
function ccGxtB() { return CC_GXT.KNEE_MYR * (1 / CC_GXT.R_END - ccGxtA()); }
// σ(T): segundos de vídeo que faltan desde «T Ma atrás» hasta hoy. (ROJO «gxtlinear»: lineal, 13,8 Ga al ritmo del final)
function ccGxtSigma(T) {
   var C = CC_GXT;
   T = Math.max(0, T);
   if (ccGxtBroken("gxtlinear")) return T * ccGxtRunS0() / ccGxtU();
   if (T <= C.TAIL_MYR) return T / C.R_END;
   return C.TAIL_MYR / C.R_END + ccGxtA() * (T - C.TAIL_MYR) + ccGxtB() * Math.log(1 + (T - C.TAIL_MYR) / C.KNEE_MYR);
}
function ccGxtRunS0() { var C = CC_GXT, U = ccGxtU(); return C.TAIL_MYR / C.R_END + ccGxtA() * (U - C.TAIL_MYR) + ccGxtB() * Math.log(1 + (U - C.TAIL_MYR) / C.KNEE_MYR); }
function ccGxtRunS() { return ccGxtSigma(ccGxtU()); }
function ccGxtDuration() { return CC_GXT.INTRO_S + ccGxtRunS() + CC_GXT.HOLD_S; }
// lo contrario: los segundos que faltan → T (Ma atrás). Monótona: bisección.
function ccGxtTofSigma(rem) {
   var C = CC_GXT, U = ccGxtU();
   if (!(rem > 0)) return 0;
   if (rem >= ccGxtRunS()) return U;
   if (!ccGxtBroken("gxtlinear") && rem <= C.TAIL_MYR / C.R_END) return rem * C.R_END;
   var lo = 0, hi = U;
   for (var i = 0; i < 60; ++i) { var mid = 0.5 * (lo + hi); if (ccGxtSigma(mid) < rem) lo = mid; else hi = mid; }
   return 0.5 * (lo + hi);
}
// el ritmo dT/ds (Ma por segundo de vídeo) a T
function ccGxtRate(T) {
   var C = CC_GXT;
   if (ccGxtBroken("gxtlinear")) return ccGxtU() / ccGxtRunS0();
   if (T <= C.TAIL_MYR) return C.R_END;
   return 1 / (ccGxtA() + ccGxtB() / (C.KNEE_MYR + T - C.TAIL_MYR));
}
// t (s de vídeo) → { T (Ma atrás), phase "intro" | "run" | "hold", rate, s (s del recorrido), titleAlpha, hold (s dentro del final) }
function ccGxtClock(t) {
   var C = CC_GXT, S = ccGxtRunS(), U = ccGxtU(), out = { T: U, phase: "intro", rate: ccGxtRate(U), s: 0, titleAlpha: 1, hold: 0 };
   if (!(t >= C.INTRO_S)) { out.titleAlpha = Math.max(0, Math.min(1, (C.INTRO_S - Math.max(0, t || 0)) / 0.6)); return out; }
   var s = t - C.INTRO_S;
   if (s >= S) { out.T = 0; out.phase = "hold"; out.rate = 0; out.s = S; out.titleAlpha = 0; out.hold = s - S; return out; }
   out.phase = "run"; out.s = s; out.titleAlpha = 0; out.T = ccGxtTofSigma(S - s); out.rate = ccGxtRate(out.T);
   return out;
}
// las pruebas: el segundo de vídeo en el que el reloj marca T
function ccGxtTimeAt(T) { return CC_GXT.INTRO_S + ccGxtRunS() - ccGxtSigma(T); }
// EL MANDO DE III: la posición de la regla (0 = el Big Bang, a la izquierda; 1 = hoy) ↔ T, con el MISMO reloj que el vídeo
function ccGxtFracToT(v) { v = Math.max(0, Math.min(1, v)); return (v >= 1) ? 0 : ccGxtTofSigma(ccGxtRunS() * (1 - v)); }
function ccGxtTToFrac(T) { return 1 - ccGxtSigma(Math.max(0, Math.min(ccGxtU(), T))) / ccGxtRunS(); }
// la estela y el punto según el ritmo: { trail (Ma), flat (0 = fundido entero … 1 = sin fundido), dot (alfa del punto), seg (px lógicos) }
function ccGxtLook(rate) {
   var C = CC_GXT, phi = (rate > C.RATE_SLOW) ? Math.min(1, Math.log(rate / C.RATE_SLOW) / Math.log(C.RATE_FAST / C.RATE_SLOW)) : 0;
   if (ccGxtBroken("gxtnotrail")) phi = 0;      // (ROJO: la estela corta de «Órbitas» también deprisa: el punto salta)
   return { trail: C.TRAIL_MIN * Math.pow(C.TRAIL_MAX / C.TRAIL_MIN, phi), flat: phi, dot: 1 - (1 - C.DOT_FAST) * phi, seg: C.SEG_SLOW + (C.SEG_FAST - C.SEG_SLOW) * phi, phi: phi };
}
// T (Ma) → «hace 4,6 Ga» / «hace 0,35 Ga» / «hoy» (lang "es" | "en"). R3 (26-oct): sin «Ma»; es el ADAPTADOR de unidades (T en Ma) de ccAgeAgoText
// (cc_science.js), la ÚNICA función que da la edad de un instante (el umbral de «hoy», uno solo: CC_JOURNEY.TODAY_MA, H7 del 24-oct).
function ccGxtAgoText(T, lang) { return ccAgeAgoText(T / 1000, lang, "run"); }
function ccGxNumInt(n) { var lang = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en"; return (typeof ccThou === "function") ? ccThou(n, lang) : String(Math.round(n)); }

// ---------------------------------------------------------------------------
// EL ENCENDIDO (la regla de «La historia del campo»: ccJourneyBirth de cc_journey.js, con la edad adoptada y su intervalo)
// ---------------------------------------------------------------------------
// f ∈ [0, 1] de la estrella `e` del modelo a «Tga Ga atrás». Sin edad: −1 (no se sabe).
function ccGxtBirth(e, Tga) {
   if (!e || !e.ageA) return -1;
   if (!(Tga > 0)) return 1;
   if (ccGxtBroken("gxtnobirth")) return 1;      // (ROJO: todas encendidas a cualquier T)
   if (typeof ccJourneyBirth === "function") return ccJourneyBirth(e.ageA, Tga);
   var v = Math.min(e.ageA.v, ccGxtU() / 1000);
   return (Tga <= v) ? 1 : 0;
}
// el anillo del nacimiento en el vídeo: 0..1 durante FLASH_S segundos de vídeo desde que el reloj cruza su edad; −1 fuera
function ccGxtFlash(e, Tmyr) {
   if (!e || !e.ageA || !(Tmyr > 0)) return -1;
   var v = 1000 * Math.min(e.ageA.v, ccGxtU() / 1000);
   if (Tmyr > v) return -1;
   var p = (ccGxtSigma(v) - ccGxtSigma(Tmyr)) / CC_GXT.FLASH_S;
   return (p >= 0 && p < 1) ? p : -1;
}
// la edad del Sol (Ga), de CC_TIMELINE
function ccGxtSunAge() {
   var TL = (typeof CC_TIMELINE !== "undefined") ? CC_TIMELINE : [];
   for (var i = 0; i < TL.length; ++i) if (TL[i].key === "sun") return TL[i].from;
   return 4.57;
}

// ---------------------------------------------------------------------------
// EL PASADO ENTERO (una vez por modelo; se guarda en G)
// ---------------------------------------------------------------------------
// Una estrella: { tr (los puntos, cada 2 Ma, hacia atrás), dt (el paso usado), dE (max |ΔE/E|), halvings }
function ccGxtBack(st, tMyr) {
   var C = CC_GXT, rev = { x: st.x, y: st.y, z: st.z, vx: -st.vx, vy: -st.vy, vz: -st.vz, E: st.E }, best = null;
   for (var h = 0; h <= C.MAX_HALVE; ++h) {
      var k = Math.pow(2, h), dt = CC_GX.DT_MYR / k;
      var tr = ccGxIntegrate(rev, tMyr, dt, CC_GX.EVERY * k, true, C.DE_EVERY, -1, true);      // (2-nov: la barra gira hacia atrás; E3: `fixed`, el paso lo afina este bucle)
      if (!tr.bound) return { tr: null, dt: dt, dE: 0, halvings: h };
      best = { tr: tr, dt: dt, dE: tr.dEmax, halvings: h };
      if (tr.dEmax <= C.DE_TOL || ccGxtBroken("gxtfixdt")) break;      // (ROJO «gxtfixdt»: sin afinar el paso)
   }
   return best;
}
// G (ccGalaxyModel) → G.deep = { ms, n, maxDE, worst (nombre), refined (cuántas con el paso afinado), tMyr }. Idempotente.
function ccGalaxyDeepPast(G, onProgress) {
   if (!G) return null;
   if (G.deep) return G.deep;
   var t0 = Date.now(), T = ccGxtU() + CC_GXT.PAST_EXTRA_MYR, out = { ms: 0, n: 0, maxDE: 0, worst: "", refined: 0, tMyr: T, dtMin: CC_GX.DT_MYR };
   for (var i = 0; i < G.stars.length; ++i) {
      var e = G.stars[i];
      if (!e.tr || !e.st0) continue;
      var b = ccGxtBack(e.st0, T);
      if (!b || !b.tr) continue;
      e.past = b.tr; e.pastDE = b.dE; e.pastDt = b.dt;
      ++out.n;
      if (b.halvings > 0) ++out.refined;
      if (b.dt < out.dtMin) out.dtMin = b.dt;
      if (b.dE > out.maxDE) { out.maxDE = b.dE; out.worst = e.name; }
      if (onProgress && (i % 20 === 0)) { try { onProgress(i, G.stars.length); } catch (eP) {} }
   }
   // el Sol (se enciende a los 4,57 Ga, pero su pasado se calcula igual: así su órbita está también antes)
   if (G.sun && G.sun.st) { var bs = ccGxtBack(G.sun.st, T); if (bs && bs.tr) { G.sun.past = bs.tr; G.sun.pastDE = bs.dE; } }
   out.ms = Date.now() - t0;
   G.deep = out;
   return out;
}
// la posición de `e` a tMyr (negativo = el pasado), por la curva suave de los puntos de 2 Ma (ccGxAtSmooth de cc_galaxy.js)
function ccGxtPos(e, tMyr, out) { return ccGxAtSmooth(e.tr, e.past, tMyr, out || [0, 0, 0]); }
// el primer instante (Ma, ≤ 0) que el pasado guardado cubre
function ccGxtPastStart(e) { return (e.past && e.past.n > 1) ? -(e.past.n - 1) * e.past.dtMyr : 0; }

// UN TRAMO DE ÓRBITA de tA a tB (Ma; pueden ser negativos), por los puntos de 2 Ma, con los tramos de más de 10 px subdivididos por
// la curva suave (como ccGxTrajPolyline). `O` (rejilla): los puntos ocupan su celda como «blando».
function ccGxtPath(g, P, e, tA, tB, step, pen, O, sc) {
   var tr = e.tr, past = e.past;
   if (!tr || !tr.n) return 0;
   var dt = tr.dtMyr, kmin = (past && past.n > 1) ? -(past.n - 1) : 0, k0 = Math.max(kmin, Math.ceil(tA / dt)), k1 = Math.min(tr.n - 1, Math.floor(tB / dt));
   var q = [0, 0, 0], qs = [0, 0, 0], run = [], prev = null, prevK = 0, segMax = 10 * (sc || 1), npts = 0, st = Math.max(1, step || 1);
   g.pen = pen; ccGxNoBrush(g);
   for (var k = k0; k <= k1; k += st) {
      ccGxGridPt(tr, past, k, q);
      var p = P.pt(q[0], q[1], q[2]);
      if (!p.ok) { if (run.length > 1) g.drawPolyline(run); run = []; prev = null; continue; }
      if (prev) {
         var dL = Math.sqrt((p.x - prev.x) * (p.x - prev.x) + (p.y - prev.y) * (p.y - prev.y));
         if (dL > segMax) {
            var mS = Math.min(12, Math.ceil(dL / segMax));
            for (var j = 1; j < mS; ++j) { ccGxAtSmooth(tr, past, (prevK + (k - prevK) * j / mS) * dt, qs); var qq = P.pt(qs[0], qs[1], qs[2]); if (qq.ok) run.push(new Point(qq.x, qq.y)); }
         }
      }
      prev = p; prevK = k;
      run.push(new Point(p.x, p.y)); ++npts;
      if (O) { var ci = Math.floor(p.x / O.cell), cj = Math.floor(p.y / O.cell); if (ci >= 0 && cj >= 0 && ci < O.nx && cj < O.ny && O.a[cj * O.nx + ci] < 1) O.a[cj * O.nx + ci] = 1; }
      if (k + st > k1 && k !== k1) k = k1 - st;
   }
   if (run.length > 1) g.drawPolyline(run);
   return npts;
}

// ---------------------------------------------------------------------------
// LAS PLACAS (miden y pintan: opacas, con su filete, como las de II)
// ---------------------------------------------------------------------------
// items = [{ text, font: [role, px, bold, italic, tracking], color, caps, wrap (líneas máx.), gap }], k = escala de la letra.
// maxW = ancho máximo del texto (px). Devuelve { W, H, rows } (sin pintar).
function ccGxtPlateMeasure(items, k, maxW) {
   var rows = [], W = 0, H = 0, padX = Math.round(12 * k), padY = Math.round(8 * k);
   for (var i = 0; i < items.length; ++i) {
      var it = items[i];
      if (!it || !it.text) continue;
      var F = it.font, px = F[1] * k, text = it.caps ? String(it.text).toUpperCase() : String(it.text), wrap = it.wrap || 1, font = null, lines = [text];
      for (var shrink = 0; shrink < 6; ++shrink) {
         font = ccFont(F[0], px, F[2], F[3], F[4] ? Math.round(px * F[4]) : 0);
         lines = (wrap > 1 && typeof ccWrap === "function") ? ccWrap(font, text, maxW) : [text];
         var widest = 0; for (var j = 0; j < lines.length; ++j) widest = Math.max(widest, font.width(lines[j]));
         if (lines.length <= wrap && widest <= maxW) break;
         px *= 0.94;
      }
      var wd = 0; for (j = 0; j < lines.length; ++j) wd = Math.max(wd, font.width(lines[j]));
      rows.push({ font: font, color: it.color, lines: lines, gap: Math.round((it.gap !== undefined ? it.gap : 3) * k) });
      W = Math.max(W, wd);
      H += lines.length * (font.ascent + font.descent) + ((i + 1 < items.length) ? Math.round((it.gap !== undefined ? it.gap : 3) * k) : 0);
   }
   return { W: W + 2 * padX, H: H + 2 * padY, rows: rows, padX: padX, padY: padY };
}
function ccGxtPlatePaint(g, R, M, x0, y0, alpha) {
   if (!M || !M.rows.length || !(alpha > 0.004)) return null;
   var A = CC_ATLAS;
   g.antialiasing = true;
   // (la placa opaca; en el fundido el fondo se hace opaco 3× más deprisa que el texto: lo de II, revisor R6)
   g.opacity = Math.min(1, 3 * alpha);
   g.fillRoundedRect(x0, y0, x0 + M.W, y0 + M.H, 6, 14, new Brush(ccInt(A.bg, 1)));
   ccGxNoBrush(g); g.pen = new Pen(ccInt(A.line), 1); g.drawRoundedRect(x0, y0, x0 + M.W, y0 + M.H, 6, 14);
   g.opacity = alpha;
   var y = y0 + M.padY;
   for (var i = 0; i < M.rows.length; ++i) {
      var r = M.rows[i];
      for (var j = 0; j < r.lines.length; ++j) { y += r.font.ascent; ccGxText(g, R, r.font, r.color, x0 + M.padX, y, r.lines[j]); y += r.font.descent; }
      y += r.gap;
   }
   g.opacity = 1;
   return { x0: x0, y0: y0, x1: x0 + M.W, y1: y0 + M.H };
}
#endif
