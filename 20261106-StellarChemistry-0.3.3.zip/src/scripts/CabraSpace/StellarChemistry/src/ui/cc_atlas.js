// ============================================================================
// src/ui/cc_atlas.js — los tokens de la estética «Atlas» para CabraComposition
// ----------------------------------------------------------------------------
// COPIA DERIVADA de `CabraBase/estilo/tokens.json` (v1.0.0, paleta «carbón
// cálido»), a través de CabraPilot `CabraCore/src/ui/atlas.js` (rama
// integracion-1410c): mismos valores, prefijo propio (CC_) para no chocar con
// nada. Lo que se aprendió allí midiendo y se respeta aquí:
//   · lo pintado a mano va en píxeles FÍSICOS (ccPx);
//   · Font.letterSpacing va en px por letra; `isExactMatch` dice si la familia está;
//   · el radio de una píldora en una hoja Qt no puede pasar de media altura.
// Los colores de DATOS (la escala de metalicidad, las poblaciones) se DERIVAN
// de la paleta (ccMix), no se inventan hex nuevos.
// ES5 puro.
// ============================================================================

var CC_ATLAS = CSH_ATLAS;            // (los tokens, comunes: ../CabraShared/csh_atlas.js)

function ccHexRgb(hex) {
   var h = String(hex).replace("#", "");
   return [parseInt(h.substring(0, 2), 16), parseInt(h.substring(2, 4), 16), parseInt(h.substring(4, 6), 16)];
}
function ccHex2(n) { var s = Math.max(0, Math.min(255, Math.round(n))).toString(16); return (s.length < 2) ? "0" + s : s; }
function ccMix(a, b, t) {
   var A = ccHexRgb(a), B = ccHexRgb(b);
   return "#" + ccHex2(A[0] + (B[0] - A[0]) * t) + ccHex2(A[1] + (B[1] - A[1]) * t) + ccHex2(A[2] + (B[2] - A[2]) * t);
}
// Entero 0xAARRGGBB para Graphics.
function ccInt(hex, alpha) {
   var c = ccHexRgb(hex), a = (alpha === undefined) ? 255 : Math.max(0, Math.min(255, Math.round(alpha * 255)));
   return ((a << 24) | (c[0] << 16) | (c[1] << 8) | c[2]) >>> 0;
}
function ccRgbInt(rgb, alpha) {
   var a = (alpha === undefined) ? 255 : Math.max(0, Math.min(255, Math.round(alpha * 255)));
   return ((a << 24) | (Math.round(rgb[0]) << 16) | (Math.round(rgb[1]) << 8) | Math.round(rgb[2])) >>> 0;
}
// Para una hoja Qt: "#AARRGGBB".
function ccQss(hex, alpha) { return "#" + ccHex2((alpha === undefined ? 1 : alpha) * 255) + String(hex).replace("#", ""); }

// Tonos derivados (ninguno es un token nuevo).
var CC_INSET = ccMix(CC_ATLAS.bg, "#000000", 0.35);
var CC_LINE_STRONG = ccMix(CC_ATLAS.line, CC_ATLAS.text3, 0.35);

// LA ESCALA DE METALICIDAD: fría (pobre en metales) -> crema (solar) -> oro (rica).
// Paradas en [Fe/H]; todas salen de la paleta (chart violeta y azul, texto, oro claro, oro).
// (14-oct, revisor visual: con la versión anterior el tramo −0,5…+0,1, donde está casi todo el
//  disco, salía casi blanco entero. Ahora el azul baja hasta −0,25 y el oro empieza en +0,05.)
var CC_FEH_STOPS = [
   [-2.5, CC_ATLAS.chart[4]], [-1.3, CC_ATLAS.chart[1]], [-0.6, ccMix(CC_ATLAS.chart[1], CC_ATLAS.text, 0.30)],
   [-0.25, ccMix(CC_ATLAS.chart[1], CC_ATLAS.text, 0.65)], [0.0, CC_ATLAS.text], [0.12, CC_ATLAS.goldLight], [0.3, CC_ATLAS.gold],
   [0.5, ccMix(CC_ATLAS.gold, CC_ATLAS.bg, 0.3)]
];
// (La unidad de las edades en cada idioma —«Gyr» en inglés en todas partes— es ccAgeUnit(lang) de cc_story.js; antes, ccGa() aquí.)

// Los GLIFOS de los controles nativos (flecha del desplegable, casilla), dibujados aquí y
// guardados como PNG: una hoja Qt solo los acepta como `image:url()`. Igual que CabraPilot
// (`cpAtlasRawCss`, ui/atlas.js). Y `background-image:none` en todo: sin él, el estilo nativo
// de PixInsight deja una TEXTURA sobre los botones (la trama de puntos de la primera entrega).
// (3-nov-2026, CPD SC6, regla 6.1) DÓNDE: en la carpeta TEMPORAL del sistema, <temp>/StellarChemistryAtlas/ (arrow_N.png, check_off_N.png,
// check_on_N.png; N = lado en píxeles). Se reescriben en cada sesión y se pueden borrar. Antes iban a ~/.cabracomposition/glyphs, una carpeta
// en el home del usuario que no estaba documentada; ahora es como el «?» de la ayuda (CabraHelpAtlas) y FieldDepth3D (CabraPilotAtlas), y la
// ayuda lo dice («Network, external programs and files»). La carpeta vieja no se toca (es del usuario).
var CC_GLYPH_DIR_NAME = "StellarChemistryAtlas";
function ccGlyphDir() { return ccSlashes(File.systemTempDirectory).replace(/\/+$/, "") + "/" + CC_GLYPH_DIR_NAME; }
var CC_GLYPH_CSS = null;
function ccGlyphCss(sc) {
   if (CC_GLYPH_CSS !== null) return CC_GLYPH_CSS;
   var css = "";
   try {
      var dir = ccGlyphDir();
      ccMkdirs(dir);
      var arr = Math.round(9 * sc), box = Math.round(13 * sc);
      function save(name, w, h, draw) {
         var b = new Bitmap(w, h); b.fill(0x00000000);
         var g = new Graphics(b);
         try { g.antialiasing = true; draw(g, w, h); } finally { g.end(); }
         var p = dir + "/" + name + "_" + w + ".png"; b.save(p); return p;
      }
      var arrow = save("arrow", arr, arr, function(g, w, h) {
         g.pen = new Pen(ccInt(CC_ATLAS.gold), Math.max(1.5, 0.16 * w));
         g.drawLine(w * 0.15, h * 0.35, w * 0.5, h * 0.7); g.drawLine(w * 0.5, h * 0.7, w * 0.85, h * 0.35);
      });
      function check(on) {
         return function(g, w, h) {
            g.fillRoundedRect(1, 1, w - 1, h - 1, 30, 30, new Brush(ccInt(on ? CC_ATLAS.gold : CC_INSET)));
            g.pen = new Pen(ccInt(on ? CC_ATLAS.gold : CC_LINE_STRONG), 1); g.drawRoundedRect(1, 1, w - 1, h - 1, 30, 30);
            if (on) { g.pen = new Pen(ccInt(CC_ATLAS.ink), Math.max(1.5, 0.14 * w)); g.drawLine(w * 0.25, h * 0.52, w * 0.43, h * 0.7); g.drawLine(w * 0.43, h * 0.7, w * 0.76, h * 0.3); }
         };
      }
      var off = save("check_off", box, box, check(false)), on = save("check_on", box, box, check(true));
      var u = function(p) { return "image:url(\"" + p + "\");"; };
      css = "QComboBox::drop-down { background-color:transparent; border:none; width:" + Math.round(18 * sc) + "px; }" +
            "QComboBox::down-arrow { width:" + arr + "px; height:" + arr + "px; " + u(arrow) + " }" +
            "QCheckBox::indicator { width:" + box + "px; height:" + box + "px; border:none; background:transparent; " + u(off) + " }" +
            "QCheckBox::indicator:checked { " + u(on) + " }";
   } catch (e) { css = ""; }
   CC_GLYPH_CSS = css;
   return css;
}
function ccFehRgb(feh) {
   var S = CC_FEH_STOPS;
   if (!(typeof feh === "number" && isFinite(feh))) return ccHexRgb(CC_ATLAS.text3);
   if (feh <= S[0][0]) return ccHexRgb(S[0][1]);
   for (var i = 1; i < S.length; ++i) if (feh <= S[i][0]) {
      var t = (feh - S[i - 1][0]) / (S[i][0] - S[i - 1][0]), a = ccHexRgb(S[i - 1][1]), b = ccHexRgb(S[i][1]);
      return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
   }
   return ccHexRgb(S[S.length - 1][1]);
}
// Colores de POBLACIÓN (para leyendas y la línea de tiempo): derivados de chart.
// (23-oct, revisor R11: «disco» —sin separar fino/grueso— salía del gris de «desconocida», casi igual que el crema del disco fino:
//  ahora el verde de la paleta, el único que no usa otra población)
var CC_POP_COLOR = {
   thin: CC_ATLAS.chart[5], thick: CC_ATLAS.gold, halo: CC_ATLAS.chart[1], accreted: CC_ATLAS.chart[4],
   disc: CC_ATLAS.chart[3], unknown: CC_ATLAS.text3
};
// LOS NOMBRES DE LEYENDA de cada población, UNO para la leyenda de A, la del mapa de III y la del vídeo «Órbitas» (revisor R11: «acretada»
// en A y «halo acretado (tipo Gaia-Enceladus)» en el mapa). El de la ficha y el relato sigue siendo CC_POP_NAME (cc_science.js).
var CC_POP_LEG = {
   en: { thin: "thin disc", thick: "thick disc", halo: "halo", accreted: "accreted halo", disc: "disc (thin / thick not separated)", unknown: "unknown population" },
   es: { thin: "disco fino", thick: "disco grueso", halo: "halo", accreted: "halo acretado", disc: "disco (sin separar fino / grueso)", unknown: "población desconocida" }
};
// LA FIRMA de los tres vídeos (23-oct, revisor R18: «CABRACOMPOSITION» en dos y «CABRASPACE» en el tercero): el mismo texto y la misma
// letra, proporcional al alto del fotograma (15 px a 1080p)
var CC_VIDEO_SIGN = "STELLAR CHEMISTRY · CABRASPACE";      // (30-oct-2026: antes «CABRACOMPOSITION · CABRASPACE»)
// (30-oct-2026, decision de Nino del 28-oct: docs/nombres-y-repositorio-pixinsight.md §3) EL NOMBRE QUE SE VE: StellarChemistry (menu Script >
// CabraSpace). De una pieza en el titulo y los ficheros; en versalitas espaciadas en la cabecera. Es marca: no se traduce. La clave de Settings
// (CC_SETTINGS = "CabraComposition"), las carpetas, los .js y los identificadores (ccXxx) NO cambian.
var CC_APP_NAME = "StellarChemistry", CC_APP_CAPS = "STELLAR CHEMISTRY";
function ccVideoSignFont(h) { var px = Math.max(7, 15 * h / 1080); return ccFont("text", px, false, false, Math.round(px * CC_ATLAS.labelTracking)); }
function ccPopLeg(key, lang) { var L = CC_POP_LEG[(lang === "es") ? "es" : "en"]; return L[key] || L.unknown; }

// ---------------------------------------------------------------------------
// Tipografía y escala
// ---------------------------------------------------------------------------
var CC_FONT_FAMILY = {};
function ccFontFamily(role) {
   if (CC_FONT_FAMILY[role]) return CC_FONT_FAMILY[role];
   var list = CC_ATLAS.fonts[role] || CC_ATLAS.fonts.text, chosen = list[list.length - 1];
   for (var i = 0; i < list.length; ++i) {
      var ok = false;
      try { ok = (new Font(list[i])).isExactMatch === true; } catch (e) {}
      if (ok) { chosen = list[i]; break; }
   }
   CC_FONT_FAMILY[role] = chosen;
   return chosen;
}
var CC_FONT_CACHE = {};
function ccFont(role, px, bold, italic, spacing) {
   var size = Math.max(6, Math.round(px)), sp = Math.round(spacing || 0);
   var key = role + "|" + size + "|" + (bold ? 1 : 0) + (italic ? 1 : 0) + "|" + sp;
   if (CC_FONT_CACHE[key]) return CC_FONT_CACHE[key];
   var f = new Font(ccFontFamily(role));
   f.pixelSize = size;
   if (bold) f.bold = true;
   if (italic) f.italic = true;
   if (sp !== 0) { try { f.letterSpacing = sp; } catch (e) {} }
   CC_FONT_CACHE[key] = f;
   return f;
}
// La escala de la interfaz: la de PixInsight, pero no menos de 1,5 (como el «Auto»
// de CabraPilot: maquetado a 1,5, a escalas menores la letra pintada se queda chica).
var CC_UI_SCALE = 0;
function ccScale(control) {
   if (CC_UI_SCALE > 0) return CC_UI_SCALE;
   var r = 0;
   try { r = control ? control.displayPixelRatio : 0; } catch (e) { r = 0; }
   if (!(r > 0)) { try { r = (new HorizontalSizer).displayPixelRatio; } catch (e2) { r = 1; } }
   CC_UI_SCALE = Math.max(1.5, r > 0 ? r : 1);
   return CC_UI_SCALE;
}
function ccPx(n, control) { return Math.round(n * ccScale(control)); }
// Corta un texto con «…» para que quepa en maxW px (midiendo con la fuente que lo pinta).
var CC_ELIDE_SPY = null;          // (solo pruebas: si es un array, cada texto que ccElide CORTA se apunta)
function ccElide(font, text, maxW) {
   var t = String(text);
   if (font.width(t) <= maxW) return t;
   if (CC_ELIDE_SPY) CC_ELIDE_SPY.push(t);
   var lo = 0, hi = t.length;
   while (lo < hi) { var mid = Math.ceil((lo + hi) / 2); if (font.width(t.substring(0, mid) + "…") <= maxW) lo = mid; else hi = mid - 1; }
   return lo > 0 ? t.substring(0, lo) + "…" : "…";
}
// Parte un texto en líneas que quepan en maxW px.
function ccWrap(font, text, maxW) {
   // (23-oct, vídeo del recorrido: «unos 13 / 600 millones» partido por el espacio de los miles. Un espacio entre dos grupos de cifras
   //  —«13 600», «1 192»— no parte línea: las palabras se separan solo por los demás)
   var raw = String(text).split(" "), words = [], i;
   for (i = 0; i < raw.length; ++i) {
      if (words.length && /\d$/.test(words[words.length - 1]) && /^\d{3}(\D|$)/.test(raw[i]) && /(^|[^\d.,])\d{1,3}$/.test(words[words.length - 1].split(" ").pop())) words[words.length - 1] += " " + raw[i];
      else words.push(raw[i]);
   }
   // (24-oct, «también: …» de las placas) Un token unido con espacios duros (U+00A0: un nombre entero, «Disco grueso (α alto)») no se parte
   //  por dentro MIENTRAS QUEPA en una línea; si él solo no cabe, entonces sí se parte por sus espacios duros
   var wide = [];
   for (i = 0; i < words.length; ++i) {
      if (words[i].indexOf("\u00a0") >= 0 && font.width(words[i]) > maxW) wide = wide.concat(words[i].split("\u00a0"));
      else wide.push(words[i]);
   }
   words = wide;
   var lines = [], cur = "";
   for (i = 0; i < words.length; ++i) {
      var t = cur ? cur + " " + words[i] : words[i];
      if (font.width(t) <= maxW || !cur) cur = t; else { lines.push(cur); cur = words[i]; }
   }
   if (cur) lines.push(cur);
   return lines;
}
// Curva de movimiento de tokens.json (cubic-bezier(.16,1,.3,1)), aproximada por su
// solución numérica: t (0..1) -> progreso (0..1).
// Curva SIMÉTRICA (a mitad de tiempo, mitad de camino): para los fundidos cruzados, que se vea el cruce.
function ccEaseInOut(t) { if (t <= 0) return 0; if (t >= 1) return 1; return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; }
function ccEase(t) {
   if (t <= 0) return 0;
   if (t >= 1) return 1;
   var lo = 0, hi = 1, x1 = 0.16, y1 = 1, x2 = 0.3, y2 = 1;
   for (var i = 0; i < 24; ++i) {
      var u = (lo + hi) / 2, x = 3 * (1 - u) * (1 - u) * u * x1 + 3 * (1 - u) * u * u * x2 + u * u * u;
      if (x < t) lo = u; else hi = u;
   }
   var s = (lo + hi) / 2;
   return 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s;
}
