// ============================================================================
// src/ui/cc_paint.js — EL DIBUJO: cuatro paneles, la línea de tiempo y la ficha
// ----------------------------------------------------------------------------
// Funciones que pintan sobre un Graphics de tamaño (w, h) a partir del ESTADO
// compartido S (cc_dialog.js). No crean ventanas ni ejecutan procesos: las usan los
// controles del diálogo (bitmap de base + capa de encima en onPaint) y los tests.
//
//   ccPaintPhoto · ccPaintAlpha · ccPaintAgeMet · ccPaintFamD   (g, w, h, S, sc, part: "base" | "over")
//   ccPaintTimeline · ccPaintCard (con la familia química, ccCardChemFamily) · ccCoverageHtml (el tooltip de la cobertura)
//   IV · Elementos: S.elem (ccElemOn, ccBGet, ccElemRange, ccElemAxis) cambia el color de A y el eje Y de B
//   (la barra de estado de abajo es ccPaintStatusBar, en cc_frame.js: el armazón común con CabraStars)
//
// DIVULGACIÓN (listón de Nino, 14-oct-2026): cada vista lleva bajo su título UNA frase
// llana de qué se ve, con un «?» que abre la explicación larga; cada término técnico, su
// «?» con la cifra traducida («−0,30 = la mitad de hierro que el Sol»). Los «?» y los
// botones pintados se registran como ZONAS (S.hits[panel]) que el diálogo consulta con el
// ratón; la burbuja de ayuda (S.tip) se pinta en la capa de encima.
//
// S = { res, list, photo, sel, hover, group, opts, zoom, anim, hits, tip, dView, cardDetail, cardScroll }
// ES5 puro.
// ============================================================================

function ccPen(c, w, style) { return (style === undefined) ? new Pen(c, w) : new Pen(c, w, style); }
function ccBrush(c) { return new Brush(c); }
// Las cifras que se PINTAN: con coma decimal en castellano (el CSV usa ccFmt, con punto).
function ccFmtL(x, d) { var t = ccFmt(x, d); return CC_LANG === "es" ? t.replace(".", ",") : t; }
function ccFmtSignedL(x, d) { var t = ccFmtSigned(x, d); return CC_LANG === "es" ? t.replace(".", ",") : t; }
// OJO: en PJSR los draw* de contorno (drawRect, drawRoundedRect...) RELLENAN con el pincel vigente `g.brush`.
// Tras un fillPolygon (que exige fijar g.brush) hay que vaciarlo, o el siguiente contorno sale relleno:
// asi salio GRIS CLARO la burbuja de ayuda de B (el color del ultimo triangulito de borde) y NEGRAS las
// cajas de Naidu en D (el velo de la zona prohibida). Medido con tests/cc_color_probe.js el 14-oct-2026.
function ccNoBrush(g) { g.brush = new Brush(0x00000000, BrushStyle_Empty); }
function ccFillRect(g, x0, y0, x1, y1, c) { g.fillRect(x0, y0, x1, y1, ccBrush(c)); }
// CC_ROWS: cuando no es null, cada texto pintado apunta su franja [arriba, abajo] (la ficha y los cuerpos con rueda cortan por
// FILAS ENTERAS: revisor visual del 22-oct, «filas a medias bajo ↓ rueda: más»). Fuera de esos dos, null: no cuesta nada.
var CC_ROWS = null;
// CC_ROW_COLS: un cuerpo a DOS columnas (II ancho) dice dónde parte; cada columna corta sus filas aparte (si se funden las
// franjas de las dos, sus filas se solapan en alto y salen un solo bloque gigante: II enseñaba 2 filas y hueco, 22-oct noche).
var CC_ROW_COLS = null;
// (23-oct, R16) CC_TEXT_SPY (solo pruebas): si es un array, cada texto pintado se apunta (T19 busca letras de panel sueltas)
var CC_TEXT_SPY = null;
// (23-oct) CC_FONT_SPY (solo pruebas): si es un array, el alto en px de cada letra pintada (T17 X9: la vista previa, legible)
var CC_FONT_SPY = null;
function ccTextAt(g, font, color, x, y, text) { g.font = font; g.pen = ccPen(color, 1); g.drawText(x, y, text); if (CC_ROWS) CC_ROWS.push([y - font.ascent, y + font.descent, x]); if (CC_TEXT_SPY) CC_TEXT_SPY.push(String(text)); if (CC_FONT_SPY) CC_FONT_SPY.push(font.pixelSize); }
// ---------------------------------------------------------------------------
// EL RELOJ DEL DIÁLOGO (23-oct, opción (a) de Nino): S.clockT = «T Ga atrás» (null = hoy) lo ponen la vista previa / grabación de II
// (el instante del vídeo) y la regla «Tiempo» de III. Con él, B, C y D (y la foto si S.clockPhoto: solo con la regla de III; durante la
// vista previa la foto NO se toca) enseñan SOLO las nacidas —la regla de «La historia del campo»: ccJourneyBirth ≥ ½; las sin edad, fuera—,
// y la línea de tiempo E marca el instante con su cursor. S.clockVisit (Gran recorrido): la edad de la estrella visitada.
// ---------------------------------------------------------------------------
function ccClockOn(S) { return !!S && typeof S.clockT === "number" && S.clockT > 0 && !(typeof ccBroken === "function" && ccBroken("noclockfilter")); }
function ccClockList(S) {
   var L = (S && S.list) || [];
   if (!ccClockOn(S) || !S.res) return L;
   var C = S._clockCache, T = S.clockT;
   if (C && C.src === L && C.T === T && C.res === S.res) return C.out;
   var out = [], st = S.res.stars;
   for (var i = 0; i < L.length; ++i) {
      var a = st[L[i]] && st[L[i]].age ? st[L[i]].age.adopted : null;
      if (!a || !(a.v > 0)) continue;
      if (typeof ccJourneyBirth === "function" ? ccJourneyBirth(a, T) >= 0.5 : Math.min(a.v, CC_SCI.UNIVERSE_GA) >= T) out.push(L[i]);
   }
   S._clockCache = { src: L, T: T, res: S.res, out: out };
   return out;
}
function ccPhotoList(S) { return (S && S.clockPhoto) ? ccClockList(S) : ((S && S.list) || []); }
// Las franjas apuntadas, fundidas en bloques [arriba, abajo] que no se tocan (en orden).
function ccRowBlocks(R) {
   var a = (R || []).slice().sort(function(p, q) { return p[0] - q[0]; }), out = [];
   for (var i = 0; i < a.length; ++i) { var L = out[out.length - 1]; if (L && a[i][0] <= L[1] + 1) L[1] = Math.max(L[1], a[i][1]); else out.push([a[i][0], a[i][1]]); }
   return out;
}
// Los bloques de UNA columna [x0, x1) (las franjas apuntadas con su x).
function ccRowBlocksCol(R, x0, x1) { return ccRowBlocks((R || []).filter(function(r) { return r[2] >= x0 && r[2] < x1; })); }
// Lo que se ve de [top, bottom) sin filas a medias: { y0, y1 } (en las mismas coordenadas que los bloques).
function ccWholeRows(B, top, bottom) {
   var y0 = top, y1 = top;
   for (var i = 0; i < B.length; ++i) {
      if (B[i][0] < top && B[i][1] > top) y0 = Math.max(y0, B[i][1] + 1);    // una fila cortada por arriba: fuera
      if (B[i][0] >= top && B[i][1] <= bottom) y1 = Math.max(y1, B[i][1] + 1);
   }
   if (y1 <= y0) y1 = bottom;            // (ninguna fila entera cabe: mejor algo que nada)
   return { y0: y0, y1: y1 };
}
// Un texto con HALO del color del fondo (8 direcciones): legible encima de puntos y curvas (rótulos de región, el Sol)
function ccHaloText(g, f, color, x, y, t, sc) {
   var hc = ccInt(CC_ATLAS.bg, 0.9), d = Math.max(1, Math.round(1.2 * sc));
   g.font = f; g.pen = ccPen(hc, 1);
   for (var dx = -1; dx <= 1; ++dx) for (var dy = -1; dy <= 1; ++dy) if (dx || dy) g.drawText(x + dx * d, y + dy * d, t);
   ccTextAt(g, f, color, x, y, t);
}
function ccTextIn(g, font, color, x0, y0, x1, y1, text, align) { g.font = font; g.pen = ccPen(color, 1); g.drawTextRect(x0, y0, x1, y1, text, align); if (CC_TEXT_SPY) CC_TEXT_SPY.push(String(text)); }
// (23-oct, noche, revisión visual 6/7: la curva violeta cruzaba «GAIA-ENCELADUS» y un punto pisaba la «S» de «THAMNOS»; en el litio, «elegida:
//  sin A(Li)» sobre los ▽ y «Sol» tapado) Un rótulo con PLACA del fondo debajo y halo, pintado DESPUÉS de curvas y puntos.
//  ROJO «noplate» de T22: sin placa (solo el halo de antes). Devuelve la caja de la placa.
function ccPlateText(g, f, color, x, y, t, sc, alpha) {
   var b = { x0: x - 3 * sc, y0: y - f.ascent - 1.5 * sc, x1: x + f.width(t) + 3 * sc, y1: y + f.descent + 1.5 * sc };
   if (!ccPBroken("noplate")) { g.antialiasing = true; g.fillRoundedRect(b.x0, b.y0, b.x1, b.y1, 30, 60, ccBrush(ccInt(CC_ATLAS.bg, ccIsNum(alpha) ? alpha : 0.82))); ccNoBrush(g); }
   ccHaloText(g, f, color, x, y, t, sc);
   if (typeof CC_PLATES !== "undefined" && CC_PLATES) CC_PLATES.push({ t: String(t), x0: b.x0, y0: b.y0, x1: b.x1, y1: b.y1 });
   return b;
}
// (23-oct, noche, revisión visual 3: «es 10–13.5 Ga» salía con punto en la ficha —CC_POP_AGES de cc_science.js, que no es de la interfaz—)
// En castellano, una cifra con punto decimal pasa a coma en lo que la interfaz pinta de cc_science.js. ROJO «dotdec»: no se toca.
function ccEsDigits(t) { return (CC_LANG === "es" && !ccPBroken("dotdec")) ? String(t).replace(/(\d)\.(\d)/g, "$1,$2") : t; }
var CC_PLATES = null;          // (solo pruebas: si es un array, cada rótulo con placa se apunta con su caja)
// (23-oct, noche, revisión visual 8: el cursor del reloj cortaba «Disco gru|eso») Una raya vertical que pasa POR DETRÁS de los rótulos:
// se pinta a trozos, saltando las cajas [x0, y0, x1, y1] que cruza (con margen m). ROJO «cursorcut» de T22: la raya entera, encima.
function ccVLineBehind(g, x, y0, y1, boxes, m) {
   var cuts = [], i;
   if (!ccPBroken("cursorcut")) for (i = 0; boxes && i < boxes.length; ++i) { var b = boxes[i]; if (x >= b[0] - m && x <= b[2] + m && b[3] + m > y0 && b[1] - m < y1) cuts.push([Math.max(y0, b[1] - m), Math.min(y1, b[3] + m)]); }
   cuts.sort(function(a, c) { return a[0] - c[0]; });
   var y = y0;
   for (i = 0; i < cuts.length; ++i) { if (cuts[i][0] > y) g.drawLine(x, y, x, cuts[i][0]); y = Math.max(y, cuts[i][1]); }
   if (y < y1) g.drawLine(x, y, x, y1);
}
// La caja de un rótulo [fuente, color, x, y, texto] de las listas `relabel` / `labels` de las líneas de tiempo
function ccLabelBox(L) { return [L[2], L[3] - L[0].ascent, L[2] + L[0].width(L[4]), L[3] + L[0].descent]; }
function ccDisc(g, x, y, r, fill, line, lw) {
   if (fill !== null && fill !== undefined) g.fillCircle(x, y, r, ccBrush(fill));
   if (line !== null && line !== undefined) g.strokeCircle(x, y, r, ccPen(line, lw || 1));
}
// Mayúsculas de versalita, salvo la notación química ([Fe/H] no es «[FE/H]», y α no es «Α»).
function ccCaps(t) {
   // (las notaciones con corchete o paréntesis —[Fe/H], A(Li)— y Teff no se tocan: «A(LI)», «TEFF» no se leen)
   return String(t).split(" ").map(function(w) { return (w.indexOf("[") >= 0 || w.indexOf("(") >= 0 || w === "Teff" || /[Ͱ-Ͽ]/.test(w)) ? w : w.toUpperCase(); }).join(" ");
}
// (23-oct, noche: «P(α alto) < 0.01» y «disco · P > 0.99» salían con punto en castellano; las cotas también por ccFmtL. ROJO «dotdec» de T22)
function ccP(p) { if (!ccIsNum(p)) return "—"; if (ccPBroken("dotdec")) return p < 0.01 ? "< 0.01" : (p > 0.99 ? "> 0.99" : ccFmtL(p, 2)); return p < 0.01 ? "< " + ccFmtL(0.01, 2) : (p > 0.99 ? "> " + ccFmtL(0.99, 2) : ccFmtL(p, 2)); }

// ---------------------------------------------------------------------------
// ZONAS DE AYUDA Y BOTONES PINTADOS
// ---------------------------------------------------------------------------
// ---------------------------------------------------------------------------
// NUNCA SE ATIENDEN EVENTOS CON UN PINTADO ABIERTO (26-oct-2026, propagado de Cabra3D/src/ui/photo_view.js; la causa, en CabraShared/csh_net.js
// junto a CSH_PAINTING y en Cabra3D/HANDOFF.md «cuelgue al pintar la foto»). Cada onPaint de CabraComposition pinta DENTRO de ccPaintGuarded:
// mientras dura, CSH_PAINTING > 0 y ni cshProcessEvents ni cshYield bombean (el trabajo se hace igual, solo sin atender la interfaz durante ese
// pintado). El caso real: el onPaint del mapa de III calcula el pasado de las órbitas la primera vez (GX.ensureDeep → cshProcessEvents en cada
// tanda). CC_PAINT_GUARD = false es la costura del rojo (tests/cc_propag_26oct.js P6).
// ---------------------------------------------------------------------------
var CC_PAINT_GUARD = true;
function ccPaintGuarded(self, fn) {
   var on = (CC_PAINT_GUARD === true && typeof CSH_PAINTING === "number");
   if (on) ++CSH_PAINTING;
   try { return fn.call(self); } finally { if (on) --CSH_PAINTING; }
}
function ccHitsReset(S, panel) { if (!S.hits) S.hits = {}; S.hits[panel] = []; }
function ccHit(S, panel, x0, y0, x1, y1, text, action, value) {
   if (!S.hits) S.hits = {};
   (S.hits[panel] = S.hits[panel] || []).push({ x0: x0, y0: y0, x1: x1, y1: y1, text: text || "", action: action || "", value: value });
}
function ccHitAt(S, panel, x, y) {
   var L = (S.hits && S.hits[panel]) || [];
   for (var i = L.length - 1; i >= 0; --i) if (x >= L[i].x0 && x <= L[i].x1 && y >= L[i].y0 && y <= L[i].y1) return L[i];
   return null;
}
// El «?»: un circulito con una interrogación. Devuelve su ancho. Con `S.video` (el fotograma de un vídeo de II, 22-oct) no se pinta
// —en un vídeo no hay a quién ayudar— pero se devuelve su ancho: la maqueta no se mueve.
function ccQMark(g, x, y, sc, S) {
   var r = 5.2 * sc;
   if (S && S.video === true && !ccVideoBroken()) return 2 * r;
   g.antialiasing = true;
   g.strokeCircle(x + r, y - r * 0.8, r, ccPen(ccInt(CC_ATLAS.gold, 0.75), Math.max(1, 0.9 * sc)));
   var f = ccFont("text", 7.6 * sc, true);
   ccTextAt(g, f, ccInt(CC_ATLAS.gold, 0.9), x + r - f.width("?") / 2, y - r * 0.8 + f.ascent / 2 - 1, "?");
   return 2 * r;
}
// La frase llana de una vista: «?» + texto en cursiva (en una o dos líneas, nunca cortado).
function ccCaption(g, x, y, maxW, capKey, tipKey, sc, S, panel) {
   var f = ccFont("text", 8.6 * sc, false, true), qw = ccQMark(g, x, y, sc, S) + 6 * sc;
   var lines = ccWrap(f, ccT(capKey), maxW - qw);
   for (var i = 0; i < lines.length && i < 2; ++i) ccTextAt(g, f, ccInt(CC_ATLAS.text2), x + qw, y + i * 13 * sc, lines[i]);
   ccHit(S, panel, x - 2 * sc, y - 12 * sc, x + qw + 6 * sc, y + 4 * sc, ccT(tipKey));
   return y + (Math.min(2, lines.length) - 1) * 13 * sc;
}
// El «?» de la frase llana junto al TÍTULO (S.compact, 22-oct, como CabraStars con el HR): la frase y su explicación larga van a
// la burbuja; los paneles ganan el alto de una o dos líneas. `plate`: placa opaca detrás (sobre la foto). Devuelve el ancho.
function ccTitleHelp(g, x, y, sc, S, panel, capKey, tipKey, plate) {
   if (plate) g.fillRoundedRect(x - 4 * sc, y - 15 * sc, x + 16 * sc, y + 5 * sc, 40, 99, ccBrush(ccInt(CC_ATLAS.bg, 0.94)));
   var qw = ccQMark(g, x, y, sc, S);
   ccHit(S, panel, x - 4 * sc, y - 14 * sc, x + qw + 6 * sc, y + 5 * sc, ccT(capKey) + (tipKey ? " " + ccT(tipKey) : ""));
   return qw;
}
// La burbuja de ayuda (en la capa de encima del panel que la pide).
function ccTipBubble(g, w, h, S, panel, sc) {
   var T = S.tip;
   if (panel === "card") S.cardLinkTip = null;           // (dónde quedó el aviso del nombre-enlace en este pintado: lo leen las pruebas)
   if (!T || T.panel !== panel || !T.text) return;
   // (27-oct-2026, D3 de Nino: «Open in SIMBAD» tapaba la línea de datos de debajo del nombre —«logg»—) el aviso del NOMBRE-ENLACE de la ficha va
   // donde lo ponen los tres scripts (CabraShared/csh_link.js cshLinkTipPlace): a la derecha del nombre, si no encima, si no en su línea; nunca
   // bajo el cursor. Las demás burbujas, como siempre. (CC_TIP_UNDER: el rojo, el sitio de antes)
   var CL = S.cardLink;
   if (panel === "card" && CL && CL.rect && T.text === ccLinkTip(CL.link) && typeof cshLinkTipPlace === "function" && CC_TIP_UNDER !== true) {
      var fL = ccFont("text", 9 * sc), sz = cshLinkTipSize(fL, T.text, sc);
      var pl = cshLinkTipPlace(CL.rect, sz.w, sz.h, w, h, Math.round(CSH_LINK_TIP.GAP * sc), 0);
      cshLinkTipPaint(g, pl, T.text, fL, sc, { bg: ccInt(CC_ATLAS.surface2, 0.97), border: ccInt(CC_ATLAS.gold, 0.6), text: ccInt(CC_ATLAS.text) });
      S.cardLinkTip = { x: pl.x, y: pl.y, w: pl.w, h: pl.h, where: pl.where, text: T.text };
      return;
   }
   var f = ccFont("text", 9 * sc), maxW = Math.min(w - 16 * sc, 360 * sc), lines = ccWrap(f, T.text, maxW - 20 * sc);
   var lw = 0;
   for (var i = 0; i < lines.length; ++i) lw = Math.max(lw, f.width(lines[i]));
   var bw = lw + 20 * sc, bh = lines.length * 14 * sc + 14 * sc, bx = T.x + 14 * sc, by = T.y + 16 * sc;
   if (bx + bw > w - 4) bx = Math.max(4, w - 4 - bw);
   if (by + bh > h - 4) by = Math.max(4, T.y - 10 * sc - bh);
   if (panel === "card" && CL && CL.rect && T.text === ccLinkTip(CL.link)) S.cardLinkTip = { x: bx, y: by, w: bw, h: bh, where: "under", text: T.text };   // (el rojo CC_TIP_UNDER)
   g.antialiasing = true;
   g.fillRoundedRect(bx, by, bx + bw, by + bh, 8, 12, ccBrush(ccInt(CC_ATLAS.surface2, 0.97)));
   ccNoBrush(g); g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.6), 1); g.drawRoundedRect(bx, by, bx + bw, by + bh, 8, 12);
   for (i = 0; i < lines.length; ++i) ccTextAt(g, f, ccInt(CC_ATLAS.text), bx + 10 * sc, by + 18 * sc + i * 14 * sc, lines[i]);
}

// La placa del título de un panel; `plate` = fondo opaco detrás. Devuelve dónde acaba.
// (23-oct · R16, decisión de Nino: SIN letras A–E, como CabraStars y Cabra3D) El nombre del panel en versalitas DORADAS y, tras « — »,
// lo que enseña en versalitas apagadas: «LA FOTO — ESTRELLAS POR METALICIDAD», «QUÍMICA — [α/Fe] FRENTE A [Fe/H]». (Un título que
// aún empiece por un numeral suelto, «X · …», se pinta como antes: numeral dorado + versalitas apagadas.)
function ccPanelTitle(g, x, y, text, sc, plate) {
   if (ccPBroken("letters")) text = "A · " + text;          // (rojo de T19 Z3: el título vuelve a llevar letra)
   var fT = ccFont("text", 8.6 * sc, false, false, Math.round(8.6 * sc * CC_ATLAS.labelTracking));
   if (!/^\S{1,3} · /.test(String(text))) {
      var dash = String(text).indexOf(" — "), nm = ccCaps(dash >= 0 ? String(text).substring(0, dash) : String(text)), more = dash >= 0 ? ccCaps(String(text).substring(dash)) : "";
      var wN = fT.width(nm), wM = more ? fT.width(more) : 0;
      if (plate) g.fillRoundedRect(x - 8 * sc, y - 16 * sc, x + wN + wM + 10 * sc, y + 7 * sc, 12, 40, ccBrush(ccInt(CC_ATLAS.bg, 0.94)));
      ccTextAt(g, fT, ccInt(CC_ATLAS.gold), x, y - Math.round(1 * sc), nm);
      if (more) ccTextAt(g, fT, ccInt(CC_ATLAS.text3), x + wN, y - Math.round(1 * sc), more);
      return x + wN + wM;
   }
   var parts = String(text).split(" · ");
   var fN = ccFont("display", 13 * sc, false, true), fL = ccFont("text", 8.6 * sc, false, false, Math.round(8.6 * sc * CC_ATLAS.labelTracking));
   var rest = parts.length > 1 ? ccCaps(parts.slice(1).join(" · ")) : "";
   var dx = fN.width(parts[0]) + Math.round(8 * sc);
   if (plate) g.fillRoundedRect(x - 8 * sc, y - 16 * sc, x + dx + fL.width(rest) + 10 * sc, y + 7 * sc, 12, 40, ccBrush(ccInt(CC_ATLAS.bg, 0.94)));
   ccTextAt(g, fN, ccInt(CC_ATLAS.gold), x, y, parts[0]);
   if (rest) ccTextAt(g, fL, ccInt(CC_ATLAS.text3), x + dx, y - Math.round(1 * sc), rest);
   return x + dx + fL.width(rest);
}
function ccFrame(g, w, h, sc) {
   ccFillRect(g, 0, 0, w, h, ccInt(CC_ATLAS.surface));
   g.pen = ccPen(ccInt(CC_ATLAS.line), 1);
   g.drawRect(0, 0, w - 1, h - 1);
   var k = Math.round(4 * sc);
   g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.10), 1);
   g.drawRect(k, k, w - 1 - k, h - 1 - k);
}
// (23-oct, revisor R15) Lo que enseñan B, C, D, E y el mapa de III mientras la vista previa o la grabación de II ocupan la foto: el vídeo
// ya los lleva dentro (no dos juegos a la vez). Una nota tenue, centrada.
function ccPaintVideoCover(g, w, h, sc) {
   ccFrame(g, w, h, sc);
   var f = ccFont("text", 9 * sc, false, true), t = ccT("videoCover"), tw = f.width(t);
   if (tw > w - 20 * sc) { t = ccT("videoCoverShort"); tw = f.width(t); }
   ccTextAt(g, f, ccInt(CC_ATLAS.text3, 0.85), Math.round((w - tw) / 2), Math.round(h / 2 + f.ascent / 2 - 1), t);
}
// El pie de un diagrama: UNA fila. A la derecha, el rótulo del eje X con su «?»; a la izquierda, los
// trozos del resumen que caben; los que no, en un «?» con el texto entero (texto largo -> ayuda; nada cortado).
// (23-oct, noche, revisión visual 4) Cada trozo puede ser [corto, largo]: en la ventana se pinta el corto y el «?» lleva los largos.
// Ya NO hay «…» antes del «?» (se leía como un texto cortado; ROJO «footdots»: vuelve). En la exportada (ccExporting), dos filas: cada
// trozo entero —el largo si cabe, si no el corto— y lo que no quepa en las dos, callado.
function ccFoot(g, P, w, h, sc, segs, S, panel, xLabel, xTip) {
   var f = ccFont("text", 8 * sc, false, true), fl = ccFont("text", 8.4 * sc, false, false, Math.round(8.4 * sc * 0.18)), y = h - 9 * sc;
   var xr = w - 12 * sc, i, exp = ccExporting();
   var SH = function(q) { return (q instanceof Array) ? q[0] : q; }, LG = function(q) { return (q instanceof Array) ? q[1] : q; };
   if (xTip) { xr -= 12 * sc; ccQMark(g, xr, y + 1 * sc, sc, S); ccHit(S, panel, xr - 3 * sc, y - 12 * sc, xr + 14 * sc, y + 4 * sc, xTip); xr -= 4 * sc; }
   if (xLabel) { xr -= fl.width(xLabel); ccTextAt(g, fl, ccInt(CC_ATLAS.text2), xr, y, xLabel); xr -= 14 * sc; }
   var x0 = 12 * sc, avail = xr - x0, txt = "";
   if (exp) {
      // fila de arriba: todo el ancho; fila de abajo: hasta el rótulo del eje
      var rows = [{ y: y - 11 * sc, w: w - 12 * sc - x0, t: "" }, { y: y, w: avail, t: "" }], r = 0;
      for (i = 0; i < segs.length && r < rows.length; ++i) {
         var cands = [LG(segs[i]), SH(segs[i])], put = false;
         while (!put && r < rows.length) {
            for (var c = 0; c < cands.length && !put; ++c) { var tt = rows[r].t ? rows[r].t + " · " + cands[c] : cands[c]; if (f.width(tt) <= rows[r].w) { rows[r].t = tt; put = true; } }
            if (!put) { if (!rows[r].t) break; ++r; }          // (no cabe ni en una fila vacía: ese trozo se calla)
         }
      }
      for (r = 0; r < rows.length; ++r) if (rows[r].t) ccTextAt(g, f, ccInt(CC_ATLAS.text3), x0, rows[r].y, rows[r].t);
      return;
   }
   for (i = 0; i < segs.length; ++i) {
      var t = txt ? txt + " · " + SH(segs[i]) : SH(segs[i]);
      if (f.width(t) + 20 * sc > avail) break;
      txt = t;
   }
   if (txt) ccTextAt(g, f, ccInt(CC_ATLAS.text3), x0, y, txt);
   // (S.video: en un vídeo, lo que no cabe se calla: ni «…» ni «?», que nadie puede abrir)
   var more = i < segs.length;
   for (var j = 0; j < i && !more; ++j) if (SH(segs[j]) !== LG(segs[j])) more = true;      // (un trozo pintado corto: el largo, en el «?»)
   if (more && !(S && S.video === true && !ccVideoBroken())) {
      if (S && S.compact && txt && (ccPBroken("footdots") || (CC_EXPORT_PAINT === true && ccPBroken("exportcut")))) { ccTextAt(g, f, ccInt(CC_ATLAS.text3), x0 + f.width(txt) + 2 * sc, y, "…"); txt += " …"; }
      var qx = x0 + (txt ? f.width(txt) + 6 * sc : 0);
      ccQMark(g, qx, y + 1 * sc, sc, S);
      ccHit(S, panel, qx - 3 * sc, y - 12 * sc, qx + 14 * sc, y + 4 * sc, segs.map(LG).join(" · "));
   }
}

// ---------------------------------------------------------------------------
// LOS SÍMBOLOS DE LAS ESTRELLAS
// ---------------------------------------------------------------------------
// (CC_BREAK «novideo», rojo de T17: los fotogramas de un vídeo vuelven a pintar «?», «…» y las píldoras)
function ccPBroken(k) { return (typeof ccBroken === "function") && ccBroken(k); }     // (los rojos de T18, sin depender de cc_dialog.js)
function ccVideoBroken() { return (typeof ccBroken === "function") && ccBroken("novideo"); }
// LAS CIFRAS DE UNA ÓRBITA (las del motor cc_dynamics.js, s.fam.orbit), UNA sola forma de escribirlas: la ficha y el rótulo del mapa de
// III las piden aquí (22-oct, integración): «peri 7,1 · apo 9,3 · Zmax 0,45 kpc · e 0,12». "" si no hay órbita ligada.
function ccOrbitLine(o, lang) {
   if (!o || o.bound === false || !ccIsNum(o.rperi) || !ccIsNum(o.rapo)) return "";
   var L = (lang === "es") ? "es" : "en";
   // (23-oct, P7: la Zmax por ccZmaxText de cc_story.js —«≈ 0,78» si es inestable o el pericentro < 1 kpc—; rojo `zmaxplain` de T20)
   var zt = (typeof ccZmaxText === "function" && !ccPBroken("zmaxplain")) ? ccZmaxText(o, L) : ccDec(o.zmax, o.zmax < 1 ? 2 : 1, L);
   // (27-oct, R2: `o.approx` —ccOrbit no conservó la energía ni partiendo el paso, cc_dynamics.js— pone «≈» también en peri, apo y e;
   //  la Zmax ya lo lleva por zmaxApprox, que cc_engine.js enciende con approx. Rojo `noapprox` de T20)
   var q = (o.approx && !ccPBroken("noapprox")) ? "≈ " : "";
   return "peri " + q + ccDec(o.rperi, 1, L) + " · apo " + q + ccDec(o.rapo, 1, L) + " · Zmax " + zt + " kpc · e " + q + ccDec(o.ecc, 2, L);
}
function ccStarRadius(s, S, sc) {
   var r = 3.3 * sc;
   if (S.opts && S.opts.sizeByAge) {
      var a = (s.age && s.age.adopted) ? s.age.adopted.v : null;
      r = (a === null) ? 2.6 * sc : (2.6 + Math.min(14, a) / 14 * 3.6) * sc;
   }
   return r;
}
function ccChemSolid(s) { return !!(s.chem && s.chem.feh && s.chem.feh.src !== "gspspec" && s.chem.feh.src !== "xpg"); }

// ---------------------------------------------------------------------------
// IV · ELEMENTOS (22-oct, fase 1 de los cuatro grupos): S.elem = el elemento elegido ("Fe" = lo de siempre: la foto por [Fe/H]
// y B por [α/Fe]). Con otro X, la foto se colorea por [X/Fe] y B pone [X/Fe] en su eje Y. Sin S.elem (CabraStarAnalysis, la
// leyenda), todo como antes.
// ---------------------------------------------------------------------------
function ccElemOn(S) { return !!(S && typeof S.elem === "string" && S.elem && S.elem !== "Fe") && !(typeof ccBroken === "function" && ccBroken("noelem")); }
function ccElemOf(s, X) {
   if (X === "Li") { var L = ccLiOf(s); return (L && !L.ul) ? L : null; }        // (el litio: solo las DETECCIONES; los límites, aparte)
   var e = (s && s.chem && s.chem.el) ? s.chem.el[X] : null; return (e && ccIsNum(e.v)) ? e : null;
}
// ---------------------------------------------------------------------------
// EL LITIO (23-oct-2026; los datos, docs/litio_y_mg_xiang.md): s.chem.li = { v: A(Li) ABSOLUTA, e, ul (límite superior), teff, logg, src }.
// No es un [X/Fe]: la foto lo colorea en una escala FIJA de 0 a 3,3 (anclas físicas: 1,05 el Sol hoy, 2,2 la meseta de Spite, 3,26 los
// meteoritos —Asplund+09, Sbordone+10—; con la escala relativa de los [X/Fe] un campo de enanas frías agotadas saldría «rico») y los
// límites son un anillo gris hueco; B pasa a A(Li) frente a Teff (las calientes a la IZQUIERDA, como un HR —decisión de esta integración; la
// literatura del litio usa las dos orientaciones—): la destrucción del litio depende de la Teff/masa (M 67: límites < 0,5 a 5 000 K, 2,4 a 6 200 K).
// ---------------------------------------------------------------------------
var CC_LI = { MAX: 3.3, SUN: 1.05, SUN_TEFF: 5772, SPITE: 2.2, SPITE_E: 0.09, METEOR: 3.26, RICH: 1.5, GIANT_LOGG: 3.5, GIANT_TEFF: 5300,
              TEFF0: 7000, TEFF1: 4000, Y0: -0.6, Y1: 3.7 };
// El eje Teff del B del litio (23-oct, revisor R12: la elegida a 3 850 K se salía del 7 000 → 4 000 fijo): de fábrica 7 000 → 4 000, y se
// abre de 500 en 500 K hasta incluir a TODAS las pintadas con A(Li) o límite (con 150 K de aire; entre 8 000 y 3 000 K).
// ROJO «liaxisfix» de T18: el eje fijo de antes.
function ccLiAxis(S) {
   var lo = 1e9, hi = -1e9, L = (S && S.list) || [], st = (S && S.res) ? S.res.stars : [];
   for (var i = 0; i < L.length; ++i) { var li = ccLiOf(st[L[i]]); if (li && ccIsNum(li.teff)) { if (li.teff < lo) lo = li.teff; if (li.teff > hi) hi = li.teff; } }
   // (y la ELEGIDA, tenga o no A(Li): si no lo tiene, B la marca con una raya en su Teff —ccLiSelMark—)
   var ss = (S && S.res && S.sel >= 0) ? st[S.sel] : null, lis = ss ? ccLiOf(ss) : null, selT = lis && ccIsNum(lis.teff) ? lis.teff : (ss && ss.chem && ccIsNum(ss.chem.teff) ? ss.chem.teff : null);
   if (ccIsNum(selT)) { if (selT < lo) lo = selT; if (selT > hi) hi = selT; }
   var t0 = CC_LI.TEFF0, t1 = CC_LI.TEFF1;
   if (!(typeof ccBroken === "function" && ccBroken("liaxisfix")) && lo < 1e9) {
      t0 = Math.min(8000, Math.max(t0, Math.ceil((hi + 150) / 500) * 500));
      t1 = Math.max(3000, Math.min(t1, Math.floor((lo - 150) / 500) * 500));
   }
   return { t0: t0, t1: t1, tMin: lo, tMax: hi, selT: selT, selLi: !!lis };
}
// La elegida SIN A(Li) en el B del litio: una raya discontinua dorada en su Teff y «elegida: sin A(Li)» (la cruz de siempre no tiene dónde ir)
// (23-oct, noche, revisión visual 7: el rótulo iba siempre abajo, encima de los ▽ del borde) Ahora con placa y en el SITIO LIBRE: arriba,
// en medio o abajo de la raya, a su derecha o a su izquierda, donde menos puntos pintados (S._liPts) caen bajo la placa. ROJO «noplate»:
// abajo y sin placa, como antes.
function ccFreeSpot(cands, f, t, pts, P, sc) {
   var best = null, bc = 1e9, tw = f.width(t), m = 3 * sc;
   for (var i = 0; i < cands.length; ++i) {
      var x = cands[i][0], y = cands[i][1];
      if (x < P.L + 2 * sc || x + tw > P.L + P.pw - 2 * sc || y - f.ascent < P.T + 1 * sc || y + f.descent > P.T + P.ph - 1 * sc) continue;
      var n = 0;
      for (var k = 0; pts && k < pts.length; ++k) if (pts[k][0] >= x - m - pts[k][2] && pts[k][0] <= x + tw + m + pts[k][2] && pts[k][1] >= y - f.ascent - m - pts[k][2] && pts[k][1] <= y + f.descent + m + pts[k][2]) ++n;
      var c = n * 1000 + i;            // (a igualdad, el orden de preferencia)
      if (c < bc) { bc = c; best = { x: x, y: y, under: n }; }
   }
   return best;
}
function ccLiSelMark(g, P, S, sc) {
   var AX = ccLiAxis(S);
   if (!ccIsNum(AX.selT) || AX.selLi) return;
   var xx = P.X(ccClamp(AX.selT, Math.min(P.x0, P.x1), Math.max(P.x0, P.x1))), f = ccFont("text", 7.8 * sc, false, true), t = ccT("liSelNone"), tw = f.width(t);
   g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.7), Math.max(1, sc), PenStyle_Dash); g.drawLine(xx, P.T, xx, P.T + P.ph);
   var tx = (xx + 4 * sc + tw > P.L + P.pw) ? xx - 4 * sc - tw : xx + 4 * sc;
   if (ccPBroken("noplate")) { ccHaloText(g, f, ccInt(CC_ATLAS.goldLight, 0.95), tx, P.T + P.ph - 6 * sc, t, sc); S._liSelLab = { x0: tx - 3 * sc, y0: P.T + P.ph - 6 * sc - f.ascent - 1.5 * sc, x1: tx + tw + 3 * sc, y1: P.T + P.ph - 6 * sc + f.descent + 1.5 * sc, under: -1 }; return; }
   var xR = xx + 5 * sc, xL = xx - 5 * sc - tw, ys = [P.T + 12 * sc, P.T + P.ph - 6 * sc], cands = [];
   for (var yy = P.T + 20 * sc; yy < P.T + P.ph - 10 * sc; yy += 6 * sc) ys.push(yy);          // (y todas las alturas, cada 6 px, a los dos lados)
   for (var i = 0; i < ys.length; ++i) { cands.push([xR, ys[i]]); cands.push([xL, ys[i]]); }
   var sp = ccFreeSpot(cands, f, t, S._liPts, P, sc) || { x: tx, y: P.T + P.ph - 6 * sc, under: -1 };
   var b = ccPlateText(g, f, ccInt(CC_ATLAS.goldLight, 0.95), sp.x, sp.y, t, sc, 0.86);
   S._liSelLab = { x0: b.x0, y0: b.y0, x1: b.x1, y1: b.y1, under: sp.under };
}
function ccLiOf(s) { var L = (s && s.chem) ? s.chem.li : null; return (L && ccIsNum(L.v)) ? L : null; }
function ccLiMode(S) { return ccElemOn(S) && S.elem === "Li"; }
function ccLiRgb(a) { return ccElemRgb(ccClamp(a, 0, CC_LI.MAX) - CC_LI.MAX / 2, CC_LI.MAX / 2); }
function ccLiCounts(S) {
   var det = 0, ul = 0, L = S.list || [];
   for (var i = 0; i < L.length; ++i) { var li = S.res ? ccLiOf(S.res.stars[L[i]]) : null; if (!li) continue; if (li.ul) ++ul; else ++det; }
   return { det: det, ul: ul };
}
// A(Li) en llano: contra la superficie del Sol de hoy (1,05) y la meseta de Spite
function ccLiPlain(L, lang) {
   var E = ccL(lang) === "es", v = L.v, k = Math.pow(10, v - CC_LI.SUN), t;
   if (L.ul) return E ? "como mucho " + ccDec(v, 2, "es") + ": solo un límite superior" : "at most " + ccDec(v, 2, "en") + ": only an upper limit";
   if (Math.abs(v - CC_LI.SUN) < 0.1) t = E ? "tanto litio como la superficie del Sol" : "as much lithium as the surface of the Sun";
   else if (k >= 1) t = E ? ccNice(k, "es", 2) + " veces el litio de la superficie del Sol" : ccNice(k, "en", 2) + " times the lithium of the surface of the Sun";
   else t = E ? "un " + Math.round(100 * k) + " % del litio de la superficie del Sol" : Math.round(100 * k) + "% of the lithium of the surface of the Sun";
   if (Math.abs(v - CC_LI.SPITE) <= 0.15) t += E ? " (en la meseta de Spite)" : " (on the Spite plateau)";
   return t;
}
function ccSrcSolid(src) { return !!src && src !== "gspspec" && src !== "xpg"; }
function ccQuant(a, q) { if (!a.length) return null; var b = a.slice().sort(function(p, r) { return p - r; }); return b[Math.min(b.length - 1, Math.max(0, Math.round(q * (b.length - 1))))]; }
// El punto de B: [Fe/H] (el del MISMO survey que dio el elemento, si lo tiene) y [X/Fe]; con Fe, el par de siempre ([Fe/H], [α/Fe]).
function ccBGet(s, S) {
   if (ccLiMode(S)) { var L = ccLiOf(s); return (L && ccIsNum(L.teff)) ? { x: L.teff, y: L.v, ex: null, ey: L.e, src: L.src, ul: !!L.ul, giant: ccIsNum(L.logg) && L.logg < CC_LI.GIANT_LOGG } : null; }
   if (!ccElemOn(S)) return s.chem.pair ? { x: s.chem.pair.feh, y: s.chem.pair.alpha, ex: s.chem.pair.efeh, ey: s.chem.pair.ealpha, src: s.chem.pair.src } : null;
   var e = ccElemOf(s, S.elem);
   if (!e) return null;
   var rf = (s.recs && e.src && s.recs[e.src] && s.recs[e.src].feh && ccIsNum(s.recs[e.src].feh.v)) ? s.recs[e.src].feh : (s.chem.feh || null);
   return rf ? { x: rf.v, y: e.v, ex: rf.e, ey: e.e, src: e.src } : null;
}
// La escala del color de la foto con [X/Fe]: simétrica en torno al Sol (0), de −R a +R; R = el percentil 90 de |[X/Fe]| de las
// pintadas, redondeado ARRIBA a 0,1 y entre 0,2 y 1,0 (diseño: que la mayoría no sature y que el 0 siga siendo crema).
function ccElemRange(S) {
   var key = S.elem + ":" + (S.list || []).length + ":" + (S.res ? S.res.stars.length : 0);
   if (S._elR && S._elR.key === key) return S._elR.R;
   var v = [], L = S.list || [];
   for (var i = 0; i < L.length; ++i) { var e = S.res ? ccElemOf(S.res.stars[L[i]], S.elem) : null; if (e) v.push(Math.abs(e.v)); }
   var q = ccQuant(v, 0.9), R = (q === null) ? 0.5 : ccClamp(Math.ceil(q * 10 - 1e-9) / 10, 0.2, 1.0);
   S._elR = { key: key, R: R };
   return R;
}
// [X/Fe] -> color: por debajo del Sol, el azul de la escala de hierro; por encima, el oro (las MISMAS paradas: un solo idioma de color)
function ccElemRgb(v, R) { if (!ccIsNum(v)) return ccHexRgb(CC_ATLAS.text3); var t = v / (R || 0.5); return ccFehRgb(t < 0 ? t * 1.3 : t * 0.3); }
// El eje X de B (23-oct, revisor R23: con un elemento de pocos datos —Eu en M 67, 28 estrellas entre −0,3 y +0,2— el eje de −2,6 a +0,7 las
// dejaba en un rincón): con Fe y Mg, el de siempre (el del fondo de APOGEE); con el resto, el de los datos con margen (0,15 dex o el 10 %),
// el Sol (0) siempre dentro y al menos 0,8 dex de ancho, dentro del de siempre. ROJO «elemxfix» de T18: el de siempre.
function ccElemXAxis(S) {
   if (!ccElemOn(S) || S.elem === "Mg" || ccLiMode(S) || ccPBroken("elemxfix")) return { x0: CC_ALPHA_AX.x0, x1: CC_ALPHA_AX.x1 };
   var lo = 1e9, hi = -1e9, L = S.list || [];
   for (var i = 0; i < L.length; ++i) { var b = S.res ? ccBGet(S.res.stars[L[i]], S) : null; if (b && ccIsNum(b.x)) { if (b.x < lo) lo = b.x; if (b.x > hi) hi = b.x; } }
   if (lo > hi) return { x0: CC_ALPHA_AX.x0, x1: CC_ALPHA_AX.x1 };
   lo = Math.min(lo, -0.1); hi = Math.max(hi, 0.1);
   var m = Math.max(0.15, 0.1 * (hi - lo)), x0 = lo - m, x1 = hi + m;
   if (x1 - x0 < 0.8) { var c = (x0 + x1) / 2; x0 = c - 0.4; x1 = c + 0.4; }
   x0 = Math.max(CC_ALPHA_AX.x0, Math.floor(x0 * 10 + 1e-9) / 10); x1 = Math.min(CC_ALPHA_AX.x1, Math.ceil(x1 * 10 - 1e-9) / 10);
   return { x0: x0, x1: x1 };
}
// El eje Y de B: el de siempre para Mg (el del fondo de APOGEE); para el resto, el de los datos (percentiles 5–95, con el Sol dentro)
function ccElemAxis(S) {
   if (!ccElemOn(S) || S.elem === "Mg") return { y0: CC_ALPHA_AX.y0, y1: CC_ALPHA_AX.y1 };
   var key = S.elem + ":" + (S.list || []).length + ":" + (S.res ? S.res.stars.length : 0);
   if (S._elA && S._elA.key === key) return S._elA.ax;
   var v = [], L = S.list || [];
   for (var i = 0; i < L.length; ++i) { var b = S.res ? ccBGet(S.res.stars[L[i]], S) : null; if (b) v.push(b.y); }
   var lo = ccQuant(v, 0.05), hi = ccQuant(v, 0.95);
   if (lo === null) { lo = -0.4; hi = 0.4; }
   lo = Math.max(-1.5, Math.floor((Math.min(lo, -0.2) - 0.1) * 10 + 1e-9) / 10); hi = Math.min(2.0, Math.ceil((Math.max(hi, 0.2) + 0.1) * 10 - 1e-9) / 10);
   S._elA = { key: key, ax: { y0: lo, y1: hi } };
   return S._elA.ax;
}
// Cuántas de las pintadas tienen el elemento (Fe: las que tienen [Fe/H])
function ccElemCount(S, X) {
   var n = 0, L = S.list || [];
   for (var i = 0; i < L.length; ++i) { var s = S.res ? S.res.stars[L[i]] : null; if (!s) continue; if (X === "Fe" ? !!s.chem.feh : !!ccElemOf(s, X)) ++n; }
   return n;
}
// [X/Fe] en llano: «un 35 % más europio por cada átomo de hierro que el Sol»
function ccElemPlain(v, X, lang) {
   var E = ccL(lang) === "es", nm = ccElName(X, lang), p = Math.pow(10, v);
   if (Math.abs(v) < 0.05) return E ? "tanto " + nm + " por hierro como el Sol" : "as much " + nm + " per iron as the Sun";
   if (v > 0) return E ? (p >= 2 ? ccDec(p, 1, "es") + " veces más " + nm + " por hierro que el Sol" : "un " + Math.round(100 * (p - 1)) + " % más " + nm + " por hierro que el Sol") : (p >= 2 ? ccDec(p, 1, "en") + " times more " + nm + " per iron than the Sun" : Math.round(100 * (p - 1)) + "% more " + nm + " per iron than the Sun");
   return E ? "un " + Math.round(100 * (1 - p)) + " % menos " + nm + " por hierro que el Sol" : Math.round(100 * (1 - p)) + "% less " + nm + " per iron than the Sun";
}

function ccStarGlyph(g, x, y, s, S, sc, dim) {
   var r = ccStarRadius(s, S, sc), feh = s.chem && s.chem.feh ? s.chem.feh.v : null, elOn = ccElemOn(S), eq = elOn ? ccElemOf(s, S.elem) : null;
   var val = elOn ? (eq ? eq.v : null) : feh, liM = ccLiMode(S), liUl = liM && !eq && !!ccLiOf(s);
   var rgb = elOn ? (liM ? ccLiRgb(val) : ccElemRgb(val, ccElemRange(S))) : ccFehRgb(feh), a = dim ? 0.22 : 1, solid = elOn ? (eq ? (liM || ccSrcSolid(eq.src)) : false) : ccChemSolid(s);
   g.antialiasing = true;
   g.fillCircle(x, y, r + 1.6 * sc, ccBrush(ccInt(CC_ATLAS.bg, 0.6 * a)));
   // (litio: un límite superior = TRIÁNGULO ▽ gris hueco, del tamaño de un valor —23-oct, revisor R12: el anillo hueco chocaba con «hueco:
   //  solo Gaia» de la misma leyenda—; el mismo ▽ que en B)
   if (liUl) ccTriDown(g, x, y, r * 1.15, ccPen(ccInt(CC_ATLAS.text2, 0.9 * a), Math.max(1.2, 1.4 * sc)));
   else if (val === null) ccDisc(g, x, y, r * 0.75, null, ccInt(CC_ATLAS.text3, 0.8 * a), Math.max(1, sc));
   else if (solid) ccDisc(g, x, y, r, ccRgbInt(rgb, 0.95 * a), null);
   else ccDisc(g, x, y, r, ccRgbInt(rgb, 0.25 * a), ccRgbInt(rgb, 0.95 * a), Math.max(1, 1.1 * sc));
   if (S.opts && S.opts.contours === false) return;
   var pop = s.pop ? s.pop.label : "unknown", rr = r + 2.6 * sc, col = ccInt(CC_ATLAS.text, 0.62 * a), lw = Math.max(1, 0.9 * sc);
   if (pop === "thin") g.strokeCircle(x, y, rr, ccPen(col, lw));
   else if (pop === "thick") { g.strokeCircle(x, y, rr, ccPen(col, lw)); g.strokeCircle(x, y, rr + 2.2 * sc, ccPen(col, lw)); }
   else if (pop === "halo" || pop === "accreted") {
      g.strokeCircle(x, y, rr, ccPen(col, lw));
      var t = 4.2 * sc, off = (pop === "accreted") ? Math.PI / 4 : 0;
      g.pen = ccPen(col, Math.max(1.2, 1.2 * sc));
      for (var k = 0; k < 4; ++k) { var ang = off + k * Math.PI / 2, cx = Math.cos(ang), cy = Math.sin(ang); g.drawLine(x + cx * rr, y + cy * rr, x + cx * (rr + t), y + cy * (rr + t)); }
   }
}
// ▽: un límite superior (el litio), hueco, de «radio» k, centrado en (x, y)
function ccTriDown(g, x, y, k, pen) {
   g.antialiasing = true; g.pen = pen; ccNoBrush(g);
   g.drawPolyline([new Point(x - k, y - k * 0.6), new Point(x + k, y - k * 0.6), new Point(x, y + k), new Point(x - k, y - k * 0.6)]);
}
// El punto de un diagrama (B, C, D): solo el color de su metalicidad (la posición ya dice el resto).
function ccDot(g, x, y, s, S, sc, dim, hollow) {
   var r = ccStarRadius(s, S, sc) * 0.8, feh = s.chem && s.chem.feh ? s.chem.feh.v : null, rgb = ccFehRgb(feh), a = dim ? 0.18 : (hollow === "faint" ? 0.4 : 1);
   g.antialiasing = true;
   g.fillCircle(x, y, r + 1.2 * sc, ccBrush(ccInt(CC_ATLAS.bg, 0.6 * a)));
   if ((hollow && hollow !== "faint") || !ccChemSolid(s)) ccDisc(g, x, y, r, ccRgbInt(rgb, 0.2 * a), ccRgbInt(rgb, 0.9 * a), Math.max(1, 1.1 * sc));
   else ccDisc(g, x, y, r, ccRgbInt(rgb, 0.92 * a), null);
}
// Un punto FUERA de la escala: un triangulito en el borde que apunta hacia fuera.
function ccEdgeMark(g, x, y, dir, s, sc, rgbIn) {
   var rgb = rgbIn || ccFehRgb(s.chem && s.chem.feh ? s.chem.feh.v : null), k = 4 * sc, pts;
   if (dir === "l") pts = [new Point(x - k, y), new Point(x + k * 0.6, y - k), new Point(x + k * 0.6, y + k)];
   else if (dir === "r") pts = [new Point(x + k, y), new Point(x - k * 0.6, y - k), new Point(x - k * 0.6, y + k)];
   else if (dir === "t") pts = [new Point(x, y - k), new Point(x - k, y + k * 0.6), new Point(x + k, y + k * 0.6)];
   else pts = [new Point(x, y + k), new Point(x - k, y - k * 0.6), new Point(x + k, y - k * 0.6)];
   g.antialiasing = true;
   g.brush = ccBrush(ccRgbInt(rgb, 0.85));
   g.pen = ccPen(ccInt(CC_ATLAS.bg), 1);
   g.fillPolygon(pts);
   ccNoBrush(g);
}
// El anillo de la elegida (con el pulso) y el de la que está bajo el ratón. El ORO es SOLO de la elegida.
function ccSelRing(g, x, y, s, S, sc, isSel) {
   var r = ccStarRadius(s, S, sc) + 6 * sc;
   g.antialiasing = true;
   if (isSel) {
      var p = (S.anim && ccIsNum(S.anim.sel)) ? S.anim.sel : 1, e = ccEase(p);
      var rr = r + (1 - e) * 22 * sc;
      g.strokeCircle(x, y, rr, ccPen(ccInt(CC_ATLAS.gold, 0.35 + 0.65 * e), Math.max(1.5, 2 * sc)));
      var q = (S.anim && ccIsNum(S.anim.pulse)) ? S.anim.pulse : 0;
      g.strokeCircle(x, y, r + q * 10 * sc, ccPen(ccInt(CC_ATLAS.goldLight, 0.45 * (1 - q)), Math.max(1, sc)));
   } else {
      g.strokeCircle(x, y, r - 1.5 * sc, ccPen(ccInt(CC_ATLAS.text, 0.85), Math.max(1, sc)));
   }
}
// El Sol de referencia: crema (no oro: el oro es de la elegida) y rotulado.
// `plate` (23-oct, revisor R12: «Sol» ilegible en la nube del litio): una placa oscura detrás del rótulo
function ccSunSymbol(g, x, y, sc, noLabel, avoid, plate) {
   g.antialiasing = true;
   g.strokeCircle(x, y, 4.5 * sc, ccPen(ccInt(CC_ATLAS.text, 0.9), Math.max(1, 1.1 * sc)));
   g.fillCircle(x, y, 1.3 * sc, ccBrush(ccInt(CC_ATLAS.text, 0.9)));
   if (noLabel) return;
   var f = ccFont("display", 8.4 * sc, false, true), t = ccT("sunLabel"), tw = f.width(t);
   // el rótulo, a la derecha; si choca con el anillo de la elegida (`avoid`), a la izquierda; si también, sin rótulo
   function hits(x0) { if (!avoid) return false; var r = 18 * sc, cx = Math.max(x0, Math.min(x0 + tw, avoid.x)), cy = Math.max(y - 14 * sc, Math.min(y - 3 * sc, avoid.y)); return (cx - avoid.x) * (cx - avoid.x) + (cy - avoid.y) * (cy - avoid.y) < r * r; }
   var xr = x + 7 * sc, xl = x - 7 * sc - tw, xs = !hits(xr) ? xr : (!hits(xl) ? xl : null);
   if (xs === null) return;
   if (plate) { g.fillRoundedRect(xs - 3 * sc, y - 5 * sc - f.ascent - 1 * sc, xs + tw + 3 * sc, y - 5 * sc + f.descent + 1 * sc, 30, 60, ccBrush(ccInt(CC_ATLAS.bg, 0.82))); ccNoBrush(g); }
   ccHaloText(g, f, ccInt(CC_ATLAS.text, 0.9), xs, y - 5 * sc, t, sc);
}
// Dónde cae en pantalla la estrella elegida de un diagrama (para que los rótulos la esquiven).
function ccSelXY(S, P, get) {
   if (!S.res || !(S.sel >= 0)) return null;
   var v = get(S.res.stars[S.sel]);
   if (!v) return null;
   return { x: P.X(ccClamp(v.x, Math.min(P.x0, P.x1), Math.max(P.x0, P.x1))), y: P.Y(ccClamp(v.y, P.y0, P.y1)) };
}
// Un rótulo de región en el hueco con MENOS puntos de entre sus candidatos (en orden de preferencia); con placa
// solo si no queda ningún hueco libre. (Antes iban debajo de los puntos y quedaban ilegibles: revisor, 15-oct.)
// (22-oct, revisor visual: «DISCO GRUESO» y «DISCO FINO» tapados por los puntos) Si ningún candidato está libre, se busca hueco
// en una REJILLA a lo largo de las filas de los candidatos (pasos de 1/24 del ancho); y se pinta SIEMPRE con halo, encima.
// (23-oct, revisor R7: «DISCO GRUESO · α ALTO» se iba a la región del HALO cuando no cabía en la suya) `xr` = [x0, x1] en px: la REGIÓN
// del rótulo; ni los candidatos ni la rejilla salen de ella; si en ella no hay hueco, va en el sitio con menos puntos de SU región, con
// halo y encima. Devuelve { x, y, w } (lo pintado).
function ccPlaceLabel(g, f, color, text, cands, scr, P, sc, xr) {
   var tw = f.width(text), th = 9 * sc, pad = 5 * sc, best = null, bn = 1e9, i, k;
   var rx0 = Math.max(P.L + 4 * sc, (xr && !ccPBroken("regionfree")) ? xr[0] : -1e9), rx1 = Math.min(P.L + P.pw - 4 * sc, (xr && !ccPBroken("regionfree")) ? xr[1] : 1e9);
   if (rx1 - rx0 < tw) { rx0 = Math.max(P.L + 4 * sc, Math.min(rx0, rx1 - tw)); }
   function count(x, y) { var n = 0; for (var k2 = 0; k2 < scr.length; ++k2) { var p = scr[k2]; if (p[0] > x - pad && p[0] < x + tw + pad && p[1] > y - th - pad && p[1] < y + pad) ++n; } return n; }
   function clampXY(c) { return [Math.max(rx0, Math.min(rx1 - tw, c[0])), Math.max(P.T + th + 3 * sc, Math.min(P.T + P.ph - 4 * sc, c[1]))]; }
   for (i = 0; i < cands.length && bn > 0; ++i) { var c = clampXY(cands[i]), n = count(c[0], c[1]); if (n < bn) { bn = n; best = c; } }
   if (bn > 0) {
      // (en la rejilla, a igual ocupación gana el sitio más cercano al candidato preferido: no salta al otro extremo)
      var rows = [], c0 = clampXY(cands[0]), bd = 1e9; for (i = 0; i < cands.length; ++i) { var cy = clampXY(cands[i])[1]; if (rows.indexOf(cy) < 0) rows.push(cy); }
      for (i = 0; i < rows.length; ++i) for (k = 0; k <= 24; ++k) {
         var gx = rx0 + Math.max(0, rx1 - rx0 - tw) * k / 24, nn = count(gx, rows[i]), dd = Math.abs(gx - c0[0]) + Math.abs(rows[i] - c0[1]);
         if (nn < bn || (nn === bn && dd < bd)) { bn = nn; bd = dd; best = [gx, rows[i]]; }
      }
   }
   if (!best) return null;
   ccHaloText(g, f, color, best[0], best[1], text, sc);
   // el sitio que ocupa, para los rótulos que vengan detrás (no se pisan entre ellos)
   for (var ox = best[0] - pad; ox <= best[0] + tw + pad; ox += 3 * sc) for (var oy = best[1] - th - pad; oy <= best[1] + pad; oy += 3 * sc) scr.push([ox, oy]);
   return { x: best[0], y: best[1], w: tw, under: bn };
}
function ccStarName(s) {
   if (s.hip > 0 && s.hipLabel) return String(s.hipLabel);       // (27-oct, D4) el nombre de Hipparcos, como Cabra3D (ccHipFill, abajo)
   if (s.id) return "Gaia DR3 " + s.id;
   if (s.name) return s.name;
   return ccFmtL(s.ra, 4) + " " + ccFmtSignedL(s.dec, 4);
}
// ---------------------------------------------------------------------------
// EL NOMBRE DE LA FICHA ES UN ENLACE A SIMBAD (26-oct-2026, propagado desde Cabra3D/src/ui/star_link.js; lo puro —URL y abrir— en
// CabraShared/csh_link.js). Un clic en el nombre abre SIMBAD. (3-nov-2026, CPD) Con csh_web.js incluido (StellarChemistry lo incluye), en el
// navegador que trae PixInsight (Dialog.openBrowser); Aladin (WebGL) y la reserva, en el del sistema de cada plataforma (rundll32 / open / xdg-open).
// El identificador, con el criterio de Cabra3D (c3SimbadIdentOfStar): nombre IAU de Hipparcos → «HIP n» → «Gaia DR3 id» → coordenadas.
// (27-oct-2026, D4) Los dos primeros, con el catálogo Hipparcos de CabraShared (csh_hipnames.js, el MISMO casado que Cabra3D): `ccHipFill`
// pone en cada estrella brillante (G ≤ 9,5) `s.hip`, `s.hipName` (IAU) y `s.hipLabel` (el de la ficha: IAU > Bayer/Flamsteed > «HIP n»);
// sin csh_hipnames.js (CabraStarAnalysis lo incluye, pero no llama a ccHipFill) quedan «Gaia DR3 <s.id>» y las coordenadas.
// `s.name` (el identificador de GALAH, APOGEE o LAMOST) NO se usa: no es del criterio. Sin csh_link.js incluido (CabraStarAnalysis incluye este fichero y no lo incluye) no hay
// enlace: la ficha sale como antes.
// Costuras (las pruebas): CC_LINK_HOOK = function(url) la recoge; con CC_NO_MAIN no abre nada salvo CC_LINK_REAL = true;
// CC_LINK_BREAK (rojos) = "nolink" (sin enlace) · "url" (sin codificar) · "noopen" (el clic no abre).
var CC_LINK_HOOK = null, CC_LINK_REAL = false, CC_LINK_BREAK = "", CC_TIP_UNDER = false;
function ccLinkBroken(k) { return (typeof CC_LINK_BREAK === "string") && CC_LINK_BREAK.length > 0 && CC_LINK_BREAK.indexOf(k) >= 0; }
function ccLinkOn() { return typeof cshSimbadIdUrl === "function" && typeof cshOpenUrl === "function"; }
function ccSimbadIdentOf(s) {
   if (s && s.hip > 0) return (s.hipName && String(s.hipName).length > 0) ? String(s.hipName) : "HIP " + s.hip;
   return (s && s.id) ? "Gaia DR3 " + s.id : "";
}
// LOS NOMBRES DE HIPPARCOS de las estrellas de un resultado (27-oct-2026, D4): solo las brillantes (G ≤ 9,5, las únicas que pueden casar) y
// solo las que aún no lo tienen (los resultados parciales llegan varias veces); el catálogo se lee una vez por sesión. Lo que tarda, en
// res.hipFill { tried, matched, named, ms, loadMs }. CC_HIP_FILL = false: el rojo de las pruebas (sin nombres de Hipparcos).
var CC_HIP_FILL = true;
function ccHipFill(res) {
   var st = (res && res.stars) ? res.stars : [], out = { tried: 0, matched: 0, named: 0, ms: 0, loadMs: 0 }, t0 = Date.now();
   if (CC_HIP_FILL !== true || typeof cshHipLookup !== "function") { if (res) res.hipFill = out; return out; }
   var cached = (typeof CSH_HIPDATA !== "undefined" && CSH_HIPDATA !== null);
   for (var i = 0; i < st.length; ++i) {
      var s = st[i];
      if (s.hip !== undefined) continue;
      s.hip = 0; s.hipName = ""; s.hipLabel = "";
      if (!(ccIsNum(s.g) && s.g <= CSH_HIP.FIELD_GMAX_MATCH) || !ccIsNum(s.ra) || !ccIsNum(s.dec)) continue;
      if (out.tried === 0 && !cached) { var tl = Date.now(); cshHipData(); out.loadMs = Date.now() - tl; }
      ++out.tried;
      // (ra, dec de CabraComposition = RA_ICRS / DE_ICRS de Gaia DR3, época J2016,0: la del casado)
      var r = cshHipLookup(s.ra, s.dec, s.g, ccIsNum(s.bpRp) ? s.bpRp : NaN);
      if (r.hip > 0) { s.hip = r.hip; s.hipName = r.iau; s.hipLabel = r.name; ++out.matched; if (r.iau) ++out.named; }
   }
   out.ms = Date.now() - t0;
   if (res) res.hipFill = out;
   return out;
}
// { text, ident, url } o null. `text` = lo que se enseña (ccStarName).
function ccLinkOfStar(s, text) {
   if (!s || !ccLinkOn() || ccLinkBroken("nolink")) return null;
   var ident = ccSimbadIdentOf(s);
   // (27-oct) las que no son de Hipparcos pueden no estar en SIMBAD: cshLinkFallback apunta el registro de Gaia para ellas (se decide al clic)
   if (ident.length > 0) return cshLinkFallback({ text: String(text), ident: ident, url: cshSimbadIdUrl(ident, CC_LINK_BREAK) }, { ra: s.ra, dec: s.dec });
   if (ccIsNum(s.ra) && ccIsNum(s.dec)) return cshLinkFallback({ text: String(text), ident: ccFmtL(s.ra, 4) + " " + ccFmtSignedL(s.dec, 4), url: cshSimbadCooUrl(s.ra, s.dec) }, { ra: s.ra, dec: s.dec });
   return null;
}
function ccOpenUrl(url) {
   if (!ccLinkOn()) return { ok: false, url: String(url), via: "", why: "csh_link.js sin incluir" };
   return cshOpenUrl(url, { hook: CC_LINK_HOOK, real: CC_LINK_REAL, noMain: (typeof CC_NO_MAIN !== "undefined" && CC_NO_MAIN) ? true : false, broken: CC_LINK_BREAK });
}
// (27-oct, D3) el texto del aviso, con el criterio común (CabraShared/csh_link.js cshLinkTipText): sin repetir el id si es el nombre que se ve
function ccLinkTip(L) { return (typeof cshLinkTipText === "function") ? cshLinkTipText(ccT("openSimbad"), L) : ccT("openSimbad") + ": " + L.ident; }
// Pinta el nombre como enlace (oro —oro claro con el ratón encima—, subrayado, icono de «abrir fuera»). Devuelve su rectángulo (lo clicable).
// (copia adaptada de c3LinkPaintName de Cabra3D/src/ui/star_link.js)
function ccLinkPaintName(g, font, x, by, L, maxW, sc, hot, alpha) {
   var a = (alpha === undefined) ? 1 : alpha, col = ccInt(hot ? CC_ATLAS.goldLight : CC_ATLAS.gold, a);
   var s = Math.max(6, Math.round(font.ascent * 0.62)), gap = Math.round(5 * sc), room = maxW - s - gap - Math.round(2 * sc);
   var txt = ccElide(font, L.text, Math.max(Math.round(20 * sc), room)), w = font.width(txt);
   ccTextAt(g, font, col, x, by, txt);
   var lw = Math.max(1, Math.round(sc)), uy = by + Math.max(2, Math.round(2 * sc)), P = new Pen(col, lw);
   g.pen = P;
   g.drawLine(x, uy, x + w, uy);
   var ix = x + w + gap, iy = by - s, k3 = Math.round(s * 0.30);
   g.drawLine(ix, iy + k3, ix, iy + s); g.drawLine(ix, iy + s, ix + s - k3, iy + s);
   g.drawLine(ix + s - k3, iy + s, ix + s - k3, iy + Math.round(s * 0.55));
   g.drawLine(ix + k3, iy + Math.round(s * 0.70), ix + s, iy);
   g.drawLine(ix + Math.round(s * 0.50), iy, ix + s, iy); g.drawLine(ix + s, iy, ix + s, iy + Math.round(s * 0.50));
   return { x0: x, y0: by - font.ascent, x1: ix + s + Math.round(2 * sc), y1: uy + Math.round(2 * sc), shown: txt };
}
// La etiqueta flotante de la estrella bajo el ratón, con la cifra traducida.
function ccHoverLabel(g, x, y, s, w, h, sc, S) {
   var f = ccFont("text", 9 * sc), fm = ccFont("mono", 9 * sc), fi = ccFont("text", 8.4 * sc, false, true);
   var t1 = ccStarName(s), eq = ccElemOn(S) ? ccElemOf(s, S.elem) : null;
   var liH = ccLiMode(S) ? ccLiOf(s) : null;
   var t2 = (ccElemOn(S) ? ccElLabel(S.elem) + " " + (liH ? (liH.ul ? "≤ " : "") + ccFmtL(liH.v, 2) : (eq ? ccFmtSignedL(eq.v) : "—")) + "  ·  " : "") + "[Fe/H] " + (s.chem.feh ? ccFmtSignedL(s.chem.feh.v) : "—") + (s.age.adopted ? "  ·  " + ccFmtL(s.age.adopted.v, 1) + " " + ccAgeUnit(CC_LANG) : "");
   var t3 = ccElemOn(S) ? (liH ? "= " + ccLiPlain(liH, CC_LANG) : eq ? "= " + ccElemPlain(eq.v, S.elem, CC_LANG) : ccT("legNoVal") + " (" + ccElLabel(S.elem) + ")") : (s.chem.feh ? "= " + ccFehPlain(s.chem.feh.v, CC_LANG) : ccT("noData"));
   var tw = Math.max(f.width(t1), fm.width(t2), fi.width(t3)) + 16 * sc, th = 50 * sc;
   var bx = x + 12 * sc, by = y - th - 8 * sc;
   if (bx + tw > w - 4) bx = x - tw - 12 * sc;
   if (by < 4) by = y + 12 * sc;
   g.fillRoundedRect(bx, by, bx + tw, by + th, 12, 20, ccBrush(ccInt(CC_ATLAS.surface2, 0.96)));
   ccNoBrush(g); g.pen = ccPen(ccInt(CC_ATLAS.line), 1); g.drawRoundedRect(bx, by, bx + tw, by + th, 12, 20);
   ccTextAt(g, f, ccInt(CC_ATLAS.text), bx + 8 * sc, by + 15 * sc, t1);
   ccTextAt(g, fm, ccInt(CC_ATLAS.text2), bx + 8 * sc, by + 29 * sc, t2);
   ccTextAt(g, fi, ccInt(CC_ATLAS.goldLight), bx + 8 * sc, by + 43 * sc, t3);
}

// ---------------------------------------------------------------------------
// A · LA FOTO
// ---------------------------------------------------------------------------
// El hueco de la foto en el panel A: debajo de la frase llana y encima de la leyenda (sin franjas muertas).
function ccPhotoBox(S, w, h, sc) {
   if (S && S.compact) return ccPhotoBoxCompact(S, w, h, sc);
   var capKey = ((S.photo && S.photo.bitmap) || !S.res) ? "capA" : "capANoPhoto";
   var fc = ccFont("text", 8.6 * sc, false, true), capLines = 0, keys = (capKey === "capA") ? ["capA", "capAPhoto"] : [capKey];
   for (var kk = 0; kk < keys.length; ++kk) { var cw0 = Math.min(w - 40 * sc, fc.width(ccT(keys[kk])) + 30 * sc); capLines = Math.max(capLines, ccWrap(fc, ccT(keys[kk]), cw0 - 20 * sc).length); }
   var y0 = 33 * sc + capLines * 13 * sc + 8 * sc + (S.photoNote ? 21 * sc : 0) + 6 * sc;
   var LD = ccPhotoLegendDims(w, sc), mB = (S.photo && S.photo.bitmap) ? ccEaseInOut(ccPhotoMix(S)) : 1;
   var y1 = h - 8 * sc - (LD.noteH + (LD.plateH - LD.noteH) * mB) - 6 * sc;
   if (y1 - y0 < h * 0.3) { y0 = 0; y1 = h; }       // panel diminuto: la foto entera, bajo las placas
   return { y0: y0, y1: y1 };
}
// (CabraComposition, 22-oct) Bajo la placa del título (la frase va a su «?»). Si la foto entera no llena el hueco y
// sobrarían bandas arriba y abajo (no se puede recortar: perdería > 20 %), el hueco se CIÑE a la foto: sube bajo el título y la
// leyenda va pegada debajo (`legY`), no al fondo del panel. Revisor visual del 22-oct.
// (23-oct · R9) CC_LEG_FOOT: lo que queda bajo la leyenda hasta el pie del panel (2 lógicos; eran 8 cuando el panel llegaba al pie
// de la ventana: ahora debajo va la línea de tiempo, a LEFT_GAP)
var CC_LEG_FOOT = 2;
function ccPhotoBoxCompact(S, w, h, sc) {
   var y0 = 36 * sc, LD = ccPhotoLegendDims(w, sc), mB = (S.photo && S.photo.bitmap) ? ccEaseInOut(ccPhotoMix(S)) : 1;
   var legH = LD.noteH + (LD.plateH - LD.noteH) * mB, y1 = h - CC_LEG_FOOT * sc - legH - 6 * sc;
   if (y1 - y0 < h * 0.3) return { y0: 0, y1: h, legY: h - CC_LEG_FOOT * sc - legH };
   var out = { y0: y0, y1: y1, legY: y1 + 6 * sc };
   if (ccPhotoField(S)) {
      var F = ccPhotoField(S), bh = y1 - y0, sIn = Math.min(w / F.width, bh / F.height), sOut = Math.max(w / F.width, bh / F.height);
      var tFill = ccClamp((0.30 - (1 - sIn / sOut)) / 0.10, 0, 1), base = sIn + (sOut - sIn) * tFill, ph = F.height * base;
      if (ph < bh - 1) { out.y1 = y0 + ph; out.legY = out.y1 + 6 * sc; }
   }
   return out;
}
// (23-oct · R9) El alto que pide el panel de la foto (compacto) para enseñar la foto ENTERA a su ancho w: el título, la foto y la
// leyenda colgando debajo (la placa entera, la de «Composición»: así el alto no cambia al pasar a «Foto real»). 0 sin encuadre.
// Lo usa cc_dialog.js (D.fitLeft) para dar a la línea de tiempo, bajo la foto, lo que sobre. Es la cuenta inversa de ccPhotoBoxCompact.
function ccPhotoNeedH(S, w, sc) {
   var F = ccPhotoField(S);
   if (!F || !(F.width > 0) || !(F.height > 0) || !(w > 0)) return 0;
   var LD = ccPhotoLegendDims(w, sc);
   return Math.ceil(36 * sc + w * F.height / F.width + 6 * sc + LD.plateH + CC_LEG_FOOT * sc);
}
// Encaje: LLENA el hueco (recortando el eje largo) si así se pierde como mucho un 20 %; si no, la foto entera.
// kMin = el zoom que enseña el encuadre entero (doble clic).
// El encuadre de la foto: el del resultado o, sin analizar (la vista previa del 22-oct, noche), el tamaño de la imagen (S.frame).
function ccPhotoField(S) { return (S && S.res && S.res.field) ? S.res.field : ((S && S.frame) ? S.frame : null); }
function ccPhotoXf(S, w, h, sc) {
   var F = ccPhotoField(S), iw = F ? F.width : 1, ih = F ? F.height : 1;
   var B = ccPhotoBox(S, w, h, sc || ccScale()), bh = Math.max(10, B.y1 - B.y0);
   var sIn = Math.min(w / iw, bh / ih), sOut = Math.max(w / iw, bh / ih), tFill = ccClamp((0.30 - (1 - sIn / sOut)) / 0.10, 0, 1), base = sIn + (sOut - sIn) * tFill;
   var z = S.zoom || { k: 1, cx: iw / 2, cy: ih / 2 };
   var s = base * z.k, cy0 = (B.y0 + B.y1) / 2;
   return {
      s: s, iw: iw, ih: ih, kMin: sIn / base, box: B,
      toScr: function(x, y) { return { x: w / 2 + (x - z.cx) * s, y: cy0 + (y - z.cy) * s }; },
      toImg: function(X, Y) { return { x: z.cx + (X - w / 2) / s, y: z.cy + (Y - cy0) / s }; }
   };
}
// QUÉ PASÓ con las consultas, en grande sobre la foto (sin estrellas con datos) o en una franja (faltan algunas).
// Con la base Gaia local, sin red se pintan además las estrellas del encuadre (anillos neutros: sin química).
function ccStatusOverlay(g, w, h, S, sc, X) {
   var T = ccStatusText(S.res, CC_LANG), list = S.list || [], E = CC_LANG === "es", i;
   if (!T) return;
   if (list.length === 0 && S.res.gaiaField && S.res.gaiaField.length) {
      g.antialiasing = true;
      for (i = 0; i < S.res.gaiaField.length; ++i) { var gf = S.res.gaiaField[i], q = X.toScr(gf.x, gf.y); if (q.x < -5 || q.y < -5 || q.x > w + 5 || q.y > h + 5) continue; g.strokeCircle(q.x, q.y, Math.max(2, (17.5 - gf.g) * 0.55 * sc), ccPen(ccInt(CC_ATLAS.text3, 0.75), Math.max(1, 0.8 * sc))); }
   }
   var B = X.box, fT = ccFont("display", (list.length ? 11 : 15) * sc, false, true), fB = ccFont("text", 9.4 * sc);
   var col = T.error ? CC_ATLAS.warn : CC_ATLAS.text2, maxW = Math.min(w - 48 * sc, 560 * sc);
   if (list.length === 0) {
      // en grande, en el centro
      var tl = ccWrap(fT, T.title, maxW), bl = ccWrap(fB, T.body, maxW), hh = tl.length * 20 * sc + 8 * sc + bl.length * 15 * sc + 10 * sc;
      var y0 = Math.max(B.y0 + 10 * sc, (B.y0 + B.y1) / 2 - hh / 2), x0 = (w - maxW) / 2 - 16 * sc;
      g.fillRoundedRect(x0, y0 - 12 * sc, x0 + maxW + 32 * sc, y0 + hh + 6 * sc, 6, 10, ccBrush(ccInt(CC_ATLAS.bg, 0.93)));
      ccNoBrush(g); g.pen = ccPen(ccInt(col, 0.7), 1); g.drawRoundedRect(x0, y0 - 12 * sc, x0 + maxW + 32 * sc, y0 + hh + 6 * sc, 6, 10);
      var y = y0 + 8 * sc;
      for (i = 0; i < tl.length; ++i) { ccTextAt(g, fT, ccInt(col), (w - fT.width(tl[i])) / 2, y, tl[i]); y += 20 * sc; }
      y += 6 * sc;
      for (i = 0; i < bl.length; ++i) { ccTextAt(g, fB, ccInt(CC_ATLAS.text2), (w - fB.width(bl[i])) / 2, y, bl[i]); y += 15 * sc; }
   } else {
      // faltan algunas: una franja arriba de la foto (el texto entero, en su ayuda)
      var line = T.title + " · " + T.body, fl = ccFont("text", 8.6 * sc, false, true);
      var lw = Math.min(w - 40 * sc, fl.width(line)), yb = B.y0 + 6 * sc;
      g.fillRoundedRect(8 * sc, yb, 8 * sc + lw + 16 * sc, yb + 22 * sc, 12, 40, ccBrush(ccInt(CC_ATLAS.bg, 0.94)));
      ccTextAt(g, fl, ccInt(CC_ATLAS.warn), 16 * sc, yb + 15 * sc, ccElide(fl, line, lw));
      ccHit(S, "A", 8 * sc, yb, 16 * sc + lw, yb + 22 * sc, line);
   }
   // («Reintentar» ya no se pinta aquí: es el botón «↻ Retry» de la barra de estado, a la derecha, el mismo sitio siempre)
}
// (30-oct-2026, Nino: los cuatro iguales) EL CONMUTADOR «Real photo | Stars»: arranca en «Real photo» y recuerda la ultima eleccion (CabraShared/csh_viewpref.js).
// ¿Hay algo que pintar sobre la foto? Los resultados del analisis o, antes de ellos, las estrellas de la vista previa de la base Gaia local. Sin
// nada de eso, «Stars» (recordado o elegido) no cambia la foto: se ve limpia, y el conmutador no se ofrece.
function ccAViewHas(S) { return !!(S.res || (S.gaiaPreview && S.gaiaPreview.pts && S.gaiaPreview.pts.length > 0)); }
// La vista que se pinta de verdad: la elegida, o la foto limpia si no hay nada que pintar encima.
// (31-oct-2026, Nino) "compare": la tercera pildora, una cortinilla (a la izquierda la foto, a la derecha la composicion).
function ccAViewEff(S) { return (S.aView === "photo" || !ccAViewHas(S)) ? "photo" : (S.aView === "compare") ? "compare" : "comp"; }
// ¿Es una prueba? (CC_NO_MAIN es una directiva #define de CabraComposition.js: 0 o 1; en las pruebas no se lee ni se escribe lo recordado)
function ccVpNoMain() { return (typeof CC_NO_MAIN !== "undefined" && CC_NO_MAIN) ? true : false; }
// Cuánto se ve de la composición (0 = la foto tal cual, 1 = composición). Sin foto, siempre composición.
function ccPhotoMix(S) {
   if (!(S.photo && S.photo.bitmap)) return 1;
   if (S.anim && ccIsNum(S.anim.aMix)) return ccClamp(S.anim.aMix, 0, 1);
   return ccAViewEff(S) === "photo" ? 0 : 1;
}
function ccPaintPhoto(g, w, h, S, sc, part) {
   var X = ccPhotoXf(S, w, h, sc), i, mix = ccPhotoMix(S), em = ccEaseInOut(mix), hasPhoto = !!(S.photo && S.photo.bitmap);
   if (part !== "over") {
      ccHitsReset(S, "A");
      ccFillRect(g, 0, 0, w, h, ccInt(CC_INSET));
      if (S.photo && S.photo.bitmap) {
         var b = S.photo.bitmap, f = S.photo.factor;
         var p0 = X.toImg(0, 0), p1 = X.toImg(w, h);
         var sx0 = Math.max(0, p0.x * f), sy0 = Math.max(0, p0.y * f), sx1 = Math.min(b.width, p1.x * f), sy1 = Math.min(b.height, p1.y * f);
         if (sx1 > sx0 && sy1 > sy0) {
            var d0 = X.toScr(sx0 / f, sy0 / f), d1 = X.toScr(sx1 / f, sy1 / f);
            g.smoothInterpolation = true;
            g.drawScaledBitmapRect(new Rect(Math.round(d0.x), Math.round(d0.y), Math.round(d1.x), Math.round(d1.y)), b, new Rect(Math.floor(sx0), Math.floor(sy0), Math.ceil(sx1), Math.ceil(sy1)));
         }
         // (31-oct) «Compare»: el velo y las estrellas, solo a la derecha de la linea
         S.aCurtainX = (ccAViewEff(S) === "compare") ? Math.round(w * cshCurtainClamp(ccIsNum(S.aSplit) ? S.aSplit : 0.5)) : null;
         if (S.aCurtainX !== null) g.clipRect = new Rect(S.aCurtainX, 0, w, h);
         // velo NEGRO (oscurece; el del color del fondo levantaba los negros: revisor visual)
         if (em > 0.004) ccFillRect(g, 0, 0, w, h, ccInt("#000000", 0.18 * em));
      } else {
         var a = X.toScr(0, 0), c = X.toScr(X.iw, X.ih);
         ccFillRect(g, a.x, a.y, c.x, c.y, ccInt(CC_ATLAS.bg));
         g.pen = ccPen(ccInt(CC_LINE_STRONG, 0.7), 1);
         for (i = 1; i < 6; ++i) { var gx = a.x + (c.x - a.x) * i / 6, gy = a.y + (c.y - a.y) * i / 6; g.drawLine(gx, a.y, gx, c.y); g.drawLine(a.x, gy, c.x, gy); }
         g.drawRect(a.x, a.y, c.x, c.y);
      }
      // (22-oct, noche) sin estrellas con datos todavía (la vista previa, o lo parcial de antes de los surveys): las estrellas G<17 de la
      // base Gaia local, en anillos neutros (lo mismo que ccStatusOverlay pinta sin red)
      var gpts = (!S.res || (S.res.partial && !(S.list || []).length)) ? ((S.res && S.res.gaiaField && S.res.gaiaField.length) ? S.res.gaiaField : (S.gaiaPreview ? S.gaiaPreview.pts : null)) : null;
      if (gpts && gpts.length && em > 0.004) {
         g.opacity = em; g.antialiasing = true;
         for (i = 0; i < gpts.length; ++i) { var gf = gpts[i], gq = X.toScr(gf.x, gf.y); if (gq.x < -5 || gq.y < -5 || gq.x > w + 5 || gq.y > h + 5) continue; g.strokeCircle(gq.x, gq.y, Math.max(2, (17.5 - gf.g) * 0.55 * sc), ccPen(ccInt(CC_ATLAS.text3, 0.75), Math.max(1, 0.8 * sc))); }
         g.opacity = 1;
      }
      if (S.res && em > 0.004) {
         var list = ccPhotoList(S), st = S.res.stars;
         g.opacity = em;
         for (var pass = 0; pass < 2; ++pass) for (i = 0; i < list.length; ++i) {
            var s = st[list[i]];
            var inG = S.group ? !!S.group[s.idx] : true;
            if (S.group && (pass === 0) === inG) continue;
            if (!S.group && pass === 1) continue;
            var q = X.toScr(s.x, s.y);
            if (q.x < -20 || q.y < -20 || q.x > w + 20 || q.y > h + 20) continue;
            ccStarGlyph(g, q.x, q.y, s, S, sc, S.group ? !inG : false);
         }
         g.opacity = 1;

      }
      if (hasPhoto && S.aCurtainX !== null && S.aCurtainX !== undefined) { g.clipRect = new Rect(0, 0, w, h); var cL14 = ccPhotoLegendDims(w, sc); cshCurtainPaint(g, S.aCurtainX, 0, S.compact ? ccPhotoBox(S, w, h, sc).legY : h - 8 * sc - cL14.plateH, 0, w, sc, ccT("aPhoto"), ccT("aComp")); }   // (la linea y sus rotulos acaban encima de la leyenda: debajo se transparentaban)
      if (S.res) ccStatusOverlay(g, w, h, S, sc, X);
      ccPhotoLegend(g, w, h, S, sc, hasPhoto ? em : 1);
      // (IV · Elementos: con un elemento que no es Fe, el título y su «?» dicen [X/Fe] —texto literal: ccT devuelve la clave si no la conoce—)
      var elA = ccElemOn(S), elLab = elA ? ccElLabel(S.elem) : "";
      var tEnd = ccPanelTitle(g, Math.round(16 * sc), Math.round(24 * sc), hasPhoto || !S.res ? (hasPhoto && mix < 0.5 ? ccT("panelAPhoto") : (elA ? ccT("panelAEl").replace("%1", elLab) : ccT("panelA"))) : ccT("noPhotoA"), sc, true);
      // el conmutador FOTO REAL | ESTRELLAS (solo si hay foto: sin ella no hay nada que alternar). (30-oct-2026, Nino: «los cuatro iguales») El dibujo y la
      // geometria son los comunes de CabraShared/csh_pills.js, los mismos de CabraStars, Cabra3D y CabraStarAnalysis; aqui se pinta sobre el lienzo y
      // cada pildora lleva su zona de clic (ccHit). La clave interna sigue siendo "comp" (S.aView, Settings aView).
      // (30-oct) SE QUEDA en la banda del titulo, no sobre la foto (decision de Nino: sobre la foto taparia el aviso de datos). Ademas gana lo que tienen los otros tres:
      // el resaltado dorado de la otra pildora al pasar el raton (`S.aHover`, lo pone el onMouseMove del panel A) y su tooltip propio (la zona de clic lleva el texto).
      if (hasPhoto && ccAViewHas(S)) {
         var GA = cshPillsGeom(["photo", "comp", "compare"], function(k) { return ccT(k === "photo" ? "aPhoto" : (k === "compare") ? "aCompare" : "aComp"); }, sc), pxA = w - CSH_PILLS.RIGHT * sc - GA.w, curA = (S.aView === "photo" || S.aView === "compare") ? S.aView : "comp";
         cshPillsPaint(g, GA, curA, { x: pxA, y: CSH_PILLS.TOP * sc, hover: (ccPBroken("nohover") ? "" : (S.aHover || "")), text: function(gg, ff, col, tx, ty, lab) { ccTextAt(gg, ff, col, tx, ty, lab); } });
         ccNoBrush(g);      // (como lo dejaba el dibujo de antes: el codigo que sigue da por hecho que no hay pincel)
         var tipAV = ccPBroken("notip") ? "" : ccT(curA === "photo" ? "aViewTipOff" : (curA === "compare") ? "aViewTipCmp" : "aViewTipOn");
         for (i = 0; i < GA.pills.length; ++i) ccHit(S, "A", pxA + GA.pills[i].x0, CSH_PILLS.TOP * sc, pxA + GA.pills[i].x1, (CSH_PILLS.TOP + CSH_PILLS.H) * sc, tipAV, "aview", GA.pills[i].key);
      }
      // la frase llana, sobre placa opaca (compacto: en el «?» del título)
      var capKey = (hasPhoto || !S.res) ? (hasPhoto && mix < 0.5 ? "capAPhoto" : "capA") : "capANoPhoto", tipKeyA = "tipA";
      if (elA && capKey === "capA") {
         if (ccLiMode(S)) { capKey = ccT("capALi"); tipKeyA = ccT("liGloss") + " " + ccElChannel("Li", CC_LANG).long; }
         else { capKey = ccT("capAEl").replace("%1", elLab).replace("%2", ccElName(S.elem, CC_LANG)); tipKeyA = ccT("elemGloss").replace("%1", elLab).replace("%2", ccElName(S.elem, CC_LANG)) + " " + ccElChannel(S.elem, CC_LANG).long; }
      }
      if (S.compact) { ccTitleHelp(g, tEnd + 12 * sc, Math.round(24 * sc), sc, S, "A", capKey, tipKeyA, true); return; }
      var fc = ccFont("text", 8.6 * sc, false, true), capW = Math.min(w - 40 * sc, fc.width(ccT(capKey)) + 30 * sc);
      var capLines = ccWrap(fc, ccT(capKey), capW - 20 * sc).length;
      g.fillRoundedRect(8 * sc, 33 * sc, 8 * sc + capW + 10 * sc, 33 * sc + capLines * 13 * sc + 8 * sc, 12, 40, ccBrush(ccInt(CC_ATLAS.bg, 0.94)));
      ccCaption(g, 16 * sc, 46 * sc, capW, capKey, "tipA", sc, S, "A");
      if (S.photoNote) { var fN = ccFont("text", 8.4 * sc, false, true), ny = 46 * sc + capLines * 13 * sc + 8 * sc; g.fillRoundedRect(8 * sc, ny - 11 * sc, 16 * sc + fN.width(S.photoNote) + 10 * sc, ny + 5 * sc, 12, 40, ccBrush(ccInt(CC_ATLAS.bg, 0.94))); ccTextAt(g, fN, ccInt(CC_ATLAS.warn), 16 * sc, ny, ccElide(fN, S.photoNote, w - 40 * sc)); }
      return;
   }
   if (!S.res) { ccTipBubble(g, w, h, S, "A", sc); return; }
   if (S.hover >= 0 && S.hover !== S.sel) { var hs = S.res.stars[S.hover], hq = X.toScr(hs.x, hs.y); ccSelRing(g, hq.x, hq.y, hs, S, sc, false); ccHoverLabel(g, hq.x, hq.y, hs, w, h, sc, S); }
   if (S.sel >= 0) {
      var ss = S.res.stars[S.sel], sq = X.toScr(ss.x, ss.y);
      if (em > 0.004) {
         g.opacity = em;
         ccStarGlyph(g, sq.x, sq.y, ss, S, sc, false);      // la elegida, ENCIMA de sus vecinas (revisor visual)
         ccSelRing(g, sq.x, sq.y, ss, S, sc, true);
         g.opacity = 1;
      }
      if (em < 0.996) {                                     // foto real: un anillo fino y una marca corta, sin tapar la estrella
         var rr = 13 * sc;
         g.opacity = 1 - em; g.antialiasing = true;
         g.strokeCircle(sq.x, sq.y, rr, ccPen(ccInt(CC_ATLAS.gold, 0.85), Math.max(1, 1.1 * sc)));
         g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.85), Math.max(1, 1.1 * sc)); g.drawLine(sq.x + rr * 0.72, sq.y - rr * 0.72, sq.x + rr * 1.35, sq.y - rr * 1.35);
         g.opacity = 1;
      }
   }
   ccTipBubble(g, w, h, S, "A", sc);
}
// La leyenda de la foto (placa OPACA), en DOS filas: la barra de [Fe/H] y, debajo, los símbolos (cuatro
// contornos + relleno/hueco), en tantas columnas como quepan. (En una fila se salía del panel: 14-oct.)
// Las medidas de la leyenda (las usan la leyenda y el hueco de la foto: un solo cálculo).
function ccPhotoLegendDims(w, sc) {
   var f = ccFont("text", 8.4 * sc), E = CC_LANG === "es", i;
   // (23-oct, revisor R11: los nombres de la leyenda, los MISMOS que el mapa de III y el vídeo: ccPopLeg de cc_atlas.js)
   var names = [["thin", ccPopLeg("thin", CC_LANG)], ["thick", ccPopLeg("thick", CC_LANG)], ["halo", ccPopLeg("halo", CC_LANG)], ["accreted", ccPopLeg("accreted", CC_LANG)],
                ["solid", E ? "relleno: espectro desde tierra" : "filled: ground-based spectrum"], ["hollow", E ? "hueco: solo Gaia" : "hollow: Gaia only"]];
   var cellW = 0;
   for (i = 0; i < names.length; ++i) cellW = Math.max(cellW, 24 * sc + f.width(names[i][1]) + 14 * sc);
   var maxW = w - 32 * sc, perRow = Math.max(1, Math.min(names.length, Math.floor((maxW - 16 * sc) / cellW))), rows = Math.ceil(names.length / perRow);
   var bw = Math.min(220 * sc, maxW - 90 * sc);
   var plateW = Math.min(maxW, Math.max(bw + 70 * sc, perRow * cellW + 16 * sc));
   // en «foto real» la caja se encoge a la línea que dice dónde están los colores
   var fpn = ccFont("text", 8.6 * sc, false, true), noteW = Math.min(maxW, fpn.width(ccT("aPhotoNote")) + 28 * sc), noteLines = ccWrap(fpn, ccT("aPhotoNote"), noteW - 28 * sc);
   return { f: f, names: names, cellW: cellW, maxW: maxW, perRow: perRow, rows: rows, bw: bw, plateW: plateW, plateH: 46 * sc + rows * 20 * sc,
            fpn: fpn, noteW: noteW, noteLines: noteLines, noteH: 14 * sc + noteLines.length * 14 * sc };
}
function ccPhotoLegend(g, w, h, S, sc, mixL) {
   var L = ccPhotoLegendDims(w, sc), f = L.f, fl = ccFont("text", 8 * sc, false, false, Math.round(8 * sc * 0.2)), i;
   var names = L.names, cellW = L.cellW, maxW = L.maxW, perRow = L.perRow, rows = L.rows, bw = L.bw, bh = Math.round(7 * sc);
   var mL = ccIsNum(mixL) ? mixL : 1;
   var plateW = L.noteW + (L.plateW - L.noteW) * mL, plateH = L.noteH + (L.plateH - L.noteH) * mL;
   // (compacto: la caja cuelga de la foto, `legY`, en vez de apoyarse en el fondo del panel)
   var yB = (S && S.compact) ? ccPhotoBox(S, w, h, sc).legY + plateH : h - 8 * sc;
   var x0 = 16 * sc, yTop = yB - plateH;
   g.fillRoundedRect(x0, yTop, x0 + plateW, yB, 8, 24, ccBrush(ccInt(CC_ATLAS.bg, 0.94)));
   var opN = ccClamp((0.6 - mL) / 0.6, 0, 1), opL = ccClamp((mL - 0.4) / 0.6, 0, 1);   // el texto y la leyenda no se cruzan
   if (opN > 0.004) {
      var nl = L.noteLines;
      g.opacity = opN;
      for (var kn = 0; kn < nl.length; ++kn) ccTextAt(g, L.fpn, ccInt(CC_ATLAS.text2), x0 + 14 * sc, yTop + plateH / 2 - (nl.length - 1) * 7 * sc + kn * 14 * sc + 3 * sc, nl[kn]);
      g.opacity = 1;
   }
   if (opL < 0.004) return;
   // el contenido, colocado en la caja ENTERA y recortado por la caja actual (mientras se encoge no se sale de ella)
   g.clipRect = new Rect(Math.floor(x0), Math.floor(yTop), Math.ceil(x0 + plateW), Math.ceil(yB));
   plateW = L.plateW; yTop = yB - L.plateH;
   g.opacity = opL;
   var bx = x0 + 14 * sc, by = yTop + 22 * sc;
   // (IV · Elementos: la barra de [X/Fe], simétrica en torno al Sol, y a su derecha el anillo gris de «sin medir»; con Fe, la de siempre)
   var elL = ccElemOn(S), liL = ccLiMode(S), barLab = elL ? ccElLabel(S.elem) : "[Fe/H]", Rr = (elL && !liL) ? ccElemRange(S) : 0;
   ccTextAt(g, fl, ccInt(CC_ATLAS.text3), bx, by - 7 * sc, barLab);
   var qx = bx + fl.width(barLab) + 6 * sc;
   ccQMark(g, qx, by - 5 * sc, sc, S);
   ccHit(S, "A", qx - 2 * sc, by - 18 * sc, qx + 14 * sc, by, liL ? ccT("liGloss") : elL ? ccT("elemGloss").replace("%1", barLab).replace("%2", ccElName(S.elem, CC_LANG)) + " " + ccElChannel(S.elem, CC_LANG).long : ccGloss("feh", CC_LANG));
   var nvT = ccT(liL ? "legLiUl" : "legNoVal"), nvW = elL ? 22 * sc + f.width(nvT) : 0;
   var bx0 = qx + 22 * sc, bwr = Math.min(bw, x0 + plateW - 16 * sc - bx0 - nvW), lo = liL ? 0 : elL ? -Rr : -2.5, hi = liL ? CC_LI.MAX : elL ? Rr : 0.5, n = 60;
   for (i = 0; i < n; ++i) { var fe = lo + (hi - lo) * (i + 0.5) / n; ccFillRect(g, bx0 + bwr * i / n, by - 12 * sc, bx0 + bwr * (i + 1) / n + 1, by - 12 * sc + bh, ccRgbInt(liL ? ccLiRgb(fe) : elL ? ccElemRgb(fe, Rr) : ccFehRgb(fe))); }
   if (elL) {
      var nvx = bx0 + bwr + 14 * sc;
      if (liL) ccTriDown(g, nvx, by - 12 * sc + bh / 2, 3.6 * sc, ccPen(ccInt(CC_ATLAS.text2, 0.9), Math.max(1.2, 1.2 * sc)));
      else ccDisc(g, nvx, by - 12 * sc + bh / 2, 2.6 * sc, null, ccInt(CC_ATLAS.text3, 0.8), Math.max(1, sc));
      ccTextAt(g, f, ccInt(CC_ATLAS.text2), nvx + 7 * sc, by - 12 * sc + bh / 2 + 3.5 * sc, nvT);
   }
   var ticks = liL ? [0, CC_LI.SUN, CC_LI.SPITE, CC_LI.METEOR] : elL ? [-Rr, -Rr / 2, 0, Rr / 2, Rr] : [-2.5, -1.5, -0.5, 0, 0.5];
   for (i = 0; i < ticks.length; ++i) {
      var tx = bx0 + bwr * (ticks[i] - lo) / (hi - lo), lab = liL ? (ticks[i] === 0 ? "0" : ccFmtL(ticks[i], Math.abs(ticks[i] * 10 - Math.round(ticks[i] * 10)) > 1e-6 ? 2 : 1) + (ticks[i] === CC_LI.SUN ? " ☉" : "")) :
                                                         ccFmtSignedL(ticks[i], (elL && Math.abs(Math.round(ticks[i] * 10) - ticks[i] * 10) > 1e-6) ? 2 : 1);
      g.pen = ccPen(ccInt(CC_ATLAS.text3), 1); g.drawLine(tx, by - 12 * sc + bh, tx, by - 9 * sc + bh);
      ccTextAt(g, f, ccInt(CC_ATLAS.text3), Math.max(bx0, Math.min(bx0 + bwr - f.width(lab), tx - f.width(lab) / 2)), by + 6 * sc, lab);
   }
   var fakeS = { opts: { contours: true } }, ly = by + 26 * sc;
   for (i = 0; i < names.length; ++i) {
      var col = i % perRow, row = Math.floor(i / perRow), cx = bx + col * cellW + 8 * sc, cy = ly + row * 20 * sc, k = names[i][0];
      var star = { chem: { feh: { v: 0, src: k === "hollow" ? "gspspec" : "apogee" } }, pop: { label: (k === "solid" || k === "hollow") ? "none" : k }, age: {} };
      ccStarGlyph(g, cx, cy, star, fakeS, sc * 0.9, false);
      ccTextAt(g, f, ccInt(CC_ATLAS.text2), cx + 14 * sc, cy + 3.5 * sc, names[i][1]);
   }
   ccHit(S, "A", bx, ly - 12 * sc, x0 + plateW, ly + rows * 20 * sc, ccGloss("population", CC_LANG));
   g.opacity = 1; g.clipping = false;
}

// ---------------------------------------------------------------------------
// B, C, D · LOS DIAGRAMAS
// ---------------------------------------------------------------------------
// (23-oct, noche) CC_EXPORT_PAINT: mientras se pinta «A vista / A fichero…» (cc_dialog.js D.exportBitmap). El pie de cada diagrama
// tiene DOS filas (11 lógicos más abajo) y lo que no cabe se calla: la exportada es producto final, sin «…» ni «?» que nadie puede abrir.
var CC_EXPORT_PAINT = false;
function ccExporting() { return CC_EXPORT_PAINT === true && !ccPBroken("exportcut"); }
function ccPlotXf(w, h, sc, x0, x1, y0, y1, top, bottom) {
   var L = Math.round(52 * sc), R = Math.round(14 * sc), T = Math.round(top || 62 * sc), B = Math.round((bottom || 40 * sc) + (ccExporting() ? 11 * sc : 0));
   var pw = w - L - R, ph = h - T - B;
   return {
      L: L, R: R, T: T, B: B, pw: pw, ph: ph, x0: x0, x1: x1, y0: y0, y1: y1,
      X: function(v) { return L + (v - x0) / (x1 - x0) * pw; },
      Y: function(v) { return T + (1 - (v - y0) / (y1 - y0)) * ph; },
      inv: function(px, py) { return { x: x0 + (px - L) / pw * (x1 - x0), y: y0 + (1 - (py - T) / ph) * (y1 - y0) }; }
   };
}
function ccNiceStep(span, n) {
   var raw = span / Math.max(1, n), p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), m = raw / p;
   return (m < 1.5 ? 1 : (m < 3.5 ? 2 : (m < 7.5 ? 5 : 10))) * p;
}
// Ejes con sus «?» (hits del panel).
function ccAxes(g, P, sc, xLabel, yLabel, xDigits, yDigits, S, panel, xTip, yTip) {
   var f = ccFont("mono", 8.2 * sc), fl = ccFont("text", 8.4 * sc, false, false, Math.round(8.4 * sc * 0.18));
   ccFillRect(g, P.L, P.T, P.L + P.pw, P.T + P.ph, ccInt(CC_INSET));
   // (al menos 2 marcas en Y, no 3: en un panel bajo —con un grupo abierto— los rótulos se pisaban; y una marca a menos de
   // 12 px de la anterior se queda sin rótulo)
   var sx = ccNiceStep(Math.abs(P.x1 - P.x0), Math.max(3, Math.round(P.pw / (70 * sc)))), sy = ccNiceStep(Math.abs(P.y1 - P.y0), Math.max(2, Math.round(P.ph / (40 * sc)))), v, lab, lastY = 1e9;
   var xmin = Math.min(P.x0, P.x1), xmax = Math.max(P.x0, P.x1);
   for (v = Math.ceil(xmin / sx - 1e-9) * sx; v <= xmax + 1e-9; v += sx) {
      var X = P.X(v);
      g.pen = ccPen(ccInt(CC_ATLAS.line, 0.7), 1); g.drawLine(X, P.T, X, P.T + P.ph);
      lab = (xDigits === 0) ? String(Math.round(v)) : ccFmtSignedL(v, xDigits);
      ccTextAt(g, f, ccInt(CC_ATLAS.text3), X - f.width(lab) / 2, P.T + P.ph + 13 * sc, lab);
   }
   for (v = Math.ceil(P.y0 / sy - 1e-9) * sy; v <= P.y1 + 1e-9; v += sy) {
      var Y = P.Y(v);
      g.pen = ccPen(ccInt(CC_ATLAS.line, 0.7), 1); g.drawLine(P.L, Y, P.L + P.pw, Y);
      lab = (yDigits === 0) ? String(Math.round(v)) : ccFmtSignedL(v, yDigits);
      if (Math.abs(lastY - Y) >= 12 * sc) { ccTextAt(g, f, ccInt(CC_ATLAS.text3), P.L - f.width(lab) - 6 * sc, Y + 3 * sc, lab); lastY = Y; }
   }
   g.pen = ccPen(ccInt(CC_LINE_STRONG), 1); g.drawRect(P.L, P.T, P.L + P.pw, P.T + P.ph);
   // (el rótulo del eje X va en la fila del pie: ccFoot)
   // eje Y: horizontal, encima del eje, a la derecha del margen (no pisa la frase llana)
   var yy = P.T - 6 * sc;
   ccTextAt(g, fl, ccInt(CC_ATLAS.text2), P.L + 4 * sc, yy, yLabel + " ↑");
   if (yTip) { var q2 = P.L + 8 * sc + fl.width(yLabel + " ↑"); ccQMark(g, q2, yy + 1 * sc, sc, S); ccHit(S, panel, q2 - 3 * sc, yy - 12 * sc, q2 + 14 * sc, yy + 4 * sc, yTip); }
}
// El mapa de densidad de referencia, SUAVIZADO y a 3x (los cuadritos de los bins se veían: revisor visual).
var CC_REF_BMP = {};
// (E4, 23-oct) Las rejillas de cc_reference_elements.js vienen compactas (`rle`: una tirada de k ceros es −k): se deshacen una vez.
function ccRefCounts(grid) {
   if (grid.counts) return grid.counts;
   var c = [], o = grid.rle || [];
   for (var i = 0; i < o.length; ++i) { if (o[i] < 0) for (var k = 0; k < -o[i]; ++k) c.push(0); else c.push(o[i]); }
   grid.counts = c;
   return c;
}
function ccSmoothLog(grid) {
   var nx = grid.nx, ny = grid.ny, v = new Array(nx * ny), sm = new Array(nx * ny), i, j, mx = 0, pass, cnt = ccRefCounts(grid);
   for (i = 0; i < nx * ny; ++i) v[i] = Math.log(1 + (cnt[i] || 0));
   for (pass = 0; pass < 2; ++pass) {      // dos pasadas de 3x3 ~ gaussiana de σ ≈ 1,2 bins
      for (j = 0; j < ny; ++j) for (i = 0; i < nx; ++i) {
         var s = 0, n = 0;
         for (var dj = -1; dj <= 1; ++dj) for (var di = -1; di <= 1; ++di) { var a = i + di, b = j + dj; if (a >= 0 && b >= 0 && a < nx && b < ny) { s += v[b * nx + a]; ++n; } }
         sm[j * nx + i] = s / n;
      }
      var t = v; v = sm; sm = t;
   }
   for (i = 0; i < nx * ny; ++i) if (v[i] > mx) mx = v[i];
   return { v: v, max: mx };
}
function ccRefBitmap(grid, hex, key) {
   if (CC_REF_BMP[key]) return CC_REF_BMP[key];
   var Sm = ccSmoothLog(grid), k = 3, W = grid.nx * k, H = grid.ny * k, b = new Bitmap(W, H), c = ccHexRgb(hex);
   b.fill(0x00000000);
   function at(i, j) { i = Math.max(0, Math.min(grid.nx - 1, i)); j = Math.max(0, Math.min(grid.ny - 1, j)); return Sm.v[j * grid.nx + i]; }
   for (var y = 0; y < H; ++y) for (var x = 0; x < W; ++x) {
      var fx = (x + 0.5) / k - 0.5, fy = (y + 0.5) / k - 0.5, i0 = Math.floor(fx), j0 = Math.floor(fy), tx = fx - i0, ty = fy - j0;
      var val = (at(i0, j0) * (1 - tx) + at(i0 + 1, j0) * tx) * (1 - ty) + (at(i0, j0 + 1) * (1 - tx) + at(i0 + 1, j0 + 1) * tx) * ty;
      if (val <= 0.05) continue;
      b.setPixel(x, H - 1 - y, ccRgbInt(c, Math.pow(val / Sm.max, 1.3) * 0.55));
   }
   CC_REF_BMP[key] = b;
   return b;
}
// (E4) `clipWH` = [w, h] del lienzo: la rejilla puede ser más ancha que los ejes (el eje de un elemento es el de sus datos) y se
// recorta al rectángulo de los datos (y se devuelve el recorte al lienzo entero al acabar). Devuelve cuántos segmentos de curva
// caen DENTRO del rectángulo (lo que se ve; para las pruebas).
function ccDrawRef(g, P, grid, hex, key, flipX, sc, clipWH) {
   if (typeof grid !== "object" || !grid) return 0;
   if (clipWH) g.clipRect = new Rect(P.L, P.T, P.L + P.pw, P.T + P.ph);
   try { return ccDrawRef0(g, P, grid, hex, key, flipX, sc); }
   finally { if (clipWH) g.clipRect = new Rect(0, 0, clipWH[0], clipWH[1]); }
}
function ccDrawRef0(g, P, grid, hex, key, flipX, sc) {
   var b = ccRefBitmap(grid, hex, key);
   var xa = P.X(flipX ? grid.x1 : grid.x0), xb = P.X(flipX ? grid.x0 : grid.x1), ya = P.Y(grid.y1), yb = P.Y(grid.y0);
   g.smoothInterpolation = true;
   if (flipX) g.drawScaledBitmap(Math.min(xa, xb), ya, Math.max(xa, xb), yb, b.mirroredHorizontally());
   else g.drawScaledBitmap(xa, ya, xb, yb, b);
   var segs = ccRefContours(grid, key), inside = 0, xl = Math.min(P.x0, P.x1), xh = Math.max(P.x0, P.x1);
   g.antialiasing = true;
   for (var L = 0; L < segs.byLevel.length; ++L) {
      var S2 = segs.byLevel[L];
      g.pen = ccPen(ccInt(CC_ATLAS.text2, 0.25 + 0.2 * L), Math.max(1, (0.8 + 0.25 * L) * (sc || 1)));
      for (var i = 0; i < S2.length; i += 4) {
         g.drawLine(P.X(S2[i]), P.Y(S2[i + 1]), P.X(S2[i + 2]), P.Y(S2[i + 3]));
         if (S2[i] >= xl && S2[i] <= xh && S2[i + 1] >= P.y0 && S2[i + 1] <= P.y1) ++inside;
      }
   }
   return inside;
}
// Solo el contorno de una rejilla, en un nivel, con raya de puntos (los LÍMITES del litio: «aquí caen los límites», sin nube)
function ccDrawRefLine(g, P, grid, key, level, hex, sc, clipWH) {
   if (typeof grid !== "object" || !grid) return 0;
   var Sm = ccSmoothLog(grid), dx = (grid.x1 - grid.x0) / grid.nx, dy = (grid.y1 - grid.y0) / grid.ny, k = key + ":" + level;
   if (!CC_REF_CONT[k]) CC_REF_CONT[k] = ccDropIslands(ccMarch(Sm.v, grid.nx, grid.ny, level * Sm.max, function(i) { return grid.x0 + (i + 0.5) * dx; }, function(j) { return grid.y0 + (j + 0.5) * dy; }), CC_REF_MIN_LEN);
   var S2 = CC_REF_CONT[k], n = 0;
   if (clipWH) g.clipRect = new Rect(P.L, P.T, P.L + P.pw, P.T + P.ph);
   try {
      g.antialiasing = true;
      g.pen = ccPen(ccInt(hex, 0.75), Math.max(1, 1.1 * (sc || 1)), PenStyle_Dot);
      for (var i = 0; i < S2.length; i += 4) { g.drawLine(P.X(S2[i]), P.Y(S2[i + 1]), P.X(S2[i + 2]), P.Y(S2[i + 3])); ++n; }
   } finally { if (clipWH) g.clipRect = new Rect(0, 0, clipWH[0], clipWH[1]); }
   return n;
}
// (E4, 23-oct) La nube de referencia de un elemento X en el diagrama de química: Mg (y Fe, que enseña [α/Fe]) = CC_REF_ALPHA de
// siempre; el resto, la de cc_reference_elements.js si la hay (un survey por elemento, sin mezclar escalas: docs/referencia_elementos.md).
// -> { grid, key, label: «APOGEE DR17» / «APOGEE DR17, gigantes» / «GALAH DR4» } o { grid: null, why: "unreliable" | "censored" | "small" | "nodata" }
// ROJOS de T23: «nocloudel» (sin nube fuera del Mg, como antes) · «cloudshift» (la nube +0,3 dex en Y: M 67 tiene que salirse).
function ccRefFor(X) {
   if (!X || X === "Fe" || X === "Mg") return { grid: (typeof CC_REF_ALPHA !== "undefined") ? CC_REF_ALPHA : null, key: "alpha", label: "APOGEE DR17" };
   if (typeof CC_REF_EL === "undefined" || !CC_REF_EL || ccPBroken("nocloudel")) return { grid: null, why: "nodata" };
   var g = CC_REF_EL.grids[X];
   if (!g) return { grid: null, why: (CC_REF_EL.none[X] && CC_REF_EL.none[X].why) || "nodata", info: CC_REF_EL.none[X] || null };
   if (ccPBroken("cloudshift")) {
      if (!g._shift) { g._shift = {}; for (var k in g) if (g.hasOwnProperty(k) && k !== "_shift") g._shift[k] = g[k]; g._shift.y0 = g.y0 + 0.3; g._shift.y1 = g.y1 + 0.3; g._shift.counts = ccRefCounts(g); }
      return { grid: g._shift, key: "el:" + X + ":shift", label: g.src === "apogee" ? "APOGEE DR17" : "GALAH DR4", who: g.who };
   }
   return { grid: g, key: "el:" + X, label: g.src === "apogee" ? "APOGEE DR17" : "GALAH DR4", who: g.who };
}
// (24-oct, N1 = b de Nino) Una nube hecha SOLO con gigantes (N, Na, Co, Ce de APOGEE: who === "giants") se pinta solo si la MAYORÍA de las
// estrellas pintadas en B son gigantes; si no (M 67, un campo de enanas), sin nube y el pie lo dice, como con el Eu. «Gigante» = log g < 3,8
// EN EL SURVEY QUE DIO EL ELEMENTO: el mismo corte con el que se hizo la nube (tests/cc_build_reference_elements.js, APOGEE_GIANT_LOGG, el de
// la calibración de DR17) y con el que T23 Z2 compara. Sin log g en ese registro, el de la adoptada (chem.logg).
// (24-oct, revisión de Gemini H4) DOS CASOS EN QUE NO HAY MAYORÍA QUE JUZGAR, y entonces el criterio NO se aplica y la nube se pinta como fondo
// de referencia (un diagrama vacío con su fondo, como el de cualquier otro elemento; el motivo «giantsonly» dice «la mayoría de las pintadas aquí no
// lo son», que con 0 pintadas es falso): (1) ninguna estrella pintada en B con valor de ese elemento (campo sin medidas, antes de analizar, reloj
// cósmico rebobinado a antes de las estrellas); (2) ninguna de las pintadas tiene log g (ni en el survey ni en la adoptada). Las SIN log g no
// cuentan en el denominador: ni son gigantes ni son enanas, no se sabe. Mayoría = ESTRICTA (la mitad justa no basta) sobre las que SÍ tienen log g.
// ROJOS de T24: «giantsany» (siempre se pinta) · «giantsnone» (nunca) · «giantsge» (≥ ½) · «giantsempty» (0 pintadas = «giantsonly», como antes de
// H4) · «giantsnolg» (las sin log g cuentan como no gigantes, como antes de H4).
var CC_REF_GIANT_LOGG = 3.8;
function ccRefLogg(s, bv) {
   var rc = (s && s.recs && bv && bv.src) ? s.recs[bv.src] : null;
   return (rc && ccIsNum(rc.logg)) ? rc.logg : ((s && s.chem && ccIsNum(s.chem.logg)) ? s.chem.logg : null);
}
function ccRefIsGiant(s, bv) { var lg = ccRefLogg(s, bv); return lg !== null && lg < CC_REF_GIANT_LOGG; }
// nG gigantes de n con log g (las sin log g no entran en n)
function ccRefGiantMajority(nG, n) {
   if (ccPBroken("giantsany")) return true;
   if (ccPBroken("giantsnone")) return false;
   if (!(n > 0)) return !ccPBroken("giantsempty");           // nada que juzgar: el criterio no se aplica (se pinta la nube)
   return ccPBroken("giantsge") ? 2 * nG >= n : 2 * nG > n;
}
// -> { n: las pintadas en B con valor Y con log g, g: las gigantes entre ellas, all: las pintadas en B con valor (con o sin log g) }
function ccRefGiantShare(S, list, getB) {
   var st = S.res ? S.res.stars : [], n = 0, g = 0, all = 0;
   for (var i = 0; i < list.length; ++i) {
      var s = st[list[i]], bv = s ? getB(s) : null;
      if (!bv) continue;
      ++all;
      if (ccRefLogg(s, bv) === null && !ccPBroken("giantsnolg")) continue;
      ++n; if (ccRefIsGiant(s, bv)) ++g;
   }
   return { n: n, g: g, all: all };
}
// El trozo del pie: «fondo: GALAH DR4 (45 300)» / «fondo: APOGEE DR17, gigantes (12 100)» / «sin fondo para [S/Fe]: …» (forma corta y larga)
function ccRefFoot(R, yLab) {
   if (R.grid) return ccT("backdropNote") + ": " + R.label + (R.who === "giants" ? ", " + ccT("refGiants") : "") + " (" + ccNice(R.grid.n, CC_LANG, 3) + ")";
   var why = ccT("refWhy_" + (R.why || "nodata"));
   // (24-oct, N1) con una nube de gigantes sin pintar, la forma corta ya dice el porqué: «sin fondo: la nube es de gigantes»
   return [R.why === "giantsonly" ? ccT("noBackdropGiants") : ccT("noBackdropShort").replace("%1", yLab), ccT("noBackdropEl").replace("%1", yLab).replace("%2", why)];
}
// Curvas de nivel por cuadrados de marcha, SIN islotes: se quitan los trozos de curva
// cerrados más cortos que CC_REF_MIN_LEN celdas (el glifo «▽ ,» de la primera entrega era uno).
var CC_REF_LEVELS = [0.30, 0.55, 0.80];
var CC_REF_MIN_LEN = 12;       // diseño: longitud mínima de una curva, en celdas
var CC_REF_CONT = {};
function ccCut(pts, t, p, q, xa, ya, xb, yb) { var f = (t - p) / (q - p); pts.push([xa + (xb - xa) * f, ya + (yb - ya) * f]); }
function ccMarch(vals, nx, ny, t, X, Y) {
   var seg = [];
   for (var j = 0; j < ny - 1; ++j) for (var i = 0; i < nx - 1; ++i) {
      var a0 = vals[j * nx + i], a1 = vals[j * nx + i + 1], a2 = vals[(j + 1) * nx + i + 1], a3 = vals[(j + 1) * nx + i];
      var c = (a0 > t ? 1 : 0) | (a1 > t ? 2 : 0) | (a2 > t ? 4 : 0) | (a3 > t ? 8 : 0);
      if (c === 0 || c === 15) continue;
      var pts = [];
      if ((a0 > t) !== (a1 > t)) ccCut(pts, t, a0, a1, X(i), Y(j), X(i + 1), Y(j));
      if ((a1 > t) !== (a2 > t)) ccCut(pts, t, a1, a2, X(i + 1), Y(j), X(i + 1), Y(j + 1));
      if ((a2 > t) !== (a3 > t)) ccCut(pts, t, a2, a3, X(i + 1), Y(j + 1), X(i), Y(j + 1));
      if ((a3 > t) !== (a0 > t)) ccCut(pts, t, a3, a0, X(i), Y(j + 1), X(i), Y(j));
      for (var k = 0; k + 1 < pts.length; k += 2) seg.push(pts[k][0], pts[k][1], pts[k + 1][0], pts[k + 1][1]);
   }
   return seg;
}
// Quita los componentes (segmentos unidos por sus extremos) con menos de minN segmentos.
function ccDropIslands(seg, minN) {
   var n = seg.length / 4, parent = [], keyOf = {}, i;
   for (i = 0; i < n; ++i) parent.push(i);
   function find(a) { while (parent[a] !== a) { parent[a] = parent[parent[a]]; a = parent[a]; } return a; }
   function key(x, y) { return Math.round(x * 1e5) + ":" + Math.round(y * 1e5); }
   for (i = 0; i < n; ++i) {
      var ks = [key(seg[4 * i], seg[4 * i + 1]), key(seg[4 * i + 2], seg[4 * i + 3])];
      for (var k = 0; k < 2; ++k) { if (keyOf[ks[k]] === undefined) keyOf[ks[k]] = i; else parent[find(i)] = find(keyOf[ks[k]]); }
   }
   var size = {};
   for (i = 0; i < n; ++i) { var r = find(i); size[r] = (size[r] || 0) + 1; }
   var out = [];
   for (i = 0; i < n; ++i) if (size[find(i)] >= minN) out.push(seg[4 * i], seg[4 * i + 1], seg[4 * i + 2], seg[4 * i + 3]);
   return out;
}
function ccRefContours(grid, key) {
   if (CC_REF_CONT[key]) return CC_REF_CONT[key];
   var Sm = ccSmoothLog(grid), dx = (grid.x1 - grid.x0) / grid.nx, dy = (grid.y1 - grid.y0) / grid.ny, out = { levels: CC_REF_LEVELS, byLevel: [], dropped: 0 };
   function X(i) { return grid.x0 + (i + 0.5) * dx; }
   function Y(j) { return grid.y0 + (j + 0.5) * dy; }
   for (var L = 0; L < CC_REF_LEVELS.length; ++L) {
      var raw = ccMarch(Sm.v, grid.nx, grid.ny, CC_REF_LEVELS[L] * Sm.max, X, Y), kept = ccDropIslands(raw, CC_REF_MIN_LEN);
      out.dropped += (raw.length - kept.length) / 4;
      out.byLevel.push(kept);
   }
   CC_REF_CONT[key] = out;
   return out;
}
function ccErrBars(g, P, x, ex, y, ey, sc, alpha) {
   g.pen = ccPen(ccInt(CC_ATLAS.text2, alpha), Math.max(1, sc * 0.8));
   if (ccIsNum(ex) && ex > 0) g.drawLine(P.X(Math.max(Math.min(P.x0, P.x1), x - ex)), P.Y(y), P.X(Math.min(Math.max(P.x0, P.x1), x + ex)), P.Y(y));
   if (ccIsNum(ey) && ey > 0) g.drawLine(P.X(x), P.Y(Math.max(P.y0, y - ey)), P.X(x), P.Y(Math.min(P.y1, y + ey)));
}
// Un punto en un diagrama: dentro, su punto; fuera de escala, su marca en el borde. Devuelve true si estaba fuera.
function ccPlotPoint(g, P, s, x, y, S, sc, dim, hollow) {
   var xl = Math.min(P.x0, P.x1), xh = Math.max(P.x0, P.x1), out = "";
   if (x < xl) out = (P.x0 < P.x1) ? "l" : "r"; else if (x > xh) out = (P.x0 < P.x1) ? "r" : "l";
   else if (y < P.y0) out = "b"; else if (y > P.y1) out = "t";
   var X = P.X(ccClamp(x, xl, xh)), Y = P.Y(ccClamp(y, P.y0, P.y1));
   if (out) { ccEdgeMark(g, X, Y, out, s, sc); return true; }
   ccDot(g, X, Y, s, S, sc, dim, hollow);
   return false;
}
// La capa de encima de un diagrama: la de debajo del ratón y la elegida (cruz hasta los ejes que «crece»).
function ccPlotOverlay(g, P, S, sc, get, k, panel, w, h, extra) {
   if (S.res) {
      var st = S.res.stars;
      g.antialiasing = true;
      if (S.hover >= 0 && S.hover !== S.sel) {
         var hv = get(st[S.hover]);
         if (hv) { var hx = P.X(ccClamp(hv.x, Math.min(P.x0, P.x1), Math.max(P.x0, P.x1))), hy = P.Y(ccClamp(hv.y, P.y0, P.y1)); ccSelRing(g, hx, hy, st[S.hover], S, sc * k, false); ccHoverLabel(g, hx, hy, st[S.hover], w, h, sc, S); }
      }
      if (S.sel >= 0) {
         var s = st[S.sel], v = get(s);
         if (v) {
            var x = P.X(ccClamp(v.x, Math.min(P.x0, P.x1), Math.max(P.x0, P.x1))), y = P.Y(ccClamp(v.y, P.y0, P.y1)), e = ccEase(S.anim && ccIsNum(S.anim.sel) ? S.anim.sel : 1);
            g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.55 * e), 1, PenStyle_Dash);
            g.drawLine(x, y, x + (P.L - x) * e, y);
            g.drawLine(x, y, x, y + (P.T + P.ph - y) * e);
            g.pen = ccPen(ccInt(CC_ATLAS.goldLight, 0.95), Math.max(1.2, 1.4 * sc));
            var xl0 = Math.min(P.x0, P.x1), xh0 = Math.max(P.x0, P.x1);
            if (ccIsNum(v.ex) && v.ex > 0) g.drawLine(P.X(ccClamp(v.x - v.ex, xl0, xh0)), y, P.X(ccClamp(v.x + v.ex, xl0, xh0)), y);
            if (ccIsNum(v.ey) && v.ey > 0) g.drawLine(x, P.Y(ccClamp(v.y - v.ey, P.y0, P.y1)), x, P.Y(ccClamp(v.y + v.ey, P.y0, P.y1)));
            ccSelRing(g, x, y, s, S, sc * k, true);
         }
      }
   }
   if (extra) extra(g);
   ccTipBubble(g, w, h, S, panel, sc);
}
// El encabezado común de un diagrama: título + frase llana. Devuelve el margen superior del trazado.
// `S.compact` (CabraComposition, 22-oct): título y frase más arriba (la columna de vistas tiene poco alto); `reserveR` = lo
// que ocupan a la derecha los botones pintados del panel (la frase no se mete debajo).
function ccPlotHeader(g, w, sc, S, panel, titleKey, capKey, tipKey, reserveR) {
   if (S && S.compact && !(typeof ccBroken === "function" && ccBroken("nohelp"))) {
      var tx = ccPanelTitle(g, Math.round(14 * sc), Math.round(18 * sc), ccT(titleKey), sc);
      var qwh = ccTitleHelp(g, tx + 10 * sc, Math.round(18 * sc), sc, S, panel, capKey, tipKey);
      if (S) { if (!S._hdrEnd) S._hdrEnd = {}; S._hdrEnd[panel] = tx + 10 * sc + qwh; }
      return Math.round(38 * sc);
   }
   ccPanelTitle(g, Math.round(14 * sc), Math.round(22 * sc), ccT(titleKey), sc);
   var yEnd = ccCaption(g, Math.round(14 * sc), Math.round(38 * sc), w - 28 * sc, capKey, tipKey, sc, S, panel);
   return yEnd + 24 * sc;
}

var CC_ALPHA_AX = { x0: -2.6, x1: 0.7, y0: -0.25, y1: 0.55 };
// B en modo litio: A(Li) frente a Teff (ver CC_LI). S._liDrawn = lo pintado (para las pruebas).
function ccPaintLiB(g, w, h, S, sc) {
   // (24-oct, revisión de Gemini H4c) con el reloj cósmico, SOLO las nacidas, como A, C y D (ccClockList). ROJO «liclock»: toda S.list, como antes.
   var st = S.res ? S.res.stars : [], list = ccPBroken("liclock") ? (S.list || []) : ccClockList(S), i, s, getB = function(s2) { return ccBGet(s2, S); };
   ccHitsReset(S, "B");
   ccFrame(g, w, h, sc);
   var top = ccPlotHeader(g, w, sc, S, "B", "panelBLi", "capBLi", "liGloss");
   var AXL = ccLiAxis(S);
   var P = ccPlotXf(w, h, sc, AXL.t0, AXL.t1, CC_LI.Y0, CC_LI.Y1, top, S.compact ? 34 * sc : 0);
   S.geomB = P;
   ccAxes(g, P, sc, "", "A(Li)", 0, 0, S, "B", null, ccT("liGloss"));
   // (E4, 23-oct) la nube de referencia del litio: las DETECCIONES de GALAH DR4 (nube y curvas, como la de [Mg/Fe]); los LÍMITES, aparte:
   // solo su curva del medio, de puntos (dónde caen; un límite no es un valor). ROJO «nocloudli» de T23: sin nada.
   var refLi = (typeof CC_REF_LI !== "undefined" && CC_REF_LI && !ccPBroken("nocloudli")) ? CC_REF_LI : null;
   S._refB = { X: "Li", has: !!refLi, label: refLi ? "GALAH DR4" : "", n: refLi ? refLi.det.n : 0, nUl: refLi ? refLi.ul.n : 0, segs: 0, segsUl: 0, on: !S.opts || S.opts.backdrop !== false };
   if (refLi && S._refB.on) {
      S._refB.segs = ccDrawRef(g, P, refLi.det, CC_ATLAS.text3, "li:det", true, sc, [w, h]);
      S._refB.segsUl = ccDrawRefLine(g, P, refLi.ul, "li:ul", CC_REF_LEVELS[1], CC_ATLAS.text2, sc, [w, h]);
   }
   g.antialiasing = true;
   // las referencias: la meseta de Spite (banda), los meteoritos (raya), las gigantes ricas (discontinua, solo en la zona fría de las gigantes)
   var xl = P.X(AXL.t0), xr = P.X(AXL.t1);
   ccFillRect(g, Math.min(xl, xr), P.Y(CC_LI.SPITE + CC_LI.SPITE_E), Math.max(xl, xr), P.Y(CC_LI.SPITE - CC_LI.SPITE_E), ccInt(CC_ATLAS.chart[1], 0.16));
   g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.7), 1, PenStyle_Dot); g.drawLine(P.L, P.Y(CC_LI.METEOR), P.L + P.pw, P.Y(CC_LI.METEOR));
   g.pen = ccPen(ccInt(CC_ATLAS.text3, 0.8), 1, PenStyle_Dash); g.drawLine(P.X(CC_LI.GIANT_TEFF), P.Y(CC_LI.RICH), P.X(AXL.t1), P.Y(CC_LI.RICH));
   var fz = ccFont("text", 7.6 * sc, false, true);
   if (P.ph >= 60 * sc) {
      ccTextAt(g, fz, ccInt(CC_ATLAS.gold, 0.85), P.L + P.pw - fz.width(ccT("liMeteor")) - 6 * sc, P.Y(CC_LI.METEOR) - 3 * sc, ccT("liMeteor"));
      ccTextAt(g, fz, ccInt(CC_ATLAS.chart[1], 0.95), P.L + P.pw - fz.width(ccT("liSpite")) - 6 * sc, P.Y(CC_LI.SPITE + CC_LI.SPITE_E) - 3 * sc, ccT("liSpite"));
      ccTextAt(g, fz, ccInt(CC_ATLAS.text3, 0.95), P.L + P.pw - fz.width(ccT("liRich")) - 6 * sc, P.Y(CC_LI.RICH) - 3 * sc, ccT("liRich"));
   }
   var nD = 0, nU = 0, nG = 0, off = 0, src = {}, liCol = [];
   S._liPts = [];          // (lo pintado, [x, y, radio]: el rótulo del Sol y el de la elegida buscan sitio libre)
   // (los rótulos de las referencias, también: puntos cada 5 px a lo largo de su caja —«elegida: sin A(Li)» se puso sobre «meteoritos»—)
   if (P.ph >= 60 * sc) {
      var refL = [[ccT("liMeteor"), CC_LI.METEOR], [ccT("liSpite"), CC_LI.SPITE + CC_LI.SPITE_E], [ccT("liRich"), CC_LI.RICH]];
      for (var rq = 0; rq < refL.length; ++rq) {
         var rw = fz.width(refL[rq][0]), rx1 = P.L + P.pw - 6 * sc, rx0 = rx1 - rw, ry = P.Y(refL[rq][1]) - 3 * sc - fz.ascent / 2;
         for (var rxx = rx0; rxx <= rx1; rxx += 5 * sc) S._liPts.push([rxx, ry, fz.ascent / 2 + 1 * sc]);
      }
   }
   for (i = 0; i < list.length; ++i) {
      s = st[list[i]];
      var bv = getB(s);
      if (!bv) continue;
      src[bv.src] = (src[bv.src] || 0) + 1;
      if (bv.giant) ++nG;
      // (23-oct, revisor R12: los puntos de B iban por el color de su [Fe/H] —azules a A(Li) ≈ 2— y los de la foto por A(Li): ahora la
      //  MISMA escala A(Li) que la foto —ccLiRgb— y los límites, el MISMO ▽ gris que la foto. ROJO «lifehcolor» de T18: el [Fe/H])
      var dimL = S.group ? !S.group[s.idx] : false, feL = (s.chem && s.chem.feh) ? s.chem.feh.v : null;
      if (bv.ul) {
         // un límite: ▽ en su valor (el litio es como mucho eso), gris como en la foto
         ++nU;
         var X = P.X(ccClamp(bv.x, AXL.t1, AXL.t0)), Y = P.Y(ccClamp(bv.y, CC_LI.Y0, CC_LI.Y1));
         S._liPts.push([X, Y, 3.6 * sc]);
         ccTriDown(g, X, Y, 3.6 * sc, ccPen(ccPBroken("lifehcolor") ? ccRgbInt(ccFehRgb(feL), dimL ? 0.25 : 0.9) : ccInt(CC_ATLAS.text2, dimL ? 0.25 : 0.9), Math.max(1, 1.1 * sc)));
         continue;
      }
      ++nD;
      var rgbL = ccPBroken("lifehcolor") ? ccFehRgb(feL) : ccLiRgb(bv.y);
      liCol.push({ v: bv.y, rgb: rgbL });
      var outL = (bv.x > AXL.t0) ? "l" : (bv.x < AXL.t1) ? "r" : (bv.y < CC_LI.Y0) ? "b" : (bv.y > CC_LI.Y1) ? "t" : "";
      var XL = P.X(ccClamp(bv.x, AXL.t1, AXL.t0)), YL = P.Y(ccClamp(bv.y, CC_LI.Y0, CC_LI.Y1));
      if (outL) { S._liPts.push([XL, YL, 4 * sc]); ccEdgeMark(g, XL, YL, outL, s, sc, rgbL); ++off; continue; }
      var rL = ccStarRadius(s, S, sc) * 0.8, aL = dimL ? 0.18 : 1;
      S._liPts.push([XL, YL, rL + 1.2 * sc]);
      g.antialiasing = true;
      g.fillCircle(XL, YL, rL + 1.2 * sc, ccBrush(ccInt(CC_ATLAS.bg, 0.6 * aL)));
      if (bv.giant) ccDisc(g, XL, YL, rL, ccRgbInt(rgbL, 0.2 * aL), ccRgbInt(rgbL, 0.9 * aL), Math.max(1, 1.1 * sc));
      else ccDisc(g, XL, YL, rL, ccRgbInt(rgbL, 0.92 * aL), null);
   }
   // (23-oct, noche, revisión visual 7: «Sol» quedaba tapado por los puntos) El símbolo, y su rótulo con placa en el sitio libre de alrededor
   var sxL = P.X(CC_LI.SUN_TEFF), syL = P.Y(CC_LI.SUN);
   if (ccPBroken("noplate")) {
      ccSunSymbol(g, sxL, syL, sc, false, ccSelXY(S, P, getB), true);
      var fS0 = ccFont("display", 8.4 * sc, false, true), xs0 = sxL + 7 * sc;        // (la caja del rótulo de antes, a la derecha: para medirlo)
      S._liSunLab = { x0: xs0 - 3 * sc, y0: syL - 5 * sc - fS0.ascent - 1 * sc, x1: xs0 + fS0.width(ccT("sunLabel")) + 3 * sc, y1: syL - 5 * sc + fS0.descent + 1 * sc, under: -1 };
   }
   else {
      ccSunSymbol(g, sxL, syL, sc, true);
      var fSunL = ccFont("display", 8.4 * sc, false, true), tSun = ccT("sunLabel"), twS = fSunL.width(tSun), dS = 7 * sc;
      var cS = [[sxL + dS, syL - 5 * sc], [sxL - dS - twS, syL - 5 * sc], [sxL + dS, syL + 12 * sc], [sxL - dS - twS, syL + 12 * sc], [sxL - twS / 2, syL - 10 * sc], [sxL - twS / 2, syL + 17 * sc],
                [sxL + 3 * dS, syL - 14 * sc], [sxL - 3 * dS - twS, syL - 14 * sc], [sxL + 3 * dS, syL + 22 * sc], [sxL - 3 * dS - twS, syL + 22 * sc]];
      var avS = ccSelXY(S, P, getB), ptsS = S._liPts.slice();
      if (avS) ptsS.push([avS.x, avS.y, 12 * sc]);
      var spS = ccFreeSpot(cS, fSunL, tSun, ptsS, P, sc);
      if (spS) {
         var near = Math.abs(spS.x - sxL) <= dS + twS + 1 && Math.abs(spS.y - syL) <= 18 * sc;
         if (!near) { g.pen = ccPen(ccInt(CC_ATLAS.text, 0.6), 1); g.drawLine(sxL, syL, (spS.x + twS / 2), spS.y - (spS.y < syL ? -3 * sc : fSunL.ascent + 1 * sc)); }
         var bS = ccPlateText(g, fSunL, ccInt(CC_ATLAS.text, 0.9), spS.x, spS.y, tSun, sc, 0.86);
         S._liSunLab = { x0: bS.x0, y0: bS.y0, x1: bS.x1, y1: bS.y1, under: spS.under };
      } else S._liSunLab = { under: -1 };
   }
   S._liDrawn = { det: nD, ul: nU, giants: nG, off: off, colors: liCol, t0: AXL.t0, t1: AXL.t1, tMin: AXL.tMin, tMax: AXL.tMax };
   var sl = []; for (var k2 in src) if (src.hasOwnProperty(k2)) sl.push((CC_SURVEY_LABEL[k2] || k2) + " " + ccThou(src[k2], CC_LANG));
   var segs = [ccThou(nD, CC_LANG) + " " + ccT("liDet"), ccThou(nU, CC_LANG) + " " + ccT("liUl"), ccT("liGiants"), ccT("from") + ": " + sl.join(", ") + " (3D NLTE)", ccT("liRefs")];
   if (off) segs.splice(2, 0, [ccThou(off, CC_LANG) + " " + ccT("offScaleShort"), ccThou(off, CC_LANG) + " " + ccT("offScale")]);
   segs[1] = [ccThou(nU, CC_LANG) + " " + ccT("liUlShort"), segs[1]];
   if (refLi) segs.push([ccT("backdropNote") + ": GALAH DR4 (" + ccNice(refLi.det.n, CC_LANG, 3) + ")",
                         ccT("refLiFoot").replace("%1", ccNice(refLi.det.n, CC_LANG, 3)).replace("%2", ccNice(refLi.ul.n, CC_LANG, 3))]);
   else segs.push(ccT("noBackdropLi"));
   if (S._refB) { var fzL = segs[segs.length - 1]; S._refB.foot = (typeof fzL === "string") ? fzL : fzL[1]; }
   ccFoot(g, P, w, h, sc, segs, S, "B", ccT("teffAxis"), ccT("teffGloss"));
}
function ccPaintAlpha(g, w, h, S, sc, part) {
   var st = S.res ? S.res.stars : [], list = ccClockList(S), i, s, E = CC_LANG === "es";
   if (ccLiMode(S)) {                                      // (23-oct: el litio, A(Li) frente a Teff)
      if (part !== "over") { ccPaintLiB(g, w, h, S, sc); return; }
      var AXo = ccLiAxis(S), PLo = S.geomB || ccPlotXf(w, h, sc, AXo.t0, AXo.t1, CC_LI.Y0, CC_LI.Y1);
      ccPlotOverlay(g, PLo, S, sc, function(s2) { return ccBGet(s2, S); }, 0.85, "B", w, h, function(g2) { ccLiSelMark(g2, PLo, S, sc); });
      return;
   }
   // (IV · Elementos, 22-oct: con un elemento X que no es Fe, el eje Y es [X/Fe]; el fondo de APOGEE y la frontera de Weinberg
   //  son de [Mg/Fe]: solo con Mg —y con Fe, que enseña [α/Fe] como siempre—. Sin S.elem —CabraStarAnalysis— todo como antes.)
   var elB = ccElemOn(S), X = elB ? S.elem : "", mgLike = !elB || X === "Mg", yLab = elB ? ccElLabel(X) : "[α/Fe]", AX = ccElemAxis(S), AXX = ccElemXAxis(S);
   var getB = function(s2) { return ccBGet(s2, S); };
   if (part !== "over") {
      ccHitsReset(S, "B");
      ccFrame(g, w, h, sc);
      var nmB = elB ? ccElName(X, CC_LANG) : "", chB = elB ? ccElChannel(X, CC_LANG) : null;
      var top = elB ? ccPlotHeader(g, w, sc, S, "B", ccT("panelBEl").replace("%1", yLab), ccT("capBEl").replace("%1", nmB), chB.long) : ccPlotHeader(g, w, sc, S, "B", "panelB", "capB", "tipB");
      var P = ccPlotXf(w, h, sc, AXX.x0, AXX.x1, AX.y0, AX.y1, top, S.compact ? 34 * sc : 0);
      S.geomB = P;
      ccAxes(g, P, sc, "", yLab, 1, 1, S, "B", null, elB ? ccT("elemGloss").replace("%1", yLab).replace("%2", nmB) : ccGloss("alpha", CC_LANG));
      // (E4, 23-oct) la nube de referencia del elemento (la de APOGEE de siempre con Mg/Fe; con otro X, la suya si la hay), recortada a los ejes
      var refB = ccRefFor(X), wantRef = !S.opts || S.opts.backdrop !== false, gsh = null;
      // (24-oct, N1 = b) la nube de gigantes, solo si la mayoría de las pintadas lo son (ccRefGiantMajority); si no, «sin fondo» como el Eu
      if (refB.grid && refB.who === "giants") { gsh = ccRefGiantShare(S, list, getB); if (!ccRefGiantMajority(gsh.g, gsh.n)) refB = { grid: null, why: "giantsonly" }; }
      S._refB = { X: X || "Fe", has: !!refB.grid, label: refB.grid ? refB.label : "", n: refB.grid ? refB.grid.n : 0, why: refB.why || "", segs: 0, on: wantRef, gN: gsh ? gsh.n : -1, gG: gsh ? gsh.g : -1, gAll: gsh ? gsh.all : -1 };
      if (wantRef && refB.grid) S._refB.segs = ccDrawRef(g, P, refB.grid, CC_ATLAS.text3, refB.key, false, sc, mgLike ? null : [w, h]);
      g.antialiasing = true;
      var pts = [], fe;
      if (mgLike) {
         for (fe = CC_ALPHA_AX.x0; fe <= CC_ALPHA_AX.x1 + 1e-9; fe += 0.05) pts.push(new Point(P.X(fe), P.Y(ccAlphaLine(fe))));
         g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.85), Math.max(1.2, 1.4 * sc), PenStyle_Dash);
         g.drawPolyline(pts);
      } else {
         // (el Sol: la raya de [X/Fe] = 0, tenue)
         g.pen = ccPen(ccInt(CC_ATLAS.text3, 0.6), 1, PenStyle_Dot); g.drawLine(P.L, P.Y(0), P.L + P.pw, P.Y(0));
      }
      g.pen = ccPen(ccInt(CC_ATLAS.chart[1], 0.55), 1, PenStyle_Dot);
      if (CC_SCI.HALO_FEH > AXX.x0) g.drawLine(P.X(CC_SCI.HALO_FEH), P.T, P.X(CC_SCI.HALO_FEH), P.T + P.ph);
      var n = 0, off = 0, tracers = {}, scr = [[P.X(0), P.Y(0)]];
      var errA = S.opts && S.opts.errors ? Math.max(0.08, 0.35 / Math.sqrt(Math.max(1, list.length / 50))) : 0;
      for (i = 0; i < list.length; ++i) {
         s = st[list[i]];
         var bv = getB(s);
         if (!bv) continue;
         ++n;
         var trk = elB ? (CC_SURVEY_LABEL[bv.src] || bv.src) : s.chem.pair.tracer;
         tracers[trk] = (tracers[trk] || 0) + 1;
         if (errA) ccErrBars(g, P, bv.x, bv.ex, bv.y, bv.ey, sc, errA);
         if (ccPlotPoint(g, P, s, bv.x, bv.y, S, sc, S.group ? !S.group[s.idx] : false, false)) ++off;
         scr.push([P.X(ccClamp(bv.x, AXX.x0, AXX.x1)), P.Y(ccClamp(bv.y, AX.y0, AX.y1))]);
      }
      ccSunSymbol(g, P.X(0), P.Y(0), sc, false, ccSelXY(S, P, getB));
      var fz = ccFont("text", 7.8 * sc, false, false, Math.round(7.8 * sc * 0.22)), xr = function(t) { return P.L + P.pw - fz.width(t) - 6 * sc; };
      var tk = E ? "DISCO GRUESO · α ALTO" : "THICK DISC · HIGH α", tn = E ? "DISCO FINO · α BAJO" : "THIN DISC · LOW α";
      // (con el trazado muy bajo —un grupo abierto en CabraComposition— los dos rótulos de disco se pisaban: no caben, no se ponen;
      //  la región sigue explicada en el «?» del panel). Las regiones son las del plano α (o Mg): con otro elemento, no se rotulan.
      if (mgLike && P.ph >= 60 * sc) {
         // (HALO primero: su sitio es el rincón de la izquierda; los de disco buscan hueco sin pisarlo)
         // las regiones: el halo a la izquierda de [Fe/H] = −1 (la raya punteada azul), los dos discos a la derecha
         var xH = P.X(CC_SCI.HALO_FEH), LBs = [];
         LBs.push(["halo", ccPlaceLabel(g, fz, ccInt(CC_ATLAS.chart[1], 0.9), "HALO", [[P.X(-2.5), P.Y(0.5)], [P.X(-2.5), P.Y(0.44)], [P.X(-2.5), P.Y(0.38)], [P.X(-2.0), P.Y(0.5)]], scr, P, sc, [P.L, xH - 4 * sc])]);
         LBs.push(["thick", ccPlaceLabel(g, fz, ccInt(CC_ATLAS.gold, 0.85), tk, [[Math.min(P.X(-0.95), xr(tk)), P.Y(0.5)], [xr(tk), P.Y(0.5)], [P.X(-0.6), P.Y(0.5)], [Math.min(P.X(-0.95), xr(tk)), P.Y(0.44)], [xr(tk), P.Y(0.44)]], scr, P, sc, [xH + 4 * sc, P.L + P.pw])]);
         LBs.push(["thin", ccPlaceLabel(g, fz, ccInt(CC_ATLAS.text, 0.75), tn, [[xr(tn), P.Y(-0.21)], [P.X(-0.95), P.Y(-0.21)], [P.X(-0.7), P.Y(-0.21)], [xr(tn), P.Y(-0.16)], [P.X(-0.95), P.Y(-0.16)]], scr, P, sc, [xH + 4 * sc, P.L + P.pw])]);
         S._bLabels = { xHalo: xH, labels: LBs };
      }
      // la leyenda de la frontera, en la cabecera (no dentro del trazado)
      // (23-oct, revisor R16: con la columna estrecha —400 y 340 lógicos— desaparecía y la raya discontinua se quedaba sin explicar; a 460 la
      //  raya tocaba el «?» del título) Compacto: la forma larga en la fila del título si cabe DESPUÉS de su «?» (con 12 px de aire); si
      //  no, en la fila del rótulo del eje Y, tras su «?»; si no, la forma corta en esas dos filas; y la más corta. Siempre con su raya;
      //  la explicación entera sigue en el «?» del título (tipB). ROJO «wbnarrow» de T18: solo la forma larga, en la fila del título.
      S._wbLegend = { form: -1 };
      if (mgLike) {
         var fi = ccFont("display", 8.6 * sc, false, true), compB = !!S.compact;
         var forms = E ? ["frontera α alto / bajo (Weinberg+19, DR17)", "frontera α alto / bajo", "frontera α"] : ["high / low α boundary (Weinberg+19, DR17)", "high / low α boundary", "α boundary"];
         var flY = ccFont("text", 8.4 * sc, false, false, Math.round(8.4 * sc * 0.18));
         var hdrEnd = (compB && S._hdrEnd && ccIsNum(S._hdrEnd.B)) ? S._hdrEnd.B : w * 0.55 - 38 * sc;
         var rowsW = (compB && !ccPBroken("wbnarrow")) ? [[Math.round(22 * sc), hdrEnd], [P.T - 6 * sc, P.L + 8 * sc + flY.width(yLab + " ↑") + 16 * sc]] : [[Math.round(22 * sc), hdrEnd]];
         var nForms = (compB && !ccPBroken("wbnarrow")) ? forms.length : 1, wb = null;
         for (var fo = 0; fo < nForms && !wb; ++fo) for (var ro = 0; ro < rowsW.length && !wb; ++ro) {
            var lxx = w - 14 * sc - fi.width(forms[fo]);
            if (lxx - 26 * sc >= rowsW[ro][1] + 12 * sc) wb = { t: forms[fo], x: lxx, y: rowsW[ro][0], form: fo, row: ro, x0: lxx - 26 * sc, x1: lxx + fi.width(forms[fo]), after: rowsW[ro][1] };
         }
         if (wb) {
            g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.85), Math.max(1.2, 1.4 * sc), PenStyle_Dash); g.drawLine(wb.x - 26 * sc, wb.y - 4 * sc, wb.x - 6 * sc, wb.y - 4 * sc);
            ccHaloText(g, fi, ccInt(CC_ATLAS.gold, 0.85), wb.x, wb.y, wb.t, sc);
            ccHit(S, "B", wb.x0, wb.y - 12 * sc, wb.x1, wb.y + 4 * sc, forms[0] + ". " + ccT("tipB"));
            S._wbLegend = wb;
         }
      }
      var tr = []; for (var t in tracers) if (tracers.hasOwnProperty(t)) tr.push(t + " " + ccThou(tracers[t], CC_LANG));
      var segs = [ccThou(n, CC_LANG) + " " + (elB ? ccT("withEl").replace("%1", yLab) : (E ? "con [α/Fe]" : "with [α/Fe]"))];
      if (off) segs.push([ccThou(off, CC_LANG) + " " + ccT("offScaleShort"), ccThou(off, CC_LANG) + " " + ccT("offScale")]);
      // (24-oct, N1) «sin fondo: la nube es de gigantes» va ANTES de «de: …»: con cuatro surveys «de: …» no cabe y se llevaría el aviso al «?»
      var footSeg = (!mgLike) ? ccRefFoot(refB, yLab) : null, giantsNote = (!mgLike && refB.why === "giantsonly");
      if (giantsNote) segs.push(footSeg);
      // (24-oct, Gemini H4, pie con 0 pintadas) sin fuentes (tr vacío) el tramo «de: …» / «trazador: …» no se escribe. ROJO «emptyfrom»: «de: » vacío, como antes.
      if (tr.length || ccPBroken("emptyfrom")) segs.push((elB ? ccT("from") + ": " : (E ? "trazador: " : "tracer: ")) + tr.join(", "));
      if (mgLike) { if (typeof CC_REF_ALPHA !== "undefined") { footSeg = ccT("backdropNote") + ": APOGEE DR17 (" + ccNice(CC_REF_ALPHA.n, CC_LANG, 3) + ")"; segs.push(footSeg); } }
      else if (!giantsNote) segs.push(footSeg);
      if (S._refB && footSeg) { S._refB.foot = (typeof footSeg === "string") ? footSeg : footSeg[1]; S._refB.footShort = (typeof footSeg === "string") ? footSeg : footSeg[0]; }
      S._footB = segs;      // (las pruebas miran los tramos del pie de B)
      ccFoot(g, P, w, h, sc, segs, S, "B", "[Fe/H]", ccGloss("feh", CC_LANG));
      return;
   }
   var P2 = S.geomB || ccPlotXf(w, h, sc, AXX.x0, AXX.x1, AX.y0, AX.y1);
   ccPlotOverlay(g, P2, S, sc, getB, 0.85, "B", w, h);
}

var CC_AGE_AX = { x0: 14, x1: 0, y0: -1.6, y1: 0.6 };   // el pasado a la izquierda, como en la línea de tiempo
function ccPaintAgeMet(g, w, h, S, sc, part) {
   var st = S.res ? S.res.stars : [], list = ccClockList(S), i, s, E = CC_LANG === "es";
   if (part !== "over") {
      ccHitsReset(S, "C");
      ccFrame(g, w, h, sc);
      var top = ccPlotHeader(g, w, sc, S, "C", "panelC", "capC", "tipC");
      var P = ccPlotXf(w, h, sc, CC_AGE_AX.x0, CC_AGE_AX.x1, CC_AGE_AX.y0, CC_AGE_AX.y1, top, S.compact ? 34 * sc : 0);
      S.geomC = P;
      ccAxes(g, P, sc, "", "[Fe/H]", 0, 1, S, "C", null, ccGloss("feh", CC_LANG));
      if (!S.opts || S.opts.backdrop !== false) ccDrawRef(g, P, (typeof CC_REF_AGE !== "undefined") ? CC_REF_AGE : null, CC_ATLAS.text3, "age", true, sc);
      // la edad del Universo: nada puede quedar a su izquierda
      var xu = P.X(CC_SCI.UNIVERSE_GA), fu = ccFont("display", 8 * sc, false, true);
      g.pen = ccPen(ccInt(CC_ATLAS.text3, 0.8), 1, PenStyle_Dot); g.drawLine(xu, P.T, xu, P.T + P.ph);
      var getC = function(s2) { return (s2.age.adopted && s2.chem.feh) ? { x: s2.age.adopted.v, y: s2.chem.feh.v } : null; };
      var nA = 0, nB = 0, nC = 0, none = 0, edge = 0, nAge = 0, lim = 0, limBins = {};
      var errA = Math.max(0.06, 0.32 / Math.sqrt(Math.max(1, list.length / 60)));    // muchas barras: más tenues (si no, una banda blanca)
      for (i = 0; i < list.length; ++i) {
         s = st[list[i]];
         var a = s.age.adopted;
         if (a) ++nAge;
         if (!a || !s.chem.feh) { if (s.chem.feh) ++none; continue; }
         if (a.tier === "A") ++nA; else if (a.tier === "B") ++nB; else ++nC;
         var dim = S.group ? !S.group[s.idx] : false, y = P.Y(ccClamp(s.chem.feh.v, CC_AGE_AX.y0, CC_AGE_AX.y1));
         g.pen = ccPen(ccRgbInt(ccFehRgb(s.chem.feh.v), dim ? 0.05 : (a.tier === "C" ? errA * 0.5 : errA)), Math.max(1, 0.9 * sc));
         g.drawLine(P.X(ccClamp(a.lo, 0, CC_SCI.UNIVERSE_GA)), y, P.X(ccClamp(a.hi, 0, CC_SCI.UNIVERSE_GA)), y);
         if (a.v > CC_SCI.UNIVERSE_GA) { ++lim; var kb = Math.round(y / (2 * sc)); if (!limBins[kb]) limBins[kb] = { y: y, n: 0, feh: s.chem.feh.v, dim: true }; ++limBins[kb].n; if (!dim) limBins[kb].dim = false; continue; }
         if (ccPlotPoint(g, P, s, a.v, s.chem.feh.v, S, sc, dim, a.tier === "C" ? "faint" : false)) ++edge;
      }
      ccSunSymbol(g, P.X(4.57), P.Y(0), sc, false, ccSelXY(S, P, getC));
      // las del límite: una rayita por fila de 2 px, más opaca cuantas más haya (77 rayitas sueltas hacían un borrón blanco)
      for (var kb2 in limBins) if (limBins.hasOwnProperty(kb2)) { var LB = limBins[kb2]; g.pen = ccPen(ccRgbInt(ccFehRgb(LB.feh), LB.dim ? 0.06 : Math.min(0.55, 0.18 + 0.04 * LB.n)), Math.max(1, sc)); g.drawLine(xu - 5 * sc, LB.y, xu - 1 * sc, LB.y); }
      ccHaloText(g, fu, ccInt(CC_ATLAS.text2), xu + 3 * sc, P.T + 11 * sc, (E ? "13,8" : "13.8") + (lim ? (E ? " · " + ccThou(lim, "es") + " en el límite de los modelos" : " · " + ccThou(lim, "en") + " at the model limit") : ""), sc);
      var TH = function(v) { return ccThou(v, CC_LANG); };
      var segs = [TH(nA + nB + nC) + " " + (E ? "con edad y [Fe/H]" : "with age and [Fe/H]"), E ? TH(nA) + " calibradas · " + TH(nB) + " por isócronas en gigantes o subgigantes · " + TH(nC) + " por isócronas en enanas: orientativas (tenues)" : TH(nA) + " calibrated · " + TH(nB) + " from isochrones on giants or subgiants · " + TH(nC) + " from isochrones on dwarfs: indicative (faint)"];
      if (lim) segs.push(TH(lim) + " " + (E ? "en el límite de los modelos (rayitas junto a 13,8)" : "at the model limit (ticks at 13.8)"));
      if (edge) segs.push([TH(edge) + " " + ccT("offScaleShort"), TH(edge) + " " + ccT("offScale")]);
      segs.push(TH(none) + " " + (E ? "con [Fe/H] pero sin edad" : "with [Fe/H] but no age"));
      if (typeof CC_REF_AGE !== "undefined") segs.push(ccT("backdropNote") + ": Xiang & Rix 2022 (" + ccNice(CC_REF_AGE.n, CC_LANG, 3) + ")");
      ccFoot(g, P, w, h, sc, segs, S, "C", E ? "edad (Ga)" : "age (Gyr)", ccGloss("age", CC_LANG));
      return;
   }
   var P2 = S.geomC || ccPlotXf(w, h, sc, CC_AGE_AX.x0, CC_AGE_AX.x1, CC_AGE_AX.y0, CC_AGE_AX.y1);
   // (23-oct) el FRENTE DEL TIEMPO con el reloj del diálogo, como en el vídeo: lo que aún no ha nacido, a la derecha de la raya, velado
   if (ccClockOn(S)) {
      var xT = P2.X(ccClamp(S.clockT, 0, 14)), xr = P2.L + P2.pw, yv = P2.T + Math.round(16 * sc);
      if (xr - xT > 1) ccFillRect(g, xT, yv, xr, P2.T + P2.ph, ccInt(CC_ATLAS.bg, 0.55));
      g.pen = ccPen(ccInt(CC_ATLAS.text, 0.85), Math.max(1, 1.2 * sc)); g.drawLine(xT, P2.T, xT, P2.T + P2.ph);
   }
   ccPlotOverlay(g, P2, S, sc, function(s2) { var a2 = s2.age.adopted; return (a2 && s2.chem.feh) ? { x: Math.min(a2.v, CC_SCI.UNIVERSE_GA), y: s2.chem.feh.v, ex: a2.e, ey: s2.chem.feh.e } : null; }, 0.85, "C", w, h);
}

// ---------------------------------------------------------------------------
// D · FAMILIAS CINEMÁTICAS: E–Lz (Naidu et al. 2020) o Toomre
// ---------------------------------------------------------------------------
var CC_ELZ_AX = { x0: -3.5, x1: 3.0, y0: -1.9, y1: -0.6 };   // Lz en 10³ kpc km/s (prógrado > 0); E en 10⁵ km²/s²
var CC_TOOMRE_AX = { x0: -420, x1: 80, y0: -18, y1: 420 };     // (y0 −18: aire bajo 0, la elegida no se corta en el borde; revisor 22-oct)
var CC_GSE_BMP = null;
function ccGseBitmap() {
   if (CC_GSE_BMP) return CC_GSE_BMP;
   var G = ccGseGrid(CC_ELZ_AX.x0 * 1000, CC_ELZ_AX.x1 * 1000, CC_ELZ_AX.y0 * 1e5, CC_ELZ_AX.y1 * 1e5, 78, 52);
   var b = new Bitmap(G.nx, G.ny), c = ccHexRgb(CC_ATLAS.chart[4]);
   b.fill(0x00000000);
   for (var j = 0; j < G.ny; ++j) for (var i = 0; i < G.nx; ++i) { var e = G.v[j * G.nx + i]; if (e > CC_FAM.GSE_ECC) b.setPixel(i, G.ny - 1 - j, ccRgbInt(c, 0.16 + 0.10 * (e - 0.7) / 0.3)); }
   // y su borde e = 0,7 (en unidades del dibujo)
   var seg = ccMarch(G.v, G.nx, G.ny, CC_FAM.GSE_ECC, function(i) { return (G.x0 + (i + 0.5) * (G.x1 - G.x0) / G.nx) / 1000; }, function(j) { return (G.y0 + (j + 0.5) * (G.y1 - G.y0) / G.ny) / 1e5; });
   CC_GSE_BMP = { bmp: b, seg: seg };
   return CC_GSE_BMP;
}
function ccFamGet(s) { return (s.fam && s.fam.nominal) ? { x: s.fam.nominal.Lz / 1000, y: s.fam.nominal.E / 1e5 } : null; }
function ccToomreGet(s) { if (!s.kin) return null; var u = s.kin.uvwLsr; return { x: u[1], y: Math.sqrt(u[0] * u[0] + u[2] * u[2]) }; }
function ccPaintFamD(g, w, h, S, sc, part) {
   var st = S.res ? S.res.stars : [], list = ccClockList(S), i, s, E = CC_LANG === "es", toomre = (S.dView === "toomre");
   if (part !== "over") {
      ccHitsReset(S, "D");
      ccFrame(g, w, h, sc);
      // el conmutador E–Lz | Toomre (dos píldoras pintadas, arriba a la derecha)
      // (S.video, 22-oct: en un vídeo no hay conmutador que pulsar; el título ya dice cuál de los dos es)
      var fp = ccFont("text", 8.4 * sc, true), labs = (S.video === true && !ccVideoBroken()) ? [] : [["elz", ccT("viewElz")], ["toomre", ccT("viewToomre")]], px = w - 14 * sc;
      var pillsW = labs.length ? fp.width(labs[0][1]) + fp.width(labs[1][1]) + 36 * sc + 10 * sc : 0;
      var top = ccPlotHeader(g, w, sc, S, "D", toomre ? "panelDT" : "panelD", toomre ? "capDT" : "capD", toomre ? "tipDT" : "tipD", pillsW);
      for (i = labs.length - 1; i >= 0; --i) {
         var pw = fp.width(labs[i][1]) + 16 * sc, on = (labs[i][0] === (toomre ? "toomre" : "elz"));
         px -= pw;
         g.fillRoundedRect(px, 9 * sc, px + pw, 27 * sc, 40, 99, ccBrush(ccInt(on ? CC_ATLAS.gold : CC_ATLAS.surface2, on ? 0.9 : 1)));
         g.pen = ccPen(ccInt(on ? CC_ATLAS.gold : CC_ATLAS.line), 1); g.drawRoundedRect(px, 9 * sc, px + pw, 27 * sc, 40, 99);
         ccTextAt(g, fp, ccInt(on ? CC_ATLAS.ink : CC_ATLAS.text2), px + 8 * sc, 22 * sc, labs[i][1]);
         ccHit(S, "D", px, 9 * sc, px + pw, 27 * sc, "", "dview", labs[i][0]);
         px -= 4 * sc;
      }
      var AX = toomre ? CC_TOOMRE_AX : CC_ELZ_AX;
      var P = ccPlotXf(w, h, sc, AX.x0, AX.x1, AX.y0, AX.y1, top, S.compact ? 34 * sc : 0);
      S.geomD = P;
      var n = 0, off = 0, fz = ccFont("text", 7.6 * sc, false, false, Math.round(7.6 * sc * 0.18));
      if (!toomre) {
         ccAxes(g, P, sc, "", "E (10\u2075 km\u00b2/s\u00b2)", 1, 1, S, "D", null, ccGloss("family", CC_LANG));
         // la región de G-E (e > 0,7 en el plano) y su borde
         var GB = ccGseBitmap();
         g.smoothInterpolation = true;
         g.drawScaledBitmap(P.X(AX.x0), P.Y(AX.y1), P.X(AX.x1), P.Y(AX.y0), GB.bmp);
         g.antialiasing = true;
         g.pen = ccPen(ccInt(CC_ATLAS.chart[4], 0.8), Math.max(1, sc));
         for (i = 0; i < GB.seg.length; i += 4) g.drawLine(P.X(GB.seg[i]), P.Y(GB.seg[i + 1]), P.X(GB.seg[i + 2]), P.Y(GB.seg[i + 3]));
         // lo prohibido: por debajo de la órbita circular
         var cc = ccCircularCurve(), poly = [], lz;
         for (lz = AX.x0; lz <= AX.x1 + 1e-9; lz += 0.05) {
            var Lk = Math.abs(lz) * 1000, Ec = null;
            for (var k = 1; k < cc.length; ++k) if (cc[k][0] >= Lk) { var t = (Lk - cc[k - 1][0]) / (cc[k][0] - cc[k - 1][0]); Ec = cc[k - 1][1] + t * (cc[k][1] - cc[k - 1][1]); break; }
            if (Ec === null) Ec = cc[cc.length - 1][1];
            poly.push(new Point(P.X(lz), P.Y(ccClamp(Ec / 1e5, AX.y0, AX.y1))));
         }
         var fillP = poly.slice(); fillP.push(new Point(P.X(AX.x1), P.Y(AX.y0))); fillP.push(new Point(P.X(AX.x0), P.Y(AX.y0)));
         g.brush = ccBrush(ccInt("#000000", 0.45)); g.pen = ccPen(ccInt(CC_ATLAS.bg, 0), 1); g.fillPolygon(fillP); ccNoBrush(g);
         g.pen = ccPen(ccInt(CC_ATLAS.text3, 0.9), Math.max(1, sc)); g.drawPolyline(poly);
         // las cajas de Naidu+20 (traducidas a Lz prógrado > 0)
         // (22-oct, revisor: «WUK.», «THAM.» con punto y abreviados aunque cupieran) El nombre ENTERO si cabe en el ancho de su
         // caja; si no, la abreviatura sin punto; el nombre entero y qué es, siempre en su ayuda. I’itoi con su apóstrofo.
         // (23-oct, revisor R8: «WUK» en el diálogo y «WUKONG» en el vídeo, «G-E» y «GAIA-ENCELADUS (e > 0,7)»: UN criterio, el mismo a
         //  cualquier tamaño) El nombre ENTERO siempre; si no cabe en el ancho de su caja, partido por « · » en varias líneas; una palabra
         //  que no quepa sale de la caja por la derecha, con halo. Nunca una abreviatura. ROJO «boxabbr» de T18: las abreviaturas de antes.
         function box(x0, x1, y0, y1, hex, full, abbr, key) {
            var X0 = P.X(Math.max(AX.x0, x0)), X1 = P.X(Math.min(AX.x1, x1)), Y0 = P.Y(Math.min(AX.y1, y1)), Y1 = P.Y(Math.max(AX.y0, y0));
            g.fillRect(X0, Y0, X1, Y1, ccBrush(ccInt(hex, 0.07)));
            g.pen = ccPen(ccInt(hex, 0.8), Math.max(1, sc), PenStyle_Dash); g.drawRect(X0, Y0, X1, Y1);
            var room = Math.abs(X1 - X0) - 6 * sc, lines;
            if (ccPBroken("boxabbr")) lines = [(fz.width(full) <= room) ? full : abbr];
            else if (fz.width(full) <= room) lines = [full];
            else {
               var parts = full.split(" · "), cur = "";
               lines = [];
               for (var pi = 0; pi < parts.length; ++pi) { var tt = cur ? cur + " · " + parts[pi] : parts[pi]; if (cur && fz.width(tt) > room) { lines.push(cur + " ·"); cur = parts[pi]; } else cur = tt; }
               if (cur) lines.push(cur);
            }
            var lh = fz.ascent + fz.descent + 1, mw = 0;
            for (var li = 0; li < lines.length; ++li) { labQ.push([fz, ccInt(hex, 0.95), X0 + 3 * sc, Y0 + 10 * sc + li * lh, lines[li]]); mw = Math.max(mw, fz.width(lines[li])); }
            ccHit(S, "D", X0, Y0, X0 + mw + 8 * sc, Y0 + 4 * sc + lines.length * lh, ccFamGloss(key, CC_LANG));      // el nombre entero y qué es
            if (S.boxNames) S.boxNames.push(lines.join(" "));
         }
         S.boxNames = [];
         var labQ = [];          // (los rótulos de las cajas, de G-E y del disco: se pintan al final, con placa, encima de curvas y puntos)
         // (23-oct, G1: las cajas son las MISMAS que clasifican —CC_FAM de cc_dynamics.js, ya en la energía del potencial nuevo: las de
         //  Naidu + CC_NAIDU_DE—; antes, escritas a mano en la energía de gala v1, salían ~2 px desplazadas. Lz en 10³, E en 10⁵.
         //  Rojo «handboxes» de T20: las de antes, a mano)
         var FB = (typeof CC_FAM !== "undefined" && !ccPBroken("handboxes")) ? CC_FAM : { THAMNOS_LZ: [-1500, -200], THAMNOS_E: [-1.5e5, -1.3e5], RETRO_LZ: -700, RETRO_E: -1.25e5, WUKONG_LZ: [200, 1000], WUKONG_E: [-1.35e5, -0.9e5], HELMI_LZ: [750, 1700] };
         S.boxRects = {};
         var boxAt = function(key, x0, x1, y0, y1) { S.boxRects[key] = [x0, x1, y0, y1]; return [x0, x1, y0, y1]; };
         var bT = boxAt("thamnos", FB.THAMNOS_LZ[0] / 1e3, FB.THAMNOS_LZ[1] / 1e3, FB.THAMNOS_E[0] / 1e5, FB.THAMNOS_E[1] / 1e5);
         var bR = boxAt("retro", AX.x0, FB.RETRO_LZ / 1e3, FB.RETRO_E / 1e5, AX.y1);
         var bW = boxAt("wukong", FB.WUKONG_LZ[0] / 1e3, FB.WUKONG_LZ[1] / 1e3, FB.WUKONG_E[0] / 1e5, FB.WUKONG_E[1] / 1e5);
         var bH = boxAt("helmi", FB.HELMI_LZ[0] / 1e3, FB.HELMI_LZ[1] / 1e3, AX.y0, AX.y1);
         box(bT[0], bT[1], bT[2], bT[3], CC_ATLAS.chart[3], "THAMNOS", "THAM", "thamnos");
         box(bR[0], bR[1], bR[2], bR[3], CC_ATLAS.chart[1], "SEQUOIA · ARJUNA · I\u2019ITOI", "SEQ · ARJ · I\u2019IT", "retro");
         box(bW[0], bW[1], bW[2], bW[3], CC_ATLAS.chart[5], "WUKONG", "WUK", "wukong");
         box(bH[0], bH[1], bH[2], bH[3], CC_ATLAS.goldLight, "HELMI (+L\u22a5)", "HELMI", "helmi");
         // (R8/R20) «GAIA-ENCELADUS» a cualquier tamaño (el «e > 0,7» de su borde, en su ayuda: la raya de HELMI lo cruzaba en el vídeo); centrado
         // en Lz = 0 y, si no cabe, corrido a la izquierda para no pisar la caja de HELMI
         var glFull = E ? "GAIA-ENCELADUS (e > 0,7)" : "GAIA-ENCELADUS (e > 0.7)", gl = ccPBroken("boxabbr") ? ((fz.width(glFull) <= P.pw * 0.34) ? glFull : "G-E") : "GAIA-ENCELADUS";
         var glX = P.X(0) - fz.width(gl) / 2;
         if (!ccPBroken("boxabbr")) glX = Math.max(P.L + 4 * sc, Math.min(glX, P.X(bH[0]) - 6 * sc - fz.width(gl)));
         labQ.push([fz, ccInt(CC_ATLAS.chart[4], 0.95), glX, P.Y(-1.78), gl]);
         ccHit(S, "D", glX - 4 * sc, P.Y(-1.78) - 12 * sc, glX + fz.width(gl) + 4 * sc, P.Y(-1.78) + 4 * sc, glFull + ": " + ccFamGloss("gse", CC_LANG));
         if (S.boxNames) S.boxNames.push(gl);
         labQ.push([fz, ccInt(CC_ATLAS.text, 0.6), P.X(2.4), P.Y(-1.62), E ? "DISCO" : "DISC"]);
         // el Sol
         var sun = ccDynState(0, 0, 0.001, 0, 0, 0);     // (la estrella en el Sol: E y Lz del propio Sol)
         for (i = 0; i < list.length; ++i) {
            s = st[list[i]];
            var v = ccFamGet(s);
            if (!v) continue;
            ++n;
            if (ccPlotPoint(g, P, s, v.x, v.y, S, sc, S.group ? !S.group[s.idx] : false, false)) ++off;
         }
         ccSunSymbol(g, P.X(sun.Lz / 1000), P.Y(sun.E / 1e5), sc, false, ccSelXY(S, P, ccFamGet));
         S.famPlates = [];
         for (var lq = 0; lq < labQ.length; ++lq) { var Q = labQ[lq]; S.famPlates.push(ccPlateText(g, Q[0], Q[1], Q[2], Q[3], Q[4], sc)); S.famPlates[lq].t = Q[4]; }
         var nf = {}; for (i = 0; i < list.length; ++i) { s = st[list[i]]; if (s.fam && s.fam.accreted && s.fam.p >= CC_SCI.FAM_P) nf[s.fam.best] = (nf[s.fam.best] || 0) + 1; }
         var fl = []; for (var kf in nf) if (nf.hasOwnProperty(kf)) fl.push(CC_FAM_NAME[E ? "es" : "en"][kf] + " " + ccThou(nf[kf], CC_LANG));
         var segsD = [ccThou(n, CC_LANG) + " " + (E ? "con órbita" : "with an orbit"), (E ? "acretadas probables: " : "probably accreted: ") + (fl.length ? fl.join(", ") : (E ? "ninguna" : "none"))];
         segsD.push(E ? "se pintan las estrellas con [Fe/H] o edad; la cabecera cuenta todas las del encuadre" : "only stars with [Fe/H] or age are drawn; the header counts every star in the frame");
         if (off) segsD.splice(1, 0, [ccThou(off, CC_LANG) + " " + ccT("offScaleShort"), ccThou(off, CC_LANG) + " " + ccT("offScale")]);
         segsD.push(E ? "regiones de Naidu+20 (en E, al potencial nuevo); MilkyWayPotential2022 de gala" : "regions of Naidu+20 (E shifted to the new potential); gala MilkyWayPotential2022");
         ccFoot(g, P, w, h, sc, segsD, S, "D", "Lz (10\u00b3 kpc km/s)", ccGloss("family", CC_LANG));
      } else {
         ccAxes(g, P, sc, "", "\u221a(U\u00b2+W\u00b2) (km/s)", 0, 0, S, "D", null, ccGloss("kinematics", CC_LANG));
         g.antialiasing = true;
         var radii = [50, 100, 200, 300, 400], fr = ccFont("mono", 7.6 * sc);
         for (i = 0; i < radii.length; ++i) {
            var r = radii[i], pts = [];
            for (var an = 0; an <= Math.PI + 1e-9; an += Math.PI / 90) { var vx = r * Math.cos(an), vy = r * Math.sin(an); if (vx >= AX.x0 && vx <= AX.x1 && vy <= AX.y1) pts.push(new Point(P.X(vx), P.Y(vy))); }
            g.pen = ccPen(ccInt(CC_ATLAS.text3, 0.55), 1, PenStyle_Dash); if (pts.length > 1) g.drawPolyline(pts);
         }
         for (i = 0; i < list.length; ++i) {
            s = st[list[i]];
            var tv = ccToomreGet(s);
            if (!tv) continue;
            ++n;
            if (ccPlotPoint(g, P, s, tv.x, tv.y, S, sc, S.group ? !S.group[s.idx] : false, false)) ++off;
         }
         var segsT = [ccThou(n, CC_LANG) + " " + (E ? "con velocidad 3D" : "with a 3D velocity")];
         if (off) segsT.push([ccThou(off, CC_LANG) + " " + ccT("offScaleShort"), ccThou(off, CC_LANG) + " " + ccT("offScale")]);
         segsT.push(E ? "círculos: velocidad total de 50, 100, 200, 300 y 400 km/s respecto al reposo local (cada uno corta el eje en −50 … −400)" : "circles: total speed of 50, 100, 200, 300 and 400 km/s relative to local rest (each crosses the axis at −50 … −400)");
         segsT.push(E ? "se pintan las estrellas con [Fe/H] o edad; la cabecera cuenta todas las del encuadre" : "only stars with [Fe/H] or age are drawn; the header counts every star in the frame");
         ccFoot(g, P, w, h, sc, segsT, S, "D", "V (km/s)", ccGloss("kinematics", CC_LANG));
      }
      return;
   }
   var P2 = S.geomD;
   if (!P2) return;
   ccPlotOverlay(g, P2, S, sc, toomre ? ccToomreGet : ccFamGet, 0.85, "D", w, h);
}

// EL RESPLANDOR de la elegida (22-oct, revisor: «se corta en rectángulo al borde del eje» y «apaga los rótulos»): columnas de 2 px
// con perfil gaussiano (o plano, `flat`, para el intervalo de una edad orientativa), que se DESVANECEN hacia arriba y abajo y en los
// 14 px junto a los bordes (13,8 Ga y hoy). Los rótulos se pintan después, encima.
function ccGlow(g, cx, half, xLo, xHi, yTop, yBot, sc, peak, flat) {
   var colW = Math.max(1, Math.round(2 * sc)), span = flat ? half + 10 * sc : Math.max(1, half) * 2.4, nb = 6, a0 = Math.min(xLo, xHi), a1 = Math.max(xLo, xHi);
   for (var x = Math.floor(cx - span); x < cx + span; x += colW) {
      if (x < a0 || x + colW > a1) continue;
      var d = (x + colW / 2 - cx) / Math.max(1, half), a = flat ? peak * ccClamp((span - Math.abs(x + colW / 2 - cx)) / (10 * sc), 0, 1) : peak * Math.exp(-0.5 * d * d);
      a *= ccClamp(Math.min(x - a0, a1 - x - colW) / (14 * sc), 0, 1);
      if (a < 0.004) continue;
      for (var k = 0; k < nb; ++k) {
         var y0 = yTop + (yBot - yTop) * k / nb, y1 = yTop + (yBot - yTop) * (k + 1) / nb, m = Math.sin(Math.PI * (k + 0.5) / nb);
         g.fillRect(x, y0, x + colW, y1, ccBrush(ccInt(CC_ATLAS.gold, a * (0.25 + 0.75 * m))));
      }
   }
}
// ---------------------------------------------------------------------------
// LA LÍNEA DE TIEMPO
// ---------------------------------------------------------------------------
function ccPaintTimeline(g, w, h, S, sc) {
   ccHitsReset(S, "T");
   ccFrame(g, w, h, sc);
   var E = CC_LANG === "es", L = Math.round(26 * sc), R = Math.round(26 * sc);
   var axY = h - Math.round(30 * sc), X = function(ga) { return L + (14 - ga) / 14 * (w - L - R); };
   var capEnd;
   if (S && S.compact) {
      // (CabraComposition, 22-oct: la línea de tiempo va bajo la ficha, más baja; la frase llana, en la línea del título si cabe)
      // (la frase llana, en el «?» del título, como en B, C y D)
      var tEnd = ccPanelTitle(g, Math.round(14 * sc), Math.round(20 * sc), ccT("timeline"), sc);
      ccTitleHelp(g, tEnd + 10 * sc, Math.round(20 * sc), sc, S, "T", "capT", "tipT");
      capEnd = Math.round(20 * sc);
   } else {
      ccPanelTitle(g, Math.round(14 * sc), Math.round(22 * sc), ccT("timeline"), sc);
      capEnd = ccCaption(g, Math.round(14 * sc), Math.round(40 * sc), w - 28 * sc, "capT", "tipT", sc, S, "T");
   }
   g.pen = ccPen(ccInt(CC_LINE_STRONG), 1); g.drawLine(L, axY, w - R, axY);
   var f = ccFont("mono", 8.2 * sc), relabel = [];
   for (var ga = 0; ga <= 14; ga += 2) {
      var x = X(ga);
      g.drawLine(x, axY, x, axY + 4 * sc);
      var lab = (ga === 0) ? ccT("today") : ga + " " + ccAgeUnit(CC_LANG);
      relabel.push([f, ccInt(CC_ATLAS.text3), x - f.width(lab) / 2, axY + 15 * sc, lab]);     // (encima del resplandor)
   }
   var st = S.res ? S.res.stars : [], list = S.list || [];
   var sel = (S.sel >= 0 && st[S.sel]) ? st[S.sel] : null, selFam = ccHomeFamily(sel);      // (24-oct, H5: una sola regla con el vídeo de II; con famTension, no)
   // (23-oct, P5) las otras fusiones con fecha publicada (CC_MERGERS de cc_science.js: Sequoia y las corrientes de Helmi), con su color
   // y su fuente en la ayuda de la banda: Sequoia en el carril del Big Bang (no pisa nada: 9,8–8,9 Ga) y Helmi en uno propio, encima
   // del Sol. Solo en CabraComposition (S.compact; CabraStarAnalysis pinta esta línea de tiempo en 93 px: no caben cinco carriles).
   var EV = CC_TIMELINE.slice(), merg = !!(S && S.compact) && typeof CC_MERGERS !== "undefined" && !ccPBroken("nomergers");
   if (merg) EV = EV.concat(ccMergerEvents());      // (la lista, una sola: cc_science.js; la usa también la línea de tiempo del vídeo)
   // (24-oct, B2 = a de Nino) el RELOJ del diálogo (S.clockT: la vista previa / grabación de II) enciende la banda del episodio en curso, igual
   //  para los de CC_TIMELINE que para Sequoia y las corrientes de Helmi, como en la línea de tiempo del vídeo. ROJO «nomerglit»: las fusiones
   //  de CC_MERGERS no se encienden con el reloj (como antes de B2); «noclocklit»: ningún episodio.
   var clk = (S && typeof S.clockT === "number" && S.clockT >= 0 && !ccPBroken("noclocklit")) ? S.clockT : null;
   S._tlLit = {};
   var lanes = merg ? { bigbang: 0, sgr: 0, sequoia: 0, halo: 1, gse: 1, thick: 2, thin: 2, helmi: 3, sun: 4 } : { bigbang: 0, sgr: 0, halo: 1, gse: 1, thick: 2, thin: 2, sun: 3 };
   var nLanes = merg ? 5 : 4, sunLane = nLanes - 1;
   var top = capEnd + 12 * sc, laneGap = Math.max(17 * sc, (axY - 16 * sc - top) / nLanes), laneH = Math.min(22 * sc, laneGap - 4 * sc);
   var fz = ccFont("text", 8.2 * sc), fi = ccFont("display", 9 * sc, false, true);
   var col = { bigbang: CC_ATLAS.text, halo: CC_ATLAS.chart[1], gse: CC_ATLAS.chart[4], thick: CC_ATLAS.gold, thin: CC_ATLAS.chart[5], sgr: CC_ATLAS.chart[3], sun: CC_ATLAS.gold,
               sequoia: CC_ATLAS.chart[2], helmi: ccMix(CC_ATLAS.chart[1], CC_ATLAS.chart[3], 0.5) };
   var sunLabelLeft = false;
   if (sel && sel.age.adopted) { var mx = X(ccClamp(sel.age.adopted.v, 0, 14)); sunLabelLeft = (mx > X(4.57) && mx < X(4.57) + 140 * sc); }
   for (var i = 0; i < EV.length; ++i) {
      var ev = EV[i], y = top + lanes[ev.key] * laneGap, x0 = X(ev.from), x1 = X(ev.to), name = E ? ev.es : ev.en;
      if (ev.from === ev.to) {
         if (ev.key === "sun") {
            ccSunSymbol(g, x0, y + laneH / 2, sc * 0.9, true);
         } else { g.pen = ccPen(ccInt(col[ev.key], 0.7), 1); g.drawLine(x0, top - 2 * sc, x0, axY); relabel.push([fi, ccInt(CC_ATLAS.text2), x0 + 4 * sc, y + laneH - 3 * sc, name]); }
         ccHit(S, "T", x0 - 6 * sc, y, x0 + 8 * sc + fi.width(name), y + laneH, name + " · " + ccAgeLocalize(ev.ref, CC_LANG));
         continue;
      }
      // la banda de la galaxia natal de una estrella acretada se ILUMINA
      var litHome = !!selFam && selFam === ev.key && (ev.key === "gse" || ev.key === "sgr" || ev.key === "sequoia" || ev.key === "helmi");
      var litClk = clk !== null && clk <= ev.from && clk >= ev.to && !(ev.merger && ccPBroken("nomerglit")), lit = litHome || litClk;
      if (lit) S._tlLit[ev.key] = (litHome ? "h" : "") + (litClk ? "c" : "");      // (las pruebas lo leen: h = galaxia natal de la elegida, c = el reloj)
      g.fillRoundedRect(x0, y, x1, y + laneH, 30, 60, ccBrush(ccInt(col[ev.key], lit ? 0.55 : 0.22)));
      g.pen = ccPen(ccInt(lit ? CC_ATLAS.goldLight : col[ev.key], lit ? 1 : 0.55), lit ? Math.max(1.5, 1.6 * sc) : 1); g.drawRoundedRect(x0, y, x1, y + laneH, 30, 60);
      var bandW = Math.abs(x1 - x0) - 16 * sc, txt = name;     // (6 px a la izquierda y 10 a la derecha: «Pasos de Sagitario» tocaba el borde)
      // (compacto, 22-oct: SIEMPRE el nombre corto —el mismo en la ventana, en la exportada y en EN: «Protogalaxia» / «Proto-Galaxy»—;
      //  el nombre entero y su referencia, en la ayuda de la banda)
      if ((S.compact || fz.width(txt) > bandW) && ev.short) txt = E ? ev.short[1] : ev.short[0];
      // (Sequoia dura 0,9 Ga: su nombre no cabe dentro; va a su DERECHA, en su carril —libre hasta Sagitario, 6 Ga—; encendida, con
      //  «← galaxia natal» detrás)
      var outside = (ev.key === "sequoia" && fz.width(txt) > bandW && ev.short) ? (E ? ev.short[1] : ev.short[0]) : "";
      if (!outside && fz.width(txt) > bandW) txt = ({ gse: "G-E", halo: "Halo", thick: E ? "Grueso" : "Thick", thin: E ? "Fino" : "Thin", sgr: "Sgr" })[ev.key] || "";
      if (!outside && txt && fz.width(txt) <= bandW) relabel.push([fz, ccInt(litClk ? CC_ATLAS.goldLight : CC_ATLAS.text, 0.95), x0 + 6 * sc, y + laneH - 4 * sc, txt]);
      // (23-oct, noche, revisión visual 8: era el único rótulo en rojo; ahora con el color y la letra de los demás, fuera porque no cabe)
      if (outside && !litHome && x1 + 6 * sc + fz.width(outside) < X(6.0) - 6 * sc) relabel.push([fz, ccPBroken("seqred") ? ccInt(col.sequoia, 0.95) : ccInt(litClk ? CC_ATLAS.goldLight : CC_ATLAS.text, 0.95), x1 + 5 * sc, y + laneH - 4 * sc, outside]);
      if (litHome) { var gl = (outside ? outside + " " : "") + "← " + ccT(ccFamFirm(sel.fam) ? "galaxyHome" : "galaxyHomeMaybe"); relabel.push([fi, ccInt(CC_ATLAS.goldLight), x1 + 6 * sc, y + laneH - 4 * sc, gl]); }
      ccHit(S, "T", Math.min(x0, x1), y, Math.max(x0, x1), y + laneH, name + " · " + ccAgeLocalize(ev.ref, CC_LANG));
   }
   // «Nace el Sol», al lado que no choque con el marcador de la elegida
   var sunY = top + sunLane * laneGap + laneH / 2, sx = X(4.57), sl = E ? "Nace el Sol" : "The Sun is born";
   relabel.push([fi, ccInt(CC_ATLAS.text, 0.9), sunLabelLeft ? sx - 8 * sc - fi.width(sl) : sx + 8 * sc, sunY + 4 * sc, sl]);     // (encima del resplandor)
   // las edades del campo: una raya por estrella (hasta 13,8 Ga: nada antes del Big Bang)
   var baseY = axY - 3 * sc;
   for (i = 0; i < list.length; ++i) {
      var s = st[list[i]], a = s.age.adopted;
      if (!a) continue;
      var c = CC_POP_COLOR[s.pop.label] || CC_ATLAS.text3, xa = X(ccClamp(a.v, 0, CC_SCI.UNIVERSE_GA));
      g.pen = ccPen(ccInt(c, a.tier === "C" ? 0.22 : 0.55), Math.max(1, sc));
      g.drawLine(xa, baseY, xa, baseY - (a.tier === "C" ? 5 : 9) * sc);
   }
   if (sel && sel.age.adopted) {
      var A = sel.age.adopted, an = S.anim || {};
      var p = ccEase(ccIsNum(an.sel) ? an.sel : 1);
      var from = ccIsNum(an.tlFrom) ? an.tlFrom : A.v, v = from + (A.v - from) * p;
      var cx = X(ccClamp(v, 0, CC_SCI.UNIVERSE_GA)), half = Math.abs(X(0) - X(Math.max(0.05, A.e))), vagueA = ccAgeVague(A);
      if (vagueA) {
         // (orientativa o muy incierta: una banda TENUE con el intervalo y una marca FINA en el valor; el resplandor ancho tapaba
         // media linea de tiempo —revision del 15-oct—)
         var rg = ccAgeRange(A), xa0 = X(rg[1]), xa1 = X(rg[0]);
         if (S.compact) ccGlow(g, (xa0 + xa1) / 2, Math.abs(xa1 - xa0) / 2, X(CC_SCI.UNIVERSE_GA), X(0), top - 4 * sc, axY, sc, 0.09, true);
         else g.fillRect(Math.min(xa0, xa1), top - 4 * sc, Math.max(xa0, xa1), axY, ccBrush(ccInt(CC_ATLAS.gold, 0.07)));
         g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.45), 1, PenStyle_Dash); g.drawLine(xa0, top - 4 * sc, xa0, axY); g.drawLine(xa1, top - 4 * sc, xa1, axY);
         g.pen = ccPen(ccInt(CC_ATLAS.gold, 0.9), Math.max(1, sc)); g.drawLine(cx, top - 4 * sc, cx, axY);
      } else {
         var steps = S.compact ? 0 : 36;
         if (S.compact) ccGlow(g, cx, half, X(CC_SCI.UNIVERSE_GA), X(0), top - 4 * sc, axY, sc, 0.32, false);
         for (var k = steps; k >= 1; --k) {
            var wk = half * 2.2 * k / steps, aa = (0.10 * Math.exp(-0.5 * Math.pow(wk / Math.max(1, half), 2)) + 0.012) * 14 / steps;
            g.fillRect(Math.max(X(CC_SCI.UNIVERSE_GA), cx - wk), top - 4 * sc, Math.min(X(0), cx + wk), axY, ccBrush(ccInt(CC_ATLAS.gold, aa)));
         }
         g.pen = ccPen(ccInt(CC_ATLAS.gold), Math.max(1.5, 1.8 * sc)); g.drawLine(cx, top - 4 * sc, cx, axY);
      }
      g.antialiasing = true;
      g.fillCircle(cx, axY, (vagueA ? 3.2 : 4.5) * sc, ccBrush(ccInt(CC_ATLAS.gold)));
      // (27-oct, R1b) el rótulo es el mismo texto que el detalle de la ficha (ccAgeText); con «sci-nouniv», lo de antes (el rojo)
      var tl = ccSciBroken("sci-nouniv") ? (vagueA ? ccAgeRangeText(A, CC_LANG) : ccDec(A.v, 1, CC_LANG) + " ± " + ccDec(A.e, 1, CC_LANG) + " " + ccAgeUnit(CC_LANG)) : ccAgeText(A, CC_LANG), fb = ccFont("mono", 9 * sc, true), tw = fb.width(tl);
      var ly = sunY + 4 * sc, tx = cx + 9 * sc;
      var sunX0 = sunLabelLeft ? sx - 8 * sc - fi.width(sl) : sx - 8 * sc, sunX1 = sunLabelLeft ? sx + 8 * sc : sx + 12 * sc + fi.width(sl);
      if (tx + tw > w - R || (tx < sunX1 && tx + tw > sunX0)) tx = cx - 9 * sc - tw;
      if (tx < L || (tx < sunX1 && tx + tw > sunX0)) tx = Math.min(w - R - tw, cx + 9 * sc);
      if (tx < sunX1 && tx + tw > sunX0) ly -= 18 * sc;      // (si aun pisa «Nace el Sol», un renglon mas arriba: revision del 15-oct)
      g.fillRoundedRect(tx - 5 * sc, ly - 12 * sc, tx + tw + 5 * sc, ly + 4 * sc, 30, 60, ccBrush(ccInt(CC_ATLAS.bg, 0.92)));
      ccTextAt(g, fb, ccInt(CC_ATLAS.goldLight), tx, ly, tl);
   }
   // (23-oct, noche: el cursor del reloj, ANTES que los rótulos y por detrás de ellos —no corta «Disco grueso»—; ROJO «cursorcut»: después)
   var boxesT = relabel.map(ccLabelBox);
   if (!ccPBroken("cursorcut")) ccClockCursor(g, w, h, S, sc, X, top, axY, boxesT);
   for (var rl = 0; rl < relabel.length; ++rl) ccTextAt(g, relabel[rl][0], relabel[rl][1], relabel[rl][2], relabel[rl][3], relabel[rl][4]);
   if (ccPBroken("cursorcut")) ccClockCursor(g, w, h, S, sc, X, top, axY, null);
   S._tlLabels = relabel.map(function(q) { var b = ccLabelBox(q); return { t: q[4], c: q[1], x0: b[0], y0: b[1], x1: b[2], y1: b[3] }; });
   ccTipBubble(g, w, h, S, "T", sc);
}
// (23-oct) EL CURSOR del reloj del diálogo en la línea de tiempo: lo que aún no ha pasado, velado; la raya y su triángulo; «hace 4,6 Ga».
// Gran recorrido: la edad de la visitada (S.clockVisit), en oro. Apunta S._tlCursor = { x, T } (las pruebas lo leen).
function ccClockCursor(g, w, h, S, sc, X, top, axY, boxes) {
   S._tlCursor = null;
   var E = CC_LANG === "es", f = ccFont("text", 8.4 * sc, true), U = CC_SCI.UNIVERSE_GA, t;
   if (S && typeof S.clockT === "number" && S.clockT >= 0 && !(typeof ccBroken === "function" && ccBroken("notlcursor"))) {
      var T = ccClamp(S.clockT, 0, U), xt = X(T), xr = X(0);
      if (xr - xt > 1) g.fillRect(xt, top - 4 * sc, xr, axY, ccBrush(ccInt(CC_ATLAS.surface, 0.62)));
      g.pen = ccPen(ccInt(CC_ATLAS.text, 0.95), Math.max(1.5, 1.6 * sc)); ccVLineBehind(g, xt, top - 6 * sc, axY + 2 * sc, boxes, 2 * sc);
      g.antialiasing = true; g.brush = ccBrush(ccInt(CC_ATLAS.text)); g.pen = ccPen(ccInt(CC_ATLAS.text), 1);
      g.fillPolygon([new Point(xt - 5 * sc, top - 9 * sc), new Point(xt + 5 * sc, top - 9 * sc), new Point(xt, top - 3 * sc)]); ccNoBrush(g);
      t = ccAgeAgoText(T, CC_LANG, "run");      // (R3, 26-oct: la MISMA función que los vídeos; sin «Ma»)
      var tw = f.width(t), tx = (xt + 8 * sc + tw < w - 8 * sc) ? xt + 8 * sc : xt - 8 * sc - tw;
      g.fillRoundedRect(tx - 4 * sc, top - 20 * sc, tx + tw + 4 * sc, top - 6 * sc, 30, 60, ccBrush(ccInt(CC_ATLAS.bg, 0.92)));
      ccTextAt(g, f, ccInt(CC_ATLAS.text), tx, top - 9 * sc, t);
      S._tlCursor = { x: xt, T: T, label: t };
   } else if (S && typeof S.clockVisit === "number" && S.res && S.res.stars[S.clockVisit] && S.res.stars[S.clockVisit].age.adopted) {
      var A = S.res.stars[S.clockVisit].age.adopted, xv = X(ccClamp(A.v, 0, U));
      g.pen = ccPen(ccInt(CC_ATLAS.gold), Math.max(1.5, 1.8 * sc)); ccVLineBehind(g, xv, top - 6 * sc, axY, boxes, 2 * sc);
      g.antialiasing = true; g.fillCircle(xv, axY, 4.5 * sc, ccBrush(ccInt(CC_ATLAS.gold)));
      S._tlCursor = { x: xv, T: A.v, visit: S.clockVisit };
   }
}

// (la franja de «E plegada» —D1-A, 22-oct— desapareció el 23-oct: la línea de tiempo va bajo la foto y no se pliega; R9)

// ---------------------------------------------------------------------------
// LA FICHA: titular + historia en llano + detalle técnico plegable
// ---------------------------------------------------------------------------
function ccPaintCard(g, w, h, S, sc) {
   ccHitsReset(S, "card");
   S.cardBar = null;                   // (5-nov: la geometría de la barra pintada, solo si hay más contenido que alto; ccBarMake)
   S.cardFamKeys = {};                // (las familias químicas que enseña la ficha: clave -> miembros, para el clic)
   ccFillRect(g, 0, 0, w, h, ccInt(CC_ATLAS.surface));
   var E = CC_LANG === "es", pad = Math.round(14 * sc), x = pad, W = w - 2 * pad, i;
   var st = S.res ? S.res.stars : [];
   if (!(S.sel >= 0) || !st[S.sel]) {
      var fe = ccFont("display", 11 * sc, false, true);
      var msg = !S.res ? ccT("noImage") : ((S.list && S.list.length === 0) ? ccT("noStars") : ccT("noSel"));
      var ml = ccWrap(fe, msg, W);
      for (i = 0; i < ml.length; ++i) ccTextAt(g, fe, ccInt(CC_ATLAS.text3), x, pad + 14 * sc + i * 16 * sc, ml[i]);
      return 0;
   }
   var s = st[S.sel], p = ccEase(S.anim && ccIsNum(S.anim.card) ? S.anim.card : 1);
   var A = function(a) { return a * p; };
   var scroll = Math.max(0, S.cardScroll || 0);
   if (S.compact && !(typeof ccBroken === "function" && ccBroken("cutrows"))) CC_ROWS = [];          // (compacto: se apuntan las filas para cortar por filas enteras, abajo)
   try {
   var y = pad + Math.round((1 - p) * 14 * sc) - scroll;
   var fT = ccFont("display", 15 * sc), fS = ccFont("text", 8.4 * sc, false, false, Math.round(8.4 * sc * 0.2)), fB = ccFont("display", 11.5 * sc, false, true);
   var fStory = ccFont("text", 9.4 * sc), fM = ccFont("mono", 9 * sc), fMb = ccFont("mono", 9.6 * sc, true), fSm = ccFont("text", 8.2 * sc, false, true);
   // cabecera
   // (26-oct) el nombre es un enlace a SIMBAD (ccLinkOfStar; sin csh_link.js o en el rojo «nolink», el texto de siempre)
   var nmL = ccLinkOfStar(s, ccStarName(s));
   S.cardLink = null;
   if (nmL) {
      var nmR = ccLinkPaintName(g, fT, x, y + 15 * sc, nmL, W, sc, S.cardLinkHot === true, A(1));
      S.cardLink = { link: nmL, rect: nmR };
      ccHit(S, "card", nmR.x0, nmR.y0, nmR.x1, nmR.y1, ccLinkTip(nmL), "simbad", nmL.url);
   } else ccTextAt(g, fT, ccInt(CC_ATLAS.text, A(1)), x, y + 15 * sc, ccElide(fT, ccStarName(s), W));
   y += 22 * sc;
   // (23-oct: sin G —Gaia dudoso la descarta— la línea empezaba por «  ·  »: se unen solo los trozos que hay)
   var subP = []; if (s.hip > 0 && s.hipLabel && s.id) subP.push("Gaia DR3 " + s.id);      // (27-oct, D4: con el nombre de Hipparcos arriba, el id de Gaia no se pierde)
   if (ccIsNum(s.g)) subP.push("G " + ccFmtL(s.g, 2)); if (ccIsNum(s.chem.teff)) subP.push("Teff " + Math.round(s.chem.teff / 10) * 10 + " K"); if (ccIsNum(s.chem.logg)) subP.push("logg " + ccFmtL(s.chem.logg, 1));
   var sub = ccElide(fM, subP.join("  ·  "), W);
   ccTextAt(g, fM, ccInt(CC_ATLAS.text3, A(1)), x, y + 10 * sc, sub);
   // (23-oct) el número de Gaia que dio APOGEE/GALAH es de OTRA estrella: una insignia junto a G (su distancia, pm y G se descartaron)
   var CW = ccCardWarnings(s, CC_LANG), xw = ccCardWarn(CW, "xmatch");
   S._cardWarn = CW.map(function(q) { return q.key; });
   S._cardWarnDrawn = [];
   if (xw) {
      var fBd = ccFont("text", 8 * sc, true, false, Math.round(8 * sc * 0.15)), bt = "⚠ " + ccCaps(xw.text), bx0 = x + fM.width(sub) + 10 * sc, bw0 = fBd.width(bt) + 14 * sc;
      if (bx0 + bw0 + 18 * sc > x + W) { y += 16 * sc; bx0 = x; }
      g.fillRoundedRect(bx0, y - 1 * sc, bx0 + bw0, y + 14 * sc, 40, 99, ccBrush(ccInt(CC_ATLAS.warn, A(0.18))));
      g.pen = ccPen(ccInt(CC_ATLAS.warn, A(0.8)), 1); g.drawRoundedRect(bx0, y - 1 * sc, bx0 + bw0, y + 14 * sc, 40, 99);
      ccTextAt(g, fBd, ccInt(CC_ATLAS.warn, A(1)), bx0 + 7 * sc, y + 10 * sc, bt);
      ccQMark(g, bx0 + bw0 + 4 * sc, y + 11 * sc, sc, S);
      ccHit(S, "card", bx0, y - 2 * sc, bx0 + bw0 + 18 * sc, y + 15 * sc, xw.tip);
      S._cardWarnDrawn.push("xmatch");
   }
   y += 18 * sc;
   g.pen = ccPen(ccInt(CC_ATLAS.gold, A(0.5)), 1); g.drawLine(x, y, x + W, y); g.drawLine(x, y + 2, x + W * 0.35, y + 2);
   y += 12 * sc;
   // el titular
   var lines = ccWrap(fB, ccEsDigits(ccBiography(s, CC_LANG, true)), W);
   for (i = 0; i < lines.length; ++i) { ccTextAt(g, fB, ccInt(CC_ATLAS.goldLight, A(1)), x, y + 13 * sc, lines[i]); y += 17 * sc; }
   y += 6 * sc;
   // la historia en llano, por párrafos
   var story = ccStory(s, CC_LANG), lastG = -1, para = "";
   function flush() {
      if (!para) return;
      var pl = ccWrap(fStory, para, W);
      for (var k = 0; k < pl.length; ++k) { ccTextAt(g, fStory, ccInt(CC_ATLAS.text2, A(1)), x, y + 12 * sc, pl[k]); y += 15 * sc; }
      y += 6 * sc; para = "";
   }
   for (i = 0; i < story.length; ++i) { if (story.g[i] !== lastG) { flush(); lastG = story.g[i]; } para += (para ? " " : "") + story[i]; }
   flush();
   // LA FAMILIA QUÍMICA (22-oct, fase 1: lo que era el grupo III). Clic en la línea = resaltarla en los paneles (otra vez = quitarlo);
   // la línea base del campo y el aviso de Ness+18, en su «?».
   y = ccCardChemFamily(g, x, y, W, s, S, sc, A);
   // el conmutador del detalle técnico
   y += 2 * sc;
   var open = !!S.cardDetail, tl = (open ? "▾ " : "▸ ") + ccCaps(ccT("moreDetail"));
   g.pen = ccPen(ccInt(CC_ATLAS.line, A(1)), 1); g.drawLine(x, y, x + W, y);
   ccTextAt(g, fS, ccInt(CC_ATLAS.gold, A(1)), x, y + 16 * sc, tl);
   ccHit(S, "card", x, y, x + W, y + 22 * sc, "", "detail", !open);
   y += 26 * sc;
   if (open) y = ccCardTechnical(g, x, y, W, s, S, sc, A);
   if (!open || S.cardBoth) {          // (S.cardBoth: la exportada, si cabe, lleva el detalle Y el campo —cc_dialog.js D.exportCard—)
      // la ficha plegada deja sitio: el campo entero en tres o cuatro frases llanas
      var fstory = ccFieldStory(S.res, CC_LANG, !!(S.photo && S.photo.bitmap));
      if (fstory.length) {
         y += 8 * sc;
         ccTextAt(g, fS, ccInt(CC_ATLAS.text3, A(1)), x, y + 10 * sc, ccCaps(E ? "El campo, en llano" : "The field, in plain words"));
         y += 18 * sc;
         var fl2 = ccWrap(fStory, fstory.join(" "), W);
         for (i = 0; i < fl2.length; ++i) { ccTextAt(g, fStory, ccInt(CC_ATLAS.text2, A(1)), x, y + 12 * sc, fl2[i]); y += 15 * sc; }
         y += 6 * sc;
      }
   }
   S.cardContentH = y + scroll + pad;
   var RB = CC_ROWS ? ccRowBlocks(CC_ROWS) : null;
   CC_ROWS = null;
   S.cardBlocks = RB ? RB.map(function(b) { return [b[0] + scroll, b[1] + scroll]; }) : null;
   // si sobra contenido: aviso de que hay más abajo
   if (S.cardContentH > h + 2 && RB) {
      // (compacto, 22-oct, revisor: filas a medias bajo «↓ rueda: más») Se ven solo FILAS ENTERAS; el aviso, en su franja propia
      var hb = Math.round(20 * sc), vis = ccWholeRows(RB, 0, h - hb - 1), moreC = scroll + h - hb < S.cardContentH - pad;
      if (vis.y0 > 0) ccFillRect(g, 0, 0, w, vis.y0, ccInt(CC_ATLAS.surface));
      ccFillRect(g, 0, vis.y1, w, h, ccInt(CC_ATLAS.surface));
      g.pen = ccPen(ccInt(CC_ATLAS.line), 1); g.drawLine(pad, h - hb, w - pad, h - hb);
      var sbXc = w - 5 * sc, sb0c = 8 * sc, sb1c = h - hb - 6 * sc, sbLc = Math.max(20 * sc, (sb1c - sb0c) * (h - hb) / S.cardContentH), sbPc = Math.min(1, scroll / Math.max(1, S.cardContentH - (h - hb))), sbYc = sb0c + (sb1c - sb0c - sbLc) * sbPc;
      S.cardBar = ccBarMake(w, sc, sb0c, sb1c, sbYc, sbLc, Math.max(0, S.cardContentH - (h - hb)));      // (5-nov) para atender el ratón sobre la barra
      g.fillRect(sbXc - 0.5 * sc, sb0c, sbXc + 0.5 * sc, sb1c, ccBrush(ccInt(CC_ATLAS.line)));
      g.fillRoundedRect(sbXc - 2 * sc, sbYc, sbXc + 2 * sc, sbYc + sbLc, 50, 50, ccBrush(ccInt(CC_ATLAS.gold, 0.75)));
      var tMore = moreC ? ccT("wheelMore") : "↑";
      ccTextAt(g, fSm, ccInt(CC_ATLAS.text3), w - pad - fSm.width(tMore), h - 6 * sc, tMore);
      S.cardVis = { y0: vis.y0, y1: vis.y1, band: h - hb };
   } else if (S.cardContentH > h + 2) {
      var more = scroll + h < S.cardContentH;
      g.fillRect(0, h - 18 * sc, w, h, ccBrush(ccInt(CC_ATLAS.surface, 0.92)));
      var sbX = w - 5 * sc, sb0 = 8 * sc, sb1 = h - 24 * sc, sbL = Math.max(20 * sc, (sb1 - sb0) * h / S.cardContentH), sbP = Math.min(1, scroll / Math.max(1, S.cardContentH - (h - Math.round(20 * sc)))), sbY = sb0 + (sb1 - sb0 - sbL) * sbP;
      S.cardBar = ccBarMake(w, sc, sb0, sb1, sbY, sbL, Math.max(0, S.cardContentH - (h - Math.round(20 * sc))));     // (5-nov) = el tope de la rueda: el fondo de la pista es el final real
      g.fillRect(sbX - 0.5 * sc, sb0, sbX + 0.5 * sc, sb1, ccBrush(ccInt(CC_ATLAS.line)));
      g.fillRoundedRect(sbX - 2 * sc, sbY, sbX + 2 * sc, sbY + sbL, 50, 50, ccBrush(ccInt(CC_ATLAS.gold, 0.75)));
      ccTextAt(g, fSm, ccInt(CC_ATLAS.text3), w - pad - fSm.width(more ? "↓ rueda: más" : "↑"), h - 5 * sc, more ? (E ? "↓ rueda: más" : "↓ wheel: more") : "↑");
   } else S.cardVis = null;
   ccTipBubble(g, w, h, S, "card", sc);
   return S.cardContentH;
   } finally { CC_ROWS = null; }
}
// Las familias químicas de una estrella: { rows: [{ key, survey, i, n, feh, nP, nC, members }], none: [surveys donde es candidata
// y no tiene familia], help: la explicación del «?» (qué es, la línea base de cada survey, el aviso de Ness+18, las del campo) }.
function ccStarChemFam(res, s, lang) {
   var out = { rows: [], none: [], help: "" }, E = ccL(lang) === "es", T = (res && res.tagging) || [], base = [], warn = false;
   for (var t = 0; t < T.length; ++t) {
      var TT = T[t];
      if (TT.candidates < 2) continue;
      var lab = CC_SURVEY_LABEL[TT.survey] || TT.survey;
      base.push(ccT("tagRate") + " (" + lab + "): " + ccDec(100 * TT.rate, 1, lang) + (E ? " % de " : "% of ") + ccThou(TT.tested, lang) + " " + ccT("pairs") + ".");
      // (umbral 5 %: cinco veces la tasa de dobles químicos de Ness+18; el mismo del grupo III de antes)
      if (TT.rate > 0.05) warn = true;
      var cand = !!(s.recs && s.recs[TT.survey] && s.recs[TT.survey].feh && ccIsNum(s.recs[TT.survey].feh.v)), found = false;
      for (var i = 0; i < TT.groups.length && i < 6; ++i) {
         var G = TT.groups[i];
         if (G.members.indexOf(s.idx) < 0) continue;
         // (30-oct-2026, M2-H3 de Codex) la base de «N de M pares se mueven juntos»: TODOS los pares del grupo con cinematica (G.pairsAll, cc_science.js ccTagging); antes solo
         // los quimicamente compatibles (M 67 GALAH: «4 717 de 6 398» = 74 %, y sobre todos los pares es 51 %). Si el grupo era demasiado grande para contarlos todos
         // (G.pairsAll = null), cae a la base de antes y la ficha lo dice (`allPairs` false: «compatibles»).
         var nP = 0, nC = 0, allP = (G.pairsAll !== null && G.pairsAll !== undefined && !ccPBroken("pairsub"));
         if (allP) { nP = G.pairsAll; nC = G.pairsAllC; }
         else for (var k = 0; k < TT.pairs.length; ++k) { var Pp = TT.pairs[k]; if (G.members.indexOf(Pp.a) >= 0 && G.members.indexOf(Pp.b) >= 0 && Pp.comove !== null) { ++nP; if (Pp.comove !== false) ++nC; } }
         out.rows.push({ key: TT.survey + ":" + i, survey: lab, i: i + 1, n: G.members.length, feh: G.feh, nP: nP, nC: nC, allPairs: allP, members: G.members });
         found = true;
      }
      if (cand && !found) out.none.push(lab);
   }
   var ff = ccFieldFamilies(res, lang, true);
   out.help = ccT("capFam") + " " + ccT("tipFam") + " " + ccT("tagHonesty") + (base.length ? " " + base.join(" ") : "") + (warn ? " " + ccT("famWarn") : "") + (ff ? " " + ccT("famInField") + ": " + ff + "." : "");
   return out;
}
// La línea de la familia química en la ficha (visible con el detalle plegado o abierto). Devuelve la nueva y.
function ccCardChemFamily(g, x, y, W, s, S, sc, A) {
   if (!S.res) return y;
   var CF = ccStarChemFam(S.res, s, CC_LANG);
   if (!CF.rows.length && !CF.none.length) return y;            // (ni GALAH ni APOGEE la miden: no hay familia que buscar)
   var E = CC_LANG === "es", fS = ccFont("text", 8.4 * sc, false, false, Math.round(8.4 * sc * 0.2)), fV = ccFont("text", 9.2 * sc), fH = ccFont("text", 8.2 * sc, false, true);
   var lab = ccCaps(ccT("famChem")), qx = x + fS.width(lab) + 4 * sc;
   ccTextAt(g, fS, ccInt(CC_ATLAS.text3, A(1)), x, y + 10 * sc, lab);
   ccQMark(g, qx, y + 10 * sc, sc);
   var helpHit = [x, y - 2 * sc, qx + 14 * sc, y + 14 * sc];
   y += 16 * sc;
   for (var r = 0; r < CF.rows.length; ++r) {
      var R = CF.rows[r], on = (S.groupKey === R.key), y0 = y;
      var cm = R.nP === 0 ? (E ? "sin cinemática" : "no kinematics") : (ccThou(R.nC, CC_LANG) + (E ? " de " : " of ") + ccThou(R.nP, CC_LANG) + (R.allPairs ? (E ? " pares del grupo se mueven juntos" : " group pairs move together") : (E ? " pares químicamente compatibles se mueven juntos" : " chemically compatible pairs move together")));
      var tv = ccT("famLine").replace("%1", R.i).replace("%2", R.survey).replace("%3", ccThou(R.n, CC_LANG)).replace("%4", ccFmtSignedL(R.feh)) + " · " + cm;
      var lines = ccWrap(fV, tv, W - 8 * sc), hint = ccT(on ? "famUnclick" : "famClick");
      var hh = lines.length * 14 * sc + 15 * sc;
      if (on) g.fillRoundedRect(x - 4 * sc, y0 - 2 * sc, x + W + 4 * sc, y0 + hh + 2 * sc, 8, 30, ccBrush(ccInt(CC_ATLAS.gold, A(0.14))));
      for (var k = 0; k < lines.length; ++k) { ccTextAt(g, fV, ccInt(on ? CC_ATLAS.goldLight : CC_ATLAS.text2, A(1)), x + 4 * sc, y + 11 * sc, lines[k]); y += 14 * sc; }
      ccTextAt(g, fH, ccInt(CC_ATLAS.gold, A(0.85)), x + 4 * sc, y + 10 * sc, "▸ " + hint);
      y += 15 * sc;
      // (la zona de la línea, la PRIMERA: el «?» se apunta después y gana al pasar el ratón por él)
      ccHit(S, "card", x - 4 * sc, y0 - 2 * sc, x + W + 4 * sc, y + 2 * sc, "", "family", R.key);
      if (!S.cardFamKeys) S.cardFamKeys = {};
      S.cardFamKeys[R.key] = R.members;
      y += 4 * sc;
   }
   if (CF.none.length) {
      var nl = ccWrap(fV, ccT("famNone").replace("%1", CF.none.join(E ? " ni " : " nor ")), W - 8 * sc);
      for (var j = 0; j < nl.length; ++j) { ccTextAt(g, fV, ccInt(CC_ATLAS.text3, A(1)), x + 4 * sc, y + 11 * sc, nl[j]); y += 14 * sc; }
      y += 4 * sc;
   }
   ccHit(S, "card", helpHit[0], helpHit[1], helpHit[2], helpHit[3], CF.help);
   return y + 4 * sc;
}
// Las filas técnicas: etiqueta con «?» (explicación llana), valor, nota y la cifra traducida.
function ccCardTechnical(g, x, y, W, s, S, sc, A) {
   var E = CC_LANG === "es", i;
   var fS = ccFont("text", 8.4 * sc, false, false, Math.round(8.4 * sc * 0.2)), fMb = ccFont("mono", 9.6 * sc, true), fSm = ccFont("text", 8.2 * sc, false, true), fPl = ccFont("text", 8.4 * sc, false, true);
   var labels = ["[Fe/H]", "[α/Fe]", ccT("age"), ccT("population"), ccT("chemistry"), ccT("kinematics"), E ? "Familia" : "Family", ccT("distance"), ccT("rv")];
   var lw = 0;
   for (i = 0; i < labels.length; ++i) lw = Math.max(lw, fS.width(ccCaps(labels[i])));
   var col = lw + 24 * sc;          // la columna de valores, medida (antes, fija: la velocidad radial se pegaba)
   function row(label, glossKey, value, note, plain) {
      ccTextAt(g, fS, ccInt(CC_ATLAS.text3, A(1)), x, y + 10 * sc, ccCaps(label));
      if (glossKey) { var qx = x + fS.width(ccCaps(label)) + 4 * sc; ccQMark(g, qx, y + 10 * sc, sc); ccHit(S, "card", x, y - 2 * sc, qx + 14 * sc, y + 14 * sc, ccGloss(glossKey, CC_LANG) + (plain ? " — " + plain : "")); }
      var vx = x + col;
      ccTextAt(g, fMb, ccInt(CC_ATLAS.text, A(1)), vx, y + 10.5 * sc, value);
      if (note) {
         var nx = vx + fMb.width(value) + 8 * sc;
         if (fSm.width(note) <= x + W - nx) ccTextAt(g, fSm, ccInt(CC_ATLAS.text3, A(1)), nx, y + 10 * sc, note);
         else { var nl = ccWrap(fSm, note, W - col); for (var kk = 0; kk < nl.length; ++kk) { y += 13 * sc; ccTextAt(g, fSm, ccInt(CC_ATLAS.text3, A(1)), vx, y + 10 * sc, nl[kk]); } }
      }
      y += 16 * sc;
      if (plain) { var pl = ccWrap(fPl, "= " + plain, W - col); for (var k = 0; k < pl.length; ++k) { ccTextAt(g, fPl, ccInt(CC_ATLAS.goldLight, A(0.9)), vx, y + 8 * sc, pl[k]); y += 13 * sc; } }
      y += 3 * sc;
   }
   var ch = s.chem;
   function pm(v, e, d) { return ccFmtSignedL(v, d) + (ccIsNum(e) ? " ± " + ccFmtL(e, d) : ""); }
   // (23-oct) un aviso bajo su fila: «⚠ …» en el color de aviso, como el de los surveys que no coinciden, y su «?» con la explicación llana
   var CWt = ccCardWarnings(s, CC_LANG);
   function warnLine(key) {
      var q = ccCardWarn(CWt, key);
      if (!q) return;
      var wl = ccWrap(fSm, "⚠ " + q.text, W - col - 18 * sc);
      for (var kq = 0; kq < wl.length; ++kq) {
         ccTextAt(g, fSm, ccInt(CC_ATLAS.warn, A(1)), x + col, y + 8 * sc, wl[kq]);
         if (kq === wl.length - 1) { var qxw = x + col + fSm.width(wl[kq]) + 4 * sc; ccQMark(g, qxw, y + 9 * sc, sc, S); ccHit(S, "card", x + col, y - 3 * sc, qxw + 14 * sc, y + 11 * sc, q.tip); }
         y += 13 * sc;
      }
      y += 3 * sc;
      if (S._cardWarnDrawn) S._cardWarnDrawn.push(key);
   }
   row("[Fe/H]", "feh", ch.feh ? pm(ch.feh.v, ch.feh.e, 2) : ccT("noData"), ch.feh ? CC_SURVEY_LABEL[ch.feh.src] + (ch.feh.proxy ? " (" + ch.feh.proxy + ")" : "") : "", ch.feh ? ccFehPlain(ch.feh.v, CC_LANG) : "");
   if (ch.discrepant) {
      var dl = ccWrap(fSm, "⚠ " + (E ? "Los surveys no coinciden: " : "Surveys disagree: ") + CC_SURVEY_LABEL[ch.discrepant.a] + (E ? " y " : " and ") + CC_SURVEY_LABEL[ch.discrepant.b] +
                      (E ? " difieren " : " differ by ") + ccFmtL(ch.discrepant.dex) + " dex (> 3 σ)" + (E ? "; se adopta el de más prioridad." : "; the higher-priority one is adopted."), W - col);
      for (i = 0; i < dl.length; ++i) { ccTextAt(g, fSm, ccInt(CC_ATLAS.warn, A(1)), x + col, y + 8 * sc, dl[i]); y += 13 * sc; }
      y += 3 * sc;
   }
   row("[α/Fe]", "alpha", ch.pair ? pm(ch.pair.alpha, ch.pair.ealpha, 2) : ccT("noData"), ch.pair ? ch.pair.tracer + " · " + CC_SURVEY_LABEL[ch.pair.src] : "", ccAlphaPlain(s.chemClass, CC_LANG));
   var ag = s.age.adopted;
   // (27-oct, R1b) la edad en una línea, la misma que la línea de tiempo (ccAgeText: nunca «v ± e» si la banda pasa de 13,8), y el intervalo
   // de debajo con ccAgeRange (antes se cortaba en 14 y no en la edad del Universo). Costura «sci-nouniv»: lo de antes (el rojo).
   var agRg = ag ? (ccSciBroken("sci-nouniv") ? [Math.max(0, ag.lo), Math.min(14, ag.hi)] : ccAgeRange(ag)) : null;
   row(ccT("age"), "age", ag ? (ccSciBroken("sci-nouniv") ? (ccAgeVague(ag) ? ccAgeRangeText(ag, CC_LANG) : ccFmtL(ag.v, 1) + " ± " + ccFmtL(ag.e, 1) + " " + ccAgeUnit(CC_LANG)) : ccAgeText(ag, CC_LANG)) : ccT("noData"), ag ? ccT(ccAgeTierKey(ag, ch.logg)) + " · " + ccAgeName(ag.src) + (ag.warn ? " · " + ccAgeWarnText(ag, CC_LANG) : "") : "",
       ag ? (E ? "entre " + ccDec(agRg[0], 1, "es") + " y " + ccDec(agRg[1], 1, "es") + " mil millones de años" : "between " + ccDec(agRg[0], 1, "en") + " and " + ccDec(agRg[1], 1, "en") + " billion years") : "");
   warnLine("age");
   if (s.age.others.length || s.age.rejected.length) {
      var o = [];
      for (i = 0; i < s.age.others.length; ++i) o.push(ccAgeName(s.age.others[i].src) + " " + ccAgeText(s.age.others[i], CC_LANG));
      for (i = 0; i < s.age.rejected.length; ++i) if (ccIsNum(s.age.rejected[i].v)) o.push(ccAgeName(s.age.rejected[i].src) + " " + ccFmtL(s.age.rejected[i].v, 1) + " ✗ " + ccAgeRejectWhyText(s.age.rejected[i].rejectWhy, CC_LANG));
      var ol = ccWrap(fSm, ccT("otherAges") + ": " + o.join(" · "), W - col);
      // (28-oct) TODAS las líneas: hasta hoy se cortaba en 4 sin avisar y se perdía el final («✗ marcada por el», «gigante fuera de 1–2» sin
      // «M☉»; capturas m67_ficha_detalle_*). Con 6 fuentes de edad como mucho, son 6 líneas. Costura «otherscap»: el tope de antes (el rojo).
      var olMax = ccPBroken("otherscap") ? 4 : ol.length;
      for (i = 0; i < ol.length && i < olMax; ++i) { ccTextAt(g, fSm, ccInt(CC_ATLAS.text3, A(0.9)), x + col, y + 8 * sc, ol[i]); y += 13 * sc; }
      y += 3 * sc;
   }
   var pop = s.pop.label;
   // (23-oct, P2: la nota es la de cc_science.js, ccPopNote: «de acuerdo» / «en tensión» / «la cinemática no distingue» —agree null—;
   //  el rojo `oldpopnote` de T20 vuelve a la de antes, que pintaba el null como «en tensión»)
   var popNote = ccPBroken("oldpopnote") ? (s.pop.basis === "chem+kin" ? (s.pop.agree ? (E ? "química y cinemática de acuerdo" : "chemistry and kinematics agree") : (E ? "química y cinemática en tensión" : "chemistry and kinematics disagree")) : "") : ccPopNote(s.pop, CC_LANG);
   // (30-oct, decisión C) con P < 0,8 no se afirma el origen: «compatible con halo acretado» (ccFamFirm)
   row(ccT("population"), "population", (pop === "accreted" && !ccFamFirm(s.fam)) ? (E ? "compatible con halo acretado" : "compatible with accreted halo") : CC_POP_NAME[E ? "es" : "en"][pop], popNote, "");
   if (s.chemClass && s.chemClass.pHigh !== null)
      row(ccT("chemistry"), "chemistry", "P(" + (E ? "α alto" : "high α") + ") " + ccP(s.chemClass.pHigh), (E ? "a " + ccDec(Math.abs(s.chemClass.z), 1, "es") : ccFmtL(Math.abs(s.chemClass.z), 1)) + " σ " + (E ? "de la frontera" : "from the boundary"), "");
   // (29-oct) la cinemática con probabilidades: las del modelo ÚNICO (CabraShared/csh_kinpop.js); el veredicto en una palabra delante
   if (s.kin && s.kin.probs) {
      ccTextAt(g, fS, ccInt(CC_ATLAS.text3, A(1)), x, y + 10 * sc, ccCaps(ccT("kinematics")));
      var qx = x + fS.width(ccCaps(ccT("kinematics"))) + 4 * sc; ccQMark(g, qx, y + 10 * sc, sc); ccHit(S, "card", x, y - 2 * sc, qx + 14 * sc, y + 14 * sc, ccGloss("kinematics", CC_LANG));
      var bx = x + col, bw = W - col, by = y + 3 * sc, bh = 9 * sc, pr = s.kin.probs, acc = 0;
      var segs = [["thin", pr.thin], ["thick", pr.thick], ["halo", pr.halo]];
      for (i = 0; i < segs.length; ++i) { var sw = bw * segs[i][1]; if (sw > 0.5) g.fillRect(bx + acc, by, bx + acc + sw, by + bh, ccBrush(ccInt(CC_POP_COLOR[segs[i][0]], A(0.85)))); acc += sw; }
      g.pen = ccPen(ccInt(CC_ATLAS.line, A(1)), 1); g.drawRect(bx, by, bx + bw, by + bh);
      y += 16 * sc;
      var kvw = ccKinVerdictWord(s.kin, CC_LANG), kt = (kvw ? kvw + " · " : "") + (E ? "fino " : "thin ") + Math.round(100 * pr.thin) + " % · " + (E ? "grueso " : "thick ") + Math.round(100 * pr.thick) + " % · halo " + Math.round(100 * pr.halo) + " % · " + Math.round(s.kin.vtot) + " km/s" + (!s.kin.local ? (E ? " · lejos: aprox. local" : " · far: local approx.") : "");
      // (30-oct) en las lejanas no cabía en una línea y se cortaba en «lejos: apro…»: ahora baja a la siguiente, como el resto de la ficha
      var ktL = ccWrap(fSm, kt, bw);
      for (var kl = 0; kl < ktL.length; ++kl) { ccTextAt(g, fSm, ccInt(CC_ATLAS.text3, A(1)), bx, y + 8 * sc, ktL[kl]); y += (kl + 1 < ktL.length) ? 13 * sc : 16 * sc; }
   } else row(ccT("kinematics"), "kinematics", ccT("noData"), (s.kin && s.kin.why === "distance-error") ? (E ? "distancia demasiado incierta (> 20 %)" : "distance too uncertain (> 20 %)") : (s.kin && s.kin.why === "suspect-distance") ? ccT("kinDoubtRuwe") : (s.kin && s.kin.why === "unbound") ? ccT("kinUnbound") : !s.rv ? (E ? "sin velocidad radial" : "no radial velocity") : (!s.dist ? (E ? "sin distancia" : "no distance") : ""), "");
   if (s.fam) {
      var fam = s.fam, fn = CC_FAM_NAME[E ? "es" : "en"][fam.best];
      // (22-oct, integración de III: la órbita con sus cuatro cifras —peri, apo, Zmax, e—, las MISMAS que el rótulo del mapa: ccOrbitLine)
      var oLine = ccOrbitLine(fam.orbit, CC_LANG);
      if (oLine) { row(E ? "Órbita" : "Orbit", "orbit", oLine, "", ""); warnLine("zmax"); warnLine("astro"); }
      // (30-oct, N1) sin familia con astrometría dudosa; (N2) la no ligada, sin P ni e: no es una familia. (D1-H3) el tooltip: P ≥ 0,8 «muy probable», por debajo «compatible»
      var famUb = (fam.best === "unbound"), famNoP = !fam.best || famUb;
      row(E ? "Familia" : "Family", "family", !fam.best ? ccT("dynFamNone") : (famUb ? fn : fn + " · P " + ccP(fam.p)), (!fam.best ? ccT("dynFamNoneNote") + " · " : "") + ((oLine || famNoP) ? "" : "e " + (fam.orbit ? ccFmtL(fam.orbit.ecc, 2) : "—") + " · ") + "Lz " + Math.round(fam.nominal.Lz) + " kpc km/s · E " + ccFmtL(fam.nominal.E / 1e5, 2) + "\u00b710\u2075 km\u00b2/s\u00b2",
          ccLzPlain(fam.nominal, CC_LANG) + (fam.accreted ? (ccFamFirm(fam) ? (E ? "; las regiones de las familias se solapan: muy probable, no segura (Naidu+20; Carrillo+24)" : "; family regions overlap: very likely, not certain (Naidu+20; Carrillo+24)") : (E ? "; las regiones de las familias se solapan: compatible, no confirmada (Naidu+20; Carrillo+24)" : "; family regions overlap: compatible, not confirmed (Naidu+20; Carrillo+24)")) : ""));
      warnLine("unbound");
   }
   row(ccT("distance"), "distance", s.dist ? ccNice(s.dist.pc, CC_LANG, 3) + " pc" + (ccIsNum(s.dist.lo) && ccIsNum(s.dist.hi) ? " (" + ccNice(s.dist.lo, CC_LANG, 3) + "–" + ccNice(s.dist.hi, CC_LANG, 3) + ")" : "") : ccT("noData"), s.dist ? s.dist.src : "",
       s.dist ? ccNice(s.dist.pc * CC_PC_TO_LY, CC_LANG, 2) + (E ? " años luz" : " light years") : "");
   warnLine("xmatch");
   if (s.rv) {
      // (23-oct, P6: con otra RV que no casa, s.rv.e ya lleva la discrepancia —la usan los sorteos—; la fila enseña el error del
      //  CATÁLOGO, s.rv.eRaw, y el aviso de debajo la otra RV y el error usado. Rojo `rvdisc` de T20: la fila enseña s.rv.e)
      var rvE = (ccIsNum(s.rv.eRaw) && !ccPBroken("rvdisc")) ? s.rv.eRaw : s.rv.e, d = (rvE < 0.95) ? 2 : 1;
      // (30-oct, decisión D) la de Gaia DR3 va corregida (cshRvCorrect, CabraShared/csh_net.js): lo movido, o que no se pudo
      var rvCn = (s.rv.corr === "katz" || s.rv.corr === "blomme") ? " · " + ccT(s.rv.corr === "katz" ? "rvCorrKatz" : "rvCorrBlomme").replace("%1", ccFmtSignedL(s.rv.v - s.rv.vCat, 2)) : (s.rv.corr === "no-info" ? " · " + ccT("rvCorrNone") : "");
      row(ccT("rv"), "rv", ccFmtL(s.rv.v, d) + " ± " + ccFmtL(Math.max(rvE, Math.pow(10, -d)), d) + " km/s", s.rv.src + rvCn + (ccIsNum(s.rv.scatter) && s.rv.scatter > 1 ? (E ? " · dispersión " : " · scatter ") + ccFmtL(s.rv.scatter, 1) + (E ? " (¿binaria?)" : " (binary?)") : ""),
          (s.rv.v < 0 ? (E ? "se acerca a nosotros" : "approaching us") : (E ? "se aleja de nosotros" : "moving away from us")) + (rvCn ? " — " + ((s.rv.corr === "no-info") ? ccT("rvCorrNoneTip") : ccT("rvCorrTip").replace("%1", ccFmtSignedL(s.rv.vCat, 2))) : ""));
      warnLine("rv");
   } else row(ccT("rv"), "rv", ccT("noData"), "", "");
   y += 4 * sc;
   y = ccFingerprintBars(g, x, y, W, s, S, sc, A);
   var tags = [];
   if (s.twin) tags.push(ccT("solarTwin"));
   for (i = 0; i < s.fp.tags.length; ++i) tags.push(s.fp.tags[i] === "s" ? (E ? "enriquecida en proceso s" : "s-process enhanced") : (s.fp.tags[i] === "CEMP" ? "CEMP" : s.fp.tags[i] + (E ? " (proceso r)" : " (r-process)")));
   if (s.pop.accreted && s.fam) tags.push((ccFamFirm(s.fam) ? (E ? "acretada: " : "accreted: ") : (E ? "compatible con " : "compatible with ")) + CC_FAM_NAME[E ? "es" : "en"][s.fam.best]);
   if (tags.length) {
      var tx = x;
      for (i = 0; i < tags.length; ++i) {
         var tw = fS.width(tags[i].toUpperCase()) + 16 * sc;
         if (tx + tw > x + W) { tx = x; y += 22 * sc; }
         if (CC_ROWS) CC_ROWS.push([y, y + 17 * sc]);
         g.fillRoundedRect(tx, y, tx + tw, y + 17 * sc, 40, 99, ccBrush(ccInt(CC_ATLAS.gold, A(0.16))));
         g.pen = ccPen(ccInt(CC_ATLAS.gold, A(0.7)), 1); g.drawRoundedRect(tx, y, tx + tw, y + 17 * sc, 40, 99);
         ccTextAt(g, fS, ccInt(CC_ATLAS.goldLight, A(1)), tx + 8 * sc, y + 12 * sc, tags[i].toUpperCase());
         ccHit(S, "card", tx, y, tx + tw, y + 17 * sc, ccGloss("tags", CC_LANG));
         tx += tw + 6 * sc;
      }
      y += 26 * sc;
   }
   var tr = [];
   for (i = 0; i < CC_CHEM_PRIORITY.length; ++i) { var r = s.recs ? s.recs[CC_CHEM_PRIORITY[i]] : null; if (r && r.feh) tr.push(CC_SURVEY_LABEL[CC_CHEM_PRIORITY[i]] + " " + ccFmtSignedL(r.feh.v)); }
   if (tr.length) {
      var trl = ccWrap(fSm, (E ? "[Fe/H] según cada catálogo: " : "[Fe/H] by catalogue: ") + tr.join(" · "), W);
      for (i = 0; i < trl.length; ++i) { ccTextAt(g, fSm, ccInt(CC_ATLAS.text3, A(1)), x, y + 9 * sc, trl[i]); y += 13 * sc; }
   }
   return y;
}
// LOS AVISOS DE LA FICHA (23-oct, docs/contradicciones_ficha.md «Para la interfaz»; los datos los pone cc_engine.js): devuelve la lista
// { key, text (corto, lo que se pinta), tip (la explicación llana del «?») } de los que tenga la estrella. ROJO «nocardwarn» de T18: ninguno.
function ccCardWarnings(s, lang) {
   var E = (lang === "es"), out = [], T = function(k) { return ccT(k); };
   if (!s || ((typeof ccPBroken === "function") && ccPBroken("nocardwarn"))) return out;
   function num(v, d) { var t = ccDec(Math.abs(v), d, lang); return (v < 0 ? "−" : "") + t; }
   if (s.xmatch && s.xmatch.ok === false) {
      var b0 = (s.xmatch.bad && s.xmatch.bad.length) ? s.xmatch.bad[0] : "", sv = (typeof CC_SURVEY_LABEL !== "undefined" && CC_SURVEY_LABEL[b0]) || b0, sep = (s.xmatch.sep && ccIsNum(s.xmatch.sep[b0])) ? s.xmatch.sep[b0] : null;
      out.push({ key: "xmatch", text: T("gaiaDoubt"), tip: T("gaiaDoubtTip").replace("%1", sv).replace("%2", sep === null ? "—" : ccDec(sep, 1, lang)) });
   }
   // (30-oct, N2 y N1) no ligada; astrometría dudosa: el aviso bajo su fila
   if (s.fam && s.fam.best === "unbound") out.push({ key: "unbound", text: T("unboundWarn") + (s.astroDoubt ? " (" + ccAstroDoubtWhy(s.astroDoubt, lang) + ")" : ""), tip: T("unboundTip") });
   else if (s.astroDoubt && s.fam && !s.fam.best) out.push({ key: "astro", text: T("astroDoubt").replace("%1", ccAstroDoubtWhy(s.astroDoubt, lang)), tip: T("astroDoubtTip") });
   if (s.fam && s.fam.zmaxUnstable && s.fam.orbit && s.fam.orbitAlt) {
      var z = s.fam.orbit.zmax, za = s.fam.orbitAlt.zmax;
      out.push({ key: "zmax", text: T("zmaxAlt").replace("%1", ccDec(z, z < 1 ? 2 : 1, lang)).replace("%2", ccDec(za, za < 1 ? 2 : 1, lang)).replace("%3", String(s.fam.orbitAlt.src || "")), tip: T("zmaxAltTip") });
   }
   if (s.rv && s.rv.alt && ccIsNum(s.rv.alt.v)) {
      // (P6) si el motor ensanchó el error con la discrepancia (s.rv.eRaw = el del catálogo), el aviso dice el que se usó
      var rvUsed = (ccIsNum(s.rv.eRaw) && ccIsNum(s.rv.e) && s.rv.e > s.rv.eRaw + 1e-9) ? T("rvAltUsed").replace("%1", ccDec(s.rv.e, 1, lang)) : "";
      out.push({ key: "rv", text: T("rvAlt").replace("%1", String(s.rv.alt.src || "")).replace("%2", num(s.rv.alt.v, 1) + " km/s") + rvUsed, tip: T("rvAltTip") + (rvUsed ? " " + T("rvAltUsedTip") : "") });
   }
   if (s.pop && s.pop.ageTension) {
      var at = s.pop.ageTension;
      out.push({ key: "age", text: T("ageTension"), tip: T("ageTensionTip").replace("%1", ccIsNum(at.hi) ? ccDec(at.hi, 1, lang) : "—").replace("%2", ccIsNum(at.floor) ? ccDec(at.floor, 0, lang) : "—") });
   }
   return out;
}
function ccCardWarn(W0, key) { for (var i = 0; i < W0.length; ++i) if (W0[i].key === key) return W0[i]; return null; }
// La huella química: barras de [X/Fe] con EJE (0 = solar, ±0,5) y el valor de cada una al pasar el ratón.
function ccFingerprintBars(g, x, y, W, s, S, sc, A) {
   var E = CC_LANG === "es", el = s.chem.el || {}, fams = [["alpha", "α"], ["odd", E ? "Z impar" : "odd-Z"], ["peak", E ? "pico Fe" : "Fe-peak"], ["s", E ? "proceso s" : "s-process"], ["r", E ? "proceso r" : "r-process"]];
   var items = [], i, f;
   for (f = 0; f < fams.length; ++f) for (i = 0; i < CC_ELEMENTS.length; ++i) if (CC_ELEMENTS[i][1] === fams[f][0] && el[CC_ELEMENTS[i][0]]) items.push({ e: CC_ELEMENTS[i][0], fam: f, v: el[CC_ELEMENTS[i][0]].v, err: el[CC_ELEMENTS[i][0]].e, src: el[CC_ELEMENTS[i][0]].src });
   var fS = ccFont("text", 8.4 * sc, false, false, Math.round(8.4 * sc * 0.2)), fm = ccFont("mono", 7.4 * sc), fa = ccFont("mono", 7.2 * sc);
   ccTextAt(g, fS, ccInt(CC_ATLAS.text3, A(1)), x, y + 10 * sc, ccCaps(ccT("fingerprint")));
   var qx = x + fS.width(ccCaps(ccT("fingerprint"))) + 4 * sc; ccQMark(g, qx, y + 10 * sc, sc); ccHit(S, "card", x, y - 2 * sc, qx + 14 * sc, y + 14 * sc, ccGloss("fingerprint", CC_LANG));
   y += 18 * sc;
   if (items.length === 0) { ccTextAt(g, ccFont("text", 8.2 * sc, false, true), ccInt(CC_ATLAS.text3, A(1)), x, y + 8 * sc, ccT("noData")); return y + 16 * sc; }
   var axW = fa.width("+0.5") + 6 * sc, x0 = x + axW, WW = W - axW;
   S.fpBox = { y0: y - 18 * sc + (S.cardScroll || 0), y1: y + 52 * sc + 32 * sc + (S.cardScroll || 0) };     // (para la captura antes/después)
   var hh = 52 * sc, mid = y + hh / 2, n = items.length, gap = 3 * sc, bw = Math.max(4 * sc, (WW - fams.length * 6 * sc) / n - gap), xx = x0, lastFam = -1;
   // el eje: 0 = el Sol, y ±0,5
   g.pen = ccPen(ccInt(CC_ATLAS.line, A(1)), 1);
   g.drawLine(x0, mid - hh / 2, x0 + WW, mid - hh / 2); g.drawLine(x0, mid + hh / 2, x0 + WW, mid + hh / 2);
   g.pen = ccPen(ccInt(CC_ATLAS.text3, A(0.9)), 1); g.drawLine(x0, mid, x0 + WW, mid);
   ccTextAt(g, fa, ccInt(CC_ATLAS.text3, A(1)), x, mid - hh / 2 + 3 * sc, E ? "+0,5" : "+0.5");
   ccTextAt(g, fa, ccInt(CC_ATLAS.text2, A(1)), x + fa.width("+0") - fa.width("0"), mid + 3 * sc, "0");
   g.strokeCircle(x + fa.width("+0.5") - 1 * sc, mid, 2.6 * sc, ccPen(ccInt(CC_ATLAS.text2, A(1)), 1)); g.fillCircle(x + fa.width("+0.5") - 1 * sc, mid, 0.8 * sc, ccBrush(ccInt(CC_ATLAS.text2, A(1))));
   ccTextAt(g, fa, ccInt(CC_ATLAS.text3, A(1)), x, mid + hh / 2 + 3 * sc, E ? "−0,5" : "−0.5");
   for (i = 0; i < n; ++i) {
      var it = items[i];
      if (it.fam !== lastFam && lastFam >= 0) xx += 6 * sc;
      lastFam = it.fam;
      var v = ccClamp(it.v, -0.5, 0.5), yy = mid - v / 0.5 * (hh / 2);
      var col = (it.fam === 4) ? CC_ATLAS.chart[4] : (it.fam === 3 ? CC_ATLAS.chart[1] : (it.fam === 0 ? CC_ATLAS.gold : CC_ATLAS.text2));
      g.fillRect(xx, Math.min(mid, yy), xx + bw, Math.max(mid, yy) + 1, ccBrush(ccInt(col, A(0.85))));
      if (ccIsNum(it.err) && it.err > 0) { var e0 = mid - ccClamp(it.v - it.err, -0.5, 0.5) / 0.5 * hh / 2, e1 = mid - ccClamp(it.v + it.err, -0.5, 0.5) / 0.5 * hh / 2; g.pen = ccPen(ccInt(CC_ATLAS.text, A(0.55)), 1); g.drawLine(xx + bw / 2, e0, xx + bw / 2, e1); }
      if (Math.abs(it.v) > 0.5) ccTextAt(g, fa, ccInt(CC_ATLAS.text, A(1)), xx, it.v > 0 ? mid - hh / 2 - 2 * sc : mid + hh / 2 + 8 * sc, it.v > 0 ? "▲" : "▼");
      ccTextAt(g, fm, ccInt(CC_ATLAS.text3, A(1)), xx + bw / 2 - fm.width(it.e) / 2, mid + hh / 2 + 12 * sc, it.e);
      var pl = Math.pow(10, it.v), txt = "[" + it.e + "/Fe] = " + ccFmtSignedL(it.v, 2) + (ccIsNum(it.err) ? " ± " + ccFmtL(it.err, 2) : "") + " (" + CC_SURVEY_LABEL[it.src] + ") — " +
          (E ? (Math.abs(it.v) < 0.05 ? "como el Sol" : (it.v > 0 ? "un " + Math.round(100 * (pl - 1)) + " % más que el Sol, por cada átomo de hierro" : "un " + Math.round(100 * (1 - pl)) + " % menos que el Sol, por cada átomo de hierro"))
             : (Math.abs(it.v) < 0.05 ? "like the Sun" : (it.v > 0 ? Math.round(100 * (pl - 1)) + "% more than the Sun, per iron atom" : Math.round(100 * (1 - pl)) + "% less than the Sun, per iron atom")));
      ccHit(S, "card", xx - 1, mid - hh / 2, xx + bw + 1, mid + hh / 2 + 14 * sc, txt);
      xx += bw + gap;
   }
   // las familias, bajo los elementos
   xx = x0; lastFam = -1;
   var ff = ccFont("text", 7.4 * sc, false, true), famStart = {}, famEnd = {};
   for (i = 0; i < n; ++i) { if (items[i].fam !== lastFam && lastFam >= 0) xx += 6 * sc; lastFam = items[i].fam; if (famStart[lastFam] === undefined) famStart[lastFam] = xx; famEnd[lastFam] = xx + bw; xx += bw + gap; }
   for (f in famStart) if (famStart.hasOwnProperty(f)) {
      var lab = fams[f][1], span = famEnd[f] - famStart[f], by2 = mid + hh / 2 + 16 * sc;
      g.pen = ccPen(ccInt(CC_ATLAS.text3, A(0.55)), 1);
      g.drawLine(famStart[f], by2, famEnd[f], by2); g.drawLine(famStart[f], by2 - 3 * sc, famStart[f], by2); g.drawLine(famEnd[f], by2 - 3 * sc, famEnd[f], by2);
      if (span + 10 * sc >= ff.width(lab)) ccTextAt(g, ff, ccInt(CC_ATLAS.text3, A(0.9)), famStart[f] + span / 2 - ff.width(lab) / 2, mid + hh / 2 + 26 * sc, lab);
   }
   if (CC_ROWS) CC_ROWS.push([y - 20 * sc, mid + hh / 2 + 30 * sc]);
   return mid + hh / 2 + 32 * sc;
}

// ---------------------------------------------------------------------------
// LA COBERTURA (el tooltip del «?» del título; hasta el 22-oct era el grupo II, y las familias químicas el III: ahora en la ficha)
// ---------------------------------------------------------------------------
// Lo que se dice de un catálogo que falló, en la cobertura (16, 22-oct: `netWhy "bad"` = contestó algo que no es una tabla)
function ccNetWord(q, E) {
   if (!q.net) return "✗";
   if (q.netWhy === "bad" && !(typeof ccBroken === "function" && ccBroken("nobad"))) return E ? "respuesta no válida" : "bad answer";
   if (q.code >= 500) return "HTTP " + q.code;
   return q.netWhy === "timeout" ? (E ? "no contesta" : "no answer") : (E ? "sin conexión" : "no connection");
}
// LA COBERTURA, en el tooltip del «?» junto a las cifras del título (22-oct, fase 1: el grupo II «Cobertura y fuentes» se va porque
// no tenía nada que elegir; aquí va TODO lo que enseñaba: el encuadre | los catálogos, qué vino de la caché, qué falló y por qué, y
// la explicación de cada fila). HTML de Qt (tabla a dos columnas). Un catálogo que falla se sigue diciendo en la línea de estado.
function ccHtmlEsc(t) { return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function ccCoverageHtml(S, lang) {
   var E = ccL(lang) === "es", A = CC_ATLAS, esc = ccHtmlEsc, i, k;
   if (!S || !S.res || !S.res.coverage) return "";
   if (typeof ccBroken === "function" && ccBroken("nocovtip")) return "";
   var c = S.res.coverage, px = function(n) { return Math.round(n * ccScale()) + "px"; };
   var sub = "color:" + A.text3 + ";font-size:" + px(9) + ";", glo = "color:" + A.text3 + ";font-size:" + px(8.6) + ";font-style:italic;", head = "color:" + A.gold + ";font-size:" + px(9) + ";font-weight:600;letter-spacing:1px;";
   function pct(n, d) { return d > 0 ? ccDec(100 * n / d, 1, lang) + (E ? " %" : "%") : "—"; }
   var L = [];
   function row(label, val, subT, gloss, valCol) {
      L.push("<tr><td style='color:" + A.text2 + ";'>" + esc(label) + "</td><td align='right' style='color:" + (valCol || A.text) + ";font-family:monospace;'>" + esc(val) + "</td></tr>");
      if (subT) L.push("<tr><td colspan='2' style='" + sub + "padding-left:" + px(10) + ";'>" + esc(subT) + "</td></tr>");
      if (gloss) L.push("<tr><td colspan='2' style='" + glo + "padding-left:" + px(10) + ";padding-bottom:" + px(4) + ";'>" + esc(gloss) + "</td></tr>");
   }
   L.push("<tr><td colspan='2' style='" + head + "'>" + (E ? "EN EL ENCUADRE" : "IN THE FRAME") + "</td></tr>");
   row(ccT("gaiaStars") + " (G<17)", ccThou(c.gaiaG17, lang), "G<15: " + ccThou(c.gaiaG15, lang) + " · G<19: " + ccThou(c.gaiaG19, lang), ccCovGloss("g17", lang));
   row(ccT("withChem"), ccThou(c.chem, lang), (E ? "de las G<17: " : "of the G<17: ") + ccThou(c.brightG17chem, lang) + (E ? " de " : " of ") + ccThou(c.gaiaG17, lang) + " (" + pct(c.brightG17chem, c.gaiaG17) + ") · " + (E ? "con [α/Fe]: " : "with [α/Fe]: ") + ccThou(c.alpha, lang) + " · " + (E ? "≥ 5 elementos: " : "≥ 5 elements: ") + ccThou(c.elems, lang) + " · Eu/Ba: " + ccThou(c.rProc, lang), ccCovGloss("chem", lang), A.goldLight);
   var ab = []; for (k in c.ageBySrc) if (c.ageBySrc.hasOwnProperty(k)) ab.push(ccAgeName(k) + " " + ccThou(c.ageBySrc[k], lang));
   row(ccT("withAge"), ccThou(c.age, lang), ab.join(" · "), ccCovGloss("age", lang));
   row(ccT("withKin"), ccThou(c.kin, lang), E ? "Gaia DR3 + velocidad radial + distancia" : "Gaia DR3 + radial velocity + distance", ccCovGloss("kin", lang));
   var GLo = S.res.gaiaLocal, ca = c.astro || { local: 0, net: 0, both: 0 };
   row(E ? "Astrometría de Gaia" : "Gaia astrometry", ccThou(ca.local + ca.net + ca.both, lang),
       (GLo && !GLo.missing ? (E ? "Gaia local (" + GLo.name + "): " + ccThou(ca.local + ca.both, "es") + " · solo por internet: " + ccThou(ca.net, "es") + " · el encuadre entero sin red: " + ccThou(GLo.inFrame, "es") + " estrellas"
                                 : "Gaia local (" + GLo.name + "): " + ccThou(ca.local + ca.both, "en") + " · internet only: " + ccThou(ca.net, "en") + " · whole frame offline: " + ccThou(GLo.inFrame, "en") + " stars")
                             : (E ? "Gaia por internet: " + ccThou(ca.net, "es") + " (la base Gaia local no está instalada en este PixInsight)" : "Gaia over the internet: " + ccThou(ca.net, "en") + " (no local Gaia database in this PixInsight)")),
       ccCovGloss("astro", lang));
   var order = ["thin", "thick", "halo", "accreted", "disc", "unknown"], pp = [];
   for (i = 0; i < order.length; ++i) if (c.byPop && c.byPop[order[i]]) pp.push(CC_POP_NAME[E ? "es" : "en"][order[i]] + " " + ccThou(c.byPop[order[i]], lang));
   row(ccT("population") + " (" + ccT("inSomeCat") + ")", ccThou(c.inFrame, lang), pp.join(" · "), "");
   var left = L.join(""); L = [];
   var Q = S.res.queries || [], nCache = 0;
   for (i = 0; i < Q.length; ++i) if (Q[i].cached) ++nCache;
   L.push("<tr><td colspan='2' style='" + head + "'>" + (E ? "CATÁLOGOS (TAPVIZIER)" : "CATALOGUES (TAPVIZIER)") + (nCache === Q.length && Q.length ? " · " + esc(ccT("cacheNote")) : "") + "</td></tr>");
   L.push("<tr><td colspan='2' style='" + glo + "padding-bottom:" + px(4) + ";'>" + esc(ccCovGloss("cats", lang)) + "</td></tr>");
   var spq = { galah: 1, apogee: 1, lamost: 1, x19: 1, gspspec: 1, xpg: 1 };
   for (i = 0; i < Q.length; ++i) {
      var q = Q[i], netTxt = ccNetWord(q, E);
      var stT = q.key === "count" ? (q.ok ? ccThou(c.gaiaG19, lang) + " G<19" + (q.local ? " · local" : "") : netTxt)
                                  : (q.ok ? (spq[q.key] && q.used === 0 ? (E ? "no cubre este campo" : "does not cover this field") : (ccThou(q.used, lang) + (E ? " de " : " of ") + ccThou(q.rows, lang))) : (q.message === "off" ? "off" : netTxt));
      var col = q.ok ? A.text2 : (q.message === "off" ? A.text3 : A.error);
      var right = stT + ((nCache === Q.length) ? "" : "  " + (q.cached ? ccT("cached") : ccThou(q.ms, lang) + " ms"));
      L.push("<tr><td style='color:" + A.text2 + ";'>" + esc(ccCatName(q.key, q.label)) + "</td><td align='right' style='color:" + col + ";font-family:monospace;'>" + esc(right) + "</td></tr>");
      if (!q.ok && q.message && q.message !== "off") L.push("<tr><td colspan='2' style='color:" + A.error + ";font-size:" + px(9) + ";padding-left:" + px(10) + ";'>" + esc(q.message) + "</td></tr>");
   }
   var right2 = L.join(""), cw = Math.round(430 * ccScale()), gap = Math.round(26 * ccScale());
   return "<html><div style='color:" + A.gold + ";font-weight:600;'>" + esc(ccCaps(ccT("secCov"))) + "</div><div style='" + glo + "'>" + esc(ccT("capCov")) + "</div>" +
          // (anchos FIJOS en las tablas, no en las celdas: Qt ignoraba el de la celda y no partía las líneas —la primera captura salió de
          //  1 700 px lógicos de ancho—)
          "<table width='" + (2 * cw + gap) + "' cellspacing='0' cellpadding='0'><tr><td valign='top' width='" + cw + "'><table width='" + cw + "' cellspacing='0' cellpadding='1'>" + left + "</table></td>" +
          "<td width='" + gap + "'></td><td valign='top' width='" + cw + "'><table width='" + cw + "' cellspacing='0' cellpadding='1'>" + right2 + "</table></td></tr></table></html>";
}
