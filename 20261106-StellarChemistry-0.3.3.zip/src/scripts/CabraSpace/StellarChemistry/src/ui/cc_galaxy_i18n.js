#ifndef __CC_GALAXY_I18N_JS
#define __CC_GALAXY_I18N_JS
// ============================================================================
// src/ui/cc_galaxy_i18n.js — las cadenas del grupo III · LA GALAXIA, en inglés y castellano
// ----------------------------------------------------------------------------
// Mismo formato que cc_i18n.js (clave: [en, es]) y el mismo idioma vigente (CC_LANG), pero en su
// tabla propia para no tocar la de la fase 1. ccGxT(key) · ccGxF(key, {n: …}) rellena «{n}».
// Las cifras con coma en castellano: ccGxNum (cc_galaxy_paint.js).
// ES5 puro.
// ============================================================================
var CC_GX_TXT = {
   // los mandos (cuerpo del grupo III)
   gxView: ["View", "Vista"],
   gxTop: ["From above", "Desde arriba"],
   gxTopTip: ["The Milky Way seen from its north pole (X–Y): the Sun below the centre, the Galaxy turning clockwise. Drag: move · wheel: zoom at the cursor · double-click: whole view · click: choose a star.",
              "La Vía Láctea vista desde su polo norte (X–Y): el Sol debajo del centro y la Galaxia girando como las agujas del reloj. Arrastrar: mover · rueda: acercar hacia el cursor · doble clic: vista entera · clic: elegir una estrella."],
   gxEdge: ["Edge-on", "De canto"],
   gxEdgeTip: ["Distance from the centre (R) against height above the disc (z): how far each star climbs out of the plane. Drag: move · wheel: zoom · double-click: whole view · click: choose a star.",
               "Distancia al centro (R) frente a altura sobre el disco (z): cuánto se sale cada estrella del plano. Arrastrar: mover · rueda: acercar · doble clic: vista entera · clic: elegir una estrella."],
   gx3d: ["3D", "3D"],
   gx3dTip: ["The Galaxy in 3D, with the camera of FieldDepth3D. Drag: turn · Shift or right button + drag: move · wheel: travel towards the cursor · double-click: whole view · click: choose a star.",
             "La Galaxia en 3D, con la cámara de FieldDepth3D. Arrastrar: girar · Mayús o botón derecho + arrastrar: mover · rueda: avanzar hacia el cursor · doble clic: vista entera · clic: elegir una estrella."],
   gxShow: ["Show", "Mostrar"],
   // (23-oct: «Hoy» pasa a «Posiciones»: con el mando de tiempo, «Hoy» en «Mostrar» se leía como el instante, no como «sin órbitas»)
   gxNow: ["Positions", "Posiciones"],
   gxNowTip: ["Only where each star is, at the instant of the time control (today, unless you move it).", "Solo dónde está cada estrella, en el instante del mando de tiempo (hoy, si no lo mueves)."],
   gxOrbit: ["Orbits", "Órbitas"],
   gxOrbitTip: ["The path of each star round the Galaxy over the 420 million years after the instant of the time control (today, unless you move it; about two turns of the Sun), integrated in the same potential as the kinematic families, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), plus the rotating bar (Dehnen 2000 quadrupole). The chosen star, also its 2 billion years, without the bar: those give the pericentre, apocentre and Zmax of its card, comparable with the literature (so the drawn line can rise higher than its Zmax).",
                "El camino de cada estrella alrededor de la Galaxia en los 420 millones de años que siguen al instante del mando de tiempo (hoy, si no lo mueves; unas dos vueltas del Sol), integrado en el mismo potencial que las familias cinemáticas, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), más la barra que gira (cuadrupolo de Dehnen 2000). La elegida, además, sus 2000 millones de años, sin la barra: de ahí salen el pericentro, el apocentro y la Zmax de su ficha, comparables con la literatura (por eso la línea dibujada puede subir más que su Zmax)."],
   gxColour: ["Colour", "Color"],
   gxPop: ["Population", "Población"],
   gxAge: ["Age", "Edad"],
   gxFeh: ["[Fe/H]", "[Fe/H]"],
   gxPopTip: ["Coloured by population (thin disc, thick disc, halo, accreted).", "Color por población (disco fino, disco grueso, halo, acretada)."],
   gxAgeTip: ["Coloured by age: blue young, cream like the Sun, gold and red old. Grey hollow: no reliable age.", "Color por edad: azul joven, crema como el Sol, oro y rojo viejas. Hueco gris: sin edad fiable."],
   gxFehTip: ["Coloured by [Fe/H], the same scale as the photo: violet and blue poor in metals, cream solar, gold rich.", "Color por [Fe/H], la misma escala que la foto: violeta y azul pobres en metales, crema como el Sol, oro ricas."],
   gxWhere: ["The map takes the place of the three diagrams (chemistry, age–metallicity and kinematic families) while this group is open.", "Mientras este grupo está abierto, el mapa ocupa el sitio de los tres diagramas (química, edad–metalicidad y familias cinemáticas)."],
   // el mapa
   gxTitle: ["THE MILKY WAY", "LA VÍA LÁCTEA"],
   gxTitleName: ["Milky Way", "Vía Láctea"],      // (23-oct, R19: el nombre del mapa en la cursiva de las letras de A–E, sin «III»)
   gxTitleTop: ["seen from above (X–Y)", "desde arriba (X–Y)"],
   gxTitleEdge: ["edge-on (R–z)", "de canto (R–z)"],
   gxTitle3d: ["in 3D", "en 3D"],
   gxSun: ["Sun", "Sol"],
   gxGC: ["Galactic centre", "Centro galáctico"],
   gxRotation: ["rotation", "giro"],
   gxPlane: ["disc plane", "plano del disco"],
   gxArms: ["arms: illustrative, not a map", "brazos: ilustrativos, no son un mapa"],
   gxDisc: ["glow: mass of the disc and the bulge", "resplandor: masa del disco y del bulbo"],      // (23-oct, R11: en llano; el potencial, en el «?» de III)
   gxRing: ["{n} kpc", "{n} kpc"],
   gxAxisR: ["R  distance from the centre (kpc)", "R  distancia al centro (kpc)"],
   gxAxisZ: ["z (kpc)", "z (kpc)"],
   gxFoot: ["{n} stars with an orbit · {m} without radial velocity or distance", "{n} estrellas con órbita · {m} sin velocidad radial o sin distancia"],
   gxFootShort: ["{n} with an orbit · {m} without RV or distance", "{n} con órbita · {m} sin VR o distancia"],
   gxFootMin: ["{n} with an orbit", "{n} con órbita"],
   gxUnboundShort: ["{n} unbound", "{n} no ligadas"],
   gxFootOrbit: ["orbits: 420 Myr (the chosen one, 2 Gyr)", "órbitas: 420 Ma (la elegida, 2 Ga)"],
   // (2-nov-2026, noche: decisión Q2b de Nino; = CabraShared/csh_galaxy_i18n.js) lo dibujado lleva la barra y las cifras de la ficha (ccOrbit) no
   gxFootOrbitBar: ["orbits: 420 Myr (the chosen one, 2 Gyr) · drawn with the bar, numbers without", "órbitas: 420 Ma (la elegida, 2 Ga) · dibujadas con la barra, cifras sin ella"],
   gxFootBarNote: ["orbits drawn with the bar; the numbers (card, tooltips) without it", "órbitas dibujadas con la barra; las cifras (ficha, burbujas) sin ella"],
   gxFootNow: ["positions today", "posiciones de hoy"],
   gxOrbitsSubset: ["{n} of {m} orbits drawn", "{n} de {m} órbitas dibujadas"],
   gxAgeNone: ["no reliable age", "sin edad fiable"],
   gxFehNone: ["no [Fe/H]", "sin [Fe/H]"],
   gxAgeUnit: ["Gyr", "Ga"],
   gxSelOrbit: ["peri {p} · apo {a} · Zmax {z} kpc · e {e}", "peri {p} · apo {a} · Zmax {z} kpc · e {e}"],
   gxNoRes: ["Analyse an image to see its stars in the Milky Way.", "Analiza una imagen para ver sus estrellas en la Vía Láctea."],
   gxNoKin: ["No star of this field has an orbit: it needs radial velocity and distance.", "Ninguna estrella de este campo tiene órbita: hace falta velocidad radial y distancia."],
   gxUnbound: ["{n} not bound to the Galaxy (no orbit)", "{n} no ligadas a la Galaxia (sin órbita)"],
   // (23-oct) EL MANDO DE TIEMPO y la placa del mapa
   gxTime: ["Time", "Tiempo"],
   gxTimeNow: ["⟲ Today", "⟲ Hoy"],
   gxTimeNowTip: ["Back to today: the map of always.", "Vuelve a hoy: el mapa de siempre."],
   gxTimeTip: ["Move back in time, to the Big Bang on the left: each star goes to where it was along its orbit and only the ones already born are shown, lighting up gradually over their age interval (the rule of “The story of the field”). Stars without an age are not drawn in the past (when they were born is unknown); the Sun appears 4.57 billion years ago. The timeline under the photo marks that instant, and the photo and the diagrams show only the stars already born (when you let go of the ruler); “⟲ Today” brings everything back. The ruler runs fast through the distant past and slows down near today, like the clock of the video. With the video playing (▶ Preview, below), the ruler follows its clock and dragging it travels in time in the video. Past positions are illustrative: they are computed with today's Galaxy (no radial migration, disc heating, mergers or bar).",
               "Viaja hacia atrás en el tiempo, hasta el Big Bang a la izquierda: cada estrella va adonde estaba en su órbita y solo se ven las que ya habían nacido, encendiéndose poco a poco a lo largo de su intervalo de edad (la regla de «La historia del campo»). Las que no tienen edad no se pintan en el pasado (no se sabe cuándo nacieron); el Sol aparece hace 4570 millones de años. La línea de tiempo bajo la foto marca ese instante, y la foto y los diagramas enseñan solo las ya nacidas (al soltar la regla); «⟲ Hoy» lo devuelve todo. La regla corre deprisa por el pasado lejano y frena cerca de hoy, como el reloj del vídeo. Con el vídeo en marcha (▶ Vista previa, debajo), la regla sigue su reloj y arrastrarla viaja en el tiempo del vídeo. Las posiciones pasadas son ilustrativas: se calculan con la Galaxia de hoy (sin migración radial, sin calentamiento del disco, sin fusiones ni barra)."],
   // (23-oct, noche: cada frase dice su conjunto —aquí las del mapa, las que tienen órbita—; el vídeo «historia» cuenta las de química)
   gxtBorn: ["Of the {t} with an orbit: {n} of {m} with an age already born", "De las {t} con órbita: {n} de {m} con edad ya han nacido"],
   gxtNoAge: ["{n} without an age: not drawn in the past", "{n} sin edad: no se pintan en el pasado"],
   gxtIllustrative: ["past positions are illustrative: computed with today's Galaxy", "posiciones pasadas ilustrativas: se calculan con la Galaxia de hoy"],
   gxFootPast: ["positions then (illustrative)", "posiciones de entonces (ilustrativas)"],
   gxFootPastOrbit: ["orbits: 420 Myr from then (illustrative)", "órbitas: 420 Ma desde entonces (ilustrativas)"],
   gxtComputing: ["Computing the past of {n} orbits (13.8 billion years back)…", "Calculando el pasado de {n} órbitas (13 800 millones de años atrás)…"],
   // el vídeo «La Galaxia en el tiempo» (sustituye a «Órbitas» desde el 23-oct; en III desde el 29-oct)
   gxVideoTitle: ["The Galaxy through time", "La Galaxia en el tiempo"],
   gxVideoNow: ["today", "hoy"],
   gxVideoSub: ["the stars of your image round the Milky Way", "las estrellas de tu imagen alrededor de la Vía Láctea"],
   gxtVideoNote: ["Past positions are illustrative: computed with today's Galaxy (no radial migration, no mergers). The clock runs fast through the distant past and slows to orbit speed over the last 0.2 Gyr.",
                  "Posiciones pasadas ilustrativas: se calculan con la Galaxia de hoy (sin migración radial ni fusiones). El reloj corre deprisa por el pasado lejano y frena a la velocidad de las órbitas en los últimos 0,2 Ga."],
   gxtClock: ["Cosmic clock", "Reloj cósmico"],
   gxtThen: ["The Galaxy, then", "La Galaxia, entonces"],
   gxtNowEyebrow: ["The Galaxy, now", "La Galaxia, ahora"],
   gxtNowLine: ["the {t} stars with an orbit, also the {n} without an age", "las {t} estrellas con órbita, también las {n} sin edad"],
   gxtNowAll: ["every star of the field with an orbit", "todas las estrellas del campo con órbita"],
   gxtSlow: ["orbit speed: {r} Myr per second", "a velocidad de órbita: {r} Ma por segundo"],
   gxtFast: ["fast clock: {r} Myr per second · the rings are their orbits", "reloj deprisa: {r} Ma por segundo · los anillos son sus órbitas"]
};
function ccGxT(key) {
   var e = CC_GX_TXT[key];
   if (!e) return key;
   if (typeof ccGxBroken === "function" && ccGxBroken("mixlang") && key === "gxGC") return e[0];     // (ROJO «mixlang» de la sonda)
   return (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? e[1] : e[0];
}
function ccGxF(key, vals) {
   var t = ccGxT(key);
   for (var k in vals) if (vals.hasOwnProperty(k)) t = t.split("{" + k + "}").join(String(vals[k]));
   // (ROJO «oldborn» de T22: la frase sin su conjunto, como antes del 23-oct noche)
   if (key === "gxtBorn" && typeof CC_BREAK === "string" && CC_BREAK.indexOf("oldborn") >= 0 && t.indexOf(": ") > 0) t = t.substring(t.indexOf(": ") + 2);
   return t;
}
#endif
