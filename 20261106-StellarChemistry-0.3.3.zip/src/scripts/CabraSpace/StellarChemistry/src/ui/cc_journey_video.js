#ifndef __CC_JOURNEY_VIDEO_JS
#define __CC_JOURNEY_VIDEO_JS
// ============================================================================
// src/ui/cc_journey_video.js — EL GRABADOR de II · VIAJE Y VÍDEO (y del vídeo «Órbitas» de III) · CabraComposition, 22-oct-2026
// ----------------------------------------------------------------------------
// PROCEDENCIA: ADAPTACIÓN de CabraStars/lib/cs_flight_paint.js (commit 1413273): `csFlRecorder`, `csFlRecord`,
// `csFlContactSheet`, y de `csFlPlan` (cs_flight.js). Se conserva TAL CUAL: fotograma a fotograma desde un Timer (o de un
// tirón), JPEG temporal → AVI MJPEG (cc_journey_avi.js, copia de cs_video_avi.js), MP4 con ffmpeg si lo hay (el AVI
// intermedio a calidad 97 y luego `ccAviToMp4`), cancelar BORRA (también el AVI temporal y el .mp4 que ffmpeg estuviera
// escribiendo), «quedarse con lo grabado», y la HOJA DE CONTACTO de 12 fotogramas repartidos (`…_contact.png`).
// LO QUE CAMBIA: el pintor NO es un vuelo 3D sino CUALQUIER función `frameFn(g, w, h, t)`; los colores y la letra, los
// de CabraComposition (cc_atlas.js); cancelar también con CC_ABORT (cerrar la ventana) o con `opts.abort()`.
//
// LA INTERFAZ (la usa II con ccJourneyFrame y la puede usar III —fase 2b— para «Órbitas»):
//
//   var R = ccJourneyRecorder(opts, frameFn)          // para un Timer: el diálogo llama a R.step() en cada tic
//   var res = ccJourneyRecord(opts, frameFn, onProgress)   // de un tirón (pruebas, o sin Timer), bombeando la interfaz
//
//   frameFn(g, w, h, t)   pinta el fotograma del segundo t (0 ≤ t < duration) en un Graphics sobre un Bitmap de w × h
//                         que YA está relleno con el fondo (CC_ATLAS.bg). Lo que devuelva se pasa a opts.onFrame.
//                         No debe cerrar `g` ni guardar el Bitmap (se reutiliza).
//   opts = { path       ruta SIN extensión (o con .mp4/.avi: se quita); se le pone .mp4 o .avi y «_contact.png»,
//            width, height (pares, 16..8192), fps (30 | 60; otro → 30), duration (s, > 0),
//            format     "auto" (MP4 si hay ffmpeg, si no AVI; de fábrica) | "mp4" | "avi",
//            title      para la hoja de contacto, sheet (false = sin hoja de contacto), quality (85 | 92 | 97),
//            limit      bytes por parte del AVI (de fábrica, 2 GB), mp4: { crf, preset, encoder, timeoutS },
//            onFrame( k, bitmap, t, lo-que-devolvió-frameFn ), onEncode( segundos ) → false cancela la codificación,
//            abort()    → true cancela (además de CC_ABORT), keepOnCancel (false: cancelar borra todo) }
//   R = { ok, why, n (fotogramas), k (los hechos), format ("mp4" | "avi"), plan, step() → true si quedan,
//         cancel(), finishNow() (quedarse con lo grabado), result, done }
//   result = { ok, cancelled, partial, why, format, path (el vídeo), files: [{ path, frames, bytes }], frames, bytes,
//              contact (ruta de la hoja o ""), seconds, encodeSeconds, msPerFrame, paintMs, width, height, fps }
//   onProgress( k, n, bitmap ) → false cancela (ccJourneyRecord)
//
// Ningún fichero a medias: al cancelar (R.cancel, CC_ABORT, abort(), onProgress → false, onEncode → false) se borran
// las partes del AVI, el AVI temporal del MP4 y el .mp4 a medio escribir; no se guarda la hoja de contacto.
// Costuras de prueba (CC_BREAK): jframes (un fotograma de menos), jcancelkeep (cancelar no borra).
// NADA de esto va en `onPaint`. ES5.
// ============================================================================

var CC_JV = {
   SIZES: [{ key: "1080p", w: 1920, h: 1080, text: "1080p · 16:9" }, { key: "4k", w: 3840, h: 2160, text: "4K · 16:9" },
           { key: "square", w: 1080, h: 1080, text: "1080 · 1:1" }, { key: "vertical", w: 1080, h: 1920, text: "1080 × 1920 · 9:16" }],
   FPS: [30, 60],
   QUALITY: 92,
   JPEG_BYTES_PER_MPX: { 85: 80000, 92: 105000, 97: 160000 },     // (cs_flight.js CS_FL, medido allí)
   SHEET_N: 12, SHEET_COLS: 4, SHEET_W: 480
};

// EL PLAN: cuántos fotogramas y en qué segundo cae cada uno. { ok, why, n, fps, width, height, duration, quality, time(k), bytes }
function ccJourneyPlan(opts) {
   var o = opts || {}, fps = (CC_JV.FPS.indexOf(o.fps) >= 0) ? o.fps : 30, w = Math.round(Number(o.width) || 1920), h = Math.round(Number(o.height) || 1080), d = Number(o.duration);
   var out = { ok: false, why: "", fps: fps, n: 0, duration: d, width: w, height: h, quality: 0, bytes: 0, time: null };
   if (!(d > 0) || !isFinite(d)) { out.why = "no duration"; return out; }
   if (!(w >= 16 && h >= 16 && w <= 8192 && h <= 8192) || (w % 2) || (h % 2)) { out.why = "bad frame size"; return out; }
   var q = (o.quality === 85 || o.quality === 97) ? o.quality : CC_JV.QUALITY, n = Math.max(2, Math.round(d * fps));
   if (ccJBroken("jframes")) n -= 1;
   out.quality = q; out.n = n;
   out.time = function(k) { return Math.max(0, Math.min(n - 1, k)) / fps; };
   out.bytes = Math.round(CC_JV.JPEG_BYTES_PER_MPX[q] * w * h / 1e6) * n;
   out.ok = true;
   return out;
}
// Un nombre que aún no existe: <dir>/CabraComposition_<título>_<modo>_<w>x<h>, y _2, _3… si ya está (sin extensión).
function ccJourneyVideoPath(dir, title, mode, w, h) {
   var base = String(title || "").replace(/[^A-Za-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
   if (base.length === 0) base = "Video";
   base = String(dir).split("\\").join("/").replace(/\/+$/, "") + "/" + CC_APP_NAME + "_" + base + "_" + mode + "_" + w + "x" + h;
   for (var k = 1; k < 1000; ++k) { var p = base + ((k > 1) ? "_" + k : ""); if (!File.exists(p + ".mp4") && !File.exists(p + ".avi") && !File.exists(p + "_contact.png")) return p; }
   return base + "_" + Date.now();
}

// LA HOJA DE CONTACTO: SHEET_N fotogramas repartidos, en una rejilla, con su número y su segundo. `shots` = [{ k, t, bmp }].
function ccJourneyContactSheet(shots, path, info) {
   if (!shots || shots.length === 0) return "";
   var cols = Math.min(CC_JV.SHEET_COLS, shots.length), rows = Math.ceil(shots.length / cols), cw = shots[0].bmp.width, ch = shots[0].bmp.height;
   var pad = 10, capH = 22, headH = 34, W = cols * cw + (cols + 1) * pad, H = headH + rows * (ch + capH) + (rows + 1) * pad;
   var out = new Bitmap(W, H), E = (typeof CC_LANG !== "undefined" && CC_LANG === "es");
   out.fill(ccInt(CC_ATLAS.bg));
   var g = new Graphics(out), fCap = ccFont("text", 13), fHead = ccFont("text", 15, true);
   try {
      g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
      g.font = fHead; g.pen = new Pen(ccInt(CC_ATLAS.gold)); g.drawText(pad, pad + fHead.ascent, String(info || ""));
      for (var i = 0; i < shots.length; ++i) {
         var c = i % cols, r = Math.floor(i / cols), x = pad + c * (cw + pad), y = headH + pad + r * (ch + capH + pad);
         g.drawBitmap(x, y, shots[i].bmp);
         g.pen = new Pen(ccInt(CC_ATLAS.line), 1); g.brush = new Brush(0x00000000); g.drawRect(x, y, x + cw - 1, y + ch - 1);
         var tt = shots[i].t.toFixed(2);
         if (E) tt = tt.replace(".", ",");
         g.font = fCap; g.pen = new Pen(ccInt(CC_ATLAS.text2)); g.drawText(x, y + ch + 4 + fCap.ascent, "#" + (shots[i].k + 1) + " · t = " + tt + " s");
      }
   } finally { g.end(); }
   var ok = false;
   try { out.save(path); ok = File.exists(path); } catch (e) { ok = false; }
   out.clear();
   return ok ? path : "";
}

function ccJourneyRemove(p) {
   for (var i = 0; i < 20 && File.exists(p); ++i) { try { File.remove(p); } catch (e) { try { msleep(100); } catch (eS) {} } }
   return !File.exists(p);
}

// EL GRABADOR (ver la cabecera).
function ccJourneyRecorder(opts, frameFn) {
   var o = opts || {}, plan = ccJourneyPlan(o);
   var R = { ok: false, why: "", n: plan.n, k: 0, done: true, plan: plan, result: null, format: "", bitmap: null, step: function() { return false; }, cancel: function() {}, finishNow: function() {} };
   if (!plan.ok) { R.why = plan.why; return R; }
   if (typeof frameFn !== "function") { R.why = "no frame painter"; return R; }
   if (!o.path) { R.why = "no path"; return R; }
   var W = null, t0 = Date.now(), paintMs = 0, bmp = null;
   var mp4 = (o.format === "mp4" || (o.format !== "avi")) && ccAviFfmpeg().available;
   if (o.format === "mp4" && !mp4) { R.why = "ffmpeg not available"; return R; }
   var base = String(o.path).split("\\").join("/").replace(/\.(avi|mp4)$/i, "");
   var outPath = base + (mp4 ? ".mp4" : ".avi"), tmpDir = String(o.tempDir || File.systemTempDirectory).split("\\").join("/");
   var aviPath = mp4 ? tmpDir + "/cc_journey_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ".avi" : outPath;
   var quality = mp4 ? CC_AVI.MP4_SOURCE_QUALITY : plan.quality;
   var sheetOn = (o.sheet !== false), want = {}, shots = [], sw = Math.min(CC_JV.SHEET_W, plan.width), sh = Math.max(2, Math.round(sw * plan.height / plan.width)), q;
   for (q = 0; q < CC_JV.SHEET_N; ++q) want[Math.round(q * (plan.n - 1) / Math.max(1, CC_JV.SHEET_N - 1))] = true;
   R.format = mp4 ? "mp4" : "avi"; R.path = outPath; R.aviPath = aviPath;
   try { bmp = new Bitmap(plan.width, plan.height); } catch (eB) { R.why = String(eB); return R; }
   try { W = ccAviOpen(aviPath, plan.width, plan.height, plan.fps, { limit: o.limit, tempDir: o.tempDir }); } catch (e) { R.why = String(e); try { bmp.clear(); } catch (eC) {} return R; }
   R.bitmap = bmp;
   function freeShots() { for (var i = 0; i < shots.length; ++i) { try { shots[i].bmp.clear(); } catch (e) {} } shots = []; }
   function finish(cancelled, why) {
      if (R.done) return;
      R.done = true;
      var c = W.close(), tFrames = Date.now(), files = c.files, bytes = c.bytes, format = "avi", enc = null, i;
      if (mp4 && c.ok && !cancelled && !why) {
         var parts = [];
         for (i = 0; i < c.files.length; ++i) parts.push(c.files[i].path);
         var mo = o.mp4 || {};
         var onTick = function(secs) {
            if (typeof CC_ABORT !== "undefined" && CC_ABORT) return false;
            if (typeof o.abort === "function") { try { if (o.abort()) return false; } catch (eA) {} }
            if (typeof o.onEncode === "function") { try { if (o.onEncode(secs) === false) return false; } catch (eO) {} }
            return true;
         };
         enc = ccAviToMp4(parts, outPath, { crf: mo.crf, preset: mo.preset, encoder: mo.encoder, timeoutS: mo.timeoutS, onTick: onTick });
         if (!enc.ok && enc.why === "cancelled") {
            // (CabraStars A3, F1) la codificación CANCELADA es una grabación cancelada: no queda nada
            for (i = 0; i < parts.length; ++i) ccJourneyRemove(parts[i]);
            ccJourneyRemove(outPath);
            cancelled = true; files = []; bytes = 0;
         } else if (enc.ok) {
            for (i = 0; i < parts.length; ++i) ccJourneyRemove(parts[i]);
            files = [{ path: outPath, frames: c.frames, bytes: enc.bytes }]; bytes = enc.bytes; format = "mp4";
         } else {
            // ffmpeg falló: se queda el AVI (movido junto a donde iba el MP4)
            var kept = [];
            ccJourneyRemove(outPath);
            for (i = 0; i < c.files.length; ++i) {
               var dst = ccAviPartPath(base + ".avi", i + 1), moved = false;
               try { File.move(c.files[i].path, dst); moved = File.exists(dst); } catch (eM) {}
               if (!moved) { try { File.copyFile(dst, c.files[i].path); moved = File.exists(dst); if (moved) File.remove(c.files[i].path); } catch (eC2) {} }
               kept.push({ path: moved ? dst : c.files[i].path, frames: c.files[i].frames, bytes: c.files[i].bytes });
            }
            files = kept;
            why = "mp4 failed (" + enc.why + "): the AVI is kept";
         }
      }
      if (cancelled && o.keepOnCancel !== true && !ccJBroken("jcancelkeep")) {
         for (i = 0; i < c.files.length; ++i) ccJourneyRemove(c.files[i].path);
         if (mp4) { ccJourneyRemove(aviPath); ccJourneyRemove(outPath); }
         files = []; bytes = 0;
      }
      var contact = "", nShots = shots.length;
      if (sheetOn && !cancelled && c.ok && shots.length > 0)
         contact = ccJourneyContactSheet(shots, base + "_contact.png", ccJT("jContactInfo", String(o.title || ""), plan.width, plan.height, plan.fps, c.frames));
      freeShots();
      try { bmp.clear(); } catch (eF) {}
      R.bitmap = null;
      R.result = { ok: (c.ok && !cancelled && !why), cancelled: !!cancelled, partial: false, why: why || c.why || "", format: format, path: (files.length ? files[0].path : ""), frames: c.frames, bytes: bytes, files: files,
                   seconds: (Date.now() - t0) / 1000, encodeSeconds: (enc !== null) ? enc.seconds : 0, encodeHow: (enc !== null) ? (enc.how || "") : "", encodeTicks: (enc !== null) ? (enc.ticks || 0) : 0, encodeTickMaxMs: (enc !== null) ? (enc.tickMaxMs || 0) : 0, aviBytes: c.bytes, contact: contact, sheetShots: nShots,
                   msPerFrame: (R.k > 0) ? (tFrames - t0) / R.k : 0, paintMs: (R.k > 0) ? paintMs / R.k : 0, width: plan.width, height: plan.height, fps: plan.fps };
   }
   R.ok = true; R.done = false;
   R.step = function() {
      if (R.done) return false;
      var a, t = plan.time(R.k), drawn = null, tp = Date.now();
      try {
         bmp.fill(ccInt(CC_ATLAS.bg));
         var g = new Graphics(bmp);
         try { g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {} drawn = frameFn(g, plan.width, plan.height, t); } finally { g.end(); }
         paintMs += Date.now() - tp;
         if (sheetOn && want[R.k]) {
            var sb = new Bitmap(sw, sh), gs = new Graphics(sb);
            try { gs.smoothInterpolation = true; gs.drawScaledBitmap(new Rect(0, 0, sw, sh), bmp); } finally { gs.end(); }
            shots.push({ k: R.k, t: t, bmp: sb });
         }
         if (typeof o.onFrame === "function") o.onFrame(R.k, bmp, t, drawn);
         a = W.addBitmap(bmp, quality);
      } catch (e) { a = { ok: false, why: String(e) }; }
      if (!a.ok) { finish(false, a.why || "frame failed"); return false; }
      ++R.k;
      if (R.k >= R.n) { finish(false, ""); return false; }
      return true;
   };
   R.cancel = function() { finish(true, ""); };
   R.finishNow = function() { if (R.done) return; if (R.k < 1) { finish(true, ""); return; } finish(false, ""); if (R.result) R.result.partial = true; };
   return R;
}

// DE UN TIRÓN (pruebas, o quien no tenga Timer): bombea la interfaz entre fotogramas; CC_ABORT, opts.abort() y
// onProgress( k, n, bitmap ) → false cancelan (y no queda nada).
function ccJourneyRecord(opts, frameFn, onProgress) {
   var o = opts || {}, R = ccJourneyRecorder(o, frameFn);
   if (!R.ok) return { ok: false, cancelled: false, partial: false, why: R.why, format: "", path: "", frames: 0, bytes: 0, files: [], contact: "", seconds: 0, msPerFrame: 0 };
   while (R.step()) {
      try { cshProcessEvents(); } catch (eP) {}
      var stop = (typeof CC_ABORT !== "undefined" && CC_ABORT === true);
      if (!stop && typeof o.abort === "function") { try { stop = !!o.abort(); } catch (eA) {} }
      if (!stop && typeof onProgress === "function") { try { stop = (onProgress(R.k, R.n, R.bitmap) === false); } catch (eO) {} }
      if (stop) { R.cancel(); break; }
   }
   return R.result;
}
#endif
