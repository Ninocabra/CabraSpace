#ifndef __CC_JOURNEY_PAINT_JS
#define __CC_JOURNEY_PAINT_JS
// ============================================================================
// src/ui/cc_journey_paint.js — II · VIAJE Y VÍDEO: PINTAR UN FOTOGRAMA (CabraComposition, 22-oct-2026, fase 2a)
// ----------------------------------------------------------------------------
//   ccJourneyFrame(g, w, h, S, sc, mode, t, opts) -> stats
//      Pinta UN fotograma COMPLETO de w × h en `g` (para la vista previa en el panel y para la grabación): la foto con sus
//      estrellas (2a: encendidas según su edad; 2c: todas, con la visitada en oro y la cámara acercándose), los diagramas
//      B, C y D como franja (con SOLO las nacidas en 2a; con la visitada elegida en 2c), la línea de tiempo propia del
//      vídeo (los episodios de CC_TIMELINE, el frente del tiempo en 2a, la edad de la visitada en 2c), la placa y el título.
//      S = el estado del diálogo (cc_dialog.js ccNewState): SE LEE, NUNCA se escribe (los paneles B/C/D se pintan con
//      una copia propia, `ccJourneyState`, con sus propias zonas S.hits, su geometría y su anim). mode = "history" | "tour".
//      t = segundos de vídeo. sc = la escala de la letra y los trazos: para que se vea como el vídeo, `ccJourneyScale(w, h)`
//      (min(w, h) / 600: 1,8 a 1080p, 3,6 a 4K); null o 0 → esa. opts = { title, duration (solo 2a) }.
//      stats = { ok, mode, T, phase, lit, litNoAge, nAge, nNoAge, episodes, primary, stop, stopIdx, star: {x, y, inside, off},
//                plate: { lines: [texto…], cut }, ms }  (lo que se pintó: lo miden las pruebas).
//   PROCEDENCIA de las ideas (no del código): CabraStars/lib/cs_flight_paint.js — el texto en fracción del alto (aquí sc),
//   la placa achicada o partida y nunca «…», el título con versalita encima, la vista previa como el vídeo en pequeño.
//   Lo que pinta las estrellas y los diagramas es de CabraComposition (cc_paint.js: ccStarGlyph, ccSelRing, ccPaintAlpha,
//   ccPaintAgeMet, ccPaintFamD): se llaman tal cual; su firma (g, w, h, S, sc, part) es la del encargo.
// LOS «?» de ayuda, los «…» de los pies y las píldoras E–Lz | Toomre no tienen sentido en un vídeo: la copia del estado lleva
// `video: true` y cc_paint.js no los pinta (integración, 22-oct: sustituye al cambio de ccQMark de la fase 2a). Lleva también
// `elem` (IV · Elementos): el vídeo colorea la foto y pone el eje de B por el elemento elegido, como el diálogo.
// NADA de esto va en `onPaint` de un control: se pinta en un Bitmap y el control lo copia. ES5.
// ============================================================================

var CC_JP = {
   REF: 600,              // el alto (o el ancho, el menor) de un fotograma a escala 1
   // (23-oct, noche, revisión visual 1: la línea de tiempo del vídeo, con los MISMOS episodios que la del diálogo —Big Bang, Sequoia, Helmi—
   //  en sus cuatro carriles: 88 → 118 de alto para que quepan con su letra)
   PAD: 14, GAP: 10, TL_H: 118,
   // el velo negro sobre la foto: EL MISMO que la vista «Composición» del diálogo (ccPaintPhoto, 0,18). (23-oct, revisor R2: con 0,45 en
   // «La historia del campo» el cielo salía un 35 % más oscuro —mediana del fondo 33 frente a 49–51 del recorrido y del diálogo—; las
   // estrellas que aún no han nacido ya no se pintan, así que no hay nada que apagar en el fondo. ROJO «histveil» de T18: 0,45)
   VEIL_HISTORY: 0.18, VEIL_TOUR: 0.18,
   MAX_UPSAMPLE: 1.4,     // (R24) el zoom del recorrido no amplía la foto más de 1,4 px de pantalla por px del bitmap (más, se ve blanda)
   PANEL_REF_W: 480, PANEL_REF_H: 200,     // un diagrama de este tamaño lógico se pinta a escala 1 (con menos de ~460 de ancho
                                           // lógico, el título de B y su leyenda «frontera α alto / bajo» se pisan: 1:1 del 22-oct)
   GLYPH_K: 0.8,          // los símbolos de la foto, a 0,8 de la escala del fotograma (como en el diálogo a 1,5)
   PLATE_MAX_LINES: 3,    // la frase de la placa: hasta 3 líneas; si no cabe, se achica la letra (nunca «…»)
   // (2-nov, Nino: «el cartel está tapando la imagen»: en la historia no se veía nacer las estrellas y en el recorrido la placa tapaba la
   //  estrella de la parada. La placa, más pequeña —letra al 80 %, como mucho el 46 % del ancho de la foto— y con el fondo al 80 %: un 20 %
   //  de transparencia, la que pidió. En el recorrido, además, la placa va a la esquina que no pisa la estrella. ROJO «plateglass»: la placa
   //  de antes, opaca, a todo lo ancho y siempre abajo a la izquierda)
   PLATE_FK: 0.8, PLATE_MAX_FRAC: 0.46, PLATE_BG_A: 0.8
};

function ccJourneyScale(w, h) { return Math.max(0.3, Math.min(w, h) / CC_JP.REF); }
function ccJLang() { return (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en"; }

// LA MAQUETA según la forma: 16:9 (foto a la izquierda, B/C/D en columna), 1:1 (foto arriba, B y C en fila) y 9:16 (foto
// arriba, B/C/D apilados); la línea de tiempo siempre abajo a lo ancho. La foto con SU proporción (`fa`), sin bandas.
function ccJourneyLayout(w, h, k, fa) {
   var pad = Math.round(CC_JP.PAD * k), gap = Math.round(CC_JP.GAP * k), tlH = Math.round(CC_JP.TL_H * k), a = w / h, i;
   var L = { pad: pad, gap: gap, k: k, shape: (a >= 1.25) ? "wide" : ((a >= 0.8) ? "square" : "tall"), panels: [] };
   L.tl = { x: pad, y: h - pad - tlH, w: w - 2 * pad, h: tlH };
   var topH = h - 3 * pad - tlH;
   if (!(fa > 0.05 && fa < 20)) fa = 1.5;
   if (L.shape === "wide") {
      var pw = Math.min(Math.round((w - 3 * pad) * 0.64), Math.round(topH * fa)), ph = Math.min(topH, Math.round(pw / fa));
      L.photo = { x: pad, y: pad + Math.round((topH - ph) / 2), w: pw, h: ph };
      var cx = 2 * pad + pw, cw = w - cx - pad, chh = Math.floor((topH - 2 * gap) / 3);
      for (i = 0; i < 3; ++i) L.panels.push({ x: cx, y: pad + i * (chh + gap), w: cw, h: (i < 2) ? chh : topH - 2 * (chh + gap) });
   } else {
      var pw2 = w - 2 * pad, ph2 = Math.round(pw2 / fa), cap = Math.round(topH * ((L.shape === "square") ? 0.6 : 0.46));
      if (ph2 > cap) { ph2 = cap; pw2 = Math.round(ph2 * fa); }
      L.photo = { x: Math.round((w - pw2) / 2), y: pad, w: pw2, h: ph2 };
      var rest = topH - ph2 - pad, y0 = 2 * pad + ph2;
      if (L.shape === "square") {
         // (1:1: DOS diagramas, B y C, en fila; con tres, a 1080 px cada uno medía 330 px y su letra ~7 px —captura del 22-oct—.
         //  D se queda fuera en este formato: la edad y la química son lo que cuenta la historia)
         var bw = Math.floor((w - 2 * pad - gap) / 2);
         for (i = 0; i < 2; ++i) L.panels.push({ x: pad + i * (bw + gap), y: y0, w: (i < 1) ? bw : w - 2 * pad - bw - gap, h: rest });
      } else {
         var bh = Math.floor((rest - 2 * gap) / 3);
         for (i = 0; i < 3; ++i) L.panels.push({ x: pad, y: y0 + i * (bh + gap), w: w - 2 * pad, h: (i < 2) ? bh : rest - 2 * (bh + gap) });
      }
   }
   return L;
}

// La COPIA del estado con la que se pintan B, C y D (S del diálogo no se toca).
function ccJourneyState(M, list, sel, pulse) {
   return { res: M.res, list: list, photo: M.photo, sel: (sel >= 0) ? sel : -1, hover: -1, group: null, groupKey: "", opts: M.opts,
            zoom: { k: 1, cx: M.field.width / 2, cy: M.field.height / 2 }, anim: { sel: 1, card: 1, pulse: pulse || 0, tlFrom: null, aMix: 1 },
            viewId: M.viewId, info: null, prog: { text: "", frac: 0, busy: false, error: false, right: "" }, photoNote: "", hits: {}, tip: null,
            dView: M.dView, aView: "comp", cardDetail: false, cardScroll: 0, cardContentH: 0, compact: true, frame: null, gaiaPreview: null,
            video: true, elem: M.elem || "Fe" };
}

// La foto con zoom: la cámara { cx, cy, k } en píxeles de la imagen; el centro se acota para no enseñar nada fuera del campo.
function ccJourneyPhotoXf(R, F, cam) {
   var iw = F.width, ih = F.height, base = Math.min(R.w / iw, R.h / ih), k = Math.max(1, cam.k || 1), s = base * k;
   var hw = R.w / (2 * s), hh = R.h / (2 * s);
   var cx = (2 * hw >= iw) ? iw / 2 : ccJClamp(cam.cx, hw, iw - hw), cy = (2 * hh >= ih) ? ih / 2 : ccJClamp(cam.cy, hh, ih - hh);
   return { s: s, cx: cx, cy: cy, k: k,
            toScr: function(x, y) { return { x: R.x + R.w / 2 + (x - cx) * s, y: R.y + R.h / 2 + (y - cy) * s }; },
            toImg: function(X, Y) { return { x: cx + (X - R.x - R.w / 2) / s, y: cy + (Y - R.y - R.h / 2) / s }; } };
}
function ccJourneyPaintPhoto(g, R, M, X, veil, k) {
   ccFillRect(g, R.x, R.y, R.x + R.w, R.y + R.h, ccInt(CC_INSET));
   var P = M.photo;
   if (P && P.bitmap) {
      var b = P.bitmap, f = P.factor || 1, p0 = X.toImg(R.x, R.y), p1 = X.toImg(R.x + R.w, R.y + R.h);
      var sx0 = Math.max(0, p0.x * f), sy0 = Math.max(0, p0.y * f), sx1 = Math.min(b.width, p1.x * f), sy1 = Math.min(b.height, p1.y * f);
      if (sx1 > sx0 && sy1 > sy0) {
         var d0 = X.toScr(sx0 / f, sy0 / f), d1 = X.toScr(sx1 / f, sy1 / f);
         g.smoothInterpolation = true;
         g.drawScaledBitmapRect(new Rect(Math.round(d0.x), Math.round(d0.y), Math.round(d1.x), Math.round(d1.y)), b, new Rect(Math.floor(sx0), Math.floor(sy0), Math.ceil(sx1), Math.ceil(sy1)));
      }
   } else {
      // sin foto: el campo como una rejilla (la de ccPaintPhoto)
      var a = X.toScr(0, 0), c = X.toScr(M.field.width, M.field.height);
      ccFillRect(g, Math.max(R.x, a.x), Math.max(R.y, a.y), Math.min(R.x + R.w, c.x), Math.min(R.y + R.h, c.y), ccInt(CC_ATLAS.bg));
      g.pen = ccPen(ccInt(CC_LINE_STRONG, 0.7), 1);
      for (var i = 1; i < 6; ++i) { var gx = a.x + (c.x - a.x) * i / 6, gy = a.y + (c.y - a.y) * i / 6; if (gx > R.x && gx < R.x + R.w) g.drawLine(gx, R.y, gx, R.y + R.h); if (gy > R.y && gy < R.y + R.h) g.drawLine(R.x, gy, R.x + R.w, gy); }
   }
   if (veil > 0.004) ccFillRect(g, R.x, R.y, R.x + R.w, R.y + R.h, ccInt("#000000", veil));
}
function ccJInside(q, R, m) { return q.x >= R.x - m && q.x <= R.x + R.w + m && q.y >= R.y - m && q.y <= R.y + R.h + m; }

// UN BLOQUE DE TEXTO sobre placa opaca, abajo a la izquierda de R (o arriba a la derecha: align "tr").
// items = [{ text, font: [role, px, bold, italic, spacing], color, wrap (líneas máximas, 1 de fábrica), caps }]
// Lo que no cabe en una línea se achica hasta 0,8 y, si lleva `wrap`, se parte (nunca «…»). Devuelve { lines, cut, box }.
// (24-oct) `avoid` = una caja que la placa no debe pisar (el reloj analógico arriba): si la pisa, la placa se estrecha hasta dejarla a su
// derecha (reloj a la derecha) o se corre a su derecha (reloj a la izquierda) y se vuelve a medir (parte más líneas, crece hacia arriba).
// (2-nov) `keep` = { x, y, r }: un punto que la placa no debe tapar (la estrella de la parada). La placa prueba abajo a la izquierda, abajo
// a la derecha y arriba a la izquierda (arriba a la derecha va «Parada n de m») y se queda en la primera que no lo pisa.
function ccJourneyPlate(g, R, k, items, alpha, align, avoid, keep) {
   var out = { lines: [], cut: false, box: null, corner: (align === "tr") ? "tr" : "bl" };
   if (!(alpha > 0.004) || !items.length) return out;
   var old = ccJBroken("plateglass"), fk = old ? 1 : CC_JP.PLATE_FK;
   var m = Math.round(16 * k), padX = Math.round(14 * k * fk), padY = Math.round(10 * k * fk), maxW = Math.min(R.w - 2 * m - 2 * padX, Math.round(760 * k)), rows = [], i, j;
   if (!old && align !== "tr") maxW = Math.min(maxW, Math.round(CC_JP.PLATE_MAX_FRAC * R.w) - 2 * padX);
   // (2-nov, S4b del vídeo de formación; visto en Collinder 34 EN, parada 3 de la vista previa 961 × 268: con la estrella en el centro el hueco a cada lado
   //  era de 427 px y la placa (el 46 % del ancho: 443) no cabía en NINGUNA esquina: se quedaba abajo a la izquierda, rozando el anillo. Con una estrella que
   //  guardar, la placa no pasa del mayor de los dos huecos laterales, y la frase parte más líneas. ROJO «platekeepcap»: el tope de antes)
   if (keep && !old && align !== "tr" && !ccJBroken("platekeepcap")) {
      var rk0 = keep.r + m, side = Math.max(keep.x - rk0 - (R.x + m), (R.x + R.w - m) - (keep.x + rk0));
      if (side - 2 * padX >= 140 * k) maxW = Math.min(maxW, Math.floor(side) - 2 * padX);
   }
   var xs = null;
   for (var pass = 0; pass < 2; ++pass) {
   rows = []; out.lines = []; out.cut = false;
   for (i = 0; i < items.length; ++i) {
      var it = items[i];
      if (!it || !it.text) continue;
      // (2-nov: se achica la letra GRANDE; la pequeña no baja de 8,4, o la vista previa queda por debajo de 7 px lógicos —T17 X9—)
      var F = it.font, px = Math.max(F[1] * fk, Math.min(F[1], 8.4)) * k, text = it.caps ? ccCaps(it.text) : String(it.text), font = ccFont(F[0], px, F[2], F[3], F[4] ? Math.round(px * F[4]) : 0), lines = [text], wrap = it.wrap ? it.wrap + (old ? 0 : 1) : 1;      // (2-nov: la placa estrecha parte en una línea más)
      for (var shrink = 0; shrink < 5; ++shrink) {
         lines = (wrap > 1) ? ccWrap(font, text, maxW) : [text];
         var widest = 0; for (j = 0; j < lines.length; ++j) widest = Math.max(widest, font.width(lines[j]));
         if (lines.length <= wrap && widest <= maxW) break;
         px *= 0.95; font = ccFont(F[0], px, F[2], F[3], F[4] ? Math.round(px * F[4]) : 0);
      }
      var wd = 0; for (j = 0; j < lines.length; ++j) wd = Math.max(wd, font.width(lines[j]));
      if (lines.length > wrap || wd > maxW) out.cut = true;
      rows.push({ font: font, color: it.color, lines: lines, gapAfter: Math.round((it.gap !== undefined ? it.gap : 4) * k) });
      for (j = 0; j < lines.length; ++j) out.lines.push(lines[j]);
   }
   if (!rows.length) return out;
   var H = 2 * padY, W = 0;
   for (i = 0; i < rows.length; ++i) {
      for (j = 0; j < rows[i].lines.length; ++j) { H += rows[i].font.ascent + rows[i].font.descent; W = Math.max(W, rows[i].font.width(rows[i].lines[j])); }
      if (i + 1 < rows.length) H += rows[i].gapAfter;
   }
   W += 2 * padX;
   var x0 = (align === "tr") ? R.x + R.w - m - W : ((xs !== null) ? xs : R.x + m), y0 = (align === "tr") ? R.y + m : R.y + R.h - m - H;
   out.box = { x0: x0, y0: y0, x1: x0 + W, y1: y0 + H };
   var A0 = (pass === 0 && avoid && align !== "tr" && !ccJBroken("jclockplate")) ? avoid : null;
   if (!A0 || A0.x1 + m <= x0 || x0 + W + m <= A0.x0 || A0.y1 + m <= y0 || y0 + H + m <= A0.y0) break;
   var left = (A0.x0 + A0.x1) / 2 < R.x + R.w / 2, w2 = left ? R.x + R.w - m - (A0.x1 + m) - 2 * padX : A0.x0 - m - x0 - 2 * padX;
   if (!(w2 > 120 * k)) break;
   if (left) xs = A0.x1 + m;                     // (el reloj a la izquierda: la placa se corre a su derecha)
   else if (w2 >= maxW) break;                   // (a la derecha: la placa, a su izquierda, más estrecha)
   maxW = Math.min(maxW, w2);
   }
   if (keep && !old && align !== "tr") {
      var cands = [["bl", R.x + m, R.y + R.h - m - H], ["br", R.x + R.w - m - W, R.y + R.h - m - H], ["tl", R.x + m, R.y + m]], rk = keep.r + m;
      for (i = 0; i < cands.length; ++i) {
         var cx0 = cands[i][1], cy0 = cands[i][2];
         if (keep.x + rk <= cx0 || keep.x - rk >= cx0 + W || keep.y + rk <= cy0 || keep.y - rk >= cy0 + H) { out.corner = cands[i][0]; x0 = cx0; y0 = cy0; break; }
      }
      out.box = { x0: x0, y0: y0, x1: x0 + W, y1: y0 + H };
   }
   g.opacity = alpha;
   g.antialiasing = true;
   // (23-oct, revisor R6: con el fondo al 86 % los anillos de las estrellas de debajo se veían ENCIMA del texto: la placa es OPACA y va
   //  encima de todo; solo el fundido de entrada/salida la transparenta. ROJO «plateglass» de T18: el 86 % de antes)
   //  (y en el fundido, el fondo se hace opaco tres veces más deprisa que el texto: a medio fundido los anillos ya no asoman —vídeo del
   //   23-oct, t = 2 s y t = 38 s—)
   //  (2-nov: Nino pide ver a través, el fondo al 80 %; el texto sigue opaco)
   if (!old) g.opacity = Math.min(1, 3 * alpha);
   g.fillRoundedRect(x0, y0, x0 + W, y0 + H, 6, 14, ccBrush(ccInt(CC_ATLAS.bg, old ? 1 : CC_JP.PLATE_BG_A)));
   ccNoBrush(g); g.pen = ccPen(ccInt(CC_ATLAS.line), 1); g.drawRoundedRect(x0, y0, x0 + W, y0 + H, 6, 14);
   g.opacity = alpha;
   var y = y0 + padY;
   for (i = 0; i < rows.length; ++i) {
      for (j = 0; j < rows[i].lines.length; ++j) {
         y += rows[i].font.ascent;
         var tx = (align === "tr") ? x0 + W - padX - rows[i].font.width(rows[i].lines[j]) : x0 + padX;
         ccTextAt(g, rows[i].font, rows[i].color, tx, y, rows[i].lines[j]);
         y += rows[i].font.descent;
      }
      y += rows[i].gapAfter;
   }
   g.opacity = 1;
   return out;
}

// B, C y D pintados por cc_paint.js en su recuadro, cada uno en su bitmap (sin los «?»: S2.video, ver la cabecera).
function ccJourneyPanels(g, L, S2, T, mode) {
   var painters = [(typeof ccPaintAlpha === "function") ? ccPaintAlpha : null, (typeof ccPaintAgeMet === "function") ? ccPaintAgeMet : null, (typeof ccPaintFamD === "function") ? ccPaintFamD : null], n = 0;
   for (var i = 0; i < L.panels.length; ++i) {
      var R = L.panels[i], P = painters[i];
      if (!P || R.w < 60 || R.h < 50) continue;
      var kp = ccJClamp(Math.min(R.w / CC_JP.PANEL_REF_W, R.h / CC_JP.PANEL_REF_H), 0.5, L.k), b = new Bitmap(R.w, R.h), gb = new Graphics(b);
      try {
         gb.antialiasing = true; gb.textAntialiasing = true;
         P(gb, R.w, R.h, S2, kp, "base"); P(gb, R.w, R.h, S2, kp, "over");
         // 2a: el FRENTE DEL TIEMPO en C (edad–metalicidad): lo que aún no ha nacido, a la derecha de la línea, velado
         if (i === 1 && mode === "history" && S2.geomC && typeof S2.geomC.X === "function") {
            var Pc = S2.geomC, xT = Pc.X(ccJClamp(T, 0, 14)), xr = Pc.L + Pc.pw;
            var yv = Pc.T + Math.round(16 * kp);      // (sin tapar el rótulo «13,8 · N en el límite de los modelos» de arriba)
            if (xr - xT > 1) ccFillRect(gb, xT, yv, xr, Pc.T + Pc.ph, ccInt(CC_ATLAS.bg, 0.55));
            gb.pen = ccPen(ccInt(CC_ATLAS.text, 0.85), Math.max(1, 1.2 * kp)); gb.drawLine(xT, Pc.T, xT, Pc.T + Pc.ph);
         }
      } finally { gb.end(); }
      g.drawBitmap(R.x, R.y, b);
      try { b.clear(); } catch (eB) {}
      ++n;
   }
   return n;
}

// LA LÍNEA DE TIEMPO DEL VÍDEO (propia: más alta de letra que E, con el frente del tiempo). Los episodios, de CC_TIMELINE.
// T = el reloj cósmico (2a) o null; star = la visitada (2c) o null.
function ccJourneyTimeline(g, R, k, M, T, star) {
   var E = ccJLang() === "es", TL = (typeof CC_TIMELINE !== "undefined") ? CC_TIMELINE : [], i, U = ccJUniverse();
   g.antialiasing = true;
   g.fillRoundedRect(R.x, R.y, R.x + R.w, R.y + R.h, 2, 6, ccBrush(ccInt(CC_ATLAS.surface)));
   ccNoBrush(g); g.pen = ccPen(ccInt(CC_ATLAS.line), 1); g.drawRoundedRect(R.x, R.y, R.x + R.w, R.y + R.h, 2, 6);
   var fH = ccFont("text", 8.2 * k, false, false, Math.round(8.2 * k * CC_ATLAS.labelTracking)), hy = R.y + Math.round(15 * k);
   // (23-oct, revisor R19: E con UN nombre en el diálogo y en el vídeo —el de cc_i18n.js, «La Vía Láctea en el tiempo»—; R18: la firma
   //  común de los tres vídeos, CC_VIDEO_SIGN)
   var eName = ccCaps((typeof ccT === "function") ? ccT("timeline") : ccJT("jTimeline")), fSg = (typeof ccVideoSignFont === "function") ? ccVideoSignFont(CC_JP.REF * k) : fH;     // (k = alto / 600 en 16:9: 15 px a 1080p, como «Órbitas»)
   ccTextAt(g, fH, ccInt(CC_ATLAS.gold), R.x + Math.round(14 * k), hy, eName);
   var sign = (typeof CC_VIDEO_SIGN === "string") ? CC_VIDEO_SIGN : "STELLAR CHEMISTRY";
   ccTextAt(g, fSg, ccInt(CC_ATLAS.text3, 0.85), R.x + R.w - Math.round(14 * k) - fSg.width(sign), hy, sign);
   var L0 = R.x + Math.round(24 * k), R0 = R.x + R.w - Math.round(24 * k), X = function(ga) { return L0 + (14 - ga) / 14 * (R0 - L0); };
   // (los carriles empiezan a 29 px de escala: el triángulo del frente del tiempo, encima, no pisa el título «LA VÍA LÁCTEA EN EL TIEMPO» ni la marca)
   // (23-oct, noche, revisión visual 1: los carriles y los episodios del diálogo —ccPaintTimeline con S.compact—: el Big Bang con su nombre,
   //  Sequoia y las corrientes de Helmi de CC_MERGERS. ROJO «jtl2» de T22: los dos carriles de antes, sin ellos)
   var old2 = (typeof CC_BREAK === "string" && CC_BREAK.indexOf("jtl2") >= 0), merg = !old2 && typeof CC_MERGERS !== "undefined", nL = merg ? 4 : 2;
   var axY = R.y + R.h - Math.round(22 * k), top = R.y + Math.round(29 * k), laneGap = Math.max(8 * k, (axY - 6 * k - top) / nL), laneH = Math.max(6 * k, laneGap - 4 * k);
   var lanes = merg ? { bigbang: 0, sgr: 0, sequoia: 0, halo: 1, gse: 1, thick: 2, thin: 2, helmi: 3 } : { halo: 0, gse: 0, sgr: 0, thick: 1, thin: 1 };
   var col = { halo: CC_ATLAS.chart[1], gse: CC_ATLAS.chart[4], thick: CC_ATLAS.gold, thin: CC_ATLAS.chart[5], sgr: CC_ATLAS.chart[3],
               sequoia: CC_ATLAS.chart[2], helmi: (typeof ccMix === "function") ? ccMix(CC_ATLAS.chart[1], CC_ATLAS.chart[3], 0.5) : CC_ATLAS.chart[1] };
   if (merg) TL = TL.concat((typeof ccMergerEvents === "function") ? ccMergerEvents() : []);      // (la lista, una sola: cc_science.js)
   var fz = ccFont("text", 8.6 * k), fm = ccFont("mono", 8.4 * k), act = (T !== null && T !== undefined) ? ccJourneyEpisodes(T) : null, actKeys = {};
   if (act) for (i = 0; i < act.active.length; ++i) actKeys[act.active[i].key] = true;
   var home = ccHomeFamily(star);      // (24-oct, revisión de Gemini H5: la misma regla que ccPaintTimeline, cc_science.js)
   var labels = [];
   for (i = 0; i < TL.length; ++i) {
      var ev = TL[i], x0 = X(ev.from), x1 = X(ev.to);
      if (ev.from === ev.to) {
         if (ev.key === "sun") { if (typeof ccSunSymbol === "function") ccSunSymbol(g, x0, axY, k * 0.8, true); }
         // (el Big Bang: con cuatro carriles, su nombre va en el suyo —el de Sagitario y Sequoia—, como en el diálogo; con dos chocaba
         //  con «Protogalaxia» —captura del 22-oct—)
         else { g.pen = ccPen(ccInt(CC_ATLAS.text, 0.55), 1); g.drawLine(x0, top - 2 * k, x0, axY); if (merg) labels.push([ccFont("display", 9 * k, false, true), ccInt(CC_ATLAS.text2), x0 + 4 * k, top + laneH / 2 + 3 * k, E ? ev.es : ev.en]); }
         continue;
      }
      if (!(ev.key in lanes)) continue;
      var y = top + lanes[ev.key] * laneGap, lit = !!actKeys[ev.key] || (home && home === ev.key);
      g.fillRoundedRect(x0, y, x1, y + laneH, 20, 50, ccBrush(ccInt(col[ev.key], lit ? 0.55 : 0.2)));
      ccNoBrush(g); g.pen = ccPen(ccInt(lit ? CC_ATLAS.goldLight : col[ev.key], lit ? 1 : 0.5), lit ? Math.max(1.5, 1.4 * k) : 1); g.drawRoundedRect(x0, y, x1, y + laneH, 20, 50);
      var nm = ev.short ? (E ? ev.short[1] : ev.short[0]) : (E ? ev.es : ev.en), bandW = Math.abs(x1 - x0) - 12 * k, ly = y + laneH / 2 + (fz.ascent - fz.descent) / 2;
      if (fz.width(nm) <= bandW && laneH >= fz.ascent) labels.push([fz, ccInt(CC_ATLAS.text, lit ? 1 : 0.8), x0 + 6 * k, ly, nm]);
      // (Sequoia no cabe en su banda —0,9 Ga—: a su derecha, en su carril, con la letra y el color de los demás; como en el diálogo)
      else if (ev.key === "sequoia" && x1 + 6 * k + fz.width(nm) < X(6.0) - 6 * k) labels.push([fz, ccInt(CC_ATLAS.text, lit ? 1 : 0.8), x1 + 5 * k, ly, nm]);
   }
   // el eje y sus cifras
   g.pen = ccPen(ccInt(CC_LINE_STRONG), 1); g.drawLine(L0, axY, R0, axY);
   for (var ga = 0; ga <= 14; ga += 2) {
      var xg = X(ga), lab = (ga === 0) ? ccJT("jTodayWord") : ga + " " + ccAgeUnit(E ? "es" : "en");
      g.drawLine(xg, axY, xg, axY + 4 * k);
      labels.push([fm, ccInt(CC_ATLAS.text3), ccJClamp(xg - fm.width(lab) / 2, R.x + 4 * k, R.x + R.w - 4 * k - fm.width(lab)), axY + 15 * k, lab]);
   }
   // las edades del campo: una raya por estrella NACIDA (2a) o por todas (2c)
   for (i = 0; i < M.stars.length; ++i) {
      var st = M.stars[i];
      if (T !== null && T !== undefined && ccJourneyBirth(st.a, T) < 0.5) continue;
      var c = (typeof CC_POP_COLOR !== "undefined" && st.s.pop) ? (CC_POP_COLOR[st.s.pop.label] || CC_ATLAS.text3) : CC_ATLAS.text3;
      g.pen = ccPen(ccInt(c, st.a.tier === "C" ? 0.3 : 0.7), Math.max(1, k)); var xa = X(st.v); g.drawLine(xa, axY - 2 * k, xa, axY - (st.a.tier === "C" ? 6 : 10) * k);
   }
   // 2a: el frente del tiempo (lo que aún no ha pasado, velado) · 2c: la edad de la visitada, en oro
   if (T !== null && T !== undefined) {
      var xt = X(ccJClamp(T, 0, 14));
      if (R0 - xt > 1) ccFillRect(g, xt, top - 4 * k, R0, axY, ccInt(CC_ATLAS.surface, 0.62));
      g.pen = ccPen(ccInt(CC_ATLAS.text, 0.95), Math.max(1.5, 1.6 * k)); ccJVLine(g, xt, top - 6 * k, axY + 2 * k, labels, k);
      g.brush = ccBrush(ccInt(CC_ATLAS.text)); g.pen = ccPen(ccInt(CC_ATLAS.text), 1);
      g.fillPolygon([new Point(xt - 5 * k, top - 9 * k), new Point(xt + 5 * k, top - 9 * k), new Point(xt, top - 3 * k)]); ccNoBrush(g);
   } else if (star && star.age && star.age.adopted && star.age.adopted.v > 0) {
      var A = star.age.adopted, rg = (typeof ccAgeRange === "function") ? ccAgeRange(A) : [A.v - A.e, A.v + A.e], xa0 = X(rg[1]), xa1 = X(rg[0]), xv = X(Math.min(A.v, U));
      ccFillRect(g, Math.min(xa0, xa1), top - 4 * k, Math.max(xa0, xa1), axY, ccInt(CC_ATLAS.gold, 0.14));
      g.pen = ccPen(ccInt(CC_ATLAS.gold), Math.max(1.5, 1.6 * k)); ccJVLine(g, xv, top - 4 * k, axY, labels, k);
      g.fillCircle(xv, axY, 4 * k, ccBrush(ccInt(CC_ATLAS.gold)));
   }
   for (i = 0; i < labels.length; ++i) ccTextAt(g, labels[i][0], labels[i][1], labels[i][2], labels[i][3], labels[i][4]);
   CC_JTL_HOME = home;
   CC_JTL_LAST = labels.map(function(q) { return { t: q[4], x0: q[2], y0: q[3] - q[0].ascent, x1: q[2] + q[0].width(q[4]), y1: q[3] + q[0].descent }; });
   return act;
}
var CC_JTL_HOME = "";            // (la galaxia natal iluminada en la última línea de tiempo pintada, ccHomeFamily: la prueba J14 la lee)
var CC_JTL_LAST = null;          // (los rótulos de la última línea de tiempo pintada: las pruebas miran que el cursor no los corte)
// La raya del cursor, por detrás de los rótulos (ccVLineBehind de cc_paint.js; sin él, entera)
function ccJVLine(g, x, y0, y1, labels, k) {
   if (typeof ccVLineBehind !== "function") { g.drawLine(x, y0, x, y1); return; }
   ccVLineBehind(g, x, y0, y1, labels.map(function(q) { return [q[2], q[3] - q[0].ascent, q[2] + q[0].width(q[4]), q[3] + q[0].descent]; }), 2 * k);
}

// El nombre de una estrella (COPIA de cc_paint.js ccStarName, 22-oct: la fase 1 rehace cc_paint.js en paralelo).
function ccJourneyStarName(s) {
   if (s.id) return "Gaia DR3 " + s.id;
   if (s.name) return String(s.name);
   var L = ccJLang();
   return ccDec(s.ra, 4, L) + " " + ((s.dec >= 0) ? "+" : "−") + ccDec(Math.abs(s.dec), 4, L);
}

// ---------------------------------------------------------------------------
// EL RELOJ ANALÓGICO (24-oct-2026; el dibujo es CabraShared/csh_clock.js, lo mismo para II y III)
// ---------------------------------------------------------------------------
// LA VARIANTE: CC_CLOCK_VARIANT ("A" | "B" | "C"); vacía = la de fábrica del módulo (CSH_CLOCK.DEFAULT). Una línea para cambiarla.
var CC_CLOCK_VARIANT = "";
// R_K: el radio en unidades de la escala del fotograma (58 × 1,8 = 104 px a 1080p: cifras de 15–16 px; la vista previa, 58 × 1,26 = 73 px).
// TALL: en vertical (9:16) el reloj es 1,25 veces mayor (en un móvil todo el fotograma se ve pequeño; la foto, a lo ancho, tiene sitio).
// MAX_H: la caja del reloj no pasa de esta fracción del alto de la foto (si no cabe, el reloj se achica: nunca tapa la placa de abajo).
// PREVIEW_PX: en la vista previa del diálogo las cifras no bajan de 7 px LÓGICOS (T17 X9: la letra mínima de la vista previa).
// STAR_W: lo que pesa una estrella al elegir esquina: 1 + (14 − G) si es más brillante que G = 14; las paradas del Gran recorrido, ×4.
// BOX: la caja con la que se elige la esquina, en fracciones del ANCHO de la imagen [ancho, alto, margen] (la mayor del reloj: 9:16 y la vista previa).
// 26-oct (Nino: «en los vídeos el reloj es demasiado grande… reduce ambas… un poco de transparencia»): VIDEO_K, el radio EN EL VÍDEO frente al de antes
// (70/104: 104 → 70 px a 1080p; la vista previa del diálogo NO cambia: sus cifras tienen el suelo de 7 px lógicos y no dan para menos); CAP_MIN_PX, el suelo de la
// cifra exacta en el vídeo (a R 70 saldría a 10,5 px); FACE_A, la opacidad del FONDO de la esfera y de la pastilla (líneas, cifras, manecilla y texto, plenas).
// ROJO «jclockbig» (CC_BREAK): el tamaño de antes.
var CC_JDIAL = { R_K: 58, TALL: 1.25, MAX_H: 0.5, PREVIEW_PX: 7.05, STAR_G0: 14, STOP_W: 4, BOX: [0.27, 0.32, 0.015], VIDEO_K: 78 / 104, CAP_MIN_PX: 11, FACE_A: 0.66 };
var CC_JDIAL_CACHE = {};
function ccJourneyDialOn() { return typeof cshClockPaint === "function" && !ccJBroken("jclockold"); }
function ccJourneyDialVariant() { return (typeof CC_CLOCK_VARIANT === "string" && CSH_CLOCK.V[CC_CLOCK_VARIANT]) ? CC_CLOCK_VARIANT : CSH_CLOCK.DEFAULT; }
// la escala de CabraComposition: del Big Bang (CC_SCI.UNIVERSE_GA) a hoy, con «nace el Sol» de CC_TIMELINE (una sola fecha en todo el script)
function ccJourneyDialScale() {
   var S = cshClockScaleCosmic(ccJUniverse()), TL = (typeof CC_TIMELINE !== "undefined") ? CC_TIMELINE : [];
   for (var i = 0; i < TL.length; ++i) if (TL[i].key === "sun") S.epochs = [{ v: -TL[i].from, sym: "sun" }];
   return S;
}
// la geometría del reloj, una vez por radio, variante e idioma (la letra se mide: no se rehace en cada fotograma)
function ccJourneyDialLayout(R, vk, lang, minPx, capMin) {
   var key = R + "|" + vk + "|" + lang + "|" + (minPx || 0) + "|" + (capMin || 0) + "|" + (typeof CSH_CLOCK_BREAK === "string" ? CSH_CLOCK_BREAK : "");
   if (!CC_JDIAL_CACHE[key]) CC_JDIAL_CACHE[key] = cshClockLayout(ccJourneyDialScale(), R, vk, ccFont, lang, { minPx: minPx || 0, capMinPx: capMin || 0 });
   return CC_JDIAL_CACHE[key];
}
// el cuerpo mínimo de las cifras en la vista previa del diálogo (px físicos)
function ccJourneyDialPreviewPx() { return Math.ceil(CC_JDIAL.PREVIEW_PX * ((typeof ccScale === "function") ? ccScale() : 1.5)); }
// el radio y su caja, achicado si la caja pasa de MAX_H del alto de la foto
// (capMin: el suelo de la cifra exacta sola —el vídeo: CC_JDIAL.CAP_MIN_PX—; 0 o sin él, el de siempre)
function ccJourneyDialFit(k, RP, caption, vk, lang, maxH, minPx, capMin) {
   var R = Math.max(30, Math.round(CC_JDIAL.R_K * k)), L = ccJourneyDialLayout(R, vk, lang, minPx, capMin), FP = cshClockFootprint(L, caption, ccFont);
   var lim = (maxH > 0 ? maxH : CC_JDIAL.MAX_H) * RP.h;
   if (FP.h > lim) { R = Math.max(30, Math.floor(R * lim / FP.h)); L = ccJourneyDialLayout(R, vk, lang, minPx, capMin); FP = cshClockFootprint(L, caption, ccFont); }
   return { R: R, L: L, FP: FP };
}
// DÓNDE: arriba a la derecha o arriba a la izquierda de la FOTO (abajo van las placas; en la vista previa, dentro de lo que ocupa la
// imagen, no en sus bandas negras), la que tenga MENOS estrellas debajo —las de edad, las que se encienden en el vídeo, con la cámara
// fija de 2a—, PESADAS por su brillo y las paradas del Gran recorrido más (revisor visual del 24-oct: con la cuenta simple, 2 a 2, el
// reloj tapaba la estrella marcada más vistosa del campo); a igualdad, a la derecha (donde estaba la placa).
// Una vez por campo (ccJourneyDialSide): el reloj no salta de esquina en esquina. ROJO «jclockcorner»: la esquina con MÁS estrellas.
function ccJourneyDialPos(RP, M, X, FP, m) {
   // lo que ocupa la imagen dentro de RP (en la vista previa la foto va con bandas)
   var e0 = X.toScr(0, 0), e1 = X.toScr(M.field.width, M.field.height);
   var A = { x: Math.max(RP.x, Math.min(e0.x, e1.x)), y: Math.max(RP.y, Math.min(e0.y, e1.y)) };
   A.w = Math.min(RP.x + RP.w, Math.max(e0.x, e1.x)) - A.x; A.h = Math.min(RP.y + RP.h, Math.max(e0.y, e1.y)) - A.y;
   var side = ccJourneyDialSide(M);
   var x = (side.corner === "tl") ? A.x + m : A.x + A.w - m - FP.w;
   return { corner: side.corner, x: Math.round(x), y: Math.round(A.y + m), costs: side.costs };
}
// LA ESQUINA, una por campo (25-oct, revisor visual: la vista previa y el vídeo la elegían distinta, y en vertical no se podía ir a la
// izquierda): se mide en la IMAGEN, con una caja fija de CC_JDIAL.BOX × el ancho de la imagen (la mayor que llega a ocupar el reloj:
// 9:16 y vista previa), así que sale la misma en 16:9, 9:16 y la vista previa. Si la placa de abajo a la izquierda choca con el reloj
// arriba a la izquierda, la placa se corre a su derecha (ccJourneyPlate, `avoid`).
function ccJourneyDialSide(M) {
   var red = ccJBroken("jclockcorner");
   if (M._dialSide && M._dialSide.red === red) return M._dialSide.side;
   var W = M.field.width, H = M.field.height, bw = CC_JDIAL.BOX[0] * W, bh = Math.min(H, CC_JDIAL.BOX[1] * W), mg = CC_JDIAL.BOX[2] * W, i, j;
   var stopW = {}; for (i = 0; i < (M.stops || []).length; ++i) stopW[M.stops[i].idx] = CC_JDIAL.STOP_W;
   var cand = [["tr", W - mg - bw], ["tl", mg]], costs = [], best = 0;
   for (i = 0; i < cand.length; ++i) {
      var x0 = cand[i][1], x1 = x0 + bw, y0 = mg, y1 = mg + bh, n = 0;
      for (j = 0; j < M.stars.length; ++j) {
         var st = M.stars[j], gm = ccJNum(st.s.g) ? st.s.g : CC_JDIAL.STAR_G0, wgt = (1 + Math.max(0, CC_JDIAL.STAR_G0 - gm)) * (stopW[st.idx] || 1);
         if (st.s.x >= x0 && st.s.x <= x1 && st.s.y >= y0 && st.s.y <= y1) n += wgt;
      }
      costs.push(Math.round(n * 10) / 10);
   }
   if (red ? costs[1] > costs[0] : costs[1] < costs[0]) best = 1;
   var side = { corner: cand[best][0], costs: { tr: costs[0], tl: costs[1] } };
   M._dialSide = { red: red, side: side };
   return side;
}
// PINTA el reloj de 2a. T en Ga atrás; caption = la cifra exacta («hace 9,3 Ga» / «hoy», ccJourneyClockText). Devuelve lo pintado
// (cshClockPaint: caja, ángulo, cifras con su cuerpo…) + la esquina y lo que costaba cada una.
function ccJourneyDial(g, RP, k, M, X, T, caption, preview, tall) {
   var lang = ccJLang(), vk = ccJourneyDialVariant(), big = ccJBroken("jclockbig"), kk = (tall ? k * CC_JDIAL.TALL : k) * ((preview || big) ? 1 : CC_JDIAL.VIDEO_K);
   var F = ccJourneyDialFit(kk, RP, caption, vk, lang, 0, preview ? ccJourneyDialPreviewPx() : 0, (preview || big) ? 0 : CC_JDIAL.CAP_MIN_PX), m = Math.round(16 * k);
   var pos = ccJourneyDialPos(RP, M, X, F.FP, m);
   var st = cshClockPaint(g, pos.x, pos.y, F.R, F.L.S, -T, { variant: vk, lang: lang, caption: caption, fontFn: ccFont, layout: F.L, faceAlpha: CC_JDIAL.FACE_A,
                                                            textFn: function(gg, f, c, x, y, s) { ccTextAt(gg, f, c, x, y, s); } });
   st.corner = pos.corner; st.costs = pos.costs;
   return st;
}

// ---------------------------------------------------------------------------
// EL FOTOGRAMA
// ---------------------------------------------------------------------------
function ccJourneyFrame(g, w, h, S, sc, mode, t, opts) {
   var t0 = Date.now(), o = opts || {}, k = (sc > 0) ? sc : ccJourneyScale(w, h), E = ccJLang() === "es";
   var stats = { ok: false, mode: mode, t: t, T: null, phase: "", lit: 0, litNoAge: 0, nAge: 0, nNoAge: 0, episodes: [], primary: "", stop: -1, stopIdx: -1, star: null, plate: { lines: [], cut: false }, title: { lines: [], cut: false }, ms: 0 };
   g.antialiasing = true;
   try { g.textAntialiasing = true; } catch (eT) {}
   ccFillRect(g, 0, 0, w, h, ccInt(CC_ATLAS.bg));
   var M = ccJourneyModel(S);
   if (!M || ccJourneyWhyNot(M, mode) !== "") {
      var why = ccJT(M ? ccJourneyWhyNot(M, mode) : "jNeedAnalysis"), fW = ccFont("display", 14 * k, false, true), ln = ccWrap(fW, why, w * 0.8);
      for (var q = 0; q < ln.length; ++q) ccTextAt(g, fW, ccInt(CC_ATLAS.text2), (w - fW.width(ln[q])) / 2, h / 2 + (q - ln.length / 2 + 0.7) * fW.ascent * 1.4, ln[q]);
      stats.ms = Date.now() - t0;
      return stats;
   }
   stats.nAge = M.nAge; stats.nNoAge = M.nNoAge;
   // (23-oct, opción (a) de Nino) o.main: SOLO la parte principal —la foto con su reloj y su placa, a todo el fotograma—, sin los
   //  diagramas ni la línea de tiempo diminutos: es la vista previa del diálogo (los diagramas y E, el diálogo los tiene a la vista y siguen
   //  el reloj). La grabación sigue con su maqueta entera. ROJO «jpreviewfull»: la vista previa con la maqueta entera (cc_journey_ui.js).
   var F = M.field, L = o.main ? { pad: 0, gap: 0, k: k, shape: "main", panels: [], tl: null, photo: { x: 0, y: 0, w: w, h: h } } : ccJourneyLayout(w, h, k, F.width / F.height), RP = L.photo, gk = k * CC_JP.GLYPH_K, title = String((o.title !== undefined && o.title !== null && o.title !== "") ? o.title : (M.viewId || CC_APP_NAME));
   var i, s, qq;
   if (mode === "tour") {
      // ============================ 2c · GRAN RECORRIDO ============================
      if (!M._plan) M._plan = ccJourneyTourPlan(M);
      var plan = M._plan, at = ccJourneyTourAt(plan, t), stop = (at.stop >= 0) ? M.stops[at.stop] : null, dwell = (at.phase === "dwell");
      stats.phase = at.phase; stats.stop = at.stop; stats.stopIdx = stop ? stop.idx : -1; stats.cam = at.cam;
      // (23-oct, revisor R24: a ×4 la foto ampliada salía blanda: el bitmap de la foto no da para tanto. El zoom se limita a lo que da su
      //  resolución —CC_JP.MAX_UPSAMPLE px de pantalla por px del bitmap— escalando el log del zoom: el vuelo sigue siendo suave)
      var camT = at.cam, PB = M.photo, base0 = Math.min(RP.w / F.width, RP.h / F.height);
      stats.kCap = CC_JOURNEY.C_ZOOM;
      if (PB && PB.bitmap && !ccJBroken("jzoomsoft")) {
         var kCap = Math.max(1, CC_JP.MAX_UPSAMPLE * (PB.factor || 1) / base0);
         stats.kCap = Math.min(CC_JOURNEY.C_ZOOM, kCap);
         if (kCap < CC_JOURNEY.C_ZOOM) camT = { cx: camT.cx, cy: camT.cy, k: Math.exp(Math.log(Math.max(1, camT.k)) * Math.log(kCap) / Math.log(CC_JOURNEY.C_ZOOM)) };
      }
      stats.upsample = PB && PB.bitmap ? base0 * camT.k / (PB.factor || 1) : 0;
      var X = ccJourneyPhotoXf(RP, F, camT), S2 = ccJourneyState(M, M.list, dwell && stop ? stop.idx : -1, ((t % 2.4) / 2.4));
      g.clipRect = new Rect(RP.x, RP.y, RP.x + RP.w, RP.y + RP.h);
      ccJourneyPaintPhoto(g, RP, M, X, CC_JP.VEIL_TOUR, k);
      for (i = 0; i < M.list.length; ++i) {
         if (stop && M.list[i] === stop.idx) continue;
         s = M.res.stars[M.list[i]]; qq = X.toScr(s.x, s.y);
         if (!ccJInside(qq, RP, 20 * k)) continue;
         ccStarGlyph(g, qq.x, qq.y, s, S2, gk, false);
      }
      if (stop) {
         s = M.res.stars[stop.idx]; qq = X.toScr(s.x, s.y);
         var ringA = dwell ? 1 : ((at.phase === "fly") ? ccJClamp((t - at.seg.t0) / (at.seg.t1 - at.seg.t0), 0, 1) : 0);
         ccStarGlyph(g, qq.x, qq.y, s, S2, gk, false);
         if (ringA > 0.01) { g.opacity = ringA; S2.anim.sel = 1; ccSelRing(g, qq.x, qq.y, s, S2, gk * 1.15, true); g.opacity = 1; }
         var off = Math.max(Math.abs(qq.x - (RP.x + RP.w / 2)) / RP.w, Math.abs(qq.y - (RP.y + RP.h / 2)) / RP.h);
         stats.star = { x: qq.x, y: qq.y, inside: ccJInside(qq, RP, 0), off: off };
      }
      g.clipRect = new Rect(0, 0, w, h);
      g.pen = ccPen(ccInt(CC_ATLAS.line), 1); ccNoBrush(g); g.drawRect(RP.x, RP.y, RP.x + RP.w, RP.y + RP.h);
      ccJourneyPanels(g, L, S2, null, "tour");
      if (L.tl) ccJourneyTimeline(g, L.tl, k, M, null, dwell && stop ? M.res.stars[stop.idx] : null);
      if (at.titleAlpha > 0.004) {
         var shorts = []; for (i = 0; i < M.stops.length; ++i) shorts.push(ccJT("jRoleShort_" + M.stops[i].roles[0]));
         var sub = (M.stops.length === 1) ? ccJT("jTourSub1", shorts[0]) : ccJT("jTourSub", M.stops.length, shorts.join(" · "));
         stats.title = ccJourneyPlate(g, RP, k, [{ text: ccJT("jEyebrowTour"), font: ["text", 9, true, false, CC_ATLAS.labelTracking], color: ccInt(CC_ATLAS.gold), caps: true, gap: 6 },
                                                 { text: title, font: ["display", 30, false, true], color: ccInt(CC_ATLAS.text), gap: 6 },
                                                 { text: sub, font: ["text", 10.5, false, true], color: ccInt(CC_ATLAS.text2), wrap: 2 }], at.titleAlpha);
      }
      if (stop && at.plateAlpha > 0.004) {
         s = M.res.stars[stop.idx];
         var lang = ccJLang(), roles = [], figs = [];
         for (i = 0; i < stop.roles.length; ++i) { roles.push(ccJT("jRole_" + stop.roles[i])); var fg = ccJourneyRoleFigure(s, stop.roles[i], lang); if (fg && figs.indexOf(fg) < 0) figs.push(fg); }
         if (s.dist && ccJNum(s.dist.pc)) figs.push(ccJT("jLy", ccNice(s.dist.pc * 3.26156, lang, 2)));
         var sent = ccJourneyRoleSentence(s, stop.roles[0], lang);
         stats.plate = ccJourneyPlate(g, RP, k, [{ text: roles.join(" · "), font: ["text", 9, true, false, CC_ATLAS.labelTracking], color: ccInt(CC_ATLAS.gold), caps: true, wrap: 2, gap: 5 },
                                                 { text: ccJourneyStarName(s), font: ["text", 17, true, false], color: ccInt(CC_ATLAS.text), gap: 4 },
                                                 { text: figs.join(" · "), font: ["mono", 10.5, true, false], color: ccInt(CC_ATLAS.goldLight), wrap: 2, gap: 6 },
                                                 { text: sent, font: ["text", 10.5, false, true], color: ccInt(CC_ATLAS.text2), wrap: CC_JP.PLATE_MAX_LINES }], at.plateAlpha,
                                                undefined, null, stats.star ? { x: stats.star.x, y: stats.star.y, r: Math.round(26 * k) } : null);
         stats.plate.figures = figs; stats.plate.roles = roles; stats.plate.sentence = sent;
         ccJourneyPlate(g, RP, k, [{ text: ccJT("jStopN", at.stop + 1, M.stops.length), font: ["text", 8.6, true, false, CC_ATLAS.labelTracking], color: ccInt(CC_ATLAS.text2), caps: true }], at.plateAlpha, "tr");
      }
   } else {
      // ============================ 2a · LA HISTORIA DEL CAMPO ============================
      var dur = ccJourneyHistoryDur(o), C = ccJourneyHistoryClock(t, dur), T = C.T, lit = [], Xh = ccJourneyPhotoXf(RP, F, { cx: F.width / 2, cy: F.height / 2, k: 1 });
      stats.T = T; stats.phase = C.phase;
      for (i = 0; i < M.stars.length; ++i) if (ccJourneyBirth(M.stars[i].a, T) >= 0.5) lit.push(M.stars[i].idx);
      var S3 = ccJourneyState(M, lit, -1, 0);
      g.clipRect = new Rect(RP.x, RP.y, RP.x + RP.w, RP.y + RP.h);
      ccJourneyPaintPhoto(g, RP, M, Xh, ccJBroken("histveil") ? 0.45 : CC_JP.VEIL_HISTORY, k);
      for (i = 0; i < M.stars.length; ++i) {
         var st = M.stars[i], f = ccJourneyBirth(st.a, T);
         if (f >= 0.5) ++stats.lit;
         if (!(f > 0.004)) continue;
         qq = Xh.toScr(st.s.x, st.s.y);
         if (!ccJInside(qq, RP, 20 * k)) continue;
         g.opacity = f; ccStarGlyph(g, qq.x, qq.y, st.s, S3, gk, false); g.opacity = 1;
         var p = ccJourneyFlash(st.a, T);
         if (p >= 0 && C.phase === "run") {
            var rr = ccStarRadius(st.s, S3, gk) + (3 + 20 * p) * k, rgb = ccFehRgb(st.s.chem && st.s.chem.feh ? st.s.chem.feh.v : null);
            g.strokeCircle(qq.x, qq.y, rr, ccPen(ccRgbInt(rgb, 0.85 * Math.pow(1 - p, 1.5)), Math.max(1, 1.4 * k)));
         }
      }
      if (ccJBroken("jnoagelit")) for (i = 0; i < M.noAge.length; ++i) { s = M.noAge[i].s; qq = Xh.toScr(s.x, s.y); ccStarGlyph(g, qq.x, qq.y, s, S3, gk, false); ++stats.litNoAge; S3.list.push(M.noAge[i].idx); }
      g.clipRect = new Rect(0, 0, w, h);
      g.pen = ccPen(ccInt(CC_ATLAS.line), 1); ccNoBrush(g); g.drawRect(RP.x, RP.y, RP.x + RP.w, RP.y + RP.h);
      ccJourneyPanels(g, L, S3, T, "history");
      var ep = L.tl ? ccJourneyTimeline(g, L.tl, k, M, T, null) : ccJourneyEpisodes(T);
      for (i = 0; i < ep.active.length; ++i) stats.episodes.push(ep.active[i].key);
      stats.point = ep.point ? ep.point.key : "";
      stats.primary = ep.primary ? ep.primary.key : "";
      // el reloj cósmico: (24-oct) el RELOJ ANALÓGICO de CabraShared/csh_clock.js arriba en la foto, en la esquina con menos estrellas
      //  debajo, con la cifra exacta pequeña debajo. ROJO «jclockold»: la placa de texto de antes («RELOJ CÓSMICO / hace 9,3 Ga»)
      if (C.phase !== "intro") {
         var big = ccJourneyClockText(C.phase, T);      // (24-oct, H7: el umbral de «hoy» es UNO, el de III también)
         stats.clockText = big;
         if (ccJourneyDialOn()) stats.clock = ccJourneyDial(g, RP, k, M, Xh, T, big, !!o.main, h > w && !o.main);
         else ccJourneyPlate(g, RP, k, [{ text: ccJT("jCosmicClock"), font: ["text", 8.6, true, false, CC_ATLAS.labelTracking], color: ccInt(CC_ATLAS.text3), caps: true, gap: 3 },
                                        { text: big, font: ["display", 24, false, true], color: ccInt(CC_ATLAS.text) }], 1, "tr");
      }
      if (C.titleAlpha > 0.004) {
         stats.title = ccJourneyPlate(g, RP, k, [{ text: ccJT("jEyebrowHistory"), font: ["text", 9, true, false, CC_ATLAS.labelTracking], color: ccInt(CC_ATLAS.gold), caps: true, gap: 6 },
                                                 { text: title, font: ["display", 30, false, true], color: ccInt(CC_ATLAS.text), gap: 6 },
                                                 { text: ccJT("jHistorySub", ccThou(M.nAge, ccJLang())), font: ["text", 10.5, false, true], color: ccInt(CC_ATLAS.text2), wrap: 2 }], C.titleAlpha, undefined, stats.clock ? stats.clock.box : null);
      }
      var pa = 1 - C.titleAlpha;
      if (pa > 0.004) {
         var counts = ccJT("jBornCount", ccThou(stats.lit, ccJLang()), ccThou(M.nAge, ccJLang()), ccThou(M.nAge + M.nNoAge, ccJLang())) + (M.nNoAge > 0 ? " · " + ccJT("jNoAgeNote", ccThou(M.nNoAge, ccJLang())) : "");
         var items;
         // (24-oct, H7) la placa de abajo dice «La Galaxia, ahora» cuando el reloj de arriba dice «hoy»: el mismo predicado. ROJO «todayplate»: solo con la fase final
         var isToday = ccJBroken("todayplate") ? (C.phase === "hold") : ccJourneyIsToday(C.phase, T * 1000);
         stats.plateToday = isToday;
         if (isToday) items = [{ text: ccJT("jGalaxyNow"), font: ["text", 9, true, false, CC_ATLAS.labelTracking], color: ccInt(CC_ATLAS.gold), caps: true, gap: 5 },
                                          { text: ccJT("jTodayName"), font: ["text", 17, true, false], color: ccInt(CC_ATLAS.text), wrap: 2, gap: 6 },
                                          { text: counts, font: ["text", 10.5, false, false], color: ccInt(CC_ATLAS.goldLight), wrap: 2 }];
         else {
            var pr = ep.primary, also = ccJourneyAlso(ep);      // (la misma lista y el mismo texto que la placa de III)
            // (2-nov, Nino: en la VISTA PREVIA la placa tapaba la foto: solo el episodio y la cuenta; la cita y el «también» los dice la
            //  línea de tiempo E del diálogo, a la vista debajo. La grabación, con la maqueta entera, los conserva)
            var lean = !!o.main && !ccJBroken("plateglass");
            items = [{ text: ccJT("jGalaxyThen"), font: ["text", 9, true, false, CC_ATLAS.labelTracking], color: ccInt(CC_ATLAS.gold), caps: true, gap: 5 },
                     { text: pr ? (E ? pr.es : pr.en) : "", font: ["text", 17, true, false], color: ccInt(CC_ATLAS.text), gap: lean ? 6 : 2 }];
            if (!lean) items.push({ text: pr ? ccAgeLocalize(pr.ref, ccJLang()) : "", font: ["text", 8.6, false, true], color: ccInt(CC_ATLAS.text3), gap: 6 },
                                  { text: also.line, font: ["text", 10, false, false], color: ccInt(CC_ATLAS.text2), wrap: 2, gap: 4 });
            items.push({ text: counts, font: ["text", 10.5, false, false], color: ccInt(CC_ATLAS.goldLight), wrap: 2 });
         }
         // (2-nov) la placa, dentro de la FOTO tal como se ve (en la vista previa la foto estrecha deja bandas negras a los lados: la placa
         //  medía el 46 % del lienzo y se salía de la foto)
         var pa0 = Xh.toScr(0, 0), pa1 = Xh.toScr(F.width, F.height), PRh = RP;
         if (!ccJBroken("plateglass")) { var hx0 = Math.max(RP.x, pa0.x), hy0 = Math.max(RP.y, pa0.y); PRh = { x: hx0, y: hy0, w: Math.min(RP.x + RP.w, pa1.x) - hx0, h: Math.min(RP.y + RP.h, pa1.y) - hy0 }; }
         stats.plate = ccJourneyPlate(g, PRh, k, items, pa, undefined, stats.clock ? stats.clock.box : null);
      }
   }
   stats.ok = true;
   stats.layout = L;
   stats.ms = Date.now() - t0;
   return stats;
}
#endif
