#ifndef __CC_GALAXY_JS
#define __CC_GALAXY_JS
// ============================================================================
// src/ui/cc_galaxy.js — III · LA GALAXIA: el MODELO (órbitas, el Sol, la Vía Láctea de
// referencia) y la CÁMARA 3D. Puro: lo ejecutan node y PixInsight (no pinta, no crea ventanas).
// ----------------------------------------------------------------------------
// Fase 2b (22-oct-2026). El dibujo está en cc_galaxy_paint.js, los mandos y el vídeo en
// cc_galaxy_ui.js, las cadenas EN/ES en cc_galaxy_i18n.js. No toca el estado S del diálogo
// (salvo que el diálogo le pase S.sel para la elegida): todo lo suyo vive en G.
//
// LOS DATOS: cada estrella del campo CON CINEMÁTICA trae ya su estado galactocéntrico de hoy
// en `s.fam.nominal` (cc_dynamics.js · ccDynState: x, y, z en kpc, vx, vy, vz en km/s, E) y su
// órbita resumida en `s.fam.orbit` (rperi, rapo, zmax, ecc; 2 Gyr con paso de 0,5 Myr). Aquí se
// INTEGRA LA TRAYECTORIA (cc_dynamics.js no la guarda) con las MISMAS piezas: `ccAcc` y
// `ccPotential` (MilkyWayPotential de gala v1), el mismo salto de rana KDK de `ccOrbit`, el mismo
// paso (0,5 Myr) y la misma convención de ejes:
//   el centro galáctico en (0, 0, 0); el Sol en (−R0, 0, z⊙) con R0 = CC_SCI.R0_KPC = 8,122 kpc y
//   z⊙ = CC_SCI.ZSUN_KPC = 20,8 pc (astropy 4.0, el marco de cc_science.js); +X del Sol hacia el
//   centro, +Y hacia l = 90° (el sentido del giro en la posición del Sol), +Z hacia el polo norte.
//   Vista desde el norte, la Galaxia gira en el sentido de las AGUJAS DEL RELOJ.
//
// LA TRAYECTORIA: se integra CC_GX.T_MYR = 2000 Myr hacia el futuro desde hoy, lo MISMO que `ccOrbit`
// (2 Gyr, paso 0,5 Myr), y se guarda un punto cada 4 pasos (2 Myr; 1001 por estrella). Peri, apo y Zmax
// se miden en CADA paso, no solo en los guardados: así salen EXACTAMENTE los de `ccOrbit` (la sonda lo
// comprueba; es el mismo integrador, no una copia que pueda divergir). Se PINTAN los primeros
// CC_GX.SHOW_MYR = 420 Myr (≈ 2 vueltas del Sol: su periodo azimutal es 2π·R0 / v⊙,φ ≈
// 2π·8,122 / 245,6 · 977,8 ≈ 203 Myr); la elegida, además, sus 2 Gyr enteros en tenue: es lo que
// recorre para llegar a los peri, apo y Zmax de su ficha (en 420 Myr una de halo no llega a su Zmax:
// HD 140283 sube a 2,3 kpc en 420 Myr y a 5,4 en 2 Gyr, medido el 22-oct).
//
// LA VÍA LÁCTEA DE REFERENCIA: NO es un dibujo inventado: es la DISTRIBUCIÓN DE MASA del mismo
// potencial que mueve las órbitas (cc_dynamics.js · CC_POT; desde el 23-oct —G1— gala MilkyWayPotential2022, docs/potencial_g1.md):
//   disco exponencial (M = 4,77e10 M⊙, h_R = 2,6 kpc, h_z = 0,3 kpc) como suma de tres Miyamoto-Nagai: ccDiskDensity
//   bulbo y núcleo Hernquist (M = 5,0e9 M⊙, c = 1,0 kpc; M = 1,81e9 M⊙, c = 0,069 kpc): ccBulgeDensity
//   (hasta el 23-oct, el Miyamoto-Nagai de gala v1 escrito aquí)
//   El brillo del disco pintado es su densidad superficial Σ(R) (integrada en z), en escala
//   logarítmica. El halo oscuro (NFW) no se pinta: no brilla. La BARRA no está en ese potencial y no
//   se pinta. Los BRAZOS espirales SÍ son un dibujo ILUSTRATIVO (cuatro espirales logarítmicas de
//   paso 12°, sin ajustar a ningún catálogo): la leyenda lo dice («brazos: ilustrativos»).
//
// LA CÁMARA 3D: COPIA ADAPTADA de CabraStars/lib/cs_h3cam.js (que a su vez es copia de Cabra3D,
// commit 509a762, src/ui/starfield_view.js: cpSvPose, cpSvDistView, cpSvBoxRadius, cpSvClipSegment,
// cpSvDistFrame, cpSvDistCam, cpSvDistOrbit, cpSvDistPan, cpSvDistZoomAt, cpSvDistViewLerp,
// cpSvDepthOrder, cpSvDepthSize, cpSvDepthDim), con los nombres de csH3… a ccGx… y CS_H3 a CC_GX_CAM.
// Lo único cambiado: la «caja» ya no es la foto con su fondo (u, v, t), sino una caja del mundo
// galactocéntrico en kpc centrada en el centro galáctico (sin `flat` ni la escala t de distancias):
//   u (a la derecha) = −Y · v (hacia abajo) = −Z · fondo = +X
// así, con giro 0 e inclinación 0 se mira desde el lado del Sol hacia el centro, el norte arriba;
// con inclinación NEGATIVA, desde el norte (la de fábrica, −28°). La matemática de la pose, la
// perspectiva, el encaje, girar, desplazar, la rueda hacia el cursor y el orden de pintado es la
// de Cabra3D tal cual.
//
// ES5 puro (#engine v8 lo pone el script que lo incluye).
// ============================================================================

var CC_GX = {
   T_MYR: 2000,         // lo integrado y guardado: lo mismo que ccOrbit (CC_ORBIT_T_MYR)
   SHOW_MYR: 420,       // diseño: lo pintado de cada órbita, ≈ 2 vueltas del Sol (periodo azimutal ≈ 203 Myr, cuenta en la cabecera)
   DT_MYR: 0.5,         // el paso de ccOrbit (cc_dynamics.js · CC_ORBIT_DT_MYR)
   EVERY: 4,            // se guarda un punto cada 4 pasos = 2 Myr
   GLOW_R: 24,          // kpc: hasta dónde llega la tabla de Σ(R)
   RINGS: [5, 10, 15, 20, 30],   // kpc: los círculos de referencia (los que caben en el encuadre)
   ARM_PITCH_DEG: 12,   // ILUSTRATIVO: el paso de los brazos dibujados (no es un ajuste a datos)
   ARM_R0: 3.0, ARM_R1: 16.0, ARM_N: 4,
   TOP_MIN_HALF: 11,    // kpc: el encuadre desde arriba enseña al menos ±11 kpc (el Sol y el centro siempre)
   EDGE_MIN_R: 12, EDGE_MIN_Z: 1.5,
   MAX_ORBITS: 300,     // diseño: órbitas dibujadas a la vez (las 809 de M 67 tardaban 1,4 s en pintarse; casi todas son la misma)
   MAX_ORBITS_LIGHT: 120,
   // (23-oct, revisor R1: en el primer segundo del vídeo las estelas empezaban TODAS en t = 0, sobre la línea de visión —un abanico
   //  de rectas paralelas cortado por un borde diagonal—) EL PASADO: se integra también hacia atrás PAST_MYR (las mismas piezas: el
   //  salto de rana es reversible, basta invertir la velocidad), así la estela del vídeo (40 Myr) ya existe en el primer fotograma.
   PAST_MYR: 60
};
// QUÉ ÓRBITAS SE DIBUJAN cuando hay más de `max`: TODAS las que no son del montón (otra población que la más común, o
// e > 0,2: las de halo, acretadas, excéntricas) y, de las del montón, una de cada k hasta llenar el cupo. Devuelve los
// índices de G.stars (con órbita). Se guarda en G (no cambia con la vista).
function ccGxOrbitSubset(G, max) {
   var key = "sub" + max;
   if (G[key]) return G[key];
   var withTr = [], cnt = {}, top = "", tc = -1, i;
   for (i = 0; i < G.stars.length; ++i) if (G.stars[i].tr) { withTr.push(i); cnt[G.stars[i].pop] = (cnt[G.stars[i].pop] || 0) + 1; }
   for (var k in cnt) if (cnt.hasOwnProperty(k) && cnt[k] > tc) { tc = cnt[k]; top = k; }
   if (withTr.length <= max) { G[key] = withTr; return withTr; }
   var odd = [], bulk = [];
   for (i = 0; i < withTr.length; ++i) { var e = G.stars[withTr[i]]; if (e.pop !== top || e.meas.ecc > 0.2) odd.push(withTr[i]); else bulk.push(withTr[i]); }
   var room = Math.max(0, max - odd.length), out = odd.slice();
   if (room > 0) { var step = bulk.length / room; for (var j = 0; j < room && Math.floor(j * step) < bulk.length; ++j) out.push(bulk[Math.floor(j * step)]); }
   out.sort(function(a, b) { return a - b; });
   G[key] = out;
   return out;
}
var CC_GX_BREAK = "";   // defectos inyectados por la sonda (tests/cc_galaxy_probe.js): un nombre, «sun», «kick», «axes»…
function ccGxBroken(k) { return (typeof CC_GX_BREAK === "string") && CC_GX_BREAK.indexOf(k) >= 0; }

// ---------------------------------------------------------------------------
// LA TRAYECTORIA (el integrador de ccOrbit, guardando los puntos)
// ---------------------------------------------------------------------------
// st = { x, y, z, vx, vy, vz, E } (lo de ccDynState). Devuelve
//   { n, dtMyr (entre puntos guardados), x, y, z (Float32Array), rperi, rapo, zmax, ecc, dE, bound, tMyr }
// `keep === false`: no guarda puntos (solo las medidas: para el control de 2 Gyr).
// `track` (23-oct, la Galaxia en el tiempo): cada cuántos pasos se mira la energía; devuelve también dEmax = max |ΔE/E| a lo largo
// del camino (no solo al final: el error del salto de rana oscila, no deriva). 0 / sin dar = no se mira.
// (2-nov-2026) LA BARRA (cc_dynamics.js ccBarOn): su ángulo en t = tsg·dtM·(i + 1) Ma; `tsign` = −1 para el PASADO, que aquí se integra
// hacia delante con la velocidad invertida (la barra tiene que girar hacia atrás); +1 o sin dar, el futuro. La energía que se vigila es
// la de Jacobi (w = Ω_b·tsg). Misma aritmética que cshGdLeap (CabraShared/csh_galdyn.js) con su `tsign`, también el ángulo por
// RECURRENCIA (2-nov, noche: Q2b; un giro fijo por paso en vez de cos y sin en cada uno). (Q2b: SOLO lo dibujado lleva la barra; la ficha
// de la elegida es ccOrbit, sin ella: el pie del mapa lo dice, gxFootOrbitBar.)
// (2-nov-2026, E3) EL PASO PARTIDO, la MISMA regla que ccOrbit (cc_dynamics.js, R2 del 27-oct): se mira |ΔE/E| en cada
// CC_ORBIT_DE_EVERY pasos y, si pasa de CC_ORBIT_DE_TOL (también al final), se vuelve a empezar con la mitad de paso, hasta
// CC_ORBIT_MAX_HALVE veces; en la última no se aborta (`approx` si ni así). Los puntos guardados siguen cada `every` × dtM (cada
// 2 Myr): con el paso partido por k se guarda uno de cada every·k. Sin la barra, la trayectoria es la de ccOrbit (peri, apo, Zmax y e a
// 1e-9: tests/cc_galaxy_probe.js F4); con la barra, la energía vigilada es la de Jacobi. Peri, apo y Zmax empiezan con el estado
// INICIAL, como ccOrbit (R7). `fixed === true`: UNA pasada con el paso dado (quien afina el paso él mismo —ccGxtBack— y las pruebas
// de «el mismo paso»). Devuelve además { halvings, approx, dtStep (el paso de integración usado) }.
// Rojo CC_GX_BREAK «fixdt»: el integrador de antes, con el paso fijo (F4 cae como el 29-oct: 4,5e-3 · 4,3e-3 · 5,1e-2).
function ccGxIntegrate(st, tMyr, dtMyr, every, keep, track, tsign, fixed) {
   var dtM = dtMyr || CC_GX.DT_MYR, T = tMyr || CC_GX.T_MYR, ev = every || CC_GX.EVERY;
   if (!(st.E < 0)) return { n: 0, dtMyr: dtM * ev, x: null, y: null, z: null, rperi: null, rapo: null, zmax: null, ecc: 1, dE: 0, dEmax: 0, bound: false, tMyr: T, halvings: 0, approx: false, dtStep: dtM };
   if (fixed === true || ccGxBroken("fixdt")) { var o1 = ccGxLeap(st, T, dtM, ev, keep, track, tsign, 0); o1.halvings = 0; o1.approx = false; o1.dtStep = dtM; return o1; }
   var o = null, h = 0, k = 1;
   for (h = 0; h <= CC_ORBIT_MAX_HALVE; ++h) {
      k = Math.pow(2, h);
      o = ccGxLeap(st, T, dtM / k, ev * k, keep, CC_ORBIT_DE_EVERY, tsign, (h < CC_ORBIT_MAX_HALVE) ? CC_ORBIT_DE_TOL : 0);
      if (o) break;
   }
   o.halvings = Math.min(h, CC_ORBIT_MAX_HALVE); o.approx = !(o.dEmax <= CC_ORBIT_DE_TOL); o.dtStep = dtM / k;
   return o;
}
// Una pasada de salto de rana con el paso dtM (Myr), guardando un punto cada `ev` pasos. `track`: cada cuántos pasos se mira la
// energía (0 = no se mira). `abortTol` > 0: null en cuanto |ΔE/E| pase de ella (en un paso mirado o al final).
function ccGxLeap(st, T, dtM, ev, keep, track, tsign, abortTol) {
   var n = Math.round(T / dtM), dt = dtM / CC_KPC_KMS_MYR, tk = (track > 0) ? Math.round(track) : 0, dEmax = 0, tol = (abortTol > 0) ? abortTol : 0;
   var bar = (typeof ccBarOn === "function") && ccBarOn(), tsg = (tsign === -1) ? -1 : 1, cs = [1, 0], w = bar ? CC_BAR.OB * tsg : 0, cd = 1, sd = 0;
   if (bar) { ccBarAngle(0, cs); var dth = ccBarK().w * tsg * dtM; cd = Math.cos(dth); sd = Math.sin(dth); }
   var E0 = bar ? ccJacobi(st.x, st.y, st.z, st.vx, st.vy, st.vz, cs[0], cs[1], w) : st.E;
   var m = (keep === false) ? 0 : Math.floor(n / ev) + 1;
   var X = m ? new Float32Array(m) : null, Y = m ? new Float32Array(m) : null, Z = m ? new Float32Array(m) : null;
   var x = st.x, y = st.y, z = st.z, vx = st.vx, vy = st.vy, vz = st.vz, a = [0, 0, 0], k = 0;
   var r0 = Math.sqrt(x * x + y * y + z * z), rmin = r0, rmax = r0, zmax = Math.abs(z), euler = ccGxBroken("kick");
   if (m) { X[0] = x; Y[0] = y; Z[0] = z; k = 1; }
   ccAcc(x, y, z, a);
   if (bar) ccBarAdd(x, y, z, cs[0], cs[1], a);
   for (var i = 0; i < n; ++i) {
      if (bar) { var c1 = cs[0] * cd - cs[1] * sd; cs[1] = cs[1] * cd + cs[0] * sd; cs[0] = c1; }
      if (euler) {
         // (ROJO «kick»: Euler explícito, de primer orden y no simpléctico: la energía se va)
         x += dt * vx; y += dt * vy; z += dt * vz;
         vx += dt * a[0]; vy += dt * a[1]; vz += dt * a[2];
         ccAcc(x, y, z, a);
         if (bar) ccBarAdd(x, y, z, cs[0], cs[1], a);
      } else {
         vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
         x += dt * vx; y += dt * vy; z += dt * vz;
         ccAcc(x, y, z, a);
         if (bar) ccBarAdd(x, y, z, cs[0], cs[1], a);
         vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
      }
      var r = Math.sqrt(x * x + y * y + z * z);
      if (r < rmin) rmin = r;
      if (r > rmax) rmax = r;
      if (Math.abs(z) > zmax) zmax = Math.abs(z);
      if (m && (i + 1) % ev === 0 && k < m) { X[k] = x; Y[k] = y; Z[k] = z; ++k; }
      if (tk && (i + 1) % tk === 0) {
         var Ei = bar ? ccJacobi(x, y, z, vx, vy, vz, cs[0], cs[1], w) : 0.5 * (vx * vx + vy * vy + vz * vz) + ccPotential(x, y, z), dEi = Math.abs((Ei - E0) / E0);
         if (dEi > dEmax) { dEmax = dEi; if (tol && dEmax > tol) return null; }
      }
   }
   var Ef = bar ? ccJacobi(x, y, z, vx, vy, vz, cs[0], cs[1], w) : 0.5 * (vx * vx + vy * vy + vz * vz) + ccPotential(x, y, z);
   if (tk) dEmax = Math.max(dEmax, Math.abs((Ef - E0) / E0));
   if (tol && dEmax > tol) return null;
   return { n: k, dtMyr: dtM * ev, x: X, y: Y, z: Z, rperi: rmin, rapo: rmax, zmax: zmax, ecc: (rmax + rmin > 0) ? (rmax - rmin) / (rmax + rmin) : 0,
            dE: (Ef - E0) / Math.abs(E0), dEmax: dEmax, bound: true, tMyr: T, end: { x: x, y: y, z: z, vx: vx, vy: vy, vz: vz } };
}
// La posición a tMyr de hoy a lo largo de la trayectoria guardada (lineal entre puntos; más allá del
// final, la órbita vuelve a empezar: NO es periódica, es solo para que el vídeo no se quede quieto).
function ccGxAt(tr, tMyr, out) {
   out = out || [0, 0, 0];
   if (!tr || !tr.n) return null;
   var f = Math.max(0, tMyr) / tr.dtMyr, last = tr.n - 1;
   if (f >= last) f = f % last;
   var i = Math.floor(f), u = f - i, j = Math.min(last, i + 1);
   out[0] = tr.x[i] + (tr.x[j] - tr.x[i]) * u; out[1] = tr.y[i] + (tr.y[j] - tr.y[i]) * u; out[2] = tr.z[i] + (tr.z[j] - tr.z[i]) * u;
   return out;
}
// El punto k de la rejilla de 2 Myr, con k NEGATIVO = el pasado (e.past, integrado hacia atrás); fuera de lo guardado, el extremo.
function ccGxGridPt(tr, past, k, out) {
   if (k < 0 && past && past.n > 1) { var j = Math.min(past.n - 1, -k); out[0] = past.x[j]; out[1] = past.y[j]; out[2] = past.z[j]; return out; }
   var i = Math.max(0, Math.min(tr.n - 1, k));
   out[0] = tr.x[i]; out[1] = tr.y[i]; out[2] = tr.z[i];
   return out;
}
// La posición a tMyr (también negativo) por CATMULL-ROM entre los puntos de 2 Myr (DIBUJO: la estela y el punto del vídeo son una
// curva suave, no una poligonal de tramos de 2 Myr; a 400 km/s junto al pericentro un tramo recto se veía como un segmento de cientos
// de px —revisor R1—. Es interpolación, no otra integración: pasa por los puntos guardados).
var CC_GX_Q = [[0, 0, 0], [0, 0, 0], [0, 0, 0], [0, 0, 0]];
function ccGxAtSmooth(tr, past, tMyr, out) {
   out = out || [0, 0, 0];
   if (!tr || !tr.n) return null;
   var f = tMyr / tr.dtMyr, i = Math.floor(f), u = f - i, Q = CC_GX_Q, u2 = u * u, u3 = u2 * u;
   ccGxGridPt(tr, past, i - 1, Q[0]); ccGxGridPt(tr, past, i, Q[1]); ccGxGridPt(tr, past, i + 1, Q[2]); ccGxGridPt(tr, past, i + 2, Q[3]);
   for (var c = 0; c < 3; ++c) {
      var p0 = Q[0][c], p1 = Q[1][c], p2 = Q[2][c], p3 = Q[3][c];
      out[c] = 0.5 * (2 * p1 + (p2 - p0) * u + (2 * p0 - 5 * p1 + 4 * p2 - p3) * u2 + (3 * p1 - p0 - 3 * p2 + p3) * u3);
   }
   return out;
}

// ---------------------------------------------------------------------------
// EL SOL (su estado, del marco de cc_science.js) y la VÍA LÁCTEA de referencia (del potencial)
// ---------------------------------------------------------------------------
function ccGxSunState() {
   var R0 = CC_SCI.R0_KPC, z0 = CC_SCI.ZSUN_KPC, V = CC_SCI.VSUN_GC;
   var x = ccGxBroken("sun") ? R0 : -R0;          // (ROJO «sun»: el Sol al otro lado del centro)
   var st = { x: x, y: 0, z: z0, vx: V[0], vy: V[1], vz: V[2] };
   st.E = 0.5 * (V[0] * V[0] + V[1] * V[1] + V[2] * V[2]) + ccPotential(st.x, st.y, st.z);
   return st;
}
// Densidades del potencial (M⊙/kpc³).
// (23-oct, G1: el resplandor sale de la densidad del MISMO potencial que integra las órbitas —ccDiskDensity / ccBulgeDensity de
//  cc_dynamics.js: el disco exponencial de MilkyWayPotential2022 como suma de tres Miyamoto-Nagai—; antes, el Miyamoto-Nagai de gala v1
//  escrito aquí con CC_POT.disk.a/b, que ya no son el disco del potencial)
function ccGxRhoDisc(R, z) {
   if (ccGxBroken("v1glow")) { var a = 3.0, b = 0.28, M = 6.8e10, B = Math.sqrt(z * z + b * b), aB = a + B; return b * b * M / (4 * Math.PI) * (a * R * R + (a + 3 * B) * aB * aB) / (Math.pow(R * R + aB * aB, 2.5) * B * B * B); }   // (rojo de T20 Q7: el disco de gala v1)
   return ccDiskDensity(R, z);
}
function ccGxRhoBulge(r) { return ccBulgeDensity(r); }
// Σ (M⊙/kpc²) del disco a radio R (integral en z, z = 6u², por Simpson) y del bulbo proyectado a distancia d del centro.
function ccGxSigmaDisc(R) {
   var n = 120, s = 0, Zm = 6;
   for (var i = 0; i <= n; ++i) {
      var u = i / n, z = Zm * u * u, dz = 2 * Zm * u, wgt = (i === 0 || i === n) ? 1 : ((i % 2) ? 4 : 2);
      s += wgt * ccGxRhoDisc(R, z) * dz;
   }
   return 2 * s / (3 * n);
}
function ccGxSigmaBulge(d) {
   var n = 160, s = 0, Lm = 40;
   d = Math.max(d, 0.02);
   for (var i = 0; i <= n; ++i) {
      var u = i / n, l = Lm * u * u, dl = 2 * Lm * u, wgt = (i === 0 || i === n) ? 1 : ((i % 2) ? 4 : 2);
      s += wgt * ccGxRhoBulge(Math.sqrt(d * d + l * l)) * dl;
   }
   return 2 * s / (3 * n);
}
// Las tablas (una vez): Σ_disco(R), Σ_bulbo(d) cada 0,05 kpc hasta GLOW_R.
var CC_GX_SIGMA = null;
function ccGxSigmaTable() {
   if (CC_GX_SIGMA) return CC_GX_SIGMA;
   var step = 0.05, n = Math.ceil(CC_GX.GLOW_R / step) + 1, D = new Float64Array(n), B = new Float64Array(n);
   for (var i = 0; i < n; ++i) { D[i] = ccGxSigmaDisc(i * step); B[i] = ccGxSigmaBulge(i * step); }
   CC_GX_SIGMA = { step: step, n: n, disc: D, bulge: B, ref: D[Math.round(CC_SCI.R0_KPC / step)] };
   return CC_GX_SIGMA;
}
function ccGxLookup(arr, T, r) {
   var f = r / T.step;
   if (f >= T.n - 1) return arr[T.n - 1] * Math.exp(-(f - T.n + 1) * T.step / 2);
   var i = Math.floor(f), u = f - i;
   return arr[i] + (arr[i + 1] - arr[i]) * u;
}
// EL BRILLO PINTADO (0…1) a partir de una densidad superficial (M⊙/kpc²): logarítmico, de
// Σ = 0,3 M⊙/pc² (apagado) a 3000 M⊙/pc² (lleno). Diseño: con esos topes el disco se apaga hacia
// los 18–20 kpc y el bulbo satura en el kpc central. A R0, Σ_disco ≈ 50 M⊙/pc² (ver la sonda).
function ccGxGlowOf(sigma) {
   var lo = Math.log(0.3e6), hi = Math.log(3000e6);
   if (!(sigma > 0)) return 0;
   return Math.max(0, Math.min(1, (Math.log(sigma) - lo) / (hi - lo)));
}
// Los BRAZOS ILUSTRATIVOS: espirales logarítmicas R = R_a · exp(tan(paso)·(θ − θ_k)), en el plano.
// Devuelve una lista de polilíneas [[x, y], …] en kpc. (Sentido: se enrollan hacia fuera en contra del
// giro, como los brazos «arrastrados» de una galaxia que gira a favor de las agujas del reloj vista
// desde el norte.) NO es un mapa: ver la cabecera.
var CC_GX_ARMS = null;
function ccGxArms() {
   if (CC_GX_ARMS) return CC_GX_ARMS;
   var out = [], k = Math.tan(CC_GX.ARM_PITCH_DEG * Math.PI / 180), N = CC_GX.ARM_N;
   for (var a = 0; a < N; ++a) {
      var th0 = a * 2 * Math.PI / N + 0.6, pts = [];
      var thMax = Math.log(CC_GX.ARM_R1 / CC_GX.ARM_R0) / k;
      for (var t = 0; t <= thMax + 1e-9; t += 0.04) {
         var R = CC_GX.ARM_R0 * Math.exp(k * t), th = th0 + t;    // θ crece hacia fuera; el giro es en θ decreciente (horario)
         pts.push([R * Math.cos(th), R * Math.sin(th)]);
      }
      out.push(pts);
   }
   CC_GX_ARMS = out;
   return out;
}

// ---------------------------------------------------------------------------
// EL MODELO DEL GRUPO III (G): una vez por resultado; los mandos viven en G.ui
// ---------------------------------------------------------------------------
function ccGxName(s) {
   if (!s) return "";
   if (s.id) return "Gaia DR3 " + s.id;
   if (s.name) return s.name;
   return "";
}
var CC_GX_STAMP = 0;      // (cada modelo nuevo, un sello: la clave de la base pintada lo lleva)
// res = S.res; `list` = los índices visibles (S.list, las que tienen química o edad: las MISMAS que B, C y D; el panel D
// cuenta igual «con órbita»); sin ella, las del encuadre.
function ccGalaxyModel(res, list, opts) {
   var o = opts || {}, t0 = Date.now(), T = o.tMyr || CC_GX.T_MYR;
   CC_GX_STAMP = (CC_GX_STAMP || 0) + 1;
   var G = { stamp: CC_GX_STAMP, res: res, stars: [], byIdx: {}, nAll: 0, nNoKin: 0, nUnbound: 0, tMyr: T, dtMyr: CC_GX.DT_MYR, ms: 0, ui: null, proj: null };
   var idx = [];
   if (list && list.length !== undefined) idx = list.slice();
   else if (res && res.stars) for (var i0 = 0; i0 < res.stars.length; ++i0) if (res.stars[i0].inFrame !== false) idx.push(i0);
   G.nAll = idx.length;
   // (el encuadre de fábrica sigue al 90 % de las órbitas, no a la más extrema: con la de más alcance, una sola estrella de
   //  halo mal medida —apo 22 kpc en Abell 39— dejaba el disco en un tercio del mapa; captura del 22-oct. Lo que se sale,
   //  con la rueda hacia fuera.)
   var maxAbsXY = 0, maxR = 0, maxZ = 0, extXY = [], extR = [], extZ = [];
   function grow(x, y, z) {
      var R = Math.sqrt(x * x + y * y);
      if (Math.abs(x) > maxAbsXY) maxAbsXY = Math.abs(x);
      if (Math.abs(y) > maxAbsXY) maxAbsXY = Math.abs(y);
      if (R > maxR) maxR = R;
      if (Math.abs(z) > maxZ) maxZ = Math.abs(z);
   }
   function flush() { extXY.push(maxAbsXY); extR.push(maxR); extZ.push(maxZ); maxAbsXY = 0; maxR = 0; maxZ = 0; }
   function p90(a) { if (!a.length) return 0; var b = a.slice().sort(function(p, q) { return p - q; }); return b[Math.min(b.length - 1, Math.floor(0.9 * (b.length - 1) + 0.5))]; }
   for (var k = 0; k < idx.length; ++k) {
      var s = res.stars[idx[k]];
      if (!s || !s.fam || !s.fam.nominal) { ++G.nNoKin; continue; }
      var d = s.fam.nominal;
      var st = ccGxBroken("axes") ? { x: d.y, y: d.x, z: d.z, vx: d.vy, vy: d.vx, vz: d.vz, E: d.E } : d;    // (ROJO «axes»: X e Y cambiados)
      var tr = ccGxIntegrate(st, T, CC_GX.DT_MYR, CC_GX.EVERY, true);
      if (!tr.bound) ++G.nUnbound;
      // (2-nov: el pasado, con la velocidad invertida y la barra girando hacia atrás: tsign −1)
      var past = tr.bound ? ccGxIntegrate({ x: st.x, y: st.y, z: st.z, vx: -st.vx, vy: -st.vy, vz: -st.vz, E: st.E }, CC_GX.PAST_MYR, CC_GX.DT_MYR, CC_GX.EVERY, true, 0, -1) : null;
      var feh = (s.chem && s.chem.feh && ccIsNum(s.chem.feh.v)) ? s.chem.feh.v : null;
      var ag = (s.age && s.age.adopted && ccIsNum(s.age.adopted.v)) ? s.age.adopted : null;
      // (st0: el estado de hoy tal cual —para integrar el pasado entero, cc_galaxy_time.js—; ageA: la edad ADOPTADA entera, con su intervalo:
      //  la Galaxia en el tiempo la enciende con ccJourneyBirth, la misma regla que «La historia del campo»)
      var e = { i: idx[k], x: st.x, y: st.y, z: st.z, st0: st, tr: tr.bound ? tr : null, past: (past && past.bound) ? past : null, orbit: s.fam.orbit || null, meas: tr,
                pop: (s.pop && s.pop.label) ? s.pop.label : "unknown", feh: feh, age: ag ? ag.v : null, ageA: (ag && ag.v > 0) ? ag : null,
                ageOk: !!(ag && !(typeof ccAgeVague === "function" && ccAgeVague(ag))), fam: s.fam.best || "", name: ccGxName(s), g: s.g };
      G.byIdx[idx[k]] = G.stars.length;
      G.stars.push(e);
      grow(st.x, st.y, st.z);
      if (tr.bound) for (var j = 0; j < tr.n; j += 2) grow(tr.x[j], tr.y[j], tr.z[j]);
      flush();
   }
   var sun = ccGxSunState(), str = ccGxIntegrate(sun, T, CC_GX.DT_MYR, CC_GX.EVERY, true);
   G.sun = { x: sun.x, y: sun.y, z: sun.z, st: sun, tr: str };
   grow(sun.x, sun.y, sun.z);
   for (j = 0; j < str.n; ++j) grow(str.x[j], str.y[j], str.z[j]);
   var sunXY = maxAbsXY, sunR = maxR;
   // los encuadres de fábrica: el 90 % de las órbitas, el centro y la órbita del Sol, con topes
   var half = Math.min(45, Math.max(CC_GX.TOP_MIN_HALF, sunXY * 1.08, p90(extXY) * 1.08));
   var zE = Math.min(30, Math.max(CC_GX.EDGE_MIN_Z, p90(extZ) * 1.15));
   G.ext = { top: { cx: 0, cy: 0, half: half },
             edge: { r1: Math.min(45, Math.max(CC_GX.EDGE_MIN_R, sunR * 1.08, p90(extR) * 1.08)), z1: zE },
             box: { hx: half, hy: half, hz: Math.max(Math.min(30, p90(extZ) * 1.1), 0.12 * half) },
             maxXY: Math.max.apply(null, extXY.concat([sunXY])), maxZ: Math.max.apply(null, extZ.concat([0])) };
   ccGxSigmaTable();
   G.ms = Date.now() - t0;
   return G;
}
// Los mandos de fábrica del grupo (lo que el usuario cambia; se recuerdan en Settings desde cc_galaxy_ui.js).
function ccGalaxyDefaultUi() {
   return { mode: "top", show: "orbit", color: "pop", sel: -1, cam: null, v2: { top: null, edge: null }, tMyr: 0, trail: 0, light: false, arms: true };
}

// ---------------------------------------------------------------------------
// LA CÁMARA 3D (copia adaptada de cs_h3cam.js / Cabra3D: ver la cabecera)
// ---------------------------------------------------------------------------
var CC_GX_CAM = {
   YAW: 38, PITCH: -26,               // la pose de fábrica: desde el norte (inclinación negativa) y un poco de lado
   PITCH_MAX: 88, PERSPECTIVE: true, CAM_DIST: 2.6, NEAR: 0.08,
   ZOOM_MIN: 0.5, ZOOM_MAX: 100, ORBIT_X: 0.4, ORBIT_Y: 0.3
};
function ccGxWrapDeg(a) { var r = a % 360; return (r < 0) ? r + 360 : r; }
function ccGxPose(yaw, pitch) {
   var y = ccGxWrapDeg((typeof yaw === "number" && isFinite(yaw)) ? yaw : CC_GX_CAM.YAW);
   var p = Math.max(-CC_GX_CAM.PITCH_MAX, Math.min(CC_GX_CAM.PITCH_MAX, (typeof pitch === "number" && isFinite(pitch)) ? pitch : CC_GX_CAM.PITCH));
   var k = Math.PI / 180;
   return { yaw: y, pitch: p, cy: Math.cos(y * k), sy: Math.sin(y * k), cp: Math.cos(p * k), sp: Math.sin(p * k) };
}
// La vista: yaw, pitch, zoom (travelín), ox, oy, oz (el pivote en coordenadas de la caja, kpc, desde el centro galáctico),
// f0, cx, cy (0 / NaN = los del encaje de esa pose).
function ccGxCamView(v) {
   var q = v || {}, P = ccGxPose(q.yaw, q.pitch);
   function num(x, d) { return (typeof x === "number" && isFinite(x)) ? x : d; }
   function lim(x, m) { return Math.max(-m, Math.min(m, num(x, 0))); }
   return { yaw: P.yaw, pitch: P.pitch, zoom: Math.max(CC_GX_CAM.ZOOM_MIN, Math.min(CC_GX_CAM.ZOOM_MAX, num(q.zoom, 1))),
            ox: lim(q.ox, 60), oy: lim(q.oy, 60), oz: lim(q.oz, 60), f0: (num(q.f0, 0) > 0) ? q.f0 : 0, cx: num(q.cx, NaN), cy: num(q.cy, NaN) };
}
function ccGxBoxRadius(box) { return Math.sqrt(box.hx * box.hx + box.hy * box.hy + box.hz * box.hz); }
function ccGxClipSegment(x1, y1, x2, y2, b) {
   var t0 = 0, t1 = 1, dx = x2 - x1, dy = y2 - y1;
   var p = [-dx, dx, -dy, dy], q = [x1 - b.x, b.x + b.w - x1, y1 - b.y, b.y + b.h - y1];
   for (var i = 0; i < 4; ++i) {
      if (p[i] === 0) { if (q[i] < 0) return null; }
      else {
         var r = q[i] / p[i];
         if (p[i] < 0) { if (r > t1) return null; if (r > t0) t0 = r; }
         else { if (r < t0) return null; if (r < t1) t1 = r; }
      }
   }
   return { x1: x1 + t0 * dx, y1: y1 + t0 * dy, x2: x1 + t1 * dx, y2: y1 + t1 * dy };
}
// mundo galactocéntrico (kpc) -> caja (u derecha, v abajo, d fondo)
function ccGxToBox(X, Y, Z) { return [-Y, -Z, X]; }
// EL ENCAJE: la caja entera cabe en `rect`, centrada (sigue a la pose, sin saltos).
// (23-oct, noche, revisión visual 10: con las 8 esquinas de la caja, girada 38°, sus picos sobresalían y la Galaxia —un disco— quedaba en
//  una franja con mucho vacío arriba y abajo. Ahora se encaja lo que se pinta: el CILINDRO del disco —radio hx, alto ±hz—, 2 × 48 puntos.
//  ROJO «camstrip» de T22: las esquinas de la caja, como antes)
function ccGxCamExtent(box, yaw, pitch) {
   var unit = ccGxCam(box, { x: 0, y: 0, w: 1, h: 1 }, { yaw: yaw, pitch: pitch, zoom: 1, f0: 1, cx: 0, cy: 0 });
   var x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity, q, a;
   function add(qq) { if (qq.x < x0) x0 = qq.x; if (qq.x > x1) x1 = qq.x; if (qq.y < y0) y0 = qq.y; if (qq.y > y1) y1 = qq.y; }
   if (ccGxBroken("camstrip")) {
      for (a = 0; a < 8; ++a) add(unit.pxBox((a & 1) ? box.hy : -box.hy, (a & 2) ? box.hz : -box.hz, (a & 4) ? box.hx : -box.hx));
   } else {
      var r = Math.max(box.hx, box.hy), n = 48;
      for (a = 0; a < n; ++a) { var t = 2 * Math.PI * a / n, u = r * Math.cos(t), d = r * Math.sin(t); add(unit.pxBox(u, box.hz, d)); add(unit.pxBox(u, -box.hz, d)); }
   }
   return { x0: x0, x1: x1, y0: y0, y1: y1 };
}
function ccGxCamFrame(box, rect, yaw, pitch) {
   var E = ccGxCamExtent(box, yaw, pitch), x0 = E.x0, x1 = E.x1, y0 = E.y0, y1 = E.y1;
   var f0 = Math.min(rect.w / (x1 - x0), rect.h / (y1 - y0));
   return { f0: f0, cx: rect.x + rect.w / 2 - f0 * (x0 + x1) / 2, cy: rect.y + rect.h / 2 - f0 * (y0 + y1) / 2 };
}
// (23-oct, noche) LA POSE DE FÁBRICA que llena el lienzo (como c3AutoPose de Cabra3D): el giro de fábrica y la inclinación MENOS empinada
// —la más parecida a la de fábrica, la que más «3D» se lee— con la que el disco proyectado cubre al menos CC_GX_AUTO.GOOD del lienzo
// (o lo mejor posible menos TOL). En un lienzo apaisado, la de fábrica ya llega y no se mueve nada. Caché por caja y tamaño.
var CC_GX_AUTO = { GOOD: 0.72, TOL: 0.03, PITCH_MIN: 26, PITCH_MAX: 80, STEP: 1 }, CC_GX_AUTO_CACHE = { key: "", pose: null };
function ccGxCover(box, rect, yaw, pitch) {
   var E = ccGxCamExtent(box, yaw, pitch), bw = E.x1 - E.x0, bh = E.y1 - E.y0, f0 = Math.min(rect.w / bw, rect.h / bh);
   return (bw * f0) * (bh * f0) / Math.max(1, rect.w * rect.h);
}
function ccGxAutoPose(box, rect) {
   var yaw = CC_GX_CAM.YAW, p0 = CC_GX_CAM.PITCH, key = [box.hx.toFixed(3), box.hy.toFixed(3), box.hz.toFixed(3), Math.round(rect.w), Math.round(rect.h), CC_GX_BREAK].join("|");
   if (ccGxBroken("camstrip")) return { yaw: yaw, pitch: p0, cover: ccGxCover(box, rect, yaw, p0) };
   if (CC_GX_AUTO_CACHE.key === key) return CC_GX_AUTO_CACHE.pose;
   var A = CC_GX_AUTO, sgn = (p0 < 0) ? -1 : 1, list = [], best = 0, p;
   for (p = A.PITCH_MIN; p <= A.PITCH_MAX + 1e-9; p += A.STEP) { var c = ccGxCover(box, rect, yaw, sgn * p); list.push({ pitch: sgn * p, cover: c }); if (c > best) best = c; }
   var need = Math.min(best - A.TOL, A.GOOD), f = ccGxCover(box, rect, yaw, p0), out = null;
   if (f >= need) out = { yaw: yaw, pitch: p0, cover: f };
   else for (var i = 0; i < list.length && !out; ++i) if (list[i].cover >= need && Math.abs(list[i].pitch) >= Math.abs(p0)) out = { yaw: yaw, pitch: list[i].pitch, cover: list[i].cover };
   if (!out) out = { yaw: yaw, pitch: p0, cover: f };
   out.factoryCover = f;
   CC_GX_AUTO_CACHE.key = key; CC_GX_AUTO_CACHE.pose = out;
   return out;
}
// LA CÁMARA: px(X, Y, Z) del mundo -> { x, y, z (zc), w, ok }; seg(...) recortada; los ejes de la cámara para mover la vista.
function ccGxCam(box, rect, view) {
   var V = ccGxCamView(view), P = ccGxPose(V.yaw, V.pitch);
   if (!(V.f0 > 0) || !isFinite(V.cx) || !isFinite(V.cy)) {
      var fr = ccGxCamFrame(box, rect, V.yaw, V.pitch);
      if (!(V.f0 > 0)) V.f0 = fr.f0;
      if (!isFinite(V.cx)) V.cx = fr.cx;
      if (!isFinite(V.cy)) V.cy = fr.cy;
   }
   var persp = (CC_GX_CAM.PERSPECTIVE === true), K0 = CC_GX_CAM.CAM_DIST * ccGxBoxRadius(box), K = K0 / V.zoom, sc = V.f0 * V.zoom, near = CC_GX_CAM.NEAR * K;
   var Cx = V.ox, Cy = V.oy, Cz = V.oz, cy = P.cy, sy = P.sy, cp = P.cp, sp = P.sp, scx = V.cx, scy = V.cy;
   var clip = { x: rect.x - 64, y: rect.y - 64, w: rect.w + 128, h: rect.h + 128 };
   function cam3(u, v, t) {
      var X = u - Cx, Y = v - Cy, Z = t - Cz, d1 = Z * cy - X * sy;
      return [X * cy + Z * sy, Y * cp + d1 * sp, d1 * cp - Y * sp];
   }
   function pxBox(u, v, t) {
      var c = cam3(u, v, t);
      if (!persp) return { x: scx + sc * c[0], y: scy + sc * c[1], z: c[2], w: 1, ok: true };
      var den = K + c[2], ok = (den > near), w = K / (ok ? den : near);
      return { x: scx + sc * c[0] * w, y: scy + sc * c[1] * w, z: c[2], w: w, ok: ok };
   }
   function px(X, Y, Z) { return pxBox(-Y, -Z, X); }
   function segBox(u0, v0, t0, u1, v1, t1) {
      var a = cam3(u0, v0, t0), b = cam3(u1, v1, t1), wa = 1, wb = 1;
      if (persp) {
         var da = K + a[2], db = K + b[2], f;
         if (da <= near && db <= near) return null;
         if (da <= near) { f = (near - da) / (db - da); a = [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, near - K]; da = near; }
         else if (db <= near) { f = (near - db) / (da - db); b = [b[0] + (a[0] - b[0]) * f, b[1] + (a[1] - b[1]) * f, near - K]; db = near; }
         wa = K / da; wb = K / db;
      }
      return ccGxClipSegment(scx + sc * a[0] * wa, scy + sc * a[1] * wa, scx + sc * b[0] * wb, scy + sc * b[1] * wb, clip);
   }
   function seg(X0, Y0, Z0, X1, Y1, Z1) { return segBox(-Y0, -Z0, X0, -Y1, -Z1, X1); }
   // el rayo de la cámara por un píxel (sx, sy), en el MUNDO: { o: origen, d: dirección } (para el brillo del disco)
   // (OJO: los argumentos NO pueden llamarse sx, sy: taparían el seno del giro `sy` de la pose; así salió el 22-oct un disco
   //  3D sin resplandor —el rayo salía de un origen distinto para cada píxel—, cazado con una prueba en node)
   function ray(qx, qy) {
      var xc = (qx - scx) / sc, yc = (qy - scy) / sc * (ccGxBroken("ray") ? -1 : 1);      // en el plano del pivote (zc = 0), en kpc (ROJO «ray»)
      // la cámara está en zc = −K (perspectiva); el punto del plano del pivote, en (xc, yc, 0)
      var R = [cy, 0, sy], U = [-sy * sp, cp, cy * sp], W = [-sy * cp, -sp, cy * cp];
      function toWorld(c0, c1, c2) {              // de la cámara a la caja y de la caja al mundo
         var u = Cx + c0 * R[0] + c1 * U[0] + c2 * W[0], v = Cy + c0 * R[1] + c1 * U[1] + c2 * W[1], t = Cz + c0 * R[2] + c1 * U[2] + c2 * W[2];
         return [t, -u, -v];
      }
      if (!persp) { var o0 = toWorld(xc, yc, -1000), o1 = toWorld(xc, yc, 0); return { o: o0, d: [o1[0] - o0[0], o1[1] - o0[1], o1[2] - o0[2]] }; }
      var oC = toWorld(0, 0, -K), pP = toWorld(xc, yc, 0);
      return { o: oC, d: [pP[0] - oC[0], pP[1] - oC[1], pP[2] - oC[2]] };
   }
   return { mode: "perspective", scale: sc, f0: V.f0, K: K, K0: K0, persp: persp, near: near, zoom: V.zoom, pose: P, view: V, cx: scx, cy: scy,
            rect: rect, clip: clip, right: [cy, 0, sy], up: [-sy * sp, cp, cy * sp], fwd: [-sy * cp, -sp, cy * cp],
            px: px, pxBox: pxBox, seg: seg, ray: ray };
}
// GIRAR (desde la vista al empezar el arrastre), DESPLAZAR, LA RUEDA hacia el cursor, ENTRE DOS VISTAS: Cabra3D tal cual.
function ccGxCamOrbit(view, dx, dy) {
   var v = ccGxCamView(view);
   v.yaw = v.yaw - dx * CC_GX_CAM.ORBIT_X; v.pitch = v.pitch + dy * CC_GX_CAM.ORBIT_Y;
   v.f0 = 0; v.cx = NaN; v.cy = NaN;
   return ccGxCamView(v);
}
function ccGxCamPan(fit, dx, dy) {
   var v = ccGxCamView(fit.view), k = 1 / fit.scale, R = fit.right, U = fit.up;
   v.ox -= (dx * R[0] + dy * U[0]) * k; v.oy -= (dx * R[1] + dy * U[1]) * k; v.oz -= (dx * R[2] + dy * U[2]) * k;
   return ccGxCamView(v);
}
function ccGxCamZoomAt(fit, factor, sx, sy, zHint) {
   var v = ccGxCamView(fit.view), z0 = v.zoom, z1 = Math.max(CC_GX_CAM.ZOOM_MIN, Math.min(CC_GX_CAM.ZOOM_MAX, z0 * factor)), r = z1 / z0;
   if (r > 1) {
      var zq = (typeof zHint === "number" && isFinite(zHint) && (!fit.persp || fit.K + zHint > fit.near)) ? zHint : 0;
      var kk = fit.persp ? (fit.K + zq) / (fit.scale * fit.K) : 1 / fit.scale;
      var xq = (sx - fit.cx) * kk, yq = (sy - fit.cy) * kk, m = 1 - 1 / r, R = fit.right, U = fit.up, W = fit.fwd;
      v.ox += m * (xq * R[0] + yq * U[0] + zq * W[0]);
      v.oy += m * (xq * R[1] + yq * U[1] + zq * W[1]);
      v.oz += m * (xq * R[2] + yq * U[2] + zq * W[2]);
   } else if (r < 1 && z0 > 1) {
      var gq = Math.max(0, (z1 - 1) / (z0 - 1));
      v.ox *= gq; v.oy *= gq; v.oz *= gq;
   }
   v.zoom = z1;
   return ccGxCamView(v);
}
function ccGxCamLerp(a, b, s) {
   var A = ccGxCamView(a), B = ccGxCamView(b);
   if (s <= 0) return A;
   if (s >= 1) return B;
   var dyaw = B.yaw - A.yaw;
   if (dyaw > 180) dyaw -= 360;
   if (dyaw < -180) dyaw += 360;
   function L(p, q) { return p + (q - p) * s; }
   function Gm(p, q) { return (p > 0 && q > 0) ? Math.exp(L(Math.log(p), Math.log(q))) : L(p, q); }
   return ccGxCamView({ yaw: A.yaw + dyaw * s, pitch: L(A.pitch, B.pitch), zoom: Gm(A.zoom, B.zoom), ox: L(A.ox, B.ox), oy: L(A.oy, B.oy), oz: L(A.oz, B.oz),
                        f0: Gm(A.f0, B.f0), cx: L(A.cx, B.cx), cy: L(A.cy, B.cy) });
}
function ccGxDepthOrder(z, n) {
   var a = new Array(n);
   for (var i = 0; i < n; ++i) a[i] = i;
   a.sort(function(p, q) { return (z[q] - z[p]) || (p - q); });
   return a;
}
function ccGxDepthSize(m) { return (m >= 1) ? Math.min(5, Math.pow(m, 1.15)) : Math.max(0.3, Math.pow(Math.max(m, 1e-6), 2.2)); }
function ccGxDepthDim(m) { return (m >= 1) ? 1 : Math.max(0.35, Math.pow(Math.max(m, 1e-6), 2)); }

// ---------------------------------------------------------------------------
// LAS VISTAS 2D: desde arriba (X–Y, desde el norte) y de canto (R–z). Zoom y desplazamiento propios.
// ---------------------------------------------------------------------------
// v2 = { k (aumentos, 1 = el encuadre de fábrica), cx, cy (el centro en kpc de la vista) }.
// Desde arriba: en pantalla, ARRIBA = +X (del Sol hacia el centro) y DERECHA = −Y: es la vista desde el polo norte
// sin espejo (derecha × arriba = +Z, hacia quien mira), el Sol abajo y el giro en el sentido de las agujas del reloj.
function ccGxTopXf(G, rect, v2) {
   var E = G.ext.top, k = (v2 && v2.k > 0) ? v2.k : 1, ccx = (v2 && ccIsNum(v2.cx)) ? v2.cx : E.cx, ccy = (v2 && ccIsNum(v2.cy)) ? v2.cy : E.cy;
   var ppk = k * Math.min(rect.w, rect.h) / (2 * E.half), mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2;
   var flip = ccGxBroken("flip") ? -1 : 1;      // (ROJO «flip»: la vista en espejo, desde el sur)
   // (cx, cy) del centro son coordenadas de PANTALLA en kpc: a = −Y (derecha), b = +X (arriba)
   return { kind: "top", ppk: ppk, k: k, ca: ccx, cb: ccy, rect: rect,
            px: function(X, Y) { return { x: mx + (flip * -Y - ccx) * ppk, y: my - (X - ccy) * ppk }; },
            inv: function(sx, sy) { var a = ccx + (sx - mx) / ppk, b = ccy - (sy - my) / ppk; return { X: b, Y: -a * flip }; } };
}
function ccGxEdgeXf(G, rect, v2) {
   var E = G.ext.edge, k = (v2 && v2.k > 0) ? v2.k : 1;
   // (de fábrica, R de −4 % a 100 % de r1: el centro galáctico queda dentro del marco, no en su borde)
   var cR = (v2 && ccIsNum(v2.cx)) ? v2.cx : E.r1 * 0.48, cz = (v2 && ccIsNum(v2.cy)) ? v2.cy : 0;
   var sx = k * rect.w / (1.04 * E.r1), sz = k * rect.h / (2 * E.z1), mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2;
   return { kind: "edge", sx: sx, sz: sz, k: k, cR: cR, cz: cz, rect: rect,
            px: function(R, z) { return { x: mx + (R - cR) * sx, y: my - (z - cz) * sz }; },
            inv: function(px, py) { return { R: cR + (px - mx) / sx, z: cz - (py - my) / sz }; } };
}
// LA RUEDA en 2D: el punto bajo el cursor no se mueve. Devuelve el v2 nuevo.
function ccGx2DZoomAt(xf, factor, sx, sy) {
   var k1 = Math.max(0.5, Math.min(200, xf.k * factor)), r = k1 / xf.k, R = xf.rect, mx = R.x + R.w / 2, my = R.y + R.h / 2;
   if (xf.kind === "top") {
      var a = xf.ca + (sx - mx) / xf.ppk, b = xf.cb - (sy - my) / xf.ppk;
      return { k: k1, cx: a - (a - xf.ca) / r, cy: b - (b - xf.cb) / r };
   }
   var Rq = xf.cR + (sx - mx) / xf.sx, zq = xf.cz - (sy - my) / xf.sz;
   return { k: k1, cx: Rq - (Rq - xf.cR) / r, cy: zq - (zq - xf.cz) / r };
}
function ccGx2DPan(xf, dx, dy) {
   if (xf.kind === "top") return { k: xf.k, cx: xf.ca - dx / xf.ppk, cy: xf.cb + dy / xf.ppk };
   return { k: xf.k, cx: xf.cR - dx / xf.sx, cy: xf.cz + dy / xf.sz };
}
#endif
// (23-oct) la Galaxia en el tiempo: el pasado entero de cada órbita, el reloj y sus placas. Se incluye desde aquí (CabraComposition.js
// no es mío): la ruta es relativa a ESTE fichero.
#include "cc_galaxy_time.js"
