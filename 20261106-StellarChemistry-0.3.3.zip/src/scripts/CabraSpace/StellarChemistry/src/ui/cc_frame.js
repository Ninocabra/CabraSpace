// ============================================================================
// src/ui/cc_frame.js — EL ARMAZÓN COMÚN con CabraStars y Cabra3D (22-oct-2026)
// ----------------------------------------------------------------------------
// Las piezas de la interfaz «como Cabra3D» que ya tienen CabraStars y Cabra3D, COPIADAS y adaptadas (prefijo cc,
// colores y letra de cc_atlas.js, tamaños con ccPx: píxeles físicos a la escala de CabraComposition):
//   · píldoras de estado (QLabel y pintadas) ........ CabraStars/lib/cs_atlas.js: csPillCss, csPillColors, csPaintPill
//                                                       (a su vez de Cabra3D/src/host/host_copied.js cpStyleStatusPill)
//   · iconos SVG a trazos (sin Bitmap ni fichero) .... CabraStars/lib/cs_atlas.js: csPathToPolys, csPaintIcon
//                                                       (a su vez de Cabra3D/src/ui/groups.js c3PathToPolys)
//   · botón de icono pintado (↻ y ⛶) ................. CabraStars/lib/cs_atlas.js: csIconButton, csIconControl
//   · el ancho de los botones (una hoja de estilo BORRA el ancho fijado; un PushButton pide ~75 px) .......
//                                                       CabraStars/lib/cs_atlas.js: csFixSize, csApplyFix, csFitButton
//   · el separador arrastrable ...................... CabraStars/lib/cs_splitter.js (CSSplitter, de Cabra3D/src/ui/splitter.js)
//   · la barra de estado con la barra de progreso DENTRO (fija) ... CabraStars/lib/cs_ui_card.js: csDrawStatusBar
//   · la cabecera de un grupo plegable ............... CabraStars/lib/cs_ui.js: CSStarsDialog.prototype._section
//   · lo recordado de los paneles (no en pruebas) .... CabraStars/lib/cs_ui.js: csLayoutRead/csLayoutWrite (CS_LAYOUT_IO)
// CabraStars y Cabra3D NO se tocan desde aquí. Este fichero lo incluye CabraComposition.js (NO CabraStarAnalysis): lo
// usa solo ccBuildDialog, en tiempo de ejecución, así que CabraStarAnalysis compila igual sin él.
// ES5, salvo la subclase de Control del separador (obligatoria bajo V8).
// ============================================================================

// Tonos derivados (ninguno es un token nuevo: cs_atlas.js de CabraStars, mismos cálculos)
var CC_GOLD_RING = ccMix(CC_ATLAS.surface, CC_ATLAS.gold, 0.45);
var CC_TEXT_OFF = ccMix(CC_ATLAS.text3, CC_ATLAS.bg, 0.45);
var CC_GOLD_BG = ccMix(CC_ATLAS.bg, CC_ATLAS.gold, 0.16);
var CC_OK_BG = ccMix(CC_ATLAS.bg, CC_ATLAS.ok, 0.18);
var CC_ERROR_BG = ccMix(CC_ATLAS.bg, CC_ATLAS.error, 0.18);

// Las medidas del armazón, en píxeles LÓGICOS (× ccScale al usarlas). Las de CabraStars (CS_UI), y las propias de los paneles.
var CC_UI = { HEAD_H: 34, BAR_H: 38, GROUP_H: 26, STATUS_H: 20, TITLE_H: 44, FOOT_H: 22, TIMELINE_H: 170, TIMELINE_MAX: 250, LEFT_GAP: 6, PLOT_OPEN: 150, SPLIT_W: 7, INDENT: 26,
              PHOTO_MIN: 360, RIGHT_MIN: 560, COL_MIN: 240, CARD_MIN: 290, PLOT_MIN: 110, GROUP_MIN: 100,
              MIN_W: 1360, MIN_H: 880, W: 1560, H: 960 };     // (MIN_W 1360 = el de CabraStars: con las píldoras de CabraStars, 22-oct)
// (23-oct · R9, decisión de Nino) La línea de tiempo va BAJO LA FOTO, a lo ancho de la mitad izquierda: TIMELINE_H es su alto mínimo y
// TIMELINE_MAX el máximo; entre los dos, el que deje la foto encajada (con su leyenda) sin hueco negro debajo (D.fitLeft).
// PLOT_OPEN: lo que se le guarda a cada diagrama de la columna con un grupo abierto (el cuerpo del grupo cede lo que falte y va con
// rueda). (La franja de D1-A, TL_STRIP_H, desapareció: E ya no está en la columna derecha y no hace falta plegarla.)

// ---------------------------------------------------------------------------
// LO RECORDADO DE LOS PANELES (como CabraStars, 21-oct): el ancho de la foto (S1) y el de la columna de vistas (S2), en
// píxeles LÓGICOS, bajo `CabraComposition/Layout/…`. 0 o ausente = de fábrica. En las pruebas (CC_NO_MAIN) NO se lee ni se
// escribe, salvo que una prueba ponga CC_LAYOUT_IO = true (y entonces restaura lo que hubiera).
// ---------------------------------------------------------------------------
var CC_LAYOUT_IO = false;
function ccLayoutIO() { return CC_LAYOUT_IO === true || !(typeof CC_NO_MAIN !== "undefined" && CC_NO_MAIN) || (typeof ccBroken === "function" && ccBroken("layoutio")); }
function ccLayoutRead(key) {
   if (!ccLayoutIO()) return 0;
   try { var v = Settings.read(CC_SETTINGS + "/Layout/" + key, DataType_Int32); if (typeof v === "number" && isFinite(v) && v > 0 && Settings.lastReadOK !== false) return Math.round(v); } catch (e) {}
   return 0;
}
function ccLayoutWrite(key, v) { if (!ccLayoutIO()) return; try { Settings.write(CC_SETTINGS + "/Layout/" + key, DataType_Int32, Math.max(0, Math.round(v))); } catch (e) {} }

// ---------------------------------------------------------------------------
// LAS HOJAS de los mandos propios del armazón (en px FÍSICOS: CabraComposition escribe sus hojas a su escala)
// ---------------------------------------------------------------------------
function ccPxs(n) { return Math.round(n * ccScale()) + "px"; }
function ccCssToggle(on) {
   var A = CC_ATLAS;
   if (on) return "QPushButton { background-color:" + A.surface2 + "; color:" + A.goldLight + "; border:1px solid " + A.gold + "; border-radius:" + ccPxs(9) + "; padding:" + ccPxs(2) + " " + ccPxs(9) +
                  "; font-size:" + ccPxs(10) + "; font-weight:700; min-width:0px; background-image:none; border-image:none; } QPushButton:hover { color:" + A.text + "; } QPushButton:focus { outline:none; }";
   return "QPushButton { background-color:" + CC_INSET + "; color:" + A.text2 + "; border:1px solid " + A.line + "; border-radius:" + ccPxs(9) + "; padding:" + ccPxs(2) + " " + ccPxs(9) +
          "; font-size:" + ccPxs(10) + "; font-weight:500; min-width:0px; background-image:none; border-image:none; } QPushButton:hover { color:" + A.text + "; border:1px solid " + CC_GOLD_RING + "; }" +
          " QPushButton:disabled { color:" + CC_TEXT_OFF + "; border:1px solid " + A.line + "; } QPushButton:focus { outline:none; }";
}
function ccCssPrimary() {
   var A = CC_ATLAS;
   return "QPushButton { background-color:" + A.gold + "; color:" + A.ink + "; border:1px solid " + A.goldLight + "; border-radius:" + ccPxs(10) + "; padding:" + ccPxs(4) + " " + ccPxs(14) +
          "; font-size:" + ccPxs(11) + "; font-weight:700; min-width:0px; background-image:none; border-image:none; } QPushButton:hover { background-color:" + A.goldLight + "; }" +
          " QPushButton:pressed { background-color:" + A.text + "; } QPushButton:disabled { background-color:" + A.surface2 + "; color:" + CC_TEXT_OFF + "; border:1px solid " + A.line + "; } QPushButton:focus { outline:none; }";
}
function ccCssBarLabel() { return "QLabel { color:" + CC_ATLAS.text3 + "; font-size:" + ccPxs(10) + "; background:transparent; border:none; }"; }
// LAS PÍLDORAS DE ESTADO de la barra de imagen. kind: "ok" (verde) · "warn" (oro) · "error" (bermellón) · "pending" (gris)
function ccPillCss(kind) {
   var A = CC_ATLAS, col = A.text3, bg = CC_INSET, edge = A.line;
   if (kind === "ok") { col = ccMix(A.ok, A.text, 0.25); bg = CC_OK_BG; edge = ccMix(A.bg, A.ok, 0.5); }
   else if (kind === "warn") { col = A.goldLight; bg = CC_GOLD_BG; edge = ccMix(A.bg, A.gold, 0.55); }
   else if (kind === "error") { col = A.error; bg = CC_ERROR_BG; edge = A.error; }
   return "QLabel { background-color:" + bg + "; color:" + col + "; border:1px solid " + edge + "; border-radius:" + ccPxs(10) + "; padding:" + ccPxs(2) + " " + ccPxs(10) + "; font-size:" + ccPxs(10) + "; background-image:none; }";
}
// Los colores de una píldora PINTADA (la línea de estado del panel y la barra de abajo), los mismos que los de arriba.
function ccPillColors(kind) {
   var A = CC_ATLAS;
   if (kind === "ok") return { text: ccInt(ccMix(A.ok, A.text, 0.25)), bg: ccInt(CC_OK_BG), edge: ccInt(ccMix(A.bg, A.ok, 0.5)), dot: ccInt(A.ok) };
   if (kind === "warn" || kind === "busy") return { text: ccInt(A.goldLight), bg: ccInt(CC_GOLD_BG), edge: ccInt(ccMix(A.bg, A.gold, 0.55)), dot: ccInt(A.gold) };
   if (kind === "error") return { text: ccInt(A.error), bg: ccInt(CC_ERROR_BG), edge: ccInt(A.error), dot: ccInt(A.error) };
   return { text: ccInt(A.text3), bg: ccInt(CC_INSET), edge: ccInt(A.line), dot: ccInt(A.text3) };
}
// Una píldora pintada que ocupa (x, y, w, h): fondo redondeado, filete y punto. Devuelve la x donde empieza el texto.
function ccPaintPill(g, x, y, w, h, sc, kind) {
   var C = ccPillColors(kind), r = h / 2;
   g.antialiasing = true;
   g.pen = new Pen(C.edge, 1); g.brush = new Brush(C.bg);
   try { g.drawRoundedRect(x + 0.5, y + 0.5, x + w - 0.5, y + h - 0.5, r, r); } catch (e) { g.drawRect(x, y, x + w, y + h); }
   g.pen = new Pen(0x00000000, 0); g.brush = new Brush(C.dot); g.drawCircle(x + r + 2 * sc, y + h / 2, 3 * sc);
   ccNoBrush(g);
   return x + r + 10 * sc;
}

// ---------------------------------------------------------------------------
// LOS ICONOS, PINTADOS A TRAZOS (ruta SVG, viewBox 24×24; solo M, L, H, V, C y Z absolutas -> polilíneas UNA vez)
// ---------------------------------------------------------------------------
var CC_ICON_POLYS = {};
function ccPathToPolys(path) {
   var tok = String(path).match(/[MLHVCZ]|-?\d+(?:\.\d+)?/g) || [], polys = [], cur = null, i = 0, cx = 0, cy = 0, sx = 0, sy = 0, cmd = "";
   function num() { return parseFloat(tok[i++]); }
   while (i < tok.length) {
      if (/^[MLHVCZ]$/.test(tok[i])) cmd = tok[i++];
      if (cmd === "Z") { if (cur) { cur.push([sx, sy]); cx = sx; cy = sy; } cmd = ""; continue; }
      if (cmd === "M") { cx = num(); cy = num(); sx = cx; sy = cy; cur = [[cx, cy]]; polys.push(cur); cmd = "L"; }
      else if (cmd === "L") { cx = num(); cy = num(); if (!cur) { cur = [[cx, cy]]; polys.push(cur); } else cur.push([cx, cy]); }
      else if (cmd === "H") { cx = num(); cur.push([cx, cy]); }
      else if (cmd === "V") { cy = num(); cur.push([cx, cy]); }
      else if (cmd === "C") {
         var x1 = num(), y1 = num(), x2 = num(), y2 = num(), x3 = num(), y3 = num();
         for (var k = 1; k <= 12; ++k) {
            var t = k / 12, u = 1 - t;
            cur.push([u * u * u * cx + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3, u * u * u * cy + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3]);
         }
         cx = x3; cy = y3;
      } else break;                                   // (una orden que no conocemos: se para, no se inventa)
   }
   return polys;
}
function ccPaintIcon(g, path, x, y, px, color) {
   var polys = CC_ICON_POLYS[path];
   if (polys === undefined) polys = CC_ICON_POLYS[path] = ccPathToPolys(path);
   var k = px / 24;
   g.pen = new Pen(color, Math.max(1, 1.8 * k));
   for (var a = 0; a < polys.length; ++a) { var Q = polys[a]; for (var b = 1; b < Q.length; ++b) g.drawLine(x + Q[b - 1][0] * k, y + Q[b - 1][1] * k, x + Q[b][0] * k, y + Q[b][1] * k); }
}
// Las rutas: las de CabraStars (eye, image, target, full, refresh, flight) y dos propias (espiral, matraz)
var CC_ICON = {
   eye:      "M2 12 C5 7 8 5 12 5 C16 5 19 7 22 12 C19 17 16 19 12 19 C8 19 5 17 2 12 Z M15 12 C15 13.66 13.66 15 12 15 C10.34 15 9 13.66 9 12 C9 10.34 10.34 9 12 9 C13.66 9 15 10.34 15 12 Z",
   image:    "M5 4 H19 C20.1 4 21 4.9 21 6 V18 C21 19.1 20.1 20 19 20 H5 C3.9 20 3 19.1 3 18 V6 C3 4.9 3.9 4 5 4 Z M11 10 C11 11.1 10.1 12 9 12 C7.9 12 7 11.1 7 10 C7 8.9 7.9 8 9 8 C10.1 8 11 8.9 11 10 Z M21 17 L16 12 L7 20",
   target:   "M19 12 C19 15.87 15.87 19 12 19 C8.13 19 5 15.87 5 12 C5 8.13 8.13 5 12 5 C15.87 5 19 8.13 19 12 Z M12 2 V7 M12 17 V22 M2 12 H7 M17 12 H22",
   full:     "M4 9 V4 H9 M15 4 H20 V9 M20 15 V20 H15 M9 20 H4 V15",
   refresh:  "M20 12 C20 16.42 16.42 20 12 20 C7.58 20 4 16.42 4 12 C4 7.58 7.58 4 12 4 C14.6 4 16.9 5.2 18.4 7.2 M19 2.5 V7.5 H14",
   // (II · VIAJE Y VÍDEO: la cámara de cine, la MISMA del grupo «FLIGHT AND VIDEO» de CabraStars —lib/cs_flight_ui.js:34, CS_ICON.flight—,
   //  que a su vez es la de Cabra3D src/ui/groups.js:22)
   flight:   "M3 7 H15 V17 H3 Z M15 10.5 L21 7 V17 L15 13.5",
   // (III · LA GALAXIA: una espiral de dos brazos con su bulbo)
   galaxy:   "M12 12 C12 9.5 14.5 8.5 16.5 10 C19 12 18 16.5 14 17.5 C9.5 18.5 5 15.5 5 11 C5 7 8.5 4 13 4.2 M12 12 C12 14.5 9.5 15.5 7.5 14 C5 12 6 7.5 10 6.5 C14.5 5.5 19 8.5 19 13 C19 17 15.5 20 11 19.8 M13 12 C13 12.55 12.55 13 12 13 C11.45 13 11 12.55 11 12 C11 11.45 11.45 11 12 11 C12.55 11 13 11.45 13 12 Z"
   // (el matraz de IV · ELEMENTOS se fue con el grupo el 23-oct: el elemento es una fila de I)
};
// UN BOTÓN DE ICONO pintado: recuadro redondeado con el filete de los mandos y el icono a trazos; `ccOn` lo pinta de oro.
function ccIconButton(parent, path, tip, onClick, wLogical, hLogical) {
   var c = new Control(parent);
   c.setFixedSize(ccPx(wLogical || 26), ccPx(hLogical || 22));
   c.toolTip = ccWrapTip(tip || "");
   c.cursor = new Cursor(StdCursor_PointingHand);
   c.ccOn = false; c.ccHover = false; c.ccPath = path;
   try { c.mouseTracking = true; } catch (eM) {}
   c.onEnter = function() { if (CC_QUIET) return; c.ccHover = true; c.update(); };
   c.onLeave = function() { if (CC_QUIET) return; c.ccHover = false; c.update(); };
   c.onMousePress = function() { if (CC_QUIET) return; if (c.enabled) onClick(); };
   c.onPaint = function() {
      if (CC_QUIET) return;
      var g = new Graphics(c), sc = ccScale(c);
      try {
         g.antialiasing = true;
         var w = c.width, h = c.height, r = 9 * sc, en = c.enabled;
         g.fillRect(0, 0, w, h, new Brush(ccInt(CC_ATLAS.bg)));
         g.pen = new Pen(ccInt(c.ccOn ? CC_ATLAS.gold : (c.ccHover && en) ? CC_GOLD_RING : CC_ATLAS.line), 1); g.brush = new Brush(ccInt(c.ccOn ? CC_ATLAS.surface2 : CC_INSET));
         try { g.drawRoundedRect(0.5, 0.5, w - 0.5, h - 0.5, r, r); } catch (eR) { g.drawRect(0, 0, w - 1, h - 1); }
         ccNoBrush(g);
         var s = Math.round(14 * sc);
         ccPaintIcon(g, c.ccPath, Math.round((w - s) / 2), Math.round((h - s) / 2), s, ccInt(c.ccOn ? CC_ATLAS.goldLight : en ? CC_ATLAS.text2 : CC_TEXT_OFF));
      } finally { g.end(); }
   };
   return c;
}
// Un icono suelto (rótulos de la barra), pintado a trazos en el color dado
function ccIconControl(parent, path, colorInt, sizeLogical) {
   var c = new Control(parent), s = sizeLogical || 14;
   c.setFixedSize(ccPx(s + 2), ccPx(s + 2));
   c.onPaint = function() { if (CC_QUIET) return; var g = new Graphics(c), sc = ccScale(c); try { g.antialiasing = true; ccPaintIcon(g, path, Math.round(sc), Math.round(sc), Math.round(s * sc), colorInt); } finally { g.end(); } };
   return c;
}

// ---------------------------------------------------------------------------
// EL ANCHO DE UN BOTÓN (CabraStars, 21-oct): aplicar una hoja de estilo BORRA el ancho fijado antes, y un PushButton sin
// ancho propio pide el mínimo de Windows (~75 px: salían «ES» y «To view» de 130 px). Se apunta y se repone.
// ---------------------------------------------------------------------------
function ccApplyFix(ctrl) { var f = null; try { f = ctrl.__ccFix; } catch (e) {} if (!f) return; try { if (f.w) ctrl.setFixedWidth(f.w); if (f.h) ctrl.setFixedHeight(f.h); } catch (e2) {} }
function ccFixSize(ctrl, wLogical, hLogical) { try { ctrl.__ccFix = { w: wLogical ? ccPx(wLogical) : 0, h: hLogical ? ccPx(hLogical) : 0 }; } catch (e) {} ccApplyFix(ctrl); return ctrl; }
function ccStyle(ctrl, css) { try { ctrl.styleSheet = css; } catch (e) {} ccApplyFix(ctrl); }
// Al ancho de su texto (en negrita: no salta al encenderlo); se llama otra vez al cambiar de idioma.
// `h`: alto propio (22 de fábrica); a 11 px en negrita 22 recorta los descendentes (CabraStars: «Analyse» se leía «Analvse»)
function ccFitButton(b, pad, minW, px, h) {
   var t = String(b.text || ""), w = 0;
   try { w = Math.ceil(ccFont("text", (px || 10) * ccScale(), true).width(t) / ccScale()); } catch (e) { w = 7 * t.length; }
   if (typeof ccBroken === "function" && ccBroken("wide")) minW = 80;        // (rojo de las pruebas: el mínimo de Windows)
   return ccFixSize(b, Math.max(minW || 0, w + (pad || 24)), h || 22);
}
function ccToggleButton(parent, text, tip, onClick) {
   var b = new PushButton(parent);
   b.text = text; b.toolTip = ccWrapTip(tip || ""); b.onClick = onClick;
   ccStyle(b, ccCssToggle(false));
   try { b.focusStyle = 0; } catch (eF) {}         // sin foco de teclado: la trama azul de Qt (CabraStars, sonda cs_probe_focus.js)
   return b;
}
function ccSetToggle(b, on) { ccStyle(b, ccCssToggle(!!on)); b.ccOnState = !!on; }

// ---------------------------------------------------------------------------
// EL SEPARADOR arrastrable (CabraStars/lib/cs_splitter.js). PJSR no tiene splitter: un Control estrecho con cursor de
// redimensión que ajusta el ancho FIJO del control contiguo (`target`). opts = { target, invert, min, max, onResized, onReset, tip }
//   min/max: px físicos (número o función) · onResized(w, final): `final` = true al soltar · doble clic -> onReset()
// ---------------------------------------------------------------------------
function ccInitSplitter(parent, opts) {
   var self = this;
   this.target = opts.target;
   this.invert = (opts.invert === true);
   this._min = (opts.min !== undefined) ? opts.min : 100;
   this._max = (opts.max !== undefined) ? opts.max : 100000;
   this.onResized = opts.onResized || null;
   this.onReset = opts.onReset || null;
   this._dragging = false; this._x0 = 0; this._w0 = 0; this._hover = false;
   this.setFixedWidth(ccPx(CC_UI.SPLIT_W));
   // (OJO: la constante es StdCursor_HorizontalSize; StdCursor_SizeHor NO existe en PJSR)
   this.cursor = new Cursor(StdCursor_HorizontalSize);
   if (opts.tip) this.toolTip = ccWrapTip(opts.tip);
   try { this.focusStyle = 0; } catch (eF) {}
   this.limit = function(v) {
      var lo = (typeof self._min === "function") ? self._min() : self._min, hi = (typeof self._max === "function") ? self._max() : self._max;
      if (hi < lo) hi = lo;
      return Math.max(lo, Math.min(hi, Math.round(v)));
   };
   // Poner el ancho del objetivo (acotado) y avisar. Lo usan el ratón y las pruebas.
   this.setWidth = function(w, final) {
      var v = self.limit(w);
      try { self.target.setFixedWidth(v); } catch (e) {}
      if (self.onResized) self.onResized(v, final === true);
      return v;
   };
   this.onPaint = function() {
      if (CC_QUIET) return;
      var g = new Graphics(this), sc = ccScale(this);
      try {
         g.fillRect(0, 0, this.width, this.height, new Brush(ccInt(CC_ATLAS.bg)));
         // tres puntos centrales: la señal universal de «arrastrable»
         var cx = Math.round(this.width / 2), cy = Math.round(this.height / 2), d = Math.max(1, Math.round(sc)), step = Math.round(8 * sc);
         var col = ccInt((self._dragging || self._hover) ? CC_ATLAS.gold : CC_ATLAS.line);
         for (var i = -1; i <= 1; ++i) g.fillRect(cx - d, cy + i * step - d, cx + d, cy + i * step + d, new Brush(col));
      } finally { g.end(); }
   };
   this.onEnter = function() { self._hover = true; self.update(); };
   this.onLeave = function() { self._hover = false; self.update(); };
   this.onMousePress = function(x) { self._dragging = true; self._x0 = self._globalX(x); self._w0 = self.target.width; self.update(); };
   this.onMouseMove = function(x) {
      if (!self._dragging) return;
      var d = self._globalX(x) - self._x0;
      self.setWidth(self._w0 + (self.invert ? -d : d), false);
   };
   this.onMouseRelease = function() {
      var was = self._dragging;
      self._dragging = false; self.update();
      if (was && self.onResized) self.onResized(self.target.width, true);
   };
   this.onMouseDoubleClick = function() { self._dragging = false; if (self.onReset) self.onReset(); };
}
class CCSplitter extends Control {
   constructor(parent, opts) { super(parent); ccInitSplitter.call(this, parent, opts); }
}
CCSplitter.prototype._globalX = function(x) {
   try { return this.localToGlobal(new Point(x, 0)).x; } catch (e) { return x; }
};

// ---------------------------------------------------------------------------
// LA BARRA DE ESTADO de abajo (CabraStars csDrawStatusBar): una píldora del color de lo que pasa, con la barra de progreso
// DENTRO, a la derecha, de tamaño FIJO (ni cambia de alto ni desplaza nada). P = S.prog { text, frac, busy, error, right }
// ---------------------------------------------------------------------------
function ccStatusKind(P) { if (!P) return "pending"; if (P.error) return "error"; if (P.busy) return "busy"; return (P.frac >= 1) ? "ok" : "pending"; }
function ccPaintStatusBar(g, w, h, P, sc) {
   ccFillRect(g, 0, 0, w, h, ccInt(CC_ATLAS.bg));
   var kind = ccStatusKind(P), C = ccPillColors(kind), tx = ccPaintPill(g, 0, 0, w, h, sc, kind);
   var tw = Math.round(Math.min(260 * sc, w * 0.22)), bx = w - Math.round(12 * sc) - tw, by = Math.round(h / 2 - 2 * sc), bh = Math.max(2, Math.round(4 * sc));
   ccFillRect(g, bx, by, bx + tw, by + bh, ccInt(CC_ATLAS.bg, 0.7));
   var col = ccInt(kind === "error" ? CC_ATLAS.error : kind === "ok" ? CC_ATLAS.ok : CC_ATLAS.gold);
   if (P && P.frac > 0) ccFillRect(g, bx, by, bx + Math.round(tw * Math.min(1, P.frac)), by + bh, col);
   var f = ccFont("text", 9 * sc), fm = ccFont("mono", 8.6 * sc), yT = Math.round((h + f.ascent - f.descent) / 2), xr = bx - Math.round(14 * sc);
   if (P && P.right) { var rt = String(P.right); xr -= fm.width(rt); ccTextAt(g, fm, ccInt(CC_ATLAS.text3), xr, yT, rt); xr -= Math.round(12 * sc); }
   ccTextAt(g, f, C.text, tx, yT, ccElide(f, P ? P.text : "", Math.max(10, xr - tx)));
}

// ---------------------------------------------------------------------------
// LA CABECERA DE UN GRUPO (CabraStars _section): filete de oro arriba, icono a trazos, «I · VIEW» en versalitas, la línea
// de subtítulo gris y ▸/▾. `last`: el último grupo cierra con un filete abajo cuando está plegado.
// ---------------------------------------------------------------------------
function ccPaintGroupHead(g, w, h, sc, roman, title, sub, icon, open, last, hover, help) {
   ccFillRect(g, 0, 0, w, h, ccInt(hover ? CC_ATLAS.surface : CC_ATLAS.bg));
   g.antialiasing = true;
   g.pen = new Pen(ccInt(CC_ATLAS.gold, open ? 0.9 : 0.4), 1); g.drawLine(0, 0, w, 0);
   var ip = Math.round(14 * sc);
   ccPaintIcon(g, icon, Math.round(6 * sc), Math.round((h - ip) / 2), ip, ccInt(CC_ATLAS.gold));
   var fC = ccFont("text", 9.6 * sc, true, false, Math.round(9.6 * sc * CC_ATLAS.labelTracking)), fS = ccFont("text", 9 * sc), fA = ccFont("text", 10 * sc);
   var y = Math.round((h + fC.ascent - fC.descent) / 2), x = Math.round(28 * sc), t = roman + " · " + String(title).toUpperCase();
   ccTextAt(g, fC, ccInt(open ? CC_ATLAS.gold : CC_ATLAS.text), x, y, t);
   x += fC.width(t) + Math.round(12 * sc);
   if (help) { x += ccQMark(g, x - 4 * sc, y + 1 * sc, sc) + Math.round(8 * sc); }     // (la frase llana del grupo, en el tooltip de la cabecera)
   if (sub) ccTextAt(g, fS, ccInt(CC_ATLAS.text3), x, y, ccElide(fS, sub, Math.max(10, w - x - 24 * sc)));
   ccTextAt(g, fA, ccInt(open ? CC_ATLAS.gold : CC_ATLAS.text3), w - Math.round(16 * sc), Math.round((h + fA.ascent - fA.descent) / 2), open ? "▾" : "▸");
   if (last && !open) { g.pen = new Pen(ccInt(CC_ATLAS.line), 1); g.drawLine(0, h - 1, w, h - 1); }
}
