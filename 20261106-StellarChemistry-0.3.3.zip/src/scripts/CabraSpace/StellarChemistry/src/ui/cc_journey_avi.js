#ifndef __CC_JOURNEY_AVI_JS
#define __CC_JOURNEY_AVI_JS
// [CabraComposition, 22-oct-2026, fase 2a] COPIA de CabraStars/lib/cs_video_avi.js (commit 1413273, sin cambios en el arbol de trabajo),
// copia a su vez de Cabra3D 509a762 src/engine/video_avi.js y de CabraPilot integracion-1410c (097fba6). Renombrado csAvi -> ccAvi,
// CS_AVI -> CC_AVI, CS_NO_MAIN -> CC_NO_MAIN; la clave de Settings es la de CabraComposition (CabraComposition/Video/ffmpeg).
// Nada mas cambia: el escritor AVI/MJPEG, su validador y el paso a MP4 con ffmpeg son los medidos alli.
// (3-nov-2026, CPD SC3) SALVO ccAviFfmpeg: ya no busca ffmpeg por su cuenta; pregunta a CabraShared/csh_ffmpeg.js (solo si el usuario lo eligio).
// ============================================================================
// engine/video_avi.js — ESCRIBIR UN VIDEO SIN DEPENDENCIAS: AVI con MJPEG
// ----------------------------------------------------------------------------
// (13-oct-2026.) En la maquina de Nino no hay ffmpeg (ni en el PATH ni dentro de
// PixInsight) y el producto no puede depender de Python. Un AVI con video MJPEG
// se escribe con lo que hay: cada fotograma es un JPEG —que PJSR sabe guardar,
// `Bitmap.save( ruta.jpg, calidad )`— y el AVI es un RIFF con tres cabeceras, la
// lista de fotogramas y un indice:
//
//   RIFF <n> 'AVI '
//     LIST <192> 'hdrl'
//        'avih' <56>   la cabecera del fichero (cuantos fotogramas, tamaño, ritmo)
//        LIST <116> 'strl'
//           'strh' <56>   la del flujo de video ('vids', 'MJPG', ritmo = dwRate / dwScale)
//           'strf' <40>   BITMAPINFOHEADER (ancho, alto, 24 bits, 'MJPG')
//     LIST <n> 'movi'
//        '00dc' <n> …un JPEG entero… [un byte de relleno si n es impar]     × fotogramas
//     'idx1' <16 × fotogramas>
//        '00dc' 0x10 <donde empieza su trozo, contado desde la palabra 'movi'> <n>
//
// La cabecera mide SIEMPRE 224 bytes: se escribe primero con ceros en lo que aun
// no se sabe y al cerrar se vuelve sobre ella. No se acumula el video en memoria:
// fotograma → JPEG temporal → sus bytes al final del fichero → fuera el temporal.
//
// MEDIDO en `_tests/cp_video_avi_probe.log` y `cp_video_avi_probe2.log` (1.9.5 build
// 1706, V8), que es lo que decide como esta escrito esto:
//   · `new ByteArray( Uint8Array )` FUNCIONA (1 MB, 1 ms) y `ByteArray.toUint8Array()` tambien;
//     `new ByteArray( [1, 2, 3] )` LANZA, y `assign( a, b )` no es «pon b en a»: RELLENA;
//   · `File.write( ByteArray )`, `File.position` (leer y poner), y `openForReadWrite` +
//     `position = n` + `write` PARCHEAN sin cambiar el tamaño del fichero;
//   · `SeekMode_FromBegin`, `DataType_UInt32` y `DataType_ByteArray` NO existen: no hay
//     forma conocida de leer un TROZO; para validar se lee el fichero entero (`File.readFile`);
//   · `Bitmap.save( .jpg, calidad )` hace caso de la calidad y tarda 10 ms a 1280 × 720,
//     18 ms a 1920 × 1080 y 53 ms a 3840 × 2160; el JPEG empieza por FF D8 y acaba en FF D9.
//
// LA PARTE PURA (las cabeceras, el indice, el escritor sobre una «io» cualquiera y
// el validador) la ejecuta node: guardian L0-96, `_tests/cp_starfield_flight_cases.js`.
// La parte de PJSR (la «io» sobre `File`, el JPEG temporal, ffmpeg si lo hay) va al
// final y es corta. ES5. (OJO: ni `VERSION` ni `TITLE` como identificadores.)
// ============================================================================

var CC_AVI = {
   HEADER_BYTES: 224,
   // UN AVI CLASICO NO PASA DE 2 GB con garantias (el tamaño del RIFF es de 32 bits y muchos lectores lo tratan
   // con signo). Se parte ANTES, con holgura. (OpenDML / AVIX no esta hecho: se parte en ficheros.)
   LIMIT: 2000000000,
   VALIDATE_MAX: 600000000,           // el validador de PJSR lee el fichero ENTERO: por encima de esto no se intenta
   MP4_TIMEOUT_S: 900,
   // EL MP4 (cuando hay ffmpeg). MEDIDO el 13-oct-2026 en el portatil (`_tests/cp_starfield_flight_look.log` y
   // `cp_starfield_flight_check.py`; cifras en README_TESTS): libx264, preset y CRF de aqui; el intermedio es el AVI
   // propio a calidad 97 (doble compresion, medida contra los PNG sin perdida).
   MP4_CRF: 17, MP4_PRESET: "medium", MP4_SOURCE_QUALITY: 97,
   // EL FILTRO DE COLOR, ELEGIDO MIDIENDO (un fotograma sacado del MP4 contra su PNG original, media por canal, de 255):
   // con el filtro `scale` a secas el video salia 3,0 / 3,0 / 3,6 niveles MAS OSCURO (redondea mal); con `colorspace`,
   // 1,5 / 1,8 / 0,7, de los que 0,8 / 1,0 / 0,9 ya los trae el JPEG. Sin convertir (yuvj420p, rango completo) no hay
   // sesgo añadido, pero ese formato lo interpretan mal bastantes moviles y redes.
   MP4_COLOR: "colorspace=space=bt709:ispace=bt470bg:primaries=bt709:iprimaries=bt709:trc=bt709:itrc=bt709:irange=pc:range=tv:format=yuv420p"
};

function ccAviPutU32(a, pos, v) { v = v >>> 0; a[pos] = v & 255; a[pos + 1] = (v >>> 8) & 255; a[pos + 2] = (v >>> 16) & 255; a[pos + 3] = (v >>> 24) & 255; }
function ccAviPutU16(a, pos, v) { a[pos] = v & 255; a[pos + 1] = (v >>> 8) & 255; }
function ccAviPutTag(a, pos, s) { for (var i = 0; i < 4; ++i) a[pos + i] = s.charCodeAt(i) & 255; }
function ccAviGetU32(a, pos) { return (a[pos] | (a[pos + 1] << 8) | (a[pos + 2] << 16) | (a[pos + 3] << 24)) >>> 0; }
function ccAviGetTag(a, pos) { return String.fromCharCode(a[pos], a[pos + 1], a[pos + 2], a[pos + 3]); }

// El ritmo como fraccion: dwRate / dwScale fotogramas por segundo (30 → 30 / 1; 29,97 → 2997 / 100).
function ccAviRate(fps) {
   var f = (fps > 0 && isFinite(fps)) ? fps : 30, scale = 1;
   while (scale < 1000 && Math.abs(f * scale - Math.round(f * scale)) > 1e-9) scale *= 10;
   return { rate: Math.round(f * scale), scale: scale, usec: Math.round(1e6 / f) };
}
// Lo que ocupa un fotograma en la lista: su cabecera de 8, sus bytes y el relleno a par.
function ccAviChunkBytes(size) { return 8 + size + (size & 1); }

// LA CABECERA (224 bytes). `frames` fotogramas, `maxFrame` = el mayor (bytes), `moviBytes` = la suma de
// `ccAviChunkBytes` de todos. Con frames = 0 y lo demas a 0 es la cabecera provisional.
function ccAviHeader(width, height, fps, frames, maxFrame, moviBytes) {
   var a = new Uint8Array(CC_AVI.HEADER_BYTES), R = ccAviRate(fps), n = frames >>> 0, idx = 8 + 16 * n;
   ccAviPutTag(a, 0, "RIFF"); ccAviPutU32(a, 4, CC_AVI.HEADER_BYTES - 8 + moviBytes + idx); ccAviPutTag(a, 8, "AVI ");
   ccAviPutTag(a, 12, "LIST"); ccAviPutU32(a, 16, 192); ccAviPutTag(a, 20, "hdrl");
   // avih
   ccAviPutTag(a, 24, "avih"); ccAviPutU32(a, 28, 56);
   ccAviPutU32(a, 32, R.usec);                                   // dwMicroSecPerFrame
   ccAviPutU32(a, 36, Math.ceil(maxFrame * R.rate / R.scale));   // dwMaxBytesPerSec
   ccAviPutU32(a, 40, 0);                                        // dwPaddingGranularity
   ccAviPutU32(a, 44, 0x10);                                     // dwFlags: AVIF_HASINDEX
   ccAviPutU32(a, 48, n);                                        // dwTotalFrames
   ccAviPutU32(a, 52, 0);                                        // dwInitialFrames
   ccAviPutU32(a, 56, 1);                                        // dwStreams
   ccAviPutU32(a, 60, maxFrame);                                 // dwSuggestedBufferSize
   ccAviPutU32(a, 64, width); ccAviPutU32(a, 68, height);        // dwWidth, dwHeight (y cuatro reservados a 0)
   // strl
   ccAviPutTag(a, 88, "LIST"); ccAviPutU32(a, 92, 116); ccAviPutTag(a, 96, "strl");
   ccAviPutTag(a, 100, "strh"); ccAviPutU32(a, 104, 56);
   ccAviPutTag(a, 108, "vids"); ccAviPutTag(a, 112, "MJPG");
   ccAviPutU32(a, 116, 0);                                       // dwFlags
   ccAviPutU32(a, 120, 0);                                       // wPriority, wLanguage
   ccAviPutU32(a, 124, 0);                                       // dwInitialFrames
   ccAviPutU32(a, 128, R.scale); ccAviPutU32(a, 132, R.rate);    // dwScale, dwRate
   ccAviPutU32(a, 136, 0);                                       // dwStart
   ccAviPutU32(a, 140, n);                                       // dwLength
   ccAviPutU32(a, 144, maxFrame);                                // dwSuggestedBufferSize
   ccAviPutU32(a, 148, 0xFFFFFFFF);                              // dwQuality: -1 = la de fabrica del codec
   ccAviPutU32(a, 152, 0);                                       // dwSampleSize
   ccAviPutU16(a, 156, 0); ccAviPutU16(a, 158, 0); ccAviPutU16(a, 160, width); ccAviPutU16(a, 162, height);   // rcFrame
   // strf: BITMAPINFOHEADER
   ccAviPutTag(a, 164, "strf"); ccAviPutU32(a, 168, 40);
   ccAviPutU32(a, 172, 40); ccAviPutU32(a, 176, width); ccAviPutU32(a, 180, height);
   ccAviPutU16(a, 184, 1); ccAviPutU16(a, 186, 24);              // biPlanes, biBitCount
   ccAviPutTag(a, 188, "MJPG");                                  // biCompression
   ccAviPutU32(a, 192, width * height * 3);                      // biSizeImage (y cuatro campos a 0)
   // movi
   ccAviPutTag(a, 212, "LIST"); ccAviPutU32(a, 216, 4 + moviBytes); ccAviPutTag(a, 220, "movi");
   return a;
}
// EL INDICE: el trozo 'idx1' entero. `sizes` = los bytes de cada fotograma, por orden.
function ccAviIndex(sizes) {
   var n = sizes.length, a = new Uint8Array(8 + 16 * n), off = 4;
   ccAviPutTag(a, 0, "idx1"); ccAviPutU32(a, 4, 16 * n);
   for (var i = 0; i < n; ++i) {
      var p = 8 + 16 * i;
      ccAviPutTag(a, p, "00dc"); ccAviPutU32(a, p + 4, 0x10);    // AVIIF_KEYFRAME: en MJPEG todos lo son
      ccAviPutU32(a, p + 8, off); ccAviPutU32(a, p + 12, sizes[i]);
      off += ccAviChunkBytes(sizes[i]);
   }
   return a;
}
// Lo que medira el fichero con esos fotogramas.
function ccAviFileBytes(sizes) {
   var movi = 0;
   for (var i = 0; i < sizes.length; ++i) movi += ccAviChunkBytes(sizes[i]);
   return CC_AVI.HEADER_BYTES + movi + 8 + 16 * sizes.length;
}

// ¿CABE? Antes de grabar: con `frames` fotogramas de unos `bytesPerFrame` cada uno.
// Devuelve { ok (cabe en UN fichero), bytes, limit, parts (en cuantos ficheros se parte), framesPerPart,
//            advice: lo que se puede hacer para que quepa en uno ("lower-quality", "lower-resolution") }.
function ccAviPlan(width, height, fps, frames, bytesPerFrame, limit) {
   var L = (limit > 0) ? limit : CC_AVI.LIMIT, per = ccAviChunkBytes(Math.max(1, Math.round(bytesPerFrame))) + 16, n = Math.max(0, Math.round(frames));
   var bytes = CC_AVI.HEADER_BYTES + 8 + per * n, fpp = Math.max(1, Math.floor((L - CC_AVI.HEADER_BYTES - 8) / per)), parts = Math.max(1, Math.ceil(n / fpp));
   return { ok: (parts === 1), bytes: bytes, limit: L, parts: parts, framesPerPart: fpp, advice: (parts === 1) ? [] : ["lower-quality", "lower-resolution"] };
}

// Lo que hay que saber de un fotograma (un `Uint8Array`, o un `ByteArray` de PJSR): cuanto mide y si es un JPEG entero.
function ccAviBlob(blob) {
   var n = blob ? blob.length : 0, f = function(i) { return blob[i] & 255; };   // (20-oct: ByteArray.at() esta obsoleta; el operador [] vale para ByteArray y Uint8Array)
   if (!(n >= 4)) return { length: n, jpeg: false };
   return { length: n, jpeg: (f(0) === 0xFF && f(1) === 0xD8 && f(n - 2) === 0xFF && f(n - 1) === 0xD9) };
}
// El nombre de la parte k (1, 2, 3…) de un video partido: video.avi, video_part2.avi, video_part3.avi…
function ccAviPartPath(path, k) {
   if (k <= 1) return path;
   var dot = path.lastIndexOf("."), slash = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
   return (dot > slash) ? path.substring(0, dot) + "_part" + k + path.substring(dot) : path + "_part" + k;
}

// EL ESCRITOR, sobre una «io» cualquiera (la de PJSR es `ccAviIo`; los tests de node le dan una en memoria):
//   io.create( ruta )            abre el fichero para escribir (lo trunca)
//   io.write( bytes )            añade al final (un Uint8Array, o lo que `io` sepa escribir)
//   io.close()
//   io.patch( ruta, pos, bytes ) vuelve a un fichero ya cerrado y sobrescribe ahi, sin cambiar su tamaño
// Devuelve { add( fotograma ) -> { ok, why }, close() -> { ok, why, frames, bytes, files: [ { path, frames, bytes } ] },
//            abort(), frames(), bytes() }. `opts.limit` = el tope por fichero: al llegar, se cierra esa parte y se
// abre la siguiente sola (`ccAviPartPath`). Un fotograma que no es un JPEG entero NO se escribe (y se dice).
function ccAviWriter(io, path, width, height, fps, opts) {
   var o = opts || {}, limit = (o.limit > 0) ? o.limit : CC_AVI.LIMIT, files = [], cur = null, total = 0, failed = "", closed = false;
   function begin() {
      var p = ccAviPartPath(path, files.length + 1);
      io.create(p);
      io.write(ccAviHeader(width, height, fps, 0, 0, 0));
      cur = { path: p, sizes: [], movi: 0, max: 0 };
   }
   function end() {
      if (cur === null) return;
      var c = cur; cur = null;
      io.write(ccAviIndex(c.sizes));
      io.close();
      io.patch(c.path, 0, ccAviHeader(width, height, fps, c.sizes.length, c.max, c.movi));
      files.push({ path: c.path, frames: c.sizes.length, bytes: CC_AVI.HEADER_BYTES + c.movi + 8 + 16 * c.sizes.length });
   }
   function fail(why) { failed = why; return { ok: false, why: why }; }
   var W = {
      add: function(blob) {
         if (closed) return { ok: false, why: "closed" };
         if (failed) return { ok: false, why: failed };
         var b = ccAviBlob(blob);
         if (!b.jpeg) return { ok: false, why: "not a whole JPEG" };
         try {
            var need = ccAviChunkBytes(b.length) + 16;
            if (cur !== null && cur.sizes.length > 0 && CC_AVI.HEADER_BYTES + cur.movi + 8 + 16 * cur.sizes.length + need > limit) end();
            if (cur === null) begin();
            var head = new Uint8Array(8);
            ccAviPutTag(head, 0, "00dc"); ccAviPutU32(head, 4, b.length);
            io.write(head);
            io.write(blob);
            if (b.length & 1) io.write(new Uint8Array(1));
            cur.sizes.push(b.length); cur.movi += ccAviChunkBytes(b.length);
            if (b.length > cur.max) cur.max = b.length;
            ++total;
         } catch (e) { return fail(String(e)); }
         return { ok: true, why: "" };
      },
      close: function() {
         var out = { ok: false, why: failed, frames: total, bytes: 0, files: files };
         if (closed) { out.why = "closed"; return out; }
         closed = true;
         try { end(); } catch (e) { out.why = String(e); try { io.close(); } catch (e2) {} return out; }
         for (var i = 0; i < files.length; ++i) out.bytes += files[i].bytes;
         if (failed) return out;
         if (total === 0) { out.why = "no frames"; return out; }
         out.ok = true;
         return out;
      },
      abort: function() { closed = true; cur = null; try { io.close(); } catch (e) {} },
      frames: function() { return total; },
      bytes: function() { var n = 0; for (var i = 0; i < files.length; ++i) n += files[i].bytes; return n + ((cur !== null) ? CC_AVI.HEADER_BYTES + cur.movi : 0); }
   };
   return W;
}

// EL VALIDADOR: vuelve a LEER un AVI (sus bytes, en un `Uint8Array`) y comprueba que es coherente consigo mismo.
// No se fia de nada de lo que escribio el escritor: recorre los trozos por su tamaño. Devuelve
//   { ok, why: [ lo que no cuadra ], width, height, fps, frames (los que hay en 'movi'), sizes, offsets (desde 'movi'),
//     declared (los que dice la cabecera), indexed (las entradas del indice), bytes }
// QUE COMPRUEBA: RIFF / 'AVI ' y su tamaño contra el del fichero; las tres cabeceras con sus tamaños; que 'avih',
// 'strh' y 'strf' dicen el mismo ancho, alto y numero de fotogramas; 'vids' / 'MJPG' en los dos sitios; cada trozo
// '00dc' empieza por FF D8 y acaba en FF D9; el relleno a par; y el indice: tantas entradas como fotogramas, cada una
// con el sitio y el tamaño DE VERDAD de su trozo.
function ccAviParse(u8) {
   var out = { ok: false, why: [], width: 0, height: 0, fps: 0, frames: 0, sizes: [], offsets: [], declared: 0, indexed: 0, bytes: u8 ? u8.length : 0 }, n = out.bytes;
   function bad(s) { if (out.why.length < 12) out.why.push(s); }
   if (!(n >= CC_AVI.HEADER_BYTES + 8)) { bad("too short"); return out; }
   if (ccAviGetTag(u8, 0) !== "RIFF" || ccAviGetTag(u8, 8) !== "AVI ") { bad("not a RIFF AVI"); return out; }
   if (ccAviGetU32(u8, 4) !== n - 8) bad("RIFF size " + ccAviGetU32(u8, 4) + " != file size - 8 (" + (n - 8) + ")");
   var pos = 12, avih = -1, strh = -1, strf = -1, movi = -1, moviEnd = -1, idx = -1, idxLen = 0;
   function walk(from, to, depth) {
      var p = from;
      while (p + 8 <= to) {
         var tag = ccAviGetTag(u8, p), sz = ccAviGetU32(u8, p + 4), data = p + 8, next = data + sz + (sz & 1);
         if (data + sz > to) { bad("chunk '" + tag + "' at " + p + " runs past its container"); return; }
         if (tag === "LIST") {
            var type = ccAviGetTag(u8, data);
            if (type === "movi") { movi = data; moviEnd = data + sz; }
            else if (depth < 3) walk(data + 4, data + sz, depth + 1);
         } else if (tag === "avih") { avih = data; if (sz !== 56) bad("avih size " + sz); }
         else if (tag === "strh") { strh = data; if (sz !== 56) bad("strh size " + sz); }
         else if (tag === "strf") { strf = data; if (sz < 40) bad("strf size " + sz); }
         else if (tag === "idx1") { idx = data; idxLen = sz; }
         p = next;
      }
      if (p !== to && p !== to + 1) bad("container ending at " + to + " has " + (to - p) + " loose bytes");
   }
   walk(pos, n, 0);
   if (avih < 0 || strh < 0 || strf < 0) { bad("missing avih / strh / strf"); return out; }
   if (movi < 0) { bad("missing movi"); return out; }
   out.width = ccAviGetU32(u8, avih + 32); out.height = ccAviGetU32(u8, avih + 36); out.declared = ccAviGetU32(u8, avih + 16);
   var scale = ccAviGetU32(u8, strh + 20), rate = ccAviGetU32(u8, strh + 24), usec = ccAviGetU32(u8, avih);
   out.fps = (scale > 0) ? rate / scale : 0;
   if (!(out.fps > 0)) bad("no frame rate");
   else if (Math.abs(usec - 1e6 / out.fps) > 1) bad("avih says " + usec + " us per frame and strh says " + out.fps + " fps");
   if (ccAviGetTag(u8, strh) !== "vids" || ccAviGetTag(u8, strh + 4) !== "MJPG") bad("stream is not vids / MJPG");
   if (ccAviGetTag(u8, strf + 16) !== "MJPG") bad("strf compression is not MJPG");
   if (ccAviGetU32(u8, strf + 4) !== out.width || ccAviGetU32(u8, strf + 8) !== out.height) bad("strf size differs from avih");
   if (ccAviGetU32(u8, strh + 32) !== out.declared) bad("strh length " + ccAviGetU32(u8, strh + 32) + " != avih frames " + out.declared);
   if (!(ccAviGetU32(u8, avih + 12) & 0x10)) bad("avih does not flag the index");
   if (ccAviGetU32(u8, avih + 24) !== 1) bad("not exactly one stream");
   // los fotogramas, uno por uno
   var p = movi + 4, maxSz = 0;
   while (p + 8 <= moviEnd) {
      var tag = ccAviGetTag(u8, p), sz = ccAviGetU32(u8, p + 4), d = p + 8;
      if (d + sz > moviEnd) { bad("frame " + out.frames + " runs past movi"); break; }
      if (tag !== "00dc") bad("chunk '" + tag + "' in movi");
      else {
         if (!(sz >= 4 && u8[d] === 0xFF && u8[d + 1] === 0xD8)) bad("frame " + out.frames + " does not start with FF D8");
         else if (!(u8[d + sz - 2] === 0xFF && u8[d + sz - 1] === 0xD9)) bad("frame " + out.frames + " does not end with FF D9");
         out.offsets.push(p - movi); out.sizes.push(sz); ++out.frames;
         if (sz > maxSz) maxSz = sz;
      }
      p = d + sz + (sz & 1);
   }
   if (p !== moviEnd) bad("movi has " + (moviEnd - p) + " loose bytes at its end");
   if (out.frames !== out.declared) bad(out.frames + " frames in movi, the header says " + out.declared);
   if (ccAviGetU32(u8, avih + 28) < maxSz) bad("suggested buffer smaller than the largest frame");
   // el indice
   if (idx < 0) bad("missing idx1");
   else {
      out.indexed = Math.floor(idxLen / 16);
      if (idxLen % 16 !== 0 || out.indexed !== out.frames) bad("idx1 has " + (idxLen / 16) + " entries for " + out.frames + " frames");
      for (var i = 0; i < out.indexed && i < out.frames; ++i) {
         var e = idx + 16 * i, off = ccAviGetU32(u8, e + 8), esz = ccAviGetU32(u8, e + 12);
         if (ccAviGetTag(u8, e) !== "00dc") { bad("index entry " + i + " is not 00dc"); break; }
         if (off !== out.offsets[i] || esz !== out.sizes[i]) { bad("index entry " + i + " points to " + off + " (" + esz + " bytes); the frame is at " + out.offsets[i] + " (" + out.sizes[i] + " bytes)"); break; }
         if (!(ccAviGetU32(u8, e + 4) & 0x10)) { bad("index entry " + i + " is not a keyframe"); break; }
      }
   }
   out.ok = (out.why.length === 0 && out.frames > 0);
   if (out.frames === 0) bad("no frames");
   return out;
}

// ===========================================================================
// LA PARTE DE PJSR (lo de arriba no toca PixInsight)
// ===========================================================================
// La «io» del escritor sobre `File`. Lo que llegue como `Uint8Array` se pasa a `ByteArray`; un `ByteArray` (lo que
// da `File.readFile` de un JPEG) se escribe tal cual, sin pasar por JavaScript.
function ccAviIo() {
   var f = null;
   function bytes(b) { return (b instanceof Uint8Array) ? new ByteArray(b) : b; }
   return {
      create: function(path) { f = new File; f.createForWriting(path); },
      write: function(b) { f.write(bytes(b)); },
      close: function() { if (f !== null) { var g = f; f = null; g.close(); } },
      patch: function(path, pos, b) {
         var g = new File;
         g.openForReadWrite(path);
         try { g.position = pos; g.write(bytes(b)); } finally { g.close(); }
      }
   };
}
// UN VIDEO, de bitmaps. Devuelve el escritor de `ccAviWriter` con dos cosas mas:
//   addBitmap( bitmap, calidad ) -> { ok, why, bytes }     (85, 92 o 97; el JPEG temporal se borra)
//   addJpegFile( ruta )          -> { ok, why, bytes }
// El bitmap tiene que medir lo que se dijo al abrir. `opts` = { limit, tempDir }.
function ccAviOpen(path, width, height, fps, opts) {
   var o = opts || {}, W = ccAviWriter(ccAviIo(), path, width, height, fps, o);
   var dir = String(o.tempDir || File.systemTempDirectory).split("\\").join("/"), tmp = dir + "/cp_avi_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ".jpg";
   W.addJpegFile = function(file) {
      var b = null;
      try { b = File.readFile(file); } catch (e) { return { ok: false, why: String(e), bytes: 0 }; }
      var r = W.add(b);
      return { ok: r.ok, why: r.why, bytes: b.length };
   };
   W.addBitmap = function(bitmap, quality) {
      if (bitmap.width !== width || bitmap.height !== height) return { ok: false, why: "frame is " + bitmap.width + "x" + bitmap.height + ", the video is " + width + "x" + height, bytes: 0 };
      try { bitmap.save(tmp, (quality > 0) ? quality : 92); } catch (e) { return { ok: false, why: String(e), bytes: 0 }; }
      var r = W.addJpegFile(tmp);
      try { File.remove(tmp); } catch (e2) {}
      return r;
   };
   return W;
}
// VALIDAR UN FICHERO ya escrito (lo lee entero: hasta VALIDATE_MAX). Devuelve lo de `ccAviParse`, mas `skipped`
// si era demasiado grande para leerlo (entonces NO esta validado y se dice).
function ccAviValidateFile(path) {
   var size = -1;
   try { size = (new FileInfo(path)).size; } catch (e) {}
   if (!(size > 0)) return { ok: false, why: ["no such file"], frames: 0, skipped: false, bytes: 0 };
   if (size > CC_AVI.VALIDATE_MAX) return { ok: false, why: ["too large to read back"], frames: 0, skipped: true, bytes: size };
   var r;
   try { r = ccAviParse(File.readFile(path).toUint8Array()); } catch (e2) { return { ok: false, why: [String(e2)], frames: 0, skipped: false, bytes: size }; }
   r.skipped = false;
   return r;
}

// ¿HAY ffmpeg? (3-nov-2026, CPD SC3, regla 5.3) SOLO SI EL USUARIO LO HA ELEGIDO: la decision y la busqueda son de
// CabraShared/csh_ffmpeg.js (cshFfmpegFind), la misma que FieldDepth3D. De fabrica NO se usa ffmpeg y el video sale en AVI
// (Motion JPEG, que este fichero escribe solo); con «MP4 · ffmpeg chosen by me…» se usa el ejecutable que el usuario eligio;
// con «MP4 · find ffmpeg for me», la busqueda de antes (CABRAPILOT_FFMPEG, lo recordado, el PATH, winget). El ajuste es la fila
// «Format» del panel ▾ de II y III (cc_journey_ui.js). Claves: CabraComposition/Video/ffmpegMode, …/ffmpegManual y …/ffmpeg (lo
// ultimo encontrado en «auto»: la misma clave que antes, asi la ruta ya encontrada sigue valiendo). Antes del 3-nov esto era una
// busqueda propia que corria SIEMPRE y lanzaba ffmpeg sin preguntar. Sin csh_ffmpeg.js incluido, como "off".
// No lanza ningun proceso y NUNCA lanza una excepcion. Devuelve { available, path, probe (ffprobe, si esta al lado), from, mode, why }.
// (OJO: ni en un comentario se puede escribir aqui una barra seguida de un asterisco: el preprocesador de PJSR lo toma
// por el principio de un comentario de bloque y el fichero NO COMPILA, sin log. Visto el 13-oct-2026.)
var CC_AVI_FFMPEG_CACHE = null;
// COSTURA PARA PRUEBAS: si se recuerda lo encontrado (en una pasada sin pantalla, no: las pruebas no tocan lo recordado de verdad).
var CC_AVI_REMEMBER = (typeof CC_NO_MAIN === "undefined" || !CC_NO_MAIN);   // CabraComposition: CC_NO_MAIN
function ccAviFfmpegPrefix() { return (typeof CC_SETTINGS === "string") ? CC_SETTINGS : "CabraComposition"; }
function ccAviFfmpeg(refresh) {
   if (CC_AVI_FFMPEG_CACHE !== null && refresh !== true) return CC_AVI_FFMPEG_CACHE;
   var out = { available: false, path: "", probe: "", from: "off", mode: "off", why: "csh_ffmpeg.js not included" };
   try { if (typeof cshFfmpegFind === "function") out = cshFfmpegFind(ccAviFfmpegPrefix(), { remember: CC_AVI_REMEMBER === true }); } catch (e) {}
   CC_AVI_FFMPEG_CACHE = out;
   return out;
}
// Los argumentos de ffmpeg para pasar a MP4 (puro: lo prueba node). `inputs` = lo que va delante (-i …).
//   · H.264 en MP4, `yuv420p` (lo que abre cualquier movil) y `+faststart` (empieza a verse sin bajarlo entero);
//   · EL COLOR: un JPEG lleva matriz BT.601 y rango completo; el video va en BT.709 y rango de video, CONVERTIDO
//     (no solo etiquetado: etiquetar sin convertir cambia los colores) y dicho en el fichero. Con el filtro
//     `colorspace` y SOLO la matriz y el rango (los primarios y la curva ya son los del video): ver CC_AVI.MP4_COLOR;
//   · `opts.encoder` = "libx264" (de fabrica: CRF, el que da la calidad) | "h264_nvenc" (la grafica: mas rapido).
function ccAviMp4Args(inputs, mp4Path, opts) {
   var o = opts || {}, enc = (o.encoder === "h264_nvenc") ? "h264_nvenc" : "libx264", crf = String((o.crf > 0) ? o.crf : CC_AVI.MP4_CRF);
   var a = ["-y", "-hide_banner", "-loglevel", "warning"].concat(inputs);
   a = a.concat(["-vf", CC_AVI.MP4_COLOR, "-an", "-c:v", enc]);
   if (enc === "libx264") a = a.concat(["-preset", String(o.preset || CC_AVI.MP4_PRESET), "-crf", crf]);
   else a = a.concat(["-preset", "p6", "-rc", "vbr", "-cq", crf, "-b:v", "0"]);
   return a.concat(["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv", "-movflags", "+faststart", mp4Path]);
}
// DE AVI A MP4, si hay ffmpeg. `avi` = una ruta o varias (las partes de un video partido: se pegan). Con tope de
// tiempo y lo que el programa haya dicho. `opts` = { crf, preset, encoder, timeoutS, onTick( s ) -> false cancela }.
// Devuelve { ok, why, seconds, bytes, log }.
function ccAviToMp4(avi, mp4Path, opts) {
   var o = opts || {}, ff = ccAviFfmpeg(), out = { ok: false, why: "", seconds: 0, bytes: 0, log: "" };
   if (!ff.available) { out.why = "ffmpeg not available"; return out; }
   var list = (avi instanceof Array) ? avi : [avi], inputs = ["-i", String(list[0])], listFile = "";
   var t0 = Date.now(), limit = 1000 * ((o.timeoutS > 0) ? o.timeoutS : CC_AVI.MP4_TIMEOUT_S), p = null;
   try {
      if (list.length > 1) {
         listFile = File.systemTempDirectory.split("\\").join("/") + "/cp_avi_parts_" + Date.now() + ".txt";
         var text = "";
         for (var i = 0; i < list.length; ++i) text += "file '" + String(list[i]).split("\\").join("/").split("'").join("'\\''") + "'\n";
         File.writeTextFile(listFile, text);
         inputs = ["-f", "concat", "-safe", "0", "-i", listFile];
      }
      p = new ExternalProcess;
      p.onStandardOutputDataAvailable = function() { try { out.log += String(p.stdout); } catch (e) {} };
      p.onStandardErrorDataAvailable = function() { try { out.log += String(p.stderr); } catch (e) {} };
      p.start(ff.path, ccAviMp4Args(inputs, mp4Path, o));
      // [CabraComposition, 24-oct-2026] EL FIN SE MIRA TAMBIEN POR EL ESTADO, no solo por lo que devuelve waitForFinished.
      // MEDIDO (`tests/cc_mp4_hang_probe.log`, M1/M2): si ffmpeg muere mientras `onTick` atiende eventos (el de la interfaz
      // hace processEvents), ese processEvents se come el aviso de «ha terminado» y desde entonces waitForFinished(250)
      // devuelve false AL INSTANTE (isRunning false, exitCode 0): el bucle viejo giraba hasta el tope (900 s) con el MP4 ya
      // escrito entero, y lo daba por «timed out» (T17 X2, baterias 332/1 y 334/1). Rojo: CC_BREAK «mp4lostexit».
      var done = false, lost = (typeof CC_BREAK === "string" && CC_BREAK.indexOf("mp4lostexit") >= 0), tk;
      out.how = ""; out.ticks = 0; out.tickMaxMs = 0;
      while (!done && Date.now() - t0 < limit) {
         done = p.waitForFinished(250);
         if (done) { out.how = "wait"; break; }
         if (!lost) {
            var running = true;
            try { running = (p.isRunning === true || p.isStarting === true); } catch (eR) {}
            if (!running) { done = true; out.how = "state"; break; }
         }
         if (typeof o.onTick === "function") {
            tk = Date.now();
            var go = o.onTick((Date.now() - t0) / 1000);
            ++out.ticks; out.tickMaxMs = Math.max(out.tickMaxMs, Date.now() - tk);
            if (go === false) break;
         }
      }
      out.seconds = (Date.now() - t0) / 1000;
      // («CabraStars:» A3, F1: matar es asincrono; sin esperar, ffmpeg seguia escribiendo el .mp4 y no se podia borrar —medido: quedaba
      // el fichero tras cancelar—)
      if (!done) { try { p.kill(); } catch (eK) {} try { p.waitForFinished(5000); } catch (eW) {} out.why = (Date.now() - t0 >= limit) ? "timed out" : "cancelled"; }
      else if (p.exitCode !== 0) out.why = "ffmpeg exit code " + p.exitCode;
      else {
         try { out.bytes = (new FileInfo(mp4Path)).size; } catch (eB) {}
         out.ok = (out.bytes > 0);
         if (!out.ok) out.why = "ffmpeg wrote nothing";
      }
   } catch (e2) { out.why = String(e2); }
   try { if (listFile.length > 0) File.remove(listFile); } catch (e3) {}
   if (out.log.length > 4000) out.log = out.log.substring(out.log.length - 4000);
   return out;
}
#endif
