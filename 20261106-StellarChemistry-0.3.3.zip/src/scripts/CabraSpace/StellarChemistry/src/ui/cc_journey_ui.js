#ifndef __CC_JOURNEY_UI_JS
#define __CC_JOURNEY_UI_JS
// ============================================================================
// src/ui/cc_journey_ui.js — II · VIAJE Y VÍDEO: LOS MANDOS del cuerpo del grupo (CabraComposition, 22-oct-2026, fase 2a)
// ----------------------------------------------------------------------------
// PROCEDENCIA: ADAPTACIÓN de CabraStars/lib/cs_flight_ui.js (commit 1413273; a su vez de Cabra3D starfield_flight_ui.js):
//   [ La historia del campo ▾ ]  [▶ Vista previa]  [● Grabar] [▾]
//   · «● Grabar» GRABA YA con lo recordado (un paso); «▾» abre lo mínimo: Tamaño [1080p · 16:9 ▾] [30 fps ▾] · Título · Guardar en […];
//   · la VISTA PREVIA a tiempo real, en la COLUMNA DEL MEDIO (D.colBox: la de los diagramas y del mapa de III), que LLENA
//     (23-oct, petición de Nino; antes iba en la foto); un clic en ella o «■ Parar» la paran y vuelven los diagramas (o el mapa).
//     La foto no se toca. La grabación se ve ahí también, encajada con la proporción del vídeo y con su barra;
//   · GRABAR por tics de un Timer (la interfaz sigue viva), con la barra de progreso DENTRO del panel; «■ Cancelar» PREGUNTA
//     en una fila del grupo (quedarse con lo grabado / borrarla / seguir), sin cuadro modal; MP4 si hay ffmpeg, AVI si no;
//     hoja de contacto al lado; cerrar la ventana (CC_ABORT / D.closing) cancela y BORRA;
//   · lo elegido (modo, tamaño, ritmo, carpeta) se recuerda en Settings `CabraComposition/Journey/…` (no en pruebas).
// LO QUE CAMBIA: no hay «Duración» ni «Mi vuelo» (los dos modos tienen su guion: 2a 30 s; 2c según las paradas); la
// vista previa va en la foto (no hay lienzo 3D); el estado del análisis se COPIA al empezar (lo que pase en el diálogo
// durante la grabación no cambia el vídeo).
//
// INTERFAZ PARA EL INTEGRADOR (cc_dialog.js, gancho D.mountJourney(body)):
//   var J = ccJourneyBuild(body, D);      // crea los mandos DENTRO de `body` (un Control; si no tiene sizer, se le pone uno
//                                         // vertical) y deja D.journey = J. Devuelve J.
//   Lo que ESPERA de D:  D.S (el estado: S.res, S.list, S.photo, S.opts, S.dView, S.viewId) · D.colBox con su sizer y D.panelB/C/D
//     (la columna: la vista previa pone ahí su lienzo y los esconde mientras dura; sin columna, la foto D.panelA, como antes) · opcionales: D.say(text, frac, busy, error, right) (la barra de estado),
//     D.closing, D.busy (analizando), D.currentView() / D.currentViewId() (título y carpeta de fábrica), y los botones que
//     se apagan mientras se graba si existen: analyseBtn, viewList, imgRefreshBtn, langBtn, retryBtn, toViewBtn, toFileBtn,
//     exportBtn, refreshBtn, split1, split2.
//   Lo que el integrador LLAMA:
//     J.sync()          al acabar un análisis, al cambiar de imagen y al abrir el grupo (habilita / explica los mandos)
//     J.retranslate()   en D.retranslate (EN/ES)
//     J.buttons()       los botones a ajustar con ccFitButton en D.fitButtons (ya se ajustan solos al cambiar de texto)
//     J.busy()          true con vista previa o grabación (p. ej. para no analizar entonces)
//     J.end()           en D.release / D.requestClose / D.onClose: para la vista previa y CANCELA la grabación (la borra)
//     J.cleanup()       = J.end() + para su Timer y repone el panel de la foto
//   Para pruebas: J.previewStart(), J.stop(), J.recordStart(opts), J.cancelAnswer("keep" | "delete" | "continue"),
//     J.tick() (un tic del Timer a mano), J.last (lo último: { what, result }), CC_JOURNEY_HOOK("dir", sugerida) → carpeta.
// DOS SITIOS, UN MOTOR (29-oct-2026, Nino: «la parte de Viaje y Vídeo de La Galaxia en el tiempo debe moverse a la parte III - La Galaxia
// e integrarse ahí, ya que es su sitio natural»): ccJourneyBuild(body, D, cfg) monta los mandos de UN grupo con los modos de cfg.modes.
//   II  · ccJourneyMount(D, body)  → cfg vacío: modos CC_JOURNEY.FIELD_MODES (historia, recorrido), Settings `…/Journey/…`, D.journey.
//   III · ccGalaxyMount (cc_galaxy_ui.js) → { modes: ["orbits"], key: "GalaxyVideo", slot: "gxVideo", labelKey: "jGxVideo", … }:
//         sin desplegable (un solo vídeo) y, con cfg.row, sus botones al final de la fila «Tiempo» de III (sin fila propia: el mapa de
//         la columna no pierde alto; ver C.row abajo), Settings `…/GalaxyVideo/…` (tamaño, ritmo y carpeta, cada uno con su
//         última carpeta; la primera vez hereda los de `…/Journey/…`, donde vivían cuando el vídeo era de II), D.gxVideo.
//   Los dos son la MISMA máquina (vista previa en la columna del medio, grabadora, pregunta al cancelar, barra dentro del panel): el
//   vídeo grabado desde III es el de antes fotograma a fotograma. Nunca dos vídeos a la vez: empezar uno para la vista previa del otro
//   y, mientras el otro graba, este explica por qué no (jBusyOther). cfg.onClock(mode, st) y cfg.onEnd(what, T) son los ganchos de la
//   regla «Tiempo» de III (UNA línea de tiempo para mirar y para grabar); J.seek(t) / J.seekRelease() mueven la vista previa desde fuera.
// NADA se calcula en `onPaint`: el panel copia un bitmap hecho. ES5.
// ============================================================================

var CC_JUI = { PREVIEW_TICK_S: 0.016, RECORD_TICK_S: 0.002, SHOW_EVERY_MS: 90, BAR: 4, OUTSIDE: 0.5 };
// (26-oct) la manecilla que se arrastra: el radio que se puede tocar (fracción de R) y el imán de «hoy» (±1,8°: el de Cabra3D, C3_CLKD)
var CC_JDRAG = { HIT_R: 0.97, SNAP_DEG: 1.8 };
// EL HALO de la manecilla agarrada o bajo el ratón, encima del fotograma copiado (no lo rehace): un anillo fino en el borde de la esfera y la
// manecilla otra vez sobre un halo de oro claro que ACABA EN EL POMO (HL1 de Cabra3D). Copia adaptada de CPStarfieldDock._clkdPaintHot
// (Cabra3D/src/tm/timeclock_panel.js). G = J.dragGeo() (la esfera en coordenadas del lienzo de la columna).
function ccJDragPaintHot(g, G, drag) {
   var A = (typeof CSH_ATLAS !== "undefined") ? CSH_ATLAS : CC_ATLAS, st = G.st, R = G.R, lw = Math.max(1, 0.011 * R), cx = G.cx, cy = G.cy, i, ox = G.ox, oy = G.oy;
   g.antialiasing = true;
   cshClockNoBrush(g);
   g.pen = new Pen(cshClockInt(A.goldLight, drag ? 0.75 : 0.5), Math.max(1.2, 1.4 * lw)); g.drawCircle(cx, cy, R * 0.985);
   function soft(c, w) { try { if (typeof PenCap_Round !== "undefined" && typeof PenJoin_Round !== "undefined") return new Pen(c, w, PenStyle_Solid, PenCap_Round, PenJoin_Round); } catch (eP) {} return new Pen(c, w); }
   var glowA = soft(cshClockInt(A.goldLight, drag ? 0.30 : 0.22), Math.max(5, 7 * lw)), glowB = soft(cshClockInt(A.goldLight, drag ? 0.6 : 0.45), Math.max(2.5, 3.2 * lw));
   var hotI = cshClockInt(drag ? (A.text || A.goldLight) : A.goldLight);
   function mv(p) { return { x: p.x + ox, y: p.y + oy }; }
   if (st.handAt) {
      var HA = st.handAt, PV = CSH_CLOCK.V[G.variant] || {}, faceI = (PV.face === "surface") ? cshClockInt(A.surface || A.bg) : cshClockInt(A.bg), pass, pen;
      var pom = null, dMax = -1;
      for (i = 0; i < HA.circles.length; ++i) if (HA.circles[i].fill === "gold") { var dd = Math.sqrt(Math.pow(HA.circles[i].x + ox - cx, 2) + Math.pow(HA.circles[i].y + oy - cy, 2)); if (dd > dMax) { dMax = dd; pom = HA.circles[i]; } }
      for (pass = 0; pass < 2; ++pass) {
         pen = pass ? glowB : glowA;
         if (pom) { g.pen = pen; g.drawLine(cx, cy, pom.x + ox, pom.y + oy); }
         else for (i = 0; i < HA.polys.length; ++i) if (HA.polys[i].fill === "gold") cshPocketPolyline(g, HA.polys[i].pts.map(mv), pen, true);
         for (i = 0; i < HA.circles.length; ++i) if (HA.circles[i].fill === "gold") g.strokeCircle(HA.circles[i].x + ox, HA.circles[i].y + oy, HA.circles[i].r, pen);
      }
      for (i = 0; i < HA.polys.length; ++i) cshPocketFillPoly(g, HA.polys[i].pts.map(mv), HA.polys[i].fill === "gold" ? hotI : faceI);
      for (i = 0; i < HA.circles.length; ++i) g.fillCircle(HA.circles[i].x + ox, HA.circles[i].y + oy, HA.circles[i].r, new Brush(HA.circles[i].fill === "gold" ? hotI : faceI));
   } else if (st.tip) { var tp = mv(st.tip); g.pen = glowA; g.drawLine(cx, cy, tp.x, tp.y); g.pen = glowB; g.drawLine(cx, cy, tp.x, tp.y); g.pen = new Pen(hotI, Math.max(1.5, 1.6 * lw)); g.drawLine(cx, cy, tp.x, tp.y); }
   g.fillCircle(cx, cy, 0.05 * R, new Brush(cshClockInt(A.gold)));
   g.fillCircle(cx, cy, 0.019 * R, new Brush(cshClockInt(A.bg)));
}
var CC_JOURNEY_HOOK = null;                  // pruebas: ( "dir", sugerida ) -> carpeta, en vez del cuadro de elegir carpeta
var CC_JOURNEY_SAVE_HOOK = null;             // pruebas: ( ruta sugerida con extension ) -> ruta | null, en vez del cuadro de guardar (6-nov-2026)
var CC_JOURNEY_CANCEL_ASKS = true;
var CC_JOURNEY_CLOCK = function() { return Date.now(); };

function ccJNoMain() { return (typeof CC_NO_MAIN !== "undefined" && CC_NO_MAIN) ? true : false; }
// (29-oct) `grp` = la carpeta de Settings del grupo: "Journey" (II, la de siempre) o "GalaxyVideo" (III)
function ccJReadAt(grp, key, type, fallback) {
   if (ccJNoMain()) return fallback;
   try { var v = Settings.read(CC_SETTINGS + "/" + grp + "/" + key, type); if (v !== null && v !== undefined && Settings.lastReadOK !== false) return v; } catch (e) {}
   return fallback;
}
function ccJWriteAt(grp, key, type, value) { if (ccJNoMain()) return; try { Settings.write(CC_SETTINGS + "/" + grp + "/" + key, type, value); } catch (e) {} }
function ccJRead(key, type, fallback) { return ccJReadAt("Journey", key, type, fallback); }
function ccJWrite(key, type, value) { ccJWriteAt("Journey", key, type, value); }

// El título de fábrica de un vídeo: el nombre del FICHERO de la imagen (sin extensión, «_» como espacio): el id de la vista suele
// ser «MasterLight» o «Image01» (captura del 22-oct). Sin fichero, "" (y entonces el id de la vista).
function ccJourneyTitleOf(view) {
   try {
      var p = (view && !view.isNull) ? String(view.window.filePath || "") : "";
      if (p.length > 0) { var b = File.extractName(p); if (b && b.length) return String(b).replace(/_+/g, " ").replace(/^\s+|\s+$/g, ""); }
   } catch (e) {}
   return "";
}
// (3-nov-2026, CPD SC3) los modos de ffmpeg (los de csh_ffmpeg.js; sin él incluido, solo AVI) y lo que se dice del formato en el tooltip de «Grabar»
function ccJFfModes() { return (typeof CSH_FFMPEG_MODES !== "undefined" && CSH_FFMPEG_MODES.length) ? CSH_FFMPEG_MODES : ["off"]; }
function ccJFfSay(ff) {
   if (ff && ff.available) return ccJT("jFmtMp4") + " ffmpeg: " + ff.path;
   if (!ff || ff.mode === "off") return ccJT("jFmtAviOff");
   return ccJT("jFmtAviNotFound") + (ff.why ? " (" + ff.why + ")" : "");
}
function ccJourneyBuild(body, D, cfg) {
   var J = { D: D, body: body, building: true, strip: false, optShown: false, askShown: false, preview: null, rec: null, last: null, title: "", show: null, panelHooked: false, locked: null };
   var C = J.cfg = cfg || {};
   // los modos de ESTE grupo (II: historia y recorrido; III: la Galaxia en el tiempo). ROJO «jorbitsinII»: II ofrece aún los tres, como antes del 29-oct
   J.modes = (C.modes && C.modes.length) ? C.modes.slice() : (ccJBroken("jorbitsinII") ? CC_JOURNEY.MODES.slice() : CC_JOURNEY.FIELD_MODES.slice());
   J.grp = C.key || "Journey"; J.slot = C.slot || "journey";
   // lo recordado: el del grupo; si no lo hay, el de II (donde vivía el vídeo de la Galaxia hasta el 29-oct). El modo, solo con desplegable.
   J.read = function(key, type, fb) { var v = ccJReadAt(J.grp, key, type, null); if (v === null && J.grp !== "Journey") v = ccJReadAt("Journey", key, type, null); return (v === null) ? fb : v; };
   J.write = function(key, type, v) { ccJWriteAt(J.grp, key, type, v); };
   J.mode = ccJourneyPickMode((J.modes.length > 1) ? String(ccJReadAt(J.grp, "mode", DataType_UCString, J.modes[0])) : J.modes[0], J.modes);
   J.size = Math.max(0, Math.min(CC_JV.SIZES.length - 1, Number(J.read("size", DataType_Int32, 0)) || 0));
   J.fps = (Number(J.read("fps", DataType_Int32, 30)) === 60) ? 60 : 30;
   J.dir = String(J.read("dir", DataType_UCString, "") || "");
   if (!body.sizer) { var vs = new VerticalSizer; vs.margin = 0; vs.spacing = 0; body.sizer = vs; }
   var BS = body.sizer, A = CC_ATLAS, i;
   // (23-oct, revisor R13: «Título» y «Guardar en» salían con la trama de puntos del estilo nativo y sin borde derecho: el mismo arreglo
   //  que los botones —background-image / border-image a none— y un ancho mínimo pequeño, para que el sizer no los saque de su panel)
   var cssField = "QLineEdit, QWidget { background-color:" + CC_INSET + "; color:" + A.text + "; border:1px solid " + A.line + "; border-radius:" + ccPxs(6) + "; padding:" + ccPxs(2) + " " + ccPxs(6) + "; background-image:none; border-image:none; }";
   var cssPanel = "QWidget { background-color:" + A.surface + "; } QLabel { background:transparent; color:" + A.text2 + "; }";
   function label(parent, wLogical) { var l = new Label(parent); ccStyle(l, ccCssBarLabel()); if (wLogical) ccFixSize(l, wLogical, 0); return l; }
   function rowOf(items, indent) {
      var r = new HorizontalSizer; r.margin = 0; r.spacing = 0;
      if (indent !== false) r.addSpacing(ccPx(CC_UI.INDENT));
      for (var q = 0; q < items.length; ++q) { if (typeof items[q] === "number") r.addSpacing(ccPx(items[q])); else r.add(items[q]); }
      r.addStretch();
      return r;
   }
   // --- la fila de los mandos ---
   // (29-oct) con UN solo modo (III) no hay desplegable que elegir: un rótulo «Vídeo» del ancho de los de III (Vista, Mostrar, Color, Tiempo)
   // (29-oct, T17 X5: la fila «Vídeo» propia le quitaba 46 px lógicos al mapa —541 → 495— y el rótulo de una estrella lejana de M 67 ya no
   //  cabía) C.row: una fila YA montada (la de «Tiempo» de III) donde van ▶ ● ▾ al final; entonces ni rótulo ni fila ni sus huecos
   var inRow = !!(C.row && J.modes.length === 1), gap = function(n) { return inRow ? 0 : n; };
   J.modeCombo = null; J.modeLabel = null; J.inRow = inRow;
   if (J.modes.length > 1) {
      J.modeCombo = new ComboBox(body);
      try { J.modeCombo.setMinWidth(ccPx(170)); } catch (eMW) {}
      J.modeCombo.onItemSelected = function(index) { if (!J.building) J.setMode(J.modes[index]); };
   } else if (!inRow) J.modeLabel = label(body, C.labelW || 82);
   J.playBtn = ccToggleButton(body, "", "", function() { J.previewToggle(); });
   J.recBtn = ccToggleButton(body, "", "", function() { J.recordButton(); });
   J.optBtn = ccToggleButton(body, "▾", "", function() { J.optionsToggle(); });
   if (inRow) { C.row.addSpacing(ccPx(10)); C.row.add(J.playBtn); C.row.addSpacing(ccPx(6)); C.row.add(J.recBtn); C.row.addSpacing(ccPx(4)); C.row.add(J.optBtn); C.row.addSpacing(ccPx(10)); }
   else {
      if (!body.ccWip) BS.addSpacing(ccPx(6));       // (en el diálogo, el cuerpo ya trae 14 px de arriba: los del rótulo «en construcción»)
      BS.add(J.modeCombo ? rowOf([J.modeCombo, 8, J.playBtn, 8, J.recBtn, 4, J.optBtn]) : rowOf([J.modeLabel, J.playBtn, 6, J.recBtn, 4, J.optBtn]));
      BS.addSpacing(ccPx(4));
   }
   // --- las opciones de grabar (▾): tamaño y ritmo, título, carpeta ---
   var Pn = J.optPanel = new Control(body);
   ccStyle(Pn, cssPanel);
   J.sizeLabel = label(Pn, 70); J.sizeCombo = new ComboBox(Pn);
   for (i = 0; i < CC_JV.SIZES.length; ++i) J.sizeCombo.addItem(CC_JV.SIZES[i].text);
   J.sizeCombo.currentItem = J.size;
   J.sizeCombo.onItemSelected = function(index) { if (J.building) return; J.size = index; J.write("size", DataType_Int32, index); J.sync(); };
   J.fpsCombo = new ComboBox(Pn);
   for (i = 0; i < CC_JV.FPS.length; ++i) J.fpsCombo.addItem(CC_JV.FPS[i] + " fps");
   J.fpsCombo.currentItem = Math.max(0, CC_JV.FPS.indexOf(J.fps));
   J.fpsCombo.onItemSelected = function(index) { if (J.building) return; J.fps = CC_JV.FPS[index]; J.write("fps", DataType_Int32, J.fps); J.sync(); };
   J.titleLabel = label(Pn, 70); J.titleEdit = new Edit(Pn); ccStyle(J.titleEdit, cssField); try { J.titleEdit.setMinWidth(ccPx(60)); } catch (eT0) {}
   J.titleEdit.onEditCompleted = function() { var tt = String(J.titleEdit.text); J.title = (tt === J.defaultTitle()) ? "" : tt; };
   J.dirLabel = label(Pn, 70); J.dirEdit = new Edit(Pn); ccStyle(J.dirEdit, cssField); try { J.dirEdit.setMinWidth(ccPx(60)); } catch (eD0) {}
   J.dirEdit.onEditCompleted = function() { J.dir = String(J.dirEdit.text).split("\\").join("/"); };
   J.browseBtn = ccToggleButton(Pn, "…", "", function() { J.browse(); });
   // (3-nov-2026, CPD SC3) EL FORMATO: AVI (de fábrica, sin programas externos) o MP4 con ffmpeg, SOLO si el usuario lo elige: con el ejecutable
   // que él elige («…», que solo se ve en ese modo) o dejando que el programa lo busque. La lógica es la común (CabraShared/csh_ffmpeg.js) y
   // el ajuste es UNO para el script (II y III lo comparten: <CC_SETTINGS>/Video/ffmpegMode). Como la fila «Formato» de FieldDepth3D.
   J.fmtLabel = label(Pn, 70); J.fmtCombo = new ComboBox(Pn);
   J.fmtCombo.onItemSelected = function(index) { if (!J.building) J.setFfmpegMode(ccJFfModes()[index]); };
   J.ffPickBtn = ccToggleButton(Pn, "…", "", function() { J.pickFfmpeg(); });
   function line(a, b, c, d) { var s = new HorizontalSizer; s.margin = 0; s.spacing = 0; s.add(a); s.addSpacing(ccPx(4)); s.add(b, 100); if (c) { s.addSpacing(ccPx(4)); s.add(c); } if (d) { s.addSpacing(ccPx(4)); s.add(d); } return s; }
   Pn.sizer = new VerticalSizer; Pn.sizer.margin = ccPx(6); Pn.sizer.spacing = ccPx(4);
   Pn.sizer.add(line(J.sizeLabel, J.sizeCombo, J.fpsCombo)); Pn.sizer.add(line(J.titleLabel, J.titleEdit)); Pn.sizer.add(line(J.dirLabel, J.dirEdit, J.browseBtn));
   Pn.sizer.add(line(J.fmtLabel, J.fmtCombo, J.ffPickBtn));
   var pr = new HorizontalSizer; pr.margin = 0; pr.spacing = 0; pr.addSpacing(ccPx(CC_UI.INDENT)); pr.add(Pn, 100); pr.addSpacing(ccPx(8));
   BS.add(pr); BS.addSpacing(ccPx(gap(4)));
   Pn.hide();
   // --- la pregunta al cancelar una grabación (una fila; la grabación se PAUSA mientras se decide) ---
   var Ak = J.askPanel = new Control(body);
   ccStyle(Ak, cssPanel);
   J.askText = label(Ak);
   J.askKeep = ccToggleButton(Ak, "", "", function() { J.cancelAnswer("keep"); });
   J.askDel = ccToggleButton(Ak, "", "", function() { J.cancelAnswer("delete"); });
   J.askCont = ccToggleButton(Ak, "", "", function() { J.cancelAnswer("continue"); });
   Ak.sizer = new HorizontalSizer; Ak.sizer.margin = ccPx(6); Ak.sizer.spacing = ccPx(6);
   Ak.sizer.add(J.askText); Ak.sizer.add(J.askKeep); Ak.sizer.add(J.askDel); Ak.sizer.add(J.askCont); Ak.sizer.addStretch();
   var ar = new HorizontalSizer; ar.margin = 0; ar.spacing = 0; ar.addSpacing(ccPx(CC_UI.INDENT)); ar.add(Ak, 100); ar.addSpacing(ccPx(8));
   BS.add(ar); BS.addSpacing(ccPx(gap(2)));
   Ak.hide();
   // --- una línea de ayuda (lo largo, en los tooltips) ---
   J.hint = label(body);
   try { J.hint.wordWrapping = true; } catch (eWW) {}
   // (29-oct, captura de III: con rowOf la ayuda se partía a ~230 px y ocupaba cuatro líneas con media fila vacía a su derecha: ahora se estira)
   var hr = new HorizontalSizer; hr.margin = 0; hr.spacing = 0; hr.addSpacing(ccPx(CC_UI.INDENT)); hr.add(J.hint, 100); hr.addSpacing(ccPx(14));
   BS.add(hr); BS.addSpacing(ccPx(gap(6)));
   BS.addStretch();          // (si el cuerpo es más alto que lo suyo, sobra abajo: las filas de opciones y de la pregunta no se estiran)
   // --- UN tic para las dos cosas (nunca a la vez): la vista previa y la grabación ---
   J.timer = new Timer; J.timer.periodic = true; J.timer.interval = CC_JUI.PREVIEW_TICK_S;
   J.timer.onTimeout = function() { J.tick(); };

   // ======================= lo que hace =======================
   J.say = function(text, frac, busy, error) { J.saidText = String(text); if (typeof D.say === "function") { try { D.say(text, frac || 0, !!busy, !!error, ""); } catch (e) {} } };
   J.model = function() { return (D.S && D.S.res) ? ccJourneyModel(D.S) : null; };
   J.busy = function() { return J.preview !== null || J.rec !== null; };
   J.modeName = function(m) { return ccJT(m === "tour" ? "jModeTour" : (m === "orbits" ? "jModeOrbits" : "jModeHistory")); };
   J.defaultTitle = function() {
      var v = null;
      try { v = (typeof D.currentView === "function") ? D.currentView() : null; } catch (e) {}
      var t = ccJourneyTitleOf(v);
      if (t) return t;
      try { t = String((D.S && D.S.viewId) || (typeof D.currentViewId === "function" ? D.currentViewId() : "") || ""); } catch (e2) {}
      return t || CC_APP_NAME;
   };
   J.defaultDir = function() {
      if (J.dir.length > 0 && File.directoryExists(J.dir)) return J.dir;
      try {
         var v = (typeof D.currentView === "function") ? D.currentView() : null, p = (v && !v.isNull) ? String(v.window.filePath || "") : "";
         if (p.length > 0) { var d = (File.extractDrive(p) + File.extractDirectory(p)).split("\\").join("/"); if (File.directoryExists(d)) return d; }
      } catch (e) {}
      var home = String(File.homeDirectory).split("\\").join("/"), names = ["Videos", "Movies"];
      for (var q = 0; q < names.length; ++q) if (File.directoryExists(home + "/" + names[q])) return home + "/" + names[q];
      return home;
   };
   // (29-oct) el otro grupo con vídeo (II <-> III): nunca dos a la vez
   J.other = function() { var o = (J.slot === "journey") ? D.gxVideo : D.journey; return (o && o !== J) ? o : null; };
   J.otherRec = function() { var o = J.other(); return !!(o && o.rec !== null); };
   J.syncOther = function() { var o = J.other(); if (o) { try { o.sync(); } catch (e) {} } };
   J.whyNot = function() {
      if (D.busy) return "jBusy";
      if (J.otherRec()) return "jBusyOther";
      return ccJourneyWhyNot(J.model(), J.mode);
   };
   J.fit = function() { var b = J.buttons(); for (var q = 0; q < b.length; ++q) ccFitButton(b[q]); };
   J.buttons = function() { return [J.playBtn, J.recBtn, J.optBtn, J.browseBtn, J.ffPickBtn, J.askKeep, J.askDel, J.askCont]; };
   J.names = function() {
      if (!J.modeCombo) { if (J.modeLabel) J.modeLabel.text = ccJT(C.labelKey || "jGxVideo"); return; }
      var was = J.building; J.building = true;
      try { while (J.modeCombo.numberOfItems > 0) J.modeCombo.removeItem(J.modeCombo.numberOfItems - 1); } catch (e) {}
      for (var q = 0; q < J.modes.length; ++q) J.modeCombo.addItem(J.modeName(J.modes[q]));
      J.modeCombo.currentItem = Math.max(0, J.modes.indexOf(J.mode));
      J.building = was;
   };
   J.sync = function() {
      var prev = (J.preview !== null), rec = (J.rec !== null), idle = !prev && !rec, why = J.whyNot(), can = (why === ""), M = J.model();
      J.building = true;
      try {
         if (J.modeCombo) J.modeCombo.currentItem = Math.max(0, J.modes.indexOf(J.mode));
         if (J.strip) {
            J.titleEdit.text = (J.title.length > 0) ? J.title : J.defaultTitle();
            J.dirEdit.text = J.dir.length ? J.dir : J.defaultDir();
            J.sizeCombo.currentItem = J.size; J.fpsCombo.currentItem = Math.max(0, CC_JV.FPS.indexOf(J.fps));
         }
      } finally { J.building = false; }
      J.playBtn.text = prev ? ("■ " + ccJT("jStop")) : ("▶ " + ccJT("jPreview"));
      J.recBtn.text = rec ? ("■ " + ccJT("jCancel")) : ("● " + ccJT("jRecord"));
      ccSetToggle(J.playBtn, prev); ccSetToggle(J.recBtn, rec); ccSetToggle(J.optBtn, J.strip);
      try {
         if (J.modeCombo) J.modeCombo.enabled = idle;
         J.playBtn.enabled = !rec && (prev || can);
         J.recBtn.enabled = !prev && (rec || can);
         J.optBtn.enabled = idle;
      } catch (e) {}
      J.optShown = !!(J.strip && idle);
      if (J.optShown) J.optPanel.show(); else J.optPanel.hide();
      if (!(J.rec && J.rec.ask)) { J.askPanel.hide(); J.askShown = false; }
      J.sizeLabel.text = ccJT("jSize"); J.titleLabel.text = ccJT("jTitle"); J.dirLabel.text = ccJT("jSaveTo"); J.fmtLabel.text = ccJT("jFmt");
      J.fmtSync();
      var hint;
      if (!can) hint = ccJT(why);
      else if (J.mode === "tour") { var sh = []; for (var q = 0; q < M.stops.length; ++q) sh.push(ccJT("jRoleShort_" + M.stops[q].roles[0])); hint = ccJT("jHintTour", sh.join(" · ")); }
      else if (J.mode === "orbits") { var gu = J.gxOpts(); hint = ccJT("jHintOrbits", ccThou(M.nKin, ccJLang()), ccGxT(gu.mode === "edge" ? "gxEdge" : (gu.mode === "3d" ? "gx3d" : "gxTop")), ccGxT(gu.color === "age" ? "gxAge" : (gu.color === "feh" ? "gxFeh" : "gxPop"))); }
      else hint = ccJT("jHintHistory");
      if (J.hint.text !== hint) J.hint.text = hint;
      // (29-oct) cfg.hintWhyOnly (III): la línea de ayuda solo cuando hay un porqué (sin órbitas, analizando, otro vídeo grabando); lo demás
      //  ya está a la vista en los mandos de arriba y en el tooltip: así el cuerpo de III no le quita alto al mapa
      if (C.hintWhyOnly) { if (can && !ccJBroken("gxhintalways")) J.hint.hide(); else J.hint.show(); }
      J.tips();
      J.fit();
   };
   J.tips = function() {
      var sz = CC_JV.SIZES[J.size], ff = ccAviFfmpeg(), wrap = (typeof ccWrapTip === "function") ? ccWrapTip : function(t) { return t; };
      if (J.modeCombo || J.modeLabel) { (J.modeCombo || J.modeLabel).toolTip = wrap(ccJT(C.modeTip || "jModeTip")); J.playBtn.toolTip = wrap(ccJT(C.previewTip || "jPreviewTip")); }
      else J.playBtn.toolTip = wrap(ccJT(C.modeTip || "jModeTip") + "\n\n" + ccJT(C.previewTip || "jPreviewTip"));      // (sin rótulo: qué vídeo es, en ▶)
      J.recBtn.toolTip = wrap(ccJT(C.recordTip || "jRecordTip", sz.text, J.fps, J.dir || J.defaultDir()) + " " + ccJFfSay(ff) + " " + ccJT("jSheetNote"));
      J.optBtn.toolTip = wrap(ccJT("jOptTip"));
      J.sizeCombo.toolTip = wrap(ccJT("jSizeTip")); J.fpsCombo.toolTip = wrap(ccJT("jFpsTip"));
      J.titleEdit.toolTip = wrap(ccJT("jTitleTip"));
      J.dirEdit.toolTip = J.browseBtn.toolTip = wrap(ccJT("jDirTip") + "\n" + (J.dir || J.defaultDir()));
   };
   J.retranslate = function() { J.names(); J.fmtNames(); J.askText.text = ccJT("jAskStop"); J.askDel.text = ccJT("jAskDelete"); J.askCont.text = ccJT("jAskContinue"); J.sync(); };
   J.setMode = function(m) {
      if (J.modes.indexOf(m) < 0 || J.busy()) return;
      J.mode = m; if (J.modes.length > 1) J.write("mode", DataType_UCString, m); J.sync();
   };
   // (6-nov-2026) la ruta del video: el cuadro de guardar (con pantalla) o la propuesta (sin ella). `suggested` sin extension. -> ruta | null (cancelado)
   J.askSavePath = function(suggested, fmt) {
      var mp4 = (fmt !== "avi") && ccAviFfmpeg().available, ext = mp4 ? ".mp4" : ".avi";
      if (typeof CC_JOURNEY_SAVE_HOOK === "function") { var h = CC_JOURNEY_SAVE_HOOK(suggested + ext); return (h === null || h === undefined || String(h).length === 0) ? null : String(h).split("\\").join("/"); }
      if (typeof cshInteractive === "function" && !cshInteractive()) return suggested + ext;
      var sfd = new SaveFileDialog;
      sfd.caption = CC_APP_NAME + " — " + ccJT("jSaveCaption");
      sfd.overwritePrompt = true;
      sfd.filters = mp4 ? [["MP4", "*.mp4"]] : [["AVI", "*.avi"]];
      try { sfd.initialPath = suggested + ext; } catch (e) {}
      if (!sfd.execute()) return null;
      var f = String(sfd.fileName || "").split("\\").join("/");
      return f.length > 0 ? f : null;
   };
   J.optionsToggle = function() { if (J.busy()) return; J.strip = !J.strip; J.sync(); };
   J.browse = function() {
      var dir = null;
      if (typeof CC_JOURNEY_HOOK === "function") dir = CC_JOURNEY_HOOK("dir", J.dir);
      else {
         var gdd = new GetDirectoryDialog;
         gdd.caption = CC_APP_NAME + " — " + ccJT("jFolderCaption");
         try { gdd.initialPath = J.dir || J.defaultDir(); } catch (e) {}
         dir = gdd.execute() ? String(gdd.directoryPath) : null;
      }
      if (dir === null || String(dir).length === 0) return false;
      J.dir = String(dir).split("\\").join("/");
      // (OJO, medido el 23-oct: el preprocesador de PJSR no expande una macro que va DETRÁS de una cadena con barra invertida doble en
      //  la misma línea —cree que la cadena sigue—: «DataType_UCString is not defined». La macro, en su propia línea.)
      J.write("dir", DataType_UCString, J.dir);
      J.sync();
      return true;
   };
   // ---------------------------------------------------------------------------------------------------------------------------------
   // (3-nov-2026, CPD SC3) EL FORMATO DEL VÍDEO Y ffmpeg (CabraShared/csh_ffmpeg.js; la misma lógica que la fila «Formato» de FieldDepth3D,
   // Cabra3D/src/ui/starfield_flight_ui.js). Tres estados: «AVI (no ffmpeg)» (de fábrica), «MP4 · ffmpeg chosen by me…» (el ejecutable que
   // se elige con «…»; si aún no hay ninguno, el selector se abre al elegir la opción; cancelado, se queda el modo de antes) y «MP4 · find
   // ffmpeg for me» (la búsqueda de antes). Se recuerda (<CC_SETTINGS>/Video/ffmpegMode y …/ffmpegManual), uno para II y III.
   J.fmtNames = function() {
      var was = J.building; J.building = true;
      try {
         while (J.fmtCombo.numberOfItems > 0) J.fmtCombo.removeItem(J.fmtCombo.numberOfItems - 1);
         var M = ccJFfModes();
         for (var q = 0; q < M.length; ++q) J.fmtCombo.addItem(ccJT("jFf_" + M[q]));
      } catch (e) {}
      J.building = was;
      J.fmtSync();
   };
   // lo que se ve del formato: la opción guardada, «…» SOLO con «chosen by me» (activo si no se graba), y los tooltips con la ruta o el porqué
   J.fmtSync = function(ff) {
      ff = ff || ccAviFfmpeg();
      var was = J.building; J.building = true;
      try { J.fmtCombo.currentItem = Math.max(0, ccJFfModes().indexOf(ff.mode || "off")); } catch (e) {}
      J.building = was;
      var manual = (ff.mode === "manual");
      try { if (manual) J.ffPickBtn.show(); else J.ffPickBtn.hide(); J.ffPickBtn.enabled = manual && J.rec === null && J.preview === null; J.fmtCombo.enabled = (J.rec === null && J.preview === null); } catch (e2) {}
      var wrap = (typeof ccWrapTip === "function") ? ccWrapTip : function(t) { return t; };
      var where = ff.available ? ("\nffmpeg: " + ff.path) : ((ff.mode !== "off" && ff.why) ? "\n" + ff.why : "");
      try { J.fmtCombo.toolTip = wrap(ccJT("jFmtTip") + where); } catch (e3) {}
      try { J.ffPickBtn.toolTip = wrap(ccJT("jFfPickTip") + ((manual && ff.path) ? "\n" + ff.path : "")); } catch (e4) {}
   };
   // elegir el modo (desde el desplegable). -> { ok, mode, ff, why }
   J.setFfmpegMode = function(mode) {
      if (typeof cshFfmpegSetMode !== "function" || ccJFfModes().indexOf(mode) < 0) return { ok: false, why: "csh_ffmpeg.js not included" };
      var pre = ccAviFfmpegPrefix(), before = cshFfmpegMode(pre);
      if (mode === "manual") {
         var cur = cshFfmpegManualPath(pre), has = false;
         try { has = cur.length > 0 && File.exists(cur); } catch (eE) {}
         if (!has) {
            var p = cshFfmpegPick(pre, cur);
            if (p === null) { J.fmtSync(ccAviFfmpeg(true)); return { ok: false, mode: before, why: "cancelled" }; }
            cshFfmpegSetManualPath(pre, p);
         }
      }
      cshFfmpegSetMode(pre, mode);
      var ff = ccAviFfmpeg(true);
      J.sync(); J.syncOther();
      J.say(ccJFfSay(ff), 0, false, !(ff.available || mode === "off"));
      return { ok: true, mode: ff.mode, ff: ff };
   };
   // el «…»: elegir (o cambiar) el ejecutable de ffmpeg; deja el modo en «chosen by me»
   J.pickFfmpeg = function() {
      if (typeof cshFfmpegPick !== "function") return { ok: false, why: "csh_ffmpeg.js not included" };
      var pre = ccAviFfmpegPrefix(), p = cshFfmpegPick(pre, cshFfmpegManualPath(pre));
      if (p === null) return { ok: false, why: "cancelled" };
      cshFfmpegSetManualPath(pre, p);
      return J.setFfmpegMode("manual");
   };
   J.fmtNames();

   // --- LA COLUMNA DEL MEDIO, prestada mientras hay vista previa o grabación ---
   // (23-oct, Nino: «al previsualizar aparece en la zona de la imagen 2D. Debe aparecer en la zona del medio, como con todos los otros
   //  scripts». Como CabraStars tras su D4 —el vuelo en el panel del HR, que LLENA; nunca en la foto—: la vista previa se pinta en un
   //  lienzo propio dentro de la columna de los diagramas (D.colBox, donde va también el mapa de III), que ocupa entera; B, C, D y el
   //  mapa se esconden mientras dura y vuelven al parar —el mapa si III sigue abierto; si no, B/C/D—. La FOTO NO SE TOCA (ni su onPaint
   //  ni su ratón: un clic en ella elige estrellas como siempre). La vista previa LLENA la columna (el fotograma se compone para la forma
   //  de la columna, alta: la maqueta 9:16 de cc_journey_paint.js); la grabación sigue a su tamaño y se ve ENCAJADA en la columna.
   //  ROJO «jonphoto»: como antes, en la foto. ROJO «jnorestore»: al parar, la columna no vuelve.)
   J.colTaken = false; J.colCanvas = null; J.onPhoto = false; J.hidden = [];
   J.makeColCanvas = function() {
      if (J.colCanvas) return J.colCanvas;
      var col = (D.colBox && D.colBox.sizer) ? D.colBox : null;
      if (!col) return null;
      var c = new Control(col);
      // (ARRIBA de la columna: en la historia y el recorrido la vista previa va encima de B/C/D, que siguen a la vista)
      // (sin estirar —0—: con 100, el sizer le quitaba 7 px a su alto fijo y B la pisaba por abajo: medido en T17 X1, visto en la captura)
      try { col.sizer.insert(0, c, 0); } catch (eI) { col.sizer.add(c, 0); }
      c.hide();
      try { c.mouseTracking = true; } catch (eMT) {}            // (26-oct: la manecilla del reloj se resalta al pasar)
      c.onPaint = function() {
         var self = this;
         ccPaintGuarded(self, function() {                       // (26-oct: con el pintado abierto nadie bombea eventos; cc_paint.js)
            var g = new Graphics(self);
            try {
               if (J.show) g.drawBitmap(0, 0, J.show); else g.fillRect(0, 0, self.width, self.height, new Brush(ccInt(CC_INSET)));
               if (J.show && (J.dragHot || J.drag)) { var geo = J.dragGeo(); if (geo) { try { ccJDragPaintHot(g, geo, !!J.drag); } catch (eH) {} } }
            } finally { g.end(); }
         });
         J.colPaints = (J.colPaints || 0) + 1;
      };
      // (26-oct) pulsar en la esfera del reloj agarra la manecilla (J.dragPress); en cualquier otro sitio, como siempre: para la vista previa
      c.onMousePress = function(x, y, button) { if (!J.dragPress(x, y, button)) J.stop(); };
      c.onMouseMove = function(x, y, buttons) { J.dragMove(x, y, buttons); };
      c.onMouseRelease = function(x, y, button) { J.dragRelease(x, y); };
      c.onLeave = function() { if (!J.drag) J.dragSetHot(false); };
      J.colCanvas = c;
      return c;
   };
   J.target = function() { return J.onPhoto ? D.panelA : J.colCanvas; };
   J.hookPanel = function() {
      if (J.panelHooked) return;
      var c = ccJBroken("jonphoto") ? null : J.makeColCanvas();
      if (!c) {
         // (el rojo, o sin columna: el camino de antes, en la foto)
         var P = D.panelA;
         if (!P) return;
         J.onPhoto = true;
         J.savedPaint = P.onPaint; J.savedPress = P.onMousePress;
         P.onPaint = function(x0, y0, x1, y1) {
            if (J.show) { var g = new Graphics(this); try { g.drawBitmap(0, 0, J.show); } finally { g.end(); } return; }
            if (J.savedPaint) J.savedPaint.call(this, x0, y0, x1, y1);
         };
         P.onMousePress = function() { J.stop(); };
      } else {
         // (23-oct, opción (a) de Nino) DOS MAQUETAS de la columna:
         //   «top»  (la historia, el recorrido): la vista previa ARRIBA, con la proporción de la foto, y B/C/D DEBAJO a su tamaño de siempre
         //          (mínimo PLOT_MIN), a la vista y siguiendo el reloj del vídeo (encienden las nacidas, C con su frente del tiempo);
         //   «full» (la Galaxia en el tiempo, y cualquier grabación): la vista previa llena la columna; B/C/D no se ven (el mapa necesita el
         //          alto; ese vídeo no lleva diagramas). En los dos, la línea de tiempo E, bajo la foto, a la vista con su cursor.
         J.onPhoto = false; J.hidden = [];
         var lay = J.colLayout = J.layoutFor(), Q = [D.panelB, D.panelC, D.panelD], GXc = (D.galaxy && D.galaxy.canvas && D.galaxy.inColumn) ? D.galaxy.canvas : null;
         if (GXc) { try { J.hidden.push(GXc); GXc.hide(); } catch (eG) {} }
         for (var q = 0; q < Q.length; ++q) if (Q[q]) { try { if (lay === "full") { J.hidden.push(Q[q]); Q[q].hide(); } else Q[q].show(); } catch (eH) {} }
         J.colTaken = true;
         J.fixColCanvas();
         try { c.show(); } catch (eS) {}
      }
      J.panelHooked = true;
      J.cover(true);
   };
   // (23-oct, revisor R15: con la vista previa se veían DOS juegos de B/C/D y dos E —los del vídeo y los del diálogo—. Ahora B/C/D y el mapa
   //  ya no se ven —la vista previa ocupa su sitio— y la línea de tiempo E, bajo la foto, enseña una nota mientras el vídeo lleve la suya
   //  (la historia y el recorrido; «La Galaxia en el tiempo» no lleva línea de tiempo): ccPaintVideoCover. ROJO «dupanels»)
   // (23-oct, opción (a) de Nino: la línea de tiempo E ya NO se tapa: sigue a la vista con el cursor en el instante del vídeo —D.setClock—.
   //  Solo el camino de la foto —el rojo «jonphoto»— y el rojo «dupanels» la tapan como antes)
   J.cover = function(on) {
      D.videoCovered = !!on && (J.onPhoto || ccJBroken("dupanels"));
      var P = [D.panelB, D.panelC, D.panelD, D.timeline, (D.galaxy && D.galaxy.canvas) ? D.galaxy.canvas : null];
      for (var q = 0; q < P.length; ++q) if (P[q]) { try { P[q].stale = true; P[q].update(); } catch (eC) {} }
   };
   J.unhookPanel = function() {
      J.show = null;
      if (!J.panelHooked) return;
      if (typeof CC_BREAK === "string" && CC_BREAK.indexOf("jnorestore") >= 0) return;     // (el rojo de la sonda: la columna —o la foto— no vuelve)
      if (J.onPhoto) {
         var P = D.panelA;
         P.onPaint = J.savedPaint; P.onMousePress = J.savedPress;
         try { P.stale = true; P.update(); } catch (e) {}
      } else {
         try { J.colCanvas.hide(); } catch (eC) {}
         J.colTaken = false;
         // lo que tenga que estar: el mapa si III está abierto (aunque se abriera durante la vista previa); si no, B/C/D
         var GX = D.galaxy, gxOpen = !!(GX && GX.open && GX.inColumn && GX.canvas);
         var B3 = [D.panelB, D.panelC, D.panelD];
         for (var q = 0; q < B3.length; ++q) if (B3[q]) { try { if (gxOpen) B3[q].hide(); else B3[q].show(); } catch (eB) {} }
         if (GX && GX.canvas && GX.inColumn) { try { if (gxOpen) { GX.canvas.show(); GX.update(); } else GX.canvas.hide(); } catch (eG) {} }
         J.hidden = [];
      }
      J.panelHooked = false; J.onPhoto = false; J.colLayout = "";
      J.cover(false);
      J.pushClock(null, null);
   };
   // el instante del vídeo, al diálogo (D.setClock): la línea de tiempo con su cursor, B/C/D con las nacidas (ROJO «jnoclock»: no se dice)
   J.pushClock = function(mode, st) {
      // (29-oct) la regla «Tiempo» de III sigue el reloj del vídeo (cfg.onClock; null = suelta): UNA línea de tiempo para mirar y grabar
      if (typeof C.onClock === "function") { try { C.onClock(mode, st || null); } catch (eOC) {} }
      if (typeof D.setClock !== "function" || ccJBroken("jnoclock")) return;
      var c = null;
      if (st) {
         if (mode === "history" && ccIsNum(st.T)) c = { T: st.T };
         else if (mode === "orbits" && st.R && st.R.clock && ccIsNum(st.R.clock.T)) c = { T: st.R.clock.T / 1000 };
         else if (mode === "tour") c = { visit: (ccIsNum(st.stopIdx) && st.stopIdx >= 0) ? st.stopIdx : null };
      }
      try { D.setClock("video", c); } catch (e) {}
      J.lastClock = c;
   };
   // la maqueta de la columna para lo que se enseña ahora (ver hookPanel)
   J.layoutFor = function() {
      if (J.rec || ccJBroken("jpreviewfull")) return "full";
      var m = J.preview ? J.preview.mode : J.mode;
      // (3-nov, S4c a de Nino) la historia también a columna entera: en la franja «top» la foto quedaba al 38 % del ancho.
      // Costura «jhistorytop»: la franja de antes.
      if (m === "orbits" || (m === "history" && !ccJBroken("jhistorytop"))) return "full";
      return (J.topHeight() >= ccPx(120)) ? "top" : "full";
   };
   // el alto de la vista previa «top»: el ancho de la columna con la proporción de la foto, sin dejar a B/C/D por debajo de PLOT_MIN
   J.topHeight = function() {
      var cw = 0, ch = 0, a = 1.5;
      try { cw = D.colBox.width; ch = D.colBox.height; } catch (e) {}
      try { var F = (D.S.res && D.S.res.field) ? D.S.res.field : (D.S.frame || null); if (F && F.width > 0 && F.height > 0) a = F.width / F.height; } catch (eF) {}
      var gap = ccPx(6), minP = (typeof D.minOf === "function") ? D.minOf((typeof CC_UI !== "undefined") ? CC_UI.PLOT_MIN : 110) : ccPx(110);
      // (con un margen: si los mínimos suman justo el alto de la columna, Qt aprieta el lienzo y B lo pisa —T17 X1, 894 = 372 + 3 × 165 + 3 × 9—)
      var hp = Math.min(Math.round(cw / Math.max(0.3, a)), ch - 3 * minP - 3 * gap - ccPx(12));
      return Math.max(0, hp - (hp % 2));
   };
   J.fixColCanvas = function() {
      var c = J.colCanvas;
      if (!c) return;
      if (J.colLayout === "top") { J.topH = J.topHeight(); try { c.setFixedHeight(J.topH); } catch (e) {} }
      else { J.topH = 0; var hh = 0; try { hh = D.colBox.height; } catch (eH) {} try { c.setFixedHeight(Math.max(ccPx(60), hh)); } catch (e2) {} }
   };
   // el tamaño del sitio donde se pinta: la parte de arriba de la columna («top»), la columna entera («full»), o la foto (el rojo)
   J.panelSize = function() {
      var w = 0, h = 0;
      try {
         if (J.onPhoto || !D.colBox) { w = D.panelA.width; h = D.panelA.height; }
         else if (J.colTaken && J.colLayout === "top") { w = D.colBox.width; h = J.topH; }
         else { w = D.colBox.width; h = D.colBox.height; }
      } catch (e) {}
      return { w: w, h: h };
   };
   // el cuadro del fotograma: la vista previa LLENA (como CabraStars D4); la grabación, encajada con su proporción
   J.previewRect = function(ps, aspect) {
      if (J.onPhoto || ccJBroken("jonphoto")) return J.fitRect(ps.w, ps.h, aspect);
      var rw = ps.w - (ps.w % 2), rh = ps.h - (ps.h % 2);
      return { x: 0, y: 0, w: Math.max(2, rw), h: Math.max(2, rh) };
   };
   J.fitRect = function(w, h, aspect) {
      var rw = w, rh = Math.round(w / aspect);
      if (rh > h) { rh = h; rw = Math.round(h * aspect); }
      rw -= rw % 2; rh -= rh % 2;
      return { x: Math.floor((w - rw) / 2), y: Math.floor((h - rh) / 2), w: Math.max(2, rw), h: Math.max(2, rh) };
   };
   // el buffer del panel: lo de fuera del cuadro del vídeo, oscurecido; el cuadro, con un filete
   J.panelBuf = function(w, h) { if (!J.buf || J.buf.width !== w || J.buf.height !== h) J.buf = new Bitmap(w, h); return J.buf; };
   J.compose = function(buf, r, frame, bar, text) {
      var g = new Graphics(buf), sc = ccScale();
      try {
         g.fillRect(new Rect(0, 0, buf.width, buf.height), new Brush(ccInt(CC_INSET)));
         g.smoothInterpolation = true;
         if (frame.width === r.w && frame.height === r.h) g.drawBitmap(r.x, r.y, frame);
         else g.drawScaledBitmap(new Rect(r.x, r.y, r.x + r.w, r.y + r.h), frame);
         g.pen = new Pen(ccInt(CC_ATLAS.line, 0.9), 1); g.brush = new Brush(0x00000000); g.drawRect(r.x, r.y, r.x + r.w - 1, r.y + r.h - 1);
         if (bar !== null && bar !== undefined) {
            var bh = Math.max(2, Math.round(CC_JUI.BAR * sc)), w = buf.width, h = buf.height;
            g.fillRect(new Rect(0, h - bh, w, h), new Brush(ccInt(CC_ATLAS.line)));
            g.fillRect(new Rect(0, h - bh, Math.round(w * bar), h), new Brush(ccInt(CC_ATLAS.gold)));
            if (text) {
               var f = ccFont("text", 9 * sc), pad = Math.round(6 * sc), tw = f.width(text), ty = h - bh - pad;
               g.fillRect(new Rect(pad, ty - f.ascent - pad / 2, pad + tw + pad, ty + f.descent + pad / 2), new Brush(ccInt(CC_ATLAS.bg, 0.85)));
               g.font = f; g.pen = new Pen(ccInt(CC_ATLAS.text)); g.drawText(pad + pad / 2, ty, text);
            }
         }
      } finally { g.end(); }
      J.show = buf;
      var T = J.target();
      if (T) { try { T.repaint(); } catch (e) { try { T.update(); } catch (e2) {} } }
   };
   // (integración, 22-oct) la copia lleva también el elemento de IV (S.elem), la elegida y, para «Órbitas», las opciones de vista y color de III
   J.gxOpts = function() { return (typeof ccGalaxyVideoOpts === "function") ? ccGalaxyVideoOpts(D.galaxy || null, {}) : { mode: "3d", color: "pop" }; };
   J.snapshot = function() {
      var S = D.S, o = S.opts || {};
      return { res: S.res, list: (S.list || []).slice(), photo: S.photo, opts: { sizeByAge: !!o.sizeByAge, contours: o.contours !== false, errors: false, backdrop: o.backdrop !== false },
               dView: S.dView, viewId: S.viewId || "", frame: S.frame || null, elem: S.elem || "Fe", sel: ccIsNum(S.sel) ? S.sel : -1, gx: J.gxOpts() };
   };
   // EL PINTOR de un fotograma del modo `mode` (una sola grabadora para los tres: ccJourneyRecorder): 2a y 2c, ccJourneyFrame;
   // «Órbitas», el fotograma del vídeo de III (ccGalaxyVideo) con el modelo de III (el mismo resultado: se reutiliza si ya está hecho)
   // preview = true (23-oct, opción (a)): la vista previa del diálogo pinta SOLO la parte principal —la foto con su reloj y su placa, o el
   // mapa con los suyos— con la letra del diálogo (ccScale: legible a 387 lógicos de ancho); la grabación, el fotograma entero (preview falso).
   // ROJO «jpreviewfull»: la vista previa con la maqueta entera y la letra del vídeo (los diagramas diminutos de antes).
   // (la foto: 0,84 de la escala del diálogo —la letra más pequeña de su placa, 8,6 × 1,26 = 11 px, 7,3 lógicos—; con más, la placa tapaba media
   //  foto; el mapa: la escala entera —su letra más pequeña es 7,6—)
   J.previewScale = function(mode) { return (mode === "orbits") ? ccScale() : 0.84 * ccScale(); };
   J.frameFnFor = function(snap, mode, title, preview) {
      var pv = !!preview && !ccJBroken("jpreviewfull");
      if (mode === "orbits" && !ccJBroken("jorbitsfn")) {        // (ROJO «jorbitsfn» de T17: «Órbitas» pintado con el pintor de 2a)
         var G = null;
         try { if (D.galaxy && typeof D.galaxy.model === "function") { var G0 = D.galaxy.model(); if (G0 && G0.res === snap.res) G = G0; } } catch (eG) {}
         if (!G) G = ccGalaxyModel(snap.res, snap.list);
         var vo = {}, gx = snap.gx || {};
         for (var k in gx) if (gx.hasOwnProperty(k)) vo[k] = gx[k];
         vo.sel = snap.sel; vo.title = title; vo.tUnit = "s";
         if (pv) vo.uiScale = J.previewScale("orbits");
         var V = ccGalaxyVideo(G, vo);
         return function(g, w, h, t) { var R = V.frameFn(g, w, h, t); return { ok: true, mode: "orbits", t: t, nStars: R ? R.nStars : 0, nOrbits: R ? R.nOrbits : 0, R: R }; };
      }
      if (pv) return function(g, w, h, t) { return ccJourneyFrame(g, w, h, snap, J.previewScale(mode), mode, t, { title: title, main: true }); };
      return function(g, w, h, t) { return ccJourneyFrame(g, w, h, snap, ccJourneyScale(w, h), mode, t, { title: title }); };
   };

   // --- ▶ LA VISTA PREVIA ---
   J.previewToggle = function() { if (J.preview !== null) { J.stop(); return false; } return J.previewStart(); };
   J.previewStart = function() {
      if (J.busy()) return false;
      var oth = J.other(); if (oth && oth.preview !== null) { try { oth.stop(); } catch (eOS) {} }      // (29-oct: la del otro grupo se para)
      var why = J.whyNot();
      if (why) { J.say(ccJT(why), 0, false, false); return false; }
      var ps = J.panelSize();
      if (!(ps.w > 32 && ps.h > 32)) return false;
      var sz = CC_JV.SIZES[J.size], snap = J.snapshot(), M = ccJourneyModel(snap), dur = ccJourneyDuration(M, J.mode);
      try { if (D.galaxy && typeof D.galaxy.stop === "function") D.galaxy.stop(); } catch (eGS) {}
      J.preview = { S: snap, mode: J.mode, r: null, w: ps.w, h: ps.h, dur: dur, t0: CC_JOURNEY_CLOCK(), frames: 0, frame: null, title: J.title || J.defaultTitle(), lastStats: null, aspect: sz.w / sz.h };
      J.preview.fn = J.frameFnFor(snap, J.mode, J.preview.title, true);
      J.hookPanel();
      ps = J.panelSize();                     // (ya con la columna tomada —o la foto, en el rojo—)
      J.preview.w = ps.w; J.preview.h = ps.h; J.preview.r = J.previewRect(ps, sz.w / sz.h); J.preview.frame = new Bitmap(J.preview.r.w, J.preview.r.h);
      J.sync();
      J.previewFrame(0);
      J.timer.interval = CC_JUI.PREVIEW_TICK_S;
      try { J.timer.start(); } catch (e) {}
      J.say(ccJT("jPreviewing", J.modeName(J.mode), Math.round(dur)), 1, false, false);
      return true;
   };
   J.previewFrame = function(t) {
      var pv = J.preview, g = new Graphics(pv.frame);
      try { g.antialiasing = true; g.fillRect(0, 0, pv.r.w, pv.r.h, new Brush(ccInt(CC_ATLAS.bg))); pv.lastStats = pv.fn(g, pv.r.w, pv.r.h, t); } finally { g.end(); }
      J.pushClock(pv.mode, pv.lastStats);
      ++pv.frames;
      J.compose(J.panelBuf(pv.w, pv.h), pv.r, pv.frame, null, "");
   };

   // --- LA MANECILLA SE ARRASTRA (26-oct-2026, propagado de Cabra3D/src/tm/timeclock_panel.js «LA MANECILLA SE ARRASTRA») ---
   // En CabraComposition el reloj analógico del PANEL en vivo es el de la VISTA PREVIA (la columna del medio): «La historia del campo» (II) y
   // «La Galaxia en el tiempo» (III desde el 29-oct; allí la regla «Tiempo» sigue también a la manecilla) (el mapa de III en vivo NO lleva reloj analógico: su instante lo dicen la regla y la placa de texto —cc_galaxy_ui.js
   // GX.ruler, cc_galaxy_paint.js R.timePlate—; el «Gran recorrido» no lleva reloj: va de parada en parada).
   //   · Pasar por la esfera: cursor de mano, halo de oro en la manecilla que acaba en el pomo (ccJDragPaintHot, copia adaptada de _clkdPaintHot)
   //     y el tooltip «jDragTip». Pulsar en la esfera: la manecilla salta a ese ángulo y, sin soltar, lo sigue (cshClockPointerDeg →
   //     cshClockYearsAt, CabraShared/csh_clock.js; acotado al arco); cerca de «hoy» (±1,8°) se pega a «hoy».
   //   · El instante → el segundo de la vista previa con las inversas que ya tenía cada reloj: ccJourneyHistoryTimeAt (cc_journey.js) y
   //     ccGxtTimeAt (cc_galaxy_time.js). Agarrar PARA el reloj de la vista previa (pv.held: los tics no la mueven); cada movimiento pinta el
   //     fotograma de ese instante (no hay dibujo «ligero» en estos pintores: el fotograma entero, como cada tic) y avisa al diálogo (la línea de
   //     tiempo y B/C/D siguen); soltar la deja seguir DESDE AHÍ (pv.t0 se corre). Diferencia con Cabra3D, a propósito: allí soltar deja la máquina
   //     en pausa porque tiene su botón ▶; la vista previa no tiene pausa (un clic fuera del reloj la PARA, como siempre).
   // Rojos (CC_BREAK): «jdragoff» = sin interacción · «jdragnohold» = agarrar no para el reloj · «jdragwrap» = el ángulo en [0, 360) a mano
   // (a la izquierda de «hoy» salta al Big Bang) · «jdragsnap» = sin el imán de «hoy».
   J.drag = null; J.dragHot = false;
   J.dragGeo = function() {
      var pv = J.preview;
      if (!pv || !pv.lastStats || !pv.r) return null;
      var st = (pv.mode === "orbits") ? (pv.lastStats.R ? pv.lastStats.R.clockDial : null) : ((pv.mode === "history") ? pv.lastStats.clock : null);
      if (!st || !st.pivot || !(st.R > 0)) return null;
      return { st: st, ox: pv.r.x, oy: pv.r.y, cx: pv.r.x + st.pivot.x, cy: pv.r.y + st.pivot.y, R: st.R, mode: pv.mode, variant: st.variant || ccJourneyDialVariant() };
   };
   J.dragCan = function() { return J.preview !== null && J.rec === null && !J.onPhoto && ccJourneyDialOn() && !ccJBroken("jdragoff"); };
   J.dragHit = function(x, y) {
      if (!J.dragCan()) return null;
      var G = J.dragGeo();
      if (!G) return null;
      var dx = x - G.cx, dy = y - G.cy, r = CC_JDRAG.HIT_R * G.R;
      return (dx * dx + dy * dy <= r * r) ? G : null;
   };
   // el instante bajo el ratón, en Ga atrás (0 = hoy)
   J.dragGaAt = function(G, x, y) {
      var S = ccJourneyDialScale(), U = ccJUniverse(), deg = cshClockPointerDeg(G.cx, G.cy, x, y);
      if (deg === null) return null;
      var Ga;
      if (ccJBroken("jdragwrap")) { var sp = CSH_CLOCK.V[G.variant].span, d3 = (deg < 0) ? deg + 360 : deg; Ga = U * (1 - Math.max(0, Math.min(1, (d3 + sp / 2) / sp))); }
      else { var yrs = cshClockYearsAt(S, deg, G.variant); if (yrs === null) return null; Ga = Math.max(0, Math.min(U, -yrs / 1e9)); }
      var dToday = deg - cshClockAngle(S, 0, G.variant);
      dToday -= 360 * Math.round(dToday / 360);
      if (!ccJBroken("jdragsnap") && Math.abs(dToday) <= CC_JDRAG.SNAP_DEG) Ga = 0;
      return Ga;
   };
   // Ga atrás → el segundo de la vista previa (las inversas de cada reloj)
   J.dragTimeOf = function(mode, Ga) {
      if (mode === "orbits") return ccGxtTimeAt(Ga * 1000);
      return ccJourneyHistoryTimeAt(Ga, J.preview ? J.preview.dur : 0);
   };
   J.dragTo = function(x, y) {
      var pv = J.preview, G = J.dragGeo(), d = J.drag;
      if (!pv || !G || !d) return;
      var Ga = J.dragGaAt(G, x, y);
      if (Ga === null) return;
      var t = Math.max(0, Math.min(pv.dur, J.dragTimeOf(pv.mode, Ga))), t0 = Date.now();
      d.lastGa = Ga; d.lastT = t; d.x = x; d.y = y;
      if (pv.tHeld === t && d.moves > 0) return;
      pv.tHeld = t;
      J.previewFrame(t);
      ++d.moves; d.ms.push(Date.now() - t0); if (d.ms.length > 400) d.ms.shift();
      var T = J.target(); if (T) { try { T.repaint(); } catch (e) { try { T.update(); } catch (e2) {} } }
   };
   J.dragCursor = function(kind) {
      var T = J.target();
      if (!T || J.dragCur === kind) return;
      J.dragCur = kind;
      try { T.cursor = new Cursor(kind === "drag" ? StdCursor_ClosedHand : (kind === "hot" ? StdCursor_PointingHand : StdCursor_Arrow)); } catch (e) {}
   };
   J.dragSetHot = function(on) {
      var T = J.target();
      if (J.dragHot === on) return;
      J.dragHot = on;
      J.dragCursor(on ? "hot" : "");
      if (T) { try { T.toolTip = on ? ((typeof ccWrapTip === "function") ? ccWrapTip(ccJT("jDragTip")) : ccJT("jDragTip")) : ""; } catch (eT) {} try { T.update(); } catch (eU) {} }
   };
   // true si la pulsación era en la esfera (la manecilla queda agarrada)
   J.dragPress = function(x, y, button) {
      var left = (typeof MouseButton_Left !== "undefined") ? MouseButton_Left : 1;
      if (button !== undefined && button !== left) return false;
      var G = J.dragHit(x, y), pv = J.preview;
      if (!G || !pv) return false;
      pv.held = true; pv.tHeld = null;
      J.drag = { x: x, y: y, moves: 0, ms: [], pressAt: Date.now(), lastGa: null, lastT: null };
      J.dragHot = true;
      J.dragCursor("drag");
      J.dragTo(x, y);                                       // (pulsar en la esfera: salta ahí)
      return true;
   };
   J.dragMove = function(x, y, buttons) {
      if (J.drag) { if (buttons) J.dragTo(x, y); else J.dragRelease(x, y); return; }   // (sin botón: se soltó fuera sin que llegara el «soltar»)
      J.dragSetHot(!buttons && !!J.dragHit(x, y));
   };
   J.dragRelease = function(x, y) {
      var d = J.drag, pv = J.preview;
      if (!d) return;
      J.drag = null;
      J.lastDrag = { moves: d.moves, ms: d.ms.slice(), Ga: d.lastGa, t: d.lastT };
      if (pv) {
         if (ccIsNum(pv.tHeld)) pv.t0 = CC_JOURNEY_CLOCK() - pv.tHeld * 1000;      // (sigue DESDE el instante elegido)
         pv.held = false;
      }
      var hot = (x !== undefined) && !!J.dragHit(x, y);
      J.dragHot = !hot;                                      // (para que dragSetHot repinte y ponga el cursor)
      J.dragSetHot(hot);
   };
   // (29-oct) MOVER LA VISTA PREVIA DESDE FUERA (la regla «Tiempo» de III): agarrarla en el segundo t (el reloj no corre mientras) y soltarla
   // (sigue desde ahí), como la manecilla. false si no hay vista previa (o se graba: entonces no se mueve nada).
   J.seek = function(t) {
      var pv = J.preview;
      if (!pv || J.rec !== null) return false;
      t = Math.max(0, Math.min(pv.dur, ccIsNum(t) ? t : 0));
      pv.held = true;
      if (pv.tHeld === t) return true;
      pv.tHeld = t;
      J.previewFrame(t);
      return true;
   };
   J.seekRelease = function() {
      var pv = J.preview;
      if (!pv) return false;
      if (ccIsNum(pv.tHeld)) pv.t0 = CC_JOURNEY_CLOCK() - pv.tHeld * 1000;
      pv.held = false;
      return true;
   };
   // PARAR lo que haya: la vista previa; o la grabación, PREGUNTANDO. true si había algo.
   J.stop = function() {
      if (J.rec !== null && J.rec.encoding) { J.rec.encodeCancel = true; J.say(ccJT("jEncodingCancel"), 0, true, false); return true; }
      if (J.rec !== null) {
         if (CC_JOURNEY_CANCEL_ASKS !== true) { J.recordEnd(true); return true; }
         if (J.rec.ask) J.cancelAnswer("continue"); else J.cancelAsk();
         return true;
      }
      var pv = J.preview;
      if (pv === null) return false;
      if (J.drag || J.dragHot) { J.drag = null; J.dragHot = false; J.dragCursor(""); try { if (J.target()) J.target().toolTip = ""; } catch (eTT) {} }
      J.preview = null;
      try { J.timer.stop(); } catch (e) {}
      J.last = { what: "preview", frames: pv.frames, ms: CC_JOURNEY_CLOCK() - pv.t0, stats: pv.lastStats };
      var endT = (pv.lastStats && pv.lastStats.R && pv.lastStats.R.clock && ccIsNum(pv.lastStats.R.clock.T)) ? pv.lastStats.R.clock.T : null;      // (Ma atrás: «orbits»)
      try { pv.frame.clear(); } catch (e2) {}
      J.unhookPanel();
      J.sync();
      if (typeof C.onEnd === "function") { try { C.onEnd("preview", endT); } catch (eOE) {} }      // (III: el mapa se queda en ese instante)
      if (typeof D.sayIdle === "function" && !D.closing) { try { D.sayIdle(); } catch (eSI) {} }      // (la barra no se queda diciendo «Vista previa…»)
      return true;
   };
   // ACABAR SIN PREGUNTAR (cerrar, otra imagen, otro análisis): una grabación a medias se BORRA.
   J.end = function() {
      if (J.rec !== null) { J.recordEnd(true); return true; }
      return J.stop();
   };
   J.tick = function() {
      if (J.rec !== null && J.rec.stepping) return;          // (un tic dentro de otro —ffmpeg bombea la interfaz—: nada; el de fuera decide)
      if (D.closing || (typeof CC_ABORT !== "undefined" && CC_ABORT === true)) { J.end(); try { J.timer.stop(); } catch (e0) {} return; }
      if (J.rec !== null) { J.recordStep(); return; }
      var pv = J.preview;
      if (pv === null) { try { J.timer.stop(); } catch (e) {} return; }
      if (pv.held && !ccJBroken("jdragnohold")) return;          // (26-oct: con la manecilla agarrada el reloj de la vista previa no corre)
      var ps = J.panelSize(), t = (CC_JOURNEY_CLOCK() - pv.t0) / 1000;
      if (!(t < pv.dur)) { J.stop(); return; }
      var cb = { w: 0, h: 0 }; try { cb = { w: D.colBox.width, h: D.colBox.height }; } catch (eCb) {}
      if (J.colTaken && (cb.w !== pv.colW || cb.h !== pv.colH)) { pv.colW = cb.w; pv.colH = cb.h; J.fixColCanvas(); ps = J.panelSize(); }
      if (ps.w !== pv.w || ps.h !== pv.h) {
         // (la columna cambió de tamaño —S2, la ventana—: el fotograma se rehace a su tamaño nuevo; antes se paraba)
         if (!(ps.w > 32 && ps.h > 32)) { J.stop(); return; }
         pv.w = ps.w; pv.h = ps.h; pv.r = J.previewRect(ps, pv.aspect); try { pv.frame.clear(); } catch (eFc) {} pv.frame = new Bitmap(pv.r.w, pv.r.h);
      }
      try { J.previewFrame(t); } catch (eF) { J.say(String(eF), 0, false, true); J.stop(); }
   };

   // --- ● GRABAR ---
   J.recordButton = function() { if (J.rec !== null) { J.stop(); return; } if (J.preview !== null) return; J.recordStart(); };
   J.lock = function(on) {
      var names = ["analyseBtn", "viewList", "imgRefreshBtn", "langBtn", "retryBtn", "toViewBtn", "toFileBtn", "exportBtn", "refreshBtn", "split1", "split2"], q;
      if (on) {
         J.locked = [];
         for (q = 0; q < names.length; ++q) { var c = D[names[q]]; if (c) { var was = true; try { was = c.enabled; } catch (e) {} J.locked.push([c, was]); try { c.enabled = false; } catch (e2) {} } }
      } else if (J.locked) {
         for (q = 0; q < J.locked.length; ++q) { try { J.locked[q][0].enabled = J.locked[q][1]; } catch (e3) {} }
         J.locked = null;
      }
   };
   // opts (pruebas): { width, height, fps, dir, title, format, sheet }. Devuelve { ok, why, path }.
   J.recordStart = function(opts) {
      var o = opts || {}, out = { ok: false, why: "", path: "" };
      if (J.busy()) { out.why = "busy"; return out; }
      var oth = J.other(); if (oth && oth.preview !== null) { try { oth.stop(); } catch (eOS) {} }
      var why = J.whyNot();
      if (why) { out.why = ccJT(why); J.say(out.why, 0, false, true); return out; }
      try { if (J.strip) { var tt = String(J.titleEdit.text || ""); J.title = (tt === J.defaultTitle()) ? "" : tt; J.dir = String(J.dirEdit.text || J.dir).split("\\").join("/"); } } catch (e) {}
      var size = (o.width > 0 && o.height > 0) ? { w: o.width, h: o.height } : CC_JV.SIZES[J.size], fps = (o.fps > 0) ? o.fps : J.fps;
      var dir = String(o.dir || J.dir || J.defaultDir()).split("\\").join("/"), title = String((o.title !== undefined) ? o.title : (J.title || J.defaultTitle()));
      if (dir.length === 0 || !File.directoryExists(dir)) { out.why = ccJT("jChooseDir"); J.say(out.why, 0, false, true); return out; }
      var snap = J.snapshot(), M = ccJourneyModel(snap), mode = J.mode, dur = (o.duration > 0) ? o.duration : ccJourneyDuration(M, mode);
      try { if (D.galaxy && typeof D.galaxy.stop === "function") D.galaxy.stop(); } catch (eGS) {}
      var frameFn = J.frameFnFor(snap, mode, title);
      var onEncode = function(secs) {
         try { cshProcessEvents(); } catch (eP) {}
         var rc = J.rec;
         if (D.closing || !rc || rc.encodeCancel) return false;
         J.say(ccJT("jEncoding") + " " + Math.round(secs) + " s · " + ccJT("jEncodingStop"), 0, true, false);
         return true;
      };
      var path = ccJourneyVideoPath(dir, title, mode, size.w, size.h), R = null;
      // (6-nov-2026, revision PTeam CPD) DONDE SE GUARDA LO DICE EL USUARIO: el cuadro de guardar de siempre (SaveFileDialog), con la
      // carpeta recordada (o la de la imagen, Videos, el home) y un nombre propuesto. Sin pantalla (pruebas, automatizacion) o con una
      // carpeta dada por quien llama (o.dir), no se pregunta: vale la ruta propuesta. Cancelar = no se graba nada.
      if (!o.dir) {
         var picked = J.askSavePath(path, o.format || "auto");
         if (picked === null) { out.why = "cancelled"; J.say(ccJT("jCancelled"), 0, false, false); return out; }
         path = picked.replace(/\.(avi|mp4)$/i, "");
         var cut = path.lastIndexOf("/");
         if (cut > 0) { dir = path.substring(0, cut); J.dir = dir; J.write("dir", DataType_UCString, dir); }
         if (!File.directoryExists(dir)) { out.why = ccJT("jChooseDir"); J.say(out.why, 0, false, true); return out; }
      }
      try { R = ccJourneyRecorder({ path: path, format: o.format || "auto", width: size.w, height: size.h, fps: fps, duration: dur, title: title, sheet: o.sheet,
                                    onEncode: onEncode, onFrame: function(k, bmp, tf, ret) { J.recordShow(k, bmp, ret); } }, frameFn); } catch (e2) { R = { ok: false, why: String(e2) }; }
      if (!R.ok) { out.why = R.why; J.say(ccJT("jFailed") + ": " + R.why, 0, false, true); return out; }
      J.rec = { R: R, dir: dir, mode: mode, t0: Date.now(), shownAt: 0, w: 0, h: 0, r: null, aspect: size.w / size.h, encoding: false, ask: false };
      J.strip = false;
      J.hookPanel();
      var ps = J.panelSize();
      J.rec.w = ps.w; J.rec.h = ps.h; J.rec.r = J.fitRect(Math.max(4, ps.w), Math.max(4, ps.h), size.w / size.h);
      J.lock(true);
      J.sync(); J.syncOther();
      if (typeof C.onEnd === "function") { try { C.onEnd("recordStart", null); } catch (eOR) {} }      // (III: la regla, apagada mientras se graba)
      J.say(ccJT("jRecording", J.modeName(mode), dir), 0, true, false);
      J.timer.interval = CC_JUI.RECORD_TICK_S;
      try { J.timer.start(); } catch (e5) {}
      out.ok = true; out.path = R.path;
      return out;
   };
   // el fotograma que acaba de salir, reducido en el panel, con la barra de progreso DENTRO (cada 90 ms)
   J.recordShow = function(k, bmp, ret) {
      var rc = J.rec;
      if (rc === null) return;
      var now = Date.now();
      if (k > 0 && k < rc.R.n - 1 && now - rc.shownAt < CC_JUI.SHOW_EVERY_MS) return;
      var ps = J.panelSize();
      if (ps.w !== rc.w || ps.h !== rc.h) { rc.w = ps.w; rc.h = ps.h; rc.r = J.fitRect(Math.max(4, ps.w), Math.max(4, ps.h), rc.aspect); }
      if (!(rc.w > 8 && rc.h > 8)) return;
      rc.shownAt = now;
      var el = (now - rc.t0) / 1000, left = (k >= 5) ? el / (k + 1) * (rc.R.n - k - 1) : -1;
      var text = ccJT("jFrames", k + 1, rc.R.n) + ((left >= 0) ? " · " + ccJT("jLeft", Math.floor(left / 60) + ":" + ("0" + Math.floor(left % 60)).slice(-2)) : "");
      rc.text = text;
      J.pushClock(rc.mode, ret || null);          // (la línea de tiempo y B/C/D siguen también a la grabación, cada 90 ms)
      J.compose(J.panelBuf(rc.w, rc.h), rc.r, bmp, (k + 1) / rc.R.n, text);
      if (typeof D.say === "function" && !rc.encoding) { try { D.say(ccJT("jRecording", J.modeName(rc.mode), rc.dir), (k + 1) / rc.R.n, true, false, ""); } catch (e) {} }
   };
   J.recordStep = function() {
      var rc = J.rec;
      if (rc === null || rc.ask || rc.stepping) return;
      var R = rc.R;
      if (!rc.encoding && R.k === R.n - 1 && R.format === "mp4") { rc.encoding = true; J.say(ccJT("jEncoding"), 0, true, false); return; }
      var more = false;
      rc.stepping = true;
      try { more = R.step(); } finally { rc.stepping = false; }
      if (more) return;
      J.recordEnd(false);
   };
   J.cancelAsk = function() {
      var rc = J.rec;
      if (rc === null || rc.ask) return false;
      rc.ask = true; rc.askAt = Date.now();
      J.askKeep.text = ccJT("jAskKeep", ccDec(rc.R.k / Math.max(1, rc.R.plan.fps), 1, ccJLang()));
      J.askKeep.enabled = rc.R.k >= 1;
      J.askText.text = ccJT("jAskStop"); J.askDel.text = ccJT("jAskDelete"); J.askCont.text = ccJT("jAskContinue");
      J.fit();
      J.askPanel.show(); J.askShown = true;
      J.say(ccJT("jPaused"), 0, false, false);
      return true;
   };
   J.cancelAnswer = function(choice) {
      var rc = J.rec;
      if (rc === null || !rc.ask) return false;
      J.askPanel.hide(); J.askShown = false;
      if (choice === "continue") { rc.ask = false; rc.t0 += Date.now() - rc.askAt; J.say(ccJT("jRecording", J.modeName(rc.mode), rc.dir), 0, true, false); return true; }
      J.recordEnd((choice === "keep") ? "keep" : true);
      return true;
   };
   // se acaba (o se cancela): false (acabó), true (se borra) o "keep" (se queda lo grabado)
   J.recordEnd = function(cancel) {
      var rc = J.rec;
      if (rc === null) return;
      J.rec = null;
      try { J.timer.stop(); } catch (e) {}
      try { J.askPanel.hide(); J.askShown = false; } catch (eA) {}
      if (cancel === "keep") { rc.R.finishNow(); cancel = false; }
      else if (cancel) rc.R.cancel();
      var res = rc.R.result || { ok: false, cancelled: !!cancel, why: "no result", files: [], bytes: 0, frames: 0, seconds: 0, format: "", contact: "" };
      J.lock(false);
      J.last = { what: "record", result: res };
      J.unhookPanel();
      if (res.ok) {
         J.dir = rc.dir; J.write("dir", DataType_UCString, rc.dir);
         J.say(ccJT("jSaved", res.path, ccDec(res.bytes / 1e6, 1, ccJLang()), res.frames, Math.round(res.seconds)) + (res.contact ? " · " + ccJT("jContact") + ": " + res.contact : ""), 1, false, false);
      } else if (res.cancelled) J.say(ccJT("jCancelled"), 0, false, false);
      else J.say(ccJT("jFailed") + ": " + res.why, 0, false, true);
      J.sync(); J.syncOther();
      if (typeof C.onEnd === "function") { try { C.onEnd("record", null); } catch (eOE) {} }
      // (integración) la ventana pidió cerrarse mientras se codificaba o se pintaba un fotograma: ahora sí
      if (D.closing && typeof D.videoClosed === "function") { try { D.videoClosed(); } catch (eVC) {} }
   };
   J.cleanup = function() {
      try { J.end(); } catch (e) {}
      try { J.timer.stop(); } catch (e1) {}
      try { J.unhookPanel(); } catch (e2) {}
      try { if (J.buf) J.buf.clear(); } catch (e3) {}
      J.buf = null;
   };

   D[J.slot] = J;
   J.retranslate();
   J.building = false;
   return J;
}
// EL GANCHO de cc_dialog.js (fase 1, 22-oct: `D.mountJourney(body)` llama a `ccJourneyMount(D, body)` UNA vez al construir el
// diálogo, con el cuerpo vacío del grupo II y su VerticalSizer; `true` = el rótulo «en construcción» se esconde solo).
function ccJourneyMount(D, body) { ccJourneyBuild(body, D); return true; }
#endif
