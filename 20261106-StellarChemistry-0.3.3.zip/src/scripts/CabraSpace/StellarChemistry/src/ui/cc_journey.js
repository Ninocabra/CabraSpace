#ifndef __CC_JOURNEY_JS
#define __CC_JOURNEY_JS
// ============================================================================
// src/ui/cc_journey.js — II · VIAJE Y VÍDEO: EL MODELO de los dos modos (CabraComposition, 22-oct-2026, fase 2a)
// ----------------------------------------------------------------------------
// Lo que dice QUÉ se ve en cada instante t (segundos de vídeo) de cada modo; el dibujo es cc_journey_paint.js y la
// grabación cc_journey_video.js. Puro salvo nada: no pinta ni toca el diálogo ni el estado S (lo lee).
//
//   2a «La historia del campo» (mode "history")
//      El reloj cósmico T (Ga atrás) corre de 13,8 (Big Bang, CC_SCI.UNIVERSE_GA) a 0 (hoy), lineal en el tiempo del vídeo:
//      [0, intro) T = 13,8 con el título · [intro, intro + run) T = 13,8·(1 − u) · [.., fin] T = 0 (hoy, todo encendido).
//      CÓMO SE ENCIENDE UNA ESTRELLA CON EDAD INCIERTA (decisión de esta fase, ccJourneyBirth): su brillo f(T) sube a lo
//      largo de SU intervalo de edad [lo, hi] (ccAgeRange: el adoptado, recortado a [0, 13,8]): f = 0 antes de hi (aún no
//      ha nacido en ningún caso), f = ½ justo en su edad adoptada v, f = 1 a partir de lo (ya ha nacido en todo caso);
//      por tramos lineales hi→v y v→lo. Así «encendida» (f ≥ ½) ⇔ T ≤ v: el recuento de encendidas es EXACTAMENTE el
//      número de estrellas con edad adoptada ≥ T (lo comprueba la sonda contra las edades, por su cuenta), y una edad
//      orientativa (intervalo ancho) se ve como un fundido largo, una fiable como un encendido casi seco. Al cruzar v,
//      un anillo de su color se abre y se apaga (el «nacimiento»; FLASH_GA de reloj cósmico).
//      LAS QUE NO TIENEN EDAD no se encienden nunca (ni en la foto ni en B/C/D) y la placa lo dice con su número.
//      LOS EPISODIOS de la Galaxia son los de la línea de tiempo E (CC_TIMELINE de cc_science.js, con su referencia; aquí
//      no hay ninguna fecha propia): una banda está «en curso» si to ≤ T ≤ from; un suceso puntual (Big Bang, nace el Sol)
//      se rotula mientras |T − su fecha| ≤ EVENT_GA y manda sobre las bandas. La principal es la que empezó más tarde.
//
//   2c «Gran recorrido» (mode "tour")
//      Paradas en las estrellas notables del campo, SOLO las que existan (ccJourneyStops; criterio, de una en una):
//        oldest   la más vieja CON EDAD FIABLE: nivel A o B (cc_science.js ccAgeTier), no orientativa (ccAgeVague) y sin
//                 tocar el límite de los modelos (a.edge); la de mayor edad adoptada.
//        poorest  la más pobre BIEN MEDIDA: [Fe/H] de un survey espectroscópico (no GSP-Spec ni XP: la regla «sólida» de la
//                 foto, ccChemSolid de cc_paint.js, copiada aquí) y error ≤ POOR_EFEH; la de menor [Fe/H].
//        accreted una acretada: población «accreted» (la del motor: familia de otra galaxia con p ≥ FAM_P y sin química de
//                 aquí); la de mayor probabilidad de familia.
//        alpha    la de α más alta: par [α/Fe] de un survey espectroscópico con error ≤ ALPHA_EALPHA; la de mayor [α/Fe].
//        twin     la gemela solar más parecida: entre las que pasan ccSolarTwin (cc_science.js: ΔTeff ≤ 100 K, Δlog g ≤ 0,1,
//                 |[Fe/H]| ≤ 0,1), la de menor distancia (ΔTeff/100)² + (Δlog g/0,1)² + ([Fe/H]/0,1)².
//        youngest la más joven con edad fiable (el mismo filtro que oldest).
//      Si una estrella gana dos papeles, es UNA parada con los dos. Orden: el de la lista. POOR_EFEH y ALPHA_EALPHA son
//      decisiones de diseño de esta fase (no medidas): «bien medida» = error del orden del de los surveys de baja resolución.
//      La cámara: el campo entero con el título → vuelo a cada parada (zoom suave: el centro y el log del zoom con
//      ccEaseInOut, con un «salto» que abre el plano a mitad de camino) → pausa con su placa → vuelta al campo entero.
//
// Costuras de prueba (CC_BREAK, de cc_dialog.js): jlitswap (encendido al revés), jnoagelit (las sin edad se encienden),
// jepisode (episodios corridos 1 Ga), jstops (la más vieja sin el filtro de fiabilidad), jcamoff (la cámara apunta a otra),
// jdot (cifras con punto en castellano).
// ES5. Comentarios en castellano; identificadores en inglés.
// ============================================================================

var CC_JOURNEY = {
   // (integración, 22-oct: «orbits» = el vídeo de III —ccGalaxyVideo de cc_galaxy_ui.js— grabado con ESTA grabadora: una sola)
   // (29-oct, Nino: «La Galaxia en el tiempo» se muda a III · La Galaxia, su sitio natural: II ofrece solo FIELD_MODES; el motor —esta
   //  tabla, la duración, el porqué y la grabadora— sigue sabiendo de los tres, y III monta sus mandos con GALAXY_MODES)
   MODES: ["history", "tour", "orbits"],
   FIELD_MODES: ["history", "tour"],
   GALAXY_MODES: ["orbits"],
   // 2a (segundos de vídeo; la duración total se reparte: intro + run + hold)
   H_DUR_S: 30, H_INTRO_S: 2.5, H_HOLD_S: 3.5, H_RUN_MIN_S: 4,
   FLASH_GA: 0.6,          // el anillo del nacimiento dura 0,6 Ga de reloj cósmico (≈ 1 s con 24 s de recorrido)
   EVENT_GA: 0.35,         // un suceso puntual se rotula ±0,35 Ga alrededor de su fecha
   // (24-oct, revisión de Gemini H7) EL UMBRAL DE «HOY», UNO SOLO para el reloj de II, su placa de abajo y el reloj de III (ccJourneyIsToday):
   //  0,5 Ma = donde las cifras de III («hace 1 Ma», en millones enteros) ya serían «0 Ma» y donde la regla «Tiempo» de III ya salta a 0
   //  (ccGalaxyUI.setTime). El de II, 5 Ma, era un literal suelto: entre 0,5 y 5 Ma II decía «hoy» y III «hace 2 Ma».
   TODAY_MA: CC_AGE_TODAY_MA,      // (0,5 Ma: el valor, y por qué, en cc_science.js)
   // 2c
   // (23-oct, revisor R24: de t ≈ 40 a 48 s del recorrido de Abell 39, tramos largos sin placa —vuelo de 2,6 s + fundidos, y 2,6 s de
   //  vuelta al campo—: el vuelo y la vuelta, más cortos)
   C_INTRO_S: 2.5, C_FLY_S: 1.9, C_DWELL_S: 4.8, C_OUTRO_S: 2.0, C_PLATE_FADE_S: 0.35,
   C_ZOOM: 4.0,            // el zoom de una parada: se ve ~1/4 del ancho del campo
   C_HOP: 0.5,             // a mitad de un vuelo entre dos paradas el plano se abre hasta ×(1 − C_HOP) del zoom
   POOR_EFEH: 0.15, ALPHA_EALPHA: 0.10,
   ROLES: ["oldest", "poorest", "accreted", "alpha", "twin", "youngest"]
};

function ccJBroken(k) { return (typeof CC_BREAK === "string") && CC_BREAK.indexOf(k) >= 0; }
function ccJClamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
// ¿«hoy»? en el final (fase «hold») o a menos de CC_JOURNEY.TODAY_MA de hoy. T en Ma. ROJO «todayold»: el literal de antes en II (5 Ma).
function ccJourneyIsToday(phase, TMa) { return ccAgeIsToday(phase, TMa / 1000); }      // (la regla vive en cc_science.js con la función del texto; ROJO «todayold» también)
// EL RELOJ de II, «hace 9,3 Ga» / «hoy»: la función ÚNICA es ccAgeAgoText (cc_science.js; R3, 26-oct); este es su nombre en II (TGa en Ga, idioma del diálogo).
function ccJourneyClockText(phase, TGa) { return ccAgeAgoText(TGa, ccJLang(), phase); }
function ccJNum(x) { return typeof x === "number" && isFinite(x); }
function ccJUniverse() { return (typeof CC_SCI !== "undefined" && CC_SCI.UNIVERSE_GA > 0) ? CC_SCI.UNIVERSE_GA : 13.8; }
// (COPIA de cc_paint.js ccChemSolid, 22-oct: la fase 1 rehace cc_paint.js en paralelo; la regla es una línea)
function ccJChemSolid(s) { return !!(s && s.chem && s.chem.feh && s.chem.feh.src !== "gspspec" && s.chem.feh.src !== "xpg"); }

// ---------------------------------------------------------------------------
// 2a · EL ENCENDIDO
// ---------------------------------------------------------------------------
// f(T) ∈ [0, 1] de una edad adoptada `a` cuando el reloj cósmico marca T Ga atrás (ver la cabecera). null → 0.
function ccJourneyBirth(a, T) {
   if (!a || !(a.v > 0)) return 0;
   var U = ccJUniverse(), v = Math.min(a.v, U), r = (typeof ccAgeRange === "function") ? ccAgeRange(a) : [Math.max(0, a.v - a.e), Math.min(U, a.v + a.e)];
   var lo = Math.min(r[0], v), hi = Math.max(r[1], v), f;
   if (T > hi) f = 0;
   else if (T <= lo) f = 1;
   else if (T > v) f = (hi > v) ? 0.5 * (hi - T) / (hi - v) : 0;
   else f = (v > lo) ? 0.5 + 0.5 * (v - T) / (v - lo) : 1;
   if (T === v) f = 0.5;
   if (ccJBroken("jlitswap")) f = 1 - f;
   return ccJClamp(f, 0, 1);
}
// El anillo del nacimiento: 0..1 mientras dura (desde que cruza su edad adoptada), -1 fuera.
function ccJourneyFlash(a, T) {
   if (!a || !(a.v > 0)) return -1;
   var v = Math.min(a.v, ccJUniverse()), p = (v - T) / CC_JOURNEY.FLASH_GA;
   return (p >= 0 && p < 1) ? p : -1;
}

// ---------------------------------------------------------------------------
// LA INSTANTÁNEA del estado (no se toca S: se copia lo que hace falta, una vez por análisis y por idioma)
// ---------------------------------------------------------------------------
var CC_JOURNEY_CACHE = null;
function ccJourneyModel(S) {
   if (!S || !S.res) return null;
   var list = S.list || [], key = [list.length, (typeof CC_LANG !== "undefined") ? CC_LANG : "en", S.photo ? 1 : 0, ccJBroken("jstops") ? 1 : 0, ccJBroken("jnoagelit") ? 1 : 0, String(S.elem || "")].join("|");
   var C = CC_JOURNEY_CACHE;
   if (C && C.res === S.res && C.photo === S.photo && C.key === key) return C.model;
   var res = S.res, stars = [], noAge = [], nKin = 0, i;
   for (i = 0; i < list.length; ++i) {
      var s = res.stars[list[i]];
      if (!s) continue;
      if (s.fam && s.fam.nominal) ++nKin;           // (las que tienen órbita: las del mapa de III, ccGalaxyModel)
      var a = (s.age && s.age.adopted && s.age.adopted.v > 0) ? s.age.adopted : null;
      if (a) stars.push({ idx: list[i], s: s, a: a, v: Math.min(a.v, ccJUniverse()) });
      else noAge.push({ idx: list[i], s: s, a: null, v: null });
   }
   // las brillantes encima (el orden de ccVisibleList: ya vienen así)
   var F = res.field || S.frame || null;
   var M = { res: res, list: list.slice(), photo: S.photo || null, field: F ? { width: F.width, height: F.height } : { width: 1, height: 1 },
             stars: stars, noAge: noAge, nAge: stars.length, nNoAge: noAge.length,
             opts: S.opts ? { sizeByAge: !!S.opts.sizeByAge, contours: S.opts.contours !== false, errors: false, backdrop: S.opts.backdrop !== false } : { sizeByAge: false, contours: true, errors: false, backdrop: true },
             dView: (S.dView === "toomre") ? "toomre" : "elz", viewId: String(S.viewId || S.photoViewId || ""),
             elem: (typeof S.elem === "string" && S.elem) ? S.elem : "Fe", nKin: nKin };      // (S.elem: el elemento de IV colorea el vídeo)
   M.stops = ccJourneyStops(res, list);
   CC_JOURNEY_CACHE = { res: S.res, photo: S.photo, key: key, model: M };
   return M;
}
function ccJourneyForget() { CC_JOURNEY_CACHE = null; }
// (29-oct) el modo recordado, dentro de los que ofrece un grupo: una preferencia de antes que decía «orbits» en II cae a la primera
// («history»); III no lee modo (solo tiene uno). ES5.
function ccJourneyPickMode(saved, modes) { var L = (modes && modes.length) ? modes : CC_JOURNEY.FIELD_MODES, m = String(saved || ""); return (L.indexOf(m) >= 0) ? m : L[0]; }

// ---------------------------------------------------------------------------
// 2a · EL RELOJ
// ---------------------------------------------------------------------------
function ccJourneyHistoryDur(opts) { var d = (opts && opts.duration > 0) ? opts.duration : CC_JOURNEY.H_DUR_S; return Math.max(CC_JOURNEY.H_INTRO_S + CC_JOURNEY.H_HOLD_S + CC_JOURNEY.H_RUN_MIN_S, d); }
// t (s de vídeo) → { T (Ga atrás), phase "intro" | "run" | "hold", u (0..1 del recorrido), titleAlpha }
function ccJourneyHistoryClock(t, dur) {
   var J = CC_JOURNEY, D = (dur > 0) ? dur : J.H_DUR_S, U = ccJUniverse(), run = Math.max(J.H_RUN_MIN_S, D - J.H_INTRO_S - J.H_HOLD_S);
   var out = { T: U, phase: "intro", u: 0, titleAlpha: 0 };
   if (t < J.H_INTRO_S) { out.titleAlpha = ccJClamp((J.H_INTRO_S - t) / 0.6, 0, 1); return out; }
   var u = (t - J.H_INTRO_S) / run;
   if (u >= 1) { out.T = 0; out.phase = "hold"; out.u = 1; return out; }
   out.phase = "run"; out.u = u; out.T = U * (1 - u);
   return out;
}
// Lo contrario (las pruebas): el segundo de vídeo en el que el reloj marca T.
function ccJourneyHistoryTimeAt(T, dur) {
   var J = CC_JOURNEY, D = (dur > 0) ? dur : J.H_DUR_S, run = Math.max(J.H_RUN_MIN_S, D - J.H_INTRO_S - J.H_HOLD_S);
   return J.H_INTRO_S + run * (1 - ccJClamp(T, 0, ccJUniverse()) / ccJUniverse());
}
// Los episodios en curso a T: { active: [ev…] (la que empezó más tarde, primero), point: ev | null, primary: ev | null }
// (24-oct, B2 = a de Nino) Sequoia y las corrientes de Helmi (ccMergerEvents, cc_science.js) cuentan como episodios en curso: se encienden en
// la línea de tiempo y salen en «También: …» de la placa. ROJO «jnomerg» de T22: sin ellas, como antes.
// EL TITULAR (primary), en este orden: (1) un suceso puntual (Big Bang, Nace el Sol); (2) (B2b = sí de Nino, 24-oct) una fusión con
// `headline` (Sequoia, mientras dura: 9,8–8,9 Ga de CC_MERGERS, vía ccMergerEvents); (3) el primer episodio de CC_TIMELINE; (4) el primero.
// Helmi NO es titular: dura 10,8–5,0 Ga y, por empezar más tarde que Gaia-Enceladus, se lo comería.
// LA FRONTERA: el intervalo es CERRADO por los dos lados, el mismo que enciende la banda (x <= from && x >= to): a 9,8 Ga y a 8,9 Ga
// exactos Sequoia ya es el titular (y está encendida); un pelo más allá (9,81 · 8,89) vuelve Gaia-Enceladus. Un criterio, no dos.
// ROJO «jnoheadline» (T24 Y8, sonda J3b/J3c): Sequoia sin titular propio, como antes de B2b.
function ccJourneyEpisodes(T) {
   var TL = (typeof CC_TIMELINE !== "undefined") ? CC_TIMELINE : [], act = [], point = null, best = 1e9, x = ccJBroken("jepisode") ? T + 1 : T;
   if (!ccJBroken("jnomerg") && typeof ccMergerEvents === "function") TL = TL.concat(ccMergerEvents());
   for (var i = 0; i < TL.length; ++i) {
      var ev = TL[i];
      if (ev.from === ev.to) { var d = Math.abs(x - ev.from); if (d <= CC_JOURNEY.EVENT_GA && d < best) { best = d; point = ev; } }
      else if (x <= ev.from && x >= ev.to) act.push(ev);
   }
   act.sort(function(a, b) { return a.from - b.from; });
   var head = null;
   if (!ccJBroken("jnoheadline")) for (i = 0; i < act.length && !head; ++i) if (act[i].headline) head = act[i];
   for (i = 0; i < act.length && !head; ++i) if (!act[i].merger) head = act[i];
   return { active: act, point: point, primary: point || head || act[0] || null };
}
// «también: …» (B2c = sí de Nino, 24-oct): los episodios en curso que NO son el titular, con su nombre completo y en el orden de `active`.
// UNA sola función para la placa del vídeo de II (cc_journey_paint.js) y la de «La Galaxia en el tiempo» de III (cc_galaxy_ui.js).
// -> { names: [..], line: "también: A · B" | "" }  (el idioma es el de CC_LANG, como el de ccJT)
// (24-oct, revisión de Gemini H7) `lang` ("es" | "en", opcional): el idioma de quien llama (la placa de III lo pasa); sin él, el global CC_LANG.
function ccJourneyAlso(ep, lang) {
   var given = (lang === "es" || lang === "en"), es = given ? (lang === "es") : (typeof CC_LANG !== "undefined" && CC_LANG === "es"), names = [], i;
   var say = function(body) { return given ? CC_JTXT.jAlso[es ? 1 : 0].split("%1").join(body) : ccJT("jAlso", body); };
   if (ep && ep.active) for (i = 0; i < ep.active.length; ++i) if (ep.active[i] !== ep.primary) names.push(es ? ep.active[i].es : ep.active[i].en);
   // (corte de línea, 24-oct) Cada nombre va unido con espacios duros (U+00A0) y el « ·» pegado al nombre que acaba: ccWrap solo puede cortar entre
   //  un « ·» y el nombre siguiente, nunca dentro de «Disco grueso (α alto)» (si un nombre solo no cabe en la línea, ccWrap sí lo parte).
   //  ROJO «alsosplit»: la lista como antes, con espacios normales (se parte donde cae). `plain` = el mismo texto con espacios normales.
   var NB = "\u00a0", units = [], plain = names.join(" · ");
   for (i = 0; i < names.length; ++i) units.push(names[i].split(" ").join(NB) + (i + 1 < names.length ? NB + "·" : ""));
   var body = ccJBroken("alsosplit") ? plain : units.join(" ");
   return { names: names, line: names.length ? say(body) : "", plain: names.length ? say(plain) : "" };
}
// Cuántas están encendidas a T (f ≥ ½), y cuántas «sin edad» lo estarían (debe ser 0).
function ccJourneyLitCount(M, T) {
   var n = 0, i;
   for (i = 0; i < M.stars.length; ++i) if (ccJourneyBirth(M.stars[i].a, T) >= 0.5) ++n;
   return n;
}

// ---------------------------------------------------------------------------
// 2c · LAS PARADAS
// ---------------------------------------------------------------------------
function ccJourneyReliableAge(a) { return !!(a && a.v > 0 && (a.tier === "A" || a.tier === "B") && !(typeof ccAgeVague === "function" && ccAgeVague(a)) && !a.edge); }
// Devuelve [ { idx, roles: ["oldest", …] } ] en el orden de CC_JOURNEY.ROLES (una estrella con dos papeles, una parada).
function ccJourneyStops(res, list) {
   var best = {}, val = {}, i, J = CC_JOURNEY;
   function take(role, idx, score) { if (!(role in val) || score > val[role]) { val[role] = score; best[role] = idx; } }
   for (i = 0; i < (list || []).length; ++i) {
      var idx = list[i], s = res.stars[idx];
      if (!s) continue;
      var a = (s.age && s.age.adopted) ? s.age.adopted : null, ch = s.chem || {}, gb = ccJNum(s.g) ? -s.g / 1000 : 0;   // (empates: la más brillante)
      var okAge = ccJBroken("jstops") ? !!(a && a.v > 0) : ccJourneyReliableAge(a);
      if (okAge) { take("oldest", idx, a.v + gb); }
      if (ccJourneyReliableAge(a)) take("youngest", idx, -a.v + gb);
      if (ccJChemSolid(s) && ccJNum(ch.feh.v) && ccJNum(ch.feh.e) && ch.feh.e <= J.POOR_EFEH) take("poorest", idx, -ch.feh.v + gb);
      if (s.pop && s.pop.label === "accreted") take("accreted", idx, ((s.fam && ccJNum(s.fam.p)) ? s.fam.p : 0) + gb);
      var pr = ch.pair;
      if (pr && ccJNum(pr.alpha) && pr.src !== "gspspec" && pr.src !== "xpg" && ccJNum(pr.ealpha) && pr.ealpha <= J.ALPHA_EALPHA) take("alpha", idx, pr.alpha + gb);
      if (typeof ccSolarTwin === "function" && ccSolarTwin(ch)) {
         var dT = (ch.teff - CC_SCI.SUN_TEFF) / 100, dG = (ch.logg - CC_SCI.SUN_LOGG) / 0.1, dF = ch.feh.v / 0.1;
         take("twin", idx, -(dT * dT + dG * dG + dF * dF) + gb);
      }
   }
   var out = [], at = {};
   for (i = 0; i < J.ROLES.length; ++i) {
      var r = J.ROLES[i];
      if (!(r in best)) continue;
      var k = best[r];
      if (k in at) out[at[k]].roles.push(r);
      else { at[k] = out.length; out.push({ idx: k, roles: [r] }); }
   }
   return out;
}

// ---------------------------------------------------------------------------
// 2c · EL PLAN DE CÁMARA
// ---------------------------------------------------------------------------
// cam = { cx, cy (píxeles de la imagen), k (zoom: 1 = el campo entero) }
function ccJourneyTourPlan(M) {
   var J = CC_JOURNEY, F = M.field, whole = { cx: F.width / 2, cy: F.height / 2, k: 1 }, segs = [], t = J.C_INTRO_S, prev = whole;
   segs.push({ kind: "intro", t0: 0, t1: J.C_INTRO_S, a: whole, b: whole, stop: -1 });
   for (var i = 0; i < M.stops.length; ++i) {
      var who = ccJBroken("jcamoff") ? M.stops[(i + 1) % M.stops.length].idx : M.stops[i].idx;
      var s = M.res.stars[who];
      if (ccJBroken("jcamoff") && M.stops.length === 1) s = { x: F.width - s.x, y: F.height - s.y };
      var cam = { cx: s.x, cy: s.y, k: J.C_ZOOM };
      segs.push({ kind: "fly", t0: t, t1: t + J.C_FLY_S, a: prev, b: cam, stop: i });
      t += J.C_FLY_S;
      segs.push({ kind: "dwell", t0: t, t1: t + J.C_DWELL_S, a: cam, b: cam, stop: i });
      t += J.C_DWELL_S;
      prev = cam;
   }
   segs.push({ kind: "outro", t0: t, t1: t + J.C_OUTRO_S, a: prev, b: whole, stop: -1 });
   t += J.C_OUTRO_S;
   return { duration: t, segs: segs, whole: whole };
}
// Entre dos cámaras (u = 0..1): el centro y el log del zoom con la curva simétrica; a mitad, un «salto» que abre el plano.
function ccJourneyCamLerp(A, B, u) {
   var e = (typeof ccEaseInOut === "function") ? ccEaseInOut(u) : u, la = Math.log(Math.max(1, A.k)), lb = Math.log(Math.max(1, B.k));
   // (23-oct: el «salto» solo ENTRE dos paradas; en la pausa —A y B la misma cámara— también se aplicaba y el plano se abría a la mitad
   //  a mitad de cada pausa: medido en T18 Y11, zoom 2 en vez de 4 a mitad de la parada 1)
   var moving = Math.abs(A.cx - B.cx) + Math.abs(A.cy - B.cy) > 1e-6;
   var hop = (moving && A.k > 1.01 && B.k > 1.01) ? -Math.log(1 / (1 - CC_JOURNEY.C_HOP)) * Math.sin(Math.PI * e) : 0;
   return { cx: A.cx + (B.cx - A.cx) * e, cy: A.cy + (B.cy - A.cy) * e, k: Math.max(1, Math.exp(la + (lb - la) * e + hop)) };
}
// t → { cam, stop (índice de parada o -1), plateAlpha, titleAlpha, phase }
function ccJourneyTourAt(plan, t) {
   var J = CC_JOURNEY, segs = plan.segs, sg = segs[segs.length - 1], i;
   for (i = 0; i < segs.length; ++i) if (t < segs[i].t1) { sg = segs[i]; break; }
   var u = ccJClamp((t - sg.t0) / Math.max(1e-6, sg.t1 - sg.t0), 0, 1), out = { cam: ccJourneyCamLerp(sg.a, sg.b, u), stop: -1, plateAlpha: 0, titleAlpha: 0, phase: sg.kind, seg: sg };
   if (sg.kind === "intro") out.titleAlpha = ccJClamp((sg.t1 - t) / 0.6, 0, 1);
   if (sg.kind === "dwell") {
      out.stop = sg.stop;
      out.plateAlpha = ccJClamp(Math.min((t - sg.t0) / J.C_PLATE_FADE_S, (sg.t1 - t) / J.C_PLATE_FADE_S), 0, 1);
   }
   if (sg.kind === "fly") out.stop = sg.stop;            // (el anillo de la que viene ya se ve llegar; la placa, no)
   return out;
}
// Las pruebas: el segundo en mitad de la pausa de la parada i.
function ccJourneyTourStopTime(plan, i) {
   for (var k = 0; k < plan.segs.length; ++k) if (plan.segs[k].kind === "dwell" && plan.segs[k].stop === i) return 0.5 * (plan.segs[k].t0 + plan.segs[k].t1);
   return -1;
}

// ---------------------------------------------------------------------------
// LA DURACIÓN de un modo (s)
// ---------------------------------------------------------------------------
function ccJourneyDuration(M, mode, opts) {
   if (!M) return 0;
   if (mode === "tour") return M.stops.length ? ccJourneyTourPlan(M).duration : 0;
   // («orbits» = «La Galaxia en el tiempo» desde el 23-oct: su duración, la de su reloj —cc_galaxy_time.js—: 46,7 s)
   if (mode === "orbits") return M.nKin ? ((typeof ccGxtDuration === "function") ? ccGxtDuration() : 46.7) : 0;
   return M.nAge ? ccJourneyHistoryDur(opts) : 0;
}
// ¿Se puede? "" o la clave del porqué (cc_journey_i18n.js).
function ccJourneyWhyNot(M, mode) {
   if (!M) return "jNeedAnalysis";
   if (mode === "tour") return M.stops.length ? "" : "jNoStops";
   if (mode === "orbits") return (typeof ccGalaxyVideo !== "function") ? "jNoGalaxy" : (M.nKin ? "" : "jNoOrbits");
   return M.nAge ? "" : "jNoAges";
}

// ---------------------------------------------------------------------------
// 2c · LO QUE DICE LA PLACA de una parada (todo de los datos; la frase, de cc_story.js)
// ---------------------------------------------------------------------------
// Las cifras que se pintan: coma decimal en castellano (ccDec de cc_story.js). Costura jdot: con punto (el rojo de la sonda).
function ccJDec(x, d, lang) { return ccDec(x, d, ccJBroken("jdot") ? "en" : lang); }
function ccJourneyRoleFigure(s, role, lang) {
   var E = (lang === "es"), ch = s.chem || {}, a = (s.age && s.age.adopted) ? s.age.adopted : null, f = function(x, d) { return ccJDec(x, d, lang); };
   var sg = function(x, d) { var t = (x >= 0 ? "+" : "−") + f(Math.abs(x), d); return t; };
   var ga = ccAgeUnit(lang);
   // (27-oct, R1b) la edad con el mismo texto que la ficha (ccAgeText: nunca «v ± e» si su banda pasa de la edad del Universo)
   if ((role === "oldest" || role === "youngest") && a) return (typeof ccAgeText === "function" && !ccJBroken("jdot")) ? ccAgeText(a, lang) : f(a.v, 1) + " ± " + f(a.e, 1) + " " + ga;
   if (role === "poorest" && ch.feh) return "[Fe/H] " + sg(ch.feh.v, 2) + (ccJNum(ch.feh.e) ? " ± " + f(ch.feh.e, 2) : "");
   if (role === "alpha" && ch.pair) return "[α/Fe] " + sg(ch.pair.alpha, 2) + (ccJNum(ch.pair.ealpha) ? " ± " + f(ch.pair.ealpha, 2) : "");
   if (role === "accreted" && s.fam) {
      var nm = (typeof CC_FAM_NAME !== "undefined" && CC_FAM_NAME[E ? "es" : "en"][s.fam.best]) ? CC_FAM_NAME[E ? "es" : "en"][s.fam.best] : String(s.fam.best || "");
      return nm + (ccJNum(s.fam.p) ? " · p = " + f(s.fam.p, 2) : "");
   }
   if (role === "twin" && ccJNum(ch.teff)) return ccThou(Math.round(ch.teff / 10) * 10, lang) + " K · log g " + f(ch.logg, 2) + (ch.feh ? " · [Fe/H] " + sg(ch.feh.v, 2) : "");
   return "";
}
// UNA frase llana del relato de la ficha (ccStory), la que va con el papel. Sin el paréntesis largo de los «metales».
function ccJourneyRoleSentence(s, role, lang) {
   var st = (typeof ccStory === "function") ? ccStory(s, lang) : [], G = st.g || [], i, want = 0, kw = null;
   if (role === "poorest" || role === "twin") { want = 1; kw = /hierro|iron/; }
   else if (role === "alpha") { want = 1; kw = /magnesio|magnesium/; }
   else if (role === "accreted") { want = 1; kw = /acretada|accreted/; }
   var pick = "";
   for (i = 0; i < st.length; ++i) if (G[i] === want && (!kw || kw.test(st[i]))) { pick = st[i]; break; }
   if (!pick) for (i = 0; i < st.length; ++i) if (G[i] === want) { pick = st[i]; break; }
   pick = String(pick);
   var cut = pick.lastIndexOf(" (");
   if (cut > 0 && /\)\s*$/.test(pick)) pick = pick.substring(0, cut).replace(/\s+$/, "");
   if (pick.length && !/[.!?…]$/.test(pick)) pick += ".";
   return pick;
}
#endif
