#ifndef __CC_GALAXY_PAINT_JS
#define __CC_GALAXY_PAINT_JS
// ============================================================================
// src/ui/cc_galaxy_paint.js — III · LA GALAXIA: el DIBUJO del mapa
// ----------------------------------------------------------------------------
//   ccGalaxyPaint(g, w, h, G, sc, view) -> R (lo pintado, para las pruebas y el ratón)
//   ccGalaxyPick(G, x, y, sc)           -> el índice de res.stars bajo el cursor, o −1
//
// G = ccGalaxyModel(S.res, S.list) (cc_galaxy.js); view = G.ui (los mandos):
//   { mode: "top" | "edge" | "3d", show: "now" | "orbit", color: "pop" | "age" | "feh", sel (índice de res.stars),
//     cam (vista 3D: ccGxCamView), v2: { top, edge } (zoom y centro 2D), tMyr (para el vídeo: dónde va cada estrella),
//     trail (Myr de estela en el vídeo; 0 = sin estela), light (al arrastrar: menos órbitas), arms }
// Colores: los de población (CC_POP_COLOR) y la escala de [Fe/H] (ccFehRgb) de cc_atlas.js, llamados, no copiados.
// La escala de EDAD es nueva y sale de la misma paleta (ccGxAgeRgb). Las cifras, con coma en castellano.
// RÓTULOS SIN PISARSE: una rejilla de ocupación (celdas de 4 px lógicos): lo duro (título, leyenda, escala, pie,
// otros rótulos, el Sol y el centro) no se pisa nunca; lo blando (los puntos) se esquiva si se puede. Un rótulo que
// no cabe en ninguno de sus 8 sitios no se pinta (R.dropped lo cuenta).
// No depende de cc_paint.js (que la fase 1 está rehaciendo): sus pocos ayudantes son propios (ccGx…).
// ES5 puro.
// ============================================================================

function ccGxNum(x, d) {
   if (!ccIsNum(x)) return "—";
   var s = x.toFixed(d === undefined ? 1 : d);
   if (/^-0(\.0+)?$/.test(s)) s = s.substring(1);
   if (s.charAt(0) === "-") s = "−" + s.substring(1);
   return (typeof CC_LANG !== "undefined" && CC_LANG === "es" && !ccGxBroken("comma")) ? s.replace(".", ",") : s;
}
function ccGxSigned(x, d) { var s = ccGxNum(x, d); return (ccIsNum(x) && x >= 0 && s.charAt(0) !== "−") ? "+" + s : s; }
function ccGxNoBrush(g) { g.brush = new Brush(0x00000000, BrushStyle_Empty); }
var CC_GX_SCALE = 1;      // (la escala del pintado en curso: la usa ccGxTrajPolyline para medir sus tramos en px lógicos)
function ccGxPen(c, w, dash) { return (dash && typeof PenStyle_Dash !== "undefined") ? new Pen(c, w, PenStyle_Dash) : new Pen(c, w); }
// LA ESCALA DE EDAD (nueva, de la paleta): azul (joven) -> crema (la edad del Sol) -> oro -> bermellón (lo más viejo)
var CC_GX_AGE_STOPS = [[0, CC_ATLAS.chart[1]], [2, ccMix(CC_ATLAS.chart[1], CC_ATLAS.text, 0.55)], [4.6, CC_ATLAS.text], [8, CC_ATLAS.goldLight],
                       [10.5, CC_ATLAS.gold], [13.5, CC_ATLAS.chart[2]]];
function ccGxAgeRgb(age) {
   var S = CC_GX_AGE_STOPS;
   if (!ccIsNum(age)) return ccHexRgb(CC_ATLAS.text3);
   if (age <= S[0][0]) return ccHexRgb(S[0][1]);
   for (var i = 1; i < S.length; ++i) if (age <= S[i][0]) {
      var t = (age - S[i - 1][0]) / (S[i][0] - S[i - 1][0]), a = ccHexRgb(S[i - 1][1]), b = ccHexRgb(S[i][1]);
      return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
   }
   return ccHexRgb(S[S.length - 1][1]);
}
// El color de una estrella del modelo: { rgb, hollow }.
function ccGxColorOf(e, mode) {
   if (mode === "age") return e.ageOk ? { rgb: ccGxAgeRgb(e.age), hollow: false } : { rgb: ccHexRgb(CC_ATLAS.text3), hollow: true };
   if (mode === "feh") return (e.feh !== null) ? { rgb: ccFehRgb(e.feh), hollow: false } : { rgb: ccHexRgb(CC_ATLAS.text3), hollow: true };
   var hex = CC_POP_COLOR[e.pop] || CC_ATLAS.text3;
   return { rgb: ccHexRgb(hex), hollow: (e.pop === "unknown") };
}
function ccGxLighter(rgb, t) { return [rgb[0] + (255 - rgb[0]) * t, rgb[1] + (255 - rgb[1]) * t, rgb[2] + (255 - rgb[2]) * t]; }

// ---------------------------------------------------------------------------
// TEXTO, apuntado en R (las pruebas leen lo pintado: idioma, comas, solapes)
// ---------------------------------------------------------------------------
function ccGxText(g, R, f, color, x, y, t) {
   g.font = f; g.pen = new Pen(color, 1); g.drawText(x, y, t);
   if (R) R.texts.push(String(t));
   if (typeof CC_TEXT_SPY !== "undefined" && CC_TEXT_SPY) CC_TEXT_SPY.push(String(t));     // (T19, R16)
   if (typeof CC_FONT_SPY !== "undefined" && CC_FONT_SPY) CC_FONT_SPY.push(f.pixelSize);    // (23-oct, T17 X9: la vista previa, legible)
}
function ccGxHalo(g, R, f, color, x, y, t, sc) {
   var hc = ccInt(CC_ATLAS.bg, 0.92), d = Math.max(1, Math.round(1.2 * sc));
   g.font = f; g.pen = new Pen(hc, 1);
   for (var dx = -1; dx <= 1; ++dx) for (var dy = -1; dy <= 1; ++dy) if (dx || dy) g.drawText(x + dx * d, y + dy * d, t);
   ccGxText(g, R, f, color, x, y, t);
}
// LA REJILLA DE OCUPACIÓN: 0 libre · 1 blando (puntos) · 2 duro (rótulos, leyenda, símbolos)
function ccGxOcc(w, h, sc) {
   var cell = Math.max(3, Math.round(4 * sc)), nx = Math.ceil(w / cell), ny = Math.ceil(h / cell);
   return { cell: cell, nx: nx, ny: ny, a: new Uint8Array(nx * ny), w: w, h: h };
}
function ccGxOccMark(O, x0, y0, x1, y1, v) {
   if (!O) return;
   // (x1, y1 EXCLUIDOS: un rectángulo que acaba justo en el borde de una celda no la ocupa; con el borde incluido, la marca
   //  del Sol tapaba los 8 sitios de su rótulo y «Sol» no salía nunca: captura del 22-oct)
   var i0 = Math.max(0, Math.floor(x0 / O.cell)), i1 = Math.min(O.nx - 1, Math.floor((x1 - 0.01) / O.cell));
   var j0 = Math.max(0, Math.floor(y0 / O.cell)), j1 = Math.min(O.ny - 1, Math.floor((y1 - 0.01) / O.cell));
   for (var j = j0; j <= j1; ++j) for (var i = i0; i <= i1; ++i) { var k = j * O.nx + i; if (O.a[k] < v) O.a[k] = v; }
}
// (29-oct-2026) `own` = [x0, y0, x1, y1] opcional: la marca del PROPIO símbolo del rótulo; sus celdas no cuentan (las mismas que marcó ccGxOccMark)
function ccGxOccCost(O, x0, y0, x1, y1, bounds, own) {
   if (bounds && (x0 < bounds.x || y0 < bounds.y || x1 > bounds.x + bounds.w || y1 > bounds.y + bounds.h)) return { hard: 1e9, soft: 0 };
   var i0 = Math.floor(x0 / O.cell), i1 = Math.floor((x1 - 0.01) / O.cell), j0 = Math.floor(y0 / O.cell), j1 = Math.floor((y1 - 0.01) / O.cell), hard = 0, soft = 0;
   var oi0 = 1, oi1 = 0, oj0 = 1, oj1 = 0;
   if (own) { oi0 = Math.floor(own[0] / O.cell); oi1 = Math.floor((own[2] - 0.01) / O.cell); oj0 = Math.floor(own[1] / O.cell); oj1 = Math.floor((own[3] - 0.01) / O.cell); }
   for (var j = j0; j <= j1; ++j) for (var i = i0; i <= i1; ++i) {
      if (i >= oi0 && i <= oi1 && j >= oj0 && j <= oj1) continue;
      if (i < 0 || j < 0 || i >= O.nx || j >= O.ny) { ++hard; continue; }
      var v = O.a[j * O.nx + i];
      if (v >= 2) ++hard; else if (v === 1) ++soft;
   }
   return { hard: hard, soft: soft };
}
// Un rótulo (una o dos líneas) junto a (ax, ay): 8 sitios alrededor; el primero sin nada duro y con menos puntos debajo.
// lines = [{ t, f, c }]. Devuelve el rectángulo o null.
// (23-oct, revisor R3/R17) `plate`: una placa oscura detrás (la elegida: las órbitas que pasan por debajo no se cruzan con su texto);
// y cada rótulo ocupa en la rejilla su caja MÁS 6 px lógicos: dos rótulos no quedan pegados («…280 Sol» se leía como uno).
// (29-oct-2026, «el rótulo del centro galáctico salta», visto en el teaser de Cabra3D —CabraShared/csh_galaxy_paint.js, cshGxPlace, la misma
//  copia—) `fix` opcional = { own: [x0, y0, x1, y1] }: un rótulo que se queda QUIETO junto a su punto: no mira lo blando (puntos y estelas, que se
//  mueven en cada fotograma) ni la marca de su propio símbolo (a menos de una celda de la primera vuelta: tapada o libre según la fase del punto
//  en la rejilla). El primero de los 24 sitios sin nada duro. ROJO «gcjump» (CC_GX_BREAK): el criterio de antes.
function ccGxPlace(g, R, O, lines, ax, ay, gap, sc, bounds, plate, fix) {
   var lw = 0, lh = 0, i;
   for (i = 0; i < lines.length; ++i) { lw = Math.max(lw, lines[i].f.width(lines[i].t)); lh += lines[i].f.ascent + lines[i].f.descent + Math.round(1 * sc); }
   // (los 8 sitios a tres distancias: la marca dura del símbolo y la celda de la rejilla, de 6 px a escala 1,5, se comían el
   //  primer anillo entero —«Sol» y «Centro galáctico» no salían nunca; sonda del 22-oct, reproducido en node—)
   var p = Math.round(2 * sc), cands = [];
   for (var ring = 0; ring < 3; ++ring) {
      var gg = gap + ring * O.cell;
      cands.push([ax + gg, ay - lh / 2], [ax - gg - lw, ay - lh / 2], [ax - lw / 2, ay - gg - lh], [ax - lw / 2, ay + gg],
                 [ax + gg * 0.7, ay - gg * 0.7 - lh], [ax - gg * 0.7 - lw, ay - gg * 0.7 - lh], [ax + gg * 0.7, ay + gg * 0.7], [ax - gg * 0.7 - lw, ay + gg * 0.7]);
   }
   if (fix && ccGxBroken("gcjump")) fix = null;
   var noGrid = ccGxBroken("labels"), best = -1, bestSoft = 1e9;
   for (i = 0; i < cands.length; ++i) {
      if (noGrid) { best = 0; break; }
      var c = ccGxOccCost(O, cands[i][0] - p, cands[i][1] - p, cands[i][0] + lw + p, cands[i][1] + lh + p, bounds, fix ? fix.own : null);
      if (fix) { if (c.hard === 0) { best = i; break; } continue; }
      if (c.hard === 0 && c.soft < bestSoft) { best = i; bestSoft = c.soft; if (c.soft === 0) break; }
   }
   if (best < 0) { R.dropped++; return null; }
   var x = cands[best][0], y = cands[best][1], yy = y;
   if (plate) { g.fillRoundedRect(x - 4 * sc, y - 2 * sc, x + lw + 4 * sc, y + lh + 2 * sc, 6, 18, new Brush(ccInt(CC_ATLAS.bg, 0.72))); ccGxNoBrush(g); }
   for (i = 0; i < lines.length; ++i) { yy += lines[i].f.ascent; ccGxHalo(g, R, lines[i].f, lines[i].c, x, yy, lines[i].t, sc); yy += lines[i].f.descent + Math.round(1 * sc); }
   var rect = { x0: x, y0: y, x1: x + lw, y1: y + lh, text: lines[0].t };
   var pm = ccGxBroken("labelgap") ? p : Math.round(6 * sc);      // (ROJO «labelgap» de T18: el margen de antes)
   if (!noGrid) ccGxOccMark(O, x - pm, y - pm, x + lw + pm, y + lh + pm, 2);
   R.labels.push(rect);
   return rect;
}
// El rótulo de un círculo de distancia («10 kpc»), en el primer sitio libre de su borde (abajo a la derecha primero). Devuelve el rectángulo o null.
// (27-oct, E4: el rojo «labelgap» de T18 dejó de caer al cambiar el reloj del vídeo; al buscar por qué salió que este rótulo miraba solo
//  ±2 px FIJOS alrededor de un rectángulo desplazado —0 px a su derecha— y marcaba +2…4 px: junto a un rótulo de ccGxPlace podía quedar a
//  6–7,5 px lógicos, y a ~3 de otro círculo; el «pegados “Gaia DR3 …” y “10 kpc” (7,3 px)» del rojo del 26-oct era ESTE camino)
//  Ahora, como ccGxPlace: su caja de texto real + 2 px lógicos al mirar y + 6 al marcar (≥ 8 px lógicos entre dos rótulos cualesquiera).
//  ROJO «labelgap» (CC_GX_BREAK): los márgenes de antes aquí y en ccGxPlace; «ringgap»: solo los de aquí. Función aparte para que T18 la
//  barra con un proyector fijo.
function ccGxRingLabel(g, R, O, P, rr2, fS, sc, bounds, color) {
   var txt = ccGxF("gxRing", { n: rr2 }), angs = [], rwT = fS.width(txt), oldGap = ccGxBroken("labelgap") || ccGxBroken("ringgap"), cpR = Math.round(2 * sc), mpR = Math.round(6 * sc);
   for (var aa = 0; aa < 18; ++aa) angs.push(-0.7 + (aa % 2 ? 1 : -1) * Math.ceil(aa / 2) * 0.35);
   for (var an = 0; an < angs.length; ++an) {
      var qr = P.pt(rr2 * Math.cos(angs[an] + Math.PI), rr2 * Math.sin(angs[an] + Math.PI), 0);
      if (!qr.ok) continue;
      var rbx0 = qr.x + 2, rby0 = qr.y - fS.ascent, rbx1 = rbx0 + rwT, rby1 = qr.y + fS.descent;
      var c0 = oldGap ? ccGxOccCost(O, qr.x - 2, qr.y - fS.ascent - 2, qr.x + rwT + 2, qr.y + 3, bounds)
                      : ccGxOccCost(O, rbx0 - cpR, rby0 - cpR, rbx1 + cpR, rby1 + cpR, bounds);
      if (c0.hard !== 0 || c0.soft !== 0) continue;
      ccGxHalo(g, R, fS, color, qr.x + 2, qr.y, txt, sc);
      if (oldGap) ccGxOccMark(O, qr.x - 2, qr.y - fS.ascent - 2, qr.x + rwT + 4, qr.y + 3, 2);
      else ccGxOccMark(O, rbx0 - mpR, rby0 - mpR, rbx1 + mpR, rby1 + mpR, 2);
      var rect = { x0: rbx0, y0: rby0, x1: rbx1, y1: rby1, text: txt };
      R.labels.push(rect);
      return rect;
   }
   return null;
}

// ---------------------------------------------------------------------------
// EL RESPLANDOR DE LA VÍA LÁCTEA (la masa del potencial: cc_galaxy.js · ccGxSigmaTable)
// ---------------------------------------------------------------------------
var CC_GX_GLOW_CACHE = {};
function ccGxGlowRgba(v) {
   // de un crema tenue a oro claro; alfa con el brillo (diseño: el disco a R0 ≈ 0,56 sale con alfa ≈ 0,2)
   if (v <= 0.12) return 0;
   var t = Math.min(1, (v - 0.12) / 0.88), c = ccHexRgb(ccMix(CC_ATLAS.text3, CC_ATLAS.goldLight, Math.pow(t, 1.4)));
   return ccRgbInt(c, Math.min(0.62, 0.62 * Math.pow(t, 1.7)));
}
// fn(cx, cy) -> brillo 0…1 en el centro de la celda; el bitmap a celdas de `cell` px sobre `rect`
function ccGxGlowBitmap(key, rect, cell, fn) {
   if (key && CC_GX_GLOW_CACHE[key]) return CC_GX_GLOW_CACHE[key];
   var nx = Math.max(2, Math.ceil(rect.w / cell)), ny = Math.max(2, Math.ceil(rect.h / cell)), b = new Bitmap(nx, ny);
   b.fill(0x00000000);
   for (var j = 0; j < ny; ++j) for (var i = 0; i < nx; ++i) {
      var c = ccGxGlowRgba(fn(rect.x + (i + 0.5) * cell, rect.y + (j + 0.5) * cell));
      if (c) b.setPixel(i, j, c);
   }
   var out = { bmp: b, w: nx * cell, h: ny * cell };
   if (key) { var n = 0; for (var k in CC_GX_GLOW_CACHE) if (CC_GX_GLOW_CACHE.hasOwnProperty(k)) ++n; if (n > 8) CC_GX_GLOW_CACHE = {}; CC_GX_GLOW_CACHE[key] = out; }
   return out;
}
function ccGxDrawGlow(g, rect, gb) {
   g.smoothInterpolation = true;
   g.drawScaledBitmap(rect.x, rect.y, rect.x + gb.w, rect.y + gb.h, gb.bmp);
}
function ccGxSigmaAt(R) { var T = ccGxSigmaTable(); return ccGxLookup(T.disc, T, R) + ccGxLookup(T.bulge, T, R); }

// ---------------------------------------------------------------------------
// EL PROYECTOR de cada vista: pt(X, Y, Z) -> { x, y, ok, m (perspectiva: 1 en el pivote), z (profundidad) }
// ---------------------------------------------------------------------------
function ccGxProjector(G, V, rect) {
   if (V.mode === "edge") {
      var xe = ccGxEdgeXf(G, rect, V.v2 ? V.v2.edge : null);
      return { kind: "edge", xf: xe, pt: function(X, Y, Z) { var q = xe.px(Math.sqrt(X * X + Y * Y), Z); q.ok = true; q.m = 1; q.z = 0; return q; } };
   }
   if (V.mode === "3d") {
      // (23-oct, noche: sin cámara del usuario, la pose de fábrica que llena el lienzo —ccGxAutoPose—)
      var cam = ccGxCam(G.ext.box, rect, V.cam || ccGxAutoPose(G.ext.box, rect));
      return { kind: "3d", cam: cam, pt: function(X, Y, Z) { var q = cam.px(X, Y, Z); q.m = q.w; return q; } };
   }
   var xt = ccGxTopXf(G, rect, V.v2 ? V.v2.top : null);
   return { kind: "top", xf: xt, pt: function(X, Y) { var q = xt.px(X, Y); q.ok = true; q.m = 1; q.z = 0; return q; } };
}
// Una polilínea del mundo, proyectada y partida donde se sale por detrás de la cámara.
function ccGxPolyline(g, P, pts3, pen) {
   g.pen = pen; ccGxNoBrush(g);
   var run = [];
   for (var i = 0; i < pts3.length; ++i) {
      var q = P.pt(pts3[i][0], pts3[i][1], pts3[i][2]);
      if (!q.ok) { if (run.length > 1) g.drawPolyline(run); run = []; continue; }
      run.push(new Point(q.x, q.y));
   }
   if (run.length > 1) g.drawPolyline(run);
}
// O (la rejilla): si se da, cada punto de la línea ocupa su celda como «blando» (los rótulos evitan las órbitas si pueden)
function ccGxTrajPolyline(g, P, tr, i0, i1, step, pen, O) {
   g.pen = pen; ccGxNoBrush(g);
   // (23-oct, revisor R1: tramos rectos de cientos de px en las de halo junto al pericentro) un tramo que en pantalla mida más de
   // 10 px se subdivide por la curva suave (ccGxAtSmooth); ROJO «trailold»: sin subdividir
   var run = [], last = Math.min(tr.n - 1, i1), prevQ = null, prevI = -1, segMax = 10 * (typeof CC_GX_SCALE === "number" ? CC_GX_SCALE : 1), qs = [0, 0, 0];
   for (var i = Math.max(0, i0); i <= last; i += step) {
      var q = P.pt(tr.x[i], tr.y[i], tr.z[i]);
      if (!q.ok) { if (run.length > 1) g.drawPolyline(run); run = []; prevQ = null; continue; }
      if (prevQ && !ccGxBroken("trailold")) {
         var dL = Math.sqrt((q.x - prevQ.x) * (q.x - prevQ.x) + (q.y - prevQ.y) * (q.y - prevQ.y));
         if (dL > segMax) {
            var mS = Math.min(12, Math.ceil(dL / segMax));
            for (var js = 1; js < mS; ++js) { ccGxAtSmooth(tr, null, (prevI + (i - prevI) * js / mS) * tr.dtMyr, qs); var qq = P.pt(qs[0], qs[1], qs[2]); if (qq.ok) run.push(new Point(qq.x, qq.y)); }
         }
      }
      prevQ = q; prevI = i;
      run.push(new Point(q.x, q.y));
      if (O) { var ci = Math.floor(q.x / O.cell), cj = Math.floor(q.y / O.cell); if (ci >= 0 && cj >= 0 && ci < O.nx && cj < O.ny && O.a[cj * O.nx + ci] < 1) O.a[cj * O.nx + ci] = 1; }
      if (i + step > last && i !== last) i = last - step;     // (el último punto, siempre)
   }
   if (run.length > 1) g.drawPolyline(run);
}
// LA ESTELA del vídeo (23-oct, revisor R1): de tA a tB (Myr; tA puede ser NEGATIVO: el pasado de e.past), por la curva suave
// (ccGxAtSmooth), con los tramos subdivididos hasta que ninguno mida más de 6 px lógicos en pantalla, y con FUNDIDO: la cola se apaga
// (6 tramos de opacidad y grosor crecientes hacia la estrella). `st` (opcional) apunta lo pintado para las pruebas.
var CC_GX_TRAIL = { SEG_PX: 6, MAX_SUB: 12, BUCKETS: 6 };
// (23-oct, la Galaxia en el tiempo) `opt` = { flat (0…1: 1 = sin fundido, el anillo entero igual: la estela LARGA del reloj deprisa),
// segPx (el tramo máximo, px lógicos; de fábrica SEG_PX) }
function ccGxTrail(g, P, e, tA, tB, rgb, amax, lw, sc, O, st, opt) {
   var tr = e.tr, past = e.past, dt = tr.dtMyr, t0 = Math.max(tA, (past && past.n > 1) ? -(past.n - 1) * dt : 0);
   if (!(tB > t0)) return;
   var times = [t0], k, flat = (opt && opt.flat > 0) ? Math.min(1, opt.flat) : 0;
   for (k = Math.floor(t0 / dt) + 1; k * dt < tB - 1e-9; ++k) times.push(k * dt);
   times.push(tB);
   var q = [0, 0, 0], pts = [], ts = [], segMax = ((opt && opt.segPx > 0) ? opt.segPx : CC_GX_TRAIL.SEG_PX) * sc, i, j;
   function proj(t) { ccGxAtSmooth(tr, past, t, q); return P.pt(q[0], q[1], q[2]); }
   var pa = proj(times[0]);
   pts.push(pa); ts.push(times[0]);
   for (i = 1; i < times.length; ++i) {
      var pb = proj(times[i]), L = (pa.ok && pb.ok) ? Math.sqrt((pb.x - pa.x) * (pb.x - pa.x) + (pb.y - pa.y) * (pb.y - pa.y)) : 0;
      var m = Math.min(CC_GX_TRAIL.MAX_SUB, Math.max(1, Math.ceil(L / segMax)));
      for (j = 1; j < m; ++j) { var tj = times[i - 1] + (times[i] - times[i - 1]) * j / m; pts.push(proj(tj)); ts.push(tj); }
      pts.push(pb); ts.push(times[i]); pa = pb;
   }
   var NB = CC_GX_TRAIL.BUCKETS, span = tB - t0, b = -1, run = [], lastPt = null;
   ccGxNoBrush(g);
   function flush() {
      if (run.length < 2) return;
      var fr = (b + 1) / NB, aa = amax * ((1 - flat) * Math.pow(fr, 1.4) + flat * 0.55), ww = lw * ((1 - flat) * (0.55 + 0.45 * fr) + flat * 0.8);
      g.pen = new Pen(ccRgbInt(rgb, aa), Math.max(1, ww)); g.drawPolyline(run);
   }
   for (i = 0; i < pts.length; ++i) {
      var bi = Math.min(NB - 1, Math.floor((ts[i] - t0) / span * NB)), p = pts[i];
      if (bi !== b) { flush(); run = lastPt ? [lastPt] : []; b = bi; }
      if (!p.ok) { flush(); run = []; lastPt = null; continue; }
      var np = new Point(p.x, p.y);
      run.push(np); lastPt = np;
      if (O) { var ci = Math.floor(p.x / O.cell), cj = Math.floor(p.y / O.cell); if (ci >= 0 && cj >= 0 && ci < O.nx && cj < O.ny && O.a[cj * O.nx + ci] < 1) O.a[cj * O.nx + ci] = 1; }
   }
   flush();
   if (st) {
      st.n++; if (t0 < -1e-6) st.fromPast++;
      var len = 0, mx = 0;
      for (i = 1; i < pts.length; ++i) if (pts[i].ok && pts[i - 1].ok) { var d = Math.sqrt((pts[i].x - pts[i - 1].x) * (pts[i].x - pts[i - 1].x) + (pts[i].y - pts[i - 1].y) * (pts[i].y - pts[i - 1].y)); len += d; if (d > mx) mx = d; }
      st.maxSegPx = Math.max(st.maxSegPx, mx / sc); st.minPts = Math.min(st.minPts, pts.length); st.sumPx += len / sc;
   }
}
// (la cuenta de la estela de antes, para el rojo «trailold»: los puntos de 2 Myr tal cual)
function ccGxTrailStat(st, P, tr, past, tA, tB, old) {
   var i0 = Math.max(0, Math.round(tA / tr.dtMyr)), i1 = Math.min(tr.n - 1, Math.round(tB / tr.dtMyr)), prev = null, len = 0, mx = 0, n = 0;
   for (var i = i0; i <= i1; ++i) {
      var q = P.pt(tr.x[i], tr.y[i], tr.z[i]); ++n;
      if (prev && prev.ok && q.ok) { var d = Math.sqrt((q.x - prev.x) * (q.x - prev.x) + (q.y - prev.y) * (q.y - prev.y)); len += d; if (d > mx) mx = d; }
      prev = q;
   }
   st.n++; st.maxSegPx = Math.max(st.maxSegPx, mx / (st.sc || 1)); st.minPts = Math.min(st.minPts, n); st.sumPx += len / (st.sc || 1);
}
function ccGxNiceStep(span, n) {
   var raw = span / Math.max(1, n), p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), m = raw / p;
   return (m < 1.5 ? 1 : (m < 3.5 ? 2 : (m < 7.5 ? 5 : 10))) * p;
}

// ---------------------------------------------------------------------------
// EL MAPA, en dos capas: la BASE (lo caro: resplandor, referencia, órbitas, puntos, el Sol y el centro; no depende de la
// elegida, el lienzo la guarda en un bitmap) y ENCIMA (la elegida, leyenda, escala, ejes, rótulos, pie: lo barato).
// (22-oct: las 809 órbitas de M 67 con el encuadre de cerca tardaban 1,4 s en pintarse: elegir una estrella no puede
//  costar eso. ccGalaxyPaint pinta las dos; el lienzo de cc_galaxy_ui.js reutiliza la base mientras no cambie su clave.)
// ---------------------------------------------------------------------------
function ccGalaxyPaint(g, w, h, G, sc, view) {
   var V = view || (G && G.ui) || ccGalaxyDefaultUi();
   var C = ccGxPaintBase(g, w, h, G, sc, V);
   if (C.empty) return C.R;
   return ccGxPaintOver(g, w, h, G, sc, V, C);
}
// La clave de la base: si no cambia, el bitmap guardado vale (la elegida NO entra: va encima).
function ccGxBaseKey(G, V, w, h, sc) {
   var m = V.mode, v2 = (V.v2 && V.v2[m]) ? V.v2[m] : null, cam = (m === "3d" && V.cam) ? ccGxCamView(V.cam) : null;
   // (ROJO «stalebase»: la clave sin el color) (23-oct: el resto de la clave estaba DENTRO de este comentario —brazos, arrastre, tMyr,
   //  estela, marco no contaban—; ahora en su línea)
   return [G ? G.stamp : "-", m, V.show, ccGxBroken("stalebase") ? "" : V.color,
           V.arms !== false ? 1 : 0, V.light ? 1 : 0, V.tMyr || 0, V.trail || 0, V.chrome === false ? 0 : 1,
           v2 ? [v2.k, v2.cx, v2.cy].join(",") : "", cam ? [cam.yaw, cam.pitch, cam.zoom, cam.ox, cam.oy, cam.oz, cam.f0, cam.cx, cam.cy].join(",") : "",
           w, h, sc, (typeof CC_LANG !== "undefined") ? CC_LANG : "", CC_GX_BREAK,
           // (23-oct, la Galaxia en el tiempo: lo que cambia con el reloj y si el pasado ya está calculado)
           V.trailFlat || 0, V.trailSeg || 0, ccIsNum(V.dotAlpha) ? V.dotAlpha : 1, ccIsNum(V.noAgeAlpha) ? V.noAgeAlpha : 1, V.flash ? 1 : 0,
           (G && G.deep) ? G.deep.n : -1, (typeof CC_BREAK === "string") ? CC_BREAK : ""].join("|");
}
// Para pintar ENCIMA de una base guardada: el contexto con su rejilla y su informe COPIADOS (los rótulos no se acumulan).
function ccGxCloneCtx(C) {
   var D = {};
   for (var k in C) if (C.hasOwnProperty(k)) D[k] = C[k];
   D.O = { cell: C.O.cell, nx: C.O.nx, ny: C.O.ny, w: C.O.w, h: C.O.h, a: new Uint8Array(C.O.a) };
   var R = {};
   for (k in C.R) if (C.R.hasOwnProperty(k)) R[k] = C.R[k];
   R.texts = C.R.texts.slice(); R.labels = C.R.labels.slice(); R.dropped = C.R.dropped; R.sel = null; R.legend = null; R.scale = null;
   D.R = R;
   return D;
}
function ccGxPaintBase(g, w, h, G, sc, V) {
   var A = CC_ATLAS, t0 = Date.now();
   CC_GX_SCALE = sc;
   var R = { texts: [], labels: [], legend: null, scale: null, dropped: 0, mode: V.mode, w: w, h: h, nStars: 0, nOrbits: 0, ms: 0, sun: null, gc: null, sel: null, hard: [] };
   g.antialiasing = true; g.textAntialiasing = true;
   g.fillRect(0, 0, w, h, new Brush(ccInt(A.bg)));
   var fT = ccFont("text", 8.6 * sc, false, false, Math.round(8.6 * sc * A.labelTracking)), fN = ccFont("display", 13 * sc, false, true);
   var fL = ccFont("text", 8.4 * sc), fLb = ccFont("text", 8.4 * sc, true), fS = ccFont("text", 7.8 * sc), fSun = ccFont("display", 9 * sc, false, true);
   // (V.chrome === false: el vídeo; sin título, pie ni marco: el mapa ocupa el fotograma y la placa la pone ccGalaxyVideo)
   var chrome = (V.chrome !== false), padX = chrome ? Math.round(10 * sc) : 0, headH = chrome ? Math.round(26 * sc) : 0, footH = chrome ? Math.round(18 * sc) : 0;
   // (2-nov-2026, T22 W3: «819 c…») con las órbitas dibujadas CON la barra el pie lleva una frase más (gxFootBarNote: «dibujadas con la barra, cifras sin
   //  ella»); en la misma línea no cabía y se cortaba el recuento. Esa frase va en una SEGUNDA línea del pie, que solo existe en ese caso (el mapa pierde
   //  esa altura; se reserva también en el pasado, aunque allí la frase no se pinte: si el mapa creciera al mover el reloj, todas las estrellas «se moverían», T21 V1). ROJO «footonerow» (CC_GX_BREAK o CC_BREAK): la frase larga en la misma línea, como antes.
   var barNote = chrome && (V.show === "orbit" || V.trail > 0) && (typeof ccBarOn === "function" && ccBarOn()) &&
                 !ccGxBroken("footonerow") && !(typeof CC_BREAK === "string" && CC_BREAK.indexOf("footonerow") >= 0);
   if (barNote) footH = Math.round(26 * sc);           // (26 y no 30: cada px lógico de menos le quita sitio a los rótulos del mapa, T17 X5/X12)
   R.barNote = barNote;
   var rect = { x: padX, y: headH, w: Math.max(20, w - 2 * padX), h: Math.max(20, h - headH - footH) };
   var O = ccGxOcc(w, h, sc);
   // --- el título: «Vía Láctea  DESDE ARRIBA (X–Y)» ---
   // (23-oct, revisor R19: el mapa se rotulaba «III», el número del GRUPO, como si fuera un panel más de A–E. Ahora, como A–E: el nombre en
   //  la cursiva dorada de sus letras y la vista en versalitas; sin número)
   var sub = ccGxT(V.mode === "edge" ? "gxTitleEdge" : (V.mode === "3d" ? "gxTitle3d" : "gxTitleTop"));
   var cut = sub.indexOf("("), subCaps = (cut > 0) ? sub.substring(0, cut).toUpperCase() + sub.substring(cut) : sub.toUpperCase();
   var tx = padX, ty = Math.round(17 * sc), gname = ccGxT("gxTitleName");
   if (chrome) {
      ccGxText(g, R, fN, ccInt(A.gold), tx, ty, gname);
      tx += fN.width(gname) + Math.round(9 * sc);
      ccGxText(g, R, fT, ccInt(A.text3), tx, ty - Math.round(1 * sc), subCaps);
   }
   if (!G || !G.res) {
      var fm = ccFont("text", 10 * sc, false, true), msg = ccGxT("gxNoRes");
      ccGxText(g, R, fm, ccInt(A.text2), rect.x + (rect.w - fm.width(msg)) / 2, rect.y + rect.h / 2, msg);
      R.ms = Date.now() - t0;
      return { empty: true, R: R };
   }
   // (23-oct, noche, revisión visual 5: la leyenda iba a la esquina con menos datos —cambiaba de esquina con la vista y a 1360 × 880
   //  tapaba órbitas—. En el diálogo va ahora en una FRANJA bajo el mapa, fuera de los datos, en el mismo sitio en las tres vistas; el
   //  vídeo —sin marco— sigue con su esquina. ROJO «legband» de T22: vuelve a la esquina)
   rect.band = null;
   if (chrome && V.legend !== false && !ccGxBroken("legband") && !ccGxBroken("legcorner")) {
      var bandH = ccGxLegendBand(g, R, V, G, rect.x, 0, rect.w, sc, true).h, bandGap = Math.round(4 * sc);
      if (rect.h - bandH - bandGap > 80 * sc) { rect.h -= bandH + bandGap; rect.band = { x: rect.x, y: rect.y + rect.h + bandGap, w: rect.w, h: bandH }; }
   }
   R.rect = { x: rect.x, y: rect.y, w: rect.w, h: rect.h };
   g.fillRect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h, new Brush(ccInt(CC_INSET)));
   var P = ccGxProjector(G, V, rect), bounds = { x: rect.x + 2, y: rect.y + 2, w: rect.w - 4, h: rect.h - 4 };
   ccGxOccMark(O, 0, 0, w, rect.y, 2); ccGxOccMark(O, 0, rect.y + rect.h, w, h, 2);
   g.clipRect = new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
   // --- 1 · el resplandor (la masa del potencial) ---
   var cell = Math.max(3, Math.round(3.5 * sc)), gb = null;
   if (P.kind === "top") {
      var xt = P.xf;
      gb = ccGxGlowBitmap(["top", rect.x, rect.y, rect.w, rect.h, cell, xt.ppk.toFixed(4), xt.ca.toFixed(3), xt.cb.toFixed(3)].join("|"), rect, cell,
         function(sx, sy) { var q = xt.inv(sx, sy); return ccGxGlowOf(ccGxSigmaAt(Math.sqrt(q.X * q.X + q.Y * q.Y))); });
   } else if (P.kind === "edge") {
      var xe = P.xf;
      gb = ccGxGlowBitmap(["edge", rect.x, rect.y, rect.w, rect.h, cell, xe.sx.toFixed(4), xe.sz.toFixed(4), xe.cR.toFixed(3), xe.cz.toFixed(3)].join("|"), rect, cell,
         function(sx, sy) { var q = xe.inv(sx, sy), Rr = Math.abs(q.R); return ccGxGlowOf((ccGxRhoDisc(Rr, q.z) + ccGxRhoBulge(Math.sqrt(Rr * Rr + q.z * q.z))) * 1.0); });
   } else {
      // (el resplandor es suave: unas 170 celdas a lo ancho bastan a cualquier tamaño; a 4,5 px fijos un fotograma 4K del vídeo
      //  eran 400 000 rayos)
      var cam = P.cam, Tb = ccGxSigmaTable(), cl = Math.max(4, Math.round(4.5 * sc), Math.ceil(rect.w / 170));
      gb = ccGxGlowBitmap(V.light ? "" : ["3d", rect.x, rect.y, rect.w, rect.h, cl, cam.view.yaw.toFixed(3), cam.view.pitch.toFixed(3), cam.view.zoom.toFixed(4), cam.view.ox.toFixed(3), cam.view.oy.toFixed(3), cam.view.oz.toFixed(3), cam.f0.toFixed(4)].join("|"), rect, cl,
         function(sx, sy) {
            var r = cam.ray(sx, sy), o = r.o, d = r.d, dl = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]), sig = 0;
            // el disco: donde el rayo cruza z = 0, con el camino oblicuo por la lámina (ópticamente delgada: Σ / |cos i|, tope 6)
            if (Math.abs(d[2]) > 1e-9) {
               var s = -o[2] / d[2];
               if (s > 0) { var X = o[0] + s * d[0], Y = o[1] + s * d[1]; sig += ccGxLookup(Tb.disc, Tb, Math.sqrt(X * X + Y * Y)) * Math.min(6, dl / Math.abs(d[2])); }
            }
            // el bulbo: la distancia del rayo al centro (si el punto más cercano está delante de la cámara)
            var sc0 = -(o[0] * d[0] + o[1] * d[1] + o[2] * d[2]) / (dl * dl);
            if (sc0 > 0) { var px0 = o[0] + sc0 * d[0], py0 = o[1] + sc0 * d[1], pz0 = o[2] + sc0 * d[2]; sig += ccGxLookup(Tb.bulge, Tb, Math.sqrt(px0 * px0 + py0 * py0 + pz0 * pz0)); }
            return ccGxGlowOf(sig);
         });
      cell = cl;
   }
   if (gb) ccGxDrawGlow(g, rect, gb);
   // --- 2 · la referencia: círculos de radio, brazos ilustrativos, plano, ejes ---
   var ringPen = ccGxPen(ccInt(A.text3, 0.28), Math.max(1, 0.8 * sc), true), ringLbl = [];
   if (P.kind === "top" || P.kind === "3d") {
      var maxRing = (P.kind === "top") ? G.ext.top.half * 1.45 / P.xf.k + Math.sqrt(P.xf.ca * P.xf.ca + P.xf.cb * P.xf.cb) : G.ext.top.half * 1.1;
      if (V.arms !== false && !ccGxBroken("noarms")) {
         var arms = ccGxArms();
         for (var ai = 0; ai < arms.length; ++ai) {
            var a3 = []; for (var aj = 0; aj < arms[ai].length; ++aj) a3.push([arms[ai][aj][0], arms[ai][aj][1], 0]);
            ccGxPolyline(g, P, a3, new Pen(ccInt(A.goldLight, 0.055), Math.max(2, 9 * sc * (P.kind === "top" ? Math.min(1.6, P.xf.k) : 1))));
            ccGxPolyline(g, P, a3, new Pen(ccInt(A.goldLight, 0.10), Math.max(1, 1.2 * sc)));
         }
      }
      for (var ri = 0; ri < CC_GX.RINGS.length; ++ri) {
         var rr = CC_GX.RINGS[ri];
         if (rr > maxRing) continue;
         var c3 = [];
         for (var th = 0; th <= 2 * Math.PI + 1e-9; th += Math.PI / 60) c3.push([rr * Math.cos(th), rr * Math.sin(th), 0]);
         ccGxPolyline(g, P, c3, ringPen);
         ringLbl.push(rr);
      }
   } else {
      // de canto: la rejilla de R y z, el plano del disco
      var xe2 = P.xf, R0e = xe2.inv(rect.x, 0).R, R1e = xe2.inv(rect.x + rect.w, 0).R, z1e = xe2.inv(0, rect.y).z, z0e = xe2.inv(0, rect.y + rect.h).z;
      var stR = ccGxNiceStep(R1e - R0e, 6), stZ = ccGxNiceStep(z1e - z0e, 5), gpen = new Pen(ccInt(A.text3, 0.12), 1);
      g.pen = gpen;
      for (var gr = Math.ceil(R0e / stR) * stR; gr <= R1e; gr += stR) { var qx = xe2.px(gr, 0).x; g.drawLine(qx, rect.y, qx, rect.y + rect.h); }
      for (var gz = Math.ceil(z0e / stZ) * stZ; gz <= z1e; gz += stZ) { var qy = xe2.px(0, gz).y; g.drawLine(rect.x, qy, rect.x + rect.w, qy); }
      var yPl = xe2.px(0, 0).y;
      g.pen = ccGxPen(ccInt(A.text3, 0.45), Math.max(1, 0.9 * sc), true); g.drawLine(rect.x, yPl, rect.x + rect.w, yPl);
   }
   // --- 3 · dónde está cada estrella (hoy o a tMyr) ---
   var N = G.stars.length, tNow = ccIsNum(V.tMyr) ? V.tMyr : 0, pos = new Array(N), q3 = [0, 0, 0], oldTrail = ccGxBroken("trailold");
   var pxs = new Float32Array(N), pys = new Float32Array(N), pzs = new Float32Array(N), pms = new Float32Array(N), okv = new Uint8Array(N);
   // (23-oct, LA GALAXIA EN EL TIEMPO: tNow < 0 = el pasado —cc_galaxy_time.js—. Cada estrella a su sitio de entonces y encendida con la
   //  regla de «La historia del campo» (fB, 0…1); las sin edad, apagadas en el pasado; en el final del vídeo —hoy— se encienden con
   //  V.noAgeAlpha. ROJO «gxtfrozen»: no se mueven)
   var pastNow = (tNow < 0), Tga = pastNow ? -tNow / 1000 : 0, timed = pastNow || ccIsNum(V.noAgeAlpha), fB = new Float32Array(N);
   if (pastNow && !G.deep && typeof ccGalaxyDeepPast === "function") ccGalaxyDeepPast(G);      // (sin su pasado, el punto se quedaría a 60 Ma)
   R.time = timed ? { T: -Math.min(0, tNow), lit: 0, fading: 0, nAge: 0, noAge: 0, unbound: 0, shown: 0, sunBorn: true } : null;
   for (var i = 0; i < N; ++i) {
      var e = G.stars[i], X0 = e.x, Y0 = e.y, Z0 = e.z;
      fB[i] = 1;
      if (timed) {
         var bth = ccGxtBirth(e, Tga);
         if (bth < 0) { ++R.time.noAge; fB[i] = pastNow ? 0 : Math.max(0, Math.min(1, V.noAgeAlpha)); }
         else { ++R.time.nAge; fB[i] = bth; if (pastNow && !e.tr) { ++R.time.unbound; fB[i] = 0; } else if (bth >= 0.5) ++R.time.lit; else if (bth > 0.004) ++R.time.fading; }
         if (fB[i] > 0.004) ++R.time.shown;
      }
      // (el punto, en la MISMA curva que su estela: Catmull-Rom; ROJO «trailold»: lineal, como antes)
      if (tNow !== 0 && e.tr && !(pastNow && ccGxtBroken("gxtfrozen"))) { if (oldTrail && tNow > 0) ccGxAt(e.tr, tNow, q3); else ccGxAtSmooth(e.tr, e.past, tNow, q3); X0 = q3[0]; Y0 = q3[1]; Z0 = q3[2]; }
      pos[i] = [X0, Y0, Z0];
      var q = P.pt(X0, Y0, Z0);
      pxs[i] = q.x; pys[i] = q.y; pzs[i] = q.z; pms[i] = q.m; okv[i] = (q.ok && fB[i] > 0.004) ? 1 : 0;
   }
   // --- 4 · las órbitas (o las estelas del vídeo) ---
   var showOrbit = (V.show === "orbit") || (V.trail > 0);
   if (showOrbit && N) {
      // (alfa por el número de órbitas: con 4,5/√N y tope 0,32 las 123 de Abell 39 eran una maraña dorada; captura del 22-oct)
      // (con muchas, un subconjunto: ccGxOrbitSubset; el alfa sigue al número DIBUJADO, y el pie dice cuántas)
      var sub = ccGxOrbitSubset(G, V.light ? CC_GX.MAX_ORBITS_LIGHT : CC_GX.MAX_ORBITS), nWith = 0;
      for (i = 0; i < N; ++i) if (G.stars[i].tr) ++nWith;
      var alpha = Math.max(0.035, Math.min(0.25, 1.8 / Math.sqrt(Math.max(1, sub.length)))), lw = Math.max(1, 0.9 * sc), stepI = V.light ? 3 : 1;
      var nShow = Math.round(CC_GX.SHOW_MYR / CC_GX.DT_MYR / CC_GX.EVERY);
      R.orbitsDrawn = sub.length; R.orbitsAll = nWith;
      R.trail = { n: 0, fromPast: 0, maxSegPx: 0, minPts: 1e9, sumPx: 0, sc: sc };
      for (var si = 0; si < sub.length; ++si) {
         i = sub[si];
         var eo = G.stars[i], fo = fB[i];
         if (!eo.tr || !(fo > 0.004)) continue;      // (en el pasado: las que aún no han nacido, sin órbita)
         var co = ccGxColorOf(eo, V.color);
         if (V.trail > 0) {
            if (V.show === "orbit") {
               if (pastNow) ccGxtPath(g, P, eo, tNow, tNow + CC_GX.SHOW_MYR, stepI * 2, new Pen(ccRgbInt(co.rgb, alpha * 0.35 * fo), lw), null, sc);
               else ccGxTrajPolyline(g, P, eo.tr, 0, nShow, stepI * 2, new Pen(ccRgbInt(co.rgb, alpha * 0.35 * fo), lw));
            }
            if (oldTrail) {
               // (ROJO «trailold» de T18: la estela de antes —tramos de 2 Myr, desde t = 0 aunque falte, borde seco—)
               var iT = Math.floor(Math.max(0, tNow) / eo.tr.dtMyr), iT0 = Math.max(0, iT - Math.round(V.trail / eo.tr.dtMyr));
               ccGxTrajPolyline(g, P, eo.tr, iT0, iT, 1, new Pen(ccRgbInt(co.rgb, Math.min(0.75, alpha * 2.6)), Math.max(1, 1.2 * sc)), O);
               ccGxTrailStat(R.trail, P, eo.tr, null, iT0 * eo.tr.dtMyr, iT * eo.tr.dtMyr, true);
            } else ccGxTrail(g, P, eo, tNow - V.trail, tNow, co.rgb, Math.min(0.75, alpha * 2.6) * fo, Math.max(1, 1.2 * sc), sc, O, R.trail, { flat: V.trailFlat || 0, segPx: V.trailSeg || 0 });
         } else if (pastNow) ccGxtPath(g, P, eo, tNow, tNow + CC_GX.SHOW_MYR, stepI, new Pen(ccRgbInt(co.rgb, alpha * fo), lw), O, sc);
         else ccGxTrajPolyline(g, P, eo.tr, 0, nShow, stepI, new Pen(ccRgbInt(co.rgb, alpha * fo), lw), O);
         R.nOrbits++;
      }
   }
   // --- 5 · el Sol: su órbita y su sitio; el centro galáctico ---
   var sp = G.sun, sx3 = [sp.x, sp.y, sp.z], sunBorn = !(pastNow && Tga > ccGxtSunAge());     // (el Sol, en el pasado, solo desde que nace: 4,57 Ga)
   if (R.time) R.time.sunBorn = sunBorn;
   if (tNow > 0 && sp.tr && sp.tr.n) sx3 = ccGxAt(sp.tr, tNow, [0, 0, 0]);
   if (pastNow && sp.tr && sp.tr.n) sx3 = ccGxAtSmooth(sp.tr, sp.past || null, tNow, [0, 0, 0]);
   if (sunBorn && sp.tr && sp.tr.n && (showOrbit || V.mode === "top")) {
      var nS = Math.round(CC_GX.SHOW_MYR / CC_GX.DT_MYR / CC_GX.EVERY), sunPen = ccGxPen(ccInt(A.gold, showOrbit ? 0.55 : 0.30), Math.max(1, 1.0 * sc), true);
      if (pastNow && sp.past) ccGxtPath(g, P, sp, tNow, tNow + CC_GX.SHOW_MYR, V.light ? 2 : 1, sunPen, null, sc);
      else ccGxTrajPolyline(g, P, sp.tr, 0, nS, V.light ? 2 : 1, sunPen);
   }
   // la flecha del giro (vista de arriba y 3D): un arco del círculo de R0 por el otro lado del centro
   if (P.kind !== "edge") {
      var R0 = CC_SCI.R0_KPC, arc = [];
      for (var ph = 2.0; ph <= 2.9 + 1e-9; ph += 0.03) arc.push([-R0 * Math.cos(ph), R0 * Math.sin(ph), 0]);
      ccGxPolyline(g, P, arc, new Pen(ccInt(A.bg, 0.6), Math.max(2, 3.4 * sc)));
      ccGxPolyline(g, P, arc, new Pen(ccInt(A.goldLight, 0.9), Math.max(1.5, 1.6 * sc)));
      // (23-oct, revisor R3: el rótulo de la elegida se pintaba ENCIMA de la flecha del giro —la flecha no estaba en la rejilla—; ahora
      //  la flecha es «dura»: ningún rótulo la pisa. ROJO «noarrowocc» de T18: sin marcar)
      R.arrowPts = [];
      for (var ap = 0; ap < arc.length; ++ap) {
         var qap = P.pt(arc[ap][0], arc[ap][1], 0);
         if (!qap.ok) continue;
         R.arrowPts.push([qap.x, qap.y]);
         if (!ccGxBroken("noarrowocc")) ccGxOccMark(O, qap.x - 4 * sc, qap.y - 4 * sc, qap.x + 4 * sc, qap.y + 4 * sc, 2);
      }
      var qa = P.pt(arc[arc.length - 1][0], arc[arc.length - 1][1], 0), qb = P.pt(arc[arc.length - 3][0], arc[arc.length - 3][1], 0);
      if (qa.ok && qb.ok) {
         var ux = qa.x - qb.x, uy = qa.y - qb.y, ul = Math.sqrt(ux * ux + uy * uy) || 1, hk = 7 * sc;
         ux /= ul; uy /= ul;
         g.brush = new Brush(ccInt(A.goldLight, 0.95)); g.pen = new Pen(ccInt(A.bg, 0.6), 1);
         g.fillPolygon([new Point(qa.x + ux * hk * 0.4, qa.y + uy * hk * 0.4), new Point(qa.x - ux * hk - uy * hk * 0.5, qa.y - uy * hk + ux * hk * 0.5), new Point(qa.x - ux * hk + uy * hk * 0.5, qa.y - uy * hk - ux * hk * 0.5)]);
         ccGxNoBrush(g);
         R.arrow = { x: qa.x, y: qa.y, dx: ux, dy: uy };
         if (!ccGxBroken("noarrowocc")) ccGxOccMark(O, qa.x - hk * 1.2, qa.y - hk * 1.2, qa.x + hk * 1.2, qa.y + hk * 1.2, 2);
         R.arrowPts.push([qa.x, qa.y]);
      }
      var qm = P.pt(arc[Math.floor(arc.length / 2)][0], arc[Math.floor(arc.length / 2)][1], 0);
      if (qm.ok) R.arrowMid = { x: qm.x, y: qm.y };
   }
   // las estrellas (los puntos se apuntan como «blandos» en la rejilla)
   var order = (P.kind === "3d") ? ccGxDepthOrder(pzs, N) : null, rBase = (N > 400 ? 1.7 : 2.2) * sc;
   for (var oi = 0; oi < N; ++oi) {
      i = order ? order[oi] : oi;
      if (!okv[i]) continue;
      var es = G.stars[i], cs = ccGxColorOf(es, V.color), m = pms[i], rS = rBase * (P.kind === "3d" ? ccGxDepthSize(m) : 1), dim = (P.kind === "3d") ? ccGxDepthDim(m) : 1;
      if (pxs[i] < rect.x - 10 || pxs[i] > rect.x + rect.w + 10 || pys[i] < rect.y - 10 || pys[i] > rect.y + rect.h + 10) continue;
      // (la Galaxia en el tiempo: el encendido fB y, con el reloj deprisa, el punto tenue —V.dotAlpha—: se lee el anillo de su estela)
      dim *= fB[i] * (ccIsNum(V.dotAlpha) ? V.dotAlpha : 1);
      if (cs.hollow) g.strokeCircle(pxs[i], pys[i], rS, new Pen(ccRgbInt(cs.rgb, 0.75 * dim), Math.max(1, 0.9 * sc)));
      else g.fillCircle(pxs[i], pys[i], rS, new Brush(ccRgbInt(cs.rgb, 0.92 * dim)));
      // el anillo del nacimiento (vídeo): se abre y se apaga en FLASH_S segundos desde que el reloj cruza su edad
      if (V.flash && pastNow) { var pf = ccGxtFlash(es, -tNow); if (pf >= 0) { R.flashes = (R.flashes || 0) + 1; g.strokeCircle(pxs[i], pys[i], rS + (3 + 20 * pf) * sc, new Pen(ccRgbInt(cs.rgb, 0.85 * Math.pow(1 - pf, 1.5)), Math.max(1, 1.3 * sc))); } }
      ccGxOccMark(O, pxs[i] - rS, pys[i] - rS, pxs[i] + rS, pys[i] + rS, 1);
      R.nStars++;
   }
   // el Sol (encima de los puntos, como en B) y el centro
   var qs = P.pt(sx3[0], sx3[1], sx3[2]);
   if (qs.ok && sunBorn) {
      g.strokeCircle(qs.x, qs.y, 5 * sc, new Pen(ccInt(A.text, 0.95), Math.max(1, 1.2 * sc)));
      g.fillCircle(qs.x, qs.y, 1.5 * sc, new Brush(ccInt(A.text, 0.95)));
      ccGxOccMark(O, qs.x - 6 * sc, qs.y - 6 * sc, qs.x + 6 * sc, qs.y + 6 * sc, 2);
      R.sun = { x: qs.x, y: qs.y };
   }
   var qg = P.pt(0, 0, 0);
   if (qg.ok) {
      var gk = 5 * sc;
      g.pen = new Pen(ccInt(A.gold, 0.9), Math.max(1, 1.2 * sc));
      g.drawLine(qg.x - gk, qg.y, qg.x + gk, qg.y); g.drawLine(qg.x, qg.y - gk, qg.x, qg.y + gk);
      g.strokeCircle(qg.x, qg.y, 2.2 * sc, new Pen(ccInt(A.gold, 0.9), Math.max(1, 1.0 * sc)));
      ccGxOccMark(O, qg.x - gk, qg.y - gk, qg.x + gk, qg.y + gk, 2);
      R.gc = { x: qg.x, y: qg.y, k: gk };
   }
   g.clipRect = new Rect(0, 0, w, h);
   return { empty: false, R: R, O: O, P: P, rect: rect, bounds: bounds, N: N, pxs: pxs, pys: pys, pzs: pzs, pms: pms, okv: okv, pos: pos,
            ringLbl: ringLbl, chrome: chrome, tNow: tNow, t0: t0, fB: fB };
}
function ccGxPaintOver(g, w, h, G, sc, V, C) {
   CC_GX_SCALE = sc;
   var A = CC_ATLAS, t0 = Date.now(), R = C.R, O = C.O, P = C.P, rect = C.rect, bounds = C.bounds, N = C.N, pxs = C.pxs, pys = C.pys, pzs = C.pzs;
   var okv = C.okv, pos = C.pos, ringLbl = C.ringLbl, chrome = C.chrome, i;
   var fLb = ccFont("text", 8.4 * sc, true), fS = ccFont("text", 7.8 * sc), fSun = ccFont("display", 9 * sc, false, true);
   g.antialiasing = true; g.textAntialiasing = true;
   var selK = (ccIsNum(V.sel) && V.sel >= 0 && G.byIdx.hasOwnProperty(V.sel)) ? G.byIdx[V.sel] : -1;
   g.clipRect = new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
   // --- 6 · la elegida: su órbita entera (2 Gyr) tenue, sus 420 Myr marcados y su sitio ---
   var pastO = (C.tNow < 0);
   if (pastO && selK >= 0 && !okv[selK]) selK = -1;          // (en el pasado, la elegida aún sin nacer —o sin edad— no se marca)
   if (selK >= 0 && pastO) {
      // la elegida en el pasado: lo mismo, desde ESE instante (2 Ga tenues, 420 Ma marcados)
      var ekp = G.stars[selK], ckp = ccGxColorOf(ekp, V.color), ltp = ccGxLighter(ckp.rgb, 0.25), tq = C.tNow;
      if (ekp.tr) {
         ccGxtPath(g, P, ekp, tq, tq + CC_GX.T_MYR, V.light ? 4 : 1, new Pen(ccRgbInt(ltp, 0.28), Math.max(1, 0.9 * sc)), null, sc);
         ccGxtPath(g, P, ekp, tq, tq + CC_GX.SHOW_MYR, 1, new Pen(ccInt(A.bg, 0.55), Math.max(2, 3.6 * sc)), null, sc);
         ccGxtPath(g, P, ekp, tq, tq + CC_GX.SHOW_MYR, 1, new Pen(ccRgbInt(ltp, 0.95), Math.max(1.5, 1.7 * sc)), O, sc);
      }
      var xkp = pxs[selK], ykp = pys[selK];
      if (P.kind === "3d") { var qdp = P.pt(pos[selK][0], pos[selK][1], 0); if (qdp.ok) { g.pen = ccGxPen(ccRgbInt(ltp, 0.6), Math.max(1, 0.9 * sc), true); g.drawLine(xkp, ykp, qdp.x, qdp.y); g.fillCircle(qdp.x, qdp.y, 1.6 * sc, new Brush(ccRgbInt(ltp, 0.6))); } }
      if (ckp.hollow) g.strokeCircle(xkp, ykp, 3.2 * sc, new Pen(ccRgbInt(ckp.rgb, 1), Math.max(1, 1.2 * sc))); else g.fillCircle(xkp, ykp, 3.2 * sc, new Brush(ccRgbInt(ckp.rgb, 1)));
      g.strokeCircle(xkp, ykp, 7 * sc, new Pen(ccInt(A.gold), Math.max(1.5, 1.6 * sc)));
      ccGxOccMark(O, xkp - 8 * sc, ykp - 8 * sc, xkp + 8 * sc, ykp + 8 * sc, 2);
      R.sel = { x: xkp, y: ykp, k: selK, i: ekp.i };
   } else if (selK >= 0) {
      var ek = G.stars[selK], ck = ccGxColorOf(ek, V.color), lt = ccGxLighter(ck.rgb, 0.25);
      if (ek.tr) {
         ccGxTrajPolyline(g, P, ek.tr, 0, ek.tr.n - 1, V.light ? 4 : 1, new Pen(ccRgbInt(lt, 0.28), Math.max(1, 0.9 * sc)));
         var nSel = Math.round(CC_GX.SHOW_MYR / CC_GX.DT_MYR / CC_GX.EVERY);
         ccGxTrajPolyline(g, P, ek.tr, 0, nSel, 1, new Pen(ccInt(A.bg, 0.55), Math.max(2, 3.6 * sc)));
         ccGxTrajPolyline(g, P, ek.tr, 0, nSel, 1, new Pen(ccRgbInt(lt, 0.95), Math.max(1.5, 1.7 * sc)), O);
      }
      if (okv[selK]) {
         var xk = pxs[selK], yk = pys[selK];
         if (P.kind === "3d") {       // la caída hasta el plano del disco: se ve a qué altura está
            var qd = P.pt(pos[selK][0], pos[selK][1], 0);
            if (qd.ok) { g.pen = ccGxPen(ccRgbInt(lt, 0.6), Math.max(1, 0.9 * sc), true); g.drawLine(xk, yk, qd.x, qd.y); g.fillCircle(qd.x, qd.y, 1.6 * sc, new Brush(ccRgbInt(lt, 0.6))); }
         }
         if (ck.hollow) g.strokeCircle(xk, yk, 3.2 * sc, new Pen(ccRgbInt(ck.rgb, 1), Math.max(1, 1.2 * sc)));
         else g.fillCircle(xk, yk, 3.2 * sc, new Brush(ccRgbInt(ck.rgb, 1)));
         g.strokeCircle(xk, yk, 7 * sc, new Pen(ccInt(A.gold), Math.max(1.5, 1.6 * sc)));
         ccGxOccMark(O, xk - 8 * sc, yk - 8 * sc, xk + 8 * sc, yk + 8 * sc, 2);
         R.sel = { x: xk, y: yk, k: selK, i: ek.i };
      }
   }
   // --- 7 · la LEYENDA (arriba a la derecha) y la ESCALA (abajo a la derecha): se reservan antes de los rótulos ---
   g.clipRect = new Rect(0, 0, w, h);
   if (V.reserve) for (var rv = 0; rv < V.reserve.length; ++rv) ccGxOccMark(O, V.reserve[rv][0], V.reserve[rv][1], V.reserve[rv][2], V.reserve[rv][3], 2);
   // (23-oct) LA PLACA DEL TIEMPO del mapa de III (con el mando lejos de «hoy»): arriba a la izquierda, reservada antes que la leyenda
   var tPlate = null, tBox = null;
   if (pastO && chrome && V.timePlate !== false && R.time) {
      var lang0 = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en", T0 = R.time;
      var cnt0 = ccGxF("gxtBorn", { n: ccGxNumInt(T0.lit), m: ccGxNumInt(T0.nAge), t: ccGxNumInt(T0.nAge + T0.noAge) }) + (T0.noAge ? " · " + ccGxF("gxtNoAge", { n: ccGxNumInt(T0.noAge) }) : "");
      tPlate = ccGxtPlateMeasure([{ text: ccGxtAgoText(T0.T, lang0), font: ["display", 13, false, true], color: ccInt(A.text), gap: 2 },
                                  { text: cnt0, font: ["text", 7.8, false, false], color: ccInt(A.goldLight), wrap: 2, gap: 2 },
                                  { text: ccGxT("gxtIllustrative"), font: ["text", 7.2, false, true], color: ccInt(A.text3), wrap: 2 }], sc, Math.round(rect.w * 0.46));
      tBox = { x0: rect.x + Math.round(8 * sc), y0: rect.y + Math.round(8 * sc) };
      ccGxOccMark(O, tBox.x0, tBox.y0, tBox.x0 + tPlate.W, tBox.y0 + tPlate.H, 2);
   }
   var scaleBox = null, leg = null;
   if (P.kind === "top") {
      var ppk = P.xf.ppk, want = rect.w * 0.18 / ppk, cand = [0.5, 1, 2, 5, 10, 20], kpc = cand[0];
      for (var ci = 0; ci < cand.length; ++ci) if (cand[ci] <= want) kpc = cand[ci];
      var barPx = kpc * ppk * (ccGxBroken("scale") ? 1.5 : 1), bx1 = rect.x + rect.w - 12 * sc, bx0 = bx1 - barPx, by = rect.y + rect.h - 12 * sc - (chrome ? 0 : 30 * sc);   // (en el vídeo, encima de la marca CABRASPACE: se pisaban, captura del 23-oct)
      var stxt = ccGxF("gxRing", { n: ccGxNum(kpc, kpc < 1 ? 1 : 0) });
      scaleBox = { x0: bx0 - 4 * sc, y0: by - fS.ascent - 8 * sc, x1: bx1 + 4 * sc, y1: by + 5 * sc };
      g.fillRoundedRect(scaleBox.x0, scaleBox.y0, scaleBox.x1, scaleBox.y1, 8, 30, new Brush(ccInt(A.bg, 0.78)));
      ccGxNoBrush(g);
      g.pen = new Pen(ccInt(A.text, 0.9), Math.max(1, 1.2 * sc));
      g.drawLine(bx0, by, bx1, by); g.drawLine(bx0, by - 3 * sc, bx0, by + 3 * sc); g.drawLine(bx1, by - 3 * sc, bx1, by + 3 * sc);
      ccGxText(g, R, fS, ccInt(A.text2), (bx0 + bx1 - fS.width(stxt)) / 2, by - 5 * sc, stxt);
      ccGxOccMark(O, scaleBox.x0, scaleBox.y0, scaleBox.x1, scaleBox.y1, 2);
      R.scale = { kpc: kpc, px: barPx, ppk: ppk };
   } else if (P.kind === "edge") {
      // los ejes de canto: números de R abajo y de z a la izquierda, dentro del marco
      var xe3 = P.xf, Ra = xe3.inv(rect.x, 0).R, Rb = xe3.inv(rect.x + rect.w, 0).R, za = xe3.inv(0, rect.y + rect.h).z, zb = xe3.inv(0, rect.y).z;
      var sR = ccGxNiceStep(Rb - Ra, 6), sZ = ccGxNiceStep(zb - za, 5), dR = (sR < 1) ? 1 : 0, dZ = (sZ < 1) ? (sZ < 0.1 ? 2 : 1) : 0;
      for (var tR = Math.ceil(Ra / sR) * sR; tR <= Rb + 1e-9; tR += sR) {
         var lx = xe3.px(tR, 0).x, ltx = ccGxNum(tR, dR);
         if (lx - fS.width(ltx) / 2 < rect.x + 30 * sc || lx + fS.width(ltx) / 2 > rect.x + rect.w - 4 * sc) continue;
         ccGxHalo(g, R, fS, ccInt(A.text3), lx - fS.width(ltx) / 2, rect.y + rect.h - 5 * sc, ltx, sc);
         ccGxOccMark(O, lx - fS.width(ltx) / 2 - 2, rect.y + rect.h - 5 * sc - fS.ascent - 2, lx + fS.width(ltx) / 2 + 2, rect.y + rect.h, 2);
      }
      for (var tz = Math.ceil(za / sZ) * sZ; tz <= zb + 1e-9; tz += sZ) {
         var ly = xe3.px(0, tz).y, lzt = ccGxSigned(tz, dZ);
         // (sin el «0»: lo dice el rótulo del plano, y pisaba el centro galáctico, que está en R = 0)
         if (Math.abs(tz) < 1e-9 || ly < rect.y + 34 * sc || ly > rect.y + rect.h - 18 * sc) continue;
         ccGxHalo(g, R, fS, ccInt(A.text3), rect.x + 4 * sc, ly + fS.ascent / 2 - 1, lzt, sc);
         ccGxOccMark(O, rect.x, ly - fS.ascent, rect.x + 6 * sc + fS.width(lzt), ly + fS.ascent / 2 + 2, 2);
      }
      var axR = ccGxT("gxAxisR"), axZ = ccGxT("gxAxisZ");
      ccGxHalo(g, R, fS, ccInt(A.text2), rect.x + rect.w - fS.width(axR) - 6 * sc, rect.y + rect.h - 7 * sc - fS.ascent - 4 * sc, axR, sc);
      ccGxOccMark(O, rect.x + rect.w - fS.width(axR) - 8 * sc, rect.y + rect.h - 7 * sc - 2 * fS.ascent - 6 * sc, rect.x + rect.w, rect.y + rect.h - 7 * sc - fS.ascent, 2);
      ccGxHalo(g, R, fS, ccInt(A.text2), rect.x + 4 * sc, rect.y + 13 * sc, axZ, sc);
      ccGxOccMark(O, rect.x, rect.y, rect.x + 8 * sc + fS.width(axZ), rect.y + 16 * sc, 2);
   }
   // --- la LEYENDA, en la esquina con MENOS datos debajo (23-oct, revisor R10: arriba a la derecha tapaba la flecha del giro y la cadena
   //     de estrellas). Las 4 esquinas del mapa; fuera las que pisen algo duro (lo reservado del vídeo, la escala, los ejes, el Sol, el
   //     centro, la elegida, la flecha); de las demás, la de menos celdas blandas (órbitas, puntos); a igualdad, arriba a la derecha.
   //     ROJO «legcorner» de T18: siempre arriba a la derecha.
   if (V.legend !== false && rect.band) {
      leg = { band: true, corner: "band", x0: rect.band.x, y0: rect.band.y, x1: rect.band.x + rect.band.w, y1: rect.band.y + rect.band.h };
      R.legendUnder = { hard: 0, soft: 0, corner: "band" }; R.legendMinSoft = 0; R.legendCosts = ["franja bajo el mapa"];
   } else if (V.legend !== false) {
      var lb = ccGxLegend(g, R, V, G, rect, sc, true), LW = lb.x1 - lb.x0, LH = lb.y1 - lb.y0, m8 = Math.round(8 * sc);
      var corners = [["tr", rect.x + rect.w - LW - m8, rect.y + m8], ["tl", rect.x + m8, rect.y + m8], ["br", rect.x + rect.w - LW - m8, rect.y + rect.h - LH - m8], ["bl", rect.x + m8, rect.y + rect.h - LH - m8]];
      var bestC = 0, bestCost = 1e18;
      R.legendCosts = [];
      R.legendMinSoft = 1e9;
      for (var cn = 0; cn < corners.length; ++cn) {
         var cco = ccGxOccCost(O, corners[cn][1], corners[cn][2], corners[cn][1] + LW, corners[cn][2] + LH, null);
         var cost = cco.hard * 1e6 + cco.soft - (cn === 0 ? 0.5 : 0);
         R.legendCosts.push(corners[cn][0] + " " + cco.hard + "/" + cco.soft);
         if (cco.hard === 0 && cco.soft < R.legendMinSoft) R.legendMinSoft = cco.soft;
         if (cost < bestCost) { bestCost = cost; bestC = cn; }
      }
      if (ccGxBroken("legcorner")) bestC = 0;
      // (23-oct, el vídeo en el tiempo: la leyenda no salta de esquina en esquina entre fotogramas: la preferida, si no pisa nada duro)
      if (V.legendPrefer) for (cn = 0; cn < corners.length; ++cn) if (corners[cn][0] === V.legendPrefer && ccGxOccCost(O, corners[cn][1], corners[cn][2], corners[cn][1] + LW, corners[cn][2] + LH, null).hard === 0) { bestC = cn; R.legendPreferred = true; }
      leg = { x0: corners[bestC][1], y0: corners[bestC][2], x1: corners[bestC][1] + LW, y1: corners[bestC][2] + LH, corner: corners[bestC][0] };
      var cfin = ccGxOccCost(O, leg.x0, leg.y0, leg.x1, leg.y1, null);
      // (18a, 26-oct) Si ni así queda un rincón libre de lo duro (en vertical 9:16 y en 1:1 la placa del título arriba y la del reloj y la firma abajo ocupan
      //  los cuatro: la leyenda caía sobre la placa y la firma), se DESLIZA por el borde derecho y luego por el izquierdo hasta el PRIMER sitio sin nada duro
      //  debajo (el más alto). Sin mirar las celdas blandas: las estrellas se mueven en cada fotograma y la leyenda saltaría (medido en 1:1: 24 px);
      //  lo duro es casi estático (cc_galaxy_ui.js reserva las placas más altas del vídeo). ROJO «legoverlap»: se queda donde cae, pisando (lo de antes).
      if (cfin.hard > 0 && !ccGxBroken("legoverlap") && !(typeof ccGxtBroken === "function" && ccGxtBroken("legoverlap"))) {
         var slide = null, stepL = Math.max(2, Math.round(m8 / 2)), colsL = [rect.x + rect.w - LW - m8, rect.x + m8], ci2, yy2;
         // (el vídeo guarda dónde la puso la última vez, V.legendMem: si ese sitio sigue libre se queda ahí y no vuelve arriba cuando el Sol o la flecha
         //  se apartan; solo se mueve cuando algo duro que se mueve —el Sol, el centro, la flecha— se le pone encima)
         var memK = Math.round(rect.w) + "x" + Math.round(rect.h) + "|" + Math.round(LW) + "x" + Math.round(LH), memV = (V.legendMem && !ccGxtBroken("legnomem")) ? V.legendMem[memK] : null;
         if (memV && ccGxOccCost(O, memV.x, memV.y, memV.x + LW, memV.y + LH, null).hard === 0) slide = { x: memV.x, y: memV.y, corner: memV.corner };
         for (ci2 = 0; ci2 < colsL.length && !slide; ++ci2) for (yy2 = rect.y + m8; yy2 + LH <= rect.y + rect.h - m8; yy2 += stepL) {
            var cs2 = ccGxOccCost(O, colsL[ci2], yy2, colsL[ci2] + LW, yy2 + LH, null);
            if (cs2.hard === 0) { slide = { x: colsL[ci2], y: yy2, corner: ci2 === 0 ? "tr" : "tl" }; break; }
         }
         if (slide && V.legendMem) V.legendMem[memK] = slide;
         if (slide) { leg = { x0: slide.x, y0: slide.y, x1: slide.x + LW, y1: slide.y + LH, corner: slide.corner, slid: true }; cfin = ccGxOccCost(O, leg.x0, leg.y0, leg.x1, leg.y1, null); R.legendSlid = true; }
      }
      R.legendUnder = { hard: cfin.hard, soft: cfin.soft, corner: leg.corner };
      ccGxOccMark(O, leg.x0, leg.y0, leg.x1, leg.y1, 2);
   }
   // --- 8 · los RÓTULOS (por prioridad): el centro (29-oct), la elegida, el Sol, el giro, los círculos ---
   g.clipRect = new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
   // (29-oct-2026, «el rótulo del Centro galáctico salta», visto en Cabra3D: el centro es el único punto QUIETO del mapa y su rótulo va PRIMERO
   //  —detrás de la elegida y del Sol, que se mueven, lo echaban a otro lado y luego volvía—; con `fix`, junto a su cruz sin mirar los puntos ni
   //  su propia marca —ccGxPlace—. ROJO «gcjump»: el orden y el criterio de antes.)
   var gcFirst = !ccGxBroken("gcjump");
   var gcPlace = function() {
      if (!R.gc) return;
      var gck = R.gc.k || 5 * sc;
      R.gcLabel = ccGxPlace(g, R, O, [{ t: ccGxT("gxGC"), f: fSun, c: ccInt(A.gold) }], R.gc.x, R.gc.y, 8 * sc, sc, bounds, false, { own: [R.gc.x - gck, R.gc.y - gck, R.gc.x + gck, R.gc.y + gck] });
   };
   if (gcFirst) gcPlace();
   // (29-oct-2026, tarde, propagado de Cabra3D, «fija el rótulo Sol»: el Sol cambiaba de lado con los puntos y las estelas debajo; mismo arreglo
   //  que el centro —`fix` con su propia marca, ±6 px lógicos— y SEGUNDO, antes de la elegida. ROJO «sunjump»: el orden y el criterio de antes.)
   var sunFirst = !ccGxBroken("sunjump");
   var sunPlace = function() {
      if (!R.sun) return;
      var sk = 6 * sc;
      R.sunLabel = ccGxPlace(g, R, O, [{ t: ccGxT("gxSun"), f: fSun, c: ccInt(A.text) }], R.sun.x, R.sun.y, 8 * sc, sc, bounds, false, sunFirst ? { own: [R.sun.x - sk, R.sun.y - sk, R.sun.x + sk, R.sun.y + sk] } : null);
   };
   if (sunFirst) sunPlace();
   // (26-oct, propagado de Cabra3D: la ficha de la Galaxia) en el PANEL en vivo la elegida no lleva rótulo en el mapa: su nombre y su órbita
   //  los dice la ficha de la derecha (cc_paint.js ccPaintCard) y el mapa deja solo la marca. V.selLabel === false lo pide el panel
   //  (cc_galaxy_ui.js GX.paintTo); el VÍDEO no lo pide y conserva el rótulo (no tiene ficha). ROJO «gxsellabel» (CC_GX_BREAK): el rótulo de antes.
   if (R.sel && (V.selLabel !== false || ccGxBroken("gxsellabel"))) {
      var ek2 = G.stars[selK], o2 = ek2.orbit || ek2.meas, lines = [{ t: ek2.name || "—", f: fLb, c: ccInt(A.goldLight) }];
      // (integración, 22-oct: las cifras, con la MISMA función que la ficha —ccOrbitLine de cc_paint.js— para que no puedan discrepar)
      // (ROJO «orbit420» de T17: las cifras medidas solo en los 420 Myr que se dibujan, no en los 2 Gyr del motor: un error verosímil)
      if (o2 && ccGxBroken("orbit420") && ek2.tr) {
         var nW = Math.min(ek2.tr.n, Math.round(CC_GX.SHOW_MYR / CC_GX.DT_MYR / CC_GX.EVERY) + 1), r0 = 1e9, r1 = 0, z1 = 0;
         for (var iw = 0; iw < nW; ++iw) { var rw = Math.sqrt(ek2.tr.x[iw] * ek2.tr.x[iw] + ek2.tr.y[iw] * ek2.tr.y[iw] + ek2.tr.z[iw] * ek2.tr.z[iw]); r0 = Math.min(r0, rw); r1 = Math.max(r1, rw); z1 = Math.max(z1, Math.abs(ek2.tr.z[iw])); }
         o2 = { bound: true, rperi: r0, rapo: r1, zmax: z1, ecc: (r1 - r0) / (r1 + r0) };
      }
      if (o2 && o2.bound !== false && ccIsNum(o2.rperi))
         lines.push({ t: (typeof ccOrbitLine === "function") ? ccOrbitLine(o2, (typeof CC_LANG !== "undefined") ? CC_LANG : "en")
                         : ccGxF("gxSelOrbit", { p: ccGxNum(o2.rperi, 1), a: ccGxNum(o2.rapo, 1), z: ccGxNum(o2.zmax, o2.zmax < 1 ? 2 : 1), e: ccGxNum(o2.ecc, 2) }), f: fS, c: ccInt(A.text) });
      ccGxPlace(g, R, O, lines, R.sel.x, R.sel.y, 11 * sc, sc, bounds, true);
   }
   if (!sunFirst) sunPlace();
   if (!gcFirst) gcPlace();
   if (R.arrowMid) ccGxPlace(g, R, O, [{ t: ccGxT("gxRotation"), f: fS, c: ccInt(A.goldLight, 0.85) }], R.arrowMid.x, R.arrowMid.y, 6 * sc, sc, bounds);
   if (P.kind === "edge") {
      var qpl = P.xf.px(P.xf.inv(rect.x + rect.w * 0.82, 0).R, 0);
      ccGxPlace(g, R, O, [{ t: ccGxT("gxPlane"), f: fS, c: ccInt(A.text3) }], qpl.x, qpl.y, 5 * sc, sc, bounds);
   }
   for (var rl = 0; rl < ringLbl.length; ++rl) ccGxRingLabel(g, R, O, P, ringLbl[rl], fS, sc, bounds, ccInt(A.text3, 0.85));
   g.clipRect = new Rect(0, 0, w, h);
   if (leg && leg.band) { g.clipRect = new Rect(0, 0, w, h); ccGxLegendBand(g, R, V, G, leg.x0, leg.y0, leg.x1 - leg.x0, sc, false); }
   else if (leg) ccGxLegend(g, R, V, G, rect, sc, false, leg);
   if (tPlate) R.timePlate = ccGxtPlatePaint(g, R, tPlate, tBox.x0, tBox.y0, 1);
   // --- 9 · el marco y el pie ---
   ccGxNoBrush(g);
   if (chrome) { g.pen = new Pen(ccInt(A.line), 1); g.drawRect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h); }
   var footL = ccGxF("gxFoot", { n: N, m: G.nNoKin }) + (G.nUnbound ? " · " + ccGxF("gxUnbound", { n: G.nUnbound }) : "");
   var footR = (V.show === "orbit" || V.trail > 0) ? ccGxT((typeof ccBarOn === "function" && ccBarOn() && !R.barNote) ? "gxFootOrbitBar" : "gxFootOrbit") : ccGxT("gxFootNow"), fy = (rect.band ? rect.band.y + rect.band.h : rect.y + rect.h) + Math.round((R.barNote ? 10.5 : 13) * sc);
   if (pastO) footR = ccGxT(V.show === "orbit" ? "gxFootPastOrbit" : "gxFootPast");
   if ((V.show === "orbit" || V.trail > 0) && R.orbitsAll > R.orbitsDrawn) footR = ccGxF("gxOrbitsSubset", { n: R.orbitsDrawn, m: R.orbitsAll }) + " · " + footR;
   var wR = fS.width(footR), maxL = rect.w - wR - 20 * sc;
   // (23-oct, noche, revisión visual 4: «124 estrellas con órbita · 28 sin velocidad radial o sin di…») Formas cortas antes de cortar:
   // la entera, la corta («124 con órbita · 28 sin VR o distancia»), la mínima («124 con órbita»). ROJO «footdots»: corta como antes.
   if (!ccGxBroken("footdots") && !(typeof CC_BREAK === "string" && CC_BREAK.indexOf("footdots") >= 0) && fS.width(footL) > Math.max(40, maxL)) {
      var fF = [ccGxF("gxFootShort", { n: N, m: G.nNoKin }) + (G.nUnbound ? " · " + ccGxF("gxUnboundShort", { n: G.nUnbound }) : ""), ccGxF("gxFootShort", { n: N, m: G.nNoKin }), ccGxF("gxFootMin", { n: N })];
      for (var ff = 0; ff < fF.length; ++ff) if (fS.width(fF[ff]) <= Math.max(40, maxL) || ff === fF.length - 1) { footL = fF[ff]; break; }
   }
   R.footL = footL;
   if (chrome) {
      ccGxText(g, R, fS, ccInt(A.text3), rect.x, fy, ccElide(fS, footL, Math.max(40, maxL)));
      ccGxText(g, R, fS, ccInt(A.text3), rect.x + rect.w - wR, fy, footR);
      if (R.barNote && !pastO) {
         var nt = ccGxT("gxFootBarNote"), wN = fS.width(nt);
         R.footNote = nt;
         ccGxText(g, R, fS, ccInt(A.text3), rect.x + Math.max(0, rect.w - wN), fy + Math.round(10.5 * sc), nt);
      }
   }
   if (!N) {
      var fm2 = ccFont("text", 10 * sc, false, true), msg2 = ccGxT("gxNoKin"), wm = fm2.width(msg2);
      g.fillRoundedRect(rect.x + (rect.w - wm) / 2 - 10 * sc, rect.y + rect.h / 2 - 18 * sc, rect.x + (rect.w + wm) / 2 + 10 * sc, rect.y + rect.h / 2 + 8 * sc, 8, 30, new Brush(ccInt(A.bg, 0.85)));
      ccGxNoBrush(g);
      ccGxText(g, R, fm2, ccInt(A.text2), rect.x + (rect.w - wm) / 2, rect.y + rect.h / 2, msg2);
   }
   // --- lo proyectado, para el ratón ---
   var idxs = new Int32Array(N);
   for (i = 0; i < N; ++i) idxs[i] = G.stars[i].i;
   G.proj = { kind: P.kind, x: pxs, y: pys, z: pzs, ok: okv, idx: idxs, n: N, rect: rect, P: P, w: w, h: h };
   R.msOver = Date.now() - t0;
   R.ms = Date.now() - C.t0;
   return R;
}

// LA LEYENDA, arriba a la derecha del mapa, con placa. measureOnly: solo devuelve el rectángulo (para reservarlo).
// `at` = { x0, y0 }: la esquina elegida (ccGxPaintOver); sin él, arriba a la derecha.
// Lo que lleva la leyenda de la franja: { items, gradient, extra, title } (los mismos que ccGxLegend). withSun: el Sol aunque aún
// no haya nacido (para MEDIR la franja: su alto no cambia con el reloj).
function ccGxLegendItems(R, V, G, withSun) {
   var A = CC_ATLAS, lang = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en", items = [], gradient = null;
   if (V.color === "age") gradient = { from: 0, to: 13.5, rgb: ccGxAgeRgb, ticks: [0, 4, 8, 12], unit: ccGxT("gxAgeUnit"), digits: 0, none: ccGxT("gxAgeNone"), title: ccGxT("gxAge") };
   else if (V.color === "feh") gradient = { from: -2.5, to: 0.5, rgb: ccFehRgb, ticks: [-2.5, -1.5, -0.5, 0.5], unit: "", digits: 1, none: ccGxT("gxFehNone"), title: "[Fe/H]", signed: true };
   else {
      var seen = {}, orderP = ["thin", "thick", "halo", "accreted", "disc", "unknown"];
      for (var i = 0; i < G.stars.length; ++i) seen[G.stars[i].pop] = true;
      for (var k = 0; k < orderP.length; ++k) if (seen[orderP[k]]) items.push({ kind: "dot", rgb: ccHexRgb(CC_POP_COLOR[orderP[k]] || A.text3), hollow: orderP[k] === "unknown", text: ccPopLeg(orderP[k], lang) });
   }
   var extra = (!withSun && R && R.time && R.time.sunBorn === false) ? [] : [{ kind: "sun", text: ccGxT("gxSun") }];
   if ((withSun || V.mode !== "edge") && V.arms !== false) extra.push({ kind: "arm", text: ccGxT("gxArms") });
   extra.push({ kind: "glow", text: ccGxT("gxDisc") });
   if (ccGxBroken("legend")) { items = []; gradient = null; }
   return { items: items, gradient: gradient, extra: extra, title: gradient ? gradient.title : ccGxT("gxPop") };
}
function ccGxLegendSymbol(g, it, x, cy, sc) {
   var A = CC_ATLAS;
   if (it.kind === "dot") {
      if (it.hollow) g.strokeCircle(x + 4 * sc, cy, 2.6 * sc, new Pen(ccRgbInt(it.rgb, 0.85), Math.max(1, 0.9 * sc)));
      else g.fillCircle(x + 4 * sc, cy, 2.8 * sc, new Brush(ccRgbInt(it.rgb, 0.95)));
   } else if (it.kind === "none") g.strokeCircle(x + 4 * sc, cy, 2.6 * sc, new Pen(ccInt(A.text3, 0.85), Math.max(1, 0.9 * sc)));
   else if (it.kind === "sun") { g.strokeCircle(x + 4 * sc, cy, 3.6 * sc, new Pen(ccInt(A.text, 0.95), Math.max(1, 1.0 * sc))); g.fillCircle(x + 4 * sc, cy, 1.1 * sc, new Brush(ccInt(A.text, 0.95))); }
   else if (it.kind === "arm") { g.pen = new Pen(ccInt(A.goldLight, 0.35), Math.max(2, 3 * sc)); g.drawLine(x, cy, x + 9 * sc, cy); }
   else g.fillRect(x, cy - 3 * sc, x + 9 * sc, cy + 3 * sc, new Brush(ccInt(A.goldLight, 0.35)));
}
// (23-oct, noche) LA LEYENDA EN FRANJA, bajo el mapa del diálogo: el título, la escala de color (si la hay) y los símbolos en filas que
// se parten a lo ancho del mapa. Devuelve { h }; al pintar, apunta R.legend con corner = "band".
function ccGxLegendBand(g, R, V, G, x0, y0, W, sc, measureOnly) {
   var A = CC_ATLAS, f = ccFont("text", 8.2 * sc), fH = ccFont("text", 7.6 * sc, false, false, Math.round(7.6 * sc * A.labelTracking));
   var L = ccGxLegendItems(R, V, G, !!measureOnly), rowH = Math.round(13 * sc), pad = Math.round(5 * sc), gapI = Math.round(12 * sc), symW = Math.round(14 * sc);
   var title = L.title.toUpperCase(), xL = x0 + pad, xR = x0 + W - pad, y = y0 + pad + f.ascent, rows = 1, cx;
   var flow = L.items.slice();
   if (L.gradient) flow.unshift({ kind: "none", text: L.gradient.none });
   flow = flow.concat(L.extra);
   if (!measureOnly) ccGxText(g, R, fH, ccInt(A.text3), xL, y, title);
   cx = xL + fH.width(title) + gapI;
   if (L.gradient) {
      var gr = L.gradient, gw = Math.max(Math.round(60 * sc), Math.min(Math.round(150 * sc), xR - cx)), gh = Math.round(7 * sc);
      if (cx + gw > xR) { rows++; y += rowH; cx = xL; }
      var gy = y - f.ascent + Math.round(2 * sc);
      if (!measureOnly) {
         for (var p = 0; p < gw; ++p) { var v = gr.from + (gr.to - gr.from) * p / (gw - 1); g.fillRect(cx + p, gy, cx + p + 1, gy + gh, new Brush(ccRgbInt(gr.rgb(v), 1))); }
         for (var tk = 0; tk < gr.ticks.length; ++tk) {
            var tv = gr.ticks[tk], tl = (gr.signed ? ccGxSigned(tv, gr.digits) : ccGxNum(tv, gr.digits)) + (tk === gr.ticks.length - 1 && gr.unit ? " " + gr.unit : "");
            var txp = Math.max(cx, Math.min(cx + gw - f.width(tl), cx + gw * (tv - gr.from) / (gr.to - gr.from) - f.width(tl) / 2));
            ccGxText(g, R, f, ccInt(A.text2), txp, y + rowH, tl);
         }
      }
      rows++; y += rowH; cx = xR + 1;          // (las marcas, debajo de la escala; lo demás, en la fila siguiente)
   }
   for (var i = 0; i < flow.length; ++i) {
      var it = flow[i], iw = symW + f.width(it.text);
      if (cx + iw > xR && cx > xL) { rows++; y += rowH; cx = xL; }
      if (!measureOnly) { ccGxLegendSymbol(g, it, cx, y - f.ascent / 2 + 1, sc); ccGxText(g, R, f, ccInt((it.kind === "dot" || it.kind === "none") ? A.text2 : A.text3), cx + symW, y, it.text); }
      cx += iw + gapI;
   }
   var H = rows * rowH + 2 * pad - Math.round(2 * sc);
   if (!measureOnly) R.legend = { x0: x0, y0: y0, x1: x0 + W, y1: y0 + H, items: L.items.length + (L.gradient ? 1 : 0), corner: "band", texts: flow.map(function(q) { return q.text; }) };
   return { h: H };
}
function ccGxLegend(g, R, V, G, rect, sc, measureOnly, at) {
   var A = CC_ATLAS, f = ccFont("text", 8.2 * sc), fH = ccFont("text", 7.6 * sc, false, false, Math.round(7.6 * sc * A.labelTracking));
   var lang = (typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en", rowH = Math.round(13 * sc), pad = Math.round(8 * sc), items = [], gradient = null;
   if (V.color === "age") gradient = { from: 0, to: 13.5, rgb: ccGxAgeRgb, ticks: [0, 4, 8, 12], unit: ccGxT("gxAgeUnit"), digits: 0, none: ccGxT("gxAgeNone"), title: ccGxT("gxAge") };
   else if (V.color === "feh") gradient = { from: -2.5, to: 0.5, rgb: ccFehRgb, ticks: [-2.5, -1.5, -0.5, 0.5], unit: "", digits: 1, none: ccGxT("gxFehNone"), title: "[Fe/H]", signed: true };
   else {
      var seen = {}, orderP = ["thin", "thick", "halo", "accreted", "disc", "unknown"];
      for (var i = 0; i < G.stars.length; ++i) seen[G.stars[i].pop] = true;
      // (23-oct, revisor R11: los MISMOS nombres que la leyenda de A y el vídeo —CC_POP_LEG de cc_atlas.js—; «disco» dice que no se separó)
      for (var k = 0; k < orderP.length; ++k) if (seen[orderP[k]]) items.push({ kind: "dot", rgb: ccHexRgb(CC_POP_COLOR[orderP[k]] || A.text3), hollow: orderP[k] === "unknown", text: ccPopLeg(orderP[k], lang) });
   }
   // (23-oct: en el pasado, antes de que nazca el Sol —4,57 Ga—, no está en el mapa ni en la leyenda)
   var extra = (R && R.time && R.time.sunBorn === false) ? [] : [{ kind: "sun", text: ccGxT("gxSun") }];
   if (V.mode !== "edge" && V.arms !== false) extra.push({ kind: "arm", text: ccGxT("gxArms") });
   extra.push({ kind: "glow", text: ccGxT("gxDisc") });
   if (ccGxBroken("legend")) { items = []; gradient = null; }
   var title = gradient ? gradient.title : ccGxT("gxPop"), wMax = fH.width(title.toUpperCase());
   for (i = 0; i < items.length; ++i) wMax = Math.max(wMax, 16 * sc + f.width(items[i].text));
   for (i = 0; i < extra.length; ++i) wMax = Math.max(wMax, 16 * sc + f.width(extra[i].text));
   var gradW = Math.round(150 * sc);
   if (gradient) wMax = Math.max(wMax, gradW, 16 * sc + f.width(gradient.none));
   var nRows = 1 + items.length + extra.length + (gradient ? 3 : 0);
   var W = wMax + 2 * pad, H = nRows * rowH + 2 * pad - Math.round(3 * sc);
   var x0 = at ? at.x0 : rect.x + rect.w - W - Math.round(8 * sc), y0 = at ? at.y0 : rect.y + Math.round(8 * sc), box = { x0: x0, y0: y0, x1: x0 + W, y1: y0 + H };
   if (measureOnly) return box;
   g.fillRoundedRect(box.x0, box.y0, box.x1, box.y1, 8, 22, new Brush(ccInt(A.bg, 0.86)));
   ccGxNoBrush(g); g.pen = new Pen(ccInt(A.line), 1); g.drawRoundedRect(box.x0, box.y0, box.x1, box.y1, 8, 22);
   var x = x0 + pad, y = y0 + pad + f.ascent - Math.round(1 * sc);
   ccGxText(g, R, fH, ccInt(A.text3), x, y, title.toUpperCase()); y += rowH;
   if (gradient) {
      var gy = y - f.ascent + Math.round(2 * sc), gh = Math.round(7 * sc);
      for (var p = 0; p < gradW; ++p) { var v = gradient.from + (gradient.to - gradient.from) * p / (gradW - 1); g.fillRect(x + p, gy, x + p + 1, gy + gh, new Brush(ccRgbInt(gradient.rgb(v), 1))); }
      y += rowH;
      for (var tk = 0; tk < gradient.ticks.length; ++tk) {
         var tv = gradient.ticks[tk], tl = (gradient.signed ? ccGxSigned(tv, gradient.digits) : ccGxNum(tv, gradient.digits)) + (tk === gradient.ticks.length - 1 && gradient.unit ? " " + gradient.unit : "");
         var txp = x + gradW * (tv - gradient.from) / (gradient.to - gradient.from) - f.width(tl) / 2;
         txp = Math.max(x, Math.min(x + gradW - f.width(tl), txp));
         ccGxText(g, R, f, ccInt(A.text2), txp, y, tl);
      }
      y += rowH;
      g.strokeCircle(x + 4 * sc, y - f.ascent / 2 + 1, 2.6 * sc, new Pen(ccInt(A.text3, 0.85), Math.max(1, 0.9 * sc)));
      ccGxText(g, R, f, ccInt(A.text2), x + 14 * sc, y, gradient.none); y += rowH;
   }
   for (i = 0; i < items.length; ++i) {
      var it = items[i], cyy = y - f.ascent / 2 + 1;
      if (it.hollow) g.strokeCircle(x + 4 * sc, cyy, 2.6 * sc, new Pen(ccRgbInt(it.rgb, 0.85), Math.max(1, 0.9 * sc)));
      else g.fillCircle(x + 4 * sc, cyy, 2.8 * sc, new Brush(ccRgbInt(it.rgb, 0.95)));
      ccGxText(g, R, f, ccInt(A.text2), x + 14 * sc, y, it.text); y += rowH;
   }
   for (i = 0; i < extra.length; ++i) {
      var ex = extra[i], cy2 = y - f.ascent / 2 + 1;
      if (ex.kind === "sun") { g.strokeCircle(x + 4 * sc, cy2, 3.6 * sc, new Pen(ccInt(A.text, 0.95), Math.max(1, 1.0 * sc))); g.fillCircle(x + 4 * sc, cy2, 1.1 * sc, new Brush(ccInt(A.text, 0.95))); }
      else if (ex.kind === "arm") { g.pen = new Pen(ccInt(A.goldLight, 0.35), Math.max(2, 3 * sc)); g.drawLine(x, cy2, x + 9 * sc, cy2); }
      else { g.fillRect(x, cy2 - 3 * sc, x + 9 * sc, cy2 + 3 * sc, new Brush(ccInt(A.goldLight, 0.35))); }
      ccGxText(g, R, f, ccInt(A.text3), x + 14 * sc, y, ex.text); y += rowH;
   }
   R.legend = { x0: box.x0, y0: box.y0, x1: box.x1, y1: box.y1, items: items.length + (gradient ? 1 : 0), corner: (at && at.corner) ? at.corner : "tr", texts: items.map(function(q) { return q.text; }).concat(extra.map(function(q) { return q.text; })) };
   return box;
}

// EL RATÓN: la estrella más cercana a (x, y) en lo último pintado, a menos de 8 px lógicos; en 3D, a igual
// distancia, la de delante. Devuelve el índice de res.stars, o −1.
function ccGalaxyPick(G, x, y, sc) {
   var P = G && G.proj;
   if (!P || !P.n) return -1;
   var r2 = Math.pow(8 * (sc || 1), 2), best = -1, bd = 1e18;
   for (var i = 0; i < P.n; ++i) {
      if (!P.ok[i]) continue;
      var dx = P.x[i] - x, dy = P.y[i] - y, d = dx * dx + dy * dy;
      if (d > r2) continue;
      var key = d + (P.kind === "3d" ? P.z[i] * 1e-6 : 0);
      if (key < bd) { bd = key; best = i; }
   }
   if (best < 0) return -1;
   if (ccGxBroken("pick")) best = (best + 1) % P.n;          // (ROJO «pick»: la de al lado)
   return P.idx[best];
}
#endif
