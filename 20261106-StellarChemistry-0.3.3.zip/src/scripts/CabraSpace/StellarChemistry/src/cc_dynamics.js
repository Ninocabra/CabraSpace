// ============================================================================
// src/cc_dynamics.js — FAMILIAS CINEMÁTICAS: energía, momento angular y órbitas
// ----------------------------------------------------------------------------
// Pura (sin PixInsight): la ejecutan node y PixInsight.
//
// EL POTENCIAL (G1, 23-oct-2026; decisión de Nino: «el mismo en todo, que sea el mejor»):
// `MilkyWayPotential2022` de gala (= `MilkyWayPotential(version="v2")`, el que gala pondrá
// de fábrica; sin artículo propio: gala, Price-Whelan 2017; vertical de Darragh-Ford et al. 2023): disco ajustado a la curva de
// rotación de Eilers et al. 2019 y a la espiral de fase vertical. Copiado de gala
// (`_setup_mwp_2022` y `MN3ExponentialDiskPotential`, src/gala/potential/potential/builtin/,
// leído el 23-oct-2026):
//   núcleo  Hernquist  M = 1,8142e9 M⊙, c = 0,0688867 kpc
//   bulbo   Hernquist  M = 5,0e9 M⊙,    c = 1,0 kpc
//   disco   exponencial M = 4,7717e10 M⊙, h_R = 2,6 kpc, h_z = 0,3 kpc (sech²), escrito como
//           SUMA DE TRES Miyamoto-Nagai (Smith et al. 2015, MNRAS 448, 2934; la tabla de
//           densidad positiva, la misma que gala): ccMn3 los calcula al cargar
//   halo    NFW  m = 5,5427e11 M⊙, r_s = 15,626 kpc
// vc(R0 = 8,122) = 229,4 km/s (Eilers+2019: 229,0); M200 = 1,03e12 M⊙. Por qué este y no
// otro, con la tabla de candidatos medida: docs/potencial_g1.md. Hasta el 23-oct era el
// `MilkyWayPotential` de gala v1 (disco Miyamoto-Nagai de 6,8e10 M⊙): sobraba disco por dentro
// (+3 a +8 km/s en 5-8 kpc) y la Zmax de las órbitas que rozan el centro saltaba con nada
// (HD 140283: 2,27 kpc con la RV de GALAH y 5,40 con la de Gaia, 3,35 km/s más; en este, 2,45 y
// 2,54; con McMillan 2017, 2,26).
// El sistema de referencia NO cambia (astropy 4.0, el de cc_science.js: R0 = 8,122 kpc,
// z⊙ = 20,8 pc, v⊙ = (12,9; 245,6; 7,78) km/s): es el mismo R0 con el que se ajustó el v2.
//
// LAS CAJAS DE NAIDU EN E: Naidu et al. 2020 las definieron en la energía del v1. La
// cinética no depende del potencial, así que E_v2 = E_v1 + ΔΦ(x), con ΔΦ = Φ_v2 − Φ_v1 en
// la posición de la estrella. En la vecindad solar ΔΦ casi no varía: en el Sol +1 018 km²/s²
// (en las 2 787 estrellas con órbita de los campos de prueba, 830 a 1 110, p5-p95). Las
// cajas se DESPLAZAN esa cifra (CC_NAIDU_DE); tests/cc_node_potential.js la recalcula con
// un v1 escrito aparte y la ve en ROJO si se pone a 0. Medido: el cambio de potencial mueve
// 2 de 2 787 estrellas de familia (las dos en el filo e = 0,70), docs/potencial_g1.md §5.
//
// LAS FAMILIAS: el árbol de Naidu et al. 2020 (§3, ec. 1-9), aplicado en su orden,
// con DOS adaptaciones (su muestra son gigantes con |Z| > 2 kpc; la nuestra, la
// vecindad solar, casi toda de disco):
//   · antes de nada, el DISCO: circularidad η ≥ 0,5 (diseño) — lo que Naidu quitó
//     con el corte |Z| > 2 kpc; Aleph (su ec. 2, órbitas casi de disco) no se usa;
//   · el corte químico del halo in situ (su ec. 3) se aplica con NUESTRO α
//     ([Mg/Fe] o el del survey), no con el de H3: aproximado.
// Convención de signos: aquí Lz > 0 es PRÓGRADO (como el resto del script).
// Naidu usa la contraria (prógrado Lz < 0): sus cajas se han traducido.
// ES5 puro.
// ============================================================================

var CC_G = 4.300917270e-6;     // kpc (km/s)^2 / M⊙ (IAU 2015 / astropy)
var CC_POT = {
   model: "gala MilkyWayPotential2022 (v2)",
   nucleus: { m: 1.8142e9, c: 0.0688867 },
   bulge:   { m: 5.0e9,    c: 1.0 },
   // el disco: exponencial (m, h_R, h_z sech²); `mn` = sus tres Miyamoto-Nagai (ccPotSetup, al cargar).
   // `a` y `b`: SOLO para el resplandor de ui/cc_galaxy.js (ccGxRhoDisc lee un único Miyamoto-Nagai y no
   // es mío tocar ui/): el MN del v1 (3,0; 0,28), que dibuja Σ(R) a ≤ 0,11 dex del disco verdadero dentro
   // de 14 kpc. Lo correcto es que ccGxRhoDisc llame a ccDiskDensity (pendiente, docs/potencial_g1.md §7).
   disk:    { m: 4.7717e10, hR: 2.6, hz: 0.3, mn: null, a: 3.0, b: 0.28 },
   halo:    { m: 5.5427e11, rs: 15.626 }
};
var CC_KPC_KMS_MYR = 977.792221;   // 1 kpc/(km/s) en millones de años

// LOS TRES MIYAMOTO-NAGAI DEL DISCO EXPONENCIAL (Smith et al. 2015, tabla de densidad positiva y perfil
// vertical sech²: la misma cuenta que gala MN3ExponentialDiskPotential, positive_density=True, sech2_z=True).
// b/h_R = −0,033 q³ + 0,262 q² + 0,659 q (q = h_z/h_R); (m_i/M, a_i/h_R) = K · [x⁴, x³, x², x, 1] con x = b/h_R.
// Las masas suman 1,108 M y una es negativa (así es el ajuste de Smith+2015: la densidad total es positiva).
var CC_MN3_K = [[ 0.0036, -0.0330,  0.1117, -0.1335,  0.1749],
                [-0.0131,  0.1090, -0.3035,  0.2921, -5.7976],
                [-0.0048,  0.0454, -0.1425,  0.1012,  6.7120],
                [-0.0158,  0.0993, -0.2070, -0.7089,  0.6445],
                [-0.0319,  0.1514, -0.1279, -0.9325,  2.6836],
                [-0.0326,  0.1816, -0.2943, -0.6329,  2.3193]];
function ccMn3(M, hR, hz) {
   var q = hz / hR, bh = -0.033 * q * q * q + 0.262 * q * q + 0.659 * q, xv = [bh * bh * bh * bh, bh * bh * bh, bh * bh, bh, 1], p = [], i, j;
   for (i = 0; i < 6; ++i) { var s = 0; for (j = 0; j < 5; ++j) s += CC_MN3_K[i][j] * xv[j]; p.push(s); }
   return [{ m: p[0] * M, a: p[3] * hR, b: bh * hR }, { m: p[1] * M, a: p[4] * hR, b: bh * hR }, { m: p[2] * M, a: p[5] * hR, b: bh * hR }];
}
// (Re)hace los tres MN desde CC_POT.disk (al cargar; una prueba que cambie m, h_R o h_z la vuelve a llamar).
function ccPotSetup() { CC_POT.disk.mn = ccMn3(CC_POT.disk.m, CC_POT.disk.hR, CC_POT.disk.hz); CC_ECIRC = null; CC_GSE_GRID = null; return CC_POT; }

// Potencial (km²/s²) en (x, y, z) kpc.
function ccPotential(x, y, z) {
   var P = CC_POT, R2 = x * x + y * y, r = Math.sqrt(R2 + z * z), D = P.disk.mn || ccPotSetup().disk.mn;
   var phi = -CC_G * P.nucleus.m / (r + P.nucleus.c) - CC_G * P.bulge.m / (r + P.bulge.c);
   var beta = Math.sqrt(z * z + D[0].b * D[0].b);      // (los tres MN comparten b)
   for (var i = 0; i < 3; ++i) { var s = D[i].a + beta; phi += -CC_G * D[i].m / Math.sqrt(R2 + s * s); }
   phi += (r > 1e-9) ? -CC_G * P.halo.m * Math.log(1 + r / P.halo.rs) / r : -CC_G * P.halo.m / P.halo.rs;
   return phi;
}
// Aceleración (km/s)²/kpc.
function ccAcc(x, y, z, out) {
   var P = CC_POT, R2 = x * x + y * y, r2 = R2 + z * z, r = Math.sqrt(r2), D = P.disk.mn || ccPotSetup().disk.mn;
   var a = 0;
   if (r > 1e-9) {
      a += CC_G * P.nucleus.m / ((r + P.nucleus.c) * (r + P.nucleus.c));
      a += CC_G * P.bulge.m / ((r + P.bulge.c) * (r + P.bulge.c));
      var A = CC_G * P.halo.m, rs = P.halo.rs;
      a += A * (Math.log(1 + r / rs) / r2 - 1 / (r * (rs + r)));
      a /= r;      // a(r)/r para multiplicar por (x, y, z)
   }
   var beta = Math.sqrt(z * z + D[0].b * D[0].b), fR = 0, fz = 0;
   for (var i = 0; i < 3; ++i) { var s = D[i].a + beta, D2 = R2 + s * s, k = CC_G * D[i].m / (D2 * Math.sqrt(D2)); fR += k; fz += k * s; }
   out[0] = -a * x - fR * x;
   out[1] = -a * y - fR * y;
   out[2] = -a * z - fz * z / beta;
   return out;
}
// Densidades del potencial (M⊙/kpc³), para dibujar la Vía Láctea con la MISMA masa que mueve las órbitas.
function ccDiskDensity(R, z) {
   var D = CC_POT.disk.mn || ccPotSetup().disk.mn, rho = 0;
   for (var i = 0; i < 3; ++i) {
      var a = D[i].a, b = D[i].b, B = Math.sqrt(z * z + b * b), aB = a + B;
      rho += b * b * D[i].m / (4 * Math.PI) * (a * R * R + (a + 3 * B) * aB * aB) / (Math.pow(R * R + aB * aB, 2.5) * B * B * B);
   }
   return rho;
}
function ccBulgeDensity(r) {
   var P = CC_POT; r = Math.max(r, 1e-3);
   return P.bulge.m * P.bulge.c / (2 * Math.PI * r * Math.pow(r + P.bulge.c, 3)) + P.nucleus.m * P.nucleus.c / (2 * Math.PI * r * Math.pow(r + P.nucleus.c, 3));
}
// Velocidad circular en el plano (km/s) a radio R (kpc).
function ccVcirc(R) {
   var o = [0, 0, 0];
   ccAcc(R, 0, 0, o);
   return Math.sqrt(Math.max(0, -o[0] * R));
}

// LA BARRA (2-nov-2026; decisión de Nino: «si no frena la visualización, que entre»). COPIA de CSH_GD.BAR, cshGdBarK, cshGdBarAngle,
// cshGdBarAdd, cshGdBarPhiCS y cshGdJacobi de CabraShared/csh_galdyn.js, la misma aritmética en el mismo orden (Cabra3D/tests/c3_gx_cases.js
// G1 compara las constantes; G7, G8 y G21 las órbitas a 1e-9). El cuadrupolo de Dehnen (2000, AJ 119, 800) en la convención de galpy
// DehnenBarPotential: Ω_b 37 km/s/kpc (centro de 33–41: Clarke y Gerhard 2022, Portail et al. 2017, Sanders et al. 2019), φ_b 25°,
// α 0,01 (NO VERIFICADO mejor que ±50 %), r_b = 0,8·v0/Ω_b. Con la barra se conserva la energía de Jacobi E_J = E + Φ_b − Ω_b·L_z (no E):
// la vigilancia del paso la mira a ella. (2-nov, noche: decisión Q2b = B de Nino) LA BARRA SOLO EN LO QUE SE DIBUJA (ui/cc_galaxy.js
// ccGxIntegrate y la Galaxia en el tiempo): la ficha (ccOrbit: peri, apo, Zmax, e), las familias (E, L_z, η de hoy y la e de GSE) y las
// comprobaciones contra la literatura siguen en el potencial SIN barra, el de McMillan y Naidu et al. 2020 (con la barra, HD 140283 daba
// Zmax 4,4 kpc frente a 2,26 ± 0,5, y el análisis costaba ×1,6–1,8). ROJO: CC_BREAK=sci-nobar.
var CC_BAR = { ON: true, OB: 37, PHIB_DEG: 25, ALPHA: 0.01, ref: "Dehnen 2000 quadrupole (galpy DehnenBarPotential)" };
var CC_BAR_K = null;
function ccBarOn() { return CC_BAR.ON === true && !ccFamBrk("sci-nobar"); }
function ccBarSetup() {
   var B = CC_BAR, v0 = ccVcirc(CC_SCI.R0_KPC), rb = 0.8 * v0 / B.OB;
   CC_BAR_K = { ob: B.OB, al: B.ALPHA, ph: B.PHIB_DEG, rb: rb, Af: B.ALPHA * v0 * v0 / 3 * Math.pow(CC_SCI.R0_KPC / rb, 3), w: B.OB / CC_KPC_KMS_MYR, phib: B.PHIB_DEG * Math.PI / 180 };
   return CC_BAR_K;
}
// (2-nov, tarde) con números y no con una cadena: se llama en cada paso (lo mismo que cshGdBarK)
function ccBarK() { var B = CC_BAR, K = CC_BAR_K; return (K && K.ob === B.OB && K.al === B.ALPHA && K.ph === B.PHIB_DEG) ? K : ccBarSetup(); }
function ccBarAngle(tMyr, out) { var K = ccBarK(), th = K.phib + K.w * tMyr; out[0] = Math.cos(th); out[1] = Math.sin(th); return out; }
function ccBarAdd(x, y, z, c, s, out) {
   var K = ccBarK(), xg = -x, yg = y, xp = xg * c + yg * s, yp = -xg * s + yg * c, r2 = xg * xg + yg * yg + z * z, r = Math.sqrt(r2), rb = K.rb, h, hp;
   if (r > rb) { var rb3 = rb * rb * rb, r5 = r2 * r2 * r; h = -rb3 / r5; hp = 5 * rb3 / (r5 * r); }
   else { var rb3i = 1 / (rb * rb * rb); h = r * rb3i - 2 / r2; hp = rb3i + 4 / (r2 * r); }
   var q = xp * xp - yp * yp, Af = K.Af, k = q * hp / r;
   var dxp = Af * (2 * xp * h + k * xp), dyp = Af * (-2 * yp * h + k * yp), dz = Af * k * z;
   var dxg = dxp * c - dyp * s, dyg = dxp * s + dyp * c;
   out[0] += dxg; out[1] -= dyg; out[2] -= dz;
   return out;
}
function ccBarPhiCS(x, y, z, c, s) {
   var K = ccBarK(), xg = -x, yg = y, xp = xg * c + yg * s, yp = -xg * s + yg * c, r2 = xg * xg + yg * yg + z * z, r = Math.sqrt(r2), rb = K.rb;
   var h = (r > rb) ? -rb * rb * rb / (r2 * r2 * r) : r / (rb * rb * rb) - 2 / r2;
   return K.Af * (xp * xp - yp * yp) * h;
}
// la energía de Jacobi (km²/s²): w = la velocidad de giro de la barra en el tiempo de la integración (Ω_b; −Ω_b con la velocidad invertida)
function ccJacobi(x, y, z, vx, vy, vz, c, s, w) {
   return 0.5 * (vx * vx + vy * vy + vz * vz) + ccPotential(x, y, z) + ccBarPhiCS(x, y, z, c, s) + w * (x * vy - y * vx);
}

// El estado dinámico a partir de la astrometría (frame de astropy 4.0, el de cc_science.js).
// Devuelve { x, y, z, vx, vy, vz, r, E, Lz (prógrado > 0), Lx, Ly, Lperp, eta,
//            LzN, LyN (convención de Naidu: prógrado < 0) }.
function ccDynState(ra, dec, dPc, pmra, pmdec, rv) {
   var g = ccGalactic(ra, dec), dk = dPc / 1000;
   var x = g.xyz[0] * dk - CC_SCI.R0_KPC, y = g.xyz[1] * dk, z = g.xyz[2] * dk + CC_SCI.ZSUN_KPC;
   var uvw = ccUvw(ra, dec, dPc, pmra, pmdec, rv);
   var vx = uvw[0] + CC_SCI.VSUN_GC[0], vy = uvw[1] + CC_SCI.VSUN_GC[1], vz = uvw[2] + CC_SCI.VSUN_GC[2];
   var Lx = y * vz - z * vy, Ly = z * vx - x * vz, LzA = x * vy - y * vx;     // momento angular de astropy (prógrado < 0)
   var r = Math.sqrt(x * x + y * y + z * z), v = Math.sqrt(vx * vx + vy * vy + vz * vz);
   var E = 0.5 * v * v + ccPotential(x, y, z);
   var Lz = -LzA;
   return { x: x, y: y, z: z, vx: vx, vy: vy, vz: vz, r: r, v: v, E: E, Lz: Lz, Lx: Lx, Ly: Ly, Lperp: Math.sqrt(Lx * Lx + Ly * Ly),
            eta: (r * v > 0) ? Lz / (r * v) : 0, LzN: LzA, LyN: Ly };
}

// Una órbita: salto de rana (kick-drift-kick) con el paso PARTIDO si la energía se va (R2, 27-oct-2026). Devuelve
// { rperi, rapo, zmax, ecc, bound, dE (el final), dEmax, approx, halvings, dtMyr (el paso usado) }.
// POR QUÉ (revisión de Codex del 27-oct, verificada contra este código): con paso fijo, una órbita de halo que pasa a < 0,5 kpc del
// centro no resuelve el pericentro y el salto de rana la desvía a otra órbita: apocentro y e falsos (35 de 400 de un halo sintético
// a 0,5 Myr, hasta +670 %; HD 140283 con el paso de 1 Myr del Monte Carlo, apocentro +3,35 %). Las familias E–Lz no cambiaban (E sale
// del estado de hoy), la ficha sí. Ahora: cada CC_ORBIT_DE_EVERY pasos se mira |ΔE/E|; si pasa de CC_ORBIT_DE_TOL (también al final),
// se vuelve a empezar con la mitad de paso, hasta CC_ORBIT_MAX_HALVE veces (como ccGxtBack de ui/cc_galaxy_time.js); si ni así,
// `approx: true` y la ficha pone «≈» en peri, apo y e (ccOrbitLine de ui/cc_paint.js).
// COPIA de cshGdOrbit / cshGdLeap / cshGdLeapSafe de CabraShared/csh_galdyn.js, la misma aritmética en el mismo orden (Cabra3D/tests/
// c3_gx_cases.js G7 y G15 lo comparan a 1e-9; un cambio aquí va también allí).
var CC_ORBIT_DT_MYR = 0.5;      // diseño: paso de 0,5 Myr
var CC_ORBIT_T_MYR = 2000;      // diseño: 2 Gyr (varias vueltas de una órbita de halo local)
var CC_ORBIT_DE_TOL = 1e-3;     // |ΔE/E| máximo admitido a lo largo del camino (= CSH_GD.DE_TOL)
// (27-oct, noche; C2 H-1 de Codex) en CADA paso: mirando cada 8 se saltaba el pico del pericentro (dura menos de 8 pasos) y `dEmax` no
// era el máximo del camino (en los datos grabados: 851 de 5470 órbitas, 832 del Monte Carlo). Cuesta ×1,6-1,9; las cifras de la ficha
// no cambian (0 de 2952 a media cifra o más) y la clasificación e > 0,7 del Monte Carlo tampoco (0 cambios). Cabra3D/tests/c3_gx_cases.js G20.
var CC_ORBIT_DE_EVERY = 1;      // cada cuántos pasos se mira la energía (= CSH_GD.DE_EVERY)
var CC_ORBIT_MAX_HALVE = 4;     // divisiones del paso como mucho (= CSH_GD.MAX_HALVE)
// Una pasada de n pasos de dtM: null si `abort` y |ΔE/E| pasa de la tolerancia.
// (2-nov, noche: Q2b) SIN barra: la ficha y las familias (la de antes del 2-nov, tal cual; la barra va solo en ccGxIntegrate).
function ccOrbitLeap(s, n, dtM, abort) {
   var dt = dtM / CC_KPC_KMS_MYR, tol = CC_ORBIT_DE_TOL, de = CC_ORBIT_DE_EVERY, aE = Math.abs(s.E);
   var x = s.x, y = s.y, z = s.z, vx = s.vx, vy = s.vy, vz = s.vz, a = [0, 0, 0], r0 = Math.sqrt(x * x + y * y + z * z);
   // (R7: peri, apo y Zmax empiezan con el estado INICIAL; antes 1e9 / 0 / 0, y un tramo corto daba peri 1e9 y e −1)
   var rmin = r0, rmax = r0, zmax = Math.abs(z), dEmax = 0;
   ccAcc(x, y, z, a);
   for (var i = 0; i < n; ++i) {
      vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
      x += dt * vx; y += dt * vy; z += dt * vz;
      ccAcc(x, y, z, a);
      vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
      var r = Math.sqrt(x * x + y * y + z * z);
      if (r < rmin) rmin = r;
      if (r > rmax) rmax = r;
      if (Math.abs(z) > zmax) zmax = Math.abs(z);
      if ((i + 1) % de === 0) {
         var dEi = Math.abs(0.5 * (vx * vx + vy * vy + vz * vz) + ccPotential(x, y, z) - s.E) / aE;
         if (dEi > dEmax) { dEmax = dEi; if (abort && dEmax > tol) return null; }
      }
   }
   // deriva de la energía (control del integrador: tiene que ser pequeña)
   var dE = (0.5 * (vx * vx + vy * vy + vz * vz) + ccPotential(x, y, z) - s.E) / aE;
   if (Math.abs(dE) > dEmax) dEmax = Math.abs(dE);
   if (abort && dEmax > tol) return null;
   return { rperi: rmin, rapo: rmax, zmax: zmax, ecc: (rmax + rmin > 0) ? (rmax - rmin) / (rmax + rmin) : 0, dE: dE, dEmax: dEmax };
}
function ccOrbit(s, tMyr, dtMyr) {
   var dtM = dtMyr || CC_ORBIT_DT_MYR, n = Math.round((tMyr || CC_ORBIT_T_MYR) / dtM), o = null, h = 0, k = 1;
   // (R7: ligada solo si E < 0 de verdad; con `E >= 0` un NaN —sin velocidad radial— pasaba por ligada, con peri 1e9 y e −1)
   if (!(s.E < 0)) return { rperi: null, rapo: null, zmax: null, ecc: 1, bound: false, dE: 0, dEmax: 0, approx: false, halvings: 0, dtMyr: dtM };
   for (h = 0; h <= CC_ORBIT_MAX_HALVE; ++h) {
      k = Math.pow(2, h);
      o = ccOrbitLeap(s, n * k, dtM / k, h < CC_ORBIT_MAX_HALVE);
      if (o) break;
   }
   return { rperi: o.rperi, rapo: o.rapo, zmax: o.zmax, ecc: o.ecc, bound: true, dE: o.dE, dEmax: o.dEmax, approx: !(o.dEmax <= CC_ORBIT_DE_TOL),
            halvings: Math.min(h, CC_ORBIT_MAX_HALVE), dtMyr: dtM / k };
}

// ---------------------------------------------------------------------------
// LAS FAMILIAS (Naidu et al. 2020, §3; cajas traducidas a Lz prógrado > 0)
// ---------------------------------------------------------------------------
// Las cajas en E, en la energía del potencial de ESTE fichero: las de Naidu (en la del v1) + CC_NAIDU_DE.
// CC_NAIDU_DE = Φ_v2(Sol) − Φ_v1(Sol) en (−8,122; 0; 0,0208) kpc = −155 350,7 − (−156 368,7) = +1 018,0 km²/s²
// (cuenta en docs/potencial_g1.md §4; la recalcula tests/cc_node_potential.js con un v1 escrito aparte).
// Si cambia el potencial, cambia esta cifra: la prueba lo ve.
var CC_NAIDU_DE = 1018.0;
var CC_NAIDU_E = { THAMNOS: [-1.5e5, -1.3e5], RETRO: -1.25e5, WUKONG: [-1.35e5, -0.9e5] };   // Naidu+2020 ec. 6-8, energía de gala v1
var CC_FAM = {
   DISC_ETA: 0.5,          // diseño: circularidad mínima del disco (sustituye al corte |Z| > 2 kpc de Naidu)
   GSE_ECC: 0.7,           // Naidu ec. 4: e > 0,7
   HELMI_LZ: [750, 1700], HELMI_LPERP: [1600, 3200],                  // ec. 5 (Koppelman et al. 2019, «caja B»)
   THAMNOS_LZ: [-1500, -200], THAMNOS_E: [CC_NAIDU_E.THAMNOS[0] + CC_NAIDU_DE, CC_NAIDU_E.THAMNOS[1] + CC_NAIDU_DE], THAMNOS_FEH: -1.6,   // ec. 6
   RETRO_ETA: -0.15, RETRO_LZ: -700, RETRO_E: CC_NAIDU_E.RETRO + CC_NAIDU_DE,          // ec. 7 (Arjuna / Sequoia / I'itoi por [Fe/H])
   ARJUNA_FEH: -1.5, IITOI_FEH: -2.0,
   WUKONG_LZ: [200, 1000], WUKONG_E: [CC_NAIDU_E.WUKONG[0] + CC_NAIDU_DE, CC_NAIDU_E.WUKONG[1] + CC_NAIDU_DE], WUKONG_FEH: -1.45,   // ec. 8
   SGR_A: -0.3, SGR_B: -2500,                                          // ec. 1: Ly < −0,3 Lz − 2,5e3 (convención de Naidu)
   DRAWS: 32,              // diseño: la primera tanda de sorteos del Monte Carlo de la pertenencia
   DRAWS_MAX: 256          // (30-oct) hasta aquí si la primera tanda no es unánime
};
var CC_FAM_ACCRETED = { sgr: true, helmi: true, gse: true, thamnos: true, arjuna: true, sequoia: true, iitoi: true, retro: true, wukong: true };
var CC_FAM_NAME = {
   en: { disc: "disc", insitu: "in-situ halo (high α)", sgr: "Sagittarius", gse: "Gaia-Enceladus", helmi: "Helmi streams", thamnos: "Thamnos",
         arjuna: "Arjuna", sequoia: "Sequoia", iitoi: "I'itoi", retro: "retrograde high-energy halo (Sequoia/Arjuna/I'itoi)", wukong: "Wukong", halo: "unclassified halo" },
   es: { disc: "disco", insitu: "halo in situ (α alto)", sgr: "Sagitario", gse: "Gaia-Enceladus", helmi: "corrientes de Helmi", thamnos: "Thamnos",
         arjuna: "Arjuna", sequoia: "Sequoia", iitoi: "I'itoi", retro: "halo retrógrado energético (Sequoia/Arjuna/I'itoi)", wukong: "Wukong", halo: "halo sin clasificar" }
};
// (30-oct, N2 de la revisión de Codex) la rama de las NO LIGADAS (E ≥ 0): no es una familia, es un aviso; se añade aquí para que todo el que
// busque el nombre lo encuentre. Medido: 3 de 2741 en los campos grabados; ninguna dato bueno seguro (RV de APOGEE +781 y +808 km/s; RUWE 23).
CC_FAM_NAME.en.unbound = "unbound (doubtful data)";
CC_FAM_NAME.es.unbound = "no ligada (dato dudoso)";
// Las costuras rojas de las familias (se leen una vez por estrella: ccFamilies las refresca). CC_BREAK=sci-phaseeta,sci-nounbound,sci-draws32 o ccBroken.
var CC_FAM_BRK = { phaseEta: false, noUnbound: false, draws32: false };
function ccFamBrk(k) { try { return (typeof ccEngineBreak === "function") ? !!ccEngineBreak(k) : ((typeof ccBroken === "function") && !!ccBroken(k)); } catch (e) { return false; } }
function ccFamBrkRefresh() { CC_FAM_BRK.phaseEta = ccFamBrk("sci-phaseeta"); CC_FAM_BRK.noUnbound = ccFamBrk("sci-nounbound"); CC_FAM_BRK.draws32 = ccFamBrk("sci-draws32"); }
// L_c(E): el momento angular de la órbita circular de energía E. Se invierte la curva ccCircularCurve (R de 0,2 a 40 kpc a pasos de ×1,04; interpolación
// lineal: error relativo < 1e-3 frente a la inversión exacta, tests/cc_node_famgate.js) y, fuera de la tabla, por bisección en R. E ≥ 0: no hay órbita circular.
function ccEcOfR(R) { var vc = ccVcirc(R); return ccPotential(R, 0, 0) + 0.5 * vc * vc; }
function ccLcOfE(E) {
   if (!(E < 0)) return Infinity;
   var p = ccCircularCurve(), n = p.length, lo = 0, hi = n - 1;
   if (E < p[0][1] || E > p[n - 1][1]) {
      var a = (E < p[0][1]) ? 1e-3 : 30, b = (E < p[0][1]) ? 0.2 : 1e7;      // (30 y no 40: la tabla acaba un pelo antes de 40 kpc y por encima de ella hay que buscar de verdad)
      if (E <= ccEcOfR(a)) return a * ccVcirc(a);
      if (E >= ccEcOfR(b)) return b * ccVcirc(b);
      for (var i = 0; i < 60; ++i) { var m = Math.sqrt(a * b); if (ccEcOfR(m) < E) a = m; else b = m; }
      var R = Math.sqrt(a * b);
      return R * ccVcirc(R);
   }
   while (hi - lo > 1) { var c = (lo + hi) >> 1; if (p[c][1] <= E) lo = c; else hi = c; }
   var u = (p[hi][1] > p[lo][1]) ? (E - p[lo][1]) / (p[hi][1] - p[lo][1]) : 0;
   return p[lo][0] + u * (p[hi][0] - p[lo][0]);
}
// η_E = Lz / L_c(E): la circularidad de la ÓRBITA, con sus dos integrales de movimiento; no cambia a lo largo de ella (la η instantánea, Lz / (r·v), sí).
function ccEtaE(d) { var Lc = ccLcOfE(d.E); return (Lc > 0 && isFinite(Lc)) ? d.Lz / Lc : 0; }
// El corte químico del halo in situ de Naidu (ec. 3): [α/Fe] > 0,25 − 0,5([Fe/H] + 0,7).
function ccInsituChem(feh, alpha) {
   return ccIsNum(feh) && ccIsNum(alpha) && alpha > 0.25 - 0.5 * (feh + 0.7);
}
// La familia de UN estado. `orbitOf` () -> órbita (se calcula solo si hace falta: GSE).
function ccFamilyOf(d, feh, alpha, orbitOf) {
   var F = CC_FAM;
   // (30-oct, N2) E ≥ 0: con estos datos no daría ni una vuelta, así que ninguna caja de abajo significa nada. Antes salía «disco · P 1,00» (η alta y
   // sin órbita) y, en los sorteos, «gse» (una órbita no ligada lleva ecc = 1). Costura «sci-nounbound».
   if (d.E >= 0 && !CC_FAM_BRK.noUnbound) return "unbound";
   if (d.LyN < F.SGR_A * d.LzN + F.SGR_B) return "sgr";
   if (d.Lz > F.HELMI_LZ[0] && d.Lz < F.HELMI_LZ[1] && d.Lperp > F.HELMI_LPERP[0] && d.Lperp < F.HELMI_LPERP[1]) return "helmi";
   // (30-oct, D1-H1) el filtro de disco con η_E = Lz / L_c(E), que no depende de en qué punto de la órbita se ve a la estrella. Con la η instantánea, 19 de 2738 saltaban de
   // familia a lo largo de su propia órbita, y una con e 0,82 salía «disco». Es diseño nuestro, como el filtro: Naidu define η con la misma aproximación pero no filtra así. Costura «sci-phaseeta».
   if ((CC_FAM_BRK.phaseEta ? d.eta : ccEtaE(d)) >= F.DISC_ETA) return "disc";
   if (ccInsituChem(feh, alpha)) return "insitu";
   var o = orbitOf();
   if (o && o.ecc > F.GSE_ECC) return "gse";
   var hasFe = ccIsNum(feh);
   if (d.Lz > F.THAMNOS_LZ[0] && d.Lz < F.THAMNOS_LZ[1] && d.E > F.THAMNOS_E[0] && d.E < F.THAMNOS_E[1] && hasFe && feh < F.THAMNOS_FEH) return "thamnos";
   if (d.eta < F.RETRO_ETA && d.Lz < F.RETRO_LZ && d.E > F.RETRO_E) {
      if (!hasFe) return "retro";
      return feh > F.ARJUNA_FEH ? "arjuna" : (feh < F.IITOI_FEH ? "iitoi" : "sequoia");
   }
   if (d.Lz > F.WUKONG_LZ[0] && d.Lz < F.WUKONG_LZ[1] && d.E > F.WUKONG_E[0] && d.E < F.WUKONG_E[1] && hasFe && feh < F.WUKONG_FEH) return "wukong";
   return "halo";
}
// La pertenencia con su probabilidad: Monte Carlo sobre los errores (distancia 16-84,
// pm, RV). s = { id, ra, dec, pmra, pmdec, epmra, epmdec, dist: {pc, lo, hi}, rv: {v, e} }.
// Devuelve null si falta algo; si no, { best, p, probs, nominal: dyn, orbit, draws }.
function ccFamilies(s, feh, alpha) {
   if (!s || !ccIsNum(s.ra) || !ccIsNum(s.pmra) || !ccIsNum(s.pmdec) || !s.dist || !(s.dist.pc > 0) || !s.rv || !ccIsNum(s.rv.v)) return null;
   ccFamBrkRefresh();
   var d0 = ccDynState(s.ra, s.dec, s.dist.pc, s.pmra, s.pmdec, s.rv.v);
   var orb0 = null;
   function nominalOrbit() { if (!orb0) orb0 = ccOrbit(d0); return orb0; }
   var nomFam = ccFamilyOf(d0, feh, alpha, nominalOrbit);
   var out = { nominal: d0, orbit: null, probs: {}, best: nomFam, p: 1, draws: 0 };
   // las de disco claro (η alta) no necesitan sorteos con órbita: se sortea solo E y Lz
   var lo = ccIsNum(s.dist.lo) ? s.dist.lo : s.dist.pc * 0.9, hi = ccIsNum(s.dist.hi) ? s.dist.hi : s.dist.pc * 1.1;
   var eL = Math.max(0, s.dist.pc - lo), eH = Math.max(0, hi - s.dist.pc);
   var erv = ccIsNum(s.rv.e) ? s.rv.e : 1, epa = ccIsNum(s.epmra) ? s.epmra : 0.05, epd = ccIsNum(s.epmdec) ? s.epmdec : 0.05;
   var rng = ccRng(ccSeedOf("fam" + (s.id || (s.ra + "," + s.dec)))), n = CC_FAM.DRAWS, nMax = CC_FAM_BRK.draws32 ? n : Math.max(n, CC_FAM.DRAWS_MAX), cnt = {}, i;
   // (30-oct, D1-H3, decisión C de Nino) POR TANDAS: los primeros DRAWS sorteos (los de siempre, con la misma semilla) y, si no son unánimes, hasta DRAWS_MAX. La inmensa mayoría (disco claro) para en la primera tanda.
   for (i = 0; i < nMax; ++i) {
      if (i === n) { var nk = 0; for (var kn in cnt) if (cnt.hasOwnProperty(kn)) ++nk; if (nk <= 1) break; }
      var zd = rng.n(), dpc = s.dist.pc + (zd < 0 ? zd * eL : zd * eH);
      if (!(dpc > 1)) dpc = 1;
      var di = ccDynState(s.ra, s.dec, dpc, s.pmra + rng.n() * epa, s.pmdec + rng.n() * epd, s.rv.v + rng.n() * erv);
      var oi = null;
      // (R2, 27-oct: 1 Myr y 1,2 Gyr de diseño, pero ccOrbit parte el paso si la energía se va: HD 140283 lo parte 3 veces y su
      //  apocentro pasa de 15,59 —un 3,35 % alto— a 15,09 kpc, el de la referencia)
      var f = ccFamilyOf(di, feh, alpha, function() { if (!oi) oi = ccOrbit(di, 1200, 1.0); return oi; });
      cnt[f] = (cnt[f] || 0) + 1;
   }
   n = i;
   var best = null, bc = -1;
   for (var k in cnt) if (cnt.hasOwnProperty(k)) { out.probs[k] = cnt[k] / n; if (cnt[k] > bc) { bc = cnt[k]; best = k; } }
   out.best = best; out.p = bc / n; out.draws = n; out.nominalFamily = nomFam;
   // (30-oct, N2) si con sus valores centrales no está ligada, lo es la ESTRELLA, aunque algún sorteo caiga dentro: la ficha dice que el dato puede ser malo.
   if (nomFam === "unbound") { out.best = "unbound"; out.p = out.probs.unbound || 0; }
   // la órbita nominal (para la ficha: e, pericentro, apocentro, Zmax), siempre
   out.orbit = nominalOrbit();
   out.accreted = !!CC_FAM_ACCRETED[out.best];
   return out;
}

// ---------------------------------------------------------------------------
// PARA DIBUJAR EL PLANO E–Lz
// ---------------------------------------------------------------------------
// La órbita circular: E_c(Lz) es el MÍNIMO de energía para cada Lz (el borde inferior
// del plano; el disco fino vive justo encima). Lz prógrado > 0 y retrógrado < 0 dan la misma curva.
var CC_ECIRC = null;
function ccCircularCurve() {
   if (CC_ECIRC) return CC_ECIRC;
   var pts = [];
   for (var R = 0.2; R <= 40; R *= 1.04) {
      var vc = ccVcirc(R), Lz = R * vc, E = ccPotential(R, 0, 0) + 0.5 * vc * vc;
      pts.push([Lz, E]);
   }
   CC_ECIRC = pts;
   return pts;
}
// El contorno e = 0,7 de las órbitas EN EL PLANO (z = 0) en (Lz, E): para cada (Lz, E), los
// radios de giro son las raíces de E = Φ(R, 0) + Lz²/(2R²). Es la región de G-E de Naidu
// (e > 0,7) aproximada sin altura: SOLO para pintar; la pertenencia usa la órbita 3D.
var CC_GSE_GRID = null;
function ccPlanarEcc(Lz, E) {
   function f(R) { return ccPotential(R, 0, 0) + Lz * Lz / (2 * R * R) - E; }
   // mínimo del potencial efectivo: la órbita circular de ese Lz
   var lo = 0.01, hi = 200, Rc = 0, best = 1e99;
   for (var R = 0.02; R < 200; R *= 1.05) { var v = f(R); if (v < best) { best = v; Rc = R; } }
   if (best > 0) return null;                  // energía por debajo de la circular: imposible
   function root(a, b) { var fa = f(a); for (var i = 0; i < 60; ++i) { var m = 0.5 * (a + b), fm = f(m); if ((fm > 0) === (fa > 0)) { a = m; fa = fm; } else b = m; } return 0.5 * (a + b); }
   var rp = (f(lo) > 0) ? root(lo, Rc) : lo, ra = (f(hi) > 0) ? root(Rc, hi) : hi;
   return (ra - rp) / (ra + rp);
}
function ccGseGrid(lz0, lz1, e0, e1, nx, ny) {
   var key = [lz0, lz1, e0, e1, nx, ny].join(",");
   if (CC_GSE_GRID && CC_GSE_GRID.key === key) return CC_GSE_GRID;
   var v = [];
   for (var j = 0; j < ny; ++j) for (var i = 0; i < nx; ++i) {
      var Lz = lz0 + (i + 0.5) * (lz1 - lz0) / nx, E = e0 + (j + 0.5) * (e1 - e0) / ny;
      var e = ccPlanarEcc(Lz, E);
      v.push(e === null ? -1 : e);
   }
   CC_GSE_GRID = { key: key, nx: nx, ny: ny, x0: lz0, x1: lz1, y0: e0, y1: e1, v: v };
   return CC_GSE_GRID;
}

// Los tres Miyamoto-Nagai del disco, al cargar.
ccPotSetup();
