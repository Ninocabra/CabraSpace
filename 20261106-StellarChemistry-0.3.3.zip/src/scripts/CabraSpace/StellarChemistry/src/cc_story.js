// ============================================================================
// src/cc_story.js — LA BIOGRAFÍA EN LLANO (petición de Nino, 14-oct-2026)
// ----------------------------------------------------------------------------
// «Que la entienda cualquiera sin saber astrofísica»: debajo del titular, un párrafo
// que cuenta la historia de ESA estrella con SUS números — edad frente al Sol y a la
// Galaxia, qué significa su metalicidad, qué es su población, qué dice su α, qué tipo
// de estrella es y cuánto tarda su luz en llegar — y la incertidumbre dicha en llano.
//
// REGLA: todo sale de los datos por plantillas (un caso por rango de cada dato); si un
// dato falta, la frase lo DICE y no afirma nada de él. Nunca texto inventado.
// ccStory(star, lang) -> [ frase, ... ]       ccGloss(key, lang) -> explicación de una etiqueta
// ccFehPlain(feh, lang) · ccAlphaPlain(chemClass, lang) · ccLzPlain(fam.nominal | Lz, lang): cifras traducidas.
// Pura (node y PixInsight). ES5.
// ============================================================================

var CC_SUN_AGE = 4.6;          // Ga (Bouvier & Wadhwa 2010: 4,568)
var CC_GALAXY_AGE = 13.0;      // Ga: las estrellas más viejas de la Vía Láctea (orden de magnitud, ver CC_TIMELINE)
var CC_PC_TO_LY = 3.26156;

function ccL(lang) { return lang === "es" ? "es" : "en"; }
// Número con separador de miles a la española o inglesa y cifras significativas razonables.
function ccNice(x, lang, sig) {
   if (!ccIsNum(x)) return "—";
   var p = Math.pow(10, Math.max(0, Math.floor(Math.log(Math.abs(x)) / Math.LN10) - (sig || 2) + 1));
   var v = Math.round(x / p) * p, s = String(Math.round(v));
   var sep = lang === "es" ? " " : ",";
   return s.replace(/\B(?=(\d{3})+(?!\d))/g, sep);
}
function ccDec(x, d, lang) { var s = ccFmt(x, d); return lang === "es" ? s.replace(".", ",") : s; }
// Un recuento exacto con separador de miles (29 189 en castellano; 29,189 en inglés).
function ccThou(n, lang) { if (!ccIsNum(n)) return "—"; return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, lang === "es" ? "\u00a0" : ","); }
// Un intervalo de edades en llano: «entre 9,0 y 13,0 mil millones», «entre 700 y 900 millones», «entre 700 millones y 1,1 mil millones».
function ccGaRange(lo, hi, lang) {
   var E = lang === "es", sep = E ? " y " : " and ";
   if (lo >= 0.95) return ccDec(lo, 1, lang) + sep + ccGaPlain(hi, lang);
   if (hi < 0.95) return ccThou(Math.max(100, Math.round(lo * 10) * 100), lang) + sep + ccGaPlain(hi, lang);
   return ccGaPlain(lo, lang) + sep + ccGaPlain(hi, lang);
}
// Una edad en Ga dicha en llano: «900 millones» por debajo de mil millones, «3,0 mil millones» por encima.
function ccGaPlain(v, lang) {
   if (v < 0.95) { var m = Math.max(100, Math.round(v * 10) * 100); return lang === "es" ? ccThou(m, "es") + " millones" : ccThou(m, "en") + " million"; }
   return lang === "es" ? ccDec(v, 1, "es") + " mil millones" : ccDec(v, 1, "en") + " billion";
}

// [Fe/H] traducido: «la mitad de hierro que el Sol», «unas 300 veces menos hierro…».
function ccFehPlain(feh, lang) {
   var L = ccL(lang);
   if (!ccIsNum(feh)) return "";
   var f = Math.pow(10, feh);
   if (f >= 1.15) return L === "es" ? "un " + Math.round(100 * (f - 1)) + " % más de hierro que el Sol" : Math.round(100 * (f - 1)) + "% more iron than the Sun";
   if (f > 0.87) return L === "es" ? "casi el mismo hierro que el Sol" : "almost the same iron as the Sun";
   if (f >= 0.4) {
      if (Math.abs(f - 0.5) < 0.06) return L === "es" ? "la mitad de hierro que el Sol" : "half the Sun’s iron";
      return L === "es" ? "un " + Math.round(100 * f) + " % del hierro del Sol" : Math.round(100 * f) + "% of the Sun’s iron";
   }
   var n = 1 / f;
   return L === "es" ? "unas " + ccNice(n, "es", n < 10 ? 1 : 2) + " veces menos hierro que el Sol" : "about " + ccNice(n, "en", n < 10 ? 1 : 2) + " times less iron than the Sun";
}
function ccAlphaPlain(cc, lang) {
   var L = ccL(lang);
   if (!cc || cc.pHigh === null || cc.pHigh === undefined) return "";
   if (cc.pHigh >= 0.84) return L === "es" ? "mucho magnesio para su hierro (α alto)" : "a lot of magnesium for its iron (high α)";
   if (cc.pHigh <= 0.16) return L === "es" ? "magnesio y hierro en proporción como el Sol (α bajo)" : "magnesium and iron in Sun-like proportion (low α)";
   return L === "es" ? "en la frontera entre α alto y bajo" : "on the border between high and low α";
}
// (28-oct, G2/H4) CÓMO GIRA ALREDEDOR DE LA GALAXIA, dicho como lo que es. `nom` = el estado de hoy (fam.nominal de cc_dynamics.js:
// { Lz, x, y }, kpc y km/s; Lz > 0 = a favor del giro) o, de compatibilidad, solo el número Lz.
// ANTES decía «gira con la Galaxia al 153 % del Sol» con Lz/Lz☉, y Lz NO es una velocidad: es MOMENTO ANGULAR, Lz = R · vφ (distancia al eje
// de la Galaxia × velocidad de giro). Una estrella lejos del centro tiene mucho Lz aunque gire más despacio que el Sol: la del «153 %»
// (M 67, Gaia DR3 598907836235994880, R = 14,6 kpc) gira a 209 km/s, el 85 % de los 246 del Sol. Medido en los 8 campos grabados
// (scratchpad lz/m_lz.js): de 2 710 «gira», 1 162 se apartaban ≥ 5 puntos de vφ/vφ☉, hasta 166 puntos (Collinder 34, R 19,3 kpc).
// AHORA: con la posición, la velocidad de giro REAL vφ = Lz / R (la de ccGalactocentric, cc_science.js) frente a la del Sol
// (CC_SCI.VSUN_GC[1]); sin posición (solo Lz), Lz comparado como momento angular, sin llamarlo velocidad.
// Los cortes (−150 y 300 kpc km/s) siguen en Lz, el eje de las familias E–Lz: en lo grabado separan también vφ (casi no gira: −21…+39 km/s;
// gira: ≥ 38,7; al revés: ≤ −22). Costura «sci-lzpct»: la frase de antes (el rojo de cc_node_story_rot.js).
function ccLzPlain(nom, lang) {
   var L = ccL(lang), E = (L === "es");
   var Lz = (nom && typeof nom === "object") ? nom.Lz : nom;
   if (!ccIsNum(Lz)) return "";
   var vSun = CC_SCI.VSUN_GC[1], LzSun = CC_SCI.R0_KPC * vSun;     // el Sol: vφ 245,6 km/s y Lz 1 995 kpc km/s (R0 8,122 kpc)
   if (typeof ccSciBroken === "function" && ccSciBroken("sci-lzpct")) {      // (ROJO: lo de antes, Lz/Lz☉ como si fuera velocidad)
      if (Lz < -150) return E ? "gira al revés que la Galaxia" : "orbits against the Galaxy’s rotation";
      if (Lz < 300) return E ? "casi no gira con la Galaxia" : "hardly rotates with the Galaxy";
      return E ? "gira con la Galaxia al " + Math.round(100 * Lz / 1990) + " % del Sol" : "rotates with the Galaxy at " + Math.round(100 * Lz / 1990) + "% of the Sun’s rate";
   }
   var R = (nom && typeof nom === "object" && ccIsNum(nom.x) && ccIsNum(nom.y)) ? Math.sqrt(nom.x * nom.x + nom.y * nom.y) : null;
   var v = (R !== null && R > 0.1) ? Lz / R : null, vs = Math.round(vSun);
   if (v !== null) {
      // la cifra y «km/s» van con espacio DURO (U+00A0; ccWrap no parte por él): la captura del 28-oct partía «220 / km/s» entre dos líneas.
      // Costura «sci-lznbsp»: espacio normal (el rojo de cc_node_story_rot.js S5).
      var K = ((typeof ccSciBroken === "function" && ccSciBroken("sci-lznbsp")) ? " " : " ") + "km/s";
      var va = Math.round(Math.abs(v));
      if (Lz < -150) return E ? "gira al revés que la Galaxia, a " + va + K + " (el Sol va a " + vs + K + " a favor)" : "orbits against the Galaxy’s rotation, at " + va + K + " (the Sun goes " + vs + K + " with it)";
      if (Lz < 300) return E ? "casi no gira con la Galaxia (" + (v < 0 ? "−" : "") + va + K + "; el Sol, " + vs + K + ")" : "hardly rotates with the Galaxy (" + (v < 0 ? "−" : "") + va + K + "; the Sun, " + vs + K + ")";
      return E ? "gira con la Galaxia a " + va + K + " (el Sol, a " + vs + K + ")" : "rotates with the Galaxy at " + va + K + " (the Sun, at " + vs + K + ")";
   }
   if (Lz < -150) return E ? "gira al revés que la Galaxia" : "orbits against the Galaxy’s rotation";
   if (Lz < 300) return E ? "casi no gira con la Galaxia" : "hardly rotates with the Galaxy";
   var k = ccDec(Lz / LzSun, 2, L);
   return E ? "gira con la Galaxia, con " + k + " veces el momento angular del Sol" : "rotates with the Galaxy, with " + k + " times the Sun’s angular momentum";
}
// (P1, 23-oct) LA FORMA DE UNA ÓRBITA por su excentricidad, con los cortes de CC_SCI.ECC_BINS (0,2 · 0,5 · 0,7; su fuente, allí):
// «casi circular» (lo típico del disco fino) · «algo alargada» (lo del grueso) · «alargada» · «muy alargada» (la de Gaia-Enceladus).
function ccEccPlain(e, lang) {
   var E = ccL(lang) === "es", B = CC_SCI.ECC_BINS;
   if (!ccIsNum(e)) return "";
   if (typeof ccSciBroken === "function" && ccSciBroken("sci-oldecc"))      // (el de antes, solo para ver el rojo: «casi circular» hasta 0,3)
      return E ? (e > 0.7 ? "muy alargada" : (e > 0.3 ? "algo alargada" : "casi circular")) : (e > 0.7 ? "very elongated" : (e > 0.3 ? "somewhat elongated" : "nearly circular"));
   if (e > B[2]) return E ? "muy alargada" : "very elongated";
   if (e >= B[1]) return E ? "alargada" : "elongated";
   if (e >= B[0]) return E ? "algo alargada" : "somewhat elongated";
   return E ? "casi circular" : "nearly circular";
}
// La excentricidad de la órbita del SOL en el mismo potencial (cc_dynamics.js), para comparar: se calcula una vez (null sin cc_dynamics).
var CC_SUN_ECC = null;
function ccSunEcc() {
   if (CC_SUN_ECC === null && typeof ccDynState === "function" && typeof ccOrbit === "function") {
      try { var o = ccOrbit(ccDynState(0, 0, 1e-6, 0, 0, 0)); CC_SUN_ECC = (o && ccIsNum(o.ecc)) ? o.ecc : false; } catch (e) { CC_SUN_ECC = false; }
   }
   return CC_SUN_ECC === false ? null : CC_SUN_ECC;
}
// (P7, 23-oct) LA ZMAX ESCRITA, con «≈» si es aproximada (inestable o pericentro < CC_SCI.ZMAX_PERI_KPC: cc_engine.js marca o.zmaxApprox).
// «≈ 5,4» · «0,45» (dos decimales por debajo de 1 kpc, como ccOrbitLine). "" sin Zmax. La usan la ficha (ccOrbitLine) y el relato.
function ccZmaxText(o, lang) {
   if (!o || !ccIsNum(o.zmax)) return "";
   var L = ccL(lang);
   return (o.zmaxApprox ? "≈ " : "") + ccDec(o.zmax, o.zmax < 1 ? 2 : 1, L);
}
// El tipo de estrella por su gravedad y su temperatura.
function ccStarKind(logg, teff, lang) {
   var L = ccL(lang), kind = "", col = "";
   if (ccIsNum(logg)) {
      if (logg < 3.5) kind = L === "es" ? "Es una gigante: ya agotó el hidrógeno de su centro y se ha hinchado; ahora brilla mucho más que el Sol." :
                                          "It is a giant: it has used up the hydrogen in its core and swollen up; it now shines far brighter than the Sun.";
      else if (logg < 3.9) kind = L === "es" ? "Es una subgigante: está dejando su larga etapa estable y empieza a hincharse." :
                                               "It is a subgiant: it is leaving its long stable stage and starting to swell.";
      else kind = L === "es" ? "Es una enana como el Sol: está en la etapa larga y tranquila de su vida, quemando hidrógeno en su centro." :
                               "It is a dwarf like the Sun: in the long, quiet stage of its life, burning hydrogen in its core.";
   }
   if (ccIsNum(teff)) {
      if (teff < 4000) col = L === "es" ? " Su superficie está a unos " + ccNice(teff, "es", 2) + " K: se vería anaranjada-rojiza." : " Its surface is about " + ccNice(teff, "en", 2) + " K: it would look orange-red.";
      else if (teff < 5300) col = L === "es" ? " Su superficie está a unos " + ccNice(teff, "es", 2) + " K, más fría que el Sol (5 800 K): se vería anaranjada." : " Its surface is about " + ccNice(teff, "en", 2) + " K, cooler than the Sun (5,800 K): it would look orange.";
      else if (teff < 6300) col = L === "es" ? " Su superficie está a unos " + ccNice(teff, "es", 2) + " K, como el Sol: se vería amarilla." : " Its surface is about " + ccNice(teff, "en", 2) + " K, like the Sun: it would look yellow.";
      else col = L === "es" ? " Su superficie está a unos " + ccNice(teff, "es", 2) + " K, más caliente que el Sol: se vería blanca." : " Its surface is about " + ccNice(teff, "en", 2) + " K, hotter than the Sun: it would look white.";
   }
   return kind + col;
}

function ccStory(s, lang) {
   var L = ccL(lang), E = (L === "es"), out = [], grp = 0;
   out.g = [];      // el grupo (párrafo) de cada frase: 0 edad · 1 composición y población · 2 órbita · 3 tipo y distancia
   function add(t) { out.push(t); out.g.push(grp); }
   if (!s) return out;
   var ch = s.chem || {}, feh = ch.feh ? ch.feh.v : null, a = (s.age && s.age.adopted) ? s.age.adopted : null;
   // 1 · la edad, comparada con el Sol y con la Galaxia, y su incertidumbre en llano
   var vague = a && ccAgeVague(a);
   if (vague) {
      // (orientativa o muy incierta: el intervalo en llano, y el Sol solo si cae claramente a un lado)
      var rg = ccAgeRange(a), very = ccAgeVeryUncertain(a), t0;
      t0 = E ? (very ? "Su edad es muy incierta: entre " : "Su edad está entre ") + ccGaRange(rg[0], rg[1], "es") + " de años"
             : (very ? "Its age is very uncertain: between " : "Its age is between ") + ccGaRange(rg[0], rg[1], "en") + " years";
      if (rg[0] > 1.25 * CC_SUN_AGE) t0 += E ? " (más vieja que el Sol, que tiene 4 600 millones)" : " (older than the Sun, which is 4.6 billion)";
      else if (rg[1] < 0.8 * CC_SUN_AGE) t0 += E ? " (más joven que el Sol, que tiene 4 600 millones)" : " (younger than the Sun, which is 4.6 billion)";
      else t0 += E ? " (la del Sol, 4 600 millones, cae dentro)" : " (the Sun’s, 4.6 billion, falls inside)";
      add(t0 + ".");
   }
   if (a) {
      var v = a.v, t = "";
      if (E) t = "Tiene unos " + ccGaPlain(v, "es") + " de años";
      else t = "It is about " + ccGaPlain(v, "en") + " years old";
      if (v > 1.25 * CC_SUN_AGE) t += E ? " (" + ccDec(v / CC_SUN_AGE, 1, "es") + " veces la edad del Sol, que tiene 4 600 millones)" : " (" + ccDec(v / CC_SUN_AGE, 1, "en") + " times the age of the Sun, which is 4.6 billion)";
      else if (v >= 0.8 * CC_SUN_AGE) t += E ? " (más o menos como el Sol, que tiene 4 600 millones)" : " (roughly like the Sun, which is 4.6 billion)";
      else t += E ? " (más joven que el Sol, que tiene 4 600 millones)" : " (younger than the Sun, which is 4.6 billion)";
      if (v >= 11.5) t += E ? ": casi tan vieja como la propia Galaxia." : ": almost as old as the Galaxy itself.";
      else t += E ? ": nació cuando la Galaxia, que hoy tiene unos 13 600 millones de años, ya tenía unos " + ccDec(13.6 - v, 1, "es") + " mil millones." :
                    ": it was born when the Galaxy, about 13.6 billion years old today, was already about " + ccDec(13.6 - v, 1, "en") + " billion years old.";
      if (!vague) add(t);
      var lo = Math.max(0, a.lo), hi = Math.min(CC_SCI.UNIVERSE_GA, a.hi);     // nada es más viejo que el Universo
      var u = vague ? "" : (E ? "Podría tener entre " + ccGaRange(lo, hi, "es") + " de años" : "It could be anywhere between " + ccGaRange(lo, hi, "en") + " years old");
      // (27-oct, R1b) su margen de error llegaba más allá: se corta en la edad del Universo, y se dice
      if (!vague) u += (typeof ccAgeCapped === "function" && ccAgeCapped(a)) ? (E ? " (el tope es la edad del Universo). " : " (the ceiling is the age of the Universe). ") : ". ";
      if (a.tier === "A" && a.src === "xr22") u += E ? "Es de las edades más fiables que se pueden medir hoy: es una subgigante, la etapa en que la edad de una estrella se nota más." :
                                                       "This is among the most reliable ages measurable today: it is a subgiant, the stage where a star’s age shows most.";
      else if (a.tier === "A" && a.warn) u += E ? "El método está calibrado con las vibraciones de las estrellas (sismología), pero esta estrella queda en el borde de las que sirvieron para calibrarlo (" + (/BLUER/.test(a.warn) ? "más azul" : "más roja") + " que ellas), así que el catálogo avisa de que su edad es menos fiable." :
                                        "The method is calibrated with the oscillations of stars (asteroseismology), but this star lies at the edge of those used to calibrate it (" + (/BLUER/.test(a.warn) ? "bluer" : "redder") + " than them), so the catalogue warns that its age is less reliable.";
      else if (a.tier === "A") u += E ? "Es de las edades más fiables que se pueden medir hoy: el método está calibrado con las vibraciones de las estrellas (sismología)." :
                                        "This is among the most reliable ages measurable today: the method is calibrated with the oscillations of stars (asteroseismology).";
      else if (a.tier === "B") u += E ? "Sale de comparar la estrella con modelos de cómo envejecen las estrellas; en una estrella ya evolucionada funciona razonablemente, pero las edades estelares nunca son exactas." :
                                        "It comes from comparing the star with models of how stars age; for an evolved star that works reasonably well, but stellar ages are never exact.";
      // (28-oct, pendiente 8) FLAME en una gigante (Flags-Flame A=1, dentro de 1–2 M☉): lo que avisa el propio catálogo (ReadMe I/355, nota 4).
      // «gigante» lo dice la BANDERA de Gaia, no nuestro log g: una de M 67 (log g 3,56) la marca FLAME como gigante y el relato la llama
      // subgigante, así que la frase atribuye la palabra al catálogo en vez de decir «esta gigante».
      else if (ccAgeVagueWhy(a, ch.logg) === "flame-giant") u += E ? "Es solo orientativa: Gaia la calcula comparando la estrella con modelos de composición como la del Sol (FLAME); el propio catálogo la marca como gigante y avisa de que entonces la edad tiene un 20-30 % de incertidumbre." :
                                                                     "It is only indicative: Gaia computes it by comparing the star with models of Sun-like composition (FLAME); the catalogue itself flags it as a giant and warns that its age is then uncertain by 20-30%.";
      else if (ccAgeVagueWhy(a, ch.logg) === "kord-giant") u += E ?"Es solo orientativa: sale de comparar esta gigante con modelos (Kordopatis et al. 2023), y en el cúmulo M 67 ese método da a las gigantes unos 1 700 millones de años de más." :
                                                                    "It is only indicative: it comes from comparing this giant with models (Kordopatis et al. 2023), and in the cluster M 67 that method makes giants about 1.7 billion years too old.";
      else u += E ? "Es solo orientativa: una estrella como el Sol pasa miles de millones de años casi sin cambiar, así que los modelos apenas distinguen una edad de otra (en el cúmulo M 67 lo comprobamos: salen unos 2 000 millones de años de más)." :
                    "It is only indicative: a star like the Sun spends billions of years barely changing, so models can hardly tell one age from another (we checked it in the cluster M 67: they come out about 2 billion years too old).";
      if (a.edge) u += E ? " Además toca el límite de los modelos: léela como «de las más viejas»." : " It also hits the model limit: read it as “among the oldest”.";
      // una del disco fino tan vieja sería rara: se dice (no se esconde la tensión)
      if (a.v >= 10 && s.pop && s.pop.label === "thin") u += E ? " Ojo: una estrella del disco fino tan vieja sería rara; lo más probable es que su edad esté sobreestimada." :
                                                                  " Note: a thin-disc star this old would be rare; most likely its age is overestimated.";
      add(u);
   } else {
      add(E ? "No se ha podido medir su edad." : "Its age could not be measured.");
   }
   // 2 · de qué está hecha
   grp = 1;
   if (feh !== null) {
      var fp = ccFehPlain(feh, L), f = Math.pow(10, feh), m;
      if (f >= 1.15) m = E ? "Tiene " + fp + ": nació de un gas muy enriquecido por muchas generaciones anteriores de estrellas." : "It has " + fp + ": it was born from gas heavily enriched by many earlier generations of stars.";
      else if (f > 0.87) m = E ? "Tiene " + fp + ": nació de un gas tan enriquecido como el que formó el Sol." : "It has " + fp + ": it was born from gas as enriched as the gas that made the Sun.";
      else if (f >= 0.4) m = E ? "Tiene " + fp + ": nació de un gas ya enriquecido por generaciones anteriores de estrellas, aunque menos que el del Sol." : "It has " + fp + ": it was born from gas already enriched by earlier generations of stars, though less than the Sun’s.";
      else if (feh > -1.3) m = E ? "Tiene " + fp + ": nació cuando la Galaxia todavía tenía pocos metales." : "It has " + fp + ": it was born when the Galaxy still had few metals.";
      else m = E ? "Tiene " + fp + ": es de las primeras generaciones de estrellas de la Galaxia." : "It has " + fp + ": it belongs to the first generations of stars in the Galaxy.";
      m += E ? " (Los astrónomos llaman «metales» a todo lo que no es hidrógeno ni helio: lo fabrican las estrellas y lo esparcen al morir, así que cada generación nace con más.)" :
               " (Astronomers call “metals” everything that is not hydrogen or helium: stars make them and spread them when they die, so each generation is born with more.)";
      add(m);
   } else {
      add(E ? "No hay un espectro de esta estrella en los catálogos: no se sabe de qué está hecha." : "No spectrum of this star is in the catalogues: we do not know what it is made of.");
   }
   // 3 · su α
   var cc = s.chemClass;
   if (cc && cc.pHigh !== null && cc.pHigh !== undefined) {
      if (cc.pHigh >= 0.84) add(E ? "Tiene mucho magnesio comparado con su hierro: nació deprisa, cuando solo habían explotado las supernovas de estrellas muy grandes (que dan magnesio) y aún no las de enanas blancas (SN Ia), que tardan más y aportan sobre todo hierro." :
                                         "It has a lot of magnesium compared with its iron: it was born quickly, when only the supernovae of very massive stars (which make magnesium) had exploded and not yet the white-dwarf ones (SN Ia), which take longer and add mostly iron.");
      else if (cc.pHigh <= 0.16) add(E ? "Su magnesio y su hierro están en la misma proporción que en el Sol: nació en un entorno que llevaba tiempo formando estrellas, cuando las supernovas de enanas blancas (SN Ia) ya habían añadido su hierro." :
                                              "Its magnesium and iron are in the same proportion as in the Sun: it was born where stars had been forming for a long time, after white-dwarf supernovae (SN Ia) had added their iron.");
      else add(E ? "Su proporción de magnesio y hierro está en la frontera entre las dos familias: con los errores, no permite decidir." : "Its magnesium-to-iron ratio sits on the border between the two families: within the errors, it does not decide.");
   }
   // 4 · su población, en una frase
   var pop = s.pop ? s.pop.label : "unknown", fam = s.fam || null;
   if (pop === "thin") add(E ? "El disco fino es el plano delgado de la Galaxia donde siguen naciendo estrellas hoy, como nació el Sol." : "The thin disc is the Galaxy’s thin plane where stars are still being born today, as the Sun was.");
   else if (pop === "thick") add(E ? "El disco grueso es una capa más hinchada y más vieja que el disco fino: se formó en los primeros miles de millones de años de la Galaxia." : "The thick disc is a puffier, older layer than the thin disc: it formed in the Galaxy’s first few billion years.");
   else if (pop === "halo") add(E ? "El halo es la nube redondeada de estrellas muy viejas que envuelve la Galaxia; sus estrellas no giran ordenadas como las del disco." : "The halo is the rounded cloud of very old stars wrapped around the Galaxy; its stars do not orbit in an orderly way like the disc’s.");
   else if (pop === "accreted") {
      var fn = (fam && CC_FAM_NAME[L][fam.best]) ? CC_FAM_NAME[L][fam.best] : (E ? "otra galaxia" : "another galaxy");
      // (C2, 23-oct) si su edad es más joven que el choque, la frase lo dice en el mismo sitio (la parada «acretada» del Gran recorrido
      // toma ESTA frase): o la edad o la familia fallan, y no se sabe cuál
      // (P5) la misma advertencia para toda familia con fecha de fusión publicada (CC_MERGERS: Gaia-Enceladus, Sequoia, corrientes de Helmi)
      var tn = s.pop.ageTension, tt = "", tfn = tn ? ((CC_FAM_NAME[L] && CC_FAM_NAME[L][tn.fam]) || tn.fam) : "";
      if (tn) tt = E ? " Ojo: su edad (unos " + ccGaPlain(tn.v, "es") + " de años) no encaja: las estrellas de " + tfn + " nacieron antes de que su galaxia cayera en la Vía Láctea, hace más de " + ccGaPlain(tn.floor, "es") + " de años. O la edad está mal (las edades por modelos de una sola estrella fallan a menudo, sobre todo en gigantes) o la estrella no es de " + tfn + "." :
                       " Note: its age (about " + ccGaPlain(tn.v, "en") + " years) does not fit: " + tfn + " stars were born before their galaxy fell into the Milky Way, more than " + ccGaPlain(tn.floor, "en") + " years ago. Either the age is wrong (model ages of single stars often fail, above all in giants) or the star is not from " + tfn + ".";
      // (30-oct, D1-H3, decisión C de Nino) la frase firme de nacimiento, solo con P ≥ 0,8 (ccFamFirm); por debajo, «compatible». Medido: 8 de 25 acretadas de G-E tenían P < 0,8 y se afirmaba su nacimiento.
      if (!ccFamFirm(fam)) add((E ? "Es compatible con una estrella acretada: su órbita encaja con " + fn + ((fam && fam.best === "gse") ? ", una galaxia pequeña que chocó con la Vía Láctea hace unos 10 000 millones de años y quedó deshecha dentro de ella" : ", restos de una galaxia pequeña que la Vía Láctea absorbió") + ", pero no basta para afirmar que naciera allí." :
                                    "It is compatible with an accreted star: its orbit fits " + fn + ((fam && fam.best === "gse") ? ", a small galaxy that collided with the Milky Way about 10 billion years ago and was torn apart inside it" : ", the remains of a small galaxy swallowed by the Milky Way") + ", but that is not enough to say it was born there.") + tt);
      // (3-nov, S5 a de Nino) «casi seguro … probablemente nació»: la frase de la órbita dice luego «probable, no confirmada» y no deben chocar.
      // Costura «sci-s5firm»: la frase rotunda de antes.
      else if (fam && fam.best === "gse") add((ccSciBroken("sci-s5firm") ? (E ? "Es una estrella acretada: nació en Gaia-Enceladus, una galaxia pequeña que chocó con la Vía Láctea hace unos 10 000 millones de años y quedó deshecha dentro de ella." :
                                                  "It is an accreted star: it was born in Gaia-Enceladus, a small galaxy that collided with the Milky Way about 10 billion years ago and was torn apart inside it.") :
                                                 (E ? "Es casi seguro una estrella acretada: probablemente nació en Gaia-Enceladus, una galaxia pequeña que chocó con la Vía Láctea hace unos 10 000 millones de años y quedó deshecha dentro de ella." :
                                                  "It is almost certainly an accreted star: it was probably born in Gaia-Enceladus, a small galaxy that collided with the Milky Way about 10 billion years ago and was torn apart inside it.")) + tt);
      else add((E ? "Es probablemente una estrella acretada: su órbita la asocia a " + fn + ", restos de una galaxia pequeña que la Vía Láctea absorbió." : "It is probably an accreted star: its orbit links it to " + fn + ", the remains of a small galaxy swallowed by the Milky Way.") + tt);
   } else if (pop === "disc" && s.pop.basis === "kin") add(E ? "Por su movimiento es una estrella del disco de la Galaxia, pero ese movimiento no basta para decir si del fino o del grueso (y no tiene química medida)." : "By its motion it is a disc star, but that motion is not enough to tell thin from thick (and it has no measured chemistry).");
   else if (pop === "disc") add(E ? "Está en el disco de la Galaxia, pero sin su α no se puede decir si en el fino o en el grueso." : "It is in the Galaxy’s disc, but without its α we cannot tell thin from thick.");
   // 5 · su órbita (familia cinemática), con la advertencia del solape
   grp = 2;
   if (fam && fam.orbit && fam.orbit.bound) {
      // (P1, 23-oct) la forma con los cortes de la literatura (ccEccPlain) y la del Sol al lado, en el mismo potencial
      var e = fam.orbit.ecc, ef = ccEccPlain(e, L), se = (typeof ccSciBroken === "function" && ccSciBroken("sci-oldecc")) ? null : ccSunEcc();
      // (27-oct, E6) si ccOrbit no conservó la energía ni partiendo el paso (`approx`), peri, apo y e llevan «≈» y el relato lo dice
      // (la ficha ya los marca, ccOrbitLine de ui/cc_paint.js). Costura «sci-noorbitapprox»: el relato de antes, sin marca.
      var ap = (fam.orbit.approx && !(typeof ccSciBroken === "function" && ccSciBroken("sci-noorbitapprox"))) ? "≈ " : "";
      var et = (E ? "excentricidad " : "eccentricity ") + ap + ccDec(e, 2, L) + (ccIsNum(se) ? (E ? "; la del Sol, " : "; the Sun’s, ") + ccDec(se, 2, L) : "");
      var o = E ? "Su órbita alrededor del centro de la Galaxia es " + ef + " (" + et + "): se acerca a " + ap + ccDec(fam.orbit.rperi, 1, "es") + " kpc del centro y se aleja hasta " + ap + ccDec(fam.orbit.rapo, 1, "es") + " kpc, y " + ccLzPlain(fam.nominal, "es") + "." + (ap ? " Estas cifras son aproximadas: la órbita pasa tan cerca del centro que el cálculo no conserva bien la energía." : "") :
                  "Its orbit around the Galactic centre is " + ef + " (" + et + "): it comes within " + ap + ccDec(fam.orbit.rperi, 1, "en") + " kpc of the centre and reaches out to " + ap + ccDec(fam.orbit.rapo, 1, "en") + " kpc, and " + ccLzPlain(fam.nominal, "en") + "." + (ap ? " These figures are approximate: the orbit passes so close to the centre that the calculation does not conserve energy well." : "");
      if (fam.accreted && fam.p >= 0.3) {
         // (30-oct, decisión C) con P < 0,8 ni «pertenencia probable»: «compatible». Con P ≥ 0,8, la frase de siempre. La P es la estabilidad de la familia ante los errores, no la del origen.
         if (ccFamFirm(fam)) o += E ? " Ese tipo de órbita es el de " + CC_FAM_NAME.es[fam.best] + " (probabilidad " + ccDec(fam.p, 2, "es") + "), pero en el diagrama energía–momento angular las familias se solapan: es una pertenencia probable, no confirmada." :
                                      " That kind of orbit is typical of " + CC_FAM_NAME.en[fam.best] + " (probability " + ccDec(fam.p, 2, "en") + "), but in the energy–angular momentum plane the families overlap: membership is probable, not confirmed.";
         else o += E ? " Ese tipo de órbita es compatible con " + CC_FAM_NAME.es[fam.best] + " (probabilidad " + ccDec(fam.p, 2, "es") + "), pero en el diagrama energía–momento angular las familias se solapan: compatible no quiere decir confirmada." :
                       " That kind of orbit is compatible with " + CC_FAM_NAME.en[fam.best] + " (probability " + ccDec(fam.p, 2, "en") + "), but in the energy–angular momentum plane the families overlap: compatible does not mean confirmed.";
      }
      // (30-oct, N1, decisión B) astrometría dudosa: la órbita se enseña, sin familia, y se dice por qué
      if (s.astroDoubt && !fam.best) o += ccAstroDoubtStory(s.astroDoubt, L);
      if (s.pop && s.pop.famTension) o += E ? " Ojo: su química (mucho α) es más propia de una estrella nacida aquí; por eso no la llamamos acretada." : " Note: its chemistry (high α) looks more like a star born here; that is why we do not call it accreted.";
      // (C3, 23-oct) dos catálogos dan velocidades radiales que no casan y con cada una la altura máxima sale muy distinta
      var oa = fam.orbitAlt, kv = function(v) { return ccDec(v, 1, L).replace("-", "−"); };
      // (P7) «≈» en las dos cifras: ninguna es robusta
      if (fam.zmaxUnstable && oa && s.rv) o += E ? " Su altura máxima sobre el disco no está bien medida: con la velocidad radial de " + s.rv.src + " (" + kv(s.rv.v) + " km/s) llega a " + ccZmaxText(fam.orbit, "es") + " kpc, y con la de " + oa.src + " (" + kv(oa.rv) + " km/s), a " + ccZmaxText({ zmax: oa.zmax, zmaxApprox: fam.orbit.zmaxApprox }, "es") + " kpc; los dos catálogos no coinciden." :
                                                   " Its greatest height above the disc is not well measured: with the radial velocity from " + s.rv.src + " (" + kv(s.rv.v) + " km/s) it reaches " + ccZmaxText(fam.orbit, "en") + " kpc, and with the one from " + oa.src + " (" + kv(oa.rv) + " km/s), " + ccZmaxText({ zmax: oa.zmax, zmaxApprox: fam.orbit.zmaxApprox }, "en") + " kpc; the two catalogues disagree.";
      add(o);
   } else if (fam && (fam.best === "unbound" || (fam.orbit && fam.orbit.bound === false))) {
      // (30-oct, N2) con estos datos escaparía de la Galaxia: lo más probable es que un dato esté mal, no que la estrella escape. Hasta hoy caía en «falta su velocidad o su distancia».
      var ubV = Math.round(fam.nominal.v), ubRv = (s.rv && ccIsNum(s.rv.v)) ? ccDec(s.rv.v, 0, L).replace("-", "−") : "—", ubSrc = s.rv ? String(s.rv.src || "") : "";
      add((E ? "Con estos datos no está ligada a la Galaxia: a " + ubV + " km/s escaparía de ella. Es mucho más probable un dato malo (su velocidad radial, " + ubRv + " km/s de " + ubSrc + ", o su distancia) que una estrella escapándose de verdad, así que no le damos órbita ni familia." :
                   "With these data it is not bound to the Galaxy: at " + ubV + " km/s it would escape. It is far more likely that a value is wrong (its radial velocity, " + ubRv + " km/s from " + ubSrc + ", or its distance) than that it is really escaping, so we give it no orbit and no family.") + (s.astroDoubt ? ccAstroDoubtStory(s.astroDoubt, L, true) : ""));
   } else if (s.xmatch && !s.xmatch.ok) {
      // (C1, 23-oct) el número de Gaia que da el catálogo es de OTRA estrella: ni su distancia ni su movimiento son los de esta
      var xs = s.xmatch.sep[s.xmatch.bad[0]], xl = (typeof CC_SURVEY_LABEL !== "undefined" && CC_SURVEY_LABEL[s.xmatch.bad[0]]) || s.xmatch.bad[0];
      add(E ? "El número de Gaia que da " + xl + " para esta estrella es el de otra, a " + ccDec(xs, 1, "es") + "″: su distancia y su movimiento no son los de esta, así que no calculamos su órbita." :
              "The Gaia number that " + xl + " gives for this star belongs to another one, " + ccDec(xs, 1, "en") + "″ away: its distance and motion are not this star's, so we do not compute its orbit.");
   } else {
      add(E ? "Falta su velocidad o su distancia para saber cómo se mueve por la Galaxia." : "Its velocity or distance is missing, so we cannot tell how it moves through the Galaxy.");
   }
   // 6 · qué tipo de estrella es y dónde está
   grp = 3;
   var kind = ccStarKind(ch.logg, ch.teff, L);
   if (kind) add(kind);
   if (s.dist && ccIsNum(s.dist.pc)) {
      var ly = s.dist.pc * CC_PC_TO_LY;
      add(E ? "Está a unos " + ccNice(ly, "es", 2) + " años luz: la luz que ha llegado a tu foto salió de ella hace unos " + ccNice(ly, "es", 2) + " años." :
                   "It is about " + ccNice(ly, "en", 2) + " light years away: the light that reached your photo left it about " + ccNice(ly, "en", 2) + " years ago.");
   }
   return out;
}

// (30-oct, N1, decisión B) la frase de la astrometría dudosa, la misma en el relato de la ficha y en el de StarFieldAnalysis (grupo 2). `also`: tras la de no ligada.
function ccAstroDoubtWhy(d, L) {
   var E = (L === "es"), bits = [];
   if (d.ruwe) bits.push("RUWE " + ccDec(d.ruweV, 2, L));
   if (d.dist) bits.push((E ? "distancia ± " : "distance ± ") + Math.round(100 * d.frac) + " %");
   return bits.join(" · ");
}
function ccAstroDoubtStory(d, L, also) {
   var E = (L === "es"), w = ccAstroDoubtWhy(d, L);
   if (also) return E ? " Además, su astrometría es dudosa (" + w + ")." : " Its astrometry is also doubtful (" + w + ").";
   return E ? " Ojo: su astrometría es dudosa (" + w + "): esta órbita es orientativa y no le asignamos familia." : " Note: its astrometry is doubtful (" + w + "): this orbit is only indicative and we assign it no family.";
}
// LAS ETIQUETAS TÉCNICAS, explicadas en una frase llana (para los «?» de la ficha).
var CC_GLOSS = {
   feh: ["How much iron the star has compared with the Sun, on a logarithmic scale: 0 = like the Sun, −1 = ten times less, +0.3 = twice as much.",
         "Cuánto hierro tiene la estrella comparado con el Sol, en escala logarítmica: 0 = como el Sol, −1 = diez veces menos, +0,3 = el doble."],
   alpha: ["How many “alpha” elements (magnesium, silicon, calcium…) it has per iron atom, compared with the Sun. High = born quickly, before white-dwarf supernovae (SN Ia) added much iron.",
           "Cuántos elementos «alfa» (magnesio, silicio, calcio…) tiene por cada átomo de hierro, comparado con el Sol. Alto = nació deprisa, antes de que las supernovas de enanas blancas (SN Ia) añadieran mucho hierro."],
   age: ["Calibrated: a method calibrated with asteroseismology, or a subgiant: the most reliable. Isochrone: stellar-evolution models on an evolved star. Indicative: models on a dwarf, or Kordopatis et al. 2023 on a giant (too old in M 67) (drawn faint in the diagrams).",
         "Calibrada: método calibrado con sismología, o una subgigante: lo más fiable. Isócrona: modelos de evolución en una estrella evolucionada. Orientativa: modelos en una enana, o Kordopatis et al. 2023 en una gigante (sale demasiado vieja en M 67) (va tenue en los diagramas)."],
   population: ["The part of the Galaxy it belongs to: thin disc (young, where stars are born today), thick disc (older, puffier), halo (very old cloud around the Galaxy) or accreted (its orbit is that of the remains of another galaxy; it points to its origin, it does not prove it).",
                "La parte de la Galaxia a la que pertenece: disco fino (joven, donde nacen hoy estrellas), disco grueso (más viejo e hinchado), halo (nube muy vieja alrededor) o acretada (su órbita es la de los restos de otra galaxia: apunta a su origen, no lo demuestra)."],
   chemistry: ["P(high α): probability that its α puts it on the high-α sequence (thick disc / halo) rather than the thin-disc one, taking the errors into account.",
               "P(α alto): probabilidad de que su α la ponga en la secuencia de α alto (disco grueso / halo) y no en la del disco fino, teniendo en cuenta los errores."],
   kinematics: ["How it moves: thin-disc orbits are almost circular; thick-disc ones are slower and tilted; halo orbits can have any shape. Bars: probability of each (probable from 80 %, possible from 50 %, undetermined below). The model: kinematics: Schönrich 2010 · Bensby 2014, with the density of each population at the star’s place (Jurić 2008).",
                "Cómo se mueve: las órbitas del disco fino son casi circulares; las del grueso, más lentas e inclinadas; las del halo, de cualquier forma. Barras: probabilidad de cada una (probable desde el 80 %, posible desde el 50 %, indeterminada por debajo). El modelo: cinemática: Schönrich 2010 · Bensby 2014, con la densidad de cada población en el sitio de la estrella (Jurić 2008)."],
   family: ["Group of stars with similar orbits in energy and angular momentum (E–Lz); many are remains of galaxies the Milky Way swallowed. Lz: angular momentum about the Galaxy’s axis = distance to the axis × rotation speed (the Sun: 8.1 kpc × 246 km/s ≈ 2,000 kpc km/s; negative = against the rotation). It is not a speed: far from the centre a star has more Lz even if it turns more slowly.",
            "Grupo de estrellas con órbitas parecidas en energía y momento angular (E–Lz); muchas son restos de galaxias que la Vía Láctea absorbió. Lz: momento angular alrededor del eje de la Galaxia = distancia al eje × velocidad de giro (el Sol: 8,1 kpc × 246 km/s ≈ 2 000 kpc km/s; negativo = al revés). No es una velocidad: lejos del centro una estrella tiene más Lz aunque gire más despacio."],
   distance: ["Distance from Gaia’s parallax (Bailer-Jones et al. 2021): the range is the 16–84 % interval. 1 parsec = 3.26 light years.",
              "Distancia de la paralaje de Gaia (Bailer-Jones et al. 2021): el intervalo es el del 16–84 %. 1 pársec = 3,26 años luz."],
   rv: ["Speed towards (−) or away from (+) us, from the Doppler shift of its spectrum.", "Velocidad hacia nosotros (−) o alejándose (+), por el desplazamiento Doppler de su espectro."],
   fingerprint: ["How much of each element it has relative to iron, compared with the Sun (0 = like the Sun). α: massive-star supernovae · Fe-peak: white-dwarf supernovae (SN Ia) · s-process: slow neutron capture in old giant stars · r-process: rapid neutron capture in neutron-star mergers.",
                 "Cuánto tiene de cada elemento respecto al hierro, comparado con el Sol (0 = como el Sol). α: supernovas de estrellas grandes · pico del Fe: supernovas de enanas blancas (SN Ia) · proceso s: captura lenta de neutrones en gigantes viejas · proceso r: captura rápida en choques de estrellas de neutrones."],
   tags: ["r-I/r-II: rich in r-process elements (Eu) · s: rich in s-process (Ba) · CEMP: carbon-rich and metal-poor · solar twin: like the Sun in temperature, gravity and iron.",
          "r-I/r-II: rica en elementos del proceso r (Eu) · s: rica en proceso s (Ba) · CEMP: rica en carbono y pobre en metales · gemela solar: como el Sol en temperatura, gravedad y hierro."]
};
function ccGloss(key, lang) { var g = CC_GLOSS[key]; return g ? g[ccL(lang) === "es" ? 1 : 0] : ""; }
// EL CAMPO EN LLANO: tres o cuatro frases sobre todas las estrellas con datos del encuadre (bajo la ficha
// plegada). Sin estrellas, nada. Solo edades fiables (calibradas o de isócrona en evolucionadas, sin tocar el límite).
function ccFieldStory(res, lang, photo) {
   var E = ccL(lang) === "es", out = [], i;
   if (!res || !res.stars) return out;
   var n = 0, pops = { thin: 0, thick: 0, halo: 0, accreted: 0, disc: 0 }, oldest = null, youngest = null, poorest = null, fams = {}, famOrder = [], feh = [];
   var C = res.coverage || null;
   for (i = 0; i < res.stars.length; ++i) {
      var s = res.stars[i];
      if (!s.inFrame) continue;
      var p = s.pop ? s.pop.label : "unknown";
      if (!C) { if (!(s.chem.feh || s.age.adopted)) continue; ++n; if (pops.hasOwnProperty(p)) ++pops[p]; }
      if (s.chem.feh) feh.push(s);
      var a = s.age.adopted;
      if (a && (a.tier === "A" || a.tier === "B") && !a.edge) { if (!oldest || a.v > oldest.age.adopted.v) oldest = s; if (!youngest || a.v < youngest.age.adopted.v) youngest = s; }
      // la más pobre, solo entre las bien medidas (±0,15 dex o mejor): el mínimo es justo donde caen los valores raros
      if (s.chem.feh && ccIsNum(s.chem.feh.e) && s.chem.feh.e <= 0.15 && (!poorest || s.chem.feh.v < poorest.chem.feh.v)) poorest = s;
      // las acretadas, por su galaxia: SOLO las que la población da por acretadas (así suman lo mismo que «N acretadas»)
      if (p === "accreted" && s.fam && typeof CC_FAM_NAME !== "undefined") { var fn = CC_FAM_NAME[E ? "es" : "en"][s.fam.best]; if (!fams[fn]) famOrder.push(fn); fams[fn] = (fams[fn] || 0) + 1; }
   }
   // los recuentos, los MISMOS que la sección de cobertura («Población, todas las estrellas con datos»)
   if (C) { n = C.inFrame || 0; for (var kp in pops) if (pops.hasOwnProperty(kp)) pops[kp] = (C.byPop && C.byPop[kp]) || 0; }
   if (n === 0) return out;
   var parts = [], pcs = {}, big = null, tot = 0;
   for (var kq in pops) if (pops.hasOwnProperty(kq) && pops[kq]) { pcs[kq] = Math.round(100 * pops[kq] / n); if (pcs[kq] >= 5) { tot += pcs[kq]; if (!big || pcs[kq] > pcs[big]) big = kq; } }
   if (tot > 100 && big) pcs[big] -= tot - 100;      // el redondeo no suma más de 100 %
   function part(k, es1, esN, en1, enN) {
      var c = pops[k]; if (!c) return;
      var pc = pcs[k];
      if (pc >= 5) parts.push(E ? "un " + pc + " % " + esN : pc + "% " + enN);
      else parts.push(c + " " + (E ? (c === 1 ? es1 : esN) : (c === 1 ? en1 : enN)));
   }
   part("thin", "del disco fino", "del disco fino", "in the thin disc", "in the thin disc");
   part("thick", "del disco grueso", "del disco grueso", "in the thick disc", "in the thick disc");
   part("halo", "del halo", "del halo", "in the halo", "in the halo");
   // (27-oct, R3) «disco» sin separar fino y grueso (solo cinemática en «mezcla», o química sin α): también cuenta en la frase
   part("disc", "del disco (sin separar fino y grueso)", "del disco (sin separar fino y grueso)", "in the disc (thin / thick not separated)", "in the disc (thin / thick not separated)");
   part("accreted", "acretada (órbita de restos de otra galaxia)", "acretadas (órbitas de restos de otras galaxias)", "accreted (orbit of the remains of another galaxy)", "accreted (orbits of the remains of other galaxies)");
   var t = (photo ? (E ? "En tu foto hay " : "Your photo has ") : (E ? "En este campo hay " : "This field has ")) + ccThou(n, lang) + (E ? " estrellas con datos en algún catálogo" : " stars with data in some catalogue");
   if (parts.length) t += ": " + (parts.length > 1 ? parts.slice(0, -1).join(", ") + (E ? " y " : " and ") + parts[parts.length - 1] : parts[0]);
   out.push(t + ".");
   if (oldest) out.push(E ? "La más vieja con una edad fiable tiene unos " + ccGaPlain(oldest.age.adopted.v, "es") + " de años" + (youngest !== oldest ? "; la más joven, unos " + ccGaPlain(youngest.age.adopted.v, "es") : "") + "." :
                            "The oldest with a reliable age is about " + ccGaPlain(oldest.age.adopted.v, "en") + " years old" + (youngest !== oldest ? "; the youngest, about " + ccGaPlain(youngest.age.adopted.v, "en") : "") + ".");
   else out.push(E ? "Ninguna tiene una edad fiable: las que hay son solo orientativas." : "None has a reliable age: the ones available are only indicative.");
   if (poorest) {
      var nLow = 0; for (i = 0; i < feh.length; ++i) if (feh[i].chem.feh.v < poorest.chem.feh.v) ++nLow;
      out.push(E ? "La más pobre en metales bien medida tiene " + ccFehPlain(poorest.chem.feh.v, "es") + (nLow ? " (hay " + nLow + " con valores aún más bajos, pero medidos con menos seguridad)" : "") + "." :
                   "The most metal-poor well-measured one has " + ccFehPlain(poorest.chem.feh.v, "en") + (nLow ? " (" + nLow + " more show even lower values, but measured less securely)" : "") + ".");
   }
   if (famOrder.length) { var fl = []; for (i = 0; i < famOrder.length; ++i) fl.push(famOrder[i] + " " + fams[famOrder[i]]); out.push((E ? "Probables restos de otras galaxias, por su órbita: " : "Probable remains of other galaxies, by their orbit: ") + fl.join(", ") + "."); }
   // (22-oct, fase 1: el grupo III «Familias químicas» se va; el recuento del campo, aquí, y la de cada estrella, en su ficha)
   var tf = ccFieldFamilies(res, lang);
   if (tf) out.push(tf);
   return out;
}
// (P3, 23-oct) EL TÍTULO DE LAS CIFRAS del análisis. El «177 en algún catálogo» cuenta estrellas de CUALQUIER brillo (en la foto de
// Abell 39: 95 con G<17, el resto más débiles o sin G de Gaia), así que no son «177 de las 421»: se dice. Lo pinta la cabecera
// (src/ui/cc_dialog.js, D.countsText). nIn: el recuento a usar en lugar de coverage.inFrame (la costura «listcount» de la interfaz).
// «421 Gaia G<17 · 177 en algún catálogo (de cualquier brillo; 95 con G<17): 152 con [Fe/H], 61 con edad, 128 con cinemática»
// (23-oct, noche, revisión visual 4: la frase entera no cabe en la cabecera de la ventana —salía «…128 con cine…»—) form "short": la
// MISMA cuenta en forma corta, para la ventana (la entera, en su tooltip y en la exportada, partida en líneas):
// «421 Gaia G<17 · 177 en catálogos (95 con G<17) · 152 [Fe/H] · 61 edad · 128 cinemática»
function ccCountsText(res, lang, nIn, form) {
   var E = ccL(lang) === "es", c = (res && res.coverage) || {}, n = ccIsNum(nIn) ? nIn : (c.inFrame || 0);
   if (form === "short")
      return ccThou(c.gaiaG17 || 0, lang) + " Gaia G<17 · " + ccThou(n, lang) + (E ? " en catálogos (" : " in catalogues (") + ccThou(c.brightG17 || 0, lang) + (E ? " con G<17) · " : " with G<17) · ") +
             ccThou(c.chem || 0, lang) + " [Fe/H] · " + ccThou(c.age || 0, lang) + (E ? " edad · " : " age · ") + ccThou(c.kin || 0, lang) + (E ? " cinemática" : " kinematics");
   return ccThou(c.gaiaG17 || 0, lang) + " Gaia G<17 · " + ccThou(n, lang) + (E ? " en algún catálogo (de cualquier brillo; " : " in some catalogue (any brightness; ") +
          ccThou(c.brightG17 || 0, lang) + (E ? " con G<17): " : " with G<17): ") +
          ccThou(c.chem || 0, lang) + (E ? " con [Fe/H], " : " with [Fe/H], ") + ccThou(c.age || 0, lang) + (E ? " con edad, " : " with age, ") +
          ccThou(c.kin || 0, lang) + (E ? " con cinemática" : " with kinematics");
}
// Las familias químicas del campo, en una frase («3 en GALAH DR4 (de 5, 3 y 2 estrellas), ninguna en APOGEE DR17») o "" si
// ningún survey tiene dos candidatas. La usan «El campo, en llano» y el «?» de la familia de la ficha.
function ccFieldFamilies(res, lang, bare) {
   var E = ccL(lang) === "es", parts = [], any = false;
   var lab = function(k) { return (typeof CC_SURVEY_LABEL !== "undefined" && CC_SURVEY_LABEL[k]) ? CC_SURVEY_LABEL[k] : k; };
   var T = (res && res.tagging) || [];
   for (var t = 0; t < T.length; ++t) {
      if (T[t].candidates < 2) continue;
      any = true;
      var G = T[t].groups, n = G.length;
      if (!n) { parts.push((E ? "ninguna en " : "none in ") + lab(T[t].survey)); continue; }
      var sz = []; for (var g = 0; g < G.length && g < 6; ++g) sz.push(ccThou(G[g].members.length, lang));
      // (23-oct, noche: con más de 6 familias decía «…de 380, 3, 3, 2, 2 y 2 estrellas…)», que se leía como un texto cortado; ahora lo dice)
      var more = n - sz.length, szT = (sz.length > 1 && !more) ? sz.slice(0, -1).join(", ") + (E ? " y " : " and ") + sz[sz.length - 1] : sz.join(", ");
      var moreT = more > 0 ? (E ? ", y " + ccThou(more, lang) + (more === 1 ? " familia más" : " familias más") : ", and " + ccThou(more, lang) + (more === 1 ? " more family" : " more families")) : "";
      parts.push(ccThou(n, lang) + (E ? " en " : " in ") + lab(T[t].survey) + (E ? " (de " + szT + " estrellas" : " (of " + szT + " stars") + moreT + ")");
   }
   if (!any) return "";
   var body = parts.join(E ? "; " : "; ");
   if (bare) return body;
   return (E ? "Familias químicas (la misma receta: quizá nacieron juntas): " : "Chemical families (the same recipe: perhaps born together): ") + body +
          (E ? "; la ficha de cada estrella dice la suya." : "; each star's card tells its own.");
}

// ---------------------------------------------------------------------------
// LOS ELEMENTOS (IV · Elementos, 22-oct): el nombre llano y el CANAL que lo fabrica, con su fuente. NO hay cifras inventadas:
// solo frases de qué fábrica de estrellas da cada elemento, de estas revisiones (todas citadas en la frase):
//   Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179 (el origen de los elementos del C al U) · Tinsley 1979, ApJ 229, 1046 (α / SN Ia)
//   Weinberg et al. 2019, ApJ 874, 102 ([Mg/Fe], los dos discos) · Das, Hawkins & Jofré 2020, MNRAS 493, 5195 (Al y Mn en acretadas)
//   Busso, Gallino & Wasserburg 1999, ARA&A 37, 239 (proceso s en gigantes AGB) · McClure, Fletcher & Nemec 1980, ApJ 238, L35 (estrellas de bario)
//   Cowan et al. 2021, Rev. Mod. Phys. 93, 015002 (proceso r) · Beers & Christlieb 2005, ARA&A 43, 531 (r-I / r-II) · Iben 1967, ARA&A 5, 571 (la mezcla en gigantes)
// El litio NO está: no se pide a GALAH (CC_GALAH_EL no lo trae), así que nunca sale en `s.chem.el`.
// ---------------------------------------------------------------------------
var CC_EL_NAME = {
   Fe: ["iron", "hierro"], C: ["carbon", "carbono"], N: ["nitrogen", "nitrógeno"], O: ["oxygen", "oxígeno"], Na: ["sodium", "sodio"],
   Mg: ["magnesium", "magnesio"], Al: ["aluminium", "aluminio"], Si: ["silicon", "silicio"], S: ["sulphur", "azufre"], K: ["potassium", "potasio"],
   Ca: ["calcium", "calcio"], Sc: ["scandium", "escandio"], Ti: ["titanium", "titanio"], V: ["vanadium", "vanadio"], Cr: ["chromium", "cromo"],
   Mn: ["manganese", "manganeso"], Co: ["cobalt", "cobalto"], Ni: ["nickel", "níquel"], Cu: ["copper", "cobre"], Zn: ["zinc", "cinc"],
   Rb: ["rubidium", "rubidio"], Sr: ["strontium", "estroncio"], Y: ["yttrium", "itrio"], Zr: ["zirconium", "circonio"], Mo: ["molybdenum", "molibdeno"],
   Ru: ["ruthenium", "rutenio"], Ba: ["barium", "bario"], La: ["lanthanum", "lantano"], Ce: ["cerium", "cerio"], Nd: ["neodymium", "neodimio"],
   Sm: ["samarium", "samario"], Eu: ["europium", "europio"]
};
function ccElName(X, lang) { var n = CC_EL_NAME[X]; return n ? n[ccL(lang) === "es" ? 1 : 0] : X; }
// La notación del eje: [Fe/H] para el hierro, [X/Fe] para el resto.
function ccElLabel(X) { return X === "Fe" ? "[Fe/H]" : "[" + X + "/Fe]"; }
// Cada canal: [corto EN, corto ES, largo EN, largo ES]; `%N` = el nombre del elemento con mayúscula.
var CC_EL_CHANNEL = {
   Fe: ["SN II and SN Ia · the yardstick", "SN II y SN Ia · la vara de medir",
        "Iron: made by type II supernovae (massive stars) and by exploding white dwarfs (SN Ia), which start exploding later. It is the yardstick: [Fe/H] says how much iron the star has compared with the Sun, and every other element is given per iron atom, [X/Fe] (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
        "Hierro: lo fabrican las supernovas de tipo II (estrellas masivas) y las de enanas blancas que estallan (SN Ia), que empiezan a estallar más tarde. Es la vara de medir: [Fe/H] dice cuánto hierro tiene la estrella comparado con el Sol, y cada uno de los demás elementos se da por átomo de hierro, [X/Fe] (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   alpha: ["α element · supernovae of massive stars (type II)", "elemento α · supernovas de estrellas masivas (tipo II)",
           "%N: an α element. Massive stars make most of it and release it when they explode as type II supernovae, soon after they are born; exploding white dwarfs (SN Ia) add iron later. So a high [X/Fe] says the star was born early, before much of that iron arrived (Tinsley 1979, ApJ 229, 1046; Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
           "%N: elemento α. Lo fabrican sobre todo las estrellas masivas y lo sueltan al estallar como supernovas de tipo II, poco después de nacer; las enanas blancas que estallan (SN Ia) añaden hierro más tarde. Por eso un [X/Fe] alto dice que la estrella nació pronto, antes de que llegara buena parte de ese hierro (Tinsley 1979, ApJ 229, 1046; Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   odd: ["odd Z · massive stars", "Z impar · estrellas masivas",
         "%N: made in massive stars, more of it the more metals the star that made it already had (the odd–even effect) (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
         "%N: lo fabrican las estrellas masivas, más cuantos más metales tenía ya la estrella que lo fabricó (el efecto par-impar) (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   oddWeak: ["odd Z · massive stars", "Z impar · estrellas masivas",
             "%N: made in massive stars; the models still do not reproduce how much there is (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
             "%N: lo fabrican las estrellas masivas; los modelos aún no reproducen cuánto hay (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   peak: ["iron peak · SN II and SN Ia", "pico del hierro · SN II y SN Ia",
          "%N: an iron-peak element, a mix of type II and white-dwarf (SN Ia) supernovae (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
          "%N: elemento del pico del hierro, mezcla de supernovas de tipo II y de enanas blancas (SN Ia) (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   s: ["s-process · AGB giants", "proceso s · gigantes AGB",
       "%N: from the s-process (slow neutron capture) in AGB giant stars, which release it in their winds at the end of their lives, so it enriches the Galaxy late (Busso, Gallino & Wasserburg 1999, ARA&A 37, 239; Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
       "%N: del proceso s (captura lenta de neutrones) en estrellas gigantes AGB, que lo sueltan con sus vientos al final de su vida, así que enriquece la Galaxia tarde (Busso, Gallino y Wasserburg 1999, ARA&A 37, 239; Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   sPeak1: ["s-process (first peak) · AGB giants", "proceso s (primer pico) · gigantes AGB",
            "%N: first peak of the s-process (slow neutron capture) in AGB giant stars, with contributions from other processes in massive stars (Busso, Gallino & Wasserburg 1999, ARA&A 37, 239; Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
            "%N: primer pico del proceso s (captura lenta de neutrones) en gigantes AGB, con aportes de otros procesos en estrellas masivas (Busso, Gallino y Wasserburg 1999, ARA&A 37, 239; Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   mixSR: ["s- and r-process mix", "mezcla de procesos s y r",
           "%N: a mix of the s-process (slow neutron capture in AGB giants) and the r-process (rapid neutron capture) (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
           "%N: mezcla del proceso s (captura lenta de neutrones en gigantes AGB) y del proceso r (captura rápida) (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   mixAll: ["several processes", "varios procesos",
            "%N: a mix of processes (s, r and others): there is no single origin (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
            "%N: mezcla de procesos (s, r y otros): no tiene un solo origen (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   r: ["r-process · neutron-star mergers", "proceso r · fusiones de estrellas de neutrones",
       "%N: mostly from the r-process (rapid neutron capture), in rare and violent events such as neutron-star mergers (Cowan et al. 2021, Rev. Mod. Phys. 93, 015002).",
       "%N: sobre todo del proceso r (captura rápida de neutrones), en sucesos raros y violentos como las fusiones de estrellas de neutrones (Cowan et al. 2021, Rev. Mod. Phys. 93, 015002)."],
   light: ["massive stars and AGB giants · changes in giants", "estrellas masivas y gigantes AGB · cambia en las gigantes",
           "%N: made in massive stars and in AGB giants (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179). In giant stars the internal mixing changes it, so it is not the birth value (Iben 1967, ARA&A 5, 571): that is why it does not enter the chemical families.",
           "%N: lo fabrican las estrellas masivas y las gigantes AGB (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179). En las gigantes la mezcla interna lo cambia, así que no es el de nacimiento (Iben 1967, ARA&A 5, 571): por eso no entra en las familias químicas."]
};
// Lo propio de algunos elementos, que se AÑADE a (o sustituye) la frase de su familia.
var CC_EL_EXTRA = {
   Mg: [" Magnesium comes almost only from type II supernovae: the two discs of the Milky Way are told apart with [Mg/Fe] (Weinberg et al. 2019, ApJ 874, 102).",
        " El magnesio viene casi solo de supernovas II: los dos discos de la Vía Láctea se separan con [Mg/Fe] (Weinberg et al. 2019, ApJ 874, 102)."],
   Ti: [" Titanium behaves like an α, although the models make less of it than is observed (Kobayashi, Karakas & Lugaro 2020).",
        " El titanio se comporta como un α, aunque los modelos fabrican menos del que se observa (Kobayashi, Karakas y Lugaro 2020)."],
   Al: [" Low aluminium is a sign of stars born in small galaxies that the Milky Way later swallowed (Das, Hawkins & Jofré 2020, MNRAS 493, 5195).",
        " El aluminio bajo es una seña de estrellas nacidas en galaxias pequeñas que luego se tragó la Vía Láctea (Das, Hawkins y Jofré 2020, MNRAS 493, 5195)."],
   Cr: [" It follows iron closely.", " Sigue de cerca al hierro."],
   Ni: [" It follows iron closely.", " Sigue de cerca al hierro."],
   V: [" The models make less vanadium than is observed.", " Los modelos fabrican menos vanadio del que se observa."],
   Ba: [" A very high [Ba/Fe] can be inherited from an AGB companion that passed it on: a barium star (McClure, Fletcher & Nemec 1980, ApJ 238, L35).",
        " Un [Ba/Fe] muy alto puede ser herencia de una compañera AGB que se lo pasó: una estrella de bario (McClure, Fletcher y Nemec 1980, ApJ 238, L35)."],
   Eu: [" Europium is almost a pure r-process element; a high [Eu/Fe] in a metal-poor star makes it r-I or r-II (Beers & Christlieb 2005, ARA&A 43, 531).",
        " El europio es casi solo de proceso r; un [Eu/Fe] alto en una estrella pobre en metales la hace r-I o r-II (Beers y Christlieb 2005, ARA&A 43, 531)."]
};
// Los elementos con canal propio (frase entera distinta de la de su familia en CC_ELEMENTS).
var CC_EL_OWN = {
   Mn: ["SN Ia · arrives late", "SN Ia · llega tarde",
        "Manganese: mostly from white-dwarf supernovae (SN Ia, white dwarfs close to their maximum mass), so it arrives late: old or accreted stars have little. Together with magnesium it helps to pick out accreted stars (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179; Das, Hawkins & Jofré 2020, MNRAS 493, 5195).",
        "Manganeso: sobre todo de supernovas de enanas blancas (SN Ia, cerca de su masa máxima), así que llega tarde: las estrellas viejas o acretadas tienen poco. Junto con el magnesio ayuda a señalar las acretadas (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179; Das, Hawkins y Jofré 2020, MNRAS 493, 5195)."],
   Zn: ["massive stars · supernovae and hypernovae", "estrellas masivas · supernovas e hipernovas",
        "Zinc: from massive stars, in type II supernovae and hypernovae (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
        "Cinc: de estrellas masivas, en supernovas de tipo II e hipernovas (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."],
   Cu: ["massive stars · weak s-process", "estrellas masivas · proceso s débil",
        "Copper: from massive stars, partly by slow neutron capture inside them (the weak s-process) (Kobayashi, Karakas & Lugaro 2020, ApJ 900, 179).",
        "Cobre: de estrellas masivas, en parte por captura lenta de neutrones dentro de ellas (el proceso s débil) (Kobayashi, Karakas y Lugaro 2020, ApJ 900, 179)."]
};
// Qué frase le toca a cada elemento (por su familia de CC_ELEMENTS y unos pocos casos propios).
var CC_EL_KIND = { K: "oddWeak", Sc: "oddWeak", Sr: "sPeak1", Y: "sPeak1", Zr: "sPeak1", Nd: "mixSR", Mo: "mixAll", Ru: "mixAll" };
// -> { short, long } en el idioma pedido ("" si el elemento no se conoce)
function ccElChannel(X, lang) {
   var es = ccL(lang) === "es", nm = ccElName(X, lang), Nm = nm.charAt(0).toUpperCase() + nm.substring(1), row = null, extra = CC_EL_EXTRA[X];
   if (CC_EL_OWN[X]) row = CC_EL_OWN[X];
   else if (X === "Fe") row = CC_EL_CHANNEL.Fe;
   else {
      var fam = CC_EL_KIND[X] || "";
      if (!fam && typeof CC_ELEMENTS !== "undefined") for (var i = 0; i < CC_ELEMENTS.length; ++i) if (CC_ELEMENTS[i][0] === X) fam = CC_ELEMENTS[i][1];
      row = CC_EL_CHANNEL[fam] || null;
   }
   if (!row) return { short: "", long: "" };
   return { short: row[es ? 1 : 0], long: row[es ? 3 : 2].replace("%N", Nm) + (extra ? extra[es ? 1 : 0] : "") };
}
// QUÉ PASÓ CON LAS CONSULTAS, en llano (res.status de ccFieldStatus). -> null si todo fue bien; si no,
// { title, body, retry, error }. Nunca un fallo de red se cuenta como «no hay estrellas».
function ccStatusText(res, lang) {
   var st = res && res.status, E = ccL(lang) === "es";
   if (!st || st.kind === "ok") return null;
   var GLo = res.gaiaLocal && !res.gaiaLocal.missing ? res.gaiaLocal : null;
   function why() {
      var host = st.host || "VizieR";
      // 16 (22-oct): `netWhy "bad"` = HTTP 200 que no es una tabla (CabraShared F2, csh_netfail cshNfJudge)
      if (st.why === "bad" && !(typeof ccBroken === "function" && ccBroken("nobad"))) return E ? host + " devolvió algo que no es una tabla (servidor sobrecargado o en mantenimiento)" : host + " returned something that is not a table (server overloaded or in maintenance)";
      if (st.why === "http" || st.code >= 500) return E ? host + " respondió HTTP " + st.code + " (servidor caído o en mantenimiento)" : host + " answered HTTP " + st.code + " (server down or in maintenance)";
      if (st.why === "timeout") return E ? host + " no contesta (se agotó el tiempo de espera)" : host + " does not answer (the wait timed out)";
      return E ? "no se pudo conectar con " + host + " (¿hay internet?)" : "could not connect to " + host + " (is there internet?)";
   }
   var loc = GLo ? (E ? " Con la base Gaia de este ordenador (" + GLo.name + ") se ven las " + ccThou(GLo.inFrame, "es") + " estrellas del encuadre, pero sin química, edades ni velocidad radial."
                      : " With this computer's Gaia database (" + GLo.name + ") the " + ccThou(GLo.inFrame, "en") + " stars in the frame are shown, but without chemistry, ages or radial velocity.") : "";
   if (st.kind === "net") return { error: true, retry: true,
      title: E ? "Sin conexión: no se ha podido preguntar a los catálogos" : "No connection: the catalogues could not be asked",
      body: why() + "." + (E ? " No es que no haya estrellas: falta la respuesta del servidor." : " It is not that there are no stars: the server's answer is missing.") + loc };
   if (st.kind === "partial") return { error: true, retry: true,
      title: E ? "Faltan datos: " + st.failed.length + " consulta(s) sin respuesta" : "Missing data: " + st.failed.length + " query(ies) unanswered",
      body: why() + "." + (E ? " Lo demás está; «Reintentar» vuelve a pedir lo que falta." : " The rest is here; “Retry” asks again for what is missing.") };
   if (st.kind === "nocover") return { error: false, retry: false,
      title: E ? "Ningún catálogo de espectros cubre este campo" : "No spectroscopic catalogue covers this field",
      body: E ? "Todos contestaron. Gaia ve " + ccThou(st.gaiaN, "es") + " estrellas aquí (G < 19), pero ni APOGEE, ni GALAH, ni LAMOST, ni los espectros de Gaia tienen ninguna: no hay química que enseñar."
              : "All answered. Gaia sees " + ccThou(st.gaiaN, "en") + " stars here (G < 19), but neither APOGEE, GALAH, LAMOST nor Gaia's spectra have any of them: there is no chemistry to show." };
   return { error: false, retry: false,
      title: E ? "No hay estrellas en este encuadre" : "There are no stars in this frame",
      body: E ? "Todos los catálogos contestaron y Gaia no tiene ninguna estrella aquí (G < 19): el campo está de verdad vacío."
              : "Every catalogue answered and Gaia has no star here (G < 19): the field really is empty." };
}
// Las regiones del diagrama de familias cinemáticas, con su nombre entero (en el diálogo estrecho se abrevian: THAM., WUK.).
var CC_FAM_GLOSS = {
   thamnos: ["Thamnos: remains of a small swallowed galaxy, on low-energy orbits that go against the Galaxy’s rotation (Koppelman+19).",
             "Thamnos: restos de una pequeña galaxia absorbida, en órbitas de poca energía que giran al revés que la Galaxia (Koppelman+19)."],
   retro: ["Sequoia, Arjuna and I’itoi: high-energy orbits against the Galaxy’s rotation, remains of swallowed galaxies; told apart by their iron (Naidu+20).",
           "Sequoia, Arjuna e I’itoi: órbitas de mucha energía que giran al revés que la Galaxia, restos de galaxias absorbidas; se distinguen por su hierro (Naidu+20)."],
   wukong: ["Wukong: a stream of metal-poor stars on orbits that rotate with the Galaxy (Naidu+20).",
            "Wukong: una corriente de estrellas pobres en metales en órbitas que giran con la Galaxia (Naidu+20)."],
   helmi: ["Helmi streams: remains of a swallowed galaxy; they rotate with the Galaxy on very tilted orbits (Helmi+99; box of Koppelman+19).",
           "Corrientes de Helmi: restos de una galaxia absorbida; giran con la Galaxia en órbitas muy inclinadas (Helmi+99; caja de Koppelman+19)."],
   gse: ["Gaia-Enceladus: the largest galaxy the Milky Way swallowed; its stars move on very elongated orbits (e > 0.7) and hardly rotate (Helmi+18; Belokurov+18). The shaded zone is approximate (orbit in the plane): a star can belong by its full orbit even if it falls outside it.",
         "Gaia-Enceladus: la mayor galaxia que absorbió la Vía Láctea; sus estrellas van en órbitas muy alargadas (e > 0,7) y casi no giran (Helmi+18; Belokurov+18). La zona sombreada es aproximada (órbita en el plano): una estrella puede ser de G-E por su órbita entera aunque caiga fuera."]
};
function ccFamGloss(key, lang) { var g = CC_FAM_GLOSS[key]; return g ? g[ccL(lang) === "es" ? 1 : 0] : ""; }
// Los términos de la sección de cobertura y de las familias químicas.
var CC_COV_GLOSS = {
   g17: ["Gaia stars brighter than magnitude 17 in the frame: the ones with a real chance of having a spectrum in the big catalogues.",
         "Estrellas de Gaia más brillantes que la magnitud 17 en el encuadre: las que tienen opción de tener espectro en los grandes catálogos."],
   chem: ["How many have their iron [Fe/H] measured from a spectrum (ground-based catalogues or Gaia’s own: GSP-Spec, XP).",
          "Cuántas tienen su hierro [Fe/H] medido con un espectro (catálogos desde tierra o los de Gaia: GSP-Spec, XP)."],
   age: ["How many have an estimated age (Xiang & Rix 22, Anders+23, Boin+26, Kordopatis+23, and FLAME: Gaia’s ages from brightness and temperature).",
         "Cuántas tienen edad estimada (Xiang & Rix 22, Anders+23, Boin+26, Kordopatis+23, y FLAME: edades de Gaia a partir de su brillo y temperatura)."],
   kin: ["How many have the three velocities (Gaia proper motion, radial velocity and distance): needed for the kinematic population and the kinematic-families diagram.",
         "Cuántas tienen las tres velocidades (movimiento propio de Gaia, velocidad radial y distancia): hacen falta para la población cinemática y el diagrama de familias cinemáticas."],
   cats: ["TAPVizieR: the service of the Strasbourg data centre (CDS) every catalogue is asked through. «x of y»: rows used of those received. GSP-Spec: metallicities from Gaia’s own spectra.",
          "TAPVizieR: el servicio del CDS de Estrasburgo por el que se piden todos los catálogos. «x de y»: filas usadas de las recibidas. GSP-Spec: metalicidades de los espectros del propio Gaia."],
   astro: ["Where each star's position, parallax and proper motion came from: this computer's Gaia database (works without internet; it has no radial velocity, no errors and no Gaia id, so it is matched by position) or the Gaia archive over the internet.",
           "De dónde salió la posición, el paralaje y el movimiento propio de cada estrella: la base Gaia de este ordenador (funciona sin internet; no trae velocidad radial, ni errores, ni el número de Gaia, así que se casa por posición) o el archivo de Gaia por internet."],
   base: ["Of all the pairs of stars in this field, the fraction that come out chemically compatible by chance. If it is high, looking alike proves little.",
          "De todas las parejas de estrellas del campo, qué fracción sale químicamente compatible por azar. Si es alta, parecerse prueba poco."]
};
function ccCovGloss(key, lang) { var g = CC_COV_GLOSS[key]; return g ? g[ccL(lang) === "es" ? 1 : 0] : ""; }
