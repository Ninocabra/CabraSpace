// ============================================================================
// src/cc_science.js — LA CIENCIA de CabraComposition (pura: sin PixInsight)
// ----------------------------------------------------------------------------
// Arqueología química: de los registros de cada survey a la «biografía
// galáctica» de cada estrella. Este fichero NO toca PixInsight, ni el disco, ni
// la red: lo ejecutan igual node (tests/cc_pure_cases.js) y PixInsight.
//
//   · CC_SCI           la tabla ÚNICA de constantes, cada una con su fuente.
//   · Cinemática       ICRS -> galácticas, UVW respecto al LSR, la población
//                      cinemática del modelo ÚNICO de CabraShared/csh_kinpop.js
//                      (29-oct: Schönrich 2010 + Bensby 2014 + Jurić 2008, el de
//                      CabraStars), coordenadas galactocéntricas y Lz.
//   · Química          adopción por prioridad de survey, par ([Fe/H], α), clase
//                      química con la frontera de Weinberg et al. 2019.
//   · Edades           adopción por método, con su incertidumbre, y la guarda
//                      de FLAME (modelos de metalicidad solar).
//   · Población        química (núcleo) + cinemática (apoyo) -> etiqueta y texto.
//   · Chemical tagging pares compatibles dentro de UN survey, χ² reducido.
//   · Huella           r / s / CEMP (Beers & Christlieb 2005; Aoki et al. 2007)
//                      y gemelas solares (Ramírez et al. 2009).
//   · Biografía        la frase y la línea de tiempo de la Vía Láctea.
//
// Procedencia: código NUEVO. La forma (tabla única de constantes con fuente,
// códigos estables en vez de frases) sigue la de CabraPilot
// `CabraCore/src/engine/starfield.js` (rama integracion-1410c).
// ES5 puro.
// ============================================================================

var CC_SCI = {
   // --- Coordenadas -------------------------------------------------------
   // Matriz ICRS -> galácticas (Gaia DR3 documentation, sec. 4.1.7, ec. 4.62;
   // es la de Hipparcos 1997 vol. 1 sec. 1.5.3). Filas: hacia el centro
   // galáctico, hacia la rotación, hacia el polo norte galáctico.
   AG: [[-0.0548755604162154, -0.8734370902348850, -0.4838350155487132],
        [ 0.4941094278755837, -0.4448296299600112,  0.7469822444972189],
        [-0.8676661490190047, -0.1980763734312015,  0.4559837761750669]],
   // km/s por (mas/año · kpc): 1 UA/año en km/s (IAU 2012).
   KV: 4.740470463533348,

   // --- Cinemática local: (29-oct-2026, decisión de Nino R4 H-2 de Codex) UN SOLO MODELO de población para CabraStars,
   // CabraComposition y CabraStarAnalysis, el de CabraStars, en CabraShared/csh_kinpop.js (CSH_KINPOP: el Sol de Schönrich
   // et al. 2010, las fracciones y elipsoides de Bensby et al. 2014, el prior espacial de Jurić et al. 2008 y el veredicto
   // «probable» P >= 0,8 / «posible» >= 0,5 / «indeterminada»). Hasta el 29-oct aquí iban SUN_LSR (Dehnen & Binney 1998:
   // 10,00; 5,25; 7,17), BENSBY (Bensby et al. 2003: 0,94 / 0,06 / 0,0015), KIN_CLASS_P (0,6, «mixed» por debajo) y KIN_DRAWS
   // (96 sorteos de Monte Carlo): ya no existen; el código de antes está en el commit 960958c.
   // Diseño: por encima de esta distancia las elipses LOCALES de Bensby ya no
   // describen bien las poblaciones (se calibraron en ~100 pc). Se avisa.
   KIN_LOCAL_PC: 1500,

   // --- Galactocéntricas (valores por defecto de astropy >= 4.0:
   // R0 = 8,122 kpc GRAVITY 2018; z⊙ = 20,8 pc Bennett & Bovy 2019;
   // v⊙ = (12,9; 245,6; 7,78) km/s Drimmel & Poggio 2018).
   R0_KPC: 8.122,
   ZSUN_KPC: 0.0208,
   VSUN_GC: [12.9, 245.6, 7.78],
   // Feuillet et al. 2021 (MNRAS 508, 1489): ventana de Lz de Gaia-Enceladus.
   GSE_LZ: 500,
   // Diseño: probabilidad mínima de la familia cinemática para llamarla acretada.
   FAM_P: 0.5,
   // (30-oct, decisión C de Nino) desde aquí se puede afirmar el origen («nació en…»); por debajo, «compatible con…» (ccFamFirm)
   FAM_FIRM_P: 0.8,

   // --- Química ----------------------------------------------------------------
   // Frontera alto-α / bajo-α en [Mg/Fe]-[Fe/H]: Weinberg et al. 2019 (ApJ 874,
   // 102) con APOGEE DR14: 0,12 − 0,13[Fe/H] si [Fe/H] < 0 y 0,12 si >= 0.
   // Con DR17 la misma recta sube 0,04 (Roberts et al. 2024, arXiv:2403.03249):
   // 0,16 − 0,13[Fe/H]. Se usa la de DR17.
   ALPHA_LINE_A: 0.16,
   ALPHA_LINE_B: -0.13,
   // Incertidumbre del CERO de la frontera entre surveys: la propia diferencia
   // DR14 -> DR17 (0,04). Entra en la anchura de la clasificación (diseño).
   ALPHA_ZP_SIGMA: 0.04,
   // [Fe/H] por debajo del cual la química ya no distingue disco grueso pobre en
   // metales de halo: valor de uso común (p. ej. Bensby et al. 2014). Diseño.
   HALO_FEH: -1.0,
   // Ventana química de Gaia-Enceladus: [Fe/H] en (−2,0; −0,7) y α bajo
   // (Helmi et al. 2018; Feuillet et al. 2021). Diseño a partir de esas figuras.
   GSE_FEH: [-2.0, -0.7],

   // --- Edades ---------------------------------------------------------------
   // FLAME (Gaia DR3) supone metalicidad SOLAR: no usarla fuera de
   // −0,5 < [M/H] < 0,5 (Creevey et al. 2023, A&A 674, A26; Fouesneau et al. 2023).
   FLAME_FEH: [-0.5, 0.5],
   // (28-oct, pendiente 8) FLAME en GIGANTES (primer dígito de Flags-Flame = 1; ccFlameFlag). Fuentes, leídas el 28-oct-2026:
   //   · ReadMe de VizieR I/355, nota 4 (copia del modelo de datos de la ESA, cuya página dio 503): «A=1 the star is a giant and the mass
   //     and age should be considered with an uncertainty on the order of 20%-30%».
   //   · Creevey et al. 2023 (A&A 674, A26; arXiv:2206.05864v1) §6.4.1: «results for giants with M > 2 M☉ are mis-classified and should not
   //     be used»; §8: con el primer dígito = 1, «the published results should only be used within the range 1–2 M☉».
   //   · Babusiaux et al. 2023 (validación, arXiv:2206.05989v1): igual, 1–2 M☉ «and with caution»; Gaia Collaboration, Creevey et al. 2023
   //     (muestra dorada, arXiv:2206.05870v1 §4.5): en gigantes conservan masa y edad solo con log g < 3,5, M < 2,0 y edad > 1,0 Ga.
   //     (Fouesneau et al. 2023, arXiv:2206.05992v1, pide 1,0 < M < 2,0 y edad > 1,5 Ga: el corte de 1,0 Ga es el de la muestra dorada.)
   FLAME_GIANT_MASS: [1.0, 2.0],      // M☉, ambos incluidos
   FLAME_GIANT_MIN_GA: 1.0,           // Ga (estricto: > 1,0)
   // Incertidumbre relativa MÍNIMA de una edad FLAME de gigante: el extremo alto del 20-30 % de la nota 4 (Creevey §8: las incertidumbres de
   // FLAME están infravaloradas). Medido (scratchpad flame/m1, m2): la semianchura publicada de esas gigantes es 0,12 de mediana (p90 0,19), y
   // en M 67 (~4 Ga) la banda publicada contiene 4 Ga en 5 de 12 gigantes; con el suelo de 0,30, en 8 de 12.
   FLAME_GIANT_EREL: 0.30,
   UNIVERSE_GA: 13.8,                 // Planck 2018: 13,787 ± 0,020 Ga
   // (27-oct, R1b) Techo de EDAD de la rejilla con que se entrenó cada red de Boin et al. 2026 (A&A 708, A215; arXiv:2603.09540v2,
   // apéndice C, tabla 1). La red (MLP con ReLU) no tiene techo: fuera de su rejilla EXTRAPOLA («unlikely (but possible, as the NN can
   // extrapolate)», §2.3). Una mediana por encima de su techo no es una edad de ese modelo. Medido en los 4 campos grabados: 402 rejillas
   // EN dominio pasan de su techo (hasta 44,9 Ga con Dartmouth, que acaba en 13,5): `inDomain` mira la ENTRADA (posición en el CMD), no la edad.
   BOIN_GRID_MAX_GA: { BaSTI: 14.0, MIST: 12.6, PARSEC: 13.9, Dartmouth: 13.5, Geneva: 12.6 },

   // --- Gaia GSP-Spec: calibración de Recio-Blanco et al. 2023 (A&A 674, A29) ---
   // [M/H]_cal = [M/H] + Σ p_i logg^i (ec. 2; ESA «dr3-gspspec-metallicity-logg-calibration»)
   GSP_MH_P: [0.274, -0.1373, -0.0050, 0.0048],
   // [α/Fe]_cal = [α/Fe] + Σ p_i logg^i (tabla 4, extrapol = 0), válido en logg 1,01-4,85
   // (fuera se lleva logg al borde, como sugiere la página de la ESA).
   GSP_AFE_P: [-0.5809, 0.7018, -0.2402, 0.0239, 0.0],
   GSP_AFE_LOGG: [1.01, 4.85],

   // --- Chemical tagging (diseño; Ness et al. 2018, ApJ 853, 198 para el método) ---
   TAG_FLOOR: 0.03,      // dex: suelo de error por elemento (los errores formales se quedan cortos)
   TAG_MIN_ELEMS: 6,     // elementos en común, [Fe/H] incluido
   TAG_DTEFF: 400,       // K: solo se comparan estrellas parecidas (sistemáticos de análisis)
   TAG_DLOGG: 0.5,
   TAG_DOPPEL_RATE: 0.01,// «del orden del 1 %» de pares de campo al azar son dobles químicos (Ness et al. 2018)
   TAG_COMOVE_KMS: 5,    // diseño: «se mueven juntas» si difieren menos de esto en v tangencial y RV

   // --- Huella nucleosintética ------------------------------------------------
   // Beers & Christlieb 2005 (ARA&A 43, 531): r-I 0,3 <= [Eu/Fe] <= 1,0 y [Ba/Eu] < 0;
   // r-II [Eu/Fe] > 1,0 y [Ba/Eu] < 0; s [Ba/Fe] > 1,0 y [Ba/Eu] > 0,5.
   // CEMP: [C/Fe] > 0,7 (Aoki et al. 2007, ApJ 655, 492).
   R1_EU: 0.3, R2_EU: 1.0, S_BA: 1.0, S_BAEU: 0.5, CEMP_C: 0.7,
   // Gemela solar (Ramírez, Meléndez & Asplund 2009): ±100 K, ±0,1 dex en logg y [Fe/H].
   SUN_TEFF: 5772, SUN_LOGG: 4.438,
   TWIN_DTEFF: 100, TWIN_DLOGG: 0.1, TWIN_DFEH: 0.1,

   // --- El LITIO (23-oct-2026; docs/litio_y_mg_xiang.md) ---------------------------------------------------------
   // Se guarda como A(Li) ABSOLUTA (log ε, H = 12), NO como [Li/Fe]: el litio no sigue a la nucleosíntesis del hierro, se
   // DESTRUYE dentro de las estrellas (arde a ~2,5 MK) y su valor depende de la Teff, la masa y la edad. Los límites
   // superiores se marcan (ul) y no se mezclan con las detecciones. Fuente de los datos: GALAH DR4, A(Li) 3D NLTE
   // (Buder et al. 2025, PASA 42, e051, sec. 7.2.3; método de Wang et al. 2024, arXiv:2402.02669).
   LI_SUN: 1.05,         // A(Li) de la fotosfera del Sol (Asplund et al. 2009, ARA&A 47, 481: 1,05 ± 0,10; el mismo que usa GALAH DR4, tabla 8)
   LI_METEOR: 3.26,      // A(Li) meteorítica = la del gas del que nació el Sistema Solar (Asplund et al. 2009: 3,26 ± 0,05)
   LI_SPITE: 2.199,      // meseta de Spite de enanas viejas pobres en metales, 3D NLTE (Sbordone et al. 2010, A&A 522, A26: 2,199 ± 0,086)
   LI_SPITE_SIG: 0.086,
   LI_RICH: 1.5,         // gigante «rica en litio» si A(Li) >= 1,5: criterio de uso común (p. ej. Gao et al. 2019, ApJS 245, 33, LAMOST),
                         // el máximo que deja el primer dragado en los modelos estándar (Iben 1967)
   LI_GIANT_LOGG: 3.5,   // diseño: por debajo, gigante a efectos del litio (el primer dragado ya ha diluido la capa externa)
   LI_TEFF_MIN: 4000,    // las atmósferas 3D (STAGGER) solo llegan a 4000 K (Buder et al. 2025, sec. 7.2.3): por debajo no se usa
   LI_FLOOR: 0.05,       // dex: suelo del error de A(Li) (diseño, como CC_GSP_FLOOR)

   // --- El CERO del [Mg/Fe] de LAMOST (Xiang et al. 2019) en ENANAS (23-oct-2026; docs/litio_y_mg_xiang.md) -------
   // MEDIDO (tests/cc_mg_xiang_compare.js, red real, 8 campos con pares): en las mismas estrellas, [Mg/Fe]_Xiang − [Mg/Fe]_APOGEE DR17 =
   // +0,07 en las enanas (logg de Xiang >= 3,8; 2 624 pares, σ 0,06; +0,06…+0,08 de un campo a otro y +0,06…+0,07 en todo
   // [Fe/H]) y −0,03 en las gigantes (logg < 3,5; 3 790 pares, σ 0,06, de −0,04 a +0,05 según el campo: NO se corrige, cabe en
   // ALPHA_ZP_SIGMA). Lo anticipa el propio artículo (Xiang et al. 2019, ApJS 245, 34, sec. IV.4 y tabla 4: su [Mg/Fe] recomendado
   // se entrenó con GALAH DR2 y queda «0,09 dex» por ENCIMA del entrenado con APOGEE en enanas y «0,04» por debajo en gigantes).
   // Control: M 67 (Gao et al. 2018, GALAH NLTE, [Mg/Fe] = +0,00 ± 0,05): las enanas miembro de Xiang dan +0,07 sin corregir
   // (FALLA) y ≈ 0,00 corregidas. La frontera de Weinberg del producto está en la escala de APOGEE DR17: por eso se lleva ahí.
   X19_MG_DWARF_LOGG: 3.8,    // medido: Δ +0,07 con logg_Xiang >= 3,8; +0,03 entre 3,5 y 3,8 (cabe en ALPHA_ZP_SIGMA: no se corrige)
   X19_MG_DWARF_ZP: -0.07,    // lo que se SUMA al [Mg/Fe] de Xiang en esas enanas (0 = apagado: así lo apagan las pruebas para ver el rojo)
   X19_MG_DWARF_ZP_E: 0.03,   // incertidumbre de la corrección (medida: +0,06…+0,08 de un campo a otro y +0,03…+0,09 con la Teff
                              // entre 4 500 y 6 500 K): se suma en cuadratura al error del [Mg/Fe] corregido

   // --- ¿El número de Gaia que trae el survey es de ESTA estrella? (C1, 23-oct-2026; docs/contradicciones_ficha.md) -------------
   // APOGEE y GALAH dan la posición de 2MASS (época ~2000). MEDIDO (tests/cc_sci_c1c2c3_check.js, 7 campos grabados + la foto de
   // Abell 39): survey − Gaia DR3 llevada a J2000 con su pm, APOGEE n 969 mediana 0,07" p99 0,48" máx (sin C1) 1,27"; GALAH n 250
   // máx 0,29". UNA sola por encima de 1,5": la de C1 (2,55"), cuyo id de Gaia en APOGEE DR17 es una vecina de G 20,3 (la estrella
   // de 2MASS, H 11,42, es Gaia DR3 1305772999760178816, G 14,38, a 0,91", sin paralaje). LAMOST y Xiang+19 NO entran: son las
   // posiciones de la fibra (medido: p99 2,5", máx 3,0" con ids correctos).
   XMATCH_ARCSEC: 1.5,        // diseño: el mismo radio con que el motor casa por posición (ccBuildStars); medido arriba que separa
   XMATCH_EPOCH_YR: 3,        // diseño: holgura de la época de 2MASS (1997-2001 frente a 2000,0) multiplicada por el pm
   // --- Velocidades radiales que no casan entre catálogos (C3, 23-oct-2026) ------------------------------------------------------
   // HD 140283: GALAH DR4 −173,71 ± 0,30 frente a Gaia DR3 −170,36 ± 0,16 y Latham et al. 2002 (AJ 124, 1144) −171,12 ± 0,29.
   // MEDIDO: GALAH − APOGEE −0,04 km/s, σ robusta 0,32 (n 128); GALAH − Gaia +0,28, σ 1,47 (n 232): la de HD 140283 es un caso suelto.
   RV_DISC_SIG: 3,            // diseño, como CC_DISCREPANT_DEX: más de 3 σ combinadas…
   RV_DISC_KMS: 2,            // …y más de 2 km/s (≈ 6 veces la σ medida GALAH − APOGEE)
   ZMAX_UNSTABLE_KPC: 0.3,    // diseño: la Zmax «no está bien medida» si con la otra RV cambia más de 0,3 kpc…
   ZMAX_UNSTABLE_FRAC: 0.25,  // …y más de un 25 % (HD 140283: 2,27 frente a 5,40 kpc con 3,35 km/s de diferencia)

   // --- Decisiones de Nino sobre P1-P8 (23-oct-2026; docs/contradicciones_ficha.md, «Aplicado») ------------------------------------
   // P1 · cómo se llama una órbita por su excentricidad. NO hay una nomenclatura única en la literatura; lo común es comparar con las
   // distribuciones de cada población (con órbitas integradas en un potencial, como aquí):
   //   disco fino: pico en e ≈ 0,12–0,15 y muy pocas por encima de 0,3 (Recio-Blanco et al. 2014, arXiv:1403.7568, sec. 8.1, Gaia-ESO:
   //   «strongly peaked at ≈ 0,15»; Yan et al. 2019, arXiv:1906.03875, LAMOST+Gaia: pico en 0,12) · disco grueso: mediana ≈ 0,3, pico en
   //   0,42 (las mismas) y casi ninguna por encima de 0,6 (Lee et al. 2011, ApJ 738, 187) · halo acretado (Gaia-Enceladus): e > 0,7, el
   //   único corte NUMÉRICO de uso común (Naidu et al. 2020, ApJ 901, 48, ec. 4; Mackereth et al. 2019, MNRAS 482, 3426: e ≳ 0,8).
   // Cortes: < 0,2 «casi circular» (lo típico del disco fino) · 0,2–0,5 «algo alargada» (lo típico del grueso) · 0,5–0,7 «alargada»
   // (ya fuera de los dos discos) · > 0,7 «muy alargada» (la de Gaia-Enceladus, el mismo corte que CC_FAM.GSE_ECC).
   ECC_BINS: [0.2, 0.5, 0.7],
   // P2 · «química y cinemática de acuerdo» solo si la cinemática da MÁS de esto a la misma población; si da más de esto a OTRA,
   // «en tensión»; si no, «la cinemática no distingue». (Nino, 23-oct. Equivale a TD/D > 2,3 con dos poblaciones; Bensby et al. 2014,
   // A&A 562, A71, llaman «disco grueso» a TD/D > 2 y «fino» a TD/D < 0,5, es decir P > 0,67.)
   KIN_AGREE_P: 0.70,
   // (29-oct, decisión de Nino) sin química, si la más probable es un disco (fino o grueso) con P por debajo de esto, la ficha dice
   // «disco» sin elegir: con el modelo único casi nunca queda «indeterminada» (0 de 2 741) y un 53 % no distingue fino de grueso.
   // 0,6 es el corte que tenía la «mezcla» del modelo de antes (KIN_CLASS_P), el que Nino vio en la ficha hasta hoy.
   KIN_DISC_P: (typeof CSH_KINPOP !== "undefined") ? CSH_KINPOP.DISC_P : 0.60,   // el de CabraShared/csh_kinpop.js
   // P4 · Kordopatis et al. 2023 en GIGANTES (log g < 3,5) -> nivel C. MEDIDO en M 67 (miembros, ref. ≈ 3,5–4,5 Ga): Kordopatis en
   // gigantes 5,66 Ga (n 30) frente a Anders+23 3,79 (26) y Boin 4,11 (41); en subgigantes, 4,24 (9): bien.
   AGE_KORD_GIANT_LOGG: 3.5,
   // P7 · la Zmax se da con «≈» si es inestable (C3) o si el pericentro pasa a menos de esto del centro: ahí la Zmax depende del
   // potencial (HD 140283, pericentro 0,41 kpc: 2,26 kpc con McMillan 2017, Kordopatis+23, frente a 5,40 aquí con la misma RV). Diseño.
   ZMAX_PERI_KPC: 1.0
};
// Costura de prueba (solo pruebas): ccBroken de cc_dialog.js en PixInsight, o el global que defina una prueba de node.
function ccSciBroken(k) { try { return typeof ccBroken === "function" && !!ccBroken(k); } catch (e) { return false; } }

// Elementos que se enseñan (y su familia nucleosintética). C y N cambian en las
// gigantes por la mezcla (no son de nacimiento): no entran en el tagging.
var CC_ELEMENTS = [
   ["C", "light"], ["N", "light"], ["O", "alpha"], ["Na", "odd"], ["Mg", "alpha"], ["Al", "odd"],
   ["Si", "alpha"], ["S", "alpha"], ["K", "odd"], ["Ca", "alpha"], ["Sc", "odd"], ["Ti", "alpha"],
   ["V", "peak"], ["Cr", "peak"], ["Mn", "peak"], ["Co", "peak"], ["Ni", "peak"], ["Cu", "peak"],
   ["Zn", "peak"], ["Rb", "s"], ["Sr", "s"], ["Y", "s"], ["Zr", "s"], ["Mo", "r"], ["Ru", "r"],
   ["Ba", "s"], ["La", "s"], ["Ce", "s"], ["Nd", "s"], ["Sm", "r"], ["Eu", "r"]
];
var CC_TAG_EXCLUDE = { C: true, N: true, Li: true };

// Prioridad de los surveys para la química (Nino: GALAH DR4 principal donde
// exista; APOGEE; LAMOST para rellenar; Gaia como base). XPG = metalicidades
// de los espectros XP (Andrae et al. 2023, gigantes) — mejores que GSP-Phot.
// (14-oct-2026: XP iba delante de GSP-Spec y se vio MAL en la captura de M 67: una gigante de
//  G = 7,5 salía con [Fe/H] −0,76 de XP frente a −0,10 del espectro RVS; XP es fotometría de
//  baja resolución, RVS es espectroscopía. Ahora GSP-Spec va antes y las discrepancias se avisan.)
var CC_CHEM_PRIORITY = ["galah", "apogee", "x19", "lamost", "gspspec", "xpg"];
// Discrepancia entre surveys que se AVISA en la ficha: más de 0,25 dex y más de 3 σ (diseño).
var CC_DISCREPANT_DEX = 0.25;
var CC_SURVEY_LABEL = {
   galah: "GALAH DR4", apogee: "APOGEE DR17", x19: "LAMOST DR5 (Xiang+19)", lamost: "LAMOST DR11",
   xpg: "Gaia XP (Andrae+23)", gspspec: "Gaia DR3 GSP-Spec", gaia: "Gaia DR3"
};

// ---------------------------------------------------------------------------
// Utilidades numéricas
// ---------------------------------------------------------------------------
function ccNum(v) {
   if (v === null || v === undefined) return null;
   if (typeof v === "number") return isFinite(v) ? v : null;
   var s = String(v).replace(/^\s+|\s+$/g, "");
   if (s.length === 0) return null;
   var x = Number(s);
   return isFinite(x) ? x : null;
}
function ccIsNum(v) { return typeof v === "number" && isFinite(v); }
function ccClamp(x, a, b) { return x < a ? a : (x > b ? b : x); }
function ccMedian(a) {
   var b = [];
   for (var i = 0; i < a.length; ++i) if (ccIsNum(a[i])) b.push(a[i]);
   if (b.length === 0) return null;
   b.sort(function(p, q) { return p - q; });
   var m = b.length >> 1;
   return (b.length % 2) ? b[m] : 0.5 * (b[m - 1] + b[m]);
}
// Función de distribución de la normal estándar (Abramowitz & Stegun 26.2.17).
function ccPhi(z) {
   if (!ccIsNum(z)) return 0.5;
   var t = 1 / (1 + 0.2316419 * Math.abs(z));
   var d = 0.3989422804014327 * Math.exp(-z * z / 2);
   var p = d * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
   return z > 0 ? 1 - p : p;
}
// Generador reproducible (LCG de Numerical Recipes) y normal de Box-Muller.
function ccRng(seed) {
   var s = (seed >>> 0) || 1;
   var spare = null;
   return {
      u: function() { s = (Math.imul(1664525, s) + 1013904223) >>> 0; return (s + 0.5) / 4294967296; },
      n: function() {
         if (spare !== null) { var r = spare; spare = null; return r; }
         var u1 = this.u(), u2 = this.u(), m = Math.sqrt(-2 * Math.log(u1));
         spare = m * Math.sin(2 * Math.PI * u2);
         return m * Math.cos(2 * Math.PI * u2);
      }
   };
}
// Una semilla estable a partir del identificador.
function ccSeedOf(id) {
   var s = String(id), h = 2166136261;
   for (var i = 0; i < s.length; ++i) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
   return h >>> 0;
}

// ---------------------------------------------------------------------------
// CINEMÁTICA
// ---------------------------------------------------------------------------
// (ra, dec en grados; d en pc; pm en mas/año; rv en km/s) -> velocidad ICRS
// cartesiana (km/s) y posición unitaria.
function ccIcrsVelocity(ra, dec, dPc, pmra, pmdec, rv) {
   var a = ra * Math.PI / 180, d = dec * Math.PI / 180;
   var ca = Math.cos(a), sa = Math.sin(a), cd = Math.cos(d), sd = Math.sin(d);
   var k = CC_SCI.KV * dPc / 1000;
   var vt1 = k * pmra, vt2 = k * pmdec;
   return [rv * cd * ca - vt1 * sa - vt2 * sd * ca,
           rv * cd * sa + vt1 * ca - vt2 * sd * sa,
           rv * sd + vt2 * cd];
}
function ccMatVec(M, v) {
   return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2],
           M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2],
           M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]];
}
// Galácticas (l, b) en grados.
function ccGalactic(ra, dec) {
   var a = ra * Math.PI / 180, d = dec * Math.PI / 180;
   var r = ccMatVec(CC_SCI.AG, [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)]);
   var l = Math.atan2(r[1], r[0]) * 180 / Math.PI;
   if (l < 0) l += 360;
   return { l: l, b: Math.asin(ccClamp(r[2], -1, 1)) * 180 / Math.PI, xyz: r };
}
// UVW HELIOCÉNTRICAS (U hacia el centro galáctico, V hacia la rotación, W al polo norte).
function ccUvw(ra, dec, dPc, pmra, pmdec, rv) {
   return ccMatVec(CC_SCI.AG, ccIcrsVelocity(ra, dec, dPc, pmra, pmdec, rv));
}
// Respecto al LSR: el MISMO movimiento solar del modelo de población (CSH_KINPOP.SUN_UVW, Schönrich et al. 2010; hasta el 29-oct,
// Dehnen & Binney 1998). Así el diagrama de Toomre y la población hablan del mismo LSR.
function ccUvwLsr(uvw) {
   var S = CSH_KINPOP.SUN_UVW;
   return [uvw[0] + S[0], uvw[1] + S[1], uvw[2] + S[2]];
}
// Galactocéntricas: X (Sol en −R0), Y, Z (kpc); vR, vφ (positiva = gira con el disco),
// vz (km/s); R (kpc); Lz (kpc km/s, positivo = prógrado).
function ccGalactocentric(ra, dec, dPc, pmra, pmdec, rv) {
   var g = ccGalactic(ra, dec), dk = dPc / 1000;
   var x = g.xyz[0] * dk, y = g.xyz[1] * dk, z = g.xyz[2] * dk;
   var uvw = ccUvw(ra, dec, dPc, pmra, pmdec, rv);
   var X = x - CC_SCI.R0_KPC, Y = y, Z = z + CC_SCI.ZSUN_KPC;
   var vx = uvw[0] + CC_SCI.VSUN_GC[0], vy = uvw[1] + CC_SCI.VSUN_GC[1], vz = uvw[2] + CC_SCI.VSUN_GC[2];
   var R = Math.sqrt(X * X + Y * Y);
   var lz = -(X * vy - Y * vx);
   var vphi = R > 0 ? lz / R : 0;
   var vR = R > 0 ? (X * vx + Y * vy) / R : 0;
   return { X: X, Y: Y, Z: Z, R: R, vR: vR, vphi: vphi, vz: vz, Lz: lz };
}

// La cinemática de una estrella. ADAPTADOR (29-oct-2026) del modelo ÚNICO de población, `cshKinPop` de
// CabraShared/csh_kinpop.js: la misma estrella da aquí y en CabraStars la misma población y las mismas probabilidades
// (CabraShared/tests/csh_kinpop_test.js, prueba A). Los errores entran como allí, sin Monte Carlo: la RV con su error (s.rv.e,
// 1 km/s si falta), la distancia con la semianchura de su intervalo (lo-hi; ±10 % si falta, como antes) y los del movimiento
// propio NO entran (tampoco en CabraStars). Con un error de distancia > 20 % (CSH_KINPOP.MAX_DIST_FRACTION) no hay población:
// la estrella conserva sus velocidades (Toomre, Lz) pero `probs` es null y `verdict` "no-data".
// s = { id, ra, dec, pmra, pmdec, epmra, epmdec, dist: { pc, lo, hi }, rv: { v, e } }
// Devuelve null si falta algo (o si no está incluido csh_kinpop.js), o
//   { uvw, uvwLsr, vtot, probs ({ thin, thick, halo } o null), best, verdict ("probable" | "possible" | "undetermined" |
//     "no-data"), why, cls, model, local, gc, draws }
// `cls` = la población si el veredicto es «probable» o «posible»; "undetermined" si ninguna llega a P 0,5 (lo que hasta el
// 29-oct era "mixed", entonces por debajo de 0,6); "" sin población. `draws` = 0 (ya no hay Monte Carlo).
function ccKinematics(s) {
   if (!s || !ccIsNum(s.ra) || !ccIsNum(s.dec) || !ccIsNum(s.pmra) || !ccIsNum(s.pmdec)) return null;
   if (!s.dist || !ccIsNum(s.dist.pc) || !(s.dist.pc > 0)) return null;
   if (!s.rv || !ccIsNum(s.rv.v)) return null;
   if (typeof cshKinPop !== "function") return null;          // sin CabraShared/csh_kinpop.js: «sin cinemática» (no se rompe nada)
   var d0 = s.dist.pc;
   var uvw = ccUvw(s.ra, s.dec, d0, s.pmra, s.pmdec, s.rv.v), L = ccUvwLsr(uvw);
   var out = { uvw: uvw, uvwLsr: L, vtot: Math.sqrt(L[0] * L[0] + L[1] * L[1] + L[2] * L[2]),
               probs: null, best: "", verdict: "no-data", why: "", cls: "", model: "",
               local: d0 <= CC_SCI.KIN_LOCAL_PC, gc: ccGalactocentric(s.ra, s.dec, d0, s.pmra, s.pmdec, s.rv.v), draws: 0 };
   var lo = ccIsNum(s.dist.lo) ? s.dist.lo : d0 * 0.9, hi = ccIsNum(s.dist.hi) ? s.dist.hi : d0 * 1.1;
   // (30-oct, N1 + D1-H5, decisión B de Nino) el RUWE ya no se lee en balde: RUWE ≥ 1,4 da distancia «suspect», como en CabraStars (`s.ruwe` lo pasa ccFinishStar; sin él, como antes)
   var k = cshKinPop({ ra: s.ra, dec: s.dec, dist: { pc: d0, lo: lo, hi: hi, quality: (ccIsNum(s.ruwe) && s.ruwe >= CSH_KINPOP.MAX_RUWE) ? "suspect" : "good" }, pmRa: s.pmra, pmDec: s.pmdec,
                       rv: s.rv.v, rvErr: ccIsNum(s.rv.e) ? s.rv.e : 1 });
   out.model = k.model; out.why = k.why; out.verdict = k.verdict;
   if (k.p) {
      out.probs = k.p; out.best = k.pop;
      out.cls = (k.verdict === "probable" || k.verdict === "possible") ? k.pop : "undetermined";
   }
   return out;
}
// El veredicto cinemático en una palabra (la ficha, delante de las barras): ES y EN.
function ccKinVerdictWord(kin, lang) {
   var E = (lang === "es"), v = kin ? kin.verdict : "";
   if (v === "probable") return "probable";
   if (v === "possible") return E ? "posible" : "possible";
   if (v === "undetermined") return E ? "indeterminada" : "undetermined";
   return "";
}

// ---------------------------------------------------------------------------
// GAIA GSP-Spec: calidad y calibración
// ---------------------------------------------------------------------------
// Calidad «media» (Recio-Blanco et al. 2023, A&A 674, A29, sec. 9.1.1, VERIFICADO en el texto y en su tabla 2 el 26-oct-2026):
// los 13 primeros caracteres de flags_gspspec <= 1, «except for the KMgiantPar, which we insist must be equal to zero and the
// fluxnoise flag that we relax to smaller than or equal to three». Tabla 2: el carácter 7 es fluxNoise (0–5, 9), el 8 extrapol
// (0–4, 9), el 9 negFlux (0, 1, 9) y el 13 KMgiantPar (0, 1, 2: gigantes K-M frías, con Teff y logg FIJADOS a 4 250 K y 1,5).
// (Hasta el 26-oct se relajaban a <= 3 los caracteres 7, 8 y 9 y no se miraba KMgiantPar: entraban extrapol 2–3 y KMgiantPar 1.
// Medido en las respuestas grabadas de tests/fx: 595 → 568 estrellas; las 18 de KMgiantPar salen todas con Teff 4 250 y logg 1,5,
// y en M 67 las 4 de extrapol 2 traen [M/H] −1,01 / −0,56 / −0,13 / … en un cúmulo de [Fe/H] ≈ 0. tests/cc_node_gspflags.js.)
function ccGspSpecGood(flags) {
   var f = String(flags || ""), old = (typeof ccSciBroken === "function" && ccSciBroken("gsp-oldflags"));   // (ROJO: el corte de antes)
   if (f.length < 13) return false;
   for (var i = 0; i < 13; ++i) {
      var c = f.charCodeAt(i) - 48, lim = old ? ((i >= 6 && i <= 8) ? 3 : 1) : ((i === 6) ? 3 : (i === 12) ? 0 : 1);
      if (!(c >= 0 && c <= lim)) return false;
   }
   return true;
}
function ccPoly(p, x) { var s = 0, xn = 1; for (var i = 0; i < p.length; ++i) { s += p[i] * xn; xn *= x; } return s; }
function ccGspCalMh(mh, logg) { return (ccIsNum(mh) && ccIsNum(logg)) ? mh + ccPoly(CC_SCI.GSP_MH_P, logg) : null; }
function ccGspCalAfe(afe, logg) {
   if (!ccIsNum(afe) || !ccIsNum(logg)) return null;
   return afe + ccPoly(CC_SCI.GSP_AFE_P, ccClamp(logg, CC_SCI.GSP_AFE_LOGG[0], CC_SCI.GSP_AFE_LOGG[1]));
}

// ---------------------------------------------------------------------------
// QUÍMICA: un registro por survey -> lo adoptado
// ----------------------------------------------------------------------------
// rec (de cc_catalogs.js) = { survey, feh: {v,e}, alpha: {v,e,tracer}, el: { Mg: {v,e}, ... },
//                             teff, logg, rv: {v,e}, ... }
// ---------------------------------------------------------------------------
// La recta NO se extrapola por debajo de [Fe/H] = HALO_FEH (Weinberg la midió en el
// disco; extrapolada a −2,6 pediría [Mg/Fe] > 0,50 para ser «alto-α» y mandaría al
// halo α-alto de toda la vida —HD 122563, [Mg/Fe] = 0,37— al lado «bajo-α»: visto en
// el control del 14-oct-2026). Por debajo se usa su valor en −1,0 (0,29).
function ccAlphaLine(feh) {
   return CC_SCI.ALPHA_LINE_A + CC_SCI.ALPHA_LINE_B * Math.min(0, Math.max(CC_SCI.HALO_FEH, feh));
}
// (27-oct, R6 de la revisión de Codex) ¿cuenta el término de PENDIENTE de la frontera en la incertidumbre de α? Solo donde la recta tiene
// pendiente: HALO_FEH < [Fe/H] < 0. Por debajo de HALO_FEH la frontera es constante (ccAlphaLine), así que el error de [Fe/H] no se propaga
// a ella; antes se aplicaba también ahí y cambiaba la frase del relato en 2 de 70 estrellas del halo. ROJO «sci-slopeall»: el criterio de antes.
function ccAlphaSlopeApplies(feh) {
   if (ccSciBroken("sci-slopeall")) return feh < 0;
   return feh > CC_SCI.HALO_FEH && feh < 0;
}
// Adopta [Fe/H], el par para el plano α y los elementos. recs = { survey: rec }.
function ccAdoptChem(recs) {
   var out = { feh: null, pair: null, el: {}, sources: [], teff: null, logg: null };
   for (var i = 0; i < CC_CHEM_PRIORITY.length; ++i) {
      var k = CC_CHEM_PRIORITY[i], r = recs[k];
      if (!r) continue;
      if (r.feh && ccIsNum(r.feh.v)) {
         out.sources.push(k);
         if (!out.feh) out.feh = { v: r.feh.v, e: ccIsNum(r.feh.e) ? r.feh.e : null, src: k, proxy: r.feh.proxy || "" };
         if (!out.pair && r.alpha && ccIsNum(r.alpha.v)) {
            out.pair = { feh: r.feh.v, efeh: r.feh.e, alpha: r.alpha.v, ealpha: r.alpha.e, tracer: r.alpha.tracer || "alpha", src: k };
            if (r.alpha.zp) out.pair.zp = r.alpha.zp;        // (la corrección de cero aplicada, p. ej. Xiang+19 en enanas: CC_SCI.X19_MG_DWARF_ZP)
         }
         if (out.teff === null && ccIsNum(r.teff)) { out.teff = r.teff; out.logg = ccIsNum(r.logg) ? r.logg : null; out.paramSrc = k; }
      }
      if (r.el) for (var e in r.el) if (r.el.hasOwnProperty(e) && !out.el[e] && r.el[e] && ccIsNum(r.el[e].v)) {
         out.el[e] = { v: r.el[e].v, e: r.el[e].e, src: k };
         if (r.el[e].zp) { out.el[e].zp = r.el[e].zp; out.el[e].raw = r.el[e].raw; }
      }
      // el litio va APARTE de out.el (A(Li) absoluta, no [X/Fe]): la primera DETECCIÓN por prioridad; un límite superior solo si no hay
      // detección. Con la Teff y la gravedad DEL MISMO survey (A(Li) depende de la Teff con que se midió). Hoy solo GALAH DR4 lo trae.
      if (r.li && ccIsNum(r.li.v) && (!out.li || (out.li.ul && !r.li.ul)))
         out.li = { v: r.li.v, e: r.li.e, ul: !!r.li.ul, src: k, method: r.li.method || "", teff: ccIsNum(r.teff) ? r.teff : null, logg: ccIsNum(r.logg) ? r.logg : null };
   }
   if (!out.li) out.li = null;
   // ¿Discrepan los surveys en [Fe/H]? (se enseña; no se esconde ni se promedia)
   out.discrepant = null;
   var vals = [];
   for (i = 0; i < CC_CHEM_PRIORITY.length; ++i) { var rr = recs[CC_CHEM_PRIORITY[i]]; if (rr && rr.feh && ccIsNum(rr.feh.v)) vals.push({ k: CC_CHEM_PRIORITY[i], v: rr.feh.v, e: ccIsNum(rr.feh.e) ? rr.feh.e : 0.1 }); }
   for (i = 0; i < vals.length; ++i) for (var j = i + 1; j < vals.length; ++j) {
      var d = Math.abs(vals[i].v - vals[j].v), sg = Math.sqrt(vals[i].e * vals[i].e + vals[j].e * vals[j].e);
      if (d > CC_DISCREPANT_DEX && d > 3 * sg && (!out.discrepant || d > out.discrepant.dex)) out.discrepant = { dex: d, a: vals[i].k, b: vals[j].k };
   }
   return out;
}

// Clase QUÍMICA. Devuelve null si no hay [Fe/H]; si no:
// { cls: "thin"|"thick"|"halo"|"halo-high"|"halo-low", pHigh, dist (σ a la frontera), basis }
//   basis = "feh+alpha" | "feh" (sin α no se separan los discos: cls "disc?" )
function ccChemClass(chem) {
   if (!chem || !chem.feh) return null;
   var feh = chem.pair ? chem.pair.feh : chem.feh.v;
   var out = { cls: "", pHigh: null, z: null, basis: chem.pair ? "feh+alpha" : "feh", line: null };
   if (chem.pair) {
      var a = chem.pair.alpha, ea = ccIsNum(chem.pair.ealpha) ? chem.pair.ealpha : 0.05;
      var ef = ccIsNum(chem.pair.efeh) ? chem.pair.efeh : 0.05;
      var line = ccAlphaLine(feh);
      var sig = Math.sqrt(ea * ea + CC_SCI.ALPHA_ZP_SIGMA * CC_SCI.ALPHA_ZP_SIGMA + (ccAlphaSlopeApplies(feh) ? 0.0169 * ef * ef : 0));
      out.z = (a - line) / sig;
      out.pHigh = ccPhi(out.z);
      out.line = line;
   }
   if (feh <= CC_SCI.HALO_FEH) {
      out.cls = (out.pHigh === null) ? "halo" : (out.pHigh >= 0.5 ? "halo-high" : "halo-low");
   } else if (out.pHigh === null) {
      out.cls = (chem.feh.v < -0.6) ? "disc-poor" : "disc";   // sin α no se separan fino y grueso
   } else {
      out.cls = (out.pHigh >= 0.5) ? "thick" : "thin";
   }
   out.confident = (out.pHigh === null) ? false : (out.pHigh >= 0.84 || out.pHigh <= 0.16);
   return out;
}

// ---------------------------------------------------------------------------
// EDADES
// ----------------------------------------------------------------------------
// ages = [ { src, method, v, lo, hi, e, flag } ] (de cc_catalogs.js); se adopta
// la del método de más prioridad que pase sus guardas; las demás quedan como
// «otras estimaciones» (se enseñan: si discrepan, el usuario lo ve).
var CC_AGE_PRIORITY = ["xr22", "anders23", "boin", "kord23", "galah-iso", "flame"];
var CC_AGE_LABEL = {
   xr22: "Xiang & Rix 2022 (subgiants, LAMOST)",
   anders23: "Anders et al. 2023 (APOGEE, asteroseismic-calibrated)",
   boin: "Boin et al. 2026 (isochrone NN, 5 grids)",
   kord23: "Kordopatis et al. 2023 (Gaia GSP-Spec isochrones)",
   "galah-iso": "GALAH DR4 (isochrone, no error)",
   flame: "Gaia DR3 FLAME (solar-metallicity models)"
};
// (27-oct, E3) LA BANDERA DE ANDERS+23 (`f_spAge`), que es TEXTO. Antes `ccNum(f_spAge)` daba siempre null y no se leía nunca.
// Valores (ReadMe de J/A+A/678/A158, nota 2): BLUER_THAN_TRAINING_SET, REDDER_THAN_TRAINING_SET, HIGH_VSINI, APPARENTLY_YOUNG_ALPHA_RICH y
// «combinaciones» (el ReadMe no dice el separador: se buscan los nombres dentro del texto, sin partirlo). Qué hace cada una (Anders+23,
// arXiv:2304.08276, §4.6 y apéndice A; docs/edades_catalogos.md §8):
//   · APPARENTLY_YOUNG_ALPHA_RICH -> SE DESCARTA. Son productos de evolución binaria (rejuvenecidas por transferencia de masa): «their
//     ages should not be used» (706 estrellas con [Mg/Fe] > 0,2 y edad ≤ 6 Ga). La edad está «catastróficamente subestimada».
//   · HIGH_VSINI (v sin i > 10 km/s, 561 estrellas) -> SE DESCARTA. Los autores las agrupan con las anteriores como «most likely affected by
//     effects of binary evolution»; el texto no dice «no usar» como en las α-ricas (INTERPRETACIÓN mía: una edad de espectro con líneas
//     ensanchadas por rotación, en una gigante que no debería rotar, no es fiable).
//   · BLUER_THAN_TRAINING_SET (4 137) y REDDER_THAN_TRAINING_SET (280) -> SOLO SE MARCAN: están en los bordes del conjunto de entrenamiento
//     y «may have less reliable ages»; la edad es utilizable. Se adopta con `warn` y la ficha lo dice.
//   · Cualquier otro texto no vacío (un valor nuevo del catálogo) -> se descarta (lo prudente: no se sabe qué avisa).
// Costura de prueba: «sci-andersflag» = como antes (la bandera de texto no se lee: nunca marca nada).
function ccAndersFlag(txt) {
   var s = String(txt === undefined || txt === null ? "" : txt).replace(/^\s+|\s+$/g, "");
   var out = { reject: false, warn: "", why: "" };
   if (!s || ccSciBroken("sci-andersflag")) return out;
   var w = [];
   if (/BLUER_THAN_TRAINING_SET/.test(s)) w.push("BLUER_THAN_TRAINING_SET");
   if (/REDDER_THAN_TRAINING_SET/.test(s)) w.push("REDDER_THAN_TRAINING_SET");
   var rest = s.replace(/BLUER_THAN_TRAINING_SET|REDDER_THAN_TRAINING_SET/g, "");
   if (/[A-Za-z]{3}/.test(rest)) { out.reject = true; out.why = s; }       // HIGH_VSINI, APPARENTLY_YOUNG_ALPHA_RICH o algo nuevo
   out.warn = w.join(" ");
   return out;
}
// (28-oct, pendiente 8) LA BANDERA DE FLAME (`Flags-Flame` = flags_flame de Gaia DR3), dos dígitos «AB». ReadMe de VizieR I/355, nota 4
// (copia del modelo de datos de la ESA, que dio 503 el 28-oct; lo mismo dice Creevey et al. 2023, §6.4.1):
//   A (masa y edad): 0 nada que decir · 1 gigante: masa y edad con un 20-30 % de incertidumbre · 2 sin masa ni edad.
//   B (de dónde sale la distancia de L y R): 0 paralaje · 1 distancia de GSP-Phot · 2 paralaje porque GSP-Phot no convergió. B NO dice nada
//     de la calidad de la edad: antes se rechazaba todo lo que no fuera 0, y con ello 42 edades A=0 de lo grabado (B = 1 o 2).
// OJO A LA CODIFICACIÓN: en VizieR la columna es ENTERA (I2, [0/22]): «01» llega como 1 y «02» como 2. Un 2 es A=0, B=2 (una edad buena),
// NO «A=2». A = floor(valor / 10), B = valor mod 10 (con texto «02» de la ESA, ccNum da 2 y sale igual).
// Qué hacemos con A=1 (las fuentes, en CC_SCI.FLAME_GIANT_*): solo con 1 ≤ M ≤ 2 M☉ (Mass-Flame) y edad > 1,0 Ga, y entonces ORIENTATIVA
// (nivel C, suelo de error del 30 %); fuera, se rechaza («flame-giant-mass» / «flame-giant-young»). Sin masa, se rechaza (no se puede mirar).
// Medido en M 67 (~4 Ga; scratchpad flame/m2_m67.js): las 8 gigantes A=1 con M > 2 dan 0,29–1,08 Ga (todas falsas); las 12 con 1–2 M☉, mediana
// 5,2 Ga (3,98–11,07): orientativas de verdad.
// Devuelve { a, b, reject, why, giant }. Sin bandera (vacía): como A=0 (lo de antes). A desconocida (> 2): se rechaza («flagged»).
// Costuras: «sci-flameall» = lo de antes (cualquier valor ≠ 0 rechaza) · «sci-flamedigit» = leer el entero como si fuera el dígito A (2 = sin edad)
// · «sci-flamenomass» = gigante aceptada sin mirar masa ni edad. Prueba: tests/cc_node_flame_28oct.js.
function ccFlameFlag(raw, mass, age) {
   var n = ccNum(raw), out = { a: null, b: null, reject: false, why: "", giant: false };
   if (n === null) return out;
   if (ccSciBroken("sci-flameall")) { out.reject = (n !== 0); out.why = out.reject ? "flagged" : ""; return out; }
   var a = Math.floor(n / 10), b = n % 10;
   if (ccSciBroken("sci-flamedigit") && n < 10) { a = n; b = 0; }
   out.a = a; out.b = b;
   if (a === 0) return out;
   if (a === 1) {
      out.giant = true;
      var M = CC_SCI.FLAME_GIANT_MASS;
      if (ccSciBroken("sci-flamenomass")) return out;      // (ROJO: gigante aceptada sin mirar masa ni edad)
      if (!ccIsNum(mass) || mass < M[0] || mass > M[1]) { out.reject = true; out.why = "flame-giant-mass"; }
      else if (!ccIsNum(age) || !(age > CC_SCI.FLAME_GIANT_MIN_GA)) { out.reject = true; out.why = "flame-giant-young"; }
      return out;
   }
   out.reject = true; out.why = "flagged";       // A=2 (sin masa ni edad) o un valor que no está en la nota
   return out;
}
function ccAdoptAge(ages, feh, logg) {
   var out = { adopted: null, others: [], rejected: [] };
   if (!ages || ages.length === 0) return out;
   var list = ages.slice();
   list.sort(function(a, b) { return CC_AGE_PRIORITY.indexOf(a.src) - CC_AGE_PRIORITY.indexOf(b.src); });
   for (var i = 0; i < list.length; ++i) {
      var a = list[i];
      var why = "";
      if (!ccIsNum(a.v) || a.v <= 0) why = "no-value";
      else if (a.src === "flame" && (!ccIsNum(feh) || feh <= CC_SCI.FLAME_FEH[0] || feh >= CC_SCI.FLAME_FEH[1])) why = "flame-metallicity";
      else if (!ccIsNum(a.e) && !(ccIsNum(a.lo) && ccIsNum(a.hi))) why = "no-error";
      else if (a.flag) why = a.flagWhy || "flagged";
      // (27-oct, R1b) BOIN: si alguna rejilla EN dominio tiene su banda de 1 σ ENTERA por encima del techo de su modelo (o de la edad del
      // Universo) —la mayoría de sus salidas extrapoladas; «más del 84 %» solo si fueran gaussianas (G4)—, la estrella no cabe en los modelos y no se adopta Boin (pasa a la siguiente
      // fuente). NO se combinan solo las rejillas que quedan: eso elige las jóvenes. Medido (docs/edades_catalogos.md): miembros de M 67
      // (~4 Ga) con edad adoptada > 8 Ga: 105 → 88 (solo con el techo del Universo → con este); sin la tolerancia de 1 σ serían 76, pero
      // HD 22879 (disco grueso, ~11-13 Ga, control positivo VIEJO) perdía su edad: MIST 13,37 ± 0,92 con techo 12,6 está en el borde, no fuera.
      else if (a.src === "boin" && a.grids && (a.over = ccBoinGridsOver(a.grids)).length) why = "beyond-model-ages";
      // (27-oct, R1b; sustituye al recorte de R1) el VALOR CENTRAL que publica el catálogo (la mediana en Boin, FLAME y Xiang & Rix) por
      // encima de la edad del Universo: más de la mitad de su distribución es imposible. Se rechaza y la ficha pasa a la siguiente
      // fuente. Ya no se recorta a 13,8: eso fabricaba «13,8 ± 4,9 Ga», una edad que el catálogo no dio (y que contradecía su intervalo).
      else if (a.v > CC_SCI.UNIVERSE_GA && !ccSciBroken("sci-nouniv")) why = "older-than-universe";
      if (why) { a.rejectWhy = why; out.rejected.push(a); continue; }
      if (!out.adopted) out.adopted = a; else out.others.push(a);
   }
   var all = [out.adopted].concat(out.others);
   for (var k = 0; k < all.length; ++k) {
      var A = all[k];
      if (!A) continue;
      if (!ccIsNum(A.lo)) A.lo = Math.max(0, A.v - A.e);
      if (!ccIsNum(A.hi)) A.hi = A.v + A.e;
      if (!ccIsNum(A.e)) A.e = 0.5 * (A.hi - A.lo);
      A.rel = A.e / A.v;
      A.tier = ccAgeTier(A.src, logg);
      // (28-oct, pendiente 8) FLAME en una gigante (Flags-Flame A=1, ya dentro de 1–2 M☉ y > 1 Ga: ccFlameFlag): orientativa, con el
      // suelo de error del 30 % (la nota 4 de I/355 dice 20-30 %). Costura «sci-flameall» = lo de antes (no llegaba aquí: se rechazaba).
      var floorRel = CC_SCI_AGE_FLOOR;
      if (A.src === "flame" && A.giant) { A.tier = "C"; floorRel = CC_SCI.FLAME_GIANT_EREL; }
      // Suelo de incertidumbre de las edades de isócrona: ninguna edad individual de isócrona
      // es mejor que ~10 % (las sismológicas, las mejores, están en 10-20 %). Visto en la captura de
      // Abell 39: Kordopatis daba 13,5 ± 0,1 Ga a una gigante (el borde de la rejilla, no precisión).
      if (A.tier !== "A" && ccIsNum(A.e) && A.e < floorRel * A.v) {
         A.eRaw = A.e; A.e = floorRel * A.v;
         A.lo = Math.max(0, Math.min(A.lo, A.v - A.e)); A.hi = Math.max(A.hi, A.v + A.e);
      }
      A.rel = A.e / A.v;
      // (27-oct, R1b) el valor central ya es <= 13,8 (lo de arriba), pero su BANDA puede pasar (Kordopatis 12,5 ± 3,0; el suelo del 10 %;
      // el error de Boin con la dispersión entre rejillas): el extremo alto se corta en la edad del Universo y se guarda el del catálogo
      // (`hiRaw`, `capped`). El valor y su error NO se tocan: la ficha no enseña «v ± e» (pasaría de 13,8) sino «v Ga (lo–13,8)» (ccAgeText).
      if (A.hi > CC_SCI.UNIVERSE_GA && !ccSciBroken("sci-nouniv")) { A.hiRaw = A.hi; A.hi = CC_SCI.UNIVERSE_GA; A.capped = true; }
      // En el límite de los modelos (las rejillas acaban en ~13,5-14 Ga): «de las más viejas».
      A.edge = (A.v >= CC_SCI_AGE_EDGE);
   }
   return out;
}
// LA FIABILIDAD DE UNA EDAD (medida en M 67, 14-oct-2026, tests/cc_node_m67_ages.js; referencia
// ~4 Ga): Anders+23 3,8 Ga (26 gigantes/subgigantes), Xiang & Rix 4,4 (4), Boin en subgigantes
// 4,4 (11) — bien; pero las isócronas en ENANAS de secuencia principal: Boin 6,4 Ga (297),
// FLAME 6,3 (84), Kordopatis 2,6 (11). En la secuencia principal la isócrona apenas se mueve
// con la edad: esas edades son INDICATIVAS.
//   "A" = método calibrado (sismología / subgigantes); "B" = isócrona en subgigante o gigante;
//   "C" = isócrona en enana (o sin gravedad conocida): indicativa.
var CC_SCI_AGE_DWARF_LOGG = 3.8;   // diseño: frontera enana / subgigante en logg
var CC_SCI_AGE_FLOOR = 0.10;       // diseño: incertidumbre relativa mínima de una edad de isócrona
var CC_SCI_AGE_EDGE = 13.0;        // diseño: por encima, la edad toca el borde de las rejillas
//   (P4, 23-oct) "C" también para Kordopatis+23 en una GIGANTE (log g < CC_SCI.AGE_KORD_GIANT_LOGG): en M 67 sale +1,5–1,9 Ga vieja.
function ccAgeTier(src, logg) {
   if (src === "xr22" || src === "anders23") return "A";
   if (src === "kord23" && ccIsNum(logg) && logg < CC_SCI.AGE_KORD_GIANT_LOGG && !ccSciBroken("sci-nokordc")) return "C";
   if (ccIsNum(logg) && logg <= CC_SCI_AGE_DWARF_LOGG) return "B";
   return "C";
}
// ¿Por qué es orientativa? "kord-giant" (P4: Kordopatis+23 en una gigante) · "flame-giant" (28-oct: FLAME con Flags-Flame A=1) ·
// "dwarf" (isócrona en una enana o sin gravedad) · "" (no lo es)
function ccAgeVagueWhy(a, logg) {
   if (!a || a.tier !== "C") return "";
   if (a.src === "flame" && a.giant) return "flame-giant";
   return (a.src === "kord23" && ccIsNum(logg) && logg < CC_SCI.AGE_KORD_GIANT_LOGG) ? "kord-giant" : "dwarf";
}
// (27-oct, R1b) la clave de i18n del rótulo del nivel bajo la edad de la ficha: a una gigante de Kordopatis (P4) la ficha le decía
// «isócrona en enana: solo orientativa» (Collinder 34, 463119215361946752, log g 1,4). Costura «sci-tierlabel»: el rótulo de antes.
function ccAgeTierKey(a, logg) {
   if (!a) return "";
   var vw = ccAgeVagueWhy(a, logg);
   if (!ccSciBroken("sci-tierlabel") && (vw === "kord-giant" || vw === "flame-giant")) return "tierCgiant";
   return "tier" + a.tier;
}
// Combina las cinco rejillas de Boin et al.: mediana de las medianas EN DOMINIO;
// error = suma cuadrática del error medio (estadístico) y de la dispersión entre
// rejillas (sistemático de modelos).
//   Qué publica Boin por rejilla (ReadMe de J/A+A/708/A215 y §2.1 del artículo): la MEDIANA de 10 000 salidas de la red al sortear
//   M_G, (BP−RP)_0 y [M/H] con sus errores, y `std` = la desviación típica de esas salidas (solo error de observación; sin el de modelo).
//   (27-oct, R1b) una rejilla sin `std` > 0 no entra: antes, con todas sin std, el error salía solo de la dispersión entre rejillas.
//   El techo de edad de cada rejilla lo mira ccAdoptAge (ccBoinGridsOver): aquí se combinan TODAS las de dominio, para que la combinación
//   no elija las jóvenes; si alguna pasa de su techo, la edad entera se rechaza allí.
function ccCombineGrids(grids) {
   var med = [], sd = [], noStd = ccSciBroken("sci-nostd");
   for (var i = 0; i < grids.length; ++i) {
      var g = grids[i];
      if (g && g.inDomain && ccIsNum(g.median) && g.median > 0 && (noStd || (ccIsNum(g.std) && g.std > 0))) { med.push(g.median); if (ccIsNum(g.std)) sd.push(g.std); }
   }
   if (med.length === 0) return null;
   var m = ccMedian(med), s2 = 0;
   for (var j = 0; j < sd.length; ++j) s2 += sd[j] * sd[j];
   var stat = sd.length ? Math.sqrt(s2 / sd.length) : null, sys = 0;
   if (med.length >= 2) { var mu = 0; for (j = 0; j < med.length; ++j) mu += med[j]; mu /= med.length; for (j = 0; j < med.length; ++j) sys += (med[j] - mu) * (med[j] - mu); sys = Math.sqrt(sys / (med.length - 1)); }
   var e = Math.sqrt((stat || 0) * (stat || 0) + sys * sys);
   return { v: m, e: (e > 0) ? e : null, n: med.length, stat: stat, sys: sys };
}
// (27-oct, R1b) Las rejillas de Boin EN DOMINIO con la banda de 1 σ entera (mediana − std) por encima del techo de su modelo
// (CC_SCI.BOIN_GRID_MAX_GA) o de la edad del Universo: la red extrapola. Devuelve sus nombres ([] si ninguna).
// Costuras: «sci-nogridcap» no mira techos (lo de antes); «sci-gridcap0» sin la tolerancia de 1 σ (HD 22879 pierde su edad).
function ccBoinGridsOver(grids) {
   var out = [];
   if (!grids || ccSciBroken("sci-nogridcap")) return out;
   for (var i = 0; i < grids.length; ++i) {
      var g = grids[i];
      if (!g || !g.inDomain || !ccIsNum(g.median) || !(g.median > 0)) continue;
      var top = CC_SCI.BOIN_GRID_MAX_GA[g.grid];
      if (!ccIsNum(top)) top = CC_SCI.UNIVERSE_GA;
      var sd = (ccIsNum(g.std) && g.std > 0 && !ccSciBroken("sci-gridcap0")) ? g.std : 0;
      if (g.median - sd > Math.min(top, CC_SCI.UNIVERSE_GA)) out.push(g.grid);
   }
   return out;
}

// ---------------------------------------------------------------------------
// POBLACIÓN: química (núcleo) + cinemática (apoyo)
// ----------------------------------------------------------------------------
// Devuelve { label, basis, agree, chem, kin, accreted, text: { en, es } }
//   label: "thin" | "thick" | "halo" | "accreted" | "disc" | "unknown"
// ---------------------------------------------------------------------------
function ccPopulation(chemClass, kin, chem, fam) {
   var out = { label: "unknown", basis: "none", agree: null, accreted: false, chem: chemClass, kin: kin };
   // (29-oct) la cinemática solo cuenta si da probabilidades (con más de un 20 % de error en la distancia no las da, csh_kinpop.js);
   // «indeterminada» = veredicto "undetermined" del modelo único (lo que antes era cls "mixed"; un kin con cls "mixed" y sin
   // veredicto, el de las pruebas de antes, se lee igual)
   var kv = (kin && kin.probs) ? kin : null;
   var c = chemClass ? chemClass.cls : "", k = kv ? kv.cls : "";
   var kb = kv ? kv.best : "";
   var kUnd = !!kv && (kv.verdict ? kv.verdict === "undetermined" : k === "mixed");
   // (29-oct) disco fino/grueso con menos de KIN_DISC_P: con solo cinemática cuenta como indeterminada («disco»)
   var kWeakDisc = !!kv && (kb === "thin" || kb === "thick") && kv.probs && (kv.probs[kb] || 0) < CC_SCI.KIN_DISC_P && !ccSciBroken("sci-weakdisc");
   if (c) {
      out.basis = kv ? "chem+kin" : "chem";
      if (c === "thin" || c === "thick") out.label = c;
      else if (c === "halo" || c === "halo-high" || c === "halo-low") out.label = "halo";
      else out.label = "disc";
      if (kv) {
         if (ccSciBroken("sci-oldagree")) {
            // (el criterio de antes, solo para ver el rojo: la más probable, aunque fuera «mezcla» con 0,53 / 0,45, contaba como acuerdo)
            var kl = kUnd ? kb : k;
            out.agree = (out.label === kl) || (out.label === "disc" && (kl === "thin" || kl === "thick"));
         } else {
            // (P2, 23-oct) de acuerdo SOLO si la cinemática da > KIN_AGREE_P a la misma población; en tensión si se lo da a otra;
            // si no, la cinemática no distingue (agree = null, kinVerdict "undecided")
            var pr = kv.probs || {}, pSame = (out.label === "disc") ? (pr.thin || 0) + (pr.thick || 0) : (pr[out.label] || 0), pOther = 0;
            for (var kp in pr) if (pr.hasOwnProperty(kp) && kp !== out.label && !(out.label === "disc" && (kp === "thin" || kp === "thick"))) pOther = Math.max(pOther, pr[kp]);
            out.kinPSame = pSame;
            if (pSame > CC_SCI.KIN_AGREE_P) { out.agree = true; out.kinVerdict = "agree"; }
            else if (pOther > CC_SCI.KIN_AGREE_P) { out.agree = false; out.kinVerdict = "tension"; }
            else { out.agree = null; out.kinVerdict = "undecided"; }
         }
      }
   } else if (kv) {
      out.basis = "kin";
      if (!kUnd && !kWeakDisc) out.label = k;
      else if (ccSciBroken("sci-mixfine")) out.label = kb;         // (lo de antes, solo para ver el rojo: la «mezcla» tomaba la más probable —0,50 / 0,50 la decidía el ruido—)
      // (27-oct, R3 de la revisión de Codex, decisión de Nino) sin química y con la cinemática «indeterminada» (29-oct: ninguna población llega a
      // P 0,5 en el modelo único; hasta el 29-oct, «mezcla» por debajo de 0,6 con el modelo de Bensby 2003):
      // «disco», sin decir fino ni grueso. Medido: 16 de las 358 estrellas con solo cinemática de los 8 campos grabados. Salvedad: si la más
      // probable es el HALO (1 de las 16: grueso 0,499 / halo 0,501) la cinemática no sabe ni si es disco, y queda «desconocida».
      else out.label = (kb === "halo") ? "unknown" : "disc";
   }
   // ¿Acretada? Lo dice la FAMILIA CINEMÁTICA (cc_dynamics.js: el árbol de Naidu et al. 2020
   // con Monte Carlo) con P >= 0,5. Si la química dice halo in situ con claridad (α alto,
   // P >= 0,84) no se le pone la etiqueta: se avisa de la tensión (familia vs química).
   // (Sustituye a la regla del 14-oct por química + ventana de Lz: la familia usa la órbita.)
   out.family = fam || null;
   if (fam && fam.accreted && fam.p >= CC_SCI.FAM_P) {
      var chemInsitu = !!(chemClass && chemClass.pHigh !== null && chemClass.pHigh >= 0.84 && chemClass.cls !== "thin");
      if (chemInsitu) out.famTension = true;
      else { out.accreted = true; out.label = "accreted"; out.basis = (out.basis === "none") ? "kin" : out.basis; }
   }
   return out;
}

// (24-oct, revisión de Gemini H5) LA GALAXIA NATAL de una estrella: la familia acretada que se ILUMINA en las líneas de tiempo (la de la ventana,
// ccPaintTimeline, y la del vídeo de II, ccJourneyTimeline) y que rotula «← galaxia natal». UNA sola regla para las dos: la estrella ES acretada
// (pop.accreted, que ya exige familia acretada con P >= FAM_P y química que no diga in situ). Con `famTension` (la órbita es de una familia acretada
// pero la química dice α alto in situ: pop.accreted === false) NO hay galaxia natal que iluminar: la ficha avisa de la tensión, la línea de tiempo
// no afirma. -> clave de la familia ("gse", "sgr", "sequoia", "helmi", …) o "". ROJO «homefam» (T25): la regla de antes en la ventana (solo la
// familia, sin mirar la población).
function ccHomeFamily(s) {
   if (!(s && s.fam && s.fam.accreted && s.fam.p >= CC_SCI.FAM_P)) return "";
   if (!ccSciBroken("homefam") && !(s.pop && s.pop.accreted === true)) return "";
   return s.fam.best || "";
}
// (30-oct, D1-H3, decisión C de Nino) ¿SE PUEDE AFIRMAR EL ORIGEN? Solo con P ≥ FAM_FIRM_P; por debajo, «compatible». P es la fracción de sorteos de los errores que caen en esa familia
// (su estabilidad), no la probabilidad de haber nacido allí: las familias se solapan. Costura roja «sci-firmorigin»: firme siempre, lo de antes.
function ccFamFirm(fam) { return !!fam && ccIsNum(fam.p) && (fam.p >= CC_SCI.FAM_FIRM_P || ccSciBroken("sci-firmorigin")); }

// Rango de edades TÍPICO de una población (Xiang & Rix 2022, Nature 603, 599:
// el disco grueso se forma de ~13 a ~8 Ga; el fino, de ~8 Ga a hoy; el halo
// in situ y lo acretado, antes de ~10 Ga). NO es una edad de la estrella.
var CC_POP_AGES = { thin: [0, 8], thick: [8, 13], halo: [10, 13.5], accreted: [10, 13.5], disc: [0, 13] };

// ¿La edad CHOCA con su familia? (C2, 23-oct-2026; docs/contradicciones_ficha.md). Una estrella acretada nació en su galaxia ANTES de
// que esta cayera en la Vía Láctea: si hasta el extremo ALTO de su edad es más joven que la fecha MÁS RECIENTE publicada para esa caída
// (`floor` de CC_MERGERS), la edad y la familia no pueden ser las dos ciertas. No se corrige nada (no se sabe cuál falla): se avisa.
// Medido: de las 6 acretadas con edad de los campos grabados, 4 salen < 8 Ga, todas gigantes con la edad de Kordopatis+23.
// (P5, 23-oct) Todas las familias con fecha de fusión CON FUENTE (CC_MERGERS); las demás, no. -> null | { fam, floor, hi, v, src }
// LAS FECHAS DE FUSIÓN (Ga atrás; `floor` = el extremo más reciente de las estimaciones citadas: así solo se avisa si la estrella es más
// joven que TODAS). Solo las familias del producto con fecha publicada:
//   gse     Belokurov et al. 2018 (MNRAS 478, 611): «between 8 and 11 Gyr ago»; Helmi et al. 2018 (Nature 563, 85): ~10; Kruijssen et al.
//           2020 (MNRAS 498, 2472, E-MOSAICS, de sus cúmulos globulares): 9,1 ± 0,7 -> 8,0
//   sequoia Kruijssen et al. 2020: 9,4 (+0,4/−0,5) -> 8,9 (una sola estimación)
//   helmi   Koppelman et al. 2019 (A&A 625, A5, N-cuerpos): «accreted 5–8 Gyr ago»; Kruijssen et al. 2020: 10,1 (+0,7/−0,9) -> 5,0
// FUERA, a sabiendas: Sagitario (Kruijssen+20: 6,8 ± 1,1; Ruiz-Lara et al. 2020: pasos a 5,7, 1,9 y 1,0 Ga) sigue cayendo y formando
// estrellas hoy, así que una joven no contradice nada; Arjuna, I'itoi, Thamnos, Wukong y el halo retrógrado mezclado: sin fecha de
// fusión publicada encontrada (23-oct). Kraken/Heracles (Kruijssen+20: 10,9; Horta et al. 2021) no es una familia de este producto.
var CC_MERGERS = {
   // (R3/18b, 26-oct: las `ref` se GUARDAN con punto decimal y «Ga» y se dicen en cada idioma con ccAgeLocalize —9,4 Ga / 9.4 Gyr—; antes, con coma
   //  y «Ga» fijos, la placa inglesa decía «9,4 Ga»)
   gse:     { from: 11.0, floor: 8.0, ref: "Belokurov et al. 2018 (8–11 Ga); Helmi et al. 2018 (~10 Ga); Kruijssen et al. 2020 (9.1 ± 0.7 Ga)" },
   sequoia: { from: 9.8,  floor: 8.9, ref: "Kruijssen et al. 2020 (9.4 +0.4/−0.5 Ga)" },
   helmi:   { from: 10.8, floor: 5.0, ref: "Koppelman et al. 2019 (5–8 Ga); Kruijssen et al. 2020 (10.1 +0.7/−0.9 Ga)" }
};
function ccAgeFamTension(age, pop, fam) {
   if (!age || !ccIsNum(age.v) || !pop || pop.label !== "accreted" || !fam || ccSciBroken("sci-noagetension")) return null;
   var floor = null;
   if (ccSciBroken("sci-oldmergers")) {
      // (lo de antes, solo para ver el rojo: Gaia-Enceladus sola, con el final de su banda de CC_TIMELINE)
      if (fam.best !== "gse") return null;
      floor = 9.0;
   } else if (CC_MERGERS[fam.best]) floor = CC_MERGERS[fam.best].floor;
   var hi = ccIsNum(age.hi) ? age.hi : (ccIsNum(age.e) ? age.v + age.e : age.v);
   if (!ccIsNum(floor) || !(hi < floor)) return null;
   return { fam: fam.best, floor: floor, hi: hi, v: age.v, src: age.src };
}

// ---------------------------------------------------------------------------
// HUELLA NUCLEOSINTÉTICA y GEMELAS SOLARES
// ---------------------------------------------------------------------------
function ccFingerprint(chem) {
   var out = { tags: [] };
   if (!chem) return out;
   var el = chem.el || {}, eu = el.Eu ? el.Eu.v : null, ba = el.Ba ? el.Ba.v : null, c = el.C ? el.C.v : null;
   var baeu = (ccIsNum(ba) && ccIsNum(eu)) ? ba - eu : null;
   if (ccIsNum(eu) && ccIsNum(baeu) && baeu < 0) {
      if (eu > CC_SCI.R2_EU) out.tags.push("r-II");
      else if (eu >= CC_SCI.R1_EU) out.tags.push("r-I");
   }
   if (ccIsNum(ba) && ba > CC_SCI.S_BA && ccIsNum(baeu) && baeu > CC_SCI.S_BAEU) out.tags.push("s");
   if (ccIsNum(c) && c > CC_SCI.CEMP_C && chem.feh && chem.feh.v < -1) out.tags.push("CEMP");
   out.baeu = baeu;
   return out;
}
function ccSolarTwin(chem) {
   if (!chem || !chem.feh || !ccIsNum(chem.teff) || !ccIsNum(chem.logg)) return false;
   return Math.abs(chem.teff - CC_SCI.SUN_TEFF) <= CC_SCI.TWIN_DTEFF && Math.abs(chem.logg - CC_SCI.SUN_LOGG) <= CC_SCI.TWIN_DLOGG &&
          Math.abs(chem.feh.v) <= CC_SCI.TWIN_DFEH;
}

// ---------------------------------------------------------------------------
// CHEMICAL TAGGING
// ----------------------------------------------------------------------------
// Solo DENTRO de un survey (los ceros de cada survey difieren ~0,05 dex).
// stars: [ { idx, recs: { survey: rec }, teff, logg, kin } ]
// Devuelve { survey, tested, compatible, rate, pairs: [ {a, b, chi2, n, comove} ],
//            groups: [ { members: [idx], survey, feh, comove } ] }
// ---------------------------------------------------------------------------
// (27-oct, R7 de la revisión de Codex) Cuantil 0,95 de χ²_ν, EXACTO para ν = 1..40 (Wilson-Hilferty se desvía justo con pocos grados de
// libertad, que son los de aquí: TAG_MIN_ELEMS elementos). Calculados con la gamma incompleta regularizada por bisección y contrastados
// con las tablas de χ² (ν=1 3,841459 · 2 5,991465 · 10 18,307038 · 20 31,410433 · 30 43,772972 · 40 55,758479). ROJO «sci-chi2wh»: la
// aproximación de antes para todo ν.
var CC_CHI2_Q95 = [0, 3.841459, 5.991465, 7.814728, 9.487729, 11.070498, 12.591587, 14.067140, 15.507313, 16.918978, 18.307038,
   19.675138, 21.026070, 22.362032, 23.684791, 24.995790, 26.296228, 27.587112, 28.869299, 30.143527, 31.410433,
   32.670573, 33.924438, 35.172462, 36.415029, 37.652484, 38.885139, 40.113272, 41.337138, 42.556968, 43.772972,
   44.985343, 46.194260, 47.399884, 48.602367, 49.801850, 50.998460, 52.192320, 53.383541, 54.572228, 55.758479];
function ccChi2Quantile95(nu) {
   // devuelve el cuantil 0,95 de χ²_ν DIVIDIDO por ν (se compara con el χ² reducido)
   if (nu >= 1 && nu <= 40 && nu === Math.floor(nu) && !ccSciBroken("sci-chi2wh")) return CC_CHI2_Q95[nu] / nu;
   // Wilson-Hilferty (ν > 40, o ν no entero)
   var a = 2 / (9 * nu), z = 1.6448536;
   return Math.pow(1 - a + z * Math.sqrt(a), 3);
}
function ccPairChi2(ra, rb) {
   var n = 0, s = 0, f2 = CC_SCI.TAG_FLOOR * CC_SCI.TAG_FLOOR;
   function add(va, ea, vb, eb) {
      if (!ccIsNum(va) || !ccIsNum(vb)) return;
      var e1 = ccIsNum(ea) ? ea : 0.1, e2 = ccIsNum(eb) ? eb : 0.1, d = va - vb;
      s += d * d / (e1 * e1 + e2 * e2 + f2); ++n;
   }
   if (ra.feh && rb.feh) add(ra.feh.v, ra.feh.e, rb.feh.v, rb.feh.e);
   if (ra.el && rb.el) for (var e in ra.el) if (ra.el.hasOwnProperty(e) && !CC_TAG_EXCLUDE[e] && rb.el[e])
      add(ra.el[e].v, ra.el[e].e, rb.el[e].v, rb.el[e].e);
   return { n: n, chi2: n > 0 ? s / n : null };
}
function ccComove(a, b) {
   if (!a || !b || !a.kin || !b.kin) return null;
   var u = a.kin.uvw, v = b.kin.uvw;
   var d = Math.sqrt((u[0] - v[0]) * (u[0] - v[0]) + (u[1] - v[1]) * (u[1] - v[1]) + (u[2] - v[2]) * (u[2] - v[2]));
   return d <= CC_SCI.TAG_COMOVE_KMS * Math.sqrt(3) ? d : false;
}
var CC_TAG_ALLPAIRS_MAX = 1500;     // miembros con cinematica por encima de los cuales no se cuentan todos los pares de un grupo (O(n²))
function ccTagging(stars, survey) {
   var out = { survey: survey, tested: 0, compatible: 0, rate: 0, pairs: [], groups: [], candidates: 0 };
   var c = [], sbyIdx = {};
   for (var si = 0; si < stars.length; ++si) sbyIdx[stars[si].idx] = stars[si];
   for (var i = 0; i < stars.length; ++i) {
      var r = stars[i].recs ? stars[i].recs[survey] : null;
      if (r && r.feh && ccIsNum(r.feh.v)) c.push({ s: stars[i], r: r });
   }
   out.candidates = c.length;
   var parent = [];
   for (i = 0; i < c.length; ++i) parent.push(i);
   function find(x) { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
   for (i = 0; i < c.length; ++i) {
      for (var j = i + 1; j < c.length; ++j) {
         var A = c[i], B = c[j];
         if (ccIsNum(A.r.teff) && ccIsNum(B.r.teff) && Math.abs(A.r.teff - B.r.teff) > CC_SCI.TAG_DTEFF) continue;
         if (ccIsNum(A.r.logg) && ccIsNum(B.r.logg) && Math.abs(A.r.logg - B.r.logg) > CC_SCI.TAG_DLOGG) continue;
         var q = ccPairChi2(A.r, B.r);
         if (q.n < CC_SCI.TAG_MIN_ELEMS) continue;
         ++out.tested;
         if (q.chi2 <= ccChi2Quantile95(q.n)) {
            ++out.compatible;
            var cm = ccComove(A.s, B.s);
            out.pairs.push({ a: A.s.idx, b: B.s.idx, chi2: q.chi2, n: q.n, comove: cm });
            parent[find(i)] = find(j);
         }
      }
   }
   out.rate = out.tested > 0 ? out.compatible / out.tested : 0;
   var byRoot = {};
   for (i = 0; i < c.length; ++i) { var rt = find(i); (byRoot[rt] = byRoot[rt] || []).push(i); }
   for (var k in byRoot) if (byRoot.hasOwnProperty(k) && byRoot[k].length >= 2) {
      var mem = byRoot[k], fe = [], idx = [];
      for (i = 0; i < mem.length; ++i) { fe.push(c[mem[i]].r.feh.v); idx.push(c[mem[i]].s.idx); }
      out.groups.push({ members: idx, survey: survey, feh: ccMedian(fe) });
   }
   // co-movimiento de grupo: fracción de pares del grupo que se mueven juntos
   for (i = 0; i < out.groups.length; ++i) {
      var G = out.groups[i], set = {}, nC = 0, nK = 0;
      for (j = 0; j < G.members.length; ++j) set[G.members[j]] = true;
      for (j = 0; j < out.pairs.length; ++j) {
         var P = out.pairs[j];
         if (set[P.a] && set[P.b]) { if (P.comove === null) continue; ++nK; if (P.comove !== false) ++nC; }
      }
      G.comoveFrac = nK > 0 ? nC / nK : null;
      // (30-oct-2026, M2-H3 de Codex) `comoveFrac` cuenta solo los pares QUIMICAMENTE COMPATIBLES del grupo (los de `out.pairs`), y la ficha decia «N de M pares se
      // mueven juntos» sobre esa base sin decirlo: M 67 GALAH, «4 717 de 6 398» = 74 %, pero sobre TODOS los pares del grupo es 51 %. Aqui la cuenta de la ficha:
      // todos los pares de miembros con cinematica (`pairsAll`) y cuantos se mueven juntos (`pairsAllC`). null = grupo demasiado grande para el O(n²) (la ficha cae
      // a la base de antes, rotulada «compatibles»).
      G.pairsAll = null; G.pairsAllC = null;
      var kinM = [];
      for (j = 0; j < G.members.length; ++j) { var ms = sbyIdx[G.members[j]]; if (ms && ms.kin && ms.kin.uvw) kinM.push(ms); }
      if (kinM.length <= CC_TAG_ALLPAIRS_MAX) {
         var aN = 0, aC = 0;
         for (j = 0; j < kinM.length; ++j) for (var j2 = j + 1; j2 < kinM.length; ++j2) { var cm2 = ccComove(kinM[j], kinM[j2]); if (cm2 === null) continue; ++aN; if (cm2 !== false) ++aC; }
         G.pairsAll = aN; G.pairsAllC = aC;
      }
   }
   out.groups.sort(function(a, b) { return b.members.length - a.members.length; });
   return out;
}

// ---------------------------------------------------------------------------
// LA LÍNEA DE TIEMPO DE LA VÍA LÁCTEA (Ga = miles de millones de años atrás)
// ----------------------------------------------------------------------------
// Rangos aproximados y su fuente; se pintan como bandas, no como fechas exactas.
var CC_TIMELINE = [
   { key: "bigbang", from: 13.8, to: 13.8, en: "Big Bang", es: "Big Bang", ref: "Planck 2018" },
   { key: "halo", from: 13.5, to: 11.5, en: "Proto-Galaxy & in-situ halo", es: "Protogalaxia y halo in situ", short: ["Proto-Galaxy", "Protogalaxia"], ref: "Belokurov & Kravtsov 2022; Xiang & Rix 2022" },
   { key: "thick", from: 13.0, to: 8.0, en: "Thick disc (high-α)", es: "Disco grueso (α alto)", short: ["Thick disc", "Disco grueso"], ref: "Xiang & Rix 2022" },
   // (P5, 23-oct: la banda va de 11 a 8 Ga, la de Belokurov et al. 2018; era 11–9. La misma fecha que CC_MERGERS.gse)
   { key: "gse", from: 11.0, to: 8.0, en: "Gaia-Enceladus merger", es: "Fusión con Gaia-Enceladus", short: ["Gaia-Enceladus", "Gaia-Enceladus"], ref: "Belokurov et al. 2018; Helmi et al. 2018" },
   { key: "thin", from: 8.0, to: 0.0, en: "Thin disc (low-α)", es: "Disco fino (α bajo)", short: ["Thin disc", "Disco fino"], ref: "Xiang & Rix 2022" },
   { key: "sgr", from: 6.0, to: 0.0, en: "Sagittarius passages", es: "Pasos de Sagitario", short: ["Sagittarius", "Sagitario"], ref: "Ruiz-Lara et al. 2020" },
   { key: "sun", from: 4.57, to: 4.57, en: "The Sun is born", es: "Nace el Sol", ref: "Bouvier & Wadhwa 2010" }
];
// (24-oct, B2 = a de Nino) Las otras fusiones con fecha publicada, Sequoia y las corrientes de Helmi (CC_MERGERS), como episodios de la
// línea de tiempo: la MISMA lista para la ventana (cc_paint.js), la línea del vídeo y los episodios en curso del reloj (cc_journey*.js),
// para que no se encienda una cosa en un sitio y otra en otro. Llevan `merger: true`: el titular de la placa del vídeo sigue siendo un
// episodio de CC_TIMELINE (Helmi dura 10,8–5,0 Ga y se lo comería entero); ellas se encienden y se nombran en «También: …».
// (24-oct, B2b = sí de Nino) UNA excepción: Sequoia (`headline: true`) es el TITULAR mientras dura (CC_MERGERS.sequoia: 9,8–8,9 Ga, las fechas
// no se repiten aquí); Gaia-Enceladus pasa a «también: …» en ese tramo. Helmi NO (10,8–5,0 Ga: se comería a Gaia-Enceladus). Quién es el
// titular lo decide ccJourneyEpisodes (cc_journey.js), que lo usan la placa del vídeo, la vista previa de la ventana y la de III.
// CabraStarAnalysis (línea de tiempo de 93 px) no las pide. -> [ { key, from, to, en, es, short, ref, merger } ]
function ccMergerEvents() {
   var out = [], mk = [["sequoia", "Sequoia merger", "Fusión con Sequoia", ["Sequoia", "Sequoia"]], ["helmi", "Helmi streams (merger)", "Corrientes de Helmi (fusión)", ["Helmi", "Helmi"]]];
   if (typeof CC_MERGERS === "undefined") return out;
   for (var mi = 0; mi < mk.length; ++mi) {
      var MG = CC_MERGERS[mk[mi][0]];
      if (MG && ccIsNum(MG.from) && ccIsNum(MG.floor)) out.push({ key: mk[mi][0], from: MG.from, to: MG.floor, en: mk[mi][1], es: mk[mi][2], short: mk[mi][3], ref: MG.ref, merger: true, headline: (mk[mi][0] === "sequoia") });
   }
   return out;
}

// ---------------------------------------------------------------------------
// FORMATO Y BIOGRAFÍA (EN / ES)
// ---------------------------------------------------------------------------
function ccFmt(x, d) {
   if (!ccIsNum(x)) return "—";
   var s = x.toFixed(d === undefined ? 2 : d);
   if (s === "-0.00" || s === "-0.0" || s === "-0") s = s.substring(1);
   return s;
}
function ccFmtSigned(x, d) {
   if (!ccIsNum(x)) return "—";
   var s = ccFmt(x, d);
   return (x >= 0 && s.charAt(0) !== "-") ? "+" + s : s.replace("-", "−");
}
// ---------------------------------------------------------------------------
// EDADES E INSTANTES: TODO EN Ga (R3, decisión de Nino 26-oct: «hace 0,2 Ga», nunca «hace 200 Ma»). UNA sola cadena de funciones:
// la placa, el reloj de II y de III, la línea de tiempo, el cursor, la ficha y los ejes pasan por aquí.
//   ccAgeUnit(lang)            «Ga» (es) · «Gyr» (en)
//   ccAgeNum(ga, lang)         el número: ≥ 1 Ga, un decimal («9,3», «12,5»); de 0,1 a 1, dos («0,35»); por debajo de 0,1, tres («0,047»),
//                              sin ceros finales por debajo de 1 Ga («0,2», «0,05»). Coma en castellano, PUNTO en inglés.
//   ccAgeBare(ga, lang)        «9,3 Ga» · «9.3 Gyr»
//   ccAgeAgo(ga, lang)         «hace 9,3 Ga» · «9.3 Gyr ago»        (sin «hoy»: eso lo decide ccAgeAgoText, más abajo)
//   ccAgeLocalize(txt, lang)   un texto escrito con punto decimal y «Ga» (las referencias) → su idioma (coma y Ga / punto y Gyr)
// Por qué esos decimales: la regla de antes en Ma daba 10 Ma de resolución por encima de 100 Ma y 1 Ma por debajo; con 2 y 3 decimales en Ga
// es la MISMA resolución (0,01 y 0,001 Ga), así que III no pierde nada. Y el último paso de «hoy» (0,5 Ma = 0,0005 Ga) sale «0,001».
// Solo se cambian EDADES e INSTANTES. Las DURACIONES («órbitas: 420 Ma») y las VELOCIDADES («10 Ma por segundo») siguen en Ma/Myr: no son una edad.
// ---------------------------------------------------------------------------
function ccAgeUnit(lang) { return lang === "es" ? "Ga" : "Gyr"; }
function ccAgeNum(ga, lang) {
   if (!ccIsNum(ga)) return "—";
   var a = Math.abs(ga), d = (a >= 1) ? 1 : (a >= 0.1 ? 2 : 3), s = a.toFixed(d);
   if (a < 1 && parseFloat(s) >= 1) s = a.toFixed(1);                 // 0,996 → «1,0», no «1»
   else if (a < 1) { if (!(parseFloat(s) > 0) && a > 0) s = "0.001"; s = s.replace(/0+$/, "").replace(/\.$/, ""); }
   // (27-oct, R7) el signo se decide ANTES de cambiar el punto por la coma: parseFloat("0,5") es 0 y se comía el «−» de las edades negativas
   // menores de 1 Ga en castellano (−0,5 → «0,5»). ROJO «agesign»: parseFloat sobre la cadena ya con coma.
   var neg = (ga < 0 && parseFloat(s) !== 0);
   if (ccAgeBroken("agecomma") || lang === "es") s = s.replace(".", ",");      // (ROJO «agecomma»: la coma también en inglés, como la placa de antes)
   if (ccAgeBroken("agesign")) neg = (ga < 0 && parseFloat(s) !== 0);
   return (neg ? "−" : "") + s;
}
function ccAgeBare(ga, lang) { return ccAgeNum(ga, lang) + " " + ccAgeUnit(lang); }
function ccAgeAgo(ga, lang) { return lang === "es" ? "hace " + ccAgeBare(ga, lang) : ccAgeBare(ga, lang) + " ago"; }
function ccAgeLocalize(txt, lang) {
   var s = String(txt || "");
   if (ccAgeBroken("refraw")) return s;      // (ROJO «refraw»: la referencia tal como está guardada, sin pasar por su idioma)
   if (lang === "es") return s.replace(/(\d)\.(\d)/g, "$1,$2");
   return s.replace(/\bGa\b/g, "Gyr");
}
function ccAgeBroken(k) { return (typeof CC_BREAK === "string") && CC_BREAK.indexOf(k) >= 0; }
// «HOY»: en el final (fase «hold») o a menos de CC_AGE_TODAY_MA de hoy. 0,5 Ma = donde la cifra con 3 decimales («hace 0,001 Ga», 1 Ma) ya sería «0,000» y donde la regla
// «Tiempo» de III ya salta a 0 (ccGalaxyUI.setTime); era un literal suelto, 5 Ma en II (24-oct, H7: un solo umbral). ROJO «todayold»: el literal de antes en II (5 Ma).
var CC_AGE_TODAY_MA = 0.5;
function ccAgeIsToday(phase, TGa) { return phase === "hold" || !(TGa * 1000 >= (ccAgeBroken("todayold") ? 5 : CC_AGE_TODAY_MA)); }
// El instante de un reloj, la ÚNICA función que lo pone en un texto: «hace 9,3 Ga» · «0.2 Gyr ago» · «hoy» / «today» (R3, 26-oct: sin «Ma»; «hace 0,2 Ga» en II y en III).
// TGa en Ga; lang "es" | "en" (sin lang, el del diálogo); phase "run" (de fábrica) | "hold" (el final del vídeo: siempre «hoy»).
// ROJO «agema»: la regla de antes (Ma enteros por debajo de 1 Ga).
function ccAgeAgoText(TGa, lang, phase) {
   var L = lang || ((typeof CC_LANG !== "undefined" && CC_LANG === "es") ? "es" : "en");
   if (ccAgeIsToday(phase || "run", TGa)) return (L === "es") ? "hoy" : "today";
   if (ccAgeBroken("agema") && TGa < 1) { var m = (TGa >= 0.1) ? Math.round(TGa * 100) * 10 : Math.round(TGa * 1000); return (L === "es") ? "hace " + m + " Ma" : m + " Myr ago"; }
   return ccAgeAgo(TGa, L);
}
// LA NOTA DE LA POBLACIÓN (P2, 23-oct): qué dicen juntas la química y la cinemática. La pinta la ficha (src/ui/cc_paint.js, junto a
// la población): «química y cinemática de acuerdo» solo si la cinemática da > CC_SCI.KIN_AGREE_P a la misma población.
function ccPopNote(pop, lang) {
   var E = (lang === "es");
   if (!pop) return "";
   if (pop.basis === "chem+kin") {
      if (pop.agree === true) return E ? "química y cinemática de acuerdo" : "chemistry and kinematics agree";
      if (pop.agree === false) return E ? "química y cinemática en tensión" : "chemistry and kinematics disagree";
      return E ? "la cinemática no distingue" : "the kinematics does not decide";
   }
   if (pop.basis === "kin") return E ? "solo cinemática" : "kinematics only";
   if (pop.basis === "chem") return E ? "solo química" : "chemistry only";
   return "";
}
var CC_POP_NAME = {
   en: { thin: "thin disc", thick: "thick disc", halo: "halo", accreted: "accreted halo (Gaia-Enceladus-like)", disc: "disc", unknown: "unknown population" },
   es: { thin: "disco fino", thick: "disco grueso", halo: "halo", accreted: "halo acretado (tipo Gaia-Enceladus)", disc: "disco", unknown: "población desconocida" }
};
// La frase de la biografía.
// UNA EDAD QUE NO SE PUEDE DAR COMO «valor ± error» (encargo del coordinador, 15-oct: «se formó hace 2,1 ± 4,2 Ga» lleva a
// edades negativas y no dice nada): las ORIENTATIVAS (nivel C, enanas) y las de error mayor que la mitad del valor se dan como
// INTERVALO en llano («edad muy incierta: entre 0 y 6,3 Ga»). La usan la biografia, el relato, la ficha y la linea de tiempo.
function ccAgeVague(a) { return !!(a && (a.tier === "C" || !(a.v > 0) || !(a.e <= 0.5 * a.v))); }
function ccAgeVeryUncertain(a) { return !!(a && (!(a.v > 0) || !(a.e <= 0.5 * a.v))); }
function ccAgeRange(a) {
   var lo = ccIsNum(a.lo) ? a.lo : a.v - a.e, hi = ccIsNum(a.hi) ? a.hi : a.v + a.e;
   // (27-oct, R1) nunca un inicio mayor que el final: si todo el intervalo cae por encima del Universo, queda en el borde ([13,8, 13,8]),
   // no al revés («entre 15,2 y 13,8 Ga»). ccAdoptAge ya rechaza esas edades; esto cubre cualquier otra entrada.
   var top = Math.min(CC_SCI.UNIVERSE_GA, hi), bot = Math.max(0, lo);
   if (ccSciBroken("sci-nouniv")) return [bot, top];
   return [Math.min(bot, top), top];
}
// «entre 0 y 6,3 Ga» · «between 0 and 6.3 Gyr»
function ccAgeRangeText(a, lang) {
   var E = (lang === "es"), r = ccAgeRange(a);
   function f(x) { var t = (x < 0.05) ? "0" : x.toFixed(1); return E ? t.replace(".", ",") : t; }
   return (E ? "entre " : "between ") + f(r[0]) + (E ? " y " : " and ") + f(r[1]) + " " + ccAgeUnit(lang);
}
// (27-oct, R1b) ¿Su banda llega a la edad del Universo? (ccAdoptAge la cortó en 13,8: `capped`). Entonces nunca «v ± e».
// (27-oct, H-1 de Codex C1, verificado) tambien si el «v ± e» que se ESCRIBE (una cifra) pasaria de 13,8 por el redondeo: 13,25 ± 0,55 → «13,3 ± 0,6» (13,9)
function ccAgeCapped(a) {
   if (!a || ccSciBroken("sci-nouniv")) return false;
   return !!a.capped || (ccIsNum(a.v) && ccIsNum(a.e) && parseFloat(a.v.toFixed(1)) + parseFloat(a.e.toFixed(1)) > CC_SCI.UNIVERSE_GA + 1e-9);
}
// LA EDAD EN UNA LÍNEA, la misma en el detalle de la ficha, la línea de tiempo, el viaje y «otras estimaciones» (27-oct, R1b):
//   orientativa o muy incierta → «entre 0 y 6,3 Ga» · banda cortada por el Universo → «12,5 Ga (10,5–13,8)» · si no → «4,1 ± 0,6 Ga»
function ccAgeText(a, lang) {
   if (!a || !ccIsNum(a.v)) return "—";
   var E = (lang === "es");
   function f(x) { var t = (Math.abs(x) < 0.05) ? "0" : x.toFixed(1); return E ? t.replace(".", ",") : t; }
   if (ccAgeVague(a)) return ccAgeRangeText(a, lang);
   if (ccAgeCapped(a)) { var r = ccAgeRange(a); return f(a.v) + " " + ccAgeUnit(lang) + " (" + f(r[0]) + "–" + f(r[1]) + ")"; }
   return f(a.v) + " ± " + f(a.e) + " " + ccAgeUnit(lang);
}
// (E3) el aviso de una edad ADOPTADA con bandera blanda (Anders+23 fuera del conjunto de entrenamiento): lo que dice la ficha bajo la edad
function ccAgeWarnText(a, lang) {
   if (!a || !a.warn) return "";
   var E = (lang === "es"), azul = /BLUER/.test(a.warn), rojo = /REDDER/.test(a.warn);
   var side = azul ? (E ? "más azul" : "bluer") : (rojo ? (E ? "más roja" : "redder") : "");
   if (azul && rojo) side = E ? "en el borde" : "at the edge";
   return E ? "⚠ " + side + " que las estrellas de entrenamiento: edad menos fiable" : "⚠ " + side + " than the training stars: less reliable age";
}
// Por qué no se adoptó una edad (la línea «otras estimaciones» de la ficha: «Boin+26 17,2 ✗ fuera de sus modelos»)
// (28-oct) cifra y unidad con espacio duro (U+00A0, escrito \u00a0): la captura partía «1–2 / M☉» entre dos líneas (ccWrap no parte por él).
function ccAgeRejectWhyText(why, lang) {
   var E = (lang === "es");
   var T = { "flame-metallicity": ["solar model", "modelo solar"], "no-error": ["no error", "sin error"], "no-value": ["no value", "sin valor"],
             "flagged": ["flagged by the catalogue", "marcada por el catálogo"], "older-than-universe": ["older than the Universe", "más vieja que el Universo"],
             "beyond-model-ages": ["beyond its models' ages", "fuera de las edades de sus modelos"],
             "flame-giant-mass": ["giant outside 1–2\u00a0M☉", "gigante fuera de 1–2\u00a0M☉"], "flame-giant-young": ["giant younger than 1\u00a0Gyr", "gigante de menos de 1\u00a0Ga"] };
   return T[why] ? T[why][E ? 1 : 0] : String(why || "");
}
function ccBiography(star, lang, short) {      // short: sin las advertencias (la ficha las dice en el relato)
   var L = (lang === "es") ? "es" : "en", P = CC_POP_NAME[L];
   var pop = star.pop ? star.pop.label : "unknown", age = star.age ? star.age.adopted : null;
   var where = P[pop] || P.unknown;
   // la acretada, con el nombre de su familia cinemática (cc_dynamics.js)
   if (pop === "accreted" && star.fam && typeof CC_FAM_NAME !== "undefined" && CC_FAM_NAME[L][star.fam.best])
      where = ccFamFirm(star.fam) ? (L === "es" ? "halo acretado (" : "accreted halo (") + CC_FAM_NAME[L][star.fam.best] + ")" :
                                    (L === "es" ? "halo (órbita compatible con " : "halo (orbit compatible with ") + CC_FAM_NAME[L][star.fam.best] + ")";      // (30-oct, decisión C)
   var s = "";
   if (age && ccAgeVague(age)) {
      // (orientativa o muy incierta: el intervalo, no «valor ± error»)
      var vt = ccAgeVeryUncertain(age) ? (L === "es" ? "Edad muy incierta" : "Very uncertain age") : (L === "es" ? "Edad solo orientativa" : "Only an indicative age");
      s = vt + ": " + ccAgeRangeText(age, L);
      if (pop !== "unknown") s += (L === "es") ? ("; probablemente del " + where) : ("; probably from the " + where);
      s += ".";
   } else if (age) {
      var v = ccFmt(age.v, 1), e = ccFmt(age.e, 1);
      if (L === "es") { v = v.replace(".", ","); e = e.replace(".", ","); }   // prosa en castellano: coma decimal (como el relato)
      if (ccAgeCapped(age)) {
         // (27-oct, R1b) su banda llega a la edad del Universo: el valor y el intervalo hasta 13,8, nunca «v ± e» (pasaría de 13,8)
         var cr = ccAgeRange(age), c0 = ccFmt(cr[0], 1), c1 = ccFmt(cr[1], 1);
         if (L === "es") s = "Probablemente se formó hace " + v + " Ga (entre " + c0.replace(".", ",") + " y " + c1.replace(".", ",") + ")";
         else s = "Probably formed " + v + " Gyr ago (between " + c0 + " and " + c1 + ")";
      } else if (L === "es") s = "Probablemente se formó hace " + v + " ± " + e + " Ga";
      else s = "Probably formed " + v + " ± " + e + " Gyr ago";
      if (pop !== "unknown") s += (L === "es") ? (", en el " + where) : (", in the " + where);
      s += ".";
      var bvw = (!short && age.tier === "C") ? ccAgeVagueWhy(age, star.chem ? star.chem.logg : null) : "";
      if (bvw === "flame-giant") s += (L === "es") ? " Edad indicativa: FLAME de Gaia en una estrella que el propio catálogo marca como gigante, con un 20-30 % de incertidumbre." :
                                                     " Indicative age: Gaia FLAME on a star the catalogue itself flags as a giant, with a 20-30% uncertainty.";
      else if (bvw) s += (bvw === "kord-giant") ?
                                                ((L === "es") ? " Edad indicativa: Kordopatis et al. 2023 en una gigante, que en el cúmulo M 67 sale demasiado vieja." : " Indicative age: Kordopatis et al. 2023 on a giant, which comes out too old in the cluster M 67.") :
                                                ((L === "es") ? " Edad indicativa: es una enana de secuencia principal, donde las isócronas apenas distinguen edades." :
                                                " Indicative age: a main-sequence dwarf, where isochrones barely separate ages.");
      if (!short && age.edge) s += (L === "es") ? " (La edad toca el límite de los modelos: tómala como «de las más viejas».)" : " (The age hits the model limit: read it as \u201camong the oldest\u201d.)";
   } else if (pop !== "unknown") {
      var r = CC_POP_AGES[pop] || null;
      if (L === "es") s = "Pertenece probablemente al " + where + "; sin edad medida." + (r ? " Lo típico de esa población es " + r[0] + "–" + r[1] + " Ga (rango de la población, no una edad de esta estrella)." : "");
      else s = "Probably belongs to the " + where + "; no measured age." + (r ? " That population typically formed " + r[0] + "–" + r[1] + " Gyr ago (a population range, not this star's age)." : "");
   } else {
      s = (L === "es") ? "Sin datos suficientes para situarla en la historia de la Galaxia." : "Not enough data to place it in the history of the Galaxy.";
   }
   // (C2, 23-oct) la edad y la familia no pueden ser las dos ciertas: se dice (ccAgeFamTension)
   // (P5) con el nombre de SU familia (Gaia-Enceladus, Sequoia, corrientes de Helmi: CC_MERGERS)
   if (!short && age && star.pop && star.pop.ageTension) {
      var tf = star.pop.ageTension, tfn = (typeof CC_FAM_NAME !== "undefined" && CC_FAM_NAME[L][tf.fam]) || tf.fam;
      s += (L === "es") ? " (Edad en tensión con su familia: las estrellas de " + tfn + " nacieron antes de que su galaxia cayera en la Vía Láctea, hace más de " + ccFmt(tf.floor, 0) + " Ga.)" :
                          " (Age in tension with its family: " + tfn + " stars were born before their galaxy fell into the Milky Way, more than " + ccFmt(tf.floor, 0) + " Gyr ago.)";
   }
   return s;
}
