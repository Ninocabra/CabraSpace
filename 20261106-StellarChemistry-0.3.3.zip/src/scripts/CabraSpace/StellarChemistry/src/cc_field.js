// ============================================================================
// src/cc_field.js — EL ENCUADRE como lo necesita el motor (geometría pura)
// ----------------------------------------------------------------------------
// ccSyntheticField( ra, dec, width, height, scaleArcsec ) -> field
//   Un encuadre sin imagen (gnomónico, norte arriba, este a la izquierda): es lo
//   que deja probar el motor entero sobre M 67 sin una foto suya.
// ccFieldFromFunctions( width, height, project, unproject, epochYears ) -> field
//   El de una imagen resuelta (cc_pixinsight.js le da las dos funciones).
// field.polygon son las 4 esquinas en (ra, dec): en una proyección TAN los lados
// rectos de la imagen son círculos máximos, que es lo que entiende POLYGON de ADQL.
//
// Procedencia: `cpSfSyntheticField` de CabraPilot (engine/starfield_run.js,
// rama integracion-1410c), adaptada. ES5 puro.
// ============================================================================

function ccSyntheticField(ra, dec, width, height, scaleArcsec) {
   var k = Math.PI / 180, s = scaleArcsec / 3600 * k, a0 = ra * k, d0 = dec * k;
   var project = function(r, d) {
      var a = r * k, dd = d * k;
      var cosc = Math.sin(d0) * Math.sin(dd) + Math.cos(d0) * Math.cos(dd) * Math.cos(a - a0);
      if (!(cosc > 0.01)) return null;
      var xi = Math.cos(dd) * Math.sin(a - a0) / cosc, eta = (Math.cos(d0) * Math.sin(dd) - Math.sin(d0) * Math.cos(dd) * Math.cos(a - a0)) / cosc;
      return { x: width / 2 - xi / s, y: height / 2 - eta / s };
   };
   var unproject = function(x, y) {
      var xi = (width / 2 - x) * s, eta = (height / 2 - y) * s, rho = Math.sqrt(xi * xi + eta * eta), c = Math.atan(rho);
      if (!(rho > 0)) return { ra: ra, dec: dec };
      var dd = Math.asin(Math.cos(c) * Math.sin(d0) + eta * Math.sin(c) * Math.cos(d0) / rho);
      var a = a0 + Math.atan2(xi * Math.sin(c), rho * Math.cos(d0) * Math.cos(c) - eta * Math.sin(d0) * Math.sin(c));
      return { ra: ((a / k) % 360 + 360) % 360, dec: dd / k };
   };
   var f = ccFieldFromFunctions(width, height, project, unproject, 0);
   f.synthetic = true;
   f.scaleArcsec = scaleArcsec;
   return f;
}

function ccFieldFromFunctions(width, height, project, unproject, epochYears) {
   var out = { ok: false, width: width, height: height, project: project, unproject: unproject, epochYears: epochYears || 0, polygon: null, ra: 0, dec: 0, radiusDeg: 0 };
   var corners = [[0, 0], [width, 0], [width, height], [0, height]], poly = [];
   for (var i = 0; i < corners.length; ++i) {
      var p = unproject(corners[i][0], corners[i][1]);
      if (!p || !isFinite(p.ra) || !isFinite(p.dec)) return out;
      poly.push([p.ra, p.dec]);
   }
   var c = unproject(width / 2, height / 2);
   if (!c) return out;
   out.ra = c.ra; out.dec = c.dec;
   // ADQL POLYGON: los vértices en sentido antihorario visto desde dentro de la esfera.
   // Con norte arriba y este a la izquierda, (0,0)->(w,0)->(w,h)->(0,h) va de NE a NO a SO a SE:
   // eso ya es antihorario en el cielo. Si la imagen está volteada, se invierte.
   if (ccPolygonArea(poly) < 0) poly.reverse();
   out.polygon = poly;
   var far = 0;
   for (i = 0; i < poly.length; ++i) far = Math.max(far, ccSepArcsec(c.ra, c.dec, poly[i][0], poly[i][1]) / 3600);
   out.radiusDeg = far;
   out.ok = true;
   return out;
}

// Área con signo en el plano tangente (positiva = antihoraria en el cielo, con el
// este hacia la izquierda: x = −Δα cos δ, y = Δδ).
function ccPolygonArea(poly) {
   var ra0 = poly[0][0], dec0 = poly[0][1], c = Math.cos(dec0 * Math.PI / 180), s = 0;
   function X(p) { var d = p[0] - ra0; if (d > 180) d -= 360; if (d < -180) d += 360; return -d * c; }
   for (var i = 0; i < poly.length; ++i) {
      var a = poly[i], b = poly[(i + 1) % poly.length];
      s += X(a) * (b[1] - dec0) - X(b) * (a[1] - dec0);
   }
   return -s / 2;
}

// ---------------------------------------------------------------------------
// EL NOMBRE QUE SE VE DE LA VISTA (2-nov-2026, S4a del vídeo de formación)
// ---------------------------------------------------------------------------
// El id de una vista de PixInsight no admite espacios: «Collinder34», «M82». La cabecera del diálogo lo enseñaba tal cual; Cabra3D ya enseña «Collinder 34»
// (starfield_panel.js `_headTitle`: un objeto del campo que SE LLAMA como la vista salvo espacios y prefijos). Aquí CC no tiene la lista de objetos del campo,
// pero sí los catálogos de cúmulos de CabraShared/data: se busca en ellos un cúmulo (nombre o alias) que se llame como el id ignorando espacios, guiones
// bajos y mayúsculas, y que ESTÉ en el campo (centro a menos de radio del campo + radio del cúmulo). Si no hay, y solo si el id es «catálogo + número»
// (M82, NGC1560, Abell39…), se le pone el espacio; cualquier otro id («MasterLight», «Image01») queda como está: no se inventa.
// ROJO «oldtitle» (CC_BREAK): el id tal cual, como hasta el 1-nov.
function ccCompactName(x) { return String(x).toLowerCase().replace(/[^a-z0-9]+/g, ""); }
// tables = [texto de clusters_hr23.csv, texto de globulars_harris.csv] -> [{ names: [..], ra, dec, reach }]
// (3-nov-2026, CPD SC10) una fila SIN posición (en globulars_harris.csv, los 13 cúmulos que solo están en la base de Baumgardt) no se usa: no se
// puede comprobar que esté en el campo, y dar su nombre sin comprobarlo sería inventarlo.
function ccClusterRows(tables) {
   var out = [], t, i, j, lines, c, hdr, names, al;
   for (t = 0; t < (tables ? tables.length : 0); ++t) {
      lines = String(tables[t] || "").split(/\r?\n/); hdr = "";
      for (i = 0; i < lines.length; ++i) {
         if (!lines[i].length || lines[i].charAt(0) === "#") continue;
         if (!hdr) { hdr = lines[i].split(";")[0]; continue; }
         c = lines[i].split(";");
         if (hdr === "name" && c.length > 6) { names = [c[0]]; al = c[1] ? c[1].split(",") : []; for (j = 0; j < al.length; ++j) names.push(al[j]); out.push({ names: names, ra: parseFloat(c[3]), dec: parseFloat(c[4]), reach: Math.max(0.1, parseFloat(c[6]) || 0) }); }
         else if (hdr === "id" && c.length > 3) { names = [c[0]]; al = c[1] ? c[1].split(",") : []; for (j = 0; j < al.length; ++j) names.push(al[j]); out.push({ names: names, ra: parseFloat(c[2]), dec: parseFloat(c[3]), reach: 0.3 }); }
      }
   }
   return out.filter(function(r) { return isFinite(r.ra) && isFinite(r.dec); });
}
var CC_ID_CATALOG_RX = /^(M|NGC|IC|Abell|Collinder|Melotte|Stock|Trumpler|Berkeley|Barnard|UGC|PGC|Arp|LDN|LBN|Sh2|vdB|Cr|Mel|Tr|King|Dolidze|Pismis|Ruprecht)[- ]?(\d+[A-Za-z]?)$/i;
// Los dos catálogos de cúmulos de CabraShared/data (la carpeta sale del propio csh_hipnames.js: vale en cualquier máquina), leídos una vez. Sin ellos, [].
// (3-nov-2026, CPD SC10, regla 7.3) Los globulares, de globulars_harris.csv (Harris 1996, edición 2010: nombre y posición, redistribuible citando)
// y NO de globulars.csv, que lleva columnas de la base de Baumgardt et al. (sin licencia de redistribución: no va en el paquete). Aquí solo
// hacen falta nombre y posición: con Harris basta (las posiciones difieren de las de Baumgardt en segundos de arco; el «alcance» es 0,3°).
var CC_CLUSTER_FILES = ["clusters_hr23.csv", "globulars_harris.csv"];
var CC_CLUSTER_TABLES = null;
function ccClusterTables() {
   if (CC_CLUSTER_TABLES !== null) return CC_CLUSTER_TABLES;
   CC_CLUSTER_TABLES = [];
   try {
      var f = String(CSH_HIP_FILE).split("\\").join("/"), dir = f.substring(0, f.lastIndexOf("/") + 1) + "data/", names = CC_CLUSTER_FILES;
      for (var i = 0; i < names.length; ++i) if (File.exists(dir + names[i])) CC_CLUSTER_TABLES.push(File.readTextFile(dir + names[i]));
   } catch (e) {}
   return CC_CLUSTER_TABLES;
}
// -> el nombre con espacios («Collinder 34») o "" si el id no es de un objeto conocido. field: { ra, dec, radiusDeg } o null.
function ccViewObjectName(id, tables, field) {
   var cid = ccCompactName(id), rows, i, j, m;
   if (cid.length < 3) return "";
   rows = ccClusterRows(tables);
   var fok = !!(field && ccIsNum(field.ra) && ccIsNum(field.dec) && field.radiusDeg > 0);
   for (i = 0; i < rows.length; ++i)
      for (j = 0; j < rows[i].names.length; ++j) {
         if (ccCompactName(rows[i].names[j]) !== cid) continue;
         if (fok && ccIsNum(rows[i].ra) && ccSepArcsec(field.ra, field.dec, rows[i].ra, rows[i].dec) / 3600 > field.radiusDeg + rows[i].reach) continue;
         return rows[i].names[j].replace(/_+/g, " ").replace(/^\s+|\s+$/g, "");
      }
   m = CC_ID_CATALOG_RX.exec(String(id).replace(/^\s+|\s+$/g, "").replace(/_+/g, " "));
   if (m) return m[1] + " " + m[2];
   return "";
}
