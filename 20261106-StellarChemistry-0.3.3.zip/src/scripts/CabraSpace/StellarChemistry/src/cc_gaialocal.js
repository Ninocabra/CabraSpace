// ============================================================================
// src/cc_gaialocal.js — GAIA LOCAL: la base Gaia DR3 (o DR3/SP) que PixInsight tenga instalada (.xpsd)
// ----------------------------------------------------------------------------
// Solo PixInsight (usa el proceso Gaia). Patrón de CabraStars (csGaiaProbe) y Cabra3D (cpSfGaiaSearch).
// Lo que trae cada fila del proceso, medido en Cabra3D: [ra, dec, paralaje, pmra, pmdec, G, BP, RP, banderas, flujo]
// — SIN identificador de Gaia, SIN errores y SIN velocidad radial. Por eso:
//   · con ella salen, SIN RED, las estrellas del encuadre (la foto y el recuento por magnitud), y la posición,
//     el paralaje y el movimiento propio de las estrellas que se casan por POSICIÓN (0,5");
//   · lo que no trae (velocidad radial, distancias de Bailer-Jones, FLAME, GSP-Spec y los surveys de espectros)
//     sigue saliendo de internet; sin red, se dice que falta.
// No registra ni toca nada: si la base no está en ESTA instancia de PixInsight, lo dice y se sigue por internet.
// ES5.
// ============================================================================

// (desde el 15-oct-2026 la consulta es la COMUN, ../CabraShared/csh_gaia.js: la misma que usan CabraStars, Cabra3D y
// CabraStarAnalysis. Si la ultima consulta de la sesion ya cubre el encuadre, se reutilizan sus filas.)
var CC_GAIA_LOCAL_MAX = CSH_GAIA_LOCAL_MAX;

// ¿Qué base Gaia ve ESTA instancia? (DR3 primero, luego DR3/SP). -> { ok, release, name, why }
function ccGaiaLocalInfo() {
   var s = cpSfGaiaSource();
   return s.ok ? { ok: true, release: s.release, name: s.name, why: "" } : { ok: false, release: null, name: "", why: (typeof Gaia === "undefined") ? "no Gaia process" : "not installed in this PixInsight" };
}
// Un cono de la base local. -> { ok, rows: [{ ra, dec, plx, pmra, pmdec, g, bp, rp }], ms, truncated, name }
function ccGaiaLocalCone(info, ra, dec, radiusDeg, gMax) {
   var out = { ok: false, rows: [], ms: 0, truncated: false, name: info ? info.name : "" };
   if (!info || !info.ok) return out;
   var q = cpSfGaiaSearch(info.release, ra, dec, radiusDeg, gMax, CC_GAIA_LOCAL_MAX);
   out.ms = q.ms; out.truncated = q.truncated; out.ok = q.ok;
   if (q.ok) out.rows = cshGaiaRowsAsObjects(q.rows, undefined);
   return out;
}
function ccLocNum(v) { return cshLocNum(v); }
// El encuadre entero desde la base local, para ccRun (opts.gaiaLocal).
function ccGaiaLocalField(field) { return cshGaiaLocalField(field, 19); }
