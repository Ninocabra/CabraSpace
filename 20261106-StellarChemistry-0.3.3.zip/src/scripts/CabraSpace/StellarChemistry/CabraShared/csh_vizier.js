// ============================================================================
// CabraShared/csh_vizier.js — EL MOTOR DE VizieR POR LOS ESPEJOS ASU (uno para todos los scripts; 29-oct-2026)
// ----------------------------------------------------------------------------
// Diseño: docs/motor-vizier-unico.md. Antes habia dos motores para lo mismo (el traductor sencillo de csh_net.js y el planificador
// de CabraComposition) y el defecto «espejo vacio» hubo que arreglarlo dos veces. Aqui vive lo comun:
//   · PURO (sin red): leer un ADQL y partirlo en peticiones ASU (cshVzPlan, cshVzRequests), leer cada respuesta (cshVzRead) y volver
//     a montar el MISMO CSV que daria TAPVizieR (cshVzBuild): polígono o cono, JOIN por ids o por la clave del ON, IN, IS NOT NULL,
//     comparaciones simples, TOP + ORDER BY, el recuento por magnitud de CabraComposition.
//   · LA REGLA DEL VACIO, una sola vez: cshVzDeclared (en csh_net.js, la capa de abajo) + cshVzLoose (su costura roja).
//   · LA RED EN SERIE: cshVzMirrorAsk recorre una lista de espejos con la regla de los 0 filas (vacio provisional, se pregunta al
//     siguiente; vale solo si ninguno trae filas). La usan cshVizierGet (csh_net.js) y ccMirrorTry (CabraComposition).
// PROCEDENCIA: CabraComposition/src/cc_catalogs.js (ccAsuSelect, ccAsuTables, ccAsuPlan, ccAsuCircle, ccAsuInside, ccAsuEnc, ccAsuRequests,
// ccAsuQsOf, ccAsuRead, ccCsvCell, ccAsuBuild: 22-oct-2026 y 29-oct noche) y cc_pixinsight.js (ccMirrorTry, 29-oct, Codex R2 H-1), en
// git a86433b. Movido tal cual salvo lo marcado «(29-oct, motor unico)». Los nombres ccAsu* siguen en cc_catalogs.js como adaptadores.
// Requiere csh_net.js antes (cshVzDeclared, cshEnv, cshYield, cpSfHttpText). ES5. Sin «barra barra» en las expresiones regulares.
// ============================================================================

// Los topes (los de CabraComposition; CC_ASU_MAX/IDS/LIST_TABLES de cc_catalogs.js son alias de estos)
var CSH_VZ_MAX = 200000;                       // filas como mucho por peticion (el tope de TAPVizieR)
var CSH_VZ_IDS = 100;                          // ids por peticion (la URL de un GET: 100 ids de Gaia = ~2 100 caracteres)
var CSH_VZ_LIST_TABLES = ["J/A+A/708/A215/"];  // las tablas cuya columna de ids es TEXTO: ahi ASU acepta la lista de ids

// COSTURAS ROJAS (las de los dos motores, con sus nombres de siempre): CSH_BREAK o CC_BREAK (variables de entorno, separadas por comas)
// o la funcion global ccBroken(k) (cc_dialog.js en PixInsight; las pruebas de node la ponen en global).
function cshVzBrk(k) {
   var e = "," + ((typeof cshEnv === "function") ? "" + "," + "" : "") + ",";
   if (e.indexOf("," + k + ",") >= 0) return true;
   try { return (typeof ccBroken === "function" && !!ccBroken(k)); } catch (e2) { return false; }
}
// «emptyloose»: cualquier «solo comentarios» vale como vacio (el criterio de la mañana del 29-oct). Los dos nombres valen:
// CSH_VIZIER_EMPTY_LOOSE = true (csh_net.js) y CC_BREAK/CSH_BREAK=emptyloose.
function cshVzLoose() { return (typeof CSH_VIZIER_EMPTY_LOOSE !== "undefined" && CSH_VIZIER_EMPTY_LOOSE === true) || cshVzBrk("emptyloose"); }

// ---------------------------------------------------------------------------
// LEER EL ADQL
// ---------------------------------------------------------------------------
// Las columnas del SELECT: [{ alias, name }] (p."Teff-S" -> { alias: "p", name: "Teff-S" }; GALAH -> { alias: "", name: "GALAH" })
// (29-oct, motor unico) «TOP n» delante se quita (va en plan.top).
function cshVzSelect(adql) {
   var m = /^\s*SELECT\s+(?:TOP\s+\d+\s+)?([\s\S]*?)\s+FROM\s/i.exec(String(adql)), items = [], cur = "", q = false, s = m ? m[1] : "", i;
   for (i = 0; i < s.length; ++i) {
      var ch = s.charAt(i);
      if (ch === "\"") q = !q;
      if (ch === "," && !q) { items.push(cur); cur = ""; } else cur += ch;
   }
   if (cur.length) items.push(cur);
   var out = [];
   for (i = 0; i < items.length; ++i) {
      var x = items[i].replace(/^\s+|\s+$/g, ""), a = "", mm = /^([A-Za-z])\.(.*)$/.exec(x);
      if (mm) { a = mm[1]; x = mm[2]; }
      out.push({ alias: a, name: x.replace(/^"|"$/g, ""), quoted: /^".*"$/.test(x) });
   }
   return out;
}
// Las tablas del FROM: [{ alias, table }] en el orden en que aparecen ("I/355/gaiadr3" AS g LEFT OUTER JOIN "I/352/gedr3dis" AS d ...)
function cshVzTables(adql) {
   var f = /\sFROM\s([\s\S]*)$/.exec(String(adql)), out = [], re = /"([^"]+)"(?:\s+AS\s+([A-Za-z]))?/g, m;
   if (!f) return out;
   var tail = f[1].split(/\sWHERE\s/)[0];
   while ((m = re.exec(tail))) {
      if (/^[A-Za-z]\.$/.test(tail.substring(Math.max(0, m.index - 2), m.index))) continue;           // (una columna d."rgeo" de un ON, no una tabla)
      out.push({ alias: m[2] || "", table: m[1] });
   }
   return out;
}
var CSH_VZ_NUM = "[-+]?[0-9.]+(?:[eE][-+]?\\d+)?";
// (29-oct, motor unico) ¿Entiende el plan TODO el WHERE? Para quien pide con ctx.strict (cshVizierGet): un termino que no se sabe decir
// (OR, BETWEEN, funciones, una comparacion sobre una tabla auxiliar…) no se puede ignorar sin cambiar la respuesta -> el plan no vale.
// CabraComposition no lo pide: sus consultas son suyas y conocidas (lo de antes, sin cambio).
function cshVzWhereUnknown(adql, baseAlias) {
   var s = String(adql).replace(/\s+/g, " "), w = / WHERE (.*?)(?: ORDER BY .*| GROUP BY .*)?$/i.exec(s);
   if (!w) return "no WHERE";
   if (/ OR /i.test(w[1])) return "OR";
   var terms = w[1].split(/ AND /i), i;
   var CONE = /^(?:1 ?= ?)?CONTAINS ?\(.*\)(?: ?= ?1)?$/i, IN = /^(?:[A-Za-z]\.)?"?[A-Za-z0-9_]+"? IN ?\([0-9, ]+\)$/i;
   var NN = /^(?:[A-Za-z]\.)?(?:"[^"]+"|[A-Za-z_][A-Za-z0-9_]*) IS NOT NULL$/i;
   var CMP = new RegExp("^(?:([A-Za-z])\\.)?(?:\"[^\"]+\"|[A-Za-z_][A-Za-z0-9_]*) ?(?:>=|<=|>|<|=) ?" + CSH_VZ_NUM + "$");
   for (i = 0; i < terms.length; ++i) {
      var t = terms[i].replace(/^ | $/g, ""), k;
      if (CONE.test(t) || IN.test(t) || NN.test(t)) continue;
      if ((k = CMP.exec(t)) !== null) { if (k[1] && k[1] !== baseAlias) return "a condition on a joined table: " + t; continue; }
      return "a condition ASU cannot say: " + t;
   }
   return "";
}
// -> plan { ok, why, key, cols, tables, poly | circle, raCol, deCol, idCol, ids, notNull, count, mode, coneOnly, want, join, cons, top, order }
// ctx = { poly (el poligono del campo, para las consultas por ids enteros), strict (todo el WHERE tiene que entenderse) }
function cshVzPlan(adql, key, ctx) {
   var A = String(adql), plan = { ok: false, why: "", key: key, cols: [], tables: [], poly: null, raCol: "", deCol: "", idCol: "", ids: null, notNull: "", count: false };
   var sel = cshVzSelect(A), tabs = cshVzTables(A), i, strict = !!(ctx && ctx.strict);
   if (!tabs.length) { plan.why = "no table in the query"; return plan; }
   plan.tables = tabs;
   var mp = /CONTAINS\(POINT\('ICRS',([^,]+),([^)]+)\),POLYGON\('ICRS',([^)]*)\)\)/.exec(A);
   if (mp) {
      plan.raCol = mp[1].replace(/^[A-Za-z]\./, "").replace(/"/g, ""); plan.deCol = mp[2].replace(/^[A-Za-z]\./, "").replace(/"/g, "");
      var nums = mp[3].split(","), poly = [];
      for (i = 0; i + 1 < nums.length; i += 2) poly.push([parseFloat(nums[i]), parseFloat(nums[i + 1])]);
      if (poly.length < 3) { plan.why = "bad polygon"; return plan; }
      plan.poly = poly;
   }
   // (29-oct, motor unico) EL CONO: CIRCLE('ICRS', ra, dec, r). ASU lo pide igual (-c, -c.rd) y no hace falta recortar en casa.
   var mc = new RegExp("CONTAINS ?\\( ?POINT ?\\( ?'ICRS' ?, ?([^,()]+) ?, ?([^,()]+) ?\\) ?, ?CIRCLE ?\\( ?'ICRS' ?, ?(" + CSH_VZ_NUM + ") ?, ?(" + CSH_VZ_NUM + ") ?, ?(" + CSH_VZ_NUM + ") ?\\) ?\\)", "i").exec(A);
   if (mc && !mp) {
      var cra = Number(mc[3]), cde = Number(mc[4]), crr = Number(mc[5]);
      if (!isFinite(cra) || !isFinite(cde) || !(crr > 0)) { plan.why = "bad circle"; return plan; }
      plan.circle = { ra: cra, dec: cde, r: crr };
      plan.raCol = mc[1].replace(/^\s+|\s+$/g, "").replace(/^[A-Za-z]\./, "").replace(/"/g, ""); plan.deCol = mc[2].replace(/^\s+|\s+$/g, "").replace(/^[A-Za-z]\./, "").replace(/"/g, "");
   }
   var mi = /WHERE\s+(?:[A-Za-z]\.)?"?([A-Za-z0-9_]+)"?\s+IN\s*\(([0-9,\s]+)\)/.exec(A);
   if (mi) { plan.idCol = mi[1]; plan.ids = mi[2].replace(/\s+/g, "").split(",").filter(function(x) { return x.length > 0; }); }
   // (29-oct, motor unico) IS NOT NULL tambien con la columna SIN comillas (AND RV IS NOT NULL, AND Teff IS NOT NULL)
   var mn = /AND\s+(?:[A-Za-z]\.)?(?:"([^"]+)"|([A-Za-z_][A-Za-z0-9_]*))\s+IS NOT NULL/.exec(A);
   if (mn) plan.notNull = mn[1] || mn[2];
   if (/GROUP BY gbin/.test(A)) { plan.count = true; plan.cols = ["gbin", "n"]; plan.ok = !!plan.poly; if (!plan.ok) plan.why = "count without polygon"; return plan; }
   for (i = 0; i < sel.length; ++i) plan.cols.push(sel[i]);
   if (strict) {
      for (i = 0; i < sel.length; ++i) if ((!sel[i].quoted && /[()*]|\sAS\s/i.test(sel[i].name)) || sel[i].name.length === 0) { plan.why = "a SELECT item ASU cannot say: " + sel[i].name; return plan; }
      if (/\bGROUP BY\b|\bDISTINCT\b|\bHAVING\b/i.test(A)) { plan.why = "GROUP BY / DISTINCT"; return plan; }
      if (tabs.length > 1 && (A.match(/\bJOIN\b/gi) || []).length !== (A.match(/\bLEFT\s+(?:OUTER\s+)?JOIN\b/gi) || []).length) { plan.why = "only LEFT JOIN can be rebuilt"; return plan; }
      var unk = cshVzWhereUnknown(A, tabs[0].alias);
      if (unk) { plan.why = unk; return plan; }
   }
   // (29-oct, motor unico) TOP n y ORDER BY col [ASC|DESC]: se ordena y se corta en casa
   var mt = /^\s*SELECT\s+TOP\s+(\d+)\s/i.exec(A);
   if (mt) plan.top = parseInt(mt[1], 10);
   var mo = /\sORDER BY\s+(?:[A-Za-z]\.)?(?:"([^"]+)"|([A-Za-z_][A-Za-z0-9_]*))(?:\s+(ASC|DESC))?\s*$/i.exec(A);
   if (mo) plan.order = { col: mo[1] || mo[2], desc: /DESC/i.test(mo[3] || "") };
   else if (strict && /\sORDER BY\s/i.test(A)) { plan.why = "an ORDER BY ASU cannot say"; return plan; }
   // (29-oct, motor unico) comparaciones simples de la tabla base (AND g.RPlx>5, AND Gmag<17): restriccion de ASU y filtro en casa
   plan.cons = [];
   var reC = new RegExp("\\sAND\\s+(?:([A-Za-z])\\.)?(?:\"([^\"]+)\"|([A-Za-z_][A-Za-z0-9_]*))\\s*(>=|<=|>|<|=)\\s*(" + CSH_VZ_NUM + ")(?=\\s|$)", "g"), kc;
   while ((kc = reC.exec(A)) !== null) if (!kc[1] || kc[1] === tabs[0].alias) plan.cons.push({ col: kc[2] || kc[3], op: kc[4], v: Number(kc[5]) });
   var geo = !!(plan.poly || plan.circle);
   if (!geo && !plan.ids) { plan.why = "neither polygon nor ids"; return plan; }
   // (29-oct, motor unico) JOIN SIN IN (el afinado, la ficha): la clave es la del ON (g.Source=d.Source) y las auxiliares van por el mismo cono
   if (tabs.length > 1 && !plan.ids) {
      var mj = /\sON\s+([A-Za-z])\.(?:"([^"]+)"|([A-Za-z_][A-Za-z0-9_]*))\s*=\s*([A-Za-z])\.(?:"([^"]+)"|([A-Za-z_][A-Za-z0-9_]*))/i.exec(A);
      if (!mj || (mj[2] || mj[3]) !== (mj[5] || mj[6])) { plan.why = "a JOIN without a common key column"; return plan; }
      plan.idCol = mj[2] || mj[3]; plan.join = true;
   }
   if (plan.ids && !geo) {
      // ¿la lista de ids vale para esta tabla? si no, el cono del campo (el polígono de la última consulta por polígono)
      var listOk = false;
      for (i = 0; i < CSH_VZ_LIST_TABLES.length; ++i) if (plan.tables[0].table.indexOf(CSH_VZ_LIST_TABLES[i]) === 0) listOk = true;
      plan.mode = listOk ? "list" : "cone";
      if (plan.mode === "cone") {
         if (!(ctx && ctx.poly && ctx.poly.length >= 3)) { plan.why = "no field polygon known for a cone request"; return plan; }
         plan.poly = ctx.poly; plan.coneOnly = true;
         var want = {};
         for (i = 0; i < plan.ids.length; ++i) want[plan.ids[i]] = true;
         plan.want = want;
      }
   }
   plan.ok = true;
   return plan;
}
// El círculo que envuelve el polígono: { ra, dec, r } (r en grados, con un 0,2 % de margen)
function cshVzCircle(poly) {
   var sx = 0, sy = 0, sz = 0, k = Math.PI / 180, i;
   for (i = 0; i < poly.length; ++i) { var a = poly[i][0] * k, d = poly[i][1] * k; sx += Math.cos(d) * Math.cos(a); sy += Math.cos(d) * Math.sin(a); sz += Math.sin(d); }
   var n = Math.sqrt(sx * sx + sy * sy + sz * sz), ra = Math.atan2(sy, sx) / k, dec = Math.asin(sz / n) / k, r = 0;
   if (ra < 0) ra += 360;
   for (i = 0; i < poly.length; ++i) {
      var d1 = poly[i][1] * k, d0 = dec * k, dr = (poly[i][0] - ra) * k;
      var c = Math.sin(d0) * Math.sin(d1) + Math.cos(d0) * Math.cos(d1) * Math.cos(dr);
      r = Math.max(r, Math.acos(Math.max(-1, Math.min(1, c))) / k);
   }
   return { ra: ra, dec: dec, r: r * 1.002 + 0.0005 };
}
// ¿Está (ra, dec) dentro del polígono? Con las aristas como CÍRCULOS MÁXIMOS (lo que es el borde de una foto y lo que hace el
// CONTAINS de VizieR): en la proyección GNOMÓNICA centrada en el campo un círculo máximo es una recta, y el test es el plano de siempre.
function cshVzInside(poly) {
   var c = cshVzCircle(poly), k = Math.PI / 180, a0 = c.ra * k, d0 = c.dec * k, P = [], i;
   function proj(ra, dec) {
      var a = ra * k, d = dec * k, cc = Math.sin(d0) * Math.sin(d) + Math.cos(d0) * Math.cos(d) * Math.cos(a - a0);
      if (!(cc > 1e-9)) return null;
      return [Math.cos(d) * Math.sin(a - a0) / cc, (Math.cos(d0) * Math.sin(d) - Math.sin(d0) * Math.cos(d) * Math.cos(a - a0)) / cc];
   }
   for (i = 0; i < poly.length; ++i) { var q = proj(poly[i][0], poly[i][1]); if (!q) return function() { return false; }; P.push(q); }
   return function(ra, dec) {
      var s = proj(ra, dec);
      if (!s) return false;
      var inside = false;
      for (var a = 0, b = P.length - 1; a < P.length; b = a++) {
         var yi = P[a][1], yj = P[b][1];
         if ((yi > s[1]) !== (yj > s[1]) && s[0] < (P[b][0] - P[a][0]) * (s[1] - yi) / (yj - yi) + P[a][0]) inside = !inside;
      }
      return inside;
   };
}
function cshVzEnc(s) { return encodeURIComponent(String(s)).replace(/%2F/g, "/"); }
// Las peticiones de un plan: [{ t (índice de la tabla), qs (la cadena tras «?») }]
function cshVzRequests(plan) {
   var reqs = [], t, i, cols;
   function base(tbl, names) { return "-source=" + cshVzEnc(tbl) + "&-oc.form=d&-out.max=" + CSH_VZ_MAX + "&-out=" + names.map(cshVzEnc).join(","); }
   function coneQs() { var cr = plan.circle || cshVzCircle(plan.poly), rr = plan.circle ? String(cr.r) : cr.r.toFixed(5); return "&-c=" + cr.ra.toFixed(6) + (cr.dec >= 0 ? "%2B" : "") + cr.dec.toFixed(6) + "&-c.rd=" + rr; }
   if (plan.count) {
      reqs.push({ t: 0, qs: base(plan.tables[0].table, [plan.raCol || "RA_ICRS", plan.deCol || "DE_ICRS", "Gmag"]) + "&Gmag=%3C19" + coneQs() });
      return reqs;
   }
   for (t = 0; t < plan.tables.length; ++t) {
      var al = plan.tables[t].alias;
      cols = [];
      for (i = 0; i < plan.cols.length; ++i) {
         var c0 = plan.cols[i];
         if ((c0.alias === al || (c0.alias === "" && t === 0)) && cols.indexOf(c0.name) < 0) cols.push(c0.name);
      }
      if (plan.ids && plan.mode === "list") {
         if (cols.indexOf(plan.idCol) < 0) cols.unshift(plan.idCol);
         for (i = 0; i < plan.ids.length; i += CSH_VZ_IDS) reqs.push({ t: t, qs: base(plan.tables[t].table, cols) + "&" + cshVzEnc(plan.idCol) + "=" + plan.ids.slice(i, i + CSH_VZ_IDS).join(",") });
      } else if (plan.coneOnly || t === 0 || plan.join) {
         if ((plan.coneOnly || plan.join) && cols.indexOf(plan.idCol) < 0) cols.unshift(plan.idCol);
         var extra = "";
         // (29-oct, motor unico) en la tabla base: la columna del IS NOT NULL y la del ORDER BY, si no se piden ya; las comparaciones, como restriccion ASU
         if (t === 0) {
            if (plan.notNull && cols.indexOf(plan.notNull) < 0 && plan.circle) cols.push(plan.notNull);
            if (plan.order && cols.indexOf(plan.order.col) < 0) cols.push(plan.order.col);
            for (i = 0; plan.cons && i < plan.cons.length; ++i) extra += "&" + cshVzEnc(plan.cons[i].col) + "=" + encodeURIComponent(plan.cons[i].op + String(plan.cons[i].v));
         }
         reqs.push({ t: t, qs: base(plan.tables[t].table, cols) + extra + coneQs() });
      }
   }
   return reqs;
}
// La tabla y las columnas que pide una petición ASU (la cadena tras «?» de cshVzRequests) -> { table, cols }
function cshVzQsOf(qs) {
   var o = { table: "", cols: [] }, parts = String(qs || "").split("&"), i;
   function dec(x) { try { return decodeURIComponent(x); } catch (e) { return x; } }
   for (i = 0; i < parts.length; ++i) {
      if (parts[i].indexOf("-source=") === 0) o.table = dec(parts[i].substring(8));
      else if (parts[i].indexOf("-out=") === 0) o.cols = parts[i].substring(5).split(",").map(dec);
   }
   return o;
}
// Una respuesta ASU (TSV: comentarios «#», cabecera, unidades, guiones y filas) -> { cols, rows: [[celdas]] }.
//   { error } si el espejo dice «#INFO Error=...» (tabla que no tiene: «Table or Catalog not found», medido en NAO con GALAH DR4);
//   { empty: true } si es una consulta válida SIN filas; null si no es ASU.
// (No es cshAsuParse: la fila de unidades de GALAH lleva dígitos «[cm/s2]» y ese lector la tomaría por un dato.)
// (29-oct, noche) «Solo comentarios» NO basta para ser vacío: un espejo que NO ENTIENDE la petición también contesta solo comentarios y sin
// «Error=», pero con «#Name:» VACÍO y ninguna «#Column». El vacío de verdad trae «#Name: <la tabla pedida>» y una «#Column» por CADA columna
// pedida: cshVzDeclared (csh_net.js), la MISMA regla que usa cshVizierAsuCommentsOnly. Costura roja: cshVzLoose().
function cshVzRead(text, table, cols) {
   var T = String(text || ""), L = T.split("\n"), lines = [], i;
   var me = /(?:^|\n)#INFO\s+Error=([^\r\n]*)/.exec(T);
   if (me && me[1].replace(/\s+/g, "").length > 0) return { error: me[1].replace(/^\s+|\s+$/g, "") };
   for (i = 0; i < L.length; ++i) {
      var s = L[i].replace(/\r$/, "");
      if (s.length === 0 || s.charAt(0) === "#") continue;
      lines.push(s);
   }
   if (lines.length < 1) {
      if (T.indexOf("service_protocol=ASU") < 0) return null;
      if (!cshVzLoose()) {
         var dc = cshVzDeclared(T, table, cols), lack = dc.lack;
         if (!dc.named || !cols || cols.length === 0 || lack.length > 0)
            return { error: "the mirror did not understand the request (" + (dc.named ? "no #Column for " + (lack.length ? lack.join(", ") : "any column") : "empty #Name, no #Column") + ")", notUnderstood: true };
      }
      return { cols: [], rows: [], empty: true };
   }
   if (lines[0].indexOf("<") >= 0) return null;
   var hcols = lines[0].split("\t").map(function(c) { return c.replace(/^\s+|\s+$/g, ""); });
   var rows = [], at = -1;
   for (i = 1; i < lines.length && i < 4; ++i) if (/^[-\t ]+$/.test(lines[i]) && lines[i].indexOf("-") >= 0) { at = i; break; }
   if (at < 0) return { cols: hcols, rows: rows, noRule: true };
   for (i = at + 1; i < lines.length; ++i) rows.push(lines[i].split("\t").map(function(c) { return c.replace(/^\s+|\s+$/g, ""); }));
   return { cols: hcols, rows: rows };
}
function cshVzCsvCell(v) {
   var s = String(v === undefined || v === null ? "" : v);
   return (s.indexOf(",") >= 0 || s.indexOf("\"") >= 0 || s.indexOf("\n") >= 0) ? "\"" + s.split("\"").join("\"\"") + "\"" : s;
}
// (29-oct, motor unico) ¿Esta (ra, dec) a menos de r grados del centro del cono?
function cshVzInCircle(c) {
   var k = Math.PI / 180, sd0 = Math.sin(c.dec * k), cd0 = Math.cos(c.dec * k), cr = Math.cos(c.r * k);
   return function(ra, dec) { var d = dec * k; return sd0 * Math.sin(d) + cd0 * Math.cos(d) * Math.cos((ra - c.ra) * k) >= cr - 1e-12; };
}
// Las respuestas (una por petición, en el orden de cshVzRequests) -> { ok, csv, rows, why, truncated, missing }
// (30-oct-2026) EL MISMO TEXTO NO SE LEE DOS VECES. Medido en Pleyades con CJ_PROFILE (StellarChemistry, IDIA): las ~28 tandas de ids de Gaia comparten las 3 respuestas de cono del espejo
// (I/355/gaiadr3 27 MB, I/352 18 MB, I/355/paramp 8,5 MB) y cada montaje las releia: 0,55 s x 28 = 14,75 s seguidos con la ventana congelada. Clave: la consulta; ademas se compara el texto
// (el mismo objeto: inmediato), asi que otro espejo o una respuesta distinta se leen de nuevo. cshVzBuild no escribe en las filas. Solo lo grande y las ultimas 4; ccRun lo suelta al acabar la red.
var CSH_VZ_READ_MEMO = [], CSH_VZ_READ_MEMO_MAX = 4, CSH_VZ_READ_MEMO_MIN = 262144;
function cshVzReadMemoClear() { CSH_VZ_READ_MEMO = []; }
function cshVzReadOnce(qs, text, table, cols) {
   if (String(text || "").length < CSH_VZ_READ_MEMO_MIN || cshVzBrk("noreadmemo")) return cshVzRead(text, table, cols);
   for (var i = 0; i < CSH_VZ_READ_MEMO.length; ++i) if (CSH_VZ_READ_MEMO[i].qs === qs && CSH_VZ_READ_MEMO[i].text === text) return CSH_VZ_READ_MEMO[i].rd;
   var rd = cshVzRead(text, table, cols);
   CSH_VZ_READ_MEMO.push({ qs: qs, text: text, rd: rd });
   if (CSH_VZ_READ_MEMO.length > CSH_VZ_READ_MEMO_MAX) CSH_VZ_READ_MEMO.shift();
   return rd;
}
function cshVzBuild(plan, reqs, texts) {
   var out = { ok: false, csv: "", rows: 0, why: "", truncated: false }, i, j, t;
   var tabs = [];
   for (t = 0; t < plan.tables.length; ++t) tabs.push({ rows: [], cols: null });
   for (i = 0; i < reqs.length; ++i) {
      var qo = cshVzQsOf(reqs[i].qs), rd = cshVzReadOnce(reqs[i].qs, texts[i], qo.table, qo.cols);
      if (!rd) { out.why = "request " + (i + 1) + " is not an ASU table"; return out; }
      if (rd.error) { out.why = rd.notUnderstood ? rd.error : "the mirror says: " + rd.error; return out; }
      var tb = tabs[reqs[i].t];
      if (rd.empty) { tb.empty = true; continue; }
      if (tb.cols === null) tb.cols = rd.cols;
      if (rd.rows.length >= CSH_VZ_MAX) { out.truncated = true; out.why = "the mirror answer was cut at " + CSH_VZ_MAX + " rows"; return out; }
      for (j = 0; j < rd.rows.length; ++j) tb.rows.push(rd.rows[j]);
      if (reqs[i].t === 0 && rd.cols.length === 0) { out.why = "no columns"; return out; }
   }
   function idx(tb, name) { return tb.cols ? tb.cols.indexOf(name) : -1; }
   var base = tabs[0], inPoly = null;
   if (base.cols === null && base.empty === true && !plan.count) {          // una consulta válida SIN filas: solo la cabecera, como TAPVizieR
      var h0 = [];
      for (i = 0; i < plan.cols.length; ++i) h0.push(cshVzCsvCell(plan.cols[i].name));
      out.csv = h0.join(",") + "\n"; out.rows = 0; out.ok = true; out.missing = [];
      return out;
   }
   if (plan.count && base.cols === null) { out.csv = "gbin,n\n"; out.rows = 0; out.ok = true; return out; }
   if (plan.poly && !plan.coneOnly) inPoly = cshVzInside(plan.poly);
   if (plan.count) {
      var iR = idx(base, plan.raCol || "RA_ICRS"), iD = idx(base, plan.deCol || "DE_ICRS"), iG = idx(base, "Gmag");
      if (iR < 0 || iD < 0 || iG < 0) { out.why = "the mirror did not return RA_ICRS, DE_ICRS and Gmag"; return out; }
      var hist = {}, keys = [];
      for (j = 0; j < base.rows.length; ++j) {
         var rw = base.rows[j], g = parseFloat(rw[iG]), ra = parseFloat(rw[iR]), de = parseFloat(rw[iD]);
         if (!isFinite(g) || !isFinite(ra) || !isFinite(de) || g >= 19 || !inPoly(ra, de)) continue;
         var b = Math.floor(g); if (hist[b] === undefined) { hist[b] = 0; keys.push(b); } ++hist[b];
      }
      keys.sort(function(a, c) { return a - c; });
      var lines = ["gbin,n"];
      for (j = 0; j < keys.length; ++j) lines.push(keys[j] + "," + hist[keys[j]]);
      out.csv = lines.join("\n") + "\n"; out.rows = keys.length; out.ok = true;
      return out;
   }
   // las tablas auxiliares (LEFT OUTER JOIN por la columna de ids): mapa id -> fila
   var maps = [];
   for (t = 1; t < tabs.length; ++t) {
      var m = {}, ik = idx(tabs[t], plan.idCol);
      for (j = 0; ik >= 0 && j < tabs[t].rows.length; ++j) m[tabs[t].rows[j][ik]] = tabs[t].rows[j];
      maps.push(m);
   }
   var aliasTab = {};
   for (t = 0; t < plan.tables.length; ++t) aliasTab[plan.tables[t].alias || "_"] = t;
   var head = [], colMap = [], missing = [], lostCols = [];
   for (i = 0; i < plan.cols.length; ++i) {
      var c1 = plan.cols[i], tt = (c1.alias === "") ? 0 : aliasTab[c1.alias];
      if (tt === undefined) tt = 0;
      head.push(cshVzCsvCell(c1.name));
      var ci = idx(tabs[tt], c1.name);
      if (ci < 0) missing.push(c1.name);
      colMap.push({ t: tt, i: ci });
      // (29-oct, noche) falta una columna de una tabla que SÍ vino con su cabecera: ese espejo la QUITA sin avisar (IDIA, medido con Age-Flame) -> se
      // pregunta al siguiente. Una tabla auxiliar que llegó vacía (cols === null) sigue dando celdas en blanco (el LEFT JOIN). Rojo CC_BREAK=missingok.
      // (30-oct, decision D) GRVSmag y RVtempTeff no valen por si solas para ceder: sin ellas el resto de la fila sirve y la RV sale sin corregir (y la ficha lo dice). Medido en IDIA; CfA y NAO, callados ese dia.
      // (2-nov-2026, Q4) e_pmRA y e_pmDE tampoco: sin ellas Cabra3D usa el error típico de Gaia para la G de la estrella, y lo dice.
      if (ci < 0 && tabs[tt].cols !== null && !cshVzBrk("missingok") && c1.name !== "GRVSmag" && c1.name !== "RVtempTeff" && c1.name !== "e_pmRA" && c1.name !== "e_pmDE") lostCols.push(c1.name);
   }
   if (lostCols.length > 0) { out.why = "the mirror did not return " + lostCols.join(", "); return out; }
   if (colMap.length && colMap[0].i < 0 && idx(base, plan.idCol || plan.cols[0].name) < 0) { out.why = "the mirror did not return the first column"; return out; }
   var iRa = plan.raCol ? idx(base, plan.raCol) : -1, iDe = plan.deCol ? idx(base, plan.deCol) : -1, iNN = plan.notNull ? idx(base, plan.notNull) : -1, iId = plan.idCol ? idx(base, plan.idCol) : -1;
   if (inPoly && (iRa < 0 || iDe < 0)) { out.why = "the mirror did not return the position columns " + plan.raCol + ", " + plan.deCol; return out; }
   // (29-oct, motor unico) las comparaciones de la base, tambien en casa (si la columna vino), y el orden de ORDER BY
   var consI = [];
   for (i = 0; plan.cons && i < plan.cons.length; ++i) { var ix = idx(base, plan.cons[i].col); if (ix >= 0) consI.push({ i: ix, op: plan.cons[i].op, v: plan.cons[i].v }); }
   function consOk(r0) {
      for (var q = 0; q < consI.length; ++q) {
         var x = parseFloat(r0[consI[q].i]), v = consI[q].v, op = consI[q].op;
         if (!isFinite(x)) return false;
         if ((op === ">" && !(x > v)) || (op === "<" && !(x < v)) || (op === ">=" && !(x >= v)) || (op === "<=" && !(x <= v)) || (op === "=" && !(x === v))) return false;
      }
      return true;
   }
   var picked = [];
   for (j = 0; j < base.rows.length; ++j) {
      var r0 = base.rows[j];
      if (inPoly) { var ra1 = parseFloat(r0[iRa]), de1 = parseFloat(r0[iDe]); if (!isFinite(ra1) || !isFinite(de1) || !inPoly(ra1, de1)) continue; }
      if (iNN >= 0 && (r0[iNN] === undefined || r0[iNN] === "")) continue;
      if (plan.want && !(iId >= 0 && plan.want[r0[iId]] === true)) continue;
      if (consI.length && !consOk(r0)) continue;
      picked.push(r0);
   }
   if (plan.order) {
      var iO = idx(base, plan.order.col);
      if (iO < 0) { out.why = "the mirror did not return the ORDER BY column " + plan.order.col; return out; }
      var sg = plan.order.desc ? -1 : 1;
      // (los nulos al final, como TAPVizieR con ASC; el orden de llegada en los empates)
      picked = picked.map(function(r, k) { return { r: r, k: k, v: parseFloat(r[iO]) }; }).sort(function(a, c) {
         var fa = isFinite(a.v), fc = isFinite(c.v);
         if (fa !== fc) return fa ? -1 : 1;
         if (fa && a.v !== c.v) return sg * (a.v - c.v);
         return a.k - c.k;
      }).map(function(x) { return x.r; });
   }
   if (plan.top > 0 && picked.length > plan.top) picked = picked.slice(0, plan.top);
   var csv = [head.join(",")], n = 0;
   for (j = 0; j < picked.length; ++j) {
      var p0 = picked[j], aux = [];
      for (t = 1; t < tabs.length; ++t) aux.push(iId >= 0 ? maps[t - 1][p0[iId]] : undefined);
      var cells = [];
      for (i = 0; i < colMap.length; ++i) {
         var cm = colMap[i], row = (cm.t === 0) ? p0 : aux[cm.t - 1];
         cells.push(cshVzCsvCell((row && cm.i >= 0) ? row[cm.i] : ""));
      }
      csv.push(cells.join(",")); ++n;
   }
   out.csv = csv.join("\n") + "\n"; out.rows = n; out.ok = true; out.missing = missing;
   return out;
}

// ---------------------------------------------------------------------------
// LA RED, EN SERIE: una consulta (ya planificada) por una lista de espejos
// ---------------------------------------------------------------------------
// Un espejo: { name, url (la de asu-tsv), lacks: [prefijos de tablas que NO sirve bien: se salta sin preguntarle] }. Se aceptan tambien
// la forma de CabraComposition [url, name, lacks] y la de csh_net.js { name, asu }.
function cshVzMirrorOf(m) {
   if (m instanceof Array) return { url: m[0], name: m[1], lacks: m[2] || [] };
   return { url: m.url || m.asu, name: m.name, lacks: m.lacks || [] };
}
function cshVzLacks(mm, adql) {
   var s = String(adql || "");
   for (var i = 0; i < mm.lacks.length; ++i) if (s.indexOf(mm.lacks[i]) >= 0) return true;
   return false;
}
// o = { mirrors (lista; por defecto CSH_VIZIER_MIRRORS), adql (para los `lacks`), fetch(url, mirror, i) -> { ok, text, message, kind, code, ms, cut, aborted },
//       memo (objeto: clave «m|qs» -> texto; la de CabraComposition), acceptEmpty (true: el primer 0 filas vale), abort() -> true para parar,
//       onEmpty(mirror, nextName), onBad(mirror, why, nextName) }
// -> { ok, csv, text (= csv), rows, empty, server, why, attempts: [{ server, kind, http, ms }], last (la ultima respuesta de la red que fallo) }
// La regla de los 0 filas (29-oct, Codex R1 H-1 / R2 H-1): 0 filas de un espejo es un vacio PROVISIONAL (el primero que lo da) y se pregunta al
// siguiente; si alguno trae filas, manda; si ninguno y alguno contesto vacio y valido, vale el vacio (empty: true).
function cshVzMirrorAsk(plan, reqs, o) {
   o = o || {};
   var M = (o.mirrors || CSH_VIZIER_MIRRORS || []).map(cshVzMirrorOf), out = { ok: false, csv: "", text: "", rows: 0, empty: false, server: "", why: "", attempts: [], last: null };
   var why = [], empty = null, m, i;
   function stop() { try { return (typeof o.abort === "function" && o.abort() === true); } catch (e) { return false; } }
   for (m = 0; m < M.length && !stop(); ++m) {
      var mm = M[m], texts = [], fail = "", nx = (m + 1 < M.length) ? M[m + 1].name : "";
      if (cshVzLacks(mm, o.adql)) { why.push(mm.name + ": table not served by this mirror"); continue; }
      // (29-oct-2026 (noche)) con `o.fetchMany(urls, mirror) -> [respuestas]` (el lote comun, csh_batch.js) las peticiones de ESTE espejo salen a la vez;
      // se leen despues en el mismo orden y con la misma regla (el primer fallo cierra el espejo), asi que el resultado es el de la serie.
      var pre = null;
      if (typeof o.fetchMany === "function") {
         var need = [], at = [];
         for (i = 0; i < reqs.length; ++i) if (!(o.memo && o.memo[m + "|" + reqs[i].qs] !== undefined)) { need.push(mm.url + "?" + reqs[i].qs); at.push(i); }
         if (need.length > 1) { var got = o.fetchMany(need, mm) || []; pre = {}; for (i = 0; i < at.length; ++i) pre[at[i]] = got[i]; }
      }
      for (i = 0; i < reqs.length && !stop(); ++i) {
         var mk = m + "|" + reqs[i].qs;
         if (o.memo && o.memo[mk] !== undefined) { texts.push(o.memo[mk]); continue; }
         var a = (pre && pre[i]) ? pre[i] : (o.fetch(mm.url + "?" + reqs[i].qs, mm, i) || {});
         out.attempts.push({ server: mm.name, kind: a.ok ? "ok" : (a.kind || (a.cut ? "timeout" : (a.code > 0) ? "http" : "offline")), http: (a.code > 0) ? a.code : 0, ms: a.ms || 0 });
         if (!a.ok) { fail = mm.name + ": " + (a.message || a.kind); out.last = a; break; }
         if (o.memo) o.memo[mk] = a.text;
         texts.push(a.text);
      }
      if (stop()) break;
      if (!fail) {
         var b = cshVzBuild(plan, reqs, texts);
         cshVzReadMemoClear();                                            // (en serie no se comparten respuestas: las filas no se quedan en memoria)
         if (b.ok && b.rows === 0 && o.acceptEmpty !== true) {
            if (!empty) empty = { csv: b.csv, server: mm.name };
            why.push(mm.name + ": 0 rows, asking the next mirror");
            if (typeof o.onEmpty === "function") { try { o.onEmpty(mm, nx); } catch (eE) {} }
            continue;
         }
         if (b.ok) { out.ok = true; out.csv = out.text = b.csv; out.server = mm.name; out.rows = b.rows; out.empty = (b.rows === 0); out.why = why.join(" · "); return out; }
         fail = mm.name + ": " + b.why; out.badWhy = b.why;
         if (typeof o.onBad === "function") { try { o.onBad(mm, b.why, nx); } catch (eB) {} }
      }
      why.push(fail);
   }
   if (empty && !stop()) { out.ok = true; out.csv = out.text = empty.csv; out.server = empty.server; out.rows = 0; out.empty = true; out.why = why.join(" · "); return out; }
   out.why = why.join(" · ");
   return out;
}
