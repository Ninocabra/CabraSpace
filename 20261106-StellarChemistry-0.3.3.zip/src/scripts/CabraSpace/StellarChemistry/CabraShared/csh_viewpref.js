#ifndef __CSH_VIEWPREF_JS
#define __CSH_VIEWPREF_JS
// ============================================================================
// CabraShared/csh_viewpref.js — LA ELECCION «REAL PHOTO | STARS» SE RECUERDA ENTRE SESIONES, IGUAL EN LOS CUATRO SCRIPTS (30-oct-2026)
// ----------------------------------------------------------------------------
// Decision de Nino (30-oct-2026): los cuatro scripts ARRANCAN en «Foto real» y RECUERDAN la ultima eleccion del conmutador (csh_pills.js).
// Hasta hoy solo CabraComposition la recordaba (Settings `CabraComposition/aView`, valores "photo" / "comp"); CabraStars, Cabra3D y CabraStarAnalysis
// la olvidaban. Aqui queda la logica comun de leer y escribir; cada script la llama con su raiz de Settings:
//   · CabraStars `CabraStars/aView` · Cabra3D `Cabra3D/aView` · CabraStarAnalysis `CabraStarAnalysis/aView` · CabraComposition `CabraComposition/aView`
//     (esta ultima ya existia: la clave y sus valores NO cambian; la elegida «Stars» se guarda como "comp", `o.stars`). Los demas guardan "stars".
//   · Sin clave, o con un valor que no sea el de «Stars», arranca en «Foto real» (de fabrica y ante cualquier basura).
//   · Se escribe SOLO cuando el usuario pulsa una pildora (no cuando el script cambia el estado por su cuenta: p. ej. CabraStarAnalysis esconde la
//     superposicion al salir del modo Polvo, y eso no es una eleccion).
//   · «Stars» recordado = lo que el usuario QUIERE; solo se pinta cuando hay algo que pintar (analisis). Sin analisis se ve la foto, y el conmutador
//     esta apagado como siempre.
// PRUEBAS: lo que no es el programa de verdad (CS_NO_MAIN, CP_NO_MAIN, CC_NO_MAIN) NO lee ni escribe nada (siempre «Foto real»), como los demas
// ajustes recordados (cs_ui.js csLayoutIO), SALVO que la prueba ponga CSH_VP.IO = true; y entonces lo hace en un ESPACIO APARTE (CSH_VP.NS): la
// raiz pasa a ser «<raiz>_vp_<NS>», de modo que la preferencia verdadera de Nino NO se toca ni se lee. Costura del rojo (CSH_VP_BREAK):
//   «nowrite» = no se escribe nunca · «leak» = el espacio aparte se ignora (se pisa la clave verdadera) · «defstars» = de fabrica «Stars» ·
//   «ignore» = no se lee lo recordado.
// ES5. Comentarios en castellano; identificadores en inglés.
// ============================================================================

var CSH_VP = { KEY: "aView", NS: "", IO: false };
var CSH_VP_BREAK = "";
function cshVpBroken(k) { return (typeof CSH_VP_BREAK === "string") && CSH_VP_BREAK.length > 0 && CSH_VP_BREAK.indexOf(k) >= 0; }
// ¿Se lee y se escribe? En el programa de verdad, si; en una prueba (noMain), solo con CSH_VP.IO.
function cshVpIO(noMain) { return noMain !== true || CSH_VP.IO === true; }
// La ruta de Settings de una clave (`key` de fabrica "aView"). Con un espacio de prueba (CSH_VP.NS) la raiz cambia.
function cshVpPath(root, key) {
   var r = root;
   if (CSH_VP.NS && String(CSH_VP.NS).length > 0 && !cshVpBroken("leak")) r = root + "_vp_" + CSH_VP.NS;
   return r + "/" + (key || CSH_VP.KEY);
}
// Lo recordado: "photo", "stars" o (31-oct-2026) "compare". `o.stars` = el valor con que ese script guarda «Stars» (de fabrica "stars"; CabraComposition, "comp").
function cshVpRead(root, noMain, o) {
   var starsTok = (o && o.stars) ? String(o.stars) : "stars";
   if (cshVpBroken("defstars")) return "stars";
   if (!cshVpIO(noMain) || cshVpBroken("ignore")) return "photo";
   try {
      var v = Settings.read(cshVpPath(root), DataType_UCString);
      if (Settings.lastReadOK !== false && v !== null && v !== undefined && String(v) === starsTok) return "stars";
      if (Settings.lastReadOK !== false && String(v) === "compare") return "compare";
   } catch (e) {}
   return "photo";
}
// Guardar la eleccion del usuario (`which` = "photo" | "stars" | "compare"). Devuelve true si se escribio.
function cshVpWrite(root, noMain, which, o) {
   var starsTok = (o && o.stars) ? String(o.stars) : "stars";
   if (!cshVpIO(noMain) || cshVpBroken("nowrite")) return false;
   try { Settings.write(cshVpPath(root), DataType_UCString, (which === "stars") ? starsTok : (which === "compare") ? "compare" : "photo"); return true; } catch (e) {}
   return false;
}
#endif
