// ============================================================================
// CabraShared/csh_kinpop.js — LA POBLACION CINEMATICA (disco fino / grueso / halo): UN SOLO MODELO (29-oct-2026)
// ----------------------------------------------------------------------------
// Decision de Nino (R4 H-2 de la revision de Codex, _ref/codex_29oct/respuestas/R4_cinematica.md): UN modelo para
// CabraStars y CabraComposition (y por tanto CabraStarAnalysis), el de CabraStars. Antes habia dos que discrepaban en las
// dos fronteras aun sin errores (Codex, barrido de 231 estrellas: 14 con otra poblacion ganadora y 21 con otra clase):
//   · CabraStars/lib/cs_astro.js (csPopulation): Sol de Schönrich 2010, fracciones de Bensby 2014, prior espacial de Juric 2008,
//     veredicto «probable» (P >= 0,8) / «posible» (>= 0,5) / «indeterminada»;
//   · CabraComposition/src/cc_science.js (ccKinematics): Sol de Dehnen & Binney 1998, fracciones de Bensby 2003, sin prior y
//     «mixed» por debajo de P 0,6, con Monte Carlo de los errores.
// PROCEDENCIA: copiado de CabraStars/lib/cs_astro.js (commit 960958c: CS_AST.SUN_UVW/POP/JURIC/P_*, csGalPosition, csVelocity,
// csGauss2, csInv3, csGauss3, csPopPrior y csPopulation) con las MISMAS operaciones en el mismo orden: CabraStars da bit a bit lo
// mismo que antes (CabraShared/tests/csh_kinpop_test.js, prueba B). Solo cambia el nombre del veredicto bajo P 0,5: aqui
// "undetermined"; csPopulation lo sigue llamando "uncertain" (su firma no cambia).
//
// DE DONDE SALE CADA NUMERO (los de cs_astro.js, leidos alli el 14-oct-2026; Codex los contrasto con los articulos el 29-oct):
//   · Movimiento del Sol respecto al LSR (U, V, W) = (11,10; 12,24; 7,25) km/s: Schönrich, Binney y Dehnen 2010 (MNRAS 403,
//     1829), el que usa Bensby 2014.
//   · Fracciones X y elipsoides (σU, σV, σW, V_asym) de disco fino, grueso y halo: Bensby, Feltzing y Oey 2014 (A&A 562, A71;
//     arXiv:1309.2631), Tabla A.1 (la corriente de Hercules no se usa).
//   · Densidad con la altura y el radio: Juric et al. 2008 (ApJ 673, 864; astro-ph/0510520): H = 300 / 900 pc, L = 2600 /
//     3600 pc, halo r^-2,8 con q = 0,64, R☉ = 8 kpc, Z☉ ~ 25 pc. Su combinacion con las fracciones de Bensby (la fraccion local
//     llevada al sitio de la estrella) es DISEÑO (Codex: «la atribucion completa de los parametros de Juric queda SIN VERIFICAR»).
//   · Matriz ICRS -> galacticas: Hipparcos (ESA 1997, vol. 1, §1.5.3), la misma de la documentacion de Gaia DR3.
//   · 4,740470446 km/s = 1 UA/año.
//   · DISEÑO: «probable» con P >= 0,8; «posible» de 0,5 a 0,8; por debajo «indeterminada» (Bensby llama grueso a TD/D > 2, es
//     decir P = 2/3 con dos clases; aqui hay tres y se pide mas). Con un error de distancia > 20 % no se da poblacion (la vara de
//     Bailer-Jones 2015 del motor de CabraStars: el error de la distancia entra linealizado, como dispersion de mas a lo largo de
//     la velocidad tangencial, y con mas error esa aproximacion ya no vale).
// COMO TRATA LOS ERRORES (sin Monte Carlo): con velocidad radial, gaussiana 3D del elipsoide + rvErr² a lo largo de la visual +
// (vtan · fraccion de distancia)² a lo largo de la tangencial. Sin radial, la velocidad que falta se MARGINALIZA (elipsoide
// proyectado en el plano del cielo). Los errores del movimiento propio NO entran (tampoco entraban en CabraStars).
//
// API
//   cshKinPop(s) -> { pop, best, p: { thin, thick, halo } | null, verdict, why, rv, vtan, uvw, z, R, model }
//     s = { ra, dec (grados), dist: { pc, lo, hi, quality, fraction }, pmRa (con cos dec), pmDec (mas/año), rv (km/s o null), rvErr }
//     verdict: "probable" | "possible" | "undetermined" | "no-data" (why: no-distance, suspect-distance, distance-error, no-pm,
//     out-of-model). uvw = U, V, W respecto al LSR (null sin radial). z, R = altura y radio galactocentricos (pc).
//   cshKinPopPrior(pos) · cshKinPopGalPosition(ra, dec, pc) · cshKinPopModelText(lang)
// Usuarios: CabraStars (csPopulation, lib/cs_astro.js), CabraComposition (ccKinematics, src/cc_science.js), CabraStarAnalysis
// (los dos). PURO (ES5, sin PixInsight, sin directivas): lo cargan en node CabraStars/tests/cs_test_pure.js,
// CabraShared/tests/csh_kinpop_test.js y CabraComposition/tests/cc_node_lib.js. Se incluye UNA vez por script, antes de cs_astro.js
// y de cc_science.js.
// ============================================================================

var CSH_KINPOP = {
   MODEL: "Schönrich 2010 + Bensby 2014 + Jurić 2008",
   KV: 4.740470446,                    // km/s por (mas/año · kpc)
   SUN_UVW: [11.10, 12.24, 7.25],      // km/s respecto al LSR (Schönrich et al. 2010)
   POPS: ["thin", "thick", "halo"],
   POP: {
      thin:  { X: 0.85,   s: [35, 20, 16],   va: -15 },
      thick: { X: 0.09,   s: [67, 38, 35],   va: -46 },
      halo:  { X: 0.0015, s: [160, 90, 90],  va: -220 }
   },
   JURIC: { zSun: 25, R0: 8000, Hthin: 300, Hthick: 900, Lthin: 2600, Lthick: 3600, nHalo: 2.8, qHalo: 0.64 },
   P_PROBABLE: 0.8, P_POSSIBLE: 0.5,   // diseño (ver la cabecera)
   // (29-oct, decisión de Nino) por debajo de esto, una estrella cuya más probable es fino o grueso se enseña como «disco», sin
   // elegir: un 53 % no distingue fino de grueso. 0,6 es el corte de la «mezcla» del modelo viejo de CabraComposition.
   DISC_P: 0.6,
   MAX_DIST_FRACTION: 0.2,             // diseño (ver la cabecera)
   MAX_RUWE: 1.4,                      // Lindegren et al. 2021; el mismo corte que CP_SF.MAX_RUWE de csh_starfield.js (cc no carga ese fichero; tests/cc_node_famgate.js comprueba que coinciden)
   // La matriz ICRS -> galacticas (Hipparcos; filas = ejes galacticos x, y, z)
   GAL: [[-0.0548755604162154, -0.8734370902348850, -0.4838350155487132],
         [ 0.4941094278755837, -0.4448296299600112,  0.7469822444972189],
         [-0.8676661490190047, -0.1980763734312015,  0.4559837761750669]]
};

// ¿Se enseña como «disco» sin decir fino ni grueso? pop = la más probable, p = { thin, thick, halo } (o null).
// Lo usan las fichas de CabraStars / CabraStarAnalysis (cs_ui_card.js) y CabraComposition (ccPopulation, solo sin química).
function cshKinPopDiscOnly(pop, p) {
   return !!p && (pop === "thin" || pop === "thick") && (p[pop] || 0) < CSH_KINPOP.DISC_P;
}

// El texto que dice QUE modelo es (ficha / ayuda de los tres scripts).
function cshKinPopModelText(lang) {
   return (lang === "es") ? "cinemática: Schönrich 2010 · Bensby 2014" : "kinematics: Schönrich 2010 · Bensby 2014";
}

function cshKpRad(d) { return d * Math.PI / 180; }
function cshKpDeg(r) { return r * 180 / Math.PI; }
function cshKpMul3(M, v) { return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2], M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2], M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]]; }

// La base local de una direccion, en GALACTICAS: r (hacia la estrella), e_ra (este), e_dec (norte).
function cshKpLocalBasis(ra, dec) {
   var a = cshKpRad(ra), d = cshKpRad(dec), G = CSH_KINPOP.GAL;
   var r = [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)];
   var ea = [-Math.sin(a), Math.cos(a), 0];
   var ed = [-Math.sin(d) * Math.cos(a), -Math.sin(d) * Math.sin(a), Math.cos(d)];
   return { r: cshKpMul3(G, r), ea: cshKpMul3(G, ea), ed: cshKpMul3(G, ed) };
}

// La posicion galactocentrica: altura z sobre el plano (con Z☉) y radio R en el plano, en pc (y l, b en grados).
function cshKinPopGalPosition(ra, dec, pc) {
   var a = cshKpRad(ra), d = cshKpRad(dec);
   var g3 = cshKpMul3(CSH_KINPOP.GAL, [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)]);
   var l = cshKpDeg(Math.atan2(g3[1], g3[0]));
   if (l < 0) l += 360;
   var b = cshKpDeg(Math.asin(Math.max(-1, Math.min(1, g3[2]))));
   var J = CSH_KINPOP.JURIC, cb = Math.cos(cshKpRad(b));
   var x = J.R0 - pc * cb * Math.cos(cshKpRad(l)), y = pc * cb * Math.sin(cshKpRad(l));
   return { l: l, b: b, z: pc * Math.sin(cshKpRad(b)) + J.zSun, R: Math.sqrt(x * x + y * y) };
}

// La velocidad: tangencial (siempre) y la espacial U, V, W HELIOCENTRICA (solo con velocidad radial).
function cshKpVelocity(ra, dec, pc, pmRa, pmDec, rv) {
   var B = cshKpLocalBasis(ra, dec), k = CSH_KINPOP.KV * pc / 1000;
   var t1 = k * pmRa, t2 = k * pmDec, out = { vtan: Math.sqrt(t1 * t1 + t2 * t2), t: [t1, t2], basis: B, uvw: null };
   if (rv !== null && rv !== undefined && isFinite(rv))
      out.uvw = [t1 * B.ea[0] + t2 * B.ed[0] + rv * B.r[0], t1 * B.ea[1] + t2 * B.ed[1] + rv * B.r[1], t1 * B.ea[2] + t2 * B.ed[2] + rv * B.r[2]];
   return out;
}

// --- gaussianas de 2 y 3 dimensiones (densidad) ---
function cshKpGauss2(x, mu, C) {
   var a = C[0][0], b = C[0][1], c = C[1][0], d = C[1][1], det = a * d - b * c;
   if (!(det > 0)) return 0;
   var dx = x[0] - mu[0], dy = x[1] - mu[1];
   var q = (d * dx * dx - (b + c) * dx * dy + a * dy * dy) / det;
   return Math.exp(-0.5 * q) / (2 * Math.PI * Math.sqrt(det));
}
function cshKpInv3(M) {
   var a = M[0][0], b = M[0][1], c = M[0][2], d = M[1][0], e = M[1][1], f = M[1][2], g = M[2][0], h = M[2][1], i = M[2][2];
   var A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g, det = a * A + b * B + c * C;
   if (!(Math.abs(det) > 0)) return null;
   return { det: det, inv: [[A / det, -(b * i - c * h) / det, (b * f - c * e) / det],
                            [B / det, (a * i - c * g) / det, -(a * f - c * d) / det],
                            [C / det, -(a * h - b * g) / det, (a * e - b * d) / det]] };
}
function cshKpGauss3(x, mu, C) {
   var r = cshKpInv3(C);
   if (r === null || !(r.det > 0)) return 0;
   var d = [x[0] - mu[0], x[1] - mu[1], x[2] - mu[2]], q = 0;
   for (var i = 0; i < 3; ++i) for (var j = 0; j < 3; ++j) q += d[i] * r.inv[i][j] * d[j];
   return Math.exp(-0.5 * q) / (Math.pow(2 * Math.PI, 1.5) * Math.sqrt(r.det));
}

// La fraccion a priori de cada poblacion EN EL SITIO DE LA ESTRELLA: la de Bensby en el entorno solar, llevada a su altura y
// radio con los perfiles de Juric (relativa a la del Sol). diseño (combinacion). pos = { z, R } en pc.
function cshKinPopPrior(pos) {
   var J = CSH_KINPOP.JURIC, P = CSH_KINPOP.POP, zs = J.zSun;
   var thin = P.thin.X * Math.exp(-(Math.abs(pos.z) - zs) / J.Hthin - (pos.R - J.R0) / J.Lthin);
   var thick = P.thick.X * Math.exp(-(Math.abs(pos.z) - zs) / J.Hthick - (pos.R - J.R0) / J.Lthick);
   var r2 = pos.R * pos.R + Math.pow(pos.z / J.qHalo, 2), r2s = J.R0 * J.R0 + Math.pow(zs / J.qHalo, 2);
   var halo = P.halo.X * Math.pow(Math.max(r2, 1e4) / r2s, -J.nHalo / 2);
   return { thin: thin, thick: thick, halo: halo };
}

// (30-oct-2026, N1 + D1-H5 de la revision de Codex; decision B de Nino) LA PUERTA DE CALIDAD DE LA ASTROMETRIA, una sola para todos los scripts: con RUWE >= 1,4
// (Lindegren et al. 2021; CP_SF.MAX_RUWE en csh_starfield.js, el mismo que pinta huecas y da «suspect» en CabraStars y Cabra3D) o con mas de un 20 % de error en la
// distancia (MAX_DIST_FRACTION) no se da poblacion cinematica ni familia. -> null si la astrometria vale, o { ruwe: bool, dist: bool, why: "ruwe" | "dist" | "ruwe+dist", ruweV, frac }.
// `dist` = { pc, lo, hi, fraction }: la fraccion, la MISMA cuenta que cshKinPop.
function cshKpDistFraction(d) { return (d.fraction > 0) ? d.fraction : ((d.hi > d.lo && d.lo > 0) ? (d.hi - d.lo) / (2 * d.pc) : 0); }
function cshAstroDoubt(ruwe, dist) {
   var K = CSH_KINPOP, r = (ruwe !== null && ruwe !== undefined && isFinite(ruwe) && ruwe >= K.MAX_RUWE);
   var f = (dist && dist.pc > 0) ? cshKpDistFraction(dist) : 0, d = (f > K.MAX_DIST_FRACTION);
   if (!r && !d) return null;
   return { ruwe: r, dist: d, why: r ? (d ? "ruwe+dist" : "ruwe") : "dist", ruweV: r ? ruwe : null, frac: f };
}
// LA POBLACION PROBABLE de una estrella (ver la cabecera: entrada, salida y errores).
function cshKinPop(s) {
   var K = CSH_KINPOP;
   var out = { pop: "", best: "", p: null, verdict: "no-data", why: "", rv: false, vtan: null, uvw: null, z: null, R: null, model: K.MODEL };
   var d = s ? s.dist : null;
   if (!d || !(d.pc > 0)) { out.why = "no-distance"; return out; }
   if (d.quality === "suspect") { out.why = "suspect-distance"; return out; }
   var frac = cshKpDistFraction(d);
   if (frac > K.MAX_DIST_FRACTION) { out.why = "distance-error"; return out; }
   if (s.pmRa === null || s.pmDec === null || !isFinite(s.pmRa) || !isFinite(s.pmDec)) { out.why = "no-pm"; return out; }
   var pos = cshKinPopGalPosition(s.ra, s.dec, d.pc);
   out.z = pos.z; out.R = pos.R;
   var v = cshKpVelocity(s.ra, s.dec, d.pc, s.pmRa, s.pmDec, (s.rv !== undefined) ? s.rv : null);
   out.vtan = v.vtan;
   var prior = cshKinPopPrior(pos), like = {}, sum = 0, i, k, sun = K.SUN_UVW;
   var errT = v.vtan * frac;                                   // km/s, a lo largo de la tangencial
   for (i = 0; i < K.POPS.length; ++i) {
      k = K.POPS[i];
      var P = K.POP[k], mu = [-sun[0], P.va - sun[1], -sun[2]];          // la media en el marco HELIOCENTRICO
      var S = [[P.s[0] * P.s[0], 0, 0], [0, P.s[1] * P.s[1], 0], [0, 0, P.s[2] * P.s[2]]];
      var f;
      if (v.uvw !== null) {
         // 3D: + el error de la radial y el de la distancia
         var C3 = [[S[0][0], 0, 0], [0, S[1][1], 0], [0, 0, S[2][2]]], re = (s.rvErr > 0) ? s.rvErr : 0, B = v.basis, a, b;
         var tu = v.vtan > 0 ? [ (v.t[0] * B.ea[0] + v.t[1] * B.ed[0]) / v.vtan, (v.t[0] * B.ea[1] + v.t[1] * B.ed[1]) / v.vtan, (v.t[0] * B.ea[2] + v.t[1] * B.ed[2]) / v.vtan ] : [0, 0, 0];
         for (a = 0; a < 3; ++a) for (b = 0; b < 3; ++b) C3[a][b] += re * re * B.r[a] * B.r[b] + errT * errT * tu[a] * tu[b];
         f = cshKpGauss3(v.uvw, mu, C3);
      } else {
         // 2D: proyeccion sobre (e_ra, e_dec)
         var E = [v.basis.ea, v.basis.ed], m2 = [0, 0], C2 = [[0, 0], [0, 0]], p, q;
         for (p = 0; p < 2; ++p) {
            m2[p] = E[p][0] * mu[0] + E[p][1] * mu[1] + E[p][2] * mu[2];
            for (q = 0; q < 2; ++q) C2[p][q] = E[p][0] * E[q][0] * S[0][0] + E[p][1] * E[q][1] * S[1][1] + E[p][2] * E[q][2] * S[2][2];
         }
         if (v.vtan > 0) { var u0 = v.t[0] / v.vtan, u1 = v.t[1] / v.vtan; C2[0][0] += errT * errT * u0 * u0; C2[0][1] += errT * errT * u0 * u1; C2[1][0] += errT * errT * u0 * u1; C2[1][1] += errT * errT * u1 * u1; }
         f = cshKpGauss2(v.t, m2, C2);
      }
      like[k] = prior[k] * f;
      sum += like[k];
   }
   if (v.uvw !== null) { out.rv = true; out.uvw = [v.uvw[0] + sun[0], v.uvw[1] + sun[1], v.uvw[2] + sun[2]]; }
   if (!(sum > 0)) { out.why = "out-of-model"; out.verdict = "undetermined"; return out; }
   out.p = { thin: like.thin / sum, thick: like.thick / sum, halo: like.halo / sum };
   var best = "thin";
   for (i = 1; i < K.POPS.length; ++i) if (out.p[K.POPS[i]] > out.p[best]) best = K.POPS[i];
   out.pop = best; out.best = best;
   out.verdict = (out.p[best] >= K.P_PROBABLE) ? "probable" : (out.p[best] >= K.P_POSSIBLE) ? "possible" : "undetermined";
   return out;
}
