#ifndef __CSH_PILLS_JS
#define __CSH_PILLS_JS
// ============================================================================
// CabraShared/csh_pills.js — EL CONMUTADOR «REAL PHOTO | STARS» (dos píldoras) COMÚN A LOS CUATRO SCRIPTS (30-oct-2026)
// ----------------------------------------------------------------------------
// Petición de Nino (30-oct-2026): «Sí quiero los cuatro iguales». Hasta hoy cada script tenía su copia: CabraComposition lo pintaba a mano
// en su lienzo (cc_paint.js), CabraStars lo copió como hijo transparente del lienzo (lib/cs_ui_overlay.js) y Cabra3D / CabraStarAnalysis
// seguían con el icono de tres anillos. Aquí queda UNA pieza de dibujo y de colocación:
//   · aspecto (de CabraComposition, cc_paint.js): alto 18 px lógicos, letra «text» 8,4 px en negrita, 8 px de margen dentro de cada píldora,
//     4 px entre las dos, 14 px al borde derecho y 9 px arriba; la elegida en oro con letra tinta, la otra en surface2 con borde line y letra
//     text2; al pasar el ratón por la otra su borde se dora. Apagado (sin nada que conmutar) se pinta a media luz (CSH_PILLS.DIM).
//   · cshPillsGeom / cshPillsAt / cshPillsPaint: geometría, acierto del ratón y dibujo, puros (sin estado). CabraComposition, que pinta sobre su
//     propio lienzo con sus zonas de clic, usa solo estas tres.
//   · cshPillsCreate(parent, o): el conmutador como HIJO TRANSPARENTE del lienzo (hoja Qt «background: transparent»: sin ella la hoja del
//     diálogo lo rellena de negro, medido el 30-oct con una sonda de CabraStars), colocado a mano arriba a la derecha (no cambia el tamaño del
//     lienzo, así que ni el encuadre ni el zoom se mueven). Lo usan CabraStars, Cabra3D y CabraStarAnalysis.
// La pieza NO decide qué se conmuta ni qué se recuerda: eso lo dicen quien la instala (`o.state`, `o.onPick`). Cada script conserva su
// criterio (CabraComposition recuerda la elección entre sesiones; los otros tres, no).
// PROCEDENCIA: cs_ui_overlay.js (CabraStars, 30-oct) y cc_paint.js:827-840 (CabraComposition). Depende de csh_atlas.js (cpInt, cpFont, cpMix).
// Defectos inyectados (pruebas: CSH_PILLS_BREAK): «pillswap» = el clic en una píldora elige la otra · «left» = colocado arriba a la izquierda ·
// «opaque» = sin la hoja transparente · «border» = sin «border: none» (en Cabra3D / CabraStarAnalysis hereda el marco del visor) · «nodim» = apagado igual que encendido.
// ES5. Comentarios en castellano; identificadores en inglés.
// ============================================================================

var CSH_PILLS = { H: 18, FONT: 8.4, PAD: 8, GAP: 4, RIGHT: 14, TOP: 9, DIM: 0.42 };
var CSH_PILLS_BREAK = "";
function cshPillsBroken(k) { return (typeof CSH_PILLS_BREAK === "string") && CSH_PILLS_BREAK.length > 0 && CSH_PILLS_BREAK.indexOf(k) >= 0; }

// La geometría en pixeles FISICOS: `keys` = las claves de izquierda a derecha, `labelOf(k)` = su texto, `sc` = pixeles fisicos por logico.
// Devuelve { f, sc, pills: [{ key, label, x0, x1 }], w, h } (x0/x1 desde el borde izquierdo del conmutador).
function cshPillsGeom(keys, labelOf, sc) {
   var f = cpFont("text", CSH_PILLS.FONT * sc, true), pills = [], x = 0, i;
   for (i = 0; i < keys.length; ++i) {
      var lab = labelOf(keys[i]), pw = f.width(lab) + 2 * CSH_PILLS.PAD * sc;
      pills.push({ key: keys[i], label: lab, x0: x, x1: x + pw });
      x += pw + (i < keys.length - 1 ? CSH_PILLS.GAP * sc : 0);
   }
   return { f: f, sc: sc, pills: pills, w: Math.ceil(x) + 1, h: Math.ceil(CSH_PILLS.H * sc) + 1 };
}
// ¿Que pildora hay en la x (desde el borde izquierdo del conmutador)? Su clave, o "" (el hueco entre las dos).
function cshPillsAt(G, x) {
   for (var i = 0; i < G.pills.length; ++i) if (x >= G.pills[i].x0 && x <= G.pills[i].x1) return G.pills[i].key;
   return "";
}
// El dibujo. `cur` = la clave elegida (en oro); opt = { enabled (de fabrica true), hover (la clave bajo el raton), x, y (esquina de arriba a la
// izquierda del conmutador en el Graphics; de fabrica 0,0), text (fn(g, font, colorInt, x, y, label): como pintar la letra; de fabrica drawText) }.
function cshPillsPaint(g, G, cur, opt) {
   opt = opt || {};
   var sc = G.sc, A = CSH_ATLAS, ox = opt.x || 0, oy = opt.y || 0, h = CSH_PILLS.H * sc, enabled = (opt.enabled !== false), ring = cpMix(A.surface, A.gold, 0.45);
   try { g.antialiasing = true; } catch (e0) {}
   try { g.textAntialiasing = true; } catch (e1) {}
   if (!enabled && !cshPillsBroken("nodim")) g.opacity = CSH_PILLS.DIM;
   for (var i = 0; i < G.pills.length; ++i) {
      var P = G.pills[i], on = (P.key === cur), hov = (!on && enabled && opt.hover === P.key);
      // (en PJSR drawRoundedRect RELLENA con el pincel vigente: relleno y borde en una sola pasada, con el pincel del relleno)
      g.brush = new Brush(cpInt(on ? A.gold : A.surface2, on ? 0.9 : 1));
      g.pen = new Pen(cpInt(on ? A.gold : (hov ? ring : A.line)), 1);
      g.drawRoundedRect(ox + P.x0, oy, ox + P.x1, oy + h, 40, 99);
      var col = cpInt(on ? A.ink : (hov ? A.text : A.text2));
      if (typeof opt.text === "function") opt.text(g, G.f, col, ox + P.x0 + CSH_PILLS.PAD * sc, oy + 13 * sc, P.label);
      else { g.font = G.f; g.pen = new Pen(col, 1); g.drawText(ox + P.x0 + CSH_PILLS.PAD * sc, oy + 13 * sc, P.label); }
   }
   g.opacity = 1;
}

// (31-oct-2026, Nino) LA CORTINILLA DE «COMPARE», LA MISMA EN LOS TRES SCRIPTS QUE LA TIENEN (la tercera pildora, encima de la foto; antes vivia en I · View
// de CabraStars y los otros no la tenian). A la izquierda de la linea, la foto; a la derecha, lo que pinta «Stars». x, y0, y1 = la linea; x0, x1 = la zona; `tl`, `tr` = los rotulos.
var CSH_CURTAIN = { GRAB: 9, MIN: 0.03, MAX: 0.97 };
function cshCurtainClamp(f) { return Math.max(CSH_CURTAIN.MIN, Math.min(CSH_CURTAIN.MAX, f)); }
function cshCurtainPaint(g, x, y0, y1, x0, x1, sc, tl, tr, labelsTop) {
   var A = CSH_ATLAS, P = function(v) { return Math.round(v * sc); }, f = cpFont("text", 8.4 * sc, true), th = f.ascent + f.descent;
   g.pen = new Pen(cpInt(A.bg, 0.8), Math.max(3, 3 * sc)); g.drawLine(x, y0, x, y1);
   g.pen = new Pen(cpInt(A.gold), Math.max(1.5, 1.6 * sc)); g.drawLine(x, y0, x, y1);
   var hy = (y0 + y1) / 2, hw = P(11), hh = P(17);
   g.pen = new Pen(cpInt(A.gold), 1); g.brush = new Brush(cpInt(A.gold));
   try { g.drawRoundedRect(x - hw, hy - hh, x + hw, hy + hh, P(4), P(4)); } catch (eR) { g.drawRect(x - hw, hy - hh, x + hw, hy + hh); }
   g.pen = new Pen(cpInt(A.ink), Math.max(1.2, 1.4 * sc));
   g.drawLine(x - P(6), hy, x - P(2), hy - P(4)); g.drawLine(x - P(6), hy, x - P(2), hy + P(4));
   g.drawLine(x + P(6), hy, x + P(2), hy - P(4)); g.drawLine(x + P(6), hy, x + P(2), hy + P(4));
   g.drawLine(x - P(6), hy, x + P(6), hy);
   g.font = f;
   // los rotulos, abajo: arriba estan las pildoras y el titulo
   var ty = (labelsTop === true) ? y0 + P(8) : y1 - P(10) - th;      // (arriba, donde abajo hay leyenda: CabraStars)
   if (x - x0 > f.width(tl) + P(24)) { g.fillRect(new Rect(x - P(14) - f.width(tl) - P(6), ty - P(2), x - P(14) + P(6), ty + th + P(2)), new Brush(cpInt(A.bg, 0.75))); g.pen = new Pen(cpInt(A.text2)); g.drawText(x - P(14) - f.width(tl), ty + f.ascent, tl); }
   if (x1 - x > f.width(tr) + P(24)) { g.fillRect(new Rect(x + P(14) - P(6), ty - P(2), x + P(14) + f.width(tr) + P(6), ty + th + P(2)), new Brush(cpInt(A.bg, 0.75))); g.pen = new Pen(cpInt(A.goldLight)); g.drawText(x + P(14), ty + f.ascent, tr); }
}

// ---------------------------------------------------------------------------
// EL CONMUTADOR COMO HIJO DEL LIENZO
//   o = { keys: ["photo","stars"], label: fn(k) → texto, scale: fn() → px fisicos por logico (de fabrica, los del lienzo),
//         state: fn() → { enabled: bool, cur: clave elegida, tip: texto del tooltip (ya partido), key: cadena que cambia si cambia el aspecto },
//         onPick: fn(k) (clic en una pildora; apagado no se llama), name: etiqueta para las pruebas,
//         geom / pillAt / place: ganchos opcionales (CabraStars los apunta a sus metodos, que las pruebas sustituyen en los rojos) }
//   Devuelve S = { ctl, geom(), pillAt(x), place(), sync(), paint() }; S.ctl lleva csHover, csKey, csW, csH, csTipKey para las pruebas.
// ---------------------------------------------------------------------------
function cshPillsCreate(parent, o) {
   var S = { parent: parent, o: o, ctl: null }, b = new Control(parent);
   function scale() {
      var k = 0;
      if (typeof o.scale === "function") { try { k = o.scale(); } catch (e) { k = 0; } }
      if (!(k > 0)) { try { k = parent.logicalPixelsToPhysical(1000) / 1000; } catch (e1) { k = 0; } }
      return (k > 0) ? k : 1;
   }
   S.scale = scale;
   S.geom = function() { return cshPillsGeom(o.keys, o.label, scale()); };
   S.pillAt = function(x) {
      var k = cshPillsAt((typeof o.geom === "function") ? o.geom() : S.geom(), x);
      if (cshPillsBroken("pillswap")) return (k === o.keys[0]) ? o.keys[1] : ((k === o.keys[1]) ? o.keys[0] : k);
      return k;
   };
   S.place = function() {
      var G = (typeof o.geom === "function") ? o.geom() : S.geom(), cw = 0;
      try { cw = parent.width; } catch (e0) {}
      if (b.csW !== G.w || b.csH !== G.h) { b.csW = G.w; b.csH = G.h; try { b.setFixedSize(G.w, G.h); } catch (e1) {} }
      var x = cshPillsBroken("left") ? Math.round(8 * G.sc) : Math.max(0, Math.round(cw - CSH_PILLS.RIGHT * G.sc - G.w)), y = cshPillsBroken("left") ? Math.round(8 * G.sc) : Math.round(CSH_PILLS.TOP * G.sc);
      try { var p = b.position; if (!p || p.x !== x || p.y !== y) b.position = new Point(x, y); } catch (e2) { try { b.position = new Point(x, y); } catch (e3) {} }
   };
   S.paint = function() {
      var g = new Graphics(b);
      try {
         var st = o.state(), G = (typeof o.geom === "function") ? o.geom() : S.geom();
         cshPillsPaint(g, G, st.cur, { enabled: st.enabled, hover: b.csHover });
      } finally { g.end(); }
   };
   S.sync = function() {
      var st = o.state(), key = [st.key, scale()].join("|");
      try { b.toolTip = st.tip; } catch (e0) {}
      try { b.enabled = st.enabled; } catch (e1) {}
      try { b.cursor = new Cursor(st.enabled ? StdCursor_PointingHand : StdCursor_Arrow); } catch (e2) {}
      b.csTipKey = st.tipKey;
      if (typeof o.place === "function") o.place(); else S.place();
      if (key !== b.csKey) { b.csKey = key; try { b.repaint(); } catch (e3) {} }
   };
   // (sonda del 30-oct: sin esto la hoja del dialogo lo rellena y se pierde la foto de alrededor; y en Cabra3D / CabraStarAnalysis, cuyo visor lleva
   // «border: 1px solid» sin selector, el borde se hereda y dibujaba un marco rectangular alrededor de las pildoras: capturas c3_conmutador_*, 30-oct)
   if (!cshPillsBroken("opaque")) b.styleSheet = cshPillsBroken("border") ? "background: transparent;" : "background: transparent; border: none;";
   b.csHover = ""; b.csKey = ""; b.csW = 0; b.csH = 0; b.csTipKey = "";
   b.cursor = new Cursor(StdCursor_PointingHand);
   try { b.mouseTracking = true; } catch (eM) {}
   b.onMouseMove = function(x, y) { var k = (typeof o.pillAt === "function") ? o.pillAt(x) : S.pillAt(x); if (k !== b.csHover) { b.csHover = k; try { b.repaint(); } catch (e) {} } };
   b.onLeave = function() { b.csHover = ""; try { b.repaint(); } catch (e) {} };
   b.onMousePress = function(x, y) { var k = (typeof o.pillAt === "function") ? o.pillAt(x) : S.pillAt(x); if (k && o.state().enabled) o.onPick(k); };
   b.onPaint = function() { if (typeof o.paint === "function") o.paint(); else S.paint(); };
   S.ctl = b;
   return S;
}
#endif
