// ============================================================================
// CabraShared/csh_ffmpeg.js — ffMPEG SOLO SI EL USUARIO LO ELIGE (3-nov-2026, reglas CPD 5.3 y 6.1; correccion C3)
// ----------------------------------------------------------------------------
// ffmpeg es un programa externo que NO viene con los scripts. La regla CPD 5.3(b) permite lanzarlo solo si el usuario lo ha
// instalado Y LO HA ELEGIDO (con un selector de fichero, o con una opcion explicita de «buscalo tu»). Hasta el 3-nov los scripts
// lo buscaban solos (variable de entorno, ruta recordada, PATH, winget) y lo lanzaban al grabar un video sin preguntar.
//
// UN AJUSTE CON TRES ESTADOS, recordado en Settings con la clave de cada script (<prefijo>/Video/ffmpegMode):
//   "off"    — NO usar ffmpeg: el video sale en AVI (Motion JPEG), que el script escribe solo. ES EL DE FABRICA (si nunca se eligio):
//              funciona en cualquier sistema sin nada instalado y no lanza ningun programa externo. Elegido asi por la regla
//              CPD 5.3 (nada externo sin que el usuario lo elija) y porque el AVI ya es el camino de serie de los tres scripts.
//   "manual" — el usuario ELIGE EL EJECUTABLE con un selector de fichero (cshFfmpegPick); la ruta se recuerda
//              (<prefijo>/Video/ffmpegManual). Solo se usa esa ruta; si ya no existe, se graba en AVI y se dice.
//   "auto"   — «que el programa lo busque»: lo que hacian los scripts hasta el 3-nov, ahora solo si el usuario lo pide:
//              la variable CABRAPILOT_FFMPEG, la ultima ruta encontrada (<prefijo>/Video/ffmpeg), las carpetas del PATH y,
//              en Windows, las de winget (%LOCALAPPDATA%/Microsoft/WinGet/Links y Packages/Gyan.FFmpeg*).
// Solo con "manual" o "auto" se lanza ffmpeg (para pasar el AVI propio a MP4, H.264).
//
// API
//   cshFfmpegMode(prefix)                 -> "off" | "manual" | "auto"   (lo guardado; "off" si nunca se eligio)
//   cshFfmpegSetMode(prefix, mode)        -> guarda (salvo CSH_FFMPEG_REMEMBER = false: las pruebas no tocan lo de verdad)
//   cshFfmpegManualPath(prefix) / cshFfmpegSetManualPath(prefix, path)
//   cshFfmpegFind(prefix, o)              -> { available, path, probe (ffprobe al lado, si esta), from, mode, why }
//        o = { mode (en vez de lo guardado), env(name), exists(path), dirs(pattern) (pruebas), remember }
//        from: "off" | "manual" | "CABRAPILOT_FFMPEG" | "remembered" | "PATH" | "winget-link" | "winget-package" | "" (no encontrado)
//   cshFfmpegSearch(o)                    -> la busqueda de "auto", sola (pura con los ganchos de `o`)
//   cshFfmpegPick(prefix, current)        -> la ruta elegida o null (OpenFileDialog; CSH_FFMPEG_PICK_HOOK en pruebas)
//   cshFfmpegModeText(mode) / CSH_FFMPEG_MODES -> los textos de la interfaz (EN; la traduccion ES va en el i18n de cada script)
// COSTURAS: CSH_FFMPEG_FORCE_MODE (pruebas y herramientas de grabacion de Nino: un modo fijo sin tocar Settings) ·
//   CSH_FFMPEG_BREAK = "oldauto" -> el comportamiento de antes del 3-nov (siempre "auto"): el control en rojo de tests/c3_cpd.js.
// ES5. Sin «barra asterisco» en ningun comentario (el preprocesador de PJSR se come el resto del fichero).
// ============================================================================
#ifndef __CSH_FFMPEG_JS
#define __CSH_FFMPEG_JS

var CSH_FFMPEG_MODES = ["off", "manual", "auto"];
var CSH_FFMPEG_DEFAULT = "off";
var CSH_FFMPEG_FORCE_MODE = null;
var CSH_FFMPEG_BREAK = "";
var CSH_FFMPEG_REMEMBER = true;
var CSH_FFMPEG_PICK_HOOK = null;     // pruebas: function(current) -> ruta | null, en lugar del cuadro de elegir fichero

function cshFfmpegKey(prefix, leaf) { return String(prefix || "CabraScripts") + "/Video/" + leaf; }
function cshFfmpegRead(key) {
   try { var v = Settings.read(key, DataType_String); if (Settings.lastReadOK !== false && v !== null && v !== undefined) return String(v); } catch (e) {}
   return "";
}
function cshFfmpegWrite(key, value) {
   if (CSH_FFMPEG_REMEMBER !== true) return false;
   try { Settings.write(key, DataType_String, String(value)); return true; } catch (e) { return false; }
}
function cshFfmpegMode(prefix) {
   if (CSH_FFMPEG_BREAK === "oldauto") return "auto";
   if (typeof CSH_FFMPEG_FORCE_MODE === "string" && CSH_FFMPEG_MODES.indexOf(CSH_FFMPEG_FORCE_MODE) >= 0) return CSH_FFMPEG_FORCE_MODE;
   var m = cshFfmpegRead(cshFfmpegKey(prefix, "ffmpegMode"));
   return (CSH_FFMPEG_MODES.indexOf(m) >= 0) ? m : CSH_FFMPEG_DEFAULT;
}
function cshFfmpegSetMode(prefix, mode) {
   if (CSH_FFMPEG_MODES.indexOf(mode) < 0) return false;
   return cshFfmpegWrite(cshFfmpegKey(prefix, "ffmpegMode"), mode);
}
function cshFfmpegManualPath(prefix) { return cshFfmpegRead(cshFfmpegKey(prefix, "ffmpegManual")).split("\\").join("/"); }
function cshFfmpegSetManualPath(prefix, path) { return cshFfmpegWrite(cshFfmpegKey(prefix, "ffmpegManual"), String(path || "").split("\\").join("/")); }

function cshFfmpegEnv(name) {
   try { var v = (typeof System !== "undefined" && typeof System.getEnvironmentVariable === "function") ? System.getEnvironmentVariable(name) : ""; return (typeof v === "string") ? v : ""; } catch (e) { return ""; }
}
function cshFfmpegExists(p) { try { return p.length > 0 && File.exists(p); } catch (e) { return false; } }
function cshFfmpegDirs(pattern) {
   var list = [];
   try {
      var ff = new FileFind;
      if (ff.begin(pattern)) { do { if (ff.isDirectory === true && ff.name !== "." && ff.name !== "..") list.push(ff.name); } while (ff.next()); }
      try { ff.end(); } catch (eE) {}
   } catch (e) {}
   list.sort();
   return list;
}
function cshFfmpegClean(p) { return String(p || "").replace(/^\s*"?|"?\s*$/g, "").split("\\").join("/"); }

// LA BUSQUEDA de "auto" (la de video_avi.js hasta el 3-nov, sin cambios de orden). o = { env, exists, dirs, remembered }
// -> { path, from } (path "" si no hay)
function cshFfmpegSearch(o) {
   o = o || {};
   var env = o.env || cshFfmpegEnv, ok = o.exists || cshFfmpegExists, dirs = o.dirs || cshFfmpegDirs, c, i;
   var local = cshFfmpegClean(env("LOCALAPPDATA")), raw = String(env("PATH") || ""), win = (local.length > 0 || raw.indexOf(";") >= 0), exe = win ? "ffmpeg.exe" : "ffmpeg";
   c = cshFfmpegClean(env("CABRAPILOT_FFMPEG"));
   if (ok(c)) return { path: c, from: "CABRAPILOT_FFMPEG" };
   c = cshFfmpegClean(o.remembered || "");
   if (ok(c)) return { path: c, from: "remembered" };
   var list = raw.split(win ? ";" : ":");
   for (i = 0; i < list.length; ++i) {
      var d = cshFfmpegClean(list[i]);
      if (d.length === 0) continue;
      c = d + ((d.charAt(d.length - 1) === "/") ? "" : "/") + exe;
      if (ok(c)) return { path: c, from: "PATH" };
   }
   if (local.length > 0) {
      c = local + "/Microsoft/WinGet/Links/" + exe;
      if (ok(c)) return { path: c, from: "winget-link" };
      var base = local + "/Microsoft/WinGet/Packages", pk = dirs(base + "/Gyan.FFmpeg*");
      for (i = pk.length - 1; i >= 0; --i) {
         c = base + "/" + pk[i] + "/bin/" + exe;
         if (ok(c)) return { path: c, from: "winget-package" };
         var sub = dirs(base + "/" + pk[i] + "/" + "*");      // (el comodin, aparte: ver el aviso de la cabecera)
         for (var j = sub.length - 1; j >= 0; --j) {
            c = base + "/" + pk[i] + "/" + sub[j] + "/bin/" + exe;
            if (ok(c)) return { path: c, from: "winget-package" };
         }
      }
   }
   return { path: "", from: "" };
}

function cshFfmpegFind(prefix, o) {
   o = o || {};
   var mode = (typeof o.mode === "string" && CSH_FFMPEG_MODES.indexOf(o.mode) >= 0) ? o.mode : cshFfmpegMode(prefix);
   var ok = o.exists || cshFfmpegExists;
   var out = { available: false, path: "", probe: "", from: "", mode: mode, why: "" };
   function found(p, from) {
      out.available = true; out.path = p; out.from = from;
      var probe = p.replace(/ffmpeg(\.exe)?$/i, function(m, ext) { return "ffprobe" + (ext || ""); });
      if (probe !== p && ok(probe)) out.probe = probe;
      return out;
   }
   try {
      if (mode === "off") { out.from = "off"; out.why = "ffmpeg is not used (chosen: AVI)"; return out; }
      if (mode === "manual") {
         var mp = cshFfmpegClean((typeof o.manual === "string") ? o.manual : cshFfmpegManualPath(prefix));
         if (mp.length === 0) { out.why = "no ffmpeg executable chosen"; return out; }
         if (!ok(mp)) { out.why = "the chosen ffmpeg is not there: " + mp; return out; }
         return found(mp, "manual");
      }
      var r = cshFfmpegSearch({ env: o.env, exists: o.exists, dirs: o.dirs, remembered: (typeof o.remembered === "string") ? o.remembered : cshFfmpegRead(cshFfmpegKey(prefix, "ffmpeg")) });
      if (r.path.length === 0) { out.why = "ffmpeg not found (environment, PATH, winget)"; return out; }
      if (o.remember !== false) cshFfmpegWrite(cshFfmpegKey(prefix, "ffmpeg"), r.path);
      return found(r.path, r.from);
   } catch (e) { out.why = String(e); }
   return out;
}

// EL SELECTOR DEL EJECUTABLE (solo con pantalla; las pruebas contestan con CSH_FFMPEG_PICK_HOOK). -> ruta o null
function cshFfmpegPick(prefix, current) {
   if (typeof CSH_FFMPEG_PICK_HOOK === "function") { var h = CSH_FFMPEG_PICK_HOOK(current); return h ? cshFfmpegClean(h) : null; }
   try { if (typeof cshInteractive === "function" && !cshInteractive()) return null; } catch (eI) {}
   var d = new OpenFileDialog;
   d.caption = (typeof cshT === "function") ? cshT("Choose the ffmpeg executable") : "Choose the ffmpeg executable";
   d.multipleSelections = false;
   try {
      var win = (typeof cshPlatform === "function") ? (cshPlatform() === "windows") : true;
      d.filters = win ? [["ffmpeg (ffmpeg.exe)", "ffmpeg.exe"], ["Programs (*.exe)", "*.exe"]] : [["ffmpeg", "ffmpeg"], ["All files", "*"]];
   } catch (eF) {}
   try { var c = cshFfmpegClean(current || ""); if (c.length > 0) d.initialPath = c; } catch (eP) {}
   if (!d.execute()) return null;
   var p = cshFfmpegClean(d.fileName);
   return (p.length > 0) ? p : null;
}

// Los textos (EN; cada script trae su ES en su i18n con estas mismas claves)
var CSH_FFMPEG_TEXT = {
   off: "AVI (no ffmpeg)",
   manual: "MP4 · ffmpeg chosen by me…",
   auto: "MP4 · find ffmpeg for me",
   tip: "Video format. AVI (Motion JPEG) is written by the script itself and needs nothing else (default). " +
        "MP4 (H.264, what phones and social networks play) needs ffmpeg, a free program that is NOT part of this script: " +
        "«chosen by me» uses the ffmpeg executable you pick with the «…» button; «find ffmpeg for me» looks for it in " +
        "CABRAPILOT_FFMPEG, the last path found, the PATH and, on Windows, the winget folders. ffmpeg is only run when you choose " +
        "one of the two MP4 options, to turn the recorded AVI into MP4 (see the documentation: Network, external programs and files)."
};
function cshFfmpegModeText(mode) { return CSH_FFMPEG_TEXT[mode] || mode; }

#endif
