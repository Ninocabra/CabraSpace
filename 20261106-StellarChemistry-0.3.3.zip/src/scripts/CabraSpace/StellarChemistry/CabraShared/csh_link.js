// ============================================================================
// CabraShared/csh_link.js — ABRIR SIMBAD (O CUALQUIER URL) EN EL NAVEGADOR (26-oct-2026)
// ----------------------------------------------------------------------------
// Parte PURA del enlace de la ficha de Cabra3D (Cabra3D/src/ui/star_link.js, líneas 1-104 del 26-oct), sacada aquí para que la usen
// todos los scripts (Cabra3D, CabraStars, CabraComposition). Sin widgets, sin estado del diálogo: solo armar la URL y abrirla.
//
// A QUÉ SITIO VA (https://simbad.cds.unistra.fr/simbad/sim-id?Ident=<id URL-codificado>), criterio de quien llama:
//   · estrella con nombre común de Hipparcos (IAU: «Alcyone»)  → ese nombre (alias de SIMBAD; medido con curl el 26-oct)
//   · estrella de Hipparcos sin nombre propio                   → «HIP <n>»
//   · cualquier otra con su source_id de Gaia                   → «Gaia DR3 <source_id>» SI SIMBAD la tiene; si no, AladinLite en su posición (29-oct)
//   · sin identificador                                         → SIMBAD por coordenadas (sim-coo), radio de 3″ si hay algo; si no, AladinLite (29-oct)
//   (29-oct-2026, opción B de Nino) y si SIMBAD la conoce y tiene artículo en Wikipedia (Wikidata P3083), la Wikipedia en el idioma de la
//   interfaz. Todo se decide AL CLIC (cshLinkResolve); antes del 29-oct la alternativa era el registro de VizieR («puros números», Nino).
//
// CÓMO SE ABRE: ExternalProcess.startDetached(rundll32.exe, ["url.dll,FileProtocolHandler", url]) (bajo V8, programa + lista de argumentos; sin
// shell, así que ni «%» ni «+» ni «&» de la URL se interpretan). MEDIDO el 26-oct desde PowerShell: rundll32 url.dll,FileProtocolHandler abrió una
// ventana nueva de Chrome; «explorer.exe <url>» NO (abrió «Documentos» del Explorador): refutado.
//
// API (opt de cshOpenUrl, todo opcional):
//   hook   : function(url) — la recoge en lugar de abrir (pruebas)
//   real   : true — abre de verdad aunque noMain diga que es prueba
//   noMain : true — estamos en prueba (CP_NO_MAIN): NO abre, solo apunta en CSH_LINK_LOG (salvo real)
//   probe  : function(entry) → "<main_id>" | true | false | null — dice si SIMBAD tiene la estrella EN LUGAR de preguntarle (pruebas; ver cshLinkProbe)
//   wiki   : function(main_id) → { es, en } | false | null — lo que contesta Wikidata EN LUGAR de preguntarle (pruebas; o CSH_LINK_WIKI_HOOK)
//   exe/pre: otro programa (y sus argumentos previos a la URL) en lugar de rundll32.exe
//   dry    : true — arma la orden y NO la lanza; out.exe / out.args la dicen
//   broken : cadena con "noopen" (el clic no abre), "url" (la URL va sin codificar), "nofallback" (siempre SIMBAD, sin pregunta), "noaladin"
//            (la alternativa de antes: el registro de VizieR) y/o "nowiki" (nunca Wikipedia): costuras rojas
// Devuelve { ok, url (la FINAL), requested (la pedida, si cambió), dest: "" | "simbad" | "wiki" | "aladin" | "gaia", via: "noopen" | "hook" | "logged" | "rundll32" | "exe"
//   | "pixinsight" | "system" (3-nov, con csh_web.js), why, exe, args }.
// (3-nov-2026, CPD C10) Si el script incluye csh_web.js (FieldDepth3D), se abre en el navegador de PixInsight (Dialog.openBrowser) y Aladin
// en el del sistema de cada plataforma; sin él (los demás scripts), como antes: rundll32.
// Requiere cshEnv (csh_net.js) para %SystemRoot%; si no está, usa C:/Windows.
// ES5. (OJO: ninguna «barra asterisco» en un comentario: el preprocesador de PJSR se traga el resto del fichero SIN error.)
// ============================================================================

// (27-oct-2026, Nino: «la página de SIMBAD que se abre no encuentra información») LA CAUSA, MEDIDA el 27-oct con TAP de SIMBAD sobre una muestra al
// azar de Gaia DR3 en el campo de las Pléyades (150 por intervalo): SIMBAD tiene entrada para el 97 % de las de G 9-12, el 85 % de G 12-14,
// el 18 % de G 14-16 y el 9 % de G 16-18; «Identifier not found in the database : Gaia DR3 <id>» es lo que sale para el resto. Los nombres de la
// IAU (410 de 410) y HIP no fallan. SIMBAD sigue siendo el destino de lo que SÍ tiene (la página más legible: tipo, designaciones, fotometría,
// bibliografía); si no lo tiene, el destino es el REGISTRO DE LA FUENTE en VizieR (I/355/gaiadr3, «VizieR-5»: todas las columnas de Gaia DR3
// con su explicación y su unidad), que existe para CUALQUIER fuente de Gaia. Se decide AL CLIC con una consulta pequeña a SIMBAD (TAP, ~0,2 s);
// ver cshLinkFallback / cshLinkResolve. GAIA_RS = el radio (″) del cono cuando no hay source_id (la posición de Gaia es J2016,0).
var CSH_LINK = { SIMBAD_ID: "https://simbad.cds.unistra.fr/simbad/sim-id?Ident=", SIMBAD_COO: "https://simbad.cds.unistra.fr/simbad/sim-coo?Radius=3&Radius.unit=arcsec&Coord=",
                 SIMBAD_TAP: (typeof CSH_SIMBAD_CDS === "string") ? CSH_SIMBAD_CDS : "https://simbad.cds.unistra.fr/simbad/sim-tap/sync", COO_ARCSEC: 3,      // (28-oct) la MISMA URL que la reserva de csh_net.js (una sola)
                 GAIA_REC: "https://vizier.cds.unistra.fr/viz-bin/VizieR-5?-source=I/355/gaiadr3&Source=",
                 GAIA_CONE: "https://vizier.cds.unistra.fr/viz-bin/VizieR-5?-source=I/355/gaiadr3&-c=", GAIA_RS: 4,
                 // (29-oct-2026, opción B de Nino) ver «Wikipedia y Aladin» más abajo
                 ALADIN: "https://aladin.cds.unistra.fr/AladinLite/?target=", ALADIN_FOV: 0.1, ALADIN_SURVEY: "P/DSS2/color",
                 WIKIDATA: "https://query.wikidata.org/sparql?format=json&query=", UA_SUFFIX: "CabraSpace-scripts (https://cabraspace.com)" };
// (6-nov-2026, revision PTeam CPD) EL User-Agent EMPIEZA POR EL DE PIXINSIGHT (CoreApplication.agentName) y despues va el nuestro.
// Se calcula al pedir (no al cargar: las pruebas de node cargan este fichero sin CoreApplication); sin CoreApplication, "PixInsight".
function cshLinkUserAgent() {
   var agent = "";
   try { if (typeof CoreApplication !== "undefined" && CoreApplication && CoreApplication.agentName) agent = String(CoreApplication.agentName); } catch (e) { agent = ""; }
   if (!agent) agent = "PixInsight";
   return agent + " " + CSH_LINK.UA_SUFFIX;
}
var CSH_LINK_LOG = [];            // las URL pedidas (las pruebas las leen)
var CSH_LINK_ALT = {};            // url de SIMBAD de una estrella dudosa -> { kind, key, sql, alt } (cshLinkFallback)
var CSH_LINK_SEEN = {};           // lo que SIMBAD ya contestó: clave -> true (la tiene) | false (no la tiene)
var CSH_LINK_PROBE_LOG = [];      // las consultas hechas a SIMBAD (las pruebas las leen)
var CSH_LINK_PROBE_TIMEOUT_S = 6;
var CSH_LINK_VIA = {};            // (28-oct) clave -> el servidor del ESPEJO que contestó (si el CDS no contestó); sin clave = el CDS (o nadie)
var CSH_LINK_PROBE_HOOK = null;   // pruebas: function(entry) → "<main_id>" | true | false | null en lugar de preguntar a SIMBAD (vale para el clic de cualquier script)
// (29-oct-2026, opción B) Wikipedia y Aladin
var CSH_LINK_MAIN = {};           // clave -> el main_id de SIMBAD («* eta Tau»), si SIMBAD la tiene
var CSH_LINK_WIKI = {};           // main_id (espacios juntos) -> { es, en } (URL de Wikipedia, "" si no hay en ese idioma) | false (sin artículo)
var CSH_LINK_WIKI_LOG = [];       // las preguntas a Wikidata (las pruebas las leen): { main, wiki }
var CSH_LINK_WIKI_HOOK = null;    // pruebas: function(main_id) → { es, en } | false (sin artículo) | null (Wikidata no contestó) en lugar de la red
var CSH_LINK_WIKI_TIMEOUT_S = 4;  // el clic no puede colgar la interfaz: Wikidata contesta en 0,1-0,6 s (medido el 29-oct); si no, SIMBAD
var CSH_LINK_DEST = {};           // clave -> "wiki" | "simbad": a dónde fue el último clic de una estrella que SIMBAD tiene

function cshLinkHas(broken, k) { return (typeof broken === "string") && broken.length > 0 && broken.indexOf(k) >= 0; }

// --- las URL ----------------------------------------------------------------------------------------------------------------------------
function cshSimbadIdUrl(ident, broken) {
   var id = String(ident);
   return CSH_LINK.SIMBAD_ID + (cshLinkHas(broken, "url") ? id : encodeURIComponent(id));
}
function cshSimbadCooUrl(raDeg, decDeg) {
   var c = raDeg.toFixed(6) + " " + ((decDeg >= 0) ? "+" : "") + decDeg.toFixed(6);
   return CSH_LINK.SIMBAD_COO + encodeURIComponent(c);
}
// El registro de la fuente de Gaia DR3 en VizieR (todas las columnas, con su explicación): por source_id, o por cono sobre la posición de Gaia.
function cshGaiaRecordUrl(sourceId) { return CSH_LINK.GAIA_REC + encodeURIComponent(String(sourceId)); }
function cshGaiaConeUrl(raDeg, decDeg) {
   var c = raDeg.toFixed(6) + " " + ((decDeg >= 0) ? "+" : "") + decDeg.toFixed(6);
   return CSH_LINK.GAIA_CONE + encodeURIComponent(c) + "&-c.rs=" + CSH_LINK.GAIA_RS;
}

// --- Wikipedia y Aladin (29-oct-2026, opción B de Nino) ----------------------------------------------------------------------------------------
// Nino: para una estrella anónima de Gaia (SIMBAD no la conoce) el registro de VizieR son «puros números». Ahora, decidido AL CLIC:
//   · SIMBAD NO la conoce                         → AladinLite centrado en ella (imágenes reales del cielo, DSS en color, campo de 0,1°)
//   · SIMBAD la conoce y tiene artículo           → Wikipedia en el idioma de la interfaz (es si ES, en si no; si no hay en ese, la otra)
//   · SIMBAD la conoce y no hay artículo          → SIMBAD, como antes (también si Wikidata no contesta a tiempo)
// LA URL DE ALADIN (NO VERIFICADA EN VIVO el 29-oct: TODO el CDS —aladin, simbad, vizier, alasky— no contestaba, ni conexión): la forma
// ?target=<ra dec en grados>&fov=<grados>&survey=<HiPS> sale del código de la propia página (js/app.js de AladinLite, copia del 15-oct-2026 en
// web.archive.org): lee `target`, `fov` y `survey` con getURLParam (decodeURIComponent, y «+» crudo = espacio: por eso el «+» de la
// declinación va codificado, %2B); sin `survey` pone 'P/DSS2/color', el que se pide aquí explícitamente.
// WIKIPEDIA: Wikidata, propiedad P3083 (SIMBAD ID) = el main_id de SIMBAD. MEDIDO el 29-oct con curl: SIMBAD da «*  17 Tau» (dos espacios
// para alinear) y Wikidata guarda «* 17 Tau» (uno): con el main_id tal cual no casa. Se preguntan las dos formas (VALUES). Wikidata con un
// User-Agent vacío contesta 403 («Please set a user-agent»): se manda el de PixInsight seguido del nuestro (cshLinkUserAgent). format=json (Accept no hace falta).
function cshAladinUrl(raDeg, decDeg) {
   var c = raDeg.toFixed(6) + " " + ((decDeg >= 0) ? "+" : "") + decDeg.toFixed(6);
   return CSH_LINK.ALADIN + encodeURIComponent(c) + "&fov=" + CSH_LINK.ALADIN_FOV + "&survey=" + encodeURIComponent(CSH_LINK.ALADIN_SURVEY);
}
function cshSimbadMainNorm(m) { return String(m).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }
function cshLinkSqlStr(s) { return "'" + String(s).replace(/'/g, "''") + "'"; }
function cshLinkSparqlStr(s) { return "\"" + String(s).replace(/\\/g, "\\\\").replace(/"/g, "\\\"") + "\""; }
function cshWikidataSparql(main) {
   var raw = String(main), nm = cshSimbadMainNorm(main), vals = cshLinkSparqlStr(nm) + ((raw !== nm) ? " " + cshLinkSparqlStr(raw) : "");
   return "SELECT ?es ?en WHERE { VALUES ?v { " + vals + " } ?i wdt:P3083 ?v . " +
          "OPTIONAL { ?es schema:about ?i ; schema:isPartOf <https://es.wikipedia.org/> } " +
          "OPTIONAL { ?en schema:about ?i ; schema:isPartOf <https://en.wikipedia.org/> } }";
}
// La respuesta JSON de Wikidata -> { es, en } · false (contestó: no hay artículo ni en es ni en en) · null (no es una respuesta de SPARQL)
function cshWikidataParse(text) {
   var j = null;
   try { j = JSON.parse(String(text)); } catch (eJ) { return null; }
   if (!j || !j.results || !j.results.bindings || typeof j.results.bindings.length !== "number") return null;
   var b = j.results.bindings;
   for (var i = 0; i < b.length; ++i) {
      var es = (b[i].es && b[i].es.value) ? String(b[i].es.value) : "", en = (b[i].en && b[i].en.value) ? String(b[i].en.value) : "";
      if (es.length > 0 || en.length > 0) return { es: es, en: en };
   }
   return false;
}
// El artículo en el idioma de la interfaz; si no lo hay, el del otro. "" si ninguno.
function cshWikiPick(w) {
   if (!w) return "";
   var es = (typeof cshLangIsEs === "function") ? cshLangIsEs() : false, a = es ? w.es : w.en, b = es ? w.en : w.es;
   return (a && String(a).length > 0) ? String(a) : (b && String(b).length > 0) ? String(b) : "";
}
// ¿Tiene artículo? { es, en } · false · null (no contestó). Memoria por main_id (lo que contesta, sí o no; un silencio no se recuerda).
function cshLinkWiki(main, o, net) {
   var k = cshSimbadMainNorm(main);
   if (CSH_LINK_WIKI.hasOwnProperty(k)) return CSH_LINK_WIKI[k];
   var hook = (o && typeof o.wiki === "function") ? o.wiki : CSH_LINK_WIKI_HOOK, w = null;
   if (typeof hook === "function") {
      try { w = hook(k, String(main)); } catch (eH) { w = null; }
      if (w && !(w.es || w.en)) w = false;
   } else if (net === true && typeof cpSfHttpText === "function") {
      var r = cpSfHttpText(CSH_LINK.WIKIDATA + encodeURIComponent(cshWikidataSparql(main)),
                           { timeoutS: CSH_LINK_WIKI_TIMEOUT_S, connectTimeoutS: 3, what: "wikidata", headers: ["User-Agent: " + cshLinkUserAgent()] });
      if (r && r.ok) w = cshWikidataParse(r.text);
   }
   CSH_LINK_WIKI_LOG.push({ main: k, wiki: w });
   if (w !== null && w !== undefined) CSH_LINK_WIKI[k] = w;
   return (w === undefined) ? null : w;
}

// --- SIMBAD si la estrella está allí; si no, el registro de Gaia (27-oct-2026) ----------------------------------------------------------------
// Las funciones `xLinkOfStar` de cada script arman el enlace como siempre ({ text, ident, url } con la URL de SIMBAD) y lo pasan por aquí:
//   cshLinkFallback(link, { ra, dec })  → si el enlace es de una estrella sin nombre de Hipparcos (ident «Gaia DR3 <id>», o sin id y por
//     coordenadas), apunta en CSH_LINK_ALT[link.url] la alternativa y la consulta que dice si SIMBAD la tiene; devuelve el mismo enlace
//     (con link.alt = la URL de Gaia). Un nombre de la IAU o «HIP n» NO se toca: SIMBAD siempre los tiene.
//   cshOpenUrl(url) mira CSH_LINK_ALT al abrir (ver abajo): así los cuatro scripts siguen llamando a su cshOpenUrl con link.url, sin cambiar sus clics.
// (29-oct, opción B) la alternativa es AladinLite en la posición de la estrella (`gaia` guarda el registro de VizieR de antes: el rojo «noaladin»
// y las estrellas sin posición). Los nombres de la IAU y «HIP n» TAMBIÉN se preguntan ahora (kind "name", sin alternativa: SIMBAD los tiene
// siempre), para saber su main_id y si tienen artículo en Wikipedia. Las consultas devuelven SIEMPRE main_id (la llave de Wikidata).
function cshLinkFallback(link, star) {
   if (!link || typeof link.url !== "string") return link;
   var st = star || {}, m = /^Gaia DR3 (\d{6,20})$/.exec(String(link.ident)), e = null, hasPos = isFinite(st.ra) && isFinite(st.dec);
   var J = "SELECT TOP 1 main_id FROM basic JOIN ident ON ident.oidref = basic.oid WHERE ident.id ";
   if (link.url.indexOf(CSH_LINK.SIMBAD_ID) === 0 && m) {
      var gr = cshGaiaRecordUrl(m[1]);
      e = { kind: "id", key: "id:" + m[1], alt: hasPos ? cshAladinUrl(st.ra, st.dec) : gr, gaia: gr, ident: "Gaia DR3 " + m[1],
            sql: J + "= 'Gaia DR3 " + m[1] + "'", col: "main_id" };
   } else if (link.url.indexOf(CSH_LINK.SIMBAD_COO) === 0 && hasPos) {
      e = { kind: "coo", key: "coo:" + st.ra.toFixed(5) + "," + st.dec.toFixed(5), alt: cshAladinUrl(st.ra, st.dec), gaia: cshGaiaConeUrl(st.ra, st.dec), ident: String(link.ident),
            sql: "SELECT TOP 1 main_id FROM basic WHERE 1=CONTAINS(POINT('ICRS',ra,dec),CIRCLE('ICRS'," + st.ra.toFixed(6) + "," + st.dec.toFixed(6) + "," + (CSH_LINK.COO_ARCSEC / 3600).toFixed(7) + "))",
            col: "main_id" };
   } else if (link.url.indexOf(CSH_LINK.SIMBAD_ID) === 0 && String(link.ident).length > 0) {
      // «HIP 17702» tal cual; un nombre de la IAU («Alcyone») está en SIMBAD como «NAME Alcyone» (medido el 29-oct en el espejo de Harvard)
      var id = String(link.ident), q = /^HIP \d+$/.test(id) ? "= " + cshLinkSqlStr(id) : "IN (" + cshLinkSqlStr(id) + ", " + cshLinkSqlStr("NAME " + id) + ")";
      e = { kind: "name", key: "name:" + id, alt: null, gaia: null, ident: id, sql: J + q, col: "main_id" };
   }
   if (e === null) return link;
   CSH_LINK_ALT[link.url] = e;
   if (e.alt) link.alt = e.alt;
   return link;
}
// ¿A dónde irá este enlace? "" (sin pregunta: SIMBAD seguro) · "simbad" · "wiki" · "aladin" · "gaia" (ya se sabe) · "unknown" (se sabrá al clic).
function cshLinkDest(link) {
   var e = cshLinkEntry(link);
   if (e === null) return "";
   if (CSH_LINK_SEEN.hasOwnProperty(e.key)) {
      if (CSH_LINK_DEST[e.key] === "wiki") return "wiki";
      if (CSH_LINK_SEEN[e.key] || e.kind === "name") return "simbad";
      return (e.alt && e.alt !== e.gaia) ? "aladin" : "gaia";
   }
   return "unknown";
}
function cshLinkEntry(link) { return (link && typeof link.url === "string" && CSH_LINK_ALT.hasOwnProperty(link.url)) ? CSH_LINK_ALT[link.url] : null; }
// ¿Por qué servidor fue la pregunta de esta estrella? "" (el CDS, o sin pregunta) · el nombre del espejo.
function cshLinkVia(link) {
   var e = (link && typeof link.url === "string" && CSH_LINK_ALT.hasOwnProperty(link.url)) ? CSH_LINK_ALT[link.url] : null;
   return (e !== null && CSH_LINK_VIA.hasOwnProperty(e.key) && CSH_LINK_SEEN[e.key] === true) ? CSH_LINK_VIA[e.key] : "";
}
// La pregunta a SIMBAD: true (la tiene) · false (no) · null (no contestó). `hook` (pruebas): function(entry) → "<main_id>" (la tiene, con ese
// nombre) | true (la tiene, sin main_id: no se pregunta a Wikidata) | false | null en lugar de la red. El main_id queda en CSH_LINK_MAIN[clave].
function cshLinkProbe(e, hook, net) {
   if (CSH_LINK_SEEN.hasOwnProperty(e.key)) return CSH_LINK_SEEN[e.key];
   var has = null, main = "";
   if (typeof hook === "function") {
      try { has = hook(e); } catch (eH) { has = null; }
      if (typeof has === "string") { main = has; has = (main.length > 0); }
   }
   else if (net === true && typeof cpSfHttpText === "function") {
      var url = CSH_LINK.SIMBAD_TAP + "?REQUEST=doQuery&LANG=ADQL&FORMAT=csv&MAXREC=1&QUERY=" + encodeURIComponent(e.sql);
      // (28-oct, B4) cpSfHttpText ya lleva la reserva de SIMBAD (csh_net.js): si el CDS no contesta, el espejo de Harvard; `r.fallback` lo dice
      var r = cpSfHttpText(url, { timeoutS: CSH_LINK_PROBE_TIMEOUT_S, connectTimeoutS: 4, what: "ident" });
      // (una tabla CSV con su cabecera: con una fila de datos la tiene; sin ella no. Cualquier otra cosa —HTML, error de TAP, nada— es «no contestó»)
      if (r.ok && cpSfLooksLikeCsv(r.text, e.col)) {
         var rows = String(r.text).replace(/\s+$/, "").split("\n");
         has = (rows.length > 1);
         if (has) main = rows[1].replace(/\r$/, "").replace(/^\s*"/, "").replace(/"\s*$/, "").replace(/""/g, "\"");
         if (r.fallback === true && typeof r.server === "string" && r.server.length > 0) CSH_LINK_VIA[e.key] = r.server;
      }
   }
   CSH_LINK_PROBE_LOG.push({ key: e.key, has: has, main: main });
   if (has === true || has === false) CSH_LINK_SEEN[e.key] = has;
   if (has === true && main.length > 0) CSH_LINK_MAIN[e.key] = main;
   return has;
}
// (28-oct-2026, B4) La página de SIMBAD en el ESPEJO de Harvard (la misma web, simbad.harvard.edu), si el CDS no contestó a la pregunta de ESTA estrella
// (CSH_LINK_VIA[key]) o, sin pregunta, si el CDS acaba de fallar y el espejo contestó (csh_net.js CSH_SIMBAD_DOWN_UNTIL). -> { url, server ("" si es el CDS) }
function cshLinkMirrorUrl(url, key) {
   var pre = "https://simbad.cds.unistra.fr/", u = String(url);
   var via = (key !== null && CSH_LINK_VIA.hasOwnProperty(key)) ? CSH_LINK_VIA[key] : "";
   if (via.length === 0 && key === null && typeof CSH_SIMBAD_DOWN_UNTIL === "number" && CSH_SIMBAD_BACKUP !== false && cshSimbadNow() < CSH_SIMBAD_DOWN_UNTIL) via = CSH_SIMBAD_MIRROR_NAME;
   if (via.length === 0 || u.indexOf(pre) !== 0) return { url: u, server: "" };
   return { url: "https://simbad.harvard.edu/" + u.substring(pre.length), server: via };
}
// La URL final de `url`. Sin pregunta registrada, la misma. Con ella (29-oct, opción B):
//   SIMBAD la tiene  → su artículo de Wikipedia si Wikidata lo da (en el idioma de la interfaz); si no hay o Wikidata no contesta, SIMBAD
//   no la tiene, o SIMBAD no contestó → AladinLite en su posición (existe para cualquier punto del cielo); sin posición, el registro de Gaia
//   un nombre de la IAU o «HIP n» → Wikipedia o SIMBAD (SIMBAD los tiene siempre, aunque la pregunta no conteste)
// `net` = ¿se puede preguntar a la red? Rojos (o.broken): "noaladin" (la alternativa de antes: VizieR) · "nowiki" (nunca Wikipedia).
function cshLinkResolve(url, o, net) {
   var e = CSH_LINK_ALT.hasOwnProperty(url) ? CSH_LINK_ALT[url] : null;
   // (28-oct, B4) sin pregunta: SIMBAD seguro, pero si el CDS acaba de no contestar y el espejo SÍ, la página va al espejo
   if (e === null) { var mw = cshLinkMirrorUrl(url, null); return { url: mw.url, dest: "", has: null, server: mw.server }; }
   var hook = (typeof o.probe === "function") ? o.probe : CSH_LINK_PROBE_HOOK, hasIt = cshLinkProbe(e, hook, net);
   // sin pregunta posible (prueba sin red ni gancho): se queda en SIMBAD y NO se anota nada
   if (hasIt === null && typeof hook !== "function" && net !== true) return { url: url, dest: "", has: null };
   if (hasIt === true || e.kind === "name") {
      var main = CSH_LINK_MAIN.hasOwnProperty(e.key) ? CSH_LINK_MAIN[e.key] : "";
      if (hasIt === true && main.length > 0 && !cshLinkHas(o.broken, "nowiki")) {
         var wk = cshLinkWiki(main, o, net), wu = cshWikiPick(wk);
         if (wu.length > 0) { CSH_LINK_DEST[e.key] = "wiki"; return { url: wu, dest: "wiki", has: true, main: main, wiki: wk }; }
      }
      if (hasIt === true) CSH_LINK_DEST[e.key] = "simbad";
      var mv = cshLinkMirrorUrl(url, (hasIt === true) ? e.key : null);
      return { url: mv.url, dest: "simbad", has: hasIt, main: main, server: mv.server };
   }
   if (cshLinkHas(o.broken, "noaladin") && e.gaia) return { url: e.gaia, dest: "gaia", has: hasIt };
   return { url: e.alt, dest: (e.alt === e.gaia) ? "gaia" : "aladin", has: hasIt };
}

// --- el aviso «Open in SIMBAD: <id>» del nombre-enlace, SIN TAPAR DATOS (27-oct-2026, D3 de Nino) ---------------------------------------------
// Nino vio en CabraComposition la burbuja bajo el cursor tapando la línea de debajo del nombre («logg»). Los tres scripts ponen ahora el aviso
// pintado por ellos (no el tooltip del sistema, que sale donde quiere) y en el MISMO sitio, decidido aquí: a la DERECHA del nombre, en su misma
// línea, si cabe y en esa línea no sigue nada (`lineEnd`: dónde acaba lo pintado en ella); si no, ENCIMA del nombre (la cabecera de la ficha,
// no un dato); y si tampoco cabe, EN LA LÍNEA DEL NOMBRE pegado al borde derecho (tapa como mucho el final del propio nombre, nunca otra línea).
// r = el rectángulo del nombre {x0, y0, x1, y1}; bw, bh = el tamaño del aviso; W, H = el área en que se pinta (sus píxeles); gap = la separación.
// Devuelve { x, y, w, h, where: "right" | "above" | "inline" }. Puro.
var CSH_LINK_TIP = { PAD_X: 6, PAD_Y: 2, GAP: 6, MARGIN: 2 };     // (píxeles lógicos)
var CSH_LINK_TIP_BREAK = "";                                       // rojo de las pruebas: "under" = el sitio de antes (bajo el cursor / el nombre)
function cshLinkTipPlace(r, bw, bh, W, H, gap, lineEnd) {
   var m = CSH_LINK_TIP.MARGIN, cy = (r.y0 + r.y1) / 2, end = Math.max(r.x1, (lineEnd > 0) ? lineEnd : 0);
   var xa = Math.round(Math.max(m, Math.min(W - m - bw, r.x0)));
   if (CSH_LINK_TIP_BREAK === "under") return { x: xa, y: Math.round(r.y1 + gap), w: bw, h: bh, where: "under" };
   var xr = end + gap, yr = Math.round(cy - bh / 2);
   // (el borde de ABAJO no baja del nombre: la línea siguiente es un dato. MEDIDO en Cabra3D, escala 1,5: el aviso centrado, 25 px en un nombre
   // de 23, pisaba 1 fila de píxeles —122 px— por encima de la línea de datos; subido lo que sobra, cae sobre el hueco bajo la cabecera)
   if (yr + bh > r.y1) yr = Math.round(r.y1 - bh);
   if (xr + bw <= W - m && yr >= m && yr + bh <= H - m) return { x: Math.round(xr), y: yr, w: bw, h: bh, where: "right" };
   var ya = Math.round(r.y0 - gap - bh);
   if (ya >= m) return { x: xa, y: ya, w: bw, h: bh, where: "above" };
   return { x: Math.round(Math.max(m, W - m - bw)), y: Math.max(m, yr), w: bw, h: bh, where: "inline" };
}
function cshLinkT(s) { return (typeof cshT === "function") ? cshT(s) : String(s); }
// El texto del aviso: «Open in SIMBAD» si el identificador es el propio nombre que se ve (no hace falta repetirlo: así cabe a su derecha), y
// «Open in SIMBAD: <id>» si no (el nombre legible de SIMBAD, «α¹ Cen A», va por «HIP 71683»; sin id, las coordenadas). `say` = el texto traducido.
// (27-oct) y DICE A DÓNDE LLEVA: «Open in SIMBAD» si SIMBAD la tiene (o es seguro: nombre de la IAU, HIP), «Open in Gaia DR3 (VizieR)» si ya se
// sabe que SIMBAD no la tiene, y «SIMBAD · Gaia DR3» mientras no se ha preguntado (se pregunta al clic, no al pasar el ratón; corto para que quepa a la derecha del nombre, F1 de Nino 27-oct).
// (29-oct, opción B) «Open in Wikipedia» · «Open the sky around it (Aladin)» cuando ya se sabe; mientras no, los sitios posibles:
// «SIMBAD · Aladin» (estrella de Gaia o por coordenadas) o «Wikipedia · SIMBAD» (nombre de la IAU, HIP). (MEDIDO el 29-oct en la ficha de
// CabraStarAnalysis, csa_test_final F2: «Wikipedia · SIMBAD · Aladin» ya no cabía a la derecha del nombre y saltaba encima; F1 de Nino del
// 27-oct pide corto. Una de Gaia que SIMBAD conoce y tiene artículo —rara— dice «SIMBAD · Aladin» antes del clic y «Open in Wikipedia» después.)
function cshLinkTipText(say, link) {
   var id = String(link && link.ident ? link.ident : ""), shown = String(link && link.text ? link.text : ""), dest = cshLinkDest(link), base = String(say);
   var en = cshLinkEntry(link);
   if (dest === "wiki") base = cshLinkT("Open in Wikipedia");
   else if (dest === "aladin") base = cshLinkT("Open the sky around it (Aladin)");
   else if (dest === "gaia") base = cshLinkT("Open in Gaia DR3 (VizieR)");
   else if (dest === "unknown") base = (en && en.kind === "name") ? cshLinkT("Wikipedia · SIMBAD") : cshLinkT("SIMBAD · Aladin");
   else if (dest === "simbad" && cshLinkVia(link).length > 0) base = base + " (Harvard)";      // (28-oct, B4) el CDS no contestó: la página es la del espejo
   return (id.length === 0 || id === shown) ? base : base + ": " + id;
}
// El tamaño del aviso para un texto: { w, h } (font = la letra con la que se pinta; sc = la escala de la interfaz).
function cshLinkTipSize(font, text, sc) {
   var px = Math.round(CSH_LINK_TIP.PAD_X * sc), py = Math.round(CSH_LINK_TIP.PAD_Y * sc);
   return { w: font.width(String(text)) + 2 * px, h: (font.ascent + font.descent) + 2 * py };
}
// Pinta el aviso en `pl` (lo de cshLinkTipPlace). col = { bg, border, text } (enteros ARGB, los de la estética de cada script).
function cshLinkTipPaint(g, pl, text, font, sc, col) {
   var px = Math.round(CSH_LINK_TIP.PAD_X * sc), py = Math.round(CSH_LINK_TIP.PAD_Y * sc), rr = Math.max(2, Math.round(4 * sc));
   g.antialiasing = true;
   g.pen = new Pen(col.border, Math.max(1, Math.round(sc)));
   g.brush = new Brush(col.bg);
   try { g.drawRoundedRect(pl.x + 0.5, pl.y + 0.5, pl.x + pl.w - 0.5, pl.y + pl.h - 0.5, rr, rr); } catch (eR) { g.drawRect(pl.x, pl.y, pl.x + pl.w, pl.y + pl.h); }
   g.font = font; g.pen = new Pen(col.text);
   g.drawText(pl.x + px, pl.y + py + font.ascent, String(text));
}

// --- abrir el navegador -----------------------------------------------------------------------------------------------------------------
function cshOpenUrl(url, opt) {
   var o = opt || {};
   var out = { ok: false, url: String(url), via: "", why: "", dest: "" };
   if (cshLinkHas(o.broken, "noopen")) { CSH_LINK_LOG.push(out.url); out.via = "noopen"; out.why = "red: no abre"; return out; }
   var useExe = (typeof o.exe === "string" && o.exe.length > 0);
   // (27-oct) SIMBAD o el registro de Gaia: solo se pregunta a la red si el clic va a abrir de verdad (una prueba sin gancho de `probe` no toca la red)
   var net = !(typeof o.hook === "function") && !(o.noMain === true && o.real !== true) && o.dry !== true && !useExe;
   var rs = cshLinkHas(o.broken, "nofallback") ? { url: out.url, dest: "", has: null } : cshLinkResolve(out.url, o, net);      // (rojo «nofallback»: el clic de antes, siempre SIMBAD)
   if (rs.url !== out.url) { out.requested = out.url; out.url = rs.url; }
   out.dest = rs.dest; out.server = rs.server || "";      // (28-oct, B4) "SIMBAD (Harvard mirror)" si la página es la del espejo
   CSH_LINK_LOG.push(out.url);
   if (typeof o.hook === "function") { try { o.hook(out.url); out.ok = true; } catch (eH) { out.why = String(eH); } out.via = "hook"; return out; }
   if (o.noMain === true && o.real !== true) { out.ok = true; out.via = "logged"; return out; }
   var exe = useExe ? o.exe : "", pre = useExe ? ((o.pre && o.pre.length) ? o.pre : []) : [];
   // (3-nov-2026, CPD C10; Nino: «con el navegador que trae PixInsight») si el script incluye csh_web.js, la pagina se abre en el
   // «PixInsight Web Browser» (Dialog.openBrowser, modal; MEDIDO el 3-nov: ver csh_web.js). Aladin Lite necesita WebGL, que el motor web
   // de PixInsight no tiene (MEDIDO: tests/c3_webgl_probe.log): Aladin va al navegador del sistema. exe/args dicen siempre la reserva.
   // Costura roja: broken "rundll32" -> el navegador del sistema, como antes.
   if (!useExe && typeof cshWebOpen === "function" && !cshLinkHas(o.broken, "rundll32")) {
      var aladin = (out.dest === "aladin") || out.url.indexOf(CSH_LINK.ALADIN) === 0;
      var ttl = (out.dest === "wiki") ? "Wikipedia" : aladin ? "Aladin Lite (CDS)" : (out.dest === "gaia") ? "Gaia DR3 (VizieR)" : (out.server || "SIMBAD");
      var w = cshWebOpen(out.url, { title: ttl, noMain: false, webgl: aladin, dry: o.dry === true });
      out.ok = w.ok; out.via = w.via; out.exe = w.exe; out.args = w.args; if (w.why) out.why = w.why;
      return out;
   }
   if (!useExe && typeof cshSystemBrowser === "function") {
      var sb2 = cshSystemBrowser(out.url, { dry: true });
      exe = sb2.exe; pre = sb2.args.slice(0, sb2.args.length - 1);
      out.via = /rundll32/i.test(exe) ? "rundll32" : "system";
      useExe = true;              // (la orden ya esta armada: se lanza abajo tal cual)
   }
   if (!useExe) {
      var root = ""; try { root = (typeof cshEnv === "function") ? cshEnv("SystemRoot") : ""; } catch (eR) {}
      exe = ((root.length > 0) ? root.split("\\").join("/") : "C:/Windows") + "/System32/rundll32.exe";
      pre = ["url.dll,FileProtocolHandler"];
      out.via = "rundll32";
   } else if (!out.via) out.via = "exe";
   out.exe = exe; out.args = pre.concat([out.url]);
   if (o.dry === true) { out.ok = true; return out; }
   try { out.ok = (ExternalProcess.startDetached(exe, out.args) !== false); }
   catch (e) { out.why = String((e && e.message) ? e.message : e); out.ok = false; }
   return out;
}
