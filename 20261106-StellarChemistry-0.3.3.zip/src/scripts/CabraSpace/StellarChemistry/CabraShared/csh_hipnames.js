// ============================================================================
// CabraShared/csh_hipnames.js — LOS NOMBRES DE HIPPARCOS de una estrella de Gaia (27-oct-2026, D4 de Nino)
// ----------------------------------------------------------------------------
// Parte PURA del catálogo del planetario de Cabra3D (Cabra3D/src/tm/sky_catalog.js del 21-oct: c3SkyCatParse, c3SkyNamesParse,
// c3SkyWgsnParse, c3SkyNamesWgsn, c3SkyMatchHip, c3SkyNameOfHip, c3SkyDesigPretty, c3SkyVfromG), sacada aquí para que la ficha y el enlace a
// SIMBAD de CabraStars y CabraComposition digan «Alcyone» como Cabra3D. Cabra3D usa ESTAS funciones (sky_catalog.js las nombra con su prefijo).
//
// LOS DATOS (UNA copia, CabraShared/data/sky/, 2,47 MB): hip_bright.csv (Hipparcos I/311 + I/239 hasta V = 8, 41 394 estrellas, 2,40 MB),
// hip_names.csv (nombres de Stellarium y Bayer/Flamsteed) e iau_wgsn.csv (los nombres propios aprobados por la IAU, WGSN). Se leen UNA vez por
// sesión de PixInsight (cshHipData) y solo cuando hace falta: una estrella más débil que G = 9,5 no puede casar y no carga nada.
//
// EL CRITERIO DE CASADO (el de c3SkyMatchHip, sin cambiar nada): la posición de Hipparcos (J1991,25) llevada a J2016,0 con su movimiento propio,
// a ≤ MATCH_ARCSEC (4″) de la de Gaia, con |V_Hip − V(G, BP−RP)| < MATCH_DMAG (1,5) —V de la G y el color, Riello et al. 2021, tabla C2—, la
// más cercana; G > FIELD_GMAX_MATCH (9,5) no casa. (ra, dec) de Gaia en grados, J2016,0.
// EL NOMBRE: el propio de la IAU (WGSN); si no tiene, su Bayer/Flamsteed («α CMa», «61 Cyg»); si tampoco, «HIP n».
//
// API:
//   cshHipLookup(ra, dec, g, bpRp) -> { hip (0 = no es de Hipparcos), name (el mejor: IAU > Bayer/Flamsteed > «HIP n»; "" sin HIP),
//                                       iau (solo el nombre propio de la IAU, o "") }
//   cshHipData() -> { ok, why, cat, names, wgsn, namesDropped, ms } (en caché: CSH_HIPDATA)
//   y las piezas puras: cshHipCatParse, cshHipNamesParse, cshHipWgsnParse, cshHipNamesWgsn, cshHipMatch, cshHipNameOfHip, cshHipDesigPretty,
//   cshHipVfromG (node las carga sustituyendo la directiva de la ruta de este fichero por una cadena).
// ES5. (OJO: ninguna «barra asterisco» en un comentario: el preprocesador de PJSR se traga el resto del fichero SIN error.)
// ============================================================================

var CSH_HIP = { EPOCH_HIP: 1991.25, EPOCH: 2016.0, MATCH_ARCSEC: 4, MATCH_DMAG: 1.5, FIELD_GMAX_MATCH: 9.5 };
var CSH_HIP_FILE = #__FILE__;

// Letras griegas de la BSC (Alp, Bet, …) -> la letra.
var CSH_HIP_GREEK = { Alp: "α", Bet: "β", Gam: "γ", Del: "δ", Eps: "ε", Zet: "ζ", Eta: "η", The: "θ", Iot: "ι",
   Kap: "κ", Lam: "λ", Mu: "μ", Nu: "ν", Xi: "ξ", Omi: "ο", Pi: "π", Rho: "ρ", Sig: "σ", Tau: "τ",
   Ups: "υ", Phi: "φ", Chi: "χ", Psi: "ψ", Ome: "ω" };
var CSH_HIP_SUP = { "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹" };

function cshHipNum(s) { if (s === undefined || s === null || s === "") return NaN; var v = parseFloat(s); return isFinite(v) ? v : NaN; }

// hip_bright.csv -> columnas (Float64Array; NaN = sin dato)
function cshHipCatParse(text) {
   var L = String(text).split(/\r?\n/), rows = [], i;
   for (i = 0; i < L.length; ++i) { var l = L[i]; if (!l.length || l.charAt(0) === "#") continue; rows.push(l); }
   var n = rows.length, C = { n: n, hip: new Int32Array(n), ra: new Float64Array(n), dec: new Float64Array(n), plx: new Float64Array(n), eplx: new Float64Array(n),
                                pmra: new Float64Array(n), pmde: new Float64Array(n), v: new Float64Array(n), bv: new Float64Array(n) };
   for (i = 0; i < n; ++i) {
      var p = rows[i].split(",");
      C.hip[i] = parseInt(p[0], 10); C.ra[i] = cshHipNum(p[1]); C.dec[i] = cshHipNum(p[2]); C.plx[i] = cshHipNum(p[3]); C.eplx[i] = cshHipNum(p[4]);
      C.pmra[i] = cshHipNum(p[5]); C.pmde[i] = cshHipNum(p[6]); C.v[i] = cshHipNum(p[7]); C.bv[i] = cshHipNum(p[8]);
   }
   return C;
}
// hip_names.csv -> { hip: { name, desig } }
function cshHipNamesParse(text) {
   var L = String(text).split(/\r?\n/), out = {};
   for (var i = 0; i < L.length; ++i) {
      var l = L[i]; if (!l.length || l.charAt(0) === "#") continue;
      var p = l.split("|"); if (p.length < 3) continue;
      out[parseInt(p[0], 10)] = { name: p[1], desig: cshHipDesigPretty(p[2]) };
   }
   return out;
}
// iau_wgsn.csv -> { hip: nombre } (los nombres aprobados por la IAU, WGSN; las filas sin HIP no entran)
function cshHipWgsnParse(text) {
   var L = String(text).split(/\r?\n/), out = {};
   for (var i = 0; i < L.length; ++i) {
      var l = L[i]; if (!l.length || l.charAt(0) === "#") continue;
      var p = l.split("|"), h = parseInt(p[1], 10); if (p.length < 2 || !(h > 0)) continue;
      out[h] = p[0];
   }
   return out;
}
// (H6e de Cabra3D, 21-oct) Solo los nombres propios de la IAU: el de Stellarium se cambia por el de la WGSN si la estrella lo tiene, y se
// QUITA si no (quedan su Bayer/Flamsteed y su HIP): fuera «Alkalbain I», «Sterope II», «Navi»… Devuelve cuántos se quitaron.
function cshHipNamesWgsn(names, wgsn) {
   var dropped = 0, h;
   for (h in names) { var w = wgsn[h]; if (w) names[h].name = w; else if (names[h].name) { names[h].name = ""; ++dropped; } }
   for (h in wgsn) if (!names[h]) names[h] = { name: wgsn[h], desig: "" };
   return dropped;
}
// ¿QUÉ ESTRELLA DE HIPPARCOS ES ESTA DE GAIA? (el criterio, en la cabecera). Devuelve el número HIP, o 0 si no hay ninguna.
function cshHipMatch(cat, ra, dec, g, bpRp) {
   if (!cat || !(cat.n > 0) || !(g <= CSH_HIP.FIELD_GMAX_MATCH) || !isFinite(ra) || !isFinite(dec)) return 0;
   var k = Math.PI / 180, dt = CSH_HIP.EPOCH - CSH_HIP.EPOCH_HIP, rMatch = CSH_HIP.MATCH_ARCSEC / 3600, vf = cshHipVfromG(g, bpRp), cdf = Math.cos(dec * k), best = -1, bd = 1e9;
   for (var i = 0; i < cat.n; ++i) {
      var cde = cat.dec[i] + (isFinite(cat.pmde[i]) ? cat.pmde[i] * dt / 3.6e6 : 0), dd = cde - dec; if (dd > rMatch || dd < -rMatch) continue;
      var cd0 = Math.cos(cat.dec[i] * k), cra = cat.ra[i] + (isFinite(cat.pmra[i]) ? cat.pmra[i] * dt / 3.6e6 / Math.max(1e-6, cd0) : 0);
      var da = cra - ra; if (da > 180) da -= 360; else if (da < -180) da += 360; da *= cdf;
      if (da > rMatch || da < -rMatch) continue;
      var s = Math.sqrt(da * da + dd * dd);
      // (27-oct-2026, T3 H-1 de Codex) `s <= rMatch`: un CIRCULO de MATCH_ARCSEC, no el cuadrado que dejaban los dos cortes de arriba (la esquina llegaba a 5,66″).
      if (s <= rMatch && s < bd && Math.abs(cat.v[i] - vf) < CSH_HIP.MATCH_DMAG) { bd = s; best = i; }
   }
   return (best >= 0) ? cat.hip[best] : 0;
}
// El nombre de una estrella de Hipparcos, el mejor primero: el propio de la IAU, si no su Bayer/Flamsteed, si no «HIP n». "" sin HIP.
function cshHipNameOfHip(names, hip) {
   if (!(hip > 0)) return "";
   var N = names ? names[hip] : null;
   if (N && N.name) return N.name;
   if (N && N.desig) return N.desig;
   return "HIP " + hip;
}
// "Alp CMa" -> "α CMa"; "Alp1 Cen" -> "α¹ Cen"; "61 Cyg" igual.
function cshHipDesigPretty(d) {
   d = String(d || "").replace(/^\s+|\s+$/g, "");
   var m = /^([A-Z][a-z]{1,2})(\d?)\s+(\w+)$/.exec(d);
   if (m && CSH_HIP_GREEK[m[1]]) return CSH_HIP_GREEK[m[1]] + (m[2] ? (CSH_HIP_SUP[m[2]] || m[2]) : "") + " " + m[3];
   return d;
}
// Gaia -> Johnson: G − V = −0,02704 + 0,01424 x − 0,2156 x² + 0,01426 x³, x = BP−RP (Riello et al. 2021, tabla C2).
function cshHipVfromG(g, bpRp) {
   var x = isFinite(bpRp) ? Math.max(-0.5, Math.min(5, bpRp)) : 0.82;
   return g - (-0.02704 + 0.01424 * x - 0.2156 * x * x + 0.01426 * x * x * x);
}

// --- los datos, leídos una vez ---------------------------------------------------------------------------------------------------------
// La carpeta de los datos: CabraShared/data/sky/, junto a este fichero (vale en cualquier máquina: la ruta sale del propio fichero).
function cshHipDataDir() {
   var f = String(CSH_HIP_FILE).split("\\").join("/");
   return f.substring(0, f.lastIndexOf("/") + 1) + "data/sky/";
}
var CSH_HIPDATA = null;
function cshHipData() {
   if (CSH_HIPDATA !== null) return CSH_HIPDATA;
   var D = { ok: false, why: "", cat: null, names: {}, wgsn: null, namesDropped: 0, ms: 0 }, t0 = Date.now(), dir = cshHipDataDir();
   try {
      D.cat = cshHipCatParse(File.readTextFile(dir + "hip_bright.csv"));
      try { D.names = cshHipNamesParse(File.readTextFile(dir + "hip_names.csv")); } catch (eN) {}
      // solo nombres propios de la IAU (WGSN); sin la lista se quedan los de Stellarium y se dice en D.why
      try { D.wgsn = cshHipWgsnParse(File.readTextFile(dir + "iau_wgsn.csv")); D.namesDropped = cshHipNamesWgsn(D.names, D.wgsn); } catch (eW) { D.wgsn = null; D.why = "no IAU name list"; }
      D.ok = D.cat.n > 0;
      if (!D.ok) D.why = "empty catalogue";
   } catch (e) { D.why = String(e && e.message ? e.message : e); }
   D.ms = Date.now() - t0;
   CSH_HIPDATA = D;
   return D;
}
// LA CONSULTA de quien llama: { hip, name, iau }. Solo una estrella que PUEDE casar (G ≤ 9,5) toca el catálogo.
function cshHipLookup(ra, dec, g, bpRp) {
   var out = { hip: 0, name: "", iau: "" };
   if (!(typeof g === "number" && isFinite(g) && g <= CSH_HIP.FIELD_GMAX_MATCH) || !isFinite(ra) || !isFinite(dec)) return out;
   var D = cshHipData();
   if (!D.ok) return out;
   var h = cshHipMatch(D.cat, ra, dec, g, (bpRp === null || bpRp === undefined) ? NaN : bpRp);
   if (!(h > 0)) return out;
   out.hip = h; out.name = cshHipNameOfHip(D.names, h);
   var N = D.names[h]; out.iau = (D.wgsn && N && N.name) ? String(N.name) : "";
   return out;
}
