// ============================================================================
// CabraShared/csh_web.js — ABRIR UNA PÁGINA CON EL NAVEGADOR QUE TRAE PIXINSIGHT (3-nov-2026, CPD C10; petición de Nino)
// ----------------------------------------------------------------------------
// Antes los enlaces (SIMBAD, Wikipedia, Aladin desde la ficha de la estrella) y la ayuda local se abrían en el navegador del sistema
// con rundll32 (solo Windows; reglas CPD 5.3: un programa externo). Ahora se abren en el «PixInsight Web Browser», la ventana de
// navegador que trae PixInsight: Dialog.openBrowser( url[, title[, width, height]] ) (doc/pjsr/objects/Dialog, 1.9.6).
// MEDIDO el 3-nov-2026 en PixInsight 1.9.6 (instancia 239, escritorio aparte, conductor tests/c3_link_browser_driver.py):
//   · Dialog.openBrowser abre una ventana «<título de la página> — PixInsight Web Browser» con atrás/adelante, recargar, parar, la
//     dirección y la página: Wikipedia (Alcyone) se ve entera (capturas/c3_link_browser_raw_2.png) y la ayuda local también (…raw_4.png);
//   · es MODAL: no vuelve hasta que el usuario la cierra (el resto de la interfaz espera; es una acción directa del usuario, un clic);
//   · SIMBAD y Aladin salieron en blanco ESE DÍA porque el CDS no contestaba (curl 000 a los 20 s): NO VERIFICADO con el CDS vivo;
//   · el motor web de PixInsight NO TIENE WebGL (tests/c3_webgl_probe.log: webgl=false, webgl2=false; 2d=true como control), y
//     Aladin Lite v3 lo necesita para pintar el cielo: los enlaces a Aladin van al navegador del sistema (o.webgl = true).
// (Se descartó un diálogo propio con un control WebView, la primera versión del 3-nov: hace lo mismo con menos —sin atrás ni
// dirección— y es más código; el navegador de PixInsight ya es «el que trae PixInsight».)
// RESERVA (sin Dialog.openBrowser, si lanza una excepción, sin pantalla de verdad, o para Aladin): el navegador del sistema de cada
// plataforma, sin shell (programa + lista de argumentos: ni «&» ni «%» de la URL se interpretan): rundll32 url.dll,FileProtocolHandler
// en Windows, /usr/bin/open en macOS, xdg-open en Linux (cshSystemBrowser).
//
// API
//   cshWebOpen(url, o)       -> { ok, via: "pixinsight" | "system" | "hook" | "logged:…" | "skipped", url, why, exe, args }
//        o = { title, hook(url) (pruebas), noMain (prueba: solo apunta), system: true (directo al del sistema), webgl: true (la página
//        necesita WebGL: al del sistema), dry: true (decide y arma, no abre) }
//   cshWebRoute(o)           -> "pixinsight" | "system": a cuál iría (puro)
//   cshSystemBrowser(arg, o) -> { ok, exe, args, why }   (arg = URL o ruta de fichero; o.platform / o.exists / o.dry para pruebas)
// COSTURA ROJA: CSH_WEB_BREAK = "system" -> todo al navegador del sistema (como antes del 3-nov).
// ES5. Sin «barra asterisco» en comentarios.
// ============================================================================
#ifndef __CSH_WEB_JS
#define __CSH_WEB_JS

var CSH_WEB_LOG = [];            // lo que se ha pedido abrir (las pruebas lo leen): { url, via, ok }
var CSH_WEB_BREAK = "";
var CSH_WEB_WEBGL = false;       // true si algún día el motor web de PixInsight trae WebGL (medido el 3-nov: no)

// EL NAVEGADOR DEL SISTEMA (la reserva). Sin shell: programa + lista de argumentos.
function cshSystemBrowser(arg, o) {
   o = o || {};
   var pf = o.platform || ((typeof cshPlatform === "function") ? cshPlatform() : "windows");
   var has = o.exists || function(p) { try { return File.exists(p); } catch (e) { return false; } };
   var out = { ok: false, exe: "", args: [], why: "" };
   if (pf === "windows") {
      var root = ""; try { root = (typeof cshEnv === "function") ? cshEnv("SystemRoot") : String(System.getEnvironmentVariable("SystemRoot") || ""); } catch (eR) {}
      out.exe = ((root.length > 0) ? root.split("\\").join("/") : "C:/Windows") + "/System32/rundll32.exe";
      out.args = ["url.dll,FileProtocolHandler", String(arg)];
   } else if (pf === "macos") {
      out.exe = "/usr/bin/open"; out.args = [String(arg)];
   } else {
      var c = ["/usr/bin/xdg-open", "/bin/xdg-open", "/usr/local/bin/xdg-open"];
      for (var i = 0; i < c.length && !out.exe; ++i) if (has(c[i])) out.exe = c[i];
      if (!out.exe) out.exe = c[0];
      out.args = [String(arg)];
   }
   if (o.dry === true) { out.ok = true; return out; }
   try { out.ok = (ExternalProcess.startDetached(out.exe, out.args) !== false); if (!out.ok) out.why = "startDetached returned false"; }
   catch (e) { out.ok = false; out.why = String((e && e.message) ? e.message : e); }
   return out;
}

function cshWebHasBrowser() { try { return typeof Dialog !== "undefined" && typeof Dialog.openBrowser === "function"; } catch (e) { return false; } }
function cshWebRoute(o) {
   o = o || {};
   if (CSH_WEB_BREAK === "system" || o.system === true) return "system";
   if (o.webgl === true && CSH_WEB_WEBGL !== true) return "system";
   return cshWebHasBrowser() ? "pixinsight" : "system";
}

function cshWebOpen(url, o) {
   o = o || {};
   var out = { ok: false, via: "", url: String(url), why: "" }, route = cshWebRoute(o);
   var sb = cshSystemBrowser(out.url, { dry: true });
   out.exe = sb.exe; out.args = sb.args;                   // (la reserva, siempre dicha)
   if (typeof o.hook === "function") { try { o.hook(out.url); out.ok = true; } catch (eH) { out.why = String(eH); } out.via = "hook:" + route; CSH_WEB_LOG.push(out); return out; }
   var noMain = (o.noMain === true) || (o.noMain !== false && typeof CP_NO_MAIN !== "undefined" && !!CP_NO_MAIN);
   if (noMain || o.dry === true) { out.ok = true; out.via = (noMain ? "logged:" : "") + route; CSH_WEB_LOG.push(out); return out; }
   if (route === "pixinsight") {
      // (sin pantalla —pruebas, automatización—, NUNCA una ventana modal: colgaría la instancia; csh_astrometry.js cshInteractive)
      var inter = true; try { if (typeof cshInteractive === "function") inter = cshInteractive(); } catch (eI) {}
      if (!inter) { out.via = "skipped"; out.why = "non-interactive"; CSH_WEB_LOG.push(out); return out; }
      try {
         Dialog.openBrowser(out.url, o.title ? String(o.title) : "FieldDepth3D");
         out.ok = true; out.via = "pixinsight"; CSH_WEB_LOG.push(out);
         return out;
      } catch (e) { out.why = "Dialog.openBrowser: " + String((e && e.message) ? e.message : e); }
   }
   var r = cshSystemBrowser(out.url);
   out.ok = r.ok; out.via = "system"; if (!r.ok) out.why = (out.why ? out.why + " · " : "") + r.why;
   CSH_WEB_LOG.push(out);
   return out;
}

#endif
