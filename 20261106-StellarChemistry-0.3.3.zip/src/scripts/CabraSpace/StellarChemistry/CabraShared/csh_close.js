// ============================================================================
// CabraShared/csh_close.js — CERRAR DE VERDAD (encargo de Nino, 15-oct-2026)
// ----------------------------------------------------------------------------
// El aspa, Esc y el boton «Cerrar» cierran AL MOMENTO, tambien con una consulta de red o una transicion en marcha, y no
// queda nada vivo. Lo aprendido en los cuatro scripts (CabraStars cs_test_close, Cabra3D c3_close_driver.py,
// CabraComposition T9, CabraQuality):
//   1. `onClose` tiene que DEVOLVER true (sin valor PJSR lo toma como un veto: el aspa no cerraba en Cabra3D).
//   2. Esc NO pasa por `onClose` (CabraBase/pjsr/esc-en-dialog-no-pasa-por-onclose.md): se coge en `onKeyPress`.
//   3. La espera de red bombea eventos: el cierre llega DENTRO de ella. La espera tiene que enterarse y matar curl
//      (CSH_NET_PUMP devuelve true, o CSH_ABORT, o C3_CLOSING): si no, `execute()` no vuelve hasta que curl acaba.
//   4. `cancel()` DIFERIDO a un temporizador corto: llamado dentro de un manejador anidado cortaba el script sin volver
//      de `execute()` (medido en CabraQuality).
//   5. Parar TODOS los temporizadores y soltar los bitmaps (con uno vivo, 112 tics despues de cerrar en Cabra3D).
// Aqui: `cshCloseLater( dlg, s )` (el paso 4) y `cshStopTimers( lista )` (el 5). Cada script pone sus pasos 1–3. ES5.
// ============================================================================

var CSH_CLOSE_DELAY_S = 0.02;
function cshCloseLater(dlg, seconds) {
   if (!dlg) return;
   try {
      if (!dlg._cshCloseTimer) {
         var t = new Timer;
         t.interval = (seconds > 0) ? seconds : CSH_CLOSE_DELAY_S; t.periodic = false;
         t.onTimeout = function() { try { dlg.cancel(); } catch (e) {} };
         dlg._cshCloseTimer = t;
      }
      dlg._cshCloseTimer.start();
   } catch (e2) { try { dlg.cancel(); } catch (e3) {} }
}
function cshStopTimers(list) {
   var n = 0;
   for (var i = 0; i < list.length; ++i) { try { if (list[i]) { list[i].stop(); ++n; } } catch (e) {} }
   return n;
}
function cshFreeBitmaps(list) {
   for (var i = 0; i < list.length; ++i) { try { if (list[i]) list[i].clear(); } catch (e) {} }
}
