// ============================================================================
// CabraShared/csh_batch.js — EL LOTE: varias descargas A LA VEZ, para todos los scripts (29-oct-2026 (noche))
// ----------------------------------------------------------------------------
// Antes solo CabraComposition preguntaba en paralelo (ccHttpBatch, 22-oct); CabraStars, Cabra3D y CabraStarAnalysis esperaban
// cada consulta detras de la anterior (cpSfHttpText / cshNfFetch, una espera bloqueante de curl cada vez). Aqui, UNA pieza:
//   1. cshBatchPool(o)            — curl SIN esperar (ExternalProcess.start), sondeados todos a la vez; tope, corte, cierre.
//   2. cshBatchRun(chains, o)     — el planificador: N «cadenas» (cada una pide, mira la respuesta y decide la siguiente) a la vez.
//   3. cshHttpMany(items, o)      — cpSfHttpText en paralelo: LA MISMA cadena de cada peticion (SIMBAD -> Harvard, VizieR -> IDIA -> NAO,
//                                   o la peticion simple), con las mismas piezas de csh_net.js (cshSimbadPlan/Step/End, cshVizierPlan/Step/End,
//                                   cshRawArgs/Finish): mismas respuestas, mismos avisos, misma memoria del CDS caido.
//   4. cshNfFetchMany(specs, o)   — cshNfFetch en paralelo (las capas de CabraStars): mismos servidores, cortacircuitos y cache.
//   5. cshVzBatch(items, cfg)     — el lote de CabraComposition (primario TAP + reintento + espejos ASU + cache), movido aqui tal
//                                   cual; ccHttpBatch (cc_pixinsight.js) es ahora un adaptador que le pasa lo suyo en `cfg`.
// TOPE COMPARTIDO: CSH_BATCH_MAX curl vivos a la vez como mucho, sumando TODOS los lotes (los servidores cortan con demasiadas: 502,
// CabraBase/pjsr/networktransfer-plazos-y-502.md). 8 = el de CabraComposition (CC_PAR_MAX, medido en su T14).
// CIERRE: todo curl lanzado queda en CSH_BATCH_PROCS hasta que se recoge; CSH_ABORT (o lo que diga el bombeo de la interfaz) mata
// los del lote en curso; cshBatchKillAll() mata los de todos. cshBatchLive() = cuantos siguen vivos.
// COSTURAS ROJAS (variable de entorno CSH_BATCH_BREAK o global del mismo nombre, separadas por comas):
//   serial = una peticion a la vez (el tiempo de antes) · nokill = al cerrar no se mata nada (quedan curl vivos).
// Procedencia: cc_pixinsight.js ccHttpBatch (22-oct-2026, noche) y la espera de csh_net.js cshCurlRun. ES5.
// ============================================================================

var CSH_BATCH_MAX = 8;            // curl vivos a la vez como mucho, entre TODOS los lotes
var CSH_BATCH_PROCS = [];         // los curl lanzados y aun no recogidos (de todos los lotes)
var CSH_BATCH_LAZY_TOTAL = 0;     // (30-oct-2026) cadenas de un lote que fueron por su camino bloqueante (x.sync): los caminos reales lo apuntan en su RESUMEN
var CSH_BATCH_STATS = null;       // el ultimo lote: { t0, maxLive, intervals: [[desde, hasta (ms), etiqueta]], killed, lazy, cached }
var CSH_BATCH_LOG = null;         // pruebas: un array donde se apunta cada curl recogido { host, args, t0, ms, exit, code, cut, aborted }
var CSH_BATCH_BREAK = "";         // pruebas: lo mismo que la variable de entorno
// (CSH_HTTP_NOTE, la cuenta de fallos de quien la lleve —Cabra3D, tm/netstatus.js—, se declara en csh_net.js: asi el orden de los #include da igual)
function cshBatchBrk(name) {
   var s = "," + String(CSH_BATCH_BREAK || "") + "," + ((typeof cshEnv === "function") ? "" : "") + ",";
   return s.indexOf("," + name + ",") >= 0;
}
function cshBatchRunning(proc) { try { return proc.isRunning === true || proc.isStarting === true; } catch (e) { return false; } }
// cuantos curl del lote siguen vivos (de todos los lotes); los ya acabados y sin recoger no cuentan para el tope
function cshBatchLive() {
   var n = 0;
   for (var i = 0; i < CSH_BATCH_PROCS.length; ++i) if (cshBatchRunning(CSH_BATCH_PROCS[i])) ++n;
   return n;
}
// matar TODOS (cierre de una ventana): -> cuantos se mataron. Con la costura nokill, ninguno.
function cshBatchKillAll() {
   if (cshBatchBrk("nokill")) return 0;
   var n = 0;
   for (var i = 0; i < CSH_BATCH_PROCS.length; ++i) if (cshBatchRunning(CSH_BATCH_PROCS[i])) { try { CSH_BATCH_PROCS[i].kill(); ++n; } catch (e) {} }
   return n;
}
// ¿Se pisan de verdad? -> { n, pairs (pares de intervalos que se solapan), sumMs, wallMs, ratio = suma / tiempo de reloj }
function cshBatchOverlap(iv) {
   var sum = 0, a = Infinity, b = -Infinity, pairs = 0, i, j;
   iv = iv || [];
   for (i = 0; i < iv.length; ++i) {
      sum += iv[i][1] - iv[i][0]; a = Math.min(a, iv[i][0]); b = Math.max(b, iv[i][1]);
      for (j = i + 1; j < iv.length; ++j) if (iv[i][0] < iv[j][1] && iv[j][0] < iv[i][1]) ++pairs;
   }
   var wall = iv.length ? b - a : 0;
   return { n: iv.length, pairs: pairs, sumMs: sum, wallMs: wall, ratio: wall > 0 ? +(sum / wall).toFixed(2) : 0 };
}
function cshBatchHost(args) { for (var i = args.length - 1; i >= 0; --i) { var m = /^https?:[/][/]([^/?]+)/.exec(String(args[i])); if (m) return m[1]; } return "?"; }
// (30-oct-2026; solo con CSH_BATCH_LOG puesto, las sondas de tiempos) lo que ocupa la respuesta en disco: el «-o fichero» de los argumentos
function cshBatchBytes(args) { try { for (var i = 0; i + 1 < args.length; ++i) if (args[i] === "-o" && File.exists(args[i + 1])) return (new FileInfo(args[i + 1])).size; } catch (e) {} return -1; }

// ---------------------------------------------------------------------------
// 1. EL POOL: curl sin esperar
//   o = { max (de este lote; el global CSH_BATCH_MAX manda tambien), stats (objeto que se rellena), curl, onLaunch(proc), onReap(proc) }
//   P.launch(args, limitS, tag) -> p { proc, t0, limit, tag }   (args COMPLETOS salvo -s -S -w: se añaden aqui)
//   P.room() -> bool · P.poll(waitMs, onDone(p, c)) · P.reap(p, cut, aborted) -> c { exit, code, cut, aborted, message, ms }
//   P.killAll(onDone) -> cuantos · P.procs
// ---------------------------------------------------------------------------
function cshBatchPool(o) {
   o = o || {};
   var P = { procs: [], max: Math.max(1, o.max || CSH_BATCH_MAX), stats: o.stats || { t0: Date.now(), maxLive: 0, intervals: [], killed: 0 }, curl: o.curl || CSH_CURL };
   if (!(P.stats.t0 > 0)) P.stats.t0 = Date.now();
   P.room = function() { return P.procs.length < P.max && cshBatchLive() < Math.max(1, CSH_BATCH_MAX); };
   P.launch = function(args, limitS, tag) {
      var p = { proc: new ExternalProcess, t0: Date.now(), limit: limitS, tag: tag || "", host: cshBatchHost(args), args: args };
      p.proc.start(P.curl, ["-s", "-S", "-w", "%{http_code}"].concat(args));
      P.procs.push(p); CSH_BATCH_PROCS.push(p.proc);
      if (typeof o.onLaunch === "function") { try { o.onLaunch(p.proc); } catch (eL) {} }
      P.stats.maxLive = Math.max(P.stats.maxLive || 0, P.procs.length);
      return p;
   };
   P.reap = function(p, cut, aborted) {
      var c = { exit: -1, code: 0, cut: cut === true, aborted: aborted === true, message: "", ms: 0 }, said = "";
      try { c.exit = p.proc.exitCode; } catch (e) {}
      try { said = p.proc.stdout.utf8ToString(); } catch (e2) {}
      var m = /(\d{3})\s*$/.exec(String(said)); c.code = m ? parseInt(m[1], 10) : 0;
      var k = P.procs.indexOf(p); if (k >= 0) P.procs.splice(k, 1);
      k = CSH_BATCH_PROCS.indexOf(p.proc); if (k >= 0) CSH_BATCH_PROCS.splice(k, 1);
      if (typeof o.onReap === "function") { try { o.onReap(p.proc); } catch (eR) {} }
      c.ms = Date.now() - p.t0;
      P.stats.intervals.push([p.t0 - P.stats.t0, Date.now() - P.stats.t0, p.tag]);
      if (CSH_BATCH_LOG instanceof Array) CSH_BATCH_LOG.push({ host: p.host, args: p.args, t0: p.t0, ms: c.ms, exit: c.exit, code: c.code, cut: c.cut, aborted: c.aborted, tag: p.tag, bytes: cshBatchBytes(p.args) });
      p.proc = null;
      return c;
   };
   // espera un rato (waitMs) a que acabe alguno y recoge los acabados y los pasados de su tope (+3 s, como cshCurlRun)
   P.poll = function(waitMs, onDone) {
      var i, now;
      if (P.procs.length) { try { P.procs[0].proc.waitForFinished(waitMs); } catch (eW) {} }
      else { now = Date.now(); while (Date.now() - now < Math.min(waitMs, 40)) { try { CoreApplication.processEvents(); } catch (eP) {} } }
      for (i = P.procs.length - 1; i >= 0; --i) {
         var p = P.procs[i], busy = cshBatchRunning(p.proc), cut = false;
         if (busy && Date.now() - p.t0 > (p.limit + 3) * 1000) { cut = true; try { p.proc.kill(); } catch (eK) {} try { p.proc.waitForFinished(2000); } catch (eW2) {} busy = false; }
         if (busy) continue;
         var c = P.reap(p, cut, false);
         if (typeof onDone === "function") onDone(p, c);
      }
   };
   P.killAll = function(onDone) {
      var n = 0;
      while (P.procs.length) {
         var p = P.procs[0];
         try { p.proc.kill(); } catch (eK) {}
         ++n; P.stats.killed = (P.stats.killed || 0) + 1;
         var c = P.reap(p, false, true);
         if (typeof onDone === "function") onDone(p, c);
      }
      return n;
   };
   return P;
}

// ---------------------------------------------------------------------------
// 2. EL PLANIFICADOR: cadenas a la vez
// Una cadena es una funcion step(r) que, con la respuesta de su peticion anterior (undefined la primera vez), devuelve:
//   { req: { args, waitS, onProgress(ms), finish(c) -> r } }  una peticion por curl (el lote la lanza cuando haya hueco)
//   { sync: function() -> r }                                 una peticion que se hace YA, en serie (ganchos de prueba, sin curl)
//   { done: valor }                                           acabo
// El primer paso de cada cadena se da cuando le toca hueco (no antes): asi la memoria del «CDS caido» que dejo una cadena ya acabada
// vale para la siguiente, como en serie. o = { max, abort() -> bool, pump (true: atender la interfaz con CSH_NET_PUMP, como cshCurlRun) }
// -> [ valores ], en el orden de las cadenas. Al acabar (o si algo lanza) no queda ningun curl de este lote vivo.
// ---------------------------------------------------------------------------
function cshBatchRun(chains, o) {
   o = o || {};
   var serial = cshBatchBrk("serial"), noKill = cshBatchBrk("nokill");
   var stats = { t0: Date.now(), maxLive: 0, intervals: [], killed: 0, lazy: 0, cached: 0 };
   CSH_BATCH_STATS = stats;
   var pool = cshBatchPool({ max: serial ? 1 : (o.max || CSH_BATCH_MAX), stats: stats });
   var S = [], k, aborted = false, lastTick = 0;
   for (k = 0; k < chains.length; ++k) S.push({ step: chains[k], st: "new", req: null, p: null, val: undefined });
   function stopNow() {
      if (typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) return true;
      if (typeof o.abort === "function") { try { if (o.abort() === true) return true; } catch (eA) {} }
      return false;
   }
   function advance(s, r) {
      for (;;) {
         var x;
         try { x = s.step(r); } catch (eS) { x = { done: { ok: false, code: 0, text: "", ms: 0, message: String(eS.message || eS), error: true } }; }
         if (!x || x.done !== undefined) { s.st = "done"; s.val = x ? x.done : undefined; s.req = null; return; }
         if (x.sync) { ++stats.lazy; ++CSH_BATCH_LAZY_TOTAL; r = x.sync(); continue; }
         s.req = x.req; s.st = "wait"; return;
      }
   }
   function abortedC() { return { exit: -1, code: 0, cut: false, aborted: true, message: "aborted", ms: 0 }; }
   function launch(s) {
      if (aborted) { var rq = s.req; s.req = null; advance(s, rq.finish(abortedC())); return; }
      try { s.p = pool.launch(s.req.args, s.req.waitS, s.req.tag || ""); s.p.s = s; s.st = "run"; }
      catch (eL) { var rq2 = s.req; s.req = null; var c0 = abortedC(); c0.aborted = false; c0.message = String(eL.message || eL); advance(s, rq2.finish(c0)); }
   }
   function fill() {
      for (var i = 0; i < S.length; ++i) {
         var s = S[i];
         if (s.st === "done" || s.st === "run") continue;
         if (!aborted && !pool.room()) break;
         if (s.st === "new") { advance(s, undefined); if (s.st !== "wait") continue; }
         if (s.st === "wait") launch(s);
      }
   }
   function onDone(p, c) { var s = p.s, rq = s.req; s.p = null; s.req = null; advance(s, rq.finish(c)); }
   function pending() { for (var i = 0; i < S.length; ++i) if (S[i].st !== "done") return true; return false; }
   try {
      fill();
      while (pending()) {
         var pump = (o.pump !== false && typeof CSH_NET_PUMP === "function");
         pool.poll(pump ? CSH_NET_PUMP_WAIT_MS : 100, onDone);
         var stop = stopNow();
         if (!stop && pump && CSH_PAINTING === 0) { CSH_YIELD_IN = true; try { stop = (CSH_NET_PUMP() === true); } catch (eQ) {} finally { CSH_YIELD_IN = false; } }
         if (stop && !aborted) {
            aborted = true;
            if (!noKill) pool.killAll(onDone);
            else { for (var a = 0; a < S.length; ++a) if (S[a].st === "run") { S[a].st = "done"; S[a].val = { ok: false, code: 0, text: "", ms: 0, message: "aborted", aborted: true }; S[a].p = null; } pool.procs = []; }
         }
         if (Date.now() - lastTick >= 500) {
            lastTick = Date.now();
            for (var t = 0; t < S.length; ++t) if (S[t].st === "run" && S[t].req && typeof S[t].req.onProgress === "function") { try { S[t].req.onProgress(Date.now() - S[t].p.t0); } catch (eT) {} }
         }
         fill();
      }
   } finally {
      if (pool.procs.length && !noKill) pool.killAll(null);
   }
   var out = [];
   for (k = 0; k < S.length; ++k) out.push(S[k].val);
   return out;
}

// ---------------------------------------------------------------------------
// 3. cpSfHttpText EN PARALELO. items = [{ url, opts }] (lo que se pasaria a cpSfHttpText) -> [respuestas de cpSfHttpText], en orden.
// Lo que no tiene red de verdad (CP_SF_HTTP_HOOK de las pruebas, sin curl) y la consulta de VizieR que hay que montar con varias
// peticiones por espejo (JOIN: cshVizierGet con su cshVzMirrorAsk) van por cpSfHttpText, en serie, cuando les toca.
// Cada peticion de dentro y cada respuesta final pasan por CSH_HTTP_NOTE (la cuenta de fallos de Cabra3D, que antes envolvia cpSfHttpText).
// ---------------------------------------------------------------------------
function cshHttpNote(url, r) { if (typeof CSH_HTTP_NOTE === "function") { try { CSH_HTTP_NOTE(url, r); } catch (e) {} } return r; }
function cshHttpMany(items, o) {
   var chains = [];
   for (var i = 0; i < (items || []).length; ++i) chains.push(cshHttpChain(items[i].url, items[i].opts || {}));
   return cshBatchRun(chains, o);
}
// una peticion GET por curl, en la forma de cpSfHttpTextRaw + cshRawNet (lo de csh_net.js)
function cshHttpReq(url, ro) {
   var ra = cshRawArgs(url, ro), tmp = cshTmpPath("csh_get", ".csv"), t0 = Date.now();
   return { args: ra.args.concat(["-o", tmp, url]), waitS: ra.waitS, tag: cshNetServer(url), onProgress: (typeof ro.onProgress === "function") ? ro.onProgress : null,
            finish: function(c) { return cshHttpNote(url, cshRawNet(url, cshRawFinish(url, ro, c, tmp, ra.limitS, t0))); } };
}
function cshHttpChain(url, opts) {
   var u = String(url), o = opts || {}, kind = "", P = null, i = 0;
   function whole() { return { sync: function() { return cpSfHttpText(u, o); } }; }
   function attempt() {
      if (i > 0 && typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) return null;
      var ro = (kind === "sim") ? cshSimbadReqOpts(P, i) : cshVizierReqOpts(P, i);
      return { req: cshHttpReq(P.list[i].url, ro) };
   }
   function end() {
      var g = (kind === "sim") ? cshSimbadEnd(P) : cshVizierEnd(P), rg = g.ok ? g.r : (g.first || g.r);
      if (rg) { rg.server = g.server; rg.fallback = g.fallback; rg.attempts = g.attempts; if (kind === "vz") rg.empty = (g.empty === true); }
      return { done: cshHttpNote(u, cshHttpCachePut(u, o, rg)) };
   }
   return function step(r) {
      if (kind === "") {
         var hook = (typeof CP_SF_HTTP_HOOK === "function"), abort = (typeof CSH_ABORT !== "undefined" && CSH_ABORT === true);
         if (hook || abort || !cshHasCurl()) { kind = "whole"; return whole(); }
         var hit = cshHttpCacheGet(u, o);                                          // (30-oct-2026: la cache de respuestas, csh_net.js)
         if (hit) { kind = "hit"; return { done: cshHttpNote(u, hit) }; }
         if (CSH_SIMBAD_BACKUP !== false && !(o.noMirror === true) && u.indexOf(CSH_SIMBAD_CDS) === 0) { kind = "sim"; P = cshSimbadPlan(u, o, null); return attempt() || end(); }
         if (CSH_VIZIER_BACKUP !== false && !(o.noMirror === true) && u.indexOf(CSH_VIZIER_CDS) === 0) {
            P = cshVizierPlan(u, o);
            if (P.vz && P.list.length > 1) { kind = "whole"; return whole(); }      // (el montaje por varias peticiones: cshVizierGet, que ya pide las suyas a la vez)
            kind = "vz"; return attempt() || end();
         }
         kind = "raw"; return { req: cshHttpReq(u, o) };
      }
      if (kind === "whole") return { done: r };
      if (kind === "raw") return { done: cshHttpCachePut(u, o, r) };
      var st = (kind === "sim") ? cshSimbadStep(P, i, r) : cshVizierStep(P, i, r, null);
      if (st === "next" && i + 1 < P.list.length) { ++i; var a = attempt(); if (a) return a; }
      return end();
   };
}

// ---------------------------------------------------------------------------
// 4. cshNfFetch EN PARALELO (las capas de CabraStars). specs = [spec de cshNfFetch] -> [lo que devolveria cshNfFetch], en orden.
// Cada cadena recorre su lista de servidores con el MISMO cortacircuitos (lo que abre una cadena lo ve la siguiente peticion de las
// demas), juicio y cache (csh_netfail.js: cshNfFetchPlan/Skip/Step/End, cshNfGetLazy/Args/Finish).
// ---------------------------------------------------------------------------
function cshNfFetchMany(specs, o) {
   var chains = [];
   for (var i = 0; i < (specs || []).length; ++i) chains.push(cshNfChain(specs[i]));
   return cshBatchRun(chains, o);
}
function cshNfChain(spec) {
   var F = null;
   function next() {
      while (F.i < F.list.length) {
         if (cshNfFetchSkip(F)) { ++F.i; continue; }
         var sv = F.list[F.i], ro = cshNfReqOpts(F, F.i);
         if (cshNfGetLazy(sv.url, ro)) return { sync: function() { return cshNfGet(sv.url, ro); } };
         var A = cshNfArgs(sv.url, ro), t0 = Date.now();
         if (!A) return { sync: function() { return { ok: false, code: 0, text: "", ms: 0, cut: false, aborted: false }; } };
         return { req: { args: A.args, waitS: A.limitS, tag: cshNfName(sv.url), onProgress: (typeof ro.onProgress === "function") ? ro.onProgress : null, finish: function(c) { return cshNfGetFinish(c, A, t0); } } };
      }
      return { done: cshNfFetchEnd(F) };
   }
   return function step(r) {
      if (F === null) { F = cshNfFetchPlan(spec); if (F.done) return { done: F.out }; return next(); }
      if (cshNfFetchStep(F, F.i, r) !== "next") return { done: F.out };
      ++F.i;
      return next();
   };
}

// ---------------------------------------------------------------------------
// 5. EL LOTE DE CabraComposition (cc_pixinsight.js ccHttpBatch, 22-oct-2026, noche), movido aqui con lo suyo en `cfg`.
// Cada consulta recorre la cascada de ccHttpTap, por pasos y sin bloquear a las demas:
//   cache -> primario (TAPVizieR) -> si es un fallo pasajero, UN reintento tras 1 s (uno solo para todo el lote: si otra consulta ya
//   esta reintentando, se espera a lo que diga) -> si el primario no contesta, los ESPEJOS (ASU, con sus peticiones tambien a la vez)
//   -> el fallo, con lo que dijeron los espejos. Lo que no tiene red de verdad se queda «perezoso»: take() devuelve null.
// cfg = { live, mirror, limitS, max, noKill, stats, curl, refresh, onTick(ms, info), abort() -> bool, onLaunch(proc), onReap(proc),
//         tmp(ext) -> ruta, judge(c, of, limitS, t0, msg) -> a, primaryArgs(qf, limitS) -> args, primaryOut(a, it) -> r,
//         net (CC_NET: downUntil, lastFail, poly, memo, mirror, viaMirror, lastCall), downMs, transient(r, limitS), retryPauseMs,
//         mirrors ([url, name]), lacks(m, adql), plan(adql, key), requests(plan), build(plan, reqs, texts), acceptEmpty() -> bool,
//         cacheMirror(adql, key, csv), cacheRead(it) -> texto | null, note(adql), netLog(entrada), connectS, mirrorTimeoutS,
//         fanOut (bool), stallS (s) }
//   -> B { add(items), take(adql, key) -> respuesta | null, pending() -> [claves], close() }
// (29-oct-2026, noche: Nino vio «más de 4 minutos adquiriendo datos»; medido en frío, M 67, 225,7 s, tests/cc_cold_antes_m67.log:
//  el CDS caído 23 s, y luego GALAH DR4 y Kordopatis+23 —que IDIA no sirve— esperando a CfA (60 s callado: su pasarela corta a los
//  60,4 s con 0 bytes, exit 18) y DESPUÉS a NAO (Kordopatis: cabeceras y 68,7 s sin un byte). Dos arreglos aquí:
//   · fanOut: el espejo PREFERIDO (el primero) va solo, como siempre; si no sirve (falla, no tiene la tabla o da 0 filas), los
//     demás se preguntan A LA VEZ y vale la primera respuesta CON filas (mismas tablas de VizieR: misma respuesta; la interfaz dice
//     cuál contestó). Un vacío sigue siendo provisional hasta que hablen todos (R2 H-1). Lo que nadie espera ya se mata.
//   · stallS: un espejo que no manda NI UN BYTE en stallS segundos se corta (curl --speed-limit 1 --speed-time). Medido el 29-oct:
//     los conos de Gaia más pesados de IDIA (Kepler 1,5°x1°, 16 MB, 110 000 filas) dan el primer byte a los 0,78 s y siguen
//     fluyendo; los callados no mandan nada nunca. Un corte nunca deja datos a medias: exit 28 = fallo, al siguiente espejo.)
// ---------------------------------------------------------------------------
function cshVzBatch(items, cfg) {
   var C = cfg, limitS = C.limitS, t0 = Date.now(), live = C.live, mirror = C.mirror, NET = C.net;
   var B = { its: [], map: {}, subs: {}, probe: null, lastTick: 0 };
   var stats = C.stats || { t0: t0, maxLive: 0, intervals: [], killed: 0, lazy: 0, cached: 0 };
   stats.t0 = t0; CSH_BATCH_STATS = stats;
   var pool = cshBatchPool({ max: C.max, stats: stats, curl: C.curl, onLaunch: C.onLaunch, onReap: C.onReap });
   B.procs = pool.procs;
   function aborting() { return C.abort() === true; }
   function abortResp() { return { ok: false, text: "", ms: 0, message: "aborted", cached: false, aborted: true, netFail: false, netWhy: "", kind: "aborted" }; }
   function finish(it, r) { it.resp = r; it.st = "done"; it.p = null; }
   // --- un curl SIN esperar -----------------------------------------------------------------------------------------
   function launch(args, of, limit, tag) { var p = pool.launch(args.concat(["-o", of]), limit, tag); p.of = of; p.qf = ""; return p; }
   function reapJudge(p, cut, aborted) {
      var of = p.of, qf = p.qf, lim = p.limit, pt0 = p.t0, c = pool.reap(p, cut, aborted);
      var a = C.judge(c, of, lim, pt0, "");
      try { if (qf && File.exists(qf)) File.remove(qf); } catch (eQ) {}
      return a;
   }
   // --- el primario ---------------------------------------------------------------------------------------------------
   function startPrimary(it) {
      var qf = C.tmp(".adql"), of = qf.replace(/\.adql$/, ".csv");
      try { File.writeTextFile(qf, it.adql); it.p = launch(C.primaryArgs(qf, limitS), of, limitS, it.key); it.p.qf = qf; it.p.it = it; it.p.kind = "tap"; it.st = "primary"; }
      catch (e) { try { if (File.exists(qf)) File.remove(qf); } catch (eQ) {} onPrimary(it, C.judge(null, of, limitS, Date.now(), String(e.message || e))); }
   }
   function onPrimary(it, a) {
      var r = C.primaryOut(a, it);
      if (it.first) { r.ms += it.first.ms; r.retried = true; r.firstMessage = it.first.message; }
      if (B.probe === it) { B.probe = null; B.probeOk = r.ok; }
      if (r.ok) { if (mirror) NET.downUntil = 0; finish(it, r); return; }
      if (aborting() || r.aborted) { finish(it, r); return; }
      // (30-oct-2026) se le pregunto porque los espejos no la dieron y la memoria del disco lo daba por caido: su fallo ya es de VERDAD (las siguientes no le repreguntan)
      if (it.primAsked) { if (r.netFail) NET.lastFail = r; r.message = String(r.message || "") + (it.mirrorSaid ? " · mirrors: " + it.mirrorSaid : ""); r.ms = (r.ms || 0) + (Date.now() - (it.mt0 || Date.now())); finish(it, r); return; }
      var downNow = mirror && NET.downUntil > Date.now();
      if (!it.first && !downNow && B.probeOk !== false && C.transient(r, limitS)) {
         it.first = r;
         if (B.probe) { it.st = "waitprobe"; return; }                 // otra ya reintenta: se espera a lo que diga
         B.probe = it; it.st = "retrywait"; it.retryAt = Date.now() + C.retryPauseMs; return;
      }
      if (mirror && r.netFail) { if (!downNow) { NET.downUntil = Date.now() + C.downMs; NET.lastFail = r; } it.prim = r; startMirror(it, 0); return; }
      finish(it, r);
   }
   // --- el espejo (ccMirrorTry, por pasos) ------------------------------------------------------------------------------
   // it.act[m] = { texts, wait, fail, done }: los espejos preguntados (con fanOut, varios a la vez); it.whyAt[m]: lo que dijo cada uno.
   function startMirror(it, m) {
      it.st = "mirror"; it.act = {}; it.whyAt = {}; it.nextM = m || 0;
      if (!it.mt0) it.mt0 = Date.now();
      it.plan = C.plan(it.adql, it.key);
      if (!it.plan.ok) { mirrorEnd(it, "no mirror plan: " + it.plan.why); return; }
      it.reqs = C.requests(it.plan);
      mirrorNext(it);
   }
   // abre el siguiente espejo; con fanOut, a partir del segundo, TODOS los que quedan a la vez
   function mirrorNext(it) {
      while (it.st === "mirror" && it.nextM < C.mirrors.length && !aborting()) {
         var m = it.nextM++, lk = C.lacks(m, it.adql);
         if (lk) { it.whyAt[m] = C.mirrors[m][1] + ": " + ((typeof lk === "string") ? lk : "table not served by this mirror"); continue; }
         var A = it.act[m] = { texts: [], wait: 0, fail: "", done: false };
         for (var i = 0; i < it.reqs.length; ++i) {
            var mk = m + "|" + it.reqs[i].qs, hit = NET.memo[mk];
            if (hit !== undefined) { A.texts[i] = hit; continue; }
            var s = B.subs[mk];
            if (!s) { s = B.subs[mk] = { mk: mk, m: m, qs: it.reqs[i].qs, key: it.key, st: "queued", waiters: [] }; }
            s.waiters.push([it, i, m]); ++A.wait;
         }
         if (!(C.fanOut === true && m > 0)) break;
      }
      mirrorSettle(it);
   }
   function mirrorWhy(it) { var w = []; for (var m = 0; m < C.mirrors.length; ++m) if (it.whyAt[m]) w.push(it.whyAt[m]); return w.join(" · "); }
   // mira los espejos que ya acabaron: el primero CON filas gana; si no queda ninguno vivo, el siguiente (o el final)
   function mirrorSettle(it) {
      if (it.st !== "mirror") return;
      var live = false;
      for (var m = 0; m < C.mirrors.length; ++m) {
         var A = it.act[m];
         if (!A || A.done) continue;
         if (A.wait > 0 && !A.fail) { live = true; continue; }
         A.done = true;
         var name = C.mirrors[m][1];
         if (!A.fail) {
            var b = C.build(it.plan, it.reqs, A.texts);
            if (b.ok && (b.rows > 0 || C.acceptEmpty())) {
               NET.mirror = name; ++NET.viaMirror; NET.lastCall = Date.now();
               C.cacheMirror(it.adql, it.key, b.csv);
               var pr = it.prim || {};
               finish(it, { ok: true, text: b.csv, ms: (pr.ms || 0) + (Date.now() - it.mt0), message: "", cached: false, code: 200, host: name, server: name, mirror: name,
                            kind: "", netFail: false, netWhy: "", retried: pr.retried === true, primaryFailed: pr.message });
               return;
            }
            if (b.ok) {                                                     // 0 filas: provisional (R2 H-1: como en ccMirrorTry)
               if (!it.empty || m < it.empty.m) it.empty = { csv: b.csv, name: name, m: m };
               it.whyAt[m] = name + ": 0 rows, asking the next mirror";
               continue;
            }
            A.fail = name + ": " + b.why;
         }
         it.whyAt[m] = A.fail;
      }
      if (live) return;
      if (it.nextM < C.mirrors.length && !aborting()) { mirrorNext(it); return; }
      mirrorEnd(it, mirrorWhy(it));
   }
   function mirrorEnd(it, why) {
      if (it.empty && !aborting()) {        // ningún espejo trajo filas y uno contestó «0 filas»: vale el vacío (sin caché: ccCacheMirror)
         var pe = it.prim || {};
         NET.mirror = it.empty.name; ++NET.viaMirror; NET.lastCall = Date.now();
         finish(it, { ok: true, text: it.empty.csv, ms: (pe.ms || 0) + (Date.now() - (it.mt0 || Date.now())), message: "", cached: false, code: 200, host: it.empty.name,
                      server: it.empty.name, mirror: it.empty.name, kind: "", netFail: false, netWhy: "", retried: pe.retried === true, primaryFailed: pe.message, empty: true });
         return;
      }
      // (30-oct-2026) ningun espejo la da y el primario se salto SOLO por la memoria del disco (otro analisis, hace un rato): antes de decir que no hay, se le pregunta.
      // Si ha vuelto, se usa; si no, cuesta su plazo de conexion (5 s) y una sola vez (al fallar, NET.lastFail ya es de verdad y las demas no repreguntan).
      if (it.prim && it.prim.skippedPrimary && it.prim.fromDisk && NET.lastFail && NET.lastFail.fromDisk === true && !it.primAsked && !aborting()) { it.primAsked = true; it.mirrorSaid = why; it.st = "queued"; return; }
      var r = it.prim || { ok: false, text: "", ms: 0, message: "", cached: false };
      r.message = String(r.message || "") + (why ? " · mirrors: " + why : "");
      r.ms = (r.ms || 0) + (Date.now() - (it.mt0 || Date.now()));
      finish(it, r);
   }
   function startSub(s) {
      var base = C.mirrors[s.m][0], of = C.tmp(".tsv");
      // (30-oct-2026) C.stallFor(m, qs): un plazo propio para ESTA tabla en ESTE espejo (el que callo hace poco se comprueba con un plazo corto: no se salta, ver ccMirrorStall)
      var stS = (typeof C.stallFor === "function") ? C.stallFor(s.m, s.qs) : C.stallS, connS = (stS > 0 && stS < C.connectS) ? stS : C.connectS;
      var stall = (stS > 0) ? ["--speed-limit", "1", "--speed-time", String(stS)] : [];
      try { s.p = launch(["-L", "--proto", "=https", "--proto-redir", "=https", "--max-redirs", "4", "--connect-timeout", String(connS), "-m", String(C.mirrorTimeoutS)].concat(stall, [base + "?" + s.qs]), of, C.mirrorTimeoutS, s.key + "@m" + s.m); s.p.sub = s; s.p.kind = "asu"; s.st = "running"; }
      catch (e) { onSub(s, C.judge(null, of, C.mirrorTimeoutS, Date.now(), String(e.message || e))); }
   }
   function onSub(s, a) {
      s.st = "done"; s.p = null;
      C.netLog({ url: C.mirrors[s.m][0], key: s.key, kind: a.kind || "ok", code: a.code, ms: a.ms, exit: a.exit, mirror: true });
      if (typeof C.onMirrorSaid === "function") { try { C.onMirrorSaid(s.m, s.qs, a); } catch (eMS) {} }
      if (a.ok) NET.memo[s.mk] = a.text;
      delete B.subs[s.mk];
      for (var w = 0; w < s.waiters.length; ++w) {
         var it = s.waiters[w][0], i = s.waiters[w][1], A = (it.st === "mirror" && it.act) ? it.act[s.waiters[w][2]] : null;
         if (!A || A.done) continue;                                      // (ese espejo ya se juzgó o la consulta acabó)
         --A.wait;
         if (a.ok) A.texts[i] = a.text;
         else if (!A.fail) A.fail = C.mirrors[s.m][1] + ": " + (a.message || a.kind);
         if (A.fail) A.wait = 0;                                          // (como la serie: el primer fallo cierra ese espejo)
         mirrorSettle(it);
      }
   }
   // ¿Alguien espera todavía esta petición de espejo?
   function subWanted(s) {
      for (var w = 0; w < s.waiters.length; ++w) { var it = s.waiters[w][0], A = (it.st === "mirror" && it.act) ? it.act[s.waiters[w][2]] : null; if (A && !A.done) return true; }
      return false;
   }
   // --- el planificador ------------------------------------------------------------------------------------------------
   function begin(it) {
      if (aborting()) { finish(it, abortResp()); return; }
      if (!live) { it.st = "lazy"; ++stats.lazy; return; }
      C.note(it.adql);
      if (!C.refresh) { var hit = C.cacheRead(it); if (hit !== null) { ++stats.cached; finish(it, { ok: true, text: hit, ms: 0, message: "", cached: true }); return; } }
      if (mirror && NET.downUntil > Date.now()) {
         // el primario acaba de caer: directo al espejo (lo de ccHttpTap con `down`)
         var lf = NET.lastFail;
         it.prim = lf ? { ok: false, text: "", ms: 0, message: lf.message, cached: false, code: lf.code, host: lf.host, server: lf.server, kind: lf.kind, netFail: lf.netFail, netWhy: lf.netWhy, skippedPrimary: true, fromDisk: lf.fromDisk === true }
                      : { ok: false, text: "", ms: 0, message: "not in cache", cached: false, cacheMiss: true };
         if (lf) { startMirror(it, 0); return; }
         finish(it, it.prim); return;
      }
      it.st = "queued";
   }
   function fill() {
      var i;
      for (i = 0; i < B.its.length && pool.room(); ++i) if (B.its[i].st === "queued" && !aborting()) {
         // (30-oct-2026) las que se encolaron para preguntarle al CDS «por si ha vuelto» no le repreguntan si otra ya ha fallado de verdad: medido en Pleyades (StellarChemistry, misma imagen otra vez),
         // 26 tandas de Kordopatis que ningun espejo da pagaban 5 s cada una, 8 a la vez, ~14 s para decir lo mismo. Rojo: CSH_NET_BREAK=reaskcds.
         var q0 = B.its[i], lf0 = NET.lastFail;
         if (q0.primAsked && lf0 && lf0.fromDisk !== true && !(typeof cshNetBrk === "function" && cshNetBrk("reaskcds"))) {
            finish(q0, { ok: false, text: "", ms: Date.now() - (q0.mt0 || Date.now()), message: String(lf0.message || "") + (q0.mirrorSaid ? " · mirrors: " + q0.mirrorSaid : ""), cached: false, code: lf0.code, host: lf0.host, server: lf0.server, kind: lf0.kind, netFail: lf0.netFail, netWhy: lf0.netWhy });
            continue;
         }
         startPrimary(q0);
      }
      for (var mk in B.subs) if (B.subs.hasOwnProperty(mk)) {
         if (!pool.room() || aborting()) break;
         var s = B.subs[mk];
         if (s.st !== "queued") continue;
         if (subWanted(s)) startSub(s); else delete B.subs[mk];        // (nadie la espera ya: ese espejo falló antes u otro contestó)
      }
   }
   // (fanOut) la petición de espejo que ya nadie espera (otro espejo contestó antes) se mata: no ocupa un hueco del tope hasta su plazo
   function dropOrphans() {
      if (C.noKill) return;
      for (var mk in B.subs) if (B.subs.hasOwnProperty(mk)) {
         var s = B.subs[mk];
         if (s.st !== "running" || !s.p || subWanted(s)) continue;
         try { s.p.proc.kill(); } catch (eK) {}
         stats.orphans = (stats.orphans || 0) + 1;
         var a = reapJudge(s.p, false, true);
         C.netLog({ url: C.mirrors[s.m][0], key: s.key, kind: "dropped", code: a.code, ms: a.ms, exit: a.exit, mirror: true });
         s.st = "done"; s.p = null; delete B.subs[mk];
      }
   }
   function killAll() {
      if (C.noKill) { for (var j = 0; j < B.its.length; ++j) if (B.its[j].st !== "done" && B.its[j].st !== "lazy") finish(B.its[j], abortResp()); return; }
      while (pool.procs.length) {
         var p = pool.procs[0];
         try { p.proc.kill(); } catch (eK) {}
         ++stats.killed;
         reapJudge(p, false, true);
      }
      for (var i = 0; i < B.its.length; ++i) if (B.its[i].st !== "done" && B.its[i].st !== "lazy") finish(B.its[i], abortResp());
      B.subs = {};
   }
   function step(waitMs, silent) {
      var i, now;
      B.stepping = true;
      if (pool.procs.length) { try { pool.procs[0].proc.waitForFinished(waitMs); } catch (eW) {} }
      else { now = Date.now(); while (Date.now() - now < Math.min(waitMs, 40)) { try { CoreApplication.processEvents(); } catch (eP) {} } }
      for (i = pool.procs.length - 1; i >= 0; --i) {
         var p = pool.procs[i], busy = cshBatchRunning(p.proc), cut = false;
         if (busy && Date.now() - p.t0 > (p.limit + 3) * 1000) { cut = true; try { p.proc.kill(); } catch (eK) {} try { p.proc.waitForFinished(2000); } catch (eW2) {} busy = false; }
         if (busy) continue;
         var kind = p.kind, owner = p.it, sub = p.sub, a = reapJudge(p, cut, false);
         if (kind === "tap") onPrimary(owner, a); else onSub(sub, a);
      }
      if (aborting()) { killAll(); B.stepping = false; return; }
      now = Date.now();
      for (i = 0; i < B.its.length; ++i) {
         var it = B.its[i];
         // (30-oct-2026, revision de Codex) el reintento vencido espera hueco como todos: sin esto, 8 curl vivos + este = 9 (csh_carga_node M13; costura CSH_NET_BREAK=noretryroom)
         var roomNow = pool.room() || cshNetBrk("noretryroom");
         if (it.st === "retrywait") { if (now >= it.retryAt && roomNow) startPrimary(it); }
         else if (it.st === "waitprobe" && !B.probe) {
            if (B.probeOk) { if (roomNow) startPrimary(it); }                                  // el reintento del otro contestó: este también reintenta
            else if (mirror && it.first.netFail) { it.prim = it.first; startMirror(it, 0); }   // tampoco contestó: al espejo
            else finish(it, it.first);
         }
      }
      dropOrphans();
      fill();
      B.stepping = false;
      if (live) NET.lastCall = Date.now();
      if (silent !== true && typeof C.onTick === "function" && Date.now() - B.lastTick >= 100) {
         B.lastTick = Date.now();
         try { C.onTick(Date.now() - t0, { pending: B.pending(), live: pool.procs.length, done: B.its.filter(function(x) { return x.st === "done"; }).length, total: B.its.length }); } catch (eT) {}
      }
   }
   B.add = function(list) {
      for (var i = 0; i < (list || []).length; ++i) {
         var k = String(list[i].key), q = String(list[i].adql), sg = k + "\n" + q;
         if (B.map.hasOwnProperty(sg)) continue;
         var it = { key: k, adql: q, st: "new", resp: null, p: null, first: null, prim: null, taken: false };
         B.map[sg] = B.its.length; B.its.push(it);
         begin(it);
      }
      fill();
   };
   B.take = function(adql, key) {
      var sg = String(key) + "\n" + String(adql);
      if (!B.map.hasOwnProperty(sg)) return null;
      var it = B.its[B.map[sg]];
      if (it.taken || it.st === "lazy") return null;
      it.taken = true;
      while (it.st !== "done") { if (aborting()) { killAll(); break; } step(100); }
      if (it.st !== "done") finish(it, abortResp());
      if (live) NET.lastCall = Date.now();
      return it.resp;
   };
   // (30-oct-2026) MIRAR SIN ESPERAR, para que el motor enseñe lo que ya llego aunque la consulta de delante siga en camino (GALAH en CfA: 21 s callado; medido, Abell 39):
   //   B.peek(adql, key) -> la respuesta si ya esta | null (sin gastarla: take() la da despues) · B.waiting(adql, key) -> ¿esta en camino? · B.wait(ms): un paso del lote (atiende la interfaz)
   // Y B.poke(): un paso SIN esperar y sin bombear, para el lote que se adelanta mientras otra espera bombea (un Timer en CabraStarAnalysis: la quimica mientras la red del 3D);
   // no entra si el lote ya esta dentro de un paso (el Timer salta dentro del bombeo de su propio take).
   function itemOf(adql, key) { var sg = String(key) + "\n" + String(adql); return B.map.hasOwnProperty(sg) ? B.its[B.map[sg]] : null; }
   B.peek = function(adql, key) { var it = itemOf(adql, key); return (it && it.st === "done") ? it.resp : null; };
   B.waiting = function(adql, key) { var it = itemOf(adql, key); return !!it && !it.taken && it.st !== "done" && it.st !== "lazy"; };
   B.wait = function(ms) { if (aborting()) { killAll(); return; } step(ms > 0 ? ms : 100); };
   B.poke = function() { if (B.stepping === true) return; step(0, true); };
   B.pending = function() { var out = []; for (var i = 0; i < B.its.length; ++i) if (B.its[i].st !== "done" && B.its[i].st !== "lazy") out.push(B.its[i].key); return out; };
   // al acabar el análisis (o al cerrar): lo que siga vivo (consultas saltadas por «servidor caído») se mata
   B.close = function() {
      if (C.noKill) return;
      while (pool.procs.length) { var p = pool.procs[0]; try { p.proc.kill(); } catch (eK) {} ++stats.killed; reapJudge(p, false, true); }
   };
   B.add(items);
   return B;
}
