// ============================================================================
// CabraShared/csh_atlas.js — ATLAS / CABRASPACE: los tokens y lo comun de pintar (15-oct-2026)
// ----------------------------------------------------------------------------
// Los tokens son los de CabraBase/estilo/tokens.json (paleta «carbon», acento oro). Cada script los tenia copiados
// (CabraStars CS_ATLAS, Cabra3D CP_ATLAS, CabraComposition CC_ATLAS, con los mismos valores): ahora los tres son
// CSH_ATLAS. Aqui van tambien los ayudantes de color y letra que CabraStars y Cabra3D tenian duplicados (cpHexRgb, cpMix,
// cpQss, cpInt, cpFont, cpElide…), los enteros de pintar CP_INT_* y el «sin foco» (la trama azul de Qt: un control con
// estilo que toma el foco de teclado la pinta; `focusStyle = 0` —la constante FocusStyle_NoFocus NO existe en PJSR,
// sonda CabraStars/tests/cs_probe_focus.js— y nunca boton por defecto).
// PROCEDENCIA: CabraPilot ui/atlas.js (via Cabra3D src/ui/atlas.js) y CabraStars lib/cs_atlas.js. ES5.
// ============================================================================

var CSH_ATLAS = {
   motion: { duration: 600 },        // ms (tokens.json · motion.duration; CabraStars lo lee asi)
   motionMs: 600,                    // (CabraComposition lo lee asi)
   version: "1.0.0",                 // la de CabraBase/estilo/tokens.json
   palette: "carbon",                // «Carbón cálido»

   // Paleta (tokens.json · palettes.carbon)
   bg:       "#110D09",              // fondo de ventana
   surface:  "#1B140E",              // tarjetas
   surface2: "#281D14",              // hover y seleccionado
   line:     "#3D2E1F",              // filetes y bordes (1 px)
   text:     "#FBF2E0",              // principal
   text2:    "#D0C1A5",              // secundario
   text3:    "#A3957B",              // apagado

   // Acento (tokens.json · accent)
   gold:      "#E5B53F",
   goldLight: "#F3D27E",
   ink:       "#1A1204",             // texto sobre oro
   vermilion: "#E0603F",             // SOLO errores y alertas; nunca decorativo
   ok:        "#7FB77E",
   warn:      "#E5B53F",
   error:     "#E0603F",

   // Series (tokens.json · chart). El azul es el único «frío» de la paleta: es
   // el de las marcas de comparación.
   chart: ["#E5B53F", "#7FA8D8", "#E0603F", "#7FB77E", "#C9A7E8", "#D0C1A5"],

   // Forma
   radius: { pill: 999, card: 22, panel: 36, plate: 10, control: 8 },
   space: [4, 8, 12, 16, 24, 32, 48, 64, 88, 128],
   labelTracking: 0.26,              // em, en las versalitas
   ornament: {
      doubleRuleGap: 1,
      innerFrameInset: 7,
      innerFrameAlpha: 0.16,
      outlineOffset: 3,
      outlineOffsetHover: 6
   },

   // Tipografía. tokens.json pide Bodoni Moda / Figtree / IBM Plex Mono; aquí
   // van SUS RESPALDOS, que son los que hay en Windows (decisión de Nino). Cada
   // lista se recorre hasta la primera familia instalada.
   fonts: {
      display: ["Georgia", "Constantia", "Cambria", "DejaVu Serif"],
      text:    ["Segoe UI", "DejaVu Sans"],
      mono:    ["Consolas", "DejaVu Sans Mono"]
   },
   // Cuerpo de escritorio. tokens.json dice 10 / 16 / 9 en PUNTOS (Tk); aquí son
   // píxeles lógicos, que es en lo que estaba maquetado CabraPilot: en puntos
   // todo saldría un tercio mayor y se moverían todos los suelos por texto.
   size: { body: 10, title: 16, label: 9, hero: 22 },   // (hero: CabraStars)

   // El HISTOGRAMA (10-oct-2026). Son colores de DATOS (los canales), no de la
   // marca: no están en tokens.json (L0-17 no los compara). El panel
   // (ui/histogram_panel.js) no escribe ni un color, ni un alfa, ni una medida a
   // mano: sale de aquí. Las curvas son rellenos SEMITRANSPARENTES con un trazo
   // antialias encima.
   // ESTILO A (decisión de Nino, 10-oct-2026):
   //   · COLOR: cada canal es un relleno semitransparente con su trazo encima, y los
   //     rellenos se SUMAN como luz (CompositionOp_Add: R+G amarillo, G+B cian, R+B
   //     magenta, los tres un neutro tenue), no un color tapando a otro. Colores
   //     suaves, elegidos por Nino.
   //   · MONOCROMO: trazo DORADO (el oro de Atlas) y relleno GRIS semitransparente con
   //     brillo: degradado vertical (más claro junto a la línea, más transparente
   //     hacia la base) y un reflejo fino claro bajo la línea de oro.
   //   · Lo ROJO es solo la zona recortada a negro.
   // Medidas en píxeles LÓGICOS (el panel las multiplica por la escala de la pantalla).
   hist: {
      r: "#E8705A", g: "#7FB77E", b: "#7FA8D8", k: "#FBF2E0",
      fillAlpha: 0.16,              // relleno de cada canal de color (se suman: tienen que dar un neutro legible)
      lineAlpha: 0.95,              // trazo de cada canal de color
      kFillAlpha: 0.07,             // la luminancia de una imagen en color es el fondo: más tenue
      kLineAlpha: 0.25,
      lineWidth: 1.5,               // grosor del trazo
      monoFill: "#D6D2CB",          // monocromo: gris neutro-cálido
      monoFillTop: 0.34,            // opacidad del relleno JUNTO a la línea
      monoFillBottom: 0.05,         // y en la base
      monoBands: 16,                // el degradado son tantas franjas apiladas (Graphics no recorta por polígono)
      monoGloss: 0.35,              // reflejo claro bajo la línea de oro (alfa)
      monoGlossWidth: 2,            // y su grosor
      clipTintAlpha: 0.16,          // lo recortado a negro (a la izquierda de S), sobre el rojo de alertas
      // EL FANTASMA DE «OUTPUT» (11-oct-2026, decisión de Nino: «que aparezca en el mismo histograma pero más
      // transparente, como un fantasma de fondo»). El histograma de SALIDA se pinta en el MISMO trazado que el de
      // entrada, DETRÁS y más tenue: relleno plano (sin degradado ni reflejo) y un trazo fino. En color, cada canal
      // con su color y los rellenos sumados como luz; en monocromo, el gris del relleno y un trazo crema (no dorado:
      // el oro es la línea de la ENTRADA). Todos por debajo de los de la entrada: lo vigila L0-68.
      ghostFillAlpha: 0.07,         // relleno de cada canal de color del fantasma (la entrada: fillAlpha)
      ghostLineAlpha: 0.42,         // su trazo (la entrada: lineAlpha)
      ghostMonoFillAlpha: 0.11,     // relleno del fantasma monocromo (la entrada: monoFillTop junto a la línea)
      ghostLineWidth: 1,            // grosor del trazo del fantasma (la entrada: lineWidth)
      ghostEdgeAlpha: 0.35,         // las barras de sus extremos (lo que acaba en 0 y en 1)
      ghostLabelPlate: 0.78,        // la plaquita oscura bajo su rótulo («OUTPUT»), que va encima de los histogramas
      gridAlpha: 0.5,
      markAlpha: 0.31,              // rayas de los marcadores estadísticos
      markMedAlpha: 0.5,            // y la de la mediana
      cursorAlpha: 0.31,
      pad: 8,                       // margen lateral y superior del trazado
      tabW: 16, tabH: 14, tabRadius: 4,   // tiradores S / M / H, colgados bajo el trazado
      axisH: 12,                    // franja de la escala 0 … 1
      bottomPad: 8,                 // y el asa para estirar el alto (las ultimas filas del lienzo)
      pointRadius: 4,               // punto de control de la curva (circulo dorado), y mas grande cuando esta bajo el cursor
      pointOffAlpha: 0.55,          // el que no actua (fuera de S..H)
      // LA CURVA DE TRANSFERENCIA (10-oct-2026): crema, fina y DISCONTINUA. Era dorada, como la linea de arriba del
      // histograma monocromo (que Nino pidio dorada) y las dos se confundian; el dorado queda para esa linea, el
      // mando M y los puntos de control. Lo discontinuo la separa tambien del trazo continuo de cada canal.
      curveAlpha: 0.9,
      curveWidth: 1.5,
      // EL EDITOR DE CURVAS (11-oct-2026, tarde; Nino, tras probar «Curves» en pantalla: «no se ve la linea diagonal
      // sobre la que marcar puntos y actuar»). Con el motor «Curves» de STRETCH el lienzo deja de ser un histograma
      // con una curva encima y pasa a ser un EDITOR DE CURVAS con el histograma de fondo: la curva manda (continua,
      // gruesa, crema, con un halo oscuro que la separa de lo que tenga debajo), la identidad queda de referencia
      // (fina y discontinua), la rejilla va a cuartos en los dos ejes, los extremos (0,0) y (1,1) se ven como anclas
      // fijas (cuadradas: no se arrastran) y los puntos de control como circulos dorados (redondos: se arrastran). El
      // histograma de la imagen, una silueta tenue SIN trazo (el oro y el trazo son de la curva y de sus puntos).
      editCurveWidth: 2.25,         // la curva que se edita
      editCurveHalo: 5,             // el halo oscuro bajo ella (grosor) …
      editCurveHaloAlpha: 0.7,      // … y su alfa (sobre el fondo del trazado)
      editIdentityAlpha: 0.5,       // la identidad de referencia (el gris de los textos apagados)
      editGridAlpha: 0.95,          // la rejilla a cuartos (el filete de Atlas: discreta, pero se ve)
      // (14-oct-2026: la silueta, mas tenue —0,2 → 0,14 y 0,1 → 0,06—. MIRADO con una imagen de color y la escala
      //  logaritmica: las cuatro siluetas sumadas llenaban el trazado de un beige casi tan claro como la curva crema.)
      editBackMonoAlpha: 0.14,      // la silueta del histograma de fondo, monocromo (la entrada normal: monoFillTop 0,34 y trazo de oro)
      editBackFillAlpha: 0.06,      // y la de cada canal de color (la entrada normal: fillAlpha 0,16 y su trazo)
      editAnchor: 3.5,              // media anchura del ancla cuadrada de (0,0) y (1,1)
      editPoint: 5,                 // radio de un punto de control EN EL EDITOR (un tirador: mas que pointRadius) …
      editPointHeld: 3,             // … y lo que crece el AGARRADO (el que esta bajo el cursor crece 2, como siempre)
      editPointHit: 12,             // a cuanto del centro se coge (px logicos): generoso, sin punteria de relojero
      editGuideAlpha: 0.55,         // las guias del punto caliente hasta los dos ejes (oro)
      editSkyAlpha: 0.6,            // la marca de donde cae el fondo (la mediana), sobre el gris de los textos secundarios
      editHintAlpha: 0.9,           // la pista de los gestos, con la curva sin puntos
      editPlate: 0.86,              // la plaquita oscura bajo la lectura entrada → salida del punto caliente
      maxExtraH: 220,               // lo maximo que se puede estirar el alto (px del lienzo, sin escalar como CP_HIST_CANVAS_H)
      edgeAlpha: 0.75,              // barra de los bins de los extremos (0 y 1)
      // Anchura del suavizado, en BINS (σ de una gaussiana). SOLO del dibujo:
      // el recorte, los porcentajes, los puntos automáticos y las lecturas se
      // calculan siempre sobre los conteos sin suavizar. 0 = sin suavizado.
      smoothSigma: 2.0,
      // Si más de esta fracción de los bins entre el primero y el último no
      // vacíos están VACÍOS, el histograma es «en peine» (imagen muy estirada):
      // ahí el suavizado se limita para que los dientes se sigan viendo.
      // Las colas de pocos conteos (ruido de Poisson) se suavizan tailWiden veces mas
      // ancho: el peso es el conteo suavizado entre tailCount (1 = ancho normal).
      tailCount: 40,
      tailWiden: 3,
      combGapFraction: 0.18,
      combSigma: 0.45,
      edgeBars: true                // dibujar los bins 0 y 1 (recorte) como barras
   }
};

function cpHexRgb(hex) {
   var h = String(hex).replace("#", "");
   return [parseInt(h.substring(0, 2), 16), parseInt(h.substring(2, 4), 16), parseInt(h.substring(4, 6), 16)];
}

function cpHex2(n) {
   var s = Math.max(0, Math.min(255, Math.round(n))).toString(16);
   return (s.length < 2) ? "0" + s : s;
}

// Mezcla de dos tokens: t = 0 da `a`, t = 1 da `b`. Los tonos intermedios se
// DERIVAN (lección de CabraTransit): no se inventa un hex nuevo por cada matiz.
function cpMix(a, b, t) {
   var A = cpHexRgb(a), B = cpHexRgb(b);
   return "#" + cpHex2(A[0] + (B[0] - A[0]) * t) + cpHex2(A[1] + (B[1] - A[1]) * t) + cpHex2(A[2] + (B[2] - A[2]) * t);
}

// Para una hoja Qt: "#AARRGGBB" (Qt lee el alfa PRIMERO).
function cpQss(hex, alpha) {
   var a = (alpha === undefined) ? 1 : alpha;
   return "#" + cpHex2(a * 255) + String(hex).replace("#", "");
}

// Para pintar con Graphics: entero 0xAARRGGBB.
function cpInt(hex, alpha) {
   var c = cpHexRgb(hex);
   var a = (alpha === undefined) ? 255 : Math.max(0, Math.min(255, Math.round(alpha * 255)));
   return ((a << 24) | (c[0] << 16) | (c[1] << 8) | c[2]) >>> 0;
}

var CP_FONT_FAMILY_CACHE = {};

// La primera familia INSTALADA de la lista del papel («display», «text»,
// «mono»). Si ninguna lo está, la última: Qt pondrá su respaldo.
function cpFontFamily(role) {
   if (Object.prototype.hasOwnProperty.call(CP_FONT_FAMILY_CACHE, role))
      return CP_FONT_FAMILY_CACHE[role];
   var list = CSH_ATLAS.fonts[role] || CSH_ATLAS.fonts.text;
   var chosen = list[list.length - 1];
   for (var i = 0; i < list.length; ++i) {
      var ok = false;
      try { ok = (new Font(list[i])).isExactMatch === true; } catch (e) {}
      if (ok) { chosen = list[i]; break; }
   }
   CP_FONT_FAMILY_CACHE[role] = chosen;
   return chosen;
}

// La familia, lista para una hoja Qt (con la genérica detrás).
function cpFontCss(role) {
   var generic = (role === "display") ? "serif" : ((role === "mono") ? "monospace" : "sans-serif");
   return "'" + cpFontFamily(role) + "'," + generic;
}

// Fuentes para PINTAR, cacheadas. Antes cada `onPaint` de cada celda hacía
// `new Font(...)`: con el resalte al pasar el ratón eso sería un `new` por
// celda y por movimiento. `px` va en píxeles FÍSICOS (pásalo por `cpPx`);
// `spacing`, en píxeles físicos por letra (ver la nota de `Font.letterSpacing`).
var CP_FONT_CACHE = {};
function cpFont(role, px, bold, italic, spacing) {
   var size = Math.max(6, Math.round(px));
   var sp = Math.round(spacing || 0);
   var key = role + "|" + size + "|" + (bold ? 1 : 0) + (italic ? 1 : 0) + "|" + sp;
   if (Object.prototype.hasOwnProperty.call(CP_FONT_CACHE, key))
      return CP_FONT_CACHE[key];
   var f = new Font(cpFontFamily(role));
   f.pixelSize = size;
   if (bold) f.bold = true;
   if (italic) f.italic = true;
   if (sp !== 0) { try { f.letterSpacing = sp; } catch (e) {} }
   CP_FONT_CACHE[key] = f;
   return f;
}

// Separación de las versalitas para un cuerpo dado (px físicos).
function cpCapsSpacing(px) {
   return Math.max(1, Math.round(px * CSH_ATLAS.labelTracking));
}

// Corta un texto con «…» para que quepa en `maxW` píxeles, MIDIENDO con la
// fuente que lo va a pintar (antes era `ancho / 9`, una constante).
function cpElide(font, text, maxW) {
   var t = String(text);
   if (font.width(t) <= maxW)
      return t;
   var lo = 0, hi = t.length;
   while (lo < hi) {
      var mid = Math.ceil((lo + hi) / 2);
      if (font.width(t.substring(0, mid) + "…") <= maxW) lo = mid; else hi = mid - 1;
   }
   return (lo > 0) ? (t.substring(0, lo) + "…") : "…";
}

function cpTextH(font) { var h = 12; try { h = font.ascent + font.descent; } catch (e) {} return h; }

// Enteros para pintar con Graphics (0xAARRGGBB). Los nombres «AMBER» vienen de CabraPilot.
var CP_INT_BG = cpInt(CSH_ATLAS.bg), CP_INT_SURFACE = cpInt(CSH_ATLAS.surface), CP_INT_SURFACE2 = cpInt(CSH_ATLAS.surface2), CP_INT_BORDER = cpInt(CSH_ATLAS.line);
var CP_INT_TEXT = cpInt(CSH_ATLAS.text), CP_INT_TEXT2 = cpInt(CSH_ATLAS.text2), CP_INT_MUTED = cpInt(CSH_ATLAS.text3), CP_INT_AMBER = cpInt(CSH_ATLAS.gold);
var CP_INT_AMBERLIGHT = cpInt(CSH_ATLAS.goldLight), CP_INT_ERROR = cpInt(CSH_ATLAS.error), CP_INT_OK = cpInt(CSH_ATLAS.ok);

// SIN FOCO: ningun control toma el foco de teclado (ni es boton por defecto: Intro no lo dispara a escondidas).
function cshNoFocus(ctrl) {
   try { if (typeof ctrl.focusStyle === "number" && ctrl.focusStyle !== 0) ctrl.focusStyle = 0; } catch (e) {}
   try { if (ctrl.defaultButton === true) ctrl.defaultButton = false; } catch (e2) {}
   return ctrl;
}
// Todos los de un dialogo (PJSR no da `children`: se recorren sus propiedades y los grupos {} / [] de controles, un nivel).
// `skip`: claves que no son controles (datos grandes). Devuelve cuantos se han cambiado.
function cshNoFocusAll(dlg, skip) {
   var S = skip || {}, n = 0;
   function fix(v) { try { if (v && typeof v === "object" && v !== dlg && typeof v.focusStyle === "number" && v.focusStyle !== 0) { v.focusStyle = 0; return 1; } } catch (e) {} return 0; }
   for (var k in dlg) {
      if (S[k]) continue;
      var v = null; try { v = dlg[k]; } catch (e0) { continue; }
      if (!v || typeof v !== "object") continue;
      if (typeof v.focusStyle === "number") { n += fix(v); continue; }
      for (var j in v) { var w = null; try { w = v[j]; } catch (e1) { continue; } if (w && typeof w === "object") { n += fix(w); if (w.head) n += fix(w.head); } }
   }
   return n;
}
