#ifndef __CSH_CLOCK_JS
#define __CSH_CLOCK_JS
// ============================================================================
// CabraShared/csh_clock.js — EL RELOJ ANALÓGICO de los vídeos con evolución temporal (24-oct-2026, fase 1)
// ----------------------------------------------------------------------------
// Petición de Nino: en lugar de la placa de texto «RELOJ CÓSMICO / hace 9,3 Ga», un reloj de esfera antiguo pero
// esquemático, con la estética de los dibujos de cabraspace.com (oro, línea fina, lámina antigua), cuya manecilla vaya
// hacia delante y hacia atrás con el reloj del vídeo y señale los Ga con claridad. La cifra exacta sigue, pequeña, debajo.
//
// MÓDULO PURO DE DIBUJO: sin estado; Graphics + una ESCALA. La geometría (ángulos, marcas, cifras, cajas) se calcula aparte
// del dibujo para que node la pruebe sin PixInsight (CabraComposition/tests/cc_node_clock.js).
//
//   LA ESCALA (S): { kind, from, to (en la unidad de la escala; pasado NEGATIVO, futuro positivo), unit ("Ga" | "Ma"),
//                   major, half, minor (pasos de las marcas), labelSteps (cifras: el primer paso que quepa sin pisarse),
//                   ends [inicio, fin] ({ sym } | { text } | null), epochs [{ v, sym }], fine (vuelta de la aguja fina), cw }
//      cshClockScaleCosmic(U)      CabraComposition: del Big Bang (−U Ga) a hoy (0); cifras «Ga atrás» 13 … 1, «hoy» al final.
//      cshClockScaleSymYears(years) Cabra3D, la máquina del tiempo (fase 2, 25-oct): TODAS sus escalas, ±1 000 años … ±1 Ga (en AÑOS), cada una
//                                  en su unidad (años · ka · Ma · Ga); pasado a la izquierda, «hoy» en lo alto, futuro a la derecha; cifras
//                                  sin signo en el anillo y con signo en los dos extremos. cshClockScaleSym(rangeMa) es la de antes (en Ma).
//      cshClockValue(S, years)     un instante en AÑOS → el valor de la escala (Ga atrás para la cósmica: −T), lo que pide cshClockPaint.
//   EL SENTIDO: el tiempo hacia delante gira a FAVOR de las agujas del reloj en todas las escalas; la escala ocupa un arco
//      simétrico respecto a las 12 (así «hoy» queda arriba en las simétricas sin ninguna regla especial).
//   LAS SEIS VARIANTES (CSH_CLOCK.V; la elegida, CSH_CLOCK.DEFAULT, se cambia en una línea; 26-oct: R4 = D, decisión de Nino del 25-oct):
//      A «Esfera»          arco de 300°, UNA manecilla (lanza con rombo), la unidad en el hueco de abajo.
//      B «Esfera y aguja»  A + una esfera pequeña arriba con una aguja fina que da una vuelta por cada marca mayor
//                          (1 Ga en CabraComposition): se mueve aunque la principal casi no lo haga (los últimos 210 Ma de III).
//      C «Limbo»           medio círculo (180°) como el limbo de un sextante, UNA manecilla (aguja con luna de Breguet),
//                          más ancho que alto: tapa la mitad de alto que A con el mismo radio.
//      DE BOLSILLO, s. XIX (25-oct; hasta el 26-oct en csh_clock_pocket.js, que se borró: ahora son variantes normales, V.pocket = true):
//      el arco y el ángulo de A, con su caja (cuello, corona, anilla), su esfera, sus cifras y su manecilla. Cada una lleva SU geometría
//      (V.geo: los radios que cambian frente a CSH_CLOCK; cshClockLayout los lee sin tocar CSH_CLOCK) y SUS cifras (V.numerals).
//      D «Esmalte romano»  (LA DE FÁBRICA) esfera esmaltada (la superficie del tema), romanos en Ga (cósmica; en las simétricas de Cabra3D,
//                          arábigas con el anillo «ancho»: 25 · 50 · 75 no tienen romano decente), minutería de puntos, borde de moneda,
//                          manecilla Breguet «pomme», corona estriada y anilla redonda.
//      E «Saboneta»        la tapa abierta abajo con la cifra exacta GRABADA (sustituye a la pastilla), guilloché, cursivas, pica calada, leontina.
//      F «Ferrocarril»     cifras de palo seminegras, minutería de raíles, subesfera a las 6 (1 vuelta por marca mayor), manecilla de catedral.
//   «HOY» UNA SOLA VEZ (R2, 26-oct, Nino): en «hoy» la palabra salía en la esfera (la cifra de la escala) y en la cifra exacta de debajo. Se
//      queda la de la ESFERA (es la escala: está en todos los fotogramas y la manecilla la señala; quitarla dejaría la punta del arco sin
//      nombre el resto del vídeo) y la cifra exacta NO se pinta cuando dice lo mismo (cshClockCaptionShown); su sitio se reserva igual (la
//      caja no cambia de alto al pasar por «hoy»).
//   REGLAS DE DIBUJO (las prueba node): la punta de la manecilla NO llega a las cifras (R_HAND < R_NUM_IN), ninguna cifra
//      pisa a otra ni sale del bisel (si no caben, se pasa al siguiente paso de labelSteps; si tampoco, se achica hasta
//      NUM_SHRINK y por fin se quita), los dos extremos de la escala van en el hueco de abajo (A, B) o bajo la base (C).
//   API:
//      cshClockAngle(S, v, variant)        grados desde las 12, a favor del reloj (continuo, acotado a [from, to])
//      cshClockFineAngle(S, v)             grados de la aguja fina [0, 360)
//      (26-oct, la inversa: arrastrar la manecilla) cshClockPointerDeg(cx, cy, x, y) grados del ratón · cshClockValueAt(S, deg, variant) el valor,
//                                          acotado al arco · cshClockYearsOf(S, v) años · cshClockYearsAt(S, deg, variant) los dos de una vez
//      cshClockLayout(S, R, variant, fontFn, lang)   la geometría entera (relativa al eje), sin pintar
//      cshClockFootprint(L, caption, fontFn)         { w, h, ox, oy }: la caja que ocupa y dónde va el eje dentro
//      cshClockPaint(g, x0, y0, R, S, v, o)          pinta con la esquina superior izquierda en (x0, y0); devuelve lo pintado
//         o = { variant, lang ("es" | "en"), caption (la cifra exacta, la da quien llama), fontFn(role, px, bold, italic, sp),
//               textFn(g, font, colorInt, x, y, s) (para que el anfitrión apunte los textos en sus pruebas), alpha,
//               faceAlpha (26-oct, Nino: «un poco de transparencia para que se vea lo que pasa por debajo pero que se pueda leer»: 0–1,
//               la opacidad SOLO del fondo de la esfera y de la pastilla de la cifra exacta —de bolsillo, D y F—; líneas, cifras, manecilla
//               y texto siguen a plena opacidad (alpha, en cambio, atenúa todo: es el fundido). Sin ella, opaco, como siempre) }
//      (las tres reparten solas: con una de bolsillo, L.pocket, van a cshClockPocketFootprint / cshClockPocketPaint, que devuelve lo mismo + sub,
//       lid, pocket, handAt. Piezas de bolsillo para las pruebas: cshPocketRoman(n), cshClockPocketHand, cshPocketHandAt, cshPocketHandBoxDist,
//       cshPocketHandCircleDist; CSH_CLOCK.POCKET, lo común.)
//      cshClockCaptionShown(caption)       la cifra exacta que se pinta: "" si dice «hoy» (R2: ya lo dice la esfera)
// COLORES Y LETRAS: los tokens (CSH_ATLAS de csh_atlas.js: oro, oro claro, crema, carbón; display = Bodoni Moda → su respaldo
//   instalado, Georgia). Ningún color nuevo.
// Costuras de prueba (CSH_CLOCK_BREAK): jump (la manecilla salta de marca en marca), ccw (gira al revés), noclamp (sin
//   acotar), asym (la simétrica con «hoy» fuera de las 12), longhand (la punta llega a las cifras), nothin (cifras sin aclarar),
//   yrunit (cshClockValue pasa los años a Ma sea cual sea la unidad), dot (el punto decimal también en castellano),
//   gap14 (los extremos de las simétricas a 14° de la punta, como en la fase 1: se leían como una suma «−100 +100»).
//   De bolsillo (las de csh_clock_pocket.js, mismas palabras): roman (romanos solo aditivos: IIII, VIIII), crownout (la caja sin la corona),
//   subbig (subesfera de 0,20 R sin achicar), lidsmall (la tapa de E aplastada), romansmall (los romanos al 0,6). Y (26-oct): geoglobal (la
//   geometría de la variante se ESCRIBE en CSH_CLOCK, como hacía csh_clock_pocket.js, y no se devuelve), today2 («hoy» otra vez en la cifra
//   exacta), shorthand (la manecilla de D a 0,545 R, la de antes), capsmall (la cifra exacta sin el suelo de letra de quien llama, opt.minPx),
//   opaque (26-oct: la esfera y la pastilla opacas aunque se pida faceAlpha: lo de antes). ptry (26-oct: cshClockPointerDeg olvida que la y crece
//   hacia abajo: el ratón arriba se lee abajo).
// ES5 (se incluye desde ficheros con #engine v8). Comentarios en castellano; identificadores en inglés.
// ============================================================================

// LAS GEOMETRÍAS PROPIAS de las de bolsillo (los radios que cambian frente a CSH_CLOCK, en fracción de R). Medidas del 25-oct (node con los anchos
// de Georgia medidos en PixInsight, y sonda): los romanos —XIII, VIII— y las cifras de palo seminegras no cabían a 15 px en el anillo de A (0,655 a
// 0,895 R; D bajaba a una cifra cada 2 Ga de 12,9 px). «WIDE»: las cifras ganan 0,05 R hacia dentro y hacia fuera; marcas, manecilla y Sol se
// recogen lo mismo (la punta, 0,03 R antes de las cifras, como en A). «ROMAN» (D con romanos): 0,345 R de anillo (0,575 a 0,92) para ir CADA Ga a
// 15 px, y 0,12 de separación entre cajas (Georgia a 15 px redondea el avance de cada letra: «VIII» 31 px frente a 27,6 lineal).
// LA MANECILLA DE D (26-oct, R4: «alargar la manecilla», el revisor tardaba un vistazo en pasar de la punta al IX/X): de 0,545 a 0,565 R. MEDIDO
// (node con la letra calibrada, todo el recorrido, polígono + halo, R 61–208, ES y EN): a 0,545 la punta quedaba a 6,0 px de la cifra a la que
// apunta a R 104 (0,057 R) con 2,8 px libres en lo más justo («XIII» a −137°); a 0,565, 4,6 px (0,044 R) y 0,7 px libres; a 0,575 ya la toca
// (−0,3 px). Detalle y sonda: CabraComposition/docs/reloj_analogico.md, «26-oct · R4 = D».
var CSH_CLOCK_GEO_WIDE = { R_NUM_OUT: 0.905, R_NUM_IN: 0.615, R_TICK0: 0.495, R_TICK_MINOR: 0.528, R_TICK_HALF: 0.55, R_TICK_MAJOR: 0.60, R_HAND: 0.585, R_TAIL: 0.14, R_EPOCH: 0.42 };
var CSH_CLOCK_GEO_ROMAN = { LABEL_PAD: 0.12, R_NUM_OUT: 0.92, R_NUM_IN: 0.575, R_TICK0: 0.455, R_TICK_MINOR: 0.487, R_TICK_HALF: 0.51, R_TICK_MAJOR: 0.56, R_HAND: 0.565, R_TAIL: 0.13, R_EPOCH: 0.39 };
var CSH_CLOCK = {
   DEFAULT: "D",
   V: {
      A: { span: 300, shape: "disc", hand: "lance", sub: false, name: ["Dial", "Esfera"] },
      B: { span: 300, shape: "disc", hand: "lance", sub: true, name: ["Dial and fine hand", "Esfera y aguja"] },
      C: { span: 180, shape: "limb", hand: "needle", sub: false, name: ["Limb", "Limbo"] },
      // (geo: la de las cifras de la variante; geoArabic: la de D cuando la escala no es cósmica —arábigas—)
      D: { span: 300, shape: "disc", hand: "pomme", sub: false, pocket: true, name: ["Enamel, Roman numerals", "Esmalte romano"], numerals: "roman", face: "surface", edge: "coin", track: "dots",
           crown: { w: 0.105, h: 0.11 }, bow: { cy: 1.11, rx: 0.19, ry: 0.21 }, lid: false, chain: false, inner: true, geo: CSH_CLOCK_GEO_ROMAN, geoArabic: CSH_CLOCK_GEO_WIDE },
      E: { span: 300, shape: "disc", hand: "spade", sub: false, pocket: true, name: ["Hunter", "Saboneta"], numerals: "italic", face: "bg", edge: "wave", track: "lines",
           crown: { w: 0.10, h: 0.11 }, bow: { cy: 1.12, rx: 0.16, ry: 0.25 }, lid: true, chain: true, guilloche: true, inner: false, geo: null },
      F: { span: 300, shape: "disc", hand: "cathedral", sub: true, pocket: true, name: ["Railroad", "Ferrocarril"], numerals: "sans", face: "bg", edge: "plain", track: "rail",
           crown: { w: 0.13, h: 0.13 }, bow: { cy: 1.12, rx: 0.22, ry: 0.22 }, lid: false, chain: false, inner: false, geo: CSH_CLOCK_GEO_WIDE }
   },
   // lo común de las de bolsillo (fracciones de R): cuello, anilla, subesfera de F, tapa de E, halo de la manecilla, cuerpo de los romanos
   POCKET: {
      NECK: { y0: 0.97, y1: 1.07, w0: 0.075, w1: 0.06 },
      BOW_END_DEG: 125,                                      // la anilla va de −125° a +125° (0 = arriba): sus puntas mueren en el hombro de la caja
      SUB: { y: 0.36, r: 0.115, rMin: 0.075 },
      LID: { gap: 0.07, rx: 0.90, ryMin: 0.27, knW: 0.10, inner: 0.72 },
      HALO: 1.1,                                             // el trazo oscuro bajo la manecilla, en múltiplos de lw a cada lado
      ROMAN_K: 0.96,                                         // D: el cuerpo de los romanos frente al de las cifras de A
      HAND_REF: 0.625                                        // las formas de las manecillas se dibujaron para una punta a 0,625 R (la de A) y se escalan a la suya
   },
   // radios, en fracción de R (el radio del bisel exterior)
   R_BEZEL2: 0.935,          // el segundo filete del bisel (el doble filete de la guía: doubleRuleGap)
   R_NUM_OUT: 0.895,         // el borde exterior de las cifras
   R_NUM_IN: 0.655,          // el borde interior de las cifras: ni la manecilla ni las marcas pasan de aquí
   R_TICK0: 0.535, R_TICK_MINOR: 0.568, R_TICK_HALF: 0.59, R_TICK_MAJOR: 0.64,
   R_HAND: 0.625, R_TAIL: 0.15, R_EPOCH: 0.455, R_INNER: 0.30,
   NUM_PX: 0.155, NUM_MIN_PX: 9, NUM_SHRINK: 0.8, CAP_PX: 0.15, CAP_MIN_PX: 10, UNIT_PX: 0.088, UNIT_MIN_PX: 7, UNIT_TRACK: 0.14,
   LABEL_PAD: 0.22,          // separación mínima entre cajas de cifras, en fracción de su cuerpo
   GAP_DEG: 14,              // A y B: los extremos van 14° más allá de cada punta del arco, en el hueco de abajo
   SUB: { y: -0.315, r: 0.165 },
   UNIT_Y: 0.56,             // A y B: la unidad, bajo el eje (la manecilla no baja a ese hueco)
   LIMB_BASE: 0.10           // C: la base del limbo, un poco por debajo del eje
};
var CSH_CLOCK_BREAK = "";
var CSH_CLOCK_TXT = {
   today: ["today", "hoy"], gaAgo: ["Gyr ago", "Ga atrás"], ga: ["Gyr", "Ga"], ma: ["Myr", "Ma"], ka: ["kyr", "ka"], yr: ["years", "años"]
};
function cshClockBroken(k) { return (typeof CSH_CLOCK_BREAK === "string") && CSH_CLOCK_BREAK.indexOf(k) >= 0; }
function cshClockTx(key, lang) { var e = CSH_CLOCK_TXT[key]; return e ? e[(lang === "es") ? 1 : 0] : key; }
function cshClockNum(x, d, lang) { var s = (d > 0) ? x.toFixed(d) : String(Math.round(x)); return (lang === "es" && !cshClockBroken("dot")) ? s.replace(".", ",") : s; }
function cshClockVar(variant) { return CSH_CLOCK.V[variant] ? variant : CSH_CLOCK.DEFAULT; }

// ---------------------------------------------------------------------------
// LAS ESCALAS
// ---------------------------------------------------------------------------
// CabraComposition: del Big Bang a hoy. v = −T (Ga). Marcas: 1 Ga mayor, 0,5 media, 0,25 menor. Cifras cada 1 Ga (o 2 si no caben).
function cshClockScaleCosmic(U) {
   U = (U > 0) ? U : 13.8;
   return { kind: "cosmic", from: -U, to: 0, unit: "Ga", yr: 1e9, major: 1, half: 0.5, minor: 0.25, labelSteps: [1, 2], fine: 1, cw: true,
            ends: [{ sym: "bigbang" }, { text: "today" }], epochs: [{ v: -4.57, sym: "sun" }] };
}
// Cabra3D: la máquina del tiempo, simétrica. `rangeMa` en Ma (la API de la fase 1: ±10 Ma, ±100 Ma, ±1 Ga). «hoy» en lo alto.
function cshClockScaleSym(rangeMa) { return cshClockScaleSymYears((Math.abs(rangeMa) || 100) * 1e6); }
// (fase 2, 25-oct) TODAS las escalas de la máquina del tiempo, en AÑOS (C3_TM_RANGES: ±1 000 años … ±1 000 000 000), cada una en la unidad
// en que sus cifras se leen sin ceros de más y caben en el anillo (a lo sumo dos dígitos o «d,d»: de tres no caben en las 3 y las 9; medido el 25-oct
// con ±1 000 años en años: 250 · 500 · 750 no cabían ni achicadas, y «−1000» en los extremos impedía la unidad): ka (±1, ±10 y ±100: 0,5 / 2,5 · 5 · 7,5 /
// 25 · 50 · 75), Ma (±1, ±10, ±100: ídem) y Ga (±1). «años» solo para menos de ±1 000 años (no lo usa Cabra3D). Los 7 rangos de C3_TM_RANGES caen
// en ka (3), Ma (3) y Ga (1). El valor de la escala es el instante en SU unidad (S.yr = años por
// unidad; cshClockValue). Marcas: ±10 → cada 2 (media 1, menor 0,5); el resto → cada décima parte del radio (media 1/20, menor 1/40).
function cshClockScaleSymYears(rangeYears) {
   var ry = Math.abs(rangeYears) || 1e8, unit, yr;
   if (ry >= 1e9) { unit = "Ga"; yr = 1e9; } else if (ry >= 1e6) { unit = "Ma"; yr = 1e6; } else if (ry >= 1e3) { unit = "ka"; yr = 1e3; } else { unit = "a"; yr = 1; }
   var r = ry / yr, five = (r > 2 && r < 20), M = five ? [r / 5, r / 10, r / 20] : [r / 10, r / 20, r / 40];
   return { kind: "sym", from: -r, to: r, unit: unit, yr: yr, major: M[0], half: M[1], minor: M[2], labelSteps: [r / 4, r / 2], fine: M[0], cw: true, signed: "ends",
            ends: [{ text: "from" }, { text: "to" }], epochs: [], gap: cshClockBroken("gap14") ? 0 : 6 };
}
// El instante T (años; pasado negativo) en la unidad de la escala: lo que se le da a cshClockAngle / cshClockPaint. (La cósmica es «Ga atrás»: −T.)
function cshClockValue(S, years) {
   if (S.kind === "cosmic") return years / (S.yr || 1e9);
   return years / (cshClockBroken("yrunit") ? 1e6 : (S.yr || 1e6));
}
// La cifra de una marca. Cósmica: «13» (Ga atrás, sin signo); simétrica: «−50», «+50» (signo menos tipográfico); 0 = «hoy».
function cshClockLabelText(S, v, lang, isEnd) {
   if (Math.abs(v) < 1e-9) return cshClockTx("today", lang);
   var a = Math.abs(v), d = (Math.abs(a - Math.round(a)) < 1e-9) ? 0 : ((Math.abs(a * 10 - Math.round(a * 10)) < 1e-9) ? 1 : 2), s = cshClockNum(a, d, lang);
   // (simétricas: las cifras del anillo SIN signo —a la izquierda el pasado, a la derecha el futuro— y los dos extremos CON signo: con signo
   //  «−50» no cabía en el anillo a R = 104 con Georgia; sonda del 24-oct)
   if (S.signed && (isEnd || S.signed !== "ends")) return ((v < 0) ? "−" : "+") + s;
   return s;
}
function cshClockUnitText(S, lang) {
   if (S.kind === "cosmic") return cshClockTx("gaAgo", lang);
   return cshClockTx(S.unit === "Ga" ? "ga" : (S.unit === "Ma" ? "ma" : (S.unit === "ka" ? "ka" : "yr")), lang);
}

// ---------------------------------------------------------------------------
// LA GEOMETRÍA PURA
// ---------------------------------------------------------------------------
function cshClockFrac(S, v) {
   var f = (v - S.from) / (S.to - S.from);
   if (!isFinite(f)) f = 0;
   if (!cshClockBroken("noclamp")) f = Math.max(0, Math.min(1, f));
   return f;
}
// grados desde las 12 a favor de las agujas del reloj; el arco va de −span/2 (from) a +span/2 (to)
function cshClockAngle(S, v, variant) {
   var V = CSH_CLOCK.V[cshClockVar(variant)], f = cshClockFrac(S, v);
   if (cshClockBroken("jump")) f = cshClockFrac(S, S.from + Math.round((v - S.from) / S.major) * S.major);
   var a = -V.span / 2 + V.span * f;
   if (cshClockBroken("asym") && S.kind === "sym") a += 9;
   if (S.cw === false || cshClockBroken("ccw")) a = -a;
   return a;
}
// la aguja fina: una vuelta por cada S.fine, a favor del reloj hacia delante. [0, 360)
function cshClockFineAngle(S, v) {
   var p = v / S.fine, fr = p - Math.floor(p), a = 360 * fr;
   if (cshClockBroken("ccw")) a = (360 - a) % 360;
   return a;
}
// ---------------------------------------------------------------------------
// LA INVERSA (26-oct, Cabra3D: Nino «haz que las manecillas del reloj sean interactivas»): del ratón al instante. PURA (la prueba node:
// Cabra3D/tests/c3_node_clock_drag.js). Tres pasos: el punto → grados (cshClockPointerDeg), los grados → el valor de la escala
// (cshClockValueAt, acotado al arco), el valor → años (cshClockYearsOf, la inversa de cshClockValue).
// ---------------------------------------------------------------------------
// grados desde las 12, a favor del reloj, del punto (x, y) visto desde el eje (cx, cy), en (−180, 180]; null en el mismo eje.
// (y crece hacia ABAJO, como en la pantalla y en cshClockPt: la costura «ptry» lo olvida)
function cshClockPointerDeg(cx, cy, x, y) {
   var dx = x - cx, dy = y - cy;
   if (!(isFinite(dx) && isFinite(dy)) || (dx * dx + dy * dy) < 1e-18) return null;
   return Math.atan2(dx, cshClockBroken("ptry") ? dy : -dy) * 180 / Math.PI;
}
// grados (cualquier vuelta) → el valor de la escala. Acotado al arco: en el hueco de abajo, la punta MÁS CERCANA (−170° → from, +170° → to).
// Deshace lo mismo que cshClockAngle (sentido, «asym»); NO deshace «jump» (cuantiza al pintar: la vuelta de ida y vuelta lo ve).
function cshClockValueAt(S, deg, variant) {
   var V = CSH_CLOCK.V[cshClockVar(variant)], a = Number(deg);
   if (!isFinite(a)) return null;
   a = a - 360 * Math.round(a / 360);                     // (a [−180, 180); el ±180 exacto cae en «from»: está en el hueco, a igual distancia de las dos puntas)
   if (S.cw === false || cshClockBroken("ccw")) a = -a;
   if (cshClockBroken("asym") && S.kind === "sym") a -= 9;
   var f = (a + V.span / 2) / V.span;
   if (!cshClockBroken("noclamp")) f = Math.max(0, Math.min(1, f));
   return S.from + f * (S.to - S.from);
}
// el valor de la escala → años (pasado negativo): la inversa de cshClockValue
function cshClockYearsOf(S, v) { return v * (S.yr || ((S.kind === "cosmic") ? 1e9 : 1e6)); }
// el ángulo → años, de una vez
function cshClockYearsAt(S, deg, variant) { var v = cshClockValueAt(S, deg, variant); return (v === null) ? null : cshClockYearsOf(S, v); }

// un punto a r del eje y `deg` grados desde las 12, a favor del reloj (y crece hacia abajo, como en la pantalla)
function cshClockPt(cx, cy, r, deg) { var a = deg * Math.PI / 180; return { x: cx + r * Math.sin(a), y: cy - r * Math.cos(a) }; }
function cshClockIsMult(v, step) { var q = v / step; return Math.abs(q - Math.round(q)) < 1e-6; }
function cshClockBoxHit(a, b, pad) { return !(a.x1 + pad <= b.x0 || b.x1 + pad <= a.x0 || a.y1 + pad <= b.y0 || b.y1 + pad <= a.y0); }
function cshClockFontBox(font, text) { return { w: font.width(text), a: font.ascent, d: font.descent }; }

// LA GEOMETRÍA ENTERA (relativa al eje: (0, 0); y hacia abajo). fontFn(role, px, bold, italic, spacing) → Font (o un sustituto
// con width(s), ascent, descent en node). opt = { minPx } (el cuerpo mínimo de cifras y unidad: la vista previa del diálogo pide
// 7 px lógicos, T17 X9). Devuelve L (ver abajo); L.bad lista lo que no se pudo poner (no debería haber nada).
// LA GEOMETRÍA DE UNA VARIANTE para una escala: CSH_CLOCK con los radios de V.geo encima, en un objeto NUEVO (CSH_CLOCK no se toca; rojo
// «geoglobal»: se escriben en CSH_CLOCK y se quedan, lo que hacía csh_clock_pocket.js de no haberlos devuelto en su finally)
function cshClockGeoOf(V, S) { if (!V || !V.geo) return null; return (V.numerals === "roman" && S && S.kind !== "cosmic" && V.geoArabic) ? V.geoArabic : V.geo; }
function cshClockK(V, S) {
   var G = cshClockGeoOf(V, S), K = {}, k;
   if (cshClockBroken("geoglobal") && G) { for (k in G) if (G.hasOwnProperty(k)) CSH_CLOCK[k] = G[k]; return CSH_CLOCK; }
   for (k in CSH_CLOCK) if (CSH_CLOCK.hasOwnProperty(k)) K[k] = CSH_CLOCK[k];
   if (G) for (k in G) if (G.hasOwnProperty(k)) K[k] = G[k];
   if (G === CSH_CLOCK_GEO_ROMAN && cshClockBroken("shorthand")) K.R_HAND = 0.545;
   return K;
}
// LAS CIFRAS DE UNA VARIANTE: la letra (D romanos al 0,96 del cuerpo; E cursivas; F de palo seminegras) y el texto (D: romanos en la cósmica).
// Romanos de 1 a 39 (los Ga de la cósmica son 1 … 13), sustractivos (IV, IX): más estrechos que IIII y VIIII, que no caben a 1080p.
function cshPocketRoman(n) {
   if (typeof n !== "number" || !(n >= 1 && n <= 39) || Math.abs(n - Math.round(n)) > 1e-9) return null;
   var T = cshClockBroken("roman") ? [[10, "X"], [5, "V"], [1, "I"]] : [[10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]], s = "", k = Math.round(n);
   for (var i = 0; i < T.length; ++i) while (k >= T[i][0]) { s += T[i][1]; k -= T[i][0]; }
   return s;
}
function cshClockRomanOn(V, S) { return !!(V && V.numerals === "roman" && S && S.kind === "cosmic"); }
function cshClockVarLabelText(V, S, v, lang, isEnd) {
   if (cshClockRomanOn(V, S) && !isEnd && Math.abs(v) > 1e-9) { var r = cshPocketRoman(Math.abs(v)); if (r) return r; }
   return cshClockLabelText(S, v, lang, isEnd);
}
function cshClockVarFont(V, S, fontFn, opt) {
   if (!V || !V.numerals) return fontFn;
   if (V.numerals === "italic") return function(role, px, bold, italic, sp) { return fontFn(role, px, bold, (role === "display") ? true : italic, sp); };
   if (V.numerals === "sans") return function(role, px, bold, italic, sp) { return (role === "display" && !italic) ? fontFn("text", px, true, false, 0) : fontFn(role, px, bold, italic, sp); };
   if (cshClockRomanOn(V, S)) {
      // (los romanos, al 0,96 del cuerpo de A —15 px a R 104, la letra redondea—: a cuerpo entero —16 px— «VIII», de cuatro letras, no cabe
      //  entre «VII» y «IX» y la esfera se queda con una cifra cada 2 Ga; barrido del 25-oct. Nunca por debajo del cuerpo mínimo pedido.)
      var floorPx = Math.max(CSH_CLOCK.NUM_MIN_PX, (opt && opt.minPx > 0) ? opt.minPx : 0);
      return function(role, px, bold, italic, sp) { return fontFn(role, (role === "display" && !italic) ? Math.max(floorPx, px * (cshClockBroken("romansmall") ? 0.6 : CSH_CLOCK.POCKET.ROMAN_K)) : px, bold, italic, sp); };
   }
   return fontFn;
}
function cshClockLayout(S, R, variant, fontFn, lang, opt) {
   var vk = cshClockVar(variant), V = CSH_CLOCK.V[vk], K = cshClockK(V, S), i;
   fontFn = cshClockVarFont(V, S, fontFn, opt);
   var L = { R: R, variant: vk, shape: V.shape, span: V.span, ticks: [], labels: [], ends: [], epochs: [], unit: null, sub: null, bad: [], labelStep: 0,
             handLen: (cshClockBroken("longhand") ? 0.80 : K.R_HAND) * R, tailLen: K.R_TAIL * R, lang: lang, S: S };
   // --- las marcas (del paso menor; las mayores y medias, más largas). Los extremos, siempre mayores.
   var n0 = Math.ceil(S.from / S.minor - 1e-9), n1 = Math.floor(S.to / S.minor + 1e-9);
   for (i = n0; i <= n1; ++i) {
      var v = Math.round(i * S.minor * 1e6) / 1e6, kind = cshClockIsMult(v, S.major) ? "major" : (S.half && cshClockIsMult(v, S.half) ? "half" : "minor");
      if (Math.abs(v - S.from) < 1e-9 || Math.abs(v - S.to) < 1e-9) kind = "major";
      L.ticks.push({ v: v, deg: cshClockAngle(S, v, vk), kind: kind, r0: K.R_TICK0 * R, r1: (kind === "major" ? K.R_TICK_MAJOR : (kind === "half" ? K.R_TICK_HALF : K.R_TICK_MINOR)) * R });
   }
   if (Math.abs(S.from / S.minor - Math.round(S.from / S.minor)) > 1e-6) L.ticks.push({ v: S.from, deg: cshClockAngle(S, S.from, vk), kind: "major", r0: K.R_TICK0 * R, r1: K.R_TICK_MAJOR * R });
   // --- las cifras del anillo
   var minPx = Math.max(K.NUM_MIN_PX, (opt && opt.minPx > 0) ? opt.minPx : 0), px0 = Math.max(minPx, K.NUM_PX * R), rOut = K.R_NUM_OUT * R, rIn = K.R_NUM_IN * R;
   L.capMin = (opt && opt.capMinPx > 0) ? opt.capMinPx : 0;      // (26-oct, reloj pequeño de los vídeos: el suelo de la cifra exacta SOLA, sin tocar el de las cifras ni la unidad)
   L.minPx = (opt && opt.minPx > 0) ? opt.minPx : 0;      // (26-oct: el suelo de la letra que pide quien llama —la vista previa— vale también para la cifra exacta: cshClockFootprintDisc)
   function place(v, text, px) {
      var f = fontFn("display", px, false, false, 0), b = cshClockFontBox(f, text), deg = cshClockAngle(S, v, vk), a = deg * Math.PI / 180;
      var hw = b.w / 2, hh = (b.a + b.d) / 2, ext = Math.abs(hw * Math.sin(a)) + Math.abs(hh * Math.cos(a)), rc = rOut - ext, p = cshClockPt(0, 0, rc, deg);
      return { v: v, text: text, font: f, px: px, deg: deg, x: p.x, y: p.y, w: b.w, h: 2 * hh, a: b.a, d: b.d, inner: rc - ext,
               box: { x0: p.x - hw, y0: p.y - hh, x1: p.x + hw, y1: p.y + hh } };
   }
   function fit(v, text) {
      for (var st = 0; st <= 4; ++st) { var q = place(v, text, Math.max(minPx, px0 * (1 - (1 - K.NUM_SHRINK) * st / 4))); if (q.inner >= rIn) return q; }
      return null;
   }
   // los EXTREMOS de la escala: en el hueco de abajo (A, B) o bajo la base (C)
   var endsAt = [S.from, S.to];
   for (i = 0; i < 2; ++i) {
      var it = S.ends ? S.ends[i] : null;
      if (!it) { L.ends.push(null); continue; }
      var e = { which: i, v: endsAt[i], sym: it.sym || "", text: "" };
      if (it.text) e.text = (it.text === "today") ? cshClockTx("today", lang) : cshClockVarLabelText(V, S, endsAt[i], lang, true);
      var f2 = fontFn("display", px0, false, true, 0), bw = e.text ? f2.width(e.text) : px0 * 0.9, bh = e.text ? f2.ascent + f2.descent : px0 * 0.9;
      e.font = f2; e.w = bw; e.h = bh;
      if (V.shape === "disc") {
         var dg = cshClockAngle(S, endsAt[i], vk) + ((i === 0) ? -1 : 1) * ((S.gap > 0) ? S.gap : K.GAP_DEG) * ((S.cw === false || cshClockBroken("ccw")) ? -1 : 1), ar = dg * Math.PI / 180;
         var ex = Math.abs(bw / 2 * Math.sin(ar)) + Math.abs(bh / 2 * Math.cos(ar)), pc = cshClockPt(0, 0, rOut - ex, dg);
         e.x = pc.x; e.y = pc.y; e.deg = dg;
      } else {
         var sx = (cshClockAngle(S, endsAt[i], vk) < 0) ? -1 : 1;
         e.x = sx * (K.R_TICK_MAJOR * R + K.R_NUM_OUT * R) / 2; e.y = K.LIMB_BASE * R + 0.05 * R + bh / 2; e.deg = 90 * sx;
      }
      e.box = { x0: e.x - bw / 2, y0: e.y - bh / 2, x1: e.x + bw / 2, y1: e.y + bh / 2 };
      L.ends.push(e);
   }
   var thin = !cshClockBroken("nothin"), steps = S.labelSteps || [S.major], chosen = null, chosenStep = steps[steps.length - 1], miss = [];
   for (var si = 0; si < steps.length; ++si) {
      var st = steps[si], arr = [], ok = true, k0 = Math.ceil(S.from / st - 1e-9), k1 = Math.floor(S.to / st + 1e-9);
      miss = [];
      for (var kk = k0; kk <= k1; ++kk) {
         var vv = Math.round(kk * st * 1e6) / 1e6;
         if (Math.abs(vv - S.from) < 1e-9 || Math.abs(vv - S.to) < 1e-9) continue;      // (los extremos van aparte)
         var q = thin ? fit(vv, cshClockVarLabelText(V, S, vv, lang)) : place(vv, cshClockVarLabelText(V, S, vv, lang), px0);
         if (!q) { ok = false; miss.push("no cabe " + cshClockVarLabelText(V, S, vv, lang)); continue; }
         arr.push(q);
      }
      // ¿se pisan? (entre vecinas y con los extremos)
      for (var a1 = 0; a1 < arr.length && ok; ++a1) {
         var pad = K.LABEL_PAD * arr[a1].px;
         if (a1 + 1 < arr.length && cshClockBoxHit(arr[a1].box, arr[a1 + 1].box, pad)) ok = false;
         for (var e1 = 0; e1 < L.ends.length; ++e1) if (L.ends[e1] && cshClockBoxHit(arr[a1].box, L.ends[e1].box, pad)) ok = false;
      }
      chosen = arr; chosenStep = st;
      if (ok || !thin) break;
   }
   L.labelStep = chosenStep;
   for (i = 0; i < miss.length; ++i) L.bad.push(miss[i]);
   // si ni el paso más largo cabe: fuera las que pisen a una ya puesta (en orden)
   if (thin && chosen) {
      var keep = [];
      for (i = 0; i < chosen.length; ++i) {
         var hit = false, pd = K.LABEL_PAD * chosen[i].px;
         for (var j = 0; j < keep.length; ++j) if (cshClockBoxHit(chosen[i].box, keep[j].box, pd)) hit = true;
         for (var e2 = 0; e2 < L.ends.length; ++e2) if (L.ends[e2] && cshClockBoxHit(chosen[i].box, L.ends[e2].box, pd)) hit = true;
         if (hit) L.bad.push("quitada " + chosen[i].text); else keep.push(chosen[i]);
      }
      chosen = keep;
   }
   L.labels = chosen || [];
   L.numPx = L.labels.length ? L.labels[0].px : px0;
   for (i = 1; i < L.labels.length; ++i) L.numPx = Math.min(L.numPx, L.labels[i].px);
   // --- las marcas de época (el Sol): dentro del anillo de marcas
   for (i = 0; i < (S.epochs || []).length; ++i) {
      var ep = S.epochs[i];
      if (ep.v < S.from || ep.v > S.to) continue;
      var dge = cshClockAngle(S, ep.v, vk), pe = cshClockPt(0, 0, K.R_EPOCH * R, dge);
      L.epochs.push({ v: ep.v, sym: ep.sym, deg: dge, x: pe.x, y: pe.y, r: 0.04 * R });
   }
   // --- la unidad
   // (25-oct, revisor: «GA ATRÁS» no salía en 9:16 en castellano —más ancha que «GYR AGO», pisaba «hoy»—: se prueba a 1, 0,9 y 0,8 del cuerpo antes de quitarla)
   var uFloor = Math.max(K.UNIT_MIN_PX, minPx), ut = cshClockUnitText(S, lang).toUpperCase();
   for (var ush = 0; ush < 3; ++ush) {
   var upx = Math.max(uFloor, K.UNIT_PX * R * (1 - 0.1 * ush)), uf = fontFn("text", upx, true, false, Math.round(upx * K.UNIT_TRACK));
   var uw = uf.width(ut), uh = uf.ascent + uf.descent, uy = (V.shape === "disc") ? K.UNIT_Y * R : Math.max(K.LIMB_BASE * R + 0.05 * R, (K.R_TAIL + 0.075) * R) + uh / 2;      // (C: por debajo del contrapeso, que baja hasta 0,18 R)
   if (V.shape === "disc") {
      // (si la unidad es más ancha que el hueco entre las dos puntas de la manecilla en los extremos, baja hasta librarlas: pasa a R pequeño,
      //  donde el cuerpo mínimo de la letra la hace relativamente ancha)
      // (la distancia del ASTA —del eje a la punta, no solo la punta— a la esquina de arriba de la unidad: sonda del 25-oct, a R 208 la
      //  rozaba 0,3 px)
      var tipE = cshClockPt(0, 0, L.handLen, V.span / 2), hw2 = 1.6 * Math.max(1, 0.011 * R);
      // (la distancia del asta a la CAJA: muestreando el asta cada 0,5 px —la punta puede quedar encima del centro de la caja—)
      var segD = function(yTop) {
         var tx = Math.abs(tipE.x), ty = tipE.y, n = Math.max(4, Math.ceil(L.handLen / 0.5)), best = 1e9;
         for (var q = 0; q <= n; ++q) { var x = tx * q / n, y = ty * q / n, dx = Math.max(0, x - uw / 2), dy = Math.max(0, yTop - y, y - (yTop + uh)); best = Math.min(best, Math.sqrt(dx * dx + dy * dy)); }
         return best;
      };
      for (var guard = 0; guard < 400 && segD(uy - uh / 2) < hw2 + 1.5; ++guard) uy += 0.5;
   }
   L.unit = { text: ut, font: uf, x: 0, y: uy, w: uw, h: uh, box: { x0: -uw / 2, y0: uy - uh / 2, x1: uw / 2, y1: uy + uh / 2 } };
   // (si aun así pisa uno de los extremos —solo a R muy pequeño—, fuera: la cifra exacta de debajo ya lleva la unidad)
   var uHit = false;
   for (i = 0; i < L.ends.length; ++i) if (L.ends[i] && cshClockBoxHit(L.unit.box, L.ends[i].box, 1)) uHit = true;
   if (!uHit) break;
   if (ush === 2) { L.unit = null; L.bad.push("sin unidad (no cabe)"); }
   }
   // --- la esfera pequeña de la aguja fina (B)
   if (V.sub && !V.pocket) L.sub = { x: 0, y: K.SUB.y * R, r: K.SUB.r * R };
   // --- el contorno de la cara (relativo al eje)
   if (V.shape === "disc") L.face = { x0: -R, y0: -R, x1: R, y1: R };
   else {
      var yb = K.LIMB_BASE * R, low = yb + 0.05 * R + Math.max(uh, L.ends[0] ? L.ends[0].h : 0, L.ends[1] ? L.ends[1].h : 0) + 0.05 * R;
      L.face = { x0: -R, y0: -R, x1: R, y1: low, base: yb };
   }
   if (V.pocket) cshClockPocketLayout(L, V, K, R);
   return L;
}
// LO DE BOLSILLO encima de la geometría (D, E, F): el cuerpo real de las cifras, la manecilla del estilo, cuello, corona, anilla, cadena (E) y la
// subesfera de F. L.pocket = la variante; L.geo = los radios con los que se hizo (los usa el dibujo).
function cshClockPocketLayout(L, V, K, R) {
   var P = CSH_CLOCK.POCKET, gk, li;
   L.pocket = L.variant;
   // el cuerpo de las cifras: el de la LETRA que se usa (con los cambios de cada estilo y el redondeo de la letra), no el pedido
   for (li = 0; li < L.labels.length; ++li) { var fpx = L.labels[li].font && L.labels[li].font.pixelSize; if (fpx > 0) L.labels[li].px = fpx; }
   if (L.labels.length) { L.numPx = L.labels[0].px; for (li = 1; li < L.labels.length; ++li) L.numPx = Math.min(L.numPx, L.labels[li].px); }
   L.geo = {}; for (gk in K) if (K.hasOwnProperty(gk) && typeof K[gk] === "number") L.geo[gk] = K[gk];
   L.hand = cshClockPocketHand(V.hand, R, L);
   // lo de arriba: cuello, corona y anilla (y la cadena en E): la cota más alta (negativa) para la caja
   var B = V.bow, top = -(B.cy + B.ry) * R, lw = Math.max(1, 0.011 * R);
   L.crown = { w: V.crown.w * R, y0: -P.NECK.y1 * R, y1: -(P.NECK.y1 + V.crown.h) * R };
   L.bow = B;
   if (V.chain) { L.chain = cshPocketChain(B, R); for (var c = 0; c < L.chain.length; ++c) top = Math.min(top, L.chain[c].y - 0.04 * R); }
   L.top = top - 1.5 * lw;
   // la subesfera de F: a las 6, entre el eje y la unidad, sin que la toque la manecilla en ningún punto del recorrido
   L.sub = null;
   if (V.sub) {
      var sb = { x: 0, y: P.SUB.y * R, r: (cshClockBroken("subbig") ? 0.20 : P.SUB.r) * R }, uTop = L.unit ? L.unit.box.y0 : 1e9, ok = false;
      for (var tries = 0; tries < 12; ++tries) {
         var clear = 1e9;
         for (var dg = -L.span / 2; dg <= -L.span / 2 + 40; dg += 2) { clear = Math.min(clear, cshPocketHandCircleDist(cshPocketHandAt(L.hand, 0, 0, dg), sb.x, sb.y, sb.r), cshPocketHandCircleDist(cshPocketHandAt(L.hand, 0, 0, -dg), sb.x, sb.y, sb.r)); }
         var below = uTop - (sb.y + sb.r);
         if ((clear > P.HALO * lw + 1 && below > 1.5) || cshClockBroken("subbig")) { ok = true; break; }
         sb.r -= 0.005 * R; if (below <= 1.5) sb.y -= 0.004 * R;
         if (sb.r < P.SUB.rMin * R) break;
      }
      if (ok) L.sub = sb; else L.bad.push("sin subesfera (no cabe)");
   }
   return L;
}

// LA CAJA que ocupa el reloj con su cifra exacta debajo: { w, h, ox, oy (el eje dentro de la caja), cap: { font, px, gap, h } }
// (las de bolsillo: + lo que asoma por arriba —anilla, cadena— y, en E, la tapa abajo en lugar de la pastilla: cshClockPocketFootprint)
function cshClockFootprint(L, caption, fontFn) { return (L && L.pocket) ? cshClockPocketFootprint(L, caption, fontFn) : cshClockFootprintDisc(L, caption, fontFn); }
// (26-oct, cc_pi_test T17 X9 en rojo con D: en la vista previa de II el reloj de bolsillo, más alto por la corona y la anilla, baja a R 60 para
//  caber y la cifra exacta caía al suelo de 10 px = 6,7 px lógicos < 7. Ahora la cifra respeta también el suelo de quien llama, L.minPx.
//  Rojo: CSH_CLOCK_BREAK «capsmall». Y opt.capMinPx (26-oct): el suelo de la cifra exacta sola, para los vídeos con el reloj pequeño: a R 70 la
//  cifra salía a 10,5 px.)
function cshClockFootprintDisc(L, caption, fontFn) {
   var K = CSH_CLOCK, R = L.R, px = Math.max(K.CAP_MIN_PX, cshClockBroken("capsmall") ? 0 : (L.minPx || 0), L.capMin || 0, K.CAP_PX * R), f = fontFn("display", px, false, true, 0), capH = f.ascent + f.descent;
   var gap = Math.round(0.07 * R), padC = Math.round(0.06 * R), F = L.face;
   var capW = caption ? f.width(caption) : 0;
   if (L.shape === "disc") {
      var hh = (F.y1 - F.y0) + (caption ? gap + capH + 2 * padC : 0);
      return { w: Math.ceil(F.x1 - F.x0), h: Math.ceil(hh), ox: -F.x0, oy: -F.y0, cap: { font: f, px: px, gap: gap, h: capH, w: capW, pad: padC } };
   }
   var pad = Math.round(0.06 * R);
   return { w: Math.ceil(F.x1 - F.x0 + 2 * pad), h: Math.ceil((F.y1 - F.y0) + 2 * pad + (caption ? capH + padC : 0)), ox: -F.x0 + pad, oy: -F.y0 + pad,
            cap: { font: f, px: px, gap: padC, h: capH, w: capW, pad: pad } };
}

// ---------------------------------------------------------------------------
// EL DIBUJO
// ---------------------------------------------------------------------------
function cshClockInt(hex, alpha) {
   if (typeof cpInt === "function") return cpInt(hex, alpha);
   var h = String(hex).replace("#", ""), a = (alpha === undefined) ? 255 : Math.round(Math.max(0, Math.min(1, alpha)) * 255);
   return ((a << 24) | (parseInt(h.substring(0, 2), 16) << 16) | (parseInt(h.substring(2, 4), 16) << 8) | parseInt(h.substring(4, 6), 16)) >>> 0;
}
function cshClockNoBrush(g) { g.brush = new Brush(0x00000000, (typeof BrushStyle_Empty !== "undefined") ? BrushStyle_Empty : 0); }
function cshClockArc(g, cx, cy, r, d0, d1, pen) {
   var n = Math.max(8, Math.ceil(Math.abs(d1 - d0) / 3)), pts = [];
   for (var i = 0; i <= n; ++i) { var p = cshClockPt(cx, cy, r, d0 + (d1 - d0) * i / n); pts.push(new Point(p.x, p.y)); }
   g.pen = pen; cshClockNoBrush(g); g.drawPolyline(pts);
}
function cshClockText(o, g, font, color, x, y, s) {
   if (o && typeof o.textFn === "function") { o.textFn(g, font, color, x, y, s); return; }
   g.font = font; g.pen = new Pen(color, 1); g.drawText(x, y, s);
}
// el Big Bang: una estrella de ocho rayos (cuatro largas, cuatro cortas)
function cshClockStar(g, x, y, r, c, w) {
   g.pen = new Pen(c, w);
   for (var i = 0; i < 8; ++i) { var rr = (i % 2) ? r * 0.55 : r, p = cshClockPt(x, y, rr, i * 45), q = cshClockPt(x, y, rr * 0.18, i * 45); g.drawLine(q.x, q.y, p.x, p.y); }
   g.fillCircle(x, y, Math.max(1, r * 0.16), new Brush(c));
}
// el Sol: ☉ (círculo con punto), dibujado: no depende de que la letra tenga el glifo
function cshClockSun(g, x, y, r, c, w) { g.strokeCircle(x, y, r, new Pen(c, w)); g.fillCircle(x, y, Math.max(1, r * 0.28), new Brush(c)); }

// La manecilla principal. «lance»: asta fina, rombo cerca de la punta, contrapeso abierto. «needle»: aguja con luna de Breguet.
function cshClockHand(g, cx, cy, L, deg, style, A, lw) {
   var R = L.R, tip = cshClockPt(cx, cy, L.handLen, deg), tail = cshClockPt(cx, cy, -L.tailLen, deg), gold = cshClockInt(A.goldLight), dark = cshClockInt(A.bg);
   // un trazo oscuro debajo: la manecilla se lee también sobre una cifra o una marca
   g.pen = new Pen(cshClockInt(A.bg, 0.85), lw * 3.2); g.drawLine(tail.x, tail.y, tip.x, tip.y);
   g.pen = new Pen(gold, lw * 1.25); g.drawLine(tail.x, tail.y, tip.x, tip.y);
   if (style === "needle") {
      var mo = cshClockPt(cx, cy, 0.47 * R, deg);
      g.fillCircle(mo.x, mo.y, 0.052 * R, new Brush(dark)); g.strokeCircle(mo.x, mo.y, 0.052 * R, new Pen(gold, lw * 1.25));
      var b1 = cshClockPt(cx, cy, L.handLen - 0.07 * R, deg - 2.6), b2 = cshClockPt(cx, cy, L.handLen - 0.07 * R, deg + 2.6);
      g.brush = new Brush(gold); g.pen = new Pen(gold, 1); g.fillPolygon([new Point(tip.x, tip.y), new Point(b1.x, b1.y), new Point(b2.x, b2.y)]); cshClockNoBrush(g);
      g.strokeCircle(tail.x, tail.y, 0.032 * R, new Pen(gold, lw));
   } else {
      // el rombo, cerca de la punta (de 0,42 R a 0,58 R): el ojo sigue la punta, no el rombo (revisor, 24-oct: a 9,3 Ga «parecía el 10»)
      var c0 = 0.42 * R, c1 = 0.58 * R, cm = 0.49 * R, hw = 0.042 * R, a = deg * Math.PI / 180, ux = Math.sin(a), uy = -Math.cos(a), nx = -uy, ny = ux;
      var P0 = new Point(cx + ux * c0, cy + uy * c0), P1 = new Point(cx + ux * cm + nx * hw, cy + uy * cm + ny * hw), P2 = new Point(cx + ux * c1, cy + uy * c1), P3 = new Point(cx + ux * cm - nx * hw, cy + uy * cm - ny * hw);
      g.brush = new Brush(gold); g.pen = new Pen(gold, 1); g.fillPolygon([P0, P1, P2, P3]); cshClockNoBrush(g);
      g.fillCircle(tail.x, tail.y, 0.034 * R, new Brush(dark)); g.strokeCircle(tail.x, tail.y, 0.034 * R, new Pen(gold, lw));
   }
   // el eje
   g.fillCircle(cx, cy, 0.05 * R, new Brush(cshClockInt(A.gold)));
   g.fillCircle(cx, cy, 0.019 * R, new Brush(dark));
   return tip;
}

// R2 (26-oct): la cifra exacta NO se pinta si dice lo mismo que la esfera («hoy» / «today»: la de la escala ya está y la manecilla la señala).
// Devuelve el texto que se pinta ("" = nada); la caja se mide igual con la cifra pedida. Rojo «today2»: se pinta otra vez.
function cshClockCaptionShown(cap) {
   var c = cap ? String(cap) : "", n = c.replace(/^\s+|\s+$/g, "").toLowerCase();
   if (!cshClockBroken("today2") && (n === cshClockTx("today", "es").toLowerCase() || n === cshClockTx("today", "en").toLowerCase())) return "";
   return c;
}
function cshClockPaint(g, x0, y0, R, S, v, o) {
   var t0 = Date.now(), O = o || {}, A = (typeof CSH_ATLAS !== "undefined") ? CSH_ATLAS : { bg: "#110D09", surface: "#1B140E", line: "#3D2E1F", text: "#FBF2E0", text2: "#D0C1A5", text3: "#A3957B", gold: "#E5B53F", goldLight: "#F3D27E" };
   var lang = (O.lang === "es") ? "es" : "en", fontFn = O.fontFn || ((typeof cpFont === "function") ? cpFont : null), K = CSH_CLOCK, i;
   var L = O.layout || cshClockLayout(S, R, O.variant, fontFn, lang);
   if (L.pocket) { if (!O.layout) { var O2 = {}; for (var ok in O) if (O.hasOwnProperty(ok)) O2[ok] = O[ok]; O2.layout = L; O = O2; } return cshClockPocketPaint(g, x0, y0, R, S, v, O); }
   var FP = cshClockFootprint(L, O.caption || "", fontFn);
   var cx = x0 + FP.ox, cy = y0 + FP.oy, lw = Math.max(1, 0.011 * R), V = CSH_CLOCK.V[L.variant];
   var alpha = (O.alpha > 0) ? Math.min(1, O.alpha) : 1;
   var out = { labels: [], ends: [], deg: 0, fineDeg: null, numPx: L.numPx, labelStep: L.labelStep, bad: L.bad.slice(), variant: L.variant, R: R };
   g.antialiasing = true;
   try { g.textAntialiasing = true; } catch (eT) {}
   g.opacity = alpha;
   // --- 1 · la cara, opaca (las estrellas de debajo no asoman) y el bisel de doble filete
   var face = cshClockInt(A.bg), rimA = cshClockInt(A.goldLight, 0.75), rimB = cshClockInt(A.gold, 0.45);
   if (L.shape === "disc") {
      g.fillCircle(cx, cy, R, new Brush(face));
      g.strokeCircle(cx, cy, R - lw / 2, new Pen(rimA, lw));
      g.strokeCircle(cx, cy, K.R_BEZEL2 * R, new Pen(rimB, lw * 0.85));
   } else {
      var F = L.face, pad = FP.cap.pad, bx0 = x0, by0 = y0, bx1 = x0 + FP.w, by1 = y0 + FP.h;
      g.fillRoundedRect(bx0, by0, bx1, by1, 6, 10, new Brush(face));
      cshClockNoBrush(g); g.pen = new Pen(cshClockInt(A.line), 1); g.drawRoundedRect(bx0, by0, bx1, by1, 6, 10);
      // el limbo: el arco y la base (dos filetes)
      cshClockArc(g, cx, cy, R - lw / 2, -90, 90, new Pen(rimA, lw));
      cshClockArc(g, cx, cy, K.R_BEZEL2 * R, -90, 90, new Pen(rimB, lw * 0.85));
      g.pen = new Pen(rimA, lw); g.drawLine(cx - R, cy, cx - R, cy + F.base); g.drawLine(cx + R, cy, cx + R, cy + F.base); g.drawLine(cx - R, cy + F.base, cx + R, cy + F.base);
      g.pen = new Pen(rimB, lw * 0.85); g.drawLine(cx - K.R_BEZEL2 * R, cy, cx - K.R_BEZEL2 * R, cy + F.base - (1 - K.R_BEZEL2) * R); g.drawLine(cx + K.R_BEZEL2 * R, cy, cx + K.R_BEZEL2 * R, cy + F.base - (1 - K.R_BEZEL2) * R);
      g.drawLine(cx - K.R_BEZEL2 * R, cy + F.base - (1 - K.R_BEZEL2) * R, cx + K.R_BEZEL2 * R, cy + F.base - (1 - K.R_BEZEL2) * R);
   }
   // un círculo interior muy tenue (el marco interior de la guía: innerFrameAlpha)
   var innerA = (A.ornament && A.ornament.innerFrameAlpha) ? A.ornament.innerFrameAlpha : 0.16;
   if (L.shape === "disc") g.strokeCircle(cx, cy, K.R_INNER * R, new Pen(cshClockInt(A.gold, innerA), lw * 0.8));
   else cshClockArc(g, cx, cy, K.R_INNER * R, -90, 90, new Pen(cshClockInt(A.gold, innerA), lw * 0.8));
   // --- 1b · la cifra exacta, pequeña, debajo (se pinta antes que la esfera: así es el primer texto del reloj para quien los apunta)
   var cap = cshClockCaptionShown(O.caption);
   if (cap) {
      var C = FP.cap, cf = C.font, cw = cf.width(cap), cyb;
      if (L.shape === "disc") {
         var py0 = cy + R + C.gap, py1 = py0 + C.h + 2 * C.pad, pw = cw + 2.4 * C.pad + C.px;
         g.fillRoundedRect(cx - pw / 2, py0, cx + pw / 2, py1, 20, 50, new Brush(face));
         cshClockNoBrush(g); g.pen = new Pen(cshClockInt(A.line), 1); g.drawRoundedRect(cx - pw / 2, py0, cx + pw / 2, py1, 20, 50);
         cyb = py0 + C.pad + cf.ascent;
         out.capBox = { x0: cx - pw / 2, y0: py0, x1: cx + pw / 2, y1: py1 };
      } else {
         cyb = y0 + FP.h - C.pad - cf.descent;
         out.capBox = { x0: cx - cw / 2, y0: cyb - cf.ascent, x1: cx + cw / 2, y1: cyb + cf.descent };
      }
      cshClockText(O, g, cf, cshClockInt(A.text), cx - cw / 2, cyb, cap);
      out.caption = cap; out.capPx = C.px;
   }
   // --- 2 · el anillo de marcas
   var a0 = -L.span / 2, a1 = L.span / 2;
   cshClockArc(g, cx, cy, K.R_TICK0 * R, a0, a1, new Pen(cshClockInt(A.gold, 0.55), lw * 0.85));
   for (i = 0; i < L.ticks.length; ++i) {
      var tk = L.ticks[i], p0 = cshClockPt(cx, cy, tk.r0, tk.deg), p1 = cshClockPt(cx, cy, tk.r1, tk.deg);
      var isToday = Math.abs(tk.v) < 1e-9;
      g.pen = new Pen(isToday ? cshClockInt(A.gold) : cshClockInt(A.goldLight, tk.kind === "major" ? 0.9 : (tk.kind === "half" ? 0.7 : 0.5)), lw * (tk.kind === "major" ? 1.3 : 0.85));
      g.drawLine(p0.x, p0.y, p1.x, p1.y);
   }
   // --- 3 · las cifras (crema; «hoy» en oro)
   var numC = cshClockInt(A.text, 0.92), todayC = cshClockInt(A.gold);
   for (i = 0; i < L.labels.length; ++i) {
      var lb = L.labels[i], tx = cx + lb.x - lb.w / 2, ty = cy + lb.y - lb.h / 2 + lb.a;
      cshClockText(O, g, lb.font, (Math.abs(lb.v) < 1e-9) ? todayC : numC, tx, ty, lb.text);
      out.labels.push({ text: lb.text, x0: cx + lb.box.x0, y0: cy + lb.box.y0, x1: cx + lb.box.x1, y1: cy + lb.box.y1, px: lb.px });
   }
   for (i = 0; i < L.ends.length; ++i) {
      var e = L.ends[i];
      if (!e) continue;
      if (e.sym === "bigbang") cshClockStar(g, cx + e.x, cy + e.y, e.h * 0.55, cshClockInt(A.goldLight), lw);
      else if (e.text) cshClockText(O, g, e.font, (Math.abs(e.v) < 1e-9) ? todayC : numC, cx + e.x - e.w / 2, cy + e.y - e.h / 2 + e.font.ascent, e.text);
      out.ends.push({ text: e.text || e.sym, x0: cx + e.box.x0, y0: cy + e.box.y0, x1: cx + e.box.x1, y1: cy + e.box.y1 });
   }
   // --- 4 · las épocas (el Sol) y la unidad
   for (i = 0; i < L.epochs.length; ++i) { var ep = L.epochs[i]; if (ep.sym === "sun") cshClockSun(g, cx + ep.x, cy + ep.y, ep.r, cshClockInt(A.gold), lw); }
   var U = L.unit;
   if (U) {
      cshClockText(O, g, U.font, cshClockInt(A.text3), cx + U.x - U.w / 2, cy + U.y - U.h / 2 + U.font.ascent, U.text);
      out.unit = { text: U.text, x0: cx + U.box.x0, y0: cy + U.box.y0, x1: cx + U.box.x1, y1: cy + U.box.y1 };
   } else out.unit = null;
   // --- 5 · la esfera pequeña y su aguja fina (B)
   if (L.sub) {
      var sb = L.sub, scx = cx + sb.x, scy = cy + sb.y;
      g.strokeCircle(scx, scy, sb.r, new Pen(cshClockInt(A.gold, 0.55), lw * 0.85));
      for (i = 0; i < 10; ++i) { var q0 = cshClockPt(scx, scy, sb.r * (i === 0 ? 0.62 : 0.78), i * 36), q1 = cshClockPt(scx, scy, sb.r * 0.95, i * 36); g.pen = new Pen(cshClockInt(i === 0 ? A.gold : A.goldLight, i === 0 ? 1 : 0.6), lw * (i === 0 ? 1.2 : 0.8)); g.drawLine(q0.x, q0.y, q1.x, q1.y); }
      var fd = cshClockFineAngle(S, v), ft = cshClockPt(scx, scy, sb.r * 0.86, fd), fb = cshClockPt(scx, scy, -sb.r * 0.22, fd);
      g.pen = new Pen(cshClockInt(A.text2), Math.max(1, lw * 0.9)); g.drawLine(fb.x, fb.y, ft.x, ft.y);
      g.fillCircle(scx, scy, Math.max(1.2, 0.022 * R), new Brush(cshClockInt(A.text2)));
      out.fineDeg = fd;
   }
   // --- 6 · la manecilla
   var deg = cshClockAngle(S, v, L.variant);
   out.deg = deg;
   out.tip = cshClockHand(g, cx, cy, L, deg, V.hand, A, lw);
   g.opacity = 1;
   out.box = { x0: x0, y0: y0, x1: x0 + FP.w, y1: y0 + FP.h };
   out.pivot = { x: cx, y: cy };
   out.ms = Date.now() - t0;
   return out;
}

// ---------------------------------------------------------------------------
// LAS DE BOLSILLO (D, E, F): la manecilla de cada estilo, la caja y el dibujo (25-oct en csh_clock_pocket.js; aquí desde el 26-oct)
// ---------------------------------------------------------------------------
// LA MANECILLA de cada estilo: polígonos y círculos en coordenadas de la manecilla (s = a lo largo, de la cola a la punta; w = de lado),
// en PÍXELES. fill: "gold" (el cuerpo) | "face" (un calado: el color de la esfera). La punta, siempre a L.handLen (la de A: no llega a las cifras).
function cshClockPocketHand(style, R, L) {
   var T = cshClockBroken("longhand") ? 0.80 * R : L.handLen, tl = L.tailLen, P = [], C = [], k;
   function poly(pts, fill) { var q = []; for (k = 0; k < pts.length; ++k) q.push({ s: pts[k][0] * R, w: pts[k][1] * R }); P.push({ pts: q, fill: fill }); }
   function sym(side, fill) {      // un polígono simétrico: los puntos de un lado (s, w>0) de la base a la punta, y vuelta por el otro
      var pts = [], i; for (i = 0; i < side.length; ++i) pts.push(side[i]); for (i = side.length - 1; i >= 0; --i) if (side[i][1] !== 0) pts.push([side[i][0], -side[i][1]]);
      poly(pts, fill);
   }
   var t = T / R, tq = tl / R, ks = (L.handLen / R) / CSH_CLOCK.POCKET.HAND_REF;
   var _poly = poly; poly = function(pts, fill) { var q = []; for (var m = 0; m < pts.length; ++m) q.push([pts[m][0] > 0 && pts[m][0] !== t ? pts[m][0] * ks : pts[m][0], pts[m][1]]); _poly(q, fill); };
   if (style === "pomme") {
      sym([[-tq, 0.007], [0, 0.016], [0.405, 0.008], [0.405, 0]], "gold");                                   // el asta, afinándose
      C.push({ s: 0.455 * ks * R, r: 0.052 * R, fill: "gold" }); C.push({ s: 0.455 * ks * R, r: 0.029 * R, fill: "face" });   // la «pomme»: anillo hueco
      sym([[0.50, 0.010], [t, 0]], "gold");                                                                  // la aguja hasta la punta
      C.push({ s: -tl, r: 0.030 * R, fill: "gold" }); C.push({ s: -tl, r: 0.016 * R, fill: "face" });      // el contrapeso, anillo
   } else if (style === "spade") {
      sym([[-tq, 0.008], [0, 0.015], [0.36, 0.009], [0.375, 0.034], [0.40, 0.051], [0.43, 0.050], [0.465, 0.034], [0.505, 0.016], [0.548, 0]], "gold");
      sym([[0.385, 0], [0.40, 0.024], [0.425, 0.026], [0.455, 0.016], [0.49, 0]], "face");                  // la pica calada
      sym([[0.53, 0.006], [t, 0]], "gold");
      C.push({ s: -tl, r: 0.032 * R, fill: "gold" }); C.push({ s: -tl, r: 0.014 * R, fill: "face" });
   } else {      // "cathedral"
      sym([[-tq, 0.010], [0.04, 0.024], [0.20, 0.043], [0.34, 0.033], [0.46, 0.013], [0.52, 0.007], [t, 0]], "gold");
      sym([[0.07, 0], [0.13, 0.013], [0.19, 0]], "face");                                                     // el rombo calado
      sym([[0.215, 0], [0.24, 0.024], [0.30, 0.021], [0.42, 0]], "face");                                   // el arco apuntado (gótico)
      C.push({ s: -tl, r: 0.030 * R, fill: "gold" });
   }
   return { polys: P, circles: C, tip: T, tail: tl };
}
// la manecilla a `deg` grados (desde las 12, a favor del reloj) con el eje en (cx, cy): polígonos en píxeles de pantalla
function cshPocketHandAt(H, cx, cy, deg) {
   var a = deg * Math.PI / 180, ux = Math.sin(a), uy = -Math.cos(a), nx = -uy, ny = ux, i, j, out = { polys: [], circles: [] };
   for (i = 0; i < H.polys.length; ++i) {
      var q = [], p = H.polys[i].pts;
      for (j = 0; j < p.length; ++j) q.push({ x: cx + ux * p[j].s + nx * p[j].w, y: cy + uy * p[j].s + ny * p[j].w });
      out.polys.push({ pts: q, fill: H.polys[i].fill });
   }
   for (i = 0; i < H.circles.length; ++i) { var c = H.circles[i]; out.circles.push({ x: cx + ux * c.s, y: cy + uy * c.s, r: c.r, fill: c.fill }); }
   return out;
}
// la distancia de una caja {x0,y0,x1,y1} a la manecilla puesta (lo que pinta en oro; los calados no cuentan): 0 si se tocan
function cshPocketHandBoxDist(HA, b) {
   function pd(x, y) { var dx = Math.max(b.x0 - x, 0, x - b.x1), dy = Math.max(b.y0 - y, 0, y - b.y1); return Math.sqrt(dx * dx + dy * dy); }
   var best = 1e9, i, j;
   for (i = 0; i < HA.polys.length; ++i) {
      if (HA.polys[i].fill !== "gold") continue;
      var p = HA.polys[i].pts;
      for (j = 0; j < p.length; ++j) {
         var A = p[j], B = p[(j + 1) % p.length], n = Math.max(2, Math.ceil(Math.sqrt((B.x - A.x) * (B.x - A.x) + (B.y - A.y) * (B.y - A.y)) / 0.5));
         for (var k = 0; k <= n; ++k) best = Math.min(best, pd(A.x + (B.x - A.x) * k / n, A.y + (B.y - A.y) * k / n));
      }
   }
   for (i = 0; i < HA.circles.length; ++i) { var c = HA.circles[i]; if (c.fill === "gold") best = Math.min(best, Math.max(0, pd(c.x, c.y) - c.r)); }
   return best;
}
// la distancia de un círculo (subesfera) a la manecilla puesta
function cshPocketHandCircleDist(HA, cx, cy, r) {
   var best = 1e9, i, j;
   for (i = 0; i < HA.polys.length; ++i) {
      if (HA.polys[i].fill !== "gold") continue;
      var p = HA.polys[i].pts;
      for (j = 0; j < p.length; ++j) {
         var A = p[j], B = p[(j + 1) % p.length], dx = B.x - A.x, dy = B.y - A.y, l2 = dx * dx + dy * dy, u = l2 > 0 ? Math.max(0, Math.min(1, ((cx - A.x) * dx + (cy - A.y) * dy) / l2)) : 0;
         var ex = A.x + u * dx - cx, ey = A.y + u * dy - cy; best = Math.min(best, Math.sqrt(ex * ex + ey * ey) - r);
      }
   }
   for (i = 0; i < HA.circles.length; ++i) { var c = HA.circles[i]; if (c.fill === "gold") best = Math.min(best, Math.sqrt((c.x - cx) * (c.x - cx) + (c.y - cy) * (c.y - cy)) - c.r - r); }
   return best;
}
// el punto de la anilla (bow) a `deg` grados (0 = arriba), relativo al eje
function cshPocketBowPt(B, R, deg) { var a = deg * Math.PI / 180; return { x: B.rx * R * Math.sin(a), y: -B.cy * R - B.ry * R * Math.cos(a) }; }
// la cadena (E): los centros y la dirección de cada eslabón, de la anilla hacia la derecha, colgando
function cshPocketChain(B, R) {
   var p0 = cshPocketBowPt(B, R, 38), p2 = { x: 0.90 * R, y: -1.10 * R }, p1 = { x: 0.52 * R, y: -1.02 * R }, n = 10, out = [];
   for (var i = 0; i <= n; ++i) {
      var u = i / n, x = (1 - u) * (1 - u) * p0.x + 2 * u * (1 - u) * p1.x + u * u * p2.x, y = (1 - u) * (1 - u) * p0.y + 2 * u * (1 - u) * p1.y + u * u * p2.y;
      var tx = 2 * (1 - u) * (p1.x - p0.x) + 2 * u * (p2.x - p1.x), ty = 2 * (1 - u) * (p1.y - p0.y) + 2 * u * (p2.y - p1.y), tn = Math.sqrt(tx * tx + ty * ty) || 1;
      out.push({ x: x, y: y, tx: tx / tn, ty: ty / tn, flat: (i % 2) === 0 });
   }
   return out;
}

// LA CAJA: la de A (cshClockFootprint) más lo que asoma por arriba (anilla, cadena) y, en E, la tapa abajo en lugar de la pastilla
function cshClockPocketFootprint(L, caption, fontFn) {
   var R = L.R, PV = CSH_CLOCK.V[L.pocket], FP = cshClockFootprintDisc(L, caption, fontFn), lw = Math.max(1, 0.011 * R);
   var up = cshClockBroken("crownout") ? 0 : Math.max(0, -L.top - R);
   FP.top = up; FP.oy += up; FP.h += up;
   if (PV.lid) {
      // la tapa: elipse de rx × ry bajo la bisagra; ry lo justo para la cifra exacta grabada dentro (con un margen de grabado)
      var C = FP.cap, LD = CSH_CLOCK.POCKET.LID, rx = LD.rx * R, cf = C.font, cw = caption ? cf.width(String(caption)) : 0, ch = cf.ascent + cf.descent;
      // la cifra cabe en el grabado (la elipse al 0,80) si (w/2 / 0,8 rx)² + (h/2 / 0,8 ry)² ≤ 1: si es muy ancha se achica la letra (no
      // por debajo del mínimo); luego ry lo justo (con 2 px de aire), nunca menos de ryMin
      var gx = 0.8 * rx * 0.92;
      if (cw / 2 + 2 > gx && caption) {
         var px2 = Math.max(CSH_CLOCK.CAP_MIN_PX, C.px * gx / (cw / 2 + 2));
         cf = fontFn("display", px2, false, true, 0); C.font = cf; C.px = px2; cw = cf.width(String(caption)); ch = cf.ascent + cf.descent; C.h = ch; C.w = cw;
      }
      var ux = Math.min(0.97, (cw / 2 + 2) / (0.8 * rx)), need = (ch / 2 + 2) / (0.8 * Math.sqrt(1 - ux * ux));
      var ry = cshClockBroken("lidsmall") ? 0.10 * R : Math.min(0.5 * R, Math.max(LD.ryMin * R, need));
      var hinge = LD.gap * R, cy = R + hinge + ry;
      FP.lid = { cx: 0, cy: cy, rx: rx, ry: ry, hinge: hinge, capW: cw, capH: ch };
      FP.h = Math.ceil(FP.oy + cy + ry + 1.5 * lw);
   }
   return FP;
}

// ---------------------------------------------------------------------------
// EL DIBUJO
// ---------------------------------------------------------------------------
function cshPocketPolyline(g, pts, pen, close) {
   var q = []; for (var i = 0; i < pts.length; ++i) q.push(new Point(pts[i].x, pts[i].y));
   if (close && pts.length) q.push(new Point(pts[0].x, pts[0].y));
   g.pen = pen; cshClockNoBrush(g); g.drawPolyline(q);
}
function cshPocketFillPoly(g, pts, color) {
   var q = []; for (var i = 0; i < pts.length; ++i) q.push(new Point(pts[i].x, pts[i].y));
   g.brush = new Brush(color); g.pen = new Pen(color, 0.6); g.fillPolygon(q); cshClockNoBrush(g);
}
function cshPocketEllipsePts(cx, cy, rx, ry, n, d0, d1) {
   var pts = [], a0 = (d0 === undefined) ? 0 : d0, a1 = (d1 === undefined) ? 360 : d1;
   for (var i = 0; i <= n; ++i) { var a = (a0 + (a1 - a0) * i / n) * Math.PI / 180; pts.push({ x: cx + rx * Math.sin(a), y: cy - ry * Math.cos(a) }); }
   return pts;
}
// la manecilla: un halo oscuro (se lee sobre marcas y guilloché), el cuerpo en oro claro, los calados del color de la esfera
function cshPocketPaintHand(g, HA, A, faceInt, lw) {
   var gold = cshClockInt(A.goldLight), halo = new Pen(cshClockInt(A.bg, 0.85), 2 * CSH_CLOCK.POCKET.HALO * lw), i;
   for (i = 0; i < HA.polys.length; ++i) if (HA.polys[i].fill === "gold") cshPocketPolyline(g, HA.polys[i].pts, halo, true);
   for (i = 0; i < HA.circles.length; ++i) if (HA.circles[i].fill === "gold") g.strokeCircle(HA.circles[i].x, HA.circles[i].y, HA.circles[i].r, halo);
   for (i = 0; i < HA.polys.length; ++i) cshPocketFillPoly(g, HA.polys[i].pts, HA.polys[i].fill === "gold" ? gold : faceInt);
   for (i = 0; i < HA.circles.length; ++i) g.fillCircle(HA.circles[i].x, HA.circles[i].y, HA.circles[i].r, new Brush(HA.circles[i].fill === "gold" ? gold : faceInt));
}
// la cifra exacta en una pastilla (D: doble filete; F: placa rectangular de doble filete)
// la opacidad del FONDO (esfera y pastilla): O.faceAlpha en (0, 1); fuera de eso, opaco
function cshClockFaceA(O) { return (O && O.faceAlpha > 0 && O.faceAlpha < 1 && !cshClockBroken("opaque")) ? O.faceAlpha : 1; }
function cshPocketCaptionPlate(g, O, A, FP, cx, cy, R, cap, square) {
   var C = FP.cap, cf = C.font, cw = cf.width(cap), py0 = cy + R + C.gap, py1 = py0 + C.h + 2 * C.pad, pw = cw + 2.4 * C.pad + C.px, face = cshClockInt(A.bg, cshClockFaceA(O));
   var rr = square ? 3 : 50, r2 = square ? 2 : 50;
   g.fillRoundedRect(cx - pw / 2, py0, cx + pw / 2, py1, square ? 3 : 20, rr, new Brush(face));
   cshClockNoBrush(g); g.pen = new Pen(cshClockInt(A.gold, 0.55), 1); g.drawRoundedRect(cx - pw / 2, py0, cx + pw / 2, py1, square ? 3 : 20, rr);
   g.pen = new Pen(cshClockInt(A.line), 1); g.drawRoundedRect(cx - pw / 2 + 3, py0 + 3, cx + pw / 2 - 3, py1 - 3, square ? 2 : 20, r2);
   cshClockText(O, g, cf, cshClockInt(A.text), cx - cw / 2, py0 + C.pad + cf.ascent, cap);
   return { x0: cx - pw / 2, y0: py0, x1: cx + pw / 2, y1: py1 };
}

function cshClockPocketPaint(g, x0, y0, R, S, v, o) {
   var t0 = Date.now(), O = o || {}, A = (typeof CSH_ATLAS !== "undefined") ? CSH_ATLAS : { bg: "#110D09", surface: "#1B140E", surface2: "#281D14", line: "#3D2E1F", text: "#FBF2E0", text2: "#D0C1A5", text3: "#A3957B", gold: "#E5B53F", goldLight: "#F3D27E" };
   var lang = (O.lang === "es") ? "es" : "en", fontFn = O.fontFn || ((typeof cpFont === "function") ? cpFont : null), K = CSH_CLOCK, i;
   var vk = (O.layout && O.layout.pocket) ? O.layout.pocket : cshClockVar(O.variant), PV = CSH_CLOCK.V[vk];
   var L = (O.layout && O.layout.pocket) ? O.layout : cshClockLayout(S, R, vk, fontFn, lang), capAsked = O.caption ? String(O.caption) : "", FP = cshClockPocketFootprint(L, capAsked, fontFn), cap = cshClockCaptionShown(capAsked);      // (R2: la caja con la pedida; se pinta la que se ve)
   var cx = x0 + FP.ox, cy = y0 + FP.oy, lw = Math.max(1, 0.011 * R), alpha = (O.alpha > 0) ? Math.min(1, O.alpha) : 1;
   var out = { labels: [], ends: [], deg: 0, fineDeg: null, numPx: L.numPx, labelStep: L.labelStep, bad: L.bad.slice(), variant: vk, pocket: vk, R: R, sub: null, lid: null };
   var bgI = cshClockInt(A.bg), rimA = cshClockInt(A.goldLight, 0.75), rimB = cshClockInt(A.gold, 0.45), faceI = (PV.face === "surface") ? cshClockInt(A.surface || A.bg) : bgI;
   // (26-oct, translúcida) fa < 1: UN solo disco del color de la esfera con esa opacidad (dos capas translúcidas se sumarían: 0,66 sobre 0,66 = 0,88)
   var fa = cshClockFaceA(O), faceF = (PV.face === "surface") ? cshClockInt(A.surface || A.bg, fa) : cshClockInt(A.bg, fa);
   // (26-oct, Cabra3D: el reloj en el PANEL en vivo) O.layer: "dial" = solo lo que no cambia con el instante (caja, esfera, marcas, cifras, unidad, la cara de la
   // subesfera); "hand" = solo lo que cambia (la cifra exacta, la aguja fina de F y la manecilla). Quien llama guarda "dial" en un bitmap y en cada fotograma pinta
   // encima "hand". Las de tapa (E: la tapa crece con la cifra) no se parten: se pinta todo y out.layer = "". Sin O.layer, todo, como siempre.
   var LY = (!PV.lid && (O.layer === "dial" || O.layer === "hand")) ? O.layer : "";
   out.layer = LY;
   g.antialiasing = true;
   try { g.textAntialiasing = true; } catch (eT) {}
   g.opacity = alpha;
   if (LY !== "hand") {
   // --- 1 · lo de arriba, de atrás hacia delante: cadena, anilla, cuello y corona (la caja, después, tapa el pie del cuello y de la anilla)
   var B = L.bow, eA = CSH_CLOCK.POCKET.BOW_END_DEG;
   if (L.chain) {
      var lp = new Pen(cshClockInt(A.gold, 0.8), Math.max(0.9, lw * 0.85));
      for (i = 0; i < L.chain.length; ++i) {
         var ln = L.chain[i], lx = cx + ln.x, ly = cy + ln.y, hl = 0.036 * R, hw = ln.flat ? 0.021 * R : 0.006 * R, pts = [];
         for (var q = 0; q <= 14; ++q) { var aa = q / 14 * 2 * Math.PI, ca = Math.cos(aa) * hl, sa = Math.sin(aa) * hw; pts.push({ x: lx + ln.tx * ca - ln.ty * sa, y: ly + ln.ty * ca + ln.tx * sa }); }
         cshPocketPolyline(g, pts, lp, false);
      }
      var le = L.chain[L.chain.length - 1], tb = 0.075 * R;      // la barra en T del final
      g.pen = new Pen(cshClockInt(A.goldLight, 0.85), lw * 1.3); g.drawLine(cx + le.x + le.ty * tb, cy + le.y - le.tx * tb, cx + le.x - le.ty * tb, cy + le.y + le.tx * tb);
   }
   var bowW = (vk === "F") ? 0.045 : 0.03, bo = cshPocketEllipsePts(cx, cy - B.cy * R, B.rx * R, B.ry * R, 48, -eA, eA), bi = cshPocketEllipsePts(cx, cy - B.cy * R, (B.rx - bowW) * R, (B.ry - bowW) * R, 48, -eA, eA);
   cshPocketPolyline(g, bo, new Pen(cshClockInt(A.bg, 0.9), lw * 3.2), false);
   cshPocketPolyline(g, bo, new Pen(rimA, lw), false); cshPocketPolyline(g, bi, new Pen(rimB, lw * 0.85), false);
   // (translúcida: el pie del cuello no baja a la esfera —se vería a través de ella—, se queda en el borde)
   var N = CSH_CLOCK.POCKET.NECK, ny0 = (fa < 1) ? Math.max(N.y0, 1 - 0.5 * lw / R) : N.y0, neck = [{ x: cx - N.w0 * R, y: cy - ny0 * R }, { x: cx - N.w1 * R, y: cy - N.y1 * R }, { x: cx + N.w1 * R, y: cy - N.y1 * R }, { x: cx + N.w0 * R, y: cy - ny0 * R }];
   cshPocketFillPoly(g, neck, bgI); cshPocketPolyline(g, neck, new Pen(rimA, lw), true);
   var Cw = L.crown, crown = [{ x: cx - Cw.w, y: cy + Cw.y0 }, { x: cx - Cw.w, y: cy + Cw.y1 + 0.02 * R }, { x: cx - Cw.w + 0.02 * R, y: cy + Cw.y1 }, { x: cx + Cw.w - 0.02 * R, y: cy + Cw.y1 }, { x: cx + Cw.w, y: cy + Cw.y1 + 0.02 * R }, { x: cx + Cw.w, y: cy + Cw.y0 }];
   cshPocketFillPoly(g, crown, bgI); cshPocketPolyline(g, crown, new Pen(rimA, lw), true);
   var nf = (vk === "F") ? 7 : 5;      // el estriado de la corona
   for (i = 1; i < nf; ++i) { var fx = cx - Cw.w + 2 * Cw.w * i / nf; g.pen = new Pen(cshClockInt(A.gold, 0.55), Math.max(0.8, lw * 0.7)); g.drawLine(fx, cy + Cw.y0 - 0.015 * R, fx, cy + Cw.y1 + 0.025 * R); }
   // --- 2 · la caja y su borde
   g.fillCircle(cx, cy, R, new Brush(fa < 1 ? faceF : bgI));
   if (PV.edge === "coin") {
      var pc = new Pen(cshClockInt(A.goldLight, 0.32), Math.max(0.8, lw * 0.75));
      for (i = 0; i < 120; ++i) { var e0 = cshClockPt(cx, cy, 0.948 * R, i * 3), e1 = cshClockPt(cx, cy, 0.99 * R, i * 3); g.pen = pc; g.drawLine(e0.x, e0.y, e1.x, e1.y); }
   } else if (PV.edge === "wave") {
      var wv = [];
      for (i = 0; i <= 288; ++i) { var wa = i * 1.25, wr = (0.9675 + 0.011 * Math.sin(wa * 32 * Math.PI / 180)) * R; wv.push(cshClockPt(cx, cy, wr, wa)); }
      cshPocketPolyline(g, wv, new Pen(cshClockInt(A.goldLight, 0.38), Math.max(0.8, lw * 0.75)), false);
   }
   g.strokeCircle(cx, cy, R - lw / 2 * (PV.edge === "plain" ? 1.6 : 1), new Pen(rimA, lw * (PV.edge === "plain" ? 1.6 : 1)));
   if (PV.edge === "plain") g.strokeCircle(cx, cy, 0.965 * R, new Pen(cshClockInt(A.gold, 0.3), lw * 0.8));
   g.strokeCircle(cx, cy, K.R_BEZEL2 * R, new Pen(rimB, lw * 0.85));
   // --- 3 · la esfera: D esmaltada (la superficie del tema); E con guilloché de torno de rosa en el centro
   if (faceI !== bgI && fa >= 1) g.fillCircle(cx, cy, K.R_BEZEL2 * R - lw * 0.5, new Brush(faceI));
   if (PV.guilloche) {
      var gp = new Pen(cshClockInt(A.gold, 0.12), Math.max(0.7, lw * 0.6));
      for (var rg = 0; rg < 9; ++rg) {
         var r0 = (0.10 + rg * 0.045) * R, gpts = [];
         for (i = 0; i <= 144; ++i) { var ga = i * 2.5, gr = r0 + 0.012 * R * Math.sin((ga * 18 + rg * 90) * Math.PI / 180); gpts.push(cshClockPt(cx, cy, gr, ga)); }
         cshPocketPolyline(g, gpts, gp, false);
      }
   }
   if (PV.inner) { var innerA = (A.ornament && A.ornament.innerFrameAlpha) ? A.ornament.innerFrameAlpha : 0.16; g.strokeCircle(cx, cy, K.R_INNER * R, new Pen(cshClockInt(A.gold, innerA), lw * 0.8)); }
   }      // (fin de LY !== "hand": secciones 1 a 3)
   // --- 4 · la cifra exacta: D y F en una pastilla debajo; E GRABADA en la tapa abierta («dial»: la cifra va en la capa «hand»)
   if (LY === "dial") cap = "";
   if (FP.lid) {
      var LD = FP.lid, lcx = cx + LD.cx, lcy = cy + LD.cy, IN = CSH_CLOCK.POCKET.LID.inner, kn = CSH_CLOCK.POCKET.LID.knW * R;
      // la bisagra (charnela) entre la caja y la tapa
      g.fillRect(cx - kn, cy + R - 0.02 * R, cx + kn, lcy - LD.ry + 0.01 * R, new Brush(bgI));
      g.pen = new Pen(rimA, lw); cshClockNoBrush(g); g.drawRect(cx - kn, cy + R - 0.02 * R, cx + kn, lcy - LD.ry + 0.01 * R);
      for (i = 1; i < 3; ++i) { var kx = cx - kn + 2 * kn * i / 3; g.pen = new Pen(cshClockInt(A.gold, 0.5), lw * 0.8); g.drawLine(kx, cy + R - 0.01 * R, kx, lcy - LD.ry); }
      var lo = cshPocketEllipsePts(lcx, lcy, LD.rx, LD.ry, 72);
      cshPocketFillPoly(g, lo, bgI);
      cshPocketPolyline(g, lo, new Pen(rimA, lw), true);
      cshPocketPolyline(g, cshPocketEllipsePts(lcx, lcy, LD.rx * 0.93, LD.ry * 0.86, 72), new Pen(rimB, lw * 0.85), true);
      cshPocketPolyline(g, cshPocketEllipsePts(lcx, lcy, LD.rx * 0.80, LD.ry * 0.80, 72), new Pen(cshClockInt(A.gold, 0.16), lw * 0.7), true);   // (0,8 ry > la mitad de la cifra: ry ≥ (h/2 + 2)/0,72)
      if (cap) {
         var cf = FP.cap.font, cwid = cf.width(cap), ctop = lcy - (cf.ascent + cf.descent) / 2;
         cshClockText(O, g, cf, cshClockInt(A.text), lcx - cwid / 2, ctop + cf.ascent, cap);
         out.capBox = { x0: lcx - cwid / 2, y0: ctop, x1: lcx + cwid / 2, y1: ctop + cf.ascent + cf.descent };
         // dos rasgos grabados a los lados de la cifra, si caben dentro del grabado
         // (revisor, 25-oct: a «hace 12,5 Ga» desaparecían y a «hace 9,3 Ga» no: el rasgo se ACORTA hasta caber, y solo se quita si queda corto)
         var sx0 = cwid / 2 + 0.05 * R, sl = Math.min(0.16 * R, LD.rx * 0.70 - sx0);
         if (sl > 0.06 * R) for (var sd = -1; sd <= 1; sd += 2) {
            var sw = []; for (i = 0; i <= 16; ++i) { var u = i / 16; sw.push({ x: lcx + sd * (sx0 + sl * u), y: lcy + 0.022 * R * Math.sin(u * 2 * Math.PI) * sd }); }
            cshPocketPolyline(g, sw, new Pen(cshClockInt(A.gold, 0.5), Math.max(0.8, lw * 0.75)), false);
         }
         out.caption = cap; out.capPx = FP.cap.px;
      }
      out.lid = { x0: lcx - LD.rx, y0: lcy - LD.ry, x1: lcx + LD.rx, y1: lcy + LD.ry };
   } else if (cap) {
      out.capBox = cshPocketCaptionPlate(g, O, A, FP, cx, cy, R, cap, vk === "F");
      out.caption = cap; out.capPx = FP.cap.px;
   }
   if (LY !== "hand") {
   // --- 5 · la minutería
   var a0 = -L.span / 2, a1 = L.span / 2, GT = L.geo, tA = GT.R_TICK0, tB = GT.R_TICK_MAJOR, rail0 = tA + 0.02, rail1 = tB - 0.025, dotR = (tA + tB) / 2 + 0.005;
   if (PV.track === "rail") {
      cshClockArc(g, cx, cy, rail0 * R, a0, a1, new Pen(cshClockInt(A.gold, 0.6), lw * 0.85));
      cshClockArc(g, cx, cy, rail1 * R, a0, a1, new Pen(cshClockInt(A.gold, 0.6), lw * 0.85));
   } else if (PV.track === "dots") cshClockArc(g, cx, cy, dotR * R, a0, a1, new Pen(cshClockInt(A.gold, 0.35), lw * 0.7));
   else cshClockArc(g, cx, cy, tA * R, a0, a1, new Pen(cshClockInt(A.gold, 0.55), lw * 0.85));
   for (i = 0; i < L.ticks.length; ++i) {
      var tk = L.ticks[i], isToday = Math.abs(tk.v) < 1e-9, col = isToday ? cshClockInt(A.gold) : cshClockInt(A.goldLight, tk.kind === "major" ? 0.9 : (tk.kind === "half" ? 0.7 : 0.55));
      var r0t = tk.r0, r1t = tk.r1, wt = lw * (tk.kind === "major" ? 1.3 : 0.85);
      if (PV.track === "rail") { r0t = (tk.kind === "major" ? tA - 0.005 : (tk.kind === "half" ? rail0 - 0.01 : rail0)) * R; r1t = (tk.kind === "major" ? tB : (tk.kind === "half" ? rail1 + 0.01 : rail1)) * R; if (tk.kind === "major") wt = lw * 1.5; }
      else if (PV.track === "dots" && tk.kind !== "major") {
         var pd = cshClockPt(cx, cy, dotR * R, tk.deg); g.fillCircle(pd.x, pd.y, Math.max(tk.kind === "half" ? 1.2 : 0.85, (tk.kind === "half" ? 0.016 : 0.010) * R), new Brush(col)); continue;
      } else if (PV.track === "dots") { r0t = (tA + 0.01) * R; r1t = tB * R; }
      var p0 = cshClockPt(cx, cy, r0t, tk.deg), p1 = cshClockPt(cx, cy, r1t, tk.deg);
      g.pen = new Pen(col, wt); g.drawLine(p0.x, p0.y, p1.x, p1.y);
   }
   // --- 6 · las cifras (crema; «hoy» en oro) y los extremos (estrella = Big Bang)
   var numC = cshClockInt(A.text, 0.92), todayC = cshClockInt(A.gold);
   for (i = 0; i < L.labels.length; ++i) {
      var lb = L.labels[i];
      cshClockText(O, g, lb.font, (Math.abs(lb.v) < 1e-9) ? todayC : numC, cx + lb.x - lb.w / 2, cy + lb.y - lb.h / 2 + lb.a, lb.text);
      out.labels.push({ text: lb.text, x0: cx + lb.box.x0, y0: cy + lb.box.y0, x1: cx + lb.box.x1, y1: cy + lb.box.y1, px: lb.px });
   }
   for (i = 0; i < L.ends.length; ++i) {
      var e = L.ends[i];
      if (!e) continue;
      if (e.sym === "bigbang") cshClockStar(g, cx + e.x, cy + e.y, e.h * 0.55, cshClockInt(A.goldLight), lw);
      else if (e.text) cshClockText(O, g, e.font, (Math.abs(e.v) < 1e-9) ? todayC : numC, cx + e.x - e.w / 2, cy + e.y - e.h / 2 + e.font.ascent, e.text);
      out.ends.push({ text: e.text || e.sym, x0: cx + e.box.x0, y0: cy + e.box.y0, x1: cx + e.box.x1, y1: cy + e.box.y1 });
   }
   // --- 7 · el Sol y la unidad
   for (i = 0; i < L.epochs.length; ++i) { var ep = L.epochs[i]; if (ep.sym === "sun") cshClockSun(g, cx + ep.x, cy + ep.y, ep.r, cshClockInt(A.gold), lw); }
   var U = L.unit;
   if (U) {
      cshClockText(O, g, U.font, cshClockInt(A.text3), cx + U.x - U.w / 2, cy + U.y - U.h / 2 + U.font.ascent, U.text);
      out.unit = { text: U.text, x0: cx + U.box.x0, y0: cy + U.box.y0, x1: cx + U.box.x1, y1: cy + U.box.y1 };
   } else out.unit = null;
   }      // (fin de LY !== "hand": secciones 5 a 7)
   // --- 8 · la subesfera de F (aguja fina: una vuelta por marca mayor, cshClockFineAngle)
   if (L.sub) {
      var sb = L.sub, scx = cx + sb.x, scy = cy + sb.y;
      if (LY !== "hand") {
      g.fillCircle(scx, scy, sb.r, new Brush(cshClockInt(A.surface || A.bg)));
      g.strokeCircle(scx, scy, sb.r, new Pen(cshClockInt(A.gold, 0.6), lw * 0.85));
      for (i = 0; i < 20; ++i) { var mj = (i % 2) === 0, q0 = cshClockPt(scx, scy, sb.r * (i === 0 ? 0.55 : (mj ? 0.72 : 0.84)), i * 18), q1 = cshClockPt(scx, scy, sb.r * 0.95, i * 18); g.pen = new Pen(cshClockInt(i === 0 ? A.gold : A.goldLight, i === 0 ? 1 : (mj ? 0.7 : 0.45)), lw * (i === 0 ? 1.2 : 0.75)); g.drawLine(q0.x, q0.y, q1.x, q1.y); }
      }
      var fd = cshClockFineAngle(S, v), ft = cshClockPt(scx, scy, sb.r * 0.86, fd), fb = cshClockPt(scx, scy, -sb.r * 0.25, fd);
      if (LY !== "dial") {
      g.pen = new Pen(cshClockInt(A.text2), Math.max(1, lw * 0.9)); g.drawLine(fb.x, fb.y, ft.x, ft.y);
      g.fillCircle(scx, scy, Math.max(1.2, 0.02 * R), new Brush(cshClockInt(A.text2)));
      }
      out.fineDeg = fd; out.sub = { x: scx, y: scy, r: sb.r };
   }
   // --- 9 · la manecilla y el eje
   var deg = cshClockAngle(S, v, vk), HA = cshPocketHandAt(L.hand, cx, cy, deg);
   if (LY !== "dial") {
   cshPocketPaintHand(g, HA, A, faceI, lw);
   g.fillCircle(cx, cy, 0.05 * R, new Brush(cshClockInt(A.gold)));
   g.fillCircle(cx, cy, 0.019 * R, new Brush(bgI));
   }
   out.deg = deg; out.tip = cshClockPt(cx, cy, L.hand.tip, deg); out.handAt = HA;
   g.opacity = 1;
   out.box = { x0: x0, y0: y0, x1: x0 + FP.w, y1: y0 + FP.h };
   out.pivot = { x: cx, y: cy };
   out.ms = Date.now() - t0;
   return out;
}
#endif
