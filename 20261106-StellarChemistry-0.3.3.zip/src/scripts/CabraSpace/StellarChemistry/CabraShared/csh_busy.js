#ifndef __CSH_BUSY_JS
#define __CSH_BUSY_JS
// ============================================================================
// CabraShared/csh_busy.js — EL RELOJ DE «ESTOY PENSANDO» sobre la imagen 2D (29-oct-2026, noche; 30-oct: al CENTRO y mayor)
// ----------------------------------------------------------------------------
// Petición de Nino (29-oct): «como al apretar Analizar tardan tiempo, yo pondría el cronómetro que hemos diseñado para el paso de tiempo
// encima de la imagen 2D, como un pequeño icono que muestre que se está pensando y recogiendo datos». Un reloj de bolsillo —esmalte, borde de
// moneda, minutería de puntos, corona y anilla, manecilla Breguet «pomme»: la variante D de la máquina del tiempo— con la manecilla girando,
// pintado ENCIMA del control de la foto. No cambia el layout: se pinta sobre lo que haya, sin ocupar sitio (criterio §11.3).
// (30-oct-2026, Nino) «el reloj que enseña la espera aparece en el mismo sitio que estos botones [el conmutador «Real photo | Stars»]. Lo que
// propongo es llevarlo al centro de la imagen 2D, y hacerlo un poco mayor, para que no haya duda de que se está cargando algo y no se puede
// tocar nada hasta que esté cargado». Ahora:
//   · va en el CENTRO de la imagen 2D de los cuatro scripts, de 96 px lógicos (CSH_BUSY.SIZE: la constante, en un solo sitio) sobre un disco
//     oscuro semiopaco para que se lea sobre cualquier foto; debajo, centrada, la pastilla «Gathering data… / Recogiendo datos…» si cabe;
//   · «centro» = el de la parte VISIBLE DE LA FOTO: con `opts.area` (fn(ctl) → {x0,y0,x1,y1} en px del control) el script dice dónde está la foto
//     (con zoom ocupa todo el control; con la foto más pequeña que el lienzo, es el centro de la foto); sin `area`, el del control. Se recoloca
//     solo al cambiar el tamaño de la ventana, el zoom o el encuadre (la geometría se rehace en cada tic si cambia algo);
//   · si la zona es demasiado pequeña para 96 px, el reloj se encoge (mínimo CSH_BUSY.MIN_SIZE); por debajo, no sale;
//   · mientras está puesto IGNORA el ratón sobre sí mismo y su pastilla (clic, arrastre, rueda, doble clic): no elige la estrella que haya debajo
//     ni mueve el zoom. Fuera del reloj la foto responde como siempre (la espera de fondo no bloquea el zoom). No cubre ningún otro control:
//     el botón de cerrar y el de parar son de la ventana y siguen vivos. La opción `corner` ha desaparecido: nadie la usa.
// PROCEDENCIA: el dibujo es nuevo y pequeño (a 28-40 px no cabía el reloj entero de CabraShared/csh_clock.js, cuyas cifras son ilegibles
// por debajo de ~100 px); toma de él la paleta (tokens de CSH_ATLAS), la forma de D (esmalte romano, corona, anilla, «pomme») y su
// manecilla (cshClockHand «lance»/«pomme»). CabraShared no depende de Cabra3D.
//
// REGLAS (de CabraPilot): nada de trabajo en onPaint —solo se pinta el ESTADO ACTUAL (`B.angle`, que pone el Timer)—; el Timer
// (≈ 12,5 fps) pide repaint SOLO de la zona del reloj (`update(x0, y0, x1, y1)`, medido en PixInsight 1.9: la zona llega a onPaint) y se
// PARA cuando no queda trabajo; ni un MessageBox. Sin este include los scripts quedan como estaban (todo llamador comprueba
// `typeof cshBusyOn === "function"`).
//
// API (todo por control; varios «motivos» pueden estar encendidos a la vez —el análisis, la red, una ficha—: el reloj vive mientras quede
// alguno y se apaga al quitar el último):
//   cshBusyAttach( ctl, opts )     envuelve ctl.onPaint y los manejadores del ratón que ctl YA tenga (llamar DESPUÉS de asignarlos). Idempotente.
//        opts = { area: fn(ctl) → {x0,y0,x1,y1} (donde centrar; de fábrica, el control entero), text: false (sin pastilla),
//                 quiet: fn() → true = no pintar (p. ej. CC_QUIET), scale: fn(ctl) → px físicos por px lógico, delayS (de fábrica 0,15: lo más
//                 corto que eso no parpadea), guard: false (no ignorar el ratón sobre el reloj) }
//   cshBusyOn( ctl, key, opt )     enciende el motivo `key` (opt.immediate: se ve YA, sin esperar los 0,15 s: para el análisis)
//   cshBusyOff( ctl, key )         lo apaga; sin motivos, el Timer se para y la zona se repinta limpia
//   cshBusySet( ctl, key, on, opt )  las dos de arriba
//   cshBusyOffAll( ctl )           lo apaga todo (cerrar el diálogo, abortar)
//   cshBusyActive( ctl ) · cshBusyRunning( ctl )   hay motivos · el Timer corre
//   cshBusyRect( ctl )             la zona que ocupa (x0, y0, x1, y1 en px del control), o null si la zona aún no tiene tamaño
//   cshBusyHit( ctl, x, y )        ¿el punto (px del control) cae sobre el reloj o su pastilla, y está puesto? (lo usan el ratón y las pruebas)
//   cshBusyPaintIcon( g, x0, y0, S, k, angle )   el dibujo del reloj entero (cara + manecilla; lo usan las pruebas)
// ES5. Comentarios en castellano; identificadores en inglés.
// ============================================================================

var CSH_BUSY = {
   SIZE: 96,          // lado de la caja del reloj, px lógicos (30-oct, Nino: «un poco mayor»; antes 34). EL ÚNICO SITIO de este valor
   MIN_SIZE: 48,      // si la zona no da para SIZE, se encoge hasta esto; por debajo, no sale
   DISC: 0.56,        // radio del disco oscuro de detrás, en lados de caja (0,56: encierra la corona y el borde de moneda)
   DISC_ALPHA: 0.78,  // opacidad del disco (semiopaco: se intuye la foto pero se lee sobre cualquier cielo)
   MARGIN: 10,        // hueco mínimo hasta el borde de la zona, px lógicos
   FPS_S: 0.08,       // intervalo del Timer: 12,5 fotogramas por segundo
   REV_S: 2.4,        // segundos por vuelta de la manecilla
   DELAY_S: 0.15,     // sin la opción immediate, el reloj sale tras este rato (un trabajo de 50 ms no lo hace parpadear)
   PILL_H: 22,        // alto de la pastilla, px lógicos
   PILL_GAP: 6        // hueco entre el disco y la pastilla, px lógicos
};
// DEFECTOS INYECTADOS (pruebas: CSH_BUSY_BREAK): «nostop» = el Timer no se para al acabar · «fullrepaint» = pide repaint del control ENTERO ·
// «static» = la manecilla no avanza · «nocenter» = el reloj en la esquina de arriba a la derecha (no en el centro) · «noguard» = el ratón
// atraviesa el reloj · «nocache» = lo estático se dibuja entero en cada tic (sin el Bitmap de lo que no se mueve)
var CSH_BUSY_BREAK = "";
function cshBusyBroken(k) { return (typeof CSH_BUSY_BREAK === "string") && CSH_BUSY_BREAK.length > 0 && CSH_BUSY_BREAK.indexOf(k) >= 0; }
var CSH_BUSY_TXT = { gather: ["Gathering data…", "Recogiendo datos…"] };
function cshBusyTx(key) {
   var e = CSH_BUSY_TXT[key], es = (typeof cshLangIsEs === "function") ? cshLangIsEs() : false;
   return e ? e[es ? 1 : 0] : key;
}
function cshBusyScaleOf(B) {
   var k = 0;
   if (B.o && typeof B.o.scale === "function") { try { k = B.o.scale(B.ctl); } catch (e0) { k = 0; } }
   if (!(k > 0)) { try { k = B.ctl.logicalPixelsToPhysical(1000) / 1000; } catch (e1) { k = 0; } }
   return (k > 0) ? k : 1;
}
// La zona donde se centra: la que dice `opts.area` (recortada al control) o el control entero
function cshBusyArea(B, w, h) {
   var r = { x0: 0, y0: 0, x1: w, y1: h };
   if (B.o && typeof B.o.area === "function") {
      var a = null;
      try { a = B.o.area(B.ctl); } catch (e) { a = null; }
      if (a && isFinite(a.x0) && isFinite(a.y0) && isFinite(a.x1) && isFinite(a.y1)) {
         r = { x0: Math.max(0, Math.round(a.x0)), y0: Math.max(0, Math.round(a.y0)), x1: Math.min(w, Math.round(a.x1)), y1: Math.min(h, Math.round(a.y1)) };
         if (!(r.x1 > r.x0 && r.y1 > r.y0)) r = { x0: 0, y0: 0, x1: w, y1: h };
      }
   }
   return r;
}
// LA GEOMETRÍA (px físicos del control): el centro, la caja del reloj, el disco, la pastilla (o null) y la unión (la zona que se repinta)
function cshBusyLayout(B) {
   var c = B.ctl, w = 0, h = 0;
   try { w = c.width; h = c.height; } catch (e) { return null; }
   var k = cshBusyScaleOf(B), mg = Math.round(CSH_BUSY.MARGIN * k), es = (typeof cshLangIsEs === "function") ? cshLangIsEs() : false;
   var ar = cshBusyArea(B, w, h), S = Math.round(CSH_BUSY.SIZE * k);
   var fit = Math.min(ar.x1 - ar.x0, ar.y1 - ar.y0) - 2 * mg;                  // (lo que da de si la zona: el disco entero con su margen)
   if (2 * CSH_BUSY.DISC * S > fit) S = Math.floor(fit / (2 * CSH_BUSY.DISC));
   if (!(S >= Math.round(CSH_BUSY.MIN_SIZE * k))) return null;
   var broken = cshBusyBroken("nocenter");
   var key = [w, h, k, es ? 1 : 0, ar.x0, ar.y0, ar.x1, ar.y1, S, broken ? 1 : 0, (B.o && B.o.text === false) ? 0 : 1].join("|");
   if (B.lay && B.lay.key === key) return B.lay;
   cshBusyFreeCache(B);
   var cx = broken ? w - mg - S / 2 : (ar.x0 + ar.x1) / 2, cy = broken ? mg + S / 2 : (ar.y0 + ar.y1) / 2, ix0 = Math.round(cx - S / 2), iy0 = Math.round(cy - S / 2), Rd = CSH_BUSY.DISC * S;
   var L = { key: key, k: k, S: S, cx: cx, cy: cy, Rd: Rd, area: ar, icon: { x0: ix0, y0: iy0, x1: ix0 + S, y1: iy0 + S }, pill: null, text: "" };
   var u = { x0: cx - Rd, y0: cy - Rd, x1: cx + Rd, y1: cy + Rd };
   if (!(B.o && B.o.text === false) && typeof cpFont === "function") {
      var f = cpFont("text", Math.round(11 * k)), t = cshBusyTx("gather"), tw = f.width(t), pad = Math.round(11 * k), ph = Math.round(CSH_BUSY.PILL_H * k), gap = Math.round(CSH_BUSY.PILL_GAP * k), pw = tw + 2 * pad;
      var px0 = Math.round(cx - pw / 2), py0 = Math.round(cy + Rd + gap);
      if (px0 >= ar.x0 + mg / 2 && px0 + pw <= ar.x1 - mg / 2 && py0 + ph <= ar.y1 - mg / 2) {       // (la pastilla solo si cabe debajo del disco, dentro de la zona)
         L.pill = { x0: px0, y0: py0, x1: px0 + pw, y1: py0 + ph, font: f, pad: pad };
         L.text = t;
         u.x0 = Math.min(u.x0, px0); u.x1 = Math.max(u.x1, px0 + pw); u.y1 = Math.max(u.y1, py0 + ph);
      }
   }
   var pd = Math.ceil(2 * k);
   L.rect = { x0: Math.max(0, Math.floor(u.x0) - pd), y0: Math.max(0, Math.floor(u.y0) - pd), x1: Math.min(w, Math.ceil(u.x1) + pd), y1: Math.min(h, Math.ceil(u.y1) + pd) };
   B.lay = L;
   return L;
}
function cshBusyRect(ctl) {
   var B = ctl ? ctl.cshBusy : null;
   if (!B) return null;
   var L = cshBusyLayout(B);
   return L ? L.rect : null;
}
// ¿El punto cae sobre el reloj (su disco) o su pastilla, y el reloj esta puesto? (el ratón se ignora ahí)
function cshBusyHit(ctl, x, y) {
   var B = ctl ? ctl.cshBusy : null;
   if (!B || !B.shown || B.n <= 0) return false;
   var L = cshBusyLayout(B);
   if (!L) return false;
   var m = Math.ceil(3 * L.k), dx = x - L.cx, dy = y - L.cy;
   if (dx * dx + dy * dy <= (L.Rd + m) * (L.Rd + m)) return true;
   var P = L.pill;
   return !!(P && x >= P.x0 - m && x <= P.x1 + m && y >= P.y0 - m && y <= P.y1 + m);
}

// ---------------------------------------------------------------------------
// EL DIBUJO: un reloj de bolsillo en miniatura. (x0, y0) = la esquina de la caja; S = su lado; k = px físicos por lógico; angle = grados desde las 12, a favor del reloj
// ---------------------------------------------------------------------------
function cshBusyPt(cx, cy, r, deg) { var a = deg * Math.PI / 180; return { x: cx + r * Math.sin(a), y: cy - r * Math.cos(a) }; }
function cshBusyPaintIcon(g, x0, y0, S, k, angle) { cshBusyPaintFace(g, x0, y0, S, k); cshBusyPaintHand(g, x0, y0, S, k, angle); }
// LA CARA (lo que no se mueve): corona, esmalte, borde de moneda y minuteria
function cshBusyPaintFace(g, x0, y0, S, k) {
   var A = CSH_ATLAS, R = S * 0.39, cx = x0 + S / 2, cy = y0 + S - R - 1.2 * k, i;
   var gold = cpInt(A.gold), goldLight = cpInt(A.goldLight), lw = Math.max(1, 0.0215 * S * 1.0);
   try { g.antialiasing = true; } catch (e0) {}
   // la corona y la anilla (arriba): el cuello, la corona estriada y la anilla redonda
   var crW = 0.15 * S, crT = y0 + 1.2 * k, crB = cy - R + 0.5 * k;
   g.brush = new Brush(gold); g.pen = new Pen(gold, 1); g.fillRect(cx - crW / 2, crT + 0.07 * S, cx + crW / 2, crB, new Brush(gold));
   g.fillRect(cx - crW * 0.8, crT, cx + crW * 0.8, crT + 0.08 * S, new Brush(gold));
   // el esmalte (la superficie del tema, algo transparente para intuir la foto) y el borde de moneda: un filete grueso y otro fino por dentro
   g.fillCircle(cx, cy, R, new Brush(cpInt(A.surface, 0.86)));
   g.strokeCircle(cx, cy, R, new Pen(gold, Math.max(1.4 * k, lw * 1.25)));
   g.strokeCircle(cx, cy, R - 2.6 * k, new Pen(cpInt(A.gold, 0.35), Math.max(1, 0.7 * k)));
   // la minutería: doce puntos, los de las 12, 3, 6 y 9 como rayitas
   for (i = 0; i < 12; ++i) {
      var d = i * 30, major = (i % 3 === 0);
      if (major) { var p0 = cshBusyPt(cx, cy, R * 0.66, d), p1 = cshBusyPt(cx, cy, R * 0.84, d); g.pen = new Pen(goldLight, Math.max(1.1, lw * 1.1)); g.drawLine(p0.x, p0.y, p1.x, p1.y); }
      else { var pp = cshBusyPt(cx, cy, R * 0.76, d); g.fillCircle(pp.x, pp.y, Math.max(0.7, 0.55 * k), new Brush(cpInt(A.gold, 0.8))); }
   }
}
// LA MANECILLA (lo unico que cambia en cada tic), con el halo oscuro debajo (se lee sobre las marcas) y el «pomme» de los relojes de bolsillo: un anillo hacia la punta
function cshBusyPaintHand(g, x0, y0, S, k, angle) {
   var A = CSH_ATLAS, R = S * 0.39, cx = x0 + S / 2, cy = y0 + S - R - 1.2 * k;
   var gold = cpInt(A.gold), goldLight = cpInt(A.goldLight), dark = cpInt(A.bg, 0.9), lw = Math.max(1, 0.0215 * S * 1.0);
   try { g.antialiasing = true; } catch (e0) {}
   var tip = cshBusyPt(cx, cy, R * 0.74, angle), tail = cshBusyPt(cx, cy, -R * 0.2, angle), pom = cshBusyPt(cx, cy, R * 0.50, angle), pr = R * 0.105;
   g.pen = new Pen(dark, lw * 3.0); g.drawLine(tail.x, tail.y, tip.x, tip.y);
   g.pen = new Pen(goldLight, lw * 1.25); g.drawLine(tail.x, tail.y, tip.x, tip.y);
   g.fillCircle(pom.x, pom.y, pr, new Brush(cpInt(A.surface)));
   g.strokeCircle(pom.x, pom.y, pr, new Pen(goldLight, lw * 1.1));
   g.fillCircle(cx, cy, Math.max(1.2, R * 0.11), new Brush(gold));
}
// el disco oscuro semiopaco de detrás (30-oct): para que el reloj se lea sobre cualquier foto (una nebulosa clara, un cielo gris)
function cshBusyPaintDisc(g, L) {
   var A = CSH_ATLAS;
   try { g.antialiasing = true; } catch (e0) {}
   g.fillCircle(L.cx, L.cy, L.Rd, new Brush(cpInt(A.bg, CSH_BUSY.DISC_ALPHA)));
   g.strokeCircle(L.cx, L.cy, L.Rd, new Pen(cpInt(A.gold, 0.45), Math.max(1, 1.2 * L.k)));
}
// la pastilla del texto, de bordes redondos (un polígono con dos medios círculos: sin solapar rellenos con alfa)
function cshBusyPaintPill(g, P, text, k) {
   var A = CSH_ATLAS, r = (P.y1 - P.y0) / 2, cy = (P.y0 + P.y1) / 2, pts = [], n = 10, i;
   for (i = 0; i <= n; ++i) { var a = -Math.PI / 2 + Math.PI * i / n; pts.push(new Point(P.x1 - r + r * Math.cos(a), cy + r * Math.sin(a))); }
   for (i = 0; i <= n; ++i) { var b = Math.PI / 2 + Math.PI * i / n; pts.push(new Point(P.x0 + r + r * Math.cos(b), cy + r * Math.sin(b))); }
   g.brush = new Brush(cpInt(A.bg, 0.86)); g.pen = new Pen(cpInt(A.gold, 0.45), Math.max(1, k * 0.8)); g.fillPolygon(pts);
   try { g.brush = new Brush(0x00000000, (typeof BrushStyle_Empty !== "undefined") ? BrushStyle_Empty : 0); } catch (e) {}
   try { g.textAntialiasing = true; } catch (e1) {}
   g.font = P.font; g.pen = new Pen(cpInt(A.text));
   g.drawText(P.x0 + P.pad, Math.round(cy + (P.font.ascent - P.font.descent) / 2), text);
}

// ---------------------------------------------------------------------------
// EL ESTADO Y EL TIMER
// ---------------------------------------------------------------------------
// El ratón sobre el reloj se ignora mientras esta puesto: se envuelven los manejadores que el control YA tiene (se puede volver a llamar tras
// asignar otros: lo ya envuelto se salta).
var CSH_BUSY_MOUSE = ["onMousePress", "onMouseRelease", "onMouseMove", "onMouseDoubleClick", "onMouseWheel"];
function cshBusyGuard(ctl) {
   var B = ctl ? ctl.cshBusy : null;
   if (!B || (B.o && B.o.guard === false)) return;
   CSH_BUSY_MOUSE.forEach(function(nm) {
      var f = ctl[nm];
      if (typeof f !== "function" || f.cshBusyGuarded === true) return;
      var w = function(x, y) {
         if (!cshBusyBroken("noguard") && cshBusyHit(ctl, x, y)) { ++B.stats.swallowed; return; }
         return f.apply(ctl, arguments);
      };
      w.cshBusyGuarded = true;
      ctl[nm] = w;
   });
}
function cshBusyAttach(ctl, opts) {
   if (!ctl || typeof Timer === "undefined") return null;
   if (ctl.cshBusy) { if (opts) { for (var k in opts) if (opts.hasOwnProperty(k)) ctl.cshBusy.o[k] = opts[k]; ctl.cshBusy.lay = null; } cshBusyGuard(ctl); return ctl.cshBusy; }
   var B = { ctl: ctl, o: opts || {}, keys: {}, n: 0, shown: false, t0: 0, tShown: 0, angle: 0, lay: null, timer: null, orig: ctl.onPaint,
             stats: { ticks: 0, updates: 0, fullUpdates: 0, paints: 0, paintMs: 0, starts: 0, stops: 0, swallowed: 0, lastRect: null, rects: [] } };
   B.timer = new Timer; B.timer.interval = CSH_BUSY.FPS_S; B.timer.periodic = true;
   B.timer.onTimeout = function() { cshBusyTick(B); };
   ctl.cshBusy = B;
   ctl.onPaint = function(x0, y0, x1, y1) {
      var t0 = Date.now();
      if (B.orig) B.orig.apply(ctl, arguments);
      cshBusyPaintOver(B, x0, y0, x1, y1);
      ++B.stats.paints; B.stats.paintMs += Date.now() - t0;
   };
   cshBusyGuard(ctl);
   return B;
}
// pide el repaint de la zona del reloj (nunca del control entero, salvo el defecto inyectado)
function cshBusyRepaint(B, sync) {
   var L = cshBusyLayout(B);
   if (!L) return;
   var r = L.rect, c = B.ctl, pr = B.stats.lastRect;
   try {
      // (si el reloj se ha movido —zoom, encuadre, tamaño de la ventana— la zona de antes se repinta tambien: sin fantasma)
      if (pr && (pr.x0 !== r.x0 || pr.y0 !== r.y0 || pr.x1 !== r.x1 || pr.y1 !== r.y1)) { try { c.update(pr.x0, pr.y0, pr.x1, pr.y1); } catch (eP) {} }
      if (cshBusyBroken("fullrepaint")) { c.update(); ++B.stats.fullUpdates; }
      else if (sync) c.repaint(r.x0, r.y0, r.x1, r.y1);
      else c.update(r.x0, r.y0, r.x1, r.y1);
      ++B.stats.updates; B.stats.lastRect = r;
      if (B.stats.rects.length < 64) B.stats.rects.push([r.x0, r.y0, r.x1, r.y1]);
   } catch (e) {}
}
function cshBusyTick(B) {
   ++B.stats.ticks;
   if (B.n <= 0) { if (!cshBusyBroken("nostop")) cshBusyHalt(B); return; }      // (red de seguridad: sin motivos no se anima)
   var now = Date.now();
   if (!B.shown) {
      var d = (B.o && B.o.delayS >= 0) ? B.o.delayS : CSH_BUSY.DELAY_S;
      if (now - B.t0 < d * 1000) return;
      B.shown = true; B.tShown = now;
   }
   B.angle = cshBusyBroken("static") ? 0 : (((now - B.tShown) / (CSH_BUSY.REV_S * 1000)) % 1) * 360;
   cshBusyRepaint(B, false);
}
// lo único que pinta el reloj: el estado de ahora (cero cálculo)
function cshBusyPaintOver(B, x0, y0, x1, y1) {
   if (!B.shown || B.n <= 0) return;
   if (B.o && typeof B.o.quiet === "function") { var q = false; try { q = B.o.quiet() === true; } catch (e0) {} if (q) return; }
   var L = cshBusyLayout(B);
   if (!L) return;
   var r = L.rect;
   if (x1 > x0 && y1 > y0 && (x1 <= r.x0 || x0 >= r.x1 || y1 <= r.y0 || y0 >= r.y1)) return;      // (la zona sucia no toca al reloj)
   var g = new Graphics(B.ctl);
   try { cshBusyPaintFrame(g, B, L, B.angle); } finally { g.end(); }
}
// Un fotograma: lo estatico (disco + pastilla + cara) sale de un Bitmap hecho UNA vez por geometria (la composicion con alfa es asociativa: el resultado
// es el de dibujarlo directo) y solo la manecilla se dibuja en cada tic. CSH_BUSY_BREAK = «nocache»: se dibuja todo directo, como en el primer
// reloj de 96 px (0,63 ms por fotograma, 4 veces mas que el icono de 34 px).
function cshBusyPaintFrame(g, B, L, angle) {
   var bm = cshBusyBroken("nocache") ? null : cshBusyStatic(L);
   if (bm) g.drawBitmap(L.rect.x0, L.rect.y0, bm);
   else cshBusyPaintStatic(g, L, 0, 0);
   cshBusyPaintHand(g, L.icon.x0, L.icon.y0, L.S, L.k, angle);
}
// lo estatico, con la esquina (ox, oy) restada (para pintarlo en el Bitmap de la zona)
function cshBusyPaintStatic(g, L, ox, oy) {
   var L2 = L;
   if (ox !== 0 || oy !== 0) {
      L2 = { k: L.k, S: L.S, cx: L.cx - ox, cy: L.cy - oy, Rd: L.Rd, icon: { x0: L.icon.x0 - ox, y0: L.icon.y0 - oy },
             pill: L.pill ? { x0: L.pill.x0 - ox, y0: L.pill.y0 - oy, x1: L.pill.x1 - ox, y1: L.pill.y1 - oy, font: L.pill.font, pad: L.pill.pad } : null, text: L.text };
   }
   cshBusyPaintDisc(g, L2);
   if (L2.pill) cshBusyPaintPill(g, L2.pill, L2.text, L2.k);
   cshBusyPaintFace(g, L2.icon.x0, L2.icon.y0, L2.S, L2.k);
}
function cshBusyStatic(L) {
   if (L.cache) return L.cache;
   var w = L.rect.x1 - L.rect.x0, h = L.rect.y1 - L.rect.y0;
   if (!(w > 0 && h > 0)) return null;
   try {
      var bm = new Bitmap(w, h);
      bm.fill(0x00000000);                                    // (transparente: ANTES de abrir el Graphics)
      var g = new Graphics(bm);
      try { cshBusyPaintStatic(g, L, L.rect.x0, L.rect.y0); } finally { g.end(); }
      L.cache = bm;
   } catch (e) { L.cache = null; }
   return L.cache;
}
function cshBusyFreeCache(B) { if (B && B.lay && B.lay.cache) { try { B.lay.cache.clear(); } catch (e) {} B.lay.cache = null; } }
function cshBusyHalt(B) {
   var was = B.shown;
   try { B.timer.stop(); } catch (e) {}
   B.shown = false; ++B.stats.stops;
   if (was) cshBusyRepaint(B, false);                 // (quita el reloj: la zona se repinta sin él)
   cshBusyFreeCache(B);
}
function cshBusyOn(ctl, key, opt) {
   var B = ctl ? ctl.cshBusy : null;
   if (!B) return false;
   key = key || "work";
   cshBusyGuard(ctl);                     // (por si el script asigno manejadores del raton despues de enganchar el reloj)
   if (!B.keys[key]) { B.keys[key] = true; ++B.n; }
   if (!B.timer.isRunning) { B.t0 = Date.now(); ++B.stats.starts; try { B.timer.start(); } catch (e) {} }
   if (opt && opt.immediate === true && !B.shown) { B.shown = true; B.tShown = Date.now(); B.angle = 0; cshBusyRepaint(B, true); }
   return true;
}
function cshBusyOff(ctl, key) {
   var B = ctl ? ctl.cshBusy : null;
   if (!B) return false;
   key = key || "work";
   if (B.keys[key]) { delete B.keys[key]; --B.n; }
   if (B.n <= 0) { B.n = 0; if (!cshBusyBroken("nostop")) cshBusyHalt(B); else B.shown = false; }
   return true;
}
function cshBusySet(ctl, key, on, opt) { return on ? cshBusyOn(ctl, key, opt) : cshBusyOff(ctl, key); }
function cshBusyOffAll(ctl) {
   var B = ctl ? ctl.cshBusy : null;
   if (!B) return false;
   B.keys = {}; B.n = 0;
   if (!cshBusyBroken("nostop")) cshBusyHalt(B); else B.shown = false;
   return true;
}
function cshBusyActive(ctl) { var B = ctl ? ctl.cshBusy : null; return !!(B && B.n > 0); }
function cshBusyRunning(ctl) { var B = ctl ? ctl.cshBusy : null; return !!(B && B.timer && B.timer.isRunning === true); }
#endif
