// ============================================================================
// CabraShared/csh_gaia.js — GAIA: LA BASE LOCAL PRIMERO, LA RED DESPUES
// ----------------------------------------------------------------------------
// Encargo de Nino (15-oct): lo que trae la base Gaia DR3 de PixInsight (proceso Gaia, ficheros .xpsd) —posicion, paralaje,
// movimiento propio, G, BP, RP y banderas— sale de ella; a internet solo va lo que no tiene. UNA sola implementacion:
//   · `cpSfGaiaSource()`   que base ve ESTA instancia (DR3; si no, DR3/SP); `cshGaiaProbe(release)` lo mide;
//   · `cpSfGaiaSearch(...)` un cono al proceso Gaia (filas del proceso tal cual) — y se RECUERDA (CSH_GAIA_LAST): quien
//     pida despues un cono contenido en ese (CabraComposition dentro de CabraStarAnalysis) recibe las MISMAS filas sin
//     volver a preguntar (`cshGaiaLocalField`);
//   · `cshGaiaNetSearch(...)` sin base local, las mismas columnas a VizieR y, si no contesta, al archivo de ESA.
// PROCEDENCIA: CabraStars lib/cs_run.js (csGaiaProbe, csGaiaNetSearch, csRefineAdqlEsa), CabraPilot engine/starfield_run.js
// (cpSfGaiaSource, cpSfGaiaSearch) y CabraComposition src/cc_gaialocal.js (filas como objetos, «sin dato» = 0).
// ES5.
// ============================================================================

// ¿Que ve el proceso Gaia de ESTA instancia para una version de la base? (get-info)
function cshGaiaProbe(release) {
   var out = { measured: false, valid: false, files: 0, spectrum: null };
   try {
      var g = new Gaia;
      g.command = "get-info";
      g.dataRelease = release;
      try { g.verbosity = 0; } catch (eV) {}
      g.executeGlobal();
      out.measured = true;
      out.valid = (g.isValid === true);
      try { out.files = g.databaseFilePaths ? g.databaseFilePaths.length : 0; } catch (eF) {}
      try {
         if (g.databaseHasMeanSpectrumData)
            out.spectrum = { start: Number(g.databaseSpectrumStart), step: Number(g.databaseSpectrumStep), count: Number(g.databaseSpectrumCount) };
      } catch (eS) {}
   } catch (e) {}
   return out;
}

// ---------------------------------------------------------------------------
// LA BASE Gaia DE ESTA INSTANCIA. DR3 si el proceso la tiene; si no, DR3/SP (solo
// las estrellas con espectro publicado: el 8-13 % de las de DR3, medido); si no,
// «no instalado». Devuelve { ok, code, release, name, onDisk }.
// ---------------------------------------------------------------------------
function cpSfGaiaSource() {
   var out = { ok: false, code: "no-gaia", release: null, name: "", onDisk: 0 };
   if (typeof Gaia !== "function") return out;
   var tries = [];
   try { tries.push([Gaia.DataRelease_3, "DR3"]); } catch (e1) {}
   try { tries.push([Gaia.DataRelease_3_SP, "DR3/SP"]); } catch (e2) {}
   for (var i = 0; i < tries.length; ++i) {
      if (tries[i][0] === undefined || tries[i][0] === null) continue;
      var p = cshGaiaProbe(tries[i][0]);
      if (p.measured && p.valid) {
         out.ok = true; out.code = ""; out.release = tries[i][0]; out.name = tries[i][1];
         return out;
      }
   }
   return out;
}

// El refinado en el archivo de ESA, con los nombres de columna de VizieR (entre comillas: se respetan mayusculas)
// (F2, 22-oct-2026) `withDistances` (opcional; sin el, la consulta de siempre): + Bailer-Jones de external.gaiaedr3_distance.
function cshRefineAdqlEsa(ra, dec, radiusDeg, withDistances) {
   // (SIN uniones: con la de las distancias de Bailer-Jones o la de A0, el servicio sincrono de ESA da «Job timeout» —HTTP
   // 408, medido el 15-oct—. Asi no trae rgeo ni A0: las distancias salen de la paralaje con su error, y se dice)
   // (F2: el 22-oct la union con external.gaiaedr3_distance SI contesto —M 13 a 0,1°, 818 filas en 17 s—: va en la cadena
   // completa de cpStarfieldRefine como un servidor mas; si da 408, se pasa al siguiente y al final a esta, sin union)
   var bj = (withDistances === true);
   return "SELECT g.ra AS \"RA_ICRS\",g.dec AS \"DE_ICRS\",g.parallax AS \"Plx\",g.parallax_error AS \"e_Plx\",g.ruwe AS \"RUWE\"," +
          (bj ? "d.r_med_geo AS \"rgeo\",d.r_lo_geo AS \"b_rgeo\",d.r_hi_geo AS \"B_rgeo\"," : "") +
          "g.source_id AS \"Source\",g.radial_velocity AS \"RV\",g.radial_velocity_error AS \"e_RV\"," + ((typeof cshRvColsOn !== "function" || cshRvColsOn()) ? "g.grvs_mag AS \"GRVSmag\",g.rv_template_teff AS \"RVtempTeff\"," : "") + "g.teff_gspphot AS \"Teff\",g.logg_gspphot AS \"logg\",g.mh_gspphot AS \"[Fe/H]\",g.ag_gspphot AS \"AG\"," +
          "g.ebpminrp_gspphot AS \"E(BP-RP)\",g.non_single_star AS \"NSS\",g.pmra_error AS \"e_pmRA\",g.pmdec_error AS \"e_pmDE\" FROM gaiadr3.gaia_source AS g " +
          (bj ? "LEFT JOIN external.gaiaedr3_distance AS d ON g.source_id=d.source_id " : "") +
          "WHERE 1=CONTAINS(POINT('ICRS',g.ra,g.dec),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND g.parallax_over_error>" + CP_SF.MIN_PLX_SNR;
}

// (F2, 22-oct-2026) El refinado en GAVO (Heidelberg, `dc.g-vo.org/tap`): Gaia EDR3 «lite» + Bailer-Jones (gedr3dist.main),
// con los nombres de VizieR. EDR3 tiene la MISMA astrometria que DR3 (posicion, paralaje y su error, RUWE: DR3 no la
// rehizo), asi que casa estrella a estrella con la base local; NO trae RV, GSP-Phot, XP ni NSS de DR3 (quedan sin dato).
// Medido el 22-oct: M 13 a 0,1°, 818 filas en 1,5 s. (gaia.edr3lite no tiene parallax_over_error: se escribe el producto.)
// (2-nov-2026, Q4) + pmra_error y pmdec_error (medido ese día: gaia.edr3lite los tiene; los de EDR3 son los de DR3, misma astrometría).
var CSH_GAVO_TAP = "https://dc.g-vo.org/tap/sync";
function cshRefineAdqlGavo(ra, dec, radiusDeg) {
   return "SELECT g.ra AS \"RA_ICRS\",g.dec AS \"DE_ICRS\",g.parallax AS \"Plx\",g.parallax_error AS \"e_Plx\",g.ruwe AS \"RUWE\"," +
          "d.r_med_geo AS \"rgeo\",d.r_lo_geo AS \"b_rgeo\",d.r_hi_geo AS \"B_rgeo\",g.source_id AS \"Source\",g.pmra_error AS \"e_pmRA\",g.pmdec_error AS \"e_pmDE\" " +
          "FROM gaia.edr3lite AS g LEFT JOIN gedr3dist.main AS d ON g.source_id=d.source_id " +
          "WHERE 1=CONTAINS(POINT('ICRS',g.ra,g.dec),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND g.parallax>" + CP_SF.MIN_PLX_SNR + "*g.parallax_error";
}

// (F2, 22-oct-2026) El refinado en el espejo de VizieR de CfA por ASU (asu-tsv; su TAP no es el de CDS): I/355/gaiadr3 y
// I/352/gedr3dis en UNA peticion (dos tablas seguidas en el TSV; las une `cshRefineAsuToCsv` por Source). La tabla de
// distancias no se puede filtrar por paralaje: trae TODAS las fuentes del cono (M 13 a 0,1°: 24 954 filas), ordenadas
// del centro hacia fuera y cortadas en -out.max; en un campo grande las de fuera pueden quedar sin Bailer-Jones (se cuenta).
var CSH_CFA_ASU = "https://vizier.cfa.harvard.edu/viz-bin/asu-tsv";
// (29-oct-2026) El espejo de IDIA (Sudafrica) sirve las dos tablas en la misma peticion (medido: CDS caido, CfA mudo 20-40 s)
var CSH_IDIA_ASU = "https://vizier.idia.ac.za/viz-bin/asu-tsv";
// (30-oct, decision D: GRVSmag y RVtempTeff, para la correccion de la RV: cshRvCorrect, csh_net.js. La cabecera las lleva siempre; sin la costura norvscols, tambien la peticion)
// (2-nov-2026, Q4) + e_pmRA y e_pmDE al final (los errores del movimiento propio: csh_starfield.js cpSfRefineApply)
var CSH_REFINE_COLS = ["RA_ICRS", "DE_ICRS", "Plx", "e_Plx", "RUWE", "rgeo", "b_rgeo", "B_rgeo", "Source", "RV", "e_RV", "GRVSmag", "RVtempTeff", "Teff", "logg", "[Fe/H]", "AG", "E(BP-RP)", "XPsamp", "A0", "NSS", "e_pmRA", "e_pmDE"];
function cshRefineAsuUrl(ra, dec, radiusDeg, maxRows, base) {
   var want = (typeof cshRvColsOn !== "function" || cshRvColsOn()) ? CSH_REFINE_COLS : CSH_REFINE_COLS.filter(function(c) { return c !== "GRVSmag" && c !== "RVtempTeff"; });
   var out = want.join(",").replace(/\[/g, "%5B").replace(/\]/g, "%5D");
   return (base || CSH_CFA_ASU) + "?-source=I/355/gaiadr3%20I/352/gedr3dis&-c=" + ra.toFixed(6) + (dec >= 0 ? "%2B" : "") + dec.toFixed(6) +
          "&-c.rd=" + radiusDeg.toFixed(5) + "&-out.max=" + (maxRows || 200000) + "&-out=" + out + "&RPlx=%3E" + CP_SF.MIN_PLX_SNR;
}
// El TSV de ASU (varias tablas: comentarios «#», cabecera, unidades, guiones, filas) -> el MISMO CSV que da TAPVizieR con
// cpSfRefineAdql (cabecera CSH_REFINE_COLS), para leerlo con cpSfRefineRows sin otro camino.
// -> { ok, csv, rows (filas de Gaia), withDist (de ellas, con rgeo), distRows, why }
// (Cabra3D, 22-oct-2026, tarde) Los tres bucles llaman a `cshYield` (csh_net.js: no hace nada sin CSH_NET_PUMP): la tabla de
// distancias del espejo trae TODAS las fuentes del cono (hasta -out.max = 200 000 filas) y en Cabra3D esto corre dentro del
// paso de red EN VIVO. Y la ultima conversion se recuerda (`CSH_ASU_LAST`): el juicio de la cadena (cshRefineJudge) y la
// lectura (cshRefineChain) la piden con el MISMO texto y antes se hacia dos veces. Mismo resultado.
var CSH_ASU_LAST = null;
function cshRefineAsuToCsv(text) {
   if (CSH_ASU_LAST !== null && CSH_ASU_LAST.text === text) return CSH_ASU_LAST.out;
   var out = { ok: false, csv: "", rows: 0, withDist: 0, distRows: 0, why: "" }, yieldOk = (typeof cshYield === "function");
   var L = String(text || "").split("\n"), tables = [], cur = null, fresh = true, i, c;
   for (i = 0; i < L.length; ++i) {
      if (yieldOk && (i & 2047) === 2047) cshYield();
      var s = L[i].replace(/\r$/, "");
      if (s.length === 0 || s.charAt(0) === "#") { fresh = true; continue; }
      var cells = s.split("\t");
      if (fresh) { cur = { cols: cells.map(function(x) { return x.replace(/^\s+|\s+$/g, ""); }), rows: [] }; tables.push(cur); fresh = false; continue; }
      if (/^[-\t ]+$/.test(s)) continue;                                        // la fila de guiones
      cur.rows.push(cells);
   }
   var gaia = null, dist = null;
   for (i = 0; i < tables.length; ++i) {
      var cols = tables[i].cols;
      if (cols.indexOf("Plx") >= 0 && cols.indexOf("RA_ICRS") >= 0 && !gaia) gaia = tables[i];
      else if (cols.indexOf("rgeo") >= 0 && cols.indexOf("Source") >= 0 && !dist) dist = tables[i];
   }
   if (!gaia) { out.why = "no Gaia DR3 table in the answer"; return out; }
   function idx(t, name) { return t.cols.indexOf(name); }
   var bj = {};
   if (dist) {
      var dS = idx(dist, "Source"), dR = idx(dist, "rgeo"), dLo = idx(dist, "b_rgeo"), dHi = idx(dist, "B_rgeo");
      for (i = 0; i < dist.rows.length; ++i) {
         if (yieldOk && (i & 2047) === 2047) cshYield();
         var sid = String(dist.rows[i][dS] || "").replace(/\s+/g, "");
         if (!/^\d{6,20}$/.test(sid)) continue;                                   // (la fila de unidades)
         bj[sid] = [dist.rows[i][dR], dLo >= 0 ? dist.rows[i][dLo] : "", dHi >= 0 ? dist.rows[i][dHi] : ""];
         ++out.distRows;
      }
   }
   var lines = [CSH_REFINE_COLS.join(",")], gi = [];
   for (c = 0; c < CSH_REFINE_COLS.length; ++c) gi.push(idx(gaia, CSH_REFINE_COLS[c]));
   var iS = idx(gaia, "Source"), iRa = idx(gaia, "RA_ICRS");
   for (i = 0; i < gaia.rows.length; ++i) {
      if (yieldOk && (i & 1023) === 1023) cshYield();
      var row = gaia.rows[i];
      if (!isFinite(Number(String(row[iRa] || "").replace(/^\s+|\s+$/g, ""))) || String(row[iRa]).replace(/\s+/g, "") === "") continue;   // (la de unidades)
      var id = String(row[iS] || "").replace(/\s+/g, ""), d = bj[id] || null, cells2 = [];
      for (c = 0; c < CSH_REFINE_COLS.length; ++c) {
         var name = CSH_REFINE_COLS[c], v = "";
         if (name === "rgeo" || name === "b_rgeo" || name === "B_rgeo") v = d ? d[name === "rgeo" ? 0 : name === "b_rgeo" ? 1 : 2] : "";
         else if (gi[c] >= 0) v = row[gi[c]];
         cells2.push(String(v === undefined ? "" : v).replace(/^\s+|\s+$/g, "").replace(/,/g, ""));
      }
      if (d) ++out.withDist;
      lines.push(cells2.join(","));
      ++out.rows;
   }
   out.csv = lines.join("\n") + "\n";
   out.ok = true;
   CSH_ASU_LAST = { text: text, out: out };
   return out;
}

// SIN BASE LOCAL: los mismos campos de la base de PixInsight, pedidos a VizieR (I/355/gaiadr3). Las banderas de calidad
// (tramos oro/plata/bronce de la paralaje y del movimiento) se rehacen con los ERRORES de verdad y las mismas cotas
// (CP_SF.PLX_ERR_MAX / PM_ERR_MAX): el motor no distingue de donde vino la fila. Tope de diseño: G < 19 y 60 000 filas
// (una consulta mayor tarda minutos en VizieR).
var CSH_GAIA_NET = { MAG: 19, MAX: 60000 };

var CSH_ESA_TAP = "https://gea.esac.esa.int/tap-server/tap/sync";

function cshGaiaFlags(ePlx, ePmRa, ePmDe, hasPm, hasBp, hasRp) {
   var f = 0, T = CP_SF.PLX_ERR_MAX, P = CP_SF.PM_ERR_MAX;
   if (!hasPm) f |= CP_SF.FLAG_NO_PM;
   if (!hasBp) f |= CP_SF.FLAG_NO_BP;
   if (!hasRp) f |= CP_SF.FLAG_NO_RP;
   if (hasPm && ePlx !== null) f |= (ePlx <= T.gold) ? CP_SF.FLAG_GOLD_PARX : (ePlx <= T.silver) ? CP_SF.FLAG_SILVER_PARX : (ePlx <= T.bronze) ? CP_SF.FLAG_BRONZE_PARX : 0;
   if (hasPm && ePmRa !== null) f |= (ePmRa <= P.gold) ? CP_SF.FLAG_GOLD_PMRA : (ePmRa <= P.silver) ? CP_SF.FLAG_SILVER_PMRA : (ePmRa <= P.bronze) ? CP_SF.FLAG_BRONZE_PMRA : 0;
   if (hasPm && ePmDe !== null) f |= (ePmDe <= P.gold) ? CP_SF.FLAG_GOLD_PMDEC : (ePmDe <= P.silver) ? CP_SF.FLAG_SILVER_PMDEC : (ePmDe <= P.bronze) ? CP_SF.FLAG_BRONZE_PMDEC : 0;
   return f >>> 0;
}

function cshGaiaNetSearch(field, magLimit, maxStars, opts) {
   var o = opts || {}, t0 = Date.now(), out = { ok: false, code: "no-network", rows: [], ms: 0, truncated: false, net: null };
   var adql = "SELECT TOP " + maxStars + " RA_ICRS,DE_ICRS,Plx,e_Plx,pmRA,e_pmRA,pmDE,e_pmDE,Gmag,BPmag,RPmag FROM \"I/355/gaiadr3\" WHERE 1=CONTAINS(POINT('ICRS',RA_ICRS,DE_ICRS),CIRCLE('ICRS'," +
              field.ra.toFixed(6) + "," + field.dec.toFixed(6) + "," + field.radiusDeg.toFixed(5) + ")) AND Gmag<" + magLimit + " ORDER BY Gmag";
   // primero VizieR; si no contesta, el ARCHIVO DE ESA (el mismo DR3, otras columnas): medido el 15-oct, VizieR dio
   // HTTP 503 durante mas de una hora y el de ESA contestaba
   var adqlEsa = "SELECT TOP " + maxStars + " ra,dec,parallax,parallax_error,pmra,pmra_error,pmdec,pmdec_error,phot_g_mean_mag,phot_bp_mean_mag,phot_rp_mean_mag FROM gaiadr3.gaia_source WHERE 1=CONTAINS(POINT('ICRS',ra,dec),CIRCLE('ICRS'," +
                 field.ra.toFixed(6) + "," + field.dec.toFixed(6) + "," + field.radiusDeg.toFixed(5) + ")) AND phot_g_mean_mag<" + magLimit + " ORDER BY phot_g_mean_mag";
   var tries = [{ url: cpSfTapUrl(CP_SF_VIZIER_TAP, adql), col: { ra: "RA_ICRS", de: "DE_ICRS", plx: "Plx", eplx: "e_Plx", pmra: "pmRA", epmra: "e_pmRA", pmde: "pmDE", epmde: "e_pmDE", g: "Gmag", bp: "BPmag", rp: "RPmag" } },
                { url: cpSfTapUrl(CSH_ESA_TAP, adqlEsa), col: { ra: "ra", de: "dec", plx: "parallax", eplx: "parallax_error", pmra: "pmra", epmra: "pmra_error", pmde: "pmdec", epmde: "pmdec_error", g: "phot_g_mean_mag", bp: "phot_bp_mean_mag", rp: "phot_rp_mean_mag" } }];
   var t = null, C = null, fails = [];
   for (var k = 0; k < tries.length && !t; ++k) {
      var r = cpSfHttpText(tries[k].url, { timeoutS: o.httpTimeoutS || 90, onProgress: o.onProgress ? function(ms) { try { o.onProgress("gaia-net", { elapsedMs: ms }); } catch (e) {} } : null });
      if (!r.ok) { fails.push(r.net); continue; }
      if (!cpSfLooksLikeCsv(r.text, tries[k].col.ra)) { var nb = cshNetFail(tries[k].url, { code: r.code }, false); nb.kind = "bad"; fails.push(nb); continue; }
      t = cpSfParseTable(r.text, ","); C = tries[k].col; out.server = cshNetServer(tries[k].url); out.tried = fails.slice();
   }
   out.ms = Date.now() - t0;
   if (!t) { out.net = fails[0]; out.netAll = fails; return out; }
   for (var i = 0; i < t.rows.length; ++i) {
      var q = t.rows[i], ra = cpSfNum(q[C.ra]), de = cpSfNum(q[C.de]);
      if (ra === null || de === null) continue;
      var plx = cpSfNum(q[C.plx]), pmra = cpSfNum(q[C.pmra]), pmde = cpSfNum(q[C.pmde]), g = cpSfNum(q[C.g]), bp = cpSfNum(q[C.bp]), rp = cpSfNum(q[C.rp]);
      var hasPm = (plx !== null && pmra !== null && pmde !== null);
      out.rows.push([ra, de, plx, pmra, pmde, g, bp, rp, cshGaiaFlags(cpSfNum(q[C.eplx]), cpSfNum(q[C.epmra]), cpSfNum(q[C.epmde]), hasPm, bp !== null, rp !== null), null]);
   }
   out.truncated = out.rows.length >= maxStars;
   out.ok = true; out.code = "";
   return out;
}

// La consulta por cono al proceso Gaia. Las filas son las del proceso tal cual:
// [ra, dec, paralaje, pmra, pmdec, G, BP, RP, banderas, flujo], de brillante a debil.
// Devuelve { ok, code, rows, ms, truncated }.
function cpSfGaiaSearch(release, ra, dec, radiusDeg, magLimit, maxStars) {
   var out = { ok: false, code: "gaia-failed", rows: [], ms: 0, truncated: false };
   var g = null;
   try { g = new Gaia; } catch (eG) { return out; }
   var t0 = Date.now();
   try {
      g.command = "search";
      g.dataRelease = release;
      g.centerRA = ra; g.centerDec = dec; g.radius = radiusDeg;
      g.magnitudeLow = -1.5; g.magnitudeHigh = magLimit;
      g.sourceLimit = maxStars;
      g.requiredFlags = 0; g.inclusionFlags = 0; g.exclusionFlags = 0;
      g.sortBy = Gaia.SortBy_G;
      g.generateTextOutput = false;
      g.generateBinaryOutput = false;
      try { g.verbosity = 0; } catch (eV) {}
      if (g.executeGlobal() === false) {
         out.ms = Date.now() - t0;
         return out;
      }
      out.rows = g.sources || [];
      try { out.truncated = (g.excessCount > 0); } catch (eX) {}
      out.ok = true; out.code = "";
      CSH_GAIA_LAST = { release: release, ra: ra, dec: dec, radiusDeg: radiusDeg, magLimit: magLimit, rows: out.rows, truncated: out.truncated, ms: Date.now() - t0 };
   } catch (e) {
      out.code = "gaia-failed";
   }
   out.ms = Date.now() - t0;
   return out;
}


// ---------------------------------------------------------------------------
// LA ULTIMA CONSULTA, PARA NO REPETIRLA
// ---------------------------------------------------------------------------
var CSH_GAIA_LAST = null;
var CSH_GAIA_SEARCHES = 0;            // cuantas veces se ha ido de verdad al proceso Gaia (las pruebas lo miran)
var cshGaiaSearchRaw = cpSfGaiaSearch;
cpSfGaiaSearch = function(release, ra, dec, radiusDeg, magLimit, maxStars) { ++CSH_GAIA_SEARCHES; return cshGaiaSearchRaw(release, ra, dec, radiusDeg, magLimit, maxStars); };
// Separacion angular en grados (haversine; csh_gaia no depende del motor del campo de estrellas)
function cshSepDeg(ra1, de1, ra2, de2) {
   var k = Math.PI / 180, a = Math.sin((de2 - de1) * k / 2), b = Math.sin((ra2 - ra1) * k / 2);
   return 2 * Math.asin(Math.min(1, Math.sqrt(a * a + Math.cos(de1 * k) * Math.cos(de2 * k) * b * b))) / k;
}
// ¿Cabe el cono (ra, dec, r, G < gMax) en la ultima consulta? -> sus filas (de la ultima), o null
// (con `polygon` —las esquinas del encuadre, [[ra, dec] x4]—: basta con que las esquinas caigan dentro del cono de la ultima
// consulta; es lo que se usa del encuadre. Medido el 15-oct: el centro y el radio de CabraComposition difieren un poco de
// los del motor del campo para la MISMA foto, y la comparacion de circulos fallaba aunque el encuadre estuviera cubierto)
function cshGaiaLastCovers(ra, dec, radiusDeg, gMax, polygon) {
   var L = CSH_GAIA_LAST;
   if (!L || L.truncated || !L.rows || !(gMax <= L.magLimit + 1e-9)) return null;
   if (polygon && polygon.length >= 3) {
      for (var k = 0; k < polygon.length; ++k) if (!(cshSepDeg(polygon[k][0], polygon[k][1], L.ra, L.dec) <= L.radiusDeg + 1e-6)) return null;
      return L;
   }
   var sep = cshSepDeg(ra, dec, L.ra, L.dec);
   if (!(sep + radiusDeg <= L.radiusDeg + 1e-6)) return null;
   return L;
}
// (la base guarda «sin dato» como 0 o NaN segun el campo: un 0 exacto en paralaje/pm/BP/RP es «sin dato»)
function cshLocNum(v) { var x = Number(v); return (isFinite(x) && x !== 0) ? x : null; }
// Las filas del proceso como objetos { ra, dec, plx, pmra, pmdec, g, bp, rp } (las de G < gMax).
function cshGaiaRowsAsObjects(rows, gMax) {
   var out = [];
   for (var i = 0; i < rows.length; ++i) {
      var r = rows[i], g = cshLocNum(r[5]);
      if (gMax !== undefined && !(g !== null && g < gMax)) continue;
      out.push({ ra: Number(r[0]), dec: Number(r[1]), plx: cshLocNum(r[2]), pmra: cshLocNum(r[3]), pmdec: cshLocNum(r[4]), g: g, bp: cshLocNum(r[6]), rp: cshLocNum(r[7]) });
   }
   return out;
}
// El encuadre entero desde la base local (lo que pide CabraComposition: `opts.gaiaLocal`).
// -> { ok, rows: [objetos], ms, truncated, release, reused } | { ok: false, why }
var CSH_GAIA_LOCAL_MAX = 200000;      // diseño: tope de fuentes por consulta (un campo de 1,5° a G<19 cerca del plano)
function cshGaiaLocalField(field, gMax) {
   gMax = gMax || 19;
   var L = cshGaiaLastCovers(field.ra, field.dec, field.radiusDeg, gMax, field.polygon);
   if (L) {
      var t0 = Date.now(), rows = [], all = cshGaiaRowsAsObjects(L.rows, gMax);
      for (var i = 0; i < all.length; ++i) if (cshSepDeg(all[i].ra, all[i].dec, field.ra, field.dec) <= field.radiusDeg) rows.push(all[i]);
      return { ok: true, rows: rows, ms: Date.now() - t0, truncated: false, release: (L.release === Gaia.DataRelease_3_SP) ? "DR3/SP" : "DR3", reused: true };
   }
   var src = cpSfGaiaSource();
   if (!src.ok) return { ok: false, why: "not installed in this PixInsight", name: "" };
   var q = cpSfGaiaSearch(src.release, field.ra, field.dec, field.radiusDeg, gMax, CSH_GAIA_LOCAL_MAX);
   if (!q.ok) return { ok: false, why: "the Gaia process did not finish the search", name: src.name };
   return { ok: true, rows: cshGaiaRowsAsObjects(q.rows, undefined), ms: q.ms, truncated: q.truncated, release: src.name, name: src.name, reused: false };
}
