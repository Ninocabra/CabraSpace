#engine v8
// ============================================================================
// Cabra3D.js — DISTANCIAS, 3D Y MAQUINA DEL TIEMPO de una foto astronomica (CabraScripts, 14-oct-2026)
// ----------------------------------------------------------------------------
// Script PJSR independiente. Nace del panel «Distances» de CabraPilot (sin su diagrama HR, que vive en CabraStars)
// (rama integracion-1410c), COPIADO y adaptado (src/engine, src/ui: cada fichero dice de
// donde viene), y añade la MAQUINA DEL TIEMPO (src/tm). No depende de CabraPilot en
// tiempo de ejecucion. Uso y estado: README.md, HANDOFF.md; la fisica: docs/.
//
//   src/i18n     castellano y tooltips (lo copiado de CabraPilot + lo propio)
//   src/host     lo que en CabraPilot ponia el resto del programa (minimo) y resolver la imagen
//   src/engine   el AVI (el motor de distancias de CabraPilot —Gaia local, cumulos, VizieR, SIMBAD— vive desde el 15-oct
//                en ../CabraShared, comun con CabraStars y CabraStarAnalysis)
//   src/ui       la estetica Atlas, el panel, sus transiciones, el vuelo, la pantalla completa, la foto y el dialogo
//   src/tm       la maquina del tiempo: la fisica (pura), la red, las filas, el dibujo y el video
//   src/data     los catalogos empaquetados de cumulos, secuencia principal y nebulosas (con su PROVENANCE)
//
// Para incluirlo sin abrir el dialogo (las pruebas):  #define CP_NO_MAIN 1  y  #include ".../Cabra3D.js"
// ES5 salvo las clases de widget (V8).
// ============================================================================

#feature-id    FieldDepth3D : CabraSpace > FieldDepth3D
#feature-icon  @script_icons_dir/FieldDepth3D.svg
#feature-info  FieldDepth3D (formerly Cabra3D): the distances of everything in your photo, in real 3D, with flights, video \
               and a time machine (proper motions and radial velocities of Gaia DR3). CabraSpace project.

#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/UndoFlag.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FontFamily.jsh>
#include <pjsr/Interpolation.jsh>
#include <pjsr/ResizeMode.jsh>
#include <pjsr/PenStyle.jsh>
#include <pjsr/PenCap.jsh>      // (26-oct-2026: PenCap_Flat, para el anillo a trozos de lo debil: sin ella la pluma lleva la tapa cuadrada y los huecos se comen medio ancho de pluma por cada lado)
#include <pjsr/RBFType.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/ImageOp.jsh>
#include <pjsr/CompositionOp.jsh>
#define Align_Expand  0
#define Align_Left    1
#define Align_Top     1
#define Align_Right   2
#define Align_Bottom  2
#define Align_Center  3
#define Align_Default 0

// La libreria ImageSolver en modo LIBRERIA (aporta ImageSolver, AstrometricMetadata, ImageSolverDialog sin ejecutar su
// main). Igual que CabraPilot.js. SETTINGS_MODULE tiene que ser un LITERAL.
// (6-nov-2026, revision PTeam CPD) SETTINGS_MODULE propio del producto: los ajustes de catalogo que la libreria guarda
// (AstronomicalCatalogs.js, AstrometricMetadata.js de pjsr/astrometry) no se mezclan con los de otros scripts. La
// configuracion del solver sigue siendo la de ImageSolver (SOLVER_SETTINGS_MODULE, la fija ImageSolver.js). STAR_CSV_FILE
// ya no se define: ImageSolver 6.6 no usa esa macro (ImageSolverEngine.js pone su propio fichero temporal).
#define SETTINGS_MODULE "FieldDepth3D_ImageSolver"
#define USE_SOLVER_LIBRARY
#include <../src/scripts/ImageSolver/ImageSolver.js>
#undef USE_SOLVER_LIBRARY

// (30-oct-2026) CP_TITLE es el nombre que se ve (antes Cabra3D); la clave de Settings sigue siendo CP_SETTINGS_PREFIX = "Cabra3D"
#define CP_TITLE   "FieldDepth3D"
#define C3_VERSION "1.0.4"
#ifndef CP_NO_MAIN
#define CP_NO_MAIN 0
#endif

#include "src/i18n/from_cabrapilot.jsh"
#include "src/i18n/cabra3d.jsh"
// CabraShared (la biblioteca comun de CabraScripts: motor del campo de estrellas, red, Gaia, astrometria, polvo, Atlas)
#include "CabraShared/csh_i18n.js"
#include "CabraShared/csh_atlas.js"
#include "CabraShared/csh_net.js"
#include "CabraShared/csh_vizier.js"       // (29-oct-2026) el motor de VizieR por los espejos ASU, uno para todos (docs/motor-vizier-unico.md)
#include "CabraShared/csh_batch.js"         // (29-oct-2026) el lote: varias descargas a la vez, para todos los scripts
// (22-oct-2026) el juicio comun de «esto no es la tabla» (HTML, VOTable de error, vacio) para el afinado en cadena, como en
// CabraStars y CabraStarAnalysis (CabraShared/CHANGELOG.md F2.1 y F2.3); Cabra3D no usa sus cortacircuitos
#include "CabraShared/csh_netfail.js"
#include "CabraShared/csh_astrometry.js"
#include "src/host/host.js"
#include "src/ui/atlas.js"
#include "src/host/host_copied.js"
#include "src/host/solve.js"
#include "CabraShared/csh_starfield.js"
#include "CabraShared/csh_view.js"
#include "CabraShared/csh_gaia.js"
#include "CabraShared/csh_thirdparty.js"   // (3-nov-2026, CPD C8) Baumgardt y las nebulosas de Sharpless: se bajan la primera vez (no van en el paquete)
#include "CabraShared/csh_starfield_run.js"
#include "CabraShared/csh_depth.js"
#include "CabraShared/csh_depth_run.js"
#include "CabraShared/csh_close.js"
#include "CabraShared/help/csh_help.js"      // (2-nov-2026) el boton «?» de la ayuda PIDoc (FieldDepth3D / FieldDepth3D_es), comun a todos
#include "CabraShared/csh_pills.js"        // (30-oct-2026) el conmutador «Real photo | Stars» de dos pildoras, comun a los cuatro scripts
#include "CabraShared/csh_viewpref.js"      // (30-oct-2026) y su eleccion recordada entre sesiones (arranca en «Real photo»), comun a los cuatro
#include "CabraShared/csh_busy.js"          // (29-oct-2026) el relojito de «pensando» sobre la foto 2D, para todos los scripts
#include "CabraShared/csh_clock.js"
#include "CabraShared/csh_ffmpeg.js"       // (3-nov-2026, CPD C3) ffmpeg solo si el usuario lo elige: AVI / el que elijo / buscalo tu
#include "src/engine/video_avi.js"
#include "src/ui/splitter.js"
#include "src/ui/starfield_view.js"
#include "src/ui/starfield_panel.js"
#include "CabraShared/csh_web.js"          // (3-nov-2026, CPD C10) los enlaces se abren en el navegador que trae PixInsight (Dialog.openBrowser); Aladin (WebGL) y la reserva, en el del sistema
#include "CabraShared/csh_link.js"         // (26-oct-2026) abrir SIMBAD: la parte pura, compartida
#include "CabraShared/csh_hipnames.js"     // (27-oct-2026) el catalogo Hipparcos y sus nombres (los usa tm/sky_catalog.js), compartido
#include "src/ui/star_link.js"                  // (26-oct-2026) el nombre de la ficha, enlace a SIMBAD
#include "src/ui/starfield_nebula.js"
#include "src/ui/starfield_photostars.js"
#include "src/ui/photo_offsets.js"
#include "src/ui/photo_stars_overlay.js"
#include "src/ui/starfield_fullscreen.js"
#include "src/ui/starfield_flight.js"
#include "src/ui/starfield_flight_paint.js"
#include "src/ui/starfield_flight_ui.js"
#include "src/ui/flight_editor.js"
#include "src/tm/timemachine.js"
// (23-oct-2026, tarde: las «órbitas galácticas» del campo usan el potencial de CabraShared —MilkyWayPotential2022—, uno solo)
#include "CabraShared/csh_galdyn.js"
#include "src/tm/galaxy.js"
#include "src/tm/skyfrom.js"
#include "src/tm/sky_catalog.js"
#include "CabraShared/csh_dust.js"
#include "CabraShared/csh_mainseq.js"       // (28-oct-2026, tarde) la UNICA conversion de Mamajek DR2 -> DR3 (la usa tm/dust_run.js c3DustIntrinsic; antes tenia la suya)
#include "src/tm/timemachine_run.js"
#include "src/tm/dust_run.js"
#include "src/tm/timeruler.js"
#include "src/tm/timemachine_ui.js"
#include "src/tm/tm_incoming.js"
#include "src/tm/hud.js"
#include "src/tm/dust_ui.js"
#include "src/tm/sky_view.js"
#include "src/tm/skyfrom_ui.js"
#include "src/tm/timeclock.js"
#include "src/tm/timemachine_video.js"
#include "src/tm/names_simbad.js"
#include "src/tm/netstatus.js"
#include "src/ui/groups.js"
#include "src/ui/photo_view.js"
// (23-oct-2026) LA VISTA GALACTICA del 3D (Campo | Galaxia: desde arriba, de canto, 3D), con la maquina del tiempo y el video: la dinamica
// y el mapa de CabraComposition, subidos a CabraShared (csh_galdyn, csh_galaxy, csh_galaxy_i18n, csh_galaxy_paint); tm/galaxy_view.js
// envuelve los metodos del panel y va DESPUES de todo lo que los define
#include "CabraShared/csh_galdyn.js"
#include "CabraShared/csh_galaxy.js"
#include "CabraShared/csh_galaxy_i18n.js"
// (24-oct-2026, V7f) el POLVO de la Galaxia entera: las rejillas (generadas) y su modulo puro; lo pinta csh_galaxy_paint.js con V.dust
#include "CabraShared/data/csh_galaxy_dust_grid.js"
#include "CabraShared/csh_galaxy_dust.js"
#include "CabraShared/csh_galaxy_paint.js"
#include "src/tm/galaxy_view.js"
#include "src/tm/galaxy_card.js"                // (26-oct-2026) lo propio de la Galaxia en la ficha de la estrella (posicion y orbita)
// (26-oct-2026) el reloj D en el PANEL en vivo (Campo y Galaxia) y los VUELOS por la Galaxia: envuelven lo de arriba, van despues
#include "src/tm/timeclock_panel.js"
#include "src/tm/galaxy_flight.js"
#include "src/ui/dialog.js"
#include "src/ui/photo_overlay_toggle.js"       // (26-oct-2026) el boton de las estrellas de la foto (extiende C3MainDialog: va despues de el)

// (Block G, 20-oct-2026) Cabra3D enseña SOLO lo que la foto alcanza: mide su profundidad y pide a los catalogos esa
// magnitud (CabraShared/csh_depth*.js). Los demas scripts no lo encienden.
CSH_DEPTH_ON = true;
// (22-oct-2026) El primer fotograma, antes: al abrir el 3D, las estrellas brillantes primero y el campo entero despues, sin parar la
// interfaz (ui/starfield_panel.js, CP_SFUI_PROGRESSIVE). Las pruebas sin pantalla siguen leyendo todo de una vez (c3_perf lo enciende).
CP_SFUI_PROGRESSIVE = !CP_NO_MAIN;

function c3Main() {
   cshNetLiveOn();                     // (30-oct-2026) las memorias de red en disco de csh_net.js: solo el script de verdad, no las pruebas
   try { cpLoadLang(); } catch (e) {}
   var d = new C3MainDialog();
   // (23-oct-2026, tarde, costura de pruebas: tests/c3_gx_real.js recorre el camino REAL —este main, lo recordado, la red en vivo— y necesita
   // el dialogo para pulsar sus botones por sus manejadores. Sin la global, nada: el main de siempre)
   if (typeof C3_MAIN_HOOK === "function") { try { C3_MAIN_HOOK(d); } catch (eH) {} }
   try { d.execute(); } finally { d.cleanup(); }
}

if (!CP_NO_MAIN) c3Main();
