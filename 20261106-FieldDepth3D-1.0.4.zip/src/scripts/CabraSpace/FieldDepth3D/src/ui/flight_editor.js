// ============================================================================
// ui/flight_editor.js — EL EDITOR DE CAMARAS de «My flight» (Cabra3D, 20-oct-2026)
// ----------------------------------------------------------------------------
// Encargo de Nino: «cuando añado mis camaras no se cuales hay, no se si las puedo borrar… tiene que haber un visor/editor
// facil y directo que de algo de control». Antes: «＋» añadia la vista actual y «−» quitaba solo la ULTIMA; no se veia
// ninguna, no se podia borrar una de en medio, ni reordenar, ni sustituir.
//
// AHORA: el boton «☰ n» (ocupa el sitio del antiguo «−»: cero redundancia) despliega, bajo la fila del vuelo y DENTRO del
// grupo «FLIGHT AND VIDEO» (no es un dialogo modal), una lista con una fila por vista:
//
//     (1) [miniatura]  View 1                         ▲ ▼ ⟳ ✎ ✕
//                      0.0 s · turn 45° · tilt 20° · zoom ×1.3
//
//   · clic en la fila → el 3D VA a esa camara (con la transicion corta de siempre);
//   · ▲ ▼ reordenan · ⟳ sustituye la vista por la camara que tienes AHORA · ✎ (o doble clic en el nombre) la renombra ·
//     ✕ borra ESA vista;
//   · «Clear all» pide confirmacion con un segundo clic en el mismo sitio («Confirm?»); moverse fuera la cancela;
//   · la fila que coincide con la camara de ahora lleva un filete de oro («estas aqui»);
//   · la rueda desplaza la lista (3 filas a la vez; el alto NO cambia al añadir o quitar: el lienzo no se mueve).
// La miniatura es un fotograma de verdad de esa camara (16:9, 64×36 a escala 1), pintado con el mismo pintor del video
// (`cpFlPaintFrame`) y guardado en una cache por camara; se hace al refrescar, NUNCA en `onPaint`.
//
// Se guarda como siempre (`_flightSave`, propiedad FieldDepth3D:Flight; la vieja CabraPilot:Flight solo se lee). El JSON es compatible hacia atras: el nombre de
// una vista (`label`) solo se escribe si existe.
// Todo en pintado propio con GLIFOS DE TEXTO (sin SVG ni bitmaps cargados de fichero en `onPaint`, que ya hizo caer el
// programa una vez). Todo son metodos de `CPStarfieldDock`. ES5.
// ============================================================================

// H5 (21-oct-2026, revision de Nino: «pone 5 vistas y solo veo 3; la barra de 3 px no se ve; al pasar por un chip la fila
// cambia de texto; ⟳ y ✎ diminutos; la "s" de Duration descolocada; el numero dos veces»):
//   · bajo las filas, un PIE fijo (FOOT) que, si hay mas vistas que filas, dice «▾ 2 more» / «▴ 1 above» y se pulsa (pasa una
//     pagina); la ultima fila visible se FUNDE hacia abajo cuando hay mas debajo (y la primera hacia arriba si hay encima); la
//     barra de desplazamiento, mas ancha;
//   · la ayuda de un boton o de un chip va en el TOOLTIP de la lista (la fila ya no cambia de texto);
//   · ⟳ y ✎ se dibujan a la escala que iguala la altura de su TINTA a la de ▲ (medida en un bitmap al refrescar, nunca en
//     onPaint; `_flightEdGlyphScale`);
//   · el numero de vistas, en un solo sitio a la vez: con la lista abierta lo dice su cabecera y el boton es «☰»; plegada, «☰ 5»;
//   · «Duration» y su «s» sin el bloque de fondo de las etiquetas de ayuda, la «s» con su ancho.
// V10 (2.ª revision, 21-oct): fuera la barra de desplazamiento (con «▾ n more» eran dos caminos a lo mismo); ✎ y ⟳ DIBUJADOS
//   (`c3FlEdPencil`, `c3FlEdRefresh`): los de la letra eran trazos finos y palidos aun a la altura de ▲.
var C3_FLED = {
   VIS: 3,                           // filas visibles (fijo: añadir o quitar vistas no cambia el alto del grupo)
   HDR: 22, ROW: 44, THUMB_W: 64, THUMB_H: 36, PAD: 6, BTN: 22, GAP: 2, SCROLL: 6, CHIP: 20, FOOT: 18, FADE: 14,
   BTNS: ["up", "down", "replace", "rename", "delete"],
   GLYPH: { up: "▲", down: "▼", replace: "⟳", rename: "✎", "delete": "✕" },
   HINT: { up: "Move up", down: "Move down", replace: "Replace with the current camera", rename: "Rename", "delete": "Delete this view" },
   // la transicion con que se llega a la vista y la pausa en ella (chips de la segunda linea de la fila; un clic cambia al siguiente)
   TRANS_LABEL: { smooth: "Smooth", out: "Ease out", "in": "Ease in", linear: "Linear", slow: "Slow-mo" },
   TRANS_HINT: { smooth: "Smooth: flowing motion at constant speed, soft start and stop of the flight (the default)",
                 out: "Ease out: leaves fast and brakes softly as it arrives",
                 "in": "Ease in: leaves slowly and arrives fast",
                 linear: "Linear: constant speed along this leg",
                 slow: "Slow motion: this leg lasts 2.5 times longer, with a soft start and stop" },
   THUMB_CACHE: 24,                  // miniaturas guardadas como mucho
   // (cuanto se parece la camara de ahora a la de una vista para llamarla «la misma»)
   SAME_DEG: 0.6, SAME_ZOOM: 0.012, SAME_PIVOT: 0.004
};

// --- construir ----------------------------------------------------------------------------------------------------------
CPStarfieldDock.prototype._flightEdBuild = function() {
   var self = this, L = new Control(this.rowsBox);
   this.fl.ed = { open: false, shown: false, mounted: false, scroll: 0, hk: -1, hb: "", clear: false, thumbs: {}, order: [], P: null, Psig: "", edit: null, renaming: -1, tipSet: "", lastH: 0 };
   this.flList = L;
   cpApplyStyle(L, "background-color:transparent; border:none;");
   L.toolTip = cpTooltip("sf.flight.list");
   try { L.mouseTracking = true; } catch (e) {}
   L.onPaint = function() { if (cpQuiet()) return; self._flightEdPaint(); };
   L.onMousePress = function(x, y, button) { if (button === OPT_MOUSE_LEFT) self._flightEdPress(x, y); };
   L.onMouseDoubleClick = function(x, y, button) { if (button === OPT_MOUSE_LEFT) self._flightEdDouble(x, y); };
   L.onMouseMove = function(x, y) { self._flightEdMove(x, y); };
   L.onMouseWheel = function(x, y, delta) { self._flightEdWheel(delta); };
   L.onLeave = function() { self._flightEdMove(-1, -1); };
   cpSetControlVisible(L, false);
   // (H5) «Duration» y su «s»: sin el bloque de fondo de `cpStyleHint` (otro color que el cuerpo del grupo) y la «s» con su ancho,
   // pegada al campo. Se hace aqui porque `_flightBuild` llama a este constructor justo despues de crearlas.
   var hintCss = "background-color:transparent; color:" + CP_UI.textDim + "; border:none; font-size:10px;";
   try { cpApplyStyle(this.flDurLabel, hintCss); } catch (e1) {}
   try { cpApplyStyle(this.flDurUnit, hintCss); this.flDurUnit.textAlignment = TextAlign_Left | TextAlign_VertCenter; this.flDurUnit.setFixedWidth(cpUiPx(14, this.flDurUnit)); } catch (e2) {}
};
// Colgarla del cuerpo del grupo «FLIGHT AND VIDEO» (ui/groups.js lo arma DESPUES de los mandos): justo bajo la fila del
// vuelo. Si el grupo aun no existe no hace nada y se reintenta en el siguiente `_flightSync`.
CPStarfieldDock.prototype._flightEdMount = function() {
   var ed = this.fl.ed;
   if (ed.mounted || !this.c3Groups || !this.c3Groups.flight) return;
   var body = this.c3Groups.flight.body, ind = new HorizontalSizer;
   try { this.flList.parent = body; } catch (e) { return; }
   cpAddGap(ind, CP_ATLAS.space[3]);
   ind.add(this.flList, 100);
   try { body.sizer.insert(1, ind); } catch (e2) { body.sizer.add(ind); }
   ed.mounted = true;
};
// Lo que la lista pide al alto: fijo (cabecera + VIS filas + el pie), segun la escala.
CPStarfieldDock.prototype._flightEdHeight = function() {
   return Math.round((C3_FLED.HDR + C3_FLED.VIS * C3_FLED.ROW + C3_FLED.FOOT + 2) * cpUiScale(this.flList));
};
// (H5) LA TINTA de un glifo: alto en pixeles de lo que pinta `font` (bitmap negro, texto blanco, se cuentan las filas con tinta).
function c3FlEdInkH(font, glyph) { return c3FlEdInk(font, glyph).h; }
// (V10, 21-oct) EL LAPIZ, DIBUJADO: el glifo ✎ de la letra es un CONTORNO y se veia mas fino que ▲ ▼ ✕ aun a la misma altura.
// Un lapiz macizo en diagonal (cuerpo + punta), de alto `s` px (la tinta de ▲), centrado en (cx, cy), con el color `rgb`.
function c3FlEdPencil(g, cx, cy, s, rgb) {
   var k = 0.7071, w = 0.15, T = [-0.5, 0.5], S0 = [-0.27, 0.27], E0 = [0.40, -0.40];
   function p(a, b) { return new Point(cx + a * s, cy + b * s); }
   var pts = [p(T[0], T[1]), p(S0[0] + k * w, S0[1] + k * w), p(E0[0] + k * w, E0[1] + k * w), p(E0[0] - k * w, E0[1] - k * w), p(S0[0] - k * w, S0[1] - k * w)];
   g.pen = new Pen(0x00000000, 0); g.brush = new Brush(rgb); g.drawPolygon(pts);
   g.brush = new Brush(0x00000000);
}
// ⟳ DIBUJADO (V10): medido con `c3FlEdInkStats`, el ⟳ de la letra tambien es un trazo fino (brillo medio 163 frente a 223 de ▲
// y 255 de ✕; el ✎, 118). Un arco de 270° con el grosor de ✕ y su punta de flecha maciza.
function c3FlEdRefresh(g, cx, cy, s, rgb) {
   var r = 0.40 * s, lw = Math.max(2, 0.20 * s), a0 = -40, a1 = 220, pts = [], a, k = Math.PI / 180;
   for (a = a0; a <= a1 + 0.1; a += 10) pts.push(new Point(cx + r * Math.cos(a * k), cy + r * Math.sin(a * k)));
   g.brush = new Brush(0x00000000); g.pen = new Pen(rgb, lw); g.drawPolyline(pts);
   var e = a1 * k, ex = cx + r * Math.cos(e), ey = cy + r * Math.sin(e), tx = -Math.sin(e), ty = Math.cos(e), nx = Math.cos(e), ny = Math.sin(e), hl = 0.32 * s, hw = 0.26 * s;
   g.pen = new Pen(0x00000000, 0); g.brush = new Brush(rgb);
   g.drawPolygon([new Point(ex + tx * hl, ey + ty * hl), new Point(ex + nx * hw, ey + ny * hw), new Point(ex - nx * hw, ey - ny * hw)]);
   g.brush = new Brush(0x00000000);
}
// La tinta de lo que pinta `draw(g, w, h)` en blanco sobre negro (las pruebas comparan pesos): { h: alto, area: pixeles > 96,
// flux: suma de brillo/255 (la «cantidad de tinta»), mean: brillo medio de los pixeles con algo de tinta (> 32; un trazo fino y
// suavizado da medias bajas aunque ocupe muchos pixeles), solid: fraccion de esos pixeles casi llenos (> 200) }
function c3FlEdInkStats(w, h, draw) {
   var b = new Bitmap(w, h), g = new Graphics(b), y0 = -1, y1 = -1, area = 0, flux = 0, lit = 0, litSum = 0, full = 0, x, y;
   try { g.antialiasing = true; g.fillRect(new Rect(0, 0, w, h), new Brush(0xff000000)); draw(g, w, h); } finally { g.end(); }
   for (y = 0; y < h; ++y) {
      var row = 0;
      for (x = 0; x < w; ++x) { var v = (b.pixel(x, y) >> 16) & 255; flux += v / 255; if (v > 32) { ++lit; litSum += v; if (v > 200) ++full; } if (v > 96) ++row; }
      if (row > 0) { area += row; if (y0 < 0) y0 = y; y1 = y; }
   }
   b.clear();
   return { h: (y0 < 0) ? 0 : y1 - y0 + 1, area: area, flux: flux, mean: lit > 0 ? litSum / lit : 0, solid: lit > 0 ? full / lit : 0 };
}
// { h: alto de la tinta, mid: centro de la tinta respecto de la linea base (negativo = por encima) }
function c3FlEdInk(font, glyph) {
   var w = Math.ceil(font.width(glyph) + 8), h = Math.ceil(font.ascent + font.descent + 8), b = new Bitmap(w, h), g = new Graphics(b), y0 = -1, y1 = -1, x, y, base = 4 + Math.round(font.ascent);
   try { g.fillRect(new Rect(0, 0, w, h), new Brush(0xff000000)); g.font = font; g.pen = new Pen(0xffffffff); g.drawText(4, base, glyph); } finally { g.end(); }
   for (y = 0; y < h; ++y) { var ink = false; for (x = 0; x < w && !ink; ++x) if (((b.pixel(x, y) >> 16) & 255) > 96) ink = true; if (ink) { if (y0 < 0) y0 = y; y1 = y; } }
   b.clear();
   return (y0 < 0) ? { h: 0, mid: 0 } : { h: y1 - y0 + 1, mid: (y0 + y1) / 2 - base };
}
// La escala de cada glifo de los botones para que su TINTA mida lo que la de ▲ (cache por tamaño de letra). Se calcula al
// refrescar (`_flightEdRefresh`), nunca al pintar; si aun no esta, el pintado usa 1.
CPStarfieldDock.prototype._flightEdGlyphScale = function(force) {
   var ed = this.fl.ed, sc = cpUiScale(this.flList), key = String(Math.round(CP_ATLAS.size.body * sc * 100));
   if (!force && ed.gs && ed.gsKey === key) return ed.gs;
   var out = {}, mids = {}, base = cpFont("text", CP_ATLAS.size.body * sc), ref = 0, i;
   try { ref = c3FlEdInkH(base, C3_FLED.GLYPH.up); } catch (e) { ref = 0; }
   for (i = 0; i < C3_FLED.BTNS.length; ++i) {
      var b = C3_FLED.BTNS[i], s = 1;
      if (ref > 0) {
         try {
            var h1 = c3FlEdInkH(base, C3_FLED.GLYPH[b]);
            if (h1 > 0 && h1 < 0.85 * ref) { s = Math.min(2.2, ref / h1); var h2 = c3FlEdInkH(cpFont("text", CP_ATLAS.size.body * sc * s), C3_FLED.GLYPH[b]); if (h2 > 0) s = Math.min(2.2, s * ref / h2); }
         } catch (e2) { s = 1; }
      }
      out[b] = (C3_FLED.GLYPH_FIX === true) ? 1 : s;
      // y el centro de su tinta, para centrarlo en su boton por la TINTA (no por la caja de la letra: ⟳ quedaba bajo)
      try { mids[b] = c3FlEdInk(cpFont("text", CP_ATLAS.size.body * sc * out[b]), C3_FLED.GLYPH[b]).mid; } catch (e3) { mids[b] = null; }
   }
   ed.gs = out; ed.gsMid = mids; ed.gsKey = key; ed.gsRef = ref;
   return out;
};
// ¿Se ve la lista? Lo llama `_flightSync` con «hay fila, en perspectiva y en My flight».
CPStarfieldDock.prototype._flightEdShow = function(want) {
   var ed = this.fl.ed;
   if (!ed) return;
   this._flightEdMount();
   var vis = (want === true) && ed.open && ed.mounted;
   if (vis) { var h = this._flightEdHeight(); if (h !== ed.lastH) { try { this.flList.setFixedHeight(h); ed.lastH = h; } catch (e) {} } }
   if (vis === ed.shown) return;
   ed.shown = vis;
   ed.clear = false;
   if (!vis) { this._flightEdRenameEnd(false); this._flightEdFree(); }
   cpSetControlVisible(this.flList, vis);
   try { this.rowsBox.adjustToContents(); } catch (e2) {}
   if (this.isFullScreen && this.isFullScreen()) { try { this._fsOptShow(); } catch (e3) {} }
};
// Tras cada `_flightSync`: el texto del boton, las miniaturas que falten y el repintado.
CPStarfieldDock.prototype._flightEdRefresh = function() {
   var ed = this.fl.ed, m = this._flightMine(), n = m ? m.keys.length : 0;
   // (H5: el numero en UN sitio: con la lista a la vista lo dice su cabecera; plegada, el boton)
   try { this.flEdit.text = "☰" + ((n > 0 && !ed.shown) ? " " + n : ""); } catch (e) {}
   var tip = cpTooltipText("sf.flight.edit") + " " + format(optT("Views now: %d."), n);
   if (ed.tipSet !== tip) { ed.tipSet = tip; try { this.flEdit.toolTip = cpWrapTooltip(tip); } catch (e2) {} }
   if (!ed.shown) return;
   try { this._flightEdGlyphScale(false); } catch (eG) {}
   this._flightEdClamp();
   try { this._flightEdThumbs(); } catch (e3) {}
   try { this.flList.repaint(); } catch (e4) {}
};
CPStarfieldDock.prototype.flightEditorToggle = function(open) {
   var ed = this.fl.ed;
   if (this.flightBusy()) return false;
   ed.open = (open === undefined) ? !ed.open : (open === true);
   this._flightSync();
   return ed.open;
};

// --- las miniaturas -----------------------------------------------------------------------------------------------------
CPStarfieldDock.prototype._flightEdFree = function() {
   var ed = this.fl.ed, k;
   for (k in ed.thumbs) { try { if (ed.thumbs[k]) ed.thumbs[k].clear(); } catch (e) {} }
   ed.thumbs = {}; ed.order = [];
   if (ed.P) { try { cpFlPaintClose(ed.P); } catch (e2) {} }
   ed.P = null; ed.Psig = "";
};
CPStarfieldDock.prototype._flightEdCleanup = function() {
   if (!this.fl || !this.fl.ed) return;
   try { this._flightEdFree(); } catch (e) {}
};
function c3FlEdCamSig(cam) {
   function r(x) { return Math.round(x * 1e4) / 1e4; }
   return [r(cam.yaw), r(cam.pitch), r(cam.zoom), r(cam.ox), r(cam.oy), r(cam.oz), r(cam.flat), r(cam.lens), r(cam.sx), r(cam.sy)].join(",");
}
// Una miniatura (un Bitmap propio) de la camara `cam`, con el pintor `P`. Un vuelo de dos claves iguales, sin efectos: el
// fotograma es la camara tal cual (los efectos del video —fundidos, rotulos, estelas— no van en una miniatura).
CPStarfieldDock.prototype._flightEdMakeThumb = function(P, cam, base) {
   var keys = [{ t: 0, cam: cam, layers: null, visit: -1, rest: false, label: "" }, { t: 1, cam: cam, layers: null, visit: -1, rest: false, label: "" }];
   var f = cpFlCopy(base, keys, { duration: 1, constantSpeed: false, loop: false, easeIn: 0, easeOut: 0,
                                   fx: { fadeIn: 0, fadeOut: 0, vignette: 0, trail: 0, glow: 0, title: false, counter: "none" } });
   var buf = cpFlPaintFrame(P, cpFlFrame(f, 0, { model: P.model, scale: P.scale, fps: 30 }));
   return new Bitmap(buf);
};
// Las que falten de las filas VISIBLES (no se pintan las 64 de golpe). Nunca en `onPaint`.
CPStarfieldDock.prototype._flightEdThumbs = function() {
   var ed = this.fl.ed, m = this._flightMine(), st = this.state;
   if (!ed.shown || !m || !st || this.flightBusy() || !this._flightAvailable()) return;
   var sc = cpUiScale(this.flList), tw = Math.round(C3_FLED.THUMB_W * sc), th = Math.round(C3_FLED.THUMB_H * sc);
   var psig = st.key + "|" + this.scaleMode + "|" + this.unit + "|" + tw + "x" + th, need = [], k, end = Math.min(m.keys.length, ed.scroll + C3_FLED.VIS);
   for (k = ed.scroll; k < end; ++k) { var sig = psig + "|" + c3FlEdCamSig(m.keys[k].cam); if (!Object.prototype.hasOwnProperty.call(ed.thumbs, sig)) need.push({ k: k, sig: sig }); }
   if (need.length === 0) return;
   if (ed.P === null || ed.Psig !== psig) {
      if (ed.P) { try { cpFlPaintClose(ed.P); } catch (e0) {} }
      ed.P = cpFlPaintOpen(this, tw, th, { hiRes: false, title: "" });
      ed.Psig = psig;
   }
   if (ed.P === null) return;
   for (var i = 0; i < need.length; ++i) {
      var bmp = null;
      try { bmp = this._flightEdMakeThumb(ed.P, m.keys[need[i].k].cam, m); } catch (e) { bmp = null; }      // (null = no se pudo: no se reintenta en bucle)
      ed.thumbs[need[i].sig] = bmp;
      ed.order.push(need[i].sig);
   }
   // la cache, acotada: fuera las mas antiguas
   while (ed.order.length > C3_FLED.THUMB_CACHE) { var old = ed.order.shift(); try { if (ed.thumbs[old]) ed.thumbs[old].clear(); } catch (e2) {} delete ed.thumbs[old]; }
};
CPStarfieldDock.prototype._flightEdThumbOf = function(key) {
   var ed = this.fl.ed, st = this.state;
   if (!st) return null;
   var sc = cpUiScale(this.flList), tw = Math.round(C3_FLED.THUMB_W * sc), th = Math.round(C3_FLED.THUMB_H * sc);
   var sig = st.key + "|" + this.scaleMode + "|" + this.unit + "|" + tw + "x" + th + "|" + c3FlEdCamSig(key.cam);
   return Object.prototype.hasOwnProperty.call(ed.thumbs, sig) ? ed.thumbs[sig] : null;
};

// --- la camara de AHORA ------------------------------------------------------------------------------------------------
// La camara del lienzo como camara de vuelo (null si no se puede: no hay perspectiva).
CPStarfieldDock.prototype._flightCurrentCam = function() {
   if (!this.lay || this.lay.kind !== "dist" || !this.lay.fit || this.lay.fit.mode !== "perspective") return null;
   return cpFlCamFromView(this.lay.fit.view, this.lay.model, this.lay.rect);
};
// ¿Cual de las vistas es la camara de ahora? (-1 ninguna). Aritmetica barata: se puede llamar al pintar.
CPStarfieldDock.prototype._flightEdCurrent = function() {
   var m = this._flightMine();
   if (!m || this.mode !== "dist" || this.pose !== "perspective") return -1;
   var best = -1, bestD = 1e9, i;
   for (i = 0; i < m.keys.length; ++i) {
      var c = m.keys[i].cam;
      var dy = Math.abs(((this.yaw - c.yaw) % 360 + 540) % 360 - 180);          // el giro por el camino corto (0 = igual)
      var dp = Math.abs(this.pitch - c.pitch), dz = Math.abs(Math.log(this.distZoom / c.zoom));
      var dx = Math.max(Math.abs(this.distOx - c.ox), Math.abs(this.distOy - c.oy)), dzz = Math.abs(this.distOz - c.oz) / CP_SV.DEPTH;
      if (dy <= C3_FLED.SAME_DEG && dp <= C3_FLED.SAME_DEG && dz <= C3_FLED.SAME_ZOOM && dx <= C3_FLED.SAME_PIVOT && dzz <= C3_FLED.SAME_PIVOT) {
         var d = dy + dp + dz * 50 + dx * 100 + dzz * 100;
         if (d < bestD) { bestD = d; best = i; }
      }
   }
   return best;
};

// --- las acciones (los metodos que usan la lista y las pruebas) ---------------------------------------------------------
// Aplicar un vuelo nuevo: se guarda con la imagen, se resincroniza y se dice.
CPStarfieldDock.prototype._flightEdCommit = function(next, msg, kind) {
   var st = this.state;
   st.myFlight = (next && next.keys.length > 0) ? next : null;
   if (!st.myFlight || st.myFlight.keys.length < 2) st.myFlightFixed = false;
   this._flightSave();
   this._flightSync();
   if (msg) this._flightSay(msg, kind || "ok");
   return true;
};
// Ir a la camara de la vista `i`: el 3D se coloca como ella (con la transicion corta de siempre).
CPStarfieldDock.prototype.flightGoTo = function(i) {
   var m = this._flightMine();
   if (!m || !(i >= 0 && i < m.keys.length) || this.flightBusy() || !this._flightAvailable() || !this.lay || this.lay.kind !== "dist") return false;
   var c = m.keys[i].cam, snap = this._animSnap();
   this._setDistView({ yaw: c.yaw, pitch: c.pitch, zoom: c.zoom, ox: c.ox, oy: c.oy, oz: c.oz });
   this._render();
   this._animGo(snap, { ms: CP_SV.ANIM_SHORT_MS });
   this._flightEdReveal(i);
   this._flightEdRepaint();
   this._flightSay(format(optT("Went to view %d"), i + 1), "ok");
   return true;
};
// ▲ (delta −1) y ▼ (delta +1): la vista `i` sube o baja un puesto. Los tiempos se reparten de nuevo y la duracion se queda.
CPStarfieldDock.prototype.flightMoveKey = function(i, delta) {
   var m = this._flightMine(), j = i + delta;
   if (!m || this.flightBusy() || !(i >= 0 && i < m.keys.length && j >= 0 && j < m.keys.length)) return false;
   var next = cpFlMoveKey(m, i, j, true);
   if (next === m) return false;
   this._flightEdCommit(next, format(optT("View %d is now view %d"), i + 1, j + 1), "ok");
   this._flightEdReveal(j);
   return true;
};
// ⟳: la vista `i` pasa a ser la camara que tienes AHORA (conserva su nombre y su sitio en la lista).
CPStarfieldDock.prototype.flightReplaceKey = function(i) {
   var m = this._flightMine(), cam = this._flightCurrentCam();
   if (!m || this.flightBusy() || !(i >= 0 && i < m.keys.length) || cam === null) return false;
   var next = cpFlReplaceKey(m, i, cam, this.state.myFlightFixed === true);
   this._flightEdCommit(next, format(optT("View %d replaced with the current camera"), i + 1), "ok");
   this._flightEdReveal(i);
   return true;
};
// ✕: borra ESA vista.
CPStarfieldDock.prototype.flightDeleteKey = function(i) {
   var m = this._flightMine();
   if (!m || this.flightBusy() || !(i >= 0 && i < m.keys.length)) return false;
   var next = cpFlRemoveKey(m, i, this.state.myFlightFixed === true);
   this._flightEdCommit(next, format(optT("View %d deleted"), i + 1) + ((next.keys.length === 1) ? ". " + optT("«My flight» needs at least two views: place the camera and press ＋.") : ""), "pending");
   return true;
};
// «Clear all» (la confirmacion es cosa de la lista: un segundo clic).
CPStarfieldDock.prototype.flightClearAll = function() {
   var m = this._flightMine();
   if (!m || this.flightBusy()) return false;
   this.fl.ed.scroll = 0;
   this._flightEdCommit(null, optT("All the views of «My flight» were deleted"), "pending");
   return true;
};
// ✎: el nombre de la vista ("" = el de fabrica, «View n»).
CPStarfieldDock.prototype.flightRenameKey = function(i, text) {
   var m = this._flightMine();
   if (!m || this.flightBusy() || !(i >= 0 && i < m.keys.length)) return false;
   var next = cpFlLabelKey(m, i, text);
   return this._flightEdCommit(next, null);
};
// El nombre que se enseña de la vista `i`.
CPStarfieldDock.prototype._flightEdName = function(i, key) {
   return (key && key.label && key.label.length > 0) ? key.label : format(optT("View %d"), i + 1);
};

// La TRANSICION con que se llega a la vista `i` (no la 1.ª: no se llega a ella) y la PAUSA en la vista. Entran en el JSON del vuelo
// (solo si no son las de siempre) y las usan igual ▶ Preview y ● Record (`cpFlAt`).
CPStarfieldDock.prototype.flightSetTransition = function(i, kind) {
   var m = this._flightMine();
   if (!m || this.flightBusy() || !(i >= 1 && i < m.keys.length) || CP_FL.TRANS.indexOf(kind) < 0) return false;
   var next = cpFlSetTrans(m, i, kind, this.state.myFlightFixed === true);
   return this._flightEdCommit(next, format(optT("Arriving at view %d: %s"), i + 1, optT(C3_FLED.TRANS_LABEL[kind])), "ok");
};
CPStarfieldDock.prototype.flightCycleTransition = function(i) {
   var m = this._flightMine();
   if (!m || !(i >= 1 && i < m.keys.length)) return false;
   return this.flightSetTransition(i, CP_FL.TRANS[(CP_FL.TRANS.indexOf(m.keys[i].trans) + 1) % CP_FL.TRANS.length]);
};
CPStarfieldDock.prototype.flightSetHold = function(i, seconds) {
   var m = this._flightMine();
   if (!m || this.flightBusy() || !(i >= 0 && i < m.keys.length)) return false;
   var next = cpFlSetPause(m, i, seconds, this.state.myFlightFixed === true);
   return this._flightEdCommit(next, (seconds > 0) ? format(optT("The camera will stay %s s on view %d"), String(seconds), i + 1) : format(optT("No hold on view %d"), i + 1), "ok");
};
CPStarfieldDock.prototype.flightCycleHold = function(i) {
   var m = this._flightMine();
   if (!m || !(i >= 0 && i < m.keys.length)) return false;
   var P = CP_FL.PAUSES, at = 0, cur = m.keys[i].pause, q;
   for (q = 0; q < P.length; ++q) if (P[q] <= cur + 1e-9) at = q;
   return this.flightSetHold(i, P[(at + 1) % P.length]);
};

// --- el desplazamiento ---------------------------------------------------------------------------------------------------
CPStarfieldDock.prototype._flightEdClamp = function() {
   var ed = this.fl.ed, m = this._flightMine(), n = m ? m.keys.length : 0;
   ed.scroll = Math.max(0, Math.min(Math.max(0, n - C3_FLED.VIS), ed.scroll));
};
// Que la vista `i` se vea (sube o baja la lista lo justo).
CPStarfieldDock.prototype._flightEdReveal = function(i) {
   var ed = this.fl.ed;
   if (i < ed.scroll) ed.scroll = i;
   else if (i >= ed.scroll + C3_FLED.VIS) ed.scroll = i - C3_FLED.VIS + 1;
   this._flightEdClamp();
   if (ed.shown) { try { this._flightEdThumbs(); } catch (e) {} }
};
CPStarfieldDock.prototype._flightEdRepaint = function() { try { if (this.fl.ed.shown) this.flList.repaint(); } catch (e) {} };
CPStarfieldDock.prototype._flightEdWheel = function(delta) {
   var ed = this.fl.ed, was = ed.scroll;
   ed.scroll += (delta > 0) ? -1 : 1;
   this._flightEdClamp();
   if (ed.scroll !== was) { try { this._flightEdThumbs(); } catch (e) {} this._flightEdRepaint(); }
};

// --- la geometria (compartida por el pintado y el clic: lo que se ve es lo que se pulsa) ----------------------------------
CPStarfieldDock.prototype._flightEdMetrics = function() {
   var L = this.flList, sc = cpUiScale(L), m = this._flightMine(), n = m ? m.keys.length : 0;
   function px(v) { return Math.round(v * sc); }
   var M = { sc: sc, px: px, n: n, W: L.width, H: L.height, pad: px(C3_FLED.PAD), hdr: px(C3_FLED.HDR), row: px(C3_FLED.ROW), thW: px(C3_FLED.THUMB_W), thH: px(C3_FLED.THUMB_H),
             btn: px(C3_FLED.BTN), gap: px(C3_FLED.GAP), sb: px(C3_FLED.SCROLL), chip: px(C3_FLED.CHIP) };
   M.scrollable = (n > C3_FLED.VIS);
   M.sbW = 0;                         // (V10: ya no hay barra de desplazamiento; se pasa con el pie y la rueda)
   M.btnsW = C3_FLED.BTNS.length * M.btn + (C3_FLED.BTNS.length - 1) * M.gap;
   M.btnX0 = M.W - M.pad - M.sbW - M.btnsW;
   M.thX = M.pad + M.chip + M.pad;
   M.textX = M.thX + M.thW + M.pad;
   M.fCaps = cpFont("text", CP_ATLAS.size.label * sc, true, false, cpCapsSpacing(CP_ATLAS.size.label * sc));
   M.fBody = cpFont("text", CP_ATLAS.size.body * sc);
   M.fSmall = cpFont("text", CP_ATLAS.size.label * sc);
   M.fGlyph = {};
   // «Clear all» / «Confirm?»: a la derecha de la cabecera
   var clearTxt = this.fl.ed.clear ? optT("Confirm?") : optT("Clear all"), cw = M.fCaps.width(clearTxt) + 2 * M.pad;
   M.clearTxt = clearTxt;
   M.clr = { x0: M.W - M.pad - cw, x1: M.W - M.pad, y0: 0, y1: M.hdr };
   // (H5) el pie: «▴ n above» a la izquierda y «▾ n more» a la derecha del centro, cuando los hay
   var ed = this.fl.ed, above = Math.max(0, Math.min(n, ed.scroll)), below = Math.max(0, n - ed.scroll - C3_FLED.VIS);
   M.footY0 = M.hdr + C3_FLED.VIS * M.row; M.footY1 = M.footY0 + px(C3_FLED.FOOT); M.above = above; M.below = below;
   M.upTxt = above > 0 ? "▴ " + format(optT("%d above"), above) : ""; M.downTxt = below > 0 ? "▾ " + format(optT("%d more"), below) : "";
   var pw = px(8), cx0 = Math.round(M.W / 2);
   M.up = above > 0 ? { x1: cx0 - px(6), x0: cx0 - px(6) - M.fSmall.width(M.upTxt) - 2 * pw, y0: M.footY0 + px(1), y1: M.footY1 - px(1) } : null;
   M.down = below > 0 ? { x0: cx0 + px(6), x1: cx0 + px(6) + M.fSmall.width(M.downTxt) + 2 * pw, y0: M.footY0 + px(1), y1: M.footY1 - px(1) } : null;
   if (M.up && !M.down) { var sh = Math.round((M.up.x1 - M.up.x0) / 2) + px(6); M.up.x0 += sh; M.up.x1 += sh; }
   if (M.down && !M.up) { var sh2 = Math.round((M.down.x1 - M.down.x0) / 2) + px(6); M.down.x0 -= sh2; M.down.x1 -= sh2; }
   return M;
};
// (H5) La ayuda de lo que hay bajo el raton, para el TOOLTIP de la lista ("" = la de siempre)
CPStarfieldDock.prototype._flightEdHintOf = function(b, k) {
   var m = this._flightMine(), key = (m && k >= 0 && k < m.keys.length) ? m.keys[k] : null;
   if (b === "trans" && key) return optT(C3_FLED.TRANS_HINT[key.trans]);
   if (b === "hold") return optT("Hold: the camera stays still on this view (click to change)");
   if (b === "more") return optT("Show the next views (also with the mouse wheel)");
   if (b === "above") return optT("Show the previous views (also with the mouse wheel)");
   if (b && C3_FLED.HINT[b]) return optT(C3_FLED.HINT[b]);
   return "";
};
CPStarfieldDock.prototype._flightEdBtnRect = function(M, r, bi) {
   var y0 = M.hdr + r * M.row + Math.round((M.row - M.btn) / 2), x0 = M.btnX0 + bi * (M.btn + M.gap);
   return { x0: x0, y0: y0, x1: x0 + M.btn, y1: y0 + M.btn };
};
// Los chips de la segunda linea de la fila `r` (vista `k`): { trans (null en la 1.ª), hold, endX (donde acaban) }.
CPStarfieldDock.prototype._flightEdChips = function(M, r, k, key) {
   var y0 = M.hdr + r * M.row + Math.round(M.row / 2) + M.px(1), h = Math.round(M.fSmall.ascent + M.fSmall.descent + M.px(4)), x = M.textX, out = { trans: null, hold: null, endX: M.textX };
   if (k > 0) {
      var tt = optT(C3_FLED.TRANS_LABEL[key.trans]), w = Math.round(M.fSmall.width(tt) + 2 * M.px(6));
      out.trans = { x0: x, y0: y0, x1: x + w, y1: y0 + h, text: tt }; x += w + M.px(4);
   }
   var ht = (key.pause > 0) ? format(optT("hold %s s"), String(key.pause)) : optT("+ hold"), hw = Math.round(M.fSmall.width(ht) + 2 * M.px(6));
   out.hold = { x0: x, y0: y0, x1: x + hw, y1: y0 + h, text: ht }; x += hw + M.px(6);
   out.endX = x;
   return out;
};
// Que hay bajo (x, y): { part: "none" | "hdr" | "clear" | "scroll" | "btn" | "name" | "row", k, b }
CPStarfieldDock.prototype._flightEdHit = function(x, y) {
   var ed = this.fl.ed, M = this._flightEdMetrics(), n = M.n, i;
   if (y < M.hdr) return (n > 0 && x >= M.clr.x0 && x <= M.clr.x1) ? { part: "clear", k: -1, b: "" } : { part: "hdr", k: -1, b: "" };
   if (y >= M.footY0) {
      if (M.down && x >= M.down.x0 && x < M.down.x1 && y >= M.down.y0 && y < M.down.y1) return { part: "foot", k: -1, b: "more" };
      if (M.up && x >= M.up.x0 && x < M.up.x1 && y >= M.up.y0 && y < M.up.y1) return { part: "foot", k: -1, b: "above" };
      return { part: "none", k: -1, b: "" };
   }
   var r = Math.floor((y - M.hdr) / M.row), k = ed.scroll + r;
   if (r < 0 || r >= C3_FLED.VIS || k >= n) return { part: "none", k: -1, b: "" };
   for (i = 0; i < C3_FLED.BTNS.length; ++i) {
      var q = this._flightEdBtnRect(M, r, i);
      if (x >= q.x0 && x < q.x1 && y >= q.y0 && y < q.y1) return { part: "btn", k: k, b: C3_FLED.BTNS[i] };
   }
   var keyH = this._flightMine().keys[k], ch = this._flightEdChips(M, r, k, keyH);
   if (ch.trans && x >= ch.trans.x0 && x < ch.trans.x1 && y >= ch.trans.y0 && y < ch.trans.y1) return { part: "btn", k: k, b: "trans" };
   if (x >= ch.hold.x0 && x < ch.hold.x1 && y >= ch.hold.y0 && y < ch.hold.y1) return { part: "btn", k: k, b: "hold" };
   if (x >= M.textX && x < M.btnX0 && y < M.hdr + r * M.row + Math.round(M.row / 2)) return { part: "name", k: k, b: "" };
   return { part: "row", k: k, b: "" };
};
// ¿Esta apagado este boton en esta vista?
CPStarfieldDock.prototype._flightEdBtnOff = function(b, k, n) {
   if (this.flightBusy()) return true;
   if (b === "up") return k <= 0;
   if (b === "down") return k >= n - 1;
   if (b === "replace") return this._flightCurrentCam() === null;
   return false;
};

// --- el pintado (copia lo ya hecho: nada se calcula aqui) --------------------------------------------------------------
CPStarfieldDock.prototype._flightEdPaint = function() {
   var L = this.flList, ed = this.fl.ed, m = this._flightMine(), keys = m ? m.keys : [], M = this._flightEdMetrics(), n = M.n, px = M.px, W = M.W, H = M.H, i, r;
   var g = new Graphics(L);
   try {
      g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
      g.fillRect(new Rect(0, 0, W, H), new Brush(CP_INT_BG));
      g.pen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1); g.brush = new Brush(0x00000000); g.drawRect(0, 0, W - 1, H - 1);
      // la cabecera
      var base = Math.round((M.hdr + M.fCaps.ascent - M.fCaps.descent) / 2), cur = this._flightEdCurrent(), busy = this.flightBusy();
      g.font = M.fCaps; g.pen = new Pen(CP_INT_AMBER);
      var title = optT("MY CAMERAS");
      g.drawText(M.pad, base, title);
      var info = (n === 1) ? optT("1 view") : format(optT("%d views"), n);
      if (n >= 2) info += " · " + Math.round(m.duration) + " s";
      g.font = M.fSmall; g.pen = new Pen(CP_INT_MUTED);
      g.drawText(M.pad + M.fCaps.width(title) + M.pad, Math.round((M.hdr + M.fSmall.ascent - M.fSmall.descent) / 2), info);
      if (n > 0) {
         var ask = ed.clear;
         g.font = M.fCaps; g.pen = new Pen(busy ? cpInt(CP_ATLAS_TEXT_OFF) : (ask ? CP_INT_ERROR : (ed.hk === -2 ? CP_INT_AMBER : CP_INT_MUTED)));
         g.drawText(M.clr.x0 + M.pad, base, M.clearTxt);
      }
      g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.35), 1); g.drawLine(0, M.hdr, W, M.hdr);
      if (n === 0) {
         g.font = M.fBody; g.pen = new Pen(CP_INT_TEXT2);
         var l1 = optT("No views yet."), l2 = optT("Move the 3D camera and press ＋ to save it here.");
         g.drawText(Math.round((W - M.fBody.width(l1)) / 2), M.hdr + Math.round(M.row * 0.8), l1);
         g.font = M.fSmall; g.pen = new Pen(CP_INT_MUTED);
         g.drawText(Math.round((W - M.fSmall.width(l2)) / 2), M.hdr + Math.round(M.row * 1.45), cpElide(M.fSmall, l2, W - 2 * M.pad));
         return;
      }
      // las filas
      for (r = 0; r < C3_FLED.VIS; ++r) {
         var k = ed.scroll + r;
         if (k >= n) break;
         var y0 = M.hdr + r * M.row, key = keys[k], hover = (ed.hk === k), here = (k === cur), name = this._flightEdName(k, key);
         if (hover) { g.fillRect(new Rect(1, y0, W - 1, y0 + M.row), new Brush(cpInt(CP_ATLAS.surface2, 0.9))); }
         if (here) { g.fillRect(new Rect(1, y0, W - 1, y0 + M.row), new Brush(cpInt(CP_ATLAS.gold, 0.10))); g.fillRect(new Rect(1, y0, 1 + px(2), y0 + M.row), new Brush(CP_INT_AMBER)); }
         if (r > 0) { g.pen = new Pen(cpInt(CP_ATLAS.line, 0.5), 1); g.drawLine(M.pad, y0, W - M.pad, y0); }
         // el numero
         g.font = M.fBody; g.pen = new Pen(here ? CP_INT_AMBER : CP_INT_TEXT2);
         var num = String(k + 1);
         g.drawText(M.pad + Math.round((M.chip - M.fBody.width(num)) / 2), y0 + Math.round((M.row + M.fBody.ascent - M.fBody.descent) / 2), num);
         // la miniatura
         var ty = y0 + Math.round((M.row - M.thH) / 2), th = this._flightEdThumbOf(key);
         if (th) { try { g.drawBitmap(M.thX, ty, th); } catch (eB) {} }
         else { g.fillRect(new Rect(M.thX, ty, M.thX + M.thW, ty + M.thH), new Brush(CP_INT_SURFACE)); g.font = M.fSmall; g.pen = new Pen(CP_INT_MUTED); g.drawText(M.thX + Math.round((M.thW - M.fSmall.width("…")) / 2), ty + Math.round((M.thH + M.fSmall.ascent - M.fSmall.descent) / 2), "…"); }
         g.pen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1); g.brush = new Brush(0x00000000); g.drawRect(M.thX, ty, M.thX + M.thW - 1, ty + M.thH - 1);
         // el nombre y su linea de datos (o la ayuda del boton sobre el que esta el raton)
         var tw = M.btnX0 - M.textX - M.pad;
         g.font = M.fBody; g.pen = new Pen(CP_INT_TEXT);
         g.drawText(M.textX, y0 + Math.round(M.row / 2) - px(3), cpElide(M.fBody, name, tw));
         // la segunda linea: los chips de transicion y pausa, y luego los datos (o la ayuda del chip/boton sobre el que esta el raton)
         var ch = this._flightEdChips(M, r, k, key), cx2, chips = [ch.trans, ch.hold], ci;
         for (ci = 0; ci < 2; ++ci) {
            var cq = chips[ci];
            if (!cq) continue;
            var isT = (ci === 0), on = isT ? (key.trans !== "smooth") : (key.pause > 0), hotc = (hover && ed.hb === (isT ? "trans" : "hold") && !busy);
            g.pen = new Pen(cpInt(on || hotc ? CP_ATLAS.gold : CP_ATLAS.line, hotc ? 0.95 : (on ? 0.7 : 0.8)), 1); g.brush = new Brush(on ? cpInt(CP_ATLAS.gold, 0.12) : 0x00000000);
            g.drawRect(cq.x0, cq.y0, cq.x1 - 1, cq.y1 - 1);
            g.font = M.fSmall; g.pen = new Pen(busy ? cpInt(CP_ATLAS_TEXT_OFF) : (on || hotc ? CP_INT_AMBER : CP_INT_MUTED));
            g.drawText(cq.x0 + M.px(6), cq.y0 + Math.round((cq.y1 - cq.y0 + M.fSmall.ascent - M.fSmall.descent) / 2), cq.text);
         }
         // (H5: la linea de datos ya no se cambia por la ayuda del chip o del boton: esa va en el tooltip de la lista)
         var sub = format("%s s · ", cpSvFx(key.t, 1)) + format(optT("turn %d° · tilt %d° · zoom ×%s"), Math.round(key.cam.yaw), Math.round(key.cam.pitch), cpSvFx(key.cam.zoom, 1)), subx = ch.endX, subw = M.btnX0 - subx - M.pad;
         g.font = M.fSmall; g.pen = new Pen(CP_INT_MUTED);
         if (subw > M.px(40)) g.drawText(subx, ch.hold.y0 + Math.round((ch.hold.y1 - ch.hold.y0 + M.fSmall.ascent - M.fSmall.descent) / 2), cpElide(M.fSmall, sub, subw));
         // los cinco botones: glifos de texto, cada uno a la escala que iguala su tinta a la de ▲ (H5)
         var GS = ed.gs || {};
         for (i = 0; i < C3_FLED.BTNS.length; ++i) {
            var b = C3_FLED.BTNS[i], q = this._flightEdBtnRect(M, r, i), off = this._flightEdBtnOff(b, k, n), hot = (hover && ed.hb === b && !off);
            if (hot) { g.fillRect(new Rect(q.x0, q.y0, q.x1, q.y1), new Brush(cpInt(CP_ATLAS.surface2))); g.pen = new Pen(cpInt(b === "delete" ? CP_ATLAS.error : CP_ATLAS.gold, 0.8), 1); g.brush = new Brush(0x00000000); g.drawRect(q.x0, q.y0, q.x1 - 1, q.y1 - 1); }
            var gcol = off ? cpInt(CP_ATLAS_TEXT_OFF) : (hot ? (b === "delete" ? CP_INT_ERROR : CP_INT_AMBER) : CP_INT_TEXT2);
            if ((b === "rename" || b === "replace") && C3_FLED.VECTOR !== false) {   // (V10: ✎ y ⟳ dibujados, con el peso de ▲ ▼ ✕)
               var vs = (ed.gsRef > 0) ? ed.gsRef : Math.round(M.btn * 0.5);
               if (b === "rename") c3FlEdPencil(g, q.x0 + M.btn / 2, q.y0 + M.btn / 2, vs, gcol); else c3FlEdRefresh(g, q.x0 + M.btn / 2, q.y0 + M.btn / 2, vs, gcol);
               continue;
            }
            var gl = C3_FLED.GLYPH[b], gsc = (GS[b] > 0) ? GS[b] : 1, fg = (gsc > 1.01) ? (M.fGlyph[b] || (M.fGlyph[b] = cpFont("text", CP_ATLAS.size.body * M.sc * gsc))) : M.fBody;
            g.font = fg;
            g.pen = new Pen(gcol);
            var gm = (ed.gsMid && typeof ed.gsMid[b] === "number") ? ed.gsMid[b] : null;
            g.drawText(q.x0 + Math.round((M.btn - fg.width(gl)) / 2), (gm !== null) ? Math.round(q.y0 + M.btn / 2 - gm) : q.y0 + Math.round((M.btn + fg.ascent - fg.descent) / 2), gl);
         }
      }
      // (H5) EL FUNDIDO: la ultima fila visible se apaga hacia abajo si hay mas debajo (y la primera hacia arriba si hay encima)
      var fadeH = px(C3_FLED.FADE), st0, NST = 7;
      if (M.below > 0) for (st0 = 0; st0 < NST; ++st0) { var fy0 = M.footY0 - fadeH + Math.round(fadeH * st0 / NST), fy1 = M.footY0 - fadeH + Math.round(fadeH * (st0 + 1) / NST); g.fillRect(new Rect(1, fy0, W - 1 - M.sbW, fy1), new Brush(cpInt(CP_ATLAS.bg, 0.85 * (st0 + 1) / NST))); }
      if (M.above > 0) for (st0 = 0; st0 < NST; ++st0) { var gy0 = M.hdr + 1 + Math.round(fadeH * st0 / NST), gy1 = M.hdr + 1 + Math.round(fadeH * (st0 + 1) / NST); g.fillRect(new Rect(1, gy0, W - 1 - M.sbW, gy1), new Brush(cpInt(CP_ATLAS.bg, 0.6 * (NST - st0) / NST))); }
      // (H5) EL PIE: «▴ n above» · «▾ n more» (se pulsan: pasan una pagina)
      g.pen = new Pen(cpInt(CP_ATLAS.line, 0.6), 1); g.drawLine(M.pad, M.footY0, W - M.pad, M.footY0);
      var pills = [[M.up, M.upTxt, "above"], [M.down, M.downTxt, "more"]];
      for (i = 0; i < 2; ++i) {
         var pq = pills[i][0]; if (!pq) continue;
         var hotP = (ed.hk === -3 && ed.hb === pills[i][2]);
         g.fillRect(new Rect(pq.x0, pq.y0, pq.x1, pq.y1), new Brush(hotP ? cpInt(CP_ATLAS.surface2) : cpInt(CP_ATLAS.gold, 0.10)));
         g.pen = new Pen(cpInt(CP_ATLAS.gold, hotP ? 0.95 : 0.6), 1); g.brush = new Brush(0x00000000); g.drawRect(pq.x0, pq.y0, pq.x1 - 1, pq.y1 - 1);
         g.font = M.fSmall; g.pen = new Pen(hotP ? CP_INT_AMBERLIGHT : CP_INT_AMBER);
         g.drawText(pq.x0 + px(8), pq.y0 + Math.round((pq.y1 - pq.y0 + M.fSmall.ascent - M.fSmall.descent) / 2), pills[i][1]);
      }
      // (V10, 21-oct: sin barra de desplazamiento: con «▾ n more» eran dos caminos a lo mismo —§11.5—; queda el pie y la rueda)
   } finally { g.end(); }
};

// --- el raton -----------------------------------------------------------------------------------------------------------
CPStarfieldDock.prototype._flightEdMove = function(x, y) {
   var ed = this.fl.ed, hk = -1, hb = "", clear = ed.clear;
   if (x >= 0) {
      var h = this._flightEdHit(x, y);
      if (h.part === "clear") hk = -2;
      else if (h.part === "foot") { hk = -3; hb = h.b; }
      else if (h.part === "btn") { hk = h.k; hb = h.b; }
      else if (h.part === "row" || h.part === "name") hk = h.k;
      if (h.part !== "clear") clear = false;               // (moverse fuera de «Clear all» cancela la confirmacion)
   } else clear = false;
   if (hk !== ed.hk || hb !== ed.hb || clear !== ed.clear) {
      ed.hk = hk; ed.hb = hb; ed.clear = clear;
      // (H5) la ayuda de lo que hay bajo el raton va en el TOOLTIP de la lista; fuera de un boton, la de siempre
      var hint = (hb !== "") ? this._flightEdHintOf(hb, hk) : "";
      if (hint !== (ed.hint || "")) { ed.hint = hint; try { this.flList.toolTip = (hint !== "") ? cpWrapTooltip(hint) : cpTooltip("sf.flight.list"); } catch (eT) {} }
      this._flightEdRepaint();
   }
};
// (H5) Pasar una pagina (el pie «▾ n more» / «▴ n above»)
CPStarfieldDock.prototype._flightEdPage = function(dir) {
   var ed = this.fl.ed, was = ed.scroll;
   ed.scroll += dir * C3_FLED.VIS;
   this._flightEdClamp();
   if (ed.scroll !== was) { try { this._flightEdThumbs(); } catch (e) {} this._flightEdRepaint(); }
   return ed.scroll !== was;
};
CPStarfieldDock.prototype._flightEdPress = function(x, y) {
   var ed = this.fl.ed, h = this._flightEdHit(x, y);
   if (ed.renaming >= 0) this._flightEdRenameEnd(true);
   if (h.part !== "clear" && ed.clear) { ed.clear = false; this._flightEdRepaint(); }
   if (h.part === "foot") {
      this._flightEdPage(h.b === "more" ? 1 : -1);
      this._flightEdMove(x, y);
   } else if (h.part === "clear") {
      if (this.flightBusy()) return;
      if (!ed.clear) { ed.clear = true; this._flightEdRepaint(); } else { ed.clear = false; this.flightClearAll(); }
   } else if (h.part === "btn") {
      if (this._flightEdBtnOff(h.b, h.k, this._flightEdMetrics().n)) return;
      if (h.b === "up") this.flightMoveKey(h.k, -1);
      else if (h.b === "down") this.flightMoveKey(h.k, 1);
      else if (h.b === "replace") this.flightReplaceKey(h.k);
      else if (h.b === "rename") this._flightEdRename(h.k);
      else if (h.b === "delete") this.flightDeleteKey(h.k);
      else if (h.b === "trans") this.flightCycleTransition(h.k);
      else if (h.b === "hold") this.flightCycleHold(h.k);
   } else if (h.part === "row" || h.part === "name") {
      this.flightGoTo(h.k);
   }
};
CPStarfieldDock.prototype._flightEdDouble = function(x, y) {
   var h = this._flightEdHit(x, y);
   if (h.part === "name") this._flightEdRename(h.k);
};

// --- renombrar en el sitio (un campo de texto encima del nombre; sin dialogo) -------------------------------------------
CPStarfieldDock.prototype._flightEdRename = function(k) {
   var ed = this.fl.ed, m = this._flightMine(), self = this;
   if (!m || !(k >= 0 && k < m.keys.length) || this.flightBusy() || !ed.shown) return false;
   if (!ed.edit) {
      var E = ed.edit = new Edit(this.flList);
      cpSfFlField(E);
      E.toolTip = cpTooltip("sf.flight.rename");
      E.onEditCompleted = function() { self._flightEdRenameEnd(true); };
      E.onKeyPress = function(key) { if (key === 27) { self._flightEdRenameEnd(false); return true; } return false; };
      cpSetControlVisible(E, false);
   }
   var M = this._flightEdMetrics(), r = k - ed.scroll;
   if (r < 0 || r >= C3_FLED.VIS) return false;
   ed.renaming = k;
   var y0 = M.hdr + r * M.row, w = Math.max(M.px(60), M.btnX0 - M.textX - M.pad), h = Math.round(M.fBody.ascent + M.fBody.descent + M.px(8));
   try {
      ed.edit.setFixedSize(w, h);
      ed.edit.move(M.textX, y0 + Math.round(M.row / 2) - h + M.px(2));
      ed.edit.text = m.keys[k].label || "";
      cpSetControlVisible(ed.edit, true);
      ed.edit.bringToFront();
      ed.edit.setFocus();
      ed.edit.selectAll();
   } catch (e) { ed.renaming = -1; return false; }
   return true;
};
// Acabar de renombrar: con `commit`, se guarda lo escrito (vacio = el nombre de fabrica).
CPStarfieldDock.prototype._flightEdRenameEnd = function(commit) {
   var ed = this.fl.ed;
   if (!ed || ed.renaming < 0 || !ed.edit) return;
   var k = ed.renaming, text = "";
   ed.renaming = -1;
   try { text = String(ed.edit.text); } catch (e) {}
   cpSetControlVisible(ed.edit, false);
   if (commit) this.flightRenameKey(k, text);
   else this._flightEdRepaint();
};
