// ============================================================================
// tm/dust_run.js — EL POLVO: leer el mapa de Edenhofer por la red (rangos HTTP) y el color de las estrellas (Cabra3D, A5)
// ----------------------------------------------------------------------------
// `c3DustFetch( result, opts )`: el polvo a lo largo del haz de la foto. Una rejilla de lineas de vista sobre la foto
// (por `result._unproject`), el pixel HEALPix de cada una (tm/dust.js), y del fichero de Zenodo SOLO esos pixeles en las
// 516 capas (rangos multiples por peticion; curl con su tope de tiempo). Lo leido se guarda en la cache
// (%LOCALAPPDATA%/CabraScripts/cache/dust2_<huella>.json, `c3CacheDir()` de CabraShared; hasta el 22-oct era <temporal>/Cabra3D_cache): la segunda vez, y sin red, sale de ahi.
// Devuelve { ok, code ("" | "no-network" | "bad-answer" | "no-coverage"), why, ms, bytes, requests, cached,
//            nx, ny, cells: [ { x0, y0, x1, y1 (pixeles de la foto), pix, prof } ], layer: { d, dE }, eMax, source }.
// `c3DustTeffFetch( result, opts )`: la temperatura de Gaia DR3 (GSP-Phot) de las estrellas del campo, para MEDIR su
// enrojecimiento (su BP−RP menos el de una estrella de esa temperatura, de la secuencia de Mamajek que ya trae el motor).
// COSTURA DE PRUEBAS: `C3_DUST_CURL_HOOK( ranges, url ) -> { ok, bytes (Uint8Array), n, multipart }` en vez de curl.
// ES5.
// ============================================================================

// CERRANDO EL SCRIPT (el aspa, Esc o «Close»; lo pone el dialogo): los bucles largos lo miran y paran (puntos de parada).
var C3_CLOSING = false;
// (la cache, curl con rangos, las tandas y los bordes de las capas son COMUNES: ../CabraShared/csh_dust.js)

function c3DustFetch(result, opts) {
   var o = opts || {}, t0 = Date.now(), out = { ok: false, code: "", why: "", ms: 0, bytes: 0, requests: 0, cached: false, missing: 0, stride: 1, cells: [], nx: 0, ny: 0, layer: null, eMax: 0,
              source: "Edenhofer et al. 2024 (A&A 685, A82), Zenodo 10658339 · mean_and_std_healpix.fits" };
   if (!result || !result.ok || typeof result._unproject !== "function") { out.code = "no-view"; return out; }
   var f = result.field, nx = Math.max(4, Math.min(12, o.nx || 10)), ny = Math.max(3, Math.min(9, Math.round(nx * f.height / f.width))), i, j;
   out.nx = nx; out.ny = ny;
   var pixOf = [], uniq = {}, list = [];
   for (j = 0; j < ny; ++j) for (i = 0; i < nx; ++i) {
      var x = f.width * (i + 0.5) / nx, y = f.height * (j + 0.5) / ny, q = result._unproject(x, y), p = (q !== null) ? c3DustPixOf(q.ra, q.dec) : -1;
      pixOf.push(p);
      if (p >= 0 && !uniq[p]) { uniq[p] = true; list.push(p); }
   }
   if (list.length === 0) { out.code = "no-coverage"; return out; }
   // (la lectura es la comun: lo ya leido en la sesion —por CabraStars o por CabraStarAnalysis— no se vuelve a pedir)
   var P = cshDustProfiles(list, { key: "dust2", onProgress: o.onProgress }), data = P.data, bounds = P.bounds;
   out.cached = P.cached || (P.fromMemory === list.length); out.requests = P.requests; out.bytes = P.bytes; out.stride = P.stride; out.missing = P.missing;
   if (!P.ok && (P.code === "no-network" || P.code === "stopped")) { out.code = "no-network"; out.why = optT("The dust map (Zenodo) did not answer."); out.ms = Date.now() - t0; return out; }
   // los perfiles de cada celda y lo que se cuenta del campo
   var profs = {}, med = [], layers = [];
   for (i = 0; i < list.length; ++i) { if (P.profs[list[i]]) profs[list[i]] = P.profs[list[i]]; }
   for (j = 0; j < ny; ++j) for (i = 0; i < nx; ++i) {
      var pp = pixOf[j * nx + i], pr = (pp >= 0) ? profs[pp] : null;
      out.cells.push({ x0: f.width * i / nx, y0: f.height * j / ny, x1: f.width * (i + 1) / nx, y1: f.height * (j + 1) / ny, pix: pp, prof: pr });
      if (pr) { var eT = pr.cum[pr.cum.length - 1]; med.push(eT); out.eMax = Math.max(out.eMax, eT); layers.push(c3DustMainLayer(pr, 40)); }
   }
   if (med.length === 0) { out.code = "bad-answer"; return out; }
   med.sort(function(a, b) { return a - b; });
   out.eMedian = med[med.length >> 1];
   // la capa principal del campo: la mediana de las de cada celda (pesada por lo que oscurecen)
   layers.sort(function(a, b) { return a.d - b.d; });
   var wsum = 0, half = 0;
   for (i = 0; i < layers.length; ++i) wsum += layers[i].dE;
   for (i = 0; i < layers.length; ++i) { half += layers[i].dE; if (half >= wsum / 2) { out.layer = { d: layers[i].d, dE: layers[i].dE }; break; } }
   out.ok = true; out.ms = Date.now() - t0;
   return out;
}
// E acumulado hasta `pc` en el pixel (x, y) de la foto (la celda que le toca). null fuera del mapa.
function c3DustEToward(dust, x, y, pc) {
   if (!dust || !dust.ok) return null;
   var f = dust.cells, nx = dust.nx;
   for (var k = 0; k < f.length; ++k) { var c = f[k]; if (x >= c.x0 && x < c.x1 && y >= c.y0 && y < c.y1) return c.prof ? c3DustEAt(c.prof, pc) : null; }
   return null;
}

// RESERVA DE LA TEMPERATURA (28-oct-2026, agente B): si VizieR no da la tabla (el CDS estuvo caido el 27 y el 28-oct), el archivo de
// Gaia de la ESA, que trae las mismas columnas GSP-Phot en gaiadr3.gaia_source. MEDIDO el 28-oct en las mismas estrellas: NGC 1560,
// 3 297 filas de VizieR (cache del 14-oct) frente a 3 298 de la ESA, casadas las 3 297 a 0,1" con |dTeff|, |dE(BP−RP)| y |dA0| = 0
// exactos; LDu 2, 21 623 frente a 21 622 (una sin pareja), igual de exactas; la ESA contesto en 0,5-0,7 s. Plazo corto: la
// comprobacion es opcional (peor caso con los dos callados: el plazo de VizieR + 15 s).
var C3_DUST_TEFF_ESA = true;
var C3_DUST_TEFF_ESA_TIMEOUT_S = 15;
function c3DustTeffAdqlEsa(ra, dec, radiusDeg) {
   return "SELECT g.ra AS \"RA_ICRS\",g.dec AS \"DE_ICRS\",g.teff_gspphot AS \"Teff\",g.ebpminrp_gspphot AS \"E(BP-RP)\",g.azero_gspphot AS \"A0\" FROM gaiadr3.gaia_source AS g " +
          "WHERE 1=CONTAINS(POINT('ICRS',g.ra,g.dec),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND g.teff_gspphot IS NOT NULL";
}
// LA TEMPERATURA de Gaia de las estrellas del campo -> { ok, code, rows, matched, byStar: { indice: { teff, bprp, ebprpGsp, a0 } },
//                                                       server ("vizier" | "esa"), fallback, source } (server/source solo si se pidio a la red)
function c3DustTeffFetch(result, opts) {
   var o = opts || {}, out = { ok: false, code: "", rows: 0, matched: 0, byStar: {}, ms: 0 };
   if (!result || !result.ok) { out.code = "no-view"; return out; }
   var f = result.field, key = "teff2_" + f.ra.toFixed(4) + "_" + f.dec.toFixed(4) + "_" + f.radiusDeg.toFixed(4) + ".json", cache = c3CacheRead(key), rows = null, t0 = Date.now();
   if (cache && cache.rows) { rows = cache.rows; out.cached = true; }
   else {
      // (de la tabla de parametros astrofisicos I/355/paramp, no de I/355/gaiadr3: MEDIDO el 15-oct, pedir Teff a gaiadr3 tardaba
      // 47-54 s en NGC 1560 —y se pasaba del tope—; a paramp, 1,4 s. El BP−RP es el de la estrella, que ya trae la base local)
      var adql = "SELECT RA_ICRS,DE_ICRS,Teff,\"E(BP-RP)\",A0 FROM \"I/355/paramp\" WHERE 1=CONTAINS(POINT('ICRS',RA_ICRS,DE_ICRS),CIRCLE('ICRS'," +
                 f.ra.toFixed(6) + "," + f.dec.toFixed(6) + "," + f.radiusDeg.toFixed(5) + ")) AND Teff IS NOT NULL";
      // (28-oct, tarde; B3) `onServer(id)` dice a quien se pregunta AHORA, para que el aviso de la interfaz no diga «VizieR» si contesta la ESA
      if (typeof o.onServer === "function") { try { o.onServer("vizier"); } catch (eS) {} }
      var r = cpSfHttpText(cpSfTapUrl(CP_SF_VIZIER_TAP, adql), { timeoutS: o.httpTimeoutS || 40, onProgress: o.onProgress });
      // (un reintento solo si se pide: en la interfaz, dos topes de 40 s eran 80 s de barra para una comprobacion opcional)
      if (o.retry === true && (!r.ok || !cpSfLooksLikeCsv(r.text, "RA_ICRS"))) r = cpSfHttpText(cpSfTapUrl(CP_SF_VIZIER_TAP, adql), { timeoutS: o.httpTimeoutS || 40, onProgress: o.onProgress });
      out.server = "vizier"; out.fallback = false; out.source = "VizieR: I/355/paramp (Teff, E(BP-RP), A0 GSP-Phot)";
      // (si VizieR no da la tabla, el archivo de la ESA, con su plazo corto: ver C3_DUST_TEFF_ESA)
      if ((!r.ok || !cpSfLooksLikeCsv(r.text, "RA_ICRS")) && C3_DUST_TEFF_ESA !== false && typeof CSH_ESA_TAP === "string") {
         if (typeof o.onServer === "function") { try { o.onServer("esa"); } catch (eS2) {} }
         var rE = cpSfHttpText(cpSfTapUrl(CSH_ESA_TAP, c3DustTeffAdqlEsa(f.ra, f.dec, f.radiusDeg)), { timeoutS: C3_DUST_TEFF_ESA_TIMEOUT_S, onProgress: o.onProgress });
         if (rE.ok && cpSfLooksLikeCsv(rE.text, "RA_ICRS")) { r = rE; out.server = "esa"; out.fallback = true; out.source = "ESA Gaia archive: gaiadr3.gaia_source (Teff, E(BP-RP), A0 GSP-Phot)"; }
      }
      if (!r.ok) { out.code = "no-network"; out.why = r.message; out.ms = Date.now() - t0; return out; }
      if (!cpSfLooksLikeCsv(r.text, "RA_ICRS")) { out.code = "bad-answer"; return out; }
      var t = cpSfParseTable(r.text, ","); rows = [];
      for (var i = 0; i < t.rows.length; ++i) {
         var q = t.rows[i], ra = cpSfNum(q.RA_ICRS), de = cpSfNum(q.DE_ICRS), te = cpSfNum(q.Teff);
         if (ra === null || de === null || te === null) continue;
         rows.push([ra, de, te, null, cpSfNum(q["E(BP-RP)"]), cpSfNum(q.A0)]);
      }
      c3CacheWrite(key, { rows: rows, when: (new Date()).toISOString() });
   }
   out.rows = rows.length;
   // (el mismo casado por posicion J2016 que las velocidades radiales: en el hueco de la «rv» va el numero de fila)
   var asRows = [];
   for (var k = 0; k < rows.length; ++k) asRows.push({ ra: rows[k][0], dec: rows[k][1], rv: k, err: null });
   var m = c3TmRvMatch(result.stars, asRows);
   for (var idx in m.rv) { var best = rows[m.rv[idx].rv]; out.byStar[idx] = { teff: best[2], bprp: best[3], ebprpGsp: best[4], a0: best[5] }; ++out.matched; }
   out.ok = true; out.ms = Date.now() - t0;
   return out;
}
// El color intrinseco (BP−RP) de una enana de temperatura `teff`, interpolado en la secuencia de Mamajek que ya trae el motor,
// y pasado al sistema de Gaia DR3 (el de las estrellas que se comparan).
// (6-nov-2026, CPD 7.3) el paquete ya no lleva la tabla: la baja dust_ui.js `_dustMsLoad` la primera vez que hace falta. Aqui no se va a la red
// (se llama estrella a estrella): sin tabla, null, y `_dustCompare` usa el E(BP−RP) de GSP-Phot.
function c3DustIntrinsic(teff) {
   var ms = cpStarfieldMainSequence();
   if (!ms || ms.length < 2) return null;
   var L = ms.filter(function(r) { return r.teff > 0 && r.bpRp !== null && isFinite(r.bpRp); }).sort(function(a, b) { return a.teff - b.teff; }), c = null;
   if (teff <= L[0].teff) c = L[0].bpRp;
   else if (teff >= L[L.length - 1].teff) c = L[L.length - 1].bpRp;
   else for (var i = 1; i < L.length; ++i) if (L[i].teff >= teff) { var w = (teff - L[i - 1].teff) / (L[i].teff - L[i - 1].teff); c = L[i - 1].bpRp + w * (L[i].bpRp - L[i - 1].bpRp); break; }
   if (c === null) return null;
   return cshMsDr3Colour(c);
}
// DE DR2 A DR3: UNA sola conversion, la comun (28-oct-2026, tarde): CabraShared/csh_mainseq.js `cshMsDr3Colour` (tabla CSH_MS_DR3_FROM_DR2,
// costura CSH_MS_DR3; origen y medida en su cabecera y en Cabra3D/docs/informe_28oct_agenteB.md §3.2). Antes vivia aqui (C3_DUST_DR3_FROM_DR2,
// c3DustDr3Offset, C3_DUST_DR3_COLOURS): se quito para no tener dos. Prueba: tests/c3_node_dust_colour.js M5 (rojo C3_DC_BREAK=nodr3).
