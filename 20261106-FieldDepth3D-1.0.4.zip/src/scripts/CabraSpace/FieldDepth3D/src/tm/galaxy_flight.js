// ============================================================================
// tm/galaxy_flight.js — LOS VUELOS EN LA GALAXIA: vista previa y vídeo en la vista abierta del mapa (desde arriba, de canto o 3D) (Cabra3D, 26-oct-2026)
// ----------------------------------------------------------------------------
// Queja de Nino: «En Cabra3D, cuando se selecciona el modo Galaxia no permite Vuelo y Vídeo. Y lo debe permitir.» Hasta hoy, con la Galaxia,
// la vista previa no arrancaba y «● Record» con «qué grabar: el vuelo» se negaba (galaxy_view.js: «los vuelos son de la caja del campo»).
//
// EL DISEÑO (en el HANDOFF, «26-oct · reloj en el panel y vuelo en Galaxia»)
//   · LOS MISMOS TRES VUELOS, con sus nombres de siempre, pensados para el mapa y EN LA VISTA QUE ESTÉ ABIERTA (26-oct, tarde, decisión de Nino:
//     antes iban siempre en 3D; ahora cada vista con SU proyección, como el vídeo de la máquina del tiempo, que graba la vista abierta):
//     EN 3D (la cámara 3D de la Galaxia, cshGxCam: pivote, giro, inclinación y travelín) — lo de siempre:
//       Dive        la Vía Láctea entera desde arriba (el centro arriba, el Sol abajo) → baja al Sol y a las estrellas del campo, girando
//                   despacio, hasta mirarlas desde detrás del Sol hacia el centro galáctico → se queda.
//       Orbit       una vuelta entera (360°, bucle cerrado) alrededor del Sol y del campo, en el instante de la máquina del tiempo.
//       Grand tour  baja como «Dive», da la vuelta al campo MIENTRAS CORRE LA MÁQUINA DEL TIEMPO (hoy → −escala → +escala → hoy; la cámara
//                   sigue al Sol por su órbita) con el RELOJ en la placa, y vuelve a subir a la Galaxia entera.
//     DESDE ARRIBA y DE CANTO (las vistas 2D: v2 = aumentos, centro y, nuevo en CabraShared/csh_galaxy.js, pivote en pantalla, giro y azimut):
//       Dive        la Galaxia entera (desde arriba: el centro en medio y el Sol abajo; de canto: el disco entero) → acercamiento al Sol y al
//                   campo, desplazando y ampliando SIN girar, con el mismo encuadre final que en 3D → se queda.
//       Orbit       una vuelta entera alrededor del EJE VERTICAL GALÁCTICO que pasa por el Sol, sin salir de la proyección (opción 3A-1 de
//                   Nino): desde arriba, el mapa gira en su plano alrededor del Sol; de canto, la mirada recorre los 360° de azimut dentro
//                   del plano (sigue de canto: la proyección LINEAL de cshGxEdgeXf con v2.az; el fondo, la lámina vertical que pasa por el Sol).
//       Grand tour  acercamiento → corre la máquina del tiempo con el encuadre siguiendo al Sol por su órbita (de canto se ve además la
//                   oscilación vertical: el plano sube y baja respecto al Sol) y el reloj en la placa → alejamiento.
//     «My flight» son vistas de la caja del CAMPO: en la Galaxia se apaga con su porqué (no hay un segundo editor de cámaras; opción 3B-1).
//   · EL ACERCAMIENTO: el travelín final hace que el 75 % de las estrellas con órbita (su distancia al Sol, en cada instante) ocupe ~42 % del
//     medio lado corto, con el Sol en el centro y algo por debajo (CY: la placa y la leyenda van arriba); el pivote llega al Sol ANTES que el
//     travelín (1,6×): el Sol no se sale del cuadro al bajar. En 2D la distancia es la de la PANTALLA (de canto, con la escala de z de la vista)
//     y, además, el pivote se adelanta lo que haga falta para que el Sol quede SIEMPRE dentro del cuadro (c3GxfSafeA: es lineal en el avance).
//   · NADA DEL USUARIO SE TOCA: el pintor del fotograma usa su propia vista (V.v2 / V.cam nuevos); al parar, gx.v2 y gx.cam son los de antes.
//   · EL MISMO BOTÓN Y EL MISMO FLUJO que el vuelo del campo: «▶ Preview» (en el lienzo, a tiempo real, encuadrado como el vídeo, con el dibujo
//     ligero del arrastre), «● Record» con «qué grabar: el vuelo por la galaxia» (los mismos tamaños, fps, título y carpeta de ▾; MP4 con ffmpeg
//     —cpAviToMp4, con el arreglo de waitForFinished—, AVI si no), la barra de progreso en el lienzo, «Cancel» que pregunta, «Flight saved: …».
//     Un solo pintor de fotograma (`_gxFlightFrame` + `c3GxfChrome`) para la vista previa y el vídeo.
//   · EL RELOJ: si corre el tiempo (Grand tour) o el instante no es «hoy», la placa del instante con el reloj D, en la esquina de la izquierda
//     (arriba o abajo) con menos estrellas debajo a lo largo del vuelo (el criterio del vídeo de la máquina del tiempo); el título, en la de
//     abajo que no ocupa la placa.
//   · EL FICHERO lleva la vista: «<título>_galaxy_<top|edge|3d>_<vuelo>_<ancho>x<alto>» (como `_gxVideoTag` del vídeo de la máquina del tiempo).
// Lo incluye SOLO Cabra3D.js, después de tm/galaxy_view.js y tm/timeclock_panel.js. ES5.
// ============================================================================

var C3_GXF = {
   KINDS: ["dive", "orbit", "tour"],
   DUR: { dive: 12, orbit: 12, tour: 24 },     // s, de fábrica (el campo de la duración los cambia, 4–180 s)
   PITCH_TOP: -88, PITCH_LOW: -22,             // desde arriba (la vista «desde arriba»: el polo norte) y la de cerca (desde el norte, por detrás del Sol)
   ZOOM_TOP: 0.85, ZOOM_MIN: 1.5, ZOOM_MAX: 60,
   SPREAD_Q: 0.75, FILL: 0.42,                 // el acercamiento: el cuantil 75 de la distancia al Sol ocupa el 42 % del medio lado corto
   CX: 0.5, CY: 0.62,                          // dónde va el pivote (el Sol, cerca) en el cuadro: centrado y por DEBAJO de la placa y la leyenda (las dos van arriba)
   SC_MIN: 0.6,                                // la letra y las placas crecen con el cuadro (la referencia: 540 px de alto); no menos de esto
   YAW_DIVE: 40, LEAD: 1.6,                    // el giro al bajar (grados) y cuánto se adelanta el pivote al travelín
   PREVIEW_MAX_W: 1280,                        // la vista previa se pinta a este ancho como mucho y se escala al lienzo
   TITLE_S: 2.6, FADE_S: 1.0,
   K2_TOP: 0.92, K2_MAX: 200,                  // 2D: los aumentos de la Galaxia entera (sobre el encuadre de fábrica de G.ext) y el tope (el de la rueda: cshGx2DZoomAt)
   SUN_M: 0.05                                 // 2D: el Sol, al menos a este margen del borde (fracción del lado corto) en todo el vuelo
};
// DEFECTOS INYECTADOS (tests/c3_gx_flight.js): «off» = lo de antes (en la Galaxia no hay vuelos: la vista previa no arranca y grabar se niega);
// «clock» = sin la placa con el reloj aunque corra el tiempo; «follow» = la cámara no sigue al Sol mientras corre el tiempo (el campo se va del cuadro).
// (tests/c3_galaxy_flight_views.js) «force3d» = siempre en 3D (lo de antes de las tres vistas); «noloop» = Orbit da 350° y no 360° (no cierra);
// «norestore» = el fotograma escribe su vista en la del usuario (gx.v2 / gx.cam); «corner1» = la esquina de la placa contada solo con el primer
// momento del vuelo (la Galaxia entera), no con la proyección de cada momento; «tag» = el fichero sin la vista («galaxy_<vuelo>»); «nosafe» = sin
// el adelanto del pivote que guarda al Sol dentro del cuadro en 2D.
var C3_GXF_BREAK = "";
function c3GxfBroken(k) { return (typeof C3_GXF_BREAK === "string") && C3_GXF_BREAK.length > 0 && C3_GXF_BREAK.indexOf(k) >= 0; }
function c3GxfSm(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
function c3GxfLerp(a, b, t) { return a + (b - a) * t; }
// La escala del dibujo de un cuadro w × h (la letra y las placas, proporcionales al cuadro)
function c3GxfSc(w, h) { return Math.max(C3_GXF.SC_MIN, Math.min(w, h) / 540); }
// La cámara del plan en un cuadro w × h: el pivote, en (CX, CY) del cuadro (sin esto, cshGxCam lo centra en el encaje, que cambia con la placa)
function c3GxfCamPx(cam, w, h) { return { yaw: cam.yaw, pitch: cam.pitch, zoom: cam.zoom, ox: cam.ox, oy: cam.oy, oz: cam.oz, cx: Math.round(C3_GXF.CX * w), cy: Math.round(C3_GXF.CY * h) }; }

// Los textos nuevos (EN de fábrica; ES aquí: cabra3d.jsh lo edita otra tarea a la vez)
C3_I18N_ES["the flight through the galaxy"] = "el vuelo por la galaxia";
C3_I18N_ES["A FLIGHT THROUGH THE MILKY WAY"] = "UN VUELO POR LA VÍA LÁCTEA";
C3_I18N_ES["«My flight» is made of views of the field's 3D box: in the galaxy choose Dive, Orbit or Grand tour (or switch to 3D VIEW › Field)."] =
   "«Mi vuelo» está hecho de vistas de la caja 3D del campo: en la galaxia elige Zambullida, Órbita o El gran viaje (o pasa a VISTA 3D › Campo).";
C3_I18N_ES["No star of this field has an orbit yet: the galaxy flights follow them (the status line says why)."] =
   "Ninguna estrella de este campo tiene órbita todavía: los vuelos por la galaxia van con ellas (la línea de estado dice por qué).";
C3_TOOLTIPS_EN["gx.flight.kind"] = "A flight over the galaxy map, with the stars of this field, in the view that is open (from above, edge-on or 3D), each with its own projection. «Dive» comes from the whole Milky Way to the Sun and the field (in 3D it comes down from above, turning; from above and edge-on it pans and zooms in without turning); «Orbit» turns once around the vertical axis of the galaxy through the Sun, closing as a loop, at the instant of the time machine (from above the map turns around the Sun; edge-on it stays edge-on and looks from every direction in the plane; in 3D it circles the field); «Grand tour» comes in, runs the time machine to the past and to the future with the frame following the Sun along its orbit (with the clock) and goes back out to the whole galaxy. «My flight» is made of views of the field's box: only in 3D VIEW › Field.";
C3_TOOLTIPS_ES["gx.flight.kind"] = "Un vuelo sobre el mapa de la galaxia, con las estrellas de este campo, en la vista que esté abierta (desde arriba, de canto o 3D), cada una con su proyección. «Zambullida» va de la Vía Láctea entera al Sol y al campo (en 3D baja desde arriba girando; desde arriba y de canto se desplaza y se acerca sin girar); «Órbita» da una vuelta alrededor del eje vertical de la galaxia que pasa por el Sol y cierra en bucle, en el instante de la máquina del tiempo (desde arriba el mapa gira alrededor del Sol; de canto sigue de canto y mira desde todas las direcciones del plano; en 3D rodea el campo); «El gran viaje» se acerca, hace correr la máquina del tiempo al pasado y al futuro con el encuadre siguiendo al Sol por su órbita (con el reloj) y vuelve a alejarse hasta la galaxia entera. «Mi vuelo» está hecho de vistas de la caja del campo: solo en VISTA 3D › Campo.";
C3_TOOLTIPS_EN["gx.flight.play"] = "Previews the galaxy flight here, in real time, framed like the video (drawn lighter than the video, like while dragging). A click on the drawing, this button or Esc stops it and leaves the view as it was.";
C3_TOOLTIPS_ES["gx.flight.play"] = "Enseña el vuelo por la galaxia aquí mismo, a tiempo real, encuadrado como el vídeo (con el dibujo ligero de cuando se arrastra). Un clic en el dibujo, este botón o Esc lo paran y dejan la vista como estaba.";
C3_TOOLTIPS_EN["gx.flight.record"] = "Records the galaxy flight as a video, now, with the size, frame rate, title and format chosen (▾ changes them). Before it starts, the save dialog asks where to save it (cancel it and nothing is recorded). The bar at the bottom of the drawing shows the progress and the time left; the same button cancels.";
C3_TOOLTIPS_ES["gx.flight.record"] = "Graba el vuelo por la galaxia en un vídeo, ya, con el tamaño, el ritmo, el título y el formato elegidos (▾ los cambia). Antes de empezar, el cuadro de guardar pregunta dónde guardarlo (si lo cancelas no se graba nada). La barra del borde de abajo del dibujo enseña el avance y lo que queda; el mismo botón cancela.";
C3_TOOLTIPS_EN["gx.rec.what"] = "What «● Record» records in the galaxy: the flight chosen beside ▶ (over the galaxy map, in the view that is open: from above, edge-on or 3D), or the time machine (16 s: today, back to the past, forward to the future) as the photo with the galaxy in an inset, or only the galaxy, or only the photo. Size, frame rate and format: ▾. It asks where to save the video.";
C3_TOOLTIPS_ES["gx.rec.what"] = "Qué graba «● Record» en la galaxia: el vuelo elegido junto a ▶ (sobre el mapa de la galaxia, en la vista abierta: desde arriba, de canto o 3D), o la máquina del tiempo (16 s: hoy, atrás al pasado, adelante al futuro) como la foto con la galaxia en un recuadro, solo la galaxia o solo la foto. Tamaño, ritmo y formato: ▾. Pregunta dónde guardar el vídeo.";

// ---------------------------------------------------------------------------
// EL PLAN DE UN VUELO (puro salvo leer el modelo): at(s) → { mode, cam: { yaw, pitch, zoom, ox, oy, oz } (3D) | v2 (2D, c3GxfV2Px), T (años) }.
// Solo depende de la proporción. `mode`: la vista (de fábrica, la abierta: `_gxFlightMode`).
// ---------------------------------------------------------------------------
// La vista del vuelo: la que tiene abierta el usuario (top | edge | 3d). (ROJO «force3d»: siempre 3D)
CPStarfieldDock.prototype._gxFlightMode = function() {
   var m = (this.gx && this.gx.mode) ? this.gx.mode : "3d";
   if (c3GxBroken("view")) m = "top";                                    // (el mismo rojo «view» de galaxy_view.js: el panel se queda arriba)
   return (c3GxfBroken("force3d") || C3_GXV.MODES.indexOf(m) < 0) ? "3d" : m;
};
// La vista 2D del plan en un cuadro w × h: el pivote (fx, fy: fracción del cuadro) en píxeles
function c3GxfV2Px(v, w, h) {
   var o = { k: v.k, cx: v.cx, cy: v.cy, pvx: v.fx * w, pvy: v.fy * h };
   if (typeof v.rot === "number") o.rot = v.rot;
   if (typeof v.az === "number") { o.az = v.az; o.ax = v.ax; o.ay = v.ay; }
   return o;
}
CPStarfieldDock.prototype._gxFlightPlan = function(kind, D, aspect, mode) {
   var G = this._gxModel();
   if (!G || !G.stars.length || C3_GXF.KINDS.indexOf(kind) < 0 || !(D > 0)) return null;
   mode = (typeof mode === "string" && C3_GXV.MODES.indexOf(mode) >= 0 && !c3GxfBroken("force3d")) ? mode : this._gxFlightMode();
   if (mode !== "3d") return this._gxFlightPlan2D(kind, D, aspect, mode, G);
   var tm = this.tm, range = tm.range, T0 = tm.t || 0, K = C3_GXF, follow = !c3GxfBroken("follow");
   var rect = { x: 0, y: 0, w: Math.max(2, Math.round(540 * (aspect > 0 ? aspect : 16 / 9))), h: 540 };
   var V = this._gxViewOpts(G, 1, true); V.mode = "3d"; V.chrome = false; V.frame = null;
   var fx = cshGxFitView(G, V, rect, 1), box = (fx && fx.box3) ? fx.box3 : G.ext.box, f0 = cshGxCamFrame(box, rect, K.YAW_DIVE, K.PITCH_LOW).f0;
   function sunAt(Tyr) { var p = cshGxPosAt(G, -1, Tyr / 1e6, [0, 0, 0]); return [-p[1], -p[2], p[0]]; }          // (en la caja: u = −Y, v = −Z, t = X)
   function spreadAt(Tyr) {
      var tM = Tyr / 1e6, s = cshGxPosAt(G, -1, tM, [0, 0, 0]), p = [0, 0, 0], d = [], k;
      for (k = 0; k < G.stars.length; ++k) { cshGxPosAt(G, k, tM, p); var dx = p[0] - s[0], dy = p[1] - s[1], dz = p[2] - s[2]; d.push(Math.sqrt(dx * dx + dy * dy + dz * dz)); }
      d.sort(function(a, b) { return a - b; });
      return d.length ? Math.max(0.02, d[Math.floor(K.SPREAD_Q * (d.length - 1))]) : 1;
   }
   function zoomFor(r) { return Math.max(K.ZOOM_MIN, Math.min(K.ZOOM_MAX, K.FILL * Math.min(rect.w, rect.h) / 2 / (r * f0))); }
   var sT = [-range, -range / 2, 0, range / 2, range], zL = [], i;
   for (i = 0; i < sT.length; ++i) zL.push(Math.log(zoomFor(spreadAt(sT[i]))));
   function zoomAt(T) {
      if (T <= sT[0]) return Math.exp(zL[0]);
      for (var q = 1; q < sT.length; ++q) if (T <= sT[q]) return Math.exp(zL[q - 1] + (zL[q] - zL[q - 1]) * (T - sT[q - 1]) / (sT[q] - sT[q - 1]));
      return Math.exp(zL[sT.length - 1]);
   }
   var sun0 = sunAt(0);
   function topCam(yaw) { return { yaw: yaw, pitch: K.PITCH_TOP, zoom: K.ZOOM_TOP, ox: 0, oy: 0, oz: 0 }; }
   function near(T, yaw, dp) { var S = follow ? sunAt(T) : sun0; return { yaw: yaw, pitch: K.PITCH_LOW + (dp || 0), zoom: zoomAt(T), ox: S[0], oy: S[1], oz: S[2] }; }
   // de arriba (p = 0) al Sol (p = 1): el pivote llega antes (LEAD) que el travelín, que es geométrico
   function descend(p, T, y0, y1) {
      var a = c3GxfSm(Math.min(1, K.LEAD * p)), b = c3GxfSm(p), S = sunAt(T);
      return { yaw: c3GxfLerp(y0, y1, b), pitch: c3GxfLerp(K.PITCH_TOP, K.PITCH_LOW, b), zoom: Math.exp(c3GxfLerp(Math.log(K.ZOOM_TOP), Math.log(zoomAt(T)), b)), ox: S[0] * a, oy: S[1] * a, oz: S[2] * a };
   }
   // el tiempo del Grand tour (en fracción de la escala), q en [0, 1] de su vuelta: hoy → −1 → +1 → hoy, con paradas en los extremos
   function tourT(q) {
      if (q < 0.05) return 0;
      if (q < 0.33) return -c3GxfSm((q - 0.05) / 0.28);
      if (q < 0.40) return -1;
      if (q < 0.78) return -1 + 2 * c3GxfSm((q - 0.40) / 0.38);
      if (q < 0.84) return 1;
      return 1 - c3GxfSm((q - 0.84) / 0.16);
   }
   var Y = K.YAW_DIVE, at, plate;
   if (kind === "dive") {
      var h0 = Math.min(1.2, 0.12 * D), h1 = Math.min(2.0, 0.18 * D);
      plate = (T0 !== 0);
      at = function(s) {
         if (s <= h0) return { cam: topCam(0), T: T0 };
         if (s >= D - h1) return { cam: near(T0, Y + 8 * (s - (D - h1)) / h1), T: T0 };
         return { cam: descend((s - h0) / (D - h0 - h1), T0, 0, Y), T: T0 };
      };
   } else if (kind === "orbit") {
      plate = (T0 !== 0);
      at = function(s) { var u = Math.max(0, Math.min(1, s / D)); return { cam: near(T0, Y + 360 * u, 6 * Math.sin(2 * Math.PI * u)), T: T0 }; };
   } else {
      var a0 = 0.06 * D, a1 = 0.26 * D, c1 = 0.80 * D, d1 = 0.95 * D;
      plate = true;
      at = function(s) {
         if (s <= a0) return { cam: topCam(0), T: 0 };
         if (s <= a1) return { cam: descend((s - a0) / (a1 - a0), 0, 0, Y), T: 0 };
         if (s <= c1) { var q = (s - a1) / (c1 - a1), T = tourT(q) * range; return { cam: near(T, Y + (360 - Y) * q, 5 * Math.sin(2 * Math.PI * q)), T: T }; }
         if (s <= d1) return { cam: descend(1 - (s - c1) / (d1 - c1), 0, 360, 360), T: 0 };
         return { cam: topCam(360), T: 0 };
      };
   }
   var at3 = at;
   return { kind: kind, mode: "3d", D: D, at: function(s) { var a = at3(s); a.mode = "3d"; return a; }, plate: plate, range: range, T0: T0, zoom: zL.map(Math.exp), f0: f0, aspect: rect.w / rect.h };
};
// el tiempo del Grand tour (en fracción de la escala), q en [0, 1] de su vuelta: hoy → −1 → +1 → hoy, con paradas en los extremos (el de 3D, también en 2D)
function c3GxfTourT(q) {
   if (q < 0.05) return 0;
   if (q < 0.33) return -c3GxfSm((q - 0.05) / 0.28);
   if (q < 0.40) return -1;
   if (q < 0.78) return -1 + 2 * c3GxfSm((q - 0.40) / 0.38);
   if (q < 0.84) return 1;
   return 1 - c3GxfSm((q - 0.84) / 0.16);
}
// EL SOL DENTRO DEL CUADRO al acercarse en 2D: el avance a del pivote (centro y sitio en pantalla) más pequeño ≥ a0 con el que el Sol cae dentro
// del cuadro w × h con margen m. Con los aumentos fijos, la posición del Sol en pantalla es LINEAL en a: pos(a) = A + a·B por eje; con a = 1 el Sol está
// en el pivote de cerca (CX, CY), que está dentro. pos0 = el Sol con a = 0, pos1 = con a = 1 (el pivote de cerca).
function c3GxfSafeA(a0, pos0, pos1, w, h, m) {
   var a = a0, lo = [m, m], hi = [w - m, h - m];
   for (var d = 0; d < 2; ++d) {
      var A = pos0[d], B = pos1[d] - pos0[d], f = A + a0 * B;
      if (f < lo[d] && B > 0) a = Math.max(a, (lo[d] - A) / B);
      else if (f > hi[d] && B < 0) a = Math.max(a, (hi[d] - A) / B);
   }
   return Math.max(0, Math.min(1, a));
}
// EL PLAN EN 2D (desde arriba o de canto): at(s) → { mode, v2: { k, cx, cy, fx, fy [, rot] [, az, ax, ay] }, T }. Mismo guion que en 3D (mismas
// paradas, mismo LEAD, mismo FILL, mismo tourT), con la proyección de la vista: el encuadre de fábrica de G.ext (sin encuadre de la nube: los aumentos
// los pone el vuelo), el centro en kpc de la vista (arriba: u = −Y, X; de canto: R, z) y el pivote en pantalla.
CPStarfieldDock.prototype._gxFlightPlan2D = function(kind, D, aspect, mode, G) {
   var tm = this.tm, range = tm.range, T0 = tm.t || 0, K = C3_GXF, follow = !c3GxfBroken("follow"), top = (mode === "top");
   var rect = { x: 0, y: 0, w: Math.max(2, Math.round(540 * (aspect > 0 ? aspect : 16 / 9))), h: 540 }, W = rect.w, H = rect.h, sh = Math.min(W, H);
   var X1 = top ? cshGxTopXf(G, rect, null) : cshGxEdgeXf(G, rect, null);
   var s1x = top ? X1.ppk : X1.sx, s1y = top ? X1.ppk : X1.sz, c0 = top ? [X1.ca, X1.cb] : [X1.cR, X1.cz], fl = cshGxBroken("flip") ? -1 : 1;
   // dónde está en la vista (kpc) lo que está en (X, Y, Z): arriba (u, X); de canto (R, z)
   function vw(p) { return top ? [fl * -p[1], p[0]] : [Math.sqrt(p[0] * p[0] + p[1] * p[1]), p[2]]; }
   function sunAt(Tyr) { return vw(cshGxPosAt(G, -1, Tyr / 1e6, [0, 0, 0])); }
   // lo que ocupan las estrellas alrededor del Sol EN PANTALLA con aumentos 1 (de canto, con la distancia en el plano —vale para cualquier azimut—
   // y z con su escala), cuantil SPREAD_Q
   function spreadAt(Tyr) {
      var tM = Tyr / 1e6, s = cshGxPosAt(G, -1, tM, [0, 0, 0]), p = [0, 0, 0], d = [], k;
      for (k = 0; k < G.stars.length; ++k) {
         cshGxPosAt(G, k, tM, p);
         var dx = p[0] - s[0], dy = p[1] - s[1], dz = p[2] - s[2];
         d.push(top ? Math.sqrt(dx * dx + dy * dy) * s1x : Math.sqrt(Math.pow(Math.sqrt(dx * dx + dy * dy) * s1x, 2) + Math.pow(dz * s1y, 2)));
      }
      d.sort(function(a, b) { return a - b; });
      return d.length ? Math.max(0.5, d[Math.floor(K.SPREAD_Q * (d.length - 1))]) : sh;
   }
   // la Galaxia entera: el encuadre de fábrica (×K2_TOP), con el Sol dentro (si no cupiera, menos aumentos)
   var k0 = K.K2_TOP, S00 = sunAt(T0), m = K.SUN_M * sh;
   for (var it = 0; it < 12; ++it) {
      var x0 = W / 2 + (S00[0] - c0[0]) * s1x * k0, y0 = H / 2 - (S00[1] - c0[1]) * s1y * k0;
      if (x0 >= m && x0 <= W - m && y0 >= m && y0 <= H - m) break;
      k0 *= 0.9;
   }
   function zoomFor(r) { return Math.max(k0, Math.min(K.K2_MAX, K.FILL * sh / 2 / r)); }
   var sT = [-range, -range / 2, 0, range / 2, range], zL = [], i;
   for (i = 0; i < sT.length; ++i) zL.push(Math.log(zoomFor(spreadAt(sT[i]))));
   function zoomAt(T) {
      if (T <= sT[0]) return Math.exp(zL[0]);
      for (var q = 1; q < sT.length; ++q) if (T <= sT[q]) return Math.exp(zL[q - 1] + (zL[q] - zL[q - 1]) * (T - sT[q - 1]) / (sT[q] - sT[q - 1]));
      return Math.exp(zL[sT.length - 1]);
   }
   var sun0 = sunAt(0);
   function whole() { return { k: k0, cx: c0[0], cy: c0[1], fx: 0.5, fy: 0.5 }; }
   function near(T) { var S = follow ? sunAt(T) : sun0; return { k: zoomAt(T), cx: S[0], cy: S[1], fx: K.CX, fy: K.CY }; }
   // de la Galaxia entera (p = 0) al Sol (p = 1): los aumentos, geométricos; el centro y el pivote en pantalla, con el avance a (LEAD) y nunca menos
   // del que deja al Sol dentro del cuadro (c3GxfSafeA)
   function descend(p, T) {
      var b = c3GxfSm(p), k = Math.exp(c3GxfLerp(Math.log(k0), Math.log(zoomAt(T)), b)), S = sunAt(T), a = c3GxfSm(Math.min(1, K.LEAD * p));
      if (!c3GxfBroken("nosafe")) {
         var p0 = [W / 2 + (S[0] - c0[0]) * s1x * k, H / 2 - (S[1] - c0[1]) * s1y * k];
         a = c3GxfSafeA(a, p0, [K.CX * W, K.CY * H], W, H, m);
      }
      return { k: k, cx: c0[0] + (S[0] - c0[0]) * a, cy: c0[1] + (S[1] - c0[1]) * a, fx: c3GxfLerp(0.5, K.CX, a), fy: c3GxfLerp(0.5, K.CY, a) };
   }
   var at, plate, turn = c3GxfBroken("noloop") ? 350 : 360;
   if (kind === "dive") {
      var h0 = Math.min(1.2, 0.12 * D), h1 = Math.min(2.0, 0.18 * D);
      plate = (T0 !== 0);
      at = function(s) {
         if (s <= h0) return { v2: whole(), T: T0 };
         if (s >= D - h1) return { v2: near(T0), T: T0 };
         return { v2: descend((s - h0) / (D - h0 - h1), T0), T: T0 };
      };
   } else if (kind === "orbit") {
      // la vuelta alrededor del eje vertical que pasa por el Sol (del instante): arriba, el mapa gira en su plano; de canto, el azimut de la mirada
      plate = (T0 !== 0);
      var Sx = cshGxPosAt(G, -1, T0 / 1e6, [0, 0, 0]);
      at = function(s) {
         var u = Math.max(0, Math.min(1, s / D)), v = near(T0);
         if (top) v.rot = turn * u; else { v.az = turn * u; v.ax = Sx[0]; v.ay = Sx[1]; }
         return { v2: v, T: T0 };
      };
   } else {
      var a0 = 0.06 * D, a1 = 0.26 * D, c1 = 0.80 * D, d1 = 0.95 * D;
      plate = true;
      at = function(s) {
         if (s <= a0) return { v2: whole(), T: 0 };
         if (s <= a1) return { v2: descend((s - a0) / (a1 - a0), 0), T: 0 };
         if (s <= c1) { var T = c3GxfTourT((s - a1) / (c1 - a1)) * range; return { v2: near(T), T: T }; }
         if (s <= d1) return { v2: descend(1 - (s - c1) / (d1 - c1), 0), T: 0 };
         return { v2: whole(), T: 0 };
      };
   }
   var at2 = at;
   return { kind: kind, mode: mode, D: D, at: function(s) { var a = at2(s); a.mode = mode; a.cam = null; return a; }, plate: plate, range: range, T0: T0,
            zoom: zL.map(Math.exp), k0: k0, aspect: rect.w / rect.h };
};

// ---------------------------------------------------------------------------
// UN FOTOGRAMA del vuelo en `bmp` (lo usan la vista previa y el vídeo). o = { light, plate, corner, reserve }. Devuelve lo pintado (cshGxPaintOver).
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._gxFlightFrame = function(bmp, at, o) {
   o = o || {};
   var G = this._gxModel(), w = bmp.width, h = bmp.height, sc = c3GxfSc(w, h), tm = this.tm, saveT = tm.t, R = null, mode = at.mode || "3d";
   tm.t = at.T;
   try {
      var V = this._gxViewOpts(G, sc, o.light === true, { autoSel: !c3GxBroken("extreme") });
      V.mode = mode; V.chrome = false; V.frame = null; V.legendOn = true; V.bgInt = cpInt(CP_ATLAS.bg); V.legendCompact = true;
      if (mode === "3d") V.cam = c3GxfCamPx(at.cam, w, h);
      else {
         // (2D: la vista del plan en un v2 NUEVO —el del usuario, gx.v2, no se toca—; sin el encuadre de la nube: los aumentos los pone el vuelo)
         V.fitWin = null; V.v2 = { top: null, edge: null }; V.v2[mode] = c3GxfV2Px(at.v2, w, h);
      }
      if (c3GxfBroken("norestore")) { if (mode === "3d") this.gx.cam = V.cam; else this.gx.v2[mode] = V.v2[mode]; }        // (ROJO «norestore»)
      if (o.plate === true && c3ClkOn() && !c3GxfBroken("clock")) { V.plateK = c3ClkPlateK(); V.plateA = c3ClkPlateA(); this._gxClockPlate(V, w, h); V.plate3At = o.corner || "tl"; V.plateAt = (mode === "3d") ? "" : (o.corner || "tl"); }
      else { V.plate = null; V.plateMax = null; }
      if (o.reserve) V.reserve = o.reserve;
      if (!this.gx.fcache) this.gx.fcache = {};
      bmp.fill(cpInt(CP_ATLAS.bg));
      var g = new Graphics(bmp);
      try {
         g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
         if (G) {
            var S = cshGxStaticDraw(g, this.gx.fcache, w, h, G, sc, V), C2 = cshGxCloneCtx(S.C);
            cshGxPaintDynamic(g, w, h, G, sc, V, C2);
            R = cshGxPaintOver(g, w, h, G, sc, V, C2);
         } else R = cshGalaxyPaint(g, w, h, null, sc, V);
      } finally { g.end(); }
      this.gx.lastFlight = { R: R, mode: mode, cam: (mode === "3d") ? V.cam : null, v2: (mode === "3d") ? null : V.v2[mode], T: at.T, plate: !!(V.plate && V.plate.length), corner: V.plate3At || "" };
   } finally { tm.t = saveT; }
   this.gx.flightFrames = (this.gx.flightFrames || 0) + 1;
   return R;
};
// LA ESQUINA DE LA PLACA con el reloj para todo el vuelo: arriba o abajo a la izquierda (arriba a la derecha va la leyenda; en vertical, arriba), la de
// menos estrellas debajo en nueve momentos del vuelo con su cámara (el criterio del vídeo: abajo solo si tiene menos del 80 %). Una vez por vuelo.
// (26-oct, tres vistas) En 2D se cuenta con la proyección REAL de cada momento (cshGxProjector con el v2 del plan: lo mismo que pinta el fotograma):
// cuántas estrellas (y el Sol, que vale 50) caen en cada caja de `boxes` en nueve momentos del vuelo, en un cuadro w × h. (ROJO «corner1»: solo el primero)
CPStarfieldDock.prototype._gxFlightCount2D = function(plan, w, h, boxes, tot) {
   var G = this._gxModel(), rect = { x: 0, y: 0, w: w, h: h }, nJ = c3GxfBroken("corner1") ? 0 : 8, j;
   tot = tot || {};
   if (!G) return tot;
   for (j = 0; j <= nJ; ++j) {
      var a = plan.at(plan.D * j / 8), Vj = { mode: plan.mode, v2: { top: null, edge: null } };
      Vj.v2[plan.mode] = c3GxfV2Px(a.v2, w, h);
      var P = cshGxProjector(G, Vj, rect);
      c3ClkpGxCount(G, { px: P.pt }, a.T / 1e6, boxes, tot);
   }
   return tot;
};
CPStarfieldDock.prototype._gxFlightCorner = function(plan, w, h) {
   if (!plan || !plan.plate || !c3ClkOn() || c3GxfBroken("clock") || h > w) return "tl";
   var G = this._gxModel(), sc = c3GxfSc(w, h), tm = this.tm, saveT = tm.t, tot = { tl: 0, bl: 0 }, j;
   if (!G) return "tl";
   if (plan.mode && plan.mode !== "3d") {
      try {
         tm.t = plan.T0;
         var V2 = this._gxViewOpts(G, sc, false); V2.mode = plan.mode; V2.chrome = false; V2.frame = null; V2.fitWin = null; V2.legendOn = true; V2.plateK = c3ClkPlateK(); V2.plateA = c3ClkPlateA();
         this._gxClockPlate(V2, w, h);
         var rect2 = cshGxLayout(w, h, sc, V2).rect, pl2 = V2.plateMax || V2.plate;
         var boxes2 = { tl: cshGxPlate(null, null, pl2, rect2, sc, true, "tl", V2.plateK), bl: cshGxPlate(null, null, pl2, rect2, sc, true, "bl", V2.plateK) };
      } finally { tm.t = saveT; }
      tot = this._gxFlightCount2D(plan, w, h, boxes2, tot);
      this.gx.flightCornerTot = tot;
      return (c3ClkBroken("corner") ? (tot.bl > tot.tl) : (tot.bl < tot.tl * 0.8)) ? "bl" : "tl";
   }
   try {
      tm.t = plan.T0;
      var V = this._gxViewOpts(G, sc, false); V.mode = "3d"; V.chrome = false; V.frame = null; V.legendOn = true; V.plateK = c3ClkPlateK(); V.plateA = c3ClkPlateA();
      this._gxClockPlate(V, w, h);
      var rect = cshGxLayout(w, h, sc, V).rect, fx = cshGxFitView(G, V, rect, sc), box = (fx && fx.box3) ? fx.box3 : G.ext.box, pl = V.plateMax || V.plate;
      var boxes = { tl: cshGxPlate(null, null, pl, rect, sc, true, "tl", V.plateK), bl: cshGxPlate(null, null, pl, rect, sc, true, "bl", V.plateK) };
      for (j = 0; j <= 8; ++j) { var a = plan.at(plan.D * j / 8); c3ClkpGxCount(G, cshGxCam(box, rect, c3GxfCamPx(a.cam, w, h)), a.T / 1e6, boxes, tot); }
   } finally { tm.t = saveT; }
   var red = c3ClkBroken("corner");
   this.gx.flightCornerTot = tot;
   return (red ? (tot.bl > tot.tl) : (tot.bl < tot.tl * 0.8)) ? "bl" : "tl";
};
// EL TÍTULO al principio (en la esquina de abajo que no ocupa la placa) y el fundido a negro al final. Devuelve la caja del título (o null).
function c3GxfChrome(g, w, h, s, D, title, corner) {
   var sc = Math.min(w, h) / CP_FLP.REF_H, mx = Math.round(w * CP_FLP.MARGIN), base = Math.round(h * CP_FLP.BASE), out = null;
   var sp = cpCapsSpacing(CP_FLP.T_CAPS * h), Fc = cpFont("text", CP_FLP.T_CAPS * h, true, false, sp), Ft = cpFont("text", CP_FLP.T_TITLE * h);
   function ss(a, b) { var u = Math.max(0, Math.min(1, (s - a) / (b - a))); return u * u * (3 - 2 * u); }
   var ta = ss(0.2, 0.9) * (1 - ss(C3_GXF.TITLE_S - 0.6, C3_GXF.TITLE_S)), caps = optT("A FLIGHT THROUGH THE MILKY WAY");
   if (ta > 0.004 && title) {
      var capsW = Fc.width(caps) + Math.max(0, caps.length - 1) * sp, tW = Math.max(capsW, Ft.width(title)) + mx / 2, tY0 = base - Math.round(Ft.ascent * 1.35) - Fc.ascent - mx / 4;
      var tx0 = (corner === "bl") ? w - mx - tW + mx / 4 : mx;
      out = { x0: tx0 - mx / 4, y0: tY0, x1: tx0 + tW, y1: base + Ft.descent + mx / 4 };
      g.fillRect(new Rect(out.x0, out.y0, out.x1, out.y1), new Brush(cpInt(CP_FLP_BLACK, 0.45 * ta)));
      cpFlPaintText(g, { sc: sc }, Fc, CP_INT_AMBER, tx0, base - Math.round(Ft.ascent * 1.35), caps, ta);
      cpFlPaintText(g, { sc: sc }, Ft, CP_INT_TEXT, tx0, base, title, ta);
   }
   var fade = ss(D - C3_GXF.FADE_S, D);
   if (fade > 0.004) g.fillRect(new Rect(0, 0, w, h), new Brush(cpInt(CP_FLP_BLACK, 0.85 * fade)));
   return out;
}

// ---------------------------------------------------------------------------
// EL GRABADOR: la forma de cpFlRecorder (ui/starfield_flight_paint.js) para que `_flightRecordStep`, `_flightRecordShow`, «Cancel» y
// `_flightRecordEnd` sean los de siempre. MP4 con ffmpeg (AVI intermedio en la carpeta temporal → cpAviToMp4), AVI si no; si ffmpeg falla,
// el AVI se queda junto al sitio pedido; cancelar borra lo escrito.
// ---------------------------------------------------------------------------
function c3GxFlightRecorder(dock, plan, opts) {
   var o = opts || {}, w = Math.round(o.width || 1920), h = Math.round(o.height || 1080), fps = (o.fps === 60) ? 60 : 30, D = plan.D;
   var n = Math.max(2, Math.round(D * fps)), R = { ok: false, why: "", n: n, k: 0, done: true, plan: { fps: fps, n: n }, result: null, galaxy: true, kind: plan.kind,
             step: function() { return false; }, cancel: function() {}, finishNow: function() {} };
   if ((w % 2) || (h % 2) || w < 16 || h < 16) { R.why = "bad frame size"; return R; }
   var title = String(o.title || ""), corner = dock._gxFlightCorner(plan, w, h);
   R.corner = corner;
   var mp4 = (o.format !== "avi") && cpAviFfmpeg().available, baseP = String(o.path).split("\\").join("/").replace(/\.(avi|mp4)$/i, "");
   var outPath = baseP + (mp4 ? ".mp4" : ".avi"), aviPath = mp4 ? File.systemTempDirectory.split("\\").join("/") + "/c3_gxflight_" + Date.now() + ".avi" : outPath;
   var quality = mp4 ? CP_AVI.MP4_SOURCE_QUALITY : 92, W = null, out = null, t0 = Date.now(), paintMs = 0;
   R.format = mp4 ? "mp4" : "avi";
   try { W = cpAviOpen(aviPath, w, h, fps, {}); } catch (e) { R.why = String(e); return R; }
   out = new Bitmap(w, h);
   function frame(k) {
      var s = Math.min(D, k / fps), at = plan.at(s), GR = dock._gxFlightFrame(out, at, { light: false, plate: plan.plate, corner: corner });
      var g = new Graphics(out);
      try { g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {} R.lastTitle = c3GxfChrome(g, w, h, s, D, title, corner); } finally { g.end(); }
      R.lastAt = at; R.lastR = GR; R.lastS = s;
      return out;
   }
   R.paint = frame;
   function finish(cancelled, why) {
      if (R.done) return;
      R.done = true;
      var c = W.close(), files = c.files, bytes = c.bytes, format = "avi", enc = null, i;
      try { if (out) out.clear(); } catch (eO) {} out = null;
      try { cshGxStaticFree(dock.gx.fcache); } catch (eF) {}
      if (mp4 && c.ok && !cancelled && !why) {
         var parts = [];
         for (i = 0; i < c.files.length; ++i) parts.push(c.files[i].path);
         var mo = o.mp4 || {};
         enc = cpAviToMp4(parts, outPath, { crf: mo.crf, preset: mo.preset, encoder: mo.encoder, timeoutS: mo.timeoutS, onTick: o.onEncode });
         if (enc.ok) { for (i = 0; i < parts.length; ++i) { try { File.remove(parts[i]); } catch (eR) {} } files = [{ path: outPath, frames: c.frames, bytes: enc.bytes }]; bytes = enc.bytes; format = "mp4"; }
         else {
            var kept = [];
            try { if (File.exists(outPath)) File.remove(outPath); } catch (eX) {}
            for (i = 0; i < c.files.length; ++i) { var dst = cpAviPartPath(baseP + ".avi", i + 1), moved = false; try { File.move(c.files[i].path, dst); moved = File.exists(dst); } catch (eM) {} kept.push({ path: moved ? dst : c.files[i].path, frames: c.files[i].frames, bytes: c.files[i].bytes }); }
            files = kept; why = "mp4 failed (" + enc.why + "): the AVI is kept";
         }
      }
      if (cancelled && o.keepOnCancel !== true) { for (i = 0; i < c.files.length; ++i) { try { File.remove(c.files[i].path); } catch (eD) {} } files = []; bytes = 0; }
      R.result = { ok: (c.ok && !cancelled && !why), cancelled: cancelled, why: why || c.why, format: format, frames: c.frames, bytes: bytes, files: files, seconds: (Date.now() - t0) / 1000,
                   encodeSeconds: enc ? enc.seconds : 0, encodeHow: enc ? (enc.how || "") : "", msPerFrame: (R.k > 0) ? paintMs / R.k : 0, width: w, height: h, fps: fps, kind: plan.kind, galaxy: true };
   }
   R.ok = true; R.done = false;
   R.step = function() {
      if (R.done) return false;
      var a;
      try { var tp = Date.now(), bmp = frame(R.k); paintMs += Date.now() - tp; if (typeof o.onFrame === "function") o.onFrame(R.k, bmp); a = W.addBitmap(bmp, quality); }
      catch (e) { a = { ok: false, why: String(e) }; }
      if (!a.ok) { finish(false, a.why || "frame failed"); return false; }
      ++R.k;
      if (R.k >= R.n) { finish(false, ""); return false; }
      return true;
   };
   R.cancel = function() { finish(true, ""); };
   R.finishNow = function() { if (R.done) return; if (R.k < 1) { finish(true, ""); return; } R.partial = true; finish(false, ""); R.result.partial = true; };
   return R;
}

// ---------------------------------------------------------------------------
// LOS MANDOS de FLIGHT AND VIDEO con la Galaxia (envuelven los del campo: con la galaxia apagada, todo es lo de antes)
// ---------------------------------------------------------------------------
var C3_GXF_OLD_WHY = "Flights go through the field: switch to 3D VIEW › Field. In the galaxy, ● Record records the time machine: choose it beside ● Record.";
CPStarfieldDock.prototype._gxFlightOn = function() { return this._gxOn() && !c3GxfBroken("off"); };
var c3GxfBaseFlightSync = CPStarfieldDock.prototype._flightSync;
CPStarfieldDock.prototype._flightSync = function() {
   c3GxfBaseFlightSync.call(this);
   if (!this.fl || !this.flPanel || !this._gxOn() || this.state === null) return;
   var rec = (this.fl.rec !== null), prev = (this.fl.preview !== null), idle = !rec && !prev, tmRec = !!(this.tm && this.tm.video !== "flight"), user = (this.fl.kind === "user"), i;
   var row = [this.flCombo, this.flDurLabel, this.flDur, this.flDurUnit, this.flPlay, this.flRec, this.flOpt];
   for (i = 0; i < row.length; ++i) cpSetControlVisible(row[i], true);
   cpSetControlVisible(this.flAdd, false); cpSetControlVisible(this.flEdit, false);
   this._flightEdShow(false);
   this.fl.tipsOff = true;                       // (al volver al campo, `_flightSync` repone los tooltips de fábrica)
   var ff = cpAviFfmpeg(), sz = CP_SFFL.SIZES[this.fl.size];
   var now = " " + format(optT("Now: %s, %d fps."), sz.text, this.fl.fps) + " " + cpSfFlFormatSay(ff);
   if (!this._gxFlightOn()) {
      // (ROJO «off»: lo de antes del 26-oct)
      var why = cpWrapTooltip(optT(C3_GXF_OLD_WHY)), off = [this.flCombo, this.flDur, this.flPlay];
      for (i = 0; i < off.length; ++i) { try { off[i].enabled = false; off[i].toolTip = why; } catch (e) {} }
      try { this.flRec.enabled = rec || (tmRec && !prev); this.flRec.toolTip = tmRec ? cpTooltip("gx.record") : why; } catch (e1) {}
   } else {
      var whyU = cpWrapTooltip(optT("«My flight» is made of views of the field's 3D box: in the galaxy choose Dive, Orbit or Grand tour (or switch to 3D VIEW › Field)."));
      this.fl.building = true;
      try {
         this.flCombo.currentItem = Math.max(0, CP_SFFL.KINDS.indexOf(this.fl.kind));
         var dtx = String(Math.round(this._flightDuration()));
         if (String(this.flDur.text) !== dtx) this.flDur.text = dtx;
      } catch (eB) {} finally { this.fl.building = false; }
      try {
         this.flCombo.enabled = idle; this.flCombo.toolTip = cpTooltip("gx.flight.kind");
         this.flDur.enabled = idle && !user; this.flDur.toolTip = user ? whyU : cpTooltip("sf.flight.duration"); this.flDurLabel.toolTip = this.flDur.toolTip;
         this.flPlay.text = prev ? ("■ " + optT("Stop")) : ("▶ " + optT("Preview")); cpStyleToggle(this.flPlay, prev);
         this.flPlay.enabled = !rec && !user; this.flPlay.toolTip = user ? whyU : cpTooltip("gx.flight.play");
         this.flRec.enabled = rec || (!prev && (tmRec || !user));
         this.flRec.toolTip = tmRec ? cpWrapTooltip(cpTooltipText("gx.record") + now) : (user ? whyU : cpWrapTooltip(cpTooltipText("gx.flight.record") + now));
      } catch (e2) {}
   }
   try {
      this.flRec.text = rec ? ("■ " + optT("Cancel")) : ("● " + optT("Record"));
      cpStyleToggle(this.flRec, rec);
      this.flOpt.enabled = idle;
      this.recWhat.enabled = !rec;
   } catch (e3) {}
   // las opciones ▾ (tamaño, fps, título, formato): las de siempre, también aquí
   var strip = this.fl.strip && idle, st2 = [this.flPanel, this.flSizeLabel, this.flSize, this.flFps, this.flTitleLabel, this.flTitle, this.flFmtLabel, this.flFmt, this.flFfPick];
   for (i = 0; i < st2.length; ++i) cpSetControlVisible(st2[i], strip);
   if (typeof this._flightFmtSync === "function") this._flightFmtSync(ff, strip);      // (3-nov, CPD C3) el formato y su «…», también en la Galaxia
   cpStyleToggle(this.flOpt, strip);
   if (strip) {
      this.fl.building = true;
      try {
         this.flTitle.text = (this.fl.title.length > 0) ? this.fl.title : this._flightTitle();
         this.flSize.currentItem = this.fl.size; this.flFps.currentItem = Math.max(0, CP_SFFL.FPS.indexOf(this.fl.fps));
      } finally { this.fl.building = false; }
      this._flightPanelPlace();
   }
};
// «Qué grabar», con la galaxia: «el vuelo por la galaxia» y su tooltip; al volver al campo, los de siempre
CPStarfieldDock.prototype._gxRecWhatSync = function() {
   if (!this.gx || !this.recWhat) return;
   var on = this._gxFlightOn();
   try {
      var w0 = on ? optT("the flight through the galaxy") : optT("the flight");
      if (this.recWhat.itemText(0) !== w0) this.recWhat.setItemText(0, w0);
      this.recWhat.toolTip = cpTooltip(this._gxOn() ? "gx.rec.what" : "rec.what");
   } catch (e) {}
};
var c3GxfBaseGxSync = CPStarfieldDock.prototype._gxSync;
CPStarfieldDock.prototype._gxSync = function() { c3GxfBaseGxSync.call(this); this._gxRecWhatSync(); };
var c3GxfBaseTmItems = CPStarfieldDock.prototype._tmItems;
CPStarfieldDock.prototype._tmItems = function() { c3GxfBaseTmItems.call(this); this._gxRecWhatSync(); };

// La duración: la de cada vuelo de la galaxia, aparte de las del campo
CPStarfieldDock.prototype._gxFlightDur = function(kind) {
   if (!this.fl.gxDur) this.fl.gxDur = {};
   return (this.fl.gxDur[kind] > 0) ? this.fl.gxDur[kind] : (C3_GXF.DUR[kind] || C3_GXF.DUR.dive);
};
var c3GxfBaseDuration = CPStarfieldDock.prototype._flightDuration;
CPStarfieldDock.prototype._flightDuration = function() {
   if (!this._gxFlightOn()) return c3GxfBaseDuration.call(this);
   return this._gxFlightDur((this.fl.kind === "user") ? "dive" : this.fl.kind);
};
var c3GxfBaseSetDuration = CPStarfieldDock.prototype.flightSetDuration;
CPStarfieldDock.prototype.flightSetDuration = function(seconds) {
   if (!this._gxFlightOn()) return c3GxfBaseSetDuration.call(this, seconds);
   if (this.flightBusy() || this.fl.kind === "user") { this._flightSync(); return; }
   if (!this.fl.gxDur) this.fl.gxDur = {};
   this.fl.gxDur[this.fl.kind] = Math.max(CP_SFFL.DUR_MIN, Math.min(CP_SFFL.DUR_MAX, Math.round(Number(seconds) || 0)));
   this._flightSync();
};
// ¿Se puede volar la galaxia AHORA? "" o por qué no (dicho en la píldora)
var c3GxfBaseWhyNot = CPStarfieldDock.prototype._flightWhyNot;
CPStarfieldDock.prototype._flightWhyNot = function() {
   if (!this._gxOn()) return c3GxfBaseWhyNot.call(this);
   var why = "";
   if (!this._gxFlightOn()) why = optT(C3_GXF_OLD_WHY);
   else if (this.state === null) why = optT("Open «Distances» in perspective first.");
   else if (this._netBusy || this._netPending()) why = optT("Still waiting for the online data: try again in a moment.");
   else if (this.fl.kind === "user") why = optT("«My flight» is made of views of the field's 3D box: in the galaxy choose Dive, Orbit or Grand tour (or switch to 3D VIEW › Field).");
   else { var G = this._gxModel(); if (!G || !G.stars.length) why = optT("No star of this field has an orbit yet: the galaxy flights follow them (the status line says why)."); }
   if (why.length > 0) this._flightSay(why, (why === optT(C3_GXF_OLD_WHY)) ? "error" : "pending");
   return why;
};

// ▶ LA VISTA PREVIA en el lienzo, a tiempo real (el mismo tic, el mismo «Stop» y el mismo clic que la del campo)
var c3GxfBasePreview = CPStarfieldDock.prototype.flightPreview;
CPStarfieldDock.prototype.flightPreview = function() {
   if (!this._gxOn()) return c3GxfBasePreview.call(this);
   if (this.fl.rec !== null || this.fl.preview !== null || this._flightWhyNot() !== "") return false;
   this._animStop(); if (this._tmStopAnims) { try { this._tmStopAnims(); } catch (eS) {} }
   var w = 0, h = 0;
   try { w = this.canvas.width; h = this.canvas.height; } catch (e) {}
   if (!(w > 32 && h > 32)) return false;
   var aspect = this._flightAspect(), rect = this._flightRect(w, h, aspect), plan = this._gxFlightPlan(this.fl.kind, this._flightDuration(), aspect);
   if (plan === null) return false;
   var pw = Math.min(rect.w, C3_GXF.PREVIEW_MAX_W), ph = Math.max(2, Math.round(pw / aspect));
   pw -= pw % 2; ph -= ph % 2;
   var fb = new Bitmap(Math.max(2, pw), Math.max(2, ph)), buf = new Bitmap(w, h);
   this.fl.preview = { gx: true, P: null, plan: plan, flight: { duration: plan.D }, t0: CP_SF_FLIGHT_CLOCK(), frames: 0, w: w, h: h, rect: rect, fb: fb, buf: buf,
                       corner: this._gxFlightCorner(plan, fb.width, fb.height), title: (this.fl.title.length > 0) ? this.fl.title : this._flightTitle(), ms: 0 };
   this._flightSync();
   this._flightFrame(0);
   this.flTimer.interval = CP_SFFL.PREVIEW_TICK_S;
   try { this.flTimer.start(); } catch (e2) {}
   return true;
};
var c3GxfBaseFrame = CPStarfieldDock.prototype._flightFrame;
CPStarfieldDock.prototype._flightFrame = function(t) {
   var pv = this.fl.preview;
   if (!pv || !pv.gx) return c3GxfBaseFrame.call(this, t);
   var t0 = Date.now(), s = Math.max(0, Math.min(pv.plan.D, t)), at = pv.plan.at(s), fb = pv.fb, r = pv.rect;
   this._gxFlightFrame(fb, at, { light: true, plate: pv.plan.plate, corner: pv.corner });
   var g = new Graphics(fb);
   try { g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {} c3GxfChrome(g, fb.width, fb.height, s, pv.plan.D, pv.title, pv.corner); } finally { g.end(); }
   pv.buf.fill(CP_INT_SURFACE);
   var g2 = new Graphics(pv.buf);
   try {
      g2.smoothInterpolation = true;
      g2.fillRect(new Rect(0, 0, pv.w, pv.h), new Brush(cpInt(CP_FLP_BLACK, CP_FLP.OUTSIDE)));
      if (fb.width === r.w && fb.height === r.h) g2.drawBitmap(r.x, r.y, fb); else g2.drawScaledBitmap(new Rect(r.x, r.y, r.x + r.w, r.y + r.h), fb);
      g2.pen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1); g2.brush = new Brush(0x00000000); g2.drawRect(r.x, r.y, r.x + r.w - 1, r.y + r.h - 1);
   } finally { g2.end(); }
   this.fl.show = pv.buf;
   ++pv.frames; pv.ms = Date.now() - t0; pv.lastAt = at; pv.lastS = s;
   try { this.canvas.repaint(); } catch (e) {}
};
var c3GxfBaseStop = CPStarfieldDock.prototype.flightStop;
CPStarfieldDock.prototype.flightStop = function() {
   var pv = (this.fl && this.fl.rec === null) ? this.fl.preview : null;
   var r = c3GxfBaseStop.call(this);
   if (pv && pv.gx && this.fl.preview === null) {
      try { pv.fb.clear(); } catch (e) {} try { pv.buf.clear(); } catch (e2) {}
      pv.fb = null; pv.buf = null;
      try { cshGxStaticFree(this.gx.fcache); } catch (e3) {}
   }
   return r;
};
// ● GRABAR el vuelo por la galaxia: el flujo de flightRecordStart del campo con el grabador de la galaxia
var c3GxfBaseRecordStart = CPStarfieldDock.prototype.flightRecordStart;
CPStarfieldDock.prototype.flightRecordStart = function(opts) {
   if (!this._gxOn()) return c3GxfBaseRecordStart.call(this, opts);
   var o = opts || {}, out = { ok: false, why: "" };
   if (this.fl.rec !== null || this.fl.preview !== null) { out.why = "busy"; return out; }
   out.why = this._flightWhyNot();
   if (out.why !== "") return out;
   this._animStop(); if (this._tmStopAnims) { try { this._tmStopAnims(); } catch (eS) {} }
   try { if (this.fl.strip) { var tt = String(this.flTitle.text || ""); this.fl.title = (tt === this._flightTitle()) ? "" : tt; } } catch (e) {}
   var size = (o.width > 0 && o.height > 0) ? { w: o.width, h: o.height } : CP_SFFL.SIZES[this.fl.size], fps = (o.fps > 0) ? o.fps : this.fl.fps;
   var title = String((o.title !== undefined) ? o.title : (this.fl.title || this._flightTitle()));
   var plan = this._gxFlightPlan(this.fl.kind, this._flightDuration(), size.w / size.h), R = null, self2 = this;
   if (plan === null) { out.why = optT("No star of this field has an orbit yet: the galaxy flights follow them (the status line says why)."); this._flightSay(out.why, "error"); return out; }
   var ftag = c3GxfBroken("tag") ? "galaxy_" + this.fl.kind : "galaxy_" + (plan.mode || "3d") + "_" + this.fl.kind;          // (como _gxVideoTag: la vista en el nombre; ROJO «tag»: sin ella)
   var tg = this._flightTarget(o, title, ftag, size);           // (6-nov, revision PTeam CPD) DONDE SE GUARDA: se pregunta ANTES de grabar
   if (!tg.ok) { out.why = tg.why; return out; }
   var dir = tg.dir;
   out.dir = dir;
   try { R = c3GxFlightRecorder(this, plan, { path: tg.path, format: o.format, width: size.w, height: size.h, fps: fps, title: title, mp4: o.mp4,
                                              onFrame: function(k, bmp) { self2._flightRecordShow(k, bmp); } }); } catch (e2) { R = { ok: false, why: String(e2) }; }
   if (!R.ok) { out.why = R.why; this._flightSay(optT("Could not record the flight") + ": " + R.why, "error"); return out; }
   var w = 0, h = 0;
   try { w = this.canvas.width; h = this.canvas.height; } catch (e3) {}
   this.fl.rec = { R: R, dir: dir, t0: Date.now(), shownAt: 0, w: w, h: h, rect: this._flightRect(Math.max(2, w), Math.max(2, h), size.w / size.h), buf: (w > 8 && h > 8) ? new Bitmap(w, h) : null,
                   locked: null, encoding: false, gx: true };
   this.fl.strip = false;
   try { this.fl.rec.locked = this.dialog._batchLock(); } catch (e4) {}
   this._flightDockLock(true);
   this._flightSync();
   this._flightSay(format(optT("Recording the flight to %s"), dir), "pending", dir);
   this.flTimer.interval = CP_SFFL.RECORD_TICK_S;
   try { this.flTimer.start(); } catch (e5) {}
   out.ok = true;
   return out;
};
// Al cerrar: la capa fija de los vuelos, libre
var c3GxfBaseCleanup = CPStarfieldDock.prototype.cleanup;
CPStarfieldDock.prototype.cleanup = function() {
   if (this.gx) { try { cshGxStaticFree(this.gx.fcache); } catch (e) {} }
   try { c3ClkpFree(); } catch (e2) {}
   return c3GxfBaseCleanup.call(this);
};
