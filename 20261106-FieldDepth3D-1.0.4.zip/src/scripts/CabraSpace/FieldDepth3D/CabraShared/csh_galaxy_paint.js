#ifndef __CSH_GALAXY_PAINT_JS
#define __CSH_GALAXY_PAINT_JS
// ============================================================================
// CabraShared/csh_galaxy_paint.js — LA GALAXIA: el DIBUJO del mapa (desde arriba, de canto, 3D) (23-oct-2026)
// ----------------------------------------------------------------------------
// PROCEDENCIA: COPIA de CabraComposition/src/ui/cc_galaxy_paint.js (fase 2b del 22-oct-2026, árbol de trabajo sin commit), con los
// nombres de ccGx… a cshGx…; los ayudantes de color y letra son los de csh_atlas.js (cpInt, cpFont, cpMix, cpHexRgb, cpElide) y el
// idioma el de csh_i18n.js (cshLangIsEs). Lo cambiado, a sabiendas:
//   · TRES capas (CabraComposition tenía dos): la FIJA (resplandor, referencia, órbitas, la órbita del Sol, el giro, el centro: lo
//     caro, que no depende del instante ni de la elegida; se guarda en un bitmap: `cshGxStatic`), la del INSTANTE (dónde está cada
//     estrella y el Sol a tMyr, y su estela: la máquina del tiempo de Cabra3D la repinta en cada fotograma) y ENCIMA (la elegida,
//     la leyenda, la escala, la placa del instante, los rótulos). Así reproducir la máquina del tiempo o elegir una estrella no
//     vuelve a trazar 300 órbitas.
//   · el COLOR lo pone el script (`V.colorOf(e) -> { rgb, hollow }` y su leyenda `V.legend`): CabraComposition colorea por población,
//     edad o [Fe/H]; Cabra3D por el color de Gaia o la distancia.
//   · las órbitas fijas se pintan CENTRADAS en hoy si hay pasado guardado (−210 … +210 Myr): la máquina del tiempo va hacia los dos
//     lados y la estrella sigue sobre su órbita dibujada.
//   · `V.frame` (el rectángulo del mapa dentro de un lienzo ajeno: Cabra3D pinta su propia cabecera y su pie) y `V.plate` (las líneas
//     de la placa del instante, arriba a la izquierda del mapa).
// RÓTULOS SIN PISARSE: la rejilla de ocupación de CabraComposition (celdas de 4 px lógicos; lo duro no se pisa nunca, lo blando —los
// puntos y las órbitas— se esquiva si se puede; un rótulo sin sitio no se pinta y R.dropped lo cuenta).
// Necesita csh_atlas.js, csh_i18n.js, csh_galdyn.js, csh_galaxy.js y csh_galaxy_i18n.js antes. ES5 (Graphics de PJSR).
// (24-oct-2026, V7f) EL POLVO de la Galaxia: con V.dust === true y csh_galaxy_dust.js (+ data/csh_galaxy_dust_grid.js) incluidos antes,
// una capa en la FIJA encima del resplandor (cshGxPaintDust) con su costura y tres filas de leyenda. Sin ellos, el dibujo de siempre.
// ============================================================================

function cshGxNum(x, d) {
   if (!cshGxIsNum(x)) return "—";
   var s = x.toFixed(d === undefined ? 1 : d);
   if (/^-0(\.0+)?$/.test(s)) s = s.substring(1);
   if (s.charAt(0) === "-") s = "−" + s.substring(1);
   return (cshLangIsEs() && !cshGxBroken("comma")) ? s.replace(".", ",") : s;
}
function cshGxSigned(x, d) { var s = cshGxNum(x, d); return (cshGxIsNum(x) && x >= 0 && s.charAt(0) !== "−") ? "+" + s : s; }
function cshGxNoBrush(g) { g.brush = new Brush(0x00000000); }
function cshGxPen(c, w, dash) { return (dash && typeof PenStyle_Dash !== "undefined") ? new Pen(c, w, PenStyle_Dash) : new Pen(c, w); }
function cshGxRgbInt(rgb, alpha) {
   var a = (alpha === undefined) ? 255 : Math.max(0, Math.min(255, Math.round(alpha * 255)));
   return ((a << 24) | (Math.round(rgb[0]) << 16) | (Math.round(rgb[1]) << 8) | Math.round(rgb[2])) >>> 0;
}
function cshGxLighter(rgb, t) { return [rgb[0] + (255 - rgb[0]) * t, rgb[1] + (255 - rgb[1]) * t, rgb[2] + (255 - rgb[2]) * t]; }
function cshGxInset() { return cpMix(CSH_ATLAS.bg, "#000000", 0.35); }
function cshGxBg(V) { return (V && typeof V.bgInt === "number") ? (V.bgInt >>> 0) : cpInt(CSH_ATLAS.bg); }
// La línea de la órbita de la ficha (las MISMAS cifras que la elegida: peri, apo y Zmax de 2 Gyr hacia el futuro).
function cshGxOrbitLine(o) {
   if (!o || o.bound === false || !cshGxIsNum(o.rperi) || !cshGxIsNum(o.rapo)) return "";
   // (27-oct, R2) `approx` (cshGdOrbit: la energía no se conservó ni partiendo el paso 4 veces): las cifras llevan «≈» —peri, apo, e y
   // también Zmax, que sale de la misma integración—. ROJO «noapprox» (CSH_GX_BREAK) para ver la prueba caer.
   var ap = !!o.approx && !(typeof cshGxBroken === "function" && cshGxBroken("noapprox")), q = ap ? "≈ " : "";
   return cshGxF("gxSelOrbit", { p: q + cshGxNum(o.rperi, 1), a: q + cshGxNum(o.rapo, 1), z: q + cshGxNum(o.zmax, o.zmax < 1 ? 2 : 1), e: q + cshGxNum(o.ecc, 2) });
}
// El color de fábrica de una estrella (si el script no da `V.colorOf`): crema.
function cshGxColorOf(e, V) {
   if (V && typeof V.colorOf === "function") { var c = V.colorOf(e); if (c && c.rgb) return c; }
   return { rgb: cpHexRgb(CSH_ATLAS.text), hollow: false };
}

// (28-oct-2026, H2/H3/H6 del 27-oct: la leyenda tapaba el disco en 3D, el gráfico de canto y, a ±100 Ma —con la placa—, la nube de las Pléyades a lienzo 756.
//  Decidido por Nino el 28-oct, variante A: la leyenda va en DOS COLUMNAS —el degradado y los puntos a la izquierda, los símbolos del mapa a la derecha—, más
//  ancha y la mitad de alta. Rojo CSH_GX_BREAK «onecol» = la de siempre, en una columna. Las otras variantes —translúcida, «el mapa cede su franja»— se
//  descartaron y se quitaron. Capturas de la elección: Cabra3D/capturas/montaje_28oct_H{2,3,6}.png.)

// ---------------------------------------------------------------------------
// TEXTO, apuntado en R (las pruebas leen lo pintado: idioma, comas, solapes)
// ---------------------------------------------------------------------------
function cshGxText(g, R, f, color, x, y, t) {
   g.font = f; g.pen = new Pen(color, 1); g.drawText(x, y, t);
   if (R) R.texts.push(String(t));
}
function cshGxHalo(g, R, f, color, x, y, t, sc) {
   var hc = cpInt(CSH_ATLAS.bg, 0.92), d = Math.max(1, Math.round(1.2 * sc));
   g.font = f; g.pen = new Pen(hc, 1);
   for (var dx = -1; dx <= 1; ++dx) for (var dy = -1; dy <= 1; ++dy) if (dx || dy) g.drawText(x + dx * d, y + dy * d, t);
   cshGxText(g, R, f, color, x, y, t);
}
// LA REJILLA DE OCUPACIÓN: 0 libre · 1 blando (puntos) · 2 duro (rótulos, leyenda, símbolos)
function cshGxOcc(w, h, sc) {
   var cell = Math.max(3, Math.round(4 * sc)), nx = Math.ceil(w / cell), ny = Math.ceil(h / cell);
   return { cell: cell, nx: nx, ny: ny, a: new Uint8Array(nx * ny), w: w, h: h };
}
function cshGxOccMark(O, x0, y0, x1, y1, v) {
   if (!O) return;
   // (x1, y1 EXCLUIDOS: con el borde incluido la marca del Sol tapaba los 8 sitios de su rótulo; CabraComposition, 22-oct)
   var i0 = Math.max(0, Math.floor(x0 / O.cell)), i1 = Math.min(O.nx - 1, Math.floor((x1 - 0.01) / O.cell));
   var j0 = Math.max(0, Math.floor(y0 / O.cell)), j1 = Math.min(O.ny - 1, Math.floor((y1 - 0.01) / O.cell));
   for (var j = j0; j <= j1; ++j) for (var i = i0; i <= i1; ++i) { var k = j * O.nx + i; if (O.a[k] < v) O.a[k] = v; }
}
// (29-oct-2026) `own` = [x0, y0, x1, y1] opcional: la marca del PROPIO símbolo del rótulo; sus celdas no cuentan (las mismas que marcó cshGxOccMark)
function cshGxOccCost(O, x0, y0, x1, y1, bounds, own) {
   if (bounds && (x0 < bounds.x || y0 < bounds.y || x1 > bounds.x + bounds.w || y1 > bounds.y + bounds.h)) return { hard: 1e9, soft: 0 };
   var i0 = Math.floor(x0 / O.cell), i1 = Math.floor((x1 - 0.01) / O.cell), j0 = Math.floor(y0 / O.cell), j1 = Math.floor((y1 - 0.01) / O.cell), hard = 0, soft = 0;
   var oi0 = 1, oi1 = 0, oj0 = 1, oj1 = 0;
   if (own) { oi0 = Math.floor(own[0] / O.cell); oi1 = Math.floor((own[2] - 0.01) / O.cell); oj0 = Math.floor(own[1] / O.cell); oj1 = Math.floor((own[3] - 0.01) / O.cell); }
   for (var j = j0; j <= j1; ++j) for (var i = i0; i <= i1; ++i) {
      if (i >= oi0 && i <= oi1 && j >= oj0 && j <= oj1) continue;
      if (i < 0 || j < 0 || i >= O.nx || j >= O.ny) { ++hard; continue; }
      var v = O.a[j * O.nx + i];
      if (v >= 2) ++hard; else if (v === 1) ++soft;
   }
   return { hard: hard, soft: soft };
}
// Un rótulo (una o más líneas) junto a (ax, ay): 8 sitios alrededor, a tres distancias; el primero sin nada duro y con menos puntos.
// (29-oct-2026, «el rótulo del centro galáctico salta»: Nino en el teaser de M 82) `fix` opcional = { own: [x0, y0, x1, y1] } para un rótulo que
//  tiene que quedarse QUIETO junto a su punto (el centro galáctico): (1) no mira lo blando —los puntos y las estelas de las estrellas, que se
//  mueven en cada fotograma: con ellos el «menos puntos debajo» elegía otro de los 24 sitios cada 2-3 fotogramas, 164 px de izquierda a derecha
//  con la cruz quieta, medido en tomas/es_m82/gx1ga.mp4— y (2) no se choca con la marca de su PROPIO símbolo: la cruz (±5 px lógicos) y la caja
//  mirada (a 8 − 2 = 6 px lógicos) quedan a menos de una celda (4 px lógicos), así que según la fase del punto en la rejilla la primera vuelta
//  salía tapada o libre. Queda el primero de los 24 sitios sin nada duro: siempre el mismo mientras nada duro se cruce.
//  ROJO «gcjump» (CSH_GX_BREAK): el criterio de antes.
function cshGxPlace(g, R, O, lines, ax, ay, gap, sc, bounds, fix) {
   var lw = 0, lh = 0, i;
   for (i = 0; i < lines.length; ++i) { lw = Math.max(lw, lines[i].f.width(lines[i].t)); lh += lines[i].f.ascent + lines[i].f.descent + Math.round(1 * sc); }
   var p = Math.round(2 * sc), cands = [];
   for (var ring = 0; ring < 3; ++ring) {
      var gg = gap + ring * O.cell;
      cands.push([ax + gg, ay - lh / 2], [ax - gg - lw, ay - lh / 2], [ax - lw / 2, ay - gg - lh], [ax - lw / 2, ay + gg],
                 [ax + gg * 0.7, ay - gg * 0.7 - lh], [ax - gg * 0.7 - lw, ay - gg * 0.7 - lh], [ax + gg * 0.7, ay + gg * 0.7], [ax - gg * 0.7 - lw, ay + gg * 0.7]);
   }
   if (fix && cshGxBroken("gcjump")) fix = null;
   var noGrid = cshGxBroken("labels"), best = -1, bestSoft = 1e9;
   for (i = 0; i < cands.length; ++i) {
      if (noGrid) { best = 0; break; }
      var c = cshGxOccCost(O, cands[i][0] - p, cands[i][1] - p, cands[i][0] + lw + p, cands[i][1] + lh + p, bounds, fix ? fix.own : null);
      if (fix) { if (c.hard === 0) { best = i; break; } continue; }
      if (c.hard === 0 && c.soft < bestSoft) { best = i; bestSoft = c.soft; if (c.soft === 0) break; }
   }
   if (best < 0) { R.dropped++; return null; }
   var x = cands[best][0], y = cands[best][1], yy = y;
   for (i = 0; i < lines.length; ++i) { yy += lines[i].f.ascent; cshGxHalo(g, R, lines[i].f, lines[i].c, x, yy, lines[i].t, sc); yy += lines[i].f.descent + Math.round(1 * sc); }
   var rect = { x0: x, y0: y, x1: x + lw, y1: y + lh, text: lines[0].t };
   // (28-oct-2026, pendiente 9: lo MISMO que CabraComposition arregló el 27-oct en ccGxPlace/ccGxRingLabel —E4—: se MIRA con 2 px lógicos de margen
   //  y se MARCA con 6, así que entre dos rótulos cualesquiera quedan ≥ 8 px lógicos; antes marcaba solo +2 —4 px entre dos rótulos de este camino—.
   //  ROJO «labelgap» (CSH_GX_BREAK): el margen de antes.)
   var pm = cshGxBroken("labelgap") ? p : Math.round(6 * sc);
   if (!noGrid) cshGxOccMark(O, x - pm, y - pm, x + lw + pm, y + lh + pm, 2);
   R.labels.push(rect);
   return rect;
}
// El rótulo de un círculo de distancia («10 kpc»), en el primer sitio libre de su borde (abajo a la derecha primero). Devuelve el rectángulo o null.
// (28-oct, pendiente 9: ESTE camino miraba solo ±2 px FIJOS alrededor de un rectángulo desplazado —0 px a su derecha— y marcaba +2…4 px: junto a un
//  rótulo de cshGxPlace podía quedar a ~6 px lógicos y a ~3 de otro círculo. Es el mismo defecto que CabraComposition arregló el 27-oct en
//  ccGxRingLabel (cc_galaxy_paint.js:124-149) y esta es su copia. Ahora: su caja de texto real + 2 px lógicos al mirar y + 6 al marcar. ROJO
//  «labelgap» (CSH_GX_BREAK): los márgenes de antes aquí y en cshGxPlace; «ringgap»: solo los de aquí. Función aparte para que
//  tests/c3_ring_label.js la barra con un proyector fijo.)
function cshGxRingLabel(g, R, O, P, rr2, fS, sc, bounds, color) {
   var txt = cshGxF("gxRing", { n: rr2 }), angs = [], rwT = fS.width(txt), oldGap = cshGxBroken("labelgap") || cshGxBroken("ringgap"), cpR = Math.round(2 * sc), mpR = Math.round(6 * sc);
   for (var aa = 0; aa < 18; ++aa) angs.push(-0.7 + (aa % 2 ? 1 : -1) * Math.ceil(aa / 2) * 0.35);
   for (var an = 0; an < angs.length; ++an) {
      var qr = P.pt(rr2 * Math.cos(angs[an] + Math.PI), rr2 * Math.sin(angs[an] + Math.PI), 0);
      if (!qr.ok) continue;
      var rbx0 = qr.x + 2, rby0 = qr.y - fS.ascent, rbx1 = rbx0 + rwT, rby1 = qr.y + fS.descent;
      var c0 = oldGap ? cshGxOccCost(O, qr.x - 2, qr.y - fS.ascent - 2, qr.x + rwT + 2, qr.y + 3, bounds)
                      : cshGxOccCost(O, rbx0 - cpR, rby0 - cpR, rbx1 + cpR, rby1 + cpR, bounds);
      if (c0.hard !== 0 || c0.soft !== 0) continue;
      cshGxHalo(g, R, fS, color, qr.x + 2, qr.y, txt, sc);
      if (oldGap) cshGxOccMark(O, qr.x - 2, qr.y - fS.ascent - 2, qr.x + rwT + 4, qr.y + 3, 2);
      else cshGxOccMark(O, rbx0 - mpR, rby0 - mpR, rbx1 + mpR, rby1 + mpR, 2);
      var rect = { x0: rbx0, y0: rby0, x1: rbx1, y1: rby1, text: txt };
      R.labels.push(rect);
      return rect;
   }
   return null;
}

// ---------------------------------------------------------------------------
// EL RESPLANDOR DE LA VÍA LÁCTEA (la masa del potencial: csh_galaxy.js · cshGxSigmaTable)
// ---------------------------------------------------------------------------
var CSH_GX_GLOW_CACHE = {}, CSH_GX_GLOW_N = 0, CSH_GX_GLOW_LUT = null;
function cshGxGlowRgbaOf(v) {
   if (v <= 0.12) return 0;
   var t = Math.min(1, (v - 0.12) / 0.88), c = cpHexRgb(cpMix(CSH_ATLAS.text3, CSH_ATLAS.goldLight, Math.pow(t, 1.4)));
   return cshGxRgbInt(c, Math.min(0.62, 0.62 * Math.pow(t, 1.7)));
}
// (23-oct, medido en Cabra3D/tests/c3_gx_prof.js: el color de cada celda mezclaba dos tokens en texto —cpMix + cpHexRgb— y eso era casi
//  todo el resplandor: 43 ms al arrastrar desde arriba. Ahora una tabla de 512 colores, la misma rampa)
function cshGxGlowRgba(v) {
   if (CSH_GX_GLOW_LUT === null) { CSH_GX_GLOW_LUT = new Array(513); for (var i = 0; i <= 512; ++i) CSH_GX_GLOW_LUT[i] = cshGxGlowRgbaOf(i / 512); }
   if (!(v > 0.12)) return 0;
   return CSH_GX_GLOW_LUT[Math.min(512, Math.round(v * 512))];
}
// fn(cx, cy) -> brillo 0…1 en el centro de la celda; el bitmap a celdas de `cell` px sobre `rect` (guardado por su clave: las
// ocho últimas)
function cshGxGlowBitmap(key, rect, cell, fn) {
   if (key && CSH_GX_GLOW_CACHE.hasOwnProperty(key)) return CSH_GX_GLOW_CACHE[key];
   var nx = Math.max(2, Math.ceil(rect.w / cell)), ny = Math.max(2, Math.ceil(rect.h / cell)), b = new Bitmap(nx, ny);
   b.fill(0x00000000);
   for (var j = 0; j < ny; ++j) for (var i = 0; i < nx; ++i) {
      var c = cshGxGlowRgba(fn(rect.x + (i + 0.5) * cell, rect.y + (j + 0.5) * cell));
      if (c) b.setPixel(i, j, c);
   }
   var out = { bmp: b, w: nx * cell, h: ny * cell };
   if (key) {
      if (CSH_GX_GLOW_N >= 8) { for (var k in CSH_GX_GLOW_CACHE) if (CSH_GX_GLOW_CACHE.hasOwnProperty(k)) { try { CSH_GX_GLOW_CACHE[k].bmp.clear(); } catch (eC) {} } CSH_GX_GLOW_CACHE = {}; CSH_GX_GLOW_N = 0; }
      CSH_GX_GLOW_CACHE[key] = out; ++CSH_GX_GLOW_N;
   }
   return out;
}
function cshGxGlowFree() { for (var k in CSH_GX_GLOW_CACHE) if (CSH_GX_GLOW_CACHE.hasOwnProperty(k)) { try { CSH_GX_GLOW_CACHE[k].bmp.clear(); } catch (e) {} } CSH_GX_GLOW_CACHE = {}; CSH_GX_GLOW_N = 0; cshGxDustFree(); }

// ---------------------------------------------------------------------------
// EL POLVO DE LA GALAXIA (24-oct-2026, V7f; los datos y el color: csh_galaxy_dust.js). Solo con V.dust === true y el módulo incluido:
// sin él, el mapa es el de antes. Va en la capa FIJA, justo encima del resplandor y debajo de la referencia, las órbitas, las estrellas y
// el Sol (que se leen siempre encima: el tope de opacidad del módulo). Un bitmap de celdas guardado por su clave, como el resplandor.
// ---------------------------------------------------------------------------
var CSH_GX_DUST_CACHE = {}, CSH_GX_DUST_N = 0;
function cshGxDustFree() { for (var k in CSH_GX_DUST_CACHE) if (CSH_GX_DUST_CACHE.hasOwnProperty(k)) { try { CSH_GX_DUST_CACHE[k].bmp.clear(); } catch (e) {} } CSH_GX_DUST_CACHE = {}; CSH_GX_DUST_N = 0; }
// fn(cx, cy) -> ARGB (0 = nada) en el centro de cada celda de `cell` px sobre `rect`; las seis últimas guardadas
function cshGxDustBitmap(key, rect, cell, fn) {
   if (key && CSH_GX_DUST_CACHE.hasOwnProperty(key)) { var h0 = CSH_GX_DUST_CACHE[key]; h0.cached = true; return h0; }
   var t0 = Date.now(), nx = Math.max(2, Math.ceil(rect.w / cell)), ny = Math.max(2, Math.ceil(rect.h / cell)), b = new Bitmap(nx, ny), n = 0;
   b.fill(0x00000000);
   for (var j = 0; j < ny; ++j) for (var i = 0; i < nx; ++i) {
      var c = fn(rect.x + (i + 0.5) * cell, rect.y + (j + 0.5) * cell);
      if (c) { b.setPixel(i, j, c); ++n; }
   }
   var out = { bmp: b, w: nx * cell, h: ny * cell, nx: nx, ny: ny, cell: cell, painted: n, ms: Date.now() - t0, cached: false };
   if (key) {
      if (CSH_GX_DUST_N >= 6) cshGxDustFree();
      CSH_GX_DUST_CACHE[key] = out; ++CSH_GX_DUST_N;
   }
   return out;
}
// Pinta la capa y su COSTURA (lo medido / el modelo, a trazos). Devuelve lo hecho (para las pruebas): { kind, ms, msGrid, cell, cached,
// cells, painted, seam: [ … ] } o null si no hay datos.
function cshGxPaintDust(g, P, rect, sc, V, lk) {
   if (typeof cshGxdData !== "function") return null;
   var D = cshGxdData();
   if (!D || !D.ok) return null;
   var A = CSH_ATLAS, t0 = Date.now(), o = { s: 0, m: 0, w: 0 }, q = { r: 0, f: 0 }, db = null, cell, L, mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2;
   // (26-oct, V7h) EL INSTANTE del polvo (V.dustMyr, Ma; sin él, hoy): girado con la Galaxia y perdiendo la identidad (csh_galaxy_dust.js cshGxdTime)
   var T = (typeof cshGxdTime === "function") ? cshGxdTime(V.dustMyr) : { t: 0, w: 1, live: false, model: false, key: "0" }, tk = T.key, ze = 1;
   // (la inversa de cada vista, en línea y sin crear objetos: con xf.inv —un objeto por celda, 280 000 al soltar— la capa fija entera tardaba
   //  ~25 ms más que lo medido dentro del polvo: la basura se cobraba después, al trazar las órbitas. Sonda tests/c3_gxdust_prof.js)
   if (P.kind === "top" && P.xf.turned) {
      // (26-oct: la vista girada o con pivote —los vuelos de Cabra3D—: la inversa de la vista, con su giro; la clave lleva giro y pivote)
      var xr = P.xf; L = cshGxdLut("top"); cell = Math.max(2, Math.round(2 * sc)) * lk;
      db = cshGxDustBitmap(["topR", rect.x, rect.y, rect.w, rect.h, cell, xr.ppk.toFixed(4), xr.ca.toFixed(3), xr.cb.toFixed(3), xr.rot.toFixed(3), xr.pvx.toFixed(1), xr.pvy.toFixed(1), xr.red ? 1 : 0, CSH_GX_BREAK, CSH_GXD_BREAK, tk].join("|"), rect, cell,
         function(qx, qy) { var iq = xr.inv(qx, qy); cshGxdSigmaT(iq.X, iq.Y, T, o); return cshGxdArgb(L, o.s, o.w); });
   } else if (P.kind === "top") {
      var xt = P.xf, ppk = xt.ppk, ca = xt.ca, cb = xt.cb, fl = cshGxBroken("flip") ? -1 : 1; L = cshGxdLut("top"); cell = Math.max(2, Math.round(2 * sc)) * lk;
      db = cshGxDustBitmap(["top", rect.x, rect.y, rect.w, rect.h, cell, ppk.toFixed(4), ca.toFixed(3), cb.toFixed(3), CSH_GX_BREAK, CSH_GXD_BREAK, tk].join("|"), rect, cell,
         function(qx, qy) { cshGxdSigmaT(cb - (qy - my) / ppk, -(ca + (qx - mx) / ppk) * fl, T, o); return cshGxdArgb(L, o.s, o.w); });
   } else if (P.kind === "edge" && P.xf.turned) {
      // (26-oct: de canto con pivote o desde otro azimut —los vuelos de Cabra3D—: la inversa de la vista y, con az, el radio de la lámina: slR)
      var xq = P.xf; L = cshGxdLut("edge"); cell = Math.max(2, Math.round(2 * sc)) * lk;
      ze = (typeof cshGxdThick === "function") ? cshGxdThick(xq.sz, sc) : 1;
      db = cshGxDustBitmap(["edgeR", rect.x, rect.y, rect.w, rect.h, cell, xq.sx.toFixed(4), xq.sz.toFixed(4), xq.cR.toFixed(3), xq.cz.toFixed(3), xq.pvx.toFixed(1), xq.pvy.toFixed(1), xq.lin ? xq.az.toFixed(3) + "," + xq.ax.toFixed(3) + "," + xq.ay.toFixed(3) : "rz", CSH_GXD_BREAK, tk, ze].join("|"), rect, cell,
         function(qx, qy) { var iq = xq.inv(qx, qy); cshGxdRingT(xq.lin ? xq.slR(iq.R) : iq.R, iq.z / ze, T, q); return cshGxdArgb(L, q.r, q.f); });
   } else if (P.kind === "edge") {
      // (26-oct, V7g) el GROSOR MÍNIMO de canto: la lámina se estira en z ×ze alrededor del plano si su altura de escala queda por debajo de
      // CSH_GXD.EDGE_HMIN px lógicos (con el encuadre de fábrica de las Pléyades, 6,4 px). La leyenda lo dice.
      var xe = P.xf, esx = xe.sx, esz = xe.sz, ecR = xe.cR, ecz = xe.cz; L = cshGxdLut("edge"); cell = Math.max(2, Math.round(2 * sc)) * lk;
      ze = (typeof cshGxdThick === "function") ? cshGxdThick(esz, sc) : 1;
      db = cshGxDustBitmap(["edge", rect.x, rect.y, rect.w, rect.h, cell, esx.toFixed(4), esz.toFixed(4), ecR.toFixed(3), ecz.toFixed(3), CSH_GXD_BREAK, tk, ze].join("|"), rect, cell,
         function(qx, qy) { cshGxdRingT(ecR + (qx - mx) / esx, (ecz - (qy - my) / esz) / ze, T, q); return cshGxdArgb(L, q.r, q.f); });
   } else {
      // (3D: donde el rayo del píxel cruza z = 0, la columna por el camino oblicuo —Σ/|cos i|, tope CSH_GXD.PATH_MAX—: el término del disco del
      //  resplandor. El rayo, el de cshGxCam · ray() escrito en línea: el mundo es (t, −u, −v) de la caja)
      var cam = P.cam, Q = cam.pose, Vw = cam.view, Kc = cam.K, csc = cam.scale, scx = cam.cx, scy = cam.cy, persp = cam.persp;
      var R0x = Q.cy, R0z = Q.sy, U0 = -Q.sy * Q.sp, U1 = Q.cp, U2 = Q.cy * Q.sp, W0 = -Q.sy * Q.cp, W1 = -Q.sp, W2 = Q.cy * Q.cp;
      L = cshGxdLut("top"); cell = Math.max(3, Math.round(3 * sc), Math.ceil(rect.w / 340)) * lk;
      db = cshGxDustBitmap(["3d", rect.x, rect.y, rect.w, rect.h, cell, Vw.yaw.toFixed(3), Vw.pitch.toFixed(3), Vw.zoom.toFixed(4), Vw.ox.toFixed(3), Vw.oy.toFixed(3), Vw.oz.toFixed(3), cam.f0.toFixed(4), CSH_GX_BREAK, CSH_GXD_BREAK, tk].join("|"), rect, cell,
         function(qx, qy) {
            var xc = (qx - scx) / csc, yc = (qy - scy) / csc, c2a = persp ? -Kc : -1000;
            // origen (xc, yc, c2a) o el ojo (0, 0, −K) y el punto del plano de la pantalla (xc, yc, 0), en la caja (u, v, t)
            var a0 = persp ? 0 : xc, a1 = persp ? 0 : yc;
            var ou = Vw.ox + a0 * R0x + a1 * U0 + c2a * W0, ov = Vw.oy + a1 * U1 + c2a * W1, ot = Vw.oz + a0 * R0z + a1 * U2 + c2a * W2;
            var pu = Vw.ox + xc * R0x + yc * U0, pv = Vw.oy + yc * U1, pt = Vw.oz + xc * R0z + yc * U2;
            var oX = ot, oY = -ou, oZ = -ov, dX = pt - ot, dY = -(pu - ou), dZ = -(pv - ov);
            if (!(Math.abs(dZ) > 1e-9)) return 0;
            var s = -oZ / dZ;
            if (!(s > 0)) return 0;
            var dl = Math.sqrt(dX * dX + dY * dY + dZ * dZ);
            cshGxdSigmaT(oX + s * dX, oY + s * dY, T, o);
            return cshGxdArgb(L, o.s * Math.min(CSH_GXD.PATH_MAX, dl / Math.abs(dZ)), o.w);
         });
   }
   var t1 = Date.now();
   // (al arrastrar —V.light—, sin suavizar el escalado: la celda gruesa se ve un instante y al soltar vuelve la fina)
   g.smoothInterpolation = (V.light !== true);
   g.drawScaledBitmap(new Rect(rect.x, rect.y, rect.x + db.w, rect.y + db.h), db.bmp);
   g.smoothInterpolation = true;
   var t2 = Date.now();
   // LA COSTURA: desde arriba y en 3D, el círculo de lo medido por Vergely (4,83 kpc del Sol de hoy, a trazos dorados; hasta el 6-nov-2026) y el de Edenhofer
   // (1,2 kpc, a trazos crema); de canto, el recuadro de lo medido (R donde algo del anillo es medido · |z − z⊙| ≤ 0,4 kpc)
   // (26-oct, V7h) fuera de hoy, la costura es la de lo medido LLEVADO por la rotación (el círculo se cizalla) y se desvanece con lo medido (×w);
   // con w < 0,1 ya no se pinta (lo medido apenas pesa); de canto, el recuadro se estira con la lámina (×ze)
   var seam = [], wS = T.live ? T.w : (T.model ? 0 : 1);
   if (!cshGxdBroken("noseam") && wS >= 0.1) {
      var LT = (V.light === true), penM = LT ? new Pen(cpInt(A.goldLight, 0.6 * wS), 1) : cshGxPen(cpInt(A.goldLight, 0.75 * wS), Math.max(1, 1.4 * sc), true);
      if (P.kind !== "edge") {
         var cM = [], cE = [], R0 = D.R0, fw = [0, 0];
         // (6-nov-2026) sin Vergely (D.fp = 0) solo queda el círculo de Edenhofer, a trazos crema
         for (var th = 0; th <= 2 * Math.PI + 1e-9; th += Math.PI / 90) {
            if (D.fp > 0) { cshGxdForward(-R0 + D.fp * Math.cos(th), D.fp * Math.sin(th), T, fw); cM.push([fw[0], fw[1], 0]); }
            cshGxdForward(-R0 + D.edenR * Math.cos(th), D.edenR * Math.sin(th), T, fw); cE.push([fw[0], fw[1], 0]);
         }
         g.antialiasing = !LT;
         if (cM.length) cshGxPolyline(g, P, cM, penM);
         cshGxPolyline(g, P, cE, LT ? new Pen(cpInt(A.text, 0.6 * wS), 1) : cshGxPen(cpInt(A.text, 0.7 * wS), Math.max(1, 0.9 * sc), true));
         g.antialiasing = true;
         if (cM.length) seam.push({ kind: "circle", r: D.fp, cx: -R0, cy: 0, w: wS, pts: cM });
         seam.push({ kind: "circle", r: D.edenR, cx: -R0, cy: 0, w: wS });
      } else if (D.edge.cov && D.edge.cov.length === 2) {      // (6-nov-2026) de canto sin nada medido (cov null): sin recuadro
         var c0 = D.edge.cov[0], c1 = D.edge.cov[1], za = (D.G.zsun - CSH_GXD.Z_MEAS) * ze, zb = (D.G.zsun + CSH_GXD.Z_MEAS) * ze;
         g.antialiasing = !LT;
         if (P.xf.lin) {
            // (vista lineal desde otro azimut: lo medido rodea al Sol; el recuadro, en (R, z) de la pantalla como con az = 0)
            g.pen = penM; cshGxNoBrush(g);
            var sq = [[c0, za], [c1, za], [c1, zb], [c0, zb], [c0, za]], pq = [];
            for (var qi = 0; qi < sq.length; ++qi) { var qq = P.xf.px(sq[qi][0], sq[qi][1]); pq.push(new Point(qq.x, qq.y)); }
            g.drawPolyline(pq);
         } else cshGxPolyline(g, P, [[c0, 0, za], [c1, 0, za], [c1, 0, zb], [c0, 0, zb], [c0, 0, za]], penM);
         g.antialiasing = true;
         seam.push({ kind: "box", R0: c0, R1: c1, z0: za, z1: zb, w: wS });
      }
   }
   return { kind: P.kind, ms: Date.now() - t0, msGrid: db.cached ? 0 : db.ms, msDraw: t2 - t1, msSeam: Date.now() - t2, cell: cell, cached: db.cached, cells: db.nx * db.ny, painted: db.painted, seam: seam, bmp: db,
            tMyr: T.t, w: T.w, live: T.live === true, model: T.model === true, stretch: ze };
}
function cshGxDrawGlow(g, rect, gb) {
   g.smoothInterpolation = true;
   g.drawScaledBitmap(new Rect(rect.x, rect.y, rect.x + gb.w, rect.y + gb.h), gb.bmp);
}

// ---------------------------------------------------------------------------
// EL PROYECTOR de cada vista: pt(X, Y, Z) -> { x, y, ok, m (perspectiva: 1 en el pivote), z (profundidad) }
// ---------------------------------------------------------------------------
// `into(X, Y, Z, out)`: lo mismo sin crear objetos (out = [x, y]; devuelve si se ve): para las órbitas.
function cshGxProjector(G, V, rect) {
   var mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2;
   if (V.mode === "edge") {
      var xe = cshGxEdgeXf(G, rect, V.v2 ? V.v2.edge : null);
      if (xe.turned) {
         // (26-oct: con pivote y, con az, la proyección lineal: h en vez de R)
         var hx = xe.lin ? xe.h : function(X, Y) { return Math.sqrt(X * X + Y * Y); }, epx = xe.pvx, epy = xe.pvy;
         return { kind: "edge", xf: xe, pt: function(X, Y, Z) { var q = xe.px(hx(X, Y), Z); q.ok = true; q.m = 1; q.z = 0; return q; },
                  into: function(X, Y, Z, out) { out[0] = epx + (hx(X, Y) - xe.cR) * xe.sx; out[1] = epy - (Z - xe.cz) * xe.sz; return true; } };
      }
      return { kind: "edge", xf: xe, pt: function(X, Y, Z) { var q = xe.px(Math.sqrt(X * X + Y * Y), Z); q.ok = true; q.m = 1; q.z = 0; return q; },
               into: function(X, Y, Z, out) { out[0] = mx + (Math.sqrt(X * X + Y * Y) - xe.cR) * xe.sx; out[1] = my - (Z - xe.cz) * xe.sz; return true; } };
   }
   if (V.mode === "3d") {
      var cam = cshGxCam((rect.fx && rect.fx.box3) ? rect.fx.box3 : G.ext.box, rect, V.cam || { yaw: CSH_GX_CAM.YAW, pitch: CSH_GX_CAM.PITCH });
      return { kind: "3d", cam: cam, pt: function(X, Y, Z) { var q = cam.px(X, Y, Z); q.m = q.w; return q; }, into: cam.pxInto };
   }
   var xt = cshGxTopXf(G, rect, V.v2 ? V.v2.top : null), fl = cshGxBroken("flip") ? -1 : 1;
   if (xt.turned) {
      // (26-oct: el mapa girado alrededor del pivote; `into` sin crear objetos, la misma cuenta que xt.px)
      var tcr = xt.cr, tsr = xt.sr, tpx = xt.pvx, tpy = xt.pvy;
      return { kind: "top", xf: xt, pt: function(X, Y) { var q = xt.px(X, Y); q.ok = true; q.m = 1; q.z = 0; return q; },
               into: xt.red ? function(X, Y, Z, out) { var q = xt.px(X, Y); out[0] = q.x; out[1] = q.y; return true; }
                            : function(X, Y, Z, out) { var a = fl * -Y - xt.ca, b = X - xt.cb; out[0] = tpx + (a * tcr - b * tsr) * xt.ppk; out[1] = tpy - (a * tsr + b * tcr) * xt.ppk; return true; } };
   }
   return { kind: "top", xf: xt, pt: function(X, Y) { var q = xt.px(X, Y); q.ok = true; q.m = 1; q.z = 0; return q; },
            into: function(X, Y, Z, out) { out[0] = mx + (fl * -Y - xt.ca) * xt.ppk; out[1] = my - (X - xt.cb) * xt.ppk; return true; } };
}
function cshGxPolyline(g, P, pts3, pen) {
   g.pen = pen; cshGxNoBrush(g);
   var run = [];
   for (var i = 0; i < pts3.length; ++i) {
      var q = P.pt(pts3[i][0], pts3[i][1], pts3[i][2]);
      if (!q.ok) { if (run.length > 1) g.drawPolyline(run); run = []; continue; }
      run.push(new Point(q.x, q.y));
   }
   if (run.length > 1) g.drawPolyline(run);
}
// Un tramo de una tabla guardada (T = una trayectoria o su `.back`), de i0 a i1 con paso `step`; O (la rejilla) apunta lo pintado
// como «blando». `pre` (opcional): un punto [x, y, z] con el que empezar (el otro lado de hoy, para que el tramo no tenga hueco).
function cshGxTablePolyline(g, P, T, i0, i1, step, pen, O, pre) {
   g.pen = pen; cshGxNoBrush(g);
   var run = [], last = Math.min(T.n - 1, i1), q = [0, 0], X = T.x, Y = T.y, Z = T.z, into = P.into;
   if (pre && into(pre[0], pre[1], pre[2], q)) run.push(new Point(q[0], q[1]));
   for (var i = Math.max(0, i0); i <= last; i += step) {
      if (!into(X[i], Y[i], Z[i], q)) { if (run.length > 1) g.drawPolyline(run); run = []; continue; }
      run.push(new Point(q[0], q[1]));
      if (O) { var ci = Math.floor(q[0] / O.cell), cj = Math.floor(q[1] / O.cell); if (ci >= 0 && cj >= 0 && ci < O.nx && cj < O.ny && O.a[cj * O.nx + ci] < 1) O.a[cj * O.nx + ci] = 1; }
      if (i + step > last && i !== last) i = last - step;     // (el último punto, siempre)
   }
   if (run.length > 1) g.drawPolyline(run);
}
// Una órbita de tMyr0 a tMyr1 (negativo = el pasado): la parte de atrás (de hoy hacia el pasado) y la de delante, sin hueco en hoy.
function cshGxOrbitSpan(g, P, tr, tMyr0, tMyr1, step, pen, O) {
   if (!tr || !tr.n) return;
   var a = Math.min(tMyr0, tMyr1), b = Math.max(tMyr0, tMyr1);
   if (a < 0 && tr.back && tr.back.n) {
      var ib = Math.min(tr.back.n - 1, Math.round(-a / tr.back.dtMyr)), ie = Math.max(0, Math.round(Math.max(0, -b) / tr.back.dtMyr));
      cshGxTablePolyline(g, P, tr.back, ie, ib, step, pen, O, null);
   }
   if (b > 0) {
      var j0 = Math.max(0, Math.round(Math.max(0, a) / tr.dtMyr)), j1 = Math.min(tr.n - 1, Math.round(b / tr.dtMyr));
      cshGxTablePolyline(g, P, tr, j0, j1, step, pen, O, null);
   }
}
function cshGxNiceStep(span, n) {
   var raw = span / Math.max(1, n), p = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), m = raw / p;
   return (m < 1.5 ? 1 : (m < 3.5 ? 2 : (m < 7.5 ? 5 : 10))) * p;
}
// LA VENTANA DE LAS ÓRBITAS FIJAS: con pasado guardado, centrada en hoy; si no, de hoy hacia el futuro (lo de CabraComposition).
function cshGxOrbitWindow(G) {
   var S = CSH_GX.SHOW_MYR;
   return (G.backMyr > 0) ? [-Math.min(S / 2, G.backMyr), S / 2] : [0, S];
}

// ---------------------------------------------------------------------------
// LA GEOMETRÍA del lienzo: el rectángulo del mapa (V.frame, o el de fábrica con título y pie) y la rejilla
// ---------------------------------------------------------------------------
function cshGxLayout(w, h, sc, V) {
   var chrome = (V.chrome !== false) && !V.frame, padX = chrome ? Math.round(10 * sc) : 0, headH = chrome ? Math.round(26 * sc) : 0, footH = chrome ? Math.round(18 * sc) : 0;
   var rect = V.frame ? { x: V.frame.x, y: V.frame.y, w: Math.max(20, V.frame.w), h: Math.max(20, V.frame.h) }
                      : { x: padX, y: headH, w: Math.max(20, w - 2 * padX), h: Math.max(20, h - headH - footH) };
   return { chrome: chrome, framed: !!V.frame, rect: rect, bounds: { x: rect.x + 2, y: rect.y + 2, w: rect.w - 4, h: rect.h - 4 } };
}
// ---------------------------------------------------------------------------
// EL ENCUADRE QUE CONTIENE LA NUBE y DÓNDE VAN LA LEYENDA Y LA PLACA (23-oct-2026, noche; revisión visual de Cabra3D: la placa del tiempo
// del vídeo de canto caía encima de la leyenda, la nube de las Pléyades se salía del mapa y pasaba detrás de la leyenda, la elegida se cortaba
// por arriba). Solo si el script lo pide con V.fitWin = [a, b] (la ventana de tiempo en Myr: la escala de la máquina del tiempo); sin
// V.fitWin, todo como antes (G.ext).
//   1. la caja de la nube en todo ese tiempo (cshGxFitData: el centro, el Sol, la nube entera y la elegida), encajada en el mapa;
//   2. la leyenda y la placa, cada una en la ESQUINA con menos estrellas debajo EN TODO ESE TIEMPO (las muestras de cshGxFitData), entre
//      V.fitCorners (de fábrica tl, tr, bl: abajo a la derecha están la escala o el rótulo del eje R); la leyenda primero (es mayor);
//   3. si aun así alguna tapa estrellas, el encaje se hace en lo que queda al quitar su franja (de lado o de arriba/abajo: la que deje la
//      vista más grande). La placa se mide con V.plateMax (lo más grande que llega a ser en esa ventana): no cambia de sitio fotograma a fotograma.
// Devuelve { top | edge | box3, legend, plate (esquinas), legBox, plateBox, fit (el rectángulo del encaje), sig } o null. Se guarda en G.
function cshGxCornerBox(c, bw, bh, rect, m) {
   var x = (c === "tr" || c === "br") ? rect.x + rect.w - m - bw : rect.x + m, y = (c === "bl" || c === "br") ? rect.y + rect.h - m - bh : rect.y + m;
   return { x0: x, y0: y, x1: x + bw, y1: y + bh, c: c };
}
function cshGxFitXf(mode, box, F, rect) {
   var mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2, fw = Math.max(20, F.x1 - F.x0), fh = Math.max(20, F.y1 - F.y0), fcx = (F.x0 + F.x1) / 2, fcy = (F.y0 + F.y1) / 2;
   if (mode === "top") {
      var ppk = Math.min(fw / (box.u1 - box.u0), fh / (box.x1 - box.x0)) / 1.06, uc = (box.u0 + box.u1) / 2, xc = (box.x0 + box.x1) / 2;
      return { ppk: ppk, ca: uc - (fcx - mx) / ppk, cb: xc + (fcy - my) / ppk, score: ppk };
   }
   var sx = fw / ((box.R1 - box.R0) * 1.04), sz = fh / ((box.z1 - box.z0) * 1.08), Rc = (box.R0 + box.R1) / 2, zc = (box.z0 + box.z1) / 2;
   return { sx: sx, sz: sz, cR: Rc - (fcx - mx) / sx, cz: zc + (fcy - my) / sz, score: Math.min(fw / rect.w, fh / rect.h) };
}
function cshGxFitView(G, V, rect, sc) {
   if (!G || !V || !V.fitWin || cshGxBroken("nofit")) return null;
   var mode = V.mode, selK = (cshGxIsNum(V.sel) && V.sel >= 0 && G.byIdx.hasOwnProperty(V.sel)) ? G.byIdx[V.sel] : -1;
   var D = cshGxFitData(G, V.fitWin[0], V.fitWin[1], selK);
   var legM = (V.legendOn !== false) ? cshGxLegendMax(V, G, rect, sc) : null;      // (26-oct, V7i: la MAYOR que llega a ser: no salta al encender capas)
   var pl = V.plateMax || V.plate, plM = (pl && pl.length) ? cshGxPlate(null, null, pl, rect, sc, true, "tl", V.plateK, 0, V.plateWrap) : null;
   var lw = legM ? legM.x1 - legM.x0 : 0, lh = legM ? legM.y1 - legM.y0 : 0, pw = plM ? plM.x1 - plM.x0 : 0, ph = plM ? plM.y1 - plM.y0 : 0;
   var cands = (V.fitCorners && V.fitCorners.length) ? V.fitCorners : ["tl", "tr", "bl"];
   var key = [D.key, D.sig, mode, rect.x, rect.y, rect.w, rect.h, sc, Math.round(lw), Math.round(lh), Math.round(pw), Math.round(ph), cands.join(","), V.reserve ? JSON.stringify(V.reserve) : "", V.plate3At || "", V.plateWrap || 0, cshGxBroken("platelegend") ? 1 : 0, cshGxBroken("onecol") ? 1 : 0, (V.legendSlimBelow > 0 && !cshGxBroken("slimleg")) ? V.legendSlimBelow : 0].join("|");
   if (!G._fv) G._fv = {};
   if (G._fv.hasOwnProperty(key)) return G._fv[key];
   var m = Math.round(8 * sc), out = { key: key, sig: "", legend: "tr", plate: "tl", legBox: null, plateBox: null, box3: D.box3, counts: {} };
   var inset = { x0: rect.x + m, y0: rect.y + m, x1: rect.x + rect.w - m, y1: rect.y + rect.h - m };
   if (mode === "3d") {
      out.legend = "tr"; out.plate = V.plate3At || "tl"; out.sig = "3d|" + D.sig + "|" + (V.plate3At || "");        // (25-oct: V.plate3At = la esquina de la placa con reloj en 3D, que elige Cabra3D con las estrellas proyectadas)
   } else {
      var S = D.S, n = S.n, px = new Float32Array(n), py = new Float32Array(n), i;
      var X0 = cshGxFitXf(mode, D.box, inset, rect), mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2;
      // (las muestras proyectadas con un encaje X: donde caen en pantalla)
      // (27-oct, D1) el centro galáctico y el Sol, además de las muestras: pesan 50 cada uno al elegir esquina (de canto, con la placa estrecha
      //  del reloj arriba a la izquierda, el centro —en el borde izquierdo del encaje— quedaba debajo; las estrellas tapadas eran el 0,5 %; con 50 seguía
      //  debajo —captura c3_D1_despues_galaxia_edge—: pesan más que todas las muestras juntas)
      var mk = [];
      function projAt(X) {
         var R0 = (typeof CSH_GD === "object" && CSH_GD.R0_KPC) ? CSH_GD.R0_KPC : 8.2, Zs = (typeof CSH_GD === "object" && CSH_GD.ZSUN_KPC) ? CSH_GD.ZSUN_KPC : 0;
         if (mode === "top") mk = [[mx + (0 - X.ca) * X.ppk, my - (0 - X.cb) * X.ppk], [mx + (0 - X.ca) * X.ppk, my - (-R0 - X.cb) * X.ppk]];
         else mk = [[mx + (0 - X.cR) * X.sx, my - (0 - X.cz) * X.sz], [mx + (R0 - X.cR) * X.sx, my - (Zs - X.cz) * X.sz]];
         for (var pi = 0; pi < n; ++pi) {
            if (mode === "top") { px[pi] = mx + (-S.Y[pi] - X.ca) * X.ppk; py[pi] = my - (S.X[pi] - X.cb) * X.ppk; }
            else { var Rr = Math.sqrt(S.X[pi] * S.X[pi] + S.Y[pi] * S.Y[pi]); px[pi] = mx + (Rr - X.cR) * X.sx; py[pi] = my - (S.Z[pi] - X.cz) * X.sz; }
         }
      }
      projAt(X0);
      function count(bx) {
         var c = 0, h = m / 2;
         for (var k = 0; k < n; ++k) if (px[k] >= bx.x0 - h && px[k] <= bx.x1 + h && py[k] >= bx.y0 - h && py[k] <= bx.y1 + h) ++c;
         if (!cshGxBroken("platelegend")) for (var q = 0; q < mk.length; ++q) if (mk[q][0] >= bx.x0 - h && mk[q][0] <= bx.x1 + h && mk[q][1] >= bx.y0 - h && mk[q][1] <= bx.y1 + h) c += n + 1;          // (más que todas las muestras juntas: casi un veto)
         return c;
      }
      // (27-oct, D1: en un panel estrecho la placa con el reloj, en la otra esquina de ARRIBA, se metía debajo de la leyenda —las dos más anchas
      //  que media vista—. La placa no va a una esquina donde pise la caja de la leyenda; solo si todas la pisan, la de menos estrellas como antes.
      //  Rojo: CSH_GX_BREAK «platelegend» = lo de antes.)
      function hitsBox(b, o) { return !!(o && b.x0 < o.x1 + m / 2 && b.x1 > o.x0 - m / 2 && b.y0 < o.y1 + m / 2 && b.y1 > o.y0 - m / 2); }
      function pick(bw, bh, pref, taken, avoid) {
         var best = null, bestFree = null;
         for (var q = 0; q < pref.length; ++q) {
            var c = pref[q];
            if (cands.indexOf(c) < 0 || c === taken) continue;
            var b = cshGxCornerBox(c, bw, bh, rect, m), k = count(b);
            out.counts[c + (taken ? "p" : "l")] = k;
            if (best === null || k < best.k) best = { c: c, k: k, b: b };
            if (!hitsBox(b, avoid) && (bestFree === null || k < bestFree.k)) bestFree = { c: c, k: k, b: b };
         }
         return (avoid && bestFree && !cshGxBroken("platelegend")) ? bestFree : best;
      }
      var Lp = legM ? pick(lw, lh, ["tr", "tl", "bl", "br"], "") : null, Pp = plM ? pick(pw, ph, ["tl", "bl", "tr", "br"], Lp ? Lp.c : "", Lp ? Lp.b : null) : null;
      if (Lp) { out.legend = Lp.c; out.legBox = Lp.b; }
      if (Pp) { out.plate = Pp.c; out.plateBox = Pp.b; }
      // (¿tapan estrellas? Una muestra de cada mil se tolera: las de fuera de los cuantiles)
      var thr = Math.max(2, Math.round(n / 1000)), boxes = [];
      if (Lp && Lp.k > thr) boxes.push(Lp.b);
      if (Pp && Pp.k > thr) boxes.push(Pp.b);
      var F = inset;
      if (boxes.length) {
         // (26-oct, c3_gx_review V7 en rojo con el reloj: la placa con reloj —500×213 en 1280×720— tapaba 565 muestras arriba a la izquierda y el
         //  encaje se estrechó por la izquierda (x0 522); la nube a −100 Ma se corrió a la derecha y quedó DEBAJO de la leyenda —583 de 5 221 estrellas,
         //  el 11,2 %—, que se había elegido con el encaje de antes. Ahora cada encaje candidato se mide otra vez con TODAS las cajas —leyenda y
         //  placa— en las posiciones que da ESE encaje: gana el de más escala entre los que no tapan; si ninguno, el que menos tapa. Rojo:
         //  CSH_GX_BREAK «fitold» = la elección de antes, sin volver a medir.)
         var all = []; if (Lp) all.push(Lp.b); if (Pp) all.push(Pp.b);
         var bestF = null, bestS = -1, bestCov = Infinity, combos = (boxes.length === 1) ? [[0], [1]] : [[0, 0], [0, 1], [1, 0], [1, 1]];
         for (var ci = 0; ci < combos.length; ++ci) {
            var F2 = { x0: inset.x0, y0: inset.y0, x1: inset.x1, y1: inset.y1 };
            for (var bi = 0; bi < boxes.length; ++bi) {
               var bx = boxes[bi], top = (bx.c === "tl" || bx.c === "tr"), left = (bx.c === "tl" || bx.c === "bl");
               if (combos[ci][bi] === 0) { if (top) F2.y0 = Math.max(F2.y0, bx.y1 + m); else F2.y1 = Math.min(F2.y1, bx.y0 - m); }
               else { if (left) F2.x0 = Math.max(F2.x0, bx.x1 + m); else F2.x1 = Math.min(F2.x1, bx.x0 - m); }
            }
            if (F2.x1 - F2.x0 < rect.w * 0.3 || F2.y1 - F2.y0 < rect.h * 0.3) continue;
            var X2 = cshGxFitXf(mode, D.box, F2, rect), sc2 = X2.score;
            if (cshGxBroken("fitold")) { if (sc2 > bestS) { bestS = sc2; bestF = F2; } continue; }
            projAt(X2);
            var cov = 0; for (var ab = 0; ab < all.length; ++ab) cov += Math.max(0, count(all[ab]) - thr);
            if (cov < bestCov || (cov === bestCov && sc2 > bestS)) { bestCov = cov; bestS = sc2; bestF = F2; }
         }
         if (bestF) F = bestF;
         out.counts.cover = (bestCov === Infinity) ? -1 : bestCov;
      }
      var Xf = cshGxFitXf(mode, D.box, F, rect);
      // (27-oct, D1, noche) la esquina de la placa se eligió con el encaje de ANTES; si el encaje final la cambia, el centro galáctico (o el Sol)
      // puede quedar debajo: de canto en el panel de 756, la leyenda abajo obligó a estrechar por abajo y el centro bajó a la placa de arriba
      // a la izquierda (sonda c3_clock_d1_probe D1b: tl 28 muestras con el encaje inicial; con el final, el centro dentro). Se vuelve a contar
      // con el encaje final y, si la placa tapa un marcador, va a la esquina libre (sin la leyenda) que menos tape. Rojo: CSH_GX_BREAK «gcunder».
      if (Pp && !cshGxBroken("gcunder") && !cshGxBroken("platelegend")) {
         projAt(Xf);
         var kNow = count(Pp.b);
         if (kNow > n) {
            var alt = null;
            for (var qa = 0; qa < cands.length; ++qa) {
               var ca = cands[qa];
               if (ca === Pp.c || (Lp && ca === Lp.c)) continue;
               var ba = cshGxCornerBox(ca, pw, ph, rect, m);
               if (Lp && hitsBox(ba, Lp.b)) continue;
               var ka = count(ba);
               if (ka < kNow && (alt === null || ka < alt.k)) alt = { c: ca, k: ka, b: ba };
            }
            out.counts.plateFinal = kNow;
            if (alt) { out.plate = alt.c; out.plateBox = alt.b; out.counts.plateMoved = alt.c + ":" + alt.k; }
         }
      }
      out.fit = F;
      if (mode === "top") out.top = { ppk: Xf.ppk, ca: Xf.ca, cb: Xf.cb }; else out.edge = { sx: Xf.sx, sz: Xf.sz, cR: Xf.cR, cz: Xf.cz };
      out.sig = [mode, out.legend, out.plate, Math.round(F.x0), Math.round(F.y0), Math.round(F.x1), Math.round(F.y1), D.sig].join(",");
   }
   var nk = 0; for (var kk in G._fv) if (G._fv.hasOwnProperty(kk)) ++nk;
   if (nk > 24) G._fv = {};
   G._fv[key] = out;
   return out;
}
// La clave de la capa FIJA: si no cambia, su bitmap vale. (Ni el instante ni la elegida entran; sí el encuadre de la nube, que con la
// elegida solo cambia si la elegida se sale de la nube.)
function cshGxStaticKey(G, V, w, h, sc) {
   var m = V.mode, v2 = (V.v2 && V.v2[m]) ? V.v2[m] : null, cam = (m === "3d" && V.cam) ? cshGxCamView(V.cam) : null, F = V.frame;
   var fx = (G && V.fitWin) ? cshGxFitView(G, V, cshGxLayout(w, h, sc, V).rect, sc) : null;
   return [G ? G.stamp : "-", m, V.orbits === false ? 0 : 1, cshGxBroken("stalebase") ? "" : (V.colorKey || ""), V.arms !== false ? 1 : 0, V.light ? 1 : 0, V.chrome === false ? 0 : 1,
           F ? [F.x, F.y, F.w, F.h].join(",") : "", v2 ? [v2.k, v2.cx, v2.cy].join(",") + (cshGxV2Turned(v2) ? "," + [v2.rot, v2.az, v2.ax, v2.ay, v2.pvx, v2.pvy].join(",") : "") : "", cam ? [cam.yaw, cam.pitch, cam.zoom, cam.ox, cam.oy, cam.oz, cam.f0, cam.cx, cam.cy].join(",") : "",
           w, h, sc, cshLangIsEs() ? "es" : "en", V.bgInt || 0, CSH_GX_BREAK, fx ? fx.sig : "",
           // (26-oct, V7h: el polvo de la capa fija depende del instante solo como «hoy» o «disco liso»; el que gira va DEBAJO, fuera de esta
           //  capa —cshGxStaticDraw—, y la capa fija de encima lleva «u»: no se rehace en cada fotograma)
           (V.dustUnder === true) ? "u" : ((V.dust === true) ? "d" + ((typeof CSH_GXD_BREAK === "string") ? CSH_GXD_BREAK : "") + ((typeof cshGxdTime === "function") ? cshGxdTime(V.dustMyr).key : "") : "")].join("|");
}
// (26-oct, V7h) EL POLVO QUE GIRA CON EL INSTANTE va DEBAJO de las órbitas como siempre, pero sin rehacer la capa fija en cada fotograma: con
// él vivo, la capa fija se pinta TRANSPARENTE y sin fondo, resplandor ni polvo (V.dustUnder, una vez: no depende del instante) y en cada
// fotograma se pinta debajo el fondo del mapa, el resplandor (su bitmap guardado), el polvo de ese instante y su costura, y encima esa capa.
// Sin polvo vivo (hoy, o el disco liso pasados ~78 Ma, o sin el módulo), lo de siempre: un solo bitmap.
function cshGxDustLive(V) {
   if (!V || V.dust !== true || typeof cshGxdTime !== "function" || typeof cshGxdData !== "function") return false;
   var D = cshGxdData();
   return !!(D && D.ok && (cshGxdTime(V.dustMyr).live || V.dustUnderForce === true));
}
// Pinta la capa fija (con el polvo vivo, el fondo, el resplandor y el polvo debajo) en g y devuelve lo de cshGxStatic ({ bmp, C, fresh }).
function cshGxStaticDraw(g, cache, w, h, G, sc, V) {
   if (!cshGxDustLive(V) || !G) { var S0 = cshGxStatic(cache, w, h, G, sc, V); g.drawBitmap(0, 0, S0.bmp); return S0; }
   var U = {}, k;
   for (k in V) if (V.hasOwnProperty(k)) U[k] = V[k];
   U.dustUnder = true;
   if (!cache.under) cache.under = {};
   var S = cshGxStatic(cache.under, w, h, G, sc, U), C = S.C, t0 = Date.now();
   if (C.empty) { g.drawBitmap(0, 0, S.bmp); return S; }
   var r = C.rect, bgI = cshGxBg(V), lk = V.light ? ((V.mode === "3d") ? 3 : 2) : 1;
   if ((bgI >>> 24) !== 0) g.fillRect(new Rect(0, 0, w, h), new Brush(bgI));
   g.fillRect(new Rect(r.x, r.y, r.x + r.w, r.y + r.h), new Brush(cpInt(V.insetHex || cshGxInset())));
   g.clipRect = new Rect(r.x, r.y, r.x + r.w, r.y + r.h);
   var gb = cshGxGlowFor(C.P, r, sc, lk);
   if (gb && !cshGxBroken("underglow")) cshGxDrawGlow(g, r, gb);          // (ROJO «underglow» de tests/c3_gxdust_time.js: debajo, sin resplandor)
   var t1 = Date.now();
   C.R.dust = cshGxPaintDust(g, C.P, r, sc, V, lk);
   g.clipRect = new Rect(0, 0, w, h);
   var t2 = Date.now();
   g.drawBitmap(0, 0, S.bmp);
   if (C.R.dust) { C.R.dust.under = true; C.R.dust.msBase = t1 - t0; C.R.dust.msOver = Date.now() - t2; }
   S.under = true;
   return S;
}
// EL RESPLANDOR de una vista (su bitmap, guardado por clave). (26-oct: sacado de cshGxPaintStatic tal cual, para pintarlo también DEBAJO del
// polvo vivo —cshGxStaticDraw—.) lk: el factor de celda al arrastrar o reproducir (1 al soltar).
function cshGxGlowFor(P, rect, sc, lk) {
   var cell = Math.max(3, Math.round(3.5 * sc)) * lk, gb = null;
   if (P.kind === "top") {
      var xt = P.xf;
      gb = cshGxGlowBitmap(["top", rect.x, rect.y, rect.w, rect.h, cell, xt.ppk.toFixed(4), xt.ca.toFixed(3), xt.cb.toFixed(3), CSH_GX_BREAK].concat(xt.turned ? [xt.rot.toFixed(3), xt.pvx.toFixed(1), xt.pvy.toFixed(1)] : []).join("|"), rect, cell,
         function(qx, qy) { var q = xt.inv(qx, qy); return cshGxGlowOf(cshGxSigmaAt(Math.sqrt(q.X * q.X + q.Y * q.Y))); });
   } else if (P.kind === "edge") {
      var xe = P.xf;
      gb = cshGxGlowBitmap(["edge", rect.x, rect.y, rect.w, rect.h, cell, xe.sx.toFixed(4), xe.sz.toFixed(4), xe.cR.toFixed(3), xe.cz.toFixed(3)].concat(xe.turned ? [xe.pvx.toFixed(1), xe.pvy.toFixed(1), xe.lin ? xe.az.toFixed(3) + "," + xe.ax.toFixed(3) + "," + xe.ay.toFixed(3) : "rz"] : []).join("|"), rect, cell,
         function(qx, qy) { var q = xe.inv(qx, qy), Rr = xe.lin ? xe.slR(q.R) : Math.abs(q.R); return cshGxGlowOf(cshGxRhoDisc(Rr, q.z) + cshGxRhoBulge(Math.sqrt(Rr * Rr + q.z * q.z))); });
   } else {
      // (el resplandor es suave: unas 170 celdas a lo ancho bastan a cualquier tamaño; al arrastrar, 85)
      var cam = P.cam, Tb = cshGxSigmaTable(), cl = Math.max(4, Math.round(4.5 * sc), Math.ceil(rect.w / 170)) * lk;
      gb = cshGxGlowBitmap(["3d", rect.x, rect.y, rect.w, rect.h, cl, cam.view.yaw.toFixed(3), cam.view.pitch.toFixed(3), cam.view.zoom.toFixed(4), cam.view.ox.toFixed(3), cam.view.oy.toFixed(3), cam.view.oz.toFixed(3), cam.f0.toFixed(4), CSH_GX_BREAK].join("|"), rect, cl,
         function(qx, qy) {
            var r = cam.ray(qx, qy), o = r.o, d = r.d, dl = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]), sig = 0;
            // el disco: donde el rayo cruza z = 0, con el camino oblicuo por la lámina (ópticamente delgada: Σ / |cos i|, tope 6)
            if (Math.abs(d[2]) > 1e-9) {
               var s = -o[2] / d[2];
               if (s > 0) { var X = o[0] + s * d[0], Y = o[1] + s * d[1]; sig += cshGxLookup(Tb.disc, Tb, Math.sqrt(X * X + Y * Y)) * Math.min(6, dl / Math.abs(d[2])); }
            }
            var sc0 = -(o[0] * d[0] + o[1] * d[1] + o[2] * d[2]) / (dl * dl);
            if (sc0 > 0) { var px0 = o[0] + sc0 * d[0], py0 = o[1] + sc0 * d[1], pz0 = o[2] + sc0 * d[2]; sig += cshGxLookup(Tb.bulge, Tb, Math.sqrt(px0 * px0 + py0 * py0 + pz0 * pz0)); }
            return cshGxGlowOf(sig);
         });
   }
   return gb;
}

// ---------------------------------------------------------------------------
// 1 · LA CAPA FIJA: resplandor, referencia, órbitas, la órbita del Sol, el giro, el centro galáctico
// ---------------------------------------------------------------------------
function cshGxPaintStatic(g, w, h, G, sc, V) {
   var A = CSH_ATLAS, t0 = Date.now(), L = cshGxLayout(w, h, sc, V), rect = L.rect;
   var R = { texts: [], labels: [], legend: null, scale: null, dropped: 0, mode: V.mode, w: w, h: h, nStars: 0, nOrbits: 0, ms: 0, msStatic: 0, sun: null, gc: null, sel: null,
             orbitsDrawn: 0, orbitsAll: 0, footText: "" };
   g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
   // (V.bgInt = 0x00000000: transparente fuera del mapa —el script pinta debajo su cabecera; cshGxStatic deja el bitmap limpio antes—)
   var bgI = cshGxBg(V), under = (V.dustUnder === true);          // (26-oct, V7h: debajo va el polvo vivo —cshGxStaticDraw—: sin fondo)
   if ((bgI >>> 24) !== 0 && !under) g.fillRect(new Rect(0, 0, w, h), new Brush(bgI));
   var O = cshGxOcc(w, h, sc);
   if (L.chrome) {
      // el título (de fábrica: «LA VÍA LÁCTEA — DESDE ARRIBA (X–Y)»; CabraComposition pone delante su «III»: V.numeral)
      var fT = cpFont("text", 8.6 * sc, false, false, Math.round(8.6 * sc * A.labelTracking)), fN = cpFont("display", 13 * sc, false, true);
      var sub = cshGxT(V.mode === "edge" ? "gxTitleEdge" : (V.mode === "3d" ? "gxTitle3d" : "gxTitleTop"));
      var cut = sub.indexOf("("), subCaps = (cut > 0) ? sub.substring(0, cut).toUpperCase() + sub.substring(cut) : sub.toUpperCase();
      var tx = L.rect.x, ty = Math.round(17 * sc);
      if (V.numeral) { cshGxText(g, R, fN, cpInt(A.gold), tx, ty, V.numeral); tx += fN.width(V.numeral) + Math.round(9 * sc); }
      cshGxText(g, R, fT, cpInt(A.text3), tx, ty - Math.round(1 * sc), cshGxT("gxTitle") + " — " + subCaps);
   }
   if (!G) {
      var fm = cpFont("text", 10 * sc, false, true), msg = cshGxT("gxNoRes");
      cshGxText(g, R, fm, cpInt(A.text2), rect.x + (rect.w - fm.width(msg)) / 2, rect.y + rect.h / 2, msg);
      R.ms = Date.now() - t0;
      return { empty: true, R: R, O: O, rect: rect, bounds: L.bounds, chrome: L.chrome, framed: L.framed };
   }
   if (!under) g.fillRect(new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h), new Brush(cpInt(V.insetHex || cshGxInset())));
   rect.fx = V.fitWin ? cshGxFitView(G, V, rect, sc) : null;          // (23-oct, noche: el encuadre de la nube y las esquinas de leyenda y placa)
   var P = cshGxProjector(G, V, rect);
   cshGxOccMark(O, 0, 0, w, rect.y, 2); cshGxOccMark(O, 0, rect.y + rect.h, w, h, 2);
   cshGxOccMark(O, 0, 0, rect.x, h, 2); cshGxOccMark(O, rect.x + rect.w, 0, w, h, 2);
   g.clipRect = new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
   // --- el resplandor (la masa del potencial); al arrastrar, celdas del doble (la cuarta parte de rayos: el tope de ~33 ms de Cabra3D) ---
   var lk = V.light ? ((V.mode === "3d") ? 3 : 2) : 1;
   if (!under) { var gb = cshGxGlowFor(P, rect, sc, lk); if (gb) cshGxDrawGlow(g, rect, gb); }
   // --- el POLVO (24-oct-2026, V7f: solo con V.dust y csh_galaxy_dust.js; encima del resplandor, debajo de todo lo demás) ---
   R.dust = (V.dust === true && !under) ? cshGxPaintDust(g, P, rect, sc, V, lk) : null;
   // --- la referencia: círculos de radio, brazos ilustrativos, plano, ejes ---
   // (AL ARRASTRAR —V.light—: líneas de 1 px sin suavizar, los brazos sin su banda ancha, los círculos sin trazos. MEDIDO en PJSR
   //  (tests/c3_gx_prof2.js): 120 polilíneas translúcidas suavizadas de 1,35 px, 241 ms; de 1 px, 75; sin suavizar, 22-32. Al soltar,
   //  el dibujo entero, suavizado, con 1 px —la tercera parte de 1,35—.)
   var LT = (V.light === true), lw1 = 1;
   var ringPen = LT ? new Pen(cpInt(A.text3, 0.22), 1) : cshGxPen(cpInt(A.text3, 0.28), Math.max(1, 0.8 * sc), true), ringLbl = [];
   if (P.kind === "top" || P.kind === "3d") {
      var maxRing = (P.kind === "top") ? G.ext.top.half * 1.45 / P.xf.k + Math.sqrt(P.xf.ca * P.xf.ca + P.xf.cb * P.xf.cb) : G.ext.top.half * 1.1;
      // (con el encuadre de la nube: hasta la esquina más lejana del mapa, o la caja 3D)
      if (rect.fx && P.kind === "top") { maxRing = 0; var cn = [[rect.x, rect.y], [rect.x + rect.w, rect.y], [rect.x, rect.y + rect.h], [rect.x + rect.w, rect.y + rect.h]]; for (var cq = 0; cq < 4; ++cq) { var iq = P.xf.inv(cn[cq][0], cn[cq][1]); maxRing = Math.max(maxRing, Math.sqrt(iq.X * iq.X + iq.Y * iq.Y)); } }
      else if (rect.fx && rect.fx.box3) maxRing = rect.fx.box3.hx * 1.1;
      if (V.arms !== false && !cshGxBroken("noarms")) {
         var arms = cshGxArms();
         for (var ai = 0; ai < arms.length; ++ai) {
            var a3 = []; for (var aj = 0; aj < arms[ai].length; aj += (LT ? 3 : 1)) a3.push([arms[ai][aj][0], arms[ai][aj][1], 0]);
            if (!LT) cshGxPolyline(g, P, a3, new Pen(cpInt(A.goldLight, 0.055), Math.max(2, 9 * sc * (P.kind === "top" ? Math.min(1.6, P.xf.k) : 1))));
            g.antialiasing = !LT;
            cshGxPolyline(g, P, a3, new Pen(cpInt(A.goldLight, LT ? 0.14 : 0.10), LT ? 1 : Math.max(1, 1.2 * sc)));
            g.antialiasing = true;
         }
      }
      g.antialiasing = !LT;
      for (var ri = 0; ri < CSH_GX.RINGS.length; ++ri) {
         var rr = CSH_GX.RINGS[ri];
         if (rr > maxRing) continue;
         var c3 = [];
         for (var th = 0; th <= 2 * Math.PI + 1e-9; th += Math.PI / 60) c3.push([rr * Math.cos(th), rr * Math.sin(th), 0]);
         cshGxPolyline(g, P, c3, ringPen);
         ringLbl.push(rr);
      }
   } else {
      var xe2 = P.xf, R0e = xe2.inv(rect.x, 0).R, R1e = xe2.inv(rect.x + rect.w, 0).R, z1e = xe2.inv(0, rect.y).z, z0e = xe2.inv(0, rect.y + rect.h).z;
      var stR = cshGxNiceStep(R1e - R0e, 6), stZ = cshGxNiceStep(z1e - z0e, 5);
      g.pen = new Pen(cpInt(A.text3, 0.12), 1);
      for (var gr = Math.ceil(R0e / stR) * stR; gr <= R1e; gr += stR) { var qx = xe2.px(gr, 0).x; g.drawLine(qx, rect.y, qx, rect.y + rect.h); }
      for (var gz = Math.ceil(z0e / stZ) * stZ; gz <= z1e; gz += stZ) { var qy = xe2.px(0, gz).y; g.drawLine(rect.x, qy, rect.x + rect.w, qy); }
      var yPl = xe2.px(0, 0).y;
      g.pen = cshGxPen(cpInt(A.text3, 0.45), Math.max(1, 0.9 * sc), true); g.drawLine(rect.x, yPl, rect.x + rect.w, yPl);
   }
   g.antialiasing = true;
   // --- las órbitas (fijas: la ventana de cshGxOrbitWindow) ---
   var N = G.stars.length, win = cshGxOrbitWindow(G), i;
   if (V.orbits !== false && N) {
      var sub = cshGxOrbitSubset(G, V.light ? CSH_GX.MAX_ORBITS_LIGHT : CSH_GX.MAX_ORBITS), nWith = 0;
      for (i = 0; i < N; ++i) if (G.stars[i].tr) ++nWith;
      var alpha = Math.max(0.035, Math.min(0.25, 1.8 / Math.sqrt(Math.max(1, sub.length)))), stepI = LT ? 4 : 1;
      R.orbitsDrawn = sub.length; R.orbitsAll = nWith;
      g.antialiasing = !LT;
      for (var si = 0; si < sub.length; ++si) {
         var eo = G.stars[sub[si]];
         if (!eo.tr) continue;
         var co = cshGxColorOf(eo, V);
         cshGxOrbitSpan(g, P, eo.tr, win[0], win[1], stepI, new Pen(cshGxRgbInt(co.rgb, alpha), lw1), O);
         R.nOrbits++;
      }
      g.antialiasing = true;
   }
   // --- la órbita del Sol (punteada; al arrastrar, seguida) y la flecha del giro (arriba y 3D) ---
   var sp = G.sun;
   if (sp.tr && sp.tr.n && (V.orbits !== false || V.mode === "top"))
      cshGxOrbitSpan(g, P, sp.tr, win[0], win[1], LT ? 4 : 1, LT ? new Pen(cpInt(A.gold, 0.5), 1) : cshGxPen(cpInt(A.gold, V.orbits !== false ? 0.55 : 0.30), Math.max(1, 1.0 * sc), true), null);
   if (P.kind !== "edge") {
      var R0 = CSH_GD.R0_KPC, arc = [];
      for (var ph = 2.0; ph <= 2.9 + 1e-9; ph += 0.03) arc.push([-R0 * Math.cos(ph), R0 * Math.sin(ph), 0]);
      cshGxPolyline(g, P, arc, new Pen(cpInt(A.bg, 0.6), Math.max(2, 3.4 * sc)));
      cshGxPolyline(g, P, arc, new Pen(cpInt(A.goldLight, 0.9), Math.max(1.5, 1.6 * sc)));
      var qa = P.pt(arc[arc.length - 1][0], arc[arc.length - 1][1], 0), qb = P.pt(arc[arc.length - 3][0], arc[arc.length - 3][1], 0);
      if (qa.ok && qb.ok) {
         var ux = qa.x - qb.x, uy = qa.y - qb.y, ul = Math.sqrt(ux * ux + uy * uy) || 1, hk = 7 * sc;
         ux /= ul; uy /= ul;
         g.brush = new Brush(cpInt(A.goldLight, 0.95)); g.pen = new Pen(cpInt(A.bg, 0.6), 1);
         g.fillPolygon([new Point(qa.x + ux * hk * 0.4, qa.y + uy * hk * 0.4), new Point(qa.x - ux * hk - uy * hk * 0.5, qa.y - uy * hk + ux * hk * 0.5), new Point(qa.x - ux * hk + uy * hk * 0.5, qa.y - uy * hk - ux * hk * 0.5)]);
         cshGxNoBrush(g);
         R.arrow = { x: qa.x, y: qa.y, dx: ux, dy: uy };
      }
      var qm = P.pt(arc[Math.floor(arc.length / 2)][0], arc[Math.floor(arc.length / 2)][1], 0);
      if (qm.ok) R.arrowMid = { x: qm.x, y: qm.y };
   }
   // --- el centro galáctico ---
   var qg = P.pt(0, 0, 0);
   if (qg.ok) {
      var gk = 5 * sc;
      g.pen = new Pen(cpInt(A.gold, 0.9), Math.max(1, 1.2 * sc));
      g.drawLine(qg.x - gk, qg.y, qg.x + gk, qg.y); g.drawLine(qg.x, qg.y - gk, qg.x, qg.y + gk);
      g.pen = new Pen(cpInt(A.gold, 0.9), Math.max(1, 1.0 * sc)); cshGxNoBrush(g); g.drawCircle(qg.x, qg.y, 2.2 * sc);
      cshGxOccMark(O, qg.x - gk, qg.y - gk, qg.x + gk, qg.y + gk, 2);
      R.gc = { x: qg.x, y: qg.y, k: gk };
   }
   g.clipRect = new Rect(0, 0, w, h);
   R.msStatic = Date.now() - t0;
   return { empty: false, R: R, O: O, P: P, rect: rect, bounds: L.bounds, N: N, ringLbl: ringLbl, chrome: L.chrome, framed: L.framed, t0: t0 };
}
// Para pintar ENCIMA de una capa fija guardada: el contexto con su rejilla y su informe COPIADOS (los rótulos no se acumulan).
function cshGxCloneCtx(C) {
   var D = {};
   for (var k in C) if (C.hasOwnProperty(k)) D[k] = C[k];
   D.O = { cell: C.O.cell, nx: C.O.nx, ny: C.O.ny, w: C.O.w, h: C.O.h, a: new Uint8Array(C.O.a) };
   var R = {};
   for (k in C.R) if (C.R.hasOwnProperty(k)) R[k] = C.R[k];
   R.texts = C.R.texts.slice(); R.labels = C.R.labels.slice(); R.dropped = C.R.dropped; R.sel = null; R.legend = null; R.scale = null; R.nStars = 0; R.sun = null;
   D.R = R;
   D.t0 = Date.now();
   return D;
}
// LA CAPA FIJA, GUARDADA: `cache` es del script (un objeto vacío la primera vez). Devuelve { bmp, C, fresh }. Reutiliza el bitmap si
// el tamaño no cambia (crear uno de 1 960 × 1 300 son 3-4 ms: medido en Cabra3D).
// LIGERO SIN REPINTAR (23-oct, medido en Cabra3D/tests/c3_gx_prof.js con 5 539 estrellas: la capa fija ligera costaba 60-80 ms en 2D,
// casi todo rasterizar las órbitas en Qt): con V.light, si la última capa ENTERA es de la misma vista salvo el centro (desplazar en
// 2D) o salvo lo ligero (reproducir la máquina del tiempo, la elegida), se COPIA esa —corrida los píxeles del desplazamiento— en vez
// de volver a trazarla. Lo que queda al descubierto por el borde es el fondo del mapa; al soltar se rehace entera.
function cshGxShiftKey(G, V, w, h, sc) {
   var m = V.mode, v2 = (V.v2 && V.v2[m]) ? V.v2[m] : null, W = {}, k;
   for (k in V) if (V.hasOwnProperty(k)) W[k] = V[k];
   W.light = false; W.v2 = {}; W.v2[m] = { k: (v2 && v2.k > 0) ? v2.k : 1, cx: 0, cy: 0 };      // (sin v2 = aumentos 1: la misma clave)
   return cshGxStaticKey(G, W, w, h, sc);
}
function cshGxShiftOf(G, V, rect, full) {
   // (el corrimiento en píxeles de la vista 2D de V respecto a la de la capa entera guardada)
   var m = V.mode, P = cshGxProjector(G, V, rect);
   if (m === "top") return { dx: -(P.xf.ca - full.xa) * P.xf.ppk, dy: (P.xf.cb - full.xb) * P.xf.ppk, P: P };
   if (m === "edge") return { dx: -(P.xf.cR - full.xa) * P.xf.sx, dy: (P.xf.cz - full.xb) * P.xf.sz, P: P };
   return { dx: 0, dy: 0, P: P };
}
function cshGxStatic(cache, w, h, G, sc, V) {
   var key = cshGxStaticKey(G, V, w, h, sc);
   if (cache.bmp && cache.key === key && cache.C) return { bmp: cache.bmp, C: cache.C, fresh: false };
   // (26-oct: una vista girada o con pivote no se corre por píxeles: se rehace)
   if (V.light === true && cache.full && cache.full.C && !cache.full.C.empty && !cshGxBroken("noshift") && !(V.mode !== "3d" && V.v2 && cshGxV2Turned(V.v2[V.mode]))) {
      var sk = cshGxShiftKey(G, V, w, h, sc), F = cache.full;
      if (sk === F.skey && (V.mode !== "3d" || cshGxStaticKey(G, cshGxNoLight(V), w, h, sc) === F.key)) {
         var S = cshGxShiftOf(G, V, F.C.rect, F), dx = Math.round(S.dx), dy = Math.round(S.dy);
         if (dx === 0 && dy === 0) return { bmp: F.bmp, C: F.C, fresh: false, shifted: true };
         var bmp2 = (cache.bmp && cache.bmp !== F.bmp && cache.bmp.width === w && cache.bmp.height === h) ? cache.bmp : null;
         if (!bmp2) { if (cache.bmp && cache.bmp !== F.bmp) { try { cache.bmp.clear(); } catch (eS) {} } bmp2 = new Bitmap(Math.max(8, w), Math.max(8, h)); }
         bmp2.fill((V.dustUnder === true) ? 0x00000000 : cshGxBg(V));          // (26-oct, V7h: la de encima del polvo vivo, transparente)
         var r = F.C.rect, gs = new Graphics(bmp2);
         try {
            if (V.dustUnder !== true) gs.fillRect(new Rect(r.x, r.y, r.x + r.w, r.y + r.h), new Brush(cpInt(V.insetHex || cshGxInset())));
            gs.clipRect = new Rect(r.x, r.y, r.x + r.w, r.y + r.h);
            gs.drawBitmap(dx, dy, F.bmp);
         } finally { gs.end(); }
         // el contexto: la proyección NUEVA (las estrellas, los rótulos de los círculos), lo de la capa corrido, la rejilla solo con sus bordes
         var C = {}, kk;
         for (kk in F.C) if (F.C.hasOwnProperty(kk)) C[kk] = F.C[kk];
         C.P = S.P; C.O = cshGxOcc(w, h, sc);
         cshGxOccMark(C.O, 0, 0, w, r.y, 2); cshGxOccMark(C.O, 0, r.y + r.h, w, h, 2); cshGxOccMark(C.O, 0, 0, r.x, h, 2); cshGxOccMark(C.O, r.x + r.w, 0, w, h, 2);
         var R2 = {};
         for (kk in F.C.R) if (F.C.R.hasOwnProperty(kk)) R2[kk] = F.C.R[kk];
         R2.texts = F.C.R.texts.slice(); R2.labels = F.C.R.labels.slice();
         R2.gc = F.C.R.gc ? { x: F.C.R.gc.x + dx, y: F.C.R.gc.y + dy } : null;
         R2.arrowMid = F.C.R.arrowMid ? { x: F.C.R.arrowMid.x + dx, y: F.C.R.arrowMid.y + dy } : null;
         C.R = R2;
         cache.bmp = bmp2; cache.key = key; cache.C = C; cache.shifts = (cache.shifts || 0) + 1;
         return { bmp: bmp2, C: C, fresh: false, shifted: true };
      }
   }
   // (dos bitmaps como mucho: el de la última capa ENTERA —cache.full, de la que salen las copias corridas— y el de la última ligera)
   var light = (V.light === true), fullBmp = (cache.full && cache.full.bmp) ? cache.full.bmp : null, bmp = null;
   function fits(b) { return b && b.width === Math.max(8, w) && b.height === Math.max(8, h); }
   if (!light) bmp = fits(fullBmp) ? fullBmp : null;
   else bmp = (cache.bmp && cache.bmp !== fullBmp && fits(cache.bmp)) ? cache.bmp : null;
   if (!bmp) bmp = new Bitmap(Math.max(8, w), Math.max(8, h));
   if (cache.bmp && cache.bmp !== bmp && cache.bmp !== fullBmp) { try { cache.bmp.clear(); } catch (eF) {} }
   bmp.fill((V.dustUnder === true) ? 0x00000000 : cshGxBg(V));            // (ANTES de abrir el Graphics: un fill con el Graphics abierto no vale)
   var gb = new Graphics(bmp), C = null;
   try { C = cshGxPaintStatic(gb, w, h, G, sc, V); } finally { gb.end(); }
   cache.bmp = bmp; cache.key = key; cache.C = C; cache.renders = (cache.renders || 0) + 1;
   if (!light) {
      if (fullBmp && fullBmp !== bmp) { try { fullBmp.clear(); } catch (eO) {} }
      var Pf = C.P, xa = 0, xb = 0;
      if (Pf && Pf.kind === "top") { xa = Pf.xf.ca; xb = Pf.xf.cb; } else if (Pf && Pf.kind === "edge") { xa = Pf.xf.cR; xb = Pf.xf.cz; }
      cache.full = { bmp: bmp, C: C, key: key, skey: cshGxShiftKey(G, V, w, h, sc), xa: xa, xb: xb };
   }
   return { bmp: bmp, C: C, fresh: true };
}
function cshGxNoLight(V) { var W = {}; for (var k in V) if (V.hasOwnProperty(k)) W[k] = V[k]; W.light = false; return W; }
function cshGxStaticFree(cache) {
   if (!cache) return;
   var a = cache.bmp, b = cache.full ? cache.full.bmp : null;
   try { if (a) a.clear(); } catch (e) {}
   try { if (b && b !== a) b.clear(); } catch (e2) {}
   cache.bmp = null; cache.C = null; cache.key = ""; cache.full = null;
   if (cache.under) { cshGxStaticFree(cache.under); cache.under = null; }          // (26-oct, V7h: la capa de encima del polvo vivo)
}

// ---------------------------------------------------------------------------
// 2 · LA CAPA DEL INSTANTE: dónde está cada estrella y el Sol a V.tMyr, y su estela (de hoy al instante)
// ---------------------------------------------------------------------------
function cshGxPaintDynamic(g, w, h, G, sc, V, C) {
   var A = CSH_ATLAS, R = C.R, O = C.O, P = C.P, rect = C.rect, N = C.N, i;
   if (C.empty) return C;
   var tNow = cshGxIsNum(V.tMyr) ? V.tMyr : 0, pos = new Array(N), q3 = [0, 0, 0];
   var pxs = new Float32Array(N), pys = new Float32Array(N), pzs = new Float32Array(N), pms = new Float32Array(N), okv = new Uint8Array(N);
   // (30-oct-2026) V.visOf(e, tNow) → 0..1: cuánto se ve cada estrella en ese instante (el encendido por edad de «la Galaxia en el tiempo» de
   // CabraStars; 0 = no se pinta, ni su estela, ni se puede elegir). V.sunVis, lo mismo para el Sol. Sin ellos, todo a 1 (Cabra3D, igual que antes).
   var visFn = (typeof V.visOf === "function") ? V.visOf : null, vis = visFn ? new Float32Array(N) : null;
   g.antialiasing = true;
   g.clipRect = new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
   for (i = 0; i < N; ++i) {
      var p3 = cshGxPosAt(G, i, tNow, q3), X0 = p3[0], Y0 = p3[1], Z0 = p3[2];
      pos[i] = [X0, Y0, Z0];
      var q = P.pt(X0, Y0, Z0);
      pxs[i] = q.x; pys[i] = q.y; pzs[i] = q.z; pms[i] = q.m; okv[i] = q.ok ? 1 : 0;
      if (vis) { var vv = 1; try { vv = +visFn(G.stars[i], tNow); } catch (eV) { vv = 1; } vis[i] = (vv > 0) ? Math.min(1, vv) : 0; if (!(vis[i] > 0)) okv[i] = 0; }
   }
   // la ESTELA: de hoy al instante (como mucho los últimos V.trailMax Myr), de las órbitas dibujadas
   if (V.trail && tNow !== 0 && N && !cshGxBroken("time")) {
      var sub = cshGxOrbitSubset(G, V.light ? CSH_GX.MAX_ORBITS_LIGHT : CSH_GX.MAX_ORBITS), tMax = cshGxIsNum(V.trailMax) ? V.trailMax : CSH_GX.SHOW_MYR;
      var t0 = (Math.abs(tNow) > tMax) ? tNow - (tNow > 0 ? tMax : -tMax) : 0, alT = Math.max(0.12, Math.min(0.75, 4.5 / Math.sqrt(Math.max(1, sub.length))));
      // (como las órbitas: al reproducir —ligero— 1 px sin suavizar; si no, 1 px suavizado. Antes, 1,8 px suavizado: lo más caro del fotograma)
      g.antialiasing = !V.light;
      for (var si = 0; si < sub.length; ++si) {
         var eo = G.stars[sub[si]];
         if (!eo.tr) continue;
         if (vis && !(vis[sub[si]] > 0)) continue;
         var co = cshGxColorOf(eo, V);
         // (30-oct-2026) la estela, tan tenue como su estrella (sin V.visOf, vis es null y todo sigue a alT)
         var alS = vis ? alT * vis[sub[si]] : alT;
         cshGxOrbitSpan(g, P, eo.tr, t0, tNow, V.light ? 2 : 1, new Pen(cshGxRgbInt(co.rgb, alS), 1), O);
      }
      g.antialiasing = true;
      if (G.sun.tr && V.sunVis !== 0) cshGxOrbitSpan(g, P, G.sun.tr, t0, tNow, 1, new Pen(cpInt(A.text, 0.8), Math.max(1.2, 1.4 * sc)), null);
   }
   // las estrellas (los puntos se apuntan como «blandos» en la rejilla). El color de cada una se guarda por modo de color (no se
   // recalcula en cada fotograma) y las brochas se reutilizan; al arrastrar o reproducir, cuadraditos sin suavizar (como los puntos del
   // 3D del campo en vuelo: a 2-4 px no se distinguen y son la cuarta parte de caros)
   // (al girar —ligero— sin ordenar por profundidad: 5 539 puntos se ordenaban en cada fotograma; al soltar, ordenados)
   var order = (P.kind === "3d" && !V.light) ? cshGxDepthOrder(pzs, N) : null, rBase = (N > 400 ? 1.7 : 2.2) * sc, ck = V.colorKey || "", brushes = {}, pens = {};
   g.antialiasing = !V.light;
   // (23-oct-2026, tarde) LAS DE SOLO HOY (G.now: sin velocidad radial, con distancia): en «hoy» y quieto, debajo de las que tienen órbita, más
   // pequeñas y tenues; fuera de «hoy» no se pintan (sin velocidad no se sabe dónde estaban ni dónde estarán). R.nNow las cuenta.
   R.nNow = 0; R.nNowAll = (G.now && G.now.length) ? G.now.length : 0;
   // (al arrastrar —ligero— no: en las Pléyades son 7 700 puntos más y el giro del 3D pasaba de 23 a 45 ms —c3_galaxy X6, 23-oct, tarde—; al soltar vuelven)
   if (R.nNowAll && tNow === 0 && V.nowStars !== false && !V.light && !cshGxBroken("nonow")) {
      var rNow = Math.max(0.8, 0.62 * rBase), nb = {};
      for (i = 0; i < G.now.length; ++i) {
         var en = G.now[i], qn = P.pt(en.x, en.y, en.z);
         if (!qn.ok || qn.x < rect.x - 4 || qn.x > rect.x + rect.w + 4 || qn.y < rect.y - 4 || qn.y > rect.y + rect.h + 4) continue;
         if (en._ck !== ck || !en._cs) { en._cs = cshGxColorOf(en, V); en._ck = ck; }
         var mN = (P.kind === "3d") ? qn.m : 1, rN = rNow * (P.kind === "3d" ? cshGxDepthSize(mN) : 1), cN = cshGxRgbInt(en._cs.rgb, 0.55 * ((P.kind === "3d") ? Math.round(cshGxDepthDim(mN) * 8) / 8 : 1));
         var bN = nb[cN] || (nb[cN] = new Brush(cN));
         g.fillRect(qn.x - rN, qn.y - rN, qn.x + rN, qn.y + rN, bN);
         R.nNow++;
      }
   }
   for (var oi = 0; oi < N; ++oi) {
      i = order ? order[oi] : oi;
      if (!okv[i]) continue;
      if (pxs[i] < rect.x - 10 || pxs[i] > rect.x + rect.w + 10 || pys[i] < rect.y - 10 || pys[i] > rect.y + rect.h + 10) continue;
      var es = G.stars[i];
      if (es._ck !== ck || !es._cs) { es._cs = cshGxColorOf(es, V); es._ck = ck; }
      var cs = es._cs, m = pms[i], rS = rBase * (P.kind === "3d" ? cshGxDepthSize(m) : 1), dim = (P.kind === "3d") ? cshGxDepthDim(m) : 1;
      if (vis) dim *= vis[i];
      var ci = cshGxRgbInt(cs.rgb, (cs.hollow ? 0.8 : 0.92) * (Math.round(dim * 8) / 8));
      if (cs.hollow) { var pn = pens[ci] || (pens[ci] = new Pen(ci, Math.max(1, 0.9 * sc))); g.pen = pn; cshGxNoBrush(g); g.drawCircle(pxs[i], pys[i], rS); }
      else {
         var br = brushes[ci] || (brushes[ci] = new Brush(ci));
         if (V.light) g.fillRect(pxs[i] - rS, pys[i] - rS, pxs[i] + rS, pys[i] + rS, br); else g.fillCircle(pxs[i], pys[i], rS, br);
      }
      cshGxOccMark(O, pxs[i] - rS, pys[i] - rS, pxs[i] + rS, pys[i] + rS, 1);
      R.nStars++;
   }
   g.antialiasing = true;
   // el Sol (encima de los puntos)
   var sx3 = cshGxPosAt(G, -1, tNow, [0, 0, 0]), qs = P.pt(sx3[0], sx3[1], sx3[2]);
   if (qs.ok && V.sunVis !== 0) {
      g.pen = new Pen(cpInt(A.text, 0.95), Math.max(1, 1.2 * sc)); cshGxNoBrush(g); g.drawCircle(qs.x, qs.y, 5 * sc);
      g.fillCircle(qs.x, qs.y, 1.5 * sc, new Brush(cpInt(A.text, 0.95)));
      cshGxOccMark(O, qs.x - 6 * sc, qs.y - 6 * sc, qs.x + 6 * sc, qs.y + 6 * sc, 2);
      R.sun = { x: qs.x, y: qs.y, X: sx3[0], Y: sx3[1], Z: sx3[2] };
   }
   g.clipRect = new Rect(0, 0, w, h);
   // --- lo proyectado, para el ratón ---
   var idxs = new Int32Array(N);
   for (i = 0; i < N; ++i) idxs[i] = G.stars[i].i;
   G.proj = { kind: P.kind, x: pxs, y: pys, z: pzs, ok: okv, idx: idxs, n: N, rect: rect, P: P, w: w, h: h, tMyr: tNow };
   C.pxs = pxs; C.pys = pys; C.pzs = pzs; C.pms = pms; C.okv = okv; C.pos = pos; C.tNow = tNow;
   return C;
}

// ---------------------------------------------------------------------------
// 3 · ENCIMA: la elegida, la leyenda, la escala o los ejes, la placa del instante, los rótulos, el marco y el pie
// ---------------------------------------------------------------------------
function cshGxPaintOver(g, w, h, G, sc, V, C) {
   var A = CSH_ATLAS, t0 = Date.now(), R = C.R, O = C.O, P = C.P, rect = C.rect, bounds = C.bounds, N = C.N, pxs = C.pxs, pys = C.pys;
   if (C.empty) { R.ms = Date.now() - C.t0; return R; }
   var okv = C.okv, pos = C.pos, ringLbl = C.ringLbl, i;
   var fLb = cpFont("text", 8.4 * sc, true), fS = cpFont("text", 7.8 * sc), fSun = cpFont("display", 9 * sc, false, true);
   g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
   var selK = (cshGxIsNum(V.sel) && V.sel >= 0 && G.byIdx.hasOwnProperty(V.sel)) ? G.byIdx[V.sel] : -1;
   g.clipRect = new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
   // --- la elegida: su órbita entera tenue (pasado y futuro guardados), su ventana marcada y su sitio ---
   if (selK >= 0) {
      var ek = G.stars[selK], ck = cshGxColorOf(ek, V), lt = cshGxLighter(ck.rgb, 0.25), win = cshGxOrbitWindow(G);
      // (V.selTr: la trayectoria de la elegida guardada en CADA paso —0,5 Myr— si el script la da: con un punto cada 2 Myr, una de halo
      //  que baja a 0,2 kpc del centro salía con esquinas de canto —captura de las Pléyades, 23-oct—)
      var trS = V.selTr || ek.tr;
      if (trS) {
         var st4 = V.light ? 4 : 1, wS = (trS === ek.tr) ? 1 : 1;
         cshGxOrbitSpan(g, P, trS, -(G.backMyr || 0), trS.tMyr, st4, new Pen(cshGxRgbInt(lt, 0.28), Math.max(1, 0.9 * sc)), null);
         cshGxOrbitSpan(g, P, trS, win[0], win[1], wS * st4, new Pen(cpInt(A.bg, 0.55), Math.max(2, 3.6 * sc)), null);
         cshGxOrbitSpan(g, P, trS, win[0], win[1], wS * st4, new Pen(cshGxRgbInt(lt, 0.95), Math.max(1.5, 1.7 * sc)), O);
      }
      if (okv[selK]) {
         var xk = pxs[selK], yk = pys[selK];
         if (P.kind === "3d") {       // la caída hasta el plano del disco: se ve a qué altura está
            var qd = P.pt(pos[selK][0], pos[selK][1], 0);
            if (qd.ok) { g.pen = cshGxPen(cshGxRgbInt(lt, 0.6), Math.max(1, 0.9 * sc), true); g.drawLine(xk, yk, qd.x, qd.y); g.fillCircle(qd.x, qd.y, 1.6 * sc, new Brush(cshGxRgbInt(lt, 0.6))); }
         }
         if (ck.hollow) { g.pen = new Pen(cshGxRgbInt(ck.rgb, 1), Math.max(1, 1.2 * sc)); cshGxNoBrush(g); g.drawCircle(xk, yk, 3.2 * sc); }
         else g.fillCircle(xk, yk, 3.2 * sc, new Brush(cshGxRgbInt(ck.rgb, 1)));
         g.pen = new Pen(cpInt(A.gold), Math.max(1.5, 1.6 * sc)); cshGxNoBrush(g); g.drawCircle(xk, yk, 7 * sc);
         cshGxOccMark(O, xk - 8 * sc, yk - 8 * sc, xk + 8 * sc, yk + 8 * sc, 2);
         R.sel = { x: xk, y: yk, k: selK, i: ek.i };
      }
   }
   // --- la LEYENDA (arriba a la derecha), la PLACA del instante (arriba a la izquierda) y la ESCALA: se reservan antes de los rótulos ---
   g.clipRect = new Rect(0, 0, w, h);
   var fxv = rect.fx || null, legAt = fxv ? fxv.legend : "tr", plAt = fxv ? fxv.plate : "tl";
   if (typeof V.plateAt === "string" && V.plateAt.length) plAt = V.plateAt;          // (26-oct: la esquina de la placa que elige el script —los vuelos de Cabra3D en 2D—; sin ella, lo de siempre)
   var leg = (V.legendOn !== false) ? cshGxLegend(g, R, V, G, rect, sc, true, legAt) : null;
   if (leg) cshGxOccMark(O, leg.x0, leg.y0, leg.x1, leg.y1, 2);
   var plate = (V.plate && V.plate.length) ? cshGxPlate(g, R, V.plate, rect, sc, true, plAt, V.plateK, 0, V.plateWrap) : null;
   if (plate) cshGxOccMark(O, plate.x0, plate.y0, plate.x1, plate.y1, 2);
   if (V.reserve) for (var rv = 0; rv < V.reserve.length; ++rv) cshGxOccMark(O, V.reserve[rv][0], V.reserve[rv][1], V.reserve[rv][2], V.reserve[rv][3], 2);
   if (P.kind === "top") {
      var ppk = P.xf.ppk, want = rect.w * 0.18 / ppk, cand = [0.5, 1, 2, 5, 10, 20], kpc = cand[0];
      for (var ci = 0; ci < cand.length; ++ci) if (cand[ci] <= want) kpc = cand[ci];
      var barPx = kpc * ppk * (cshGxBroken("scale") ? 1.5 : 1), bx1 = rect.x + rect.w - 12 * sc, bx0 = bx1 - barPx, by = rect.y + rect.h - 12 * sc;
      var stxt = cshGxF("gxRing", { n: cshGxNum(kpc, kpc < 1 ? 1 : 0) });
      var scaleBox = { x0: bx0 - 4 * sc, y0: by - fS.ascent - 8 * sc, x1: bx1 + 4 * sc, y1: by + 5 * sc };
      g.fillRect(new Rect(scaleBox.x0, scaleBox.y0, scaleBox.x1, scaleBox.y1), new Brush(cpInt(A.bg, 0.78)));
      cshGxNoBrush(g);
      g.pen = new Pen(cpInt(A.text, 0.9), Math.max(1, 1.2 * sc));
      g.drawLine(bx0, by, bx1, by); g.drawLine(bx0, by - 3 * sc, bx0, by + 3 * sc); g.drawLine(bx1, by - 3 * sc, bx1, by + 3 * sc);
      cshGxText(g, R, fS, cpInt(A.text2), (bx0 + bx1 - fS.width(stxt)) / 2, by - 5 * sc, stxt);
      cshGxOccMark(O, scaleBox.x0, scaleBox.y0, scaleBox.x1, scaleBox.y1, 2);
      R.scale = { kpc: kpc, px: barPx, ppk: ppk };
   } else if (P.kind === "edge") {
      var xe3 = P.xf, Ra = xe3.inv(rect.x, 0).R, Rb = xe3.inv(rect.x + rect.w, 0).R, za = xe3.inv(0, rect.y + rect.h).z, zb = xe3.inv(0, rect.y).z;
      var sR = cshGxNiceStep(Rb - Ra, 6), sZ = cshGxNiceStep(zb - za, 5), dR = (sR < 1) ? 1 : 0, dZ = (sZ < 1) ? (sZ < 0.1 ? 2 : 1) : 0;
      // (24-oct, revisor visual del polvo: con la leyenda abajo a la izquierda, las cifras de los ejes quedaban DEBAJO de ella. Una cifra que
      //  cae bajo la leyenda o la placa no se pinta)
      function underBox(x0, y0, x1, y1) { var bs = [leg, plate]; for (var bq = 0; bq < bs.length; ++bq) { var b = bs[bq]; if (b && x0 < b.x1 + 2 && x1 > b.x0 - 2 && y0 < b.y1 + 2 && y1 > b.y0 - 2) return true; } return false; }
      // (26-oct: en la vista lineal desde otro azimut —xf.lin— lo de a lo ancho ya no es R: ni sus cifras ni su rótulo)
      for (var tR = Math.ceil(Ra / sR) * sR; tR <= Rb + 1e-9 && !xe3.lin; tR += sR) {
         var lx = xe3.px(tR, 0).x, ltx = cshGxNum(tR, dR);
         if (lx - fS.width(ltx) / 2 < rect.x + 30 * sc || lx + fS.width(ltx) / 2 > rect.x + rect.w - 4 * sc) continue;
         if (underBox(lx - fS.width(ltx) / 2, rect.y + rect.h - 5 * sc - fS.ascent, lx + fS.width(ltx) / 2, rect.y + rect.h)) continue;
         cshGxHalo(g, R, fS, cpInt(A.text3), lx - fS.width(ltx) / 2, rect.y + rect.h - 5 * sc, ltx, sc);
         cshGxOccMark(O, lx - fS.width(ltx) / 2 - 2, rect.y + rect.h - 5 * sc - fS.ascent - 2, lx + fS.width(ltx) / 2 + 2, rect.y + rect.h, 2);
      }
      for (var tz = Math.ceil(za / sZ) * sZ; tz <= zb + 1e-9; tz += sZ) {
         var ly = xe3.px(0, tz).y, lzt = cshGxSigned(tz, dZ);
         if (Math.abs(tz) < 1e-9 || ly < rect.y + 34 * sc || ly > rect.y + rect.h - 18 * sc) continue;
         if (underBox(rect.x, ly - fS.ascent, rect.x + 6 * sc + fS.width(lzt), ly + fS.ascent / 2 + 2)) continue;
         cshGxHalo(g, R, fS, cpInt(A.text3), rect.x + 4 * sc, ly + fS.ascent / 2 - 1, lzt, sc);
         cshGxOccMark(O, rect.x, ly - fS.ascent, rect.x + 6 * sc + fS.width(lzt), ly + fS.ascent / 2 + 2, 2);
      }
      var axR = cshGxT("gxAxisR"), axZ = cshGxT("gxAxisZ");
      if (!xe3.lin) cshGxHalo(g, R, fS, cpInt(A.text2), rect.x + rect.w - fS.width(axR) - 6 * sc, rect.y + rect.h - 7 * sc - fS.ascent - 4 * sc, axR, sc);
      if (!xe3.lin) cshGxOccMark(O, rect.x + rect.w - fS.width(axR) - 8 * sc, rect.y + rect.h - 7 * sc - 2 * fS.ascent - 6 * sc, rect.x + rect.w, rect.y + rect.h - 7 * sc - fS.ascent, 2);
      // (la «z» del eje, debajo de la placa si la hay: arriba a la izquierda es su sitio)
      var zY = (plate && plAt === "tl") ? plate.y1 + 12 * sc : ((leg && legAt === "tl") ? leg.y1 + 12 * sc : rect.y + 13 * sc);
      cshGxHalo(g, R, fS, cpInt(A.text2), rect.x + 4 * sc, zY, axZ, sc);
      cshGxOccMark(O, rect.x, zY - fS.ascent - 2, rect.x + 8 * sc + fS.width(axZ), zY + 3 * sc, 2);
   }
   // --- los RÓTULOS (por prioridad): el centro (29-oct), la elegida, el Sol, el giro, el plano, los círculos ---
   g.clipRect = new Rect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
   // (29-oct-2026, «el rótulo del Centro galáctico salta»: el centro es el único punto QUIETO del mapa y su rótulo va PRIMERO —antes iba
   //  detrás de la elegida y del Sol, que se mueven: al pasar el rótulo del Sol por su sitio lo echaba a otro lado y luego volvía—; con `fix`,
   //  junto a su cruz sin mirar los puntos ni su propia marca —cshGxPlace—. ROJO «gcjump»: el orden y el criterio de antes.)
   var gcFirst = !cshGxBroken("gcjump");
   var gcPlace = function() {
      if (!R.gc) return;
      var gck = R.gc.k || 5 * sc;
      R.gcLabel = cshGxPlace(g, R, O, [{ t: cshGxT("gxGC"), f: fSun, c: cpInt(A.gold) }], R.gc.x, R.gc.y, 8 * sc, sc, bounds, { own: [R.gc.x - gck, R.gc.y - gck, R.gc.x + gck, R.gc.y + gck] });
   };
   if (gcFirst) gcPlace();
   // (29-oct-2026, tarde, «fija el rótulo Sol»: el mismo defecto que el del centro —con los puntos y las estelas debajo, el Sol cambiaba de lado
   //  cada pocos fotogramas— y el mismo arreglo: `fix` con su propia marca (±6 px lógicos, la de arriba) y SEGUNDO, antes de la elegida, que
   //  también se mueve. Solo se aparta si choca con algo duro: el rótulo del centro o el borde. ROJO «sunjump»: el orden y el criterio de antes.)
   var sunFirst = !cshGxBroken("sunjump");
   var sunPlace = function() {
      if (!R.sun) return;
      var sk = 6 * sc;
      R.sunLabel = cshGxPlace(g, R, O, [{ t: cshGxT("gxSun"), f: fSun, c: cpInt(A.text) }], R.sun.x, R.sun.y, 8 * sc, sc, bounds, sunFirst ? { own: [R.sun.x - sk, R.sun.y - sk, R.sun.x + sk, R.sun.y + sk] } : null);
   };
   if (sunFirst) sunPlace();
   if (R.sel && V.selLabel !== false) {          // (26-oct-2026: Cabra3D, en el panel, pone el texto en la ficha de abajo y deja en el mapa solo la marca: V.selLabel = false)
      // (las cifras: las de la FICHA si el script las da —V.selMeas: 2 Gyr hacia el futuro, como CabraComposition—; si no, las del tramo integrado)
      var ek2 = G.stars[selK], o2 = V.selMeas || ek2.meas, lines = [{ t: ek2.name || "—", f: fLb, c: cpInt(A.goldLight) }];
      if (o2 && cshGxBroken("orbit420") && ek2.tr) {
         // (ROJO «orbit420»: las cifras medidas solo en los 420 Myr que se dibujan, no en los 2 Gyr del motor)
         var nW = Math.min(ek2.tr.n, Math.round(CSH_GX.SHOW_MYR / CSH_GX.DT_MYR / CSH_GX.EVERY) + 1), r0 = 1e9, r1 = 0, z1 = 0;
         for (var iw = 0; iw < nW; ++iw) { var rw = Math.sqrt(ek2.tr.x[iw] * ek2.tr.x[iw] + ek2.tr.y[iw] * ek2.tr.y[iw] + ek2.tr.z[iw] * ek2.tr.z[iw]); r0 = Math.min(r0, rw); r1 = Math.max(r1, rw); z1 = Math.max(z1, Math.abs(ek2.tr.z[iw])); }
         o2 = { bound: true, rperi: r0, rapo: r1, zmax: z1, ecc: (r1 - r0) / (r1 + r0) };
      }
      var ol = cshGxOrbitLine(o2);
      if (ol) lines.push({ t: ol, f: fS, c: cpInt(A.text) });
      if (V.selExtra) lines.push({ t: String(V.selExtra), f: fS, c: cpInt(A.text3) });
      R.selLines = []; for (var sl = 0; sl < lines.length; ++sl) R.selLines.push(lines[sl].t);
      R.selLabel = cshGxPlace(g, R, O, lines, R.sel.x, R.sel.y, 11 * sc, sc, bounds);
   }
   if (!sunFirst) sunPlace();
   if (!gcFirst) gcPlace();
   if (R.arrowMid) cshGxPlace(g, R, O, [{ t: cshGxT("gxRotation"), f: fS, c: cpInt(A.goldLight, 0.85) }], R.arrowMid.x, R.arrowMid.y, 6 * sc, sc, bounds);
   if (P.kind === "edge") {
      var qpl = P.xf.px(P.xf.inv(rect.x + rect.w * 0.82, 0).R, 0);
      cshGxPlace(g, R, O, [{ t: cshGxT("gxPlane"), f: fS, c: cpInt(A.text3) }], qpl.x, qpl.y, 5 * sc, sc, bounds);
   }
   for (var rl = 0; rl < ringLbl.length; ++rl) cshGxRingLabel(g, R, O, P, ringLbl[rl], fS, sc, bounds, cpInt(A.text3, 0.85));
   g.clipRect = new Rect(0, 0, w, h);
   if (leg) cshGxLegend(g, R, V, G, rect, sc, false, legAt);
   if (plate) cshGxPlate(g, R, V.plate, rect, sc, false, plAt, V.plateK, V.plateA, V.plateWrap);
   // --- el marco y el pie ---
   cshGxNoBrush(g);
   if (C.chrome || C.framed) { g.pen = new Pen(cpInt(A.line), 1); g.drawRect(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h); }
   // (23-oct, noche: una sola frase para las que no tienen órbita —antes «977 sin velocidad radial o sin distancia · 977 en su sitio de hoy»—)
   var nNow = (G.now && G.now.length) ? G.now.length : 0, hid = (C.tNow !== 0);
   // (las cifras con su separador de miles —«5 539», textos_galaxia.md §3—: cpSvGroup de csh_view.js si está; si no, tal cual)
   function gi(v) { return (typeof cpSvGroup === "function") ? cpSvGroup(v) : String(v); }
   var footL = ((nNow > 0 && nNow >= G.nNoKin) ? cshGxF(hid ? "gxFootAllNowHidden" : "gxFootAllNow", { n: gi(N), m: gi(G.nNoKin) })
               : (nNow > 0) ? cshGxF(hid ? "gxFootPartNowHidden" : "gxFootPartNow", { n: gi(N), m: gi(G.nNoKin), k: gi(nNow) }) : cshGxF("gxFoot", { n: gi(N), m: gi(G.nNoKin) })) +
               (G.nUnbound ? " · " + cshGxF("gxUnbound", { n: gi(G.nUnbound) }) : "");
   if (cshGxBroken("footdup")) footL = cshGxF("gxFoot", { n: gi(N), m: gi(G.nNoKin) }) + (nNow ? " · " + cshGxF(hid ? "gxNowHidden" : "gxNowFoot", { n: gi(nNow) }) : "");   // (ROJO «footdup»: lo de antes)
   var footR = (V.orbits !== false) ? cshGxT((typeof cshGdBarOn === "function" && cshGdBarOn()) ? "gxFootOrbitBar" : "gxFootOrbit") : cshGxT("gxFootNow");   // (Q2b: con la barra, lo dice)
   if (V.orbits !== false && R.orbitsAll > R.orbitsDrawn) footR = cshGxF("gxOrbitsSubset", { n: gi(R.orbitsDrawn), m: gi(R.orbitsAll) }) + " · " + footR;
   R.footText = footL + " · " + footR;
   if (C.chrome) {
      var fy = rect.y + rect.h + Math.round(13 * sc), wR = fS.width(footR), maxL = rect.w - wR - 20 * sc;
      cshGxText(g, R, fS, cpInt(A.text3), rect.x, fy, cpElide(fS, footL, Math.max(40, maxL)));
      cshGxText(g, R, fS, cpInt(A.text3), rect.x + rect.w - wR, fy, footR);
   }
   if (!N && !cshGxBroken("smallempty")) {
      // (23-oct-2026, tarde, queja de Nino: «en Galaxia no se pinta nada». Antes, una línea pequeña en cursiva en medio del mapa. Ahora, EN GRANDE
      // y con el porqué —V.emptyWhy, lo dice el script: la red aún no ha traído las velocidades radiales, no ha contestado, o Gaia no
      // tiene ninguna en este campo— y lo que sí se ve: las de solo hoy.)
      var fB2 = cpFont("display", 17 * sc, false, true), fW2 = cpFont("text", 9.6 * sc), fS2 = cpFont("text", 8.6 * sc, false, true);
      var rows2 = [{ t: cshGxT("gxNoKinBig"), f: fB2, c: cpInt(A.goldLight) }], whys = (V.emptyWhy && V.emptyWhy.length) ? V.emptyWhy : [cshGxT("gxNoKin")], maxW2 = rect.w * 0.7;
      for (var wi = 0; wi < whys.length; ++wi) {
         var words2 = String(whys[wi]).split(" "), cur2 = "";
         for (var wk = 0; wk < words2.length; ++wk) { var tr2 = cur2.length ? cur2 + " " + words2[wk] : words2[wk]; if (cur2.length && fW2.width(tr2) > maxW2) { rows2.push({ t: cur2, f: fW2, c: cpInt(A.text) }); cur2 = words2[wk]; } else cur2 = tr2; }
         if (cur2.length) rows2.push({ t: cur2, f: fW2, c: cpInt(A.text) });
      }
      if (G.now && G.now.length) rows2.push({ t: cshGxF(C.tNow === 0 ? "gxNowOnly" : "gxNowOnlyHidden", { n: G.now.length }), f: fS2, c: cpInt(A.text2) });
      var W2 = 0, H2 = 0, gap2 = Math.round(5 * sc), pad2 = Math.round(14 * sc);
      for (var ri = 0; ri < rows2.length; ++ri) { W2 = Math.max(W2, rows2[ri].f.width(rows2[ri].t)); H2 += rows2[ri].f.ascent + rows2[ri].f.descent + gap2; }
      // (arriba, bajo la leyenda y la placa: en medio tapaba el Sol y las de solo hoy, que están junto a él —captura del 23-oct, tarde—)
      var bx0 = rect.x + (rect.w - W2) / 2 - pad2, by0 = Math.max(rect.y + rect.h * 0.1, leg ? leg.y1 : 0, plate ? plate.y1 : 0) + Math.round(12 * sc);
      g.fillRect(new Rect(bx0, by0, bx0 + W2 + 2 * pad2, by0 + H2 + 2 * pad2), new Brush(cpInt(A.bg, 0.9)));
      g.pen = new Pen(cpInt(A.gold, 0.8), Math.max(1, sc)); cshGxNoBrush(g); g.drawRect(bx0, by0, bx0 + W2 + 2 * pad2, by0 + H2 + 2 * pad2);
      var yy2 = by0 + pad2;
      for (ri = 0; ri < rows2.length; ++ri) { yy2 += rows2[ri].f.ascent; cshGxText(g, R, rows2[ri].f, rows2[ri].c, rect.x + (rect.w - rows2[ri].f.width(rows2[ri].t)) / 2, yy2, rows2[ri].t); yy2 += rows2[ri].f.descent + gap2; }
      R.empty = { big: true, lines: rows2.map(function(r) { return r.t; }), box: { x0: bx0, y0: by0, x1: bx0 + W2 + 2 * pad2, y1: by0 + H2 + 2 * pad2 } };
   } else if (!N) {
      // (ROJO «smallempty»: lo de antes, una línea pequeña)
      var fm2 = cpFont("text", 10 * sc, false, true), msg2 = cshGxT("gxNoKin"), wm = fm2.width(msg2);
      g.fillRect(new Rect(rect.x + (rect.w - wm) / 2 - 10 * sc, rect.y + rect.h / 2 - 18 * sc, rect.x + (rect.w + wm) / 2 + 10 * sc, rect.y + rect.h / 2 + 8 * sc), new Brush(cpInt(A.bg, 0.85)));
      cshGxText(g, R, fm2, cpInt(A.text2), rect.x + (rect.w - wm) / 2, rect.y + rect.h / 2, msg2);
   }
   R.msOver = Date.now() - t0;
   R.ms = Date.now() - C.t0;
   return R;
}
// TODO EL MAPA de una vez (sin bitmap guardado): las tres capas.
function cshGalaxyPaint(g, w, h, G, sc, V) {
   var C = cshGxPaintStatic(g, w, h, G, sc, V || {});
   if (C.empty) return C.R;
   cshGxPaintDynamic(g, w, h, G, sc, V || {}, C);
   return cshGxPaintOver(g, w, h, G, sc, V || {}, C);
}

// LA PLACA DEL INSTANTE (arriba a la izquierda del mapa): lines = [{ t, kind: "big" | "warn" | "small" }]. measureOnly: el rectángulo.
// (23-oct, noche) `at`: la esquina (tl de fábrica, tr, bl, br: la elige cshGxFitView donde no hay estrellas); `k`: el tamaño (el vídeo la pide mayor)
// (25-oct, fase 2 del RELOJ) una línea puede ser un RELOJ: { kind: "clock", w, h, paint(g, x, y) → lo pintado } — una fila de ese tamaño, centrada,
// que se pinta con su propio dibujo (Cabra3D, tm/timeclock.js: sustituye a la cifra grande del instante, que pasa a ser la cifra exacta del reloj).
// No se parte en renglones; lo que pinta paint queda en R.plate.clock.
// (26-oct) bgA: la opacidad del fondo de la placa (de fábrica 0,84; los vídeos de Cabra3D la bajan: el mapa se intuye)
// (27-oct, D1) wrapW: el ancho al que se parten los renglones (de fábrica, media vista). El panel de Cabra3D da el ancho del reloj: la placa no
// se ensancha más que su reloj (antes, con la línea del modelo, ocupaba media vista y en un panel estrecho pisaba la leyenda y el mapa).
function cshGxPlate(g, R, lines, rect, sc, measureOnly, at, k, bgA, wrapW) {
   var kk = (k > 0) ? k : 1, A = CSH_ATLAS, pad = Math.round(7 * sc * kk), fB = cpFont("display", 12 * sc * kk, false, true), fW = cpFont("text", 7.8 * sc * kk, true), fM = cpFont("text", 7.8 * sc * kk);
   var maxW = (wrapW > 0) ? Math.round(wrapW) : Math.round(rect.w * 0.5), rows = [], wMax = 0, i;
   function fontOf(k) { return (k === "big") ? fB : ((k === "warn") ? fW : fM); }
   for (i = 0; i < lines.length; ++i) {
      if (lines[i].kind === "clock") { rows.push({ t: "", f: null, kind: "clock", w: lines[i].w, h: lines[i].h, paint: lines[i].paint }); continue; }
      var f = fontOf(lines[i].kind), words = String(lines[i].t).split(" "), cur = "";
      // (nada se corta con «…»: lo largo se parte en renglones del ancho de media vista)
      for (var k = 0; k < words.length; ++k) {
         var tryT = cur.length ? cur + " " + words[k] : words[k];
         if (cur.length && f.width(tryT) > maxW) { rows.push({ t: cur, f: f, kind: lines[i].kind }); cur = words[k]; } else cur = tryT;
      }
      if (cur.length) rows.push({ t: cur, f: f, kind: lines[i].kind });
   }
   function rowH(r) { return (r.kind === "clock") ? r.h : r.f.ascent + r.f.descent; }
   for (i = 0; i < rows.length; ++i) wMax = Math.max(wMax, (rows[i].kind === "clock") ? rows[i].w : rows[i].f.width(rows[i].t));
   var H = 0;
   for (i = 0; i < rows.length; ++i) H += rowH(rows[i]) + Math.round(2 * sc);
   var bw = wMax + 2 * pad, bh = H + 2 * pad - Math.round(2 * sc), cb = cshGxCornerBox(at || "tl", bw, bh, rect, Math.round(8 * sc)), x0 = cb.x0, y0 = cb.y0, box = { x0: x0, y0: y0, x1: x0 + bw, y1: y0 + bh };
   if (measureOnly) return box;
   g.fillRect(new Rect(box.x0, box.y0, box.x1, box.y1), new Brush(cpInt(A.bg, (bgA > 0 && bgA <= 1) ? bgA : 0.84)));
   g.pen = new Pen(cpInt(A.line), 1); cshGxNoBrush(g);
   g.drawRect(box.x0, box.y0, box.x1, box.y1);
   g.fillRect(new Rect(box.x0, box.y0, box.x0 + Math.max(2, Math.round(2 * sc)), box.y1), new Brush(cpInt(A.gold)));
   var y = y0 + pad, clk = null;
   for (i = 0; i < rows.length; ++i) {
      if (rows[i].kind === "clock") {
         // (centrado en la placa, sin contar la barra de oro de la izquierda)
         var cxm = Math.round(x0 + Math.max(2, Math.round(2 * sc)) + (bw - Math.max(2, Math.round(2 * sc)) - rows[i].w) / 2);
         if (typeof rows[i].paint === "function") clk = rows[i].paint(g, cxm, Math.round(y));
         y += rows[i].h + Math.round(2 * sc);
         continue;
      }
      y += rows[i].f.ascent;
      var col = (rows[i].kind === "big") ? cpInt(A.text) : ((rows[i].kind === "warn") ? cpInt(A.goldLight) : cpInt(A.text3));
      cshGxText(g, R, rows[i].f, col, x0 + pad + Math.round(2 * sc), y, rows[i].t);
      y += rows[i].f.descent + Math.round(2 * sc);
   }
   R.plate = { x0: box.x0, y0: box.y0, x1: box.x1, y1: box.y1, rows: rows.length, at: at || "tl", clock: clk };
   return box;
}

// (26-oct, V7i; Nino: «al encender el polvo, la leyenda cambia de esquina de canto… busca una mejor solución») LA LEYENDA MAYOR: el encuadre de
// la nube y la esquina de la leyenda se eligen con la leyenda MÁS GRANDE que puede llegar a ser en esa vista —con la fila del polvo aunque esté
// apagado, la estela aunque se esté en «hoy», el texto más ancho de cada fila—, igual que la placa se mide con V.plateMax. Así ni la esquina
// ni el encuadre dependen de las capas encendidas ni del instante: encender el polvo o salir de «hoy» solo alarga o acorta la leyenda en su
// sitio. Lo que no cambia: la esquina sigue siendo la de menos estrellas en toda la escala de tiempo (no tapa). ROJO CSH_GX_BREAK «legjump»: lo de antes.
function cshGxLegendMax(V, G, rect, sc) {
   if (cshGxBroken("legjump")) return cshGxLegend(null, null, V, G, rect, sc, true);
   var W = {}, k;
   for (k in V) if (V.hasOwnProperty(k)) W[k] = V[k];
   W.legendMeasureMax = true;
   return cshGxLegend(null, null, W, G, rect, sc, true);
}
// Los textos de la fila del polvo [el de ahora, los demás que puede tener en esta vista]. R (lo pintado): de canto, R.dust.stretch (V7g).
function cshGxDustRowTexts(V, R) {
   var edge = (V.mode === "edge"), cmp = (V.legendCompact === true), n = (typeof CSH_GXD === "object" && CSH_GXD.EVO) ? CSH_GXD.EVO.ILLUS : 20;
   var t = (typeof V.dustMyr === "number" && isFinite(V.dustMyr) && !cshGxdBroken("frozen")) ? V.dustMyr : 0;
   var st = (R && R.dust && R.dust.stretch > 1) ? R.dust.stretch : 1;
   // (6-nov-2026) de canto sin nada medido (la rejilla sin Vergely: edge.cov null) la leyenda no promete un recuadro que no se pinta
   var edgeMeas = !!(edge && typeof cshGxdData === "function" && cshGxdData() && cshGxdData().edge && cshGxdData().edge.cov);
   var nowK = cmp ? "gxDiscDust" : (cshGxdBroken("noseam") ? "gxDustRowPlain" : (edge ? (edgeMeas ? "gxDustRowEdge" : "gxDustRowEdgeModel") : "gxDustRow"));
   var turnK = cmp ? "gxDiscDustT" : (edge ? nowK : "gxDustRowT"), illK = cmp ? "gxDiscDustIllus" : "gxDustRowIllus";
   function tx(key, s) { var x = cshGxF(key, { n: cshGxNum(n, 0) }); return (edge && s > 1) ? x + cshGxF("gxDustThick", { n: String(s) }) : x; }
   var cur = (t === 0) ? tx(nowK, st) : ((Math.abs(t) > n) ? tx(illK, st) : tx(turnK, st));
   return [cur, tx(nowK, 10), tx(turnK, 10), tx(illK, 10)];
}
// LA LEYENDA, arriba a la derecha del mapa. V.legend = { title, items: [{ rgb, hollow, text }], gradient: { from, to, rgb(v), ticks: [v],
// tickText(v), none (el texto del punto hueco gris) }, extra: [{ hollow, text }], extraMax (las filas que pueden salir: para medir la mayor) }.
// measureOnly: solo el rectángulo (para reservarlo).
function cshGxLegend(g, R, V, G, rect, sc, measureOnly, at) {
   var A = CSH_ATLAS, f = cpFont("text", 8.2 * sc), fH = cpFont("text", 7.6 * sc, false, false, Math.round(7.6 * sc * A.labelTracking));
   var rowH = Math.round(13 * sc), pad = Math.round(8 * sc), Lg = V.legend || {}, items = (Lg.items || []).slice(), gradient = Lg.gradient || null, i;
   var extra = (Lg.extra || []).slice(), mmax = (V.legendMeasureMax === true);
   // (26-oct, V7i) al medir la MAYOR: también las filas que el script dice que pueden salir (Lg.extraMax: la estela, que sale fuera de «hoy»)
   if (mmax && Lg.extraMax) for (var em = 0; em < Lg.extraMax.length; ++em) { var has = false; for (var eh = 0; eh < extra.length; ++eh) if (extra[eh].kind === Lg.extraMax[em].kind) has = true; if (!has) extra.push(Lg.extraMax[em]); }
   if (G && G.now && G.now.length && V.nowStars !== false) extra.unshift({ kind: "now", text: cshGxT("gxNowLegend") });
   extra.push({ kind: "sun", text: cshGxT("gxSun") });
   if (V.mode !== "edge" && V.arms !== false) extra.push({ kind: "arm", text: cshGxT("gxArms") });
   extra.push({ kind: "glow", text: cshGxT("gxDisc") });
   // (24-oct-2026, V7f) el polvo: UNA fila (medido | modelo y la costura); sus cifras, en el tooltip del script
   // (26-oct, V7h/V7g) su texto sigue al instante —«girado con la Galaxia», «posición ilustrativa pasados 20 Ma»— y, de canto, al grosor; al medir la
   // MAYOR, la fila está aunque el polvo esté apagado y con su texto más ancho)
   if ((V.dust === true || mmax) && typeof cshGxdData === "function" && cshGxdData() && cshGxdData().ok) {
      var dTx = cshGxDustRowTexts(V, R), dT = dTx[0];
      if (mmax) for (var dq = 1; dq < dTx.length; ++dq) if (f.width(dTx[dq]) > f.width(dT)) dT = dTx[dq];
      if (V.legendCompact === true) { for (var ge = 0; ge < extra.length; ++ge) if (extra[ge].kind === "glow") extra[ge] = { kind: "glowdust", text: dT }; }
      else extra.push({ kind: "dustboth", text: dT });
   }
   if (cshGxBroken("legend")) { items = []; gradient = null; }
   // (28-oct, V7, decisión de Nino) LA LEYENDA ESTRECHA: en 3D y a lienzo pequeño —el ancho lógico del mapa, rect.w / sc, por debajo de V.legendSlimBelow que
   //  pone el script— la leyenda se queda SOLO con el título y la barra de color con sus marcas; lo demás —los puntos, «sin BP−RP», las filas del mapa— no se
   //  pinta y va en R.legend.hidden, que el script enseña en el tooltip de la leyenda. Rojo CSH_GX_BREAK «slimleg» = la leyenda entera de antes.
   var slim = (V.mode === "3d" && V.legendSlimBelow > 0 && gradient !== null && rect.w / sc < V.legendSlimBelow && !cshGxBroken("slimleg")), hidden = [];
   if (slim) {
      for (i = 0; i < items.length; ++i) hidden.push(items[i].text);
      if (gradient.none) hidden.push(gradient.none);
      for (i = 0; i < extra.length; ++i) hidden.push(extra[i].text);
      var g2 = {}, gk; for (gk in gradient) if (gradient.hasOwnProperty(gk)) g2[gk] = gradient[gk];
      g2.none = null; gradient = g2; items = []; extra = [];
   }
   var title = String(Lg.title || ""), wMax = fH.width(title.toUpperCase()), twoCol = !cshGxBroken("onecol") && !slim, wR = 0;
   for (i = 0; i < items.length; ++i) wMax = Math.max(wMax, 16 * sc + f.width(items[i].text));
   for (i = 0; i < extra.length; ++i) { if (twoCol) wR = Math.max(wR, 16 * sc + f.width(extra[i].text)); else wMax = Math.max(wMax, 16 * sc + f.width(extra[i].text)); }
   var gradW = Math.round(150 * sc);
   if (gradient) wMax = Math.max(wMax, gradW + Math.round(10 * sc), gradient.none ? 16 * sc + f.width(gradient.none) : 0);
   var nRowsL = items.length + (gradient ? (gradient.none ? 3 : 2) : 0), nRows = (title ? 1 : 0) + (twoCol ? Math.max(nRowsL, extra.length) : nRowsL + extra.length);
   // (H2/H3/H6, 28-oct: dos columnas —el degradado y los puntos a la izquierda, los símbolos del mapa a la derecha—: la mitad de alta)
   var colGap = twoCol ? Math.round(12 * sc) : 0, W = wMax + (twoCol ? colGap + wR : 0) + 2 * pad, H = nRows * rowH + 2 * pad - Math.round(3 * sc);
   var cbL = cshGxCornerBox(at || "tr", W, H, rect, Math.round(8 * sc)), x0 = cbL.x0, y0 = cbL.y0, box = { x0: x0, y0: y0, x1: x0 + W, y1: y0 + H };
   if (measureOnly) return box;
   g.fillRect(new Rect(box.x0, box.y0, box.x1, box.y1), new Brush(cpInt(A.bg, 0.86)));
   cshGxNoBrush(g); g.pen = new Pen(cpInt(A.line), 1); g.drawRect(box.x0, box.y0, box.x1, box.y1);
   var x = x0 + pad, y = y0 + pad + f.ascent - Math.round(1 * sc), lgText = cshGxText;
   if (title) { lgText(g, R, fH, cpInt(A.text3), x, y, title.toUpperCase()); y += rowH; }
   var yBody = y;
   if (gradient) {
      var gy = y - f.ascent + Math.round(2 * sc), gh = Math.round(7 * sc);
      for (var p = 0; p < gradW; ++p) { var v = gradient.from + (gradient.to - gradient.from) * p / (gradW - 1); g.fillRect(new Rect(x + p, gy, x + p + 1, gy + gh), new Brush(cshGxRgbInt(gradient.rgb(v), 1))); }
      y += rowH;
      for (var tk = 0; tk < gradient.ticks.length; ++tk) {
         var tv = gradient.ticks[tk], tl = gradient.tickText ? gradient.tickText(tv) : cshGxNum(tv, 1);
         var txp = x + gradW * (tv - gradient.from) / (gradient.to - gradient.from) - f.width(tl) / 2;
         txp = Math.max(x, Math.min(x + gradW + Math.round(10 * sc) - f.width(tl), txp));
         lgText(g, R, f, cpInt(A.text2), txp, y, tl);
      }
      y += rowH;
      if (gradient.none) {
         // (el «sin dato»: hueco gris de fábrica —CabraComposition—; con `noneRgb`, un punto LLENO de ese color: en Cabra3D el hueco ya
         //  dice «distancia dudosa» y un mismo símbolo no puede querer decir dos cosas —captura del 23-oct—)
         if (gradient.noneRgb) g.fillCircle(x + 4 * sc, y - f.ascent / 2 + 1, 2.8 * sc, new Brush(cshGxRgbInt(gradient.noneRgb, 0.95)));
         else { g.pen = new Pen(cpInt(A.text3, 0.85), Math.max(1, 0.9 * sc)); cshGxNoBrush(g); g.drawCircle(x + 4 * sc, y - f.ascent / 2 + 1, 2.6 * sc); }
         lgText(g, R, f, cpInt(A.text2), x + 14 * sc, y, gradient.none); y += rowH;
      }
   }
   for (i = 0; i < items.length; ++i) {
      var it = items[i], cyy = y - f.ascent / 2 + 1;
      if (it.hollow) { g.pen = new Pen(cshGxRgbInt(it.rgb, 0.85), Math.max(1, 0.9 * sc)); cshGxNoBrush(g); g.drawCircle(x + 4 * sc, cyy, 2.6 * sc); }
      else g.fillCircle(x + 4 * sc, cyy, 2.8 * sc, new Brush(cshGxRgbInt(it.rgb, 0.95)));
      lgText(g, R, f, cpInt(A.text2), x + 14 * sc, y, it.text); y += rowH;
   }
   if (twoCol) { x = x0 + pad + wMax + colGap; y = yBody; }
   for (i = 0; i < extra.length; ++i) {
      var ex = extra[i], cy2 = y - f.ascent / 2 + 1;
      if (ex.kind === "sun") { g.pen = new Pen(cpInt(A.text, 0.95), Math.max(1, 1.0 * sc)); cshGxNoBrush(g); g.drawCircle(x + 4 * sc, cy2, 3.6 * sc); g.fillCircle(x + 4 * sc, cy2, 1.1 * sc, new Brush(cpInt(A.text, 0.95))); }
      else if (ex.kind === "arm") { g.pen = new Pen(cpInt(A.goldLight, 0.35), Math.max(2, 3 * sc)); g.drawLine(x, cy2, x + 9 * sc, cy2); }
      else if (ex.kind === "trail") { g.pen = new Pen(cpInt(A.text, 0.7), Math.max(1, sc)); g.drawLine(x, cy2 + 2 * sc, x + 9 * sc, cy2 - 2 * sc); }
      else if (ex.kind === "now") { g.fillRect(new Rect(x + 4 * sc - 1.4 * sc, cy2 - 1.4 * sc, x + 4 * sc + 1.4 * sc, cy2 + 1.4 * sc), new Brush(cpInt(A.text2, 0.6))); }
      else if (ex.kind === "hollow") { g.pen = new Pen(cpInt(A.text2, 0.9), Math.max(1, 0.9 * sc)); cshGxNoBrush(g); g.drawCircle(x + 4 * sc, cy2, 2.6 * sc); }
      else if (ex.kind === "dustboth" || ex.kind === "glowdust") {
         // (la muestra como se ve en el mapa: el color de una columna de 1 mag —o 3 A_V/kpc de canto— con un alfa que se lea a 12 px (×1,6, al menos 0,45),
         //  compuesto sobre el fondo de la leyenda; «dustboth»: medido a la izquierda y modelo a la derecha. Revisor visual: la de antes era un
         //  terracota saturado que no se parecía a lo pintado)
         var Pd = (V.mode === "edge") ? cshGxdEdgeP() : cshGxdTopP(), vd = (V.mode === "edge") ? 3 : 1, bgd = cpHexRgb(A.bg);
         // (tramos [desde, hasta, medido]: «dustboth» medido | modelo; «glowdust» —el vídeo— resplandor | medido | modelo)
         var parts = (ex.kind === "glowdust") ? [[1 / 3, 2 / 3, 1], [2 / 3, 1, 0]] : [[0, 0.5, 1], [0.5, 1, 0]];
         if (ex.kind === "glowdust") g.fillRect(new Rect(x, cy2 - 3 * sc, x + 3 * sc, cy2 + 3 * sc), new Brush(cpInt(A.goldLight, 0.35)));
         for (var pd = 0; pd < parts.length; ++pd) {
            var Sd = cshGxdStyle(Pd, vd, parts[pd][2]), ad = Math.max(0.45, Math.min(1, 1.6 * Sd.a)), cd = [bgd[0] * (1 - ad) + Sd.rgb[0] * ad, bgd[1] * (1 - ad) + Sd.rgb[1] * ad, bgd[2] * (1 - ad) + Sd.rgb[2] * ad];
            g.fillRect(new Rect(x + parts[pd][0] * 9 * sc, cy2 - 3 * sc, x + parts[pd][1] * 9 * sc, cy2 + 3 * sc), new Brush(cshGxRgbInt(cd, 1)));
         }
      }
      else if (ex.kind === "seam") { g.pen = cshGxPen(cpInt(A.goldLight, 0.85), Math.max(1, 1.4 * sc), true); g.drawLine(x, cy2, x + 10 * sc, cy2); }
      else { g.fillRect(new Rect(x, cy2 - 3 * sc, x + 9 * sc, cy2 + 3 * sc), new Brush(cpInt(A.goldLight, 0.35))); }
      lgText(g, R, f, cpInt(A.text3), x + 14 * sc, y, ex.text); y += rowH;
   }
   R.legend = { x0: box.x0, y0: box.y0, x1: box.x1, y1: box.y1, items: items.length + (gradient ? 1 : 0), at: at || "tr", slim: slim, hidden: hidden };
   return box;
}

// EL RATÓN: la estrella más cercana a (x, y) en lo último pintado, a menos de 8 px lógicos; en 3D, a igual distancia, la de
// delante. Devuelve el índice del script (e.i), o −1.
function cshGalaxyPick(G, x, y, sc) {
   var P = G && G.proj;
   if (!P || !P.n) return -1;
   var r2 = Math.pow(8 * (sc || 1), 2), best = -1, bd = 1e18;
   for (var i = 0; i < P.n; ++i) {
      if (!P.ok[i]) continue;
      var dx = P.x[i] - x, dy = P.y[i] - y, d = dx * dx + dy * dy;
      if (d > r2) continue;
      var key = d + (P.kind === "3d" ? P.z[i] * 1e-6 : 0);
      if (key < bd) { bd = key; best = i; }
   }
   if (best < 0) return -1;
   if (cshGxBroken("pick")) best = (best + 1) % P.n;          // (ROJO «pick»: la de al lado)
   return P.idx[best];
}
#endif
