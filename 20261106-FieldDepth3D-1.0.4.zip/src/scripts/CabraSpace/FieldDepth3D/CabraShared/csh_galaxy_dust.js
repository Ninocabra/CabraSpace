#ifndef __CSH_GALAXY_DUST_JS
#define __CSH_GALAXY_DUST_JS
// ============================================================================
// CabraShared/csh_galaxy_dust.js — EL POLVO DE LA GALAXIA ENTERA (la capa «Polvo» de la vista Galaxia) (24-oct-2026, V7f)
// ----------------------------------------------------------------------------
// Decisión de Nino (V7 = C; 6-nov-2026, sin Vergely): MEDIDO Edenhofer et al. 2024 (A&A 685, A82; el del «Polvo» de Campo) dentro de 1,2 kpc
// del Sol + fuera el DISCO LISO de Galaxia (Sharma et al. 2011, ApJ 730, 3, §II.6) anclado a Edenhofer (un factor: la mediana de su columna =
// la de Edenhofer entre 0,8 y 1,2 kpc del Sol, ×1,6682). Hasta el 6-nov, además, Vergely, Lallement & Cox 2022 (A&A 664, A174) dentro de
// 4,83 kpc y el ancla en él (×1,2745): sale de FieldDepth3D 1.0.4 (regla CPD 7.3: sin licencia de redistribución verificada). La clase
// m = 1 (Vergely) ya no existe; el código la sigue entendiendo si una rejilla trae `topV` (no la trae). De canto (V7a = columna 3): la media
// del ANILLO entero (360°), hoy SOLO el modelo (sin los vóxeles 3D de Edenhofer, que serían como mucho ~5 % de un anillo; `edge.cov` null).
// Lo del MODELO se pinta más gris y más tenue: nunca pasa por medido. Doc: Cabra3D/docs/mapa_polvo_galaxia.md §10.
// Las rejillas: CabraShared/data/csh_galaxy_dust_grid.js (CSH_GXD_GRID, generadas por Cabra3D/tests/c3_gx_dust_proto.py export). Este
// módulo es PURO (node y PixInsight): lee, interpola y da el color; el pintado está en csh_galaxy_paint.js (cshGxPaintDust).
// EL MARCO: el de csh_galdyn.js (galactocéntrico, kpc: +X del Sol al centro —el Sol en X = −R0—, +Y hacia l = 90°, +Z al norte).
// EL DIBUJO (V7e): bruma que SUMA (como el «Polvo» de Campo), con la rampa de Campo SIN su crema del tenue, y tope de opacidad para que
// las órbitas, las estrellas y el Sol se lean SIEMPRE encima (el criterio y sus cifras: el doc §8 y Cabra3D/tests/c3_gxdust.js).
// Necesita CSH_GXD_GRID antes (y, si lo hay, CSH_ATLAS para los colores; si no, los de Atlas tal cual). ES5 puro.
// ============================================================================

var CSH_GXD = {
   // desde arriba y en 3D: la columna vertical (A_V, mag) — t = log(Σ/lo)/log(hi/lo), alfa = amax·t^g (lo del modelo, ×ma y como mucho mcap)
   // (1.ª pasada en PixInsight, 24-oct: amax 0,45 —arriba ±16 kpc el polvo casi no se veía, K4 p90 7,5 niveles— y de canto 0,5·t desde
   //  0,3 A_V/kpc —la lámina de 88 pc, con la nube de las Pléyades a z ±4 kpc, era invisible: alfa máx 0,21—. Medido en tests/c3_gxdust.js)
   // (revisor visual, 24-oct: junto al bulbo el MODELO pesaba tanto como lo medido —+10,7 frente a +10,5 niveles— y ensuciaba de rosa el
   //  resplandor. El modelo lleva ahora su propio tope de alfa, `mcap`, por debajo del p90 de lo medido —0,2—: nunca pasa por medido)
   TOP: { lo: 0.05, hi: 3.0, amax: 0.5, g: 1.3, ma: 0.45, mcap: 0.12 },
   // de canto: la densidad media del anillo (A_V por kpc)
   // (2.ª pasada: con 0,2–20 la lámina seguía sin verse de canto con la nube a z ±4 kpc —recorte mirado—; la escala baja a 0,1–10: en el plano a R0,
   //  1,3 A_V/kpc, alfa 0,26; en el centro, 0,35. 3.ª: de canto AMPLIADO alrededor del Sol —z ±0,7 kpc—, el Sol, dentro de la lámina, conservaba
   //  solo el 77 % de su contraste —K2 pide 80 %—: tope 0,45 → en el plano a R0, alfa 0,19)
   // (de canto, la media del ANILLO es casi toda modelo —lo medido es como mucho el 20 % de cada anillo, V7a—: el modelo conserva más peso;
   //  la costura —el recuadro a trazos— y el gris dicen qué es qué)
   EDGE: { lo: 0.1, hi: 10, amax: 0.45, g: 0.8, ma: 0.6, mcap: 0.3 },
   MODEL_GREY: 0.65,
   RAMP: ["#C98A4E", "#8E3A1E"],          // la del «Polvo» de Campo (C3_DUST_SCALE.RAMP de csh_dust.js) sin su crema del tenue
   GREY: "#A3957B",                        // CSH_ATLAS.text3 (si no está)
   PATH_MAX: 6,                            // 3D: camino oblicuo por la lámina, Σ/|cos i| con tope (el del resplandor)
   Z_MEAS: 0.4                             // kpc: lo medido de canto llega a |Z − z⊙| = 400 pc (la costura en z; solo si la rejilla trae edge.cov)
};
// (las de antes de V7f, las del prototipo —su 2.ª pasada—: con ellas la vista ±6 kpc quedaba casi toda parda; el ROJO «opaque» las pone)
var CSH_GXD_PROTO = { TOP: { lo: 0.03, hi: 4.0, amax: 0.75, g: 1.4, ma: 0.6, mcap: 1 }, EDGE: { lo: 0.3, hi: 100, amax: 0.9, g: 0.7, ma: 0.6, mcap: 1 } };
// DEFECTOS INYECTADOS por las pruebas: «flip» (la rejilla con Y al revés), «noseam» (sin costura ni su leyenda), «opaque» (el alfa del
// prototipo), «nomeas» (todo pintado como medido: lo del modelo sin gris).
var CSH_GXD_BREAK = "";
function cshGxdBroken(k) { return (typeof CSH_GXD_BREAK === "string") && CSH_GXD_BREAK.length > 0 && CSH_GXD_BREAK.indexOf(k) >= 0; }
function cshGxdTopP() { return cshGxdBroken("opaque") ? CSH_GXD_PROTO.TOP : CSH_GXD.TOP; }
function cshGxdEdgeP() { return cshGxdBroken("opaque") ? CSH_GXD_PROTO.EDGE : CSH_GXD.EDGE; }

// ---------------------------------------------------------------------------
// LEER LAS REJILLAS (una vez): base64url -> bytes -> valores
// ---------------------------------------------------------------------------
var CSH_GXD_D = null;
function cshGxdB64(lines) {
   var s = lines.join(""), A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", T = {}, i;
   for (i = 0; i < A.length; ++i) T[A.charAt(i)] = i;
   while (s.length && s.charAt(s.length - 1) === "=") s = s.substring(0, s.length - 1);
   var n = Math.floor(s.length * 3 / 4), out = new Uint8Array(n), o = 0, acc = 0, bits = 0;
   for (i = 0; i < s.length; ++i) {
      var v = T[s.charAt(i)];
      if (v === undefined) continue;
      acc = (acc << 6) | v; bits += 6;
      if (bits >= 8) { bits -= 8; if (o < n) out[o++] = (acc >> bits) & 255; }
      acc &= 0xFFFF;
   }
   return out;
}
function cshGxdDecodeLog(u8, lo, hi) {
   var out = new Float32Array(u8.length), k = Math.log(hi / lo) / 254;
   for (var i = 0; i < u8.length; ++i) out[i] = u8[i] ? lo * Math.exp((u8[i] - 1) * k) : 0;
   return out;
}
function cshGxdData() {
   if (CSH_GXD_D) return CSH_GXD_D;
   if (typeof CSH_GXD_GRID === "undefined" || !CSH_GXD_GRID) return null;
   var G = CSH_GXD_GRID, t0 = Date.now(), T = G.top, E = G.edge;
   // (6-nov-2026) sin Vergely: la rejilla ya no trae topV ni fp (D.v = null, D.fp = 0)
   var D = { G: G, R0: G.R0, fp: (G.fp > 0 && G.topV) ? G.fp : 0, edenR: G.edenR, edenR3: G.edenR3, model: G.model,
             v: (T.v && G.topV) ? { n: T.v.n, o: T.v.o, step: T.v.step, a: cshGxdDecodeLog(cshGxdB64(G.topV), T.lo, T.hi) } : null,
             e: { n: T.e.n, o: T.e.o, step: T.e.step, a: cshGxdDecodeLog(cshGxdB64(G.topE), T.lo, T.hi) },
             edge: { nR: E.nR, R0: E.R0, dR: E.dR, nz: E.nz, z0: E.z0, dz: E.dz, cov: E.cov, fmax: E.fmax,
                     rho: cshGxdDecodeLog(cshGxdB64(G.edgeRho), E.lo, E.hi), frac: null } };
   var fb = cshGxdB64(G.edgeFrac), fr = new Float32Array(fb.length);
   for (var i = 0; i < fb.length; ++i) fr[i] = fb[i] / 255;
   D.edge.frac = fr;
   D.ok = (D.v === null || D.v.a.length === D.v.n * D.v.n) && (D.e.a.length === D.e.n * D.e.n) && (D.edge.rho.length === D.edge.nR * D.edge.nz) && (fr.length === D.edge.nR * D.edge.nz);
   D.ms = Date.now() - t0;
   CSH_GXD_D = D;
   return D;
}

// ---------------------------------------------------------------------------
// EL MODELO (fuera de lo medido): Galaxia, ρ = s·e^(−(R−R0)/h_R)·e^(−|z|/h_z) (A_V/kpc); su columna vertical, 2·h_z·ρ(R, 0)
// ---------------------------------------------------------------------------
function cshGxdModelRho(R, z) { var D = cshGxdData(), M = D.model; return M.scale * Math.exp(-(R - D.R0) / M.hR) * Math.exp(-Math.abs(z) / M.hz); }
function cshGxdModelSigma(R) { var D = cshGxdData(), M = D.model; return M.scale * Math.exp(-(R - D.R0) / M.hR) * 2 * M.hz; }
// bilineal en una rejilla cuadrada [iy·n + ix] de centros o + k·step (heliocéntricos); NaN fuera
function cshGxdBilin(g, x, y) {
   var fx = (x - g.o) / g.step, fy = (y - g.o) / g.step, n = g.n;
   if (!(fx >= 0 && fy >= 0 && fx <= n - 1 && fy <= n - 1)) return NaN;
   var ix = Math.min(n - 2, Math.floor(fx)), iy = Math.min(n - 2, Math.floor(fy)), ux = fx - ix, uy = fy - iy, a = g.a, k = iy * n + ix;
   return (a[k] * (1 - ux) + a[k + 1] * ux) * (1 - uy) + (a[k + n] * (1 - ux) + a[k + n + 1] * ux) * uy;
}
// LA COLUMNA VERTICAL (A_V, mag) en (X, Y) galactocéntricos -> out = { s, m } (m: 0 modelo, 2 Edenhofer; el 1, Vergely, ya no sale)
function cshGxdSigma(X, Y, out) {
   var D = cshGxdData(), o = out || { s: 0, m: 0 };
   var xh = X + D.R0, yh = cshGxdBroken("flip") ? -Y : Y, r2 = xh * xh + yh * yh;
   if (r2 < D.edenR * D.edenR) { var se = cshGxdBilin(D.e, xh, yh); if (se === se) { o.s = se; o.m = 2; return o; } }
   if (D.v && r2 < D.fp * D.fp) { var sv = cshGxdBilin(D.v, xh, yh); if (sv === sv) { o.s = sv; o.m = 1; return o; } }
   o.s = cshGxdModelSigma(Math.sqrt(X * X + Y * Y)); o.m = 0;
   return o;
}
// DE CANTO: la media del anillo (A_V/kpc) y la fracción medida de lo promediado -> out = { r, f }
function cshGxdRing(R, z, out) {
   var D = cshGxdData(), E = D.edge, o = out || { r: 0, f: 0 };
   R = Math.abs(R);
   var fR = (R - E.R0) / E.dR, fz = (z - E.z0) / E.dz;
   if (!(fR >= 0 && fR <= E.nR - 1 && fz >= 0 && fz <= E.nz - 1)) { o.r = cshGxdModelRho(R, z); o.f = 0; return o; }
   var iR = Math.min(E.nR - 2, Math.floor(fR)), iz = Math.min(E.nz - 2, Math.floor(fz)), uR = fR - iR, uz = fz - iz, k = iz * E.nR + iR, n = E.nR;
   var a = E.rho, b = E.frac;
   o.r = (a[k] * (1 - uR) + a[k + 1] * uR) * (1 - uz) + (a[k + n] * (1 - uR) + a[k + n + 1] * uR) * uz;
   o.f = (b[k] * (1 - uR) + b[k + 1] * uR) * (1 - uz) + (b[k + n] * (1 - uR) + b[k + n + 1] * uR) * uz;
   return o;
}

// ---------------------------------------------------------------------------
// EL COLOR (ARGB de PJSR): tablas de 256 niveles de t × 17 niveles de «medido» (0 = modelo … 16 = medido), una por vista
// ---------------------------------------------------------------------------
function cshGxdHex(h) { h = String(h).replace("#", ""); return [parseInt(h.substring(0, 2), 16), parseInt(h.substring(2, 4), 16), parseInt(h.substring(4, 6), 16)]; }
// el alfa y el color (0…255) de un valor con su parte medida m (0…1): lo que dibuja el pintado y lo que miden las pruebas
function cshGxdStyle(P, v, m) {
   var t = (v > P.lo) ? Math.min(1, Math.log(v / P.lo) / Math.log(P.hi / P.lo)) : 0;
   if (cshGxdBroken("nomeas")) m = 1;
   var a0 = cshGxdHex(CSH_GXD.RAMP[0]), a1 = cshGxdHex(CSH_GXD.RAMP[1]), gr = cshGxdHex((typeof CSH_ATLAS !== "undefined" && CSH_ATLAS.text3) ? CSH_ATLAS.text3 : CSH_GXD.GREY);
   var rgb = [a0[0] + (a1[0] - a0[0]) * t, a0[1] + (a1[1] - a0[1]) * t, a0[2] + (a1[2] - a0[2]) * t], gk = (1 - m) * CSH_GXD.MODEL_GREY;
   rgb = [rgb[0] * (1 - gk) + gr[0] * gk, rgb[1] * (1 - gk) + gr[1] * gk, rgb[2] * (1 - gk) + gr[2] * gk];
   var a0 = (t > 0) ? P.amax * Math.pow(t, P.g) : 0, ma = (P.ma > 0) ? P.ma : 0.6, mc = (P.mcap > 0) ? P.mcap : 1;
   var alpha = a0 * m + Math.min(a0 * ma, mc) * (1 - m);
   return { t: t, a: alpha, rgb: rgb };
}
var CSH_GXD_LUT = {};
function cshGxdLut(kind) {
   var P = (kind === "edge") ? cshGxdEdgeP() : cshGxdTopP(), key = kind + "|" + CSH_GXD_BREAK + "|" + [P.lo, P.hi, P.amax, P.g, P.ma, P.mcap, CSH_GXD.MODEL_GREY].join(",");
   if (CSH_GXD_LUT[key]) return CSH_GXD_LUT[key];
   var L = { P: P, a: new Array(256 * 17), lnlo: Math.log(P.lo), k: 255 / Math.log(P.hi / P.lo) };
   for (var mi = 0; mi <= 16; ++mi) for (var ti = 0; ti < 256; ++ti) {
      var t = ti / 255, v = P.lo * Math.exp(t * Math.log(P.hi / P.lo)) * (ti === 0 ? 0 : 1), S = cshGxdStyle(P, v, mi / 16);
      var A = Math.max(0, Math.min(255, Math.round(S.a * 255)));
      L.a[mi * 256 + ti] = A ? (((A << 24) | (Math.round(S.rgb[0]) << 16) | (Math.round(S.rgb[1]) << 8) | Math.round(S.rgb[2])) >>> 0) : 0;
   }
   CSH_GXD_LUT[key] = L;
   return L;
}
// el ARGB de un valor v (mag o A_V/kpc según la vista) con la parte medida m (0…1); 0 = transparente
function cshGxdArgb(L, v, m) {
   if (!(v > L.P.lo)) return 0;
   var ti = Math.min(255, Math.round((Math.log(v) - L.lnlo) * L.k)), mi = Math.max(0, Math.min(16, Math.round(m * 16)));
   return L.a[mi * 256 + ti];
}
// el alfa 0…1 de un ARGB (para las pruebas)
function cshGxdAlphaOf(c) { return ((c >>> 24) & 255) / 255; }

// ---------------------------------------------------------------------------
// EL POLVO EN EL TIEMPO (26-oct-2026, V7h; Nino: «si puedes calcular su evolución y hacerlo evolucionar con el resto, perfecto. Adopta un
// modelo sencillo pero preciso»). Doc: Cabra3D/docs/mapa_polvo_galaxia.md §9. Dos piezas, y nada más:
//   1. ARRASTRE por la ROTACIÓN DIFERENCIAL del MISMO potencial que mueve las estrellas (MilkyWayPotential2022, csh_galdyn.js): el gas va casi
//      en órbitas circulares, así que lo que hoy está en (R, φ) estaba / estará en (R, φ + Ω(R)·t) (en este marco la Galaxia gira hacia −φ:
//      el Sol, en X = −R0, sale hacia +Y). Ω(R) = Vc(R)/R; a R0, 28,2 km/s/kpc; A 14,7 y B −13,5 km/s/kpc (cizalla: 1/(2A) = 33 Ma).
//      Es PRECISO mientras las nubes existan (lo que no lleva: corrientes de los brazos y movimientos propios de las nubes, ~5–10 km/s: ~0,1 kpc
//      cada 10 Ma; razonado, NO MEDIDO).
//   2. PÉRDIDA DE IDENTIDAD: las nubes de hoy viven decenas de Ma (nubes moleculares 5–30 Myr en 54 galaxias, Kim et al. 2022, MNRAS 516,
//      3006 —leído el resumen de arXiv 2206.09857; volumen y página NO VERIFICADOS—; 10–30 Myr, Chevance et al. 2020, MNRAS 493, 2872; la
//      emisión infrarroja media —PAH y polvo— de las nubes, 10–30 Myr, Kim et al. 2025, ApJ, arXiv 2506.10063; las nubes de la vecindad
//      nacieron en la burbuja local hace ~14 Ma, Zucker et al. 2022, Nature 601, 334). Fracción de las de
//      hoy que sobrevive (hacia delante) o que ya existía (hacia atrás) con vida media τ = 20 Ma: w = e^(−|t|/τ). Lo que se pinta es lo ESPERADO:
//      modelo + w·(lo medido girado − modelo), y la parte «medida» del color pesa w. El GRANO de polvo dura mucho más (silicatos ~2–3 Ga, Slavin,
//      Dwek & Jones 2015, ApJ 803, 7 —resumen de arXiv 1502.00929; volumen y página NO VERIFICADOS—): por eso se funde hacia el DISCO LISO, no hacia nada. Con w < WMIN (|t| > 78 Ma), solo el disco liso.
// ILUSTRATIVO pasados ILLUS = τ = 20 Ma (lo dice la leyenda): ahí ya no existen dos de cada tres nubes de hoy.
// ---------------------------------------------------------------------------
CSH_GXD.EVO = { TAU: 20, ILLUS: 20, WMIN: 0.02, DR: 0.01, RMAX: 40, KMS_KPC_PER_RAD_MYR: 977.792221 };
// DE CANTO (V7g, 26-oct; Nino: SÍ a un grosor mínimo en pantalla): con el encuadre de fábrica de una nube que llega lejos del plano, la lámina
// (h_z 88 pc) mide pocos píxeles. Si su altura de escala en pantalla baja de EDGE_HMIN px lógicos, el polvo (y su recuadro) se ESTIRAN en z
// alrededor del plano —×s, como mucho EDGE_SMAX— y la leyenda dice «grosor ×s». Las estrellas, las órbitas y los ejes no se tocan.
// 19 px: MEDIDO y MIRADO en las Pléyades de fábrica (h_z = 6,4 px lógicos; tests/c3_gxdust_time.js caso 3, capturas c3_polvo_canto_*): ×1 se ve
// 25 px lógicos de lámina (filas cuya mediana sube la luz ≥ 3 niveles), ×2 (EDGE_HMIN 9) 58 px y apenas se distingue de ×1 a ojo; ×3 (19) 89 px
// y la banda parda se lee fuera de las órbitas. K1–K3 igual en las tres (estrellas 1,00, Sol 0,93–0,94, alfa ≥ 0,2 en 0,4 / 0,9 / 1,4 %).
CSH_GXD.EDGE_HMIN = 19;
CSH_GXD.EDGE_SMAX = 10;
// DEFECTOS INYECTADOS del tiempo (en CSH_GXD_BREAK, como los de arriba): «frozen» (el polvo de hoy en todo instante: lo de antes de V7h),
// «sign» (gira al revés), «rigid» (todo gira con Ω(R0): sin cizalla), «nofade» (sin pérdida de identidad), «asym» (solo se pierde hacia
// delante), «t0» (ya se pierde en t = 0: un desfase de 1 Ma), «thin» (de canto sin grosor mínimo: lo de antes de V7g).
var CSH_GXD_OM = null, CSH_GXD_TC = null, CSH_GXD_T0 = { t: 0, w: 1, live: false, model: false, key: "0" };
// Ω(R) en rad/Ma (de 0 a RMAX cada DR), con la Vc del potencial (cshGdVcirc de csh_galdyn.js); sin él, la del Sol a 229,4 km/s
function cshGxdOmegaTab() {
   if (CSH_GXD_OM) return CSH_GXD_OM;
   var E = CSH_GXD.EVO, n = Math.round(E.RMAX / E.DR) + 1, om = new Float64Array(n), hasV = (typeof cshGdVcirc === "function");
   for (var i = 0; i < n; ++i) { var R = Math.max(0.05, i * E.DR); om[i] = (hasV ? cshGdVcirc(R) : 229.4) / R / E.KMS_KPC_PER_RAD_MYR; }
   CSH_GXD_OM = { n: n, dr: E.DR, om: om, hasV: hasV };
   return CSH_GXD_OM;
}
function cshGxdOmega(R) { var O = cshGxdOmegaTab(); return O.om[Math.max(0, Math.min(O.n - 1, Math.round(Math.abs(R) / O.dr)))]; }
// la fracción de la estructura de hoy que queda a t Ma (1 en t = 0)
function cshGxdW(tMyr) {
   var a = Math.abs(tMyr);
   if (cshGxdBroken("nofade")) return 1;
   if (cshGxdBroken("asym") && tMyr < 0) return 1;
   if (cshGxdBroken("t0")) a += 1;
   return Math.exp(-a / CSH_GXD.EVO.TAU);
}
// EL INSTANTE del polvo: { t, w, live (cambia con t: hay que girar), model (solo el disco liso), key, rc/rs (el coseno y el seno del giro
// Ω(R)·t por anillo de DR) }. El último se guarda (cada fotograma pide uno).
function cshGxdTime(tMyr) {
   var t = (typeof tMyr === "number" && isFinite(tMyr) && !cshGxdBroken("frozen")) ? tMyr : 0;
   if (t === 0 && !cshGxdBroken("t0")) return CSH_GXD_T0;
   var w = cshGxdW(t);
   if (w < CSH_GXD.EVO.WMIN) return { t: t, w: 0, live: false, model: true, key: "m" };
   if (CSH_GXD_TC && CSH_GXD_TC.t === t && CSH_GXD_TC.brk === CSH_GXD_BREAK) return CSH_GXD_TC;
   var O = cshGxdOmegaTab(), rc = new Float64Array(O.n), rs = new Float64Array(O.n), om0 = cshGxdOmega(cshGxdR0()), sg = cshGxdBroken("sign") ? -1 : 1, rig = cshGxdBroken("rigid");
   for (var i = 0; i < O.n; ++i) { var a = sg * (rig ? om0 : O.om[i]) * t; rc[i] = Math.cos(a); rs[i] = Math.sin(a); }
   CSH_GXD_TC = { t: t, w: w, live: true, model: false, key: "t" + t.toFixed(4), rc: rc, rs: rs, n: O.n, dr: O.dr, brk: CSH_GXD_BREAK };
   return CSH_GXD_TC;
}
function cshGxdR0() { var D = cshGxdData(); return (D && D.R0) ? D.R0 : 8.122; }
// ¿se dice «ilustrativo»?
function cshGxdIllustrative(tMyr) { return (typeof tMyr === "number") && Math.abs(tMyr) > CSH_GXD.EVO.ILLUS && !cshGxdBroken("frozen"); }
// LA COLUMNA a t: out = { s, m (la clase de hoy de lo que se muestrea), w (el peso de lo medido en el color: 0…1) }
function cshGxdSigmaT(X, Y, T, out) {
   var o = out || { s: 0, m: 0, w: 0 };
   if (!T || !T.live) {
      if (T && T.model) { o.s = cshGxdModelSigma(Math.sqrt(X * X + Y * Y)); o.m = 0; o.w = 0; return o; }
      cshGxdSigma(X, Y, o); o.w = o.m ? 1 : 0; return o;
   }
   var R = Math.sqrt(X * X + Y * Y), k = Math.min(T.n - 1, Math.round(R / T.dr)), c = T.rc[k], s = T.rs[k];
   cshGxdSigma(X * c - Y * s, Y * c + X * s, o);
   if (o.m) { var md = cshGxdModelSigma(R); o.s = md + T.w * (o.s - md); o.w = T.w; } else o.w = 0;
   return o;
}
// DE CANTO a t: la media del anillo no cambia al girar (la rotación la conserva); solo se pierde la identidad. out = { r, f }
function cshGxdRingT(R, z, T, out) {
   var o = cshGxdRing(R, z, out);
   if (T && (T.live || T.model)) { var w = T.live ? T.w : 0, md = cshGxdModelRho(Math.abs(R), z); o.r = md + w * (o.r - md); o.f *= w; }
   return o;
}
// DÓNDE ESTÁ a t lo que hoy está en (X, Y): el giro hacia delante (para la costura)
function cshGxdForward(X, Y, T, out) {
   var o = out || [0, 0];
   if (!T || !T.live) { o[0] = X; o[1] = Y; return o; }
   var R = Math.sqrt(X * X + Y * Y), k = Math.min(T.n - 1, Math.round(R / T.dr)), c = T.rc[k], s = T.rs[k];
   o[0] = X * c + Y * s; o[1] = Y * c - X * s;
   return o;
}
// V7g: el estiramiento en z de canto para una escala vertical de szPx px/kpc: 1 = tal cual; si no, un ENTERO (2…EDGE_SMAX), el mismo que
// dice la leyenda («grosor ×3»: lo dicho es lo aplicado)
function cshGxdThick(szPx, sc) {
   if (cshGxdBroken("thin") || !(szPx > 0)) return 1;
   var D = cshGxdData(), hz = (D && D.model && D.model.hz > 0) ? D.model.hz : 0.088, s = CSH_GXD.EDGE_HMIN * (sc > 0 ? sc : 1) / (hz * szPx);
   return (s <= 1.25) ? 1 : Math.max(2, Math.min(CSH_GXD.EDGE_SMAX, Math.round(s)));
}
#endif
