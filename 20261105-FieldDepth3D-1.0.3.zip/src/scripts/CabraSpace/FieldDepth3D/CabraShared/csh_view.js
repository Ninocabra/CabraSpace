// ============================================================================
// CabraShared/csh_view.js — LO COMUN DE LAS VISTAS DEL CAMPO DE ESTRELLAS (15-oct-2026)
// ----------------------------------------------------------------------------
// PROCEDENCIA: CabraPilot integracion-1410c, CabraCore/src/ui/starfield_view.js, copiado dos veces (CabraStars
// lib/cs_view.js, el HR; Cabra3D src/ui/starfield_view.js, el 3D). Las constantes CP_SV son la UNION (las de CabraStars
// contenian todas las de Cabra3D con los mismos valores, mas las del HR) y los ayudantes cpSv* eran identicos letra a
// letra (comprobado con tools: 19 funciones). Lo propio del HR sigue en CabraStars; lo del 3D, en Cabra3D. ES5 puro.
// ============================================================================

// ---- desde ui/starfield_view.js:36 ----
var CP_SV = {
   // --- el HR ---------------------------------------------------------------
   HR_X_LO: -0.7, HR_X_HI: 4.5,       // diseño: topes del eje de color (BP-RP); fuera no hay estrellas normales
   HR_Y_LO: -7, HR_Y_HI: 17.5,        // diseño: topes del eje de magnitud absoluta
   HR_PAD_X: 0.25, HR_PAD_Y: 0.9,     // diseño: aire alrededor de los puntos
   HR_MIN_SPAN_X: 2.4, HR_MIN_SPAN_Y: 9,   // diseño: un campo con cuatro estrellas no se pinta a toda pantalla
   HR_ZOOM_MAX: 16,                   // diseño
   // El Sol en estos ejes (Casagrande y VandenBerg 2018, MNRAS 479, L102: M_G = 4,67; BP-RP = 0,82).
   SUN_BPRP: 0.82, SUN_ABSG: 4.67,
   // --- el mapa de densidad (diseño; lo ejercitan los casos) ----------------
   DENS_COVER: 2.2,                   // opacidad: 1 - exp(-DENS_COVER · cuenta): un punto solo tapa el 89 % en su centro
   DENS_BASE: 0.62,                   // brillo de un punto SOLO (fraccion de su color)
   DENS_GAMMA: 2.2,                   // el brillo sube con (log cuenta / log ref) ELEVADO a esto: el contraste se guarda para donde hay muchos
   DENS_WHITE: 0.35,                  // y lo mas denso se aclara hacia el blanco hasta esta fraccion (el filo de la secuencia)
   DENS_REF_MIN: 6,                   // la cuenta que da brillo 1 nunca baja de esto (un campo ralo no se quema)
   WEIGHT_GAIA: 0.62,                 // en «mixed», el punto cuyo color sale de Gaia pesa menos (la marca discreta)
   WEIGHT_SUSPECT: 0.42,              // una distancia dudosa
   // --- las distancias --------------------------------------------------------
   // Las bandas, en parsecs (diseño; valores redondos de libro: el disco de la Via Lactea llega a unos 30 kpc del
   // Sol por el lado lejano; el Grupo Local tiene un radio de unos 1,5 Mpc; «cercanas» hasta z ~ 0,07).
   BAND_GALAXY_PC: 3.0e4, BAND_LOCAL_PC: 1.5e6, BAND_NEAR_PC: 3.0e8,
   LOG_T0: 0.07,                      // diseño: en la escala logaritmica, la primera decada empieza al 7 % del fondo
   DEPTH: 1.9,                        // diseño: el fondo de la caja, en lados de la foto (con 2,7 la caja era una tira y medio lienzo quedaba vacio)
   SIDE_PHOTO: 0.36,                  // diseño: en el corte lateral, la fraccion del ancho que se lleva la foto de frente
   // diseño: la pose con la que se abre (grados). Con la camara ortografica de antes el giro era de 62; con la
   // perspectiva de verdad la camara gira alrededor del CENTRO de la caja y a 62 la foto quedaba casi de canto
   // (114 px de ancho en un lienzo de 840: visto en la captura). A 55 se lee y el fondo conserva su largo.
   YAW: 55, PITCH: 13,
   // LA CAMARA ORBITAL (13-oct-2026). El giro no tiene topes (da la vuelta entera); la inclinacion se para un poco
   // antes de la vertical (a 90° «arriba» deja de estar definido y el arrastre se volveria loco).
   PITCH_MAX: 88,
   // Perspectiva de verdad: la camara esta a CAM_DIST radios de la caja de su pivote (2,6: lo de delante se ve
   // hasta el doble de grande que lo del fondo, sin deformar). MEDIDO en `_tests/cp_starfield_3d_probe.log`
   // (1.9.5 build 1706): la foto en una malla de 16 x 16 celdas con una afin por celda cuesta 1 ms y, con 1 px de
   // solape y los bordes sin suavizar, deja 0 pixeles de costura (con suavizado y sin solape, 5 049: el control).
   PERSPECTIVE: true, CAM_DIST: 2.6, NEAR: 0.08,   // NEAR: lo que esta a menos de esta fraccion de la distancia al pivote no se pinta
   PHOTO_MESH: 16,
   SIDE_ZOOM_MAX: 50,                 // diseño: en el corte lateral, hasta 50 aumentos (una ventana del 2 % del fondo)
   ZOOM_STEPS: 200,                   // diseño: pasos de la barra de zoom
   DIST_ZOOM_MIN: 0.5, DIST_ZOOM_MAX: 100,   // 100: el nucleo de un cumulo llena el lienzo
   ORBIT_X: 0.4, ORBIT_Y: 0.3,        // diseño: grados por pixel de arrastre (una vuelta entera, 900 px)
   EDGE_STICK: 14,                    // diseño: una cifra del eje no cambia de arista hasta que otra gana por estos pixeles
   MAX_MEMBERS: 3500,                 // diseño: miembros de un cumulo que se pintan en su plano (los mas brillantes)
   MAX_PLATES: 7,                     // diseño: placas a la vez
   // LOS RECORTES (13-oct-2026): un objeto extenso se pinta con SU TROZO DE LA FOTO, a su distancia.
   CUT_MAX: 12,                       // diseño: cuantos a la vez (los mas grandes en pantalla); el resto, su simbolo
   CUT_MIN_PX: 5,                     // diseño: por debajo de este radio en pantalla (por la escala de la interfaz) no se ve nada: simbolo
   CUT_MARGIN: 1.25,                  // diseño: el recorte coge este tanto del radio de catalogo (las alas de una galaxia)
   CUT_FEATHER: 0.1,                  // diseño: la ultima fraccion del radio del recorte se desvanece (sin borde duro)
   MATTE_RING: 0.82,                  // diseño: la corona de la que sale el fondo del recorte, de aqui hacia fuera (en radios del recorte: mas alla del objeto)
   MATTE_GAIN: 2.4, MATTE_GAIN_AT: 0.8,   // (…y lo que se iguala a la foto es este percentil del brillo del objeto)                     // diseño: lo mas que se le sube el brillo a un objeto debil al quitarle el fondo de cielo
   // (vuelta 4) LA MASCARA DICE DONDE ESTA EL OBJETO, NO CUANTO BRILLA: sube de 0 a 1 entre MATTE_LO y MATTE_HI sigmas de
   // exceso MEDIO (alisado 5 x 5: su ruido es la quinta parte). Con 1…4 la transparencia seguia al brillo y, como la luz del
   // recorte es exceso × transparencia, lo tenue salia dos veces apagado: una galaxia beige, plana y SIN GRANO (visto a 1:1).
   // (OJO: el exceso es el MAYOR de los tres canales, que en cielo puro ya vale 0,85 sigmas de media: por debajo de 1,4 entra el cielo)
   MATTE_LO: 1.4, MATTE_HI: 3,
   MATTE_ISLAND: 0.2,                // diseño: una mancha suelta (una estrella al lado del objeto) con menos de esta fraccion de la luz de la mayor se quita
   // (vuelta 4) BORRAR UNA ESTRELLA NO DEJA UN DISCO LISO: se rellena con lo de alrededor (cada pixel, la media de un anillo
   // de MATTE_FILL_N muestras pesada por cercania: sigue el degradado del objeto) MAS el grano del cielo; y solo si el
   // relleno es FIABLE: la estrella no mide mas de MATTE_FILL_R del lado del recorte y en su anillo no hay otra cosa
   // (menos de MATTE_FILL_BAD de las muestras se salen). Si no, la estrella SE DEJA: mejor una estrella que un lunar.
   MATTE_FILL_N: 32, MATTE_FILL_R: 0.02, MATTE_FILL_BAD: 0.25, MATTE_FILL_SPREAD: 10,     // (…o su anillo va, del 10 % al 90 %, mas de SPREAD veces el ruido: ahi hay otra cosa)
   MATTE_CORE: 0.3,                   // diseño: las manchas se separan por donde la transparencia baja de esto (una estrella pegada al borde del objeto es otra mancha)
   MATTE_REACH: 0.06,                 // diseño: lo que no llega a nucleo solo se queda a menos de esta fraccion del lado del recorte de un nucleo que se queda
   MATTE_GROW: 6,                     // diseño: una mancha que se quita se lleva tambien su halo: estos pixeles alrededor (por 1 024 de lado del recorte)
   MATTE_SHINE: 0.9,                  // diseño: «lo que brilla» de un objeto es la caja que contiene esta fraccion de su transparencia
   CUT_FACE: 0.35,                    // diseño: el recorte acaba de girarse hacia la camara cuando la caja se ha abierto esta fraccion
   CUT_NEAR0: 0.9, CUT_NEAR1: 1.8,    // diseño: un recorte que en pantalla mide mas que esto (su radio, en altos del dibujo) se apaga: la camara no lo atraviesa
   SUBJECT_R: 0.25,                   // diseño: «el motivo de la foto» es lo no estelar mas cercano al centro, a menos de esta fraccion del lado mayor
   // --- LA NEBULOSIDAD, A SU DISTANCIA (14-oct-2026; `cpSvNebulaMatte`, `cpSvStarlessOwn`) -------------------------
   // diseño: la capa de una nebulosa es la foto SIN ESTRELLAS menos su fondo de cielo, de 0 a 1 de transparencia entre
   // NEB_LO y NEB_HI ruidos de exceso MEDIO (alisado 5 x 5), y se pinta SUMANDO luz (como los recortes) con NEB_ALPHA:
   // semitransparente, se ve lo que tiene detras.
   NEB_BG_PCT: 0.05,                  // el fondo de cielo: este percentil de cada canal alisado (lo mas oscuro de la foto; la nebulosa la llena)
   NEB_LO: 1.0, NEB_HI: 6,            // la rampa de transparencia, en ruidos (mas ancha que la de un objeto: una nebulosa se desvanece despacio)
   NEB_ALPHA: 0.85,                   // diseño: la opacidad con la que se pinta (lo de detras se sigue viendo)
   NEB_FEATHER: 0.06,                 // diseño: los bordes de la capa (y el de su disco, si cae dentro) se desvanecen en esta fraccion de su lado
   NEB_STAR_R: 4,                     // diseño (quitar estrellas sin StarXTerminator ni StarNet2): radio de la apertura morfologica, en pixeles de la capa
   NEB_STAR_K: 3,                     // …un pixel es estrella si pasa de su apertura en mas de estos ruidos
   // --- las transiciones (diseño; `motion` de CabraBase/estilo/tokens.json da 600 ms a un cambio de estado de la
   // interfaz: aqui cada estrella cruza medio lienzo y tiene que poder seguirse con el ojo) -----
   ANIM_MS: 1300, ANIM_SHORT_MS: 700, // una transicion entre vistas; una corta (reponer la vista, cerrar)
   ANIM_STAGGER: 0.22,                // las estrellas no salen todas a la vez: cada una espera hasta esta fraccion del tiempo
   ANIM_ARC: 0.10,                    // y va en un arco suave: se aparta de la recta esta fraccion de su camino
   ANIM_HEAD: 0.10, ANIM_TAIL: 0.20,  // el dibujo de salida se funde al principio y el definitivo al final (asi casan sin salto)
   ANIM_MAX_POINTS: 40000,            // por encima, se anima un subconjunto ESTABLE (los mismos en todos los fotogramas)
   // --- LAS ESTRELLAS DE LA FOTO (14-oct-2026; estudio en propuestas/hr_3d/estrellas_reales/ESTUDIO.md) -----
   // Las cuatro formas de pintar las estrellas del 3D (el desplegable «Stars»): el punto de Gaia de siempre; el punto
   // con el COLOR de la foto; el RECORTE de la foto a su distancia (con la perspectiva); y el recorte del tamaño que
   // tiene EN la foto. La primera es la de fabrica.
   STARS_MODES: ["gaia", "photo-colour", "photo", "photo-size"],
   PS_SNR_MIN: 5,                     // diseño: por debajo de esta señal / ruido de pico la estrella no sale en la foto
   PS_NEIGHBOUR: 0.1,                 // diseño: una vecina de Gaia con mas de esta fraccion de su flujo dentro del recorte lo ensucia
   PS_DOUBLE: 1.5,                    // diseño: a menos de esto (en FWHM) la vecina es una doble sin resolver
   PS_REACH: 1.5,                     // diseño: lo que alcanza una vecina (en FWHM), que crece una vez por cada magnitud que brilla mas
   PS_RING: 3,                        // diseño: el recorte acaba donde el anillo medio baja de esto (en ruidos del anillo)
   PS_MIN_CORE: 0.75,                 // diseño: un nucleo de menos de esto (pixeles de pantalla) no da recorte: punto con el color de la foto
   // (MEDIDO en NGC 1560 a x35: sin tope, una G 11 era un disco blando de 143 px que tapaba lo de detras; con «Photo size», 1 270)
   PS_CAP: 0.04,                      // diseño: el radio de un recorte en pantalla no pasa de esta fraccion del alto del dibujo
   // EN UN VUELO la estrella gana brillo al acercarse (decision de Nino del 14-oct, R3): el factor es (d0 / d)², d0 la
   // distancia desde la Tierra y d desde la camara, con estos topes.
   PS_GAIN_MIN: 0.25, PS_GAIN_MAX: 4
};

// El color de una estrella en pantalla a partir de su BP-RP. Son colores de DATOS
// (como los canales del histograma), no de la marca: una rampa de cuerpo negro a
// ojo, del azul de una B al naranja de una M. Devuelve [r, g, b] en 0..255.
var CP_SV_STAR_RAMP = [
   [-0.6, 150, 172, 255], [-0.2, 164, 186, 255], [0.2, 190, 206, 255], [0.55, 228, 232, 255], [0.82, 255, 244, 232],
   [1.15, 255, 226, 190], [1.6, 255, 200, 140], [2.2, 255, 170, 100], [3.0, 255, 138, 70], [4.2, 238, 104, 52]
];

// LO QUE SE VE DE CADA CAPA en el instante `tau`. Una transicion se pinta en capas: el dibujo de
// SALIDA entero (`from`: se funde en los primeros fotogramas, y por eso el primero ES el de salida),
// el decorado de la salida y el de la llegada sin estrellas (`chromeA` se va, `chromeB` viene), las
// estrellas viajando, y el dibujo DEFINITIVO de llegada (`to`: aparece en los ultimos fotogramas, y
// por eso el ultimo ES el definitivo: no hay salto al acabar).
function cpSvAnimLayers(tau) {
   var t = (tau > 0) ? ((tau < 1) ? tau : 1) : 0;
   function ss(x) { x = (x > 0) ? ((x < 1) ? x : 1) : 0; return x * x * (3 - 2 * x); }
   // (el decorado se CRUZA: el de llegada va debajo, entero, y el de salida encima, yendose. Lo que es igual en los
   // dos —la cabecera, el marco de la ficha— no se apaga a mitad de camino. `cross` = lo que queda del de salida.)
   return { from: 1 - ss(t / CP_SV.ANIM_HEAD), to: ss((t - (1 - CP_SV.ANIM_TAIL)) / CP_SV.ANIM_TAIL), chromeA: 1 - ss(t / 0.6), chromeB: ss((t - 0.3) / 0.6),
            cross: 1 - ss((t - 0.12) / 0.6) };
}

function cpSvBoxesOverlap(a, b) {
   return !(a.x + a.w <= b.x || b.x + b.w <= a.x || a.y + a.h <= b.y || b.y + b.h <= a.y);
}

// Cuantos puntos caen dentro de una caja (pixeles).
function cpSvCountInBox(grid, px, py, x0, y0, x1, y1) {
   var c = grid.cell, n = 0;
   var cx0 = Math.max(0, Math.floor(x0 / c)), cx1 = Math.min(grid.cols - 1, Math.floor(x1 / c));
   var cy0 = Math.max(0, Math.floor(y0 / c)), cy1 = Math.min(grid.rows - 1, Math.floor(y1 / c));
   for (var cy = cy0; cy <= cy1; ++cy)
      for (var cx = cx0; cx <= cx1; ++cx) {
         var k = cy * grid.cols + cx;
         for (var j = grid.start[k]; j < grid.start[k + 1]; ++j) {
            var i = grid.index[j];
            if (px[i] >= x0 && px[i] <= x1 && py[i] >= y0 && py[i] <= y1) ++n;
         }
      }
   return n;
}

// Suave al salir y al llegar (cubica): 0 → 0, 0,5 → 0,5, 1 → 1; fuera de 0…1 se queda en el extremo.
function cpSvEase(t) {
   var x = (t > 0) ? ((t < 1) ? t : 1) : 0;
   return (x < 0.5) ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
}

// Una distancia en la unidad pedida. `words` = { ly, mly, pc, kpc, mpc, gpc }: los
// rotulos de las unidades, que pone quien llama (pasan por la traduccion).
//   años luz: 290 ly · 24 200 ly · 52 M ly · 11 800 M ly
//   parsecs:  89 pc · 7.42 kpc · 16 Mpc · 3.62 Gpc
// Devuelve { text, number, unit }.
function cpSvFormatDistance(pc, unit, words) {
   var W = words || {};
   function w(k, d) { return (typeof W[k] === "string" && W[k].length > 0) ? W[k] : d; }
   if (!(pc > 0) || !isFinite(pc)) return { text: "—", number: "—", unit: "" };
   var num, u;
   if (unit === "ly") {
      var ly = cpSfDistanceIn(pc, "ly");
      if (ly >= 999500) { num = cpSvGroup(cpSvRound3(ly / 1e6)); u = w("mly", "M ly"); }
      else { num = cpSvGroup(cpSvRound3(ly)); u = w("ly", "ly"); }
   } else {
      if (pc >= 9.995e8) { num = cpSvGroup(cpSvRound3(pc / 1e9)); u = w("gpc", "Gpc"); }
      else if (pc >= 999500) { num = cpSvGroup(cpSvRound3(pc / 1e6)); u = w("mpc", "Mpc"); }
      else if (pc >= 999.5) { num = cpSvGroup(cpSvRound3(pc / 1e3)); u = w("kpc", "kpc"); }
      else { num = cpSvGroup(cpSvRound3(pc)); u = w("pc", "pc"); }
   }
   return { text: num + " " + u, number: num, unit: u };
}

// Unos años (el «su luz salio hace»): 8 400 yr · 52 M yr · 11 800 M yr.
function cpSvFormatYears(yr, words) {
   var W = words || {};
   if (!(yr > 0) || !isFinite(yr)) return "—";
   if (yr >= 999500) return cpSvGroup(cpSvRound3(yr / 1e6)) + " " + ((typeof W.myr === "string" && W.myr.length) ? W.myr : "M yr");
   return cpSvGroup(cpSvRound3(yr)) + " " + ((typeof W.yr === "string" && W.yr.length) ? W.yr : "yr");
}

// La COMA decimal en castellano (revision visual del 15-oct: «10.9 M al», «z = 5.16» en la version ES). Solo si el script
// tiene idioma (cshLangIsEs, CabraShared/csh_i18n.js); en node —las pruebas puras— el punto de siempre.
// (1-nov-2026, D5 del video de formacion: «G ≈ 20.1», «26.3 mag», «V 8.5», «M(G) +4.7» salian con punto en castellano: eran `toFixed` a pelo.
//  `cpSvFx(v, d)` = `v.toFixed(d)` con la coma en castellano; es lo que se usa para toda cifra que el usuario VE. Costura del rojo: CSH_DEC_BREAK = true
//  = siempre el punto.)
var CSH_DEC_BREAK = false;
function cpSvDecSep() { return (CSH_DEC_BREAK !== true && typeof cshLangIsEs === "function" && cshLangIsEs()) ? "," : "."; }
function cpSvDec(t) { return (cpSvDecSep() === ",") ? String(t).replace(/(\d)\.(\d)/g, "$1,$2") : String(t); }
function cpSvFx(v, d) { return cpSvDec(Number(v).toFixed(d)); }
function cpSvGroup(v) {
   var n = Math.abs(v), neg = (v < 0), dec = "";
   if (n < 100 && Math.abs(n - Math.round(n)) > 1e-9) {
      var d = (n < 10) ? 2 : 1, s0 = n.toFixed(d).replace(/0+$/, "").replace(/\.$/, "");
      var p = s0.split(".");
      n = Number(p[0]); dec = (p.length > 1) ? cpSvDecSep() + p[1] : "";
   } else
      n = Math.round(n);
   var s = String(n), out = "";
   while (s.length > 3) { out = " " + s.substring(s.length - 3) + out; s = s.substring(0, s.length - 3); }
   return (neg ? "-" : "") + s + out + dec;
}

// ---- desde ui/starfield_view.js:1993 ----
// Un numero de 0 a 1 por clave, siempre el mismo (el turno de salida de cada estrella y el
// subconjunto que se anima cuando son demasiadas).
function cpSvHash01(k, salt) {
   var x = Math.sin((k + 1.5) * 12.9898 + (salt || 0) * 78.233) * 43758.5453;
   return x - Math.floor(x);
}

// A QUIEN APUNTA EL RATON. Una rejilla de celdas con los indices de los puntos
// visibles; se hace al proyectar, no al mover el raton.
function cpSvHitGrid(px, py, inside, n, w, h, cell) {
   var c = Math.max(4, Math.round(cell || 10)), cols = Math.max(1, Math.ceil(w / c)), rows = Math.max(1, Math.ceil(h / c));
   var count = new Int32Array(cols * rows + 1), i, k;
   function cellOf(j) {
      var cx = Math.floor(px[j] / c), cy = Math.floor(py[j] / c);
      return (cx < 0 || cy < 0 || cx >= cols || cy >= rows) ? -1 : cy * cols + cx;
   }
   for (i = 0; i < n; ++i) { if (inside && !inside[i]) continue; k = cellOf(i); if (k >= 0) ++count[k + 1]; }
   for (i = 0; i < cols * rows; ++i) count[i + 1] += count[i];
   var fill = new Int32Array(cols * rows), index = new Int32Array(count[cols * rows]);
   for (i = 0; i < n; ++i) { if (inside && !inside[i]) continue; k = cellOf(i); if (k >= 0) index[count[k] + fill[k]++] = i; }
   return { cell: c, cols: cols, rows: rows, start: count, index: index };
}

// El primer valor «redondo» (1, 1.5, 2, 3, 5, 6, 8 por una potencia de diez) que no baja de v.
function cpSvNiceCeil(v) {
   if (!(v > 0) || !isFinite(v)) return 1;
   var e = Math.pow(10, Math.floor(Math.log(v) / Math.LN10)), f = v / e, S = [1, 1.5, 2, 3, 4, 5, 6, 8, 10];
   for (var i = 0; i < S.length; ++i) if (f <= S[i] * (1 + 1e-9)) return S[i] * e;
   return 10 * e;
}

// Marcas redondas entre lo y hi: pasos de 1, 2 o 5 por una potencia de diez.
function cpSvNiceTicks(lo, hi, maxTicks) {
   var span = hi - lo, out = [];
   if (!(span > 0) || !isFinite(span)) return out;
   // (con una holgura de una parte en un millon: 30 000 años luz pasados a parsecs y de vuelta son 30 000,000000004,
   // y sin ella el paso saltaba de 10 000 a 20 000 y el tramo se quedaba con una sola cifra. Visto en la captura.)
   var raw = span / Math.max(1, maxTicks || 6) * (1 - 1e-6), e = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10)), f = raw / e;
   var step = ((f <= 1) ? 1 : (f <= 2) ? 2 : (f <= 5) ? 5 : 10) * e;
   for (var v = Math.ceil(lo / step - 1e-9) * step; v <= hi + step * 1e-9; v += step)
      out.push(Math.abs(v) < step * 1e-9 ? 0 : Number(v.toPrecision(12)));
   return out;
}

// DE LA CAJA A LA FOTO (y vuelta): el avance del giro y el del aplastado en el instante `tau`
// (0 = la caja abierta, 1 = la foto de frente). La camara empieza a girar primero y la profundidad
// acaba de aplastarse despues: se ve como la caja se cierra sobre la foto. Devuelve { turn, flat }
// para `cpSvDistViewLerp( vista3D, vistaFoto, turn, flat )`.
function cpSvPhotoTau(tau) {
   return { turn: cpSvEase(tau / 0.8), flat: cpSvEase((tau - 0.2) / 0.8) };
}

// ---------------------------------------------------------------------------
// LAS CIFRAS
// ---------------------------------------------------------------------------
// Un numero con tres cifras significativas y los miles separados por un espacio.
function cpSvRound3(v) {
   if (!(v > 0) || !isFinite(v)) return 0;
   var e = Math.floor(Math.log(v) / Math.LN10), k = Math.pow(10, e - 2);
   return Math.round(v / k) * k;
}

// ===========================================================================
// LAS TRANSICIONES (13-oct-2026): de una vista a otra, CADA ESTRELLA VIAJA A SU SITIO
// ===========================================================================
// Tres estados del lienzo: FOTO (cada estrella en su sitio de la imagen), HR y 3D
// (Distances). Una ESCENA dice quien hay en un estado y donde: la clave de un punto
// es el indice de su estrella en `result.stars` (lo demas —un cumulo, una galaxia, un
// cuasar— lleva -( 1 + su indice en el modelo de distancias )), y eso es lo que
// permite saber que el punto del HR y el de la caja son LA MISMA estrella.
//   escena = { n, key, x, y (pixeles del lienzo), rgb, size (radio, px), alpha (1 = esta; 0 = no se ve),
//              mark (como se pinta alli: 0 = un punto; 1 = un anillo; 2 = un aspa) }
function cpSvScene(n) {
   return { n: n, key: new Int32Array(n), x: new Float32Array(n), y: new Float32Array(n), rgb: new Int32Array(n), size: new Float32Array(n), alpha: new Float32Array(n), mark: new Uint8Array(n) };
}

// ---- desde ui/starfield_view.js:1877 ----
// La estrella de `stars` mas cercana a un punto de la IMAGEN, entre las que estan
// en `allowed` (un mapa indice -> algo), a menos de `maxPx` pixeles de imagen.
function cpSvStarAt(stars, allowed, x, y, maxPx) {
   var best = -1, bd = maxPx * maxPx;
   for (var key in allowed) {
      if (!Object.prototype.hasOwnProperty.call(allowed, key)) continue;
      var s = stars[key];
      if (!s || s.x === null) continue;
      var dx = s.x - x, dy = s.y - y, d = dx * dx + dy * dy;
      if (d <= bd) { bd = d; best = Number(key); }
   }
   return best;
}

function cpSvStarRgb(bpRp) {
   var R = CP_SV_STAR_RAMP, c = Number(bpRp);
   // (23-oct-2026, tarde, encargo de Nino: «sin BP−RP» es el gris de «sin color». Antes `Number(null)` —y `Number("")`, `Number(false)`— daba 0:
   // el color de BP−RP = 0, azulado, en el 3D del campo y la máquina del tiempo de Cabra3D. Solo un NÚMERO finito (o su texto) es un color.)
   if (bpRp === null || bpRp === undefined || typeof bpRp === "boolean" || (typeof bpRp === "string" && bpRp.replace(/\s+/g, "").length === 0) || !isFinite(c)) return [220, 214, 200];
   if (c <= R[0][0]) return [R[0][1], R[0][2], R[0][3]];
   for (var i = 1; i < R.length; ++i)
      if (c <= R[i][0]) {
         var a = R[i - 1], b = R[i], t = (c - a[0]) / (b[0] - a[0]);
         return [Math.round(a[1] + (b[1] - a[1]) * t), Math.round(a[2] + (b[2] - a[2]) * t), Math.round(a[3] + (b[3] - a[3]) * t)];
      }
   var z = R[R.length - 1];
   return [z[1], z[2], z[3]];
}

// EL FOTOGRAMA de una transicion en el instante `tau` (el tiempo, de 0 —la salida— a 1 —la
// llegada—, SIN suavizar: el suavizado va aqui dentro, estrella a estrella, cada una con su turno
// de salida). Con tau = 0 cada punto esta EXACTAMENTE en su sitio de A y con tau = 1, en el de B.
// LA OPACIDAD de la que VIAJA y aparece (sale de la foto, donde no se ve) sube deprisa al despegar, y la de la que
// viaja y desaparece aguanta hasta que se posa (asi el viaje se ve entero, y las dos curvas son la misma pelicula
// al derecho y al reves); la de la que aparece o desaparece SIN moverse va repartida en todo el tiempo.
// `out` (opcional) se reutiliza de un fotograma a otro. Devuelve { x, y, a, size, rgb, hollow (0 = punto
// relleno … 1 = anillo: solo cuenta en los de T.mark 1) }.
function cpSvTransAt(T, tau, out) {
   var n = T.n, o = out || { x: new Float32Array(n), y: new Float32Array(n), a: new Float32Array(n), size: new Float32Array(n), rgb: new Int32Array(n), hollow: new Float32Array(n) };
   var st = CP_SV.ANIM_STAGGER, arc = CP_SV.ANIM_ARC, t = (tau > 0) ? ((tau < 1) ? tau : 1) : 0, span = 1 - st;
   for (var i = 0; i < n; ++i) {
      var s = cpSvEase((t - T.delay[i] * st) / span), q = 1 - s;
      var dx = T.x1[i] - T.x0[i], dy = T.y1[i] - T.y0[i], b = (s > 0 && s < 1) ? arc * Math.sin(Math.PI * s) : 0;
      o.x[i] = T.x0[i] * q + T.x1[i] * s - dy * b;
      o.y[i] = T.y0[i] * q + T.y1[i] * s + dx * b;
      var e = s;
      if (dx !== 0 || dy !== 0) e = (T.a1[i] > T.a0[i]) ? 1 - q * q * q : (T.a1[i] < T.a0[i]) ? s * s * s : s;
      o.a[i] = T.a0[i] * (1 - e) + T.a1[i] * e;
      o.size[i] = T.s0[i] * q + T.s1[i] * s;
      o.hollow[i] = T.h0[i] * q + T.h1[i] * s;
      var c0 = T.rgb0[i], c1 = T.rgb1[i];
      o.rgb[i] = (c0 === c1 || s <= 0) ? c0 : (s >= 1) ? c1 :
                 (Math.round(((c0 >> 16) & 255) * q + ((c1 >> 16) & 255) * s) << 16) | (Math.round(((c0 >> 8) & 255) * q + ((c1 >> 8) & 255) * s) << 8) | Math.round((c0 & 255) * q + (c1 & 255) * s);
   }
   return o;
}

// EMPAREJAR dos escenas. Cada punto de la transicion sale de su sitio en A y llega a su sitio en
// B. El que solo esta en una de las dos no viaja: aparece o desaparece por opacidad donde esta.
// Devuelve { n, key, x0, y0, x1, y1, a0, a1 (la opacidad en cada extremo), rgb0, rgb1, s0, s1 (el
// tamaño), delay (0…1: su turno de salida), from, to (su indice en A y en B, o -1), draw (1 = se
// anima), paired, onlyA, onlyB, shown, maxMove (lo mas que viaja uno que se ve, en pixeles) }.
function cpSvTransPair(A, B) {
   var at = {}, i, j, mate = new Int32Array(A.n), onlyB = [];
   for (i = 0; i < A.n; ++i) { mate[i] = -1; if (at[A.key[i]] === undefined) at[A.key[i]] = i; }
   for (i = 0; i < B.n; ++i) {
      j = at[B.key[i]];
      if (j !== undefined && mate[j] < 0) mate[j] = i; else onlyB.push(i);
   }
   var n = A.n + onlyB.length;
   var T = { n: n, key: new Int32Array(n), x0: new Float32Array(n), y0: new Float32Array(n), x1: new Float32Array(n), y1: new Float32Array(n),
             a0: new Float32Array(n), a1: new Float32Array(n), rgb0: new Int32Array(n), rgb1: new Int32Array(n), s0: new Float32Array(n), s1: new Float32Array(n),
             delay: new Float32Array(n), from: new Int32Array(n), to: new Int32Array(n), draw: new Uint8Array(n), mark: new Uint8Array(n), h0: new Uint8Array(n), h1: new Uint8Array(n),
             paired: 0, onlyA: 0, onlyB: onlyB.length, shown: 0, maxMove: 0 };
   for (i = 0; i < A.n; ++i) {
      j = mate[i];
      var ma = A.mark ? A.mark[i] : 0, mb = (j >= 0 && B.mark) ? B.mark[j] : ma;
      T.key[i] = A.key[i]; T.x0[i] = A.x[i]; T.y0[i] = A.y[i]; T.a0[i] = A.alpha[i]; T.rgb0[i] = A.rgb[i]; T.s0[i] = A.size[i]; T.from[i] = i; T.to[i] = j;
      // LA FORMA no cambia de golpe al llegar: un aspa lo es todo el viaje; un anillo que va a ser un punto se va rellenando
      T.mark[i] = (ma === 2 || mb === 2) ? 2 : (ma === 1 || mb === 1) ? 1 : 0; T.h0[i] = (ma === 1) ? 1 : 0; T.h1[i] = (mb === 1) ? 1 : 0;
      if (j >= 0) { T.x1[i] = B.x[j]; T.y1[i] = B.y[j]; T.a1[i] = B.alpha[j]; T.rgb1[i] = B.rgb[j]; T.s1[i] = B.size[j]; ++T.paired; }
      else { T.x1[i] = A.x[i]; T.y1[i] = A.y[i]; T.a1[i] = 0; T.rgb1[i] = A.rgb[i]; T.s1[i] = A.size[i]; ++T.onlyA; }
   }
   for (var q = 0; q < onlyB.length; ++q) {
      i = A.n + q; j = onlyB[q];
      T.key[i] = B.key[j]; T.x0[i] = B.x[j]; T.y0[i] = B.y[j]; T.x1[i] = B.x[j]; T.y1[i] = B.y[j]; T.a0[i] = 0; T.a1[i] = B.alpha[j];
      T.rgb0[i] = B.rgb[j]; T.rgb1[i] = B.rgb[j]; T.s0[i] = B.size[j]; T.s1[i] = B.size[j]; T.from[i] = -1; T.to[i] = j;
      var mo = B.mark ? B.mark[j] : 0;
      T.mark[i] = mo; T.h0[i] = (mo === 1) ? 1 : 0; T.h1[i] = T.h0[i];
   }
   // demasiados: se anima un subconjunto ESTABLE (por clave: los mismos en todos los fotogramas)
   var keep = (n > CP_SV.ANIM_MAX_POINTS) ? CP_SV.ANIM_MAX_POINTS / n : 1;
   for (i = 0; i < n; ++i) {
      T.delay[i] = cpSvHash01(T.key[i], 0);
      T.draw[i] = (keep >= 1 || cpSvHash01(T.key[i], 1) < keep) ? 1 : 0;
      if (T.draw[i]) ++T.shown;
      if (T.a0[i] > 0 || T.a1[i] > 0) {
         var dx = T.x1[i] - T.x0[i], dy = T.y1[i] - T.y0[i], d = Math.sqrt(dx * dx + dy * dy);
         if (d > T.maxMove) T.maxMove = d;
      }
   }
   return T;
}
