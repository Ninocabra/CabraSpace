// ============================================================================
// CabraShared/csh_depth_run.js — LA PROFUNDIDAD DE LA FOTO Y LO QUE SE VE EN ELLA: lo que toca la imagen y la red
// (Block G, 20-oct-2026). La aritmetica esta en csh_depth.js (pura, node).
// ----------------------------------------------------------------------------
// QUE HACE, en el orden en que lo llama el motor (csh_starfield_run.js, con `cshDepthWanted(opts)`):
//   1. `cshDepthMeasure(view, res)` — LA PROFUNDIDAD: en la posicion de cada estrella de Gaia del encuadre (aislada, de
//      todas las magnitudes; hasta BIN_MAX_N por tramo de 0,25 mag) una APERTURA FORZADA sobre la luminancia (la media de
//      los canales: vale en color y en B/N, lineal o estirada, porque solo se pregunta «¿hay luz de mas aqui?»), con el
//      fondo y su ruido de un anillo. El ruido de la apertura se calibra con aperturas VACIAS al azar (`eta`: en una foto
//      apilada el ruido esta correlado entre pixeles y el del anillo, por pixel, lo subestima); esas mismas aperturas dan
//      la tasa de falsos positivos (`fp5`, `fp3`). Detectada = S/R >= 5 (o saturada). Completitud por tramo -> G50, G90.
//      Si la foto es LINEAL (pendiente de G frente a la magnitud medida = 1 ± 0,05): el punto cero, la G de S/R = 5 por el
//      ruido de las aperturas vacias (`gSnr5`, la estimacion INDEPENDIENTE) y el brillo superficial limite en cajas de 10".
//   2. `cshDepthPruneStars(res)` — LAS ESTRELLAS QUE LA FOTO ALCANZA: fuera las del encuadre mas debiles que G50 + 1; entre
//      G90 y G50 + 1, solo si se ven en su sitio (S/R >= 5, la misma vara). Las de fuera del encuadre no se tocan (no se pintan y la
//      maquina del tiempo las puede necesitar). Se reindexan los cumulos.
//   3. `cshDepthDeepSky(result, out)` (desde cpStarfieldDeepSky) — LO LEJANO: mas fuentes (GLADE+, Quaia), y de cada objeto
//      su veredicto (csh_depth.js) y, si esta cerca del limite o no tiene magnitud, sus pixeles. Lo que no se ve sale de
//      `objects` a `hidden`, con su razon; `hiddenBy` las cuenta.
// Encendido: `CSH_DEPTH_ON` (Cabra3D lo pone a true) o `opts.depth === true`; `opts.depth === false` lo apaga. Los demas
// scripts no lo encienden: para ellos el motor hace lo de siempre.
// ES5.
// ============================================================================

var CSH_DEPTH_ON = false;             // Cabra3D.js lo enciende
var CSH_DEPTH_PRUNE_TEST_MAX = 40000; // diseño: estrellas de la franja G90..G50+1 que se miran una a una como mucho
var CSH_DEPTH_SEED = 20261020;        // diseño: semilla de las posiciones al azar (determinista: misma foto, mismo numero)

function cshDepthWanted(o) {
   if (o && o.depth === false) return false;
   return (o && o.depth === true) || CSH_DEPTH_ON === true;
}

// Azar determinista (mulberry32).
function cshRand(seed) {
   var a = seed >>> 0;
   return function() {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
   };
}
// (mediana de los n primeros, sin tocar `arr`: copia en un vector tipado, cuyo sort es numerico y rapido)
function cshMedianN(arr, n) {
   if (!(n > 0)) return NaN;
   var a = new Float64Array(n);
   for (var i = 0; i < n; ++i) a[i] = arr[i];
   a.sort();
   return (n % 2) ? a[n >> 1] : (a[(n >> 1) - 1] + a[n >> 1]) / 2;
}
function cshMad(vals, center) {
   var d = [];
   for (var i = 0; i < vals.length; ++i) d.push(Math.abs(vals[i] - center));
   return 1.4826 * cshMedianN(d, d.length);
}

// LA IMAGEN, por cajas: luminancia (media de hasta 3 canales) y si algun canal esta saturado (90 % de su maximo, como la
// fotometria del motor: CP_SF_PHOT_SATURATION).
function cshDepthCtx(view) {
   var img = view.image, nc = Math.min(3, img.numberOfChannels), sat = [], c;
   for (c = 0; c < nc; ++c) { img.selectedChannel = c; sat.push(0.9 * img.maximum()); }
   img.resetSelections();
   var tmp = {};
   function direct(rect, L, S) {
      var n = rect.width * rect.height, t = tmp[n] || (tmp[n] = new Float32Array(n)), i;
      for (i = 0; i < n; ++i) { L[i] = 0; S[i] = 0; }
      for (var k = 0; k < nc; ++k) {
         img.getSamples(t, rect, k);
         var s = sat[k];
         for (i = 0; i < n; ++i) { L[i] += t[i]; if (t[i] >= s) S[i] = 1; }
      }
      if (nc > 1) for (i = 0; i < n; ++i) L[i] /= nc;
   }
   // (23-oct-2026) UNA BALDOSA EN MEMORIA: la poda de estrellas mira miles de sitios; leidos de uno en uno son 3 llamadas
   // nativas por sitio. `tile(rect)` lee la luminancia de una baldosa UNA vez y `read` copia de ella lo que cae dentro (los
   // MISMOS valores: es la misma cuenta de `direct`); `tile(null)` la suelta.
   var T = null;
   return { view: view, img: img, W: img.width, H: img.height, nc: nc, sat: sat,
            tile: function(rect) {
               if (rect === null) { T = null; return; }
               var n = rect.width * rect.height;
               T = { x0: rect.x0, y0: rect.y0, x1: rect.x1, y1: rect.y1, w: rect.width, L: new Float32Array(n), S: new Uint8Array(n) };
               direct(rect, T.L, T.S);
            },
            read: function(rect, L, S) {
               if (T !== null && rect.x0 >= T.x0 && rect.y0 >= T.y0 && rect.x1 <= T.x1 && rect.y1 <= T.y1) {
                  var w = rect.width, h = rect.height;
                  for (var y = 0; y < h; ++y) {
                     var src = (rect.y0 - T.y0 + y) * T.w + (rect.x0 - T.x0), dst = y * w;
                     for (var x = 0; x < w; ++x) { L[dst + x] = T.L[src + x]; S[dst + x] = T.S[src + x]; }
                  }
                  return;
               }
               direct(rect, L, S);
            } };
}

// UNA APERTURA en (tx, ty) (indices de pixel), radio P.rAp, fondo en el anillo [P.rIn, P.rOut]. Borde suavizado a un
// pixel (como la fotometria del motor). -> { flux, nAp, bg, sig, snrLocal, sat } o null si no cabe.
function cshApMeasure(C, tx, ty, P) {
   var R = P.R, side = 2 * R + 1, x0 = Math.round(tx), y0 = Math.round(ty);
   if (x0 < R + 1 || y0 < R + 1 || x0 >= C.W - R - 1 || y0 >= C.H - R - 1) return null;
   var n = side * side;
   if (!P._L || P._L.length !== n) { P._L = new Float32Array(n); P._S = new Uint8Array(n); P._ring = new Float32Array(n); }
   var L = P._L, S = P._S, ring = P._ring;
   C.read(new Rect(x0 - R, y0 - R, x0 + R + 1, y0 + R + 1), L, S);
   var px = tx - x0, py = ty - y0, rIn2 = P.rIn * P.rIn, rOut2 = P.rOut * P.rOut, nr = 0, dx, dy;
   for (dy = -R; dy <= R; ++dy)
      for (dx = -R; dx <= R; ++dx) {
         var ex = dx - px, ey = dy - py, r2 = ex * ex + ey * ey;
         if (r2 >= rIn2 && r2 <= rOut2) ring[nr++] = L[(dy + R) * side + (dx + R)];
      }
   if (nr < 20) return null;
   var bg = cshMedianN(ring, nr);
   for (var i = 0; i < nr; ++i) ring[i] = Math.abs(ring[i] - bg);
   var sig = 1.4826 * cshMedianN(ring, nr);
   if (!(sig > 0)) { P.lastNoData = true; return null; }  // sin datos (borde negro del apilado, recorte): no dice nada
   P.lastNoData = false;
   var flux = 0, nAp = 0, sat = false, lim = (P.rAp + 0.5) * (P.rAp + 0.5);
   for (dy = -R; dy <= R; ++dy)
      for (dx = -R; dx <= R; ++dx) {
         var fx = dx - px, fy = dy - py, d2 = fx * fx + fy * fy;
         if (d2 > lim) continue;
         var w = Math.min(1, Math.max(0, P.rAp + 0.5 - Math.sqrt(d2)));
         if (w <= 0) continue;
         var at = (dy + R) * side + (dx + R);
         flux += w * (L[at] - bg); nAp += w;
         if (S[at]) sat = true;
      }
   return { flux: flux, nAp: nAp, bg: bg, sig: sig, snrLocal: (sig > 0 && nAp > 0) ? flux / (sig * Math.sqrt(nAp)) : 0, sat: sat };
}

// La FWHM y el desplazamiento foto - Gaia (mismo metodo que cpSfMeasureSeeing del motor, pero sobre la luminancia: el del
// motor lee el canal 1 y en B/N no existe). La FWHM, de las 60 primeras; el DESPLAZAMIENTO, de hasta CSH_DEPTH_OFF_N
// estrellas brillantes repartidas por la foto: la solucion astrometrica se aparta en los bordes (MEDIDO el 20-oct-2026 en
// Abell 39: las estrellas de G 15-17 «no detectadas» estaban todas a x > 5200 de 5693 o en las esquinas: la apertura
// caia al lado). `snrMin`: 30 sigmas de pico; en una foto estirada el pico se aplasta y se reintenta con 10.
// -> { fwhm, dx, dy, n, offs: [ { x, y, dx, dy } ] }
var CSH_DEPTH_OFF_N = 800;            // diseño
function cshDepthSeeing(C, stars, order, snrMin) {
   var R = 15, side = 2 * R + 1, n = side * side, L = new Float32Array(n), S = new Uint8Array(n), ring = new Float32Array(n), vals = [], peaks = [], sx = [], sy = [], offs = [];
   var kPeak = (snrMin > 0) ? snrMin : 30;
   var yieldOk = (typeof cshYield === "function");
   for (var q = 0; q < order.length && offs.length < CSH_DEPTH_OFF_N; ++q) {
      if (yieldOk && (q & 31) === 31) cshYield();
      var s = stars[order[q]], x = Math.round(s.x - 0.5), y = Math.round(s.y - 0.5);
      if (x < R + 1 || y < R + 1 || x >= C.W - R - 1 || y >= C.H - R - 1) continue;
      C.read(new Rect(x - R, y - R, x + R + 1, y + R + 1), L, S);
      var nr = 0, peak = -1e30, sat = false, i, dx, dy;
      for (dy = -R; dy <= R; ++dy)
         for (dx = -R; dx <= R; ++dx) {
            var at = (dy + R) * side + (dx + R), v = L[at], r2 = dx * dx + dy * dy;
            if (r2 >= 100 && r2 <= 225) ring[nr++] = v;
            if (r2 <= 16) { if (v > peak) peak = v; if (S[at]) sat = true; }
         }
      if (nr < 50 || sat) continue;
      var bg = cshMedianN(ring, nr);
      for (i = 0; i < nr; ++i) ring[i] = Math.abs(ring[i] - bg);
      var dev = 1.4826 * cshMedianN(ring, nr);
      if (!(peak - bg > kPeak * dev)) continue;
      var half = bg + (peak - bg) / 2, area = 0, sw = 0, cx = 0, cy = 0;
      for (dy = -8; dy <= 8; ++dy)
         for (dx = -8; dx <= 8; ++dx) {
            var u = L[(dy + R) * side + (dx + R)];
            if (u > half) { ++area; sw += u - half; cx += (u - half) * dx; cy += (u - half) * dy; }
         }
      if (area < 3 || area >= 200 || !(sw > 0)) continue;
      var ox = x + cx / sw - (s.x - 0.5), oy = y + cy / sw - (s.y - 0.5);
      vals.push(2 * Math.sqrt(area / Math.PI)); peaks.push((peak - bg) / dev);
      sx.push(ox); sy.push(oy); offs.push({ x: s.x, y: s.y, dx: ox, dy: oy });
   }
   if (vals.length < 5) {
      if (kPeak > 10) return cshDepthSeeing(C, stars, order, 10);
      return { fwhm: 0, dx: 0, dy: 0, n: vals.length, offs: [] };
   }
   // LA FWHM, de la MITAD MAS DEBIL de las medidas (al menos 10): en una foto lineal da lo mismo que las brillantes; en una
   // ESTIRADA las brillantes salen hinchadas —el estirado aplasta el nucleo— y con ellas la apertura crecia al doble y el
   // limite caia 0,75 mag (medido el 20-oct-2026 con NGC 1560 estirada: FWHM 8,96 px frente a 4,92)
   var pm = cshMedianN(peaks, peaks.length), fv = [];
   for (var t = 0; t < vals.length; ++t) if (peaks[t] <= pm) fv.push(vals[t]);
   if (fv.length < 10) fv = vals;
   return { fwhm: cshMedianN(fv, fv.length), fwhmBright: cshMedianN(vals, Math.min(vals.length, 60)), dx: cshMedianN(sx, sx.length), dy: cshMedianN(sy, sy.length), n: vals.length, offs: offs, peakSigmas: kPeak };
}

// EL CAMPO DE DESPLAZAMIENTOS: una rejilla de 16 x 12 nodos; en cada uno, la mediana de las 7 estrellas brillantes mas
// cercanas (con menos de 20 estrellas, el comun en todas partes). `at(x, y)` lo interpola (bilineal). -> { at, maxPx }
function cshDepthOffsetField(seeing, W, H) {
   var NX = 16, NY = 12, K = 7, offs = seeing.offs || [], gx = [], gy = [], i, j, k;
   var flat = (offs.length < 20);
   var maxPx = 0;
   for (j = 0; j < NY; ++j)
      for (i = 0; i < NX; ++i) {
         var px = (i + 0.5) * W / NX, py = (j + 0.5) * H / NY, dx = seeing.dx, dy = seeing.dy;
         if (!flat) {
            var best = [];
            for (k = 0; k < offs.length; ++k) {
               var d = (offs[k].x - px) * (offs[k].x - px) + (offs[k].y - py) * (offs[k].y - py);
               if (best.length < K) { best.push([d, k]); best.sort(function(a, b) { return a[0] - b[0]; }); }
               else if (d < best[K - 1][0]) { best[K - 1] = [d, k]; best.sort(function(a, b) { return a[0] - b[0]; }); }
            }
            var bx = [], by = [];
            for (k = 0; k < best.length; ++k) { bx.push(offs[best[k][1]].dx); by.push(offs[best[k][1]].dy); }
            dx = cshMedianN(bx, bx.length); dy = cshMedianN(by, by.length);
         }
         gx.push(dx); gy.push(dy);
         maxPx = Math.max(maxPx, Math.sqrt(dx * dx + dy * dy));
      }
   return { maxPx: maxPx, n: offs.length,
            at: function(x, y) {
               var u = Math.max(0, Math.min(NX - 1, x / W * NX - 0.5)), v = Math.max(0, Math.min(NY - 1, y / H * NY - 0.5));
               var i0 = Math.min(NX - 2, Math.floor(u)), j0 = Math.min(NY - 2, Math.floor(v)), a = u - i0, b = v - j0;
               function g(arr) { return (1 - a) * (1 - b) * arr[j0 * NX + i0] + a * (1 - b) * arr[j0 * NX + i0 + 1] + (1 - a) * b * arr[(j0 + 1) * NX + i0] + a * b * arr[(j0 + 1) * NX + i0 + 1]; }
               return { dx: g(gx), dy: g(gy) };
            } };
}

// Rejilla de las estrellas con posicion en pixeles (las de dentro y las de cerca del encuadre: tambien contaminan).
function cshDepthGrid(stars, cell) {
   var g = { cell: cell, map: {} }, yieldOk = (typeof cshYield === "function");
   for (var i = 0; i < stars.length; ++i) {
      if (yieldOk && (i & 4095) === 4095) cshYield();
      var s = stars[i];
      if (s.x === null || s.x === undefined || s.g === null) continue;
      var key = Math.floor(s.x / cell) + "," + Math.floor(s.y / cell);
      (g.map[key] || (g.map[key] = [])).push(i);
   }
   return g;
}
// Las estrellas a menos de `reach` px de (x, y) (coordenadas de la libreria): [ { i, d } ].
function cshDepthNear(grid, stars, x, y, reach) {
   var out = [], c = grid.cell, gx = Math.floor(x / c), gy = Math.floor(y / c), span = Math.ceil(reach / c);
   for (var ax = -span; ax <= span; ++ax)
      for (var ay = -span; ay <= span; ++ay) {
         var list = grid.map[(gx + ax) + "," + (gy + ay)];
         if (!list) continue;
         for (var k = 0; k < list.length; ++k) {
            var s = stars[list[k]], ddx = s.x - x, ddy = s.y - y, d = Math.sqrt(ddx * ddx + ddy * ddy);
            if (d <= reach) out.push({ i: list[k], d: d });
         }
      }
   return out;
}
// Luz ajena en la apertura de radio rAp: suma de 10^(-0,4 (G_vecina - G)) por la parte de su perfil que cae dentro
// (la misma cuenta que la fotometria del motor). `g0` = la G de la que se mide.
function cshDepthContam(grid, stars, idx, x, y, g0, rAp, sigmaPsf) {
   var near = cshDepthNear(grid, stars, x, y, rAp + 4 * sigmaPsf), sum = 0;
   for (var k = 0; k < near.length; ++k) {
      if (near[k].i === idx) continue;
      var s1 = stars[near[k].i], t = (near[k].d - rAp) / sigmaPsf;
      sum += Math.pow(10, -0.4 * (s1.g - g0)) * ((t <= 0) ? 1 : 0.5 * Math.exp(-t * t / 2));
   }
   return sum;
}

// ---------------------------------------------------------------------------
// 1 · LA PROFUNDIDAD
// -> res.depth = { ok, code, g50, g90, lower50, lower90, bins, fwhmPx, fwhmArcsec, rApPx, offsetPx, eta, etaMeasured,
//                  biasEmpty, fp5, fp3, nEmpty, nStars, slope, linear, zp, nZp, gSnr5, sigmaAp, sbLim, sbLimPix, sbBoxes,
//                  sbWhy, channels, ms }
// ---------------------------------------------------------------------------
function cshDepthMeasure(view, res, opts) {
   var o = opts || {}, t0 = Date.now();
   var D = { ok: false, code: "", g50: null, g90: null, lower50: false, lower90: false, bins: [], fwhmPx: 0, fwhmArcsec: 0, rApPx: 0, offsetPx: [0, 0],
             eta: 1, etaMeasured: false, biasEmpty: 0, fp5: 0, fp3: 0, nEmpty: 0, nStars: 0, slope: null, linear: false, zp: null, nZp: 0,
             gSnr5: null, sigmaAp: null, sbLim: null, sbLimPix: null, sbBoxes: 0, sbWhy: "", channels: 0, ms: 0, source: "forced aperture at the Gaia positions" };
   res.depth = D;
   function no(code) { D.code = code; D.ms = Date.now() - t0; return D; }
   if (!view || !optSafeView(view)) return no("no-view");
   var C = null;
   try { C = cshDepthCtx(view); } catch (e0) { D.error = String(e0.message || e0); return no("measure-failed"); }
   D.channels = C.nc;
   var stars = res.stars, f = res.field, i;
   if (typeof cshYield === "function") cshYield();
   var order = [];
   for (i = 0; i < stars.length; ++i) if (stars[i].inFrame && stars[i].g !== null && stars[i].x !== null) order.push(i);
   order.sort(function(p, q) { return stars[p].g - stars[q].g; });
   var seeing = null;
   if (typeof cshYield === "function") cshYield();
   try { seeing = cshDepthSeeing(C, stars, order); } catch (e1) { D.error = String(e1.message || e1); return no("measure-failed"); }
   if (!(seeing.fwhm > 0)) return no("few-stars");
   var fwhm = seeing.fwhm, sigmaPsf = fwhm / 2.3548;
   var rAp = Math.max(CSH_DEPTH.AP_MIN, CSH_DEPTH.AP_FWHM * fwhm);
   var rIn = Math.max(rAp + 3, 2.5 * fwhm), rOut = Math.min(30, rIn + Math.max(4, 1.5 * fwhm));
   if (rIn >= rOut - 2) rIn = rOut - 3;
   var P = { rAp: rAp, rIn: rIn, rOut: rOut, R: Math.ceil(rOut) + 1 };
   // (la apertura FOTOMETRICA, la del motor: 1,5 FWHM; la de detectar es pequeña —la de mas señal/ruido— y su fraccion de
   // luz cambia con el perfil: medido el 20-oct-2026, con ella LDu 2 daba pendiente 0,90 y con la del motor 1,01)
   var rPh = Math.max(2.5, Math.min(15, CP_SF_PHOT_APERTURE * fwhm)), rInP = Math.max(rPh + 2, 2.5 * fwhm), rOutP = Math.min(30, rInP + Math.max(3, fwhm));
   if (rInP >= rOutP - 2) rInP = rOutP - 3;
   var PP = { rAp: rPh, rIn: rInP, rOut: rOutP, R: Math.ceil(rOutP) + 1 };
   if (typeof cshYield === "function") cshYield();
   var OF = cshDepthOffsetField(seeing, C.W, C.H);
   if (typeof cshYield === "function") cshYield();
   D.fwhmPx = fwhm; D.fwhmArcsec = fwhm * (f.scaleArcsec || 0); D.rApPx = rAp; D.offsetPx = [seeing.dx, seeing.dy]; D.offsetMaxPx = OF.maxPx; D.offsetStars = OF.n;
   D.peakSigmas = seeing.peakSigmas; D.fwhmBrightPx = seeing.fwhmBright;
   var grid = cshDepthGrid(stars, Math.max(8, rAp + 4 * sigmaPsf));
   // --- las estrellas: hasta BIN_MAX_N aisladas por tramo -------------------------------------------------------------
   var perBin = {}, meas = [], yieldOk = (typeof cshYield === "function");            // (cshYield: Cabra3D, 22-oct, la interfaz atendida; csh_net.js)
   try {
      for (var q = 0; q < order.length; ++q) {
         if (yieldOk && (q & 7) === 7) cshYield();
         var idx = order[q], s = stars[idx], b = Math.floor(s.g / CSH_DEPTH.BIN);
         if ((perBin[b] || 0) >= CSH_DEPTH.BIN_MAX_N) continue;
         if (cshDepthContam(grid, stars, idx, s.x, s.y, s.g, rAp, sigmaPsf) > CSH_DEPTH.ISO_CONTAM) continue;
         var off = OF.at(s.x, s.y), m = cshApMeasure(C, s.x - 0.5 + off.dx, s.y - 0.5 + off.dy, P);
         if (m === null) continue;
         perBin[b] = (perBin[b] || 0) + 1;
         meas.push({ i: idx, g: s.g, bpRp: s.bpRp, flux: m.flux, snrLocal: m.snrLocal, sat: m.sat, sig: m.sig, off: off });
      }
   } catch (e2) { D.error = String(e2.message || e2); return no("measure-failed"); }
   D.nStars = meas.length;
   // --- las aperturas vacias: el ruido de verdad y los falsos positivos ------------------------------------------------
   var rnd = cshRand(CSH_DEPTH_SEED), ratios = [], fluxes = [], sigs = [], tries = 0, clear = rAp + 2 * fwhm, eAll = [];
   while (ratios.length < CSH_DEPTH.EMPTY_N && tries < 4 * CSH_DEPTH.EMPTY_N) {
      ++tries;
      if (yieldOk && (tries & 7) === 7) cshYield();
      var ex = P.R + 2 + rnd() * (C.W - 2 * P.R - 4), ey = P.R + 2 + rnd() * (C.H - 2 * P.R - 4);
      if (cshDepthNear(grid, stars, ex + 0.5, ey + 0.5, clear).length > 0) continue;
      var me = cshApMeasure(C, ex, ey, P);
      if (me === null || !(me.sig > 0)) continue;
      ratios.push(me.snrLocal); fluxes.push(me.flux); sigs.push(me.sig);
      eAll.push({ x: ex + 0.5, y: ey + 0.5, r: me.snrLocal });
   }
   // (23-oct-2026: mas sitios vacios, con OTRA semilla, para el MAPA del ruido —`cshDepthEtaMap`—: los de arriba y la secuencia
   // de `rnd` —que luego eligen las cajas del cielo— quedan como antes; eta, fp5, fp3, sigmaAp y mu_lim, identicos)
   if (CSH_DEPTH_VIS_ON === true) {
      var rndM = cshRand(CSH_DEPTH_SEED + 1), triesM = 0;
      while (eAll.length < CSH_VIS.EMPTY_MAP && triesM < 4 * CSH_VIS.EMPTY_MAP) {
         ++triesM;
         if (yieldOk && (triesM & 7) === 7) cshYield();
         var mx = P.R + 2 + rndM() * (C.W - 2 * P.R - 4), my = P.R + 2 + rndM() * (C.H - 2 * P.R - 4);
         if (cshDepthNear(grid, stars, mx + 0.5, my + 0.5, clear).length > 0) continue;
         var mm2 = cshApMeasure(C, mx, my, P);
         if (mm2 === null || !(mm2.sig > 0)) continue;
         eAll.push({ x: mx + 0.5, y: my + 0.5, r: mm2.snrLocal });
      }
   }
   D.nEmpty = ratios.length;
   if (ratios.length >= 30) {
      var med = cshMedianN(ratios, ratios.length);
      D.biasEmpty = med;
      D.eta = Math.max(0.5, cshMad(ratios, med));
      D.etaMeasured = true;
      D.sigmaAp = cshMad(fluxes, cshMedianN(fluxes, fluxes.length));
      var n5 = 0, n3 = 0;
      for (i = 0; i < ratios.length; ++i) { var rr = ratios[i] / D.eta; if (rr >= CSH_DEPTH.SNR_DET) ++n5; if (rr >= 3) ++n3; }        // (fp3: a 3 sigmas, el control de que la foto no da falsos positivos)
      D.fp5 = n5 / ratios.length; D.fp3 = n3 / ratios.length;
   }
   // (23-oct-2026) EL MAPA DEL RUIDO: eta por zonas (la textura de una nebulosa o el halo de una galaxia suben el ruido de
   // una apertura donde estan; un solo eta para toda la foto se lo traga)
   if (CSH_DEPTH_VIS_ON === true && D.etaMeasured) D.etaMap = cshDepthEtaMap(eAll, C.W, C.H, D.eta);
   // --- la completitud --------------------------------------------------------------------------------------------------
   var samples = [];
   for (i = 0; i < meas.length; ++i) {
      meas[i].snr = meas[i].snrLocal / D.eta;
      meas[i].det = meas[i].sat || meas[i].snr >= CSH_DEPTH.SNR_DET;
      samples.push({ g: meas[i].g, det: meas[i].det });
   }
   var lim = cshDepthLimits(samples, D.fp5);
   D.bins = lim.bins; D.fp = lim.fp;
   if (!lim.ok) return no(lim.code || "few-bins");
   D.g50 = lim.g50; D.g90 = lim.g90; D.lower50 = lim.lower50; D.lower90 = lim.lower90; D.gMax = lim.gMax;
   D._snrOf = {};
   for (i = 0; i < meas.length; ++i) D._snrOf[meas[i].i] = meas[i].sat ? Infinity : meas[i].snr;
   // --- (23-oct-2026) LO QUE SE VE A OJO: la misma completitud con la vara SNR_VIS y el ruido de SU zona (`etaMap`) ------
   // -> D.gVis50, D.gVis90 (lowerVis50/90 si es cota), D.binsVis; D._visOf = el S/R «a ojo» de cada estrella medida
   if (CSH_DEPTH_VIS_ON === true) {
      var sv = [], TV = CSH_DEPTH.SNR_VIS, nFpV = 0;
      D._visOf = {};
      for (i = 0; i < meas.length; ++i) {
         var stV = stars[meas[i].i], sV = meas[i].sat ? Infinity : meas[i].snrLocal / cshDepthEtaAt(D, stV.x, stV.y);
         D._visOf[meas[i].i] = sV;
         sv.push({ g: meas[i].g, det: meas[i].sat || sV >= TV });
      }
      for (i = 0; i < ratios.length; ++i) if (ratios[i] / D.eta >= TV) ++nFpV;
      D.fpVis = ratios.length ? nFpV / ratios.length : 0;
      var limV = cshDepthLimits(sv, D.fpVis);
      if (limV.ok) { D.gVis50 = limV.g50; D.gVis90 = limV.g90; D.lowerVis50 = limV.lower50; D.lowerVis90 = limV.lower90; D.binsVis = limV.bins; }
   }
   // --- el punto cero y la linealidad: estrellas con señal de sobra, sin saturar, con color de Gaia; apertura del motor y
   // TERMINO DE COLOR (G = a + b·m + c·(BP-RP)): sin el, las debiles —en promedio mas rojas— tuercen la pendiente (medido
   // el 20-oct-2026: el master L de Abell 39, lineal, daba 0,93 sin color) --------------------------------------------
   var xm = [], xc = [], ys = [], fr = [];
   for (i = 0; i < meas.length; ++i) {
      if (yieldOk && (i & 15) === 15) cshYield();
      var mm = meas[i];
      if (mm.sat || !(mm.flux > 0) || !(mm.snr >= CSH_DEPTH.ZP_MIN_SNR) || mm.bpRp === null || !isFinite(mm.bpRp)) continue;
      var sm = stars[mm.i], mb = cshApMeasure(C, sm.x - 0.5 + mm.off.dx, sm.y - 0.5 + mm.off.dy, PP);
      if (mb === null || mb.sat || !(mb.flux > 0)) continue;
      xm.push(-2.5 * Math.log(mb.flux) / Math.LN10); xc.push(mm.bpRp); ys.push(mm.g); fr.push(mm.flux / mb.flux);
   }
   D.nZp = xm.length;
   if (xm.length >= 20) {
      var pl = cpSfRobustPlane(xm, xc, ys, 3);
      if (pl.ok) { D.slope = pl.b1; D.colorTerm = pl.b2; }
      var rz = [];
      for (i = 0; i < xm.length; ++i) rz.push(ys[i] - xm[i]);
      var zl = cpSfRobustLine(xc, rz, 3);          // G - m = a + c·(BP-RP), con la pendiente 1
      var cMed = cshMedianN(xc, xc.length);
      if (zl.ok) { D.zp = zl.a + zl.b * cMed; D.zpColor = cMed; D.zpSigma = zl.sigma; }
      D.apFraction = cshMedianN(fr, fr.length);
      D.linear = (D.slope !== null && Math.abs(D.slope - 1) <= CSH_DEPTH.SLOPE_TOL);
   }
   // (la independiente: la luz que da S/R = 5 en la apertura de detectar, pasada a luz total con su fraccion medida)
   if (D.linear && D.zp !== null && D.sigmaAp > 0 && D.apFraction > 0)
      D.gSnr5 = D.zp - 2.5 * Math.log(CSH_DEPTH.SNR_DET * D.sigmaAp / D.apFraction) / Math.LN10;
   // --- el brillo superficial limite (solo LINEAL: sin punto cero no hay mag/arcsec²) ------------------------------------
   if (!D.linear) D.sbWhy = (D.slope === null) ? "too few bright stars to fix the zero point." : "the photo is not linear (stretched): there is no zero point for the sky.";
   else if (!(f.scaleArcsec > 0)) D.sbWhy = "unknown pixel scale.";
   else {
      try { cshDepthSky(C, D, stars, grid, f.scaleArcsec, sigs, rnd); } catch (e3) { D.sbWhy = "the sky boxes could not be read."; }
   }
   res._depthCtx = { view: view, P: { rAp: rAp, rIn: rIn, rOut: rOut, R: P.R }, dx: seeing.dx, dy: seeing.dy, off: OF, fwhm: fwhm, C: C };
   D.ok = true;
   D.ms = Date.now() - t0;
   return D;
}

// El ruido del cielo en cajas de 10" (media de la caja menos la mediana de su marco de 3 x 3 cajas), sin estrellas de Gaia
// mas brillantes que G50 dentro (ni a 2 FWHM). sigma = 1,4826 MAD de esas diferencias.
function cshDepthSky(C, D, stars, grid, scale, sigs, rnd) {
   var b = Math.max(3, Math.round(CSH_DEPTH.SB_BOX_ARCSEC / scale)), big = 3 * b, n = big * big;
   if (big + 4 >= Math.min(C.W, C.H)) { D.sbWhy = "the photo is too small for 10\" boxes."; return; }
   var L = new Float32Array(n), S = new Uint8Array(n), diffs = [], tries = 0, outer = new Float32Array(n);
   var yieldOk = (typeof cshYield === "function");
   while (diffs.length < CSH_DEPTH.SB_BOXES && tries < 6 * CSH_DEPTH.SB_BOXES) {
      ++tries;
      if (yieldOk) cshYield();
      var x0 = Math.floor(2 + rnd() * (C.W - big - 4)), y0 = Math.floor(2 + rnd() * (C.H - big - 4));
      var cx = x0 + 1.5 * b, cy = y0 + 1.5 * b;
      var near = cshDepthNear(grid, stars, cx, cy, b * 0.7072 + 2 * D.fwhmPx), bad = false;
      for (var k = 0; k < near.length; ++k) if (stars[near[k].i].g <= D.g50) { bad = true; break; }
      if (bad) continue;
      C.read(new Rect(x0, y0, x0 + big, y0 + big), L, S);
      var sum = 0, ni = 0, no = 0, satHit = false;
      for (var y = 0; y < big; ++y)
         for (var x = 0; x < big; ++x) {
            var v = L[y * big + x];
            if (S[y * big + x]) satHit = true;
            if (x >= b && x < 2 * b && y >= b && y < 2 * b) { sum += v; ++ni; } else outer[no++] = v;
         }
      if (satHit) continue;
      diffs.push(sum / ni - cshMedianN(outer, no));
   }
   D.sbBoxes = diffs.length;
   if (diffs.length < 30) { D.sbWhy = "too crowded: fewer than 30 sky boxes without stars."; return; }
   var sigmaBox = cshMad(diffs, cshMedianN(diffs, diffs.length));
   D.sigmaBox = sigmaBox;
   D.sbLim = cshSbLimit(D.zp, sigmaBox, scale, CSH_DEPTH.SB_NSIGMA);
   if (sigs.length > 0) { D.sigmaPix = cshMedianN(sigs, sigs.length); D.sbLimPix = cshSbLimitRoman(D.zp, D.sigmaPix, scale, CSH_DEPTH.SB_BOX_ARCSEC, CSH_DEPTH.SB_NSIGMA); }
}

// ---------------------------------------------------------------------------
// LOS PIXELES EN LA POSICION DE UN OBJETO (x, y de la libreria). `rPx` = radio de la apertura (0: la de las estrellas);
// `extPx` = su semieje (el anillo del fondo empieza fuera); `ignorePx` = las fuentes de Gaia a menos de eso del centro
// son el propio objeto (el nucleo de una galaxia, el cuasar). -> { snr, contaminated, trusted } o null (no cabe / sin foto)
// ---------------------------------------------------------------------------
function cshDepthPixelTest(res, x, y, rPx, extPx, ignorePx) {
   var K = res ? res._depthCtx : null, D = res ? res.depth : null;
   if (!K || !D || !D.ok || !optSafeView(K.view)) return null;
   var P = K.P, rA = Math.max(P.rAp, Math.min(rPx > 0 ? rPx : 0, 3 * P.rAp));
   var rI = Math.max(rA + 3, Math.min(extPx > 0 ? extPx : 0, 40), P.rIn), rO = rI + Math.max(4, 1.5 * K.fwhm);
   var Q = { rAp: rA, rIn: rI, rOut: rO, R: Math.ceil(rO) + 1 };
   var m = null;
   var off = K.off ? K.off.at(x, y) : { dx: K.dx, dy: K.dy };
   try { m = cshApMeasure(K.C, x - 0.5 + off.dx, y - 0.5 + off.dy, Q); } catch (e) { m = null; }
   if (m === null) return Q.lastNoData ? { noData: true, snr: null, contaminated: false, trusted: true } : null;
   if (!K.grid || K.gridN !== res.stars.length) { K.grid = cshDepthGrid(res.stars, Math.max(8, P.rAp + 4 * K.fwhm / 2.3548)); K.gridN = res.stars.length; }
   // contamina una estrella de Gaia (que no sea el propio objeto) que por si sola meteria en la apertura una luz de
   // G50 + 1 o mas brillante
   var sp = K.fwhm / 2.3548, near = cshDepthNear(K.grid, res.stars, x, y, rA + 4 * sp + 2 * K.fwhm), cont = false;
   for (var k = 0; k < near.length && !cont; ++k) {
      if (near[k].d <= (ignorePx > 0 ? ignorePx : 0)) continue;
      var t = (near[k].d - rA) / sp, w = (t <= 0) ? 1 : 0.5 * Math.exp(-t * t / 2);
      if (w > 0 && res.stars[near[k].i].g - 2.5 * Math.log(w) / Math.LN10 < D.g50 + CSH_DEPTH.BAND) cont = true;
   }
   var snr = m.sat ? Infinity : m.snrLocal / D.eta;
   // (23-oct-2026: `snrMap`, con el eta de SU zona —`cshDepthEtaAt`, nunca menor que el de toda la foto—)
   var snrMap = m.sat ? Infinity : m.snrLocal / cshDepthEtaAt(D, x, y);
   return { snr: snr, snrMap: snrMap, contaminated: cont, trusted: (D.etaMeasured === true && D.fp3 <= CSH_DEPTH.FP_MAX), flux: m.flux, rAp: rA };
}

// ---------------------------------------------------------------------------
// EL RUIDO DE ALREDEDOR (23-oct-2026, queja de Nino: «aparece un circulo donde deberian estar pero no los diferencio del
// ruido»). La pregunta del ojo no es «¿hay luz de mas aqui?» sino «¿destaca esto de lo que hay a su alrededor?». Se mide
// igual que lo mide el ojo: la MISMA apertura (radio `rA`, pixeles) en el objeto y en hasta CSH_VIS.NULL_MAX sitios de su
// alrededor (corona de `rho0` a `rho0` + NULL_SPAN_FWHM FWHM, rejilla de paso 2 rA + 1: aperturas que no se solapan), lejos
// de toda estrella de Gaia (radio rA + 1,5 FWHM, mas cuanto mas brillante) y sin pixeles saturados; el fondo, la mediana de
// la corona sin estrellas. snrLoc = (F_objeto - mediana(F_alrededor)) / (1,4826 MAD(F_alrededor)). Asi entran solos el
// ruido correlado de un apilado, la textura de una nebulosa o del halo de una galaxia y los gradientes: lo que el ojo ve
// como «ruido» donde esta el objeto, no la media de la foto. `rank` = fraccion de sitios de alrededor con tanta luz o mas.
// `extPx` = el semieje del objeto (la corona empieza fuera); `ignorePx` = las fuentes de Gaia a menos de eso son el propio
// objeto. -> { snrLoc, rank, n, F0, med, sig, sat, bg } | { noData: true } | null (sin profundidad / no cabe / pocos sitios)
// ---------------------------------------------------------------------------
var CSH_VIS = {
   NULL_MIN: 16,           // diseño: con menos sitios limpios alrededor, la MAD no dice nada (se devuelve null)
   NULL_MAX: 64,           // diseño: sitios que se miden como mucho (el coste: 64 aperturas de ~30 px)
   NULL_SPAN_FWHM: 12,     // diseño: ancho de la corona, en FWHM (lo que el ojo compara al mirar un circulo ampliado)
   NULL_EXT_MAX: 40,       // diseño: un objeto de semieje mayor (pixeles) no se mide asi (la corona saldria del recorte)
   EMPTY_MAP: 1600,        // diseño: aperturas vacias para el MAPA del ruido (las EMPTY_N primeras son las de siempre; ~33 por zona)
   ETA_NX: 8, ETA_NY: 6,   // diseño: zonas del mapa (6 000 x 4 000 px -> 750 x 670 px cada una)
   ETA_MIN_N: 20,          // diseño: una zona con menos aperturas vacias se queda con el eta de toda la foto
   TILE: 512               // diseño: lado de la baldosa que la poda de estrellas lee de una vez
};
// EL MAPA DEL RUIDO: en cada zona, eta = 1,4826 MAD de (flujo / ruido del anillo) de sus aperturas vacias. -> { nx, ny, v[] }
function cshDepthEtaMap(empties, W, H, etaAll) {
   var NX = CSH_VIS.ETA_NX, NY = CSH_VIS.ETA_NY, cells = [], i, v = [];
   for (i = 0; i < NX * NY; ++i) cells.push([]);
   for (i = 0; i < empties.length; ++i) {
      var e = empties[i], cx = Math.min(NX - 1, Math.max(0, Math.floor(e.x / W * NX))), cy = Math.min(NY - 1, Math.max(0, Math.floor(e.y / H * NY)));
      cells[cy * NX + cx].push(e.r);
   }
   var nUsed = 0;
   for (i = 0; i < cells.length; ++i) {
      if (cells[i].length < CSH_VIS.ETA_MIN_N) { v.push(etaAll); continue; }
      ++nUsed;
      v.push(Math.max(0.5, cshMad(cells[i], cshMedianN(cells[i], cells[i].length))));
   }
   var mx = 0; for (i = 0; i < v.length; ++i) mx = Math.max(mx, v[i]);
   return { nx: NX, ny: NY, W: W, H: H, v: v, nCells: nUsed, max: mx };
}
// El eta en (x, y): el del mapa (bilineal entre centros de zona) y nunca menos que el de toda la foto (la vara de siempre
// no se afloja: el mapa solo puede endurecerla donde la foto es mas ruidosa).
function cshDepthEtaAt(D, x, y) {
   var M = D ? D.etaMap : null, e = (D && D.eta > 0) ? D.eta : 1;
   if (!M || CSH_DEPTH_VIS_ON !== true) return e;
   var u = Math.max(0, Math.min(M.nx - 1, x / M.W * M.nx - 0.5)), w = Math.max(0, Math.min(M.ny - 1, y / M.H * M.ny - 0.5));
   var i0 = Math.min(M.nx - 2, Math.floor(u)), j0 = Math.min(M.ny - 2, Math.floor(w)), a = u - i0, b = w - j0;
   if (M.nx < 2 || M.ny < 2) return Math.max(e, M.v[0]);
   var V = M.v, m = (1 - a) * (1 - b) * V[j0 * M.nx + i0] + a * (1 - b) * V[j0 * M.nx + i0 + 1] + (1 - a) * b * V[(j0 + 1) * M.nx + i0] + a * b * V[(j0 + 1) * M.nx + i0 + 1];
   return Math.max(e, m);
}
function cshDepthLocalNull(res, x, y, rA, extPx, ignorePx, nMax, spanFwhm) {
   var NMAX = (nMax > 0) ? Math.min(nMax, CSH_VIS.NULL_MAX) : CSH_VIS.NULL_MAX, SPAN = (spanFwhm > 0) ? spanFwhm : CSH_VIS.NULL_SPAN_FWHM;
   var K = res ? res._depthCtx : null, D = res ? res.depth : null;
   if (!K || !D || !D.ok || !optSafeView(K.view)) return null;
   var ext = (extPx > 0) ? extPx : 0;
   if (ext > CSH_VIS.NULL_EXT_MAX) return null;
   var C = K.C, f = K.fwhm, off = K.off ? K.off.at(x, y) : { dx: K.dx, dy: K.dy };
   var tx = x - 0.5 + off.dx, ty = y - 0.5 + off.dy;
   var rho0 = ext + 2 * rA + 2 * f, rho1 = rho0 + SPAN * f, R = Math.ceil(rho1 + rA + 1);
   var xc = Math.round(tx), yc = Math.round(ty);
   var bx0 = Math.max(0, xc - R), by0 = Math.max(0, yc - R), bx1 = Math.min(C.W, xc + R + 1), by1 = Math.min(C.H, yc + R + 1);
   var bw = bx1 - bx0, bh = by1 - by0;
   if (bw < 8 || bh < 8 || tx - rA < bx0 || ty - rA < by0 || tx + rA >= bx1 - 1 || ty + rA >= by1 - 1) return null;
   var n = bw * bh;
   // (los vectores se reutilizan entre llamadas: en la poda de estrellas son miles)
   if (!K._ln || K._ln.n < n) K._ln = { n: n, L: new Float32Array(n), S: new Uint8Array(n), M: new Uint8Array(n), ring: new Float32Array(n) };
   var L = K._ln.L, S = K._ln.S, M = K._ln.M, ringBuf = K._ln.ring;
   C.read(new Rect(bx0, by0, bx1, by1), L, S);
   for (var z = 0; z < n; ++z) M[z] = 0;
   // las estrellas de Gaia de la caja (salvo el propio objeto), cada una con su disco de exclusion (mas grande cuanto mas
   // brillante), pintado UNA vez en la mascara M
   if (!K.grid || K.gridN !== res.stars.length) { K.grid = cshDepthGrid(res.stars, Math.max(8, K.P.rAp + 4 * f / 2.3548)); K.gridN = res.stars.length; }
   var near = cshDepthNear(K.grid, res.stars, x, y, R * 1.415 + 12 * f), k, i, j;
   for (k = 0; k < near.length; ++k) {
      if (near[k].d <= ((ignorePx > 0) ? ignorePx : 0)) continue;
      var st = res.stars[near[k].i], gs = (st.g !== null && isFinite(st.g)) ? st.g : D.g50;
      var rm = rA + f * Math.min(12, 1.5 + 0.5 * Math.max(0, D.g50 - gs)), rm2 = rm * rm;
      var sx = st.x - 0.5 + off.dx - bx0, sy = st.y - 0.5 + off.dy - by0;
      var mx0 = Math.max(0, Math.floor(sx - rm)), mx1 = Math.min(bw - 1, Math.ceil(sx + rm)), my0 = Math.max(0, Math.floor(sy - rm)), my1 = Math.min(bh - 1, Math.ceil(sy + rm));
      for (j = my0; j <= my1; ++j) { var ddy = j - sy, row = j * bw; for (i = mx0; i <= mx1; ++i) { var ddx = i - sx; if (ddx * ddx + ddy * ddy < rm2) M[row + i] = 1; } }
   }
   var cx = tx - bx0, cy = ty - by0, rho02 = rho0 * rho0, rho12 = rho1 * rho1;
   // el fondo: la mediana de la corona sin estrellas (cada 2 pixeles basta)
   var nr = 0;
   for (j = 0; j < bh; j += 2)
      for (i = 0; i < bw; i += 2) {
         var dx0 = i - cx, dy0 = j - cy, r2 = dx0 * dx0 + dy0 * dy0, at0 = j * bw + i;
         if (r2 < rho02 || r2 > rho12 || S[at0] || M[at0]) continue;
         ringBuf[nr++] = L[at0];
      }
   if (nr < 50) return null;
   var bg = cshMedianN(ringBuf, nr);
   function apSum(px, py) {
      var s = 0, lim = (rA + 0.5) * (rA + 0.5), sat = false;
      var ix0 = Math.max(0, Math.floor(px - rA - 1)), ix1 = Math.min(bw - 1, Math.ceil(px + rA + 1)), iy0 = Math.max(0, Math.floor(py - rA - 1)), iy1 = Math.min(bh - 1, Math.ceil(py + rA + 1));
      for (var yy = iy0; yy <= iy1; ++yy)
         for (var xx = ix0; xx <= ix1; ++xx) {
            var fx = xx - px, fy = yy - py, d2 = fx * fx + fy * fy;
            if (d2 > lim) continue;
            var w = Math.min(1, Math.max(0, rA + 0.5 - Math.sqrt(d2)));
            if (w <= 0) continue;
            s += w * (L[yy * bw + xx] - bg);
            if (S[yy * bw + xx]) sat = true;
         }
      return { s: s, sat: sat };
   }
   var obj = apSum(cx, cy);
   // los sitios de alrededor: rejilla de paso 2 rA + 1, dentro de la corona y de la caja, limpios
   var step = 2 * rA + 1, cand = [];
   for (var gy = -Math.floor(rho1 / step); gy <= Math.floor(rho1 / step); ++gy)
      for (var gx = -Math.floor(rho1 / step); gx <= Math.floor(rho1 / step); ++gx) {
         var px = cx + gx * step, py = cy + gy * step, d2c = (gx * step) * (gx * step) + (gy * step) * (gy * step);
         if (d2c < rho02 || d2c > rho12) continue;
         if (px - rA - 1 < 0 || py - rA - 1 < 0 || px + rA + 1 > bw - 1 || py + rA + 1 > bh - 1) continue;
         if (M[Math.round(py) * bw + Math.round(px)]) continue;          // (el centro fuera de todo disco: rm ya lleva rA dentro)
         cand.push([px, py]);
      }
   if (cand.length < CSH_VIS.NULL_MIN) return null;
   var every = Math.max(1, cand.length / NMAX), fl = [];
   for (var kk = 0; kk < NMAX; ++kk) {
      var t = Math.floor(kk * every);
      if (t >= cand.length) break;
      var m = apSum(cand[t][0], cand[t][1]);
      if (!m.sat) fl.push(m.s);
   }
   if (fl.length < CSH_VIS.NULL_MIN) return null;
   var med = cshMedianN(fl, fl.length), sig = cshMad(fl, med);
   if (!(sig > 0)) return { noData: true };
   var above = 0;
   for (k = 0; k < fl.length; ++k) if (fl[k] >= obj.s) ++above;
   return { snrLoc: obj.sat ? Infinity : (obj.s - med) / sig, rank: above / fl.length, n: fl.length, F0: obj.s, med: med, sig: sig, sat: obj.sat, bg: bg, rA: rA };
}

// ¿SE VE EN SU SITIO? (23-oct-2026) La prueba de pixeles de siempre (`cshDepthPixelTest`: S/R frente al ruido de la foto,
// calibrado con aperturas vacias) Y la de su alrededor (`cshDepthLocalNull`), con la MISMA apertura; `snrVis` = la menor de
// las dos (si no se pudo medir el alrededor —un borde, una zona llena de estrellas—, la de siempre). `localWhen` = mirar el
// alrededor solo si la de siempre pasa de esto (el coste: la de siempre por debajo del umbral ya dice «no»). La decision la
// toma `cshDepthResolve` (csh_depth.js) con CSH_DEPTH.SNR_VIS.
// -> { snr, snrLoc, snrVis, contaminated, trusted, rAp, nNull } | { noData: true, … } | null
function cshDepthSeenAt(res, x, y, rPx, extPx, ignorePx, localWhen) {
   var pt = cshDepthPixelTest(res, x, y, rPx, extPx, ignorePx);
   if (pt === null || pt.noData) return pt;
   var loc = null, nNull = 0;
   var base = (CSH_DEPTH_VIS_ON === true && pt.snrMap !== undefined) ? pt.snrMap : pt.snr;
   var want = (CSH_DEPTH_VIS_ON === true) && (base === Infinity || !(localWhen > 0) || base >= localWhen);
   if (want) {
      var ln = null;
      try { ln = cshDepthLocalNull(res, x, y, pt.rAp, extPx, ignorePx); } catch (e) { ln = null; }
      if (ln && !ln.noData && (ln.snrLoc === Infinity || isFinite(ln.snrLoc))) { loc = ln.snrLoc; nNull = ln.n; }
   }
   pt.snrLoc = loc; pt.nNull = nNull;
   pt.snrVis = (loc === null) ? base : Math.min(base, loc);
   return pt;
}
// ¿Se ve? (la misma decision que `cshDepthResolve` con pixeles limpios) para quien solo tiene un sitio: las estrellas.
function cshDepthSeenSnr() { return (CSH_DEPTH_VIS_ON === true) ? CSH_DEPTH.SNR_VIS : CSH_DEPTH.SNR_POS; }

// ---------------------------------------------------------------------------
// 2 · LAS ESTRELLAS QUE LA FOTO ALCANZA
// -> res.depth.pruned = { stars, withDistance, tested, detected, kept }
// ---------------------------------------------------------------------------
function cshDepthPruneStars(res) {
   var D = res.depth, stars = res.stars, i;
   D.pruned = { stars: 0, withDistance: 0, tested: 0, detected: 0, untested: 0 };
   if (!D || !D.ok) return D.pruned;
   if (CSH_DEPTH_VIS_ON === true && D.gVis50 > 0) return cshDepthPruneVis(res);
   if (!(D.g50 > 0) || D.lower50) return D.pruned;
   var g90 = (D.g90 !== null) ? D.g90 : D.g50, top = D.g50 + CSH_DEPTH.BAND, keep = new Array(stars.length), tests = 0;
   // las de la franja con paralaje positiva primero (las que pueden tener distancia), luego el resto, hasta el tope
   var band = [];
   for (i = 0; i < stars.length; ++i) {
      var s = stars[i];
      keep[i] = true;
      if (!s.inFrame || s.g === null) continue;
      if (s.g <= g90) continue;
      if (s.g > top) { keep[i] = false; continue; }
      band.push(i);
   }
   band.sort(function(a, b) { return stars[a].g - stars[b].g; });
   var yieldOk = (typeof cshYield === "function");
   for (var q = 0; q < band.length; ++q) {
      if (yieldOk && (q & 15) === 15) cshYield();
      var k = band[q], st = stars[k], snr = (D._snrOf && D._snrOf[k] !== undefined) ? D._snrOf[k] : null, px = null;
      // (una a una solo las que pueden llegar a tener distancia —paralaje positiva—; las demas no se pintan en 3D y decide
      // su magnitud: medido el 20-oct-2026, LDu 2 gastaba 8,6 s mirando 17 500)
      if (snr === null && st.plx > 0 && tests < CSH_DEPTH_PRUNE_TEST_MAX) { px = cshDepthPixelTest(res, st.x, st.y, 0, 0, 0.5); ++tests; }
      if (snr === null && px && !px.contaminated) snr = px.snr;
      if (snr === null) { keep[k] = (st.g <= D.g50); ++D.pruned.untested; continue; }
      ++D.pruned.tested;
      keep[k] = (snr >= CSH_DEPTH.SNR_POS);
      if (keep[k]) ++D.pruned.detected;
   }
   return cshDepthPruneKeep(res, keep);
}

// (23-oct-2026) LAS ESTRELLAS QUE SE VEN A OJO. La misma idea con la vara de lo que se ve (CSH_DEPTH.SNR_VIS, con el eta de
// su zona): hasta gVis90 - VIS_SAFE (lo bastante brillante para verse siempre) todas; de ahi a G50 + 1, TODAS las del
// encuadre se miran en su sitio (despues del afinado casi todas tienen distancia de Bailer-Jones y se pintan: antes solo se
// miraban las de paralaje positiva y en las Pleyades se pintaban 3 500 de S/R 5-10, que a ojo no se ven —tests/c3_vis_probe.js—);
// las que tienen una vecina que les mete luz deciden por su magnitud (hasta gVis90). Leidas por baldosas (`C.tile`: los mismos
// pixeles, menos llamadas). Mas debiles que G50 + 1, fuera (si la foto llega mas hondo que Gaia, no hay tope).
var CSH_DEPTH_VIS_SAFE = 1.0;          // diseño: mas brillante que gVis90 - 1 (x2,5 la luz de una que se ve al 90 %) no se mira
var CSH_DEPTH_VIS_CURVE_ALL = 0.99;    // diseño: un tramo de la curva «a ojo» con >= 99 % se da por visto entero
var CSH_DEPTH_VIS_CURVE_NONE = 0.01;   // diseño: pasado el primer tramo con <= 1 % no se mira ninguna
var CSH_DEPTH_PRUNE_LOCAL_N = 64;      // MEDIDO (26-oct-2026, A'b): aperturas del alrededor por estrella = las de un objeto (antes 24: la MAD de 24, ±15 %). Con 24 la estrella era mas estricta que
                                       //   un cuasar con la misma S/R (Pleyades: de las inyectadas de S/R 16 y 18, «debiles» 79/107 frente a 97/107 de lo lejano); con 64, 90/107, y la poda cuesta lo mismo
                                       //   (Pleyades 5,1 s, LDu 2 7,2 → 7,9 s: lo que cuesta es leer y enmascarar, no sumar mas aperturas)
var CSH_DEPTH_PRUNE_LOCAL_SPAN = 12;   // diseño, MEDIDO el 23-oct-2026: con 6 FWHM (un tercio de pixeles) la poda de LDu 2 baja de 4,8
                                       //   a 4,0 s pero en las Pleyades pasa por buenas 141 estrellas que con 12 —el recorte que mira el
                                       //   ojo: ±12 FWHM— no destacan de su nebulosa (flips 431 -> 290): se queda la de los objetos
var CSH_DEPTH_PRUNE_LOCAL_UPTO = 1.5;  // diseño: el alrededor solo en las que pasan por menos de 1,5 x la vara (el coste: LDu 2); desde el 26-oct tambien hasta
                                       //   CSH_DEPTH_FAINT_LOCAL_K x SNR_CLEAR (`cshDepthStarLocal`): lo «debil» es la menor de zona y alrededor, como en lo lejano
var CSH_DEPTH_FAINT_LOCAL_K = 1.5;     // diseño (26-oct-2026, A'b): una estrella de S/R de zona hasta 1,5 x SNR_CLEAR se mira tambien frente a su alrededor: ahi el alrededor aun
                                       //   puede bajarla de SNR_CLEAR (un alrededor con 1,5 x el ruido de la zona). MEDIDO en `tests/c3_vis_faint_stars.js` (SA)
var CSH_DEPTH_PRUNE_LOCAL_MAX = 20000; // diseño: estrellas que se miran frente a su alrededor como mucho (el coste)
// (26-oct-2026, A'b de Nino) LA S/R «A OJO» DE UNA ESTRELLA, en dos pasos, para que la poda y la prueba de inyectadas usen el MISMO codigo:
//   1. `cshDepthStarPixel`: la prueba de pixeles de siempre (S/R frente al ruido de SU zona, `snrMap`) con la apertura de estrella (la de un cuasar de
//      lo lejano). -> { noData } | { contaminated } | { sv }   (`tileFn(st)` deja leida la baldosa de la estrella: el coste de la poda)
//   2. `cshDepthStarLocal`: la menor de esa y la de SU alrededor (`cshDepthLocalNull`), solo si pasa la vara por menos de lo que haga falta para
//      saber si es «debil» (hasta SNR_CLEAR, no solo 1,5 x la vara). `opts.n` aperturas (24 la poda; las 64 de lo lejano si se pide) y `opts.span`.
//   Lo que la poda guarda en `st.snrVis` es esto: la misma magnitud que `ob.depth.snrVis` de lo lejano (`cshDepthFaintSnr`).
function cshDepthStarPixel(res, st, tileFn) {
   if (typeof tileFn === "function") tileFn(st);
   var px = cshDepthPixelTest(res, st.x, st.y, 0, 0, 0.5);
   if (px === null) return { sv: null };
   if (px.noData) return { noData: true, sv: null };
   if (px.contaminated) return { contaminated: true, sv: null };
   return { sv: px.snrMap };
}
function cshDepthStarLocal(res, st, sv, tileFn, opts) {
   var TV = CSH_DEPTH.SNR_VIS, o = opts || {}, upto = Math.max(CSH_DEPTH_PRUNE_LOCAL_UPTO, (CSH_DEPTH.SNR_CLEAR > 0) ? CSH_DEPTH_FAINT_LOCAL_K * CSH_DEPTH.SNR_CLEAR / TV : 0);
   if (!(sv >= TV) || sv === Infinity || !(sv < upto * TV)) return { sv: sv, local: false, flip: false };
   if (typeof tileFn === "function") tileFn(st);
   var ln = cshDepthLocalNull(res, st.x, st.y, res.depth.rApPx, 0, 0.5, (o.n > 0) ? o.n : CSH_DEPTH_PRUNE_LOCAL_N, (o.span > 0) ? o.span : CSH_DEPTH_PRUNE_LOCAL_SPAN);
   if (ln && !ln.noData && (ln.snrLoc === Infinity || isFinite(ln.snrLoc))) return { sv: Math.min(sv, ln.snrLoc), local: true, flip: (ln.snrLoc < TV) };
   return { sv: sv, local: true, flip: false };
}
function cshDepthPruneVis(res) {
   var D = res.depth, stars = res.stars, i, TV = CSH_DEPTH.SNR_VIS, t0 = Date.now();
   var gv90 = (D.gVis90 > 0) ? D.gVis90 : D.gVis50, safe = gv90 - CSH_DEPTH_VIS_SAFE, top = (D.lower50 || !(D.g50 > 0)) ? Infinity : D.g50 + CSH_DEPTH.BAND;
   // (el COSTE, medido el 23-oct-2026: en LDu 2 la franja gVis90 - 1 .. G50 + 1 eran 37 000 estrellas y 9,8 s. La propia curva
   // de completitud «a ojo» de ESTA foto dice donde ya no hace falta mirar: por encima del ultimo tramo con >= 99 % se ven
   // todas, y pasado el primero con <= 1 % no se ve ninguna (el 1 % que se pierde se dice: `pruned.byCurve`))
   var BV = D.binsVis || [], gTop = null, gLow = null, bi;
   for (bi = 0; bi < BV.length; ++bi) { if (BV[bi].iso >= CSH_DEPTH_VIS_CURVE_ALL) gLow = BV[bi].g + CSH_DEPTH.BIN / 2; else break; }
   for (bi = 0; bi < BV.length; ++bi) if (BV[bi].g > gv90 && BV[bi].iso <= CSH_DEPTH_VIS_CURVE_NONE) { gTop = BV[bi].g - CSH_DEPTH.BIN / 2; break; }
   if (gLow !== null && gLow > safe) safe = Math.min(gLow, gv90);
   var cut = (gTop !== null) ? Math.min(top, gTop) : top, byCurve = 0;
   D.pruned.safe = safe; D.pruned.cut = cut;
   var keep = new Array(stars.length), band = [], safeOut = 0, safeZoneFaint = 0;
   for (i = 0; i < stars.length; ++i) {
      var s = stars[i];
      keep[i] = true;
      if (!s.inFrame || s.g === null || s.x === null) continue;
      // (brillante por su G pero MEDIDA en su sitio —aislada, en la muestra de la completitud— y no llega: fuera. MEDIDO el
      // 23-oct-2026 en Abell 39, banda estrecha: 15 de G <= 17,5 con S/R < 5; su G no es su luz en Hα/OIII/SII)
      if (s.g <= safe) {
         if (D._visOf && D._visOf[i] !== undefined && D._visOf[i] < TV) { keep[i] = false; ++safeOut; }
         else if (D._visOf && D._visOf[i] !== undefined && D._visOf[i] < CSH_DEPTH.SNR_CLEAR) ++safeZoneFaint;      // (26-oct-2026, A'b) brillantes por su G con S/R de zona 12-20 (sin su alrededor: NO se marcan «debiles»; se cuentan)
         continue;
      }
      if (s.g > top) { keep[i] = false; continue; }
      // (pasado el tramo de <= 1 %: fuera sin mirar, salvo las MEDIDAS que si llegan)
      if (s.g > cut) { var mv = (D._visOf && D._visOf[i] !== undefined) ? D._visOf[i] : null; keep[i] = (mv !== null && mv >= TV); if (!keep[i]) ++byCurve; continue; }
      band.push(i);
   }
   var K = res._depthCtx, C = K ? K.C : null, TS = CSH_VIS.TILE, MG = 128, locals = 0, flips = 0;
   function tileOf(k) { return Math.floor(stars[k].y / TS) * 100000 + Math.floor(stars[k].x / TS); }
   // (la baldosa de la estrella, leida una vez para todas las de su cuadro: lo llaman `cshDepthStarPixel` y `cshDepthStarLocal`)
   var cur = -1;
   function tileFn(s2) {
      if (!(C && typeof C.tile === "function")) return;
      var tk = Math.floor(s2.y / TS) * 100000 + Math.floor(s2.x / TS);
      if (tk === cur) return;
      cur = tk;
      var ix = Math.floor(s2.x / TS), iy = Math.floor(s2.y / TS);
      C.tile(new Rect(Math.max(0, ix * TS - MG), Math.max(0, iy * TS - MG), Math.min(C.W, (ix + 1) * TS + MG), Math.min(C.H, (iy + 1) * TS + MG)));
   }
   for (i = 0; i < stars.length; ++i) stars[i].snrVis = null;      // (26-oct-2026, A'b: la S/R de una pasada anterior no vale)
   band.sort(function(a, b) { return tileOf(a) - tileOf(b) || stars[a].g - stars[b].g; });
   var yieldOk = (typeof cshYield === "function"), tests = 0;
   try {
      for (var q = 0; q < band.length; ++q) {
         if (yieldOk && (q & 15) === 15) cshYield();
         var k = band[q], st = stars[k], sv = (D._visOf && D._visOf[k] !== undefined) ? D._visOf[k] : null;
         // (sin paralaje —solucion de 2 parametros— no tendra distancia ni con el afinado: no se pinta en 3D; queda como antes,
         // por su magnitud, sin gastar en mirarla)
         if (sv === null && (st.plx === null || st.plx === undefined)) { keep[k] = (D.g50 > 0) ? (st.g <= D.g50) : true; ++D.pruned.untested; continue; }
         if (sv === null && tests < CSH_DEPTH_PRUNE_TEST_MAX) {
            var pxs = cshDepthStarPixel(res, st, tileFn);
            ++tests;
            if (pxs.noData) { keep[k] = false; continue; }             // (en el borde negro de un apilado no hay foto)
            if (!pxs.contaminated) sv = pxs.sv;
         }
         if (sv === null) { keep[k] = (st.g <= gv90); ++D.pruned.untested; continue; }
         // (y frente a SU alrededor, como lo lejano, en las que pasan la vara por poco —hasta SNR_CLEAR: de ahi sale lo «debil»—; con
         // CSH_DEPTH_PRUNE_LOCAL_N aperturas, la mitad que un objeto: son muchas)
         if (locals < CSH_DEPTH_PRUNE_LOCAL_MAX) {
            var lc = cshDepthStarLocal(res, st, sv, tileFn);
            if (lc.local) ++locals;
            if (lc.flip) ++flips;
            sv = lc.sv;
         }
         ++D.pruned.tested;
         keep[k] = (sv >= TV);
         if (keep[k]) { ++D.pruned.detected; if (sv !== Infinity && isFinite(sv)) st.snrVis = sv; }      // (26-oct-2026, A'b) su S/R a ojo, para marcarla «debil»
      }
   } finally { if (C && typeof C.tile === "function") C.tile(null); }
   D.pruned.locals = locals; D.pruned.localFlips = flips;
   var bandOut = 0; for (q = 0; q < band.length; ++q) if (!keep[band[q]]) ++bandOut;
   D.pruned.tests = tests; D.pruned.band = band.length; D.pruned.bandOut = bandOut + safeOut + byCurve; D.pruned.safeOut = safeOut; D.pruned.safeZoneFaint = safeZoneFaint; D.pruned.byCurve = byCurve; D.pruned.ms = Date.now() - t0; D.pruned.vis = true;
   return cshDepthPruneKeep(res, keep);
}

// Fuera las que no se quedan, y los indices de los cumulos (y de las cifras por estrella) al dia.
function cshDepthPruneKeep(res, keep) {
   var D = res.depth, stars = res.stars, i;
   var map = new Array(stars.length), out = [], n = 0;
   for (i = 0; i < stars.length; ++i) {
      if (keep[i]) { map[i] = n++; out.push(stars[i]); }
      else { map[i] = -1; ++D.pruned.stars; if (stars[i].dist) ++D.pruned.withDistance; }
   }
   if (D.pruned.stars === 0) return D.pruned;
   for (var c = 0; res.clusters && c < res.clusters.length; ++c) {
      var mem = res.clusters[c].members || [], nm = [];
      for (i = 0; i < mem.length; ++i) if (map[mem[i]] >= 0) nm.push(map[mem[i]]);
      res.clusters[c].members = nm;
      res.clusters[c].membersInPhoto = nm.length;
   }
   var snrOf = {}, visOf = {}, key;
   if (D._snrOf) for (key in D._snrOf) if (Object.prototype.hasOwnProperty.call(D._snrOf, key) && map[key] >= 0) snrOf[map[key]] = D._snrOf[key];
   if (D._visOf) for (key in D._visOf) if (Object.prototype.hasOwnProperty.call(D._visOf, key) && map[key] >= 0) visOf[map[key]] = D._visOf[key];
   D._snrOf = snrOf;
   if (D._visOf) D._visOf = visOf;
   res.stars = out;
   var inF = 0;
   for (i = 0; i < out.length; ++i) if (out[i].inFrame) ++inF;
   res.gaia.count = out.length; res.gaia.inFrame = inF; res.gaia.prunedByDepth = D.pruned.stars;
   res.distances = cpSfAssignDistances(res.stars, res.clusters);
   return D.pruned;
}

// Lo que el motor llama en cpSfBuildField: medir y quedarse con lo que se ve.
function cshDepthApply(view, res, opts) {
   var D = cshDepthMeasure(view, res, opts);
   if (D.ok) cshDepthPruneStars(res);
   return D;
}

// ---------------------------------------------------------------------------
// 3 · LO LEJANO QUE SE VE (desde cpStarfieldDeepSky, con `out` ya lleno de lo de SIMBAD y colocado)
// ---------------------------------------------------------------------------
function cshDepthPlace(result, ob) {
   var f = result.field;
   ob.inFrame = false; ob.cluster = (ob.cluster === undefined) ? -1 : ob.cluster;
   var p = (typeof result._project === "function") ? result._project(ob.ra, ob.dec) : null;
   if (p !== null) { ob.x = p.x; ob.y = p.y; ob.inFrame = (p.x >= 0 && p.y >= 0 && p.x <= f.width && p.y <= f.height); }
}
// La fuente de Gaia del propio objeto (la mas cercana a menos de `arcsec`), o null: el cuasar en la foto, el nucleo de
// una galaxia... o una ESTRELLA que el catalogo tomo por galaxia.
function cshDepthGaiaTwin(result, ob, arcsec) {
   if (ob.x === null || ob.x === undefined || !(result.field.scaleArcsec > 0)) return null;
   var K = result._depthCtx;
   if (!K) return null;
   if (!K.grid || K.gridN !== result.stars.length) { K.grid = cshDepthGrid(result.stars, Math.max(8, K.P.rAp + 4 * K.fwhm / 2.3548)); K.gridN = result.stars.length; }
   var near = cshDepthNear(K.grid, result.stars, ob.x, ob.y, arcsec / result.field.scaleArcsec), best = null;
   for (var k = 0; k < near.length; ++k) if (best === null || near[k].d < best.d) best = near[k];
   return best ? result.stars[best.i] : null;
}
function cshDepthGaiaG(result, ob) { var s = cshDepthGaiaTwin(result, ob, CSH_DEPTH.MATCH_PT_ARCSEC); return s ? s.g : null; }
// ¿Es una ESTRELLA de la Via Lactea segun Gaia? Paralaje o movimiento propio medidos a 5 veces la cota del error de su
// tramo (y el movimiento, ademas, de mas de 2 mas/año): una galaxia o un cuasar no tienen ni una ni otro. MEDIDO el
// 20-oct-2026 en NGC 1560 (b = +16°): galaxias de GLADE+ (WISExSCOS) con S/R 25 en su sitio eran estrellas de Gaia.
function cshDepthIsGaiaStar(s) {
   if (!s) return false;
   var eP = CP_SF.PLX_ERR_MAX[s.plxTier], eM = CP_SF.PM_ERR_MAX[s.pmTier];
   if (eP > 0 && s.plx !== null && s.plx / eP > CP_SF.MIN_PLX_SNR) return true;
   if (eM > 0 && s.pmRa !== null && s.pmDec !== null) { var pm = Math.sqrt(s.pmRa * s.pmRa + s.pmDec * s.pmDec); if (pm > 5 * eM && pm > 2) return true; }
   return false;
}
// (29-oct-2026 (noche)) Las fuentes de mas y su URL, en UN sitio: las pide cshDepthDeepSky y, a la vez que SIMBAD, cpStarfieldDeepSky (csh_starfield_run.js)
function cshDepthExtraList() { return [["glade", cshGladeAdql, cshGladeObjects, "GLADE+"], ["quaia", cshQuaiaAdql, cshQuaiaObjects, "GaiaDR3"]]; }
function cshDepthExtraUrl(e, f) { return cpSfTapUrl(CP_SF_VIZIER_TAP, e[1](f.ra, f.dec, f.radiusDeg)); }
function cshDepthExtra(result, o, url, parse, col, stage) {
   // (lo que ya se pidio a la vez que SIMBAD —o.prefetch, por URL— no se vuelve a pedir)
   var r = (o.prefetch && o.prefetch[url]) ? o.prefetch[url] : cpSfHttpText(url, { timeoutS: o.httpTimeoutS, onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress(stage, { elapsedMs: ms }); } });
   if (!r.ok) return { ok: false, net: r.net, ms: r.ms, list: [] };
   if (!cpSfLooksLikeCsv(r.text, col)) { var nb = cshNetFail(url, { code: r.code }, false); nb.kind = "bad"; return { ok: false, net: nb, ms: r.ms, list: [] }; }
   // (29-oct-2026, P8) quien contesto: el CDS o un espejo de VizieR (csh_net.js cshVizierGet, la reserva de todas las consultas a VizieR)
   return { ok: true, ms: r.ms, list: parse(r.text), server: r.server || cshNetServer(url), fallback: r.fallback === true };
}
function cshDepthDeepSky(result, out, opts) {
   var o = opts || {}, f = result.field, D = result.depth, i;
   out.hidden = []; out.hiddenBy = {}; out.extra = {}; out.hiddenSimbadOutside = 0;
   // --- mas fuentes: GLADE+ (galaxias y cuasares de SDSS-DR16Q) y Quaia (cuasares de Gaia) ------------------------------
   if (o.extraSources !== false) {
      var add = cshDepthExtraList();
      for (var a = 0; a < add.length; ++a) {
         var url = cshDepthExtraUrl(add[a], f);
         var x = cshDepthExtra(result, o, url, add[a][2], add[a][3], "deepsky");
         var E = { ok: x.ok, rows: x.list.length, added: 0, matched: 0, ms: x.ms, server: x.server || cshNetServer(url), fallback: x.fallback === true };
         if (!x.ok) E.net = x.net;
         else {
            for (i = 0; i < x.list.length; ++i) { if ((i & 127) === 127) if (typeof cshYield === "function") cshYield(); cshDepthPlace(result, x.list[i]); }
            var mg = cshDepthMerge(out.objects, x.list);
            E.added = mg.added; E.matched = mg.matched;
         }
         out.extra[add[a][0]] = E;
      }
   }
   // --- el veredicto de cada uno ---------------------------------------------------------------------------------------
   var keep = [], scale = f.scaleArcsec || 0, yieldOk = (typeof cshYield === "function"), tVerdict = Date.now();
   for (i = 0; i < out.objects.length; ++i) {
      if (yieldOk && (i & 7) === 7) cshYield();
      var ob = out.objects[i];
      if (ob.x === undefined) cshDepthPlace(result, ob);
      if (!ob.mags) ob.mags = {};
      if (ob.cls === "quasar" && !(ob.mags.G > 0)) { var gg = cshDepthGaiaG(result, ob); if (gg !== null) { ob.mags.G = gg; ob.magFromPhotoGaia = true; } }
      // (una «galaxia» o un «cuasar» que en Gaia es una estrella de la Via Lactea no se coloca a su corrimiento al rojo)
      var lone = (ob.cls === "galaxy" || ob.cls === "quasar") && ob.inFrame && !(ob.sizeArcmin > 0.5);
      var twin = lone ? cshDepthGaiaTwin(result, ob, (ob.cls === "quasar") ? CSH_DEPTH.MATCH_PT_ARCSEC : CSH_DEPTH.MATCH_GAL_ARCSEC) : null;
      if (twin && cshDepthIsGaiaStar(twin)) {
         ob.depth = { state: "faint", reason: "gaia-star", g: twin.g, gLo: twin.g, gHi: twin.g, band: "G", sb: null, extended: false, snr: null, hiddenWhy: "gaia-star",
                     twin: { g: twin.g, plx: twin.plx, plxTier: twin.plxTier, pmRa: twin.pmRa, pmDec: twin.pmDec, pmTier: twin.pmTier } };
         out.hiddenBy["gaia-star"] = (out.hiddenBy["gaia-star"] || 0) + 1;
         out.hidden.push(ob);
         continue;
      }
      var v = cshDepthVerdict(ob, D);
      ob.depth = { state: v.state, reason: v.reason, g: v.est ? v.est.g : null, gLo: v.est ? v.est.lo : null, gHi: v.est ? v.est.hi : null, band: v.est ? v.est.band : "",
                   sb: v.sb, extended: v.extended, snr: null };
      var visible = (v.state === "visible" || v.state === "keep");
      if (v.state === "check") {
         var semi = (ob.sizeArcmin > 0 && scale > 0) ? ob.sizeArcmin * 60 / 2 / scale : 0;
         // (apertura: la mitad del semieje si se sabe su tamaño; una galaxia sin tamaño, GAL_AP veces la de una estrella)
         var rObj = v.extended ? 0.5 * semi : (v.galaxy ? CSH_DEPTH.GAL_AP * D.rApPx : 0);
         // (las fuentes de Gaia a menos de esto del centro son el propio objeto, no una vecina: 1,5" un cuasar; una galaxia,
         // MATCH_GAL_ARCSEC o el 30 % de su semieje —sus posiciones de WISE o de placa se separan de la de Gaia un par de ")
         var ignore = (v.galaxy ? Math.max(CSH_DEPTH.MATCH_GAL_ARCSEC / Math.max(scale, 1e-6), 0.3 * semi) : CSH_DEPTH.MATCH_PT_ARCSEC / Math.max(scale, 1e-6));
         // (23-oct-2026: «se ve» = S/R frente al ruido de su zona Y frente al de su alrededor —`cshDepthSeenAt`—, vara SNR_VIS)
         var px = (CSH_DEPTH_VIS_ON === true) ? cshDepthSeenAt(result, ob.x, ob.y, rObj, v.extended ? semi : rObj, ignore, 0) : cshDepthPixelTest(result, ob.x, ob.y, rObj, v.extended ? semi : rObj, ignore);
         var rs = cshDepthResolve(v, px, D);
         visible = rs.visible; ob.depth.reason = rs.reason; ob.depth.snr = px ? px.snr : null; ob.depth.contaminated = px ? px.contaminated : null;
         if (px && px.snrVis !== undefined) { ob.depth.snrVis = px.snrVis; ob.depth.snrLoc = px.snrLoc; }
      }
      if (visible) { keep.push(ob); if (ob.catalog === "GLADE+" && out.extra.glade) out.extra.glade.shown = (out.extra.glade.shown || 0) + 1; if (ob.catalog === "Quaia" && out.extra.quaia) out.extra.quaia.shown = (out.extra.quaia.shown || 0) + 1; continue; }
      var why = (v.state === "outside") ? "outside" : (v.state === "faint") ? v.reason : (ob.depth.reason === "no-data") ? "outside" : ob.depth.reason;
      ob.depth.hiddenWhy = why;
      out.hiddenBy[why] = (out.hiddenBy[why] || 0) + 1;
      if (why === "outside" && !ob.catalog) out.hiddenSimbadOutside = (out.hiddenSimbadOutside || 0) + 1;
      out.hidden.push(ob);
   }
   out.objects = keep;
   out.verdictMs = Date.now() - tVerdict;              // (23-oct-2026: el coste de mirar cada objeto en su sitio, sin la red)
   out.hiddenCount = out.hidden.length;
   out.inFrame = 0; out.withDistance = 0;
   for (i = 0; i < keep.length; ++i) { if (keep[i].inFrame) ++out.inFrame; if (keep[i].dist !== null) ++out.withDistance; }
   // (23-oct-2026) LO QUE NO SE VE pero esta en la foto y tiene distancia: para el interruptor «tambien lo que no se ve en tu
   // foto» (APAGADO de fabrica: `CSH_DEPTH_SHOW_UNSEEN`; `cshDepthShowUnseen`). No las de fuera del encuadre ni las que Gaia
   // dice que son estrellas: esas no son de la foto o no son lo que dice su catalogo.
   out.unseen = [];
   for (i = 0; i < out.hidden.length; ++i) {
      var hu = out.hidden[i], hw = hu.depth ? hu.depth.hiddenWhy : "";
      if (hu.inFrame && hu.dist && hu.dist.pc > 0 && hw !== "outside" && hw !== "gaia-star") out.unseen.push(hu);
   }
   out.unseenShown = false;
   if (CSH_DEPTH_SHOW_UNSEEN === true) cshDepthShowUnseen(result, true);
   return out;
}

// EL INTERRUPTOR «TAMBIEN LO QUE NO SE VE EN TU FOTO» (23-oct-2026; apagado de fabrica). Encendido, lo del catalogo que esta
// en el encuadre con distancia pero no se ve se AÑADE al final de `deepSky.objects` (los indices de lo de antes no cambian)
// con `unseen: true` —el 3D lo pinta hueco y fuera del «mas lejano» y de la escala (ui/starfield_view.js)—; apagado, se
// quita. Las ESTRELLAS que no se ven no vuelven (la poda las saca del campo entero). -> cuantos hay ahora con `unseen`.
var CSH_DEPTH_SHOW_UNSEEN = false;
function cshDepthShowUnseen(result, on) {
   var ds = result ? result.deepSky : null;
   if (!ds || !ds.unseen) return 0;
   var objs = ds.objects || [], keep = [], i;
   for (i = 0; i < objs.length; ++i) if (objs[i].unseen !== true) keep.push(objs[i]);
   if (on === true) for (i = 0; i < ds.unseen.length; ++i) { ds.unseen[i].unseen = true; keep.push(ds.unseen[i]); }
   ds.objects = keep;
   ds.unseenShown = (on === true);
   ds.count = keep.length;
   return (on === true) ? ds.unseen.length : 0;
}
