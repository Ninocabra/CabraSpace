#ifndef __CSH_GALDYN_JS
#define __CSH_GALDYN_JS
// ============================================================================
// CabraShared/csh_galdyn.js — LA DINÁMICA DE LA VÍA LÁCTEA: potencial, estado galactocéntrico y órbitas (23-oct-2026)
// ----------------------------------------------------------------------------
// PURO (sin PixInsight): lo ejecutan node (Cabra3D/tests/c3_gx_cases.js) y PixInsight.
//
// PROCEDENCIA (copiado, no reescrito; los nombres pasan de cc… a csh…, la matemática es la misma línea a línea):
//   · CabraComposition/src/cc_dynamics.js (commit 10d3718): CC_G, CC_POT, CC_KPC_KMS_MYR, ccPotential, ccAcc, ccVcirc,
//     ccDynState, ccOrbit (con CC_ORBIT_DT_MYR, CC_ORBIT_T_MYR).
//   · CabraComposition/src/cc_science.js (commit 10d3718): de CC_SCI las constantes AG, KV, R0_KPC, ZSUN_KPC, VSUN_GC, y
//     ccIcrsVelocity, ccMatVec, ccGalactic, ccUvw.
//   · CabraComposition/src/ui/cc_galaxy.js (fase 2b, 22-oct-2026, árbol de trabajo sin commit): ccGxIntegrate, ccGxAt,
//     ccGxSunState. AÑADIDO aquí: la integración HACIA ATRÁS (el salto de rana es reversible: el mismo integrador con el paso
//     cambiado de signo) y `cshGdAt` con el pasado, para la máquina del tiempo de Cabra3D.
// PENDIENTE (CabraShared/CHANGELOG.md, 23-oct): que CabraComposition use ESTE fichero en vez de sus copias.
//
// EL POTENCIAL (23-oct-2026, tarde, decisión G1 de Nino: UNO SOLO en todo, el mejor): `MilkyWayPotential2022` de gala (v2; ajustado a
// la curva de rotación de Eilers et al. 2019 y a las restricciones de la v1). Especificación: CabraComposition/docs/potencial_g1.md §3
// y §7a; COPIA línea a línea de CabraComposition/src/cc_dynamics.js (CC_POT, CC_MN3_K, ccMn3, ccPotSetup, ccPotential, ccAcc,
// ccDiskDensity, ccBulgeDensity), con los nombres csh…:
//   núcleo  Hernquist  M = 1,8142e9 M⊙, c = 0,0688867 kpc
//   bulbo   Hernquist  M = 5,0e9 M⊙,    c = 1,0 kpc
//   disco   exponencial M = 4,7717e10 M⊙, h_R = 2,6, h_z = 0,3 kpc (sech²), como 3 Miyamoto-Nagai (Smith et al. 2015, tabla de
//           densidad positiva: gala MN3ExponentialDiskPotential, positive_density=True, sech2_z=True)
//   halo    NFW  m = 5,5427e11 M⊙, r_s = 15,626 kpc
//   vc(R0) = 229,404 km/s (cuenta a mano en potencial_g1.md §3). Antes (hasta el 23-oct por la mañana): el MilkyWayPotential de gala v1.
// EL MARCO: el de astropy >= 4.0 (el de CC_SCI): R0 = 8,122 kpc (GRAVITY 2018), z⊙ = 20,8 pc (Bennett & Bovy 2019),
//   v⊙ = (12,9; 245,6; 7,78) km/s (Drimmel & Poggio 2018). El centro galáctico en (0, 0, 0), el Sol en (−R0, 0, z⊙), +X del
//   Sol hacia el centro, +Y hacia l = 90° (el giro), +Z al polo norte. Vista desde el norte, la Galaxia gira como el reloj.
//   (Como en cc_dynamics.js, z⊙ se SUMA sin inclinar el plano. El error NO es de segundo orden —así lo decía este comentario hasta el
//   27-oct—: es LINEAL en la distancia, el ángulo z⊙/R0 = 0,1467° por el camino recorrido: unos 2,6 pc por kpc hacia el centro y
//   0,26 km/s en vz (s·U): en el estado, por debajo de las cifras que se enseñan; en la Zmax de una órbita que pasa junto al centro
//   puede mover la última cifra (HD 140283: 2,531 → 2,565 kpc; esa Zmax ya lleva «≈» en CabraComposition, pericentro < 1 kpc). Medido
//   en la revisión de Codex del 27-oct (scratchpad codex/verif/v_t1_galdyn.log, H-2). NO se cambia la transformación: las cajas de
//   Naidu de cc_dynamics.js —CC_NAIDU_DE, la E de hoy— están ajustadas en ESTE marco, y cambiarlo las movería.)
//
// UN SOLO POTENCIAL EN CABRA3D (23-oct, tarde): la máquina del tiempo EN EL CAMPO («Galactic orbits», Cabra3D/src/tm/galaxy.js)
// usa ESTE (csh_galdyn.js, en kpc; antes MWPotential2014 con R0 = 8 kpc y vc = 220 km/s); su vista galáctica, también.
// ES5 puro.
// ============================================================================

var CSH_GD = {
   // Matriz ICRS -> galácticas (Gaia DR3 documentation, sec. 4.1.7, ec. 4.62; la de Hipparcos 1997 vol. 1 sec. 1.5.3).
   // Filas: hacia el centro galáctico, hacia la rotación, hacia el polo norte galáctico. (= CC_SCI.AG)
   AG: [[-0.0548755604162154, -0.8734370902348850, -0.4838350155487132],
        [ 0.4941094278755837, -0.4448296299600112,  0.7469822444972189],
        [-0.8676661490190047, -0.1980763734312015,  0.4559837761750669]],
   KV: 4.740470463533348,          // km/s por (mas/año · kpc): 1 UA/año en km/s (IAU 2012) (= CC_SCI.KV)
   R0_KPC: 8.122,                  // GRAVITY 2018, el de astropy >= 4.0 (= CC_SCI.R0_KPC)
   ZSUN_KPC: 0.0208,               // Bennett & Bovy 2019 (= CC_SCI.ZSUN_KPC)
   VSUN_GC: [12.9, 245.6, 7.78],   // Drimmel & Poggio 2018 (= CC_SCI.VSUN_GC)
   G: 4.300917270e-6,              // kpc (km/s)² / M⊙ (IAU 2015 / astropy) (= CC_G)
   POT: {                          // gala MilkyWayPotential2022 (= CC_POT de cc_dynamics.js, sin su disk.a/b: un MN del v1 que solo leía el resplandor)
      model: "gala MilkyWayPotential2022 (v2)",
      nucleus: { m: 1.8142e9, c: 0.0688867 },
      bulge:   { m: 5.0e9,    c: 1.0 },
      disk:    { m: 4.7717e10, hR: 2.6, hz: 0.3, mn: null },      // `mn`: sus tres Miyamoto-Nagai (cshGdPotSetup, al cargar)
      halo:    { m: 5.5427e11, rs: 15.626 }
   },
   KPC_KMS_MYR: 977.792221,        // 1 kpc/(km/s) en millones de años (= CC_KPC_KMS_MYR)
   DT_MYR: 0.5,                    // diseño (CabraComposition): paso de 0,5 Myr (= CC_ORBIT_DT_MYR)
   T_MYR: 2000,                    // diseño (CabraComposition): 2 Gyr de órbita para peri, apo y Zmax (= CC_ORBIT_T_MYR)
   // LA VIGILANCIA DE LA ENERGÍA (R2, 27-oct-2026; = CC_ORBIT_DE_TOL, CC_ORBIT_DE_EVERY, CC_ORBIT_MAX_HALVE de cc_dynamics.js):
   DE_TOL: 1e-3,                   // |ΔE/E| máximo admitido a lo largo del camino (el de cc_galaxy_time.js); por encima, el paso se parte
   // (27-oct, noche; C2 H-1 de Codex) en CADA paso: mirando cada 8, el pico del pericentro (dura menos de 8 pasos) no se veía y el
   // `dEmax` devuelto no era el máximo del camino (0,00094 dicho, 0,0207 de verdad; en los datos grabados de CabraComposition, 851 de 5470
   // órbitas). Cuesta un potencial por paso: ×1,6-1,9 de tiempo (antes ~+10 %). Las cifras de la ficha no cambian (0 de 2952 reales a
   // media cifra o más); el «≈» sí donde toca (1 ficha real más). ROJO «sparsede» (la mirada cada 8 pasos de antes).
   DE_EVERY: 1,                    // cada cuántos pasos se mira la energía
   MAX_HALVE: 4                    // divisiones como mucho (0,5 → 0,03125 Myr); si ni así baja de DE_TOL, la órbita sale `approx: true`
};
// DEFECTOS INYECTADOS para ver los controles en ROJO (Cabra3D/tests/c3_gx_cases.js): «kick» (Euler en vez del salto de rana),
// «sun» (el Sol al otro lado del centro), «axes» (X e Y cambiados en el estado), «const» (R0 = 8 kpc en vez de 8,122), «back» (el
// pasado integrado hacia DELANTE: el pasado sería un espejo del futuro). Vacío = nada.
// (27-oct, R2 y R7) «fixdt» (sin partir el paso: el de antes), «oldguard» (la órbita ligada con `E >= 0` falso: un NaN pasaba por
// ligada), «oldinit» (peri, apo y Zmax sin el estado inicial: 1e9 / 0 / 0 de salida), «noround» (lo guardado sin redondear a la cadencia).
// (27-oct, noche) «sparsede» (la energía mirada cada 8 pasos, como antes: se salta el pico del pericentro; c3_gx_cases G20).
// (2-nov, noche) «nobar», «barrec», «barficha» (c3_gx_cases G21), «barfwd» (la barra gira hacia delante también en el pasado; G22) y la
// costura «barsincos», que NO es un defecto (el ángulo con cos/sin en cada paso, para medir lo que gana la recurrencia).
var CSH_GD_BREAK = "";
function cshGdBroken(k) { return (typeof CSH_GD_BREAK === "string") && CSH_GD_BREAK.length > 0 && CSH_GD_BREAK.indexOf(k) >= 0; }
function cshGdIsNum(v) { return typeof v === "number" && isFinite(v); }
function cshGdR0() { return cshGdBroken("const") ? 8.0 : CSH_GD.R0_KPC; }

// LOS TRES MIYAMOTO-NAGAI DEL DISCO EXPONENCIAL (Smith et al. 2015; = CC_MN3_K / ccMn3 de cc_dynamics.js, copiados de gala core.py).
// b/h_R = −0,033 q³ + 0,262 q² + 0,659 q (q = h_z/h_R); (m_i/M, a_i/h_R) = K · [x⁴, x³, x², x, 1] con x = b/h_R. Una masa es negativa y
// suman 1,108 M (así es el ajuste; la densidad total es positiva).
var CSH_GD_MN3_K = [[ 0.0036, -0.0330,  0.1117, -0.1335,  0.1749],
                    [-0.0131,  0.1090, -0.3035,  0.2921, -5.7976],
                    [-0.0048,  0.0454, -0.1425,  0.1012,  6.7120],
                    [-0.0158,  0.0993, -0.2070, -0.7089,  0.6445],
                    [-0.0319,  0.1514, -0.1279, -0.9325,  2.6836],
                    [-0.0326,  0.1816, -0.2943, -0.6329,  2.3193]];
function cshGdMn3(M, hR, hz) {
   var q = hz / hR, bh = -0.033 * q * q * q + 0.262 * q * q + 0.659 * q, xv = [bh * bh * bh * bh, bh * bh * bh, bh * bh, bh, 1], p = [], i, j;
   for (i = 0; i < 6; ++i) { var s = 0; for (j = 0; j < 5; ++j) s += CSH_GD_MN3_K[i][j] * xv[j]; p.push(s); }
   return [{ m: p[0] * M, a: p[3] * hR, b: bh * hR }, { m: p[1] * M, a: p[4] * hR, b: bh * hR }, { m: p[2] * M, a: p[5] * hR, b: bh * hR }];
}
// (Re)hace los tres MN desde CSH_GD.POT.disk (al cargar, abajo; una prueba que cambie m, h_R o h_z la vuelve a llamar).
function cshGdPotSetup() { CSH_GD.POT.disk.mn = cshGdMn3(CSH_GD.POT.disk.m, CSH_GD.POT.disk.hR, CSH_GD.POT.disk.hz); return CSH_GD.POT; }
// Potencial (km²/s²) en (x, y, z) kpc.
function cshGdPotential(x, y, z) {
   var P = CSH_GD.POT, G = CSH_GD.G, R2 = x * x + y * y, r = Math.sqrt(R2 + z * z), D = P.disk.mn || cshGdPotSetup().disk.mn;
   var phi = -G * P.nucleus.m / (r + P.nucleus.c) - G * P.bulge.m / (r + P.bulge.c);
   var beta = Math.sqrt(z * z + D[0].b * D[0].b);      // (los tres MN comparten b)
   for (var i = 0; i < 3; ++i) { var s = D[i].a + beta; phi += -G * D[i].m / Math.sqrt(R2 + s * s); }
   phi += (r > 1e-9) ? -G * P.halo.m * Math.log(1 + r / P.halo.rs) / r : -G * P.halo.m / P.halo.rs;
   return phi;
}
// Aceleración (km/s)²/kpc.
function cshGdAcc(x, y, z, out) {
   var P = CSH_GD.POT, G = CSH_GD.G, R2 = x * x + y * y, r2 = R2 + z * z, r = Math.sqrt(r2), D = P.disk.mn || cshGdPotSetup().disk.mn;
   var a = 0;
   if (r > 1e-9) {
      a += G * P.nucleus.m / ((r + P.nucleus.c) * (r + P.nucleus.c));
      a += G * P.bulge.m / ((r + P.bulge.c) * (r + P.bulge.c));
      var A = G * P.halo.m, rs = P.halo.rs;
      a += A * (Math.log(1 + r / rs) / r2 - 1 / (r * (rs + r)));
      a /= r;      // a(r)/r para multiplicar por (x, y, z)
   }
   var beta = Math.sqrt(z * z + D[0].b * D[0].b), fR = 0, fz = 0;
   for (var i = 0; i < 3; ++i) { var s = D[i].a + beta, D2 = R2 + s * s, k = G * D[i].m / (D2 * Math.sqrt(D2)); fR += k; fz += k * s; }
   out[0] = -a * x - fR * x;
   out[1] = -a * y - fR * y;
   out[2] = -a * z - fz * z / beta;
   return out;
}
// LA BARRA (2-nov-2026, decisión 4 de Nino; Cabra3D/docs/investigacion_orbitas_largo_plazo.md §3.2 y §5 #6): el cuadrupolo de Dehnen
// (2000, AJ 119, 800) en la convención de galpy `DehnenBarPotential` (contra galpy 1.12: fuerzas a 2,6e-7 relativo, Cabra3D/docs/
// investigacion_orbitas/ref_forces.log). Φ_b = A_f cos(2(φ − Ω_b t − φ_b)) (R/r)² · {−(r_b/r)³ fuera, (r/r_b)³ − 2 dentro}, con
// A_f = α v0²/3 · (R0/r_b)³ y r_b = 0,8 v0/Ω_b (corrotación a 1/0,8 del radio de la barra). Parámetros: Ω_b 37 km/s/kpc (centro de
// 33–41: Clarke y Gerhard 2022, Portail et al. 2017, Sanders et al. 2019), φ_b 25° (el ángulo con la línea Sol-centro), α 0,01 (la
// fuerza en el Sol; poco conocida: NO VERIFICADO mejor que «0,01 ± ~50 %»). v0 = vc(R0) de este potencial.
// El marco: el de este fichero (el Sol en x = −R0); galpy pone el Sol en +R0 → x_galpy = −x. t en Ma desde HOY.
// (2-nov-2026, tarde: decisión de Nino «si no frena la visualización, que entre»; medido en la interfaz: la tabla de la máquina del tiempo
//  con barra cuesta lo mismo dentro del ruido y el arrastre no cambia) ON = true.
// (2-nov-2026, noche: decisión Q2b = B de Nino) LA BARRA SOLO EN LO QUE SE DIBUJA: las trayectorias (cshGdIntegrate: el mapa de la Galaxia,
//  su pasado y la Galaxia en el tiempo), su copia de CabraComposition (ui/cc_galaxy.js ccGxIntegrate) y la máquina del tiempo (Cabra3D
//  tm/galaxy.js). LA FICHA NO (cshGdOrbit y ccOrbit: peri, apo, Zmax, e) ni las familias ni las comprobaciones contra la literatura: siguen en
//  el potencial sin barra, el de McMillan, Naidu et al. 2020 y las demás referencias (con la barra, HD 140283 daba Zmax 4,4 kpc frente a
//  2,26 ± 0,5 de la literatura, y el análisis de CabraComposition costaba ×1,6–1,8). El rótulo de las órbitas lo dice (csh_galaxy_i18n.js
//  gxFootOrbitBar). En lo dibujado se conserva la energía de Jacobi E_J = E + Φ_b − Ω_b·L_z (la barra gira), no E: la vigilancia del paso
//  la mira a ella. ROJO: ON = false (Cabra3D/tests/c3_gx_cases.js G21, C3_MUTATE=gxnobar).
CSH_GD.BAR = { ON: true, OB: 37, PHIB_DEG: 25, ALPHA: 0.01, ref: "Dehnen 2000 quadrupole (galpy DehnenBarPotential)" };
var CSH_GD_BAR_K = null;
function cshGdBarOn() { return !!(CSH_GD.BAR && CSH_GD.BAR.ON === true) && !cshGdBroken("nobar"); }      // (ROJO «nobar»: c3_gx_cases G21)
function cshGdBarSetup() {
   var B = CSH_GD.BAR, v0 = cshGdVcirc(CSH_GD.R0_KPC), rb = 0.8 * v0 / B.OB;
   CSH_GD_BAR_K = { ob: B.OB, al: B.ALPHA, ph: B.PHIB_DEG, rb: rb, Af: B.ALPHA * v0 * v0 / 3 * Math.pow(CSH_GD.R0_KPC / rb, 3), w: B.OB / CSH_GD.KPC_KMS_MYR, phib: B.PHIB_DEG * Math.PI / 180 };
   return CSH_GD_BAR_K;
}
// (2-nov, tarde) la comprobación de que no han cambiado los parámetros, con números y no con una cadena (se llama en cada paso). Medido en
// node: sin cambio apreciable (HD 140283, 2 Ga a 0,5 Ma: 1,8 ms con barra y 1,0–1,1 sin ella, antes y después); se queda por no crear una
// cadena en cada paso. Lo que cuesta la barra es su fuerza y su ángulo en cada paso, no esto.
function cshGdBarK() { var B = CSH_GD.BAR, K = CSH_GD_BAR_K; return (K && K.ob === B.OB && K.al === B.ALPHA && K.ph === B.PHIB_DEG) ? K : cshGdBarSetup(); }
// [cos, sin] del ángulo de la barra en t Ma (para calcularlo una vez por paso y no por estrella)
function cshGdBarAngle(tMyr, out) { var K = cshGdBarK(), th = K.phib + K.w * tMyr; out[0] = Math.cos(th); out[1] = Math.sin(th); return out; }
// SUMA a out la aceleración de la barra ((km/s)²/kpc) en (x, y, z) kpc con el ángulo dado por c = cos, s = sin
function cshGdBarAdd(x, y, z, c, s, out) {
   var K = cshGdBarK(), xg = -x, yg = y, xp = xg * c + yg * s, yp = -xg * s + yg * c, r2 = xg * xg + yg * yg + z * z, r = Math.sqrt(r2), rb = K.rb, h, hp;
   if (r > rb) { var rb3 = rb * rb * rb, r5 = r2 * r2 * r; h = -rb3 / r5; hp = 5 * rb3 / (r5 * r); }
   else { var rb3i = 1 / (rb * rb * rb); h = r * rb3i - 2 / r2; hp = rb3i + 4 / (r2 * r); }
   var q = xp * xp - yp * yp, Af = K.Af, k = q * hp / r;
   var dxp = Af * (2 * xp * h + k * xp), dyp = Af * (-2 * yp * h + k * yp), dz = Af * k * z;
   var dxg = dxp * c - dyp * s, dyg = dxp * s + dyp * c;
   out[0] += dxg; out[1] -= dyg; out[2] -= dz;
   return out;
}
// Su potencial (km²/s²) en (x, y, z) kpc con el ángulo dado (c = cos, s = sin)
function cshGdBarPhiCS(x, y, z, c, s) {
   var K = cshGdBarK(), xg = -x, yg = y, xp = xg * c + yg * s, yp = -xg * s + yg * c, r2 = xg * xg + yg * yg + z * z, r = Math.sqrt(r2), rb = K.rb;
   var h = (r > rb) ? -rb * rb * rb / (r2 * r2 * r) : r / (rb * rb * rb) - 2 / r2;
   return K.Af * (xp * xp - yp * yp) * h;
}
// LA ENERGÍA DE JACOBI (km²/s²): E + Φ_b − w·L_z, con L_z prógrado > 0 (= −(x vy − y vx), el de cshGdState) y w la velocidad de giro de la
// barra EN EL TIEMPO DE LA INTEGRACIÓN (km/s/kpc): Ω_b, o −Ω_b si el pasado se integra hacia delante con la velocidad invertida.
function cshGdJacobi(x, y, z, vx, vy, vz, c, s, w) {
   return 0.5 * (vx * vx + vy * vy + vz * vz) + cshGdPotential(x, y, z) + cshGdBarPhiCS(x, y, z, c, s) + w * (x * vy - y * vx);
}
// Su potencial (km²/s²) en (x, y, z) kpc y t Ma
function cshGdBarPhi(x, y, z, tMyr) {
   var K = cshGdBarK(), A = cshGdBarAngle(tMyr, [0, 0]), xg = -x, yg = y, xp = xg * A[0] + yg * A[1], yp = -xg * A[1] + yg * A[0], r2 = xg * xg + yg * yg + z * z, r = Math.sqrt(r2), rb = K.rb;
   var h = (r > rb) ? -rb * rb * rb / (r2 * r2 * r) : r / (rb * rb * rb) - 2 / r2;
   return K.Af * (xp * xp - yp * yp) * h;
}
// Densidades del potencial (M⊙/kpc³), para dibujar la Vía Láctea con la MISMA masa que mueve las órbitas (= ccDiskDensity, ccBulgeDensity)
function cshGdDiskDensity(R, z) {
   var D = CSH_GD.POT.disk.mn || cshGdPotSetup().disk.mn, rho = 0;
   for (var i = 0; i < 3; ++i) {
      var a = D[i].a, b = D[i].b, B = Math.sqrt(z * z + b * b), aB = a + B;
      rho += b * b * D[i].m / (4 * Math.PI) * (a * R * R + (a + 3 * B) * aB * aB) / (Math.pow(R * R + aB * aB, 2.5) * B * B * B);
   }
   return rho;
}
function cshGdHaloDensity(r) {
   var H = CSH_GD.POT.halo, x = Math.max(r, 1e-3) / H.rs;
   return H.m / (4 * Math.PI * H.rs * H.rs * H.rs) / (x * (1 + x) * (1 + x));
}
// La densidad TOTAL (disco + bulbo + núcleo + halo) en (R, z) kpc, M⊙/kpc³ (la local, para los epiciclos de Cabra3D: tm/timemachine.js)
function cshGdDensity(R, z) { var r = Math.sqrt(R * R + z * z); return cshGdDiskDensity(R, z) + cshGdBulgeDensity(r) + cshGdHaloDensity(r); }
function cshGdBulgeDensity(r) {
   var P = CSH_GD.POT; r = Math.max(r, 1e-3);
   return P.bulge.m * P.bulge.c / (2 * Math.PI * r * Math.pow(r + P.bulge.c, 3)) + P.nucleus.m * P.nucleus.c / (2 * Math.PI * r * Math.pow(r + P.nucleus.c, 3));
}
// Velocidad circular en el plano (km/s) a radio R (kpc).
function cshGdVcirc(R) {
   var o = [0, 0, 0];
   cshGdAcc(R, 0, 0, o);
   return Math.sqrt(Math.max(0, -o[0] * R));
}

// ---------------------------------------------------------------------------
// DE LA ASTROMETRÍA AL ESTADO GALACTOCÉNTRICO
// ---------------------------------------------------------------------------
function cshGdMatVec(M, v) {
   return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2],
           M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2],
           M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]];
}
// (ra, dec en grados; d en pc; pm en mas/año; rv en km/s) -> velocidad ICRS cartesiana (km/s).
function cshGdIcrsVelocity(ra, dec, dPc, pmra, pmdec, rv) {
   var a = ra * Math.PI / 180, d = dec * Math.PI / 180;
   var ca = Math.cos(a), sa = Math.sin(a), cd = Math.cos(d), sd = Math.sin(d);
   var k = CSH_GD.KV * dPc / 1000;
   var vt1 = k * pmra, vt2 = k * pmdec;
   return [rv * cd * ca - vt1 * sa - vt2 * sd * ca,
           rv * cd * sa + vt1 * ca - vt2 * sd * sa,
           rv * sd + vt2 * cd];
}
// Galácticas (l, b) en grados y el vector unitario.
function cshGdGalactic(ra, dec) {
   var a = ra * Math.PI / 180, d = dec * Math.PI / 180;
   var r = cshGdMatVec(CSH_GD.AG, [Math.cos(d) * Math.cos(a), Math.cos(d) * Math.sin(a), Math.sin(d)]);
   var l = Math.atan2(r[1], r[0]) * 180 / Math.PI;
   if (l < 0) l += 360;
   return { l: l, b: Math.asin(Math.max(-1, Math.min(1, r[2]))) * 180 / Math.PI, xyz: r };
}
// UVW HELIOCÉNTRICAS (U hacia el centro galáctico, V hacia la rotación, W al polo norte), km/s.
function cshGdUvw(ra, dec, dPc, pmra, pmdec, rv) {
   return cshGdMatVec(CSH_GD.AG, cshGdIcrsVelocity(ra, dec, dPc, pmra, pmdec, rv));
}
// EL ESTADO DINÁMICO (= ccDynState). Devuelve { x, y, z (kpc), vx, vy, vz (km/s), r, v, E, Lz (prógrado > 0), Lx, Ly, Lperp, eta,
// LzN, LyN (convención de Naidu: prógrado < 0) }.
function cshGdState(ra, dec, dPc, pmra, pmdec, rv) {
   var g = cshGdGalactic(ra, dec), dk = dPc / 1000, R0 = cshGdR0();
   var x = g.xyz[0] * dk - R0, y = g.xyz[1] * dk, z = g.xyz[2] * dk + CSH_GD.ZSUN_KPC;
   var uvw = cshGdUvw(ra, dec, dPc, pmra, pmdec, rv);
   var vx = uvw[0] + CSH_GD.VSUN_GC[0], vy = uvw[1] + CSH_GD.VSUN_GC[1], vz = uvw[2] + CSH_GD.VSUN_GC[2];
   if (cshGdBroken("axes")) { var t = x; x = y; y = t; t = vx; vx = vy; vy = t; }      // (ROJO «axes»)
   var Lx = y * vz - z * vy, Ly = z * vx - x * vz, LzA = x * vy - y * vx;     // momento angular de astropy (prógrado < 0)
   var r = Math.sqrt(x * x + y * y + z * z), v = Math.sqrt(vx * vx + vy * vy + vz * vz);
   var E = 0.5 * v * v + cshGdPotential(x, y, z);
   var Lz = -LzA;
   return { x: x, y: y, z: z, vx: vx, vy: vy, vz: vz, r: r, v: v, E: E, Lz: Lz, Lx: Lx, Ly: Ly, Lperp: Math.sqrt(Lx * Lx + Ly * Ly),
            eta: (r * v > 0) ? Lz / (r * v) : 0, LzN: LzA, LyN: Ly };
}
// EL SOL: su estado en el mismo marco (lo de cshGdState a distancia cero).
function cshGdSunState() {
   var R0 = cshGdR0(), z0 = CSH_GD.ZSUN_KPC, V = CSH_GD.VSUN_GC;
   var x = cshGdBroken("sun") ? R0 : -R0;          // (ROJO «sun»: el Sol al otro lado del centro)
   var st = { x: x, y: 0, z: z0, vx: V[0], vy: V[1], vz: V[2] };
   st.E = 0.5 * (V[0] * V[0] + V[1] * V[1] + V[2] * V[2]) + cshGdPotential(st.x, st.y, st.z);
   return st;
}

// ---------------------------------------------------------------------------
// LAS ÓRBITAS: salto de rana (kick-drift-kick), simpléctico y reversible, con el paso PARTIDO si la energía se va (R2, 27-oct-2026)
// ---------------------------------------------------------------------------
// POR QUÉ SE PARTE EL PASO (revisión de Codex del 27-oct, verificada contra este código): con el paso fijo de 0,5 Myr, una órbita de
// halo que pasa a < 0,5 kpc del centro no resuelve el pericentro (r/v ≈ 0,6 Myr) y el salto de rana la DESVÍA a otra órbita: el
// apocentro y la e salían falsos en 35 de 400 estrellas de un halo sintético (hasta un +670 %); con 1,0 Myr (el Monte Carlo de
// CabraComposition), HD 140283 da el apocentro un 3,35 % alto. Nadie miraba ΔE. Ahora: cada DE_EVERY pasos se mira |ΔE/E| y, si
// pasa de DE_TOL (también al final), se vuelve a empezar con la MITAD de paso, hasta MAX_HALVE veces (como ccGxtBack de
// CabraComposition/src/ui/cc_galaxy_time.js). Si ni así baja, el resultado (el del paso más fino) sale `approx: true` y la ficha pone
// «≈». Se mira el MÁXIMO a lo largo del camino y no solo el final: el final puede volver cerca de E después de haberse desviado.
// MEDIDO (scratchpad r2/proto.js, 27-oct): halo sintético 2 Gyr / 0,5 Myr: las 35 vigiladas, apocentro y e bien en todas (las que
// siguen distintas de la referencia lo son solo en Zmax, y la propia referencia a 0,02 y a 0,005 Myr discrepa: órbitas caóticas que
// cruzan el núcleo); 0,66 divisiones de media, 4 approx de 400, ×2,6 de tiempo. Un campo de disco: ×1,00; el campo al azar de
// c3_gx_cases: 9 de 267 se parten, ×1,09. La estrella de baja L (−8, 0, 0) kpc, (250, 10, 0) km/s: apo 14,906 kpc (antes 14,447).
// (Esas cifras de tiempo son con la mirada cada 8 pasos; desde el 27-oct por la noche se mira en CADA paso —DE_EVERY 1, C2 H-1 de Codex—:
//  ×1,6-1,9 más. Medido en scratchpad verifc/c2_real.js, c2_sweep.js, c2_cost.js: las cifras de la ficha no cambian en 2952 órbitas reales
//  ni en 967 de un halo sintético; el «≈» aparece en 1 ficha real más y en 11 del halo, las que de verdad pasan de DE_TOL en el pericentro.)
// Una pasada con el paso dtM (dir sgn): n pasos, guarda m puntos (cada ev pasos; el 0 es hoy) y mira la energía. Con `abort`, en
// cuanto |ΔE/E| pasa de DE_TOL devuelve null (para partir el paso sin terminar la pasada).
// (2-nov-2026) LA BARRA (CSH_GD.BAR.ON y `withBar === true`: solo lo dibujado, ver arriba): su ángulo va con el tiempo de cada paso —el
// instante del final del «drift», donde se calcula la fuerza—, t = tsg·dtM·(i + 1) Ma. «tsign» (opcional) es el sentido del tiempo de la
// BARRA: por defecto el de la integración (sgn: hacia atrás con el paso negativo, la barra gira hacia atrás); −1 con sgn = +1 para un pasado
// integrado hacia delante con la velocidad invertida (como CabraComposition). La vigilancia mira la energía de Jacobi con w = Ω_b·tsg·sgn.
// (2-nov, noche: Q2b) el ángulo avanza por RECURRENCIA —un giro fijo de Ω_b·tsg·dtM por paso: dos productos y dos sumas— en vez de un
// coseno y un seno en cada paso; mismo ángulo a ~1e-12 en 64 000 pasos (c3_gx_cases G21e lo compara con la pasada de cos/sin). ROJO de
// la recurrencia: CSH_GD_BREAK «barrec» (gira el doble).
// (2-nov, noche: la reversibilidad) «t0Myr» (opcional, 0 = hoy): el instante FÍSICO del estado de partida; el ángulo de la barra arranca en
// φ_b + Ω_b·t0. Todo lo de la aplicación parte de hoy (0); hace falta para VOLVER: ir −T y volver +T desde el estado de −T solo devuelve el
// de hoy si la vuelta arranca la barra en −T (medido en c3_gx_cases G22b: con t0 = −T, 1e-12–1e-7 pc, lo mismo que sin barra; con el
// ángulo de hoy, 160–2500 pc). Devuelve además `end` = [x, y, z, vx, vy, vz] (el estado final en doble precisión).
// COSTURAS: «barfwd» (ROJO: la barra gira hacia DELANTE también en el pasado; c3_gx_cases G22) y «barsincos» (NO es un defecto: el ángulo
// con cos/sin en cada paso en vez de la recurrencia, para medir lo que gana; mismo resultado a ~1e-12).
function cshGdLeap(st, n, dtM, sgn, ev, m, abort, tsign, withBar, t0Myr) {
   var bar = (withBar === true) && cshGdBarOn(), tsg = (tsign === 1 || tsign === -1) ? tsign : sgn, t0 = cshGdIsNum(t0Myr) ? t0Myr : 0, rec = !cshGdBroken("barsincos");
   if (tsg === -1 && cshGdBroken("barfwd")) tsg = 1;      // (ROJO «barfwd»)
   var cs = [1, 0], w = bar ? CSH_GD.BAR.OB * tsg * sgn : 0, cd = 1, sd = 0;
   if (bar) { cshGdBarAngle(t0, cs); var dth = cshGdBarK().w * tsg * dtM * (cshGdBroken("barrec") ? 2 : 1); cd = Math.cos(dth); sd = Math.sin(dth); }
   var E0 = bar ? cshGdJacobi(st.x, st.y, st.z, st.vx, st.vy, st.vz, cs[0], cs[1], w) : st.E;
   var dt = sgn * dtM / CSH_GD.KPC_KMS_MYR, tol = CSH_GD.DE_TOL, de = cshGdBroken("sparsede") ? 8 : CSH_GD.DE_EVERY, aE = Math.abs(E0);
   var X = m ? new Float32Array(m) : null, Y = m ? new Float32Array(m) : null, Z = m ? new Float32Array(m) : null;
   var x = st.x, y = st.y, z = st.z, vx = st.vx, vy = st.vy, vz = st.vz, a = [0, 0, 0], k = 0, r0 = Math.sqrt(x * x + y * y + z * z);
   // (R7: peri, apo y Zmax empiezan con el estado INICIAL —antes 1e9 / 0 / 0: un tramo corto daba peri 1e9 y e −1—; ROJO «oldinit»)
   var old = cshGdBroken("oldinit"), rmin = old ? 1e9 : r0, rmax = old ? 0 : r0, zmax = old ? 0 : Math.abs(z), dEmax = 0, euler = cshGdBroken("kick");
   if (m) { X[0] = x; Y[0] = y; Z[0] = z; k = 1; }
   cshGdAcc(x, y, z, a);
   if (bar) cshGdBarAdd(x, y, z, cs[0], cs[1], a);
   for (var i = 0; i < n; ++i) {
      if (bar) { if (rec) { var c1 = cs[0] * cd - cs[1] * sd; cs[1] = cs[1] * cd + cs[0] * sd; cs[0] = c1; } else cshGdBarAngle(t0 + tsg * dtM * (i + 1), cs); }
      if (euler) {
         // (ROJO «kick»: Euler explícito, de primer orden y no simpléctico: la energía se va)
         x += dt * vx; y += dt * vy; z += dt * vz;
         vx += dt * a[0]; vy += dt * a[1]; vz += dt * a[2];
         cshGdAcc(x, y, z, a);
         if (bar) cshGdBarAdd(x, y, z, cs[0], cs[1], a);
      } else {
         vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
         x += dt * vx; y += dt * vy; z += dt * vz;
         cshGdAcc(x, y, z, a);
         if (bar) cshGdBarAdd(x, y, z, cs[0], cs[1], a);
         vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
      }
      var r = Math.sqrt(x * x + y * y + z * z);
      if (r < rmin) rmin = r;
      if (r > rmax) rmax = r;
      if (Math.abs(z) > zmax) zmax = Math.abs(z);
      if (m && (i + 1) % ev === 0 && k < m) { X[k] = x; Y[k] = y; Z[k] = z; ++k; }
      if ((i + 1) % de === 0) {
         var dEi = Math.abs((bar ? cshGdJacobi(x, y, z, vx, vy, vz, cs[0], cs[1], w) : 0.5 * (vx * vx + vy * vy + vz * vz) + cshGdPotential(x, y, z)) - E0) / aE;
         if (dEi > dEmax) { dEmax = dEi; if (abort && dEmax > tol) return null; }
      }
   }
   var dE = ((bar ? cshGdJacobi(x, y, z, vx, vy, vz, cs[0], cs[1], w) : 0.5 * (vx * vx + vy * vy + vz * vz) + cshGdPotential(x, y, z)) - E0) / aE;
   if (Math.abs(dE) > dEmax) dEmax = Math.abs(dE);
   if (abort && dEmax > tol) return null;
   return { n: k, x: X, y: Y, z: Z, rperi: rmin, rapo: rmax, zmax: zmax, ecc: (rmax + rmin > 0) ? (rmax - rmin) / (rmax + rmin) : 0, dE: dE, dEmax: dEmax, end: [x, y, z, vx, vy, vz] };
}
// n pasos de dtM (los de diseño) partidos lo que haga falta: a la h-ésima división, n·2^h pasos de dtM/2^h, guardando cada ev·2^h
// pasos (los MISMOS instantes: lo guardado sigue a dtM·ev, que es lo que interpola cshGdAt). Devuelve lo de cshGdLeap y además
// { halvings, dtUsed (el paso que quedó, Myr), approx (|ΔE/E| máx. > DE_TOL aun con el paso más fino) }.
function cshGdLeapSafe(st, n, dtM, sgn, ev, keep, tsign, withBar, t0Myr) {
   var maxH = cshGdBroken("fixdt") ? 0 : CSH_GD.MAX_HALVE, m = keep ? Math.floor(n / ev) + 1 : 0, o = null, h = 0, k = 1;
   for (h = 0; h <= maxH; ++h) {
      k = Math.pow(2, h);
      o = cshGdLeap(st, n * k, dtM / k, sgn, ev * k, m, h < maxH, tsign, withBar, t0Myr);
      if (o) break;
   }
   o.halvings = Math.min(h, maxH); o.dtUsed = dtM / k; o.approx = !(o.dEmax <= CSH_GD.DE_TOL);
   return o;
}
// (R7: una órbita es ligada solo si E < 0 de verdad; con `E >= 0` un NaN —rv sin dato— pasaba por ligada; ROJO «oldguard»)
function cshGdBoundE(E) { return cshGdBroken("oldguard") ? !(E >= 0) : (E < 0); }
// LA ÓRBITA RESUMIDA (= ccOrbit): { rperi, rapo, zmax, ecc, bound, dE (el final), dEmax, approx, halvings, dtMyr (el paso usado) }.
// (2-nov, noche: Q2b) la de la FICHA: SIN la barra (las cifras comparables con la literatura y con CabraComposition; ver CSH_GD.BAR).
function cshGdOrbit(s, tMyr, dtMyr) {
   var dtM = dtMyr || CSH_GD.DT_MYR, n = Math.round((tMyr || CSH_GD.T_MYR) / dtM);
   if (!cshGdBoundE(s.E)) return { rperi: null, rapo: null, zmax: null, ecc: 1, bound: false, dE: 0, dEmax: 0, approx: false, halvings: 0, dtMyr: dtM };
   var o = cshGdLeapSafe(s, n, dtM, 1, 1, false, undefined, cshGdBroken("barficha"));      // (ROJO «barficha»: la ficha con la barra, lo del 2-nov por la tarde)
   return { rperi: o.rperi, rapo: o.rapo, zmax: o.zmax, ecc: o.ecc, bound: true, dE: o.dE, dEmax: o.dEmax, approx: o.approx, halvings: o.halvings, dtMyr: o.dtUsed };
}
// LA TRAYECTORIA GUARDADA (= ccGxIntegrate, con el sentido del tiempo): st = { x, y, z, vx, vy, vz, E }; `dir` = +1 (futuro, de
// fábrica) o −1 (pasado: el mismo integrador con el paso negativo). Devuelve
//   { n, dtMyr (entre puntos guardados, POSITIVO), dir, x, y, z (Float32Array; el 0 es hoy), rperi, rapo, zmax, ecc, dE, dEmax, approx,
//     halvings, dtUsed, bound, tMyr (lo integrado DE VERDAD) }
// Peri, apo y Zmax se miden en CADA paso (no solo en los guardados): hacia el futuro, con 2 Gyr y SIN la barra salen EXACTAMENTE los de
// cshGdOrbit (el mismo paso partido las mismas veces); con la barra (2-nov, Q2b: lo dibujado la lleva) son los de la órbita barrada, que
// solo sirven para escoger qué se dibuja: la ficha es cshGdOrbit. Si el paso se parte, lo guardado sigue cada dtMyr (los mismos instantes).
// `keep === false`: sin puntos (solo las medidas).
// (R7, 27-oct) Con puntos, los pasos se redondean a un múltiplo de `every`: antes el tramo final que no llenaba un punto guardado se
// integraba y no se guardaba, y cshGdAt daba como último instante uno que no era el pedido. `tMyr` devuelve lo integrado.
// «tsign» (opcional, 2-nov): el sentido del tiempo de la barra (ver cshGdLeap); −1 con dir = +1 y la velocidad invertida = el pasado.
// «t0Myr» (opcional, 2-nov, noche): el instante del estado de partida (0 = hoy; ver cshGdLeap). `end`: el estado final en doble.
function cshGdIntegrate(st, tMyr, dtMyr, every, keep, dir, tsign, t0Myr) {
   var dtM = dtMyr || CSH_GD.DT_MYR, T = tMyr || CSH_GD.T_MYR, ev = every || 4, sgn = (dir === -1 && !cshGdBroken("back")) ? -1 : 1;
   var n = Math.round(T / dtM);
   if (keep !== false && !cshGdBroken("noround")) n = Math.round(n / ev) * ev;
   if (!cshGdBoundE(st.E)) return { n: 0, dtMyr: dtM * ev, dir: sgn, x: null, y: null, z: null, rperi: null, rapo: null, zmax: null, ecc: 1, dE: 0, dEmax: 0, approx: false, halvings: 0, dtUsed: dtM, bound: false, tMyr: n * dtM };
   var o = cshGdLeapSafe(st, n, dtM, sgn, ev, keep !== false, tsign, true, t0Myr);
   return { n: o.n, dtMyr: dtM * ev, dir: sgn, x: o.x, y: o.y, z: o.z, rperi: o.rperi, rapo: o.rapo, zmax: o.zmax, ecc: o.ecc,
            dE: o.dE, dEmax: o.dEmax, approx: o.approx, halvings: o.halvings, dtUsed: o.dtUsed, bound: true, tMyr: n * dtM, end: o.end };
}
// LA TRAYECTORIA EN LOS DOS SENTIDOS: el futuro (fwdMyr; sus medidas son las de la ficha) y, si backMyr > 0, el pasado en `.back`.
function cshGdTrajectory(st, fwdMyr, backMyr, dtMyr, every) {
   var tr = cshGdIntegrate(st, fwdMyr || CSH_GD.T_MYR, dtMyr, every, true, 1);
   if (tr.bound && backMyr > 0) tr.back = cshGdIntegrate(st, backMyr, dtMyr, every, true, -1);
   return tr;
}
// LA POSICIÓN a tMyr de hoy (negativo = el pasado, en `tr.back`), lineal entre puntos guardados. Más allá del final: con
// `wrap` vuelve a empezar (solo para un vídeo que no se quede quieto: NO es periódica); sin `wrap`, el último punto.
// Sin pasado guardado, un instante negativo da hoy. Devuelve `out` ([x, y, z] kpc) o null sin trayectoria.
function cshGdAt(tr, tMyr, out, wrap) {
   out = out || [0, 0, 0];
   if (!tr || !tr.n) return null;
   var T = tr, t = cshGdIsNum(tMyr) ? tMyr : 0;
   if (t < 0) { if (tr.back && tr.back.n) { T = tr.back; t = -t; } else t = 0; }
   var f = t / T.dtMyr, last = T.n - 1;
   if (last <= 0) { out[0] = T.x[0]; out[1] = T.y[0]; out[2] = T.z[0]; return out; }
   if (f >= last) f = wrap ? f % last : last;
   var i = Math.floor(f), u = f - i, j = Math.min(last, i + 1);
   out[0] = T.x[i] + (T.x[j] - T.x[i]) * u; out[1] = T.y[i] + (T.y[j] - T.y[i]) * u; out[2] = T.z[i] + (T.z[j] - T.z[i]) * u;
   return out;
}
// El índice (fraccionario) del punto guardado de un instante, en su sentido: { T (la tabla), f } (para trazar estelas).
function cshGdIndexAt(tr, tMyr) {
   if (!tr || !tr.n) return null;
   var t = cshGdIsNum(tMyr) ? tMyr : 0, T = tr;
   if (t < 0) { if (!(tr.back && tr.back.n)) return { T: tr, f: 0 }; T = tr.back; t = -t; }
   return { T: T, f: Math.min(T.n - 1, t / T.dtMyr) };
}
cshGdPotSetup();
#endif
