// ============================================================================
// CabraShared/csh_mainseq.js — LA SECUENCIA DE MAMAJEK, DE GAIA DR2 A DR3: UNA SOLA CONVERSION (28-oct-2026, tarde)
// ----------------------------------------------------------------------------
// Decision de Nino (28-oct, E3): una sola conversion DR2 -> DR3, aqui, y que el DIBUJO y el ANALISIS de todos los scripts
// salgan de ella. Antes habia tres: CabraStars/lib/cs_astro.js (analisis, `csMsDr3Offset`), Cabra3D/src/tm/dust_run.js
// (`c3DustDr3Offset`, el color intrinseco) y ninguna en el dibujo (la linea discontinua del HR seguia en DR2: 1-1,6 px).
// Usuarios hoy: Cabra3D (el color intrinseco del polvo), CabraStars (`csMsTable` en lib/cs_astro.js; la linea del HR y las letras espectrales por
// `cpStarfieldMainSequenceDr3`, CabraShared/csh_starfield_run.js) y CabraStarAnalysis (incluye los mismos ficheros).
// Cabra3D (28-oct, tarde): `c3DustIntrinsic` (src/tm/dust_run.js) llama a `cshMsDr3Colour`; Cabra3D.js lo incluye despues de csh_dust.js. Ya no tiene
// tabla propia (era C3_DUST_DR3_FROM_DR2). Su prueba en node (tests/c3_node_dust_colour.js) carga ESTE fichero: mismas 122 lineas que antes.
//
// DE DONDE SALE (medido por el agente B, Cabra3D/docs/informe_28oct_agenteB.md §3.2). La columna Bp−Rp de la tabla de Mamajek
// (2022.04.16) esta en el sistema de Gaia DR2 (su cabecera: «Gaia DR2 G/Bp/Rp»; data/main_sequence.csv lo repite); el BP−RP de
// las estrellas con las que se compara (Gaia o la foto, calibrada sobre Gaia) es DR3. En las mismas estrellas (archivo de ESA,
// gaiadr3.dr2_neighbourhood + gaiadr2.gaia_source, casado uno a uno): mediana de DR3 − DR2 por tramo del color DR2, 1 229
// estrellas con G < 15 de M 67, NGC 1560 y LDu 2 (error de la mediana 0,0001-0,0009; entre campos difiere hasta ±0,005). En un
// campo que no se uso (Praesepe, 702 estrellas): residuo ≤ 0,003 en 5 de 6 tramos y +0,0056 en el 1,5-2,0.
// NO VERIFICADO para G < 10 (las estandares de Mamajek) ni la M_G (la columna G de DR2 va sin convertir).
// Fuera de la tabla, el borde (no se extrapola).
// PURO (ES5, sin PixInsight): lo cargan en node tests/cs_test_pure.js (CabraStars). Sin directivas de preprocesador: se incluye
// UNA vez por script (CabraStars.js, CabraStarAnalysis.js, Cabra3D.js), antes de quien lo use.
// ============================================================================

var CSH_MS_DR3 = true;      // costura: false = los colores de Mamajek tal cual (DR2), como hasta el 27-oct (controles en rojo)
var CSH_MS_DR3_FROM_DR2 = [[0.45, -0.0045], [0.70, -0.0080], [0.90, -0.0115], [1.10, -0.0148], [1.35, -0.0149], [1.75, -0.0118], [2.25, -0.0020]];

// DR3 − DR2 en el color DR2 `c` (interpolacion lineal entre tramos; fuera, el extremo). No mira la costura.
function cshMsDr3Offset(c) {
   var T = CSH_MS_DR3_FROM_DR2, n = T.length;
   if (!(c > T[0][0])) return T[0][1];
   if (c >= T[n - 1][0]) return T[n - 1][1];
   for (var i = 1; i < n; ++i) if (c <= T[i][0]) return T[i - 1][1] + (c - T[i - 1][0]) / (T[i][0] - T[i - 1][0]) * (T[i][1] - T[i - 1][1]);
   return T[n - 1][1];
}

// EL color de Mamajek que se usa: el DR2 de la tabla pasado a DR3 (con la costura apagada, el DR2 tal cual).
function cshMsDr3Colour(c) {
   return (CSH_MS_DR3 !== false) ? c + cshMsDr3Offset(c) : c;
}

// La secuencia del motor (`cpSfMainSequence`: [{ spt, teff, bpRp, absG }], bpRp en DR2) -> una COPIA con bpRp en DR3 y el
// color de la tabla en bpRpDr2. Lo que dibuja el HR (la linea discontinua y las letras espectrales) sale de aqui.
function cshMsSequenceDr3(rows) {
   var out = [];
   for (var i = 0; rows && i < rows.length; ++i) {
      var r = rows[i], c = (r.bpRp === null || r.bpRp === undefined) ? null : r.bpRp;
      out.push({ spt: r.spt, teff: r.teff, bpRp: (c === null || !isFinite(c)) ? c : cshMsDr3Colour(c), bpRpDr2: c, absG: r.absG });
   }
   return out;
}
