// ============================================================================
// CabraShared/csh_dust.js — EL POLVO EN 3D: Edenhofer et al. 2024 leido por rangos HTTP (UNA implementacion, 15-oct-2026)
// ----------------------------------------------------------------------------
// PROCEDENCIA: Cabra3D src/tm/dust.js (A5; la parte pura, tal cual) + src/tm/dust_run.js (la lectura) y CabraStars
// lib/cs_dust3d.js (copia de los dos, con bombeo de la interfaz). Ya divergian en la lectura (cache distinta, cierre
// distinto). Aqui: lo puro (HEALPix, multipart, perfiles, capas, escala de densidad) y `cshDustProfiles( pixeles, o )`,
// que da los perfiles de una lista de pixeles HEALPix leyendo SOLO lo que falta: lo ya leido en la sesion se guarda en
// memoria (CSH_DUST_MEM) y lo leido completo, en la cache de disco. Asi el polvo de CabraStarAnalysis se lee UNA vez
// aunque lo pidan la foto, el 3D, el HR y la ficha. Los nombres c3*/C3_* se conservan (los usan Cabra3D, CabraStars y sus
// pruebas).
// ----------------------------------------------------------------------------
// (lo que sigue es la cabecera original de Cabra3D tm/dust.js)
// ----------------------------------------------------------------------------
// EL MAPA: Edenhofer et al. 2024 (A&A 685, A82; «A parsec-scale Galactic 3D dust map out to 1.25 kpc from
// the Sun»). Densidad de extincion por parsec en unidades «E» de Zhang, Green y Rix 2023, en esferas HEALPix
// (nside 256, ordenacion NEST: pixeles de 13,7') a 516 distancias de 69 a 1 250 pc (0,4 pc de paso a 69 pc, 7 pc a
// 1 250 pc), mas lo integrado DENTRO de 68,8 pc. Fichero `mean_and_std_healpix.fits` de Zenodo (registro 10658339),
// 3,25 GB: NO se baja. Se leen por HTTP Range SOLO los pixeles del campo (Zenodo sirve rangos multiples): unos cientos
// de kB por campo (tm/dust_run.js), y se guardan en la cache.
// DISPOSICION DEL FICHERO (medida el 15-oct-2026 recorriendo sus cabeceras; tools: edenhofer_layout.py):
//   MEAN  datos en 5 760, [516 distancias][786 432 pixeles] float32 big-endian
//   RADIAL PIXEL BOUNDARIES  3 246 410 880 (517 float32), INNER (integrado < 68,8 pc) 3 246 416 640; total 3 252 715 200
// UNIDADES: E de ZGR23 (Zhang, Green y Rix 2023), sin unidades; NO es E(B−V). La extincion en mag a una longitud de onda
// es E × R(λ), con la curva de ZGR23 (src/data/dust/zgr23_extinction_curve.txt, Zenodo 7811871). VERIFICADO el 15-oct:
//   · A_V = 2,8 E: Edenhofer et al. 2024 §2 («multiplied the unitless ZGR23 extinction by a factor of 2.8», V = 540 nm),
//     y la curva da R(540 nm) = 2,78 (A0, a 541,4 nm: 2,77).
//   · E(BP−RP) ≈ 1,28 E (28-oct-2026, tarde, agente B; hasta hoy 1,35). DERIVACION: E(BP−RP) = A0·(k_BP − k_RP)(x0, A0) con los coeficientes
//     de Gaia Collaboration, Babusiaux et al. 2018 (A&A 616, A10, tabla 1: bandas de Gaia integradas con espectros de Kurucz y la ley de
//     Fitzpatrick 1999), A0 a 550 nm = 2,8·E / 1,022 = 2,74·E (el 2,8 de Edenhofer es a 540 nm; A(540)/A(550) = 1,022 con CCM R_V 3,1) y x0 el
//     color intrinseco de cada estrella: mediana 1,284 en las 652 estrellas del rotulo de LDu 2 (G < 15) y 1,280 en las 152 de NGC 1560;
//     p10–p90 1,23–1,34 segun el color (sin pasar a 550 nm saldria 1,31). MEDIDO, independiente: con la Teff de los ESPECTROS (LAMOST/APOGEE,
//     1 359 estrellas alrededor de LDu 2) la mediana E_color/E_mapa es 1,280 (tests/c3_node_dust_colour.js M2). El 1,35 de antes salia de la
//     curva de ZGR23 con bandas aproximadas por una longitud de onda (1,28 con λ medias, 1,39 con pivotes; 1,29–1,45 con cuerpos negros):
//     el centro de un intervalo ancho, sin integrar las bandas. Comprobacion: c3_node_dust_colour.js M6 (rojo C3_DC_BREAK=old135).
// (Hasta el 15-oct ponia 3,1 «porque E ≈ E(B−V)»: un numero sin fuente. El coordinador lo cazo.)
// Aqui: HEALPix NEST (ang2pix / pix2ang), las cabeceras multipart de las respuestas Range, float32 big-endian,
// los perfiles de cada linea de vista y su integral. ES5 puro (node lo ejecuta: tests/c3_tm_cases.js 10.x).
// ============================================================================

var C3_DUST = {
   URL: "https://zenodo.org/records/10658339/files/mean_and_std_healpix.fits?download=1",
   SIZE: 3252715200, NSIDE: 256, NPIX: 786432, NR: 516,
   OFF_MEAN: 5760, OFF_BOUNDS: 3246410880, OFF_INNER: 3246416640,
   R_IN: 68.8, R_OUT: 1250,
   AV_PER_E: 2.8,            // A_V = 2,8 E (Edenhofer et al. 2024 §2; curva de ZGR23: R(540 nm) = 2,78)
   EBPRP_PER_E: 1.28         // E(BP−RP) ≈ 1,28 E (Babusiaux+2018 con A0 = 2,74·E; ±0,05 segun el color; ver arriba). Hasta el 28-oct: 1,35
};

// --- HEALPix NEST (Gorski et al. 2005), solo lo que hace falta ----------------
function c3HpSpread(v) { var r = 0; for (var b = 0; b < 16; ++b) if ((v >> b) & 1) r += Math.pow(2, 2 * b); return r; }
function c3HpCompress(v) { var r = 0; for (var b = 0; b < 16; ++b) if (Math.floor(v / Math.pow(2, 2 * b)) % 2) r += Math.pow(2, b); return r; }
// fmodulo de healpix_base.cc: el resto en [0, v2) tambien para v1 negativo (sin que un resto minusculo negativo + v2 redondee a v2).
function c3HpFmodulo(v1, v2) {
   if (v1 >= 0) return (v1 < v2) ? v1 : (v1 % v2);
   var t = (v1 % v2) + v2;
   return (t === v2) ? 0 : t;
}
function c3HpAng2PixNest(nside, theta, phi) {
   var z = Math.cos(theta), za = Math.abs(z), tt = c3HpFmodulo(phi * (2 / Math.PI), 4), face, ix, iy;   // (27-oct-2026, T3 H-5 de Codex) fmodulo de healpix_base.cc: el redondeo de ((phi%2π)+2π)%2π/(π/2) mandaba a 4 el borde exacto y cambiaba de pixel
   if (za <= 2 / 3) {
      var t1 = nside * (0.5 + tt), t2 = nside * z * 0.75, jp = Math.floor(t1 - t2), jm = Math.floor(t1 + t2), ifp = Math.floor(jp / nside), ifm = Math.floor(jm / nside);
      face = (ifp === ifm) ? (ifp | 4) : ((ifp < ifm) ? ifp : ifm + 8);
      ix = jm & (nside - 1); iy = nside - (jp & (nside - 1)) - 1;
   } else {
      var ntt = Math.min(3, Math.floor(tt)), tp = tt - ntt, tmp = nside * Math.sqrt(3 * (1 - za));
      var jp2 = Math.min(nside - 1, Math.floor(tp * tmp)), jm2 = Math.min(nside - 1, Math.floor((1 - tp) * tmp));
      if (z >= 0) { face = ntt; ix = nside - jm2 - 1; iy = nside - jp2 - 1; }
      else { face = ntt + 8; ix = jp2; iy = jm2; }
   }
   return face * nside * nside + c3HpSpread(ix) + 2 * c3HpSpread(iy);
}
var C3_HP_JRLL = [2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4], C3_HP_JPLL = [1, 3, 5, 7, 0, 2, 4, 6, 1, 3, 5, 7];
function c3HpPix2AngNest(nside, pix) {
   var npf = nside * nside, face = Math.floor(pix / npf), ipf = pix - face * npf, ix = c3HpCompress(ipf), iy = c3HpCompress(Math.floor(ipf / 2));
   var npix = 12 * npf, fact2 = 4 / npix, fact1 = 2 * nside * fact2, jr = C3_HP_JRLL[face] * nside - ix - iy - 1, nr, z, kshift;
   if (jr < nside) { nr = jr; z = 1 - nr * nr * fact2; kshift = 0; }
   else if (jr > 3 * nside) { nr = 4 * nside - jr; z = nr * nr * fact2 - 1; kshift = 0; }
   else { nr = nside; z = (2 * nside - jr) * fact1; kshift = (jr - nside) & 1; }
   var jp = (C3_HP_JPLL[face] * nr + ix - iy + 1 + kshift) / 2;
   if (jp > 4 * nside) jp -= 4 * nside;
   if (jp < 1) jp += 4 * nside;
   return { theta: Math.acos(Math.max(-1, Math.min(1, z))), phi: (jp - (kshift + 1) * 0.5) * (Math.PI / 2 / nr) };
}
// (ra, dec) ICRS -> (l, b) galacticas, grados
var CSH_ICRS_TO_GAL = [            // la matriz A_G de Hipparcos (ESA 1997, vol. 1 §1.5.3), la misma de Cabra3D C3_TM_AG
   [-0.0548755604162154, -0.8734370902348850, -0.4838350155487132],
   [ 0.4941094278755837, -0.4448296299600112,  0.7469822444972189],
   [-0.8676661490190047, -0.1980763734312015,  0.4559837761750669]
];
function c3Galactic(ra, dec) {
   var k = Math.PI / 180, x = Math.cos(dec * k) * Math.cos(ra * k), y = Math.cos(dec * k) * Math.sin(ra * k), z = Math.sin(dec * k), M = CSH_ICRS_TO_GAL;
   var v = [M[0][0] * x + M[0][1] * y + M[0][2] * z, M[1][0] * x + M[1][1] * y + M[1][2] * z, M[2][0] * x + M[2][1] * y + M[2][2] * z];
   var l = Math.atan2(v[1], v[0]) / k;
   return { l: (l < 0) ? l + 360 : l, b: Math.asin(Math.max(-1, Math.min(1, v[2]))) / k };
}
function c3DustPixOf(ra, dec) { var g = c3Galactic(ra, dec), k = Math.PI / 180; return c3HpAng2PixNest(C3_DUST.NSIDE, (90 - g.b) * k, g.l * k); }

// --- las respuestas Range --------------------------------------------------------
// float32 big-endian en `bytes` (cualquier cosa con [i]) a partir de `o`
function c3F32BE(bytes, o) {
   var b0 = bytes[o], b1 = bytes[o + 1], b2 = bytes[o + 2], b3 = bytes[o + 3], sign = (b0 & 0x80) ? -1 : 1, exp = ((b0 & 0x7f) << 1) | (b1 >> 7), man = ((b1 & 0x7f) << 16) | (b2 << 8) | b3;
   if (exp === 0) return (man === 0) ? 0 : sign * man * Math.pow(2, -149);
   if (exp === 255) return NaN;
   return sign * (1 + man / 8388608) * Math.pow(2, exp - 127);
}
// Las partes de una respuesta «multipart/byteranges» (o una sola parte, si `single` = [inicio, fin]).
// Devuelve [ { start, end, data: [bytes] , at (indice en `bytes` del primer byte de datos) } ].
function c3DustParts(bytes, n, single) {
   var out = [];
   if (single) { out.push({ start: single[0], end: single[1], at: 0 }); return out; }
   var i = 0;
   function lineAt(p) { var s = ""; while (p < n && bytes[p] !== 10) { if (bytes[p] !== 13) s += String.fromCharCode(bytes[p]); ++p; } return { s: s, next: p + 1 }; }
   while (i < n) {
      var L = lineAt(i), m = /^Content-Range:\s*bytes\s+(\d+)-(\d+)[/](\d+|[*])/i.exec(L.s);   // (OJO: «\/» seguido de «/i» son dos barras: el preprocesador de PJSR lo toma por un comentario y el fichero no compila)
      if (m) {
         var a = parseInt(m[1], 10), b = parseInt(m[2], 10), p = L.next;
         // la linea en blanco que separa la cabecera de los datos
         var L2 = lineAt(p);
         while (L2.s.length > 0 && L2.next < n) { p = L2.next; L2 = lineAt(p); }
         // (una respuesta CORTADA —curl llego a su tope de tiempo— deja la ultima parte a medias: esa no se da por buena)
         // (3-nov-2026, CPD C6) Y LA PARTE TIENE QUE SER LA DEL FICHERO QUE SE CREE: el total de «Content-Range» es el tamaño publicado
         // del mapa (C3_DUST.SIZE; si Zenodo sirviera otro fichero, o una pagina, no cuadra) y tras sus b-a+1 bytes viene el separador
         // de la siguiente parte («--…») o el final: si no, la parte no mide lo que dice y no se usa. Costura roja: CSH_NET_BREAK=nopartcheck.
         var total = (m[3] === "*") ? -1 : parseInt(m[3], 10), endAt = L2.next + (b - a + 1), sane = true;
         if (!(typeof cshNetBrk === "function" && cshNetBrk("nopartcheck"))) {   // (sin csh_net.js —pruebas node que cargan csh_dust.js solo— se comprueba igual)
            if (total >= 0 && total !== C3_DUST.SIZE) sane = false;
            if (sane && endAt < n) { var tail = lineAt(endAt); if (tail.s.length > 0) sane = false; else { var nx = lineAt(tail.next); if (tail.next < n && nx.s.indexOf("--") !== 0) sane = false; } }
         }
         if (sane && endAt <= n) out.push({ start: a, end: b, at: L2.next });
         i = L2.next + (b - a + 1);
      } else i = L.next;
   }
   return out;
}
// Lo que vale el float32 de la posicion absoluta `off` del fichero, buscandolo en las partes.
function c3DustValueAt(parts, bytes, off) {
   for (var k = 0; k < parts.length; ++k) { var P = parts[k]; if (off >= P.start && off + 3 <= P.end) return c3F32BE(bytes, P.at + (off - P.start)); }
   return NaN;
}

// --- los perfiles -----------------------------------------------------------------
// Los rangos a pedir para unos pixeles y unas distancias (indices de capa `shells`): uno por capa y por RACHA de pixeles
// (pixeles a menos de `gap` uno de otro van en la misma racha: se leen unos pocos bytes de mas a cambio de menos rangos).
// (MEDIDO en NGC 1560, 15-oct: con «un rango que los cubra a todos» si cabian en 4 096 pixeles, 9 pixeles costaban 5 MB y
// 136 s, y curl se cortaba a su tope de tiempo. Por rachas, unos kB.)
// Devuelve [ [inicio, fin] ] en bytes, ordenados y fundidos si se tocan.
function c3DustRuns(pixels, gap) {
   var p = pixels.slice().sort(function(a, b) { return a - b; }), runs = [], a = p[0], b = p[0], G = (gap > 0) ? gap : 16;
   for (var i = 1; i < p.length; ++i) { if (p[i] - b <= G) b = p[i]; else { runs.push([a, b]); a = b = p[i]; } }
   runs.push([a, b]);
   return runs;
}
function c3DustRanges(pixels, shells, gap) {
   var runs = c3DustRuns(pixels, gap), i, k, out = [];
   for (k = 0; k < shells.length; ++k) for (i = 0; i < runs.length; ++i) {
      var s = C3_DUST.OFF_MEAN + (shells[k] * C3_DUST.NPIX + runs[i][0]) * 4, e = C3_DUST.OFF_MEAN + (shells[k] * C3_DUST.NPIX + runs[i][1]) * 4 + 3;
      if (out.length && s <= out[out.length - 1][1] + 1) out[out.length - 1][1] = Math.max(out[out.length - 1][1], e); else out.push([s, e]);
   }
   return out;
}
// Integrar un perfil: `bounds` (517 bordes, pc), `dens` (densidad por capa, solo las capas de `shells`; las demas se rellenan con la
// muestra mas cercana), `inner` (E integrado dentro de 68,8 pc). Devuelve { r: Float64Array (bordes), cum: E acumulado en cada borde }.
function c3DustCumulative(bounds, shells, dens, inner) {
   var NR = bounds.length - 1, full = new Float64Array(NR), k = 0, i;
   for (i = 0; i < NR; ++i) {
      while (k + 1 < shells.length && Math.abs(shells[k + 1] - i) <= Math.abs(shells[k] - i)) ++k;
      if (typeof dens[k] !== "number" || !isFinite(dens[k])) return null;                      // (un valor que no llego: esa linea de vista queda SIN DATOS, no a cero)
      full[i] = Math.max(0, dens[k]);
   }
   var cum = new Float64Array(NR + 1);
   // (27-oct-2026, T3 H-4 de Codex) Un `inner` que no llego (NaN/undefined) es una linea de vista SIN DATOS, no «cero polvo dentro de 68,8 pc».
   if (typeof inner !== "number" || !isFinite(inner)) return null;
   cum[0] = Math.max(0, inner);
   for (i = 0; i < NR; ++i) cum[i + 1] = cum[i] + full[i] * (bounds[i + 1] - bounds[i]);
   return { r: bounds, cum: cum, dens: full };
}
// E acumulado hasta `d` pc (interpolado; mas alla de 1 250 pc, el ultimo: el mapa no sabe mas).
function c3DustEAt(prof, d) {
   var r = prof.r, n = r.length;
   if (!(d > r[0])) return prof.cum[0] * Math.max(0, d) / r[0];
   if (d >= r[n - 1]) return prof.cum[n - 1];
   var lo = 0, hi = n - 1;
   while (hi - lo > 1) { var m = (lo + hi) >> 1; if (r[m] <= d) lo = m; else hi = m; }
   return prof.cum[lo] + (prof.cum[hi] - prof.cum[lo]) * (d - r[lo]) / (r[hi] - r[lo]);
}
// Donde esta el grueso del polvo de un perfil: el tramo de `win` pc donde mas sube E, y cuanto (para decirlo con palabras).
function c3DustMainLayer(prof, win) {
   var r = prof.r, best = { d: 0, dE: 0 }, w = win || 40;
   // (27-oct-2026, T3 H-2 de Codex) E acumulado es lineal a trozos: el maximo de la ventana se alcanza con un EXTREMO en un borde de capa. Antes solo
   // se probaban las que EMPIEZAN en un borde; ahora tambien las que ACABAN en uno (empiezan en r[i] - w): perdian hasta un 12 % de E.
   for (var i = 0; i < r.length; ++i) {
      for (var c = 0; c < 2; ++c) {
         var s = (c === 0) ? r[i] - w : r[i];
         if (s < r[0]) continue;
         var dE = c3DustEAt(prof, s + w) - c3DustEAt(prof, s);
         if (dE > best.dE) best = { d: s + w / 2, dE: dE, i0: i, s: s };
      }
   }
   // (el centro de la capa: la media pesada por el polvo dentro de la ventana, no el centro de la ventana). La ventana se recorta en LOS DOS
   // extremos (antes la ultima celda entraba entera aunque la ventana acabara a mitad de ella: el centro salia hasta ~0,8 pc de mas).
   if (best.dE > 0 && prof.dens) {
      var sw = 0, sr = 0, s0 = best.s, s1 = best.s + w;
      for (var j = 0; j < r.length - 1; ++j) {
         var lo = Math.max(r[j], s0), hi = Math.min(r[j + 1], s1);
         if (!(hi > lo)) continue;
         var m = prof.dens[j] * (hi - lo); sw += m; sr += m * 0.5 * (lo + hi);
      }
      if (sw > 0) best.d = sr / sw;
   }
   return best;
}

// --- LA ESCALA DEL POLVO (encargo de Nino, 15-oct-2026): su DENSIDAD, en llano ----------------------------------------
// La densidad es lo que apaga el polvo por cada kiloparsec de camino: A_V por kpc (magnitudes de luz visible por kpc).
// Referencias para elegir las palabras: el medio difuso del plano galactico apaga ~1–2 mag/kpc de media (Whittet 2003,
// «Dust in the Galactic Environment», cap. 3); una nube molecular, decenas o cientos (Tauro: unas 2,5 mag en ~10 pc).
//   tenue < 1 mag/kpc · denso 1–10 · muy denso ≥ 10. La rampa de color va de 0,3 a 100 mag/kpc (logaritmica).
var C3_DUST_SCALE = { LO: 0.3, HI: 100, DENSE: 1, VERY: 10, TICKS: [0.3, 1, 3, 10, 30, 100],
                      RAMP: [[0, 0xF3E1C2], [0.26, 0xC98A4E], [1, 0x8E3A1E]] };   // crema -> marron dorado -> marron rojizo (contraste sobre el carbon de Atlas). (Cabra3D, tarea H, 21-oct: el marron llega ya en «denso» —1 mag/kpc es t = 0,21—; con 0,45 una capa densa de 1,5 mag/kpc salia casi crema, igual que la tenue: montaje del 21-oct)
function c3DustDensityClass(avPerKpc) { return (avPerKpc >= C3_DUST_SCALE.VERY) ? "very dense" : (avPerKpc >= C3_DUST_SCALE.DENSE) ? "dense" : "thin"; }
// Donde cae una densidad en la rampa (0…1, logaritmica; fuera, en los topes).
function c3DustRampT(avPerKpc) {
   if (!(avPerKpc > 0)) return 0;
   return Math.max(0, Math.min(1, Math.log(avPerKpc / C3_DUST_SCALE.LO) / Math.log(C3_DUST_SCALE.HI / C3_DUST_SCALE.LO)));
}
// El color (0xRRGGBB) de la rampa en t.
function c3DustRampColor(t) {
   var R = C3_DUST_SCALE.RAMP, k = 1;
   while (k < R.length - 1 && t > R[k][0]) ++k;
   var a = R[k - 1], b = R[k], w = Math.max(0, Math.min(1, (t - a[0]) / (b[0] - a[0]))), out = 0;
   for (var sh = 16; sh >= 0; sh -= 8) { var ca = (a[1] >> sh) & 255, cb = (b[1] >> sh) & 255; out |= Math.round(ca + (cb - ca) * w) << sh; }
   return out;
}
// LAS CAPAS de polvo de un campo, a lo largo del haz: con el perfil MEDIANO de sus lineas de vista (E en cada borde de
// `B` tramos logaritmicos de 69 a 1 250 pc), los tramos seguidos con densidad ≥ `thr` mag/kpc forman una capa.
// Devuelve [ { from, to (pc), dAV (mag), peak (mag/kpc), cls } ] por distancia (las de menos de 0,05 mag, fuera).
function c3DustLayers(profs, avPerE, B, thr) {
   var n = (profs || []).length, i, k;
   if (n === 0) return [];
   B = B || 60; thr = (thr > 0) ? thr : C3_DUST_SCALE.DENSE;
   var r0 = C3_DUST.R_IN, r1 = C3_DUST.R_OUT, edges = [], E = [];
   for (k = 0; k <= B; ++k) edges.push(r0 * Math.pow(r1 / r0, k / B));
   for (k = 0; k <= B; ++k) {
      var v = [];
      for (i = 0; i < n; ++i) v.push(c3DustEAt(profs[i], edges[k]));
      v.sort(function(a, b) { return a - b; });
      E.push(v[v.length >> 1]);
   }
   var out = [], cur = null;
   for (k = 0; k < B; ++k) {
      var dAV = Math.max(0, E[k + 1] - E[k]) * avPerE, dens = dAV / (edges[k + 1] - edges[k]) * 1000;
      if (dens >= thr) {
         if (cur === null) cur = { from: edges[k], to: edges[k + 1], dAV: 0, peak: 0 };
         cur.to = edges[k + 1]; cur.dAV += dAV; cur.peak = Math.max(cur.peak, dens);
      } else if (cur !== null) { out.push(cur); cur = null; }
   }
   if (cur !== null) out.push(cur);
   var keep = [];
   for (i = 0; i < out.length; ++i) if (out[i].dAV >= 0.05) { out[i].cls = c3DustDensityClass(out[i].peak); keep.push(out[i]); }
   return keep;
}

// ============================================================================
// LA LECTURA (comun): cache, curl con rangos, tandas comprobadas, bordes de las capas y perfiles por pixel
// ============================================================================
// COSTURA DE PRUEBAS: C3_DUST_CURL_HOOK( ranges, url ) -> { ok, bytes (Uint8Array), n, multipart } EN VEZ de curl.
var C3_DUST_CURL_HOOK = null;
var C3_DUST_TIMEOUT_S = 40;
var C3_DUST_MAX_RANGES = 800;       // rangos por campo como mucho (4 peticiones)
var C3_DUST_BATCH = 200;            // rangos por peticion (~4,5 kB de cabecera «Range»)
var C3_DUST_BOUNDS = null;          // los 517 bordes de las capas (una vez por sesion)
var CSH_DUST_MEM = {};              // pixel -> { shells, dens, inner } ya leido en esta sesion
var CSH_DUST_READS = 0;             // lecturas de verdad (red) en la sesion: las pruebas de «una sola vez» lo miran
var CSH_DUST_MISSES = 0;            // peticiones con algun pixel que NO estaba en memoria (de disco o de red): «una sola vez» = 1
var CSH_NET_LAST = null;            // el ultimo fallo de red del polvo: { server, code, message }
// ¿Se esta cerrando el script? (los bucles largos lo miran: CSH_ABORT, o el C3_CLOSING de Cabra3D)
function cshStopping() { return (CSH_ABORT === true) || (typeof C3_CLOSING !== "undefined" && C3_CLOSING === true); }

// LA CACHE de disco, comun a los cuatro scripts (se puede borrar: se rehace).
// (F2, 22-oct-2026) Vive en %LOCALAPPDATA%\CabraScripts\cache\ (csh_net.js `cshCacheRoot`), no en %TEMP% (Windows la limpia
// y con ella el polvo ya leido). Se ESCRIBE siempre en la nueva; se LEE de la nueva y, si no esta, de la vieja
// (<temporal>/CabraScripts_cache), para no volver a pedir lo que ya se tenia. `c3CacheDir()` da la nueva (sin barra final).
var CSH_CACHE_DIRNAME = "CabraScripts_cache";            // (la carpeta VIEJA, en el temporal: solo se lee)
function c3CacheDir() { return cshCacheRoot().replace(/[/]+$/, ""); }
function c3CacheDirOld() { return String(File.systemTempDirectory).split("\\").join("/") + "/" + CSH_CACHE_DIRNAME; }
// (3-nov-2026, CPD C6) CADA FICHERO LLEVA SU HUELLA (cshCacheSave/cshCacheLoad de csh_net.js: SHA-256 en PixInsight) y se comprueba al leer:
// si no cuadra se BORRA y quien llama lo vuelve a pedir (devuelve null, como si no estuviera). Un fichero de antes del 3-nov (sin sello)
// se acepta UNA vez si es JSON valido y se vuelve a guardar sellado (CSH_CACHE_LEGACY; si se pone a false, se descarta como uno que no cuadra).
// CSH_CACHE_LAST = el porque de la ultima lectura ("" | "missing" | "legacy" | "integrity" | "read" | "json"): las pruebas lo leen.
var CSH_CACHE_LEGACY = true;
var CSH_CACHE_LAST = "";
function c3CacheLoadAt(p) {
   var ld = cshCacheLoad(p, { legacy: CSH_CACHE_LEGACY === true });
   CSH_CACHE_LAST = ld.why;
   if (!ld.ok) return { found: ld.why !== "missing", obj: null, legacy: false, text: "" };
   try { return { found: true, obj: JSON.parse(ld.text), legacy: ld.legacy === true, text: ld.text }; }
   catch (eJ) { CSH_CACHE_LAST = "json"; try { File.remove(p); } catch (eR) {} return { found: true, obj: null, legacy: false, text: "" }; }
}
function c3CacheRead(name) {
   try {
      var p = c3CacheDir() + "/" + name, r = c3CacheLoadAt(p);
      if (r.obj !== null) { if (r.legacy) cshCacheSave(p, r.text); return r.obj; }
      if (r.found) return null;                    // (estaba pero no cuadraba: ya se ha borrado; no se mira la vieja)
   } catch (e) {}
   // (22-oct-2026, tarde, Cabra3D) lo que solo esta en la vieja se COPIA a la nueva al leerlo: si no, una cache que ya no se reescribe
   // (los nombres de SIMBAD, las Teff, la RV de un campo ya visto) seguia viviendo solo en %TEMP% hasta que Windows la limpiase.
   try {
      var q = c3CacheDirOld() + "/" + name, rq = c3CacheLoadAt(q);
      if (rq.obj !== null) { try { cshCacheSave(c3CacheDir() + "/" + name, rq.text); } catch (eM) {} return rq.obj; }
   } catch (e2) {}
   return null;
}
function c3CacheWrite(name, obj) { try { cshCacheSave(c3CacheDir() + "/" + name, JSON.stringify(obj)); } catch (e) {} }

// curl con rangos: [ [a, b] ] -> { ok, bytes (Uint8Array), n, multipart, code, ms, why }
function c3CurlRanges(url, ranges, timeoutS) {
   if (typeof C3_DUST_CURL_HOOK === "function") return C3_DUST_CURL_HOOK(ranges, url);
   if (!cshHasCurl()) return { ok: false, bytes: null, n: 0, multipart: ranges.length > 1, code: 0, ms: 0, why: "no curl" };
   var q = c3RangesReq(url, ranges, timeoutS);
   // (sin bombeo propio de la interfaz, Cabra3D repintaba con optProcessEvents: se conserva)
   return q.finish(cshCurlRun(q.args, { timeoutS: q.T, graceS: 5, abort: function() { return cshStopping(); }, idle: function() { if (typeof optProcessEvents === "function") optProcessEvents(); } }));
}
// lo comun a la serie y al lote: los argumentos de curl y lo que se hace con lo que llega
function c3RangesReq(url, ranges, timeoutS) {
   var t0 = Date.now(), tmp = cshTmpPath("csh_dust", ".bin"), T = timeoutS || C3_DUST_TIMEOUT_S, spec = [];
   for (var i = 0; i < ranges.length; ++i) spec.push(ranges[i][0] + "-" + ranges[i][1]);
   return { T: T, args: ["-L", "--proto", "=https", "--proto-redir", "=https", "--connect-timeout", "15", "-m", String(T), "-r", spec.join(","), "-o", tmp, url], finish: function(c) { return c3RangesEnd(c, ranges, tmp, T, t0); } };
}
function c3RangesEnd(c, ranges, tmp, T, t0) {
   var out = { ok: false, bytes: null, n: 0, multipart: ranges.length > 1, code: c.code, ms: 0, why: "" };
   // (el porque, para decirlo: «no answer» = tope de tiempo —curl 28 o cortado aqui—; «curl exit 6/7» = sin conexion)
   out.why = c.cut ? ("no answer in " + T + " s") : c.aborted ? "stopped" : (c.exit === 28) ? "no answer (curl exit 28)" : (c.exit > 0) ? ("curl exit " + c.exit) : "";
   try {
      if (File.exists(tmp)) {
         var ba = File.readFile(tmp), n = ba.length, u = new Uint8Array(n);
         for (var k = 0; k < n; ++k) u[k] = ba[k];   // (20-oct: ByteArray.at() esta obsoleta)
         out.bytes = u; out.n = n;
         File.remove(tmp);
      }
   } catch (eR) {}
   out.ok = (out.code === 206 && out.n > 0);
   out.ms = Date.now() - t0;
   return out;
}
// (30-oct-2026) LAS TANDAS A LA VEZ. Medido en Abell 39 (StellarPopulations, 30-oct): 4 tandas en serie, 1,0-1,7 s cada una = 5,7 s, y hasta que acaban la ficha de la estrella elegida no sale (_starStep
// espera a _netBusy). Son 4 peticiones de rangos a un mismo fichero: no se abusa de Zenodo (tope C3_DUST_PARALLEL) y el reintento por tanda de c3DustRead sigue igual, en serie.
// -> [respuesta de c3CurlRanges por tanda] o null (el gancho de las pruebas cuenta sus visitas en orden; una sola tanda; costura CSH_NET_BREAK=noparalleldust)
var C3_DUST_PARALLEL = 4;
function c3CurlRangesMany(url, chunks) {
   if (chunks.length < 2 || typeof C3_DUST_CURL_HOOK === "function" || typeof cshBatchRun !== "function" || !cshHasCurl() || cshNetBrk("noparalleldust")) return null;
   var chains = chunks.map(function(ch) {
      return function(r) {
         if (r !== undefined) return { done: r };
         var q = c3RangesReq(url, ch);
         return { req: { args: q.args, waitS: q.T, tag: "Zenodo", finish: q.finish } };
      };
   });
   // (Cabra3D no siempre tiene CSH_NET_PUMP aqui: repintaba con optProcessEvents, como arriba)
   var ownPump = (typeof CSH_NET_PUMP !== "function" && typeof optProcessEvents === "function");
   if (ownPump) CSH_NET_PUMP = function() { optProcessEvents(); return false; };
   try { return cshBatchRun(chains, { max: C3_DUST_PARALLEL, abort: function() { return cshStopping(); } }); }
   finally { if (ownPump) CSH_NET_PUMP = null; }
}
// Los valores float32 de unos rangos (pedidos en tandas de `batch`): { ok, get( off ) -> valor, bytes, requests }
function c3DustRead(ranges, batch, onProgress) {
   var parts = [], total = 0, req = 0, B = batch || 120;
   // ¿estan TODOS los rangos pedidos en lo que llego? (una respuesta cortada a medias no avisa: se comprueba)
   function complete(chunk, ps) {
      for (var a = 0; a < chunk.length; ++a) { var hit = false; for (var b = 0; b < ps.length && !hit; ++b) hit = (ps[b].start <= chunk[a][0] && ps[b].end >= chunk[a][1]); if (!hit) return false; }
      return true;
   }
   var chunks = [], ci = -1;
   for (var i0 = 0; i0 < ranges.length; i0 += B) chunks.push(ranges.slice(i0, i0 + B));
   var pre = c3CurlRangesMany(C3_DUST.URL, chunks);             // (la primera pasada de todas las tandas, a la vez; lo que falle se reintenta abajo)
   for (var i = 0; i < ranges.length; i += B) {
      if (cshStopping()) return { ok: false, code: "stopped", requests: req, bytes: total };
      ++ci;
      var chunk = chunks[ci], r = null, ps = null;
      for (var tries = 0; tries < 2; ++tries) {                 // (un reintento por tanda)
         r = (tries === 0 && pre && pre[ci]) ? pre[ci] : c3CurlRanges(C3_DUST.URL, chunk);
         ++req;
         if (!r.ok) continue;
         if (chunk.length === 1 && r.n !== chunk[0][1] - chunk[0][0] + 1) { r.ok = false; continue; }
         ps = c3DustParts(r.bytes, r.n, (chunk.length === 1) ? chunk[0] : null);
         if (complete(chunk, ps)) break;
         r.ok = false;
      }
      if (!r.ok) {
         CSH_NET_LAST = { server: "Zenodo", code: r.code | 0, message: String(r.why || "") };
         if (typeof C3_NET_LAST !== "undefined") C3_NET_LAST = CSH_NET_LAST;   // (Cabra3D lo dice en su linea de estado)
         return { ok: false, code: "no-network", requests: req, bytes: total };
      }
      for (var k = 0; k < ps.length; ++k) parts.push({ start: ps[k].start, end: ps[k].end, at: ps[k].at, bytes: r.bytes });
      total += r.n;
      if (typeof onProgress === "function") onProgress(Math.min(1, (i + B) / ranges.length));
   }
   parts.sort(function(a, b) { return a.start - b.start; });
   return { ok: true, requests: req, bytes: total, get: function(off) {
      var lo = 0, hi = parts.length - 1;
      while (lo <= hi) { var m = (lo + hi) >> 1, P = parts[m]; if (off < P.start) hi = m - 1; else if (off > P.end) lo = m + 1; else return c3F32BE(P.bytes, P.at + (off - P.start)); }
      return NaN;
   } };
}
function c3DustBounds() {
   if (C3_DUST_BOUNDS) return C3_DUST_BOUNDS;
   var c = c3CacheRead("eden_bounds.json");
   if (c && c.length === 517) { C3_DUST_BOUNDS = c; return c; }
   var r = c3DustRead([[C3_DUST.OFF_BOUNDS, C3_DUST.OFF_BOUNDS + 517 * 4 - 1]], 1);
   if (!r.ok) return null;
   var b = [];
   for (var i = 0; i < 517; ++i) b.push(r.get(C3_DUST.OFF_BOUNDS + 4 * i));
   if (!(b[0] > 60 && b[0] < 75 && b[516] > 1200 && b[516] < 1300)) return null;      // (no es lo que tenia que ser: el fichero ha cambiado)
   c3CacheWrite("eden_bounds.json", b);
   C3_DUST_BOUNDS = b;
   return b;
}

// LOS PERFILES de una lista de pixeles HEALPix (nside 256, NEST). Lo ya leido en la sesion sale de memoria; lo que falte,
// de la cache de disco (por lista) o de Zenodo (solo esos pixeles, en las capas que quepan en C3_DUST_MAX_RANGES rangos:
// una de cada `stride`; la densidad del mapa es suave a esa escala).
// o = { key: prefijo de la cache, onProgress(frac) }
// -> { ok, code ("" | "no-network" | "stopped" | "bad-answer"), profs: { pix: perfil }, data: { pix: crudo }, bounds, cached,
//      fromMemory, requests, bytes, stride, missing, ms }
function cshDustProfiles(list, o) {
   o = o || {};
   var t0 = Date.now(), out = { ok: false, code: "", profs: {}, data: {}, bounds: null, cached: false, fromMemory: 0, requests: 0, bytes: 0, stride: 1, missing: 0, ms: 0 }, i, j;
   var need = [];
   for (i = 0; i < list.length; ++i) { if (CSH_DUST_MEM[list[i]]) { out.data[list[i]] = CSH_DUST_MEM[list[i]]; ++out.fromMemory; } else need.push(list[i]); }
   var bounds = C3_DUST_BOUNDS;
   if (need.length > 0) {
      ++CSH_DUST_MISSES;
      // (F2, 22-oct-2026) la CLAVE: la huella de la lista ENTERA (antes, la lista recortada a 120 caracteres: dos campos con los
      // mismos primeros pixeles y el mismo numero compartian fichero y el segundo leia perfiles de otro campo, sin aviso).
      // Una copia con la clave vieja se acepta solo si trae TODOS los pixeles pedidos, y se vuelve a guardar con la nueva.
      var sorted = need.slice().sort(function(a, b) { return a - b; }), pre = (o.key || "eden") + "_";
      var key = pre + "h" + cshHash16(sorted.join("_")) + "_" + need.length + ".json", cache = c3CacheRead(key);
      if (!(cache && cache.bounds && cache.pix)) {
         var old = c3CacheRead(pre + sorted.join("_").substring(0, 120) + "_" + need.length + ".json"), all = !!(old && old.bounds && old.pix);
         for (i = 0; all && i < need.length; ++i) if (!old.pix[need[i]]) all = false;
         if (all) { cache = old; c3CacheWrite(key, old); } else cache = null;
      }
      if (cache && cache.bounds && cache.pix) {
         bounds = cache.bounds; if (!C3_DUST_BOUNDS && bounds.length === 517) C3_DUST_BOUNDS = bounds;
         out.cached = true;
         for (i = 0; i < need.length; ++i) if (cache.pix[need[i]]) { out.data[need[i]] = cache.pix[need[i]]; CSH_DUST_MEM[need[i]] = cache.pix[need[i]]; }
      } else {
         bounds = c3DustBounds();
         if (bounds === null) { out.code = cshStopping() ? "stopped" : "no-network"; out.ms = Date.now() - t0; return out; }
         var runs = c3DustRuns(need, 16), shells = [], stride = Math.max(1, Math.ceil(C3_DUST.NR * runs.length / C3_DUST_MAX_RANGES));
         for (i = 0; i < C3_DUST.NR; i += stride) shells.push(i);
         if (shells[shells.length - 1] !== C3_DUST.NR - 1) shells.push(C3_DUST.NR - 1);
         out.stride = stride;
         var ranges = c3DustRanges(need, shells, 16);
         for (i = 0; i < runs.length; ++i) ranges.push([C3_DUST.OFF_INNER + 4 * runs[i][0], C3_DUST.OFF_INNER + 4 * runs[i][1] + 3]);
         ++CSH_DUST_READS;
         var rd = c3DustRead(ranges, C3_DUST_BATCH, o.onProgress);
         out.requests = rd.requests; out.bytes = rd.bytes;
         if (!rd.ok) { out.code = rd.code || "no-network"; out.ms = Date.now() - t0; return out; }
         var fresh = {};
         for (i = 0; i < need.length; ++i) {
            var p2 = need[i], dens = [];
            for (j = 0; j < shells.length; ++j) dens.push(rd.get(C3_DUST.OFF_MEAN + (shells[j] * C3_DUST.NPIX + p2) * 4));
            fresh[p2] = { shells: shells, dens: dens, inner: rd.get(C3_DUST.OFF_INNER + 4 * p2) };
            for (j = 0; j < dens.length; ++j) if (!isFinite(dens[j])) ++out.missing;
            if (!isFinite(fresh[p2].inner)) ++out.missing;   // (27-oct-2026, T3 H-4) un `inner` que no llego tambien es un dato que falta (y no se guarda en la cache)
            out.data[p2] = fresh[p2];
         }
         if (out.missing === 0) {
            for (i = 0; i < need.length; ++i) CSH_DUST_MEM[need[i]] = fresh[need[i]];
            c3CacheWrite(key, { bounds: bounds, pix: fresh, when: (new Date()).toISOString(), source: "Edenhofer et al. 2024 (A&A 685, A82), Zenodo 10658339" });   // (a la cache solo lo COMPLETO)
         }
      }
   }
   if (!bounds) bounds = C3_DUST_BOUNDS || c3DustBounds();
   out.bounds = bounds;
   if (!bounds) { out.code = "no-network"; out.ms = Date.now() - t0; return out; }
   for (i = 0; i < list.length; ++i) { var d = out.data[list[i]]; if (d) { var pr = c3DustCumulative(bounds, d.shells, d.dens, d.inner); if (pr) out.profs[list[i]] = pr; } }
   out.ok = Object.keys(out.profs).length > 0;
   if (!out.ok && !out.code) out.code = "bad-answer";
   out.ms = Date.now() - t0;
   return out;
}
