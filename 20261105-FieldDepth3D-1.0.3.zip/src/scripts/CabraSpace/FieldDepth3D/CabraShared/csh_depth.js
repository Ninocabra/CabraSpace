// ============================================================================
// CabraShared/csh_depth.js — LO QUE DE VERDAD SE VE EN LA FOTO: la parte PURA (Block G, 20-oct-2026)
// ----------------------------------------------------------------------------
// Encargo de Nino: «tienes que enseñar los objetos que estan EN LA IMAGEN, no los que estan en el campo en todos los
// catalogos. Estima la magnitud de lo que hay en la imagen y pide a los catalogos esa misma magnitud». Y (bloque 10):
// cuasares, galaxias y nebulosidad con su sitio y su valor.
// Este fichero es la ARITMETICA (node la ejecuta entera: `Cabra3D/tests/c3_blockG_pure.js`):
//   · la COMPLETITUD por tramos de 0,25 mag de G y sus cortes al 50 % y al 90 % (`cshDepthLimits`);
//   · las relaciones G -> V, R, g, r, B de Gaia, para llevar la magnitud de un catalogo a G (`cshGMinus`, `cshObjG`);
//   · el BRILLO SUPERFICIAL limite (`cshSbLimit`) y el medio de una galaxia (`cshMeanSb`);
//   · el VEREDICTO de cada objeto: se ve / demasiado debil / fuera / hay que mirar los pixeles (`cshDepthVerdict`);
//   · GLADE+ y Quaia: las consultas, las filas y su distancia (`cshGladeAdql`, `cshGladeObjects`, `cshQuaiaAdql`,
//     `cshQuaiaObjects`), y casar sus objetos con los de SIMBAD (`cshDepthMerge`);
//   · la linea de estado (`cshDepthSay`).
// Lo que toca la imagen y la red esta en csh_depth_run.js. Necesita de csh_starfield.js: CP_SF, cpSfParseTable,
// cpSfNum, cpSfSeparation, cpSfCosmo, cpSfMedian. ES5.
//
// DE DONDE SALE CADA NUMERO (regla: ninguno de memoria; lo que es decision va marcado «diseño»):
//   · Relaciones fotometricas de Gaia (G-V, G-R, G-g, G-r en funcion de BP-RP; G-V en funcion de B-V): documentacion de
//     Gaia EDR3, §5.5.1 (Carrasco y Bellazzini), tablas 5.6 (SDSS12) y 5.7 (Johnson-Cousins), con sus intervalos de
//     validez (tabla 5.8). Leidas el 20-oct-2026 en gea.esac.esa.int/archive/documentation/GEDR3/…/cu5pho_ssec_photRelations.
//     Son relaciones de ESTRELLAS: aplicadas a una galaxia o a un cuasar son una aproximacion (se dice); el margen de
//     color las cubre y, cerca del limite, decide la prueba de los pixeles.
//   · Color de las galaxias, g-r de 0,3 a 1,0: Shimasaku et al. 2001 (AJ 122, 1238), tabla 1: medias por tipo de 0,42
//     (Sdm) a 0,83 (E) con dispersiones de 0,12 a 0,24 (leida el 20-oct-2026 en ar5iv astro-ph/0105401). El intervalo es
//     «media ± ~1 dispersion» redondeado: diseño.
//   · Color de lo puntual sin color medido (cuasares), g-r de 0,0 a 0,6: diseño, ANCHO A PROPOSITO. NO VERIFICADO contra un
//     catalogo de cuasares; solo decide si un objeto es claro u «hay que mirar sus pixeles».
//   · Brillo superficial limite mu_lim(3 sigma; 10" x 10"): Roman, Trujillo y Montes 2020 (A&A 644, A42), apendice A:
//     mu_lim = -2,5 log10( 3 sigma / (pix · 10) ) + ZP. Aqui sigma se MIDE en cajas de 10" (el ruido de una foto apilada
//     esta correlado entre pixeles y la formula por pixel lo subestima: se dan las dos).
//   · GLADE+ (Dalya et al. 2022, MNRAS 514, 1403; VizieR VII/291): 22,5 millones de galaxias y 750 000 cuasares
//     (GWGC, HyperLEDA, 2MPZ, 2MASS XSC, WISExSCOS, SDSS-DR16Q). `f_dL`: 1 corrimiento FOTOMETRICO, 2 distancia medida,
//     3 corrimiento ESPECTROSCOPICO (ReadMe de VizieR, nota 3, leida el 20-oct-2026).
//   · Quaia (Storey-Fisher et al. 2024, ApJ 964, 69; VizieR J/ApJ/964/69, G < 20,0): cuasares de Gaia DR3 limpiados con
//     unWISE y con corrimiento al rojo calibrado contra SDSS, con su error (`e_zQuaia`). Se prefiere a la tabla cruda de
//     candidatos de Gaia DR3 (I/356/qsocand, pureza baja). Ver Cabra3D/docs/profundidad_y_objetos.md.
// ============================================================================

var CSH_DEPTH = {
   BIN: 0.25,              // encargo: la completitud por tramos de 0,25 mag de G
   BIN_MIN_N: 8,           // diseño: un tramo con menos estrellas aisladas no dice nada
   BIN_MAX_N: 250,         // diseño: estrellas que se miden por tramo como mucho (el coste: 44 tramos de G 10 a 21)
   SNR_DET: 5,             // diseño: «detectada» = señal / ruido >= 5 en la apertura en la posicion de Gaia
   SNR_POS: 5,             // diseño: un objeto (o una estrella cerca del limite) «se ve» en su sitio con la MISMA vara que
                           //   la profundidad, S/R >= 5. Primera version, 3 sigmas (20-oct-2026): en Abell 39, con G50 = 20,0,
                           //   pasaban cuasares de G 20,7-20,9 con S/R 3,5: estadisticamente estan, pero no «se ven». (`fp3`
                           //   sigue midiendo los falsos positivos a 3 sigmas como control)
   FP_MAX: 0.1,            // diseño: si mas del 10 % de las aperturas vacias pasa SNR_POS, la prueba de pixeles no discrimina
   AP_FWHM: 0.75,          // diseño: radio de la apertura en FWHM (cerca del optimo de señal/ruido de una gaussiana, ~0,7)
   AP_MIN: 1.5,            // diseño: radio minimo, en pixeles
   ISO_CONTAM: 0.1,        // diseño: una estrella con mas del 10 % de luz ajena en su apertura no cuenta para la completitud
   BAND: 1.0,              // diseño: pasado G50 + 1 mag no se mira nada (ni estrellas ni objetos): no se ve
   EMPTY_N: 800,           // diseño: aperturas al azar para medir el ruido de verdad y los falsos positivos
   SB_BOX_ARCSEC: 10,      // Roman et al. 2020
   SB_NSIGMA: 3,           // Roman et al. 2020
   SB_BOXES: 400,          // diseño
   ZP_MIN_SNR: 20,         // diseño: estrellas que fijan el punto cero (como PHOT_MIN_SNR del motor)
   SLOPE_TOL: 0.05,        // = CP_SF.PHOT_SLOPE_TOL: una imagen LINEAL da pendiente 1 de G frente a la magnitud medida
   EXT_FWHM: 2,            // diseño: un objeto de menos de 2 FWHM de eje mayor se trata como puntual
   GAL_GR: [0.3, 1.0],     // Shimasaku et al. 2001, tabla 1 (ver cabecera)
   PT_GR: [0.0, 0.6],      // diseño, NO VERIFICADO (ver cabecera)
   MATCH_PT_ARCSEC: 1.5,   // diseño: el mismo objeto puntual en dos catalogos
   MATCH_EXT_FRAC: 0.25,   // diseño: una galaxia casa dentro de un cuarto de su eje mayor (y nunca menos de 3")
   MATCH_EXT_MIN: 3,
   MATCH_GAL_ARCSEC: 2.5,  // diseño: la fuente de Gaia de una galaxia sin tamaño (su nucleo) cae a menos de 2,5" de su posicion
   OBVIOUS: 2.5,           // diseño: G <= G90 - 2,5 (diez veces la luz de una estrella al 90 %) se da por visto sin mirar
   GAL_PENALTY: 1.5,       // diseño: sin pixeles, una galaxia se da por vista si es 1,5 mag (x4) mas brillante que G90
   GAL_AP: 2,              // diseño: apertura de una galaxia sin tamaño, en radios de la de las estrellas
   // --- LO QUE SE VE A OJO (23-oct-2026, queja de Nino: «aparece un circulo donde deberian estar pero no los diferencio del
   // ruido»). S/R >= 5 dice que la luz ESTA (estadistica: 1 de 300 sitios vacios), no que se VEA. MEDIDO a ojo, a ciegas, en
   // los recortes tal como los pinta Cabra3D (tests/c3_vis_probe.js; tests/out/vis/<foto>_ojo.txt): de 384 objetos pintados
   // (Abell 39, NGC 1560, Pleyades), «nada» en su sitio el 87 % a S/R 5-7, el 47 % a 7-10, el 13 % a 10-12, el 4 % a 12-14 y
   // ninguno desde 14; «claro» solo desde ~20-25. Con fuentes INYECTADAS con la PSF de la foto: desde S/R 10, nunca «nada».
   // Los sitios vacios de control, todos «nada». El detector, con esta vara, recupera el 50 % de lo inyectado a S/R 12,9-13,4
   // y ningun sitio vacio de 6 000 (tests/c3_vis_control.js). Ver Cabra3D/docs/lo_que_se_ve.md. El ojo es el de Claude:
   // si Nino quiere solo lo que se ve CLARO, la vara es ~20.
   SNR_VIS: 12,            // MEDIDO (ver arriba y el doc): «se ve» = S/R >= 12 en su sitio Y frente al ruido de su alrededor
   // (24-oct-2026, decision D1 = A' de Nino) entre SNR_VIS y SNR_CLEAR lo que se pinta es «debil»: se ve si se mira el anillo, ampliado.
   // MEDIDO a ojo (docs/lo_que_se_ve.md §2): «clara» solo desde S/R ~20-25 (5 % a 17-20, 30 % a 20-25, 94 % desde 25); por debajo, una mancha.
   // Se pinta igual (la vara sigue en SNR_VIS) pero con el anillo y el punto mas tenues y la palabra «debil» con su S/R en la ficha.
   SNR_CLEAR: 20,          // MEDIDO (ver arriba): desde aqui, «claro»; entre SNR_VIS y esto, «debil» (`cshDepthFaintSnr`)
   VIS_MAG_MARGIN: 0.5,    // diseño: sin pixeles limpios (una estrella al lado), solo se da por visto lo que su catalogo pone
                           //   0,5 mag (x1,6) mas brillante que el G90 «a ojo» (gVis90)
   BIG_SEMI_FWHM: 8        // diseño: una galaxia de semieje mayor que 8 FWHM no cabe en la prueba de pixeles (su apertura
                           //   y su anillo caerian dentro de su propio disco): decide su magnitud y su brillo superficial
};
// La costura del rojo (C3V_BREAK=vis en las pruebas): apagado, todo vuelve a la vara de S/R 5 de antes del 23-oct-2026.
var CSH_DEPTH_VIS_ON = true;

// Las relaciones de Gaia (EDR3 §5.5.1, tablas 5.6 y 5.7): coeficientes de x^0, x^1, …; x = BP-RP salvo GV_BV (x = B-V).
var CSH_GAIA_REL = {
   GV:    { c: [-0.02704, 0.01424, -0.2156, 0.01426], lo: -0.5, hi: 5.0, sigma: 0.03017 },
   GR:    { c: [-0.02275, 0.3961, -0.1243, -0.01396, 0.003775], lo: 0.0, hi: 4.0, sigma: 0.03167 },
   Gg:    { c: [0.2199, -0.6365, -0.1548, 0.0064], lo: 0.3, hi: 3.0, sigma: 0.0745 },
   Gr:    { c: [-0.09837, 0.08592, 0.1907, -0.1701, 0.02263], lo: 0.0, hi: 3.0, sigma: 0.03776 },
   GV_BV: { c: [-0.04749, -0.0124, -0.2901, 0.02008], lo: 0.0, hi: 3.3, sigma: 0.04772 }     // (de -0,4 a 0 no es monotona: se usa desde 0)
};

function cshPoly(c, x) { var s = 0; for (var i = c.length - 1; i >= 0; --i) s = s * x + c[i]; return s; }

// Biseccion de f(x) = y en [a, b] (f monotona). null si y no cae entre f(a) y f(b).
function cshSolve(f, y, a, b) {
   var fa = f(a) - y, fb = f(b) - y;
   if (!isFinite(fa) || !isFinite(fb) || fa * fb > 0) return null;
   for (var i = 0; i < 60; ++i) {
      var m = (a + b) / 2, fm = f(m) - y;
      if (fa * fm <= 0) { b = m; fb = fm; } else { a = m; fa = fm; }
   }
   return (a + b) / 2;
}

// B-V para un BP-RP: el que da la misma G-V por las dos relaciones. null fuera de su validez.
function cshBvOfX(x) {
   var gv = cshPoly(CSH_GAIA_REL.GV.c, x);
   return cshSolve(function(bv) { return cshPoly(CSH_GAIA_REL.GV_BV.c, bv); }, gv, CSH_GAIA_REL.GV_BV.lo, CSH_GAIA_REL.GV_BV.hi);
}
// g-r para un BP-RP: (G-r) - (G-g).
function cshGrOfX(x) { return cshPoly(CSH_GAIA_REL.Gr.c, x) - cshPoly(CSH_GAIA_REL.Gg.c, x); }

// G - banda, para el color x = BP-RP. band: "G" | "V" | "R" | "g" | "r" | "B". null si no hay relacion o x se sale.
function cshGMinus(band, x) {
   if (band === "G") return 0;
   var R = CSH_GAIA_REL;
   function inRange(rel) { return x >= rel.lo - 1e-9 && x <= rel.hi + 1e-9; }
   if (band === "V") return inRange(R.GV) ? cshPoly(R.GV.c, x) : null;
   if (band === "R") return inRange(R.GR) ? cshPoly(R.GR.c, x) : null;
   if (band === "g") return inRange(R.Gg) ? cshPoly(R.Gg.c, x) : null;
   if (band === "r") return inRange(R.Gr) ? cshPoly(R.Gr.c, x) : null;
   if (band === "B") {
      if (!inRange(R.GV)) return null;
      var bv = cshBvOfX(x);
      return (bv === null) ? null : cshPoly(R.GV.c, x) - bv;      // G - B = (G - V) - (B - V)
   }
   return null;
}

// EL COLOR x = BP-RP de un objeto: medido (g y r, o B y V) si los tiene; si no, el intervalo de su clase.
// -> { lo, hi, measured, from }. Fuera de lo que cubren las relaciones, se recorta a [0,3; 3,0] (validez de G-g).
function cshColorX(mags, cls) {
   var m = mags || {}, x, lo = 0.3, hi = 3.0;
   function clip(v) { return Math.max(lo, Math.min(hi, v)); }
   if (isFinite(m.g) && isFinite(m.r) && m.g !== null && m.r !== null) {
      x = cshSolve(cshGrOfX, m.g - m.r, lo, hi);
      if (x !== null) return { lo: x, hi: x, measured: true, from: "g-r" };
   }
   if (isFinite(m.B) && isFinite(m.V) && m.B !== null && m.V !== null) {
      var gv = cshPoly(CSH_GAIA_REL.GV_BV.c, Math.max(CSH_GAIA_REL.GV_BV.lo, Math.min(CSH_GAIA_REL.GV_BV.hi, m.B - m.V)));
      x = cshSolve(function(t) { return cshPoly(CSH_GAIA_REL.GV.c, t); }, gv, lo, hi);
      if (x !== null) return { lo: x, hi: x, measured: true, from: "B-V" };
   }
   var gr = (cls === "galaxy" || cls === "galaxy-part" || cls === "galaxy-group") ? CSH_DEPTH.GAL_GR : CSH_DEPTH.PT_GR;
   var a = cshSolve(cshGrOfX, gr[0], lo, hi), b = cshSolve(cshGrOfX, gr[1], lo, hi);
   return { lo: (a === null) ? lo : clip(a), hi: (b === null) ? hi : clip(b), measured: false, from: "class " + (gr === CSH_DEPTH.GAL_GR ? "galaxy" : "point") };
}

// LA MAGNITUD G DE UN OBJETO a partir de lo que trae su catalogo. `mags` = { G, B, V, R, g, r } (null o ausente = no la
// tiene). Orden: para lo PUNTUAL, G (la de Gaia ES la de la foto), luego r, g, V, R, B; para lo EXTENSO, r, g, V, R, B —
// la G de Gaia de una galaxia es la de su nucleo (ventana de pocos segundos: 2MASX J16283210+2753141 tiene G 19,9 y
// r 17,3 en SIMBAD) y solo se usa si no hay otra, como cota por abajo del brillo (`coreOnly`).
// -> { g (centro), lo, hi (el intervalo por el color), band, m, coreOnly, x } o null si no tiene ninguna.
// (28-oct-2026, con A: el tamaño de OpenNGC) LA FOTOMETRIA DE SDSS DE UNA GALAXIA GRANDE ESTA TROCEADA: el r y el g de SIMBAD de M 82 son los
// de un trozo (r 15,66 y g 17,32 frente a V 8,41 y B 9,3: medido el 28-oct en el espejo de Harvard). Con su tamaño (11′), el brillo
// superficial de r 15,7 en esa elipse salia «demasiado difuso» y la profundidad ESCONDIA M 82. En una galaxia normal r es ~0,3 mag MAS
// brillante que V y g que B; si el de SDSS es SDSS_SHRED mag MAS DEBIL que su pareja de Johnson, g y r no se usan (ni para el color).
// Costura del rojo: CSH_DEPTH_SDSS_SHRED = false.
var CSH_DEPTH_SDSS_SHRED = true, CSH_DEPTH_SHRED_MAG = 1.5;      // diseño: margen holgado (los colores de galaxia dan −0,3…−1)
function cshObjSdssShredded(m) {
   if (CSH_DEPTH_SDSS_SHRED !== true || !m) return false;
   function ok(v) { return v !== null && v !== undefined && isFinite(v); }
   return (ok(m.r) && ok(m.V) && m.r - m.V > CSH_DEPTH_SHRED_MAG) || (ok(m.g) && ok(m.B) && m.g - m.B > CSH_DEPTH_SHRED_MAG);
}
function cshObjG(mags, cls, extended) {
   var m = mags || {};
   if (extended && cshObjSdssShredded(m)) { var m2 = {}; for (var kk in m) if (Object.prototype.hasOwnProperty.call(m, kk) && kk !== "g" && kk !== "r") m2[kk] = m[kk]; m = m2; }
   var order = extended ? ["r", "g", "V", "R", "B", "G"] : ["G", "r", "g", "V", "R", "B"];
   var cx = cshColorX(m, cls);
   for (var i = 0; i < order.length; ++i) {
      var b = order[i], v = m[b];
      if (v === null || v === undefined || !isFinite(v)) continue;
      var lo = Infinity, hi = -Infinity;
      for (var k = 0; k <= 4; ++k) {
         var x = cx.lo + (cx.hi - cx.lo) * k / 4, d = cshGMinus(b, x);
         if (d === null) continue;
         if (v + d < lo) lo = v + d;
         if (v + d > hi) hi = v + d;
      }
      if (!(lo <= hi)) continue;
      return { g: (lo + hi) / 2, lo: lo, hi: hi, band: b, m: v, coreOnly: (extended && b === "G"), x: cx };
   }
   return null;
}

// EL BRILLO SUPERFICIAL MEDIO de una galaxia de magnitud total `m` y ejes `majArcmin` × `minArcmin` (minutos de arco;
// sin el menor, circular): m + 2,5 log10(area de la elipse en segundos de arco cuadrados). null sin tamaño.
function cshMeanSb(m, majArcmin, minArcmin) {
   if (!isFinite(m) || !(majArcmin > 0)) return null;
   var a = majArcmin * 60, b = (minArcmin > 0) ? minArcmin * 60 : a;
   return m + 2.5 * Math.log(Math.PI * a * b / 4) / Math.LN10;
}

// mu_lim(n sigma; caja de lado `boxArcsec`) a partir del ruido de la media de una caja `sigmaBox` (en unidades de pixel),
// la escala `scale` ("/px) y el punto cero ZP (G = ZP - 2,5 log10 flujo): ZP - 2,5 log10( n sigmaBox / scale^2 ).
// Y la de Roman et al. 2020 con el ruido por pixel (`sigmaPix`, sin correlacion): ZP - 2,5 log10( n sigmaPix / (scale · box) ).
function cshSbLimit(zp, sigmaBox, scale, nSigma) {
   if (!isFinite(zp) || !(sigmaBox > 0) || !(scale > 0)) return null;
   return zp - 2.5 * Math.log((nSigma || CSH_DEPTH.SB_NSIGMA) * sigmaBox / (scale * scale)) / Math.LN10;
}
function cshSbLimitRoman(zp, sigmaPix, scale, boxArcsec, nSigma) {
   if (!isFinite(zp) || !(sigmaPix > 0) || !(scale > 0)) return null;
   return zp - 2.5 * Math.log((nSigma || CSH_DEPTH.SB_NSIGMA) * sigmaPix / (scale * (boxArcsec || CSH_DEPTH.SB_BOX_ARCSEC))) / Math.LN10;
}

// ---------------------------------------------------------------------------
// LA COMPLETITUD. `samples` = [ { g, det } ] (det: la estrella de Gaia se ve en la foto). `fp` = la fraccion de
// aperturas VACIAS que pasan el mismo umbral (falsos positivos: una estrella que no se ve puede «verse» por azar).
// Por tramo de BIN mag: n, k (detectadas), frac = k/n, y la corregida (frac - fp) / (1 - fp). Luego una curva NO
// CRECIENTE con G (regresion isotonica, pool-adjacent-violators, pesos n): la completitud no puede subir hacia lo debil;
// lo que lo hace es ruido de pocas estrellas. G50 y G90: donde esa curva cruza 0,5 y 0,9 (interpolacion lineal entre
// centros de tramo). Si no baja de 0,5 hasta el ultimo tramo con estrellas, G50 es una COTA (la foto llega mas hondo
// que el catalogo): `lower50` true y g50 = el centro del ultimo tramo. Lo mismo para 0,9.
// -> { ok, code, bins: [ { g, n, k, frac, fracCorr, iso } ], g50, g90, lower50, lower90, nUsed, gMax }
// ---------------------------------------------------------------------------
function cshDepthLimits(samples, fp, opts) {
   var o = opts || {}, W = (o.bin > 0) ? o.bin : CSH_DEPTH.BIN, minN = (o.minN > 0) ? o.minN : CSH_DEPTH.BIN_MIN_N;
   var f0 = (fp > 0 && fp < 0.5) ? fp : 0;
   var out = { ok: false, code: "", bins: [], g50: null, g90: null, lower50: false, lower90: false, nUsed: 0, gMax: null, fp: f0 };
   var by = {}, keys = [], i;
   for (i = 0; samples && i < samples.length; ++i) {
      var s = samples[i];
      if (!s || !isFinite(s.g)) continue;
      var key = Math.floor(s.g / W);
      if (!by[key]) { by[key] = { n: 0, k: 0 }; keys.push(key); }
      ++by[key].n;
      if (s.det) ++by[key].k;
   }
   keys.sort(function(a, b) { return a - b; });
   for (i = 0; i < keys.length; ++i) {
      var b = by[keys[i]];
      if (b.n < minN) continue;
      var fr = b.k / b.n, fc = Math.max(0, Math.min(1, (fr - f0) / (1 - f0)));
      out.bins.push({ g: (keys[i] + 0.5) * W, n: b.n, k: b.k, frac: fr, fracCorr: fc, iso: fc });
      out.nUsed += b.n;
   }
   if (out.bins.length < 3) { out.code = "few-bins"; return out; }
   // pool-adjacent-violators: no creciente
   var blocks = [];
   for (i = 0; i < out.bins.length; ++i) {
      blocks.push({ v: out.bins[i].fracCorr, w: out.bins[i].n, from: i, to: i });
      while (blocks.length > 1 && blocks[blocks.length - 2].v < blocks[blocks.length - 1].v) {
         var q = blocks.pop(), p = blocks.pop();
         blocks.push({ v: (p.v * p.w + q.v * q.w) / (p.w + q.w), w: p.w + q.w, from: p.from, to: q.to });
      }
   }
   for (var bk = 0; bk < blocks.length; ++bk) for (i = blocks[bk].from; i <= blocks[bk].to; ++i) out.bins[i].iso = blocks[bk].v;
   function cross(level) {
      var B = out.bins;
      if (B[0].iso < level) return { g: B[0].g, lower: false, above: false };        // ya el primer tramo esta por debajo
      for (var j = 1; j < B.length; ++j)
         if (B[j].iso < level) {
            var a = B[j - 1], c = B[j], t = (a.iso - level) / Math.max(1e-9, a.iso - c.iso);
            return { g: a.g + t * (c.g - a.g), lower: false };
         }
      return { g: B[B.length - 1].g, lower: true };
   }
   var c50 = cross(0.5), c90 = cross(0.9);
   out.g50 = c50.g; out.lower50 = c50.lower; out.g90 = c90.g; out.lower90 = c90.lower;
   if (out.g90 > out.g50) out.g90 = out.g50;
   out.gMax = out.bins[out.bins.length - 1].g;
   out.ok = true;
   return out;
}

// ---------------------------------------------------------------------------
// EL VEREDICTO de un objeto del cielo profundo. `ob` = { cls, inFrame, mags, sizeArcmin, minArcmin }; `D` = la
// profundidad ({ g50, lower50, sbLim, fwhmArcsec }). Devuelve { state, reason, est, sb, extended } con
//   state "outside" (fuera de la foto) · "keep" (no se le aplica la profundidad: nebulosas, planetarias, cumulos de
//   estrellas y asociaciones —su catalogo da la estrella central o nada; los cumulos se ven por sus estrellas—, o la
//   foto no tiene profundidad medida) · "visible" · "faint" · "check" (deciden los pixeles en su posicion,
//   csh_depth_run.js)
//   reason "outside" | "no-depth-test" | "no-depth" | "bright-enough" | "too-faint" | "below-sb-limit" | "near-limit" |
//   "no-magnitude"
// LAS REGLAS (la misma vara que las estrellas: lo que se da por visto sin mirar es lo que la foto ve al 90 %):
//   · mas debil que G50 + 1 por su catalogo (lo mas brillante que le dé el color): no se ve, sin mirar;
//   · extensa con tamaño y brillo superficial medio mas de 1 mag por debajo del limite: demasiado difusa;
//   · OBVIAMENTE brillante —G <= G90 - 2,5, diez veces la luz de una estrella al 90 %—: se ve, sin mirar (asi NGC 1560, de
//     10' y G 11, no depende de que su nucleo destaque sobre su propio disco);
//   · todo lo demas, a los PIXELES (S/R >= 5 en su sitio). Primera version (20-oct-2026): se daba por visto todo lo que su
//     catalogo ponia por encima de G50, y en los recortes de Abell 39 y NGC 1560 la mitad de esas galaxias de GLADE+
//     (G 18,3-19,5 por su B) NO SE VEIAN: una galaxia reparte su luz y la apertura de una estrella coge una parte.
// ---------------------------------------------------------------------------
var CSH_DEPTH_EXEMPT = { "nebula": true, "planetary-nebula": true, "star-cluster": true, "association": true };
function cshDepthVerdict(ob, D) {
   var out = { state: "keep", reason: "", est: null, sb: null, extended: false };
   if (!ob.inFrame) { out.state = "outside"; out.reason = "outside"; return out; }
   if (CSH_DEPTH_EXEMPT[String(ob.cls || "")] === true) { out.reason = "no-depth-test"; return out; }
   if (!D || !(D.g50 > 0)) { out.reason = "no-depth"; return out; }
   var ext = (ob.cls !== "quasar" && ob.sizeArcmin > 0 && D.fwhmArcsec > 0 && ob.sizeArcmin * 60 >= CSH_DEPTH.EXT_FWHM * D.fwhmArcsec);
   out.extended = ext;
   out.galaxy = (ob.cls === "galaxy" || ob.cls === "galaxy-part" || ob.cls === "galaxy-group");
   // (una GALAXIA va siempre por sus bandas de luz total —r, g, V, R, B— aunque SIMBAD no de su tamaño: la G de Gaia es la de
   // su nucleo. Primera version, 20-oct-2026: sin tamaño se tomaba por puntual y SDSS J162728.92+275118.1 —r 17,7, G 21,4—
   // salia «demasiado debil» en Abell 39)
   var galaxyLike = (ob.cls === "galaxy" || ob.cls === "galaxy-part" || ob.cls === "galaxy-group");
   var est = cshObjG(ob.mags, ob.cls, galaxyLike || ext || (ob.cls !== "quasar" && ob.sizeArcmin > 0));
   out.est = est;
   if (est === null) { out.state = "check"; out.reason = "no-magnitude"; return out; }
   var lim = D.g50, band = CSH_DEPTH.BAND, g90 = (D.g90 > 0) ? D.g90 : D.g50;
   if (ext && D.sbLim > 0 && !est.coreOnly) out.sb = cshMeanSb(est.g, ob.sizeArcmin, ob.minArcmin);
   // (la G del nucleo de Gaia es una cota POR ABAJO del brillo: nunca dice «demasiado debil»)
   if (!est.coreOnly && !D.lower50 && est.lo > lim + band) { out.state = "faint"; out.reason = "too-faint"; return out; }
   if (out.sb !== null && out.sb - D.sbLim > band) { out.state = "faint"; out.reason = "below-sb-limit"; return out; }
   // (23-oct-2026, lo que se ve A OJO: el «obvio sin mirar» solo vale para lo que no cabe en la prueba de pixeles —una galaxia
   // de semieje > BIG_SEMI_FWHM FWHM, como NGC 1560—; todo lo demas, por brillante que lo ponga su catalogo, a los pixeles: un
   // cuasar varia y una B de placa de GLADE+ puede errar en una magnitud)
   out.big = ext && ob.sizeArcmin * 30 > CSH_DEPTH.BIG_SEMI_FWHM * D.fwhmArcsec;
   if (est.hi <= g90 - CSH_DEPTH.OBVIOUS && (CSH_DEPTH_VIS_ON !== true || out.big)) { out.state = "visible"; out.reason = "bright-enough"; return out; }
   out.state = "check"; out.reason = "near-limit";
   return out;
}

// La decision de un «check» con lo que dijeron los pixeles. `px` = { snr, contaminated, trusted, noData } o null (no se
// pudo mirar: el borde, sin foto). En su sitio NO HAY FOTO (el borde negro de un apilado): fuera («outside»). Sin prueba de
// pixeles fiable (una estrella al lado, o la foto da falsos positivos): con magnitud, la misma vara que las estrellas sin
// mirar —se ve si llega a G90; una galaxia, 1,5 mag mas brillante, porque reparte su luz—; sin magnitud, no se pone
// («not-verifiable»: nunca se coloca un objeto que no se sabe si esta).
// -> { visible, reason ("detected" | "not-detected" | "by-magnitude" | "too-faint" | "not-verifiable" | "no-data") }
// (23-oct-2026) LO QUE SE VE A OJO (CSH_DEPTH_VIS_ON): la vara es CSH_DEPTH.SNR_VIS sobre `px.snrVis` —el menor de S/R
// frente al ruido de la foto y S/R frente al ruido de SU alrededor (csh_depth_run.js `cshDepthSeenAt`)—, y sin pixeles
// limpios la magnitud se compara con el G90 «a ojo» (`D.gVis90`, la G a la que el 90 % de las estrellas de Gaia aisladas
// llega a SNR_VIS) menos VIS_MAG_MARGIN. Una prueba de pixeles en la que caben 3 sigmas de falsos positivos no vale (`trusted`).
function cshDepthResolve(verdict, px, D) {
   if (px && px.noData) return { visible: false, reason: "no-data" };
   var vis = (CSH_DEPTH_VIS_ON === true);
   var s = (vis && px && px.snrVis !== undefined && px.snrVis !== null) ? px.snrVis : (px ? px.snr : null);
   var usable = (px && px.trusted && !px.contaminated && (s === Infinity || isFinite(s)));
   if (usable) return (s >= (vis ? CSH_DEPTH.SNR_VIS : CSH_DEPTH.SNR_POS)) ? { visible: true, reason: "detected" } : { visible: false, reason: "not-detected" };
   var g90 = (D.g90 > 0) ? D.g90 : D.g50;
   if (vis) g90 = ((D.gVis90 > 0) ? D.gVis90 : g90) - CSH_DEPTH.VIS_MAG_MARGIN;
   if (verdict.est) return (verdict.est.hi <= g90 - (verdict.galaxy ? CSH_DEPTH.GAL_PENALTY : 0)) ? { visible: true, reason: "by-magnitude" } : { visible: false, reason: "not-verifiable" };
   return { visible: false, reason: "not-verifiable" };
}

// (24-oct-2026, D1 = A') ¿Se pinta pero apenas se ve? `depth` = `ob.depth` de un objeto de lo lejano. Devuelve su S/R (la que decidio: la menor
// frente al ruido de su zona y de su alrededor) si se midio en los pixeles y cae en [SNR_VIS, SNR_CLEAR); si no, null. Lo que se da por
// visto sin pixeles (brillante por su magnitud, galaxia grande, el catalogo manda) NO se marca: no hay S/R medida que decirle.
function cshDepthFaintSnr(depth) {
   if (CSH_DEPTH_VIS_ON !== true || !depth || depth.reason !== "detected") return null;
   var s = depth.snrVis;
   if (s === undefined || s === null || !isFinite(s)) return null;
   return (s >= CSH_DEPTH.SNR_VIS && s < CSH_DEPTH.SNR_CLEAR) ? s : null;
}

// (26-oct-2026, A'b de Nino) Lo mismo para una ESTRELLA de la foto: `star` = un elemento de `res.stars`. `star.snrVis` lo deja la poda
// (`cshDepthPruneVis`, csh_depth_run.js): la menor S/R frente al ruido de su zona y de su alrededor, medida en los pixeles. Una estrella que la poda no
// midio (brillante por su G, con una vecina que le mete luz, saturada) no lleva S/R: no se marca. Devuelve esa S/R si cae en [SNR_VIS, SNR_CLEAR); si no, null.
function cshDepthStarFaintSnr(star) {
   if (CSH_DEPTH_VIS_ON !== true || !star) return null;
   var s = star.snrVis;
   if (s === undefined || s === null || !isFinite(s)) return null;
   return (s >= CSH_DEPTH.SNR_VIS && s < CSH_DEPTH.SNR_CLEAR) ? s : null;
}

// ---------------------------------------------------------------------------
// LA DISTANCIA DE UN CORRIMIENTO AL ROJO CON SU ERROR (fotometrico o del catalogo). El intervalo es z ± dz con
// dz = raiz( zErr^2 + (v_pec/c)^2 ) (la velocidad peculiar de cpSfRedshiftDistance, como cota por debajo). La fraccion se
// mide sobre las distancias (comoviles) y, como en el resto del motor, pasada del 20 % la distancia es «unreliable»: se
// pinta, marcada (no se borra: es la mejor que hay). -> la misma forma que cpSfRedshiftDistance, con `zErr` y `ref`.
function cshRedshiftDistanceErr(z, zErr, ref, kind) {
   if (!(z > 0) || !isFinite(z)) return null;
   var vp = CP_SF.VPEC_KMS / (CP_SF.C_M_S / 1000), e = (zErr > 0 && isFinite(zErr)) ? zErr : 0;
   // (27-oct-2026, T2 H-5 de Codex) La misma omision que en cpSfRedshiftDistance: la velocidad peculiar compone con el corrimiento cosmologico,
   // sigma_z = (1+z)·v/c. Solo ella: el error del corrimiento (zErr) ya esta en el z observado.
   vp *= (1 + z);
   var dz = Math.sqrt(e * e + vp * vp);
   // (24-oct-2026, H1 de Gemini, decision de Nino) UN SOLO CRITERIO: SIN DISTANCIA SI EL INTERVALO DE ERROR LLEGA A z <= 0. Si z - dz <= 0
   // el corrimiento no dice a que distancia esta (solo que no es lejana): la barra bajaria al suelo y saldria de ruido (GLADE+ fotometrico
   // z = 0,0246 con e_zhelio 0,0339 -> barra de 4 448 pc a 257 Mpc, factor 57 726). Cubre tambien z <= v_pec/c (dz >= vp). Solo corrimientos:
   // una distancia MEDIDA de GLADE+ (f_dL = 2) no pasa por aqui.
   if (z - dz <= 0) return null;
   var mid = cpSfCosmo(z), lo = cpSfCosmo(z - dz), hi = cpSfCosmo(z + dz);
   if (!mid || !lo || !hi) return null;
   // (26-oct-2026, F1b de Nino) SEGUNDO CORTE, del mismo criterio: tampoco hay distancia si la barra de error pasa de ×10 (hi/lo > MAX_BAR_RATIO). z - dz <= 0
   // solo quitaba lo que llegaba a cero; un fotometrico de GLADE+ con z - dz apenas positivo (Abell 39: ×92, ×22, ×11) seguia con una barra que no dice nada.
   if (hi.comovingPc / lo.comovingPc > CP_SF.MAX_BAR_RATIO) return null;
   var frac = (hi.comovingPc - lo.comovingPc) / (2 * mid.comovingPc);
   return { pc: mid.comovingPc, lo: lo.comovingPc, hi: hi.comovingPc, source: "redshift", kind: kind || "redshift",
            quality: (frac > CP_SF.MAX_FRACTION) ? "unreliable" : "good", fraction: frac,
            interval: (e > 0) ? "redshift error + peculiar velocity 240 km/s" : "peculiar velocity 240 km/s (lower bound)",
            z: z, zErr: e, lookbackYr: mid.lookbackYr, lookbackLoYr: lo.lookbackYr, lookbackHiYr: hi.lookbackYr,
            comovingPc: mid.comovingPc, luminosityPc: mid.luminosityPc, ref: (ref || "") + " · " + CP_SF.COSMOLOGY };
}

// ---------------------------------------------------------------------------
// GLADE+ (VizieR VII/291/gladep): galaxias y cuasares con distancia. Solo los que tienen corrimiento o distancia
// (f_dL > 0). Nombres de columna con «+» y «-» van entre comillas dobles.
// ---------------------------------------------------------------------------
function cshGladeAdql(ra, dec, radiusDeg) {
   return "SELECT \"GLADE+\",PGC,HyperLEDA,\"2MASS\",WISExSCOS,\"SDSS-DR16Q\",Type,RAJ2000,DEJ2000,\"Bmag\",f_Bmag,W1mag,zhelio,zcmb,e_zhelio,dL,e_dL,f_dL " +
          "FROM \"VII/291/gladep\" WHERE 1=CONTAINS(POINT('ICRS',RAJ2000,DEJ2000),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND f_dL>0";
}
// (GLADE+ escribe «-» —con espacios delante— en los nombres que no tiene: eso es «vacio»)
function cshTrim(s) { var t = String((s === null || s === undefined) ? "" : s).replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); return (t === "-") ? "" : t; }
// -> [ objeto como los de cpSfSimbadObjects: { name, ra, dec, cls, extragalactic, z, dist, mags, sizeArcmin, catalog, … } ]
function cshGladeObjects(csvText) {
   var t = cpSfParseTable(csvText, ","), out = [];
   for (var i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], ra = cpSfNum(r.RAJ2000), dec = cpSfNum(r.DEJ2000), fd = cpSfNum(r.f_dL);
      if (ra === null || dec === null || !(fd > 0)) continue;
      var isQ = (cshTrim(r.Type) === "Q");
      var pgc = cpSfNum(r.PGC), name = "";
      if (pgc !== null && pgc > 0) name = "PGC " + pgc;
      else if (cshTrim(r.HyperLEDA).length) name = cshTrim(r.HyperLEDA);
      else if (cshTrim(r["SDSS-DR16Q"]).length) name = "SDSS J" + cshTrim(r["SDSS-DR16Q"]).replace(/^J/, "");
      else if (cshTrim(r["2MASS"]).length) name = "2MASX J" + cshTrim(r["2MASS"]).replace(/^J/, "");
      else if (cshTrim(r.WISExSCOS).length) name = "WISExSCOS " + cshTrim(r.WISExSCOS);
      else name = "GLADE+ " + cshTrim(r["GLADE+"]);
      var zc = cpSfNum(r.zcmb), zh = cpSfNum(r.zhelio), z = (zc !== null && zc > 0) ? zc : zh, ez = cpSfNum(r.e_zhelio), dist = null;
      var kind = (fd === 1) ? "photo-z" : (fd === 3) ? "spec-z" : "distance";
      if (fd === 2) {
         // una distancia MEDIDA (de luminosidad, en Mpc): se pasa a comovil con su z (la que GLADE+ calcula de ella)
         var dl = cpSfNum(r.dL), edl = cpSfNum(r.e_dL), k = (z > 0) ? 1 / (1 + z) : 1;
         if (dl !== null && dl > 0) {
            var e = (edl !== null && edl > 0) ? edl : 0, pc = dl * 1e6 * k;
            dist = { pc: pc, lo: Math.max(0, (dl - e) * 1e6 * k), hi: (dl + e) * 1e6 * k, source: "glade", kind: "distance", quality: (e / dl > CP_SF.MAX_FRACTION) ? "unreliable" : "good",
                     fraction: e / dl, interval: (e > 0) ? "error of the measurement" : "no error declared", z: z, ref: "GLADE+ (Dalya et al. 2022): measured luminosity distance" };
         }
      } else if (z !== null && z > 0)
         dist = cshRedshiftDistanceErr(z, ez, "GLADE+ (Dalya et al. 2022): " + ((fd === 1) ? "photometric redshift" : "spectroscopic redshift"), kind);
      if (dist === null) continue;
      dist.source = "glade";
      var B = cpSfNum(r.Bmag);
      out.push({ name: name, ra: ra, dec: dec, x: null, y: null, otype: isQ ? "QSO" : "G", cls: isQ ? "quasar" : "galaxy", extragalactic: true, candidate: false, agn: isQ,
                 sizeArcmin: null, minArcmin: null, z: z, zKind: kind, dist: dist, direct: null, redshift: dist, measures: [],
                 // (B medida —f_Bmag 0— o calculada de la B_J de SuperCOSMOS —f_Bmag 1—: las dos son una B, la segunda peor)
                 mags: { B: B, BfromBj: (B !== null && cpSfNum(r.f_Bmag) === 1), W1: cpSfNum(r.W1mag) },
                 catalog: "GLADE+", gladeId: cshTrim(r["GLADE+"]) });
   }
   return out;
}

// QUAIA (VizieR J/ApJ/964/69/quaiag200, G < 20,0): cuasares con su corrimiento al rojo y su error.
function cshQuaiaAdql(ra, dec, radiusDeg) {
   return "SELECT GaiaDR3,RA_ICRS,DE_ICRS,zQuaia,e_zQuaia,Gmag,BPmag,RPmag FROM \"J/ApJ/964/69/quaiag200\" " +
          "WHERE 1=CONTAINS(POINT('ICRS',RA_ICRS,DE_ICRS),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + "))";
}
function cshQuaiaObjects(csvText) {
   var t = cpSfParseTable(csvText, ","), out = [];
   for (var i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], ra = cpSfNum(r.RA_ICRS), dec = cpSfNum(r.DE_ICRS), z = cpSfNum(r.zQuaia);
      if (ra === null || dec === null || !(z > 0)) continue;
      var dist = cshRedshiftDistanceErr(z, cpSfNum(r.e_zQuaia), "Quaia (Storey-Fisher et al. 2024): Gaia + unWISE redshift", "redshift");
      if (dist === null) continue;
      dist.source = "quaia";
      out.push({ name: "Gaia DR3 " + cshTrim(r.GaiaDR3), ra: ra, dec: dec, x: null, y: null, otype: "QSO", cls: "quasar", extragalactic: true, candidate: false, agn: true,
                 sizeArcmin: null, minArcmin: null, z: z, zKind: "quaia", dist: dist, direct: null, redshift: dist, measures: [],
                 mags: { G: cpSfNum(r.Gmag), BP: cpSfNum(r.BPmag), RP: cpSfNum(r.RPmag) }, catalog: "Quaia", sourceId: cshTrim(r.GaiaDR3) });
   }
   return out;
}

// ¿El objeto `b` (de otro catalogo) es el `a` de SIMBAD? Por posicion: los puntuales a MATCH_PT_ARCSEC; una galaxia
// dentro de un cuarto de su eje mayor (nunca menos de MATCH_EXT_MIN).
function cshSameObject(a, b) {
   var tol = CSH_DEPTH.MATCH_PT_ARCSEC;
   var big = Math.max(a.sizeArcmin > 0 ? a.sizeArcmin : 0, b.sizeArcmin > 0 ? b.sizeArcmin : 0);
   if (a.cls !== "quasar" && b.cls !== "quasar") tol = Math.max(CSH_DEPTH.MATCH_EXT_MIN, CSH_DEPTH.MATCH_EXT_FRAC * big * 60);
   return cpSfSeparation(a.ra, a.dec, b.ra, b.dec) * 3600 <= tol;
}
// UNIR: a `base` (los de SIMBAD) se le añaden los de `extra` que no estan; de los que estan, solo se toman las
// magnitudes que a SIMBAD le faltan. Modifica `base`. -> { added, matched }
function cshDepthMerge(base, extra) {
   var out = { added: 0, matched: 0 }, cell = 30 / 3600, grid = {}, i, key;
   function k2(ra, dec) { return Math.floor(dec / cell) + "," + Math.floor(ra * Math.cos(dec * Math.PI / 180) / cell); }
   for (i = 0; i < base.length; ++i) { key = k2(base[i].ra, base[i].dec); (grid[key] || (grid[key] = [])).push(i); }
   for (var e = 0; e < extra.length; ++e) {
      var b = extra[e], gy = Math.floor(b.dec / cell), gx = Math.floor(b.ra * Math.cos(b.dec * Math.PI / 180) / cell), hit = -1;
      for (var dy = -2; dy <= 2 && hit < 0; ++dy)
         for (var dx = -2; dx <= 2 && hit < 0; ++dx) {
            var list = grid[(gy + dy) + "," + (gx + dx)];
            if (!list) continue;
            for (var q = 0; q < list.length; ++q) if (cshSameObject(base[list[q]], b)) { hit = list[q]; break; }
         }
      if (hit >= 0) {
         var a = base[hit];
         a.mags = a.mags || {};
         for (var mk in b.mags) if (Object.prototype.hasOwnProperty.call(b.mags, mk) && b.mags[mk] !== null && (a.mags[mk] === null || a.mags[mk] === undefined)) a.mags[mk] = b.mags[mk];
         (a.alsoIn = a.alsoIn || []).push(b.catalog);
         ++out.matched;
         continue;
      }
      base.push(b);
      key = k2(b.ra, b.dec); (grid[key] || (grid[key] = [])).push(base.length - 1);
      ++out.added;
   }
   return out;
}

// LAS MAGNITUDES DE SIMBAD de una fila (`allfluxes`: B, V, G, R, g_, r_). null si no trae ninguna columna.
function cshSimbadMags(row) {
   if (!row || !("V" in row || "g_" in row || "B" in row)) return null;
   return { B: cpSfNum(row.B), V: cpSfNum(row.V), G: cpSfNum(row.G), R: cpSfNum(row.R), g: cpSfNum(row.g_), r: cpSfNum(row.r_) };
}

// ---------------------------------------------------------------------------
// LA LINEA DE ESTADO (encargo: «Image depth: G ≈ 18.6 (50 %), sky ≈ 22.1 mag/arcsec² · showing 1 240 stars, 14 galaxies,
// 2 quasars visible in the image (63 catalogue objects too faint, 8 outside the frame)»). `result` de cpStarfieldBuild;
// `bits` = lo que la linea ya dice (estrellas, galaxias…, del modelo de la vista). -> { bits, detail } o null si no hay
// profundidad. `T` = la funcion de traduccion (optT si existe).
// ---------------------------------------------------------------------------
// (1-nov-2026, D5) una cifra con su decimal en el idioma de la interfaz (coma en castellano; csh_view.js `cpSvFx`)
function cshDepthFx(v, d) { return (typeof cpSvFx === "function") ? cpSvFx(v, d) : Number(v).toFixed(d); }
function cshDepthGroup(n) { var s = String(Math.round(n)); return (s.length > 4) ? s.replace(/\B(?=(\d{3})+(?!\d))/g, " ") : s; }
function cshDepthSay(result, bits) {
   var D = result ? result.depth : null;
   if (!D) return null;
   var T = (typeof optT === "function") ? optT : function(s) { return s; };
   var F = (typeof format === "function") ? format : null;
   // (24-oct-2026: de cualquier numero de argumentos; con dos solo se perdia el tercero de «%s of … (S/N %s to %s)»)
   function fmt(s) {
      var a = Array.prototype.slice.call(arguments, 1), n = 0;
      if (F) return F.apply(null, [s].concat(a));
      return s.replace(/%%/g, "").replace(/%s/g, function() { return String(a[n++]); }).replace(//g, "%");
   }
   if (!D.ok) return { bits: bits, detail: T("Image depth not measured: ") + T(cshDepthWhy(D.code)) + "<br>" + T("Nothing could be checked against the photo: galaxies and quasars are shown as the catalogues give them.") };
   var vis = (CSH_DEPTH_VIS_ON === true && D.gVis50 > 0);
   // (23-oct-2026: la cabecera dice hasta donde se VE —la vara de lo que se pinta—; la profundidad estadistica, S/R 5, al detalle)
   var head = vis ? (D.lowerVis50 ? fmt(T("This photo shows stars down to G ≥ %s (deeper than the Gaia catalogue)"), cshDepthFx(D.gVis50, 1)) : fmt(T("This photo shows down to G ≈ %s"), cshDepthFx(D.gVis50, 1)))
                  : (D.lower50 ? fmt(T("Image depth: G ≥ %s (deeper than the Gaia catalogue)"), cshDepthFx(D.g50, 1)) : fmt(T("Image depth: G ≈ %s (50 %%)"), cshDepthFx(D.g50, 1)));
   if (D.sbLim > 0) head += ", " + fmt(T("sky ≈ %s mag/arcsec²"), cshDepthFx(D.sbLim, 1));
   var H = (result.deepSky && result.deepSky.hiddenBy) ? result.deepSky.hiddenBy : null, pr = D.pruned || null;
   var faint = (H ? (H["too-faint"] || 0) + (H["below-sb-limit"] || 0) + (H["not-detected"] || 0) + (H["not-verifiable"] || 0) : 0) + (pr ? ((vis && pr.vis) ? (pr.bandOut || 0) : pr.withDistance) : 0);
   // (fuera del encuadre: solo lo de SIMBAD —lo que antes estaba en la lista del campo—; lo de GLADE+ y Quaia de fuera es
   // geometria del cono, no informa: va en el detalle)
   var outside = (result.deepSky && result.deepSky.hiddenSimbadOutside !== undefined) ? result.deepSky.hiddenSimbadOutside : (H ? (H.outside || 0) : 0);
   var tail = [];
   // (a ojo, las dos cuentas por separado: las estrellas de Gaia de la franja que no destacan y lo lejano que no)
   var deepOut = H ? (H["too-faint"] || 0) + (H["below-sb-limit"] || 0) + (H["not-detected"] || 0) + (H["not-verifiable"] || 0) : 0, starOut = (pr && pr.vis) ? (pr.bandOut || 0) : 0;
   if (vis && pr && pr.vis) { if (starOut + deepOut > 0) tail.push(fmt(T("not visible in the photo: %s Gaia stars and %s galaxies, quasars or groups"), cshDepthGroup(starOut), cshDepthGroup(deepOut))); }
   else if (faint > 0) tail.push(fmt(vis ? T("%s catalogue objects not visible in the photo") : T("%s catalogue objects too faint"), cshDepthGroup(faint)));
   if (outside > 0) tail.push(fmt(T("%s outside the frame"), cshDepthGroup(outside)));
   var out = [head, T("in the photo:") + " " + (bits || []).join(", ") + (tail.length ? " (" + tail.join(", ") + ")" : "")];
   // el detalle (tooltip)
   var L = [];
   L.push(T("What is shown is what this photo really reaches, not everything the catalogues know in this patch of sky."));
   if (vis) {
      L.push(fmt(T("Shown in depth only what you can see in the photo: signal-to-noise of %s or more at its position, against the noise of the photo there and of its own surroundings (S/N 5 says the light is there; by eye it only stands out from about %s)."), String(CSH_DEPTH.SNR_VIS), String(CSH_DEPTH.SNR_VIS)));
      if (!D.lowerVis50) L.push(fmt(T("By eye: half of the isolated Gaia stars stand out at G = %s; 90 %% at G = %s."), cshDepthFx(D.gVis50, 2), (D.gVis90 > 0 ? cshDepthFx(D.gVis90, 2) : "—")));
      // (24-oct-2026, D1 = A') lo que pasa la vara por poco: «debil», con su anillo y su punto mas tenues
      var nFaint = 0, dso = (result.deepSky && result.deepSky.objects) ? result.deepSky.objects : [], fi;
      for (fi = 0; fi < dso.length; ++fi) if (dso[fi].unseen !== true && cshDepthFaintSnr(dso[fi].depth) !== null) ++nFaint;
      if (nFaint > 0) L.push(fmt(T("%s of the galaxies, quasars or groups are FAINT (S/N %s to %s): barely visible, drawn with a dashed ring; zoom in to see them."), String(nFaint), String(CSH_DEPTH.SNR_VIS), String(CSH_DEPTH.SNR_CLEAR)));
      // (26-oct-2026, A'b de Nino) y lo mismo de las estrellas: su S/R a ojo, en [SNR_VIS, SNR_CLEAR)
      var nFaintS = 0, stF = result.stars || [], fs2;
      for (fs2 = 0; fs2 < stF.length; ++fs2) if (cshDepthStarFaintSnr(stF[fs2]) !== null) ++nFaintS;
      if (nFaintS > 0) L.push(fmt(T("%s of the stars are FAINT (S/N %s to %s): barely visible, drawn with a dashed ring; zoom in to see them."), cshDepthGroup(nFaintS), String(CSH_DEPTH.SNR_VIS), String(CSH_DEPTH.SNR_CLEAR)));
      L.push(T("What you can see in the photo but no catalogue gives a distance for cannot be placed in 3D: the 3D view does not invent distances."));
      var ds0 = result.deepSky;
      if (ds0 && ds0.unseen && ds0.unseen.length > 0) L.push(fmt(ds0.unseenShown ? T("Also shown, hollow, %s catalogue objects that are NOT visible in your photo (switch on).") : T("%s catalogue objects in the frame with a distance are not visible in your photo and are not drawn (switch «also what your photo doesn't show»: off)."), String(ds0.unseen.length)));
   }
   if (D.lower50) L.push(fmt(T("Depth: more than 50 %% of the Gaia stars are detected down to G %s, the end of the catalogue: the photo goes deeper."), cshDepthFx(D.g50, 2)));
   else L.push(fmt(T("Depth: half of the isolated Gaia stars are detected (S/N ≥ 5 at their position) at G = %s; 90 %% at G = %s."), cshDepthFx(D.g50, 2), (D.g90 !== null ? cshDepthFx(D.g90, 2) : "—")));
   if (D.gSnr5 > 0) L.push(fmt(T("Independent check: the zero point of the photo and its sky noise put S/N = 5 at G = %s."), cshDepthFx(D.gSnr5, 2)));
   if (D.sbLim > 0) L.push(fmt(T("Faintest surface brightness (3σ in 10″ boxes, Román et al. 2020): %s mag/arcsec² in G."), cshDepthFx(D.sbLim, 2)));
   else if (D.sbWhy) L.push(T("Surface brightness limit not given: ") + T(D.sbWhy));
   if (pr && pr.stars > 0) L.push(fmt(T("Stars: %s too faint for this photo are left out (%s of them had a distance)."), cshDepthGroup(pr.stars), cshDepthGroup(pr.withDistance)));
   if (H) {
      var R = [["too-faint", T("too faint (catalogue magnitude)")], ["below-sb-limit", T("too diffuse (below the surface brightness limit)")], ["not-detected", vis ? T("they do not stand out from the noise at their position in the photo") : T("nothing at their position in the photo")],
               ["not-verifiable", T("no magnitude and no clean pixels to check")], ["gaia-star", T("stars of the Milky Way according to Gaia (parallax or proper motion)")], ["outside", T("outside the frame")]];
      var hl = [];
      for (var i = 0; i < R.length; ++i) if (H[R[i][0]] > 0) hl.push(H[R[i][0]] + " " + R[i][1]);
      if (hl.length) L.push(T("Galaxies, quasars and other objects left out: ") + hl.join("; ") + ".");
      var nPz = 0, objs = result.deepSky.objects || [];
      for (var j = 0; j < objs.length; ++j) if (objs[j].dist && objs[j].dist.kind === "photo-z") ++nPz;
      if (nPz > 0) L.push(fmt(T("%s galaxies are placed by their PHOTOMETRIC redshift (GLADE+): their distance is uncertain by 20 %% or more and they are drawn as doubtful."), String(nPz)));
      var E = result.deepSky.extra || null;
      if (E) {
         var es = [];
         // (29-oct-2026, P8) si contesto un espejo de VizieR (csh_net.js cshVizierGet), de cual
         var via = function(x) { return (x.ok && x.fallback === true && x.server) ? fmt(T(" (from %s)"), String(x.server)) : ""; };
         if (E.glade) es.push("GLADE+ " + (E.glade.ok ? fmt(T("%s visible of %s new"), String(E.glade.shown || 0), String(E.glade.added)) + via(E.glade) : T("did not answer")));
         if (E.quaia) es.push("Quaia " + (E.quaia.ok ? fmt(T("%s visible of %s new"), String(E.quaia.shown || 0), String(E.quaia.added)) + via(E.quaia) : T("did not answer")));
         if (es.length) L.push(T("Besides SIMBAD: ") + es.join(" · ") + ".");
      }
   }
   return { bits: out, detail: L.join("<br>") };
}
// (23-oct-2026) LA FRASE DEL PIE DEL 3D (va tambien en la foto exportada y en el video, que pintan el mismo pie): hasta donde
// se ve y cuanto del catalogo se deja fuera por no verse. "" sin la vara de lo que se ve.
function cshDepthFoot(result) {
   var D = result ? result.depth : null;
   if (!D || !D.ok || CSH_DEPTH_VIS_ON !== true || !(D.gVis50 > 0)) return "";
   var T = (typeof optT === "function") ? optT : function(s) { return s; };
   var F = (typeof format === "function") ? format : null;
   function fmt(s, a, b, c) { return F ? F(s, a, b, c) : s.replace("%s", a).replace("%s", b).replace("%s", c); }
   var H = (result.deepSky && result.deepSky.hiddenBy) ? result.deepSky.hiddenBy : {}, pr = D.pruned || {};
   var nDeep = (H["too-faint"] || 0) + (H["below-sb-limit"] || 0) + (H["not-detected"] || 0) + (H["not-verifiable"] || 0), nStar = pr.vis ? (pr.bandOut || 0) : 0;
   var lim = (D.lowerVis50 ? "G ≥ " : "G ≈ ") + cshDepthFx(D.gVis50, 1);
   // (24-oct-2026, H2 de Gemini) Con «tambien lo que no se ve en tu foto» ENCENDIDO el pie no puede decir que lo que la foto no enseña «se deja
   // fuera»: se enseña, hueco. Cuenta de lo mostrado = los `unseen`; lo que sigue fuera = el resto de lo que no se ve (sin distancia o fuera del
   // encuadre) y las estrellas, que no vuelven.
   var dsU = result.deepSky, nShown = (dsU && dsU.unseenShown === true && dsU.unseen) ? dsU.unseen.length : 0;
   if (nShown > 0) {
      var nRest = Math.max(0, nDeep - nShown), head = fmt(T("Drawn: what this photo shows (by eye down to %s) and, hollow, %s galaxies, quasars or groups of the catalogues that it does NOT show."), lim, cshDepthGroup(nShown));
      return (nStar + nRest > 0) ? head + " " + fmt(T("Left out: %s Gaia stars and %s other galaxies, quasars or groups of the catalogues."), cshDepthGroup(nStar), cshDepthGroup(nRest)) : head;
   }
   if (nDeep + nStar === 0) return fmt(T("Only what this photo shows is drawn (by eye down to %s)."), lim);
   return fmt(T("Only what this photo shows is drawn (by eye down to %s): %s Gaia stars and %s galaxies, quasars or groups of the catalogues that it does not show are left out."), lim, cshDepthGroup(nStar), cshDepthGroup(nDeep));
}
// Las fuentes que se añadieron y se ven (para el pie «Data: …» del 3D).
function cshDepthCredits(result) {
   var E = (result && result.deepSky) ? result.deepSky.extra : null, out = [];
   if (E && E.glade && E.glade.shown > 0) out.push("GLADE+ (Dalya et al. 2022)");
   if (E && E.quaia && E.quaia.shown > 0) out.push("Quaia (Storey-Fisher et al. 2024)");
   return out;
}
function cshDepthWhy(code) {
   switch (String(code || "")) {
   case "no-view": return "there is no image to measure.";
   case "few-stars": return "too few unsaturated, isolated Gaia stars in the photo.";
   case "few-bins": return "too few Gaia stars to build the completeness curve.";
   case "measure-failed": return "the pixels could not be read.";
   }
   return String(code || "");
}
