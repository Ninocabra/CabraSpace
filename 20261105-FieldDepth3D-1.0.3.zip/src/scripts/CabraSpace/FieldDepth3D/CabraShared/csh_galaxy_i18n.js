#ifndef __CSH_GALAXY_I18N_JS
#define __CSH_GALAXY_I18N_JS
// ============================================================================
// CabraShared/csh_galaxy_i18n.js — las cadenas del MAPA de la Galaxia (csh_galaxy_paint.js), en inglés y castellano (23-oct-2026)
// ----------------------------------------------------------------------------
// PROCEDENCIA: las del mapa de CabraComposition/src/ui/cc_galaxy_i18n.js (fase 2b, 22-oct, sin commit), mismas claves y mismo
// formato (clave: [en, es]). Lo que es de los MANDOS de cada script (botones, tooltips del grupo) se queda en su script.
// Añadidas para Cabra3D: el instante de la máquina del tiempo, el potencial, la leyenda de BP−RP y de la distancia, las huecas.
// El idioma: el vigente del script (`cshLangIsEs`, csh_i18n.js). Las cifras con coma en castellano: cshGxNum (csh_galaxy_paint.js).
// ES5 puro.
// ============================================================================
var CSH_GX_TXT = {
   gxTitle: ["THE MILKY WAY", "LA VÍA LÁCTEA"],
   gxTitleTop: ["seen from above (X–Y)", "desde arriba (X–Y)"],
   gxTitleEdge: ["edge-on (R–z)", "de canto (R–z)"],
   gxTitle3d: ["in 3D", "en 3D"],
   gxSun: ["Sun", "Sol"],
   gxGC: ["Galactic centre", "Centro galáctico"],
   gxRotation: ["rotation", "giro"],
   gxPlane: ["disc plane", "plano del disco"],
   gxArms: ["arms: illustrative, not a map", "brazos: ilustrativos, no son un mapa"],
   // (23-oct, noche: los TEXTOS CANÓNICOS del mapa de la Galaxia —los mismos en CabraComposition: docs/textos_galaxia.md—. El potencial es
   //  MilkyWayPotential2022 de gala —Price-Whelan 2017—, sin artículo propio: su disco se ajustó a la curva de rotación de Eilers et al. 2019 y su vertical a Darragh-Ford et al. 2023, según la documentación de gala; 2-nov-2026)
   gxDisc: ["glow: mass of the disc and the bulge", "resplandor: masa del disco y del bulbo"],
   gxRing: ["{n} kpc", "{n} kpc"],
   gxAxisR: ["R  distance from the centre (kpc)", "R  distancia al centro (kpc)"],
   gxAxisZ: ["z (kpc)", "z (kpc)"],
   gxFoot: ["{n} stars with an orbit · {m} without radial velocity or distance", "{n} estrellas con órbita · {m} sin velocidad radial o sin distancia"],
   gxFootOrbit: ["orbits: 420 Myr (the chosen one, 2 Gyr)", "órbitas: 420 Ma (la elegida, 2 Ga)"],
   // (2-nov-2026, noche: decisión Q2b de Nino) con la barra (csh_galdyn.js cshGdBarOn), lo dibujado la lleva y las cifras de la elegida —su
   //  ficha: cshGdOrbit— no: el pie lo dice, para que la Zmax de la ficha (HD 140283: 2,5 kpc) no choque con lo que sube la línea (4,4 kpc)
   gxFootOrbitBar: ["orbits: 420 Myr (the chosen one, 2 Gyr) · drawn with the bar, numbers without", "órbitas: 420 Ma (la elegida, 2 Ga) · dibujadas con la barra, cifras sin ella"],
   gxFootNow: ["positions at this instant", "posiciones en este instante"],
   gxOrbitsSubset: ["{n} of {m} orbits drawn", "{n} de {m} órbitas dibujadas"],
   gxUnbound: ["{n} not bound to the Galaxy (no orbit)", "{n} no ligadas a la Galaxia (sin órbita)"],
   gxNoRes: ["Open the 3D view of an image to see its stars in the Milky Way.", "Abre la vista 3D de una imagen para ver sus estrellas en la Vía Láctea."],
   gxNoKin: ["No star of this field has an orbit yet: it needs a radial velocity and a distance.", "Ninguna estrella de este campo tiene órbita aún: hace falta velocidad radial y distancia."],
   gxSelOrbit: ["peri {p} · apo {a} · Zmax {z} kpc · e {e}", "peri {p} · apo {a} · Zmax {z} kpc · e {e}"],
   // (Cabra3D, 23-oct) la leyenda del color, las huecas, la estela, el instante y el modelo
   gxColourGaia: ["GAIA COLOUR (BP−RP)", "COLOR DE GAIA (BP−RP)"],
   gxColourDist: ["DISTANCE FROM THE SUN", "DISTANCIA AL SOL"],
   gxBpRpNone: ["no BP−RP", "sin BP−RP"],
   gxHollow: ["hollow: doubtful distance (RUWE ≥ 1.4)", "hueca: distancia dudosa (RUWE ≥ 1,4)"],
   gxClusterRv: ["with the cluster's radial velocity", "con la velocidad radial del cúmulo"],
   gxTrail: ["trail: its path from today", "estela: su camino desde hoy"],
   gxNow: ["today", "hoy"],
   gxPast: ["{t} million years ago", "hace {t} millones de años"],
   gxFuture: ["in {t} million years", "dentro de {t} millones de años"],
   gxModel: ["orbits in MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023)", "órbitas en MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023)"],
   // (2-nov-2026: la barra ya está en lo dibujado: lo que falta son los brazos y los encuentros)
   gxWarn: ["beyond ~100 Myr the model lacks the spiral arms and the encounters: an illustration", "pasados ~100 Ma al modelo le faltan los brazos y los encuentros: una ilustración"],
   gxBeyond: ["beyond ~500 Myr these are no longer their real orbits", "pasados ~500 Ma ya no son sus órbitas de verdad"],
   // (23-oct-2026, tarde) las de solo hoy y el mapa sin ninguna órbita, en grande
   gxNoKinBig: ["No star of this field has an orbit", "Ninguna estrella de este campo tiene órbita"],
   gxNowOnly: ["Shown: {n} stars at today's position (they have a distance but no radial velocity: they cannot be moved)", "Se ven {n} estrellas en su sitio de hoy (tienen distancia pero no velocidad radial: no se pueden mover)"],
   gxNowOnlyHidden: ["{n} stars have only today's position (no radial velocity): back to «now» to see them", "{n} estrellas solo tienen su sitio de hoy (sin velocidad radial): vuelve a «ahora» para verlas"],
   gxNowFoot: ["{n} at today's position, without orbit", "{n} en su sitio de hoy, sin órbita"],
   gxNowHidden: ["{n} without orbit only at «now»", "{n} sin órbita solo en «ahora»"],
   gxNowLegend: ["faint: today's position only (no radial velocity)", "tenue: solo su sitio de hoy (sin velocidad radial)"],
   // (23-oct, noche: el pie decía «977 sin velocidad radial o sin distancia · 977 en su sitio de hoy, sin órbita»: la misma cifra dos veces.
   //  Ahora UNA frase: si todas las que no tienen órbita están en su sitio de hoy, se dice una vez; si solo una parte, «de ellas»)
   gxFootAllNow: ["{n} stars with an orbit · {m} without radial velocity, at today's position (no orbit)", "{n} estrellas con órbita · {m} sin velocidad radial, en su sitio de hoy (sin órbita)"],
   gxFootAllNowHidden: ["{n} stars with an orbit · {m} without radial velocity (only at «now»)", "{n} estrellas con órbita · {m} sin velocidad radial (solo en «ahora»)"],
   gxFootPartNow: ["{n} stars with an orbit · {m} without radial velocity or distance, {k} of them at today's position", "{n} estrellas con órbita · {m} sin velocidad radial o sin distancia, {k} de ellas en su sitio de hoy"],
   gxFootPartNowHidden: ["{n} stars with an orbit · {m} without radial velocity or distance ({k} of them only at «now»)", "{n} estrellas con órbita · {m} sin velocidad radial o sin distancia ({k} de ellas solo en «ahora»)"],
   // (24-oct-2026, V7f) el POLVO de la Galaxia (csh_galaxy_dust.js): lo medido HOY, lo del modelo y la costura
   // (UNA fila de leyenda: con tres, la leyenda del vídeo 3D tapaba estrellas —c3_gx_review V7: 6,6 % a −100 Ma— y dejaba sin sitio el rótulo de
   //  la elegida —V1—. Las cifras —4,8 kpc, 1,2 kpc, R 3,3–12,9, |z − z⊙| ≤ 0,4, ≤ 20 % de cada anillo— van en el tooltip del botón)
   gxDustRow: ["dust today: measured | model (greyer) · - - - edge of the measured", "polvo de hoy: medido | modelo (más gris) · - - - borde de lo medido"],
   gxDustRowEdge: ["dust today, ring mean: measured | model (greyer) · - - - measured box", "polvo de hoy, media del anillo: medido | modelo (más gris) · - - - recuadro medido"],
   // (en el VÍDEO —V.legendCompact—, el polvo comparte fila con el resplandor: la leyenda no crece. Con una fila más, en el vídeo 3D a −100 Ma
   //  quedaba el 1,05 % de la nube debajo —c3_gx_review V7, tope 1 %— y a +87,6 Ma el rótulo de la elegida sin sitio —V1—)
   gxDiscDust: ["glow: mass · dust today: measured | model", "resplandor: masa · polvo de hoy: medido | modelo"],
   gxDustRowPlain: ["dust today: measured | model (greyer)", "polvo de hoy: medido | modelo (más gris)"],
   // (26-oct-2026, V7h) el polvo EN EL TIEMPO: el de hoy girado con la Galaxia (rotación diferencial del mismo potencial) y, pasada la vida de
   // las nubes (τ = 20 Ma), lo que se ve es ILUSTRATIVO (Nino: «dilo en pantalla»). V7g: de canto, si la lámina se estira, «grosor ×n»
   gxDustRowT: ["today's dust turned with the Galaxy: measured | model (greyer) · - - - its edge", "polvo de hoy girado con la Galaxia: medido | modelo (más gris) · - - - su borde"],
   gxDustRowIllus: ["dust: position illustrative beyond {n} Myr (clouds live 10–30 Myr)", "polvo: posición ilustrativa pasados {n} Ma (las nubes viven 10–30 Ma)"],
   gxDiscDustT: ["glow: mass · dust turned with the Galaxy", "resplandor: masa · polvo girado con la Galaxia"],
   gxDiscDustIllus: ["glow: mass · dust illustrative beyond {n} Myr", "resplandor: masa · polvo ilustrativo pasados {n} Ma"],
   gxDustThick: [" · thickness ×{n}", " · grosor ×{n}"],
   gxShort: ["time machine at ±{r}: at this scale the stars barely move · choose ±10 Myr or more", "máquina del tiempo a ±{r}: a esta escala las estrellas apenas se mueven · elige ±10 Ma o más"]
};
function cshGxT(key) {
   var e = CSH_GX_TXT[key];
   if (!e) return key;
   if (typeof cshGxBroken === "function" && cshGxBroken("mixlang") && key === "gxGC") return e[0];     // (ROJO «mixlang» de las sondas)
   return (typeof cshLangIsEs === "function" && cshLangIsEs()) ? e[1] : e[0];
}
function cshGxF(key, vals) {
   var t = cshGxT(key);
   for (var k in vals) if (vals.hasOwnProperty(k)) t = t.split("{" + k + "}").join(String(vals[k]));
   return t;
}
#endif
