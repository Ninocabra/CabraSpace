#ifndef __CSH_GALAXY_JS
#define __CSH_GALAXY_JS
// ============================================================================
// CabraShared/csh_galaxy.js — LA GALAXIA: el MODELO del mapa (órbitas, el Sol, la Vía Láctea de referencia), la CÁMARA 3D y las
// vistas 2D (desde arriba X–Y, de canto R–z). Puro: lo ejecutan node y PixInsight (no pinta, no crea ventanas). (23-oct-2026)
// ----------------------------------------------------------------------------
// PROCEDENCIA: COPIA de CabraComposition/src/ui/cc_galaxy.js (fase 2b del 22-oct-2026, árbol de trabajo sin commit), con los
// nombres de ccGx… a cshGx… y CC_GX a CSH_GX. Lo cambiado, a sabiendas:
//   · la ENTRADA es genérica (no lee `res.stars[].fam` de CabraComposition): una lista de { i, st, name, g, grp, data } con el
//     estado galactocéntrico de hoy de cada estrella (`st`, de cshGdState: csh_galdyn.js). Así lo usan Cabra3D y, cuando migre,
//     CabraComposition (CabraShared/CHANGELOG.md, 23-oct: pendiente).
//   · la trayectoria se integra también hacia ATRÁS si se pide (`opts.backMyr`; la máquina del tiempo de Cabra3D va de −1 Gyr a
//     +1 Gyr): `cshGdTrajectory` / `cshGdAt` de csh_galdyn.js.
//   · el subconjunto de órbitas dibujadas agrupa por `grp` (el que diga el script: en CabraComposition la población, en Cabra3D el
//     cúmulo) en vez de por población.
// La física es la de csh_galdyn.js (MilkyWayPotential2022 desde el 23-oct, tarde; el marco de astropy); la cámara 3D es la de Cabra3D (src/ui/starfield_view.js: cpSvPose,
// cpSvDistView, cpSvDistFrame, cpSvDistCam, cpSvDistOrbit, cpSvDistPan, cpSvDistZoomAt, cpSvDistViewLerp, cpSvDepth*), vía CabraStars
// lib/cs_h3cam.js y CabraComposition, con la caja del mundo galactocéntrico en kpc:  u (derecha) = −Y · v (abajo) = −Z · fondo = +X.
//
// LA VÍA LÁCTEA DE REFERENCIA (lo que se pinta de fondo) NO es un dibujo inventado: es la DISTRIBUCIÓN DE MASA del mismo potencial
// que mueve las órbitas (disco Miyamoto-Nagai, bulbo y núcleo Hernquist; el halo oscuro no brilla y no se pinta; la barra —2-nov-2026: en
// las órbitas dibujadas, no en la ficha ni en el resplandor— tampoco se pinta). Los BRAZOS espirales SÍ son ILUSTRATIVOS (cuatro espirales logarítmicas de paso 12°, sin ajustar a ningún
// catálogo): la leyenda lo dice.
// ES5 puro (#engine v8 lo pone el script que lo incluye). Necesita csh_galdyn.js antes.
// ============================================================================

var CSH_GX = {
   T_MYR: 2000,         // lo integrado hacia el futuro: lo mismo que cshGdOrbit (sus peri, apo y Zmax son los de la ficha)
   BACK_MYR: 0,         // hacia el pasado, de fábrica nada (Cabra3D pide 1 000 Myr: el tope de su máquina del tiempo)
   SHOW_MYR: 420,       // diseño (CabraComposition): lo pintado de cada órbita, ≈ 2 vueltas del Sol (periodo azimutal ≈ 203 Myr)
   DT_MYR: 0.5,         // el paso de cshGdOrbit
   EVERY: 4,            // se guarda un punto cada 4 pasos = 2 Myr
   GLOW_R: 24,          // kpc: hasta dónde llega la tabla de Σ(R)
   RINGS: [5, 10, 15, 20, 30],   // kpc: los círculos de referencia
   ARM_PITCH_DEG: 12,   // ILUSTRATIVO: el paso de los brazos dibujados (no es un ajuste a datos)
   ARM_R0: 3.0, ARM_R1: 16.0, ARM_N: 4,
   TOP_MIN_HALF: 11,    // kpc: el encuadre desde arriba enseña al menos ±11 kpc (el Sol y el centro siempre)
   EDGE_MIN_R: 12, EDGE_MIN_Z: 1.5,
   MAX_ORBITS: 300,     // diseño (CabraComposition): órbitas dibujadas a la vez
   MAX_ORBITS_LIGHT: 40      // (CabraComposition: 120. Cabra3D, 23-oct: al girar el 3D con 5 539 estrellas, 120 órbitas eran ~26 ms solo de trazar; con 60 el fotograma aún pasaba de 33 ms)
};
var CSH_GX_BREAK = "";   // defectos inyectados por las sondas: «flip», «ray», «scale», «pick», «labels», «legend», «comma», «mixlang»…
function cshGxBroken(k) { return (typeof CSH_GX_BREAK === "string") && CSH_GX_BREAK.length > 0 && CSH_GX_BREAK.indexOf(k) >= 0; }
function cshGxIsNum(v) { return typeof v === "number" && isFinite(v); }

// QUÉ ÓRBITAS SE DIBUJAN cuando hay más de `max`: TODAS las que no son del montón (otro grupo que el más común, o e > 0,2) y, de
// las del montón, una de cada k hasta llenar el cupo. Devuelve índices de G.stars (con órbita). Se guarda en G.
function cshGxOrbitSubset(G, max) {
   var key = "sub" + max;
   if (G[key]) return G[key];
   var withTr = [], cnt = {}, top = "", tc = -1, i;
   for (i = 0; i < G.stars.length; ++i) if (G.stars[i].tr) { withTr.push(i); cnt[G.stars[i].grp] = (cnt[G.stars[i].grp] || 0) + 1; }
   for (var k in cnt) if (cnt.hasOwnProperty(k) && cnt[k] > tc) { tc = cnt[k]; top = k; }
   if (withTr.length <= max) { G[key] = withTr; return withTr; }
   var odd = [], bulk = [], perGrp = {}, gm = (G.groupMax > 0) ? G.groupMax : 0;
   for (i = 0; i < withTr.length; ++i) {
      var e = G.stars[withTr[i]];
      if (e.grp !== top || e.meas.ecc > 0.2) {
         // (G.groupMax: como mucho tantas de cada grupo que no es el del montón. Cabra3D, 23-oct: los 245 miembros de Berkeley 89 llevan la
         //  velocidad del cúmulo, así que su órbita es LA MISMA: 245 líneas apiladas eran un trazo grueso y brillante que parecía la elegida)
         if (gm && e.grp !== top) { perGrp[e.grp] = (perGrp[e.grp] || 0) + 1; if (perGrp[e.grp] > gm) continue; }
         odd.push(withTr[i]);
      } else bulk.push(withTr[i]);
   }
   if (odd.length > max) {                    // (demasiadas raras: las más excéntricas primero)
      odd.sort(function(a, b) { return (G.stars[b].meas.ecc - G.stars[a].meas.ecc) || (a - b); });
      odd.length = max;
   }
   var room = Math.max(0, max - odd.length), out = odd.slice();
   if (room > 0) { var step = bulk.length / room; for (var j = 0; j < room && Math.floor(j * step) < bulk.length; ++j) out.push(bulk[Math.floor(j * step)]); }
   out.sort(function(a, b) { return a - b; });
   G[key] = out;
   return out;
}

// ---------------------------------------------------------------------------
// LA VÍA LÁCTEA de referencia (del potencial de csh_galdyn.js)
// ---------------------------------------------------------------------------
// Densidades del potencial (M⊙/kpc³).
// (23-oct-2026, tarde: el disco del v2 son TRES Miyamoto-Nagai —cshGdDiskDensity—, no uno; el resplandor dibuja la masa que mueve las órbitas)
function cshGxRhoDisc(R, z) { return cshGdDiskDensity(R, z); }
function cshGxRhoBulge(r) { return cshGdBulgeDensity(r); }
// Σ (M⊙/kpc²) del disco a radio R (integral en z, z = 6u², por Simpson) y del bulbo proyectado a distancia d del centro.
function cshGxSigmaDisc(R) {
   var n = 120, s = 0, Zm = 6;
   for (var i = 0; i <= n; ++i) {
      var u = i / n, z = Zm * u * u, dz = 2 * Zm * u, wgt = (i === 0 || i === n) ? 1 : ((i % 2) ? 4 : 2);
      s += wgt * cshGxRhoDisc(R, z) * dz;
   }
   return 2 * s / (3 * n);
}
function cshGxSigmaBulge(d) {
   var n = 160, s = 0, Lm = 40;
   d = Math.max(d, 0.02);
   for (var i = 0; i <= n; ++i) {
      var u = i / n, l = Lm * u * u, dl = 2 * Lm * u, wgt = (i === 0 || i === n) ? 1 : ((i % 2) ? 4 : 2);
      s += wgt * cshGxRhoBulge(Math.sqrt(d * d + l * l)) * dl;
   }
   return 2 * s / (3 * n);
}
var CSH_GX_SIGMA = null;
function cshGxSigmaTable() {
   if (CSH_GX_SIGMA) return CSH_GX_SIGMA;
   var step = 0.05, n = Math.ceil(CSH_GX.GLOW_R / step) + 1, D = new Float64Array(n), B = new Float64Array(n);
   for (var i = 0; i < n; ++i) { D[i] = cshGxSigmaDisc(i * step); B[i] = cshGxSigmaBulge(i * step); }
   CSH_GX_SIGMA = { step: step, n: n, disc: D, bulge: B, ref: D[Math.round(CSH_GD.R0_KPC / step)] };
   return CSH_GX_SIGMA;
}
function cshGxLookup(arr, T, r) {
   var f = r / T.step;
   if (f >= T.n - 1) return arr[T.n - 1] * Math.exp(-(f - T.n + 1) * T.step / 2);
   var i = Math.floor(f), u = f - i;
   return arr[i] + (arr[i + 1] - arr[i]) * u;
}
function cshGxSigmaAt(R) { var T = cshGxSigmaTable(); return cshGxLookup(T.disc, T, R) + cshGxLookup(T.bulge, T, R); }
// EL BRILLO PINTADO (0…1), logarítmico, de Σ = 0,3 M⊙/pc² (apagado) a 3000 M⊙/pc² (lleno) (diseño de CabraComposition).
function cshGxGlowOf(sigma) {
   var lo = Math.log(0.3e6), hi = Math.log(3000e6);
   if (!(sigma > 0)) return 0;
   return Math.max(0, Math.min(1, (Math.log(sigma) - lo) / (hi - lo)));
}
// Los BRAZOS ILUSTRATIVOS: espirales logarítmicas en el plano (polilíneas [[x, y], …] en kpc). NO es un mapa.
var CSH_GX_ARMS = null;
function cshGxArms() {
   if (CSH_GX_ARMS) return CSH_GX_ARMS;
   var out = [], k = Math.tan(CSH_GX.ARM_PITCH_DEG * Math.PI / 180), N = CSH_GX.ARM_N;
   for (var a = 0; a < N; ++a) {
      var th0 = a * 2 * Math.PI / N + 0.6, pts = [];
      var thMax = Math.log(CSH_GX.ARM_R1 / CSH_GX.ARM_R0) / k;
      for (var t = 0; t <= thMax + 1e-9; t += 0.04) {
         var R = CSH_GX.ARM_R0 * Math.exp(k * t), th = th0 + t;
         pts.push([R * Math.cos(th), R * Math.sin(th)]);
      }
      out.push(pts);
   }
   CSH_GX_ARMS = out;
   return out;
}

// ---------------------------------------------------------------------------
// EL MODELO DEL MAPA (G): una vez por campo (y por lo que traiga la red)
// ---------------------------------------------------------------------------
// items = [ { i (el índice del script), st ({ x, y, z, vx, vy, vz, E }: cshGdState), name, g, grp (para el subconjunto), data (lo que
//             el script quiera para colorear: se guarda tal cual en e.data) } ]
// opts  = { tMyr (futuro, de fábrica CSH_GX.T_MYR), backMyr (pasado, de fábrica CSH_GX.BACK_MYR), nNoKin (las del campo que se
//           quedaron fuera por falta de datos: el pie lo dice), onProgress (f 0…1 -> false para parar), groupMax (órbitas dibujadas
//           como mucho de cada grupo que no es el del montón; 0 = sin tope, lo de CabraComposition),
//           now (23-oct, tarde: las que solo tienen su sitio de hoy —sin velocidad radial—: [ { i, x, y, z, name, g, data } ], en G.now) }
// OJO: con tMyr < 2000 las medidas (e.meas: peri, apo, Zmax) son las de ESE tramo, no las de 2 Gyr de la ficha de CabraComposition:
// para la ficha, cshGdOrbit(e.st) (Cabra3D lo hace solo con la elegida).
var CSH_GX_STAMP = 0;
function cshGalaxyModel(items, opts) {
   var o = opts || {}, t0 = Date.now(), T = o.tMyr || CSH_GX.T_MYR, B = cshGxIsNum(o.backMyr) ? Math.max(0, o.backMyr) : CSH_GX.BACK_MYR;
   CSH_GX_STAMP = (CSH_GX_STAMP || 0) + 1;
   var G = { stamp: CSH_GX_STAMP, stars: [], byIdx: {}, nAll: 0, nNoKin: o.nNoKin || 0, nUnbound: 0, tMyr: T, backMyr: B, dtMyr: CSH_GX.DT_MYR, ms: 0, proj: null, groupMax: (o.groupMax > 0) ? o.groupMax : 0 };
   var list = items || [];
   G.nAll = list.length + G.nNoKin;
   // (el encuadre de fábrica sigue al 90 % de las órbitas, no a la más extrema; lo que se sale, con la rueda hacia fuera)
   var maxAbsXY = 0, maxR = 0, maxZ = 0, extXY = [], extR = [], extZ = [];
   function grow(x, y, z) {
      var R = Math.sqrt(x * x + y * y);
      if (Math.abs(x) > maxAbsXY) maxAbsXY = Math.abs(x);
      if (Math.abs(y) > maxAbsXY) maxAbsXY = Math.abs(y);
      if (R > maxR) maxR = R;
      if (Math.abs(z) > maxZ) maxZ = Math.abs(z);
   }
   function flush() { extXY.push(maxAbsXY); extR.push(maxR); extZ.push(maxZ); maxAbsXY = 0; maxR = 0; maxZ = 0; }
   function p90(a) { if (!a.length) return 0; var b = a.slice().sort(function(p, q) { return p - q; }); return b[Math.min(b.length - 1, Math.floor(0.9 * (b.length - 1) + 0.5))]; }
   var j, lastTick = Date.now();
   for (var k = 0; k < list.length; ++k) {
      // (opts.onProgress(f): la barra del script cada ~0,25 s; si devuelve false —cerrando—, se para y no hay modelo)
      if (typeof o.onProgress === "function" && Date.now() - lastTick > 250) { lastTick = Date.now(); if (o.onProgress(k / list.length) === false) return null; }
      var it = list[k], st = it.st;
      if (!st || !cshGxIsNum(st.x) || !cshGxIsNum(st.E)) { ++G.nNoKin; continue; }
      var tr = cshGdTrajectory(st, T, B, CSH_GX.DT_MYR, CSH_GX.EVERY);
      if (!tr.bound) ++G.nUnbound;
      var e = { i: it.i, x: st.x, y: st.y, z: st.z, st: st, tr: tr.bound ? tr : null, meas: tr, name: it.name || "", g: it.g, grp: String((it.grp === undefined || it.grp === null) ? "" : it.grp), data: it.data };
      G.byIdx[it.i] = G.stars.length;
      G.stars.push(e);
      grow(st.x, st.y, st.z);
      if (tr.bound) for (j = 0; j < tr.n; j += 2) grow(tr.x[j], tr.y[j], tr.z[j]);
      flush();
   }
   // (23-oct-2026, tarde, queja de Nino: «en Galaxia no se pinta nada») LAS ESTRELLAS SIN VELOCIDAD RADIAL pero con distancia: su sitio de HOY
   // sí se sabe (ra, dec, distancia → x, y, z), su órbita no. opts.now = [ { i, x, y, z, name, g, data } ]: se pintan solo en «hoy»
   // (csh_galaxy_paint.js cshGxPaintDynamic), sin órbita, más tenues; no se mueven con la máquina del tiempo (no se puede).
   G.now = [];
   var nowList = o.now || [];
   for (k = 0; k < nowList.length; ++k) {
      var nw = nowList[k];
      if (!nw || !cshGxIsNum(nw.x) || !cshGxIsNum(nw.y) || !cshGxIsNum(nw.z)) continue;
      // (no entran en el encuadre: están a unos kpc del Sol, dentro de lo que ya se enseña; con ellas el p90 del encuadre de fábrica
      //  cambiaba —medido en c3_galaxy X3, 23-oct, tarde— y el mapa no era el mismo con y sin velocidades radiales)
      G.now.push({ i: nw.i, x: nw.x, y: nw.y, z: nw.z, name: nw.name || "", g: nw.g, data: nw.data });
   }
   var sun = cshGdSunState(), str = cshGdTrajectory(sun, T, B, CSH_GX.DT_MYR, CSH_GX.EVERY);
   G.sun = { x: sun.x, y: sun.y, z: sun.z, st: sun, tr: str };
   grow(sun.x, sun.y, sun.z);
   for (j = 0; j < str.n; ++j) grow(str.x[j], str.y[j], str.z[j]);
   var sunXY = maxAbsXY, sunR = maxR;
   var half = Math.min(45, Math.max(CSH_GX.TOP_MIN_HALF, sunXY * 1.08, p90(extXY) * 1.08));
   var zE = Math.min(30, Math.max(CSH_GX.EDGE_MIN_Z, p90(extZ) * 1.15));
   G.ext = { top: { cx: 0, cy: 0, half: half },
             edge: { r1: Math.min(45, Math.max(CSH_GX.EDGE_MIN_R, sunR * 1.08, p90(extR) * 1.08)), z1: zE },
             box: { hx: half, hy: half, hz: Math.max(Math.min(30, p90(extZ) * 1.1), 0.12 * half) },
             maxXY: Math.max.apply(null, extXY.concat([sunXY])), maxZ: Math.max.apply(null, extZ.concat([0])) };
   cshGxSigmaTable();
   G.ms = Date.now() - t0;
   return G;
}
// Dónde está la estrella k del modelo (o el Sol: k = −1) a tMyr de hoy: [x, y, z] kpc. Hoy, su estado exacto (no el Float32).
function cshGxPosAt(G, k, tMyr, out) {
   out = out || [0, 0, 0];
   var e = (k < 0) ? G.sun : G.stars[k];
   if (!(tMyr !== 0 && e.tr && e.tr.n) || cshGxBroken("time")) { out[0] = e.x; out[1] = e.y; out[2] = e.z; return out; }
   return cshGdAt(e.tr, tMyr, out, false);
}

// ---------------------------------------------------------------------------
// EL ENCUADRE DE LA NUBE EN EL TIEMPO (23-oct-2026, noche; revisión visual de Cabra3D: en las Pléyades la nube de 5 539 estrellas se salía
// por abajo «ahora» desde arriba y por la derecha a −100 Myr de canto, y la elegida y su rótulo se cortaban por arriba en +44,9 Myr).
// El encuadre de fábrica (G.ext) sigue al 90 % de las ÓRBITAS de 420 Myr, no a dónde ESTÁN las estrellas mientras corre la máquina del
// tiempo. Esto mide, para la ventana [a, b] Myr (la escala de la máquina del tiempo), los extremos de cada estrella (su sitio en cada punto
// guardado de su trayectoria) y devuelve la caja que contiene la nube ENTERA en todo ese tiempo (cuantiles de los extremos —el recorte más estrecho que deja dentro, enteras, al menos el 99 %—
// de cada estrella: una sola estrella rara no decide el encuadre), el Sol en todo ese tiempo, el centro galáctico y la elegida (selK, índice
// de G.stars, o −1) en todo ese tiempo. Y unas muestras (≤ ~60 000) de esas posiciones para saber dónde NO hay estrellas (las placas).
//   top: u = −Y (derecha en pantalla), X (arriba) · edge: R, z · box3: la caja 3D centrada en el centro galáctico.
// Puro (node). Se guarda en G (una sola, la última pedida).
function cshGxFitData(G, a, b, selK) {
   a = Math.max(-(G.backMyr || 0), Math.min(0, cshGxIsNum(a) ? a : 0)); b = Math.min(G.tMyr || 0, Math.max(0, cshGxIsNum(b) ? b : 0));
   var sk = (cshGxIsNum(selK) && selK >= 0 && selK < G.stars.length) ? selK : -1, key = [a, b, cshGxBroken("nofit") ? 1 : 0].join("|");
   // (la nube se mide una vez por ventana; la elegida solo AÑADE su tramo: elegir otra estrella no vuelve a recorrer 5 539 trayectorias)
   if (G._fit && G._fit.key === key) return cshGxFitSel(G._fit, sk);
   var N = G.stars.length, k, j;
   var lo = { u: new Float64Array(N), x: new Float64Array(N), R: new Float64Array(N), z: new Float64Array(N) };
   var hi = { u: new Float64Array(N), x: new Float64Array(N), R: new Float64Array(N), z: new Float64Array(N) };
   // (las muestras: cada cuántos puntos guardados, para no pasar de ~60 000 en total)
   var nPts = 0;
   for (k = 0; k < N; ++k) { var e0 = G.stars[k]; nPts += e0.tr ? (Math.round(b / e0.tr.dtMyr) + 1 + ((e0.tr.back && a < 0) ? Math.round(-a / e0.tr.back.dtMyr) : 0)) : 1; }
   var every = Math.max(1, Math.ceil(nPts / 60000)), cap = Math.ceil(nPts / every) + 2 * N + 8, S = { n: 0, X: new Float32Array(cap), Y: new Float32Array(cap), Z: new Float32Array(cap) };
   function push(X, Y, Z) { if (S.n < cap) { S.X[S.n] = X; S.Y[S.n] = Y; S.Z[S.n] = Z; ++S.n; } }
   // los extremos de una tabla en [a, b] (y las muestras): out = [uMin, uMax, xMin, xMax, RMin, RMax, zMin, zMax]
   function span(e, out, sample) {
      out[0] = out[2] = out[4] = out[6] = Infinity; out[1] = out[3] = out[5] = out[7] = -Infinity;
      function add(X, Y, Z, s) {
         var u = -Y, R = Math.sqrt(X * X + Y * Y);
         if (u < out[0]) out[0] = u; if (u > out[1]) out[1] = u; if (X < out[2]) out[2] = X; if (X > out[3]) out[3] = X;
         if (R < out[4]) out[4] = R; if (R > out[5]) out[5] = R; if (Z < out[6]) out[6] = Z; if (Z > out[7]) out[7] = Z;
         if (s) push(X, Y, Z);
      }
      add(e.x, e.y, e.z, sample);
      var tr = e.tr, T, n, cnt = 0;
      if (tr && tr.n) {
         T = tr; n = Math.min(T.n - 1, Math.round(b / T.dtMyr));
         for (j = 0; j <= n; ++j) add(T.x[j], T.y[j], T.z[j], sample && ((++cnt) % every === 0));
         if (a < 0 && tr.back && tr.back.n) { T = tr.back; n = Math.min(T.n - 1, Math.round(-a / T.dtMyr)); for (j = 0; j <= n; ++j) add(T.x[j], T.y[j], T.z[j], sample && ((++cnt) % every === 0)); }
      }
      return out;
   }
   var o8 = [0, 0, 0, 0, 0, 0, 0, 0];
   for (k = 0; k < N; ++k) {
      span(G.stars[k], o8, true);
      lo.u[k] = o8[0]; hi.u[k] = o8[1]; lo.x[k] = o8[2]; hi.x[k] = o8[3]; lo.R[k] = o8[4]; hi.R[k] = o8[5]; lo.z[k] = o8[6]; hi.z[k] = o8[7];
   }
   // (LOS CUANTILES, adaptados: el recorte más ESTRECHO por eje —1 %, 0,5 %, 0,25 %, 0,1 % o nada— con el que al menos el 99 % de las
   //  estrellas quedan ENTERAS dentro en todo el tiempo. Con un 0,1 % fijo, cinco estrellas del halo de las Pléyades —Zmax de 4 kpc— decidían
   //  la altura del mapa de canto y la nube salía en una raya —captura del 23-oct, noche—; con un 0,5 % fijo, en un campo de estrellas muy
   //  distintas se quedaba fuera hasta un 3 % —c3_gx_cases G14—)
   function sorted(arr) { return Array.prototype.slice.call(arr).sort(function(p, r) { return p - r; }); }
   var SL = { u: sorted(lo.u), x: sorted(lo.x), R: sorted(lo.R), z: sorted(lo.z) }, SH = { u: sorted(hi.u), x: sorted(hi.x), R: sorted(hi.R), z: sorted(hi.z) };
   function at(s, f) { return s.length ? s[Math.max(0, Math.min(s.length - 1, Math.round(f * (s.length - 1))))] : NaN; }
   function cut(f) { return [at(SL.u, f), at(SH.u, 1 - f), at(SL.x, f), at(SH.x, 1 - f), at(SL.R, f), at(SH.R, 1 - f), at(SL.z, f), at(SH.z, 1 - f)]; }
   var QS = [0.01, 0.005, 0.0025, 0.001, 0], v8 = null, qUsed = 0, fIn = 1;
   for (var qi = 0; qi < QS.length && N; ++qi) {
      var c8 = cut(QS[qi]), nin = 0;
      for (k = 0; k < N; ++k) if (lo.u[k] >= c8[0] && hi.u[k] <= c8[1] && lo.x[k] >= c8[2] && hi.x[k] <= c8[3] && hi.R[k] <= c8[5] && lo.z[k] >= c8[6] && hi.z[k] <= c8[7]) ++nin;
      v8 = c8; qUsed = QS[qi]; fIn = nin / N;
      if (fIn >= 0.99) break;
   }
   var box = { u0: 0, u1: 0, x0: 0, x1: 0, R0: 0, R1: 0, z0: 0, z1: 0 };        // (el centro galáctico, siempre: u = X = R = z = 0)
   function grow8(v) { box.u0 = Math.min(box.u0, v[0]); box.u1 = Math.max(box.u1, v[1]); box.x0 = Math.min(box.x0, v[2]); box.x1 = Math.max(box.x1, v[3]);
                       box.R1 = Math.max(box.R1, v[5]); box.z0 = Math.min(box.z0, v[6]); box.z1 = Math.max(box.z1, v[7]); }
   if (N && v8 && !cshGxBroken("nofit")) grow8(v8);
   var sunS = span(G.sun, [0, 0, 0, 0, 0, 0, 0, 0], false); grow8(sunS);
   G._fit = { key: key, a: a, b: b, base: box, lo: lo, hi: hi, S: S, every: every, bySel: {}, q: qUsed, fIn: fIn };
   return cshGxFitSel(G._fit, sk);
}
// La caja de la ventana con la elegida (sk, índice de G.stars, o −1) dentro, con sus mínimos, y la caja 3D. { box, box3, sel, sig, S }
function cshGxFitSel(D, sk) {
   if (D.bySel.hasOwnProperty(sk)) return D.bySel[sk];
   var b0 = D.base, box = { u0: b0.u0, u1: b0.u1, x0: b0.x0, x1: b0.x1, R0: 0, R1: b0.R1, z0: b0.z0, z1: b0.z1 };
   if (sk >= 0 && sk < D.lo.u.length) {
      box.u0 = Math.min(box.u0, D.lo.u[sk]); box.u1 = Math.max(box.u1, D.hi.u[sk]); box.x0 = Math.min(box.x0, D.lo.x[sk]); box.x1 = Math.max(box.x1, D.hi.x[sk]);
      box.R1 = Math.max(box.R1, D.hi.R[sk]); box.z0 = Math.min(box.z0, D.lo.z[sk]); box.z1 = Math.max(box.z1, D.hi.z[sk]);
   }
   // (mínimos: desde arriba al menos 8 kpc de lado; de canto al menos ±0,5 kpc en z —el disco fino no puede salir aplastado en una raya—)
   var MIN_TOP = 8, MIN_Z = 0.5;
   if (box.u1 - box.u0 < MIN_TOP) { var cu = (box.u0 + box.u1) / 2; box.u0 = cu - MIN_TOP / 2; box.u1 = cu + MIN_TOP / 2; }
   if (box.x1 - box.x0 < MIN_TOP) { var cx = (box.x0 + box.x1) / 2; box.x0 = cx - MIN_TOP / 2; box.x1 = cx + MIN_TOP / 2; }
   box.z0 = Math.min(box.z0, -MIN_Z); box.z1 = Math.max(box.z1, MIN_Z);
   box.R1 = Math.max(box.R1, 1);
   // la caja 3D: centrada en el centro galáctico (el pivote de la cámara), lo bastante para la nube
   var hxy = Math.max(Math.abs(box.u0), Math.abs(box.u1), Math.abs(box.x0), Math.abs(box.x1)) * 1.04, hz = Math.max(Math.abs(box.z0), Math.abs(box.z1)) * 1.1;
   var out = { box: box, box3: { hx: hxy, hy: hxy, hz: Math.max(hz, 0.12 * hxy) }, sel: sk, S: D.S, key: D.key,
               sig: [box.u0, box.u1, box.x0, box.x1, box.R1, box.z0, box.z1].map(function(v) { return v.toFixed(3); }).join(",") };
   var n = 0; for (var kk in D.bySel) if (D.bySel.hasOwnProperty(kk)) ++n;
   if (n > 32) D.bySel = {};
   D.bySel[sk] = out;
   return out;
}

// ---------------------------------------------------------------------------
// LA CÁMARA 3D (la de Cabra3D, copia adaptada: ver la cabecera)
// ---------------------------------------------------------------------------
var CSH_GX_CAM = {
   YAW: 38, PITCH: -26,               // la pose de fábrica: desde el norte (inclinación negativa) y un poco de lado
   PITCH_MAX: 88, PERSPECTIVE: true, CAM_DIST: 2.6, NEAR: 0.08,
   ZOOM_MIN: 0.5, ZOOM_MAX: 100, ORBIT_X: 0.4, ORBIT_Y: 0.3
};
function cshGxWrapDeg(a) { var r = a % 360; return (r < 0) ? r + 360 : r; }
function cshGxPose(yaw, pitch) {
   var y = cshGxWrapDeg(cshGxIsNum(yaw) ? yaw : CSH_GX_CAM.YAW);
   var p = Math.max(-CSH_GX_CAM.PITCH_MAX, Math.min(CSH_GX_CAM.PITCH_MAX, cshGxIsNum(pitch) ? pitch : CSH_GX_CAM.PITCH));
   var k = Math.PI / 180;
   return { yaw: y, pitch: p, cy: Math.cos(y * k), sy: Math.sin(y * k), cp: Math.cos(p * k), sp: Math.sin(p * k) };
}
// La vista: yaw, pitch, zoom (travelín), ox, oy, oz (el pivote en coordenadas de la caja, kpc), f0, cx, cy (0 / NaN = los del encaje).
function cshGxCamView(v) {
   var q = v || {}, P = cshGxPose(q.yaw, q.pitch);
   function num(x, d) { return cshGxIsNum(x) ? x : d; }
   function lim(x, m) { return Math.max(-m, Math.min(m, num(x, 0))); }
   return { yaw: P.yaw, pitch: P.pitch, zoom: Math.max(CSH_GX_CAM.ZOOM_MIN, Math.min(CSH_GX_CAM.ZOOM_MAX, num(q.zoom, 1))),
            ox: lim(q.ox, 60), oy: lim(q.oy, 60), oz: lim(q.oz, 60), f0: (num(q.f0, 0) > 0) ? q.f0 : 0, cx: num(q.cx, NaN), cy: num(q.cy, NaN) };
}
function cshGxBoxRadius(box) { return Math.sqrt(box.hx * box.hx + box.hy * box.hy + box.hz * box.hz); }
function cshGxClipSegment(x1, y1, x2, y2, b) {
   var t0 = 0, t1 = 1, dx = x2 - x1, dy = y2 - y1;
   var p = [-dx, dx, -dy, dy], q = [x1 - b.x, b.x + b.w - x1, y1 - b.y, b.y + b.h - y1];
   for (var i = 0; i < 4; ++i) {
      if (p[i] === 0) { if (q[i] < 0) return null; }
      else {
         var r = q[i] / p[i];
         if (p[i] < 0) { if (r > t1) return null; if (r > t0) t0 = r; }
         else { if (r < t0) return null; if (r < t1) t1 = r; }
      }
   }
   return { x1: x1 + t0 * dx, y1: y1 + t0 * dy, x2: x1 + t1 * dx, y2: y1 + t1 * dy };
}
// EL ENCAJE: la caja entera cabe en `rect`, centrada.
function cshGxCamFrame(box, rect, yaw, pitch) {
   var unit = cshGxCam(box, { x: 0, y: 0, w: 1, h: 1 }, { yaw: yaw, pitch: pitch, zoom: 1, f0: 1, cx: 0, cy: 0 });
   var x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
   for (var a = 0; a < 8; ++a) {
      var q = unit.pxBox((a & 1) ? box.hy : -box.hy, (a & 2) ? box.hz : -box.hz, (a & 4) ? box.hx : -box.hx);
      if (q.x < x0) x0 = q.x; if (q.x > x1) x1 = q.x; if (q.y < y0) y0 = q.y; if (q.y > y1) y1 = q.y;
   }
   var f0 = Math.min(rect.w / (x1 - x0), rect.h / (y1 - y0));
   return { f0: f0, cx: rect.x + rect.w / 2 - f0 * (x0 + x1) / 2, cy: rect.y + rect.h / 2 - f0 * (y0 + y1) / 2 };
}
// LA CÁMARA: px(X, Y, Z) del mundo -> { x, y, z (zc), w, ok }; seg(...) recortada; ray(x, y) el rayo de un píxel (para el resplandor).
function cshGxCam(box, rect, view) {
   var V = cshGxCamView(view), P = cshGxPose(V.yaw, V.pitch);
   if (!(V.f0 > 0) || !isFinite(V.cx) || !isFinite(V.cy)) {
      var fr = cshGxCamFrame(box, rect, V.yaw, V.pitch);
      if (!(V.f0 > 0)) V.f0 = fr.f0;
      if (!isFinite(V.cx)) V.cx = fr.cx;
      if (!isFinite(V.cy)) V.cy = fr.cy;
   }
   var persp = (CSH_GX_CAM.PERSPECTIVE === true), K0 = CSH_GX_CAM.CAM_DIST * cshGxBoxRadius(box), K = K0 / V.zoom, sc = V.f0 * V.zoom, near = CSH_GX_CAM.NEAR * K;
   var Cx = V.ox, Cy = V.oy, Cz = V.oz, cy = P.cy, sy = P.sy, cp = P.cp, sp = P.sp, scx = V.cx, scy = V.cy;
   var clip = { x: rect.x - 64, y: rect.y - 64, w: rect.w + 128, h: rect.h + 128 };
   function cam3(u, v, t) {
      var X = u - Cx, Y = v - Cy, Z = t - Cz, d1 = Z * cy - X * sy;
      return [X * cy + Z * sy, Y * cp + d1 * sp, d1 * cp - Y * sp];
   }
   function pxBox(u, v, t) {
      var c = cam3(u, v, t);
      if (!persp) return { x: scx + sc * c[0], y: scy + sc * c[1], z: c[2], w: 1, ok: true };
      var den = K + c[2], ok = (den > near), w = K / (ok ? den : near);
      return { x: scx + sc * c[0] * w, y: scy + sc * c[1] * w, z: c[2], w: w, ok: ok };
   }
   function px(X, Y, Z) { return pxBox(-Y, -Z, X); }
   // (sin crear objetos: el trazado de las órbitas proyecta decenas de miles de puntos por fotograma —23-oct, c3_gx_prof.js—)
   function pxInto(X, Y, Z, out) {
      var u = -Y - Cx, v = -Z - Cy, t = X - Cz, d1 = t * cy - u * sy, c0 = u * cy + t * sy, c1 = v * cp + d1 * sp, c2 = d1 * cp - v * sp;
      if (!persp) { out[0] = scx + sc * c0; out[1] = scy + sc * c1; return true; }
      var den = K + c2;
      if (!(den > near)) return false;
      var w = K / den;
      out[0] = scx + sc * c0 * w; out[1] = scy + sc * c1 * w;
      return true;
   }
   function segBox(u0, v0, t0, u1, v1, t1) {
      var a = cam3(u0, v0, t0), b = cam3(u1, v1, t1), wa = 1, wb = 1;
      if (persp) {
         var da = K + a[2], db = K + b[2], f;
         if (da <= near && db <= near) return null;
         if (da <= near) { f = (near - da) / (db - da); a = [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, near - K]; da = near; }
         else if (db <= near) { f = (near - db) / (da - db); b = [b[0] + (a[0] - b[0]) * f, b[1] + (a[1] - b[1]) * f, near - K]; db = near; }
         wa = K / da; wb = K / db;
      }
      return cshGxClipSegment(scx + sc * a[0] * wa, scy + sc * a[1] * wa, scx + sc * b[0] * wb, scy + sc * b[1] * wb, clip);
   }
   function seg(X0, Y0, Z0, X1, Y1, Z1) { return segBox(-Y0, -Z0, X0, -Y1, -Z1, X1); }
   // (OJO: los argumentos NO pueden llamarse sx, sy: taparían el seno del giro `sy` de la pose; así salió el 22-oct en CabraComposition
   //  un disco 3D sin resplandor)
   function ray(qx, qy) {
      var xc = (qx - scx) / sc, yc = (qy - scy) / sc * (cshGxBroken("ray") ? -1 : 1);
      var R = [cy, 0, sy], U = [-sy * sp, cp, cy * sp], W = [-sy * cp, -sp, cy * cp];
      function toWorld(c0, c1, c2) {
         var u = Cx + c0 * R[0] + c1 * U[0] + c2 * W[0], v = Cy + c0 * R[1] + c1 * U[1] + c2 * W[1], t = Cz + c0 * R[2] + c1 * U[2] + c2 * W[2];
         return [t, -u, -v];
      }
      if (!persp) { var o0 = toWorld(xc, yc, -1000), o1 = toWorld(xc, yc, 0); return { o: o0, d: [o1[0] - o0[0], o1[1] - o0[1], o1[2] - o0[2]] }; }
      var oC = toWorld(0, 0, -K), pP = toWorld(xc, yc, 0);
      return { o: oC, d: [pP[0] - oC[0], pP[1] - oC[1], pP[2] - oC[2]] };
   }
   return { mode: "perspective", scale: sc, f0: V.f0, K: K, K0: K0, persp: persp, near: near, zoom: V.zoom, pose: P, view: V, cx: scx, cy: scy,
            rect: rect, clip: clip, right: [cy, 0, sy], up: [-sy * sp, cp, cy * sp], fwd: [-sy * cp, -sp, cy * cp],
            px: px, pxBox: pxBox, pxInto: pxInto, seg: seg, ray: ray };
}
// GIRAR (desde la vista al empezar el arrastre), DESPLAZAR, LA RUEDA hacia el cursor, ENTRE DOS VISTAS: Cabra3D tal cual.
function cshGxCamOrbit(view, dx, dy) {
   var v = cshGxCamView(view);
   v.yaw = v.yaw - dx * CSH_GX_CAM.ORBIT_X; v.pitch = v.pitch + dy * CSH_GX_CAM.ORBIT_Y;
   v.f0 = 0; v.cx = NaN; v.cy = NaN;
   return cshGxCamView(v);
}
function cshGxCamPan(fit, dx, dy) {
   var v = cshGxCamView(fit.view), k = 1 / fit.scale, R = fit.right, U = fit.up;
   v.ox -= (dx * R[0] + dy * U[0]) * k; v.oy -= (dx * R[1] + dy * U[1]) * k; v.oz -= (dx * R[2] + dy * U[2]) * k;
   return cshGxCamView(v);
}
function cshGxCamZoomAt(fit, factor, sx, sy, zHint) {
   var v = cshGxCamView(fit.view), z0 = v.zoom, z1 = Math.max(CSH_GX_CAM.ZOOM_MIN, Math.min(CSH_GX_CAM.ZOOM_MAX, z0 * factor)), r = z1 / z0;
   if (r > 1) {
      var zq = (cshGxIsNum(zHint) && (!fit.persp || fit.K + zHint > fit.near)) ? zHint : 0;
      var kk = fit.persp ? (fit.K + zq) / (fit.scale * fit.K) : 1 / fit.scale;
      var xq = (sx - fit.cx) * kk, yq = (sy - fit.cy) * kk, m = 1 - 1 / r, R = fit.right, U = fit.up, W = fit.fwd;
      v.ox += m * (xq * R[0] + yq * U[0] + zq * W[0]);
      v.oy += m * (xq * R[1] + yq * U[1] + zq * W[1]);
      v.oz += m * (xq * R[2] + yq * U[2] + zq * W[2]);
   } else if (r < 1 && z0 > 1) {
      var gq = Math.max(0, (z1 - 1) / (z0 - 1));
      v.ox *= gq; v.oy *= gq; v.oz *= gq;
   }
   v.zoom = z1;
   return cshGxCamView(v);
}
function cshGxDepthOrder(z, n) {
   var a = new Array(n);
   for (var i = 0; i < n; ++i) a[i] = i;
   a.sort(function(p, q) { return (z[q] - z[p]) || (p - q); });
   return a;
}
function cshGxDepthSize(m) { return (m >= 1) ? Math.min(5, Math.pow(m, 1.15)) : Math.max(0.3, Math.pow(Math.max(m, 1e-6), 2.2)); }
function cshGxDepthDim(m) { return (m >= 1) ? 1 : Math.max(0.35, Math.pow(Math.max(m, 1e-6), 2)); }

// ---------------------------------------------------------------------------
// LAS VISTAS 2D: desde arriba (X–Y, desde el norte) y de canto (R–z). Zoom y desplazamiento propios.
// ---------------------------------------------------------------------------
// v2 = { k (aumentos, 1 = el encuadre de fábrica), cx, cy (el centro de la vista, kpc) }.
// Desde arriba: en pantalla ARRIBA = +X (del Sol hacia el centro) y DERECHA = −Y: vista desde el polo norte sin espejo, el Sol
// abajo y el giro en el sentido de las agujas del reloj.
// (23-oct, noche) `rect.fx` (si lo hay: cshGxFitView de csh_galaxy_paint.js) = el encuadre de fábrica que contiene la nube en todo el
// tiempo, dentro del hueco que dejan la leyenda y la placa: { top: { ppk, ca, cb }, edge: { sx, sz, cR, cz }, box3 }. Sin él, lo de antes.
// (26-oct-2026, vuelos de Cabra3D en las tres vistas) CAMPOS OPCIONALES de v2, todos ausentes = lo de siempre, idéntico (la rama de siempre,
// sin tocar): pvx, pvy = el píxel del lienzo donde cae el centro (cx, cy) (de fábrica, el centro del rectángulo); rot (solo desde arriba, grados,
// positivo = antihorario en pantalla) = el mapa GIRADO en su plano alrededor de ese centro; az (solo de canto, grados) = la vista de canto
// LINEAL desde otro azimut (abajo, cshGxEdgeXf). cshGx2DZoomAt / cshGx2DPan no los conocen (el ratón del usuario nunca los pone).
// `turned`: true si la vista usa alguno (la capa fija no se corre por píxeles —cshGxStatic— y las claves de los bitmaps los llevan).
function cshGxV2Turned(v2) { return !!(v2 && ((cshGxIsNum(v2.rot) && v2.rot !== 0) || cshGxIsNum(v2.az) || cshGxIsNum(v2.pvx) || cshGxIsNum(v2.pvy))); }
function cshGxTopXf(G, rect, v2) {
   var E = G.ext.top, F = (rect && rect.fx && rect.fx.top) ? rect.fx.top : null, k = (v2 && v2.k > 0) ? v2.k : 1;
   var ccx = (v2 && cshGxIsNum(v2.cx)) ? v2.cx : (F ? F.ca : E.cx), ccy = (v2 && cshGxIsNum(v2.cy)) ? v2.cy : (F ? F.cb : E.cy);
   var ppk = k * (F ? F.ppk : Math.min(rect.w, rect.h) / (2 * E.half)), mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2;
   var flip = cshGxBroken("flip") ? -1 : 1;      // (ROJO «flip»: la vista en espejo, desde el sur)
   if (cshGxV2Turned(v2)) {
      // EL MAPA GIRADO alrededor de (cx, cy), que cae en (pvx, pvy). (ROJO «rotpivot»: gira alrededor del centro del rectángulo, no del pivote)
      var rot = cshGxIsNum(v2.rot) ? v2.rot : 0, kr = rot * Math.PI / 180, cr = Math.cos(kr), sr = Math.sin(kr);
      var pvx = cshGxIsNum(v2.pvx) ? v2.pvx : mx, pvy = cshGxIsNum(v2.pvy) ? v2.pvy : my;
      if (cshGxBroken("rotpivot") && rot !== 0)
         return { kind: "top", ppk: ppk, k: k, ca: ccx, cb: ccy, rect: rect, turned: true, rot: rot, cr: cr, sr: sr, pvx: pvx, pvy: pvy, flip: flip, red: true,
                  px: function(X, Y) { var dx = pvx + (flip * -Y - ccx) * ppk - mx, dy = pvy - (X - ccy) * ppk - my; return { x: mx + dx * cr + dy * sr, y: my - dx * sr + dy * cr }; },
                  inv: function(sx, sy) { var qx = sx - mx, qy = sy - my, dx = qx * cr - qy * sr, dy = qx * sr + qy * cr; return { X: ccy - (my + dy - pvy) / ppk, Y: -(ccx + (mx + dx - pvx) / ppk) * flip }; } };
      return { kind: "top", ppk: ppk, k: k, ca: ccx, cb: ccy, rect: rect, turned: true, rot: rot, cr: cr, sr: sr, pvx: pvx, pvy: pvy, flip: flip,
               px: function(X, Y) { var a = flip * -Y - ccx, b = X - ccy; return { x: pvx + (a * cr - b * sr) * ppk, y: pvy - (a * sr + b * cr) * ppk }; },
               inv: function(sx, sy) { var a1 = (sx - pvx) / ppk, b1 = -(sy - pvy) / ppk, a = ccx + a1 * cr + b1 * sr, b = ccy - a1 * sr + b1 * cr; return { X: b, Y: -a * flip }; } };
   }
   return { kind: "top", ppk: ppk, k: k, ca: ccx, cb: ccy, rect: rect,
            px: function(X, Y) { return { x: mx + (flip * -Y - ccx) * ppk, y: my - (X - ccy) * ppk }; },
            inv: function(sx, sy) { var a = ccx + (sx - mx) / ppk, b = ccy - (sy - my) / ppk; return { X: b, Y: -a * flip }; } };
}
// DE CANTO con v2.az (26-oct-2026): en vez de R–z (cada estrella en su radio galactocéntrico: no hay dirección de mirada), la proyección
// LINEAL a lo largo de una dirección del plano galáctico: en pantalla, h = Rp + (P − A)·ê(az) a lo ancho y z a lo alto, donde A = (ax, ay)
// (de fábrica, el Sol de hoy), Rp = |A| y ê(0) = la dirección del centro galáctico a A. Con az = 0, cerca de A, h ≈ R (A cae en R = Rp, igual que
// en R–z); al girar az, se mira el plano de canto desde otro azimut alrededor del eje vertical que pasa por A. EL FONDO (resplandor y polvo, que
// en R–z son funciones de (R, z)) se evalúa en la LÁMINA vertical que pasa por A y contiene ê: el punto de la pantalla (h, z) es el de radio
// slR(h) = |A + (h − Rp)·ê|; con az = 0 eso es |h|, lo de siempre. Las estrellas y el centro galáctico, proyectados (de todas las
// profundidades); el fondo, la lámina. (ROJO «azfold»: az se ignora y sigue en R–z: la vuelta no gira nada.)
function cshGxEdgeXf(G, rect, v2) {
   var E = G.ext.edge, F = (rect && rect.fx && rect.fx.edge) ? rect.fx.edge : null, k = (v2 && v2.k > 0) ? v2.k : 1;
   var cR = (v2 && cshGxIsNum(v2.cx)) ? v2.cx : (F ? F.cR : E.r1 * 0.48), cz = (v2 && cshGxIsNum(v2.cy)) ? v2.cy : (F ? F.cz : 0);
   var sx = k * (F ? F.sx : rect.w / (1.04 * E.r1)), sz = k * (F ? F.sz : rect.h / (2 * E.z1)), mx = rect.x + rect.w / 2, my = rect.y + rect.h / 2;
   if (cshGxV2Turned(v2)) {
      var pvx = cshGxIsNum(v2.pvx) ? v2.pvx : mx, pvy = cshGxIsNum(v2.pvy) ? v2.pvy : my, lin = cshGxIsNum(v2.az) && !cshGxBroken("azfold");
      var out = { kind: "edge", sx: sx, sz: sz, k: k, cR: cR, cz: cz, rect: rect, turned: true, pvx: pvx, pvy: pvy, lin: lin,
                  px: function(R, z) { return { x: pvx + (R - cR) * sx, y: pvy - (z - cz) * sz }; },
                  inv: function(px, py) { return { R: cR + (px - pvx) / sx, z: cz - (py - pvy) / sz }; } };
      if (lin) {
         var ax = cshGxIsNum(v2.ax) ? v2.ax : G.sun.x, ay = cshGxIsNum(v2.ay) ? v2.ay : G.sun.y, Rp = Math.sqrt(ax * ax + ay * ay) || 1;
         var ka = v2.az * Math.PI / 180, ux = ax / Rp, uy = ay / Rp, ca = Math.cos(ka), sa = Math.sin(ka), ex = ux * ca - uy * sa, ey = ux * sa + uy * ca;
         out.az = v2.az; out.ax = ax; out.ay = ay; out.Rp = Rp; out.ex = ex; out.ey = ey;
         out.h = function(X, Y) { return Rp + (X - ax) * ex + (Y - ay) * ey; };
         out.hGC = Rp - (ax * ex + ay * ey);
         out.slR = function(h) { var t = h - Rp, X = ax + t * ex, Y = ay + t * ey; return Math.sqrt(X * X + Y * Y); };
      }
      return out;
   }
   return { kind: "edge", sx: sx, sz: sz, k: k, cR: cR, cz: cz, rect: rect,
            px: function(R, z) { return { x: mx + (R - cR) * sx, y: my - (z - cz) * sz }; },
            inv: function(px, py) { return { R: cR + (px - mx) / sx, z: cz - (py - my) / sz }; } };
}
// LA RUEDA en 2D: el punto bajo el cursor no se mueve. Devuelve el v2 nuevo.
function cshGx2DZoomAt(xf, factor, sx, sy) {
   var k1 = Math.max(0.5, Math.min(200, xf.k * factor)), r = k1 / xf.k, R = xf.rect, mx = R.x + R.w / 2, my = R.y + R.h / 2;
   if (xf.kind === "top") {
      var a = xf.ca + (sx - mx) / xf.ppk, b = xf.cb - (sy - my) / xf.ppk;
      return { k: k1, cx: a - (a - xf.ca) / r, cy: b - (b - xf.cb) / r };
   }
   var Rq = xf.cR + (sx - mx) / xf.sx, zq = xf.cz - (sy - my) / xf.sz;
   return { k: k1, cx: Rq - (Rq - xf.cR) / r, cy: zq - (zq - xf.cz) / r };
}
function cshGx2DPan(xf, dx, dy) {
   if (xf.kind === "top") return { k: xf.k, cx: xf.ca - dx / xf.ppk, cy: xf.cb + dy / xf.ppk };
   return { k: xf.k, cx: xf.cR - dx / xf.sx, cy: xf.cz + dy / xf.sz };
}
#endif
