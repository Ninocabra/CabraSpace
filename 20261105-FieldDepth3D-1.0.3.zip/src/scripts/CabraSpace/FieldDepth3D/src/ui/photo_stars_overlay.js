// ============================================================================
// ui/photo_stars_overlay.js — LAS ESTRELLAS DEL DESPLEGABLE «Stars», TAMBIEN EN LA FOTO 2D (21-oct-2026; revisado el 22-oct)
// ----------------------------------------------------------------------------
// Nino: «cuando selecciono las distintas opciones de estrellas, esto debe reflejarse en la imagen 2D, mostrando las estrellas
// superpuestas segun la opcion elegida». Hasta hoy el desplegable (ui/starfield_photostars.js) solo cambiaba el 3D; la foto
// enseñaba un anillo de la estrella elegida. Aqui la foto pinta LAS MISMAS estrellas que el 3D, en su pixel, como las pinta el 3D:
//
//   opcion del 3D          que pinta el 3D                                 que pone la foto (anillo fino, alfa 0,7)
//   Gaia                   punto, color BP-RP, tamaño por G                anillo del color de Gaia, radio por clase de G
//   Photo colour           el punto con el color medido en la foto         anillo del color medido en la foto (limpias y
//                          (limpias y saturadas; las demas, Gaia)          saturadas; las demas, color de Gaia: igual que el 3D);
//                                                                           las que su color difiere del de Gaia MAS ALLA de la dispersion
//                                                                           de la foto llevan un SEGUNDO anillo (y el pie lo cuenta)
//   Photo                  el RECORTE de la foto (limpias y saturadas);    SIN anillo en las que llevan recorte (la foto YA es ese
//                          las demas, su punto de Gaia                     recorte: tapar la estrella real seria mentir);
//                                                                           anillo de Gaia en las que el 3D deja como punto
//   Photo size             el recorte con su tamaño EN la foto             anillo del color de la foto con el RADIO MEDIDO de la
//                                                                           estrella (el del recorte, en pixeles de imagen:
//                                                                           crece con el zoom); el resto, como en «Photo»
// (27-oct-2026, D2 de Nino) «None» ya NO es una opcion: la foto limpia se pide SOLO con el boton de la esquina (ui/photo_overlay_toggle.js).
// Los miembros de un cumulo van siempre con su punto de Gaia (cpSvPhotoLook): anillo de Gaia, el mas pequeño. LAS DE DISTANCIA DUDOSA (RUWE ≥ 1,4:
// el 3D las pinta HUECAS) llevan un anillo A TRAZOS en todas las opciones.
// «Photo» y «Photo size» solo se distinguen en el 3D por la profundidad (uno mengua con ella); en 2D no hay profundidad, y lo que
// queda como diferencia verdadera es el tamaño medido: por eso «Photo size» lo dibuja y «Photo» no.
// COLOR (22-oct, Nino: «A y B se ven iguales»): los anillos de TODAS las opciones llevan un realce de saturacion PERCEPTUAL (croma ×
// C3_OV.BOOST en CIE Lab, luminosidad comun con tope, dentro del gamut): la misma funcion `c3OvRing` en Gaia y en Photo colour. Si la foto esta bien
// calibrada A y B DEBEN parecerse (es fisica: no se finge); lo que se marca es donde NO se parecen.
// POSICION (22-oct): la solucion astrometrica de la imagen se aparta de las estrellas (LDu 2: hasta 6 px); los anillos llevan el desfase local
// foto − Gaia del Bloque G (ui/photo_offsets.js).
//
// LA MAQUINA DEL TIEMPO: con t ≠ 0 el overlay SE OCULTA. Ahi `tmPaintPhoto` ya pinta las estrellas movidas (en su sitio de ese
// instante) sobre la foto sin estrellas: anillos en el sitio de HOY serian estrellas fantasma (lo que ya se vio el 14-oct).
//
// RENDIMIENTO: la lista de marcas (en pixeles de imagen, ordenada por pluma para cambiar lo minimo) se hace FUERA de onPaint, al elegir la
// opcion o cambiar la medida, y se guarda por (estado, opcion, medida). LA CAPA de anillos es un bitmap transparente de la zona visible MAS UN
// MARGEN (el visor × 1,6, con tope), en coordenadas de la foto ya ampliada; al DESPLAZAR (arrastrar, 22-oct: «7 000 anillos = 300 ms por
// fotograma») onPaint solo COPIA la capa con el desplazamiento —los deltas del arrastre son enteros: el pixel es identico al de un trazado
// nuevo—; se rehace al cambiar el zoom, la opcion, el tamaño del visor o al salirse del margen. El tamaño es CONSTANTE en pantalla (minimo
// 4 px × escala de la interfaz) salvo «Photo size», que es el tamaño real de la estrella en la foto (con el mismo minimo). Plumas cacheadas.
// Metodos de CPStarfieldDock (como ui/starfield_photostars.js). ES5.
// ============================================================================

// (21-oct) «None» fue la quinta opcion del desplegable («que se pueda ver la foto limpia»). (27-oct-2026, D2 de Nino) FUERA: era un segundo
// camino al boton de la esquina de la foto (ui/photo_overlay_toggle.js, 26-oct), que ademas conserva la opcion elegida. Ocultar las estrellas
// de la foto se hace SOLO con el boton. Lo RECORDADO de antes (Settings «Starfield/stars» = "none") se MIGRA al abrir: la opcion de fabrica
// («Gaia», la primera) + la superposicion OCULTA en esa sesion (la primera apertura se ve igual que antes: la foto limpia). Se reescribe "gaia"
// en Settings. (30-oct, Nino: los cuatro iguales) El boton SI se recuerda ya entre sesiones, aparte: `Cabra3D/aView`, CabraShared/csh_viewpref.js; antes, decision T3 del 26-oct: no.
// Ver `_starsBuild` abajo.
var C3_STARS_PREF_TEST = false;       // la costura de las pruebas: encendido, lo recordado se lee y se escribe tambien en una pasada sin pantalla (instancia 232)
var C3_STARS_MIGRATE = true;          // la costura del rojo de la migracion (C3_MUTATE=4): apagado, un "none" recordado abre con los anillos VISIBLES
// Un valor recordado de antes -> { mode, hide } (o null si es una opcion de hoy). Puro.
function c3StarsLegacy(m) { return (String(m) === "none") ? { mode: CP_SV.STARS_MODES[0], hide: true } : null; }
var C3_STARS_OVERLAY = true;          // la costura de las pruebas: apagado, la foto no pinta las estrellas (el rojo, C3_MUTATE=1)
var C3_OV_SHIFT = 0;                  // la costura del rojo de la POSICION (desplaza los anillos; 0 de verdad)
var C3_OV_LAYER = true;               // la costura del rojo del DESPLAZAMIENTO (C3_MUTATE=6): apagado, la capa se traza en cada fotograma
var C3_OV = {
   ALPHA: 0.7,                        // opacidad de los anillos
   MIN_R: 4,                          // radio minimo en pixeles (× escala de la interfaz)
   MAX_R: 60,                         // tope del radio medido de «Photo size» (× escala)
   MEMBER_R: 4,                       // los miembros de un cumulo: el mas pequeño
   BOOST: 2.0,                        // realce de croma (CIE Lab) de los anillos; 1 = sin realce
   RING_L: 72,                        // luminosidad maxima de los anillos (CIE L*): a la de la rampa de Gaia (~90) el gamut casi no deja croma
   SECOND_R: 3.5,                     // el segundo anillo de «difiere de Gaia»: pixeles (× escala) por fuera del primero
   DIFF_SNR: 30,                      // «difiere» se mide contra la dispersion de las estrellas con al menos esta señal / ruido de pico (el ruido de foton ya no manda)
   DIFF_SIGMAS: 3,                    // y solo cuenta pasadas estas sigmas robustas (MAD) de esa dispersion
   DIFF_MIN: 0.02,                    // y al menos esto en calidez ((R − B)/(R + G + B)): ~ΔE 3, lo que un ojo ve
   LAYER_MARGIN: 0.3,                 // margen de la capa por cada lado, en fracciones del visor
   LAYER_MAX: 5200                    // lado maximo de la capa (pixeles)
};

// --- el color: CIE Lab (D65), sRGB ----------------------------------------------------------------------------------------------------
function c3OvLin(c) { c /= 255; return (c <= 0.04045) ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
function c3OvGam(v) { v = (v <= 0.0031308) ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055; return 255 * v; }
function c3OvToLab(rgb) {
   var r = c3OvLin((rgb >>> 16) & 255), g = c3OvLin((rgb >>> 8) & 255), b = c3OvLin(rgb & 255);
   var x = (0.4124564 * r + 0.3575761 * g + 0.1804375 * b) / 0.95047, y = 0.2126729 * r + 0.7151522 * g + 0.0721750 * b, z = (0.0193339 * r + 0.1191920 * g + 0.9503041 * b) / 1.08883;
   function f(t) { return (t > 216 / 24389) ? Math.pow(t, 1 / 3) : (24389 / 27 * t + 16) / 116; }
   var fx = f(x), fy = f(y), fz = f(z);
   return { L: 116 * fy - 16, a: 500 * (fx - fy), b: 200 * (fy - fz) };
}
function c3OvFromLab(L, a, b) {              // -> [r, g, b] sin recortar (0…255 si cabe en sRGB)
   var fy = (L + 16) / 116, fx = fy + a / 500, fz = fy - b / 200;
   function fi(t) { var t3 = t * t * t; return (t3 > 216 / 24389) ? t3 : (116 * t - 16) / (24389 / 27); }
   var x = 0.95047 * fi(fx), y = fi(fy), z = 1.08883 * fi(fz);
   return [c3OvGam(3.2404542 * x - 1.5371385 * y - 0.4985314 * z), c3OvGam(-0.9692660 * x + 1.8760108 * y + 0.0415560 * z), c3OvGam(0.0556434 * x - 0.2040259 * y + 1.0572252 * z)];
}
// (L, a, b) -> 0xRRGGBB; si se sale del gamut sRGB, la mayor croma que cabe a esa luminosidad y ese matiz (biseccion).
function c3OvFit(L, a, b) {
   function fits(t) { var c = c3OvFromLab(L, a * t, b * t); return c[0] >= -0.5 && c[0] <= 255.5 && c[1] >= -0.5 && c[1] <= 255.5 && c[2] >= -0.5 && c[2] <= 255.5; }
   var t = 1, lo = 0, hi = 1, i;
   if (!fits(1)) { for (i = 0; i < 14; ++i) { var mid = (lo + hi) / 2; if (fits(mid)) lo = mid; else hi = mid; } t = lo; }
   var c2 = c3OvFromLab(L, a * t, b * t);
   function q(v) { return Math.max(0, Math.min(255, Math.round(v))); }
   return (q(c2[0]) << 16) | (q(c2[1]) << 8) | q(c2[2]);
}
// EL COLOR DEL ANILLO (el mismo mapa en A y B). La rampa de Gaia es pastel y clara (L ≈ 90: ahi el gamut sRGB casi no deja croma, y un realce no
// se nota); el color de la foto, normalizado al canal mayor = 255, es mas claro y saturado por construccion. Para que los anillos se puedan
// comparar y el realce quepa: LUMINOSIDAD comun, la de Gaia con tope C3_OV.RING_L, y croma × k (CIE Lab, dentro del gamut). El color de la foto
// entra con su MATIZ y su saturacion relativa (a, b × L_anillo / L_foto): A y B solo difieren en lo que la foto dice de la estrella.
// `photoRgb` < 0 = sin color de la foto (Gaia). Devuelve 0xRRGGBB.
function c3OvRing(gaiaRgb, photoRgb, k) {
   var g = c3OvToLab(gaiaRgb), L = Math.min(g.L, C3_OV.RING_L), a = g.a, b = g.b;
   if (photoRgb >= 0) { var p = c3OvToLab(photoRgb); if (p.L > 1) { var s = L / p.L; a = p.a * s; b = p.b * s; } }
   var kk = (k > 1) ? k : 1;
   return c3OvFit(L, a * kk, b * kk);
}
// La calidez de un color de pantalla: (R − B) / (R + G + B). (Sirve para comparar el color medido en la foto con el de Gaia.)
function c3OvWarmth(rgb) { var r = (rgb >>> 16) & 255, g = (rgb >>> 8) & 255, b = rgb & 255, s = r + g + b; return (s > 0) ? (r - b) / s : 0; }

// El radio (pixeles logicos) de una estrella de Gaia por su clase de brillo (`ob.size`: 2,6 · 2,0 · 1,5 · 1,1, de cpSvDistModel).
function c3OvGaiaRadius(ob) {
   if (ob.kind === "member") return C3_OV.MEMBER_R;
   return Math.max(C3_OV.MIN_R, 1.5 + 2.5 * ob.size);
}

// LA LISTA de marcas de una opcion, en pixeles de imagen (con el desfase local foto − Gaia). Devuelve { mode, list, cutouts, rings, doubtful, diff }:
// `cutouts` = las estrellas que el 3D pinta con su recorte (en «Photo» y «Photo size»): en «Photo» no llevan anillo. Cada marca = { ref, x, y,
// rgb (realzado), r (logico), px (radio medido en pixeles de imagen, 0 = tamaño fijo), look, dash (distancia dudosa), diff (0 · 1 mas roja · −1 mas azul que Gaia) }.
CPStarfieldDock.prototype._ovMarkers = function(st, mode) {
   var ps = st.ps, ok = (mode !== "gaia" && ps && ps.meas), model = this._distModel(), stars = st.result.stars, list = [], cut = 0, i, doubt = 0;
   if (model && model.tmBase) model = model.tmBase;            // (siempre las estrellas de AHORA)
   var field = (C3_OV_CORRECT === true) ? this._offField(st) : null, boost = C3_OV.BOOST, wantDiff = (mode === "photo-colour"), dw = [], dwSnr = [];
   for (i = 0; i < model.objects.length; ++i) {
      var ob = model.objects[i];
      if (ob.kind !== "star" && ob.kind !== "member") continue;
      var s = stars[ob.ref];
      if (!s || typeof s.x !== "number" || typeof s.y !== "number") continue;
      var me = ok ? ps.meas[ob.ref] : null, look = ok ? cpSvPhotoLook(mode, ob.kind, me ? me.cat : "", CP_SFUI_PS_R4, CP_SFUI_PS_R5) : "gaia";
      var gaiaRgb = ob.rgb, photoMix = -1, px = 0, shown = "gaia", dash = (ob.suspect === true), photoRgb = -1;
      if (dash) { ++doubt; look = "gaia"; }                      // (distancia dudosa: el 3D la pinta HUECA y con el color de Gaia; aqui, a trazos)
      if (look === "colour") {
         if (ps.rgb[ob.ref] !== undefined) { photoRgb = ps.rgb[ob.ref]; photoMix = photoRgb; shown = "colour"; }
      } else if (look === "sprite") {
         if (ps.spr[ob.ref]) {
            ++cut;                                              // (el 3D la pinta con su recorte)
            if (mode === "photo") continue;                     // la foto YA es ese recorte: sin anillo
            if (ps.rgb[ob.ref] !== undefined) photoMix = ps.rgb[ob.ref];
            px = me ? me.r : 0; shown = "sprite";
         }                                                      // (sin recorte hecho el 3D vuelve a su punto: anillo de Gaia)
      } else if (look === "synth-photo" || look === "synth-gaia") {
         if (look === "synth-photo" && ps.rgb[ob.ref] !== undefined) photoMix = ps.rgb[ob.ref];
         shown = look;
      }
      var off = field ? field.at(s.x, s.y) : C3_OFF_NONE, mk = { ref: ob.ref, x: s.x + off.dx, y: s.y + off.dy, rgb: c3OvRing(gaiaRgb, photoMix, boost) & 0xfcfcfc, r: c3OvGaiaRadius(ob), px: px, look: shown, dash: dash, diff: 0, faint: (ob.faint > 0) };      // (26-oct-2026, A'b de Nino: `faint` = estrella DEBIL, S/R a ojo de 12 a 20: su anillo, mas tenue)
      list.push(mk);
      if (wantDiff && photoRgb >= 0 && me) { mk.w = c3OvWarmth(photoRgb) - c3OvWarmth(gaiaRgb); mk.snr = me.snr; dw.push(mk); }
   }
   // «difiere de Gaia»: el color medido contra el de Gaia, en calidez; la dispersion (MAD robusto) sale de las estrellas con buena señal
   // (con DIFF_SNR el ruido de foton ya no manda: lo que queda es calibracion + la rampa de color) y el desplazamiento general (la foto mas roja o mas
   // azul que Gaia en conjunto) se resta: eso lo dice el pie aparte. Lo marcado = pasa de DIFF_SIGMAS sigmas y de DIFF_MIN.
   var diff = { m: dw.length, n: 0, redder: 0, bluer: 0, shift: 0, sigma: 0, thr: 0 };
   if (wantDiff && dw.length >= 20) {
      var all = [], good = [], k;
      for (k = 0; k < dw.length; ++k) { all.push(dw[k].w); if (dw[k].snr >= C3_OV.DIFF_SNR) good.push(dw[k].w); }
      if (good.length < 20) good = all;
      var med = cshMedianN(all, all.length), sig = cshMad(good, cshMedianN(good, good.length)), thr = Math.max(C3_OV.DIFF_SIGMAS * sig, C3_OV.DIFF_MIN);
      diff.shift = med; diff.sigma = sig; diff.thr = thr;
      for (k = 0; k < dw.length; ++k) {
         var d = dw[k].w - med;
         if (Math.abs(d) > thr) { dw[k].diff = (d > 0) ? 1 : -1; ++diff.n; if (d > 0) ++diff.redder; else ++diff.bluer; }
      }
   }
   // por pluma (color + trazos): pocos cambios al pintar
   list.sort(function(a, b) { return (a.rgb + (a.dash ? 0x1000000 : 0) + (a.faint ? 0x4000000 : 0)) - (b.rgb + (b.dash ? 0x1000000 : 0) + (b.faint ? 0x4000000 : 0)); });
   var rings = {};
   for (i = 0; i < list.length; ++i) rings[list[i].look] = (rings[list[i].look] || 0) + 1;
   return { mode: mode, list: list, cutouts: cut, rings: rings, doubtful: doubt, diff: diff, offField: !!field };
};
// La lista guardada (por estado, opcion y medida): se rehace si alguno cambia. Sin proceso ni lectura de la imagen: solo recorre el modelo
// (y, la primera vez, mide el desfase local de la foto: `_offField`, ~0,3 s, una vez por estado).
// (la guardada, si sigue valiendo; si no, null: comprobarlo no cuesta nada)
CPStarfieldDock.prototype._ovValid = function(st) {
   var ps = st.ps, mode = this.starsMode, c = st.c3ov, corr = (C3_OV_CORRECT === true), boost = C3_OV.BOOST;
   return (c && c.mode === mode && c.meas === (ps ? ps.meas : null) && c.from === (ps ? ps.from : null) && c.dist === st.dist && c.corr === corr && c.boost === boost && c.nStars === st.result.stars.length) ? c : null;
};
CPStarfieldDock.prototype._ovEnsure = function(st) {
   var ps = st.ps, mode = this.starsMode, c = this._ovValid(st), corr = (C3_OV_CORRECT === true), boost = C3_OV.BOOST;
   if (c) return c;
   var t0 = Date.now(), m = this._ovMarkers(st, mode);
   m.meas = ps ? ps.meas : null; m.from = ps ? ps.from : null; m.dist = st.dist; m.corr = corr; m.boost = boost; m.nStars = st.result.stars.length; m.ms = Date.now() - t0;
   st.c3ov = m;
   return m;
};
// Al elegir la opcion (o abrir con una puesta): la lista y la capa se hacen AQUI, no al pintar, y la foto se repinta.
CPStarfieldDock.prototype._ovRefresh = function() {
   var st = this.state;
   try { if (st && this.mode === "dist" && this.dialog.preview.bitmap && !(this.tm && this.tm.t !== 0) && this.starsOverlayOn !== false) this._ovLayer(st, this.dialog.preview); } catch (e) {}
   try { this.dialog.preview.viewport.repaint(); } catch (e2) {}
};
// (27-oct, D2) LA MIGRACION de «None»: el base ya descarta "none" (no esta en CP_SV.STARS_MODES) y abre con «Gaia»; aqui se oculta ademas la
// superposicion (la foto limpia, como la dejo el usuario) y se reescribe lo recordado. Sin fallo: cualquier error deja el base tal cual.
var c3OvBaseStarsBuild = CPStarfieldDock.prototype._starsBuild;
CPStarfieldDock.prototype._starsBuild = function() {
   c3OvBaseStarsBuild.call(this);
   var m = null, prefs = (!CP_NO_MAIN || C3_STARS_PREF_TEST === true);
   if (prefs) try { var v = Settings.read(CP_SETTINGS_PREFIX + "/Starfield/stars", DataType_String); if (v !== null && v !== undefined && Settings.lastReadOK !== false) m = String(v); } catch (eR) {}
   var L = (C3_STARS_MIGRATE === true && m !== null) ? c3StarsLegacy(m) : null;
   if (!L) return;
   this.starsMode = L.mode;
   this.starsOverlayOn = !L.hide;
   this.c3StarsMigrated = m;
   if (prefs) { try { Settings.write(CP_SETTINGS_PREFIX + "/Starfield/stars", DataType_String, L.mode); } catch (eW) {} }
   try { this._starsItems(); } catch (eI) {}
};
var c3OvBaseSetStarsMode = CPStarfieldDock.prototype.setStarsMode;
CPStarfieldDock.prototype.setStarsMode = function(mode) {
   var r = c3OvBaseSetStarsMode.call(this, mode);
   if (r) this._ovRefresh();
   return r;
};
// Lo que dice el pie en «Photo colour»: cuantas difieren de Gaia y hacia donde (con el desplazamiento general, si lo hay).
CPStarfieldDock.prototype._ovDiffText = function() {
   var st = this.state;
   if (!st || this.starsMode !== "photo-colour" || !st.result) return "";
   var d = null;
   try { d = this._ovEnsure(st).diff; } catch (e) { return ""; }
   if (!d || d.m < 20) return "";
   var s = format(optT("%s of %s stars: the photo colour differs from Gaia (%s redder, %s bluer); double ring."), cpSvGroup(d.n), cpSvGroup(d.m), cpSvGroup(d.redder), cpSvGroup(d.bluer));
   if (Math.abs(d.shift) >= 0.02) s += " " + format((d.shift > 0) ? optT("On average the photo is redder than Gaia (%s).") : optT("On average the photo is bluer than Gaia (%s)."), cpSvFx(Math.abs(d.shift), 3));
   return s;
};

// LA CAPA ---------------------------------------------------------------------------------------------------------------------------------
CPStarfieldDock.prototype._ovFree = function() {
   var c = this._ovCache;
   if (c && c.bmp) { try { cpSfUiFree(c.bmp); } catch (e) {} }
   this._ovCache = null;
};
// Traza la capa que cubre [X0, X0 + LW] × [Y0, Y0 + LH] (pixeles de pantalla de la foto ya ampliada: sin el desplazamiento del visor).
CPStarfieldDock.prototype._ovDraw = function(ov, pv, sc, lw, X0, Y0, LW, LH) {
   var list = ov.list, zx = pv.scale / Math.max(1e-9, pv.imageCoordScaleX), zy = pv.scale / Math.max(1e-9, pv.imageCoordScaleY);
   if (!this._ovPens || this._ovPensW !== lw) { this._ovPens = {}; this._ovPensW = lw; this._ovBrush = new Brush(0x00000000); }
   var bmp = new Bitmap(LW, LH);
   bmp.fill(0x00000000);                                         // (transparente: antes de abrir el Graphics)
   var g = new Graphics(bmp), a = Math.round(C3_OV.ALPHA * 255), last = -1, n = 0, rec = (this._ovRecord === true) ? [] : null, i, m, ringAdd = C3_OV.SECOND_R * sc;
   try {
      g.antialiasing = true;
      g.brush = this._ovBrush;
      for (i = 0; i < list.length; ++i) {
         m = list[i];
         var X = m.x * zx + C3_OV_SHIFT, Y = m.y * zy, x = X - X0, y = Y - Y0, r = ((m.px > 0) ? Math.min(C3_OV.MAX_R * sc, Math.max(C3_OV.MIN_R * sc, m.px * zx)) : m.r * sc);
         if (x < -r - ringAdd || y < -r - ringAdd || x > LW + r + ringAdd || y > LH + r + ringAdd) continue;
         // (26-oct-2026, decision «b» de Nino: el anillo de una estrella DEBIL va a TROZOS —c3DashCircle, trazos segun el radio— y con la opacidad de la clara; la
         // «dim» de antes, 55 %, es solo el modo C3_FAINT_STYLE = "dim". Una estrella de distancia dudosa que ademas es debil lleva el de trozos.)
         var fdash = (m.faint === true && C3_FAINT_STYLE === "dash"), fdim = (m.faint === true && C3_FAINT_STYLE === "dim");
         var pk = m.rgb + (m.dash ? 0x1000000 : 0) + (fdim ? 0x4000000 : 0) + (fdash ? 0x8000000 : 0);
         if (pk !== last) {
            var pen = this._ovPens[pk];
            if (!pen) pen = this._ovPens[pk] = fdash ? c3FlatPen(((a << 24) | m.rgb) >>> 0, lw) : new Pen((((fdim ? Math.round(a * C3_FAINT_DIM) : a) << 24) | m.rgb) >>> 0, lw, m.dash ? PenStyle_Dash : PenStyle_Solid);
            g.pen = pen; last = pk;
         }
         if (fdash) c3DashCircle(g, x, y, r, lw); else g.drawEllipse(x - r, y - r, x + r, y + r);
         if (m.diff !== 0) {                                          // «difiere de Gaia»: un segundo anillo, mas grueso y opaco, para que se vea
            var pk2 = m.rgb + 0x2000000, pen2 = this._ovPens[pk2];
            if (!pen2) pen2 = this._ovPens[pk2] = new Pen((0xff000000 | m.rgb) >>> 0, lw * 2);
            g.pen = pen2; last = -1;
            g.drawEllipse(x - r - ringAdd, y - r - ringAdd, x + r + ringAdd, y + r + ringAdd);
         }
         ++n;
         if (rec) rec.push({ ref: m.ref, X: X, Y: Y, r: r, rgb: m.rgb, look: m.look, dash: m.dash, diff: m.diff, faint: !!m.faint, fdash: fdash });
      }
   } finally { g.end(); }
   return { bmp: bmp, n: n, rec: rec };
};
// La capa vigente. Se REUSA mientras la foto no cambie de zoom ni el visor de tamaño y el visor siga DENTRO de la capa (desplazar = copiar);
// si no, se traza una nueva centrada en el visor. `x0, y0`: donde cae el origen de la capa en el visor (pixeles enteros: el arrastre mueve
// la foto en pasos enteros, asi que la copia es identica a un trazado nuevo).
// (22-oct, fluidez: rehacer la capa son 170-290 ms con 7 000-13 000 anillos. Mientras se gira el 3D o corre una transicion —abrir el panel
// cambia el tamaño del visor en cada fotograma: eran 5 capas nuevas, ~0,9 s, durante la transicion de abrir; la red, al llegar, cambia el
// modelo y la capa se rehacia en mitad de un giro—, NO se rehace: si la capa vieja vale para este zoom y este visor se sigue copiando
// (con las marcas de antes, un instante), y si no, la foto va sin anillos; en cuanto el 3D queda quieto 0,25 s, se rehace FUERA de onPaint
// (`_ovIdle`). `allowDefer` = false (o CP_SFUI_NET_DEFER apagado: el rojo de c3_perf) la rehace siempre en el acto, como antes.)
CPStarfieldDock.prototype._ovBusy = function() {
   return (CP_SFUI_NET_DEFER === true) && (this.anim !== null || this._animPending === true || !!(this._drag && this._drag.moved) || this._light === true);
};
CPStarfieldDock.prototype._ovIdle = function() {
   var self = this;
   if (!this._ovTimer) {
      this._ovTimer = new Timer; this._ovTimer.interval = 0.25; this._ovTimer.periodic = false;
      this._ovTimer.onTimeout = function() {
         if (self._closed || self.mode === "") return;
         if (self._ovBusy() || cpQuiet()) { try { self._ovTimer.start(); } catch (e) {} return; }
         self._ovRefresh();
      };
   }
   try { this._ovTimer.stop(); this._ovTimer.start(); } catch (e2) {}
};
CPStarfieldDock.prototype._ovLayer = function(st, pv, allowDefer) {
   var sc = cpUiScale(pv.viewport), lw = Math.max(1, sc), vw = pv.viewport.width, vh = pv.viewport.height;
   var key = [this.starsMode, vw, vh, pv.scale, sc, pv.imageCoordScaleX, C3_OV_SHIFT, this._ovRecord === true, C3_OV.BOOST, C3_FAINT_STYLE].join("|"), c = this._ovCache;
   var inside = !!(c && pv.sx >= c.X0 && pv.sy >= c.Y0 && pv.sx + vw <= c.X0 + c.LW && pv.sy + vh <= c.Y0 + c.LH);
   if (allowDefer === true && C3_OV_LAYER === true && this._ovBusy() && !(c && c.key === key && inside && c.ov === this._ovValid(st))) {
      this._ovIdle();
      if (c && c.key === key && inside) { c.rebuilt = false; c.stale = true; return c; }
      return null;
   }
   var ov = this._ovEnsure(st);
   if (c && c.key === key && c.ov === ov && C3_OV_LAYER === true && inside) { c.rebuilt = false; return c; }
   this._ovFree();
   var t0 = Date.now(), LW = Math.min(C3_OV.LAYER_MAX, Math.round(vw * (1 + 2 * C3_OV.LAYER_MARGIN))), LH = Math.min(C3_OV.LAYER_MAX, Math.round(vh * (1 + 2 * C3_OV.LAYER_MARGIN)));
   var mx = Math.floor((LW - vw) / 2), my = Math.floor((LH - vh) / 2), X0 = pv.sx - mx, Y0 = pv.sy - my;      // (X0 − sx = −mx: entero)
   c = this._ovDraw(ov, pv, sc, lw, X0, Y0, LW, LH);
   c.key = key; c.ov = ov; c.rebuilt = true; c.ms = Date.now() - t0; c.X0 = X0; c.Y0 = Y0; c.LW = LW; c.LH = LH;
   this._ovCache = c;
   return c;
};

// PINTAR (lo llama `dialog.paintPhotoOverlay`, antes del anillo de la estrella elegida). Solo copia la capa (la rehace si hace falta).
// Devuelve cuantos anillos lleva. `this._ovRecord = true` (las pruebas) guarda en `this._ovLast` lo del visor (posiciones de pantalla).
CPStarfieldDock.prototype.starsPaintPhoto = function(g, pv) {
   var st = this.state, rec = this.dialog.currentRec;
   pv.curtainX = null;
   this._ovStats = { drawn: 0, total: 0, mode: this.starsMode, hidden: "" };
   var why = this._ovWhy();                                        // (la causa ajena al boton: ui/photo_overlay_toggle.js)
   if (why !== "") { this._ovStats.hidden = why; this._ovFree(); return 0; }
   // (26-oct-2026, el boton de la izquierda) oculta A PROPOSITO: solo se deja de pintar; la capa guardada y la lista se CONSERVAN (al volver, se copia)
   if (this.starsOverlayOn === false && C3_OVT_SEAM === true) { this._ovStats.hidden = "toggle"; return 0; }
   var t0 = Date.now(), c, ov;
   try { c = this._ovLayer(st, pv, true); } catch (eL) { this._ovStats.hidden = "error: " + eL; this._ovFree(); throw eL; }
   if (c === null) { this._ovStats.hidden = "deferred"; return 0; }       // (girando o en una transicion: la capa, al quedar quieto)
   ov = c.ov;
   var vw = pv.viewport.width, vh = pv.viewport.height;
   // (31-oct-2026, Nino) «Compare»: los anillos solo a la derecha de la linea; la foto de la izquierda, limpia
   var cmpX = (this.starsCompare === true) ? Math.round(vw * cshCurtainClamp(pv.curtainFrac)) : null;
   if (cmpX !== null) g.clipRect = new Rect(cmpX, 0, vw, vh);
   g.drawBitmap(Math.round(c.X0 - pv.sx), Math.round(c.Y0 - pv.sy), c.bmp);
   if (cmpX !== null) { g.clipRect = new Rect(0, 0, vw, vh); cshCurtainPaint(g, cmpX, 0, vh, 0, vw, cpUiScale(pv.viewport), optT("Real photo"), optT("Stars")); pv.curtainX = cmpX; }
   this._ovStats = { drawn: c.n, total: ov.list.length, mode: this.starsMode, hidden: "", ms: Date.now() - t0, rebuilt: c.rebuilt, cutouts: ov.cutouts, rings: ov.rings, built: ov.ms, drawMs: c.ms, doubtful: ov.doubtful, diff: ov.diff, offField: ov.offField, layer: c.LW + "x" + c.LH };
   if (c.rec) {                                                  // (las pruebas: lo que cae en el visor, en pixeles de pantalla)
      var out = [], i, e;
      for (i = 0; i < c.rec.length; ++i) {
         e = c.rec[i]; var x = e.X - pv.sx, y = e.Y - pv.sy;
         if (x >= -e.r && y >= -e.r && x <= vw + e.r && y <= vh + e.r) out.push({ ref: e.ref, x: x, y: y, r: e.r, rgb: e.rgb, look: e.look, dash: e.dash, diff: e.diff, faint: !!e.faint, fdash: e.fdash === true });
      }
      this._ovLast = out;
   }
   return c.n;
};
