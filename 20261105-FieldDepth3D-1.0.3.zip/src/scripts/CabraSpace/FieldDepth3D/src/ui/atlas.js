// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/atlas.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/atlas.js — LA tabla de tokens de la estética «Atlas» (3-oct-2026)
// ----------------------------------------------------------------------------
// «Atlas estelar del siglo XIX, limpio y nórdico»: carbón cálido de fondo, oro
// de acento, ornamento mínimo (filete, doble filete, filete interior). Es el
// estilo común de CabraSpace; su fuente es `CabraBase/estilo/tokens.json`, y
// AQUÍ vive la única copia que usa CabraPilot. Decisiones de Nino (3-oct-2026):
// paleta carbón cálido; Georgia / Segoe UI / Consolas (las instaladas en
// Windows, sin depender de Bodoni / Figtree / Plex); Atlas SUSTITUYE a la regla
// «imitar PI Workflow».
//
// TODO lo demás se DERIVA de esta tabla: `Theme` (CabraPilot_UI.js), `CP_UI` y
// los `CP_INT_*` (ui/theme.js). Antes había dos tablas escritas a mano más un
// puñado de literales, y ya habían divergido (`CP_INT_BORDER` no era el borde
// de `CP_UI`). El nivel 0 vigila dos cosas: que esta tabla siga siendo la de
// `tokens.json` (L0-17) y que nadie vuelva a escribir un color de la paleta
// vieja a mano (L0-18).
//
// LO QUE PJSR/Qt HACEN DE VERDAD, medido en PixInsight 1.9.5 build 1706 con
// `_tests/cp_atlas_probe.js` (el log está al lado; los PNG, en `_tests/atlas/`):
//
//   · `Font.isExactMatch` distingue una familia instalada de una inventada
//     (control en rojo incluido) -> `cpFontFamily`.
//   · `Font.letterSpacing` FUNCIONA, pero va en PÍXELES por letra y vale 0 por
//     defecto. La documentación instalada dice «porcentaje, 100 = normal» y se
//     equivoca: 126 separó las letras 126 px.
//   · `Graphics.drawRoundedRect` y compañía funcionan; `rx`/`ry` son PORCENTAJES
//     de medio lado, no píxeles -> `cpRoundRect` hace la cuenta.
//   · `LinearGradientBrush` funciona (no se usa: Atlas es plano).
//   · En una hoja Qt, `letter-spacing` SÍ se aplica (la ficha de CabraBase lo
//     daba por no admitido); `border-radius:999px` NO da píldora: si el radio
//     pasa de media altura, Qt lo IGNORA y pinta la caja cuadrada. El radio de
//     una píldora tiene que caber -> `cpPillRadius`.
//   · `image:url()` en la casilla y en la flecha del desplegable manda sobre el
//     dibujo nativo, PERO `scaledStyleSheet` reescribe la ruta (le mete un
//     directorio «1.5/»): esas reglas se añaden SIN escalar -> `cpAtlasRawCss`.
//   · Todo lo pintado a mano va en píxeles FÍSICOS: a 150 % una fuente de
//     `pixelSize 12` mide 8 px lógicos. Lo pintado pasa por `cpPx`.
// ES5 puro.
// ============================================================================

var CP_ATLAS = CSH_ATLAS;           // (los tokens, comunes: ../CabraShared/csh_atlas.js)

// ---------------------------------------------------------------------------
// Color: de "#RRGGBB" a lo que pide cada sitio
// ---------------------------------------------------------------------------


// Mezcla de dos tokens: t = 0 da `a`, t = 1 da `b`. Los tonos intermedios se
// DERIVAN (lección de CabraTransit): no se inventa un hex nuevo por cada matiz.

// Para una hoja Qt: "#AARRGGBB" (Qt lee el alfa PRIMERO).

// Para pintar con Graphics: entero 0xAARRGGBB.

// Tonos derivados que usan la hoja y lo pintado. NINGUNO es un token nuevo.
var CP_ATLAS_INSET       = cpMix(CP_ATLAS.bg, "#000000", 0.35);        // campo hundido
var CP_ATLAS_LINE_STRONG = cpMix(CP_ATLAS.line, CP_ATLAS.text3, 0.35); // filete marcado
var CP_ATLAS_GOLD_RING   = cpMix(CP_ATLAS.surface, CP_ATLAS.gold, 0.45); // oro al 45 % sobre tarjeta
var CP_ATLAS_TEXT_OFF    = cpMix(CP_ATLAS.text3, CP_ATLAS.bg, 0.45);   // deshabilitado
var CP_ATLAS_OK_BG       = cpMix(CP_ATLAS.bg, CP_ATLAS.ok, 0.18);
var CP_ATLAS_ERROR_BG    = cpMix(CP_ATLAS.bg, CP_ATLAS.error, 0.18);
var CP_ATLAS_MARK        = CP_ATLAS.chart[1];                          // marcas de comparación
// La marca «NLIN» de una imagen NO LINEAL en la barra de imágenes (Nino, 11-oct-2026:
// «un LIN más amarillo que GHS y STF»; 12-oct-2026: «marcar las no lineales, NLIN»):
// el oro de Atlas, MACIZO, con la letra en la tinta de «texto sobre oro». Las marcas
// del estirado de pantalla van en `text2` (un gris cálido) sobre fondo oscuro; el oro
// es el mismo matiz (HSV: 0,12 frente a 0,11) con la saturación a 0,73 en vez de 0,21.
// No es un token nuevo.
var CP_ATLAS_NLIN        = CP_ATLAS.gold;
// «Preview», la PUERTA del modo preview (10-oct-2026, a peticion de Nino: «que
// aparezca mas realzado»). EL ORO, SOLO CON EL MODO ENCENDIDO (Nino, 11-oct-2026, tras
// verlo en pantalla: «siempre esta en amarillo. No tiene sentido. Tiene que estar
// amarillo cuando este activado»): encendido, contorno y letra de oro sobre una placa
// teñida de oro (no maciza: el oro macizo es «Apply preview», la salida del modo).
// A LA ESPERA no lleva nada de oro y aun asi se ve mas que sus vecinos, por tres
// cosas que no son color de acento: la placa un paso mas clara (la de «hover y
// seleccionado»), el filete en el gris de los textos apagados (los vecinos, el filete
// oscuro de siempre) y la letra en negrita (la misma en los dos estados: el boton no
// cambia de ancho). Ninguno es un token nuevo.
var CP_ATLAS_DOOR_REST   = CP_ATLAS.surface2;
var CP_ATLAS_DOOR_EDGE   = CP_ATLAS.text3;
var CP_ATLAS_DOOR_LIT    = cpMix(CP_ATLAS.surface, CP_ATLAS.gold, 0.34);

// Los colores PINTADOS del histograma (ui/histogram_panel.js), derivados de
// CP_ATLAS.hist: trazo (alfa alto) y relleno (alfa bajo) de cada canal; la
// luminancia K, más tenue, es el fondo. Monocromo: trazo dorado (el oro de Atlas) y
// el color del reflejo; el degradado del relleno gris se calcula al pintar con
// monoFill, monoFillTop y monoFillBottom.
var CP_HISTCOL_R = cpInt(CP_ATLAS.hist.r, CP_ATLAS.hist.lineAlpha);
var CP_HISTCOL_G  = cpInt(CP_ATLAS.hist.g, CP_ATLAS.hist.lineAlpha);
var CP_HISTCOL_B  = cpInt(CP_ATLAS.hist.b, CP_ATLAS.hist.lineAlpha);
var CP_HISTCOL_K  = cpInt(CP_ATLAS.hist.k, CP_ATLAS.hist.kLineAlpha);
var CP_HISTFILL_R = cpInt(CP_ATLAS.hist.r, CP_ATLAS.hist.fillAlpha);
var CP_HISTFILL_G = cpInt(CP_ATLAS.hist.g, CP_ATLAS.hist.fillAlpha);
var CP_HISTFILL_B = cpInt(CP_ATLAS.hist.b, CP_ATLAS.hist.fillAlpha);
var CP_HISTFILL_K = cpInt(CP_ATLAS.hist.k, CP_ATLAS.hist.kFillAlpha);
var CP_HISTCOL_MONO   = cpInt(CP_ATLAS.gold);
var CP_HISTGLOSS_MONO = cpInt(CP_ATLAS.text, CP_ATLAS.hist.monoGloss);
var CP_HISTCOL_CURVE  = cpInt(CP_ATLAS.text, CP_ATLAS.hist.curveAlpha);     // la curva de transferencia
// El FANTASMA de «Output» (el histograma de salida, detrás del de entrada y más tenue): trazo y relleno de cada canal,
// y los del monocromo (trazo crema, relleno gris).
var CP_HISTGHOST_R = cpInt(CP_ATLAS.hist.r, CP_ATLAS.hist.ghostLineAlpha);
var CP_HISTGHOST_G = cpInt(CP_ATLAS.hist.g, CP_ATLAS.hist.ghostLineAlpha);
var CP_HISTGHOST_B = cpInt(CP_ATLAS.hist.b, CP_ATLAS.hist.ghostLineAlpha);
var CP_HISTGHOST_K = cpInt(CP_ATLAS.hist.k, CP_ATLAS.hist.kLineAlpha);
var CP_HISTGHOSTFILL_R = cpInt(CP_ATLAS.hist.r, CP_ATLAS.hist.ghostFillAlpha);
var CP_HISTGHOSTFILL_G = cpInt(CP_ATLAS.hist.g, CP_ATLAS.hist.ghostFillAlpha);
var CP_HISTGHOSTFILL_B = cpInt(CP_ATLAS.hist.b, CP_ATLAS.hist.ghostFillAlpha);
var CP_HISTGHOSTFILL_K = cpInt(CP_ATLAS.hist.k, CP_ATLAS.hist.kFillAlpha);
var CP_HISTGHOST_MONO     = cpInt(CP_ATLAS.text, CP_ATLAS.hist.ghostLineAlpha);
var CP_HISTGHOSTFILL_MONO = cpInt(CP_ATLAS.hist.monoFill, CP_ATLAS.hist.ghostMonoFillAlpha);
// El EDITOR DE CURVAS (el motor «Curves» de STRETCH): la curva, su halo, la identidad de referencia, la rejilla y la
// silueta del histograma de fondo (sin trazo: 0 = no se pinta).
var CP_HISTEDIT_CURVE    = cpInt(CP_ATLAS.text);
var CP_HISTEDIT_HALO     = cpInt(CP_ATLAS.bg, CP_ATLAS.hist.editCurveHaloAlpha);
var CP_HISTEDIT_IDENTITY = cpInt(CP_ATLAS.text3, CP_ATLAS.hist.editIdentityAlpha);
var CP_HISTEDIT_GRID     = cpInt(CP_ATLAS.line, CP_ATLAS.hist.editGridAlpha);
var CP_HISTEDIT_BACK_MONO = cpInt(CP_ATLAS.hist.monoFill, CP_ATLAS.hist.editBackMonoAlpha);
var CP_HISTEDIT_BACK_R    = cpInt(CP_ATLAS.hist.r, CP_ATLAS.hist.editBackFillAlpha);
var CP_HISTEDIT_BACK_G    = cpInt(CP_ATLAS.hist.g, CP_ATLAS.hist.editBackFillAlpha);
var CP_HISTEDIT_BACK_B    = cpInt(CP_ATLAS.hist.b, CP_ATLAS.hist.editBackFillAlpha);

// ---------------------------------------------------------------------------
// Tipografía
// ---------------------------------------------------------------------------

// La primera familia INSTALADA de la lista del papel («display», «text»,
// «mono»). Si ninguna lo está, la última: Qt pondrá su respaldo.

// La familia, lista para una hoja Qt (con la genérica detrás).

// Fuentes para PINTAR, cacheadas. Antes cada `onPaint` de cada celda hacía
// `new Font(...)`: con el resalte al pasar el ratón eso sería un `new` por
// celda y por movimiento. `px` va en píxeles FÍSICOS (pásalo por `cpPx`);
// `spacing`, en píxeles físicos por letra (ver la nota de `Font.letterSpacing`).

// Separación de las versalitas para un cuerpo dado (px físicos).

// Corta un texto con «…» para que quepa en `maxW` píxeles, MIDIENDO con la
// fuente que lo va a pintar (antes era `ancho / 9`, una constante).

// ---------------------------------------------------------------------------
// LA ESCALA PROPIA DE CABRAPILOT: píxeles lógicos -> físicos (13-oct-2026)
// ----------------------------------------------------------------------------
// CabraPilot está MAQUETADO A 1,5: su letra de 10 px lógicos (15 físicos) y sus
// cajas en píxeles físicos fijos (columnas, lienzo del histograma, mínimos de
// ventana) están pensados para esa escala de interfaz de PixInsight. A una
// escala menor la letra encogía y las cajas no (medido el 13-oct-2026: cuerpo
// de 10 / 12 / 15 px físicos a escala 1 / 1,25 / 1,5, y la misma frase un 25 %
// más estrecha a 1,25). Decisión de Nino: «la interfaz debe valer a las dos
// escalas» (el portátil va a 1,25 con pantalla externa; el sobremesa, a 1,5).
//
// Por eso CabraPilot lleva SU escala: la de PixInsight por un FACTOR.
//   · «Auto» (de fábrica): la escala efectiva no baja de `CP_UI_SCALE_MIN` (1,5).
//     Factor 1,5 a escala 1; 1,2 a 1,25; y 1 de 1,5 en adelante — allí no
//     cambia NADA (con factor 1 todo pasa por las funciones de PixInsight, las
//     de siempre: `scaledStyleSheet`, `sizer.spacing`…).
//   · o la que elija el usuario en ⚙ («Interface size»), recordada entre
//     sesiones. Se aplica al ABRIR CabraPilot: la interfaz se construye una vez.
//
// LO QUE HACE PIXINSIGHT CON SU ESCALA, medido en 1.9.5 build 1706 a 1, 1,25 y
// 1,5 (el pack UISCALE lo vuelve a medir en cada pasada):
//   · `scaledStyleSheet`, `setScaled*`, `logicalPixelsToPhysical` y los huecos
//     de los sizers (`spacing`, `margin`, `addSpacing`) dan TODOS
//     redondeo-al-par de n × escala (3 → 4 y 5 → 8 a 1,5; 10 → 12 a 1,25). No es
//     `Math.round` (que daría 5 para el 3): por eso existe `cpUiPx`.
//   · en una hoja, `Npt` pasa a píxeles con la resolución de fuente de
//     PixInsight (100 ppp de fábrica): N × escala × 100 / 72.
//   · `displayPixelRatio` es de solo lectura, y `spacing` / `margin` de un sizer
//     son propiedades del objeto nativo que no se pueden interceptar: no hay un
//     sitio único donde cambiar la escala. Lo que PixInsight escala por su
//     cuenta se lo tiene que pedir CabraPilot ya en píxeles físicos:
//     `cpApplyStyle` (ui/theme.js) para las hojas, `cpGap` / `cpMargin` /
//     `cpAddGap` para los sizers y `cpUiPx` para lo demás. Lo vigila L0-92.
//
// TRES MEDIDAS, que no son la misma:
//   · `cpPx(n)`   lo PINTADO a mano: n lógicos × escala, con `Math.round` (como
//                 siempre; a escala efectiva 1,5 da lo mismo que daba a 1,5).
//   · `cpUiPx(n)` lo que PixInsight daría para n lógicos (redondeo al par):
//                 huecos de sizer, mínimos de controles, medidas de una hoja.
//   · `cpDp(n)`   una caja escrita en píxeles FÍSICOS de la maqueta (a 1,5):
//                 n × escala / 1,5. A escala efectiva 1,5 es n, tal cual.
// ---------------------------------------------------------------------------
var CP_UI_SCALE_MIN = 1.5;         // «Auto»: la escala efectiva no baja de aquí (la de la maqueta)
var CP_UI_DESIGN_SCALE = 1.5;      // la escala a la que están medidas las cajas en píxeles físicos (cpDp)
// Lo que se puede elegir en ⚙ (0 = «Auto»); el resto son escalas EFECTIVAS, en
// las mismas unidades que la escala de interfaz de PixInsight.
var CP_UI_SIZE_CHOICES = [0, 1, 1.25, 1.5, 1.75, 2];

var CP_UI_SIZE = 0;         // lo elegido para ESTA sesión (0 = «Auto»); se lee de lo recordado al cargar
var CP_UI_SIZE_NEXT = 0;    // lo elegido en ⚙ para la PRÓXIMA (es lo que se guarda)
var CP_UI_NATIVE = 0;       // la escala de PixInsight (0 = aún sin leer)
var CP_UI_SCALE = 0;        // la efectiva (0 = aún sin calcular)

// La escala efectiva para una escala de PixInsight y una elección. PURA.
function cpUiScaleFor(native, choice) {
   var k = (isFinite(native) && native > 0) ? native : 1;
   if (isFinite(choice) && choice > 0)
      return choice;
   return Math.max(k, CP_UI_SCALE_MIN);
}

// La escala de PixInsight. Se lee de un control (o, sin él, de un sizer suelto,
// que la conoce sin tener ventana) y se guarda: PixInsight usa una sola escala
// para toda la aplicación.
function cpUiNativeScale(control) {
   var r = 0;
   if (control) {
      try { r = control.displayPixelRatio; } catch (e) { r = 0; }
   }
   if (!(isFinite(r) && r > 0) && !(CP_UI_NATIVE > 0)) {
      try { r = (new HorizontalSizer).displayPixelRatio; } catch (e2) { r = 0; }
   }
   if (isFinite(r) && r > 0 && r !== CP_UI_NATIVE) {
      CP_UI_NATIVE = r;
      CP_UI_SCALE = 0;
   }
   return (CP_UI_NATIVE > 0) ? CP_UI_NATIVE : 1;
}

// LA ESCALA DE CABRAPILOT (la efectiva). De aquí cuelga todo lo pintado a mano
// (`cpPx`, las fuentes de `cpFont`, los glifos) y, por `cpUiPx` y
// `cpApplyStyle`, todo lo demás.
function cpUiScale(control) {
   var k = cpUiNativeScale(control);
   if (!(CP_UI_SCALE > 0))
      CP_UI_SCALE = cpUiScaleFor(k, CP_UI_SIZE);
   return CP_UI_SCALE;
}

// El factor sobre la escala de PixInsight. 1 = CabraPilot va a la escala de
// PixInsight, y entonces TODO pasa por las funciones nativas de siempre.
function cpUiFactor(control) {
   var e = cpUiScale(control), k = cpUiNativeScale();
   return (Math.abs(e - k) < 1e-9) ? 1 : e / k;
}

// Elegir la escala de ESTA sesión (0 = «Auto»). Solo la usan el arranque (con lo
// recordado) y los tests: lo ya construido no se rehace, y las cajas que se
// calculan al cargar (`cpDp` en una constante) se quedan como estaban.
function cpUiSetSize(choice) {
   var c = 0;
   for (var i = 0; i < CP_UI_SIZE_CHOICES.length; ++i)
      if (CP_UI_SIZE_CHOICES[i] === choice) c = choice;
   CP_UI_SIZE = c;
   CP_UI_SCALE = 0;
   return c;
}

// Lo recordado (engine/prefs.js: `ui.size` del JSON de ajustes). Cualquier cosa
// que no sea exactamente una de las opciones vale por «Auto». Incluido como
// librería (los tests) las prefs están apagadas: «Auto».
function cpUiSizeSaved() {
   try {
      if (typeof cpPrefsLoad !== "function")
         return 0;
      var ui = cpPrefsObject(cpPrefsLoad().ui);
      return cpPrefsChoice(ui.size, CP_UI_SIZE_CHOICES, 0);
   } catch (e) {}
   return 0;
}

// El redondeo de PixInsight: al entero más próximo y, en el empate, al PAR.
function cpRoundEven(x) {
   var f = Math.floor(x), d = x - f;
   if (Math.abs(d - 0.5) < 1e-9)
      return (f % 2 === 0) ? f : f + 1;
   return Math.round(x);
}

// Lo pintado a mano.
function cpPx(n, control) {
   return Math.round(n * cpUiScale(control));
}

// Lo que PixInsight daría para `n` píxeles lógicos, a la escala de CabraPilot.
function cpUiPx(n, control) {
   return cpRoundEven(n * cpUiScale(control));
}

// Una caja escrita en píxeles físicos de la maqueta (a 1,5), a la escala de
// CabraPilot. A 1,5 devuelve `n` sin tocarlo.
function cpDp(n, control) {
   var e = cpUiScale(control);
   if (Math.abs(e - CP_UI_DESIGN_SCALE) < 1e-9)
      return n;
   return Math.round(n * e / CP_UI_DESIGN_SCALE);
}

// Y al revés: de píxeles físicos de ESTA escala a los de la maqueta (para
// guardar un ancho que el usuario ha movido sin atarlo a la escala del día).
function cpDpInv(n, control) {
   var e = cpUiScale(control);
   if (Math.abs(e - CP_UI_DESIGN_SCALE) < 1e-9)
      return n;
   return Math.round(n * CP_UI_DESIGN_SCALE / e);
}

// ---------------------------------------------------------------------------
// Los HUECOS de un sizer, a la escala de CabraPilot
// ----------------------------------------------------------------------------
// `sizer.spacing = 4` lo escala PixInsight con SU escala. Con factor 1 se deja
// así (es lo de siempre); con otro, se le da el hueco ya en píxeles físicos.
function cpGap(sizer, n) {
   if (cpUiFactor() === 1) sizer.spacing = n;
   else sizer.unscaledSpacing = cpUiPx(n);
   return sizer;
}

function cpMargin(sizer, n) {
   if (cpUiFactor() === 1) sizer.margin = n;
   else sizer.unscaledMargin = cpUiPx(n);
   return sizer;
}

function cpAddGap(sizer, n) {
   if (cpUiFactor() === 1) sizer.addSpacing(n);
   else sizer.addUnscaledSpacing(cpUiPx(n));
   return sizer;
}

// LEER el hueco o el margen de un sizer, en píxeles LÓGICOS (el número que se le
// puso). Con factor 1 es `sizer.spacing`; con otro, `spacing` devolvería los
// píxeles físicos divididos por la escala de PixInsight, que no es el número
// que se puso: se deshace con la de CabraPilot.
function cpGapOf(sizer) {
   if (cpUiFactor() === 1) return sizer.spacing;
   return cpRoundEven(sizer.unscaledSpacing / cpUiScale());
}

function cpMarginOf(sizer) {
   if (cpUiFactor() === 1) return sizer.margin;
   return cpRoundEven(sizer.unscaledMargin / cpUiScale());
}

// ---------------------------------------------------------------------------
// Una hoja Qt, a la escala de CabraPilot
// ----------------------------------------------------------------------------
// Lo mismo que `Control.scaledStyleSheet` (cada `Npx` pasa a redondeo-al-par de
// N × escala; cada `Npt`, a píxeles con la resolución de fuente de PixInsight),
// pero con NUESTRA escala. Con factor 1 no se usa: va la nativa.
var CP_UI_PT_TO_PX = 0;     // píxeles lógicos por punto (0 = aún sin medir)

function cpUiPtToPx(control) {
   if (!(CP_UI_PT_TO_PX > 0)) {
      var v = 0;
      try {
         // Se le pregunta a PixInsight: 7200 pt a SU escala son 7200 × k × (ppp / 72) px.
         var m = /(\d+)px/.exec(String(control.scaledStyleSheet("a:7200pt;")));
         if (m) v = parseInt(m[1], 10) / 7200 / cpUiNativeScale(control);
      } catch (e) { v = 0; }
      CP_UI_PT_TO_PX = (isFinite(v) && v > 0.5 && v < 4) ? v : 100 / 72;
   }
   return CP_UI_PT_TO_PX;
}

function cpScaleCssAt(css, scale, ptToPx) {
   return String(css).replace(/(\d+(?:\.\d+)?)(px|pt)/g, function(all, num, unit) {
      var n = parseFloat(num);
      if (!isFinite(n)) return all;
      return String(cpRoundEven(n * scale * (unit === "pt" ? ptToPx : 1))) + "px";
   });
}

function cpScaleCss(css, control) {
   if (cpUiFactor(control) === 1 && control && typeof control.scaledStyleSheet === "function")
      return control.scaledStyleSheet(css);
   return cpScaleCssAt(css, cpUiScale(control), control ? cpUiPtToPx(control) : 100 / 72);
}

// La escala de esta sesión: la recordada (o «Auto»). Se fija AL CARGAR, antes de
// que ninguna constante de los paneles pida una medida.
CP_UI_SIZE_NEXT = cpUiSetSize(cpUiSizeSaved());

// ---------------------------------------------------------------------------
// Píldoras en una hoja Qt
// ----------------------------------------------------------------------------
// MEDIDO (`cp_atlas_probe.log`, bloque Q2): un botón con letra de 10 px mide de
// alto 22 px físicos más el relleno vertical escalado (a 150 %: 26 con 1 px, 28
// con 2, 30 con 3, 34 con 4), y el radio máximo que Qt respeta es media altura:
// con `padding` de 3 px vale 10 y con 11 la caja sale CUADRADA. Se deja un
// píxel de margen para el redondeo de otras escalas de pantalla.
function cpPillRadius(padY) {
   return 6 + Math.max(0, Math.round(padY));
}

// ---------------------------------------------------------------------------
// Rectángulo redondeado con el radio en PÍXELES
// ----------------------------------------------------------------------------
// `drawRoundedRect(x0, y0, x1, y1, rx, ry)` toma `rx`/`ry` como PORCENTAJE de
// medio lado. Usa la pluma y la brocha que lleve `g`.
function cpRoundRect(g, x0, y0, x1, y1, r) {
   var w = Math.max(1, x1 - x0), h = Math.max(1, y1 - y0);
   var rx = Math.max(0, Math.min(100, 200 * r / w));
   var ry = Math.max(0, Math.min(100, 200 * r / h));
   g.drawRoundedRect(x0, y0, x1, y1, rx, ry);
}

// ---------------------------------------------------------------------------
// Esquinas redondeadas SOBRE un bitmap ya pintado
// ----------------------------------------------------------------------------
// `Graphics` solo recorta por rectángulo, así que una miniatura no se puede
// pintar con las esquinas redondeadas. Se pinta recta y se le tapan las cuatro
// esquinas con el color del fondo: cuatro bitmaps de r×r, opacos por fuera del
// arco y transparentes por dentro, con el borde suavizado. Se generan una vez
// por (radio, color) y se guardan.
var CP_CORNER_CACHE = {};
function cpCornerMasks(r, colorInt) {
   var key = r + "|" + colorInt;
   if (Object.prototype.hasOwnProperty.call(CP_CORNER_CACHE, key))
      return CP_CORNER_CACHE[key];
   var rgb = colorInt & 0x00ffffff;
   var out = [];
   // 0 = arriba-izq, 1 = arriba-der, 2 = abajo-izq, 3 = abajo-der
   for (var k = 0; k < 4; ++k) {
      var b = new Bitmap(r, r);
      for (var y = 0; y < r; ++y)
         for (var x = 0; x < r; ++x) {
            // Centro del arco en la esquina INTERIOR del cuadrado.
            var cx = (k === 0 || k === 2) ? r : 0;
            var cy = (k === 0 || k === 1) ? r : 0;
            var dx = (x + 0.5) - cx, dy = (y + 0.5) - cy;
            var d = Math.sqrt(dx * dx + dy * dy);
            var a = Math.max(0, Math.min(1, d - r + 0.5));     // 0 dentro, 1 fuera
            b.setPixel(x, y, (((Math.round(a * 255) & 0xff) << 24) | rgb) >>> 0);
         }
      out.push(b);
   }
   CP_CORNER_CACHE[key] = out;
   return out;
}

function cpPaintCornerMasks(g, x0, y0, x1, y1, r, colorInt) {
   if (r < 2)
      return;
   var m = cpCornerMasks(r, colorInt);
   g.drawBitmap(x0, y0, m[0]);
   g.drawBitmap(x1 - r, y0, m[1]);
   g.drawBitmap(x0, y1 - r, m[2]);
   g.drawBitmap(x1 - r, y1 - r, m[3]);
}

// ---------------------------------------------------------------------------
// LA CASILLA Y LA FLECHA DEL DESPLEGABLE
// ----------------------------------------------------------------------------
// Con la hoja de antes la casilla salía con el dibujo NATIVO (una caja blanca)
// aunque llevara `QCheckBox::indicator{background…}`, y la flecha del
// desplegable era la nativa, oscura: sobre carbón no se ve. Una `image:url()`
// nuestra sí manda. Los PNG se pintan aquí, al tamaño de la pantalla, y se
// dejan en el directorio temporal; si no se pudiera escribir, se devuelve una
// hoja vacía y casilla y flecha se quedan como las pinta PixInsight.
//
// Estas reglas NO pueden pasar por `scaledStyleSheet`: reescribe la ruta de la
// `url()` metiéndole el directorio de la escala. Por eso van aparte, con los
// píxeles ya físicos, y `cpApplyStyle` las pega detrás.
var CP_ATLAS_RAW_CACHE = {};

// Lado de la casilla, en píxeles LÓGICOS: el de la hoja y el de las casillas
// PINTADAS a mano (la matriz de capas de MULTISCALE, ui/layer_matrix.js).
var CP_ATLAS_CHECK_BOX = CP_ATLAS.space[2];

// EL DIBUJO DE LA CASILLA, uno solo: lo usan las imágenes de la hoja
// (`cpAtlasRawCss`) y las casillas pintadas a mano (`cpAtlasCheckBitmap`).
// Devuelve la función que la pinta en un lienzo de `s` × `s` píxeles físicos.
// `tick` = 0 es «sin marca».
function cpAtlasCheckPainter(scale, boxFill, boxLine, tick) {
   var pen = Math.max(1, Math.round(scale));
   return function(g, s) {
      g.pen = new Pen(boxLine, pen);
      g.brush = new Brush(boxFill);
      g.drawRoundedRect(pen / 2, pen / 2, s - pen / 2, s - pen / 2, 45, 45);
      if (tick !== 0) {
         g.pen = new Pen(tick, Math.max(1.5, 1.4 * scale));
         g.drawLine(s * 0.24, s * 0.52, s * 0.43, s * 0.72);
         g.drawLine(s * 0.43, s * 0.72, s * 0.78, s * 0.28);
      }
   };
}

// La casilla como BITMAP, para pintarla con `Graphics.drawBitmap` dentro de un
// control dibujado a mano. Los MISMOS colores que la de la hoja, estado a
// estado: `on` (marcada), `hover` (el ratón encima) y `dim` (apagada: la fila
// no cuenta). Se generan una vez por escala y estado, FUERA de `onPaint`
// (quien pinta llama aquí antes de abrir su `Graphics`).
var CP_ATLAS_CHECK_CACHE = {};
function cpAtlasCheckBitmap(control, on, hover, dim) {
   var scale = cpUiScale(control);
   var key = Math.round(scale * 100) + "|" + (on ? 1 : 0) + (hover ? 1 : 0) + (dim ? 1 : 0);
   if (Object.prototype.hasOwnProperty.call(CP_ATLAS_CHECK_CACHE, key))
      return CP_ATLAS_CHECK_CACHE[key];
   var fill, line, tick;
   if (dim) {
      fill = on ? cpInt(CP_ATLAS.line) : cpInt(CP_ATLAS.bg);
      line = cpInt(CP_ATLAS.line);
      tick = on ? cpInt(CP_ATLAS_TEXT_OFF) : 0;
   } else if (on) {
      fill = line = cpInt(hover ? CP_ATLAS.goldLight : CP_ATLAS.gold);
      tick = cpInt(CP_ATLAS.ink);
   } else {
      fill = cpInt(CP_ATLAS_INSET);
      line = cpInt(hover ? CP_ATLAS.gold : CP_ATLAS_LINE_STRONG);
      tick = 0;
   }
   var side = Math.round(CP_ATLAS_CHECK_BOX * scale);
   var b = new Bitmap(side, side);
   b.fill(0x00000000);
   var g = new Graphics(b);
   try {
      g.antialiasing = true;
      cpAtlasCheckPainter(scale, fill, line, tick)(g, side);
   } finally {
      g.end();
   }
   CP_ATLAS_CHECK_CACHE[key] = b;
   return b;
}

function cpAtlasGlyph(dir, name, size, paint) {
   var b = new Bitmap(size, size);
   b.fill(0x00000000);
   var g = new Graphics(b);
   try {
      g.antialiasing = true;
      paint(g, size);
   } finally {
      g.end();
   }
   var path = dir + "/" + name + ".png";
   b.save(path);
   try { b.clear(); } catch (e) {}
   return path;
}

function cpAtlasRawCss(control) {
   var scale = cpUiScale(control);
   var tag = String(Math.round(scale * 100));
   if (Object.prototype.hasOwnProperty.call(CP_ATLAS_RAW_CACHE, tag))
      return CP_ATLAS_RAW_CACHE[tag];
   var css = "";
   try {
      var dir = File.systemTempDirectory.replace(/\\/g, "/") + "/CabraPilotAtlas";
      if (!File.directoryExists(dir))
         File.createDirectory(dir, true);
      var box = Math.round(CP_ATLAS_CHECK_BOX * scale), arr = Math.round(9 * scale);
      var check = function(boxFill, boxLine, tick) { return cpAtlasCheckPainter(scale, boxFill, boxLine, tick); };
      var arrow = function(col) {
         return function(g, s) {
            g.pen = new Pen(col, Math.max(1.5, 1.2 * scale));
            g.drawLine(s * 0.12, s * 0.32, s * 0.5, s * 0.72);
            g.drawLine(s * 0.5, s * 0.72, s * 0.88, s * 0.32);
         };
      };
      var n = "s" + tag + "_";
      var off    = cpAtlasGlyph(dir, n + "check_off", box, check(cpInt(CP_ATLAS_INSET), cpInt(CP_ATLAS_LINE_STRONG), 0));
      var offH   = cpAtlasGlyph(dir, n + "check_off_hover", box, check(cpInt(CP_ATLAS_INSET), cpInt(CP_ATLAS.gold), 0));
      var on     = cpAtlasGlyph(dir, n + "check_on", box, check(cpInt(CP_ATLAS.gold), cpInt(CP_ATLAS.gold), cpInt(CP_ATLAS.ink)));
      var onH    = cpAtlasGlyph(dir, n + "check_on_hover", box, check(cpInt(CP_ATLAS.goldLight), cpInt(CP_ATLAS.goldLight), cpInt(CP_ATLAS.ink)));
      var offD   = cpAtlasGlyph(dir, n + "check_off_disabled", box, check(cpInt(CP_ATLAS.bg), cpInt(CP_ATLAS.line), 0));
      var onD    = cpAtlasGlyph(dir, n + "check_on_disabled", box, check(cpInt(CP_ATLAS.line), cpInt(CP_ATLAS.line), cpInt(CP_ATLAS_TEXT_OFF)));
      var arrowN = cpAtlasGlyph(dir, n + "arrow", arr, arrow(cpInt(CP_ATLAS.gold)));
      var arrowD = cpAtlasGlyph(dir, n + "arrow_disabled", arr, arrow(cpInt(CP_ATLAS_TEXT_OFF)));
      var u = function(p) { return "image:url(\"" + p + "\");"; };
      css =
         "QCheckBox::indicator { width:" + box + "px; height:" + box + "px; border:none; background:transparent; " + u(off) + " }" +
         "QCheckBox::indicator:hover { " + u(offH) + " }" +
         "QCheckBox::indicator:checked { " + u(on) + " }" +
         "QCheckBox::indicator:checked:hover { " + u(onH) + " }" +
         "QCheckBox::indicator:disabled { " + u(offD) + " }" +
         "QCheckBox::indicator:checked:disabled { " + u(onD) + " }" +
         "QComboBox::down-arrow { width:" + arr + "px; height:" + arr + "px; " + u(arrowN) + " }" +
         "QComboBox::down-arrow:disabled { " + u(arrowD) + " }";
   } catch (e) {
      css = "";
   }
   CP_ATLAS_RAW_CACHE[tag] = css;
   return css;
}
