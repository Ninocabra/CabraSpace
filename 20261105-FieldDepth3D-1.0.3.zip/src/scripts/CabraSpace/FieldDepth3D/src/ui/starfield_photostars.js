// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_photostars.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_photostars.js — LAS ESTRELLAS DE LA FOTO en «Distances» (14-oct-2026)
// ----------------------------------------------------------------------------
// Peticion de Nino: «¿podrias mapear las estrellas reales tal y como estan en la imagen?». Estudio, medidas y
// decisiones en `propuestas/hr_3d/estrellas_reales/ESTUDIO.md` (R1-R7). Un desplegable «Stars» en la fila de
// «Distances» (la del vuelo, junto a «Nebula…») con cuatro formas de pintar las estrellas del 3D:
//   Gaia          el punto de siempre (color BP-RP, tamaño por G). DE FABRICA.
//   Photo colour  el mismo punto con el COLOR que la estrella tiene en la foto (las limpias; las demas, Gaia).
//   Photo         su RECORTE de la foto (fondo restado, borde suave), a su distancia y con la perspectiva; con tope
//                 de tamaño; en un vuelo gana brillo al acercarse (1/d², R3).
//   Photo size    el recorte con el tamaño que tiene EN la foto (no mengua con la profundidad).
// Solo llevan recorte las LIMPIAS y las SATURADAS (las que la foto separa bien). Los miembros de un cumulo van siempre
// con su punto; las que tienen una vecina dentro del recorte, con lo que diga CP_SFUI_PS_R5 (R5); las demas sin recorte
// limpio (debiles, del borde, sobre un objeto extenso), con lo que diga CP_SFUI_PS_R4 (R4). Lo puro (la clase, lo que se
// pinta, la escala, el brillo) esta en ui/starfield_view.js; aqui se lee la imagen (UNA vez, al elegir el modo o al
// abrir con él puesto: nunca al pintar) y se hacen los bitmaps.
// Metodos de CPStarfieldDock (como ui/starfield_flight_ui.js). ES5.
// ============================================================================

// R4 (sin decidir por Nino): lo que llevan las estrellas SIN recorte limpio en «Photo» y «Photo size».
//   "a" su punto de Gaia (lo de hoy) · "b" recorte sintetico (la PSF media de la foto) con el color de la foto ·
//   "c" recorte sintetico con el color de Gaia · "d" punto con el color de la foto
var CP_SFUI_PS_R4 = "a";
// R5b (sin decidir por Nino): las que tienen una vecina dentro del recorte. "gaia" su punto de Gaia · "r4" como R4.
var CP_SFUI_PS_R5 = "gaia";
// La costura de las pruebas: apagado, el panel no mira el desplegable (el dibujo de siempre, para compararlo con «Gaia»).
var CP_SFUI_PHOTO_STARS = true;
var CP_SFUI_PS_WIN = 36;               // la ventana de medida, en pixeles de imagen a cada lado (con FWHM grandes, mas)
var CP_SFUI_PS_SAT = 0.9;              // saturada: un pixel del nucleo pasa de esta fraccion del maximo de su canal (la regla de la fotometria)
var CP_SFUI_PS_PSF_SNR = 20;           // la PSF media sale de las limpias con al menos esta señal / ruido
var CP_SFUI_PS_PSF_BINS = 24;

CPStarfieldDock.prototype._starsBuild = function() {
   var self = this;
   var m = "gaia";
   if (!CP_NO_MAIN || (typeof C3_STARS_PREF_TEST !== "undefined" && C3_STARS_PREF_TEST === true)) try { var v = Settings.read(CP_SETTINGS_PREFIX + "/Starfield/stars", DataType_String); if (v !== null && v !== undefined && Settings.lastReadOK !== false) m = String(v); } catch (eR) {}
   this.starsMode = (CP_SV.STARS_MODES.indexOf(m) >= 0) ? m : "gaia";
   this._starsBuilding = true;
   this.starsLabel = new Label(this.rowsBox);
   this.starsLabel.text = optT("Stars");
   this.starsLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.starsLabel.toolTip = cpTooltip("sf.stars");
   cpStyleHint(this.starsLabel);
   this.starsCombo = new ComboBox(this.rowsBox);
   cpSfFlField(this.starsCombo);
   this.starsCombo.toolTip = cpTooltip("sf.stars");
   this._starsItems();
   this.starsCombo.onItemSelected = function(index) { if (!self._starsBuilding) self.setStarsMode(CP_SV.STARS_MODES[index]); };
   this._starsBuilding = false;
};
CPStarfieldDock.prototype._starsItems = function() {
   var was = this._starsBuilding, names = [optT("Gaia"), optT("Photo colour"), optT("Photo"), optT("Photo size")];
   this._starsBuilding = true;
   try {
      this.starsCombo.clear();
      for (var i = 0; i < names.length; ++i) this.starsCombo.addItem(names[i]);
      this.starsCombo.currentItem = Math.max(0, CP_SV.STARS_MODES.indexOf(this.starsMode));
   } finally { this._starsBuilding = was; }
};
CPStarfieldDock.prototype._starsSync = function() {
   if (!this.starsCombo) return;
   var on = (this.mode === "dist" && this.state !== null && !this._closed);
   cpSetControlVisible(this.starsLabel, on); cpSetControlVisible(this.starsCombo, on);
   this._starsBuilding = true;
   try { this.starsCombo.currentItem = Math.max(0, CP_SV.STARS_MODES.indexOf(this.starsMode)); } finally { this._starsBuilding = false; }
   try { this.starsCombo.enabled = !(this.flightBusy && this.flightBusy()); } catch (e) {}
};
// ELEGIR. Lo que hay que leer de la imagen se lee AQUI (una vez por imagen), no al pintar.
CPStarfieldDock.prototype.setStarsMode = function(mode) {
   if (CP_SV.STARS_MODES.indexOf(mode) < 0 || mode === this.starsMode) return false;
   if (this.flightBusy && this.flightBusy()) { this._starsSync(); return false; }
   this.starsMode = mode;
   if (!CP_NO_MAIN || (typeof C3_STARS_PREF_TEST !== "undefined" && C3_STARS_PREF_TEST === true)) { try { Settings.write(CP_SETTINGS_PREFIX + "/Starfield/stars", DataType_String, mode); } catch (eW) {} }      // (las pruebas no tocan lo recordado de verdad)
   if (mode !== "gaia" && this.state !== null && this.mode === "dist") this._psPrepare(this.state);
   this._syncButtons();
   if (this.mode === "dist") { this._render(); this._sayState(); }
   return true;
};

// ---------------------------------------------------------------------------
// MEDIR: cada estrella del 3D en la imagen (lineal o no): señal / ruido de pico, saturada, hasta donde llega su
// recorte, sus vecinas de Gaia y si cae sobre un objeto extenso. Queda en `st.ps.meas[ref]` = { cat, snr, r }.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._psPrepare = function(st) {
   if (!st || !CP_SFUI_PHOTO_STARS) return null;
   if (!st.ps) st.ps = { meas: null, fwhm: 0, from: null, spr: {}, rgb: {}, synth: {}, psf: null, ms: 0, bytes: 0 };
   var ps = st.ps, busy = false;
   try {
      if (ps.meas === null) {
         var rec = this.dialog.findRecById(st.viewId);
         if (rec && optSafeView(rec.view)) {
            this.dialog.preview.setBusy(true, optT("Measuring the stars of the photo…"), false); busy = true;
            var t0 = Date.now();
            ps.meas = this._psMeasure(rec.view, st, (this.state === st) ? this._distModel() : cpSvDistModel(st.result, {}));
            ps.from = null;                                  // (los recortes salen de la medida: se rehacen)
            ps.ms = Date.now() - t0;
         } else ps.meas = {};
      }
      if (ps.from !== st.photoFull && st.photoFull) {
         if (!busy) { this.dialog.preview.setBusy(true, optT("Measuring the stars of the photo…"), false); busy = true; }
         this._psSprites(st);
      }
   } catch (e) {
      ps.meas = ps.meas || {};
   } finally {
      if (busy) this.dialog.preview.setBusy(false);
   }
   return ps;
};
// La FWHM: la de la fotometria del motor si la hay; si no (una imagen no lineal), medida aqui en las brillantes.
function cpSfUiPsFwhm(img, res) {
   var ph = res.photometry || {};
   if (ph.method && ph.method.fwhmPx > 0) return ph.method.fwhmPx;
   var vals = [], stars = res.stars, order = [], i, R = 10, side = 2 * R + 1, buf = new Float32Array(side * side), W = img.width, H = img.height;
   for (i = 0; i < stars.length; ++i) if (stars[i].inFrame && stars[i].g !== null && typeof stars[i].x === "number") order.push(i);
   order.sort(function(p, q) { return stars[p].g - stars[q].g; });
   for (var q = 0; q < order.length && vals.length < 60; ++q) {
      var s = stars[order[q]], x0 = Math.round(s.x - 0.5), y0 = Math.round(s.y - 0.5);
      if (x0 < R || y0 < R || x0 >= W - R || y0 >= H - R) continue;
      img.getSamples(buf, new Rect(x0 - R, y0 - R, x0 + R + 1, y0 + R + 1), Math.min(1, img.numberOfChannels - 1));
      var mn = Infinity, mx = -Infinity;
      for (i = 0; i < buf.length; ++i) { if (buf[i] < mn) mn = buf[i]; if (buf[i] > mx) mx = buf[i]; }
      if (mx >= 0.95) continue;
      // (solo estrellas que se ven: el pico pasa de 20 ruidos del cuadro; en el ruido puro la «mitad del pico» da manchas al azar)
      var md = cpSfUiMedian(buf, buf.length), dev = new Float32Array(buf.length);
      for (i = 0; i < buf.length; ++i) dev[i] = Math.abs(buf[i] - md);
      if (!(mx - md > 20 * 1.4826 * cpSfUiMedian(dev, dev.length))) continue;
      mn = md;
      var half = mn + (mx - mn) / 2, area = 0;
      for (i = 0; i < buf.length; ++i) if (buf[i] > half) ++area;
      if (area >= 3 && area < 200) vals.push(2 * Math.sqrt(area / Math.PI));
   }
   if (vals.length < 5) return 3;
   vals.sort(function(a, b) { return a - b; });
   return vals[vals.length >> 1];
}
function cpSfUiMedian(a, n) {
   var s = Array.prototype.slice.call(a, 0, n).sort(function(p, q) { return p - q; });
   return s.length ? s[s.length >> 1] : 0;
}
CPStarfieldDock.prototype._psMeasure = function(view, st, model) {
   var img = view.image, res = st.result, nc = Math.min(3, img.numberOfChannels), W = img.width, H = img.height, big = Math.max(W, H), c, i, k;
   var fwhm = cpSfUiPsFwhm(img, res), chMax = [];
   st.ps.fwhm = fwhm;
   for (c = 0; c < nc; ++c) { img.selectedChannel = c; chMax[c] = img.maximum(); }
   img.resetSelections();
   var RW = Math.max(16, Math.min(CP_SFUI_PS_WIN, Math.round(6 * fwhm) + 8)), side = 2 * RW + 1, lum = new Float32Array(side * side), ch = new Float32Array(side * side);
   var rIn = RW - 6, ring = new Float32Array(side * side), nR = rIn, sum = new Float64Array(nR), cnt = new Float64Array(nR);
   // las del cono, en una rejilla (las vecinas)
   var cell = 32, grid = {}, stars = res.stars;
   for (i = 0; i < stars.length; ++i) { var s0 = stars[i]; if (!s0.inFrame || s0.g === null || typeof s0.x !== "number") continue; var key0 = Math.floor(s0.x / cell) + "," + Math.floor(s0.y / cell); (grid[key0] || (grid[key0] = [])).push(i); }
   // los objetos extensos (galaxias, planetarias, grupos) con su tamaño: una estrella encima a OTRA distancia arrastraria su luz
   var ext = [];
   for (i = 0; i < model.objects.length; ++i) { var o = model.objects[i]; if ((o.kind === "galaxy" || o.kind === "other" || o.kind === "group") && o.ext > 0) ext.push({ x: o.u * big + W / 2, y: o.v * big + H / 2, r: o.ext * big, pc: o.pc }); }
   var out = {}, rSat = Math.max(2, fwhm), rPk = Math.max(2, fwhm / 2 + 1), rMin = Math.max(2, Math.ceil(1.5 * fwhm));
   for (var oi = 0; oi < model.objects.length; ++oi) {
      var ob = model.objects[oi];
      if (ob.kind !== "star" && ob.kind !== "member") continue;
      var st0 = stars[ob.ref], x0 = Math.round(st0.x - 0.5), y0 = Math.round(st0.y - 0.5);
      if (ob.kind === "member") { out[ob.ref] = { cat: "member", snr: 0, r: 0 }; continue; }        // (siempre su punto: no se mide)
      if (ob.suspect === true) { out[ob.ref] = { cat: "doubtful", snr: 0, r: 0 }; continue; }          // Cabra3D (22-oct): distancia dudosa: siempre su punto (hueco)
      if (x0 - RW < 0 || y0 - RW < 0 || x0 + RW >= W || y0 + RW >= H) { out[ob.ref] = { cat: "edge", snr: 0, r: 0 }; continue; }
      var rect = new Rect(x0 - RW, y0 - RW, x0 + RW + 1, y0 + RW + 1), sat = false, dx, dy;
      for (i = 0; i < side * side; ++i) lum[i] = 0;
      for (c = 0; c < nc; ++c) {
         img.getSamples(ch, rect, c);
         for (dy = -RW; dy <= RW; ++dy)
            for (dx = -RW; dx <= RW; ++dx) {
               i = (dy + RW) * side + (dx + RW);
               lum[i] += ch[i] / nc;
               if (!sat && dx * dx + dy * dy <= rSat * rSat && ch[i] >= CP_SFUI_PS_SAT * chMax[c]) sat = true;
            }
      }
      var nRing = 0;
      for (dy = -RW; dy <= RW; ++dy) for (dx = -RW; dx <= RW; ++dx) { var r2 = dx * dx + dy * dy; if (r2 >= rIn * rIn && r2 <= RW * RW) ring[nRing++] = lum[(dy + RW) * side + (dx + RW)]; }
      var bg = cpSfUiMedian(ring, nRing);
      for (i = 0; i < nRing; ++i) ring[i] = Math.abs(ring[i] - bg);
      var sig = 1.4826 * cpSfUiMedian(ring, nRing);
      if (!(sig > 0)) sig = 1e-6;
      for (k = 0; k < nR; ++k) { sum[k] = 0; cnt[k] = 0; }
      var peak = -Infinity, fx = st0.x - 0.5 - x0, fy = st0.y - 0.5 - y0;
      for (dy = -RW; dy <= RW; ++dy)
         for (dx = -RW; dx <= RW; ++dx) {
            var ex = dx - fx, ey = dy - fy, rr = Math.sqrt(ex * ex + ey * ey), v = lum[(dy + RW) * side + (dx + RW)] - bg;
            if (rr <= rPk && v > peak) peak = v;
            k = Math.floor(rr);
            if (k < nR) { sum[k] += v; cnt[k] += 1; }
         }
      var snr = peak / sig, R = cpSvStampRadius(sum, cnt, sig, rMin).r;
      // las vecinas (con al menos PS_NEIGHBOUR de su flujo) a menos de lo que puede alcanzar el recorte
      var nb = [], gx = Math.floor(st0.x / cell), gy = Math.floor(st0.y / cell), reach = Math.ceil((R + 4 * fwhm) / cell);
      for (var ax = -reach; ax <= reach; ++ax)
         for (var ay = -reach; ay <= reach; ++ay) {
            var L = grid[(gx + ax) + "," + (gy + ay)];
            if (!L) continue;
            for (var q = 0; q < L.length; ++q) {
               if (L[q] === ob.ref) continue;
               var s1 = stars[L[q]], dg = s1.g - st0.g;
               if (!cpSvStampNeighbourCounts(dg)) continue;
               var dd = Math.sqrt((s1.x - st0.x) * (s1.x - st0.x) + (s1.y - st0.y) * (s1.y - st0.y));
               if (dd < R + 6 * fwhm) nb.push({ d: dd, dg: dg });
            }
         }
      var onExt = false;
      for (var z = 0; z < ext.length && !onExt; ++z) { var dz = Math.sqrt((ext[z].x - st0.x) * (ext[z].x - st0.x) + (ext[z].y - st0.y) * (ext[z].y - st0.y)); if (dz < ext[z].r && Math.abs(Math.log(ext[z].pc / ob.pc)) > Math.log(1.25)) onExt = true; }
      out[ob.ref] = { cat: cpSvStampClass({ edge: false, snr: snr, saturated: sat, neighbours: nb, r: R, fwhm: fwhm, onExtended: onExt }), snr: snr, r: R };
   }
   return out;
};

// ---------------------------------------------------------------------------
// LOS RECORTES, de la foto grande (la del visor a la resolucion de la imagen, `st.photoFull`): el fondo de un anillo
// justo por fuera restado, borde suave. Solo de las limpias y las saturadas; de las demas medibles, su color (R4 «d»).
// Y la PSF MEDIA (para los sinteticos de R4 «b» y «c»): el perfil radial mediano de las limpias con buena señal y dos
// rectas contra la G de Gaia (su pico y su radio en la foto).
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._psSprites = function(st) {
   var ps = st.ps, P = st.photoFull, res = st.result;
   this._psFreeBitmaps(ps);
   ps.spr = {}; ps.rgb = {}; ps.synth = {}; ps.bytes = 0; ps.from = P;
   if (!P || !ps.meas) return;
   var rec = this.dialog.findRecById(st.viewId), imgW = (rec && optSafeView(rec.view)) ? rec.view.image.width : P.width;
   var f = P.width / Math.max(1, imgW), PW = P.width, PH = P.height, NB = CP_SFUI_PS_PSF_BINS, prof = [], G = [], lnP = [], RR = [];
   for (var ref in ps.meas) {
      if (!ps.meas.hasOwnProperty(ref)) continue;
      var me = ps.meas[ref];
      if (me.cat === "member" || me.cat === "edge" || me.cat === "doubtful") continue;
      var s = res.stars[Number(ref)], cxp = s.x * f, cyp = s.y * f, want = (me.cat === "clean" || me.cat === "saturated");
      var R = Math.max(2, Math.ceil((want ? me.r : Math.max(1, ps.fwhm)) * f)), x0 = Math.floor(cxp) - R, y0 = Math.floor(cyp) - R, side = 2 * R + 1, M = 3, x, y, px, d;
      if (x0 - M < 0 || y0 - M < 0 || x0 + side + M > PW || y0 + side + M > PH) continue;
      var rr = [], gg = [], bb = [];
      for (y = -M; y < side + M; ++y)
         for (x = -M; x < side + M; ++x) {
            d = Math.sqrt((x0 + x + 0.5 - cxp) * (x0 + x + 0.5 - cxp) + (y0 + y + 0.5 - cyp) * (y0 + y + 0.5 - cyp));
            if (d < R + 0.5 || d > R + M) continue;
            px = P.pixel(x0 + x, y0 + y) >>> 0; rr.push((px >>> 16) & 255); gg.push((px >>> 8) & 255); bb.push(px & 255);
         }
      var br = cpSfUiMedian(rr, rr.length), bgc = cpSfUiMedian(gg, gg.length), bbl = cpSfUiMedian(bb, bb.length);
      var core = Math.max(1, ps.fwhm * f), sr = 0, sg = 0, sb = 0, bmp = want ? new Bitmap(side, side) : null, pk = 0, vals = want ? new Float32Array(side * side) : null;
      for (y = 0; y < side; ++y)
         for (x = 0; x < side; ++x) {
            d = Math.sqrt((x0 + x + 0.5 - cxp) * (x0 + x + 0.5 - cxp) + (y0 + y + 0.5 - cyp) * (y0 + y + 0.5 - cyp));
            if (!want && d > core) continue;
            var t = (d - 0.75 * R) / (0.25 * R + 0.5), fe = (d <= 0.75 * R) ? 1 : (d >= R + 0.5) ? 0 : 1 - t * t * (3 - 2 * t);
            px = P.pixel(x0 + x, y0 + y) >>> 0;
            var r = Math.round(Math.max(0, ((px >>> 16) & 255) - br) * fe), gq = Math.round(Math.max(0, ((px >>> 8) & 255) - bgc) * fe), b = Math.round(Math.max(0, (px & 255) - bbl) * fe);
            if (d <= core) { sr += r; sg += gq; sb += b; }
            if (!want) continue;
            bmp.setPixel(x, y, (0xff000000 | (r << 16) | (gq << 8) | b) >>> 0);
            var mxv = Math.max(r, gq, b);
            vals[y * side + x] = mxv;
            if (mxv > pk) pk = mxv;
         }
      var mx = Math.max(sr, sg, sb);
      if (mx > 0) ps.rgb[ref] = (Math.round(255 * sr / mx) << 16) | (Math.round(255 * sg / mx) << 8) | Math.round(255 * sb / mx);
      if (!want) continue;
      ps.spr[ref] = { bmp: bmp, cx: cxp - x0, cy: cyp - y0, R: R, core: Math.max(0.5, ps.fwhm * f / 2), rgb: ps.rgb[ref] };
      ps.bytes += side * side * 4;
      // (para la PSF media: las limpias con buena señal)
      if (me.cat === "clean" && me.snr >= CP_SFUI_PS_PSF_SNR && s.g !== null && pk > 2) {
         var sum = new Float64Array(NB), cnt = new Float64Array(NB);
         for (y = 0; y < side; ++y)
            for (x = 0; x < side; ++x) {
               var rho = Math.sqrt((x + 0.5 - (cxp - x0)) * (x + 0.5 - (cxp - x0)) + (y + 0.5 - (cyp - y0)) * (y + 0.5 - (cyp - y0))) / R;
               if (rho >= 1) continue;
               var bn = Math.floor(rho * NB); sum[bn] += vals[y * side + x] / pk; cnt[bn] += 1;
            }
         var p = [];
         for (var q = 0; q < NB; ++q) p.push(cnt[q] > 0 ? sum[q] / cnt[q] : NaN);
         prof.push(p); G.push(s.g); lnP.push(Math.log(pk)); RR.push(R / f);
      }
   }
   ps.psf = cpSfUiPsModel(prof, G, lnP, RR, NB);
};
function cpSfUiLinFit(xs, ys) {
   var n = xs.length, sx = 0, sy = 0, sxx = 0, sxy = 0, i;
   for (i = 0; i < n; ++i) { sx += xs[i]; sy += ys[i]; sxx += xs[i] * xs[i]; sxy += xs[i] * ys[i]; }
   var den = n * sxx - sx * sx, b = (n >= 2 && Math.abs(den) > 1e-12) ? (n * sxy - sx * sy) / den : 0, a = (n > 0) ? (sy - b * sx) / n : 0;
   return { a: a, b: b, n: n };
}
function cpSfUiPsModel(prof, G, lnP, RR, NB) {
   if (prof.length < 3) return null;
   var T = [], q, s;
   for (q = 0; q < NB; ++q) { var col = []; for (s = 0; s < prof.length; ++s) if (isFinite(prof[s][q])) col.push(prof[s][q]); col.sort(function(a, b) { return a - b; }); T.push(col.length ? col[col.length >> 1] : 0); }
   var t0 = (T[0] > 0) ? T[0] : 1;
   for (q = 0; q < NB; ++q) T[q] = Math.max(0, T[q] / t0);
   T.push(0);
   return { T: T, NB: NB, n: prof.length, peak: cpSfUiLinFit(G, lnP), size: cpSfUiLinFit(G, RR) };
}
// Un recorte SINTETICO (R4 «b» y «c»): la PSF media con el pico y el radio que da su G, del color `rgb` (el canal mayor 255).
CPStarfieldDock.prototype._psSynth = function(st, ref, rgb) {
   var ps = st.ps, M = ps.psf, key = ref + ":" + rgb;
   if (ps.synth[key]) return ps.synth[key];
   var s = st.result.stars[Number(ref)], P = st.photoFull;
   if (!M || !P || s.g === null) return null;
   var rec = this.dialog.findRecById(st.viewId), imgW = (rec && optSafeView(rec.view)) ? rec.view.image.width : P.width, f = P.width / Math.max(1, imgW);
   var R = Math.max(2, Math.min(30, M.size.a + M.size.b * s.g)) * f, A = Math.max(2, Math.min(255, Math.exp(M.peak.a + M.peak.b * s.g)));
   var cxp = s.x * f, cyp = s.y * f, Ri = Math.ceil(R), x0 = Math.floor(cxp) - Ri, y0 = Math.floor(cyp) - Ri, side = 2 * Ri + 1, bmp = new Bitmap(side, side);
   var cr = ((rgb >>> 16) & 255) / 255, cg = ((rgb >>> 8) & 255) / 255, cb = (rgb & 255) / 255;
   for (var y = 0; y < side; ++y)
      for (var x = 0; x < side; ++x) {
         var rho = Math.sqrt((x0 + x + 0.5 - cxp) * (x0 + x + 0.5 - cxp) + (y0 + y + 0.5 - cyp) * (y0 + y + 0.5 - cyp)) / R, t = 0;
         if (rho < 1) { var u = rho * M.NB - 0.5, j = Math.floor(Math.max(0, u)), fr = Math.max(0, u) - j; t = (u <= 0) ? M.T[0] : M.T[j] * (1 - fr) + M.T[Math.min(M.NB, j + 1)] * fr; }
         t *= A;
         bmp.setPixel(x, y, (0xff000000 | (Math.min(255, Math.round(t * cr)) << 16) | (Math.min(255, Math.round(t * cg)) << 8) | Math.min(255, Math.round(t * cb))) >>> 0);
      }
   ps.synth[key] = { bmp: bmp, cx: cxp - x0, cy: cyp - y0, R: R, core: Math.max(0.5, ps.fwhm * f / 2), rgb: rgb };
   ps.bytes += side * side * 4;
   return ps.synth[key];
};
CPStarfieldDock.prototype._psFreeBitmaps = function(ps) {
   if (!ps) return;
   var sets = [ps.spr || {}, ps.synth || {}];
   for (var s = 0; s < sets.length; ++s) for (var k in sets[s]) if (sets[s].hasOwnProperty(k)) cpSfUiFree(sets[s][k].bmp);
   ps.spr = {}; ps.synth = {}; ps.from = null;
};
CPStarfieldDock.prototype._psFree = function(st) {
   if (!st || !st.ps) return;
   this._psFreeBitmaps(st.ps);
   st.ps = null;
};

// ---------------------------------------------------------------------------
// PINTAR una estrella (lo llama `_distBody`, en lugar de su punto de Gaia). Devuelve false si lo que toca es el punto
// de Gaia de siempre (lo pinta el panel). `o` = las opciones de `_distBody` (en un vuelo, `o.video`).
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._photoStarDraw = function(g, fit, proj, scale, i, ob, x, y, r, dim, bg, video, drawn) {
   var st = this.state, ps = st ? st.ps : null;
   if (!CP_SFUI_PHOTO_STARS || !ps || !ps.meas || fit.mode !== "perspective") return false;
   var me = ps.meas[ob.ref], look = cpSvPhotoLook(this.starsMode, ob.kind, me ? me.cat : "", CP_SFUI_PS_R4, CP_SFUI_PS_R5), sp = null, rgb;
   if (drawn) drawn.looks[look] = (drawn.looks[look] || 0) + 1;
   if (this._psLooks) this._psLooks[i] = look;
   if (look === "gaia") return false;
   if (look === "colour") {
      rgb = ps.rgb[ob.ref];
      if (rgb === undefined) return false;
      this._dot(g, x, y, r, this._brush(cpSfUiDim(rgb, dim, bg), 1), video);
      return true;
   }
   if (look === "sprite") sp = ps.spr[ob.ref];
   else if (look === "synth-photo" || look === "synth-gaia") {
      var pr = ps.rgb[ob.ref], gr = cpSvStarRgb(st.result.stars[ob.ref].bpRp), gaia = (gr[0] << 16) | (gr[1] << 8) | gr[2], c = (look === "synth-gaia" || pr === undefined) ? gaia : pr;
      var mx = Math.max((c >>> 16) & 255, (c >>> 8) & 255, c & 255, 1);
      sp = this._psSynth(st, ob.ref, (Math.round(255 * ((c >>> 16) & 255) / mx) << 16) | (Math.round(255 * ((c >>> 8) & 255) / mx) << 8) | Math.round(255 * (c & 255) / mx));
   }
   if (!sp) return false;
   var big = Math.max(st.photoFull ? st.photoFull.width : 1, st.photoFull ? st.photoFull.height : 1);
   var w0 = (this.starsMode === "photo-size") ? fit.px(ob.u, ob.v, 0).w : 1;
   var k = cpSvSpriteScale(this.starsMode, fit.scale, proj.pw[i], w0, big, sp.R, CP_SV.PS_CAP * fit.rect.h);
   if (sp.core * k < CP_SV.PS_MIN_CORE) {
      // (el nucleo no llega a un pixel: un punto, del color del recorte; el de Gaia si no lo tiene)
      if (sp.rgb === undefined) return false;
      this._dot(g, x, y, r, this._brush(cpSfUiDim(sp.rgb, dim, bg), 1), video);
      if (drawn) ++drawn.psDots;
      return true;
   }
   // EN UN VIDEO gana brillo al acercarse (R3): se SUMA su luz las veces que diga el factor
   var gain = 1;
   if (video) {
      var cam = cpSvCamBox(fit), pcCam = (cam.t > 0) ? cpSvDistPcAt(scale, cam.t) : 0, fr = st.result.field, rad = (fr && fr.scaleArcsec > 0) ? Math.max(fr.width, fr.height) * fr.scaleArcsec / 206265 : 0;
      var du = ob.u - cam.u, dv = ob.v - cam.v;
      gain = cpSvFlightGain(ob.pc, pcCam, rad * Math.sqrt(du * du + dv * dv) * ob.pc);
   }
   var op = g.opacity;
   g.compositionOperator = CompositionOp_Add;
   g.smoothInterpolation = true;
   g.resetTransformation(); g.translateTransformation(x, y); g.scaleTransformation(k, k);
   for (var left = gain; left > 0.004; left -= 1) {
      g.opacity = op * Math.min(1, left);
      g.drawBitmap(-sp.cx, -sp.cy, sp.bmp);
   }
   g.resetTransformation();
   g.compositionOperator = CompositionOp_SourceOver;
   g.opacity = op;
   if (drawn) { ++drawn.psSprites; if (gain > drawn.psGain) drawn.psGain = gain; }
   return true;
};

var C3_PS_HINT = true;      // (el rojo del 1-nov, D8: false = sin la frase de «todavia son puntos»)
// LO QUE DICE EL PIE con las estrellas de la foto (R7: en banda estrecha, el color es el de la paleta)
CPStarfieldDock.prototype._psFootText = function() {
   var st = this.state;
   if (!CP_SFUI_PHOTO_STARS || this.starsMode === "gaia" || !st) return "";
   var s = (this.starsMode === "photo-colour") ? optT("Stars: the colour they have in the photo.") : optT("Stars: as your camera recorded them; their size and colour are those of the photo, not of the star.");
   if (st.narrowband && st.narrowband.yes === true) s += " " + optT("Narrowband photo: the star colours are those of the filter palette, not of the stars.");
   if (this._ovDiffText) { var dt = this._ovDiffText(); if (dt.length > 0) s += " " + dt; }          // Cabra3D (22-oct): cuantas difieren de Gaia
   // (1-nov-2026, D8 del video de formacion: «Photo» y «Photo size» se veian IGUAL —0 % de pixeles distintos— porque, de lejos, cada estrella es un punto de menos de un
   // pixel en los dos y solo se distinguen al acercarse; ahora el pie lo dice mientras todas sean puntos. Medido en tests/c3_d_fixes.js D8.)
   var pd = (C3_PS_HINT === false) ? null : this._c3PsDrawn;
   if ((this.starsMode === "photo" || this.starsMode === "photo-size") && pd && pd.psSprites === 0 && pd.psDots > 0) s += " " + optT("From here the stars are still points: zoom the 3D in and they open into their cut-outs of the photo («Photo» makes them smaller with depth, «Photo size» keeps their size in the photo).");
   return s;
};
