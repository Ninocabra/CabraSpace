// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_flight_paint.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_flight_paint.js — PINTAR un fotograma de un VUELO y GRABARLO
// ----------------------------------------------------------------------------
// (13-oct-2026.) `ui/starfield_flight.js` dice DONDE esta la camara y QUE efectos
// tocan en cada fotograma (datos, puros); aqui se pinta. Lo que es de «Distances»
// lo pintan los metodos que ya tiene el panel, llamados desde fuera:
//   · la foto en perspectiva: `dock._drawPhotoMesh( g, fit, foto, recorte )`;
//   · los objetos, con su color, su tamaño y su brillo por profundidad:
//     `dock._distBody( g, modelo, escala, fit, proj, sc, recorte, { part: "objects" } )`;
//   · el texto de la placa de un objeto: `dock._plateOf( modelo, indice, papel )`.
// Y aqui va lo que es del VIDEO: la caja con su opacidad y una cifra en cada marco,
// la estela de movimiento, el halo de lo cercano, la viñeta, el titulo de entrada,
// el contador «desde casa», el rotulo del objeto visitado y el fundido a negro.
// (14-oct-2026, vuelta 3: la foto a la resolucion de la imagen y a varios tamaños, los recortes de video, las estelas
// en degradado y por lo que se mueve cada punto, el texto de un solo tipo y con su reserva, el marco del video.)
//
// EL PANEL NO SE TOCA: se necesita que `dock.state` sea el de la imagen (que
// «Distances» se haya abierto una vez con ella). No mira `dock.yaw` ni la vista del
// lienzo, ni deja nada cambiado en el panel.
//
// NADA DE ESTO VA EN `onPaint`: un fotograma se pinta en un bitmap (`cpFlPaintFrame`)
// desde el tic de un `Timer` (la vista previa) o desde el bucle de grabar.
// Las medidas salen de la escala de Atlas por la escala del fotograma (`sc`: un
// fotograma de 600 px de alto se pinta como el lienzo a escala 1); los colores, de
// `CP_ATLAS`. ES5.
// ============================================================================

var CP_FLP = {
   REF_H: CP_ATLAS.space[9] * 4 + CP_ATLAS.space[8],    // el alto del fotograma que se pinta a escala 1
   MARGIN: 0.055,                                       // el margen de los rotulos, en anchos del fotograma
   BASE: 0.875,                                         // la linea de base de los rotulos, en altos del fotograma
   // EL TEXTO, en fracciones del ALTO del video (se lee en un movil: el dato de una placa media 20 px a 1080p) y de UN
   // SOLO TIPO (el de texto de Atlas: antes eran tres familias, una con remates, otra de palo y una monoespaciada)
   T_CAPS: 0.019, T_SUB: 0.028, T_NAME: 0.05, T_TITLE: 0.064, T_COUNT: 0.046, T_GATE: 0.017,
   // (21-oct, Nino: «la segunda linea de la placa es muy pequeña en el video») el DATO de la placa = 66 % del nombre (antes 56 %, y se leia
   // mas chico: 15 px frente a 27 a 540p); y los rotulos pequeños del video (eyebrow, «FROM HOME») a 13 px a 540p (antes 10). Solo el video de vuelo:
   // la maquina del tiempo sigue con T_SUB / T_CAPS.
   T_PLATE_SUB: 0.033, T_CAPS_FL: 0.025,
   // LA RESERVA del texto: el pie del cuadro se oscurece suave (de SCRIM_TOP del alto al borde, hasta SCRIM de opacidad), y
   // cada letra lleva su sombra alrededor: una estrella debajo de una cifra se leia como un punto dentro del numero
   SCRIM_TOP: 0.64, SCRIM: 0.55, SCRIM_ROWS: 64,
   // LA ESTELA de un punto: se empieza a ver cuando en un obturador se mueve TRAIL_MIN (pixeles a escala 1) y del todo a
   // TRAIL_FULL; nunca mas larga que TRAIL_MAX del alto (y un punto que se mueve mas de 4 veces eso pasa rozando la camara:
   // sin estela); fina (TRAIL_W pixeles a escala 1 como mucho) y en degradado: TRAIL_STEPS trazos que salen todos de la cabeza
   TRAIL_MIN: 2.5, TRAIL_FULL: 9, TRAIL_MAX: 0.09, TRAIL_W: 1.2, TRAIL_STEPS: 8, TRAIL_AVOID: 0.36,
   NEAR_W: 1.35,                                        // el halo es de lo que la perspectiva agranda mas que esto
   GATE_W0: 0.3, GATE_W1: 4.5,                          // la cifra de un marco se ve mientras la perspectiva lo deja entre estos tamaños
   // LA FOTO NUNCA SE VE A BLOQUES: se apaga (y con ella su marco de oro) cuando un pixel de la IMAGEN llega a medir de
   // PHOTO_MAG0 a PHOTO_MAG1 pixeles del video (al cruzar su plano: «foto desenfocada a pantalla completa»)
   PHOTO_MAG0: 1.25, PHOTO_MAG1: 2.5,
   // (vuelta 4) LA FOTO Y SU MARCO, DE CANTO, se apagan (por ANGULO, no solo por ampliacion): eran una raya de oro cruzando el cuadro
   EDGE0: 0.10, EDGE1: 0.30,                            // el coseno del angulo entre la mirada y la normal de la foto: de 0 a 1 de opacidad
   // EL TRAMADO: un ruido de un nivel sobre todo el cuadro antes de codificar. Sin el, la viñeta y los degradados oscuros salen
   // en ANILLOS de un nivel (visibles estirando los oscuros). Una tesela de DITHER_N de lado, con opacidades de 0 a DITHER_A / 255.
   DITHER_N: 256, DITHER_A: 3,
   TRAIL_COUNT: 500,                                    // estelas a la vez, como mucho (junto a un cumulo denso eran un «pelo»): de mas, una de cada tantas
   TEXT_DIM: 0.85, TEXT_PAD: 0.035,                     // bajo el texto los puntos pierden esto de opacidad, con un borde suave de TEXT_PAD del lado menor
   VIG_R0: 0.42,                                        // la viñeta empieza a esta fraccion de la media diagonal y cae SUAVE (sin borde)
   OUTSIDE: 0.5                                         // en la vista previa, lo que queda fuera del cuadro del video se oscurece esto
};
var CP_FLP_DITHER = true;            // (apagado: sin tramado; el control de las pruebas del fondo en anillos)
// El negro del fundido y de la viñeta (no es de ninguna paleta: es apagar la luz).
var CP_FLP_BLACK = "#000000";

// ABRIR UN PINTOR para fotogramas de w × h. `opts` = { rect (donde va el fotograma dentro del bitmap: por defecto
// todo; en la vista previa, la proporcion del video centrada en el lienzo), title (el del campo; por defecto el del
// panel), hiRes (true = la foto a la resolucion de la imagen, a varios tamaños —`dock._photoPyramid`—, y los recortes de
// video; false = la copia pequeña del lienzo) }.
// Devuelve null si el panel no tiene nada que enseñar.
function cpFlPaintOpen(dock, w, h, opts) {
   var o = opts || {};
   if (!dock || dock.state === null || !dock.state.result) return null;
   // (vuelta 4: las medidas —puntos, texto— salen del lado MENOR del cuadro: en un video vertical, con el alto, los puntos eran
   // discos de 60 px y el texto no cabia. En 16:9 el lado menor es el alto: nada cambia.)
   var rect = o.rect || { x: 0, y: 0, w: w, h: h }, H = Math.min(rect.h, rect.w), sc = H / CP_FLP.REF_H, st = dock.state;
   var model = dock._distModel(), scale = cpSvDistScale(dock.scaleMode, model, dock.unit), hi = (o.hiRes === true);
   var photos = hi ? dock._photoPyramid(st) : (st.photo ? [st.photo] : []), caps = CP_FLP.T_CAPS_FL * H, scrim = new Bitmap(4, CP_FLP.SCRIM_ROWS);
   var dn = CP_FLP.DITHER_N, dither = new Bitmap(dn, dn);
   for (var dy = 0; dy < dn; ++dy) for (var dx = 0; dx < dn; ++dx) dither.setPixel(dx, dy, ((Math.floor(cpSvHash01(dy * dn + dx, 5) * (CP_FLP.DITHER_A + 1)) << 24) | 0xffffff) >>> 0);
   for (var sy = 0; sy < CP_FLP.SCRIM_ROWS; ++sy) { var sr = (sy + 0.5) / CP_FLP.SCRIM_ROWS, sa = Math.round(255 * sr * sr * (3 - 2 * sr)) << 24; for (var sx = 0; sx < 4; ++sx) scrim.setPixel(sx, sy, sa >>> 0); }
   return { dock: dock, w: w, h: h, rect: rect, sc: sc, model: model, scale: scale, title: String((o.title !== undefined && o.title !== null) ? o.title : st.title),
            buf: new Bitmap(w, h), scrim: scrim, dither: dither, side: H, photos: photos, photo: (photos.length > 0) ? photos[0] : null, hi: hi, ms: 0, level: 0, mag: 0, times: null,
            F: { caps: cpFont("text", caps, true, false, cpCapsSpacing(caps)), body: cpFont("text", CP_FLP.T_PLATE_SUB * H), gate: cpFont("text", Math.max(7, CP_FLP.T_GATE * H)),
                 count: cpFont("text", CP_FLP.T_COUNT * H), name: cpFont("text", CP_FLP.T_NAME * H), title: cpFont("text", CP_FLP.T_TITLE * H) } };
}
function cpFlPaintClose(P) {
   if (!P) return;
   try { if (P.buf) P.buf.clear(); } catch (e) {}
   try { if (P.scrim) P.scrim.clear(); } catch (e2) {}
   try { if (P.dither) P.dither.clear(); } catch (e3) {}
   P.buf = null; P.scrim = null; P.dither = null; P.photo = null; P.photos = [];
}

// LO QUE MIDE LA FOTO EN PANTALLA, donde mas: pixeles del fotograma por unidad de la foto (su lado mayor mide `wn`).
// Se mira en una rejilla de puntos de la foto los que caen en el cuadro (o cerca); si no cae ninguno, en todos.
function cpFlPhotoScale(fit, model, R) {
   var seen = 0, any = 0, wn = model.wn, hn = model.hn, m = 0.2 * Math.max(R.w, R.h);
   for (var j = 0; j <= 8; ++j)
      for (var i = 0; i <= 8; ++i) {
         var p = fit.px((i / 8 - 0.5) * wn, (j / 8 - 0.5) * hn, 0);
         if (!p.ok) continue;
         var s = p.w * fit.scale;
         if (s > any) any = s;
         if (p.x >= R.x - m && p.x <= R.x + R.w + m && p.y >= R.y - m && p.y <= R.y + R.h + m && s > seen) seen = s;
      }
   return (seen > 0) ? seen : any;
}
// La copia de la foto para ESTE fotograma (la menor que da para lo que la foto mide en pantalla) y cuanto se amplia la
// grande: { photo, level, mag (pixeles del video por pixel de la imagen) }.
function cpFlPhotoPick(P, fit) {
   if (P.photos.length === 0) return { photo: null, level: 0, mag: 0 };
   var need = cpFlPhotoScale(fit, P.model, P.rect) * P.model.wn, level = 0;
   for (var q = P.photos.length - 1; q > 0; --q) if (P.photos[q].width >= 0.95 * need) { level = q; break; }
   return { photo: P.photos[level], level: level, mag: need / P.photos[0].width };
}

// LA CIFRA DE CADA MARCO, en su esquina de abajo a la izquierda: los marcos pasan como puertas, y cada una dice a
// cuanto esta. (La caja —marcos y aristas, por profundidad respecto a la foto— la pinta el panel: `_distBody`.)
// EN VUELO SOLO VAN LAS QUE CABEN: ninguna pisa a otra ni cae ENCIMA DE LA FOTO (`photoQuad`: apiladas sobre la imagen no
// se leian; revision visual del 14-oct-2026). Devuelve cuantas ha puesto.
function cpFlPaintGates(g, P, fit, alpha, photoQuad) {
   if (!(alpha > 0.004)) return 0;
   var model = P.model, scale = P.scale, wn = model.wn, hn = model.hn, sc = P.sc, R = P.rect, font = P.F.gate;
   var words = P.dock._words(), gap = Math.round(CP_ATLAS.space[0] * sc), put = [];
   g.font = font;
   for (var i = 0; i < scale.ticks.length; ++i) {
      var tk = scale.ticks[i], p = fit.px(-wn / 2, hn / 2, tk.t);
      if (!p.ok || !(p.w > CP_FLP.GATE_W0 && p.w < CP_FLP.GATE_W1)) continue;
      var text = cpSvFormatDistance(tk.pc, scale.unit, words).text, tw = font.width(text), x = p.x + gap, y = p.y - gap;
      if (x < R.x + gap || x + tw > R.x + R.w - gap || y - font.ascent < R.y + gap || y > R.y + R.h - gap) continue;
      var box = { x: x - 2 * gap, y: y - font.ascent - 2 * gap, w: tw + 4 * gap, h: font.ascent + 4 * gap }, hit = false;
      for (var q = 0; q < put.length && !hit; ++q) hit = cpSvBoxesOverlap(box, put[q]);
      if (!hit && photoQuad) hit = cpFlInQuad(photoQuad, x, y) || cpFlInQuad(photoQuad, x + tw, y) || cpFlInQuad(photoQuad, x, y - font.ascent) || cpFlInQuad(photoQuad, x + tw, y - font.ascent);
      if (hit) continue;
      put.push(box);
      var a = Math.min(1, (p.w - CP_FLP.GATE_W0) / 0.3) * Math.min(1, (CP_FLP.GATE_W1 - p.w) / 1.5);
      g.opacity = alpha * Math.max(0, a) * 0.9;
      g.pen = new Pen(CP_INT_MUTED); g.drawText(x, y, text);
   }
   g.opacity = 1;
   return put.length;
}
// ¿Cae (x, y) dentro del cuadrilatero convexo `q` (cuatro puntos { x, y }, en orden)?
function cpFlInQuad(q, x, y) {
   var sign = 0;
   for (var i = 0; i < 4; ++i) {
      var a = q[i], b = q[(i + 1) % 4], c = (b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x);
      if (c === 0) continue;
      if (sign === 0) sign = (c > 0) ? 1 : -1;
      else if ((c > 0) !== (sign > 0)) return false;
   }
   return true;
}
// ¿Cae (x, y) sobre EL OBJETO de un recorte? (`q`: las cuatro esquinas de su bitmap, un paralelogramo; el objeto es la
// elipse de su centro, de TRAIL_AVOID de su lado de radio.)
function cpFlOnCutout(q, x, y) {
   var ax = q[1].x - q[0].x, ay = q[1].y - q[0].y, bx = q[3].x - q[0].x, by = q[3].y - q[0].y, det = ax * by - ay * bx;
   if (Math.abs(det) < 1e-9) return false;
   var dx = x - q[0].x, dy = y - q[0].y, s = (dx * by - dy * bx) / det - 0.5, t = (ax * dy - ay * dx) / det - 0.5;
   return s * s + t * t < CP_FLP.TRAIL_AVOID * CP_FLP.TRAIL_AVOID;
}
// Una pluma de canto recto (los trazos de una estela acaban en seco: con el canto redondo de fabrica cada uno dejaba un punto).
function cpFlPen(color, width) {
   try { if (typeof PenCap_Flat !== "undefined" && typeof PenStyle_Solid !== "undefined") return new Pen(color, width, PenStyle_Solid, PenCap_Flat); } catch (e) {}
   return new Pen(color, width);
}

// LA ESTELA (rehecha el 14-oct-2026, vuelta 3; revision visual: «no son un degradado sino 3-4 BLOQUES rectangulares, salen
// con la camara casi quieta y cruzan por encima de la galaxia»). Cada punto, unido con donde estaba hace un obturador:
//   · PROPORCIONAL A LO QUE ESE PUNTO SE MUEVE EN PANTALLA: por debajo de TRAIL_MIN no hay estela, y entra suave hasta
//     TRAIL_FULL (un punto casi quieto —lo que se rodea, lo lejano— no lleva cola aunque la camara se mueva);
//   · UN DEGRADADO FINO: TRAIL_STEPS trazos que salen todos de la cabeza, cada uno mas largo que el anterior, con la
//     opacidad justa para que juntos den la de la cabeza: cae de forma continua hasta 0 en la cola. De TRAIL_W de grosor;
//   · NUNCA sobre la foto (`avoid.photo`: sus cuatro esquinas) ni sobre un objeto con recorte (`avoid.cuts`: las de cada uno);
//   · `alpha` (0…1): el tope de este fotograma (`cpFlFrame`: 0 en una parada y al caer sobre la foto).
// Devuelve cuantas ha pintado.
function cpFlPaintTrails(g, P, fit, proj, prevCam, alpha, avoid) {
   if (!(alpha > 0.02)) return 0;
   var model = P.model, objs = model.objects, R = P.rect, sc = P.sc, n = 0, av = avoid || {}, cuts = av.cuts || [], q, k, list = [];
   var fitP = cpSvDistCam(model, R, cpFlCamToView(prevCam, model, R)), projP = cpSvDistProject(model, P.scale, fitP);
   var minL = CP_FLP.TRAIL_MIN * sc, fullL = CP_FLP.TRAIL_FULL * sc, maxL = CP_FLP.TRAIL_MAX * P.side, x0 = R.x, x1 = R.x + R.w, y0 = R.y, y1 = R.y + R.h, wMax = Math.max(1, CP_FLP.TRAIL_W * sc);
   for (var i = 0; i < objs.length; ++i) {
      var ob = objs[i];
      if ((ob.kind !== "star" && ob.kind !== "member") || !proj.vis[i] || !projP.vis[i]) continue;
      var x = proj.px[i], y = proj.py[i];
      if (x < x0 || x > x1 || y < y0 || y > y1) continue;
      var px = projP.px[i], py = projP.py[i], dx = x - px, dy = y - py, len = Math.sqrt(dx * dx + dy * dy);
      if (len < minL || len > 4 * maxL) continue;
      var r = (len - minL) / (fullL - minL), a = alpha * ((r >= 1) ? 1 : r * r * (3 - 2 * r));
      if (a < 0.03) continue;
      if (av.photo && (cpFlInQuad(av.photo, x, y) || cpFlInQuad(av.photo, px, py))) continue;
      var hit = false;
      for (q = 0; q < cuts.length && !hit; ++q) hit = cpFlOnCutout(cuts[q], x, y) || cpFlOnCutout(cuts[q], px, py);
      if (hit) continue;
      var L = Math.min(len, maxL);
      list.push([x, y, dx / len, dy / len, L, a, Math.max(1, Math.min(wMax, ((ob.kind === "member") ? 0.67 : ob.size) * sc * cpSvDepthSize(proj.pm[i]) * 0.9)), ob.rgb & 0xffffff]);
   }
   // (junto a un cumulo denso salian miles: un «pelo». Como mucho TRAIL_COUNT: de mas, una de cada tantas, siempre las mismas.)
   var stride = Math.max(1, Math.ceil(list.length / CP_FLP.TRAIL_COUNT));
   for (var t = 0; t < list.length; t += stride) {
      var T = list[t], steps = Math.max(2, Math.min(CP_FLP.TRAIL_STEPS, Math.round(T[4] / (2.5 * sc)))), layer = 1 - Math.pow(1 - T[5], 1 / steps);
      while (steps > 2 && layer * 255 < 2) { --steps; layer = 1 - Math.pow(1 - T[5], 1 / steps); }
      g.pen = cpFlPen(((Math.max(1, Math.round(255 * layer)) << 24) | T[7]) >>> 0, T[6]);
      for (k = 1; k <= steps; ++k) g.drawLine(T[0], T[1], T[0] - T[2] * T[4] * k / steps, T[1] - T[3] * T[4] * k / steps);
      ++n;
   }
   return n;
}
// EL HALO de lo cercano: un disco tenue del color de la estrella, mayor que ella, bajo las que la perspectiva agranda.
function cpFlPaintGlow(g, P, proj, strength) {
   if (!(strength > 0.02)) return 0;
   var objs = P.model.objects, R = P.rect, sc = P.sc, n = 0, maxR = CP_ATLAS.space[2] * sc;
   g.pen = new Pen(0x00000000, 0);
   for (var i = 0; i < objs.length; ++i) {
      var ob = objs[i];
      if (ob.kind !== "star" || !proj.vis[i] || !(proj.pm[i] > CP_FLP.NEAR_W)) continue;
      var x = proj.px[i], y = proj.py[i], r = Math.min(maxR, ob.size * sc * cpSvDepthSize(proj.pm[i]));
      if (x < R.x - 4 * r || x > R.x + R.w + 4 * r || y < R.y - 4 * r || y > R.y + R.h + 4 * r) continue;
      var k = Math.min(1, (proj.pm[i] - CP_FLP.NEAR_W) / 1.2) * strength;
      g.brush = P.dock._brush(ob.rgb);
      // (leve: en la primera captura eran discos grises con borde, como un desenfoque)
      g.opacity = 0.045 * k; g.drawCircle(x, y, r * 3.0);
      g.opacity = 0.08 * k; g.drawCircle(x, y, r * 1.9);
      ++n;
   }
   g.opacity = 1;
   return n;
}
// Un texto con su opacidad y una sombra corta (se lee encima de una nebulosa clara). (x, y) = su linea de base.
function cpFlPaintText(g, P, font, color, x, y, text, alpha) {
   if (!(alpha > 0.004) || !text) return;
   var d = Math.max(1, Math.round(P.sc));
   g.font = font;
   g.opacity = 0.5 * alpha; g.pen = new Pen(cpInt(CP_FLP_BLACK));
   g.drawText(x + d, y + d, text); g.drawText(x - d, y + d, text); g.drawText(x + d, y - d, text); g.drawText(x - d, y - d, text);
   g.opacity = alpha; g.pen = new Pen(color); g.drawText(x, y, text);
   g.opacity = 1;
}
// LA PLACA de un objeto EN UN VIDEO: [ NOMBRE, papel · dato ] con UNA SOLA CIFRA, la distancia («26 200 M ly» al lado de «light
// left 12 700 M yr ago» parecian dos datos que no casan; el tiempo de luz se queda en la ficha del panel). El nombre y el papel
// son los del panel (`_plateOf`: una sola convencion; 21-oct: «pon tambien los NOMBRES del mas lejano y el mas cercano»).
function cpFlPlateText(dock, model, idx) {
   var role = "", hi = cpSvDistHighlights(model), ob = model.objects[idx];
   for (var q = 0; q < hi.length; ++q) if (hi[q].index === idx) role = hi[q].role;
   var txt = dock._plateOf(model, idx, role);
   // (vuelta 4) UNA SOLA CONVENCION para lo lejano, en el video y en el panel: lo que se mide con el corrimiento al rojo se dice
   // por CUANDO SALIO SU LUZ («light left 12 700 M yr ago»): una distancia de 26 200 M ly, mayor que la edad del universo, sin
   // explicar confunde (esa, la de hoy, queda para la ficha del panel). Lo demas, su distancia.
   if (ob.kind === "galaxy" || ob.kind === "quasar" || ob.kind === "group") {
      var d = null;
      try { d = dock.state.result.deepSky.objects[ob.ref]; } catch (e) {}
      // (la z va delante, como en el panel: no es una distancia —«farthest quasar · z = 2.68 · light left 11.2 G yr ago»—; la CIFRA de distancia es una sola)
      var isZ = (d && d.dist && d.dist.kind === "redshift" && d.redshift);
      txt[1] = dock._plateLabel(model, idx, role) + " · " + (isZ ? ("z = " + cpSvDec(d.redshift.z.toFixed((d.redshift.z < 0.1) ? 3 : 2)) + " · " + format(optT("light left %s ago"), cpSvFormatYears(d.redshift.lookbackYr, dock._words()))) : dock._dist(ob.pc));
   } else if (ob.kind === "star") {
      txt[1] = dock._plateLabel(model, idx, role) + " · " + dock._dist(ob.pc);
   }
   if (ob.faint > 0) txt[1] += " · " + optT("faint");      // (24-oct-2026, D1 = A': lo debil lo dice tambien en el video)
   return txt;
}
// QUE CABE: una linea que no cabe en `maxW` NO se corta con «…»: se achica la letra hasta MINK de su tamaño y, si aun asi no cabe, se
// parte en lineas por «·» o por espacios (con una letra que ya cabe la mas larga). `font` = la fuente; `role` = su familia de cpFont.
// Devuelve { font, lines, w (la linea mas ancha) }.
function cpFlFitLines(font, role, text, maxW, minK) {
   text = String(text);
   var w0 = font.width(text);
   if (w0 <= maxW || !(maxW > 0)) return { font: font, lines: [text], w: w0 };
   var px = font.pixelSize, f = font, k, size;
   var minPx = Math.max(6, Math.floor(px * minK));
   for (size = Math.floor(px * maxW / w0); size >= minPx; --size) {
      f = cpFont(role, size);
      if (f.width(text) <= maxW) return { font: f, lines: [text], w: f.width(text) };
   }
   // partir: por « · » primero, por espacios si no; voraz, con la letra de siempre
   var toks = text.split(" · "), sep = " · ", i, lines = [], cur = "";
   for (i = 0; i < toks.length; ++i) {
      var cand = (cur.length > 0) ? cur + sep + toks[i] : toks[i];
      if (cur.length > 0 && font.width(cand) > maxW) { lines.push(cur); cur = toks[i]; } else cur = cand;
   }
   lines.push(cur);
   var out = [];
   for (i = 0; i < lines.length; ++i) {
      if (font.width(lines[i]) <= maxW) { out.push(lines[i]); continue; }
      var wd = lines[i].split(" "), c2 = "";
      for (var j = 0; j < wd.length; ++j) {
         var c3 = (c2.length > 0) ? c2 + " " + wd[j] : wd[j];
         if (c2.length > 0 && font.width(c3) > maxW) { out.push(c2); c2 = wd[j]; } else c2 = c3;
      }
      out.push(c2);
   }
   // …y si una palabra sola aun no cabe, la letra baja hasta que cabe la mas ancha (nunca «…»)
   var widest = 0, f2 = font;
   for (i = 0; i < out.length; ++i) widest = Math.max(widest, font.width(out[i]));
   if (widest > maxW) {
      for (size = Math.floor(px * maxW / widest); size > 6; --size) {
         f2 = cpFont(role, size);
         widest = 0; for (i = 0; i < out.length; ++i) widest = Math.max(widest, f2.width(out[i]));
         if (widest <= maxW) break;
      }
   }
   return { font: f2, lines: out, w: widest };
}
// LA PLACA DE ABAJO A LA IZQUIERDA ya encajada: el nombre (grande) y el dato (debajo), cada uno en lo que cabe en `maxW`.
function cpFlPlateFit(P, txt, maxW) {
   var nm = cpFlFitLines(P.F.name, "text", txt[0], maxW, 0.8), sb = cpFlFitLines(P.F.body, "text", txt[1], maxW, 0.85);
   return { name: nm, sub: sb, w: Math.max(nm.w, sb.w) };
}

// UN FOTOGRAMA. `fr` = lo de `cpFlFrame( vuelo, t, { model: P.model, scale: P.scale, fps } )`. Devuelve el bitmap
// del pintor (se reutiliza de un fotograma a otro: no se libera; lo libera `cpFlPaintClose`).
// LA CAJA, LA FOTO (con el hueco de cada objeto que ha salido de ella), LOS OBJETOS Y SUS RECORTES LOS PINTA EL PANEL
// (`dock._distBody`, con la opacidad de cada capa): aqui solo va lo que es del video.
function cpFlPaintFrame(P, fr) {
   var t0 = Date.now(), dock = P.dock, R = P.rect, sc = P.sc, model = P.model, scale = P.scale, L = fr.layers, fx = fr.fx, F = P.F;
   var fit = cpSvDistCam(model, R, cpFlCamToView(fr.cam, model, R)), proj = cpSvDistProject(model, scale, fit);
   var whole = new Rect(R.x, R.y, R.x + R.w, R.y + R.h), objA = (typeof L.objects === "number") ? L.objects : 1;
   // la foto de este fotograma, y si ya se veria a bloques (al cruzar su plano): se apaga, y su marco de oro con ella
   var pick = cpFlPhotoPick(P, fit), mr = Math.max(0, Math.min(1, (pick.mag - CP_FLP.PHOTO_MAG0) / (CP_FLP.PHOTO_MAG1 - CP_FLP.PHOTO_MAG0))), sharp = 1 - mr * mr * (3 - 2 * mr);
   // …y de CANTO (el coseno entre la mirada y su normal; con la caja a medio aplastar no cuenta: ahi la foto se ve de frente)
   var er = (Math.abs(fit.fwd[2]) - CP_FLP.EDGE0) / (CP_FLP.EDGE1 - CP_FLP.EDGE0), edge = (fr.cam.flat < 0.5) ? 1 : (er <= 0) ? 0 : (er >= 1) ? 1 : er * er * (3 - 2 * er);
   var photoA = L.photo * sharp * edge;
   // LA RESERVA DEL TEXTO: las cajas de lo que se va a escribir (el rotulo de abajo a la izquierda y el contador), para que
   // los puntos que caen debajo se atenuen de verdad (una estrella sobre una cifra se leia como parte del numero)
   var dim = [], mxT = Math.round(R.w * CP_FLP.MARGIN), baseT = Math.round(R.y + R.h * CP_FLP.BASE), padT = CP_FLP.TEXT_PAD * P.side, plT = fx.plate, obT = (plT !== null) ? model.objects[plT.obj] : null;
   if (fx.title > 0.004) dim.push({ x0: R.x + mxT, x1: R.x + mxT + Math.max(F.title.width(P.title), F.caps.width(optT("A JOURNEY THROUGH"))), y0: baseT - F.title.ascent - F.caps.ascent * 2.2, y1: baseT + F.title.descent, a: fx.title });
   else if (obT) {
      // (21-oct) la placa ya encajada (nombre y dato, achicados o partidos si no caben): su caja es la de TODAS sus lineas
      var fitT = cpFlPlateFit(P, cpFlPlateText(dock, model, plT.obj), R.w - 2 * mxT), hT = fitT.sub.lines.length * (fitT.sub.font.ascent + fitT.sub.font.descent) + fitT.name.lines.length * fitT.name.font.ascent * 1.25 + fitT.name.font.descent;
      dim.push({ x0: R.x + mxT, x1: R.x + mxT + fitT.w, y0: baseT - hT, y1: baseT + fitT.sub.font.descent, a: plT.alpha });
   }
   if (fx.counter.alpha > 0.004) { var numT = dock._dist(fx.counter.pc); dim.push({ x0: R.x + R.w - mxT - Math.max(F.count.width(numT), F.caps.width(optT("FROM HOME"))), x1: R.x + R.w - mxT, y0: baseT - F.count.ascent * 1.25 - F.caps.ascent, y1: baseT + F.count.descent, a: fx.counter.alpha }); }
   for (var dq = 0; dq < dim.length; ++dq) dim[dq].pad = padT;
   P.level = pick.level; P.mag = pick.mag;
   P.buf.fill(CP_INT_SURFACE);
   var g = new Graphics(P.buf), drawn = { trails: 0, glow: 0, gates: 0, objects: null, level: pick.level, mag: pick.mag, photo: photoA };
   try {
      g.antialiasing = true;
      try { g.textAntialiasing = true; } catch (eT) {}
      g.clipRect = whole;
      var back = dock._distBody(g, model, scale, fit, proj, sc, R, { part: "back", photoAlpha: photoA, boxAlpha: L.box, frameAlpha: L.box * sharp * edge * L.photo, photo: pick.photo, holes: objA, hi: P.hi });
      g.antialiasing = true;
      var photoQuad = (photoA > 0.25 && back.mesh && back.mesh.quad) ? back.mesh.quad : null;
      drawn.gates = cpFlPaintGates(g, P, fit, L.box * sharp, photoQuad);
      drawn.glow = cpFlPaintGlow(g, P, proj, fx.glow * objA);
      drawn.objects = dock._distBody(g, model, scale, fit, proj, sc, R, { part: "objects", alpha: objA, hi: P.hi, video: true, dim: dim, shadeQuad: (back.mesh && back.mesh.quad) ? back.mesh.quad : null, shadePhoto: photoA }).drawn;
      g.opacity = 1; g.antialiasing = true;
      // las estelas, DESPUES de los objetos: asi se sabe donde ha caido cada recorte (y no pasan por encima)
      var cutQuads = [], cl = drawn.objects.cutouts || [], hasCut = {}, q;
      for (q = 0; q < cl.length; ++q) if (cl[q].alpha > 0.15) { cutQuads.push(cl[q].quad); hasCut[cl[q].index] = true; }
      drawn.trails = cpFlPaintTrails(g, P, fit, proj, fr.prevCam, fx.trail * objA, { photo: photoQuad, cuts: cutQuads });
      g.opacity = 1;
      // el objeto visitado: su anillo de oro, SOLO si es una estrella (lo demas lleva su recorte o su destello: un anillo
      // encima era una diana, y dos objetos juntos, un 8)
      var plate = fx.plate, ob = (plate !== null) ? model.objects[plate.obj] : null;
      if (ob && proj.vis[plate.obj] && !hasCut[plate.obj] && ob.kind === "star") {
         g.opacity = plate.alpha; g.pen = new Pen(CP_INT_AMBER, Math.max(1, sc)); g.brush = new Brush(0x00000000);
         g.drawCircle(proj.px[plate.obj], proj.py[plate.obj], CP_ATLAS.space[1] * sc * Math.max(1, Math.min(3, cpSvDepthSize(proj.pm[plate.obj])) * 0.6));
         g.opacity = 1;
      }
      // la viñeta: cae suave desde VIG_R0 (sin borde: con un solo tramo recto se le veia el contorno en los fotogramas oscuros)
      if (fx.vignette > 0.01) {
         var rad = 0.5 * Math.sqrt(R.w * R.w + R.h * R.h), c = new Point(R.x + R.w / 2, R.y + R.h / 2), stops = [[0, cpInt(CP_FLP_BLACK, 0)], [CP_FLP.VIG_R0, cpInt(CP_FLP_BLACK, 0)]];
         for (q = 1; q <= 6; ++q) { var vr = q / 6; stops.push([CP_FLP.VIG_R0 + (1 - CP_FLP.VIG_R0) * vr, cpInt(CP_FLP_BLACK, fx.vignette * vr * vr * (3 - 2 * vr))]); }
         g.fillRect(whole, new RadialGradientBrush(c, rad, c, stops));
      }
      // los rotulos: abajo a la izquierda, el titulo o el objeto visitado; abajo a la derecha, el contador
      var mx = Math.round(R.w * CP_FLP.MARGIN), base = Math.round(R.y + R.h * CP_FLP.BASE), lx = R.x + mx, rule = Math.max(1, Math.round(sc)), gap = Math.round(CP_ATLAS.space[1] * sc);
      // …sobre su RESERVA: el pie del cuadro se oscurece SUAVE mientras hay texto. Es UN degradado (un bitmap de 4 × 64 con
      // la transparencia en rampa, estirado con interpolacion): a franjas pintadas una a una se le veian las rayas, y con mas
      // fuerza era una banda que cortaba el cumulo por la mitad (visto en las tiras de la vuelta 3).
      var said = Math.max(fx.title, (ob ? plate.alpha : 0), fx.counter.alpha);
      if (said > 0.004 && P.scrim) {
         g.smoothInterpolation = true;
         g.opacity = CP_FLP.SCRIM * said;
         g.drawScaledBitmap(new Rect(R.x - R.w, Math.round(R.y + R.h * CP_FLP.SCRIM_TOP), R.x + 2 * R.w, R.y + R.h), P.scrim);
         g.opacity = 1;
      }
      // (21-oct) `fit` = la placa de un objeto ya encajada (`cpFlPlateFit`: nombre y dato, achicados o en varias lineas; nunca «…»)
      function lowerThird(eyebrow, name, sub, alpha, nameFont, fit) {
         if (!(alpha > 0.004)) return;
         var y = base, k, nmF = nameFont, nmL, sbF = F.body, sbL;
         if (fit) { nmF = fit.name.font; nmL = fit.name.lines; sbF = fit.sub.font; sbL = fit.sub.lines; }
         else { nmL = [cpElide(nameFont, name, R.w - 2 * mx)]; sbL = sub ? [cpElide(F.body, sub, R.w - 2 * mx)] : []; }
         if (sbL.length > 0) {
            for (k = sbL.length - 1; k >= 0; --k) { cpFlPaintText(g, P, sbF, CP_INT_AMBERLIGHT, lx, y, sbL[k], alpha); y -= Math.round(sbF.ascent + sbF.descent + ((k === 0) ? gap * 0.6 : 0)); }
         }
         for (k = nmL.length - 1; k >= 0; --k) { cpFlPaintText(g, P, nmF, CP_INT_TEXT, lx, y, nmL[k], alpha); y -= Math.round(nmF.ascent + ((k === 0) ? gap * 0.9 : gap * 0.3)); }
         if (eyebrow) {
            cpFlPaintText(g, P, F.caps, CP_INT_AMBER, lx, y, eyebrow, alpha);
            y -= Math.round(F.caps.ascent + gap);
         }
         g.opacity = alpha; g.fillRect(new Rect(lx, y, lx + Math.round(CP_ATLAS.space[6] * sc), y + rule), new Brush(CP_INT_AMBER)); g.opacity = 1;
      }
      if (fx.title > 0.004) lowerThird(optT("A JOURNEY THROUGH"), P.title, "", fx.title, F.title);
      else if (ob) {
         var txt = cpFlPlateText(dock, model, plate.obj);
         lowerThird("", txt[0], txt[1], plate.alpha, F.name, cpFlPlateFit(P, txt, R.w - 2 * mx));
      }
      if (fx.counter.alpha > 0.004) {
         var num = dock._dist(fx.counter.pc), cap = optT("FROM HOME"), rx = R.x + R.w - mx;
         cpFlPaintText(g, P, F.count, CP_INT_TEXT, rx - F.count.width(num), base, num, fx.counter.alpha);
         cpFlPaintText(g, P, F.caps, CP_INT_MUTED, rx - F.caps.width(cap), base - Math.round(F.count.ascent + gap * 0.8), cap, fx.counter.alpha);
      }
      // el fundido a negro
      if (fx.fade > 0.004) g.fillRect(whole, new Brush(cpInt(CP_FLP_BLACK, Math.min(1, fx.fade))));
      // EL TRAMADO, lo ultimo (tambien sobre el fundido): la tesela, repetida por todo el cuadro
      if (CP_FLP_DITHER === true && P.dither) {
         g.opacity = 1;
         for (var ty = R.y; ty < R.y + R.h; ty += CP_FLP.DITHER_N) for (var tx = R.x; tx < R.x + R.w; tx += CP_FLP.DITHER_N) g.drawBitmap(tx, ty, P.dither);
      }
      // EL CUADRO DEL VIDEO (la vista previa, cuando el lienzo no tiene su proporcion): lo de fuera, oscurecido, y un filete:
      // se entiende que ESO es lo que se graba
      if (R.w < P.w || R.h < P.h) {
         g.clipRect = new Rect(0, 0, P.w, P.h);
         var dark = new Brush(cpInt(CP_FLP_BLACK, CP_FLP.OUTSIDE));
         if (R.y > 0) g.fillRect(new Rect(0, 0, P.w, R.y), dark);
         if (R.y + R.h < P.h) g.fillRect(new Rect(0, R.y + R.h, P.w, P.h), dark);
         if (R.x > 0) g.fillRect(new Rect(0, R.y, R.x, R.y + R.h), dark);
         if (R.x + R.w < P.w) g.fillRect(new Rect(R.x + R.w, R.y, P.w, R.y + R.h), dark);
         g.antialiasing = false;
         g.pen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1); g.brush = new Brush(0x00000000);
         g.drawRect(R.x, R.y, R.x + R.w - 1, R.y + R.h - 1);
      }
   } finally {
      g.end();
   }
   P.ms = Date.now() - t0;
   if (P.times) P.times.push(P.ms);
   P.drawn = drawn;
   P.last = fr;
   return P.buf;
}

// ---------------------------------------------------------------------------
// GRABAR. Un GRABADOR va fotograma a fotograma: el panel llama a `step()` desde el tic de un `Timer` (la
// interfaz sigue viva, la barra avanza y «cancelar» funciona entre fotogramas).
//   opts = { path (el video: se le pone la extension que toque), format ("mp4" | "avi"; por defecto MP4 si hay
//            ffmpeg —`cpAviFfmpeg`— y AVI si no), width, height, fps, quality (la del AVI), limit (bytes por fichero),
//            mp4 (lo de `cpAviToMp4`: crf, preset, encoder), title, hiRes (por defecto true),
//            onFrame( k, bitmap, fotograma ) (cada fotograma recien pintado: para enseñarlo en el lienzo mientras se graba) }
// CON MP4 los fotogramas se graban primero en un AVI propio a calidad 97 en la carpeta temporal y, al acabar, ffmpeg
// lo pasa a H.264 (el ultimo `step()` tarda lo que tarde eso: `opts.onEncode( s )` da señal de vida); el AVI
// intermedio se borra. Si ffmpeg falla, el AVI NO se borra: queda como resultado (`format: "avi"`, y se dice).
// Devuelve { ok, why, n (fotogramas), k (los hechos), done, plan, format, step() -> true mientras quede,
//            cancel(), result: { ok, cancelled, why, format, frames, bytes, files, seconds, encodeSeconds, msPerFrame,
//                                width, height, fps } }.
// AL CANCELAR se cierra el fichero y se BORRA lo que esta misma grabacion llevaba escrito (un video a medias no es lo
// que se pidio): `result.cancelled`, sin ficheros. (`opts.keepOnCancel`: se queda, como un AVI valido mas corto.)
// `finishNow()` (Q3, 14-oct-2026: «Keep what was recorded»): acaba YA y se QUEDA con lo grabado como un video valido
// mas corto (MP4 si hay ffmpeg, AVI si no; `result.partial`). Sin un solo fotograma es cancelar.
// ---------------------------------------------------------------------------
function cpFlRecorder(dock, flight, opts) {
   var o = opts || {}, plan = cpFlPlan(flight, { fps: o.fps, width: o.width, height: o.height, quality: o.quality });
   var R = { ok: false, why: "", n: plan.n, k: 0, done: true, plan: plan, result: null, step: function() { return false; }, cancel: function() {} };
   if (!plan.ok) { R.why = plan.why; return R; }
   var P = cpFlPaintOpen(dock, plan.width, plan.height, { title: o.title, hiRes: (o.hiRes !== false) });
   if (P !== null && typeof o.frameMs === "object" && o.frameMs !== null) P.times = o.frameMs;
   if (P === null) { R.why = "nothing to record"; return R; }
   var W = null, t0 = Date.now(), ctx = { model: P.model, scale: P.scale, fps: plan.fps }, paintMs = 0;
   var mp4 = (o.format !== "avi") && cpAviFfmpeg().available, base = String(o.path).split("\\").join("/").replace(/\.(avi|mp4)$/i, "");
   var outPath = base + (mp4 ? ".mp4" : ".avi"), aviPath = mp4 ? File.systemTempDirectory.split("\\").join("/") + "/cp_flight_" + Date.now() + ".avi" : outPath;
   var quality = mp4 ? CP_AVI.MP4_SOURCE_QUALITY : plan.quality;
   R.format = mp4 ? "mp4" : "avi";
   try { W = cpAviOpen(aviPath, plan.width, plan.height, plan.fps, { limit: o.limit }); } catch (e) { cpFlPaintClose(P); R.why = String(e); return R; }
   function finish(cancelled, why) {
      if (R.done) return;
      R.done = true;
      var c = W.close(), tFrames = Date.now(), files = c.files, bytes = c.bytes, format = "avi", enc = null, i;
      cpFlPaintClose(P);
      if (mp4 && c.ok && !cancelled && !why) {
         var parts = [];
         for (i = 0; i < c.files.length; ++i) parts.push(c.files[i].path);
         var mo = o.mp4 || {};
         enc = cpAviToMp4(parts, outPath, { crf: mo.crf, preset: mo.preset, encoder: mo.encoder, timeoutS: mo.timeoutS, onTick: o.onEncode });
         if (enc.ok) {
            // (el intermedio es NUESTRO y esta en la carpeta temporal: fuera)
            for (i = 0; i < parts.length; ++i) { try { File.remove(parts[i]); } catch (eR) {} }
            files = [{ path: outPath, frames: c.frames, bytes: enc.bytes }]; bytes = enc.bytes; format = "mp4";
         } else {
            // ffmpeg ha fallado: el AVI intermedio NO se tira. Es un video entero: se deja JUNTO al sitio pedido (no en la carpeta
            // temporal, donde nadie lo iba a encontrar) y se dice.
            var kept = [];
            try { if (File.exists(outPath)) File.remove(outPath); } catch (eO) {}      // (lo que ffmpeg dejara a medias)
            for (i = 0; i < c.files.length; ++i) {
               var dst = cpAviPartPath(base + ".avi", i + 1), moved = false;
               try { File.move(c.files[i].path, dst); moved = File.exists(dst); } catch (eM) {}
               if (!moved) { try { File.copyFile(dst, c.files[i].path); moved = File.exists(dst); if (moved) File.remove(c.files[i].path); } catch (eC) {} }
               kept.push({ path: moved ? dst : c.files[i].path, frames: c.files[i].frames, bytes: c.files[i].bytes });
            }
            files = kept;
            why = "mp4 failed (" + enc.why + "): the AVI is kept";
         }
      }
      if (cancelled && o.keepOnCancel !== true) {
         for (i = 0; i < c.files.length; ++i) { try { File.remove(c.files[i].path); } catch (eD) {} }
         files = []; bytes = 0;
      }
      R.result = { ok: (c.ok && !cancelled && !why), cancelled: cancelled, why: why || c.why, format: format, frames: c.frames, bytes: bytes, files: files, seconds: (Date.now() - t0) / 1000,
                   encodeSeconds: (enc !== null) ? enc.seconds : 0, encodeLog: (enc !== null) ? enc.log : "", aviBytes: c.bytes,
                   msPerFrame: (R.k > 0) ? (tFrames - t0) / R.k : 0, paintMs: (R.k > 0) ? paintMs / R.k : 0, width: plan.width, height: plan.height, fps: plan.fps };
   }
   R.ok = true; R.done = false;
   R.step = function() {
      if (R.done) return false;
      var a;
      try {
         var bmp = cpFlPaintFrame(P, cpFlFrame(flight, plan.time(R.k), ctx));
         paintMs += P.ms;
         if (typeof o.onFrame === "function") o.onFrame(R.k, bmp, P.last);
         a = W.addBitmap(bmp, quality);
      } catch (e) { a = { ok: false, why: String(e) }; }
      if (!a.ok) { finish(false, a.why || "frame failed"); return false; }
      ++R.k;
      if (R.k >= R.n) { finish(false, ""); return false; }
      return true;
   };
   R.cancel = function() { finish(true, ""); };
   R.finishNow = function() { if (R.done) return; if (R.k < 1) { finish(true, ""); return; } R.partial = true; finish(false, ""); R.result.partial = true; };
   return R;
}
// Lo mismo, de un tiron (las pruebas y la demo). `opts.onProgress( k, n )` devuelve false para cancelar.
function cpFlRecord(dock, flight, opts) {
   var R = cpFlRecorder(dock, flight, opts);
   if (!R.ok) return { ok: false, cancelled: false, why: R.why, format: "", frames: 0, bytes: 0, files: [], seconds: 0, encodeSeconds: 0, msPerFrame: 0 };
   while (R.step()) { if (opts && typeof opts.onProgress === "function" && opts.onProgress(R.k, R.n) === false) R.cancel(); }
   return R.result;
}
