// ============================================================================
// ui/photo_offsets.js — EL DESFASE LOCAL FOTO - GAIA (22-oct-2026)
// ----------------------------------------------------------------------------
// Nino: en LDu 2 los anillos caian 2–6 px al lado de las brillantes: la solucion astrometrica de la imagen se aparta de las estrellas
// (distorsion que su ajuste no recoge; MEDIDO: mediana 2,4 px y maximo 6,2 en las 30 mas brillantes; NGC 1560: 0,4 px). El Bloque G (CabraShared/
// csh_depth_run.js) ya mide ese desfase para colocar sus aperturas: `cshDepthSeeing` (el centroide de hasta 800 brillantes sin saturar,
// repartidas por la foto, menos su posicion de Gaia) y `cshDepthOffsetField` (una rejilla de 16 × 12 nodos, en cada uno la mediana de las 7 mas
// cercanas; `at(x, y)` interpola). AQUI SE REUTILIZAN TAL CUAL (sin tocar CabraShared) y se aplican a lo que se pinta SOBRE LA FOTO: los anillos
// de «Stars», el anillo de la estrella elegida o del cursor, los puntos de la maquina del tiempo y el clic sobre una estrella. NO se aplica al 3D
// (alli la posicion es del cielo, no de los pixeles) ni a las medidas de la foto (recortes, color), que ya miran la ventana entera.
// Se calcula UNA vez por estado (fuera de onPaint: al elegir la opcion o al primer pintado) y se guarda en `st.c3off`.
// `C3_OV_CORRECT = false` apaga la correccion (el rojo de las pruebas, C3_MUTATE=5). Metodos de CPStarfieldDock. ES5.
// ============================================================================

var C3_OV_CORRECT = true;
var C3_OFF_NONE = { dx: 0, dy: 0 };
// LA ZONA MUERTA: el campo del Bloque G sale de centroides de medio maximo (con su ruido; MEDIDO el 22-oct en NGC 1560, que no tiene
// distorsion: mediana del desfase foto − Gaia 0,11 px, y un campo de hasta 0,79 px que es todo ruido) y aplicarlo donde vale menos que eso SUBIA el
// error (LDu 2: mediana 0,19 → 0,34 px). Se aplica con una rampa suave: nada por debajo de DEAD0, completo por encima de DEAD1 (el rincon de LDu 2 llega a 6 px).
var C3_OFF_DEAD0 = 0.4, C3_OFF_DEAD1 = 0.8;

// El campo de desfases del estado `st` (o null si no se pudo medir: sin vista, pocas estrellas…). `at(x, y)` -> { dx, dy } en pixeles de
// imagen (foto − Gaia: se SUMA a la posicion de Gaia para dar donde esta la estrella en la foto).
CPStarfieldDock.prototype._offField = function(st) {
   if (!st || !st.result || !st.result.stars) return null;
   var nStars = st.result.stars.length;
   if (st.c3off !== undefined && st.c3offN === nStars) return st.c3off;
   st.c3off = null; st.c3offN = nStars;
   var t0 = Date.now();
   try {
      var rec = this.dialog.findRecById(st.viewId);
      if (!rec || !optSafeView(rec.view) || typeof cshDepthSeeing !== "function") return null;
      var C = cshDepthCtx(rec.view), stars = st.result.stars, order = [], i;
      for (i = 0; i < stars.length; ++i) if (stars[i].inFrame && stars[i].g !== null && stars[i].x !== null) order.push(i);
      order.sort(function(p, q) { return stars[p].g - stars[q].g; });
      var seeing = cshDepthSeeing(C, stars, order);
      if (!(seeing.fwhm > 0) || !seeing.offs || seeing.offs.length < 20) return null;
      var OF = cshDepthOffsetField(seeing, C.W, C.H);
      var raw = OF.at;
      st.c3off = { at: function(x, y) {
                      var f = raw(x, y), m = Math.sqrt(f.dx * f.dx + f.dy * f.dy), u = Math.max(0, Math.min(1, (m - C3_OFF_DEAD0) / (C3_OFF_DEAD1 - C3_OFF_DEAD0))), w = u * u * (3 - 2 * u);
                      return (w <= 0) ? C3_OFF_NONE : { dx: f.dx * w, dy: f.dy * w };
                   }, raw: raw, n: seeing.offs.length, maxPx: OF.maxPx, medDx: seeing.dx, medDy: seeing.dy, fwhm: seeing.fwhm, ms: Date.now() - t0 };
   } catch (e) { st.c3off = null; }
   return st.c3off;
};
// El desfase en (x, y) (pixeles de imagen, como `stars[i].x`); { 0, 0 } si la correccion esta apagada o no hay campo.
CPStarfieldDock.prototype._offAt = function(x, y) {
   if (C3_OV_CORRECT !== true) return C3_OFF_NONE;
   var f = this.state ? this._offField(this.state) : null;
   return f ? f.at(x, y) : C3_OFF_NONE;
};
