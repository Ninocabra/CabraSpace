// ============================================================================
// ui/star_link.js — EL NOMBRE DE LA FICHA ES UN ENLACE A SIMBAD (Cabra3D, 26-oct-2026)
// ----------------------------------------------------------------------------
// Encargo de Nino: «haciendo un click al nombre de la estrella, se abra un explorador que me envíe al sitio de internet donde pueda encontrar la
// información más completa.» La ficha de abajo (la misma en Campo y en Galaxia: `_cardOfStar` / `_drawCard` de ui/starfield_panel.js) lleva su nombre
// en oro y subrayado, con un icono de «abrir fuera»; el cursor pasa a mano y el tooltip dice «Open in SIMBAD». Un clic abre el navegador de siempre.
//
// A QUÉ SITIO VA (https://simbad.cds.unistra.fr/simbad/sim-id?Ident=<id URL-codificado>):
//   · estrella con nombre común de Hipparcos (el de la IAU: «Alcyone»)  → ese nombre (SIMBAD lo resuelve: es un alias suyo; medido con curl)
//   · estrella de Hipparcos sin nombre propio                          → «HIP <n>»
//   · cualquier otra con su source_id de Gaia                          → «Gaia DR3 <source_id>» (SIMBAD lo resuelve si la estrella tiene entrada)
//   · sin identificador                                                → SIMBAD por coordenadas (sim-coo), radio de 3″ (27-oct; si SIMBAD no tiene nada ahí, el registro de Gaia: csh_link.js cshLinkFallback)
//   · un cúmulo, una nebulosa, una galaxia, un cuásar                  → su nombre (el de SIMBAD o el del catálogo)
// El nombre que se ENSEÑA en la ficha puede ser el legible de SIMBAD (α¹ Cen A, con superíndices): no es un identificador que SIMBAD acepte
// seguro, así que la URL no sale de ese texto sino del identificador de arriba.
//
// (3-nov-2026, CPD C10: AHORA se abre en el navegador que trae PixInsight, Dialog.openBrowser —CabraShared/csh_web.js—; Aladin y la reserva, en el del sistema.)
// CÓMO SE ABRÍA hasta el 3-nov: ExternalProcess.startDetached(rundll32.exe, ["url.dll,FileProtocolHandler", url]) (bajo V8, programa + lista de argumentos; sin shell,
// así que ni «%» ni «+» ni «&» de la URL se interpretan; abre el navegador predeterminado de Windows). MEDIDO el 26-oct desde PowerShell con la misma URL:
// rundll32 url.dll,FileProtocolHandler abrió una ventana nueva de Chrome; «explorer.exe <url>» NO abrió ningún navegador (abrió una ventana de
// «Documentos» del Explorador de archivos): refutado. Costuras de las pruebas:
//   C3_LINK_REAL  = false de fábrica con CP_NO_MAIN (cualquier prueba): NO abre nada, apunta la URL en C3_LINK_LOG;
//   C3_LINK_HOOK  = function(url) { … }: la prueba la recoge en vez de abrir;
//   C3_LINK_EXE / C3_LINK_PRE: otro programa (con sus argumentos previos) en lugar de rundll32.exe, para ver que la URL llega ENTERA por startDetached.
// Rojos: C3_LINK_BREAK = "nolink" (la ficha sale sin enlace) · "url" (la URL va sin codificar) · "noopen" (el clic no abre).
// ES5. (OJO: ninguna «barra asterisco» en un comentario: el preprocesador de PJSR se traga el resto del fichero SIN error.)
// ============================================================================

// (26-oct-2026) La parte pura (URL y abrir) vive ahora en CabraShared/csh_link.js; aquí quedan envoltorios con las costuras C3_LINK_* de siempre.
var C3_LINK = CSH_LINK;
var C3_LINK_REAL = false;        // true: abre de verdad aunque haya CP_NO_MAIN (lo pone quien lo prueba a mano)
var C3_LINK_HOOK = null;         // function(url): recoge la URL en lugar de abrir el navegador
var C3_LINK_EXE = "";            // otro programa en lugar de rundll32.exe (pruebas)
var C3_LINK_PRE = [];            // …y sus argumentos previos a la URL
var C3_LINK_LOG = [];            // las URL pedidas (las pruebas las leen)
var C3_LINK_DRY = false;         // true (con C3_LINK_REAL): arma la orden y NO la lanza; out.exe / out.args la dicen (prueba)
var C3_LINK_BREAK = "";          // rojos: nolink · url · noopen
function c3LinkBroken(k) { return (typeof C3_LINK_BREAK === "string") && C3_LINK_BREAK.length > 0 && C3_LINK_BREAK.indexOf(k) >= 0; }

// --- las URL (envoltorios de csh_link.js) -------------------------------------------------------------------------------------------------
function c3SimbadIdUrl(ident) { return cshSimbadIdUrl(ident, C3_LINK_BREAK); }
function c3SimbadCooUrl(raDeg, decDeg) { return cshSimbadCooUrl(raDeg, decDeg); }

// --- el enlace de una estrella: { text, ident, url } o null -------------------------------------------------------------------------------
// `text` = lo que se enseña como nombre (el mismo de la ficha). El identificador sale de `ident` (arriba), no de `text`.
function c3SimbadIdentOfStar(dock, idx) {
   var st = dock.state, s = (st && st.result) ? st.result.stars[idx] : null;
   if (!s) return "";
   // el casado con Hipparcos lo hace `_starName` (solo las brillantes) y lo guarda en st.starHip
   try { if (typeof dock._starName === "function") dock._starName(idx); } catch (e0) {}
   var hip = (st.starHip && st.starHip[idx] > 0) ? st.starHip[idx] : 0;
   if (hip > 0) {
      try { var N = c3SkyData().names[hip]; if (N && N.name) return String(N.name); } catch (e1) {}
      return "HIP " + hip;
   }
   if (s.sourceId) return "Gaia DR3 " + s.sourceId;
   return "";
}
function c3LinkOfStar(dock, idx, text) {
   if (c3LinkBroken("nolink")) return null;
   var st = dock.state, s = (st && st.result) ? st.result.stars[idx] : null;
   if (!s) return null;
   var ident = c3SimbadIdentOfStar(dock, idx);
   // (27-oct) las que no son de Hipparcos pueden no estar en SIMBAD: cshLinkFallback apunta el registro de Gaia para ellas (se decide al clic)
   var pos = { ra: s.ra0, dec: s.dec0 };
   if (ident.length > 0) return cshLinkFallback({ text: String(text), ident: ident, url: c3SimbadIdUrl(ident) }, pos);
   if (isFinite(s.ra0) && isFinite(s.dec0)) return cshLinkFallback({ text: String(text), ident: cpAnnotSexRA(s.ra0) + " " + cpAnnotSexDec(s.dec0), url: c3SimbadCooUrl(s.ra0, s.dec0) }, pos);
   return null;
}
// …y el de un objeto que no es una estrella (cúmulo, nebulosa, galaxia, cuásar, grupo): por su nombre. `raw` = el nombre tal cual lo guarda el
// modelo (el de SIMBAD con su prefijo de catálogo, que SIMBAD acepta), `text` = el que se enseña.
function c3LinkOfName(raw, text) {
   if (c3LinkBroken("nolink")) return null;
   var id = String(raw || "").replace(/^\s+|\s+$/g, "");
   if (id.length === 0 || String(text || "").length === 0) return null;
   return { text: String(text), ident: id, url: c3SimbadIdUrl(id) };
}

// --- abrir el navegador (envoltorio de cshOpenUrl) ------------------------------------------------------------------------------------
// Devuelve { ok, url, via: "hook" | "logged" | "rundll32" | "exe" | "noopen" | "pixinsight" | "system", why, exe, args }.
function c3OpenUrl(url) {
   C3_LINK_LOG.push(String(url));
   return cshOpenUrl(url, {
      hook: C3_LINK_HOOK, real: C3_LINK_REAL, noMain: (typeof CP_NO_MAIN !== "undefined" && CP_NO_MAIN) ? true : false,
      exe: C3_LINK_EXE, pre: C3_LINK_PRE, dry: C3_LINK_DRY, broken: C3_LINK_BREAK
   });
}

// --- dibujar el nombre como enlace (lo llama `_drawCard`) -----------------------------------------------------------------------------
// Devuelve el rectángulo del nombre (lo clicable), en los píxeles del lienzo.
function c3LinkPaintName(g, dock, card, tx, by, F, maxW, sc) {
   var P = function(v) { return Math.round(v * sc); }, L = card.link, hot = (dock._c3LinkHot === true), col = hot ? CP_INT_AMBERLIGHT : CP_INT_AMBER;
   var s = Math.max(6, Math.round(F.plate.ascent * 0.62)), gap = P(5), room = maxW - s - gap - P(2);
   var txt = cpElide(F.plate, L.text, Math.max(P(20), room)), w = F.plate.width(txt);
   g.font = F.plate; g.pen = new Pen(col);
   g.drawText(tx, by, txt);
   // el subrayado (1 px lógico, justo bajo la línea base) y el icono de «abrir fuera»: una caja abierta por arriba a la derecha y una flecha
   var lw = Math.max(1, Math.round(sc)), uy = by + Math.max(2, P(2));
   g.pen = new Pen(col, lw);
   g.drawLine(tx, uy, tx + w, uy);
   var ix = tx + w + gap, iy = by - s;
   g.drawLine(ix, iy + Math.round(s * 0.30), ix, iy + s); g.drawLine(ix, iy + s, ix + s - Math.round(s * 0.30), iy + s);
   g.drawLine(ix + s - Math.round(s * 0.30), iy + s, ix + s - Math.round(s * 0.30), iy + Math.round(s * 0.55));
   g.drawLine(ix + Math.round(s * 0.30), iy + Math.round(s * 0.70), ix + s, iy);
   g.drawLine(ix + Math.round(s * 0.50), iy, ix + s, iy); g.drawLine(ix + s, iy, ix + s, iy + Math.round(s * 0.50));
   var x1 = ix + s;
   // lo que siga al nombre en la misma línea (con el polvo encendido: «  ·  Dust in front…»), en texto normal
   var rest = (String(card.name).indexOf(L.text) === 0) ? String(card.name).substring(L.text.length) : "", lineEnd = 0;
   if (rest.length > 0) {
      var rx = x1 + P(4), rw = tx + maxW - rx;
      if (rw > P(30)) { var rt = cpElide(F.plate, rest, rw); g.font = F.plate; g.pen = new Pen(CP_INT_TEXT); g.drawText(rx, by, rt); lineEnd = rx + F.plate.width(rt); }
   }
   // (27-oct, D3) `lineEnd`: dónde acaba lo pintado en la línea del nombre (el aviso no lo pisa); `args`: para repintar el nombre en oro claro encima
   return { x0: tx, y0: by - F.plate.ascent, x1: x1 + P(2), y1: uy + P(2), shown: txt, lineEnd: lineEnd, args: { card: card, tx: tx, by: by, F: F, maxW: maxW, sc: sc } };
}

// --- el ratón sobre el nombre ---------------------------------------------------------------------------------------------------------
// El enlace bajo (x, y), o null: lo que dejó el último pintado de la ficha (`lay.card`, que lleva su `link` y su `nameRect`).
function c3LinkAt(dock, x, y) {
   var lay = dock.lay, c = lay ? lay.card : null;
   if (!c || !c.link || !c.nameRect) return null;
   var r = c.nameRect;
   return (x >= r.x0 && x <= r.x1 && y >= r.y0 && y <= r.y1) ? c.link : null;
}
// (27-oct, D3) el texto del aviso, con el criterio común (CabraShared/csh_link.js): sin repetir el id si es el nombre que se ve
function c3LinkTipText(link) { return cshLinkTipText(optT("Open in SIMBAD"), link); }
// El tooltip de la zona de la ficha (lo pide `_onMove`): el del enlace si el cursor está sobre el nombre, si no "" (queda la ficha entera).
function c3LinkTipAt(dock, x, y) {
   var L = c3LinkAt(dock, x, y);
   return L ? c3LinkTipText(L) : "";
}
CPStarfieldDock.prototype.c3LinkOpen = function(link) {
   if (!link || !link.url) return { ok: false, url: "", via: "", why: "no link" };
   return c3OpenUrl(link.url);
};
// (27-oct-2026, D3 de Nino: en CabraComposition el tooltip tapaba la línea de datos de debajo del nombre) EL AVISO del nombre-enlace ya no es el
// tooltip del sistema (sale bajo el cursor, encima de los datos): se PINTA donde lo ponen los tres scripts (cshLinkTipPlace, CabraShared/csh_link.js):
// a la derecha del nombre, si no encima (la cabecera de la ficha), si no en su línea. Lo llama `_drawCard` (ui/starfield_panel.js) al final, con la
// ficha ya pintada: la ficha se pinta en `_drawMarks` (onPaint), en el Campo y en la Galaxia, así que entrar o salir del nombre solo repinta.
// Sobre el nombre el tooltip del sistema queda VACÍO (`_onMove`). `c.tip` dice lo pintado (las pruebas lo leen). `c` = la ficha ya maquetada.
function c3LinkPaintTip(g, dock, c, H) {
   var r = c ? c.nameRect : null;
   if (!c || !c.link || !r || !r.args || dock._c3LinkHot !== true) { if (c) c.tip = null; return null; }
   var sc = r.args.sc, F = r.args.F, text = c3LinkTipText(c.link), sz = cshLinkTipSize(F.small, text, sc);
   var pl = cshLinkTipPlace(r, sz.w, sz.h, c.x + c.w, H, Math.round(CSH_LINK_TIP.GAP * sc), r.lineEnd);
   cshLinkTipPaint(g, pl, text, F.small, sc, { bg: CP_INT_SURFACE2, border: CP_INT_AMBER, text: CP_INT_TEXT });
   c.tip = { x: pl.x, y: pl.y, w: pl.w, h: pl.h, where: pl.where, text: text };
   return c.tip;
}
CPStarfieldDock.prototype._c3LinkSync = function(x, y, buttons) {
   var hot = (buttons === 0 || buttons === undefined) && c3LinkAt(this, x, y) !== null;
   if (hot === (this._c3LinkHot === true)) return;
   this._c3LinkHot = hot;
   try { this.canvas.cursor = new Cursor(hot ? StdCursor_PointingHand : StdCursor_Arrow); } catch (eC) {}
   try { this.canvas.repaint(); } catch (eP) {}
};
CPStarfieldDock.prototype._c3LinkLeave = function() {
   if (this._c3LinkHot !== true) return;
   this._c3LinkHot = false;
   try { this.canvas.cursor = new Cursor(StdCursor_Arrow); } catch (eC) {}
   try { this.canvas.repaint(); } catch (eP) {}
};
var c3LinkBaseOnMove = CPStarfieldDock.prototype._onMove;
CPStarfieldDock.prototype._onMove = function(x, y, buttons) {
   c3LinkBaseOnMove.call(this, x, y, buttons);
   this._c3LinkSync(x, y, buttons);
};
// UN CLIC (sin arrastrar) sobre el nombre abre SIMBAD y NO cambia lo elegido (el base lo soltaría: un clic en vacío suelta la elegida).
var c3LinkBaseOnRelease = CPStarfieldDock.prototype._onRelease;
CPStarfieldDock.prototype._onRelease = function(x, y, button) {
   var d = this._drag, L = null;
   if (d && !d.moved && button === OPT_MOUSE_LEFT && this.mode !== "" && this.state !== null) {
      L = c3LinkAt(this, x, y);
      if (L && c3LinkAt(this, d.x, d.y) === null) L = null;          // (la pulsación empezó fuera del nombre: era otro gesto)
   }
   if (L) d.moved = true;                                           // (para el base, esto ya fue un arrastre: no elige ni suelta nada)
   c3LinkBaseOnRelease.call(this, x, y, button);
   if (L) this.c3LinkOpen(L);
};

// --- los textos (EN y ES) -------------------------------------------------------------------------------------------------------------
(function() {
   C3_I18N_ES["Open in SIMBAD"] = "Abrir en SIMBAD";
})();
