// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_view.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_view.js — DISTANCIAS: la GEOMETRIA de la vista, PURA (Cabra3D: sin el HR)
// ----------------------------------------------------------------------------
// Fase 3 de la vista de distancias (13-oct-2026; Cabra3D no lleva el diagrama HR de la fase 2). El motor
// (`engine/starfield.js`, `engine/starfield_run.js`) da los DATOS; el panel
// (`ui/starfield_panel.js`) pinta. Aqui esta lo de en medio, que es aritmetica y
// por eso node lo ejecuta entero (guardian L0-94, `_tests/cp_starfield_view_cases.js`):
//
//   · las distancias: que objetos hay y a cuanto, la escala (logaritmica, o por
//     tramos lineales), la caja mirada de lado o en 3D con una CAMARA ORBITAL
//     LIBRE y perspectiva de verdad (`cpSvDistCam`: giro completo, inclinacion
//     hasta casi ±90°, la rueda es un travelin hacia lo que hay bajo el cursor),
//     la foto troceada en una malla (cada celda, una afin: `Graphics` no da mas),
//     las bandas, los objetos que llevan placa y donde va cada placa sin que su
//     filete cruce una cifra del eje;
//   · las TRANSICIONES (13-oct-2026): que estrella es cual en dos vistas, donde
//     esta cada una en el fotograma que toque (`cpSvTransPair`, `cpSvTransAt`) y
//     la camara que va de la foto de frente a la caja abierta (`cpSvDistViewLerp`);
//   · las cifras: una distancia en años luz o en parsecs, con sus millones.
//
// NADA DE AQUI TOCA PixInsight: ni `Graphics`, ni `Font`, ni `optT`. Lo que hay
// que medir en pantalla (cuanto ocupa un texto) llega como dato. Las medidas van
// en PIXELES FISICOS: quien llama ya las ha pasado por `cpPx`.
//
// TODO INTERNO EN PARSECS, como el motor. La unica conversion es `cpSfDistanceIn`.
// ES5 puro. (OJO: ni `VERSION` ni `TITLE` como identificadores: son macros de
// ImageSolver; ver engine/starfield.js.)
// ============================================================================























// ===========================================================================
// LA VISTA DE DISTANCIAS
// ===========================================================================
// LOS OBJETOS, con su sitio en la foto (u, v: de -0,5 a 0,5 en el lado MAYOR; v
// hacia abajo) y su distancia. Solo lo que esta DENTRO del encuadre y tiene
// distancia. De `result` (cpStarfieldBuild, con o sin lo de red).
// Devuelve { objects, counts: { stars, members, clusters, galaxies, quasars,
//            others, noDistance, suspect }, wn, hn (los lados de la foto, el mayor
//            = 1), nearest, farthest (indices en objects, o -1), pcMin, pcMax,
//            subject: EL MOTIVO DE LA FOTO —lo no estelar (de SIMBAD) mas cercano al centro del encuadre, a menos de
//            SUBJECT_R—, o null: { name, cls, hasDistance, index (en objects; -1 si no se ha podido colocar) } }
//   object = { kind: "star" | "member" | "cluster" | "galaxy" | "quasar" | "group" | "other",
//              u, v, pc, lo, hi, rgb, ref (indice en stars / clusters / deepSky.objects),
//              size (radio del simbolo, en unidades de escala), suspect, name, cls,
//              radius (un cumulo: su radio en unidades de u),
//              ext (lo que MIDE en la foto: su radio de catalogo en unidades de u —el eje mayor de SIMBAD
//              partido por dos, o el radio del cumulo—, no mas que medio lado menor; 0 = el catalogo no lo dice),
//              faint (24-oct-2026, D1 = A': lo lejano que pasa la vara por poco —S/R medida entre SNR_VIS y SNR_CLEAR—: su S/R; 0 = no) }
//   counts.faint = cuantos de lo lejano son «debiles» (solo si hay)
//   faint tambien en las estrellas (26-oct-2026, A'b: su S/R medida entre SNR_VIS y SNR_CLEAR; 0 = no) y counts.faintStars = cuantas (solo si hay)
var CP_SV_SUBJECT_INSIDE = true;      // (28-oct-2026, b) la costura del rojo: apagado, una planetaria anonima DENTRO de una galaxia clasica vuelve a llevarse el motivo
// (29-oct-2026, barrido S2) LO QUE NO ES LUZ DE LA FOTO no lleva recorte: las supercascaras de HI (otype «sh», 21 cm), las nubes moleculares
// (MoC: CO, como las de MWISP) y los nucleos densos, glóbulos y nubes oscuras o de radio/submilimetrico. Su «recorte» cogia la luz de OTRA cosa —la
// nebulosa de la foto, estrellas— y la llevaba a su distancia cinematica (en IC 1396, «GSH 098+06-128» se llevaba la nebulosa a 17,5 kpc; en Rosette
// «GSH 206-01+56» a 12 kpc). Siguen en el modelo con su simbolo y su distancia; solo pierden el recorte y el hueco (ext 0).
// Costura del rojo: CP_SV_CUT_OPTICAL = false (como antes). Prueba: tests/c3_cut_optical.js.
var CP_SV_CUT_OPTICAL = true;
var CP_SV_NOT_PHOTO_OTYPES = { sh: 1, MoC: 1, cor: 1, glb: 1, DNe: 1, HVC: 1, smm: 1, mm: 1, out: 1, Cld: 1, HI: 1 };
function cpSvNotPhotoLight(d) { if (CP_SV_CUT_OPTICAL !== true || !d) return false; var t = String(d.otype || "").replace(/\?$/, ""); return CP_SV_NOT_PHOTO_OTYPES[t] === 1; }
var CP_SV_PLACE_DOUBTFUL = true;      // la costura del rojo de las brillantes (C3_MUTATE=7): apagado, las de distancia dudosa vuelven a no colocarse
function cpSvDistModel(result, opts) {
   var o = opts || {}, out = { objects: [], counts: { stars: 0, members: 0, clusters: 0, galaxies: 0, quasars: 0, others: 0, noDistance: 0, suspect: 0, doubtful: 0 },
                              wn: 1, hn: 1, nearest: -1, farthest: -1, pcMin: 0, pcMax: 0 };
   if (!result || !result.ok || !result.field) return out;
   var f = result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H), i;
   out.wn = W / big; out.hn = H / big;
   function U(x) { return (x - W / 2) / big; }
   function V(y) { return (y - H / 2) / big; }
   var stars = result.stars || [], maxMembers = (o.maxMembers > 0) ? o.maxMembers : CP_SV.MAX_MEMBERS, mem = [], extMax = Math.min(out.wn, out.hn) / 2;
   for (i = 0; i < stars.length; ++i) {
      var s = stars[i];
      if (!s.inFrame || s.dist === null || !(s.dist.pc > 0) || s.x === null) continue;
      if (s.cluster >= 0) { mem.push(i); continue; }
      // (26-oct-2026, A'b de Nino) «debil»: la S/R medida de la estrella cae entre SNR_VIS y SNR_CLEAR (`faint` = su S/R; 0 = no es debil o no se midio)
      var starFaint = (typeof cshDepthStarFaintSnr === "function") ? cshDepthStarFaintSnr(s) : null;
      // UNA DISTANCIA DUDOSA NO SE PINTA AQUI. Visto en la primera captura de M 13:
      // las 403 estrellas del nucleo del cumulo con una paralaje que no es suya salian como un chorro rojo desde
      // el cumulo hacia nosotros: una estructura que no existe. Se cuentan y el pie lo dice.
      // Cabra3D (22-oct, Nino: «las mas brillantes no salen»; medido: G 9,7 de NGC 1560 con RUWE 12 y paralaje 5,3 mas): una distancia dudosa por RUWE ≥ 1,4 de una
      // estrella de CAMPO (no del nucleo apiñado de un cumulo, que es lo que el parrafo de arriba describe) SE COLOCA, marcada `suspect` y pintada HUECA (el 3D) / a
      // trazos (la foto), con su ficha diciendolo; no cuenta como «estrella con paralaje fiable» ni entra en la escala. Las del nucleo apiñado siguen sin colocarse.
      if (s.dist.quality === "suspect") {
         if (s.dist.suspectWhy !== "crowded" && s.cluster < 0 && CP_SV_PLACE_DOUBTFUL === true) {
            var drgb = cpSvStarRgb(s.bpRp);
            out.objects.push({ kind: "star", u: U(s.x), v: V(s.y), pc: s.dist.pc, lo: s.dist.lo, hi: s.dist.hi, rgb: (drgb[0] << 16) | (drgb[1] << 8) | drgb[2], ref: i,
                               size: (s.g !== null && s.g < 9) ? 2.6 : (s.g !== null && s.g < 12) ? 2.0 : (s.g !== null && s.g < 15) ? 1.5 : 1.1,
                               suspect: true, name: "", cls: "star", radius: 0, faint: (starFaint !== null) ? starFaint : 0 });
            if (starFaint !== null) out.counts.faintStars = (out.counts.faintStars || 0) + 1;
            ++out.counts.doubtful;
         } else ++out.counts.suspect;
         continue;
      }
      var rgb = cpSvStarRgb(s.bpRp);
      out.objects.push({ kind: "star", u: U(s.x), v: V(s.y), pc: s.dist.pc, lo: s.dist.lo, hi: s.dist.hi, rgb: (rgb[0] << 16) | (rgb[1] << 8) | rgb[2], ref: i,
                         size: (s.g !== null && s.g < 9) ? 2.6 : (s.g !== null && s.g < 12) ? 2.0 : (s.g !== null && s.g < 15) ? 1.5 : 1.1,
                         suspect: false, name: "", cls: "star", radius: 0, faint: (starFaint !== null) ? starFaint : 0 });
      if (starFaint !== null) out.counts.faintStars = (out.counts.faintStars || 0) + 1;
      ++out.counts.stars;
   }
   // los miembros: los mas brillantes (la lista de estrellas ya viene de brillante a debil)
   for (i = 0; i < mem.length && i < maxMembers; ++i) {
      var ms = stars[mem[i]], mrgb = cpSvStarRgb(ms.bpRp);
      out.objects.push({ kind: "member", u: U(ms.x), v: V(ms.y), pc: ms.dist.pc, lo: ms.dist.lo, hi: ms.dist.hi, rgb: (mrgb[0] << 16) | (mrgb[1] << 8) | mrgb[2], ref: mem[i],
                         size: 0.8, suspect: false, name: "", cls: "member", radius: 0 });
   }
   out.counts.members = mem.length;
   var cl = result.clusters || [];
   for (i = 0; i < cl.length; ++i) {
      var c = cl[i];
      if (!c.inFrame || !c.dist || !(c.dist.pc > 0) || c.x === null) continue;
      var rdeg = (c.coreRadiusDeg > 0) ? c.coreRadiusDeg : 0.05;
      out.objects.push({ kind: "cluster", u: U(c.x), v: V(c.y), pc: c.dist.pc, lo: c.dist.lo, hi: c.dist.hi, rgb: 0, ref: i, size: 3, suspect: false,
                         name: String(c.name || c.id || ""), cls: String(c.kind || "cluster"), radius: (f.scaleArcsec > 0) ? rdeg * 3600 / f.scaleArcsec / big : 0.05 });
      out.objects[out.objects.length - 1].ext = (c.coreRadiusDeg > 0 && f.scaleArcsec > 0) ? Math.min(extMax, out.objects[out.objects.length - 1].radius) : 0;
      ++out.counts.clusters;
   }
   var ds = (result.deepSky && result.deepSky.objects) ? result.deepSky.objects : [], subj = null, subjR2 = CP_SV.SUBJECT_R * CP_SV.SUBJECT_R;
   out.subject = null;
   // LAS NEBULOSAS (14-oct-2026; `cpStarfieldNebulae`): la nebulosidad de la foto, a su distancia. Su sitio es su HUELLA en
   // la foto (lo que de su disco cae dentro: puede ser la foto entera, y su centro puede quedar fuera), y su recorte es esa
   // huella (`rect`). La que no tiene distancia NO se coloca: se cuenta y, si es el motivo de la foto, se dice. Lo que SIMBAD
   // ya trae como objeto de esa nebulosa no se pinta otra vez (`nebNames`).
   var nbs = (result.nebulae && result.nebulae.objects) ? result.nebulae.objects : [], nebNames = {}, placedRects = [];
   out.counts.nebulae = 0;
   for (i = 0; i < nbs.length; ++i) {
      var nb = nbs[i], ft = nb.foot;
      if (!ft || !(ft.x1 > ft.x0) || !(ft.y1 > ft.y0)) continue;
      nebNames[String(nb.name || "")] = true;
      var nu0 = U(ft.x0), nu1 = U(ft.x1), nv0 = V(ft.y0), nv1 = V(ft.y1), nu = (nu0 + nu1) / 2, nv = (nv0 + nv1) / 2, hasN = (nb.dist !== null && nb.dist !== undefined && nb.dist.pc > 0);
      // (es el motivo si cubre el centro de la foto o su centro de masas esta cerca de el)
      var ncx = U(ft.cx), ncy = V(ft.cy), nr2 = (nu0 <= 0 && nu1 >= 0 && nv0 <= 0 && nv1 >= 0) ? Math.min(ncx * ncx + ncy * ncy, subjR2 * 0.999) : ncx * ncx + ncy * ncy;
      // (la que CUBRE el centro de la foto va por delante de todo: en el campo de Sh 2-132 una region WISE de SIMBAD mas
      // pequeña y mas centrada se llevaba el motivo —medido el 14-oct-2026 en `cp_nebula_look.log`—)
      var covers = (nu0 <= 0 && nu1 >= 0 && nv0 <= 0 && nv1 >= 0);
      if (nr2 < subjR2 && (subj === null || nr2 < subjR2)) { subjR2 = nr2; subj = { name: String(nb.id), cls: "nebula", hasDistance: hasN, index: -1, ref: -1, neb: i, rank: covers ? -1 : 0 }; }
      if (hasN) placedRects.push({ u0: nu0, v0: nv0, u1: nu1, v1: nv1, id: String(nb.id) });
      if (!hasN) { ++out.counts.noDistance; continue; }
      out.objects.push({ kind: "nebula", u: nu, v: nv, pc: nb.dist.pc, lo: (nb.dist.lo > 0) ? nb.dist.lo : nb.dist.pc, hi: (nb.dist.hi > 0 && isFinite(nb.dist.hi)) ? nb.dist.hi : nb.dist.pc,
                         rgb: 0, ref: i, size: 3.0, suspect: false, name: String(nb.id), alias: (nb.name && nb.name !== nb.id) ? String(nb.name) : "", cls: "nebula", radius: 0,
                         ext: Math.max(nu1 - nu0, nv1 - nv0) / 2, rect: { u0: nu0, v0: nv0, u1: nu1, v1: nv1 },
                         disc: { u: U(ft.cx), v: V(ft.cy), r: (f.scaleArcsec > 0) ? nb.radiusDeg * 3600 / f.scaleArcsec / big : 0 } });
      ++out.counts.nebulae;
      if (subj !== null && subj.neb === i) subj.index = out.objects.length - 1;
   }
   // (28-oct-2026, b de Nino) LAS GALAXIAS DE NOMBRE CLASICO CON TAMAÑO (su disco, en unidades de u): una nebulosa o planetaria de nombre NO
   // clasico que cae DENTRO de una de ellas es suya —en el campo de M 82, «[JMT2009] 232», una candidata a planetaria DE M 82, se llevaba
   // la placa del motivo por delante de la galaxia, y la linea de estado decia que no se colocaba—. No puede ser el motivo. Costura del
   // rojo: CP_SV_SUBJECT_INSIDE = false (como antes).
   var hosts = [];
   if (CP_SV_SUBJECT_INSIDE === true && f.scaleArcsec > 0)
      for (i = 0; i < ds.length; ++i) {
         var hg = ds[i];
         if (!hg.inFrame || hg.x === null || hg.x === undefined || !(hg.sizeArcmin > 0) || hg.unseen === true) continue;
         if ((hg.cls === "galaxy" || hg.cls === "galaxy-group" || hg.cls === "galaxy-part") && CP_SV_CLASSIC.test(String(hg.name || "")))
            hosts.push({ u: U(hg.x), v: V(hg.y), r: hg.sizeArcmin * 60 / 2 / f.scaleArcsec / big });
      }
   function insideHost(u, v) { for (var h = 0; h < hosts.length; ++h) { var hu = u - hosts[h].u, hv = v - hosts[h].v; if (hu * hu + hv * hv <= hosts[h].r * hosts[h].r) return true; } return false; }
   for (i = 0; i < ds.length; ++i) {
      var d = ds[i];
      if (!d.inFrame || d.x === null || d.x === undefined) continue;
      if (d.cluster >= 0) continue;                      // ese cumulo ya esta pintado, con su distancia de catalogo
      if (nebNames[String(d.name || "")] === true) continue;   // esa nebulosa ya esta, con su huella
      // EL MOTIVO DE LA FOTO: el mas centrado (tenga o no distancia: si no la tiene hay que DECIRLO, no solo contarlo).
      // Antes una nebulosa (planetaria o no) que una galaxia; y de lo que no es nebulosa, solo lo que tiene NOMBRE DE
      // CATALOGO CLASICO (M, NGC, IC, UGC, Abell, Arp, Mrk, 3C…), nunca un objeto anonimo de un cartografiado: en el
      // campo de Abell 39 habia una «SDSS J162733.43+275317.4» mas cerca del centro que la planetaria, y en el de M 13
      // un cuasar «Gaia DR3 1328031826695938816», y se llevaban la placa (vistos en las capturas).
      var du = U(d.x), dv = V(d.y), hasD = (d.dist !== null && d.dist !== undefined && d.dist.pc > 0), nm = String(d.name || "");
      var rank = (d.cls === "planetary-nebula" || d.cls === "nebula") ? 0 : 1, r2 = du * du + dv * dv;
      var guest = (rank === 0 && hosts.length > 0 && !CP_SV_CLASSIC.test(nm) && insideHost(du, dv));      // (b: la de dentro de una galaxia clasica)
      if (r2 < CP_SV.SUBJECT_R * CP_SV.SUBJECT_R && nm.length > 0 && d.unseen !== true && !guest && (rank === 0 || CP_SV_CLASSIC.test(nm)) && (subj === null || rank < subj.rank || (rank === subj.rank && r2 < subjR2)) && !(subj !== null && subj.neb >= 0 && rank > 0)) {
         subjR2 = r2; subj = { name: nm, cls: String(d.cls || ""), hasDistance: hasD, index: -1, ref: i, rank: rank };
      }
      if (!hasD) { ++out.counts.noDistance; continue; }
      var kind = (d.cls === "quasar") ? "quasar" : (d.cls === "galaxy" || d.cls === "galaxy-part" || d.cls === "supernova") ? "galaxy" : (d.cls === "galaxy-group") ? "group" : "other";
      // lo que mide: el eje mayor de SIMBAD (minutos de arco), la mitad, en unidades de u
      var dExt = (kind !== "quasar" && d.sizeArcmin > 0 && f.scaleArcsec > 0) ? Math.min(extMax, d.sizeArcmin * 60 / 2 / f.scaleArcsec / big) : 0;
      // (una nube de SIMBAD DENTRO de una nebulosa ya colocada —o cuyo recorte cae en ella mas de la mitad— no lleva recorte: su
      // luz ya va en la capa de la nebulosa, y repetida a otra distancia era la misma nebulosidad dos o tres veces: en el campo
      // de Sh 2-132, una region WISE a 13 500 al y la supercascara de HI «GSH 102+00-85» a 30 000. Medido el 14-oct-2026.)
      var inNeb = (d.cls === "nebula") ? (cpSvInRects(placedRects, du, dv, 0) || cpSvInRects(placedRects, du, dv, dExt * CP_SV.CUT_MARGIN, out.wn, out.hn)) : false;
      // (23-oct-2026: `unseen` = esta en el catalogo y en el encuadre pero NO se ve en la foto —solo con el interruptor «tambien
      // lo que no se ve en tu foto», apagado de fabrica: CabraShared/csh_depth_run.js `cshDepthShowUnseen`—: hueco como lo dudoso,
      // fuera del «mas cercano / mas lejano», de la escala, de los recortes de foto —`ext` 0: ni recorte ni hueco, ni en el vuelo,
      // ni en la maquina del tiempo, ni en las estrellas de la foto— y de las cuentas de la linea de estado; H2 de Gemini, 24-oct)
      var unseen = (d.unseen === true);
      // (24-oct-2026, D1 = A') «debil»: pasa la vara (S/R >= SNR_VIS) pero no llega a SNR_CLEAR: `faint` = su S/R medida (0 = no es debil)
      var faintSnr = (!unseen && typeof cshDepthFaintSnr === "function") ? cshDepthFaintSnr(d.depth) : null;
      out.objects.push({ kind: kind, u: U(d.x), v: V(d.y), pc: d.dist.pc, lo: (d.dist.lo > 0) ? d.dist.lo : d.dist.pc, hi: (d.dist.hi > 0) ? d.dist.hi : d.dist.pc, rgb: 0, ref: i,
                         size: (kind === "quasar") ? 2.4 : 3.0, suspect: (d.dist.quality === "unreliable") || unseen, unseen: unseen, name: String(d.name || ""), cls: String(d.cls || ""), radius: 0,
                         ext: (inNeb || unseen || cpSvNotPhotoLight(d)) ? 0 : dExt, inNebula: inNeb, notPhoto: cpSvNotPhotoLight(d), faint: (faintSnr !== null) ? faintSnr : 0 });
      if (unseen) { out.counts.unseen = (out.counts.unseen || 0) + 1; continue; }
      if (faintSnr !== null) out.counts.faint = (out.counts.faint || 0) + 1;
      if (kind === "quasar") ++out.counts.quasars; else if (kind === "other") ++out.counts.others; else ++out.counts.galaxies;
      if (subj !== null && subj.ref === i) subj.index = out.objects.length - 1;
   }
   out.subject = subj;
   for (i = 0; i < out.objects.length; ++i) {
      var ob = out.objects[i];
      if (ob.kind === "member" || ob.suspect) continue;
      if (out.nearest < 0 || ob.pc < out.objects[out.nearest].pc) out.nearest = i;
      if (out.farthest < 0 || ob.pc > out.objects[out.farthest].pc) out.farthest = i;
   }
   if (out.nearest >= 0) { out.pcMin = out.objects[out.nearest].pc; out.pcMax = out.objects[out.farthest].pc; }
   return out;
}

// LA ESCALA DEL FONDO. `mode` = "log" | "segments"; `unit` = "ly" | "pc" (las
// marcas son redondas EN la unidad que se enseña). Devuelve
//   { mode, unit, t( pc ) -> 0..1, ticks: [ { pc, t, value (en la unidad) } ],
//     bands: [ { key, t0, t1 } ], lo, hi (parsecs de los extremos) }
// "log": cada decada mide lo mismo; la primera empieza en LOG_T0 (la foto, que
// somos nosotros, esta en 0). "segments": hasta tres tramos LINEALES (nuestra
// galaxia / universo cercano / universo lejano), solo los que tienen algo.
function cpSvDistScale(mode, model, unit) {
   var un = (unit === "ly") ? "ly" : "pc", k = cpSfDistanceIn(1, un);          // parsecs -> unidad
   var objs = model.objects, i, vmin = Infinity, vmax = 0;
   for (i = 0; i < objs.length; ++i) {
      if (objs[i].suspect && objs[i].kind === "star") continue;
      if (objs[i].unseen === true) continue;      // (24-oct-2026, H2: lo que la foto NO enseña no entra en la escala; ver cpSvDistModel)
      var a = objs[i].pc * k;
      if (a < vmin) vmin = a;
      if (a > vmax) vmax = a;
   }
   if (!(vmax > 0)) { vmin = 100; vmax = 10000; }
   var S = { mode: (mode === "segments") ? "segments" : "log", unit: un, ticks: [], bands: [], lo: 0, hi: 0, t: null };
   var bandEdges = [[CP_SV.BAND_GALAXY_PC, "milky-way"], [CP_SV.BAND_LOCAL_PC, "local-group"], [CP_SV.BAND_NEAR_PC, "nearby"], [Infinity, "far"]];
   if (S.mode === "log") {
      var e0 = Math.floor(Math.log(vmin * 0.999) / Math.LN10), e1 = Math.ceil(Math.log(vmax * 1.001) / Math.LN10);
      if (e1 - e0 < 2) e1 = e0 + 2;
      var T0 = CP_SV.LOG_T0;
      S.lo = Math.pow(10, e0) / k; S.hi = Math.pow(10, e1) / k;
      S.t = function(pc) {
         var v = pc * k;
         if (!(v > 0)) return 0;
         var l = Math.log(v) / Math.LN10;
         if (l <= e0) return T0 * v / Math.pow(10, e0);
         return Math.min(1, T0 + (1 - T0) * (l - e0) / (e1 - e0));
      };
      for (i = e0; i <= e1; ++i) S.ticks.push({ pc: Math.pow(10, i) / k, t: S.t(Math.pow(10, i) / k), value: Math.pow(10, i) });
      var from = 0;
      for (i = 0; i < bandEdges.length; ++i) {
         var to = Math.min(1, S.t(Math.min(bandEdges[i][0], S.hi)));
         if (to - from > 0.02) S.bands.push({ key: bandEdges[i][1], t0: from, t1: to });
         from = to;
         if (bandEdges[i][0] >= S.hi) break;
      }
      return S;
   }
   // por tramos lineales
   var edges = [0, CP_SV.BAND_GALAXY_PC, CP_SV.BAND_NEAR_PC, Infinity], keys = ["galaxy", "nearby", "far"], segs = [];
   for (var sIdx = 0; sIdx < 3; ++sIdx) {
      var top = 0;
      for (i = 0; i < objs.length; ++i) {
         if (objs[i].suspect && objs[i].kind === "star") continue;
         if (objs[i].unseen === true) continue;   // (H2: ni en los tramos lineales)
         if (objs[i].pc > edges[sIdx] && objs[i].pc <= edges[sIdx + 1] && objs[i].pc > top) top = objs[i].pc;
      }
      if (top > 0) segs.push({ key: keys[sIdx], top: top });
   }
   if (segs.length === 0) segs.push({ key: "galaxy", top: 1000 / k });
   var gap = 0.03, wSeg = (1 - gap * (segs.length - 1)) / segs.length, start = 0;
   for (i = 0; i < segs.length; ++i) {
      var sg = segs[i];
      sg.pc0 = start;
      sg.pc1 = cpSvNiceCeil(sg.top * k * 1.02) / k;
      sg.t0 = i * (wSeg + gap);
      sg.t1 = sg.t0 + wSeg;
      start = sg.pc1;
      S.bands.push({ key: sg.key, t0: sg.t0, t1: sg.t1 });
      var tv = cpSvNiceTicks(sg.pc0 * k, sg.pc1 * k, 3);
      for (var q = 0; q < tv.length; ++q) {
         if (tv[q] <= sg.pc0 * k * (1 + 1e-9) && i > 0) continue;       // el arranque de un tramo es el final del anterior
         if (tv[q] === 0) continue;
         S.ticks.push({ pc: tv[q] / k, t: sg.t0 + (tv[q] / k - sg.pc0) / (sg.pc1 - sg.pc0) * wSeg, value: tv[q] });
      }
   }
   S.segments = segs;
   S.lo = 0; S.hi = segs[segs.length - 1].pc1;
   S.t = function(pc) {
      if (!(pc > 0)) return 0;
      for (var j = 0; j < segs.length; ++j)
         if (pc <= segs[j].pc1 || j === segs.length - 1)
            return Math.max(segs[j].t0, Math.min(segs[j].t1, segs[j].t0 + (pc - segs[j].pc0) / (segs[j].pc1 - segs[j].pc0) * (segs[j].t1 - segs[j].t0)));
      return 1;
   };
   return S;
}

// ---------------------------------------------------------------------------
// LA CAMARA ORBITAL DE LA VISTA DE DISTANCIAS (13-oct-2026)
// ---------------------------------------------------------------------------
function cpSvWrapDeg(a) { var r = a % 360; return (r < 0) ? r + 360 : r; }

// LA POSE: el giro `yaw` sobre el eje vertical, SIN TOPES (da la vuelta entera; se
// normaliza a 0…360), y la inclinacion `pitch`, hasta ±PITCH_MAX. Un punto
// (X, Y, Z) —X a la derecha de la foto, Y hacia abajo, Z el fondo—, medido desde
// el pivote, queda en la camara en
//     xc = X·cos(yaw) + Z·sin(yaw)                                    (a la derecha)
//     yc = Y·cos(pitch) + ( Z·cos(yaw) - X·sin(yaw) )·sin(pitch)      (hacia abajo)
//     zc = ( Z·cos(yaw) - X·sin(yaw) )·cos(pitch) - Y·sin(pitch)      (hacia el fondo)
// Con yaw 0 se mira la foto de frente; con 90, de canto (el fondo a la derecha);
// con 180, POR DETRAS (xc = -X: la foto se ve en espejo, como el reverso de una
// diapositiva, y las estrellas con ella).
function cpSvPose(yaw, pitch) {
   var y = cpSvWrapDeg((typeof yaw === "number" && isFinite(yaw)) ? yaw : CP_SV.YAW);
   var p = Math.max(-CP_SV.PITCH_MAX, Math.min(CP_SV.PITCH_MAX, (typeof pitch === "number" && isFinite(pitch)) ? pitch : CP_SV.PITCH));
   var k = Math.PI / 180;
   return { yaw: y, pitch: p, cy: Math.cos(y * k), sy: Math.sin(y * k), cp: Math.cos(p * k), sp: Math.sin(p * k) };
}

// LA VISTA de la camara, completa y con cada cosa en sus topes:
//   yaw, pitch    la pose
//   zoom          1 = el encuadre de fabrica. Es un TRAVELIN (la camara se acerca a su pivote), no una lupa:
//                 lo que queda entre la camara y el pivote se va agrandando y acaba pasando de largo
//   ox, oy, oz    el pivote —el punto alrededor del que se gira—, desde el centro de la caja (en lados de la
//                 foto; oz, a lo largo del fondo)
//   flat          1 = la caja con su fondo; 0 = aplastada sobre la foto (el estado FOTO de las transiciones)
//   f0, cx, cy    pixeles por lado de la foto en el pivote con zoom 1, y donde cae el pivote en el lienzo
//                 (0 / NaN = los del ENCAJE de esa pose, con los que la caja cabe entera: los pone `cpSvDistCam`)
function cpSvDistView(v) {
   var q = v || {}, P = cpSvPose(q.yaw, q.pitch), D = CP_SV.DEPTH;
   function num(x, d) { return (typeof x === "number" && isFinite(x)) ? x : d; }
   function lim(x, m) { return Math.max(-m, Math.min(m, num(x, 0))); }
   return { yaw: P.yaw, pitch: P.pitch, zoom: Math.max(CP_SV.DIST_ZOOM_MIN, Math.min(CP_SV.DIST_ZOOM_MAX, num(q.zoom, 1))),
            ox: lim(q.ox, 0.75), oy: lim(q.oy, 0.75), oz: lim(q.oz, 0.75 * D), flat: Math.max(0, Math.min(1, num(q.flat, 1))),
            f0: (num(q.f0, 0) > 0) ? q.f0 : 0, cx: num(q.cx, NaN), cy: num(q.cy, NaN) };
}
function cpSvDistViewEqual(a, b) {
   var A = cpSvDistView(a), B = cpSvDistView(b), e = 1e-6;
   function same(p, q) { return Math.abs(p - q) <= e || (p !== p && q !== q); }
   return same(A.yaw, B.yaw) && same(A.pitch, B.pitch) && same(A.zoom, B.zoom) && same(A.ox, B.ox) && same(A.oy, B.oy) && same(A.oz, B.oz) &&
          same(A.flat, B.flat) && same(A.f0, B.f0) && same(A.cx, B.cx) && same(A.cy, B.cy);
}

function cpSvBoxRadius(model) {
   var D = CP_SV.DEPTH;
   return 0.5 * Math.sqrt(model.wn * model.wn + model.hn * model.hn + D * D);
}

// El trozo del segmento (x1, y1)-(x2, y2) que cae en la caja `b`, o null. (Liang-Barsky. Una
// arista de la caja con la camara dentro llega a medir cientos de miles de pixeles.)
function cpSvClipSegment(x1, y1, x2, y2, b) {
   var t0 = 0, t1 = 1, dx = x2 - x1, dy = y2 - y1;
   var p = [-dx, dx, -dy, dy], q = [x1 - b.x, b.x + b.w - x1, y1 - b.y, b.y + b.h - y1];
   for (var i = 0; i < 4; ++i) {
      if (p[i] === 0) { if (q[i] < 0) return null; }
      else {
         var r = q[i] / p[i];
         if (p[i] < 0) { if (r > t1) return null; if (r > t0) t0 = r; }
         else { if (r < t0) return null; if (r < t1) t1 = r; }
      }
   }
   return { x1: x1 + t0 * dx, y1: y1 + t0 * dy, x2: x1 + t1 * dx, y2: y1 + t1 * dy };
}

// EL ENCAJE: la escala y el sitio del pivote con los que la caja, vista con el giro y la
// inclinacion que se digan, CABE ENTERA en `rect` y queda centrada. Sigue a la pose (decision del
// 13-oct-2026 tras la revision visual: con una escala fija, en media orbita la caja se cortaba
// contra la leyenda): al girar la caja se reencaja, y como el encaje es una funcion CONTINUA de la
// pose —la caja que envuelve ocho esquinas que se mueven sin saltos— lo hace sin saltos. El zoom y
// el desplazamiento del usuario van encima de este encaje.
function cpSvDistFrame(model, rect, yaw, pitch) {
   var unit = cpSvDistCam(model, { x: 0, y: 0, w: 1, h: 1 }, { yaw: yaw, pitch: pitch, zoom: 1, f0: 1, cx: 0, cy: 0 });
   var x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
   for (var a = 0; a < 8; ++a) {
      var q = unit.px((a & 1) ? model.wn / 2 : -model.wn / 2, (a & 2) ? model.hn / 2 : -model.hn / 2, (a & 4) ? 1 : 0);
      if (q.x < x0) x0 = q.x; if (q.x > x1) x1 = q.x; if (q.y < y0) y0 = q.y; if (q.y > y1) y1 = q.y;
   }
   var f0 = Math.min(rect.w / (x1 - x0), rect.h / (y1 - y0));
   return { f0: f0, cx: rect.x + rect.w / 2 - f0 * (x0 + x1) / 2, cy: rect.y + rect.h / 2 - f0 * (y0 + y1) / 2 };
}

// LA CAMARA. `rect` = { x, y, w, h } del lienzo donde va el dibujo; `view`, lo de `cpSvDistView`.
// De agujero, con PERSPECTIVA de verdad (lo cercano, mas grande): la camara esta a K lados de su
// pivote —K0 con zoom 1, K0 / zoom despues— y un punto a profundidad zc del pivote se pinta con la
// escala del pivote por w = K / ( K + zc ). (Con CP_SV.PERSPECTIVE apagado, ortografica: w = 1.)
// Devuelve lo que hace falta para pintar y para mover la vista:
//   { mode: "perspective", px( u, v, t ) -> { x, y, z (zc), w, ok (false = detras de la camara) },
//     seg( u0, v0, t0, u1, v1, t1 ) -> { x1, y1, x2, y2 } | null   (una linea, recortada),
//     onPhoto( u, v ), scale (pixeles por lado en el pivote), K, K0, zoom, pose, view (la vista, completa),
//     cx, cy (el pivote en el lienzo), right, up, fwd (los ejes de la camara en la caja),
//     front (¿se ve la foto por delante?), wn, hn, depth, rect }
function cpSvDistCam(model, rect, view) {
   var wn = model.wn, hn = model.hn, D = CP_SV.DEPTH, V = cpSvDistView(view), P = cpSvPose(V.yaw, V.pitch);
   if (!(V.f0 > 0) || !isFinite(V.cx) || !isFinite(V.cy)) {
      var fr = cpSvDistFrame(model, rect, V.yaw, V.pitch);
      if (!(V.f0 > 0)) V.f0 = fr.f0;
      if (!isFinite(V.cx)) V.cx = fr.cx;
      if (!isFinite(V.cy)) V.cy = fr.cy;
   }
   var persp = (CP_SV.PERSPECTIVE === true), K0 = CP_SV.CAM_DIST * cpSvBoxRadius(model), K = K0 / V.zoom, sc = V.f0 * V.zoom, near = CP_SV.NEAR * K;
   var Cx = V.ox, Cy = V.oy, Cz = D / 2 + V.oz, flat = V.flat, cy = P.cy, sy = P.sy, cp = P.cp, sp = P.sp, scx = V.cx, scy = V.cy;
   var clip = { x: rect.x - 64, y: rect.y - 64, w: rect.w + 128, h: rect.h + 128 };
   function cam3(u, v, t) {
      var X = u - Cx, Y = v - Cy, Z = (t * D - Cz) * flat, d1 = Z * cy - X * sy;
      return [X * cy + Z * sy, Y * cp + d1 * sp, d1 * cp - Y * sp];
   }
   function px(u, v, t) {
      var c = cam3(u, v, t);
      if (!persp) return { x: scx + sc * c[0], y: scy + sc * c[1], z: c[2], w: 1, ok: true };
      var den = K + c[2], ok = (den > near), w = K / (ok ? den : near);
      return { x: scx + sc * c[0] * w, y: scy + sc * c[1] * w, z: c[2], w: w, ok: ok };
   }
   function seg(u0, v0, t0, u1, v1, t1) {
      var a = cam3(u0, v0, t0), b = cam3(u1, v1, t1), wa = 1, wb = 1;
      if (persp) {
         var da = K + a[2], db = K + b[2], f;
         if (da <= near && db <= near) return null;
         if (da <= near) { f = (near - da) / (db - da); a = [a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, near - K]; da = near; }
         else if (db <= near) { f = (near - db) / (da - db); b = [b[0] + (a[0] - b[0]) * f, b[1] + (a[1] - b[1]) * f, near - K]; db = near; }
         wa = K / da; wb = K / db;
      }
      return cpSvClipSegment(scx + sc * a[0] * wa, scy + sc * a[1] * wa, scx + sc * b[0] * wb, scy + sc * b[1] * wb, clip);
   }
   // ¿la camara esta por delante del plano de la foto? (en ortografica, ¿mira hacia el fondo?)
   var front = persp ? (K * cy * cp > Cz * flat) : (cy * cp > 0);
   return { mode: "perspective", scale: sc, f0: V.f0, K: K, K0: K0, persp: persp, near: near, zoom: V.zoom, pose: P, view: V, cx: scx, cy: scy,
            photo: null, plot: null, wn: wn, hn: hn, depth: D, rect: rect, clip: clip, front: front,
            right: [cy, 0, sy], up: [-sy * sp, cp, cy * sp], fwd: [-sy * cp, -sp, cy * cp],
            px: px, seg: seg, onPhoto: function(u, v) { return px(u, v, 0); } };
}

// EL ENCAJE de la caja en el lienzo. `mode` = "perspective" (la camara de arriba) | "side" (el corte lateral).
//   rect      { x, y, w, h } del lienzo donde cabe el dibujo
//   view      la vista de la camara (solo en perspectiva)
//   win       { zoom, centre } (solo de lado): la ventana del fondo que se enseña (`cpSvSideWindow`)
// En "side" devuelve { mode, px( u, v, t ), scale, photo: { x, y, w, h } (la foto de frente),
//                      plot: { x, y, w, h } (el corte), wn, hn }
function cpSvDistFit(mode, model, rect, view, sideGap, win) {
   if (mode !== "side") return cpSvDistCam(model, rect, view);
   var wn = model.wn, hn = model.hn, W = cpSvSideWindow(win ? win.zoom : 1, win ? win.centre : 0.5), span = W.t1 - W.t0;
   // la foto de frente a la izquierda; el corte, a su derecha, con su mismo alto
   var gap = (sideGap > 0) ? sideGap : 16;
   var ph = Math.max(20, Math.min(rect.h, (rect.w * CP_SV.SIDE_PHOTO) * hn / wn)), pw = ph * wn / hn;
   // (pegados ARRIBA, no centrados: lo que sobra de alto es para las filas de placas que cuelgan debajo)
   var photo = { x: rect.x, y: rect.y, w: pw, h: ph };
   var plot = { x: rect.x + pw + gap, y: photo.y, w: Math.max(40, rect.w - pw - gap), h: ph };
   // (con zoom, el corte enseña la ventana `win` del fondo: lo que cae fuera no se ve —`ok` false— y `tx` da el pixel de un fondo)
   function tx(t) { return plot.x + (t - W.t0) / span * plot.w; }
   return { mode: "side", scale: ph / hn, photo: photo, plot: plot, wn: wn, hn: hn, depth: 0, zoom: 1, view: null, rect: rect, front: true, win: W, tx: tx,
            px: function(u, v, t) { return { x: tx(t), y: plot.y + (v / hn + 0.5) * plot.h, z: t, w: 1, ok: (t >= W.t0 - 1e-9 && t <= W.t1 + 1e-9) }; },
            seg: function(u0, v0, t0, u1, v1, t1) { return { x1: tx(t0), y1: plot.y + (v0 / hn + 0.5) * plot.h, x2: tx(t1), y2: plot.y + (v1 / hn + 0.5) * plot.h }; },
            onPhoto: function(u, v) { return { x: photo.x + (u / wn + 0.5) * photo.w, y: photo.y + (v / hn + 0.5) * photo.h, z: 0, w: 1, ok: true }; } };
}

// EL ZOOM DEL CORTE LATERAL (R24, 14-oct-2026; peticion de Nino: una barra deslizadora). El corte enseña una VENTANA del
// fondo: de t0 a t1 (0 = la foto, 1 = el final de la escala), de ancho 1 / zoom, centrada donde se diga y sin salirse.
function cpSvSideWindow(zoom, centre) {
   var z = Math.max(1, Math.min(CP_SV.SIDE_ZOOM_MAX, (typeof zoom === "number" && isFinite(zoom)) ? zoom : 1)), half = 0.5 / z;
   var c = Math.max(half, Math.min(1 - half, (typeof centre === "number" && isFinite(centre)) ? centre : 0.5));
   return { zoom: z, centre: c, t0: c - half, t1: c + half };
}
// La rueda sobre el corte: el fondo que hay bajo el cursor (`frac`: 0 = el borde izquierdo del corte, 1 = el derecho) NO se mueve.
function cpSvSideZoomAt(win, factor, frac) {
   var W = cpSvSideWindow(win ? win.zoom : 1, win ? win.centre : 0.5), z1 = Math.max(1, Math.min(CP_SV.SIDE_ZOOM_MAX, W.zoom * factor));
   var f = Math.max(0, Math.min(1, (typeof frac === "number" && isFinite(frac)) ? frac : 0.5)), tc = W.t0 + f * (W.t1 - W.t0);
   return cpSvSideWindow(z1, tc - f / z1 + 0.5 / z1);
}
// Arrastrar el corte: `dFrac` = lo arrastrado, en anchos del corte (hacia la derecha se ve lo de mas cerca).
function cpSvSidePan(win, dFrac) {
   var W = cpSvSideWindow(win ? win.zoom : 1, win ? win.centre : 0.5);
   return cpSvSideWindow(W.zoom, W.centre - dFrac / W.zoom);
}
// LA BARRA DE ZOOM, EN EL CORTE: se amplia HACIA DONDE ESTAN LAS COSAS (14-oct-2026, vuelta 3: con el borde cercano
// quieto, a 4 aumentos el corte enseñaba un tramo casi vacio). `anchor` = el fondo que manda (el objeto elegido o, sin
// ninguno, la mediana de los pintados); `ts` = los fondos de los objetos. Si el ancla se ve, NO SE MUEVE de su sitio en el
// corte; si no, la ventana se centra en ella. Y NUNCA queda vacia habiendo objetos: si en la ventana no cae ninguno, se
// centra en el mas cercano a su centro.
function cpSvSideZoomTo(win, zoom, anchor, ts) {
   var W = cpSvSideWindow(win ? win.zoom : 1, win ? win.centre : 0.5), out, i;
   var a = (typeof anchor === "number" && isFinite(anchor)) ? Math.max(0, Math.min(1, anchor)) : W.centre;
   if (a >= W.t0 - 1e-9 && a <= W.t1 + 1e-9) out = cpSvSideZoomAt(W, zoom / W.zoom, (a - W.t0) / (W.t1 - W.t0));
   else out = cpSvSideWindow(zoom, a);
   if (ts && ts.length > 0) {
      var any = false, near = -1, dn = Infinity;
      for (i = 0; i < ts.length; ++i) {
         if (ts[i] >= out.t0 && ts[i] <= out.t1) { any = true; break; }
         var d = Math.abs(ts[i] - out.centre);
         if (d < dn) { dn = d; near = i; }
      }
      if (!any && near >= 0) out = cpSvSideWindow(out.zoom, ts[near]);
   }
   return out;
}
// La mediana de una lista de numeros (0.5 si esta vacia): el ancla de la barra cuando no hay nada elegido.
function cpSvMedian(list) {
   if (!list || list.length === 0) return 0.5;
   var a = list.slice().sort(function(p, q) { return p - q; }), n = a.length;
   return (n & 1) ? a[n >> 1] : (a[n / 2 - 1] + a[n / 2]) / 2;
}
// UN SOLO ZOOM, DOS MANERAS DE MOVERLO: la barra va en pasos (0…steps) y el zoom en proporcion (cada paso multiplica lo mismo).
function cpSvZoomToSlider(zoom, zMin, zMax, steps) {
   var z = Math.max(zMin, Math.min(zMax, zoom));
   return Math.max(0, Math.min(steps, Math.round(steps * Math.log(z / zMin) / Math.log(zMax / zMin))));
}
function cpSvSliderToZoom(value, zMin, zMax, steps) { return zMin * Math.pow(zMax / zMin, Math.max(0, Math.min(steps, value)) / steps); }
// LA DISTANCIA DE UN FONDO: la inversa de `scale.t` (por biseccion: vale para la logaritmica y para los tramos).
// t <= 0 (delante de la foto: en casa) da 0; t >= 1, el final de la escala.
function cpSvDistPcAt(scale, t) {
   if (!(t > 0) || !scale || typeof scale.t !== "function") return 0;
   var hi = (scale.hi > 0) ? scale.hi : 1e10, lo = hi * 1e-14;
   if (t >= scale.t(hi)) return hi;
   for (var i = 0; i < 80; ++i) { var mid = Math.sqrt(lo * hi); if (scale.t(mid) < t) lo = mid; else hi = mid; }
   return Math.sqrt(lo * hi);
}
// LAS CIFRAS DEL CORTE CON ZOOM. Sin zoom, las de la escala (una por decada, o las de cada tramo). Con zoom casi nunca
// cae una decada dentro de la ventana: se ponen cifras REDONDAS de la serie 1 - 2 - 5 (en la unidad que se enseña) que
// caen dentro; y si la ventana es mas estrecha que eso (menos de un factor 3), pasos redondos lineales. `want` = cuantas
// hacen falta para dar las de la escala por buenas. Devuelve [ { pc, t, value } ], de cerca a lejos, todas DENTRO.
// `maxN` (opcional): cuantas CABEN. Si salen mas, se quedan una de cada dos, o de cada tres…: SIEMPRE una serie regular
// (antes quien pintaba se saltaba la que pisaba a su vecina y quedaba «100 · 150 · 250»: visto en la captura de la vuelta 2).
function cpSvSideTicks(scale, win, want, maxN) {
   var W = cpSvSideWindow(win ? win.zoom : 1, win ? win.centre : 0.5), n = (want > 0) ? want : 3, k = cpSfDistanceIn(1, scale.unit), out = [], i;
   function inside(t) { return t >= W.t0 - 1e-9 && t <= W.t1 + 1e-9; }
   function thin(list) {
      if (!(maxN >= 1) || list.length <= maxN) return list;
      var step = Math.ceil(list.length / maxN), kept = [];
      for (var q = 0; q < list.length; q += step) kept.push(list[q]);
      return kept;
   }
   for (i = 0; i < scale.ticks.length; ++i) if (inside(scale.ticks[i].t)) out.push(scale.ticks[i]);
   if (W.zoom <= 1 + 1e-9 || out.length >= n) return thin(out);
   // (por debajo de la primera decada de la escala logaritmica no hay cifras: ese tramo, pegado a la foto, es lineal y corto)
   var v0 = cpSvDistPcAt(scale, Math.max(W.t0, 1e-4)) * k, v1 = cpSvDistPcAt(scale, W.t1) * k, vals = [];
   if (scale.mode !== "segments" && scale.lo > 0) v0 = Math.max(v0, scale.lo * k * (1 - 1e-9));
   if (!(v1 > v0) || !(v0 > 0)) return out;
   if (scale.mode === "segments" || v1 / v0 < 3) vals = cpSvNiceTicks(v0, v1, n + 1);
   else {
      for (var e = Math.floor(Math.log(v0) / Math.LN10); e <= Math.ceil(Math.log(v1) / Math.LN10); ++e)
         for (var m = 0; m < 3; ++m) vals.push([1, 2, 5][m] * Math.pow(10, e));
   }
   out = [];
   for (i = 0; i < vals.length; ++i) {
      var v = Number(vals[i].toPrecision(12)), t = scale.t(v / k);
      if (v > 0 && inside(t) && (out.length === 0 || v > out[out.length - 1].value * (1 + 1e-9))) out.push({ pc: v / k, t: t, value: v });
   }
   return thin(out);
}

// MOVER LA VISTA. Las tres devuelven una vista nueva (no tocan la que reciben).
// GIRAR: `view` es la vista al EMPEZAR el arrastre y (dx, dy) lo arrastrado desde entonces.
function cpSvDistOrbit(view, dx, dy) {
   var v = cpSvDistView(view);
   v.yaw = v.yaw - dx * CP_SV.ORBIT_X; v.pitch = v.pitch + dy * CP_SV.ORBIT_Y;
   v.f0 = 0; v.cx = NaN; v.cy = NaN;          // (el encaje era el de la pose de antes: el de la nueva lo pone la camara)
   return cpSvDistView(v);
}
// DESPLAZAR: el pivote se mueve en el plano de la camara, de modo que lo que esta a su altura sigue
// al cursor pixel a pixel. `fit` es la camara al empezar el arrastre.
function cpSvDistPan(fit, dx, dy) {
   var v = cpSvDistView(fit.view), k = 1 / fit.scale, R = fit.right, U = fit.up, fl = (v.flat > 1e-6) ? v.flat : 1;
   v.ox -= (dx * R[0] + dy * U[0]) * k; v.oy -= (dx * R[1] + dy * U[1]) * k; v.oz -= (dx * R[2] + dy * U[2]) * k / fl;
   return cpSvDistView(v);
}
// LA RUEDA. Hacia dentro (`factor` > 1), la camara avanza HACIA lo que hay bajo el cursor (sx, sy):
// ese punto no se mueve en pantalla, y el pivote se le acerca (al tercer golpe de rueda ya se gira
// alrededor de lo que se mira). `zHint` = la profundidad zc del objeto bajo el cursor (`proj.pz`);
// sin el, el punto del plano del pivote. Hacia fuera se deshace el camino: el pivote vuelve al
// centro de la caja a la vez que el zoom vuelve a 1.
function cpSvDistZoomAt(fit, factor, sx, sy, zHint) {
   var v = cpSvDistView(fit.view), z0 = v.zoom, z1 = Math.max(CP_SV.DIST_ZOOM_MIN, Math.min(CP_SV.DIST_ZOOM_MAX, z0 * factor)), r = z1 / z0;
   if (r > 1) {
      var zq = (typeof zHint === "number" && isFinite(zHint) && (!fit.persp || fit.K + zHint > fit.near)) ? zHint : 0;
      var kk = fit.persp ? (fit.K + zq) / (fit.scale * fit.K) : 1 / fit.scale;
      var xq = (sx - fit.cx) * kk, yq = (sy - fit.cy) * kk, m = 1 - 1 / r, R = fit.right, U = fit.up, W = fit.fwd, fl = (v.flat > 1e-6) ? v.flat : 1;
      v.ox += m * (xq * R[0] + yq * U[0] + zq * W[0]);
      v.oy += m * (xq * R[1] + yq * U[1] + zq * W[1]);
      v.oz += m * (xq * R[2] + yq * U[2] + zq * W[2]) / fl;
   } else if (r < 1 && z0 > 1) {
      var g = Math.max(0, (z1 - 1) / (z0 - 1));
      v.ox *= g; v.oy *= g; v.oz *= g;
   }
   v.zoom = z1;
   return cpSvDistView(v);
}

// ENTRE DOS VISTAS: la camara que va de `a` a `b` (las dos COMPLETAS: las de `fit.view`). El giro
// va por el camino corto; el zoom y la escala, en proporcion (no en diferencia); `sFlat` (si se da)
// es el avance del aplastado, que puede ir a otro ritmo que el giro. Con s = 0 da `a` y con 1, `b`.
function cpSvDistViewLerp(a, b, s, sFlat) {
   var A = cpSvDistView(a), B = cpSvDistView(b), f = (sFlat === undefined) ? s : sFlat;
   if (s <= 0 && f <= 0) return A;
   if (s >= 1 && f >= 1) return B;
   var dyaw = B.yaw - A.yaw;
   if (dyaw > 180) dyaw -= 360;
   if (dyaw < -180) dyaw += 360;
   function L(p, q) { return p + (q - p) * s; }
   function G(p, q) { return (p > 0 && q > 0) ? Math.exp(L(Math.log(p), Math.log(q))) : L(p, q); }
   return cpSvDistView({ yaw: A.yaw + dyaw * s, pitch: L(A.pitch, B.pitch), zoom: G(A.zoom, B.zoom), ox: L(A.ox, B.ox), oy: L(A.oy, B.oy), oz: L(A.oz, B.oz),
                         flat: A.flat + (B.flat - A.flat) * f, f0: G(A.f0, B.f0), cx: L(A.cx, B.cx), cy: L(A.cy, B.cy) });
}

// EL ESTADO «FOTO»: la foto encajada en `rect`, y la vista de la camara que la enseña ASI —de
// frente y con la caja aplastada sobre ella—: cada objeto cae justo en su sitio de la imagen.
function cpSvPhotoRect(model, rect) {
   var k = Math.min(rect.w / model.wn, rect.h / model.hn), w = model.wn * k, h = model.hn * k;
   return { x: rect.x + (rect.w - w) / 2, y: rect.y + (rect.h - h) / 2, w: w, h: h };
}
function cpSvDistPhotoView(model, rect) {
   var r = cpSvPhotoRect(model, rect);
   return cpSvDistView({ yaw: 0, pitch: 0, zoom: 1, ox: 0, oy: 0, oz: -CP_SV.DEPTH / 2, flat: 0, f0: r.w / model.wn, cx: r.x + r.w / 2, cy: r.y + r.h / 2 });
}

// LOS RECORTES. Un objeto EXTENSO (una planetaria, una galaxia, un cumulo) no es un punto: se pinta con SU
// TROZO DE LA FOTO —lo que se ve en el visor—, en un plano paralelo a la foto, a la distancia del objeto y con
// el mismo sitio (u, v) y el mismo tamaño que tiene en la foto. Por eso, de frente o con la caja aplastada (el
// estado FOTO), cae EXACTAMENTE sobre si mismo; y al abrirse la caja «sale» de la foto hacia su distancia.
// (Peticion de Nino, 13-oct-2026: «la nebulosa aparece pero como un punto. ¿La podrias representar con la imagen
// tal y como la tengo yo en pantalla?»)
// El trozo de foto de un objeto: un cuadrado de CUT_MARGIN radios alrededor de su centro, recortado al encuadre.
// Devuelve { u0, v0, u1, v1, r (el radio del recorte, en u) } o null si el catalogo no dice lo que mide.
// (Una NEBULOSA trae su trozo hecho, `rect`: su huella en la foto, que puede ser la foto entera.)
// El id de la primera caja de `rects` ({ u0, v0, u1, v1, id }) que contiene (u, v) —con `half` > 0: en la que cae al menos la
// MITAD del cuadrado de semilado `half` centrado en (u, v), recortado a la foto (`wn` x `hn`, como el recorte de verdad)—, o false.
function cpSvInRects(rects, u, v, half, wn, hn) {
   var a0 = u - half, a1 = u + half, b0 = v - half, b1 = v + half;
   if (half > 0 && wn > 0 && hn > 0) { a0 = Math.max(a0, -wn / 2); a1 = Math.min(a1, wn / 2); b0 = Math.max(b0, -hn / 2); b1 = Math.min(b1, hn / 2); }
   for (var i = 0; rects && i < rects.length; ++i) {
      var r = rects[i];
      if (half > 0) {
         var ov = Math.max(0, Math.min(a1, r.u1) - Math.max(a0, r.u0)) * Math.max(0, Math.min(b1, r.v1) - Math.max(b0, r.v0));
         if (a1 > a0 && b1 > b0 && ov >= 0.5 * (a1 - a0) * (b1 - b0)) return r.id;
      } else if (u >= r.u0 && u <= r.u1 && v >= r.v0 && v <= r.v1) return r.id;
   }
   return false;
}
function cpSvCutoutRect(ob, wn, hn) {
   if (!ob || !(ob.ext > 0)) return null;
   if (ob.rect) {
      var a0 = Math.max(-wn / 2, ob.rect.u0), a1 = Math.min(wn / 2, ob.rect.u1), b0 = Math.max(-hn / 2, ob.rect.v0), b1 = Math.min(hn / 2, ob.rect.v1);
      return (a1 > a0 && b1 > b0) ? { u0: a0, v0: b0, u1: a1, v1: b1, r: ob.ext } : null;
   }
   var r = ob.ext * CP_SV.CUT_MARGIN;
   var u0 = Math.max(-wn / 2, ob.u - r), u1 = Math.min(wn / 2, ob.u + r), v0 = Math.max(-hn / 2, ob.v - r), v1 = Math.min(hn / 2, ob.v + r);
   if (!(u1 > u0) || !(v1 > v0)) return null;
   return { u0: u0, v0: v0, u1: u1, v1: v1, r: r };
}
// CUALES SE PINTAN con su recorte: los que el catalogo mide, se ven, y en pantalla tienen al menos `minPx`
// de radio; si son muchos, los CUT_MAX mas grandes en pantalla (el resto se queda en su simbolo). Devuelve
// [ { index, u0, v0, u1, v1, r, t, rPx (su radio en pantalla) } ], del mas grande al mas pequeño.
var CP_SV_CUT_NO_CLUSTER = true;      // (28-oct-2026, D1) la costura del rojo: apagado, los cumulos y asociaciones de SIMBAD vuelven a llevar recorte
function cpSvCutouts(model, proj, fit, minPx, max) {
   var out = [], lim = (max > 0) ? max : CP_SV.CUT_MAX, floor = (minPx > 0) ? minPx : CP_SV.CUT_MIN_PX;
   if (fit.mode !== "perspective") return out;
   for (var i = 0; i < model.objects.length; ++i) {
      var ob = model.objects[i];
      if (!(ob.ext > 0) || !proj.vis[i]) continue;
      if (ob.unseen === true) continue;          // (24-oct-2026, H2: lo que la foto no enseña no tiene trozo de foto que recortar ni deja hueco)
      // UN CUMULO CUYAS ESTRELLAS SE PINTAN una a una no lleva recorte: ya esta dibujado, y su trozo de foto —un disco
      // opaco en mitad de la nube de miembros— tapaba a los que quedan detras de su plano (visto el 13-oct-2026 en M 13:
      // un disco gris con un canto recto que partia el cumulo, y la pantalla entera gris con la camara dentro).
      if (ob.kind === "cluster" && model.counts.members > 0) continue;
      // (28-oct-2026, D1 de Nino) UN CUMULO O UNA ASOCIACION DE SIMBAD tampoco: su luz son estrellas, que ya van como puntos, y su trozo
      // de foto se quedaba con LA NEBULOSA de alrededor —en Collinder 34, SAI 24 daba dos manchas verdes saturadas: tests/c3_neb_c34_probe.log—
      if (CP_SV_CUT_NO_CLUSTER === true && ob.kind !== "cluster" && (ob.cls === "star-cluster" || ob.cls === "association")) continue;
      var c = cpSvCutoutRect(ob, model.wn, model.hn);
      if (c === null) continue;
      var rPx = ob.ext * fit.scale * proj.pw[i];
      if (!(rPx >= floor)) continue;
      out.push({ index: i, u0: c.u0, v0: c.v0, u1: c.u1, v1: c.v1, r: c.r, t: proj.tt[i], rPx: rPx });
   }
   out.sort(function(a, b) { return (b.rPx - a.rPx) || (a.index - b.index); });
   if (out.length > lim) out.length = lim;
   return out;
}
// COMO SE PINTA un recorte: de UNA pieza, con UNA afin —la que lleva su centro a su sitio y sus dos ejes a
// donde caen de verdad los puntos medios de sus lados—. No con una malla como la foto: el recorte tiene el
// borde TRANSLUCIDO, y translucido troceado no hay manera (si las celdas se solapan, lo doblado sale mas
// claro: una rejilla de cuadros; si no, quedan rendijas negras; medido las dos veces en el test 4.5). Con
// una sola pieza no hay costura. Lo que se pierde es la perspectiva DENTRO del recorte (sus esquinas, que
// son transparentes, se apartan unos pixeles de donde irian), y solo cuando se mira muy de lado y de cerca;
// de frente y en el estado FOTO la afin es exacta: el recorte cae sobre si mismo en la foto.
// `rect` = { u0, v0, u1, v1 } (el trozo de foto que lleva el bitmap), a la profundidad t. Devuelve
// { x, y (a donde va la esquina u0, v0), ax, ay (por unidad de u), bx, by (por unidad de v), quad (sus cuatro
// esquinas en pantalla) } o null si el recorte toca el plano de la camara.
// EL RECORTE MIRA A LA CAMARA (14-oct-2026, vuelta 3; revision visual: «se delata como LAMINA: la planetaria se vuelve
// elipse y la galaxia una astilla de canto»). `face` (0…1): 0 = el plano paralelo a la foto de siempre; 1 = un CARTEL,
// siempre de frente, del tamaño que le toca a su distancia (la mayor de las dos escalas de la afin: la del eje que el
// escorzo no acorta) y derecho como en la foto (u hacia la derecha, v hacia abajo). De frente las dos cosas son LA MISMA:
// por eso en el estado FOTO sigue cayendo sobre si mismo. `cpSvCutoutFace( fit )` da el `face` que toca: 0 con la caja
// aplastada sobre la foto y 1 desde que se ha abierto CUT_FACE.
function cpSvCutoutFace(fit) {
   var f = (fit && fit.view && typeof fit.view.flat === "number") ? fit.view.flat : 1, r = Math.max(0, Math.min(1, f / CP_SV.CUT_FACE));
   return r * r * (3 - 2 * r);
}
function cpSvCutoutAffine(fit, rect, t, face) {
   var um = (rect.u0 + rect.u1) / 2, vm = (rect.v0 + rect.v1) / 2, c = fit.px(um, vm, t);
   var l = fit.px(rect.u0, vm, t), r = fit.px(rect.u1, vm, t), a = fit.px(um, rect.v0, t), b = fit.px(um, rect.v1, t);
   if (!(c.ok && l.ok && r.ok && a.ok && b.ok)) return null;
   var du = rect.u1 - rect.u0, dv = rect.v1 - rect.v0;
   if (!(du > 0) || !(dv > 0)) return null;
   var ax = (r.x - l.x) / du, ay = (r.y - l.y) / du, bx = (b.x - a.x) / dv, by = (b.y - a.y) / dv;
   // la mayor escala de la afin (su mayor valor singular): lo que mide una unidad de la foto a esa distancia, sin escorzo
   var E = (ax + by) / 2, Fq = (ax - by) / 2, G = (ay + bx) / 2, H = (ay - bx) / 2, smax = Math.sqrt(E * E + H * H) + Math.sqrt(Fq * Fq + G * G);
   var f = (face > 0) ? Math.min(1, face) : 0;
   if (f > 0) { ax += (smax - ax) * f; ay += (0 - ay) * f; bx += (0 - bx) * f; by += (smax - by) * f; }
   var x = c.x - ax * du / 2 - bx * dv / 2, y = c.y - ay * du / 2 - by * dv / 2;
   return { x: x, y: y, ax: ax, ay: ay, bx: bx, by: by, scale: smax,
            quad: [{ x: x, y: y }, { x: x + ax * du, y: y + ay * du }, { x: x + ax * du + bx * dv, y: y + ay * du + by * dv }, { x: x + bx * dv, y: y + by * dv }] };
}

// EL RECORTE ES SOLO EL OBJETO (14-oct-2026). Hasta aqui el recorte era un disco de foto con el borde desvanecido: se
// llevaba consigo el fondo de cielo y las estrellas de primer plano, y a su distancia parecia un parche gris, no una
// galaxia flotando. Ahora la transparencia sale del BRILLO SOBRE EL FONDO LOCAL:
//   · el fondo: la MEDIANA por canal de la corona exterior del recorte (de MATTE_RING del radio hacia fuera, esquinas
//     incluidas), y su ruido, la desviacion robusta (1,4826 · MAD) de esa misma corona;
//   · la transparencia: una rampa suave del exceso sobre el fondo —en sigmas, el mayor de los tres canales (una
//     planetaria casi solo se ve en uno), alisado 5 × 5— entre MATTE_LO y MATTE_HI sigmas, POR la caida radial de
//     siempre (opaco hasta `inner`, a 0 en el borde);
//   · el color: el del pixel MENOS el fondo (sin eso, el borde translucido deja un velo gris);
//   · las ESTRELLAS DE PRIMER PLANO que se le digan (`stars`: las de Gaia que caen dentro y estan a OTRA distancia; ya
//     se pintan como puntos en su sitio) se borran antes: su disco —hasta donde su perfil deja de caer, sin pasar de
//     `rmax`— se rellena con la mediana del anillo que lo rodea.
//   r, g, b   los canales del recorte (0…255), de w × h         geo = { cx, cy, rx, ry (px), inner (0…1) }
//   stars     [ { x, y, rmax } ] (px del recorte)
//   · las ISLAS (manchas sueltas de transparencia: una estrella al lado del objeto) se quitan (`islands`: cuantas), y
//     `shine` = { x0, y0, x1, y1 } (px) es la caja de LO QUE BRILLA (la que contiene MATTE_SHINE de la transparencia).
// Devuelve { a (0…1), r, g, b (con el fondo restado, 0…255), gain (por cuanto multiplicarlos: ver abajo), bg: [ r, g, b ], sigma: [ … ], removed, flat (true = la
// corona no tiene ruido medible: una foto de un solo color; no hay con que decidir y la transparencia es la radial) }.
function cpSvCutoutMatte(r, g, b, w, h, geo, stars) {
   var N = w * h, C = [new Float32Array(N), new Float32Array(N), new Float32Array(N)], src = [r, g, b], i, c, x, y, k;
   for (c = 0; c < 3; ++c) for (i = 0; i < N; ++i) C[c][i] = src[c][i];
   var rho = new Float32Array(N), inner = Math.max(0, Math.min(0.98, geo.inner));
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var dx = (x + 0.5 - geo.cx) / geo.rx, dy = (y + 0.5 - geo.cy) / geo.ry; rho[y * w + x] = Math.sqrt(dx * dx + dy * dy); }
   // (ordenacion NATIVA de numeros: con la funcion de comparar, la corona de un recorte de 1 024 px tardaba medio segundo)
   function medianOf(list) { var a = new Float32Array(list); a.sort(); var n = a.length; return (n === 0) ? 0 : (n & 1) ? a[n >> 1] : (a[n / 2 - 1] + a[n / 2]) / 2; }
   // el fondo y su ruido, de la corona
   function ring() {
      var bg = [0, 0, 0], sg = [0, 0, 0], n = 0;
      for (var ch = 0; ch < 3; ++ch) {
         var v = [], j;
         for (j = 0; j < N; ++j) if (rho[j] >= CP_SV.MATTE_RING) v.push(C[ch][j]);
         n = v.length;
         bg[ch] = medianOf(v);
         for (j = 0; j < v.length; ++j) v[j] = Math.abs(v[j] - bg[ch]);
         sg[ch] = 1.4826 * medianOf(v);
      }
      return { bg: bg, sigma: sg, n: n };
   }
   var R0 = ring(), removed = 0, kept = 0;
   // las estrellas de primer plano, fuera
   function sample(ch, cx, cy, rad) {
      var v = [];
      for (var q = 0; q < 16; ++q) { var xx = Math.round(cx + rad * Math.cos(q * Math.PI / 8)), yy = Math.round(cy + rad * Math.sin(q * Math.PI / 8)); if (xx >= 0 && yy >= 0 && xx < w && yy < h) v.push(C[ch][yy * w + xx]); }
      return (v.length >= 4) ? medianOf(v) : NaN;
   }
   for (k = 0; stars && k < stars.length; ++k) {
      var S = stars[k], rmax = Math.max(2, Math.min(S.rmax, Math.min(w, h) / 4)), noise = Math.max(1, R0.sigma[0] + R0.sigma[1] + R0.sigma[2]);
      if (!(S.x >= 0 && S.y >= 0 && S.x < w && S.y < h)) continue;
      // su radio: hasta donde el perfil (la suma de los tres canales, mediana por anillo) deja de caer
      var prof = [], rr;
      for (rr = 1; rr <= rmax + 2; ++rr) prof.push(sample(0, S.x, S.y, rr) + sample(1, S.x, S.y, rr) + sample(2, S.x, S.y, rr));
      // (hasta donde su perfil llega al nivel de alrededor —el del anillo mas lejano—, no «hasta donde deja de caer»: una
      // estrella SATURADA tiene el centro plano, su perfil no cae en el primer pixel y no se borraba. Visto en NGC 1560: dos
      // estrellas brillantes de primer plano seguian sobre la galaxia como dos borrones.)
      var rad = rmax, floor = prof[prof.length - 1];
      // (…y ademas ha dejado de caer: sobre la ladera de una galaxia el perfil sigue bajando despacio hasta el anillo lejano y el
      // radio salia el doble de lo que mide la estrella)
      for (rr = 0; rr < prof.length - 1; ++rr) if (!(prof[rr] - floor > 2 * noise) && !(prof[rr] - prof[rr + 1] > 0.7 * noise)) { rad = Math.max(1, rr + 1); break; }
      var centre = C[0][Math.round(S.y) * w + Math.round(S.x)] + C[1][Math.round(S.y) * w + Math.round(S.x)] + C[2][Math.round(S.y) * w + Math.round(S.x)];
      if (!(centre - prof[Math.min(prof.length - 1, rad)] > 3 * noise)) continue;      // ahi no hay ninguna estrella que quitar
      if (rad > Math.max(6, CP_SV.MATTE_FILL_R * Math.min(w, h))) { ++kept; continue; }      // demasiado grande para rellenarla bien: se deja
      // EL ANILLO de alrededor (fuera de su halo): MATTE_FILL_N muestras, cada una la mediana de tres radios seguidos
      var RN = CP_SV.MATTE_FILL_N, rr2 = rad * 1.3 + 2, rx = new Float32Array(RN), ry = new Float32Array(RN), rv = [new Float32Array(RN), new Float32Array(RN), new Float32Array(RN)], lumR = [], okN = 0, q, c2;
      for (q = 0; q < RN; ++q) {
         var an = q * 2 * Math.PI / RN, good = true;
         rx[q] = S.x + rr2 * Math.cos(an); ry[q] = S.y + rr2 * Math.sin(an);
         for (c2 = 0; c2 < 3; ++c2) {
            var tri = [];
            for (var dr = 0; dr < 3; ++dr) { var sx3 = Math.round(S.x + (rr2 + dr) * Math.cos(an)), sy3 = Math.round(S.y + (rr2 + dr) * Math.sin(an)); if (sx3 >= 0 && sy3 >= 0 && sx3 < w && sy3 < h) tri.push(C[c2][sy3 * w + sx3]); }
            if (tri.length === 0) { good = false; rv[c2][q] = NaN; } else { tri.sort(function(p1, p2) { return p1 - p2; }); rv[c2][q] = tri[tri.length >> 1]; }
         }
         if (good) { lumR.push(rv[0][q] + rv[1][q] + rv[2][q]); ++okN; }
      }
      if (okN < RN * 0.6) { ++kept; continue; }
      // …sin lo que se sale (otra estrella en el anillo): fuera de la mediana ± 3 desviaciones robustas; si se salen muchas, no es fiable
      var lmed = medianOf(lumR), dev = [];
      for (q = 0; q < lumR.length; ++q) dev.push(Math.abs(lumR[q] - lmed));
      var lmad = Math.max(1.4826 * medianOf(dev), noise / 2), bad = 0, use = new Uint8Array(RN);
      for (q = 0; q < RN; ++q) { var lq = rv[0][q] + rv[1][q] + rv[2][q]; if (lq === lq && Math.abs(lq - lmed) <= 3 * lmad) use[q] = 1; else ++bad; }
      var srt = lumR.slice().sort(function(p1, p2) { return p1 - p2; }), spread = srt[Math.floor(0.9 * (srt.length - 1))] - srt[Math.floor(0.1 * (srt.length - 1))];
      if (bad > RN * CP_SV.MATTE_FILL_BAD || spread > CP_SV.MATTE_FILL_SPREAD * noise) { ++kept; continue; }
      // EL RELLENO: cada pixel, la media del anillo pesada por cercania (sigue el degradado de lo de alrededor), mas el GRANO
      // del cielo (el mismo ruido que tiene la foto: un parche sin grano se ve como un lunar liso). El borde, desvanecido.
      // (…HASTA EL ANILLO del que sale el relleno: si acababa en el radio de la estrella, entre ese radio y el anillo quedaba
      // su halo, y a 1:1 se veia un aro alrededor de cada parche)
      var fe = Math.max(1, 0.3 * rr2), fr = rr2 - fe, x0 = Math.max(0, Math.floor(S.x - rr2)), x1 = Math.min(w - 1, Math.ceil(S.x + rr2)), y0 = Math.max(0, Math.floor(S.y - rr2)), y1 = Math.min(h - 1, Math.ceil(S.y + rr2));
      for (y = y0; y <= y1; ++y) for (x = x0; x <= x1; ++x) {
         var d = Math.sqrt((x - S.x) * (x - S.x) + (y - S.y) * (y - S.y)), m = (d <= fr) ? 1 : (d >= rr2) ? 0 : (rr2 - d) / fe;
         if (m <= 0) continue;
         var ws = 0, acc = [0, 0, 0];
         for (q = 0; q < RN; ++q) { if (use[q] === 0) continue; var dq = (x - rx[q]) * (x - rx[q]) + (y - ry[q]) * (y - ry[q]) + 1, wq = 1 / (dq * Math.sqrt(dq)); ws += wq; acc[0] += wq * rv[0][q]; acc[1] += wq * rv[1][q]; acc[2] += wq * rv[2][q]; }
         for (c = 0; c < 3; ++c) {
            var grain = (cpSvHash01(y * w + x, 31 + c) + cpSvHash01(y * w + x, 57 + c) + cpSvHash01(y * w + x, 83 + c) - 1.5) * 2 * R0.sigma[c];
            C[c][y * w + x] = C[c][y * w + x] * (1 - m) + (acc[c] / ws + grain) * m;
         }
      }
      ++removed;
   }
   var R1 = (removed > 0) ? ring() : R0, bg = R1.bg, sg = R1.sigma, flat = !(R1.n >= 24 && (sg[0] > 1e-6 || sg[1] > 1e-6 || sg[2] > 1e-6));
   var A = new Float32Array(N), E0 = new Float32Array(N);
   if (!flat) {
      // (un canal sin ruido medible —saturado a 0, o una foto en un solo canal— no decide con una sigma de 0: la del que mas tenga)
      var smax = Math.max(sg[0], sg[1], sg[2]), s3 = [Math.max(sg[0], 0.25 * smax), Math.max(sg[1], 0.25 * smax), Math.max(sg[2], 0.25 * smax)];
      for (i = 0; i < N; ++i) E0[i] = Math.max((C[0][i] - bg[0]) / s3[0], (C[1][i] - bg[1]) / s3[1], (C[2][i] - bg[2]) / s3[2]);
   }
   var lo = CP_SV.MATTE_LO, hi = CP_SV.MATTE_HI;
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) {
      i = y * w + x;
      var p = rho[i], rad2 = (p <= inner) ? 1 : (p >= 1) ? 0 : (1 - p) / (1 - inner), al = 1;
      rad2 = rad2 * rad2 * (3 - 2 * rad2);
      if (!flat && rad2 > 0) {
         // el exceso, alisado 5 x 5 (un pixel de ruido suelto no se queda flotando, y el borde no sale a dientes)
         var sum = 0, cnt = 0;
         for (var yy2 = Math.max(0, y - 2); yy2 <= Math.min(h - 1, y + 2); ++yy2) for (var xx2 = Math.max(0, x - 2); xx2 <= Math.min(w - 1, x + 2); ++xx2) { sum += E0[yy2 * w + xx2]; ++cnt; }
         var e = (sum / cnt - lo) / (hi - lo);
         e = (e > 0) ? ((e < 1) ? e : 1) : 0;
         al = e * e * (3 - 2 * e);
      }
      A[i] = al * rad2;
   }
   // LAS ISLAS (14-oct-2026, vuelta 3): una estrella que cae en el cuadro del recorte pero FUERA del objeto brilla sobre el
   // fondo igual que el: se quedaba flotando a su lado como una mancha gris. Se etiquetan las manchas conexas de la
   // transparencia y solo se quedan la mayor (por luz: la suma de su transparencia) y las que lleguen a MATTE_ISLAND de ella
   // (un brazo suelto de una galaxia); el resto, a 0.
   var islands = 0;
   if (!flat) {
      // (las manchas se separan por su NUCLEO —transparencia de MATTE_CORE arriba—: con un umbral bajo, una estrella pegada
      // al borde de una planetaria quedaba unida a ella por el halo de las dos y no se quitaba. Visto en Abell 39.)
      var lab = new Int32Array(N), stack = new Int32Array(N), mass = [0], nl = 0, sp, j2, core = CP_SV.MATTE_CORE;
      for (i = 0; i < N; ++i) {
         if (lab[i] !== 0 || !(A[i] > core)) continue;
         ++nl; mass.push(0); sp = 0; stack[sp++] = i; lab[i] = nl;
         while (sp > 0) {
            j2 = stack[--sp]; mass[nl] += A[j2];
            var jx = j2 % w;
            if (jx > 0 && lab[j2 - 1] === 0 && A[j2 - 1] > core) { lab[j2 - 1] = nl; stack[sp++] = j2 - 1; }
            if (jx < w - 1 && lab[j2 + 1] === 0 && A[j2 + 1] > core) { lab[j2 + 1] = nl; stack[sp++] = j2 + 1; }
            if (j2 >= w && lab[j2 - w] === 0 && A[j2 - w] > core) { lab[j2 - w] = nl; stack[sp++] = j2 - w; }
            if (j2 < N - w && lab[j2 + w] === 0 && A[j2 + w] > core) { lab[j2 + w] = nl; stack[sp++] = j2 + w; }
         }
      }
      var best = 0;
      for (k = 1; k <= nl; ++k) if (mass[k] > best) best = mass[k];
      for (k = 1; k <= nl; ++k) if (mass[k] < CP_SV.MATTE_ISLAND * best) { mass[k] = -1; ++islands; }
      if (islands > 0) {
         // …cada mancha que se quita se lleva su halo: crece MATTE_GROW pixeles por lo que NO es nucleo de nadie
         // (…y lo que ELLA MISMA mide: una estrella brillante suelta tiene un halo tan ancho como su nucleo. Con un margen fijo de
         // 6 px quedaba de ella una media luna pegada a la galaxia: visto a 1:1 en NGC 1560.)
         var budget = new Int16Array(N), base = Math.max(2, Math.round(CP_SV.MATTE_GROW * Math.max(w, h) / 1024)), area = new Int32Array(nl + 1), front = [], nextF, gi, maxB = 0;
         for (i = 0; i < N; ++i) if (lab[i] > 0) ++area[lab[i]];
         for (i = 0; i < N; ++i) if (lab[i] > 0 && mass[lab[i]] < 0) { var bq = Math.min(32000, Math.max(base, Math.round(2.5 * Math.sqrt(area[lab[i]] / Math.PI)))); budget[i] = bq + 1; if (bq > maxB) maxB = bq; front.push(i); }
         for (gi = 0; gi < maxB && front.length > 0; ++gi) {
            nextF = [];
            for (k = 0; k < front.length; ++k) {
               j2 = front[k];
               var bj = budget[j2] - 1;
               if (bj <= 1) continue;
               var gx = j2 % w, nb = [(gx > 0) ? j2 - 1 : -1, (gx < w - 1) ? j2 + 1 : -1, (j2 >= w) ? j2 - w : -1, (j2 < N - w) ? j2 + w : -1];
               for (var q4 = 0; q4 < 4; ++q4) { var nn = nb[q4]; if (nn >= 0 && budget[nn] < bj && (lab[nn] === 0 || mass[lab[nn]] < 0)) { budget[nn] = bj; nextF.push(nn); } }
            }
            front = nextF;
         }
         for (i = 0; i < N; ++i) if (budget[i] > 0) A[i] = 0;
      }
      // …y lo que no llega a nucleo (un punto debil suelto) solo se queda si esta al lado de uno que se queda: a menos de
      // MATTE_REACH del lado del recorte. (Si nada llega a nucleo —un objeto muy tenue— no se toca nada.)
      if (best > 0) {
         var seen = new Uint8Array(N), reach = Math.max(3, Math.round(CP_SV.MATTE_REACH * Math.max(w, h))), fr2 = [], nx2, ri;
         for (i = 0; i < N; ++i) if (lab[i] > 0 && mass[lab[i]] >= 0) { seen[i] = 1; fr2.push(i); }
         for (ri = 0; ri < reach && fr2.length > 0; ++ri) {
            nx2 = [];
            for (k = 0; k < fr2.length; ++k) {
               j2 = fr2[k];
               var sx2 = j2 % w;
               if (sx2 > 0 && seen[j2 - 1] === 0) { seen[j2 - 1] = 1; nx2.push(j2 - 1); }
               if (sx2 < w - 1 && seen[j2 + 1] === 0) { seen[j2 + 1] = 1; nx2.push(j2 + 1); }
               if (j2 >= w && seen[j2 - w] === 0) { seen[j2 - w] = 1; nx2.push(j2 - w); }
               if (j2 < N - w && seen[j2 + w] === 0) { seen[j2 + w] = 1; nx2.push(j2 + w); }
            }
            fr2 = nx2;
         }
         for (i = 0; i < N; ++i) if (seen[i] === 0) A[i] = 0;
      }
   }
   // EL BORDE, LIMPIO (vuelta 4): la transparencia, alisada otra vez (5 × 5). Su borde seguia al ruido y salia RASGADO, con
   // jirones (visto a 1:1 en NGC 1560 y en NGC 6207).
   if (!flat) {
      var A2 = new Float32Array(N), q5;
      for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var s5 = 0, n5 = 0; for (q5 = Math.max(0, x - 2); q5 <= Math.min(w - 1, x + 2); ++q5) { s5 += A[y * w + q5]; ++n5; } A2[y * w + x] = s5 / n5; }
      for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var s6 = 0, n6 = 0; for (q5 = Math.max(0, y - 2); q5 <= Math.min(h - 1, y + 2); ++q5) { s6 += A2[q5 * w + x]; ++n6; } A[y * w + x] = s6 / n6; }
   }
   // LO QUE BRILLA: la caja que contiene MATTE_SHINE de la transparencia (por cada eje, de su percentil 5 al 95). Es lo que
   // la camara de un vuelo encuadra: el tamaño de catalogo de una galaxia debil es el doble de lo que se le ve.
   var shine = { x0: 0, y0: 0, x1: w, y1: h };
   {
      var mx = new Float64Array(w), my = new Float64Array(h), tot = 0, cut = (1 - CP_SV.MATTE_SHINE) / 2, acc;
      for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var av = A[y * w + x]; mx[x] += av; my[y] += av; tot += av; }
      if (tot > 0) {
         for (acc = 0, x = 0; x < w; ++x) { acc += mx[x]; if (acc >= cut * tot) { shine.x0 = x; break; } }
         for (acc = 0, x = w - 1; x >= 0; --x) { acc += mx[x]; if (acc >= cut * tot) { shine.x1 = x + 1; break; } }
         for (acc = 0, y = 0; y < h; ++y) { acc += my[y]; if (acc >= cut * tot) { shine.y0 = y; break; } }
         for (acc = 0, y = h - 1; y >= 0; --y) { acc += my[y]; if (acc >= cut * tot) { shine.y1 = y + 1; break; } }
      }
   }
   if (!flat) for (c = 0; c < 3; ++c) for (i = 0; i < N; ++i) C[c][i] = Math.max(0, C[c][i] - bg[c]);
   // LA GANANCIA: restar el fondo le quita al objeto el pedestal de cielo que llevaba en la foto, y una nebulosa debil (30
   // niveles sobre un cielo de 65) se quedaba casi negra, MAS OSCURA que el fondo de la escena (visto en Abell 39: un
   // agujero morado con halo oscuro). Se le devuelve su brillo: lo que hace falta para que lo mas brillante del objeto
   // (el percentil 99 de su canal mayor, donde es opaco) valga lo mismo que valia en la foto. Nunca menos de 1 ni mas de
   // MATTE_GAIN. Quien pinta pone el color como FONDO DE LA ESCENA + ganancia × exceso: asi el borde translucido nunca
   // oscurece lo que tiene detras.
   var gain = 1;
   if (!flat) {
      var top = [];
      for (i = 0; i < N; ++i) if (A[i] > 0.5) top.push(Math.max(C[0][i], C[1][i], C[2][i]));
      if (top.length >= 8) {
         top.sort(function(p1, q1) { return p1 - q1; });
         // (el percentil 80, no el 99: en el 99 mandan las estrellas que caen sobre el objeto, y el cuerpo —lo que se ve— quedaba a
         // la mitad de su brillo en la foto: medido a 1:1 en NGC 1560, 73 niveles contra 129)
         var p99 = top[Math.floor(CP_SV.MATTE_GAIN_AT * (top.length - 1))];
         if (p99 > 1) gain = Math.max(1, Math.min(CP_SV.MATTE_GAIN, (Math.max(bg[0], bg[1], bg[2]) + p99) / p99));
      }
   }
   return { a: A, r: C[0], g: C[1], b: C[2], bg: bg, sigma: sg, removed: removed, kept: kept, flat: flat, gain: gain, islands: islands, shine: shine };
}

// ---------------------------------------------------------------------------
// LA NEBULOSIDAD SIN ESTRELLAS (14-oct-2026). Cuando no hay StarXTerminator ni StarNet2 (o para las pruebas): una
// APERTURA MORFOLOGICA (minimo y despues maximo, en una ventana cuadrada de radio `R`) se queda con lo que es mas ancho
// que la ventana —la nebulosa— y pierde lo que es mas estrecho —las estrellas—. Donde la luz pasa de su apertura en
// mas de `K` ruidos SOBRE SU MEDIANA hay una estrella (21-oct-2026: antes se comparaba contra cero y, con una foto de poco ruido, tocaba el 86 % de los
// pixeles —medido en las Pleyades—: reescribia el grano de casi toda la imagen): ahi se pone la apertura (alisada 3 x 3, para que no salga a bloques), con el
// borde de la mascara desvanecido en un pixel. El ruido, la desviacion robusta de la luz menos su apertura (casi
// todo es cielo o nebulosa: la mayoria de los pixeles no son estrella). Una estrella mas gorda que la ventana (las
// muy brillantes) deja su halo: por eso es el ultimo recurso, y se dice cual se ha usado.
//   r, g, b  canales (Float32Array o Array, 0…255) de w × h      opts = { R, K } (por defecto NEB_STAR_R, NEB_STAR_K)
// Devuelve { r, g, b (nuevos), mask (0…1, la estrella quitada), frac (fraccion de pixeles tocados), sigma }.
function cpSvMinMax1d(src, dst, w, h, R, horiz, isMax) {
   for (var y = 0; y < h; ++y)
      for (var x = 0; x < w; ++x) {
         var pos = horiz ? x : y, lim = horiz ? w : h, step = horiz ? 1 : w, i = y * w + x, m = src[i];
         for (var d = 1; d <= R; ++d) {
            if (pos - d >= 0) { var a = src[i - d * step]; if (isMax ? a > m : a < m) m = a; }
            if (pos + d < lim) { var b = src[i + d * step]; if (isMax ? b > m : b < m) m = b; }
         }
         dst[i] = m;
      }
}
function cpSvOpening(src, w, h, R) {
   var N = w * h, t = new Float32Array(N), u = new Float32Array(N);
   cpSvMinMax1d(src, t, w, h, R, true, false); cpSvMinMax1d(t, u, w, h, R, false, false);
   cpSvMinMax1d(u, t, w, h, R, true, true); cpSvMinMax1d(t, u, w, h, R, false, true);
   return u;
}
function cpSvBox3(src, w, h) {
   var N = w * h, t = new Float32Array(N), o = new Float32Array(N), x, y, i;
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { i = y * w + x; t[i] = (src[(x > 0) ? i - 1 : i] + src[i] + src[(x < w - 1) ? i + 1 : i]) / 3; }
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { i = y * w + x; o[i] = (t[(y > 0) ? i - w : i] + t[i] + t[(y < h - 1) ? i + w : i]) / 3; }
   return o;
}
// El GRANO del cielo (aprox. gaussiano, desviacion 1; suma de tres uniformes) de un pixel y un canal, siempre el mismo: una tabla de
// 65536 valores (un hash entero, murmur3, con la multiplicacion de 32 bits en ES5) a la que se entra por (pixel, canal). Antes, tres
// `Math.sin` por pixel y canal: con millones de pixeles tocados era el 70 % del tiempo de `cpSvStarlessOwn`.
function cpSvImul(a, b) { return ((a & 0xffff) * b + ((((a >>> 16) * b) & 0xffff) << 16)) | 0; }
var CP_SV_GRAIN_T = null;
function cpSvGrain(i, c) {
   if (CP_SV_GRAIN_T === null) {
      CP_SV_GRAIN_T = new Float32Array(65536);
      for (var q = 0; q < 65536; ++q) {
         var hh = (q * 7919 + 1013904223) | 0, ss = 0, k;
         for (k = 0; k < 3; ++k) {
            hh = (hh + 0x9e3779b9 + k) | 0;
            hh ^= hh >>> 16; hh = cpSvImul(hh, 0x85ebca6b); hh ^= hh >>> 13; hh = cpSvImul(hh, 0xc2b2ae35); hh ^= hh >>> 16;
            ss += (hh >>> 0) / 4294967296;
         }
         CP_SV_GRAIN_T[q] = (ss - 1.5) * 2;
      }
   }
   return CP_SV_GRAIN_T[(i * 40503 + c * 21701) & 65535];
}
// La mediana de una muestra de 1 de cada `stride` valores (ordenar millones de pixeles para sacar una mediana era lo mas caro).
function cpSvMedianStride(a, n, stride) {
   var m = Math.max(1, Math.ceil(n / stride)), t = new Float32Array(m), k = 0;
   for (var i = 0; i < n; i += stride) t[k++] = a[i];
   t.sort();
   return t[m >> 1];
}
function cpSvStarlessOwn(r, g, b, w, h, opts) {
   var o = opts || {}, R = (typeof o.R === "number") ? o.R : CP_SV.NEB_STAR_R, K = (o.K > 0) ? o.K : CP_SV.NEB_STAR_K, N = w * h, i, c;
   var src = [r, g, b], L = new Float32Array(N);
   for (i = 0; i < N; ++i) L[i] = (r[i] + g[i] + b[i]) / 3;
   if (!(R >= 1)) return { r: new Float32Array(r), g: new Float32Array(g), b: new Float32Array(b), mask: new Float32Array(N), frac: 0, sigma: 0 };
   var LO = cpSvOpening(L, w, h, R), dv = new Float32Array(N);
   for (i = 0; i < N; ++i) dv[i] = L[i] - LO[i];
   var med = cpSvMedianStride(dv, N, 4), tmp = new Float32Array(N);
   for (i = 0; i < N; ++i) tmp[i] = Math.abs(dv[i] - med);
   var sigma = Math.max(0.5, 1.4826 * cpSvMedianStride(tmp, N, 4));
   // la mascara (y un pixel mas alrededor), desvanecida
   var m0 = new Float32Array(N);
   for (i = 0; i < N; ++i) if (dv[i] - med > K * sigma) m0[i] = 1;
   var m1 = new Float32Array(N);
   cpSvMinMax1d(m0, m1, w, h, 1, true, true); cpSvMinMax1d(m1, m0, w, h, 1, false, true);
   var mask = cpSvBox3(m0, w, h), out = [], touched = 0;
   for (c = 0; c < 3; ++c) {
      // (LA APERTURA DE UNA FOTO CON RUIDO SALE BAJA: el minimo se queda con lo mas oscuro del ruido. Medido en el sintetico
      // de V30: 1,7 niveles por debajo, y cada estrella dejaba un hoyo. Se le suma lo que se aparta de la foto donde NO hay
      // estrella —la mediana—, y el GRANO del cielo: un parche liso se ve como un lunar.)
      var op = cpSvBox3(cpSvOpening(src[c], w, h, R), w, h), dst = new Float32Array(N), off = [], res = [];
      for (i = 0; i < N; i += 3) if (mask[i] === 0) { off.push(src[c][i] - op[i]); }
      var offA = new Float32Array(off); offA.sort();
      var shift = (offA.length > 0) ? offA[offA.length >> 1] : 0;
      for (i = 0; i < offA.length; ++i) res.push(Math.abs(offA[i] - shift));
      var resA = new Float32Array(res); resA.sort();
      var gsig = (resA.length > 0) ? 1.4826 * resA[resA.length >> 1] : 0;
      for (i = 0; i < N; ++i) {
         if (mask[i] === 0) { dst[i] = src[c][i]; continue; }
         var grain = cpSvGrain(i, c) * gsig;
         dst[i] = src[c][i] * (1 - mask[i]) + (op[i] + shift + grain) * mask[i];
      }
      out.push(dst);
   }
   for (i = 0; i < N; ++i) if (mask[i] > 0) ++touched;
   return { r: out[0], g: out[1], b: out[2], mask: mask, frac: touched / N, sigma: sigma };
}

// ---------------------------------------------------------------------------
// LA FOTO SIN ESTRELLAS CON LA LISTA DE GAIA (21-oct-2026). Sin StarXTerminator ni StarNet2 la apertura morfologica
// (`cpSvStarlessOwn`) deja un cuadrado gris y un halo alrededor de las estrellas brillantes (medido a 1:1 contra StarXTerminator:
// tests/c3_starless_compare.js). Aqui se sabe DONDE esta cada estrella (Gaia) y cuanto mide la de la foto (la FWHM de la
// fotometria), y se hace lo que haria una persona con un pincel de clonar:
//   1 · de cada estrella, su PERFIL RADIAL (la mediana de 16 direcciones: ni las espigas de difraccion ni una vecina lo mueven) y
//       hasta que radio sube sobre el cielo de su alrededor (el cielo = la mediana del tercio exterior del perfil): ese es su
//       disco, mas un pixel. Una estrella tan debil que su centro no pasa de 3 ruidos sobre el cielo no se toca (no se ve).
//   2 · el disco (la union de todos) se RELLENA por difusion desde su borde (pirámide «pull-push» y despues algunas pasadas de
//       Laplace dentro del disco: una continuacion lisa de la nebulosidad de alrededor), y se le pone el grano del cielo;
//   3 · lo que queda (espigas de difraccion, estrellas sin Gaia, pixeles calientes) lo limpia la apertura de siempre.
//   r, g, b canales 0…255 de w × h · stars = [{ x, y, g }] en pixeles de ESAS matrices · fwhm = FWHM de las estrellas en esos pixeles
//       Para que una estrella sobre un PICO de nebulosidad no se coma la nebulosidad, el radio sale del ALA ajustada (perfil = c0 + c1·r + A·r^-2),
//       no del nivel del perfil (medido en el sintetico de tests/c3_starless_cases.js: sin el ajuste, 5 niveles de error en el pico).
//   opts = { K (ruidos sobre el cielo para dar por acabado el halo, 0,75), gMax (19), fit (false: radio solo por nivel), p (2, el ala), pre (la
//   apertura antes, no despues), tail (false: sin la apertura final), tailK (2), iters (40, pasadas de Laplace), RMAX (120) }
// Devuelve { r, g, b, mask (0…1), frac, sigma, info { stars, holes, ms } }. Determinista (el grano sale de `cpSvGrain`).
// ---------------------------------------------------------------------------
function cpSvSample(a, w, h, x, y) {
   if (x < 0) x = 0; else if (x > w - 1) x = w - 1;
   if (y < 0) y = 0; else if (y > h - 1) y = h - 1;
   var x0 = x | 0, y0 = y | 0, x1 = (x0 < w - 1) ? x0 + 1 : x0, y1 = (y0 < h - 1) ? y0 + 1 : y0, fx = x - x0, fy = y - y0;
   return (a[y0 * w + x0] * (1 - fx) + a[y0 * w + x1] * fx) * (1 - fy) + (a[y1 * w + x0] * (1 - fx) + a[y1 * w + x1] * fx) * fy;
}
// Rellena los pixeles de `hole` (1) de `src` con una continuacion lisa de los de alrededor. Devuelve una copia (lo que no es hoyo, igual).
function cpSvFillHoles(src, hole, w, h, iters) {
   var N = w * h, out = new Float32Array(src), S = new Float32Array(N), Wt = new Float32Array(N), i, x, y, any = false;
   for (i = 0; i < N; ++i) { var v = hole[i] ? 0 : 1; Wt[i] = v; S[i] = src[i] * v; if (!v) any = true; }
   if (!any) return out;
   var lv = [{ w: w, h: h, S: S, W: Wt }];
   for (;;) {
      var P = lv[lv.length - 1], full = true;
      for (i = 0; i < P.w * P.h; ++i) if (!(P.W[i] > 0)) { full = false; break; }
      if (full || (P.w <= 1 && P.h <= 1)) break;
      var nw = (P.w + 1) >> 1, nh = (P.h + 1) >> 1, nS = new Float32Array(nw * nh), nW = new Float32Array(nw * nh);
      for (y = 0; y < P.h; ++y) for (x = 0; x < P.w; ++x) { var q = (y >> 1) * nw + (x >> 1); nS[q] += P.S[y * P.w + x]; nW[q] += P.W[y * P.w + x]; }
      lv.push({ w: nw, h: nh, S: nS, W: nW });
   }
   // de lo grueso a lo fino: donde hay peso, su media; donde no, lo del nivel de arriba (bilineal)
   var val = null, l;
   for (l = lv.length - 1; l >= 0; --l) {
      var Lv = lv[l], cur = new Float32Array(Lv.w * Lv.h);
      for (y = 0; y < Lv.h; ++y) for (x = 0; x < Lv.w; ++x) {
         i = y * Lv.w + x;
         if (Lv.W[i] > 0) cur[i] = Lv.S[i] / Lv.W[i];
         else if (val !== null) cur[i] = cpSvSample(val, lv[l + 1].w, lv[l + 1].h, (x + 0.5) / 2 - 0.5, (y + 0.5) / 2 - 0.5);
         else cur[i] = 0;
      }
      val = cur;
   }
   // el nivel 0 ya trae lo de fuera intacto; dentro del hoyo, el relleno
   var idx = [];
   for (i = 0; i < N; ++i) if (hole[i]) { out[i] = val[i]; idx.push(i); }
   // unas pasadas de Laplace (Gauss-Seidel, en orden fijo) dentro del hoyo: quita los bloques de la piramide
   for (var it = 0; it < iters; ++it)
      for (var k = 0; k < idx.length; ++k) {
         i = idx[k]; x = i % w; y = (i - x) / w;
         out[i] = 0.25 * (out[(x > 0) ? i - 1 : i] + out[(x < w - 1) ? i + 1 : i] + out[(y > 0) ? i - w : i] + out[(y < h - 1) ? i + w : i]);
      }
   return out;
}
// Resta de cada estrella de `wl` ({ x, y, g, Rm }) el ala radial que se le ajusta fuera de su disco, en cada canal. Devuelve copias de los tres canales.
// El perfil: la mediana de 16 direcciones (no la mueven ni las espigas ni una vecina). El ala: y = c0 + A·r^-p, la p de 1 a 3 que menos error deja
// con A > 0; c0 es el cielo (y la nebulosidad radial de fondo: no se resta). Se resta A·(r^-p − Rend^-p) hasta donde baja a `wingK` ruidos.
function cpSvSubtractWings(src, w, h, wl, fw, sigma, o) {
   var N = w * h, wk = [new Float32Array(src[0]), new Float32Array(src[1]), new Float32Array(src[2])], wingK = (o.wingK > 0) ? o.wingK : 0.3, smp = new Float32Array(16), ang = [];
   var q, c, k, ri, i, j, RMAXW = (o.RMAX > 0) ? o.RMAX : 120;
   for (i = 0; i < 16; ++i) ang.push([Math.cos(2 * Math.PI * i / 16), Math.sin(2 * Math.PI * i / 16), Math.cos(2 * Math.PI * (i + 0.5) / 16), Math.sin(2 * Math.PI * (i + 0.5) / 16)]);
   wl.sort(function(p1, p2) { return p1.g - p2.g; });
   for (q = 0; q < wl.length; ++q) {
      var s = wl[q], Rbig = Math.min(RMAXW, Math.ceil(fw * (10 + 6 * Math.max(0, 12 - s.g)))), rin = Math.max(2, Math.ceil(s.Rm));
      if (Rbig < rin + 6) continue;
      for (c = 0; c < 3; ++c) {
         var ys = [], rs = [];
         for (ri = rin; ri <= Rbig; ++ri) {
            for (k = 0; k < 16; ++k) { var a = ang[k], odd = ri & 1; smp[k] = cpSvSample(wk[c], w, h, s.x + ri * (odd ? a[2] : a[0]), s.y + ri * (odd ? a[3] : a[1])); }
            for (k = 1; k < 16; ++k) { var vk = smp[k], jk = k - 1; while (jk >= 0 && smp[jk] > vk) { smp[jk + 1] = smp[jk]; --jk; } smp[jk + 1] = vk; }
            rs.push(ri); ys.push(0.5 * (smp[7] + smp[8]));
         }
         var n = rs.length, bestE = Infinity, bA = 0, bp = 0, pw;
         for (pw = 1; pw <= 3.001; pw += 0.25) {
            // minimos cuadrados de y = c0 + c1·r + A·r^-p (el termino lineal absorbe la pendiente de la nebulosidad de fondo: sin el, una mancha
            // de nebulosidad bajo la estrella se ajustaba como «ala» y se restaba)
            var s11 = n, s12 = 0, s13 = 0, s22 = 0, s23 = 0, s33 = 0, t1 = 0, t2 = 0, t3 = 0;
            for (j = 0; j < n; ++j) { var bb = Math.pow(rs[j], -pw), rr = rs[j]; s12 += rr; s13 += bb; s22 += rr * rr; s23 += rr * bb; s33 += bb * bb; t1 += ys[j]; t2 += ys[j] * rr; t3 += ys[j] * bb; }
            var det = s11 * (s22 * s33 - s23 * s23) - s12 * (s12 * s33 - s23 * s13) + s13 * (s12 * s23 - s22 * s13);
            if (!(Math.abs(det) > 1e-9)) continue;
            var A = (s11 * (s22 * t3 - t2 * s23) - s12 * (s12 * t3 - t2 * s13) + t1 * (s12 * s23 - s22 * s13)) / det;
            var c1 = (s11 * (t2 * s33 - s23 * t3) - t1 * (s12 * s33 - s23 * s13) + s13 * (s12 * t3 - t2 * s13)) / det;
            var c0 = (t1 * (s22 * s33 - s23 * s23) - s12 * (t2 * s33 - s23 * t3) + s13 * (t2 * s23 - s22 * t3)) / det, E = 0;
            if (!(A > 0)) continue;
            for (j = 0; j < n; ++j) { var dd = ys[j] - c0 - c1 * rs[j] - A * Math.pow(rs[j], -pw); E += dd * dd; }
            if (E < bestE) { bestE = E; bA = A; bp = pw; }
         }
         if (!(bA > 0) || bA * Math.pow(rin, -bp) < 1.5 * sigma) continue;
         // (guardia: el ala de una estrella no pasa de una fraccion de su propio pico; si el «ala» ajustada es mayor, es nebulosidad bajo la estrella —en el
         // sintetico, una estrella de G 8 sobre una mancha de 36 niveles— y no se toca. El pico saturado esta por debajo del real: guardia conservadora.)
         var peak = cpSvSample(wk[c], w, h, s.x, s.y) - ys[n - 1];
         var mY = 0, vY = 0;
         for (j = 0; j < n; ++j) mY += ys[j];
         mY /= n;
         for (j = 0; j < n; ++j) vY += (ys[j] - mY) * (ys[j] - mY);
         var rel = bestE / Math.max(1e-9, vY);
         if (o.dbg) o.dbg.push({ g: s.g, c: c, rin: rin, Rbig: Rbig, p: bp, wing: bA * Math.pow(rin, -bp), peak: peak, frac: bA * Math.pow(rin, -bp) / peak, rel: rel, snr: bA * Math.pow(rin, -bp) / Math.sqrt(Math.max(1e-9, bestE / n)), sigma: sigma });
         // (la guardia buena es `rel`: un ala de verdad se ajusta casi sin resto —Pleyades, G < 4,3: 0,01–0,07—; la nebulosidad o el ruido no —0,17–0,94 en el
         // sintetico y en las debiles—)
         // y que el ala destaque del resto del ajuste (snr = ala / error cuadratico medio >= 8: en Orion, las del Trapecio con ajuste «bueno» pero snr 1–5 eran nebulosidad)
         // y que no pase de lo que da una estrella de su brillo (el ala crece con el flujo: 60 niveles a G 4, el 40 % por cada magnitud de mas; medido en las Pleyades,
         // G 2,9–4,2: 20–27 niveles a 13 px; en Orion, las de G 7,3–7,8 con «ala» de 15–43 niveles eran la nebulosidad del Trapecio)
         if (bA * Math.pow(rin, -bp) > ((o.wingAmp > 0) ? o.wingAmp : 60) * Math.pow(10, -0.4 * (s.g - 4)) || rel > ((o.wingRel > 0) ? o.wingRel : 0.1) || bA * Math.pow(rin, -bp) < ((o.wingSnr > 0) ? o.wingSnr : 8) * Math.sqrt(bestE / n) || bA * Math.pow(rin, -bp) > ((o.wingFrac > 0) ? o.wingFrac : 0.3) * peak) continue;
         // hasta donde el ala pasa de `wingK` ruidos
         var Rend = Rbig;
         for (ri = rin; ri <= Rbig; ++ri) if (bA * Math.pow(ri, -bp) < wingK * sigma) { Rend = ri; break; }
         if (o.dbgApplied) o.dbgApplied.push({ g: s.g, c: c, x: s.x, y: s.y, rin: rin, Rend: Rend, p: bp, wing: bA * Math.pow(rin, -bp), rel: rel });
         // un ala SUAVE (p < 2) se confunde con la nebulosidad que rodea a la estrella (medido: en la mancha del Pleyades de G 3,9, p = 1,25, restarla entera
         // se comia 7 niveles de nebulosidad real; a medias, 1): se resta solo p/2 de ella (entre el 50 % y el 100 %)
         var damp = Math.max(0.5, Math.min(1, bp / 2)), tail = bA * Math.pow(Rend, -bp), x, y, Rc = Math.ceil(Rend);
         for (y = Math.max(0, Math.floor(s.y - Rc)); y <= Math.min(h - 1, Math.ceil(s.y + Rc)); ++y)
            for (x = Math.max(0, Math.floor(s.x - Rc)); x <= Math.min(w - 1, Math.ceil(s.x + Rc)); ++x) {
               var d = Math.sqrt((x - s.x) * (x - s.x) + (y - s.y) * (y - s.y));
               if (d > Rend) continue;
               wk[c][y * w + x] -= damp * (bA * Math.pow(Math.max(d, rin), -bp) - tail);
            }
      }
   }
   return wk;
}
function cpSvStarlessGaia(r, g, b, w, h, stars, fwhm, opts) {
   var t0 = Date.now(), o = opts || {}, N = w * h, i, c, x, y, K = (o.K > 0) ? o.K : 0.75, gMax = (typeof o.gMax === "number") ? o.gMax : 19, RMAX = (o.RMAX > 0) ? o.RMAX : 120;
   var fw = Math.max(0.6, fwhm || 3);
   var base = o.pre ? cpSvStarlessOwn(r, g, b, w, h, {}) : null, src = base ? [base.r, base.g, base.b] : [r, g, b], L = new Float32Array(N);
   for (i = 0; i < N; ++i) L[i] = (r[i] + g[i] + b[i]) / 3;
   // el ruido de pixel de la luz (desviacion robusta de la luz menos su media 3 x 3; el 8/9 es lo que se come la media)
   var sm = cpSvBox3(L, w, h), dv = new Float32Array(N);
   for (i = 0; i < N; ++i) dv[i] = Math.abs(L[i] - sm[i]);
   var sigma = Math.max(0.3, 1.4826 * cpSvMedianStride(dv, N, 4) / Math.sqrt(8 / 9));
   var hole = new Uint8Array(N), used = 0, nHole = 0, smp = new Float32Array(16), order = [], wl = [], wingG = (typeof o.wingG === "number") ? o.wingG : 11;
   var mg = Math.ceil(4 * fw) + 4;           // (una estrella fuera del trozo mas alla de esto no mete su disco: su perfil saldria de pixeles repetidos del borde)
   for (i = 0; i < stars.length; ++i) if (stars[i].g <= gMax && stars[i].x > -mg && stars[i].y > -mg && stars[i].x < w + mg && stars[i].y < h + mg) order.push(i);
   var ang = [];
   for (i = 0; i < 16; ++i) ang.push([Math.cos(2 * Math.PI * i / 16), Math.sin(2 * Math.PI * i / 16), Math.cos(2 * Math.PI * (i + 0.5) / 16), Math.sin(2 * Math.PI * (i + 0.5) / 16)]);
   for (var q = 0; q < order.length; ++q) {
      var s = stars[order[q]], gm = Math.max(0, 15 - s.g);
      var Rmax = Math.min(RMAX, Math.ceil(fw * (4 + 3 * gm)) + 4), nR = Rmax + 1, prof = new Float32Array(nR), ri, k;
      prof[0] = cpSvSample(L, w, h, s.x, s.y);
      for (ri = 1; ri < nR; ++ri) {
         for (k = 0; k < 16; ++k) { var a = ang[k], odd = ri & 1; smp[k] = cpSvSample(L, w, h, s.x + ri * (odd ? a[2] : a[0]), s.y + ri * (odd ? a[3] : a[1])); }
         for (k = 1; k < 16; ++k) { var vk = smp[k], jk = k - 1; while (jk >= 0 && smp[jk] > vk) { smp[jk + 1] = smp[jk]; --jk; } smp[jk + 1] = vk; }
         prof[ri] = 0.5 * (smp[7] + smp[8]);
      }
      // el cielo de su alrededor: la mediana del tercio exterior del perfil
      var o0 = Math.max(2, Math.floor(nR * 2 / 3)), tail = [];
      for (ri = o0; ri < nR; ++ri) tail.push(prof[ri]);
      tail.sort(function(p1, p2) { return p1 - p2; });
      var sky = tail[tail.length >> 1];
      // (con el centro y el pixel de al lado: la estrella cae entre pixeles)
      if (!(Math.max(prof[0], prof[1]) - sky > 3 * sigma)) continue;
      var d = Math.max(1, Math.round(fw / 2)), r0 = Math.ceil(1.2 * fw), Re = nR - 1 - d;
      for (ri = r0; ri <= nR - 1 - d; ++ri) {
         var mm = 0;
         for (k = 0; k <= d; ++k) mm += prof[ri + k];
         if (mm / (d + 1) - sky < K * sigma) { Re = ri; break; }
      }
      if (o.fit !== false) {
         // el ALA de la estrella frente a la NEBULOSIDAD: sin esto, una estrella sobre un pico de nebulosidad no acababa nunca (el perfil sigue
         // alto por la nebulosidad, no por la estrella) y su disco se comia la nebulosidad (medido en el sintetico: error de 5 niveles). Perfil =
         // c0 + c1·r + A·r^-p (minimos cuadrados, tres incognitas); el radio de la estrella es donde su ala A·r^-p baja a K ruidos.
         var pw = o.p || 2, s11 = 0, s12 = 0, s13 = 0, s22 = 0, s23 = 0, s33 = 0, b1 = 0, b2 = 0, b3 = 0, rr, f3, nn = 0;
         for (rr = r0; rr < nR; ++rr) { f3 = Math.pow(rr, -pw); s11 += 1; s12 += rr; s13 += f3; s22 += rr * rr; s23 += rr * f3; s33 += f3 * f3; b1 += prof[rr]; b2 += prof[rr] * rr; b3 += prof[rr] * f3; ++nn; }
         if (nn >= 5) {
            var det = s11 * (s22 * s33 - s23 * s23) - s12 * (s12 * s33 - s23 * s13) + s13 * (s12 * s23 - s22 * s13);
            if (Math.abs(det) > 1e-12) {
               var A = (s11 * (s22 * b3 - b2 * s23) - s12 * (s12 * b3 - b2 * s13) + b1 * (s12 * s23 - s22 * s13)) / det;
               var Rf = (A > 0) ? Math.pow(A / (K * sigma), 1 / pw) : r0;
               Re = Math.min(Re, Math.max(r0, Math.ceil(Rf)));
            }
         }
      }
      var Rm = Re + 1 + 0.5 * fw, Rc = Math.ceil(Rm);
      for (y = Math.max(0, Math.floor(s.y - Rc)); y <= Math.min(h - 1, Math.ceil(s.y + Rc)); ++y)
         for (x = Math.max(0, Math.floor(s.x - Rc)); x <= Math.min(w - 1, Math.ceil(s.x + Rc)); ++x)
            if ((x - s.x) * (x - s.x) + (y - s.y) * (y - s.y) <= Rm * Rm) hole[y * w + x] = 1;
      ++used;
      if (s.g <= wingG) wl.push({ x: s.x, y: s.y, g: s.g, Rm: Rm });
   }
   // EL ALA LARGA de las brillantes (21-oct-2026): su disco acaba donde el ala baja a K ruidos, pero el ala real cae mas despacio que r^-2 y sigue
   // decenas de FWHM mas alla: rellenar el disco con ese borde dejaba una MANCHA redonda y difusa (visto por Nino a 1:1: +5 niveles hasta 20 px de una
   // estrella de G 3). Se resta antes del relleno, por canal, un ala radial c0 + A·r^-p (p entre 1 y 3, ajustada de fuera del disco hasta Rbig).
   if (o.wing !== false && wl.length > 0) src = cpSvSubtractWings(src, w, h, wl, fw, sigma, o);
   for (i = 0; i < N; ++i) if (hole[i]) ++nHole;
   // el desvanecido (un pixel) y el relleno de cada canal, con su grano
   var mf = new Float32Array(N);
   for (i = 0; i < N; ++i) mf[i] = hole[i];
   var al = cpSvBox3(mf, w, h), out = [];
   for (c = 0; c < 3; ++c) {
      var fl = cpSvFillHoles(src[c], hole, w, h, (typeof o.iters === "number") ? o.iters : 40), dst = new Float32Array(N), res = [];
      var s3 = cpSvBox3(src[c], w, h);
      for (i = 0; i < N; i += 3) if (!hole[i]) res.push(Math.abs(src[c][i] - s3[i]));
      var rA = new Float32Array(res); rA.sort();
      var gsig = (rA.length > 0) ? 1.4826 * rA[rA.length >> 1] / Math.sqrt(8 / 9) : 0;
      for (i = 0; i < N; ++i) {
         if (al[i] === 0) { dst[i] = src[c][i]; continue; }
         var grain = cpSvGrain(i, c) * gsig;
         var filled = hole[i] ? fl[i] + grain : src[c][i];
         dst[i] = src[c][i] * (1 - al[i]) + filled * al[i];
      }
      out.push(dst);
   }
   var fin = { r: out[0], g: out[1], b: out[2] };
   // lo que queda (espigas, estrellas sin Gaia, pixeles calientes): la apertura de siempre
   // (K = 2, no 3: con 3 quedan las estrellas debiles que Gaia no trae; medido en las Pleyades, 16-18 mag: residuo 0,08 contra 0,15)
   if (!o.pre && o.tail !== false) { var tl = cpSvStarlessOwn(out[0], out[1], out[2], w, h, { K: (o.tailK > 0) ? o.tailK : 2 }); fin = { r: tl.r, g: tl.g, b: tl.b }; }
   return { r: fin.r, g: fin.g, b: fin.b, mask: al, frac: nHole / N, sigma: sigma, info: { stars: used, holes: nHole, ms: Date.now() - t0 } };
}

// LA CAPA DE UNA NEBULOSA (14-oct-2026): de su trozo de foto SIN ESTRELLAS, lo que brilla sobre el cielo.
//   · el FONDO de cada canal: el percentil NEB_BG_PCT de ese canal alisado 5 x 5 (lo mas oscuro de la foto: una nebulosa
//     que la llena entera no deja corona de cielo alrededor, que es de donde lo saca el recorte de un objeto);
//   · su RUIDO: la desviacion robusta del canal menos su alisado (el grano de pixel a pixel);
//   · la TRANSPARENCIA: el exceso medio (alisado 5 x 5) del canal que mas sube, en ruidos, en rampa suave de NEB_LO a
//     NEB_HI; por el desvanecido de los bordes (NEB_FEATHER del lado: la capa no tiene canto) y, si `geo.disc` cae
//     dentro, el del borde de su disco;
//   · la LUZ: el canal menos su fondo; y la GANANCIA que le devuelve el pedestal de cielo (como en `cpSvCutoutMatte`).
//   geo = { disc: { cx, cy, r } (px) | null }
// Devuelve { a, r, g, b (luz, sin fondo), bg, sigma, gain, cover, shine { x0, y0, x1, y1 } }.
function cpSvBox5(a, w, h) {
   var N = w * h, t = new Float32Array(N), o = new Float32Array(N), x, y, q, s, n;
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { s = 0; n = 0; for (q = Math.max(0, x - 2); q <= Math.min(w - 1, x + 2); ++q) { s += a[y * w + q]; ++n; } t[y * w + x] = s / n; }
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { s = 0; n = 0; for (q = Math.max(0, y - 2); q <= Math.min(h - 1, y + 2); ++q) { s += t[q * w + x]; ++n; } o[y * w + x] = s / n; }
   return o;
}
function cpSvNebulaMatte(r, g, b, w, h, geo) {
   var N = w * h, src = [r, g, b], bg = [0, 0, 0], sg = [0, 0, 0], S = [], i, c, x, y;
   for (c = 0; c < 3; ++c) {
      var sm = cpSvBox5(src[c], w, h), srt = new Float32Array(sm), d = new Float32Array(N);
      srt.sort();
      bg[c] = srt[Math.min(N - 1, Math.floor(CP_SV.NEB_BG_PCT * (N - 1)))];
      for (i = 0; i < N; ++i) d[i] = Math.abs(src[c][i] - sm[i]);
      d.sort();
      sg[c] = Math.max(0.5, 1.4826 * d[N >> 1]);
      S.push(sm);
   }
   var A = new Float32Array(N), L = [new Float32Array(N), new Float32Array(N), new Float32Array(N)], fe = Math.max(1e-6, CP_SV.NEB_FEATHER);
   var disc = (geo && geo.disc && geo.disc.r > 0) ? geo.disc : null, cover = 0;
   for (y = 0; y < h; ++y)
      for (x = 0; x < w; ++x) {
         i = y * w + x;
         var e = Math.max((S[0][i] - bg[0]) / sg[0], (S[1][i] - bg[1]) / sg[1], (S[2][i] - bg[2]) / sg[2]), t = (e - CP_SV.NEB_LO) / (CP_SV.NEB_HI - CP_SV.NEB_LO);
         t = (t > 0) ? ((t < 1) ? t : 1) : 0;
         var al = t * t * (3 - 2 * t);
         // los bordes de la capa
         var ex = Math.min(x + 0.5, w - x - 0.5) / (fe * w), ey = Math.min(y + 0.5, h - y - 0.5) / (fe * h), ee = Math.max(0, Math.min(1, Math.min(ex, ey)));
         al *= ee * ee * (3 - 2 * ee);
         if (disc !== null) {
            var dd = Math.sqrt((x + 0.5 - disc.cx) * (x + 0.5 - disc.cx) + (y + 0.5 - disc.cy) * (y + 0.5 - disc.cy)), ed = Math.max(0, Math.min(1, (disc.r - dd) / (fe * disc.r)));
            al *= ed * ed * (3 - 2 * ed);
         }
         A[i] = al; cover += al;
         for (c = 0; c < 3; ++c) L[c][i] = Math.max(0, src[c][i] - bg[c]);
      }
   var gain = 1, top = [];
   for (i = 0; i < N; i += 2) if (A[i] > 0.5) top.push(Math.max(L[0][i], L[1][i], L[2][i]));
   if (top.length >= 8) {
      var ts = new Float32Array(top); ts.sort();
      var p = ts[Math.floor(CP_SV.MATTE_GAIN_AT * (ts.length - 1))];
      if (p > 1) gain = Math.max(1, Math.min(CP_SV.MATTE_GAIN, (Math.max(bg[0], bg[1], bg[2]) + p) / p));
   }
   // lo que brilla: la caja con MATTE_SHINE de la transparencia
   var shine = { x0: 0, y0: 0, x1: w, y1: h }, mx = new Float64Array(w), my = new Float64Array(h), tot = 0, cut = (1 - CP_SV.MATTE_SHINE) / 2, acc;
   for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var av = A[y * w + x]; mx[x] += av; my[y] += av; tot += av; }
   if (tot > 0) {
      for (acc = 0, x = 0; x < w; ++x) { acc += mx[x]; if (acc >= cut * tot) { shine.x0 = x; break; } }
      for (acc = 0, x = w - 1; x >= 0; --x) { acc += mx[x]; if (acc >= cut * tot) { shine.x1 = x + 1; break; } }
      for (acc = 0, y = 0; y < h; ++y) { acc += my[y]; if (acc >= cut * tot) { shine.y0 = y; break; } }
      for (acc = 0, y = h - 1; y >= 0; --y) { acc += my[y]; if (acc >= cut * tot) { shine.y1 = y + 1; break; } }
   }
   return { a: A, r: L[0], g: L[1], b: L[2], bg: bg, sigma: sg, gain: gain, cover: cover / N, shine: shine };
}

// LA FOTO EN PERSPECTIVA. `Graphics` solo sabe pintar un bitmap con una transformacion AFIN, y un
// rectangulo en perspectiva no lo es: se trocea en n x n celdas y cada una se pinta con la afin que
// lleva tres de sus esquinas a su sitio (con 16 x 16 la cuarta se queda a menos de 0,4 px: medido).
// Devuelve { n, cells: [ [ fx0, fy0, fx1, fy1 (la celda, en fracciones de la foto), x00, y00, x10, y10,
// x01, y01 (a donde van tres de sus esquinas), x11, y11 (donde cae DE VERDAD la cuarta: lo que la afin
// se equivoca con ella es lo que cada celda tiene que meterse en sus vecinas para no dejar rendija) ] ],
// quad: las cuatro esquinas de la foto (o null si alguna queda detras de la camara), front }. Las celdas
// con una esquina detras de la camara, o enteras fuera de `clip`, no salen.
function cpSvPhotoMesh(fit, n, clip) {
   return cpSvQuadMesh(fit, n, clip, -fit.wn / 2, -fit.hn / 2, fit.wn / 2, fit.hn / 2, 0);
}
// Lo mismo para CUALQUIER rectangulo paralelo a la foto: de (u0, v0) a (u1, v1), a la profundidad t. Las
// fracciones de cada celda son las de ESE rectangulo (0…1 de lado a lado).
function cpSvQuadMesh(fit, n, clip, u0, v0, u1, v1, t) {
   var N = Math.max(1, Math.min(64, Math.round(n) || CP_SV.PHOTO_MESH)), pts = [], cells = [], i, j;
   for (j = 0; j <= N; ++j)
      for (i = 0; i <= N; ++i) pts.push(fit.px(u0 + (u1 - u0) * i / N, v0 + (v1 - v0) * j / N, t));
   for (j = 0; j < N; ++j)
      for (i = 0; i < N; ++i) {
         var a = pts[j * (N + 1) + i], b = pts[j * (N + 1) + i + 1], c = pts[(j + 1) * (N + 1) + i], d = pts[(j + 1) * (N + 1) + i + 1];
         if (!(a.ok && b.ok && c.ok && d.ok)) continue;
         if (clip) {
            var x0 = Math.min(a.x, b.x, c.x, d.x), x1 = Math.max(a.x, b.x, c.x, d.x), y0 = Math.min(a.y, b.y, c.y, d.y), y1 = Math.max(a.y, b.y, c.y, d.y);
            if (x1 < clip.x || x0 > clip.x + clip.w || y1 < clip.y || y0 > clip.y + clip.h) continue;
         }
         cells.push([i / N, j / N, (i + 1) / N, (j + 1) / N, a.x, a.y, b.x, b.y, c.x, c.y, d.x, d.y]);
      }
   var q = [pts[0], pts[N], pts[(N + 1) * (N + 1) - 1], pts[N * (N + 1)]];
   return { n: N, cells: cells, quad: (q[0].ok && q[1].ok && q[2].ok && q[3].ok) ? q : null, front: fit.front };
}
// Lo que la afin se equivoca con la cuarta esquina, en la peor celda (pixeles).
function cpSvPhotoMeshError(mesh) {
   var worst = 0;
   for (var i = 0; i < mesh.cells.length; ++i) {
      var c = mesh.cells[i], ex = c[6] + c[8] - c[4] - c[10], ey = c[7] + c[9] - c[5] - c[11], e = Math.sqrt(ex * ex + ey * ey);
      if (e > worst) worst = e;
   }
   return worst;
}
// LA MALLA QUE HACE FALTA. De lejos bastan PHOTO_MESH celdas por lado; con la camara cerca de la foto la
// perspectiva se curva mas en cada celda y el error de la cuarta esquina pasaba de dos pixeles (rendijas
// negras entre celdas: visto en la captura). Se afina —el error baja con el cuadrado de las celdas por
// lado— hasta que no pasa de `tol` pixeles (o hasta 64 por lado). Las celdas que no se ven no se pintan:
// de cerca son muchas en la cuenta y pocas en el lienzo. Devuelve la malla, con su `err`.
function cpSvPhotoMeshFine(fit, clip, tol) {
   var N = CP_SV.PHOTO_MESH, T = (tol > 0) ? tol : 0.75, M = null;
   for (var pass = 0; pass < 4; ++pass) {
      M = cpSvPhotoMesh(fit, N, clip);
      M.err = cpSvPhotoMeshError(M);
      if (M.err <= T || N >= 64) break;
      N = Math.min(64, Math.ceil(N * Math.sqrt(M.err / (0.6 * T))));
   }
   return M;
}

// Una afin de 2 x 2 —el eje x de la fuente va a (a, b) y el eje y a (c, d)— como GIRO · CIZALLA ·
// ESCALA, que es lo que `Graphics` deja encadenar: L = R(rot) · [[1, shear], [0, 1]] · diag(sx, sy).
// null si no tiene area (la celda esta de canto). OJO al pintar: `rotateTransformation` de PJSR
// gira al reves que R (medido en la sonda): se le pasa -rot.
function cpSvAffineQr(a, b, c, d) {
   var sx = Math.sqrt(a * a + b * b);
   if (!(sx > 1e-9)) return null;
   var ct = a / sx, st = b / sx, r0 = ct * c + st * d, sy = -st * c + ct * d;
   if (!(Math.abs(sy) > 1e-9)) return null;
   return { rot: Math.atan2(b, a), shear: r0 / sy, sx: sx, sy: sy };
}

// De las cuatro aristas LARGAS de la caja (las que van de la foto al fondo; la c sale de la esquina
// CP_SV_CORNERS[c]), la que queda mas ABAJO en pantalla (`which` = "low": bajo ella van las cifras)
// o mas ARRIBA ("high": sobre ella, los rotulos de las bandas). `prev` = la que se usaba: no se
// cambia hasta que otra le gana por `margin` pixeles (al girar, las cifras no bailan de una arista
// a otra en el empate). Devuelve 0…3, o -1 si ninguna esta delante de la camara.
var CP_SV_CORNERS = [[-1, -1], [1, -1], [1, 1], [-1, 1]];
function cpSvDistEdge(fit, which, prev, margin) {
   var best = -1, bs = 0, ps = null, sgn = (which === "high") ? -1 : 1;
   for (var c = 0; c < 4; ++c) {
      var u = CP_SV_CORNERS[c][0] * fit.wn / 2, v = CP_SV_CORNERS[c][1] * fit.hn / 2, a = fit.px(u, v, 0), b = fit.px(u, v, 1);
      var y = (a.ok && b.ok) ? (a.y + b.y) / 2 : a.ok ? a.y : b.ok ? b.y : NaN;
      if (y !== y) continue;
      var s = sgn * y;
      if (best < 0 || s > bs) { best = c; bs = s; }
      if (c === prev) ps = s;
   }
   if (ps !== null && best !== prev && bs - ps < ((margin > 0) ? margin : 0)) return prev;
   return best;
}

// ¿Pisa la caja `b` el cuadrilatero convexo `q` (cuatro puntos en orden)? (Un rotulo no va encima de la foto.)
function cpSvQuadHitsBox(q, b) {
   var i, j, x0 = b.x, y0 = b.y, x1 = b.x + b.w, y1 = b.y + b.h;
   function inQuad(x, y) {
      var sign = 0;
      for (var k = 0; k < 4; ++k) {
         var a = q[k], c = q[(k + 1) % 4], cr = (c.x - a.x) * (y - a.y) - (c.y - a.y) * (x - a.x);
         if (cr === 0) continue;
         if (sign === 0) sign = (cr > 0) ? 1 : -1; else if ((cr > 0 ? 1 : -1) !== sign) return false;
      }
      return true;
   }
   for (i = 0; i < 4; ++i) if (q[i].x >= x0 && q[i].x <= x1 && q[i].y >= y0 && q[i].y <= y1) return true;       // una esquina de la foto, dentro de la caja
   if (inQuad(x0, y0) || inQuad(x1, y0) || inQuad(x1, y1) || inQuad(x0, y1) || inQuad((x0 + x1) / 2, (y0 + y1) / 2)) return true;
   for (i = 0; i < 4; ++i) { j = (i + 1) % 4; if (cpSvSegmentHitsBox(q[i].x, q[i].y, q[j].x, q[j].y, b)) return true; }   // un lado de la foto cruza la caja
   return false;
}

// QUE CIFRAS DEL EJE SE PONEN. `boxes` = la caja de cada cifra, en orden a lo largo del eje, o null la
// que no se puede poner (se sale del lienzo, cae encima de la foto). Se pone la serie REGULAR mas
// larga: todas las seguidas que caben sin pisarse (con `pad` de aire); si se pisan, una de cada dos; si
// no, una de cada tres… y SIN HUECOS dentro de la serie (una cifra que no se puede poner la corta).
// Nunca «las que quepan», que dejaba 100, 1 000, 100 000 y saltaba las demas a ojo (revision visual
// del 13-oct-2026). A igual numero de cifras, la serie de paso mas corto. Devuelve los indices.
function cpSvPickTicks(boxes, pad) {
   var n = boxes.length, p = (pad > 0) ? pad : 0, best = [];
   function clash(a, b) { return cpSvBoxesOverlap({ x: a.x - p, y: a.y - 1, w: a.w + 2 * p, h: a.h + 2 }, b); }
   for (var stride = 1; stride <= n; ++stride)
      for (var phase = 0; phase < stride; ++phase) {
         var run = [];
         for (var i = phase; i < n + stride; i += stride) {
            var b = (i < n) ? boxes[i] : null, ok = (b !== null && b !== undefined);
            for (var j = 0; ok && j < run.length; ++j) ok = !clash(b, boxes[run[j]]);
            if (ok) { run.push(i); continue; }
            if (run.length > best.length) best = run;
            run = (b !== null && b !== undefined) ? [i] : [];
         }
      }
   return best;
}

// EL ORDEN DE PINTADO: lo lejano antes (lo cercano lo tapa). Indices de 0 a n-1 por profundidad
// `z` decreciente; a igual profundidad, por indice (el orden no baila de un fotograma a otro).
function cpSvDepthOrder(z, n) {
   var a = new Array(n);
   for (var i = 0; i < n; ++i) a[i] = i;
   a.sort(function(p, q) { return (z[q] - z[p]) || (p - q); });
   return a;
}
// Lo que la perspectiva le hace a un punto. `m` = el factor de la perspectiva ( K / ( K + zc ) )
// por la RAIZ del zoom: al acercarse la camara lo que tiene delante crece, pero menos que la
// escena (con el zoom entero, a 1,6 aumentos las estrellas eran discos que tapaban la foto: visto
// en la captura; con la raiz, a 35 aumentos una estrella debil mide 10 px de ancho).
//   el tamaño: lo lejano mengua DEPRISA (m elevado a 2,2) y lo cercano crece (a 1,15), con tope de 5 (un punto
//              pegado a la camara no es un disco que tapa el lienzo);
//   el brillo: lo del fondo, apagado (m al cuadrado) hasta el 35 %.
// (La primera version usaba m tal cual entre 0,5 y 4 y el 55 % de brillo: «no se aprecia que los
// puntos mengüen ni se apaguen con la distancia», revision visual del 13-oct-2026. Con esta, en la
// pose de fabrica lo de delante se pinta mas de 3 veces mas grande que lo del fondo: caso V19.)
function cpSvDepthSize(m) { return (m >= 1) ? Math.min(5, Math.pow(m, 1.15)) : Math.max(0.3, Math.pow(Math.max(m, 1e-6), 2.2)); }
function cpSvDepthDim(m) { return (m >= 1) ? 1 : Math.max(0.35, Math.pow(Math.max(m, 1e-6), 2)); }

// Todos los objetos a pixel. Devuelve { px, py, tt (su t), lo, hi (el t de su intervalo), pz (su
// profundidad zc), pw (el factor de la perspectiva), pm (pw por la raiz del zoom: lo que entra en
// cpSvDepthSize / cpSvDepthDim), vis (0 = detras de la camara) }:
// lo que pinta el panel y lo que mira el raton.
var CP_SV_GONE_HIDDEN = true;     // (C7, 2-nov-2026; la costura del rojo: false = una estrella salida por el margen sigue siendo elegible)
function cpSvDistProject(model, scale, fit) {
   var n = model.objects.length, px = new Float32Array(n), py = new Float32Array(n), tt = new Float32Array(n), lo = new Float32Array(n), hi = new Float32Array(n);
   var pz = new Float32Array(n), pw = new Float32Array(n), pm = new Float32Array(n), vis = new Uint8Array(n), zoom = (fit.mode === "perspective" && fit.zoom > 0) ? Math.sqrt(fit.zoom) : 1;
   for (var i = 0; i < n; ++i) {
      var ob = model.objects[i], t = scale.t(ob.pc), p = fit.px(ob.u, ob.v, t);
      px[i] = p.x; py[i] = p.y; tt[i] = t; lo[i] = scale.t(ob.lo); hi[i] = scale.t(ob.hi);
      // Cabra3D (bloque F, 20-oct): un objeto que no es una estrella y que la maquina del tiempo ha sacado del encuadre (`tmGone`) no
      // se ve: ni su simbolo, ni su placa, ni se puede elegir (las estrellas que se van ya las salta el dibujo, como siempre)
      // (C7, 2-nov-2026: una ESTRELLA que se ha ido por el margen del encuadre (`tmGone` sin `tmNoTan`) tampoco se pinta —el dibujo la salta—, pero seguia con vis = 1: se podia
      // elegir y llevar placa sin verse. Ahora `tmGone` la saca de aqui igual que a lo demas. Costura del rojo: CP_SV_GONE_HIDDEN = false = como antes.)
      pz[i] = p.z; pw[i] = p.w; pm[i] = p.w * zoom; vis[i] = (p.ok && ob.tmNoTan !== true && !(ob.tmGone === true && (CP_SV_GONE_HIDDEN === true || (ob.kind !== "star" && ob.kind !== "member")))) ? 1 : 0;   // (B1, 2-nov-2026: `tmNoTan` = la proyeccion de la foto ya no llega a la estrella: no se ve ni se elige)
   }
   return { px: px, py: py, tt: tt, lo: lo, hi: hi, pz: pz, pw: pw, pm: pm, vis: vis };
}

// Un nombre de catalogo CLASICO (lo que un astrofotografo reconoce), frente a la designacion de un cartografiado.
var CP_SV_CLASSIC = /^(M|NGC|IC|UGC|UGCA|Abell|ACO|Arp|Mrk|Mkn|3C|4C|PKS|Sh ?2-?|LBN|LDN|Barnard|vdB|Ced|Cr|Mel|Tr|Stock|Berkeley|King|Pal|Terzan|Hickson|HCG|Maffei|Leo|Draco|Sculptor)\s*[-+]?\d|^(Maffei|Leo|Draco|Sculptor|Fornax|Carina|Sextans|Andromeda|Triangulum)\b/;
// LOS OBJETOS QUE LLEVAN PLACA: el mas cercano, EL MOTIVO DE LA FOTO (lo no estelar mas
// centrado: una planetaria, una nebulosa, una galaxia…), los cumulos, el mas lejano, lo
// demas de nuestra galaxia con nombre (nebulosas, planetarias; las mas centradas) y las
// galaxias con nombre de catalogo clasico (M, NGC, IC, UGC; las mas cercanas primero).
// Como mucho MAX_PLATES. Devuelve [ { index, role } ], role = "nearest" | "subject" |
// "cluster" | "farthest" | "nebula" | "galaxy".
// (Hasta el 13-oct-2026 una planetaria no llevaba placa NUNCA —solo estrellas, cumulos y
// galaxias—: en un campo cuyo protagonista es una, quedaba como un simbolo anonimo entre
// las estrellas y Nino no sabia si el programa la habia colocado.)
// (27-oct-2026, D3) EL PAPEL DEL MAS LEJANO MANDA: si el mas lejano es tambien el motivo de la foto o un cumulo (que entran antes
// en la lista), su placa decia solo la clase («galaxy · 10.9 M ly») en el video y en el panel, y «farthest galaxy» en `_plateOf`
// llamado con el papel a mano. Pasaba en NGC 1560 cuando lo lejano de VizieR (GLADE+, Quaia) no estaba o no se veia: el mas lejano
// era NGC 1560, el motivo. Ahora el objeto que es el mas lejano lleva SIEMPRE el papel «farthest» (el mismo hueco en la lista).
var CP_SV_HL_FARTHEST_WINS = true;     // (la costura del rojo: false = como antes del 27-oct)
function cpSvDistHighlights(model) {
   var out = [], used = {}, objs = model.objects, i;
   function add(idx, role) {
      if (idx >= 0 && !used[idx] && out.length < CP_SV.MAX_PLATES) {
         if (CP_SV_HL_FARTHEST_WINS === true && idx === model.farthest && model.farthest !== model.nearest) role = "farthest";
         used[idx] = true; out.push({ index: idx, role: role });
      }
   }
   add(model.nearest, "nearest");
   if (model.subject && model.subject.index >= 0) add(model.subject.index, "subject");
   for (i = 0; i < objs.length; ++i) if (objs[i].kind === "cluster") add(i, "cluster");
   if (model.farthest !== model.nearest) add(model.farthest, "farthest");
   var local = [];
   for (i = 0; i < objs.length; ++i) if ((objs[i].kind === "other" || objs[i].kind === "nebula") && objs[i].name.length > 0 && !objs[i].suspect) local.push(i);
   local.sort(function(a, b) { return (objs[a].u * objs[a].u + objs[a].v * objs[a].v) - (objs[b].u * objs[b].u + objs[b].v * objs[b].v); });
   for (i = 0; i < local.length && i < 2; ++i) add(local[i], "nebula");
   var named = [];
   for (i = 0; i < objs.length; ++i)
      if ((objs[i].kind === "galaxy" || objs[i].kind === "group") && /^(M|NGC|IC|UGC|Abell|ACO)\s*\d/.test(objs[i].name) && !objs[i].suspect) named.push(i);
   named.sort(function(a, b) { return objs[a].pc - objs[b].pc; });
   for (i = 0; i < named.length && i < 3; ++i) add(named[i], "galaxy");
   return out;
}

// ¿Corta el segmento (x1, y1)-(x2, y2) la caja? (Liang-Barsky.)
function cpSvSegmentHitsBox(x1, y1, x2, y2, b) {
   var t0 = 0, t1 = 1, dx = x2 - x1, dy = y2 - y1;
   var p = [-dx, dx, -dy, dy], q = [x1 - b.x, b.x + b.w - x1, y1 - b.y, b.y + b.h - y1];
   for (var i = 0; i < 4; ++i) {
      if (p[i] === 0) { if (q[i] < 0) return false; }
      else {
         var r = q[i] / p[i];
         if (p[i] < 0) { if (r > t1) return false; if (r > t0) t0 = r; }
         else { if (r < t0) return false; if (r < t1) t1 = r; }
      }
   }
   return t0 <= t1;
}

// DONDE VA CADA PLACA. `items` = [ { ax, ay (el objeto), w, h (lo que ocupa su
// placa) } ]; `rect` = donde tienen que caber; `forbidden` = cajas que ni la placa
// ni su filete pueden pisar (las cifras del eje, los rotulos de las bandas); una
// con `boxOnly: true` (la foto) solo veta a la placa, no al filete.
// Devuelve, por cada una, { ok, x, y, w, h, lx1, ly1, lx2, ly2 (el filete) }; la
// que no encuentra sitio sale con ok false y NO se pinta (mejor sin placa que con
// un filete cruzando una cifra).
//   mode "rows": las placas van en filas BAJO `rowsTop`, colgando de la vertical de
//   su objeto (el corte lateral). Una placa no se pone donde taparia la vertical de
//   un objeto que aun no tiene la suya (si no, la segunda de dos vecinas se quedaba
//   sin sitio: visto en la primera captura, con M 13 junto a la estrella mas cercana).
//   cualquier otro modo: alrededor del objeto; con `score( caja ) -> numero` se
//   queda, de las que valen, la que MENOS tapa (menos puntos debajo).
//   `maxScore` (con `score`): el sitio que tapa MAS que esto no vale; si ninguno vale, la placa no se pone (mejor una
//   placa menos que una encima del cumulo o de otro objeto destacado).
function cpSvPlacePlates(items, rect, forbidden, mode, rowsTop, gap, score, maxScore) {
   var out = [], placed = [], g = (gap > 0) ? gap : 6, F = forbidden || [], i, k;
   var leaders = [], air = (mode === "rows") ? 2 : g;        // el aire entre dos placas: alrededor del objeto, un hueco entero (no se tocan)
   function clashes(box, lx1, ly1, lx2, ly2) {
      var j;
      if (box.x < rect.x || box.y < rect.y || box.x + box.w > rect.x + rect.w || box.y + box.h > rect.y + rect.h) return true;
      for (j = 0; j < placed.length; ++j) {
         if (cpSvBoxesOverlap({ x: box.x - air, y: box.y - air, w: box.w + 2 * air, h: box.h + 2 * air }, placed[j])) return true;
         if (cpSvSegmentHitsBox(lx1, ly1, lx2, ly2, placed[j])) return true;
         // …ni la placa nueva puede caer sobre el filete de una ya puesta
         if (cpSvSegmentHitsBox(leaders[j][0], leaders[j][1], leaders[j][2], leaders[j][3], box)) return true;
      }
      for (j = 0; j < F.length; ++j) {
         if (cpSvBoxesOverlap(box, F[j])) return true;
         // (una caja con `boxOnly` —la foto— no se puede TAPAR, pero un filete si puede salir de ella: el objeto
         // mas cercano se proyecta dentro de su recuadro, y con el veto entero se quedaba sin placa)
         if (F[j].boxOnly !== true && cpSvSegmentHitsBox(lx1, ly1, lx2, ly2, F[j])) return true;
      }
      return false;
   }
   var order = [];
   for (i = 0; i < items.length; ++i) order.push(i);
   if (mode === "rows") order.sort(function(a, b) { return items[a].ax - items[b].ax; });
   for (var oi = 0; oi < order.length; ++oi) {
      i = order[oi];
      var it = items[i], res = { ok: false, x: 0, y: 0, w: it.w, h: it.h, lx1: it.ax, ly1: it.ay, lx2: it.ax, ly2: it.ay };
      var cands = [], strict = [], best = null;
      if (mode === "rows") {
         for (var row = 0; row < 6; ++row) {
            var yy = rowsTop + g + row * (it.h + g);
            // la placa cuelga de la vertical del objeto. Primero HACIA LA IZQUIERDA (su borde derecho en el filete):
            // se colocan de izquierda a derecha, y asi el filete de las siguientes pasa siempre a la derecha de las
            // ya puestas (con «primero a la derecha», de cinco placas cabian tres: visto en la captura de M 13).
            var xs = [it.ax - it.w + 2, it.ax - 2, it.ax - it.w / 2];
            for (k = 0; k < xs.length; ++k) {
               var bx = Math.round(Math.max(rect.x, Math.min(rect.x + rect.w - it.w, xs[k])));
               // ¿taparia la vertical de alguno que aun espera su placa?
               var blocks = false;
               for (var oj = oi + 1; oj < order.length && !blocks; ++oj) { var ox = items[order[oj]].ax; blocks = (ox > bx - 2 && ox < bx + it.w + 2); }
               (blocks ? cands : strict).push([bx, yy, it.ax, it.ay, it.ax, yy]);
            }
         }
         cands = strict.concat(cands);
      } else {
         var steps = [1, 2.4, 4, 6];
         for (var s = 0; s < steps.length; ++s) {
            var dd = g * 2 * steps[s];
            // arriba a la derecha, arriba a la izquierda, abajo a la derecha, abajo a la izquierda
            cands.push([it.ax + dd, it.ay - dd - it.h, it.ax, it.ay, it.ax + dd, it.ay - dd]);
            cands.push([it.ax - dd - it.w, it.ay - dd - it.h, it.ax, it.ay, it.ax - dd, it.ay - dd]);
            cands.push([it.ax + dd, it.ay + dd, it.ax, it.ay, it.ax + dd, it.ay + dd]);
            cands.push([it.ax - dd - it.w, it.ay + dd, it.ax, it.ay, it.ax - dd, it.ay + dd]);
         }
         // …y, si cerca todo esta lleno, MAS LEJOS (el hilo se alarga hasta una zona vacia) y tambien en las cuatro
         // direcciones rectas. Sin `score` no hacen falta: se queda la primera que vale. (Con las de arriba solas, las
         // cinco placas de M 13 se amontonaban en el centro, sobre el cumulo: revision visual del 13-oct-2026.)
         if (typeof score === "function") {
            var far = [3, 6, 9, 13, 18, 24];
            for (s = 0; s < far.length; ++s) {
               var df = g * 2 * far[s];
               cands.push([it.ax + df, it.ay - it.h / 2, it.ax, it.ay, it.ax + df, it.ay]);
               cands.push([it.ax - df - it.w, it.ay - it.h / 2, it.ax, it.ay, it.ax - df, it.ay]);
               cands.push([it.ax - it.w / 2, it.ay - df - it.h, it.ax, it.ay, it.ax, it.ay - df]);
               cands.push([it.ax - it.w / 2, it.ay + df, it.ax, it.ay, it.ax, it.ay + df]);
               if (far[s] > 6) {
                  cands.push([it.ax + df, it.ay - df - it.h, it.ax, it.ay, it.ax + df, it.ay - df]);
                  cands.push([it.ax - df - it.w, it.ay - df - it.h, it.ax, it.ay, it.ax - df, it.ay - df]);
                  cands.push([it.ax + df, it.ay + df, it.ax, it.ay, it.ax + df, it.ay + df]);
                  cands.push([it.ax - df - it.w, it.ay + df, it.ax, it.ay, it.ax - df, it.ay + df]);
               }
            }
         }
      }
      var bestScore = Infinity;
      for (k = 0; k < cands.length; ++k) {
         var c = cands[k], box = { x: Math.round(c[0]), y: Math.round(c[1]), w: it.w, h: it.h };
         if (clashes(box, c[2], c[3], c[4], c[5])) continue;
         // sin `score`, la primera que vale; con el, la que menos tapa (a igualdad, la primera: la mas cercana)
         // (lo que tapa manda; la distancia solo desempata: 0,02 por candidata, que con 60 no llega a valer un punto tapado… salvo las 16 primeras, como siempre)
         var sc = (typeof score === "function" && mode !== "rows") ? Number(score(box)) + ((k < 16) ? k * 0.25 : 4 + (k - 16) * 0.05) : 0;
         if (typeof maxScore === "number" && typeof score === "function" && mode !== "rows" && Number(score(box)) > maxScore) continue;
         if (sc < bestScore) { bestScore = sc; best = { box: box, c: c }; }
         if (sc <= 0) break;
      }
      if (best !== null) {
         res.ok = true; res.x = best.box.x; res.y = best.box.y; res.lx1 = best.c[2]; res.ly1 = best.c[3]; res.lx2 = best.c[4]; res.ly2 = best.c[5];
         placed.push(best.box);
         leaders.push([best.c[2], best.c[3], best.c[4], best.c[5]]);
      }
      out[i] = res;
   }
   return out;
}

// El objeto mas cercano al raton (los miembros de un cumulo no se cogen uno a uno
// si `skipMembers`), o -1.
function cpSvDistNearest(model, proj, x, y, maxR, skipMembers) {
   var best = -1, bd = maxR * maxR;
   for (var i = 0; i < model.objects.length; ++i) {
      if (skipMembers && model.objects[i].kind === "member") continue;
      if (proj.vis && !proj.vis[i]) continue;                 // detras de la camara
      var dx = proj.px[i] - x, dy = proj.py[i] - y, d = dx * dx + dy * dy;
      if (d <= bd) { bd = d; best = i; }
   }
   return best;
}


// La vista de distancias: `proj` es lo de `cpSvDistProject`; `sc`, la escala de la pantalla;
// `deepRgb` y `quasarRgb`, el color de lo que no es una estrella (lo pone el panel: es de Atlas).
function cpSvSceneOfDist(model, proj, sc, deepRgb, quasarRgb) {
   var n = model.objects.length, S = cpSvScene(n);
   for (var i = 0; i < n; ++i) {
      var ob = model.objects[i], star = (ob.kind === "star" || ob.kind === "member");
      S.key[i] = star ? ob.ref : -(1 + i);
      S.x[i] = proj.px[i]; S.y[i] = proj.py[i];
      S.rgb[i] = star ? ob.rgb : (ob.kind === "quasar") ? quasarRgb : deepRgb;
      S.size[i] = ((ob.kind === "member") ? 0.67 : ob.size) * sc * cpSvDepthSize(proj.pm ? proj.pm[i] : 1);
      S.alpha[i] = (!proj.vis || proj.vis[i]) ? 1 : 0;
   }
   return S;
}
// El sitio EN LA FOTO de cada punto de una escena (como `object.u`, `object.v`: de -0,5 a 0,5 en el
// lado mayor). NaN = no lo tiene. `stars` = result.stars; `field` = result.field; `model` = el de
// distancias (para las claves negativas; puede faltar).
function cpSvSceneUv(scene, stars, field, model) {
   var U = new Float32Array(scene.n), V = new Float32Array(scene.n), W = Math.max(1, field.width), H = Math.max(1, field.height), big = Math.max(W, H);
   for (var i = 0; i < scene.n; ++i) {
      var k = scene.key[i], u = NaN, v = NaN;
      if (k >= 0) { var s = stars ? stars[k] : null; if (s && typeof s.x === "number" && typeof s.y === "number" && isFinite(s.x) && isFinite(s.y)) { u = (s.x - W / 2) / big; v = (s.y - H / 2) / big; } }
      else { var ob = (model && model.objects) ? model.objects[-k - 1] : null; if (ob) { u = ob.u; v = ob.v; } }
      U[i] = u; V[i] = v;
   }
   return { U: U, V: V };
}
// LA ESCENA «FOTO» de otra escena: los mismos puntos, cada uno EN SU SITIO DE LA IMAGEN.
//   photo   { x, y, w, h }: donde esta pintada la foto en el lienzo (cpSvPhotoRect)
// El que no tiene sitio en la imagen se queda donde esta en la otra escena.
function cpSvSceneOnPhoto(scene, U, V, photo, wn, hn, size) {
   var S = cpSvScene(scene.n);
   for (var i = 0; i < scene.n; ++i) {
      var u = U[i], v = V[i];
      S.key[i] = scene.key[i]; S.rgb[i] = scene.rgb[i]; S.size[i] = size; S.mark[i] = scene.mark[i];
      // EN LA FOTO NO SE VE NINGUNA (opacidad 0): el estado FOTO es la foto, tal cual. Cada estrella aparece al
      // despegar de su sitio (y al volver se apaga al posarse). Pintadas encima, las 20 000 de M 13 eran un disco
      // gris que tapaba el nucleo del cumulo (revision visual del 13-oct-2026).
      S.alpha[i] = 0;
      if (u === u && v === v) { S.x[i] = photo.x + (u / wn + 0.5) * photo.w; S.y[i] = photo.y + (v / hn + 0.5) * photo.h; }
      else { S.x[i] = scene.x[i]; S.y[i] = scene.y[i]; }
   }
   return S;
}







// ---------------------------------------------------------------------------
// LAS ESTRELLAS DE LA FOTO (14-oct-2026). Lo PURO: hasta donde llega el recorte de una estrella, de que clase es, que
// se pinta para ella segun el desplegable «Stars», a que escala y, en un vuelo, cuanto brillo gana. Lo que lee la
// imagen y hace los bitmaps esta en ui/starfield_photostars.js.
// ---------------------------------------------------------------------------
// El radio del recorte: el primer anillo (desde `rMin`) cuya media (suma / cuenta, ya sin fondo) baja de PS_RING veces
// el ruido de esa media (`sig` es el ruido de UN pixel). Si ninguno baja, el ultimo (y `capped`).
function cpSvStampRadius(sum, cnt, sig, rMin) {
   var n = Math.min(sum.length, cnt.length), s = (sig > 0) ? sig : 1e-9;
   for (var k = Math.max(1, rMin); k < n; ++k)
      if (cnt[k] > 0 && sum[k] / cnt[k] < CP_SV.PS_RING * s / Math.sqrt(cnt[k])) return { r: k, capped: false };
   return { r: Math.max(1, n - 1), capped: true };
}
// La clase de una estrella del 3D en la foto. `m` = { edge, snr, saturated, neighbours (las vecinas con al menos
// PS_NEIGHBOUR de su flujo: [ { d (px), dg (su G menos la nuestra) } ]), r (el radio del recorte), fwhm, onExtended }.
// "edge" | "faint" | "saturated" | "double" | "contaminated" | "onExtended" | "clean". (Saturada va antes que vecina: su
// recorte es grande y se queda con su disco; es la regla del estudio, medida en tres campos.)
function cpSvStampClass(m) {
   if (!m || m.edge) return "edge";
   if (!(m.snr >= CP_SV.PS_SNR_MIN)) return "faint";
   if (m.saturated) return "saturated";
   var nb = m.neighbours || [];
   for (var i = 0; i < nb.length; ++i) if (nb[i].d < CP_SV.PS_DOUBLE * m.fwhm) return "double";
   for (i = 0; i < nb.length; ++i) if (nb[i].d < m.r + CP_SV.PS_REACH * m.fwhm * (1 + Math.max(0, -nb[i].dg))) return "contaminated";
   if (m.onExtended) return "onExtended";
   return "clean";
}
// ¿Cuenta esta vecina? (la que tiene al menos PS_NEIGHBOUR del flujo de la nuestra: dG <= 2,5 mag)
function cpSvStampNeighbourCounts(dg) { return Math.pow(10, -0.4 * dg) >= CP_SV.PS_NEIGHBOUR; }
// LO QUE SE PINTA para una estrella. `mode` = el del desplegable; `kind` = "star" | "member"; `cat` = su clase (o "" si no
// se ha medido); `r4` = lo que llevan las que no tienen recorte limpio ("a" el punto de Gaia, "b" recorte sintetico con
// el color de la foto, "c" sintetico con el de Gaia, "d" punto con el color de la foto); `r5` = las que tienen una vecina
// dentro ("gaia" su punto de Gaia; "r4" como las demas sin recorte limpio).
// Devuelve "gaia" | "colour" | "sprite" | "synth-photo" | "synth-gaia".
function cpSvPhotoLook(mode, kind, cat, r4, r5) {
   if (mode !== "photo-colour" && mode !== "photo" && mode !== "photo-size") return "gaia";
   if (kind === "member") return "gaia";                                  // un cumulo: siempre su punto (6 % limpias en M 13)
   if (cat === "clean" || cat === "saturated") return (mode === "photo-colour") ? "colour" : "sprite";
   if ((cat === "double" || cat === "contaminated") && r5 !== "r4") return "gaia";
   if (mode === "photo-colour") return "gaia";                            // su color de la foto no vale (vecina, debil, borde)
   if (r4 === "b") return "synth-photo";
   if (r4 === "c") return "synth-gaia";
   if (r4 === "d") return "colour";
   return "gaia";
}
// LA ESCALA del recorte en pantalla: pixeles de pantalla por pixel de la foto grande (`bigPx` = su lado mayor). «photo»,
// con la perspectiva a su profundidad (`pw`, de cpSvDistProject); «photo-size», la del plano de la foto en su sitio
// (`w0`, la perspectiva en t = 0). Con tope: el radio `R` (pixeles de la foto) no pasa de `capPx`.
function cpSvSpriteScale(mode, scale, pw, w0, bigPx, R, capPx) {
   var k = scale * ((mode === "photo-size") ? w0 : pw) / Math.max(1, bigPx);
   if (capPx > 0 && R > 0 && k * R > capPx) k = capPx / R;
   return k;
}
// DONDE ESTA LA CAMARA, en la caja: { u, v, t }. La camara de cpSvDistCam esta a K de su pivote, mirando por `fwd`.
function cpSvCamBox(fit) {
   var P = fit.pose, V = fit.view, K = fit.K, flat = (V.flat > 0.05) ? V.flat : 0.05;
   var X = K * P.cp * P.sy, Y = K * P.sp, Z = -K * P.cp * P.cy;
   return { u: V.ox + X, v: V.oy + Y, t: (fit.depth / 2 + V.oz + Z / flat) / fit.depth };
}
// EL BRILLO QUE GANA una estrella en un vuelo: (d0 / d)², con d0 su distancia desde la Tierra (pc) y d la que hay desde la
// camara (pc): la diferencia de profundidades y, de lado, `latPc`. Con topes PS_GAIN_MIN … PS_GAIN_MAX.
function cpSvFlightGain(pcStar, pcCam, latPc) {
   if (!(pcStar > 0)) return 1;
   var dz = pcStar - Math.max(0, pcCam || 0), d = Math.sqrt(dz * dz + (latPc || 0) * (latPc || 0)), g = (d > 0) ? (pcStar / d) * (pcStar / d) : Infinity;
   return Math.max(CP_SV.PS_GAIN_MIN, Math.min(CP_SV.PS_GAIN_MAX, g));
}
