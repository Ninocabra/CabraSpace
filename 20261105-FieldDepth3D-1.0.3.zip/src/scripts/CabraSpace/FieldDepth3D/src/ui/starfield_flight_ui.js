// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_flight_ui.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_flight_ui.js — LA FILA «Flight» del panel de «Distances»
// ----------------------------------------------------------------------------
// (14-oct-2026.) Encargo de Nino: «permite grabar un video donde tu has definido
// las camaras y por donde vuelas por el interior de tu imagen… lo mas facil
// posible, pero potente y bonito». El vuelo es de `ui/starfield_flight.js` (puro),
// el fotograma lo pinta `ui/starfield_flight_paint.js` y el video lo escribe
// `engine/video_avi.js`; aqui estan los MANDOS, que son metodos de `CPStarfieldDock`:
//
//   [ Dive · Orbit · Grand tour · My flight ]  [ duracion ] s   ▶   ＋  −        ● Record…
//      └ al pulsar «Record…» se abre debajo, y solo entonces, lo minimo:
//        [ tamaño ] [ 30 / 60 ] [ titulo ]
//        [ carpeta ] [ … ]                                              [ Start ]
//
// DECISIONES (Nino estaba fuera; van en CONTINUAR_AQUI para que las cambie):
//   · UNA FILA COMPACTA, no una seccion: solo existe en «Distances» en perspectiva y
//     mide lo que un boton. Las opciones de grabar NO son un cuadro modal: son dos
//     filas que se abren debajo y se cierran al empezar (un modal encima de un
//     dialogo modal es justo lo que este proyecto evita: CONTINUAR_AQUI §5c, §5i);
//   · LA VISTA PREVIA va en el propio lienzo, a tiempo real, encajada a la proporcion
//     del video elegido. No toca la vista del panel: al parar (un clic en el lienzo,
//     el mismo boton o Esc) el lienzo vuelve a enseñar lo que enseñaba;
//   · GRABAR va por tics de un `Timer` (`R.step()`): la interfaz sigue viva, con los
//     mandos apagados como en un lote (`_batchLock`) y el boton convertido en
//     «Cancel». LA BARRA DE PROGRESO SE PINTA DENTRO DEL LIENZO, en su borde de abajo:
//     no hay ningun control que aparezca ni nada que se desplace;
//   · CANCELAR borra lo que la propia grabacion llevaba escrito (un video a medias no
//     es lo que se pidio) y deja el panel como estaba;
//   · el formato no se pregunta: MP4 si hay ffmpeg, AVI si no (lo dice el tooltip);
//   · «My flight» se guarda CON LA IMAGEN (una propiedad de la vista) y lo elegido
//     en la fila (vuelo, tamaño, ritmo, carpeta) se recuerda entre sesiones.
//
// NADA SE CALCULA NI SE EJECUTA EN `onPaint`: el lienzo copia un bitmap ya hecho.
// Los tics respetan la zona tranquila (`cpQuiet`). Medidas y colores, de Atlas. ES5.
// ============================================================================

var CP_SFFL = {
   KINDS: ["dive", "orbit", "tour", "user"],
   // lo que se puede grabar: 16:9 (lo normal), y cuadrado y vertical para redes (el vuelo se hace para esa proporcion)
   SIZES: [{ key: "1080p", w: 1920, h: 1080, text: "1080p · 16:9" }, { key: "4k", w: 3840, h: 2160, text: "4K · 16:9" },
           { key: "square", w: 1080, h: 1080, text: "1080 · 1:1" }, { key: "vertical", w: 1080, h: 1920, text: "1080 × 1920 · 9:16" }],
   FPS: [30, 60],
   PREVIEW_TICK_S: 0.016,             // la vista previa: el tic de las transiciones
   RECORD_TICK_S: 0.002,              // grabar: un fotograma por tic, sin esperar entre ellos
   SHOW_EVERY_MS: 90,                 // al grabar, el lienzo enseña el fotograma que va saliendo cada tanto (no todos: cuesta)
   BAR: CP_ATLAS.space[0],            // grosor de la barra de progreso (dentro del lienzo, abajo)
   DUR_W: CP_ATLAS.space[6] + CP_ATLAS.space[1],     // ancho del campo de la duracion
   PANEL_W: CP_ATLAS.space[9] * 2 + CP_ATLAS.space[8],    // ancho del panel de opciones (superpuesto al lienzo, arriba a la derecha, bajo «▾»: lo justo)
   DUR_MIN: 4, DUR_MAX: 180,
   PROP: "CabraPilot:Flight",         // «My flight», en la imagen
   PROP_TYPE: 46, PROP_ATTR: 0x80 | 0x20     // (los de la marca del modo preview: una cadena, que se guarda con la imagen)
};
// COSTURAS PARA PRUEBAS: `CP_SF_FLIGHT_HOOK( "dir", sugerida ) -> carpeta | null` contesta en vez del cuadro de elegir
// carpeta (que sin pantalla no vuelve), y `CP_SF_FLIGHT_CLOCK` es el reloj de la vista previa (milisegundos).
var CP_SFFL_ROW_STAYS = true;        // la fila sigue en su sitio en «Side» (apagado: desaparece y todo sube; el control de las pruebas)
// (14-oct-2026, regresion vista por Nino en CabraPilot: las transiciones se cortaban) LA FILA GUARDA SU ALTO cuando se esconde,
// vacia: el lienzo mide lo mismo con ella y sin ella y una transicion no se corta. (En CabraPilot era por el HR; Cabra3D no lo
// tiene y el puntal queda para cuando la fila se esconde.)
var CP_SFFL_ROW_KEEPS_HEIGHT = true;
var CP_SFFL_CANCEL_ASKS = true;     // (Q3) «Cancel» pregunta (quedarse con lo grabado / borrarlo / seguir); apagado: borra sin preguntar (el control de las pruebas)
var CP_SF_FLIGHT_HOOK = null;
var CP_SF_FLIGHT_CLOCK = function() { return Date.now(); };

function cpSfFlRead(key, type, fallback) {
   try { var v = Settings.read(CP_SETTINGS_PREFIX + "/Starfield/flight/" + key, type); if (v !== null && v !== undefined && Settings.lastReadOK !== false) return v; } catch (e) {}
   return fallback;
}
function cpSfFlWrite(key, type, value) {
   if (CP_NO_MAIN) return;        // las pruebas no tocan lo recordado de verdad
   try { Settings.write(CP_SETTINGS_PREFIX + "/Starfield/flight/" + key, type, value); } catch (e) {}
}

// UN CAMPO QUE SE VE EDITABLE (14-oct-2026, vuelta 3). El contenedor del panel lleva una hoja sin selector («fondo
// transparente, sin borde») que Qt aplica tambien a sus hijos: un `Edit` o un desplegable dentro de el salian planos, sin
// caja, y no se sabia que se podian tocar. Cada campo lleva la suya, con los mismos colores que los campos del resto del
// programa (la hoja global: `CP_UI`).
function cpSfFlField(ctrl) {
   cpApplyStyle(ctrl, "background-color:" + CP_UI.bgInset + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_UI.radius + "; padding:3px 7px;");
}

// LOS MANDOS. Lo llama el constructor del panel, justo despues de su fila de mandos.
//   la fila:      [vuelo ▾]  Duration [18] s   [▶ Preview] [＋] [−]            [● Record] [▾]
//   las opciones: un panel SUPERPUESTO al lienzo (hijo suyo, sin sizer: no cambia el alto de nada ni desplaza la imagen;
//                 revision visual del 14-oct-2026: las dos filas de antes empujaban y reescalaban el lienzo), arriba a la
//                 derecha, bajo el boton que lo abre:  Size [1080p ▾] [30 fps ▾] · Title [……] · Save to [……] […]
// «● Record» GRABA YA con lo recordado (un paso, no dos); «▾» abre las opciones.
function cpSfFlButton(parent, text, tipKey, onClick) {
   var b = new PushButton(parent);
   b.text = text; b.toolTip = cpTooltip(tipKey); b.cpTipKey = tipKey; b.onClick = onClick;
   cpStyleToggle(b, false);
   return b;
}
function cpSfFlLabel(parent, text) {
   var l = new Label(parent);
   l.text = text; l.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   cpStyleHint(l);
   return l;
}
CPStarfieldDock.prototype._flightBuild = function() {
   var self = this, C = this.rowsBox, i, button = cpSfFlButton, label = cpSfFlLabel;     // (la caja de los mandos del panel: ver «rowsBox»)
   var kind = String(cpSfFlRead("kind", DataType_String, "dive"));
   this.fl = { kind: (CP_SFFL.KINDS.indexOf(kind) >= 0) ? kind : "dive", dur: {}, strip: false, size: Math.max(0, Math.min(CP_SFFL.SIZES.length - 1, Number(cpSfFlRead("size", DataType_Int32, 0)) || 0)),
               fps: (Number(cpSfFlRead("fps", DataType_Int32, 30)) === 60) ? 60 : 30, title: "", dir: "", dirWhy: "", preview: null, rec: null, show: null, last: null, prepared: null, saidText: null, saidSig: "", building: true };
   this.flPanel = null;
   this.flCombo = new ComboBox(C);
   cpSfFlField(this.flCombo);
   this.flCombo.toolTip = cpTooltip("sf.flight.kind");
   this.flCombo.onItemSelected = function(index) { if (!self.fl.building) self.flightSetKind(CP_SFFL.KINDS[index]); };
   // la duracion: un campo de texto con su rotulo (el proyecto no usa `SpinBox` en ningun otro sitio: sus flechas salian blancas)
   this.flDurLabel = label(C, optT("Duration"));
   this.flDurLabel.toolTip = cpTooltip("sf.flight.duration");
   this.flDur = new Edit(C);
   cpSfFlField(this.flDur);
   try { this.flDur.setFixedWidth(cpUiPx(CP_SFFL.DUR_W, this.flDur)); } catch (eW) {}
   this.flDur.toolTip = cpTooltip("sf.flight.duration");
   this.flDur.onEditCompleted = function() { if (!self.fl.building) self.flightSetDuration(parseFloat(String(self.flDur.text).replace(",", "."))); };
   this.flDurUnit = label(C, "s");
   this.flPlay = button(C, "▶ " + optT("Preview"), "sf.flight.play", function() { self.flightPreviewToggle(); });
   this.flAdd = button(C, "＋", "sf.flight.add", function() { self.flightAddKey(); });
   // (Cabra3D, 20-oct: el «−» —quitar solo la ULTIMA— se fue: lo sustituye el EDITOR DE CAMARAS, una lista con cada vista
   // (ver ui/flight_editor.js). `flDel` queda como otro nombre del mismo boton para lo que aun lo nombra.)
   this.flEdit = button(C, "☰", "sf.flight.edit", function() { self.flightEditorToggle(); });
   this.flDel = this.flEdit;
   this._flightEdBuild();
   this.flRec = button(C, "● " + optT("Record"), "sf.flight.record", function() { self.flightRecordButton(); });
   this.flOpt = button(C, "▾", "sf.flight.options", function() { self.flightOptionsToggle(); });
   // EL PUNTAL: un control vacio y transparente, del alto de la fila, que se ve cuando la fila no. Sin el, el lienzo crece
   // 42 px al esconderla y una transicion en marcha se corta (el lienzo cambia y `_render` la tira).
   // Medido con el dialogo a la vista: `_tests/cp_starfield_anim_live.js` (14-oct-2026).
   this.flStrut = new Control(C);
   cpApplyStyle(this.flStrut, "background-color:transparent; border:none;");
   try { this.flStrut.setFixedWidth(1); } catch (eS) {}
   cpSetControlVisible(this.flStrut, false);
   // (Cabra3D: la fila la arma `_c3Layout` —ui/groups.js—, en el grupo «Vuelo y video»)

   // UN TIC para las dos cosas (nunca a la vez): la vista previa y la grabacion.
   this.flTimer = new Timer;
   this.flTimer.periodic = true;
   this.flTimer.interval = CP_SFFL.PREVIEW_TICK_S;
   this.flTimer.onTimeout = function() {
      if (cpQuiet()) return;                                 // zona tranquila: este tic no hace nada
      self._flightTick();
   };
   this._flightNames();
   this.fl.building = false;
};
// LAS OPCIONES DE GRABAR, superpuestas al lienzo. Se hacen la primera vez que hacen falta (`_flightSync`): cuando el
// constructor del panel hace la fila, EL LIENZO AUN NO EXISTE, y un control sin padre es una ventana suelta (visto en la
// primera captura: el panel de opciones no salia en el lienzo).
CPStarfieldDock.prototype._flightPanelBuild = function() {
   var self = this, i, button = cpSfFlButton, label = cpSfFlLabel;
   var Pn = this.flPanel = new Control(this.canvas);
   cpApplyStyle(Pn, "background-color:" + CP_UI.bgPanel + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_UI.radius + ";");
   this.flSizeLabel = label(Pn, optT("Size"));
   this.flSize = new ComboBox(Pn);
   cpSfFlField(this.flSize);
   for (i = 0; i < CP_SFFL.SIZES.length; ++i) this.flSize.addItem(CP_SFFL.SIZES[i].text);
   this.flSize.currentItem = this.fl.size;
   this.flSize.toolTip = cpTooltip("sf.flight.size");
   this.flSize.onItemSelected = function(index) { self.fl.size = index; cpSfFlWrite("size", DataType_Int32, index); self._flightSync(); };
   this.flFps = new ComboBox(Pn);
   cpSfFlField(this.flFps);
   for (i = 0; i < CP_SFFL.FPS.length; ++i) this.flFps.addItem(CP_SFFL.FPS[i] + " fps");
   this.flFps.currentItem = Math.max(0, CP_SFFL.FPS.indexOf(this.fl.fps));
   this.flFps.toolTip = cpTooltip("sf.flight.fps");
   this.flFps.onItemSelected = function(index) { self.fl.fps = CP_SFFL.FPS[index]; cpSfFlWrite("fps", DataType_Int32, self.fl.fps); };
   this.flTitleLabel = label(Pn, optT("Title"));
   this.flTitle = new Edit(Pn);
   cpSfFlField(this.flTitle);
   this.flTitle.toolTip = cpTooltip("sf.flight.title");
   this.flTitle.onEditCompleted = function() { var tt = String(self.flTitle.text); self.fl.title = (tt === self._flightTitle()) ? "" : tt; };
   this.flDirLabel = label(Pn, optT("Save to"));
   this.flDir = new Edit(Pn);
   cpSfFlField(this.flDir);
   this.flDir.toolTip = cpTooltip("sf.flight.dir");
   this.flDir.onEditCompleted = function() { self.fl.dir = String(self.flDir.text).split("\\").join("/"); self.fl.dirWhy = "typed"; };
   this.flBrowse = button(Pn, "…", "sf.flight.dir", function() { self.flightBrowse(); });
   // (3-nov-2026, CPD C3) EL FORMATO: AVI (de fabrica, sin programas externos) o MP4 con ffmpeg, SOLO si el usuario lo elige: con el
   // ejecutable que el elige («…») o dejando que el programa lo busque. La logica es de CabraShared/csh_ffmpeg.js.
   this.flFmtLabel = label(Pn, optT("Format"));
   this.flFmt = new ComboBox(Pn);
   cpSfFlField(this.flFmt);
   this._flightFmtNames();
   this.flFmt.toolTip = cpTooltip("sf.flight.format");
   this.flFmt.onItemSelected = function(index) { if (!self.fl.building) self.flightSetFfmpegMode(CSH_FFMPEG_MODES[index]); };
   this.flFfPick = button(Pn, "…", "sf.flight.ffpick", function() { self.flightPickFfmpeg(); });
   this._flightLabelWidths();
   function line(a, b, c) {
      var s = new HorizontalSizer;
      cpGap(s, CP_SFUI.GAP);
      s.add(a); s.add(b, 100); if (c) s.add(c);
      return s;
   }
   Pn.sizer = new VerticalSizer;
   cpMargin(Pn.sizer, CP_ATLAS.space[1]); cpGap(Pn.sizer, CP_SFUI.GAP);
   Pn.sizer.add(line(this.flSizeLabel, this.flSize, this.flFps));
   Pn.sizer.add(line(this.flTitleLabel, this.flTitle, null));
   Pn.sizer.add(line(this.flDirLabel, this.flDir, this.flBrowse));
   Pn.sizer.add(line(this.flFmtLabel, this.flFmt, this.flFfPick));
   try { Pn.setFixedWidth(cpUiPx(CP_SFFL.PANEL_W, Pn)); } catch (eP) {}
   cpSetControlVisible(Pn, false);
};

// El ancho comun de las tres etiquetas del panel (Size / Title / Save to). (1-nov-2026, D2 del video de formacion: se media UNA vez, al
// construir el panel, con el texto del idioma de ese momento —«Save to»—; al pasar a castellano «Guardar en» (73 px) se cortaba en los 61 del
// ancho viejo, «Guardar e». Ahora se mide con el texto vigente cada vez que cambia: al construir y al traducir.) Costura del rojo:
// C3_FL_LABELW_ONCE = true (como antes: solo al construir).
var C3_FL_LABELW_ONCE = false;
CPStarfieldDock.prototype._flightLabelWidths = function() {
   var labs = [this.flSizeLabel, this.flTitleLabel, this.flDirLabel, this.flFmtLabel], lw = 0, i;
   for (i = 0; i < labs.length; ++i) { try { lw = Math.max(lw, labs[i].font.width(labs[i].text)); } catch (eL) {} }
   for (i = 0; i < labs.length; ++i) { try { labs[i].setFixedWidth(lw + cpUiPx(CP_ATLAS.space[1], labs[i])); } catch (eL2) {} }
   this._flLabelW = lw;
   return lw;
};
// ---------------------------------------------------------------------------------------------------------------------------
// (3-nov-2026, CPD C3) EL FORMATO DEL VIDEO Y ffmpeg (CabraShared/csh_ffmpeg.js). Tres estados: «AVI (no ffmpeg)» (de fabrica),
// «MP4 · ffmpeg chosen by me…» (el ejecutable que se elige con «…»; si aun no hay ninguno, el cuadro se abre al elegir la opcion) y
// «MP4 · find ffmpeg for me» (la busqueda de antes). Se recuerda (CP_SETTINGS_PREFIX/Video/ffmpegMode y …/ffmpegManual).
// -> el texto de «Format: …» del tooltip de «Record»
function cpSfFlFormatSay(ff) {
   if (ff && ff.available) return optT("Format: MP4 (H.264).") + " ffmpeg: " + ff.path;
   if (!ff || ff.mode === "off") return optT("Format: AVI (Motion JPEG). For MP4, choose ffmpeg in ▾ Format.");
   return optT("Format: AVI (Motion JPEG): ffmpeg was not found.") + (ff.why ? " (" + ff.why + ")" : "");
}
CPStarfieldDock.prototype._flightFmtNames = function() {
   if (!this.flFmt) return;
   var was = this.fl.building;
   this.fl.building = true;
   try {
      while (this.flFmt.numberOfItems > 0) this.flFmt.removeItem(this.flFmt.numberOfItems - 1);
      for (var i = 0; i < CSH_FFMPEG_MODES.length; ++i) this.flFmt.addItem(optT(cshFfmpegModeText(CSH_FFMPEG_MODES[i])));
      this.flFmt.currentItem = Math.max(0, CSH_FFMPEG_MODES.indexOf(cshFfmpegMode(CP_SETTINGS_PREFIX)));
   } catch (e) {}
   this.fl.building = was;
};
// lo que se ve del formato, con lo que dice la busqueda: la opcion elegida, «…» activo solo con «chosen by me», y el tooltip con la ruta
// (3-nov, revisión) «…» SOLO con «chosen by me»: con AVI o «find ffmpeg for me» no sirve, y dos «…» iguales en el panel (el de la carpeta y
// este) confundían. `strip` = el panel ▾ se ve (si no se pasa, no se toca la visibilidad).
CPStarfieldDock.prototype._flightFmtSync = function(ff, strip) {
   if (!this.flFmt) return;
   ff = ff || cpAviFfmpeg();
   if (strip !== undefined) cpSetControlVisible(this.flFfPick, strip === true && ff.mode === "manual");
   var was = this.fl.building;
   this.fl.building = true;
   try { this.flFmt.currentItem = Math.max(0, CSH_FFMPEG_MODES.indexOf(ff.mode || "off")); } catch (e) {}
   this.fl.building = was;
   try { this.flFfPick.enabled = (ff.mode === "manual") && this.fl.rec === null; } catch (e2) {}
   var where = ff.available ? ("<br>ffmpeg: " + ff.path) : ((ff.mode !== "off" && ff.why) ? "<br>" + ff.why : "");
   try { this.flFmt.toolTip = cpWrapTooltip(cpTooltipText("sf.flight.format") + where); } catch (e3) {}
   try { this.flFfPick.toolTip = cpWrapTooltip(cpTooltipText("sf.flight.ffpick") + ((ff.mode === "manual" && ff.path) ? "<br>" + ff.path : "")); } catch (e4) {}
};
// elegir el modo (desde el desplegable). «chosen by me» sin ejecutable elegido abre el selector; si se cancela, se queda el modo de antes.
CPStarfieldDock.prototype.flightSetFfmpegMode = function(mode) {
   var before = cshFfmpegMode(CP_SETTINGS_PREFIX);
   if (mode === "manual") {
      var cur = cshFfmpegManualPath(CP_SETTINGS_PREFIX), has = false;
      try { has = cur.length > 0 && File.exists(cur); } catch (eE) {}
      if (!has) {
         var p = cshFfmpegPick(CP_SETTINGS_PREFIX, cur);
         if (p === null) { this._flightFmtSync(cpAviFfmpeg(true), this.fl.strip === true); return { ok: false, mode: before, why: "cancelled" }; }
         cshFfmpegSetManualPath(CP_SETTINGS_PREFIX, p);
      }
   }
   cshFfmpegSetMode(CP_SETTINGS_PREFIX, mode);
   var ff = cpAviFfmpeg(true);
   this._flightSync();
   this._flightSay(cpSfFlFormatSay(ff), (ff.available || mode === "off") ? "ok" : "error", ff.path || "");
   return { ok: true, mode: ff.mode, ff: ff };
};
// el «…»: elegir (o cambiar) el ejecutable de ffmpeg. Deja el modo en «chosen by me».
CPStarfieldDock.prototype.flightPickFfmpeg = function() {
   var p = cshFfmpegPick(CP_SETTINGS_PREFIX, cshFfmpegManualPath(CP_SETTINGS_PREFIX));
   if (p === null) return { ok: false, why: "cancelled" };
   cshFfmpegSetManualPath(CP_SETTINGS_PREFIX, p);
   return this.flightSetFfmpegMode("manual");
};
CPStarfieldDock.prototype._flightNames = function() {
   var was = this.fl.building, names = [optT("Dive"), optT("Orbit"), optT("Grand tour"), optT("My flight")];
   this.fl.building = true;
   try { while (this.flCombo.numberOfItems > 0) this.flCombo.removeItem(this.flCombo.numberOfItems - 1); } catch (e) {}
   for (var i = 0; i < names.length; ++i) this.flCombo.addItem(names[i]);
   this.flCombo.currentItem = Math.max(0, CP_SFFL.KINDS.indexOf(this.fl.kind));
   this.fl.building = was;
};

// ¿Hay fila? Solo en «Distances», en perspectiva y con algo calculado.
CPStarfieldDock.prototype._flightAvailable = function() {
   return this.mode === "dist" && this.pose === "perspective" && this.state !== null && !this._closed;
};
CPStarfieldDock.prototype.flightBusy = function() { return !!(this.fl && (this.fl.preview !== null || this.fl.rec !== null)); };

// DONDE SE GUARDA, de fabrica: la ultima carpeta que se uso; si no hay, la del fichero de la imagen; si la imagen no
// tiene fichero, la carpeta de videos del usuario (`File.homeDirectory`: sin rutas escritas). { dir, why }.
CPStarfieldDock.prototype._flightDefaultDir = function() {
   var last = cpSfUiLastDir();
   if (last.length > 0) return { dir: last.split("\\").join("/"), why: "last" };
   try {
      var rec = this.dialog.findRecById(this.state.viewId), p = (rec && optSafeView(rec.view)) ? String(rec.view.window.filePath || "") : "";
      if (p.length > 0) { var d = (File.extractDrive(p) + File.extractDirectory(p)).split("\\").join("/"); if (File.directoryExists(d)) return { dir: d, why: "image" }; }
   } catch (e) {}
   var home = String(File.homeDirectory).split("\\").join("/"), names = ["Videos", "Movies"];
   for (var i = 0; i < names.length; ++i) if (File.directoryExists(home + "/" + names[i])) return { dir: home + "/" + names[i], why: "videos" };
   return { dir: home, why: "home" };
};
// El panel de opciones, en su sitio: arriba a la derecha del lienzo (bajo «▾»). No esta en ningun sizer.
CPStarfieldDock.prototype._flightPanelPlace = function() {
   var Pn = this.flPanel, pad = cpUiPx(CP_SFUI.GAP, this.canvas);
   try {
      Pn.adjustToContents();
      Pn.move(Math.max(pad, this.canvas.width - Pn.width - pad), pad);
      Pn.bringToFront();
   } catch (e) {}
};

// EL ALTO DE LA FILA cuando se ve: el mayor de lo que piden sus mandos (`adjustToContents` = su tamaño preferido, que es el
// que les da el sizer: alto fijo). Se mide con la fila ESCONDIDA, asi que no mueve nada de lo que se ve.
CPStarfieldDock.prototype._flightRowH = function() {
   var ctl = [this.flCombo, this.flDur, this.flPlay, this.flRec, this.flOpt, this.flDurLabel], h = 0;
   for (var i = 0; i < ctl.length; ++i) { try { ctl[i].adjustToContents(); h = Math.max(h, ctl[i].height); } catch (e) {} }
   return h;
};

// Lo que se ve y lo que se puede pulsar. Lo llama `_syncButtons`.
CPStarfieldDock.prototype._flightSync = function() {
   if (!this.fl) return;
   if (!this.flPanel) { if (!this.canvas) return; this._flightPanelBuild(); }
   // (vuelta 4) LA FILA CONSERVA SU SITIO en las dos vistas de «Distances»: al pasar a «Side» desaparecia y todo subia 42 px.
   // De lado se queda, apagada, y su tooltip dice por que. `can` = se puede volar (en perspectiva).
   var can = this._flightAvailable(), on = (CP_SFFL_ROW_STAYS === true) ? (this.mode === "dist" && this.state !== null && !this._closed) : can;
   var user = (this.fl.kind === "user"), prev = (this.fl.preview !== null), rec = (this.fl.rec !== null), strip = can && this.fl.strip && !rec && !prev;
   var row = [this.flCombo, this.flDurLabel, this.flDur, this.flDurUnit, this.flPlay, this.flRec, this.flOpt], i;
   for (i = 0; i < row.length; ++i) cpSetControlVisible(row[i], on);
   cpSetControlVisible(this.flAdd, on && user); cpSetControlVisible(this.flEdit, on && user);
   this._flightEdShow(on && can && user);          // (el editor de camaras: la lista solo se ve abierta, en «My flight» y en perspectiva)
   // el puntal: con el panel abierto y la fila escondida, la fila guarda su alto (`CP_SFFL_ROW_KEEPS_HEIGHT`)
   // (a pantalla completa no hace falta: el lienzo no depende del alto de las filas)
   var strut = (CP_SFFL_ROW_KEEPS_HEIGHT === true) && !on && this.mode !== "" && !this._closed && !(this.isFullScreen && this.isFullScreen());
   if (strut) { var rh = this._flightRowH(); if (rh > 0 && this.fl.strutH !== rh) { try { this.flStrut.setFixedHeight(rh); this.fl.strutH = rh; } catch (eH) {} } }
   cpSetControlVisible(this.flStrut, strut);
   var st2 = [this.flPanel, this.flSizeLabel, this.flSize, this.flFps, this.flTitleLabel, this.flTitle, this.flDirLabel, this.flDir, this.flBrowse, this.flFmtLabel, this.flFmt, this.flFfPick];
   for (i = 0; i < st2.length; ++i) cpSetControlVisible(st2[i], strip);
   // (lo que dijo un vuelo —«Recording cancelled…»— caduca al cambiar de vista: vuelve a decirse el estado del panel)
   var sig = this.mode + "|" + this.pose + "|" + this.scaleMode + "|" + this.unit;
   if (this.fl.saidText !== null && sig !== this.fl.saidSig && !prev && !rec) {
      var mine = (this.said && this.said.text === this.fl.saidText);
      this.fl.saidText = null;
      if (mine && this.mode !== "") { try { this._sayState(); } catch (eS) {} }
   }
   this.fl.saidSig = sig;
   if (!on) return;
   if (!can) {
      var off = [this.flCombo, this.flDur, this.flPlay, this.flRec, this.flOpt, this.flAdd, this.flEdit], why = cpWrapTooltip(optT("Flights go through the perspective view: switch to «Perspective» to preview or record one."));
      for (i = 0; i < off.length; ++i) { try { off[i].enabled = false; off[i].toolTip = why; } catch (eO) {} }
      this.fl.tipsOff = true;
      return;
   }
   if (this.fl.tipsOff === true) { this.fl.tipsOff = false; this._flightTips(); }
   var st = this.state, mineF = this._flightMine(), keys = mineF ? mineF.keys.length : 0, playable = !user || keys >= 2, idle = !prev && !rec;
   this._flightLoad();
   this.fl.building = true;
   try {
      this.flCombo.currentItem = Math.max(0, CP_SFFL.KINDS.indexOf(this.fl.kind));
      var dtx = String(Math.round(this._flightDuration()));
      if (String(this.flDur.text) !== dtx) this.flDur.text = dtx;
      // (el titulo escrito a mano es de ESA imagen; sin escribir nada, el del campo, que puede cambiar al llegar la red)
      if (this.fl.titleKey !== st.key) { this.fl.title = ""; this.fl.titleKey = st.key; }
      if (this.fl.dir.length === 0) { var dd = this._flightDefaultDir(); this.fl.dir = dd.dir; this.fl.dirWhy = dd.why; }
      if (strip) {
         this.flTitle.text = (this.fl.title.length > 0) ? this.fl.title : this._flightTitle(); this.flDir.text = this.fl.dir;
         this.flSize.currentItem = this.fl.size; this.flFps.currentItem = Math.max(0, CP_SFFL.FPS.indexOf(this.fl.fps));
      }
   } finally { this.fl.building = false; }
   if (strip) this._flightPanelPlace();
   this.flPlay.text = prev ? ("■ " + optT("Stop")) : ("▶ " + optT("Preview"));
   this.flRec.text = rec ? ("■ " + optT("Cancel")) : ("● " + optT("Record"));
   cpStyleToggle(this.flPlay, prev); cpStyleToggle(this.flRec, rec); cpStyleToggle(this.flOpt, strip); cpStyleToggle(this.flAdd, false); cpStyleToggle(this.flEdit, this.fl.ed.open);
   try {
      this.flCombo.enabled = idle; this.flDur.enabled = idle && (!user || keys >= 2);
      this.flPlay.enabled = !rec && playable; this.flRec.enabled = !prev && (rec || playable);
      this.flAdd.enabled = idle && keys < CP_FL.MAX_KEYS; this.flEdit.enabled = idle;
      this.flOpt.enabled = idle;
   } catch (e) {}
   var ff = cpAviFfmpeg(), sz = CP_SFFL.SIZES[this.fl.size];
   try { this.flRec.toolTip = cpWrapTooltip(cpTooltipText("sf.flight.record") + " " + format(optT("Now: %s, %d fps, to %s."), sz.text, this.fl.fps, this.fl.dir) + " " + cpSfFlFormatSay(ff)); } catch (e2) {}
   this._flightFmtSync(ff, strip);
   try { this.flAdd.toolTip = cpWrapTooltip(cpTooltipText("sf.flight.add") + " " + format(optT("Views now: %d."), keys)); } catch (e3) {}
   // (la ruta entera, en el tooltip de su campo: el campo enseña el final)
   try { this.flDir.toolTip = cpWrapTooltip(cpTooltipText("sf.flight.dir") + "<br>" + this.fl.dir); } catch (e4) {}
   this._flightEdRefresh();
};
// Los tooltips de fabrica de la fila (tras haber estado apagada de lado, o al cambiar de idioma).
CPStarfieldDock.prototype._flightTips = function() {
   var all = [this.flCombo, this.flDurLabel, this.flDur, this.flPlay, this.flAdd, this.flSize, this.flFps, this.flTitle, this.flDir, this.flBrowse, this.flOpt, this.flRec];
   var keys = ["sf.flight.kind", "sf.flight.duration", "sf.flight.duration", "sf.flight.play", "sf.flight.add", "sf.flight.size", "sf.flight.fps", "sf.flight.title", "sf.flight.dir", "sf.flight.dir", "sf.flight.options", "sf.flight.record"];
   for (var i = 0; i < all.length; ++i) { try { all[i].toolTip = cpTooltip(keys[i]); } catch (e) {} }
};
// Lo que dice un vuelo en la pildora (se apunta: caduca al cambiar de vista).
CPStarfieldDock.prototype._flightSay = function(text, kind, detail) {
   this._say(text, kind, detail);
   this.fl.saidText = String(text);
};

// El titulo que se propone: el PROTAGONISTA del campo si tiene nombre (el cumulo, el motivo de la foto, una galaxia de
// catalogo: `cpFlProtagonist`, la misma definicion que usan los vuelos); si no, el del panel (el nombre de la imagen).
CPStarfieldDock.prototype._flightTitle = function() {
   var st = this.state, model = this._distModel();
   var p = cpFlProtagonist(model);
   if (p >= 0 && model.objects[p].kind !== "star" && String(model.objects[p].name).length > 0) return String(model.objects[p].name);
   return String(st.title);
};
// «My flight» de la imagen que se enseña (o null).
CPStarfieldDock.prototype._flightMine = function() { return (this.state && this.state.myFlight) ? this.state.myFlight : null; };
// …leido de la imagen la primera vez que hace falta.
CPStarfieldDock.prototype._flightLoad = function() {
   var st = this.state;
   if (!st || st.myFlightRead === true) return;
   st.myFlightRead = true;
   try {
      var rec = this.dialog.findRecById(st.viewId), text = (rec && optSafeView(rec.view)) ? rec.view.propertyValue(CP_SFFL.PROP) : null;
      if (typeof text === "string" && text.length > 0) { var r = cpFlFromJson(text); if (r.ok && r.flight.keys.length > 0) st.myFlight = r.flight; }
   } catch (e) {}
};
CPStarfieldDock.prototype._flightSave = function() {
   var st = this.state;
   if (!st) return false;
   try {
      var rec = this.dialog.findRecById(st.viewId);
      if (!rec || !optSafeView(rec.view)) return false;
      rec.view.setPropertyValue(CP_SFFL.PROP, st.myFlight ? cpFlToJson(st.myFlight) : "", CP_SFFL.PROP_TYPE, CP_SFFL.PROP_ATTR);
      return true;
   } catch (e) { return false; }
};
// La proporcion del video elegido.
CPStarfieldDock.prototype._flightAspect = function() { var s = CP_SFFL.SIZES[this.fl.size]; return s.w / s.h; };
// EL VUELO ELEGIDO, hecho para una proporcion. null si «My flight» aun no tiene dos vistas.
CPStarfieldDock.prototype._flightOf = function(aspect, height) {
   var model = this._distModel(), scale = cpSvDistScale(this.scaleMode, model, this.unit), kind = this.fl.kind;
   if (kind === "user") {
      var m = this._flightMine();
      return (m && m.keys.length >= 2) ? m : null;
   }
   return cpFlPreset(kind, model, scale, { aspect: aspect, duration: (this.fl.dur[kind] > 0) ? this.fl.dur[kind] : undefined, extent: this._flightExtent(model),
                                         height: (height > 0) ? height : CP_SFFL.SIZES[this.fl.size].h });      // (el tope de ampliacion de un objeto va por el alto del video QUE SE GRABA)
};
// LO QUE BRILLA de cada objeto extenso (para encuadrarlo: `cpFlShine`): la caja que contiene el 90 % de la transparencia
// de su recorte, medida en su mascara de brillo. null = no se ha medido (o no brilla nada): manda el catalogo.
CPStarfieldDock.prototype._flightExtent = function(model) {
   var st = this.state;
   return function(idx) {
      var ob = model.objects[idx];
      if (!ob || !st || (ob.kind === "cluster" && model.counts.members > 0)) return null;
      var key = ob.kind + ":" + ob.ref, c = (st.cutsHi && st.cutsHi[key]) ? st.cutsHi[key] : (st.cuts ? st.cuts[key] : null);
      if (!c || !c.shine || c.matte.flat || !(c.matte.cover > 0.002)) return null;
      return { rx: (c.shine.u1 - c.shine.u0) / 2, ry: (c.shine.v1 - c.shine.v0) / 2, px: c.shine.px };
   };
};
// PREPARAR UN VUELO (una vez, al empezar la vista previa o la grabacion; con «ocupado»: nunca en `onPaint` ni en un tic):
// la foto a varios tamaños y el recorte de VIDEO de cada objeto extenso (y el hueco del cumulo). Lo que tarda queda en
// `this.fl.prepared` = { ms, cuts, photo: [ w, h ], levels }.
CPStarfieldDock.prototype._flightPrepare = function() {
   var st = this.state, t0 = Date.now(), model = this._distModel(), n = 0, pyr = [];
   try { this.dialog.preview.setBusy(true, optT("Preparing the flight…"), false); } catch (e0) {}
   try {
      pyr = this._photoPyramid(st);
      // (los mas grandes primero, y como mucho los que se pintan a la vez mas unos pocos: el resto se haria al vuelo, en su tic)
      var cand = [], i;
      for (i = 0; i < model.objects.length; ++i) {
         var ob = model.objects[i], ext = (ob.ext > 0) ? ob.ext : ((ob.kind === "cluster" && model.counts.members > 0) ? ob.radius : 0);
         if (ext > 0) cand.push({ index: i, ext: ext });
      }
      cand.sort(function(a, b) { return (b.ext - a.ext) || (a.index - b.index); });
      for (i = 0; i < cand.length && n < CP_SV.CUT_MAX + 4; ++i) {
         var oc = model.objects[cand[i].index], rc = cpSvCutoutRect({ ext: cand[i].ext, u: oc.u, v: oc.v }, model.wn, model.hn);
         if (rc !== null && this._cutOf(st, model, { index: cand[i].index, u0: rc.u0, v0: rc.v0, u1: rc.u1, v1: rc.v1, r: rc.r }, true) !== null) ++n;
      }
   } finally { try { this.dialog.preview.setBusy(false); } catch (e1) {} }
   this.fl.prepared = { ms: Date.now() - t0, cuts: n, photo: (pyr.length > 0) ? [pyr[0].width, pyr[0].height] : null, levels: pyr.length };
   return this.fl.prepared;
};
CPStarfieldDock.prototype._flightDuration = function() {
   if (this.fl.kind === "user") { var m = this._flightMine(); return (m && m.keys.length >= 2) ? m.duration : CP_FL.SEG_S; }
   if (this.fl.dur[this.fl.kind] > 0) return this.fl.dur[this.fl.kind];
   var f = this._flightOf(this._flightAspect());
   return f ? f.duration : CP_FL.DUR_DIVE;
};

// --- lo que hacen los mandos -------------------------------------------------------------------
CPStarfieldDock.prototype.flightSetKind = function(kind) {
   if (CP_SFFL.KINDS.indexOf(kind) < 0 || this.flightBusy()) return;
   this.fl.kind = kind;
   cpSfFlWrite("kind", DataType_String, kind);
   this._flightSync();
};
CPStarfieldDock.prototype.flightSetDuration = function(seconds) {
   if (this.flightBusy()) return;
   var s = Math.max(CP_SFFL.DUR_MIN, Math.min(CP_SFFL.DUR_MAX, Math.round(Number(seconds) || 0)));
   if (this.fl.kind === "user") {
      var m = this._flightMine();
      if (m && m.keys.length >= 2) { this.state.myFlight = cpFlSetDuration(m, s); this.state.myFlightFixed = true; this._flightSave(); }
   } else {
      this.fl.dur[this.fl.kind] = s;
      // (vuelta 4: «Orbit» no baja de 6 s; el campo admitia 5 y el video duraba 6. El campo dice lo que DURA y se avisa.)
      var real = this._flightAvailable() ? this._flightOf(this._flightAspect()) : null;
      if (real && Math.round(real.duration) !== s) { this.fl.dur[this.fl.kind] = Math.round(real.duration); this._flightSay(format(optT("This flight lasts at least %d s."), Math.round(real.duration)), "pending"); }
   }
   this._flightSync();
};
// ＋: la vista que el usuario tiene AHORA en el lienzo pasa a ser la siguiente clave de «My flight».
CPStarfieldDock.prototype.flightAddKey = function() {
   if (!this._flightAvailable() || this.flightBusy()) return false;
   var cam = this._flightCurrentCam();                      // (ui/flight_editor.js: la camara del lienzo como camara de vuelo)
   if (cam === null) return false;
   var st = this.state, model = this.lay.model, base = this._flightMine() || cpFlNew(optT("My flight"), model, this._flightAspect());
   var next = cpFlAddKey(base, cam, undefined, st.myFlightFixed === true);
   if (next === base) return false;
   st.myFlight = next;
   this._flightSave();
   this._flightEdReveal(next.keys.length - 1);            // (la lista enseña la vista recien añadida)
   this._flightSync();
   this._flightSay(format(optT("View %d added to «My flight»"), next.keys.length) + ((next.keys.length < 2) ? ". " + optT("Move the camera and press ＋ again.") : ""), "ok");
   return true;
};
// (Cabra3D, 20-oct: ya SIN boton —lo sustituye el editor de camaras, ui/flight_editor.js, que borra cualquiera—; el metodo
// queda para quien lo llame: quita la ultima.)
CPStarfieldDock.prototype.flightDelKey = function() {
   var m = this._flightMine();
   if (!m || m.keys.length === 0 || this.flightBusy()) return false;
   this.state.myFlight = cpFlRemoveKey(m, m.keys.length - 1, false);
   if (this.state.myFlight.keys.length < 2) this.state.myFlightFixed = false;
   this._flightSave();
   this._flightSync();
   this._flightSay(format(optT("«My flight» has %d views"), this.state.myFlight.keys.length), "pending");
   return true;
};
// ¿Se puede volar AHORA? Devuelve "" o por que no (y lo dice en la pildora).
CPStarfieldDock.prototype._flightWhyNot = function() {
   var why = "";
   if (!this._flightAvailable()) why = optT("Open «Distances» in perspective first.");
   // la red tiene la interfaz parada a tramos de medio segundo y al llegar cambia lo que hay en la caja: se espera
   else if (this._netBusy || this._netPending()) why = optT("Still waiting for the online data: try again in a moment.");
   else if (this.fl.kind === "user" && !this._flightOf(1)) why = optT("«My flight» needs at least two views: place the camera and press ＋.");
   if (why.length > 0) this._flightSay(why, "pending");
   return why;
};
// Donde va el fotograma dentro del lienzo: la proporcion del video, centrada.
CPStarfieldDock.prototype._flightRect = function(w, h, aspect) {
   var rw = w, rh = Math.round(w / aspect);
   if (rh > h) { rh = h; rw = Math.round(h * aspect); }
   return { x: Math.floor((w - rw) / 2), y: Math.floor((h - rh) / 2), w: rw, h: rh };
};

// ▶ LA VISTA PREVIA, en el lienzo y a tiempo real. No toca la vista del panel.
CPStarfieldDock.prototype.flightPreviewToggle = function() {
   if (this.fl.preview !== null) { this.flightStop(); return false; }
   return this.flightPreview();
};
CPStarfieldDock.prototype.flightPreview = function() {
   if (this.fl.rec !== null || this.fl.preview !== null || this._flightWhyNot() !== "") return false;
   this._animStop();
   var w = 0, h = 0;
   try { w = this.canvas.width; h = this.canvas.height; } catch (e) {}
   if (!(w > 32 && h > 32)) return false;
   this._flightPrepare();
   var aspect = this._flightAspect(), flight = this._flightOf(aspect), P = cpFlPaintOpen(this, w, h, { rect: this._flightRect(w, h, aspect), hiRes: true, title: (this.fl.title.length > 0) ? this.fl.title : this._flightTitle() });
   if (flight === null || P === null) { cpFlPaintClose(P); return false; }
   this.fl.preview = { P: P, flight: flight, t0: CP_SF_FLIGHT_CLOCK(), frames: 0, w: w, h: h, ctx: { model: P.model, scale: P.scale, fps: 60 } };
   this._flightSync();
   this._flightFrame(0);
   this.flTimer.interval = CP_SFFL.PREVIEW_TICK_S;
   try { this.flTimer.start(); } catch (e2) {}
   return true;
};
CPStarfieldDock.prototype._flightFrame = function(t) {
   var pv = this.fl.preview;
   this.fl.show = cpFlPaintFrame(pv.P, cpFlFrame(pv.flight, t, pv.ctx));
   ++pv.frames;
   try { this.canvas.repaint(); } catch (e) {}
};
// PARAR lo que haya en marcha (la vista previa; o la grabacion, cancelandola). Devuelve true si habia algo.
// La llaman un clic en el lienzo, el propio boton, Esc (`cancelActiveMode`), cerrar el panel y cambiar de imagen.
CPStarfieldDock.prototype.flightStop = function() {
   if (!this.fl) return false;
   // (con una grabacion en marcha, Esc y un clic PREGUNTAN; con la pregunta abierta, Esc es «Continue recording»)
   if (this.fl.rec !== null) {
      if (CP_SFFL_CANCEL_ASKS !== true) { this._flightRecordEnd(true); return true; }
      if (this.fl.rec.ask) this.flightCancelAnswer("continue"); else this.flightCancelAsk();
      return true;
   }
   var pv = this.fl.preview;
   if (pv === null) return false;
   this.fl.preview = null;
   try { this.flTimer.stop(); } catch (e) {}
   this.fl.show = null;
   this.fl.last = { what: "preview", frames: pv.frames, ms: CP_SF_FLIGHT_CLOCK() - pv.t0 };
   cpFlPaintClose(pv.P);
   this._flightSync();
   try { this.canvas.repaint(); } catch (e2) {}
   return true;
};
// ACABAR lo que haya en marcha SIN preguntar (cerrar el panel, cambiar de imagen): una grabacion a medias se borra.
CPStarfieldDock.prototype.flightEnd = function() {
   if (!this.fl) return false;
   if (this.fl.rec !== null) { this._flightRecordEnd(true); return true; }
   return this.flightStop();
};
CPStarfieldDock.prototype._flightTick = function() {
   var pv = this.fl.preview, rc = this.fl.rec;
   if (rc !== null) { this._flightRecordStep(); return; }
   if (pv === null) { try { this.flTimer.stop(); } catch (e) {} return; }
   var w = 0, h = 0;
   try { w = this.canvas.width; h = this.canvas.height; } catch (e1) {}
   var t = (CP_SF_FLIGHT_CLOCK() - pv.t0) / 1000;
   // (el lienzo ha cambiado de tamaño, o el vuelo se ha acabado: fuera)
   if (w !== pv.w || h !== pv.h || !(t < pv.flight.duration)) { this.flightStop(); return; }
   try { this._flightFrame(t); } catch (eF) { this.flightStop(); }
};

// ● GRABAR: graba YA, con lo recordado (un paso; antes eran dos: «Record…» y «Start»); con una grabacion en marcha, la cancela.
CPStarfieldDock.prototype.flightRecordButton = function() {
   if (this.fl.rec !== null) { this.flightStop(); return; }
   if (this.fl.preview !== null) return;
   this.flightRecordStart();
};
// ▾ LAS OPCIONES: abre o cierra el panel superpuesto (tamaño, ritmo, titulo y carpeta).
CPStarfieldDock.prototype.flightOptionsToggle = function() {
   if (this.flightBusy()) return;
   this.fl.strip = !this.fl.strip;
   this._flightSync();
};
CPStarfieldDock.prototype.flightBrowse = function() {
   var dir = null;
   if (typeof CP_SF_FLIGHT_HOOK === "function") dir = CP_SF_FLIGHT_HOOK("dir", this.fl.dir);
   else {
      var gdd = new GetDirectoryDialog;
      gdd.caption = CP_TITLE + " — " + optT("Folder for the video");
      try { if (this.fl.dir.length > 0) gdd.initialPath = this.fl.dir; } catch (e) {}
      dir = gdd.execute() ? String(gdd.directoryPath) : null;
   }
   if (dir === null || String(dir).length === 0) return false;
   this.fl.dir = String(dir).split("\\").join("/"); this.fl.dirWhy = "chosen";
   this.flDir.text = this.fl.dir;
   this._flightSync();
   return true;
};
// Un nombre de fichero que no existe aun: Titulo_vuelo_1920x1080, y _2, _3… si ya esta.
CPStarfieldDock.prototype._flightPath = function(dir, title, kind, size) {
   var base = String(title).replace(/[^A-Za-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
   if (base.length === 0) base = "Flight";
   base = dir + "/" + base + "_" + kind + "_" + size.w + "x" + size.h;
   for (var k = 1; k < 1000; ++k) {
      var p = base + ((k > 1) ? "_" + k : "");
      if (!File.exists(p + ".mp4") && !File.exists(p + ".avi")) return p;
   }
   return base + "_" + Date.now();
};
// EMPEZAR. `opts` (las pruebas): { width, height, fps, dir, title, format }. Devuelve { ok, why }.
CPStarfieldDock.prototype.flightRecordStart = function(opts) {
   var o = opts || {}, out = { ok: false, why: "" };
   if (this.fl.rec !== null || this.fl.preview !== null) { out.why = "busy"; return out; }
   out.why = this._flightWhyNot();
   if (out.why !== "") return out;
   this._animStop();
   // (lo escrito en el panel de opciones, si esta abierto y aun no se ha dado por terminado)
   try { if (this.fl.strip) { var tt = String(this.flTitle.text || ""); this.fl.title = (tt === this._flightTitle()) ? "" : tt; this.fl.dir = String(this.flDir.text || this.fl.dir).split("\\").join("/"); } } catch (e) {}
   var size = (o.width > 0 && o.height > 0) ? { w: o.width, h: o.height } : CP_SFFL.SIZES[this.fl.size], fps = (o.fps > 0) ? o.fps : this.fl.fps;
   var def = (o.dir || this.fl.dir.length > 0) ? null : this._flightDefaultDir();
   var dir = String(o.dir || this.fl.dir || def.dir).split("\\").join("/"), title = String((o.title !== undefined) ? o.title : (this.fl.title || this._flightTitle()));
   if (dir.length === 0 || !File.directoryExists(dir)) { out.why = optT("Choose a folder for the video (▾)."); this._flightSay(out.why, "error"); return out; }
   out.dir = dir;
   this._flightPrepare();
   var flight = this._flightOf(size.w / size.h, size.h), R = null, self2 = this;
   try { R = cpFlRecorder(this, flight, { path: this._flightPath(dir, title, this.fl.kind, size), format: o.format, width: size.w, height: size.h, fps: fps, title: title, hiRes: true, mp4: o.mp4,
                                          frameMs: o.frameMs, onFrame: function(k, bmp) { self2._flightRecordShow(k, bmp); } }); } catch (e2) { R = { ok: false, why: String(e2) }; }
   if (!R.ok) { out.why = R.why; this._flightSay(optT("Could not record the flight") + ": " + R.why, "error"); return out; }
   var w = 0, h = 0;
   try { w = this.canvas.width; h = this.canvas.height; } catch (e3) {}
   this.fl.rec = { R: R, dir: dir, t0: Date.now(), shownAt: 0, w: w, h: h, rect: this._flightRect(Math.max(2, w), Math.max(2, h), size.w / size.h), buf: (w > 8 && h > 8) ? new Bitmap(w, h) : null,
                   locked: null, encoding: false };
   this.fl.strip = false;
   // LOS MANDOS, APAGADOS COMO EN UN LOTE (los del resto del dialogo; los de este panel los apaga `_flightSync` y los de arriba, aqui)
   try { this.fl.rec.locked = this.dialog._batchLock(); } catch (e4) {}
   this._flightDockLock(true);
   this._flightSync();
   // (donde se guarda se dice SIEMPRE al empezar: la primera vez nadie ha elegido carpeta)
   this._flightSay(format(optT("Recording the flight to %s"), dir), "pending", dir);
   this.flTimer.interval = CP_SFFL.RECORD_TICK_S;
   try { this.flTimer.start(); } catch (e5) {}
   out.ok = true;
   return out;
};
// Los mandos de arriba del panel (fuente, vista, escala, exportar, cerrar): apagados mientras se graba.
CPStarfieldDock.prototype._flightDockLock = function(lock) {
   var list = [this.btnPersp, this.btnSide, this.btnLog, this.btnSeg, this.btnLy, this.btnPc, this.btnToView, this.btnToFile, this.zoomSlider];
   for (var i = 0; i < list.length; ++i) { try { if (list[i]) list[i].enabled = !lock; } catch (e) {} }
   if (!lock) this._syncButtons();
};
// El fotograma que acaba de salir, en el lienzo (reducido), con la BARRA DE PROGRESO en el borde de abajo.
CPStarfieldDock.prototype._flightRecordShow = function(k, bmp) {
   var rc = this.fl.rec;
   if (rc === null || rc.buf === null) return;
   var now = Date.now();
   if (k > 0 && k < rc.R.n - 1 && now - rc.shownAt < CP_SFFL.SHOW_EVERY_MS) return;
   rc.shownAt = now;
   var sc = cpUiScale(this.canvas), bar = Math.max(2, Math.round(CP_SFFL.BAR * sc)), w = rc.w, h = rc.h, r = rc.rect, done = (k + 1) / rc.R.n;
   // (lo que lleva y lo que queda, JUNTO a la barra: antes el texto estaba arriba, en la pildora, y la barra abajo, sin tiempo)
   var el = (now - rc.t0) / 1000, left = (k >= 5) ? el / (k + 1) * (rc.R.n - k - 1) : -1, font = cpFont("text", CP_ATLAS.size.label * sc), pad = Math.round(CP_ATLAS.space[1] * sc);
   var text = format(optT("%d of %d frames"), k + 1, rc.R.n) + ((left >= 0) ? " · " + format(optT("about %s left"), Math.floor(left / 60) + ":" + ("0" + Math.floor(left % 60)).slice(-2)) : "");
   rc.text = text; rc.left = left;
   rc.buf.fill(CP_INT_SURFACE);
   var g = new Graphics(rc.buf);
   try {
      g.smoothInterpolation = true;
      g.fillRect(new Rect(0, 0, w, h), new Brush(cpInt(CP_FLP_BLACK, CP_FLP.OUTSIDE)));
      g.drawScaledBitmap(new Rect(r.x, r.y, r.x + r.w, r.y + r.h), bmp);
      g.pen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1); g.brush = new Brush(0x00000000);
      g.drawRect(r.x, r.y, r.x + r.w - 1, r.y + r.h - 1);
      g.fillRect(new Rect(0, h - bar, w, h), new Brush(CP_INT_BORDER));
      g.fillRect(new Rect(0, h - bar, Math.round(w * done), h), new Brush(CP_INT_AMBER));
      try { g.textAntialiasing = true; } catch (eT) {}
      g.font = font;
      var tw = font.width(text), ty = h - bar - pad;
      g.fillRect(new Rect(pad, ty - font.ascent - pad / 2, pad + tw + pad, ty + font.descent + pad / 2), new Brush(cpInt(CP_ATLAS.bg, 0.8)));
      g.pen = new Pen(CP_INT_TEXT); g.drawText(pad + pad / 2, ty, text);
   } finally { g.end(); }
   this.fl.show = rc.buf;
   try { this.canvas.repaint(); } catch (e) {}
};
CPStarfieldDock.prototype._flightRecordStep = function() {
   var rc = this.fl.rec;
   if (rc === null || rc.ask) return;                      // (con la pregunta abierta, la grabacion esta en PAUSA)
   var R = rc.R;
   // (el ultimo paso cierra el fichero y, si hay ffmpeg, lo pasa a MP4: tarda; se dice ANTES y se da una vuelta para que se lea)
   if (!rc.encoding && R.k === R.n - 1 && R.format === "mp4") { rc.encoding = true; this._flightSay(optT("Encoding the video (H.264)…"), "pending"); return; }
   var more = R.step();
   // (cuanto lleva y cuanto queda se pinta junto a la barra, al enseñar el fotograma)
   if (more) return;
   this._flightRecordEnd(false);
};
// (Q3) «CANCEL» PREGUNTA, en un panel superpuesto al lienzo (no un cuadro modal): la grabacion se PAUSA mientras se decide.
// «Keep what was recorded (N s)» cierra el video como uno valido mas corto; «Delete it» borra lo escrito; «Continue
// recording» sigue. Esc = seguir.
CPStarfieldDock.prototype._flightAskBuild = function() {
   var self = this, button = cpSfFlButton;
   var Ak = this.flAsk = new Control(this.canvas);
   cpApplyStyle(Ak, "background-color:" + CP_UI.bgPanel + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_UI.radius + ";");
   this.flAskText = cpSfFlLabel(Ak, "");
   this.flAskKeep = button(Ak, "", "sf.flight.keep", function() { self.flightCancelAnswer("keep"); });
   this.flAskDel = button(Ak, "", "sf.flight.delete", function() { self.flightCancelAnswer("delete"); });
   this.flAskCont = button(Ak, "", "sf.flight.continue", function() { self.flightCancelAnswer("continue"); });
   var s = new HorizontalSizer;
   cpGap(s, CP_SFUI.GAP);
   s.add(this.flAskKeep); s.add(this.flAskDel); s.add(this.flAskCont);
   Ak.sizer = new VerticalSizer;
   cpMargin(Ak.sizer, CP_ATLAS.space[1]); cpGap(Ak.sizer, CP_SFUI.GAP);
   Ak.sizer.add(this.flAskText); Ak.sizer.add(s);
   cpSetControlVisible(Ak, false);
};
CPStarfieldDock.prototype.flightCancelAsk = function() {
   var rc = this.fl.rec;
   if (rc === null || rc.ask) return false;
   if (!this.flAsk) this._flightAskBuild();
   rc.ask = true; rc.askAt = Date.now();
   var secs = rc.R.k / Math.max(1, rc.R.plan.fps);
   this.flAskText.text = optT("Stop the recording?");
   this.flAskKeep.text = format(optT("Keep what was recorded (%s s)"), cpSvFx(secs, 1));
   this.flAskKeep.enabled = rc.R.k >= 1;
   this.flAskDel.text = optT("Delete it"); this.flAskCont.text = optT("Continue recording");
   var pad = cpUiPx(CP_SFUI.GAP, this.canvas);
   try {
      cpSetControlVisible(this.flAsk, true);
      this.flAsk.adjustToContents();
      this.flAsk.move(Math.max(pad, Math.round((this.canvas.width - this.flAsk.width) / 2)), pad);
      this.flAsk.bringToFront();
   } catch (e) {}
   this._flightSay(optT("Recording paused."), "pending");
   return true;
};
CPStarfieldDock.prototype.flightCancelAnswer = function(choice) {
   var rc = this.fl.rec;
   if (rc === null || !rc.ask) return false;
   if (this.flAsk) cpSetControlVisible(this.flAsk, false);
   if (choice === "continue") {
      rc.ask = false;
      rc.t0 += Date.now() - rc.askAt;                       // (lo que queda no cuenta la pausa)
      this._flightSay(format(optT("Recording the flight to %s"), rc.dir), "pending", rc.dir);
      return true;
   }
   this._flightRecordEnd((choice === "keep") ? "keep" : true);
   return true;
};
// Se acaba (o se cancela): fuera el tic, los mandos como estaban, y lo que ha pasado, en la pildora.
// `cancel`: false (acabo), true (se borra lo escrito) o "keep" (se queda lo grabado, como un video mas corto).
CPStarfieldDock.prototype._flightRecordEnd = function(cancel) {
   var rc = this.fl.rec;
   if (rc === null) return;
   this.fl.rec = null;
   try { this.flTimer.stop(); } catch (e) {}
   if (this.flAsk) cpSetControlVisible(this.flAsk, false);
   if (cancel === "keep") { if (rc.R.format === "mp4") this._flightSay(optT("Encoding the video (H.264)…"), "pending"); rc.R.finishNow(); cancel = false; }
   else if (cancel) rc.R.cancel();
   var res = rc.R.result || { ok: false, cancelled: cancel, why: "no result", files: [], bytes: 0, frames: 0, seconds: 0, format: "" };
   this.fl.show = null;
   cpSfUiFree(rc.buf);
   try { this.dialog._batchUnlock(rc.locked); } catch (e2) {}
   this._flightDockLock(false);
   this.fl.last = { what: "record", result: res };
   if (res.ok) {
      var path = res.files[0].path;
      cpSfUiRememberDir(rc.dir);
      this._flightSay(format(optT("Flight saved: %s (%s MB, %d frames, %s s)"), path, cpSvFx(res.bytes / 1e6, 1), res.frames, res.seconds.toFixed(0)), "ok", path);
   } else if (res.cancelled) this._flightSay(optT("Recording cancelled: nothing was saved."), "pending");
   else this._flightSay(optT("Could not record the flight") + ": " + res.why, "error", (res.files && res.files.length) ? res.files[0].path : "");
   this._flightSync();
   try { this.canvas.repaint(); } catch (e3) {}
};

CPStarfieldDock.prototype._flightRetranslate = function() {
   if (!this.fl) return;
   this._flightNames();
   if (!this.flPanel) return;
   this.flDurLabel.text = optT("Duration"); this.flSizeLabel.text = optT("Size"); this.flTitleLabel.text = optT("Title"); this.flDirLabel.text = optT("Save to");
   this.flFmtLabel.text = optT("Format"); this._flightFmtNames();
   if (C3_FL_LABELW_ONCE !== true) this._flightLabelWidths();
   this._flightTips();
   this._flightSync();
};
CPStarfieldDock.prototype._flightCleanup = function() {
   if (!this.fl) return;
   try { this.flightEnd(); } catch (e) {}
   try { this.flTimer.stop(); } catch (e1) {}
   try { this._flightEdCleanup(); } catch (e2) {}
};
