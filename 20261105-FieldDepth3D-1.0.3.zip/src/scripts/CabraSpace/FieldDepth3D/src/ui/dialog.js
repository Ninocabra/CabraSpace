// ============================================================================
// ui/dialog.js — EL DIALOGO DE Cabra3D (14-oct-2026)
// ----------------------------------------------------------------------------
// Una sola ventana, en el orden en que se usa:
//   ① la IMAGEN (las abiertas en PixInsight; de fabrica, la activa) y lo que se sabe
//     de su color (blanco y negro o sin calibrar: se AVISA, no se bloquea);
//   ② su SOLUCION ASTROMETRICA (si ya la tiene, no se llama a ImageSolver; si no, se
//     resuelve al pedir una vista);
//   ③ «Distances»: el panel de CabraPilot (copiado; sin el HR desde el 15-oct, que vive en CabraStars), junto a la foto,
//     con sus transiciones foto ↔ 3D, el vuelo, el video, la pantalla completa… y la
//     MAQUINA DEL TIEMPO (tm/), que vive en las filas de «Distances».
// La foto (ui/photo_view.js) hace de «visor» para el panel: lo que en CabraPilot era el
// dialogo principal (`currentRec`, `findRecById`, `preview`, `onStarfieldDock`,
// `stretchModeForRec`, `annotPanel.openStarfield`, `_batchLock`) lo pone este dialogo.
// Estetica Atlas (ui/atlas.js); el idioma, EN con ES al lado (boton ES/EN). ES5 salvo la
// declaracion de la clase (V8).
// ============================================================================

var C3_TITLE_SUB = "distances, 3D and a time machine";
var C3_EYEBROW = "FIELD DEPTH 3D";        // (30-oct-2026) el nombre que se ve, en versalitas espaciadas (antes «CABRA3D»); es marca: no se traduce

function cpInitC3MainDialog() {
   var self = this;
   C3_CLOSING = false;
   this.windowTitle = CP_TITLE;
   this.recs = [];
   this.currentRec = null;
   this._locked = false;
   cpStyleDialog(this);

   // --- la cabecera -------------------------------------------------------------
   this.eyebrow = new Label(this);
   this.eyebrow.text = C3_EYEBROW;
   cpApplyStyle(this.eyebrow, "background-color:transparent; color:" + CP_UI.primary + "; border:none; font-size:10px; font-weight:700; letter-spacing:2px;");
   this.subtitle = new Label(this);
   cpApplyStyle(this.subtitle, "background-color:transparent; color:" + CP_UI.textMuted + "; border:none; font-family:" + CP_UI.fontDisplay + "; font-size:12px; font-style:italic;");
   this.langButton = new PushButton(this);
   this.langButton.onClick = function() { self.toggleLanguage(); };
   cpStyleToggle(this.langButton, false);
   // CERRAR (encargo de Nino, 15-oct): un boton visible, siempre en el mismo sitio (arriba a la derecha), que cierra el script de
   // verdad: para temporizadores, grabacion y vuelo, y libera los bitmaps (`closeScript`). El aspa y Esc hacen lo mismo.
   this.closeButton = new PushButton(this);
   this.closeButton.onClick = function() { self.closeScript(); };
   cpStyleToggle(this.closeButton, false);
   // AYUDA (2-nov-2026): el «?» dorado abre la ayuda PIDoc en el idioma de la interfaz (FieldDepth3D_es / FieldDepth3D), la instalada
   // en PixInsight o, si no, la compilada en _help/ en el navegador (CabraShared/help/csh_help.js). Con lo de la ventana: ? · ES · Cerrar.
   this.helpButton = cshHelpButton(this, "FieldDepth3D", { title: "FieldDepth3D — CabraSpace", matchHeightOf: this.closeButton });
   var head = new HorizontalSizer; cpGap(head, CP_ATLAS.space[1]);
   head.add(this.eyebrow); head.add(this.subtitle); head.addStretch(); head.add(this.helpButton); head.add(this.langButton); head.add(this.closeButton);

   // --- ① la imagen --------------------------------------------------------------
   this.stepImage = new Label(this);
   cpStyleHint(this.stepImage);
   this.imageCombo = new ComboBox(this);
   try { this.imageCombo.setMinWidth(cpUiPx(CP_ATLAS.space[9] + CP_ATLAS.space[8], this.imageCombo)); } catch (eW) {}
   this.imageCombo.onItemSelected = function(k) { if (!self._building) self.selectImage(self.recs[k] ? self.recs[k].id : null); };
   this.refreshButton = new PushButton(this);
   this.refreshButton.text = "⟳";
   this.refreshButton.onClick = function() { self.refreshImages(self.currentRec ? self.currentRec.id : null); };
   cpStyleToggle(this.refreshButton, false);
   this.colorPill = new Label(this);
   cpStyleStatusPill(this.colorPill, "●", "pending");
   // --- ② la solucion -----------------------------------------------------------------
   this.stepSolve = new Label(this);
   cpStyleHint(this.stepSolve);
   this.solvePill = new Label(this);
   cpStyleStatusPill(this.solvePill, "●", "pending");
   this.solveButton = new PushButton(this);
   this.solveButton.onClick = function() { self.ensureSolved(); };
   cpStyleToggle(this.solveButton, false);
   // --- ③ las vistas --------------------------------------------------------------------
   this.stepOpen = new Label(this);
   cpStyleHint(this.stepOpen);
   this.distButton = new PushButton(this);
   this.distButton.onClick = function() { self.openStarfield("dist"); };
   cpStylePrimaryButton(this.distButton);
   var steps = new HorizontalSizer; cpGap(steps, CP_ATLAS.space[1]);
   // (MIRADO en la captura: con factores de estiramiento el desplegable y las pildoras se comian la fila entera; ahora cada
   // cosa mide lo suyo y lo que sobra queda en medio, antes de los botones de las vistas)
   try { this.imageCombo.setMaxWidth(cpUiPx(CP_ATLAS.space[9] * 3, this.imageCombo)); } catch (eMx) {}
   steps.add(this.stepImage); steps.add(this.imageCombo); steps.add(this.refreshButton); steps.add(this.colorPill);
   cpAddGap(steps, CP_ATLAS.space[3]);
   steps.add(this.stepSolve); steps.add(this.solvePill); steps.add(this.solveButton);
   // (20-oct, Nino: «Show in 3D» pegado a la astrometria, a su izquierda; lo que sobra queda a la derecha)
   cpAddGap(steps, CP_ATLAS.space[3]);
   steps.add(this.stepOpen); steps.add(this.distButton);
   steps.addStretch();

   // --- la foto y el panel ------------------------------------------------------------
   this.preview = new C3PhotoView(this, this);
   this._ovToggleBuild();       // (26-oct-2026) el boton que pone y quita las estrellas de la foto: dentro del visor, arriba a la izquierda (ui/photo_overlay_toggle.js)
   this.annotPanel = { openStarfield: function(mode) { return self.openStarfield(mode); } };
   this.starfieldDock = new CPStarfieldDock(this, this);
   this._ovPrefApply();         // (30-oct-2026) el conmutador «Real photo | Stars» arranca en «Real photo» o en lo que el usuario dejo la ultima vez (CabraShared/csh_viewpref.js)
   // LO RECORDADO del panel (en CabraPilot lo guardaba su sistema de preferencias): la pose, la escala, la unidad y el giro
   if (!CP_NO_MAIN) { try { var pj = Settings.read(CP_SETTINGS_PREFIX + "/Distances/prefs", DataType_String); if (pj && Settings.lastReadOK !== false) this.starfieldDock.prefsSet(JSON.parse(String(pj)), {}); } catch (ePr) {} }
   var dw = this._layoutRead("dockW", 0);
   this.starfieldDock.container.setFixedWidth((dw > 0) ? dw : cpUiPx(CP_ATLAS.space[9] * 9, this));
   this.dockSplitter = new CPSplitter(this, { target: this.starfieldDock.container, invert: true, min: cpUiPx(CP_SFUI.DOCK_MIN, this), max: cpUiPx(CP_ATLAS.space[9] * 20, this),
                                              onResized: function(w) { self._dockManual = true; self._layoutWrite("dockW", w); } });
   this._dockManual = false;     // true desde que el usuario mueve el separador: el ancho del 3D es suyo y la foto CUBRE su hueco (`_fitPhoto`)
   this._fitBusy = false;
   cpSetControlVisible(this.dockSplitter, false);
   var row = new HorizontalSizer; cpGap(row, 0);
   row.add(this.preview.viewport, 100); row.add(this.dockSplitter); row.add(this.starfieldDock.container);

   // --- el pie: lo que pasa (una linea) --------------------------------------------------
   this.status = new Label(this);
   cpStyleStatusPill(this.status, "●", "pending");
   cpFixHeightToText(this.status, "● Xg");

   this.sizer = new VerticalSizer;
   cpMargin(this.sizer, CP_ATLAS.space[2]); cpGap(this.sizer, CP_ATLAS.space[1]);
   this.sizer.add(head); this.sizer.add(steps); this.sizer.add(row, 100); this.sizer.add(this.status);

   this.onKeyPress = function(key, modifiers) { return self._onKey(key, modifiers); };
   // (DIAGNOSTICO del 15-oct, tests/c3_close_antes_del_arreglo.log: con el aspa —WM_CLOSE real— el dialogo NO se cerraba en 6 s.
   // `onClose` no devolvia nada; PJSR lo toma como un veto. Ahora devuelve true, y antes lo para todo)
   this.onClose = function() { C3_CLOSING = true; self.cleanup(); return true; };
   this.retranslate();
   try {
      var scr = this.availableScreenRect;
      this.resize(Math.round(scr.width * 0.86), Math.round(scr.height * 0.84));
   } catch (eR) { try { this.resize(cpUiPx(1500, this), cpUiPx(900, this)); } catch (eR2) {} }
   this.refreshImages(null);
}
class C3MainDialog extends Dialog {
   constructor() { super(); cpInitC3MainDialog.call(this); }
}

// --- lo recordado de la ventana (el ancho del panel) -------------------------------------
C3MainDialog.prototype._layoutRead = function(key, fallback) {
   if (CP_NO_MAIN) return fallback;
   try { var v = Settings.read(CP_SETTINGS_PREFIX + "/Layout/" + key, DataType_Int32); if (typeof v === "number" && isFinite(v) && Settings.lastReadOK !== false) return v; } catch (e) {}
   return fallback;
};
C3MainDialog.prototype._layoutWrite = function(key, v) { if (CP_NO_MAIN) return; try { Settings.write(CP_SETTINGS_PREFIX + "/Layout/" + key, DataType_Int32, Math.round(v)); } catch (e) {} };

// ---------------------------------------------------------------------------
// LOS TEXTOS (y su traduccion en vivo)
// ---------------------------------------------------------------------------
C3MainDialog.prototype.retranslate = function() {
   this.subtitle.text = optT(C3_TITLE_SUB);
   this.langButton.text = (CP_LANG === "es") ? "EN" : "ES";
   this.langButton.toolTip = cpTooltip("c3.lang");
   try { this.helpButton.cshHelpRetranslate(); } catch (eHelp) {}
   this.closeButton.text = "✕ " + optT("Close"); this.closeButton.toolTip = cpTooltip("c3.close");
   this.stepImage.text = "① " + optT("Image");
   this.stepSolve.text = "② " + optT("Astrometry");
   this.stepOpen.text = "③";
   this.imageCombo.toolTip = cpTooltip("c3.image");
   this.refreshButton.toolTip = cpTooltip("c3.refresh");
   this.solveButton.text = optT("Solve");
   this.solveButton.toolTip = cpTooltip("c3.solve");
   this.distButton.text = optT("Show in 3D"); this.distButton.toolTip = cpTooltip("c3.dist");
   var all = [this.langButton, this.closeButton, this.refreshButton, this.solveButton, this.distButton];
   for (var i = 0; i < all.length; ++i) cpMinWidthToText(all[i], CP_ATLAS.space[2]);
   try { this.starfieldDock.retranslate(); } catch (e) {}
   try { if (this.ovToggle) this._ovToggleSync(true); } catch (eOv) {}
   this._sayImage();
   // (tarea H7, 21-oct: con el 3D abierto, la linea de estado vuelve a decir lo de el —y su aviso del tiempo— en el idioma nuevo; antes
   // se quedaba con lo de la imagen, o con un aviso en el idioma de antes)
   try { var dk = this.starfieldDock; if (dk && dk.state && dk.mode && !dk._closed && dk._c3SayCurrent) dk._c3SayCurrent(); } catch (e2) {}
};
C3MainDialog.prototype.toggleLanguage = function() {
   CP_LANG = (CP_LANG === "es") ? "en" : "es";
   cpSaveLang();
   this.retranslate();
   try { this.preview.viewport.repaint(); } catch (e) {}
};
C3MainDialog.prototype.say = function(text, kind, tip) {
   cpStyleStatusPill(this.status, "● " + text, kind || "pending");
   try { this.status.toolTip = tip ? cpWrapTooltip(tip) : ""; this.status.__cpTipBound = !!tip; } catch (e) {}
};

// ---------------------------------------------------------------------------
// ① LAS IMAGENES ABIERTAS
// ---------------------------------------------------------------------------
C3MainDialog.prototype.refreshImages = function(keepId) {
   var wins = [], i, active = null;
   try { wins = ImageWindow.windows; } catch (e) { wins = []; }
   try { active = ImageWindow.activeWindow; } catch (e2) {}
   this.recs = [];
   for (i = 0; i < wins.length; ++i) {
      var w = wins[i];
      try { if (w.isNull || !optSafeView(w.mainView)) continue; } catch (e3) { continue; }
      this.recs.push({ id: w.mainView.id, view: w.mainView });
   }
   var want = keepId || ((active && !active.isNull) ? active.mainView.id : null), sel = -1;
   this._building = true;
   try {
      this.imageCombo.clear();
      for (i = 0; i < this.recs.length; ++i) { this.imageCombo.addItem(this.recs[i].id); if (this.recs[i].id === want) sel = i; }
      if (sel < 0 && this.recs.length > 0) sel = 0;
      if (sel >= 0) this.imageCombo.currentItem = sel;
   } finally { this._building = false; }
   this.selectImage((sel >= 0) ? this.recs[sel].id : null);
};
C3MainDialog.prototype.findRecById = function(id) {
   for (var i = 0; i < this.recs.length; ++i) if (this.recs[i].id === id && optSafeView(this.recs[i].view)) return this.recs[i];
   // (una vista que no estaba en la lista —recien abierta—)
   try { var v = View.viewById(id); if (optSafeView(v)) return { id: id, view: v }; } catch (e) {}
   return null;
};
// Como se pinta la foto: la regla comun (cshPhotoStretchMode, CabraShared/csh_astrometry.js). "view" lo decide optRenderPreviewBitmap por su cuenta.
C3MainDialog.prototype.stretchModeForRec = function(rec) {
   if (!rec || !optSafeView(rec.view)) return "none";
   return cshPhotoStretchMode(rec.view);
};
C3MainDialog.prototype.selectImage = function(id) {
   var rec = (id !== null && id !== undefined) ? this.findRecById(id) : null;
   if (rec && this.currentRec && rec.id === this.currentRec.id && this.preview.view === rec.view && this.preview.bitmap) { this._sayImage(); return; }
   this.currentRec = rec;
   this.preview.setBusy(true, optT("Preparing the photo…"));
   try { this.preview.setView(rec ? rec.view : null, this.stretchModeForRec(rec)); } finally { this.preview.setBusy(false); }
   this._fitPhoto();      // (otro aspecto: con el 3D abierto, el ancho del panel se recalcula)
   this._sayImage();
   try { this.starfieldDock.onImageChanged(); } catch (e) {}
   this._modeButtons();
};
// Lo que se sabe de la imagen: su color y su solucion.
C3MainDialog.prototype._sayImage = function() {
   var rec = this.currentRec;
   this.solveButton.enabled = !!rec;
   this.distButton.enabled = !!rec;
   if (!rec) {
      cpStyleStatusPill(this.colorPill, "● " + optT("Open an image in PixInsight first"), "pending");
      cpStyleStatusPill(this.solvePill, "●", "pending");
      cpSetControlVisible(this.solveButton, false);
      this.say(optT("No image is open: open one in PixInsight and press ⟳."), "pending");
      return;
   }
   var c = c3ColorStatus(rec.view), lin = cpViewIsLinear(rec.view);
   // (B/N: admitido del todo —los colores salen de Gaia—, asi que es informacion, no aviso: pildora «ok», sin ⚠ ni ambar; 20-oct, Nino)
   if (c.mono) { cpStyleStatusPill(this.colorPill, "✓ " + optT("Black and white · colours from Gaia"), "ok"); this.colorPill.toolTip = cpTooltip("c3.color.mono"); }
   else if (!c.calibrated) { cpStyleStatusPill(this.colorPill, "⚠ " + optT("No colour calibration in its history (SPCC recommended)"), "warn"); this.colorPill.toolTip = cpTooltip("c3.color.uncal"); }
   else { cpStyleStatusPill(this.colorPill, "✓ " + format(optT("Colour calibrated (%s)"), (c.how === "SpectrophotometricColorCalibration") ? "SPCC" : (c.how === "PhotometricColorCalibration") ? "PCC" : c.how) + (lin ? "" : " · " + optT("stretched")), "ok"); this.colorPill.toolTip = cpTooltip("c3.color.ok"); }
   this.colorPill.__cpTipBound = true;
   var solved = cpHasAstrometricSolution(rec.view);
   cpStyleStatusPill(this.solvePill, solved ? "✓ " + optT("Solved: ImageSolver is not needed") : "● " + optT("Not solved: it will be solved when you open a view"), solved ? "ok" : "pending");
   cpSetControlVisible(this.solveButton, !solved);
   this.say(format(optT("%s · %d × %d px · %s"), rec.id, rec.view.image.width, rec.view.image.height, lin ? optT("linear") : optT("stretched")), "pending");
};

// ---------------------------------------------------------------------------
// ② RESOLVER, SOLO SI HACE FALTA
// ---------------------------------------------------------------------------
C3MainDialog.prototype.ensureSolved = function() {
   var rec = this.currentRec;
   if (!rec) return { ok: false, state: "failed", why: optT("no image is selected.") };
   if (cpHasAstrometricSolution(rec.view)) return { ok: true, state: "already" };
   this.say(optT("Solving the image with ImageSolver…"), "info");
   this.preview.setBusy(true, optT("Solving the image with ImageSolver…"));
   var r = null;
   try { r = c3ProcRun(function() { return c3EnsureSolved(rec.view); }); } finally { this.preview.setBusy(false); }
   this._sayImage();
   if (r.ok) this.say(format(optT("Solved in %s s."), cpSvFx((r.ms / 1000), 1)), "ok");
   else this.say(optT("Could not solve the image") + ": " + r.why, "error", r.why);
   return r;
};

// ---------------------------------------------------------------------------
// ③ ABRIR UNA VISTA (lo que en CabraPilot hacia ANNOTATIONS)
// ---------------------------------------------------------------------------
C3MainDialog.prototype.openStarfield = function(mode) {
   var rec = this.currentRec, what = optT("Distances");
   if (!rec) { this.say(optT("No image is open: open one in PixInsight and press ⟳."), "error"); return { ok: false, code: "no-view", why: "" }; }
   var sol = this.ensureSolved();
   if (!sol.ok) return { ok: false, code: "no-solution", why: sol.why };
   var r = null;
   try { r = this.starfieldDock.open(mode); }
   catch (e) { r = { ok: false, code: "failed", why: String(e.message || e) }; }
   if (!r.ok) {
      var notInstalled = (r.code === "no-gaia");
      this.say(what + ": " + (notInstalled ? optT("not installed") + " — " : "") + r.why, notInstalled ? "warn" : "error", notInstalled ? cpTooltipText("c3.nogaia") : "");
   } else {
      this.say(what + " · " + rec.id, "ok");
      // (20-oct, Nino: al abrir el 3D se abre solo el grupo «3D VIEW»; solo al ABRIR, no al repintar —no pisa lo que elija despues—)
      try { this.starfieldDock.c3GroupOpen("view", true); } catch (eG) {}
   }
   this._modeButtons();
   return r;
};
// El panel se abre o se cierra (lo avisa el propio panel): el separador con el.
C3MainDialog.prototype.onStarfieldDock = function(open) {
   cpSetControlVisible(this.dockSplitter, open === true);
   this._modeButtons();
   this.preview.cover = (open === true);     // (el 3D abierto; la foto se enseña entera salvo con la costura roja C3_PHOTO_COVER, photo_view.js)
   if (open) {
      try { var room = this.width, w = this.starfieldDock.container.width; if (room > 0 && w > room * 0.72) this.starfieldDock.container.setFixedWidth(Math.round(room * 0.6)); } catch (e) {}
      this._fitPhoto();
   }
   // (21-oct: ya NO `fit()`: reponia el zoom del usuario al abrir/cerrar el 3D; `relayout` encaja solo si estaba encajada)
   try { this.preview.relayout(); } catch (e2) {}
};

// LA FOTO SIN FRANJAS (revision del 15-oct: una foto apaisada dejaba grandes franjas negras arriba y abajo; 21-oct, Nino: «quita las
// franjas vacias arriba y abajo de la foto con el 3D abierto»). Con el 3D abierto, el ancho del panel se calcula para que la foto
// llene EXACTAMENTE el alto de su hueco (ancho del hueco = alto × aspecto de la foto): sin franjas, sin recorte. El 3D se lleva lo que
// sobra, entre el 35 % y el 70 % del ancho (antes 45–70 %: con una foto apaisada la foto no llenaba y quedaban 86–160 px de franja;
// medido en tests/c3_photo_fill_errbars.js que a un 35 % el 3D sigue siendo usable). Si ni asi llena (una foto muy panoramica o muy alta; 28-oct, H7,
// decision de Nino) la foto se ve ENTERA con franjas arriba y abajo —o a los lados— y el 3D se queda en su ancho; antes cubria el hueco y se recortaba
// (`preview.cover` + costura roja C3_PHOTO_COVER). Lo mismo si el usuario movio el separador a mano: su ancho se respeta (`_dockManual`). Sin proceso: solo aritmetica.
var C3_PHOTO_DOCK_LO = 0.35, C3_PHOTO_DOCK_HI = 0.7;
C3MainDialog.prototype._fitPhoto = function() {
   if (this._fitBusy) return;                    // (poner el ancho redimensiona el visor, que vuelve a llamar aqui)
   this._fitBusy = true;
   try {
      var rec = this.currentRec, vp = this.preview.viewport, dock = this.starfieldDock.container;
      if (!rec || !(vp.height > 50) || this._dockManual === true || this.starfieldDock.mode === "") return;
      var img = rec.view.image, aspect = img.width / Math.max(1, img.height), photoW = Math.round(vp.height * aspect);
      var total = vp.width + dock.width, want = total - photoW, lo = Math.max(cpUiPx(CP_SFUI.DOCK_MIN, this), Math.round(total * C3_PHOTO_DOCK_LO)), hi = Math.round(total * C3_PHOTO_DOCK_HI);
      want = Math.max(lo, Math.min(hi, want));
      if (want !== dock.width) dock.setFixedWidth(want);
   } catch (e) {} finally { this._fitBusy = false; }
};
// El visor de la foto cambio de tamaño (ventana, maximizar, otra imagen…): con el 3D abierto y el separador sin tocar, el panel se
// reajusta para que la foto siga llenando su hueco.
C3MainDialog.prototype.onPhotoResized = function() { this._fitPhoto(); };
// --- lo que la foto le pide al dialogo ---------------------------------------------------------
C3MainDialog.prototype.paintPhotoOverlay = function(g, scale, sx, sy) {
   var dock = this.starfieldDock;
   if (!dock) return;
   try { dock.dustPaintPhoto(g, this.preview); } catch (eD) {}
   try { dock.tmPaintPhoto(g, this.preview); } catch (eT) { try { console.warningln("Cabra3D tm overlay: " + eT); } catch (eW) {} }
   try { dock.starsPaintPhoto(g, this.preview); } catch (eS) { try { console.warningln("Cabra3D stars overlay: " + eS); } catch (eW2) {} }   // las estrellas del desplegable «Stars», como en el 3D (ui/photo_stars_overlay.js)
   try { this._ovToggleSync(false); } catch (eT2) {}      // (el aspecto del boton de las estrellas: solo si cambio, con un temporizador)
   try { dock.paintOverlay(g, scale, sx, sy); } catch (e) {}
};
C3MainDialog.prototype.photoDim = function() { try { return this.starfieldDock.tmPhotoDim(); } catch (e) { return 1; } };
C3MainDialog.prototype.photoMix = function() { try { return this.starfieldDock.tmPhotoMix(); } catch (e) { return 0; } };
// (solo la YA hecha: al pintar no se calcula nada)
C3MainDialog.prototype.photoStarless = function() { try { var st = this.starfieldDock.state; return (st && st.tmStarless) ? st.tmStarless : null; } catch (e) { return null; } };
// El boton de la vista que se esta viendo va de oro lleno; el otro, de filete (revision visual: «Distances» salia siempre lleno).
C3MainDialog.prototype._modeButtons = function() {
   var m = "";
   try { m = this.starfieldDock.mode; } catch (e) {}
   // (revision del 15-oct: con una sola vista, un conmutador de una opcion sobraba. Es una ACCION —leer esta imagen y verla en
   // 3D— y solo esta cuando hay algo que abrir: el panel cerrado, o abierto con otra imagen que aun no se ha leido)
   var dock = this.starfieldDock, need = true;
   try { need = (dock.mode === "") || dock.state === null || (this.currentRec && dock._find(cpSfUiKey(this.currentRec.view)) !== dock.state); } catch (eN) {}
   cpStylePrimaryButton(this.distButton);
   cpSetControlVisible(this.distButton, need); cpSetControlVisible(this.stepOpen, need);
   cpMinWidthToText(this.distButton, CP_ATLAS.space[2]);
};
C3MainDialog.prototype.onImageClick = function(x, y) { try { return this.starfieldDock.onImageClick(x, y); } catch (e) { return -1; } };

// --- grabando: los mandos de arriba, apagados (lo pide el panel) ------------------------------------
C3MainDialog.prototype._batchLock = function() {
   var list = [this.imageCombo, this.refreshButton, this.solveButton, this.distButton, this.langButton], was = [];
   for (var i = 0; i < list.length; ++i) { try { was.push(list[i].enabled); list[i].enabled = false; } catch (e) { was.push(true); } }
   return { list: list, was: was };
};
C3MainDialog.prototype._batchUnlock = function(lock) {
   if (!lock) return;
   for (var i = 0; i < lock.list.length; ++i) { try { lock.list[i].enabled = lock.was[i]; } catch (e) {} }
};

// --- el teclado: la pantalla completa primero (alli Esc sale de ella, o para el vuelo); fuera, Esc CIERRA el script --------
// (encargo de Nino, 15-oct: «Esc tambien cierra igual», con lo que haya en marcha. Esc real no pasa por onClose —ficha de CabraBase
// esc-en-dialog-no-pasa-por-onclose—: se coge aqui, se para todo y se cierra.)
C3MainDialog.prototype._onKey = function(key, modifiers) {
   var dock = this.starfieldDock;
   try { if (dock.fullScreenKey && dock.fullScreenKey(key, modifiers) === true) return true; } catch (e) {}
   if (key === 27) {
      try { if (dock.isFullScreen && dock.isFullScreen()) { dock.flightStop(); return true; } } catch (e1) {}
      this.closeScript();
      return true;
   }
   return false;
};
// CERRAR DE VERDAD: todo parado y liberado (`cleanup`) y el dialogo fuera. Lo usan el boton, Esc y el de la pantalla completa.
C3MainDialog.prototype.closeScript = function() {
   if (this._closing) return;
   this._closing = true;
   C3_CLOSING = true;                            // (los bucles largos —el polvo, las orbitas— lo miran y paran)
   this.cleanup();
   // (el cierre, DIFERIDO a un temporizador corto: CabraQuality midio el 15-oct que un ok() dentro de un manejador anidado
   // —el boton pulsado mientras un trabajo largo bombea eventos— cortaba el script sin volver de execute())
   var self = this, t = new Timer;
   t.interval = 0.05; t.periodic = false;
   t.onTimeout = function() { try { self.cancel(); } catch (e) {} };
   this._closeTimer = t;
   t.start();
};
C3MainDialog.prototype.cleanup = function() {
   if (this._cleaned) return;
   this._cleaned = true;
   if (!CP_NO_MAIN) { try { Settings.write(CP_SETTINGS_PREFIX + "/Distances/prefs", DataType_String, JSON.stringify(this.starfieldDock.prefsGet())); } catch (ePw) {} }
   try { this.starfieldDock.cleanup(); } catch (e) {}
   try { this.preview.cleanup(); } catch (e2) {}
};
