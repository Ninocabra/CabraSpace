// ============================================================================
// ui/photo_overlay_toggle.js — EL CONMUTADOR «REAL PHOTO | STARS» QUE PONE Y QUITA LA SUPERPOSICION DE ESTRELLAS DE LA FOTO (26-oct-2026; 30-oct)
// ----------------------------------------------------------------------------
// Nino (26-oct): «En la parte izquierda de la interfaz pon un botón de toggle para que pueda poner y quitar la superposición de estrellas que genero
// con las opciones de la derecha.» La izquierda es la FOTO; la superposicion son los anillos que dibuja `starsPaintPhoto`
// (ui/photo_stars_overlay.js) segun el desplegable «Stars» de la derecha.
// (30-oct-2026, Nino: «Sí quiero los cuatro iguales») El icono de tres anillos de la esquina de arriba a la izquierda SALE y en su lugar va el
// conmutador de dos pildoras «Real photo | Stars» de CabraComposition y CabraStars, arriba a la DERECHA de la foto: el MISMO dibujo, de
// CabraShared/csh_pills.js. Cero redundancia: el icono viejo (c3OvtIcon, sus SVG en %TEMP%) se ha ido. Vive DENTRO del visor de la foto (hijo del
// visor, colocado a mano: no cambia el tamaño del visor, asi que ni el encuadre ni el zoom se mueven) y se recoloca al cambiar el tamaño del visor.
//   · Es un CONMUTADOR de lo que se PINTA, nada mas: `dock.starsOverlayOn` («Stars» = true). NO toca el desplegable «Stars» ni la lista de marcas ni
//     la capa de anillos (la capa guardada se conserva: al volver a «Stars» se COPIA, sin recalcular nada si el zoom y el visor no han cambiado).
//   · No es un segundo camino para generar la superposicion: esa sigue naciendo de «Show in 3D» + «Stars». Sin eso el conmutador esta APAGADO
//     (deshabilitado, pintado a media luz) y su tooltip dice por que; lo mismo con la maquina del tiempo lejos de «ahora» (el overlay se oculta solo:
//     la foto ya pinta las estrellas movidas). (27-oct, D2) Es el UNICO camino a la foto limpia: «Stars: None» ya no existe (un "none" recordado se
//     migra a «Gaia» + oculta, ui/photo_stars_overlay.js).
//   · Estado visible: la pildora elegida en oro («Stars» = visibles, «Real photo» = la foto limpia). El tooltip cambia con el estado (EN/ES).
//   · (30-oct-2026, Nino: los cuatro iguales) Arranca en «Real photo» y RECUERDA la ultima eleccion entre sesiones (Settings `<raiz>/aView`: Cabra3D
//     `Cabra3D/aView`, CabraStarAnalysis `CabraStarAnalysis/aView`; CabraShared/csh_viewpref.js). Un «Stars» recordado se aplica cuando hay 3D que
//     pintar (sin el, o con la maquina del tiempo lejos de «ahora», el conmutador sigue apagado). Solo se guarda lo que el usuario PULSA.
// El estado visual se decide al PINTAR la foto y se aplica con un temporizador corto (nunca se tocan los controles dentro de onPaint).
// ES5.
// ============================================================================

var C3_OVT_SEAM = true;            // la costura del rojo (C3_MUTATE=1): apagado, el boton cambia de estado pero la foto sigue pintando los anillos
var C3_OVT_RECALC = false;         // la costura del rojo (C3_MUTATE=2): encendido, quitar/poner tira la capa y la lista (hay que recalcularlas)
// --- los textos (EN y ES) -------------------------------------------------------------------------------------------------------------
(function() {
   C3_TOOLTIPS_EN["ovt.on"] = "Stars on the photo: SHOWN. «Real photo» hides the rings that the «Stars» option on the right draws on your photo. Nothing is recalculated and the option stays as it is: when you show them again they come back exactly the same. The zoom and the framing do not change.";
   C3_TOOLTIPS_ES["ovt.on"] = "Estrellas sobre la foto: VISIBLES. «Foto real» oculta los anillos que la opción «Stars» de la derecha dibuja sobre tu foto. No se recalcula nada y la opción se queda como está: al volver a mostrarlos salen exactamente igual. El zoom y el encuadre no cambian.";
   C3_TOOLTIPS_EN["ovt.cmp"] = "Compare: a curtain over the photo. On the left of the gold line, your photo, clean; on the right, the rings of the «Stars» option. Drag the line. Nothing is recalculated; the zoom and the framing do not change.";
   C3_TOOLTIPS_ES["ovt.cmp"] = "Comparar: una cortinilla sobre la foto. A la izquierda de la línea dorada, tu foto limpia; a la derecha, los anillos de la opción «Stars». Arrastra la línea. No se recalcula nada; el zoom y el encuadre no cambian.";
   C3_TOOLTIPS_EN["ovt.off"] = "Stars on the photo: HIDDEN (your photo, clean). «Stars» shows again the rings of the option on the right, exactly as you left them. Nothing is recalculated; the zoom and the framing do not change.";
   C3_TOOLTIPS_ES["ovt.off"] = "Estrellas sobre la foto: OCULTAS (tu foto, limpia). «Estrellas» vuelve a mostrar los anillos de la opción de la derecha, tal como los dejaste. No se recalcula nada; el zoom y el encuadre no cambian.";
   C3_TOOLTIPS_EN["ovt.no3d"] = "Not available yet: the stars on the photo are drawn from the 3D view. Press «Show in 3D» (③) and choose how to draw them in «Stars» (3D VIEW, on the right).";
   C3_TOOLTIPS_ES["ovt.no3d"] = "Aún no disponible: las estrellas sobre la foto salen de la vista 3D. Pulsa «Show in 3D» (③) y elige cómo dibujarlas en «Stars» (3D VIEW, a la derecha).";
   C3_TOOLTIPS_EN["ovt.tm"] = "The rings are hidden while the time machine is away from «now»: the photo already shows the stars where they were. Your choice (shown or hidden) is kept and applies again at «now».";
   C3_TOOLTIPS_ES["ovt.tm"] = "Los anillos se ocultan mientras la máquina del tiempo está lejos de «ahora»: la foto ya muestra las estrellas donde estaban. Tu elección (visibles u ocultos) se conserva y vuelve a valer en «ahora».";
})();

// --- las letras del conmutador (EN; ES en la tabla) ------------------------------------------------------------------------------------------
C3_I18N_ES["Real photo"] = "Foto real";
C3_I18N_ES["Compare"] = "Comparar";

// --- el estado, en el panel ---------------------------------------------------------------------------------------------------------------
CPStarfieldDock.prototype.starsOverlayOn = false;      // lo que el usuario quiere; (30-oct) de fabrica «Real photo», o lo recordado (CabraShared/csh_viewpref.js, `_ovPrefApply`)
// Por que NO hay superposicion por causas ajenas al boton: "off" (la costura de las pruebas) · "no-3d" · "time-machine"; "" = puede haberla.
CPStarfieldDock.prototype._ovWhy = function() {
   var st = this.state, rec = this.dialog.currentRec, pv = this.dialog.preview;
   if (C3_STARS_OVERLAY !== true) return "off";
   if (this.mode !== "dist" || !st || !rec || !pv || !pv.bitmap || this._find(cpSfUiKey(rec.view)) !== st) return "no-3d";
   if (this.tm && this.tm.t !== 0) return "time-machine";
   return "";
};
// El estado del boton: { why, enabled, on, tip } (`why` = la causa ajena; enabled = no hay ninguna).
CPStarfieldDock.prototype.starsCompare = false;       // (31-oct-2026, Nino) «Compare», la tercera pildora: una cortinilla, a la izquierda la foto y a la derecha los anillos
CPStarfieldDock.prototype.starsOverlayState = function() {
   var why = this._ovWhy(), on = (this.starsOverlayOn !== false), tip;
   if (why === "") tip = on ? (this.starsCompare ? "ovt.cmp" : "ovt.on") : "ovt.off";
   else if (why === "time-machine") tip = "ovt.tm";
   else tip = "ovt.no3d";
   return { why: why, enabled: (why === ""), on: on, tip: tip };
};
// Poner o quitar. Devuelve el estado nuevo (true = visible). Solo cambia lo que se pinta: la foto se repinta y ya (la capa guardada se conserva).
CPStarfieldDock.prototype.setStarsCompare = function(on) {
   on = (on === true);
   this.starsCompare = on; if (on) this.starsOverlayOn = true;
   try { this.dialog.preview.viewport.repaint(); } catch (e) {}
   try { this.dialog._ovToggleSync(true); } catch (e2) {}
   return on;
};
CPStarfieldDock.prototype.setStarsOverlay = function(on) {
   on = (on !== false);
   if (this.starsOverlayOn === on && !this.starsCompare) return on;
   this.starsOverlayOn = on; this.starsCompare = false;
   if (C3_OVT_RECALC === true) { this._ovFree(); try { if (this.state) this.state.c3ov = null; } catch (eR) {} }
   try { this.dialog.preview.viewport.repaint(); } catch (e) {}
   try { this.dialog._ovToggleSync(true); } catch (e2) {}
   return on;
};

// --- el boton, en el dialogo ---------------------------------------------------------------------------------------------------------------
// (27-oct-2026) INSTALABLE en otro dialogo con el mismo visor de foto (`preview`, un C3PhotoView): `_ovtSrc()` devuelve quien dice el estado y
// lo cambia (starsOverlayState / setStarsOverlay / starsOverlayOn). En Cabra3D es el panel 3D, lo de siempre (comportamiento identico);
// CabraStarAnalysis lo instala en su ventana con su propia fuente (su superposicion es la de los modos de la foto: src/csa_dialog.js).
function c3OvtInstall(P) {
if (typeof P._ovtSrc !== "function") P._ovtSrc = function() { return this.starfieldDock; };
// (30-oct-2026) LA ELECCION RECORDADA (CabraShared/csh_viewpref.js): la raiz de Settings del script (CabraStarAnalysis la cambia por la suya) y si es una prueba.
if (typeof P._ovPrefRoot !== "function") P._ovPrefRoot = function() { return CP_SETTINGS_PREFIX; };
P._ovPrefNoMain = function() { return CP_NO_MAIN ? true : false; };
P._ovPrefRead = function() { return cshVpRead(this._ovPrefRoot(), this._ovPrefNoMain()); };
P._ovPrefWrite = function(which) { return cshVpWrite(this._ovPrefRoot(), this._ovPrefNoMain(), which); };
// Aplica lo recordado a la fuente del estado (el 3D en Cabra3D, la ventana en CabraStarAnalysis). Se llama UNA vez, cuando la fuente ya existe.
P._ovPrefApply = function() {
   var d = this._ovtSrc();
   if (!d) return "";
   var w = this._ovPrefRead();
   d.starsOverlayOn = (w !== "photo");
   if (this._ovCompare === true) d.starsCompare = (w === "compare");
   try { this._ovToggleSync(true); } catch (e) {}
   return w;
};
P._ovToggleBuild = function() {
   var self = this, vp = this.preview.viewport;
   this.ovSw = cshPillsCreate(vp, {
      keys: (this._ovCompare === true) ? ["photo", "stars", "compare"] : ["photo", "stars"], label: function(k) { return optT(k === "photo" ? "Real photo" : (k === "compare") ? "Compare" : "Stars"); }, scale: function() { return cpUiScale(vp); },
      state: function() {
         var d = self._ovtSrc();
         if (!d) return { enabled: false, cur: "stars", tip: "", tipKey: "", key: "nosrc" };
         var s = d.starsOverlayState();
         return { enabled: s.enabled, cur: !s.on ? "photo" : (d.starsCompare === true ? "compare" : "stars"), tip: cpTooltip(s.tip), tipKey: s.tip, key: [s.why, s.on, s.tip, CP_LANG].join("|") };
      },
      onPick: function(k) {
         var d = self._ovtSrc();
         if (d && d.starsOverlayState().enabled) {
            var want = (k !== "photo"), wasC = (d.starsCompare === true);
            if (k === "compare") { if (!wasC || d.starsOverlayOn === false) { d.setStarsCompare(true); self._ovPrefWrite("compare"); } }
            else if ((d.starsOverlayOn !== false) !== want || wasC) { d.setStarsOverlay(want); self._ovPrefWrite(want ? "stars" : "photo"); }
         }
      }
   });
   var b = this.ovSw.ctl, prevResize = vp.onResize;
   vp.onResize = function() { if (typeof prevResize === "function") prevResize.apply(vp, arguments); try { self.ovSw.place(); } catch (eP) {} };
   b.cpTipKey = "ovt.no3d";
   this.ovToggle = b;
   this._ovToggleKey = "";
   this._ovToggleTimer = null;
   this._ovToggleSync(true);
};
// El aspecto del conmutador segun el estado. `now`: en el acto; si no, solo si cambio (y con un temporizador, que se llama desde el pintado).
P._ovToggleSync = function(now) {
   var b = this.ovToggle, d = this._ovtSrc();
   if (!b || !d) return;
   var s = d.starsOverlayState(), key = [s.why, s.on, s.tip, CP_LANG, cpUiScale(b)].join("|");
   if (key === this._ovToggleKey) return;
   if (now !== true) {
      var self = this;
      if (!this._ovToggleTimer) {
         this._ovToggleTimer = new Timer; this._ovToggleTimer.interval = 0.02; this._ovToggleTimer.periodic = false;
         this._ovToggleTimer.onTimeout = function() { try { self._ovToggleSync(true); } catch (e) {} };
      }
      try { this._ovToggleTimer.start(); } catch (e2) {}
      return;
   }
   this._ovToggleKey = key;
   b.cpTipKey = s.tip;
   this.ovSw.sync();
};
}
if (typeof C3MainDialog !== "undefined") { C3MainDialog.prototype._ovCompare = true; c3OvtInstall(C3MainDialog.prototype); }
