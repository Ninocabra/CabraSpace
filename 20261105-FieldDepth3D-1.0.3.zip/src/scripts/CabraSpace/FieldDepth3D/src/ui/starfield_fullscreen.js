// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_fullscreen.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_fullscreen.js — «Distances» a PANTALLA COMPLETA (14-oct-2026; Cabra3D: sin el HR, que vive en CabraStars)
// ----------------------------------------------------------------------------
// Peticion de Nino: «pon para activar y desactivar pantalla completa», y dentro de ella una forma de cambiar entre FOTO y
// 3D (si no, las transiciones no sirven ahi).
// COMO (medido antes en `_tests/cp_fullscreen_probe.log`, 1.9.5 build 1706, V8): el dialogo se lleva a la pantalla en
// la que esta (`screenRect`), con su CLIENTE exactamente encima de ella (el titulo, fuera por arriba: `position` es el
// marco y `localToGlobal(0, 0)` el cliente; la diferencia es el marco), y un control HIJO del dialogo, sin sizer, puesto
// a mano encima de todo (lo tapa todo en `render()`), hace de lienzo: el panel pinta en `this.canvas`, y durante la
// pantalla completa `this.canvas` ES ese control (`_canvasDocked` guarda el de siempre). Asi todo lo del panel —el
// dibujo, el raton, las transiciones, los vuelos— sigue igual, y las tres vistas miden lo mismo (el lienzo no cambia de
// tamaño entre ellas: la regresion del 14-oct fue esa).
// LA BARRA: superpuesta (hija del lienzo, colocada a mano: NO le quita alto), dorada y minima: FOTO · 3D, «⚙ Options»,
// salir y «✕ Close» (cierra el script). Se esconde sola a los BAR_HIDE_MS sin mover el raton y vuelve al moverlo.
// LAS OPCIONES (peticion de Nino del 14-oct: «muestra las mismas opciones de visualizacion y configuracion que en el de
// pantalla no completa»): un panel SUPERPUESTO y PLEGABLE (plegado al entrar; «⚙ Options» lo abre y lo cierra), bajo la
// barra y escondido con ella, que no cambia el lienzo. Lo que lleva dentro NO es una copia: es la caja de los mandos del
// panel (`rowsBox`: las dos filas, con todos sus controles, su estado y sus manejadores), que se MUDA aqui al entrar y vuelve
// a su sitio al salir (`Control.parent` se puede asignar: medido en `_tests/cp_fullscreen_probe.log`). El panel «▾» de las
// opciones de grabar (hijo del lienzo) se muda con el lienzo. Teclas: 1 / F la foto, 3 / D el 3D, Esc sale (si no hay un vuelo en marcha).
// FOTO dentro de la pantalla completa: el panel «cerrado» (modo "") pero visible, con la foto en el lienzo (la misma que
// la transicion deja al acabar: `_fotoChrome`); salir desde ahi cierra el panel, como siempre.
// Metodos de CPStarfieldDock. ES5.
// ============================================================================

var CP_SFFS = {
   BAR_HIDE_MS: 2500,                 // diseño: la barra se esconde tras esto sin mover el raton
   TICK_S: 0.25,                      // el tic que la esconde
   OPT_HIDE_MS: 8000,                 // diseño: con las opciones abiertas, la barra espera esto (elegir en un desplegable no mueve el raton sobre el lienzo)
   ICON: CP_ATLAS.space[3]            // el lado del icono (pixeles logicos)
};
var CP_SFFS_CLOCK = function() { return Date.now(); };     // (la costura de las pruebas: el reloj de la barra)

// EL ICONO: un SVG de verdad (cuatro esquinas hacia fuera para entrar; hacia dentro para salir), del oro de Atlas, al
// tamaño de la escala de CabraPilot. Se escribe UNA vez por tamaño en la carpeta temporal de Atlas.
function cpSfFsIcon(control, exit) {
   var px = Math.max(10, cpPx(CP_SFFS.ICON, control)), s = 24, a = 3, b = 9, c = 15, d = 21;
   var path = exit ? ("M" + b + " " + a + "V" + b + "H" + a + " M" + c + " " + a + "V" + b + "H" + d + " M" + d + " " + c + "H" + c + "V" + d + " M" + a + " " + c + "H" + b + "V" + d)
                   : ("M" + a + " " + b + "V" + a + "H" + b + " M" + c + " " + a + "H" + d + "V" + b + " M" + d + " " + c + "V" + d + "H" + c + " M" + b + " " + d + "H" + a + "V" + c);
   var key = (exit ? "fs_exit_" : "fs_enter_") + px, cache = cpSfFsIcon.cache || (cpSfFsIcon.cache = {});
   if (cache[key]) return cache[key];
   try {
      var dir = File.systemTempDirectory.replace(/\\/g, "/") + "/Cabra3DAtlas" /* Cabra3D */;
      if (!File.directoryExists(dir)) File.createDirectory(dir, true);
      var f = dir + "/" + key + ".svg";
      File.writeTextFile(f, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"" + px + "\" height=\"" + px + "\" viewBox=\"0 0 " + s + " " + s + "\"><path d=\"" + path +
                            "\" fill=\"none\" stroke=\"" + CP_ATLAS.gold + "\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>");
      cache[key] = new Bitmap(f);
   } catch (e) { cache[key] = null; }
   return cache[key];
}

// EL BOTON de la fila de arriba (en «Distances»). Lo llama el constructor del panel.
CPStarfieldDock.prototype._fsBuild = function() {
   var self = this;
   this.fs = { on: false, ov: null, bar: null, saved: null, timer: null, lastMove: 0, barOn: false, foto: false, leaving: false };

   this.btnFull = new PushButton(this.rowsBox);
   this.btnFull.text = "";
   this.btnFull.toolTip = cpTooltip("sf.fullscreen");
   this.btnFull.cpTipKey = "sf.fullscreen";
   cpStyleToggle(this.btnFull, false);
   var ic = cpSfFsIcon(this.btnFull, false);
   if (ic) this.btnFull.icon = ic; else this.btnFull.text = "⛶";
   this.btnFull.onClick = function() { self.toggleFullScreen(); };
};
CPStarfieldDock.prototype.isFullScreen = function() { return !!(this.fs && this.fs.on); };
CPStarfieldDock.prototype.toggleFullScreen = function() { return this.isFullScreen() ? this.exitFullScreen() : this.enterFullScreen(); };

// EL LIENZO DE LA PANTALLA COMPLETA y su barra (se hacen la primera vez)
CPStarfieldDock.prototype._fsMake = function() {
   var self = this, D = this.dialog, ov = new Control(D);
   cpApplyStyle(ov, "background-color:" + CP_ATLAS.surface + "; border:none;");
   try { ov.mouseTracking = true; } catch (eT) {}
   ov.onPaint = function(x0, y0, x1, y1) { if (cpQuiet()) return; self._paintGuarded(ov); };      // (27-oct, E7: la guarda, ui/starfield_panel.js `_paintGuarded`)
   ov.onResize = function() { if (cpQuiet()) return; if (self.canvas === ov && self.mode !== "" && !self._closed) self._render(); self._fsBarPlace(); };
   ov.onMousePress = function(x, y, button, buttons, modifiers) { self._fsTouch(); self._onPress(x, y, button, modifiers); };
   ov.onMouseMove = function(x, y, buttons, modifiers) { if (cpQuiet()) return; self._fsTouch(); self._onMove(x, y, buttons); };
   ov.onMouseRelease = function(x, y, button, buttons, modifiers) { self._onRelease(x, y, button); };
   ov.onMouseDoubleClick = function(x, y, buttons, modifiers) { if (self.mode !== "") self.resetView(); };
   ov.onMouseWheel = function(x, y, delta, buttons, modifiers) { self._fsTouch(); if (self.mode !== "") self._onWheel(x, y, delta); };
   ov.onLeave = function() { if (cpQuiet()) return; if (typeof self._c3LinkLeave === "function") self._c3LinkLeave(); if (self.mode !== "") self._setHover(-1, -1); };
   cpSetControlVisible(ov, false);
   // LA BARRA (hija del lienzo, colocada a mano)
   var bar = new Control(ov);
   cpApplyStyle(bar, "background-color:" + CP_ATLAS.bg + "; border:1px solid " + CP_ATLAS.gold + "; border-radius:" + CP_ATLAS.space[1] + "px;");
   bar.sizer = new HorizontalSizer;
   cpMargin(bar.sizer, CP_ATLAS.space[0]); cpGap(bar.sizer, CP_ATLAS.space[0]);
   function btn(text, tip, fn) { var b = new PushButton(bar); b.text = text; b.toolTip = cpTooltip(tip); b.cpTipKey = tip; b.onClick = function() { self._fsTouch(); fn(); }; cpStyleToggle(b, false); return b; }
   this.fsFoto = btn(optT("Photo"), "sf.fs.foto", function() { self.fullScreenShow("foto"); });
   this.fsDist = btn("3D", "sf.fs.dist", function() { self.fullScreenShow("dist"); });
   this.fsOptBtn = btn("⚙ " + optT("Options"), "sf.fs.options", function() { self.fullScreenOptions(!self.fs.optOpen); });
   this.fsExit = btn("", "sf.fullscreen.exit", function() { self.exitFullScreen(); });
   this.fsClose = btn("✕ " + optT("Close"), "c3.close", function() { try { self.dialog.closeScript(); } catch (eC) {} });   // Cabra3D: cerrar el script tambien desde aqui
   var ic = cpSfFsIcon(this.fsExit, true);
   if (ic) this.fsExit.icon = ic; else this.fsExit.text = "✕";
   bar.sizer.add(this.fsFoto); bar.sizer.add(this.fsDist);
   cpAddGap(bar.sizer, CP_ATLAS.space[1]);
   bar.sizer.add(this.fsOptBtn);
   cpAddGap(bar.sizer, CP_ATLAS.space[1]);
   bar.sizer.add(this.fsExit);
   cpAddGap(bar.sizer, CP_ATLAS.space[1]);
   bar.sizer.add(this.fsClose);
   cpSetControlVisible(bar, false);
   // EL PANEL DE OPCIONES: transparente y SIN borde en su hoja (una hoja sin selector la heredan los hijos: un borde dorado
   // saldria en cada boton); su fondo y su filete dorado se PINTAN en onPaint. Dentro, al abrirse, la caja de los mandos.
   var opt = new Control(ov);
   cpApplyStyle(opt, "background-color:transparent; border:none;");
   opt.sizer = new VerticalSizer;
   cpMargin(opt.sizer, CP_ATLAS.space[1]);
   opt.onPaint = function() {
      if (cpQuiet()) return;
      var g = new Graphics(opt), r = cpPx(CP_ATLAS.space[1], opt);
      try {
         g.antialiasing = true;
         g.pen = new Pen(cpInt(CP_ATLAS.gold), Math.max(1, cpPx(1, opt))); g.brush = new Brush(cpInt(CP_ATLAS.bg, 0.94));
         cpRoundRect(g, 0.5, 0.5, opt.width - 0.5, opt.height - 0.5, r);
      } finally { g.end(); }
   };
   cpSetControlVisible(opt, false);
   this.fs.ov = ov; this.fs.bar = bar; this.fs.opt = opt;
   // el tic que esconde la barra
   var fsTimer = new Timer;
   fsTimer.interval = CP_SFFS.TICK_S; fsTimer.periodic = true;
   fsTimer.onTimeout = function() { if (cpQuiet()) return; self._fsTick(); };
   this.fs.timer = fsTimer;
};

// ENTRAR. Devuelve true si entra.
CPStarfieldDock.prototype.enterFullScreen = function() {
   if (this.isFullScreen() || this.mode === "" || this._closed || this.state === null) return false;
   if (this.flightBusy && this.flightBusy()) return false;
   if (this.anim !== null) this._animEnd();
   var D = this.dialog;
   if (!this.fs.ov) this._fsMake();
   var c0 = D.localToGlobal(new Point(0, 0)), p = D.position;
   this.fs.saved = { x: p.x, y: p.y, w: D.width, h: D.height };
   var S = D.screenRect, dx = c0.x - p.x, dy = c0.y - p.y;
   this.fs.on = true; this.fs.optOpen = false;
   this.canvas = this.fs.ov;
   this._fsRowsAway();
   try { D.move(S.x0 - dx, S.y0 - dy); D.resize(S.x1 - S.x0, S.y1 - S.y0); } catch (eG) {}
   var ov = this.fs.ov;
   ov.position = new Point(0, 0); ov.resize(D.width, D.height);
   cpSetControlVisible(ov, true);
   try { ov.bringToFront(); } catch (eB) {}
   this._fsBarShow(true);
   try { this.fs.timer.start(); } catch (eT) {}
   this._syncButtons();
   this._render();
   try { ov.repaint(); } catch (eR) {}
   return true;
};
// SALIR. Desde la FOTO el panel se cierra (como siempre: la foto es el visor); desde el 3D se queda abierto
// con la vista, el zoom y la orbita de antes.
CPStarfieldDock.prototype.exitFullScreen = function() {
   if (!this.isFullScreen()) return false;
   if (this.flightBusy && this.flightBusy()) return false;
   if (this.anim !== null) this._animEnd();
   var D = this.dialog, s = this.fs.saved, foto = (this.mode === "");
   try { this.fs.timer.stop(); } catch (eT) {}
   cpSetControlVisible(this.fs.bar, false); this.fs.barOn = false;
   cpSetControlVisible(this.fs.opt, false); this.fs.optOpen = false;
   cpSetControlVisible(this.fs.ov, false);
   this.canvas = this._canvasDocked;
   this._fsRowsHome();
   this.fs.on = false; this.fs.foto = false;
   try { if (s) { D.move(s.x, s.y); D.resize(s.w, s.h); } } catch (eG) {}
   // (cerrar de verdad: «close» ya sin la pantalla completa)
   if (foto) { this.mode = "dist"; this.close(); }
   else { this._syncButtons(); this._render(); try { this.canvas.repaint(); } catch (eR) {} }
   return true;
};
// CAMBIAR DE VISTA dentro de la pantalla completa: "foto" | "dist", con su transicion (Cabra3D: sin el HR).
CPStarfieldDock.prototype.fullScreenShow = function(what) {
   if (!this.isFullScreen() || (this.flightBusy && this.flightBusy())) return false;
   if (what === "foto") { if (this.mode === "") return false; this.closeAnimated(); this._fsSync(); return true; }
   if (what !== "dist") return false;
   if (this.mode === what) return false;
   var r = this.dialog.annotPanel.openStarfield(what);
   this._fsSync();
   return !!(r && r.ok);
};
// LA FOTO dentro de la pantalla completa (lo llama `close`): el panel «cerrado» pero a la vista, con la foto encajada.
CPStarfieldDock.prototype._fsFotoRest = function() {
   this.flightEnd();
   this._animDrop();
   this._animOpenAt = 0;
   var lay = this.lay, w = this.canvas.width, h = this.canvas.height;
   this.mode = "";
   this.hoverStar = -1; this.hoverObj = -1;
   this.fs.foto = true;
   if (lay && this.state) {
      try { if (this.frame && this.frame !== (this.anim ? this.anim.buf : null)) this.frame.clear(); } catch (eF) {}
      this.frame = this._fotoChrome(w, h, lay.sc, this._fotoPad(lay));
   }
   try { this.dialog.preview.viewport.repaint(); } catch (e2) {}
   this._fsSync();
   try { this.canvas.repaint(); } catch (e) {}
};

// LA BARRA
CPStarfieldDock.prototype._fsTouch = function() {
   if (!this.isFullScreen()) return;
   this.fs.lastMove = CP_SFFS_CLOCK();
   if (!this.fs.barOn) this._fsBarShow(true);
};
CPStarfieldDock.prototype._fsBarShow = function(on) {
   if (!this.fs || !this.fs.bar) return;
   this.fs.barOn = !!on;
   if (on) { this.fs.lastMove = CP_SFFS_CLOCK(); this._fsSync(); }
   cpSetControlVisible(this.fs.bar, !!on);
   if (on) { this._fsBarPlace(); try { this.fs.bar.bringToFront(); } catch (e) {} }
   this._fsOptShow();
};
// Cabra3D (tarea H, V4, 21-oct): en una pantalla MUY ancha la barra crece con el dibujo (`c3BoxScale`): a 5 120 px era un sello de
// 20 px de alto. Se añade a cada boton una hoja que solo cambia la letra y el relleno (marcada, para quitarla y ponerla de nuevo).
CPStarfieldDock.prototype._fsBarScale = function() {
   var ov = this.fs ? this.fs.ov : null;
   if (!ov) return;
   var u = cpUiScale(ov), f = (typeof c3BoxScale === "function") ? c3BoxScale(ov.width, u) / u : 1, all = [this.fsFoto, this.fsDist, this.fsOptBtn, this.fsExit, this.fsClose];
   for (var i = 0; i < all.length; ++i) {
      var b = all[i]; if (!b) continue;
      try {
         var css = String(b.styleSheet || "").replace(/\/\*c3fs\*\/[\s\S]*$/, "");
         if (f > 1.05) css += "/*c3fs*/ QPushButton { font-size:" + Math.round(10 * u * f) + "px; padding:" + Math.round(1 * u * f) + "px " + Math.round(4 * u * f) + "px; }";
         if (css !== b.styleSheet) b.styleSheet = css;
      } catch (e) {}
   }
};
CPStarfieldDock.prototype._fsBarPlace = function() {
   var bar = this.fs ? this.fs.bar : null, ov = this.fs ? this.fs.ov : null;
   if (!bar || !ov) return;
   this._fsBarScale();
   try { bar.adjustToContents(); } catch (e) {}
   var m = cpPx(CP_ATLAS.space[2], ov);
   bar.position = new Point(Math.max(0, Math.round((ov.width - bar.width) / 2)), m);
   this._fsOptPlace();
};
CPStarfieldDock.prototype._fsTick = function() {
   // (Cabra3D, V4: Windows deja el dialogo ~30 px mas bajo de lo pedido DESPUES de entrar; el lienzo se quedaba con el alto pedido y el
   // pie salia cortado por abajo. En cada tic, el lienzo del tamaño del dialogo)
   try { var D = this.dialog, ov = this.fs ? this.fs.ov : null; if (this.isFullScreen() && ov && (ov.width !== D.width || ov.height !== D.height)) ov.resize(D.width, D.height); } catch (eS) {}
   if (!this.isFullScreen() || !this.fs.barOn) return;
   var under = false;
   try { under = this.fs.bar.isUnderMouse || (this.fs.optOpen && this.fs.opt.isUnderMouse) || (this.flPanel && this.fl.strip && this.flPanel.isUnderMouse); } catch (e) {}
   // (con las opciones abiertas se espera mas: elegir en un desplegable no mueve el raton sobre el lienzo)
   var wait = this.fs.optOpen ? CP_SFFS.OPT_HIDE_MS : CP_SFFS.BAR_HIDE_MS;
   if (!under && CP_SFFS_CLOCK() - this.fs.lastMove > wait) this._fsBarShow(false);
};
CPStarfieldDock.prototype._fsSync = function() {
   if (!this.fs || !this.fs.bar) return;
   var dist = (this.mode === "dist"), busy = !!(this.flightBusy && this.flightBusy());
   cpStyleToggle(this.fsFoto, this.mode === ""); cpStyleToggle(this.fsDist, dist);
   cpStyleToggle(this.fsOptBtn, !!this.fs.optOpen); cpStyleToggle(this.fsExit, false);
   // (en la FOTO no hay mandos que enseñar: las opciones son las de la vista)
   cpSetControlVisible(this.fsOptBtn, this.mode !== "");
   var views = [this.fsFoto, this.fsDist], i;
   for (i = 0; i < views.length; ++i) try { views[i].enabled = !busy; } catch (e) {}
   if (this.fs.barOn) this._fsBarPlace();
};
CPStarfieldDock.prototype._fsRetranslate = function() {
   if (!this.btnFull) return;
   this.btnFull.toolTip = cpTooltip("sf.fullscreen");
   if (!this.fs || !this.fs.bar) return;
   this.fsFoto.text = optT("Photo"); this.fsOptBtn.text = "⚙ " + optT("Options"); this.fsClose.text = "✕ " + optT("Close");
   var all = [this.fsFoto, this.fsDist, this.fsOptBtn, this.fsExit, this.fsClose];
   for (var i = 0; i < all.length; ++i) try { all[i].toolTip = cpTooltip(all[i].cpTipKey); } catch (e) {}
   this._fsSync();
};
// LAS TECLAS (las manda el dialogo, `_onEscKey`, antes que nada). true = la tecla era de la pantalla completa.
CPStarfieldDock.prototype.fullScreenKey = function(key, modifiers) {
   if (!this.isFullScreen() || (modifiers && modifiers !== 0)) return false;
   this._fsTouch();
   if (key === 27) {
      if (this.flightBusy && this.flightBusy()) return false;         // (Esc es del vuelo: lo para)
      this.exitFullScreen();
      return true;
   }
   var k = String.fromCharCode(key).toUpperCase();
   if (k === "1" || k === "F") { this.fullScreenShow("foto"); return true; }
   if (k === "3" || k === "D") { this.fullScreenShow("dist"); return true; }   // (Cabra3D: sin el HR, que era el 2 / H)
   return false;
};
CPStarfieldDock.prototype._fsCleanup = function() {
   if (!this.fs) return;
   try { if (this.fs.timer) this.fs.timer.stop(); } catch (e) {}
   if (this.fs.on) { this.canvas = this._canvasDocked; this.fs.on = false; try { this._fsRowsHome(); cpSetControlVisible(this.fs.ov, false); } catch (e2) {} }
};

// ---------------------------------------------------------------------------
// LAS OPCIONES: la caja de los mandos del panel, MUDADA (no copiada)
// ---------------------------------------------------------------------------
// Todos los controles de la caja de los mandos (las dos filas): los de la vista, los del vuelo, «Stars» y «Nebula…».
// Es la lista con la que la prueba mira que cada uno esta en el panel normal Y en el de la pantalla completa (el mismo).
CPStarfieldDock.prototype._fsRowControls = function() {
   return [this.btnPersp, this.btnSide, this.btnLog, this.btnSeg, this.btnLy, this.btnPc,
           this.zoomLabel, this.zoomSlider, this.btnFull, this.btnToView, this.btnToFile,
           this.flCombo, this.flDurLabel, this.flDur, this.flDurUnit, this.flPlay, this.flAdd, this.flDel, this.starsLabel, this.starsCombo, this.btnNebula, this.flRec, this.flOpt];
};
// Al ENTRAR: la caja de los mandos sale del panel y entra en el de opciones; el panel «▾» de grabar, al lienzo grande.
CPStarfieldDock.prototype._fsRowsAway = function() {
   var opt = this.fs.opt;
   try { this.container.sizer.remove(this.rowsBox); } catch (e) {}
   this.rowsBox.parent = opt;
   opt.sizer.add(this.rowsBox);
   if (this.flPanel) this.flPanel.parent = this.fs.ov;
};
// Al SALIR: a su sitio de siempre (arriba del panel) y el panel «▾», al lienzo de siempre.
CPStarfieldDock.prototype._fsRowsHome = function() {
   var opt = this.fs ? this.fs.opt : null;
   if (!opt || this.rowsBox.parent === this.container) return;
   try { opt.sizer.remove(this.rowsBox); } catch (e) {}
   this.rowsBox.parent = this.container;
   this.container.sizer.insert(0, this.rowsBox);
   cpSetControlVisible(this.rowsBox, true);
   if (this.flPanel) this.flPanel.parent = this._canvasDocked;
};
// ABRIR o CERRAR las opciones (el boton «⚙ Options» de la barra). No cambia el lienzo: el panel va encima.
CPStarfieldDock.prototype.fullScreenOptions = function(open) {
   if (!this.isFullScreen()) return false;
   this.fs.optOpen = !!open;
   this.fs.lastMove = CP_SFFS_CLOCK();
   this._fsSync();
   this._fsOptShow();
   return true;
};
CPStarfieldDock.prototype._fsOptShow = function() {
   var opt = this.fs ? this.fs.opt : null;
   if (!opt) return;
   var on = !!(this.fs.on && this.fs.barOn && this.fs.optOpen && this.mode !== "");
   cpSetControlVisible(opt, on);
   if (on) { this._fsOptPlace(); try { opt.bringToFront(); } catch (e) {} }
};
CPStarfieldDock.prototype._fsOptPlace = function() {
   var opt = this.fs ? this.fs.opt : null, ov = this.fs ? this.fs.ov : null, bar = this.fs ? this.fs.bar : null;
   if (!opt || !ov || !bar || opt.__cpHidden === true) return;
   try { this.rowsBox.ensureLayoutUpdated(); this.rowsBox.adjustToContents(); opt.ensureLayoutUpdated(); opt.adjustToContents(); } catch (e) {}
   // (con la fila del vuelo escondida su hueco del sizer dejaba una franja vacia debajo —visto en la captura—: el alto,
   // hasta el pie de la fila de arriba; con ella a la vista, el que pide el contenido. Medido DESPUES de rehacer la disposicion.)
   var pad = cpPx(CP_ATLAS.space[1], opt), h = opt.height;
   if (this.flCombo.__cpHidden === true) { try { h = Math.min(opt.height, this.rowsBox.position.y + this.rowsBox.height + 2 * pad); } catch (eB) {} }
   var m = cpPx(CP_ATLAS.space[2], ov), w = Math.min(opt.width, ov.width - 2 * m);
   if (w !== opt.width || h !== opt.height) try { opt.resize(w, h); } catch (e2) {}
   opt.position = new Point(Math.max(m, Math.round((ov.width - opt.width) / 2)), bar.position.y + bar.height + Math.round(m / 2));
};
