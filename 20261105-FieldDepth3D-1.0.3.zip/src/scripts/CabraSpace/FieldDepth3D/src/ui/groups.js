// ============================================================================
// ui/groups.js — LOS MANDOS DEL PANEL, POR CLASES (encargo de Nino, 15-oct-2026)
// ----------------------------------------------------------------------------
// Antes, cuatro filas seguidas (la de la vista, la del vuelo, las dos de la maquina del tiempo) con cosas de una clase en
// la fila de otra («Stars» y «Nebula…» en la del vuelo; «Dust» y «Sky» en la del tiempo) y DOS botones de grabar («● Record»
// del vuelo y «● Video» del tiempo). Ahora, tres grupos con su cabecera (icono SVG que evoca la funcion, titulo en versalitas
// y un ▸/▾), plegables, PLEGADOS al abrir y en acordeon (abrir uno cierra los demas: criterio §11):
//   ◇ VISTA 3D           — como veo la escena: perspectiva / lado, log / tramos, ly / pc, zoom, y las capas
//                          (estrellas, nebulosa, polvo, el cielo desde una estrella)
//   ▶ VUELO Y VIDEO      — como navego y grabo: el vuelo, su duracion, previsualizar; UN solo «● Record» con «que grabar»
//                          (el vuelo, o la maquina del tiempo: foto + 3D, 3D o foto) y sus opciones ▾; exportar la vista
//   ⧗ MAQUINA DEL TIEMPO — la regla del tiempo, ▶ / ⟲ ahora, el alcance, el modelo de movimiento y las estelas
// Arriba del todo, fuera de los grupos, la pantalla completa. (El ✕ del panel se fue el 15-oct: cerraba la unica vista.)
// Los controles son los MISMOS de siempre (creados por sus modulos): aqui solo se cuelgan de la caja de su grupo
// (`Control.parent` se puede asignar: medido en CabraPilot) y se colocan. A pantalla completa la caja entera se muda al
// panel de opciones (ui/starfield_fullscreen.js), con sus grupos.
// ES5 (metodos de CPStarfieldDock).
// ============================================================================

var C3_GROUPS = [
   { key: "view",   title: "3D VIEW",          tip: "grp.view",   icon: "M12 3 L20 7.5 L20 16.5 L12 21 L4 16.5 L4 7.5 Z M4 7.5 L12 12 L20 7.5 M12 12 L12 21" },
   { key: "flight", title: "FLIGHT AND VIDEO", tip: "grp.flight", icon: "M3 7 H15 V17 H3 Z M15 10.5 L21 7 V17 L15 13.5" },
   { key: "time",   title: "TIME MACHINE",     tip: "grp.time",   icon: "M6 3 H18 M6 21 H18 M7 3 C7 9 12 10 12 12 C12 14 7 15 7 21 M17 3 C17 9 12 10 12 12 C12 14 17 15 17 21" }
];
// EL ICONO, PINTADO A TRAZOS (20-oct-2026, fallo de Nino: «Access violation … QTransform::type / QRasterPaintEngine::drawImage»
// en `g.drawBitmap` de esta cabecera, repintada dentro del bucle de eventos anidado de HistogramTransformation). Antes el
// icono era un `Bitmap` cargado de un SVG escrito en la carpeta temporal: un objeto nativo que vivia en una cache global y se
// dibujaba desde un manejador que PixInsight puede llamar en mitad de un proceso. Ahora NO hay bitmap ni fichero: la ruta del
// SVG (viewBox 24×24; solo M, L, H, V, C y Z, absolutas) se convierte UNA vez en polilineas de numeros de JS puro, y cada
// pintado las traza con `Graphics.drawLine` sobre el propio control. Los arcos y curvas (el reloj de arena) se aproximan
// con 12 segmentos por curva cubica.
var C3_GROUP_ICON_POLYS = {};
function c3PathToPolys(path) {
   var tok = String(path).match(/[MLHVCZ]|-?\d+(?:\.\d+)?/g) || [], polys = [], cur = null, i = 0, cx = 0, cy = 0, sx = 0, sy = 0, cmd = "";
   function num() { return parseFloat(tok[i++]); }
   while (i < tok.length) {
      if (/^[MLHVCZ]$/.test(tok[i])) cmd = tok[i++];
      if (cmd === "Z") { if (cur) { cur.push([sx, sy]); cx = sx; cy = sy; } cmd = ""; continue; }
      if (cmd === "M") { cx = num(); cy = num(); sx = cx; sy = cy; cur = [[cx, cy]]; polys.push(cur); cmd = "L"; }
      else if (cmd === "L") { cx = num(); cy = num(); if (!cur) { cur = [[cx, cy]]; polys.push(cur); } else cur.push([cx, cy]); }
      else if (cmd === "H") { cx = num(); cur.push([cx, cy]); }
      else if (cmd === "V") { cy = num(); cur.push([cx, cy]); }
      else if (cmd === "C") {
         var x1 = num(), y1 = num(), x2 = num(), y2 = num(), x3 = num(), y3 = num();
         for (var k = 1; k <= 12; ++k) {
            var t = k / 12, u = 1 - t;
            cur.push([u * u * u * cx + 3 * u * u * t * x1 + 3 * u * t * t * x2 + t * t * t * x3,
                      u * u * u * cy + 3 * u * u * t * y1 + 3 * u * t * t * y2 + t * t * t * y3]);
         }
         cx = x3; cy = y3;
      } else break;                                   // (una orden que no conocemos: se para, no se inventa)
   }
   return polys;
}
// Traza el icono de `G` con su esquina arriba-izquierda en (x, y) y de lado `px` (pixeles fisicos), en el color dado.
function c3GroupPaintIcon(g, path, x, y, px, color) {
   var polys = C3_GROUP_ICON_POLYS[path];
   if (polys === undefined) polys = C3_GROUP_ICON_POLYS[path] = c3PathToPolys(path);
   var k = px / 24;
   var w = Math.max(1, 1.8 * k);
   try { g.pen = (typeof PenCap_Round !== "undefined" && typeof PenJoin_Round !== "undefined") ? new Pen(color, w, PenStyle_Solid, PenCap_Round, PenJoin_Round) : new Pen(color, w); }
   catch (eP) { g.pen = new Pen(color, w); }
   for (var a = 0; a < polys.length; ++a) {
      var P = polys[a];
      for (var b = 1; b < P.length; ++b)
         g.drawLine(x + P[b - 1][0] * k, y + P[b - 1][1] * k, x + P[b][0] * k, y + P[b][1] * k);
   }
}
function c3GroupHash(s) { var h = 0; for (var i = 0; i < s.length; ++i) h = ((h << 5) - h + s.charCodeAt(i)) | 0; return h; }
// Las cabeceras vivas (para repintarlas cuando un proceso termina y se salto su pintado; ver c3ProcRun en host/host.js)
var C3_GROUP_HEADERS = [];
function c3GroupsRepaintAll() { for (var i = 0; i < C3_GROUP_HEADERS.length; ++i) { try { C3_GROUP_HEADERS[i].repaint(); } catch (e) {} } }

// LA CABECERA de un grupo: pintada (icono, titulo, ▸/▾ y un filete de oro), y un clic la abre o la cierra.
function c3GroupHeader(parent, dock, G) {
   var h = new Control(parent), self = dock;
   cpApplyStyle(h, "background-color:transparent; border:none;");
   var F = cpFont("text", CP_ATLAS.size.label, true, false, cpCapsSpacing(CP_ATLAS.size.label));
   try { h.setFixedHeight(cpUiPx(CP_ATLAS.space[4] + 2, h)); } catch (e) {}
   h.toolTip = cpTooltip(G.tip);
   h.cursor = new Cursor(StdCursor_PointingHand);
   C3_GROUP_HEADERS.push(h);
   h.onPaint = function() {
      if (cpQuiet() || c3ProcBusy()) return;           // (ni con un proceso en marcha: su bucle de eventos repinta a mitad de camino)
      var g = new Graphics(h), sc = cpUiScale(h), open = (self.c3Open === G.key);
      try {
         g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
         var W = h.width, H = h.height, pad = Math.round(CP_ATLAS.space[0] * sc), ip = Math.round(16 * sc), f = cpFont("text", CP_ATLAS.size.label * sc, true, false, cpCapsSpacing(CP_ATLAS.size.label * sc));
         // el filete de arriba, de oro: separa un grupo de otro
         g.pen = new Pen(cpInt(CP_ATLAS.gold, open ? 0.9 : 0.45), Math.max(1, sc)); g.drawLine(0, Math.round(sc), W, Math.round(sc));
         c3GroupPaintIcon(g, G.icon, pad, Math.round((H - ip) / 2), ip, cpInt(CP_ATLAS.gold, 1));
         g.font = f; g.pen = new Pen(open ? CP_INT_AMBER : CP_INT_TEXT2);
         var y = Math.round((H + f.ascent - f.descent) / 2);
         g.drawText(pad + ip + Math.round(CP_ATLAS.space[1] * sc), y, optT(G.title));
         g.pen = new Pen(open ? CP_INT_AMBER : CP_INT_MUTED);
         g.drawText(W - pad - f.width("▾"), y, open ? "▾" : "▸");
      } finally { g.end(); }
   };
   h.onMousePress = function(x, y, button) { if (button === OPT_MOUSE_LEFT) self.c3GroupToggle(G.key); };
   return h;
}

// EL ARMADO: se llama una vez, al final de `_tmBuild` (cuando ya existen todos los controles).
CPStarfieldDock.prototype._c3Layout = function() {
   var self = this, C = this.rowsBox, P = CP_SFUI.GAP;
   this.c3Open = "";                                 // plegados al abrir (§11)
   this.c3Groups = {};
   this.c3Blocks = {};
   function row(list) {
      var s = new HorizontalSizer; cpGap(s, P);
      for (var i = 0; i < list.length; ++i) {
         var it = list[i];
         if (it === "|") cpAddGap(s, CP_SFUI.PAD);
         else if (it === "~") s.addStretch();
         else if (it && it.ctl) s.add(it.ctl, it.k || 0);
         else if (it) s.add(it);
      }
      return s;
   }
   // las filas `rows` dentro de `box` (cada control pasa a ser hijo de `box`). Una entrada { block: nombre, rows: [...] } es un BLOQUE: un
   // control propio con sus filas, que se enseña o se esconde entero (24-oct-2026, Nino: en 3D VIEW las opciones de Galaxia van ABAJO, en el
   // sitio de las de Campo, y no al lado de «Campo | Galaxia»; tm/galaxy_view.js `_gxSync` elige el bloque: `self.c3Blocks`)
   function fill(box, rows) {
      for (var r = 0; r < rows.length; ++r) {
         if (rows[r] && rows[r].block) {
            var bk = new Control(box);
            cpApplyStyle(bk, "background-color:transparent; border:none;");
            bk.sizer = new VerticalSizer; cpGap(bk.sizer, P);
            fill(bk, rows[r].rows);
            self.c3Blocks[rows[r].block] = bk;
            box.sizer.add(bk);
            continue;
         }
         for (var k = 0; k < rows[r].length; ++k) { var c = rows[r][k]; c = (c && c.ctl) ? c.ctl : c; if (c && typeof c === "object" && c.parent !== undefined) { try { c.parent = box; } catch (eP) {} } }
         // (un poco de sangria: el cuerpo cuelga de su cabecera)
         var ind = new HorizontalSizer; cpAddGap(ind, CP_ATLAS.space[3]); ind.add(row(rows[r]), 100);
         box.sizer.add(ind);
      }
   }
   function group(G, rows) {
      var hdr = c3GroupHeader(C, self, G), body = new Control(C);
      cpApplyStyle(body, "background-color:transparent; border:none;");
      body.sizer = new VerticalSizer; cpGap(body.sizer, P);
      fill(body, rows);
      cpSetControlVisible(body, false);
      self.c3Groups[G.key] = { header: hdr, body: body, def: G };
      C.sizer.add(hdr); C.sizer.add(body);
   }
   // lo del panel, arriba a la derecha: pantalla completa y cerrar el panel (no son de ninguna clase)
   var top = new HorizontalSizer; cpGap(top, P);
   // «↻ Retry» (15-oct): solo cuando algo de la red fallo; vuelve a pedirlo (tm/netstatus.js)
   this.btnRetry = cpSfFlButton(C, "↻ " + optT("Retry"), "c3.retry", function() { self.c3NetRetry(); });
   cpSetControlVisible(this.btnRetry, false);
   top.add(this.btnRetry); top.addStretch(); top.add(this.btnFull);
   C.sizer.add(top);
   // ◇ VISTA 3D (23-oct-2026: arriba, «Field | Galaxy» —tm/galaxy_view.js, solo en Cabra3D: CabraStarAnalysis, que incluye este fichero
   // sin aquel, no tiene `_gxBuild` y sigue con sus dos filas—. 24-oct: arriba SOLO «Field | Galaxy»; debajo, las filas del modo elegido:
   // el bloque «field» —las de siempre— o el bloque «galaxy» en su sitio, con el mismo número de filas)
   var gx = (typeof this._gxBuild === "function") ? this._gxBuild(C) : null, viewRows = [];
   var fieldRows = [[this.btnPersp, this.btnSide, "|", this.btnLog, this.btnSeg, "|", this.btnLy, this.btnPc, "|", this.zoomLabel, this.zoomSlider, "~"],
                    [this.starsLabel, this.starsCombo, "|", this.btnNebula, this.dustBtn, this.skyBtn, this.btnErr, this.btnUnseen, "~"]];
   if (gx && gx.top && !c3GxBroken("beside")) {
      viewRows.push(gx.top);
      viewRows.push({ block: "field", rows: fieldRows });
      viewRows.push({ block: "galaxy", rows: gx.rows });
   } else if (gx) {
      // (el rojo `beside` de tests/c3_gx_review.js V9: lo de antes —las de Galaxia AL LADO de «Field | Galaxy», en la fila de arriba—)
      viewRows.push(gx.top.slice(0, gx.top.length - 1).concat(["|"], gx.rows[0].slice(0, gx.rows[0].length - 1), ["|"], gx.rows[1]));
      viewRows = viewRows.concat(fieldRows);
   } else viewRows = fieldRows;
   group(C3_GROUPS[0], viewRows);
   // ▶ VUELO Y VIDEO (un solo «● Record»: que grabar lo dice el desplegable de al lado)
   group(C3_GROUPS[1], [
      [this.flStrut, this.flCombo, "|", this.flDurLabel, this.flDur, this.flDurUnit, "|", this.flPlay, this.flAdd, this.flDel, "~"],
      [this.recWhat, this.flRec, this.flOpt, "~", this.btnToView, this.btnToFile]
   ]);
   // ⧗ MAQUINA DEL TIEMPO
   group(C3_GROUPS[2], [
      [this.tmNow, this.tmPlay, { ctl: this.tmSlider, k: 100 }, this.tmLabel],
      [this.tmRange, this.tmMotion, this.tmTrails, "~"]
   ]);
};
// Abrir o cerrar un grupo (acordeon: abrir uno cierra los demas).
CPStarfieldDock.prototype.c3GroupToggle = function(key) { this.c3GroupOpen(key, this.c3Open !== key); };
CPStarfieldDock.prototype.c3GroupOpen = function(key, on) {
   if (!this.c3Groups) return;
   var was = this.c3Open;
   this.c3Open = on ? key : (this.c3Open === key ? "" : this.c3Open);
   // CERRAR LA MAQUINA DEL TIEMPO es salir de ella (Nino, 21-oct: «elimina de la imagen su leyenda»): para la reproduccion y
   // vuelve a «ahora», que es lo que quita el rotulo, la leyenda de huecas y estelas, el frente de luz y la foto sin estrellas.
   // No si se pasa a VUELO Y VIDEO (desde alli se graba la maquina del tiempo) ni con una grabacion en marcha.
   var leaveTime = (was === "time" && this.c3Open !== "time" && this.c3Open !== "flight" && !(this.fl && this.fl.rec));
   for (var k in this.c3Groups) {
      var G = this.c3Groups[k];
      cpSetControlVisible(G.body, this.c3Open === k);
      try { G.header.repaint(); } catch (e) {}
   }
   try { this.rowsBox.adjustToContents(); } catch (e2) {}
   // (DESPUES de recolocar los mandos: el lienzo cambia de alto al plegar, y un dibujo hecho antes se quedaba en pantalla —medido
   // en tests/c3_tm_close.js: el 3D ya estaba en «ahora» y la ventana seguia ensenando el rotulo del tiempo—)
   if (leaveTime) {
      try {
         if (this.tm && (this.tm.t !== 0 || this.tm.playing || this.tm.go)) {
            this.tmGo(0);
            optProcessEvents();
            this._tmRepaint(false);
         }
      } catch (eT) {}
   }
   if (this.isFullScreen && this.isFullScreen()) { try { this._fsOptShow(); } catch (e3) {} }
};
// Los textos (el idioma cambia en vivo)
CPStarfieldDock.prototype._c3GroupsRetranslate = function() {
   if (!this.c3Groups) return;
   try { this.btnRetry.text = "↻ " + optT("Retry"); this.btnRetry.toolTip = cpTooltip("c3.retry"); } catch (eR) {}
   for (var k in this.c3Groups) { var G = this.c3Groups[k]; try { G.header.toolTip = cpTooltip(G.def.tip); G.header.repaint(); } catch (e) {} }
};
