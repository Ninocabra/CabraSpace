// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_nebula.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_nebula.js — LA NEBULOSIDAD, A SU DISTANCIA, EN «Distances» (14-oct-2026)
// ----------------------------------------------------------------------------
// Peticion de Nino (14-oct-2026): «en la representacion 3D / Distances, en el caso de la nebulosidad, ¿puedes
// tambien asignarle una distancia y ponerla en ese punto?». Hasta aqui solo tenian recorte los objetos con
// distancia Y tamaño en SIMBAD (planetarias, galaxias); una nebulosa difusa casi nunca trae tamaño, y muchas
// tampoco distancia.
//
// QUIEN HACE QUE:
//   · `engine/starfield.js` (puro): de que catalogo sale cada distancia y cual se usa (`cpSfNebulaPick`), la
//     huella de la nebulosa en la foto (`cpSfNebulaFootprint`), la mediana de las paralajes de sus estrellas.
//   · `engine/starfield_run.js`: `cpStarfieldNebulae` (las de Sharpless que tocan la foto y SIMBAD).
//   · `ui/starfield_view.js` (puro): la nebulosa en el modelo de la vista (kind "nebula", con su huella como
//     recorte), la capa (`cpSvNebulaMatte`) y quitar estrellas sin StarXTerminator ni StarNet2 (`cpSvStarlessOwn`).
//   · AQUI: lo que toca PixInsight —preguntar a la red en el paso de red del panel, quitar las estrellas de la
//     foto con StarXTerminator o StarNet2 si estan instalados (en una ventana oculta y temporal: nada entra en la
//     barra ni en el historial de la imagen), hacer la capa en bitmaps— y la distancia ESCRITA A MANO (un cuadro
//     pequeño; se guarda en la imagen, como «My flight»).
//
// COMO SE PINTA: la capa es un RECORTE mas (`_drawCutout`, ui/starfield_panel.js): su luz SUMANDO (`Screen`), con
// NEB_ALPHA de opacidad (semitransparente), en un plano a su distancia, de su tamaño angular real (su huella en la
// foto: de frente cae EXACTAMENTE sobre la foto), mirando a la camara como los demas; y al abrirse la caja la
// nebulosa SALE de la foto (su hueco le resta su luz: quedan las estrellas, que tienen su distancia propia). Por
// ser un recorte entra sola en las transiciones FOTO ↔ 3D y en los vuelos.
//
// LO QUE NO ES DE AQUI: ejecutar un proceso dentro de `ui/starfield_panel.js` (guardian L0-94); por eso quitar
// estrellas vive en este fichero, y se hace en el paso de red (un temporizador, nunca en `onPaint`).
// ES5 salvo la subclase de `Dialog` (obligatoria bajo `#engine v8`).
// ============================================================================

// (5-nov-2026, decision de Nino: «mas que una resolucion fija, un porcentaje de la de la imagen») La foto sin estrellas y la capa de la
// nebulosa, como PORCENTAJE DEL LADO MAYOR DE LA IMAGEN: RES_HI_PCT en reposo, en el video y en la captura; RES_LO_PCT mientras se gira,
// se arrastra o se acerca (el dibujo ligero, `_light`: FieldDepth3D no tiene otro modo de «baja resolucion»). Nunca mas que la foto
// grande de la que salen (`st.photoFull`: la imagen hasta IMAGE_MAX de lado). Antes: tope fijo de 2048 (sin estrellas) y 1280 (capa).
// RES_FIXED = true: los topes fijos de antes (SRC_MAX, LAYER_MAX, LAYER_HI) —la costura del rojo de tests/c3_neb_tp_body.jsh N8—.
var C3_NEB_RES_HI_PCT = 75;
var C3_NEB_RES_LO_PCT = 40;
var C3_NEB_RES_FIXED = false;
var CP_SFNEB = {
   SRC_MAX: 2048,                   // (con C3_NEB_RES_FIXED) lado mayor de la foto que se pasa a StarXTerminator / StarNet2 (pixeles de imagen)
   LAYER_MAX: 1280,                 // (con C3_NEB_RES_FIXED) lado mayor de la capa de una nebulosa en el panel
   LAYER_HI: 2048,                  // (con C3_NEB_RES_FIXED) …y en un video
   PROP: "CabraPilot:NebulaDistance",   // la distancia escrita a mano, en la imagen (JSON { "<id>": { pc, err } })
   PROP_TYPE: 46, PROP_ATTR: 0x80 | 0x20 // (los mismos que «My flight»: una cadena que se guarda con la imagen)
};
// (5-nov) el lado mayor permitido, en pixeles, para un porcentaje del lado mayor de la IMAGEN (la que tiene la vista, no la foto grande)
function c3NebResSide(st, pct) {
   var img = 0;
   try { img = Math.max(st.result.field.width, st.result.field.height); } catch (e) {}
   if (!(img > 0)) { var s = st.photoFull || st.photo; img = s ? Math.max(s.width, s.height) : 0; }
   return Math.max(8, Math.round(img * pct / 100));
}
// COSTURA PARA PRUEBAS: como se quitan las estrellas. "auto" = StarXTerminator, si no StarNet2, si no la propia;
// "own" = la propia (`cpSvStarlessOwn`); "none" = no se quitan (el control: la capa lleva las estrellas).
var CP_SFNEB_STARLESS = "auto";
// (29-oct-2026, barrido 3D, S4) MIENTRAS StarXTerminator TRABAJA, NINGUNA CAPA. `_nebulaStarless` deja `st.starless` = { method "own", bmp null }
// ANTES de lanzar el motor y su aviso («Removing the stars…») deja pintar: un dibujo en esos segundos hacia la capa con la mascara
// PROPIA y la guardaba (`st.cuts`), y `_nebulaPrepare` ya no la rehacia con la foto sin estrellas. Visto en el barrido: en el Alma,
// la Roseta, IC 1396, el Tulipan y la Bruja la capa salio «own» (engine "") con StarXTerminator instalado; en el Alma, negra
// (cubierta 0,010; en Collinder 34, la misma Sh 2-199 con SXT, 0,861). Con la costura, mientras `busy` la capa espera (su simbolo).
var CP_SFNEB_WAIT_STARLESS = true;

// ---------------------------------------------------------------------------
// LA NEBULOSA GRANDE, UNA CAPA FINA A SU DISTANCIA (Cabra3D, 28-oct-2026; arreglos A2 + B + C1 aprobados por Nino tras el
// diagnostico de Collinder 34, tests/c3_neb_c34_probe.log). En el campo de Sh 2-199 la capa —la foto entera— era un CARTEL que
// miraba a la camara (`cpSvCutoutFace` = 1 con la caja abierta): de canto abarcaba t 0,37…0,90 (de ~285 pc a ~14 kpc) en una caja
// de 1,9 lados de fondo, y parecia ir de la foto al final de las estrellas; su hueco vaciaba la foto (marco oscuro de frente).
//   B   SIN CARTEL lo que es nebulosa o mide mas de FACE_MAX_EXT: plano paralelo a la foto (`c3CutNoFace`). Galaxias y planetarias
//       (todas por debajo: medido en tests/c3_neb_c34_data.log) lo conservan;
//   A2  la nebulosa, en SHEETS laminas paralelas repartidas en su profundidad real (`_c3NebHalfDepth`), que se reparten su luz;
//   C1  la que cubre mas de HOLE_MAX_COVER de la foto NO le hace hueco (la foto se queda con su nebulosidad) y, vista a traves de la
//       foto desde delante, se apaga como las estrellas de detras (GLASS, el C3_GLASS_STARS de ui/starfield_panel.js).
// ---------------------------------------------------------------------------
var C3_NEB_FIX = { FACE_MAX_EXT: 0.25, SHEETS: 5, HOLE_MAX_COVER: 0.75, GLASS: 0.35 };
var C3_NEB_FIX_ON = { face: true, sheets: true, hole: true, share: true };      // las costuras del rojo (tests/c3_neb_c34_fix.js; share: false = cada lamina con toda la luz)
// ¿Va sin cartel? (B)
function c3CutNoFace(ob) { return C3_NEB_FIX_ON.face === true && !!ob && (ob.kind === "nebula" || ob.ext > C3_NEB_FIX.FACE_MAX_EXT); }
// La fraccion de la foto que cubre la huella de una nebulosa del modelo (0 si no se sabe)
CPStarfieldDock.prototype._c3NebCover = function(st, ob) {
   try { var nb = st.result.nebulae.objects[ob.ref]; return (nb && nb.foot && nb.foot.frac > 0) ? nb.foot.frac : 0; } catch (e) { return 0; }
};
// ¿Sin hueco en la foto? (C1)
CPStarfieldDock.prototype._c3NebNoHole = function(st, ob) {
   return C3_NEB_FIX_ON.hole === true && !!ob && ob.kind === "nebula" && this._c3NebCover(st, ob) > C3_NEB_FIX.HOLE_MAX_COVER;
};
// EL SEMIESPESOR de la capa (A2), en parsecs: el mayor de (a) su RADIO —el tamaño angular de Sharpless por la distancia— y (b) la mitad
// de su intervalo de distancia; nunca mas que la mitad del fondo de las estrellas del campo (p5…p95 de las de paralaje fiable).
// -> { h, phys, err, cap }
CPStarfieldDock.prototype._c3NebHalfDepth = function(st, model, ob) {
   var nb = null;
   try { nb = st.result.nebulae.objects[ob.ref]; } catch (e) { nb = null; }
   var rd = (nb && nb.radiusDeg > 0) ? nb.radiusDeg : 0, phys = ob.pc * Math.tan(rd * Math.PI / 180), err = (ob.hi > ob.lo) ? (ob.hi - ob.lo) / 2 : 0;
   if (!model._c3StarSpan) {
      var pcs = [], i;
      for (i = 0; i < model.objects.length; ++i) if (model.objects[i].kind === "star" && !model.objects[i].suspect) pcs.push(model.objects[i].pc);
      pcs.sort(function(a, b) { return a - b; });
      model._c3StarSpan = (pcs.length >= 20) ? { p5: pcs[Math.round(0.05 * (pcs.length - 1))], p95: pcs[Math.round(0.95 * (pcs.length - 1))] } : { p5: 0, p95: 0 };
   }
   var S = model._c3StarSpan, cap = (S.p95 > S.p5) ? (S.p95 - S.p5) / 2 : Infinity, h = Math.min(Math.max(phys, err), cap);
   return { h: (h > 0 && isFinite(h)) ? h : 0, phys: phys, err: err, cap: cap };
};
// (5-nov-2026, opcion 3 de Nino: «quitar el emborronado entre laminas») Vista de lado —no de canto— las SHEETS copias caen desplazadas
// en pantalla y la nebulosa se ve borrosa. C3_NEB_SHEET_MODE: "single" = una sola lamina, a su distancia, cuando la primera y la ultima se
// separan en pantalla mas de SHEET.PX pixeles; "close" = las cinco, juntadas hasta que se separen SHEET.PX; "five" = como antes (la costura
// del rojo). De CANTO (la capa casi de perfil: |a×b| / max(|a|,|b|)² < SHEET.EDGE) siguen las cinco a su profundidad real: alli se ve
// su espesor y no hay detalle que emborronar. Girando, una sola (como antes).
var C3_NEB_SHEET_MODE = "single";
var C3_NEB_SHEET = { PX: 1.5, EDGE: 0.25 };
// LA NEBULOSA EN LAMINAS (A2): SHEETS planos paralelos a la foto de pc − h a pc + h, cada uno con la opacidad que hace que, uno encima
// de otro, den lo que daba la capa sola en su brillo tipico (`cbar`): 1 − (1 − a·c)^K = 1 − (1 − α·c) en c = cbar. Devuelve la afin de
// la del medio (para el raton). `o.light` (girando): una sola.
CPStarfieldDock.prototype._c3NebSheets = function(g, st, model, fit, scale, cut, o) {
   var ob = model.objects[cut.index], K = (o && o.light === true) ? 1 : Math.max(1, Math.round(C3_NEB_FIX.SHEETS));
   var D = this._c3NebHalfDepth(st, model, ob);
   if (K === 1 || !(D.h > 0) || !scale || typeof scale.t !== "function") return this._drawCutout(g, st, model, fit, cut, o);
   var bm = this._cutOf(st, model, cut, !!(o && o.hi === true));
   if (bm === null) return null;
   // (5-nov, opcion 3 de Nino) SIN EMBORRONAR: lo que se separan en pantalla la primera y la ultima lamina (`d`, px) y si la capa esta de canto
   var tc = scale.t(Math.max(1e-6, ob.pc)), sq = 1, edge = false, d = 0;
   if (C3_NEB_SHEET_MODE !== "five") {
      var Q0 = cpSvCutoutAffine(fit, bm, scale.t(Math.max(1e-6, ob.pc - D.h)), 0), Q1 = cpSvCutoutAffine(fit, bm, scale.t(ob.pc + D.h), 0);
      if (Q0 && Q1) {
         for (var qi = 0; qi < 4; ++qi) d = Math.max(d, Math.sqrt(Math.pow(Q1.quad[qi].x - Q0.quad[qi].x, 2) + Math.pow(Q1.quad[qi].y - Q0.quad[qi].y, 2)));
         var la = Math.sqrt(Q0.ax * Q0.ax + Q0.ay * Q0.ay), lb = Math.sqrt(Q0.bx * Q0.bx + Q0.by * Q0.by), mx = Math.max(la, lb);
         edge = !(mx > 0) || Math.abs(Q0.ax * Q0.by - Q0.ay * Q0.bx) / (mx * mx) < C3_NEB_SHEET.EDGE;
         if (!edge && d > C3_NEB_SHEET.PX) {
            if (C3_NEB_SHEET_MODE === "single") { this._c3NebSheetInfo = { K: 1, mode: "single", d: d, h: D.h, t: [tc] }; return this._drawCutout(g, st, model, fit, cut, o); }
            sq = C3_NEB_SHEET.PX / d;
         }
      }
   }
   var cb = (bm.cbar > 0) ? Math.min(1, bm.cbar) : 0.25, a1 = Math.min(0.999, CP_SV.NEB_ALPHA * cb), share = (1 - Math.pow(1 - a1, 1 / K)) / a1, mid = null, key;
   var info = { K: K, h: D.h, phys: D.phys, err: D.err, cap: D.cap, share: share, cbar: cb, t: [], mode: String(C3_NEB_SHEET_MODE), d: d, squeeze: sq, edge: edge };
   for (var k = 0; k < K; ++k) {
      var c2 = {}, o2 = {};
      for (key in cut) c2[key] = cut[key];
      for (key in o) o2[key] = o[key];
      c2.t = scale.t(Math.max(1e-6, ob.pc - D.h + 2 * D.h * k / (K - 1)));
      if (sq < 1) c2.t = tc + (c2.t - tc) * sq;
      o2.share = (C3_NEB_FIX_ON.share === false) ? 1 : share;
      info.t.push(c2.t);
      var A = this._drawCutout(g, st, model, fit, c2, o2);
      if (k === ((K - 1) >> 1)) mid = A;
   }
   this._c3NebSheetInfo = info;
   return mid;
};
// LO QUE SE APAGA una capa sin hueco vista desde delante a traves de la foto (C1): la fraccion de su cuadro que cae dentro del contorno
// de la foto en pantalla (7 × 7 muestras), por 1 − GLASS. 1 = no se apaga.
CPStarfieldDock.prototype._c3GlassK = function(fit, A, model) {
   var wn = model.wn, hn = model.hn, Q = [fit.px(-wn / 2, -hn / 2, 0), fit.px(wn / 2, -hn / 2, 0), fit.px(wn / 2, hn / 2, 0), fit.px(-wn / 2, hn / 2, 0)], s = 0, k;
   if (!A || !A.quad || !(Q[0].ok && Q[1].ok && Q[2].ok && Q[3].ok)) return 1;
   for (k = 0; k < 4; ++k) s += Q[k].x * Q[(k + 1) % 4].y - Q[(k + 1) % 4].x * Q[k].y;
   var sg = (s > 0) ? 1 : -1, q = A.quad, n = 0, inn = 0, i, j;
   for (j = 0; j < 7; ++j)
      for (i = 0; i < 7; ++i) {
         var fx = (i + 0.5) / 7, fy = (j + 0.5) / 7, x = q[0].x + (q[1].x - q[0].x) * fx + (q[3].x - q[0].x) * fy, y = q[0].y + (q[1].y - q[0].y) * fx + (q[3].y - q[0].y) * fy, ok = true;
         for (k = 0; k < 4 && ok; ++k) { var a = Q[k], b = Q[(k + 1) % 4]; if (sg * ((b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x)) < 0) ok = false; }
         ++n; if (ok) ++inn;
      }
   return 1 - (inn / n) * (1 - C3_NEB_FIX.GLASS);
};

// Lo escrito a mano para esta imagen: { "<id>": { pc, err } }.
CPStarfieldDock.prototype._nebulaManual = function(st) {
   try {
      var rec = this.dialog.findRecById(st.viewId), text = (rec && optSafeView(rec.view)) ? rec.view.propertyValue(CP_SFNEB.PROP) : null;
      return (typeof text === "string" && text.length > 0) ? cpSfNebulaManualParse(text) : {};
   } catch (e) { return {}; }
};

// EL PASO DE RED (lo llama `_netStep` en el paso «deepsky», detras de lo lejano): las nebulosas del campo y su
// distancia; y, si alguna se coloca, la foto sin estrellas de la que sale su capa. Devuelve el estado para `st.net.nebula`.
CPStarfieldDock.prototype._nebulaRun = function(st, opts) {
   var out = null;
   try {
      // (5-nov-2026) forceCatalog: «↻ Retry» con el catalogo de nebulosas sin bajar (tm/netstatus.js) lo pide ya, sin esperar al sello .fail
      var o = { httpTimeoutS: opts.httpTimeoutS, onProgress: opts.onProgress, manual: this._nebulaManual(st), forceCatalog: (st.nebForce === true) };
      st.nebForce = false;
      out = cpStarfieldNebulae(st.result, o);
   } catch (e) { out = { ok: false, code: "no-network", why: String(e.message || e) }; }
   if (!out || !out.ok) return "failed:" + ((out && out.code) || "no-network");
   // (22-oct: en el panel en vivo, la capa —StarXTerminator y la mascara, 1-4 s que no se pueden trocear— espera al reposo: `_idleArm`)
   if (out.withDistance > 0) {
      if (CP_SFUI_NET_DEFER === true && this._liveNet === true) { st.nebPrep = true; this._idleArm(); }
      else { this._nebulaStarless(st); this._nebulaPrepare(st); }
   }
   return "ok";
};
// LA CAPA, HECHA YA (en el paso de red, con su aviso): si no, la hacia el primer dibujo y el panel se quedaba parado unos
// segundos sin decir nada (3 s la de Sh 2-132 con la mascara propia; medido en `cp_nebula_look.log`).
CPStarfieldDock.prototype._nebulaPrepare = function(st) {
   var model = cpSvDistModel(st.result, {}), n = 0;
   this._say(optT("Preparing the layer of the nebula…"), "info");
   for (var i = 0; i < model.objects.length; ++i) {
      var ob = model.objects[i];
      if (ob.kind !== "nebula") continue;
      var r = cpSvCutoutRect(ob, model.wn, model.hn);
      if (r === null) continue;
      if (this._nebulaCutOf(st, model, { index: i, u0: r.u0, v0: r.v0, u1: r.u1, v1: r.v1, r: r.r }, false) !== null) ++n;
   }
   return n;
};

// LA FOTO SIN ESTRELLAS (una vez por imagen): la grande del visor, a SRC_MAX de lado, por StarXTerminator o StarNet2
// en una ventana OCULTA y temporal (sin historial, fuera de la barra, cerrada al acabar). Si no hay ninguno, o falla,
// la propia (`cpSvStarlessOwn`, al hacer la capa). `st.starless` = { bmp (o null), method, engine, ms, why }.
CPStarfieldDock.prototype._nebulaStarless = function(st) {
   if (st.starless) return st.starless;
   var src = st.photoFull || st.photo, t0 = Date.now(), mode = String(CP_SFNEB_STARLESS);
   st.starless = { bmp: null, method: (mode === "none") ? "none" : "own", engine: "", ms: 0, why: "" };
   if (mode !== "auto" || !src) { if (!src) st.starless.why = "no photo"; return st.starless; }
   var engines = [], i;
   try { var av = cpStarAvailableEngines(); for (i = 0; i < av.length; ++i) if (av[i].id === "SXT" || av[i].id === "SN2") engines.push(av[i]); } catch (eA) {}
   engines.sort(function(a, b) { return (a.id === "SXT") ? -1 : (b.id === "SXT") ? 1 : 0; });
   if (engines.length === 0) { st.starless.why = "StarXTerminator and StarNet2 not installed"; return st.starless; }
   var srcMax = (C3_NEB_RES_FIXED === true) ? CP_SFNEB.SRC_MAX : c3NebResSide(st, C3_NEB_RES_HI_PCT);      // (5-nov: % de la imagen)
   var k = Math.min(1, srcMax / Math.max(src.width, src.height)), w =Math.max(2, Math.round(src.width * k)), h = Math.max(2, Math.round(src.height * k));
   // (StarNet2 pide al menos 512 x 512)
   if (engines[0].id === "SN2" && (w < 512 || h < 512)) { st.starless.why = "photo too small for StarNet2"; return st.starless; }
   var small = new Bitmap(w, h), g = new Graphics(small), win = null, self = this;
   try { g.smoothInterpolation = true; g.drawScaledBitmap(new Rect(0, 0, w, h), src); } finally { g.end(); }
   st.starless.busy = true;      // (S4: hasta el `finally`, `_nebulaCutOf` no hace capas)
   try {
   this._say(format(optT("Removing the stars of the nebula with %s…"), engines[0].label), "info");
      win = new ImageWindow(w, h, 3, 32, true, true, optUniqueId("cp_nebula_starless"));
      var v = win.mainView;
      v.beginProcess(UndoFlag_NoSwapFile);
      try { v.image.blend(small); } finally { v.endProcess(); }
      var values = cpStarDefaults(engines[0]);
      values.starsImage = CP_STAR_IMAGE_NONE;
      if (engines[0].id === "SN2") values.linear = 2;               // «Non-linear»: lo que se le pasa es la foto ya estirada
      // (SIN `cpBackgroundRun`: marcado como trabajo de fondo, el propio guardian de ejecutar lo rechaza —«CabraPilot was busy
      // for an instant with a background measurement…»—: medido el 14-oct-2026 en la primera pasada de `cp_nebula_look.js`)
      var res = cpStarRunOnView(engines[0].id, values, v);
      if (res && res.ok) {
         st.starless.bmp = optRenderDirect(v.image, 1, true);
         st.starless.method = engines[0].id; st.starless.engine = engines[0].label;
      } else st.starless.why = (res && (res.brief || res.message)) ? String(res.brief || res.message) : "the process failed";
   } catch (e) {
      st.starless.why = String(e.message || e);
   } finally {
      try { if (win) win.forceClose(); } catch (eC) {}
      cpSfUiFree(small);
      st.starless.busy = false;
   }
   st.starless.ms = Date.now() - t0;
   // (tarea H7: «Removing the stars… with StarXTerminator…» se quedaba en la linea de estado despues de acabar)
   try { if (this._c3SayCurrent) this._c3SayCurrent(); else this._sayState(); } catch (eS) {}
   return st.starless;
};

// QUITAR LAS ESTRELLAS SIN MOTOR EXTERNO (21-oct-2026): con la lista de Gaia (posicion, G y la FWHM de la foto: `cpSvStarlessGaia`, el
// perfil de cada estrella y un relleno liso de su disco) y, si no hay lista, la apertura de siempre (`cpSvStarlessOwn`). La apertura sola
// dejaba un cuadrado gris y un halo en las brillantes (medido a 1:1 contra StarXTerminator: tests/c3_starless_compare.js).
// (r, g, b) son los canales (0…255) de w × h del trozo (x0, y0) de la foto grande `st.photoFull || st.photo`, reducido por kx × ky.
// La FWHM de las estrellas, en pixeles de la IMAGEN: la de la fotometria del motor y, si no, medida en las brillantes (una vez por imagen).
CPStarfieldDock.prototype._starlessFwhm = function(st) {
   if (typeof st.starlessFwhm === "number") return st.starlessFwhm;
   var f = 0;
   try { var ph = st.result.photometry || {}; if (ph.method && ph.method.fwhmPx > 0) f = ph.method.fwhmPx; } catch (eP) {}
   if (!(f > 0)) try { var rec = this.dialog.findRecById(st.viewId); if (rec && optSafeView(rec.view)) f = cpSfUiPsFwhm(rec.view.image, st.result); } catch (eM) {}
   st.starlessFwhm = (f > 0) ? f : 3;
   return st.starlessFwhm;
};
CPStarfieldDock.prototype._starlessOwnRun = function(st, r, g, b, w, h, x0, y0, kx, ky) {
   var list = [], res = st.result, P = st.photoFull || st.photo, f = 1, i;
   try { var rec = this.dialog.findRecById(st.viewId); if (rec && optSafeView(rec.view) && P) f = P.width / Math.max(1, rec.view.image.width); } catch (eF) {}
   if (res && res.stars) for (i = 0; i < res.stars.length; ++i) {
      var s = res.stars[i];
      if (!s.inFrame || s.g === null || typeof s.x !== "number" || typeof s.y !== "number") continue;
      list.push({ x: (s.x * f - x0) * kx, y: (s.y * f - y0) * ky, g: s.g });
   }
   var out = null;
   if (list.length > 0) {
      try { out = cpSvStarlessGaia(r, g, b, w, h, list, this._starlessFwhm(st) * f * (kx + ky) / 2, {}); out.kind = "gaia"; } catch (eG) { out = null; }
   }
   if (out === null) { out = cpSvStarlessOwn(r, g, b, w, h, {}); out.kind = "opening"; }
   return out;
};

// LA CAPA DE UNA NEBULOSA: como `_cutOf` (lo que devuelve tiene la misma forma), pero de su huella entera y de la foto
// SIN ESTRELLAS. Se guarda por objeto (una vez).
CPStarfieldDock.prototype._nebulaCutOf = function(st, model, cut, hi) {
   var ob = model.objects[cut.index], key = ob.kind + ":" + ob.ref, src = st.photoFull || st.photo;
   if (!st.cutsHi) st.cutsHi = {};
   // (5-nov, % de la imagen) UNA capa, a RES_HI_PCT, para el reposo, el video y la captura; girando, su copia reducida a RES_LO_PCT
   // (`c3NebLighter`, hecha una vez y guardada en la propia capa)
   var pctOn = (C3_NEB_RES_FIXED !== true), light = (pctOn && hi !== true && this._light === true);
   if (pctOn) { var made = st.cutsHi[key] || st.cuts[key] || null; if (made) return light ? c3NebLighter(st, made) : made; }
   if (st.cutsHi[key]) return st.cutsHi[key];
   if (hi !== true && st.cuts[key]) return st.cuts[key];
   if (!src) return null;
   if (st.nebPrep === true && this._nebPrepNow !== true) return null;   // (22-oct: la capa se prepara en reposo; hasta entonces, su simbolo)
   if (CP_SFNEB_WAIT_STARLESS === true && st.starless && st.starless.busy === true) return null;      // (S4: StarXTerminator trabajando)
   if (hi !== true && this._cutLater(st)) return null;
   var t0 = Date.now(), W = src.width, H = src.height, wn = model.wn, hn = model.hn;
   var x0 = Math.max(0, Math.floor((cut.u0 / wn + 0.5) * W)), x1 = Math.min(W, Math.ceil((cut.u1 / wn + 0.5) * W)), y0 = Math.max(0, Math.floor((cut.v0 / hn + 0.5) * H)), y1 = Math.min(H, Math.ceil((cut.v1 / hn + 0.5) * H));
   if (x1 - x0 < 8 || y1 - y0 < 8) return null;
   var lim = !pctOn ? ((hi === true) ? CP_SFNEB.LAYER_HI : CP_SFNEB.LAYER_MAX) : c3NebResSide(st, C3_NEB_RES_HI_PCT), k = Math.min(1, lim / Math.max(x1 - x0, y1 - y0));
   var w = Math.max(8, Math.round((x1 - x0) * k)), h = Math.max(8, Math.round((y1 - y0) * k)), N = w * h, i, x, y;
   function grab(bmp, sx0, sy0, sx1, sy1) {
      var b = new Bitmap(w, h), gg = new Graphics(b);
      try { gg.smoothInterpolation = true; gg.drawScaledBitmapRect(new Rect(0, 0, w, h), bmp, new Rect(sx0, sy0, sx1, sy1)); } finally { gg.end(); }
      var R = new Float32Array(N), G = new Float32Array(N), B = new Float32Array(N);
      for (var yy = 0; yy < h; ++yy) for (var xx = 0; xx < w; ++xx) { var px = b.pixel(xx, yy) >>> 0, j = yy * w + xx; R[j] = (px >>> 16) & 255; G[j] = (px >>> 8) & 255; B[j] = px & 255; }
      cpSfUiFree(b);
      return [R, G, B];
   }
   var orig = grab(src, x0, y0, x1, y1), sl = st.starless || { bmp: null, method: "own" }, clean = null, method = sl.method, own = null;
   if (sl.bmp) {
      var ks = sl.bmp.width / W;
      clean = grab(sl.bmp, x0 * ks, y0 * ks, x1 * ks, y1 * ks);
   } else if (method === "none") clean = orig;
   else { own = this._starlessOwnRun(st, orig[0], orig[1], orig[2], w, h, x0, y0, w / (x1 - x0), h / (y1 - y0)); clean = [own.r, own.g, own.b]; method = "own"; if (st.starless) st.starless.ownKind = own.kind; }
   // su sitio exacto (de pixel entero a pixel entero) y su disco en pixeles de la capa
   var tu0 = (x0 / W - 0.5) * wn, tu1 = (x1 / W - 0.5) * wn, tv0 = (y0 / H - 0.5) * hn, tv1 = (y1 / H - 0.5) * hn;
   var disc = (ob.disc && ob.disc.r > 0) ? { cx: (ob.disc.u - tu0) / (tu1 - tu0) * w, cy: (ob.disc.v - tv0) / (tv1 - tv0) * h, r: ob.disc.r / (tu1 - tu0) * w } : null;
   var M = cpSvNebulaMatte(clean[0], clean[1], clean[2], w, h, { disc: disc }), gn = M.gain;
   var front = new Bitmap(w, h), hole = new Bitmap(w, h), cbS = 0, cbN = 0;      // (cbS/cbN, Cabra3D A2: el brillo tipico de la luz, `cbar`)
   for (y = 0; y < h; ++y)
      for (x = 0; x < w; ++x) {
         i = y * w + x;
         var a = M.a[i], fr = Math.min(255, Math.round(gn * M.r[i] * a)), fg = Math.min(255, Math.round(gn * M.g[i] * a)), fb = Math.min(255, Math.round(gn * M.b[i] * a));
         if (a > 0.02) { cbS += Math.max(fr, fg, fb) / 255; ++cbN; }
         front.setPixel(x, y, (0xff000000 | (fr << 16) | (fg << 8) | fb) >>> 0);
         // EL HUECO: la foto pierde la luz de la nebulosa (sin estrellas: las estrellas se quedan) —foto × (1 − luz / foto)—
         var hr = 1 - Math.min(1, a * M.r[i] / Math.max(1, orig[0][i])), hg = 1 - Math.min(1, a * M.g[i] / Math.max(1, orig[1][i])), hb = 1 - Math.min(1, a * M.b[i] / Math.max(1, orig[2][i]));
         hole.setPixel(x, y, (0xff000000 | (Math.round(255 * hr) << 16) | (Math.round(255 * hg) << 8) | Math.round(255 * hb)) >>> 0);
      }
   var sh = M.shine, rec = { front: front, back: front, hole: hole, shade: null, screen: true, hi: (hi === true), inner: 1, cx: 0.5, cy: 0.5, rx: 0.5, ry: 0.5, u0: tu0, v0: tv0, u1: tu1, v1: tv1, cbar: (cbN > 0) ? cbS / cbN : 0,
               shine: { u0: tu0 + sh.x0 / w * (tu1 - tu0), u1: tu0 + sh.x1 / w * (tu1 - tu0), v0: tv0 + sh.y0 / h * (tv1 - tv0), v1: tv0 + sh.y1 / h * (tv1 - tv0), px: Math.min(sh.x1 - sh.x0, sh.y1 - sh.y0) / k },
               nebula: { method: method, engine: sl.engine || "", why: sl.why || "", starsRemoved: own ? own.frac : null },
               matte: { bg: M.bg, sigma: M.sigma, removed: 0, kept: 0, edge: [0, 0, 0], flat: false, gain: M.gain, stars: 0, cover: M.cover, islands: 0, w: w, h: h, k: k, foot: Math.max(x1 - x0, y1 - y0), ms: Date.now() - t0 } };
   if (pctOn) { st.cutsHi[key] = rec; st.cuts[key] = rec; return light ? c3NebLighter(st, rec) : rec; }      // (5-nov: una sola, para todo)
   if (hi === true) st.cutsHi[key] = rec; else st.cuts[key] = rec;
   return rec;
};
// (5-nov) LA CAPA PARA GIRAR: la de reposo reducida a RES_LO_PCT del lado mayor de la imagen (escalado suave del bitmap; la mascara y la luz
// son las mismas). Se hace una vez y se guarda en la capa (`rec.lo`). Si no reduce nada, la misma capa.
function c3NebLighter(st, rec) {
   if (rec.lo) return rec.lo;
   var mt = rec.matte || {}, kLo = Math.min(1, c3NebResSide(st, C3_NEB_RES_LO_PCT) / Math.max(1, mt.foot || 1)), r = (mt.k > 0) ? kLo / mt.k : 1;
   if (!(r < 0.999)) { rec.lo = rec; return rec; }
   var w = Math.max(8, Math.round(rec.front.width * r)), h = Math.max(8, Math.round(rec.front.height * r));
   function down(b) { var o = new Bitmap(w, h), g = new Graphics(o); try { g.smoothInterpolation = true; g.drawScaledBitmap(new Rect(0, 0, w, h), b); } finally { g.end(); } return o; }
   var out = {}, p;
   for (p in rec) if (p !== "lo") out[p] = rec[p];
   out.front = down(rec.front); out.back = out.front; out.hole = down(rec.hole); out.light = true;
   out.matte = {}; for (p in mt) out.matte[p] = mt[p];
   out.matte.w = w; out.matte.h = h; out.matte.k = kLo;
   rec.lo = out;
   return out;
}

// El nombre del metodo propio (para la ficha de la nebulosa y el tooltip de la linea de estado).
CPStarfieldDock.prototype._starlessOwnName = function(kind) {
   return (kind === "opening") ? optT("its own morphological opening") : optT("its own method (Gaia star positions and a morphological opening)");
};
// Lo que se dice de como se ha quitado las estrellas (la ficha).
CPStarfieldDock.prototype._nebulaMethodText = function(st) {
   var sl = st ? st.starless : null;
   if (!sl) return "";
   if (sl.method === "SXT" || sl.method === "SN2") return format(optT("stars removed with %s"), sl.engine);
   if (sl.method === "none") return optT("stars not removed");
   // (21-oct-2026) dice QUE se ha usado (la lista de Gaia + la apertura, o solo la apertura) y que con StarXTerminator o StarNet2 saldria mas limpio
   return format(optT("stars removed with %s"), this._starlessOwnName(sl.ownKind)) +
          ((sl.why && sl.why.length) ? " (" + ((sl.why === "StarXTerminator and StarNet2 not installed") ? optT("StarXTerminator and StarNet2 not installed") : sl.why) + ")" : "") +
          ". " + optT("StarXTerminator or StarNet2, if you have them, give a cleaner result.");
};

// EL NOMBRE DE UNA FUENTE de distancia de nebulosa, corto (para la placa) o largo (para la ficha).
CPStarfieldDock.prototype._nebulaSourceText = function(d, short) {
   if (!d) return "";
   switch (String(d.source)) {
   case "simbad":
      var obj = (d.simbadName && d.simbadName.length) ? d.simbadName : "";
      if (short) return "SIMBAD";
      return optT("SIMBAD, measured distance") + (obj ? " (" + obj + ((d.simbadType === "OpC" || d.simbadType === "Cl*") ? ", " + optT("the cluster that lights it") : "") + ")" : "") +
             ((d.kind === "parallax" && d.catalog) ? " · " + optT("parallax") + " " + d.catalog : "") + ((d.bibcode) ? " · " + d.bibcode : "");
   case "foster-brunt": return short ? "Foster & Brunt 2015" : optT("Foster & Brunt 2015: distance to its ionising stars (spectrophotometric)") + (d.n > 0 ? " · " + format(optT("%d stars"), d.n) : "");
   case "wise": return short ? "WISE HII" : optT("Anderson et al. 2014, WISE HII catalogue") + (d.method ? " · " + d.method : "") + ((d.kind === "kinematic") ? " (" + optT("kinematic") + ")" : "");
   case "members-parallax": return short ? optT("its stars · Gaia DR3") : format(optT("median Gaia DR3 parallax of %d stars of the nebula (SIMBAD hierarchy)"), d.n);
   case "cluster-inside": return short ? d.clusterName : format(optT("the cluster %s, inside the nebula (association by position only)"), d.clusterName);
   case "manual": return short ? optT("by hand") : optT("entered by hand");
   }
   return String(d.source || "");
};
// «± error» de una distancia, o «error not declared».
CPStarfieldDock.prototype._nebulaErrText = function(d) {
   if (!d) return "";
   if (d.hi > d.lo && d.lo >= 0 && isFinite(d.hi)) {
      var W = this._words(), e = cpSvFormatDistance(Math.max(d.hi - d.pc, d.pc - d.lo), this.unit, W);
      return "± " + e.text;
   }
   if (d.hi === Infinity) return optT("upper bound unknown");
   return optT("error not declared");
};

// ---------------------------------------------------------------------------
// LA DISTANCIA ESCRITA A MANO
// ---------------------------------------------------------------------------
// Las nebulosas del campo (con o sin distancia), para el cuadro y para el boton.
CPStarfieldDock.prototype._nebulaList = function() {
   var st = this.state;
   return (st && st.result && st.result.nebulae && st.result.nebulae.objects) ? st.result.nebulae.objects : [];
};
// Pone (o, con pc <= 0, quita) la distancia escrita a mano de la nebulosa `id`: la guarda en la imagen y rehace la
// eleccion SIN red (las candidatas ya estan en el objeto). Devuelve true si la ha guardado.
CPStarfieldDock.prototype.setNebulaDistance = function(id, pc, errPc) {
   var st = this.state;
   if (!st) return false;
   var man = this._nebulaManual(st);
   if (pc > 0 && isFinite(pc)) man[id] = { pc: pc, err: (errPc > 0 && isFinite(errPc)) ? errPc : 0 };
   else delete man[id];
   var saved = false;
   try {
      var rec = this.dialog.findRecById(st.viewId);
      if (rec && optSafeView(rec.view)) { rec.view.setPropertyValue(CP_SFNEB.PROP, JSON.stringify(man), CP_SFNEB.PROP_TYPE, CP_SFNEB.PROP_ATTR); saved = true; }
   } catch (e) { saved = false; }
   var list = this._nebulaList(), placed = false;
   for (var i = 0; i < list.length; ++i) {
      if (list[i].id !== id) continue;
      var r = cpSfNebulaRepick(list[i].candidates, cpSfNebulaManualDistance(man[id] || null));
      list[i].candidates = r.list; list[i].dist = r.dist;
      placed = (r.dist !== null);
   }
   var n = 0;
   for (i = 0; i < list.length; ++i) if (list[i].dist) ++n;
   if (st.result.nebulae) st.result.nebulae.withDistance = n;
   if (placed) { this._nebulaStarless(st); this._nebulaPrepare(st); }
   // lo que dependia de la distancia se rehace (los recortes de esa nebulosa siguen valiendo: no dependen de ella)
   st.dist = null;
   if (this.state === st && this.mode !== "") { this._syncButtons(); this._render(); this._sayState(); }
   return saved;
};
// El cuadro. Lo abre el boton «Nebula…» de la fila (solo en «Distances» y con alguna nebulosa en el campo).
CPStarfieldDock.prototype.nebulaDistanceDialog = function() {
   var list = this._nebulaList();
   if (list.length === 0) return false;
   var d = new CPNebulaDistanceDialog(this, list);
   if (d.execute() !== 1 || d.nebulaResult === null) return false;
   return this.setNebulaDistance(d.nebulaResult.id, d.nebulaResult.pc, d.nebulaResult.err);
};

function cpInitNebulaDistanceDialog(dock, list) {
   var self = this, i;
   this.windowTitle = optT("Distance of the nebula");
   this.nebulaResult = null;
   this.dock = dock; this.list = list;
   cpStyleDialog(this);
   this.combo = new ComboBox(this);
   for (i = 0; i < list.length; ++i) this.combo.addItem(list[i].id + ((list[i].name !== list[i].id) ? " · " + list[i].name : ""));
   this.info = new Label(this);
   this.info.wordWrapping = true; this.info.useRichText = false;
   cpStyleHint(this.info);
   this.distLabel = new Label(this); this.distLabel.text = format(optT("Distance (%s):"), dock._words()[dock.unit]);
   this.distEdit = new Edit(this);
   this.errLabel = new Label(this); this.errLabel.text = format(optT("Error, ± (%s):"), dock._words()[dock.unit]);
   this.errEdit = new Edit(this);
   this.combo.onItemSelected = function() { self.refresh(); };
   this.okButton = new PushButton(this); this.okButton.text = optT("Use"); this.okButton.defaultButton = true;
   cpStylePrimaryButton(this.okButton);
   this.okButton.onClick = function() { self.acceptDistance(); };
   this.clearButton = new PushButton(this); this.clearButton.text = optT("Remove mine");
   this.clearButton.onClick = function() { self.nebulaResult = { id: self.list[self.combo.currentItem].id, pc: 0, err: 0 }; self.done(1); };
   this.cancelButton = new PushButton(this); this.cancelButton.text = optT("Cancel");
   this.cancelButton.onClick = function() { self.nebulaResult = null; self.done(0); };
   var grid = new HorizontalSizer; cpGap(grid, 6);
   grid.add(this.distLabel); grid.add(this.distEdit); grid.add(this.errLabel); grid.add(this.errEdit);
   var buttons = new HorizontalSizer; cpGap(buttons, 6);
   buttons.add(this.clearButton); buttons.addStretch(); buttons.add(this.okButton); buttons.add(this.cancelButton);
   this.sizer = new VerticalSizer;
   cpMargin(this.sizer, 10); cpGap(this.sizer, 8);
   this.sizer.add(this.combo); this.sizer.add(this.info); this.sizer.add(grid); this.sizer.add(buttons);
   this.setMinWidth(cpDp(420));
   this.refresh();
   this.adjustToContents();
}
class CPNebulaDistanceDialog extends Dialog {
   constructor(dock, list) { super(); cpInitNebulaDistanceDialog.call(this, dock, list); }
}
// (Ni `ok` ni `cancel`: bajo #engine v8 los tapa el nativo. Ver CPRenameDialog en ui/main_dialog.js.)
CPNebulaDistanceDialog.prototype.refresh = function() {
   var nb = this.list[Math.max(0, this.combo.currentItem)], dk = this.dock, k = cpSfDistanceIn(1, dk.unit), man = null, auto = null;
   for (var i = 0; nb && i < nb.candidates.length; ++i) {
      var c = nb.candidates[i];
      if (c.source === "manual") man = c.dist; else if (auto === null && c.why !== "poor") auto = c.dist;
   }
   this.info.text = (auto !== null) ? format(optT("Found: %s %s, from %s. What you enter here is used instead, and it is saved with the image."), dk._dist(auto.pc), dk._nebulaErrText(auto), dk._nebulaSourceText(auto, false))
                                    : optT("No catalogue gives a distance for this nebula: enter it here to place it (it is saved with the image).");
   this.distEdit.text = man ? String(Math.round(man.pc * k)) : "";
   this.errEdit.text = (man && man.hi > man.pc) ? String(Math.round((man.hi - man.pc) * k)) : "";
};
CPNebulaDistanceDialog.prototype.acceptDistance = function() {
   var k = cpSfDistanceIn(1, this.dock.unit), v = Number(String(this.distEdit.text).replace(",", ".").replace(/\s+/g, "")), e = Number(String(this.errEdit.text).replace(",", ".").replace(/\s+/g, ""));
   if (!(v > 0) || !isFinite(v)) return;
   this.nebulaResult = { id: this.list[Math.max(0, this.combo.currentItem)].id, pc: v / k, err: (e > 0 && isFinite(e)) ? e / k : 0 };
   this.done(1);
};
