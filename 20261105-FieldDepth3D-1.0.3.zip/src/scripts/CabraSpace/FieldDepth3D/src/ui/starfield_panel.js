// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_panel.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_panel.js — «Distances»: el panel JUNTO a la foto (Cabra3D: sin el diagrama HR, que vive en CabraStars)
// ----------------------------------------------------------------------------
// Fase 2 y 3 (13-oct-2026). Decisiones de Nino (cerradas): dos entradas al final
// de ANNOTATIONS; un clic con la imagen resuelta y sin configurar nada; el
// resultado en un panel AL LADO del visor (no en una ventana suelta) para que el
// enlace punto <-> estrella funcione en los dos sentidos; Distances se abre en
// PERSPECTIVA y las otras dos (lateral logaritmica, lateral por tramos) son
// conmutadores en el mismo sitio; años luz Y parsecs, a elegir; la red, toda la que
// mejore, SIN BLOQUEAR: primero lo local y se pinta, lo de red llega despues.
//
// QUIEN HACE QUE:
//   · los DATOS: `engine/starfield_run.js` (`cpStarfieldBuild`, `…Refine`, `…DeepSky`);
//   · la GEOMETRIA (ejes, densidad, escalas, poses, placas): `ui/starfield_view.js`,
//     que es puro y se prueba en node (L0-94);
//   · AQUI: los botones, el lienzo y el raton.
//
// REGLA 4 DEL PROYECTO: en `onPaint` NO se calcula nada ni se ejecuta ningun
// proceso. El dibujo entero se hace en `_render` (al abrir, al cambiar algo, al
// mover el raton con un boton pulsado) sobre un bitmap; `onPaint` copia ese
// bitmap y pinta encima el anillo del punto bajo el cursor. Girar la vista de
// distancias es: proyectar (aritmetica), pintar en el bitmap, copiar.
//
// LA VISTA DE DISTANCIAS ES 3D DE VERDAD (13-oct-2026): una camara orbital libre
// con perspectiva (`cpSvDistCam`). Arrastrar gira (la vuelta entera), el boton
// derecho —o el central, o Mayus + arrastrar— desplaza, la rueda es un travelin
// hacia lo que hay bajo el cursor y el doble clic repone la vista. La foto se
// pinta troceada en una malla, cada celda con su afin (`_drawPhotoMesh`).
//
// LAS TRANSICIONES (13-oct-2026): al pasar de una vista a otra cada estrella
// viaja de su sitio en la de salida a su sitio en la de llegada (FOTO y 3D). Quien es quien y donde esta en cada fotograma lo calcula
// `ui/starfield_view.js`; aqui, un `Timer` periodico pinta cada fotograma en un
// bitmap y repinta (`_animTick` → `_animFrame`): `onPaint` sigue sin calcular.
// El primer fotograma ES el dibujo de salida y el ultimo ES el definitivo (se
// funden en capas: `cpSvAnimLayers`), asi que no hay salto al acabar. Cualquier
// pulsacion corta la transicion y deja el estado final (`_animStop`).
// MEDIDO (`_tests/cp_starfield_3d_probe.log`, 1.9.5 build 1706): la foto en una
// malla de 16 x 16, 1 ms y 0 pixeles de costura (con 1 px de solape y sin
// suavizar los bordes de las celdas); 20 000 puntos con `fillRect`, 5 ms; fundir
// dos bitmaps del lienzo con `opacity`, 2 ms; `g.transformation = Matrix` NO
// existe (no lanza y no hace nada): la afin se pone con translate + rotate( -θ )
// + shear + scale.
//
// MEDIDO (`_tests/cp_starfield_ui_probe.log`, 1.9.5 build 1706): el mapa de
// densidad de 20 000 puntos en un trazado de 900 x 700 son 34 ms (25 ms con 1 000:
// casi todo es fijo); 3 000 circulos suavizados, 4 ms; copiar el bitmap, menos de
// 1 ms. (`Graphics.opacity` y `fillPolygon( [Point…] )` FUNCIONAN bajo V8 en 1706
// —`cp_starfield_ui_probe2.log`; la primera sonda dijo que lanzaban y se equivocaba:
// metia tres sentencias en un `try`—. Aqui no hacen falta: la transparencia va en
// el color de cada pluma.) OJO: en PJSR una excepcion del nucleo es una CADENA, no
// un Error: `e.message` sale `undefined`; el texto es `String( e )`.
//
// LAS MEDIDAS salen de la escala de Atlas (`CP_ATLAS.space`, `CP_ATLAS.size`) y se
// multiplican por la escala de la pantalla al pintar: ni un pixel suelto.
// ES5. (Sin subclase de widget: el lienzo es un `Control` con sus manejadores.)
// ============================================================================

// Medidas en pixeles LOGICOS (el pintado las multiplica por la escala).
var CP_SFUI = {
   DOCK_W:     CP_ATLAS.space[9] * 4 + CP_ATLAS.space[6],   // ancho de fabrica del panel
   DOCK_MIN:   CP_ATLAS.space[8] * 4,
   DOCK_MAX:   CP_ATLAS.space[9] * 10,
   CANVAS_MIN: CP_ATLAS.space[8] * 3,                        // alto minimo del lienzo
   PAD:        CP_ATLAS.space[1],                            // margen del lienzo
   GAP:        CP_ATLAS.space[0],
   CARD_H:     CP_ATLAS.space[6] + CP_ATLAS.space[1],        // la ficha del objeto
   FOOT_H:     CP_ATLAS.space[3] + CP_ATLAS.space[1],        // el pie: UNA linea; lo largo, a su tooltip (tarea H4, 21-oct; antes dos lineas)
   HINT_H:     CP_ATLAS.space[3] + CP_ATLAS.space[1],        // lo que se reserva para «señala una estrella»: una linea (la ficha, al salir, va encima de la leyenda)
   ROW_H:      CP_ATLAS.space[3],                            // una fila de la leyenda
   RING:       CP_ATLAS.space[1],                            // radio del anillo de oro del enlace
   HIT:        CP_ATLAS.space[2],                            // a cuanto coge el raton un punto
   PHOTO_MAX:  CP_ATLAS.space[9] * 6,                        // lado mayor de la copia de la foto (en el estado FOTO de las transiciones llena el lienzo)
   FULL_MAX:   CP_ATLAS.space[9] * 12,                       // lado mayor de la copia de la que salen los RECORTES de los objetos extensos (la mejor que da el visor)
   CUT_MAX:    CP_ATLAS.space[9] * 2,                        // lado mayor del recorte de un objeto
   ZOOM_W:     CP_ATLAS.space[7] + CP_ATLAS.space[4]         // ancho de la barra de zoom
};

// LO QUE VA EN PIXELES DE IMAGEN O DE VIDEO (no de interfaz: por eso no sale de la escala de Atlas ni va en CP_SFUI)
var CP_SFUI_IMG = {
   IMAGE_MAX: 6144,                  // lado mayor de la foto a la resolucion de la imagen (mas: se reduce; 151 MB en el peor caso)
   PYR_MIN: 768,                     // la foto para un vuelo, a mitades hasta este lado
   CUT_HI: 2048,                     // lado mayor del recorte de un objeto para un video (vuelta 4: con 1 024 el de NGC 1560 —1 140 px de imagen— ya iba reducido)
   CUT_SMALL: 160, CUT_UP: 4,        // un recorte de menos de CUT_SMALL de lado se amplia (suave) hasta ahi, CUT_UP veces como mucho
   HOLE_CLUSTER: 0,                  // lo que se atenuan en la foto las estrellas de un cumulo cuyos miembros se pintan uno a uno (vuelta 4: nada; se leia como dos elipses)
   // MEDIDO en el fotograma nativo del despegue de NGC 1560 (mediana del hueco contra la de lo que lo rodea, canal verde, 72):
   // restandolo todo y sin el minimo, 68 (una lengua oscura); con el minimo y toda la referencia del borde, 88 (una lengua
   // clara); el minimo ya deja lo que hace falta y de la referencia basta una parte.
   // Con el minimo de 7 × 7 y un decimo de la referencia, 77 (aun claro); el minimo de 5 × 5 solo es lo que cuadra.
   EDGE_REF: 0, HOLE_MIN_R: 2,
   EDGE_FULL: 2,                     // …y se le resta ENTERA desde un tercio de transparencia (con la transparencia tal cual, el borde tenue del objeto se quedaba: un cerco claro)
   EDGE_LO: 0.02, EDGE_HI: 0.15,     // el borde de la mascara de un objeto: de donde sale el nivel hasta el que su hueco le resta luz a la foto
   GLINT_PX: 24,                     // un recorte cuyo objeto mide menos que esto (en pixeles de imagen) lleva ademas su destello en un video
   SHADE_LUM: 80                     // lo BRILLANTE del objeto tapa lo que tiene detras (los marcos de la caja): del todo desde este nivel de su luz. Nunca oscurece: su luz es siempre mas que lo que tapa
};
var CP_SFUI_FACTORY = { pose: "perspective", scale: "log", unit: "ly", yaw: CP_SV.YAW, pitch: CP_SV.PITCH };
var CP_SFUI_HTTP_TIMEOUT_S = 15;     // lo que se espera a cada servicio desde la interfaz (medido: SIMBAD 0,3-5 s, TAPVizieR 5-7 s)
// (22-oct-2026) EL AFINADO, CON LA CADENA COMPLETA DE CabraShared, como CabraStars: VizieR -> GAVO (Gaia EDR3 = la misma astrometria,
// Bailer-Jones) -> ESA con Bailer-Jones -> espejo de VizieR en CfA -> ESA sin union (CabraShared/CHANGELOG.md F2.3). Con VizieR bien,
// la MISMA consulta y el mismo resultado que antes; si cae, los mismos datos que CabraStars y no la ESA sin Bailer-Jones. "" = el camino
// de antes (VizieR y la ESA sin union: el control en rojo de tests/c3_net.js, C3_MUTATE=chain).
var CP_SFUI_REFINE_CHAIN = "full";
var CP_SFUI_KEEP = 2;                // cuantas imagenes se guardan calculadas
var CP_SFUI_LIGHT_DRAG = true;        // mientras se arrastra la vista de distancias, el dibujo va sin placas (se colocan al soltar)
// LA MALLA DE LA FOTO NO DEJA RENDIJAS: cada celda se mete en sus vecinas lo que su afin se equivoca con la cuarta
// esquina MAS estos pixeles de pantalla. (Con «1 pixel de la foto» fijo, que es lo que midio la sonda a zoom 1,
// de cerca y con la copia grande de la foto un pixel de foto son 1,6 de pantalla y el error 2: rayas negras entre
// celdas. Visto en la captura `…_foto_de_cerca_por_delante.png`.) 0 = sin solape (el control en rojo del test 4.3).
var CP_SFUI_MESH_SEAL = 1.5;
// …y ademas crece estos pixeles de la FOTO por los CUATRO lados: al ampliar un trozo de bitmap, `Graphics` deja su
// medio pixel de borde a medio pintar, y con la foto ampliada (una copia pequeña, o la camara cerca) eso era una
// trama fina de lineas oscuras entre celdas. Con un pixel de mas por cada lado, el borde a medias de cada celda cae
// sobre lo que la vecina ya pinto bien. 0 = sin crecer (el control en rojo del test 4.3).
var CP_SFUI_MESH_GROW = 1;
var CP_SFUI_PLATE_COVER = 60;        // una placa que taparia mas objetos que estos (o a otro destacado, que cuenta 1000) no se pone
var CP_SFUI_CUT_MATTE = true;        // el recorte es SOLO el objeto (transparencia por brillo sobre el fondo local); apagado: el disco de foto de antes
var CP_SFUI_CUTOUTS = true;          // los objetos extensos, con su recorte de la foto (apagado: solo su simbolo; el control de los tests y de la medida)
var CP_SFUI_IMAGE_RES = true;        // la foto grande sale de la IMAGEN con el estirado del visor (apagado: la copia del visor, como antes)
var CP_SFUI_CUT_FACE = true;         // el recorte mira a la camara (apagado: el plano paralelo a la foto de antes)
var CP_SFUI_SHADE_OFF_PHOTO = true;  // …pero NO mientras tiene la foto detras: ahi la sombra hacia del recorte un disco oscuro sobre el cielo de la foto
var CP_SFUI_CUT_SHADE = true;        // el nucleo del recorte tapa lo que tiene detras (apagado: solo suma luz; las lineas de la caja lo cruzan)
var CP_SFUI_HOLE_MULTIPLY = true;    // el hueco de un objeto se pinta MULTIPLICANDO (le resta su luz a la foto); apagado: se pinta encima, y es un parche claro (el control de las pruebas)
var CP_SFUI_CUT_HOLES = true;        // el objeto SALE de la foto: su hueco se apaga al abrirse la caja (apagado: se ve dos veces)
var CP_SFUI_TICK_S = 0.016;          // el tic de las transiciones, en SEGUNDOS (medido: un Timer periodico de 16 ms da 62 tics por segundo)
// MIENTRAS SE GIRA O SE ACERCA (Cabra3D, 20-oct-2026, tarea C): el dibujo pinta como mucho estas estrellas (las mas
// brillantes y los miembros de cumulo siempre; del resto, una muestra fija —la misma en cada fotograma, no chispea—). Al
// soltar (o 0,2 s despues de la ultima vuelta de la rueda) se pinta el dibujo ENTERO, el mismo de siempre. MEDIDO
// (`tests/c3_perf.js`, Pleyades, 25 700 objetos, lienzo 1982 x 1303): las estrellas eran ~80 % de cada fotograma de
// arrastre (72 ms de mediana: 14 fotogramas por segundo). 0 = sin limite (como antes: el control en rojo).
// Tope: la tarea C midio 6 000 (Pleyades 36/47 ms de mediana/p95); Nino, 20-oct: 12 000 (mas estrellas al girar).
var CP_SFUI_LOD_STARS = 12000;
// EL TOPE, ADAPTATIVO (decision C de Nino, 22-oct-2026): en vez de 12 000 fijas, las que quepan en ~33 ms por fotograma de
// arrastre. Se mide lo que tarda cada dibujo ligero (media movil de los ultimos, con el mismo tope) y el tope sube o baja en
// escalones de LOD_STEP (la mascara solo se rehace al cambiar de escalon), entre LOD_MIN y todas. La regla de que se pinta es
// la de siempre (`_lodOf`: miembros y las mas brillantes siempre, una muestra fija del resto). Lo aprendido se queda para el
// siguiente arrastre del mismo modelo. Un campo ligero lo pinta todo (el tope llega a «todas»: sin tope). Al soltar, el dibujo
// entero de siempre. CP_SFUI_LOD_STARS es el punto de partida. CP_SFUI_LOD_ADAPT = false: el tope fijo de antes (el control en rojo).
var CP_SFUI_LOD_ADAPT = true;
var CP_SFUI_LOD_TARGET_MS = 33;      // diseño (Nino): ~30 fotogramas por segundo
var CP_SFUI_LOD_MIN = 3000;          // diseño (Nino): nunca menos estrellas que estas al girar
var CP_SFUI_LOD_STEP = 250;          // diseño: el escalon del tope
var CP_SFUI_LOD_BAND = 0.12;         // diseño: dentro de ±12 % del objetivo no se toca (el ruido del reloj de un fotograma es ~2-4 ms)
// LO QUE LLEGA DE LA RED, SIN PARAR EL GIRO (22-oct-2026). MEDIDO (tests/c3_perf.js, Pleyades): al llegar la respuesta de VizieR, leerla
// y casarla con 90 000 estrellas paraba la interfaz 0,6-0,8 s (parseTable 65-131 ms, refineRows 122-213, refineApply 298-351); al llegar
// la RV, 0,4 s (rvMatch ~100 y la capa de anillos de la foto rehecha en onPaint, 290 ms). Ahora esos bucles atienden la interfaz cada 25 ms
// (`cshYield`, CabraShared/csh_net.js) y la capa de anillos se rehace al quedar quieto (ui/photo_stars_overlay.js `_ovIdle`).
// CP_SFUI_NET_DEFER = false (con CSH_YIELD_ON = false): como antes (el control en rojo (ii) de c3_perf, C3_PERF_DEFER=0).
var CP_SFUI_NET_DEFER = true;
// EL PRIMER FOTOGRAMA, ANTES (22-oct-2026). MEDIDO (c3_perf): leer el campo entero tardaba 12,5-15,6 s en las Pleyades (la solucion con
// spline de la imagen 5,6 s —AstrometricMetadata, nativo—, las 90 000 estrellas a pixel 1,4, cumulos 1,3-1,9, fotometria 1,5-2,5,
// profundidad 2,6-3,5) y 8,8 s en LDu 2 (profundidad 5,9). Ahora, al abrir: la geometria del campo UNA vez y las estrellas de G <= FIRST_G
// sin fotometria ni profundidad (el primer vistazo); el campo ENTERO se lee despues como un paso mas de la cola de la red («full»: antes
// que la red, porque la red se aplica sobre el), con la interfaz atendida (cshYield) y la barra de progreso; al acabar sustituye al
// primero. El resultado final es EL MISMO de antes (la misma llamada, con la misma geometria). Lo enciende Cabra3D fuera de las pruebas
// (Cabra3D.js); CabraStarAnalysis no (abre el panel con su resultado ya hecho). Apagado: todo de una vez, como antes.
var CP_SFUI_PROGRESSIVE = false;
var CP_SFUI_FIRST_G = 15;            // diseño: el primer vistazo (Pleyades: unas 3 000 estrellas)
var CP_SFUI_LOD_ANIM = true;       // …y en las transiciones de camara (abrir, reponer la vista): el ultimo tramo ya funde con el dibujo entero
var CP_SFUI_SETTLE_S = 0.2;          // la rueda: el dibujo entero, a los 0,2 s de la ultima vuelta
var CP_SFUI_REUSE_FRAME = true;      // el bitmap del dibujo se reutiliza (medido: crear + llenar + liberar uno de 1962 x 1303, 3-4 ms por fotograma)
var C3_RENDER_BREAK = "";             // (pruebas) "spare": el repuesto se reserva tarde, como antes del 24-oct (el rojo de tests/c3_render_reentry.js)

// LAS TRANSICIONES ANIMADAS (13-oct-2026). COSTURA PARA PRUEBAS: con `CP_SF_ANIM` apagado todo
// cambio de vista es instantaneo, como antes; en una pasada sin pantalla (CP_NO_MAIN) nace apagado,
// para que ninguna prueba dependa del reloj. `CP_SF_ANIM_CLOCK` es el reloj (milisegundos): una
// prueba lo sustituye para llevar una transicion fotograma a fotograma.
var CP_SF_ANIM = !CP_NO_MAIN;
var CP_SF_ANIM_CLOCK = function() { return Date.now(); };

// COSTURA PARA PRUEBAS: `CP_SF_EXPORT_HOOK( kind, suggested ) -> ruta | null` contesta
// EN VEZ del cuadro de «guardar como» (que en una pasada sin pantalla no vuelve).
var CP_SF_EXPORT_HOOK = null;

// La clave del estado de una imagen: lo que cambia cuando cambia su contenido y NO
// cambia al renombrarla (va por `uniqueId`; por eso no hace falta seguir al renombrado).
function cpSfUiKey(view) {
   try {
      var uid = String(view.uniqueId || "");
      if (uid.length === 0) uid = "id:" + view.id;
      return uid + ":" + view.image.width + "x" + view.image.height + ":c" + view.image.numberOfChannels + ":h" + cpHistoryIndex(view) +
             ":t" + cpViewContentToken(view.id) + "." + CP_CONTENT_EPOCH;
   } catch (e) { return ""; }
}

function cpSfUiLastDir() {
   try {
      var v = Settings.read(CP_SETTINGS_PREFIX + "/Starfield/lastDir", DataType_String);
      if (typeof v === "string" && v.length > 0 && File.directoryExists(v)) return v;
   } catch (e) {}
   return "";
}
function cpSfUiRememberDir(dir) {
   if (CP_NO_MAIN) return;        // las pruebas no tocan lo recordado de verdad
   try { Settings.write(CP_SETTINGS_PREFIX + "/Starfield/lastDir", DataType_String, String(dir)); } catch (e) {}
}

// Reparto en filas de unas piezas de ancho conocido. Devuelve { rows, at: [ { x, row } ] }.
function cpSfUiFlow(widths, maxW, gap) {
   var x = 0, row = 0, at = [];
   for (var i = 0; i < widths.length; ++i) {
      if (x > 0 && x + widths[i] > maxW) { x = 0; ++row; }
      at.push({ x: x, row: row });
      x += widths[i] + gap;
   }
   return { rows: (widths.length > 0) ? row + 1 : 0, at: at };
}

// (29-oct-2026, Nino) `_netBusy` es el interruptor de TODA espera de red del panel (el paso base, SIMBAD, la maquina del tiempo, los nombres,
// la velocidad radial…: cada uno lo pone a mano en su sitio). Como propiedad con efecto, el relojito de la foto (CabraShared/csh_busy.js) sigue
// a todos con UN solo punto, sin tocar cada paso ni la red. Sin el include, sigue siendo una propiedad normal.
Object.defineProperty(CPStarfieldDock.prototype, "_netBusy", {
   get: function() { return this._nbv === true; },
   set: function(v) { this._nbv = (v === true); this._busyNote(); },
   configurable: true, enumerable: false
});
CPStarfieldDock.prototype._busyNote = function() {
   var pv = this.dialog ? this.dialog.preview : null;
   if (pv && pv.viewport && typeof cshBusySet === "function") cshBusySet(pv.viewport, "net", this._nbv === true && this._closed !== true);
};
function CPStarfieldDock(dialog, parent) {
   var self = this;
   this.dialog = dialog;
   this.mode = "";                 // "" (cerrado) | "dist"   (Cabra3D: sin el HR, que vive en CabraStars)
   this.state = null;              // lo calculado de la imagen que se enseña
   this._kept = [];                // lo calculado de las ultimas imagenes (ver cpSfUiKey)
   this.pose = CP_SFUI_FACTORY.pose;
   this.scaleMode = CP_SFUI_FACTORY.scale;
   this.unit = CP_SFUI_FACTORY.unit;
   this.yaw = CP_SFUI_FACTORY.yaw;
   this.pitch = CP_SFUI_FACTORY.pitch;
   this.distZoom = 1; this.distOx = 0; this.distOy = 0; this.distOz = 0;   // la camara de distancias: el travelin y el pivote (cpSvDistView)
   this.sideZoom = 1; this.sideCentre = 0.5;                // el corte lateral: los aumentos y el centro de la ventana del fondo (cpSvSideWindow)
   this._zoomSyncing = false;
   this._edgeLow = -1; this._edgeHigh = -1;                 // la arista de la caja que lleva las cifras y la de las bandas (no bailan al girar)
   this._light = false;                                     // arrastrando: el dibujo sin placas
   this._lod = false;                                       // girando o acercando: ademas, con un tope de estrellas (CP_SFUI_LOD_STARS)
   this._spare = null;                                      // el bitmap del dibujo anterior, para el siguiente (CP_SFUI_REUSE_FRAME)
   this.anim = null;                                        // la transicion en marcha
   this._animPending = false;                               // hay una transicion a punto de arrancar (el dibujo hecho aun no se enseña)
   this.lastAnim = null;                                    // lo que hizo la ultima transicion (fotogramas, milisegundos): para medir
   this._animOpenAt = 0;                                    // el panel se abrio y el lienzo aun no tenia tamaño: cuando (reloj de las transiciones)
   this.hoverStar = -1;            // la estrella bajo el cursor (indice en result.stars)
   this.selStar = -1;              // la elegida con un clic (se queda)
   this.hoverObj = -1;             // en distancias: el objeto bajo el cursor (indice en el modelo)
   this.selObj = -1;
   this.frame = null;              // el dibujo, hecho
   this.lay = null;                // lo que _render dejo apuntado para el raton y los tests
   this._drag = null;
   this._netBusy = false;
   this._closed = false;
   this.said = { text: "", kind: "" };

   this.container = new Control(parent);
   cpApplyStyle(this.container, "background-color:transparent; border:none;");
   this.container.sizer = new VerticalSizer;
   cpGap(this.container.sizer, CP_SFUI.GAP);
   // LOS MANDOS, EN UNA CAJA PROPIA (14-oct-2026): las dos filas (la de la vista y la del vuelo) son hijas de `rowsBox`, que
   // va arriba del panel. A pantalla completa la MISMA caja se muda al panel de opciones superpuesto
   // (ui/starfield_fullscreen.js) y vuelve al salir: los mismos controles, el mismo estado, los mismos manejadores (cero
   // redundancia: no hay una copia de los mandos que pueda divergir).
   this.rowsBox = new Control(this.container);
   cpApplyStyle(this.rowsBox, "background-color:transparent; border:none;");
   this.rowsBox.sizer = new VerticalSizer;
   cpGap(this.rowsBox.sizer, CP_SFUI.GAP);

   function toggle(text, tipKey, onClick) {
      var b = new PushButton(self.rowsBox);
      b.text = text;
      b.toolTip = cpTooltip(tipKey);
      b.cpTipKey = tipKey;
      b.onClick = onClick;
      cpStyleToggle(b, false);
      return b;
   }
   // --- fila de mandos: lo de cada vista a la izquierda, lo comun a la derecha ---
   this.btnPersp = toggle(optT("Perspective"), "sf.pose.perspective", function() { self.setPose("perspective"); });
   this.btnSide = toggle(optT("Side"), "sf.pose.side", function() { self.setPose("side"); });
   this.btnLog = toggle(optT("Log"), "sf.scale.log", function() { self.setScale("log"); });
   this.btnSeg = toggle(optT("Segments"), "sf.scale.segments", function() { self.setScale("segments"); });
   this.btnLy = toggle(optT("ly"), "sf.unit", function() { self.setUnit("ly"); });
   this.btnPc = toggle(optT("pc"), "sf.unit", function() { self.setUnit("pc"); });
   // EL ZOOM, EN UNA BARRA (R24): el MISMO valor que mueve la rueda —el travelin en perspectiva, los aumentos del corte de
   // lado—; un solo zoom y dos maneras de moverlo, siempre de acuerdo (`_zoomSync`).
   this.zoomSlider = new HorizontalSlider(this.rowsBox);
   this.zoomSlider.minValue = 0; this.zoomSlider.maxValue = CP_SV.ZOOM_STEPS;
   try { this.zoomSlider.setFixedWidth(cpUiPx(CP_SFUI.ZOOM_W, this.zoomSlider)); } catch (eZw) {}
   this.zoomSlider.toolTip = cpTooltip("sf.zoom");
   this.zoomSlider.onValueUpdated = function(value) { if (!self._zoomSyncing) self.setZoomSlider(value); };
   // (con su rotulo: una barra sola no decia que era el zoom. Revision visual del 14-oct-2026.)
   this.zoomLabel = new Label(this.rowsBox);
   this.zoomLabel.text = optT("Zoom"); this.zoomLabel.toolTip = cpTooltip("sf.zoom");
   cpStyleHint(this.zoomLabel);
   // LA DISTANCIA DE LA NEBULOSA, A MANO (14-oct-2026; ui/starfield_nebula.js): solo en «Distances» y con alguna nebulosa en el campo
   this.btnNebula = toggle(optT("Nebula…"), "sf.nebula", function() { self.nebulaDistanceDialog(); });
   // LAS BARRAS DE INCERTIDUMBRE (21-oct, Nino: las lineas doradas largas de galaxias y cuasares, con desplazamientos al rojo
   // fotometricos de GLADE+ de ±20–50 %, se veian raras): un solo interruptor, ENCENDIDO de fabrica y recordado (prefs).
   this.errBars = true;
   this.btnErr = toggle(optT("± Uncertainty"), "c3.errbars", function() { self.errBarsToggle(); });
   // «TAMBIEN LO QUE NO SE VE EN TU FOTO» (24-oct-2026, decision D2 de Nino): el interruptor de `setShowUnseen`, en la 2.ª fila de capas
   // de 3D VIEW (ui/groups.js), APAGADO de fabrica y recordado en prefs como «± Uncertainty». Encendido, lo del catalogo que cae en el
   // encuadre con distancia y que la foto no enseña se pinta hueco, fuera del «mas lejano» y de la escala.
   this.showUnseen = false;
   this.btnUnseen = toggle(optT("Also what your photo doesn't show"), "c3.unseen", function() { self.setShowUnseen(!self.showUnseen); });
   this.btnToView = toggle(optT("To view"), "sf.export.view", function() { self.exportTo("view"); });
   this.btnToFile = toggle(optT("To file…"), "sf.export.file", function() { self.exportTo("file"); });

   // LA PANTALLA COMPLETA (14-oct-2026; ui/starfield_fullscreen.js): su boton va en la fila de arriba, junto a «To view»
   this._fsBuild();
   // (Cabra3D: las filas de los mandos las arma `_c3Layout` —ui/groups.js—, por clases: vista 3D, vuelo y video, maquina del tiempo)
   // LA FILA «Flight» (ui/starfield_flight_ui.js): volar por dentro de la caja y grabarlo. Solo en perspectiva.
   // LAS ESTRELLAS DE LA FOTO (14-oct-2026; ui/starfield_photostars.js): el desplegable «Stars», en la fila del vuelo
   this._starsBuild();
   this._flightBuild();
   this._tmBuild();                              // Cabra3D: LA MAQUINA DEL TIEMPO (tm/timemachine_ui.js), sus filas van en la misma caja
   this.container.sizer.add(this.rowsBox);

   // --- la señal de vida (lo local ya esta pintado; aqui se dice lo que llega de red) ---
   this.status = new Label(this.container);
   cpStyleStatusPill(this.status, "● " + optT("Ready"), "pending");
   cpFixHeightToText(this.status, "● Xg");
   this.container.sizer.add(this.status);

   // --- el lienzo -------------------------------------------------------------
   this.canvas = new Control(this.container);
   try { this.canvas.setMinHeight(cpUiPx(CP_SFUI.CANVAS_MIN, this.canvas)); } catch (eMin) {}
   try { this.canvas.mouseTracking = true; } catch (eMT) {}
   // (a pantalla completa el lienzo es otro —ui/starfield_fullscreen.js—: este, tapado, ni pinta —`_paint` lo mira— ni rehace el dibujo)
   this.canvas.onPaint = function(x0, y0, x1, y1) { if (cpQuiet()) return; self._paintGuarded(); };      // (27-oct, E7: la guarda, `_paintGuarded`)
   this.canvas.onResize = function(wNew, hNew, wOld, hOld) { if (cpQuiet()) return; if (self._canvasDocked && self.canvas !== self._canvasDocked) return; if (self.mode !== "" && !self._closed) self._render(); };
   this.canvas.onMousePress = function(x, y, button, buttons, modifiers) { self._onPress(x, y, button, modifiers); };
   this.canvas.onMouseMove = function(x, y, buttons, modifiers) { if (cpQuiet()) return; self._onMove(x, y, buttons); };
   this.canvas.onMouseRelease = function(x, y, button, buttons, modifiers) { self._onRelease(x, y, button); };
   this.canvas.onMouseDoubleClick = function(x, y, buttons, modifiers) { self.resetView(); };
   this.canvas.onMouseWheel = function(x, y, delta, buttons, modifiers) { self._onWheel(x, y, delta); };
   this.canvas.onLeave = function() { if (cpQuiet()) return; if (typeof self._c3LinkLeave === "function") self._c3LinkLeave(); self._setHover(-1, -1); };
   this.container.sizer.add(this.canvas, 100);
   // (el lienzo de siempre; a pantalla completa «this.canvas» es otro)
   this._canvasDocked = this.canvas;

   // LA RED, DESPUES: un solo disparo, que cada paso vuelve a armar si queda otro. No
   // lee ninguna imagen (trabaja sobre lo ya calculado). El intervalo va en SEGUNDOS.
   this.netTimer = new Timer;
   this.netTimer.interval = 0.05;
   this.netTimer.periodic = false;
   this.netTimer.onTimeout = function() {
      if (cpQuiet()) { self.netTimer.start(); return; }      // zona tranquila: se vuelve a armar y pregunta luego
      if (self.anim !== null) return;                        // una transicion en marcha: la red la arma ella al acabar
      self._netStepLive();
   };

   // LAS TRANSICIONES: un tic periodico. Cada tic proyecta (aritmetica), pinta el fotograma en un
   // bitmap y repinta el lienzo. No lee ninguna imagen ni ejecuta nada (trabaja con lo ya calculado).
   this.animTimer = new Timer;
   this.animTimer.interval = CP_SFUI_TICK_S;
   this.animTimer.periodic = true;
   this.animTimer.onTimeout = function() {
      if (cpQuiet()) return;                                 // zona tranquila: este tic no pinta (el siguiente pone el reloj al dia)
      self._animTick();
   };

   // LA RUEDA, AL PARAR: un solo disparo que vuelve al dibujo entero (cada vuelta de la rueda pinta el ligero y lo rearma)
   this.settleTimer = new Timer;
   this.settleTimer.interval = CP_SFUI_SETTLE_S;
   this.settleTimer.periodic = false;
   this.settleTimer.onTimeout = function() {
      if (self._closed || self._drag) return;               // (arrastrando: lo deja entero el soltar)
      if (cpQuiet()) { self.settleTimer.start(); return; }
      if (self._light || self._lod) { self._light = false; self._lod = false; if (self.mode !== "" && self.state !== null) self._render(); }
   };

   this.fitLabels();
   this._syncButtons();
   cpSetControlVisible(this.container, false);
}

CPStarfieldDock.prototype.fitLabels = function() {
   var all = [this.btnPersp, this.btnSide, this.btnLog, this.btnSeg,
              this.btnLy, this.btnPc, this.btnNebula, this.btnErr, this.btnUnseen, this.btnToView, this.btnToFile];
   for (var i = 0; i < all.length; ++i) cpMinWidthToText(all[i], CP_ATLAS.space[2]);
};

CPStarfieldDock.prototype.isOpen = function() { return this.mode !== ""; };

// «± Uncertainty»: las barras de la incertidumbre de la distancia, en la escena 3D, en los videos y en las exportaciones (todo sale de
// `_distBody` / `_drawDist`) y su entrada de la leyenda. Se recuerda entre sesiones (`prefsGet`). Devuelve el estado.
CPStarfieldDock.prototype.errBarsToggle = function(force) {
   this.errBars = (force === true || force === false) ? force : !(this.errBars !== false);
   cpStyleToggle(this.btnErr, this.errBars);
   if (this.mode !== "" && this.state !== null) this._render();
   try { this.dialog.preview.viewport.repaint(); } catch (e) {}
   return this.errBars;
};

// Los rotulos de las unidades, traducidos.
CPStarfieldDock.prototype._words = function() {
   return { ly: optT("ly"), mly: optT("M ly"), pc: optT("pc"), kpc: optT("kpc"), mpc: optT("Mpc"), gpc: optT("Gpc"), yr: optT("yr"), myr: optT("M yr") };
};
CPStarfieldDock.prototype._dist = function(pc) { return cpSvFormatDistance(pc, this.unit, this._words()).text; };

// `detail` (opcional): lo que no cabe en una linea corta y va al tooltip de la pildora.
CPStarfieldDock.prototype._say = function(text, kind, detail) {
   this.said = { text: String(text), kind: String(kind || "pending"), detail: String(detail || "") };
   var t = "● " + this.said.text;
   // una linea: lo que no cabe, al tooltip
   var w = 0;
   try { w = this.status.width - cpPx(CP_ATLAS.space[4], this.status); } catch (e) {}
   var shown = t;
   try { if (w > cpPx(CP_ATLAS.space[8], this.status)) shown = cpElide(this.status.font, t, w); } catch (e2) {}
   cpStyleStatusPill(this.status, shown, this.said.kind);
   var tip = (shown !== t) ? this.said.text : "";
   if (this.said.detail.length > 0) tip += (tip.length ? "<br><br>" : "") + this.said.detail;
   try { this.status.toolTip = tip.length ? cpWrapTooltip(tip) : ""; this.status.__cpTipBound = (tip.length > 0); } catch (e3) {}
};

// UNA IMAGEN DE BANDA ESTRECHA: lo dice el programa como siempre (`cpColorModeResolve`: lo elegido en COLOR, el historial
// o el nombre); no se mide ni se inventa aqui. Se mira al ABRIR. Lo usan las estrellas de la foto (ui/starfield_photostars.js).
CPStarfieldDock.prototype._narrowbandOf = function(view) {
   try {
      var m = cpColorModeResolve(view);
      return { yes: (m.mode === "nb-rgb"), palette: String(m.palette || "") };
   } catch (e) { return { yes: false, palette: "" }; }
};

// ---------------------------------------------------------------------------
// ABRIR. Un clic: si la imagen no esta resuelta (o no hay base Gaia) se dice y no
// se abre nada. Si ya se calculo y la imagen no ha cambiado, no se recalcula.
// Devuelve { ok, code, why }.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype.open = function(mode) {
   var want = "dist";                                        // (Cabra3D: la unica vista; el HR vive en CabraStars)
   var rec = this.dialog.currentRec;
   if (!rec || !optSafeView(rec.view)) return { ok: false, code: "no-view", why: cpStarfieldReasonText("no-view") };
   if (!cpHasAstrometricSolution(rec.view)) return { ok: false, code: "no-solution", why: cpStarfieldReasonText("no-solution") };
   if (this._netBusy && this.state && this.state.key !== cpSfUiKey(rec.view))
      return { ok: false, code: "busy", why: optT("still waiting for the online answer of the previous image: try again in a moment.") };
   var key = cpSfUiKey(rec.view), st = this._find(key);
   if (st === null) {
      var res = null, self = this;
      this.dialog.preview.setBusy(true, optT("Reading the Gaia stars of the field…"), false);
      try {
         // El proceso Gaia bombea eventos con el dialogo encendido: marcado como trabajo de
         // fondo, un «Apply» que entre mientras dura no ejecuta nada y lo dice (engine/inherited.js).
         res = cpBackgroundRun(function() { return (CP_SFUI_PROGRESSIVE === true) ? self._firstLook(rec.view) : cpStarfieldBuild(rec.view, {}); });
      } catch (e) {
         res = { ok: false, code: "gaia-failed", why: String(e.message || e) };
      } finally {
         this.dialog.preview.setBusy(false);
      }
      if (!res || !res.ok)
         return { ok: false, code: res ? res.code : "gaia-failed", why: res ? (res.why || cpStarfieldReasonText(res.code)) : "" };
      st = { key: key, viewId: rec.id, result: res, dist: null, photo: null, net: { refine: "", deepsky: "", nebula: "" }, title: "" };
      if (res._firstField) { st.partial = { field: res._firstField, view: rec.view }; st.net.full = ""; delete res._firstField; }
      st.photo = this._grabPhoto();
      st.photoFull = null;                                   // (la grande, de la IMAGEN: abajo, cada vez que se abre)
      st.cuts = {}; st.cutsHi = {};
      st.title = this._titleOf(st, rec);
      this._kept.unshift(st);
      while (this._kept.length > CP_SFUI_KEEP) { var old = this._kept.pop(); try { if (old.photo) old.photo.clear(); if (old.photoBack) old.photoBack.clear(); } catch (eO) {} this._freeCuts(old); }
   }
   st.narrowband = this._narrowbandOf(rec.view);      // (cada vez que se abre: el modo de color se puede elegir despues)
   // LA FOTO GRANDE, a la resolucion de la imagen y con el estirado del visor (`_renderFull`): solo la tiene la imagen que se enseña
   for (var kf = 0; kf < this._kept.length; ++kf) if (this._kept[kf] !== st) this._freeFull(this._kept[kf]);
   if (!st.photoFull) {
      this.dialog.preview.setBusy(true, optT("Preparing the photo…"), false);
      try { st.photoFull = this._renderFull(rec); } finally { this.dialog.preview.setBusy(false); }
   }
   // (las estrellas de la foto: se miden UNA vez por imagen y sus recortes salen de la foto grande, que se acaba de sacar)
   if (this.starsMode !== "gaia") this._psPrepare(st);
   // De donde sale la transicion: lo que el panel enseña AHORA (cerrado: la foto, con cada estrella en su sitio).
   var snap = this._animSnap();
   this.state = st;
   this._unseenApply(st);                                    // (H3: el interruptor vale para la imagen que entra, calculada con el otro estado o no)
   this.mode = want;
   this.hoverStar = -1; this.hoverObj = -1;
   cpSetControlVisible(this.container, true);
   try { this.dialog.onStarfieldDock(true); } catch (eD) {}
   this._syncButtons();
   this._render();
   this._sayState();
   this._netArm();
   this._animGo(snap);
   return { ok: true, code: "", why: "" };
};

CPStarfieldDock.prototype.close = function() {
   if (this.mode === "") return;
   // (a pantalla completa, «cerrar» es ir a la FOTO: el panel se queda, con la foto en el lienzo)
   if (this.fs && this.fs.on) { this._fsFotoRest(); return; }
   this.flightEnd();
   this._animDrop();
   this._animOpenAt = 0;
   this._freeFull(this.state);                               // (la foto grande: al volver a abrir se saca otra vez)
   this.mode = "";
   this.hoverStar = -1; this.hoverObj = -1;
   cpSetControlVisible(this.container, false);
   try { this.dialog.onStarfieldDock(false); } catch (e) {}
   try { this.dialog.preview.viewport.repaint(); } catch (e2) {}
};

// Al cerrar el dialogo: fuera el temporizador y los bitmaps.
CPStarfieldDock.prototype.cleanup = function() {
   if (this._cleaned) return;                    // Cabra3D: idempotente (el boton, el aspa y el final de c3Main)
   this._cleaned = true;
   if (this._c3Cleanup) this._c3Cleanup();      // Cabra3D: el cielo desde otra estrella, el polvo
   this._fsCleanup();
   this._flightCleanup();
   if (this._tmCleanup) this._tmCleanup();       // Cabra3D
   cpSfUiFree(this._layer); this._layer = null;
   this._closed = true;
   this._busyNote();                              // (29-oct-2026: el relojito de la foto fuera, con la red a medias o no)
   this._animDrop();
   try { this.animTimer.stop(); } catch (eA) {}
   try { this.netTimer.stop(); } catch (e) {}
   try { this.settleTimer.stop(); } catch (eSt) {}
   try { if (this._ovTimer) this._ovTimer.stop(); } catch (eOv) {}      // (Cabra3D, 22-oct: la capa de anillos al quedar quieto)
   try { if (this._idleTimer) this._idleTimer.stop(); } catch (eId) {}  // (y el trabajo en reposo)
   try { if (this.frame) this.frame.clear(); } catch (e1) {}
   this.frame = null;
   cpSfUiFree(this._spare); this._spare = null;
   for (var i = 0; i < this._kept.length; ++i) { try { if (this._kept[i].photo) this._kept[i].photo.clear(); if (this._kept[i].photoBack) this._kept[i].photoBack.clear(); } catch (e2) {} this._freeCuts(this._kept[i]); }
   this._kept = [];
   this.state = null;
};

CPStarfieldDock.prototype._find = function(key) {
   if (key === "") return null;
   for (var i = 0; i < this._kept.length; ++i) if (this._kept[i].key === key) return this._kept[i];
   return null;
};

// La imagen del visor ha cambiado. Si la nueva ya esta calculada se enseña; si
// no, el panel lo dice (calcularla es un clic: ejecuta un proceso, y no se lanza solo).
CPStarfieldDock.prototype.onImageChanged = function() {
   if (this.mode === "" || this._closed) return;
   this.flightEnd();
   this._animStop();
   if (this.mode === "") return;                             // (la transicion que se corta era la de cerrar)
   var rec = this.dialog.currentRec, st = (rec && optSafeView(rec.view)) ? this._find(cpSfUiKey(rec.view)) : null;
   if (st !== null && st === this.state) return;
   this.hoverStar = -1; this.hoverObj = -1; this.selStar = -1; this.selObj = -1;
   if (st !== null) st.narrowband = this._narrowbandOf(rec.view);
   this.state = st;
   if (st !== null) this._unseenApply(st);                   // (H3: el interruptor vale para la imagen que entra)
   this._syncButtons();
   this._render();
   if (st !== null) { this._sayState(); this._netArm(); }
   else this._say(optT("This image has not been read yet: press «Show in 3D».") /* Cabra3D: sin ANNOTATIONS ni HR */, "pending");
};

// Una imagen ha cambiado de nombre. Lo calculado va por `uniqueId` y no se pierde; lo unico
// que lleva el nombre es el titulo de un campo sin cumulo.
CPStarfieldDock.prototype.onRenamed = function(oldId, newId) {
   var hit = false;
   for (var i = 0; i < this._kept.length; ++i) {
      var st = this._kept[i];
      if (st.viewId !== oldId) continue;
      st.viewId = newId;
      if (st.title === String(oldId)) { st.title = String(newId); hit = true; }
   }
   if (hit && this.mode !== "") this._render();
};

// Una copia pequeña de lo que enseña el visor, para la boca del tunel.
CPStarfieldDock.prototype._grabPhoto = function(maxSide) {
   try {
      var pv = this.dialog.preview, src = pv.bitmap;
      if (!src || pv.grid || src.width < 2 || src.height < 2) return null;
      var big = cpPx(maxSide || CP_SFUI.PHOTO_MAX, this.canvas), k = Math.min(1, big / Math.max(src.width, src.height));
      var w = Math.max(2, Math.round(src.width * k)), h = Math.max(2, Math.round(src.height * k));
      var out = new Bitmap(w, h), g = new Graphics(out);
      try { g.smoothInterpolation = true; g.drawScaledBitmap(new Rect(0, 0, w, h), src); } finally { g.end(); }
      return out;
   } catch (e) { return null; }
};

// El titulo: el cumulo del campo si es de verdad el protagonista (cien miembros, o la
// quinta parte de las estrellas con distancia); si no, el nombre de la imagen. (Una
// nebulosa con un grupo de 26 estrellas dentro no se titula con el nombre del grupo.)
CPStarfieldDock.prototype._titleOf = function(st, rec) {
   var cl = st.result.clusters, d = st.result.distances || {}, withDist = (d.cluster || 0) + (d.parallaxLocal || 0) + (d.bailerJones || 0) + (d.parallaxOnline || 0);
   st.titleIsId = false;
   for (var i = 0; i < cl.length; ++i)
      if (cl[i].inFrame && cl[i].name && (cl[i].n >= 100 || cl[i].n >= 0.2 * withDist)) return String(cl[i].name);
   st.titleIsId = true;
   var name = String(rec.id);
   try { if (typeof cpPvDisplayText === "function") name = cpPvDisplayText(name); } catch (e) {}
   return name;
};

// (1-nov-2026, D9 del video de formacion) EL TITULO QUE SE VE: el nombre del objeto si existe. `st.title` es el cumulo del campo si lo hay y, si no, el ID de la
// vista («M82», «Collinder34»: sin el espacio de su nombre). Cuando es el ID, la cabecera enseña el nombre del PROTAGONISTA del campo si SIMBAD le da uno (el mismo
// que el titulo del video, `_flightTitle`: «M 82», «Collinder 34»); sin protagonista con nombre, el ID de siempre: no se inventa. `st.title` (nombres de fichero,
// renombrado de la vista) no cambia. Costura del rojo: C3_HEAD_OBJNAME = false (como antes).
var C3_HEAD_OBJNAME = true;
CPStarfieldDock.prototype._headTitle = function() {
   var st = this.state;
   if (!st) return "";
   if (C3_HEAD_OBJNAME !== false && st.titleIsId === true) {
      try {
         // 1 · un objeto del campo que SE LLAMA como la vista salvo los espacios y el tipo que SIMBAD antepone («Collinder34» = «Cl Collinder 34»; «M82» = «M 82»)
         var compact = function(x) { return String(x).toLowerCase().replace(/[^a-z0-9]+/g, ""); }, cid = compact(st.title), objs = this._distModel().objects, i;
         if (cid.length >= 3)
            for (i = 0; i < objs.length; ++i) {
               if (objs[i].kind === "star" || objs[i].kind === "member" || String(objs[i].name).length === 0) continue;
               var nm = cpSfUiShowName(objs[i].name).replace(/^(Cl\*?|OCl|GCl)\s+/, "");
               if (compact(nm) === cid) return nm;
            }
         // 2 · si no, el protagonista del campo con nombre (el mismo que el titulo del video)
         var t = cpSfUiShowName(this._flightTitle()); if (t.length > 0) return t;
      } catch (e) {}
   }
   return String(st.title);
};

// ---------------------------------------------------------------------------
// LOS MANDOS
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._syncButtons = function() {
   var dist = (this.mode === "dist"), st = this.state;
   cpSetControlVisible(this.btnPersp, dist); cpSetControlVisible(this.btnSide, dist);
   cpSetControlVisible(this.btnLog, dist); cpSetControlVisible(this.btnSeg, dist);
   cpSetControlVisible(this.zoomSlider, dist); cpSetControlVisible(this.zoomLabel, dist);
   cpSetControlVisible(this.btnNebula, dist && !!(st && st.result.nebulae && st.result.nebulae.objects && st.result.nebulae.objects.length > 0));
   cpStyleToggle(this.btnNebula, false);
   cpSetControlVisible(this.btnErr, dist && st !== null); cpStyleToggle(this.btnErr, this.errBars !== false);
   cpSetControlVisible(this.btnUnseen, dist && st !== null); cpStyleToggle(this.btnUnseen, this.showUnseen === true);
   try { this.zoomSlider.enabled = (st !== null); } catch (eZ) {}
   this._zoomSync();
   cpStyleToggle(this.btnPersp, this.pose === "perspective"); cpStyleToggle(this.btnSide, this.pose === "side");
   cpStyleToggle(this.btnLog, this.scaleMode === "log"); cpStyleToggle(this.btnSeg, this.scaleMode === "segments");
   cpStyleToggle(this.btnLy, this.unit === "ly"); cpStyleToggle(this.btnPc, this.unit === "pc");
   cpStyleToggle(this.btnToView, false); cpStyleToggle(this.btnToFile, false);
   try { this.btnToView.enabled = (st !== null); this.btnToFile.enabled = (st !== null); } catch (e2) {}
   this.fitLabels();
   this._flightSync();
   this._starsSync();
   if (this._tmSync) this._tmSync();             // Cabra3D: la maquina del tiempo
   cpSetControlVisible(this.btnFull, dist && st !== null && !this.isFullScreen());
   cpStyleToggle(this.btnFull, false);
   this._fsSync();
   if (this.isFullScreen()) this._fsOptShow();
};

CPStarfieldDock.prototype.setPose = function(p) {
   var v = (p === "side") ? "side" : "perspective";
   if (v === this.pose) return;
   var snap = this._animSnap();
   this.pose = v;
   this._syncButtons(); this._render();
   this._animGo(snap);
};
CPStarfieldDock.prototype.setScale = function(s) {
   var v = (s === "segments") ? "segments" : "log";
   if (v === this.scaleMode) return;
   var snap = this._animSnap();
   this.scaleMode = v;
   this._syncButtons(); this._render();
   this._animGo(snap);
};
CPStarfieldDock.prototype.setUnit = function(u) {
   var v = (u === "pc") ? "pc" : "ly";
   if (v === this.unit) return;
   this._animStop();
   this.unit = v;
   this._syncButtons(); this._render(); this._sayState();
};
// Reponer la vista (el doble clic): con transicion, la camara vuelve sola a la pose de fabrica.
CPStarfieldDock.prototype.resetView = function() {
   var snap = this._animSnap();
   if (this.mode === "dist") { this.distZoom = 1; this.distOx = 0; this.distOy = 0; this.distOz = 0; this.yaw = CP_SFUI_FACTORY.yaw; this.pitch = CP_SFUI_FACTORY.pitch; this.sideZoom = 1; this.sideCentre = 0.5; }
   this._render();
   this._animGo(snap, { ms: CP_SV.ANIM_SHORT_MS });
};

// ---------------------------------------------------------------------------
// LO QUE SE RECUERDA de una sesion a otra (viaja con lo de ANNOTATIONS, que es
// donde estan sus dos botones): la pose y la escala de
// Distances, la unidad y el giro. El zoom y lo elegido son de la sesion.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype.prefsGet = function() {
   var auto = (this.yaw === this._autoYaw && this.pitch === this._autoPitch);      // (la pose que puso el encuadre automatico no se recuerda: es de fabrica)
   return { pose: this.pose, scale: this.scaleMode, unit: this.unit, yaw: Math.round(auto ? CP_SFUI_FACTORY.yaw : this.yaw), pitch: Math.round(auto ? CP_SFUI_FACTORY.pitch : this.pitch), errBars: this.errBars !== false, showUnseen: this.showUnseen === true };
};
CPStarfieldDock.prototype.prefsSet = function(p, f) {
   var q = cpPrefsObject(p), d = cpPrefsObject(f);
   this.pose = cpPrefsChoice(q.pose, ["perspective", "side"], d.pose || CP_SFUI_FACTORY.pose);
   this.scaleMode = cpPrefsChoice(q.scale, ["log", "segments"], d.scale || CP_SFUI_FACTORY.scale);
   this.unit = cpPrefsChoice(q.unit, ["ly", "pc"], d.unit || CP_SFUI_FACTORY.unit);
   this.errBars = (typeof q.errBars === "boolean") ? q.errBars : (d.errBars !== false);   // (Cabra3D: ± Uncertainty, encendido de fabrica)
   // («Also what your photo doesn't show»: apagado de fabrica; si estaba encendido se vuelve a encender. El modelo se rehace aqui y el
   // render de abajo ya lo lleva; con la red aun por llegar, la bandera global basta: `cshDepthApply`/deepsky lo aplican al llegar)
   this.showUnseen = (q.showUnseen === true);
   this._unseenApply();
   // (el giro da la vuelta entera: de 0 a 360; la inclinacion, hasta el tope de la camara)
   this.yaw = cpPrefsNum(q.yaw, 0, 360, isFinite(d.yaw) ? d.yaw : CP_SFUI_FACTORY.yaw);
   this.pitch = cpPrefsNum(q.pitch, -CP_SV.PITCH_MAX, CP_SV.PITCH_MAX, isFinite(d.pitch) ? d.pitch : CP_SFUI_FACTORY.pitch);
   this._animStop();
   this._syncButtons();
   if (this.mode !== "") this._render();
};

// ---------------------------------------------------------------------------
// LA RED, SIN BLOQUEAR. Lo local ya esta pintado; cada paso pide una cosa, da
// señal de vida mientras espera (el motor avisa cada medio segundo) y, al llegar,
// se rehace el dibujo. Si falla, lo local sigue valiendo y se dice.
//   Afinar (error real, RUWE, Bailer-Jones) y lo lejano (SIMBAD).
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._netPending = function() {
   var st = this.state;
   if (!st || this.mode === "") return "";
   if (st.partial) return "full";                           // (el campo entero, antes que la red: ver CP_SFUI_PROGRESSIVE)
   if (this.mode === "dist" && st.net.deepsky === "") return "deepsky";
   if (st.net.refine === "") return "refine";
   return "";
};
// (Con una transicion en marcha NO se arma: una consulta de red tiene la interfaz parada a tramos de
// medio segundo y la transicion iria a saltos. La arma la propia transicion al acabar: `_animEnd`.)
CPStarfieldDock.prototype._netArm = function() {
   if (this._closed || this._netBusy || this.anim !== null || this._netPending() === "") return;
   try { this.netTimer.start(); } catch (e) {}
};
// Un paso. Devuelve lo que ha pedido ("" si no habia nada).
CPStarfieldDock.prototype._netStep = function() {
   if (this._closed || this._netBusy) return "";
   this._animStop();
   var step = this._netPending(), st = this.state, self = this;
   if (step === "") return "";
   if (step === "full") return this._fullStep(st);
   this._netBusy = true;
   st.net[step] = "running";
   var label = (step === "deepsky") ? optT("Asking SIMBAD for galaxies and quasars…") : optT("Asking VizieR for the real parallax errors…");
   this._say(label, "info");
   var out = null;
   try {
      var opts = { httpTimeoutS: CP_SFUI_HTTP_TIMEOUT_S, onProgress: function(stage, info) {
         if (self._closed || cpQuiet()) return;
         // (con la cadena, a quien se pregunta si no es VizieR: «… · GAVO (Heidelberg, Gaia EDR3) 3 s»)
         var who = (info && info.server && !/^VizieR \(CDS\)$/.test(String(info.server))) ? " · " + info.server : "";
         self._say(((stage === "nebulae") ? optT("Asking SIMBAD for the nebulae of the field…") : label) + who + " " + Math.round(((info && info.elapsedMs) || 0) / 1000) + " s", "info");
         try { optProcessEvents(); } catch (eP) {}
      } };
      if (step === "refine" && CP_SFUI_REFINE_CHAIN === "full") opts.chain = "full";
      out = (step === "deepsky") ? cpStarfieldDeepSky(st.result, opts) : cpStarfieldRefine(st.result, opts);
      // LAS NEBULOSAS DEL CAMPO (14-oct-2026): en el mismo paso que lo lejano, detras de el; si SIMBAD no contesta, valen los
      // catalogos empaquetados (ui/starfield_nebula.js). Su estado va aparte: no es un paso mas de la red.
      if (step === "deepsky") st.net.nebula = this._nebulaRun(st, opts);
   } catch (e) {
      out = { ok: false, code: "no-network", why: String(e.message || e) };
   } finally {
      this._netBusy = false;
   }
   st.net[step] = (out && out.ok) ? "ok" : ("failed:" + ((out && out.code) || "no-network"));
   if (this._closed) return step;
   // lo que dependia de las distancias se rehace
   st.dist = null;
   // (las estrellas de la foto se vuelven a medir: con la red llegan estrellas nuevas —Bailer-Jones— y los objetos extensos)
   if (st.ps) { st.ps.meas = null; if (this.state === st && this.mode === "dist" && this.starsMode !== "gaia") this._psPrepare(st); }
   // (el boton «Nebula…» depende de lo que ha llegado: si hay nebulosas en el campo)
   if (this.state === st && this.mode !== "") { this._syncButtons(); this._render(); this._sayState(); }
   this._netArm();
   return step;
};
// EL PASO DE RED DEL TEMPORIZADOR, SIN PARAR EL RATON (Cabra3D, 20-oct-2026, tarea C). MEDIDO (`tests/c3_perf.js`, commit
// 3fd77ac): mientras esperaba a SIMBAD/VizieR la espera de curl (CabraShared/csh_net.js) solo atendia la interfaz cada
// 500 ms (en el aviso de progreso), asi que girar el 3D en los primeros 10-15 s iba a saltos de medio segundo (hueco entre
// fotogramas p95 540 ms en NGC 1560) hasta que acababa la red. Ahora, durante el paso, `CSH_NET_PUMP` atiende la interfaz
// en cada vuelta corta de la espera (15 ms) y, si el panel o el script se cierran, corta curl. Lo que la interfaz puede
// hacer mientras tanto es lo mismo que ya podia en cada aviso de medio segundo (solo mas a menudo): no abre otra clase de
// reentrada. `runNetworkNow` (las pruebas) sigue sin bombear. CP_SFUI_NET_PUMP = false: como antes (el control en rojo).
var CP_SFUI_NET_PUMP = true;
CPStarfieldDock.prototype._netStepLive = function() {
   var self = this, was = (typeof CSH_NET_PUMP !== "undefined") ? CSH_NET_PUMP : null, mine = false;
   this._liveNet = true;                                    // (22-oct: el panel esta en vivo: lo pesado puede esperar al reposo —`_idleArm`—)
   if (CP_SFUI_NET_PUMP === true && typeof CSH_NET_PUMP !== "undefined" && was === null) {
      CSH_NET_PUMP = function() { optProcessEvents(); return self._closed === true || (typeof C3_CLOSING !== "undefined" && C3_CLOSING === true); };
      mine = true;
   }
   try { return this._netStep(); }
   finally { if (mine) CSH_NET_PUMP = was; }
};
// EL PRIMER VISTAZO (CP_SFUI_PROGRESSIVE): la geometria del campo y las estrellas de G <= FIRST_G, sin fotometria ni profundidad. Lleva
// la geometria en `_firstField` para el campo entero (no se vuelve a leer la solucion: 5,6 s con spline). Si no sale (o salen menos de 50
// estrellas: no merece un segundo paso), el campo entero ahora, como siempre.
CPStarfieldDock.prototype._firstLook = function(view) {
   var field = cpSfField(view);
   if (!field.ok) return cpStarfieldBuild(view, {});
   var first = null;
   try { first = cpSfBuildField(field, view, { magLimit: CP_SFUI_FIRST_G, photometry: false, depth: false }); } catch (e) { first = null; }
   if (!first || !first.ok || first.stars.length < 50) return cpSfBuildField(field, view, {});
   first._firstField = field;
   first.firstLook = { gMax: CP_SFUI_FIRST_G };
   return first;
};
// EL CAMPO ENTERO, como paso de la cola (con la interfaz atendida: `_netStepLive` pone CSH_NET_PUMP y los bucles largos lo llaman). La
// misma llamada que hacia `open` (cpStarfieldBuild = cpSfField + cpSfBuildField(campo, vista, {})) con la geometria ya leida. Al acabar
// sustituye al primer vistazo: lo que dependia de el se rehace (modelo, medidas de la foto, recortes, la eleccion).
CPStarfieldDock.prototype._fullStep = function(st) {
   var self = this, P = st.partial, out = null, pv = this.dialog.preview, label = optT("Reading all the Gaia stars of the field…");
   var stages = { gaia: optT("Gaia"), clusters: optT("clusters"), photometry: optT("photometry"), depth: optT("depth of the photo") };
   this._netBusy = true;
   st.net.full = "running";
   this._say(label, "info");
   try { pv.setBusy(true, label, false); } catch (eB) {}
   try {
      if (!P || !P.view || !optSafeView(P.view)) throw new Error("the image is no longer open");
      out = cpBackgroundRun(function() {
         return cpSfBuildField(P.field, P.view, { onProgress: function(stage) {
            if (self._closed) return;
            try { pv.setBusy(true, label + " " + (stages[stage] || ""), false); } catch (eP) {}
         } });
      });
   } catch (e) {
      out = { ok: false, code: "gaia-failed", why: String(e.message || e) };
   } finally {
      this._netBusy = false;
      try { pv.setBusy(false); } catch (eB2) {}
   }
   st.partial = null;
   st.net.full = (out && out.ok) ? "ok" : ("failed:" + ((out && out.code) || "gaia-failed"));
   if (this._closed) return "full";
   if (out && out.ok) {
      st.result = out;
      st.dist = null; st.tmd = null;
      // (los recortes y las medidas de la foto iban por los indices del primer vistazo; la foto grande y la sin estrellas se quedan)
      var sets = [st.cuts || {}, st.cutsHi || {}];
      for (var s2 = 0; s2 < sets.length; ++s2) for (var kc in sets[s2]) if (Object.prototype.hasOwnProperty.call(sets[s2], kc)) { var cc = sets[s2][kc]; cpSfUiFree(cc.front); cpSfUiFree(cc.hole); cpSfUiFree(cc.shade); }
      st.cuts = {}; st.cutsHi = {};
      try { this._psFree(st); } catch (ePs) {}
      if (st.ps) st.ps.meas = null;
      try { var rec = this.dialog.findRecById ? this.dialog.findRecById(st.viewId) : null; if (rec) st.title = this._titleOf(st, rec); } catch (eT) {}
      if (this.state === st) { this.hoverStar = -1; this.hoverObj = -1; this.selStar = -1; this.selObj = -1; this._card = null; }
      if (this.state === st && this.mode === "dist" && this.starsMode !== "gaia") this._psPrepare(st);
   }
   // (si no salio, se queda el primer vistazo y la red sigue sobre el: se dice en la linea de estado)
   if (this.state === st && this.mode !== "") { this._syncButtons(); this._render(); this._sayState(); try { pv.viewport.repaint(); } catch (eR) {} }
   this._netArm();
   return "full";
};
// LO PESADO QUE NO ES RED, CON EL RATON QUIETO (22-oct-2026). MEDIDO (c3_perf, LDu 2): la capa de la nebulosa —StarXTerminator 2,6-3,5 s
// (un proceso: no se puede trocear) y su mascara propia 0,9-1,0 s— iba DENTRO del paso de red de lo lejano: si se giraba en ese momento,
// huecos de 1,1 s; y los recortes de las galaxias recien llegadas se hacian en el primer dibujo ligero (216 ms en NGC 1560). Ahora, en
// el panel en vivo (`_netStepLive`): la capa de la nebulosa se prepara como «trabajo en reposo» —cuando el raton lleva IDLE_MS quieto y
// no hay red en marcha— y, girando, los recortes que faltan no se hacen (va su simbolo; el dibujo entero al soltar los hace).
// Con CP_SFUI_NET_DEFER apagado, o desde `runNetworkNow` (las pruebas), como antes.
var CP_SFUI_IDLE_MS = 400;
CPStarfieldDock.prototype._userBusy = function() {
   return !!(this._drag && this._drag.moved) || this._light === true || this.anim !== null || this._animPending === true || (Date.now() - (this._lastInput || 0) < CP_SFUI_IDLE_MS);
};
CPStarfieldDock.prototype._idleArm = function() {
   var self = this;
   if (!this._idleTimer) {
      this._idleTimer = new Timer; this._idleTimer.interval = CP_SFUI_IDLE_MS / 1000; this._idleTimer.periodic = false;
      this._idleTimer.onTimeout = function() {
         if (self._closed || self.mode === "" || !self.state) return;
         if (cpQuiet() || self._userBusy() || self._netBusy) { try { self._idleTimer.start(); } catch (e) {} return; }
         self._idleRun();
      };
   }
   try { this._idleTimer.stop(); this._idleTimer.start(); } catch (e2) {}
};
CPStarfieldDock.prototype._idleRun = function() {
   var st = this.state;
   if (st && st.nebPrep === true) {
      st.nebPrep = false;
      this._nebPrepNow = true;
      try { this._nebulaStarless(st); this._nebulaPrepare(st); } catch (e) { try { console.warningln("Cabra3D nebula layer: " + e); } catch (eW) {} }
      finally { this._nebPrepNow = false; }
      if (this.state === st && this.mode !== "" && !this._closed) { this._render(); this._sayState(); }
   }
};
// ¿Se deja para luego un recorte que falta? (girando, en el panel en vivo)
CPStarfieldDock.prototype._cutLater = function(st) {
   return (CP_SFUI_NET_DEFER === true && this._light === true && this._liveNet === true);
};
// Para los tests y para quien quiera todo de una vez: los pasos que queden, ahora.
CPStarfieldDock.prototype.runNetworkNow = function() {
   var done = [], s;
   for (var i = 0; i < 6 && (s = this._netStep()) !== ""; ++i) done.push(s);
   try { this.netTimer.stop(); } catch (e) {}
   return done;
};

// EL INTERRUPTOR «TAMBIEN LO QUE NO SE VE EN TU FOTO» (23-oct-2026; APAGADO de fabrica: `CSH_DEPTH_SHOW_UNSEEN`). Encendido,
// las galaxias, cuasares y grupos del catalogo que caen en el encuadre con distancia pero que la foto NO enseña se pintan
// huecos (fuera del «mas lejano» y de la escala); apagado, no estan. Las estrellas que no se ven no vuelven. Su boton («Also what your
// photo doesn't show», `btnUnseen`) esta en la 2.ª fila de capas de 3D VIEW (ui/groups.js; 24-oct-2026). -> cuantos se enseñan ahora.
// (`_unseenApply`: poner la bandera y rehacer el modelo, sin dibujar; `setShowUnseen`: ademas el boton, el dibujo y la linea de estado)
// (24-oct-2026, H3 de Gemini) El interruptor es UNO (`showUnseen`) pero cada imagen guardada en `_kept` lleva su `deepSky`: al cambiar
// de imagen (`onImageChanged`, `open`) se aplica a la que entra (`_unseenApply(st)`), no solo a la que estaba; si ya estaba como toca,
// no se toca su modelo. `force` (el clic del boton) lo rehace siempre.
CPStarfieldDock.prototype._unseenApply = function(stIn, force) {
   CSH_DEPTH_SHOW_UNSEEN = (this.showUnseen === true);
   var st = stIn || this.state, n = 0;
   if (st && st.result && typeof cshDepthShowUnseen === "function") {
      var ds = st.result.deepSky, was = !!(ds && ds.unseenShown === true);
      n = cshDepthShowUnseen(st.result, CSH_DEPTH_SHOW_UNSEEN);
      if (force === true || was !== (CSH_DEPTH_SHOW_UNSEEN === true)) st.dist = null;   // (el modelo se rehace con lo de ahora)
   } else if (st && force === true) st.dist = null;
   return n;
};
CPStarfieldDock.prototype.setShowUnseen = function(on) {
   this.showUnseen = (on === true);
   var n = this._unseenApply(null, true), st = this.state;
   try { cpStyleToggle(this.btnUnseen, this.showUnseen); } catch (eB) {}
   if (st && this.mode !== "" && !this._closed) { try { this._render(); this._sayState(); } catch (e) {} }
   return n;
};

// La linea de estado: que se enseña y que ha pasado con la red.
CPStarfieldDock.prototype._sayState = function() {
   var st = this.state;
   if (!st) return;
   var r = st.result, bits = [], kind = "ok", net = [];
   {
      var m = this._distModel();
      // (tarea H7, 21-oct: el singular —«1 galaxies»—)
      bits.push(cpSvGroup(m.counts.stars) + " " + ((m.counts.stars === 1) ? optT("star") : optT("stars")));
      if (m.counts.clusters > 0) bits.push(m.counts.clusters + " " + ((m.counts.clusters === 1) ? optT("cluster") : optT("clusters")));
      if (m.counts.galaxies > 0) bits.push(m.counts.galaxies + " " + ((m.counts.galaxies === 1) ? optT("galaxy") : optT("galaxies")));
      if (m.counts.quasars > 0) bits.push(m.counts.quasars + " " + ((m.counts.quasars === 1) ? optT("quasar") : optT("quasars")));
      if (m.counts.nebulae > 0) bits.push(m.counts.nebulae + " " + ((m.counts.nebulae === 1) ? optT("nebula") : optT("nebulae")));
      if (m.subject && !m.subject.hasDistance) { bits.push(this._subjectText(m)); kind = "warn"; }
   }
   // (22-oct: el primer vistazo, dicho: son solo las brillantes y el resto esta llegando; o, si el campo entero fallo, que se queda asi)
   if (st.partial) { bits.push(format(optT("first look: the stars down to G %s, reading the rest…"), String(CP_SFUI_FIRST_G))); kind = "info"; }
   else if (r.firstLook && String(st.net.full || "").indexOf("failed:") === 0) { bits.push(format(optT("only the stars down to G %s: the whole field could not be read"), String(CP_SFUI_FIRST_G))); kind = "warn"; }
   // (Block G, 20-oct-2026) la profundidad de la foto delante y lo que se deja fuera detras (CabraShared/csh_depth.js)
   var DL = (typeof cshDepthSay === "function") ? cshDepthSay(r, bits) : null;
   if (DL) bits = DL.bits;
   // Cabra3D (15-oct): la red, con QUE servidor y QUE codigo; y en el tooltip, de donde sale cada dato (tm/netstatus.js)
   var NL = this._c3NetLine();
   net = NL.net;
   if (NL.warn && kind === "ok") kind = "warn";
   this._say(bits.concat(net).join(" · "), kind, (DL && DL.detail) ? DL.detail + (NL.detail ? "<br><br>" + NL.detail : "") : NL.detail);
};

// ---------------------------------------------------------------------------
// LOS MODELOS (se hacen una vez por imagen y fuente; la red los tira)
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._distModel = function() {
   var st = this.state;
   if (!st.dist) {
      st.dist = cpSvDistModel(st.result, {});
      st.dist.objOfStar = {};
      for (var i = 0; i < st.dist.objects.length; ++i) { var o = st.dist.objects[i]; if (o.kind === "star" || o.kind === "member") st.dist.objOfStar[o.ref] = i; }
   }
   return st.dist;
};

// ---------------------------------------------------------------------------
// PINTAR. `_render` hace el dibujo en un bitmap; `_paint` (onPaint) lo copia y
// pinta encima lo que sigue al raton.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._render = function() {
   if (this._closed || this.mode === "") return;
   if (this.fl && this.fl.strip) this._flightPanelPlace();          // (el panel de opciones de un vuelo, superpuesto: a su sitio si el lienzo ha cambiado)
   // Un dibujo pedido con una transicion en marcha: la transicion se acaba aqui. Si era la de ABRIR (el
   // lienzo coge su tamaño mientras el panel aparece), sigue despues hacia el dibujo nuevo, sin volver a empezar.
   var reopen = null;
   if (this.anim !== null && !this._animPending) {
      if (this.anim.close) { this._animEnd(); return; }
      if (this.anim.fromFoto) reopen = this.anim.t0;
      this._animDrop();
   }
   var w = 0, h = 0;
   try { w = this.canvas.width; h = this.canvas.height; } catch (e) {}
   if (!(w > 8 && h > 8)) return;
   // (el bitmap del dibujo anterior se reutiliza si es del mismo tamaño y nadie mas lo guarda; si lo guarda alguien —el cielo
   // desde otra estrella, `sky.from`—, se libera como se hacia siempre y no se reutiliza: no se pinta encima de lo ajeno)
   var into = (CP_SFUI_REUSE_FRAME === true && this._spare && this._spare.width === w && this._spare.height === h) ? this._spare : null;
   var o = this._light ? { light: true } : null;
   var lodCap = (o && this._lod && CP_SFUI_LOD_STARS > 0) ? this._lodCapNow() : 0;
   if (lodCap > 0) o.lod = lodCap;
   if (into) { o = o || {}; o.into = into; }
   // (Cabra3D, tarea H9: en un lienzo muy ancho —pantalla completa— la escala del dibujo crece con el, hasta el doble: `c3BoxScale`)
   var scU = cpUiScale(this.canvas), scR = (typeof c3BoxScale === "function") ? c3BoxScale(w, scU) : scU;
   // (V4, segunda ronda: con la escala crecida, las cifras del eje del fondo se pisaban y se quitaban —«10 000 M ly», «100 000 M ly»—: su
   // letra no pasa de 1,25 veces la de la interfaz)
   if (scR > 1.25 * scU) { o = o || {}; o.tickSc = 1.25 * scU; }
   // (V4: el lienzo de la pantalla completa, del tamaño del dialogo: Windows lo deja 30 px mas bajo de lo pedido y el pie salia cortado)
   if (this.isFullScreen && this.isFullScreen() && !this._fsFix) { var Dd = this.dialog; if (Dd && (this.canvas.height > Dd.height || this.canvas.width > Dd.width)) { this._fsFix = true; try { this.canvas.resize(Dd.width, Dd.height); } catch (eR) {} this._fsFix = false; w = this.canvas.width; h = this.canvas.height; } }
   // (24-oct-2026, Nino: «Bitmap.fill(): Illegal operation while a painting task is active» al abrir Cabra3D) el bitmap de repuesto
   // se RESERVA antes de pintar, no despues: si durante el dibujo algo atiende eventos (la consulta de nombres de SIMBAD, la red
   // de la maquina del tiempo: optProcessEvents) y entra otro `_render`, ese otro cogia el mismo `_spare` y le hacia `fill` con
   // nuestro Graphics aun abierto. Ahora el de dentro no lo ve y pinta en uno nuevo. C3_RENDER_BREAK = "spare" vuelve a lo de antes.
   if (into && C3_RENDER_BREAK !== "spare") this._spare = null;
   var t0 = Date.now(), made = null;
   try { made = this.renderAt(w, h, scR, o); }
   finally { if (into && (made === null || made.bitmap !== into) && !this._spare) this._spare = into; }
   if (made === null) return;
   if (made.bitmap === into) this._spare = null;
   var old = this.frame;
   this.frame = made.bitmap;
   if (old && old !== this.frame) {
      var held = (this.sky && this.sky.from === old) || (this.anim && (this.anim.final === old || this.anim.buf === old));
      if (!held && CP_SFUI_REUSE_FRAME === true && old.width === w && old.height === h) { cpSfUiFree(this._spare); this._spare = old; }
      else { try { old.clear(); } catch (e1) {} }
   }
   this.lay = made.lay;
   this.lay.ms = Date.now() - t0;
   if (o && o.light && this._lod && CP_SFUI_LOD_STARS > 0) this._lodFeed(this.lay.ms, lodCap);
   this._zoomSync();
   if (this._animPending) return;                            // lo enseña la transicion que esta a punto de arrancar
   // (el panel se acaba de abrir y hasta ahora el lienzo no tenia tamaño: la transicion de abrir arranca aqui)
   if (reopen === null && this._animOpenAt > 0) {
      if (CP_SF_ANIM_CLOCK() - this._animOpenAt < CP_SV.ANIM_MS) reopen = CP_SF_ANIM_CLOCK();
      this._animOpenAt = 0;
   }
   if (reopen !== null && this._animOn() && this._animGo({ kind: "foto" }, { t0: reopen })) return;
   try { this.canvas.repaint(); } catch (e2) {}
};

// El dibujo entero a un tamaño y una escala dados. Devuelve { bitmap, lay } (lo
// usa tambien «exportar», con el doble de escala). NO depende del lienzo.
// `opts` (las transiciones y el arrastre): { noObjects, noBody, light }: ver `_drawDist`.
// (`opts.into`: un bitmap de ese tamaño en el que pintar en vez de crear otro; `opts.lod`: el tope de estrellas al girar)
CPStarfieldDock.prototype.renderAt = function(w, h, sc, opts) {
   var bmp = (opts && opts.into && opts.into.width === w && opts.into.height === h) ? opts.into : new Bitmap(w, h), lay = null;
   bmp.fill(CP_INT_SURFACE);
   var g = new Graphics(bmp);
   try {
      g.antialiasing = true;
      try { g.textAntialiasing = true; } catch (eTa) {}
      if (this.state === null) lay = this._drawEmpty(g, w, h, sc);
      else lay = this._drawDist(g, w, h, sc, opts);
   } finally {
      g.end();
   }
   lay.w = w; lay.h = h; lay.sc = sc;
   this._card = this._currentCard();
   return { bitmap: bmp, lay: lay };
};

// LA GUARDA DEL PINTADO DEL LIENZO 3D (27-oct-2026, E7), el mismo patron que la foto (ui/photo_view.js:55-59), csPaintGuarded
// (CabraShared/cs_ui.js:62) y ccPaintGuarded (CabraComposition/src/ui/cc_paint.js:142):
//   · CSH_PAINTING > 0 mientras pinta: si algo llamado desde `_paint` (la ficha, `_drawMarks`, el enlace de SIMBAD…) usa cshYield o
//     cshProcessEvents, NO atiende eventos dentro del onPaint (regla 4; el cuelgue C0000005 del 26-oct en la foto);
//   · una EXCEPCION al pintar no sale del onPaint: se apunta (`_paintErr`, la consola UNA vez por mensaje distinto) y el lienzo enseña
//     al menos el dibujo ya hecho (`this.frame`, sin las marcas del raton) o el fondo; el contador baja siempre (finally) y el
//     siguiente repintado vuelve a intentarlo entero: el control no queda colgado ni con basura a medias.
// Costura del rojo (tests/c3_paint_guard3d.js, $env:C3_PG_MUTATE="1"): C3_PAINT_GUARD3D = false → el onPaint de antes.
var C3_PAINT_GUARD3D = true;
CPStarfieldDock.prototype._paintGuarded = function(target) {
   if (C3_PAINT_GUARD3D !== true) { this._paint(target); return; }
   var on = (typeof CSH_PAINTING === "number");
   if (on) ++CSH_PAINTING;
   try { this._paint(target); }
   catch (e) { this._paintFailed(e, target); }
   finally { if (on) --CSH_PAINTING; }
};
CPStarfieldDock.prototype._paintFailed = function(e, target) {
   var msg = String((e && e.message) ? e.message : e), prev = this._paintErr;
   this._paintErr = { msg: msg, n: (prev && prev.msg === msg) ? prev.n + 1 : 1, total: (prev ? prev.total : 0) + 1 };
   if (this._paintErr.n === 1) { try { console.warningln("Cabra3D 3D canvas: paint failed: " + msg); } catch (eC) {} }
   // (lo minimo, con otro Graphics: el de `_paint` ya se cerro en su finally; si tambien falla, el lienzo se queda como este)
   var t = target || this._canvasDocked || this.canvas, g = null;
   if (t !== this.canvas) return;
   try {
      g = new Graphics(this.canvas);
      if (this.frame && this.frame.width === this.canvas.width && this.frame.height === this.canvas.height) g.drawBitmap(0, 0, this.frame);
      else g.fillRect(new Rect(0, 0, this.canvas.width, this.canvas.height), new Brush(CP_INT_SURFACE));
   } catch (eF) {}
   finally { if (g !== null) { try { g.end(); } catch (eE) {} } }
};

// (Con una transicion en marcha se copia su fotograma y nada mas: las marcas del raton van dentro
// de los dibujos de salida y de llegada que la transicion funde.)
// `target` = el control que pinta (el lienzo de la pantalla completa lo pasa; el de siempre, no). Solo pinta el que ES el
// lienzo ahora: a pantalla completa el de siempre, tapado, no pinta (pintar otro control fuera de SU repintado no vale).
CPStarfieldDock.prototype._paint = function(target) {
   var t = target || this._canvasDocked || this.canvas;
   if (t !== this.canvas) return;
   var g = new Graphics(this.canvas);
   try {
      // (un vuelo en marcha —vista previa o grabacion—: se copia SU fotograma, ya pintado en el tic, y nada mas)
      if (this.fl && this.fl.show && this.mode !== "") { g.drawBitmap(0, 0, this.fl.show); return; }
      if (this.sky && this.sky.show && this.mode !== "") { g.drawBitmap(0, 0, this.sky.show); return; }   // Cabra3D: el cielo desde otra estrella
      if (this.frame && (this.mode !== "" || (this.fs && this.fs.on))) g.drawBitmap(0, 0, this.frame);      // (a pantalla completa, la FOTO es un dibujo mas)
      else g.fillRect(new Rect(0, 0, this.canvas.width, this.canvas.height), new Brush(CP_INT_SURFACE));
      if (this.lay && this.mode !== "" && this.anim === null) {
         g.antialiasing = true;
         this._drawMarks(g, this.lay, 1);
      }
   } finally {
      g.end();
   }
};

// Una brocha por color (a 5 bits por canal: unas decenas), guardada: girar no crea miles.
// `alpha` (0…1, opcional): opacidad DE VERDAD (en 16 pasos). (La primera version de las transiciones «apagaba» un
// punto mezclando su color con el del fondo: encima de la foto o de otros puntos eso era un cuadrado oscuro que los
// TAPABA —el «agujero» en el nucleo de M 13 y en la estrella brillante de NGC 1560: revision visual del 13-oct-2026—.)
CPStarfieldDock.prototype._brush = function(rgb, alpha) {
   var lev = (alpha === undefined || alpha >= 1) ? 15 : Math.max(0, Math.round(alpha * 15)), key = (rgb & 0xf8f8f8) + lev * 0x1000000;
   if (!this._brushes) this._brushes = {};
   if (!this._brushes[key]) this._brushes[key] = new Brush(((Math.round(lev * 17) << 24) | (rgb & 0xf8f8f8)) >>> 0);
   return this._brushes[key];
};
CPStarfieldDock.prototype._pen = function(rgb, alpha, width) {
   var lev = (alpha >= 1) ? 15 : Math.max(0, Math.round(alpha * 15)), key = (rgb & 0xf8f8f8) + lev * 0x1000000;
   if (!this._pens || this._pensW !== width) { this._pens = {}; this._pensW = width; }
   if (!this._pens[key]) this._pens[key] = new Pen(((Math.round(lev * 17) << 24) | (rgb & 0xf8f8f8)) >>> 0, width);
   return this._pens[key];
};
// UN PUNTO de radio `r` (la pluma tiene que venir nula). El mismo en el dibujo definitivo y en vuelo: de menos de 3 px
// de ancho, un cuadradito suavizado (los 20 000 del HR de M 13: en circulos no llegan a 25 fotogramas por segundo, y
// con tres rectangulos por punto «para redondearlos» bajaban de 60 a 30: medido); de ahi arriba, un circulo.
// (`round`: en un VIDEO todos son discos suavizados, tambien los de 1-3 px: un globular de cuadraditos se nota. En el panel,
// los pequeños son un cuadrado sin alisar, que es mucho mas rapido y a ese tamaño no se distingue.)
CPStarfieldDock.prototype._dot = function(g, x, y, r, brush, round) {
   if (round === true && CP_SFUI_ROUND_DOTS === true) { g.brush = brush; g.drawCircle(x, y, (r > 0.7) ? r : 0.7); }
   else if (r < 1.5) { var d = (r > 0.5) ? r : 0.5; g.fillRect(x - d, y - d, x + d, y + d, brush); }
   else { g.brush = brush; g.drawCircle(x, y, r); }
};
var CP_SFUI_ROUND_DOTS = true;       // (apagado: en un video los puntos pequeños vuelven a ser cuadrados; el control de las pruebas)

// Fuentes del lienzo, a la escala que toque.
CPStarfieldDock.prototype._fonts = function(sc) {
   var lab = CP_ATLAS.size.label * sc, body = CP_ATLAS.size.body * sc;
   return { caps: cpFont("text", lab, true, false, cpCapsSpacing(lab)), body: cpFont("text", body), small: cpFont("text", lab),
            mono: cpFont("mono", lab), monoBody: cpFont("mono", body), name: cpFont("display", CP_ATLAS.size.title * sc),
            plate: cpFont("display", (CP_ATLAS.size.body + 2) * sc),
            sub: cpFont("display", (CP_ATLAS.size.body + 1) * sc, false, true) };
};
function cpSfUiTextH(font) { var h = 12; try { h = font.ascent + font.descent; } catch (e) {} return h; }

// La cabecera pintada: el rotulo, el nombre y un subtitulo. Devuelve su alto.
CPStarfieldDock.prototype._drawHead = function(g, w, sc, F, eyebrow, sub) {
   var P = function(v) { return Math.round(v * sc); }, x = P(CP_SFUI.PAD), y = P(CP_SFUI.PAD);
   g.font = F.caps; g.pen = new Pen(CP_INT_AMBER);
   g.drawText(x, y + F.caps.ascent, eyebrow);
   var y2 = y + cpSfUiTextH(F.caps) + P(CP_SFUI.GAP);
   g.font = F.name; g.pen = new Pen(CP_INT_TEXT);
   // (tarea H3, 21-oct: en un lienzo estrecho el subtitulo salia cortado con «…». Ahora va ENTERO o no va; el titulo usa el ancho que haga
   // falta —solo un titulo larguisimo se acorta— y los dos, enteros, en el tooltip de la cabecera: `this._headTip`)
   var full = this.state ? String(this._headTitle()) : "", room = w - 2 * x, gapS = P(CP_ATLAS.space[2]), withSub = (F.name.width(full) + gapS + F.sub.width(sub) <= room);
   this._headFull = full;      // (1-nov, D9: lo que dice la cabecera; lo lee tests/c3_d_fixes.js)
   var name = withSub ? full : cpElide(F.name, full, room);
   g.drawText(x, y2 + F.name.ascent, name);
   if (withSub) { g.font = F.sub; g.pen = new Pen(CP_INT_MUTED); g.drawText(x + F.name.width(name) + gapS, y2 + F.name.ascent, sub); }
   this._headTip = (withSub && name === full) ? "" : full + " — " + sub;
   var bottom = y2 + cpSfUiTextH(F.name) + P(CP_SFUI.GAP);
   this._headBottom = bottom;
   g.pen = new Pen(CP_INT_BORDER, 1);
   g.drawLine(x, bottom, w - x, bottom);
   return bottom + P(CP_SFUI.GAP);
};

CPStarfieldDock.prototype._drawEmpty = function(g, w, h, sc) {
   var F = this._fonts(sc);
   g.font = F.sub; g.pen = new Pen(CP_INT_MUTED);
   g.drawTextRect(new Rect(0, 0, w, h), optT("Nothing computed for this image yet"), TextAlign_Center | TextAlign_VertCenter);
   return { kind: "empty" };
};

// La leyenda, en filas, a partir de y. `items` = [ { draw( g, x, yMid ), text } ].
// Devuelve el y donde acaba.
CPStarfieldDock.prototype._drawLegend = function(g, items, x, y, maxW, sc, F) {
   var P = function(v) { return Math.round(v * sc); }, sym = P(CP_ATLAS.space[3]), gap = P(CP_ATLAS.space[3]), widths = [], i;
   for (i = 0; i < items.length; ++i) widths.push(sym + F.small.width(items[i].text));
   var flow = cpSfUiFlow(widths, maxW, gap), rowH = P(CP_SFUI.ROW_H);
   g.font = F.small;
   for (i = 0; i < items.length; ++i) {
      var ix = x + flow.at[i].x, iy = y + flow.at[i].row * rowH + rowH / 2;
      items[i].draw(g, ix + sym / 2 - P(2), iy);
      g.font = F.small; g.pen = new Pen(CP_INT_TEXT2);
      g.drawText(ix + sym, iy + F.small.ascent / 2 - 1, items[i].text);
   }
   return y + flow.rows * rowH;
};
// Cuantas filas ocupara (para reservarle el sitio antes de pintar el trazado).
CPStarfieldDock.prototype._legendRows = function(items, maxW, sc, F) {
   var P = function(v) { return Math.round(v * sc); }, widths = [];
   for (var i = 0; i < items.length; ++i) widths.push(P(CP_ATLAS.space[3]) + F.small.width(items[i].text));
   return cpSfUiFlow(widths, maxW, P(CP_ATLAS.space[3])).rows;
};

// El pie: UNA linea (tarea H4, 21-oct: el texto de dos o tres lineas —«The width of the field is not to scale…»— estaba siempre a la
// vista y en pantalla completa salia cortado por abajo). Si el texto entero cabe en una linea, va; si no, un aviso corto de que esta en
// el tooltip (lo pone `_onMove`) y, si ni eso cabe, uno mas corto. Nunca «…».
CPStarfieldDock.prototype._drawFoot = function(g, w, h, sc, F, text) {
   var P = function(v) { return Math.round(v * sc); }, x = P(CP_SFUI.PAD), maxW = w - 2 * x, fh = P(CP_SFUI.FOOT_H);
   var cands = [String(text), optT("Notes on the scale and the sources: point here to read them."), optT("Notes: point here.")], line = "", i;
   for (i = 0; i < cands.length; ++i) if (F.small.width(cands[i]) <= maxW) { line = cands[i]; break; }
   var y = h - fh + Math.round((fh - cpSfUiTextH(F.small)) / 2);
   g.font = F.small; g.pen = new Pen(CP_INT_MUTED);
   if (line.length) g.drawText(x, y + F.small.ascent, line);
   return { rect: { x: 0, y: h - fh, w: w, h: fh }, text: String(text), cut: (line !== String(text)), lines: line.length ? [line] : [] };
};

// La ficha: una caja con filete de oro a la izquierda y tres lineas.
CPStarfieldDock.prototype._drawCard = function(g, w, y, sc, F, card) {
   var P = function(v) { return Math.round(v * sc); }, x = P(CP_SFUI.PAD), hh = this._cardH(sc, F, (card && card.line4) ? 1 : 0), maxW = w - 2 * x - P(CP_ATLAS.space[3]);
   // (tarea H4, 21-oct: sin ficha, la pista es UNA linea corta, sin caja —antes una banda vacia de tres lineas—; la ficha, al salir, va
   // ENCIMA de la leyenda: el dibujo solo le reserva la linea de la pista, `CP_SFUI.HINT_H`. En pantalla completa no hay «imagen» a la que
   // señalar: no se dice)
   if (!card) {
      if (this._c3Narrow) return { x: x, y: y + hh, w: w - 2 * x, h: 0, lines: [] };          // (tarea H3: estrecho, sin pista)
      var hint = (this.isFullScreen && this.isFullScreen()) ? optT("Point at a star to see what it is.") : optT("Point at a star, here or in the photo, to see what it is.");
      if (F.sub.width(hint) > w - 2 * x) hint = optT("Point at a star to see what it is.");
      var hy = y + hh - P(CP_SFUI.HINT_H);
      g.font = F.sub; g.pen = new Pen(CP_INT_MUTED);
      if (F.sub.width(hint) <= w - 2 * x) g.drawText(x, hy + Math.round((P(CP_SFUI.HINT_H) + F.sub.ascent) / 2) - 1, hint);
      return { x: x, y: hy, w: w - 2 * x, h: P(CP_SFUI.HINT_H), lines: [] };
   }
   g.pen = new Pen(CP_INT_BORDER, 1); g.brush = new Brush(CP_INT_BG);
   g.drawRect(x, y, w - x, y + hh);
   g.fillRect(new Rect(x, y, x + Math.max(2, P(2)), y + hh), new Brush(CP_INT_AMBER));
   var tx = x + P(CP_ATLAS.space[2]), ty = y + P(CP_SFUI.GAP);
   g.font = F.caps; g.pen = new Pen(CP_INT_AMBER);
   g.drawText(tx, ty + F.caps.ascent, cpElide(F.caps, card.head, maxW));
   var y2 = ty + cpSfUiTextH(F.caps) + 1;
   g.font = F.plate; g.pen = new Pen(CP_INT_TEXT);
   // (26-oct-2026) el NOMBRE es un enlace a SIMBAD cuando la ficha lleva `link` (ui/star_link.js): oro, subrayado, con su icono; devuelve su rectangulo
   var nameRect = null;
   if (card.link && typeof c3LinkPaintName === "function") nameRect = c3LinkPaintName(g, this, card, tx, y2 + F.plate.ascent, F, maxW, sc);
   else g.drawText(tx, y2 + F.plate.ascent, cpElide(F.plate, card.name, maxW));
   var y3 = y2 + cpSfUiTextH(F.plate);
   // (5-nov-2026) las TRES FILAS (`c3CardRowsOf`): la 1, lo principal, en claro y en la letra del texto; la 2 en el gris de los datos; la 3, las cifras, en mono apagado
   var rows = c3CardRowsOf(card), lines = [card.head, card.name], ri;
   if (rows.length === 1) {
      g.font = F.mono; g.pen = new Pen(CP_INT_TEXT2);
      g.drawText(tx, y3 + F.mono.ascent, cpElide(F.mono, rows[0], maxW));
      lines.push(rows[0]); y3 += cpSfUiTextH(F.mono);
   } else for (ri = 0; ri < rows.length; ++ri) {
      var mono = (ri === 2 && card.rows && card.rowsOf === card.data && card.rowsText !== true), rf = (ri === 0) ? F.body : mono ? F.mono : F.small;      // (la mono, solo para las cifras de Gaia de una estrella)
      g.font = rf; g.pen = new Pen((ri === 0) ? CP_INT_TEXT : (ri === 2) ? CP_INT_MUTED : CP_INT_TEXT2);
      g.drawText(tx, y3 + rf.ascent, cpElide(rf, rows[ri], maxW));
      lines.push(rows[ri]); y3 += cpSfUiTextH(rf);
   }
   // (26-oct-2026) una cuarta linea opcional (en la Galaxia: la posicion y la orbita de la estrella; tm/galaxy_card.js)
   if (card.line4) {
      var y4 = y3;
      g.pen = new Pen(CP_INT_TEXT2);
      g.drawText(tx, y4 + F.mono.ascent, cpElide(F.mono, card.line4, maxW));
      lines.push(card.line4);
   }
   var out = { x: x, y: y, w: w - 2 * x, h: hh, lines: lines, full: card.full, link: card.link || null, nameRect: nameRect };
   // (27-oct-2026, D3) con el cursor sobre el nombre-enlace, su aviso «Open in SIMBAD», pintado donde no tapa datos (ui/star_link.js)
   if (nameRect && typeof c3LinkPaintTip === "function") { try { c3LinkPaintTip(g, this, out, y + hh); } catch (eTip) {} }
   return out;
};

// ---------------------------------------------------------------------------
// LA FICHA de una estrella o de un objeto lejano: { head, name, data, full }
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._sourceText = function(d) {
   switch (String(d.source)) {
   case "cluster-catalog": return optT("cluster distance from the catalogue");
   case "cluster-parallax": return optT("mean parallax of the group");
   case "bailer-jones": return optT("Bailer-Jones et al. 2021");
   case "parallax-online": return optT("Gaia parallax with its real error");
   case "parallax-local": return optT("Gaia parallax, local database");
   // (N1: si es una paralaje, se dice, con su catalogo: «parallax · Gaia DR3»)
   case "simbad": return (d.kind === "parallax") ? optT("parallax") + ((d.catalog && d.catalog.length) ? " · " + d.catalog : " · SIMBAD") : optT("SIMBAD, measured distance");
   case "redshift": return optT("redshift");
   }
   return String(d.source || "");
};
CPStarfieldDock.prototype._interval = function(d) {
   if (!(d.lo > 0) || !(d.hi > 0) || d.hi <= d.lo) return "";
   var W = this._words(), a = cpSvFormatDistance(d.lo, this.unit, W), b = cpSvFormatDistance(d.hi, this.unit, W);
   return " (" + ((a.unit === b.unit) ? a.number : a.text) + " – " + b.text + ")";
};
// El nombre de una estrella por su fuente: «Gaia DR3 <id>», o su posicion si no hay id.
CPStarfieldDock.prototype._gaiaName = function(s) {
   return s.sourceId ? ("Gaia DR3 " + s.sourceId) : ("Gaia DR3 · " + cpAnnotSexRA(s.ra0) + " " + cpAnnotSexDec(s.dec0));
};
// El nombre que se ENSEÑA de una estrella (placa y ficha): el comun de Hipparcos, si no el legible de SIMBAD (cuando ha llegado), si no «Gaia DR3 <id>».
CPStarfieldDock.prototype._starShownName = function(si, s) {
   var n = (typeof this._starName === "function") ? this._starName(si) : this._gaiaName(s);
   var alt = (typeof this._simbadName === "function") ? this._simbadName(n) : "";
   return alt || n;
};
CPStarfieldDock.prototype._cardOfStar = function(idx) {
   var st = this.state;
   if (!st || !(idx >= 0)) return null;
   var s = st.result.stars[idx];
   if (!s) return null;
   var cl = (s.cluster >= 0) ? st.result.clusters[s.cluster] : null, sel = (idx === this.selStar);
   var head = (sel ? optT("SELECTED STAR") : optT("STAR")) + "  ·  " +
              (cl ? format(optT("MEMBER OF %s"), String(cl.name || cl.id || "").toUpperCase()) : optT("FIELD STAR"));
   // (21-oct) el MISMO nombre que la placa (Hipparcos o SIMBAD); el «Gaia DR3 <id>» queda como identificador, el primer dato
   var gname = this._gaiaName(s), name = this._starShownName(idx, s);
   var color = s.bpRp, mag = s.g, bits = [];      // (Cabra3D: la ficha da los datos de Gaia; la fuente «Image» era del HR)
   if (mag !== null && isFinite(mag)) bits.push("G " + cpSvFx(mag, 2));
   if (color !== null && isFinite(color)) bits.push("BP−RP " + cpSvFx(color, 2) + " (Gaia)");
   if (s.dist) {
      var absM = cpSfAbsMag(mag, s.dist.pc);
      if (absM !== null) bits.push("M(G) " + ((absM >= 0) ? "+" : "−") + cpSvFx(Math.abs(absM), 1));
      bits.push(this._dist(s.dist.pc) + this._interval(s.dist));
      bits.push(this._sourceText(s.dist));
      if (s.dist.quality === "suspect") bits.push("⚠ " + ((s.dist.suspectWhy === "crowded") ? optT("doubtful: crowded cluster core") : optT("doubtful: RUWE of 1.4 or more")));
   } else
      bits.push(optT("no reliable distance"));
   // (26-oct-2026, A'b de Nino) lo que pasa la vara por poco —S/R a ojo de 12 a 20—: la misma palabra y la misma frase que lo lejano
   var faintS = (typeof cshDepthStarFaintSnr === "function") ? cshDepthStarFaintSnr(s) : null;
   if (faintS !== null) bits.push(format(optT("faint · barely visible: S/N %s; zoom in to see it"), cpSvDec(faintS.toFixed(1))));
   if (name !== gname) bits.unshift(gname);
   var full = head + "\n" + name + "\n" + bits.join(" · ");
   var rows = this._starRows(s, name, gname, faintS);
   if (rows) full += "\n" + optT("Colour: as seen (Gaia BP−RP), reddened by any dust in front. Luminosity: in the Gaia G band, from its distance and without correcting for dust, so the real one can only be higher (Sun: M(G) = +4.67, Casagrande & VandenBerg 2018).");
   if (s.dist && s.dist.ref) full += "\n" + String(s.dist.ref) + (s.dist.interval ? " [" + s.dist.interval + "]" : "");
   if (s.ruwe !== null && isFinite(s.ruwe)) full += "\nRUWE " + cpSvFx(s.ruwe, 2);
   if (s.phot && s.phot.ok && s.phot.use === false) full += "\n" + optT("the measure in the image is not used") + ": " + String(s.phot.why);
   // (26-oct-2026) el nombre de la ficha, enlace a SIMBAD (ui/star_link.js): el mismo en Campo y en Galaxia
   var data = bits.join("  ·  ");
   return { head: head, name: name, data: data, rows: rows, rowsOf: data, full: full, link: (typeof c3LinkOfStar === "function") ? c3LinkOfStar(this, idx, name) : null };
};
// (5-nov-2026, peticion de Nino: «solo damos una linea dificil de entender; da tres, con lo mas importante claro y organizado»)
// LAS TRES LINEAS de la ficha de una estrella: 1 · como es (su color a la vista y cuanta luz da frente al Sol) · 2 · donde esta (la
// distancia, su intervalo y de donde sale) · 3 · los datos de Gaia. `data` (la linea unica de antes) se queda: la leen las pruebas y la
// maquina del tiempo. C3_CARD_ROWS = false vuelve a la linea unica (el rojo de la prueba).
var C3_CARD_ROWS = true;
var C3_SUN_MG = 4.67;            // M(G) del Sol: Casagrande & VandenBerg 2018, MNRAS 479, L102
// El color a la vista por BP−RP: los cortes son los de las clases B/A/F/G/K/M en enanas (Pecaut & Mamajek 2013, tabla de 2022).
function c3CardColourWord(bpRp) {
   if (bpRp === null || !isFinite(bpRp)) return "";
   if (bpRp < 0.0) return optT("bluish white");
   if (bpRp < 0.37) return optT("white");
   if (bpRp < 0.72) return optT("yellowish white");
   if (bpRp < 0.98) return optT("yellow, like the Sun");
   if (bpRp < 1.84) return optT("orange");
   return optT("red");
}
// Cuanta luz da frente al Sol, por su M(G): «12× la luz del Sol», «85 % de la luz del Sol». Cota inferior: el polvo solo apaga.
function c3CardLumText(absM) {
   if (absM === null || !isFinite(absM)) return "";
   var L = Math.pow(10, -0.4 * (absM - C3_SUN_MG)), n;
   if (L >= 2) {
      n = (L < 10) ? cpSvFx(L, 1) : cpSvGroup(Number(L.toPrecision(2)));
      return format(optT("at least %s× the Sun's light"), n);
   }
   n = (L < 0.1) ? cpSvFx(L * 100, 1) : String(Math.round(L * 100));
   return format(optT("at least %s %% of the Sun's light"), n);
}
CPStarfieldDock.prototype._starRows = function(s, name, gname, faintS) {
   if (C3_CARD_ROWS !== true) return null;
   var col = c3CardColourWord(s.bpRp), r1 = [], r2 = [], r3 = [];
   if (col.length) r1.push(format(optT("Looks %s"), col));
   if (s.dist) {
      var lum = c3CardLumText(cpSfAbsMag(s.g, s.dist.pc));
      if (lum.length) r1.push(lum);
      r2.push(format(optT("At %s"), this._dist(s.dist.pc) + this._interval(s.dist)));
      r2.push(this._sourceText(s.dist));
      if (s.dist.quality === "suspect") r2.push("⚠ " + ((s.dist.suspectWhy === "crowded") ? optT("doubtful: crowded cluster core") : optT("doubtful: RUWE of 1.4 or more")));
   } else {
      r1.push(optT("its light is unknown without a distance"));
      r2.push(optT("No reliable distance in Gaia"));
   }
   if (name !== gname) r3.push(gname);
   if (s.g !== null && isFinite(s.g)) r3.push("G " + cpSvFx(s.g, 2));
   if (s.bpRp !== null && isFinite(s.bpRp)) r3.push("BP−RP " + ((s.bpRp < 0) ? "−" : "") + cpSvFx(Math.abs(s.bpRp), 2));
   var absM = s.dist ? cpSfAbsMag(s.g, s.dist.pc) : null;
   if (absM !== null) r3.push("M(G) " + ((absM >= 0) ? "+" : "−") + cpSvFx(Math.abs(absM), 1));
   if (faintS !== null) r3.push(format(optT("faint · barely visible: S/N %s; zoom in to see it"), cpSvDec(faintS.toFixed(1))));
   return [r1.join("  ·  "), r2.join("  ·  "), r3.join("  ·  ")];
};
// Las filas de una ficha cualquiera: las suyas si las trae (y nadie ha cambiado `data` despues: la maquina del tiempo la rehace), si no
// las de `data` repartidas: hasta tres datos, uno por linea; con mas, los dos primeros y el resto juntos en la tercera.
function c3CardRowsOf(card) {
   if (card.rows && card.rowsOf === card.data) return card.rows;
   var bits = String(card.data || "").split("  ·  ").filter(function(b) { return b.length > 0; });
   if (C3_CARD_ROWS !== true || bits.length <= 1) return [String(card.data || "")];
   if (bits.length <= 3) return bits;
   return [bits[0], bits[1], bits.slice(2).join("  ·  ")];
}
// El alto de la ficha: cabecera, nombre, tres filas y, si la lleva (la Galaxia), la cuarta.
CPStarfieldDock.prototype._cardH = function(sc, F, extra) {
   var P = function(v) { return Math.round(v * sc); };
   if (C3_CARD_ROWS !== true) return P(CP_SFUI.CARD_H);
   return Math.max(P(CP_SFUI.CARD_H), 2 * P(CP_SFUI.GAP) + cpSfUiTextH(F.caps) + 1 + cpSfUiTextH(F.plate) + cpSfUiTextH(F.body) + cpSfUiTextH(F.small) + (1 + (extra || 0)) * cpSfUiTextH(F.mono) + P(CP_ATLAS.space[0]));
};
CPStarfieldDock.prototype._kindText = function(ob) {
   switch (ob.kind) {
   case "cluster": return (ob.cls === "globular") ? optT("globular cluster") : (ob.cls === "open") ? optT("open cluster") : optT("star group");
   case "galaxy": return optT("galaxy");
   case "quasar": return optT("quasar");
   case "group": return optT("group of galaxies");
   case "star": case "member": return optT("star");
   case "nebula": return optT("emission nebula");
   }
   if (ob.cls === "star-cluster" || ob.cls === "association") return optT("star cluster");
   if (ob.cls === "planetary-nebula") return optT("planetary nebula");
   if (ob.cls === "nebula") return optT("nebula");
   return optT("object");
};
// EL NOMBRE A LA VISTA (tarea H7, 21-oct): SIMBAD da «NAME Tau R1», «* alf Tau», «V* T Tau»: el prefijo de catalogo no se enseña
// (el nombre guardado no se toca: con el se casan las consultas de SIMBAD).
function cpSfUiShowName(n) { return String(n || "").replace(/^(NAME|\*\*|\*|V\*)\s+/, ""); }
// (21-oct, a peticion de Nino: «en los videos, al mostrar el objeto mas lejano y el mas cercano, pon tambien sus NOMBRES») LA PLACA de un
// objeto, UNA SOLA para el video y el panel: [ NOMBRE, PAPEL · dato ]. Linea 1: el nombre de verdad (nunca el papel); linea 2: lo que es
// en este campo («nearest star in this field», «farthest quasar») o su clase, y su dato.
// El nombre: el de SIMBAD sin prefijo de catalogo; una estrella, el comun si es de Hipparcos, si no «Gaia DR3 <id>» (`_starName`).
CPStarfieldDock.prototype._plateBase = function(model, idx) {
   var ob = model.objects[idx], st = this.state, name = cpSfUiShowName(ob.name);
   if (name.length > 0) return name;
   if (ob.kind === "star" || ob.kind === "member") return (typeof this._starName === "function") ? this._starName(ob.ref) : this._gaiaName(st.result.stars[ob.ref]);
   try {
      var d = st.result.deepSky.objects[ob.ref];
      if (d && d.id) return cpSfUiShowName(d.id);
      if (d && isFinite(d.ra) && isFinite(d.dec)) return this._kindText(ob) + " · " + cpAnnotSexRA(d.ra) + " " + cpAnnotSexDec(d.dec);
   } catch (e) {}
   return this._kindText(ob);
};
// …y el que se enseña: si SIMBAD ha dado un nombre legible para un «Gaia DR3 <id>» (`tm/names_simbad.js`), ese.
CPStarfieldDock.prototype._plateName = function(model, idx) {
   var b = this._plateBase(model, idx), alt = (typeof this._simbadName === "function") ? this._simbadName(b) : "";
   return alt || b;
};
// El PAPEL de un destacado, con su clase («nearest star in this field», «farthest quasar»); sin papel, la clase sola.
var C3_PLATE_RELIABLE = true;
CPStarfieldDock.prototype._plateLabel = function(model, idx, role) {
   var ob = model.objects[idx];
   if (role !== "nearest" && role !== "farthest") return this._kindText(ob);
   var near = (role === "nearest");
   switch (ob.kind) {
   case "star": case "member": if (C3_PLATE_RELIABLE === false) return near ? optT("nearest star in this field") : optT("farthest star in this field");      // (el rojo: el rotulo de antes)
      return near ? optT("nearest star with a reliable distance") : optT("farthest star with a reliable distance");   // (1-nov, D3: la mas cercana/lejana excluye las de distancia dudosa —`ob.suspect`, cpSvDistModel—; el rotulo lo dice)
   case "cluster": return near ? optT("nearest cluster") : optT("farthest cluster");
   case "galaxy": return near ? optT("nearest galaxy") : optT("farthest galaxy");
   case "quasar": return near ? optT("nearest quasar") : optT("farthest quasar");
   case "group": return near ? optT("nearest group of galaxies") : optT("farthest group of galaxies");
   case "nebula": return near ? optT("nearest nebula") : optT("farthest nebula");
   }
   return near ? optT("nearest object") : optT("farthest object");
};
CPStarfieldDock.prototype._plateOf = function(model, idx, role) {
   var ob = model.objects[idx], st = this.state, name = this._plateName(model, idx), label = this._plateLabel(model, idx, role), data = label + " · " + this._dist(ob.pc);
   if (ob.kind === "star" && ob.faint > 0) data += " · " + optT("faint");      // (26-oct-2026, A'b: una estrella debil tambien lo dice en su placa)
   if (ob.kind === "nebula") {
      // LA NEBULOSA (14-oct-2026): nombre, distancia CON SU ERROR y de donde sale (peticion de Nino: «como las de las planetarias»)
      var nd = st.result.nebulae.objects[ob.ref].dist;
      data = label + " · " + this._dist(ob.pc) + " " + this._nebulaErrText(nd) + " · " + this._nebulaSourceText(nd, true);
   } else if (ob.kind === "galaxy" || ob.kind === "quasar" || ob.kind === "group") {
      var d = st.result.deepSky.objects[ob.ref];
      if (d && d.dist && d.dist.kind === "redshift" && d.redshift)
         data = label + " · z = " + cpSvDec(d.redshift.z.toFixed((d.redshift.z < 0.1) ? 3 : 2)) + " · " + format(optT("light left %s ago"), cpSvFormatYears(d.redshift.lookbackYr, this._words()));
      // (el intervalo NO va en la placa: va en la ficha. Con el dentro la placa media 310 px y de cinco cabian cuatro.)
      if (ob.faint > 0) data += " · " + optT("faint");      // (24-oct-2026, D1 = A')
   }
   return [name, data];
};
CPStarfieldDock.prototype._cardOfObject = function(idx) {
   var st = this.state, model = st ? st.dist : null;
   if (!model || !(idx >= 0) || !model.objects[idx]) return null;
   var ob = model.objects[idx];
   if (ob.kind === "star" || ob.kind === "member") return this._cardOfStar(ob.ref);
   var head = this._kindText(ob).toUpperCase(), name = cpSfUiShowName(ob.name), bits = [], full = "", distFirst = true;
   if (ob.kind === "cluster") {
      var cl = st.result.clusters[ob.ref];
      bits.push(this._dist(cl.dist.pc) + this._interval(cl.dist));
      bits.push(cpSvGroup(cl.n) + " " + optT("members by common proper motion"));
      bits.push(this._sourceText({ source: (cl.dist.source === "cluster-parallax") ? "cluster-parallax" : "cluster-catalog" }));
      full = String(cl.dist.ref || "");
   } else if (ob.kind === "nebula") {
      // LA NEBULOSA: la distancia elegida con su error y su fuente, el tamaño de Sharpless, las OTRAS que hay (no se esconden) y
      // como se han quitado las estrellas de su capa
      var nb = st.result.nebulae.objects[ob.ref], nd2 = nb.dist, oth2 = [];
      bits.push(this._dist(nd2.pc) + " " + this._nebulaErrText(nd2));
      bits.push(this._nebulaSourceText(nd2, false));
      bits.push(format(optT("%d′ across (Sharpless)"), Math.round(nb.sizeArcmin)));
      for (var ci = 0; ci < nb.candidates.length; ++ci) if (!nb.candidates[ci].used) oth2.push(this._dist(nb.candidates[ci].dist.pc) + " " + this._nebulaErrText(nb.candidates[ci].dist) + " (" + this._nebulaSourceText(nb.candidates[ci].dist, true) + ((nb.candidates[ci].why === "poor") ? ", " + optT("error over 20 %") : "") + ")");
      if (oth2.length > 0) bits.push(format(optT("%d other estimates"), oth2.length));
      full = String(nd2.ref || "") + ((nd2.bibcodes && nd2.bibcodes.length) ? " · " + nd2.bibcodes.join(", ") : "") + (oth2.length ? "\n" + optT("other estimates") + ": " + oth2.join("; ") : "") +
             "\n" + this._nebulaMethodText(st);
      head += (ob.alias ? "  ·  " + ob.alias : "");
   } else {
      var d = st.result.deepSky.objects[ob.ref];
      if (d.dist.kind === "redshift" && d.redshift) {
         distFirst = false;
         // LAS DOS CIFRAS de lo lejano (decision de Nino): cuando salio su luz y a que distancia esta hoy.
         bits.push("z = " + cpSvDec(d.redshift.z.toFixed((d.redshift.z < 0.1) ? 4 : 2)));
         bits.push(format(optT("its light left %s ago"), cpSvFormatYears(d.redshift.lookbackYr, this._words())));
         bits.push(format(optT("today it is at %s"), this._dist(d.redshift.comovingPc)));
         full = String(d.redshift.ref || "").replace(/(=\s*\d+)\.(\d+)/g, function(mm, a, b) { return a + cpSvDecSep() + b; });      // (1-nov, D5: «H0 = 67,4 … Omega_m = 0,315» en castellano; solo lo que sigue a «=»: «arXiv 1807.06209» se queda)
      } else {
         bits.push(this._dist(d.dist.pc) + this._interval(d.dist));
         bits.push(this._sourceText(d.dist) + (d.dist.n > 1 ? " (" + d.dist.n + ")" : ""));
         if (d.redshift && d.redshift.quality === "good") bits.push(format(optT("its light left %s ago"), cpSvFormatYears(d.redshift.lookbackYr, this._words())));
         full = String(d.dist.ref || "") + ((d.dist.methods && d.dist.methods.length) ? " · " + d.dist.methods.join(", ") : "");
         // las OTRAS medidas (cuando la que se enseña es la paralaje mas reciente, las demas no se esconden)
         if (d.dist.kind === "parallax" && d.measures && d.measures.length > 1) {
            var oth = [];
            for (var mi = 0; mi < d.measures.length; ++mi) if (!d.measures[mi].modelled && !(d.measures[mi].pc === d.dist.pc && d.measures[mi].bibcode === d.dist.bibcode)) oth.push(this._dist(d.measures[mi].pc) + (d.measures[mi].method ? " (" + d.measures[mi].method + ")" : ""));
            if (oth.length > 0) { bits.push(format(optT("%d other measurements"), oth.length)); full += "\n" + optT("other measurements") + ": " + oth.join(", "); }
         }
      }
      if (ob.suspect) bits.push("⚠ " + optT("redshift too small to be a distance"));
      // (24-oct-2026, D1 = A' de Nino) lo que se pinta porque pasa la vara por poco: la palabra «debil» con su S/R
      if (ob.faint > 0) bits.push(format(optT("faint · barely visible: S/N %s; zoom in to see it"), cpSvDec(ob.faint.toFixed(1))));
      // (sin tamaño en el catalogo no se inventa uno: el objeto se queda en su simbolo, y se dice)
      if (ob.kind !== "quasar" && !(ob.ext > 0) && ob.unseen !== true) bits.push(optT("size not in catalogue"));   // (lo que no se ve lleva ext 0 aunque tenga tamaño)
      // (28-oct-2026, A) el tamaño que no da SIMBAD y se ha tomado de OpenNGC (CabraShared/csh_starfield.js `cshSizeFallback`): se dice de donde sale
      if (ob.ext > 0 && d.sizeSource === "OpenNGC") bits.push(format(optT("size from OpenNGC (%s): SIMBAD has none"), String(d.sizeRef || "")));
      head += "  ·  SIMBAD " + String(d.otype || "");
   }
   // (26-oct-2026) cumulos, nebulosas, galaxias, cuasares: el nombre, enlace a SIMBAD por su identificador (`ob.name` tal cual lo guarda el modelo)
   // (5-nov-2026) las filas: los datos repartidos (`c3CardRowsOf`) y, si el primero es la distancia (todo menos lo que va por desplazamiento al rojo), «A …»
   var data = bits.join("  ·  "), card = { head: head, name: name, data: data, full: head + "\n" + name + "\n" + bits.join(" · ") + (full ? "\n" + full : ""),
               link: (typeof c3LinkOfName === "function") ? c3LinkOfName(ob.name, name) : null };
   var rows = c3CardRowsOf(card);
   if (rows.length > 1 && distFirst) { rows = rows.slice(0); rows[0] = format(optT("At %s"), rows[0]); card.rows = rows; card.rowsOf = data; card.rowsText = true; }
   return card;
};

// ---------------------------------------------------------------------------
// LAS DISTANCIAS
// ---------------------------------------------------------------------------
// LA BARRA DE ZOOM (R24). Lo que marca: en perspectiva, el travelin (`distZoom`, el de la rueda); de lado, los aumentos del corte.
CPStarfieldDock.prototype._zoomRange = function() {
   return (this.pose === "side") ? { lo: 1, hi: CP_SV.SIDE_ZOOM_MAX, zoom: this.sideZoom } : { lo: CP_SV.DIST_ZOOM_MIN, hi: CP_SV.DIST_ZOOM_MAX, zoom: this.distZoom };
};
// La barra, al valor que tenga AHORA el zoom (lo haya movido quien lo haya movido: la rueda, el doble clic, un vuelo).
CPStarfieldDock.prototype._zoomSync = function() {
   if (!this.zoomSlider) return;
   var r = this._zoomRange(), v = cpSvZoomToSlider(r.zoom, r.lo, r.hi, CP_SV.ZOOM_STEPS);
   this._zoomSyncing = true;
   try { if (this.zoomSlider.value !== v) this.zoomSlider.value = v; } catch (e) {}
   this._zoomSyncing = false;
};
// La barra movida por el usuario: el mismo zoom que la rueda, hacia el centro del dibujo.
CPStarfieldDock.prototype.setZoomSlider = function(value) {
   if (this.mode !== "dist" || this.state === null || !this.lay || this.lay.kind !== "dist" || this.flightBusy()) return false;
   this._animStop();
   var r = this._zoomRange(), z = cpSvSliderToZoom(value, r.lo, r.hi, CP_SV.ZOOM_STEPS), fit = this.lay.fit;
   if (this.pose === "side") {
      // (la barra amplia HACIA DONDE ESTAN LAS COSAS: el objeto elegido o, sin ninguno, la mediana de los pintados; y la
      // ventana nunca queda vacia habiendo objetos. `cpSvSideZoomTo`. Con el borde cercano quieto —la vuelta 2— a 4 aumentos
      // el corte era un tramo casi vacio: visto en la captura.)
      var a = this._sideAnchor(), w = cpSvSideZoomTo(fit.win, z, a.anchor, a.ts);
      this.sideZoom = w.zoom; this.sideCentre = w.centre;
   } else {
      if (Math.abs(z / fit.zoom - 1) < 1e-9) return false;
      this._setDistView(cpSvDistZoomAt(fit, z / fit.zoom, fit.rect.x + fit.rect.w / 2, fit.rect.y + fit.rect.h / 2));
   }
   this._render();
   return true;
};
// El ancla de la barra en el corte: { anchor (el fondo, 0…1, del objeto elegido o la mediana de los pintados), ts (los de todos) }.
CPStarfieldDock.prototype._sideAnchor = function() {
   var md = this.lay.model, scl = this.lay.scale, ts = [], pick = this.selObj, i;
   if (pick < 0 && this.selStar >= 0 && Object.prototype.hasOwnProperty.call(md.objOfStar, this.selStar)) pick = md.objOfStar[this.selStar];
   for (i = 0; i < md.objects.length; ++i) if (!md.objects[i].suspect) ts.push(Math.max(0, Math.min(1, scl.t(md.objects[i].pc))));
   return { anchor: (pick >= 0 && md.objects[pick]) ? Math.max(0, Math.min(1, scl.t(md.objects[pick].pc))) : cpSvMedian(ts), ts: ts };
};
// EL ENCUADRE AUTOMATICO DE LA POSE DE FABRICA (21-oct, Nino: «el 3D se dibuja pequeño en medio de un lienzo alto, con mucho hueco arriba y
// abajo»). La caja ya se encaja ENTERA en el rectangulo de dibujo, pero la pose de fabrica (giro 55°, inclinacion 13°) da una caja de
// aspecto fijo, y en un lienzo alto —el panel al 35 %— solo llena el ancho. Mientras el usuario NO haya girado ni acercado la camara,
// el giro y la inclinacion se eligen entre los de abajo para que el aspecto de la caja proyectada case con el del rectangulo (que cubra
// el ancho Y el alto), y de entre las que lo consiguen, la que MEJOR ENSEÑA LA FOTO (la hoja de la foto se ve con cos(giro)·cos(inclinacion);
// subir la inclinacion para llenar el alto la dejaba oblicua y casi irreconocible). En cuanto el usuario gira,
// acerca o desplaza, la pose es suya y no se toca; doble clic = vuelta a la de fabrica (y al encuadre automatico).
// LOS ROTULOS DE ZONA de la caja («US · THE PHOTO», «LOCAL GROUP»…; 21-oct, Nino: casi se tocaban con la pose automatica): entre las cajas de
// dos rotulos queda SIEMPRE un hueco de GAP pixeles de interfaz (>= 1,5 veces el espaciado de las versalitas). Si no cabe donde toca, se
// DESLIZA por su arista, luego se apila un escalon mas arriba, y si no hay sitio limpio no se pinta: su nombre pasa al tooltip del pie.
// `OLD` = la colocacion de antes (hueco de 12 px solo en horizontal, escalon de un renglon), para el rojo de las pruebas.
// (28-oct-2026, H1: a lienzo 756, con la máquina del tiempo abierta y el instante en −51 300 años, el rótulo de franja «ESTRELLAS DE LA VÍA LÁCTEA» no
//  encontraba sitio limpio y desaparecía —medido: `lay.bandsDropped`—; Nino lo vio como «OTROS · LA FOTO» (el de al lado, «NOSOTROS · LA FOTO», sí salía). Lo que
//  estorba es el rótulo de la máquina del tiempo, no las estrellas. Decidido el 28-oct (variante B): si no cabe en su sitio, se busca MÁS LEJOS —se desliza por la
//  arista hasta 2,5 anchos fuera de su tramo y sube hasta 6 escalones— y, si el nombre entero no cabe, se usa su forma CORTA («VÍA LÁCTEA» / «MILKY WAY»): antes
//  la corta en su sitio, luego la corta lejos, luego la larga lejos. `NOFAR` = lo de antes (rojo de tests/c3_clock_panel.js P3d).)
var C3_LABELS = { GAP: 12, OLD: false, NOFAR: false };
// La forma CORTA de un rótulo de franja: «ESTRELLAS DE LA VÍA LÁCTEA» → «VÍA LÁCTEA».
function bandShortLabel(key) { return (key === "milky-way") ? optT("MILKY WAY") : ""; }
var C3_AUTOPOSE = { YAW_MIN: 35, YAW_MAX: 75, PITCH_MIN: 5, PITCH_MAX: 40, STEP_YAW: 5, STEP_PITCH: 2.5, TOL: 0.02, GOOD: 0.92 };
// Cuanto cubre la caja proyectada del rectangulo, de 0 a 1 (el cociente de los dos aspectos: 1 = el aspecto de la caja casa con el del
// rectangulo y llena ancho y alto). Devuelve tambien las fracciones del ancho y del alto del rectangulo que ocupa la caja encajada.
function c3BoxCover(model, rect, yaw, pitch) {
   var unit = cpSvDistCam(model, { x: 0, y: 0, w: 1, h: 1 }, { yaw: yaw, pitch: pitch, zoom: 1, f0: 1, cx: 0, cy: 0 });
   var x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
   for (var a = 0; a < 8; ++a) {
      var q = unit.px((a & 1) ? model.wn / 2 : -model.wn / 2, (a & 2) ? model.hn / 2 : -model.hn / 2, (a & 4) ? 1 : 0);
      if (q.x < x0) x0 = q.x; if (q.x > x1) x1 = q.x; if (q.y < y0) y0 = q.y; if (q.y > y1) y1 = q.y;
   }
   var bw = x1 - x0, bh = y1 - y0, f0 = Math.min(rect.w / bw, rect.h / bh), fw = f0 * bw / rect.w, fh = f0 * bh / rect.h;
   return { fw: fw, fh: fh, cover: Math.min(fw, fh) };
}
var C3_AUTOPOSE_CACHE = { key: "", pose: null };
function c3AutoPose(model, rect) {
   var key = [model.wn.toFixed(4), model.hn.toFixed(4), Math.round(rect.w), Math.round(rect.h)].join("|");
   if (C3_AUTOPOSE_CACHE.key === key) return C3_AUTOPOSE_CACHE.pose;
   var A = C3_AUTOPOSE, list = [], best = 0, y, p, i, k = Math.PI / 180;
   for (y = A.YAW_MIN; y <= A.YAW_MAX + 1e-9; y += A.STEP_YAW)
      for (p = A.PITCH_MIN; p <= A.PITCH_MAX + 1e-9; p += A.STEP_PITCH) {
         var c = c3BoxCover(model, rect, y, p).cover;
         list.push({ yaw: y, pitch: p, cover: c, vis: Math.cos(y * k) * Math.cos(p * k) });
         if (c > best) best = c;
      }
   // (basta con «bien»: lo mejor menos una tolerancia, y como mucho GOOD; de las que llegan, la que mas enseña la foto)
   var need = Math.min(best - A.TOL, A.GOOD), pick = null;
   for (i = 0; i < list.length; ++i) if (list[i].cover >= need && (pick === null || list[i].vis > pick.vis)) pick = list[i];
   // (la de fabrica gana si ya llega: no se mueve nada sin motivo)
   var f = c3BoxCover(model, rect, CP_SV.YAW, CP_SV.PITCH).cover;
   var out = (f >= need) ? { yaw: CP_SV.YAW, pitch: CP_SV.PITCH, cover: f } : { yaw: pick.yaw, pitch: pick.pitch, cover: pick.cover };
   C3_AUTOPOSE_CACHE.key = key; C3_AUTOPOSE_CACHE.pose = out;
   return out;
}
// ¿esta la camara «de fabrica» (ni girada, ni con zoom, ni desplazada)? Solo entonces se encuadra sola: su giro y su inclinacion son los
// de fabrica o los que puso el propio encuadre automatico la ultima vez (`_autoYaw`, `_autoPitch`); cualquier otra pose es del usuario
// (arrastrar, una vista guardada, un vuelo, las preferencias) y no se toca.
CPStarfieldDock.prototype._poseIsAuto = function() {
   if (C3_AUTOFRAME === false || !(Math.abs(this.distZoom - 1) < 1e-9) || this.distOx !== 0 || this.distOy !== 0 || this.distOz !== 0) return false;
   return (this.yaw === CP_SFUI_FACTORY.yaw && this.pitch === CP_SFUI_FACTORY.pitch) || (this.yaw === this._autoYaw && this.pitch === this._autoPitch);
};
var C3_AUTOFRAME = true;      // (la prueba lo apaga para medir el encuadre de ANTES)
// (24-oct-2026, decision D1 = A' de Nino) lo «debil» —lo lejano con S/R medida entre CSH_DEPTH.SNR_VIS y SNR_CLEAR, `ob.faint` del modelo— se
// pinta con el anillo y el punto a esta fraccion de su brillo (lo que no se ve, con el interruptor, va a 0,4 y hueco: se distingue). 1 = sin marca.
var C3_FAINT_DIM = 0.55;
// (26-oct-2026, decision «b» de Nino: «el 55 % casi no se nota») lo debil YA NO baja el brillo: su ANILLO va en trazo DISCONTINUO (a trozos), con el
// brillo de lo claro. C3_FAINT_STYLE: "dash" (de fabrica) · "dim" (el 55 % de antes; solo para las capturas «antes» y las pruebas) · "solid" (sin marca:
// lo debil igual que lo claro; el rojo de las pruebas). Donde no hay anillo —el punto de una estrella o de una galaxia en el 3D, el rombo de un cuasar— se
// DIBUJA uno, un poco por fuera del simbolo (la marca tiene que verse tambien alli); el del grupo y el de la elegida son los que ya habia, a trozos.
var C3_FAINT_STYLE = "dash";
var C3_FAINT_DASH = { DUTY: 0.5, PERIOD: 6, N_MIN: 6, N_MAX: 48, GAP: 2.6, STEP: 2.5 };      // fraccion de cada tramo que se pinta · largo de un tramo (× ancho de pluma) · trazos minimo y maximo · luz entre simbolo y anillo (× escala) · largo de un segmento de arco (px)
function c3IsFaint(ob) { return !!(ob && ob.faint > 0 && ob.unseen !== true); }
function c3IsFaintStar(star) { return !!(star && typeof cshDepthStarFaintSnr === "function" && cshDepthStarFaintSnr(star) !== null); }
function c3FaintK(ob) { return (C3_FAINT_STYLE === "dim" && c3IsFaint(ob)) ? C3_FAINT_DIM : 1; }
function c3FaintDash(ob) { return C3_FAINT_STYLE === "dash" && c3IsFaint(ob); }
// (26-oct-2026, A'b) lo mismo para una estrella de `result.stars` (la foto la marca sin pasar por el modelo): su S/R medida entre SNR_VIS y SNR_CLEAR
function c3FaintKStar(star) { return (C3_FAINT_STYLE === "dim" && c3IsFaintStar(star)) ? C3_FAINT_DIM : 1; }
function c3FaintDashStar(star) { return C3_FAINT_STYLE === "dash" && c3IsFaintStar(star); }
// Cuantos trazos lleva un anillo de radio `r` (px) con pluma de ancho `lw`: uno cada ~PERIOD anchos de pluma, entre N_MIN y N_MAX. Un anillo de 4 px lleva
// 6 (trazo y hueco de ~2 px: se lee como «a trozos», no como un borron); uno de 60 px, 48 (si no, los trazos serian largos como lineas rectas).
function c3DashCount(r, lw) {
   var n = Math.round(2 * Math.PI * r / (C3_FAINT_DASH.PERIOD * Math.max(1, lw)));
   return Math.max(C3_FAINT_DASH.N_MIN, Math.min(C3_FAINT_DASH.N_MAX, n));
}
// Una pluma lisa de extremos planos (el trazo acaba donde acaba, sin pasarse medio ancho de pluma: con la tapa cuadrada del defecto el hueco de un anillo
// pequeño se comia un tercio). `argb` = 0xAARRGGBB.
function c3FlatPen(argb, lw) {
   try { if (typeof PenCap_Flat !== "undefined" && typeof PenStyle_Solid !== "undefined") return new Pen(argb, lw, PenStyle_Solid, PenCap_Flat); } catch (e) {}
   return new Pen(argb, lw);
}
// Un anillo a trozos: `n` trazos iguales (la pluma ya puesta en `g.pen`), el primero centrado ARRIBA (simetrico), cada uno la fraccion DUTY de su tramo.
// Cada trazo es una linea, o una poligonal de varios segmentos de ~STEP px si el arco se nota (un anillo grande). `lw` solo da el numero de trazos (o `nForce`: los trazos que se piden, para que el aro exterior de la elegida lleve los mismos que el interior y casen en radio).
var C3_FAINT_LOG = null;      // (las pruebas: un array; cada anillo a trozos que se pinta deja aqui { x, y, r, lw, n })
function c3DashCircle(g, x, y, r, lw, nForce) {
   var n = (nForce > 0) ? nForce : c3DashCount(r, lw), step = 2 * Math.PI / n, span = step * C3_FAINT_DASH.DUTY, a0 = -Math.PI / 2 - span / 2, m = Math.max(1, Math.ceil(r * span / C3_FAINT_DASH.STEP)), i, j, pts;
   if (C3_FAINT_LOG) C3_FAINT_LOG.push({ x: x, y: y, r: r, lw: lw, n: n });
   for (i = 0; i < n; ++i) {
      var s = a0 + i * step;
      if (m === 1) { g.drawLine(x + r * Math.cos(s), y + r * Math.sin(s), x + r * Math.cos(s + span), y + r * Math.sin(s + span)); continue; }
      pts = [];
      for (j = 0; j <= m; ++j) { var a = s + span * j / m; pts.push(new Point(x + r * Math.cos(a), y + r * Math.sin(a))); }
      g.drawPolyline(pts);
   }
}
// La pluma plana de un color, guardada (un 3D de miles de debiles no crea miles): clave = color + ancho.
CPStarfieldDock.prototype._c3FlatPen = function(argb, lw) {
   var key = argb + "|" + lw, c = this._c3FlatPens || (this._c3FlatPens = {});
   if (!c[key]) { if (this._c3FlatPensN > 300) { c = this._c3FlatPens = {}; this._c3FlatPensN = 0; } c[key] = c3FlatPen(argb, lw); this._c3FlatPensN = (this._c3FlatPensN || 0) + 1; }
   return c[key];
};
// El anillo de lo debil alrededor de un simbolo de radio `r` (px): un poco por fuera (GAP × escala), del color y la opacidad que lleva el simbolo (`argb`).
CPStarfieldDock.prototype._c3FaintRing = function(g, x, y, r, argb, sc) {
   var lw = Math.max(1, sc);
   g.pen = this._c3FlatPen(argb >>> 0, lw);
   c3DashCircle(g, x, y, Math.max(r + C3_FAINT_DASH.GAP * sc, 3.6 * sc), lw);
   if (C3_FAINT_LOG) C3_FAINT_LOG[C3_FAINT_LOG.length - 1].add = true;      // (un anillo AÑADIDO a un simbolo que sin el no lo lleva: el de un punto, una galaxia, un rombo)
};
CPStarfieldDock.prototype._distView = function() {
   return { yaw: this.yaw, pitch: this.pitch, zoom: this.distZoom, ox: this.distOx, oy: this.distOy, oz: this.distOz };
};
CPStarfieldDock.prototype._setDistView = function(v) {
   this.yaw = v.yaw; this.pitch = v.pitch; this.distZoom = v.zoom; this.distOx = v.ox; this.distOy = v.oy; this.distOz = v.oz;
};
// EL SIMBOLO de una nebulosa (planetaria o no) y de lo demas de nuestra galaxia que no es estrella ni cumulo: un
// circulo hueco con cuatro marcas hacia fuera (el de las cartas celestes para una planetaria). Distinto, a proposito,
// del disco relleno de una galaxia: hasta el 13-oct-2026 compartian casi el mismo y no se distinguian.
function cpSfUiNebula(g, x, y, r, col, penW) {
   g.pen = new Pen(col, penW); g.brush = new Brush(0x00000000);
   g.drawCircle(x, y, r);
   g.drawLine(x - 1.9 * r, y, x - r, y); g.drawLine(x + r, y, x + 1.9 * r, y); g.drawLine(x, y - 1.9 * r, x, y - r); g.drawLine(x, y + r, x, y + 1.9 * r);
}
// Un color de dato apagado hacia el fondo (lo lejano; o un punto a medio aparecer). k = 1: el suyo.
function cpSfUiDim(rgb, k, bg) {
   if (k >= 0.999) return rgb;
   var q = 1 - k;
   return (Math.round(((rgb >> 16) & 255) * k + bg[0] * q) << 16) | (Math.round(((rgb >> 8) & 255) * k + bg[1] * q) << 8) | Math.round((rgb & 255) * k + bg[2] * q);
}

// LA FOTO, EN PERSPECTIVA: troceada en una malla, cada celda con su afin (`Graphics` no da mas).
// SIN suavizar los bordes de las celdas y con 1 px de solape: asi no queda costura (medido: 0
// pixeles; con suavizado y sin solape, 5 049). Vista por detras se pinta APAGADA (es el reverso), con una
// copia ya apagada de la foto y NO con `opacity`: con opacidad, el pixel de solape entre celdas se pinta dos
// veces y sale una rejilla clara sobre la foto (visto en la captura de la orbita, con la camara dentro).
// Devuelve la malla (sus cuatro esquinas sirven para el marco y para no tapar la foto con una placa).
CPStarfieldDock.prototype._photoBack = function(st) {
   if (!st.photo) return null;
   if (!st.photoBack) {
      var b = new Bitmap(st.photo.width, st.photo.height);
      b.fill(CP_INT_SURFACE);                                // (antes de abrir el Graphics: con uno abierto, Bitmap.fill lanza)
      var g = new Graphics(b);
      try { g.opacity = 0.5; g.drawBitmap(0, 0, st.photo); } finally { g.end(); }
      st.photoBack = b;
   }
   return st.photoBack;
};
CPStarfieldDock.prototype._drawPhotoMesh = function(g, fit, photo, clip) {
   var mesh = cpSvPhotoMeshFine(fit, clip);
   if (photo && mesh.cells.length > 0) this._drawMesh(g, mesh, mesh.front ? photo : (this._photoBack(this.state) || photo));
   else if (!photo && mesh.quad) {
      g.pen = new Pen(0x00000000, 0); g.brush = new Brush(CP_INT_BG);
      g.fillPolygon([new Point(Math.round(mesh.quad[0].x), Math.round(mesh.quad[0].y)), new Point(Math.round(mesh.quad[1].x), Math.round(mesh.quad[1].y)),
                     new Point(Math.round(mesh.quad[2].x), Math.round(mesh.quad[2].y)), new Point(Math.round(mesh.quad[3].x), Math.round(mesh.quad[3].y))]);
   }
   return mesh;
};
// Las celdas de una malla, cada una con su afin, SOLAPADAS con sus vecinas (asi no queda rendija). Solo vale para un
// bitmap OPACO: translucido, lo solapado se pinta dos veces (por eso los recortes no van por aqui: `_drawCutout`).
CPStarfieldDock.prototype._drawMesh = function(g, mesh, photo) {
   var W = photo.width, H = photo.height;
   {
      {
      g.antialiasing = false;
      g.smoothInterpolation = true;
      for (var i = 0; i < mesh.cells.length; ++i) {
         var c = mesh.cells[i], sx0 = Math.floor(c[0] * W), sy0 = Math.floor(c[1] * H);
         // la afin de la celda, por pixel de la foto
         var cw = (c[2] - c[0]) * W, ch = (c[3] - c[1]) * H;
         var ax = (c[6] - c[4]) / cw, ay = (c[7] - c[5]) / cw, bx = (c[8] - c[4]) / ch, by = (c[9] - c[5]) / ch, qr = cpSvAffineQr(ax, ay, bx, by);
         if (qr === null) continue;
         // el solape, por los CUATRO lados: lo que la afin se equivoca con la cuarta esquina mas el sello (en pixeles de
         // pantalla, pasados a pixeles de la foto), y nunca menos que CP_SFUI_MESH_GROW pixeles de la foto
         var mx = c[6] + c[8] - c[4] - c[10], my = c[7] + c[9] - c[5] - c[11], seal = (CP_SFUI_MESH_SEAL > 0) ? Math.sqrt(mx * mx + my * my) + CP_SFUI_MESH_SEAL : 0;
         var ox = Math.max(CP_SFUI_MESH_GROW, (seal > 0) ? Math.min(cw, Math.ceil(seal / Math.max(1e-6, Math.sqrt(ax * ax + ay * ay)))) : 0), oy = Math.max(CP_SFUI_MESH_GROW, (seal > 0) ? Math.min(ch, Math.ceil(seal / Math.max(1e-6, Math.sqrt(bx * bx + by * by)))) : 0);
         sx0 = Math.max(0, sx0 - ox); sy0 = Math.max(0, sy0 - oy);
         var sx1 = Math.min(W, Math.ceil(c[2] * W) + ox), sy1 = Math.min(H, Math.ceil(c[3] * H) + oy);
         if (sx1 <= sx0 || sy1 <= sy0) continue;
         var ex = sx0 - c[0] * W, ey = sy0 - c[1] * H;       // la celda empieza en un pixel entero: lo que eso la corre
         g.resetTransformation();
         g.translateTransformation(c[4] + ex * ax + ey * bx, c[5] + ex * ay + ey * by);
         g.rotateTransformation(-qr.rot);
         g.shearTransformation(qr.shear, 0);
         g.scaleTransformation(qr.sx, qr.sy);
         g.drawBitmapRect(new Point(0, 0), photo, new Rect(sx0, sy0, sx1, sy1));
      }
      g.resetTransformation();
      g.antialiasing = true;
      }
   }
};

// Una capa TRANSPARENTE del tamaño que se pida (se reutiliza): para pintar con opacidad lo que no se puede pintar a trozos.
CPStarfieldDock.prototype._layerOf = function(w, h) {
   if (!this._layer || this._layer.width !== w || this._layer.height !== h) { cpSfUiFree(this._layer); this._layer = new Bitmap(w, h); }
   this._layer.fill(0x00000000);
   return this._layer;
};

// LOS RECORTES DE LOS OBJETOS EXTENSOS (13-oct-2026). El trozo de la foto de un objeto, con el borde desvanecido (una
// mascara radial: sin sello cuadrado ni borde duro), en dos versiones: por delante y por detras (apagada, como la foto).
// Sale de `st.photoFull` (la mejor copia del visor que se guardo al abrir) y se guarda por objeto: se hace UNA vez.
CPStarfieldDock.prototype._freeFull = function(st) {
   if (!st) return;
   try { if (st.photoFull) st.photoFull.clear(); } catch (e) {}
   st.photoFull = null;
   for (var q = 1; st.pyr && q < st.pyr.length; ++q) cpSfUiFree(st.pyr[q]);      // (el nivel 0 es la propia foto grande)
   st.pyr = null;
};
CPStarfieldDock.prototype._freeCuts = function(st) {
   this._freeFull(st);
   this._psFree(st);
   var sets = [st.cuts || {}, st.cutsHi || {}];
   for (var s2 = 0; s2 < sets.length; ++s2)
      for (var k in sets[s2]) if (Object.prototype.hasOwnProperty.call(sets[s2], k)) { var c = sets[s2][k]; cpSfUiFree(c.front); cpSfUiFree(c.hole); cpSfUiFree(c.shade); }
   st.cuts = {}; st.cutsHi = {};
   if (st.starless) { cpSfUiFree(st.starless.bmp); st.starless = null; }      // (la foto sin estrellas de las nebulosas: se rehace al volver)
};
// LA FOTO A LA RESOLUCION DE LA IMAGEN (14-oct-2026, vuelta 3; Q5). Hasta aqui la foto y los recortes salian de la copia
// que tiene EL VISOR (un tercio de la imagen, o menos): en un video, de cerca, se veian a bloques (M 13: 300 × 300).
// Ahora la copia grande se saca DE LA IMAGEN, con el MISMO render que usa el visor (`optRenderPreviewBitmap` con el
// estirado de pantalla de esa imagen: `stretchModeForRec`), a reduccion 1 mientras el lado mayor no pase de IMAGE_MAX
// (6 144 px: 151 MB en el peor caso; una de 5 693 × 3 705 son 84 MB y 0,4 s, medido en `_tests/cp_flight_hires_probe.log`).
// Se hace al ABRIR (nunca en `onPaint` ni en un tic) y solo la imagen que se enseña la guarda: al cerrar el panel o
// pasar a otra imagen se libera. Si no se puede (el visor enseña un mosaico, o falla), la mejor copia del visor.
CPStarfieldDock.prototype._renderFull = function(rec) {
   this.fullInfo = { ms: 0, reduction: 0, w: 0, h: 0, from: "viewer" };
   try {
      if (CP_SFUI_IMAGE_RES === true && rec && optSafeView(rec.view) && !this.dialog.preview.grid) {
         var im = rec.view.image, n = Math.max(1, Math.ceil(Math.max(im.width, im.height) / CP_SFUI_IMG.IMAGE_MAX)), t0 = Date.now();
         var b = optRenderPreviewBitmap(rec.view, n, this.dialog.stretchModeForRec(rec));
         if (b && b.width >= 2 && b.height >= 2) { this.fullInfo = { ms: Date.now() - t0, reduction: n, w: b.width, h: b.height, from: "image" }; return b; }
      }
   } catch (e) {}
   var v = this._grabPhoto(CP_SFUI.FULL_MAX);
   if (v) { this.fullInfo.w = v.width; this.fullInfo.h = v.height; }
   return v;
};
// LA FOTO, A VARIOS TAMAÑOS (para un vuelo): la grande, su mitad, su cuarto… hasta PYR_MIN de lado. Cada fotograma se
// pinta con el menor que da para lo que la foto mide en pantalla: reducir la grande tres veces con interpolacion
// bilineal en cada fotograma hace chispear las estrellas, y cuesta mas. Se hace una vez (al empezar el vuelo).
CPStarfieldDock.prototype._photoPyramid = function(st) {
   if (!st || !st.photoFull) return st && st.photo ? [st.photo] : [];
   if (st.pyr && st.pyr[0] === st.photoFull) return st.pyr;
   var list = [st.photoFull], cur = st.photoFull;
   while (Math.max(cur.width, cur.height) / 2 >= CP_SFUI_IMG.PYR_MIN && list.length < 5) {
      var w = Math.max(2, Math.round(cur.width / 2)), h = Math.max(2, Math.round(cur.height / 2)), nb = new Bitmap(w, h), g = new Graphics(nb);
      try { g.smoothInterpolation = true; g.drawScaledBitmap(new Rect(0, 0, w, h), cur); } finally { g.end(); }
      list.push(nb); cur = nb;
   }
   st.pyr = list;
   return list;
};
// EL RECORTE DE UN OBJETO. Sale de `st.photoFull` (la foto a la resolucion de la imagen) y se guarda por objeto: se hace
// UNA vez. `hi` = el de un VIDEO: a la resolucion de la imagen, hasta CUT_HI de lado (el del panel, hasta CUT_MAX por la
// escala de la interfaz); si el de video ya esta hecho, el panel tambien lo usa. Un objeto de cuatro pixeles se AMPLIA
// con interpolacion suave antes de hacerle la mascara (hasta CUT_SMALL de lado, CUT_UP veces como mucho): la mascara
// hecha sobre 20 pixeles salia a dientes.
// Devuelve { front (EL OBJETO, SU LUZ: opaco, negro donde no hay objeto; se pinta SUMANDO —`CompositionOp_Screen`—, asi
// el borde translucido no puede oscurecer lo que tiene detras ni dejar un aro «de pegatina», que es lo que hacia el color
// de fondo de la escena con transparencia encima de la foto), hole (EL HUECO que el objeto deja en la foto al
// salir de ella: un mapa que, MULTIPLICANDO, le resta a la foto la luz del objeto), shade (lo brillante del objeto, del color
// de la escena y a media resolucion: va debajo de su luz y tapa lo que tiene detras), screen (false = una foto
// de un solo color: el disco de foto de antes, con transparencia), u0…v1 (su sitio exacto), shine { u0, v0, u1, v1, px
// (lo que mide lo que brilla en pixeles de la IMAGEN, el lado menor) }, matte { … } }.
CPStarfieldDock.prototype._cutOf = function(st, model, cut, hi) {
   if (model.objects[cut.index] && model.objects[cut.index].kind === "nebula") return this._nebulaCutOf(st, model, cut, hi);      // (su huella entera, sin estrellas: ui/starfield_nebula.js)
   var ob = model.objects[cut.index], key = ob.kind + ":" + ob.ref, src = st.photoFull || st.photo;
   if (!st.cutsHi) st.cutsHi = {};
   if (st.cutsHi[key]) return st.cutsHi[key];
   if (hi !== true && st.cuts[key]) return st.cuts[key];
   if (!src) return null;
   if (hi !== true && this._cutLater(st)) return null;     // (22-oct: girando, el recorte que falta lo hace el dibujo entero al soltar)
   var W = src.width, H = src.height, wn = model.wn, hn = model.hn;
   var x0 = Math.max(0, Math.floor((cut.u0 / wn + 0.5) * W)), x1 = Math.min(W, Math.ceil((cut.u1 / wn + 0.5) * W)), y0 = Math.max(0, Math.floor((cut.v0 / hn + 0.5) * H)), y1 = Math.min(H, Math.ceil((cut.v1 / hn + 0.5) * H));
   if (x1 - x0 < 2 || y1 - y0 < 2) return null;
   var side = Math.max(x1 - x0, y1 - y0), lim = (hi === true) ? CP_SFUI_IMG.CUT_HI : cpPx(CP_SFUI.CUT_MAX, this.canvas);
   var k = Math.min(lim / side, Math.max(1, Math.min(CP_SFUI_IMG.CUT_UP, CP_SFUI_IMG.CUT_SMALL / side))), w = Math.max(2, Math.round((x1 - x0) * k)), h = Math.max(2, Math.round((y1 - y0) * k));
   var front = new Bitmap(w, h), g = new Graphics(front), t0 = Date.now();
   try { g.smoothInterpolation = true; g.drawScaledBitmapRect(new Rect(0, 0, w, h), src, new Rect(x0, y0, x1, y1)); } finally { g.end(); }
   // (el trozo va de pixel entero a pixel entero: su sitio EXACTO en la foto es el de esos pixeles, no el pedido; con el
   // pedido, el recorte quedaba corrido hasta un pixel respecto a la foto y la mascara descentrada)
   var tu0 = (x0 / W - 0.5) * wn, tu1 = (x1 / W - 0.5) * wn, tv0 = (y0 / H - 0.5) * hn, tv1 = (y1 / H - 0.5) * hn;
   var bg = cpHexRgb(CP_ATLAS.surface), cx = ((ob.u - tu0) / (tu1 - tu0)) * w, cy = ((ob.v - tv0) / (tv1 - tv0)) * h;
   var rx = cut.r / (tu1 - tu0) * w, ry = cut.r / (tv1 - tv0) * h, inner = 1 - CP_SV.CUT_FEATHER, x, y, i, N = w * h;
   var R = new Float32Array(N), G = new Float32Array(N), B = new Float32Array(N), stars = [], M;
   for (y = 0; y < h; ++y)
      for (x = 0; x < w; ++x) { var px = front.pixel(x, y) >>> 0; i = y * w + x; R[i] = (px >>> 16) & 255; G[i] = (px >>> 8) & 255; B[i] = px & 255; }
   if (CP_SFUI_CUT_MATTE === true) {
      for (i = 0; i < model.objects.length; ++i) {
         var so = model.objects[i];
         if ((so.kind !== "star" && so.kind !== "member") || so.u <= tu0 || so.u >= tu1 || so.v <= tv0 || so.v >= tv1) continue;
         if (Math.abs(Math.log(so.pc / ob.pc)) < Math.log(1.25)) continue;                 // a su misma distancia: es suya (la central de una planetaria)
         stars.push({ x: (so.u - tu0) / (tu1 - tu0) * w, y: (so.v - tv0) / (tv1 - tv0) * h, rmax: Math.max(2, 0.012 * Math.max(w, h) * so.size * so.size) });
      }
      M = cpSvCutoutMatte(R, G, B, w, h, { cx: cx, cy: cy, rx: rx, ry: ry, inner: inner }, stars);
   } else {
      // (la mascara de antes: solo la caida radial. La usa el juez de costuras del test 4.5, con una foto de un solo color.)
      M = { a: new Float32Array(N), r: R, g: G, b: B, bg: [0, 0, 0], sigma: [0, 0, 0], removed: 0, flat: true, gain: 1, islands: 0, shine: { x0: 0, y0: 0, x1: w, y1: h } };
      for (y = 0; y < h; ++y)
         for (x = 0; x < w; ++x) { var dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry, rho = Math.sqrt(dx * dx + dy * dy), a = (rho <= inner) ? 1 : (rho >= 1) ? 0 : (1 - rho) / (1 - inner); M.a[y * w + x] = a * a * (3 - 2 * a); }
   }
   var cover = 0, screen = !M.flat, gn = M.flat ? 1 : M.gain, hole = null, shade = null;
   for (y = 0; y < h; ++y)
      for (x = 0; x < w; ++x) {
         i = y * w + x;
         var av = M.a[i];
         cover += av;
         // LA LUZ del objeto (su exceso sobre el fondo, por la ganancia y por su transparencia), sobre negro; o, sin mascara
         // de brillo (una foto de un solo color), el pixel tal cual con su transparencia radial
         if (screen) front.setPixel(x, y, (0xff000000 | (Math.min(255, Math.round(gn * M.r[i] * av)) << 16) | (Math.min(255, Math.round(gn * M.g[i] * av)) << 8) | Math.min(255, Math.round(gn * M.b[i] * av))) >>> 0);
         else front.setPixel(x, y, ((Math.round(255 * av) << 24) | (Math.min(255, Math.round(M.r[i])) << 16) | (Math.min(255, Math.round(M.g[i])) << 8) | Math.min(255, Math.round(M.b[i]))) >>> 0);
      }
   if (screen) {
      // EL HUECO (vuelta 4, a la tercera). El objeto SALE de la foto: en su sitio hay que dejar CIELO. Pintar encima un parche
      // de «cielo» no vale: liso se ve como un disco, y con grano y del color de alrededor sigue siendo una calva sin
      // estrellas, mas clara o mas oscura que lo que la rodea (visto a 1:1 las dos veces: `_tests/cp_starfield_flight_look4`).
      // Lo que se hace es RESTARLE A LA FOTO LA LUZ DEL OBJETO: su exceso sobre el fondo, alisado 3 × 3 y sin las estrellas
      // (recortado a su percentil 99: una estrella no es luz difusa). Queda el cielo que habia debajo, CON SU GRANO Y SUS
      // ESTRELLAS, porque son los de la propia foto. Como `Graphics` no resta, se MULTIPLICA (`CompositionOp_Multiply`): este
      // bitmap lleva, por pixel y canal, 1 − luz / foto, y pintado con opacidad p deja foto × ( 1 − p · luz / foto ) = foto − p · luz.
      // (A la resolucion del recorte: casa pixel a pixel con la foto.)
      var top = [], cap, sm = [new Float32Array(N), new Float32Array(N), new Float32Array(N)], tmp = new Float32Array(N), src3 = [M.r, M.g, M.b], hc, xx, yy;
      for (i = 0; i < N; i += 2) if (M.a[i] > 0.5) top.push(Math.max(M.r[i], M.g[i], M.b[i]));
      // (el tope de lo «difuso»: tres veces la mediana del cuerpo; lo que pasa de ahi es una estrella)
      if (top.length >= 8) { var ts = new Float32Array(top); ts.sort(); cap = 3 * ts[ts.length >> 1]; } else cap = 255;
      // (1) LA LUZ ALISADA 3 × 3, recortada al tope de lo difuso. (EL ORDEN IMPORTA: en dos pasadas de esta vuelta el minimo y la
      // referencia del borde se calculaban ANTES que esto, sobre ceros, y no hacian nada: por eso «nada cambiaba» al mirar.)
      for (hc = 0; hc < 3; ++hc) {
         var e = src3[hc], o2 = sm[hc];
         for (yy = 0; yy < h; ++yy) for (xx = 0; xx < w; ++xx) { i = yy * w + xx; var l = (xx > 0) ? Math.min(cap, e[i - 1]) : Math.min(cap, e[i]), r2 = (xx < w - 1) ? Math.min(cap, e[i + 1]) : Math.min(cap, e[i]); tmp[i] = (l + Math.min(cap, e[i]) + r2) / 3; }
         for (yy = 0; yy < h; ++yy) for (xx = 0; xx < w; ++xx) { i = yy * w + xx; o2[i] = (((yy > 0) ? tmp[i - w] : tmp[i]) + tmp[i] + ((yy < h - 1) ? tmp[i + w] : tmp[i])) / 3; }
      }
      // …y de lo alisado, el MINIMO de alrededor (7 × 7): una estrella que ha quedado en el objeto es un bulto estrecho en esa
      // luz alisada y, restado a sus vecinos —que no lo tienen—, dejaba un cerco MAS OSCURO que el cielo (lunares oscuros en el
      // despegue de NGC 1560, vistos a 1:1). El minimo se come el bulto y deja la luz ancha del objeto. (Restarle a cada pixel
      // «lo suyo» tampoco vale: le aplana el grano.)
      function minPass(a, o3, step, lim) {
         for (var q = 0; q < N; ++q) {
            var pos = (step === 1) ? q % w : Math.floor(q / w), m3 = a[q];
            for (var d3 = 1; d3 <= CP_SFUI_IMG.HOLE_MIN_R; ++d3) { if (pos - d3 >= 0 && a[q - d3 * step] < m3) m3 = a[q - d3 * step]; if (pos + d3 < lim && a[q + d3 * step] < m3) m3 = a[q + d3 * step]; }
            o3[q] = m3;
         }
      }
      // …y se resta SOLO LO QUE PASA DEL BORDE: la mascara empieza donde el objeto ya vale ~1,5 ruidos sobre el fondo; lo de
      // justo fuera se queda con esa luz y, si dentro se quita TODA, el hueco es un punto MAS OSCURO que su borde: una
      // lengua oscura con un cerco claro (visto a 1:1, ampliado ×3, en el despegue de NGC 1560). La referencia: la mediana de
      // la luz alisada en el borde mismo de la mascara (transparencia de EDGE_LO a EDGE_HI).
      // (…medida ANTES de pasar el minimo: el minimo de 7 × 7 baja el nivel justo en el borde, donde la luz cae hacia fuera, y
      // con la referencia medida despues el hueco quedaba 3-4 niveles MAS OSCURO que lo que lo rodea: medido en el fotograma nativo)
      var ref = [0, 0, 0];
      for (hc = 0; hc < 3; ++hc) {
         var ez = [];
         for (i = 0; i < N; i += 2) if (M.a[i] > CP_SFUI_IMG.EDGE_LO && M.a[i] < CP_SFUI_IMG.EDGE_HI) ez.push(sm[hc][i]);
         if (ez.length >= 16) { var es = new Float32Array(ez); es.sort(); ref[hc] = es[es.length >> 1]; }
      }
      for (hc = 0; hc < 3; ++hc) { minPass(sm[hc], tmp, 1, w); minPass(tmp, sm[hc], w, h); }
      hole = new Bitmap(w, h);
      var src0 = [R, G, B];
      for (yy = 0; yy < h; ++yy)
         for (xx = 0; xx < w; ++xx) {
            i = yy * w + xx;
            var col = 0;
            for (hc = 0; hc < 3; ++hc) col = (col << 8) | Math.round(255 * Math.max(0, Math.min(1, 1 - Math.min(1, CP_SFUI_IMG.EDGE_FULL * M.a[i]) * Math.max(0, sm[hc][i] - CP_SFUI_IMG.EDGE_REF * ref[hc]) / Math.max(1, src0[hc][i]))));
            hole.setPixel(xx, yy, (0xff000000 | col) >>> 0);
         }
      // LA SOMBRA: lo BRILLANTE del objeto, del color de la escena, a media resolucion: se pinta debajo de su luz para que tape
      // lo que tiene detras (las lineas de la caja cruzaban la nebulosa). Por lo que brilla ahi: nunca tapa mas que la luz que pone.
      var hw = Math.max(1, w >> 1), hh = Math.max(1, h >> 1), sfc = (bg[0] << 16) | (bg[1] << 8) | bg[2];
      shade = new Bitmap(hw, hh);
      for (y = 0; y < hh; ++y)
         for (x = 0; x < hw; ++x) {
            var i4 = Math.min(h - 1, 2 * y) * w + Math.min(w - 1, 2 * x), lm = gn * M.a[i4] * Math.max(M.r[i4], M.g[i4], M.b[i4]);
            shade.setPixel(x, y, ((Math.round(255 * Math.max(0, Math.min(1, lm / CP_SFUI_IMG.SHADE_LUM))) << 24) | sfc) >>> 0);
         }
   }
   var sh = M.shine, rec = { front: front, back: front, hole: hole, shade: shade, screen: screen, hi: (hi === true), inner: inner, cx: cx / w, cy: cy / h, rx: rx / w, ry: ry / h, u0: tu0, v0: tv0, u1: tu1, v1: tv1,
               shine: { u0: tu0 + sh.x0 / w * (tu1 - tu0), u1: tu0 + sh.x1 / w * (tu1 - tu0), v0: tv0 + sh.y0 / h * (tv1 - tv0), v1: tv0 + sh.y1 / h * (tv1 - tv0), px: Math.min(sh.x1 - sh.x0, sh.y1 - sh.y0) / k },
               matte: { bg: M.bg, sigma: M.sigma, removed: M.removed, kept: M.kept || 0, edge: (typeof ref !== "undefined") ? ref : [0, 0, 0], flat: M.flat, gain: M.gain, stars: stars.length, cover: cover / N, islands: M.islands, w: w, h: h, k: k, ms: Date.now() - t0 } };
   if (hi === true) st.cutsHi[key] = rec; else st.cuts[key] = rec;
   return rec;
};
// Pinta el recorte de un objeto, a su distancia: de UNA pieza, con una afin (`cpSvCutoutAffine` dice por que no
// con la malla de la foto). Devuelve esa afin (sus cuatro esquinas sirven para saber si el raton esta encima), o null.
// MIRA A LA CAMARA (un cartel; `cpSvCutoutFace`) y SE APAGA si llega a llenar el dibujo (la camara no lo atraviesa: un
// recorte a pantalla completa es una mancha desenfocada). `o` = { hi (el de video), alpha (la opacidad de los objetos) }.
// Lo DENTRO que cae (x, y) del cuadrilatero convexo `q` (cuatro puntos { x, y } en orden): la distancia a su borde mas
// cercano, positiva dentro y negativa fuera.
function cpSfUiQuadDepth(q, x, y) {
   var area = 0, i, d = Infinity;
   for (i = 0; i < 4; ++i) { var p0 = q[i], p1 = q[(i + 1) % 4]; area += p0.x * p1.y - p1.x * p0.y; }
   var sg = (area >= 0) ? 1 : -1;
   for (i = 0; i < 4; ++i) {
      var a = q[i], b = q[(i + 1) % 4], len = Math.sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y));
      if (!(len > 0)) continue;
      var c = sg * ((b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x)) / len;
      if (c < d) d = c;
   }
   return (d === Infinity) ? -1e9 : d;
}

CPStarfieldDock.prototype._drawCutout = function(g, st, model, fit, cut, o) {
   var bm = this._cutOf(st, model, cut, !!(o && o.hi === true));
   if (bm === null) return null;
   // Cabra3D (28-oct-2026, B): la nebulosa y lo muy grande, SIN cartel —plano paralelo a la foto— (ui/starfield_nebula.js `c3CutNoFace`)
   var obC = model.objects[cut.index], faceK = (CP_SFUI_CUT_FACE === true) ? cpSvCutoutFace(fit) : 0;
   if (faceK > 0 && typeof c3CutNoFace === "function" && c3CutNoFace(obC)) faceK = 0;
   var A = cpSvCutoutAffine(fit, bm, cut.t, faceK);
   if (A === null) return null;
   var pic = bm.front, kx = (bm.u1 - bm.u0) / pic.width, ky = (bm.v1 - bm.v0) / pic.height;
   var qr = cpSvAffineQr(A.ax * kx, A.ay * kx, A.bx * ky, A.by * ky);
   if (qr === null) return null;
   // (lo que mide LO QUE BRILLA, no el cuadro del recorte: el de una galaxia debil es el triple de lo que se le ve)
   var sr = (bm.shine && bm.screen) ? Math.max(bm.shine.u1 - bm.shine.u0, bm.shine.v1 - bm.shine.v0) / 2 : cut.r;
   var near = Math.max(0, Math.min(1, (A.scale * sr / fit.rect.h - CP_SV.CUT_NEAR0) / (CP_SV.CUT_NEAR1 - CP_SV.CUT_NEAR0))), base = (o && typeof o.alpha === "number") ? o.alpha : 1;
   // (una NEBULOSA es una capa semitransparente: lo que tiene detras se sigue viendo)
   if (model.objects[cut.index] && model.objects[cut.index].kind === "nebula") base *= CP_SV.NEB_ALPHA;
   A.alpha = 1 - near * near * (3 - 2 * near);
   A.px = (bm.shine && bm.shine.px > 0) ? bm.shine.px : 0;
   // Cabra3D (28-oct-2026, A2 y C1): `o.share` = la parte de la luz de una de las laminas de la nebulosa; y la nebulosa SIN hueco, vista
   // desde delante a traves de la foto, apagada como las estrellas de detras (ui/starfield_nebula.js `_c3GlassK`). Solo a esta pintura:
   // la opacidad que se deja al salir sigue siendo `base`, como antes.
   var extra = (o && o.share > 0) ? o.share : 1;
   if (fit.front && obC && obC.kind === "nebula" && this._c3NebNoHole && this._c3NebNoHole(st, obC)) extra *= this._c3GlassK(fit, A, model);
   var al = base * A.alpha * ((fit.front || !bm.screen) ? 1 : 0.5) * extra;
   if (al > 0.004) {
      g.smoothInterpolation = true;
      g.resetTransformation();
      g.translateTransformation(A.x, A.y);
      g.rotateTransformation(-qr.rot);
      g.shearTransformation(qr.shear, 0);
      g.scaleTransformation(qr.sx, qr.sy);
      var shA = (o && typeof o.shade === "number") ? Math.max(0, Math.min(1, o.shade)) : 1;
      g.opacity = al * shA;
      if (bm.screen && bm.shade && CP_SFUI_CUT_SHADE === true && shA > 0.004) {
         // la sombra del nucleo (a media resolucion: dos veces mayor), debajo de la luz
         g.scaleTransformation(pic.width / bm.shade.width, pic.height / bm.shade.height);
         g.drawBitmap(0, 0, bm.shade);
         g.scaleTransformation(bm.shade.width / pic.width, bm.shade.height / pic.height);
      }
      g.opacity = al;
      if (bm.screen) g.compositionOperator = CompositionOp_Screen;
      g.drawBitmap(0, 0, pic);
      g.opacity = base;
      if (bm.screen) g.compositionOperator = CompositionOp_SourceOver;
      g.resetTransformation();
   }
   return A;
};
// EL HUECO DE CADA OBJETO EN LA FOTO (14-oct-2026, vuelta 3; revision visual: «al abrirse la foto se ven DOS planetarias»).
// El objeto SALE de la foto: conforme la caja se abre, su sitio en la foto se apaga hacia el fondo de cielo local (la
// misma mascara de brillo del recorte). `weight` (0…1): cuanto. Tambien el CUMULO cuyas estrellas se pintan una a una
// (no lleva recorte): sus estrellas de la foto se atenuan (HOLE_CLUSTER) mientras los miembros se despegan.
CPStarfieldDock.prototype._drawHoles = function(g, st, model, fit, proj, sc, weight, hi) {
   if (!(weight > 0.01) || CP_SFUI_CUT_HOLES !== true || CP_SFUI_CUTOUTS !== true || fit.mode !== "perspective") return 0;
   var list = cpSvCutouts(model, proj, fit, CP_SV.CUT_MIN_PX * sc, CP_SV.CUT_MAX), n = 0, i;
   for (i = 0; i < model.objects.length; ++i) {
      var oc = model.objects[i];
      if (!(CP_SFUI_IMG.HOLE_CLUSTER > 0) || oc.kind !== "cluster" || !(model.counts.members > 0) || !proj.vis[i]) continue;
      var rc = cpSvCutoutRect({ ext: (oc.ext > 0) ? oc.ext : oc.radius, u: oc.u, v: oc.v }, model.wn, model.hn);
      if (rc !== null) list.push({ index: i, u0: rc.u0, v0: rc.v0, u1: rc.u1, v1: rc.v1, r: rc.r, t: proj.tt[i], rPx: 0, cluster: true });
   }
   for (i = 0; i < list.length; ++i) {
      var obH = model.objects[list[i].index];
      if (obH && this._c3NebNoHole && this._c3NebNoHole(st, obH)) continue;     // Cabra3D (28-oct-2026, C1): la que llena la foto no le hace hueco
      var bm = this._cutOf(st, model, list[i], hi === true);
      if (bm === null || !bm.hole) continue;
      var A = cpSvCutoutAffine(fit, bm, 0, 0);
      if (A === null) continue;
      var pic = bm.hole, kx = (bm.u1 - bm.u0) / pic.width, ky = (bm.v1 - bm.v0) / pic.height, qr = cpSvAffineQr(A.ax * kx, A.ay * kx, A.bx * ky, A.by * ky);
      if (qr === null) continue;
      g.smoothInterpolation = true;
      g.resetTransformation();
      g.translateTransformation(A.x, A.y);
      g.rotateTransformation(-qr.rot);
      g.shearTransformation(qr.shear, 0);
      g.scaleTransformation(qr.sx, qr.sy);
      // (MULTIPLICANDO: la foto pierde ahi la luz del objeto y se queda con su cielo. Ver `_cutOf`.)
      if (CP_SFUI_HOLE_MULTIPLY === true) g.compositionOperator = CompositionOp_Multiply;
      g.opacity = weight * (list[i].cluster ? CP_SFUI_IMG.HOLE_CLUSTER : 1);
      g.drawBitmap(0, 0, pic);
      g.opacity = 1;
      g.compositionOperator = CompositionOp_SourceOver;
      g.resetTransformation();
      ++n;
   }
   return n;
};

// LA CAJA EN 3D: la foto, los marcos y los objetos, vistos por la camara `fit`. Lo usa el dibujo
// de «Distances» y cada fotograma de una transicion que mueve la camara (por eso no mira `this.yaw`
// ni nada de la vista: todo le llega en `fit` y `proj`). `o.part` = "back" (la foto y los marcos),
// "objects" (los objetos) o nada (todo). Devuelve { mesh (si pinto la foto), drawn }.
// PARA EL VUELO (ui/starfield_flight_paint.js; 14-oct-2026): `o.photoAlpha` y `o.boxAlpha` (0…1: lo que se ven la foto y
// los marcos; la foto a medias va en una capa aparte, porque troceada en malla y con opacidad sale una rejilla: R22),
// `o.photo` (otra copia de la foto: la grande, para un video) y `o.alpha` (los objetos).
var C3_GLASS_STARS = 0.35;            // Cabra3D (tarea H, V2): lo que se ve una estrella de DETRAS de la foto, mirandola de frente
var C3_GONE_RESTORE = true;           // (2-nov-2026, pendiente 3D-1) costura del rojo: false = la estrella salida del encuadre deja puesta la opacidad del cristal. Prueba E3 de tests/c3_d_fixes.js.
// Cabra3D (29-oct-2026, barrido S1): un objeto con SU RECORTE pintado (la galaxia de verdad, su luz) no lleva encima su simbolo —el disco
// dorado relleno— ni los aros de su placa: tapaban el nucleo (M 82, captura c3_m82_3d_defrente). En el video ya se omitia. El filete de la
// placa se para en el borde del recorte (CUT_RIM de su radio en pantalla), lejos del nucleo. La barra de la incertidumbre se queda.
// Costura del rojo: C3_CUT_NO_SYMBOL = false (como antes: disco y aros encima). Prueba: tests/c3_cut_symbol.js.
var C3_CUT_NO_SYMBOL = true, C3_CUT_RIM = 0.6;
// Los trozos de un segmento que quedan FUERA del circulo (cx, cy, R): la barra de la incertidumbre y el hilo a la foto no cruzan el nucleo
// de un objeto con su recorte (S1). -> [ { x1, y1, x2, y2 } ] (0, 1 o 2 trozos)
function c3SegOutside(s, cx, cy, R) {
   if (s === null || !(R > 0)) return (s === null) ? [] : [s];
   var dx = s.x2 - s.x1, dy = s.y2 - s.y1, fx = s.x1 - cx, fy = s.y1 - cy, a = dx * dx + dy * dy, b = 2 * (fx * dx + fy * dy), c = fx * fx + fy * fy - R * R, D = b * b - 4 * a * c;
   if (!(a > 0) || D <= 0) return [s];
   var q = Math.sqrt(D), t1 = (-b - q) / (2 * a), t2 = (-b + q) / (2 * a), out = [];
   function pt(t) { return { x: s.x1 + dx * t, y: s.y1 + dy * t }; }
   if (t1 > 0) { var e1 = pt(Math.min(1, t1)); out.push({ x1: s.x1, y1: s.y1, x2: e1.x, y2: e1.y }); }
   if (t2 < 1) { var e2 = pt(Math.max(0, t2)); out.push({ x1: e2.x, y1: e2.y, x2: s.x2, y2: s.y2 }); }
   return out;
}
CPStarfieldDock.prototype._distBody = function(g, model, scale, fit, proj, sc, clip, o) {
   var st = this.state, wn = model.wn, hn = model.hn, gold = CP_INT_AMBER, i, s, penW = Math.max(1, sc), self = this;
   var framePen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1), faintPen = new Pen(cpInt(CP_ATLAS.line, 0.6), 1);
   var K = CP_SV_CORNERS, drawn = { members: 0, stars: 0, deep: 0, bars: 0, rMin: 0, rMax: 0, glints: 0, dimmed: 0, unshaded: 0, looks: {}, psSprites: 0, psDots: 0, psGain: 0, glass: 0, doubtful: 0, faintStars: 0, escaped: 0 };
   function line(sg, pen) { if (sg === null) return; g.pen = pen; g.drawLine(sg.x1, sg.y1, sg.x2, sg.y2); }
   function frameAt(t, pen) {
      for (var c = 0; c < 4; ++c) { var a = K[c], b = K[(c + 1) % 4]; line(fit.seg(a[0] * wn / 2, a[1] * hn / 2, t, b[0] * wn / 2, b[1] * hn / 2, t), pen); }
   }
   // los marcos del tunel: uno por marca de la escala, y las cuatro aristas largas
   function wire() {
      for (var c = 0; c < 4; ++c) line(fit.seg(K[c][0] * wn / 2, K[c][1] * hn / 2, 0, K[c][0] * wn / 2, K[c][1] * hn / 2, 1), faintPen);
      for (c = 0; c < scale.ticks.length; ++c) frameAt(scale.ticks[c].t, faintPen);
      frameAt(1, framePen);
   }
   var part = (o && o.part) ? o.part : "all", mesh = null;
   if (part !== "objects") {
      // LA CAJA Y LA FOTO, POR PROFUNDIDAD. Mirando por delante, la caja entera esta DETRAS de la foto: la foto la tapa
      // (pintada despues). Por detras es al reves: la caja va delante. (Con la caja siempre encima, sus marcos cruzaban la
      // foto como rayas oscuras: revision visual del 13-oct-2026.) Los OBJETOS si se ven a traves de la foto: es el cristal
      // por el que se mira.
      var pA = (o && typeof o.photoAlpha === "number") ? o.photoAlpha : 1, bA = (o && typeof o.boxAlpha === "number") ? o.boxAlpha : 1, pic = (o && o.photo) ? o.photo : st.photo;
      var box = function() { if (bA <= 0.004) return; if (bA < 1) g.opacity = bA; wire(); if (bA < 1) g.opacity = 1; };
      var photo = function() {
         if (pA >= 0.996) return self._drawPhotoMesh(g, fit, pic, clip);
         var mm = cpSvPhotoMeshFine(fit, clip);
         if (pA > 0.004 && pic && mm.cells.length > 0) {
            var layer = self._layerOf(clip.x + clip.w, clip.y + clip.h), gl = new Graphics(layer);
            try { self._drawMesh(gl, mm, mm.front ? pic : (self._photoBack(st) || pic)); } finally { gl.end(); }
            g.opacity = pA; g.drawBitmap(0, 0, layer); g.opacity = 1;
         }
         return mm;
      };
      var hw = ((o && typeof o.holes === "number") ? o.holes : cpSvCutoutFace(fit)) * pA, hole = function() { if (pic) self._drawHoles(g, st, model, fit, proj, sc, hw, !!(o && o.hi === true)); };
      if (fit.front) { box(); mesh = photo(); hole(); }
      else { mesh = photo(); hole(); box(); }
      // (`o.frameAlpha`: el marco de oro de la foto, aparte: en un vuelo se apaga con ella al cruzar su plano)
      var fA = (o && typeof o.frameAlpha === "number") ? o.frameAlpha : bA;
      if (fA > 0.004) { if (fA < 1) g.opacity = fA; frameAt(0, new Pen(gold, penW)); if (fA < 1) g.opacity = 1; }
   }
   // Cabra3D: el polvo. Aqui solo se PROYECTAN sus laminas (y su ocupacion, que el rotulo mira antes de los objetos); se pintan por
   // profundidad con los objetos, abajo (tarea H1, 21-oct: antes iba entero aqui, encima de la foto y detras de todo)
   if (part !== "objects" && this._dustPaint3d) this._dustPaint3d(g, model, scale, fit, sc, clip, o);
   if (part === "back") return { mesh: mesh, drawn: drawn };
   // `o.alpha`: lo que se ven los objetos (en la transicion con la foto: en el estado FOTO, nada)
   var alpha = (o && typeof o.alpha === "number") ? o.alpha : 1;
   if (alpha <= 0.01) return { mesh: mesh, drawn: drawn };
   if (alpha < 1) g.opacity = alpha;
   // los objetos, de lejos a cerca; con la perspectiva, lo cercano mas grande y lo del fondo mas pequeño y mas apagado
   var lod = (o && o.lod > 0) ? this._lodOf(model, o.lod) : null;
   var objs = model.objects, order = lod ? cpSfUiDepthOrderOf(lod.keep, proj.pz) : cpSvDepthOrder(proj.pz, objs.length), bg = cpHexRgb(CP_ATLAS.surface), nullPen = new Pen(0x00000000, 0), W0 = clip.x, W1 = clip.x + clip.w, H0 = clip.y, H1 = clip.y + clip.h;
   var maxR = CP_ATLAS.space[2] * sc, plain = false, hollow = new Brush(0x00000000);
   // LOS RECORTES: los objetos extensos que se ven de un tamaño que merece la pena, cada uno en su turno de profundidad
   var cuts = (CP_SFUI_CUTOUTS === true && !(o && o.cutouts === false)) ? cpSvCutouts(model, proj, fit, CP_SV.CUT_MIN_PX * sc, CP_SV.CUT_MAX) : [], cutAt = {}, cutLay = [];
   for (i = 0; i < cuts.length; ++i) cutAt[cuts[i].index] = cuts[i];
   function diamond(col, r, x, y) { var a = r * sc; g.pen = new Pen(col, penW); g.drawLine(x - a, y, x, y - a); g.drawLine(x, y - a, x + a, y); g.drawLine(x + a, y, x, y + a); g.drawLine(x, y + a, x - a, y); }
   // EN UN VIDEO (`o.video`): un objeto lejano sin recorte no es un disco amarillo plano sino un DESTELLO (un nucleo claro
   // con un halo suave de su color); y el que lleva recorte no lleva ademas su simbolo encima (era una diana sobre la galaxia).
   var video = !!(o && o.video === true), dimBoxes = (o && o.dim && o.dim.length) ? o.dim : null;
   function glint(hex, r, x, y, d) {
      var c = new Point(x, y);
      g.pen = nullPen;
      g.brush = new RadialGradientBrush(c, r, c, [[0, cpInt(hex, 0.8 * d)], [0.16, cpInt(hex, 0.42 * d)], [0.45, cpInt(hex, 0.12 * d)], [1, cpInt(hex, 0)]]);
      g.drawCircle(x, y, r);
      g.brush = new Brush(cpInt(CP_ATLAS.text, Math.min(1, 0.95 * d + 0.05))); g.drawCircle(x, y, Math.max(1, 0.14 * r));
   }
   var dustZ = (this._c3DustDrawUntil && this._c3DustFrame && this._c3DustFrame.fit === fit) ? this._c3DustFrame : null;   // Cabra3D: las capas de polvo, por profundidad
   if (dustZ) dustZ.next = 0;
   // Cabra3D (tarea H, V2, 21-oct): mirando la foto DE FRENTE, los puntos que caen dentro de su contorno estan DETRAS de ella: se ven a
   // traves del cristal, apagados (C3_GLASS_STARS); antes se pintaban encima de la foto con todo su brillo (revision visual del 21-oct)
   var glassQ = null;
   if (fit.front && fit.mode === "perspective" && (part === "objects" || part === "all")) {
      var gq = [fit.px(-wn / 2, -hn / 2, 0), fit.px(wn / 2, -hn / 2, 0), fit.px(wn / 2, hn / 2, 0), fit.px(-wn / 2, hn / 2, 0)];
      if (gq[0].ok && gq[1].ok && gq[2].ok && gq[3].ok) { glassQ = gq; var gA = 0; for (var gk = 0; gk < 4; ++gk) { var ga = gq[gk], gb = gq[(gk + 1) % 4]; gA += ga.x * gb.y - gb.x * ga.y; } glassQ.s = (gA > 0) ? 1 : -1; }
   }
   function inGlass(x, y) {
      for (var k = 0; k < 4; ++k) { var a = glassQ[k], b = glassQ[(k + 1) % 4]; if (glassQ.s * ((b.x - a.x) * (y - a.y) - (b.y - a.y) * (x - a.x)) < 0) return false; }
      return true;
   }
   for (var q = 0; q < order.length; ++q) {
      i = order[q];
      if (!proj.vis[i]) continue;
      if (dustZ && dustZ.next < dustZ.groups.length && dustZ.groups[dustZ.next].z > proj.pz[i] && this._c3DustDrawUntil(g, fit, proj.pz[i]) > 0) plain = false;
      var ob = objs[i], x = proj.px[i], y = proj.py[i], m = proj.pm[i], k = cpSvDepthSize(m), dim = cpSvDepthDim(m);
      if (ob.kind === "member" || ob.kind === "star") {
         if (x < W0 || x > W1 || y < H0 || y > H1) continue;
         var r = Math.min(maxR, ((ob.kind === "member") ? 0.67 : ob.size) * sc * k);
         if (!plain) { g.pen = nullPen; plain = true; }
         // (en un video, bajo el texto los puntos casi no se ven: `o.dim` = las cajas del texto, con su opacidad y su borde suave)
         var under = 0;
         for (var dz = 0; dimBoxes && dz < dimBoxes.length; ++dz) {
            var bz = dimBoxes[dz], ox2 = Math.max(bz.x0 - x, 0, x - bz.x1), oy2 = Math.max(bz.y0 - y, 0, y - bz.y1), far = Math.sqrt(ox2 * ox2 + oy2 * oy2);
            if (far < bz.pad) under = Math.max(under, bz.a * (1 - far / bz.pad));
         }
         if (under > 0.01) { g.opacity = alpha * (1 - CP_FLP.TEXT_DIM * under); ++drawn.dimmed; }
         if (glassQ !== null && inGlass(x, y)) { g.opacity = alpha * ((under > 0.01) ? (1 - CP_FLP.TEXT_DIM * under) : 1) * C3_GLASS_STARS; under = Math.max(under, 0.02); ++drawn.glass; }
         // (las estrellas de la foto, si el desplegable «Stars» lo pide: ui/starfield_photostars.js; con «Gaia» ni se mira)
         // Cabra3D: en la maquina del tiempo, una estrella SIN velocidad radial (asumida 0) va HUECA: su sitio es incierto
         // (2-nov-2026, pendiente 3D-1, el «parpadeo»: la opacidad del cristal, o la del texto del video, se acaba de poner y este `continue` se saltaba el
         // `g.opacity = alpha` de abajo: si la ULTIMA estrella tras la foto era una salida del encuadre, lo de despues —las estrellas de delante, las placas, la leyenda— salia al 35 %.)
         if (ob.tmGone === true) { if (C3_GONE_RESTORE === true && under > 0.01) g.opacity = alpha; continue; }   // Cabra3D: salio del encuadre en la maquina del tiempo: ya no esta detras de la foto
         var dimS = ((ob.kind === "star") ? dim * c3FaintK(ob) : dim) * ((ob.tmFade >= 0 && ob.tmFade < 1) ? ob.tmFade : 1);      // (2-nov, decisión 5a: el cono la apaga) // (26-oct-2026, A'b de Nino: una estrella DEBIL, S/R a ojo de 12 a 20, va al 55 %: C3_FAINT_DIM)
         // (2-nov-2026, decisión 2 de Nino) un miembro que se ha ESCAPADO de su cúmulo (más lejos que su radio de Jacobi en ese instante): gris tenue
         if (ob.tmEsc === true && typeof C3_TMUI !== "undefined" && typeof C3_TM_ESC_GREY !== "undefined" && C3_TM_ESC_GREY === true) { this._dot(g, x, y, r, this._brush(cpSfUiDim(C3_TMUI.ESC_RGB, dimS, bg), C3_TMUI.ESC_ALPHA), video); ++drawn.escaped; }
         else if (ob.tmHollow === true) { this._tmHollowDot(g, x, y, r, cpSfUiDim(ob.rgb, dimS, bg), sc); plain = false; }
         else if (ob.suspect === true) { this._tmHollowDot(g, x, y, r * 1.2, cpSfUiDim(ob.rgb, dimS, bg), sc); plain = false; ++drawn.doubtful; }      // Cabra3D (22-oct): distancia dudosa (RUWE ≥ 1,4): punto HUECO
         else if (!(this.starsMode !== "gaia" && this._photoStarDraw(g, fit, proj, scale, i, ob, x, y, r, dimS, bg, video, drawn)))
            this._dot(g, x, y, r, this._brush(cpSfUiDim(ob.rgb, dimS, bg), 1), video);
         if (ob.kind === "star" && c3FaintDash(ob)) {      // (26-oct-2026, decision «b» de Nino: la estrella DEBIL lleva un anillo a trozos alrededor de su punto, a su brillo)
            this._c3FaintRing(g, x, y, (ob.tmHollow === true || ob.suspect === true) ? 1.2 * r : r, 0xff000000 | (cpSfUiDim(ob.rgb, dim, bg) & 0xf8f8f8), sc); plain = false; ++drawn.faintStars;
         } else if (dimS < dim) ++drawn.faintStars;
         if (under > 0.01) g.opacity = alpha;
         if (ob.kind === "member") ++drawn.members; else { ++drawn.stars; if (drawn.rMin === 0 || r < drawn.rMin) drawn.rMin = r; if (r > drawn.rMax) drawn.rMax = r; }
         continue;
      }
      plain = false;
      var fk = c3FaintK(ob), goldD = cpInt(CP_ATLAS.gold, dim * fk), k2 = Math.min(3, k), cutSym = false;
      if (cutAt[i]) {
         // LA SOMBRA del recorte tapa lo que tiene detras (los marcos de la caja)… salvo LA FOTO: con ella detras, la foto
         // menos la luz del objeto (su hueco) mas la luz del recorte tiene que dar la foto; la sombra lo dejaba en un disco
         // oscuro con cerco. Se apaga segun lo dentro de la foto que cae el recorte (suave: 4 % del alto a cada lado del borde).
         var shw = 1;
         if (CP_SFUI_SHADE_OFF_PHOTO === true && o && o.shadeQuad && typeof o.shadePhoto === "number") {
            var rq = Math.max(8, 0.04 * fit.rect.h), dq = cpSfUiQuadDepth(o.shadeQuad, x, y);
            shw = 1 - Math.max(0, Math.min(1, o.shadePhoto)) * Math.max(0, Math.min(1, (dq + rq) / (2 * rq)));
         }
         // Cabra3D (28-oct-2026, A2): la nebulosa, en laminas paralelas repartidas en su profundidad (ui/starfield_nebula.js `_c3NebSheets`)
         var cOpt = { hi: !!(o && o.hi === true), alpha: alpha, shade: shw, light: !!(o && o.light === true) };
         var cm = (ob.kind === "nebula" && this._c3NebSheets && C3_NEB_FIX_ON.sheets === true) ? this._c3NebSheets(g, st, model, fit, scale, cutAt[i], cOpt) : this._drawCutout(g, st, model, fit, cutAt[i], cOpt);
         if (shw < 0.5) ++drawn.unshaded;
         if (cm !== null) cutLay.push({ index: i, quad: cm.quad, rPx: cutAt[i].rPx, z: proj.pz[i], alpha: cm.alpha });
         // (…salvo que su recorte no de señal —menos de GLINT_PX pixeles de imagen—: un borron tenue con el rotulo «señalando nada».
         // Ese lleva ademas su destello, para que se vea donde esta.)
         if (cm !== null && video && cm.px >= CP_SFUI_IMG.GLINT_PX) { ++drawn.deep; continue; }
         // (29-oct, S1) en el panel, igual: con su recorte con señal, sin el simbolo encima (la barra de la incertidumbre si)
         cutSym = (C3_CUT_NO_SYMBOL === true && cm !== null && cm.px >= CP_SFUI_IMG.GLINT_PX && ob.kind !== "cluster");
      }
      // la incertidumbre: una barra a lo largo del fondo
      s = fit.seg(ob.u, ob.v, proj.lo[i], ob.u, ob.v, proj.hi[i]);
      if (this.errBars !== false && !video && s !== null && Math.abs(s.x2 - s.x1) + Math.abs(s.y2 - s.y1) > 2) {
         var bPen = new Pen(cpInt(ob.kind === "quasar" ? CP_ATLAS.chart[1] : CP_ATLAS.gold, 0.7 * dim), penW), bSeg = cutSym ? c3SegOutside(s, x, y, C3_CUT_RIM * cutAt[i].rPx) : [s];
         for (var bq = 0; bq < bSeg.length; ++bq) line(bSeg[bq], bPen);      // (29-oct, S1: con su recorte, la barra no cruza el nucleo)
         ++drawn.bars;
      }
      if (cutSym) { ++drawn.deep; drawn.cutNoSym = (drawn.cutNoSym || 0) + 1; continue; }      // (29-oct, S1)
      if (ob.kind === "cluster") {
         // el cumulo: su circulo en el plano de la foto, a su distancia
         var ring = [], whole = true;
         for (var a2 = 0; a2 <= 48 && whole; ++a2) { var an = a2 * Math.PI / 24, pp = fit.px(ob.u + ob.radius * Math.cos(an), ob.v + ob.radius * Math.sin(an), proj.tt[i]); whole = pp.ok && Math.abs(pp.x) < 30000 && Math.abs(pp.y) < 30000; ring.push(new Point(Math.round(pp.x), Math.round(pp.y))); }
         if (whole) { g.pen = new Pen(gold, penW); g.drawPolyline(ring); }
         g.pen = new Pen(gold, penW); g.brush = hollow; g.drawCircle(x, y, 3 * sc * k2);
      } else if (video && ob.suspect) {
         // en el VIDEO lo de distancia dudosa no se pinta: su aro hueco, sin rotulo, cae encima del objeto de al lado (dos aros
         // sobre NGC 6207 en el recorrido de M 13) y en una pelicula se lee como un defecto. En el panel sigue, con su leyenda.
      } else if (video && (ob.kind === "quasar" || ob.kind === "galaxy" || ob.kind === "group")) {
         glint((ob.kind === "quasar") ? CP_ATLAS.chart[1] : CP_ATLAS.gold, CP_ATLAS.space[1] * sc * (0.7 + 0.5 * k2), x, y, Math.max(0.55, dim) * fk);
         // (26-oct-2026, decision «b»: lo debil, en el video, lleva el anillo a trozos dentro de su halo, al brillo del destello)
         if (c3FaintDash(ob)) this._c3FaintRing(g, x, y, 0.3 * CP_ATLAS.space[1] * sc * (0.7 + 0.5 * k2), cpInt((ob.kind === "quasar") ? CP_ATLAS.chart[1] : CP_ATLAS.gold, Math.max(0.55, dim)), sc);
         ++drawn.glints;
      } else if (ob.kind === "quasar") {
         // (23-oct-2026: con el interruptor «tambien lo que no se ve en tu foto», lo que no se ve va APAGADO: un rombo igual que los
         // que se ven los confundia —visto en la captura c3_vis_unseen_encendido—)
         diamond(cpInt(CP_ATLAS.chart[1], ob.unseen === true ? 0.4 * dim : dim * fk), ob.size * k2, x, y);
         if (c3FaintDash(ob)) this._c3FaintRing(g, x, y, ob.size * k2 * sc, cpInt(CP_ATLAS.chart[1], dim), sc);      // (26-oct-2026, decision «b»: el anillo a trozos por fuera del rombo)
      } else if (ob.kind === "group") {
         if (c3FaintDash(ob)) { g.pen = this._c3FlatPen(goldD >>> 0, penW); c3DashCircle(g, x, y, ob.size * sc * k2, penW); }      // (26-oct-2026, decision «b»: el anillo del grupo, a trozos)
         else { g.pen = new Pen(ob.unseen === true ? cpInt(CP_ATLAS.gold, 0.4 * dim) : goldD, penW); g.brush = hollow; g.drawCircle(x, y, ob.size * sc * k2); }
      } else if (ob.kind === "other" || ob.kind === "nebula") {
         cpSfUiNebula(g, x, y, 2.6 * sc * k2, goldD, penW);
      } else {
         g.pen = new Pen(ob.suspect ? cpInt(CP_ATLAS.gold, 0.5 * dim) : goldD, penW); g.brush = ob.suspect ? hollow : new Brush(goldD);
         g.drawCircle(x, y, 2.4 * sc * k2);
         if (c3FaintDash(ob)) this._c3FaintRing(g, x, y, 2.4 * sc * k2, goldD, sc);      // (26-oct-2026, decision «b»: la galaxia debil, un anillo a trozos por fuera de su disco, a su brillo)
      }
      ++drawn.deep;
   }
   if (dustZ) this._c3DustDrawUntil(g, fit, -Infinity);                 // Cabra3D: las capas que estan mas cerca que todos los objetos
   if (this._tmTrails3d) this._tmTrails3d(g, model, scale, fit, proj, sc, clip, alpha, video);   // Cabra3D: las estelas de la maquina del tiempo
   if (alpha < 1) g.opacity = 1;
   drawn.cutouts = cutLay;
   return { mesh: mesh, drawn: drawn };
};

// EL TOPE DE ESTRELLAS AL GIRAR (CP_SFUI_LOD_STARS). Por modelo, una vez: los miembros de cumulo y la mitad del tope con las
// estrellas mas grandes (las mas brillantes) siempre; del resto, una muestra fija por indice (`cpSvHash01`) hasta llenar el
// tope. Lo que no es estrella (galaxias, cumulos, nebulosas, cuasares) va siempre. Devuelve null si no hace falta (menos
// estrellas que el tope), o { mask (1 = se pinta), keep (los indices que se pintan, en orden), stars, kept }.
// (Una copia del modelo de la maquina del tiempo tiene los mismos objetos en el mismo orden: usa el de su modelo de base.)
// (22-oct, tope adaptativo: el orden por brillo se hace UNA vez por modelo —`base._lodPrep`— y cada tope pedido se guarda —hasta
// LOD_MEMO—: cambiar de escalon cuesta un recorrido, no una ordenacion. La regla y el resultado de cada tope son los de antes.)
var CP_SFUI_LOD_MEMO = 6;
CPStarfieldDock.prototype._lodPrep = function(base) {
   var P = base._lodPrep;
   if (P && P.n === base.objects.length) return P;
   var objs = base.objects, n = objs.length, i, members = 0, rest = [], nStars = 0;
   for (i = 0; i < n; ++i) {
      var kd = objs[i].kind;
      if (kd !== "star" && kd !== "member") continue;
      ++nStars;
      if (kd === "member") ++members; else rest.push(i);
   }
   rest.sort(function(a, b) { return (objs[b].size - objs[a].size) || (a - b); });
   P = base._lodPrep = { n: n, stars: nStars, members: members, rest: rest, memo: [] };
   return P;
};
CPStarfieldDock.prototype._lodOf = function(model, cap) {
   var base = model.tmBase || model, P = this._lodPrep(base), m;
   for (m = 0; m < P.memo.length; ++m) if (P.memo[m].cap === cap) return P.memo[m].out;
   var objs = base.objects, n = objs.length, i, out = null;
   if (P.stars > cap) {
      var mask = new Uint8Array(n), kept = 0, rest = P.rest;
      for (i = 0; i < n; ++i) { var kd = objs[i].kind; if (kd !== "star") { mask[i] = 1; if (kd === "member") ++kept; } }
      var top = Math.max(0, Math.min(rest.length, Math.round(cap / 2) - kept));
      for (i = 0; i < top; ++i) { mask[rest[i]] = 1; ++kept; }
      var left = rest.length - top, p = (left > 0) ? Math.max(0, cap - kept) / left : 0;
      for (i = top; i < rest.length; ++i) if (cpSvHash01(rest[i], 7) < p) { mask[rest[i]] = 1; ++kept; }
      var keep = [];
      for (i = 0; i < n; ++i) if (mask[i]) keep.push(i);
      out = { mask: mask, keep: keep, stars: P.stars, kept: kept };
   }
   P.memo.push({ cap: cap, out: out });
   if (P.memo.length > CP_SFUI_LOD_MEMO) P.memo.shift();
   return out;
};
// El tope de AHORA para el dibujo ligero (0 = todas). Con CP_SFUI_LOD_ADAPT apagado, el fijo.
CPStarfieldDock.prototype._lodCapNow = function() {
   if (CP_SFUI_LOD_ADAPT !== true) return CP_SFUI_LOD_STARS;
   var model = this._distModel(), base = model.tmBase || model, A = this._lodA;
   if (!A || A.base !== base || A.n !== base.objects.length) {
      // (el modelo se rehace al llegar la red: con la misma imagen se sigue desde el tope aprendido, no desde el de partida)
      var ns = this._lodPrep(base).stars, from = (A && A.st === this.state) ? A.cap : CP_SFUI_LOD_STARS;
      A = this._lodA = { base: base, st: this.state, n: base.objects.length, stars: ns, cap: Math.max(Math.min(CP_SFUI_LOD_MIN, ns), Math.min(ns, from)), ema: -1, k: 0, changes: 0 };
   }
   return (A.cap >= A.stars) ? 0 : A.cap;
};
// Lo que tardo un dibujo ligero hecho con el tope `capUsed` (0 = todas): media movil y, cada dos dibujos con el mismo tope, el tope nuevo.
// Modelo del coste: t = fijo + b·N; el paso multiplicativo con exponente 1,5 converge sin oscilar mientras las estrellas sean menos de
// ~3/4 del dibujo (medido en la ablacion de c3_perf: Pleyades 25 de 49 ms, LDu 2 14 de 30).
CPStarfieldDock.prototype._lodFeed = function(ms, capUsed) {
   var A = this._lodA;
   if (CP_SFUI_LOD_ADAPT !== true || !A || !(ms >= 0)) return;
   var used = (capUsed > 0) ? capUsed : A.stars;
   if (used !== Math.min(A.cap, A.stars)) return;                 // (un dibujo con otro tope: no cuenta)
   A.ema = (A.k === 0) ? ms : A.ema + 0.4 * (ms - A.ema);
   if (++A.k < 2) return;
   var r = CP_SFUI_LOD_TARGET_MS / Math.max(1, A.ema);
   if (r > 1 - CP_SFUI_LOD_BAND && r < 1 + CP_SFUI_LOD_BAND) return;
   if (r > 1 && A.cap >= A.stars) return;                         // (ya van todas)
   var f = Math.max(0.6, Math.min(1.5, Math.pow(r, 1.5)));
   var lo = Math.min(CP_SFUI_LOD_MIN, A.stars), next = Math.round(A.cap * f / CP_SFUI_LOD_STEP) * CP_SFUI_LOD_STEP;
   next = Math.max(lo, Math.min(A.stars, next));
   if (next !== A.cap) { A.cap = next; A.k = 0; A.ema = -1; ++A.changes; }
};
// El orden de pintado (lo lejano antes) de unos indices: el mismo criterio que `cpSvDepthOrder` (a igual profundidad, por indice).
function cpSfUiDepthOrderOf(idx, z) {
   var a = idx.slice();
   a.sort(function(p, q) { return (z[q] - z[p]) || (p - q); });
   return a;
}

// `opts` (para las transiciones y el arrastre):
//   noObjects   el decorado SIN objetos ni placas (la caja, la foto, las cifras, las bandas)
//   noBody      solo la cabecera, la leyenda y el pie (la caja la pinta la transicion, fotograma a fotograma)
//   light       sin placas (mientras se arrastra)
CPStarfieldDock.prototype._drawDist = function(g, w, h, sc, opts) {
   var self = this, st = this.state, res = st.result, F = this._fonts(sc), P = function(v) { return Math.round(v * sc); }, o = opts || {};
   var model = this._distModel(), pad = P(CP_SFUI.PAD), i, q, gold = CP_INT_AMBER, blue = cpInt(CP_ATLAS.chart[1]);
   if (o.tickSc > 0 && o.tickSc < sc) { var F2 = {}, kF; for (kF in F) F2[kF] = F[kF]; F2.mono = cpFont("mono", CP_ATLAS.size.label * o.tickSc); F = F2; }   // Cabra3D (V4)
   var top = this._drawHead(g, w, sc, F, C3_EYEBROW + "  ·  " + optT("DISTANCES"), optT("what lies behind the photo, and how far"));
   var side = (this.pose === "side"), scale = cpSvDistScale(this.scaleMode, model, this.unit), W = this._words(), words = W;
   var bandText = { "milky-way": optT("MILKY WAY STARS"), "local-group": optT("LOCAL GROUP"), "nearby": optT("NEARBY GALAXIES"), "far": optT("FAR UNIVERSE"),
                    "galaxy": optT("OUR GALAXY · LINEAR"), "nearby-linear": optT("NEARBY UNIVERSE · LINEAR"), "far-linear": optT("FAR UNIVERSE · LINEAR") };
   function bandLabel(key) { return (scale.mode === "segments" && key !== "galaxy") ? bandText[key + "-linear"] : bandText[key]; }
   // la leyenda
   var items = [];
   function dot(col, r, hollow) { return function(gg, x, y) { gg.pen = new Pen(col, Math.max(1, sc)); gg.brush = new Brush(hollow ? 0x00000000 : col); gg.drawCircle(x, y, r * sc); }; }
   function diamond(col, r) { return function(gg, x, y) { var a = r * sc; gg.pen = new Pen(col, Math.max(1, sc)); gg.drawLine(x - a, y, x, y - a); gg.drawLine(x, y - a, x + a, y); gg.drawLine(x + a, y, x, y + a); gg.drawLine(x, y + a, x - a, y); }; }
   // (26-oct-2026, decision «b»: la muestra de lo debil es un punto con SU ANILLO A TROZOS, como se pinta; en el modo «dim» de antes, el punto tenue)
   function faintDot(colInt, atlasHex, r) {
      return function(gg, x, y) {
         if (C3_FAINT_STYLE === "dim") return dot(cpInt(atlasHex, C3_FAINT_DIM), r, false)(gg, x, y);
         dot(colInt, r, false)(gg, x, y);
         if (C3_FAINT_STYLE === "dash") { gg.pen = c3FlatPen(colInt >>> 0, Math.max(1, sc)); c3DashCircle(gg, x, y, Math.max(r * sc + C3_FAINT_DASH.GAP * sc, 3.6 * sc), Math.max(1, sc)); }
      };
   }
   items.push({ text: format(optT("%s stars with a reliable parallax (real colour)"), cpSvGroup(model.counts.stars)), short: cpSvGroup(model.counts.stars), draw: dot(CP_INT_TEXT, 2, false) });
   // (26-oct-2026, A'b de Nino: de las estrellas de arriba, las de S/R a ojo de 12 a 20: el anillo a trozos)
   // (2-nov-2026, 3D-11) en la maquina del tiempo los recuentos son los de la escena y pueden quedar en 0: la entrada se decide con los de AHORA
   // (`tmBase`), para que la leyenda no pierda filas y la caja 3D no salte al arrastrar el tiempo
   var cnt0 = (model.tmBase && model.tmBase.counts && (typeof C3_TM_LEGEND_KEEP === "undefined" || C3_TM_LEGEND_KEEP !== false)) ? model.tmBase.counts : model.counts;
   if (cnt0.faintStars > 0) items.push({ text: format(optT("%s of the stars FAINT in your photo (dashed ring)"), cpSvGroup(model.counts.faintStars)), short: cpSvGroup(model.counts.faintStars), draw: faintDot(CP_INT_TEXT, CP_ATLAS.text, 2) });
   if (cnt0.doubtful > 0) items.push({ text: format(optT("%s stars with a doubtful distance (RUWE of 1.4 or more)"), cpSvGroup(model.counts.doubtful)), short: cpSvGroup(model.counts.doubtful), draw: dot(CP_INT_TEXT, 2.4, true) });
   if (model.counts.clusters > 0) items.push({ text: format(optT("cluster (%s members)"), cpSvGroup(model.counts.members)), short: cpSvGroup(model.counts.members), draw: dot(gold, 3.5, true) });
   if (model.counts.galaxies > 0) items.push({ text: (model.counts.galaxies === 1) ? optT("1 galaxy or group") : format(optT("%d galaxies and groups"), model.counts.galaxies), short: String(model.counts.galaxies), draw: dot(gold, 2.4, false) });
   if (model.counts.quasars > 0) items.push({ text: (model.counts.quasars === 1) ? optT("1 quasar") : format(optT("%d quasars"), model.counts.quasars), short: String(model.counts.quasars), draw: diamond(blue, 3) });
   // (24-oct-2026, D1 = A': de los de arriba, los que pasan la vara por poco —S/R 12 a 20—: el anillo a trozos)
   if (model.counts.faint > 0) items.push({ text: format(optT("%s of them FAINT in your photo (dashed ring)"), cpSvGroup(model.counts.faint)), short: cpSvGroup(model.counts.faint), draw: faintDot(gold, CP_ATLAS.gold, 2.4) });
   // (23-oct-2026: solo con el interruptor «tambien lo que no se ve en tu foto», apagado de fabrica)
   if (model.counts.unseen > 0) items.push({ text: format(optT("%s of the catalogues that your photo does NOT show (hollow, dimmed)"), cpSvGroup(model.counts.unseen)), short: cpSvGroup(model.counts.unseen), draw: dot(cpInt(CP_ATLAS.gold, 0.5), 2.4, true) });
   if (model.counts.others > 0) items.push({ text: (model.counts.others === 1) ? optT("1 nebula or other object of our galaxy") : format(optT("%d nebulae and other objects of our galaxy"), model.counts.others), short: String(model.counts.others), draw: function(gg, x, y) { cpSfUiNebula(gg, x, y, 2.6 * sc, gold, Math.max(1, sc)); } });
   if (this.errBars !== false) items.push({ text: optT("uncertainty of the distance"), short: "±", err: true, draw: function(gg, x, y) { gg.pen = new Pen(gold, Math.max(1, sc)); gg.drawLine(x - 6 * sc, y, x + 6 * sc, y); } });
   // Cabra3D (tarea H8, 21-oct): con la maquina del tiempo lejos de «ahora», lo suyo: el punto HUECO (sin velocidad radial: no es el simbolo
   // del cumulo, que es de oro y mayor) y la estela
   // (el sitio se reserva SIEMPRE —al pulsar ▶ o al llegar las velocidades radiales la escena no salta: lo vio c3_blockD_editor 5, una vista
   // guardada antes de llegar la RV ya no casaba—; se pintan solo lejos de «ahora» y con velocidades radiales)
   var tmItems = [];
   if (this.tm) {
      tmItems.push({ text: optT("hollow: no radial velocity (its depth is uncertain)"), short: optT("no RV"), draw: function(gg, x, y) { gg.pen = new Pen(CP_INT_TEXT, Math.max(1, 0.8 * sc)); gg.brush = new Brush(0x00000000); gg.drawCircle(x, y, 2 * sc); } });
      tmItems.push({ text: optT("trail: its path since the photo"), short: optT("trail"), draw: function(gg, x, y) { gg.pen = new Pen(cpInt(CP_ATLAS.text, 0.25), Math.max(1, sc)); gg.drawLine(x - 7 * sc, y + 2 * sc, x - 1 * sc, y); gg.pen = new Pen(cpInt(CP_ATLAS.text, 0.7), Math.max(1, sc)); gg.drawLine(x - 1 * sc, y, x + 6 * sc, y - 2 * sc); } });
      // (1-nov-2026, D4 del video de formacion) las que ENTRAN desde fuera de la foto (tm/tm_incoming.js) se pintaban con un rombo y la leyenda solo conocia la hueca:
      // ahora cuadrado abierto, con su entrada. Se reserva el sitio siempre, como las otras dos
      tmItems.push({ text: optT("open square: comes in from outside your photo (Gaia; no radial velocity)"), short: optT("comes in"), draw: function(gg, x, y) { gg.pen = new Pen(CP_INT_TEXT, Math.max(1, 0.8 * sc)); gg.brush = new Brush(0x00000000); gg.drawRect(x - 1.8 * sc, y - 1.8 * sc, x + 1.8 * sc, y + 1.8 * sc); } });
   }
   var legendRows = this._legendRows(items.concat(tmItems), w - 2 * pad, sc, F);
   if (this.tm && this.tm.t !== 0 && st.tmRv) { items = items.concat(tmItems.slice(0, this.tm.trails ? 2 : 1)); }
   if (this.tm && this.tm.t !== 0 && tmItems.length > 2 && typeof this._tmInInside === "function" && (typeof C3_TMIN === "undefined" || C3_TMIN.LEGEND !== false) && this._tmInInside(this.tm.t).length > 0) items.push(tmItems[2]);      // (D4: lo que entra)
   // Cabra3D (tarea H3, 21-oct): en un lienzo ESTRECHO —menos de 640 px de interfaz— la escena era una miniatura de ~100 px: la leyenda en
   // tres filas, la pista y el pie se comian el alto. Ahora la leyenda se queda en UNA fila (lo que no cabe va, con su texto, al tooltip
   // del pie) y la pista no se reserva (la ficha sale igual, encima de la leyenda)
   var narrow = (w < 640 * sc), legendMore = [];
   this._c3Narrow = narrow;
   if (narrow && legendRows > 1) {
      // (V11, segunda ronda: antes de quitar entradas, cada una se queda en su SIMBOLO y una cifra —«● 6 788», «○ 246», «● 75»…—; el
      // texto entero va al tooltip del pie)
      var ii, shortIt = [];
      for (ii = 0; ii < items.length; ++ii) { legendMore.push(items[ii].text); shortIt.push(items[ii].short ? { text: items[ii].short, draw: items[ii].draw, err: items[ii].err } : items[ii]); }
      items = shortIt;
      var wd = []; for (ii = 0; ii < items.length; ++ii) wd.push(P(CP_ATLAS.space[3]) + F.small.width(items[ii].text));
      var fl = cpSfUiFlow(wd, w - 2 * pad, P(CP_ATLAS.space[3])), first = [];
      for (ii = 0; ii < items.length; ++ii) if (fl.at[ii].row === 0) first.push(items[ii]);
      items = first; legendRows = 1;
   }
   var bottomBlock = legendRows * P(CP_SFUI.ROW_H) + P(CP_SFUI.GAP) + (narrow ? 0 : P(CP_SFUI.HINT_H)) + P(CP_SFUI.FOOT_H), bottomBlock0 = bottomBlock;
   // Cabra3D: con el polvo encendido, su escala va en una FRANJA propia sobre la leyenda; la escena se encaja en lo que queda (nada debajo)
   var c3Strip = this._c3DustStrip ? this._c3DustStrip(w, sc) : null;
   if (c3Strip) bottomBlock += c3Strip.h;
   var plateH = cpSfUiTextH(F.plate) + cpSfUiTextH(F.small) + P(CP_SFUI.GAP) * 2, tickH = cpSfUiTextH(F.mono), bandH = cpSfUiTextH(F.caps) + P(CP_SFUI.GAP) * 2;
   var area = { x: pad, y: top, w: w - 2 * pad, h: Math.max(60, h - top - bottomBlock) };
   var fit, drawRect, rowsTop = 0, forbidden = [], bandBoxes = [], tickBoxes = [], bandsDropped = [];
   if (side) {
      // arriba: las bandas y las cifras; abajo: tres filas de placas
      drawRect = { x: area.x, y: area.y + 2 * bandH + tickH + P(CP_SFUI.GAP), w: area.w, h: 0 };
      drawRect.h = Math.max(40, area.y + area.h - drawRect.y - 4 * (plateH + P(6)) - P(6));
      fit = cpSvDistFit("side", model, drawRect, null, P(CP_ATLAS.space[3]), { zoom: this.sideZoom, centre: this.sideCentre });
      this.sideZoom = fit.win.zoom; this.sideCentre = fit.win.centre;
   } else {
      drawRect = { x: area.x + P(CP_SFUI.GAP), y: area.y + 2 * bandH + P(CP_SFUI.GAP), w: area.w - 2 * P(CP_SFUI.GAP), h: 0 };
      drawRect.h = Math.max(40, area.y + area.h - drawRect.y - tickH - P(CP_SFUI.PAD));
      var dview = this._distView();
      if (this._poseIsAuto()) { var ap = c3AutoPose(model, drawRect); dview.yaw = ap.yaw; dview.pitch = ap.pitch; this._autoYaw = ap.yaw; this._autoPitch = ap.pitch; }
      fit = cpSvDistFit("perspective", model, drawRect, dview);
      this._setDistView(fit.view);
   }
   var proj = cpSvDistProject(model, scale, fit), wn = model.wn, hn = model.hn;
   var framePen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1), faintPen = new Pen(cpInt(CP_ATLAS.line, 0.6), 1);
   function tickLabel(tk) { return cpSvFormatDistance(tk.pc, scale.unit, words).text; }
   var bandLay = [], tickLay = [], objs = model.objects, drawn = { members: 0, stars: 0, deep: 0, bars: 0 }, mesh = null;
   // lo que es de la caja no se sale de su sitio (con la camara dentro, una arista cruza el lienzo entero)
   var clip = { x: 0, y: top, w: w, h: Math.max(1, h - top - bottomBlock) };
   if (o.noBody === true) {
      // (solo el decorado de fuera: la caja la pinta quien llama)
   } else if (side) {
      var pr = fit.plot, ph = fit.photo;
      // la foto, de frente
      if (st.photo) { g.smoothInterpolation = true; g.drawScaledBitmap(new Rect(ph.x, ph.y, ph.x + ph.w, ph.y + ph.h), st.photo); }
      else g.fillRect(new Rect(ph.x, ph.y, ph.x + ph.w, ph.y + ph.h), new Brush(CP_INT_BG));
      g.pen = new Pen(gold, Math.max(1, sc)); g.brush = new Brush(0x00000000); g.drawRect(ph.x, ph.y, ph.x + ph.w, ph.y + ph.h);
      g.font = F.caps; g.pen = new Pen(CP_INT_MUTED);
      g.drawText(ph.x, ph.y - P(CP_SFUI.GAP), cpElide(F.caps, optT("THE PHOTO, FACE ON"), ph.w));
      // el corte
      g.fillRect(new Rect(pr.x, pr.y, pr.x + pr.w, pr.y + pr.h), new Brush(CP_INT_BG));
      g.pen = framePen; g.drawRect(pr.x, pr.y, pr.x + pr.w, pr.y + pr.h);
      g.pen = new Pen(gold, Math.max(1, sc)); g.drawLine(pr.x, pr.y, pr.x, pr.y + pr.h);
      // las cifras ARRIBA (las placas cuelgan hacia abajo: su filete no puede cruzar una cifra)
      // (con zoom, las de la ventana: redondas de la serie 1 - 2 - 5. `cpSvSideTicks`)
      var lastEnd = -1e9, sideTicks = cpSvSideTicks(scale, fit.win, 3), win = fit.win, tickW = 1;
      g.font = F.mono;
      // (las que CABEN, y siempre una serie regular: si no caben todas, una de cada dos, o de cada tres…)
      for (i = 0; i < sideTicks.length; ++i) tickW = Math.max(tickW, F.mono.width(tickLabel(sideTicks[i])));
      sideTicks = cpSvSideTicks(scale, fit.win, 3, Math.max(2, Math.floor(pr.w / (tickW + 2 * P(CP_SFUI.PAD)))));
      for (i = 0; i < sideTicks.length; ++i) {
         var tk = sideTicks[i], txp = Math.round(fit.tx(tk.t)), lab = tickLabel(tk), lw = F.mono.width(lab);
         g.pen = faintPen; g.drawLine(txp, pr.y, txp, pr.y + pr.h);
         var lx = Math.max(pr.x, Math.min(pr.x + pr.w - lw, txp - lw / 2));
         if (lx < lastEnd + P(CP_SFUI.PAD)) continue;
         g.pen = new Pen(CP_INT_MUTED); g.drawText(lx, pr.y - P(CP_SFUI.GAP), lab);
         tickBoxes.push({ x: lx, y: pr.y - P(CP_SFUI.GAP) - tickH, w: lw, h: tickH });
         tickLay.push({ text: lab, x: lx, w: lw });
         lastEnd = lx + lw;
      }
      // las bandas, en dos alturas si hace falta
      var rowEnd = [-1e9, -1e9];
      g.font = F.caps;
      for (i = 0; i < scale.bands.length; ++i) {
         var b = scale.bands[i];
         if (b.t1 <= win.t0 + 1e-9 || b.t0 >= win.t1 - 1e-9) continue;                 // esa banda no cae en la ventana
         var bx0 = fit.tx(Math.max(b.t0, win.t0)), bx1 = fit.tx(Math.min(b.t1, win.t1)), bl = bandLabel(b.key), bw = F.caps.width(bl);
         var bxl = Math.max(pr.x, Math.min(pr.x + pr.w - bw, (bx0 + bx1) / 2 - bw / 2)), row = (bxl > rowEnd[0] + P(CP_SFUI.PAD)) ? 0 : (bxl > rowEnd[1] + P(CP_SFUI.PAD)) ? 1 : -1;
         var by = pr.y - P(CP_SFUI.GAP) - tickH - P(CP_SFUI.GAP);
         g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.6), 1);
         g.drawLine(bx0 + 2, by, bx1 - 2, by); g.drawLine(bx0 + 2, by, bx0 + 2, by + P(3)); g.drawLine(bx1 - 2, by, bx1 - 2, by + P(3));
         if (row < 0) continue;
         rowEnd[row] = bxl + bw;
         var byt = by - P(CP_SFUI.GAP) - row * bandH;
         g.pen = new Pen(gold); g.drawText(bxl, byt, bl);
         bandBoxes.push({ x: bxl, y: byt - cpSfUiTextH(F.caps), w: bw, h: cpSfUiTextH(F.caps) });
         bandLay.push({ key: b.key, text: bl, row: row });
      }
      rowsTop = pr.y + pr.h;
      // los objetos. Primero los miembros (puntos), luego las estrellas, luego lo lejano.
      if (o.noObjects !== true) {
         var lastCol = -1, dotSz = Math.max(1, Math.round(sc)), sideLod = (o.lod > 0) ? this._lodOf(model, o.lod) : null, keepS = sideLod ? sideLod.mask : null;
         g.clipRect = new Rect(fit.plot.x, fit.plot.y, fit.plot.x + fit.plot.w + 1, fit.plot.y + fit.plot.h + 1);
         for (i = 0; i < objs.length; ++i) {
            if (objs[i].kind !== "member" || (keepS && !keepS[i])) continue;
            g.fillRect(new Rect(proj.px[i], proj.py[i], proj.px[i] + dotSz, proj.py[i] + dotSz), this._brush(objs[i].rgb));
            ++drawn.members;
         }
         g.pen = new Pen(0x00000000, 0);
         for (i = 0; i < objs.length; ++i) {
            var ob = objs[i];
            if (ob.kind !== "star" || ob.tmGone === true || (keepS && !keepS[i])) continue;   // Cabra3D: fuera del encuadre
            var fkS = c3FaintK(ob), sc2 = (ob.rgb & 0xf8f8f8) + ((fkS < 1) ? 0x1000000 : 0);      // (26-oct-2026, A'b: la estrella debil, al 55 %)
            if (sc2 !== lastCol) { g.brush = this._brush(ob.rgb, fkS); lastCol = sc2; }
            g.drawCircle(proj.px[i], proj.py[i], ob.size * sc);
            if (c3FaintDash(ob)) { this._c3FaintRing(g, proj.px[i], proj.py[i], ob.size * sc, 0xff000000 | (ob.rgb & 0xf8f8f8), sc); g.pen = new Pen(0x00000000, 0); }      // (26-oct-2026, decision «b»: la estrella debil, un anillo a trozos por fuera de su punto)
            ++drawn.stars;
         }
         for (i = 0; i < objs.length; ++i) {
            var od = objs[i];
            if (od.kind === "star" || od.kind === "member") continue;
            // la incertidumbre: una barra a lo largo del fondo
            var pa = fit.px(od.u, od.v, proj.lo[i]), pb = fit.px(od.u, od.v, proj.hi[i]);
            if (this.errBars !== false && Math.abs(pb.x - pa.x) + Math.abs(pb.y - pa.y) > 2) { g.pen = new Pen(cpInt(od.kind === "quasar" ? CP_ATLAS.chart[1] : CP_ATLAS.gold, 0.7), Math.max(1, sc)); g.drawLine(pa.x, pa.y, pb.x, pb.y); ++drawn.bars; }
            if (od.kind === "cluster") {
               // el cumulo: su circulo en el plano de la foto, a su distancia (de lado, una elipse)
               var rr = od.radius / hn * fit.plot.h;
               g.pen = new Pen(gold, Math.max(1, sc)); g.brush = new Brush(0x00000000);
               g.drawEllipse(proj.px[i] - Math.max(2, P(2)), proj.py[i] - rr, proj.px[i] + Math.max(2, P(2)), proj.py[i] + rr);
               g.drawCircle(proj.px[i], proj.py[i], 3 * sc);
            } else if (od.kind === "quasar") {
               diamond((c3FaintK(od) < 1) ? cpInt(CP_ATLAS.chart[1], c3FaintK(od)) : blue, od.size)(g, proj.px[i], proj.py[i]);      // (24-oct: lo debil, mas tenue; 26-oct, decision «b»: ya no, el anillo a trozos)
               if (c3FaintDash(od)) this._c3FaintRing(g, proj.px[i], proj.py[i], od.size * sc, blue, sc);
            } else if (od.kind === "group") {
               if (c3FaintDash(od)) { g.pen = this._c3FlatPen(gold >>> 0, Math.max(1, sc)); c3DashCircle(g, proj.px[i], proj.py[i], od.size * sc, Math.max(1, sc)); }      // (26-oct-2026, decision «b»: el anillo del grupo, a trozos)
               else { g.pen = new Pen((c3FaintK(od) < 1) ? cpInt(CP_ATLAS.gold, c3FaintK(od)) : gold, Math.max(1, sc)); g.brush = new Brush(0x00000000); g.drawCircle(proj.px[i], proj.py[i], od.size * sc); }
            } else if (od.kind === "other") {
               cpSfUiNebula(g, proj.px[i], proj.py[i], 2.6 * sc, gold, Math.max(1, sc));
            } else {
               var gd = (c3FaintK(od) < 1) ? cpInt(CP_ATLAS.gold, c3FaintK(od)) : gold;
               g.pen = new Pen(od.suspect ? cpInt(CP_ATLAS.gold, 0.5) : gd, Math.max(1, sc)); g.brush = new Brush(od.suspect ? 0x00000000 : gd);
               g.drawCircle(proj.px[i], proj.py[i], 2.4 * sc);
               if (c3FaintDash(od)) this._c3FaintRing(g, proj.px[i], proj.py[i], 2.4 * sc, gold, sc);      // (26-oct-2026, decision «b»: la galaxia debil, un anillo a trozos por fuera de su disco)
            }
            ++drawn.deep;
         }
         g.clipRect = new Rect(0, 0, w, h);
      }
   } else {
      // LA CAJA, EN 3D
      g.clipRect = new Rect(clip.x, clip.y, clip.x + clip.w, clip.y + clip.h);
      var body = this._distBody(g, model, scale, fit, proj, sc, clip, { part: "back" });
      mesh = body.mesh;
      // LOS ROTULOS DE LA CAJA van solo donde hay sitio LIMPIO: dentro del area de dibujo, sin pisar la foto, ni otro rotulo
      // ni (los de zona) un objeto. Si no lo hay, el rotulo NO se pone: la misma regla para todos.
      // (Al orbitar salian cortados por la foto, pisados por estrellas o partidos por el marco: revision visual del 13-oct-2026.)
      var grid3 = cpSvHitGrid(proj.px, proj.py, proj.vis, objs.length, w, h, P(CP_ATLAS.space[3])), capH = cpSfUiTextH(F.caps), taken = [];
      // (27-oct, D1: lo que el rótulo esquiva —la caja del reloj, tm/timeclock_panel.js— también lo esquivan las cifras y las franjas: el reloj se
      //  coloca quieto para toda la escala de tiempo y la franja «OTROS · LA FOTO», que se mueve con el instante, se le metía debajo —c3_clock_panel P3—)
      var hudAvoid0 = [];
      if (this._tmHudRect) { var tmHud0 = this._tmHudRect(w, sc, area, o.light === true, hudAvoid0, proj, { fit: fit, model: model, mesh: mesh, grid: grid3, scale: scale }); if (tmHud0) taken.push(tmHud0); for (var ha = 0; ha < hudAvoid0.length; ++ha) taken.push(hudAvoid0[ha]); }   // Cabra3D: el rotulo se queda su sitio ANTES: cifras y franjas lo esquivan (tapaba «FAR UNIVERSE»)
      function clean(box, maxUnder) {
         if (box.x < clip.x + 1 || box.y < clip.y + 1 || box.x + box.w > clip.x + clip.w - 1 || box.y + box.h > clip.y + clip.h - 1) return false;
         if (mesh.quad && cpSvQuadHitsBox(mesh.quad, box)) return false;
         if (maxUnder >= 0 && cpSvCountInBox(grid3, proj.px, proj.py, box.x, box.y, box.x + box.w, box.y + box.h) > maxUnder) return false;
         for (var tk2 = 0; tk2 < taken.length; ++tk2) if (cpSvBoxesOverlap(box, taken[tk2])) return false;
         return true;
      }
      // LAS CIFRAS: bajo la arista larga que queda mas ABAJO en pantalla (la que toque segun se mire). Todas, o una de
      // cada dos, o de cada tres…: con criterio REGULAR (cpSvPickTicks), y nunca encima de la foto.
      this._edgeLow = cpSvDistEdge(fit, "low", this._edgeLow, P(CP_SV.EDGE_STICK));
      this._edgeHigh = cpSvDistEdge(fit, "high", this._edgeHigh, P(CP_SV.EDGE_STICK));
      var eL = this._edgeLow, eH = this._edgeHigh, tBoxes = [], tText = [];
      g.font = F.mono;
      for (i = 0; i < scale.ticks.length; ++i) {
         var tkp = scale.ticks[i], pt = (eL >= 0) ? fit.px(CP_SV_CORNERS[eL][0] * wn / 2, CP_SV_CORNERS[eL][1] * hn / 2, tkp.t) : null, labp = tickLabel(tkp), lwp = F.mono.width(labp);
         var tb = (pt !== null && pt.ok) ? { x: pt.x - lwp / 2, y: pt.y + P(CP_SFUI.GAP), w: lwp, h: tickH } : null;
         tBoxes.push((tb !== null && clean(tb, -1)) ? tb : null); tText.push(labp);
      }
      var pick = cpSvPickTicks(tBoxes, P(CP_SFUI.PAD));
      for (i = 0; i < pick.length; ++i) {
         var pb = tBoxes[pick[i]];
         g.pen = new Pen(CP_INT_MUTED); g.drawText(pb.x, pb.y + F.mono.ascent, tText[pick[i]]);
         tickBoxes.push(pb); taken.push({ x: pb.x - P(CP_SFUI.GAP), y: pb.y - 1, w: pb.w + 2 * P(CP_SFUI.GAP), h: pb.h + 2 });
         tickLay.push({ text: tText[pick[i]], x: pb.x, w: pb.w, index: pick[i] });
      }
      // el rotulo de la foto: junto a una de sus esquinas, por fuera (siempre derecho, se mire por donde se mire)
      g.font = F.caps;
      var usLay = null, lgap = Math.max(P(C3_LABELS.GAP), Math.ceil(1.5 * cpCapsSpacing(CP_ATLAS.size.label * sc)));
      if (mesh.quad) {
         var us = optT("US · THE PHOTO"), usW = F.caps.width(us), qd = mesh.quad.slice(), gp = P(CP_SFUI.GAP), usTry = [];
         qd.sort(function(p1, p2) { return p1.y - p2.y; });
         // sobre la esquina de mas arriba (centrado, a su izquierda, a su derecha), sobre la segunda, y bajo la de mas abajo
         usTry.push([qd[0].x - usW / 2, qd[0].y - gp - capH]); usTry.push([qd[0].x - usW - gp, qd[0].y - gp - capH]); usTry.push([qd[0].x + gp, qd[0].y - gp - capH]);
         // (28-oct, R1/H1: con el reloj arriba a la izquierda y el rótulo de la máquina del tiempo ancho, ni centrado ni a un lado cabía —a −51 300 años, a lienzo 756, la foto se quedaba sin su
         //  «US · THE PHOTO»—: antes de pasar a la otra esquina se prueba DESLIZADO hacia la izquierda; rojo C3_LABELS.NOFAR)
         if (C3_LABELS.NOFAR !== true) { usTry.push([qd[0].x - 0.7 * usW, qd[0].y - gp - capH]); usTry.push([qd[0].x - 0.85 * usW, qd[0].y - gp - capH]); }
         usTry.push([qd[1].x - usW / 2, qd[1].y - gp - capH]); usTry.push([qd[1].x - usW - gp, qd[1].y - gp - capH]); usTry.push([qd[1].x + gp, qd[1].y - gp - capH]);
         usTry.push([qd[3].x - usW / 2, qd[3].y + gp + tickH + gp]); usTry.push([qd[2].x - usW / 2, qd[2].y + gp + tickH + gp]);
         for (i = 0; i < usTry.length && usLay === null; ++i) {
            var ub = { x: Math.round(usTry[i][0]), y: Math.round(usTry[i][1]), w: usW, h: capH };
            if (clean(ub, 0)) usLay = ub;
         }
         if (usLay !== null) {
            g.pen = new Pen(CP_INT_MUTED); g.drawText(usLay.x, usLay.y + F.caps.ascent, us);
            taken.push(C3_LABELS.OLD === true ? { x: usLay.x - gp, y: usLay.y - 2, w: usLay.w + 2 * gp, h: usLay.h + 4 } : { x: usLay.x - lgap / 2, y: usLay.y - lgap / 2, w: usLay.w + lgap, h: usLay.h + lgap });
            bandBoxes.push(usLay);
         }
      }
      // las bandas: sobre la arista larga de mas ARRIBA, en escalones si hace falta
      for (i = 0; eH >= 0 && eH !== eL && i < scale.bands.length; ++i) {
         var bb = scale.bands[i], hu = CP_SV_CORNERS[eH][0] * wn / 2, hv = CP_SV_CORNERS[eH][1] * hn / 2, a0 = fit.px(hu, hv, bb.t0), a1 = fit.px(hu, hv, bb.t1);
         if (!a0.ok || !a1.ok) continue;
         var blp = bandLabel(bb.key), bwp = F.caps.width(blp), brk = cpSvClipSegment(a0.x, a0.y - P(3), a1.x, a1.y - P(3), clip);
         if (brk === null) continue;
         g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.6), 1);
         g.drawLine(brk.x1, brk.y1, brk.x2, brk.y2);
         // (el rotulo va DENTRO del dibujo —lo de fuera lo corta el recorte del lienzo: «FAR UNIVERSE» salia partido por la
         // derecha— y cerca de su tramo: si para caber hay que apartarlo mas de su ancho, no hay sitio limpio y no se pinta)
         var mx = (brk.x1 + brk.x2) / 2, my = Math.min(brk.y1, brk.y2) - P(CP_SFUI.GAP), bxp = Math.max(Math.max(pad, clip.x), Math.min(Math.min(w - pad, clip.x + clip.w) - bwp, mx - bwp / 2)), got = null;
         if (bwp > clip.w || Math.abs(bxp - (mx - bwp / 2)) > bwp) continue;
         // (la arista esta inclinada: se mira la CAJA de cada rotulo contra las ya puestas y, si pisa, se sube un escalon)
         // (hueco de `lgap` entre rotulos: la caja que se prueba se ensancha lo que pide la separacion y la que se aparta tambien; primero
         // se DESLIZA por la arista —el centro del rotulo sigue sobre su tramo—, luego se apila un escalon mas arriba)
         var oldL = (C3_LABELS.OLD === true), ixp = oldL ? P(CP_SFUI.PAD) : Math.max(P(CP_SFUI.PAD), lgap / 2), iyp = oldL ? 2 : lgap / 2, stepY = oldL ? bandH : capH + lgap;
         var segLo = Math.min(brk.x1, brk.x2), segHi = Math.max(brk.x1, brk.x2), slides = oldL ? [0] : [0, -0.2, 0.2, -0.4, 0.4, -0.6, 0.6, -0.8, 0.8, -1, 1, -1.3, 1.3];
         // (28-oct, H1: lo que se hace cuando el rótulo no encuentra sitio —ver C3_LABELS—; farOK: vale un rótulo lejos de su tramo: más deslizamientos, sin la regla
         //  de «sobre su tramo», y hasta 6 escalones)
         var slidesFar = slides.concat([-1.6, 1.6, -2, 2, -2.5, 2.5]);
         var bandFind = function(bw2, txtX, farOK) {
            var gotX = null, bxp2 = Math.max(Math.max(pad, clip.x), Math.min(Math.min(w - pad, clip.x + clip.w) - bw2, mx - bw2 / 2)), sl = farOK ? slidesFar : slides, rowsN = farOK ? 6 : 4;
            for (var tryRow = 0; tryRow < rowsN && gotX === null; ++tryRow) {
               for (var si = 0; si < sl.length && gotX === null; ++si) {
                  var cxs = bxp2 + sl[si] * bw2;
                  if (si > 0 && ((!farOK && (cxs + bw2 / 2 < segLo || cxs + bw2 / 2 > segHi)) || cxs < Math.max(pad, clip.x) || cxs + bw2 > Math.min(w - pad, clip.x + clip.w))) continue;
                  var cand = { x: Math.round(cxs), y: Math.round(my - tryRow * stepY - capH), w: bw2, h: capH };
                  if (clean({ x: cand.x - ixp, y: cand.y - iyp, w: cand.w + 2 * ixp, h: cand.h + 2 * iyp }, 1)) gotX = { box: cand, row: tryRow, text: txtX };
               }
            }
            return gotX;
         };
         var shortT = C3_LABELS.NOFAR === true ? "" : bandShortLabel(bb.key);
         got = bandFind(bwp, blp, false);
         if (got === null && shortT.length) got = bandFind(F.caps.width(shortT), shortT, false);        // (mejor el nombre corto en su sitio que el largo lejos)
         if (got === null && shortT.length) got = bandFind(F.caps.width(shortT), shortT, true);         // (corto y algo lejos antes que largo y muy lejos)
         if (got === null && C3_LABELS.NOFAR !== true) got = bandFind(bwp, blp, true);
         if (got === null) { bandsDropped.push(blp); continue; }
         blp = got.text;
         g.pen = new Pen(gold); g.drawText(got.box.x, got.box.y + F.caps.ascent, blp);
         bandBoxes.push(got.box); taken.push(oldL ? { x: got.box.x - P(CP_SFUI.PAD), y: got.box.y - 2, w: got.box.w + 2 * P(CP_SFUI.PAD), h: got.box.h + 4 } : { x: got.box.x - lgap / 2, y: got.box.y - lgap / 2, w: got.box.w + lgap, h: got.box.h + lgap });
         bandLay.push({ key: bb.key, text: blp, row: got.row });
      }
      model.tmFrontBox = null; model.tmAvoid = taken;      // (1-nov, D1: lo ya ocupado —cifras, rotulos de zona, reloj—: el rotulo «FRENTE DE LUZ» de la pasada de objetos lo esquiva)
      if (o.noObjects !== true) drawn = this._distBody(g, model, scale, fit, proj, sc, clip, { part: "objects", lod: o.lod }).drawn;
      model.tmAvoid = null;
      this._c3PsDrawn = drawn;      // (1-nov, D8: el pie de «Photo» / «Photo size» dice si las estrellas siguen siendo puntos)
      g.clipRect = new Rect(0, 0, w, h);
   }
   // las placas de los destacados: su hilo hasta la foto y su placa, sin cruzar una cifra
   var plates = [];
   if (o.noBody !== true && o.noObjects !== true && o.light !== true) {
      var hi = cpSvDistHighlights(model), pItems = [];
      if (narrow && hi.length > 2) hi = hi.slice(0, 2);          // Cabra3D (V11): estrecho, solo las dos primeras placas (se amontonaban)
      for (i = 0; i < hi.length; ++i) {
         if (!proj.vis[hi[i].index]) continue;                // detras de la camara: sin placa
         var txt = this._plateOf(model, hi[i].index, hi[i].role);
         // (21-oct) la placa lleva el NOMBRE y «papel · dato»: si no caben en el ancho que se le da, la letra se achica un poco o el dato
         // pasa a dos lineas (nunca «…»; no se corta nada, por lo que no hace falta tooltip)
         var maxPw = Math.max(P(160), Math.min(P(480), area.w * 0.6)), fitN = cpFlFitLines(F.plate, "display", txt[0], maxPw - P(CP_ATLAS.space[2]), 0.8), fitD = cpFlFitLines(F.small, "text", txt[1], maxPw - P(CP_ATLAS.space[2]), 0.85);
         var pw = Math.max(fitN.w, fitD.w) + P(CP_ATLAS.space[2]), ph = fitN.lines.length * cpSfUiTextH(fitN.font) + fitD.lines.length * cpSfUiTextH(fitD.font) + P(CP_SFUI.GAP) * 2;
         var pax = proj.px[hi[i].index], pay = proj.py[hi[i].index];
         // (una NEBULOSA: la placa cuelga del borde de ARRIBA de su capa, no de su centro, que cae en mitad de la nube de estrellas y
         // ahi no hay sitio que no tape a sesenta: la de Sh 2-132 se quedaba sin placa —medido el 14-oct-2026 en `cp_nebula_look.log`—)
         if (objs[hi[i].index].kind === "nebula" && drawn && drawn.cutouts)
            for (var cq = 0; cq < drawn.cutouts.length; ++cq) {
               if (drawn.cutouts[cq].index !== hi[i].index || !drawn.cutouts[cq].quad) continue;
               var qq = drawn.cutouts[cq].quad.slice().sort(function(a, b) { return a.y - b.y; }), tqx = (qq[0].x + qq[1].x) / 2, tqy = Math.max(clip.y, (qq[0].y + qq[1].y) / 2);
               if (tqx >= clip.x && tqx <= clip.x + clip.w && tqy <= clip.y + clip.h) { pax = tqx; pay = tqy; }
            }
         pItems.push({ ax: pax, ay: pay, w: pw, h: Math.max(plateH, ph) });
         plates.push({ index: hi[i].index, role: hi[i].role, text: txt, fit: { name: fitN, data: fitD } });
      }
      forbidden = tickBoxes.concat(bandBoxes);
      if (model.tmFrontBox) forbidden.push(model.tmFrontBox);      // (1-nov, D1: ni una placa encima del rotulo del frente de luz)
      if (this._tmHudRect) { var tmHud = this._tmHudRect(w, sc, area, o.light === true, forbidden, proj, { fit: fit, model: model, mesh: mesh, scale: scale }); if (tmHud) forbidden.push(tmHud); }   // Cabra3D: las placas no se meten bajo el rotulo de la maquina del tiempo
      // (en perspectiva tampoco se tapa la foto: la placa de la estrella mas cercana caia encima. Visto en la captura.)
      if (!side && mesh !== null && mesh.quad) {
         var qx0 = Math.min(mesh.quad[0].x, mesh.quad[1].x, mesh.quad[2].x, mesh.quad[3].x), qx1 = Math.max(mesh.quad[0].x, mesh.quad[1].x, mesh.quad[2].x, mesh.quad[3].x);
         var qy0 = Math.min(mesh.quad[0].y, mesh.quad[1].y, mesh.quad[2].y, mesh.quad[3].y), qy1 = Math.max(mesh.quad[0].y, mesh.quad[1].y, mesh.quad[2].y, mesh.quad[3].y);
         forbidden.push({ x: qx0, y: qy0, w: qx1 - qx0, h: qy1 - qy0, boxOnly: true });
      }
      var placeRect = side ? { x: area.x, y: area.y, w: area.w, h: area.h } : { x: area.x, y: top, w: area.w, h: area.h };
      // (en perspectiva, de los sitios que valen, el que menos objetos tapa)
      var coverGrid = side ? null : cpSvHitGrid(proj.px, proj.py, proj.vis, objs.length, w, h, P(CP_ATLAS.space[3]));
      var placed = cpSvPlacePlates(pItems, placeRect, forbidden, side ? "rows" : "around", rowsTop, P(6),
                                   side ? null : function(box) {
                                      var under = cpSvCountInBox(coverGrid, proj.px, proj.py, box.x, box.y, box.x + box.w, box.y + box.h);
                                      // (tapar a otro de los destacados —el cumulo, la galaxia con nombre— es lo peor que puede hacer una placa)
                                      for (var a = 0; a < pItems.length; ++a) if (pItems[a].ax >= box.x && pItems[a].ax <= box.x + box.w && pItems[a].ay >= box.y && pItems[a].ay <= box.y + box.h) under += 1000;
                                      return under;
                                   }, CP_SFUI_PLATE_COVER);
      if (!side) g.clipRect = new Rect(clip.x, clip.y, clip.x + clip.w, clip.y + clip.h);
      for (i = 0; i < plates.length; ++i) {
         var pl = placed[i], idx = plates[i].index, o3 = objs[idx];
         plates[i].ok = pl.ok; plates[i].box = pl;
         // el hilo del objeto a su sitio en la foto (solo los destacados y el que esta bajo el raton)
         var thread = fit.seg(o3.u, o3.v, 0, o3.u, o3.v, proj.tt[idx]), onPh = fit.onPhoto(o3.u, o3.v);
         // (29-oct, S1) con su recorte pintado: sin aros sobre el nucleo, el filete parado en el borde del recorte y el hilo a la foto tambien
         var cutR = 0;
         if (C3_CUT_NO_SYMBOL === true && o3.kind !== "nebula" && o3.kind !== "cluster" && drawn && drawn.cutouts)
            for (var cr = 0; cr < drawn.cutouts.length; ++cr) if (drawn.cutouts[cr].index === idx && drawn.cutouts[cr].rPx > 0) cutR = drawn.cutouts[cr].rPx;
         if (thread !== null) {
            g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.45), 1, PenStyle_Dot);
            var tSeg = (cutR > 0) ? c3SegOutside(thread, proj.px[idx], proj.py[idx], C3_CUT_RIM * cutR) : [thread];
            for (var tq = 0; tq < tSeg.length; ++tq) g.drawLine(tSeg[tq].x1, tSeg[tq].y1, tSeg[tq].x2, tSeg[tq].y2);
         }
         g.brush = new Brush(0x00000000);
         if (cutR > 0) {
            if (pl.ok) {
               var ldx = pl.lx2 - pl.lx1, ldy = pl.ly2 - pl.ly1, lln = Math.sqrt(ldx * ldx + ldy * ldy), cut0 = Math.min(Math.max(C3_CUT_RIM * cutR, 6 * sc), 0.8 * lln);
               if (lln > 0) { pl = { ok: true, x: pl.x, y: pl.y, w: pl.w, h: pl.h, lx1: pl.lx1 + ldx * cut0 / lln, ly1: pl.ly1 + ldy * cut0 / lln, lx2: pl.lx2, ly2: pl.ly2 }; plates[i].box = pl; plates[i].rim = cut0; }
            }
         } else if (c3FaintDash(o3)) {      // (26-oct-2026, decision «b»: el anillo de un debil, a trozos y a su brillo)
            g.pen = this._c3FlatPen(gold >>> 0, Math.max(1, sc));
            if (onPh.ok !== false) c3DashCircle(g, onPh.x, onPh.y, 4 * sc, Math.max(1, sc));
            c3DashCircle(g, proj.px[idx], proj.py[idx], 5 * sc, Math.max(1, sc));
         } else {
            g.pen = new Pen((c3FaintK(o3) < 1) ? cpInt(CP_ATLAS.gold, c3FaintK(o3)) : gold, Math.max(1, sc));      // (24-oct: el anillo de un debil, mas tenue; modo «dim»)
            if (onPh.ok !== false) g.drawCircle(onPh.x, onPh.y, 4 * sc);
            g.drawCircle(proj.px[idx], proj.py[idx], 5 * sc);
         }
         if (!pl.ok) continue;
         g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.8), 1); g.drawLine(pl.lx1, pl.ly1, pl.lx2, pl.ly2);
         g.pen = new Pen(CP_INT_BORDER, 1); g.brush = new Brush(cpInt(CP_ATLAS.bg, 0.92));
         g.drawRect(pl.x, pl.y, pl.x + pl.w, pl.y + pl.h);
         var ft = plates[i].fit, ty = pl.y + P(CP_SFUI.GAP), tl;
         g.font = ft.name.font; g.pen = new Pen(CP_INT_TEXT);
         for (tl = 0; tl < ft.name.lines.length; ++tl) { g.drawText(pl.x + P(CP_ATLAS.space[2]) / 2, ty + ft.name.font.ascent, ft.name.lines[tl]); ty += cpSfUiTextH(ft.name.font); }
         g.font = ft.data.font; g.pen = new Pen(CP_INT_AMBERLIGHT);
         for (tl = 0; tl < ft.data.lines.length; ++tl) { g.drawText(pl.x + P(CP_ATLAS.space[2]) / 2, ty + ft.data.font.ascent, ft.data.lines[tl]); ty += cpSfUiTextH(ft.data.font); }
      }
      g.clipRect = new Rect(0, 0, w, h);
   }
   // la leyenda, la ficha y el pie
   var ly = h - bottomBlock0;
   var dustLegend = c3Strip ? this._c3DustStripPaint(g, c3Strip, pad, ly - c3Strip.h, sc) : null;   // Cabra3D: la escala del polvo, en su franja
   var legendEnd = this._drawLegend(g, items, pad, ly, w - 2 * pad, sc, F);
   var cardY = h - P(CP_SFUI.FOOT_H) - this._cardH(sc, F, 0);
   var foot = this._drawFoot(g, w, h, sc, F, this._distFootText(model, scale) + (legendMore.length ? "\n" + optT("Legend") + ": " + legendMore.join(" · ") : "") + (bandsDropped.length ? "\n" + optT("Zones with no room on the box") + ": " + bandsDropped.join(" · ") : ""));
   return { kind: "dist", pose: this.pose, scale: scale, fit: fit, proj: proj, model: model, rect: drawRect, clip: clip, win: (side ? fit.win : null), plates: plates, tickBoxes: tickBoxes, bandBoxes: bandBoxes,
            ticks: tickLay, bands: bandLay, bandBoxes: bandBoxes, bandsDropped: bandsDropped, drawn: drawn, legend: { y: ly, end: legendEnd, rows: legendRows, items: items.length, texts: items.map(function(it) { return it.text; }), err: items.some(function(it) { return it.err === true; }) }, cardY: cardY, foot: foot,
            dustLegend: dustLegend, edges: { low: this._edgeLow, high: this._edgeHigh }, light: (o.light === true), area: area, quad: (mesh !== null) ? mesh.quad : null, usLabel: (typeof usLay === "undefined") ? null : usLay, cutouts: drawn.cutouts || [] };
};

// EL MOTIVO DE LA FOTO SIN DISTANCIA: se dice con su nombre (en la pildora y en el pie), no solo dentro de un contador.
CPStarfieldDock.prototype._subjectText = function(model) {
   if (model.subject.cls === "nebula") return format(optT("%s (nebula): no distance in SIMBAD, in Foster & Brunt 2015, in the WISE HII catalogue or from its stars, so it is not placed. You can enter one with «Nebula…»."), cpSfUiShowName(model.subject.name));
   return format(optT("%s (%s): SIMBAD has no measured distance for it, so it is not placed."), cpSfUiShowName(model.subject.name), this._kindText({ kind: (model.subject.cls === "galaxy") ? "galaxy" : (model.subject.cls === "quasar") ? "quasar" : "other", cls: model.subject.cls }));
};
CPStarfieldDock.prototype._distFootText = function(model, scale) {
   var st = this.state, s = [];
   s.push(optT("The width of the field is not to scale: at true scale this beam would be a line."));
   // (las estrellas de la foto, justo despues: el pie tiene dos lineas y lo del final se corta —visto en la captura del 14-oct—)
   var psFoot = this._psFootText();
   if (psFoot.length > 0) s.push(psFoot);
   if (scale.mode === "log") s.push(optT("Each frame is ten times farther than the one before."));
   else s.push(optT("Each stretch is at linear scale; the breaks mark a change of scale."));
   if (model.subject && !model.subject.hasDistance) s.push(this._subjectText(model));
   // (23-oct-2026, Nino: «que solo aparezca en profundidad lo que veo en la imagen»: hasta donde se ve y cuanto se deja fuera)
   var dFoot = (typeof cshDepthFoot === "function") ? cshDepthFoot(st.result) : "";
   if (dFoot.length > 0) s.push(dFoot);
   if (st.net.deepsky === "ok") s.push(optT("Far objects are placed at the distance they are at today; their card also says when their light left."));
   if (model.counts.noDistance === 1) s.push(optT("1 catalogued object of the field has no known distance and is not drawn."));
   else if (model.counts.noDistance > 1) s.push(format(optT("%d catalogued objects of the field have no known distance and are not drawn."), model.counts.noDistance));
   if (model.counts.doubtful > 0) s.push(format(optT("%s stars with a doubtful distance (RUWE of 1.4 or more) are drawn hollow."), cpSvGroup(model.counts.doubtful)));
   if (model.counts.suspect > 0) s.push(format(optT("%s stars with a doubtful distance are not placed here."), cpSvGroup(model.counts.suspect)));
   var src = ["Gaia " + st.result.gaia.release];
   if (st.net.refine === "ok") src.push("Bailer-Jones 2021");
   if (st.net.deepsky === "ok") src.push("SIMBAD");
   if (typeof cshDepthCredits === "function") src = src.concat(cshDepthCredits(st.result));      // (Block G: GLADE+, Quaia)
   if (model.counts.nebulae > 0) src.push("Sharpless 1959");
   s.push(optT("Data") + ": " + src.join(", ") + ".");
   return s.join(" ");
};

// ---------------------------------------------------------------------------
// LO QUE SIGUE AL RATON, encima del dibujo hecho: el anillo de oro del punto bajo
// el cursor y el del elegido. `k` = factor de escala respecto al dibujo (1 en
// pantalla). Solo dibuja (las coordenadas las dejo `_render`).
// ---------------------------------------------------------------------------
// (1-nov-2026, D6 del video de formacion) «LA ESCENA SE PINTA SOBRE LA LEYENDA»: el anillo del objeto elegido o bajo el cursor, su hilo punteado hasta la foto, su barra de
// incertidumbre y su circulo en la foto —todo esto lo pinta `_drawMarks` ENCIMA del dibujo ya recortado— se salian del area de la escena: con la rueda hacia lo alto, el objeto
// baja por debajo del recorte y su anillo, su hilo y su barra cruzaban la leyenda, la pista y el pie. Ahora las marcas del 3D se recortan al area de la escena (`lay.clip`);
// la ficha, que va en su sitio, no. Costura del rojo: C3_MARKS_CLIP = false (como antes).
var C3_MARKS_CLIP = true;
var C3_ANIM_CLIP = true;          // E2: las estrellas de las transiciones tambien se recortan a `lay.clip`
CPStarfieldDock.prototype._drawMarks = function(g, lay, k) {
   var sc = lay.sc * k, R = CP_SFUI.RING * sc, gold = CP_INT_AMBER;
   // la ficha de lo que se mira (la calculo quien cambio lo que se mira: aqui solo se escribe)
   if (lay.cardY !== undefined) lay.card = this._drawCard(g, lay.w * k, lay.cardY * k, sc, this._fonts(sc), this._card || null);
   function ring(x, y, strong, fk, dashed) {
      var gc = (fk < 1) ? cpInt(CP_ATLAS.gold, fk) : gold;                     // (24-oct, D1 = A': el anillo de un objeto DEBIL, mas tenue y sin el aro de fondo opaco; modo «dim»)
      g.brush = new Brush(0x00000000);
      if (dashed) {      // (26-oct-2026, decision «b»: el anillo de un debil, a trozos y a su brillo; el aro oscuro de fondo, a los mismos trozos para que el oro se lea)
         var w1 = Math.max(3, 3 * sc), w2 = Math.max(1.5, 1.5 * sc);
         g.pen = c3FlatPen(cpInt(CP_ATLAS.bg, 0.8) >>> 0, w1); c3DashCircle(g, x, y, R, w2);
         g.pen = c3FlatPen(gold >>> 0, w2); c3DashCircle(g, x, y, R, w2);
         if (strong) { g.pen = c3FlatPen(gold >>> 0, Math.max(1, sc)); c3DashCircle(g, x, y, R + 3 * sc, Math.max(1, sc), c3DashCount(R, w2)); }
         return;
      }
      g.pen = new Pen(cpInt(CP_ATLAS.bg, (fk < 1) ? 0.8 * fk : 0.8), Math.max(3, 3 * sc)); g.drawCircle(x, y, R);
      g.pen = new Pen(gc, Math.max(1.5, 1.5 * sc)); g.drawCircle(x, y, R);
      if (strong) { g.pen = new Pen(gc, Math.max(1, sc)); g.drawCircle(x, y, R + 3 * sc); }
   }
   if (lay.kind === "dist") {
      var cl = (C3_MARKS_CLIP !== false && lay.clip) ? lay.clip : null;
      if (cl) g.clipRect = new Rect(cl.x * k, cl.y * k, (cl.x + cl.w) * k, (cl.y + cl.h) * k);
      var md = lay.model, picks = [[this.selObj, true], [this.hoverObj, false]];
      if (this.selObj < 0 && this.selStar >= 0 && Object.prototype.hasOwnProperty.call(md.objOfStar, this.selStar)) picks[0][0] = md.objOfStar[this.selStar];
      for (var j = 0; j < picks.length; ++j) {
         var o = picks[j][0];
         if (!(o >= 0) || !md.objects[o] || !lay.proj.vis[o]) continue;      // (detras de la camara no hay nada que marcar)
         var ob = md.objects[o], on = lay.fit.onPhoto(ob.u, ob.v), th = lay.fit.seg(ob.u, ob.v, 0, ob.u, ob.v, lay.proj.tt[o]);
         g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.6), 1, PenStyle_Dot);
         if (th !== null) g.drawLine(th.x1 * k, th.y1 * k, th.x2 * k, th.y2 * k);
         // la incertidumbre del que se mira
         var bar = lay.fit.seg(ob.u, ob.v, lay.proj.lo[o], ob.u, ob.v, lay.proj.hi[o]);
         g.pen = new Pen(gold, Math.max(1.5, 1.5 * sc));
         if (bar !== null && this.errBars !== false) g.drawLine(bar.x1 * k, bar.y1 * k, bar.x2 * k, bar.y2 * k);
         var fd = c3FaintDash(ob);
         ring(lay.proj.px[o] * k, lay.proj.py[o] * k, picks[j][1], c3FaintK(ob), fd);
         g.brush = new Brush(0x00000000);
         if (fd) { g.pen = c3FlatPen(gold >>> 0, Math.max(1, sc)); if (on.ok !== false) c3DashCircle(g, on.x * k, on.y * k, 4 * sc, Math.max(1, sc)); }
         else { g.pen = new Pen((c3FaintK(ob) < 1) ? cpInt(CP_ATLAS.gold, c3FaintK(ob)) : gold, Math.max(1, sc)); if (on.ok !== false) g.drawCircle(on.x * k, on.y * k, 4 * sc); }
      }
      if (cl) g.clipRect = new Rect(0, 0, lay.w * k, lay.h * k);
   }
};

// ---------------------------------------------------------------------------
// EL RATON SOBRE EL LIENZO
// ---------------------------------------------------------------------------
// La ficha de lo que se mira ahora: lo que esta bajo el cursor y, si no hay nada, lo elegido.
CPStarfieldDock.prototype._currentCard = function() {
   if (this.state === null || this.mode === "") return null;
   if (this.mode === "dist") {
      this._distModel();
      var pick = (this.hoverObj >= 0) ? this.hoverObj : this.selObj;
      if (pick >= 0) return this._cardOfObject(pick);
   }
   return this._cardOfStar((this.hoverStar >= 0) ? this.hoverStar : this.selStar);
};
// Cambia lo que hay bajo el cursor: la ficha se rehace AQUI (son tres cadenas) y el lienzo solo
// se repinta: el dibujo, que es lo caro, no se toca.
CPStarfieldDock.prototype._setHover = function(star, obj) {
   if (star === this.hoverStar && obj === this.hoverObj) return;
   this.hoverStar = star; this.hoverObj = obj;
   this._card = this._currentCard();
   try { this.canvas.repaint(); } catch (e0) {}
   try { this.dialog.preview.viewport.repaint(); } catch (e) {}
};
CPStarfieldDock.prototype._hitAt = function(x, y) {
   var lay = this.lay, out = { star: -1, obj: -1 };
   if (!lay) return out;
   var R = cpPx(CP_SFUI.HIT, this.canvas);
   if (lay.kind === "dist") {
      var o = cpSvDistNearest(lay.model, lay.proj, x, y, R, false);
      // (sin un punto bajo el cursor: si esta SOBRE el recorte de un objeto extenso, es ese objeto; de varios, el de mas cerca)
      if (o < 0 && lay.cutouts) {
         for (var c = 0; c < lay.cutouts.length; ++c) {
            var cu = lay.cutouts[c];
            if (cpSvQuadHitsBox(cu.quad, { x: x, y: y, w: 0, h: 0 }) && (o < 0 || cu.z < lay.proj.pz[o])) o = cu.index;
         }
      }
      if (o >= 0) { out.obj = o; var ob = lay.model.objects[o]; if (ob.kind === "star" || ob.kind === "member") out.star = ob.ref; }
   }
   return out;
};
CPStarfieldDock.prototype._onPress = function(x, y, button, modifiers) {
   // un clic en el lienzo PARA la vista previa de un vuelo (y nada mas); con una grabacion en marcha, no hace nada
   if (this.flightBusy()) { if (this.fl.preview !== null) this.flightStop(); return; }
   // (un clic FUERA del panel de opciones de grabar lo cierra, y nada mas)
   if (this.fl && this.fl.strip) { this.flightOptionsToggle(); return; }
   this._lastInput = Date.now();                            // (22-oct: el trabajo en reposo espera a que el raton se quede quieto)
   this._animStop();                                        // una pulsacion corta la transicion: queda el estado final
   if (this.mode === "" || !this.lay || this.state === null) return;
   var lay = this.lay, cam = (lay.kind === "dist" && lay.fit.mode === "perspective");
   // el boton izquierdo gira; el derecho, el central o Mayus + arrastrar, desplazan
   this._drag = { x: x, y: y, button: button, moved: false, fit: cam ? lay.fit : null, win: (lay.kind === "dist" && lay.fit.mode === "side") ? lay.fit.win : null,
                  pan: (button !== OPT_MOUSE_LEFT || (((modifiers || 0) & KeyModifier_Shift) !== 0)) };
};
CPStarfieldDock.prototype._onMove = function(x, y, buttons) {
   if (this.mode === "" || !this.lay || this.state === null || this.anim !== null) return;
   var d = this._drag, lay = this.lay;
   if (d && buttons !== 0) {
      var dx = x - d.x, dy = y - d.y;
      if (!d.moved && dx * dx + dy * dy <= 9) return;
      d.moved = true;
      this._lastInput = Date.now();
      if (lay.kind === "dist" && d.fit !== null && this.pose === "perspective") {
         // (siempre desde la vista con la que empezo el arrastre: no se acumula error de un movimiento a otro)
         this._setDistView(d.pan ? cpSvDistPan(d.fit, dx, dy) : cpSvDistOrbit(d.fit.view, dx, dy));
         this._light = CP_SFUI_LIGHT_DRAG;                  // mientras se arrastra, sin placas; al soltar, el dibujo entero
         this._lod = CP_SFUI_LIGHT_DRAG;                    // …y con el tope de estrellas (CP_SFUI_LOD_STARS)
      } else if (lay.kind === "dist" && d.win && this.pose === "side") {
         // de lado, arrastrar DESPLAZA la ventana del fondo (solo hay a donde ir con zoom)
         if (!(d.win.zoom > 1)) return;
         this.sideCentre = cpSvSidePan(d.win, dx / lay.fit.plot.w).centre;
         this._light = CP_SFUI_LIGHT_DRAG; this._lod = CP_SFUI_LIGHT_DRAG;
      } else
         return;
      this.hoverStar = -1; this.hoverObj = -1;
      this._render();
      return;
   }
   // el pie entero y la ficha entera, en el tooltip de su zona
   var tip = "";
   if (lay.foot && y >= lay.foot.rect.y) tip = lay.foot.text;
   else if (this._headTip && this._headBottom && y < this._headBottom) tip = this._headTip;                  // (tarea H3: la cabecera entera)
   else if (lay.card && lay.card.full && y >= lay.card.y && y < lay.card.y + lay.card.h) tip = (typeof c3LinkAt === "function" && c3LinkAt(this, x, y) !== null) ? "" : lay.card.full;   // (27-oct, D3: sobre el nombre, NADA: el aviso «Open in SIMBAD» lo pinta ui/star_link.js donde no tapa datos)
   if (tip !== this._tip) { this._tip = tip; try { this.canvas.toolTip = tip.length ? cpWrapTooltip(tip.split("\n").join("<br>")) : ""; } catch (eT) {} }
   var hit = this._hitAt(x, y);
   this._setHover(hit.star, hit.obj);
};
CPStarfieldDock.prototype._onRelease = function(x, y, button) {
   var d = this._drag;
   this._drag = null;
   try { this.settleTimer.stop(); } catch (eSt) {}
   if (this._light || this._lod) { this._light = false; this._lod = false; if (this.mode !== "" && this.state !== null) this._render(); }
   if (this.mode === "" || !this.lay || this.state === null || !d || d.moved) return;
   if (button !== OPT_MOUSE_LEFT) return;
   // un clic sin arrastre: elegir (o soltar lo elegido si cae en vacio)
   var hit = this._hitAt(x, y);
   this.selectStar(hit.star, hit.obj);
};
CPStarfieldDock.prototype._onWheel = function(x, y, delta) {
   if (this.flightBusy()) return;
   this._animStop();
   if (this.mode === "" || !this.lay || this.state === null || !delta) return;
   this._lastInput = Date.now();
   var f = (delta > 0) ? 1.25 : 0.8, lay = this.lay;
   if (lay.kind === "dist" && lay.fit.mode === "perspective") {
      // un travelin HACIA lo que hay bajo el cursor: si hay un objeto, hacia el (a su profundidad)
      var near = cpSvDistNearest(lay.model, lay.proj, x, y, cpPx(CP_SFUI.HIT, this.canvas), false);
      this._setDistView(cpSvDistZoomAt(lay.fit, f, x, y, (near >= 0) ? lay.proj.pz[near] : undefined));
   } else if (lay.kind === "dist" && lay.fit.mode === "side") {
      // de lado: mas aumentos del corte, sin mover el fondo que hay bajo el cursor
      var sw = cpSvSideZoomAt(lay.fit.win, f, (x - lay.fit.plot.x) / lay.fit.plot.w);
      this.sideZoom = sw.zoom; this.sideCentre = sw.centre;
   } else
      return;
   // (cada vuelta de la rueda, el dibujo ligero; a los CP_SFUI_SETTLE_S de la ultima, el entero: `settleTimer`)
   if (CP_SFUI_LIGHT_DRAG === true && !this._drag) {
      this._light = true; this._lod = true;
      try { this.settleTimer.stop(); this.settleTimer.start(); } catch (eSt) { this._light = false; this._lod = false; }
   }
   this._render();
};

// ELEGIR una estrella (o un objeto de la vista de distancias): se queda marcada en
// el diagrama y en la foto. -1 la suelta.
CPStarfieldDock.prototype.selectStar = function(star, obj) {
   this._animStop();
   this.selStar = (star >= 0) ? star : -1;
   this.selObj = (obj >= 0) ? obj : -1;
   this._card = this._currentCard();
   try { this.canvas.repaint(); } catch (e0) {}
   try { this.dialog.preview.viewport.repaint(); } catch (e) {}
};

// ---------------------------------------------------------------------------
// EL ENLACE CON LA FOTO
// ---------------------------------------------------------------------------
// Un clic (sin arrastre) sobre la imagen del visor: la estrella del diagrama mas
// cercana a ese punto queda elegida. Devuelve el indice de la estrella, o -1.
CPStarfieldDock.prototype.onImageClick = function(imgX, imgY) {
   var st = this.state, rec = this.dialog.currentRec;
   if (this.mode === "" || !st || !rec || this._find(cpSfUiKey(rec.view)) !== st) return -1;
   var pv = this.dialog.preview, tol = cpPx(CP_SFUI.HIT, this.canvas) * Math.max(1e-6, pv.imageCoordScaleX) / Math.max(1e-6, pv.scale);
   var allowed = this._distModel().objOfStar;
   var cf = this._offAt ? this._offAt(imgX + 0.5, imgY + 0.5) : { dx: 0, dy: 0 };          // Cabra3D (22-oct): el anillo va corrido por el desfase local; el clic, al reves
   var star = cpSvStarAt(st.result.stars, allowed, imgX + 0.5 - cf.dx, imgY + 0.5 - cf.dy, Math.max(2, tol));
   if (star < 0) {
      // lo lejano y los cumulos, que no son estrellas de Gaia
      var m = this._distModel(), best = -1, bd = tol * tol * 4, W = st.result.field.width, H = st.result.field.height, big = Math.max(W, H);
      for (var i = 0; i < m.objects.length; ++i) {
         var o = m.objects[i];
         if (o.kind === "star" || o.kind === "member") continue;
         var dx = o.u * big + W / 2 - imgX, dy = o.v * big + H / 2 - imgY, d = dx * dx + dy * dy;
         if (d <= bd) { bd = d; best = i; }
      }
      if (best >= 0) { this.selectStar(-1, best); return -1; }
   }
   if (star < 0) return -1;
   this.selectStar(star, this._distModel().objOfStar[star]);
   return star;
};

// El anillo de oro sobre la FOTO (lo llama el overlay del visor): la estrella bajo
// el cursor del diagrama y la elegida. Solo dibuja.
CPStarfieldDock.prototype.paintOverlay = function(g, scale, sx, sy) {
   var st = this.state, rec = this.dialog.currentRec;
   if (this.mode === "" || !st || !rec || this._find(cpSfUiKey(rec.view)) !== st) return;
   var pv = this.dialog.preview, kx = pv.imageCoordScaleX, ky = pv.imageCoordScaleY, R = cpPx(CP_SFUI.RING, pv), gold = CP_INT_AMBER, self = this;
   function mark(x, y, strong, fk, dashed) {
      if (x === null || x === undefined) return;
      var fx = self._offAt ? self._offAt(x, y) : { dx: 0, dy: 0 };          // Cabra3D (22-oct): el desfase local foto − Gaia (ui/photo_offsets.js)
      var p = cpCropImgToViewport(x + fx.dx, y + fx.dy, scale, sx, sy, kx, ky);
      var gc = (fk < 1) ? cpInt(CP_ATLAS.gold, fk) : gold;                  // (24-oct, D1 = A': el anillo de un objeto DEBIL, mas tenue y el aro de fondo, menos opaco: deja ver lo que haya dentro)
      g.brush = new Brush(0x00000000);
      if (dashed) {      // (26-oct-2026, decision «b»: el anillo de lo debil, a trozos y a su brillo; el aro de fondo, a los mismos trozos)
         g.pen = c3FlatPen(cpInt(CP_ATLAS.bg, 0.75) >>> 0, 4); c3DashCircle(g, p.x, p.y, R, 2);
         g.pen = c3FlatPen(gold >>> 0, 2); c3DashCircle(g, p.x, p.y, R, 2);
         if (strong) { var r3 = R + cpPx(3, pv); g.pen = c3FlatPen(gold >>> 0, 1); c3DashCircle(g, p.x, p.y, r3, 1, c3DashCount(R, 2)); }
         return;
      }
      g.pen = new Pen(cpInt(CP_ATLAS.bg, (fk < 1) ? 0.75 * fk : 0.75), 4); g.drawEllipse(p.x - R, p.y - R, p.x + R, p.y + R);
      g.pen = new Pen(gc, 2); g.drawEllipse(p.x - R, p.y - R, p.x + R, p.y + R);
      if (strong) { var r2 = R + cpPx(3, pv); g.pen = new Pen(gc, 1); g.drawEllipse(p.x - r2, p.y - r2, p.x + r2, p.y + r2); }
   }
   function ofObj(o, strong) {
      var m = st.dist;
      if (!m || !(o >= 0) || !m.objects[o]) return false;
      var ob = m.objects[o];
      if (ob.kind === "star" || ob.kind === "member") return false;
      var W = st.result.field.width, H = st.result.field.height, big = Math.max(W, H);
      mark(ob.u * big + W / 2, ob.v * big + H / 2, strong, c3FaintK(ob), c3FaintDash(ob));
      return true;
   }
   var stars = st.result.stars;
   // (26-oct-2026, A'b de Nino) el anillo de una estrella DEBIL (S/R a ojo de 12 a 20): a trozos (c3FaintDashStar); en el modo «dim» de antes, al 55 % (c3FaintKStar)
   if (!(this.mode === "dist" && ofObj(this.selObj, true)) && this.selStar >= 0 && stars[this.selStar]) mark(stars[this.selStar].x, stars[this.selStar].y, true, c3FaintKStar(stars[this.selStar]), c3FaintDashStar(stars[this.selStar]));
   if (!(this.mode === "dist" && ofObj(this.hoverObj, false)) && this.hoverStar >= 0 && this.hoverStar !== this.selStar && stars[this.hoverStar]) mark(stars[this.hoverStar].x, stars[this.hoverStar].y, false, c3FaintKStar(stars[this.hoverStar]), c3FaintDashStar(stars[this.hoverStar]));
};

// ---------------------------------------------------------------------------
// EXPORTAR la vista como imagen: a una vista nueva de PixInsight, o a un fichero
// (recuerda la ultima carpeta). Al doble de la escala de la pantalla.
// Devuelve { ok, kind, where, width, height, why }.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype.exportTo = function(kind) {
   var out = { ok: false, kind: String(kind), where: "", width: 0, height: 0, why: "" };
   this._animStop();
   if (this.mode === "" || this.state === null || !this.lay) { out.why = "nothing to export"; return out; }
   var k = 2, w = Math.round(this.lay.w * k), h = Math.round(this.lay.h * k), made = null;
   try {
      made = this.renderAt(w, h, this.lay.sc * k);
      var g = new Graphics(made.bitmap);
      try { g.antialiasing = true; this._drawMarks(g, made.lay, 1); } finally { g.end(); }
      out.width = w; out.height = h;
      var base = "Distances_" + String(this.state.title).replace(/[^A-Za-z0-9]+/g, "_").replace(/^_+|_+$/g, "");
      if (kind === "view") {
         var id = optUniqueId(base);
         var win = new ImageWindow(w, h, 3, 8, false, true, id);
         win.mainView.beginProcess(UndoFlag_NoSwapFile);
         try { win.mainView.image.blend(made.bitmap); } finally { win.mainView.endProcess(); }
         try { win.show(); } catch (eS) {}
         out.ok = true; out.where = win.mainView.id; out.window = win;
      } else {
         var path = null;
         if (typeof CP_SF_EXPORT_HOOK === "function") path = CP_SF_EXPORT_HOOK(kind, base + ".png");
         else {
            var sfd = new SaveFileDialog;
            sfd.caption = CP_TITLE + " — " + optT("Save the view as an image…");
            sfd.overwritePrompt = true;
            sfd.filters = [["PNG", "*.png"], ["JPEG", "*.jpg"]];
            var dir = cpSfUiLastDir();
            try { sfd.initialPath = (dir.length ? dir + "/" : "") + base + ".png"; } catch (eI) {}
            path = sfd.execute() ? String(sfd.fileName) : null;
         }
         if (path === null || String(path).length === 0) { out.why = "cancelled"; return out; }
         path = String(path).split("\\").join("/");
         if (!/\.(png|jpg|jpeg|tif|tiff|bmp)$/i.test(path)) path += ".png";
         made.bitmap.save(path);
         out.ok = File.exists(path); out.where = path;
         if (out.ok) cpSfUiRememberDir(path.substring(0, path.lastIndexOf("/")));
      }
   } catch (e) {
      out.why = String(e.message || e);
   } finally {
      try { if (made && made.bitmap) made.bitmap.clear(); } catch (e2) {}
   }
   if (out.ok) this._say(format(optT("Exported: %s (%d × %d px)"), out.where, w, h), "ok");
   else if (out.why !== "cancelled") this._say(optT("Could not export the view") + ": " + out.why, "error");
   return out;
};

CPStarfieldDock.prototype.retranslate = function() {
   this.btnPersp.text = optT("Perspective"); this.btnSide.text = optT("Side");
   this.btnLog.text = optT("Log"); this.btnSeg.text = optT("Segments");
   this.btnLy.text = optT("ly"); this.btnPc.text = optT("pc");
   this.btnToView.text = optT("To view"); this.btnToFile.text = optT("To file…"); this.btnNebula.text = optT("Nebula…");
   try { this.btnErr.text = optT("± Uncertainty"); this.btnUnseen.text = optT("Also what your photo doesn't show"); } catch (eE) {}
   var all = [this.btnPersp, this.btnSide, this.btnLog, this.btnSeg, this.btnLy, this.btnPc, this.btnNebula, this.btnErr, this.btnUnseen, this.btnToView, this.btnToFile];
   for (var i = 0; i < all.length; ++i) { try { all[i].toolTip = cpTooltip(all[i].cpTipKey); } catch (e) {} }
   try { this.zoomSlider.toolTip = cpTooltip("sf.zoom"); this.zoomLabel.toolTip = cpTooltip("sf.zoom"); this.zoomLabel.text = optT("Zoom"); } catch (eZt) {}
   this._flightRetranslate();
   this._fsRetranslate();
   try { this.starsLabel.text = optT("Stars"); this.starsLabel.toolTip = cpTooltip("sf.stars"); this.starsCombo.toolTip = cpTooltip("sf.stars"); this._starsItems(); } catch (eSt) {}
   this._syncButtons();
   if (this.state) { for (var k = 0; k < this._kept.length; ++k) { this._kept[k].dist = null; } }
   if (this.mode !== "") { this._render(); if (this.state) this._sayState(); }
};

// ===========================================================================
// LAS TRANSICIONES ANIMADAS (13-oct-2026)
// ---------------------------------------------------------------------------
// De una vista a otra, cada estrella viaja de su sitio en la de salida a su sitio
// en la de llegada. Tres estados: FOTO (el panel cerrado: cada estrella en su sitio
// de la imagen) y 3D (Distances). Quien cambia de vista hace siempre lo mismo:
//     var snap = this._animSnap();     // lo que se enseña AHORA
//     … cambia el estado …  this._render();     // el dibujo DEFINITIVO, como siempre
//     this._animGo( snap );            // de lo de antes a lo de ahora
// Con las transiciones apagadas `_animSnap` da null y `_animGo( null )` no hace nada:
// el camino de siempre, sin tocar.
// DOS CLASES de transicion:
//   · "points": cada punto va en un arco de su pixel de salida a su pixel de llegada
//     (`cpSvTransPair`, `cpSvTransAt`). Perspectiva ↔ lateral, logaritmica ↔ por tramos.
//   · "camera": la que se mueve es la CAMARA y los objetos se proyectan en cada
//     fotograma (`cpSvDistViewLerp`). FOTO ↔ 3D —la camara se pone de frente y la caja
//     se aplasta sobre la foto, o la foto «se abre» en profundidad— y reponer la vista 3D.
// CAPAS de un fotograma (`cpSvAnimLayers`): el decorado de la salida que se va y el de
// la llegada que viene (sin estrellas), las estrellas, y encima el dibujo de salida
// ENTERO (solo al principio) y el DEFINITIVO de llegada (solo al final). Por eso el
// primer fotograma es el dibujo de salida y el ultimo es el definitivo, sin salto.
// EL TIC: `animTimer` (periodico) → `_animTick` → `_animFrame( tau )` pinta en un
// bitmap y repinta el lienzo. En `onPaint` no se calcula nada: se copia ese bitmap.
// ===========================================================================
function cpSfUiFree(b) { try { if (b) b.clear(); } catch (e) {} }

// ¿Se anima? Ni en una pasada sin pantalla (la costura), ni en la zona tranquila, ni con una
// consulta de red en marcha (tiene la interfaz parada a tramos de medio segundo: iria a saltos).
CPStarfieldDock.prototype._animOn = function() {
   return CP_SF_ANIM === true && !this._closed && !this._netBusy && !cpQuiet();
};
// Cortar la transicion en marcha y dejar el estado FINAL (una pulsacion, la rueda, otro boton).
CPStarfieldDock.prototype._animStop = function() {
   this._animOpenAt = 0;
   if (this.anim !== null) this._animEnd();
};
// Fuera la transicion, sin pintar: el lienzo se queda con un dibujo ENTERO (el definitivo de la
// llegada; si se estaba cerrando, el de salida).
CPStarfieldDock.prototype._animDrop = function() {
   var an = this.anim;
   this._animPending = false;
   if (an === null) return;
   this.anim = null;
   try { this.animTimer.stop(); } catch (e) {}
   if (this.frame === an.buf) this.frame = an.final;
   cpSfUiFree(an.buf); cpSfUiFree(an.fromShot); cpSfUiFree(an.toShot); cpSfUiFree(an.chromeA); cpSfUiFree(an.chromeB);
   this.lastAnim = { kind: an.kind, frames: an.frames, ms: CP_SF_ANIM_CLOCK() - an.t0, points: an.tr ? an.tr.shown : (an.model ? an.model.objects.length : 0), close: an.close };
};
// La transicion acaba (o se corta): queda el dibujo definitivo, y lo que esperaba a que acabase.
CPStarfieldDock.prototype._animEnd = function() {
   var an = this.anim;
   if (an === null) return;
   this._animDrop();
   if (an.close) { this.close(); return; }
   try { this.canvas.repaint(); } catch (e) {}
   this._netArm();
};
CPStarfieldDock.prototype._animFreeSnap = function(snap) {
   if (!snap) return;
   cpSfUiFree(snap.shot); cpSfUiFree(snap.chrome); cpSfUiFree(snap.chrome0);
   snap.shot = null; snap.chrome = null; snap.chrome0 = null;
};

// Un dibujo con sus marcas (la ficha, los anillos de lo elegido): lo que el lienzo enseña de verdad.
CPStarfieldDock.prototype._shot = function(frame, lay) {
   var b = new Bitmap(frame.width, frame.height), g = new Graphics(b);
   try {
      g.drawBitmap(0, 0, frame);
      g.antialiasing = true;
      try { g.textAntialiasing = true; } catch (eT) {}
      this._drawMarks(g, lay, 1);
   } finally { g.end(); }
   return b;
};
// La escena de un dibujo hecho: quien hay y en que pixel.
CPStarfieldDock.prototype._sceneOf = function(lay) {
   var gold = cpHexRgb(CP_ATLAS.gold), blue = cpHexRgb(CP_ATLAS.chart[1]);
   return cpSvSceneOfDist(lay.model, lay.proj, lay.sc, (gold[0] << 16) | (gold[1] << 8) | gold[2], (blue[0] << 16) | (blue[1] << 8) | blue[2]);
};
// EL ESTADO «FOTO»: la foto encajada en el lienzo (con su margen) y cada punto en su sitio de la imagen.
// (Dentro del AREA DE DIBUJO de la vista —bajo la cabecera, sobre la leyenda—: la foto no se mete bajo el titulo.)
CPStarfieldDock.prototype._fotoPad = function(lay) {
   var a = lay.area, p = Math.round(CP_SFUI.GAP * lay.sc);
   return { x: a.x, y: a.y + p, w: Math.max(20, a.w), h: Math.max(20, a.h - 2 * p) };
};
CPStarfieldDock.prototype._photoScene = function(scene, pad, sc) {
   var st = this.state, model = this._distModel(), uv = cpSvSceneUv(scene, st.result.stars, st.result.field, model);
   return cpSvSceneOnPhoto(scene, uv.U, uv.V, cpSvPhotoRect(model, pad), model.wn, model.hn, 0.8 * sc);
};
CPStarfieldDock.prototype._fotoChrome = function(w, h, sc, pad) {
   var b = new Bitmap(w, h), r = cpSvPhotoRect(this._distModel(), pad), ph = this.state.photo;
   b.fill(CP_INT_SURFACE);
   var g = new Graphics(b);
   try {
      if (ph) { g.smoothInterpolation = true; g.drawScaledBitmap(new Rect(r.x, r.y, r.x + r.w, r.y + r.h), ph); }
      else g.fillRect(new Rect(r.x, r.y, r.x + r.w, r.y + r.h), new Brush(CP_INT_BG));
      g.antialiasing = true;
      g.pen = new Pen(CP_INT_AMBER, Math.max(1, sc)); g.brush = new Brush(0x00000000);
      g.drawRect(r.x, r.y, r.x + r.w, r.y + r.h);
   } finally { g.end(); }
   return b;
};

// LO QUE SE ENSEÑA AHORA, guardado para salir de ello: el dibujo con sus marcas, su decorado sin
// estrellas y su escena. Con el panel cerrado, { kind: "foto" }. null = no hay transicion (apagadas,
// o no hay de donde salir). Si da algo, el `_render` que venga despues NO se enseña: lo enseña la
// transicion (hay que llamar a `_animGo` SIEMPRE despues).
CPStarfieldDock.prototype._animSnap = function() {
   if (this.anim !== null) this._animEnd();
   if (!this._animOn()) return null;
   if (this.mode === "") { this._animPending = true; return { kind: "foto" }; }
   var lay = this.lay;
   if (!this.frame || !lay || this.state === null || lay.kind !== "dist") return null;
   var snap = { kind: lay.kind, lay: lay, state: this.state, w: lay.w, h: lay.h, sc: lay.sc, shot: null, chrome: null, chrome0: null, scene: null };
   try {
      snap.scene = this._sceneOf(lay);
      snap.shot = this._shot(this.frame, lay);
      snap.chrome = this.renderAt(lay.w, lay.h, lay.sc, { noObjects: true }).bitmap;
      if (lay.kind === "dist" && lay.fit.mode === "perspective") snap.chrome0 = this.renderAt(lay.w, lay.h, lay.sc, { noBody: true }).bitmap;
   } catch (e) { this._animFreeSnap(snap); return null; }
   this._animPending = true;
   return snap;
};

// ARRANCAR la transicion de `snap` al dibujo que hay ahora (o, con `opts.close`, del dibujo que hay
// a la foto, y cerrar). Devuelve true si arranca; si no (apagadas, nada que mover, otro tamaño), el
// lienzo enseña el dibujo definitivo como siempre.   opts = { close, ms, t0 }
CPStarfieldDock.prototype._animGo = function(snap, opts) {
   var o = opts || {}, was = this._animPending, ok = false;
   this._animPending = false;
   if (!snap) return false;
   try { ok = this._animOn() && this._animBuild(snap, o); } catch (e) { ok = false; this._animDrop(); }
   this._animFreeSnap(snap);
   if (ok) return true;
   // (abriendo, y el lienzo aun no tiene su tamaño: la transicion arranca en cuanto lo tenga: `_render`)
   if (snap.kind === "foto" && o.close !== true && !(o.t0 > 0) && this._animOn() && !(this.frame && this.lay && this.lay.w > 8)) this._animOpenAt = CP_SF_ANIM_CLOCK();
   if (was) { try { this.canvas.repaint(); } catch (e2) {} }
   return false;
};
CPStarfieldDock.prototype._animBuild = function(snap, o) {
   var lay = this.lay, st = this.state;
   if (!this.frame || !lay || st === null || lay.kind !== "dist") return false;
   var w = lay.w, h = lay.h, sc = lay.sc, close = (o.close === true), now = CP_SF_ANIM_CLOCK();
   if (this.frame.width !== w || this.frame.height !== h) return false;
   if (snap.kind !== "foto" && (snap.w !== w || snap.h !== h || snap.state !== st)) return false;
   function take(key) { var b = snap[key]; snap[key] = null; return b; }
   var an = { kind: "points", close: close, fromFoto: (snap.kind === "foto"), w: w, h: h, sc: sc, ms: (o.ms > 0) ? o.ms : CP_SV.ANIM_MS, t0: (o.t0 > 0) ? o.t0 : now, frames: 0, tau: 0,
              final: this.frame, buf: null, fromShot: null, toShot: null, chromeA: null, chromeB: null, tr: null, out: null, dots: 0,
              model: null, scale: null, all: { x: 0, y: 0, w: w, h: h }, move: false, toPhoto: false, viewA: null, viewB: null, chromeFade: "" };
   if (now - an.t0 >= an.ms) return false;
   var cam3d = (lay.kind === "dist" && lay.fit.mode === "perspective"), pad = this._fotoPad(lay);
   if (close || snap.kind === "foto") {
      // UN EXTREMO ES LA FOTO
      if (cam3d) {
         // la camara se pone de frente y la caja se aplasta sobre la foto (o al reves: la foto se abre)
         an.kind = "camera"; an.model = lay.model; an.scale = lay.scale; an.toPhoto = close;
         an.viewA = lay.fit.view; an.viewB = cpSvDistPhotoView(lay.model, pad);
         an.chromeA = close ? take("chrome0") : this.renderAt(w, h, sc, { noBody: true }).bitmap;
         an.chromeFade = close ? "out" : "in";
      } else {
         var here = close ? snap.scene : this._sceneOf(lay), foto = this._photoScene(here, pad, sc);
         an.tr = close ? cpSvTransPair(here, foto) : cpSvTransPair(foto, here);
         if (close) { an.chromeA = take("chrome"); an.chromeB = this._fotoChrome(w, h, sc, pad); }
         else { an.chromeA = this._fotoChrome(w, h, sc, pad); an.chromeB = this.renderAt(w, h, sc, { noObjects: true }).bitmap; }
      }
      if (close) an.fromShot = take("shot"); else an.toShot = this._shot(this.frame, lay);
   } else {
      var old = snap.lay;
      if (cam3d && old.kind === "dist" && old.fit.mode === "perspective" && old.scale.mode === lay.scale.mode && old.scale.unit === lay.scale.unit) {
         // la misma caja desde otra vista: se mueve la camara
         if (cpSvDistViewEqual(old.fit.view, lay.fit.view)) return false;
         an.kind = "camera"; an.move = true; an.model = lay.model; an.scale = lay.scale; an.viewA = old.fit.view; an.viewB = lay.fit.view;
         an.chromeA = take("chrome0");
      } else {
         var A = snap.scene, B = this._sceneOf(lay);
         an.tr = cpSvTransPair(A, B);
         if (old.kind === lay.kind && an.tr.maxMove < 1) return false;        // nada se mueve: no hay nada que animar
         an.chromeA = take("chrome"); an.chromeB = this.renderAt(w, h, sc, { noObjects: true }).bitmap;
      }
      an.fromShot = take("shot"); an.toShot = this._shot(this.frame, lay);
   }
   an.buf = new Bitmap(w, h);
   this.anim = an;
   this.frame = an.buf;
   this._animOpenAt = 0;
   this._animFrame(Math.max(0, (now - an.t0) / an.ms));
   try { this.canvas.repaint(); } catch (e) {}
   try { this.animTimer.start(); } catch (e2) {}
   return true;
};

// UN TIC: el fotograma que toca segun el reloj; pasado el final, el dibujo definitivo.
CPStarfieldDock.prototype._animTick = function() {
   var an = this.anim;
   if (an === null) { try { this.animTimer.stop(); } catch (e) {} return; }
   var tau = (CP_SF_ANIM_CLOCK() - an.t0) / an.ms;
   if (!(tau < 1)) { this._animEnd(); return; }
   // (si un fotograma falla, la transicion se acaba ahi y queda el dibujo definitivo: el panel nunca se queda a medias)
   try { this._animFrame(Math.max(0, tau)); } catch (eF) { this._animEnd(); return; }
   ++an.frames;
   try { this.canvas.repaint(); } catch (e2) {}
};

// EL FOTOGRAMA del instante `tau` (0…1), pintado en el bitmap de la transicion (que es el que copia
// `onPaint`). Con 0 es el dibujo de salida y con 1 el definitivo. Devuelve ese bitmap (no se libera).
CPStarfieldDock.prototype._animFrame = function(tau) {
   var an = this.anim;
   if (an === null) return null;
   var L = cpSvAnimLayers(tau), w = an.w, h = an.h;
   // (1-nov-2026, E2) las estrellas de la transicion se recortan al area de la escena (`lay.clip`, como las marcas): no cruzan la leyenda ni la ficha. Costura del rojo: C3_ANIM_CLIP = false
   var animClip = (C3_ANIM_CLIP !== false && this.lay && this.lay.clip && this.lay.w === w && this.lay.h === h) ? this.lay.clip : null;
   an.buf.fill(CP_INT_SURFACE);
   var g = new Graphics(an.buf);
   try {
      g.antialiasing = true;
      if (an.kind === "camera") {
         var ca = (an.chromeFade === "out") ? L.chromeA : (an.chromeFade === "in") ? L.chromeB : 1, view;
         if (an.chromeA && ca > 0.004) { g.opacity = ca; g.drawBitmap(0, 0, an.chromeA); g.opacity = 1; }
         if (an.move) view = cpSvDistViewLerp(an.viewA, an.viewB, cpSvEase(tau));
         else { var pt = cpSvPhotoTau(an.toPhoto ? tau : 1 - tau); view = cpSvDistViewLerp(an.viewA, an.viewB, pt.turn, pt.flat); }
         var fit = cpSvDistCam(an.model, an.all, view), proj = cpSvDistProject(an.model, an.scale, fit), hid = 1 - view.flat;
         // (en el estado FOTO la foto se ve tal cual: los objetos aparecen al abrirse la caja y se apagan al posarse)
         // (con muchas estrellas, el mismo tope que al girar: el ultimo tramo funde con el dibujo entero —`toShot`—, asi que las que
         // faltan aparecen al posarse. MEDIDO en las Pleyades: 44 ms por fotograma, 20 por segundo, con las 25 700)
         if (animClip) g.clipRect = new Rect(animClip.x, animClip.y, animClip.x + animClip.w, animClip.y + animClip.h);
         an.dots = this._distBody(g, an.model, an.scale, fit, proj, an.sc, an.all, { alpha: 1 - hid * hid * hid, lod: (CP_SFUI_LOD_ANIM === true) ? CP_SFUI_LOD_STARS : 0 }).drawn.members;
         if (animClip) g.clipRect = new Rect(0, 0, w, h);
      } else {
         // el decorado se CRUZA: el de llegada debajo, entero; el de salida encima, yendose (lo comun a los dos no se apaga)
         if (an.chromeB) g.drawBitmap(0, 0, an.chromeB);
         if (an.chromeA && L.cross > 0.004) { g.opacity = L.cross; g.drawBitmap(0, 0, an.chromeA); }
         g.opacity = 1;
         an.out = cpSvTransAt(an.tr, tau, an.out);
         if (animClip) g.clipRect = new Rect(animClip.x, animClip.y, animClip.x + animClip.w, animClip.y + animClip.h);
         an.dots = this._drawDots(g, an.tr, an.out, w, h);
         if (animClip) g.clipRect = new Rect(0, 0, w, h);
      }
      if (an.fromShot && L.from > 0.004) { g.opacity = L.from; g.drawBitmap(0, 0, an.fromShot); }
      if (an.toShot && L.to > 0.004) { g.opacity = L.to; g.drawBitmap(0, 0, an.toShot); }
      g.opacity = 1;
   } finally { g.end(); }
   an.tau = tau;
   return an.buf;
};
// Las estrellas de un fotograma, con su opacidad DE VERDAD y con la forma que tienen en el dibujo (`_dot`; el aspa
// de una distancia dudosa; el anillo de las del grupo que va en anillo, que se rellena si va hacia un punto).
CPStarfieldDock.prototype._drawDots = function(g, T, o, w, h) {
   var n = T.n, drawn = 0, nullPen = new Pen(0x00000000, 0), plain = false, lw = Math.max(1, 0.8 * this.anim.sc), err = cpHexRgb(CP_ATLAS.error), errRgb = (err[0] << 16) | (err[1] << 8) | err[2];
   var clear = new Brush(0x00000000);
   for (var i = 0; i < n; ++i) {
      if (!T.draw[i]) continue;
      var a = o.a[i];
      if (a < 0.04) continue;
      var x = o.x[i], y = o.y[i];
      if (x < -6 || y < -6 || x > w + 6 || y > h + 6) continue;
      var r = o.size[i], mark = T.mark[i];
      if (mark === 0) {
         if (!plain) { g.pen = nullPen; plain = true; }
         this._dot(g, x, y, r, this._brush(o.rgb[i], a));
      } else if (mark === 2) {
         var c = 1.2 * r;
         g.pen = this._pen(errRgb, 0.5 * a, lw); plain = false;
         g.drawLine(x - c, y - c, x + c, y + c); g.drawLine(x - c, y + c, x + c, y - c);
      } else {
         var hol = o.hollow[i];
         g.pen = this._pen(o.rgb[i], a * Math.min(1, 0.25 + hol), lw); plain = false;
         g.brush = (hol > 0.97) ? clear : this._brush(o.rgb[i], a * (1 - hol));
         g.drawCircle(x, y, r);
      }
      ++drawn;
   }
   return drawn;
};

// LA ✕: una transicion corta de vuelta a la foto —cada estrella cae a su sitio de la imagen— y el
// panel se cierra. Una segunda pulsacion, o cualquier otra, lo cierra en el acto; sin transiciones,
// se cierra sin mas.
CPStarfieldDock.prototype.closeAnimated = function() {
   if (this.mode === "") return;
   if (this.anim !== null) { this.close(); return; }
   var snap = this._animSnap();
   if (snap === null || !this._animGo(snap, { close: true, ms: CP_SV.ANIM_SHORT_MS })) this.close();
};
