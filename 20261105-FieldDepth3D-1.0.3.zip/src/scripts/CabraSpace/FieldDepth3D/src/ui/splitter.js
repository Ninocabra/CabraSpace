// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/splitter.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/splitter.js — separador arrastrable entre paneles (código nuevo)
// ----------------------------------------------------------------------------
// PJSR no tiene un widget splitter (solo Sizer/HorizontalSizer/VerticalSizer),
// así que se implementa como un Control estrecho con cursor de redimensión que
// ajusta el ancho fijo del panel contiguo mientras se arrastra.
// ES5.
// ============================================================================

var CP_SPLIT_W = cpDp(7);      // (píxeles físicos de la maqueta, a la escala de CabraPilot)

// opts = { target, invert, min, max, onResized }
//   target   : control cuyo ancho se ajusta
//   invert   : true si arrastrar a la derecha debe REDUCIR el objetivo
//              (caso del panel derecho)
//   min/max  : límites de ancho
//   onResized: callback tras cada ajuste
// Cuerpo ES5; la declaración `class … extends Control` va al final (bajo V8 el
// constructor del núcleo no se puede invocar sin `new`; ver ui/main_dialog.js).
function cpInitSplitter(parent, opts) {
   var self = this;
   this.target = opts.target;
   this.invert = (opts.invert === true);
   this.minW = opts.min || 200;
   this.maxW = opts.max || 640;
   this.onResized = opts.onResized || null;
   // Modo VERTICAL: el separador es horizontal y lo que ajusta es la ALTURA.
   // Lo pide la barra de imagenes, para poder agrandar las fichas.
   this.vertical = (opts.vertical === true);
   this._dragging = false;
   this._globalX0 = 0;
   this._w0 = 0;
   this._hover = false;

   if (this.vertical) {
      this.setFixedHeight(CP_SPLIT_W);
      this.cursor = new Cursor(StdCursor_VerticalSize);
   } else {
      this.setFixedWidth(CP_SPLIT_W);
      // OJO: la constante es StdCursor_HorizontalSize; StdCursor_SizeHor NO
      // existe en PJSR (verificado en include/pjsr/StdCursor.jsh).
      this.cursor = new Cursor(StdCursor_HorizontalSize);
   }
   this.toolTip = cpTooltip("ui.splitter");

   this.onPaint = function(x0, y0, x1, y1) {
      if (cpQuiet()) return;
      var g = new Graphics(this);
      try {
         g.fillRect(new Rect(0, 0, this.width, this.height), new Brush(CP_INT_BG));
         // Tres puntos centrales: la señal universal de "arrastrable".
         var cx = Math.round(this.width / 2);
         var cy = Math.round(this.height / 2);
         var col = self._dragging ? CP_INT_AMBER : (self._hover ? CP_INT_AMBER : CP_INT_BORDER);
         for (var i = -1; i <= 1; ++i) {
            if (self.vertical)
               g.fillRect(new Rect(cx + i * 8 - 1, cy - 1, cx + i * 8 + 1, cy + 1), new Brush(col));
            else
               g.fillRect(new Rect(cx - 1, cy + i * 8 - 1, cx + 1, cy + i * 8 + 1), new Brush(col));
         }
      } finally {
         g.end();
      }
   };

   this.onEnter = function() { if (cpQuiet()) return; self._hover = true; self.repaint(); };
   this.onLeave = function() { if (cpQuiet()) return; self._hover = false; self.repaint(); };

   this.onMousePress = function(x, y, button, buttons, modifiers) {
      self._dragging = true;
      self._globalX0 = self.vertical ? self._globalY(y) : self._globalX(x);
      self._w0 = self.vertical ? self.target.height : self.target.width;
      self.repaint();
   };

   this.onMouseMove = function(x, y, buttons, modifiers) {
      if (cpQuiet()) return;
      if (!self._dragging)
         return;
      var d = (self.vertical ? self._globalY(y) : self._globalX(x)) - self._globalX0;
      var w = self._w0 + (self.invert ? -d : d);
      w = Math.max(self.minW, Math.min(self.maxW, Math.round(w)));
      try {
         if (self.vertical) self.target.setFixedHeight(w);
         else self.target.setFixedWidth(w);
      } catch (e) {}
      if (self.onResized)
         self.onResized(w);
   };

   this.onMouseRelease = function(x, y, button, buttons, modifiers) {
      self._dragging = false;
      self.repaint();
      if (self.onResized)
         self.onResized(self.vertical ? self.target.height : self.target.width);
   };
}
class CPSplitter extends Control {
   constructor(parent, opts) { super(parent); cpInitSplitter.call(this, parent, opts); }
}

CPSplitter.prototype._globalX = function(x) {
   try {
      return this.localToGlobal(new Point(x, 0)).x;
   } catch (e) {
      return x;
   }
};

CPSplitter.prototype._globalY = function(y) {
   try {
      return this.localToGlobal(new Point(0, y)).y;
   } catch (e) {
      return y;
   }
};
