// ============================================================================
// ui/photo_view.js — LA FOTO de Cabra3D: el visor a la izquierda del panel (14-oct-2026)
// ----------------------------------------------------------------------------
// En CabraPilot el panel de «Distances» vive junto a SU visor (un
// control grande heredado de PI Workflow, con mipmaps, mosaico, split…). Cabra3D solo
// necesita lo que el panel le pide a ese visor, y esto es eso, minimo:
//   bitmap, grid (siempre false), scale (pixeles de pantalla por pixel del bitmap),
//   imageCoordScaleX/Y (pixeles de imagen por pixel del bitmap), viewport (el lienzo:
//   el panel le pide `repaint()`), setBusy( on, texto ).
// Y lo de un visor: encaje, rueda = zoom hacia el cursor, arrastrar = desplazar, doble
// clic = encajar, clic = elegir la estrella (el enlace foto -> panel). EL ZOOM PERSISTE
// mientras la imagen no cambia (al abrir el panel, al cambiar de vista, a pantalla
// completa): solo lo repone el doble clic.
// AL CAMBIAR EL TAMAÑO DEL VISOR (ventana, maximizar, separador, abrir o cerrar el 3D, pantalla completa; 21-oct, Nino:
// «si amplio un punto, ese zoom tiene que quedarse en ese punto»): en estado «encajada» se vuelve a encajar y CENTRAR; con zoom
// o desplazamiento del usuario se conserva el MISMO factor y el MISMO punto de la imagen en el centro del visor (`cx`,`cy`, en
// pixeles del bitmap; solo los toca el usuario —rueda, arrastre, encajar—, nunca el cambio de tamaño ni el recorte).
// «ENCAJAR» con el 3D ABIERTO (`cover`, lo pone el dialogo; 21-oct, Nino: «quita las franjas vacias arriba y abajo de la foto»): la foto
// CUBRE el visor —lo que sobra en un eje se recorta, centrado, y se alcanza arrastrando— en vez de dejar franjas; el dialogo ya
// calcula el ancho del panel para que casi no haya recorte (`_fitPhoto`). Con el 3D cerrado, la foto entera como siempre.
// LA BARRA DE PROGRESO va DENTRO del visor, en su borde de abajo, pintada encima: no
// aparece ni empuja nada (criterio §11.3).
// Sin subclase de widget (un Control con sus manejadores). Medidas de Atlas. ES5.
// ============================================================================

var C3_PV = {
   MAX_SIDE: 2400,          // lado mayor del bitmap de la foto (la imagen se reduce por un entero hasta caber)
   ZOOM_MIN: 0.05, ZOOM_MAX: 16,
   BUSY_H: CP_ATLAS.space[5]  // alto de la franja de progreso (pixeles logicos)
};

var C3_PAINT_GUARD = true;      // la costura del rojo de tests/c3_paint_crash.js (C3_PAINT_MUTATE=1): apagada, el onPaint de la foto deja bombear eventos dentro
function C3PhotoView(dialog, parent) {
   var self = this;
   this.dialog = dialog;
   this.view = null;            // la vista de PixInsight que se enseña
   this.bitmap = null;
   this.grid = false;
   this.scale = 1; this.sx = 0; this.sy = 0;
   this.imageCoordScaleX = 1; this.imageCoordScaleY = 1;
   this.cover = false;          // el 3D está abierto (lo pone el diálogo). Solo cuenta con la costura roja C3_PHOTO_COVER: «encajar» = CUBRIR el visor en vez de enseñar la foto entera
   this.fitted = true;          // el zoom sigue al tamaño del visor hasta que el usuario lo toca
   this.cx = 0; this.cy = 0;    // el punto de la imagen (pixeles del bitmap) que el usuario tiene en el CENTRO del visor
   this.busy = null;            // { text, t0 }
   this._drag = null;
   this.viewport = new Control(parent);
   this.control = this.viewport;
   cpApplyStyle(this.viewport, "background-color:" + CP_ATLAS.bg + "; border:1px solid " + CP_ATLAS.line + ";");
   try { this.viewport.setMinSize(cpUiPx(CP_ATLAS.space[9] * 2, this.viewport), cpUiPx(CP_ATLAS.space[9] * 2, this.viewport)); } catch (eMin) {}
   try { this.viewport.mouseTracking = true; } catch (eT) {}
   // (26-oct-2026, el cuelgue de Nino «C0000005 … photo_view.js:185 g.antialiasing»: el primer pintado tras cambiar las estrellas mide el desfase local
   // —cshDepthSeeing, con cshYield— y, con la red en vivo, eso atendia eventos DENTRO de este onPaint; Qt pintaba otro control de la ventana y
   // dejaba a este Graphics sin estado. Mientras se pinta, CSH_PAINTING > 0: nadie bombea. C3_PAINT_GUARD = false es la costura del rojo de
   // tests/c3_paint_crash.js.)
   this.viewport.onPaint = function(x0, y0, x1, y1) {
      if (C3_PAINT_GUARD !== true || typeof CSH_PAINTING !== "number") { self._paint(); return; }
      ++CSH_PAINTING;
      try { self._paint(); } finally { --CSH_PAINTING; }
   };
   this.viewport.onResize = function() { self.relayout(); try { self.dialog.onPhotoResized(); } catch (eR) {} };
   this.curtainX = null; this.curtainFrac = 0.5; this._curtain = false;   // (31-oct-2026) la cortinilla de «Compare» (ui/photo_stars_overlay.js)
   this.viewport.onMousePress = function(x, y, button, buttons, modifiers) { if (self.curtainX !== null && Math.abs(x - self.curtainX) <= CSH_CURTAIN.GRAB * cpUiScale(self.viewport)) { self._curtain = true; return; } self._drag = { x: x, y: y, sx: self.sx, sy: self.sy, moved: false, button: button, modifiers: modifiers }; };
   this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
      if (self._curtain) { self.curtainFrac = cshCurtainClamp(x / Math.max(1, self.viewport.width)); self.viewport.repaint(); return; }
      var d = self._drag;
      if (!d) return;
      if (Math.abs(x - d.x) + Math.abs(y - d.y) > 3) d.moved = true;
      if (d.moved) { self.sx = d.sx - (x - d.x); self.sy = d.sy - (y - d.y); self.fitted = false; self._clamp(); self._noteCentre(); self.viewport.repaint(); }
   };
   this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
      if (self._curtain) { self._curtain = false; return; }
      var d = self._drag; self._drag = null;
      if (d && !d.moved && button === OPT_MOUSE_LEFT && (modifiers || 0) === 0) {
         var p = self.toImage(x, y);
         if (p !== null) { try { self.dialog.onImageClick(p.x, p.y); } catch (e) {} }
      }
   };
   this.viewport.onMouseDoubleClick = function() { self.fitted = true; self.fit(); };
   this.viewport.onMouseWheel = function(x, y, delta, buttons, modifiers) { self.zoomAt(x, y, (delta > 0) ? 1.25 : 0.8); };
   // (29-oct-2026, Nino) el reloj de «estoy pensando» sobre la foto (CabraShared/csh_busy.js; sin el include, nada). Se enciende
   // con setBusy (los pasos largos del panel, el vuelo, el polvo…) y con la red del panel (`_netBusy`, starfield_panel.js); CabraStarAnalysis pone los suyos.
   // (30-oct) En el CENTRO de la parte visible de la foto (`busyArea`); se engancha AL FINAL, cuando el visor ya tiene sus manejadores del raton
   // (el reloj ignora el ratón sobre sí mismo mientras está puesto).
   if (typeof cshBusyAttach === "function") cshBusyAttach(this.viewport, { area: function() { return self.busyArea(); } });
}

// (30-oct) Donde se centra el reloj de «pensando»: la parte visible de la foto en el visor (con zoom llena el visor; entera y mas pequeña, es la foto).
// null = sin foto (se usa el visor entero).
C3PhotoView.prototype.busyArea = function() {
   if (!this.bitmap || !(this.scale > 0)) return null;
   var w = this.viewport.width, h = this.viewport.height;
   return { x0: Math.max(0, -this.sx), y0: Math.max(0, -this.sy), x1: Math.min(w, this.bitmap.width * this.scale - this.sx), y1: Math.min(h, this.bitmap.height * this.scale - this.sy) };
};

// La imagen que se enseña (null = ninguna). Se pinta UNA vez aqui (nunca en onPaint).
C3PhotoView.prototype.setView = function(view, stretchMode) {
   cpSfUiFree(this.bitmap);
   this.bitmap = null; this.view = null;
   if (!optSafeView(view)) { this.viewport.repaint(); return; }
   var W = view.image.width, H = view.image.height, n = Math.max(1, Math.ceil(Math.max(W, H) / C3_PV.MAX_SIDE));
   this.view = view;
   this.bitmap = optRenderPreviewBitmap(view, n, stretchMode);
   this.reduction = n;
   this.imageCoordScaleX = W / Math.max(1, this.bitmap.width);
   this.imageCoordScaleY = H / Math.max(1, this.bitmap.height);
   this.fitted = true;
   this.fit();
};
// El factor del encaje: la foto ENTERA dentro del visor (franjas arriba y abajo, o a los lados, si el aspecto no casa).
// (28-oct-2026, H7, decisión de Nino, variante B: antes, con el 3D abierto, la foto CUBRÍA el visor y se recortaba —en un diálogo pequeño NGC 1560 se veía al
//  70,5 % del ancho—; ahora se ve entera con franjas y el 3D se queda en su ancho, 35–70 %. `C3_PHOTO_COVER` = true es lo de antes: rojo de las pruebas
//  tests/c3_photo_fill_errbars.js y c3_photo_zoom.js; `this.cover` lo pone el diálogo con el 3D abierto.)
var C3_PHOTO_COVER = false;
C3PhotoView.prototype._fitScale = function() {
   var a = this.viewport.width / this.bitmap.width, b = this.viewport.height / this.bitmap.height;
   return (this.cover && C3_PHOTO_COVER === true) ? Math.max(a, b) : Math.min(a, b);
};
C3PhotoView.prototype.fit = function() {
   if (!this.bitmap) { this.viewport.repaint(); return; }
   var w = this.viewport.width, h = this.viewport.height;
   if (!(w > 4 && h > 4)) return;
   this.scale = this._fitScale();
   this.sx =(this.bitmap.width * this.scale - w) / 2; this.sy = (this.bitmap.height * this.scale - h) / 2;
   this.fitted = true;
   this._noteCentre();
   this.viewport.repaint();
};
// El visor ha cambiado de tamaño (o el 3D se abre/cierra): encajada → se vuelve a encajar y centrar; con zoom del usuario →
// mismo factor y mismo punto de la imagen en el centro (si en un eje la imagen cabe entera, se centra en ese eje: `_clamp`).
// Sin proceso ninguno: solo aritmetica. Un tamaño degenerado (visor oculto o replegado) no toca nada.
C3PhotoView.prototype.relayout = function() {
   if (!this.bitmap) return;
   var w = this.viewport.width, h = this.viewport.height;
   if (!(w > 4 && h > 4)) return;
   if (this.fitted) { this.fit(); return; }
   this.sx = this.cx * this.scale - w / 2; this.sy = this.cy * this.scale - h / 2;
   this._clamp();
   this.viewport.repaint();
};
// Apunta que punto del bitmap esta ahora en el centro del visor (lo llaman la rueda, el arrastre y el encaje).
C3PhotoView.prototype._noteCentre = function() {
   if (!this.bitmap || !(this.scale > 0)) return;
   this.cx = (this.sx + this.viewport.width / 2) / this.scale;
   this.cy = (this.sy + this.viewport.height / 2) / this.scale;
};
// (lo que cabe se centra; lo que no, no se sale mas de media ventana). `soft` (la rueda acercando): lo que aun cabe NO se centra a la
// fuerza —eso mandaba el punto bajo el cursor lejos de el en los primeros pasos—, solo se deja entero dentro del visor.
C3PhotoView.prototype._clamp = function(soft) {
   if (!this.bitmap) return;
   var w = this.viewport.width, h = this.viewport.height, bw = this.bitmap.width * this.scale, bh = this.bitmap.height * this.scale;
   if (bw <= w) this.sx = soft ? Math.max(bw - w, Math.min(0, this.sx)) : (bw - w) / 2; else this.sx = Math.max(-w / 2, Math.min(bw - w / 2, this.sx));
   if (bh <= h) this.sy = soft ? Math.max(bh - h, Math.min(0, this.sy)) : (bh - h) / 2; else this.sy = Math.max(-h / 2, Math.min(bh - h / 2, this.sy));
};
C3PhotoView.prototype.zoomAt = function(x, y, factor) {
   if (!this.bitmap) return;
   var s0 = this.scale, s1 = Math.max(C3_PV.ZOOM_MIN, Math.min(C3_PV.ZOOM_MAX, s0 * factor));
   if (s1 === s0) return;
   var bx = (x + this.sx) / s0, by = (y + this.sy) / s0;
   this.scale = s1; this.sx = bx * s1 - x; this.sy = by * s1 - y;
   this.fitted = false;
   this._clamp(factor > 1);
   // (de vuelta justo al tamaño de encaje —p. ej. tras acercar y alejar la rueda lo mismo—: vuelve a ser «encajada»)
   var fs = this._fitScale();
   if (fs > 0 && Math.abs(s1 / fs - 1) < 0.002) { this.fit(); return; }
   this._noteCentre();
   this.viewport.repaint();
};
// De pantalla a imagen (null fuera de la foto) y al reves.
C3PhotoView.prototype.toImage = function(x, y) {
   if (!this.bitmap) return null;
   var bx = (x + this.sx) / this.scale, by = (y + this.sy) / this.scale;
   if (bx < 0 || by < 0 || bx > this.bitmap.width || by > this.bitmap.height) return null;
   return { x: bx * this.imageCoordScaleX, y: by * this.imageCoordScaleY };
};
C3PhotoView.prototype.toScreen = function(ix, iy) {
   return { x: ix / this.imageCoordScaleX * this.scale - this.sx, y: iy / this.imageCoordScaleY * this.scale - this.sy };
};

// LA BARRA DE PROGRESO, en el borde de abajo del visor (encima de la foto). `cancellable` no se usa (lo pide la firma).
C3PhotoView.prototype.setBusy = function(on, text, cancellable) {
   this.busy = on ? { text: String(text || ""), t0: (this.busy && this.busy.t0) ? this.busy.t0 : Date.now() } : null;
   if (typeof cshBusySet === "function") cshBusySet(this.viewport, "bar", !!on, { immediate: true });      // (el relojito: se ve YA, como la barra)
   try { this.viewport.repaint(); } catch (e) {}
   try { optProcessEvents(); } catch (e2) {}
};

C3PhotoView.prototype._paint = function() {
   var g = new Graphics(this.viewport), w = this.viewport.width, h = this.viewport.height, sc = cpUiScale(this.viewport);
   try {
      g.fillRect(new Rect(0, 0, w, h), new Brush(CP_INT_BG));
      if (this.bitmap) {
         var dim = 1;
         try { dim = this.dialog.photoDim(); } catch (eD) {}
         g.smoothInterpolation = (this.scale < 1);
         g.translateTransformation(-this.sx, -this.sy);
         g.scaleTransformation(this.scale, this.scale);
         g.drawBitmap(0, 0, this.bitmap);
         // (la maquina del tiempo: lejos de «ahora», la foto SIN estrellas encima —las estrellas son las que se mueven— y algo apagada)
         var mix = 0, sl = null;
         try { mix = this.dialog.photoMix(); sl = (mix > 0.004) ? this.dialog.photoStarless() : null; } catch (eM) {}
         if (sl) { g.smoothInterpolation = true; g.opacity = mix; g.drawScaledBitmap(new Rect(0, 0, this.bitmap.width, this.bitmap.height), sl); g.opacity = 1; }
         if (dim < 0.999) g.fillRect(new Rect(0, 0, this.bitmap.width, this.bitmap.height), new Brush(cpInt(CP_ATLAS.bg, 1 - dim)));
         g.resetTransformation();
         g.antialiasing = true;
         try { this.dialog.paintPhotoOverlay(g, this.scale, this.sx, this.sy); } catch (eO) { try { console.warningln("Cabra3D overlay: " + eO); } catch (eW) {} }
      } else {
         var F = cpFont("text", Math.round(12 * sc));
         g.font = F; g.pen = new Pen(CP_INT_MUTED);
         var t = optT("Choose an image above");
         g.drawText((w - F.width(t)) / 2, h / 2, t);
      }
      if (this.busy) {
         var bh = cpPx(C3_PV.BUSY_H, this.viewport), y0 = h - bh, Fb = cpFont("text", Math.round(10 * sc));
         g.antialiasing = false;
         g.fillRect(new Rect(0, y0, w, h), new Brush(cpInt(CP_ATLAS.bg, 0.88)));
         g.pen = new Pen(CP_INT_AMBER, Math.max(1, sc)); g.drawLine(0, y0, w, y0);
         // una barra que va y viene (no hay fraccion conocida: el proceso Gaia o la red no la dan)
         var period = 1600, ph = ((Date.now() - this.busy.t0) % period) / period, bw = w * 0.22, bx = (w + bw) * ph - bw;
         g.fillRect(new Rect(Math.max(0, bx), y0 + 1, Math.min(w, bx + bw), y0 + Math.max(2, Math.round(2 * sc)) + 1), new Brush(CP_INT_AMBER));
         g.antialiasing = true;
         g.font = Fb; g.pen = new Pen(CP_INT_TEXT);
         g.drawText(cpPx(CP_ATLAS.space[2], this.viewport), y0 + (bh + Fb.ascent) / 2, cpElide(Fb, this.busy.text, w - cpPx(CP_ATLAS.space[4], this.viewport)));
      }
   } finally { g.end(); }
};
C3PhotoView.prototype.cleanup = function() { if (typeof cshBusyOffAll === "function") cshBusyOffAll(this.viewport); cpSfUiFree(this.bitmap); this.bitmap = null; this.view = null; };
