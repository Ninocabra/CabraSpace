// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/ui/starfield_flight.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// ui/starfield_flight.js — EL VUELO por dentro de «Distances»: PURO
// ----------------------------------------------------------------------------
// Encargo de Nino (13-oct-2026): «permite grabar un video donde tu has definido
// las camaras y por donde vuelas por el interior de tu imagen… 3 paths ya
// preparados con efectos dignos de award. Lo mas facil posible, pero potente y
// bonito.» Aqui esta el VUELO, que es aritmetica y por eso node lo ejecuta entero
// (guardian L0-96, `_tests/cp_starfield_flight_cases.js`):
//
//   · la CAMARA DE UN VUELO: los mismos campos de `cpSvDistView` (giro, inclinacion,
//     travelin, pivote, aplastado) mas el OBJETIVO (`lens`) y el sitio del pivote en
//     el fotograma (`sx`, `sy`), los dos sin pixeles: el mismo vuelo vale a 720p y
//     a 4K (`cpFlCamToView`, `cpFlCamFromView`);
//   · un vuelo: fotogramas clave { t, cam, layers, visit, rest }, interpolados con
//     una cubica MONOTONA por canal (Fritsch-Carlson: la velocidad es continua y
//     NO hay rebote: una pausa es una pausa, la opacidad no sale de 0…1, el
//     travelin no se pasa de su tope); el giro, por el camino corto;
//   · `cpFlAt( vuelo, t )`: la camara y las capas en el segundo t. Determinista;
//   · TRES VUELOS PREPARADOS que se hacen A PARTIR DEL MODELO del campo
//     (`cpFlPreset`): «Dive», «Orbit» (bucle perfecto) y «Grand tour»;
//   · el vuelo PROPIO: añadir la vista actual, quitar, reordenar, la duracion, los
//     tiempos repartidos solos y JSON de ida y vuelta;
//   · los EFECTOS, como DATOS (`cpFlFrame`): fundidos, viñeta, estela de movimiento,
//     titulo, contador de distancia «desde casa» y la placa del objeto visitado. No
//     se pinta nada aqui: lo pinta `ui/starfield_flight_paint.js`;
//   · el PLAN de render (`cpFlPlan`): cuantos fotogramas, el segundo de cada uno,
//     cuanto pesara y cuanto tardara.
//
// NADA DE AQUI TOCA PixInsight (ni `Graphics`, ni `Bitmap`, ni `optT`, ni `File`).
// Usa `ui/starfield_view.js` (la camara, la escala, los destacados). ES5 puro.
// (OJO: ni `VERSION` ni `TITLE` como identificadores: son macros de ImageSolver.)
// ============================================================================

var CP_FL = {
   FORMAT: 1,                         // version del JSON de un vuelo
   ASPECT: 16 / 9,                    // diseño: el fotograma de un video
   DUR_DIVE: 21, DUR_ORBIT: 14, DUR_TOUR: 26, DUR_MIN: 2, DUR_MAX: 180,   // diseño (segundos)
   INTENSITY: 0.5,                    // diseño: «cuanto se mueve» de fabrica, de 0 a 1
   SEG_S: 3,                          // diseño: lo que dura de fabrica un tramo del vuelo propio
   MAX_KEYS: 64,                      // diseño
   // LA TRANSICION con que se LLEGA a una vista (editor de camaras, 20-oct-2026; peticion de Nino): "smooth" (la de siempre: velocidad
   // percibida constante, con arranque y frenada suaves en los extremos del vuelo), "out" (sale rapido y frena al llegar),
   // "in" (sale despacio y llega rapido), "linear" (velocidad constante en el tramo), "slow" (camara lenta: el tramo dura
   // SLOW_K veces mas y arranca y frena suave). Y una PAUSA de 0 a PAUSE_MAX segundos en la vista (la camara se queda).
   TRANS: ["smooth", "out", "in", "linear", "slow"], SLOW_K: 2.5, PAUSE_MAX: 10, PAUSES: [0, 1, 2, 3, 5],
   LABEL_MAX: 32,                     // diseño: letras del nombre que el usuario le puede dar a una vista (editor de camaras)
   CLUSTER_MEMBERS: 100,              // el cumulo es el protagonista del campo con al menos estos miembros (como el titulo del panel)
   // EL PROTAGONISTA, GRANDE EN CUADRO (14-oct-2026, vuelta 3): LO QUE BRILLA de un objeto (no su tamaño de catalogo) ocupa
   // esta fraccion del ALTO del cuadro cuando se le mira, sin pasar de LOOK_WIDTH del ancho (un video vertical, una galaxia
   // de canto) ni ampliar sus pixeles de imagen mas de LOOK_MAG veces en un video de LOOK_REF_H de alto (no pixelar); el
   // aro de un cumulo, entero dentro de LOOK_RING del alto.
   TOUR_FILL: 0.42, DIVE_FILL: 0.44,
   LOOK_WIDTH: 0.56, LOOK_MAG: 1.5, LOOK_REF_H: 1080, LOOK_MIN_FILL: 0.12, LOOK_RING: 0.9, LOOK_MAX: 40,
   // UNA PARADA ES PARA MIRAR ALGO. Un PUNTO (una estrella, un cuasar, una galaxia sin recorte) no es una parada: es un PASO
   // (la camara pasa a su lado sin detenerse, con su placa), que pesa TOUR_PASS de lo que un tramo. Y un objeto extenso
   // pequeño (pocos pixeles de imagen) se mira menos tiempo: de TOUR_DWELL_MIN a 1, lineal hasta TOUR_DWELL_PX pixeles.
   TOUR_PASS: 1.3, TOUR_DWELL_MIN: 0.35, TOUR_DWELL_PX: 300,
   // (vuelta 4) LA HONESTIDAD CON LOS PIXELES: un objeto no se amplia en cuadro mas de LOOK_MAG (1,5) veces sus pixeles de
   // imagen, en el alto del video que se graba (`opts.height`; sin el, LOOK_REF_H): mejor pequeño y nitido que grande y
   // blando. Y uno que no da señal (menos de VISIT_MIN_PX pixeles de imagen) NO se visita: es un paso, con su destello.
   VISIT_MIN_PX: 24,
   // UN ROTULO QUE APARECE SE LEE: la placa de un PASO esta a plena opacidad PASS_SHOW_S segundos alrededor de su clave
   PASS_SHOW_S: 2.2,
   COUNTER_N: 360,                    // muestras de la serie del contador, monotona por tramos (la hace cpFlPrepare)
   HOLD_S: 0.3,                       // una visita de menos de esto es un paso: no apaga las estelas
   FADE_FROM: 0.85,                   // diseño: el fundido de entrada (si se pide) no sale de negro puro
   MAX_STOPS: 5,                      // diseño: paradas del «Grand tour» (con mas, ninguna se llega a leer)
   // LA FOTO SE APAGA SOLA cuando la camara se le echa encima (a menos de NEAR1 lados de su rectangulo; del todo a
   // NEAR0): de cerca son cuatro pixeles enormes que tapan las estrellas. Visto en las tiras del primer render.
   PHOTO_NEAR0: 0.7, PHOTO_NEAR1: 1.6,
   OBJECTS_FLAT: 0.35,                // diseño: los objetos acaban de aparecer cuando la caja se ha abierto esta fraccion
   PHOTO_MIN_H: 0.42, PHOTO_CROP: 2,  // diseño: en un video estrecho la foto de frente ocupa al menos este alto, recortada por los lados (estas veces como mucho)
   PHOTO_FILL: 0.86,                  // diseño: la foto de frente llena esta fraccion del fotograma
   FIT_MARGIN: 0.05,                  // diseño: aire alrededor de la caja cuando se ve entera
   // LA «VELOCIDAD PERCIBIDA» de la camara: lo que se mueve el ojo (en lados de la foto) y, con estos pesos, lo que
   // gira (un radian cuenta como ANG_W lados), lo que se aplasta la caja y lo que cambia el objetivo. Diseño.
   ANG_W: 0.9, FLAT_W: 0.8, LENS_W: 0.5,
   LUT_N: 600,                        // muestras de la tabla de longitud de arco (velocidad constante)
   // --- los efectos (diseño: sobrios; el fundido y la viñeta son los de un plano de cine, no un filtro) ---
   FADE_IN_S: 0.7, FADE_OUT_S: 0.9,
   END_FADE_S: 0.5,                   // los vuelos preparados EMPIEZAN en la foto (sin fundido: es la miniatura del video) y acaban SOBRE la foto, de frente, con este fundido corto
   TRAIL_FLAT0: 0.5, TRAIL_FLAT1: 0.9,   // las estelas se apagan cuando la caja cae sobre la foto (la vuelta) : de FLAT1 de abierta a FLAT0
   VIGNETTE: 0.26,                    // oscurecimiento de las esquinas (0 = ninguno)
   TRAIL: 0.6,                        // opacidad maxima de la estela
   TRAIL_SHUTTER_S: 1 / 24,           // la estela une cada punto con donde estaba hace este tiempo (un obturador de cine)
   TRAIL_V0: 0.10, TRAIL_V1: 0.9,     // la estela empieza a verse a V0 de velocidad percibida por segundo y llega a su tope a V1
   GLOW: 0.5,                         // halo de los puntos cercanos (0 = ninguno); el tamaño y el brillo, de cpSvDepthSize / cpSvDepthDim
   TITLE_AT_S: 0.25, TITLE_IN_S: 0.6, TITLE_HOLD_S: 1.5, TITLE_OUT_S: 0.9,
   PLATE_FADE_S: 0.45,                // la placa del objeto visitado aparece y se va en este tiempo
   COUNTER_FADE_S: 0.5,
   // --- el plan de render -------------------------------------------------------
   FPS: [24, 30, 60],
   SIZES: [[1280, 720], [1920, 1080], [3840, 2160]],
   QUALITY: 92,
   // MEDIDO (portatil, 1.9.5 build 1706, `_tests/cp_starfield_flight_look.log`: 24 fotogramas de «Dive» sobre M 13 a
   // 1920 x 1080): bytes de JPEG por megapixel a calidad 85 / 92 / 97 = 80 266 / 104 652 / 159 961. Es el caso que MAS
   // pesa de los medidos (a 3840 x 2160, 54 253 / 68 933 / 102 887; con NGC 1560, un tercio menos): la cuenta peca de larga.
   JPEG_BYTES_PER_MPX: { 85: 80000, 92: 105000, 97: 160000 }
};

var CP_FL_COUNTER_STEPS = true;     // (el control de las pruebas: sin esto, el contador es solo el minimo / maximo de lo que queda)
var CP_FL_COUNTER_RAW = false;      // (el control de las pruebas: el contador dice el fondo del pivote tal cual, como antes)
var CP_FL_CAM_FIELDS = ["yaw", "pitch", "zoom", "ox", "oy", "oz", "flat", "lens", "sx", "sy"];
var CP_FL_KINDS = ["dive", "orbit", "tour", "user"];

// ---------------------------------------------------------------------------
// LA CAMARA DE UN VUELO
// ---------------------------------------------------------------------------
// { yaw (grados, SIN normalizar: 415 es una vuelta y 55), pitch, zoom, ox, oy, oz, flat: lo de `cpSvDistView`;
//   lens: el objetivo, en veces el del encuadre de fabrica (1 = la caja cabe en el fotograma; mas = teleobjetivo);
//   sx, sy: donde cae el pivote, desde el centro del fotograma, en ALTOS del fotograma (0 = centrado) }
function cpFlNum(x, d) { return (typeof x === "number" && isFinite(x)) ? x : d; }
function cpFlClamp(x, lo, hi) { return (x < lo) ? lo : (x > hi) ? hi : x; }
function cpFlCam(c) {
   var q = c || {}, D = CP_SV.DEPTH;
   return { yaw: cpFlNum(q.yaw, CP_SV.YAW), pitch: cpFlClamp(cpFlNum(q.pitch, CP_SV.PITCH), -CP_SV.PITCH_MAX, CP_SV.PITCH_MAX),
            zoom: cpFlClamp(cpFlNum(q.zoom, 1), CP_SV.DIST_ZOOM_MIN, CP_SV.DIST_ZOOM_MAX),
            ox: cpFlClamp(cpFlNum(q.ox, 0), -0.75, 0.75), oy: cpFlClamp(cpFlNum(q.oy, 0), -0.75, 0.75), oz: cpFlClamp(cpFlNum(q.oz, 0), -0.75 * D, 0.75 * D),
            flat: cpFlClamp(cpFlNum(q.flat, 1), 0, 1), lens: cpFlClamp(cpFlNum(q.lens, 1), 0.2, 8),
            sx: cpFlClamp(cpFlNum(q.sx, 0), -1, 1), sy: cpFlClamp(cpFlNum(q.sy, 0), -1, 1) };
}
function cpFlLayers(l) {
   var q = l || {};
   return { photo: cpFlClamp(cpFlNum(q.photo, 1), 0, 1), box: cpFlClamp(cpFlNum(q.box, 1), 0, 1) };
}
// El rectangulo de un fotograma de aspecto dado, con el alto como unidad.
function cpFlUnitRect(aspect) { return { x: 0, y: 0, w: (aspect > 0) ? aspect : CP_FL.ASPECT, h: 1 }; }
// El objetivo de referencia: pixeles por lado de la foto con los que la caja, en la pose de FABRICA, cabe en `rect`.
// (FIJO: el encaje del panel sigue a la pose —la caja se reencaja al girar—; en un vuelo eso «respira». Aqui la escala
// es siempre la de la pose de fabrica por `lens`, y el pivote va donde digan `sx`, `sy`.)
function cpFlRef(model, rect) { return cpSvDistFrame(model, rect, CP_SV.YAW, CP_SV.PITCH).f0; }
// De la camara del vuelo a la VISTA completa que entiende `cpSvDistCam( model, rect, vista )`.
function cpFlCamToView(cam, model, rect) {
   var c = cpFlCam(cam);
   return cpSvDistView({ yaw: c.yaw, pitch: c.pitch, zoom: c.zoom, ox: c.ox, oy: c.oy, oz: c.oz, flat: c.flat, f0: c.lens * cpFlRef(model, rect),
                         cx: rect.x + rect.w / 2 + c.sx * rect.h, cy: rect.y + rect.h / 2 + c.sy * rect.h });
}
// Y al reves: de una vista COMPLETA (la de `fit.view`: con f0, cx, cy) en su `rect` a la camara del vuelo.
// Es lo que hace «añadir la vista actual»: el vuelo guarda lo que el usuario VE, sin pixeles.
function cpFlCamFromView(view, model, rect) {
   var v = cpSvDistView(view), ref = cpFlRef(model, rect), fr = null;
   if (!(v.f0 > 0) || !isFinite(v.cx) || !isFinite(v.cy)) fr = cpSvDistFrame(model, rect, v.yaw, v.pitch);
   var f0 = (v.f0 > 0) ? v.f0 : fr.f0, cx = isFinite(v.cx) ? v.cx : fr.cx, cy = isFinite(v.cy) ? v.cy : fr.cy;
   return cpFlCam({ yaw: v.yaw, pitch: v.pitch, zoom: v.zoom, ox: v.ox, oy: v.oy, oz: v.oz, flat: v.flat, lens: f0 / ref,
                    sx: (cx - rect.x - rect.w / 2) / rect.h, sy: (cy - rect.y - rect.h / 2) / rect.h });
}
// LA FOTO DE FRENTE (el estado FOTO de las transiciones), como camara de un vuelo: llena PHOTO_FILL del fotograma.
function cpFlPhotoCam(model, aspect) {
   var R = cpFlUnitRect(aspect), m = (1 - CP_FL.PHOTO_FILL) / 2;
   // (vuelta 4) EN UN VIDEO MAS ESTRECHO QUE LA FOTO (vertical, cuadrado) la foto encajada a lo ancho es una franja con el
   // resto en negro: se acerca hasta ocupar PHOTO_MIN_H del alto, recortada por los lados (PHOTO_CROP veces como mucho).
   var fitH = CP_FL.PHOTO_FILL * (R.w / R.h) / (model.wn / model.hn), s = (fitH < CP_FL.PHOTO_MIN_H) ? Math.min(CP_FL.PHOTO_CROP, CP_FL.PHOTO_MIN_H / fitH) : 1;
   var w2 = R.w * (1 - 2 * m) * s, h2 = R.h * (1 - 2 * m) * s;
   var pv = cpSvDistPhotoView(model, { x: R.x + R.w / 2 - w2 / 2, y: R.y + R.h / 2 - h2 / 2, w: w2, h: h2 });
   return cpFlCamFromView(pv, model, R);
}
// La distancia de la camara a su pivote con zoom 1 (en lados de la foto).
function cpFlK0(model) { return CP_SV.CAM_DIST * cpSvBoxRadius(model || { wn: 1, hn: 1 }); }
// DONDE ESTA EL OJO, en la caja: { x, y, t (su fondo, 0 = el plano de la foto, 1 = el final; puede ser negativo:
// delante de la foto), zf (el fondo ya aplastado, en lados: lo que se usa para medir cuanto se mueve) }.
function cpFlEye(cam, k0) {
   var c = cpFlCam(cam), P = cpSvPose(c.yaw, c.pitch), K = k0 / c.zoom, D = CP_SV.DEPTH, Cz = D / 2 + c.oz;
   var fz = P.cy * P.cp, fl = (c.flat > 0.02) ? c.flat : 0.02;
   return { x: c.ox + K * P.sy * P.cp, y: c.oy + K * P.sp, t: (Cz - K * fz / fl) / D, zf: Cz * c.flat - K * fz };
}
// La camara cuyo OJO esta en ( x, y, t ) mirando con ese giro, esa inclinacion y ese travelin (la caja abierta).
function cpFlCamEyeAt(eye, yaw, pitch, zoom, lens, k0) {
   var P = cpSvPose(yaw, pitch), K = k0 / zoom, D = CP_SV.DEPTH;
   return cpFlCam({ yaw: yaw, pitch: pitch, zoom: zoom, lens: lens, flat: 1, ox: eye.x - K * P.sy * P.cp, oy: eye.y - K * P.sp, oz: eye.t * D + K * P.cy * P.cp - D / 2 });
}
// La camara que MIRA a un punto ( u, v, t ) de la caja: el pivote es el punto.
function cpFlCamLookAt(p, yaw, pitch, zoom, lens) {
   return cpFlCam({ yaw: yaw, pitch: pitch, zoom: zoom, lens: lens, flat: 1, ox: p.u, oy: p.v, oz: p.t * CP_SV.DEPTH - CP_SV.DEPTH / 2 });
}
// LO QUE SE MUEVE la camara entre dos poses, en «velocidad percibida» (ver CP_FL.ANG_W).
function cpFlCamMetric(a, b, k0) {
   var A = cpFlCam(a), B = cpFlCam(b), ea = cpFlEye(A, k0), eb = cpFlEye(B, k0), r = Math.PI / 180;
   var dx = ea.x - eb.x, dy = ea.y - eb.y, dz = ea.zf - eb.zf, da = (A.yaw - B.yaw) * r * CP_FL.ANG_W, dp = (A.pitch - B.pitch) * r * CP_FL.ANG_W;
   var df = (A.flat - B.flat) * CP_FL.FLAT_W, dl = Math.log(A.lens / B.lens) * CP_FL.LENS_W;
   return Math.sqrt(dx * dx + dy * dy + dz * dz + da * da + dp * dp + df * df + dl * dl);
}
// El mayor travelin (hasta `zMax`) con el que la caja ENTERA cabe en el fotograma con esa pose (con su aire).
function cpFlFitZoom(model, aspect, cam, zMax) {
   var R = cpFlUnitRect(aspect), m = CP_FL.FIT_MARGIN, lo = CP_SV.DIST_ZOOM_MIN, hi = (zMax > 0) ? zMax : 1.6;
   function fits(z) {
      var c = cpFlCam(cam); c.zoom = z;
      var fit = cpSvDistCam(model, R, cpFlCamToView(c, model, R));
      for (var a = 0; a < 8; ++a) {
         var p = fit.px((a & 1) ? model.wn / 2 : -model.wn / 2, (a & 2) ? model.hn / 2 : -model.hn / 2, (a & 4) ? 1 : 0);
         if (!p.ok || p.x < R.x + R.w * m || p.x > R.x + R.w * (1 - m) || p.y < R.y + R.h * m || p.y > R.y + R.h * (1 - m)) return false;
      }
      return true;
   }
   if (fits(hi)) return hi;
   if (!fits(lo)) return lo;
   for (var i = 0; i < 24; ++i) { var mid = Math.sqrt(lo * hi); if (fits(mid)) lo = mid; else hi = mid; }
   return lo;
}

// ---------------------------------------------------------------------------
// LA DISTANCIA DE UN FONDO: la inversa de `scale.t` (por biseccion: vale para la logaritmica y para los tramos).
// t <= 0 (delante de la foto: en casa) da 0; t >= 1, el final de la escala.
// ---------------------------------------------------------------------------
// (Una sola definicion: la de la vista, `cpSvDistPcAt`, que tambien usan las cifras del corte lateral con zoom.)
function cpFlPcAt(scale, t) { return cpSvDistPcAt(scale, t); }

// ---------------------------------------------------------------------------
// UN VUELO
// ---------------------------------------------------------------------------
//   { format, name, kind ("dive" | "orbit" | "tour" | "user"), duration (s),
//     keys: [ { t (s), cam, layers: { photo, box } (opacidades), visit (indice del objeto visitado, o -1),
//               rest (true = la camara llega y sale PARADA de esta clave) } ],
//     shortYaw (true = entre claves el giro va por el camino corto: el vuelo propio; false = el giro de cada clave
//               es el que es: «Orbit» da la vuelta entera),
//     constantSpeed (true = velocidad percibida constante: se recorre por longitud de arco y las pausas desaparecen),
//     easeIn, easeOut (s: con velocidad constante, lo que tarda en arrancar y en frenar),
//     loop (el ultimo fotograma es el primero),
//     fx: { fadeIn, fadeOut (s), vignette, trail, glow (0…1), title (bool), counter ("eye" | "pivot" | "none") },
//     k0 (la distancia de la camara a su pivote con zoom 1, del modelo con que se hizo: para medir velocidades),
//     aspect (el del fotograma para el que se hizo: de el salen `lens` de la foto de frente y los encajes),
//     wn, hn (los lados de la foto, el mayor = 1: para saber cuando la camara se le echa encima) }
function cpFlFx(f) {
   var q = f || {};
   return { fadeIn: cpFlClamp(cpFlNum(q.fadeIn, CP_FL.FADE_IN_S), 0, 10), fadeOut: cpFlClamp(cpFlNum(q.fadeOut, CP_FL.FADE_OUT_S), 0, 10),
            vignette: cpFlClamp(cpFlNum(q.vignette, CP_FL.VIGNETTE), 0, 1), trail: cpFlClamp(cpFlNum(q.trail, CP_FL.TRAIL), 0, 1),
            glow: cpFlClamp(cpFlNum(q.glow, CP_FL.GLOW), 0, 1), title: (q.title !== false),
            counter: (q.counter === "pivot" || q.counter === "none") ? q.counter : "eye" };
}
function cpFlKey(k) {
   var q = k || {};
   return { t: Math.max(0, cpFlNum(q.t, 0)), cam: cpFlCam(q.cam), layers: cpFlLayers(q.layers),
            visit: (typeof q.visit === "number" && isFinite(q.visit) && q.visit >= 0) ? Math.round(q.visit) : -1, rest: (q.rest === true),
            label: (typeof q.label === "string") ? q.label.substring(0, CP_FL.LABEL_MAX) : "",
            trans: (CP_FL.TRANS.indexOf(q.trans) >= 0) ? q.trans : "smooth",                            // (falta = la de siempre)
            pause: (typeof q.pause === "number" && isFinite(q.pause) && q.pause > 0) ? Math.min(CP_FL.PAUSE_MAX, q.pause) : 0 };     // (Cabra3D, editor de camaras: el nombre que le da el usuario; "" = «Vista n»)
}
// Un vuelo bien formado a partir de lo que llegue (cada cosa en sus topes; las claves, por orden de tiempo).
function cpFlMake(f) {
   var q = f || {}, keys = [], i;
   for (i = 0; q.keys && i < q.keys.length && i < CP_FL.MAX_KEYS; ++i) keys.push(cpFlKey(q.keys[i]));
   keys.sort(function(a, b) { return a.t - b.t; });
   var last = (keys.length > 0) ? keys[keys.length - 1].t : 0;
   var dur = cpFlNum(q.duration, 0);
   if (!(dur > 0)) dur = last;
   dur = cpFlClamp(Math.max(dur, last), (keys.length > 1) ? 0.1 : 0, CP_FL.DUR_MAX);
   return { format: CP_FL.FORMAT, name: String((q.name === undefined || q.name === null) ? "" : q.name).substring(0, 80),
            kind: (CP_FL_KINDS.indexOf(q.kind) >= 0) ? q.kind : "user", duration: dur, keys: keys,
            shortYaw: (q.shortYaw !== false), constantSpeed: (q.constantSpeed === true), easeIn: cpFlClamp(cpFlNum(q.easeIn, 0), 0, 30), easeOut: cpFlClamp(cpFlNum(q.easeOut, 0), 0, 30),
            loop: (q.loop === true), fx: cpFlFx(q.fx), wn: cpFlClamp(cpFlNum(q.wn, 1), 0.05, 1), hn: cpFlClamp(cpFlNum(q.hn, 1), 0.05, 1), k0: (cpFlNum(q.k0, 0) > 0) ? q.k0 : cpFlK0(null), aspect: (cpFlNum(q.aspect, 0) > 0) ? q.aspect : CP_FL.ASPECT };
}

// LA CUBICA MONOTONA (Fritsch-Carlson, la de `pchip`): las pendientes en las claves. Donde los datos cambian de
// sentido (o se paran) la pendiente es 0: no hay rebote. En los extremos, 0: el vuelo arranca y acaba PARADO.
function cpFlSlopes(x, y, rest) {
   var n = x.length, m = new Array(n), i;
   for (i = 0; i < n; ++i) m[i] = 0;
   if (n < 3) return m;
   for (i = 1; i < n - 1; ++i) {
      if (rest && rest[i]) continue;
      var h0 = x[i] - x[i - 1], h1 = x[i + 1] - x[i];
      if (!(h0 > 0) || !(h1 > 0)) continue;
      var d0 = (y[i] - y[i - 1]) / h0, d1 = (y[i + 1] - y[i]) / h1;
      if (d0 * d1 <= 0) continue;
      var w1 = 2 * h1 + h0, w2 = h1 + 2 * h0;
      m[i] = (w1 + w2) / (w1 / d0 + w2 / d1);
   }
   return m;
}
function cpFlHermite(x, y, m, t) {
   var n = x.length;
   if (n === 0) return 0;
   if (n === 1 || t <= x[0]) return y[0];
   if (t >= x[n - 1]) return y[n - 1];
   var lo = 0, hi = n - 1;
   while (hi - lo > 1) { var mid = (lo + hi) >> 1; if (x[mid] <= t) lo = mid; else hi = mid; }
   var h = x[hi] - x[lo];
   if (!(h > 0)) return y[hi];
   var s = (t - x[lo]) / h, s2 = s * s, s3 = s2 * s;
   return (2 * s3 - 3 * s2 + 1) * y[lo] + (s3 - 2 * s2 + s) * h * m[lo] + (-2 * s3 + 3 * s2) * y[hi] + (s3 - s2) * h * m[hi];
}

// Lo que hace falta para evaluar un vuelo, hecho UNA vez (se guarda en el propio vuelo: los vuelos no se
// modifican, cada operacion devuelve uno nuevo). Canales: el giro (ya desenrollado), la inclinacion, el
// LOGARITMO del travelin y del objetivo (se interpolan en proporcion), el pivote, el aplastado y las capas.
var CP_FL_CH = ["yaw", "pitch", "lz", "ox", "oy", "oz", "flat", "ll", "sx", "sy", "photo", "box"];
function cpFlPrepare(flight) {
   if (flight._p) return flight._p;
   var K = flight.keys, n = K.length, x = [], rest = [], ch = {}, i, c;
   for (c = 0; c < CP_FL_CH.length; ++c) ch[CP_FL_CH[c]] = [];
   var yaw = 0;
   for (i = 0; i < n; ++i) {
      var k = K[i], cam = k.cam;
      // (dos claves en el mismo instante: la segunda va un pelo despues, para que el tramo tenga duracion)
      x.push((i > 0 && k.t <= x[i - 1]) ? x[i - 1] + 1e-6 : k.t);
      rest.push(k.rest === true);
      if (i === 0) yaw = cam.yaw;
      else if (flight.shortYaw) { var d = (cam.yaw - yaw) % 360; if (d > 180) d -= 360; if (d <= -180) d += 360; yaw += d; }
      else yaw = cam.yaw;
      ch.yaw.push(yaw); ch.pitch.push(cam.pitch); ch.lz.push(Math.log(cam.zoom)); ch.ox.push(cam.ox); ch.oy.push(cam.oy); ch.oz.push(cam.oz);
      ch.flat.push(cam.flat); ch.ll.push(Math.log(cam.lens)); ch.sx.push(cam.sx); ch.sy.push(cam.sy);
      ch.photo.push(k.layers.photo); ch.box.push(k.layers.box);
   }
   var m = {};
   for (c = 0; c < CP_FL_CH.length; ++c) m[CP_FL_CH[c]] = cpFlSlopes(x, ch[CP_FL_CH[c]], rest);
   // las paradas: dos claves seguidas que visitan el mismo objeto (o una sola)
   var stops = [];
   for (i = 0; i < n; ++i) {
      if (K[i].visit < 0) continue;
      var j = i;
      while (j + 1 < n && K[j + 1].visit === K[i].visit) ++j;
      // (un PASO —una sola clave— no detiene la camara, pero su placa se tiene que poder leer: PASS_SHOW_S a plena opacidad)
      var pass = (j === i), half = pass ? CP_FL.PASS_SHOW_S / 2 : 0;
      stops.push({ obj: K[i].visit, t0: x[i] - half, t1: x[j] + half, pass: pass, key: x[i] });
      i = j;
   }
   // (dos ventanas no se pisan: se parten por la mitad del solape, dejando sitio a los fundidos)
   for (i = 1; i < stops.length; ++i) {
      var over = stops[i - 1].t1 + 2 * 0.2 - stops[i].t0;
      if (over > 0) { if (stops[i - 1].pass) stops[i - 1].t1 -= over / 2; if (stops[i].pass) stops[i].t0 += stops[i - 1].pass ? over / 2 : over; else if (stops[i - 1].pass) stops[i - 1].t1 -= over / 2; }
   }
   var p = { n: n, x: x, ch: ch, m: m, stops: stops, lut: null, seg: null, counter: null, T: flight.duration };
   // LA SERIE DEL CONTADOR «desde casa» (vuelta 4; revision visual: «va hacia atras: 138 000 → 10 300 → 944 → 265 → 312…»).
   // Lo que cuenta es el fondo de lo que la camara mira (su pivote, por lo abierta que esta la caja: aplastada sobre la
   // foto es 0, casa), pero MONOTONO POR TRAMOS: a la ida (hasta el punto mas lejano del vuelo) cada instante vale el
   // MINIMO de lo que queda por delante —la camara que sale de ver la caja entera hacia la primera estrella no «vuelve» de
   // 138 000 años luz: va hacia 254—, y a la vuelta, el MAXIMO de lo que queda. Asi nunca retrocede, llega a cada objeto
   // con SU distancia (la de su placa) y no da saltos.
   if (n > 1) {
      var NC = CP_FL.COUNTER_N, cu = new Float64Array(NC + 1), cd = new Float64Array(NC + 1), top = -1, ti = 0, Dz = CP_SV.DEPTH;
      for (i = 0; i <= NC; ++i) {
         cu[i] = x[0] + (x[n - 1] - x[0]) * i / NC;
         var sc = cpFlSample(flight, p, cu[i]).cam;
         cd[i] = cpFlClamp((Dz / 2 + sc.oz) / Dz, 0, 1) * sc.flat;
         if (cd[i] > top) { top = cd[i]; ti = i; }
      }
      for (i = ti - 1; i >= 0; --i) if (cd[i] > cd[i + 1]) cd[i] = cd[i + 1];
      for (i = NC - 1; i > ti; --i) if (cd[i] < cd[i + 1]) cd[i] = cd[i + 1];
      // CON VISITAS (los vuelos preparados), mejor que eso: el contador CUENTA. Entre dos visitas seguidas vale lo que la
      // camara lleva AVANZADO (el fondo de su ojo) llevado a escala para salir de la distancia de un objeto y LLEGAR a la del
      // siguiente (de 0 —casa— a la del primero; y del ultimo, de vuelta a 0). Con solo el minimo de lo que queda, en «Dive»
      // se quedaba clavado en la distancia de la nebulosa los cinco segundos del camino. Monotono por construccion.
      if (stops.length > 0 && CP_FL_COUNTER_STEPS === true) {
         var eye = new Float64Array(NC + 1), anc = [], a2, b2, s0 = 0;
         for (i = 0; i <= NC; ++i) eye[i] = cpFlEye(cpFlSample(flight, p, cu[i]).cam, flight.k0).t;
         function idx(uu, how) { var fq = (uu - cu[0]) / Math.max(1e-9, cu[NC] - cu[0]) * NC; return Math.max(0, Math.min(NC, (how < 0) ? Math.floor(fq) : (how > 0) ? Math.ceil(fq) : Math.round(fq))); }
         // (de donde sale: la primera muestra con la caja ya abierta)
         while (s0 < NC && cpFlSample(flight, p, cu[s0]).cam.flat < 0.999) ++s0;
         anc.push({ i: s0, d: 0 });
         for (i = 0; i < stops.length; ++i) {
            var sk = stops[i], ka = sk.pass ? idx(sk.key, 0) : idx(sk.t0, -1), kb = sk.pass ? ka : idx(sk.t1, 1), sd = cpFlSample(flight, p, sk.pass ? sk.key : sk.t0).cam, dd = cpFlClamp((Dz / 2 + sd.oz) / Dz, 0, 1);
            if (ka <= anc[anc.length - 1].i) continue;
            anc.push({ i: ka, d: dd }); if (kb > ka) anc.push({ i: kb, d: dd });
         }
         anc.push({ i: NC, d: 0 });
         for (a2 = 0; a2 + 1 < anc.length; ++a2) {
            var A = anc[a2], B = anc[a2 + 1], run = 0, de = eye[B.i] - eye[A.i], lastLeg = (a2 + 2 === anc.length);
            for (b2 = A.i; b2 <= B.i; ++b2) {
               // (el avance del ojo en este tramo, de 0 a 1 y sin retroceder; en la vuelta —o si el ojo no avanza—, por tiempo)
               var f = (lastLeg || Math.abs(de) < 1e-6) ? (b2 - A.i) / Math.max(1, B.i - A.i) : cpFlClamp((eye[b2] - eye[A.i]) / de, 0, 1);
               if (f < run) f = run; else run = f;
               cd[b2] = A.d + (B.d - A.d) * f;
            }
         }
         for (b2 = 0; b2 < anc[0].i; ++b2) cd[b2] = 0;
      }
      p.counter = { u: cu, d: cd, top: ti };
   }
   // LA PLACA no se pisa con la de al lado: su fundido no pasa de la mitad del hueco entre dos paradas
   for (i = 0; i < stops.length; ++i) {
      var gapL = (i > 0) ? stops[i].t0 - stops[i - 1].t1 : stops[i].t0 * 2 + 1e9, gapR = (i + 1 < stops.length) ? stops[i + 1].t0 - stops[i].t1 : 1e9;
      stops[i].fade = Math.max(0.01, Math.min(CP_FL.PLATE_FADE_S, 0.45 * gapL, 0.45 * gapR));
   }
   try { Object.defineProperty(flight, "_p", { value: p, enumerable: false, writable: true }); } catch (e) { flight._p = p; }
   if (flight.constantSpeed && n > 1) p.lut = cpFlArcTable(flight, p);
   if (p.lut !== null && cpFlHasSegments(flight)) p.seg = cpFlSegPlan(flight, p);
   return p;
}
// La camara y las capas en el instante `u` del RECORRIDO (el tiempo de las claves).
function cpFlSample(flight, p, u) {
   function v(name) { return cpFlHermite(p.x, p.ch[name], p.m[name], u); }
   if (p.n === 0) return { cam: cpFlCam(null), layers: cpFlLayers(null) };
   return { cam: cpFlCam({ yaw: v("yaw"), pitch: v("pitch"), zoom: Math.exp(v("lz")), ox: v("ox"), oy: v("oy"), oz: v("oz"), flat: v("flat"), lens: Math.exp(v("ll")), sx: v("sx"), sy: v("sy") }),
            layers: cpFlLayers({ photo: v("photo"), box: v("box") }) };
}
// LA TABLA DE LONGITUD DE ARCO: cuanto se ha movido la camara (velocidad percibida) hasta cada instante del
// recorrido. Con ella, «velocidad constante» es recorrer la longitud a ritmo fijo.
function cpFlArcTable(flight, p) {
   var N = CP_FL.LUT_N, a = p.x[0], b = p.x[p.n - 1], u = new Float64Array(N + 1), s = new Float64Array(N + 1), prev = null;
   for (var i = 0; i <= N; ++i) {
      u[i] = a + (b - a) * i / N;
      var cam = cpFlSample(flight, p, u[i]).cam;
      s[i] = (i === 0) ? 0 : s[i - 1] + cpFlCamMetric(prev, cam, flight.k0);
      prev = cam;
   }
   return { u: u, s: s, total: s[N] };
}
// El arranque y la frenada: de 0…T a 0…1, con la velocidad subiendo suave durante `a` segundos y bajando durante `b`.
function cpFlWarp(t, T, a, b) {
   if (!(T > 0)) return 0;
   var x = cpFlClamp(t, 0, T), A = Math.max(0, Math.min(a, T / 2)), B = Math.max(0, Math.min(b, T / 2));
   // la velocidad es s( x / A ) al arrancar, 1 en medio y s( ( T - x ) / B ) al frenar, con s = 3r² − 2r³; su integral:
   function ramp(r) { return r * r * r - r * r * r * r / 2; }             // ∫0..r s = r³ − r⁴/2  (en r = 1: 1/2)
   var total = T - A / 2 - B / 2, I;
   if (x < A) I = A * ramp(x / A);
   else if (x <= T - B) I = A / 2 + (x - A);
   else I = A / 2 + (T - B - A) + B * (0.5 - ramp((T - x) / B));
   return (total > 0) ? I / total : x / T;
}
// El instante del recorrido en que la camara lleva recorrido `target` de la tabla de arco (la inversa de la tabla).
function cpFlLutInv(L, target) {
   var lo = 0, hi = L.s.length - 1;
   if (target <= 0) return L.u[0];
   if (target >= L.total) return L.u[hi];
   while (hi - lo > 1) { var mid = (lo + hi) >> 1; if (L.s[mid] <= target) lo = mid; else hi = mid; }
   var ds = L.s[hi] - L.s[lo];
   return L.u[lo] + (L.u[hi] - L.u[lo]) * ((ds > 0) ? (target - L.s[lo]) / ds : 0);
}
// Lo recorrido (arco) en el instante `u` del recorrido: la tabla de arco, al reves.
function cpFlLutAt(L, u) {
   var N = L.u.length - 1, f = (u - L.u[0]) / Math.max(1e-12, L.u[N] - L.u[0]) * N, i = Math.max(0, Math.min(N - 1, Math.floor(f))), r = cpFlClamp(f - i, 0, 1);
   return L.s[i] + (L.s[i + 1] - L.s[i]) * r;
}
// ¿Tiene el vuelo transiciones o pausas propias? (si no, el movimiento es EXACTAMENTE el de antes)
function cpFlHasSegments(flight) {
   for (var i = 0; i < flight.keys.length; ++i) if (flight.keys[i].pause > 0 || (i > 0 && flight.keys[i].trans !== "smooth")) return true;
   return false;
}
// LA FORMA de un tramo: de la fraccion de tiempo `s` (0…1) a la fraccion del recorrido (0…1).
//   smooth: velocidad constante (la de siempre), con el arranque suave del vuelo si es el primer tramo y la frenada si es el ultimo
//   linear: velocidad constante · out: sale rapido y frena (1 − (1 − s)³) · in: sale despacio y llega rapido (s³) · slow: suave en los dos extremos
function cpFlShape(kind, s, first, last, dur, flight) {
   var x = cpFlClamp(s, 0, 1);
   if (kind === "out") return 1 - (1 - x) * (1 - x) * (1 - x);
   if (kind === "in") return x * x * x;
   if (kind === "slow") return x * x * (3 - 2 * x);
   if (kind === "linear") return x;
   // smooth
   if (first || last) return cpFlWarp(x * dur, dur, first ? flight.easeIn : 0, last ? flight.easeOut : 0);
   return x;
}
// El plan por tramos de un vuelo con transiciones o pausas: el arco recorrido al llegar a cada vista.
function cpFlSegPlan(flight, p) {
   var K = flight.keys, n = K.length, S = [], i;
   for (i = 0; i < n; ++i) S.push(cpFlLutAt(p.lut, p.x[i]));
   return { S: S };
}
// Del segundo del VIDEO al instante del recorrido.
function cpFlPathTime(flight, p, t) {
   var T = flight.duration, x = cpFlClamp(t, 0, T);
   if (p.seg) return cpFlSegTime(flight, p, x);
   if (p.lut === null || !(p.lut.total > 0)) return x;
   var L = p.lut;
   return cpFlLutInv(L, L.total * cpFlWarp(x, T, flight.easeIn, flight.easeOut));
}
// …con transiciones y pausas por vista: la vista j se alcanza en K[j].t y la camara se queda en ella K[j].pause segundos.
function cpFlSegTime(flight, p, t) {
   var K = flight.keys, n = K.length, S = p.seg.S, L = p.lut, j;
   if (t <= K[0].t + K[0].pause) return p.x[0];
   for (j = 1; j < n; ++j) if (t <= K[j].t) break;
   if (j >= n) return p.x[n - 1];
   var a = K[j - 1].t + K[j - 1].pause, b = K[j].t;
   if (t <= a) return p.x[j - 1];
   if (!(b > a)) return p.x[j];
   var f = cpFlShape(K[j].trans, (t - a) / (b - a), j === 1, j === n - 1, b - a, flight);
   if (!(S[j] - S[j - 1] > 1e-9)) return p.x[j - 1] + f * (p.x[j] - p.x[j - 1]);
   return cpFlLutInv(L, S[j - 1] + f * (S[j] - S[j - 1]));
}

// El fondo que dice el contador en el instante `u` del recorrido (la serie monotona por tramos de `cpFlPrepare`).
function cpFlCounterAt(flight, u, fallback) {
   var c = cpFlPrepare(flight).counter;
   if (c === null || CP_FL_COUNTER_RAW === true) return fallback;
   var N = c.u.length - 1, f = (u - c.u[0]) / Math.max(1e-9, c.u[N] - c.u[0]) * N, i = Math.max(0, Math.min(N - 1, Math.floor(f))), r = cpFlClamp(f - i, 0, 1);
   return c.d[i] + (c.d[i + 1] - c.d[i]) * r;
}
// EL ESTADO DEL VUELO EN EL SEGUNDO `t`: { t, u (el instante del recorrido), cam, layers, stop (la parada cuya placa
// se ve: { obj, alpha } o null) }. DETERMINISTA: el mismo vuelo y el mismo t dan siempre lo mismo.
function cpFlAt(flight, t) {
   var p = cpFlPrepare(flight), tt = cpFlClamp(cpFlNum(t, 0), 0, flight.duration), u = cpFlPathTime(flight, p, tt), S = cpFlSample(flight, p, u), stop = null;
   function ss(r) { r = cpFlClamp(r, 0, 1); return r * r * (3 - 2 * r); }
   for (var i = 0; i < p.stops.length; ++i) {
      var st = p.stops[i], a = ss((u - (st.t0 - st.fade)) / st.fade) * (1 - ss((u - st.t1) / st.fade));
      if (a > 0 && (stop === null || a > stop.alpha)) stop = { obj: st.obj, alpha: a, hold: (st.pass !== true && st.t1 - st.t0 >= CP_FL.HOLD_S) };
   }
   // la foto, de cerca, se apaga (CP_FL.PHOTO_NEAR0): lo que dista el ojo del rectangulo de la foto
   var e = cpFlEye(S.cam, flight.k0), ex = Math.max(0, Math.abs(e.x) - flight.wn / 2), ey = Math.max(0, Math.abs(e.y) - flight.hn / 2);
   S.layers.photo *= ss((Math.sqrt(e.zf * e.zf + ex * ex + ey * ey) - CP_FL.PHOTO_NEAR0) / (CP_FL.PHOTO_NEAR1 - CP_FL.PHOTO_NEAR0));
   // LOS OBJETOS no se pintan sobre la foto de frente (el estado FOTO es la foto, tal cual: R3): aparecen al abrirse la caja
   S.layers.objects = ss(S.cam.flat / CP_FL.OBJECTS_FLAT);
   return { t: tt, u: u, cam: S.cam, layers: S.layers, stop: stop };
}

// ---------------------------------------------------------------------------
// LOS EFECTOS, COMO DATOS. `ctx` = { model, scale, fps }. Devuelve lo que el pintor necesita de un fotograma:
//   { t, cam, layers, prevCam (donde estaba la camara hace un obturador: de ahi sale la estela),
//     fx: { fade (0…1 de negro encima), vignette, trail (opacidad de la estela: 0 en las pausas), glow,
//           title (opacidad del titulo de entrada), counter: { alpha, pc (la distancia «desde casa»), t },
//           plate: { obj, alpha } | null (el objeto visitado) },
//     speed (velocidad percibida, por segundo) }
// ---------------------------------------------------------------------------
function cpFlFrame(flight, t, ctx) {
   var c = ctx || {}, S = cpFlAt(flight, t), T = flight.duration, F = flight.fx, sh = CP_FL.TRAIL_SHUTTER_S;
   function ss(r) { r = cpFlClamp(r, 0, 1); return r * r * (3 - 2 * r); }
   var prev = (S.t - sh > 0) ? cpFlAt(flight, S.t - sh).cam : cpFlAt(flight, 0).cam;
   var speed = (S.t > 0) ? cpFlCamMetric(S.cam, prev, flight.k0) / Math.min(sh, S.t) : 0;
   var fade = 0;
   if (F.fadeIn > 0) fade = Math.max(fade, CP_FL.FADE_FROM * (1 - ss(S.t / F.fadeIn)));
   // (ni el primer fotograma ni el ultimo son negro puro: son lo que enseña un reproductor parado. El fundido llega a FADE_FROM.)
   if (F.fadeOut > 0) fade = Math.max(fade, CP_FL.FADE_FROM * ss((S.t - (T - F.fadeOut)) / F.fadeOut));
   var title = 0;
   if (F.title) title = ss((S.t - CP_FL.TITLE_AT_S) / CP_FL.TITLE_IN_S) * (1 - ss((S.t - CP_FL.TITLE_AT_S - CP_FL.TITLE_IN_S - CP_FL.TITLE_HOLD_S) / CP_FL.TITLE_OUT_S));
   var counter = { alpha: 0, pc: 0, t: 0 };
   if (F.counter !== "none" && c.scale) {
      var D = CP_SV.DEPTH, depth = (F.counter === "pivot") ? cpFlCounterAt(flight, S.u, (D / 2 + S.cam.oz) / D) : cpFlEye(S.cam, flight.k0).t;
      counter.t = depth;
      counter.pc = cpFlPcAt(c.scale, depth);
      // se ve con la caja abierta y la camara ya dentro (pasado el plano de la foto), y nunca a la vez que el titulo
      // …y solo cuando dice algo: volando hacia delante (no al darse la vuelta) o mirando algo de cerca (no la caja entera)
      var Pz = cpSvPose(S.cam.yaw, S.cam.pitch), says = (F.counter === "pivot") ? ss((S.cam.zoom - 1.1) / 0.7) : ss((Pz.cy * Pz.cp - 0.5) / 0.3) * ((depth <= 1) ? 1 : 0);
      counter.alpha = ss((S.cam.flat - 0.6) / 0.4) * ss(depth / 0.02) * (1 - title) * says * ((counter.pc > 0) ? 1 : 0);
      // …y NUNCA a la vez que la placa de un objeto: «1,97 M ly» con una nebulosa de 3 840 ly llenando la pantalla era la
      // distancia del pivote, no la de lo que se mira; mientras se visita algo, manda su placa
      if (S.stop !== null) counter.alpha *= 1 - S.stop.alpha;
   }
   // LAS ESTELAS: su opacidad TOPE. Cuanto se ve la de cada punto lo decide quien pinta, por lo que ese punto se mueve en
   // pantalla; aqui se apagan en una PARADA (rodeando o mirando algo: «que no quede ni una cola») y en la vuelta a la foto.
   var calm = (S.stop !== null && S.stop.hold) ? 1 - S.stop.alpha : 1;
   calm *= ss((S.cam.flat - CP_FL.TRAIL_FLAT0) / (CP_FL.TRAIL_FLAT1 - CP_FL.TRAIL_FLAT0));
   return { t: S.t, u: S.u, cam: S.cam, layers: S.layers, prevCam: prev, speed: speed,
            fx: { fade: fade, vignette: F.vignette, trail: F.trail * calm * ss((speed - CP_FL.TRAIL_V0) / (CP_FL.TRAIL_V1 - CP_FL.TRAIL_V0)), glow: F.glow * S.cam.flat,
                  title: title, counter: counter, plate: (S.stop !== null && S.stop.alpha > 0.004) ? { obj: S.stop.obj, alpha: S.stop.alpha, hold: S.stop.hold } : null } };
}

// ---------------------------------------------------------------------------
// EL PROTAGONISTA del campo: lo NO estelar mas cercano al centro del encuadre (un cumulo, una nebulosa, una galaxia
// con nombre de catalogo clasico antes que una anonima); si no hay nada, la estrella mas brillante (la mas cercana
// al centro entre las del simbolo mayor). -1 = el campo esta vacio.
// ---------------------------------------------------------------------------
function cpFlProtagonist(model) {
   var objs = (model && model.objects) ? model.objects : [], best = -1, bs = Infinity, i, o, s;
   // UNA SOLA DEFINICION, la del panel: (1) EL CUMULO DEL CAMPO si es de verdad el protagonista (cien miembros: lo mismo
   // que le da su nombre al titulo del panel, `_titleOf`) —en M 13 el motivo «de SIMBAD» mas centrado es IC 4617, una
   // galaxia de fondo, y el protagonista es el cumulo: visto en el pack STARFIELD-UI—; (2) el MOTIVO DE LA FOTO que dice la
   // vista (`model.subject`, ui/starfield_view.js), si esta colocado; (3) y, en los campos sin ninguno de los dos, lo de abajo.
   if (model && model.counts && model.counts.members >= CP_FL.CLUSTER_MEMBERS) {
      for (i = 0; i < objs.length; ++i) { o = objs[i]; if (o.kind !== "cluster") continue; s = o.u * o.u + o.v * o.v; if (s < bs) { bs = s; best = i; } }
      if (best >= 0) return best;
   }
   if (model && model.subject && model.subject.index >= 0 && objs[model.subject.index]) return model.subject.index;
   for (i = 0; i < objs.length; ++i) {
      o = objs[i];
      if (o.kind === "star" || o.kind === "member" || o.kind === "quasar" || o.suspect) continue;
      s = Math.sqrt(o.u * o.u + o.v * o.v) + ((o.kind === "cluster" || o.kind === "other" || o.kind === "nebula") ? 0 : 0.08) + (/^(M|NGC|IC|UGC|Abell|ACO|PN|PK|Sh)\s*\d/.test(o.name) ? 0 : 0.25);
      if (s < bs) { bs = s; best = i; }
   }
   if (best >= 0) return best;
   var size = 0;
   for (i = 0; i < objs.length; ++i) if (objs[i].kind === "star" && objs[i].size > size) size = objs[i].size;
   for (i = 0; i < objs.length; ++i) {
      o = objs[i];
      if (o.kind !== "star" || o.size < size) continue;
      s = o.u * o.u + o.v * o.v;
      if (s < bs) { bs = s; best = i; }
   }
   if (best >= 0) return best;
   for (i = 0; i < objs.length; ++i) if (!objs[i].suspect) return i;      // (solo quedan cuasares, o miembros)
   return -1;
}
// LO QUE MIDE un objeto en la foto (su radio, en lados del lado mayor): lo que dice el catalogo (`ext`: de ahi sale su
// recorte) o, en un cumulo, su radio. 0 = es un punto.
function cpFlExtent(ob) { return (ob && ob.ext > 0) ? ob.ext : (ob && ob.kind === "cluster" && ob.radius > 0) ? ob.radius : 0; }
// EL TRAVELIN CON EL QUE UN OBJETO SE VE BIEN mirandolo (el pivote en el): su diametro ocupa `fill` del alto del cuadro.
// Un punto se mira de cerca (6; una estrella, 5: a su alrededor hay mas estrellas).
// LO QUE BRILLA de un objeto (14-oct-2026, vuelta 3): { rx, ry (sus semiejes en la foto, en lados del lado mayor), px (lo
// que mide en pixeles de la IMAGEN su lado menor; 0 = no se sabe), ring (el radio de su aro, si lo lleva) } o null si es
// un punto. `extent( indice )` lo da quien ha medido el recorte (el panel: la caja que contiene el 90 % de la transparencia
// de su mascara de brillo); sin eso, lo del catalogo. UN CUMULO: el radio que contiene a la MITAD de sus miembros pintados.
function cpFlShine(model, idx, extent) {
   var ob = (model && model.objects) ? model.objects[idx] : null;
   if (!ob) return null;
   var e = (typeof extent === "function") ? extent(idx) : null;
   if (e && e.rx > 0 && e.ry > 0) return { rx: e.rx, ry: e.ry, px: (e.px > 0) ? e.px : 0, ring: 0 };
   if (ob.kind === "cluster") {
      var d = [];
      for (var i = 0; i < model.objects.length; ++i) { var m = model.objects[i]; if (m.kind === "member") d.push(Math.sqrt((m.u - ob.u) * (m.u - ob.u) + (m.v - ob.v) * (m.v - ob.v))); }
      d.sort(function(p, q) { return p - q; });
      var half = (d.length >= 8) ? d[d.length >> 1] : cpFlExtent(ob);
      return (half > 0) ? { rx: half, ry: half, px: 0, ring: (ob.radius > 0) ? ob.radius : 0 } : null;
   }
   var r = cpFlExtent(ob);
   return (r > 0) ? { rx: r, ry: r, px: 0, ring: 0 } : null;
}
// (`ob`: el objeto, o su indice. `extent`: ver `cpFlShine`.)
function cpFlLookZoom(model, aspect, ob, fill, extent, height) {
   var idx = (typeof ob === "number") ? ob : model.objects.indexOf(ob), o = model.objects[idx], s = cpFlShine(model, idx, extent);
   if (s === null) return (o && o.kind === "star") ? 5 : 6;
   // (con el pivote en el objeto y lens 1, un lado de la foto mide `ref · zoom` altos de cuadro)
   var ref = cpFlRef(model, cpFlUnitRect(aspect)), f = fill;
   if (s.px > 0) f = Math.min(f, Math.max(CP_FL.LOOK_MIN_FILL, CP_FL.LOOK_MAG * s.px / ((height > 0) ? height : CP_FL.LOOK_REF_H)));
   var z = Math.min(f / (2 * s.ry), CP_FL.LOOK_WIDTH * aspect / (2 * s.rx)) / ref;
   if (s.ring > 0) z = Math.min(z, CP_FL.LOOK_RING / (2 * s.ring * ref), CP_FL.LOOK_RING * aspect / (2 * s.ring * ref));
   return cpFlClamp(z, 1.5, CP_FL.LOOK_MAX);
}
// Lo que se queda la camara mirando un objeto, de 0 (un punto: es un paso) a 1.
function cpFlDwell(model, idx, extent) {
   var s = cpFlShine(model, idx, extent);
   if (s === null) return 0;
   if (s.px > 0 && s.px < CP_FL.VISIT_MIN_PX) return 0;
   return (s.px > 0) ? cpFlClamp(s.px / CP_FL.TOUR_DWELL_PX, CP_FL.TOUR_DWELL_MIN, 1) : 1;
}
// El sitio de un objeto en la caja: { u, v, t }.
function cpFlPlace(model, scale, idx) {
   var o = model.objects[idx];
   return { u: o.u, v: o.v, t: cpFlClamp(scale.t(o.pc), 0, 1) };
}
// LAS PARADAS DEL «GRAND TOUR»: los destacados (`cpSvDistHighlights`) y el protagonista, POR ORDEN DE DISTANCIA.
// Como mucho MAX_STOPS: se quedan el mas cercano, el protagonista y el mas lejano, y los demas por orden.
function cpFlTourStops(model) {
   var hi = cpSvDistHighlights(model), used = {}, list = [], i, pro = cpFlProtagonist(model);
   function add(idx, role) { if (idx >= 0 && !used[idx] && model.objects[idx] && !model.objects[idx].suspect) { used[idx] = true; list.push({ index: idx, role: role }); } }
   for (i = 0; i < hi.length; ++i) add(hi[i].index, hi[i].role);
   add(pro, "protagonist");
   list.sort(function(a, b) { return (model.objects[a.index].pc - model.objects[b.index].pc) || (a.index - b.index); });
   while (list.length > CP_FL.MAX_STOPS) {
      // fuera el que menos aporta: ni el primero, ni el ultimo, ni el protagonista; de los demas, el que esta mas cerca (en fondo) de su vecino
      var drop = -1, dmin = Infinity;
      for (i = 1; i < list.length - 1; ++i) {
         if (list[i].index === pro) continue;
         var d = Math.log(model.objects[list[i + 1].index].pc / model.objects[list[i - 1].index].pc);
         if (d < dmin) { dmin = d; drop = i; }
      }
      if (drop < 0) drop = list.length - 2;
      list.splice(drop, 1);
   }
   return list;
}

// ---------------------------------------------------------------------------
// LOS TRES VUELOS PREPARADOS. Salen del MODELO (`cpSvDistModel`) y de la ESCALA (`cpSvDistScale`) del campo: no
// llevan coordenadas fijas. `opts` = { duration (s), intensity (0…1), aspect }. Con un campo vacio, o con una sola
// estrella, dan un vuelo igual de valido (mas corto de cosas que ver).
// ---------------------------------------------------------------------------
function cpFlPresetList() {
   return [{ kind: "dive", name: "Dive", duration: CP_FL.DUR_DIVE }, { kind: "orbit", name: "Orbit", duration: CP_FL.DUR_ORBIT }, { kind: "tour", name: "Grand tour", duration: CP_FL.DUR_TOUR }];
}
function cpFlPreset(kind, model, scale, opts) {
   var o = opts || {}, a = cpFlClamp(cpFlNum(o.intensity, CP_FL.INTENSITY), 0, 1), aspect = (cpFlNum(o.aspect, 0) > 0) ? o.aspect : CP_FL.ASPECT;
   var D = CP_SV.DEPTH, k0 = cpFlK0(model), photo = cpFlPhotoCam(model, aspect), keys = [], pro = cpFlProtagonist(model);
   var P = (pro >= 0) ? cpFlPlace(model, scale, pro) : { u: 0, v: 0, t: 0.35 };
   var far = (model.farthest >= 0) ? cpFlPlace(model, scale, model.farthest) : { u: 0, v: 0, t: 1 };
   function key(t, cam, layers, more) {
      var k = { t: t, cam: cam, layers: layers || { photo: 1, box: 1 }, visit: -1, rest: false };
      if (more) { if (more.visit >= 0) k.visit = more.visit; if (more.rest) k.rest = true; }
      keys.push(k);
   }
   function wide(yaw, pitch, more) {
      var c = cpFlCam({ yaw: yaw, pitch: pitch, zoom: 1, ox: 0, oy: 0, oz: 0, flat: 1, lens: 1 });
      c.zoom = cpFlFitZoom(model, aspect, c, 1.25);
      if (more) for (var q in more) if (Object.prototype.hasOwnProperty.call(more, q)) c[q] = more[q];
      return cpFlCam(c);
   }
   var T, flight = { name: "", kind: kind, keys: keys, shortYaw: false, constantSpeed: false, loop: false, k0: k0, aspect: aspect, wn: model.wn, hn: model.hn, fx: {} };

   if (kind === "orbit") {
      // LA GRAN ORBITA: la foto quieta → se abre → la vuelta ENTERA (el giro no cambia nunca de sentido: de 0 a 360)
      // con la inclinacion subiendo y bajando en arco y un «vertigo» cuando el protagonista pasa por delante →
      // todo cae otra vez sobre la foto. El ultimo fotograma es el primero.
      T = cpFlClamp(cpFlNum(o.duration, CP_FL.DUR_ORBIT), 6, CP_FL.DUR_MAX);
      var hold0 = Math.min(0.5, 0.05 * T), hold1 = Math.min(0.4, 0.04 * T), tA = hold0 + 0.12 * T, tB = T - hold1 - 0.12 * T;
      // el giro en el que el protagonista queda DELANTE (entre la camara y el centro de la caja)
      var pz = P.t * D - D / 2, front = cpSvWrapDeg(180 - Math.atan2(P.u, pz) * 180 / Math.PI), vk = 4, vd = 1e9, i;
      for (i = 2; i <= 6; ++i) { var dd = Math.abs(((45 * i - front + 540) % 360) - 180); if (dd < vd) { vd = dd; vk = i; } }
      key(0, photo, { photo: 1, box: 0 }, { rest: true });
      key(hold0, photo, { photo: 1, box: 0 }, { rest: true });
      for (i = 1; i <= 7; ++i) {
         var yaw = 45 * i, pitch = (8 + 22 * a) * Math.sin(Math.PI * i / 8), c = wide(yaw, pitch, null);
         // (la caja, mas cerrada en cuadro: encajada entera ocupaba el 45 % del alto. Revision visual del 14-oct-2026.)
         c.zoom *= 1.3;
         if (i === vk && pro >= 0) {
            // el vertigo: la camara entra (travelin) mientras el objetivo se abre: lo que esta en el pivote no cambia
            // de tamaño y todo lo demas se estira. El pivote se va hacia el protagonista.
            var vz = 1 + 1.3 * a;
            c = cpFlCam({ yaw: yaw, pitch: pitch, zoom: c.zoom * vz, lens: 1 / vz, flat: 1, ox: 0.6 * P.u, oy: 0.6 * P.v, oz: 0.6 * pz });
         }
         key(tA + (tB - tA) * (i - 1) / 6, c, { photo: 1, box: 1 }, null);
      }
      var back = cpFlCam(photo); back.yaw = 360;
      key(T - hold1, back, { photo: 1, box: 0 }, { rest: true });
      key(T, back, { photo: 1, box: 0 }, { rest: true });
      flight.name = "Orbit"; flight.loop = true;
      // (vuelta 4: «Orbit» tambien lleva su titulo al arrancar; el bucle se conserva: en el primer y en el ultimo fotograma no hay titulo)
      flight.fx = { fadeIn: 0, fadeOut: 0, title: true, counter: "none", trail: 0.35 * CP_FL.TRAIL / 0.6 };
   } else if (kind === "tour") {
      // EL VIAJE: la foto → se abre → una parada en cada destacado, POR ORDEN DE DISTANCIA (la placa del objeto
      // aparece al llegar y se va al salir), con un arco entre paradas (la camara se aparta y vuelve a entrar) →
      // la caja entera. El contador dice a que distancia esta lo que se mira. UNA PARADA ES PARA MIRAR ALGO: si el
      // objeto es extenso (lleva su recorte de la foto) la camara se pone a la distancia a la que el recorte llena una
      // parte digna del cuadro y se queda; si es un punto, la parada es corta.
      // (14-oct-2026, vuelta 3) UN PUNTO NO ES UNA PARADA: es un paso (una sola clave: la camara no se detiene). Un objeto
      // extenso pequeño se mira menos. Y EL VIAJE ACABA SOBRE LA FOTO, de frente, como los otros dos.
      var stops = cpFlTourStops(model), n = stops.length, s, wsum = 0, dwell = [];
      for (s = 0; s < n; ++s) { dwell.push(cpFlDwell(model, stops[s].index, o.extent)); wsum += (dwell[s] > 0) ? 1 + dwell[s] : CP_FL.TOUR_PASS; }
      T = cpFlClamp(cpFlNum(o.duration, Math.round(Math.max(14, 7.5 + 3.2 * wsum))), 6, CP_FL.DUR_MAX);
      var hold = Math.min(1, 0.06 * T), tOpen = hold + 0.09 * T, rest = Math.min(0.7, 0.04 * T), tLast = T - rest - Math.max(3, 0.16 * T), unit = (n > 0) ? (tLast - tOpen) / wsum : 0, sgn = 1;
      key(0, photo, { photo: 1, box: 0 }, { rest: true });
      key(hold, photo, { photo: 1, box: 0 }, { rest: true });
      // (la caja ENTERA, encajada: con el travelin forzado a 1 la apertura salia recortada por arriba. Visto en la tira.)
      var open = wide(CP_SV.YAW * (0.5 + 0.3 * a), CP_SV.PITCH, null), prevCam = open, tPrev = tOpen;
      key(tOpen, open, { photo: 1, box: 1 }, null);
      for (s = 0; s < n; ++s) {
         var at = cpFlPlace(model, scale, stops[s].index), z = cpFlLookZoom(model, aspect, stops[s].index, CP_FL.TOUR_FILL, o.extent, o.height);
         var yawS = sgn * (16 + 20 * a), pitS = 5 + 6 * a * ((s % 2) ? 0.4 : 1);
         if (!(dwell[s] > 0)) {
            // EL PASO: de largo, mirandolo
            var tPass = tPrev + unit * CP_FL.TOUR_PASS, pass = cpFlCamLookAt(at, yawS * 0.6, pitS, z, 1);
            key(tPass, pass, { photo: 1, box: 1 }, { visit: stops[s].index });
            prevCam = pass; tPrev = tPass; sgn = -sgn;
            continue;
         }
         var arrive = cpFlCamLookAt(at, yawS, pitS, z, 1), leave = cpFlCamLookAt(at, yawS + sgn * (3 + 4 * a) * (0.5 + dwell[s]), pitS, z * (1 + 0.1 * dwell[s]), 1);
         var tArr = tPrev + unit, tLea = tArr + unit * dwell[s];
         // el arco: a medio camino la camara esta mas lejos de lo que mira y algo mas alta
         var midZ = Math.max(1.1, Math.min(prevCam.zoom, z) * (0.8 - 0.2 * a));
         key((tPrev + tArr) / 2, cpFlCam({ yaw: (prevCam.yaw + yawS) / 2, pitch: (prevCam.pitch + pitS) / 2 + 6 * a, zoom: midZ, lens: 1, flat: 1,
                                           ox: (prevCam.ox + arrive.ox) / 2, oy: (prevCam.oy + arrive.oy) / 2, oz: (prevCam.oz + arrive.oz) / 2 }), { photo: 1, box: 1 }, null);
         key(tArr, arrive, { photo: 1, box: 1 }, { visit: stops[s].index });
         key(tLea, leave, { photo: 1, box: 1 }, { visit: stops[s].index });
         prevCam = leave; tPrev = tLea; sgn = -sgn;
      }
      // de vuelta, de un tiron: la camara se pone de frente y la caja se aplasta sobre la foto
      key(T - rest, photo, { photo: 1, box: 0 }, { rest: true });
      key(T, photo, { photo: 1, box: 0 }, { rest: true });
      flight.name = "Grand tour";
      flight.fx = { fadeIn: 0, fadeOut: CP_FL.END_FADE_S, title: true, counter: "pivot", trail: CP_FL.TRAIL };
   } else {
      // LA ZAMBULLIDA (rehecha el 14-oct-2026 con lo que se vio en las primeras tiras y lo que decidio el coordinador):
      //   la foto quieta → se abre (la camara se echa un poco atras: toma impulso) → entra por la foto y cruza la nube de
      //   estrellas CON EL TIEMPO REPARTIDO SEGUN DONDE HAY COSAS (las claves van en los cuantiles de profundidad de los
      //   objetos del camino: donde hay muchas se va despacio y el vacio se cruza deprisa; nunca segundos de pantalla
      //   casi negra) → LLEGA AL PROTAGONISTA y lo rodea mirandolo, con su recorte de la foto a la vista y su placa →
      //   si hay algo lejano con placa, un SALTO rapido, con estelas, hasta lo mas lejano → y de un tiron, de vuelta: todo
      //   cae sobre la foto, DE FRENTE (no la foto por detras, en espejo: se probo y no gustaba).
      kind = "dive"; flight.kind = "dive";
      T = cpFlClamp(cpFlNum(o.duration, CP_FL.DUR_DIVE), 6, CP_FL.DUR_MAX);
      var side = (P.u >= 0) ? -1 : 1, sway = 4 + 7 * a, zd = 7, Kd = k0 / zd, objs = model.objects, i2, j;
      // …el protagonista, a la distancia a la que se ve bien (su recorte, un tercio del alto del cuadro)
      var zP = (pro >= 0) ? cpFlLookZoom(model, aspect, pro, CP_FL.DIVE_FILL, o.extent, o.height) : 3, yawA = -side * (22 + 14 * a), yawB = side * (20 + 16 * a), pitP = 6 + 4 * a;
      var arrive2 = cpFlCamLookAt(P, yawA, pitP, zP, 1), midP = cpFlCamLookAt(P, (yawA + yawB) / 2, pitP + 3, zP * 1.06, 1), leave2 = cpFlCamLookAt(P, yawB, pitP + 1, zP * 1.12, 1);
      var eArr = cpFlEye(arrive2, k0), eA = 0.02;
      // …y lo mas lejano que lleva placa (si lo hay y esta bien mas alla)
      var hi = cpSvDistHighlights(model), farIdx = -1;
      for (i2 = 0; i2 < hi.length; ++i2) if (hi[i2].index !== pro && !objs[hi[i2].index].suspect && (farIdx < 0 || objs[hi[i2].index].pc > objs[farIdx].pc)) farIdx = hi[i2].index;
      var F = (farIdx >= 0) ? cpFlPlace(model, scale, farIdx) : null;
      if (F !== null && !(F.t > P.t + 0.12)) { F = null; farIdx = -1; }
      // los tramos y lo que pesa cada uno en el reparto del tiempo (la pausa del principio, un segundo como mucho)
      // (lo lejano: si es un punto —un cuasar, una galaxia sin recorte— es un PASO, no una parada: llega con estelas, su placa
      // se lee al pasar y la camara se da la vuelta; dos segundos parados sobre un rombo de 15 px eran un tramo muerto)
      var farDwell = (F !== null) ? cpFlDwell(model, farIdx, o.extent) : 0;
      var through = (eArr.t > eA + 0.06), W = { open: 1.6, enter: through ? 1.3 : 0, cloud: through ? 3.6 : 1.6, orbit: 3.0, jump: (F !== null) ? 2.6 : 0, far: (F !== null) ? 1.2 * farDwell : 0, back: 2.8, rest: 0.7 };
      var h = Math.min(1, 0.07 * T), wAll = W.open + W.enter + W.cloud + W.orbit + W.jump + W.far + W.back + W.rest, u = (T - h) / wAll, t = h;
      key(0, photo, { photo: 1, box: 0 }, { rest: true });
      key(h, photo, { photo: 1, box: 0 }, { rest: true });
      t += W.open * u;
      key(t, cpFlCam({ yaw: 9 + 9 * a, pitch: 5 + 4 * a, zoom: 1, ox: 0, oy: 0, oz: -D / 2 + 0.2 * D, flat: 1, lens: Math.max(1, photo.lens * 0.72) }), { photo: 1, box: 1 }, null);
      if (through) {
         // por la foto adentro…
         t += W.enter * u;
         key(t, cpFlCamEyeAt({ x: 0.5 * eArr.x, y: 0.5 * eArr.y, t: eA }, -side * sway * 0.4, 3, zd, 1, k0), { photo: 1, box: 1 }, null);
         // …y la nube, a su ritmo: las profundidades que dejan el MISMO numero de objetos en cada tramo
         var depths = [], hiT = eArr.t - 0.03, parts = 4;
         for (i2 = 0; i2 < objs.length; ++i2) { var td = scale.t(objs[i2].pc) - Kd / D * 0.35; if (td > eA && td < hiT && !objs[i2].suspect) depths.push(td); }
         depths.sort(function(p, q) { return p - q; });
         for (j = 1; j < parts; ++j) {
            var f = j / parts, dj = (depths.length >= 2 * parts) ? depths[Math.floor(f * (depths.length - 1))] : eA + (hiT - eA) * f;
            dj = cpFlClamp(dj, eA + (hiT - eA) * 0.08 * j, hiT - (hiT - eA) * 0.08 * (parts - j));
            var wj = (dj - eA) / Math.max(1e-6, eArr.t - eA);
            key(t + W.cloud * u * f, cpFlCamEyeAt({ x: eArr.x * (0.5 + 0.5 * wj), y: eArr.y * (0.5 + 0.5 * wj), t: dj }, yawA * wj * 0.8 + side * sway * 0.5 * ((j % 2) ? 1 : -1) * (1 - wj), 3 + (pitP - 3) * wj, zd + (zP - zd) * wj * wj, 1, k0),
                { photo: 1, box: 1 }, null);
         }
      }
      t += W.cloud * u;
      key(t, arrive2, { photo: 1, box: 1 }, { visit: pro });
      key(t + 0.5 * W.orbit * u, midP, { photo: 1, box: 1 }, { visit: pro });
      t += W.orbit * u;
      key(t, leave2, { photo: 1, box: 1 }, { visit: pro });
      var lastYaw = yawB;
      if (F !== null) {
         var farA = cpFlCamLookAt(F, side * 9, 4, cpFlLookZoom(model, aspect, farIdx, CP_FL.DIVE_FILL, o.extent, o.height), 1), farB = cpFlCam(farA);
         farB.yaw += side * 4; farB.zoom *= 1.08;
         t += W.jump * u;
         key(t, farA, { photo: 1, box: 1 }, { visit: farIdx });
         if (W.far > 0) {
            t += W.far * u;
            key(t, cpFlCam(farB), { photo: 1, box: 1 }, { visit: farIdx });
         }
      }
      // de vuelta, de un tiron: la camara se pone de frente y la caja se aplasta sobre la foto
      t += W.back * u;
      key(t, photo, { photo: 1, box: 0 }, { rest: true });
      key(T, photo, { photo: 1, box: 0 }, { rest: true });
      flight.name = "Dive";
      flight.fx = { fadeIn: 0, fadeOut: CP_FL.END_FADE_S, title: true, counter: "pivot", trail: CP_FL.TRAIL * (0.7 + 0.6 * a) };
   }
   flight.duration = T;
   return cpFlMake(flight);
}

// ---------------------------------------------------------------------------
// EL VUELO PROPIO. Todas devuelven un vuelo NUEVO (no tocan el que reciben).
// ---------------------------------------------------------------------------
// Copia de una clave con OTRO tiempo: todos sus campos viajan (nombre, transicion, pausa…) al reordenar, sustituir o retemporizar.
function cpFlKeyAt(q, t) { return { t: t, cam: q.cam, layers: q.layers, visit: q.visit, rest: q.rest, label: q.label, trans: q.trans, pause: q.pause }; }
function cpFlNew(name, model, aspect) {
   return cpFlMake({ name: (name === undefined || name === null) ? "My flight" : name, kind: "user", keys: [], duration: 0, shortYaw: true, constantSpeed: true,
                     easeIn: 0.8, easeOut: 1.0, k0: cpFlK0(model || null), aspect: aspect, wn: model ? model.wn : 1, hn: model ? model.hn : 1, fx: { title: false, counter: "eye" } });
}
function cpFlCopy(flight, keys, more) {
   var f = { name: flight.name, kind: flight.kind, duration: flight.duration, keys: keys || flight.keys, shortYaw: flight.shortYaw, constantSpeed: flight.constantSpeed,
             easeIn: flight.easeIn, easeOut: flight.easeOut, loop: flight.loop, fx: flight.fx, k0: flight.k0, aspect: flight.aspect, wn: flight.wn, hn: flight.hn };
   if (more) for (var q in more) if (Object.prototype.hasOwnProperty.call(more, q)) f[q] = more[q];
   return cpFlMake(f);
}
// LOS TIEMPOS, SOLOS: cada tramo dura en proporcion a lo que se mueve la camara en el (un tramo en que no se
// mueve —dos vistas iguales— es una pausa: dura como el tramo medio). `total` = la duracion (0 = SEG_S por tramo).
function cpFlAutoTimes(flight, total) {
   var K = flight.keys, n = K.length, i;
   if (n === 0) return cpFlCopy(flight, [], { duration: 0 });
   if (n === 1) return cpFlCopy(flight, [cpFlKeyAt(K[0], 0)], { duration: (total > 0) ? total : 0 });
   var len = [], sum = 0, yaw = K[0].cam.yaw;
   for (i = 1; i < n; ++i) {
      // (por el camino corto, como se va a volar)
      var b = cpFlCam(K[i].cam), a0 = cpFlCam(K[i - 1].cam), d = (b.yaw - yaw) % 360;
      if (flight.shortYaw) { if (d > 180) d -= 360; if (d <= -180) d += 360; a0.yaw = 0; b.yaw = d; yaw += d; }
      len.push(cpFlCamMetric(a0, b, flight.k0)); sum += len[i - 1];
   }
   var mean = (sum > 0) ? sum / (n - 1) : 1, w = [], wsum = 0, factors = 0, pauses = 0;
   for (i = 0; i < n - 1; ++i) {
      w.push(Math.max(len[i], 0.25 * mean)); if (len[i] < 1e-9) w[i] = mean;
      var fk = (K[i + 1].trans === "slow") ? CP_FL.SLOW_K : 1;           // (camara lenta: el tramo pesa mas, dura mas)
      w[i] *= fk; factors += fk; wsum += w[i];
   }
   for (i = 0; i < n; ++i) pauses += K[i].pause;
   // el recorrido (sin las pausas) dura SEG_S por tramo —o lo que quepa si el usuario fijo la duracion—; las pausas se suman
   var T = cpFlClamp((total > 0) ? total : CP_FL.SEG_S * factors + pauses, CP_FL.DUR_MIN, CP_FL.DUR_MAX), Tm = Math.max(0.5, T - pauses), t = 0, keys = [];
   if (T - pauses < 0.5) T = Math.min(CP_FL.DUR_MAX, Tm + pauses);
   for (i = 0; i < n; ++i) {
      keys.push(cpFlKeyAt(K[i], (i === n - 1) ? T - K[i].pause : t));
      if (i < n - 1) t += K[i].pause + Tm * w[i] / wsum;
   }
   return cpFlCopy(flight, keys, { duration: T });
}
// AÑADIR UNA VISTA (la camara tal como la tiene el usuario). `at` = donde (por defecto, al final). Los tiempos se
// reparten solos; la duracion crece SEG_S por tramo salvo que el usuario la haya fijado (`keepDuration`).
function cpFlAddKey(flight, cam, at, keepDuration) {
   var K = flight.keys.slice(), n = K.length;
   if (n >= CP_FL.MAX_KEYS) return flight;
   var i = (typeof at === "number" && at >= 0 && at <= n) ? Math.round(at) : n;
   K.splice(i, 0, { t: 0, cam: cpFlCam(cam), layers: cpFlLayers(null), visit: -1, rest: false });
   return cpFlRetime(flight, K, keepDuration ? flight.duration : 0);
}
function cpFlRemoveKey(flight, index, keepDuration) {
   var K = flight.keys.slice();
   if (!(index >= 0 && index < K.length)) return flight;
   K.splice(index, 1);
   return cpFlRetime(flight, K, keepDuration ? flight.duration : 0);
}
function cpFlMoveKey(flight, from, to, keepDuration) {
   var K = flight.keys.slice(), n = K.length;
   if (!(from >= 0 && from < n && to >= 0 && to < n) || from === to) return flight;
   var k = K.splice(from, 1)[0];
   K.splice(to, 0, k);
   return cpFlRetime(flight, K, keepDuration ? flight.duration : flight.duration);
}
// SUSTITUIR LA CAMARA de una vista por otra (la actual del usuario); conserva su nombre. Los tiempos se vuelven a repartir.
function cpFlReplaceKey(flight, index, cam, keepDuration) {
   var K = flight.keys.slice();
   if (!(index >= 0 && index < K.length)) return flight;
   var nk = cpFlKeyAt(K[index], K[index].t); nk.cam = cpFlCam(cam); K[index] = nk;
   return cpFlRetime(flight, K, keepDuration ? flight.duration : 0);
}
// PONERLE NOMBRE a una vista ("" = el de fabrica, «Vista n»). No toca los tiempos.
function cpFlLabelKey(flight, index, label) {
   var K = flight.keys.slice();
   if (!(index >= 0 && index < K.length)) return flight;
   var nk = cpFlKeyAt(K[index], K[index].t);
   nk.label = String(label === undefined || label === null ? "" : label).replace(/^\s+|\s+$/g, "");
   K[index] = nk;
   return cpFlCopy(flight, K);
}
// LA TRANSICION con que se llega a la vista `index` (ver CP_FL.TRANS) y su PAUSA (segundos). Los tiempos se vuelven a repartir.
function cpFlSetTrans(flight, index, trans, keepDuration) {
   var K = flight.keys.slice();
   if (!(index >= 0 && index < K.length) || CP_FL.TRANS.indexOf(trans) < 0) return flight;
   var nk = cpFlKeyAt(K[index], K[index].t); nk.trans = trans; K[index] = nk;
   return cpFlRetime(flight, K, keepDuration ? flight.duration : 0);
}
function cpFlSetPause(flight, index, seconds, keepDuration) {
   var K = flight.keys.slice();
   if (!(index >= 0 && index < K.length)) return flight;
   var nk = cpFlKeyAt(K[index], K[index].t); nk.pause = cpFlClamp(cpFlNum(seconds, 0), 0, CP_FL.PAUSE_MAX); K[index] = nk;
   return cpFlRetime(flight, K, keepDuration ? flight.duration : 0);
}
function cpFlRetime(flight, keys, total) {
   // (las claves llegan EN SU ORDEN: se les pone un tiempo creciente provisional para que `cpFlMake` no las reordene)
   var tmp = [];
   for (var i = 0; i < keys.length; ++i) tmp.push(cpFlKeyAt(keys[i], i));
   return cpFlAutoTimes(cpFlCopy(flight, tmp, { duration: keys.length }), total);
}
// CAMBIAR LA DURACION: el mismo recorrido, mas despacio o mas deprisa (los tiempos de las claves, en proporcion).
function cpFlSetDuration(flight, seconds) {
   var T = cpFlClamp(cpFlNum(seconds, flight.duration), CP_FL.DUR_MIN, CP_FL.DUR_MAX), k = (flight.duration > 0) ? T / flight.duration : 1, keys = [];
   // (con pausas o transiciones propias los tiempos no escalan en proporcion —las pausas son segundos fijos—: se reparten de nuevo)
   if (cpFlHasSegments(flight)) return cpFlAutoTimes(flight, T);
   for (var i = 0; i < flight.keys.length; ++i) { var q = flight.keys[i]; keys.push(cpFlKeyAt(q, q.t * k)); }
   return cpFlCopy(flight, keys, { duration: T });
}

// JSON DE IDA Y VUELTA (para guardar el vuelo con la imagen y para recordarlo). Los numeros, con seis decimales.
function cpFlToJson(flight) {
   function r(x) { return Math.round(x * 1e6) / 1e6; }
   var f = cpFlMake(flight), keys = [];
   for (var i = 0; i < f.keys.length; ++i) {
      var k = f.keys[i], c = {}, j;
      for (j = 0; j < CP_FL_CAM_FIELDS.length; ++j) c[CP_FL_CAM_FIELDS[j]] = r(k.cam[CP_FL_CAM_FIELDS[j]]);
      var jk = { t: r(k.t), cam: c, layers: { photo: r(k.layers.photo), box: r(k.layers.box) }, visit: k.visit, rest: k.rest };
      if (k.label.length > 0) jk.label = k.label;          // (solo si lo hay: el JSON de antes sigue siendo el mismo)
      if (k.trans !== "smooth") jk.trans = k.trans;
      if (k.pause > 0) jk.pause = r(k.pause);
      keys.push(jk);
   }
   return JSON.stringify({ format: f.format, name: f.name, kind: f.kind, duration: r(f.duration), shortYaw: f.shortYaw, constantSpeed: f.constantSpeed, easeIn: r(f.easeIn), easeOut: r(f.easeOut),
                           loop: f.loop, k0: r(f.k0), aspect: r(f.aspect), wn: r(f.wn), hn: r(f.hn), fx: { fadeIn: r(f.fx.fadeIn), fadeOut: r(f.fx.fadeOut), vignette: r(f.fx.vignette), trail: r(f.fx.trail), glow: r(f.fx.glow), title: f.fx.title, counter: f.fx.counter },
                           keys: keys });
}
// Devuelve { ok, flight, why }. Lo que no sea un vuelo (texto roto, otra version, sin claves) NO lanza: dice por que.
function cpFlFromJson(text) {
   var q = null;
   try { q = JSON.parse(String(text)); } catch (e) { return { ok: false, flight: null, why: "not JSON" }; }
   if (!q || typeof q !== "object" || q instanceof Array) return { ok: false, flight: null, why: "not a flight" };
   if (q.format !== CP_FL.FORMAT) return { ok: false, flight: null, why: "unknown format" };
   if (!(q.keys instanceof Array)) return { ok: false, flight: null, why: "no keys" };
   for (var i = 0; i < q.keys.length; ++i) if (!q.keys[i] || typeof q.keys[i] !== "object" || !q.keys[i].cam || typeof q.keys[i].cam !== "object") return { ok: false, flight: null, why: "bad key " + i };
   return { ok: true, flight: cpFlMake(q), why: "" };
}

// ---------------------------------------------------------------------------
// EL PLAN DE RENDER. `opts` = { fps (24 | 30 | 60), width, height, quality (85 | 92 | 97), msPerFrame (lo medido) }.
// Devuelve { ok, why, fps, n (fotogramas), duration, width, height, quality, time( k ) -> el segundo del fotograma k,
//            bytesPerFrame, bytes (estimado), seconds (estimado; -1 sin msPerFrame), avi (lo que diga `cpAviPlan`:
//            si cabe en un fichero o en cuantos hay que partirlo) }.
// En un vuelo en bucle el ultimo fotograma cae en la pausa final, que es igual a la primera: el bucle cierra.
// ---------------------------------------------------------------------------
function cpFlPlan(flight, opts) {
   var o = opts || {}, fps = (CP_FL.FPS.indexOf(o.fps) >= 0) ? o.fps : 30, w = Math.round(cpFlNum(o.width, 1920)), h = Math.round(cpFlNum(o.height, 1080));
   var out = { ok: false, why: "", fps: fps, n: 0, duration: flight ? flight.duration : 0, width: w, height: h, quality: 0, bytesPerFrame: 0, bytes: 0, seconds: -1, avi: null, time: null };
   if (!flight || !(flight.keys.length >= 2) || !(flight.duration > 0)) { out.why = "the flight needs at least two views"; return out; }
   // (dimensiones pares: los reproductores las piden)
   if (!(w >= 16 && h >= 16 && w <= 8192 && h <= 8192) || (w % 2) || (h % 2)) { out.why = "bad frame size"; return out; }
   var q = (o.quality === 85 || o.quality === 97) ? o.quality : CP_FL.QUALITY, n = Math.max(2, Math.round(flight.duration * fps));
   out.quality = q; out.n = n;
   out.time = function(k) { return cpFlClamp(k, 0, n - 1) / fps; };
   out.bytesPerFrame = Math.round(CP_FL.JPEG_BYTES_PER_MPX[q] * w * h / 1e6);
   out.bytes = out.bytesPerFrame * n;
   if (o.msPerFrame > 0) out.seconds = n * o.msPerFrame / 1000;
   if (typeof cpAviPlan === "function") { out.avi = cpAviPlan(w, h, fps, n, out.bytesPerFrame); out.bytes = out.avi.bytes; }
   out.ok = true;
   return out;
}
