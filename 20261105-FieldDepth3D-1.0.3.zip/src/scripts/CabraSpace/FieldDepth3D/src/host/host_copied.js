// ============================================================================
// host/host_copied.js — LO QUE LOS MODULOS DE CabraPilot NECESITAN, COPIADO TAL CUAL
// ----------------------------------------------------------------------------
// PROCEDENCIA: CabraPilot, rama integracion-1410c (097fba6), CabraCore/src —
// engine/annotations.js, engine/crop.js, engine/gradient.js, engine/inherited.js,
// engine/prefs.js, engine/survey.js, ui/section.js, ui/theme.js y
// CabraPilot_resources.jsh—. Sacado con un cierre transitivo de simbolos (solo lo
// que usan los modulos de starfield copiados en src/engine y src/ui) el 14-oct-2026.
// Lo que alli arrastraba medio programa (el render del visor, la linealidad, la red
// con registro, quitar estrellas) NO esta aqui: va simplificado en host/host.js.
// No editar a mano lo copiado: si cambia en CabraPilot, se vuelve a copiar.
// ES5.
// ============================================================================

// ==== from CabraPilot_resources.jsh

function cpTooltip(key) {
   return cpWrapTooltip(cpTooltipText(key));
}

function cpWrapTooltip(text) {
   // EN MODO PREVIEW el nombre interno de una copia no se enseña (el rotulo de
   // su ficha si): engine/preview_mode.js, `cpPvDisplayText`. Fuera, no toca nada.
   if (text && typeof cpPvDisplayText === "function")
      text = cpPvDisplayText(String(text));
   if (!text || text.length <= CP_TOOLTIP_WRAP)
      return text || "";
   // (2-nov-2026, Cabra3D: los tooltips de la barra vistos pintados, tests/c3_bar_tips.js) un <br> del texto EMPIEZA renglón: cada
   // tramo entre saltos se parte por su cuenta. Antes la cuenta de 72 seguía a través del <br> («kpc<br>Órbita» era una sola palabra)
   // y el renglón de después se cortaba a destiempo: «Orbit over the» / «next 2 Gyr…», «The drawn orbit includes the» / «rotating bar…»,
   // «kpc» o «0,31» solos. Costura del rojo: CP_TOOLTIP_BR_RESET = false (lo de antes).
   var segs = (CP_TOOLTIP_BR_RESET === false) ? [String(text)] : String(text).split(/<br\s*\/?>/i);
   var lines = [];
   for (var s = 0; s < segs.length; ++s) {
      var words = segs[s].split(" ");
      var line = "";
      for (var i = 0; i < words.length; ++i) {
         if (line.length > 0 && (line.length + 1 + words[i].length) > CP_TOOLTIP_WRAP) {
            lines.push(line);
            line = words[i];
         } else {
            line = (line.length > 0) ? (line + " " + words[i]) : words[i];
         }
      }
      if (line.length > 0 || segs.length > 1)      // (un tramo vacío —«<br><br>»— es un renglón en blanco y se queda)
         lines.push(line);
   }
   return "<html>" + lines.join("<br>") + "</html>";
}
var CP_TOOLTIP_BR_RESET = true;

// Los tooltips largos se parten en varias líneas: Qt solo respeta los saltos
// si el texto es rich text, así que se envuelve en <html> con <br> cada ~72
// caracteres (sin cortar palabras).
var CP_TOOLTIP_WRAP = 72;

// ==== from engine\annotations.js

// ---------------------------------------------------------------------------
// Metadata lista para los catalogos, con la guarda de la epoca.
// Devuelve null si la imagen no tiene solucion astrometrica.
// ---------------------------------------------------------------------------

// (CP_ANNOT_DEFAULT_EPOCH, optSafeView y cpAnnotMetadata: comunes, ../CabraShared/csh_astrometry.js)

// Sexagesimal en el formato que come `sim-coo`: "HH MM SS.ss" y "+DD MM SS.s".
function cpAnnotSexRA(deg) {
   var t = deg / 15 * 3600;
   while (t < 0) t += 86400;
   t = t % 86400;
   var h = Math.floor(t / 3600);
   var m = Math.floor((t - h * 3600) / 60);
   var s = t - h * 3600 - m * 60;
   return format("%02d %02d %05.2f", h, m, s);
}

function cpAnnotSexDec(deg) {
   var sign = (deg < 0) ? "-" : "+";
   var t = Math.abs(deg) * 3600;
   var d = Math.floor(t / 3600);
   var m = Math.floor((t - d * 3600) / 60);
   var s = t - d * 3600 - m * 60;
   return format("%s%02d %02d %04.1f", sign, d, m, s);
}

// ==== from engine\crop.js

// sc = escala del preview; kx/ky = píxeles de imagen por píxel de bitmap.
function cpCropImgToViewport(ix, iy, sc, sx, sy, kx, ky) {
   return {
      x: Math.round((ix / Math.max(1e-9, kx)) * sc - sx),
      y: Math.round((iy / Math.max(1e-9, ky)) * sc - sy)
   };
}

// ==== from engine\gradient.js

function cpProcessAvailable(name) {
   try { return (typeof CP_GLOBAL[name] === "function"); } catch (e) { return false; }
}

// Que ve EL PROCESO de catalogo XPSD DE ESTA INSTANCIA para una version
// concreta, y nada mas (desde el 5-oct-2026 no mira los ajustes: ver la nota de
// arriba). Devuelve
//    { count, valid, measured, error, source, files }
// con la distincion que faltaba: `measured:false` y `count:-1` es NO SE HA
// PODIDO SABER, que no es lo mismo que `measured:true` y `count:0`, que es
// «el proceso esta y no tiene bases».
function cpXpsdDatabaseProbe(processName, releaseConst) {
   var r = { count: -1, valid: false, measured: false, error: "", source: "none", files: [] };
   if (!cpProcessAvailable(processName)) {
      r.error = processName + " is not installed";
      return r;
   }
   var P = cpNewProcess(processName);
   if (!P) {
      r.error = "could not instantiate " + processName;
      return r;
   }
   try {
      P.command = "get-info";
      if (releaseConst !== null && typeof releaseConst !== "undefined")
         P.dataRelease = releaseConst;
      try { P.verbosity = 0; } catch (eV) {}
      // `get-info` devuelve true cuando contesta (medido en 1706, `cp_execfail_probe.log`).
      // Un false es que NO ha podido contestar: no es «el proceso esta y no tiene bases»
      // (measured true, count 0), es «no se ha podido saber» (measured false, count -1).
      if (P.executeGlobal() === false) {
         r.error = processName + " get-info did not finish";
         return r;
      }
      r.measured = true;
      r.source = "process";
      r.count = 0;
      try {
         var paths = P.databaseFilePaths;
         for (var i = 0; i < paths.length; ++i)
            r.files.push(String(paths[i]));
         r.count = r.files.length;
      } catch (eL) {}
      // ISVALID, NO LA LONGITUD: es lo que comprueba el nucleo.
      try { r.valid = (P.isValid === true); } catch (eI) { r.valid = (r.count > 0); }
   } catch (e) {
      r.error = String(e.message || e);
   }
   return r;
}

// (3-nov-2026, CPD C7) Aqui estaban cpXpsdSettingsFilesOnDisk, cpPixInsightConfigDirs, cpXpsdScanSettingsText y las claves
// CP_GAIA_*_SETTINGS: leian a mano los core-*.settings del nucleo y el programa no los llamaba (grep). Se fueron a
// tests/c3_settings_disk.jsh, que solo usan las pruebas (registrar la base Gaia en una instancia de pruebas).

function cpNewProcess(name) {
   try { return new CP_GLOBAL[name](); } catch (e) {
      console.warningln(optT("CabraPilot: could not instantiate ") + name + ": " + (e.message || e));
      return null;
   }
}

// ==== from engine\inherited.js


function optUniqueId(baseId) {
   var clean = (baseId || "CP_Img").replace(/[^A-Za-z0-9_]/g, "_");
   if (!/^[A-Za-z]/.test(clean))
      clean = "CP_" + clean;
   var id = clean;
   var n = 1;
   while (optFindWorkspaceViewById(id)) {
      if (n > 100000)
         throw new Error("Could not generate a unique view id for base id: " + clean);
      id = clean + "_" + n;
      ++n;
   }
   return id;
}

function optFindWorkspaceViewById(id) {
   if (!id || id.length === 0)
      return null;
   try {
      var view = View.viewById(id);
      if (optSafeView(view))
         return view;
   } catch (e) {
   }
   return null;
}

// ==== from engine\prefs.js

// ---------------------------------------------------------------------------
// VALIDAR. Todas devuelven `fallback` ante cualquier cosa que no sea
// exactamente lo esperado; ninguna lanza y ninguna acota.
// ---------------------------------------------------------------------------
function cpPrefsObject(v) {
   return (v !== null && typeof v === "object" && Object.prototype.toString.call(v) === "[object Object]") ? v : {};
}

// Uno de una lista cerrada (comparacion estricta).
function cpPrefsChoice(v, list, fallback) {
   for (var i = 0; list && i < list.length; ++i)
      if (list[i] === v)
         return v;
   return fallback;
}

function cpPrefsNum(v, lo, hi, fallback) {
   if (typeof v !== "number" || !isFinite(v))
      return fallback;
   // Una pizca de holgura: 0.7 guardado como 0.7000000000000001 sigue valiendo.
   var eps = 1e-9 * Math.max(1, Math.abs(lo), Math.abs(hi));
   if (v < lo - eps || v > hi + eps)
      return fallback;
   return Math.max(lo, Math.min(hi, v));
}

// ==== from engine\survey.js

// (3-nov-2026, CPD C10: CP_SURVEY_CURL, la ruta fija de curl que nadie usaba, fuera; el curl de cada sistema es CSH_CURL de CabraShared/csh_net.js)

// ==== from ui\section.js

// Port de optSetControlVisible (Dev_200/ui/theme.js:233): en PJSR no basta con
// asignar `visible`; hay que llamar además a show()/hide() para que el sizer
// recalcule y el hueco desaparezca de verdad.
function cpSetControlVisible(control, visible) {
   if (!control)
      return;
   var v = (visible === true);
   try { control.visible = v; } catch (e0) {}
   // LO PEDIDO queda apuntado en el control: `control.visible` dice si se VE (y
   // en un dialogo sin mostrar no se ve nada), no si alguien lo ha escondido.
   // Quien reparte sitio (la matriz de capas: `cpEnginePanelColumnFree`) necesita
   // saber que secciones estan escondidas aunque el dialogo no este en pantalla.
   try { control.__cpHidden = !v; } catch (eH) {}
   try {
      if (v) {
         if (typeof control.show === "function") control.show();
      } else {
         if (typeof control.hide === "function") control.hide();
      }
   } catch (e1) {}
}

// ==== from ui\theme.js

// ---------------------------------------------------------------------------
// Helpers de aplicación
// ---------------------------------------------------------------------------
// `raw` (opcional) son reglas que se pegan detrás SIN pasar por
// `scaledStyleSheet`, con los píxeles ya físicos: las que llevan una
// `image:url()`, porque `scaledStyleSheet` reescribe la ruta (ui/atlas.js).
// LA ESCALA es la de CabraPilot (`cpScaleCss`, ui/atlas.js): con factor 1 es la
// `scaledStyleSheet` de PixInsight, la de siempre; con otro, la misma cuenta
// (cada `Npx` a redondeo-al-par de N × escala) con la escala propia.
function cpApplyStyle(control, css, raw) {
   var tail = raw ? String(raw) : "";
   try {
      if (typeof control.scaledStyleSheet === "function")
         control.styleSheet = cpScaleCss(css, control) + tail;
      else
         control.styleSheet = css + tail;
   } catch (e) {
      try { control.styleSheet = css; } catch (e2) {}
   }
   // Y se repone lo que el pulido acaba de borrar. Ver la nota larga de arriba.
   cpReapplyWidths();
}

// (Cabra3D, 15-oct-2026, receta medida en CabraQuality: sin foco de teclado ni «boton por defecto», o Windows pinta su trama
// azul de puntos encima del texto del primer boton. El teclado —Esc— lo atiende el dialogo en onKeyPress.)
// (FocusStyle.NoFocus NO existe en PJSR —sonda de CabraStars—: la asignacion lanzaba y el try la callaba; el comun pone 0)
function cpNoFocus(btn) { if (btn && btn.cpNoFocus !== true) { cshNoFocus(btn); try { btn.cpNoFocus = true; } catch (e) {} } }
function cpStyleToggle(btn, active) {
   cpApplyStyle(btn, active ? CP_CSS_TOGGLE_ON : CP_CSS_TOGGLE_OFF);
   cpNoFocus(btn);
}

// Texto informativo dentro de tarjetas (fondo del panel, sin borde).
function cpStyleHint(label) {
   cpApplyStyle(label,
      "background-color:" + CP_UI.bgPanel +
      "; color:" + CP_UI.textDim + "; border:none; font-size:10px;");
}

// Etiqueta de estado tipo "píldora" (patrón optThemeSetStatus de PI Workflow):
// un punto de color + texto. kind: "ok" | "pending" | "error" | "info".
function cpStyleStatusPill(label, text, kind) {
   var col = CP_UI.textDim;
   var bg = CP_UI.bgInset;
   var edge = CP_UI.border;
   if (kind === "ok")      { col = CP_UI.success; bg = CP_UI.successBg; }
   else if (kind === "error") { col = CP_UI.danger;  bg = CP_UI.dangerBg; edge = CP_UI.danger; }
   else if (kind === "info")  { col = CP_UI.primaryLight; bg = CP_UI.primaryBg; }
   // «warn» no es «error»: no ha fallado nada, hace falta una decision. Se pinta
   // con el oro de la interfaz, que es el color de «esto pide tu atencion».
   else if (kind === "warn")  { col = CP_UI.primaryLight; bg = CP_UI.primaryBg; edge = CP_UI.primaryRing; }
   cpApplyStyle(label,
      "background-color:" + bg + "; color:" + col +
      "; border:1px solid " + edge + "; border-radius:" + CP_PILL_3 +
      "; padding:3px 9px; font-size:10px;");
   // EN MODO PREVIEW el nombre interno de una copia («CP_tmp_pv1_…») no se
   // enseña: sale el rotulo de su ficha («Preview 1») (engine/preview_mode.js).
   // Aqui, que es por donde pasa el pie de todos los paneles. Fuera del modo no
   // toca nada. (Con `typeof`: este fichero se carga tambien sin el motor.)
   if (typeof cpPvDisplayText === "function")
      text = cpPvDisplayText(text);
   try { label.text = text; } catch (e) {}
   // Una pildora que se parte en lineas pide el alto de TODAS ellas (`cpFitWrappedPill`); `CP_LEFT_ROW_W` es el
   // ancho de la columna de las herramientas (donde viven las pildoras que se parten).
   try {
      if (label.wordWrapping === true)
         cpFitWrappedPill(label, (typeof CP_LEFT_ROW_W !== "undefined") ? CP_LEFT_ROW_W : 300);
   } catch (eFit) {}
   // La CLASE de lo dicho queda apuntada en la etiqueta: el Apply por lotes
   // (ui/batch_ui.js) lee del pie de cada panel lo que ha pasado con cada imagen,
   // y «aviso» o «error» no se pueden deducir del texto.
   try { label.__cpKind = String(kind || ""); } catch (e2) {}
   // Y CUANTAS VECES SE HA ESCRITO: el lote lee el pie antes y despues de cada
   // imagen, y si la cuenta no se ha movido el panel no ha dicho nada de ESA
   // (`cpBatchSaidFresh`, engine/batch.js).
   try { label.__cpSaidN = (Number(label.__cpSaidN) || 0) + 1; } catch (e3) {}
   // UN TOOLTIP QUE ERA DEL TEXTO ANTERIOR SE VA CON EL (8-oct-2026). El informe
   // de un lote deja su texto entero en el tooltip (`cpBatchShowPill`); un panel
   // que despues reescribe solo el texto («MGC applied · H») dejaba debajo el
   // informe del lote anterior, y el lote siguiente lo citaba como motivo de
   // cada imagen. Quien quiera tooltip lo pone DESPUES de llamar aqui.
   try {
      if (label.__cpTipBound === true) {
         label.toolTip = "";
         label.__cpTipBound = false;
      }
   } catch (e4) {}
}

// ---------------------------------------------------------------------------
// UN ALTO QUE NO DEPENDE DE LO QUE DIGA EL TEXTO (2-oct-2026)
// ----------------------------------------------------------------------------
// Una etiqueta de texto enriquecido mide de alto lo que pida su contenido, y un
// glifo que la fuente no tiene (un ⚠) sale de otra fuente, mas alta: la linea de
// estadisticas media 30 px sin avisos y 32 con ellos, y todo lo que cuelga de
// ella —el visor— subia y bajaba 2 px al cambiar de imagen. Lo vio Nino en
// pantalla («la linea de texto de arriba cambia de tamano con el texto y
// desplaza la imagen») y esta medido en `_tests/cp_p9_gui3_probe.log`.
//
// El alto se FIJA al del contenido MAS ALTO que la etiqueta puede llevar
// (`tallest`, con su mismo marcado), y se lo pregunta a Qt con la hoja ya
// aplicada, como `cpTextWidthNeeded`: `adjustToContents()` es el oraculo. No es
// un numero puesto a mano: sigue a la fuente y a la escala de la pantalla.
// Devuelve el alto fijado (0 si no se pudo medir: la etiqueta queda como estaba).
function cpFixHeightToText(ctrl, tallest) {
   try {
      var keep = ctrl.text;
      ctrl.text = tallest;
      ctrl.adjustToContents();
      var h = ctrl.height;
      ctrl.text = keep;
      if (!(h > 0))
         return 0;
      ctrl.setFixedHeight(h);
      return h;
   } catch (e) {
      return 0;
   }
}

// ---------------------------------------------------------------------------
// Igual, pero MINIMO en vez de fijo: para los botones que comparten fila.
// ----------------------------------------------------------------------------
// `cpFitToText` fija el ancho, y eso vale para un boton que va a su aire. Pero en
// una fila donde tres botones se reparten el sitio con `add(btn, 100)`, fijarles
// el ancho les quita la elasticidad: dejarian de crecer al ensanchar la columna y
// la fila se veria descuadrada. Lo que hace falta es un SUELO — que se estiren
// cuanto quieran, pero que no bajen de lo que mide su texto.
//
// De ahi el defecto 11 (6-ago-2026): `Re-measure` compartia fila con `Place` y
// `Seed grid`, cada uno con un tercio del sitio, y su texto no cabia en ese
// tercio: se leía «?e-measure», cortado por los dos lados.
//
// Y HAY QUE VOLVER A LLAMARLO AL CAMBIAR DE IDIOMA. El minimo se calcula del
// texto, y el texto cambia: «Re-measure» son 10 caracteres y «Volver a medir» son
// 14. Un minimo calculado en ingles deja el castellano cortado, que es el mismo
// fallo con otra cara.
// Y HAY QUE APUNTARLO, porque escribirlo no basta: aplicar una hoja de estilo lo
// borra. Toda la historia, medida, en la nota de `CP_WIDTH_FLOORS`.
function cpMinWidthToText(ctrl, extra) {
   try {
      var t = String(ctrl.text || "");
      if (t.length === 0) return ctrl;
      var w = cpTextWidthNeeded(ctrl, extra, 28);
      ctrl.minWidth = w;
      cpRegisterWidth(ctrl, w, false);
   } catch (e) {}
   return ctrl;
}







// Colores para pintar con Graphics (0xAARRGGBB). Todos de la tabla de Atlas; los
// nombres «AMBER» se conservan porque los usan los paneles.



// La hoja GLOBAL se aplica al diálogo raíz: estiliza todos sus descendientes.
// Detrás van la casilla y la flecha del desplegable, que son imágenes nuestras.
function cpStyleDialog(dlg) {
   cpApplyStyle(dlg, CP_CSS_GLOBAL, cpAtlasRawCss(dlg) + cpNativeFrameCss(dlg));
}

function cpStylePrimaryButton(btn) { cpApplyStyle(btn, CP_CSS_PRIMARY); cpNoFocus(btn); }

// Los nombres son los de siempre (los usan todos los paneles); los valores,
// los de Atlas.
var CP_UI = {
   bg:           cpQss(CP_ATLAS.bg),
   bgPanel:      cpQss(CP_ATLAS.surface),
   bgPanelAlt:   cpQss(CP_ATLAS.surface2),
   bgInset:      cpQss(CP_ATLAS_INSET),
   border:       cpQss(CP_ATLAS.line),
   borderStrong: cpQss(CP_ATLAS_LINE_STRONG),
   text:         cpQss(CP_ATLAS.text),
   textDim:      cpQss(CP_ATLAS.text2),
   textMuted:    cpQss(CP_ATLAS.text3),
   textMute:     cpQss(CP_ATLAS_TEXT_OFF),
   primary:      cpQss(CP_ATLAS.gold),
   primaryLight: cpQss(CP_ATLAS.goldLight),
   primaryRing:  cpQss(CP_ATLAS_GOLD_RING),
   primaryBg:    cpQss(CP_ATLAS.surface2),
   primaryHover: cpQss(CP_ATLAS.goldLight),
   doorRest:     cpQss(CP_ATLAS_DOOR_REST),      // la placa de «Preview» a la espera (sin oro)
   doorEdge:     cpQss(CP_ATLAS_DOOR_EDGE),      // y su filete, claro y neutro
   doorLit:      cpQss(CP_ATLAS_DOOR_LIT),       // y con el modo encendido
   ink:          cpQss(CP_ATLAS.ink),
   success:      cpQss(CP_ATLAS.ok),
   successBg:    cpQss(CP_ATLAS_OK_BG),
   danger:       cpQss(CP_ATLAS.error),
   dangerBg:     cpQss(CP_ATLAS_ERROR_BG),
   radius: "6px",
   radiusLg: "10px",
   fontFamily:  cpFontCss("text"),
   fontMono:    cpFontCss("mono"),
   fontDisplay: cpFontCss("display")
};

// Repone lo apuntado. Devuelve cuántos hizo falta reponer — el test de regresión
// lo usa como señal de que el borrado sigue ocurriendo (si dejara de ocurrir,
// reponer cero sería la respuesta correcta y no un fallo).
// Un control ya destruido lanza al leerlo y se cae del registro: un diálogo
// cerrado no debe dejar entradas vivas.
function cpReapplyWidths() {
   if (CP_WIDTH_REPOSING) return 0;
   CP_WIDTH_REPOSING = true;
   var vivos = [], repuestos = 0;
   for (var i = 0; i < CP_WIDTH_FLOORS.length; ++i) {
      var e = CP_WIDTH_FLOORS[i];
      try {
         if (e.fixed) {
            if (e.c.minWidth !== e.v || e.c.maxWidth !== e.v) {
               e.c.setFixedWidth(e.v);
               ++repuestos;
            }
         } else if (e.c.minWidth < e.v) {
            e.c.minWidth = e.v;
            ++repuestos;
         }
         vivos.push(e);
      } catch (eDead) {}
   }
   CP_WIDTH_FLOORS = vivos;
   CP_WIDTH_REPOSING = false;
   return repuestos;
}

// Conmutador COMPACTO (log, 0-5%, K/R/G/B…). Sin anchos fijos: en pantallas
// con escalado DPI los anchos fijos se inflan y los botones se solapan; aquí
// el botón se ajusta a su texto con padding mínimo.
var CP_PILL_3 = cpPillRadius(3) + "px";

// LA MISMA CUENTA PARA UNA PILDORA DE ESTADO QUE SE PARTE (12-oct-2026). La pildora de pie de un panel de motor
// («✓ tried: …», «✓ swept Intensity (S): 0.20 · 0.35 · 0.50 …») es una etiqueta con `wordWrapping`: cuando el texto
// no cabe en una linea se parte en dos, pero el sizer solo le reserva UNA (el mismo hueco de PJSR que arriba), asi
// que la seccion pedia un alto de menos, la columna la dejaba asi y las filas de mandos de debajo se pisaban
// (MEDIDO con el dialogo MOSTRADO: `_tests/cp_engine_fit_probe.js`). Aqui se cuenta el texto a su ancho, descontando el
// relleno y el borde que pone `cpStyleStatusPill` (padding 9 px de lado, 3 de alto, borde 1: px de hoja de estilo,
// que escalan con la pantalla), y se le dice a la pildora el alto minimo de esas lineas: el layout de la seccion
// pide lo que hace falta. Se parte por palabras (como Qt) y se pasa por alto si dudamos: sobrar es feo, cortar es un defecto.
function cpFitWrappedPill(ctrl, ancho) {
   try {
      var t = String(ctrl.text || "");
      if (t.length === 0) {
         ctrl.setMinHeight(0);
         return ctrl;
      }
      var sc = cpUiScale(ctrl);
      var w = (isFinite(ancho) && ancho > 0) ? ancho : 300;
      try { if (ctrl.width > 100 && ctrl.width < w) w = ctrl.width; } catch (e0) {}
      var usable = w - Math.round(20 * sc) - 4;
      var linea = 0, f = ctrl.font;
      try { linea = f.lineSpacing; } catch (e1) {}
      if (!(linea > 0)) { try { linea = f.height; } catch (e2) {} }
      if (!(linea > 0)) linea = Math.round(14 * sc);
      var words = t.replace(/<[^>]*>/g, "").split(" "), lines = 1, cur = 0, sp = f.width(" ");
      for (var i = 0; i < words.length; ++i) {
         var ww = f.width(words[i]);
         if (cur > 0 && cur + sp + ww > usable) { ++lines; cur = ww; }
         else cur = (cur > 0) ? cur + sp + ww : ww;
         while (cur > usable && usable > 0) { ++lines; cur -= usable; }
      }
      ctrl.setMinHeight(lines * linea + Math.round(8 * sc));
   } catch (e) {}
   return ctrl;
}

// ---------------------------------------------------------------------------
// CUÁNTO SITIO NECESITA DE VERDAD UN CONTROL PARA SU TEXTO
// ----------------------------------------------------------------------------
// `font.width(texto) + extra` NO BASTA, y está medido (7-ago-2026,
// `_tests/cp_textwidth_probe.js`, a raíz de ver `Clear annotations` cortado EN
// PANTALLA con su suelo puesto y honrado):
//
//     control                        font+extra   Qt pide   falta
//     btnClear «Clear annotations»          140       144      +4
//     btnNet   «Fetch»                        59        63      +4
//     cbLegend «Scale and orientation»       171       172      +1
//
// La causa estaba escrita desde el 6-ago en el comentario de `cpFitToText` sin
// que nadie sacara la consecuencia: **`font.width` mide con la fuente DEL
// CONTROL y la hoja de estilo dibuja con la suya**, con su propio padding. Los
// cuatro píxeles que faltan son justo los que se comían la última letra.
//
// `adjustToContents()` es el oráculo bueno: lo calcula Qt CON la hoja aplicada,
// que es exactamente lo que luego pinta. Se toma el MAYOR de los dos — sobrar
// sitio no corta nada, faltar sí.
//
// Y OJO CON EL COROLARIO DE §0.2: esto se descubrió mirando la pantalla, no
// midiendo. El número decía 140 para un texto de 116 y parecía de sobra.
function cpTextWidthNeeded(ctrl, extra, porDefecto) {
   var t = String(ctrl.text || "");
   if (t.length === 0)
      return 0;
   var calculado = 0, qt = 0;
   try {
      calculado = ctrl.font.width(t) + (isFinite(extra) ? extra : porDefecto);
   } catch (e1) {}
   // `adjustToContents` redimensiona el control como efecto secundario. No
   // importa: quien manda al final es el sizer, y esto ocurre al construir.
   try {
      ctrl.adjustToContents();
      qt = ctrl.width;
   } catch (e2) {}
   return Math.max(calculado, qt);
}

// Apunta (o actualiza) el ancho de un control. `fixed` distingue el ancho fijo
// de `cpFitToText` del suelo de `cpMinWidthToText`: reponerlos no es lo mismo.
function cpRegisterWidth(ctrl, value, fixed) {
   if (!isFinite(value) || value <= 0) return;
   for (var i = 0; i < CP_WIDTH_FLOORS.length; ++i)
      if (CP_WIDTH_FLOORS[i].c === ctrl) {
         CP_WIDTH_FLOORS[i].v = value;
         CP_WIDTH_FLOORS[i].fixed = !!fixed;
         return;
      }
   CP_WIDTH_FLOORS.push({ c: ctrl, v: value, fixed: !!fixed });
}

// Hoja global.
// EL FILETE QUE PIXINSIGHT PONE POR SU CUENTA (13-oct-2026). Con la hoja puesta
// quedan dos cosas que siguen a la escala de PixInsight y no a la de la hoja:
// el marco interior de un campo de texto y el de una caja con desplazamiento
// (el visor, los árboles, la fórmula). Es 1 px lógico por lado: 1 px físico a
// escala 1 y a 1,25, 2 a 1,5 (redondeo al par). MEDIDO (pack UISCALE): con la
// escala de CabraPilot a 1,5 sobre un PixInsight a 1,25, un campo medía 34 px
// de alto y no los 36 de 1,5 (cada fila con un número, 2 px menos), y el visor
// 2 px más. Se compensa con relleno, en píxeles ya físicos y solo cuando la
// escala de CabraPilot no es la de PixInsight (con factor 1 no se añade nada).
// El «3» es el relleno vertical de los campos en la hoja global.
function cpNativeFrameCss(control) {
   if (cpUiFactor(control) === 1)
      return "";
   var d = cpUiPx(1) - cpRoundEven(cpUiNativeScale());
   if (!(d > 0))
      return "";
   var pad = cpUiPx(3) + d;
   return "QLineEdit, QSpinBox, QDoubleSpinBox { padding-top:" + pad + "px; padding-bottom:" + pad + "px; }" +
          "QAbstractScrollArea { padding:" + d + "px; }";
}

// Botón primario: el ÚNICO relleno de oro de la ventana, con tinta oscura.
var CP_WIDTH_REPOSING = false;

// ---------------------------------------------------------------------------
// EL REGISTRO DE ANCHOS. Aplicar una hoja de estilo BORRA los suelos.
// ----------------------------------------------------------------------------
// MEDIDO el 7-ago-2026 (`_tests/cp_minwidth_probe*.js`), a raíz del único fallo
// de la batería de esa mañana: los tres botones de ANNOTATIONS salían del
// constructor con suelo 28 en vez de 59 / 56 / 140.
//
// `cpMinWidthToText` y `cpFitToText` NO fallan: instrumentando la llamada, miden
// bien y escriben bien. Lo que pasa es que el suelo se borra DESPUÉS, y lo borra
// esta misma función: al asignar una hoja de estilo, Qt vuelve a pulir el control
// y a sus descendientes, y recalcula el mínimo de cada `QPushButton` DESDE LA
// HOJA — donde pone `min-width:0px`, que es el arreglo del defecto 8. En
// `main_dialog.js` los paneles se construyen (696, 783) y los contenedores se
// estilizan después (768, 794), así que todo suelo puesto al construir se perdía.
//
// LOS TRES DATOS QUE LO DEJAN CERRADO, y que explican por qué era invisible:
//
//   · Solo le pasa a los BOTONES. Las casillas del mismo `fitLabels` conservan
//     el suyo, porque la hoja no tiene regla `min-width` para `QCheckBox`. Esa
//     asimetría es la que hacía el fallo incomprensible.
//   · De un `setFixedWidth` se lleva SOLO LA MITAD DE ABAJO: el tope sobrevive y
//     el suelo no. Por eso los 14 botones del histograma seguían sin descuadrar
//     la fila y nadie notó que se habían quedado sin protección.
//   · El panel de DBE se salvaba POR ORDEN, no por mérito: se construye en
//     diferido, después de estilizar. Su test en verde no probaba el mecanismo.
//
// EL ARREGLO VIVE AQUÍ A PROPÓSITO, en la misma función que causa el daño. Las
// alternativas se descartaron con números: volver a llamar a los ajustes al final
// del constructor arregla lo de hoy y se rompe con el siguiente restyle, en
// silencio; y poner el suelo en la hoja del propio control DUPLICA LA ESCALA
// (140 px pedidos → 238 leídos, porque `scaledStyleSheet` escala los px y
// `font.width` ya devuelve píxeles físicos) además de sustituirle la estética.
//
// Se guarda el NÚMERO, no se vuelve a medir el texto: reponer es escribir un
// entero, y solo si hace falta — comparar antes de escribir evita invalidar el
// layout en cada estilizado.
var CP_WIDTH_FLOORS = [];

// ==== from ui\theme.js (las hojas, de varias lineas)
var CP_PILL_1 = cpPillRadius(1) + "px";
var CP_PILL_2 = cpPillRadius(2) + "px";
var CP_PILL_4 = cpPillRadius(4) + "px";
var CP_CSS_GLOBAL =
   "* { font-family:" + CP_UI.fontFamily + "; font-size:10px; color:" + CP_UI.text + "; border-image:none; outline:none; }" +
   "QDialog, QWidget { background-color:" + CP_UI.bg + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.bg + "; }" +
   "QLabel { background-color:" + CP_UI.bg + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.bg + "; padding:0px; }" +
   "QLabel:disabled { color:" + CP_UI.textMute + "; }" +
   "QLineEdit, QSpinBox, QDoubleSpinBox { background-color:" + CP_UI.bgInset + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_UI.radius + "; padding:3px 7px; selection-background-color:" + CP_UI.primary + "; selection-color:" + CP_UI.ink + "; }" +
   "QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus { border:1px solid " + CP_UI.primaryRing + "; }" +
   // El desplegable: de «bloque ámbar» a filete, con el oro solo en el foco y
   // en la flecha (la flecha es una imagen nuestra: ver `cpAtlasRawCss`).
   "QComboBox { background-color:" + CP_UI.bgPanel + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_UI.radius + "; padding:1px 5px; selection-background-color:" + CP_UI.primary + "; selection-color:" + CP_UI.ink + "; min-height:16px; }" +
   "QComboBox:focus, QComboBox:hover { background-color:" + CP_UI.bgPanelAlt + "; border:1px solid " + CP_UI.primaryRing + "; }" +
   "QComboBox:disabled { color:" + CP_UI.textMute + "; }" +
   "QComboBox::drop-down { background-color:transparent; border:none; width:18px; }" +
   "QComboBox QAbstractItemView { background-color:" + CP_UI.bgPanel + " !important; color:" + CP_UI.text + " !important; selection-background-color:" + CP_UI.bgPanelAlt + " !important; selection-color:" + CP_UI.primaryLight + " !important; border:1px solid " + CP_UI.border + "; outline:0px; }" +
   "QComboBox QAbstractItemView::item { background-color:" + CP_UI.bgPanel + " !important; color:" + CP_UI.text + " !important; padding:4px; }" +
   "QComboBox QAbstractItemView::item:selected { background-color:" + CP_UI.bgPanelAlt + " !important; color:" + CP_UI.primaryLight + " !important; }" +
   // `min-width:0px` NO ES DECORACION. MEDIDO el 6-ago-2026: sin el, un
   // `PushButton` de PixInsight conserva el minimo por defecto de Qt (**128 px**)
   // y ese minimo **gana a `setFixedWidth`** — se le pide 48 px y se queda en 128,
   // sin lanzar y sin avisar. Es lo que dejaba las filas del panel del histograma
   // pidiendo 565 px en una columna de 330, con los rotulos cortados a dos letras
   // (defecto 8). Los botones de toggle ya lo llevaban en su propio CSS, y por eso
   // ESOS si encogian: el sintoma era que unos obedecian y otros no.
   "QPushButton { background-color:" + CP_UI.bgPanel + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_PILL_3 + "; padding:3px 9px; min-width:0px; background-image:none; }" +
   "QPushButton:hover { background-color:" + CP_UI.bgPanelAlt + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.primaryRing + "; background-image:none; }" +
   "QPushButton:pressed { background-color:" + CP_UI.bgInset + "; color:" + CP_UI.primaryLight + "; border:1px solid " + CP_UI.primary + "; background-image:none; }" +
   "QPushButton:disabled { background-color:" + CP_UI.bg + "; color:" + CP_UI.textMute + "; border:1px solid " + CP_UI.border + "; background-image:none; }" +
   "QScrollBar:vertical { background-color:" + CP_UI.bg + "; width:10px; margin:0; }" +
   "QScrollBar::handle:vertical { background:" + CP_UI.border + "; border-radius:5px; min-height:20px; }" +
   "QScrollBar::handle:vertical:hover { background:" + CP_UI.borderStrong + "; }" +
   "QScrollBar:horizontal { background-color:" + CP_UI.bg + "; height:10px; margin:0; }" +
   "QScrollBar::handle:horizontal { background:" + CP_UI.border + "; border-radius:5px; min-width:20px; }" +
   "QScrollBar::handle:horizontal:hover { background:" + CP_UI.borderStrong + "; }" +
   "QScrollBar::add-line, QScrollBar::sub-line { height:0; width:0; }" +
   "QScrollBar::add-page, QScrollBar::sub-page { background-color:" + CP_UI.bg + "; }" +
   "QToolTip { background:" + CP_UI.bgPanel + "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.borderStrong + "; padding:5px 8px; border-radius:5px; }" +
   // Árboles: la columna de indicadores de rama la pinta Qt con la paleta por
   // defecto (se veía como una franja blanca); hay que forzarla transparente.
   "QTreeView, QTreeWidget { background-color:" + CP_UI.bgInset + "; alternate-background-color:" + CP_UI.bgInset +
   "; color:" + CP_UI.text + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_UI.radius + "; outline:0; }" +
   "QTreeView::item { padding:2px 3px; color:" + CP_UI.text + "; background-color:transparent; border:none; }" +
   "QTreeView::item:hover { background-color:" + CP_UI.bgPanel + "; }" +
   "QTreeView::item:selected { background-color:" + CP_UI.primaryBg + "; color:" + CP_UI.primaryLight + "; }" +
   "QTreeView::branch { background-color:transparent; border:none; }" +
   "QTreeView::branch:hover { background-color:" + CP_UI.bgPanel + "; }" +
   "QTreeView::branch:selected { background-color:" + CP_UI.primaryBg + "; }" +
   "QHeaderView::section { background-color:" + CP_UI.bgPanel + "; color:" + CP_UI.textDim + "; border:none; padding:2px 4px; }" +
   // Sliders (NumericControl): el estilo nativo desentona con el tema oscuro.
   "QSlider::groove:horizontal { background:" + CP_UI.border + "; border:1px solid " + CP_UI.border + "; height:4px; border-radius:2px; }" +
   "QSlider::sub-page:horizontal { background:" + CP_UI.primary + "; border:1px solid " + CP_UI.primary + "; height:4px; border-radius:2px; }" +
   "QSlider::handle:horizontal { background:" + CP_UI.primaryLight + "; border:1px solid " + CP_UI.bg + "; width:10px; margin:-5px 0; border-radius:5px; }" +
   "QSlider::handle:horizontal:hover { background:" + CP_UI.text + "; }" +
   "QSlider::handle:horizontal:disabled { background:" + CP_UI.border + "; }" +
   // La casilla: aquí solo el texto. La caja es una imagen nuestra y sus reglas
   // van aparte, sin escalar (ver `cpAtlasRawCss` en ui/atlas.js).
   "QCheckBox { background-color:transparent; color:" + CP_UI.text + "; border:none; spacing:6px; }" +
   "QCheckBox:disabled { color:" + CP_UI.textMute + "; }" +
   "QTabWidget::pane { background-color:" + CP_UI.bgPanel + "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_UI.radius + "; }" +
   "QTabBar { background-color:transparent; }" +
   "QTabBar::tab { background-color:" + CP_UI.bgInset + "; color:" + CP_UI.textMuted + "; border:1px solid " + CP_UI.border + "; border-bottom:none; border-top-left-radius:" + CP_UI.radius + "; border-top-right-radius:" + CP_UI.radius + "; padding:5px 14px; margin-right:2px; }" +
   "QTabBar::tab:selected { background-color:" + CP_UI.bgPanelAlt + "; color:" + CP_UI.primaryLight + "; border:1px solid " + CP_UI.primaryRing + "; border-bottom:none; font-weight:700; }" +
   "QTabBar::tab:hover { color:" + CP_UI.text + "; }" +
   "QFrame, QPushButton, QGroupBox, QLabel, QWidget { background-image:none; }";
var CP_CSS_PRIMARY =
   "QPushButton { background-color:" + CP_UI.primary + "; color:" + CP_UI.ink + "; border:1px solid " + CP_UI.primary + "; border-radius:" + CP_PILL_4 + "; padding:4px 10px; min-width:0px; font-weight:600; background-image:none; }" +
   "QPushButton:hover { background-color:" + CP_UI.primaryHover + "; color:" + CP_UI.ink + "; border:1px solid " + CP_UI.primaryHover + "; background-image:none; }" +
   "QPushButton:pressed { background-color:" + CP_UI.text + "; color:" + CP_UI.ink + "; border:1px solid " + CP_UI.text + "; background-image:none; }" +
   "QPushButton:disabled { background-color:" + CP_UI.bg + "; color:" + CP_UI.textMute + "; border:1px solid " + CP_UI.border + "; background-image:none; }";
var CP_CSS_TOGGLE_ON =
   "QPushButton { background-color:" + CP_UI.bgPanelAlt + "; color:" + CP_UI.primaryLight +
   "; border:1px solid " + CP_UI.primary + "; border-radius:" + CP_PILL_1 +
   "; padding:1px 4px; margin:0px; min-width:0px; font-size:10px; font-weight:700" +
   "; background-image:none; }" +
   "QPushButton:hover { color:" + CP_UI.text + "; border:1px solid " + CP_UI.primaryLight + "; }";
var CP_CSS_TOGGLE_OFF =
   "QPushButton { background-color:" + CP_UI.bgInset + "; color:" + CP_UI.textMuted +
   "; border:1px solid " + CP_UI.border + "; border-radius:" + CP_PILL_1 +
   "; padding:1px 4px; margin:0px; min-width:0px; font-size:10px; font-weight:500" +
   "; background-image:none; }" +
   "QPushButton:hover { color:" + CP_UI.text + "; border:1px solid " + CP_UI.primaryRing + "; }";
