// ============================================================================
// host/host.js — EL ANFITRION: lo que en CabraPilot ponia el programa entero y
// aqui pone Cabra3D, mas sencillo (14-oct-2026)
// ----------------------------------------------------------------------------
// Los modulos de starfield copiados de CabraPilot (src/engine, src/ui) llaman a un
// puñado de funciones del resto de CabraPilot. Lo que se pudo copiar tal cual esta
// en host/host_copied.js; aqui van las que alli arrastraban medio programa, con la
// MISMA firma y una version minima (anotado en cada una que hacia alli y que hace
// aqui). Cabra3D no depende de CabraPilot en tiempo de ejecucion.
// ES5.
// ============================================================================

// --- constantes del programa -------------------------------------------------
var CP_SETTINGS_PREFIX = "Cabra3D";
var CP_GLOBAL = (typeof globalSelf !== "undefined") ? globalSelf : ((typeof globalThis !== "undefined") ? globalThis : this);
var OPT_MOUSE_LEFT  = (typeof MouseButton_Left  !== "undefined") ? MouseButton_Left  : 0x01;
var OPT_MOUSE_RIGHT = (typeof MouseButton_Right !== "undefined") ? MouseButton_Right : 0x02;
// (V8: Image.free / Bitmap.clear existen por instancia; la red de CabraPilot, por si no)
if (typeof Image.prototype.free === "undefined") Image.prototype.free = function() {};
if (typeof Bitmap.prototype.clear === "undefined") Bitmap.prototype.clear = function() {};

// processEvents portable (CabraPilot.js)
function optProcessEvents() {
   if (typeof CSH_PAINTING === "number" && CSH_PAINTING > 0) return;      // (26-oct-2026: nunca con un pintado abierto; CabraShared/csh_net.js, CSH_PAINTING)
   try { if (typeof CoreApplication !== "undefined" && typeof CoreApplication["processEvents"] === "function") { CoreApplication["processEvents"](); return; } } catch (e0) {}
   try { if (typeof processEvents === "function") { processEvents(); return; } } catch (e1) {}
}

// --- el idioma (CabraPilot.js / CabraPilot_resources.jsh, mismo mecanismo) ---
var CP_LANG = "en";
var CP_LANGUAGES = [
   { code: "en", tooltips: C3_TOOLTIPS_EN, strings: null },
   { code: "es", tooltips: C3_TOOLTIPS_ES, strings: C3_I18N_ES }
];
function cpLangEntry() {
   for (var i = 0; i < CP_LANGUAGES.length; ++i) if (CP_LANGUAGES[i].code === CP_LANG) return CP_LANGUAGES[i];
   return CP_LANGUAGES[0];
}
function cpLoadLang() {
   try {
      var v = Settings.read(CP_SETTINGS_PREFIX + "/lang", DataType_String);
      for (var i = 0; i < CP_LANGUAGES.length; ++i) if (CP_LANGUAGES[i].code === v) { CP_LANG = v; break; }
   } catch (e) {}
}
function cpSaveLang() { if (CP_NO_MAIN) return; try { Settings.write(CP_SETTINGS_PREFIX + "/lang", DataType_String, CP_LANG); } catch (e) {} }
function optT(s) {
   try {
      var L = cpLangEntry();
      if (L && L.strings && Object.prototype.hasOwnProperty.call(L.strings, s) && L.strings[s]) return L.strings[s];
   } catch (e) {}
   return s;
}
function cpTooltipText(key) {
   var L = cpLangEntry();
   if (L.tooltips && Object.prototype.hasOwnProperty.call(L.tooltips, key) && L.tooltips[key]) return L.tooltips[key];
   if (Object.prototype.hasOwnProperty.call(C3_TOOLTIPS_EN, key)) return C3_TOOLTIPS_EN[key];
   return "";
}

// --- la «zona tranquila» y el trabajo de fondo (engine/inherited.js) ---------
// Alli protegian de ejecutar procesos mientras otro dialogo de CabraPilot medía; aqui
// no hay nada que proteger: Cabra3D no aplica procesos a la imagen del usuario.
function cpQuiet() { return false; }
// UN PROCESO EN MARCHA (20-oct-2026, fallo de Nino: «Access violation … QRasterPaintEngine::drawImage» al repintarse una cabecera
// de grupo dentro del bucle de eventos de HistogramTransformation). Todo proceso que Cabra3D lanza con el dialogo en pantalla
// pasa por `c3ProcRun`: mientras corre, `c3ProcBusy()` es verdadero y las cabeceras de grupo no pintan (ui/groups.js). Al terminar
// se repintan una vez. No es `cpQuiet()` a proposito: ese afecta tambien al lienzo 3D y a los temporizadores, que no necesitan
// callar (y un lienzo que se salta un pintado queda en blanco hasta el siguiente).
var C3_PROC_DEPTH = 0;
function c3ProcBusy() { return C3_PROC_DEPTH > 0; }
function c3ProcRun(fn) {
   ++C3_PROC_DEPTH;
   try { return fn(); }
   finally {
      --C3_PROC_DEPTH;
      if (C3_PROC_DEPTH === 0) { try { if (typeof c3GroupsRepaintAll === "function") c3GroupsRepaintAll(); } catch (eR) {} }
   }
}
function cpBackgroundRun(fn) { return fn(); }

// --- la identidad del contenido de una imagen (engine/image_manager.js) ------
// Alli llevaba el historial de CabraPilot; aqui, el del propio PixInsight.
var CP_CONTENT_EPOCH = 0;
function cpHistoryIndex(view) { try { return view.historyIndex; } catch (e) { return 0; } }
function cpViewContentToken(viewId) { return 0; }

// ¿LINEAL? (engine/image_manager.js: alli, override manual + historial + tres señales). Aqui: la propiedad del nucleo si
// la hay, y si no las MISMAS tres señales con los MISMOS umbrales (mediana < 0,10, MAD < 0,008, MTF necesaria < 0,15).
// La funcion de transferencia de medios tonos (la de HistogramTransformation) y su inversa para el AutoSTF.
// (cpViewIsLinear y cpHasAstrometricSolution: comunes, ../CabraShared/csh_astrometry.js)
function c3Mtf(m, x) {
   if (x <= 0) return 0; if (x >= 1) return 1; if (m === x) return 0.5;
   return (m - 1) * x / ((2 * m - 1) * x - m);
}

// ¿BANDA ESTRECHA? (engine/color.js: alli lo elegido en COLOR, el historial o el nombre). Aqui: el nombre de la vista y las
// palabras clave FILTER, con las mismas pistas (Ha, OIII, SII, HOO, SHO, palette). Devuelve { mode, palette }.
function cpColorModeResolve(view) {
   var txt = "";
   try { txt += " " + String(view.id); } catch (e0) {}
   try { var kw = view.window.keywords; for (var i = 0; i < kw.length; ++i) if (/^FILTER/i.test(kw[i].name)) txt += " " + String(kw[i].strippedValue || kw[i].value); } catch (e1) {}
   var s = txt.toUpperCase(), pal = "";
   if (/\bSHO\b/.test(s)) pal = "SHO"; else if (/\bHOO\b/.test(s)) pal = "HOO"; else if (/\bHSO\b/.test(s)) pal = "HSO";
   else if (/(H[-_ ]?A(LPHA)?\b|\bOIII\b|\bO3\b|\bSII\b|\bS2\b)/.test(s) && /(OIII|O3|SII|S2)/.test(s)) pal = "NB";
   return { mode: pal.length ? "nb-rgb" : "bb-rgb", palette: pal };
}

// --- ¿RESUELTA? (engine/astrometry.js, copiada tal cual) ---------------------

// --- LA RED sin curl (engine/survey.js: alli con prefetch y registro de fallos) -
function cpSurveyNetLogTally(launched, good) {}
function cpSurveyNetLogRecord(ev) {}
function cpSurveyHttpGet(url, timeoutSeconds) {
   var out = { ok: false, data: null, bytes: 0, code: -1, message: "" }, buffer = new ByteArray, T = null;
   try {
      T = new NetworkTransfer;
      T.setURL(url);
      T.setConnectionTimeout(timeoutSeconds || 30);
      T.onDownloadDataAvailable = function(data) { buffer.add(data); return true; };
      var ok = T.download();
      out.bytes = buffer.length;
      try { if (typeof T.responseCode === "number") out.code = T.responseCode; } catch (eRC) {}
      if (!ok) out.message = "the download failed";
      else if (buffer.length === 0) out.message = "the service returned 0 bytes";
      else { out.ok = true; out.data = buffer; }
   } catch (e) { out.message = "network exception: " + (e.message || e); }
   finally { try { if (T) T.closeConnection(); } catch (eC) {} }
   return out;
}

// --- PINTAR UNA IMAGEN (engine/inherited.js: alli con Auto GHS, STF propio por imagen, mascaras…) ----------------------
var OPT_RENDER_MAX_REDUCTION = 64;
function optRenderDirect(image, reduction, opaque) {
   var n = Math.max(1, Math.min(OPT_RENDER_MAX_REDUCTION, Math.floor(reduction)));
   return image.render(n > 1 ? -n : 1, opaque !== true, false);
}
// `stretchMode`: "none" (tal cual), "mad-linked" | "mad-unlinked" (el AutoSTF de PixInsight: sombras a −2,8 MAD, fondo
// al C3_STF_BKG). Una imagen LINEAL se pinta estirada (si no, es negra); una ya estirada, tal cual. El estirado se hace con el
// proceso HistogramTransformation sobre una ventana temporal (nativo y rapido) y la ventana se cierra.
function optRenderPreviewBitmap(view, reductionFactor, stretchMode) {
   if (!optSafeView(view) || !view.image) return null;
   var n = Math.max(1, Math.min(OPT_RENDER_MAX_REDUCTION, Math.floor(reductionFactor || 1)));
   // (30-oct-2026) si la vista tiene STF en PixInsight, ESE (cshViewStf): la foto sale con los colores del Workspace
   if (typeof cshViewStf === "function" && cshViewStf(view, view.image.numberOfChannels)) return c3ProcRun(function() { return optRenderStretched(view, n, "view"); });
   if (stretchMode !== "mad-linked" && stretchMode !== "mad-unlinked") return optRenderDirect(view.image, n);
   return c3ProcRun(function() { return optRenderStretched(view, n, stretchMode); });
}
function optRenderStretched(view, n, stretchMode) {
   var img = view.image, nc = img.numberOfChannels, win = null;
   try {
      win = new ImageWindow(1, 1, nc, 32, true, nc >= 3, optUniqueId("c3_render_tmp"));
      var v = win.mainView;
      v.beginProcess(UndoFlag_NoSwapFile);
      try { v.image.assign(img); } finally { v.endProcess(); }
      var vs = (stretchMode === "view") ? cshViewStf(view, nc) : null, H = new HistogramTransformation;
      var stf = vs ? null : c3AutoStf(img, stretchMode === "mad-linked");
      var rows = [[0, 0.5, 1, 0, 1], [0, 0.5, 1, 0, 1], [0, 0.5, 1, 0, 1], [0, 0.5, 1, 0, 1], [0, 0.5, 1, 0, 1]];
      if (vs) { if (nc >= 3) { for (var cv = 0; cv < 3; ++cv) rows[cv] = [vs[cv].c0, vs[cv].m, vs[cv].c1, vs[cv].r0, vs[cv].r1]; } else rows[3] = [vs[0].c0, vs[0].m, vs[0].c1, vs[0].r0, vs[0].r1]; }
      else if (nc >= 3) { for (var c = 0; c < 3; ++c) rows[c] = [stf[c].c0, stf[c].m, 1, 0, 1]; }
      else rows[3] = [stf[0].c0, stf[0].m, 1, 0, 1];
      H.H = rows;
      H.executeOn(v, false);
      return optRenderDirect(v.image, n);
   } catch (e) {
      try { console.warningln("Cabra3D: render — " + (e.message || e)); } catch (eW) {}
      return optRenderDirect(view.image, n);
   } finally {
      try { if (win) win.forceClose(); } catch (eC) {}
   }
}
// El AutoSTF de PixInsight por canal: [{ c0, m }]. Enlazado: la media de los canales.
// Fondo del cielo al pintar la foto (Nino, 20-oct: con el 0,25 del AutoSTF la foto salia lavada; pidio 10-15 %)
var C3_STF_BKG = CSH_STF_BKG;      // (31-oct-2026) el comun
function c3AutoStf(img, linked) {
   var out = [], nc = Math.min(3, img.numberOfChannels), c;
   for (c = 0; c < nc; ++c) {
      img.selectedChannel = c;
      var med = img.median(), mad = img.MAD() * 1.4826;
      var c0 = (med > 0.5) ? 0 : Math.max(0, Math.min(1, med - 2.8 * mad));
      out.push({ c0: c0, m: c3Mtf(C3_STF_BKG, med - c0), med: med, mad: mad });
   }
   img.resetSelections();
   if (linked && nc > 1) {
      var a = 0, b = 0;
      for (c = 0; c < nc; ++c) { a += out[c].med; b += out[c].mad; }
      a /= nc; b /= nc;
      var lc0 = Math.max(0, a - 2.8 * b), lm = c3Mtf(C3_STF_BKG, a - lc0);
      for (c = 0; c < nc; ++c) { out[c].c0 = lc0; out[c].m = lm; }
   }
   return out;
}

// --- QUITAR ESTRELLAS (engine/starless.js: alli una tabla de motores con todos sus parametros) -----------------------
// Lo unico que usa la capa de nebulosas: StarXTerminator o StarNet2, sin imagen de estrellas.
var CP_STAR_IMAGE_NONE = 0, CP_STAR_IMAGE_SUBTRACT = 1, CP_STAR_IMAGE_UNSCREEN = 2;
function cpStarAvailableEngines() {
   var out = [];
   if (cpProcessAvailable("StarXTerminator")) out.push({ id: "SXT", process: "StarXTerminator", label: "StarXTerminator" });
   if (cpProcessAvailable("StarNet2")) out.push({ id: "SN2", process: "StarNet2", label: "StarNet2" });
   return out;
}
function cpStarDefaults(engine) { return { starsImage: CP_STAR_IMAGE_NONE, linear: 0 }; }
function c3SetParam(P, names, value) {
   for (var i = 0; i < names.length; ++i) { try { if (names[i] in P) { P[names[i]] = value; return true; } } catch (e) {} }
   return false;
}
function cpStarRunOnView(engineId, values, view) {
   var v = values || {}, P = null;
   try {
      if (engineId === "SXT") { P = new StarXTerminator; c3SetParam(P, ["stars", "output_stars"], false); c3SetParam(P, ["unscreen", "unscreen_stars"], false); }
      else if (engineId === "SN2") { P = new StarNet2; c3SetParam(P, ["mask"], false); c3SetParam(P, ["unscreen"], false); if (v.linear === 2) c3SetParam(P, ["linear"], false); }
      else return { ok: false, message: "unknown star removal engine: " + engineId };
      var ok = c3ProcRun(function() { return P.executeOn(view); });
      return { ok: ok !== false, message: (ok === false) ? engineId + " did not finish" : "" };
   } catch (e) { return { ok: false, message: String(e.message || e) }; }
}

// Los datos PROPIOS de Cabra3D (constelaciones, curva de extincion): src/data/. Los del motor comun (cumulos, secuencia
// principal, nebulosas, Babusiaux 2018) estan en ../CabraShared/data/ (cpSfDataDir).
var C3_FILE = #__FILE__;
function c3DataDir() {
   var here = (File.extractDrive(C3_FILE) + File.extractDirectory(C3_FILE)).split("\\").join("/");
   return here.substring(0, here.lastIndexOf("/")) + "/data/";
}
