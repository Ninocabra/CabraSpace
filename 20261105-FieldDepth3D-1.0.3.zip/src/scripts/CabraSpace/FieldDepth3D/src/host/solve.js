// ============================================================================
// host/solve.js — RESOLVER LA IMAGEN SOLO SI HACE FALTA (14-oct-2026)
// ----------------------------------------------------------------------------
// PROCEDENCIA: CabraPilot integracion-1410c, engine/astrometry.js —
// `cpSolveAstrometry`, `cpPrepareWindowForSolver`, `cpDropStaleAstrometry`,
// `cpKillSolverDiagnostics`— y engine/crop.js (`CP_CROP_WCS_STALE`), adaptados.
// Peticion de Nino: «si la imagen se puede resolver (WCS ya presente) NO se llama a
// ImageSolver; si no, se resuelve». `c3EnsureSolved( view )` hace eso y dice que ha
// hecho: { ok, state ("already" | "solved" | "failed" | "cancelled"), why, ms }.
// La libreria ImageSolver se incluye en Cabra3D.js (modo libreria, como CabraPilot).
// COSTURA DE PRUEBAS: `C3_SOLVE_HOOK( window ) -> { ok, why }` contesta EN VEZ de
// ImageSolver (y cuenta las llamadas: el test «una imagen resuelta NO llama a
// ImageSolver» mira `C3_SOLVE_CALLS`). `C3_SOLVE_DIALOG = false` no abre el dialogo
// de ImageSolver si el intento automatico falla (una pasada sin pantalla se colgaria).
// ES5.
// ============================================================================

var C3_SOLVE_HOOK = null;
var C3_SOLVE_CALLS = 0;
var C3_SOLVE_DIALOG = true;
var C3_WCS_STALE = ["PCL:AstrometricSolution:Information", "PCL:AstrometricSolution:SplineWorldTransformation"];

function c3ImageSolverAvailable() { return cshImageSolverAvailable(); }
function c3KillSolverDiagnostics() { cshKillSolverDiagnostics(); }
// (la receta es la comun, ../CabraShared/csh_astrometry.js; aqui se le pasan las costuras de Cabra3D)
function c3EnsureSolved(view) {
   var before = CSH_SOLVE_CALLS;
   CSH_SOLVE_HOOK = C3_SOLVE_HOOK;
   var r;
   try { r = cshEnsureSolved(view, { dialog: C3_SOLVE_DIALOG === true }); }
   finally { CSH_SOLVE_HOOK = null; }
   C3_SOLVE_CALLS += CSH_SOLVE_CALLS - before;
   return r;
}

// ¿COLOR, Y CALIBRADO? (consejo, no bloqueo: Nino admite blanco y negro). Mira el historial de la imagen buscando una
// calibracion de color (la lista de CabraPilot, engine/image_manager.js: SPCC, PCC, ColorCalibration).
// Devuelve { mono, calibrated, how }.
function c3ColorStatus(view) { return cshColorStatus(view); }   // (comun: csh_astrometry.js)
