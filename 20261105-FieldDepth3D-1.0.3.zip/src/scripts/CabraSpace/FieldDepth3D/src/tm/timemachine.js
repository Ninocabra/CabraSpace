// ============================================================================
// tm/timemachine.js — LA MAQUINA DEL TIEMPO: la fisica, PURA (Cabra3D, 14-oct-2026)
// ----------------------------------------------------------------------------
// Capacidad nueva de Cabra3D (no viene de CabraPilot). Dada una estrella con su
// posicion (Gaia DR3, J2016,0), su distancia, su movimiento propio y —si Gaia la
// tiene— su velocidad radial, dice DONDE ESTARA (o estuvo) dentro de T años, vista
// desde el Sol: ascension recta, declinacion y distancia. Node lo ejecuta entero
// (`tests/c3_tm_cases.js`): aqui no hay nada de PixInsight.
//
// DOS MODELOS (la fisica y sus limites, en `docs/maquina_del_tiempo.md`):
//   · "linear"   movimiento RECTILINEO Y UNIFORME en 3D, relativo al Sol (el de los
//                catalogos: ESA 1997, vol. 1, §1.5.5; es lo que hace la propagacion
//                de epocas de Gaia). Incluye la ACELERACION DE PERSPECTIVA (una
//                estrella que se acerca «acelera» en el cielo) porque se propaga el
//                vector, no los angulos. Vale mientras la gravedad de la Galaxia no
//                curve las trayectorias: a ~1 Myr el error ya es del orden del 1 % del
//                desplazamiento (el tiron vertical del disco, ν² Δz t² / 2).
//   · "galactic" las ECUACIONES DE HILL (epiciclos) en el plano y la oscilacion
//                vertical del disco, para el movimiento RELATIVO al Sol (lineales: la
//                diferencia de dos soluciones es solucion). Constantes de Oort MEDIDAS
//                (media de cinco medidas con Gaia) y densidad total local de McKee et al.
//                2015 (K1, 23-oct-2026; docs/maquina_del_tiempo.md §4b). Vale mientras la
//                separacion sea pequeña frente a R0 (8 kpc) y no haya encuentros:
//                decenas de Myr como mucho; mas alla, nada lineal vale (brazos,
//                nubes moleculares, dispersion).
// Las posiciones salen SIEMPRE en el marco ICRS (el de la foto), vistas desde el Sol.
//
// EL MARCO DEL SOL. Gaia da los movimientos RELATIVOS AL SOL: el movimiento del Sol
// ya va dentro (por eso las estrellas «huyen» del apex). La opcion `lsr` le suma a
// cada estrella el movimiento peculiar del Sol (Schönrich, Binney y Dehnen 2010):
// se ve el campo desde un punto que se mueve con el Estandar Local de Reposo, sin el
// reflejo del movimiento solar.
//
// UNIDADES: parsecs, años julianos, km/s, mas y mas/año. ES5 puro.
// ============================================================================

var C3_TM = {
   // --- unidades (exactas o IAU) ----------------------------------------------
   // 1 km/s en pc/año: 31 557 600 s / 3,0856775814913673e13 km
   KMS_PCYR: 31557600 / 3.0856775814913673e13,
   // km/s por (mas/año · kpc) = 1 UA por año en km/s: 149 597 870,7 / 31 557 600
   K_PM: 149597870.7 / 31557600,
   DEG: Math.PI / 180,
   MAS: Math.PI / 180 / 3600000,
   // --- la Galaxia ------------------------------------------------------------
   // (K1 de Nino, 23-oct-2026, noche: «los valores más cercanos a la realidad». Los EPICICLOS usan constantes MEDIDAS, no las del
   // potencial. Tabla de medidas, fuentes y elección en docs/maquina_del_tiempo.md §4b.)
   // Constantes de Oort: MEDIA SIN PESOS de cinco medidas de la era Gaia en ≲ 1 kpc —Bovy 2017 (DR1, MNRAS 468, L63) 15,3 / −11,9;
   // Li, Zhao y Yang 2019 (DR2, ApJ 872, 205) 15,1 / −13,4; Wang F. et al. 2021 (LAMOST A + Gaia, MNRAS, doi:10.1093/mnras/stab848) 16,31 / −11,99;
   // Nelson y Widrow 2022 (DR2, MNRAS, doi:10.1093/mnras/stac2594; media en 500 pc) 15,2 / −12,4; Akhmetov et al. 2024 (DR3, MNRAS,
   // doi:10.1093/mnras/stae772; esfera de 1 kpc) 14,79 / −13,73—:
   // A = 15,3 ± 0,6, B = −12,7 ± 0,8 km/s/kpc (± = la dispersión entre ellas: sus errores formales, 0,1–0,9, son menores que lo que
   // discrepan; manda la sistemática —muestra, volumen, disco no axisimétrico—, no el ruido)
   OORT_A: 15.3, OORT_B: -12.7,
   // Densidad TOTAL local (estrellas + gas + materia oscura): McKee, Parravano y Hollenbach 2015 (ApJ 814, 13), 0,097 ± 0,013 Msun/pc³.
   // (Hasta el 23-oct ponía 0,084 «total»: es su parte BARIÓNICA —0,097 − 0,013 de materia oscura—, no la total.)
   RHO0: 0.097,
   G_PC3_MSUN_YR2: 4.498502151469554e-15,     // G en pc³ / (Msun · año²)
   // Movimiento peculiar del Sol respecto al LSR (Schönrich, Binney y Dehnen 2010, MNRAS 403, 1829), km/s: U (hacia el
   // centro galactico), V (sentido de la rotacion), W (polo norte galactico)
   SUN_UVW: [11.1, 12.24, 7.25],
   // --- los limites honestos (diseño: ver docs/maquina_del_tiempo.md) ---------
   // MEDIDO (tests/c3_tm_cases.js, 4.3; estrella a 500 pc, 30 km/s): la recta se separa de los epiciclos un 0,1 % del
   // desplazamiento a 0,1 Myr, un 1 % a 1 Myr y un 12 % a 10 Myr (la diferencia crece como t²: la marea de la Galaxia; con las constantes medidas del K1, 0,11 / 1,2 / 14 %)
   LINEAR_OK_YR: 1e5,      // hasta aqui la recta y la orbita difieren < 0,1 % del desplazamiento
   LINEAR_WARN_YR: 1e6,    // a partir de aqui la recta se equivoca en ~1 % del desplazamiento: se avisa
   GALACTIC_WARN_YR: 1e8,  // las orbitas integradas (A7): hasta aqui, sin aviso
   GALACTIC_MAX_YR: 5e8,   // y mas alla ni ellas (la barra, los brazos espirales, las nubes y los encuentros no estan en el potencial)
   CLUSTER_RV_MIN: 3,      // miembros con velocidad radial de Gaia para dar la del cumulo a los que no la tienen
   // Un MIEMBRO de cumulo cuya RV de Gaia tiene un error mayor que esto lleva la del cumulo (MEDIDO en las Pleyades, 15-oct:
   // con las RV individuales —errores de 1 a 10 km/s a G 12–15— el cumulo «se dispersaba» a 86 pc de radio en 10 Myr, el
   // ruido de la medida y no el cumulo: su dispersion interna real es ~0,5–0,8 km/s)
   MEMBER_RV_ERR: 1.0
};

// La matriz ICRS -> galacticas (Hipparcos, ESA 1997, vol. 1, ec. 1.5.11): r_gal = A · r_icrs.
// X hacia el centro galactico, Y en el sentido de la rotacion (l = 90°), Z al polo norte galactico.
var C3_TM_AG = [
   [-0.0548755604162154, -0.8734370902348850, -0.4838350155487132],
   [ 0.4941094278755837, -0.4448296299600112,  0.7469822444972189],
   [-0.8676661490190047, -0.1980763734312015,  0.4559837761750669]
];

function c3TmMul(M, v) { return [M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2], M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2], M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2]]; }
function c3TmMulT(M, v) { return [M[0][0] * v[0] + M[1][0] * v[1] + M[2][0] * v[2], M[0][1] * v[0] + M[1][1] * v[1] + M[2][1] * v[2], M[0][2] * v[0] + M[1][2] * v[1] + M[2][2] * v[2]]; }

// Las frecuencias del modelo galactico, en 1/año: { omega, A, B, kappa, nu, from }, de A, B (km/s/kpc) y ρ0 (M⊙/pc³):
//   Ω = A − B,  κ² = 4 Ω (Ω − A) = −4 B Ω,  ν² = ∂²Φ/∂z² en el plano = 4πGρ0 + 2 (A² − B²)
// (la última es la ecuación de Poisson de un disco axisimétrico en el plano: el término 2 (A² − B²) = −(1/R) d(vc²)/dR es el de la curva de
// rotación. MEDIDO en MilkyWayPotential2022 —docs §4b—: ∂²Φ/∂z² numérico = 7 132,6 (km/s/kpc)², 4πGρ(z = 0) + 2(A² − B²) = 7 132,6. Con
// las medidas sube ν² un 2,7 %: el periodo vertical, de 84,9 a 83,7 Myr.)
function c3TmFreqOf(Akpc, Bkpc, rho0, from) {
   var k = C3_TM.KMS_PCYR / 1000, A = Akpc * k, B = Bkpc * k, om = A - B;   // km/s/kpc -> 1/año
   return { omega: om, A: A, B: B, kappa: Math.sqrt(4 * om * (om - A)), nu: Math.sqrt(4 * Math.PI * C3_TM.G_PC3_MSUN_YR2 * rho0 + 2 * (A * A - B * B)), from: from };
}
// LOS EPICICLOS DE LA MÁQUINA DEL TIEMPO: SIEMPRE las constantes MEDIDAS (C3_TM.OORT_A, OORT_B, RHO0; K1 de Nino, 23-oct, noche).
// (Del 23-oct por la tarde al K1 salían del potencial si csh_galdyn.js estaba cargado —G1, «un solo potencial»—: A 14,73, B −13,52,
// ρ0 0,129. Las órbitas integradas —tm/galaxy.js— siguen en el potencial, y a 1 Myr ya no casan con los epiciclos al 5,7 % sino al
// ~23 % (tests/c3_tm_cases.js 8.6): la diferencia es REAL, la de las constantes medidas frente a las de ese potencial.)
var C3_TM_FREQ = null, C3_TM_FREQ_KEY = "";
function c3TmGalFreq() {
   var key = C3_TM.OORT_A + "|" + C3_TM.OORT_B + "|" + C3_TM.RHO0;
   if (C3_TM_FREQ && C3_TM_FREQ_KEY === key) return C3_TM_FREQ;
   C3_TM_FREQ = c3TmFreqOf(C3_TM.OORT_A, C3_TM.OORT_B, C3_TM.RHO0, "measured");
   C3_TM_FREQ_KEY = key;
   return C3_TM_FREQ;
}
// Las MISMAS frecuencias, pero las del potencial que integra las órbitas (CabraShared/csh_galdyn.js, en el Sol: R0, z⊙): para comparar
// los epiciclos con las órbitas a igualdad de constantes (tests/c3_tm_cases.js 8.5). null sin csh_galdyn.js. No la usa la interfaz.
function c3TmGalFreqPotential() {
   if (typeof cshGdVcirc !== "function" || typeof CSH_GD === "undefined") return null;
   var R = CSH_GD.R0_KPC, h = 0.01, v = cshGdVcirc(R), dv = (cshGdVcirc(R + h) - cshGdVcirc(R - h)) / (2 * h);
   return c3TmFreqOf(0.5 * (v / R - dv), -0.5 * (v / R + dv), cshGdDensity(R, CSH_GD.ZSUN_KPC) / 1e9, "potential");   // (M⊙/kpc³ -> M⊙/pc³)
}

// EL ESTADO 3D de una estrella: posicion (pc) y velocidad (pc/año) en ICRS, con el Sol en el origen.
//   ra, dec (grados), d (pc), pmRa (mas/año, YA multiplicado por cos dec: el «pmra» de Gaia), pmDec (mas/año), rv (km/s)
function c3TmState(ra, dec, d, pmRa, pmDec, rv) {
   var a = ra * C3_TM.DEG, b = dec * C3_TM.DEG, ca = Math.cos(a), sa = Math.sin(a), cb = Math.cos(b), sb = Math.sin(b);
   var r = [cb * ca, cb * sa, sb], p = [-sa, ca, 0], q = [-sb * ca, -sb * sa, cb];
   var vt = C3_TM.K_PM * d / 1000, va = (pmRa || 0) * vt, vd = (pmDec || 0) * vt, vr = rv || 0, k = C3_TM.KMS_PCYR;
   return { x: d * r[0], y: d * r[1], z: d * r[2],
            vx: (va * p[0] + vd * q[0] + vr * r[0]) * k, vy: (va * p[1] + vd * q[1] + vr * r[1]) * k, vz: (va * p[2] + vd * q[2] + vr * r[2]) * k };
}

// De vuelta: { ra, dec (grados), d (pc) }.
function c3TmSky(x, y, z) {
   var d = Math.sqrt(x * x + y * y + z * z);
   if (!(d > 0)) return { ra: 0, dec: 0, d: 0 };
   var ra = Math.atan2(y, x) / C3_TM.DEG;
   if (ra < 0) ra += 360;
   return { ra: ra, dec: Math.asin(Math.max(-1, Math.min(1, z / d))) / C3_TM.DEG, d: d };
}

// El movimiento peculiar del Sol, en ICRS y pc/año (lo que se le SUMA a cada estrella para verla desde el LSR).
function c3TmSunIcrs() {
   var k = C3_TM.KMS_PCYR, u = C3_TM.SUN_UVW;
   return c3TmMulT(C3_TM_AG, [u[0] * k, u[1] * k, u[2] * k]);
}

// PROPAGAR un estado T años (negativo = hacia atras). `model` = "linear" | "galactic". Devuelve un estado nuevo.
// `t0` (solo el modelo galactico): el instante del estado de entrada, en años desde la REFERENCIA (la foto). El campo de
// marea de la Galaxia gira con la orbita del Sol (Ω t0), asi que propagar desde otro instante no es lo mismo: con t0 la
// composicion vale (de la foto a +N y de +N vuelta a la foto con t0 = N da el origen; test 3.1).
function c3TmPropagate(s, T, model, t0) {
   if (model !== "galactic" || T === 0) return { x: s.x + s.vx * T, y: s.y + s.vy * T, z: s.z + s.vz * T, vx: s.vx, vy: s.vy, vz: s.vz };
   return c3TmHill(s, T, c3TmGalFreq(), t0 || 0);
}

// LAS ECUACIONES DE HILL, resueltas (no integradas): el marco que gira con la orbita del Sol, x hacia FUERA del centro
// galactico, y en el sentido de la rotacion, z al polo SUR galactico (asi es dextrogiro y la rotacion es +Omega z):
//     x'' - 2 Ω y' - 4 Ω A x = 0      y'' + 2 Ω x' = 0      z'' + ν² z = 0
// (Binney y Tremaine 2008, §8.3). Con κ² = 4 Ω (Ω − A):
//     x(t) = xc + (x0 − xc) cos κt + (x0'/κ) sin κt,        xc = (2 Ω y0' + 4 Ω² x0) / κ²
//     y(t) = y0 + (y0' + 2 Ω x0) t − 2 Ω [ xc t + (x0 − xc) sin κt / κ + (x0'/κ²)(1 − cos κt) ]
//     z(t) = z0 cos νt + (z0'/ν) sin νt
// Las velocidades del marco que gira son las inerciales menos Ω × r; al final el resultado se lleva al marco INERCIAL
// (el marco ha girado Ω t): asi las posiciones siguen en ICRS, el marco de la foto.
// (Con `t0`: el estado de entrada es del instante t0 y el marco que gira ya estaba girado Ω t0: se lleva a el, se propaga
// y se devuelve girado Ω (t0 + T).)
function c3TmHill(s, T, F, t0) {
   var g = c3TmMul(C3_TM_AG, [s.x, s.y, s.z]), gv = c3TmMul(C3_TM_AG, [s.vx, s.vy, s.vz]);
   var Om = F.omega, ka = F.kappa, nu = F.nu, a0 = -Om * (t0 || 0), c0 = Math.cos(a0), s0 = Math.sin(a0);
   var hx = -g[0], hy = g[1], hvx = -gv[0], hvy = gv[1];
   var x0 = c0 * hx - s0 * hy, y0 = s0 * hx + c0 * hy, z0 = -g[2], vx0 = c0 * hvx - s0 * hvy, vy0 = s0 * hvx + c0 * hvy, vz0 = -gv[2];
   // al marco que gira
   var ux = vx0 + Om * y0, uy = vy0 - Om * x0;
   var xc = (2 * Om * uy + 4 * Om * Om * x0) / (ka * ka), ck = Math.cos(ka * T), sk = Math.sin(ka * T);
   var x = xc + (x0 - xc) * ck + (ux / ka) * sk;
   var y = y0 + (uy + 2 * Om * x0) * T - 2 * Om * (xc * T + (x0 - xc) * sk / ka + (ux / (ka * ka)) * (1 - ck));
   var wx = -(x0 - xc) * ka * sk + ux * ck;
   var wy = (uy + 2 * Om * x0) - 2 * Om * x;
   var cn = Math.cos(nu * T), sn = Math.sin(nu * T);
   var z = z0 * cn + (vz0 / nu) * sn, wz = -z0 * nu * sn + vz0 * cn;
   // de vuelta al marco inercial: el marco ha girado θ = Ω (t0 + T)
   var th = Om * ((t0 || 0) + T), c = Math.cos(th), sn2 = Math.sin(th);
   var Ix = c * x - sn2 * y, Iy = sn2 * x + c * y;
   var Vx = wx - Om * y, Vy = wy + Om * x;                   // v_inercial (en el marco que gira) = w + Ω × r
   var IVx = c * Vx - sn2 * Vy, IVy = sn2 * Vx + c * Vy;
   var r = c3TmMulT(C3_TM_AG, [-Ix, Iy, -z]), v = c3TmMulT(C3_TM_AG, [-IVx, IVy, -wz]);
   return { x: r[0], y: r[1], z: r[2], vx: v[0], vy: v[1], vz: v[2] };
}

// La «energia» de Jacobi del marco de Hill (se conserva: la prueba de que la solucion cerrada es la de las ecuaciones).
// `t` = el instante del estado (el marco que gira esta girado Ω t respecto al de la referencia).
function c3TmJacobi(s, F, t) {
   var g = c3TmMul(C3_TM_AG, [s.x, s.y, s.z]), gv = c3TmMul(C3_TM_AG, [s.vx, s.vy, s.vz]), a = -F.omega * (t || 0), ca = Math.cos(a), sa = Math.sin(a);
   var hx = -g[0], hy = g[1], hvx = -gv[0], hvy = gv[1];
   var x = ca * hx - sa * hy, y = sa * hx + ca * hy, z = -g[2], vx = ca * hvx - sa * hvy, vy = sa * hvx + ca * hvy;
   var ux = vx + F.omega * y, uy = vy - F.omega * x, uz = -gv[2];
   return 0.5 * (ux * ux + uy * uy + uz * uz) - 2 * F.omega * F.A * x * x + 0.5 * F.nu * F.nu * z * z;
}

// EL ENCUENTRO MAS CERCANO CON EL SOL de un movimiento rectilineo: { t (años desde el estado), d (pc) }.
function c3TmClosest(s) {
   var v2 = s.vx * s.vx + s.vy * s.vy + s.vz * s.vz;
   if (!(v2 > 0)) return { t: 0, d: Math.sqrt(s.x * s.x + s.y * s.y + s.z * s.z) };
   var t = -(s.x * s.vx + s.y * s.vy + s.z * s.vz) / v2, x = s.x + s.vx * t, y = s.y + s.vy * t, z = s.z + s.vz * t;
   return { t: t, d: Math.sqrt(x * x + y * y + z * z) };
}

// EL PUNTO DE CONVERGENCIA de un grupo: la direccion de su velocidad media EN EL CIELO (el apex hacia el que «van» sus
// movimientos propios; y el antiapex, de donde vienen). Metodo clasico del punto convergente (Boss 1908; Hyades). Solo con
// las que tienen velocidad radial medida (sin ella la direccion 3D no se sabe). Devuelve null o
//   { ra, dec (del apex), antiRa, antiDec, speed (km/s), n }.
function c3TmConvergent(states) {
   var vx = 0, vy = 0, vz = 0, n = 0;
   for (var i = 0; i < states.length; ++i) { var s = states[i]; if (!s) continue; vx += s.vx; vy += s.vy; vz += s.vz; ++n; }
   if (n === 0) return null;
   vx /= n; vy /= n; vz /= n;
   var a = c3TmSky(vx, vy, vz), b = c3TmSky(-vx, -vy, -vz);
   // la incertidumbre de la direccion: la dispersion de las velocidades de los miembros entre √n, sobre la velocidad media
   var s2 = 0;
   for (i = 0; i < states.length; ++i) { var q = states[i]; if (!q) continue; s2 += Math.pow(q.vx - vx, 2) + Math.pow(q.vy - vy, 2) + Math.pow(q.vz - vz, 2); }
   var sig = Math.sqrt(s2 / Math.max(1, n - 1) / 3), errDeg = (a.d > 0) ? Math.atan(sig / Math.sqrt(n) / a.d) * 180 / Math.PI : 180;
   return { ra: a.ra, dec: a.dec, antiRa: b.ra, antiDec: b.dec, speed: a.d / C3_TM.KMS_PCYR, n: n, errDeg: errDeg };
}
// EL APEX DE LA LITERATURA de un cumulo cercano (Gaia Collaboration, Babusiaux et al. 2018, A&A 616, A10, tabla A.3: punto de
// convergencia de 9 cumulos a menos de 250 pc; src/data/starfield/babusiaux2018_tablea3_convergent.csv). `rows` = la tabla leida.
// Devuelve { ra, dec, ref } si el centro del cumulo cae a menos de 1,5° del de la tabla; si no, null.
function c3TmApexLiteratureOf(ra, dec, rows) {
   for (var i = 0; rows && i < rows.length; ++i) {
      var r = rows[i];
      if (c3TmSepDeg(ra, dec, r.ra, r.dec) < 1.5) return { ra: r.raConv, dec: r.decConv, ref: "Babusiaux et al. 2018", name: r.name, rv: r.rv, pmRa: r.pmRa, pmDec: r.pmDec, plx: r.plx };
   }
   return null;
}
function c3TmSepDeg(ra1, de1, ra2, de2) {
   var k = Math.PI / 180, a = Math.sin((de2 - de1) * k / 2), b = Math.sin((ra2 - ra1) * k / 2);
   return 2 * Math.asin(Math.min(1, Math.sqrt(a * a + Math.cos(de1 * k) * Math.cos(de2 * k) * b * b))) / k;
}

// EL TAMAÑO DE UN GRUPO a lo largo del tiempo (la «edad cinematica»: rebobinando, una asociacion que se expande se encoge
// hasta un minimo). `states` = los de sus miembros; `times` = los instantes (años). Devuelve
//   { sizes: [ radio cuadratico medio (pc) ], best: { t, size } }   —el minimo de la lista—.
// OJO (y se dice en la interfaz): un cumulo LIGADO no se dispersa; sus miembros orbitan. Las rectas solo valen menos que su
// tiempo de cruce (~1 Myr para un abierto tipico) y el «minimo» de un cumulo ligado no es una edad.
function c3TmSpread(states, times, model) {
   var out = { sizes: [], best: null };
   for (var k = 0; k < times.length; ++k) {
      var mx = 0, my = 0, mz = 0, n = 0, pts = [];
      for (var i = 0; i < states.length; ++i) {
         if (!states[i]) continue;
         var p = c3TmPropagate(states[i], times[k], model);
         pts.push(p); mx += p.x; my += p.y; mz += p.z; ++n;
      }
      if (n < 2) { out.sizes.push(0); continue; }
      mx /= n; my /= n; mz /= n;
      var s2 = 0;
      for (i = 0; i < pts.length; ++i) { var dx = pts[i].x - mx, dy = pts[i].y - my, dz = pts[i].z - mz; s2 += dx * dx + dy * dy + dz * dz; }
      var rms = Math.sqrt(s2 / n);
      out.sizes.push(rms);
      if (out.best === null || rms < out.best.size) out.best = { t: times[k], size: rms };
   }
   return out;
}

// LA PROYECCION GNOMONICA del campo (para llevar de cielo a pixel SIN la libreria en cada fotograma). Se ajusta una afin
// sobre las coordenadas tangentes (ξ, η) del centro con puntos (ra, dec, x, y) que da la solucion de verdad; el resto
// (la distorsion) lo lleva cada estrella como RESIDUO constante (`c3TmTanResidual`): exacta en t = 0.
function c3TmTanXiEta(ra0, dec0, ra, dec) {
   var a0 = ra0 * C3_TM.DEG, d0 = dec0 * C3_TM.DEG, a = ra * C3_TM.DEG, d = dec * C3_TM.DEG;
   var cd = Math.cos(d), den = Math.sin(d0) * Math.sin(d) + Math.cos(d0) * cd * Math.cos(a - a0);
   if (!(den > 1e-6)) return null;                          // al otro lado del cielo
   return { xi: cd * Math.sin(a - a0) / den, eta: (Math.cos(d0) * Math.sin(d) - Math.sin(d0) * cd * Math.cos(a - a0)) / den };
}
function c3TmTanFit(ra0, dec0, pts) {
   // minimos cuadrados de x = a0 + a1 ξ + a2 η (y lo mismo para y)
   var S = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], bx = [0, 0, 0], by = [0, 0, 0], n = 0;
   for (var i = 0; i < pts.length; ++i) {
      var t = c3TmTanXiEta(ra0, dec0, pts[i].ra, pts[i].dec);
      if (t === null) continue;
      var f = [1, t.xi, t.eta];
      for (var r = 0; r < 3; ++r) { for (var c = 0; c < 3; ++c) S[r][c] += f[r] * f[c]; bx[r] += f[r] * pts[i].x; by[r] += f[r] * pts[i].y; }
      ++n;
   }
   if (n < 3) return null;
   var ax = c3TmSolve3(S, bx), ay = c3TmSolve3(S, by);
   if (ax === null || ay === null) return null;
   return { ra0: ra0, dec0: dec0, ax: ax, ay: ay, n: n };
}
function c3TmSolve3(M, b) {
   var A = [[M[0][0], M[0][1], M[0][2], b[0]], [M[1][0], M[1][1], M[1][2], b[1]], [M[2][0], M[2][1], M[2][2], b[2]]];
   for (var c = 0; c < 3; ++c) {
      var p = c;
      for (var r = c + 1; r < 3; ++r) if (Math.abs(A[r][c]) > Math.abs(A[p][c])) p = r;
      if (Math.abs(A[p][c]) < 1e-300) return null;
      var tmp = A[c]; A[c] = A[p]; A[p] = tmp;
      for (r = 0; r < 3; ++r) { if (r === c) continue; var f = A[r][c] / A[c][c]; for (var k = c; k < 4; ++k) A[r][k] -= f * A[c][k]; }
   }
   return [A[0][3] / A[0][0], A[1][3] / A[1][1], A[2][3] / A[2][2]];
}
// LA DISTORSION que la afin no recoge, en una rejilla N × N de nodos (los de `pts`, en orden de filas, en el centro de cada
// celda de W/N × H/N): el residuo «de verdad − afin» de cada nodo. `c3TmTanCorr` lo interpola (bilineal) en cualquier pixel.
// Asi una estrella que se mueve lleva la distorsion del sitio al que va, no la del que salio (test 3.2 de c3_run.js: sin
// esto, 0,54 px de error a ±10 000 años en NGC 1560).
function c3TmTanGrid(fit, pts, N, W, H) {
   if (!fit || pts.length !== N * N) return fit;
   var gx = new Float64Array(N * N), gy = new Float64Array(N * N);
   for (var i = 0; i < pts.length; ++i) { var q = c3TmTan(fit, pts[i].ra, pts[i].dec); gx[i] = (q !== null) ? pts[i].x - q.x : 0; gy[i] = (q !== null) ? pts[i].y - q.y : 0; }
   fit.grid = { N: N, W: W, H: H, gx: gx, gy: gy };
   return fit;
}
function c3TmTanCorr(fit, x, y) {
   var G = fit ? fit.grid : null;
   if (!G) return [0, 0];
   var N = G.N, u = Math.max(0, Math.min(N - 1, x / G.W * N - 0.5)), v = Math.max(0, Math.min(N - 1, y / G.H * N - 0.5));
   var i0 = Math.min(N - 2, Math.floor(u)), j0 = Math.min(N - 2, Math.floor(v)), a = u - i0, b = v - j0, k = j0 * N + i0;
   if (N < 2) return [G.gx[0], G.gy[0]];
   return [(1 - a) * (1 - b) * G.gx[k] + a * (1 - b) * G.gx[k + 1] + (1 - a) * b * G.gx[k + N] + a * b * G.gx[k + N + 1],
           (1 - a) * (1 - b) * G.gy[k] + a * (1 - b) * G.gy[k + 1] + (1 - a) * b * G.gy[k + N] + a * b * G.gy[k + N + 1]];
}
function c3TmTan(fit, ra, dec) {
   var t = c3TmTanXiEta(fit.ra0, fit.dec0, ra, dec);
   if (t === null) return null;
   return { x: fit.ax[0] + fit.ax[1] * t.xi + fit.ax[2] * t.eta, y: fit.ay[0] + fit.ay[1] * t.xi + fit.ay[2] * t.eta };
}

// ---------------------------------------------------------------------------
// EL CAMPO EN MOVIMIENTO. `c3TmBuild( result, opts )` prepara, una vez por imagen, el estado de las estrellas que se
// pintan; `c3TmAt( tm, T )` da, para un instante, su pixel y su distancia. Pura: `result` es el de cpStarfieldBuild
// (o un sintetico de los tests) y `opts.tan` la proyeccion ajustada (`c3TmTanFit`).
//   opts: { tan, epochYears (años de J2016 a la foto), model ("linear"|"galactic"), lsr (bool), rv: { indice: { rv, err } } }
// Devuelve tm = { n, idx: [ indice en result.stars ], st0: [ estado en J2016 ], rvFrom: [ "gaia"|"cluster"|"none" ],
//                 res: [ residuo x, y del pixel ], counts: { gaia, cluster, none }, clusterRv: { indice cumulo: km/s } }
// ---------------------------------------------------------------------------
function c3TmBuild(result, opts) {
   var o = opts || {}, stars = (result && result.stars) ? result.stars : [], rv = o.rv || {}, tm = { n: 0, idx: [], st0: [], rvFrom: [], rvKms: [], res: [], dPc: [], err: [],
            coneDeg: c3TmConeDeg(result), pmErrCounts: { gaia: 0, g: 0, tier: 0, none: 0 },
            counts: { gaia: 0, cluster: 0, none: 0 }, clusterRv: {}, epochYears: (typeof o.epochYears === "number" && isFinite(o.epochYears)) ? o.epochYears : 0, tan: o.tan || null,
            model: (o.model === "galactic") ? "galactic" : "linear", lsr: (o.lsr === true), sun: c3TmSunIcrs() };
   var i, s;
   // la velocidad radial de un cumulo: la mediana de la de sus miembros que la tienen (al menos CLUSTER_RV_MIN)
   var byCl = {};
   for (i = 0; i < stars.length; ++i) { s = stars[i]; if (s.cluster >= 0 && rv[i] && isFinite(rv[i].rv)) (byCl[s.cluster] = byCl[s.cluster] || []).push(rv[i].rv); }
   for (var c in byCl) if (byCl[c].length >= C3_TM.CLUSTER_RV_MIN) { var l = byCl[c].sort(function(a, b) { return a - b; }); tm.clusterRv[c] = l[l.length >> 1]; }
   // (2-nov-2026, decisión 2) un cúmulo LIGADO con menos de CLUSTER_RV_MIN miembros con RV: la mediana de los que la tienen, para todos sus
   // miembros sin una RV precisa. Si no, unos van con su RV (con errores de varios km/s a 2-3 kpc) y otros con 0, y el cúmulo «estalla» en 1 Ma
   // (Collinder 34, HSC 1120: 17 de 17 dentro de r_J en la foto y 0 % a +1 Ma; con esto, 100 %). Su error común mueve el cúmulo entero, no lo deshace.
   var clList = (result && result.clusters) ? result.clusters : [];
   for (var c2 in byCl) {
      var K2 = clList[c2];
      if (tm.clusterRv[c2] !== undefined || !K2 || !(K2.kind === "open" || K2.kind === "globular") || C3_TM_CL_DECONV !== true) continue;   // (rojo: C3_TM_CL_DECONV = false, con lo de c3TmClusterDeconv)
      var l2 = byCl[c2].slice().sort(function(a, b) { return a - b; }); tm.clusterRv[c2] = l2[l2.length >> 1];
   }
   var want = o.indices || null;
   for (i = 0; i < stars.length; ++i) {
      if (want !== null && want[i] !== true) continue;
      s = stars[i];
      if (!s || s.pmRa === null || s.pmDec === null || !isFinite(s.pmRa) || !isFinite(s.pmDec)) continue;
      var d = (s.dist && s.dist.pc > 0) ? s.dist.pc : ((s.plx > 0.05) ? 1000 / s.plx : 0);
      // (2-nov-2026, decisión 2) un miembro de un cúmulo LIGADO (abierto o globular con distancia de catálogo) va a la distancia del cúmulo: su
      // paralaje propia lo dispersaría en profundidad por su error (a 2,6 kpc, ±140 pc frente a un radio de Jacobi de 5 pc). En la interfaz ya
      // viene así (CabraShared/csh_starfield.js cpSfAssignDistances da a cada miembro de un cúmulo confirmado la distancia del cúmulo): esto solo
      // cuenta para un `result` que no lo haga (los sintéticos de tests/c3_tm_cases.js, 8.8 frente a 8.8b). Medido el 2-nov: con la costura en
      // false, Collinder 34 sigue con 17 de 17 dentro de r_J en la foto. (El «0 % unidas a +1 Ma» de HSC 1120 NO venía de aquí, sino de las RV
      // mezcladas —unos miembros con la suya, otros con 0— y del centro con la media: ver más abajo y c3TmClusterDeconv.)
      var clD = (C3_TM_MEMBER_CLDIST === true && s.cluster >= 0 && result.clusters) ? result.clusters[s.cluster] : null;
      if (clD && (clD.kind === "open" || clD.kind === "globular") && clD.dist && clD.dist.pc > 0) d = clD.dist.pc; else clD = null;
      if (!(d > 0)) continue;
      var from = "none", v = 0;
      var precise = !(s.cluster >= 0 && tm.clusterRv[s.cluster] !== undefined) || (rv[i] && rv[i].err !== null && isFinite(rv[i].err) && rv[i].err <= C3_TM.MEMBER_RV_ERR);
      if (rv[i] && isFinite(rv[i].rv) && precise) { from = "gaia"; v = rv[i].rv; }
      else if (s.cluster >= 0 && tm.clusterRv[s.cluster] !== undefined) { from = "cluster"; v = tm.clusterRv[s.cluster]; }
      var st0 = c3TmState(s.ra0, s.dec0, d, s.pmRa, s.pmDec, v);
      // el residuo de la proyeccion (distorsion) en la epoca de la foto, que es donde esta el pixel de verdad
      var rx = 0, ry = 0;
      if (tm.tan && typeof s.x === "number") {
         var e = c3TmPropagate(st0, tm.epochYears, "linear"), sk = c3TmSky(e.x, e.y, e.z), q = c3TmTan(tm.tan, sk.ra, sk.dec);
         if (q !== null) { var g0 = c3TmTanCorr(tm.tan, q.x, q.y); rx = s.x - q.x - g0[0]; ry = s.y - q.y - g0[1]; }
      }
      tm.idx.push(i); tm.st0.push(st0); tm.rvFrom.push(from); tm.rvKms.push(v); tm.res.push([rx, ry]); tm.dPc.push(d);
      var Ei = c3TmErrOf(clD ? { dist: clD.dist, plxErr: s.plxErr, plxErrMax: s.plxErrMax, pmErr: s.pmErr, pmTier: s.pmTier, g: s.g, ra0: s.ra0, dec0: s.dec0, pmRa: s.pmRa, pmDec: s.pmDec } : s, d, from, rv[i]);
      tm.err.push(Ei); ++tm.pmErrCounts[Ei.pmSrc];
      ++tm.counts[from];
   }
   tm.n = tm.idx.length;
   tm.pos = {};
   for (i = 0; i < tm.n; ++i) tm.pos[tm.idx[i]] = i;
   tm.cls = c3TmClusterSetup(tm, result);
   return tm;
}

// ---------------------------------------------------------------------------
// LOS CÚMULOS EN LA MÁQUINA DEL TIEMPO (2-nov-2026, decisiones 2 y 3A de Nino; docs/investigacion_orbitas_largo_plazo.md §3.4)
//  · GRAVEDAD PROPIA: un Plummer RÍGIDO centrado en la órbita del centro del cúmulo (tm/galaxy.js). Sin ella sus miembros, partículas de
//    prueba, se «evaporaban» (4–18 % dentro del radio de Jacobi a 100 Ma; con ella 77–97 %, y sigue a unas N cuerpos a ~10 puntos).
//  · MASA Y RADIO: del catálogo de Hunt y Reffert 2023 (CabraShared/data/clusters_hr23.csv). Su `rt` NO es un radio de Jacobi dinámico:
//    es «el radio con el mejor contraste frente a las estrellas del campo, parecido a la definición de radio de marea de King (1962)»
//    (HR23, §4; leído en el artículo, arXiv:2303.13424). Se toma como radio de Jacobi r_J y la masa es la que lo haría serlo:
//    M = (4Ω² − κ²) r_J³ / G con Ω y κ del potencial (MilkyWayPotential2022) en el radio galactocéntrico del cúmulo. La escala del Plummer,
//    a = r50 (el radio que encierra la mitad de los miembros en el cielo: en un Plummer, el de la mitad de la masa proyectada es a).
//    NO VERIFICADO frente a las masas de Jacobi de Hunt y Reffert 2024 (arXiv:2403.05143), que no están en la base local.
//  · ESCAPADAS: un miembro más lejos que r_J del centro del cúmulo en ese instante (gris tenue en la foto y en el 3D).
//  · EDAD (3A): antes de 10^age años (log de la edad de HR23) el cúmulo no existía: sus miembros no se pintan.
//  · Solo cúmulos abiertos y globulares del catálogo con distancia y r_J; las asociaciones («moving groups») no están ligadas: sin Plummer
//    ni recuento de escapadas (sí su edad).
// ---------------------------------------------------------------------------
var C3_TM_CL = { MIN_MEMBERS: 5 };
// (2-nov-2026, Q6 del coordinador: se queda) En la interfaz no cambia nada —csh_starfield.js cpSfAssignDistances ya da a cada miembro de un
// cúmulo confirmado la distancia del cúmulo; medido: con false, Collinder 34 sigue 17 de 17 dentro de r_J—. Sirve a los «result» que no lo
// hacen: los sintéticos de tests/c3_tm_cases.js (8.8 con cada miembro a su distancia 3D de verdad, 8.8b a la del cúmulo).
var C3_TM_MEMBER_CLDIST = true;
// 4Ω² − κ² = −R dΩ²/dR (1/año²) en R pc del plano, en el potencial (o, sin él, con las constantes de Oort medidas: 4A(A − B)).
function c3TmTidalAt(Rpc) {
   var k = C3_TM.KMS_PCYR / 1000;
   if (typeof cshGdVcirc === "function" && Rpc > 100) {
      var R = Rpc / 1000, h = 0.01, om2 = function(r) { var v = cshGdVcirc(r); return v * v / (r * r); };
      var t = -R * (om2(R + h) - om2(R - h)) / (2 * h);                // (km/s/kpc)²
      if (t > 0) return t * k * k;
   }
   var A = C3_TM.OORT_A * k, B = C3_TM.OORT_B * k;
   return 4 * A * (A - B);
}
function c3TmClusterSetup(tm, result) {
   var out = [], stars = (result && result.stars) ? result.stars : [], list = (result && result.clusters) ? result.clusters : [], byC = {}, i, c;
   tm.clOf = new Int32Array(tm.n);
   for (i = 0; i < tm.n; ++i) { tm.clOf[i] = -1; c = stars[tm.idx[i]] ? stars[tm.idx[i]].cluster : -1; if (c >= 0) (byC[c] = byC[c] || []).push(i); }
   var sun = (typeof c3GalSun === "function") ? c3GalSun() : { x: -8122, y: 0, z: 20.8 };
   for (var key in byC) {
      var ci = Number(key), cl = list[ci], mem = byC[key];
      if (!cl || mem.length < C3_TM_CL.MIN_MEMBERS) continue;
      var s0 = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0 };
      for (i = 0; i < mem.length; ++i) { var q = tm.st0[mem[i]]; s0.x += q.x; s0.y += q.y; s0.z += q.z; s0.vx += q.vx; s0.vy += q.vy; s0.vz += q.vz; }
      for (var f in s0) s0[f] /= mem.length;
      // (2-nov, noche: Q1) la masa y la escala ANTES de la deconvolución: su suelo virial las necesita (solo usan la POSICIÓN del centro)
      var d = (cl.dist && cl.dist.pc > 0) ? cl.dist.pc : Math.sqrt(s0.x * s0.x + s0.y * s0.y + s0.z * s0.z);
      var rtDeg = (cl.selRadiusDeg > 0) ? cl.selRadiusDeg : null, r50Deg = (cl.coreRadiusDeg > 0) ? cl.coreRadiusDeg : null;
      var bound = (cl.kind === "open" || cl.kind === "globular") && rtDeg !== null && d > 0;
      var rJ = bound ? d * Math.tan(rtDeg * C3_TM.DEG) : null, a = (bound && r50Deg !== null) ? d * Math.tan(r50Deg * C3_TM.DEG) : (bound ? rJ / 3 : null);
      var g = c3TmMul(C3_TM_AG, [s0.x, s0.y, s0.z]), X = sun.x + g[0], Y = sun.y + g[1], Rgc = Math.sqrt(X * X + Y * Y), tid = c3TmTidalAt(Rgc);
      var M = bound ? tid * rJ * rJ * rJ / C3_TM.G_PC3_MSUN_YR2 : 0;
      var sv = c3TmVirialSigma(bound ? M : 0, a);
      // (solo en los LIGADOS: en una asociación que se expande, la desviación de cada miembro es la señal —su edad cinemática—)
      var dv = (C3_TM_CL_DECONV === true && (cl.kind === "open" || cl.kind === "globular")) ? c3TmClusterDeconv(tm, mem, s0, sv) : { kt: 1, kr: 1, n: 0, sv: 0, floor: false, ktMeas: 1 };
      var la = (cl.extra && typeof cl.extra.logAge === "number" && isFinite(cl.extra.logAge)) ? cl.extra.logAge : null;
      var k = out.length;
      for (i = 0; i < mem.length; ++i) tm.clOf[mem[i]] = k;
      // los que están DENTRO de r_J en la foto: los únicos que pueden «escaparse» (un miembro del catálogo puede estar en la cola o en el halo, o
      // venir del grupo por movimiento propio —origen «blind»—, más allá de r_J ya hoy; no cuenta ni se pinta gris)
      var in0 = new Uint8Array(mem.length), nIn0 = 0;
      for (i = 0; i < mem.length && rJ > 0; ++i) { var q0 = tm.st0[mem[i]], ddx = q0.x - s0.x, ddy = q0.y - s0.y, ddz = q0.z - s0.z; if (ddx * ddx + ddy * ddy + ddz * ddz <= rJ * rJ) { in0[i] = 1; ++nIn0; } }
      out.push({ c: ci, in0: in0, nIn0: nIn0, name: cl.name || cl.id || ("#" + ci), kind: cl.kind, catalog: cl.catalog || "", mem: mem, st0: s0, dPc: d, rtDeg: rtDeg, r50Deg: r50Deg,
                 rJ: rJ, a: a, M: M, gm: M * C3_TM.G_PC3_MSUN_YR2, Rgc: Rgc, logAge: la, ageYr: (la !== null) ? Math.pow(10, la) : null, bound: bound,
                 kt: dv.kt, kr: dv.kr, nRv: dv.n, sv: dv.sv || 0, ktFloor: dv.floor === true, ktMeas: dv.ktMeas });
   }
   for (var kk = 0; kk < out.length; ++kk) { out[kk].memIx = {}; for (i = 0; i < out[kk].mem.length; ++i) out[kk].memIx[out[kk].mem[i]] = i; }
   return out;
}
// (2-nov-2026, decisión 2) LO QUE SE MUEVE UN MIEMBRO RESPECTO DE SU CÚMULO: lo medido menos lo que explican los errores de Gaia.
//  · la velocidad del centro: la MEDIANA de las de sus miembros, componente a componente. Con la media, una RV de Gaia de 27 km/s (una
//    binaria o un intruso) arrastraba el centro 12 pc en 10 Ma y el cúmulo entero «se escapaba» (IC 1396, UBC 10b: 0 % unidas a +10 Ma).
//  · la desviación de cada miembro, encogida por el cociente de la dispersión DE VERDAD entre la observada (deconvolución de un error
//    gaussiano conocido): en el cielo k_t = √(1 − σ_err² / σ_obs²) con σ_err el error del movimiento propio (c3TmErrOf) a la distancia del
//    cúmulo; en la visual k_r, lo mismo con las RV de Gaia de sus miembros, y 0 con menos de 3 (con 1 o 2 no se separa la dispersión del
//    error). Medido en la interfaz (tests/c3_orbits_2nov.js, parte C): Collinder 34, HSC 1120 a 2,6 kpc, σ_obs 0,59 pc/Ma y σ_err 0,69 → k_t = 0
//    (el ruido de Gaia es TODO lo que se ve: sin esto, «47 % unidas» a +10 Ma era ruido); IC 1396, σ_obs 0,36–1,19 y σ_err 0,09–0,34 → k_t ≈ 0,9–0,97.
//  Cambia la velocidad de los miembros en tm.st0 (su sitio en la foto no: la diferencia en los años de J2016 a la foto es de milésimas de segundo).
//  Rojo: C3_TM_CL_DECONV = false (la media y lo medido tal cual; tests/c3_tm_cases.js 8.13 y C3_ORB_BREAK=deconv).
// (2-nov-2026, noche: Q1 = A de Nino) EL SUELO VIRIAL. Si el ruido de Gaia lo explica todo (k_t = 0: Collinder 34 a 2,6 kpc), los miembros
//  se movían EXACTAMENTE con el centro: un cúmulo «frío» que no se deshace nunca y un «100 % unidas» que no significa nada. Pero un cúmulo
//  ligado no puede tener menos dispersión interna que la que le da su propia gravedad: el teorema del virial (2K + W = 0) en una esfera de
//  Plummer de masa M y escala a —la MISMA que sujeta a sus miembros: M de su radio de Jacobi, a = r50— da W = −3πGM²/(32a) (Plummer 1911;
//  Binney y Tremaine 2008, §2.2.2), K = 3πGM²/(64a) y la dispersión 1D media σ_vir² = 2K/(3M) = πGM/(32a). Así lo medido que queda es, como
//  poco, σ_vir: k_t = max(k_t, min(1, σ_vir/σ_obs)) (y k_r igual, con ≥ 3 RV propias). Los miembros siguen ligados al Plummer y se van
//  solos por la marea, no por un 0 % o un 100 % de mentira. Rojo: C3_TM_CL_VIRIAL = false (tests/c3_tm_cases.js 8.14).
var C3_TM_CL_VIRIAL = true;
// σ_vir (pc/año) de un Plummer de M (M☉) y escala a (pc): √(πGM/(32a)); 0 sin masa o sin escala
function c3TmVirialSigma(M, a) { return (C3_TM_CL_VIRIAL === true && M > 0 && a > 0) ? Math.sqrt(Math.PI * C3_TM.G_PC3_MSUN_YR2 * M / (32 * a)) : 0; }
var C3_TM_CL_DECONV = true;
function c3TmMedian(a) { var s = a.slice().sort(function(x, y) { return x - y; }), n = s.length; return (n === 0) ? 0 : (n % 2) ? s[n >> 1] : 0.5 * (s[n / 2 - 1] + s[n / 2]); }
function c3TmClusterDeconv(tm, mem, s0, sv) {
   var i, q, vx = [], vy = [], vz = [];
   for (i = 0; i < mem.length; ++i) { q = tm.st0[mem[i]]; vx.push(q.vx); vy.push(q.vy); vz.push(q.vz); }
   s0.vx = c3TmMedian(vx); s0.vy = c3TmMedian(vy); s0.vz = c3TmMedian(vz);
   var so = 0, se = 0, sr = 0, ser = 0, nR = 0, U = [], k = C3_TM.KMS_PCYR;
   for (i = 0; i < mem.length; ++i) {
      q = tm.st0[mem[i]];
      var dq = Math.sqrt(q.x * q.x + q.y * q.y + q.z * q.z), ux = q.x / dq, uy = q.y / dq, uz = q.z / dq;
      var dx = q.vx - s0.vx, dy = q.vy - s0.vy, dz = q.vz - s0.vz, dr = dx * ux + dy * uy + dz * uz;
      U.push([ux, uy, uz, dx, dy, dz, dr]);
      so += Math.max(0, dx * dx + dy * dy + dz * dz - dr * dr) / 2;
      var E = tm.err ? tm.err[mem[i]] : null;
      if (E) { var st = C3_TM.K_PM * E.spm * (dq / 1000) * k; se += st * st; }
      if (tm.rvFrom[mem[i]] === "gaia") { sr += dr * dr; var er = (E ? E.srv : 2) * k; ser += er * er; ++nR; }
   }
   var kt = (so > 0) ? Math.sqrt(Math.max(0, 1 - se / so)) : 0, kr = (nR >= 3 && sr > 0) ? Math.sqrt(Math.max(0, 1 - ser / sr)) : 0, kt0 = kt;
   // (Q1) el suelo virial: la dispersión que queda, como poco σ_vir (so / N = σ_obs² por componente en el cielo; sr / nR, en la visual)
   if (sv > 0 && so > 0) kt = Math.max(kt, Math.min(1, sv / Math.sqrt(so / mem.length)));
   if (sv > 0 && nR >= 3 && sr > 0) kr = Math.max(kr, Math.min(1, sv / Math.sqrt(sr / nR)));
   // (un miembro sin RV propia —la del cúmulo o ninguna— no tiene desviación visual medida: la suya es solo la proyección de una RV común en
   //  su línea de vista, hasta |V|·Δθ ≈ 2 km/s en un cúmulo de 5° como las Pléyades; se queda con la del centro, k_r = 0)
   for (i = 0; i < mem.length; ++i) {
      var u = U[i], o = tm.st0[mem[i]], n = {}, kri = (tm.rvFrom[mem[i]] === "gaia") ? kr : 0;
      for (var f in o) n[f] = o[f];
      n.vx = s0.vx + kri * u[6] * u[0] + kt * (u[3] - u[6] * u[0]);
      n.vy = s0.vy + kri * u[6] * u[1] + kt * (u[4] - u[6] * u[1]);
      n.vz = s0.vz + kri * u[6] * u[2] + kt * (u[5] - u[6] * u[2]);
      tm.st0[mem[i]] = n;
   }
   return { kt: kt, kr: kr, n: nR, sv: sv || 0, floor: kt > kt0, ktMeas: kt0 };
}
// El centro del cúmulo c (de tm.cls) en el instante de la foto, como c3TmStateAtPhoto (el mismo marco y la misma corrección del LSR).
function c3TmClusterStateAtPhoto(tm, c) {
   var e = c3TmPropagate(tm.cls[c].st0, tm.epochYears, "linear");
   if (tm.lsr) { e.vx += tm.sun[0]; e.vy += tm.sun[1]; e.vz += tm.sun[2]; }
   return e;
}
// ---------------------------------------------------------------------------
// LO QUE NO SE SABE (2-nov-2026, decisión 5 de Nino, «las dos»; docs/investigacion_orbitas_largo_plazo.md §3.1 y §5 #3)
//  (a) EL CONO de cada estrella: cuánto crece el error de su sitio con |T| por los errores de Gaia. Si su sitio en el cielo ya no se sabe
//      mejor que FIELD_FRAC del lado menor de la foto, o su distancia mejor que DEPTH_FRAC de ella (lo que crece por el movimiento, no el
//      error de hoy, que ya enseñan las barras), se apaga: de x = 0,5 (entera) a x = 1 (no se pinta). Rectas (la propagación lineal del error):
//      casa con el Monte Carlo al 5 % hasta 10 Ma (§3.1); más allá, con órbitas, es la escala, no la cifra.
//  (b) LA NUBE de la estrella elegida: N_CLOUD estados de partida sacados de esos mismos errores y llevados con el mismo modelo (con órbitas,
//      integrados: tm/galaxy.js c3TmCloudOrbit). Se hace al elegirla o al cambiar de alcance o de movimiento, no al arrastrar.
// DE DÓNDE SALEN LOS ERRORES (la base Gaia local de PixInsight NO trae errores por estrella, solo el tramo de calidad oro/plata/bronce):
//  · distancia: su intervalo (Bailer-Jones 16-84 % o la paralaje refinada ± su error, de la red); sin él, la cota del tramo de paralaje;
//  · movimiento propio (2-nov, Q4 del coordinador): el de la PROPIA estrella, si el afinado en red lo trajo (e_pmRA y e_pmDE de Gaia DR3 en las
//    cuatro consultas de refinado; CabraShared/csh_starfield.js cpSfRefineApply deja `pmErr`, la media cuadrática de los dos). Medido en
//    M 13 a 0,1°: 817 de 817 filas con los dos en ESA, GAVO, el espejo IDIA por ASU y la consulta de VizieR por el motor de espejos (CDS
//    sin conexión ese día). Sin él (sin red, caché vieja): el error TÍPICO de Gaia para su G (c3TmPmErrOfG), sin pasar de la cota superior
//    de su tramo en la base local (oro ≤ 0,14, plata ≤ 0,97, bronce ≤ 1,58 mas/año; CP_SF.PM_ERR_MAX). Con la cota sola (la primera versión)
//    a 1 Ma se apagaba casi todo un campo de 0,5° (Collinder 34: 470 de 470 atenuándose). `pmSrc` dice cuál fue ("gaia" | "g" | "tier" |
//    "none") y tm.pmErrCounts los cuenta: el rótulo lo dice (tm/hud.js c3TmPmErrWords);
//  · velocidad radial: la de Gaia DR3 con su error; un miembro con la de su cúmulo, RV_CLUSTER; sin ninguna (estrella hueca), RV_NONE:
//    la dispersión de velocidades de las estrellas del disco cerca del Sol (~30 km/s; supuesto, no medido aquí).
// Rojos: C3_TM_CONE = false (no se apaga nada), y el de la nube en tests/c3_tm_cases.js 8.12.
// ---------------------------------------------------------------------------
var C3_TM_CONE = true;
// (2-nov-2026, noche: Q3 = A de Nino) EL CONO NO ESCONDE: una estrella cuyo sitio ya no se sabe (x ≥ 1) se queda al MIN_ALPHA (25 %) de su
// opacidad, no desaparece; de x = 0,5 a 1 baja de 1 a MIN_ALPHA. Lo mismo los cuadrados (las que entran de fuera: tm/tm_incoming.js). El
// rótulo dice cuántas son inciertas (tm/hud.js). Rojo: C3_TM_CONE_FLOOR = false (lo de antes: de 1 a 0 y, con x ≥ 1, no se pinta; 8.15).
var C3_TM_CONE_FLOOR = true;
var C3_TM_UNC = { FIELD_FRAC: 0.10, DEPTH_FRAC: 0.25, RV_CLUSTER: 1.0, RV_NONE: 30, PM_DEFAULT: 1.0, PLX_DEFAULT: 0.5, N_CLOUD: 200, MIN_ALPHA: 0.25 };
// La opacidad (0…1) que el cono deja a una estrella de x: 1 hasta 0,5; luego baja en recta hasta MIN_ALPHA en x = 1 y ahí se queda.
// (Rojo C3_TM_CONE_FLOOR = false: de 1 a 0, como antes; 0 = no se pinta.)
function c3TmConeAlpha(x) {
   if (!(x > 0.5)) return 1;
   var lo = (C3_TM_CONE_FLOOR === true) ? C3_TM_UNC.MIN_ALPHA : 0;
   return Math.max(lo, 1 - (1 - lo) * Math.min(1, 2 * x - 1));
}
// El lado menor de la foto en grados × FIELD_FRAC (el límite del error en el cielo). Sin campo, 0,1°.
function c3TmConeDeg(result) {
   var f = result && result.field;
   if (f && f.width > 0 && f.height > 0 && f.scaleArcsec > 0) return C3_TM_UNC.FIELD_FRAC * Math.min(f.width, f.height) * f.scaleArcsec / 3600;
   return 0.1;
}
// Los errores de una estrella: { sd (pc), spm (mas/año), srv (km/s), y lo observado para la nube: ra0, dec0, d, pmRa, pmDec, rv }
function c3TmErrOf(s, d, from, rvi) {
   var sd = (s.dist && s.dist.hi > s.dist.lo && s.dist.lo > 0) ? (s.dist.hi - s.dist.lo) / 2 : null;
   if (sd === null) { var pe = (s.plxErr > 0) ? s.plxErr : (s.plxErrMax > 0) ? s.plxErrMax : C3_TM_UNC.PLX_DEFAULT; sd = Math.min(d, d * d * pe / 1000); }
   // (sin el error de la estrella: el típico de Gaia para su G, sin pasar de la cota de su tramo; la cota sola apagaba a 1 Ma TODO un campo de 0,5°)
   var tierMax = (typeof CP_SF !== "undefined" && CP_SF.PM_ERR_MAX && s.pmTier && CP_SF.PM_ERR_MAX[s.pmTier] > 0) ? CP_SF.PM_ERR_MAX[s.pmTier] : null;
   var own = (s.pmErr > 0 && isFinite(s.pmErr)), byG = !own && (typeof s.g === "number" && isFinite(s.g));
   var spm = own ? s.pmErr : byG ? Math.min(tierMax || 9, c3TmPmErrOfG(s.g)) : (tierMax || C3_TM_UNC.PM_DEFAULT);
   var pmSrc = own ? "gaia" : byG ? "g" : (tierMax ? "tier" : "none");
   var srv = (from === "gaia" && rvi && rvi.err > 0) ? rvi.err : (from === "cluster") ? C3_TM_UNC.RV_CLUSTER : (from === "gaia") ? 2 : C3_TM_UNC.RV_NONE;
   return { sd: sd, spm: spm, pmSrc: pmSrc, srv: srv, ra0: s.ra0, dec0: s.dec0, d: d, pmRa: s.pmRa, pmDec: s.pmDec, rv: (rvi && isFinite(rvi.rv) && from === "gaia") ? rvi.rv : 0 };
}
// El error TÍPICO del movimiento propio de Gaia (E)DR3 para una G (mas/año): 0,02–0,03 a G < 15, 0,07 a G = 17, 0,5 a G = 20, 1,4 a G = 21
// (Gaia Collaboration, Brown et al. 2021, resumen de EDR3; DR3 tiene la misma astrometría). Interpolado en log. NO VERIFICADO contra el
// artículo en esta sesión (cifras de memoria del resumen); por eso no pasa nunca de la cota del tramo de la base local.
var C3_TM_PMERR_G = [[12, 0.02], [15, 0.025], [17, 0.07], [20, 0.5], [21, 1.4]];
function c3TmPmErrOfG(g) {
   var T = C3_TM_PMERR_G;
   if (g <= T[0][0]) return T[0][1];
   for (var k = 1; k < T.length; ++k) if (g <= T[k][0]) { var f = (g - T[k - 1][0]) / (T[k][0] - T[k - 1][0]); return Math.exp(Math.log(T[k - 1][1]) + f * (Math.log(T[k][1]) - Math.log(T[k - 1][1]))); }
   return T[T.length - 1][1] * Math.pow(10, 0.4 * (g - 21));
}
// El cono de la estrella i en T (e = su estado en la foto, p = su sitio en T): { th: error en el cielo (grados, rms), par: el que crece en
// profundidad (pc), D: su distancia en T }. Propagación LINEAL de los errores de partida (distancia, dos movimientos propios, RV).
var C3_TM_CONE_BREAK = "";       // (rojo de tests/c3_tm_cases.js 8.11: "norv" quita el término de la RV)
function c3TmConeSig(tm, i, e, p, T) {
   var E = tm.err[i]; if (!E) return null;
   var d0 = Math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z); if (!(d0 > 0)) return null;
   var ux = e.x / d0, uy = e.y / d0, uz = e.z / d0, a = Math.atan2(uy, ux), b = Math.asin(Math.max(-1, Math.min(1, uz)));
   var rx = -Math.sin(a), ry = Math.cos(a), dx = -Math.sin(b) * Math.cos(a), dy = -Math.sin(b) * Math.sin(a), dz = Math.cos(b);
   var k = C3_TM.KMS_PCYR, svr = E.srv * k * T, svt = C3_TM.K_PM * E.spm * (d0 / 1000) * k * T;
   var vr = e.vx * ux + e.vy * uy + e.vz * uz, tx = e.vx - vr * ux, ty = e.vy - vr * uy, tz = e.vz - vr * uz, f = E.sd / d0 * T;    // (la velocidad en el cielo crece con la distancia)
   var D = Math.sqrt(p.x * p.x + p.y * p.y + p.z * p.z); if (!(D > 0)) return null;
   if (C3_TM_CONE_BREAK === "norv") svr = 0;
   var nx = p.x / D, ny = p.y / D, nz = p.z / D, perp = 0, par = 0;
   var V = [[svr * ux, svr * uy, svr * uz], [svt * rx, svt * ry, 0], [svt * dx, svt * dy, svt * dz], [E.sd * ux + f * tx, E.sd * uy + f * ty, E.sd * uz + f * tz]];
   for (var q = 0; q < 4; ++q) { var w = V[q], dn = w[0] * nx + w[1] * ny + w[2] * nz; par += dn * dn; perp += w[0] * w[0] + w[1] * w[1] + w[2] * w[2] - dn * dn; }
   return { th: Math.sqrt(Math.max(0, perp)) / D / C3_TM.DEG, par: Math.sqrt(Math.max(0, par - E.sd * E.sd)), D: D };
}
// x del cono: ≥ 1, no se sabe dónde está en T; ≤ 0,5, sí (el mayor de los dos cocientes: cielo frente a FIELD_FRAC de la foto, profundidad
// frente a DEPTH_FRAC de su distancia)
function c3TmConeX(tm, i, e, p, T) {
   var S = c3TmConeSig(tm, i, e, p, T);
   return (S === null) ? 0 : Math.max(S.th / Math.max(1e-6, tm.coneDeg), S.par / (C3_TM_UNC.DEPTH_FRAC * S.D));
}
// LA NUBE de la estrella i: n estados en la foto (heliocéntrico ICRS, como c3TmStateAtPhoto) sacados de sus errores. `seed` fija el azar.
function c3TmCloudMake(tm, i, n, seed) {
   var E = tm.err[i], N = n || C3_TM_UNC.N_CLOUD, s = (seed || 12345) >>> 0, out = [], spare = null;
   function u() { s = (Math.imul(1664525, s) + 1013904223) >>> 0; return (s + 0.5) / 4294967296; }
   function g() { if (spare !== null) { var t = spare; spare = null; return t; } var a = u(), b = u(), r = Math.sqrt(-2 * Math.log(a)); spare = r * Math.sin(2 * Math.PI * b); return r * Math.cos(2 * Math.PI * b); }
   for (var q = 0; q < N; ++q) {
      var d = Math.max(0.2 * E.d, E.d + E.sd * g()), rvq = ((tm.rvFrom[i] === "gaia") ? E.rv : tm.rvKms[i]) + E.srv * g();
      var st = c3TmState(E.ra0, E.dec0, d, E.pmRa + E.spm * g(), E.pmDec + E.spm * g(), rvq), e = c3TmPropagate(st, tm.epochYears, "linear");
      if (tm.lsr) { e.vx += tm.sun[0]; e.vy += tm.sun[1]; e.vz += tm.sun[2]; }
      out.push(e);
   }
   return { i: i, n: N, st: out, orbit: null };
}
// La nube en T: { x, y, pc, ok } (pixel de la foto con el residuo de la estrella, como c3TmAt) y la dispersión en el cielo (grados, rms)
function c3TmCloudAt(tm, cl, T) {
   var N = cl.n, o = { x: new Float64Array(N), y: new Float64Array(N), pc: new Float64Array(N), ok: new Uint8Array(N), ra: new Float64Array(N), dec: new Float64Array(N) }, i = cl.i;
   for (var q = 0; q < N; ++q) {
      var p = (T === 0) ? cl.st[q] : (tm.model === "galactic" && cl.orbit) ? c3TmTableAt(cl.orbit.rel, cl.orbit.vel, cl.orbit, q, T) : c3TmPropagate(cl.st[q], T, tm.model);
      var k = c3TmSky(p.x, p.y, p.z); o.pc[q] = k.d; o.ra[q] = k.ra; o.dec[q] = k.dec;
      var t = tm.tan ? c3TmTan(tm.tan, k.ra, k.dec) : null;
      if (t === null) { o.ok[q] = 0; o.x[q] = NaN; o.y[q] = NaN; continue; }
      var gq = c3TmTanCorr(tm.tan, t.x, t.y); o.ok[q] = 1; o.x[q] = t.x + gq[0] + tm.res[i][0]; o.y[q] = t.y + gq[1] + tm.res[i][1];
   }
   return o;
}
// Los centros de los cúmulos en T (heliocéntrico ICRS, pc): de la tabla con «Galactic orbits», si no con el mismo modelo que sus miembros
// (las rectas y los epiciclos son lineales en el estado: el centro de la media es la media de las posiciones).
function c3TmClusterCentres(tm, T) {
   var cls = tm.cls || [], out = [];
   for (var c = 0; c < cls.length; ++c) {
      var e = c3TmClusterStateAtPhoto(tm, c);
      out.push((T === 0) ? e : (tm.model === "galactic" && tm.orbit && tm.orbit.nc === cls.length) ? c3TmClusterOrbitAt(tm, c, T) : c3TmPropagate(e, T, tm.model));
   }
   return out;
}

// UN INSTANTE: T = años desde la FOTO (0 = la foto). Devuelve { x: Float64Array, y, pc, ok: Uint8Array } en el orden de
// `tm.idx` (pixel de la imagen y distancia en pc). `out` (opcional) se reutiliza.
// (2-nov-2026) Con cúmulos (tm.cls), además: esc (Uint8Array: 0 = no cuenta —no es miembro de uno con r_J, o ya estaba fuera de r_J en la foto—,
// 1 = dentro de r_J, 2 = escapada —estaba dentro en la foto y ahora no—, 3 = su cúmulo aún no había nacido) y clStat = [ { n, bound, esc, unborn } ]
// en el orden de tm.cls (n = los que estaban dentro en la foto).
var C3_TM_UNBORN = true;          // costura del rojo de la decisión 3A: false = los miembros se pintan también antes de la edad del cúmulo
function c3TmAt(tm, T, out) {
   var n = tm.n, o = out || { x: new Float64Array(n), y: new Float64Array(n), pc: new Float64Array(n), ok: new Uint8Array(n), ra: new Float64Array(n), dec: new Float64Array(n) };
   var tt = tm.epochYears + T, sun = tm.sun, cls = tm.cls || [], nc = cls.length, cen = (nc > 0) ? c3TmClusterCentres(tm, T) : null;
   if (nc > 0) {
      if (!o.esc || o.esc.length !== n) o.esc = new Uint8Array(n);
      o.clStat = [];
      for (var c0 = 0; c0 < nc; ++c0) o.clStat.push({ n: 0, bound: 0, esc: 0, unborn: (C3_TM_UNBORN === true && cls[c0].ageYr !== null && T < -cls[c0].ageYr) });
   }
   var coneOn = (C3_TM_CONE === true && tm.err && tm.err.length === n);
   if (coneOn && (!o.cone || o.cone.length !== n)) o.cone = new Float32Array(n);
   if (!coneOn) o.cone = null;
   for (var i = 0; i < n; ++i) {
      // (lo de la foto es con la recta de siempre —la epoca de la foto esta a pocos años de J2016—; lo demas, con el modelo elegido)
      var e = c3TmPropagate(tm.st0[i], tm.epochYears, "linear");
      // (con el LSR la camara se mueve con el LSR desde el instante de la foto: se suma el movimiento peculiar del Sol)
      if (tm.lsr) { e.vx += sun[0]; e.vy += sun[1]; e.vz += sun[2]; }
      // (A7: con «Galactic orbits» y la tabla de orbitas hecha, de la tabla: estrella y Sol integrados en el potencial)
      var p = (T === 0) ? e : (tm.model === "galactic" && tm.orbit) ? c3TmOrbitAt(tm, i, T) : c3TmPropagate(e, T, tm.model);
      var k = c3TmSky(p.x, p.y, p.z);
      o.pc[i] = k.d; o.ra[i] = k.ra; o.dec[i] = k.dec;
      if (nc > 0) {
         var ck = tm.clOf[i];
         if (ck < 0) o.esc[i] = 0;
         else {
            var S = o.clStat[ck], C = cls[ck];
            if (S.unborn) { o.esc[i] = 3; ++S.n; }
            else if (!(C.rJ > 0) || !C.in0[C.memIx[i]]) o.esc[i] = 0;
            else { ++S.n; var ex = p.x - cen[ck].x, ey = p.y - cen[ck].y, ez = p.z - cen[ck].z, out2 = (ex * ex + ey * ey + ez * ez > C.rJ * C.rJ); o.esc[i] = out2 ? 2 : 1; if (out2) ++S.esc; else ++S.bound; }
         }
      }
      // (decisión 5a) el cono: x ≥ 1, su sitio en T ya no se sabe (ver c3TmConeX)
      if (coneOn) o.cone[i] = (T === 0) ? 0 : c3TmConeX(tm, i, e, p, T);
      var q = tm.tan ? c3TmTan(tm.tan, k.ra, k.dec) : null;
      if (q === null) { o.ok[i] = 0; o.x[i] = NaN; o.y[i] = NaN; continue; }
      var gq = c3TmTanCorr(tm.tan, q.x, q.y);
      o.ok[i] = 1; o.x[i] = q.x + gq[0] + tm.res[i][0]; o.y[i] = q.y + gq[1] + tm.res[i][1];
   }
   return o;
}

// UNA estrella (la i de `tm.idx`) en un instante: { x, y, pc, ok }. Lo que usan las estelas (pocas, varios instantes).
function c3TmAtOne(tm, i, T) {
   var e = c3TmPropagate(tm.st0[i], tm.epochYears, "linear");
   if (tm.lsr) { e.vx += tm.sun[0]; e.vy += tm.sun[1]; e.vz += tm.sun[2]; }
   var p = (T === 0) ? e : (tm.model === "galactic" && tm.orbit) ? c3TmOrbitAt(tm, i, T) : c3TmPropagate(e, T, tm.model), k = c3TmSky(p.x, p.y, p.z), q = tm.tan ? c3TmTan(tm.tan, k.ra, k.dec) : null;
   if (q === null) return { x: NaN, y: NaN, pc: k.d, ok: false };
   var gq = c3TmTanCorr(tm.tan, q.x, q.y);
   return { x: q.x + gq[0] + tm.res[i][0], y: q.y + gq[1] + tm.res[i][1], pc: k.d, ok: true };
}
// El estado de la estrella i en el instante de la FOTO (para el encuentro con el Sol, la convergencia…).
function c3TmStateAtPhoto(tm, i) {
   var e = c3TmPropagate(tm.st0[i], tm.epochYears, "linear");
   if (tm.lsr) { e.vx += tm.sun[0]; e.vy += tm.sun[1]; e.vz += tm.sun[2]; }
   return e;
}

// EL AVISO HONESTO del instante: { level: "ok" | "warn" | "beyond", code } (el texto lo pone la interfaz).
function c3TmValidity(T, model) {
   var a = Math.abs(T);
   // (A7: las orbitas integradas en MilkyWayPotential2022 —antes MWPotential2014— valen hasta ~100 Myr; mas alla, la barra, los brazos y los encuentros que el
   // potencial no tiene pesan cada vez mas: aviso; pasados 500 Myr, ni eso)
   if (model === "galactic") return (a > C3_TM.GALACTIC_MAX_YR) ? { level: "beyond", code: "galactic-beyond" } : (a > C3_TM.GALACTIC_WARN_YR) ? { level: "warn", code: "galactic-warn" } : (a > C3_TM.LINEAR_WARN_YR) ? { level: "ok", code: "galactic" } : { level: "ok", code: "" };
   if (a >= 10 * C3_TM.LINEAR_WARN_YR) return { level: "beyond", code: "linear-beyond" };
   if (a > C3_TM.LINEAR_WARN_YR) return { level: "warn", code: "linear-warn" };
   return { level: "ok", code: "" };
}

// LAS ESCALAS del deslizador (años a cada lado de «ahora») y el reparto del deslizador: SIMETRICO y con mas resolucion
// cerca de ahora (seno hiperbolico: el centro es casi lineal, los extremos crecen), para que ±100 años y ±100 000 se
// puedan elegir en la misma barra.
var C3_TM_RANGES = [1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9];
var C3_TM_STEPS = 2000;               // pasos del deslizador (la mitad a cada lado)
function c3TmSliderToYears(v, range) {
   var s = Math.max(-1, Math.min(1, (v - C3_TM_STEPS / 2) / (C3_TM_STEPS / 2))), K = 4;
   var y = range * (Math.sinh(K * s) / Math.sinh(K));
   return (Math.abs(y) < 1e-9) ? 0 : y;
}
function c3TmYearsToSlider(y, range) {
   var K = 4, s = Math.log(Math.abs(y) / range * Math.sinh(K) + Math.sqrt(Math.pow(Math.abs(y) / range * Math.sinh(K), 2) + 1)) / K;
   if (y < 0) s = -s;
   return Math.round(C3_TM_STEPS / 2 + Math.max(-1, Math.min(1, s)) * C3_TM_STEPS / 2);
}
// Un instante «redondo» para enseñarlo (sin decimales falsos): 3 cifras significativas.
function c3TmRoundYears(y) {
   var a = Math.abs(y);
   if (a < 1) return 0;
   var p = Math.pow(10, Math.max(0, Math.floor(Math.log(a) / Math.LN10) - 2));
   return Math.round(y / p) * p;
}

// ============================================================================
// BLOQUE F (20-oct-2026) — LO QUE NO ES UNA ESTRELLA. Encargo de Nino: «en la maquina del tiempo, ademas de animar las
// estrellas, ¿podrias animar las galaxias y lo que has detectado y segmentado?». La decision y su porque, en
// docs/maquina_del_tiempo.md §10. En corto:
//   · LO DE NUESTRA GALAXIA (nebulosas de Sharpless, planetarias, «otros» de SIMBAD, cumulos sin miembros pintados) SE
//     MUEVE con su propio movimiento en el espacio, el mismo vector y los mismos tres modelos que las estrellas
//     (`c3TmBodies` da un `tm` de la misma forma que `c3TmBuild`: c3TmAt, c3TmAtOne y c3TmOrbitTable valen tal cual).
//     De donde sale su movimiento (`c3TmBodyPick`): lo MEDIDO mas preciso de (a) SIMBAD —el del propio objeto—, (b) la
//     mediana de las estrellas de Gaia que tiene dentro y a su distancia (las que lo iluminan, su cumulo) y (c) el del
//     cumulo de catalogo que tiene dentro; si no hay nada medido, (d) SUPUESTO: la rotacion de la Galaxia en su sitio
//     (orbita circular en MilkyWayPotential2022), y se dice.
//   · GALAXIAS, CUASARES Y GRUPOS NO SE MUEVEN en el cielo. NO porque sea despreciable siempre (con 200 km/s de velocidad
//     transversal, una galaxia a 3 Mpc se mueve 14 µas/año: 0,014" en 1 Myr, pero 0,4° en 100 Myr y 4° en 1 000 Myr), sino porque
//     NO SE CONOCE: el movimiento propio de una galaxia solo esta medido para un puñado del Grupo Local, y a esas escalas ademas
//     orbitan en su grupo. No se inventa (docs §10). Lo que SI cambia y se enseña: (1) EL FRENTE DE LUZ —donde estaba, en el
//     instante elegido, la luz que forma esta foto (hacia atras) o hasta donde habra llegado la luz que sale hoy del Sol
//     (hacia delante)—, y (2) LA EXPANSION: la distancia propia de lo que va con el flujo de Hubble es a(t)·D_comovil.
//   Cosmologia: la MISMA que CabraShared (CP_SF: Planck 2018, ΛCDM plano, H0 = 67,4, Ωm = 0,315; lo comprueba el test).
// ============================================================================
var C3_TMF = {
   STARS_MIN: 5,          // (diseño) estrellas de Gaia con movimiento propio y distancia DENTRO de un objeto y a su distancia para dar el suyo
   RV_MIN: 3,             // (diseño) …y con velocidad radial de Gaia, para dar la suya (lo mismo que CLUSTER_RV_MIN)
   DIST_TOL: 0.15,        // (diseño) «a su distancia»: dentro del 15 % o de 2 sigmas de la distancia del objeto, lo que sea mas
   // Suelo sistematico del movimiento propio MEDIO de un grupo en Gaia (E)DR3: 0,026 mas/año (Vasiliev y Baumgardt 2021, MNRAS 505,
   // 5978 —el mismo trabajo del que sale el suelo de la paralaje media de CP_SF—). Se suma en cuadratura al error de la mediana.
   PM_FLOOR: 0.026,
   // Una galaxia «va con la expansion» si su c·z pasa de 1 200 km/s: 240 km/s de velocidad peculiar (CP_SF.VPEC_KMS, Brout et al.
   // 2022) son entonces menos del 20 % (CP_SF.MAX_FRACTION): la misma vara con que su z vale como distancia.
   HUBBLE_CZ: 1200,
   MAX_BODIES: 400        // (diseño) como mucho, tantos objetos se mueven (los de mas tamaño en la foto primero)
};
var C3_COSMO = { H0: 67.4, OM: 0.315, C_KMS: 299792.458, PC_M: 3.0856775814913673e16, YR_S: 31557600,
                 REF: "flat ΛCDM, H0 = 67.4 km/s/Mpc, Ωm = 0.315 (Planck 2018, A&A 641, A6)" };
// 1/H0 en años; c en pc/año; años luz por parsec
function c3CosmoTH() { return C3_COSMO.PC_M * 1e6 / 1000 / C3_COSMO.H0 / C3_COSMO.YR_S; }
function c3CosmoC() { return C3_COSMO.C_KMS * 1000 * C3_COSMO.YR_S / C3_COSMO.PC_M; }
function c3CosmoLyPc() { return C3_COSMO.PC_M / (C3_COSMO.C_KMS * 1000 * C3_COSMO.YR_S); }
function c3Asinh(x) { return Math.log(x + Math.sqrt(x * x + 1)); }
// LA EDAD DEL UNIVERSO cuando el factor de escala era a (forma CERRADA del ΛCDM plano sin radiacion, en años):
//     t(a) = 2 / (3 H0 √ΩΛ) · asinh( √(ΩΛ/Ωm) · a^1,5 )
function c3CosmoTimeOfA(a) { var OL = 1 - C3_COSMO.OM; return c3CosmoTH() * 2 / (3 * Math.sqrt(OL)) * c3Asinh(Math.sqrt(OL / C3_COSMO.OM) * Math.pow(Math.max(0, a), 1.5)); }
function c3CosmoAge() { return c3CosmoTimeOfA(1); }
// …y su inversa: a(t) = (Ωm/ΩΛ)^(1/3) · sinh( 1,5 √ΩΛ H0 t )^(2/3)
function c3CosmoAOfTime(t) {
   var OL = 1 - C3_COSMO.OM, x = 1.5 * Math.sqrt(OL) * Math.max(0, t) / c3CosmoTH(), s = 0.5 * (Math.exp(x) - Math.exp(-x));
   return Math.pow(C3_COSMO.OM / OL, 1 / 3) * Math.pow(s, 2 / 3);
}
// EL FACTOR DE ESCALA en el instante T de la maquina del tiempo (años desde HOY): 1 ahora, < 1 hacia atras.
function c3CosmoScale(T) { return (T === 0) ? 1 : c3CosmoAOfTime(c3CosmoAge() + T); }
// LO QUE RECORRE LA LUZ, en distancia COMOVIL (pc), entre los instantes cosmicos t1 < t2: χ = c ∫ dt / a(t).
// Se integra EN EL TIEMPO con la a(t) cerrada (y u = t^(1/3), que quita la singularidad de 1/a cerca de t = 0) por Simpson:
// un camino distinto del de CabraShared (que integra en a), para que el test compare dos metodos y no una copia de si misma.
function c3CosmoChiPc(t1, t2) {
   if (!(t2 > t1)) return 0;
   var u1 = Math.pow(t1, 1 / 3), u2 = Math.pow(t2, 1 / 3), n = 600, h = (u2 - u1) / n, s = 0;
   for (var i = 0; i <= n; ++i) { var u = u1 + i * h, f = 3 * u * u / c3CosmoAOfTime(u * u * u); s += f * ((i === 0 || i === n) ? 1 : (i % 2) ? 4 : 2); }
   return c3CosmoC() * s * h / 3;
}
// Las DOS CIFRAS de lo lejano, de su z: { lookbackYr (cuanto hace que salio la luz), comovingPc (a que distancia esta HOY),
// emittedPc (a que distancia estaba cuando la luz salio = comovil / (1 + z)), travelPc (c · lookback: lo que la luz «ha andado»;
// NO es la distancia de hoy), ageThenYr }. null si z ≤ 0.
function c3CosmoOfZ(z) {
   if (!(z > 0) || !isFinite(z)) return null;
   var a = 1 / (1 + z), t0 = c3CosmoAge(), te = c3CosmoTimeOfA(a), chi = c3CosmoChiPc(te, t0);
   return { z: z, lookbackYr: t0 - te, comovingPc: chi, emittedPc: chi * a, travelPc: (t0 - te) * c3CosmoC(), ageThenYr: te };
}
// ¿Va con la expansion? (c·z ≥ HUBBLE_CZ)
function c3CosmoInHubbleFlow(z) { return (z > 0) && isFinite(z) && C3_COSMO.C_KMS * z >= C3_TMF.HUBBLE_CZ; }
// EL FRENTE DE LUZ del instante T (años desde hoy):
//   · T < 0: donde estaba, en ese instante, la luz que llega HOY (la de esta foto): χ(t0 + T, t0). Lo que esta mas cerca que eso
//     aun NO habia emitido la luz de la foto; lo que esta mas lejos, ya: su luz iba de camino.
//   · T > 0: hasta donde habra llegado la luz que sale HOY del Sol: χ(t0, t0 + T). Lo de dentro ya la habra recibido.
// { pc (radio COMOVIL, el de la caja: lo lejano esta en la caja a su distancia comovil), properPc (el radio propio en ese
//   instante, a(t)·χ), lightPc (c·|T|) }. Por debajo de 10 Myr la expansion no llega al 0,07 %: χ = c·|T|.
function c3CosmoLightFront(T) {
   var a = Math.abs(T), c = c3CosmoC();
   if (a === 0) return { pc: 0, properPc: 0, lightPc: 0 };
   if (a < 1e7) return { pc: c * a, properPc: c * a, lightPc: c * a };
   var t0 = c3CosmoAge(), chi = (T < 0) ? c3CosmoChiPc(t0 + T, t0) : c3CosmoChiPc(t0, t0 + T);
   return { pc: chi, properPc: chi * c3CosmoAOfTime(t0 + T), lightPc: c * a };
}
// Lo que el frente de luz le dice a un objeto a distancia comovil `pc` en el instante T:
//   "not-left" (T < 0: la luz de la foto aun no habia salido de el) · "on-way" (T < 0: ya iba de camino) ·
//   "reached" (T > 0: la luz que sale hoy ya le ha llegado) · "not-reached" · "" (T = 0)
function c3CosmoLightState(pc, T, front) {
   if (T === 0 || !(pc > 0)) return "";
   var f = (front && front.pc >= 0) ? front.pc : c3CosmoLightFront(T).pc;
   return (T < 0) ? ((pc < f) ? "not-left" : "on-way") : ((pc < f) ? "reached" : "not-reached");
}

// LA VELOCIDAD de un estado dicha como movimiento propio y velocidad radial (la inversa de c3TmState):
//   { ra, dec (grados), d (pc), pmRa (mas/año, YA por cos dec), pmDec (mas/año), rv (km/s) }
function c3TmPmRv(s) {
   var d = Math.sqrt(s.x * s.x + s.y * s.y + s.z * s.z);
   if (!(d > 0)) return { ra: 0, dec: 0, d: 0, pmRa: 0, pmDec: 0, rv: 0 };
   var k = c3TmSky(s.x, s.y, s.z), a = k.ra * C3_TM.DEG, b = k.dec * C3_TM.DEG, ca = Math.cos(a), sa = Math.sin(a), cb = Math.cos(b), sb = Math.sin(b);
   var r = [cb * ca, cb * sa, sb], p = [-sa, ca, 0], q = [-sb * ca, -sb * sa, cb], K = C3_TM.KMS_PCYR;
   var vx = s.vx / K, vy = s.vy / K, vz = s.vz / K, vt = C3_TM.K_PM * d / 1000;
   return { ra: k.ra, dec: k.dec, d: d, rv: vx * r[0] + vy * r[1] + vz * r[2], pmRa: (vx * p[0] + vy * p[1] + vz * p[2]) / vt, pmDec: (vx * q[0] + vy * q[1] + vz * q[2]) / vt };
}
// LA MEDIANA DEL MOVIMIENTO de unas estrellas (las de un objeto): list = [ { pmRa, pmDec, rv } ] ->
//   { n, pmRa, pmDec, pmErr (el error de la mediana —1,2533 · sigma robusta / √n— con el suelo sistematico en cuadratura),
//     nRv, rv, rvErr } (null lo que no hay).
function c3TmMedian(v) { var a = v.slice().sort(function(p, q) { return p - q; }), n = a.length; return (n === 0) ? NaN : (n & 1) ? a[n >> 1] : 0.5 * (a[n / 2 - 1] + a[n / 2]); }
function c3TmRobustSigma(v, m) { var d = []; for (var i = 0; i < v.length; ++i) d.push(Math.abs(v[i] - m)); return 1.4826 * c3TmMedian(d); }
function c3TmStarsMotion(list) {
   var pa = [], pd = [], rv = [], i;
   for (i = 0; list && i < list.length; ++i) {
      var s = list[i];
      if (s && isFinite(s.pmRa) && isFinite(s.pmDec) && s.pmRa !== null && s.pmDec !== null) { pa.push(s.pmRa); pd.push(s.pmDec); }
      if (s && s.rv !== null && s.rv !== undefined && isFinite(s.rv)) rv.push(s.rv);
   }
   var out = { n: pa.length, pmRa: null, pmDec: null, pmErr: null, nRv: rv.length, rv: null, rvErr: null };
   if (pa.length >= 1) {
      var ma = c3TmMedian(pa), md = c3TmMedian(pd), n = pa.length, sa = c3TmRobustSigma(pa, ma), sd = c3TmRobustSigma(pd, md);
      var e = 1.2533 * Math.sqrt((sa * sa + sd * sd) / 2) / Math.sqrt(n);
      out.pmRa = ma; out.pmDec = md; out.pmErr = Math.sqrt(e * e + C3_TMF.PM_FLOOR * C3_TMF.PM_FLOOR);
   }
   if (rv.length >= 1) { var mr = c3TmMedian(rv); out.rv = mr; out.rvErr = 1.2533 * c3TmRobustSigma(rv, mr) / Math.sqrt(rv.length); }
   return out;
}
// DE DONDE SALE EL MOVIMIENTO de un objeto. `c` = { simbad, stars, cluster, assumed }, cada uno { pmRa, pmDec, pmErr, rv, rvErr,
// pmRef, rvRef } o null (`stars` con n y nRv: solo vale con STARS_MIN y RV_MIN). Para el movimiento propio y para la velocidad
// radial POR SEPARADO: lo MEDIDO con el error declarado mas pequeño (sin error declarado va detras de cualquiera que lo tenga; a
// igualdad, SIMBAD, luego las estrellas, luego el cumulo); si no hay nada medido, lo SUPUESTO (`assumed`: la rotacion de la Galaxia).
// Devuelve { pmRa, pmDec, pmErr, pmFrom, pmRef, rv, rvErr, rvFrom, rvRef, assumed (algo es supuesto), cands }.
function c3TmBodyPick(c) {
   var C = c || {}, order = ["simbad", "stars", "cluster"], out = { pmFrom: "assumed", rvFrom: "assumed", pmRa: 0, pmDec: 0, pmErr: null, rv: 0, rvErr: null, pmRef: "", rvRef: "", cands: C };
   function ok(k, what) {
      var q = C[k];
      if (!q) return false;
      if (k === "stars" && what === "pm" && !(q.n >= C3_TMF.STARS_MIN)) return false;
      if (k === "stars" && what === "rv" && !(q.nRv >= C3_TMF.RV_MIN)) return false;
      return (what === "pm") ? (q.pmRa !== null && q.pmDec !== null && q.pmRa !== undefined && isFinite(q.pmRa) && isFinite(q.pmDec)) : (q.rv !== null && q.rv !== undefined && isFinite(q.rv));
   }
   function best(what) {
      var b = null, be = Infinity;
      for (var i = 0; i < order.length; ++i) {
         if (!ok(order[i], what)) continue;
         var e = (what === "pm") ? C[order[i]].pmErr : C[order[i]].rvErr, ee = (e > 0 && isFinite(e)) ? e : Infinity;
         if (b === null || ee < be) { b = order[i]; be = ee; }
      }
      return b;
   }
   var bp = best("pm"), br = best("rv"), A = C.assumed || { pmRa: 0, pmDec: 0, rv: 0, ref: "" };
   if (bp !== null) { out.pmFrom = bp; out.pmRa = C[bp].pmRa; out.pmDec = C[bp].pmDec; out.pmErr = C[bp].pmErr; out.pmRef = String(C[bp].pmRef || ""); }
   else { out.pmRa = A.pmRa; out.pmDec = A.pmDec; out.pmRef = String(A.ref || ""); }
   if (br !== null) { out.rvFrom = br; out.rv = C[br].rv; out.rvErr = C[br].rvErr; out.rvRef = String(C[br].rvRef || ""); }
   else { out.rv = A.rv; out.rvRef = String(A.ref || ""); }
   out.assumed = (out.pmFrom === "assumed" || out.rvFrom === "assumed");
   return out;
}
// LOS OBJETOS QUE SE MUEVEN, con la misma forma que `c3TmBuild` (por eso c3TmAt, c3TmAtOne y c3TmOrbitTable les valen tal cual).
// `list` = [ { ra, dec (grados), pc, x, y (su pixel en la foto: el centro de lo que se ve de el), motion (de c3TmBodyPick) } ];
// opts = { tan, model, lsr }. Su posicion es la de AHORA (la foto): epochYears 0. El residuo (su pixel menos la proyeccion de su
// ra, dec) es constante: una nebulosa cuyo centro de catalogo cae fuera de la foto mueve lo que se ve de ella como un todo.
// `idx[i]` = su indice en `list`; `pos[indice en list]` = i.
function c3TmBodies(list, opts) {
   var o = opts || {}, tm = { n: 0, idx: [], st0: [], rvFrom: [], pmFrom: [], rvKms: [], res: [], dPc: [], motion: [], counts: { measured: 0, partial: 0, assumed: 0 },
                              epochYears: 0, tan: o.tan || null, model: (o.model === "galactic") ? "galactic" : "linear", lsr: (o.lsr === true), sun: c3TmSunIcrs(), bodies: true, clusterRv: {} };
   for (var i = 0; list && i < list.length; ++i) {
      var b = list[i], m = b ? b.motion : null;
      if (!b || !(b.pc > 0) || !m || !isFinite(b.ra) || !isFinite(b.dec)) continue;
      var st0 = c3TmState(b.ra, b.dec, b.pc, m.pmRa, m.pmDec, m.rv), rx = 0, ry = 0;
      if (tm.tan && typeof b.x === "number" && isFinite(b.x)) {
         var q = c3TmTan(tm.tan, b.ra, b.dec);
         if (q !== null) { var g0 = c3TmTanCorr(tm.tan, q.x, q.y); rx = b.x - q.x - g0[0]; ry = b.y - q.y - g0[1]; }
      }
      tm.idx.push(i); tm.st0.push(st0); tm.rvFrom.push(m.rvFrom); tm.pmFrom.push(m.pmFrom); tm.rvKms.push(m.rv); tm.res.push([rx, ry]); tm.dPc.push(b.pc); tm.motion.push(m);
      ++tm.counts[(m.pmFrom === "assumed" && m.rvFrom === "assumed") ? "assumed" : m.assumed ? "partial" : "measured"];
   }
   tm.n = tm.idx.length;
   tm.pos = {};
   for (i = 0; i < tm.n; ++i) tm.pos[tm.idx[i]] = i;
   return tm;
}
