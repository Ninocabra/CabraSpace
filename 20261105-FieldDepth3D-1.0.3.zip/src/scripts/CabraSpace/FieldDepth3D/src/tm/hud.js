// ============================================================================
// tm/hud.js — EL ROTULO del 3D: la maquina del tiempo y el polvo, dichos en llano (Cabra3D, 15-oct-2026)
// ----------------------------------------------------------------------------
// Liston de Nino: «el rigor cientifico y la simplicidad de una divulgacion que entienda cualquiera, y a la vez
// profunda». Por eso el rotulo tiene dos pisos: arriba, UNA FRASE LLANA de que se esta viendo, el instante y,
// si lo hay, el aviso de validez (siempre a la vista); debajo, plegado, lo tecnico con sus fuentes («▸ details»:
// un clic en el rotulo lo abre o lo cierra). Las palabras tecnicas (Myr, pc, velocidad radial, LSR, apex, AV) se
// explican en el tooltip del rotulo. Nada se corta: las lineas se PARTEN al ancho del rotulo.
// Va arriba a la derecha del dibujo (a la izquierda esta la boca de la caja, con su rotulo) y las placas lo evitan
// (costura en `_drawDist`). Lo pinta `renderAt` (envuelto): tambien sale en lo exportado. ES5.
// ============================================================================

// (20-oct, encargo de Nino: el rotulo tapaba el 3D. Mas estrecho —un tercio del lienzo, plegado; algo mas abierto— y algo
// translucido; la escala del polvo ya NO va dentro: es una tira propia (tm/dust_ui.js, `c3DustLegPaint`).)
var C3_HUD = { W: 0.34, W_OPEN: 0.42, ALPHA: 0.86 };
// (tarea H9, 21-oct: en un lienzo MUY ancho —pantalla completa a 5 120 px— el rotulo, la leyenda y los textos, a la escala de la interfaz,
// eran un sello. El dibujo del lienzo —`_render`— y la leyenda de la foto crecen con el ancho a partir de 1 700 px por unidad de escala,
// hasta el doble de la escala de la interfaz. Todo a la vez: el rotulo y la leyenda no crecen solos)
function c3BoxScale(w, sc) { var s0 = (sc > 0) ? sc : 1; return Math.min(2 * s0, Math.max(s0, w / 1700)); }
function c3HudMaxW(w, open, sc) {
   // (un tercio del lienzo, pero en uno estrecho no menos de ~230 px de interfaz —con menos el texto se parte en renglones de tres palabras—)
   var f = Math.round(w * (open ? C3_HUD.W_OPEN : C3_HUD.W)), floor = Math.min(Math.round(w * 0.6), Math.round(230 * (sc || 1)));
   return Math.max(f, floor);
}

// «dentro de 100 000 años» / «hace 60 000 años» / «dentro de 1,2 millones de años» (la cifra entera, en palabras)
function c3TmTimeWords(T) {
   var y = c3TmRoundYears(T), a = Math.abs(y);
   if (a === 0) return optT("now: the photo");
   var n = (a >= 1e6) ? format(optT("%s million years"), cpSvDec(String(Math.round(a / 1e4) / 100).replace(/\.0+$/, ""))) : format(optT("%s years"), cpSvGroup(a));
   return (y > 0) ? format(optT("in %s"), n) : format(optT("%s ago"), n);
}

// La edad de un cúmulo en palabras: «4,8 Ma», «120 Ma», «1,2 Ga»
function c3TmAgeText(yr) {
   if (!(yr > 0)) return "?";
   var my = yr / 1e6;
   return (my >= 1000) ? cpSvFx(my / 1000, 1) + " " + optT("Gyr") : (my >= 100) ? cpSvGroup(Math.round(my)) + " " + optT("Myr") : cpSvFx(my, 1) + " " + optT("Myr");
}
// (decisión 4) lo que se añade al texto del movimiento si el potencial lleva la barra (CabraShared/csh_galdyn.js)
function c3TmBarWords() {
   if (typeof cshGdBarOn !== "function" || !cshGdBarOn()) return "";
   return " " + format(optT("With the rotating bar (Dehnen 2000 quadrupole; pattern speed %s km/s/kpc, angle %s°, strength %s)."), cpSvFx(CSH_GD.BAR.OB, 0), cpSvFx(CSH_GD.BAR.PHIB_DEG, 0), cpSvFx(CSH_GD.BAR.ALPHA, 2));
}
// (2-nov-2026, Q4) de dónde salió el error del movimiento propio de las estrellas que se mueven (tm/timemachine.js c3TmErrOf, pmSrc):
// el de cada estrella (afinado en red: e_pmRA, e_pmDE de Gaia DR3) o el típico de Gaia para su magnitud. `c` = tm.pmErrCounts.
function c3TmPmErrWords(c) {
   var own = (c && c.gaia > 0) ? c.gaia : 0, other = c ? (c.g || 0) + (c.tier || 0) + (c.none || 0) : 0;
   if (own > 0 && other === 0) return optT("each star's own Gaia error");
   if (own > 0) return format(optT("each star's own Gaia error for %s of them; for the other %s, the typical Gaia error for its magnitude"), cpSvGroup(own), cpSvGroup(other));
   return optT("the typical Gaia error for its magnitude: the local database has no per-star errors and the network refinement did not bring them");
}
// LAS LINEAS: [ { k: "caps" | "big" | "plain" | "small" | "warn" | "error" | "idea" | "fold", t } ]
CPStarfieldDock.prototype._hudLines = function(full) {
   var st = this.state, L = [];
   if (!st || this.mode !== "dist") return L;
   var open = !!(this.tm && this.tm.hudOpen), tmOn = !!(this.tm && this.tm.t !== 0), dustOn = !!(this.dust && this.dust.on && st.dust && st.dust.ok);
   if (tmOn) {
      var tm = this.tm, d = this._tmData(st);
      if (d) {
         var y = c3TmCalendarYear(st, tm.t);
         L.push({ k: "caps", t: optT("TIME MACHINE") });
         L.push({ k: "big", t: c3TmTimeWords(tm.t) + (y.length ? "  ·  " + y : "") });
         L.push({ k: "plain", t: (tm.t > 0) ? optT("This is how this patch of sky will look: each star has moved with its own speed, and the nearest ones have moved the most.")
                                           : optT("This is how this patch of sky looked: each star was where its speed brings it back to, and the nearest ones have moved the most.") });
         var lv = c3TmValidity(tm.t, this._tmModelName());
         if (lv.code !== "" && lv.code !== "galactic") L.push({ k: "warn", t: c3TmValidityText(lv.code) });          // (V9: ambar, no rojo)
         // (2-nov-2026, decisiones 2 y 3A de Nino) UNA LÍNEA POR CÚMULO: cuántos de sus miembros siguen dentro de su radio de Jacobi y cuántos se han
         // escapado (grises), o que aún no se había formado (sus miembros no se pintan). Los números, del instante (c3TmAt: clStat).
         var Pc = this._tmAt(d, tm.t), CL = d.tm.cls || [], ci2;
         for (ci2 = 0; Pc && Pc.clStat && ci2 < CL.length && ci2 < 3; ++ci2) {
            var S2 = Pc.clStat[ci2], C2 = CL[ci2];
            // («idea» y no «plain»: el rótulo corto —sin sitio— quita las «plain» y esta línea es de las que tienen que verse)
            if (S2.unborn) L.push({ k: "idea", t: format(optT("%s · not yet formed (age ≈ %s, Hunt & Reffert 2023): its stars are not drawn"), C2.name, c3TmAgeText(C2.ageYr)) });
            else if (C2.rJ > 0 && S2.n > 0) { var pb = Math.round(100 * S2.bound / S2.n); L.push({ k: "idea", t: format(optT("%s · %s %% still bound, %s %% escaped"), C2.name, String(pb), String(100 - pb)) }); }
         }
         // (decisión 5a; Q3 = A, 2-nov, noche) las inciertas: su sitio en este instante no se sabe; siguen pintadas al 25 % (no se esconden)
         var mdlU = (d.models) ? d.models[Object.keys(d.models)[0]] : null, nUncIn = (typeof this._tmInUncertain === "function") ? this._tmInUncertain() : 0;
         if (mdlU && mdlU.tmUnknown > 0) L.push({ k: "plain", t: format(optT("%s stars uncertain, drawn faint (25 %%): where they are at this instant is not known to better than a tenth of the photo"), cpSvGroup(mdlU.tmUnknown + nUncIn)) });
         else if (nUncIn > 0) L.push({ k: "plain", t: format(optT("%s stars uncertain, drawn faint (25 %%): where they are at this instant is not known to better than a tenth of the photo"), cpSvGroup(nUncIn)) });
         if (open && d.tm.err && d.tm.err.length) L.push({ k: "small", t: format(optT("A star dims down to a quarter when its error passes %s° in the sky (a tenth of the photo's short side) or a quarter of its distance in depth, from its Gaia errors: distance interval, proper motion (%s), radial velocity (30 km/s assumed without one)."), cpSvFx(d.tm.coneDeg, 2), c3TmPmErrWords(d.tm.pmErrCounts)) });
         // (Q4) y la de la nube dice el error del movimiento propio de ESA estrella y de dónde salió
         if (open && d.cloud && typeof this._tmCloudKey === "function" && d.cloud.key === this._tmCloudKey(d)) L.push({ k: "small", t: format(optT("The amber cloud: %s possible places of the chosen star at this instant, from its Gaia errors (Monte Carlo; proper motion ± %s mas/yr, %s)."), cpSvGroup(d.cloud.n), cpSvFx(d.cloud.spm || 0, 3),
                                                                                                                   (d.cloud.pmSrc === "gaia") ? optT("its own") : optT("typical for its magnitude")) });
         if (tm.autoOrbits && open) L.push({ k: "small", t: format(optT("«Galactic orbits» chosen by itself for a range of 10 Myr or more; «%s» comes back below."), c3TmMotionWord(tm.motionUser)) });
         if (open) {
            L.push({ k: "small", t: (tm.motion === "galactic") ? (optT("Motion: calculated orbits in a model of the Milky Way, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), integrated star by star and for the Sun.") + c3TmBarWords())
                                  : (tm.motion === "lsr") ? optT("Motion: straight lines, seen from the Local Standard of Rest (without the Sun's own drift: Schönrich et al. 2010).")
                                  : optT("Motion: straight lines in space, seen from the Sun (valid to about 1 million years).") });
            var c = d.tm.counts;
            L.push({ k: "small", t: format(optT("Of the %s stars that move: radial velocity from Gaia DR3 %s · from their cluster %s (members without one better than 1 km/s) · unknown %s (hollow dots: depth path uncertain)"), cpSvGroup(d.tm.n), cpSvGroup(c.gaia), cpSvGroup(c.cluster), cpSvGroup(c.none)) });
            var mdl = (d.models) ? d.models[Object.keys(d.models)[0]] : null;
            if (mdl && mdl.tmGone > 0) L.push({ k: "small", t: format(optT("%s of them have left the frame of the photo"), cpSvGroup(mdl.tmGone)) });
            // (26-oct-2026, pendiente 11: tm/tm_incoming.js) las que han ENTRADO desde fuera de la foto: cuadrados abiertos, no estan en la foto
            var nIn = (typeof this._tmInCount === "function") ? this._tmInCount() : 0;
            if (nIn > 0) L.push({ k: "small", t: format(optT("□ %s stars have come in from outside the photo (Gaia, as bright as the ones that move here; they are not in your photo)"), cpSvGroup(nIn)) });
            var capIn = (nIn > 0 && typeof this._tmInCappedDeg === "function") ? this._tmInCappedDeg() : 0;
            if (capIn > 0) L.push({ k: "small", t: format(optT("(searched up to %s° outside the photo: the ones coming from farther away are not drawn)"), cpSvDec(String(Math.round(capIn)))) });
            if (full) {
               var info = this._tmInfo(d), i;
               for (i = 0; i < info.clusters.length && i < 2; ++i) {
                  var q = info.clusters[i], bits = [];
                  if (q.apex) bits.push(format(optT("heading to RA %s, Dec %s (its apex, ±%s°)"), cpAnnotSexRA(q.apex.ra).substring(0, 5).replace(" ", "h ") + "m", cpAnnotSexDec(q.apex.dec).substring(0, 3) + "°", (q.apexErr < 0.1 ? "<0.1" : cpSvFx(q.apexErr, 1))) +
                                        ((q.basis === "pm") ? " " + optT("(sky only: no radial velocity)") : ""));
                  if (q.lit) bits.push(format(optT("literature: RA %s, Dec %s (%s)"), cpAnnotSexRA(q.lit.ra).substring(0, 5).replace(" ", "h ") + "m", cpAnnotSexDec(q.lit.dec).substring(0, 3) + "°", q.lit.ref));
                  if (q.compactPast) bits.push(format(optT("most compact %s (%s pc across)"), c3TmTimeWords(q.best.t), cpSvFx((2 * q.best.size), 1)));
                  var sz = c3HudClusterSize(this._tmAt(d, tm.t), q.mem);
                  if (sz > 0) bits.push(format(optT("%s pc across now, %s pc at this instant"), (2 * q.sizeNow).toFixed(0), (2 * sz).toFixed(0)));
                  if (bits.length) L.push({ k: "idea", t: q.name + ": " + bits.join(" · ") });
               }
               // (2-nov, decisión 2) la gravedad propia ya está: lo que dice el rótulo es cómo y con qué
               for (var cj = 0; cj < CL.length && cj < 3; ++cj) {
                  var Cc = CL[cj];
                  if (Cc.rJ > 0) L.push({ k: "small", t: format(optT("%s: Jacobi radius %s pc = the tidal radius rt of Hunt & Reffert 2023 (%s° at %s pc); mass ≈ %s M☉, the one that makes rt its Jacobi radius in MilkyWayPotential2022 at R = %s kpc; a rigid Plummer sphere of scale %s pc (their r50) holds its stars, with «Galactic orbits». Escaped = farther than the Jacobi radius from the centre (grey)."),
                                                                     Cc.name, cpSvFx(Cc.rJ, 1), cpSvFx(Cc.rtDeg, 3), cpSvGroup(Math.round(Cc.dPc)), cpSvGroup(Math.round(Cc.M)), cpSvFx(Cc.Rgc / 1000, 2), cpSvFx(Cc.a, 1)) });
                  if (Cc.ageYr !== null) L.push({ k: "small", t: format(optT("%s: age ≈ %s (log age %s, Hunt & Reffert 2023): before that its stars are not drawn."), Cc.name, c3TmAgeText(Cc.ageYr), cpSvFx(Cc.logAge, 2)) });
                  // (2-nov) la deconvolución de lo que se mueve cada miembro (tm/timemachine.js c3TmClusterDeconv): cuánto de lo medido se queda
                  // (Q1, 2-nov, noche) si el ruido de Gaia lo explicaba todo, el suelo virial: lo que le da su propia gravedad
                  if (Cc.rJ > 0 && Cc.ktFloor === true && Cc.sv > 0) L.push({ k: "small", t: format(optT("%s: Gaia's errors explain most of what its members seem to depart on the sky, so they keep at least the internal motion its own gravity gives: %s km/s (virial dispersion of a Plummer sphere of its mass and r50); the centre moves with their median."), Cc.name, cpSvFx(Cc.sv / C3_TM.KMS_PCYR, 2)) });
                  else if (Cc.rJ > 0 && typeof Cc.kt === "number") L.push({ k: "small", t: format(optT("%s: its members move with the cluster plus %s %% of how far Gaia says they depart from it on the sky (the rest is explained by Gaia's errors); the centre moves with their median."), Cc.name, String(Math.round(100 * Cc.kt))) });
               }
               if (tm.motion === "galactic" && CL.length) L.push({ k: "small", t: optT("A cluster's own gravity is a rigid Plummer sphere, not every star pulling on every other; without the molecular clouds that shake real clusters, it holds them together somewhat too long (real ones dissolve in 0.1–0.25 Gyr).") });
               if (info.closest !== null && info.closest.d < 30) {
                  var cc = info.closest, cs = st.result.stars[cc.star], cra = cpAnnotSexRA(cs.ra).substring(0, 5).replace(" ", "h ") + "m", cde = cpAnnotSexDec(cs.dec).substring(0, 3) + "°";
                  L.push({ k: "idea", t: format((cc.t < 0) ? optT("Of the stars of this photo, the one that came closest to the Sun: G = %s (RA %s, Dec %s), %s away, %s") : optT("Of the stars of this photo, the one that will come closest to the Sun: G = %s (RA %s, Dec %s), %s away, %s"),
                                               (cc.g !== null) ? cpSvFx(cc.g, 1) : "?", cra, cde, this._dist(cc.d), c3TmTimeWords(cc.t)) });
               }
            }
         }
      }
   }
   if (dustOn) {
      var D = st.dust, ly = D.layer, thick = !!(ly && ly.dE * C3_DUST.AV_PER_E > 0.05);
      L.push({ k: "caps", t: optT("DUST IN THE BEAM") });
      // (plegado, UNA frase corta; abierto, la explicacion entera)
      if (!open) L.push({ k: "plain", t: thick ? format(optT("Interstellar dust (the sand-brown haze): its thickest layer, at %s, dims what is behind it by about %s mag; all of it together, by about %s mag."), this._dist(ly.d), cpSvFx((ly.dE * C3_DUST.AV_PER_E), 1), cpSvFx((D.eMedian * C3_DUST.AV_PER_E), 1))
                                              : optT("Interstellar dust (the sand-brown haze): there is little of it in this direction; the photo looks through clean space.") });
      else L.push({ k: "plain", t: thick ? format(optT("The sand-brown haze is interstellar dust. Its thickest layer, at %s, dims what is behind it by about %s magnitudes in visible light; all of it together, by about %s. Where it is thick, it is what makes the dark patches of a photo."), this._dist(ly.d), cpSvFx((ly.dE * C3_DUST.AV_PER_E), 1), cpSvFx((D.eMedian * C3_DUST.AV_PER_E), 1))
                                                 : optT("The sand-brown haze is interstellar dust. There is little of it in this direction: the photo looks through clean space.") });
      // (encargo de Nino, 15-oct: su PROFUNDIDAD —de que distancia a que distancia va cada capa y cuanto apaga— y su DENSIDAD; la escala de
      // color de la densidad, en la tira de abajo)
      var LY = st.dustLayers || [];
      if (open && LY.length) {
         L.push({ k: "small", t: format(optT("Where it is (along the line of sight, median of the field): %s"), (LY.length === 1) ? optT("one layer") : format(optT("%s layers"), String(LY.length))) });
         for (var li = 0; li < LY.length && li < 4; ++li)
            L.push({ k: "idea", t: format(optT("from %s to %s: %s, it dims %s mag"), this._dist(LY[li].from), this._dist(LY[li].to), c3HudDustWord(LY[li].cls), cpSvFx(LY[li].dAV, 1)) });
         if (LY.length > 4) L.push({ k: "small", t: format(optT("and %s thinner layers more"), String(LY.length - 4)) });
      } else if (open) L.push({ k: "small", t: optT("No layer of dense dust: what there is, is spread thin along the way.") });
      if (open) {
         L.push({ k: "small", t: format(optT("Across the field, up to %s: AV ≈ %s (median) and up to %s (darkest line of sight); AV = 1 means 2.5 times fainter."), this._dist(C3_DUST.R_OUT), cpSvFx((D.eMedian * C3_DUST.AV_PER_E), 2), cpSvFx((D.eMax * C3_DUST.AV_PER_E), 2)) });
         L.push({ k: "small", t: format(optT("Map: Edenhofer et al. 2024, 14' resolution, from %s to %s; beyond, no data. AV = 2.8 × E (their extinction curve)."), this._dist(C3_DUST.R_IN), this._dist(C3_DUST.R_OUT)) });
         if (st.dustTeff && st.dustTeff.cmp && isFinite(st.dustTeff.cmp.a0)) L.push({ k: "small", t: format(optT("Gaia's own extinction of those stars (GSP-Phot A0, ≈ AV) / map = %s (the conversion used is 2.8)"), cpSvFx(st.dustTeff.cmp.a0, 2)) });
         // (29-oct; decision P1(b) de Nino) la comprobacion por color da la PENDIENTE de E_color frente a E_mapa (Theil-Sen, dust_ui.js `_dustCompare`) con su
         // intervalo del 5 al 95 % y el DESFASE (la ordenada), y lo esperado sale de C3_DUST.EBPRP_PER_E (1,28). La razon E_color/E_mapa ya NO se muestra: el desfase
         // aditivo de la Teff de GSP-Phot la bajaba a ~1,0 (dos cifras compitiendo en el rotulo; sigue en el objeto `cmp` solo para los registros). Solo las estrellas de
         // G < 15 (C3_DUSTUI.CMP_GMAX). Sin el minimo de estrellas o de rango de E (C3_DUSTUI.CMP_N_MIN, CMP_RANGE_MIN) se avisa en vez de dar la cifra.
         var cm = st.dustTeff ? st.dustTeff.cmp : null;
         if (cm) {
            var gmTxt = String(cm.gMax || C3_DUSTUI.CMP_GMAX);
            if (cm.ok) {
               L.push({ k: "small", t: format(optT("Check with the colours of %s stars of the photo with G < %s: measured reddening vs map, slope = %s (between %s and %s; expected ≈ %s)"), cpSvGroup(cm.n), gmTxt,
                                                 cpSvFx(cm.slope, 2), cpSvFx(cm.lo, 2), cpSvFx(cm.hi, 2), cpSvFx(C3_DUST.EBPRP_PER_E, 2)) });
               L.push({ k: "small", t: format(optT("Colour offset (temperature scale of GSP-Phot): %s mag"), ((cm.offset < 0) ? "−" : "+") + cpSvFx(Math.abs(cm.offset), 2)) });
            } else if (cm.why === "n") {
               L.push({ k: "small", t: format(optT("No check with the colours: only %s stars of the photo with G < %s have a Gaia temperature and dust in front; it needs at least %s to give the slope."), cpSvGroup(cm.n), gmTxt, cpSvGroup(cm.nMin)) });
            } else {
               L.push({ k: "small", t: format(optT("No check with the colours: the %s stars of the photo with G < %s have almost the same dust in front (spread of AV %s mag; it needs at least %s mag): without spread there is no slope to measure."), cpSvGroup(cm.n), gmTxt,
                                                 cpSvFx((cm.eRange * C3_DUST.AV_PER_E), 2), cpSvFx((cm.rangeMin * C3_DUST.AV_PER_E), 2)) });
            }
         }
      }
   }
   if (L.length) L.push({ k: "fold", t: open ? optT("▾ fewer details") : optT("▸ details and sources (click)") });
   // (23-oct, noche; revisión visual: «+3.19 Myr», «−93.5 Myr» y las cifras de este rótulo salían con punto en castellano. TODA cifra
   //  pintada lleva la coma del idioma: cpSvDec —CabraShared/csh_view.js— solo cambia «dígito.dígito», y solo en castellano)
   if (typeof cpSvDec === "function") for (var di = 0; di < L.length; ++di) if (typeof L[di].t === "string") L[di].t = cpSvDec(L[di].t);
   return L;
};
// «polvo tenue» / «denso» / «muy denso»
function c3HudDustWord(cls) { return (cls === "very dense") ? optT("very dense dust") : (cls === "dense") ? optT("dense dust") : optT("thin dust"); }
// El radio cuadratico medio (pc, en 3D) de unos miembros en las posiciones `P` de un instante (las de c3TmAt).
function c3HudClusterSize(P, mem) {
   var k = Math.PI / 180, mx = 0, my = 0, mz = 0, n = 0, pts = [], i;
   for (i = 0; mem && i < mem.length; ++i) {
      var j = mem[i];
      if (!P.ok[j]) continue;
      var c = Math.cos(P.dec[j] * k), p = [P.pc[j] * c * Math.cos(P.ra[j] * k), P.pc[j] * c * Math.sin(P.ra[j] * k), P.pc[j] * Math.sin(P.dec[j] * k)];
      pts.push(p); mx += p[0]; my += p[1]; mz += p[2]; ++n;
   }
   if (n < 3) return 0;
   mx /= n; my /= n; mz /= n;
   var s2 = 0;
   for (i = 0; i < pts.length; ++i) s2 += Math.pow(pts[i][0] - mx, 2) + Math.pow(pts[i][1] - my, 2) + Math.pow(pts[i][2] - mz, 2);
   return Math.sqrt(s2 / n);
}
CPStarfieldDock.prototype._hudGlossary = function() {
   return optT("Words: Myr = a million years. ly = light-year (9.5 million million km); pc = parsec = 3.26 light-years. Radial velocity = how fast a star comes towards us or goes away, measured by Gaia from its spectrum; without it the star's path in depth is unknown (hollow dots). LSR = Local Standard of Rest, a point that circles the Galaxy beside the Sun; seen from it, the Sun's own drift disappears. Apex = the point of the sky a group of stars is heading to. AV = how much dust dims visible light, in magnitudes (1 = 2.5 times fainter).");
};

function c3HudFonts(sc) {
   // (20-oct: mas pequeño —el rotulo no es el protagonista—: el instante en el cuerpo del titulo, la frase en el del texto)
   return { sp: cpCapsSpacing(CP_ATLAS.size.label * sc), caps: cpFont("text", CP_ATLAS.size.label * sc, true, false, cpCapsSpacing(CP_ATLAS.size.label * sc)), big: cpFont("display", CP_ATLAS.size.title * sc),
            plain: cpFont("display", CP_ATLAS.size.body * sc, false, true), small: cpFont("text", CP_ATLAS.size.label * sc) };
}
// (el ancho de una linea: `Font.width` no cuenta el espaciado de las versalitas)
function c3HudWidth(F, k, t) { var f = c3HudFontOf(F, k); return f.width(t) + ((k === "caps" || k === "fold") ? Math.max(0, String(t).length - 1) * (F.sp || 0) : 0); }
function c3HudFontOf(F, k) { return (k === "caps" || k === "fold") ? F.caps : (k === "big") ? F.big : (k === "plain") ? F.plain : F.small; }
// Partir en renglones al ancho (por palabras). Devuelve [ { k, t } ] ya partidos.
function c3HudWrap(lines, F, maxW) {
   var out = [];
   for (var i = 0; i < lines.length; ++i) {
      // (las cifras con separador de miles —«435 000»— no se parten: MIRADO el 15-oct, «in 435» / «000 years»)
      var f = c3HudFontOf(F, lines[i].k), words = String(lines[i].t).replace(/(\d) (?=\d{3}(\D|$))/g, "$1 ").split(" "), cur = "";
      for (var j = 0; j < words.length; ++j) {
         var nx = cur.length ? cur + " " + words[j] : words[j];
         if (c3HudWidth(F, lines[i].k, nx) <= maxW || cur.length === 0) cur = nx;
         else { out.push({ k: lines[i].k, t: cur }); cur = words[j]; }
      }
      if (cur.length) out.push({ k: lines[i].k, t: cur });
   }
   return out;
}
// Medir: { w, h, rows }
function c3HudMeasure(lines, maxBoxW, sc) {
   if (!lines.length) return null;
   var F = c3HudFonts(sc), pad = Math.round(CP_ATLAS.space[1] * sc), maxW = maxBoxW - 2 * pad - Math.round(2 * sc), rows = c3HudWrap(lines, F, maxW), h = 0, wMax = 0;
   for (var i = 0; i < rows.length; ++i) {
      var f = c3HudFontOf(F, rows[i].k); h += f.ascent + f.descent + Math.round(2 * sc); wMax = Math.max(wMax, c3HudWidth(F, rows[i].k, rows[i].t));
   }
   return { w: wMax + 2 * pad + Math.round(4 * sc), h: h + 2 * pad, rows: rows, F: F, pad: pad };
}
// Pintar arriba a la derecha de x1 (o a la izquierda de x0 con box.left). Devuelve el rectangulo.
function c3HudPaint(g, lines, box, sc) {
   var M = c3HudMeasure(lines, box.w, sc);
   if (M === null) return null;
   var x = (box.left === true) ? box.x : box.x - M.w, y = box.y, F = M.F, pad = M.pad, i;
   g.antialiasing = true;
   g.pen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1); g.brush = new Brush(cpInt(CP_ATLAS.bg, C3_HUD.ALPHA));   // (translucido, pero con letra legible sobre cualquier cosa)
   g.drawRect(x, y, x + M.w, y + M.h);
   g.fillRect(new Rect(x, y, x + Math.max(2, Math.round(2 * sc)), y + M.h), new Brush(CP_INT_AMBER));
   var yy = y + pad;
   for (i = 0; i < M.rows.length; ++i) {
      var R = M.rows[i], f = c3HudFontOf(F, R.k);
      g.font = f;
      g.pen = new Pen((R.k === "caps") ? CP_INT_AMBER : (R.k === "big") ? CP_INT_TEXT : (R.k === "plain") ? CP_INT_TEXT : (R.k === "error") ? CP_INT_ERROR : (R.k === "warn" || R.k === "idea") ? CP_INT_AMBERLIGHT : (R.k === "fold") ? CP_INT_MUTED : CP_INT_TEXT2);
      g.drawText(x + pad + Math.round(4 * sc), yy + f.ascent, R.t);
      yy += f.ascent + f.descent + Math.round(2 * sc);
   }
   return { x: x, y: y, w: M.w, h: M.h };
}
// DONDE va: arriba a la derecha del dibujo, bajando lo justo para no tapar los rotulos de la caja (`boxes`: las marcas de
// distancia y los nombres de las franjas, «MILKY WAY STARS»…). (MIRADO el 15-oct: tapaba «MILKY WAY STARS» y asomaba «MI».)
function c3HudPlace(M, area, boxes, sc) {
   var x = area.x + area.w - M.w, y = area.y, gap = Math.round(4 * sc), B = boxes || [];
   for (var it = 0; it < 12; ++it) {
      var hit = null;
      for (var i = 0; i < B.length; ++i) { var b = B[i]; if (b && x < b.x + b.w && x + M.w > b.x && y < b.y + b.h && y + M.h > b.y) { if (hit === null || b.y + b.h > hit.y + hit.h) hit = b; } }
      if (hit === null) break;
      y = hit.y + hit.h + gap;
   }
   if (y + M.h > area.y + area.h) y = area.y;                       // (no cabe debajo: arriba, como siempre)
   return { x: x, y: y, w: M.w, h: M.h };
}
// Las lineas y su medida para un lienzo: si plegado y todo y aun asi no cabe (lienzo estrecho), la frase llana se queda en
// el tooltip y el rotulo es solo su titulo, el aviso y «detalles» (nada se corta: se dice en el tooltip y se abre con un clic).
// (tarea H3, 21-oct: en un lienzo ESTRECHO —menos de C3_HUD.NARROW px de interfaz— el rotulo plegado es siempre el corto: con la frase
// llana tapaba media escena de 480 px. Tarea H4: ABIERTO, no pasa de C3_HUD.OPEN_H del alto del dibujo —llegaba a 800 × 300 y tapaba el
// 3D—: las lineas tecnicas que no caben se quitan del final y van, enteras, a su tooltip, con una linea que dice cuantas quedan alli)
C3_HUD.NARROW = 640; C3_HUD.OPEN_H = 0.2; C3_HUD.OPEN_LINES = 4; C3_HUD.CROWDED = 30;
// (segunda ronda V5/V6, 21-oct: abierto, como mucho OPEN_LINES lineas tecnicas —con 9 tapaba la arista de la caja—; y si en ninguna
// esquina hay sitio libre —ocupacion > CROWDED—, el rotulo plegado se queda en su version corta: `_c3HudForceShort`)
CPStarfieldDock.prototype._hudFit = function(w, sc, area, light) {
   var open = !!(this.tm && this.tm.hudOpen), lines = this._hudLines(light !== true), M = c3HudMeasure(lines, c3HudMaxW(w, open, sc), sc), j, short = [];
   this._c3HudShort = false; this._c3HudMore = null;
   if (M !== null && !open && area && (M.h > area.h * 0.6 || w < C3_HUD.NARROW * (sc || 1) || this._c3HudForceShort === true)) {
      for (j = 0; j < lines.length; ++j) if (lines[j].k !== "plain") short.push(lines[j]);
      var M2 = c3HudMeasure(short, c3HudMaxW(w, open, sc), sc);
      // (V11: estrecho, el pliegue en corto: «▸ details and / sources (click)» se partia mal)
      if (w < C3_HUD.NARROW * (sc || 1)) for (j = 0; j < short.length; ++j) if (short[j].k === "fold" && !open) short[j] = { k: "fold", t: optT("▸ details") };
      M2 = c3HudMeasure(short, c3HudMaxW(w, open, sc), sc);
      if (M2 !== null && M2.h < M.h) { lines = short; M = M2; this._c3HudShort = true; }
   }
   function nTech(L) { var n = 0; for (var q = 0; q < L.length; ++q) if (L[q].k === "small" || L[q].k === "idea") ++n; return n; }
   if (M !== null && open && area && (M.h > area.h * C3_HUD.OPEN_H || nTech(lines) > C3_HUD.OPEN_LINES)) {
      var keep = lines.slice(), more = [], fold = (keep.length && keep[keep.length - 1].k === "fold") ? keep.pop() : null, M3 = M;
      while (M3 !== null && (M3.h > area.h * C3_HUD.OPEN_H || nTech(keep) > C3_HUD.OPEN_LINES)) {
         var k = -1;
         for (j = keep.length - 1; j >= 0; --j) if (keep[j].k === "small" || keep[j].k === "idea") { k = j; break; }
         if (k < 0) break;
         more.unshift(keep[k]); keep.splice(k, 1);
         var tail = keep.concat([{ k: "small", t: format(optT("%s more lines: point at this box to read them"), String(more.length)) }]);
         if (fold) tail.push(fold);
         M3 = c3HudMeasure(tail, c3HudMaxW(w, open, sc), sc);
         if (M3 !== null) lines = tail;
      }
      if (more.length) { M = M3; this._c3HudMore = more; }
   }
   return { lines: lines, M: M, open: open };
};
// DONDE va, por OCUPACION (20-oct, encargo de Nino: «tapa partes del 3D»). Se mide lo que de verdad hay dibujado bajo cada
// esquina candidata —los puntos (una rejilla que ya hace `_drawDist`), las nubes de polvo (`_dustPaint3d` deja su rejilla
// gruesa), la foto en 3D y los recortes de galaxias y nebulosas— y se elige la que menos tapa. Se rehace en cada dibujo
// (girar, acercar, volar) y con histeresis: la esquina de antes se queda salvo que otra sea claramente mejor.
// Es barato: unos pocos rectangulos contra rejillas; los objetos extensos (pocos) se listan una vez por modelo.
function c3HudExtList(model) {
   if (!model || !model.objects) return [];
   if (model.c3HudExt) return model.c3HudExt;
   var L = [], i;
   for (i = 0; i < model.objects.length; ++i) if (model.objects[i].ext > 0) L.push(i);
   model.c3HudExt = L;
   return L;
}
// El solape de un rectangulo con otro, en pixeles cuadrados
function c3HudOverlap(q, b) { var w = Math.min(q.x + q.w, b.x + b.w) - Math.max(q.x, b.x), h = Math.min(q.y + q.h, b.y + b.h) - Math.max(q.y, b.y); return (w > 0 && h > 0) ? w * h : 0; }
// La «ocupacion» de q: puntos + nubes + foto + recortes (en unidades de «estrellas», para compararlas)
CPStarfieldDock.prototype._c3HudCover = function(q, proj, sc, X, boxes) {
   var s = 0, cellA = Math.pow(24 * sc, 2), i;
   if (X.grid) s += cpSvCountInBox(X.grid, proj.px, proj.py, q.x, q.y, q.x + q.w, q.y + q.h);
   var oc = X.occ;
   if (oc) {
      var c0 = Math.max(0, Math.floor((q.x - oc.x0) / oc.cell)), c1 = Math.min(oc.cols - 1, Math.floor((q.x + q.w - oc.x0) / oc.cell)), r0 = Math.max(0, Math.floor((q.y - oc.y0) / oc.cell)), r1 = Math.min(oc.rows - 1, Math.floor((q.y + q.h - oc.y0) / oc.cell));
      for (var r = r0; r <= r1; ++r) for (var c = c0; c <= c1; ++c) s += 2 * oc.v[r * oc.cols + c];
   }
   // (V5/V6: la FOTO, por su contorno de verdad —no su caja—: la parte del rotulo que cae dentro de ella, muestreada, pesa mucho)
   if (X.quadPts) {
      var nin = 0, QP = X.quadPts, sg = 0, ia, jb;
      for (ia = 0; ia < 4; ++ia) sg += QP[ia].x * QP[(ia + 1) % 4].y - QP[(ia + 1) % 4].x * QP[ia].y;
      for (jb = 0; jb < 5; ++jb) for (ia = 0; ia < 10; ++ia) {
         var sx = q.x + (ia + 0.5) * q.w / 10, sy = q.y + (jb + 0.5) * q.h / 5, inq = true;
         for (var e = 0; e < 4 && inq; ++e) { var A0 = QP[e], A1 = QP[(e + 1) % 4]; if (((A1.x - A0.x) * (sy - A0.y) - (A1.y - A0.y) * (sx - A0.x)) * sg < 0) inq = false; }
         if (inq) ++nin;
      }
      s += 120 * nin / 50;
   } else if (X.quad) s += 3 * c3HudOverlap(q, X.quad) / cellA;
   for (i = 0; X.cuts && i < X.cuts.length; ++i) s += 3 * c3HudOverlap(q, X.cuts[i]) / cellA;
   for (i = 0; boxes && i < boxes.length; ++i) s += 50 * c3HudOverlap(q, boxes[i]) / cellA;        // (las cifras y los rotulos de la caja: casi vetados)
   // (V5/V6: las ARISTAS de la caja y el marco del fondo, muestreados, y donde iran las CIFRAS del eje —casi vetadas—)
   for (i = 0; X.pts && i < X.pts.length; ++i) { var P = X.pts[i]; if (P.x >= q.x && P.x <= q.x + q.w && P.y >= q.y && P.y <= q.y + q.h) s += P.w; }
   return s;
};
// El rectangulo que ocupara. Con `proj` (el dibujo que se esta haciendo) se elige por ocupacion; la segunda llamada de la
// misma pasada (las placas) devuelve lo ya decidido. `X` = { fit, model, mesh, grid } (lo que el dibujo ya tiene).
CPStarfieldDock.prototype._tmHudRect = function(w, sc, area, light, boxes, proj, X, again) {
   var cached = this._c3HudAt;
   if (proj && cached && cached.proj === proj && cached.w === w && cached.R) return cached.R;
   if (again !== true) this._c3HudForceShort = false;
   var HF = this._hudFit(w, sc, area, light), M = HF.M;
   if (M === null) { this._c3HudAt = null; return null; }
   var R = c3HudPlace(M, area, boxes, sc), name = "tr";
   if (proj && proj.px) {
      var ext = X || {}, pad = Math.round(CP_ATLAS.space[1] * sc), i;
      var ctx = { grid: ext.grid || null, occ: (this._c3Occ && ext.fit && this._c3Occ.fit === ext.fit) ? this._c3Occ : null, quad: null, cuts: [] };
      if (!ctx.grid) ctx.grid = cpSvHitGrid(proj.px, proj.py, proj.vis, proj.px.length, w, area.y + area.h + 1, Math.round(24 * sc));
      if (ext.mesh && ext.mesh.quad && ext.mesh.quad.length === 4) {
         var qq = ext.mesh.quad, qx0 = Math.min(qq[0].x, qq[1].x, qq[2].x, qq[3].x), qx1 = Math.max(qq[0].x, qq[1].x, qq[2].x, qq[3].x), qy0 = Math.min(qq[0].y, qq[1].y, qq[2].y, qq[3].y), qy1 = Math.max(qq[0].y, qq[1].y, qq[2].y, qq[3].y);
         ctx.quad = { x: qx0, y: qy0, w: qx1 - qx0, h: qy1 - qy0 }; ctx.quadPts = qq;
      }
      if (ext.model && ext.fit && ext.fit.mode === "perspective") {
         var EL = c3HudExtList(ext.model);
         for (i = 0; i < EL.length; ++i) {
            var k = EL[i], ob = ext.model.objects[k];
            if (!proj.vis[k] || (ob.kind === "cluster" && ext.model.counts && ext.model.counts.members > 0)) continue;
            var rPx = ob.ext * ext.fit.scale * proj.pw[k];
            if (rPx >= CP_SV.CUT_MIN_PX * sc) ctx.cuts.push({ x: proj.px[k] - rPx, y: proj.py[k] - rPx, w: 2 * rPx, h: 2 * rPx });
         }
      }
      // (V5/V6: las aristas largas de la caja, el marco del fondo y las marcas del eje —en las cuatro aristas largas: aun no se sabe en
      // cual iran las cifras—, como puntos con peso)
      ctx.pts = [];
      if (ext.fit && ext.model && ext.fit.mode === "perspective") {
         var Kc = CP_SV_CORNERS, wn2 = ext.model.wn / 2, hn2 = ext.model.hn / 2, c, sI, tickW = 25, edgeW = 4;
         for (c = 0; c < 4; ++c) {
            for (sI = 0; sI <= 24; ++sI) { var pE = ext.fit.px(Kc[c][0] * wn2, Kc[c][1] * hn2, sI / 24); if (pE.ok) ctx.pts.push({ x: pE.x, y: pE.y, w: edgeW }); }
            var c2 = (c + 1) % 4;
            for (sI = 0; sI <= 12; ++sI) { var u2 = Kc[c][0] + (Kc[c2][0] - Kc[c][0]) * sI / 12, v2 = Kc[c][1] + (Kc[c2][1] - Kc[c][1]) * sI / 12, pF = ext.fit.px(u2 * wn2, v2 * hn2, 1); if (pF.ok) ctx.pts.push({ x: pF.x, y: pF.y, w: edgeW }); }
            for (sI = 0; ext.scale && sI < ext.scale.ticks.length; ++sI) { var pT = ext.fit.px(Kc[c][0] * wn2, Kc[c][1] * hn2, ext.scale.ticks[sI].t); if (pT.ok) ctx.pts.push({ x: pT.x, y: pT.y + Math.round(10 * sc), w: tickW }); }
         }
      }
      var cands = [{ n: "tr", r: R }, { n: "tl", r: { x: area.x, y: area.y, w: M.w, h: M.h } }, { n: "br", r: { x: area.x + area.w - M.w, y: area.y + area.h - M.h, w: M.w, h: M.h } }, { n: "bl", r: { x: area.x, y: area.y + area.h - M.h, w: M.w, h: M.h } }];
      var best = null, prev = (cached && cached.w === w) ? cached.name : "", prevScore = -1;
      for (i = 0; i < cands.length; ++i) {
         var q = cands[i].r;
         if (q.y < area.y - 1 || q.y + q.h > area.y + area.h + 1) continue;
         var sco = this._c3HudCover(q, proj, sc, ctx, (cands[i].n === "tr") ? null : boxes);
         cands[i].s = sco;
         if (cands[i].n === prev) prevScore = sco;
         if (best === null || sco < best.s - 2) best = cands[i];          // (a igualdad, la primera: arriba a la derecha)
      }
      if (best) {
         // histeresis: la esquina de antes se queda salvo que la mejor tape claramente menos (el rotulo no baila al girar)
         if (prevScore >= 0 && prevScore <= best.s * 1.25 + 4) { for (i = 0; i < cands.length; ++i) if (cands[i].n === prev) best = cands[i]; }
         R = best.r; name = best.n;
         this._c3HudScores = { chosen: best.n, tr: cands[0].s, tl: cands[1].s, br: cands[2].s, bl: cands[3].s, short: !!this._c3HudForceShort };
         // (sin esquina libre: el plegado, corto —titulos, avisos y «detalles»; la frase entera en su tooltip—, y otra vuelta)
         if (best.s > C3_HUD.CROWDED && again !== true && !HF.open && !this._c3HudShort) { this._c3HudForceShort = true; this._c3HudAt = null; return this._tmHudRect(w, sc, area, light, boxes, proj, X, true); }
      }
   }
   this._c3HudAt = { w: w, proj: proj || null, R: R, name: name };
   return R;
};
var c3BaseRenderAt = CPStarfieldDock.prototype.renderAt;
CPStarfieldDock.prototype.renderAt = function(w, h, sc, opts) {
   var made = c3BaseRenderAt.call(this, w, h, sc, opts), o = opts || {};
   if (this.mode === "dist" && this.state && o.noObjects !== true && o.noBody !== true && made && made.lay && made.lay.area) {
      var HF = this._hudFit(w, sc, made.lay.area, o.light), lines = HF.lines;
      if (lines.length) {
         var g = new Graphics(made.bitmap);
         try {
            g.textAntialiasing = true;
            var scB = sc, a = made.lay.area, mw = c3HudMaxW(w, HF.open, scB), M = HF.M, R = (this._c3HudAt && this._c3HudAt.w === w && this._c3HudAt.R) ? this._c3HudAt.R : c3HudPlace(M, a, (made.lay.tickBoxes || []).concat(made.lay.bandBoxes || []), scB);
            made.lay.hudRect = c3HudPaint(g, lines, { x: R.x, y: R.y, w: mw, left: true }, scB);
         }
         catch (e) {} finally { g.end(); }
      }
   }
   return made;
};
// Un clic en el rotulo lo abre o lo cierra; sobre el, el tooltip con las palabras explicadas.
var c3BaseOnPress = CPStarfieldDock.prototype._onPress;
CPStarfieldDock.prototype._onPress = function(x, y, button, modifiers) {
   var r = this.lay ? this.lay.hudRect : null;
   if (r && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h && this.tm) { this.tm.hudOpen = !this.tm.hudOpen; this._render(); return; }
   return c3BaseOnPress.call(this, x, y, button, modifiers);
};
var c3BaseOnMove = CPStarfieldDock.prototype._onMove;
CPStarfieldDock.prototype._onMove = function(x, y, buttons) {
   var res = c3BaseOnMove.call(this, x, y, buttons), r = this.lay ? this.lay.hudRect : null, d = this.lay ? this.lay.dustLegend : null;
   if (r && !buttons && x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) { try {
      // (con la frase llana fuera del rotulo —lienzo estrecho—, va entera en su tooltip)
      // (28-oct, tarde; B1) el tooltip es HTML (cpWrapTooltip lo envuelve en <html>): «G < 15» abria una etiqueta y Qt se comia el resto de la
      // linea hasta el siguiente «>». Las lineas del rotulo son texto llano: se escapan (C3_HUD.TIP_ESC; tests/c3_dust_label.js L3)
      var esc = function(t) { return (C3_HUD.TIP_ESC === false) ? String(t) : String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); };
      var sen = "", ls = this._c3HudShort ? this._hudLines(true) : [], q, mo = this._c3HudMore || [];
      for (q = 0; q < ls.length; ++q) if (ls[q].k === "plain") sen += esc(ls[q].t) + " ";
      for (q = 0; q < mo.length; ++q) sen += (q === 0 ? "" : "<br>") + esc(mo[q].t);          // (tarea H4: lo que no cabe en el rotulo abierto)
      this.canvas.toolTip = cpWrapTooltip((sen.length ? sen + "<br><br>" : "") + this._hudGlossary());
   } catch (e) {} }
   else if (d && !buttons && x >= d.x && x <= d.x + d.w && y >= d.y && y <= d.y + d.h) { try { this.canvas.toolTip = cpWrapTooltip(this._dustSpec("density").tip); } catch (e2) {} }
   return res;
};
