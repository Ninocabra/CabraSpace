// ============================================================================
// tm/timemachine_ui.js — LA MAQUINA DEL TIEMPO en el panel de «Distances» y en la foto (Cabra3D, 14-oct-2026)
// ----------------------------------------------------------------------------
// Peticion de Nino: con los movimientos propios, la velocidad radial cuando la haya
// y los demas movimientos relevantes, hacer evolucionar el campo HACIA DELANTE Y
// HACIA ATRAS: control de tiempo (deslizador + reproduccion, de años a millones de
// años), estrellas que se desplazan en la foto y en 3D, estelas, las que no tienen
// velocidad radial marcadas como inciertas, aviso honesto de donde deja de valer la
// recta, y exportarlo como video igual que el vuelo.
//
// COMO ENCAJA (sin tocar el dibujo de CabraPilot mas que en tres costuras, ver
// tools/patch_copies.js):
//   · `_distModel` devuelve, con t ≠ 0, una COPIA del modelo de «Distances» con cada
//     estrella en su sitio de ese instante (u, v, distancia): la caja, la perspectiva, las
//     transiciones, los vuelos y las estrellas de la foto («Stars») lo pintan como siempre.
//     Los indices son los mismos (las estrellas no aparecen ni desaparecen: las que salen
//     del encuadre siguen dibujandose fuera).
//   · `cpSvDistScale` usa siempre el modelo de AHORA (`tmBase`): la caja no «respira».
//   · `_distBody` pinta HUECA una estrella sin velocidad radial (`tmHollow`) y llama a
//     `_tmTrails3d` (las estelas en 3D).
//   · La foto (ui/photo_view.js) llama a `tmPaintPhoto`: estelas, estrellas en su sitio de
//     ese instante y el rotulo; la foto se apaga un poco al alejarse de «ahora».
// LAS FILAS van en la caja de mandos del panel (`rowsBox`): a pantalla completa se mudan
// con ella (cero redundancia). Solo en «Distances».
//   [⟲ Now] [▶] [══════●══════] [+12 300 years]
//   [±100 kyr ▾] [Seen from the Sun ▾] [Trails]        [Photo + 3D ▾] [● Video]
// NADA SE CALCULA EN onPaint: las posiciones de un instante se calculan al cambiar el
// instante (una vez) y se guardan; pintar es copiar y trazar. ES5 (metodos de CPStarfieldDock).
// ============================================================================

var C3_TMUI = {
   TICK_S: 0.033,            // el tic de reproducir y de las transiciones de tiempo
   PLAY_S: 16,               // una pasada entera de la escala (−escala → +escala) al reproducir
   GO_MS: 1300,              // un salto de tiempo animado («Now», cambiar de escala): lo mismo que una transicion de vista
   BLEND_MS: 900,            // cambiar de modelo de movimiento: cada estrella va de su sitio en uno a su sitio en el otro
   // (MIRADO en las capturas del 14-oct: con 1 200 estelas y las 15 000 estrellas del campo de las Pleyades en la foto, a
   // ±100 000 años todo era una maraña. CabraPilot ya lo midio en los vuelos: de 500 estelas arriba es «un pelo».)
   TRAIL_MEMBERS: 160,       // estelas de miembros de cumulos (los mas brillantes)
   TRAIL_FAST: 60,           // y las del campo que MAS se mueven en el cielo (configurable aqui)
   PHOTO_MEMBERS: 2500,      // en la FOTO se mueven, como mucho, estos miembros…
   PHOTO_FIELD: 700,         // …y estas estrellas del campo (las mas brillantes): lo demas, la foto
   FIELD_ALPHA: 0.62,        // las del campo, algo apagadas: los cumulos mandan
   TRAIL_K: 12,              // puntos de cada estela
   STARLESS_MAX: 1600, STARLESS_R: 4,   // la foto sin estrellas propia: lado de la copia y radio de la apertura (pixeles de la copia)
   DIM: 0.85,                // la foto, lejos de «ahora», se apaga hasta esto (las estrellas que se mueven mandan; con 0,42 en el video era negra)
   DIM_AT: 0.04,             // …del todo a esta fraccion de la escala
   RANGE_DEFAULT: 1e5,
   MOTIONS: ["sun", "galactic", "lsr"],
   VIDEO_KINDS: ["both", "3d", "photo"],
   REC_KINDS: ["flight", "both", "3d", "photo"],      // lo que graba el unico «● Record» (ui/groups.js)
   VIDEO_S: 16,              // la duracion del video (storyboard abajo)
   HUD_W: 0.46,              // ancho maximo del rotulo, en anchos del lienzo
   SPREAD_N: 41,             // instantes con los que se busca el minimo de tamaño de un cumulo
   ORBIT_K: 161,             // instantes de la tabla de orbitas (de −escala a +escala)
   OUT_MARGIN: 0.04,         // una estrella sale del haz al pasar el borde de la foto en esta fraccion
   PHOTO_BODIES: 8,          // (bloque F) en la FOTO se llevan a su sitio, como mucho, las capas de los 8 objetos mas grandes que se mueven…
   PHOTO_BODY_MARGIN: 0.01,  // …y solo las que caben enteras en la foto, a 1 % del lado menor de sus bordes (ver `_tmPaintBodiesOn`)
   ENCOUNTER_MAX_YR: 1e6,    // un encuentro con el Sol mas alla de esto no se cuenta (pasado 1 Myr la recta ya se equivoca un 1 %)
   AUTO_ORBITS_YR: 1e7,      // (2-nov, decisión 1A) desde este alcance el movimiento pasa solo a «Órbitas galácticas» (ver c3TmMotionFor)
   ESC_RGB: 0x9a9a9a,        // (decisión 2) una estrella que se ha escapado de su cúmulo: gris…
   ESC_ALPHA: 0.6            // …tenue (con 0,45 y la profundidad, en IC 1396 quedaba casi del color del fondo: 27,20,14)
};
// (2-nov-2026, decisión 1A de Nino; docs/investigacion_orbitas_largo_plazo.md §5 #1) EL PASO SOLO A ÓRBITAS. Con un alcance de 10 Ma o más
// el movimiento pasa a «Órbitas galácticas»: las rectas se separan de la órbita un 12-14 % a 10 Ma y crecen como t² (docs/maquina_del_tiempo.md
// §5). Por debajo vuelve lo que eligió la persona (`tm.motionUser`, lo único que se guarda). «Rectas, desde el LSR» pasa también: es la misma
// recta con la cámara en el LSR y se equivoca igual (lo que enseña —quitar el reflejo del movimiento del Sol— solo tiene sentido a escalas
// cortas). Elegir una recta A MANO con un alcance largo se respeta (con su aviso rojo); el siguiente cambio de alcance vuelve a aplicar la
// regla. El desplegable enseña «Órbitas · auto» (con «Órbitas galácticas · auto» no cabía: se cortaba en «· a») y su ayuda dice por qué. Rojo: C3_TM_AUTO_ORBITS = false.
var C3_TM_AUTO_ORBITS = true;
// (decisión 2) costura del rojo: false = una escapada de su cúmulo se pinta con el color de siempre (en el 3D, en la foto y en su estela)
var C3_TM_ESC_GREY = true;
function c3TmMotionFor(range, user) { return (C3_TM_AUTO_ORBITS === true && range >= C3_TMUI.AUTO_ORBITS_YR && user !== "galactic") ? "galactic" : user; }
function c3TmMotionWord(m) { return (m === "galactic") ? optT("Galactic orbits") : (m === "lsr") ? optT("Straight lines, from the LSR") : optT("Straight lines, from the Sun"); }
// (2-nov-2026, B1 del video de formacion) costura del rojo: false = una estrella a la que la proyeccion de la foto ya no llega (> 90° del centro del campo:
// `c3TmTan` da null, `P.ok` falso) se pinta en su sitio de HOY, como hasta entonces. true = cuenta como salida del encuadre (`tmGone` + `tmNoTan`).
// Prueba F de tests/c3_d_fixes.js (C3D_BREAK=f).
var C3_TM_NOTAN_GONE = true;
// (2-nov-2026, pendiente 3D-11) costura del rojo: false = la leyenda cuenta las estrellas de HOY aunque la maquina del tiempo las haya sacado del encuadre
// (a -100 Ma decia «470 estrellas con paralaje fiable» con 0 pintadas). true = cuenta las que siguen en la escena. Prueba G de tests/c3_d_fixes.js (C3D_BREAK=g).
var C3_TM_LEGEND_COUNT = true;
// (C7b, 2-nov-2026) costura del rojo: false = la «mas cercana / lejana» sigue siendo la de hoy aunque se haya ido del encuadre (su placa desaparece). Prueba H de tests/c3_d_fixes.js (C3D_BREAK=h2).
var C3_TM_NEAR_REASSIGN = true;
// (idem) costura: false = una entrada de la leyenda que queda en 0 desaparece (la leyenda pierde filas y la caja 3D salta). Rojo C3D_BREAK=g2.
var C3_TM_LEGEND_KEEP = true;
// Lo recordado de la maquina del tiempo (escala, movimiento, estelas, clase de video). Las pruebas ni lo leen ni lo escriben.
function c3TmRead(key, type, fallback) {
   if (CP_NO_MAIN) return fallback;
   try { var v = Settings.read(CP_SETTINGS_PREFIX + "/TimeMachine/" + key, type); if (v !== null && v !== undefined && Settings.lastReadOK !== false) return v; } catch (e) {}
   return fallback;
}
function c3TmWrite(key, type, value) { if (CP_NO_MAIN) return; try { Settings.write(CP_SETTINGS_PREFIX + "/TimeMachine/" + key, type, value); } catch (e) {} }
var C3_TM_CLOCK = function() { return Date.now(); };     // (costura de pruebas: el reloj de reproducir y de las transiciones)
var C3_TM_ANIM = !CP_NO_MAIN;                             // (sin pantalla, los saltos de tiempo son instantaneos: ninguna prueba depende del reloj)

// ---------------------------------------------------------------------------
// LA ESCALA DEL FONDO, siempre la de AHORA (si no, la caja «respiraria» al moverse las estrellas)
// ---------------------------------------------------------------------------
var c3BaseDistScale = cpSvDistScale;
cpSvDistScale = function(mode, model, unit) { return c3BaseDistScale(mode, (model && model.tmBase) ? model.tmBase : model, unit); };

// ---------------------------------------------------------------------------
// LAS FILAS
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._tmBuild = function() {
   var self = this, C = this.rowsBox, button = cpSfFlButton, label = cpSfFlLabel, i;
   c3TmfPatchHud();                                      // (bloque F: el rotulo —tm/hud.js se carga despues— lleva el frente de luz)
   var r = Number(c3TmRead("range", DataType_Double, C3_TMUI.RANGE_DEFAULT));
   var mo = String(c3TmRead("motion", DataType_String, "sun")), vk = String(c3TmRead("video", DataType_String, "flight"));
   var mu = (C3_TMUI.MOTIONS.indexOf(mo) >= 0) ? mo : "sun", r0 = (C3_TM_RANGES.indexOf(r) >= 0) ? r : C3_TMUI.RANGE_DEFAULT;
   this.tm = { t: 0, range: r0, motion: c3TmMotionFor(r0, mu), motionUser: mu, autoOrbits: (c3TmMotionFor(r0, mu) !== mu),
               trails: (c3TmRead("trails", DataType_Boolean, true) !== false), video: (C3_TMUI.REC_KINDS.indexOf(vk) >= 0) ? vk : "flight",
               playing: false, play: null, go: null, blend: null, building: true, syncing: false, lastFrameMs: 0 };
   this.tmNow = button(C, "⟲ " + optT("Now"), "tm.now", function() { self.tmGo(0); });
   this.tmPlay = button(C, "▶ " + optT("Play"), "tm.play", function() { self.tmPlayToggle(); });
   // LA REGLA DEL TIEMPO (tm/timeruler.js): pintada, con «ahora» en el centro y el oro desde ahora hasta el tirador
   this.tmSlider = c3TimeRuler(C);
   this.tmSlider.c3range = this.tm.range;
   this.tmSlider.toolTip = cpTooltip("tm.slider");
   this.tmSlider.onValueUpdated = function(v) { if (self.tm.syncing) return; self._tmStopAnims(); self.tmSetTime(c3TmSliderToYears(v, self.tm.range), { light: true }); };
   this.tmSlider.c3onRelease = function() { if (!self.tm.syncing) self._tmSettle(); };
   this.tmLabel = new Label(C);
   this.tmLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   cpApplyStyle(this.tmLabel, "background-color:transparent; color:" + CP_UI.text + "; border:none; font-family:" + CP_UI.fontMono + "; font-size:10px;");
   try { this.tmLabel.setFixedWidth(cpUiPx(CP_ATLAS.space[8] + CP_ATLAS.space[4], this.tmLabel)); } catch (eL) {}
   this.tmLabel.toolTip = cpTooltip("tm.label");
   this.tmRange = new ComboBox(C); cpSfFlField(this.tmRange); this.tmRange.toolTip = cpTooltip("tm.range");
   this.tmRange.onItemSelected = function(k) { if (!self.tm.building) self.tmSetRange(C3_TM_RANGES[k]); };
   this.tmMotion = new ComboBox(C); cpSfFlField(this.tmMotion); this.tmMotion.toolTip = cpTooltip("tm.motion");
   this.tmMotion.onItemSelected = function(k) { if (!self.tm.building) self.tmSetMotion(C3_TMUI.MOTIONS[k]); };
   this.tmTrails = button(C, optT("Trails"), "tm.trails", function() { self.tmSetTrails(!self.tm.trails); });
   // QUE GRABAR (encargo de Nino, 15-oct: «● Record» del vuelo y «● Video» del tiempo eran dos caminos a lo mismo): UN solo
   // «● Record» —el del vuelo— y, a su lado, este desplegable: el vuelo, o la maquina del tiempo (foto + 3D, 3D o foto).
   this.recWhat = new ComboBox(C); cpSfFlField(this.recWhat); this.recWhat.toolTip = cpTooltip("rec.what");
   this.recWhat.onItemSelected = function(k) { if (!self.tm.building) { self.tm.video = C3_TMUI.REC_KINDS[k]; c3TmWrite("video", DataType_String, self.tm.video); self._flightSync(); } };
   this._tmItems();
   this._dustBuild(); this._skyBuild();                  // (A5, A6: el polvo y el cielo desde otra estrella; capas opcionales, apagadas de fabrica)
   this._c3Layout();                                     // (ui/groups.js: los mandos, por clases)
   this.tmTimer = new Timer;
   this.tmTimer.periodic = true;
   this.tmTimer.interval = C3_TMUI.TICK_S;
   this.tmTimer.onTimeout = function() { if (cpQuiet()) return; self._tmTick(); };
   this.tm.building = false;
   this._tmLabelSync();
};
CPStarfieldDock.prototype._tmItems = function() {
   var was = this.tm.building, i;
   this.tm.building = true;
   try {
      this.tmRange.clear();
      for (i = 0; i < C3_TM_RANGES.length; ++i) this.tmRange.addItem("± " + c3TmRangeText(C3_TM_RANGES[i]));
      this.tmRange.currentItem = Math.max(0, C3_TM_RANGES.indexOf(this.tm.range));
      this.tmMotion.clear();
      this.tmMotion.addItem(optT("Straight lines, from the Sun")); this.tmMotion.addItem(this.tm.autoOrbits ? optT("Orbits · auto") : optT("Galactic orbits")); this.tmMotion.addItem(optT("Straight lines, from the LSR"));
      this.tm.itemsAuto = !!this.tm.autoOrbits;
      this.tmMotion.currentItem = Math.max(0, C3_TMUI.MOTIONS.indexOf(this.tm.motion));
      this.recWhat.clear();
      this.recWhat.addItem(optT("the flight")); this.recWhat.addItem(optT("the time machine: photo + 3D")); this.recWhat.addItem(optT("the time machine: 3D")); this.recWhat.addItem(optT("the time machine: photo"));
      this.recWhat.currentItem = Math.max(0, C3_TMUI.REC_KINDS.indexOf(this.tm.video));
   } finally { this.tm.building = was; }
};
// El apex publicado de un cumulo (si esta en la tabla de Babusiaux et al. 2018; tm/timemachine.js)
var C3_TM_LIT_ROWS = null;
function c3TmApexLiterature(cl) {
   if (!cl) return null;
   if (C3_TM_LIT_ROWS === null) {
      C3_TM_LIT_ROWS = [];
      try {
         var t = cpSfParseTable(File.readTextFile(cpSfDataDir() + "babusiaux2018_tablea3_convergent.csv"), ",");
         for (var i = 0; i < t.rows.length; ++i) { var r = t.rows[i]; C3_TM_LIT_ROWS.push({ name: String(r.Cluster).replace(/^\s+|\s+$/g, ""), ra: cpSfNum(r.RA_ICRS), dec: cpSfNum(r.DE_ICRS), raConv: cpSfNum(r.RAconv), decConv: cpSfNum(r.DEconv), rv: cpSfNum(r.RV), pmRa: cpSfNum(r.pmRA), pmDec: cpSfNum(r.pmDE), plx: cpSfNum(r.plx) }); }
      } catch (e) {}
   }
   return c3TmApexLiteratureOf(cl.ra, cl.dec, C3_TM_LIT_ROWS);
}
// «±100 kyr», «±1 Myr»… (las escalas del deslizador)
function c3TmRangeText(y) {
   // (23-oct, noche: en castellano «Ma / Ga», como CabraComposition; antes «1000 Myr» y «Myr» también en castellano)
   if (y >= 1e9) return cpSvDec(String(y / 1e9)) + " " + optT("Gyr");
   if (y >= 1e6) return cpSvDec(String(y / 1e6)) + " " + optT("Myr");
   if (y >= 1e3) return cpSvDec(String(y / 1e3)) + " " + optT("kyr");
   return String(y) + " " + optT("yr");
}
// Un instante, en palabras: «now · the photo», «+12 300 years», «−1.25 Myr». (Sin decimales falsos: 3 cifras.)
function c3TmTimeText(T) {
   var y = c3TmRoundYears(T), a = Math.abs(y), s = (y < 0) ? "−" : "+";
   // (tarea H8, 21-oct: «now» salia tres veces —el boton «⟲ Now», la marca «now» de la regla y este «now · the photo»—: aqui basta «the photo»)
   if (a === 0) return optT("the photo");
   // (antes, 10 Myr salia «1 Myr»: se comia el cero de las decenas. Revision visual)
   // (23-oct, noche; revisión visual: «+3.19 Myr» con punto en castellano. La coma del idioma —cpSvDec— y las unidades Ma / Ga)
   if (a >= 1e9) { var gy = a / 1e9, tg = (Math.round(gy) === gy) ? String(gy) : gy.toFixed(2).replace(/0+$/, "").replace(/[.]$/, ""); return s + cpSvDec(tg) + " " + optT("Gyr"); }
   if (a >= 1e6) { var my = a / 1e6, tx = (Math.round(my) === my) ? String(my) : my.toFixed(2).replace(/0+$/, "").replace(/[.]$/, ""); return s + cpSvDec(tx) + " " + optT("Myr"); }
   return s + cpSvGroup(a) + " " + ((a === 1) ? optT("year") : optT("years"));
}
// El año del calendario (solo cuando tiene sentido: dentro de ±1 Myr).
function c3TmCalendarYear(st, T) {
   // (del instante REDONDEADO, el mismo que se enseña: «−82 600 años» y su año casan; revision visual)
   var y0 = 2016 + ((st && st.result && st.result.field) ? st.result.field.years : 0), y = Math.round(y0 + c3TmRoundYears(T));
   if (Math.abs(T) > 1e6 || T === 0) return "";
   return (y < 0) ? format(optT("year %s BCE"), cpSvGroup(1 - y)) : format(optT("year %s"), cpSvGroup(y));
}

// Lo que se ve y lo que se puede tocar (lo llama `_syncButtons`).
CPStarfieldDock.prototype._tmSync = function() {
   if (!this.tm) return;
   // (MIRADO por la revision del 15-oct: con tmSetRange/tmSetMotion llamados desde codigo, los desplegables se quedaban en lo viejo)
   try { var wasB = this.tm.building; this.tm.building = true; this.tmRange.currentItem = Math.max(0, C3_TM_RANGES.indexOf(this.tm.range)); this.tmMotion.currentItem = Math.max(0, C3_TMUI.MOTIONS.indexOf(this.tm.motion)); this.tm.building = wasB; } catch (eC) {}
   try { if (this._dustSync) this._dustSync(); if (this._skySync) this._skySync(); if (this._c3RetrySync) this._c3RetrySync(); } catch (eL) {}
   var on = (this.mode === "dist" && this.state !== null && !this._closed), rec = !!(this.fl && this.fl.rec !== null);
   var all = [this.tmNow, this.tmPlay, this.tmSlider, this.tmLabel, this.tmRange, this.tmMotion, this.tmTrails], i;
   for (i = 0; i < all.length; ++i) cpSetControlVisible(all[i], on);
   if (!on) return;
   var ready = this._tmReady();
   try {
      for (i = 0; i < all.length; ++i) all[i].enabled = ready && !rec;
      this.recWhat.enabled = !rec;
   } catch (e) {}
   this.tmPlay.text = this.tm.playing ? ("❚❚ " + optT("Pause")) : ("▶ " + optT("Play"));
   cpStyleToggle(this.tmPlay, this.tm.playing); cpStyleToggle(this.tmNow, false); cpStyleToggle(this.tmTrails, this.tm.trails);
   if (!ready) { var why = cpWrapTooltip(this._tmWhyNot()); for (i = 0; i < all.length; ++i) { try { all[i].toolTip = why; } catch (e2) {} } this.tm.tipsOff = true; }
   else if (this.tm.tipsOff) { this.tm.tipsOff = false; this._tmTips(); }
   else this._tmMotionTip();
   this._tmLabelSync();
};
CPStarfieldDock.prototype._tmTips = function() {
   var all = [this.tmNow, this.tmPlay, this.tmSlider, this.tmLabel, this.tmRange, this.tmMotion, this.tmTrails, this.recWhat];
   var keys = ["tm.now", "tm.play", "tm.slider", "tm.label", "tm.range", "tm.motion", "tm.trails", "rec.what"];
   for (var i = 0; i < all.length; ++i) { try { all[i].toolTip = cpTooltip(keys[i]); } catch (e) {} }
   this._tmMotionTip();
};
// (decisión 1A) la ayuda del desplegable de movimiento dice POR QUÉ ha pasado solo a órbitas, y el texto del desplegable lleva «· auto»
CPStarfieldDock.prototype._tmMotionTip = function() {
   if (!this.tm || !this.tmMotion) return;
   if (!!this.tm.itemsAuto !== !!this.tm.autoOrbits) this._tmItems();
   if (this.tm.tipsOff) return;
   try {
      this.tmMotion.toolTip = this.tm.autoOrbits
         ? cpWrapTooltip(format(optT("«Galactic orbits» has been chosen by itself because the range is 10 Myr or more: straight lines drift from the real orbits by 12–14 %% at 10 Myr, and more and more after (the stars circle the Galaxy, they do not fly straight). Below 10 Myr your choice, «%s», comes back. You can still pick a straight line here to compare."), c3TmMotionWord(this.tm.motionUser)))
         : cpTooltip("tm.motion");
   } catch (e) {}
};
CPStarfieldDock.prototype._tmReady = function() {
   var st = this.state;
   if (!st || !st.result || !st.result.ok) return false;
   var d = this._tmData(st);
   return !!(d && d.tm && d.tm.n > 0 && d.tm.tan);
};
CPStarfieldDock.prototype._tmWhyNot = function() {
   var st = this.state;
   if (!st) return optT("Nothing computed for this image yet");
   var d = this._tmData(st);
   if (!d || !d.tm.tan) return optT("The time machine needs the astrometric solution of the photo to place the stars.");
   if (d.tm.n === 0) return optT("No star of this field has both a distance and a proper motion: there is nothing to move.");
   return "";
};
CPStarfieldDock.prototype._tmLabelSync = function() {
   if (!this.tm || !this.tmLabel) return;
   this.tm.syncing = true;
   try {
      this.tmLabel.text = c3TmTimeText(this.tm.t);
      var v = c3TmYearsToSlider(this.tm.t, this.tm.range);
      this.tmSlider.c3range = this.tm.range;
      this.tmSlider.c3set(v);
      try { this.tmSlider.repaint(); } catch (eR) {}
      var lv = c3TmValidity(this.tm.t, this._tmModelName());
      cpApplyStyle(this.tmLabel, "background-color:transparent; color:" + ((lv.level === "beyond") ? cpQss(CP_ATLAS.error) : (lv.level === "warn") ? CP_UI.primaryLight : CP_UI.text) +
                   "; border:none; font-family:" + CP_UI.fontMono + "; font-size:10px;");
   } finally { this.tm.syncing = false; }
};
CPStarfieldDock.prototype._tmModelName = function() { return (this.tm.motion === "galactic") ? "galactic" : "linear"; };

// ---------------------------------------------------------------------------
// LOS DATOS de la maquina del tiempo de una imagen: el estado de cada estrella que se pinta (una vez por imagen, por
// movimiento elegido y por lo que trae la red), y las posiciones de cada instante (una vez por instante).
// ---------------------------------------------------------------------------
var c3BaseDistModelFn = CPStarfieldDock.prototype._distModel;
CPStarfieldDock.prototype._tmBaseModel = function() { return c3BaseDistModelFn.call(this); };
CPStarfieldDock.prototype._tmData = function(st) {
   if (!st || !st.result || !st.result.ok || !this.tm) return null;
   var keep = this.state;
   this.state = st;
   var base = null;
   try { base = this._tmBaseModel(); } finally { this.state = keep; }
   var rvRef = st.tmRv || null, kinRef = st.tmKin || null, key = this.tm.motion;
   if (st.tmd && st.tmd.baseRef === base && st.tmd.motion === key && st.tmd.rvRef === rvRef && st.tmd.kinRef === kinRef) return st.tmd;
   if (st.tmTan === undefined) st.tmTan = c3TmTanOf(st.result);
   var want = {}, i, objs = base.objects;
   for (i = 0; i < objs.length; ++i) if (objs[i].kind === "star" || objs[i].kind === "member") want[objs[i].ref] = true;
   var tm = c3TmBuild(st.result, { tan: st.tmTan, epochYears: st.result.field.years, model: (key === "galactic") ? "galactic" : "linear", lsr: (key === "lsr"),
                                   rv: rvRef ? rvRef.rv : {}, indices: want });
   var objTm = new Int32Array(objs.length);
   for (i = 0; i < objs.length; ++i) { var j = (objs[i].kind === "star" || objs[i].kind === "member") ? tm.pos[objs[i].ref] : undefined; objTm[i] = (j === undefined) ? -1 : j; }
   // las estelas: las mas brillantes (siempre las mismas para este campo)
   var order = [];
   for (i = 0; i < tm.n; ++i) order.push(i);
   var stars = st.result.stars;
   order.sort(function(a, b) { var ga = stars[tm.idx[a]].g, gb = stars[tm.idx[b]].g; return ((ga === null) ? 99 : ga) - ((gb === null) ? 99 : gb); });
   // LO QUE SE ENSEÑA en la foto y lo que lleva estela: los miembros de los cumulos primero, y lo mas brillante del campo
   var mem = [], fld = [];
   for (i = 0; i < order.length; ++i) (stars[tm.idx[order[i]]].cluster >= 0 ? mem : fld).push(order[i]);
   // (b, revision del coordinador: con 15 000 estrellas las estelas de las mas BRILLANTES eran una maraña; llevan estela los miembros de
   // los cumulos, las del campo que MAS se mueven en el cielo y la elegida —`_tmTrailIdx`—)
   var fast = fld.slice().sort(function(a, b) { var sa = stars[tm.idx[a]], sb = stars[tm.idx[b]]; return (Math.abs(sb.pmRa) + Math.abs(sb.pmDec)) - (Math.abs(sa.pmRa) + Math.abs(sa.pmDec)); });
   var trailIdx = mem.slice(0, C3_TMUI.TRAIL_MEMBERS).concat(fast.slice(0, C3_TMUI.TRAIL_FAST));
   var photoIdx = mem.slice(0, C3_TMUI.PHOTO_MEMBERS).concat(fld.slice(0, C3_TMUI.PHOTO_FIELD));
   // BLOQUE F: lo que no es una estrella. Los objetos de nuestra galaxia que se mueven (tmx, con la forma de `tm`), y lo lejano que va
   // con la expansion (hub). `objX[i]` = el objeto i en tmx (o −1).
   var B = this._tmBodyList(st, base, tm), tmx = c3TmBodies(B.list, { tan: st.tmTan, model: tm.model, lsr: tm.lsr }), objX = new Int32Array(objs.length), hub = new Uint8Array(objs.length);
   for (i = 0; i < objs.length; ++i) {
      objX[i] = (B.objOf[i] >= 0 && tmx.pos[B.objOf[i]] !== undefined) ? tmx.pos[B.objOf[i]] : -1;
      var ok = objs[i], dso = ((ok.kind === "galaxy" || ok.kind === "quasar" || ok.kind === "group") && st.result.deepSky && st.result.deepSky.objects) ? st.result.deepSky.objects[ok.ref] : null;
      hub[i] = (dso && dso.extragalactic && !ok.suspect && c3CosmoInHubbleFlow(dso.z)) ? 1 : 0;
   }
   st.tmd = { baseRef: base, motion: key, rvRef: rvRef, kinRef: kinRef, tm: tm, objTm: objTm, at: {}, atKeys: [], trailIdx: trailIdx, photoIdx: photoIdx, trail: null, info: null, models: {},
              tmx: tmx, objX: objX, hub: hub, bodies: B.list, atX: {}, atXKeys: [] };
   return st.tmd;
};
// LOS OBJETOS QUE SE MUEVEN (bloque F; la fisica en tm/timemachine.js, `c3TmBodyPick` y `c3TmBodies`): las nebulosas de Sharpless, lo
// de nuestra galaxia que trae SIMBAD («other»: planetarias, regiones HII, cumulos que no son de los nuestros…) y los cumulos SIN
// miembros pintados (los que tienen miembros siguen a sus miembros, como hasta ahora). Para cada uno, sus candidatos de movimiento:
// el suyo en SIMBAD (st.tmKin), la mediana de las estrellas de Gaia que tiene DENTRO y a su distancia, el de un cumulo de catalogo
// que tenga dentro (o el suyo, si es un cumulo), y el supuesto (la rotacion de la Galaxia). Devuelve { list, objOf (Int32Array) }.
CPStarfieldDock.prototype._tmBodyList = function(st, base, tm) {
   var res = st.result, objs = base.objects, f = res.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H), i, j;
   var kin = (st.tmKin && st.tmKin.byName) ? st.tmKin.byName : {}, rv = (st.tmRv && st.tmRv.rv) ? st.tmRv.rv : {}, stars = res.stars || [], cls = res.clusters || [];
   var objOf = new Int32Array(objs.length), memN = {}, cand = [];
   for (i = 0; i < objs.length; ++i) { objOf[i] = -1; if (objs[i].kind === "member") { var cm = stars[objs[i].ref].cluster; memN[cm] = (memN[cm] || 0) + 1; } }
   for (i = 0; i < objs.length; ++i) {
      var ob = objs[i], info = null;
      if (ob.suspect || !(ob.pc > 0)) continue;
      try {
         if (ob.kind === "nebula") { var nb = res.nebulae.objects[ob.ref]; info = { ra: nb.ra, dec: nb.dec, rDeg: nb.radiusDeg || 0, names: [nb.name, nb.id], dist: nb.dist, cl: -1 }; }
         else if (ob.kind === "other") { var dd = res.deepSky.objects[ob.ref]; if (!dd.extragalactic) info = { ra: dd.ra, dec: dd.dec, rDeg: (dd.sizeArcmin > 0) ? dd.sizeArcmin / 120 : 0, names: [dd.name], dist: dd.dist, cl: -1 }; }
         else if (ob.kind === "cluster" && !(memN[ob.ref] > 0)) { var cc = cls[ob.ref]; info = { ra: cc.ra, dec: cc.dec, rDeg: (cc.coreRadiusDeg > 0) ? cc.coreRadiusDeg : 0, names: [cc.name, cc.id].concat(cc.aliases || []), dist: cc.dist, cl: ob.ref }; }
      } catch (eI) { info = null; }
      if (info === null || !isFinite(info.ra) || !isFinite(info.dec)) continue;
      info.index = i; info.ob = ob;
      cand.push(info);
   }
   cand.sort(function(a, b) { return ((b.ob.ext || 0) - (a.ob.ext || 0)) || (a.index - b.index); });
   if (cand.length > C3_TMF.MAX_BODIES) cand.length = C3_TMF.MAX_BODIES;
   // las estrellas con distancia y movimiento propio, como vectores (una vez): «dentro» = a menos de su radio del centro del objeto
   var su = [], k = Math.PI / 180;
   for (j = 0; j < stars.length; ++j) {
      var s = stars[j];
      if (!s || !s.dist || !(s.dist.pc > 0) || s.dist.quality === "suspect" || s.pmRa === null || s.pmDec === null || !isFinite(s.pmRa) || !isFinite(s.pmDec)) continue;
      su.push([Math.cos(s.dec * k) * Math.cos(s.ra * k), Math.cos(s.dec * k) * Math.sin(s.ra * k), Math.sin(s.dec * k), j]);
   }
   var list = [];
   for (i = 0; i < cand.length; ++i) {
      var c = cand[i], C = {}, n;
      // (1) SIMBAD: el objeto por su nombre
      for (n = 0; n < c.names.length && !C.simbad; ++n) { var kr = kin[c3TmKinName(c.names[n])]; if (kr) C.simbad = { pmRa: kr.pmRa, pmDec: kr.pmDec, pmErr: kr.pmErr, rv: kr.rv, rvErr: kr.rvErr, pmRef: "SIMBAD " + kr.pmRef, rvRef: "SIMBAD " + kr.rvRef, name: kr.name }; }
      // (2) sus estrellas: dentro de su radio y a su distancia (DIST_TOL o 2 sigmas de la suya)
      if (c.rDeg > 0) {
         var cu = [Math.cos(c.dec * k) * Math.cos(c.ra * k), Math.cos(c.dec * k) * Math.sin(c.ra * k), Math.sin(c.dec * k)], cr = Math.cos(c.rDeg * k), sig = (c.dist && c.dist.hi > c.dist.lo) ? (c.dist.hi - c.dist.lo) / 2 : 0;
         var tol = Math.max(C3_TMF.DIST_TOL * c.ob.pc, 2 * sig), inside = [];
         for (j = 0; j < su.length; ++j) {
            if (su[j][0] * cu[0] + su[j][1] * cu[1] + su[j][2] * cu[2] < cr) continue;
            var sj = stars[su[j][3]];
            if (Math.abs(sj.dist.pc - c.ob.pc) > tol) continue;
            inside.push({ pmRa: sj.pmRa, pmDec: sj.pmDec, rv: (rv[su[j][3]] && isFinite(rv[su[j][3]].rv)) ? rv[su[j][3]].rv : null });
         }
         if (inside.length > 0) { var sm = c3TmStarsMotion(inside); sm.pmRef = format(optT("median of its %s Gaia DR3 stars"), cpSvGroup(sm.n)); sm.rvRef = format(optT("median of %s Gaia DR3 radial velocities of its stars"), cpSvGroup(sm.nRv)); C.stars = sm; }
      }
      // (3) un cumulo: el suyo (si es un cumulo) o el de catalogo que tenga dentro
      var ci = c.cl;
      if (ci < 0 && c.rDeg > 0) { var bd = Infinity; for (j = 0; j < cls.length; ++j) { var q = cls[j]; if (!q || !(q.dist && q.dist.pc > 0)) continue; var sp = cpSfSeparation(c.ra, c.dec, q.ra, q.dec); if (sp <= c.rDeg && sp < bd && Math.abs(q.dist.pc - c.ob.pc) <= tol) { bd = sp; ci = j; } } }
      if (ci >= 0 && cls[ci]) {
         var cq = cls[ci], pm = cq.pm || {}, pa = (isFinite(pm.ra) && pm.ra !== null) ? pm.ra : pm.catalogRa, pd = (isFinite(pm.dec) && pm.dec !== null) ? pm.dec : pm.catalogDec;
         var crv = (tm && tm.clusterRv && tm.clusterRv[ci] !== undefined) ? tm.clusterRv[ci] : null;
         if ((pa !== null && pa !== undefined && isFinite(pa)) || crv !== null) C.cluster = { pmRa: (pa !== undefined) ? pa : null, pmDec: (pd !== undefined) ? pd : null, pmErr: null, rv: crv, rvErr: null,
                                                                                         pmRef: format(optT("the cluster %s"), String(cq.name || cq.id || "")), rvRef: format(optT("the cluster %s (median of its Gaia DR3 radial velocities)"), String(cq.name || cq.id || "")) };
      }
      // (4) lo supuesto: la rotacion de la Galaxia en su sitio
      var rot = c3GalRotationRel(c.ra, c.dec, c.ob.pc);
      C.assumed = rot ? { pmRa: rot.pmRa, pmDec: rot.pmDec, rv: rot.rv, ref: optT("assumed: it turns with the Galaxy (circular orbit in MilkyWayPotential2022): nothing measured") } : { pmRa: 0, pmDec: 0, rv: 0, ref: "" };
      var mo = c3TmBodyPick(C);
      objOf[c.index] = list.length;
      list.push({ ra: c.ra, dec: c.dec, pc: c.ob.pc, x: c.ob.u * big + W / 2, y: c.ob.v * big + H / 2, motion: mo, index: c.index, kind: c.ob.kind, name: c.ob.name });
   }
   return { list: list, objOf: objOf };
};
// Las posiciones de los objetos en un instante (guardadas: las ultimas 6).
CPStarfieldDock.prototype._tmAtX = function(d, T) {
   if (!d || !d.tmx || d.tmx.n === 0) return null;
   var k = String(T);
   if (d.atX[k]) return d.atX[k];
   var o = c3TmAt(d.tmx, T);
   d.atX[k] = o; d.atXKeys.push(k);
   while (d.atXKeys.length > 6) delete d.atX[d.atXKeys.shift()];
   return o;
};
// Las posiciones de un instante (guardadas: las ultimas 6).
CPStarfieldDock.prototype._tmAt = function(d, T) {
   var k = String(T);
   if (d.at[k]) return d.at[k];
   var o = c3TmAt(d.tm, T);
   d.at[k] = o; d.atKeys.push(k);
   while (d.atKeys.length > 6) delete d.at[d.atKeys.shift()];
   return o;
};

// EL MODELO DE «Distances» EN UN INSTANTE: el de ahora con cada estrella en su sitio de ese instante. Con el cambio de modelo de
// movimiento en marcha (`tm.blend`), cada estrella entre su sitio en uno y en otro.
CPStarfieldDock.prototype._distModel = function() {
   var base = c3BaseDistModelFn.call(this);
   if (!this.tm || this._tmUseBase === true || this.state === null) return base;
   var T = this.tm.t, bl = this.tm.blend;
   if (T === 0 && bl === null) return base;
   var st = this.state, d = this._tmData(st);
   if (!d || !d.tm.tan || d.tm.n === 0) return base;
   var key = T + "|" + (bl ? bl.s.toFixed(3) + bl.from : "");
   if (d.models[key]) return d.models[key];
   var P = this._tmAt(d, T), Q = null, s = 0;
   if (bl !== null) { Q = bl.fromAt; s = 1 - cpSvEase(bl.s); }
   var f = st.result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H), objs = base.objects, n = objs.length, out = {}, k, i;
   for (k in base) out[k] = base[k];
   out.objects = new Array(n); out.tmBase = base; out.tmT = T;
   var clU = {}, clV = {}, clN = {}, clNo = {}, clR2 = {}, clR02 = {}, clUn = {}, gone = 0, unknown = 0;
   for (i = 0; i < n; ++i) {
      var ob = objs[i], j = d.objTm[i];
      if (j < 0) { out.objects[i] = ob; continue; }
      var x = P.x[j], y = P.y[j], pc = P.pc[j], pOk = !!P.ok[j];
      if (Q !== null && Q.ok[j]) {
         if (pOk) { x = x + (Q.x[j] - x) * s; y = y + (Q.y[j] - y) * s; pc = pc + (Q.pc[j] - pc) * s; }
         // (B1, 2-nov-2026) en el cambio de modelo, una estrella que el modelo nuevo saca de la proyeccion (P no, Q si) no se puede mezclar —no hay
         // sitio al que ir—: se queda donde la dejaba el modelo viejo mientras este pese mas que el nuevo (s > 0,5) y despues se va. Con P y Q a la vez
         // (el caso de siempre) se mezcla como antes; con Q sin P (entra en la proyeccion) aparece ya en su sitio nuevo.
         else if (C3_TM_NOTAN_GONE === true && s > 0.5) { x = Q.x[j]; y = Q.y[j]; pc = Q.pc[j]; pOk = true; }
         else { x = NaN; y = NaN; }
      }
      if (!pOk || !isFinite(x) || !isFinite(y)) {
         if (C3_TM_NOTAN_GONE !== true || T === 0) { out.objects[i] = ob; continue; }
         // (B1) la proyeccion de la foto no llega (> 90° del centro del campo): la estrella ha salido del encuadre; NO se pinta la de hoy. Su sitio real no
         // existe en la foto, asi que no cuenta para el centro de su cumulo; `tmNoTan` hace que `cpSvDistProject` la dé por no vista (sin placa ni mira).
         var cg = {}, rg = pc / Math.max(1e-9, d.tm.dPc[j]);
         for (k in ob) cg[k] = ob[k];
         cg.pc = ob.pc * rg; cg.lo = ob.lo * rg; cg.hi = ob.hi * rg; cg.tmI = j; cg.tmGone = true; cg.tmNoTan = true;
         out.objects[i] = cg; ++gone;
         var cl0 = st.result.stars[ob.ref].cluster;
         if (cl0 >= 0) clNo[cl0] = (clNo[cl0] || 0) + 1;
         continue;
      }
      var c = {};
      for (k in ob) c[k] = ob[k];
      var ratio = pc / Math.max(1e-9, d.tm.dPc[j]);
      c.u = (x - W / 2) / big; c.v = (y - H / 2) / big; c.pc = ob.pc * ratio; c.lo = ob.lo * ratio; c.hi = ob.hi * ratio;
      c.tmHollow = (T !== 0 && d.tm.rvFrom[j] === "none"); c.tmI = j;
      // (REVISION VISUAL del 14-oct: una estrella que ha SALIDO del encuadre ya no esta «detras de la foto»; pintada en la caja,
      // con la perspectiva caia encima de NGC 1560, a 10 millones de años luz. Se va, y el rotulo cuenta cuantas se han ido.)
      c.tmGone = (Math.abs(c.u) > base.wn / 2 * (1 + C3_TMUI.OUT_MARGIN) || Math.abs(c.v) > base.hn / 2 * (1 + C3_TMUI.OUT_MARGIN));
      // (2-nov-2026, decisiones 2 y 3A) su cúmulo aún no había nacido: no se pinta (y no cuenta como «salida del encuadre»); escapada de su cúmulo
      // (más lejos que su radio de Jacobi): gris tenue (`tmEsc`; ui/starfield_panel.js)
      var es = P.esc ? P.esc[j] : 0;
      if (es === 3) { c.tmGone = true; c.tmUnborn = true; }
      else if (c.tmGone) ++gone;
      if (es === 2) c.tmEsc = true;
      // (decisión 5a) el cono: de 0,5 a 1 se va apagando. (Q3 = A, 2-nov, noche) con x ≥ 1 —su sitio ya no se sabe— se queda al 25 % y se cuenta
      // como incierta (`tmUnknown`; el rótulo lo dice); ya no se esconde. Rojo C3_TM_CONE_FLOOR = false: no se pinta (lo de antes).
      var cx = P.cone ? P.cone[j] : 0, ca = c3TmConeAlpha(cx);
      if (cx >= 1 && !c.tmGone) { c.tmUnknown = true; ++unknown; if (!(ca > 0)) c.tmGone = true; }
      if (cx > 0.5 && ca > 0) c.tmFade = ca;
      out.objects[i] = c;
      var cl = st.result.stars[ob.ref].cluster;
      if (es === 3 && cl >= 0) clUn[cl] = true;
      if (cl >= 0 && es !== 2 && es !== 3) { clU[cl] = (clU[cl] || 0) + c.u; clV[cl] = (clV[cl] || 0) + c.v; clN[cl] = (clN[cl] || 0) + 1; }
   }
   // LOS CUMULOS: su centro sigue al de sus miembros, y su aro crece o mengua con ellos (rebobinando, un grupo que se expande se encoge)
   for (i = 0; i < n; ++i) {
      if (objs[i].kind !== "member" || out.objects[i] === objs[i] || out.objects[i].tmNoTan === true || out.objects[i].tmEsc === true || out.objects[i].tmUnborn === true) continue;
      var cm = st.result.stars[objs[i].ref].cluster, mu = clU[cm] / clN[cm], mv = clV[cm] / clN[cm];
      var du = out.objects[i].u - mu, dv = out.objects[i].v - mv;
      clR2[cm] = (clR2[cm] || 0) + du * du + dv * dv;
   }
   var mu0 = {}, mv0 = {}, mn0 = {};
   for (i = 0; i < n; ++i) { if (objs[i].kind !== "member" || out.objects[i] === objs[i] || out.objects[i].tmNoTan === true || out.objects[i].tmEsc === true || out.objects[i].tmUnborn === true) continue; var c0 = st.result.stars[objs[i].ref].cluster; mu0[c0] = (mu0[c0] || 0) + objs[i].u; mv0[c0] = (mv0[c0] || 0) + objs[i].v; mn0[c0] = (mn0[c0] || 0) + 1; }
   for (i = 0; i < n; ++i) { if (objs[i].kind !== "member" || out.objects[i] === objs[i] || out.objects[i].tmNoTan === true || out.objects[i].tmEsc === true || out.objects[i].tmUnborn === true) continue; var c1 = st.result.stars[objs[i].ref].cluster, a = objs[i].u - mu0[c1] / mn0[c1], b = objs[i].v - mv0[c1] / mn0[c1]; clR02[c1] = (clR02[c1] || 0) + a * a + b * b; }
   for (i = 0; i < n; ++i) {
      var oc = objs[i];
      // (B1) un cumulo cuyos miembros se han ido TODOS por la proyeccion tampoco se queda en su sitio de hoy
      // (3A) un cúmulo que aún no había nacido: tampoco su aro ni su nombre
      if (oc.kind === "cluster" && clUn[oc.ref] === true) { var cu = {}; for (k in oc) cu[k] = oc[k]; cu.tmGone = true; cu.tmUnborn = true; out.objects[i] = cu; continue; }
      if (C3_TM_NOTAN_GONE === true && oc.kind === "cluster" && !(clN[oc.ref] > 0) && clNo[oc.ref] > 0) { var cz = {}; for (k in oc) cz[k] = oc[k]; cz.tmGone = true; cz.tmNoTan = true; out.objects[i] = cz; continue; }
      if (oc.kind !== "cluster" || !(clN[oc.ref] > 0)) continue;
      var cc = {};
      for (k in oc) cc[k] = oc[k];
      cc.u = oc.u + (clU[oc.ref] / clN[oc.ref] - mu0[oc.ref] / mn0[oc.ref]); cc.v = oc.v + (clV[oc.ref] / clN[oc.ref] - mv0[oc.ref] / mn0[oc.ref]);
      if (clR02[oc.ref] > 0) { var gr = Math.sqrt(clR2[oc.ref] / clR02[oc.ref]); cc.radius = oc.radius * Math.max(0.2, Math.min(20, gr)); }
      out.objects[i] = cc;
   }
   // BLOQUE F · LO QUE NO ES UNA ESTRELLA. (1) Los objetos de nuestra galaxia, con su propio movimiento: su centro y su distancia como
   // los de una estrella; su recorte (la huella de la nebulosa, el trozo de foto) va con ellos: `tmShift` = { du, dv, k } —lo que se ha
   // movido y lo que cambia su tamaño en el cielo (∝ 1/distancia)—, y su `rect`/`disc`/`ext` siguen siendo los de la FOTO (de donde
   // se recorta). (2) Lo lejano que va con la expansion: a(t)·D. (3) El frente de luz del instante (lo pinta `_tmTrails3d`).
   var PX = this._tmAtX(d, T), QX = (bl !== null && bl.fromAtX) ? bl.fromAtX : null, aT = c3CosmoScale(T), nb = 0;
   for (i = 0; i < n; ++i) {
      var jx = d.objX ? d.objX[i] : -1, o0 = objs[i];
      if (jx >= 0 && PX !== null) {
         var bx = PX.x[jx], by = PX.y[jx], bpc = PX.pc[jx];
         var pxOk = !!PX.ok[jx];
         if (QX !== null && QX.ok[jx]) {
            if (pxOk) { bx = bx + (QX.x[jx] - bx) * s; by = by + (QX.y[jx] - by) * s; bpc = bpc + (QX.pc[jx] - bpc) * s; }
            else if (C3_TM_NOTAN_GONE === true && s > 0.5) { bx = QX.x[jx]; by = QX.y[jx]; bpc = QX.pc[jx]; pxOk = true; }      // (B1: igual que las estrellas)
            else { bx = NaN; by = NaN; }
         }
         if (!pxOk || !isFinite(bx) || !isFinite(by)) {
            // (B1) un objeto de nuestra galaxia que la proyeccion ya no alcanza: se va (antes se quedaba el de hoy)
            if (C3_TM_NOTAN_GONE === true) { var cn = {}; for (k in o0) cn[k] = o0[k]; cn.tmGone = true; cn.tmNoTan = true; out.objects[i] = cn; }
            continue;
         }
         var cb = {};
         for (k in o0) cb[k] = o0[k];
         var rb = bpc / Math.max(1e-9, d.tmx.dPc[jx]);
         cb.u = (bx - W / 2) / big; cb.v = (by - H / 2) / big; cb.pc = o0.pc * rb; cb.lo = o0.lo * rb; cb.hi = o0.hi * rb;
         cb.tmShift = { du: cb.u - o0.u, dv: cb.v - o0.v, k: 1 / rb };
         cb.tmBody = jx; cb.tmAssumed = d.tmx.motion[jx].assumed;
         var half = (o0.ext > 0) ? o0.ext / rb : 0;
         cb.tmGone = (Math.abs(cb.u) - half > base.wn / 2 * (1 + C3_TMUI.OUT_MARGIN) || Math.abs(cb.v) - half > base.hn / 2 * (1 + C3_TMUI.OUT_MARGIN));
         if (o0.kind === "cluster" && o0.radius > 0) cb.radius = o0.radius / rb;
         out.objects[i] = cb; ++nb;
      } else if (d.hub && d.hub[i] && aT !== 1) {
         var ce = {};
         for (k in o0) ce[k] = o0[k];
         ce.pc = o0.pc * aT; ce.lo = o0.lo * aT; ce.hi = o0.hi * aT; ce.tmExp = aT;
         out.objects[i] = ce;
      }
   }
   out.tmBodies = nb; out.tmScale = aT; out.tmFront = c3CosmoLightFront(T);
   out.tmGone = gone; out.tmUnknown = unknown;
   // (C7b, 2-nov-2026) «la mas cercana / la mas lejana» (las placas de `cpSvDistHighlights`): el modelo de hoy las elige entre TODO lo fiable; si en este instante la elegida se ha ido del
   // encuadre (`tmGone`) su placa no se pinta (vis = 0) y el campo se quedaba sin ella. Ahora pasa a la mas cercana / lejana (misma regla que `cpSvDistModel`: ni miembros ni dudosas) que SIGUE en la escena.
   if (C3_TM_NEAR_REASSIGN === true) {
      var rn = out.nearest, rf = out.farthest;
      if ((rn >= 0 && out.objects[rn].tmGone === true) || (rf >= 0 && out.objects[rf].tmGone === true)) {
         rn = -1; rf = -1;
         for (i = 0; i < n; ++i) {
            var oq = out.objects[i];
            if (oq.kind === "member" || oq.suspect || oq.tmGone === true) continue;
            if (rn < 0 || oq.pc < out.objects[rn].pc) rn = i;
            if (rf < 0 || oq.pc > out.objects[rf].pc) rf = i;
         }
         out.nearest = rn; out.farthest = rf;
      }
   }
   // (3D-11) la leyenda y el pie cuentan lo que sigue en la escena: las estrellas que se han ido (por el margen o por la proyeccion) se restan.
   // `counts` es el objeto del modelo de ahora (compartido): se copia antes de tocarlo.
   if (C3_TM_LEGEND_COUNT === true) {
      var cnt = {};
      for (k in base.counts) cnt[k] = base.counts[k];
      for (i = 0; i < n; ++i) {
         var og = out.objects[i];
         if (objs[i].kind !== "star" || og.tmGone !== true) continue;
         if (objs[i].suspect === true) --cnt.doubtful; else --cnt.stars;
         if (objs[i].faint > 0 && cnt.faintStars > 0) --cnt.faintStars;
      }
      out.counts = cnt;
   }
   d.models = {}; d.models[key] = out;          // (solo el ultimo: cada instante es otro)
   return out;
};

// ---------------------------------------------------------------------------
// EL TIEMPO: ponerlo, animarlo, reproducirlo
// ---------------------------------------------------------------------------
// Pone el instante (años desde la foto) y repinta el panel y la foto. opts: { light } (sin placas: mientras se arrastra o se reproduce).
CPStarfieldDock.prototype.tmSetTime = function(T, opts) {
   if (!this.tm) return;
   var o = opts || {}, lim = this.tm.range;
   T = Math.max(-lim, Math.min(lim, Number(T) || 0));
   if (Math.abs(T) < 1e-9) T = 0;
   this.tm.t = T;
   // (la foto sin estrellas se hace UNA vez, aqui, la primera vez que se sale de «ahora»; al pintar solo se copia)
   if (T !== 0 && this.state && this.state.tmd && this.state.tmStarless === undefined) this.tmStarless();
   if (T !== 0) this._tmEnsureOrbit();
   if (T !== 0) this._tmPrepBodies();
   this._tmLabelSync();
   this._tmRepaint(o.light === true);
};
CPStarfieldDock.prototype._tmRepaint = function(light) {
   // (bloque F: la ficha de lo que se mira dice lo que el instante le hace —el frente de luz, donde esta—: se rehace con el instante)
   try { if (this.mode === "dist" && this.state !== null && (this.hoverObj >= 0 || this.selObj >= 0)) this._card = this._currentCard(); } catch (eC) {}
   if (this.mode === "dist" && this.state !== null && !this._closed) {
      var was = this._light;
      this._light = (light === true);
      try { this._render(); } finally { this._light = was; }
   }
   try { this.dialog.preview.viewport.repaint(); } catch (e) {}
   if (this.tm.t !== 0) this._tmSayValidity();
};
// BLOQUE F: las capas de los objetos que se mueven (su recorte: la nebulosa sin estrellas, con su hueco), hechas UNA vez y fuera de
// onPaint, la primera vez que se sale de «ahora»: la foto las lleva a su sitio de cada instante (`_tmPaintBodiesOn`). Las PHOTO_BODIES
// mas grandes.
CPStarfieldDock.prototype._tmPrepBodies = function() {
   var st = this.state;
   if (!st || !st.tmd || st.tmBodyCutsFor === st.tmd) return;
   st.tmBodyCutsFor = st.tmd;
   var d = st.tmd, base = d.baseRef, list = [], i;
   if (!base || !d.objX || !(d.tmx && d.tmx.n > 0)) return;
   for (i = 0; i < base.objects.length; ++i) {
      var bo = base.objects[i];
      // (28-oct-2026, D1: ni cumulo ni asociacion de SIMBAD llevan trozo de foto; ver cpSvCutouts, ui/starfield_view.js)
      if (typeof CP_SV_CUT_NO_CLUSTER !== "undefined" && CP_SV_CUT_NO_CLUSTER === true && bo.kind !== "cluster" && (bo.cls === "star-cluster" || bo.cls === "association")) continue;
      if (d.objX[i] >= 0 && bo.ext > 0) list.push(i);
   }
   list.sort(function(a, b) { return base.objects[b].ext - base.objects[a].ext; });
   var mg = C3_TMUI.PHOTO_BODY_MARGIN * Math.min(base.wn, base.hn), made = 0;
   for (i = 0; i < list.length && made < C3_TMUI.PHOTO_BODIES; ++i) {
      var r = cpSvCutoutRect(base.objects[list[i]], base.wn, base.hn);
      // (solo las que caben enteras en la foto: las demas no se llevan en ella —`_tmPaintBodiesOn`—)
      if (r === null || !(r.u0 > -base.wn / 2 + mg && r.u1 < base.wn / 2 - mg && r.v0 > -base.hn / 2 + mg && r.v1 < base.hn / 2 - mg)) continue;
      ++made;
      try { this._cutOf(st, base, { index: list[i], u0: r.u0, v0: r.v0, u1: r.u1, v1: r.v1, r: r.r, t: 0, rPx: 0 }, false); } catch (eC) {}
   }
};
// Al soltar el deslizador o acabar una animacion: el dibujo entero (con sus placas).
CPStarfieldDock.prototype._tmSettle = function() { this._tmRepaint(false); };
// A7: con «Galactic orbits», las orbitas de todas las estrellas que se mueven y la del Sol, integradas en MilkyWayPotential2022 (CabraShared/csh_galdyn.js; antes MWPotential2014) para la escala
// elegida (una vez por escala; la barra de progreso lo dice). Sin la tabla, c3TmAt usa los epiciclos.
CPStarfieldDock.prototype._tmEnsureOrbit = function() {
   var st = this.state;
   if (!this.tm || this.tm.motion !== "galactic" || !st) return;
   var d = this._tmData(st);
   if (!d || !d.tm || d.tm.n === 0) return;
   if (d.tm.orbit && d.tm.orbit.R === this.tm.range) return;
   var self = this, busy = false, t0 = Date.now();
   try { this.dialog.preview.setBusy(true, format(optT("Integrating %s orbits in the Milky Way…"), cpSvGroup(d.tm.n)), false); busy = true; } catch (eB) {}
   try {
      var made = c3TmOrbitTable(d.tm, this.tm.range, C3_TMUI.ORBIT_K, function(f) {
         if (C3_CLOSING) return false;                        // (cerrando: se para aqui)
         try { self.dialog.preview.setBusy(true, format(optT("Integrating %s orbits in the Milky Way… %d %%"), cpSvGroup(d.tm.n), Math.round(100 * f)), false); } catch (eP) {}
         return true;
      });
      if (made === null) return;
      // (bloque F: los objetos que se mueven, en el mismo potencial y con la misma escala; son pocos)
      if (d.tmx && d.tmx.n > 0 && c3TmOrbitTable(d.tmx, this.tm.range, C3_TMUI.ORBIT_K, function() { return !C3_CLOSING; }) === null) return;
      d.at = {}; d.atKeys = []; d.atX = {}; d.atXKeys = []; d.models = {}; d.trail = null; d.info = null;
      d.orbitMs = Date.now() - t0;
   } finally { if (busy) try { this.dialog.preview.setBusy(false); } catch (eF) {} }
};
CPStarfieldDock.prototype._tmSayValidity = function() {
   var lv = c3TmValidity(this.tm.t, this._tmModelName());
   var sig = lv.code + "|" + this.tm.motion;
   if (sig === this.tm.saidSig) return;
   this.tm.saidSig = sig;
   // (segunda ronda V9, 21-oct: el aviso de validez salia DOS veces —en la linea de estado, en rojo, y en el rotulo del 3D—. Se queda en el
   // rotulo, en ambar —es un aviso, no un error—; la linea de estado vuelve a decir el estado del 3D)
   if (this.tm.saidWarn !== (lv.code !== "")) { this.tm.saidWarn = (lv.code !== ""); try { this._sayState(); } catch (e) {} }
};
function c3TmValidityText(code) {
   switch (code) {
   case "linear-warn": return optT("Beyond ~1 Myr the straight lines drift ~1 % from the real orbits: try «Galactic orbits».");
   case "linear-beyond": return optT("Beyond ~10 Myr straight lines no longer describe the motion (the stars orbit the Galaxy, they do not fly straight): choose «Galactic orbits» in the motion list.");
   // (2-nov-2026: MilkyWayPotential2022 no tiene artículo propio; se cita gala —Price-Whelan 2017, JOSS— y la curva de rotación a la que se ajustó, Eilers et al. 2019)
   case "galactic": return optT("Galactic orbits: each star and the Sun integrated in a model of the Milky Way, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), valid to about 100 Myr.");
   case "galactic-warn": return (typeof cshGdBarOn === "function" && cshGdBarOn()) ? optT("Beyond ~100 Myr the model lacks the spiral arms and the encounters with clouds, which weigh more and more: take it as an illustration.")
                                                                                   : optT("Beyond ~100 Myr the model lacks the bar, the spiral arms and the encounters, which weigh more and more: take it as an illustration.");
   case "galactic-beyond": return optT("Beyond ~500 Myr these are no longer the stars' real orbits: the bar, spiral arms and encounters have scattered them.");
   }
   return "";
}
function c3TmValidityDetail(code) { return optT("The physics and its limits are in docs/maquina_del_tiempo.md (straight-line motion 0.1 % off the orbit at 0.1 Myr, 1 % at 1 Myr, 12 % at 10 Myr; measured)."); }

CPStarfieldDock.prototype._tmStopAnims = function() {
   if (!this.tm) return;
   this.tm.go = null; this.tm.blend = null;
   if (this.tm.playing) { this.tm.playing = false; this.tm.play = null; this._tmSync(); }
   try { this.tmTimer.stop(); } catch (e) {}
};
// UN SALTO ANIMADO a `T` (la transicion de la maquina del tiempo: cada estrella vuelve por su camino). Sin animaciones, en el acto.
CPStarfieldDock.prototype.tmGo = function(T, ms) {
   if (!this.tm) return;
   this._tmStopAnims();
   var from = this.tm.t, to = Math.max(-this.tm.range, Math.min(this.tm.range, T));
   if (!C3_TM_ANIM || from === to) { this.tmSetTime(to); return; }
   // (la foto sin estrellas ANTES de animar: hacerla en el primer tic congelaba la transicion —medido en c3_look 2—)
   if (to !== 0 && this.state && this.state.tmd && this.state.tmStarless === undefined) this.tmStarless();
   if (to !== 0) this._tmPrepBodies();                   // (bloque F: las capas de los objetos, tambien antes)
   this.tm.go = { from: from, to: to, t0: C3_TM_CLOCK(), ms: (ms > 0) ? ms : C3_TMUI.GO_MS };
   try { this.tmTimer.start(); } catch (e) {}
};
CPStarfieldDock.prototype.tmPlayToggle = function() {
   if (!this.tm) return;
   if (this.tm.playing) { this._tmStopAnims(); this._tmSettle(); return; }
   this._tmStopAnims();
   // (desde el final, vuelve a empezar por el otro lado; si no, sigue hacia delante)
   var start = (this.tm.t >= this.tm.range * 0.999) ? -this.tm.range : this.tm.t;
   if (this.state && this.state.tmd && this.state.tmStarless === undefined) this.tmStarless();     // (antes de arrancar, no en un tic)
   this._tmPrepBodies();
   this.tm.playing = true;
   this.tm.play = { t0: C3_TM_CLOCK(), from: start };
   this.tmSetTime(start, { light: true });
   this._tmSync();
   try { this.tmTimer.start(); } catch (e) {}
};
// Reproducir avanza en PROPORCION A LA ESCALA (una pasada entera, PLAY_S segundos) y por el deslizador (que es mas fino cerca
// de ahora): se ve igual de bien ±1 000 años que ±10 Myr.
CPStarfieldDock.prototype._tmTick = function() {
   var tm = this.tm, now = C3_TM_CLOCK(), t0 = Date.now();
   if (tm.go) {
      var g = tm.go, s = (now - g.t0) / g.ms;
      if (s >= 1) { tm.go = null; this.tmSetTime(g.to); if (!tm.playing && !tm.blend) { try { this.tmTimer.stop(); } catch (e) {} } return; }
      this.tmSetTime(g.from + (g.to - g.from) * cpSvEase(s), { light: true });
   } else if (tm.blend) {
      var b = tm.blend;
      b.s = Math.min(1, (now - b.t0) / C3_TMUI.BLEND_MS);
      if (b.s >= 1) { tm.blend = null; this.tmSetTime(tm.t); try { this.tmTimer.stop(); } catch (e2) {} return; }
      this._tmRepaint(true);
   } else if (tm.playing) {
      var p = tm.play, v0 = c3TmYearsToSlider(p.from, tm.range), dv = (now - p.t0) / 1000 / C3_TMUI.PLAY_S * C3_TM_STEPS, v = v0 + dv;
      if (v >= C3_TM_STEPS) { this._tmStopAnims(); this.tmSetTime(tm.range); return; }
      this.tmSetTime(c3TmSliderToYears(v, tm.range), { light: true });
   } else { try { this.tmTimer.stop(); } catch (e3) {} }
   tm.lastFrameMs = Date.now() - t0;
};
CPStarfieldDock.prototype.tmSetRange = function(R) {
   if (C3_TM_RANGES.indexOf(R) < 0 || !this.tm) return;
   this.tm.range = R;
   c3TmWrite("range", DataType_Double, R);
   this.tm.info = null;
   if (this.state && this.state.tmd) { this.state.tmd.info = null; if (this.state.tmd.tm) this.state.tmd.tm.orbit = null; }
   // (decisión 1A) con 10 Ma o más, a órbitas; por debajo, lo elegido (sin escribirlo: lo guardado sigue siendo lo que eligió la persona)
   var mu = this.tm.motionUser || this.tm.motion, want = c3TmMotionFor(R, mu);
   if (want !== this.tm.motion) this._tmSwitchMotion(want);
   this.tm.autoOrbits = (this.tm.motion !== mu) && !(this._gxTimeOn && this._gxTimeOn());     // (en Galaxia el desplegable ya va fijo en órbitas, con su porqué)
   var to = Math.max(-R, Math.min(R, this.tm.t));
   if (to !== this.tm.t) this.tmGo(to); else this._tmLabelSync();
   this._tmEnsureOrbit();
   this._tmRepaint(false);
   this._tmSync();
};
// Cambiar de modelo de movimiento (lo elige la persona en el desplegable): se recuerda, y cuenta como su elección también con un alcance
// largo (decisión 1A: se respeta, con su aviso).
CPStarfieldDock.prototype.tmSetMotion = function(m) {
   if (C3_TMUI.MOTIONS.indexOf(m) < 0 || !this.tm) return;
   this.tm.motionUser = m; this.tm.autoOrbits = false;
   c3TmWrite("motion", DataType_String, m);
   if (m === this.tm.motion) { this._tmSync(); return; }
   this._tmSwitchMotion(m);
};
// Cada estrella va de su sitio con el uno a su sitio con el otro (BLEND_MS).
CPStarfieldDock.prototype._tmSwitchMotion = function(m) {
   if (C3_TMUI.MOTIONS.indexOf(m) < 0 || !this.tm || m === this.tm.motion) return;
   var st = this.state, fromAt = null, fromAtX = null;
   if (st && this.tm.t !== 0) { var d0 = this._tmData(st); if (d0) { fromAt = this._tmAt(d0, this.tm.t); fromAtX = this._tmAtX(d0, this.tm.t); } }
   this._tmStopAnims();
   this.tm.motion = m;
   if (this.tm.t !== 0) this._tmEnsureOrbit();
   this.tm.saidSig = "";
   if (fromAt !== null && C3_TM_ANIM) {
      // (los indices son los mismos con los dos modelos: las mismas estrellas)
      this.tm.blend = { fromAt: fromAt, fromAtX: fromAtX, from: "m" + C3_TMUI.MOTIONS.indexOf(m), t0: C3_TM_CLOCK(), s: 0 };
      try { this.tmTimer.start(); } catch (e) {}
   } else this.tmSetTime(this.tm.t);
   this._tmSync();
};
CPStarfieldDock.prototype.tmSetTrails = function(on) {
   this.tm.trails = (on === true);
   c3TmWrite("trails", DataType_Boolean, this.tm.trails);
   this._tmSync();
   this._tmRepaint(false);
};
CPStarfieldDock.prototype._tmCleanup = function() {
   if (!this.tm) return;
   try { this.tmTimer.stop(); } catch (e) {}
   this.tm.playing = false; this.tm.go = null; this.tm.blend = null;
};
CPStarfieldDock.prototype._tmRetranslate = function() {
   if (!this.tm) return;
   this.tmNow.text = "⟲ " + optT("Now"); this.tmTrails.text = optT("Trails");
   this._tmItems(); this._tmTips(); this._tmSync(); this._c3GroupsRetranslate();
};

// ---------------------------------------------------------------------------
// LAS ESTELAS: los puntos de cada una, de la foto (t = 0) al instante (TRAIL_K tramos). Una vez por instante.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._tmTrailIdx = function(d) {
   var sel = (this.selStar >= 0 && d.tm.pos[this.selStar] !== undefined) ? d.tm.pos[this.selStar] : -1;
   if (sel < 0 || d.trailIdx.indexOf(sel) >= 0) return d.trailIdx;
   return d.trailIdx.concat([sel]);
};
CPStarfieldDock.prototype._tmTrailOf = function(d, T) {
   var list = this._tmTrailIdx(d), key = T + "|" + d.motion + "|" + list.length + "|" + list[list.length - 1] + "|" + (d.tm.orbit ? d.tm.orbit.R : 0);
   if (d.trail && d.trail.key === key) return d.trail;
   var K = C3_TMUI.TRAIL_K, n = list.length, X = new Float32Array(n * (K + 1)), Y = new Float32Array(n * (K + 1)), PC = new Float32Array(n * (K + 1));
   for (var a = 0; a < n; ++a) for (var k = 0; k <= K; ++k) {
      var p = c3TmAtOne(d.tm, list[a], T * k / K), o = a * (K + 1) + k;
      X[o] = p.ok ? p.x : NaN; Y[o] = p.ok ? p.y : NaN; PC[o] = p.pc;
   }
   d.trail = { key: key, X: X, Y: Y, PC: PC, n: n, K: K, idx: list };
   return d.trail;
};
// En 3D (lo llama `_distBody`, costura de Cabra3D): el camino de cada estrella en la caja, de lo viejo (tenue) a lo nuevo.
// (1-nov-2026, D5) los decimales de una cita («H0 = 67.4 km/s/Mpc, Ωm = 0.315»): coma en castellano, SOLO los que siguen a «=» («arXiv 1807.06209» no se toca)
function c3RefDec(t) { return String(t).replace(/(=\s*\d+)\.(\d+)/g, function(m, a, b) { return a + cpSvDecSep() + b; }); }
var C3_TRAIL_OLD = false;
// (2-nov-2026, decisión 5b de Nino) LA NUBE de la estrella elegida: C3_TM_UNC.N_CLOUD sitios posibles en el instante, de un Monte Carlo de sus
// errores de Gaia (tm/timemachine.js c3TmCloudMake; con órbitas, integrados: tm/galaxy.js c3TmCloudOrbit). Se rehace al elegir otra estrella o
// cambiar de alcance o de movimiento, NUNCA en un fotograma de arrastre (`_light`): mientras se arrastra solo se pinta la ya hecha.
var C3_TM_CLOUD = true;
CPStarfieldDock.prototype._tmCloudKey = function(d) {
   if (C3_TM_CLOUD !== true || !this.tm || this.tm.t === 0 || !(this.selObj >= 0) || !d || !d.objTm || this.selObj >= d.objTm.length) return "";
   var j = d.objTm[this.selObj];
   return (j < 0) ? "" : j + "|" + this.tm.range + "|" + this.tm.motion + "|" + (d.tm.orbit ? d.tm.orbit.R : 0);
};
CPStarfieldDock.prototype._tmCloud = function(d) {
   var key = this._tmCloudKey(d);
   if (key === "") return null;
   if (d.cloud && d.cloud.key === key) return d.cloud;
   if (this._light === true) return null;                     // (al arrastrar no se calcula: se hará al soltar)
   var j = d.objTm[this.selObj], t0 = Date.now(), cl = c3TmCloudMake(d.tm, j, C3_TM_UNC.N_CLOUD, 1000 + j);
   if (d.tm.model === "galactic" && d.tm.orbit) c3TmCloudOrbit(d.tm, cl, d.tm.orbit.R, d.tm.orbit.K);
   var Ej = d.tm.err ? d.tm.err[j] : null;                      // (Q4: el rótulo dice el error del movimiento propio de la elegida y de dónde salió)
   cl.spm = Ej ? Ej.spm : null; cl.pmSrc = Ej ? Ej.pmSrc : "";
   cl.key = key; cl.ms = Date.now() - t0; d.cloud = cl;
   return cl;
};
// La nube en el 3D (puntos tenues, ámbar) y en la foto (`map`: pixel de la foto → pantalla). Devuelve cuántos puntos.
CPStarfieldDock.prototype._tmCloud3d = function(g, model, scale, fit, sc, clip, alpha) {
   var st = this.state, d = st && st.tmd, cl = d ? this._tmCloud(d) : null;
   if (!cl) return 0;
   var C = c3TmCloudAt(d.tm, cl, model.tmT), f = st.result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H), n = 0, r = Math.max(1, 1.1 * sc);
   var br = this._brush(CP_INT_AMBERLIGHT & 0xffffff, 0.45 * alpha);
   g.pen = new Pen(0x00000000, 0); g.antialiasing = true;
   for (var q = 0; q < cl.n; ++q) {
      if (!C.ok[q]) continue;
      var p = fit.px((C.x[q] - W / 2) / big, (C.y[q] - H / 2) / big, scale.t(C.pc[q]));
      if (!p.ok || p.x < clip.x || p.y < clip.y || p.x > clip.x + clip.w || p.y > clip.y + clip.h) continue;
      g.brush = br; g.drawCircle(p.x, p.y, r); ++n;
   }
   d.cloudDrawn3d = n;
   return n;
};
CPStarfieldDock.prototype._tmCloudPhoto = function(g, map, sc, clip) {
   var st = this.state, d = st && st.tmd, cl = d ? this._tmCloud(d) : null;
   if (!cl) return 0;
   var C = c3TmCloudAt(d.tm, cl, this.tm.t), n = 0, r = Math.max(1, 1.2 * sc), br = this._brush(CP_INT_AMBERLIGHT & 0xffffff, 0.5);
   g.pen = new Pen(0x00000000, 0); g.antialiasing = true;
   for (var q = 0; q < cl.n; ++q) {
      if (!C.ok[q]) continue;
      var sp = map(C.x[q], C.y[q]);
      if (clip && (sp.x < clip.x || sp.y < clip.y || sp.x > clip.x + clip.w || sp.y > clip.y + clip.h)) continue;
      g.brush = br; g.drawCircle(sp.x, sp.y, r); ++n;
   }
   d.cloudDrawnPhoto = n;
   return n;
};
CPStarfieldDock.prototype._tmTrails3d = function(g, model, scale, fit, proj, sc, clip, alpha, video) {
   var tm = this.tm, st = this.state;
   if (!tm || !model || model.tmT === undefined || model.tmT === 0 || !st || !st.tmd) return 0;
   try { this._tmCloud3d(g, model, scale, fit, sc, clip, alpha); } catch (eC) {}
   // (bloque F) el frente de luz y el camino de los objetos que se mueven, con o sin estelas de estrellas
   try { this._tmFront3d(g, model, scale, fit, sc, clip, alpha, video); } catch (eF) {}
   try { if (tm.trails) this._tmBodyTrails3d(g, model, scale, fit, sc, clip, alpha); } catch (eB) {}
   if (!tm.trails) return 0;
   var d = st.tmd, tr = this._tmTrailOf(d, model.tmT), K = tr.K, f = st.result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H);
   // (1-nov-2026, D11 del video de formacion: las estelas se veian casi nada —0,6 % del lienzo cambiaba al encenderlas—: trazo de 0,75·sc y opacidad de 0,03 a 0,53. Ahora
   // trazo de 1,6·sc (min. 1,5 px) y opacidad de 0,15 a 0,85; sin saturar: medido en tests/c3_d_fixes.js D11. Costura del rojo: C3_TRAIL_OLD = true.)
   var lw = C3_TRAIL_OLD ? Math.max(1, 0.75 * sc) : Math.max(1.5, 1.6 * sc), a0 = C3_TRAIL_OLD ? 0.03 : 0.15, a1 = C3_TRAIL_OLD ? 0.5 : 0.7, drawn = 0, x0 = clip.x, x1 = clip.x + clip.w, y0 = clip.y, y1 = clip.y + clip.h, stars = st.result.stars;
   g.antialiasing = true;
   var Pn = this._tmAt(d, model.tmT);          // (3A: sin estela los miembros de un cúmulo que aún no había nacido)
   for (var a = 0; a < tr.n; ++a) {
      var j = tr.idx[a], s = stars[d.tm.idx[j]], rgb = cpSvStarRgb(s.bpRp), col = (rgb[0] << 16) | (rgb[1] << 8) | rgb[2], prev = null, any = false;
      if (Pn.esc && Pn.esc[j] === 3) continue;
      if (Pn.esc && Pn.esc[j] === 2 && C3_TM_ESC_GREY === true) col = C3_TMUI.ESC_RGB;     // (decisión 2: la estela de una escapada, gris también)
      for (var k = 0; k <= K; ++k) {
         var o = a * (K + 1) + k;
         if (!isFinite(tr.X[o])) { prev = null; continue; }
         var tu = (tr.X[o] - W / 2) / big, tv = (tr.Y[o] - H / 2) / big;
         if (Math.abs(tu) > model.wn / 2 * (1 + C3_TMUI.OUT_MARGIN) || Math.abs(tv) > model.hn / 2 * (1 + C3_TMUI.OUT_MARGIN)) break;     // (fuera del haz: la estela acaba donde sale)
         var p = fit.px(tu, tv, scale.t(tr.PC[o]));
         if (!p.ok) { prev = null; continue; }
         if (prev !== null && (p.x >= x0 && p.x <= x1 && p.y >= y0 && p.y <= y1)) {
            var dx = p.x - prev.x, dy = p.y - prev.y;
            if (dx * dx + dy * dy > 0.25) { g.pen = this._pen(col, alpha * (a0 + a1 * k / K), lw); g.drawLine(prev.x, prev.y, p.x, p.y); any = true; }
         }
         prev = p;
      }
      if (any) ++drawn;
   }
   return drawn;
};
// BLOQUE F · EL FRENTE DE LUZ en la caja: un marco claro, a trazos, a la distancia que la luz recorre en |T| (comovil: la de la caja),
// con su rotulo. Hacia atras: donde estaba la luz de esta foto (lo de delante aun no la habia emitido); hacia delante: hasta donde
// habra llegado la luz que sale hoy del Sol. Si cae mas alla del fondo de la caja o pegado a la foto, no se pinta (lo dice el rotulo).
// Lo que se pinta queda en `model.tmFrontDrawn` (para las pruebas: { t, pc } o null).
// (1-nov-2026, D1 del video de formacion) el rotulo «FRENTE DE LUZ» se pintaba encima de los rotulos de zona («GRUPO LOCAL»…) y de las cifras: lo pinta la pasada de
// los objetos, DESPUES de que `_drawDist` los pusiera. Ahora `_drawDist` deja en `model.tmAvoid` las cajas ya ocupadas y el rotulo busca sitio libre (junto a su
// esquina: deslizado a los lados y subiendo de fila); si no lo hay, se queda donde estaba. `model.tmFrontBox` = la caja que pinta (las pruebas y las placas la leen).
// Costura del rojo: C3_FRONT_AVOID = false (como antes: sin esquivar).
var C3_FRONT_AVOID = true;
CPStarfieldDock.prototype._tmFront3d = function(g, model, scale, fit, sc, clip, alpha, video) {
   model.tmFrontDrawn = null; model.tmFrontBox = null;
   var F = model.tmFront;
   if (!F || !(F.pc > 0) || !(scale.hi > 0) || F.pc >= scale.hi) return;
   var t = scale.t(F.pc);
   if (!(t > 0.004 && t < 0.999)) return;
   var wn = model.wn, hn = model.hn, K = [[-1, -1], [1, -1], [1, 1], [-1, 1]], pts = [], ok = true, c;
   for (c = 0; c < 4; ++c) { var p = fit.px(K[c][0] * wn / 2, K[c][1] * hn / 2, t); if (!p.ok || Math.abs(p.x) > 30000 || Math.abs(p.y) > 30000) { ok = false; break; } pts.push(new Point(Math.round(p.x), Math.round(p.y))); }
   if (!ok) return;
   var a = (alpha > 0) ? alpha : 1, col = CP_ATLAS.text;
   g.antialiasing = true;
   // (sin relleno: casi no se veia. Medido en c3_look 3 —una pasada de cada, 20-oct—: con el velo, 35 ms de mediana al reproducir; sin
   // el, 29 y 34; sin el bloque F, 29. El ruido entre pasadas es de ~5 ms: NO esta demostrado que el velo costara. Basta el marco a trazos)
   g.pen = new Pen(cpInt(col, 0.7 * a), Math.max(1, 1.2 * sc), PenStyle_Dash); g.brush = new Brush(0x00000000);
   for (c = 0; c < 4; ++c) g.drawLine(pts[c].x, pts[c].y, pts[(c + 1) % 4].x, pts[(c + 1) % 4].y);
   g.pen = new Pen(0x00000000, 0);
   // el rotulo, encima de la esquina de arriba a la izquierda del marco (dentro del lienzo). La cifra es la de la CAJA (comovil: donde
   // esta el marco frente a las marcas del eje); pasados 10 Myr, se dice que es comovil (el rotulo de arriba da la propia de entonces).
   // (MIRADO en la primera captura de Abell 39 a −1 000 Myr: decia «966 M al» —la propia— con el marco en la marca de 1 036)
   var Fc = cpFont("text", CP_ATLAS.size.label * sc, true), lab = optT("LIGHT FRONT") + "  ·  " + this._dist(F.pc) + ((Math.abs(model.tmT) >= 1e7) ? " " + optT("(comoving)") : "");
   // (tarea H8, 21-oct: el rotulo caia sobre la nube de estrellas. Ahora va POR FUERA del marco, encima de su esquina mas alta en pantalla:
   // el haz —donde estan las estrellas— queda por debajo de ella)
   var top = pts[0]; for (c = 1; c < 4; ++c) if (pts[c].y < top.y) top = pts[c];
   var labW = Fc.width(lab), labH = Fc.ascent + Fc.descent + 4 * sc;
   var lx = Math.max(clip.x + 4 * sc, Math.min(clip.x + clip.w - labW - 4 * sc, top.x - labW / 2)), ly = Math.max(clip.y + Fc.ascent + 4 * sc, Math.min(clip.y + clip.h - 4 * sc, top.y - Fc.descent - 6 * sc));
   var avoid = (C3_FRONT_AVOID !== false && model.tmAvoid && model.tmAvoid.length) ? model.tmAvoid : null;
   function boxAt(x, y) { return { x: x - 3 * sc, y: y - Fc.ascent - 2 * sc, w: labW + 6 * sc, h: labH }; }
   function free(b) {
      if (b.x < clip.x + 2 || b.y < clip.y + 2 || b.x + b.w > clip.x + clip.w - 2 || b.y + b.h > clip.y + clip.h - 2) return false;
      for (var q = 0; q < avoid.length; ++q) { var o = avoid[q]; if (b.x < o.x + o.w && o.x < b.x + b.w && b.y < o.y + o.h && o.y < b.y + b.h) return false; }
      return true;
   }
   if (avoid !== null && !free(boxAt(lx, ly))) {
      // las esquinas de la mas alta a la mas baja; en cada una, deslizado a los lados y subiendo de fila
      var cs = pts.slice().sort(function(p1, p2) { return p1.y - p2.y; }), slides = [0, -0.5, 0.5, -1, 1, -1.5, 1.5, -2, 2], found = null, ci, rw, si;
      for (ci = 0; ci < cs.length && found === null; ++ci)
         for (rw = 0; rw < 4 && found === null; ++rw)
            for (si = 0; si < slides.length && found === null; ++si) {
               var tx = Math.max(clip.x + 4 * sc, Math.min(clip.x + clip.w - labW - 4 * sc, cs[ci].x - labW / 2 + slides[si] * labW)), ty = cs[ci].y - Fc.descent - 6 * sc - rw * (labH + 2 * sc);
               if (free(boxAt(tx, ty))) found = { x: tx, y: ty };
            }
      if (found !== null) { lx = found.x; ly = found.y; }
   }
   g.font = Fc;
   var fb = boxAt(lx, ly);
   g.fillRect(new Rect(fb.x, fb.y, fb.x + fb.w, fb.y + fb.h), new Brush(cpInt(CP_ATLAS.bg, 0.55 * a)));
   g.pen = new Pen(cpInt(col, 0.9 * a)); g.drawText(lx, ly, lab);
   model.tmFrontBox = fb;
   model.tmFrontDrawn = { t: t, pc: F.pc };
};
// BLOQUE F · EL CAMINO de cada objeto que se mueve, en la caja: de su sitio de ahora al de este instante (a trazos si su movimiento es,
// en todo o en parte, SUPUESTO).
CPStarfieldDock.prototype._tmBodyTrails3d = function(g, model, scale, fit, sc, clip, alpha) {
   var b = model.tmBase, objs = model.objects, n = 0, a = (alpha > 0) ? alpha : 1;
   if (!b || !(model.tmBodies > 0)) return 0;
   g.antialiasing = true;
   for (var i = 0; i < objs.length; ++i) {
      var c = objs[i];
      if (!c.tmShift || c.tmGone) continue;
      var o = b.objects[i], p0 = fit.px(o.u, o.v, scale.t(o.pc)), p1 = fit.px(c.u, c.v, scale.t(c.pc));
      if (!p0.ok || !p1.ok || Math.abs(p0.x) > 30000 || Math.abs(p1.x) > 30000) continue;
      if (Math.pow(p1.x - p0.x, 2) + Math.pow(p1.y - p0.y, 2) < 4) continue;
      g.pen = new Pen(cpInt(CP_ATLAS.goldLight, (c.tmAssumed ? 0.45 : 0.75) * a), Math.max(1, sc), c.tmAssumed ? PenStyle_Dash : PenStyle_Solid);
      g.drawLine(p0.x, p0.y, p1.x, p1.y);
      ++n;
   }
   g.pen = new Pen(0x00000000, 0);
   return n;
};
// La estrella hueca (sin velocidad radial): un aro de su color.
CPStarfieldDock.prototype._tmHollowDot = function(g, x, y, r, rgb, sc) {
   g.pen = this._pen(rgb, 0.95, Math.max(1, 0.8 * sc)); g.brush = new Brush(0x00000000);
   g.drawCircle(x, y, Math.max(1.6 * sc, r * 1.15));
   g.pen = new Pen(0x00000000, 0);
};

// ---------------------------------------------------------------------------
// LO QUE SE CUENTA del campo en el tiempo (ideas adicionales 1 y 2, ver HANDOFF):
//   · CUMULOS: su punto de convergencia (el apex de su movimiento en el cielo: metodo del punto convergente) y el
//     instante en que, rebobinando, es mas compacto (la «edad cinematica»; con la advertencia de que un cumulo
//     LIGADO no se dispersa: sus miembros orbitan).
//   · EL ENCUENTRO MAS CERCANO CON EL SOL de las estrellas del campo con velocidad radial.
// Una vez por imagen, movimiento y escala.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._tmInfo = function(d) {
   if (d.info && d.info.range === this.tm.range) return d.info;
   var st = this.state, tm = d.tm, res = st.result, out = { range: this.tm.range, clusters: [], closest: null }, i;
   var times = [], R = this.tm.range, N = C3_TMUI.SPREAD_N;
   for (i = 0; i < N; ++i) times.push(-R + R * i / (N - 1));
   for (var c = 0; c < res.clusters.length; ++c) {
      var cl = res.clusters[c];
      if (!cl.inFrame) continue;
      var sts = [], gaia = [], mem = [];
      for (i = 0; i < tm.n; ++i) {
         if (res.stars[tm.idx[i]].cluster !== c) continue;
         var s0 = c3TmStateAtPhoto(tm, i);
         sts.push(s0); mem.push(i);
         if (tm.rvFrom[i] === "gaia") gaia.push(s0);
      }
      if (sts.length < 10) continue;
      // (con la velocidad radial de Gaia o la del cumulo, la direccion es la de la velocidad 3D; sin ninguna, solo la del cielo: se dice)
      var conv = c3TmConvergent(sts);
      var sp = c3TmSpread(sts, times, (tm.model === "galactic") ? "linear" : tm.model), now = sp.sizes[N - 1];
      out.clusters.push({ index: c, name: String(cl.name || cl.id || ""), n: sts.length, rvGaia: gaia.length, rvKms: (tm.clusterRv[c] !== undefined) ? tm.clusterRv[c] : null,
                          apex: conv, apexErr: conv ? conv.errDeg : 0, lit: c3TmApexLiterature(cl), basis: (tm.clusterRv[c] !== undefined) ? "rv" : "pm", sizeNow: now, best: sp.best, mem: mem,
                          compactPast: (sp.best && sp.best.t < -R * 0.02 && sp.best.size < 0.8 * now) });
   }
   for (i = 0; i < tm.n; ++i) {
      if (tm.rvFrom[i] === "none") continue;
      var e = c3TmClosest(c3TmStateAtPhoto(tm, i));
      if (Math.abs(e.t) > C3_TMUI.ENCOUNTER_MAX_YR || Math.abs(e.t) < 1000) continue;
      // (solo un ENCUENTRO: que de verdad se acerque —a menos del 80 % de lo que esta hoy—; una que pasa de lado «ahora» no lo es)
      var s1 = c3TmStateAtPhoto(tm, i), dNow = Math.sqrt(s1.x * s1.x + s1.y * s1.y + s1.z * s1.z);
      if (!(e.d < 0.8 * dNow)) continue;
      if (out.closest === null || e.d < out.closest.d) out.closest = { i: i, star: tm.idx[i], t: e.t, d: e.d, g: res.stars[tm.idx[i]].g, from: tm.rvFrom[i] };
   }
   d.info = out;
   return out;
};

// (EL ROTULO del 3D —la maquina del tiempo y el polvo— vive en tm/hud.js)

// ---------------------------------------------------------------------------
// LA FOTO: la apaga un poco lejos de «ahora» (`tmPhotoDim`) y encima pinta estelas, estrellas y rotulo (`tmPaintPhoto`).
// ---------------------------------------------------------------------------
// LA FOTO EN EL TIEMPO (revision visual del 14-oct: con la foto solo apagada, sus estrellas se quedaban donde estaban y los
// marcadores en otro sitio: estrellas FANTASMA). Lejos de «ahora» la foto pasa a ser la foto SIN ESTRELLAS (nebulosas y galaxias
// se quedan; las estrellas son las que se mueven). `tmPhotoMix()` = cuanto de la sin estrellas (0…1); `tmPhotoDim()` = el brillo.
// `tm.mixOverride` (el video) manda sobre el instante: si no, al cruzar «ahora» la foto destellaba un fotograma.
CPStarfieldDock.prototype.tmPhotoMix = function() {
   if (!this.tm || !this.state || !this.state.tmd) return 0;
   if (typeof this.tm.mixOverride === "number") return this.tm.mixOverride;
   if (this.tm.t === 0) return 0;
   var s = Math.min(1, Math.abs(this.tm.t) / (C3_TMUI.DIM_AT * this.tm.range));
   return s * s * (3 - 2 * s);
};
CPStarfieldDock.prototype.tmPhotoDim = function() { return 1 - (1 - C3_TMUI.DIM) * this.tmPhotoMix(); };
// La foto sin estrellas (una vez por imagen): la de StarXTerminator / StarNet2 si los hay (la misma de las nebulosas), y si no,
// la propia (apertura morfologica, `cpSvStarlessOwn`) sobre una copia de STARLESS_MAX px de lado.
CPStarfieldDock.prototype.tmStarless = function() {
   var st = this.state;
   if (!st) return null;
   try { this._tmPrepBodies(); } catch (eB) {}          // (bloque F: tambien el video pasa por aqui antes de grabar)
   if (st.tmStarless !== undefined) return st.tmStarless;
   st.tmStarless = null;
   var busy = false, t0 = Date.now();
   try {
      try { var sl = this._nebulaStarless(st); if (sl && sl.bmp) { st.tmStarless = sl.bmp; st.tmStarlessHow = sl.engine; return sl.bmp; } } catch (eS) {}
      var src = st.photoFull || st.photo;
      if (!src) return null;
      try { this.dialog.preview.setBusy(true, optT("Taking the stars out of the photo (for the time machine)…"), false); busy = true; } catch (eB) {}
      var k = Math.min(1, C3_TMUI.STARLESS_MAX / Math.max(src.width, src.height)), w = Math.max(2, Math.round(src.width * k)), h = Math.max(2, Math.round(src.height * k));
      var small = new Bitmap(w, h), g = new Graphics(small);
      try { g.smoothInterpolation = true; g.drawScaledBitmap(new Rect(0, 0, w, h), src); } finally { g.end(); }
      var N = w * h, r = new Float32Array(N), gg = new Float32Array(N), b = new Float32Array(N), x, y, i;
      for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { var p = small.pixel(x, y); i = y * w + x; r[i] = (p >>> 16) & 255; gg[i] = (p >>> 8) & 255; b[i] = p & 255; }
      var own = this._starlessOwnRun(st, r, gg, b, w, h, 0, 0, w / src.width, h / src.height);
      for (y = 0; y < h; ++y) for (x = 0; x < w; ++x) { i = y * w + x; small.setPixel(x, y, (0xff000000 | (Math.max(0, Math.min(255, Math.round(own.r[i]))) << 16) | (Math.max(0, Math.min(255, Math.round(own.g[i]))) << 8) | Math.max(0, Math.min(255, Math.round(own.b[i])))) >>> 0); }
      st.tmStarless = small; st.tmStarlessHow = "own"; st.tmStarlessKind = own.kind; st.tmStarlessMs = Date.now() - t0;
   } catch (e) { st.tmStarless = null; }
   finally { if (busy) try { this.dialog.preview.setBusy(false); } catch (eF) {} }
   return st.tmStarless;
};
// `map( x, y ) -> { x, y }` de pixel de imagen a pixel de `g`; `sc` la escala de la interfaz; `k` cuantos pixeles de pantalla mide un
// pixel de imagen (para el tamaño de los puntos). Lo usan la foto y el video.
CPStarfieldDock.prototype._tmPaintStarsOn = function(g, map, sc, k, clip) {
   var st = this.state, tm = this.tm;
   if (!st || !tm || tm.t === 0) return 0;
   var d = this._tmData(st);
   if (!d || !d.tm.tan || d.tm.n === 0) return 0;
   var T = tm.t, P = this._tmAt(d, T), stars = st.result.stars, n = d.tm.n, i, drawn = 0, lw = Math.max(1, 0.9 * sc), nullPen = new Pen(0x00000000, 0);
   g.antialiasing = true;
   // (bloque F) las nebulosas y los demas objetos que se mueven, ANTES que las estrellas (las estrellas van encima)
   try { this._tmPaintBodiesOn(g, map, sc, k, clip); } catch (eB) {}
   // las estelas
   if (tm.trails) {
      var tr = this._tmTrailOf(d, T), K = tr.K;
      for (var a = 0; a < tr.n; ++a) {
         var s0 = stars[d.tm.idx[tr.idx[a]]], rgb = cpSvStarRgb(s0.bpRp), col = (rgb[0] << 16) | (rgb[1] << 8) | rgb[2], prev = null;
         if (P.esc && P.esc[tr.idx[a]] === 3) continue;          // (3A)
         if (P.esc && P.esc[tr.idx[a]] === 2 && C3_TM_ESC_GREY === true) col = C3_TMUI.ESC_RGB;
         for (var q = 0; q <= K; ++q) {
            var o = a * (K + 1) + q;
            if (!isFinite(tr.X[o])) { prev = null; continue; }
            var p = map(tr.X[o], tr.Y[o]);
            if (prev !== null) { var dx = p.x - prev.x, dy = p.y - prev.y; if (dx * dx + dy * dy > 0.2) { g.pen = this._pen(col, (0.04 + 0.56 * q / K) * ((s0.cluster >= 0) ? 1 : C3_TMUI.FIELD_ALPHA), lw); g.drawLine(prev.x, prev.y, p.x, p.y); } }
            prev = p;
         }
      }
   }
   // las estrellas, en su sitio de ese instante (las sin velocidad radial, huecas)
   // (MIRADO por la revision del 15-oct: a ±100 Myr las elegidas para la foto —miembros y las mas brillantes, casi todas cercanas—
   // se habian ido todas del encuadre y la foto quedaba sin un solo punto, aunque miles de estrellas lejanas seguian dentro. Si de las
   // elegidas quedan menos de 200, se pintan las que esten dentro, hasta 3 000)
   var list = d.photoIdx, inside = 0, fW = st.result.field.width, fH = st.result.field.height;
   function inF(j) { return P.ok[j] && !(P.esc && P.esc[j] === 3) && P.x[j] >= 0 && P.y[j] >= 0 && P.x[j] <= fW && P.y[j] <= fH; }
   for (var pj = 0; pj < list.length && inside < 200; ++pj) if (inF(list[pj])) ++inside;
   if (inside < 200) { list = []; for (var pk = 0; pk < n && list.length < 3000; ++pk) if (inF(pk)) list.push(pk); }
   for (var pi = 0; pi < list.length; ++pi) {
      i = list[pi];
      if (!P.ok[i]) continue;
      var esI = P.esc ? P.esc[i] : 0;
      if (esI === 3) continue;                                   // (3A: su cúmulo aún no había nacido)
      var cxI = P.cone ? P.cone[i] : 0, caI = c3TmConeAlpha(cxI);
      if (!(caI > 0)) continue;                                  // (5a: su sitio ya no se sabe; Q3: solo con el rojo C3_TM_CONE_FLOOR = false)
      var sp = map(P.x[i], P.y[i]);
      if (clip && (sp.x < clip.x - 8 || sp.y < clip.y - 8 || sp.x > clip.x + clip.w + 8 || sp.y > clip.y + clip.h + 8)) continue;
      var s = stars[d.tm.idx[i]], gm = (s.g !== null) ? s.g : 16, r = Math.max(1.1 * sc, Math.min(4.5 * sc, (17.5 - gm) * 0.38 * sc)), rg = cpSvStarRgb(s.bpRp), c = (rg[0] << 16) | (rg[1] << 8) | rg[2];
      var fa = (s.cluster >= 0) ? 1 : C3_TMUI.FIELD_ALPHA;
      if (esI === 2 && C3_TM_ESC_GREY === true) { c = C3_TMUI.ESC_RGB; fa = C3_TMUI.ESC_ALPHA; }  // (decisión 2: escapada de su cúmulo, gris tenue)
      if (cxI > 0.5) fa *= caI;                                  // (Q3: como poco al 25 %)
      if (d.tm.rvFrom[i] === "none") { g.pen = this._pen(c, 0.9 * fa, lw); g.brush = new Brush(0x00000000); g.drawCircle(sp.x, sp.y, r * 1.15); }
      else { g.pen = nullPen; g.brush = this._brush(c, fa); g.drawCircle(sp.x, sp.y, r); }
      ++drawn;
   }
   try { this._tmCloudPhoto(g, map, sc, clip); } catch (eCl) {}        // (decisión 5b: la nube de la elegida, encima)
   // LA IDEA 1: hacia donde va cada cumulo (una flecha desde su centro hacia su apex, y el rotulo)
   var info = this._tmInfo(d), f = st.result.field;
   for (i = 0; i < info.clusters.length; ++i) {
      var ci = info.clusters[i], cl = st.result.clusters[ci.index];
      if (!ci.apex || cl.x === null || cl.x === undefined || !d.tm.tan) continue;
      // el centro de sus miembros en este instante
      var mx = 0, my = 0, mn = 0;
      for (var m = 0; m < n; ++m) if (stars[d.tm.idx[m]].cluster === ci.index && P.ok[m]) { mx += P.x[m]; my += P.y[m]; ++mn; }
      if (mn === 0) continue;
      mx /= mn; my /= mn;
      // la direccion hacia el apex EN LA FOTO: un paso pequeño de la proyeccion hacia el
      var c0 = map(mx, my), toward = c3TmToward(d.tm.tan, cl.ra, cl.dec, ci.apex.ra, ci.apex.dec);
      if (toward === null) continue;
      var L = 46 * sc, ex = c0.x + toward.x * L, ey = c0.y + toward.y * L;
      g.pen = new Pen(CP_INT_AMBER, Math.max(1.5, 1.4 * sc)); g.drawLine(c0.x, c0.y, ex, ey);
      var ah = 8 * sc, ang = Math.atan2(toward.y, toward.x);
      g.drawLine(ex, ey, ex - ah * Math.cos(ang - 0.45), ey - ah * Math.sin(ang - 0.45)); g.drawLine(ex, ey, ex - ah * Math.cos(ang + 0.45), ey - ah * Math.sin(ang + 0.45));
      var Fl = cpFont("text", CP_ATLAS.size.label * sc);
      g.font = Fl; g.pen = new Pen(CP_INT_AMBERLIGHT);
      g.drawText(ex + 4 * sc * (toward.x >= 0 ? 1 : -1) - ((toward.x < 0) ? Fl.width(optT("apex")) : 0), ey + Fl.ascent / 2, optT("apex"));
   }
   return drawn;
};
// BLOQUE F · LOS OBJETOS QUE SE MUEVEN, EN LA FOTO. Una nebulosa con su capa hecha (`_tmPrepBodies`: la de «Nebula…», sin estrellas)
// se LLEVA a su sitio de este instante: en su sitio de la foto se quita su luz (el hueco, multiplicando: foto × (1 − luz/foto)) y en
// el nuevo se SUMA (CompositionOp_Add) esa misma luz —sin la ganancia de la capa 3D y con el apagado de la foto—: con desplazamiento
// cero, foto − luz + luz = la foto. Encima, el camino (de su sitio de ahora al de este instante; a trazos si es supuesto) y un aro de
// su tamaño. Lo demas que se mueve (sin capa): solo el camino y un aro pequeño. Nada se calcula aqui: las capas ya estan hechas.
CPStarfieldDock.prototype._tmPaintBodiesOn = function(g, map, sc, k, clip) {
   var st = this.state, M = this._distModel(), base = M ? M.tmBase : null;
   if (!st || !base || !(M.tmBodies > 0)) return 0;
   var f = st.result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H), objs = M.objects, n = 0, nRel = 0, i, dim = this.tmPhotoDim(), rel = [];
   function img(u, v) { return map(u * big + W / 2, v * big + H / 2); }
   var order = [];
   for (i = 0; i < objs.length; ++i) if (objs[i].tmShift) order.push(i);
   order.sort(function(a, b) { return (base.objects[b].ext || 0) - (base.objects[a].ext || 0); });
   for (var q = 0; q < order.length && q < C3_TMUI.PHOTO_BODIES * 6; ++q) {
      i = order[q];
      var c = objs[i], o = base.objects[i], key = o.kind + ":" + o.ref, bm = (st.cutsHi && st.cutsHi[key]) ? st.cutsHi[key] : (st.cuts ? st.cuts[key] : null), S = c.tmShift;
      var a0 = img(o.u, o.v), a1 = img(c.u, c.v), moved = false, mg = C3_TMUI.PHOTO_BODY_MARGIN * Math.min(base.wn, base.hn);
      // (MIRADO en la primera captura de Orion, 20-oct: una nebulosa cuya capa llega al BORDE de la foto —Sh 2-276, que la cubre entera,
      // o una cortada por un lado— al llevarla dejaba bandas oscuras y claras de canto recto en los bordes, y su hueco se sumaba al de
      // la nebulosa de dentro (M 42 quitada dos veces: un agujero negro). Solo se lleva en la foto lo que cabe ENTERO en ella; lo demas
      // se mueve en el 3D, y en la foto queda su camino.)
      var whole = bm && bm.u0 > -base.wn / 2 + mg && bm.u1 < base.wn / 2 - mg && bm.v0 > -base.hn / 2 + mg && bm.v1 < base.hn / 2 - mg;
      if (bm && whole && bm.screen && bm.front && bm.hole && nRel < C3_TMUI.PHOTO_BODIES) {
         moved = true; ++nRel;
         var r0 = img(bm.u0, bm.v0), r1 = img(bm.u1, bm.v1), cx = (bm.u0 + bm.u1) / 2, cy = (bm.v0 + bm.v1) / 2;
         var m0 = img(cx + S.du - (cx - bm.u0) * S.k, cy + S.dv - (cy - bm.v0) * S.k), m1 = img(cx + S.du + (bm.u1 - cx) * S.k, cy + S.dv + (bm.v1 - cy) * S.k);
         var gain = (bm.matte && bm.matte.gain > 0) ? bm.matte.gain : 1;
         g.smoothInterpolation = true;
         g.compositionOperator = CompositionOp_Multiply; g.opacity = 1;
         g.drawScaledBitmap(new Rect(r0.x, r0.y, r1.x, r1.y), bm.hole);
         g.compositionOperator = CompositionOp_Add; g.opacity = Math.max(0, Math.min(1, dim / gain));
         if (!c.tmGone) g.drawScaledBitmap(new Rect(m0.x, m0.y, m1.x, m1.y), bm.front);
         g.compositionOperator = CompositionOp_SourceOver; g.opacity = 1;
         rel.push(String(o.name || key) + (c.tmGone ? " (gone)" : ""));
      }
      if (c.tmGone) continue;
      // el camino y el aro
      var dx = a1.x - a0.x, dy = a1.y - a0.y;
      if (dx * dx + dy * dy >= 9) {
         g.pen = new Pen(cpInt(CP_ATLAS.goldLight, c.tmAssumed ? 0.5 : 0.8), Math.max(1, 1.1 * sc), c.tmAssumed ? PenStyle_Dash : PenStyle_Solid);
         g.drawLine(a0.x, a0.y, a1.x, a1.y);
      }
      // (el aro solo si no se ha llevado su capa —con la nebulosa entera ya en su sitio sobraba— y si es pequeño: el de una nebulosa
      // que cubre media foto era un circulo a trazos que no casaba con nada —MIRADO en Orion, 20-oct—; de esas queda el camino)
      var rr = (o.ext > 0) ? Math.max(4 * sc, o.ext * S.k * big * k) : 3.5 * sc, lim = 0.12 * Math.min(clip ? clip.w : 2000, clip ? clip.h : 2000);
      if (!moved && rr <= lim) {
         g.pen = new Pen(cpInt(CP_ATLAS.goldLight, c.tmAssumed ? 0.45 : 0.7), Math.max(1, sc), PenStyle_Dash); g.brush = new Brush(0x00000000);
         g.drawCircle(a1.x, a1.y, rr);
      }
      ++n;
   }
   g.pen = new Pen(0x00000000, 0);
   this.tm.photoBodies = { drawn: n, relocated: rel };            // (lo que se ha pintado: para las pruebas)
   return n;
};
// La direccion (unitaria, en pixeles de imagen: x a la derecha, y hacia abajo) en que se ve el punto (ra1, dec1) desde
// (ra0, dec0) EN LA FOTO: el gran circulo que los une, un paso corto, por la proyeccion ajustada.
function c3TmToward(tan, ra0, dec0, ra1, dec1) {
   var k = Math.PI / 180, a0 = ra0 * k, d0 = dec0 * k, a1 = ra1 * k, d1 = dec1 * k;
   var p0 = [Math.cos(d0) * Math.cos(a0), Math.cos(d0) * Math.sin(a0), Math.sin(d0)], p1 = [Math.cos(d1) * Math.cos(a1), Math.cos(d1) * Math.sin(a1), Math.sin(d1)];
   var dot = p0[0] * p1[0] + p0[1] * p1[1] + p0[2] * p1[2], t = [p1[0] - dot * p0[0], p1[1] - dot * p0[1], p1[2] - dot * p0[2]], tn = Math.sqrt(t[0] * t[0] + t[1] * t[1] + t[2] * t[2]);
   if (!(tn > 1e-12)) return null;
   var e = 0.01 * k, q = [p0[0] + t[0] / tn * e, p0[1] + t[1] / tn * e, p0[2] + t[2] / tn * e], sk = c3TmSky(q[0], q[1], q[2]);
   var A = c3TmTan(tan, ra0, dec0), B = c3TmTan(tan, sk.ra, sk.dec);
   if (A === null || B === null) return null;
   var dx = B.x - A.x, dy = B.y - A.y, n = Math.sqrt(dx * dx + dy * dy);
   return (n > 0) ? { x: dx / n, y: dy / n } : null;
}
// En la foto del dialogo (ui/photo_view.js, por `dialog.paintPhotoOverlay`).
CPStarfieldDock.prototype.tmPaintPhoto = function(g, pv) {
   if (!this.tm || this.tm.t === 0 || !this.state || !pv || !pv.bitmap) return 0;
   var rec = this.dialog.currentRec;
   if (!rec || this._find(cpSfUiKey(rec.view)) !== this.state) return 0;
   var self = this, sc = cpUiScale(pv.viewport), map = function(x, y) { var f = self._offAt ? self._offAt(x, y) : { dx: 0, dy: 0 }; return pv.toScreen(x + f.dx, y + f.dy); };      // (22-oct: con el desfase local foto − Gaia, ui/photo_offsets.js)
   // (recortado a la FOTO: una estrella que sale del encuadre se va, como en el video)
   var f = this.state.result.field, a = pv.toScreen(0, 0), b = pv.toScreen(f.width, f.height);
   var cx0 = Math.max(0, a.x), cy0 = Math.max(0, a.y), cx1 = Math.min(pv.viewport.width, b.x), cy1 = Math.min(pv.viewport.height, b.y);
   g.clipRect = new Rect(cx0, cy0, Math.max(cx0 + 1, cx1), Math.max(cy0 + 1, cy1));
   var n = this._tmPaintStarsOn(g, map, sc, pv.scale / pv.imageCoordScaleX, { x: cx0, y: cy0, w: cx1 - cx0, h: cy1 - cy0 });
   g.clipRect = new Rect(0, 0, pv.viewport.width, pv.viewport.height);
   // (sin rotulo aqui: ya lo dicen el 3D y la regla del tiempo, al lado; repetido tres veces era ruido —revision visual—)
   return n;
};

// ============================================================================
// BLOQUE F (20-oct-2026) — LAS COSTURAS con el panel (sin tocar starfield_panel.js: se envuelven sus metodos) y con el rotulo
// ============================================================================
// (1) EL RECORTE de un objeto se hace SIEMPRE con el modelo de AHORA (las estrellas que se le quitan y su centro, los de la foto: si la
//     primera vez que se pide es lejos de «ahora», con el modelo movido la mascara salia de otro sitio). Los indices son los mismos.
var c3TmfBaseCutOf = CPStarfieldDock.prototype._cutOf;
CPStarfieldDock.prototype._cutOf = function(st, model, cut, hi) { return c3TmfBaseCutOf.call(this, st, (model && model.tmBase) ? model.tmBase : model, cut, hi); };
// (2) EL RECORTE SE MUEVE con su objeto: se pinta con una camara «corrida» (la misma `fit`, con su px llevando cada punto de la foto
//     a su sitio de este instante: desplazado y escalado alrededor del centro del objeto). Uno que se ha ido del encuadre, no se pinta.
var c3TmfBaseDrawCutout = CPStarfieldDock.prototype._drawCutout;
CPStarfieldDock.prototype._drawCutout = function(g, st, model, fit, cut, o) {
   var ob = (model && model.objects) ? model.objects[cut.index] : null;
   if (!ob || !ob.tmShift) return c3TmfBaseDrawCutout.call(this, g, st, model, fit, cut, o);
   if (ob.tmGone) return null;
   var S = ob.tmShift, uc = ob.u - S.du, vc = ob.v - S.dv, F2 = {}, key;
   for (key in fit) F2[key] = fit[key];
   F2.px = function(u, v, t) { return fit.px(uc + S.du + (u - uc) * S.k, vc + S.dv + (v - vc) * S.k, t); };
   F2.seg = function(u0, v0, t0, u1, v1, t1) { return fit.seg(uc + S.du + (u0 - uc) * S.k, vc + S.dv + (v0 - vc) * S.k, t0, uc + S.du + (u1 - uc) * S.k, vc + S.dv + (v1 - vc) * S.k, t1); };
   return c3TmfBaseDrawCutout.call(this, g, st, model, F2, cut, o);
};

// LAS CIFRAS de lo lejano: años y distancias grandes, en miles de millones (las de siempre se quedan para lo cercano)
function c3TmfYears(yr, plate) {
   if (!(yr > 0) || !isFinite(yr)) return "—";
   if (yr >= 9.995e8) { var g = cpSvDec(String(Math.round(yr / 1e7) / 100).replace(/(\.\d)0$/, "$1")); return plate ? format(optT("%s Gyr"), g) : format(optT("%s billion years"), g); }
   return cpSvFormatYears(yr, { yr: optT("yr"), myr: optT("M yr") });
}
CPStarfieldDock.prototype._tmfDist = function(pc, plate) {
   if (this.unit === "ly" && pc * c3CosmoLyPc() >= 9.995e8) { var g = cpSvDec(String(Math.round(pc * c3CosmoLyPc() / 1e7) / 100).replace(/(\.\d)0$/, "$1")); return plate ? format(optT("%s Gly"), g) : format(optT("%s billion light years"), g); }
   return this._dist(pc);
};
// Las cifras cosmologicas de un objeto lejano de SIMBAD (con z > 0 y extragalactico), o null.
CPStarfieldDock.prototype._tmfCosmoOf = function(ob) {
   var st = this.state;
   if (!st || !ob || (ob.kind !== "galaxy" && ob.kind !== "quasar" && ob.kind !== "group") || !st.result.deepSky) return null;
   var d = st.result.deepSky.objects[ob.ref];
   if (!d || !d.extragalactic || !(d.z > 0)) return null;
   var c = c3CosmoOfZ(d.z);
   if (c) { c.d = d; c.fromZ = !!(d.dist && d.dist.kind === "redshift"); }
   return c;
};
// (3) LA PLACA de lo lejano: «z = 5,16 · luz: 12,7 G años · hoy: 26,2 G al (comóvil)» —el tiempo de viaje de la luz Y la distancia de hoy,
//     cada una con su nombre (20-oct: la placa y la ficha daban la COMOVIL como «al» a secas, mayor que el tiempo de viaje)—.
var c3TmfBasePlate = CPStarfieldDock.prototype._plateOf;
CPStarfieldDock.prototype._plateOf = function(model, idx, role) {
   var r = c3TmfBasePlate.call(this, model, idx, role);
   try {
      var ob = model.objects[idx], c = this._tmfCosmoOf(ob);
      // (21-oct) con su papel o su clase delante: «farthest quasar · z = 2,68 · light travel … · today … (comoving)»
      if (c && c.fromZ) r[1] = this._plateLabel(model, idx, role) + " · " + format(optT("z = %s · light travel %s · today %s (comoving)"), cpSvDec(c.z.toFixed((c.z < 0.1) ? 3 : 2)), c3TmfYears(c.lookbackYr, true), this._tmfDist(c.comovingPc, true));
      if (ob && ob.faint > 0 && r[1].slice(-(" · " + optT("faint")).length) !== " · " + optT("faint")) r[1] += " · " + optT("faint");      // (24-oct-2026, D1 = A': lo debil lo dice tambien aqui; la base lo pone, esta placa lo rehace)
   } catch (e) {}
   return r;
};
// (4) LA FICHA: lo lejano con sus cifras dichas como son, y en la maquina del tiempo lo que el instante le hace (el frente de luz, la
//     expansion); lo de nuestra galaxia que se mueve, DE DONDE sale su movimiento.
var c3TmfBaseCard = CPStarfieldDock.prototype._cardOfObject;
CPStarfieldDock.prototype._cardOfObject = function(idx) {
   var card = c3TmfBaseCard.call(this, idx);
   try { card = this._tmfCard(idx, card); } catch (e) {}
   return card;
};
CPStarfieldDock.prototype._tmfCard = function(idx, card) {
   var st = this.state, model = st ? st.dist : null;
   if (!card || !model || !model.objects[idx]) return card;
   var ob = model.objects[idx], bits = String(card.data || "").split("  ·  "), extra = [], T = (this.tm && this.tm.t) ? this.tm.t : 0, c = this._tmfCosmoOf(ob), self = this;
   if (bits.length === 1 && bits[0] === "") bits = [];
   if (c) {
      var keep = [];
      if (c.fromZ) {
         // la ficha de siempre decia «su luz salio hace 12 670 M años · hoy esta a 26 191 M al»: ahora las tres cifras con su nombre
         keep.push("z = " + cpSvDec(c.z.toFixed((c.z < 0.1) ? 4 : 2)));
         keep.push(format(optT("light travel time %s"), c3TmfYears(c.lookbackYr, false)));
         keep.push(format(optT("distance today (comoving) %s"), this._tmfDist(c.comovingPc, false)));
         keep.push(format(optT("when its light left, it was %s away"), this._tmfDist(c.emittedPc, false)));
         for (var b = 0; b < bits.length; ++b) if (bits[b].indexOf("z = ") !== 0 && bits[b] !== format(optT("its light left %s ago"), cpSvFormatYears(c.lookbackYr, this._words())) && bits[b] !== format(optT("today it is at %s"), this._dist(c.comovingPc))) keep.push(bits[b]);
         bits = keep;
      } else if (c3CosmoInHubbleFlow(c.z)) bits.push(format(optT("light travel time %s"), c3TmfYears(c.lookbackYr, false)));
      extra.push(format(optT("Cosmology: %s. Light travel time = how long ago its light left (lookback); distance today = comoving (proper distance now); when the light left = comoving / (1 + z)."), c3RefDec(C3_COSMO.REF)));
      if (T !== 0) {
         var M = this._distModel(), F = (M && M.tmFront) ? M.tmFront : c3CosmoLightFront(T), ls = c3CosmoLightState(ob.pc, T, F), w = c3TmTimeWords(T);
         if (ls === "not-left") bits.push(format(optT("%s: the light of this photo had not left it yet"), w));
         else if (ls === "on-way") bits.push(format(optT("%s: the light of this photo was already on its way, %s from us"), w, this._tmfDist(F.properPc, false)));
         else if (ls === "reached") bits.push(format(optT("%s: the light leaving the Sun today will have reached it"), w));
         else if (ls === "not-reached") bits.push(format(optT("%s: the light leaving the Sun today will not have reached it yet"), w));
         var mo = M ? M.objects[idx] : null;
         if (mo && mo.tmExp && mo.tmExp !== 1) bits.push(format((T < 0) ? optT("%s it was %s away (the Universe %s %% smaller)") : optT("%s it will be %s away (the Universe %s %% larger)"), w, this._tmfDist(mo.pc, false), cpSvDec(Math.abs((mo.tmExp - 1) * 100).toFixed(1))));
         else bits.push(optT("it does not move here: its motion across the sky is not measured (millionths of an arcsecond a year)"));
      }
   }
   var d = st.tmd, j = (d && d.objX) ? d.objX[idx] : -1;
   if (j >= 0 && d.tmx && d.tmx.motion[j]) {
      var m = d.tmx.motion[j];
      var src = function(k) { return (k === "simbad") ? optT("SIMBAD") : (k === "stars") ? optT("its stars (Gaia DR3)") : (k === "cluster") ? optT("its cluster") : optT("assumed (the Galaxy's rotation)"); };
      bits.push((m.pmFrom === m.rvFrom) ? format(optT("moves with: %s"), src(m.pmFrom)) : format(optT("motion: in the sky %s, in depth %s"), src(m.pmFrom), src(m.rvFrom)));
      var err = function(e, dg) { return (e > 0 && isFinite(e)) ? " ± " + cpSvDec(e.toFixed(dg)) : ""; };
      extra.push(format(optT("In the time machine: proper motion %s, %s mas/yr%s (%s) · radial velocity %s km/s%s (%s)."), cpSvDec(m.pmRa.toFixed(2)), cpSvDec(m.pmDec.toFixed(2)), err(m.pmErr, 2), m.pmRef || src(m.pmFrom),
                        cpSvDec(m.rv.toFixed(1)), err(m.rvErr, 1), m.rvRef || src(m.rvFrom)));
      var C = m.cands || {}, alt = [];
      if (C.simbad && m.pmFrom !== "simbad" && C.simbad.pmRa !== null && isFinite(C.simbad.pmRa)) alt.push(format(optT("SIMBAD gives %s, %s mas/yr%s"), cpSvDec(C.simbad.pmRa.toFixed(2)), cpSvDec(C.simbad.pmDec.toFixed(2)), err(C.simbad.pmErr, 2)));
      if (C.stars && m.pmFrom !== "stars" && C.stars.n >= C3_TMF.STARS_MIN) alt.push(format(optT("its %s Gaia stars give %s, %s mas/yr"), cpSvGroup(C.stars.n), cpSvDec(C.stars.pmRa.toFixed(2)), cpSvDec(C.stars.pmDec.toFixed(2))));
      if (alt.length) extra.push(optT("Also measured") + ": " + alt.join("; ") + ".");
      if (T !== 0) {
         var M2 = this._distModel(), q = M2 ? M2.objects[idx] : null, f = st.result.field;
         if (q && q.tmShift && f.scaleArcsec > 0) {
            var big = Math.max(f.width, f.height), mv = Math.sqrt(q.tmShift.du * q.tmShift.du + q.tmShift.dv * q.tmShift.dv) * big * f.scaleArcsec / 60;
            bits.push(format(optT("%s: %s′ from here across the sky, %s in depth"), c3TmTimeWords(T), cpSvDec(mv.toFixed(mv < 10 ? 1 : 0)), (q.pc >= ob.pc ? "+" : "−") + this._dist(Math.abs(q.pc - ob.pc))));
         }
      }
   }
   if (!c && j < 0) return card;
   var rest = String(card.full || "").split("\n").slice(3);
   card.data = bits.join("  ·  ");
   card.full = card.head + "\n" + card.name + "\n" + bits.join(" · ") + (rest.length ? "\n" + rest.join("\n") : "") + (extra.length ? "\n" + extra.join("\n") : "");
   return card;
};

// (5) LA RED: el movimiento de SIMBAD de lo de nuestra galaxia, en el MISMO paso que lo lejano (detras de el, como las nebulosas): sin
//     un paso nuevo en la cola. Si SIMBAD no contesta, se sigue (lo de sus estrellas o lo supuesto) y la ficha y el rotulo lo dicen.
var c3TmfBaseNetStep = CPStarfieldDock.prototype._netStep;
CPStarfieldDock.prototype._netStep = function() {
   var st = this.state, step = (st && !this._closed && !this._netBusy) ? this._netPending() : "";
   var r = c3TmfBaseNetStep.call(this);
   if (step === "deepsky" && st && this.state === st && !this._closed && (st.net.kin === undefined || st.net.kin === "")) this._tmfFetchKin(st);
   return r;
};
CPStarfieldDock.prototype._tmfFetchKin = function(st) {
   var self = this, label = optT("Asking SIMBAD for the motions of the nebulae and clusters…"), out = null;
   st.net.kin = "running";
   this._netBusy = true;
   try {
      try { this._say(label, "info"); } catch (eS) {}
      out = c3TmFetchKin(st.result, { httpTimeoutS: CP_SFUI_HTTP_TIMEOUT_S, onProgress: function(stage, info) { if (self._closed || cpQuiet()) return; try { self._say(label + " " + Math.round(((info && info.elapsedMs) || 0) / 1000) + " s", "info"); optProcessEvents(); } catch (eP) {} } });
      var f = st.result.field, ckey = "kin_" + f.ra.toFixed(4) + "_" + f.dec.toFixed(4) + "_" + f.radiusDeg.toFixed(4) + ".json";
      if (out && out.ok) { try { c3CacheWrite(ckey, { byName: out.byName, rows: out.rows, when: (new Date()).toISOString() }); } catch (eW) {} }
      else { var cc = null; try { cc = c3CacheRead(ckey); } catch (eR) {} if (cc && cc.byName) out = { ok: true, code: "", rows: cc.rows, byName: cc.byName, cached: true, when: cc.when }; }
   } catch (e) { out = { ok: false, code: "no-network", why: String(e.message || e) }; }
   finally { this._netBusy = false; }
   st.net.kin = (out && out.ok) ? "ok" : ("failed:" + ((out && out.code) || "no-network"));
   if (out && out.ok) { st.tmKin = out; st.tmd = null; }
   if (this.state === st && this.mode !== "" && !this._closed) { try { this._syncButtons(); this._render(); this._sayState(); } catch (eU) {} }
   // (integracion C+F, 20-oct) el paso de base ya armo el temporizador de la red ANTES de esta consulta; con la interfaz
   // atendida durante la espera (CSH_NET_PUMP, tarea C) ese disparo llega aqui dentro, ve _netBusy y se pierde, y la cadena
   // (refine, rv) no seguia: medido en c3_perf, «red acabada -1». Se vuelve a armar al acabar (no hace nada si no queda paso).
   if (!this._closed) { try { this._netArm(); } catch (eA) {} }
};

// (6) EL ROTULO (tm/hud.js, que se carga DESPUES de este fichero: se envuelve al construir el panel). Debajo de la frase de la maquina
//     del tiempo: el frente de luz (siempre), que las galaxias no se mueven (si las hay) y, con los detalles abiertos, la expansion y de
//     donde sale el movimiento de las nebulosas y los cumulos.
function c3TmfPatchHud() {
   var P = CPStarfieldDock.prototype;
   if (P._c3TmfHud === true || typeof P._hudLines !== "function") return;
   var base = P._hudLines;
   P._hudLines = function(full) { var L = base.call(this, full); try { this._tmfHud(L); } catch (e) {} return L; };
   P._c3TmfHud = true;
}
CPStarfieldDock.prototype._tmfHud = function(L) {
   var st = this.state, tm = this.tm;
   if (!st || !tm || tm.t === 0 || !L || L.length === 0) return;
   var i0 = -1, i;
   for (i = 0; i < L.length; ++i) if (L[i].k === "caps" && L[i].t === optT("TIME MACHINE")) { i0 = i; break; }
   if (i0 < 0) return;
   var at = i0 + 1;
   while (at < L.length && (L[at].k === "big" || L[at].k === "plain" || L[at].k === "warn" || L[at].k === "error")) ++at;
   var M = this._distModel(), T = tm.t, F = (M && M.tmFront) ? M.tmFront : c3CosmoLightFront(T), mine = [], open = !!tm.hudOpen;
   if (!M) return;
   // el frente de luz: cuantos de los objetos pintados quedan delante
   var tot = 0, inside = 0, gal = 0, hubN = 0, far = -1;
   for (i = 0; i < M.objects.length; ++i) {
      var ob = M.objects[i];
      if (ob.kind === "member" || ob.suspect || ob.tmGone) continue;
      ++tot; if (ob.pc < F.pc) ++inside;
      if (ob.kind === "galaxy" || ob.kind === "quasar" || ob.kind === "group") { ++gal; if (ob.tmExp) { ++hubN; if (far < 0 || ob.pc > M.objects[far].pc) far = i; } }
   }
   var cnt = (inside === tot) ? optT("all of them") : (inside === 0) ? optT("none of them") : format(optT("%s of %s"), cpSvGroup(inside), cpSvGroup(tot)), w = c3TmTimeWords(T);
   mine.push({ k: "plain", t: (T < 0) ? format(optT("Light front (the pale dashed frame): %s the light that makes this photo was %s from us; of what you see, %s had not yet sent it."), w, this._tmfDist(F.properPc, false), cnt)
                                      : format(optT("Light front (the pale dashed frame): %s the light leaving the Sun now will be %s away; of what you see, %s will have received it."), w, this._tmfDist(F.properPc, false), cnt) });
   // (lo de las galaxias, con los detalles abiertos: plegado, el rotulo crecia dos lineas mas y tapaba el 3D —MIRADO en las Pleyades
   // a −100 000 años—; su ficha lo dice siempre)
   if (gal > 0 && open) mine.push({ k: "small", t: optT("Galaxies and quasars do not move here: their motion across the sky (millionths of an arcsecond a year) is measured for almost none of them.") });
   // (la expansion, solo cuando pasa del 0,05 %: a ±1 Myr era «0,007 % mas cerca; en la caja, 0,00 %», ruido en el rotulo —MIRADO—)
   if (open && hubN > 0 && far >= 0 && Math.abs(M.tmScale - 1) >= 5e-4) {
      var aT = M.tmScale, sc0 = cpSvDistScale(this.scaleMode, M, this.unit), fo = M.objects[far], dt = Math.abs(sc0.t(fo.pc) - sc0.t(fo.pc / aT)) * 100;
      mine.push({ k: "small", t: format((T < 0) ? optT("Cosmic expansion: %s the far galaxies were %s %% closer (scale factor %s); in the box, %s %% of its depth.") : optT("Cosmic expansion: %s the far galaxies will be %s %% farther (scale factor %s); in the box, %s %% of its depth."),
                                         w, cpSvDec(Math.abs((aT - 1) * 100).toFixed(aT > 0.999 && aT < 1.001 ? 3 : 1)), cpSvDec(aT.toFixed(4)), cpSvDec(dt.toFixed(dt < 1 ? 2 : 1))) });
   }
   var d = st.tmd;
   if (open && d && d.tmx && d.tmx.n > 0) {
      var cN = d.tmx.counts;
      mine.push({ k: "small", t: format(optT("Nebulae and clusters move like the stars (%s): %s with a measured motion (SIMBAD or their own Gaia DR3 stars), %s with a motion partly or wholly assumed (the Galaxy's rotation, where nothing is measured)."),
                                        cpSvGroup(d.tmx.n), cpSvGroup(cN.measured), cpSvGroup(cN.partial + cN.assumed)) + ((String(st.net.kin || "").indexOf("failed:") === 0) ? " " + optT("(SIMBAD did not answer: their own motions are missing.)") : "") });
   }
   for (i = mine.length - 1; i >= 0; --i) L.splice(at, 0, mine[i]);
};
