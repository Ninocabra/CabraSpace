// ============================================================================
// tm/netstatus.js — DE DONDE SALE CADA DATO, Y QUE PASA CUANDO LA RED FALLA (encargo de Nino, 15-oct-2026)
// ----------------------------------------------------------------------------
// GAIA LOCAL PRIMERO: lo que trae la base Gaia DR3 de ESTE PixInsight (el proceso Gaia, ficheros .xpsd) se lee de alli:
// posicion (J2016), paralaje, movimiento propio, G, BP, RP y banderas —las columnas de `cpSfGaiaSearch`—. A la red solo va lo
// que la base no tiene: el error real de la paralaje, el RUWE y las distancias de Bailer-Jones (VizieR), las velocidades
// radiales (VizieR, I/355/gaiadr3; si no contesta, GAVO gaia.dr3lite —27-oct—), las temperaturas (VizieR, I/355/paramp), lo lejano y las nebulosas (SIMBAD) y el mapa de
// polvo (Zenodo). Sin base local, el panel lo dice y no abre (no hay de donde sacar las estrellas).
// DISTINGUIR SIEMPRE: un servidor que no contesta (sin conexion, tope de tiempo), uno que contesta con un error (HTTP 5xx,
// 4xx), un catalogo que no cubre el campo y un campo que de verdad no tiene nada son cosas distintas, y se dicen distintas:
// QUE servidor, QUE codigo, y «↻ Retry». Un fallo de red NUNCA sale como «no hay estrellas»: el 3D sigue con la base local
// y se dice que falta (RV: estrellas huecas; polvo; galaxias).
// COMO: `cpSfHttpText` (el unico camino a VizieR y SIMBAD) se envuelve para apuntar el ultimo fallo (servidor, codigo,
// mensaje); el polvo apunta el suyo en `c3CurlRanges` (tm/dust_run.js). Cada paso de red guarda el suyo en `st.netWhy`.
// ES5.
// ============================================================================

var C3_NET_LAST = null;                      // el ultimo fallo de red: { server, code, message }
// (22-oct-2026, la cadena del afinado de CabraShared F2) los respaldos, por su nombre: el espejo de CfA y el de NAO son VizieR
// pero no el de CDS (se dicen aparte: si cae CDS y contesta CfA, «VizieR» solo confundiria); GAVO (Heidelberg) por su nombre,
// no por el host (antes salia «dc.g-vo.org»).
function c3NetServerOf(url) {
   var u = String(url || "");
   return /cfa[.]harvard[.]edu/i.test(u) ? "VizieR CfA" : /nao[.]ac[.]jp/i.test(u) ? "VizieR NAO" : /g-vo[.]org/i.test(u) ? "GAVO" :
          /ari[.]uni-heidelberg/i.test(u) ? "ARI Heidelberg" : /tapvizier|vizier/i.test(u) ? "VizieR" : /simbad/i.test(u) ? "SIMBAD" : /zenodo/i.test(u) ? "Zenodo" : /gea[.]esac[.]esa[.]int/i.test(u) ? "ESA" : (u.replace(/^https?:[/][/]/, "").split("/")[0] || "?");   // (OJO: dos barras seguidas son un comentario para el preprocesador de PJSR)
}
// (22-oct-2026) Las consultas de Cabra3D siguen las redirecciones (-L, como las capas de CabraStars —csh_netfail.js— y los rangos del
// polvo): un servicio que se muda deja una redireccion y no un fallo. Sin reintento por defecto (el afinado ya lleva el suyo, en la
// cadena): un 503 o un plazo agotado no tardan mas en decirse. (CSH_HTTP_DEFAULTS: CabraShared/csh_net.js, F2.2)
if (typeof CSH_HTTP_DEFAULTS === "object" && CSH_HTTP_DEFAULTS !== null) CSH_HTTP_DEFAULTS.follow = true;
var c3BaseHttpText = cpSfHttpText;
cpSfHttpText = function(url, opts) { return c3NetNote(url, c3BaseHttpText(url, opts)); };
// (15-oct, CabraShared: el afinado prueba VizieR y, si no contesta, el archivo de ESA. Si fallan los DOS, se dicen los dos
// —«VizieR / ESA: HTTP 503»—, no solo el ultimo)
// (29-oct-2026 (noche)) La misma cuenta para las peticiones que hace el lote comun (../CabraShared/csh_batch.js, varias a la vez): no pasan por
// cpSfHttpText, asi que el lote llama a CSH_HTTP_NOTE con cada una.
function c3NetNote(url, r) {
   if (r && !r.ok) {
      var sv = c3NetServerOf(url), prev = C3_NET_LAST;
      if (prev && prev.server && prev.server.split(" / ").indexOf(sv) < 0 && prev.code === ((typeof r.code === "number") ? r.code : 0)) sv = prev.server + " / " + sv;
      C3_NET_LAST = { server: sv, code: (typeof r.code === "number") ? r.code : 0, message: String(r.message || "") };
   }
   return r;
}
if (typeof CSH_HTTP_NOTE !== "undefined") CSH_HTTP_NOTE = c3NetNote;
// La clase de un fallo: "server" (contesto con 5xx: el servidor esta caido o en apuros), "refused" (4xx), "timeout" (no contesto
// a tiempo), "offline" (no hubo conexion: sin red, o el nombre no resuelve). (En rojo, C3_NET_MUTATE: todo pasa por «no hay nada».)
var C3_NET_MUTATE = false;
function c3NetKind(rec) {
   if (C3_NET_MUTATE) return "empty";
   if (!rec) return "offline";
   if (rec.bad === true) return "bad";
   return cshNetKind4(rec.code, rec.message, false);    // (comun: ../CabraShared/csh_net.js)
}
// La frase corta (para la linea de estado): «VizieR: HTTP 503 (server error)», «SIMBAD: no answer in 15 s», «Zenodo: no connection».
function c3NetShort(rec) {
   var k = c3NetKind(rec), s = (rec && rec.server) ? rec.server : "?";
   if (k === "server") return format(optT("%s: HTTP %s (the server is failing)"), s, String(rec.code));
   if (k === "refused") return format(optT("%s: HTTP %s (the request was refused)"), s, String(rec.code));
   if (k === "timeout") return format(optT("%s did not answer in time"), s);
   if (k === "empty") return format(optT("%s: nothing in this field"), s);
   if (k === "bad") return format(optT("%s answered something that is not the table"), s) + c3NetMore(rec);
   return format(optT("%s: no connection (no network?)"), s) + c3NetMore(rec);
}
// (los demas grupos de la cadena, si fallaron de otra manera: «VizieR / GAVO: HTTP 503 (…); ESA did not answer in time»)
function c3NetMore(rec) {
   if (!rec || !rec.groups || !rec.groups.length) return "";
   var out = "";
   for (var i = 0; i < rec.groups.length; ++i) out += "; " + c3NetShort(rec.groups[i]);
   return out;
}

// EL AFINADO EN CADENA (CabraShared F2.3: VizieR -> GAVO -> ESA con Bailer-Jones -> espejo CfA -> ESA sin union). `refine.attempts`
// = [{ server, id, kind ("ok" | "http" | "timeout" | "offline" | "bad"), http, ms }].
var C3_NET_CHAIN_NAMES = { vizier: "VizieR", gavo: "GAVO", "esa-bj": "ESA", "idia-asu": "VizieR IDIA", "nao-asu": "VizieR NAO", "vizier-mirror": "VizieR mirror", "cfa-asu": "VizieR CfA", esa: "ESA" };
function c3NetChainName(a) { return (a && C3_NET_CHAIN_NAMES[a.id]) ? C3_NET_CHAIN_NAMES[a.id] : String((a && a.server) || "?"); }
// Los fallos de la cadena -> UN registro como el de C3_NET_LAST, con los que fallaron IGUAL juntos («VizieR / GAVO / ESA: HTTP 503»)
// y, en `groups`, los que fallaron de otra manera. null si no fallo ninguno.
function c3NetChainWhy(att) {
   if (!att || !att.length) return null;
   var groups = [], byKey = {};
   for (var i = 0; i < att.length; ++i) {
      var a = att[i];
      if (!a || a.kind === "ok") continue;
      var kind = String(a.kind || "offline"), key = kind + "/" + (a.http | 0), nm = c3NetChainName(a), g = byKey[key];
      if (!g) {
         g = byKey[key] = { server: nm, code: (kind === "http") ? (a.http | 0) : 0, message: (kind === "timeout") ? "no answer in time" : "", bad: (kind === "bad") };
         groups.push(g);
      } else if (g.server.split(" / ").indexOf(nm) < 0) g.server += " / " + nm;
   }
   if (!groups.length) return null;
   var rec = groups[0];
   rec.groups = groups.slice(1);
   return rec;
}
// El afinado salio, pero NO de VizieR (CDS): quien lo dio, si trae Bailer-Jones y por que no fue VizieR. null si fue VizieR.
function c3NetRefineVia(ref) {
   if (!ref || !ref.ok || ref.chain !== "full" || !ref.serverId || ref.serverId === "vizier") return null;
   var used = null;
   for (var i = 0; ref.attempts && i < ref.attempts.length; ++i) if (ref.attempts[i].kind === "ok") used = ref.attempts[i];
   return { id: ref.serverId, name: used ? c3NetChainName(used) : String(ref.server || "?"), full: String(ref.server || "?"), bj: (ref.fallback !== true),
            why: c3NetChainWhy(ref.attempts) };
}

// Cada paso de red guarda POR QUE fallo (el ultimo fallo de su consulta).
var c3NsBaseNetStep = CPStarfieldDock.prototype._netStep;
CPStarfieldDock.prototype._netStep = function() {
   var st = this.state, step = this._netPending();
   C3_NET_LAST = null;
   var done = c3NsBaseNetStep.call(this);
   if (st && step !== "") {
      st.netWhy = st.netWhy || {};
      var ref = (step === "refine" && st.result) ? st.result.refine : null, chainWhy = (ref && ref.chain === "full") ? c3NetChainWhy(ref.attempts) : null;
      // (27-oct: la RV tambien va en cadena —VizieR y GAVO, tm/timemachine_run.js—: el porque, de sus intentos, no del ultimo fallo suelto)
      if (step === "rv") chainWhy = c3NetChainWhy(st.tmRvAttempts);
      if (String(st.net[step] || "").indexOf("failed:") === 0) st.netWhy[step] = chainWhy || C3_NET_LAST || { server: (step === "deepsky" || step === "names") ? "SIMBAD" : "VizieR", code: 0, message: "" };
      else delete st.netWhy[step];
      if (step === "refine") st.refineVia = c3NetRefineVia(ref);
      this._c3RetrySync();
      // (el paso ya dijo su linea ANTES de que se supiera el porque: se vuelve a decir, ya con el servidor y el codigo)
      if (this.state === st && this.mode !== "" && !this._closed) this._sayState();
   }
   return done;
};
// ¿Algo de la red fallo? (lo que hay que reintentar)
CPStarfieldDock.prototype._c3NetFailed = function() {
   var st = this.state, out = [];
   if (!st || !st.net) return out;
   ["refine", "deepsky", "rv", "names"].forEach(function(k) { if (String(st.net[k] || "").indexOf("failed:") === 0 && String(st.net[k]).substring(7) !== "no-objects") out.push(k); });
   // (5-nov-2026) el catalogo de nebulosas sin bajar: las nebulosas van en el paso «deepsky», asi que se repite ese paso
   if ((c3NetNebNoCatalog(st) || c3NetNebPartial(st)) && out.indexOf("deepsky") < 0) out.push("deepsky");
   return out;
};
// (5-nov-2026) ¿Falta el catalogo de nebulosas? (no va en el paquete —CPD 7.3—: CabraShared/csh_thirdparty.js lo baja de VizieR la primera
// vez; si no se pudo, la nebulosa de la foto no se coloca a su distancia y se queda en el plano de la foto). Costura del rojo:
// C3_NET_NEB_WARN = false (como antes: ni se dice ni «↻ Retry» lo vuelve a pedir).
var C3_NET_NEB_WARN = true;
function c3NetNebNoCatalog(st) { return C3_NET_NEB_WARN === true && !!st && !!st.net && String(st.net.nebula || "") === "failed:no-nebula-catalog"; }
// (KC2 H7, 5-nov) ¿El catalogo llego A MEDIAS? (Sharpless si, Foster-Brunt o WISE no: las nebulosas del campo se colocan, pero alguna sin su
// distancia). Solo cuenta si en ESTE campo hay nebulosas (`ok`): si no, no hay nada que reintentar. Costura del rojo: C3_NET_NEB_PARTIAL = false.
var C3_NET_NEB_PARTIAL = true;
function c3NetNebPartial(st) {
   if (C3_NET_NEB_WARN !== true || C3_NET_NEB_PARTIAL !== true || !st || !st.result || !st.result.nebulae) return false;
   var nb = st.result.nebulae;
   return nb.ok === true && nb.catalogPartial === true && String((st.net && st.net.nebula) || "") === "ok";
}
// «↻ Retry»: vuelve a pedir lo que fallo (los pasos de la cola; el polvo, si estaba encendido y fallo, se vuelve a pedir con «Dust»).
CPStarfieldDock.prototype.c3NetRetry = function() {
   var st = this.state, f = this._c3NetFailed();
   if (!st || f.length === 0) return 0;
   if (c3NetNebNoCatalog(st) || c3NetNebPartial(st)) { st.nebForce = true; st.net.nebula = ""; }      // (5-nov: el catalogo de nebulosas —entero o lo que falto—, ya, sin esperar al sello .fail)
   for (var i = 0; i < f.length; ++i) st.net[f[i]] = "";
   st.netWhy = {};
   if (typeof cshNfResetBreakers === "function") { try { cshNfResetBreakers(); } catch (eB) {} }
   this._c3RetrySync();
   this._say(optT("Retrying the online sources…"), "info");
   this._netArm();
   return f.length;
};
CPStarfieldDock.prototype._c3RetrySync = function() {
   if (!this.btnRetry) return;
   var f = this._c3NetFailed();
   cpSetControlVisible(this.btnRetry, f.length > 0 && !this._netBusy);
};

// LA LINEA DE ESTADO, por partes: lo que falta por la red (corto) y, en el tooltip, DE DONDE SALE CADA DATO con sus cifras.
// Devuelve { net: [frases cortas], warn, detail }.
var C3_NET_FAR_WARN = true;      // (27-oct-2026, D3: la costura del rojo; false = como antes, GLADE+/Quaia caidos solo en el tooltip)
CPStarfieldDock.prototype._c3NetLine = function() {
   var st = this.state, net = [], warn = false, D = [];
   if (!st || !st.net) return { net: net, warn: warn, detail: "" };
   net.push = function(t) { if (this.indexOf(t) < 0) Array.prototype.push.call(this, t); };   // (el mismo servidor y el mismo fallo, una vez)
   var why = st.netWhy || {}, r = st.result, i;
   function failed(k) { return String(st.net[k] || "").indexOf("failed:") === 0; }
   // lo local
   var n = r.stars ? r.stars.length : 0;
   D.push(format(optT("From this PixInsight (local Gaia DR3 database): positions, parallaxes, proper motions and G, BP, RP of %s stars."), cpSvGroup(n)));
   // VizieR: el afinado de las distancias
   if (failed("refine")) { net.push(c3NetShort(why.refine)); warn = true; D.push(c3NetShort(why.refine) + " — " + optT("distances from the local parallaxes only (no real errors, no RUWE, no Bailer-Jones).")); }
   else if (st.net.refine === "ok" && r.refine) {
      var dd = [], k = 0;
      for (i = 0; i < r.stars.length; ++i) { var s = r.stars[i]; if (s.refined && s.plx !== null && isFinite(s.refined.plx)) dd.push(Math.abs(s.plx - s.refined.plx)); }
      dd.sort(function(a, b) { return a - b; });
      var via = st.refineVia || null, ddm = dd.length ? cpSvFx(dd[dd.length >> 1], 4) : "?";
      if (!via) D.push(format(optT("VizieR: real parallax errors, RUWE and Bailer-Jones distances for %s stars; local against VizieR parallax: median difference %s mas (%s stars differ by more than 0.001 mas and keep the local one)."),
                         cpSvGroup(r.refine.matched), ddm, cpSvGroup(r.refine.plxMismatch)));
      else {
         // (22-oct, la cadena: VizieR no dio la tabla y la dio un respaldo; se dice en la linea —quien y por que— y aqui, con sus cifras)
         var vw = via.why ? c3NetShort(via.why) : optT("VizieR did not answer");
         net.push(format(via.bj ? optT("%s — distances from %s") : optT("%s — distances from %s, without Bailer-Jones"), vw, via.name));
         if (!via.bj) warn = true;
         D.push(format(via.bj ? optT("%s (backup for VizieR): real parallax errors, RUWE and Bailer-Jones distances for %s stars; local against its parallax: median difference %s mas (%s stars differ by more than 0.001 mas and keep the local one).")
                              : optT("%s (backup for VizieR): real parallax errors and RUWE for %s stars, WITHOUT Bailer-Jones distances (distances from the parallax); local against its parallax: median difference %s mas (%s stars differ by more than 0.001 mas and keep the local one)."),
                       via.full, cpSvGroup(r.refine.matched), ddm, cpSvGroup(r.refine.plxMismatch)) + " " + vw + ".");
      }
   }
   // VizieR: las velocidades radiales
   if (failed("rv")) { net.push(c3NetShort(why.rv)); warn = true; D.push(c3NetShort(why.rv) + " — " + optT("no radial velocities: in the time machine every star is hollow (assumed 0).")); }
   else if (st.net.rv === "ok" && st.tmRv) {
      // (27-oct-2026) la RV en cadena (VizieR -> GAVO): si la dio GAVO, se dice en la linea —quien fallo y de donde salen— y aqui con su cifra,
      // como el afinado. Si salio de la cache, de que servidor era y por que no se pudo pedir ahora.
      var rvT = st.tmRv, rvWhy = c3NetChainWhy(rvT.attempts), rvVia = (rvT.serverId && rvT.serverId !== "vizier");
      var rvCache = rvT.cached ? " " + (rvWhy ? format(optT("(from the cache: %s)"), c3NetShort(rvWhy)) : optT("(from the cache: VizieR did not answer)")) : "";
      if (!rvVia) D.push(format(optT("VizieR: %s radial velocities (Gaia DR3)%s."), cpSvGroup(rvT.matched), rvCache));
      else {
         var rvW = rvWhy ? c3NetShort(rvWhy) : optT("VizieR did not answer");
         if (!rvT.cached) net.push(format(optT("%s — radial velocities from %s"), rvW, c3NetChainName({ id: rvT.serverId, server: rvT.server })));
         // (28-oct: tambien ESA, tercer servidor —tm/timemachine_run.js—: la tabla, la de quien la dio; la frase traducida es la misma)
         var rvTab = (typeof C3_TM_RV_TABLE === "object" && C3_TM_RV_TABLE[rvT.serverId]) ? C3_TM_RV_TABLE[rvT.serverId] : "gaia.dr3lite";
         D.push(format(optT("%s (backup for VizieR): %s radial velocities (Gaia DR3, gaia.dr3lite)%s."), String(rvT.server || "?"), cpSvGroup(rvT.matched), rvCache).replace("gaia.dr3lite", rvTab) + (rvT.cached ? "" : " " + rvW + "."));
      }
      // (30-oct, decision D de Nino) si la correccion de la RV no se pudo aplicar (GAVO no trae las columnas y la ESA calla; c3TmRvCorrect), se dice: la misma estrella diria otra cosa en los otros scripts
      if (rvT.corr && rvT.corr.on === true && rvT.corr.ok === false) D.push(optT("Radial velocities uncorrected: the server that answered does not give the RVS magnitude and the ESA archive did not answer, so Gaia's bias (Katz et al. 2023) stays in, about 0.2 km/s."));
   }
   // SIMBAD
   if (failed("deepsky")) {
      var code = String(st.net.deepsky).substring(7);
      if (code === "no-objects") D.push(optT("SIMBAD answered: no galaxy or quasar with a distance in this field."));
      else { net.push(c3NetShort(why.deepsky)); warn = true; D.push(c3NetShort(why.deepsky) + " — " + optT("no galaxies, quasars or nebulae from SIMBAD: stars and clusters only.")); }
   } else if (st.net.deepsky === "ok") {
      // (28-oct-2026, tarde) la reserva de SIMBAD (CabraShared csh_net.js cshSimbadGet): si lo lejano o las nebulosas salieron del espejo de Harvard,
      // se dice en la linea —quien contesto— y en el tooltip, igual que el afinado y la RV. Los datos: result.deepSky / result.nebulae .server / .fallback
      var dsMir = (r.deepSky && r.deepSky.fallback === true) ? String(r.deepSky.server || "SIMBAD") : "";
      if (dsMir.length > 0) {
         net.push(format(optT("SIMBAD (CDS) did not answer — answered by %s"), dsMir));
         D.push(format(optT("%s (backup for SIMBAD (CDS)): the galaxies, quasars and nebulae of the field."), dsMir));
      } else D.push(optT("SIMBAD: the galaxies, quasars and nebulae of the field."));
   }
   // (5-nov-2026) SIN CATALOGO DE NEBULOSAS: en la linea (no solo en la consola), con el porque en el tooltip
   if (c3NetNebNoCatalog(st)) {
      var ncWhy = String((r.nebulae && r.nebulae.catalogWhy) || "").replace(/^\s+|\s+$/g, "") || optT("VizieR did not answer");
      net.push(optT("nebula catalogue not downloaded: the nebula stays on the photo")); warn = true;
      D.push(format(optT("Sharpless nebula catalogue (VizieR): %s. It is not included in the package (licence): it is downloaded the first time it is needed, and without it the nebula of the photo stays on the photo plane instead of at its distance. «↻ Retry» tries again now."), ncWhy));
   }
   // (KC2 H7, 5-nov) CATALOGO A MEDIAS: la nebulosa se coloca, pero la distancia de Foster-Brunt o de WISE no llego
   if (c3NetNebPartial(st)) {
      var npWhy = String(r.nebulae.catalogWhy || "").replace(/^\s+|\s+$/g, "") || optT("VizieR did not answer");
      net.push(optT("nebula catalogue incomplete: some nebula distances missing")); warn = true;
      D.push(format(optT("Nebula distance tables (VizieR, Foster & Brunt 2015 and WISE H II): %s. The nebulae are placed, but without these distances some may fall back on a less precise one. «↻ Retry» tries again now."), npWhy));
   }
   if (r.nebulae && r.nebulae.ok === true && r.nebulae.simbad === "ok" && r.nebulae.fallback === true) {
      var nbMir = String(r.nebulae.server || "SIMBAD");
      net.push(format(optT("SIMBAD (CDS) did not answer — answered by %s"), nbMir));
      D.push(format(optT("%s (backup for SIMBAD (CDS)): the distances of the nebulae of the field."), nbMir));
   }
   // (27-oct-2026, D3) LO LEJANO DE VizieR (GLADE+ y Quaia, CabraShared/csh_depth_run.js): si no contesta, el paso de lo lejano sigue «ok»
   // (SIMBAD si contesto) pero faltan las galaxias y los cuasares mas lejanos, y el «mas lejano» del campo es otro, mas cercano (en NGC 1560,
   // NGC 1560 misma en vez de un cuasar de z = 1,63). Antes solo lo decia el tooltip de la profundidad: ahora es un aviso de la linea.
   var ex = (st.net.deepsky === "ok" && r.deepSky && r.deepSky.extra) ? r.deepSky.extra : null, exNo = [], exRec = null;
   if (ex) {
      if (ex.glade && ex.glade.ok === false) { exNo.push("GLADE+"); exRec = exRec || ex.glade.net; }
      if (ex.quaia && ex.quaia.ok === false) { exNo.push("Quaia"); exRec = exRec || ex.quaia.net; }
   }
   if (exNo.length > 0 && C3_NET_FAR_WARN === true) {
      var exS = exRec ? c3NetShort(exRec) : format(optT("%s did not answer in time"), "VizieR");
      net.push(format(optT("%s — no %s"), exS, exNo.join(" / "))); warn = true;
      D.push(exS + " — " + format(optT("without %s: the farthest galaxies and quasars of the field may be missing, so the farthest object shown may not be the farthest in the photo."), exNo.join(" / ")));
   }
   // (29-oct-2026, P8) GLADE+ / Quaia de un ESPEJO de VizieR (CabraShared csh_net.js cshVizierGet): se dice quien contesto, como la reserva de SIMBAD
   var exMir = [], exMirSv = "";
   if (ex) {
      if (ex.glade && ex.glade.ok === true && ex.glade.fallback === true) { exMir.push("GLADE+"); exMirSv = exMirSv || String(ex.glade.server || ""); }
      if (ex.quaia && ex.quaia.ok === true && ex.quaia.fallback === true) { exMir.push("Quaia"); exMirSv = exMirSv || String(ex.quaia.server || ""); }
   }
   if (exMir.length > 0) {
      net.push(format(optT("VizieR (CDS) did not answer — %s from %s"), exMir.join(" / "), exMirSv || "VizieR"));
      D.push(format(optT("%s (backup for VizieR (CDS)): %s, the farthest galaxies and quasars of the field."), exMirSv || "VizieR", exMir.join(" / ")));
   }
   // SIMBAD: los nombres legibles de lo destacado (solo en el tooltip: si falla, las placas se quedan con el «Gaia DR3 <id>»)
   if (failed("names")) D.push(c3NetShort(why.names) + " — " + optT("no readable names from SIMBAD: the plates keep their Gaia DR3 number."));
   else if (st.net.names === "ok" && st.namesFound > 0) D.push(format(optT("SIMBAD: highlighted objects with a readable name instead of their Gaia DR3 number: %s."), cpSvGroup(st.namesFound)));
   // el polvo y las temperaturas (si se pidieron)
   if (st.dustFail) { net.push(c3NetShort(st.dustFail)); warn = true; D.push(c3NetShort(st.dustFail) + " — " + optT("no dust map.")); }
   else if (st.dust && st.dust.ok) D.push(format(optT("Zenodo: the 3D dust map (Edenhofer et al. 2024), %s lines of sight%s."), cpSvGroup(st.dust.cells.length), st.dust.cached ? " " + optT("(from the cache)") : ""));
   if (st.dustTeff && !st.dustTeff.ok && st.dustTeffWhy) D.push(c3NetShort(st.dustTeffWhy) + " — " + optT("no Gaia temperatures: no check of the reddening."));
   // la foto SIN ESTRELLAS (capas de las nebulosas y maquina del tiempo): con que motor, y si es el propio, que con StarXTerminator o StarNet2 saldria mas limpio
   var how = "";
   if (st.starless && (st.starless.method === "SXT" || st.starless.method === "SN2")) how = String(st.starless.engine);
   else if (st.tmStarlessHow && st.tmStarlessHow !== "own") how = String(st.tmStarlessHow);
   else if (st.starless && st.starless.method === "own" && st.starless.ownKind) how = this._starlessOwnName(st.starless.ownKind);
   else if (st.tmStarlessHow === "own") how = this._starlessOwnName(st.tmStarlessKind || "opening");
   if (how.length > 0) {
      var ownHow = (how.indexOf("StarXTerminator") !== 0 && how.indexOf("StarNet2") !== 0);
      D.push(format(optT("Stars of the photo (nebula layers and time machine) removed with %s."), how) + (ownHow ? " " + optT("StarXTerminator or StarNet2, if you have them, give a cleaner result.") : ""));
   }
   return { net: net, warn: warn, detail: D.join("\n") };
};

// (28-oct-2026, tarde) lo lejano y las nebulosas con la reserva de SIMBAD: su castellano esta en i18n/cabra3d.jsh (29-oct: movido alli desde aqui)
