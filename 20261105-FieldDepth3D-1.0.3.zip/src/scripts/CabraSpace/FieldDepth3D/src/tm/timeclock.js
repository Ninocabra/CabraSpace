// ============================================================================
// tm/timeclock.js — EL RELOJ ANALÓGICO de los vídeos de la máquina del tiempo (Cabra3D, fase 2, 25-oct-2026)
// ----------------------------------------------------------------------------
// Petición de Nino: «aplica este reloj en todos los vídeos en los que quieras enseñar evolución temporal». La fase 1 lo puso en
// CabraComposition (II y III); aquí, en los vídeos de la máquina del tiempo: Campo (foto + 3D, 3D, foto) y Galaxia (mapa, foto + galaxia).
// El dibujo, la geometría y la variante (A, la elegida por Nino: esfera de 300°, una manecilla, la cifra exacta pequeña debajo) son los
// COMUNES de CabraShared/csh_clock.js; esto es solo el pegamento de Cabra3D: la escala de la máquina del tiempo (cshClockScaleSymYears:
// «hoy» arriba, pasado a la izquierda, futuro a la derecha, en la unidad de cada rango), el radio según el fotograma, la geometría cacheada
// y el dibujo con la letra de Cabra3D.
//   DÓNDE va: lo decide quien lo pinta (tm/timemachine_video.js: la esquina con menos escena debajo, medida en cinco instantes del guion;
//   o columna del recuadro 3D; la placa del mapa de la Galaxia —csh_galaxy_paint.js— lo lleva como una fila propia).
//   El PANEL EN VIVO también lo lleva desde el 26-oct (Nino: «no me aparece el reloj»; sustituye a la decisión del 25-oct de no ponerlo):
//   tm/timeclock_panel.js, y para no decir el instante dos veces, el reloj SUSTITUYE a la cifra de junto a la regla y a la línea grande del rótulo.
// ES5. Comentarios en castellano.
// ============================================================================

// R_K: el radio en fracción del lado corto del fotograma. 26-oct (Nino: «en los vídeos el reloj es demasiado grande»): 70 px a 1080p (antes 104,
// −33 %); y esa misma tarde, «las cifras se ven pequeñas»: 78 px (−25 %; cifras ~12 px). Lo de debajo es de los 70 px:
// −33 %; cifras de 10,9 px en lugar de 16). TALL: en vertical 1,25 veces mayor (en un móvil todo se ve pequeño). W_CAP: la esfera no pasa de
// esta fracción del ancho de lo que la contiene (el recuadro 3D).
// FACE_A: la opacidad del FONDO de la esfera y de la pastilla (las líneas, cifras, manecilla y texto, plenas): se intuye la escena. CAP_MIN_PX: el
// suelo de la cifra exacta (a R 70 saldría a 10,5 px). TXT_K: las filas de texto bajo la esfera del Campo (el modelo y el aviso), al 0,8 de lo de antes.
// PLATE_K y PLATE_A: la placa del mapa de la Galaxia (el vídeo y el vuelo): su escala de letra (antes 1,45) y la opacidad de su fondo (antes 0,84).
var C3_CLK = { R_K: 78 / 1080, TALL: 1.25, W_CAP: 0.46, R_MIN: 40, SAMPLES: 5, FACE_A: 0.66, CAP_MIN_PX: 11, TXT_K: 0.8, PLATE_K: 1.0, PLATE_A: 0.6 };
// DEFECTOS INYECTADOS (tests/c3_clock_probe.js): «off» = el contador de texto de antes; «corner» = la esquina con MÁS escena debajo;
// «fixed» = la esquina a las cuentas del primer fotograma (sin medir los cinco instantes del guion); «bigcap» = la cifra exacta sin el suelo
// de 11 px (a R 70, 10,5 px); (CSH_CLOCK_BREAK «opaque» = el fondo opaco; «bigclock», más abajo, = el tamaño de antes, R 104)
var C3_CLK_BREAK = "";
var C3_CLK_VARIANT = "";           // vacía = la de fábrica del módulo (CSH_CLOCK.DEFAULT: «D», esmalte romano, desde el 26-oct —R4—; antes «A»)
function c3ClkBroken(k) { return (typeof C3_CLK_BREAK === "string") && C3_CLK_BREAK.length > 0 && C3_CLK_BREAK.indexOf(k) >= 0; }
function c3ClkOn() { return typeof cshClockPaint === "function" && typeof cshClockScaleSymYears === "function" && !c3ClkBroken("off"); }
function c3ClkLang() { return (typeof CP_LANG === "string" && CP_LANG === "es") ? "es" : "en"; }
function c3ClkVariant() { return (typeof C3_CLK_VARIANT === "string" && CSH_CLOCK.V[C3_CLK_VARIANT]) ? C3_CLK_VARIANT : CSH_CLOCK.DEFAULT; }

// La placa del mapa de la Galaxia (vídeo y vuelo): la escala de su letra y la opacidad de su fondo (con la costura «bigclock»: lo de antes, 1,45 y 0,84)
function c3ClkPlateK() { return c3ClkBroken("bigclock") ? 1.45 : C3_CLK.PLATE_K; }
function c3ClkPlateA() { return c3ClkBroken("bigclock") ? 0.84 : C3_CLK.PLATE_A; }
// La escala (de la máquina del tiempo: el rango en AÑOS) y la geometría, una vez por rango, radio, idioma y variante
var C3_CLK_CACHE = {};
function c3ClkScale(rangeYears) { return cshClockScaleSymYears(rangeYears); }
// `capMin` (px, opcional): el suelo de la cifra exacta (los vídeos; el panel en vivo no lo pide: queda como estaba)
function c3ClkLayout(rangeYears, R, lang, capMin) {
   var vk = c3ClkVariant(), cm = (capMin > 0) ? capMin : 0, key = rangeYears + "|" + R + "|" + lang + "|" + vk + "|" + cm + "|" + ((typeof CSH_CLOCK_BREAK === "string") ? CSH_CLOCK_BREAK : "");
   if (!C3_CLK_CACHE[key]) C3_CLK_CACHE[key] = cshClockLayout(c3ClkScale(rangeYears), R, vk, cpFont, lang, cm > 0 ? { capMinPx: cm } : undefined);
   return C3_CLK_CACHE[key];
}
// El radio para un fotograma w × h; `maxW` (opcional): el ancho de lo que lo contiene (la esfera no pasa de W_CAP de él)
function c3ClkRadius(w, h, maxW) {
   var R = Math.round((c3ClkBroken("bigclock") ? 104 / 1080 : C3_CLK.R_K) * Math.min(w, h) * ((h > w) ? C3_CLK.TALL : 1));
   if (maxW > 0) R = Math.min(R, Math.floor(C3_CLK.W_CAP * maxW));
   return Math.max(C3_CLK.R_MIN, R);
}
// La caja que ocupa (la esfera con su cifra exacta debajo): { w, h, FP, L, pillW (el ancho del recuadro de la cifra) }. `video` (true): con el suelo
// de la cifra exacta de los vídeos (C3_CLK.CAP_MIN_PX); el panel en vivo llama sin él.
function c3ClkMeasure(rangeYears, R, caption, video) {
   var lang = c3ClkLang(), L = c3ClkLayout(rangeYears, R, lang, (video === true && !c3ClkBroken("bigcap")) ? C3_CLK.CAP_MIN_PX : 0), FP = cshClockFootprint(L, caption, cpFont);
   var pillW = caption ? (FP.cap.w + 2.4 * FP.cap.pad + FP.cap.px) : 0;
   return { w: Math.ceil(Math.max(FP.w, pillW)), h: FP.h, FP: FP, L: L, lang: lang, pillW: pillW, R: R };
}
// PINTA el reloj en el instante T (años) con la esquina de arriba a la izquierda de su CAJA en (x0, y0) (si la caja es más ancha que la esfera —la
// cifra exacta es larga—, la esfera va centrada en ella). `o.alpha`: la opacidad (el fundido); `o.faceAlpha`: la del fondo de la esfera y de la pastilla
// (los vídeos: C3_CLK.FACE_A; sin ella, opaca; la costura «opaque» de CSH_CLOCK_BREAK la quita). Devuelve lo pintado (cshClockPaint) + T y el rango.
function c3ClkPaint(g, x0, y0, M, T, rangeYears, caption, o) {
   var S = M.L.S, ox = (M.w - M.FP.w) / 2;
   var st = cshClockPaint(g, x0 + ox, y0, M.R, S, cshClockValue(S, T), { variant: M.L.variant, lang: M.lang, caption: caption, fontFn: cpFont, layout: M.L, alpha: (o && o.alpha > 0) ? o.alpha : 1, faceAlpha: (o && o.faceAlpha > 0) ? o.faceAlpha : 1 });
   st.T = T; st.range = rangeYears; st.cell = { x0: x0, y0: y0, x1: x0 + M.w, y1: y0 + M.h };
   return st;
}
