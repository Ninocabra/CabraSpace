// ============================================================================
// tm/galaxy_card.js — LO PROPIO DE LA GALAXIA EN LA FICHA DE LA ESTRELLA (Cabra3D, 26-oct-2026)
// ----------------------------------------------------------------------------
// Encargo de Nino: «Si selecciono una estrella en vista Campo, la info me aparece abajo en un recuadro negro. Haz que en Galaxia pase lo mismo para ser
// consistente y sacar de la imagen información para que quede todo más claro.»
// ANTES: la estrella elegida en el mapa de la Galaxia llevaba SU TEXTO PEGADO al marcador (nombre, «peri · apo · Zmax · e», la distancia y de dónde sale su
// velocidad radial; cshGxPaintOver / cshGxPlace de CabraShared/csh_galaxy_paint.js) y tapaba la nube. AHORA:
//   · el mapa deja solo la MARCA de la elegida (anillo de oro, su caída al disco en 3D y su órbita; `V.selLabel = false` en `_gxDraw`);
//   · el texto va a la ficha de abajo, LA MISMA del Campo (`_cardOfStar` / `_drawCard` de ui/starfield_panel.js, con el nombre-enlace a SIMBAD de
//     ui/star_link.js): cabecera, nombre, datos de Gaia, y una CUARTA línea propia de la Galaxia: su sitio en la Galaxia en el instante del mapa
//     (R y z desde el centro galáctico) y su órbita (pericentro, apocentro, Zmax, excentricidad). El tooltip de la ficha lleva además de dónde sale
//     su velocidad radial y con qué potencial se integra.
//   · con el cursor sobre otra estrella, la ficha enseña esa (como en el Campo); al soltarla, vuelve la elegida.
// Una estrella elegida en el Campo o en la foto que no está en el mapa (le falta la distancia o la velocidad radial) lo dice en esa cuarta línea.
// Solo con la Galaxia puesta (`_gxOn`): el Campo no cambia. ES5.
// ============================================================================

// «−51,3 Ma», «+120 ka», «−3,0 Myr»…: el instante del mapa, corto (la ficha tiene una línea)
function c3GcWhen(T) {
   var es = cshLangIsEs(), a = Math.abs(T);
   if (a >= 1e6) return cshGxSigned(T / 1e6, 1) + " " + (es ? "Ma" : "Myr");
   return cshGxSigned(T / 1e3, 0) + " " + (es ? "ka" : "kyr");
}
function c3GcRz(pos) { return { R: Math.sqrt(pos[0] * pos[0] + pos[1] * pos[1]), z: pos[2] }; }

// Las dos líneas de la Galaxia de la estrella `idx` (índice del script): { line4, full }. null si no hay mapa que consultar.
CPStarfieldDock.prototype._gxCardLines = function(idx) {
   var st = this.state, G = (st && st.gx) ? st.gx.G : null, T = (this.tm && this.tm.t) ? this.tm.t : 0, head = optT("Galaxy"), k, i;
   if (!G || !G.byIdx) return null;
   var at = (T !== 0) ? " (" + c3GcWhen(T) + ")" : "";
   // (1) una estrella con órbita: R y z en el instante del mapa y las cifras de su órbita (2 Gyr hacia el futuro, como la ficha de CabraComposition)
   if (G.byIdx.hasOwnProperty(idx)) {
      k = G.byIdx[idx];
      var e = G.stars[k], p = cshGxPosAt(G, k, T / 1e6, [0, 0, 0]), rz = c3GcRz(p), o = this._gxSelMeas(G, idx), ol = cshGxOrbitLine(o);
      var pos = "R " + cshGxNum(rz.R, 2) + " · z " + cshGxSigned(rz.z, 2) + " kpc";
      var line4 = head + at + " · " + pos + " · " + (ol.length > 0 ? ol : optT("not on a bound orbit"));
      var rv = (e.data && e.data.rvFrom === "cluster") ? optT("radial velocity of its cluster") : optT("radial velocity of Gaia DR3");
      var full = head + at + ": " + optT("distance from the Galactic centre (R) and height over the plane (z)") + ": " + pos + "\n" +
                 optT("Orbit over the next 2 Gyr (pericentre, apocentre, maximum height, eccentricity)") + ": " + (ol.length > 0 ? ol : optT("not on a bound orbit")) + "\n" +
                 // (27-oct, R2: el porqué del «≈», en el tooltip y no en la línea)
                 ((o && o.approx) ? optT("≈ approximate: it passes so close to the Galactic centre that the energy was not conserved even with a 16 times finer step") + "\n" : "") +
                 // (2-nov-2026, noche: decisión Q2b de Nino) lo dibujado lleva la barra y estas cifras no: que la Zmax de aquí no choque con lo que sube la línea
                 ((typeof cshGdBarOn === "function" && cshGdBarOn()) ? optT("The drawn orbit includes the rotating bar (Dehnen 2000); these numbers do not (axisymmetric potential, comparable with the literature and with StellarChemistry), so the line can rise higher than this Zmax.") + "\n" : "") +
                 rv + " · MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023)";
      return { line4: line4, full: full };
   }
   // (2) sin velocidad radial pero con distancia: su sitio de hoy (sin órbita)
   if (G.now) for (i = 0; i < G.now.length; ++i) {
      if (G.now[i].i !== idx) continue;
      var q = G.now[i], r2 = c3GcRz([q.x, q.y, q.z]);
      var pos2 = "R " + cshGxNum(r2.R, 2) + " · z " + cshGxSigned(r2.z, 2) + " kpc";
      return { line4: head + " · " + pos2 + " · " + optT("no orbit: no radial velocity"), full: head + ": " + pos2 + "\n" + optT("no orbit: no radial velocity") };
   }
   // (3) ni una cosa ni la otra
   var why = optT("not on the map: it needs a distance and a radial velocity");
   return { line4: head + " · " + why, full: head + ": " + why };
};
var c3GcBaseCardOfStar = CPStarfieldDock.prototype._cardOfStar;
CPStarfieldDock.prototype._cardOfStar = function(idx) {
   var card = c3GcBaseCardOfStar.call(this, idx);
   if (!card || !this._gxOn()) return card;
   try {
      var L = this._gxCardLines(idx);
      if (L) { card.line4 = L.line4; card.full += "\n" + L.full; }
   } catch (e) {}
   return card;
};

(function() {
   C3_I18N_ES["Galaxy"] = "Galaxia";
   C3_I18N_ES["not on a bound orbit"] = "sin órbita ligada";
   C3_I18N_ES["no orbit: no radial velocity"] = "sin órbita: sin velocidad radial";
   C3_I18N_ES["not on the map: it needs a distance and a radial velocity"] = "no está en el mapa: le falta la distancia o la velocidad radial";
   C3_I18N_ES["distance from the Galactic centre (R) and height over the plane (z)"] = "distancia al centro galáctico (R) y altura sobre el plano (z)";
   C3_I18N_ES["Orbit over the next 2 Gyr (pericentre, apocentre, maximum height, eccentricity)"] = "Órbita en los próximos 2 Ga (pericentro, apocentro, altura máxima, excentricidad)";
})();
