// ============================================================================
// tm/dust_ui.js — EL POLVO en la vista 3D, en la foto y en la ficha (Cabra3D, A5, 15-oct-2026)
// ----------------------------------------------------------------------------
// Una capa OPCIONAL, apagada de fabrica (boton «Dust» de la fila de la maquina del tiempo): al encenderla por primera
// vez se leen del mapa de Edenhofer et al. 2024 los pixeles del campo (tm/dust_run.js; la barra de progreso lo dice) y
// la temperatura de Gaia de sus estrellas (para MEDIR su enrojecimiento). Lo que se pinta:
//   · en 3D, CAPAS translucidas a su distancia: una lamina por celda del campo y tramo de distancia, del color de su densidad
//     y tan opaca como el polvo que lleva; se pintan por profundidad con los objetos (costura en `_distBody`; tarea H1, 21-oct);
//   · en la foto, la misma rejilla teñida por el polvo total de cada linea de vista (se ve que las manchas oscuras
//     de la foto caen donde el mapa pone polvo);
//   · en la ficha de una estrella, «polvo delante de ella» segun el mapa frente a su enrojecimiento MEDIDO (su color de
//     Gaia menos el de una estrella de su temperatura);
//   · en el rotulo (tm/hud.js), una frase llana: a que distancia esta el grueso del polvo y cuanto oscurece.
// ES5 (metodos de CPStarfieldDock).
// ============================================================================

// CMP_GMAX (28-oct-2026, tarde; decision B1 de Nino): la comprobacion por color solo con las estrellas de G < 15. MEDIDO (informe
// docs/informe_28oct_tarde_polvo.md): con G ≥ 16,5 la Teff de GSP-Phot ya no ve el polvo (pendiente 0,26 frente a 1,36 en las brillantes, en las
// mismas estrellas de LDu 2) y la cifra mezclaba las dos mitades.
//
// LA COMPROBACION DA LA PENDIENTE (29-oct-2026; decision P1(b) de Nino, docs/informe_28oct_tarde_polvo.md): el rotulo ya no da la MEDIANA
// de E_color/E_mapa sino la PENDIENTE de E_color frente a E_mapa (Theil-Sen), con su intervalo y el desfase (la ordenada). MEDIDO el
// 29-oct (scratchpad polvo_color/pc_diag.log): la Teff de GSP-Phot sale ~100 K fria → el color intrinseco de Mamajek sale 0,03-0,05 mag
// rojo → un DESFASE ADITIVO en E_color que, al dividir entre E_mapa ≈ 0,18, bajaba la razon de 1,28 a ~1,04; la pendiente no lo nota.
// Remuestreado al tamaño del producto: Theil-Sen 1,29 [1,01; 1,55] en NGC 1560 (n 80) y 1,36 [1,22; 1,49] en LDu 2 (n 395); la razon, 1,05 / 1,02.
//   CMP_N_MIN, CMP_RANGE_MIN: el MINIMO para dar la cifra (si no, se avisa). MEDIDO el 29-oct con la funcion real sobre las estrellas reales de G < 15
//     (scratchpad polvo_color/pc_min.log; ancho = el del intervalo del 5 al 95 %): baja como 1/(rango de E · √n) (las ventanas de E y las submuestras lo siguen).
//     NGC 1560 (rango p90-p10 de E 0,154): n 20 ancho 1,32 · n 30 0,99 · n 40 0,79 · n 60 0,65 · n 80 0,53; LDu 2 (rango 0,24): n 20 0,87 · n 30 0,64 · n 60 0,44.
//     Con n fijo en 40 y el rango recortado: rango 0,15 → 0,79 · 0,08 → 1,5-2,5 · 0,03-0,05 → 2,2-5,7 (la pendiente se pierde). Y con pocas estrellas manda la
//     estructura del campo: las 40 mas centrales de NGC 1560 dan 0,70 [0,35; 1,09], las 80 centrales 1,12 [0,87; 1,36]. De ahi n ≥ 60 y rango ≥ 0,10: en esa esquina el
//     ancho sale ~0,85-1,0 (EXTRAPOLADO con la ley 1/(rango · √n), no medido en la esquina). Pasan: NGC 1560 (80 estrellas centrales, rango 0,154) y LDu 2 (395, rango 0,21).
//   CMP_DX_MIN: se ignoran los pares de estrellas con E_mapa casi igual (|ΔE| < 0,02 ≈ un 10 % del E tipico): su pendiente es solo ruido de color.
//   CMP_PAIRS / CMP_PAIRS_BOOT: tope de pares por estimacion (con n de miles, n² pares serian millones; se toman pares al azar fijos).
//   CMP_BOOT: replicas del remuestreo para el intervalo (semilla CMP_SEED fija: la misma cifra cada vez); el intervalo es el de 5-95 %.
var C3_DUSTUI = { COL: "#C98A4E", BINS: 72, PHOTO_ALPHA: 0.28, CMP_GMAX: 15, CMP_N_MIN: 60, CMP_RANGE_MIN: 0.10, CMP_DX_MIN: 0.02,
                  CMP_PAIRS: 20000, CMP_PAIRS_BOOT: 4000, CMP_BOOT: 200, CMP_SEED: 20261029 };

// Theil-Sen de y frente a x: la MEDIANA de las pendientes de todos los pares (i, j) con |x_j − x_i| ≥ dxMin, y la ordenada = mediana de y − b·x.
// Robusto a valores atipicos y sin suponer errores en y gaussianos (la razon E_color/E_mapa, en cambio, mezcla un desfase aditivo con la escala).
// Con muchos puntos (n(n−1)/2 > maxPairs) se toman maxPairs pares AL AZAR con un generador fijo (semilla `seed`): coste O(maxPairs), no O(n²).
// Devuelve { b, a, pairs } o null si no hay ni un par valido.
function c3DustMulberry(seed) {
   var t = seed | 0;
   return function() {
      t = (t + 0x6D2B79F5) | 0;
      var r = Math.imul(t ^ (t >>> 15), 1 | t);
      r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
      return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
   };
}
function c3DustMedianOf(v) {
   var s = v.slice().sort(function(p, q) { return p - q; }), n = s.length;
   return (n === 0) ? NaN : (n % 2) ? s[n >> 1] : 0.5 * (s[n / 2 - 1] + s[n / 2]);
}
function c3DustTheilSen(x, y, dxMin, maxPairs, seed) {
   var n = x.length, sl = [], i, j;
   if (n < 2) return null;
   if (n * (n - 1) / 2 <= maxPairs) {
      for (i = 0; i < n - 1; ++i) for (j = i + 1; j < n; ++j) { var dx = x[j] - x[i]; if (Math.abs(dx) >= dxMin) sl.push((y[j] - y[i]) / dx); }
   } else {
      var rnd = c3DustMulberry(seed), tries = 0;
      while (sl.length < maxPairs && tries < 4 * maxPairs) {
         ++tries;
         i = Math.floor(rnd() * n); j = Math.floor(rnd() * n);
         if (i === j) continue;
         var dx2 = x[j] - x[i];
         if (Math.abs(dx2) >= dxMin) sl.push((y[j] - y[i]) / dx2);
      }
   }
   if (sl.length === 0) return null;
   var b = c3DustMedianOf(sl), res = [];
   for (i = 0; i < n; ++i) res.push(y[i] - b * x[i]);
   return { b: b, a: c3DustMedianOf(res), pairs: sl.length };
}
// La pendiente de Theil-Sen con su intervalo del 5 al 95 % por remuestreo de las estrellas (bootstrap: n con reemplazo, CMP_BOOT veces, semilla fija).
// { b, a, lo, hi, pairs } o null.
function c3DustSlope(x, y) {
   var K = C3_DUSTUI, n = x.length, main = c3DustTheilSen(x, y, K.CMP_DX_MIN, K.CMP_PAIRS, K.CMP_SEED);
   if (!main) return null;
   var rnd = c3DustMulberry(K.CMP_SEED + 1), bs = [], it, k;
   for (it = 0; it < K.CMP_BOOT; ++it) {
      var bx = [], by = [];
      for (k = 0; k < n; ++k) { var q = Math.floor(rnd() * n); bx.push(x[q]); by.push(y[q]); }
      var r = c3DustTheilSen(bx, by, K.CMP_DX_MIN, K.CMP_PAIRS_BOOT, K.CMP_SEED + 2 + it);
      if (r) bs.push(r.b);
   }
   bs.sort(function(p, q2) { return p - q2; });
   var m = bs.length;
   return { b: main.b, a: main.a, lo: m >= 20 ? bs[Math.floor(0.05 * (m - 1))] : NaN, hi: m >= 20 ? bs[Math.ceil(0.95 * (m - 1))] : NaN, pairs: main.pairs };
}

CPStarfieldDock.prototype._dustBuild = function() {
   var self = this;
   this.dust = { on: false };
   this.dustBtn = cpSfFlButton(this.rowsBox, optT("Dust"), "c3.dust", function() { self.dustToggle(); });
   // (lo coloca `_c3Layout`, en el grupo «Vista 3D»: es una capa de la escena)
};
CPStarfieldDock.prototype._dustSync = function() {
   if (!this.dustBtn) return;
   var on = (this.mode === "dist" && this.state !== null && !this._closed);
   cpSetControlVisible(this.dustBtn, on);
   cpStyleToggle(this.dustBtn, !!this.dust.on);
};
// Encender / apagar. Devuelve { ok, why }.
CPStarfieldDock.prototype.dustToggle = function(force) {
   var st = this.state, out = { ok: false, why: "" };
   if (!st) return out;
   var want = (force === true || force === false) ? force : !this.dust.on;
   if (!want) { this.dust.on = false; this._dustSync(); this._render(); try { this.dialog.preview.viewport.repaint(); } catch (e) {} out.ok = true; return out; }
   if (!st.dust || !st.dust.ok) {
      var self = this, busy = false;
      try { this.dialog.preview.setBusy(true, optT("Reading the 3D dust map for this field (Edenhofer et al. 2024)…"), false); busy = true; } catch (eB) {}
      try {
         C3_NET_LAST = null;
         st.dust = c3DustFetch(st.result, { onProgress: function(f) { try { self.dialog.preview.setBusy(true, format(optT("Reading the 3D dust map for this field (Edenhofer et al. 2024)… %d %%"), Math.round(100 * f)), false); } catch (eP) {} } });
         if (st.dust.ok && !st.dustTeff) {
            // (28-oct, tarde; B3: decia siempre «VizieR», y con el CDS caido contesta la ESA) el aviso dice a quien se pregunta en cada momento
            var teffSay = function(who) {
               try { self.dialog.preview.setBusy(true, (who === "esa") ? optT("VizieR did not answer: asking the ESA Gaia archive for the temperatures of the stars (Gaia DR3)…")
                                                                       : optT("Asking VizieR for the temperatures of the stars (Gaia DR3)…"), false); } catch (eT) {}
            };
            self._dustTeffSaid = [];
            C3_NET_LAST = null;
            st.dustTeff = c3DustTeffFetch(st.result, { httpTimeoutS: 30, onServer: function(who) { self._dustTeffSaid.push(who); teffSay(who); } });
            st.dustTeffWhy = st.dustTeff.ok ? null : C3_NET_LAST;
            if (st.dustTeff.ok) st.dustTeff.cmp = this._dustCompare(st);
         }
      } catch (e) { st.dust = { ok: false, code: "failed", why: String(e) }; }
      finally { if (busy) try { this.dialog.preview.setBusy(false); } catch (eF) {} }
      st.dustBins = null; st.dustTintBmp = null; st.dustLayers = null;
   }
   if (!st.dust.ok) {
      st.dustFail = (st.dust.code === "no-network") ? (C3_NET_LAST || { server: "Zenodo", code: 0, message: "" }) : null;
      out.why = (st.dust.code === "no-network") ? c3NetShort(st.dustFail) + " — " + optT("the dust layer stays off; press «Dust» again to retry (once read, it is kept in a cache).") :
                (st.dust.code === "no-coverage") ? optT("The dust map has nothing for this field.") : optT("The dust map could not be read") + (st.dust.why ? ": " + st.dust.why : "");
      this._say(out.why, "warn");
      st.dust = null;
      this.dust.on = false; this._dustSync();
      return out;
   }
   // LAS CAPAS (su profundidad y su densidad, para el rotulo y la ficha), una vez por campo
   if (!st.dustLayers) { var profs = []; for (var pc0 = 0; pc0 < st.dust.cells.length; ++pc0) if (st.dust.cells[pc0].prof) profs.push(st.dust.cells[pc0].prof); st.dustLayers = c3DustLayers(profs, C3_DUST.AV_PER_E); }
   st.dustFail = null;
   this.dust.on = true;
   this._dustSync();
   this._render();
   try { this.dialog.preview.viewport.repaint(); } catch (e2) {}
   var D = st.dust;
   this._say(format(optT("Dust: %s lines of sight, %s kB read%s · Edenhofer et al. 2024"), cpSvGroup(D.cells.length), cpSvGroup(Math.round((D.bytes || 0) / 1024)), D.cached ? " " + optT("(from the cache)") : "") +
             ((st.dustTeff && !st.dustTeff.ok) ? " · " + optT("the Gaia temperatures did not arrive: no check of the reddening") : ""), "ok");
   out.ok = true;
   return out;
};
// El enrojecimiento MEDIDO de las estrellas con temperatura de Gaia frente al polvo que el mapa les pone delante.
// { n, ok, why, slope, lo, hi, offset, eRange, ratio (mediana de E_color/E_mapa: SOLO para los registros y las pruebas, el rotulo ya no la
//   muestra —29-oct—), a0, nA0, gMax, nMin, rangeMin }
//   ok: hay estrellas y rango de E de sobra para dar la PENDIENTE (slope, con su intervalo lo-hi del 5 al 95 %) y el DESFASE (offset, en mag).
//   why (si !ok): "n" = pocas estrellas · "range" = E_mapa casi constante (sin rango no hay pendiente).
// EL MINIMO (29-oct; MEDIDO con las estrellas de NGC 1560 y LDu 2, scratchpad polvo_color/pc_min.log): ver CMP_N_MIN y CMP_RANGE_MIN arriba.
CPStarfieldDock.prototype._dustCompare = function(st) {
   // (y, aparte, el A0 de GSP-Phot de esas estrellas frente al E del mapa: la conversion MEDIDA a A0 ≈ AV, el puente con CabraStars,
   // que corrige con A0 y los coeficientes de Babusiaux et al. 2018. Sesgo conocido de GSP-Phot con poco polvo: Andrae et al. 2023)
   var T = st.dustTeff, D = st.dust, rat = [], ra0 = [], ex = [], ey = [], k, K = C3_DUSTUI, gMax = K.CMP_GMAX;
   if (!T || !T.ok || !D || !D.ok) return null;
   for (k in T.byStar) {
      var s = st.result.stars[k], t = T.byStar[k];
      if (!s || !s.dist || !(s.dist.pc > 0) || s.dist.pc > C3_DUST.R_OUT || s.bpRp === null || !(t.teff > 3500 && t.teff < 9000)) continue;
      // (28-oct, tarde) solo las brillantes: ver C3_DUSTUI.CMP_GMAX (una estrella sin G no entra)
      if (gMax > 0 && !(typeof s.g === "number" && s.g < gMax)) continue;
      var e0 = c3DustIntrinsic(t.teff), em = c3DustEToward(D, s.x, s.y, s.dist.pc);
      if (e0 === null || em === null || !(em > 0.05)) continue;
      rat.push((s.bpRp - e0) / em);
      ex.push(em); ey.push(s.bpRp - e0);
      if (t.a0 !== null && isFinite(t.a0)) ra0.push(t.a0 / em);
   }
   rat.sort(function(a, b) { return a - b; }); ra0.sort(function(a, b) { return a - b; });
   var ex2 = ex.slice().sort(function(a, b) { return a - b; }), n = ex.length;
   var out = { n: n, ok: false, why: "", slope: NaN, lo: NaN, hi: NaN, offset: NaN, eRange: (n >= 5) ? ex2[Math.min(n - 1, Math.floor(0.9 * n))] - ex2[Math.floor(0.1 * n)] : 0,
               ratio: (n >= 5) ? rat[rat.length >> 1] : NaN, nA0: ra0.length, a0: ra0.length >= 5 ? ra0[ra0.length >> 1] : NaN, gMax: gMax, nMin: K.CMP_N_MIN, rangeMin: K.CMP_RANGE_MIN };
   // el minimo: sin estrellas de sobra o sin rango de E no se da la cifra (se avisa): una pendiente de 20 estrellas casi a la misma E es ruido
   if (n < K.CMP_N_MIN) { out.why = "n"; return out; }
   if (!(out.eRange >= K.CMP_RANGE_MIN)) { out.why = "range"; return out; }
   var sl = c3DustSlope(ex, ey);
   if (!sl) { out.why = "range"; return out; }
   out.ok = true; out.slope = sl.b; out.lo = sl.lo; out.hi = sl.hi; out.offset = sl.a;
   return out;
};

// LAS NUBES EN 3D — una BRUMA con forma de NUBE a su distancia (tarea H1, 21-oct-2026; rondas V1/V2 y tercera el mismo dia).
// HISTORIA. Hasta el 20-oct: discos de radio 2,5 veces la celda, 40 por celda, casi opacos al sumarse: una LOSA color arena hasta
// ~100 000 al (el mapa acaba en 4 080), encima de la foto y de «la estrella mas cercana». Primera ronda H1: laminas planas por celda y
// tramo, por profundidad con los objetos: bien colocadas, pero un MURO de placas. Segunda ronda (V1): grupos difuminados, una bruma…
// que aun se leia como un BLOQUE rectangular (montaje del 21-oct, filas 5 y 8) y de un solo tono arena. TERCERA RONDA, AHORA:
//   · cada tramo de cada celda es una lamina en su sitio (dentro del haz, sin pasar de R_OUT) con la opacidad de la LEY (1 − exp(−KAPPA·AV),
//     tope TOT_MAX, mas peso en los tramos densos): eso es `a0` (lo que mide tests/c3_H_cases.js H1.2);
//   · el perfil de cada celda se SUAVIZA en distancia (gaussiana de SMOOTH tramos, ~±5 %: la resolucion del mapa) y cada celda se corre un
//     poco en distancia (JITTER, ±4 %, ruido fijo): una capa densa ya no es una placa con cantos rectos vista de lado;
//   · la FORMA: lo que se pinta (`a`) es `a0` por una caida ELIPTICA hacia las paredes del haz (FEATHER: 1 en el centro, 0 en las esquinas:
//     ninguna silueta de rectangulo desde ninguna pose) y por un RUIDO suave de baja frecuencia (NOISE, determinista, sembrado por el campo:
//     la misma nube cada vez), que da textura de nube donde el mapa es uniforme (un campo pequeño cae entero en un pixel del mapa);
//     la estructura de VERDAD del mapa entre celdas se conserva (el ruido multiplica, no aplana);
//   · el COLOR, el de la RAMPA de densidad de la leyenda en cada tramo (crema < 1, marron 1–10, oxido ≥ 10 mag/kpc), con mas grupos de
//     profundidad (GROUPS) para que una capa densa no se mezcle con las tenues de al lado;
//   · los grupos se pintan en lienzos pequeños (1/DS) difuminados y se intercalan POR PROFUNDIDAD con los objetos (`_distBody`): lo de
//     detras queda velado; mirando de frente, dentro del contorno de la foto, cada grupo se rebaja a GLASS.
var C3_DUSTUI_3D = { KAPPA: 0.55, TOT_MAX: 0.62, MIN_A: 0.002, GLASS: 0.18, OCC: 4, GROUPS: 6, DS: 10, TAPER: 0.15, SMOOTH: 1.4, JITTER: 0.04,
                     FEATHER: [0.25, 1.12], NOISE: { F: 1.5, FZ: 7, FR: 6, AMP: 1.0, ON: true }, MONO: -1 };
// Ruido de valores 3D, suave (interpolacion «smoothstep» entre los vertices de una rejilla con valores al azar FIJOS por la semilla)
function c3DustHash(i, j, k, s) {
   var h = Math.imul(i | 0, 374761393) ^ Math.imul(j | 0, 668265263) ^ Math.imul(k | 0, 1274126177) ^ Math.imul(s | 0, 1103515245);
   h = Math.imul(h ^ (h >>> 13), 1274126177); h ^= h >>> 16;
   return (h >>> 0) / 4294967296;
}
function c3DustNoise3(x, y, z, s) {
   var x0 = Math.floor(x), y0 = Math.floor(y), z0 = Math.floor(z), fx = x - x0, fy = y - y0, fz = z - z0;
   fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy); fz = fz * fz * (3 - 2 * fz);
   function L(a, b, t) { return a + (b - a) * t; }
   var c000 = c3DustHash(x0, y0, z0, s), c100 = c3DustHash(x0 + 1, y0, z0, s), c010 = c3DustHash(x0, y0 + 1, z0, s), c110 = c3DustHash(x0 + 1, y0 + 1, z0, s);
   var c001 = c3DustHash(x0, y0, z0 + 1, s), c101 = c3DustHash(x0 + 1, y0, z0 + 1, s), c011 = c3DustHash(x0, y0 + 1, z0 + 1, s), c111 = c3DustHash(x0 + 1, y0 + 1, z0 + 1, s);
   return L(L(L(c000, c100, fx), L(c010, c110, fx), fy), L(L(c001, c101, fx), L(c011, c111, fx), fy), fz);
}
// La semilla del campo (la misma nube cada vez que se abre esta foto)
function c3DustSeed(f) { return (Math.round((f.ra || 0) * 1000) * 31 + Math.round((f.dec || 0) * 1000) * 17) | 0; }
// (una vez por campo) los tramos de cada celda: { u0, u1, v0, v1, av, tot, bins: [ { pc, a0 (la ley), a (lo que se pinta), col, k } ] }
CPStarfieldDock.prototype._dustCells3d = function(st) {
   if (st.dustBins) return st.dustBins;
   var D = st.dust, f = st.result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H);
   var B = C3_DUSTUI.BINS, r0 = C3_DUST.R_IN, r1 = C3_DUST.R_OUT, K = C3_DUSTUI_3D, N = K.NOISE, seed = c3DustSeed(f), list = [], c, b, j;
   // el nucleo del suavizado en distancia (gaussiana normalizada de SMOOTH tramos de sigma)
   var R = Math.max(1, Math.ceil(3 * K.SMOOTH)), ker = [], ks = 0;
   for (j = -R; j <= R; ++j) { var kv = Math.exp(-0.5 * j * j / (K.SMOOTH * K.SMOOTH)); ker.push(kv); ks += kv; }
   for (j = 0; j < ker.length; ++j) ker[j] /= ks;
   for (c = 0; c < D.cells.length; ++c) {
      var cl = D.cells[c];
      if (!cl.prof) continue;
      var raw = [], edges = [], avTot = 0;
      for (b = 0; b <= B; ++b) edges.push(r0 * Math.pow(r1 / r0, b / B));
      for (b = 0; b < B; ++b) { var dA = Math.max(0, c3DustEAt(cl.prof, edges[b + 1]) - c3DustEAt(cl.prof, edges[b])) * C3_DUST.AV_PER_E; raw.push(dA); avTot += dA; }
      // el perfil suavizado (lo que sale por un extremo se devuelve al tramo del borde: el total se conserva)
      var sm = [];
      for (b = 0; b < B; ++b) sm.push(0);
      for (b = 0; b < B; ++b) for (j = -R; j <= R; ++j) { var bb = Math.max(0, Math.min(B - 1, b + j)); sm[bb] += raw[b] * ker[j + R]; }
      // donde esta la celda en la seccion del haz (−1…1) y su corrimiento en distancia
      var ex = ((cl.x0 + cl.x1) / 2 - W / 2) / (W / 2), ey = ((cl.y0 + cl.y1) / 2 - H / 2) / (H / 2), er = Math.sqrt(ex * ex + ey * ey);
      var fe = 1 - Math.max(0, Math.min(1, (er - K.FEATHER[0]) / (K.FEATHER[1] - K.FEATHER[0]))); fe = fe * fe * (3 - 2 * fe);
      var jit = 1 + K.JITTER * (2 * c3DustNoise3(ex * N.F + 7.3, ey * N.F + 1.9, 0.5, seed) - 1);
      var bins = [], wsum = 0;
      for (b = 0; b < B; ++b) {
         var ra = edges[b], rb = edges[b + 1], dAV = sm[b];
         // (encargo de Nino, 15-oct: el color dice la DENSIDAD —AV por kpc—, con su escala en la leyenda)
         var dens = dAV / (rb - ra) * 1000, densRaw = raw[b] / (rb - ra) * 1000;
         if (!(dens >= C3_DUST_SCALE.LO) || !(dAV > 0)) continue;
         // (las caras del mapa —el primer y el ultimo TAPER del camino, en escala logaritmica— pesan menos: sin «pared» en R_OUT)
         var u = (b + 0.5) / B, tap = Math.min(1, u / K.TAPER, (1 - u) / K.TAPER), tR = c3DustRampT(dens), tC = c3DustRampT(Math.max(dens, densRaw)), wgt = dAV * Math.pow(0.25 + tR, 1.2) * Math.max(0.02, tap * tap * (3 - 2 * tap));
         bins.push({ pc: Math.sqrt(ra * rb) * jit, dAV: dAV, dens: dens, w: wgt, col: c3DustRampColor((K.MONO >= 0) ? K.MONO : tC), k: b, u: u });   // (MONO: solo el control en rojo de las pruebas —un tono—)
         wsum += wgt;
      }
      // la opacidad total de la linea de vista (de frente), repartida entre sus tramos por su peso
      // (los tramos que saldrian casi invisibles —menos de MIN_A— no se pintan, y su parte se reparte entre los demas: la opacidad de
      // frente sigue siendo la de la ley; MEDIDO en tests/c3_H_cases.js H1.2, sin el reparto se quedaba en 0,394 frente a 0,420)
      var tot = Math.min(K.TOT_MAX, 1 - Math.exp(-K.KAPPA * avTot)), tau = -Math.log(1 - tot), keep = [], it, ws = wsum;
      for (it = 0; it < 4; ++it) {
         keep = []; var ws2 = 0;
         for (b = 0; b < bins.length; ++b) { if (tau * bins[b].w / Math.max(1e-12, ws) < K.MIN_A) continue; keep.push(bins[b]); ws2 += bins[b].w; }
         if (ws2 === ws || keep.length === 0) break;
         ws = ws2;
      }
      for (b = 0; b < keep.length; ++b) {
         var q = keep[b];
         q.a0 = 1 - Math.exp(-tau * q.w / Math.max(1e-12, ws));
         // (lo que se PINTA: la ley por la caida eliptica y por el ruido de nube; solo en el dibujo: la ficha y el rotulo usan el perfil de verdad)
         var nz = N.ON ? Math.max(0, 1 + N.AMP * (2 * c3DustNoise3(ex * N.F, ey * N.F, q.u * N.FZ, seed) - 1)) : 1;
         // (y el RADIO de la caida cambia con la distancia —ruido aparte—: de lado o desde arriba la silueta ondula, no es un canto)
         var feb = fe;
         if (N.ON) {
            var rs = 0.6 + 0.8 * c3DustNoise3(3.1 + q.u * N.FR, 5.7, 2.3, seed + 11), er2 = er / rs;
            feb = 1 - Math.max(0, Math.min(1, (er2 - K.FEATHER[0]) / (K.FEATHER[1] - K.FEATHER[0]))); feb = feb * feb * (3 - 2 * feb);
         }
         q.a = Math.min(0.9, q.a0 * feb * nz);
      }
      // (el color, por la densidad de VERDAD del tramo —sin suavizar— donde es mayor: el suavizado en distancia no aclara una capa densa)
      if (keep.length) list.push({ u0: (cl.x0 - W / 2) / big, u1: (cl.x1 - W / 2) / big, v0: (cl.y0 - H / 2) / big, v1: (cl.y1 - H / 2) / big, av: avTot, tot: tot, feather: fe, bins: keep });
   }
   st.dustBins = list;
   return list;
};
// Difuminar un bitmap ARGB (premultiplicado) con una caja de (2r+1)²: la media de copias corridas, SUMADAS (CompositionOp_Add con
// opacidad 1/n). Devuelve un bitmap nuevo del mismo tamaño.
function c3DustBlur(src, r) {
   var out = new Bitmap(src.width, src.height), n = (2 * r + 1) * (2 * r + 1), g;
   out.fill(0x00000000);
   g = new Graphics(out);
   try {
      g.compositionOperator = CompositionOp_Add; g.opacity = 1 / n;
      for (var dy = -r; dy <= r; ++dy) for (var dx = -r; dx <= r; ++dx) g.drawBitmap(dx, dy, src);
      g.opacity = 1; g.compositionOperator = CompositionOp_SourceOver;
   } finally { g.end(); }
   return out;
}
// LA PARTE «BACK»: proyectar las laminas de este dibujo, pintarlas por grupos en sus lienzos pequeños difuminados y apuntar su
// ocupacion (para el rotulo). Devuelve cuantas laminas hay.
CPStarfieldDock.prototype._dustPaint3d = function(g, model, scale, fit, sc, clip, o) {
   var st = this.state, K = C3_DUSTUI_3D, old = this._c3DustFrame, i, b, gi;
   if (old && old.groups) for (gi = 0; gi < old.groups.length; ++gi) cpSfUiFree(old.groups[gi].bmp);
   this._c3DustFrame = null;
   if (!this.dust || !this.dust.on || !st || !st.dust || !st.dust.ok || !model || !fit || fit.mode !== "perspective") return 0;
   var cells = this._dustCells3d(st), wn = model.wn, hn = model.hn, x0 = clip.x, x1 = clip.x + clip.w, y0 = clip.y, y1 = clip.y + clip.h, B = C3_DUSTUI.BINS, G = K.GROUPS;
   // (la foto: mirando de frente, todo el polvo queda detras de ella)
   var pq = null;
   if (fit.front) {
      var Q = [fit.px(-wn / 2, -hn / 2, 0), fit.px(wn / 2, -hn / 2, 0), fit.px(wn / 2, hn / 2, 0), fit.px(-wn / 2, hn / 2, 0)];
      if (Q[0].ok && Q[1].ok && Q[2].ok && Q[3].ok) pq = Q;
   }
   var oc = Math.max(8, Math.round(40 * sc)), occ = { fit: fit, cell: oc, x0: x0, y0: y0, cols: Math.max(1, Math.ceil(clip.w / oc)), rows: Math.max(1, Math.ceil(clip.h / oc)), v: null };
   occ.v = new Float32Array(occ.cols * occ.rows);
   // los grupos: sus laminas (poligonos en pixeles del lienzo pequeño) y su profundidad media pesada por la opacidad
   var ds = Math.max(3, Math.round(K.DS * sc)), lw = Math.max(2, Math.ceil(clip.w / ds) + 2), lh = Math.max(2, Math.ceil(clip.h / ds) + 2), grp = [], n = 0, maxSum = 0;
   for (gi = 0; gi < G; ++gi) grp.push({ polys: [], za: 0, aa: 0, da: 0 });
   for (i = 0; i < cells.length; ++i) {
      var C = cells[i], sumA = 0;
      for (b = 0; b < C.bins.length; ++b) {
         var q = C.bins[b], t = scale.t(q.pc);
         if (!(t >= 0 && t <= 1)) continue;
         var p0 = fit.px(C.u0, C.v0, t), p1 = fit.px(C.u1, C.v0, t), p2 = fit.px(C.u1, C.v1, t), p3 = fit.px(C.u0, C.v1, t);
         if (!p0.ok || !p1.ok || !p2.ok || !p3.ok) continue;
         var bx0 = Math.min(p0.x, p1.x, p2.x, p3.x), bx1 = Math.max(p0.x, p1.x, p2.x, p3.x), by0 = Math.min(p0.y, p1.y, p2.y, p3.y), by1 = Math.max(p0.y, p1.y, p2.y, p3.y);
         if (bx1 < x0 || bx0 > x1 || by1 < y0 || by0 > y1 || bx1 - bx0 > 40000 || by1 - by0 > 40000) continue;
         var pc = fit.px((C.u0 + C.u1) / 2, (C.v0 + C.v1) / 2, t), G1 = grp[Math.min(G - 1, Math.floor(q.k * G / B))];
         G1.polys.push({ a: q.a, col: q.col, pts: [p0, p1, p2, p3] });
         G1.za += q.a * pc.z; G1.aa += q.a; G1.da += q.a * q.dens; ++n;
         sumA = 1 - (1 - sumA) * (1 - q.a);
         // (la ocupacion, para el rotulo: la caja de la lamina, pesada por su opacidad)
         var ca0 = Math.max(0, Math.floor((bx0 - x0) / oc)), ca1 = Math.min(occ.cols - 1, Math.floor((bx1 - x0) / oc)), cb0 = Math.max(0, Math.floor((by0 - y0) / oc)), cb1 = Math.min(occ.rows - 1, Math.floor((by1 - y0) / oc));
         for (var cb = cb0; cb <= cb1; ++cb) for (var ca = ca0; ca <= ca1; ++ca) occ.v[cb * occ.cols + ca] += K.OCC * q.a;
      }
      if (sumA > maxSum) maxSum = sumA;
   }
   // cada grupo, a su lienzo pequeño: las laminas (de lejos a cerca dentro del grupo), la foto «de cristal» y el difuminado
   var groups = [], self = this;
   function lp(p) { return new Point((p.x - x0) / ds + 1, (p.y - y0) / ds + 1); }
   for (gi = 0; gi < G; ++gi) {
      var GG = grp[gi];
      if (GG.polys.length === 0) continue;
      var bm = new Bitmap(lw, lh), gl;
      bm.fill(0x00000000);
      gl = new Graphics(bm);
      try {
         gl.antialiasing = true; gl.pen = new Pen(0x00000000, 0);
         for (i = 0; i < GG.polys.length; ++i) {
            var P = GG.polys[i];
            gl.brush = new Brush(cpInt("#" + ("000000" + P.col.toString(16)).slice(-6), P.a));
            gl.fillPolygon([lp(P.pts[0]), lp(P.pts[1]), lp(P.pts[2]), lp(P.pts[3])]);
         }
         // (mirando de frente: dentro del contorno de la foto, el polvo se ve a traves de ella —se le quita 1 − GLASS—)
         if (pq !== null) { gl.compositionOperator = CompositionOp_DestinationOut; gl.brush = new Brush(cpInt("#000000", 1 - K.GLASS)); gl.fillPolygon([lp(pq[0]), lp(pq[1]), lp(pq[2]), lp(pq[3])]); gl.compositionOperator = CompositionOp_SourceOver; }
      } finally { gl.end(); }
      var b1 = c3DustBlur(bm, 1), b2 = c3DustBlur(b1, 2);
      cpSfUiFree(bm); cpSfUiFree(b1);
      groups.push({ z: GG.za / Math.max(1e-9, GG.aa), bmp: b2, dens: GG.da / Math.max(1e-9, GG.aa) });   // (dens: la densidad media del grupo, pesada por la opacidad —para las pruebas—)
   }
   groups.sort(function(p, q2) { return q2.z - p.z; });                 // lo lejano antes
   this._c3Occ = occ;
   this._c3DustFrame = { fit: fit, groups: groups, next: 0, rect: { x: x0 - ds, y: y0 - ds, w: lw * ds, h: lh * ds } };
   this._c3DustStats = { sheets: n, groups: groups.length, glass: pq !== null, maxColumnAlpha: Math.round(maxSum * 1000) / 1000, cells: cells.length, layer: lw + "x" + lh };
   return n;
};
// LA PARTE «OBJECTS»: pintar los grupos de polvo que estan mas LEJOS que `z` (o todos los que queden, con z = −Infinity). Las llama
// `_distBody` antes de cada objeto (lejos → cerca): lo que esta mas cerca que un grupo se pinta despues, encima; lo de detras, velado.
CPStarfieldDock.prototype._c3DustDrawUntil = function(g, fit, z) {
   var F = this._c3DustFrame;
   if (!F || F.fit !== fit || !F.groups || F.next >= F.groups.length) return 0;
   var n = 0, si = g.smoothInterpolation, R = F.rect;
   g.smoothInterpolation = true;
   while (F.next < F.groups.length && F.groups[F.next].z > z) {
      g.drawScaledBitmap(new Rect(R.x, R.y, R.x + R.w, R.y + R.h), F.groups[F.next++].bmp);
      ++n;
   }
   g.smoothInterpolation = si;
   return n;
};

// EN LA FOTO: la rejilla del mapa teñida por el polvo total de cada linea de vista (hasta 1 250 pc).
CPStarfieldDock.prototype.dustPaintPhoto = function(g, pv) {
   var st = this.state;
   if (!this.dust || !this.dust.on || !st || !st.dust || !st.dust.ok || !pv || !pv.bitmap) return 0;
   var rec = this.dialog.currentRec;
   if (!rec || this._find(cpSfUiKey(rec.view)) !== st) return 0;
   var D = st.dust, vw = pv.viewport.width, vh = pv.viewport.height, sc = c3BoxScale(vw, cpUiScale(pv.viewport)), n = this._dustTint(g, function(x, y) { return pv.toScreen(x, y); });
   // LA LEYENDA: la misma tira que en el 3D (el mismo pintor). (Tarea H9, 21-oct: abajo a la izquierda tapaba estrellas de la foto.) Va en el
   // MARGEN negro del visor si lo hay (abajo, arriba o a un lado); si no, mas pequeña y mas translucida en la esquina de la foto con MENOS
   // estrellas (las de la foto, contadas en cada esquina).
   var spec = this._dustSpec("column"), mg = Math.round(8 * sc), f = st.result.field, a = pv.toScreen(0, 0), b = pv.toScreen(f.width, f.height);
   var px0 = Math.max(0, Math.min(a.x, b.x)), px1 = Math.min(vw, Math.max(a.x, b.x)), py0 = Math.max(0, Math.min(a.y, b.y)), py1 = Math.min(vh, Math.max(a.y, b.y));
   var M = c3DustLegLayout(spec, sc, Math.max(Math.round(120 * sc), Math.min(vw - 2 * mg, Math.round(vw * 0.45)))), x, y, alpha = C3_DLEG.ALPHA, where = "";
   if (vh - py1 >= M.h + 2 * mg) { x = mg; y = vh - mg - M.h; where = "margin-bottom"; }
   else if (py0 >= M.h + 2 * mg) { x = mg; y = mg; where = "margin-top"; }
   else if (vw - px1 >= M.w + 2 * mg) { x = vw - mg - M.w; y = vh - mg - M.h; where = "margin-right"; }
   else if (px0 >= M.w + 2 * mg) { x = mg; y = vh - mg - M.h; where = "margin-left"; }
   else {
      // (V15, segunda ronda: la letra no baja de la de la interfaz —con 0,85 quedaba en ~5 px en la captura—; mas estrecha, eso si)
      M = c3DustLegLayout(spec, sc, Math.max(Math.round(110 * sc), Math.min(vw - 2 * mg, Math.round(vw * 0.30))));
      alpha = 0.62;
      var C = [{ n: "bl", x: mg, y: vh - mg - M.h }, { n: "br", x: vw - mg - M.w, y: vh - mg - M.h }, { n: "tl", x: mg, y: mg }, { n: "tr", x: vw - mg - M.w, y: mg }], best = null, S = st.result.stars, i, k;
      for (k = 0; k < C.length; ++k) C[k].s = 0;
      for (i = 0; i < S.length; i += (S.length > 20000) ? 4 : 1) {
         var s0 = S[i]; if (typeof s0.x !== "number") continue;
         var p = pv.toScreen(s0.x, s0.y), wq = (s0.g !== undefined && s0.g !== null && s0.g < 12) ? 4 : 1;
         for (k = 0; k < C.length; ++k) if (p.x >= C[k].x && p.x <= C[k].x + M.w && p.y >= C[k].y && p.y <= C[k].y + M.h) C[k].s += wq;
      }
      for (k = 0; k < C.length; ++k) if (best === null || C[k].s < best.s) best = C[k];
      x = best.x; y = best.y; where = best.n;
   }
   this._c3PhotoLeg = { x: x, y: y, w: M.w, h: M.h, where: where };
   c3DustLegPaint(g, Math.round(x), Math.round(y), M, spec, alpha);
   return n;
};
// (el texto largo de la leyenda, para su tooltip: nada se corta con «…» en la tira)
CPStarfieldDock.prototype._dustLegend = function() {
   return format(optT("Brown: interstellar dust in front (3D map of Edenhofer et al. 2024, 14' cells); the browner, the more dust, up to AV ≈ %s"), cpSvFx((this.state.dust.eMax * C3_DUST.AV_PER_E), 1));
};
// La rejilla teñida, con `map(x, y)` de pixeles de la foto a la pantalla. Devuelve las celdas pintadas.
CPStarfieldDock.prototype._dustTint = function(g, map) {
   // (MIRADO el 15-oct: con un rectangulo por celda quedaba una rejilla de costuras. Ahora un bitmap de nx × ny pixeles —uno por
   // linea de vista, su alfa el polvo— escalado con interpolacion sobre la foto: un tinte continuo, sin costuras)
   var st = this.state, D = st.dust, n = 0;
   if (!st.dustTintBmp) {
      var b = new Bitmap(D.nx, D.ny), rgb = cpInt(C3_DUSTUI.COL, 1) & 0xffffff;
      b.fill(0x00000000);
      for (var c = 0; c < D.cells.length; ++c) {
         var cl = D.cells[c];
         if (!cl.prof) continue;
         // (escala ABSOLUTA, no la del maximo del campo: un campo casi limpio sale casi sin teñir; AV 1,5 → 63 % del tinte maximo)
         var e = cl.prof.cum[cl.prof.cum.length - 1], a = C3_DUSTUI.PHOTO_ALPHA * (1 - Math.exp(-e * C3_DUST.AV_PER_E / 1.5));
         b.setPixel(c % D.nx, Math.floor(c / D.nx), ((Math.round(255 * a) & 0xff) << 24 | rgb) >>> 0);
         ++n;
      }
      st.dustTintBmp = b; st.dustTintN = n;
   }
   var f = st.result.field, p0 = map(0, 0), p1 = map(f.width, f.height), si = g.smoothInterpolation;
   g.smoothInterpolation = true;
   g.drawScaledBitmap(new Rect(p0.x, p0.y, p1.x, p1.y), st.dustTintBmp);
   g.smoothInterpolation = si;
   return st.dustTintN;
};

// LA FICHA: con el polvo encendido, la linea del nombre dice el polvo que el mapa le pone delante y el que su color MIDE.
var c3BaseCardOfStar = CPStarfieldDock.prototype._cardOfStar;
CPStarfieldDock.prototype._cardOfStar = function(idx) {
   var card = c3BaseCardOfStar.call(this, idx), st = this.state;
   if (!card || !this.dust || !this.dust.on || !st || !st.dust || !st.dust.ok) return card;
   var s = st.result.stars[idx];
   if (!s || !s.dist || !(s.dist.pc > 0)) return card;
   var em = c3DustEToward(st.dust, s.x, s.y, s.dist.pc), bits = [];
   if (em === null) return card;
   bits.push(format(optT("Dust in front (map): AV ≈ %s"), cpSvFx((em * C3_DUST.AV_PER_E), 2)) + ((s.dist.pc > C3_DUST.R_OUT) ? " " + format(optT("(the map stops at %s)"), this._dist(C3_DUST.R_OUT)) : ""));
   var t = (st.dustTeff && st.dustTeff.byStar) ? st.dustTeff.byStar[idx] : null;
   if (t && s.bpRp !== null) {
      var e0 = c3DustIntrinsic(t.teff);
      if (e0 !== null) bits.push(format(optT("its colour says E(BP−RP) = %s (expected from the map ≈ %s)"), cpSvFx((s.bpRp - e0), 2), cpSvFx((em * C3_DUST.EBPRP_PER_E), 2)));
   } else bits.push(optT("no Gaia temperature to measure its reddening"));
   // (mas alla del mapa, el respaldo: la extincion de la propia estrella segun Gaia GSP-Phot, con su sesgo conocido)
   if (s.dist.pc > C3_DUST.R_OUT && t && t.a0 !== null && isFinite(t.a0)) bits.push(format(optT("beyond the map, Gaia GSP-Phot gives it A0 = %s"), cpSvFx(t.a0, 2)));
   card.name = (card.link ? card.link.text + "  ·  " : "") + bits.join(" · ");        // (26-oct: el nombre de la estrella, enlace a SIMBAD, delante del polvo)
   var LY = st.dustLayers || [], fr = [];
   for (var li = 0; li < LY.length; ++li) if (LY[li].from < s.dist.pc) fr.push(format(optT("from %s to %s: %s, it dims %s mag"), this._dist(LY[li].from), this._dist(Math.min(LY[li].to, s.dist.pc)), c3HudDustWord(LY[li].cls), cpSvFx(LY[li].dAV, 1)));
   card.full += "\n" + (fr.length ? optT("Dust layers in front of it") + ": " + fr.join(" · ") : optT("No layer of dense dust in front of it."));
   // (28-oct, tarde: E(BP−RP) ≈ 1,28 E —antes 1,35—, la cifra sale de C3_DUST.EBPRP_PER_E: ver CabraShared/csh_dust.js)
   card.full += "\n" + format(optT("Dust: Edenhofer et al. 2024 3D map (E of Zhang, Green & Rix 2023; AV = 2.8 E; E(BP−RP) ≈ %s E with the Gaia coefficients of Babusiaux et al. 2018)"),
                              (typeof cpSvDec === "function") ? cpSvDec(String(C3_DUST.EBPRP_PER_E)) : String(C3_DUST.EBPRP_PER_E)) + "\nE = " + cpSvFx(em, 3) +
                (t ? "\n" + format(optT("Gaia DR3 GSP-Phot: Teff %s K, E(BP−RP) %s; intrinsic BP−RP of that temperature (Mamajek): %s"), String(Math.round(t.teff)), (t.ebprpGsp !== null) ? cpSvFx(t.ebprpGsp, 2) : "?", cpSvFx(c3DustIntrinsic(t.teff), 2)) : "");
   return card;
};

// ============================================================================
// LA LEYENDA DEL POLVO — UNA sola, igual en todas las vistas (encargo de Nino, 20-oct: «cuando sale la leyenda del polvo
// tapa partes del 3D; que quede bien integrada con todas las visualizaciones»)
// ----------------------------------------------------------------------------
// Una TIRA fina: titulo corto, rampa de color y tres rotulos, con fondo translucido y su filete de oro a la izquierda
// (la misma voz que el rotulo). Un solo pintor (`c3DustLegLayout` + `c3DustLegPaint`) para el 3D (franja propia al pie de
// la zona de dibujo: la escena se ENCAJA en lo que queda, no hay nada debajo), la foto, la pantalla completa, lo exportado
// y los fotogramas del video; todo en funcion de `sc` (la escala del lienzo) y de un ancho maximo relativo al lienzo.
// Dos escalas, las dos del mismo aspecto: «density» (el 3D: AV por kpc, lo que dice el color de las nubes) y «column» (la
// foto: AV total por delante, lo que dice el tinte). Nada se corta con «…»: si no cabe en una fila, el titulo pasa
// encima de la rampa; si aun asi no cabe, se parte en renglones.
// ============================================================================
var C3_DLEG = { MAXW: 0.62, ALPHA: 0.80, BAR_MAX: 280, BAR_MIN: 140 };

function c3DustFmt(v) { return String(Number(v.toFixed(2))).replace(".", (CP_LANG === "es") ? "," : "."); }
// El «spec» de una escala: { kind, title, color(t) → 0xRRGGBB, marks [t], labels [{ t, text, short }], tip }
CPStarfieldDock.prototype._dustSpec = function(kind) {
   var S = C3_DUST_SCALE, st = this.state, sp;
   if (kind === "density") {
      sp = { kind: kind, title: optT("DUST DENSITY · AV PER KPC"), titleShort: optT("DUST · AV/KPC"), color: c3DustRampColor,
             marks: [c3DustRampT(S.DENSE), c3DustRampT(S.VERY)],
             labels: [{ t: c3DustRampT(Math.sqrt(S.LO * S.DENSE)), text: optT("thin") + " <" + c3DustFmt(S.DENSE), short: "<" + c3DustFmt(S.DENSE) },
                      { t: c3DustRampT(Math.sqrt(S.DENSE * S.VERY)), text: optT("dense") + " " + c3DustFmt(S.DENSE) + "–" + c3DustFmt(S.VERY), short: c3DustFmt(S.DENSE) + "–" + c3DustFmt(S.VERY) },
                      { t: c3DustRampT(Math.sqrt(S.VERY * S.HI)), text: optT("very dense") + " ≥" + c3DustFmt(S.VERY), short: "≥" + c3DustFmt(S.VERY) }],
             tip: optT("Colour of the 3D dust clouds: how much visible light the dust dims per kiloparsec (AV in magnitudes per kpc), on a logarithmic scale. Thin: under 1; dense: 1 to 10; very dense: 10 or more (the diffuse medium of the Galactic plane dims about 1–2 mag/kpc; a molecular cloud, tens to hundreds).") };
   } else {
      var D = (st && st.dust) ? st.dust : null, avMax = D ? D.eMax * C3_DUST.AV_PER_E : 1, nice = [0.5, 1, 2, 3, 5, 10, 20, 50], top = nice[nice.length - 1], k;
      for (k = 0; k < nice.length; ++k) if (nice[k] >= avMax) { top = nice[k]; break; }
      var f = function(t) { return (1 - Math.exp(-t * top / 1.5)) / (1 - Math.exp(-top / 1.5)); };       // (el tinte de la foto: 1 - exp(-AV / 1,5), normalizado al tope de la escala)
      sp = { kind: kind, title: optT("DUST IN FRONT · TOTAL AV"), titleShort: optT("DUST · AV"),
             color: function(t) { var bg = cpHexRgb(CP_ATLAS.bg), c = cpHexRgb(C3_DUSTUI.COL), u = 0.85 * f(t), r = Math.round(bg[0] + (c[0] - bg[0]) * u), gg = Math.round(bg[1] + (c[1] - bg[1]) * u), b = Math.round(bg[2] + (c[2] - bg[2]) * u); return (r << 16) | (gg << 8) | b; },
             marks: [0.5], labels: [{ t: 0, text: "0", short: "0" }, { t: 0.5, text: c3DustFmt(top / 2), short: c3DustFmt(top / 2) }, { t: 1, text: c3DustFmt(top) + " mag", short: c3DustFmt(top) }],
             tip: optT("Brown tint of the photo: the dust in front of each part of the field, from the 3D map (Edenhofer et al. 2024, 14' cells). The browner, the more it dims visible light, as AV in magnitudes (1 magnitude = 2.5 times fainter) up to the darkest line of sight of the field.") };
   }
   return sp;
};
function c3DustLegCapsW(F, sp, t) { return F.width(t) + Math.max(0, String(t).length - 1) * sp; }
// Parte un titulo en versalitas en renglones de ancho <= maxW (por palabras).
function c3DustLegWrap(F, sp, title, maxW) {
   var words = String(title).split(" "), out = [], cur = "";
   for (var i = 0; i < words.length; ++i) {
      var nx = cur.length ? cur + " " + words[i] : words[i];
      if (c3DustLegCapsW(F, sp, nx) <= maxW || cur.length === 0) cur = nx; else { out.push(cur); cur = words[i]; }
   }
   if (cur.length) out.push(cur);
   return out;
}
// El hueco que ocupa: { w, h, mode ("row" | "stack"), rw (ancho de la rampa), ... } con `sc` y un ancho maximo.
function c3DustLegLayout(spec, sc, maxW) {
   var szL = CP_ATLAS.size.label * sc, sp = cpCapsSpacing(szL), Fc = cpFont("text", szL, true, false, sp), Fs = cpFont("text", szL), pad = Math.max(3, Math.round(6 * sc)), gap = Math.max(4, Math.round(10 * sc));
   var acc = Math.max(2, Math.round(2 * sc)), barH = Math.max(4, Math.round(7 * sc)), tickH = Math.max(2, Math.round(3 * sc)), capH = Fc.ascent + Fc.descent, smH = Fs.ascent + Fs.descent;
   var inner = Math.max(40, maxW - 2 * pad - acc), titleW = c3DustLegCapsW(Fc, sp, spec.title), mode = "row", rw, lines, M;
   // (tarea H3, 21-oct: en un lienzo estrecho, antes de pasar a dos pisos, el titulo corto en una fila —el largo esta en el tooltip—)
   var title = spec.title;
   if (!(titleW + gap + C3_DLEG.BAR_MIN * sc <= inner) && spec.titleShort && c3DustLegCapsW(Fc, sp, spec.titleShort) + gap + C3_DLEG.BAR_MIN * sc <= inner) { title = spec.titleShort; titleW = c3DustLegCapsW(Fc, sp, title); }
   if (titleW + gap + C3_DLEG.BAR_MIN * sc <= inner) { rw = Math.min(Math.round(C3_DLEG.BAR_MAX * sc), inner - titleW - gap); lines = [title]; }
   else { mode = "stack"; rw = Math.min(Math.round(C3_DLEG.BAR_MAX * sc), inner); lines = c3DustLegWrap(Fc, sp, spec.title, inner); rw = Math.max(rw, Math.min(inner, Math.round(C3_DLEG.BAR_MIN * sc))); }
   // los rotulos: con palabra si caben sin tocarse, si no solo la cifra; si ni asi, solo los de los extremos
   var lab = [], pass, i, ok;
   for (pass = 0; pass < 3; ++pass) {
      lab = []; ok = true;
      for (i = 0; i < spec.labels.length; ++i) {
         if (pass === 2 && i === 1 && spec.labels.length === 3) continue;
         var tx = (pass === 0) ? spec.labels[i].text : spec.labels[i].short, lw = Fs.width(tx), cx = rw * spec.labels[i].t, lx = Math.max(0, Math.min(rw - lw, cx - lw / 2));
         if (lab.length && lx < lab[lab.length - 1].x + lab[lab.length - 1].w + Math.round(6 * sc)) { ok = false; break; }
         lab.push({ text: tx, x: lx, w: lw });
      }
      if (ok) break;
   }
   var barBlock = barH + tickH + smH + Math.round(1 * sc);
   if (mode === "row") {
      var topOff = Math.max(0, Math.round(capH * 0.35 - barH / 2)), contentH = Math.max(capH, topOff + barBlock);
      M = { mode: mode, w: 2 * pad + acc + titleW + gap + rw, h: 2 * pad + contentH, rw: rw, lines: lines, barX: pad + acc + titleW + gap, barY: pad + topOff, titleX: pad + acc, titleY: pad };
   } else {
      var tw = 0; for (i = 0; i < lines.length; ++i) tw = Math.max(tw, c3DustLegCapsW(Fc, sp, lines[i]));
      var th = lines.length * capH + (lines.length - 1) * Math.round(1 * sc), g2 = Math.round(3 * sc);
      M = { mode: mode, w: 2 * pad + acc + Math.max(rw, tw), h: 2 * pad + th + g2 + barBlock, rw: rw, lines: lines, barX: pad + acc, barY: pad + th + g2, titleX: pad + acc, titleY: pad };
   }
   M.labels = lab; M.Fc = Fc; M.Fs = Fs; M.pad = pad; M.acc = acc; M.barH = barH; M.tickH = tickH; M.capH = capH; M.sp = sp; M.sc = sc;
   return M;
}
// Pintarla con su esquina de arriba a la izquierda en (x, y). Devuelve su rectangulo { x, y, w, h }.
function c3DustLegPaint(g, x, y, M, spec, alpha) {
   var sc = M.sc, i, N = 48, a = (alpha === undefined) ? C3_DLEG.ALPHA : alpha, aa = g.antialiasing, bx = x + M.barX, by = y + M.barY;
   g.antialiasing = false;
   g.fillRect(new Rect(x, y, x + M.w, y + M.h), new Brush(cpInt(CP_ATLAS.bg, a)));
   g.pen = new Pen(cpInt(CP_ATLAS.line, 0.9), 1); g.brush = new Brush(0x00000000); g.drawRect(x, y, x + M.w - 1, y + M.h - 1);
   g.fillRect(new Rect(x, y, x + M.acc, y + M.h), new Brush(CP_INT_AMBER));
   g.antialiasing = true;
   // el titulo
   g.font = M.Fc; g.pen = new Pen(CP_INT_AMBER);
   for (i = 0; i < M.lines.length; ++i) g.drawText(x + M.titleX, y + M.titleY + M.Fc.ascent + i * (M.capH + Math.round(1 * sc)), M.lines[i]);
   // la rampa, en tiras (Atlas es plano: sin degradados de pincel), opaca: se lee de punta a punta
   g.antialiasing = false;
   for (i = 0; i < N; ++i) g.fillRect(new Rect(Math.round(bx + M.rw * i / N), by, Math.round(bx + M.rw * (i + 1) / N), by + M.barH), new Brush(((0xff000000 | spec.color((i + 0.5) / N)) >>> 0)));
   g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.8), 1); g.brush = new Brush(0x00000000); g.drawRect(bx, by, bx + M.rw, by + M.barH);
   g.pen = new Pen(CP_INT_TEXT2);
   for (i = 0; i < spec.marks.length; ++i) { var mx = Math.round(bx + M.rw * spec.marks[i]); g.drawLine(mx, by + M.barH, mx, by + M.barH + M.tickH); }
   g.antialiasing = true;
   g.font = M.Fs; g.pen = new Pen(CP_INT_TEXT2);
   for (i = 0; i < M.labels.length; ++i) g.drawText(bx + M.labels[i].x, by + M.barH + M.tickH + M.Fs.ascent, M.labels[i].text);
   g.antialiasing = aa;
   return { x: x, y: y, w: M.w, h: M.h };
}
// LA FRANJA DEL 3D: lo que reserva `_drawDist` al pie de la zona de dibujo (la escena se encaja en lo que queda) y donde se pinta.
CPStarfieldDock.prototype._c3DustStrip = function(w, sc) {
   var st = this.state;
   if (this.mode !== "dist" || !this.dust || !this.dust.on || !st || !st.dust || !st.dust.ok) return null;
   // (tarea H3: en un lienzo estrecho, todo el ancho: con el 62 % la tira pasaba a dos pisos y se comia la escena)
   var spec = this._dustSpec("density"), M = c3DustLegLayout(spec, sc, (w < 640 * sc) ? w - Math.round(16 * sc) : Math.round(w * C3_DLEG.MAXW));
   return { spec: spec, M: M, h: M.h + Math.round(4 * sc), sc: sc };
};
CPStarfieldDock.prototype._c3DustStripPaint = function(g, strip, x, y, sc) {
   return c3DustLegPaint(g, x, y + Math.round(4 * (strip.sc || sc)), strip.M, strip.spec);
};
