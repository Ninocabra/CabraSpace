// ============================================================================
// tm/names_simbad.js — EL NOMBRE LEGIBLE de lo destacado, de SIMBAD (Cabra3D, 21-oct-2026)
// ----------------------------------------------------------------------------
// Una estrella sin nombre comun de Hipparcos sale en la placa como «Gaia DR3 <id>»; un cuasar, con el identificador que le da SIMBAD
// (a veces tambien «Gaia DR3 <id>»). SIMBAD conoce ese identificador y todos los demas del mismo objeto: UNA consulta pequeña (TAP,
// tabla `ident`) devuelve los de todos los destacados a la vez, y se elige el mas legible por prioridad:
//   nombre propio (NAME) > Bayer/Flamsteed (* alf CMa, * 61 Cyg) > variable (V* RR Lyr) > HD > HIP > TYC > BD/CD/SAO > 2MASS > SDSS/QSO…
//   > se queda el «Gaia DR3 <id>».
// La parte PURA (`c3NamesPick`, `c3NamesAdql`, `c3NamesParse`) corre en node (tests/c3_names_cases.js). La RED va por el camino de siempre
// (`cpSfHttpText`: curl, plazos, el gancho de pruebas CP_SF_HTTP_HOOK) y por un PASO MAS de la cola de red del panel («names», detras de
// los demas): nunca bloquea (`_netStepLive` atiende la interfaz), guarda lo contestado en la cache comun (%LOCALAPPDATA%/CabraScripts/cache, csh_dust.js c3CacheDir) y, si SIMBAD falla, no dice
// nada en la placa —se queda el nombre de ahora— y lo dice en el tooltip de la linea de estado. Al llegar el nombre se repinta.
// ES5.
// ============================================================================

var C3_NAMES = { URL: "https://simbad.cds.unistra.fr/simbad/sim-tap/sync", TIMEOUT_S: 15, CACHE: "simbad_names.json", MAX_IDS: 40 };
var C3_NAMES_GREEK = { alf: "α", bet: "β", gam: "γ", del: "δ", eps: "ε", zet: "ζ", eta: "η", tet: "θ", iot: "ι", kap: "κ", lam: "λ", mu: "μ", nu: "ν", ksi: "ξ", omi: "ο",
                       pi: "π", rho: "ρ", sig: "σ", tau: "τ", ups: "υ", phi: "φ", chi: "χ", psi: "ψ", ome: "ω" };
var C3_NAMES_SUP = { "1": "¹", "2": "²", "3": "³", "4": "⁴", "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹" };

function c3NamesClean(s) { return String(s || "").replace(/\s+/g, " ").replace(/^ | $/g, ""); }

// «* alf CMa» -> «α CMa»; «* alf01 Cen A» -> «α¹ Cen A»; «* 61 Cyg A» -> «61 Cyg A»; null si no es Bayer ni Flamsteed.
function c3NamesBayer(rest) {
   var m = /^([a-z]{2,3})\.?(\d{0,2})\s+([A-Za-z]{3})(?:\s+(\S+))?$/.exec(rest), g, sup;
   if (m && C3_NAMES_GREEK[m[1]]) {
      g = C3_NAMES_GREEK[m[1]]; sup = m[2] ? String(parseInt(m[2], 10)) : "";
      return g + (sup ? (C3_NAMES_SUP[sup] || sup) : "") + " " + m[3] + (m[4] ? " " + m[4] : "");
   }
   m = /^(\d{1,3})\s+([A-Za-z]{3})(?:\s+(\S+))?$/.exec(rest);
   if (m) return m[1] + " " + m[2] + (m[3] ? " " + m[3] : "");
   return null;
}
// La clase de legibilidad de UN identificador de SIMBAD: { tier (menor = mejor), text } o null si no vale (el Gaia DR3 no vale: es lo que hay).
function c3NamesTier(id) {
   var s = c3NamesClean(id), m;
   if ((m = /^NAME (.+)$/.exec(s))) return { tier: 0, text: m[1] };
   if ((m = /^\* (.+)$/.exec(s))) { var b = c3NamesBayer(m[1]); return b ? { tier: 1, text: b } : null; }
   if ((m = /^V\* (.+)$/.exec(s))) return { tier: 1.5, text: m[1] };
   if (/^HD \d+/.test(s)) return { tier: 2, text: s };
   if (/^HIP \d+/.test(s)) return { tier: 3, text: s };
   if (/^TYC \d+/.test(s)) return { tier: 4, text: s };
   if (/^(BD|CD|CPD)[-+]\d/.test(s)) return { tier: 5, text: s };
   if (/^SAO \d+/.test(s)) return { tier: 5.5, text: s };
   if (/^2MASS/.test(s)) return { tier: 6, text: s };
   if (/^(SDSS|QSO|NVSS|PKS|3C|4C|PSS|LBQS|HS |UM |FIRST|1RXS|2dFGRS|2QZ|\[VV|\[HB|PG |Q\d)/.test(s)) return { tier: 7, text: s };
   return null;
}
// El mejor nombre de UN objeto, de la lista de todos sus identificadores. `wgsn` (opcional) = { nombre: true } de los nombres de la IAU:
// entre varios «NAME …» gana uno de la IAU, y si no, el mas corto. Devuelve el texto, o "" si no hay nada mejor que el Gaia DR3.
function c3NamesPick(ids, wgsn) {
   var best = null, i;
   for (i = 0; i < ids.length; ++i) {
      var t = c3NamesTier(ids[i]);
      if (!t) continue;
      if (t.tier === 0) t.iau = !!(wgsn && wgsn[t.text]);
      if (best === null || t.tier < best.tier) { best = t; continue; }
      if (t.tier === best.tier) {
         if (t.tier === 0) { if ((t.iau && !best.iau) || (t.iau === best.iau && t.text.length < best.text.length)) best = t; }
         else if (t.text < best.text) best = t;                   // (determinista: el mismo resultado se pida en el orden que se pida)
      }
   }
   return best ? best.text : "";
}
// La consulta: todos los identificadores de los objetos que tienen CADA UNO de los identificadores pedidos (de «Gaia DR3 …»).
function c3NamesAdql(ids) {
   var q = [];
   for (var i = 0; i < ids.length; ++i) q.push("'" + String(ids[i]).replace(/'/g, "''") + "'");
   return "SELECT q.id AS q, i.id AS id FROM ident AS q JOIN ident AS i ON i.oidref=q.oidref WHERE q.id IN (" + q.join(",") + ")";
}
// El CSV de la respuesta -> { identificador pedido: [todos los identificadores] }. (Campos con o sin comillas.)
function c3NamesParse(text) {
   var L = String(text || "").split("\n"), out = {}, first = true;
   function fields(line) {
      var r = [], cur = "", inq = false, k, ch;
      for (k = 0; k < line.length; ++k) {
         ch = line.charAt(k);
         if (inq) { if (ch === '"') { if (line.charAt(k + 1) === '"') { cur += '"'; ++k; } else inq = false; } else cur += ch; }
         else if (ch === '"') inq = true;
         else if (ch === ",") { r.push(cur); cur = ""; }
         else cur += ch;
      }
      r.push(cur);
      return r;
   }
   for (var i = 0; i < L.length; ++i) {
      var l = L[i].replace(/\r$/, ""); if (l.length === 0) continue;
      var f = fields(l);
      if (first) { first = false; if (f[0] === "q") continue; }
      if (f.length < 2) continue;
      var q = c3NamesClean(f[0]);
      (out[q] || (out[q] = [])).push(c3NamesClean(f[1]));
   }
   return out;
}
// UNA peticion (hasta MAX_IDS identificadores). Devuelve { ok, code, why, map: { pedido: nombre o "" } }.
// `opts.onProgress(ms)` = señal de vida (la interfaz la usa para atenderse). Sin consulta si no hay nada que pedir.
function c3NamesFetch(ids, opts) {
   var o = opts || {}, out = { ok: false, code: "no-network", why: "", map: {} };
   if (!ids || ids.length === 0) { out.ok = true; out.code = ""; return out; }
   var list = ids.slice(0, C3_NAMES.MAX_IDS), url = C3_NAMES.URL + "?REQUEST=doQuery&LANG=ADQL&FORMAT=csv&MAXREC=5000&QUERY=" + encodeURIComponent(c3NamesAdql(list));
   var T = (o.timeoutS > 0) ? o.timeoutS : C3_NAMES.TIMEOUT_S, r;
   function isTable(t) { var h = String(t || "").substring(0, 300); return h.indexOf("<") < 0 && h.indexOf("q") >= 0; }
   // (28-oct-2026) con reserva: si el CDS no da la tabla, el espejo de SIMBAD en Harvard (CabraShared csh_net.js cshSimbadGet, la unica;
   //  los 13 nombres de la cache salieron iguales en el espejo, medido el 28-oct)
   var g = cshSimbadGet(url, { timeoutS: T, what: "ident (names)", onProgress: o.onProgress }, isTable); r = g.r; out.server = g.server; out.fallback = g.fallback;
   if (!r.ok) { out.why = String(r.message || ""); out.code = (r.code > 0) ? "http-" + r.code : (r.cut ? "timeout" : "no-network"); return out; }
   if (!isTable(r.text)) { out.why = "not a table"; out.code = "bad-answer"; return out; }
   var byQ = c3NamesParse(r.text), wgsn = null, k;
   try { var D = c3SkyData(); if (D && D.wgsn) { wgsn = {}; for (k in D.wgsn) wgsn[D.wgsn[k]] = true; } } catch (eW) {}
   for (var i = 0; i < list.length; ++i) {
      var key = c3NamesClean(list[i]);
      out.map[list[i]] = byQ[key] ? c3NamesPick(byQ[key], wgsn) : "";
   }
   out.ok = true; out.code = "";
   return out;
}

// ---------------------------------------------------------------------------
// EL PASO DE RED («names»), detras de los demas. Los nombres se guardan en `st.idNames` { «Gaia DR3 <id>»: nombre legible o "" }.
// ---------------------------------------------------------------------------
// El nombre legible que ya llego para este identificador de Gaia ("" si no).
CPStarfieldDock.prototype._simbadName = function(key) {
   var st = this.state;
   return (st && st.idNames && st.idNames[key]) ? st.idNames[key] : "";
};
// Los destacados cuyo nombre es solo un «Gaia DR3 <id>» y todavia no se han pedido: { ids, n }.
CPStarfieldDock.prototype._namesWanted = function() {
   var st = this.state, out = [], seen = {};
   if (!st || this.mode !== "dist") return out;
   var model = this._distModel(), hi = cpSvDistHighlights(model), idx = [], i;
   for (i = 0; i < hi.length; ++i) idx.push(hi[i].index);
   try { var pro = cpFlProtagonist(model); if (pro >= 0) idx.push(pro); } catch (eP) {}
   for (i = 0; i < idx.length; ++i) {
      var b = this._plateBase(model, idx[i]);
      if (/^Gaia DR3 \d+$/.test(b) && !seen[b] && !(st.idNames && st.idNames[b] !== undefined)) { seen[b] = true; out.push(b); }
   }
   return out;
};
var c3NamesBasePending = CPStarfieldDock.prototype._netPending;
CPStarfieldDock.prototype._netPending = function() {
   var s = c3NamesBasePending.call(this);
   if (s !== "") return s;
   var st = this.state;
   if (st && this.mode === "dist" && (st.net.names === undefined || st.net.names === "")) return "names";
   return "";
};
var c3NamesBaseNetStep = CPStarfieldDock.prototype._netStep;
CPStarfieldDock.prototype._netStep = function() {
   if (this._closed || this._netBusy) return "";
   if (this._netPending() !== "names") return c3NamesBaseNetStep.call(this);
   this._animStop();
   var st = this.state, self = this, want = this._namesWanted(), out = null, label = optT("Asking SIMBAD for the names of the objects…");
   if (!st.idNames) st.idNames = {};
   // lo que ya se contesto otra vez (cache comun de %LOCALAPPDATA%; la vieja de %TEMP% se lee y se copia): sin red
   var cache = null, ask = [], i;
   try { cache = c3CacheRead(C3_NAMES.CACHE); } catch (eC) {}
   var cm = (cache && cache.map) ? cache.map : {};
   for (i = 0; i < want.length; ++i) { if (cm[want[i]] !== undefined) st.idNames[want[i]] = cm[want[i]]; else ask.push(want[i]); }
   if (ask.length === 0) { st.net.names = "ok"; if (this.state === st && this.mode !== "" && !this._closed) { this._render(); this._sayState(); } this._netArm(); return "names"; }
   this._netBusy = true;
   st.net.names = "running";
   this._say(label, "info");
   try {
      out = c3NamesFetch(ask, { onProgress: function(ms) {
         if (self._closed || cpQuiet()) return;
         self._say(label + " " + Math.round(ms / 1000) + " s", "info");
         try { optProcessEvents(); } catch (eP) {}
      } });
   } catch (e) { out = { ok: false, code: "no-network", why: String(e.message || e), map: {} }; }
   finally { this._netBusy = false; }
   // (si SIMBAD no contesta —o no hay respuesta—: nada cambia en las placas; se dice en el tooltip de la linea de estado)
   st.net.names = (out && out.ok) ? "ok" : ("failed:" + ((out && out.code) || "no-network"));
   if (out && out.ok) {
      var found = 0;
      for (i = 0; i < ask.length; ++i) { var nm = out.map[ask[i]] || ""; st.idNames[ask[i]] = nm; cm[ask[i]] = nm; if (nm) ++found; }
      try { c3CacheWrite(C3_NAMES.CACHE, { map: cm, when: (new Date()).toISOString() }); } catch (eW) {}
      st.namesFound = (st.namesFound || 0) + found;
   }
   if (this._closed) return "names";
   if (this.state === st && this.mode !== "") { this._syncButtons(); this._render(); this._sayState(); try { this.dialog.preview.viewport.repaint(); } catch (eR) {} }
   this._netArm();
   return "names";
};
