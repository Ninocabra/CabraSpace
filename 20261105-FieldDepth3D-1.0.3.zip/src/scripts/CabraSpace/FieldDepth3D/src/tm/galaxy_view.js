// ============================================================================
// tm/galaxy_view.js — LA VISTA GALÁCTICA del panel 3D: las estrellas del campo en la Vía Láctea (Cabra3D, 23-oct-2026)
// ----------------------------------------------------------------------------
// Encargo de Nino: «Añade también en Cabra3D esta visualización tipo galaxia [la del grupo III · LA GALAXIA de CabraComposition]
// dentro de la máquina del tiempo y también dentro de la representación 3D. En su versión desde arriba, de canto y 3D. Permitir
// que el vídeo se pueda grabar en cualquiera de estas vistas.»
//
// QUÉ ES: en el grupo 3D VIEW, un conmutador «Field | Galaxy» (Campo | Galaxia). En «Galaxy» el lienzo del 3D enseña el mapa de la
// Vía Láctea con las estrellas del campo que tienen cinemática completa (distancia + movimiento propio + velocidad radial de Gaia
// DR3, o la del cúmulo en sus miembros: lo mismo que mueve la máquina del tiempo), en tres versiones —Desde arriba (X–Y), De canto
// (R–z), 3D (la cámara de Cabra3D)—, con sus órbitas y el color de Gaia (BP−RP) o la distancia. El mapa, la física y la cámara
// son los de CabraShared (csh_galdyn.js, csh_galaxy.js, csh_galaxy_paint.js, csh_galaxy_i18n.js: la copia de CabraComposition).
//   · LA MÁQUINA DEL TIEMPO mueve el mapa: su instante (tm.t, años) es el del mapa; cada estrella y el Sol van por su órbita
//     integrada hacia el pasado y hacia el futuro (MilkyWayPotential2022 desde el 23-oct, tarde). Su comportamiento en el campo NO cambia.
//   · EL VÍDEO: el ÚNICO «● Record» de FLIGHT AND VIDEO. Con la galaxia puesta, «qué grabar» dice «la máquina del tiempo: galaxia»
//     (y «foto + galaxia»): graba con el grabador de siempre (c3TmRecorder: tamaños, fps, título, carpeta, MP4/AVI) la vista
//     galáctica elegida —desde arriba, de canto o 3D girando despacio— con la máquina del tiempo corriendo. (26-oct) Los VUELOS (Dive,
//     Orbit, Grand tour) también vuelan la Galaxia, con la cámara 3D del mapa: tm/galaxy_flight.js.
//   · CLIC en una estrella del mapa = la misma elegida en la foto y en el 3D del campo (selectStar).
//   · RENDIMIENTO: la capa fija del mapa (resplandor, órbitas) va en un bitmap; reproducir la máquina del tiempo o elegir solo
//     repinta las estrellas y lo de encima. Al girar el 3D, el resplandor a media resolución y 120 órbitas (cshGxPaintStatic).
// Lo incluye SOLO Cabra3D.js (CabraStarAnalysis no: sus ficheros de Cabra3D llaman a esto con `typeof`, ver ui/groups.js y
// tm/timemachine_video.js). Métodos de CPStarfieldDock que envuelven los de siempre: con la galaxia apagada, todo es lo de antes.
// ES5.
// ============================================================================

var C3_GXV = {
   MODES: ["top", "edge", "3d"],
   COLORS: ["gaia", "dist"],
   MIN_SPAN_MYR: 210,        // lo integrado a cada lado de hoy, como mínimo (media ventana de órbitas, CSH_GX.SHOW_MYR / 2)
   SHORT_RANGE: 1e7,         // con la máquina del tiempo a menos de ±10 Myr, el mapa apenas se mueve: la placa lo dice
   NO_BPRP: [220, 214, 200], // sin BP−RP: el gris de cpSvStarRgb para «sin color»
   // (28-oct, V7, decisión de Nino) «LIENZO PEQUEÑO» para la leyenda del 3D: el ancho LÓGICO del mapa (rect.w / sc) por debajo de SLIM_BELOW. Cifras MEDIDAS
   // (tests/c3_gx_legend_slim.js S1, Pléyades, 3D, escala 1,5; la leyenda entera mide 666 px = 444 lógicos): lienzo 756 → mapa 488 lógicos, la leyenda ocupa el 91 %
   // y tapa el 83,9 % de la nube a +100 Ma (16,4 % a −100); lienzo 881 → 571 lógicos, 78 % del ancho, 0 % tapado; lienzo 1976 → 1301 lógicos, 34 %, 0 %. El tapado
   // solo separa 488 de 571 (y para una nube y un campo): no sirve de umbral. El umbral es el ancho a partir del cual la leyenda entera deja de ocupar más de la
   // mitad del mapa: 2 × 444 ≈ 890 → 900. Deja «pequeño» a 756 y 881 (leyenda estrecha: 264 px) y «grande» a 1976 (entera, sin cambios).
   SLIM_BELOW: 900,
   // (23-oct-2026, tarde, queja de Nino usándolo de verdad: «en Galaxia no se mueve nada cuando uso la máquina del tiempo». MEDIDO con
   // tests/c3_gx_real.js —el main real, con lo recordado de Nino—: su máquina del tiempo estaba a ±1 000 años (la escala del CAMPO,
   // recordada), y a esa escala el Sol se mueve 0,0002 kpc: 0,0 px en el mapa, 0,03 % de píxeles distintos entre dos instantes. La placa lo
   // avisaba en letra pequeña. Ahora LA GALAXIA TIENE SU PROPIA ESCALA (recordada aparte, Galaxy/range; de fábrica ±100 Ma) y el
   // desplegable, en la galaxia, solo ofrece las que mueven el mapa. La del campo no se toca: al volver a Campo vuelven su escala y su instante.)
   RANGES: [1e7, 1e8, 1e9],
   RANGE_DEFAULT: 1e8
};
// El color de Gaia de una estrella: cpSvStarRgb (CabraShared/csh_view.js), pero sin BP−RP de verdad el gris. (OJO, visto el 23-oct en un
// fotograma del vídeo: cpSvStarRgb(null) da el color de BP−RP = 0 —Number(null) es 0—, azulado, y no el gris de «sin color»: sin esta
// guarda las estrellas sin BP−RP salían azules. Lo mismo le pasa al 3D del campo: anotado en el HANDOFF, csh_view.js no se toca aquí.)
function c3GxBpRpRgb(c) { return (c === null || c === undefined || !isFinite(Number(c))) ? C3_GXV.NO_BPRP : cpSvStarRgb(c); }
// DEFECTOS INYECTADOS para ver en ROJO las pruebas de tests/c3_galaxy.js: «view» (el modo no cambia la vista), «leak» (al volver al
// campo quedan mandos apagados y el dibujo ligero), «video» (el grabador no ve la galaxia). Los de CabraShared: CSH_GX_BREAK.
var C3_GXV_BREAK = "";       // (23-oct, tarde: «range» = sin escala propia —la del campo, lo de ayer—; «nonow» = sin las de solo hoy)
function c3GxBroken(k) { return (typeof C3_GXV_BREAK === "string") && C3_GXV_BREAK.length > 0 && C3_GXV_BREAK.indexOf(k) >= 0; }
// Lo recordado (vista, versión, color, órbitas). Las pruebas ni lo leen ni lo escriben.
function c3GxRead(key, fallback, allowed) {
   if (CP_NO_MAIN) return fallback;
   try { var v = Settings.read(CP_SETTINGS_PREFIX + "/Galaxy/" + key, DataType_String); if (Settings.lastReadOK !== false && typeof v === "string" && (!allowed || allowed.indexOf(v) >= 0)) return v; } catch (e) {}
   return fallback;
}
function c3GxWrite(key, value) { if (CP_NO_MAIN) return; try { Settings.write(CP_SETTINGS_PREFIX + "/Galaxy/" + key, DataType_String, String(value)); } catch (e) {} }
// La rampa de la DISTANCIA (de la paleta Atlas): cerca azul, ~300 pc crema, ~2 kpc oro, 10 kpc violeta.
function c3GxDistRgb(pc) {
   var cols = [cpHexRgb(CP_ATLAS.chart[1]), cpHexRgb(CP_ATLAS.text), cpHexRgb(CP_ATLAS.gold), cpHexRgb(CP_ATLAS.chart[4])], L = [1, 2.5, 3.3, 4];
   var v = (pc > 0) ? Math.log(pc) / Math.LN10 : 1;
   if (v <= L[0]) return cols[0];
   for (var i = 1; i < L.length; ++i) if (v <= L[i]) { var t = (v - L[i - 1]) / (L[i] - L[i - 1]), a = cols[i - 1], b = cols[i]; return [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t]; }
   return cols[cols.length - 1];
}

// ---------------------------------------------------------------------------
// LOS MANDOS (los crea ui/groups.js `_c3Layout` con `typeof this._gxBuild`: la fila de arriba del grupo 3D VIEW)
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._gxBuild = function(C) {
   var self = this, B = cpSfFlButton;
   // (23-oct, Nino: «empieza en modo Galaxia y enseña este cartel. No puedo continuar. Haz que empiece en campo») la vista Campo |
   // Galaxia NO se recuerda al abrir: siempre empieza en Campo; versión, color, órbitas y escala sí se recuerdan
   this.gx = { on: false, mode: c3GxRead("mode", "top", C3_GXV.MODES), color: c3GxRead("color", "gaia", C3_GXV.COLORS),
               orbits: c3GxRead("orbits", "on", ["on", "off"]) === "on",
               // (24-oct-2026, V7f) la capa «Polvo» PROPIA de la Galaxia (csh_galaxy_dust.js): ENCENDIDA de fábrica y recordada. Por qué
               // encendida: es local (sin red, cero espera), Nino la pidió para ver la Galaxia entera, y su tope de opacidad está medido para
               // que órbitas, estrellas y Sol se lean siempre encima (tests/c3_gxdust.js K1–K3); el «Polvo» del Campo sigue apagado (red)
               dust: c3GxRead("dust", "on", ["on", "off"]) === "on", cam: null, v2: { top: null, edge: null }, cache: {}, vcache: {}, fieldOff: false, videoFrames: 0, lastMs: 0,
               range: Number(c3GxRead("range", String(C3_GXV.RANGE_DEFAULT), C3_GXV.RANGES.map(String))), t: 0, field: null };
   // (23-oct, tarde) la escala del desplegable: en la galaxia, la suya (`_gxRanges`); el manejador elige de la lista que se enseña
   this.tmRange.onItemSelected = function(k) { if (!self.tm.building) { var L = self._gxRanges(); if (k >= 0 && k < L.length) self.tmSetRange(L[k]); } };
   if (this.gx.on) { this._gxTimeSwap(true); this._tmItems(); }
   this.gxField = B(C, optT("Field"), "gx.field", function() { self.gxSetOn(false); });
   this.gxGalaxy = B(C, optT("Galaxy"), "gx.galaxy", function() { self.gxSetOn(true); });
   this.gxTop = B(C, optT("From above"), "gx.top", function() { self.gxSetMode("top"); });
   this.gxEdge = B(C, optT("Edge-on"), "gx.edge", function() { self.gxSetMode("edge"); });
   this.gx3d = B(C, "3D", "gx.3d", function() { self.gxSetMode("3d"); });
   this.gxOrbits = B(C, optT("Orbits"), "gx.orbits", function() { self.gxSetOrbits(!self.gx.orbits); });
   this.gxDust = B(C, optT("Dust"), "gx.dust", function() { self.gxSetDust(!self.gx.dust); });
   this.gxColLabel = cpSfFlLabel(C, optT("Colour"));
   this.gxColLabel.toolTip = cpTooltip("gx.col.gaia");
   this.gxColGaia = B(C, "BP−RP", "gx.col.gaia", function() { self.gxSetColor("gaia"); });
   this.gxColDist = B(C, optT("Distance"), "gx.col.dist", function() { self.gxSetColor("dist"); });
   this.gxButtons = [this.gxField, this.gxGalaxy, this.gxTop, this.gxEdge, this.gx3d, this.gxOrbits, this.gxDust, this.gxColGaia, this.gxColDist];
   // (24-oct-2026, Nino: «en Campo las opciones aparecen abajo; en Galaxia, al lado. Que las de Galaxia aparezcan abajo, sustituyendo las
   // de Campo». Arriba solo «Field | Galaxy»; las de la galaxia, DOS filas como las del campo —ui/groups.js las pone en su bloque—)
   return { top: [this.gxField, this.gxGalaxy, "~"],
            rows: [[this.gxTop, this.gxEdge, this.gx3d, "|", this.gxOrbits, this.gxDust, "~"],
                   [this.gxColLabel, this.gxColGaia, this.gxColDist, "~"]] };
};
CPStarfieldDock.prototype._gxOn = function() { return !!(this.gx && this.gx.on && this.mode === "dist" && !this._closed); };
// Los mandos del CAMPO que en la galaxia no aplican: apagados con su porqué en el tooltip. (Desde el 24-oct, además, ESCONDIDOS con su
// bloque —las filas de la galaxia van en su sitio—; lo de apagarlos se queda: es lo que mira el rojo «leak» de tests/c3_galaxy.js X1.)
CPStarfieldDock.prototype._gxFieldOnly = function() {
   return [this.btnPersp, this.btnSide, this.btnLog, this.btnSeg, this.btnLy, this.btnPc, this.zoomSlider, this.zoomLabel, this.btnErr, this.skyBtn];
};
CPStarfieldDock.prototype._gxSync = function() {
   if (!this.gx || !this.gxField) return;
   var dist = (this.mode === "dist" && this.state !== null && !this._closed), on = this._gxOn(), i, list = this._gxFieldOnly();
   cpSetControlVisible(this.gxField, dist); cpSetControlVisible(this.gxGalaxy, dist);
   var only = [this.gxTop, this.gxEdge, this.gx3d, this.gxOrbits, this.gxDust, this.gxColLabel, this.gxColGaia, this.gxColDist];
   for (i = 0; i < only.length; ++i) cpSetControlVisible(only[i], dist && on);
   // (24-oct) las filas de abajo: las del campo o las de la galaxia, en el mismo sitio (ui/groups.js `c3Blocks`); solo se recoloca si cambia
   var BK = this.c3Blocks || {};
   if (BK.field && BK.galaxy && (BK.galaxy.__cpHidden !== !(dist && on) || BK.field.__cpHidden !== (dist && on))) {
      // (el mismo alto: las filas del campo llevan un desplegable y un deslizador, 8 px más altas que los botones de la galaxia —medido
      // en tests/c3_gx_review.js V9: 104 frente a 96 px—; el bloque de la galaxia toma el alto del del campo, medido mientras se veía)
      try { if (BK.field.__cpHidden !== true && BK.field.height > 0) this.gx.fieldBlockH = BK.field.height; if (this.gx.fieldBlockH > 0 && !c3GxBroken("beside")) BK.galaxy.setMinHeight(this.gx.fieldBlockH); } catch (eH) {}
      cpSetControlVisible(BK.field, !(dist && on)); cpSetControlVisible(BK.galaxy, dist && on);
      try { var bv = this.c3Groups && this.c3Groups.view ? this.c3Groups.view.body : null; if (bv) bv.adjustToContents(); this.rowsBox.adjustToContents(); } catch (eA) {}
   }
   cpStyleToggle(this.gxField, !on); cpStyleToggle(this.gxGalaxy, on);
   cpStyleToggle(this.gxTop, this.gx.mode === "top"); cpStyleToggle(this.gxEdge, this.gx.mode === "edge"); cpStyleToggle(this.gx3d, this.gx.mode === "3d");
   cpStyleToggle(this.gxOrbits, this.gx.orbits); cpStyleToggle(this.gxDust, this.gx.dust); cpStyleToggle(this.gxColGaia, this.gx.color === "gaia"); cpStyleToggle(this.gxColDist, this.gx.color === "dist");
   var rec = !!(this.fl && this.fl.rec !== null);
   try { for (i = 0; i < this.gxButtons.length; ++i) this.gxButtons[i].enabled = !rec; } catch (eE) {}
   // (23-oct, tarde, visto con tests/c3_gx_real.js: con la galaxia RECORDADA —Nino— nadie llamaba a gxSetOn y «qué grabar» seguía diciendo
   // «la máquina del tiempo: 3D» aunque grababa la galaxia. Ahora el texto sigue a la vista en cada sincronización)
   try {
      var w1 = on ? optT("the time machine: photo + galaxy") : optT("the time machine: photo + 3D"), w2 = on ? optT("the time machine: galaxy") : optT("the time machine: 3D");
      if (this.recWhat.itemText(1) !== w1) this.recWhat.setItemText(1, w1);
      if (this.recWhat.itemText(2) !== w2) this.recWhat.setItemText(2, w2);
   } catch (eW) {}
   if (on) {
      var why = cpWrapTooltip(optT("Field view only: switch to 3D VIEW › Field."));
      // (y sin su dorado de «puesto»: apagados y en oro parecían elegidos —captura del 23-oct—; al volver, `_syncButtons` repone el suyo)
      for (i = 0; i < list.length; ++i) { if (!list[i]) continue; try { list[i].enabled = false; list[i].toolTip = why; if (list[i] !== this.zoomSlider && list[i] !== this.zoomLabel) cpStyleToggle(list[i], false); } catch (e) {} }
      this.gx.fieldOff = true;
   } else if (this.gx.fieldOff && !c3GxBroken("leak")) {
      // (al volver al campo, una vez: lo que se apagó aquí se enciende y su tooltip vuelve; el cielo lo rehace `_skySync`)
      for (i = 0; i < list.length; ++i) { var c = list[i]; if (!c || c === this.skyBtn) continue; try { c.enabled = !rec; c.toolTip = cpTooltip(c.cpTipKey || ((c === this.zoomSlider || c === this.zoomLabel) ? "sf.zoom" : "")); } catch (e2) {} }
      try { this.zoomSlider.enabled = (this.state !== null) && !rec; } catch (e3) {}
      this.gx.fieldOff = false;
      if (this._skySync) this._skySync();
   }
};
var c3GxBaseSyncButtons = CPStarfieldDock.prototype._syncButtons;
CPStarfieldDock.prototype._syncButtons = function() { c3GxBaseSyncButtons.call(this); this._gxSync(); };
// ---------------------------------------------------------------------------
// LA ESCALA DE TIEMPO DE LA GALAXIA (23-oct-2026, tarde): la suya, recordada aparte; la del campo, guardada y devuelta al volver
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._gxTimeOn = function() { return !!(this.gx && this.gx.on && this.tm) && !c3GxBroken("range"); };
CPStarfieldDock.prototype._gxRanges = function() { return this._gxTimeOn() ? C3_GXV.RANGES : C3_TM_RANGES; };
// Entrar en la galaxia (on) o salir: la escala y el instante de cada vista, en su sitio. No pinta (lo hace quien llama).
CPStarfieldDock.prototype._gxTimeSwap = function(on) {
   if (!this.tm || !this.gx || c3GxBroken("range")) return;
   var tm = this.tm, gx = this.gx, R;
   if (this._tmStopAnims) { try { this._tmStopAnims(); } catch (eS) {} }
   // (23-oct, noche; revisión visual: en Galaxia la foto seguía con «Rectas, desde el Sol» —y su aviso «pasados ~10 Myr las rectas ya no
   // describen el movimiento»— mientras el mapa iba por órbitas. Con la galaxia, la máquina del tiempo va SIEMPRE por órbitas galácticas —el
   // mismo potencial que el mapa, tm/galaxy.js—, también la foto y la foto del vídeo; el desplegable queda fijo en «Órbitas galácticas» y
   // apagado con su porqué. Lo elegido para el campo no se toca: vuelve al volver a Campo. ROJO «motion»: lo de antes.)
   var gxMotion = !c3GxBroken("motion");
   if (on) {
      gx.field = { range: tm.range, t: tm.t, motion: tm.motion };
      R = (C3_GXV.RANGES.indexOf(gx.range) >= 0) ? gx.range : C3_GXV.RANGE_DEFAULT;
      tm.range = R; tm.t = Math.max(-R, Math.min(R, gx.t || 0));
      if (gxMotion) { tm.motion = "galactic"; tm.blend = null; tm.autoOrbits = false; }
   } else {
      gx.t = tm.t;
      var f = gx.field || { range: Number(c3TmRead("range", DataType_Double, C3_TMUI.RANGE_DEFAULT)), t: 0, motion: String(c3TmRead("motion", DataType_String, "sun")) };
      R = (C3_TM_RANGES.indexOf(f.range) >= 0) ? f.range : C3_TMUI.RANGE_DEFAULT;
      tm.range = R; tm.t = Math.max(-R, Math.min(R, f.t || 0));
      // (2-nov, decisión 1A) sin lo guardado al entrar, lo elegido pasa por la regla del alcance (≥ 10 Ma: órbitas)
      if (!gx.field && typeof c3TmMotionFor === "function" && C3_TMUI.MOTIONS.indexOf(f.motion) >= 0) f.motion = c3TmMotionFor(R, f.motion);
      if (gxMotion && C3_TMUI.MOTIONS.indexOf(f.motion) >= 0) { tm.motion = f.motion; tm.blend = null; }
      tm.autoOrbits = (tm.motion !== (tm.motionUser || tm.motion));
      gx.field = null;
   }
   if (this.state && this.state.tmd && this.state.tmd.tm) this.state.tmd.tm.orbit = null;
   tm.info = null; tm.saidSig = "";
   if (this.state && this.state.tmd) this.state.tmd.info = null;
   try { this.tmSlider.c3range = tm.range; } catch (eR) {}
};
var c3GxBaseTmSetRange = CPStarfieldDock.prototype.tmSetRange;
CPStarfieldDock.prototype.tmSetRange = function(R) {
   if (!this._gxTimeOn()) return c3GxBaseTmSetRange.call(this, R);
   if (C3_GXV.RANGES.indexOf(R) < 0) return;
   var fieldR = (this.gx.field && C3_TM_RANGES.indexOf(this.gx.field.range) >= 0) ? this.gx.field.range : null;
   c3GxBaseTmSetRange.call(this, R);
   this.gx.range = R; c3GxWrite("range", String(R));
   // (la base recuerda la escala como la del CAMPO —TimeMachine/range—: se devuelve la del campo, que sigue siendo la suya)
   if (fieldR !== null) c3TmWrite("range", DataType_Double, fieldR);
   this._tmItems(); this._tmSync();
};
var c3GxBaseTmSync = CPStarfieldDock.prototype._tmSync;
CPStarfieldDock.prototype._tmSync = function() {
   c3GxBaseTmSync.call(this);
   if (!this._gxTimeOn()) { if (this.gx && this.gx.motionOff && this.tmMotion) { this.gx.motionOff = false; try { this.tmMotion.toolTip = cpTooltip("tm.motion"); } catch (eT) {} } return; }
   try { var wasB = this.tm.building; this.tm.building = true; this.tmRange.currentItem = Math.max(0, C3_GXV.RANGES.indexOf(this.tm.range)); this.tm.building = wasB; } catch (e) {}
   // (el desplegable de MOVIMIENTO: fijo en «Órbitas galácticas» y apagado, con su porqué: el mapa no tiene rectas)
   if (!c3GxBroken("motion") && this.tmMotion) {
      try {
         var wasM = this.tm.building; this.tm.building = true; this.tmMotion.currentItem = Math.max(0, C3_TMUI.MOTIONS.indexOf("galactic")); this.tm.building = wasM;
         this.tmMotion.enabled = false; this.tmMotion.toolTip = cpTooltip("gx.motion"); this.gx.motionOff = true;
      } catch (eM) {}
   }
};
var c3GxBaseTmItems = CPStarfieldDock.prototype._tmItems;
CPStarfieldDock.prototype._tmItems = function() {
   c3GxBaseTmItems.call(this);
   if (this._gxTimeOn && this._gxTimeOn()) {
      var was = this.tm.building, i;
      this.tm.building = true;
      try {
         this.tmRange.clear();
         for (i = 0; i < C3_GXV.RANGES.length; ++i) this.tmRange.addItem("± " + c3TmRangeText(C3_GXV.RANGES[i]));
         this.tmRange.currentItem = Math.max(0, C3_GXV.RANGES.indexOf(this.tm.range));
         this.tmRange.toolTip = cpTooltip("gx.range");
      } catch (eI) {} finally { this.tm.building = was; }
   } else if (this.gx) { try { this.tmRange.toolTip = cpTooltip("tm.range"); } catch (eT) {} }
   // (con la galaxia, lo que graba «3D» es el mapa: el desplegable lo dice. Las mismas cuatro opciones, la misma clave: un solo grabador)
   if (this._gxOn && this._gxOn()) { try { this.recWhat.setItemText(1, optT("the time machine: photo + galaxy")); this.recWhat.setItemText(2, optT("the time machine: galaxy")); } catch (e) {} }
};
// La cifra del instante (junto a la regla): con la galaxia, su color es el aviso de las ÓRBITAS (ámbar pasados 100 Myr, rojo pasados
// 500), no el de las rectas del campo (rojo ya a 10 Myr: en la captura del 23-oct «−100 Myr» salía en rojo sobre el mapa de órbitas)
var c3GxBaseTmLabelSync = CPStarfieldDock.prototype._tmLabelSync;
CPStarfieldDock.prototype._tmLabelSync = function() {
   c3GxBaseTmLabelSync.call(this);
   if (!this._gxOn || !this._gxOn() || !this.tmLabel) return;
   var lv = c3TmValidity(this.tm.t, "galactic");
   try { cpApplyStyle(this.tmLabel, "background-color:transparent; color:" + ((lv.level === "beyond") ? cpQss(CP_ATLAS.error) : (lv.level === "warn") ? CP_UI.primaryLight : CP_UI.text) + "; border:none; font-family:" + CP_UI.fontMono + "; font-size:10px;"); } catch (e) {}
};
var c3GxBaseRetranslate = CPStarfieldDock.prototype.retranslate;
CPStarfieldDock.prototype.retranslate = function() {
   c3GxBaseRetranslate.call(this);
   if (!this.gxField) return;
   var t = [[this.gxField, "Field"], [this.gxGalaxy, "Galaxy"], [this.gxTop, "From above"], [this.gxEdge, "Edge-on"], [this.gxOrbits, "Orbits"], [this.gxDust, "Dust"], [this.gxColDist, "Distance"]];
   for (var i = 0; i < t.length; ++i) { try { t[i][0].text = optT(t[i][1]); t[i][0].toolTip = cpTooltip(t[i][0].cpTipKey); } catch (e) {} }
   try { this.gxColLabel.text = optT("Colour"); this.gx3d.toolTip = cpTooltip("gx.3d"); this.gxColGaia.toolTip = cpTooltip("gx.col.gaia"); this.gxColLabel.toolTip = cpTooltip("gx.col.gaia"); } catch (e2) {}
   this._tmItems(); this._gxSync();
   if (this._gxOn()) this._render();
};

// ---------------------------------------------------------------------------
// CAMBIAR la vista, la versión, el color, las órbitas
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype.gxSetOn = function(on) {
   on = (on === true);
   if (!this.gx || this.gx.on === on) return;
   if (this.fl && this.fl.rec !== null) return;                  // (grabando, nada cambia de vista)
   this._animStop();
   if (this.fl && this.fl.preview !== null) this.flightStop();         // (26-oct: la vista previa de un vuelo es de una vista —campo o galaxia—: se para al cambiar, en los dos sentidos)
   if (on) {
      if (this.sky && this.sky.phase && this.sky.phase !== "off") { try { this.skyExit(); } catch (eS) {} }
   }
   this.gx.on = on;
   c3GxWrite("view", on ? "galaxy" : "field");
   this._gxTimeSwap(on);                                          // (23-oct, tarde: la escala de tiempo de cada vista)
   this._light = c3GxBroken("leak") && !on;                       // (ROJO «leak»: el campo se queda en el dibujo ligero)
   this._lod = false; this._drag = null;
   this.hoverStar = -1; this.hoverObj = -1;
   this._tmItems();
   this._syncButtons();
   try { this._tmSync(); } catch (eTs) {}
   this._render();
   try { this.dialog.preview.viewport.repaint(); } catch (e) {}
   if (on) this._gxSay();
   else { try { this._sayState(); } catch (e2) {} }
};
CPStarfieldDock.prototype.gxSetMode = function(m) {
   if (!this.gx || C3_GXV.MODES.indexOf(m) < 0) return;
   this.gx.mode = m; c3GxWrite("mode", m);
   this._syncButtons(); this._render();
};
CPStarfieldDock.prototype.gxSetColor = function(c) {
   if (!this.gx || C3_GXV.COLORS.indexOf(c) < 0) return;
   this.gx.color = c; c3GxWrite("color", c);
   this._syncButtons(); this._render();
};
CPStarfieldDock.prototype.gxSetOrbits = function(on) {
   if (!this.gx) return;
   this.gx.orbits = (on === true); c3GxWrite("orbits", this.gx.orbits ? "on" : "off");
   this._syncButtons(); this._render();
};
// (24-oct-2026, V7f) el POLVO de la Galaxia: encender / apagar (recordado)
CPStarfieldDock.prototype.gxSetDust = function(on) {
   if (!this.gx) return;
   this.gx.dust = (on === true); c3GxWrite("dust", this.gx.dust ? "on" : "off");
   this._syncButtons(); this._render();
};
// (1-nov-2026, D7 del video de formacion) EN GALAXIA, LA LINEA DE ESTADO ES LA DE GALAXIA. Al mover la regla, `_tmSayValidity` (y la red, los nombres de SIMBAD…)
// llaman a `_sayState`, que dice el texto de CAMPO («Esta foto llega a la vista hasta G ≈ 20,1 …»): la linea saltaba del de Galaxia al de Campo con el primer
// movimiento. Ahora `_sayState`, con la Galaxia puesta y su modelo listo, dice el de Galaxia. Costura del rojo: C3_GX_SAYSTATE = false (como antes).
var C3_GX_SAYSTATE = true;
var c3GxBaseSayState = CPStarfieldDock.prototype._sayState;
CPStarfieldDock.prototype._sayState = function() {
   if (C3_GX_SAYSTATE !== false && this._gxOn() && this.state && this.state.gx) { this._gxSay(); return; }
   return c3GxBaseSayState.apply(this, arguments);
};
// La línea de estado al entrar: cuántas tienen órbita y de dónde sale la velocidad radial.
CPStarfieldDock.prototype._gxSay = function() {
   var G = this._gxModel(), st = this.state;
   if (!G || !st || !st.gx) return;
   var c = st.gx.counts;
   this._say(format(optT("Galaxy: %s stars of this field with an orbit (%s without radial velocity yet)"), cpSvGroup(c.orbit), cpSvGroup(c.none)), (c.orbit > 0) ? "ok" : "pending",
             format(optT("%s with their own Gaia DR3 radial velocity, %s with that of their cluster."), cpSvGroup(c.gaia), cpSvGroup(c.cluster)) + "<br><br>" + optT("The map: orbits integrated in MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023): the same potential as the field's «Galactic orbits» and StellarChemistry.") + c3TmBarWords() +
             ((typeof cshGdBarOn === "function" && cshGdBarOn()) ? " " + optT("The chosen star's numbers (pericentre, apocentre, Zmax, e) are without the bar, as in StellarChemistry.") : ""));
};

// ---------------------------------------------------------------------------
// EL MODELO: las estrellas con cinemática completa y sus órbitas (una vez por campo, por velocidades radiales y por escala de tiempo)
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._gxSpanMyr = function() {
   var R = (this.tm && this.tm.range > 0) ? this.tm.range / 1e6 : 0;
   return Math.max(C3_GXV.MIN_SPAN_MYR, Math.min(1000, Math.ceil(R)));
};
CPStarfieldDock.prototype._gxModel = function() {
   var st = this.state;
   if (!st || !st.result || !st.result.ok || !this.tm) return null;
   var base = this._tmBaseModel(), rvRef = st.tmRv || null, span = this._gxSpanMyr(), wantNow = !c3GxBroken("nonow");
   if (st.gx && st.gx.baseRef === base && st.gx.rvRef === rvRef && st.gx.G && st.gx.G.tMyr >= span && st.gx.wantNow === wantNow) return st.gx.G;
   var t0 = Date.now(), objs = base.objects, want = {}, nWant = 0, i, k;
   for (i = 0; i < objs.length; ++i) if (objs[i].kind === "star" || objs[i].kind === "member") { want[objs[i].ref] = true; ++nWant; }
   // (la MISMA elección de velocidad radial que la máquina del tiempo: c3TmBuild —la de Gaia DR3 si es precisa, la del cúmulo en los
   //  miembros si no—; las que se quedan en «none» no tienen órbita)
   var tm = c3TmBuild(st.result, { tan: null, epochYears: st.result.field.years, model: "linear", rv: rvRef ? rvRef.rv : {}, indices: want }), stars = st.result.stars;
   var items = [], nowItems = [], counts = { orbit: 0, gaia: 0, cluster: 0, none: nWant - tm.n, now: 0 };
   for (k = 0; k < tm.n; ++k) {
      i = tm.idx[k];
      var s = stars[i], dPc = tm.dPc[k];
      if (tm.rvFrom[k] === "none") {
         ++counts.none;
         // (23-oct, tarde) sin velocidad radial, con distancia: su sitio de HOY (la posición no depende de la velocidad: rv = 0 solo para llamar)
         if (wantNow && dPc > 0 && isFinite(dPc)) {
            var p0 = cshGdState(s.ra0, s.dec0, dPc, s.pmRa || 0, s.pmDec || 0, 0);
            if (p0 && isFinite(p0.x)) nowItems.push({ i: i, x: p0.x, y: p0.y, z: p0.z, name: this._starShownName(i, s), g: s.g, data: { bpRp: s.bpRp, pc: dPc, rvFrom: "none", suspect: !!(s.dist && s.dist.quality === "suspect") } });
         }
         continue;
      }
      items.push({ i: i, st: cshGdState(s.ra0, s.dec0, dPc, s.pmRa, s.pmDec, tm.rvKms[k]), name: this._starShownName(i, s), g: s.g, grp: (s.cluster >= 0) ? "c" + s.cluster : "field",
                   data: { bpRp: s.bpRp, pc: dPc, rvFrom: tm.rvFrom[k], suspect: !!(s.dist && s.dist.quality === "suspect") } });
      ++counts[tm.rvFrom[k]];
   }
   counts.orbit = items.length;
   var self = this, busy = false;
   if (items.length > 200) { try { this.dialog.preview.setBusy(true, format(optT("Integrating %s orbits in the Milky Way (MilkyWayPotential2022)…"), cpSvGroup(items.length)), false); busy = true; } catch (eB) {} }
   var G = null;
   try {
      // (groupMax 6: los miembros de un cúmulo con la velocidad del cúmulo tienen todos la MISMA órbita: se dibujan seis, no cientos)
      G = cshGalaxyModel(items, { tMyr: span, backMyr: span, nNoKin: counts.none, groupMax: 6, now: nowItems, onProgress: function(f) {
         if (typeof C3_CLOSING !== "undefined" && C3_CLOSING) return false;
         if (busy) { try { self.dialog.preview.setBusy(true, format(optT("Integrating %s orbits in the Milky Way (MilkyWayPotential2022)… %d %%"), cpSvGroup(items.length), Math.round(100 * f)), false); } catch (eP) {} }
         return true;
      } });
   } finally { if (busy) { try { this.dialog.preview.setBusy(false); } catch (eF) {} } }
   if (G === null) return null;
   counts.now = G.now ? G.now.length : 0;
   st.gx = { baseRef: base, rvRef: rvRef, G: G, counts: counts, ms: Date.now() - t0, sel: {}, wantNow: wantNow };
   cshGxStaticFree(this.gx.cache); cshGxStaticFree(this.gx.vcache);
   return G;
};
// La órbita de la FICHA de la elegida: 2 Gyr hacia el futuro, como la de CabraComposition (cshGdOrbit; ~2 ms, una vez por estrella).
CPStarfieldDock.prototype._gxSelMeas = function(G, idx) {
   var st = this.state;
   if (!st || !st.gx || !(idx >= 0) || !G.byIdx.hasOwnProperty(idx)) return null;
   if (!st.gx.sel.hasOwnProperty(idx)) st.gx.sel[idx] = cshGdOrbit(G.stars[G.byIdx[idx]].st);
   return st.gx.sel[idx];
};
// …y su trayectoria con un punto en CADA paso (0,5 Myr; la de todas va a 2 Myr): la elegida se dibuja sin esquinas.
CPStarfieldDock.prototype._gxSelTr = function(G, idx) {
   var st = this.state;
   if (!st || !st.gx || !(idx >= 0) || !G.byIdx.hasOwnProperty(idx)) return null;
   if (!st.gx.selTr) st.gx.selTr = {};
   // (23-oct, noche: hacia el futuro, los 2 Gyr de su ficha —el pie lo dice: «la elegida, 2 Ga», el texto canónico de CabraComposition—; ~4 ms)
   if (!st.gx.selTr.hasOwnProperty(idx)) { var e = G.stars[G.byIdx[idx]]; st.gx.selTr[idx] = e.tr ? cshGdTrajectory(e.st, Math.max(G.tMyr, CSH_GX.T_MYR), G.backMyr, CSH_GX.DT_MYR, 1) : null; }
   return st.gx.selTr[idx];
};

// Por qué no hay ninguna órbita: lo que dice la red de las velocidades radiales (23-oct-2026, tarde)
CPStarfieldDock.prototype._gxEmptyWhy = function() {
   var st = this.state, net = (st && st.net) ? st.net : {}, rv = String(net.rv || ""), out = [];
   if (st && st.partial) out.push(optT("The whole field is still being read from Gaia; then VizieR is asked for the radial velocities."));
   else if (rv === "" || rv === "running") out.push(optT("Waiting for the radial velocities (Gaia DR3, from VizieR, GAVO or ESA): an orbit needs a distance, a proper motion and a radial velocity. They arrive in a few seconds."));
   else if (rv.indexOf("failed") === 0) out.push(optT("Neither VizieR nor its backups GAVO and ESA sent the radial velocities (Gaia DR3) and there is no copy in the cache: without them no star has an orbit. «↻ Retry» in the status line asks again."));
   else out.push(optT("Gaia DR3 measures the radial velocity only of the brighter stars (G up to about 15): none of this field has one, nor a cluster that gives it its own."));
   return out;
};

// ---------------------------------------------------------------------------
// LAS OPCIONES DEL DIBUJO (las mismas para el panel y el vídeo)
// ---------------------------------------------------------------------------
// Las líneas de la placa del instante a T años (la cifra, el modelo, los avisos). `tpl`: la plantilla de lo más que llega a ocupar (el
// encuadre la mide así, una vez por escala: la placa no cambia de sitio ni el encuadre de tamaño mientras corre el tiempo).
CPStarfieldDock.prototype._gxPlateLines = function(T, tpl) {
   var plate = [{ t: (T === 0) ? cshGxT("gxNow") : c3TmTimeText(T), kind: "big" }, { t: cshGxT("gxModel"), kind: "small" }], aT = Math.abs(T) / 1e6;
   if (tpl && aT > 100) plate.push({ t: (cshGxT("gxWarn").length >= cshGxT("gxBeyond").length) ? cshGxT("gxWarn") : cshGxT("gxBeyond"), kind: "warn" });
   else if (aT > 500) plate.push({ t: cshGxT("gxBeyond"), kind: "warn" }); else if (aT > 100) plate.push({ t: cshGxT("gxWarn"), kind: "warn" });
   if (this.tm && this.tm.range < C3_GXV.SHORT_RANGE && (tpl || T !== 0 || this.c3Open === "time")) plate.push({ t: cshGxF("gxShort", { r: c3TmRangeText(this.tm.range) }), kind: "warn" });
   return plate;
};
// LA TÍPICA DEL CAMPO (23-oct, noche; revisión visual: la elegida de las capturas y los vídeos era la MÁS excéntrica —Gaia DR3
// 64801440066594944, e 0,97, una estrella del halo de verdad: ver HANDOFF— y su órbita casi radial dominaba el mapa). La más cercana a la
// MEDIANA de la órbita (peri, apo, Zmax de lo integrado) entre las de su grupo más numeroso (el cúmulo si lo hay: «c<n>»; si no, el campo),
// prefiriendo su propia velocidad radial de Gaia y su distancia sin dudas (RUWE < 1,4). Índice del script, o −1.
CPStarfieldDock.prototype._gxTypical = function(G) {
   if (!G || !G.stars.length) return -1;
   if (G._typ !== undefined) return G._typ;
   var cnt = {}, top = "", tc = -1, i, k;
   for (i = 0; i < G.stars.length; ++i) if (G.stars[i].tr) { var gg = G.stars[i].grp; cnt[gg] = (cnt[gg] || 0) + 1; }
   for (k in cnt) if (cnt.hasOwnProperty(k) && (cnt[k] > tc || (cnt[k] === tc && k.charAt(0) === "c"))) { tc = cnt[k]; top = k; }
   // (un cúmulo con al menos 10 con órbita va primero aunque el campo tenga más: es lo que la foto enseña)
   for (k in cnt) if (cnt.hasOwnProperty(k) && k.charAt(0) === "c" && cnt[k] >= 10 && (top.charAt(0) !== "c" || cnt[k] > cnt[top])) top = k;
   function med(a) { var b = a.slice().sort(function(p, q) { return p - q; }); return b.length ? b[b.length >> 1] : 0; }
   var cand = [], P = [], A = [], Z = [];
   for (i = 0; i < G.stars.length; ++i) { var e = G.stars[i]; if (!e.tr || e.grp !== top || !e.meas || !isFinite(e.meas.rperi)) continue; cand.push(i); P.push(e.meas.rperi); A.push(e.meas.rapo); Z.push(e.meas.zmax); }
   if (!cand.length) { G._typ = G.stars[0].i; return G._typ; }
   var mp = med(P), ma = med(A), mz = med(Z), best = -1, bd = Infinity;
   for (k = 0; k < cand.length; ++k) {
      var s = G.stars[cand[k]], d = Math.pow((s.meas.rperi - mp) / 0.5, 2) + Math.pow((s.meas.rapo - ma) / 0.5, 2) + Math.pow((s.meas.zmax - mz) / 0.1, 2);
      if (s.data && s.data.suspect) d += 100;                    // (distancia dudosa: solo si no hay otra)
      if (s.data && s.data.rvFrom !== "gaia") d += 10;           // (la de su propia velocidad radial, mejor que la del cúmulo)
      if (d < bd) { bd = d; best = cand[k]; }
   }
   G._typ = (best >= 0) ? G.stars[best].i : -1;
   return G._typ;
};
CPStarfieldDock.prototype._gxViewOpts = function(G, sc, light, opts) {
   var self = this, gx = this.gx, mode = c3GxBroken("view") ? "top" : gx.mode, T = (this.tm && this.tm.t) ? this.tm.t : 0, color = gx.color;
   var anyHollow = false, anyCl = false, i;
   if (G) for (i = 0; i < G.stars.length; ++i) { var d = G.stars[i].data; if (d.suspect) anyHollow = true; if (d.rvFrom === "cluster") anyCl = true; }
   var extra = [];
   if (anyHollow) extra.push({ kind: "hollow", text: cshGxT("gxHollow") });
   var trail = !!(this.tm && this.tm.trails) && T !== 0;
   if (trail) extra.push({ kind: "trail", text: cshGxT("gxTrail") });
   var legend = (color === "dist")
      ? { title: cshGxT("gxColourDist"), extra: extra, gradient: { from: 1, to: 4, rgb: function(v) { return c3GxDistRgb(Math.pow(10, v)); }, ticks: [1, 2, 3, 4],
          tickText: function(v) { return (v >= 3) ? cshGxNum(Math.pow(10, v - 3), 0) + " kpc" : cshGxNum(Math.pow(10, v), 0) + " pc"; } } }
      : { title: cshGxT("gxColourGaia"), extra: extra, gradient: { from: -0.3, to: 3.3, rgb: cpSvStarRgb, ticks: [0, 1, 2, 3], tickText: function(v) { return cshGxNum(v, 0); }, none: cshGxT("gxBpRpNone"), noneRgb: C3_GXV.NO_BPRP } };
   // (26-oct, V7i) la fila que sale fuera de «hoy» (la estela), para que la leyenda se mida con ella siempre y no cambie de esquina al reproducir
   if (this.tm && this.tm.trails) legend.extraMax = [{ kind: "trail", text: cshGxT("gxTrail") }];
   // (26-oct, V7h) dustMyr: el polvo gira con la Galaxia y pierde la identidad con el instante (csh_galaxy_dust.js cshGxdTime)
   var V = { legendSlimBelow: c3GxBroken("slimleg") ? 0 : C3_GXV.SLIM_BELOW, mode: mode, orbits: gx.orbits, dust: gx.dust === true && !c3GxBroken("nodust"), dustMyr: T / 1e6, colorKey: color, light: light === true, arms: true, legend: legend, legendOn: true, cam: gx.cam, v2: gx.v2, tMyr: T / 1e6,
             trail: trail, trailMax: CSH_GX.SHOW_MYR, sel: this.selStar, bgInt: 0x00000000, insetHex: cpMix(CP_ATLAS.bg, "#000000", 0.35),
             colorOf: function(e) { var dd = e.data; return { rgb: (color === "dist") ? c3GxDistRgb(dd.pc) : c3GxBpRpRgb(dd.bpRp), hollow: dd.suspect }; } };
   // (23-oct, noche) la elegida; sin ninguna, en el VÍDEO la típica del campo (`auto`: la pide _gxVideoFrame) y se dice en su rótulo
   var selI = (G && this.selStar >= 0 && G.byIdx.hasOwnProperty(this.selStar)) ? this.selStar : -1, auto = false;
   if (selI < 0 && G && opts && opts.autoSel === true) { selI = this._gxTypical(G); auto = (selI >= 0); }
   if (selI >= 0) {
      V.sel = selI;
      V.selMeas = this._gxSelMeas(G, selI);
      V.selTr = this._gxSelTr(G, selI);
      var e = G.stars[G.byIdx[selI]];
      V.selExtra = this._dist(e.data.pc) + " · " + ((e.data.rvFrom === "cluster") ? optT("radial velocity of its cluster") : optT("radial velocity of Gaia DR3")) +
                   (auto ? " · " + optT("a typical star of the field (closest to the median orbit)") : "");
   }
   // la placa del instante: cuándo, con qué modelo, y los avisos (validez; la escala de la máquina del tiempo demasiado corta)
   var plate = this._gxPlateLines(T, false);
   V.plate = plate;
   // (23-oct, noche; revisión visual) EL ENCUADRE DE LA NUBE en toda la escala de la máquina del tiempo y la leyenda y la placa donde no
   // hay estrellas (CabraShared/csh_galaxy_paint.js cshGxFitView). La placa se mide con lo más grande que llega a ser en esa escala.
   var Rm = (this.tm && this.tm.range > 0) ? this.tm.range / 1e6 : 0;
   if (!c3GxBroken("fit") && Rm > 0) {
      V.fitWin = [-Rm, Rm];
      var pA = this._gxPlateLines(-this.tm.range, true), pB = this._gxPlateLines(this.tm.range, true);
      V.plateMax = (pA.length > pB.length) ? pA : pB;
      // (la cifra más ancha de la escala: «−88,88 Ma» es más larga que «−100 Ma»)
      var tA = c3TmTimeText(-this.tm.range), tB = c3TmTimeText(-0.8888 * this.tm.range), tBig = (tB.length > tA.length) ? tB : tA;
      for (i = 0; i < V.plateMax.length; ++i) if (V.plateMax[i].kind === "big") V.plateMax[i] = { t: tBig, kind: "big" };
   }
   // (23-oct, tarde) sin ninguna estrella con órbita, el porqué (en grande, en medio del mapa: cshGxPaintOver)
   if (G && G.stars.length === 0) V.emptyWhy = this._gxEmptyWhy();
   return V;
};

// ---------------------------------------------------------------------------
// EL DIBUJO del panel: la cabecera de Cabra3D, el mapa y el pie
// ---------------------------------------------------------------------------
var c3GxBaseRenderAt = CPStarfieldDock.prototype.renderAt;
CPStarfieldDock.prototype.renderAt = function(w, h, sc, opts) {
   if (!this._gxOn() || this.state === null) return c3GxBaseRenderAt.call(this, w, h, sc, opts);
   var bmp = (opts && opts.into && opts.into.width === w && opts.into.height === h) ? opts.into : new Bitmap(w, h), lay = null;
   bmp.fill(CP_INT_SURFACE);
   var g = new Graphics(bmp);
   try {
      g.antialiasing = true;
      try { g.textAntialiasing = true; } catch (eTa) {}
      lay = this._gxDraw(g, w, h, sc, opts || {});
   } finally { g.end(); }
   lay.w = w; lay.h = h; lay.sc = sc;
   this._card = this._currentCard();          // (26-oct-2026: la ficha de la estrella elegida o bajo el cursor, la MISMA del Campo, abajo; tm/galaxy_card.js le suma lo propio de la Galaxia)
   return { bitmap: bmp, lay: lay };
};
function c3GxNoModelRow(lines) {
   if (!lines) return lines;
   var out = [], m = cshGxT("gxModel");
   for (var i = 0; i < lines.length; ++i) if (!(lines[i].kind === "small" && lines[i].t === m)) out.push(lines[i]);
   return out;
}
CPStarfieldDock.prototype._gxDraw = function(g, w, h, sc, o) {
   var t0 = Date.now(), F = this._fonts(sc), P = function(v) { return Math.round(v * sc); }, G = this._gxModel(), gx = this.gx;
   var mode = c3GxBroken("view") ? "top" : gx.mode, sub = optT("where its stars are in the Milky Way") + " · " + cshGxT(mode === "edge" ? "gxTitleEdge" : (mode === "3d" ? "gxTitle3d" : "gxTitleTop"));
   var top = this._drawHead(g, w, sc, F, C3_EYEBROW + "  ·  " + optT("THE GALAXY"), sub);
   // (26-oct-2026) el mapa deja abajo el sitio de la ficha (la del Campo: `_drawCard`), siempre el mismo: al elegir o pasar el cursor el mapa no se mueve
   var frame = { x: P(CP_SFUI.PAD), y: top, w: w - 2 * P(CP_SFUI.PAD), h: Math.max(60, h - top - P(CP_SFUI.FOOT_H) - this._cardH(sc, F, 1) - P(CP_SFUI.GAP)) };
   var V = this._gxViewOpts(G, sc, o.light === true), R = null;
   V.frame = frame;
   V.selLabel = (c3GxBroken("label")) ? true : false;          // (en el mapa solo la marca de la elegida; su texto va a la ficha. Rojo «label»: el rótulo largo de antes)
   // (28-oct, V5, decisión de Nino) la placa del PANEL lleva otra vez «órbitas en MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023)»: a lienzo
   // pequeño el pie no cabe y sin esa línea el potencial no se veía. Se parte al ancho de su reloj (`plateWrap`, D1: la placa no más ancha que el reloj) y
   // el encaje y la esquina de la placa cuentan con ella (V.plateMax lleva la línea). Rojo C3_CLKP_BREAK «nomodel» = la placa sin la línea (27-oct, D1).
   if (typeof c3ClkpBroken === "function" && c3ClkpBroken("nomodel")) { V.plate = c3GxNoModelRow(V.plate); if (V.plateMax) V.plateMax = c3GxNoModelRow(V.plateMax); }
   if (this._gxPanelClock) this._gxPanelClock(V, w, h, sc, frame, o);       // (26-oct: el reloj en la placa del panel, tm/timeclock_panel.js)
   if (G) {
      var S = cshGxStaticDraw(g, gx.cache, w, h, G, sc, V);          // (26-oct, V7h: con el polvo vivo, el polvo del instante DEBAJO de la capa fija)
      var C2 = cshGxCloneCtx(S.C);
      cshGxPaintDynamic(g, w, h, G, sc, V, C2);
      R = cshGxPaintOver(g, w, h, G, sc, V, C2);
      R.staticFresh = S.fresh;
   } else {
      R = cshGalaxyPaint(g, w, h, null, sc, V);
   }
   var st = this.state, c = (st && st.gx) ? st.gx.counts : null;
   // (2-nov, E1) Rojo C3_GXV_BREAK «footmodel» = el pie (y su tooltip, las notas) sin la línea del potencial: c3_gx_review V5 tiene que caer
   var foot = (R.footText || "") + (c && c.cluster ? " · " + format(optT("%s with the cluster's radial velocity"), cpSvGroup(c.cluster)) : "") +
              (c3GxBroken("footmodel") ? "" : " · " + optT("orbits in MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), the same as the time machine of the field"));
   var ft = this._drawFoot(g, w, h, sc, F, foot);
   gx.lastMs = Date.now() - t0;
   return { kind: "galaxy", G: G, R: R, foot: ft, frame: frame, mode: mode, ms: gx.lastMs, cardY: c3GxBroken("nocard") ? undefined : h - P(CP_SFUI.FOOT_H) - this._cardH(sc, F, 1) };
};
// El anillo de lo que hay bajo el cursor (onPaint solo copia y pinta esto)
var c3GxBaseDrawMarks = CPStarfieldDock.prototype._drawMarks;
CPStarfieldDock.prototype._drawMarks = function(g, lay, k) {
   if (!lay || lay.kind !== "galaxy") return c3GxBaseDrawMarks.call(this, g, lay, k);
   var G = lay.G, pr = G ? G.proj : null, sc = lay.sc * k;
   // la ficha de abajo: la MISMA que en el Campo (`_drawCard`; la rehace quien cambia lo elegido o lo que hay bajo el cursor)
   if (lay.cardY !== undefined) lay.card = this._drawCard(g, lay.w * k, lay.cardY * k, sc, this._fonts(sc), this._card || null);
   if (!pr || !(this.hoverStar >= 0) || !G.byIdx.hasOwnProperty(this.hoverStar)) return;
   var j = G.byIdx[this.hoverStar];
   if (!pr.ok[j]) return;
   var x = pr.x[j] * k, y = pr.y[j] * k, R = CP_SFUI.RING * sc;
   g.brush = new Brush(0x00000000);
   g.pen = new Pen(cpInt(CP_ATLAS.bg, 0.8), Math.max(3, 3 * sc)); g.drawCircle(x, y, R);
   g.pen = new Pen(CP_INT_AMBER, Math.max(1.5, 1.5 * sc)); g.drawCircle(x, y, R);
};

// ---------------------------------------------------------------------------
// EL RATÓN en el mapa: el de Cabra3D (izquierdo gira en 3D y desplaza en 2D; derecho, central o Mayús desplazan; rueda hacia el
// cursor; doble clic, la vista entera; clic, elegir —la misma estrella en la foto y en el 3D del campo—)
// ---------------------------------------------------------------------------
var c3GxBaseHitAt = CPStarfieldDock.prototype._hitAt;
CPStarfieldDock.prototype._hitAt = function(x, y) {
   var lay = this.lay;
   if (!lay || lay.kind !== "galaxy") return c3GxBaseHitAt.call(this, x, y);
   var out = { star: -1, obj: -1 }, G = lay.G;
   if (!G) return out;
   var i = cshGalaxyPick(G, x, y, lay.sc);
   if (i >= 0) { out.star = i; var m = this._distModel(); if (m && m.objOfStar && Object.prototype.hasOwnProperty.call(m.objOfStar, i)) out.obj = m.objOfStar[i]; }
   return out;
};
var c3GxBaseOnPress = CPStarfieldDock.prototype._onPress;
CPStarfieldDock.prototype._onPress = function(x, y, button, modifiers) {
   c3GxBaseOnPress.call(this, x, y, button, modifiers);
   if (this._drag && this.lay && this.lay.kind === "galaxy" && this.lay.G && this.lay.G.proj) { var P = this.lay.G.proj.P; this._drag.gx = { fit: P.cam || null, xf: P.xf || null }; }
};
// (28-oct, V7) EL TOOLTIP DE LA LEYENDA ESTRECHA: lo que la leyenda no pinta (R.legend.hidden), una entrada por renglón. El tooltip de Qt es HTML:
// los textos llanos se escapan (&, <, >) o un «<» abriría una etiqueta y se perdería el resto (ficha del 28-oct, hud.js). Se parte aquí, entrada a entrada,
// a CP_TOOLTIP_WRAP caracteres SIN contar las etiquetas (cpWrapTooltip parte el HTML ya montado y deja un «·» solo en un renglón); el resultado va tal cual al tooltip.
function c3GxLegendTip(L) {
   if (!L || !L.slim || !L.hidden || !L.hidden.length) return "";
   var esc = function(t) { return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }, lines = [esc(optT("Also in this map:"))], i, j;
   for (i = 0; i < L.hidden.length; ++i) {
      var words = String(L.hidden[i]).split(" "), cur = "", first = true;
      for (j = 0; j < words.length; ++j) {
         if (cur.length && cur.length + 1 + words[j].length > CP_TOOLTIP_WRAP) { lines.push((first ? "· " : "&nbsp;&nbsp;") + esc(cur)); first = false; cur = words[j]; }
         else cur += (cur.length ? " " : "") + words[j];
      }
      lines.push((first ? "· " : "&nbsp;&nbsp;") + esc(cur));
   }
   return "<html>" + lines.join("<br>") + "</html>";
}
var c3GxBaseOnMove = CPStarfieldDock.prototype._onMove;
CPStarfieldDock.prototype._onMove = function(x, y, buttons) {
   var d = this._drag;
   var LG = (!buttons && !d && this._gxOn() && this.lay && this.lay.kind === "galaxy" && this.lay.R) ? this.lay.R.legend : null;
   if (LG && LG.slim && x >= LG.x0 && x <= LG.x1 && y >= LG.y0 && y <= LG.y1) {
      // (sobre la leyenda: ninguna estrella bajo el cursor y su tooltip, una vez)
      if (this.hoverStar >= 0 || this.hoverObj >= 0) this._setHover(-1, -1);
      var tipL = c3GxLegendTip(LG);
      if (this._tip !== tipL) { this._tip = tipL; try { this.canvas.toolTip = tipL; } catch (eTL) {} }
      return;
   }
   if (!(d && d.gx && buttons !== 0 && this._gxOn())) return c3GxBaseOnMove.call(this, x, y, buttons);
   var dx = x - d.x, dy = y - d.y;
   if (!d.moved && dx * dx + dy * dy <= 9) return;
   d.moved = true;
   this._lastInput = Date.now();
   var gx = this.gx;
   if (gx.mode === "3d" && d.gx.fit) gx.cam = d.pan ? cshGxCamPan(d.gx.fit, dx, dy) : cshGxCamOrbit(d.gx.fit.view, dx, dy);
   else if (d.gx.xf) gx.v2[gx.mode] = cshGx2DPan(d.gx.xf, dx, dy);
   else return;
   this._light = CP_SFUI_LIGHT_DRAG;            // (mientras se arrastra, lo ligero; al soltar, el dibujo entero: `_onRelease` de siempre)
   this.hoverStar = -1; this.hoverObj = -1;
   this._render();
};
var c3GxBaseOnWheel = CPStarfieldDock.prototype._onWheel;
CPStarfieldDock.prototype._onWheel = function(x, y, delta) {
   if (!this._gxOn() || !this.lay || this.lay.kind !== "galaxy") return c3GxBaseOnWheel.call(this, x, y, delta);
   if (this.flightBusy() || !delta || !this.lay.G || !this.lay.G.proj) return;
   this._lastInput = Date.now();
   var f = (delta > 0) ? 1.25 : 0.8, pr = this.lay.G.proj, P = pr.P, gx = this.gx;
   if (gx.mode === "3d" && P.cam) {
      var near = -1, bd = Math.pow(10 * this.lay.sc, 2);
      for (var i = 0; i < pr.n; ++i) { if (!pr.ok[i]) continue; var ddx = pr.x[i] - x, ddy = pr.y[i] - y, dd = ddx * ddx + ddy * ddy; if (dd < bd) { bd = dd; near = i; } }
      gx.cam = cshGxCamZoomAt(P.cam, f, x, y, (near >= 0) ? pr.z[near] : undefined);
   } else if (P.xf) gx.v2[gx.mode] = cshGx2DZoomAt(P.xf, f, x, y);
   else return;
   if (CP_SFUI_LIGHT_DRAG === true && !this._drag) { this._light = true; try { this.settleTimer.stop(); this.settleTimer.start(); } catch (eSt) { this._light = false; } }
   this._render();
};
var c3GxBaseResetView = CPStarfieldDock.prototype.resetView;
CPStarfieldDock.prototype.resetView = function() {
   if (!this._gxOn()) return c3GxBaseResetView.call(this);
   if (this.gx.mode === "3d") this.gx.cam = null; else this.gx.v2[this.gx.mode] = null;
   this._render();
};
var c3GxBaseSelectStar = CPStarfieldDock.prototype.selectStar;
CPStarfieldDock.prototype.selectStar = function(star, obj) {
   c3GxBaseSelectStar.call(this, star, obj);
   if (this._gxOn()) this._render();             // (la elegida va en la capa de encima del mapa: se rehace, la capa fija no)
};
// Sin transiciones de cámara en el mapa (son de la caja del campo)
var c3GxBaseAnimGo = CPStarfieldDock.prototype._animGo;
CPStarfieldDock.prototype._animGo = function(snap, opts) { if (this._gxOn()) return false; return c3GxBaseAnimGo.call(this, snap, opts); };

// ---------------------------------------------------------------------------
// EL VÍDEO: el grabador de siempre (tm/timemachine_video.js · c3TmRecorder) pregunta `_gxVideoOn` y pinta con `_gxVideoFrame`
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._gxVideoOn = function() { return this._gxOn() && !c3GxBroken("video"); };
CPStarfieldDock.prototype._gxVideoTag = function(kind) { return this._gxVideoOn() ? ((kind === "both") ? "photo_galaxy_" : "galaxy_") + this.gx.mode : ""; };
// EL RELOJ ANALÓGICO en la placa del vídeo (25-oct-2026, fase 2; tm/timeclock.js): la fila «big» del instante (la cifra grande) pasa a ser un RELOJ
// —«hoy» arriba, el pasado a la izquierda, el futuro a la derecha, en la escala elegida de la máquina del tiempo— y esa misma cifra, su cifra exacta
// pequeña debajo; el modelo y los avisos siguen como estaban. La caja de la fila es la misma en todo el vídeo (la de la cifra más ancha de la escala):
// la placa no cambia de tamaño ni de sitio mientras corre el tiempo. (26-oct: también en el PANEL —tm/timeclock_panel.js `_gxPanelClock`—, con su radio
// `Rp` y `panel` = true: la esfera guardada en un bitmap, c3ClkpPaint, y lo pintado en gx.panelClock; el vídeo, en gx.lastClock.)
CPStarfieldDock.prototype._gxClockPlate = function(V, w, h, Rp, panel) {
   var tm = this.tm, T = tm.t || 0, range = tm.range, R = (Rp > 0) ? Rp : c3ClkRadius(w, h), i, bigNow = "", bigMax = "";
   for (i = 0; V.plate && i < V.plate.length; ++i) if (V.plate[i].kind === "big") { bigNow = V.plate[i].t; break; }
   for (i = 0; V.plateMax && i < V.plateMax.length; ++i) if (V.plateMax[i].kind === "big") { bigMax = V.plateMax[i].t; break; }
   if (!bigMax.length) bigMax = (bigNow.length > c3TmTimeText(-range).length) ? bigNow : c3TmTimeText(-range);
   var M = c3ClkMeasure(range, R, bigMax, panel !== true), self = this;
   function row(caption) {
      return { kind: "clock", w: M.w, h: M.h, paint: function(g, x, y) {
         if (panel === true && typeof c3ClkpPaint === "function") { var sp = c3ClkpPaint(g, x, y, M, T, range, caption); self.gx.panelClock = sp; return sp; }
         var st = c3ClkPaint(g, x, y, M, T, range, caption, { faceAlpha: C3_CLK.FACE_A }); self.gx.lastClock = st; return st; } };
   }
   function swap(lines, cap) { if (!lines) return lines; var out = []; for (var q = 0; q < lines.length; ++q) out.push(lines[q].kind === "big" ? row(cap) : lines[q]); return out; }
   V.plate = swap(V.plate, bigNow);
   if (V.plateMax) V.plateMax = swap(V.plateMax, bigMax);
};
// DONDE va la placa con el reloj en la vista 3D (la única sin encuadre por esquinas: la cámara gira): la esquina de arriba a la izquierda o abajo a la izquierda
// (arriba a la derecha está la leyenda; en vertical, solo arriba) con MENOS estrellas debajo, contadas sobre las estrellas proyectadas en cinco instantes del
// guion (hoy, rebobinando, −escala, avanzando, +escala: a ±1 Ga la nube se abre y tapaba el 41 % de las estrellas arriba a la izquierda). UNA vez por
// campo, escala, tamaño e idioma. Sin reloj (texto de antes) o fuera del 3D no se llama.
CPStarfieldDock.prototype._gxClockCorner3d = function(V, w, h, bmp) {
   var G = this._gxModel(), tm = this.tm, key = [w, h, tm.range, c3ClkLang(), V.plateK, c3ClkBroken("corner") ? 1 : 0].join("|"), memo = this.gx.clockAt;
   if (memo && memo.G === G && memo.key === key) return memo.corner;
   var cands = (h > w) ? ["tl"] : ["tl", "bl"], corner = "tl";
   if (cands.length > 1 && G) {
      var sc = Math.max(1, Math.min(w, h) / 540), rect = { x: 0, y: 0, w: w, h: h }, pl = V.plateMax || V.plate, tot = { tl: 0, bl: 0 }, saveT = tm.t, c, j;
      var boxes = {}; for (c = 0; c < cands.length; ++c) boxes[cands[c]] = cshGxPlate(null, null, pl, rect, sc, true, cands[c], V.plateK);
      var Ss = [C3_TMV.HOLD0 + 0.2, (C3_TMV.HOLD0 + C3_TMV.BACK) / 2, C3_TMV.BACK, (C3_TMV.HOLD1 + C3_TMV.FWD) / 2, C3_TMV.FWD], tmp = new Bitmap(w, h);
      this.gx.clockAt = { G: G, key: key, corner: "tl" };            // (los fotogramas de medida entran aquí otra vez con plate:false: no llegan a esta función)
      for (j = 0; j < Ss.length; ++j) {
         tm.t = c3TmVideoTime(Ss[j], tm.range);
         this._gxVideoFrame(tmp, Ss[j] / C3_TMV.S, false, { plate: false });
         var Gp = (this.state && this.state.gx && this.state.gx.G) ? this.state.gx.G.proj : null;
         if (!Gp) continue;
         for (var i = 0; i < Gp.n; ++i) if (Gp.ok[i]) for (c = 0; c < cands.length; ++c) { var b = boxes[cands[c]]; if (Gp.x[i] >= b.x0 && Gp.x[i] <= b.x1 && Gp.y[i] >= b.y0 && Gp.y[i] <= b.y1) ++tot[cands[c]]; }
      }
      tm.t = saveT; try { tmp.clear(); } catch (eT) {}
      var red = c3ClkBroken("corner");
      if (red ? (tot.bl > tot.tl) : (tot.bl < tot.tl * 0.8)) corner = "bl";
      this.gx.clockCounts = { tl: tot.tl, bl: tot.bl };
   }
   this.gx.clockAt = { G: G, key: key, corner: corner };
   return corner;
};
// Un fotograma del mapa en `bmp` (chrome fuera: el contador y el título los pone el grabador). `frac` = el avance del guion (0…1):
// en 3D la cámara gira despacio (C3_TMV.YAW, como el 3D del campo). `pip`: en el recuadro de «foto + galaxia» (sin leyenda).
// `vo` (23-oct, noche; revisión visual): { plate (true: la placa del instante DENTRO del mapa —en su rejilla de ocupación, en la esquina sin
// estrellas—, en vez del contador del grabador, que caía encima de la leyenda), reserve ([[x0, y0, x1, y1]]: lo que el grabador pinta encima
// del mapa —el rótulo del recuadro—, para que los rótulos del mapa no lo pisen) }. Sin elegida, la típica del campo (dicho en su rótulo).
// Lo pintado (R: leyenda, placa, rótulos) queda en this.gx.lastVideoR.
CPStarfieldDock.prototype._gxVideoFrame = function(bmp, frac, pip, vo) {
   vo = vo || {};
   var G = this._gxModel(), w = bmp.width, h = bmp.height, sc = Math.max(1, Math.min(w, h) / 540), V = this._gxViewOpts(G, sc, false, { autoSel: !c3GxBroken("extreme") });
   V.chrome = false; V.frame = null; V.legendOn = !pip; V.bgInt = cpInt(CP_ATLAS.bg);
   V.legendCompact = true;            // (24-oct, V7f: el polvo comparte fila con el resplandor en el vídeo: la leyenda no crece —c3_gx_review V1/V7—)
   if (vo.plate === true && !pip) { V.plateK = c3ClkPlateK(); V.plateA = c3ClkPlateA(); V.fitCorners = ["tl", "tr", "bl"]; if (c3ClkOn()) { this._gxClockPlate(V, w, h); if (h > w) V.fitCorners = ["tl", "tr"]; if (V.mode === "3d") V.plate3At = this._gxClockCorner3d(V, w, h, bmp); } } else if (!c3GxBroken("pipplate")) { V.plate = null; V.plateMax = null; }
   // (vertical: la placa con el reloj no baja —ahi va el titulo, que ocupa todo el ancho—; 25-oct: el «else» estuvo un rato DENTRO de este comentario y el recuadro de «foto + galaxia» pintaba la placa;
   //  costura «pipplate» = ese fallo, para el rojo de K4c en tests/c3_clock_probe.js)
   if (vo.reserve) V.reserve = vo.reserve;
   if (V.mode === "3d") {
      var c = cshGxCamView(this.gx.cam || { yaw: CSH_GX_CAM.YAW, pitch: CSH_GX_CAM.PITCH });
      V.cam = { yaw: c.yaw + C3_TMV.YAW * ((frac || 0) - 0.5), pitch: c.pitch, zoom: c.zoom, ox: c.ox, oy: c.oy, oz: c.oz };
   }
   bmp.fill(cpInt(CP_ATLAS.bg));
   var g = new Graphics(bmp);
   try {
      g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
      if (G) {
         var S = cshGxStaticDraw(g, this.gx.vcache, w, h, G, sc, V);          // (26-oct, V7h: el polvo del instante, debajo)
         var C2 = cshGxCloneCtx(S.C);
         cshGxPaintDynamic(g, w, h, G, sc, V, C2);
         this.gx.lastVideoR = cshGxPaintOver(g, w, h, G, sc, V, C2);
      } else this.gx.lastVideoR = cshGalaxyPaint(g, w, h, null, sc, V);
   } finally { g.end(); }
   ++this.gx.videoFrames;
   return bmp;
};

// ---------------------------------------------------------------------------
// LOS VUELOS con la galaxia (26-oct-2026): ya no se apagan. Vista previa, grabación y mandos en tm/galaxy_flight.js (el mismo botón y el mismo
// flujo que los del campo; ese fichero envuelve `_flightSync`, `flightPreview`, `flightRecordStart`…).
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// AL CERRAR: los bitmaps del mapa, libres
// ---------------------------------------------------------------------------
var c3GxBaseCleanup = CPStarfieldDock.prototype.cleanup;
CPStarfieldDock.prototype.cleanup = function() {
   if (this.gx) { cshGxStaticFree(this.gx.cache); cshGxStaticFree(this.gx.vcache); }
   try { cshGxGlowFree(); } catch (e) {}
   return c3GxBaseCleanup.call(this);
};
