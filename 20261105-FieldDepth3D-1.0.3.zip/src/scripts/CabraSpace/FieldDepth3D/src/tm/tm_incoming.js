// ============================================================================
// tm/tm_incoming.js — LAS ESTRELLAS QUE ENTRAN EN EL ENCUADRE (Cabra3D, 26-oct-2026, pendiente 11)
// ----------------------------------------------------------------------------
// Queja: en la maquina del tiempo (Campo), al avanzar o retroceder, las estrellas de FUERA de la foto que entrarian por su
// movimiento no se pintaban: solo se leen de Gaia las del encuadre (el cono que pasa por las esquinas) y solo se mueven las que
// estan DENTRO de la foto. El encuadre se vaciaba por un lado (medido en tests/c3_incoming.js, caso M).
//
// LO QUE SE HACE (con el minimo coste):
//   · UNA consulta mas a la base LOCAL de Gaia por imagen y escala: el cono de la foto + un MARGEN = |mu|ref · escala (el
//     camino mas largo que puede hacer en el cielo una estrella tipica-rapida del campo en esa escala), con tope MARGIN_MAX.
//     Solo hasta la G con que la foto ya mueve sus estrellas del CAMPO (la vara de `photoIdx`: lo que entra se pinta con la misma
//     vara que lo que ya se mueve), y solo las que HOY estan FUERA de la foto: lo de dentro que la foto no enseña sigue sin pintarse
//     (el criterio «solo lo que veo en la imagen», 23-oct, no se toca; no aplica a lo que hoy esta fuera de la foto).
//   · Se mueven con la MISMA fisica (c3TmBuild / c3TmAt, el movimiento elegido; en «orbitas» con los epiciclos, sin la tabla)
//     y se pintan SOLO mientras estan dentro del encuadre.
//   · COMO SE PINTAN: NO como las de la foto. Las estrellas de tu foto que se mueven son discos (huecos sin velocidad radial);
//     las que entran son CUADRADOS ABIERTOS del color de su BP−RP: «esto no esta en tu foto: es Gaia, donde estara». En el 3D,
//     el mismo cuadrado. El rotulo (desplegado) dice cuantas han entrado y de donde salen, y la leyenda tiene su entrada.
//     (1-nov-2026, D4 del video de formacion: eran ROMBOS. Como a TODAS estas estrellas les falta la velocidad radial —la consulta no la
//     trae: `rv: {}`— el ojo las leia como «sin velocidad radial» (el circulo hueco de la leyenda), y el rombo azul de los cuasares ya
//     existe. Cuadrado: ni circulo hueco, ni rombo. Costura del rojo: C3_TMIN.MARK = "diamond".)
// Costuras: C3_TMIN.ON (false = como antes: el rojo de tests/c3_incoming.js). ES5, metodos de CPStarfieldDock (envuelve
// tmSetTime, tmStarless —el video pasa por ahi antes de grabar—, _tmPaintStarsOn y _tmTrails3d, como el bloque F).
// NADA en onPaint: la consulta y el estado, al poner un instante ≠ 0 (una vez por imagen y escala); las posiciones, una vez por instante.
// ============================================================================
var C3_TMIN = {
   ON: true,
   // EL MARGEN (medido el 26-oct en tests/c3_incoming.js, caso M, ±100 ka, rectas desde el Sol): las que entran necesitan, del borde,
   // p95 2,4° y max 5,4° en las Pleyades (|mu| de las que entran hasta 230 mas/año), p95 0,9° y max 5,0° en NGC 1560. Con 1 × p99 (2,3°)
   // se recogian ~129 de 137 (94 %) en las Pleyades; con 1,5 × p99 del campo (3,4° y 2,3°) 116 de 119 y 241 de 241 (HANDOFF «26-oct · 11»).
   MU_Q: 0.99,              // |mu|ref = MU_K × este cuantil del |mu| de las estrellas del campo que se mueven en la foto (el maximo lo fija UNA estrella)
   MU_K: 1.5,
   MU_MIN: 5,               // mas/año: |mu|ref nunca por debajo (un campo lejano casi quieto)
   MARGIN_MAX: 6,           // grados: tope del margen (a ±1 Ma ya hace falta todo: las que vienen de mas lejos no se buscan, y el rotulo lo dice)
   REACH_K: 1.3, REACH_ADD: 0.05,   // una candidata solo si SU |mu| · escala (× 1,3 + 0,05°) llega al borde: lo que no puede llegar no se mueve
   SAMPLES: 96,             // instantes de [−escala, +escala] con que se comprueba que llega a entrar (paso < lado menor de NGC 1560 a 200 mas/año)
   MAX_ROWS: 200000,        // tope de filas de la consulta
   MAX_PAINT: 700,          // como mucho estas a la vez (= C3_TMUI.PHOTO_FIELD: las del campo que se mueven en la foto)
   EDGE_PX: 2,              // «fuera» = a mas de esto del borde (en el borde mismo ya puede estar en el modelo)
   LEGEND: true,            // (1-nov, D4) la entrada de la leyenda del 3D («cuadrado: entra desde fuera de tu foto»); false = el rojo
   MARK: "square"           // el simbolo de las que entran: "square" (1-nov, D4) | "diamond" (el de antes: el rojo)
};

// La vara de G y el margen de una imagen y una escala
CPStarfieldDock.prototype._tmInPlan = function(d, range) {
   var st = this.state, res = st.result, k, gCut = -99, mus = [];
   for (k = 0; k < d.photoIdx.length; ++k) { var s = res.stars[d.tm.idx[d.photoIdx[k]]]; if (s.cluster < 0 && s.g !== null && s.g > gCut) gCut = s.g; }
   for (k = 0; k < d.tm.n; ++k) { var m = res.stars[d.tm.idx[k]]; if (m.cluster < 0) mus.push(Math.sqrt(m.pmRa * m.pmRa + m.pmDec * m.pmDec)); }
   if (!(gCut > 0)) return null;
   mus.sort(function(a, b) { return a - b; });
   var muRef = Math.max(C3_TMIN.MU_MIN, C3_TMIN.MU_K * (mus.length ? mus[Math.min(mus.length - 1, Math.floor(C3_TMIN.MU_Q * (mus.length - 1)))] : 0));
   var want = muRef * range / 3.6e6;
   return { gCut: gCut, muRef: muRef, margin: Math.min(C3_TMIN.MARGIN_MAX, want), capped: want > C3_TMIN.MARGIN_MAX };
};
// La consulta y el estado (una vez por imagen, escala y movimiento). -> st.tmIn = { key, tm, stars, plan, n, ms } | null
CPStarfieldDock.prototype._tmInEnsure = function() {
   var st = this.state, tm = this.tm;
   if (C3_TMIN.ON !== true || !st || !tm || !st.result || !st.result.ok) return null;
   if (typeof this._gxOn === "function" && this._gxOn()) return st.tmIn || null;     // (Galaxia: su escala es otra; lo de aqui es de Campo)
   var d = this._tmData(st);
   if (!d || !d.tm || !d.tm.tan) return null;
   var key = tm.range + "|" + tm.motion;
   if (st.tmIn && st.tmIn.key === key && st.tmIn.dRef === d) return st.tmIn;
   var t0 = Date.now(), plan = this._tmInPlan(d, tm.range), f = st.result.field, W = f.width, H = f.height, E = C3_TMIN.EDGE_PX;
   if (plan === null || !(plan.margin > 0)) { st.tmIn = { key: key, dRef: d, tm: null, stars: [], plan: plan, n: 0, ms: 0 }; return st.tmIn; }
   // las filas: se reutilizan si la consulta anterior ya cubre este radio y esta vara
   var R = f.radiusDeg + plan.margin, rows = st.tmInRows;
   if (!rows || rows.radius < R - 1e-9 || rows.gCut !== plan.gCut) {
      var src = cpSfGaiaSource();
      if (!src.ok) { st.tmIn = { key: key, dRef: d, tm: null, stars: [], plan: plan, n: 0, ms: 0, why: "no-gaia" }; return st.tmIn; }
      var q = cpSfGaiaSearch(src.release, f.ra, f.dec, R, plan.gCut, C3_TMIN.MAX_ROWS), list = [];
      for (var i = 0; q.ok && i < q.rows.length; ++i) { var s = cpSfStarFromRow(q.rows[i], f.years); if (s.pmRa !== null && s.pmDec !== null && s.plx !== null && s.plx > 0.05) list.push(s); }
      rows = st.tmInRows = { radius: R, gCut: plan.gCut, stars: list, truncated: !!q.truncated, ok: !!q.ok, queryMs: q.ms };
   }
   // las que HOY estan fuera de la foto, dentro del margen, y que con SU movimiento pueden llegar (|mu| · escala, con holgura);
   // de esas, las que en algun instante de [−escala, +escala] (SAMPLES instantes) caen dentro: las demas no se mueven en cada tic
   var all = c3TmBuild({ stars: rows.stars }, { tan: d.tm.tan, epochYears: f.years, model: d.tm.model, lsr: d.tm.lsr, rv: {} }), P0 = c3TmAt(all, 0), pre = {}, nPre = 0, j;
   for (j = 0; j < all.n; ++j) {
      if (!P0.ok[j]) continue;
      var dx = Math.max(0, -P0.x[j], P0.x[j] - W), dy = Math.max(0, -P0.y[j], P0.y[j] - H);
      if (dx <= E && dy <= E) continue;                                   // hoy dentro: lo decide la foto, no esto
      var sj = rows.stars[all.idx[j]], edge = Math.sqrt(dx * dx + dy * dy) * f.scaleArcsec / 3600, reach = C3_TMIN.REACH_K * Math.sqrt(sj.pmRa * sj.pmRa + sj.pmDec * sj.pmDec) * tm.range / 3.6e6 + C3_TMIN.REACH_ADD;
      if (edge > plan.margin || edge > reach) continue;
      pre[all.idx[j]] = true; ++nPre;
   }
   var cand = c3TmBuild({ stars: rows.stars }, { tan: d.tm.tan, epochYears: f.years, model: d.tm.model, lsr: d.tm.lsr, rv: {}, indices: pre }), hit = new Uint8Array(cand.n), keep = {}, n = 0, S = C3_TMIN.SAMPLES;
   for (var a = 0; a <= S; ++a) {
      var Ts = -tm.range + 2 * tm.range * a / S;
      if (Ts === 0) continue;
      var Pa = c3TmAt(cand, Ts);
      for (j = 0; j < cand.n; ++j) if (!hit[j] && Pa.ok[j] && Pa.x[j] >= 0 && Pa.y[j] >= 0 && Pa.x[j] <= W && Pa.y[j] <= H) hit[j] = 1;
   }
   for (j = 0; j < cand.n; ++j) if (hit[j]) { keep[cand.idx[j]] = true; ++n; }
   var tmIn = c3TmBuild({ stars: rows.stars }, { tan: d.tm.tan, epochYears: f.years, model: d.tm.model, lsr: d.tm.lsr, rv: {}, indices: keep });
   tmIn.coneDeg = d.tm.coneDeg;          // (Q3, 2-nov: el mismo límite del cono que las de la foto —el décimo del lado menor de ESTA foto—)
   st.tmIn = { key: key, dRef: d, tm: tmIn, stars: rows.stars, plan: plan, n: tmIn.n, pre: nPre, ms: Date.now() - t0, at: null, atT: NaN, truncated: rows.truncated };
   return st.tmIn;
};
// Las que estan DENTRO del encuadre en el instante T, de brillante a debil (como mucho MAX_PAINT): [ { j, x, y, pc, s } ]
CPStarfieldDock.prototype._tmInInside = function(T) {
   var st = this.state, I = st ? st.tmIn : null;
   if (C3_TMIN.ON !== true || !I || !I.tm || I.tm.n === 0 || T === 0) return [];
   if (typeof this._gxOn === "function" && this._gxOn()) return [];               // (en Galaxia no: ver _tmInEnsure)
   if (I.key !== this.tm.range + "|" + this.tm.motion) return [];                 // (de otra escala o movimiento: aun no rehecho)
   if (I.atT !== T) { I.at = c3TmAt(I.tm, T, (I.at && I.at.x.length === I.tm.n) ? I.at : undefined); I.atT = T; I.inside = null; }
   if (I.inside) return I.inside;
   var P = I.at, f = st.result.field, W = f.width, H = f.height, out = [];
   // (Q3, 2-nov, noche) cada cuadrado lleva su opacidad del cono (`a`: 1…0,25; c3TmConeAlpha) y se cuentan los inciertos (x ≥ 1)
   for (var j = 0; j < I.tm.n; ++j) if (P.ok[j] && P.x[j] >= 0 && P.y[j] >= 0 && P.x[j] <= W && P.y[j] <= H) { var cx = P.cone ? P.cone[j] : 0, ca = c3TmConeAlpha(cx); if (ca > 0) out.push({ j: j, x: P.x[j], y: P.y[j], pc: P.pc[j], s: I.stars[I.tm.idx[j]], a: ca, unc: cx >= 1 }); }
   out.sort(function(a, b) { return ((a.s.g === null) ? 99 : a.s.g) - ((b.s.g === null) ? 99 : b.s.g); });
   I.insideN = out.length;                       // (cuantas hay dentro antes del tope: lo miran las pruebas)
   if (out.length > C3_TMIN.MAX_PAINT) out.length = C3_TMIN.MAX_PAINT;
   I.insideUnc = 0; for (var u = 0; u < out.length; ++u) if (out[u].unc) ++I.insideUnc;
   I.inside = out;
   return out;
};
CPStarfieldDock.prototype._tmInCount = function() { return (this.tm && this.tm.t !== 0) ? this._tmInInside(this.tm.t).length : 0; };
// (Q3) de ellas, las inciertas (pintadas al 25 %)
CPStarfieldDock.prototype._tmInUncertain = function() { if (!this.tm || this.tm.t === 0) return 0; this._tmInInside(this.tm.t); var I = this.state ? this.state.tmIn : null; return (I && I.insideUnc > 0) ? I.insideUnc : 0; };
// Con el margen en su tope (escalas largas): hasta cuantos grados se ha buscado (0 = sin tope: estan todas las de esa vara)
CPStarfieldDock.prototype._tmInCappedDeg = function() { var I = this.state ? this.state.tmIn : null; return (I && I.plan && I.plan.capped) ? I.plan.margin : 0; };
// EL CUADRADO ABIERTO: «no esta en tu foto» (`r` = la mitad de la diagonal del rombo de antes; el lado da el mismo area aproximada)
function c3TmInMark(g, x, y, r) {
   if (C3_TMIN.MARK === "diamond") { g.drawLine(x, y - r, x + r, y); g.drawLine(x + r, y, x, y + r); g.drawLine(x, y + r, x - r, y); g.drawLine(x - r, y, x, y - r); return; }
   var a = 0.78 * r;
   g.drawLine(x - a, y - a, x + a, y - a); g.drawLine(x + a, y - a, x + a, y + a); g.drawLine(x + a, y + a, x - a, y + a); g.drawLine(x - a, y + a, x - a, y - a);
}

// --- LAS COSTURAS -----------------------------------------------------------
var c3TmInBaseSetTime = CPStarfieldDock.prototype.tmSetTime;
CPStarfieldDock.prototype.tmSetTime = function(T, opts) {
   if (this.tm && Number(T) !== 0 && this.state) { try { this._tmInEnsure(); } catch (e) { if (this.state) this.state.tmIn = null; } }
   return c3TmInBaseSetTime.apply(this, arguments);
};
var c3TmInBaseSetRange = CPStarfieldDock.prototype.tmSetRange;
CPStarfieldDock.prototype.tmSetRange = function(R) {
   var r = c3TmInBaseSetRange.apply(this, arguments);
   if (this.tm && this.tm.t !== 0 && this.state) { try { this._tmInEnsure(); this._tmRepaint(false); } catch (e) {} }
   return r;
};
var c3TmInBaseStarless = CPStarfieldDock.prototype.tmStarless;
CPStarfieldDock.prototype.tmStarless = function() {
   try { this._tmInEnsure(); } catch (e) {}
   return c3TmInBaseStarless.apply(this, arguments);
};
// En la foto (y en el video de la foto): despues de las estrellas de la foto
var c3TmInBasePaintStars = CPStarfieldDock.prototype._tmPaintStarsOn;
CPStarfieldDock.prototype._tmPaintStarsOn = function(g, map, sc, k, clip) {
   var drawn = c3TmInBasePaintStars.apply(this, arguments);
   var tm = this.tm;
   if (!tm) return drawn;
   tm.photoIncoming = { drawn: 0, inside: 0 };
   if (tm.t === 0 || C3_TMIN.ON !== true) return drawn;
   var L = this._tmInInside(tm.t), lw = Math.max(1, 0.9 * sc), n = 0;
   g.antialiasing = true; g.brush = new Brush(0x00000000);
   for (var i = 0; i < L.length; ++i) {
      var p = map(L[i].x, L[i].y);
      if (clip && (p.x < clip.x - 8 || p.y < clip.y - 8 || p.x > clip.x + clip.w + 8 || p.y > clip.y + clip.h + 8)) continue;
      var s = L[i].s, gm = (s.g !== null) ? s.g : 16, r = Math.max(1.6 * sc, Math.min(5 * sc, (17.5 - gm) * 0.42 * sc)), rg = cpSvStarRgb(s.bpRp);
      g.pen = this._pen((rg[0] << 16) | (rg[1] << 8) | rg[2], 0.9 * C3_TMUI.FIELD_ALPHA * ((L[i].a > 0) ? L[i].a : 1), lw);       // (Q3: el cono)
      c3TmInMark(g, p.x, p.y, r * 1.3);
      ++n;
   }
   g.pen = new Pen(0x00000000, 0);
   tm.photoIncoming = { drawn: n, inside: L.length };
   return drawn;
};
// En el 3D: el mismo cuadrado, en su sitio (dentro del haz de la foto)
var c3TmInBaseTrails3d = CPStarfieldDock.prototype._tmTrails3d;
CPStarfieldDock.prototype._tmTrails3d = function(g, model, scale, fit, proj, sc, clip, alpha, video) {
   var r0 = c3TmInBaseTrails3d.apply(this, arguments);
   var tm = this.tm, st = this.state;
   if (tm) tm.incoming3d = 0;
   if (C3_TMIN.ON !== true || !tm || !st || !model || model.tmT === undefined || model.tmT === 0 || !(scale && scale.hi > 0)) return r0;
   var L = this._tmInInside(model.tmT), f = st.result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H), n = 0, a = (alpha > 0) ? alpha : 1;
   var lw = Math.max(1, 0.8 * sc), x0 = clip.x, x1 = clip.x + clip.w, y0 = clip.y, y1 = clip.y + clip.h;
   g.antialiasing = true; g.brush = new Brush(0x00000000);
   for (var i = 0; i < L.length; ++i) {
      if (!(L[i].pc > 0) || L[i].pc > scale.hi) continue;
      var t = scale.t(L[i].pc);
      if (!(t >= 0 && t <= 1)) continue;
      var p = fit.px((L[i].x - W / 2) / big, (L[i].y - H / 2) / big, t);
      if (!p.ok || p.x < x0 || p.x > x1 || p.y < y0 || p.y > y1) continue;
      var rg = cpSvStarRgb(L[i].s.bpRp);
      g.pen = this._pen((rg[0] << 16) | (rg[1] << 8) | rg[2], 0.85 * a * C3_TMUI.FIELD_ALPHA * ((L[i].a > 0) ? L[i].a : 1), lw);   // (Q3: el cono)
      c3TmInMark(g, p.x, p.y, 3.2 * sc);
      ++n;
   }
   g.pen = new Pen(0x00000000, 0);
   tm.incoming3d = n;
   return r0;
};
