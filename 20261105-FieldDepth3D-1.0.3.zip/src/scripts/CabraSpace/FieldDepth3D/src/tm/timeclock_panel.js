// ============================================================================
// tm/timeclock_panel.js — EL RELOJ ANALÓGICO EN EL PANEL EN VIVO (Cabra3D, 26-oct-2026)
// ----------------------------------------------------------------------------
// Queja de Nino: «Al ejecutar la máquina del tiempo en Cabra3D no me aparece el reloj». El reloj D (CabraShared/csh_clock.js, el pegamento
// en tm/timeclock.js) estaba solo en los vídeos; el 25-oct se decidió que el panel no lo llevase (su rótulo y la cifra junto a la regla ya
// decían el instante). Nino lo pide en el panel: esta decisión SUSTITUYE a aquella (HANDOFF, «26-oct · reloj en el panel y vuelo en Galaxia»).
//
// QUÉ HACE
//   · CAMPO (3D VIEW › Field): el reloj se pinta encima del dibujo del panel, en una esquina del área de la caja, cuando se usa la máquina
//     del tiempo (su grupo abierto, o el instante fuera de «ahora», o reproduciendo). También en T = 0: la esfera dice «hoy» y la cifra
//     exacta de debajo no se pinta (R2: «hoy» una sola vez, cshClockCaptionShown).
//   · GALAXIA (desde arriba, de canto, 3D): la fila grande de la placa del instante pasa a ser el reloj, como en el vídeo (galaxy_view.js
//     _gxClockPlate con el radio del panel). Siempre: la placa de la Galaxia dice siempre el instante.
//   · UNA SOLA INDICACIÓN DEL INSTANTE: el reloj sustituye a la cifra de junto a la regla (tmLabel, escondida) y, en el rótulo del campo
//     (tm/hud.js), a la línea grande «hace 60 000 años»; el año del calendario se queda en letra pequeña (es otra unidad, no otra vez lo mismo).
//   · DÓNDE (el criterio del vídeo, tm/timemachine_video.js clkChoose): la esquina del área con MENOS escena debajo, contada en CINCO instantes
//     de la reproducción (las posiciones de la regla 0, ¼, ½, ¾ y 1: las estrellas se mueven), más la foto en 3D, las aristas y las cifras
//     del eje, el polvo y los recortes (las mismas medidas que el rótulo, `_c3HudCover`). Se decide con el dibujo QUIETO y se CONGELA
//     mientras se reproduce o se arrastra: el reloj no salta de esquina. El rótulo y las placas lo esquivan (va en sus «boxes»).
//   · FLUIDEZ: la esfera (caja, cifras, marcas) se pinta UNA vez en un bitmap y en cada fotograma solo la manecilla y la cifra exacta
//     (csh_clock.js, O.layer "dial" / "hand"). Medido en tests/c3_clock_panel.js (K6) y tests/c3_fps_probe.js.
//   · LA MANECILLA SE ARRASTRA (26-oct, «que las manecillas sean interactivas»): pasar por la esfera la resalta; pulsar y arrastrar mueve el
//     instante por el MISMO camino que la regla (tmSetTime; al soltar, _tmSettle). Al final del fichero; prueba tests/c3_clock_drag.js.
// Lo incluye SOLO Cabra3D.js (después de tm/galaxy_view.js). ES5.
// ============================================================================

// R_UI: el radio en píxeles de interfaz (×escala): 64 → 96 px a 1,5 (cifras de 15 px, las del vídeo a 1080p). R_FRAC: no más de esta fracción
// del lado corto del área (un panel pequeño). PAD: el aire alrededor de su caja. SAMPLES: las posiciones de la regla que se miden.
// (27-oct, D1: R_FRAC 0,17 → 0,12. Con el portátil sin el monitor grande el panel queda en 756 × 799 px y el reloj de 0,17 —R 96, con su
//  placa la mitad del mapa— tapaba la leyenda, el centro galáctico y en el Campo la foto. Con el panel grande —1976 × 1269— sigue mandando R_UI.)
var C3_CLKP = { R_UI: 64, R_FRAC: 0.12, R_FRAC_OLD: 0.17, PAD: 4, SAMPLES: [0, 0.25, 0.5, 0.75, 1] };
// DEFECTOS INYECTADOS (tests/c3_clock_panel.js): «off» = sin reloj en el panel (lo de antes); «corner» = la esquina con MÁS escena; «jump» = se
// recoloca en cada fotograma con las estrellas de ese instante (sin congelar ni medir los cinco); «label» = la cifra de junto a la regla sigue
// (dos indicaciones del instante); «hudtime» = el rótulo sigue diciendo «hace … años»; «nomemo» = la esfera entera en cada fotograma;
// «d1» (27-oct) = el reloj como el 26-oct: radio 0,17 del lado corto, la placa de la Galaxia con la línea del modelo y media vista de ancho, y en
// 3D solo arriba o abajo a la izquierda aunque pise la leyenda; «hitsfirst» (28-oct) = en el Campo, entre las esquinas libres, la del radio más
// grande aunque tape más escena (lo del 27-oct: a 756 caía sobre la nube); «nomodel» (28-oct) = la placa de la Galaxia en el panel sin la línea «órbitas en MilkyWayPotential2022…».
var C3_CLKP_BREAK = "";
function c3ClkpBroken(k) { return (typeof C3_CLKP_BREAK === "string") && C3_CLKP_BREAK.length > 0 && C3_CLKP_BREAK.indexOf(k) >= 0; }
function c3ClkpOn() { return c3ClkOn() && !c3ClkpBroken("off"); }
function c3ClkpRadius(aw, ah, sc) {
   var s = (sc > 0) ? sc : 1;
   var fr = c3ClkpBroken("d1") ? C3_CLKP.R_FRAC_OLD : C3_CLKP.R_FRAC;
   return Math.max(C3_CLK.R_MIN, Math.min(Math.round(C3_CLKP.R_UI * s), Math.round(fr * Math.min(aw, ah))));
}
// La cifra exacta del instante: «hoy» en T = 0 (y R2 no la pinta: ya lo dice la esfera)
function c3ClkpCaption(T) { return (Math.abs(T) < 1e-9) ? cshClockTx("today", c3ClkLang()) : c3TmTimeText(T); }
// La más ancha de la escala (la caja se mide con ella: no cambia de tamaño mientras corre el tiempo)
function c3ClkpWide(range) {
   var a = [c3TmTimeText(-range), c3TmTimeText(-0.8888 * range), c3TmTimeText(0.9 * range), cshClockTx("today", c3ClkLang())], w = "";
   for (var i = 0; i < a.length; ++i) if (a[i].length > w.length) w = a[i];
   return w;
}
var C3_CLKP_M = {};
function c3ClkpMeasure(range, R) {
   var key = range + "|" + R + "|" + c3ClkLang() + "|" + c3ClkVariant() + "|" + ((typeof CSH_CLOCK_BREAK === "string") ? CSH_CLOCK_BREAK : "");
   if (!C3_CLKP_M[key]) C3_CLKP_M[key] = c3ClkMeasure(range, R, c3ClkpWide(range));
   return C3_CLKP_M[key];
}

// ---------------------------------------------------------------------------
// PINTAR con la esfera guardada: el bitmap de la capa «dial» (una vez por escala, radio, idioma y variante) y encima la capa «hand».
// Las de tapa (E) no se parten (la tapa crece con la cifra): se pintan enteras. Devuelve lo de c3ClkPaint + memo, ms.
// ---------------------------------------------------------------------------
var C3_CLKP_DIAL = { key: "", bmp: null, builds: 0, buildMs: 0 };
function c3ClkpLayered(M) {
   var V = (M && M.L && M.L.pocket) ? CSH_CLOCK.V[M.L.pocket] : null;
   return !!(V && !V.lid) && !c3ClkpBroken("nomemo");
}
function c3ClkpPaint(g, x0, y0, M, T, range, caption) {
   var t0 = Date.now(), st;
   if (!c3ClkpLayered(M)) { st = c3ClkPaint(g, x0, y0, M, T, range, caption); st.memo = false; st.ms = Date.now() - t0; return st; }
   var S = M.L.S, ox = (M.w - M.FP.w) / 2, D = C3_CLKP_DIAL;
   var key = [range, M.R, M.lang, M.L.pocket, M.w, M.h, (typeof CSH_CLOCK_BREAK === "string") ? CSH_CLOCK_BREAK : ""].join("|");
   if (D.key !== key || !D.bmp) {
      var tb = Date.now();
      try { if (D.bmp) D.bmp.clear(); } catch (eC) {}
      D.bmp = new Bitmap(Math.max(1, Math.ceil(M.w)), Math.max(1, Math.ceil(M.h)));          // (M.w y M.h pueden traer decimales)
      D.bmp.fill(0x00000000);
      var gd = new Graphics(D.bmp);
      try { cshClockPaint(gd, ox, 0, M.R, S, cshClockValue(S, 0), { variant: M.L.variant, lang: M.lang, caption: caption, fontFn: cpFont, layout: M.L, layer: "dial" }); }
      finally { gd.end(); }
      D.key = key; ++D.builds; D.buildMs = Date.now() - tb;
   }
   g.drawBitmap(Math.round(x0), Math.round(y0), D.bmp);
   st = cshClockPaint(g, Math.round(x0) + ox, Math.round(y0), M.R, S, cshClockValue(S, T), { variant: M.L.variant, lang: M.lang, caption: caption, fontFn: cpFont, layout: M.L, layer: "hand" });
   st.T = T; st.range = range; st.cell = { x0: Math.round(x0), y0: Math.round(y0), x1: Math.round(x0) + M.w, y1: Math.round(y0) + M.h };
   st.memo = true; st.ms = Date.now() - t0;
   return st;
}
function c3ClkpFree() { try { if (C3_CLKP_DIAL.bmp) C3_CLKP_DIAL.bmp.clear(); } catch (e) {} C3_CLKP_DIAL.bmp = null; C3_CLKP_DIAL.key = ""; }

// ---------------------------------------------------------------------------
// ¿LLEVA RELOJ el panel ahora?
// ---------------------------------------------------------------------------
// El campo: con la máquina del tiempo en uso (su grupo abierto, fuera de «ahora» o en marcha) y lista (solución astrométrica, estrellas que se mueven)
CPStarfieldDock.prototype._clkpField = function() {
   if (!c3ClkpOn() || this.mode !== "dist" || this.state === null || this._closed || !this.tm) return false;
   if (this._gxOn && this._gxOn()) return false;
   if (this.sky && this.sky.phase && this.sky.phase !== "off") return false;
   var tm = this.tm;
   if (!(this.c3Open === "time" || tm.t !== 0 || tm.playing || tm.go || (this._drag && this._drag.clock))) return false;      // (arrastrando la manecilla por «hoy» con el grupo cerrado, no desaparece)
   return this._tmReady();
};
// ¿El reloj es LA indicación del instante? (entonces la cifra de junto a la regla sobra). En la Galaxia siempre; en el campo, si la máquina
// está lista (con su grupo abierto el reloj se ve; cerrado, la regla tampoco se ve)
CPStarfieldDock.prototype._clkpOwnsInstant = function() {
   if (!c3ClkpOn() || c3ClkpBroken("label") || !this.tm || this.mode !== "dist" || this.state === null || this._closed) return false;
   if (this._gxOn && this._gxOn()) return true;
   if (this.sky && this.sky.phase && this.sky.phase !== "off") return false;
   return this._tmReady();
};

// ---------------------------------------------------------------------------
// EL CAMPO: dónde va (una vez con el dibujo quieto; congelado al reproducir o arrastrar)
// ---------------------------------------------------------------------------
// Lo fijo que hay bajo una caja: el polvo, la foto en 3D, los recortes, las aristas y las cifras del eje (lo mismo que mide el rótulo en
// tm/hud.js `_tmHudRect`, sin las estrellas: esas se cuentan aparte en cinco instantes)
CPStarfieldDock.prototype._clkpCtx = function(proj, X, sc) {
   var ctx = { grid: null, occ: (this._c3Occ && X.fit && this._c3Occ.fit === X.fit) ? this._c3Occ : null, quad: null, quadPts: null, cuts: [], pts: [] }, i;
   if (X.mesh && X.mesh.quad && X.mesh.quad.length === 4) ctx.quadPts = X.mesh.quad;
   if (X.model && X.fit && X.fit.mode === "perspective" && proj && proj.pw) {
      var EL = c3HudExtList(X.model);
      for (i = 0; i < EL.length; ++i) {
         var k = EL[i], ob = X.model.objects[k];
         if (!proj.vis[k] || (ob.kind === "cluster" && X.model.counts && X.model.counts.members > 0)) continue;
         var rPx = ob.ext * X.fit.scale * proj.pw[k];
         if (rPx >= CP_SV.CUT_MIN_PX * sc) ctx.cuts.push({ x: proj.px[k] - rPx, y: proj.py[k] - rPx, w: 2 * rPx, h: 2 * rPx });
      }
   }
   if (X.fit && X.model && X.fit.mode === "perspective") {
      var Kc = CP_SV_CORNERS, wn2 = X.model.wn / 2, hn2 = X.model.hn / 2, c, sI;
      for (c = 0; c < 4; ++c) {
         for (sI = 0; sI <= 24; ++sI) { var pE = X.fit.px(Kc[c][0] * wn2, Kc[c][1] * hn2, sI / 24); if (pE.ok) ctx.pts.push({ x: pE.x, y: pE.y, w: 4 }); }
         var c2 = (c + 1) % 4;
         for (sI = 0; sI <= 12; ++sI) { var u2 = Kc[c][0] + (Kc[c2][0] - Kc[c][0]) * sI / 12, v2 = Kc[c][1] + (Kc[c2][1] - Kc[c][1]) * sI / 12, pF = X.fit.px(u2 * wn2, v2 * hn2, 1); if (pF.ok) ctx.pts.push({ x: pF.x, y: pF.y, w: 4 }); }
         for (sI = 0; X.scale && sI < X.scale.ticks.length; ++sI) { var pT = X.fit.px(Kc[c][0] * wn2, Kc[c][1] * hn2, X.scale.ticks[sI].t); if (pT.ok) ctx.pts.push({ x: pT.x, y: pT.y + Math.round(10 * sc), w: 25 }); }
      }
   }
   return ctx;
};
// Las estrellas proyectadas con la cámara de AHORA en los instantes Ts (años): [{ px, py }]. Las que no mueve la máquina, en su sitio. Con
// «Órbitas galácticas» y aún sin la tabla de órbitas de esta escala, por rectas (es para elegir una esquina: no se integra nada aquí ni se
// toca la caché de posiciones del dibujo).
CPStarfieldDock.prototype._clkpStarsAt = function(Ts, X) {
   var st = this.state, d = this._tmData(st), base = this._tmBaseModel(), fit = X.fit, scale = X.scale, out = [], i, k;
   if (!d || !d.tm || !d.tm.tan || !fit || !scale || !base) return out;
   var f = st.result.field, W = Math.max(1, f.width), H = Math.max(1, f.height), big = Math.max(W, H), objs = base.objects, n = objs.length;
   var lim = 1 + C3_TMUI.OUT_MARGIN, sx = [], sy = [];
   for (i = 0; i < n; ++i) {
      if (d.objTm[i] >= 0) continue;
      var p0 = fit.px(objs[i].u, objs[i].v, scale.t(objs[i].pc));
      if (p0.ok) { sx.push(p0.x); sy.push(p0.y); }
   }
   var mdl = d.tm.model, noOrbit = (mdl === "galactic" && !(d.tm.orbit && d.tm.orbit.R === this.tm.range));
   for (k = 0; k < Ts.length; ++k) {
      var P = null;
      if (noOrbit) d.tm.model = "linear";
      try { P = c3TmAt(d.tm, Ts[k]); } finally { d.tm.model = mdl; }
      var px = sx.slice(), py = sy.slice();
      for (i = 0; i < n; ++i) {
         var j = d.objTm[i];
         if (j < 0 || !P.ok[j]) continue;
         var u = (P.x[j] - W / 2) / big, v = (P.y[j] - H / 2) / big;
         if (Math.abs(u) > base.wn / 2 * lim || Math.abs(v) > base.hn / 2 * lim) continue;          // (las que se han ido no se pintan)
         var pc = objs[i].pc * P.pc[j] / Math.max(1e-9, d.tm.dPc[j]), p = fit.px(u, v, scale.t(pc));
         if (p.ok) { px.push(p.x); py.push(p.y); }
      }
      out.push({ px: px, py: py });
   }
   return out;
};
// Las posiciones de la regla que se miden (años)
CPStarfieldDock.prototype._clkpTimes = function() {
   var R = this.tm.range, out = [];
   for (var i = 0; i < C3_CLKP.SAMPLES.length; ++i) out.push(c3TmSliderToYears(C3_CLKP.SAMPLES[i] * C3_TM_STEPS, R));
   return out;
};
function c3ClkpAreaSig(area) { return [area.x, area.y, area.w, area.h].map(Math.round).join(","); }
// La firma de la cámara del dibujo: tres puntos fijos de la caja proyectados (cualquier giro, zoom o desplazamiento la cambia) y la escala
function c3ClkpFitSig(fit, scale) {
   if (!fit || !fit.px) return "-";
   var a = fit.px(0, 0, 0), b = fit.px(0.4, 0.3, 1), c = fit.px(-0.3, 0.2, 0.5);
   return [a.x, a.y, b.x, b.y, c.x, c.y].map(function(v) { return isFinite(v) ? Math.round(v) : 0; }).join(",") + "|" + (scale && scale.t ? [scale.t(10), scale.t(1e4), scale.t(1e7)].map(function(v) { return Math.round(1000 * v); }).join(",") : "");
}
// EL SITIO: { key, w, area, range, R, M, corner, box (con su aire, para que lo esquiven), at (la esquina de la caja del reloj), scores, ms }
CPStarfieldDock.prototype._clkpPlace = function(w, sc, area, light, proj, X) {
   var tm = this.tm, range = tm.range, R = c3ClkpRadius(area.w, area.h, sc), M = c3ClkpMeasure(range, R), memo = this.c3clk || null, i, k;
   var pad = Math.round(C3_CLKP.PAD * sc), m = Math.round(CP_ATLAS.space[1] * sc), bw = M.w + 2 * pad, bh = M.h + 2 * pad, areaSig = c3ClkpAreaSig(area), base = this._tmBaseModel();
   var jump = c3ClkpBroken("jump");
   var key = [w, areaSig, sc, range, c3ClkLang(), c3ClkVariant(), R, tm.motion, this.pose, c3ClkpFitSig(X.fit, X.scale), (this.dust && this.dust.on) ? 1 : 0, c3ClkpBroken("corner") ? 1 : 0, jump ? tm.t : ""].join("|");
   if (memo && memo.key === key && memo.base === base) return memo;
   var settled = (light !== true) && !tm.playing && !tm.go && !this._drag;
   // (reproduciendo, arrastrando o con el dibujo ligero: el de antes, si es de este lienzo y esta escala —no salta de esquina—)
   if (!jump && !settled && memo && memo.w === w && memo.areaSig === areaSig && memo.range === range && (memo.R0 || memo.R) === R) return memo;
   var t0 = Date.now(), ctx = this._clkpCtx(proj, X, sc), Ts = jump ? [tm.t] : this._clkpTimes(), S = this._clkpStarsAt(Ts, X), none = { px: [], py: [] };
   // (arriba a la derecha NO: es la casa del rótulo de la máquina del tiempo, y su candidato «tr» no mira las cajas de los demás —tm/hud.js—)
   var cands = [{ n: "tl", x: area.x + m, y: area.y + m }, { n: "bl", x: area.x + m, y: area.y + area.h - m - bh },
                { n: "br", x: area.x + area.w - m - bw, y: area.y + area.h - m - bh }];
   var best = null, red = c3ClkpBroken("corner"), scores = {};
   for (i = 0; i < cands.length; ++i) {
      var q = { x: cands[i].x, y: cands[i].y, w: bw, h: bh }, nS = 0;
      if (q.y < area.y - 1 || q.x < area.x - 1 || q.w > area.w || q.h > area.h) { scores[cands[i].n] = -1; continue; }
      for (k = 0; k < S.length; ++k) { var A = S[k]; for (var j = 0; j < A.px.length; ++j) if (A.px[j] >= q.x && A.px[j] <= q.x + q.w && A.py[j] >= q.y && A.py[j] <= q.y + q.h) ++nS; }
      var sFix = this._c3HudCover(q, none, sc, ctx, null);
      cands[i].stars = nS; cands[i].fixed = sFix; cands[i].s = nS / Math.max(1, S.length) + sFix;
      scores[cands[i].n] = Math.round(cands[i].s * 10) / 10;
      if (best === null || (red ? cands[i].s > best.s : cands[i].s < best.s - 0.5)) best = cands[i];
   }
   if (best === null) best = cands[0];
   var nIn = 0;          // (cuántas estrellas del área, de media en los instantes medidos: la base de «% de estrellas tapadas» al elegir con el dibujo hecho)
   for (k = 0; k < S.length; ++k) for (i = 0; i < S[k].px.length; ++i) if (S[k].px[i] >= area.x && S[k].px[i] <= area.x + area.w && S[k].py[i] >= area.y && S[k].py[i] <= area.y + area.h) ++nIn;
   nIn = nIn / Math.max(1, S.length);
   this.c3clk = { key: key, base: base, w: w, areaSig: areaSig, range: range, R: R, R0: R, M: M, corner: best.n, box: { x: best.x, y: best.y, w: bw, h: bh },
                  at: { x: best.x + pad, y: best.y + pad }, scores: scores, stars: best.stars, nT: S.length, ms: Date.now() - t0, places: ((memo && memo.places) || 0) + 1, last: memo ? memo.last : null,
                  sigNL: [w, areaSig, sc, range, R, tm.motion, this.pose, c3ClkpFitSig(X.fit, X.scale)].join("|"),
                  S: S, nIn: nIn, pad: pad, cands: cands.filter(function(c) { return typeof c.s === "number"; }).map(function(c) { return { n: c.n, x: c.x, y: c.y, s: c.s, stars: c.stars }; }), checked: false };
   return this.c3clk;
};
// (27-oct, D1) LO QUE EL RELOJ NO PUEDE PISAR en el Campo, comprobado con el dibujo YA HECHO (las franjas y las cifras del eje se colocan después
// de elegir la esquina y no la esquivan): las franjas, las cifras, el rótulo, las placas y la foto (más de 4 de 200 muestras de su caja dentro
// de su contorno). Si la elegida pisa algo: la esquina donde el reloj cabe LIBRE con el radio más grande (del suyo hacia R_MIN, de 8 en 8 %;
// a igual radio, la de menos puntuación); si en ninguna cabe libre, la que menos pisa con su radio. Devuelve true si cambió (se vuelve a pintar).
// Con el panel pequeño —756 × 799— la de menos estrellas (tl) caía sobre la foto y la franja «OTROS · LA FOTO» (c3_clock_panel P3, P3b;
// sonda tests/c3_clock_d1_probe.js: tl pisa 28, bl 28, br 1 —una cifra del eje—).
function c3ClkpHits(q, lay) {
   function ov(b) { var x0 = (b.x0 !== undefined) ? b.x0 : b.x, y0 = (b.y0 !== undefined) ? b.y0 : b.y, x1 = (b.x1 !== undefined) ? b.x1 : b.x + b.w, y1 = (b.y1 !== undefined) ? b.y1 : b.y + b.h;
                    return q.x < x1 && q.x + q.w > x0 && q.y < y1 && q.y + q.h > y0; }
   var j, n = 0;
   for (j = 0; lay.bandBoxes && j < lay.bandBoxes.length; ++j) if (ov(lay.bandBoxes[j])) ++n;
   for (j = 0; lay.tickBoxes && j < lay.tickBoxes.length; ++j) if (ov(lay.tickBoxes[j])) ++n;
   for (j = 0; lay.plates && j < lay.plates.length; ++j) if (lay.plates[j].ok && lay.plates[j].box && ov(lay.plates[j].box)) ++n;
   if (lay.hudRect && ov(lay.hudRect)) ++n;
   if (lay.quad && lay.quad.length === 4) {
      var QP = lay.quad, sg = 0, nin = 0, ia, jb;
      for (ia = 0; ia < 4; ++ia) sg += QP[ia].x * QP[(ia + 1) % 4].y - QP[(ia + 1) % 4].x * QP[ia].y;
      for (jb = 0; jb < 10; ++jb) for (ia = 0; ia < 20; ++ia) {
         var sx = q.x + (ia + 0.5) * q.w / 20, sy = q.y + (jb + 0.5) * q.h / 10, inq = true;
         for (var e = 0; e < 4 && inq; ++e) { var A0 = QP[e], A1 = QP[(e + 1) % 4]; if (((A1.x - A0.x) * (sy - A0.y) - (A1.y - A0.y) * (sx - A0.x)) * sg < 0) inq = false; }
         if (inq) ++nin;
      }
      if (nin > 4) n += nin;
   }
   return n;
}
// (lo decidido se recuerda por ESCENA —lienzo, área, escala, cámara—, no por idioma: al cambiar ES ↔ EN cambian las cifras del eje y las
//  franjas, y sin esto el reloj saltaba de tl R 63 a br R 69 —c3_clock_drag K1 en rojo, 27-oct—)
CPStarfieldDock.prototype._clkpHardFix = function(Q, lay, bmp) {
   if (!Q || Q.checked || c3ClkpBroken("d1") || !Q.cands || !lay) return false;
   Q.checked = true;
   var bw = Q.box.w, bh = Q.box.h, cur = c3ClkpHits(Q.box, lay), best = null, least = null, i, a = lay.area, m = Math.round(CP_ATLAS.space[1] * (lay.sc || 1)), self = this;
   Q.hits = cur;
   if (!a) return false;
   // la caja de la candidata c con el radio r (anclada a su esquina, como en _clkpPlace)
   function boxOf(c, r) {
      var M = c3ClkpMeasure(Q.range, r), w2 = M.w + 2 * Q.pad, h2 = M.h + 2 * Q.pad;
      var x = (c.n === "br") ? a.x + a.w - m - w2 : a.x + m, y = (c.n === "tl") ? a.y + m : a.y + a.h - m - h2;
      return { M: M, q: { x: x, y: y, w: w2, h: h2 } };
   }
   function keep(n, r) { self._clkpFixed = { sig: Q.sigNL, corner: n, R: r }; }
   var F = this._clkpFixed;
   if (F && F.sig === Q.sigNL) {
      if (F.corner === Q.corner && F.R === Q.R) return false;
      for (i = 0; i < Q.cands.length; ++i) if (Q.cands[i].n === F.corner) {
         var Bf = boxOf(Q.cands[i], F.R);
         Q.corner = F.corner; Q.R = F.R; Q.M = Bf.M; Q.box = Bf.q; Q.at = { x: Bf.q.x + Q.pad, y: Bf.q.y + Q.pad }; Q.stars = Q.cands[i].stars; Q.moved = (Q.moved || 0) + 1;
         return true;
      }
   }
   if (cur === 0) { keep(Q.corner, Q.R); return false; }
   // (28-oct, R1) LO QUE TAPA una caja = % de las estrellas del área (media de los instantes medidos) + % de tinta del dibujo hecho (píxeles que
   // se apartan del fondo, sin el reloj). El 27-oct la elegida era la del radio MÁS GRANDE sin pisar nada, sin mirar cuánta escena tapa: a 756 daba
   // «br», encima de la nube (15 % de las estrellas, 37 % de tinta) con tl y bl al 0,0 % y 8-10 %. Ahora: entre las esquinas donde cabe libre
   // (radio de 8 en 8 % hacia abajo) gana la que menos tapa; a igual tapado (0,5 puntos), la del radio mayor. Costura «hitsfirst» = lo del 27-oct.
   var S = Q.S || [], nIn = Q.nIn || 0, old = c3ClkpBroken("hitsfirst"), inkBg = cpInt(CP_ATLAS.bg);
   function cover(q) {
      var n = 0, k, j, ink = 0, tot = 0, A;
      for (k = 0; k < S.length; ++k) { A = S[k]; for (j = 0; j < A.px.length; ++j) if (A.px[j] >= q.x && A.px[j] <= q.x + q.w && A.py[j] >= q.y && A.py[j] <= q.y + q.h) ++n; }
      var starPct = (nIn > 0 && S.length) ? 100 * (n / S.length) / nIn : 0;
      if (bmp) {
         var br0 = (inkBg >> 16) & 255, bg0 = (inkBg >> 8) & 255, bb0 = inkBg & 255;
         var x0 = Math.max(0, Math.round(q.x)), y0 = Math.max(0, Math.round(q.y)), x1 = Math.min(bmp.width, Math.round(q.x + q.w)), y1 = Math.min(bmp.height, Math.round(q.y + q.h));
         for (var y = y0; y < y1; y += 2) for (var x = x0; x < x1; x += 2) {
            var c = bmp.pixel(x, y); ++tot;
            if (Math.abs(((c >> 16) & 255) - br0) + Math.abs(((c >> 8) & 255) - bg0) + Math.abs((c & 255) - bb0) > 60) ++ink;
         }
      }
      return starPct + (tot ? 100 * ink / tot : 0);
   }
   var trace = [];
   for (i = 0; i < Q.cands.length; ++i) {
      var c = Q.cands[i], n0 = c3ClkpHits({ x: c.x, y: c.y, w: bw, h: bh }, lay);
      if (least === null || n0 < least.n || (n0 === least.n && c.s < least.c.s)) least = { c: c, n: n0 };
      for (var r = Q.R0; r >= C3_CLK.R_MIN; r = (r === C3_CLK.R_MIN) ? 0 : Math.max(C3_CLK.R_MIN, Math.round(r * 0.92))) {
         var B = boxOf(c, r);
         if (c3ClkpHits(B.q, lay) > 0) continue;
         var cv = old ? 0 : cover(B.q);
         trace.push(c.n + " R" + r + " " + (Math.round(cv * 10) / 10) + " %");
         if (best === null || (old ? (r > best.r || (r === best.r && c.s < best.c.s)) : (cv < best.cv - 0.5 || (cv <= best.cv + 0.5 && r > best.r)))) best = { c: c, r: r, B: B, cv: cv };
         break;
      }
   }
   if (best === null) {
      if (!least || least.c.n === Q.corner || least.n >= cur) { keep(Q.corner, Q.R); return false; }
      best = { c: least.c, r: Q.R, B: { M: Q.M, q: { x: least.c.x, y: least.c.y, w: bw, h: bh } } };
   }
   Q.corner = best.c.n; Q.R = best.r; Q.M = best.B.M; Q.box = best.B.q; Q.at = { x: best.B.q.x + Q.pad, y: best.B.q.y + Q.pad }; Q.stars = best.c.stars; Q.moved = (Q.moved || 0) + 1;
   Q.cover = best.cv; Q.trace = trace;
   keep(Q.corner, Q.R);
   return true;
};
// El rótulo (tm/hud.js) y las placas lo esquivan: su caja va en las de ellos
var c3ClkpBaseTmHudRect = CPStarfieldDock.prototype._tmHudRect;
CPStarfieldDock.prototype._tmHudRect = function(w, sc, area, light, boxes, proj, X, again) {
   if (proj && area && this._clkpField()) {
      var Q = this._clkpPlace(w, sc, area, light, proj, X || {});
      if (Q && boxes && boxes.indexOf(Q.box) < 0) boxes.push(Q.box);
   }
   return c3ClkpBaseTmHudRect.call(this, w, sc, area, light, boxes, proj, X, again);
};
// Y se pinta encima del dibujo entero (el de la Galaxia lo lleva en su placa: allí no)
var c3ClkpBaseRenderAt = CPStarfieldDock.prototype.renderAt;
CPStarfieldDock.prototype.renderAt = function(w, h, sc, opts) {
   var o = opts || {}, want = this._clkpField() && o.noObjects !== true && o.noBody !== true;
   if (this.gx) this.gx.panelClock = null;          // (26-oct, manecilla interactiva: el de la placa de la Galaxia, solo si se pinta en ESTE dibujo)
   var made = c3ClkpBaseRenderAt.call(this, w, h, sc, opts);
   if (!made || !made.lay) return made;
   made.lay.clock = null;
   // (la Galaxia: el reloj de su placa, con lo pintado —eje, radio, ángulo—, para arrastrar su manecilla: más abajo, «LA MANECILLA SE ARRASTRA»)
   if (made.lay.kind === "galaxy") { var pc = this.gx ? this.gx.panelClock : null; if (pc && pc.pivot) made.lay.clock = { box: pc.box, corner: "plate", st: pc, ms: pc.ms || 0, T: pc.T }; return made; }
   if (!want || made.lay.kind !== "dist" || !made.lay.area) return made;
   var lay = made.lay, Q = this.c3clk;
   if (!Q || Q.w !== w || Q.areaSig !== c3ClkpAreaSig(lay.area) || Q.range !== this.tm.range)
      Q = this._clkpPlace(w, sc, lay.area, o.light === true, lay.proj, { fit: lay.fit, model: lay.model, scale: lay.scale, mesh: lay.quad ? { quad: lay.quad } : null });
   if (!Q) return made;
   // (27-oct, D1) ¿pisa lo que se colocó después? Entonces a la esquina libre y otra vez el dibujo (el rótulo y las placas esquivan la caja nueva)
   if (this._clkpHardFix(Q, lay, made.bitmap)) {
      try { if (!(o.into && o.into === made.bitmap)) made.bitmap.clear(); } catch (eC) {}
      made = c3ClkpBaseRenderAt.call(this, w, h, sc, opts);
      if (!made || !made.lay) return made;
      made.lay.clock = null; lay = made.lay;
   }
   var T = this.tm.t, stc = null, g = new Graphics(made.bitmap);
   try { g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {} stc = c3ClkpPaint(g, Q.at.x, Q.at.y, Q.M, T, this.tm.range, c3ClkpCaption(T)); }
   finally { g.end(); }
   lay.clock = { box: Q.box, corner: Q.corner, st: stc, ms: stc ? stc.ms : 0, T: T };
   this.c3clk.last = lay.clock;
   return made;
};
// El rótulo del campo: sin «hace 60 000 años» (lo dice el reloj); el año del calendario, en letra pequeña
var c3ClkpBaseHudLines = CPStarfieldDock.prototype._hudLines;
CPStarfieldDock.prototype._hudLines = function(full) {
   var L = c3ClkpBaseHudLines.call(this, full);
   if (c3ClkpBroken("hudtime") || !this._clkpField()) return L;
   for (var i = 0; i < L.length; ++i) if (L[i].k === "big") {
      var y = c3TmCalendarYear(this.state, this.tm.t);
      if (y.length) L[i] = { k: "small", t: y }; else L.splice(i, 1);
      break;
   }
   return L;
};
// La cifra de junto a la regla: escondida cuando el reloj es la indicación del instante (la regla crece en su sitio)
var c3ClkpBaseTmSync = CPStarfieldDock.prototype._tmSync;
CPStarfieldDock.prototype._tmSync = function() {
   c3ClkpBaseTmSync.apply(this, arguments);
   try { if (this.tmLabel && this._clkpOwnsInstant()) cpSetControlVisible(this.tmLabel, false); } catch (e) {}
};
// Abrir o cerrar el grupo de la máquina del tiempo enciende o apaga el reloj del campo: se repinta si cambia
var c3ClkpBaseGroupOpen = CPStarfieldDock.prototype.c3GroupOpen;
CPStarfieldDock.prototype.c3GroupOpen = function(key, on) {
   var was = this._clkpField();
   var r = c3ClkpBaseGroupOpen.apply(this, arguments);
   try { if (this._clkpField() !== was && this.mode === "dist" && this.state !== null) this._render(); this._tmSync(); } catch (e) {}
   return r;
};

// ---------------------------------------------------------------------------
// LA GALAXIA: el reloj en la placa del panel (galaxy_view.js `_gxDraw` llama aquí) y, en 3D, su esquina
// ---------------------------------------------------------------------------
// Cuántas estrellas de la Galaxia caen en cada caja (boxes: { tl: {x0,y0,x1,y1}, … }) con la cámara `cam` (cshGxCam) en el instante tMyr
function c3ClkpGxCount(G, cam, tMyr, boxes, tot) {
   var p = [0, 0, 0], k, c;
   for (k = -1; k < G.stars.length; ++k) {          // (k = −1: el Sol)
      cshGxPosAt(G, k, tMyr, p);
      var q = cam.px(p[0], p[1], p[2]);
      if (!q.ok) continue;
      for (c in boxes) if (boxes.hasOwnProperty(c)) { var b = boxes[c]; if (q.x >= b.x0 && q.x <= b.x1 && q.y >= b.y0 && q.y <= b.y1) tot[c] = (tot[c] || 0) + ((k < 0) ? 50 : 1); }
   }
   return tot;
}
CPStarfieldDock.prototype._gxPanelClock = function(V, w, h, sc, frame, o) {
   if (!c3ClkpOn() || !V.plate || !V.plate.length) return;
   var R = c3ClkpRadius(frame.w, frame.h, sc);
   this._gxClockPlate(V, w, h, R, true);
   // (27-oct, D1) la placa no más ancha que su reloj: los avisos se parten a ese ancho (cshGxPlate wrapW)
   if (!c3ClkpBroken("d1")) for (var i = 0; V.plate && i < V.plate.length; ++i) if (V.plate[i].kind === "clock") { V.plateWrap = V.plate[i].w; break; }
   if (V.mode === "3d") V.plate3At = this._clkpGx3dCorner(V, w, h, sc, o || {});
};
// En 3D (la única vista sin esquinas por encuadre: la cámara la mueve Nino): arriba o abajo a la izquierda (arriba a la derecha va la leyenda),
// la de menos estrellas debajo en los cinco instantes de la regla con la cámara del panel; congelada al reproducir o arrastrar.
// (27-oct, D1) Candidatas tl, bl y br; fuera las que pisan la caja de la leyenda (la mayor que llega a ser, cshGxLegendMax, arriba a la
// derecha); el Sol y el centro galáctico pesan 50 estrellas cada uno. Gana tl salvo que otra tenga menos del 80 % de lo de tl.
CPStarfieldDock.prototype._clkpGx3dCorner = function(V, w, h, sc, o) {
   var G = this._gxModel(), tm = this.tm, gx = this.gx;
   if (!G) return "tl";
   var Lr = cshGxLayout(w, h, sc, V).rect, cv = cshGxCamView(V.cam || { yaw: CSH_GX_CAM.YAW, pitch: CSH_GX_CAM.PITCH }), pl = V.plateMax || V.plate;
   var key = [G.stamp, w, h, sc, Lr.x, Lr.y, Lr.w, Lr.h, tm.range, c3ClkLang(), cv.yaw, cv.pitch, cv.zoom, cv.ox, cv.oy, cv.oz, pl ? pl.length : 0, c3ClkpBroken("corner") ? 1 : 0, V.plateWrap || 0, V.legendOn !== false ? 1 : 0].join("|");
   var memo = gx.clockPanelAt, settled = o.light !== true && !tm.playing && !tm.go && !this._drag;
   if (memo && memo.G === G && memo.key === key) return memo.corner;
   if (memo && memo.G === G && !settled && !c3ClkpBroken("jump")) return memo.corner;
   var old = c3ClkpBroken("d1"), cands = old ? ((h > w) ? ["tl"] : ["tl", "bl"]) : ["tl", "bl", "br"], corner = "tl", tot = {}, c, j, boxes = {};
   if (!old) {
      // (las que pisan la leyenda, fuera; si todas la pisan, se queda con todas)
      var legM = (V.legendOn !== false) ? cshGxLegendMax(V, G, Lr, sc) : null, mL = Math.round(8 * sc), free = [];
      var lb = legM ? cshGxCornerBox("tr", legM.x1 - legM.x0, legM.y1 - legM.y0, Lr, mL) : null;
      for (c = 0; c < cands.length; ++c) {
         var bq = cshGxPlate(null, null, pl, Lr, sc, true, cands[c], V.plateK, 0, V.plateWrap);
         boxes[cands[c]] = bq;
         if (!(lb && bq.x0 < lb.x1 + mL / 2 && bq.x1 > lb.x0 - mL / 2 && bq.y0 < lb.y1 + mL / 2 && bq.y1 > lb.y0 - mL / 2)) free.push(cands[c]);
      }
      if (free.length) cands = free;
      var bx2 = {}; for (c = 0; c < cands.length; ++c) bx2[cands[c]] = boxes[cands[c]];
      boxes = bx2;
   }
   if (cands.length > 1) {
      var fx = cshGxFitView(G, V, Lr, sc), cam = cshGxCam((fx && fx.box3) ? fx.box3 : G.ext.box, Lr, V.cam || { yaw: CSH_GX_CAM.YAW, pitch: CSH_GX_CAM.PITCH });
      for (c = 0; c < cands.length; ++c) { if (!boxes[cands[c]]) boxes[cands[c]] = cshGxPlate(null, null, pl, Lr, sc, true, cands[c], V.plateK); tot[cands[c]] = 0; }
      var Ts = c3ClkpBroken("jump") ? [tm.t] : this._clkpTimes();
      for (j = 0; j < Ts.length; ++j) c3ClkpGxCount(G, cam, Ts[j] / 1e6, boxes, tot);
      if (!old) {          // el centro galáctico, como el Sol (50)
         var q0 = cam.px(0, 0, 0);
         if (q0.ok) for (c in boxes) if (boxes.hasOwnProperty(c)) { var b0 = boxes[c]; if (q0.x >= b0.x0 && q0.x <= b0.x1 && q0.y >= b0.y0 && q0.y <= b0.y1) tot[c] += 50; }
      }
      var red = c3ClkpBroken("corner");
      if (old) { if (red ? (tot.bl > tot.tl) : (tot.bl < tot.tl * 0.8)) corner = "bl"; }
      else {
         corner = cands[0];
         for (c = 1; c < cands.length; ++c) if (red ? (tot[cands[c]] > tot[corner]) : (tot[cands[c]] < tot[corner] * 0.8)) corner = cands[c];
      }
   } else if (cands.length === 1) corner = cands[0];
   gx.clockPanelAt = { G: G, key: key, corner: corner, tot: tot, places: ((memo && memo.places) || 0) + 1 };
   return corner;
};

// ---------------------------------------------------------------------------
// LA MANECILLA SE ARRASTRA (26-oct-2026; Nino: «haz que las manecillas del reloj sean interactivas y que pueda moverlas a mi antojo y la
// animación reaccione»). En el PANEL en vivo (Campo y la placa de la Galaxia —arriba, de canto, 3D—); los vídeos no (no tienen ratón).
//   · Pasar por la esfera: cursor de mano, la manecilla con un halo de oro (se pinta en `_drawMarks`, lo que sigue al ratón: sin rehacer el
//     dibujo) y su tooltip EN/ES. Pulsar en la esfera: la manecilla salta a ese ángulo (como la regla, que salta a donde se pulsa) y, sin soltar,
//     la sigue (el ángulo desde el eje, acotado al arco: en el hueco de abajo se queda en la punta más cercana; CabraShared/csh_clock.js
//     cshClockPointerDeg → cshClockYearsAt).
//   · EL MISMO CAMINO QUE LA REGLA (tm/timemachine_ui.js, `tmSlider.onValueUpdated` / `c3onRelease`): agarrar para lo que corra
//     (`_tmStopAnims`: si reproducía, queda en pausa), cada movimiento es `tmSetTime(T, { light: true })` —el único estado del tiempo; la regla se
//     mueve sola por `_tmLabelSync`— y soltar es `_tmSettle()` (el dibujo entero), y sigue en pausa. Cerca de «hoy» se pega a «hoy» como la regla
//     (su ventana es el 0,6 % de su recorrido; aquí, el 0,6 % del arco: 1,8°, menos de media marca menor, 1,875°).
//   · Mientras se arrastra, `_drag` está puesto: el reloj no cambia de esquina (`_clkpPlace` y `_clkpGx3dCorner` la congelan) y la cámara no gira.
// Costuras (tests/c3_clock_drag.js, C3_MUTATE): «own» = un segundo estado (tm.t a mano, sin tmSetTime: la regla no se entera); «nopause» = agarrar no
// pausa; «wrap360» = el ángulo en [0, 360) (a la izquierda de «hoy» salta a +escala); «off» = sin interacción (lo de antes).
var C3_CLKD = { HIT_R: 0.97, SNAP_DEG: 1.8, DBL_MS: 700 };
var C3_CLKD_BREAK = "";
function c3ClkdBroken(k) { return (typeof C3_CLKD_BREAK === "string") && C3_CLKD_BREAK.length > 0 && C3_CLKD_BREAK.indexOf(k) >= 0; }
function c3ClkdTip() {
   return (c3ClkLang() === "es") ? "Arrastra la manecilla para viajar en el tiempo (o pulsa en la esfera para saltar allí). Si se estaba reproduciendo, se pausa."
                                 : "Drag the hand to travel in time (or click on the dial to jump there). Playback pauses.";
}
// ¿Se puede tocar ahora? (lo mismo que la regla: la máquina lista y sin grabar —`tmSlider.enabled`—, y nada que tenga el lienzo: vuelo, cielo)
CPStarfieldDock.prototype._clkdCan = function() {
   if (!c3ClkpOn() || c3ClkdBroken("off") || !this.tm || this.mode !== "dist" || this.state === null || this._closed) return false;
   if (!this.tmSlider || this.tmSlider.enabled === false) return false;
   if (this.fl && (this.fl.strip || (this.flightBusy && this.flightBusy()))) return false;
   if (this.sky && this.sky.phase && this.sky.phase !== "off") return false;
   return true;
};
// Lo pintado en el dibujo de ahora (`lay.clock.st`: eje, radio, ángulo, variante), si es de esta escala
CPStarfieldDock.prototype._clkdGeo = function() {
   var lay = this.lay, st = (lay && lay.clock) ? lay.clock.st : null;
   if (!st || !st.pivot || !(st.R > 0) || (st.range !== undefined && st.range !== this.tm.range)) return null;
   return st;
};
CPStarfieldDock.prototype._clkdHit = function(x, y) {
   if (!this._clkdCan()) return null;
   var st = this._clkdGeo();
   if (!st) return null;
   var dx = x - st.pivot.x, dy = y - st.pivot.y, r = C3_CLKD.HIT_R * st.R;
   return (dx * dx + dy * dy <= r * r) ? st : null;
};
// El instante bajo el ratón (años): el ángulo desde el eje → la escala → años; cerca de «hoy», «hoy». En el eje mismo, el de ahora.
CPStarfieldDock.prototype._clkdYearsAt = function(st, x, y) {
   var deg = cshClockPointerDeg(st.pivot.x, st.pivot.y, x, y);
   if (deg === null) return this.tm.t;
   var S = c3ClkScale(this.tm.range), T = cshClockYearsAt(S, deg, st.variant);
   // (la costura: el ángulo en [0, 360) y la escala a mano, sin cshClockValueAt —lo que haría un arreglo ingenuo—: a la izquierda de «hoy», +escala)
   if (c3ClkdBroken("wrap360")) { var d3 = (deg < 0) ? deg + 360 : deg, f3 = Math.max(0, Math.min(1, (d3 + 150) / 300)); T = cshClockYearsOf(S, S.from + f3 * (S.to - S.from)); }
   if (Math.abs(deg) <= C3_CLKD.SNAP_DEG) T = 0;
   return T;
};
CPStarfieldDock.prototype._clkdCursor = function(kind) {
   if (this._clkdCur === kind) return;
   this._clkdCur = kind;
   try { this.canvas.cursor = new Cursor(kind === "drag" ? StdCursor_ClosedHand : (kind === "hot" ? StdCursor_PointingHand : StdCursor_Arrow)); } catch (e) {}
};
CPStarfieldDock.prototype._clkdSetHot = function(on) {
   var C = this._clkd || (this._clkd = { hot: false, drag: false, moves: 0, ms: [] });
   if (C.hot === on) return;
   C.hot = on;
   try { this.canvas.repaint(); } catch (e) {}
};
// Un movimiento: el instante bajo el ratón, por el camino de la regla. Mide lo que tarda (ms por movimiento: el dibujo ligero entero).
CPStarfieldDock.prototype._clkdMove = function(x, y) {
   var st = this._clkdGeo(), C = this._clkd;
   if (!st || !C) return;
   var T = this._clkdYearsAt(st, x, y), t0 = Date.now();
   C.lastX = x; C.lastY = y; C.lastT = T;
   if (T === this.tm.t) return;
   if (c3ClkdBroken("own")) { this.tm.t = T; var was = this._light; this._light = true; try { this._render(); } finally { this._light = was; } }
   else this.tmSetTime(T, { light: true });
   ++C.moves; C.ms.push(Date.now() - t0); if (C.ms.length > 400) C.ms.shift();
};
CPStarfieldDock.prototype._clkdEnd = function(x, y) {
   var C = this._clkd;
   this._drag = null;
   if (C) C.drag = false;
   if (c3ClkdBroken("own")) this._render(); else this._tmSettle();        // (lo de la regla al soltar: el dibujo entero; sigue en pausa)
   var hot = (x !== undefined) && !!this._clkdHit(x, y);
   if (C) C.hot = hot;
   this._clkdCursor(hot ? "hot" : "");
   try { this.canvas.repaint(); } catch (e) {}
};
// EL RATÓN, envolviendo (los de debajo —la Galaxia, el rótulo, el cielo, el panel— siguen igual fuera de la esfera)
var c3ClkdBaseOnPress = CPStarfieldDock.prototype._onPress;
CPStarfieldDock.prototype._onPress = function(x, y, button, modifiers) {
   var st = (button === OPT_MOUSE_LEFT && !(this._drag && this._drag.clock)) ? this._clkdHit(x, y) : null;
   if (!st) return c3ClkdBaseOnPress.apply(this, arguments);
   this._lastInput = Date.now();
   try { this._animStop(); } catch (eA) {}
   if (!c3ClkdBroken("nopause")) this._tmStopAnims();                       // (la regla: `_tmStopAnims` en cada valor nuevo)
   this._drag = { x: x, y: y, button: button, moved: true, fit: null, win: null, pan: false, clock: true };
   var C = this._clkd || (this._clkd = { hot: false, drag: false, moves: 0, ms: [] });
   C.hot = true; C.drag = true; C.pressAt = Date.now();
   this._clkdCursor("drag");
   this._clkdMove(x, y);                                                    // (pulsar en la esfera: salta ahí, como la regla)
   try { this.canvas.repaint(); } catch (eR) {}
};
var c3ClkdBaseOnMove = CPStarfieldDock.prototype._onMove;
CPStarfieldDock.prototype._onMove = function(x, y, buttons) {
   var d = this._drag;
   if (d && d.clock) {
      if (buttons !== 0) { this._clkdMove(x, y); return; }
      this._clkdEnd(x, y);                                                  // (se soltó fuera sin que llegara el «soltar»)
      return;
   }
   if (!buttons && this._clkdHit(x, y)) {
      // (sobre la esfera: ni estrella bajo el cursor ni el tooltip de otra zona; el de la esfera, una vez)
      this._clkdSetHot(true); this._clkdCursor("hot");
      if (this.hoverStar >= 0 || this.hoverObj >= 0) this._setHover(-1, -1);
      var tip = c3ClkdTip();
      if (this._tip !== tip) { this._tip = tip; try { this.canvas.toolTip = cpWrapTooltip(tip); } catch (eT) {} }
      return;
   }
   if (this._clkd && this._clkd.hot) { this._clkdSetHot(false); this._clkdCursor(""); }
   return c3ClkdBaseOnMove.apply(this, arguments);
};
var c3ClkdBaseOnRelease = CPStarfieldDock.prototype._onRelease;
CPStarfieldDock.prototype._onRelease = function(x, y, button) {
   var d = this._drag;
   if (!(d && d.clock)) return c3ClkdBaseOnRelease.apply(this, arguments);
   this._clkdEnd(x, y);
};
// (el doble clic del lienzo es «la vista entera»: un doble clic en la esfera no mueve la cámara)
var c3ClkdBaseResetView = CPStarfieldDock.prototype.resetView;
CPStarfieldDock.prototype.resetView = function() {
   var C = this._clkd;
   if (C && C.pressAt && Date.now() - C.pressAt < C3_CLKD.DBL_MS) return;
   return c3ClkdBaseResetView.apply(this, arguments);
};
// EL HALO de la manecilla agarrada o bajo el ratón: encima del dibujo copiado (no lo rehace). Un anillo fino en el borde de la esfera (se puede
// tocar) y la manecilla otra vez sobre un halo de oro claro. Solo en el lienzo (no en lo exportado: `lay` es el del lienzo).
CPStarfieldDock.prototype._clkdPaintHot = function(g, st) {
   var A = (typeof CSH_ATLAS !== "undefined") ? CSH_ATLAS : { bg: "#110D09", surface: "#1B140E", gold: "#E5B53F", goldLight: "#F3D27E" };
   var R = st.R, lw = Math.max(1, 0.011 * R), cx = st.pivot.x, cy = st.pivot.y, drag = !!(this._clkd && this._clkd.drag), i;
   g.antialiasing = true;
   cshClockNoBrush(g);
   g.pen = new Pen(cshClockInt(A.goldLight, drag ? 0.75 : 0.5), Math.max(1.2, 1.4 * lw)); g.drawCircle(cx, cy, R * 0.985);
   // (mirado en la primera captura: el halo oscuro de la manecilla —cshPocketPaintHand— encima del de oro la dejaba con doble contorno, «hueca». Ahora
   //  dos capas de luz de oro claro y la manecilla en CREMA —el color del texto del tema, ningún color nuevo—, sin el halo oscuro)
   // (puntas y esquinas redondas: con la punta cuadrada el halo acababa en un bloque romo junto a las cifras)
   function soft(c, w) { try { if (typeof PenCap_Round !== "undefined" && typeof PenJoin_Round !== "undefined") return new Pen(c, w, PenStyle_Solid, PenCap_Round, PenJoin_Round); } catch (eP) {} return new Pen(c, w); }
   var glowA = soft(cshClockInt(A.goldLight, drag ? 0.30 : 0.22), Math.max(5, 7 * lw)), glowB = soft(cshClockInt(A.goldLight, drag ? 0.6 : 0.45), Math.max(2.5, 3.2 * lw));
   var hotI = cshClockInt(drag ? (A.text || A.goldLight) : A.goldLight);
   if (st.handAt) {
      var HA = st.handAt, PV = CSH_CLOCK.V[st.variant] || {}, faceI = (PV.face === "surface") ? cshClockInt(A.surface || A.bg) : cshClockInt(A.bg), pass, pen;
      // (HL1, 26-oct, mirado en la captura: el halo seguía la aguja fina de la «pomme» a la punta y se leía como un palo pálido hasta las cifras.
      //  Ahora el halo acaba en la «pomme»: una línea del eje a su centro + los círculos; la aguja de después, solo en crema, sin halo)
      var pom = null, dMax = -1;
      for (i = 0; i < HA.circles.length; ++i) if (HA.circles[i].fill === "gold") { var dd = Math.sqrt(Math.pow(HA.circles[i].x - cx, 2) + Math.pow(HA.circles[i].y - cy, 2)); if (dd > dMax) { dMax = dd; pom = HA.circles[i]; } }
      for (pass = 0; pass < 2; ++pass) {
         pen = pass ? glowB : glowA;
         if (pom) { g.pen = pen; g.drawLine(cx, cy, pom.x, pom.y); }
         else for (i = 0; i < HA.polys.length; ++i) if (HA.polys[i].fill === "gold") cshPocketPolyline(g, HA.polys[i].pts, pen, true);
         for (i = 0; i < HA.circles.length; ++i) if (HA.circles[i].fill === "gold") g.strokeCircle(HA.circles[i].x, HA.circles[i].y, HA.circles[i].r, pen);
      }
      for (i = 0; i < HA.polys.length; ++i) cshPocketFillPoly(g, HA.polys[i].pts, HA.polys[i].fill === "gold" ? hotI : faceI);
      for (i = 0; i < HA.circles.length; ++i) g.fillCircle(HA.circles[i].x, HA.circles[i].y, HA.circles[i].r, new Brush(HA.circles[i].fill === "gold" ? hotI : faceI));
   } else if (st.tip) { g.pen = glowA; g.drawLine(cx, cy, st.tip.x, st.tip.y); g.pen = glowB; g.drawLine(cx, cy, st.tip.x, st.tip.y); g.pen = new Pen(hotI, Math.max(1.5, 1.6 * lw)); g.drawLine(cx, cy, st.tip.x, st.tip.y); }
   g.fillCircle(cx, cy, 0.05 * R, new Brush(cshClockInt(A.gold)));
   g.fillCircle(cx, cy, 0.019 * R, new Brush(cshClockInt(A.bg)));
};
var c3ClkdBaseDrawMarks = CPStarfieldDock.prototype._drawMarks;
CPStarfieldDock.prototype._drawMarks = function(g, lay, k) {
   c3ClkdBaseDrawMarks.apply(this, arguments);
   var C = this._clkd;
   if (!C || !(C.hot || C.drag) || lay !== this.lay || (k !== undefined && k !== 1)) return;
   var st = this._clkdGeo();
   if (st) { try { this._clkdPaintHot(g, st); } catch (e) {} }
};
