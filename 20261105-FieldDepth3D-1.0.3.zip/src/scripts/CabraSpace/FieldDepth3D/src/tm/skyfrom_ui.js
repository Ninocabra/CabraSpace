// ============================================================================
// tm/skyfrom_ui.js — EL CIELO VISTO DESDE OTRA ESTRELLA, en el panel (Cabra3D, A6 15-oct-2026; bloque E 20-oct-2026)
// ----------------------------------------------------------------------------
// Eliges una estrella (clic en el 3D o en la foto) y «✦ Sky from the star»: la camara VUELA hasta ella por dentro de la
// caja (los mismos fotogramas que un vuelo) y se funde con un PLANETARIO desde alli (tm/sky_view.js): TODO el cielo
// —Hipparcos hasta V = 8 y las estrellas de la foto, tm/sky_catalog.js— en su nueva direccion y su nuevo brillo, el Sol
// como una estrella mas (con su magnitud y la constelacion en que se ve, Roman 1987), y las figuras de las constelaciones
// deformadas por el cambio de punto de vista. Se mira alrededor arrastrando, la rueda acerca, pasar por encima da la ficha.
// Se vuelve con «✕ Back», con Esc o con el mismo boton. Nada se calcula en onPaint: cada fotograma se pinta en un bitmap
// desde el tic o al cambiar la vista.
// (Bloque E, 20-oct: antes solo se dibujaban las estrellas del campo de la foto, sin interaccion y sin redibujar al cambiar
// de tamaño; y un clic cualquiera volvia. Ahora un clic elige una estrella.)
// ES5 (metodos de CPStarfieldDock).
// ============================================================================

var C3_SKYUI = { FLY_MS: 1500, FADE_MS: 700, BACK_MS: 500, TICK_S: 0.016, ZOOM_IN: 40 };
var C3_SKY_ROMAN = null;
function c3SkyRoman() {
   if (C3_SKY_ROMAN !== null) return C3_SKY_ROMAN;
   C3_SKY_ROMAN = [];
   try { C3_SKY_ROMAN = c3RomanParse(File.readTextFile(c3DataDir() + "constellations/" + "roman1987_vi42.dat")); } catch (e) {}
   return C3_SKY_ROMAN;
}

CPStarfieldDock.prototype._skyBuild = function() {
   var self = this;
   this.sky = { phase: "off", show: null };
   this.skyBtn = cpSfFlButton(this.rowsBox, "✦ " + optT("Sky from the star"), "c3.skyfrom", function() { self.skyToggle(); });
   // (lo coloca `_c3Layout`, en el grupo «Vista 3D»)
   this.skyTimer = new Timer;
   this.skyTimer.periodic = true; this.skyTimer.interval = C3_SKYUI.TICK_S;
   this.skyTimer.onTimeout = function() { self._skyTick(); };
};
CPStarfieldDock.prototype._skySync = function() {
   if (!this.skyBtn) return;
   var on = (this.mode === "dist" && this.state !== null && !this._closed), d = on ? this._tmData(this.state) : null;
   var ok = !!(d && d.tm && this.selStar >= 0 && d.tm.pos[this.selStar] !== undefined && this.pose === "perspective");
   cpSetControlVisible(this.skyBtn, on);
   try { this.skyBtn.enabled = ok || this.sky.phase !== "off"; this.skyBtn.toolTip = ok || this.sky.phase !== "off" ? cpTooltip("c3.skyfrom") : cpWrapTooltip(optT("Choose a star first (click it in the 3D view or in the photo); it needs a distance. In «Perspective».")); } catch (e) {}
   cpStyleToggle(this.skyBtn, this.sky.phase !== "off");
};
// AL CERRAR: su temporizador parado y sus bitmaps libres (lo llama `cleanup` del panel por `_c3Cleanup`).
CPStarfieldDock.prototype._c3Cleanup = function() {
   try { if (this.skyTimer) this.skyTimer.stop(); } catch (e) {}
   if (this.sky) { try { if (this.sky.P) cpFlPaintClose(this.sky.P); } catch (e1) {} this.sky.P = null; cpSfUiFree(this.sky.buf); cpSfUiFree(this.sky.chart); cpSfUiFree(this.sky.lastCopy); this.sky.buf = this.sky.chart = this.sky.lastCopy = this.sky.show = null; this.sky.phase = "off"; }
   try { if (this.state) { cpSfUiFree(this.state.dustTintBmp); this.state.dustTintBmp = null; } } catch (e2) {}
   for (var i = 0; this._kept && i < this._kept.length; ++i) { try { cpSfUiFree(this._kept[i].dustTintBmp); this._kept[i].dustTintBmp = null; cpSfUiFree(this._kept[i].tmStarless); this._kept[i].tmStarless = null; } catch (e3) {} }
};
CPStarfieldDock.prototype.skyToggle = function() { if (this.sky.phase !== "off") this.skyExit(); else this.skyFromStar(this.selStar); };

// Preparar el planetario en la estrella `wi` del mundo (sin pintar): { ok, why }
CPStarfieldDock.prototype._skyPrepare = function(wi, view) {
   var S = this.sky;
   S.W = this._skyWorldOf(this.state);
   if (wi === undefined || wi === null || wi < 0 || S.W.inf[wi]) return { ok: false, why: optT("Choose a star with a distance first.") };
   S.R = null; S.v = view || this._skyViewDefaults(); S.sel = null; S.hover = null; S.drag = null; S.info = {};
   this._skySetOrigin(wi);
   this._skyInfo();
   return { ok: true, why: "" };
};

// IR: { ok, why }. Sin animaciones (las pruebas), directo al cielo.
CPStarfieldDock.prototype.skyFromStar = function(idx) {
   var st = this.state, out = { ok: false, why: "" };
   if (!st || this.mode !== "dist" || !this.lay || this.lay.kind !== "dist") { out.why = "not in Distances"; return out; }
   var d = this._tmData(st);
   if (!d || d.tm.pos[idx] === undefined) { out.why = optT("Choose a star with a distance first."); return out; }
   this._animStop(); try { this._tmStopAnims(); } catch (e0) {}
   var W = this._skyWorldOf(st), pr = this._skyPrepare(W.byRef[idx]);
   if (!pr.ok) { out.why = pr.why; return out; }
   var model = this._distModel(), oi = model.objOfStar ? model.objOfStar[idx] : undefined, w = this.lay.w, h = this.lay.h, sc = this.lay.sc;
   this.sky.star = idx; this.sky.w = w; this.sky.h = h; this.sky.sc = sc;
   this.sky.chart = this._skyDraw(w, h, sc, false);
   this.sky.from0 = this.frame;
   if (oi === undefined || !C3_TM_ANIM) { this.sky.phase = "show"; this.sky.show = this.sky.chart; this._skySync(); try { this.canvas.repaint(); } catch (e1) {} out.ok = true; return out; }
   var ob = model.objects[oi], R = this.lay.rect, scale = cpSvDistScale(this.scaleMode, model, this.unit);
   this.sky.P = cpFlPaintOpen(this, w, h, { rect: R, hiRes: false });
   this.sky.camA = cpFlCamFromView(this.lay.fit.view, model, R);
   this.sky.camB = cpFlCam({ yaw: this.sky.camA.yaw, pitch: this.sky.camA.pitch, zoom: C3_SKYUI.ZOOM_IN, ox: ob.u, oy: ob.v, oz: scale.t(ob.pc) * CP_SV.DEPTH - CP_SV.DEPTH / 2, flat: 1, lens: this.sky.camA.lens, sx: 0, sy: 0 });
   this.sky.phase = "fly"; this.sky.t0 = C3_TM_CLOCK(); this.sky.buf = new Bitmap(w, h);
   this._skySync();
   try { this.skyTimer.start(); } catch (e2) {}
   out.ok = true;
   return out;
};
// Desde una estrella del CATALOGO por su numero HIP (sin vuelo): las pruebas, y ponerse en alfa Cen o en una Pleyade sin foto.
CPStarfieldDock.prototype.skyFromHip = function(hip, view) {
   var st = this.state, out = { ok: false, why: "" };
   if (!st || this.mode !== "dist") { out.why = "not in Distances"; return out; }
   this._animStop(); try { this._tmStopAnims(); } catch (e0) {}
   var W = this._skyWorldOf(st), pr = this._skyPrepare(W.byHip[hip], view);
   if (!pr.ok) { out.why = pr.why + " (HIP " + hip + ")"; return out; }
   this.sky.star = -1; this.sky.phase = "show";
   this._skyRedraw(false);
   this._skySync();
   out.ok = true;
   return out;
};
// Cambiar la vista desde fuera (las pruebas): { mode, ra, dec, fov, lim, lines, names, grid, photo, from: "sun"|"there" }
CPStarfieldDock.prototype.skySetView = function(o) {
   var S = this.sky; if (!S || S.phase !== "show") return false;
   for (var k in o) { if (k === "from") S.from = o[k]; else if (k !== "lines") S.v[k] = o[k]; }
   this._skyInfo();
   // (H6a: las lineas por el mismo camino que el mando —apiñado, solo para esta estrella—, despues de saber si esta apiñado)
   if (o.lines !== undefined) { this._skySetLines(o.lines === true); this._skyInfo(); }
   S.hover = null; this._skyRedraw(false);
   return true;
};
CPStarfieldDock.prototype.skyExit = function() {
   if (this.sky.phase === "off") return false;
   if (!C3_TM_ANIM || this.sky.phase === "fly" || !this.frame) { this._skyEnd(); return true; }
   this.sky.phase = "back"; this.sky.t0 = C3_TM_CLOCK();
   try { this.canvas.toolTip = ""; } catch (eT) {} this._skyTipNow = "";
   try { this.skyTimer.start(); } catch (e) {}
   return true;
};
CPStarfieldDock.prototype._skyEnd = function() {
   try { this.skyTimer.stop(); } catch (e) {}
   if (this.sky.P) { cpFlPaintClose(this.sky.P); this.sky.P = null; }
   cpSfUiFree(this.sky.buf); this.sky.buf = null;
   cpSfUiFree(this.sky.chart); this.sky.chart = null;
   this.sky.show = null; this.sky.phase = "off"; this.sky.lay = null; this.sky.scr = null; this.sky.hit = null; this.sky.hover = null; this.sky.sel = null;
   try { this.canvas.toolTip = ""; } catch (eT) {} this._skyTipNow = "";
   this._skySync();
   this._render();
};
function c3SkyEase(t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }
CPStarfieldDock.prototype._skyTick = function() {
   var S = this.sky, now = C3_TM_CLOCK();
   if (S.phase === "fly") {
      var s = (now - S.t0) / C3_SKYUI.FLY_MS;
      if (s >= 1) { S.phase = "fade"; S.t0 = now; S.last = cpFlPaintFrame(S.P, this._skyFrame(1)); S.lastCopy = new Bitmap(S.w, S.h); var gc = new Graphics(S.lastCopy); try { gc.drawBitmap(0, 0, S.last); } finally { gc.end(); } return this._skyTick(); }
      S.show = cpFlPaintFrame(S.P, this._skyFrame(c3SkyEase(s)));
      // (el vuelo, con su rotulo: la revision lo vio sin decir a donde va)
      try {
         var gF = new Graphics(S.show), FF = this._fonts(this.sky.sc), pd = Math.round(CP_SFUI.PAD * this.sky.sc), sl = this.state.result.stars[this.sky.star];
         try { gF.textAntialiasing = true; gF.font = FF.caps; gF.pen = new Pen(CP_INT_AMBER);
               gF.drawText(pd, pd + FF.caps.ascent, C3_EYEBROW + "  ·  " + format(optT("FLYING TO A G = %s STAR, TO SEE THE SKY FROM THERE"), (sl.g !== null) ? cpSvFx(sl.g, 1) : "?")); } finally { gF.end(); }
      } catch (eF) {}
   } else if (S.phase === "fade" || S.phase === "back") {
      var f = (now - S.t0) / ((S.phase === "fade") ? C3_SKYUI.FADE_MS : C3_SKYUI.BACK_MS), a = c3SkyEase(f), from = (S.phase === "fade") ? (S.lastCopy || S.from0) : S.chart, to = (S.phase === "fade") ? S.chart : this.frame;
      if (f >= 1) {
         if (S.phase === "back") { cpSfUiFree(S.lastCopy); S.lastCopy = null; this._skyEnd(); return; }
         S.phase = "show"; S.show = S.chart; try { this.skyTimer.stop(); } catch (e) {} cpSfUiFree(S.lastCopy); S.lastCopy = null;
         if (S.P) { cpFlPaintClose(S.P); S.P = null; }
         // (si el lienzo ha cambiado de tamaño durante el vuelo, el cielo se rehace a su tamaño)
         try { if (this.canvas.width !== S.w || this.canvas.height !== S.h) this._skyRedraw(false); } catch (eR) {}
      } else {
         if (!S.buf || S.buf.width !== S.w || S.buf.height !== S.h) { cpSfUiFree(S.buf); S.buf = new Bitmap(S.w, S.h); }
         var g = new Graphics(S.buf);
         try { g.fillRect(new Rect(0, 0, S.w, S.h), new Brush(CP_INT_SURFACE)); if (from) { g.opacity = 1 - a; g.drawBitmap(0, 0, from); } if (to) { g.opacity = a; g.drawBitmap(0, 0, to); } g.opacity = 1; } finally { g.end(); }
         S.show = S.buf;
      }
   } else { try { this.skyTimer.stop(); } catch (e2) {} }
   try { this.canvas.repaint(); } catch (e3) {}
};
CPStarfieldDock.prototype._skyFrame = function(s) {
   var A = this.sky.camA, B = this.sky.camB, c = {};
   for (var k in A) c[k] = A[k] + (B[k] - A[k]) * s;
   c.zoom = A.zoom * Math.pow(B.zoom / A.zoom, s);
   c = cpFlCam(c);
   return { t: 0, cam: c, prevCam: c, layers: { photo: 1, box: 1 - 0.6 * s, objects: 1 }, fx: { fade: 0, vignette: 0.25 * s, trail: 0, glow: 0, title: 0, counter: { alpha: 0, pc: 0 }, plate: null } };
};
// (compatibilidad: la carta desde la estrella idx de la foto, a w × h —la usaba c3_run 3.13—)
CPStarfieldDock.prototype._skyChart = function(idx, w, h, sc) {
   var W = this._skyWorldOf(this.state), pr = this._skyPrepare(W.byRef[idx]);
   return pr.ok ? this._skyDraw(w, h, sc, false) : null;
};

// ---------------------------------------------------------------------------
// LOS GANCHOS en el panel (envolviendo sus metodos: el panel no se toca)
// ---------------------------------------------------------------------------
function c3SkyLive(dock) { return !!(dock.sky && dock.sky.phase === "show" && dock.sky.v && dock.mode !== ""); }
// Pulsar: con el cielo a la vista, empieza un arrastre o un clic; durante el vuelo o el fundido, vuelve
var c3SkyBaseOnPress = CPStarfieldDock.prototype._onPress;
CPStarfieldDock.prototype._onPress = function(x, y, button, modifiers) {
   if (c3SkyLive(this)) { this.sky.lastPress = { x: x, y: y }; this._skyPress(x, y, button, modifiers); return; }
   if (this.sky && this.sky.phase !== "off") { this.skyExit(); return; }
   return c3SkyBaseOnPress.call(this, x, y, button, modifiers);
};
var c3SkyBaseOnMove = CPStarfieldDock.prototype._onMove;
CPStarfieldDock.prototype._onMove = function(x, y, buttons) {
   if (c3SkyLive(this)) { this._skyMove(x, y, buttons); return; }
   if (this.sky && this.sky.phase !== "off") return;
   return c3SkyBaseOnMove.call(this, x, y, buttons);
};
var c3SkyBaseOnRelease = CPStarfieldDock.prototype._onRelease;
CPStarfieldDock.prototype._onRelease = function(x, y, button) {
   if (c3SkyLive(this)) { this._skyRelease(x, y, button); return; }
   if (this.sky && this.sky.phase !== "off") { this._drag = null; return; }
   return c3SkyBaseOnRelease.call(this, x, y, button);
};
var c3SkyBaseOnWheel = CPStarfieldDock.prototype._onWheel;
CPStarfieldDock.prototype._onWheel = function(x, y, delta) {
   if (c3SkyLive(this)) { this._skyWheel(x, y, delta); return; }
   if (this.sky && this.sky.phase !== "off") return;
   return c3SkyBaseOnWheel.call(this, x, y, delta);
};
// Doble clic (el panel llama a resetView sin coordenadas: se usa la ultima pulsacion): centrar ahi la mirada
var c3SkyBaseResetView = CPStarfieldDock.prototype.resetView;
CPStarfieldDock.prototype.resetView = function() {
   if (c3SkyLive(this)) { var p = this.sky.lastPress; if (p) this._skyCentreAt(p.x, p.y); return; }
   if (this.sky && this.sky.phase !== "off") return;
   return c3SkyBaseResetView.apply(this, arguments);
};
// Esc con el cielo a la vista: volver (sin esto Esc cerraba el script entero)
var c3SkyBaseFsKey = CPStarfieldDock.prototype.fullScreenKey;
CPStarfieldDock.prototype.fullScreenKey = function(key, modifiers) {
   if (key === 27 && this.sky && this.sky.phase !== "off") { this.skyExit(); return true; }
   return c3SkyBaseFsKey.call(this, key, modifiers);
};
// Pintar: el bitmap del cielo y, encima, el anillo y la ficha de lo que hay bajo el raton (sin calcular nada)
var c3SkyBasePaint = CPStarfieldDock.prototype._paint;
CPStarfieldDock.prototype._paint = function(target) {
   if (c3SkyLive(this) && this.sky.show) {
      var t = target || this._canvasDocked || this.canvas;
      if (t !== this.canvas) return;
      var g = new Graphics(this.canvas);
      try { g.drawBitmap(0, 0, this.sky.show); this._skyOverlay(g); } finally { g.end(); }
      return;
   }
   return c3SkyBasePaint.call(this, target);
};
// Cambiar de tamaño (o cualquier redibujado del panel) con el cielo a la vista: el cielo se rehace a su tamaño
var c3SkyBaseRender = CPStarfieldDock.prototype._render;
CPStarfieldDock.prototype._render = function() {
   var r = c3SkyBaseRender.apply(this, arguments);
   try { if (c3SkyLive(this) && !this._closed && (this.canvas.width !== this.sky.w || this.canvas.height !== this.sky.h)) this._skyRedraw(false); } catch (e) {}
   return r;
};
// Elegir otra estrella: el boton se enciende o se apaga, y la elegida lleva su estela en la maquina del tiempo
var c3SkyBaseSelect = CPStarfieldDock.prototype.selectStar;
CPStarfieldDock.prototype.selectStar = function(star, obj) {
   var r = c3SkyBaseSelect.call(this, star, obj);
   try { this._skySync(); if (this.tm && this.tm.t !== 0 && this.tm.trails && this.mode === "dist") this._render(); } catch (e) {}
   return r;
};
