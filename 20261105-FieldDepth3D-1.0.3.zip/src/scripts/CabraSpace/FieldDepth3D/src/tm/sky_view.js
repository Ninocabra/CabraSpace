// ============================================================================
// tm/sky_view.js — EL PLANETARIO «desde la estrella» (Cabra3D, bloque E, 20-oct-2026): el dibujo y el raton
// ----------------------------------------------------------------------------
// Todo el cielo (Hipparcos hasta V = 8 + las estrellas de la foto, tm/sky_catalog.js) re-centrado en la estrella elegida,
// con las figuras de las constelaciones de Stellarium dibujadas EN 3D desde alli (se deforman: es lo que se quiere ver),
// sus nombres, una reticula AR/Dec, el contorno de la foto (las direcciones de la foto, desde el Sol) y el Sol.
// Dos vistas: PERSPECTIVA (estereografica alrededor de la mirada, 10°–180°) y TODO EL CIELO (Hammer-Aitoff).
// Raton: arrastrar mira alrededor; la rueda acerca (alejar del todo pasa a «todo el cielo» y acercar en el vuelve a la
// perspectiva, bajo el cursor); doble clic centra; pasar por encima da la ficha de la estrella; un clic la fija (y desde
// su ficha, «✦ Go there» salta a ella). Los mandos van DIBUJADOS arriba (chips de oro), con su tooltip.
// Rendimiento: el dibujo va a un bitmap SOLO cuando cambia la vista (`_skyRedraw`), con todo pre-calculado (direcciones y
// magnitudes desde alli, orden por brillo); las debiles son un pixel; se descarta lo que cae fuera. `onPaint` copia ese
// bitmap y pinta encima solo el anillo y la ficha de lo que hay bajo el raton (sin calcular nada).
// ES5 (metodos de CPStarfieldDock).
// ============================================================================

var C3_ONE_AGREE = true;          // costura del rojo E1 (tests/c3_d_fixes.js): false = «1 de ellas estan»
var C3_SKYV = { FOV0: 100, FOV_MIN: 10, FOV_MAX: 180, LIM0: 6.5, LIM_MIN: 3, LIM_MAX: 8, LIM_STEP: 0.5, LABELS_MAX: 40, HIT_CELL: 16,
   // (H6a) cuando las lineas nacen apagadas: mas de CROWD_LY al del Sol, o mas de CROWD_FIGS figuras a < 40° del Sol
   LY_PER_PC: 3.26156, CROWD_LY: 50, CROWD_FIGS: 30,
   // (H6b / V8) las debiles de la foto: como mucho PHOTO_MAX puntos (las mas brillantes vistas desde alli); opacidad FAINT_AMAX
   // en el limite, FAINT_STEP menos por magnitud, sin bajar de FAINT_AMIN
   PHOTO_MAX: 1500, FAINT_AMAX: 0.55, FAINT_STEP: 0.08, FAINT_AMIN: 0.15,
   // (H6d) rotulos de constelacion: celda de la rejilla de lo ya dibujado (px a escala 1)
   LAB_CELL: 6,
   // (3.ª ronda) nombres de constelacion desde OTRA estrella: como mucho uno por celda de NAME_CELL px (a escala 1; 0 = sin tope);
   // el de la constelacion del Sol primero y siempre (SUN_NAME_FIRST); luego el zodiaco
   NAME_CELL: 133, SUN_NAME_FIRST: true, ZODIAC: ["Ari", "Tau", "Gem", "Cnc", "Leo", "Vir", "Lib", "Sco", "Sgr", "Cap", "Aqr", "Psc"] };

// LOS DATOS empaquetados, leidos una vez por sesion de PixInsight: el catalogo Hipparcos y sus nombres de CabraShared (cshHipData,
// CabraShared/data/sky/: UNA lectura que comparten Cabra3D, CabraStars y CabraComposition en la misma sesion; 27-oct-2026, D4) y las
// figuras de las constelaciones de aqui (src/data/sky/constellations_modern.csv).
var C3_SKYDATA = null;
function c3SkyData() {
   if (C3_SKYDATA !== null) return C3_SKYDATA;
   var D = { ok: false, why: "", cat: null, names: {}, cons: [], ms: 0 }, t0 = Date.now(), dir = c3DataDir() + "sky/";
   try {
      var H = cshHipData();
      D.cat = H.cat; D.names = H.names; D.wgsn = H.wgsn; D.namesDropped = H.namesDropped;
      if (H.why) D.why = H.why;
      try { D.cons = c3SkyConstParse(File.readTextFile(dir + "constellations_modern.csv")); } catch (eC) {}
      D.ok = H.ok && D.cat !== null && D.cat.n > 0;
      if (!D.ok && !D.why) D.why = "empty catalogue";
   } catch (e) { D.why = String(e && e.message ? e.message : e); }
   D.ms = Date.now() - t0;
   C3_SKYDATA = D;
   return D;
}
function c3SkyTip(key) { return cpWrapTooltip(cpTooltipText(key)); }

// EL MUNDO de una foto: el catalogo + las estrellas de la foto (las de la maquina del tiempo, en su sitio de la foto).
CPStarfieldDock.prototype._skyWorldOf = function(st) {
   var d = this._tmData(st);
   if (st.skyWorld && st.skyWorldRef === d) return st.skyWorld;
   var D = c3SkyData(), tm = d ? d.tm : null, stars = st.result.stars, F = [], i;
   // (MIRADO el 15-oct desde Alcyone: los miembros de un cumulo van TODOS a la distancia del cumulo en «Distances», y desde uno de
   // ellos los demas caian en un CIRCULO perfecto a 90°. Aqui cada miembro con paralaje de Gaia bueno (> 5 sigma) va a la SUYA)
   var nOwn = 0;
   for (i = 0; tm && i < tm.n; ++i) {
      var e = c3TmStateAtPhoto(tm, i), s0 = stars[tm.idx[i]];
      if (s0.cluster >= 0 && s0.plx > 0 && (s0.plxErr === null || !(s0.plxErr > 0) || s0.plx / s0.plxErr > 5)) {
         var r = Math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z), kk = (1000 / s0.plx) / r;
         if (isFinite(kk) && kk > 0) { e.x *= kk; e.y *= kk; e.z *= kk; ++nOwn; }
      }
      var rd = c3SkyDirToRaDec(e.x, e.y, e.z);
      F.push({ x: e.x, y: e.y, z: e.z, ra: rd.ra, dec: rd.dec, g: (s0.g === null || s0.g === undefined) ? NaN : s0.g, bpRp: (s0.bpRp === null || s0.bpRp === undefined) ? NaN : s0.bpRp, ref: tm.idx[i] });
   }
   // las de la foto SIN distancia: al infinito (su direccion de la foto)
   for (i = 0; i < stars.length; ++i) {
      if (tm && tm.pos[i] !== undefined) continue;
      var s1 = stars[i]; if (s1.g === null || s1.g === undefined) continue;
      F.push({ x: null, y: null, z: null, ra: s1.ra0, dec: s1.dec0, g: s1.g, bpRp: (s1.bpRp === null || s1.bpRp === undefined) ? NaN : s1.bpRp, ref: i });
   }
   var W = c3SkyWorld(D.ok ? D.cat : null, F, {});
   W.nOwn = nOwn; W.dataOk = D.ok; W.dataWhy = D.why;
   W.byRef = {}; W.rgb = new Int32Array(W.n);
   for (i = 0; i < W.n; ++i) { if (W.ref[i] >= 0) W.byRef[W.ref[i]] = i; var c = cpSvStarRgb(W.bp[i]); W.rgb[i] = (c[0] << 16) | (c[1] << 8) | c[2]; }
   // las figuras, en indices del mundo
   W.figs = [];
   for (i = 0; i < D.cons.length; ++i) {
      var C = D.cons[i], polys = [], all = [];
      for (var j = 0; j < C.polys.length; ++j) {
         var p = [];
         for (var k = 0; k < C.polys[j].length; ++k) { var q = W.byHip[C.polys[j][k]]; p.push(q === undefined ? -1 : q); if (q !== undefined) all.push(q); }
         polys.push(p);
      }
      W.figs.push({ abbr: C.abbr, name: C.name, polys: polys, all: all });
   }
   st.skyWorld = W; st.skyWorldRef = d;
   return W;
};

// El nombre de una estrella del mundo: { title, sub }.
CPStarfieldDock.prototype._skyNameOf = function(i) {
   var S = this.sky, W = S.W, D = c3SkyData(), N = (W.hip[i] > 0) ? D.names[W.hip[i]] : null, t = "", sub = [];
   if (N && N.name) t = N.name;
   if (N && N.desig) { if (t) sub.push(N.desig); else t = N.desig; }
   if (W.hip[i] > 0) { if (t) sub.push("HIP " + W.hip[i]); else t = "HIP " + W.hip[i]; }
   if (W.ref[i] >= 0) {
      var s = this.state.result.stars[W.ref[i]];
      if (!t) t = format(optT("A G = %s star of the photo"), (s && s.g !== null) ? cpSvFx(s.g, 1) : "?");
      sub.push(optT("in the photo (Gaia DR3)"));
   }
   return { title: t, sub: sub.join(" · "), short: (N && N.name) ? N.name : ((N && N.desig) ? N.desig : "") };
};

// (21-oct) EL NOMBRE de una estrella de la foto, para las placas (video y panel): el comun de las brillantes casando la estrella
// (posicion y G de Gaia) con el catalogo Hipparcos empaquetado —el propio de la IAU, si no Bayer/Flamsteed, si no «HIP n»—; si no es
// de Hipparcos, «Gaia DR3 <id>»; si no hay id, «Gaia DR3 · <AR Dec>». El catalogo se lee una vez (c3SkyData) y el casado con Hipparcos se
// guarda por estrella (`st.starHip`: el numero HIP, 0 si no es de Hipparcos): solo se pide para los pocos destacados. El «Gaia DR3 <id>»
// NO se guarda: el id llega con el afinado en red, y un nombre guardado antes de que llegase se quedaria con la posicion.
CPStarfieldDock.prototype._starName = function(si) {
   var st = this.state, s = st ? st.result.stars[si] : null;
   if (!s) return "";
   if (!st.starHip) st.starHip = {};
   if (st.starHip[si] === undefined) {
      var hip = 0;
      try {
         // (solo las brillantes tocan el catalogo: la ficha de una estrella debil no carga 2,4 MB)
         var D = (s.g !== null && s.g !== undefined && isFinite(s.g) && s.g <= CSH_HIP.FIELD_GMAX_MATCH) ? c3SkyData() : { ok: false };
         if (D.ok) hip = c3SkyMatchHip(D.cat, s.ra0, s.dec0, s.g, (s.bpRp === null || s.bpRp === undefined) ? NaN : s.bpRp);
      } catch (e) {}
      st.starHip[si] = hip;
   }
   if (st.starHip[si] > 0) { try { return c3SkyNameOfHip(c3SkyData().names, st.starHip[si]); } catch (e2) {} }
   return this._gaiaName(s);
};

// EL ORIGEN: { kind: "world", w, pos } (una estrella) o null (el Sol). Re-centrar solo si ha cambiado.
CPStarfieldDock.prototype._skyRecentred = function() {
   var S = this.sky, o = (S.from === "sun" || !S.origin) ? null : S.origin, key = o ? ("w" + o.w) : "sun";
   if (S.R && S.Rkey === key && S.RW === S.W) return S.R;
   var t0 = Date.now(), R = c3SkyRecentre(S.W, o ? o.pos : null, o ? o.w : -1);
   // la direccion media de las estrellas de la foto vistas desde aqui («THE PHOTO FIELD»)
   var x = 0, y = 0, z = 0, n = 0, W = S.W;
   for (var i = 0; i < W.n; ++i) if (W.ref[i] >= 0 && !W.inf[i] && isFinite(R.m[i])) { x += R.ux[i]; y += R.uy[i]; z += R.uz[i]; ++n; }
   var r = Math.sqrt(x * x + y * y + z * z);
   R.fieldDir = (n > 0 && r > 0.05 * n) ? c3SkyDirToRaDec(x, y, z) : null;
   R.ms = Date.now() - t0;
   S.R = R; S.Rkey = key; S.RW = S.W;
   return R;
};

// LA VISTA de fabrica (se conservan entre entradas los interruptores y el limite; la mirada se pone en cada entrada)
CPStarfieldDock.prototype._skyViewDefaults = function() {
   if (!this.skyPrefs) this.skyPrefs = { mode: "persp", fov: C3_SKYV.FOV0, lim: C3_SKYV.LIM0, lines: true, names: true, grid: false, photo: true };
   var P = this.skyPrefs, f = this.state.result.field;
   return { mode: P.mode, fov: P.fov, lim: P.lim, lines: P.lines, names: P.names, grid: P.grid, photo: P.photo, ra: f.ra, dec: f.dec };
};

// ---------------------------------------------------------------------------
// EL DIBUJO: un bitmap w × h. `light` (arrastrando): sin rotulos de estrellas.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._skyDraw = function(w, h, sc, light) {
   var S = this.sky, V = S.v, W = S.W, R = this._skyRecentred(), D = c3SkyData(), st = this.state, f = st.result.field, F = this._fonts(sc);
   var t0 = Date.now(), b = new Bitmap(w, h), g = new Graphics(b), pad = Math.round(CP_SFUI.PAD * sc), i, n = W.n;
   var scr = { x: new Float32Array(n), y: new Float32Array(n), r: new Float32Array(n) }, hit = { cell: Math.round(C3_SKYV.HIT_CELL * sc), map: {} };
   var lay = { mode: V.mode, w: w, h: h, sc: sc, pad: pad };
   S.scr = scr; S.hit = hit; S.lay = lay; S.chips = []; S.sunXY = null;
   try {
      g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
      g.fillRect(new Rect(0, 0, w, h), new Brush(CP_INT_BG));
      // los mandos primero (se miden): el cielo va por debajo de todo
      var tb = this._skyToolbar(g, w, sc, F, true);
      var B = c3SkyBasis(V.ra, V.dec), P = { X: 0, Y: 0, c: 0, x: 0, y: 0 }, A = 0, k = 0, cx = w / 2, cy = h / 2;
      if (V.mode === "all") {
         var top = tb.bottom + pad, bot = h - pad - 3 * cpSfUiTextH(F.small);
         A = Math.min((w - 2 * pad) / (4 * Math.SQRT2), (bot - top) / (2 * Math.SQRT2)); cy = top + (bot - top) / 2;
         var ell = [];
         for (i = 0; i <= 120; ++i) { var an = 2 * Math.PI * i / 120; ell.push(new Point(cx + 2 * Math.SQRT2 * A * Math.cos(an), cy + Math.SQRT2 * A * Math.sin(an))); }
         g.fillRect(new Rect(0, 0, w, h), new Brush(CP_INT_SURFACE));
         g.pen = new Pen(0x00000000, 0); g.brush = new Brush(CP_INT_BG); g.drawPolygon(ell);
         lay.ell = ell;
      } else k = c3SkyStereoK(w, V.fov);
      lay.A = A; lay.k = k; lay.cx = cx; lay.cy = cy; lay.B = B;
      // proyectar una direccion -> P.x, P.y (false si no se ve)
      function proj(ux, uy, uz) {
         if (V.mode === "all") { c3SkyHammerVec(B, ux, uy, uz, P); P.x = cx + P.x * A; P.y = cy - P.y * A; return true; }
         if (!c3SkyStereo(B, ux, uy, uz, P, -0.9)) return false;
         P.x = cx - k * P.X; P.y = cy - k * P.Y; return true;
      }
      var wrapD = (V.mode === "all") ? 1.2 * A : 0.6 * w;
      // (H6d, 21-oct) LA REJILLA DE LO YA DIBUJADO (trazos de las figuras = 1, estrellas que se ven = 2), para que los nombres de
      // las constelaciones no caigan encima de una linea o de una estrella
      var oc = Math.max(3, Math.round(C3_SKYV.LAB_CELL * sc)), ogw = Math.ceil(w / oc) + 1, ogh = Math.ceil(h / oc) + 1, occ = new Uint8Array(ogw * ogh), markOcc = false;
      function occSet(x, y, v) { var cx0 = Math.floor(x / oc), cy0 = Math.floor(y / oc); if (cx0 >= 0 && cy0 >= 0 && cx0 < ogw && cy0 < ogh && occ[cx0 + cy0 * ogw] < v) occ[cx0 + cy0 * ogw] = v; }
      function occSeg(a0, b0) { var dx = b0.x - a0.x, dy = b0.y - a0.y, L = Math.sqrt(dx * dx + dy * dy), st = Math.max(1, Math.ceil(L / (oc / 2))); for (var s0 = 0; s0 <= st; ++s0) occSet(a0.x + dx * s0 / st, a0.y + dy * s0 / st, 1); }
      function occDisc(x, y, r0) { var c0 = Math.max(0, Math.floor((x - r0) / oc)), c1 = Math.min(ogw - 1, Math.floor((x + r0) / oc)), q0 = Math.max(0, Math.floor((y - r0) / oc)), q1 = Math.min(ogh - 1, Math.floor((y + r0) / oc)); for (var yy = q0; yy <= q1; ++yy) for (var xx = c0; xx <= c1; ++xx) occ[xx + yy * ogw] = 2; }
      function occScore(r0) { var s0 = 0, c0 = Math.max(0, Math.floor(r0.x0 / oc)), c1 = Math.min(ogw - 1, Math.floor(r0.x1 / oc)), q0 = Math.max(0, Math.floor(r0.y0 / oc)), q1 = Math.min(ogh - 1, Math.floor(r0.y1 / oc)); for (var yy = q0; yy <= q1; ++yy) for (var xx = c0; xx <= c1; ++xx) s0 += (occ[xx + yy * ogw] === 2) ? 4 : occ[xx + yy * ogw]; return s0; }
      function polyline(pts) {
         var seg = [];
         function out() { if (seg.length > 1) { g.drawPolyline(seg); if (markOcc) for (var s1 = 1; s1 < seg.length; ++s1) occSeg(seg[s1 - 1], seg[s1]); } }
         for (var q = 0; q < pts.length; ++q) {
            var pt = pts[q];
            if (pt === null || (seg.length && (Math.abs(pt.x - seg[seg.length - 1].x) > wrapD || Math.abs(pt.y - seg[seg.length - 1].y) > wrapD))) { out(); seg = []; if (pt === null) continue; }
            seg.push(pt);
         }
         out();
      }
      // un arco de circulo maximo entre dos direcciones, en trozos de ≤ 4°
      // (gap0, gap1: pixeles que se dejan libres en cada punta —las figuras no tocan sus estrellas, como en una carta—)
      function trim(pts, gap) {
         if (!(gap > 0) || pts.length < 2 || pts[0] === null || pts[1] === null) return;
         var dx = pts[1].x - pts[0].x, dy = pts[1].y - pts[0].y, L = Math.sqrt(dx * dx + dy * dy);
         if (L <= gap) { pts[0] = null; return; }
         pts[0] = new Point(pts[0].x + dx * gap / L, pts[0].y + dy * gap / L);
      }
      function arc(a, c, gap0, gap1) {
         var dot = a[0] * c[0] + a[1] * c[1] + a[2] * c[2], ang = Math.acos(Math.max(-1, Math.min(1, dot))), m = Math.max(1, Math.ceil(ang / (4 * Math.PI / 180))), pts = [];
         if (ang > 3.0) return;      // (casi opuestas: el arco no esta definido)
         for (var q = 0; q <= m; ++q) {
            var t = q / m, x = a[0] * (1 - t) + c[0] * t, y = a[1] * (1 - t) + c[1] * t, z = a[2] * (1 - t) + c[2] * t, r = Math.sqrt(x * x + y * y + z * z);
            pts.push(proj(x / r, y / r, z / r) ? new Point(P.x, P.y) : null);
         }
         trim(pts, gap0); pts.reverse(); trim(pts, gap1);
         polyline(pts);
      }
      // el radio de una estrella de magnitud m (el mismo que al pintarla)
      function rOf(m) { return (m <= V.lim) ? sc * Math.min(6.5, Math.max(0.5, 0.55 + 0.52 * (V.lim - m))) : 0.5 * sc; }
      var kd = Math.PI / 180, dc, ra2, line;
      // 1. la reticula AR/Dec (cada 30° y cada 2 h), el ecuador un poco mas marcado
      if (V.grid) {
         for (dc = -60; dc <= 60; dc += 30) {
            g.pen = new Pen(cpInt(CP_ATLAS.line, dc === 0 ? 1 : 0.75), Math.max(1, sc)); line = [];
            for (ra2 = 0; ra2 <= 360; ra2 += 3) { var u1 = c3SkyUnit(ra2, dc); line.push(proj(u1[0], u1[1], u1[2]) ? new Point(P.x, P.y) : null); }
            polyline(line);
         }
         g.pen = new Pen(cpInt(CP_ATLAS.line, 0.75), Math.max(1, sc));
         for (ra2 = 0; ra2 < 360; ra2 += 30) { line = []; for (dc = -88; dc <= 88; dc += 4) { var u2 = c3SkyUnit(ra2, dc); line.push(proj(u2[0], u2[1], u2[2]) ? new Point(P.x, P.y) : null); } polyline(line); }
      }
      // 2. las figuras de las constelaciones, desde aqui
      var nSeg = 0, nSegHidden = 0;
      if (V.lines && W.figs) {
         // (MIRADO el 20-oct desde Alcyone: las figuras que conocemos se APIÑAN alrededor del Sol y sus trazos hacia las estrellas
         // lejanas cruzan todo el cielo: un erizo. Un trazo de mas de 20° se apaga con su largo —lo recogido se lee y lo estirado
         // se ve, tenue— y uno de mas de 70° no se dibuja: se cuentan en S.info.nSegHidden y lo dice el tooltip de «LINES»)
         var goldRgb = cpInt(CP_ATLAS.gold) & 0xffffff, lw1 = Math.max(1, 1.1 * sc);
         markOcc = true;
         for (i = 0; i < W.figs.length; ++i) {
            var Fg = W.figs[i];
            for (var j = 0; j < Fg.polys.length; ++j) {
               var pl = Fg.polys[j];
               for (var q2 = 1; q2 < pl.length; ++q2) {
                  var a = pl[q2 - 1], c2 = pl[q2];
                  if (a < 0 || c2 < 0 || !isFinite(R.m[a]) || !isFinite(R.m[c2])) continue;
                  var sg = Math.acos(Math.max(-1, Math.min(1, R.ux[a] * R.ux[c2] + R.uy[a] * R.uy[c2] + R.uz[a] * R.uz[c2]))) * 180 / Math.PI;
                  if (sg > 70) { ++nSegHidden; continue; }
                  g.pen = this._pen(goldRgb, (sg <= 20) ? 0.4 : Math.max(0.07, 0.4 * Math.pow(20 / sg, 2)), lw1);
                  arc([R.ux[a], R.uy[a], R.uz[a]], [R.ux[c2], R.uy[c2], R.uz[c2]], rOf(R.m[a]) + 3 * sc, rOf(R.m[c2]) + 3 * sc); ++nSeg;
               }
            }
         }
         markOcc = false;
      }
      // 3. la foto: su contorno con las direcciones de la foto (desde el Sol)
      if (V.photo && st.result._unproject) {
         var cn = [[0, 0], [f.width, 0], [f.width, f.height], [0, f.height], [0, 0]], cdir = [];
         for (i = 0; i < cn.length; ++i) { var u4 = st.result._unproject(cn[i][0], cn[i][1]); cdir.push(u4 ? c3SkyUnit(u4.ra, u4.dec) : null); }
         g.pen = new Pen(cpInt(CP_ATLAS.text2, 0.7), Math.max(1, sc));
         for (i = 1; i < cdir.length; ++i) if (cdir[i - 1] && cdir[i]) arc(cdir[i - 1], cdir[i]);
         // (V8: la caja del contorno en pantalla, para poner «the photo» FUERA de su borde)
         var bx0 = 1e9, by0 = 1e9, bx1 = -1e9, by1 = -1e9, nbc = 0;
         for (i = 0; i < 4; ++i) if (cdir[i] && proj(cdir[i][0], cdir[i][1], cdir[i][2])) { bx0 = Math.min(bx0, P.x); bx1 = Math.max(bx1, P.x); by0 = Math.min(by0, P.y); by1 = Math.max(by1, P.y); ++nbc; }
         lay.photoBox = (nbc === 4 && bx1 - bx0 < 0.8 * w && by1 - by0 < 0.8 * h) ? { x0: bx0, y0: by0, x1: bx1, y1: by1 } : null;
         var uc = c3SkyUnit(f.ra, f.dec);
         if (proj(uc[0], uc[1], uc[2])) lay.photoXY = { x: P.x, y: P.y };
      }
      // 4. las estrellas, de la mas debil a la mas brillante; las de la foto, aunque pasen del limite, como un pixel tenue
      var ord = R.order, lim = V.lim, nDrawn = 0, labels = [], labLim = (V.mode === "all") ? 2.0 : Math.min(lim - 0.5, 2.6 + Math.max(0, (C3_SKYV.FOV0 - V.fov) / 30));
      var faintC = [], faintDone = false, nFaint = 0, pen0 = new Pen(0x00000000, 0), cell = hit.cell, M = hit.map, px1 = Math.max(1, Math.round(sc)), self = this;
      // (H6b, 21-oct; V8 de la revision) LAS DEBILES DE LA FOTO (mas debiles que el limite, con distancia): solo las PHOTO_MAX mas
      // brillantes VISTAS DESDE ALLI, cada una un punto suelto con su opacidad por magnitud. MIRADO en las Pleyades desde una de
      // ellas: las 7 800 a un pixel y 0,3 cada una pintaban un RECTANGULO NARANJA macizo; sumando su luz por pixel salia una
      // «caja gris» moteada. Asi se ven estrellas, no una mancha.
      function faintFlush() {
         if (faintDone) return; faintDone = true;
         faintC.sort(function(a3, b3) { return a3.m - b3.m; });
         var nF = Math.min(faintC.length, C3_SKYV.PHOTO_MAX);
         for (var fi = nF - 1; fi >= 0; --fi) {
            var Fp = faintC[fi], al2 = Math.max(C3_SKYV.FAINT_AMIN, Math.min(C3_SKYV.FAINT_AMAX, C3_SKYV.FAINT_AMAX - C3_SKYV.FAINT_STEP * (Fp.m - lim)));
            g.fillRect(Math.round(Fp.x), Math.round(Fp.y), Math.round(Fp.x) + px1, Math.round(Fp.y) + px1, self._brush(W.rgb[Fp.i], al2));
            scr.x[Fp.i] = Fp.x; scr.y[Fp.i] = Fp.y; scr.r[Fp.i] = 0.5 * sc; ++nDrawn;
            var key2 = Math.floor(Fp.x / cell) + Math.floor(Fp.y / cell) * 10000;
            if (M[key2]) M[key2].push(Fp.i); else M[key2] = [Fp.i];
         }
         nFaint = nF;
      }
      g.pen = pen0;
      for (var oi = 0; oi < ord.length; ++oi) {
         i = ord[oi];
         var m = R.m[i], isPhoto = (W.ref[i] >= 0);
         if (m <= lim && !faintDone) faintFlush();          // (la bruma, debajo de las que se ven)
         // (las de la foto mas debiles que el limite solo si tienen distancia: las que no, al infinito, se quedaban todas en el
         // recuadro de la foto y en las Pleyades —161 671 sin paralaje— eran un disco naranja que parecia una estrella enorme)
         if (!(m <= lim) && !(V.photo && isPhoto && !W.inf[i])) continue;
         if (!proj(R.ux[i], R.uy[i], R.uz[i])) continue;
         var x = P.x, y = P.y;
         if (x < -8 || y < -8 || x > w + 8 || y > h + 8) continue;
         var r, rgb = W.rgb[i];
         if (m <= lim) {
            r = sc * Math.min(6.5, Math.max(0.5, 0.55 + 0.52 * (lim - m)));
            if (r < 1.05 * sc) {
               var al = Math.max(0.3, Math.min(1, 0.3 + 0.7 * (lim - m) / 1.5));
               g.fillRect(Math.round(x), Math.round(y), Math.round(x) + px1, Math.round(y) + px1, this._brush(rgb, al));
            } else {
               if (m < 1.0) { g.brush = this._brush(rgb, 0.13); g.drawCircle(x, y, r * 2.4); }
               g.brush = this._brush(rgb, 1); g.drawCircle(x, y, r);
               if (r >= 1.5 * sc) occDisc(x, y, r + sc);
            }
         } else {
            // (las debiles de la foto: candidatas; se pintan las mas brillantes en `faintFlush`, antes que las que se ven)
            faintC.push({ i: i, x: x, y: y, m: m });
            continue;
         }
         scr.x[i] = x; scr.y[i] = y; scr.r[i] = r; ++nDrawn;
         var key = Math.floor(x / cell) + Math.floor(y / cell) * 10000;
         if (M[key]) M[key].push(i); else M[key] = [i];
         if (V.names && !light && m <= labLim && W.hip[i] > 0 && D.names[W.hip[i]]) labels.push(i);
      }
      faintFlush();
      S.info.nFaint = nFaint; S.info.nFaintCand = faintC.length;
      // 5. el Sol (si no se mira desde el)
      if (R.sun && proj(R.sun.ux, R.sun.uy, R.sun.uz) && P.x > -20 && P.y > -20 && P.x < w + 20 && P.y < h + 20) {
         var rs = sc * Math.min(7, Math.max(3, 0.55 + 0.52 * (lim - R.sun.m))), xs = P.x, ys = P.y;
         g.pen = new Pen(CP_INT_AMBER, Math.max(1, 1.2 * sc));
         for (i = 0; i < 8; ++i) { var an2 = Math.PI * i / 4; g.drawLine(xs + rs * 1.6 * Math.cos(an2), ys + rs * 1.6 * Math.sin(an2), xs + rs * 2.5 * Math.cos(an2), ys + rs * 2.5 * Math.sin(an2)); }
         g.pen = pen0; g.brush = new Brush(CP_INT_AMBER); g.drawCircle(xs, ys, rs);
         S.sunXY = { x: xs, y: ys, r: rs }; occDisc(xs, ys, rs * 2.5);
      }
      // 6. los rotulos: nombres de constelaciones (en el centro de su figura, desde aqui) y de las estrellas brillantes
      var used = [];
      function free(r0) { for (var q = 0; q < used.length; ++q) { var u = used[q]; if (r0.x0 < u.x1 && r0.x1 > u.x0 && r0.y0 < u.y1 && r0.y1 > u.y0) return false; } return true; }
      // (V12, 21-oct) LA ZONA SEGURA: ningun rotulo bajo la cabecera, el pie, «adonde se mira», la barra de mandos ni la ficha
      // fijada (MIRADO: MONOCEROS bajo la cabecera, COLUMBA cortado por el pie, PYXIS contra la ficha, PERSEUS contra los mandos).
      // Se reservan como rotulos ya puestos y `safe` exige el margen de la barra.
      var CH = this._skyChrome(g, w, h, sc, F, tb, R, nDrawn, true), mg = 4 * sc, topY = tb.bottom + mg;
      used.push({ x0: CH.head.x0 - mg, y0: CH.head.y0 - mg, x1: CH.head.x1 + mg, y1: CH.head.y1 + mg });
      used.push({ x0: CH.look.x0 - mg, y0: CH.look.y0 - mg, x1: CH.look.x1, y1: CH.look.y1 });
      used.push({ x0: CH.foot.x0 - mg, y0: CH.foot.y0 - mg, x1: CH.foot.x1 + mg, y1: h });
      if (S.sel !== null && S.sel !== undefined) { var cb = this._skyCardBox(S.sel, F, sc); used.push({ x0: cb.x0 - mg, y0: cb.y0 - mg, x1: cb.x1 + mg, y1: cb.y1 + mg }); }
      var nRes = used.length;
      function safe(r0) { return r0.x0 >= pad && r0.x1 <= w - pad && r0.y0 >= topY && r0.y1 <= h - pad; }
      // (la puntuacion de un rotulo contra lo dibujado, sin contar el disco de SU estrella)
      function occScoreEx(r0, ex, ey, er) { var s0 = 0, c0 = Math.max(0, Math.floor(r0.x0 / oc)), c1 = Math.min(ogw - 1, Math.floor(r0.x1 / oc)), q0 = Math.max(0, Math.floor(r0.y0 / oc)), q1 = Math.min(ogh - 1, Math.floor(r0.y1 / oc)); for (var yy = q0; yy <= q1; ++yy) for (var xx = c0; xx <= c1; ++xx) { var ccx = (xx + 0.5) * oc, ccy = (yy + 0.5) * oc; if ((ccx - ex) * (ccx - ex) + (ccy - ey) * (ccy - ey) <= (er + oc) * (er + oc)) continue; s0 += (occ[xx + yy * ogw] === 2) ? 4 : occ[xx + yy * ogw]; } return s0; }
      if (S.sunXY) {
         var ls = format(optT("the Sun · V %s"), cpSvFx(R.sun.m, 1)); g.font = F.plate;
         var lw = F.plate.width(ls), lx = S.sunXY.x + S.sunXY.r * 2.8, ly = S.sunXY.y - S.sunXY.r;
         if (lx + lw > w - pad) lx = S.sunXY.x - S.sunXY.r * 2.8 - lw;
         g.fillRect(new Rect(lx - 3 * sc, ly - F.plate.ascent - 2 * sc, lx + lw + 3 * sc, ly + F.plate.descent + 2 * sc), new Brush(cpInt(CP_ATLAS.bg, 0.75)));
         g.pen = new Pen(CP_INT_AMBERLIGHT); g.drawText(lx, ly, ls);
         used.push({ x0: lx - 3 * sc, x1: lx + lw + 3 * sc, y0: ly - F.plate.ascent - 2 * sc, y1: ly + F.plate.descent + 2 * sc });
      }
      // la foto: donde mira (desde el Sol) y donde quedan sus estrellas vistas desde aqui (si se separan mas de 1°)
      // `box` (V8): el contorno de la foto en pantalla; el rotulo va FUERA de su borde (encima, debajo o a un lado), no dentro
      function tag(x, y, text, box) {
         g.font = F.small; var tw2 = F.small.width(text), cand = [], th2 = F.small.ascent + F.small.descent, gap6 = 8 * sc, q7, r6 = null;
         if (box && box.x1 - box.x0 > 24 * sc) {
            var mx = (box.x0 + box.x1) / 2, my = (box.y0 + box.y1) / 2;
            cand.push([mx - tw2 / 2, box.y0 - gap6 - F.small.descent], [mx - tw2 / 2, box.y1 + gap6 + F.small.ascent], [box.x1 + gap6, my + th2 / 2 - F.small.descent], [box.x0 - gap6 - tw2, my + th2 / 2 - F.small.descent]);
         }
         cand.push([x + gap6, y - 6 * sc], [x - gap6 - tw2, y - 6 * sc]);
         for (q7 = 0; q7 < cand.length && r6 === null; ++q7) {
            var t6 = { x0: cand[q7][0] - 2 * sc, x1: cand[q7][0] + tw2 + 2 * sc, y0: cand[q7][1] - F.small.ascent - 1, y1: cand[q7][1] + F.small.descent + 1, tx: cand[q7][0], ty: cand[q7][1] };
            if (safe(t6) && free(t6)) r6 = t6;
         }
         if (r6 === null) return;
         g.fillRect(new Rect(r6.x0, r6.y0, r6.x1, r6.y1), new Brush(cpInt(CP_ATLAS.bg, 0.75)));
         g.pen = new Pen(CP_INT_TEXT2); g.drawText(r6.tx, r6.ty, text);
         used.push({ x0: r6.x0 - mg, x1: r6.x1 + mg, y0: r6.y0 - mg, y1: r6.y1 + mg });     // (con margen: Merope ya no se pega)
      }
      if (V.photo) {
         var fu = c3SkyUnit(f.ra, f.dec), apart = R.fieldDir ? c3SkySepDeg(fu, c3SkyUnit(R.fieldDir.ra, R.fieldDir.dec)) : 0;
         if (lay.photoXY) tag(lay.photoXY.x, lay.photoXY.y, apart > 1 ? optT("the photo (as seen from the Sun)") : optT("the photo"), lay.photoBox);
         if (R.fieldDir && apart > 1) { var fdu = c3SkyUnit(R.fieldDir.ra, R.fieldDir.dec); if (proj(fdu[0], fdu[1], fdu[2]) && P.x > 0 && P.y > tb.bottom && P.x < w && P.y < h) tag(P.x, P.y, optT("its stars, as seen from here"), null); }
      }
      // los nombres de las estrellas brillantes: FUERA del halo de su estrella (V12: «Toliman» caia encima del suyo) y sin caer
      // encima de otra estrella; se prueban derecha, izquierda, encima y debajo
      var nStarLab = 0, nStarLabSkip = 0, skipNames = [];
      if (labels.length) {
         labels.sort(function(a2, b2) { return R.m[a2] - R.m[b2]; });
         g.font = F.small; g.pen = new Pen(cpInt(CP_ATLAS.text2, 0.9));
         for (i = 0; i < labels.length && nStarLab < C3_SKYV.LABELS_MAX; ++i) {
            var q3 = labels[i], nm = this._skyNameOf(q3).short; if (!nm) continue;
            var tw = F.small.width(nm), sx3 = scr.x[q3], sy3 = scr.y[q3], halo = ((R.m[q3] < 1.0 && scr.r[q3] >= 1.05 * sc) ? 2.4 * scr.r[q3] : scr.r[q3]) + 3 * sc;
            var asc = F.small.ascent, dsc = F.small.descent, r3 = null;
            var c3s = [[sx3 + halo, sy3 + asc / 2 - 1], [sx3 - halo - tw, sy3 + asc / 2 - 1], [sx3 - tw / 2, sy3 - halo - dsc], [sx3 - tw / 2, sy3 + halo + asc]];
            var fb3 = null;
            for (var q8 = 0; q8 < c3s.length && r3 === null; ++q8) {
               var t3 = { x0: c3s[q8][0], x1: c3s[q8][0] + tw, y0: c3s[q8][1] - asc, y1: c3s[q8][1] + dsc, tx: c3s[q8][0], ty: c3s[q8][1] };
               if (!(safe(t3) && free({ x0: t3.x0 - 2 * sc, x1: t3.x1 + 2 * sc, y0: t3.y0, y1: t3.y1 }))) continue;
               if (occScoreEx(t3, sx3, sy3, halo) < 4) r3 = t3; else if (fb3 === null) fb3 = t3;
            }
            // (si los cuatro sitios rozan otra estrella, el nombre va igual —en el primero libre— con un fondo oscuro debajo para que
            // se lea y no quede «escondido» entre estrellas: MIRADO desde alfa Cen A, callar los que rozaban dejaba sin nombre a
            // Toliman, Deneb, Antares, Pollux… —21 de 49—)
            if (r3 === null && fb3 !== null) { r3 = fb3; g.fillRect(new Rect(r3.x0 - 2 * sc, r3.y0, r3.x1 + 2 * sc, r3.y1), new Brush(cpInt(CP_ATLAS.bg, 0.7))); g.pen = new Pen(cpInt(CP_ATLAS.text2, 0.9)); }
            if (r3 === null) { ++nStarLabSkip; if (skipNames.length < 12) skipNames.push(nm + (fb3 ? "*" : "")); continue; }
            g.drawText(r3.tx, r3.ty, nm); used.push(r3); ++nStarLab;
         }
      }
      var nNames = 0, nNamesSkipped = 0, nNamesOver = 0, nNamesDense = 0, consR = [], sunNameOk = false;
      function inEll(x, y) { var u = (x - cx) / A, v = (y - cy) / A; return u * u / 8 + v * v / 2 <= 1; }
      // (3.ª ronda, 21-oct: PRIORIDAD Y DENSIDAD. MIRADO en la comparativa —fila 7—: desde Atlas o una Pleyade 40–50 nombres se
      // apiñaban alrededor del Sol, y SCORPIUS —donde la cabecera dice que esta el Sol— no salia. Ahora se ponen por orden:
      // (1) la constelacion del Sol, SIEMPRE, junto al Sol (es la de sus limites, Roman 1987, la que dice la cabecera);
      // (2) el zodiaco y las figuras grandes o con estrellas brillantes (vistas desde aqui); (3) el resto. Y desde otra
      // estrella, como mucho UN nombre por celda de NAME_CELL px: nada se amontona. Desde el Sol, como antes —bien repartidos—)
      var fromSunV = (S.from === "sun" || !S.origin), sunAb = (!fromSunV && S.info.constellation) ? String(S.info.constellation).toLowerCase() : "";
      var cellPx = (!fromSunV && C3_SKYV.NAME_CELL > 0) ? Math.round(C3_SKYV.NAME_CELL * sc) : 0, cellUsed = {};
      if (V.names && W.figs) {
         g.font = F.caps; g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.6));
         var NC = [];
         for (i = 0; i < W.figs.length; ++i) {
            var isSunC = (sunAb !== "" && C3_SKYV.SUN_NAME_FIRST !== false && String(W.figs[i].abbr).toLowerCase() === sunAb);
            // (MIRADO el 20-oct desde una estrella a 133 pc: las figuras ESTALLAN —sus estrellas quedan repartidas por todo el
            // cielo— y el centro de una figura rota no esta en ningun sitio: 0 nombres en pantalla. Una figura que sigue
            // recogida (todas sus estrellas a < 40° de su centro) lleva el nombre en el centro; una rota, junto a la mas
            // brillante de sus estrellas que se vea, para saber de que figura es ese trozo)
            var Fa = W.figs[i].all, cd = c3SkyCentroid(R, Fa), spread = 0, q5;
            if (!cd && !isSunC) continue;
            if (cd) for (q5 = 0; q5 < Fa.length; ++q5) if (isFinite(R.m[Fa[q5]])) spread = Math.max(spread, c3SkySepDeg(cd, [R.ux[Fa[q5]], R.uy[Fa[q5]], R.uz[Fa[q5]]]));
            var ok5 = false, below = 0;
            if (isSunC && S.sunXY) {
               // (la del Sol, debajo del Sol y de su rotulo)
               P.x = S.sunXY.x; P.y = S.sunXY.y; below = S.sunXY.r * 2.6 + F.caps.ascent + 6 * sc; ok5 = true;
            } else if (cd && spread <= 40) ok5 = proj(cd[0], cd[1], cd[2]);
            else if (cd) {
               var bb = -1;
               for (q5 = 0; q5 < Fa.length; ++q5) { var s5 = Fa[q5]; if (scr.r[s5] > 0 && (bb < 0 || R.m[s5] < R.m[bb])) bb = s5; }
               // (solo si ese trozo tiene una estrella que se vea bien: con todas las figuras rotas, los nombres tapaban el cielo)
               if (bb >= 0 && R.m[bb] > 3.5) bb = -1;
               if (bb >= 0) { P.x = scr.x[bb]; P.y = scr.y[bb]; below = scr.r[bb] + F.caps.ascent + 4 * sc; ok5 = true; }
            }
            if (!ok5) continue;
            // la PRIORIDAD: la del Sol; luego el zodiaco; luego por su estrella mas brillante (vista desde aqui) y su tamaño en pantalla
            var mMin = 99, ex0 = 1e9, ex1 = -1e9, ey0 = 1e9, ey1 = -1e9;
            for (q5 = 0; q5 < Fa.length; ++q5) { var s6 = Fa[q5]; if (isFinite(R.m[s6]) && R.m[s6] < mMin) mMin = R.m[s6]; if (scr.r[s6] > 0) { ex0 = Math.min(ex0, scr.x[s6]); ex1 = Math.max(ex1, scr.x[s6]); ey0 = Math.min(ey0, scr.y[s6]); ey1 = Math.max(ey1, scr.y[s6]); } }
            var extent = (ex1 > ex0) ? Math.sqrt((ex1 - ex0) * (ex1 - ex0) + (ey1 - ey0) * (ey1 - ey0)) / sc : 0;
            var pri = isSunC ? 1e6 : ((C3_SKYV.ZODIAC.indexOf(String(W.figs[i].abbr)) >= 0 ? 100 : 0) + 10 * Math.max(-2, Math.min(6, 6 - mMin)) + Math.min(40, extent / 20));
            NC.push({ i: i, x: P.x, y: P.y + below, pri: pri, sun: isSunC });
         }
         NC.sort(function(a4, b4) { return (b4.pri - a4.pri) || (a4.i - b4.i); });
         for (var nci = 0; nci < NC.length; ++nci) {
            var Nc = NC[nci]; i = Nc.i; P.x = Nc.x; P.y = Nc.y;
            // (H6d, 21-oct: el nombre ya no cae encima de las lineas ni de las estrellas. Se prueban unos sitios alrededor del
            // centro —el centro, renglon y medio y dos y medio abajo y arriba, a los lados, en diagonal—; gana el primero LIMPIO;
            // si ninguno lo esta, el que menos roza, con un fondo oscuro debajo para que se lea; solo si TODOS chocan con otro
            // rotulo (o se salen del mapa) el nombre no se pone. MIRADO desde el Sol: callar los que rozaban dejaba fuera la
            // Osa Mayor, Escorpio o Casiopea —57 de 88—; mejor un nombre sobre una linea tenue que un nombre que falta)
            var cnm = W.figs[i].name.toUpperCase(), cw = F.caps.width(cnm), lh = 1.6 * cpSfUiTextH(F.caps), rr = null, best6 = 1e9, rrKey = "", forced = null, dense = false;
            var offs = [[0, 0], [0, lh], [0, -lh], [0.6 * cw, 0], [-0.6 * cw, 0], [0.6 * cw, lh], [-0.6 * cw, lh], [0.6 * cw, -lh], [-0.6 * cw, -lh],
                        [0, 2.5 * lh], [0, -2.5 * lh], [cw, 0], [-cw, 0]];
            for (var q6 = 0; q6 < offs.length && best6 > 0; ++q6) {
               var xx6 = P.x + offs[q6][0], yy6 = P.y + offs[q6][1], r7 = { x0: xx6 - cw / 2, x1: xx6 + cw / 2, y0: yy6 - F.caps.ascent, y1: yy6 + F.caps.descent, y: yy6 };
               if (!safe(r7)) continue;
               // (en «todo el cielo», dentro de la elipse: fuera no hay cielo)
               if (V.mode === "all" && !(inEll(r7.x0, r7.y0) && inEll(r7.x1, r7.y0) && inEll(r7.x0, r7.y1) && inEll(r7.x1, r7.y1))) continue;
               if (forced === null) forced = r7;
               // (con un margen a los lados: «MICROSCOPIUMSAGITTARIUS» salia pegado)
               if (!free({ x0: r7.x0 - 6 * sc, x1: r7.x1 + 6 * sc, y0: r7.y0, y1: r7.y1 })) continue;
               // (la densidad: una celda ya tiene su nombre —salvo el del Sol, que va siempre—)
               var key7 = cellPx > 0 ? Math.floor(xx6 / cellPx) + "," + Math.floor(yy6 / cellPx) : "";
               if (cellPx > 0 && !Nc.sun && cellUsed[key7]) { dense = true; continue; }
               var sc6 = occScore(r7);
               if (sc6 < best6) { best6 = sc6; rr = r7; rrKey = key7; }
            }
            // (V7: tambien lejos y con las lineas apagadas los nombres se quedan; NAMES es su propio interruptor. Se calla el que no
            // tiene sitio o cae en una celda ya ocupada —desde otra estrella—. El del Sol va SIEMPRE: si hace falta, encima de otro)
            if (rr === null && Nc.sun && forced !== null) { rr = forced; best6 = 1; rrKey = cellPx > 0 ? Math.floor((rr.x0 + rr.x1) / 2 / cellPx) + "," + Math.floor(rr.y / cellPx) : ""; }
            if (rr === null) { if (dense) ++nNamesDense; else ++nNamesSkipped; continue; }
            if (best6 > 0) { g.fillRect(new Rect(rr.x0 - 3 * sc, rr.y0 - sc, rr.x1 + 3 * sc, rr.y1 + sc), new Brush(cpInt(CP_ATLAS.bg, 0.7))); ++nNamesOver; }
            if (Nc.sun) { g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.9)); sunNameOk = true; }
            g.drawText(rr.x0, rr.y, cnm); used.push(rr); ++nNames;
            if (Nc.sun) g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.6));
            if (rrKey !== "") cellUsed[rrKey] = 1;
            consR.push({ x0: rr.x0, y0: rr.y0, x1: rr.x1, y1: rr.y1, abbr: W.figs[i].abbr, sun: Nc.sun });
         }
      }
      // el marco de todo el cielo, encima
      if (V.mode === "all") { g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.7), Math.max(1, sc)); g.brush = new Brush(0x00000000); g.drawPolygon(lay.ell); }
      // 7. los textos: cabecera, pie y donde se mira (con fondo, partidos en renglones: nunca «…»)
      this._skyChrome(g, w, h, sc, F, tb, R, nDrawn);
      // los mandos, encima de todo
      this._skyToolbar(g, w, sc, F, false);
      S.info.nDrawn = nDrawn; S.info.nSeg = nSeg; S.info.nSegHidden = nSegHidden; S.info.nNames = nNames; S.info.nNamesSkipped = nNamesSkipped; S.info.nNamesOver = nNamesOver; S.info.nStarLab = nStarLab; S.info.nStarLabSkip = nStarLabSkip; S.info.starLabSkipped = skipNames;
      S.info.nNamesDense = nNamesDense; S.info.consRects = consR; S.info.sunNameOk = sunNameOk; S.info.nameCellPx = cellPx;
      S.info.labRects = used.slice(nRes);                    // (las pruebas comprueban que ningun rotulo cae en la zona reservada)
      S.info.reserved = { head: CH.head, look: CH.look, foot: CH.foot, top: topY };
   } finally { g.end(); }
   S.info.ms = Date.now() - t0;
   return b;
};

// LOS MANDOS (chips dibujados). measure=true: solo calcula (devuelve { bottom }); false: pinta y guarda sus rectangulos.
CPStarfieldDock.prototype._skyToolbar = function(g, w, sc, F, measure) {
   var S = this.sky, V = S.v, pad = Math.round(CP_SFUI.PAD * sc), px = Math.round(6 * sc), py = Math.round(3 * sc), gap = Math.round(4 * sc), sep = Math.round(12 * sc);
   var hasThere = !!S.origin, fromSun = (S.from === "sun");
   var items = [
      { id: "back", t: "✕ " + optT("BACK"), tip: "c3sky.back" }, "|",
      { id: "persp", t: optT("PERSPECTIVE"), on: V.mode === "persp", tip: "c3sky.persp" }, { id: "all", t: optT("ALL SKY"), on: V.mode === "all", tip: "c3sky.all" }, "|",
      { id: "lines", t: optT("LINES"), on: V.lines, tip: "c3sky.lines" }, { id: "names", t: optT("NAMES"), on: V.names, tip: "c3sky.names" },
      { id: "grid", t: optT("GRID"), on: V.grid, tip: "c3sky.grid" }, { id: "photo", t: optT("PHOTO"), on: V.photo, tip: "c3sky.photo" }, "|",
      { id: "limDown", t: "−", tip: "c3sky.mag" }, { id: "lim", t: format(optT("MAG ≤ %s"), cpSvFx(V.lim, 1)), label: true, tip: "c3sky.mag" }, { id: "limUp", t: "+", tip: "c3sky.mag" }, "|",
      { id: "lookL", t: optT("LOOK AT"), label: true }, { id: "lookSun", t: optT("THE SUN"), tip: "c3sky.lookSun", off: fromSun || !hasThere },
      { id: "lookField", t: optT("THE PHOTO FIELD"), tip: "c3sky.lookField" }, { id: "lookCentre", t: optT("FIELD CENTRE"), tip: "c3sky.lookCentre" }, "|",
      { id: "fromL", t: optT("FROM"), label: true }, { id: "fromStar", t: optT("THE STAR"), on: !fromSun, tip: "c3sky.fromStar", off: !hasThere }, { id: "fromSun", t: optT("THE SUN"), on: fromSun, tip: "c3sky.fromSun" }
   ];
   var fh = cpSfUiTextH(F.caps), ch = fh + 2 * py, x = pad, y = pad, rows = 1;
   if (!measure) S.chips = [];
   for (var i = 0; i < items.length; ++i) {
      var it = items[i];
      if (it === "|") { x += sep; continue; }
      var tw = F.caps.width(it.t), cw = tw + 2 * px;
      if (x + cw > w - pad && x > pad) { x = pad; y += ch + gap; ++rows; }
      if (!measure) {
         var R0 = new Rect(x, y, x + cw, y + ch);
         if (!it.label) {
            g.fillRect(R0, new Brush(cpInt(CP_ATLAS.surface, 0.88)));
            g.pen = new Pen(it.on ? CP_INT_AMBER : cpInt(CP_ATLAS.line, 1), Math.max(1, sc)); g.brush = new Brush(0x00000000);
            g.drawRect(x, y, x + cw, y + ch);
         } else g.fillRect(R0, new Brush(cpInt(CP_ATLAS.bg, 0.6)));
         g.font = F.caps; g.pen = new Pen(it.off ? cpInt(CP_ATLAS.text3, 0.5) : (it.on ? CP_INT_AMBER : (it.label ? CP_INT_MUTED : CP_INT_TEXT2)));
         g.drawText(x + px, y + py + F.caps.ascent, it.t);
         S.chips.push({ id: it.id, x0: x, y0: y, x1: x + cw, y1: y + ch, tip: it.tip || "", off: !!it.off, label: !!it.label });
      }
      x += cw + gap;
   }
   return { bottom: y + ch, rows: rows };
};

// LOS TEXTOS: arriba a la izquierda quien mira y una frase llana; abajo el pie; abajo a la derecha, adonde se mira.
// `measure` (V12, 21-oct): no pinta; devuelve los rectangulos { head, look, foot } para que los rotulos del cielo no caigan debajo.
CPStarfieldDock.prototype._skyChrome = function(g, w, h, sc, F, tb, R, nDrawn, measure) {
   var S = this.sky, V = S.v, W = S.W, st = this.state, pad = Math.round(CP_SFUI.PAD * sc), gp = Math.round(CP_SFUI.GAP * sc), I = S.info, i, D = (measure !== true);
   var fromSun = (S.from === "sun" || !S.origin), o = S.origin;
   var eyebrow = fromSun ? optT("THE SKY SEEN FROM THE SUN") : ((o.kind === "photo") ? optT("THE SKY SEEN FROM A STAR OF THE PHOTO") : optT("THE SKY SEEN FROM ANOTHER STAR"));
   var who = fromSun ? optT("The real sky: as seen from the Sun (and from the Earth)") : format(optT("%s, %s from the Sun"), o.label, this._dist(I.dFrom));
   var plain;
   if (fromSun) plain = format(optT("%s stars to V %s, each in its real direction and brightness. Press «FROM: THE STAR» to see how the same sky looks from the star."), cpSvGroup(nDrawn), cpSvFx(V.lim, 1));
   else plain = format(optT("From there the Sun is a star of magnitude %s in %s, %s away. Each star is drawn in its direction and with its brightness from there (1/d²); the constellation figures are the ones we know, drawn in 3D: that is why they deform. %s stars without a reliable parallax stay at infinity (direction and brightness as from the Sun)."),
                    cpSvFx(R.sun.m, 1), I.name || "?", this._dist(R.sun.d), cpSvGroup(W.nInf));
   if (!fromSun && W.figs) {
      // (H6a: el recuento lo hace `_skyInfo`; si por eso las lineas estan apagadas, se dice y se dice como encenderlas)
      if (I.crowd && !V.lines) plain += " " + format(optT("Constellation lines are off: from here %s of the 88 figures we know crowd within 40° of the Sun (press «LINES» to draw them anyway)."), String(I.figsNearSun));
      else plain += " " + format(optT("%s of the 88 constellation figures we know now lie within 40° of the Sun."), String(I.figsNearSun));
   }
   var maxW = Math.min(w - 2 * pad, Math.max(Math.round(320 * sc), Math.round(w * 0.46)));
   var rows = c3HudWrap([{ k: "plain", t: plain }], { plain: F.small, caps: F.caps, big: F.plate, small: F.small }, maxW - 2 * gp);
   var hh = cpSfUiTextH(F.caps) + gp + cpSfUiTextH(F.plate) + gp + rows.length * (cpSfUiTextH(F.small) + 1) + 2 * gp, y0 = tb.bottom + gp, bw = 0;
   bw = Math.max(F.caps.width(eyebrow), F.plate.width(who)); for (i = 0; i < rows.length; ++i) bw = Math.max(bw, F.small.width(rows[i].t));
   bw = Math.min(bw + 2 * gp, w - 2 * pad);
   if (D) g.fillRect(new Rect(pad, y0, pad + bw, y0 + hh), new Brush(cpInt(CP_ATLAS.bg, 0.93)));
   var y = y0 + gp;
   if (D) { g.font = F.caps; g.pen = new Pen(CP_INT_AMBER); g.drawText(pad + gp, y + F.caps.ascent, eyebrow); }
   y += cpSfUiTextH(F.caps) + gp;
   // (si aun asi no cabe, se parte: la estrella elegida puede tener un nombre largo)
   var whoRows = c3HudWrap([{ k: "big", t: who }], { plain: F.plate, caps: F.caps, big: F.plate, small: F.small }, bw - 2 * gp);
   if (D) { g.font = F.plate; g.pen = new Pen(CP_INT_TEXT); }
   for (i = 0; i < whoRows.length; ++i) { if (D) g.drawText(pad + gp, y + F.plate.ascent, whoRows[i].t); y += cpSfUiTextH(F.plate); }
   y += gp;
   if (D) { g.font = F.small; g.pen = new Pen(CP_INT_TEXT2); }
   for (i = 0; i < rows.length; ++i) { if (D) g.drawText(pad + gp, y + F.small.ascent, rows[i].t); y += cpSfUiTextH(F.small) + 1; }
   S.lay.headBottom = y + gp;
   var headR = { x0: pad, y0: y0, x1: pad + bw, y1: Math.max(y0 + hh, y + gp) };
   // el pie: de donde sale todo y como se usa
   var foot = format(optT("Hipparcos (ESA 1997; van Leeuwen 2007) to V 8 + %s stars of the photo (Gaia DR3; %s of them are also in Hipparcos: drawn once) · figures: Stellarium «modern» (CC BY-SA 4.0) · star names: IAU (WGSN) · stars of one system share its parallax · the Sun's constellation: Roman 1987 · %s projection, east to the left · drag to look around, wheel to zoom, double click to centre, click a star for its card"),
                     cpSvGroup(W.nField), cpSvGroup(W.nMerged), V.mode === "all" ? optT("Hammer-Aitoff") : optT("stereographic"));
   // (1-nov-2026, E1) CONCORDANCIA: «1 de ellas estan» / «1 of them are» -> «1 de ellas esta» / «1 of them is» (con C3_ONE_AGREE = false, como antes)
   if (C3_ONE_AGREE !== false && W.nMerged === 1) foot = foot.replace(" of them are also in Hipparcos", " of them is also in Hipparcos").replace(" de ellas están también en Hipparcos", " de ellas está también en Hipparcos");
   if (!W.dataOk) foot = format(optT("The bright-star catalogue could not be read (%s): only the stars of the photo are drawn."), W.dataWhy) + " · " + foot;
   var fr = c3HudWrap([{ k: "small", t: foot }], { small: F.small, caps: F.small, big: F.small, plain: F.small }, w - 2 * pad - 2 * gp), fh = fr.length * cpSfUiTextH(F.small) + gp;
   // adonde se mira (abajo a la derecha, encima del pie)
   var look = (V.mode === "all") ? format(optT("centre RA %s, Dec %s"), c3SkyFmtRa(V.ra), c3SkyFmtDec(V.dec)) : format(optT("looking at RA %s, Dec %s · %s° across"), c3SkyFmtRa(V.ra), c3SkyFmtDec(V.dec), String(Math.round(V.fov)));
   var lkw = F.small.width(look) + 2 * gp, lky = h - pad - fh - cpSfUiTextH(F.small) - gp;
   var fy = h - pad - fh;
   if (D) {
      g.fillRect(new Rect(w - pad - lkw, lky, w - pad, lky + cpSfUiTextH(F.small) + gp), new Brush(cpInt(CP_ATLAS.bg, 0.9)));
      g.font = F.small; g.pen = new Pen(CP_INT_TEXT2); g.drawText(w - pad - lkw + gp, lky + gp / 2 + F.small.ascent, look);
      g.fillRect(new Rect(pad, fy - gp / 2, w - pad, h - pad + gp / 2), new Brush(cpInt(CP_ATLAS.bg, 0.9)));
      g.pen = new Pen(CP_INT_MUTED);
      for (i = 0; i < fr.length; ++i) g.drawText(pad + gp, fy + F.small.ascent + i * cpSfUiTextH(F.small), fr[i].t);
   }
   S.lay.footTop = lky - gp;
   return { head: headR, look: { x0: w - pad - lkw, y0: lky, x1: w - pad, y1: lky + cpSfUiTextH(F.small) + gp }, foot: { x0: pad, y0: fy - gp / 2, x1: w - pad, y1: h } };
};
function c3SkyFmtRa(ra) { var hh = ((ra % 360) + 360) % 360 / 15, H = Math.floor(hh), m = Math.round((hh - H) * 60); if (m === 60) { m = 0; H = (H + 1) % 24; } return H + "h " + (m < 10 ? "0" : "") + m + "m"; }
function c3SkyFmtDec(d) { return (d >= 0 ? "+" : "−") + Math.abs(d).toFixed(0) + "°"; }

// ---------------------------------------------------------------------------
// LO QUE SIGUE AL RATON (en onPaint, sin calcular nada: posiciones del ultimo dibujo): anillos y fichas.
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._skyOverlay = function(g) {
   var S = this.sky; if (!S || !S.lay) return;
   var sc = S.lay.sc, F = this._fonts(sc);
   g.antialiasing = true; try { g.textAntialiasing = true; } catch (e) {}
   S.cardChip = null;
   if (S.sel !== null && S.sel !== undefined) {
      var ps = this._skyXY(S.sel);
      if (ps) { g.pen = new Pen(CP_INT_AMBER, Math.max(1, 1.5 * sc)); g.brush = new Brush(0x00000000); var rr = Math.max(6 * sc, ps.r + 4 * sc); g.drawEllipse(ps.x - rr, ps.y - rr, ps.x + rr, ps.y + rr); }
      this._skyCard(g, S.sel, null, F, sc, true);
   }
   if (S.hover !== null && S.hover !== undefined && S.hover !== S.sel) {
      var ph = this._skyXY(S.hover);
      if (ph) {
         g.pen = new Pen(cpInt(CP_ATLAS.goldLight, 0.85), Math.max(1, sc)); g.brush = new Brush(0x00000000); var r2 = Math.max(5 * sc, ph.r + 3 * sc); g.drawEllipse(ph.x - r2, ph.y - r2, ph.x + r2, ph.y + r2);
         this._skyCard(g, S.hover, ph, F, sc, false);
      }
   }
};
CPStarfieldDock.prototype._skyXY = function(i) {
   var S = this.sky;
   if (i === -2) return S.sunXY;
   if (!S.scr || !(S.scr.r[i] > 0)) return null;
   return { x: S.scr.x[i], y: S.scr.y[i], r: S.scr.r[i] };
};
// Los renglones de la ficha de una estrella (o del Sol, i = −2)
CPStarfieldDock.prototype._skyCardLines = function(i) {
   var S = this.sky, W = S.W, R = S.R, L = [], fromSun = (S.from === "sun" || !S.origin);
   if (i === -2) {
      L.push({ k: "big", t: optT("the Sun") });
      L.push({ k: "plain", t: format(optT("From here: mag %s · %s"), cpSvFx(R.sun.m, 2), this._dist(R.sun.d)) });
      L.push({ k: "small", t: format(optT("Among the constellations we know, it is in %s"), S.info.name || "?") });
      return L;
   }
   var nm = this._skyNameOf(i);
   L.push({ k: "big", t: nm.title });
   if (nm.sub) L.push({ k: "small", t: nm.sub });
   if (W.inf[i]) {
      L.push({ k: "plain", t: format(optT("mag %s · no reliable parallax: placed at infinity (same direction and brightness from anywhere)"), cpSvFx(R.m[i], 2)) });
   } else {
      if (!fromSun) L.push({ k: "plain", t: format(optT("From here: mag %s · %s"), cpSvFx(R.m[i], 2), this._skyDist(R.d[i])) });
      L.push({ k: fromSun ? "plain" : "small", t: format(optT("From the Sun: mag %s · %s"), cpSvFx(W.v[i], 2), this._dist(W.d[i])) });
      if (W.sys && W.sys[i] >= 0) L.push({ k: "small", t: optT("Distance: the parallax of its system (weighted mean of its components within 30″, Hipparcos)") });
   }
   return L;
};
// Una distancia de la ficha: las muy cortas (la compañera de un sistema, < 0,01 al) en unidades astronomicas
CPStarfieldDock.prototype._skyDist = function(pc) {
   if (pc > 0 && pc * C3_SKYV.LY_PER_PC < 0.01) return format(optT("%s AU"), cpSvGroup(Math.round(pc * 206264.8)));
   return this._dist(pc);
};
// Pintar la ficha: junto al cursor (hover) o fija abajo a la izquierda (elegida, con «✦ Go there»)
// El rectangulo de la ficha FIJADA de la estrella i (V12: el dibujo lo reserva para que ningun rotulo quede debajo)
CPStarfieldDock.prototype._skyCardBox = function(i, F, sc) {
   var S = this.sky, L = this._skyCardLines(i), gp = Math.round(CP_SFUI.GAP * sc) + Math.round(2 * sc), pad = Math.round(CP_SFUI.PAD * sc), w = S.lay.w, h = S.lay.h;
   var FF = { big: F.plate, plain: F.small, small: F.small, caps: F.caps }, maxW = Math.min(Math.round(330 * sc), w - 2 * pad), rows = c3HudWrap(L, FF, maxW - 2 * gp), bw = 0, bh = 0, q;
   for (q = 0; q < rows.length; ++q) { var f = FF[rows[q].k] || F.small; bw = Math.max(bw, f.width(rows[q].t)); bh += cpSfUiTextH(f) + 1; }
   var go = i >= 0 && !S.W.inf[i] && !(S.origin && S.origin.w === i && S.from !== "sun"), goW = F.caps.width("✦ " + optT("GO THERE")) + Math.round(12 * sc), goH = cpSfUiTextH(F.caps) + Math.round(6 * sc);
   if (go) { bw = Math.max(bw, goW); bh += goH + gp; }
   bw += 2 * gp; bh += 2 * gp;
   var y = (S.lay.footTop || (h - pad)) - bh - gp;
   return { x0: pad, y0: y, x1: pad + bw, y1: y + bh };
};
CPStarfieldDock.prototype._skyCard = function(g, i, at, F, sc, pinned) {
   var S = this.sky, L = this._skyCardLines(i), gp = Math.round(CP_SFUI.GAP * sc) + Math.round(2 * sc), pad = Math.round(CP_SFUI.PAD * sc), w = S.lay.w, h = S.lay.h;
   var FF = { big: F.plate, plain: F.small, small: F.small, caps: F.caps }, maxW = Math.min(Math.round(330 * sc), w - 2 * pad), rows = c3HudWrap(L, FF, maxW - 2 * gp), bw = 0, bh = 0, q;
   for (q = 0; q < rows.length; ++q) { var f = FF[rows[q].k] || F.small; bw = Math.max(bw, f.width(rows[q].t)); bh += cpSfUiTextH(f) + 1; }
   var go = pinned && i >= 0 && !S.W.inf[i] && !(S.origin && S.origin.w === i && S.from !== "sun"), goT = "✦ " + optT("GO THERE"), goW = F.caps.width(goT) + Math.round(12 * sc), goH = cpSfUiTextH(F.caps) + Math.round(6 * sc);
   if (go) { bw = Math.max(bw, goW); bh += goH + gp; }
   bw += 2 * gp; bh += 2 * gp;
   var x, y;
   if (pinned) { x = pad; y = (S.lay.footTop || (h - pad)) - bh - gp; }
   else { x = at.x + 14 * sc; y = at.y + 14 * sc; if (x + bw > w - pad) x = at.x - 14 * sc - bw; if (y + bh > h - pad) y = at.y - 14 * sc - bh; x = Math.max(pad, x); y = Math.max(pad, y); }
   g.fillRect(new Rect(x, y, x + bw, y + bh), new Brush(cpInt(CP_ATLAS.surface, 0.94)));
   g.pen = new Pen(pinned ? CP_INT_AMBER : cpInt(CP_ATLAS.line, 1), Math.max(1, sc)); g.brush = new Brush(0x00000000); g.drawRect(x, y, x + bw, y + bh);
   var yy = y + gp;
   for (q = 0; q < rows.length; ++q) {
      var k = rows[q].k, f2 = FF[k] || F.small;
      g.font = f2; g.pen = new Pen(k === "big" ? CP_INT_AMBERLIGHT : (k === "small" ? CP_INT_MUTED : CP_INT_TEXT));
      g.drawText(x + gp, yy + f2.ascent, rows[q].t); yy += cpSfUiTextH(f2) + 1;
   }
   if (go) {
      yy += gp;
      g.fillRect(new Rect(x + gp, yy, x + gp + goW, yy + goH), new Brush(cpInt(CP_ATLAS.surface2, 1)));
      g.pen = new Pen(CP_INT_AMBER, Math.max(1, sc)); g.brush = new Brush(0x00000000); g.drawRect(x + gp, yy, x + gp + goW, yy + goH);
      g.font = F.caps; g.drawText(x + gp + Math.round(6 * sc), yy + Math.round(3 * sc) + F.caps.ascent, goT);
      S.cardChip = { id: "go", x0: x + gp, y0: yy, x1: x + gp + goW, y1: yy + goH, tip: "c3sky.go", w: i };
   }
   if (pinned) S.cardRect = { x0: x, y0: y, x1: x + bw, y1: y + bh };
};

// ---------------------------------------------------------------------------
// LO QUE HAY BAJO EL RATON: un mando, la ficha o una estrella (la mas brillante a menos de HIT px)
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._skyChipAt = function(x, y) {
   var S = this.sky, C = S.chips || [];
   if (S.cardChip && x >= S.cardChip.x0 && x <= S.cardChip.x1 && y >= S.cardChip.y0 && y <= S.cardChip.y1) return S.cardChip;
   for (var i = 0; i < C.length; ++i) if (x >= C[i].x0 && x <= C[i].x1 && y >= C[i].y0 && y <= C[i].y1) return C[i];
   return null;
};
CPStarfieldDock.prototype._skyStarAt = function(x, y) {
   var S = this.sky, H = S.hit; if (!H) return null;
   var best = null, bm = 1e9, R = S.R, sc = S.lay.sc, rad = Math.max(CP_SFUI.HIT * sc, 6 * sc), cell = H.cell;
   if (S.sunXY) { var dsx = x - S.sunXY.x, dsy = y - S.sunXY.y; if (dsx * dsx + dsy * dsy <= Math.pow(Math.max(rad, S.sunXY.r * 2.5), 2)) return -2; }
   var c0 = Math.floor((x - rad) / cell), c1 = Math.floor((x + rad) / cell), r0 = Math.floor((y - rad) / cell), r1 = Math.floor((y + rad) / cell);
   for (var cy = r0; cy <= r1; ++cy) for (var cx = c0; cx <= c1; ++cx) {
      var L = H.map[cx + cy * 10000]; if (!L) continue;
      for (var q = 0; q < L.length; ++q) {
         var i = L[q], dx = x - S.scr.x[i], dy = y - S.scr.y[i], rr = Math.max(rad, S.scr.r[i] + 3 * sc);
         if (dx * dx + dy * dy > rr * rr) continue;
         // (la mas brillante gana; a igualdad, la mas cercana)
         var score = R.m[i] + Math.sqrt(dx * dx + dy * dy) / rad * 0.5;
         if (score < bm) { bm = score; best = i; }
      }
   }
   return best;
};

// ---------------------------------------------------------------------------
// LAS ACCIONES
// ---------------------------------------------------------------------------
CPStarfieldDock.prototype._skyRedraw = function(light) {
   var S = this.sky; if (!S || S.phase !== "show") return;
   var w = 0, h = 0, sc = 1;
   try { w = this.canvas.width; h = this.canvas.height; sc = cpUiScale(this.canvas); } catch (e) {}
   if (!(w > 8 && h > 8)) return;
   var old = S.chart;
   S.chart = this._skyDraw(w, h, sc, light); S.show = S.chart; S.w = w; S.h = h; S.sc = sc;
   if (old && old !== S.chart) cpSfUiFree(old);
   try { this.canvas.repaint(); } catch (e2) {}
};
CPStarfieldDock.prototype._skyAction = function(id, chip) {
   var S = this.sky, V = S.v, P = this.skyPrefs, R = S.R;
   if (id === "back") { this.skyExit(); return; }
   if (id === "persp" || id === "all") { V.mode = P.mode = (id === "all") ? "all" : "persp"; if (V.mode === "persp" && V.fov >= C3_SKYV.FOV_MAX) V.fov = 150; }
   else if (id === "lines") { this._skySetLines(!V.lines); }
   else if (id === "names" || id === "grid" || id === "photo") { V[id] = P[id] = !V[id]; }
   else if (id === "limDown" || id === "limUp") { V.lim = P.lim = Math.max(C3_SKYV.LIM_MIN, Math.min(C3_SKYV.LIM_MAX, V.lim + (id === "limUp" ? 1 : -1) * C3_SKYV.LIM_STEP)); }
   else if (id === "lookSun") { if (!R.sun) return; V.ra = R.sun.ra; V.dec = R.sun.dec; }
   else if (id === "lookField") { var fd = R.fieldDir || { ra: this.state.result.field.ra, dec: this.state.result.field.dec }; V.ra = fd.ra; V.dec = fd.dec; }
   else if (id === "lookCentre") { V.ra = this.state.result.field.ra; V.dec = this.state.result.field.dec; }
   else if (id === "fromStar") { if (!S.origin) return; S.from = "there"; }
   else if (id === "fromSun") { S.from = "sun"; }
   else if (id === "go") { this._skySetOrigin(chip.w); S.sel = null; }
   else return;
   S.hover = null;
   this._skyInfo();
   this._skyRedraw(false);
};
// Ponerse en la estrella w del mundo
CPStarfieldDock.prototype._skySetOrigin = function(wi) {
   var S = this.sky, W = S.W;
   if (wi < 0 || W.inf[wi]) return false;
   var nm = this._skyNameOf(wi);
   S.origin = { kind: (W.ref[wi] >= 0) ? "photo" : "hip", w: wi, pos: { x: W.x[wi], y: W.y[wi], z: W.z[wi] }, label: nm.title, hip: W.hip[wi], ref: W.ref[wi] };
   S.from = "there"; S.linesUser = null;          // (H6a: lo elegido con las lineas apiñadas vale para UNA estrella)
   return true;
};
// Lo que cuentan las pruebas y la cabecera (el Sol desde alli y su constelacion de Roman)
CPStarfieldDock.prototype._skyInfo = function() {
   var S = this.sky, R = this._skyRecentred(), o = S.origin, I = S.info || {};
   I.dFrom = o ? Math.sqrt(o.pos.x * o.pos.x + o.pos.y * o.pos.y + o.pos.z * o.pos.z) : 0;
   if (R.sun) {
      I.sun = { ra: R.sun.ra, dec: R.sun.dec, d: R.sun.d, mv: R.sun.m, mg: C3_SKY.SUN_MG + 5 * Math.log(R.sun.d / 10) / Math.LN10 };
      I.constellation = c3ConstellationOf(R.sun.ra, R.sun.dec, c3SkyRoman());
      I.name = (I.constellation && C3_CONST_NAMES[I.constellation]) ? C3_CONST_NAMES[I.constellation] : I.constellation;
   } else { I.sun = null; I.constellation = ""; I.name = ""; }
   I.n = S.W.n; I.nHip = S.W.nHip; I.nField = S.W.nField; I.nMerged = S.W.nMerged; I.nInf = S.W.nInf; I.from = (S.from === "sun" || !o) ? "sun" : "there";
   // (H6a, 21-oct) EL ERIZO: desde una Pleyade 75 de las 88 figuras caen a < 40° del Sol y sus trazos se apiñan alrededor de el.
   // Lejos (> CROWD_LY del Sol) o con > CROWD_FIGS figuras a < 40° del Sol, las LINEAS nacen apagadas (y se dice); el usuario las
   // enciende con «LINES» (S.linesUser: lo que eligio ESTANDO apiñado; se olvida al cambiar de estrella).
   I.figsNearSun = 0;
   if (I.from === "there" && S.W.figs && R.sun) {
      var su = [R.sun.ux, R.sun.uy, R.sun.uz];
      for (var f = 0; f < S.W.figs.length; ++f) { var cdn = c3SkyCentroid(R, S.W.figs[f].all); if (cdn && c3SkySepDeg(cdn, su) <= 40) ++I.figsNearSun; }
   }
   I.crowd = (I.from === "there") && (I.dFrom * C3_SKYV.LY_PER_PC > C3_SKYV.CROWD_LY || I.figsNearSun > C3_SKYV.CROWD_FIGS);
   if (S.v) {
      var P = this.skyPrefs || { lines: true };
      S.v.lines = I.crowd ? (S.linesUser === true) : (P.lines !== false);
   }
   S.info = I;
   return I;
};
// Encender o apagar LAS LINEAS (el mando y skySetView): apiñado, solo para esta estrella; si no, es la preferencia.
CPStarfieldDock.prototype._skySetLines = function(on) {
   var S = this.sky, I = S.info || {};
   if (I.crowd) S.linesUser = (on === true);
   else { if (this.skyPrefs) this.skyPrefs.lines = (on === true); }
   if (S.v) S.v.lines = (on === true);
};

// EL RATON con el cielo a la vista
CPStarfieldDock.prototype._skyPress = function(x, y, button, modifiers) {
   var S = this.sky; S.drag = { x: x, y: y, ra: S.v.ra, dec: S.v.dec, moved: false, button: button };
};
CPStarfieldDock.prototype._skyMove = function(x, y, buttons) {
   var S = this.sky, d = S.drag;
   if (d && buttons !== 0) {
      var dx = x - d.x, dy = y - d.y;
      if (!d.moved && dx * dx + dy * dy <= 9) return;
      d.moved = true; S.hover = null;
      var k = (S.v.mode === "all") ? S.lay.A : S.lay.k, gz = c3SkyGazeDrag(d.ra, d.dec, dx, dy, k > 0 ? k : 1);
      S.v.ra = gz.ra; S.v.dec = gz.dec;
      this._skyRedraw(true);
      return;
   }
   var chip = this._skyChipAt(x, y), tip = "";
   if (chip && chip.tip) tip = c3SkyTip(chip.tip);
   if (tip !== this._skyTipNow) { this._skyTipNow = tip; try { this.canvas.toolTip = tip; } catch (eT) {} }
   var hv = chip ? null : this._skyStarAt(x, y);
   if (hv !== S.hover) { S.hover = hv; try { this.canvas.repaint(); } catch (e) {} }
};
CPStarfieldDock.prototype._skyRelease = function(x, y, button) {
   var S = this.sky, d = S.drag; S.drag = null;
   if (!d) return;
   if (d.moved) { this._skyRedraw(false); return; }
   if (button !== OPT_MOUSE_LEFT) return;
   var chip = this._skyChipAt(x, y);
   if (chip) { if (!chip.off && !chip.label) this._skyAction(chip.id, chip); return; }
   if (S.cardRect && x >= S.cardRect.x0 && x <= S.cardRect.x1 && y >= S.cardRect.y0 && y <= S.cardRect.y1) return;
   var hit = this._skyStarAt(x, y), was = S.sel;
   S.sel = (hit !== null) ? hit : null; S.cardRect = null; S.cardChip = null;
   // (V12: la ficha fijada reserva su sitio en el dibujo —ningun rotulo debajo—: si cambia, se rehace el dibujo)
   if (S.sel !== was && !(S.sel === null && (was === null || was === undefined))) this._skyRedraw(false);
   else { try { this.canvas.repaint(); } catch (e) {} }
};
// La direccion bajo el pixel (x, y) del ultimo dibujo, o null
CPStarfieldDock.prototype._skyDirAt = function(x, y) {
   var L = this.sky.lay; if (!L) return null;
   if (L.mode === "all") return c3SkyHammerInv(L.B, (x - L.cx) / L.A, (L.cy - y) / L.A);
   return c3SkyStereoInv(L.B, (L.cx - x) / L.k, (L.cy - y) / L.k);
};
CPStarfieldDock.prototype._skyWheel = function(x, y, delta) {
   var S = this.sky, V = S.v, L = S.lay; if (!delta || !L) return;
   var u = this._skyDirAt(x, y);
   if (V.mode === "all") {
      if (delta < 0) return;
      // acercar en «todo el cielo»: a la perspectiva, mirando bajo el cursor
      if (!u) return;
      var rd = c3SkyDirToRaDec(u[0], u[1], u[2]); V.mode = this.skyPrefs.mode = "persp"; V.fov = 150; V.ra = rd.ra; V.dec = rd.dec;
      this._skyRedraw(false); return;
   }
   var nf = V.fov * ((delta > 0) ? 0.8 : 1.25);
   if (nf > C3_SKYV.FOV_MAX + 1) { V.mode = this.skyPrefs.mode = "all"; this._skyRedraw(false); return; }
   V.fov = this.skyPrefs.fov = Math.max(C3_SKYV.FOV_MIN, Math.min(C3_SKYV.FOV_MAX, nf));
   // que lo que hay bajo el cursor se quede bajo el cursor (dos pasos de arrastre bastan)
   if (u) {
      for (var it = 0; it < 2; ++it) {
         var B = c3SkyBasis(V.ra, V.dec), k = c3SkyStereoK(L.w, V.fov), P = {};
         if (!c3SkyStereo(B, u[0], u[1], u[2], P, -0.9)) break;
         var gz = c3SkyGazeDrag(V.ra, V.dec, x - (L.cx - k * P.X), y - (L.cy - k * P.Y), k);
         V.ra = gz.ra; V.dec = gz.dec;
      }
   }
   this._skyRedraw(false);
};
CPStarfieldDock.prototype._skyCentreAt = function(x, y) {
   var u = this._skyDirAt(x, y); if (!u) return;
   var rd = c3SkyDirToRaDec(u[0], u[1], u[2]); this.sky.v.ra = rd.ra; this.sky.v.dec = rd.dec;
   this._skyRedraw(false);
};
