// ============================================================================
// tm/timemachine_run.js — LA MAQUINA DEL TIEMPO: lo que toca la red y el campo (14-oct-2026)
// ----------------------------------------------------------------------------
// La fisica es pura (tm/timemachine.js). Aqui:
//   · `c3TmFetchRv( result, opts )`: las VELOCIDADES RADIALES de Gaia DR3 del campo (la
//     base local del proceso Gaia no las trae). Una consulta TAP a VizieR (I/355/gaiadr3,
//     columna RV), por el mismo camino que el afinado de CabraPilot (`cpSfHttpText`, con
//     su tope de tiempo, su señal de vida y su costura de pruebas `CP_SF_HTTP_HOOK`), y se
//     casan por posicion J2016 (0,1", como `cpSfRefineApply`). Gaia DR3 da velocidad radial
//     a ~33,8 millones de estrellas, casi todas de G < 15: en un campo tipico, una minoria.
//     Devuelve { ok, code, why, rows, matched, ms, rv: { indice de estrella: { rv, err } } }.
//     (27-oct-2026) Si VizieR no da la tabla, la MISMA consulta a GAVO (Heidelberg, gaia.dr3lite): `source`, `server`, `serverId`,
//     `fallback` y `attempts` dicen de donde vino y quien fallo (c3TmFetchRv, abajo).
//   · `c3TmTanOf( result )`: la proyeccion gnomonica ajustada a la solucion de la foto (una
//     rejilla de 7 × 7 puntos por `result._unproject`), para llevar de cielo a pixel sin la
//     libreria en cada fotograma.
// ES5.
// ============================================================================

function c3TmRvAdql(ra, dec, radiusDeg) {
   // (30-oct, decision D: GRVSmag y RVtempTeff, medidas en I/355/gaiadr3 el 30-oct: con ellas, si contesta VizieR la correccion ya no necesita preguntar a la ESA, c3TmRvCorrect)
   return "SELECT RA_ICRS,DE_ICRS,RV,e_RV" + (cshRvColsOn() ? ",GRVSmag,RVtempTeff" : "") + " FROM \"I/355/gaiadr3\" WHERE 1=CONTAINS(POINT('ICRS',RA_ICRS,DE_ICRS),CIRCLE('ICRS'," +
          ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND RV IS NOT NULL";
}
function c3TmRvRows(csvText) {
   var t = cpSfParseTable(csvText, ","), out = [];
   for (var i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], ra = cpSfNum(r.RA_ICRS), dec = cpSfNum(r.DE_ICRS), rv = cpSfNum(r.RV);
      if (ra === null || dec === null || rv === null) continue;
      var row = { ra: ra, dec: dec, rv: rv, err: cpSfNum(r.e_RV) };
      // (28-oct, tarde: la magnitud RVS y la Teff de la plantilla, si la tabla las trae —la de la ESA—, para la correccion de Katz/Blomme)
      // (30-oct: VizieR tambien, GRVSmag y RVtempTeff; la de la ESA, con su alias de siempre)
      if (r.GRVSmag !== undefined) { row.grvs = cpSfNum(r.GRVSmag); row.tteff = cpSfNum(r.RVtempTeff); }
      else if (r.grvs !== undefined) { row.grvs = cpSfNum(r.grvs); row.tteff = cpSfNum(r.tteff); }
      out.push(row);
   }
   return out;
}
// Casar filas con estrellas por su posicion J2016 (ra0, dec0). Devuelve { rv: { indice: { rv, err } }, at: { indice: n.º de fila }, matched, unmatched }.
function c3TmRvMatch(stars, rows, tolArcsec) {
   var tol = ((tolArcsec > 0) ? tolArcsec : 0.1) / 3600, cell = 2 / 3600, grid = {}, i, key, out = { rv: {}, at: {}, matched: 0, unmatched: 0 };
   var yieldOk = (typeof cshYield === "function");             // (22-oct: la interfaz atendida mientras se casa: CabraShared/csh_net.js)
   for (i = 0; i < stars.length; ++i) {
      if (yieldOk && (i & 1023) === 1023) cshYield();
      key = Math.floor(stars[i].dec0 / cell) + "," + Math.floor(stars[i].ra0 * Math.cos(stars[i].dec0 * Math.PI / 180) / cell);
      (grid[key] || (grid[key] = [])).push(i);
   }
   for (var r = 0; r < rows.length; ++r) {
      if (yieldOk && (r & 255) === 255) cshYield();
      var q = rows[r], gy = Math.floor(q.dec / cell), gx = Math.floor(q.ra * Math.cos(q.dec * Math.PI / 180) / cell), best = -1, bd = tol;
      for (var dy = -1; dy <= 1; ++dy) for (var dx = -1; dx <= 1; ++dx) {
         var list = grid[(gy + dy) + "," + (gx + dx)];
         if (!list) continue;
         for (var k = 0; k < list.length; ++k) { var d = cpSfSeparation(q.ra, q.dec, stars[list[k]].ra0, stars[list[k]].dec0); if (d <= bd) { bd = d; best = list[k]; } }
      }
      if (best < 0) { ++out.unmatched; continue; }
      out.rv[best] = { rv: q.rv, err: (q.err !== null && isFinite(q.err)) ? q.err : null };
      out.at[best] = r;
      ++out.matched;
   }
   return out;
}
// (27-oct-2026) RESERVA GAVO. Con el CDS caido (27-oct, ~21:00: TAPVizieR sin respuesta o HTTP 503; SIMBAD y el espejo de CfA,
// tampoco) la Galaxia y la maquina del tiempo se quedaban sin ninguna velocidad radial. GAVO (Heidelberg, CSH_GAVO_TAP) sirve
// gaia.dr3lite, que es Gaia DR3 gaia_source: ra/dec ICRS a la epoca 2016.0 (la MISMA que RA_ICRS/DE_ICRS de I/355/gaiadr3) y
// radial_velocity(_error). Se piden con los nombres de VizieR, asi el lector (c3TmRvRows) y el casado no cambian.
// MEDIDO el 27-oct (Pleyades, 56,75 +24,12, radio 1,5°): GAVO 3 184 filas en 1,5 s; el archivo de ESA (gaiadr3.gaia_source, la misma
// condicion) cuenta 3 184: la tabla de GAVO trae TODAS las RV de DR3 de ese cono.
function c3TmRvAdqlGavo(ra, dec, radiusDeg) {
   return "SELECT g.ra AS \"RA_ICRS\",g.dec AS \"DE_ICRS\",g.radial_velocity AS \"RV\",g.radial_velocity_error AS \"e_RV\" FROM gaia.dr3lite AS g " +
          "WHERE 1=CONTAINS(POINT('ICRS',g.ra,g.dec),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND g.radial_velocity IS NOT NULL";
}
// (28-oct-2026) TERCER SERVIDOR: el archivo de ESA (CSH_ESA_TAP, gaiadr3.gaia_source: la tabla de la que copian VizieR y GAVO), con los
// mismos nombres de columna. MEDIDO el 28-oct con el CDS caido (10:31-10:39; scratchpad rv_compare.py): en 4 conos (Pleyades r 2,6127°
// y 2,6128°, Orion r 2,6135°, Abell 39 r 0,49°) GAVO y ESA dan las MISMAS filas por source_id (9 394, 9 397, 9 872, 192) con |ΔRV| = 0 y
// |Δe_RV| = 0; lo que VizieR contesto antes de caer (cache de Cabra3D, 22 y 27-oct) tiene el mismo numero de filas y las 9 152 + 9 154 +
// 9 541 + 192 RV casadas aparecen en GAVO con el mismo (RV, e_RV) a 0,01 km/s (VizieR redondea a 2 decimales; GAVO y ESA dan float32).
// NGC 1560 r 0,3754°: GAVO 291 = ESA 291 = las 291 de VizieR del 23-oct (c3_gx_real.log). ESA contesto en 0,3-0,7 s.
// (28-oct, tarde) Con grvs_mag y rv_template_teff, que necesita la correccion de Katz/Blomme (abajo, c3TmRvBias). GAVO (gaia.dr3lite) NO las
// tiene (MEDIDO en su TAP_SCHEMA.columns el 28-oct: 27 columnas, ninguna RVS) y los nombres de VizieR no se pudieron comprobar (CDS caido).
function c3TmRvAdqlEsa(ra, dec, radiusDeg) {
   return "SELECT g.ra AS \"RA_ICRS\",g.dec AS \"DE_ICRS\",g.radial_velocity AS \"RV\",g.radial_velocity_error AS \"e_RV\",g.grvs_mag AS \"grvs\",g.rv_template_teff AS \"tteff\" FROM gaiadr3.gaia_source AS g " +
          "WHERE 1=CONTAINS(POINT('ICRS',g.ra,g.dec),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + ")) AND g.radial_velocity IS NOT NULL";
}
// LOS PLAZOS. VizieR, el de quien llama (C3_TM_RV_TIMEOUT_S = 30 s en el panel). GAVO, como mucho C3_TM_RV_GAVO_TIMEOUT_S (20 s): contesta
// en 1-2 s y asi la espera total con los DOS callados es 30 + 20 = 50 s, no 60 (ver c3TmRvRetrySkip: el reintento no repite a un callado).
// (28-oct) ESA, como mucho C3_TM_RV_ESA_TIMEOUT_S (15 s; contesta en < 1 s, pero su «sync» da HTTP 408 si la consulta es pesada —medido el
// 28-oct con un cono denso de LDu 2 y dos JOIN—; la de la RV, un cono sin JOIN, contesto siempre). Los TRES callados: 30 + 20 + 15 = 65 s.
var C3_TM_RV_GAVO_TIMEOUT_S = 20;
var C3_TM_RV_ESA_TIMEOUT_S = 15;
// COSTURAS: C3_TM_RV_BACKUP = false -> solo VizieR, como antes (el ROJO de las pruebas). C3_TM_RV_ESA = false -> sin el tercero (su rojo).
// C3_TM_RV_SERVERS(f) -> otra lista (pruebas).
var C3_TM_RV_BACKUP = true;
var C3_TM_RV_ESA = true;
var C3_TM_RV_SERVERS = null;
// La tabla de la que salio la RV, por servidor (para decirlo en la linea de estado)
var C3_TM_RV_TABLE = { vizier: "I/355/gaiadr3", gavo: "gaia.dr3lite", esa: "gaiadr3.gaia_source" };
function c3TmRvServerList(f) {
   if (typeof C3_TM_RV_SERVERS === "function") { try { var L0 = C3_TM_RV_SERVERS(f); if (L0 && L0.length) return L0; } catch (eS) {} }
   var L = [{ id: "vizier", name: "VizieR (CDS)", what: "I/355/gaiadr3 (RV)", source: "TAPVizieR: I/355/gaiadr3 (RV)",
              url: cpSfTapUrl(CP_SF_VIZIER_TAP, c3TmRvAdql(f.ra, f.dec, f.radiusDeg)) }];
   if (C3_TM_RV_BACKUP !== false && typeof CSH_GAVO_TAP === "string")
      L.push({ id: "gavo", name: "GAVO (Heidelberg)", what: "gaia.dr3lite (RV)", source: "GAVO (Heidelberg): gaia.dr3lite (RV)", timeoutS: C3_TM_RV_GAVO_TIMEOUT_S,
               url: cpSfTapUrl(CSH_GAVO_TAP, c3TmRvAdqlGavo(f.ra, f.dec, f.radiusDeg)) });
   if (C3_TM_RV_BACKUP !== false && C3_TM_RV_ESA !== false && typeof CSH_ESA_TAP === "string")
      L.push({ id: "esa", name: "ESA Gaia archive", what: "gaiadr3.gaia_source (RV)", source: "ESA Gaia archive: gaiadr3.gaia_source (RV)", timeoutS: C3_TM_RV_ESA_TIMEOUT_S,
               url: cpSfTapUrl(CSH_ESA_TAP, c3TmRvAdqlEsa(f.ra, f.dec, f.radiusDeg)) });
   return L;
}
// LA CORRECCION DEL SESGO CON LA MAGNITUD (28-oct-2026, tarde, agente B; decision B5 de Nino). Las radial_velocity de Gaia DR3 NO la llevan.
//   · Katz et al. 2023, A&A 674, A5 (arXiv 2206.05902), §6.1 «Magnitude trend», Ec. 5 (leida en el articulo el 28-oct): para las estrellas
//     con rv_template_teff < 8 500 K, «it is therefore recommended to subtract from Gaia DR3 radial_velocity»
//        grvs_mag < 11:  VRcorr = 0 km/s;   grvs_mag ≥ 11:  VRcorr = 0,02755·grvs_mag² − 0,55863·grvs_mag + 2,81129 km/s
//     (un polinomio de grado 2 ajustado a la mediana Gaia − APOGEE de 129 598 gigantes; ~0,4 km/s en grvs_mag 14, 0 en 11).
//   · Las calientes NO: «For the stars with a template temperature rv_template_teff ≥ 8500 K it is recommended to use the correction derived
//     in Blomme et al. (2022), instead of Eq. 5». Blomme et al. 2023, A&A 674, A7 (arXiv 2206.05486), §4.1 Ec. 1 y §5: para
//     8 500 ≤ rv_template_teff ≤ 14 500 K y 6 ≤ grvs_mag ≤ 12, RVcorrected = radial_velocity − 7,98 + 1,135·grvs_mag (es decir, se resta
//     RVoffset = 7,98 − 1,135·grvs_mag; «individual stars can behave quite differently»). Fuera de esos intervalos, sin correccion.
//   · Sin grvs_mag (MEDIDO: ~1,4 % de las RV de las Pleyades, 133 de 9 394) no hay correccion (la ecuacion es en grvs_mag; no se estima).
// MEDIDO el 28-oct en la ESA: Pleyades r 2,6127°, 8 096 de 9 394 RV con la de Katz, mediana −0,214 km/s, maxima −0,411; 26 calientes con la
// de Blomme (de +5,5 a −1,1 km/s). NGC 1560: 247 de 291, mediana −0,233. (scratchpad katz/count.js)
// DE DONDE SALEN grvs_mag y rv_template_teff: la ESA las trae en la misma consulta (c3TmRvAdqlEsa). Si contesto VizieR o GAVO, se piden a la ESA
// por el MISMO cono (la consulta de la RV de la ESA) y se casan por posicion como la RV; si la ESA no contesta, las RV quedan SIN corregir y
// `corr` lo dice (ok false, why). Las caches de antes del 28-oct guardan RV sin corregir (sin `corr` por estrella).
// COSTURAS: C3_TM_RV_CORR = false -> las RV tal cual del catalogo (como hasta el 28-oct; el ROJO «nokatz»); C3_TM_RV_CORR_HOT = false -> sin
// la de Blomme (el ROJO «noblomme»). Pruebas: tests/c3_node_rv_gavo.js K1-K5, tests/c3_rv_gavo.js G5.
var C3_TM_RV_CORR = true;
var C3_TM_RV_CORR_HOT = true;
var C3_TM_RV_CORR_TIMEOUT_S = 10;
// Lo que hay que RESTAR a radial_velocity (km/s): 0 si no toca, null si falta grvs_mag o rv_template_teff (no se puede decidir).
// (30-oct, decision D de Nino) La receta ya es UNA, la de todos los scripts: cshRvBias, CabraShared/csh_net.js. Aqui queda solo la costura de la de Blomme.
function c3TmRvBias(grvs, tteff) { return cshRvBias(grvs, tteff, C3_TM_RV_CORR_HOT === false); }
// Aplicar la correccion a las RV casadas `out.rv` (en su sitio). `rows`/`at` = las filas de la respuesta y estrella -> fila; `sv` = el servidor.
// -> { on, ok, from, katz, blomme, zero, noMag, noInfo, medKatz, why }   (cada estrella corregida guarda `rvCat`, la del catalogo, y `corr`)
function c3TmRvCorrect(result, out, rows, at, sv, o) {
   var c = { on: C3_TM_RV_CORR !== false, ok: false, from: "", katz: 0, blomme: 0, zero: 0, noMag: 0, noInfo: 0, medKatz: NaN, why: "" }, info = null, idx;
   if (!c.on) { c.why = "off"; return c; }
   if (rows.length && rows[0].grvs !== undefined) { info = {}; for (idx in at) info[idx] = rows[at[idx]]; c.from = sv.id; }
   else {
      if ((typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) || typeof CSH_ESA_TAP !== "string") { c.why = "no ESA"; return c; }
      var f = result.field, sname = "ESA Gaia archive";
      // (30-oct-2026) Medido en Abell 39: 10 s al final de la red de CADA ventana, con la ESA callada, para acabar igual (las RV sin corregir, y `corr` lo dice). Si esta misma consulta se
      // agoto hace menos de 10 min, no se repite la espera (csh_net.js cshHealth*, su propia clave: que la ficha de una estrella cediera a ARI a los 6 s no quita esta correccion).
      if (cshHealthUntil("esa-rvcorr") > 0) { c.why = "ESA did not answer a moment ago"; return c; }
      var r = cpSfHttpText(cpSfTapUrl(CSH_ESA_TAP, c3TmRvAdqlEsa(f.ra, f.dec, f.radiusDeg)), { timeoutS: C3_TM_RV_CORR_TIMEOUT_S, what: "gaiadr3.gaia_source (grvs_mag, rv_template_teff)",
                             onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress("rv", { elapsedMs: ms, server: sname }); } });
      if (!r.ok && (r.cut === true || /curl exit 28/.test(String(r.message || "")))) cshHealthMark("esa-rvcorr", "timeout", 600);
      if (!r.ok || !cpSfLooksLikeCsv(r.text, "RA_ICRS")) { c.why = r.ok ? "bad answer" : (r.message || "no answer"); return c; }
      var sup = c3TmRvRows(r.text), mm = c3TmRvMatch(result.stars, sup);
      info = {}; for (idx in mm.at) info[idx] = sup[mm.at[idx]];
      c.from = "esa";
   }
   var dk = [];
   for (idx in out.rv) {
      var q = info[idx], s = out.rv[idx];
      if (!q) { ++c.noInfo; continue; }
      var b = c3TmRvBias(q.grvs, q.tteff);
      if (b === null) { ++c.noMag; continue; }
      if (b === 0) { ++c.zero; continue; }
      s.rvCat = s.rv; s.rv = s.rv - b; s.corr = (q.tteff >= 8500) ? "blomme" : "katz"; s.grvs = q.grvs; s.tteff = q.tteff;
      if (s.corr === "katz") { ++c.katz; dk.push(-b); } else ++c.blomme;
   }
   if (dk.length) { dk.sort(function(a, b2) { return a - b2; }); c.medKatz = dk[dk.length >> 1]; }
   c.ok = true;
   return c;
}
// Las velocidades radiales del campo: VizieR y, si no da la tabla (sin respuesta, HTTP de error, o algo que no es el CSV), GAVO; y si
// tampoco, ESA (28-oct). Como la cadena del afinado (CabraShared/csh_starfield_run.js cshRefineChain): una tabla buena SIN filas no cede (es la respuesta).
// opts = { httpTimeoutS, onProgress(stage, { elapsedMs, server }), skip: [ids que no se piden] }
// -> { ok, code, why, rows, matched, ms, rv, source, server, serverId, fallback, attempts: [{ id, server, kind, http, ms }], net }
function c3TmFetchRv(result, opts) {
   var o = opts || {}, out = { ok: false, code: "", why: "", rows: 0, matched: 0, ms: 0, rv: {}, source: "", server: "", serverId: "", fallback: false, attempts: [] };
   function no(code) { out.code = code; out.why = cpStarfieldReasonText(code); return out; }
   if (!result || !result.ok || !result.field) return no("no-view");
   var f = result.field, all = c3TmRvServerList(f), skip = o.skip || [], list = [], i, t0 = Date.now(), got = null, gotSv = null, fails = [], nBad = 0;
   for (i = 0; i < all.length; ++i) if (skip.indexOf(all[i].id) < 0) list.push(all[i]);
   out.source = list.length ? list[0].source : "";
   for (i = 0; i < list.length && !got; ++i) {
      var sv = list[i];
      if (typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) break;
      var T = (o.httpTimeoutS > 0) ? o.httpTimeoutS : CP_SF_HTTP_TIMEOUT_S;
      if (sv.timeoutS > 0) T = Math.min(T, sv.timeoutS);
      var r = cpSfHttpText(sv.url, { timeoutS: T, what: sv.what, next: (i + 1 < list.length) ? list[i + 1].name : "",
                                     onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress("rv", { elapsedMs: ms, server: sv.name }); } });
      var att = { id: sv.id, server: sv.name, kind: "", http: (r.code > 0) ? r.code : 0, ms: r.ms };
      out.attempts.push(att);
      if (!r.ok) {
         var n = r.net || cshNetFail(sv.url, r, r.cut === true); n.server = sv.name;
         att.kind = n.kind; fails.push(n); if (n.kind === "bad") ++nBad;
         if (r.aborted) break;
         continue;
      }
      if (!cpSfLooksLikeCsv(r.text, "RA_ICRS")) {
         var nb = cshNetFail(sv.url, { code: r.code }, false); nb.kind = "bad"; nb.server = sv.name;
         att.kind = "bad"; fails.push(nb); ++nBad;
         try { console.warningln(cshConsoleEsc("CabraShared: " + sv.name + " answered something that is not the table - " + sv.what + ((i + 1 < list.length) ? "; trying " + list[i + 1].name + "..." : ""))); } catch (eW) {}
         continue;
      }
      att.kind = "ok"; got = r; gotSv = sv;
   }
   out.ms = Date.now() - t0;
   if (!got) {
      no((fails.length > 0 && nBad === fails.length) ? "bad-answer" : "no-network");
      out.net = fails.length ? fails[0] : null;
      var seen = {}, said = [];
      for (i = 0; i < fails.length; ++i) { var tx = cshNetText(fails[i]); if (!seen[tx]) { seen[tx] = true; said.push(tx); } }
      if (said.length) out.why = said.join(" ");
      return out;
   }
   out.source = gotSv.source; out.server = gotSv.name; out.serverId = gotSv.id; out.fallback = (gotSv.id !== "vizier");
   var rows = c3TmRvRows(got.text);
   out.rows = rows.length;
   if (rows.length === 0) { out.ok = true; out.code = "no-rv"; return out; }      // (un campo sin ninguna: no es un fallo)
   var m = c3TmRvMatch(result.stars, rows);
   out.rv = m.rv; out.matched = m.matched;
   // (28-oct, tarde) el sesgo con la magnitud (Katz+2023 / Blomme+2023): ver c3TmRvCorrect
   if (m.matched > 0) out.corr = c3TmRvCorrect(result, out, rows, m.at, gotSv, o);
   out.ok = true;
   return out;
}
// EL REINTENTO del panel (tm/timemachine_video.js): no repite al servidor que se quedo CALLADO hasta su plazo (eso solo doblaria la
// espera: 30 s mas por VizieR); si repite al que fallo deprisa (un 503, sin conexion, una respuesta que no es la tabla). Devuelve la
// lista de ids a saltar, o null si no queda ninguno que reintentar.
function c3TmRvRetrySkip(out) {
   var skip = [], left = 0, att = (out && out.attempts) ? out.attempts : [];
   for (var i = 0; i < att.length; ++i) { if (att[i].kind === "timeout") skip.push(att[i].id); else ++left; }
   return (att.length === 0 || left > 0) ? skip : null;
}

// BLOQUE F (20-oct): EL MOVIMIENTO DE LO QUE NO ES UNA ESTRELLA en SIMBAD. Una consulta TAP por cono (la del campo) a `basic`:
// el movimiento propio (pmra, pmdec, pm_err_maj/min, pm_bibcode) y la velocidad radial (rvz_radvel, rvz_err, rvz_type,
// rvz_bibcode) de los objetos de NUESTRA galaxia —nebulosas (ISM), cumulos (Cl*), asociaciones (As*), planetarias— que tengan
// alguno de los dos. (La consulta de lo lejano de CabraShared no los trae: ver el informe del bloque F.) Se casan por NOMBRE
// (main_id con los espacios juntados, como los guarda el motor). Devuelve { ok, code, why, rows, ms, byName: { nombre: fila } },
// fila = { name, ra, dec, otype, pmRa, pmDec, pmErr, pmRef, rv, rvErr, rvRef }.
function c3TmKinAdql(ra, dec, radiusDeg) {
   return "SELECT b.main_id,b.ra,b.dec,b.otype,b.pmra,b.pmdec,b.pm_err_maj,b.pm_err_min,b.pm_bibcode,b.rvz_radvel,b.rvz_err,b.rvz_type,b.rvz_bibcode " +
          "FROM basic AS b JOIN otypedef AS t ON t.otype=b.otype " +
          "WHERE CONTAINS(POINT('ICRS',b.ra,b.dec),CIRCLE('ICRS'," + ra.toFixed(6) + "," + dec.toFixed(6) + "," + radiusDeg.toFixed(5) + "))=1 " +
          "AND (b.pmra IS NOT NULL OR b.rvz_radvel IS NOT NULL) " +
          "AND (t.path LIKE 'ISM%' OR t.path LIKE 'Cl*%' OR t.path LIKE 'As*%' OR t.path LIKE 'PoC%' OR b.otype IN ('PN','PN?'))";
}
function c3TmKinName(s) { return String(s || "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, ""); }
function c3TmKinRows(csvText) {
   var t = cpSfParseTable(csvText, ","), out = { rows: 0, byName: {} };
   for (var i = 0; i < t.rows.length; ++i) {
      var r = t.rows[i], nm = c3TmKinName(r.main_id), pa = cpSfNum(r.pmra), pd = cpSfNum(r.pmdec), ea = cpSfNum(r.pm_err_maj), eb = cpSfNum(r.pm_err_min), rv = cpSfNum(r.rvz_radvel);
      if (nm.length === 0) continue;
      // (una velocidad radial de mas de 1 000 km/s no es de un objeto de la Galaxia: un corrimiento mal tipado)
      if (rv !== null && Math.abs(rv) > 1000) rv = null;
      if ((pa === null || pd === null) && rv === null) continue;
      out.byName[nm] = { name: nm, ra: cpSfNum(r.ra), dec: cpSfNum(r.dec), otype: String(r.otype || ""),
                         pmRa: (pa !== null && pd !== null) ? pa : null, pmDec: (pa !== null && pd !== null) ? pd : null,
                         pmErr: (ea !== null || eb !== null) ? Math.max(ea || 0, eb || 0) : null, pmRef: String(r.pm_bibcode || ""),
                         rv: rv, rvErr: cpSfNum(r.rvz_err), rvRef: String(r.rvz_bibcode || "") };
      ++out.rows;
   }
   return out;
}
// (28-oct-2026, tarde) LA RESERVA DE SIMBAD es UNA sola, la de CabraShared: `cshSimbadGet` (csh_net.js; el espejo oficial de Harvard,
// plazos, memoria del CDS caido, costura roja CSH_SIMBAD_BACKUP). Aqui vivia una copia (c3SimbadGet, C3_SIMBAD_CDS/MIRROR/
// MIRROR_TIMEOUT_S/BACKUP): se quito para no tener dos. La medida de equivalencia CDS ↔ espejo (28-oct, 11:01: 31 objetos de cinematica
// y 13 nombres iguales campo a campo a lo que dio el CDS el 22-27-oct) esta en Cabra3D/docs/informe_28oct_agenteB.md.
function c3TmFetchKin(result, opts) {
   var o = opts || {}, out = { ok: false, code: "", why: "", rows: 0, ms: 0, byName: {}, source: "SIMBAD TAP: basic (pmra, pmdec, rvz_radvel)", server: "", fallback: false, attempts: [] };
   function no(code) { out.code = code; out.why = cpStarfieldReasonText(code); return out; }
   if (!result || !result.ok || !result.field) return no("no-view");
   var f = result.field, t0 = Date.now();
   var g = cshSimbadGet(cpSfTapUrl(CP_SF_SIMBAD_TAP, c3TmKinAdql(f.ra, f.dec, f.radiusDeg)), { timeoutS: o.httpTimeoutS, what: "basic (motions)", onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress("kin", { elapsedMs: ms }); } },
                       function(t) { return cpSfLooksLikeCsv(t, "main_id"); });
   var r = g.r;
   out.ms = Date.now() - t0; out.server = g.server; out.fallback = g.fallback; out.attempts = g.attempts;
   if (!g.ok) return no((r && r.ok) ? "bad-answer" : "no-network");
   if (g.fallback) out.source = "SIMBAD TAP (Harvard mirror): basic (pmra, pmdec, rvz_radvel)";
   var k = c3TmKinRows(r.text);
   out.rows = k.rows; out.byName = k.byName; out.ok = true;
   return out;
}

// LA PROYECCION del campo, ajustada a su solucion (null si no se puede).
function c3TmTanOf(result) {
   if (!result || !result.field || typeof result._unproject !== "function") return null;
   var f = result.field, pts = [], N = 9;
   for (var j = 0; j < N; ++j) for (var i = 0; i < N; ++i) {
      var x = f.width * (i + 0.5) / N, y = f.height * (j + 0.5) / N, q = result._unproject(x, y);
      if (q !== null) pts.push({ ra: q.ra, dec: q.dec, x: x, y: y });
   }
   if (pts.length < 6) return null;
   var fit = c3TmTanFit(f.ra, f.dec, pts);
   return (pts.length === N * N) ? c3TmTanGrid(fit, pts, N, f.width, f.height) : fit;
}
