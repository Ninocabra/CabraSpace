// ============================================================================
// tm/timemachine_video.js — LA MAQUINA DEL TIEMPO: la red (velocidades radiales) y el VIDEO (Cabra3D, 14-oct-2026)
// ----------------------------------------------------------------------------
// LA RED: un paso mas de la cola del panel (`_netPending` / `_netStep`, la misma que
// usa «Distances» para VizieR y SIMBAD: sin bloquear, con señal de vida, tope de
// tiempo, y si falla lo local sigue y se dice). Pide las velocidades radiales de Gaia
// DR3 del campo (tm/timemachine_run.js).
// EL VIDEO: se graba con la MISMA maquinaria que el vuelo (ui/starfield_flight_ui.js:
// el tic, la barra de progreso dentro del lienzo, «Cancel» que pregunta, AVI o MP4 con
// ffmpeg, la carpeta y el tamaño de las opciones «▾» del vuelo): solo cambia QUE se
// pinta en cada fotograma. Tres clases: «Photo + 3D» (la foto llena el fotograma y el 3D va en un recuadro en una esquina de arriba; AY-5, 2-nov-2026: antes
// decia «lado a lado»), «3D», «Photo».
// EL GUION (VIDEO_S = 16 s): 0-1,5 s la foto de hoy con el titulo; 1,5-6 s rebobina hasta
// −escala; 6-7 s se para; 7-12,5 s avanza hasta +escala; 12,5-14,5 s se para; 14,5-16 s
// funde. En 3D la camara gira despacio 25° en todo el video.
// ES5 (metodos de CPStarfieldDock y una funcion de grabar).
// ============================================================================

var C3_TM_RV_TIMEOUT_S = 30;
var C3_TMV = { S: 16, HOLD0: 1.5, BACK: 6, HOLD1: 7, FWD: 12.5, HOLD2: 14.5, YAW: 25, TITLE_S: 2.6 };
// DEFECTOS INYECTADOS para ver en ROJO las pruebas del vídeo de la galaxia (tests/c3_gx_review.js): «gxplate» = el contador del grabador
// encima del mapa, como antes (sin la placa dentro del mapa); «platetr» = ese contador arriba a la derecha (donde lo vio el revisor); «pipcap» =
// sin reservar el rótulo del recuadro
var C3_TMV_BREAK = "";
function c3TmVideoBroken(k) { return (typeof C3_TMV_BREAK === "string") && C3_TMV_BREAK.length > 0 && C3_TMV_BREAK.indexOf(k) >= 0; }

// ---------------------------------------------------------------------------
// LA RED: las velocidades radiales, detras de lo de siempre
// ---------------------------------------------------------------------------
var c3BaseNetPending = CPStarfieldDock.prototype._netPending;
CPStarfieldDock.prototype._netPending = function() {
   var s = c3BaseNetPending.call(this);
   if (s !== "") return s;
   var st = this.state;
   if (st && this.mode === "dist" && (st.net.rv === undefined || st.net.rv === "")) return "rv";
   return "";
};
var c3BaseNetStep = CPStarfieldDock.prototype._netStep;
CPStarfieldDock.prototype._netStep = function() {
   if (this._closed || this._netBusy) return "";
   if (this._netPending() !== "rv") return c3BaseNetStep.call(this);
   this._animStop();
   var st = this.state, self = this, label = optT("Asking VizieR for the radial velocities (Gaia DR3)…"), out = null;
   this._netBusy = true;
   st.net.rv = "running";
   this._say(label, "info");
   try {
      // (30 s y no los 15 del panel: en el campo de las Pleyades —2,6° de radio, 9 400 filas— VizieR no llego a tiempo dos veces de tres)
      // (27-oct: VizieR y, si no contesta, GAVO —tm/timemachine_run.js—; la linea dice a quien se esta preguntando)
      var prog = function(stage, info) {
         if (self._closed) return;
         var who = (info && info.server && !/^VizieR/.test(info.server)) ? " · " + info.server : "";
         self._say(label + who + " " + Math.round(((info && info.elapsedMs) || 0) / 1000) + " s", "info");
         try { optProcessEvents(); } catch (eP) {}
      };
      out = c3TmFetchRv(st.result, { httpTimeoutS: C3_TM_RV_TIMEOUT_S, onProgress: prog });
      // (a, revision del coordinador: una consulta caida dejaba TODAS las estrellas huecas en una captura) un reintento, y si no, la cache.
      // (27-oct) El reintento no repite al servidor que se quedo callado hasta su plazo (c3TmRvRetrySkip): con VizieR y GAVO callados la
      // espera es 30 + 20 s y no se dobla. Los intentos de las dos pasadas quedan juntos (la linea de estado dice quien fallo y como).
      var skip = (!out || !out.ok) ? c3TmRvRetrySkip(out) : null;
      if ((!out || !out.ok) && skip !== null) {
         self._say(label + " " + optT("(retrying)"), "info");
         var first = out;
         out = c3TmFetchRv(st.result, { httpTimeoutS: C3_TM_RV_TIMEOUT_S, skip: skip, onProgress: prog });
         if (first && first.attempts && out && out.attempts) { out.attempts = first.attempts.concat(out.attempts); out.ms += first.ms || 0; }
      }
      var ckey = "rv_" + st.result.field.ra.toFixed(4) + "_" + st.result.field.dec.toFixed(4) + "_" + st.result.field.radiusDeg.toFixed(4) + ".json";
      if (out && out.ok) c3CacheWrite(ckey, { rv: out.rv, rows: out.rows, matched: out.matched, source: out.source, server: out.server, serverId: out.serverId, corr: out.corr || null, when: (new Date()).toISOString() });
      else {
         var cc = c3CacheRead(ckey), failed = out;
         if (cc && cc.rv) out = { ok: true, code: "", rv: cc.rv, rows: cc.rows, matched: cc.matched, cached: true, when: cc.when, corr: cc.corr || null,
                                  source: cc.source || "TAPVizieR: I/355/gaiadr3 (RV)", server: cc.server || "VizieR (CDS)", serverId: cc.serverId || "vizier",
                                  attempts: (failed && failed.attempts) ? failed.attempts : [] };
      }
   } catch (e) { out = { ok: false, code: "no-network", why: String(e.message || e) }; }
   finally { this._netBusy = false; }
   st.tmRvAttempts = (out && out.attempts) ? out.attempts : null;     // (27-oct: tm/netstatus.js dice con ellos quien fallo y quien dio la RV)
   st.net.rv = (out && out.ok) ? "ok" : ("failed:" + ((out && out.code) || "no-network"));
   if (out && out.ok) { st.tmRv = out; st.tmd = null; }
   if (this._closed) return "rv";
   if (this.state === st && this.mode !== "") { this._syncButtons(); this._render(); this._sayState(); try { this.dialog.preview.viewport.repaint(); } catch (eR) {} }
   this._netArm();
   return "rv";
};
// (la linea de estado de la RV —y de toda la red— la compone tm/netstatus.js: `_c3NetLine`)
var c3BaseRetranslate = CPStarfieldDock.prototype.retranslate;
CPStarfieldDock.prototype.retranslate = function() {
   c3BaseRetranslate.call(this); try { this._tmRetranslate(); } catch (e) {}
   // (tarea H7, 21-oct: «Dust» y «✦ Sky from the star» se quedaban en ingles al pasar a castellano)
   try { if (this.dustBtn) this.dustBtn.text = optT("Dust"); if (this.skyBtn) this.skyBtn.text = "✦ " + optT("Sky from the star"); } catch (e2) {}
};

// LA LINEA DE ESTADO AL CAMBIAR DE ESTADO (tarea H7, 21-oct-2026). Se quedaban mensajes viejos: «Galactic orbits… MWPotential2014»
// durante el vuelo al cielo de una estrella, «Removing the stars of the nebula with StarXTerminator…» despues de quitarlas, el aviso
// del tiempo en ingles tras pasar a castellano. `_c3SayCurrent` dice lo que toca AHORA: el cielo si se esta en el, si no el estado del
// 3D y, con la maquina del tiempo lejos de «ahora», su aviso de validez (otra vez, en el idioma de ahora).
CPStarfieldDock.prototype._c3SayCurrent = function() {
   if (!this.state || this._closed) return;
   if (this.sky && this.sky.phase && this.sky.phase !== "off") { this._say(optT("Sky from the star: the whole sky as seen from there (Esc or «BACK» to return)."), "info"); return; }
   this._sayState();
   if (this.tm) { this.tm.saidSig = null; this.tm.saidWarn = false; if (this.tm.t !== 0) try { this._tmSayValidity(); } catch (e) {} }
};
var c3BaseSkyFromStar = CPStarfieldDock.prototype.skyFromStar, c3BaseSkyFromHip = CPStarfieldDock.prototype.skyFromHip, c3BaseSkyEnd = CPStarfieldDock.prototype._skyEnd;
if (c3BaseSkyFromStar) CPStarfieldDock.prototype.skyFromStar = function(idx) { var r = c3BaseSkyFromStar.apply(this, arguments); if (r && r.ok) try { this._c3SayCurrent(); } catch (e) {} return r; };
if (c3BaseSkyFromHip) CPStarfieldDock.prototype.skyFromHip = function(hip, view) { var r = c3BaseSkyFromHip.apply(this, arguments); if (r && r.ok) try { this._c3SayCurrent(); } catch (e) {} return r; };
if (c3BaseSkyEnd) CPStarfieldDock.prototype._skyEnd = function() { var r = c3BaseSkyEnd.apply(this, arguments); try { this._c3SayCurrent(); } catch (e) {} return r; };

// ---------------------------------------------------------------------------
// EL GUION: el instante del fotograma de `s` segundos (R = la escala)
// ---------------------------------------------------------------------------
function c3TmVideoTime(s, R) {
   var V = C3_TMV;
   function ease(a, b, x) { var u = Math.max(0, Math.min(1, (x - a) / (b - a))); return u * u * (3 - 2 * u); }
   if (s < V.HOLD0) return 0;
   if (s < V.BACK) return -R * ease(V.HOLD0, V.BACK, s);
   if (s < V.HOLD1) return -R;
   if (s < V.FWD) return -R + 2 * R * ease(V.HOLD1, V.FWD, s);
   return R;
}

// ---------------------------------------------------------------------------
// UN FOTOGRAMA de la FOTO en el tiempo, en `g` dentro de `R` (la foto encajada, apagada como en el visor, y las estrellas)
// ---------------------------------------------------------------------------
// `lg` (opcional, el polvo): { side: "left" | "right" (la esquina de arriba de la foto), y (si se da: su borde de arriba —bajo el recuadro 3D,
// en su MISMA esquina: tarea H2, 21-oct—), maxW (su ancho maximo) }
CPStarfieldDock.prototype._tmPaintPhotoFrame = function(g, R, sc, lg) {
   var st = this.state, ph = st.photoFull || st.photo, f = st.result.field;
   g.fillRect(new Rect(R.x, R.y, R.x + R.w, R.y + R.h), new Brush(cpInt(CP_FLP_BLACK)));
   if (!ph) return;
   var k = Math.min(R.w / f.width, R.h / f.height), w = f.width * k, h = f.height * k, x0 = R.x + (R.w - w) / 2, y0 = R.y + (R.h - h) / 2;
   g.clipRect = new Rect(R.x, R.y, R.x + R.w, R.y + R.h);
   g.smoothInterpolation = true;
   g.drawScaledBitmap(new Rect(x0, y0, x0 + w, y0 + h), ph);
   // (lejos de «ahora», la foto SIN estrellas: las estrellas son las que se mueven; y un poco apagada)
   var mix = this.tmPhotoMix(), sl = (mix > 0.004) ? (st.tmStarless || null) : null;
   if (sl) { g.opacity = mix; g.drawScaledBitmap(new Rect(x0, y0, x0 + w, y0 + h), sl); g.opacity = 1; }
   var dim = this.tmPhotoDim();
   if (dim < 0.999) g.fillRect(new Rect(x0, y0, x0 + w, y0 + h), new Brush(cpInt(CP_FLP_BLACK, 1 - dim)));
   // (con el polvo encendido, la misma rejilla teñida que en el visor; su leyenda, al final, encima de las estrellas)
   var dustOn = !!(this.dust && this.dust.on && st.dust && st.dust.ok);
   if (dustOn) this._dustTint(g, function(x, y) { return { x: x0 + x * k, y: y0 + y * k }; });
   g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.6), Math.max(1, sc)); g.brush = new Brush(0x00000000);
   g.drawRect(x0, y0, x0 + w, y0 + h);
   // (MIRADO en el video de las Pleyades: las que salen del encuadre se pintaban en el margen negro; la foto es la foto, se recorta a ella)
   g.clipRect = new Rect(Math.max(R.x, x0), Math.max(R.y, y0), Math.min(R.x + R.w, x0 + w), Math.min(R.y + R.h, y0 + h));
   this._tmPaintStarsOn(g, function(x, y) { return { x: x0 + x * k, y: y0 + y * k }; }, sc, k, R);
   g.clipRect = new Rect(R.x, R.y, R.x + R.w, R.y + R.h);
   // LA LEYENDA del polvo: la misma tira que en el visor, arriba de la foto, en la esquina que el recuadro 3D deja libre (nunca debajo de el)
   if (dustOn) {
      // (tarea H2, 21-oct: UNA sola leyenda en el video —la de lo que se ve en la foto—, mas pequeña: 0,8 de la escala del cuadro, y como
      // mucho un tercio del ancho o el del recuadro 3D)
      var sL = 0.8 * sc, spec = this._dustSpec("column"), mg = Math.round(10 * sc), maxW = (lg && lg.maxW > 0) ? lg.maxW : Math.round(w / 3), M = c3DustLegLayout(spec, sL, Math.max(Math.round(160 * sL), Math.min(w - 2 * mg, maxW)));
      var lx = (lg && typeof lg.xl === "number") ? ((lg.side === "right") ? lg.xr - M.w : lg.xl) : (lg && lg.side === "right") ? x0 + w - mg - M.w : x0 + mg;
      return c3DustLegPaint(g, Math.round(lx), Math.round((lg && lg.y >= 0) ? lg.y : y0 + mg), M, spec);
   }
   return null;
};

// Lo «ocupado» de un rectangulo de un fotograma: la luz media de una rejilla de 32 × 12 muestras (para elegir donde va un rotulo; tarea H2)
function c3TmVideoBusy(bmp, r) {
   var s = 0, n = 0, br = 0, i, j;
   for (j = 0; j < 24; ++j) for (i = 0; i < 64; ++i) {
      var x = Math.round(r.x + (i + 0.5) * r.w / 64), y = Math.round(r.y + (j + 0.5) * r.h / 24);
      if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) continue;
      var c = bmp.pixel(x, y), l = ((c >> 16) & 255) + ((c >> 8) & 255) + (c & 255);
      s += l; ++n; if (l > 330) ++br;
   }
   // (la luz media mas, con peso, la parte de pixeles CLAROS: un rotulo o una galaxia son pocos pixeles pero no se pueden tapar)
   return n ? s / n + 600 * br / n : 0;
}

// ---------------------------------------------------------------------------
// GRABAR: un grabador con la forma del de un vuelo (`cpFlRecorder`: step, cancel, finishNow, result, n, k, plan, format),
// para que la maquinaria de la fila del vuelo lo lleve tal cual.
//   opts = { path, width, height, fps, kind ("both" | "3d" | "photo"), title, format ("avi" para no usar ffmpeg), mp4, seconds }
// ---------------------------------------------------------------------------
function c3TmRecorder(dock, opts) {
   var o = opts || {}, w = Math.round(o.width || 1920), h = Math.round(o.height || 1080), fps = (o.fps === 60) ? 60 : 30, S = (o.seconds > 0) ? o.seconds : C3_TMV.S;
   var n = Math.max(2, Math.round(S * fps)), kind = (C3_TMUI.VIDEO_KINDS.indexOf(o.kind) >= 0) ? o.kind : "both", R = { ok: false, why: "", n: n, k: 0, done: true, plan: { fps: fps, n: n }, result: null,
             step: function() { return false; }, cancel: function() {}, finishNow: function() {}, kind: kind };
   var st = dock.state, tm = dock.tm;
   if (!st || !tm || !dock._tmReady()) { R.why = dock._tmWhyNot() || "nothing to record"; return R; }
   if ((w % 2) || (h % 2) || w < 16 || h < 16) { R.why = "bad frame size"; return R; }
   // (23-oct-2026) LA VISTA GALACTICA (tm/galaxy_view.js, solo Cabra3D: CabraStarAnalysis no tiene `_gxVideoOn`): con ella puesta, lo que
   // se graba como «3D» es el MAPA de la Galaxia en su version elegida (arriba, de canto, 3D girando), con la maquina del tiempo corriendo
   var gxv = (typeof dock._gxVideoOn === "function") && dock._gxVideoOn(), gxB = null;
   if (kind !== "3d") dock.tmStarless();
   // (23-oct, noche; revisión visual) con «Órbitas galácticas» —siempre con la galaxia—, la tabla de órbitas de la escala ANTES de grabar: el
   // grabador pone tm.t a mano (no pasa por tmSetTime) y sin la tabla la foto iría por los epiciclos
   if (kind !== "3d" && tm.motion === "galactic" && typeof dock._tmEnsureOrbit === "function") { try { dock._tmEnsureOrbit(); } catch (eO) {} }
   var range = tm.range, saveT = tm.t, base = dock._tmBaseModel(), scale = c3BaseDistScale(dock.scaleMode, base, dock.unit), title = String(o.title || st.title);
   // («Photo + 3D», revision del coordinador: la foto a media altura desperdiciaba el cuadro. Ahora la FOTO llena el cuadro y el 3D va
   // en un recuadro en una esquina de arriba, con su filete de oro: abajo quedan el titulo y el contador)
   // (tarea H2, 21-oct: el recuadro —40 % del ancho—, su rotulo debajo y dos leyendas tapaban mas de un tercio de la foto. Ahora un 30 %
   // del ancho, su rotulo DENTRO y la UNICA leyenda del polvo —la del tinte de la foto— debajo de el, en su misma esquina)
   var pip = (kind === "both"), w3 = pip ? Math.round(w * 0.30) : w, h3 = pip ? Math.round(w3 * 9 / 16) : h, P3 = null;
   w3 -= (w3 % 2); h3 -= (h3 % 2);
   // LA ESCALA DEL POLVO (20-oct): con el polvo encendido, UNA tira por video (tarea H2): con la foto, la de su tinte (la pinta
   // `_tmPaintPhotoFrame`); en «3D» solo, la de la densidad de las capas, en una banda ARRIBA (el 3D se encaja debajo: nada bajo la tira)
   var dustOn = !!(dock.dust && dock.dust.on && st.dust && st.dust.ok), scV = Math.min(w, h) / CP_FLP.REF_H, legD = null, legBand = 0;
   if (dustOn && kind === "3d" && !gxv) { var specD = dock._dustSpec("density"), mD = c3DustLegLayout(specD, 0.8 * scV, Math.round(w * 0.4)); legD = { spec: specD, M: mD }; legBand = mD.h + 2 * Math.round(6 * scV); }
   if (legBand % 2) ++legBand;
   if (kind !== "photo" && gxv) gxB = new Bitmap(w3, h3);
   if (kind !== "photo" && !gxv) { P3 = cpFlPaintOpen(dock, w3, h3, { title: title, hiRes: true, rect: (legBand > 0) ? { x: 0, y: legBand, w: w3, h: h3 - legBand } : undefined }); if (P3 === null) { R.why = "nothing to record"; return R; } P3.scale = scale; }
   var out = new Bitmap(w, h), sc = Math.min(w, h) / CP_FLP.REF_H, t0 = Date.now(), paintMs = 0;
   var ff = st.result.field, kf = Math.min(w / ff.width, h / ff.height), phL = (w - ff.width * kf) / 2, phR = (w + ff.width * kf) / 2, phT = (h - ff.height * kf) / 2;
   var capsSp = cpCapsSpacing(CP_FLP.T_CAPS * h), capsSpS = cpCapsSpacing(0.7 * CP_FLP.T_CAPS * h), pipLeft = false, cntTop = null, titleSide = null;
   if (pip) {
      // (la esquina de arriba con menos estrellas bajo el recuadro y su leyenda; los miembros de cumulo pesan diez —tarea H2: antes solo contaban
      // los miembros—)
      var cR = 0, cL = 0, qx0 = phR - w3 - Math.round(h * 0.03), qx1 = phL + Math.round(h * 0.03) + w3, qy1 = phT + Math.round(h * 0.03) + h3 + Math.round(0.08 * h);
      for (var mI = 0; mI < st.result.stars.length; ++mI) {
         var sm = st.result.stars[mI];
         if (typeof sm.x !== "number") continue;
         var X = phL + sm.x * kf, Y = phT + sm.y * kf, wq = (sm.cluster >= 0) ? 10 : 1;
         if (Y > qy1) continue;
         if (X >= qx0) cR += wq; else if (X <= qx1) cL += wq;
      }
      pipLeft = (cL < cR);
   }
   var cam0 = cpFlCam({ yaw: dock.yaw, pitch: dock.pitch, zoom: dock.distZoom, ox: dock.distOx, oy: dock.distOy, oz: dock.distOz, flat: 1, lens: 1 });
   var mp4 = (o.format !== "avi") && cpAviFfmpeg().available, baseP = String(o.path).split("\\").join("/").replace(/\.(avi|mp4)$/i, "");
   var outPath = baseP + (mp4 ? ".mp4" : ".avi"), aviPath = mp4 ? File.systemTempDirectory.split("\\").join("/") + "/c3_tm_" + Date.now() + ".avi" : outPath;
   var quality = mp4 ? CP_AVI.MP4_SOURCE_QUALITY : 92, W = null;
   R.format = mp4 ? "mp4" : "avi";
   try { W = cpAviOpen(aviPath, w, h, fps, {}); } catch (e) { cpFlPaintClose(P3); if (gxB !== null) { try { gxB.clear(); } catch (eG) {} } R.why = String(e); return R; }
   var F = { caps: cpFont("text", CP_FLP.T_CAPS * h, true, false, cpCapsSpacing(CP_FLP.T_CAPS * h)), title: cpFont("text", CP_FLP.T_TITLE * h), count: cpFont("text", CP_FLP.T_COUNT * h),
             body: cpFont("text", CP_FLP.T_SUB * h), capsS: cpFont("text", 0.7 * CP_FLP.T_CAPS * h, true, false, capsSpS), countS: cpFont("text", 0.78 * CP_FLP.T_COUNT * h), countP: cpFont("text", 0.55 * CP_FLP.T_COUNT * h) };
   // (el recuadro 3D, si lo hay: su esquina)
   var mgP = Math.round(h * 0.03), pyP = Math.round(phT + mgP), pxP = pip ? ((pipLeft === true) ? Math.round(Math.max(mgP, phL + mgP)) : Math.round(Math.min(w - w3 - mgP, phR - w3 - mgP))) : 0;
   // EL RÓTULO DEL RECUADRO («THE SAME STARS…»), medido una vez: si no cabe, la letra mengua hasta caber (V13, segunda ronda). Su caja, en
   // coordenadas del recuadro, la reserva el mapa de la Galaxia (23-oct, noche: el rótulo de la elegida lo pisaba)
   var capT = gxv ? optT("THE SAME STARS IN THE MILKY WAY") : optT("THE SAME STARS, AT THEIR DISTANCE (3D)"), cpd = Math.round(5 * sc), capFS = F.capsS, capSp = capsSpS, capW = 0, kS = 0.7;
   for (var tries = 0; tries < 6; ++tries) {
      capW = capFS.width(capT) + Math.max(0, capT.length - 1) * capSp;
      if (capW + 2 * cpd <= w3 - 4) break;
      kS *= 0.88; capSp = cpCapsSpacing(kS * CP_FLP.T_CAPS * h); capFS = cpFont("text", kS * CP_FLP.T_CAPS * h, true, false, capSp);
   }
   var capH = capFS.ascent + capFS.descent, pipCapBox = c3TmVideoBroken("pipcap") ? { w: 0, h: 0 } : { w: Math.min(w3 - 2, capW + 2 * cpd) + 3, h: capH + 2 * cpd + 3 };
   R.pip = pip ? { x: pxP, y: pyP, w: w3, h: h3, cap: { w: Math.min(w3 - 2, capW + 2 * cpd) + 3, h: capH + 2 * cpd + 3 } } : null;
   // EL 3D del campo en el instante del guion `s` (con tm.t ya puesto): lo pinta el fotograma y, para elegir donde va el reloj, la medida de la esquina
   function scene3(s) {
      P3.model = dock._distModel();
      // (MIRADO: con la camara del panel en medio cuadro vertical, la caja se salia por la izquierda. La caja ENTERA en el cuadro,
      // con la pose del panel girando despacio: el encaje de esa pose en ESE rectangulo, como camara del vuelo)
      var yaw = cam0.yaw + C3_TMV.YAW * (s / C3_TMV.S - 0.5), RR = P3.rect, fr0 = cpSvDistFrame(P3.model, RR, yaw, cam0.pitch);
      var cam = cpFlCamFromView({ yaw: yaw, pitch: cam0.pitch, zoom: 1, ox: 0, oy: 0, oz: 0, flat: 1, f0: fr0.f0 * 0.94, cx: fr0.cx, cy: fr0.cy }, P3.model, RR);
      var fr = { t: s, cam: cam, prevCam: cam, layers: { photo: 1, box: 1, objects: 1 }, fx: { fade: 0, vignette: 0.35, trail: 0, glow: 0, title: 0, counter: { alpha: 0, pc: 0 }, plate: null } };
      return cpFlPaintFrame(P3, fr);
   }
   // EL RELOJ ANALOGICO (fase 2, 25-oct; tm/timeclock.js): sustituye a la cifra grande del contador, que pasa a ser su cifra exacta pequeña. El
   // radio y la caja (la esfera con su cifra debajo) se miden UNA vez con la cifra mas ancha de la escala; DONDE va se decide UNA vez (clkPos).
   var clkOn = c3ClkOn(), clkR = 0, clkM = null, clkPos = null, clkRows = 0, clkWide = "";
   // (la letra de las filas bajo la esfera: la del rotulo pequeño pero por el lado CORTO del fotograma —en 9:16 la de por el alto era el doble y partia «año 38 585 a. C.» en tres renglones—)
   // (26-oct, Nino: «reduce la descripción debajo»: al C3_CLK.TXT_K de antes)
   var txK = c3ClkBroken("bigclock") ? 1 : C3_CLK.TXT_K, kminC = Math.min(w, h), spCk = Math.round(0.5 * cpCapsSpacing(txK * 0.7 * CP_FLP.T_CAPS * kminC)), FCk = cpFont("text", txK * 0.7 * CP_FLP.T_CAPS * kminC, true, false, spCk);
   if (clkOn) {
      var pdC = Math.round(h * CP_FLP.MARGIN / 4);
      clkR = c3ClkRadius(w, h, pip ? (w3 - 2 * pdC) : 0);
      var tA = c3TmTimeText(-range), tB = c3TmTimeText(-0.8888 * range), tC = c3TmTimeText(0.9 * range);
      clkWide = (tB.length > tA.length) ? tB : tA; if (tC.length > clkWide.length) clkWide = tC;
      clkM = c3ClkMeasure(range, clkR, clkWide, true);
   }
   // las filas de texto bajo la esfera en el instante T: la linea de modelo (muted) y el aviso de validez (ambar), partidas al ancho `maxW`
   function clkTextRows(T, FKf, FKsp, maxW, gxOnly) {
      var st0 = dock.state, cy0 = c3TmCalendarYear(st0, T), mod0 = (gxOnly ? optT("orbits in the Milky Way (MilkyWayPotential2022)") : (tm.motion === "galactic") ? optT("Galactic orbits") : optT("straight lines"));
      var lv0 = c3TmValidity(T, gxOnly ? "galactic" : dock._tmModelName()), rows0 = [], wr0 = [], FW = { caps: FKf, small: FKf, big: FKf, plain: FKf, sp: FKsp };
      // (la linea del modelo: «año 38 585 a. C. · rectas» en UNA linea si cabe; si no, el año y el modelo en dos, cada uno partido al ancho: antes se partia por el «·» y lo dejaba colgando)
      var one = cy0.length ? cy0 + "  ·  " + mod0 : mod0, parts = (c3HudWidth(FW, "caps", one) <= maxW) ? [one] : (cy0.length ? [cy0, mod0] : [mod0]), pw0;
      for (var q2 = 0; q2 < parts.length; ++q2) { pw0 = c3HudWrap([{ k: "caps", t: parts[q2] }], FW, maxW); for (var q1 = 0; q1 < pw0.length; ++q1) rows0.push({ t: pw0[q1].t, warn: false }); }
      if (lv0.code !== "" && lv0.code !== "galactic") wr0 = c3HudWrap([{ k: "caps", t: c3TmValidityText(lv0.code) }], FW, maxW);
      for (var q0 = 0; q0 < wr0.length; ++q0) rows0.push({ t: wr0[q0].t, warn: true });
      return rows0;
   }
   // DONDE va el reloj (sin recuadro 3D): la esquina de arriba a la derecha, arriba a la izquierda o abajo a la derecha —abajo a la izquierda va el
   // titulo— con MENOS escena debajo, MEDIDA en cinco instantes del guion (hoy, rebobinando, −escala, avanzando, +escala: las estrellas se mueven y
   // la que estaba libre al principio no lo esta al final) y fija despues. «3D»: sobre el 3D pintado; «foto»: sobre la foto con sus estrellas.
   // (Antes del `Graphics` del fotograma: no se pinta en `out` dos veces a la vez.) ROJO «corner»: la esquina con MAS escena.
   function clkChoose() {
      var mxC = Math.round(w * CP_FLP.MARGIN), pdC2 = Math.round(mxC / 4), rowHC = Math.round(FCk.ascent * 1.5), mgC = Math.round(h * 0.03), i, j;
      var capsWC = function(t) { return FCk.width(t) + Math.max(0, String(t).length - 1) * spCk; }, nRows = 1, wRows = 0, Ts = [-1, -0.6, -0.2, 0, 0.2, 0.6, 1];
      for (i = 0; i < Ts.length; ++i) {
         var rr = clkTextRows(Ts[i] * range, FCk, spCk, Math.round(clkM.w * 2.5), false);
         nRows = Math.max(nRows, rr.length);
         for (j = 0; j < rr.length; ++j) wRows = Math.max(wRows, capsWC(rr[j].t));
      }
      var bw = Math.ceil(Math.max(clkM.w, wRows + 2 * pdC2)), bh = Math.ceil(clkM.h + Math.round(8 * sc) + Math.round(pdC2 / 2) + nRows * rowHC + pdC2);
      var A = (kind === "3d") ? { x0: 0, y0: legBand, x1: w, y1: h } : { x0: Math.max(0, phL), y0: Math.max(0, phT), x1: Math.min(w, phR), y1: Math.min(h, phT + ff.height * kf) };
      var cands = [{ n: "tr", x: A.x1 - mgC - bw, y: A.y0 + mgC }, { n: "tl", x: A.x0 + mgC, y: A.y0 + mgC }, { n: "br", x: A.x1 - mgC - bw, y: A.y1 - mgC - bh }];
      // (en vertical, «foto»: la foto es una tira con ~600 px de negro encima; si el reloj cabe ENTERO en esa banda, es un sitio mas: la medida lo elegira, vacio)
      if (kind === "photo" && A.y0 - 0 >= bh + 2 * mgC && phT >= bh + 2 * mgC) cands.push({ n: "band", x: w - mgC - bw, y: Math.round((phT - bh) / 2) });
      for (i = 0; i < cands.length; ++i) { cands[i].bw = bw; cands[i].bh = bh; cands[i].tot = 0; cands[i].per = []; }
      var Ss = [C3_TMV.HOLD0 + 0.2, (C3_TMV.HOLD0 + C3_TMV.BACK) / 2, C3_TMV.BACK, (C3_TMV.HOLD1 + C3_TMV.FWD) / 2, C3_TMV.FWD], sv = tm.t, svm = tm.mixOverride;
      for (j = 0; j < Ss.length; ++j) {
         tm.t = c3TmVideoTime(Ss[j], range); tm.mixOverride = 1;
         var bmp = null;
         if (kind === "3d" && P3 !== null) bmp = scene3(Ss[j]);
         else if (kind === "photo") {
            var g2 = new Graphics(out);
            try { g2.antialiasing = true; dock._tmPaintPhotoFrame(g2, { x: 0, y: 0, w: w, h: h }, sc, { side: "left" }); g2.clipRect = new Rect(0, 0, w, h); } finally { g2.end(); }
            bmp = out;
         }
         if (bmp === null) continue;
         for (i = 0; i < cands.length; ++i) { var bz = c3TmVideoBusy(bmp, { x: cands[i].x, y: cands[i].y, w: bw, h: bh }); cands[i].tot += bz; cands[i].per.push(Math.round(bz)); }
      }
      tm.t = sv; tm.mixOverride = svm;
      var best = cands[0], red = c3ClkBroken("corner");
      if (cands.length > 3 && !red) { var bnd = cands[3]; if (bnd.tot <= best.tot * 0.5) best = bnd; }          // (la banda negra, si cabe, gana si es la mitad de ocupada que arriba a la derecha)
      for (i = 1; i < Math.min(cands.length, 3); ++i) if (red ? (cands[i].tot > best.tot) : (cands[i].tot < best.tot * 0.87)) best = cands[i];
      R.clockCorner = { n: best.n, tot: { tr: Math.round(cands[0].tot), tl: Math.round(cands[1].tot), br: Math.round(cands[2].tot), band: cands[3] ? Math.round(cands[3].tot) : -1 }, box: { x0: best.x, y0: best.y, x1: best.x + bw, y1: best.y + bh },
                        cands: cands.map(function(q) { return { n: q.n, x0: q.x, y0: q.y, x1: q.x + q.bw, y1: q.y + q.bh, per: q.per }; }) };
      return best;
   }
   function frame(k) {
      // (el guion esta escrito para C3_TMV.S segundos: con otra duracion se estira o se encoge entero)
      var s = k / fps * C3_TMV.S / S, T = c3TmVideoTime(s, range);
      tm.t = T;
      // (la mezcla con la foto sin estrellas la lleva el GUION, no el instante: al cruzar «ahora» la foto destellaba un fotograma)
      tm.mixOverride = Math.max(0, Math.min(1, (s - 0.8) / (C3_TMV.HOLD0 + 0.6 - 0.8)));
      R.lastCounter = null; R.lastTitle = null; R.lastClock = null;     // (lo que el grabador pinta encima: las pruebas miran que no tape la leyenda)
      if (clkOn && !pip && clkPos === null && s >= C3_TMV.HOLD0 - 0.6 && !(gxv && kind === "3d" && !c3TmVideoBroken("gxplate"))) clkPos = clkChoose();
      var g = new Graphics(out);
      try {
         g.fillRect(new Rect(0, 0, w, h), new Brush(cpInt(CP_FLP_BLACK)));
         g.antialiasing = true; try { g.textAntialiasing = true; } catch (eT) {}
         var legR = null;
         if (kind !== "3d") legR = dock._tmPaintPhotoFrame(g, { x: 0, y: 0, w: w, h: h }, sc, pip ? { side: pipLeft ? "left" : "right", xl: pxP, xr: pxP + w3, y: pyP + h3 + Math.round(8 * sc), maxW: w3 } : { side: "left" });
         g.clipRect = new Rect(0, 0, w, h);
         if (P3 !== null || gxB !== null) {
            var b3 = null;
            // (el mapa de la Galaxia en el instante T: tm.t. 23-oct, noche: solo, con SU placa del instante dentro —en la esquina sin estrellas
            // y en su rejilla de ocupación: la del grabador caía encima de la leyenda—; en el recuadro, con el rótulo del recuadro reservado)
            if (gxB !== null) b3 = dock._gxVideoFrame(gxB, s / C3_TMV.S, pip, pip ? { reserve: [[0, 0, pipCapBox.w, pipCapBox.h]] } : { plate: !c3TmVideoBroken("gxplate") });
            else b3 = scene3(s);
            if (pip) {
               // (DENTRO de la foto, en una esquina de arriba: MIRADO el 15-oct, con una foto 3:2 el recuadro se salia por el margen negro)
               // (y en la esquina de arriba con MENOS estrellas debajo: MIRADO por la revision del 15-oct, en LDu 2 el recuadro tapaba
               // justo Berkeley 89, adonde convergen las estelas)
               g.drawBitmap(pxP, pyP, b3);
               g.pen = new Pen(cpInt(CP_ATLAS.gold, 0.8), Math.max(1, sc)); g.brush = new Brush(0x00000000); g.drawRect(pxP, pyP, pxP + w3, pyP + h3);
               // (su rotulo, DENTRO del recuadro, arriba a la izquierda y pequeño: fuera ocupaba otra franja de la foto)
               // (V13, segunda ronda: con su espaciado, el rotulo se salia del filete por la derecha: si no cabe, la letra mengua hasta caber)
               g.fillRect(new Rect(pxP + 1, pyP + 1, pxP + 1 + Math.min(w3 - 2, capW + 2 * cpd), pyP + 1 + capH + 2 * cpd), new Brush(cpInt(CP_FLP_BLACK, 0.55)));
               g.font = capFS; g.pen = new Pen(CP_INT_AMBER); g.drawText(pxP + 1 + cpd, pyP + 1 + cpd + capFS.ascent, capT);
            } else {
               g.drawBitmap(0, 0, b3);
               if (legD !== null) c3DustLegPaint(g, Math.round(w * CP_FLP.MARGIN * 0.6), Math.round(6 * sc), legD.M, legD.spec);
               // (tarea H2: el contador, en la esquina de la derecha —abajo o arriba— con MENOS escena debajo, mirada en el primer fotograma
               // en que aparece y fija despues: abajo tapaba la nube de estrellas y la cifra «10 000 al»)
               // (V3, segunda ronda: tres esquinas —abajo a la derecha, arriba a la derecha y arriba a la izquierda, bajo la leyenda—, por la
               // luz media Y por la parte de pixeles claros —los rotulos del eje, las galaxias, los nombres—: la menos ocupada)
               if (cntTop === null && s >= C3_TMV.HOLD0 - 0.6) {
                  var rw = Math.round(w * 0.30), rh = Math.round(h * 0.18), cc = [{ n: "tr", x: w - rw - Math.round(w * 0.02), y: legBand + Math.round(h * 0.02) }, { n: "br", x: w - rw - Math.round(w * 0.02), y: Math.round(h * 0.96) - rh },
                           { n: "tl", x: Math.round(w * 0.02), y: legBand + Math.round(h * 0.02) }], bestC = null;
                  for (var ci = 0; ci < cc.length; ++ci) { cc[ci].s = c3TmVideoBusy(b3, { x: cc[ci].x, y: cc[ci].y, w: rw, h: rh }); if (bestC === null || cc[ci].s < bestC.s * 0.87) bestC = cc[ci]; }
                  cntTop = c3TmVideoBroken("platetr") ? "tr" : bestC.n;      // (ROJO «platetr»: arriba a la derecha, como en el vídeo de canto del revisor)
               }
            }
         }
         // EL TEXTO: el titulo al principio; el contador del tiempo siempre (abajo a la derecha); el modelo y el aviso, debajo
         // (los textos DENTRO de la foto, no en la banda negra; y el ancho de las versalitas con su espaciado: Font.width no lo cuenta y
         // «straight lines» se salia de su caja. MIRADO por la revision del 15-oct)
         var mx = Math.round(w * CP_FLP.MARGIN), base = Math.round(h * CP_FLP.BASE), ss = function(a, b) { var u = Math.max(0, Math.min(1, (s - a) / (b - a))); return u * u * (3 - 2 * u); };
         var mxL = (kind !== "3d") ? Math.max(mx, Math.round(phL + mx * 0.6)) : mx;
         function capsW(t) { return F.caps.width(t) + Math.max(0, String(t).length - 1) * capsSp; }
         var ta = ss(0.2, 0.9) * (1 - ss(C3_TMV.TITLE_S - 0.6, C3_TMV.TITLE_S));
         if (ta > 0.004) {
            var tW = Math.max(capsW(optT("A TIME MACHINE THROUGH")), F.title.width(title)) + mx / 2, tY0 = base - Math.round(F.title.ascent * 1.35) - F.caps.ascent - mx / 4;
            // (23-oct, noche; mirado en el vídeo de las Pléyades desde arriba: el título de abajo a la izquierda tapaba la nube y el rótulo de la
            // elegida) con el mapa de la Galaxia solo, el título va a la esquina de abajo con menos debajo —estrellas, leyenda, placa, rótulos—,
            // elegida en su primer fotograma y fija después
            if (titleSide === null) {
               titleSide = "l";
               if (gxv && kind === "3d" && dock.gx && dock.gx.lastVideoR) {
                  var LR = dock.gx.lastVideoR, Gp = (dock.state && dock.state.gx && dock.state.gx.G) ? dock.state.gx.G.proj : null, ty1 = base + F.title.descent + mx / 4;
                  var cand = [{ s: "l", b: { x0: mxL - mx / 4, y0: tY0, x1: mxL + tW, y1: ty1 } }, { s: "r", b: { x0: w - mx - tW, y0: tY0, x1: w - mx + mx / 4, y1: ty1 } }], best = null;
                  for (var tc = 0; tc < cand.length; ++tc) {
                     var bb = cand[tc].b, sco = 0, q;
                     var hit = function(o) { return !!(o && o.x0 < bb.x1 && o.x1 > bb.x0 && o.y0 < bb.y1 && o.y1 > bb.y0); };
                     if (hit(LR.legend)) sco += 5000; if (hit(LR.plate)) sco += 5000; if (hit(LR.selLabel)) sco += 3000; if (hit(LR.sel ? { x0: LR.sel.x - 8, y0: LR.sel.y - 8, x1: LR.sel.x + 8, y1: LR.sel.y + 8 } : null)) sco += 3000;
                     for (q = 0; LR.labels && q < LR.labels.length; ++q) if (hit(LR.labels[q])) sco += 200;
                     if (Gp) for (q = 0; q < Gp.n; ++q) if (Gp.ok[q] && Gp.x[q] >= bb.x0 && Gp.x[q] <= bb.x1 && Gp.y[q] >= bb.y0 && Gp.y[q] <= bb.y1) ++sco;
                     cand[tc].sco = sco;
                     if (best === null || sco < best.sco) best = cand[tc];
                  }
                  titleSide = best.s;
               }
            }
            var tx0 = (titleSide === "r") ? w - mx - tW + mx / 4 : mxL;
            g.fillRect(new Rect(tx0 - mx / 4, tY0, tx0 + tW, base + F.title.descent + mx / 4), new Brush(cpInt(CP_FLP_BLACK, 0.45 * ta)));
            R.lastTitle = { x0: tx0 - mx / 4, y0: tY0, x1: tx0 + tW, y1: base + F.title.descent + mx / 4 };
            cpFlPaintText(g, { sc: sc }, F.caps, CP_INT_AMBER, tx0, base - Math.round(F.title.ascent * 1.35), optT("A TIME MACHINE THROUGH"), ta);
            cpFlPaintText(g, { sc: sc }, F.title, CP_INT_TEXT, tx0, base, title, ta);
         }
         var ca = ss(C3_TMV.HOLD0 - 0.6, C3_TMV.HOLD0), num = c3TmTimeText(T), cy = c3TmCalendarYear(st, T), rx = (kind !== "3d") ? Math.min(w - mx, Math.round(phR - mx * 0.6)) : w - mx;
         if (ca > 0.004 && clkOn && !(gxv && kind === "3d" && !c3TmVideoBroken("gxplate"))) {
            // EL RELOJ (fase 2): la esfera con su cifra exacta (la de antes, pequeña) y, debajo, la linea del modelo y el aviso de validez, centrados en su
            // eje. Un fondo translucido solo detras de las filas de texto: la esfera lleva su propia cara opaca.
            var gxOnlyK = gxv && kind === "3d", FKc = FCk, spc = spCk, pdk = Math.round(mx / 4), rowHk = Math.round(FKc.ascent * 1.5), gapk = Math.round((pip ? 5 : 8) * sc);
            var cWk = function(t) { return FKc.width(t) + Math.max(0, String(t).length - 1) * spc; };
            var rowsK = clkTextRows(T, FKc, spc, pip ? Math.min(w3 - 2 * pdk, Math.round(clkM.w * 2.5)) : Math.round(clkM.w * 2.5), gxOnlyK);
            if (clkPos === null) {      // (con el recuadro 3D: debajo de el y de su leyenda, en su misma esquina, centrado en su columna)
               clkPos = { n: "pip", x: pxP + (w3 - clkM.w) / 2, y: (legR ? legR.y + legR.h : pyP + h3) + Math.round(10 * sc) + pdk, bw: w3, bh: 0 };
               // (vertical: si el reloj con sus filas cabe ENTERO en la banda negra de encima de la foto, va alli, sobre el recuadro 3D, y no tapa la foto)
               var bhP = clkM.h + gapk + Math.round(pdk / 2) + 3 * rowHk + pdk;
               if (h > w && phT >= bhP + 2 * mgP && !c3ClkBroken("noband")) clkPos = { n: "pipband", x: pxP + (w3 - clkM.w) / 2, y: Math.round((phT - bhP) / 2), bw: w3, bh: bhP };
            }
            var dxk = (clkPos.n === "pip" || clkPos.n === "pipband") ? clkPos.x : clkPos.x + (clkPos.bw - clkM.w) / 2, dyk = clkPos.y, cxk = dxk + clkM.w / 2;
            var nod = c3ClkBroken("nodraw");      // («nodraw»: solo para MEDIR lo que hay debajo del sitio del reloj: la escena sin el reloj ni su texto)
            var stk = nod ? { cell: { x0: Math.round(dxk), y0: Math.round(dyk), x1: Math.round(dxk) + clkM.w, y1: Math.round(dyk) + clkM.h }, box: null, deg: NaN, nodraw: true } : c3ClkPaint(g, Math.round(dxk), Math.round(dyk), clkM, T, range, num, { alpha: ca, faceAlpha: C3_CLK.FACE_A });
            var ry0 = dyk + clkM.h + gapk + Math.round(pdk / 2), wTxt = 0, qk;
            for (qk = 0; qk < rowsK.length; ++qk) wTxt = Math.max(wTxt, cWk(rowsK[qk].t));
            var tx0 = cxk - wTxt / 2 - pdk, tx1 = cxk + wTxt / 2 + pdk, ty0 = ry0 - Math.round(pdk / 2), ty1 = ry0 + FKc.ascent + (rowsK.length - 1) * rowHk + FKc.descent + Math.round(pdk / 2);
            if (!nod) g.fillRect(new Rect(tx0, ty0, tx1, ty1), new Brush(cpInt(CP_FLP_BLACK, (pip ? 0.6 : 0.45) * ca)));
            for (qk = 0; !nod && qk < rowsK.length; ++qk) cpFlPaintText(g, { sc: sc }, FKc, rowsK[qk].warn ? CP_INT_AMBERLIGHT : CP_INT_MUTED, cxk - cWk(rowsK[qk].t) / 2, ry0 + FKc.ascent + qk * rowHk, rowsK[qk].t, ca);
            R.lastClock = stk;
            R.lastCounter = { x0: Math.min(tx0, stk.cell.x0), y0: Math.min(ty0, stk.cell.y0), x1: Math.max(tx1, stk.cell.x1), y1: Math.max(ty1, stk.cell.y1), cap: rowsK[0].t, num: num, clock: true,
                              warn: rowsK.slice(1).map(function(q) { return q.t; }), dial: stk.box, text: { x0: tx0, y0: ty0, x1: tx1, y1: ty1 } };
         } else if (ca > 0.004 && !(gxv && kind === "3d" && !c3TmVideoBroken("gxplate"))) {
            // (una reserva suave detras del contador: se leia sobre las estrellas. Tarea H2, 21-oct: la caja se AJUSTA a lo que lleva —antes
            // reservaba dos renglones de aviso aunque no los hubiera— y la cifra es algo mas pequeña)
            // (con el mapa de la Galaxia solo —«3D»—, lo que se ve son las orbitas en MilkyWayPotential2022: lo dice el contador, y su aviso es el de las orbitas)
            var gxOnly = gxv && kind === "3d";
            var cap = (cy.length ? cy + "  ·  " : "") + (gxOnly ? optT("orbits in the Milky Way (MilkyWayPotential2022)") : (tm.motion === "galactic") ? optT("Galactic orbits") : optT("straight lines")), FC = F.countS, pd = Math.round(mx / 4);
            var lv = c3TmValidity(T, gxOnly ? "galactic" : dock._tmModelName()), vr = [], vk;
            // (el aviso entero, partido en renglones a la derecha: nada se corta con «…»)
            if (lv.code !== "" && lv.code !== "galactic") vr = c3HudWrap([{ k: "caps", t: c3TmValidityText(lv.code) }], { caps: F.caps, small: F.caps, big: F.caps, plain: F.caps }, Math.round(w * 0.45));
            var rowH = Math.round(F.caps.ascent * 1.5), gapC = Math.round(8 * sc), FK = F.caps, cW = capsW;
            // (con la foto, junto al recuadro 3D: letra pequeña —la del rotulo del recuadro— para que quepa en su ancho)
            if (pip) { FK = F.capsS; FC = F.countP; gapC = Math.round(5 * sc); rowH = Math.round(FK.ascent * 1.5); cW = function(t) { return F.capsS.width(t) + Math.max(0, String(t).length - 1) * capsSpS; }; }
            var top0, xr, xl = null;
            if (pip) {
               // (V3, segunda ronda: con la foto, el contador va con el recuadro 3D —debajo de el y de su leyenda, en su misma esquina—: no
               // tapa la foto en otra parte. Su ancho, el del recuadro; el aviso, partido a ese ancho)
               if (lv.code !== "" && lv.code !== "galactic") vr = c3HudWrap([{ k: "caps", t: c3TmValidityText(lv.code) }], { caps: F.capsS, small: F.capsS, big: F.capsS, plain: F.capsS, sp: capsSpS }, w3 - 2 * pd);
               top0 = (legR ? legR.y + legR.h : pyP + h3) + Math.round(10 * sc) + pd;
               if (pipLeft) xl = pxP + pd; else xr = pxP + w3 - pd;
            } else {
               top0 = (kind === "3d" && (cntTop === "tr" || cntTop === "tl")) ? legBand + Math.round(h * 0.04) : 0;
               if (kind === "3d" && cntTop === "tl") xl = Math.round(w * 0.02) + pd; else xr = rx;
            }
            var blockH = FK.ascent + gapC + FC.ascent + FC.descent + vr.length * rowH;
            if (!pip && !(kind === "3d" && (cntTop === "tr" || cntTop === "tl"))) top0 = Math.min(base - FC.ascent - gapC - FK.ascent, h - mgP - blockH);
            var capY = top0 + FK.ascent, numY = capY + gapC + FC.ascent, bw = Math.max(FC.width(num), cW(cap));
            for (vk = 0; vk < vr.length; ++vk) bw = Math.max(bw, cW(vr[vk].t));
            if (pip) bw = Math.max(bw, w3 - 2 * pd);                 // (la caja, del ancho del recuadro: un bloque con el)
            function at(wd) { return (xl !== null) ? xl : xr - wd; }
            var bx0 = (xl !== null) ? xl - pd : xr - bw - pd, bx1 = (xl !== null) ? xl + bw + pd : xr + pd;
            g.fillRect(new Rect(bx0, top0 - pd, bx1, top0 + blockH + pd), new Brush(cpInt(CP_FLP_BLACK, (pip ? 0.6 : 0.45) * ca)));
            R.lastCounter = { x0: bx0, y0: top0 - pd, x1: bx1, y1: top0 + blockH + pd, cap: cap, num: num, warn: vr.map(function(q) { return q.t; }) };
            cpFlPaintText(g, { sc: sc }, FK, CP_INT_MUTED, at(cW(cap)), capY, cap, ca);
            cpFlPaintText(g, { sc: sc }, FC, CP_INT_TEXT, at(FC.width(num)), numY, num, ca);
            for (var vi = 0; vi < vr.length; ++vi) cpFlPaintText(g, { sc: sc }, FK, CP_INT_AMBERLIGHT, at(cW(vr[vi].t)), numY + FC.descent + (vi + 1) * rowH - FK.descent, vr[vi].t, ca);
         }
         var fade = ss(C3_TMV.HOLD2, C3_TMV.S);
         if (fade > 0.004) g.fillRect(new Rect(0, 0, w, h), new Brush(cpInt(CP_FLP_BLACK, 0.85 * fade)));
      } finally { g.end(); }
      return out;
   }
   R.paint = frame;
   function finish(cancelled, why) {
      if (R.done) return;
      R.done = true;
      tm.t = saveT; tm.mixOverride = null;
      var c = W.close(), files = c.files, bytes = c.bytes, format = "avi", enc = null, i;
      cpFlPaintClose(P3);
      if (gxB !== null) { try { gxB.clear(); } catch (eG) {} gxB = null; }
      if (mp4 && c.ok && !cancelled && !why) {
         var parts = [];
         for (i = 0; i < c.files.length; ++i) parts.push(c.files[i].path);
         var mo = o.mp4 || {};
         enc = cpAviToMp4(parts, outPath, { crf: mo.crf, preset: mo.preset, encoder: mo.encoder, timeoutS: mo.timeoutS, onTick: o.onEncode });
         if (enc.ok) { for (i = 0; i < parts.length; ++i) { try { File.remove(parts[i]); } catch (eR) {} } files = [{ path: outPath, frames: c.frames, bytes: enc.bytes }]; bytes = enc.bytes; format = "mp4"; }
         else {
            var kept = [];
            for (i = 0; i < c.files.length; ++i) { var dst = cpAviPartPath(baseP + ".avi", i + 1), moved = false; try { File.move(c.files[i].path, dst); moved = File.exists(dst); } catch (eM) {} kept.push({ path: moved ? dst : c.files[i].path, frames: c.files[i].frames, bytes: c.files[i].bytes }); }
            files = kept; why = "mp4 failed (" + enc.why + "): the AVI is kept";
         }
      }
      if (cancelled && o.keepOnCancel !== true) { for (i = 0; i < c.files.length; ++i) { try { File.remove(c.files[i].path); } catch (eD) {} } files = []; bytes = 0; }
      R.result = { ok: (c.ok && !cancelled && !why), cancelled: cancelled, why: why || c.why, format: format, frames: c.frames, bytes: bytes, files: files, seconds: (Date.now() - t0) / 1000,
                   encodeSeconds: enc ? enc.seconds : 0, msPerFrame: (R.k > 0) ? paintMs / R.k : 0, width: w, height: h, fps: fps, kind: kind, galaxy: gxv };
   }
   R.ok = true; R.done = false;
   R.step = function() {
      if (R.done) return false;
      var a;
      try { var tp = Date.now(), bmp = frame(R.k); paintMs += Date.now() - tp; if (typeof o.onFrame === "function") o.onFrame(R.k, bmp); a = W.addBitmap(bmp, quality); }
      catch (e) { a = { ok: false, why: String(e) }; }
      if (!a.ok) { finish(false, a.why || "frame failed"); return false; }
      ++R.k;
      if (R.k >= R.n) { finish(false, ""); return false; }
      return true;
   };
   R.cancel = function() { finish(true, ""); };
   R.finishNow = function() { if (R.done) return; if (R.k < 1) { finish(true, ""); return; } finish(false, ""); R.result.partial = true; };
   return R;
}

// ● VIDEO: con la grabacion de la maquina en marcha, la cancela (pregunta, como el vuelo); si no, empieza.
// EL UNICO «● Record» (encargo de Nino, 15-oct: cero redundancia): graba lo que diga «que grabar» —el vuelo o la maquina
// del tiempo—. Con una grabacion en marcha, el boton la para (lo de siempre del vuelo, que pregunta).
var c3BaseFlightRecordButton = CPStarfieldDock.prototype.flightRecordButton;
CPStarfieldDock.prototype.flightRecordButton = function() {
   if (this.fl && (this.fl.rec !== null || this.fl.preview !== null)) return c3BaseFlightRecordButton.call(this);
   if (this.tm && this.tm.video !== "flight") { this.tmRecordStart(); return; }
   return c3BaseFlightRecordButton.call(this);
};
// EMPEZAR. `opts` (las pruebas): { width, height, fps, dir, title, format, kind, seconds }. Devuelve { ok, why, dir }.
CPStarfieldDock.prototype.tmRecordStart = function(opts) {
   var o = opts || {}, out = { ok: false, why: "" };
   if (!this.fl || this.fl.rec !== null || this.fl.preview !== null) { out.why = "busy"; return out; }
   if (!this._tmReady()) { out.why = this._tmWhyNot(); this._flightSay(out.why, "error"); return out; }
   this._animStop(); this._tmStopAnims();
   var size = (o.width > 0 && o.height > 0) ? { w: o.width, h: o.height } : CP_SFFL.SIZES[this.fl.size], fps = (o.fps > 0) ? o.fps : this.fl.fps;
   if (this.fl.dir.length === 0) { var dd = this._flightDefaultDir(); this.fl.dir = dd.dir; this.fl.dirWhy = dd.why; }
   var dir = String(o.dir || this.fl.dir).split("\\").join("/"), title = String((o.title !== undefined) ? o.title : (this.fl.title || this._flightTitle()));
   if (dir.length === 0 || !File.directoryExists(dir)) { out.why = optT("Choose a folder for the video (▾ in the flight row)."); this._flightSay(out.why, "error"); return out; }
   out.dir = dir;
   var self = this, kind = o.kind || ((this.tm.video !== "flight") ? this.tm.video : "both"), R = null;
   var gxTag = (typeof this._gxVideoTag === "function") ? this._gxVideoTag(kind) : "";          // (23-oct: «timemachine_galaxy_top»… con la galaxia)
   try { R = c3TmRecorder(this, { path: this._flightPath(dir, title, "timemachine_" + (gxTag || kind), size), width: size.w, height: size.h, fps: fps, kind: kind, title: title, format: o.format, seconds: o.seconds,
                                  onFrame: function(k, bmp) { self._flightRecordShow(k, bmp); } }); } catch (e) { R = { ok: false, why: String(e) }; }
   if (!R.ok) { out.why = R.why; this._flightSay(optT("Could not record the time machine") + ": " + R.why, "error"); return out; }
   var w = 0, h = 0;
   try { w = this.canvas.width; h = this.canvas.height; } catch (e3) {}
   this.fl.rec = { R: R, dir: dir, t0: Date.now(), shownAt: 0, w: w, h: h, rect: this._flightRect(Math.max(2, w), Math.max(2, h), size.w / size.h), buf: (w > 8 && h > 8) ? new Bitmap(w, h) : null,
                   locked: null, encoding: false, tm: true, saveT: this.tm.t };
   this.fl.strip = false;
   try { this.fl.rec.locked = this.dialog._batchLock(); } catch (e4) {}
   this._flightDockLock(true);
   this._flightSync(); this._tmSync();
   this._flightSay(format(optT("Recording the time machine to %s"), dir), "pending", dir);
   this.flTimer.interval = CP_SFFL.RECORD_TICK_S;
   try { this.flTimer.start(); } catch (e5) {}
   out.ok = true;
   return out;
};
// Al acabar una grabacion de la maquina: lo que se dice es suyo (no «Flight saved»), y el instante vuelve a donde estaba.
var c3BaseFlightRecordEnd = CPStarfieldDock.prototype._flightRecordEnd;
CPStarfieldDock.prototype._flightRecordEnd = function(cancel) {
   var rc = this.fl.rec, isTm = !!(rc && rc.tm);
   c3BaseFlightRecordEnd.call(this, cancel);
   if (!isTm) return;
   this.tm.t = rc.saveT;
   var res = (this.fl.last && this.fl.last.result) ? this.fl.last.result : null;
   if (res && res.ok) this._flightSay(format(optT("Time machine video saved: %s (%s MB, %d frames)"), res.files[0].path, cpSvFx((res.bytes / 1e6), 1), res.frames), "ok", res.files[0].path);
   else if (res && !res.cancelled) this._flightSay(optT("Could not record the time machine") + ": " + res.why, "error");
   this._tmSync();
   this._tmRepaint(false);
};
