// ============================================================================
// tm/timeruler.js — LA REGLA DEL TIEMPO: el deslizador de la maquina del tiempo, pintado (Cabra3D, 14-oct-2026)
// ----------------------------------------------------------------------------
// MIRADO en la primera captura del dialogo: el `HorizontalSlider` de siempre rellena de oro DESDE LA IZQUIERDA hasta
// el tirador, y en una barra simetrica (el centro es «ahora») eso se lee como «progreso desde el principio». Esta regla
// es un `Control` pintado: la pista, la muesca de oro de AHORA en el centro, las marcas con sus cifras (−escala,
// −escala/10, −escala/100, ahora, …: el reparto es el del deslizador, mas fino cerca de ahora), el tramo de oro
// DESDE AHORA hasta el tirador (cuanto te has ido, y hacia donde) y el tirador. Clic o arrastre = mover el tiempo.
// Misma forma que el deslizador para quien la usa: `value`, `maxValue`, `onValueUpdated( v )`, `onMouseRelease()`.
// Nada se calcula en onPaint mas que la geometria de la propia regla. ES5.
// ============================================================================

function c3TmShortYears(y) {
   var a = Math.abs(y), s = (y < 0) ? "−" : "+";
   if (a === 0) return "0";                 // (tarea H8, 21-oct: «now» ya lo dice el boton «⟲ Now» de al lado; la marca es el cero de la escala)
   // (23-oct, noche; revisión visual: las marcas «−100 M / +1 M» → «Ma / Ga» en castellano, «Myr / Gyr» en inglés, como CabraComposition)
   if (a >= 1e9) return s + cpSvDec(String(a / 1e9)) + " " + optT("Gyr");
   if (a >= 1e6) return s + cpSvDec(String(a / 1e6)) + " " + optT("Myr");
   if (a >= 1e3) return s + cpSvDec(String(a / 1e3)) + " " + ((typeof cshLangIsEs === "function" && cshLangIsEs()) ? "ka" : "kyr");
   return s + a;
}

function c3TimeRuler(parent) {
   var c = new Control(parent), sc = cpUiScale(c);
   c.value = C3_TM_STEPS / 2; c.maxValue = C3_TM_STEPS; c.minValue = 0;
   c.c3range = C3_TMUI.RANGE_DEFAULT; c.c3drag = false;
   c.onValueUpdated = null;
   try { c.setFixedHeight(Math.round(CP_ATLAS.space[5] * sc)); } catch (eH) {}
   try { c.setMinWidth(cpUiPx(CP_ATLAS.space[9] + CP_ATLAS.space[7], c)); } catch (eW) {}
   cpApplyStyle(c, "background-color:transparent; border:none;");
   function geo() { var w = c.width, h = c.height, mx = Math.round(h * 0.45); return { w: w, h: h, mx: mx, y: Math.round(h * 0.36), span: Math.max(1, w - 2 * mx) }; }
   function xOf(G, v) { return G.mx + G.span * v / C3_TM_STEPS; }
   function vOf(G, x) { return Math.max(0, Math.min(C3_TM_STEPS, Math.round((x - G.mx) / G.span * C3_TM_STEPS))); }
   c.c3set = function(v) { v = Math.max(0, Math.min(C3_TM_STEPS, Math.round(v))); if (v === c.value) return; c.value = v; c.repaint(); };
   function move(x) {
      var v = vOf(geo(), x);
      // (cerca de ahora, se pega a ahora: 0 es un sitio, no un punto que haya que acertar)
      if (Math.abs(v - C3_TM_STEPS / 2) <= Math.max(2, Math.round(C3_TM_STEPS * 0.006))) v = C3_TM_STEPS / 2;
      if (v === c.value) return;
      c.value = v; c.repaint();
      if (typeof c.onValueUpdated === "function") c.onValueUpdated(v);
   }
   c.onMousePress = function(x, y, b) { if (!c.enabled) return; c.c3drag = true; move(x); };
   c.onMouseMove = function(x, y, buttons) { if (c.c3drag) move(x); };
   c.onMouseRelease = function(x, y) { if (!c.c3drag) return; c.c3drag = false; if (typeof c.c3onRelease === "function") c.c3onRelease(); };
   c.onPaint = function() {
      var g = new Graphics(c), G = geo(), k = cpUiScale(c), on = c.enabled, gold = on ? CP_INT_AMBER : CP_INT_BORDER;
      try {
         g.antialiasing = true;
         try { g.textAntialiasing = true; } catch (eT) {}
         var lw = Math.max(1, Math.round(2 * k)), x0 = G.mx, x1 = G.mx + G.span, xc = xOf(G, C3_TM_STEPS / 2), xh = xOf(G, c.value);
         // la pista
         g.pen = new Pen(CP_INT_BORDER, lw); g.drawLine(x0, G.y, x1, G.y);
         // las marcas y sus cifras (las que caben)
         var R = c.c3range, marks = [-R, -R / 10, -R / 100, 0, R / 100, R / 10, R], F = cpFont("mono", CP_ATLAS.size.label * k * 0.92), lastEnd = -1e9, i;
         g.font = F;
         var order = [3, 0, 6, 1, 5, 2, 4], placed = [];       // (primero ahora y los extremos: si no caben todas, quedan esas)
         for (var q = 0; q < order.length; ++q) {
            i = order[q];
            var y = marks[i], xm = xOf(G, c3TmYearsToSlider(y, R)), t = c3TmShortYears(y), tw = F.width(t), tx = Math.max(0, Math.min(G.w - tw, xm - tw / 2)), ok = true;
            if (Math.abs(y) < 1 && i !== 3) continue;
            for (var p = 0; p < placed.length; ++p) if (tx < placed[p][1] + 4 * k && tx + tw > placed[p][0] - 4 * k) ok = false;
            g.pen = new Pen((i === 3) ? gold : CP_INT_MUTED, Math.max(1, k));
            g.drawLine(xm, G.y - ((i === 3) ? 5 : 3) * k, xm, G.y + ((i === 3) ? 5 : 3) * k);
            if (!ok) continue;
            placed.push([tx, tx + tw]);
            g.pen = new Pen((i === 3) ? (on ? CP_INT_AMBERLIGHT : CP_INT_MUTED) : CP_INT_MUTED);
            g.drawText(tx, G.h - Math.max(1, Math.round(1 * k)), t);
         }
         // de ahora al tirador: lo que te has ido
         if (Math.abs(xh - xc) > 0.5) { g.pen = new Pen(gold, Math.max(2, Math.round(3 * k))); g.drawLine(xc, G.y, xh, G.y); }
         // el tirador
         var r = Math.max(4, Math.round(5.5 * k));
         g.pen = new Pen(CP_INT_BG, Math.max(1, k)); g.brush = new Brush(on ? CP_INT_AMBERLIGHT : CP_INT_BORDER);
         g.drawCircle(xh, G.y, r);
      } finally { g.end(); }
   };
   return c;
}
