// ============================================================================
// tm/skyfrom.js — EL CIELO VISTO DESDE OTRA ESTRELLA (Cabra3D, A6, 15-oct-2026), la parte PURA
// ----------------------------------------------------------------------------
// Te pones en una estrella del campo y miras: cada estrella del campo se ve desde alli en otra
// direccion (paralaje real: la resta de los dos vectores) y con otro brillo (el flujo cae como 1/d²:
// m' = m + 5 log10(d'/d)). El Sol aparece como una estrella mas: m = M + 5 log10(d/10 pc), con
// M_V = 4,83 y M_G = 4,67 (Willmer 2018; Casagrande y VandenBerg 2018).
// CONTROL (tests/c3_tm_cases.js, 9.x): desde alfa Centauri el Sol sale en Casiopea con V ≈ 0,5.
// La constelacion de una posicion: el metodo de Roman (1987, CDS VI/42; src/data/constellations/), que
// pide la posicion en el equinoccio 1875: se precesa con IAU 1976 (Lieske et al. 1977; Meeus cap. 21).
// La proyeccion del cielo entero: Hammer-Aitoff (igual area), centrada en la direccion de la foto.
// ES5 puro (node lo ejecuta).
// ============================================================================

var C3_SKY = { SUN_MV: 4.83, SUN_MG: 4.67, B1875_JD: 2405889.258550475 };

// Las 88, abreviatura de la IAU -> nombre latino.
var C3_CONST_NAMES = { And: "Andromeda", Ant: "Antlia", Aps: "Apus", Aqr: "Aquarius", Aql: "Aquila", Ara: "Ara", Ari: "Aries", Aur: "Auriga", Boo: "Bootes",
   Cae: "Caelum", Cam: "Camelopardalis", Cnc: "Cancer", CVn: "Canes Venatici", CMa: "Canis Major", CMi: "Canis Minor", Cap: "Capricornus", Car: "Carina",
   Cas: "Cassiopeia", Cen: "Centaurus", Cep: "Cepheus", Cet: "Cetus", Cha: "Chamaeleon", Cir: "Circinus", Col: "Columba", Com: "Coma Berenices",
   CrA: "Corona Australis", CrB: "Corona Borealis", Crv: "Corvus", Crt: "Crater", Cru: "Crux", Cyg: "Cygnus", Del: "Delphinus", Dor: "Dorado",
   Dra: "Draco", Equ: "Equuleus", Eri: "Eridanus", For: "Fornax", Gem: "Gemini", Gru: "Grus", Her: "Hercules", Hor: "Horologium", Hya: "Hydra",
   Hyi: "Hydrus", Ind: "Indus", Lac: "Lacerta", Leo: "Leo", LMi: "Leo Minor", Lep: "Lepus", Lib: "Libra", Lup: "Lupus", Lyn: "Lynx", Lyr: "Lyra",
   Men: "Mensa", Mic: "Microscopium", Mon: "Monoceros", Mus: "Musca", Nor: "Norma", Oct: "Octans", Oph: "Ophiuchus", Ori: "Orion", Pav: "Pavo",
   Peg: "Pegasus", Per: "Perseus", Phe: "Phoenix", Pic: "Pictor", Psc: "Pisces", PsA: "Piscis Austrinus", Pup: "Puppis", Pyx: "Pyxis",
   Ret: "Reticulum", Sge: "Sagitta", Sgr: "Sagittarius", Sco: "Scorpius", Scl: "Sculptor", Sct: "Scutum", Ser: "Serpens", Sex: "Sextans",
   Tau: "Taurus", Tel: "Telescopium", Tri: "Triangulum", TrA: "Triangulum Australe", Tuc: "Tucana", UMa: "Ursa Major", UMi: "Ursa Minor",
   Vel: "Vela", Vir: "Virgo", Vol: "Volans", Vul: "Vulpecula" };

// La tabla de Roman: texto de data.dat -> [ [raLo (h), raHi (h), decLo, abr] ] en su orden.
function c3RomanParse(text) {
   var out = [], L = String(text).split(/\r?\n/);
   for (var i = 0; i < L.length; ++i) {
      var p = L[i].replace(/^\s+|\s+$/g, "").split(/\s+/);
      if (p.length < 4) continue;
      out.push([parseFloat(p[0]), parseFloat(p[1]), parseFloat(p[2]), p[3]]);
   }
   return out;
}
// Precesion IAU 1976 de J2000 a la epoca `jd` (grados). Meeus, cap. 21.
function c3PrecessFromJ2000(ra, dec, jd) {
   var T = (jd - 2451545.0) / 36525, as = Math.PI / 180 / 3600, d = Math.PI / 180;
   var zeta = (2306.2181 * T + 0.30188 * T * T + 0.017998 * T * T * T) * as, z = (2306.2181 * T + 1.09468 * T * T + 0.018203 * T * T * T) * as,
       th = (2004.3109 * T - 0.42665 * T * T - 0.041833 * T * T * T) * as;
   var a = ra * d, de = dec * d, A = Math.cos(de) * Math.sin(a + zeta), B = Math.cos(th) * Math.cos(de) * Math.cos(a + zeta) - Math.sin(th) * Math.sin(de),
       C = Math.sin(th) * Math.cos(de) * Math.cos(a + zeta) + Math.cos(th) * Math.sin(de);
   var r = (Math.atan2(A, B) + z) / d;
   r = ((r % 360) + 360) % 360;
   return { ra: r, dec: Math.asin(Math.max(-1, Math.min(1, C))) / d };
}
// La constelacion (abreviatura) de una posicion J2000.
function c3ConstellationOf(ra, dec, table) {
   if (!table || !table.length) return "";
   var p = c3PrecessFromJ2000(ra, dec, C3_SKY.B1875_JD), rh = p.ra / 15;
   for (var i = 0; i < table.length; ++i) { var t = table[i]; if (p.dec >= t[2] && rh >= t[0] && rh < t[1]) return t[3]; }
   return "";
}

// EL CIELO DESDE `origin` ({ x, y, z } en pc, ICRS, Sol en el origen). `stars` = [ { x, y, z, mag } ] (mag vista desde el Sol).
// Devuelve { sun: { ra, dec, d, mv, mg }, stars: [ { ra, dec, d, mag } ] } (mag = la de alli).
function c3SkyFrom(origin, stars) {
   var out = { stars: [] };
   var sx = -origin.x, sy = -origin.y, sz = -origin.z, sd = Math.sqrt(sx * sx + sy * sy + sz * sz), sk = c3TmSky(sx, sy, sz);
   out.sun = { ra: sk.ra, dec: sk.dec, d: sd, mv: C3_SKY.SUN_MV + 5 * Math.log(sd / 10) / Math.LN10, mg: C3_SKY.SUN_MG + 5 * Math.log(sd / 10) / Math.LN10 };
   for (var i = 0; i < stars.length; ++i) {
      var s = stars[i], dx = s.x - origin.x, dy = s.y - origin.y, dz = s.z - origin.z, d1 = Math.sqrt(dx * dx + dy * dy + dz * dz), d0 = Math.sqrt(s.x * s.x + s.y * s.y + s.z * s.z);
      if (!(d1 > 0)) { out.stars.push(null); continue; }
      var q = c3TmSky(dx, dy, dz);
      out.stars.push({ ra: q.ra, dec: q.dec, d: d1, mag: (s.mag === null || s.mag === undefined) ? null : s.mag + 5 * Math.log(d1 / d0) / Math.LN10 });
   }
   return out;
}

// HAMMER-AITOFF centrada en (ra0, dec0): { x, y } en [−2√2, 2√2] × [−√2, √2] (x crece hacia el ESTE = a la izquierda en el cielo: se
// devuelve ya con el este a la izquierda, como se mira el cielo).
function c3Hammer(ra, dec, ra0, dec0) {
   var d = Math.PI / 180, a = ra * d, de = dec * d, a0 = ra0 * d, d0 = dec0 * d;
   // girar para que (ra0, dec0) quede en (0, 0)
   var x = Math.cos(de) * Math.cos(a - a0), y = Math.cos(de) * Math.sin(a - a0), z = Math.sin(de);
   var x2 = x * Math.cos(d0) + z * Math.sin(d0), z2 = -x * Math.sin(d0) + z * Math.cos(d0);
   var lon = Math.atan2(y, x2), lat = Math.asin(Math.max(-1, Math.min(1, z2)));
   var den = Math.sqrt(1 + Math.cos(lat) * Math.cos(lon / 2));
   return { x: -2 * Math.SQRT2 * Math.cos(lat) * Math.sin(lon / 2) / den, y: Math.SQRT2 * Math.sin(lat) / den };
}
