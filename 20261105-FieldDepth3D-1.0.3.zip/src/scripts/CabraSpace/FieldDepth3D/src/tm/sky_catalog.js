// ============================================================================
// tm/sky_catalog.js — EL CIELO ENTERO para «Sky from the star» (Cabra3D, bloque E, 20-oct-2026), la parte PURA
// ----------------------------------------------------------------------------
// Lee el catalogo empaquetado (src/data/sky/: Hipparcos I/311 + I/239 hasta V = 8, nombres, figuras de Stellarium),
// lo fusiona con las estrellas de la foto (Gaia, las de la maquina del tiempo) sin duplicados, y RE-CENTRA todo en
// cualquier punto: la direccion de cada estrella es la resta de los dos vectores y su brillo cae como 1/d²
// (m' = m + 5 log10(d'/d)). Las que no tienen paralaje fiable van «al infinito»: su direccion y su brillo no cambian.
// El Sol, una estrella mas (M_V = 4,83, B−V = 0,65).
// Proyecciones de la vista: ESTEREOGRAFICA alrededor de la mirada (conforme: las figuras conservan la forma local; vale
// hasta 180°) y HAMMER-AITOFF de todo el cielo. El este, a la izquierda (como se mira el cielo).
// CONTROLES (tests/c3_blockE_cases.js): desde el Sol, Sirio −1,44 (Hipparcos; lit. −1,46), Betelgeuse en Orion,
// Dubhe–Merak 5,37°; desde alfa Cen el Sol en Casiopea con V ≈ 0,45; desde Alpheratz (30 pc) el cinturon de Orion casi
// quieto y las cercanas desplazadas HACIA ATRAS. Con el signo de la resta al reves, fallan.
// ES5 puro (node lo ejecuta). Usa c3TmSky (timemachine.js) solo en c3SkyDirToRaDec si existe; si no, la suya.
// NECESITA CabraShared/csh_hipnames.js incluido ANTES (27-oct-2026: el catalogo Hipparcos, sus nombres y el casado con Gaia viven alli).
// ============================================================================

// (27-oct-2026, D4) las epocas y el CRITERIO DE CASADO con Gaia (MATCH_ARCSEC, MATCH_DMAG, FIELD_GMAX_MATCH) viven en CabraShared/csh_hipnames.js
// (CSH_HIP), que comparten CabraStars y CabraComposition: aqui no se repiten (dos copias de un umbral se desafinan sin avisar).
var C3_SKYCAT = { PLX_SNR: 3, EPOCH_HIP: CSH_HIP.EPOCH_HIP, EPOCH: CSH_HIP.EPOCH, SUN_MV: 4.83, SUN_BV: 0.65,
   // (H6c, 21-oct) PARALAJE COMUN DE UN SISTEMA: dos estrellas de Hipparcos a < SYS_ARCSEC cuyas paralajes son COMPATIBLES
   // (diferencia ≤ SYS_K sigma combinadas) son un sistema: las dos llevan la media ponderada (1/σ²). Sin esto, alfa Cen B
   // (796,9 ± 25,9 mas) quedaba a 0,23 al de A (754,8 ± 4,1 mas) y desde A brillaba a −4,9: el ruido de la paralaje de B
   // convertido en distancia. Si la diferencia pasa de SYS_K sigma son, casi seguro, una pareja OPTICA y no se tocan.
   // SYSTEMS: los que van juntos SIEMPRE (por si un dia sus errores dejan de solaparse): alfa Cen A + B.
   SYS_ARCSEC: 30, SYS_K: 3, SYSTEMS: [[71683, 71681]] };

// (27-oct-2026, D4) EL CATALOGO HIPPARCOS Y SUS NOMBRES: la parte pura (leer hip_bright / hip_names / iau_wgsn, casar una estrella de Gaia,
// el nombre de un HIP, Bayer/Flamsteed bonito, V de la G) se MUDO a CabraShared/csh_hipnames.js (con los datos, CabraShared/data/sky/) para
// que CabraStars y CabraComposition nombren igual. Aqui quedan con su nombre de siempre (lo usan el planetario, las placas, la ficha y las
// pruebas): son LAS MISMAS funciones, no copias.
var C3_SKY_GREEK = CSH_HIP_GREEK, C3_SKY_SUP = CSH_HIP_SUP;
var c3SkyNum = cshHipNum, c3SkyCatParse = cshHipCatParse, c3SkyNamesParse = cshHipNamesParse, c3SkyWgsnParse = cshHipWgsnParse, c3SkyNamesWgsn = cshHipNamesWgsn;
var c3SkyMatchHip = cshHipMatch, c3SkyNameOfHip = cshHipNameOfHip, c3SkyDesigPretty = cshHipDesigPretty, c3SkyVfromG = cshHipVfromG;
// constellations_modern.csv -> [ { abbr, name, polys: [[hip, …], …] } ]
function c3SkyConstParse(text) {
   var L = String(text).split(/\r?\n/), out = [];
   for (var i = 0; i < L.length; ++i) {
      var l = L[i]; if (!l.length || l.charAt(0) === "#") continue;
      var p = l.split("|"); if (p.length < 3) continue;
      var polys = [], segs = p[2].split(";");
      for (var j = 0; j < segs.length; ++j) {
         var hs = segs[j].replace(/^\s+|\s+$/g, "").split(/\s+/), poly = [];
         for (var k = 0; k < hs.length; ++k) { var h = parseInt(hs[k], 10); if (h > 0) poly.push(h); }
         if (poly.length >= 2) polys.push(poly);
      }
      out.push({ abbr: p[0], name: p[1], polys: polys });
   }
   return out;
}

// B−V <-> BP−RP de la secuencia principal, APROXIMADO (solo para el COLOR de los puntos, un producto estetico, no una
// medida): tabla a tramos anclada en Vega (0, 0) y el Sol (0,65, 0,82).
var C3_SKY_BV_BPRP = [[-0.35, -0.45], [-0.10, -0.15], [0.0, 0.0], [0.30, 0.43], [0.50, 0.66], [0.65, 0.82], [0.82, 0.99], [1.00, 1.22], [1.20, 1.52], [1.40, 1.85], [1.60, 2.40], [2.00, 3.20]];
function c3SkyInterp(T, x, a, b) {
   if (!isFinite(x)) return NaN;
   if (x <= T[0][a]) return T[0][b];
   for (var i = 1; i < T.length; ++i) if (x <= T[i][a]) { var t = (x - T[i - 1][a]) / (T[i][a] - T[i - 1][a]); return T[i - 1][b] + (T[i][b] - T[i - 1][b]) * t; }
   return T[T.length - 1][b];
}
function c3SkyBpRpFromBV(bv) { return c3SkyInterp(C3_SKY_BV_BPRP, bv, 0, 1); }
function c3SkyBVFromBpRp(c) { return c3SkyInterp(C3_SKY_BV_BPRP, c, 1, 0); }

function c3SkyUnit(ra, dec) { var k = Math.PI / 180, cd = Math.cos(dec * k); return [cd * Math.cos(ra * k), cd * Math.sin(ra * k), Math.sin(dec * k)]; }
function c3SkyDirToRaDec(x, y, z) {
   var r = Math.sqrt(x * x + y * y + z * z), k = 180 / Math.PI;
   if (!(r > 0)) return { ra: 0, dec: 0 };
   var ra = Math.atan2(y, x) * k; if (ra < 0) ra += 360;
   return { ra: ra, dec: Math.asin(Math.max(-1, Math.min(1, z / r))) * k };
}
function c3SkySepDeg(a, b) {           // dos vectores (no hace falta que sean unitarios)
   var d = a[0] * b[0] + a[1] * b[1] + a[2] * b[2], cx = a[1] * b[2] - a[2] * b[1], cy = a[2] * b[0] - a[0] * b[2], cz = a[0] * b[1] - a[1] * b[0];
   return Math.atan2(Math.sqrt(cx * cx + cy * cy + cz * cz), d) * 180 / Math.PI;
}

// LA PARALAJE COMUN de los sistemas (ver C3_SKYCAT.SYS_*). `cra`, `cde`: posiciones (grados) en la misma epoca.
// Devuelve { plx, eplx (Float64Array: la de cada estrella, la del sistema si lo tiene), sys (Int32Array: n.º de sistema o −1),
// nGroups, nStars, groups: [[indices]] }. Barrido por declinacion: 41 000 estrellas en pocos ms.
function c3SkyCommonPlx(cat, cra, cde, opts) {
   opts = opts || {};
   var n = cat.n, rDeg = (opts.arcsec > 0 ? opts.arcsec : C3_SKYCAT.SYS_ARCSEC) / 3600, K = (opts.k > 0) ? opts.k : C3_SKYCAT.SYS_K, k = Math.PI / 180, i, j;
   var plx = new Float64Array(n), eplx = new Float64Array(n), sys = new Int32Array(n), par = new Int32Array(n), idx = [];
   for (i = 0; i < n; ++i) { plx[i] = cat.plx[i]; eplx[i] = cat.eplx[i]; sys[i] = -1; par[i] = i; idx.push(i); }
   function root(a) { while (par[a] !== a) { par[a] = par[par[a]]; a = par[a]; } return a; }
   function join(a, b) { a = root(a); b = root(b); if (a !== b) par[b] = a; }
   function good(a) { return plx[a] > 0 && eplx[a] > 0 && isFinite(plx[a]) && isFinite(eplx[a]); }
   idx.sort(function(a, b) { return cde[a] - cde[b]; });
   for (var p = 0; p < n; ++p) {
      i = idx[p]; if (!good(i)) continue;
      var cdi = Math.max(1e-6, Math.cos(cde[i] * k));
      for (var q = p + 1; q < n; ++q) {
         j = idx[q]; if (cde[j] - cde[i] > rDeg) break;
         if (!good(j)) continue;
         var da = cra[j] - cra[i]; if (da > 180) da -= 360; else if (da < -180) da += 360; da *= cdi;
         var dd = cde[j] - cde[i];
         if (da * da + dd * dd > rDeg * rDeg) continue;
         if (Math.abs(plx[i] - plx[j]) <= K * Math.sqrt(eplx[i] * eplx[i] + eplx[j] * eplx[j])) join(i, j);
      }
   }
   // los que van juntos siempre (por numero HIP)
   var byHip = {}, S = opts.systems || C3_SKYCAT.SYSTEMS;
   for (i = 0; i < n; ++i) byHip[cat.hip[i]] = i;
   for (i = 0; i < S.length; ++i) { var a0 = byHip[S[i][0]]; for (j = 1; j < S[i].length; ++j) { var b0 = byHip[S[i][j]]; if (a0 !== undefined && b0 !== undefined && good(a0) && good(b0)) join(a0, b0); } }
   var G = {}, groups = [], nStars = 0;
   for (i = 0; i < n; ++i) { if (!good(i)) continue; var r = root(i); if (G[r] === undefined) G[r] = []; G[r].push(i); }
   for (var key in G) {
      var M = G[key]; if (M.length < 2) continue;
      var sw = 0, sp = 0;
      for (j = 0; j < M.length; ++j) { var w = 1 / (eplx[M[j]] * eplx[M[j]]); sw += w; sp += w * plx[M[j]]; }
      var pm = sp / sw, em = 1 / Math.sqrt(sw), gid = groups.length;
      for (j = 0; j < M.length; ++j) { plx[M[j]] = pm; eplx[M[j]] = em; sys[M[j]] = gid; }
      groups.push(M); nStars += M.length;
   }
   return { plx: plx, eplx: eplx, sys: sys, nGroups: groups.length, nStars: nStars, groups: groups };
}

// EL MUNDO: cada estrella con su posicion 3D (pc, ICRS, Sol en el origen) o solo su direccion («al infinito»).
// `field` (opcional): las de la foto, [ { x, y, z (pc; null sin distancia), ra, dec, g, bpRp, ref } ].
// Devuelve columnas: x, y, z, d (pc; NaN = infinito), ux, uy, uz, v (V vista desde el Sol), bp (indice de color BP−RP, para
// pintar), hip (0 = ninguno), ref (indice en la foto o −1), kind (0 Hipparcos, 1 de la foto, 2 las dos), inf (1 = al infinito);
// y byHip: { hip: i }, nHip, nField, nMerged, nInf.
function c3SkyWorld(cat, field, opts) {
   opts = opts || {};
   var snr = (opts.plxSnr > 0) ? opts.plxSnr : C3_SKYCAT.PLX_SNR, dt = C3_SKYCAT.EPOCH - C3_SKYCAT.EPOCH_HIP, F = field || [], i, j;
   var nC = cat ? cat.n : 0, nMax = nC + F.length;
   var W = { n: 0, x: new Float64Array(nMax), y: new Float64Array(nMax), z: new Float64Array(nMax), d: new Float64Array(nMax), ux: new Float64Array(nMax), uy: new Float64Array(nMax), uz: new Float64Array(nMax),
             v: new Float64Array(nMax), bp: new Float64Array(nMax), hip: new Int32Array(nMax), ref: new Int32Array(nMax), kind: new Uint8Array(nMax), inf: new Uint8Array(nMax),
             byHip: {}, nHip: 0, nField: 0, nMerged: 0, nInf: 0 };
   // 1. las de la foto que son de Hipparcos (las brillantes): casar por posicion (J2016) y magnitud
   var takenBy = {}, fieldHip = new Int32Array(F.length), k = Math.PI / 180;
   var cra = new Float64Array(nC), cde = new Float64Array(nC);
   for (i = 0; i < nC; ++i) {
      var cd0 = Math.cos(cat.dec[i] * k);
      cra[i] = cat.ra[i] + (isFinite(cat.pmra[i]) ? cat.pmra[i] * dt / 3.6e6 / Math.max(1e-6, cd0) : 0);
      cde[i] = cat.dec[i] + (isFinite(cat.pmde[i]) ? cat.pmde[i] * dt / 3.6e6 : 0);
   }
   // 0. la paralaje comun de los sistemas (opts.commonPlx === false la apaga: el control en rojo de las pruebas)
   var PS = (opts.commonPlx === false || nC === 0) ? null : c3SkyCommonPlx(cat, cra, cde);
   W.sys = new Int32Array(nMax); W.nSys = PS ? PS.nGroups : 0; W.nSysStars = PS ? PS.nStars : 0;
   for (i = 0; i < nMax; ++i) W.sys[i] = -1;
   var rMatch = CSH_HIP.MATCH_ARCSEC / 3600;
   for (j = 0; j < F.length; ++j) {
      var f = F[j]; fieldHip[j] = 0;
      if (!(f.g <= CSH_HIP.FIELD_GMAX_MATCH)) continue;
      var vf = c3SkyVfromG(f.g, f.bpRp), cdf = Math.cos(f.dec * k), best = -1, bd = 1e9;
      for (i = 0; i < nC; ++i) {
         var dd = cde[i] - f.dec; if (dd > rMatch || dd < -rMatch) continue;
         var da = (cra[i] - f.ra); if (da > 180) da -= 360; else if (da < -180) da += 360; da *= cdf;
         if (da > rMatch || da < -rMatch) continue;
         var s = Math.sqrt(da * da + dd * dd);
         if (s < bd && Math.abs(cat.v[i] - vf) < CSH_HIP.MATCH_DMAG) { bd = s; best = i; }
      }
      if (best >= 0 && takenBy[best] === undefined) { takenBy[best] = j; fieldHip[j] = best + 1; }
   }
   function put(x, y, z, ux, uy, uz, d, v, bp, hip, ref, kind) {
      var q = W.n++;
      W.x[q] = x; W.y[q] = y; W.z[q] = z; W.ux[q] = ux; W.uy[q] = uy; W.uz[q] = uz; W.d[q] = d; W.v[q] = v; W.bp[q] = bp; W.hip[q] = hip; W.ref[q] = ref; W.kind[q] = kind;
      W.inf[q] = isFinite(d) ? 0 : 1; if (W.inf[q]) ++W.nInf;
      if (hip > 0) W.byHip[hip] = q;
      return q;
   }
   // 2. Hipparcos (las que no son de la foto)
   for (i = 0; i < nC; ++i) {
      if (takenBy[i] !== undefined || !isFinite(cat.v[i])) continue;
      var u = c3SkyUnit(cra[i], cde[i]), plx = PS ? PS.plx[i] : cat.plx[i], ep = PS ? PS.eplx[i] : cat.eplx[i], d = (plx > 0 && (!(ep > 0) || plx / ep >= snr)) ? 1000 / plx : NaN;
      var bpc = isFinite(cat.bv[i]) ? c3SkyBpRpFromBV(cat.bv[i]) : NaN, q0;
      if (isFinite(d)) q0 = put(u[0] * d, u[1] * d, u[2] * d, u[0], u[1], u[2], d, cat.v[i], bpc, cat.hip[i], -1, 0);
      else q0 = put(NaN, NaN, NaN, u[0], u[1], u[2], NaN, cat.v[i], bpc, cat.hip[i], -1, 0);
      if (PS) W.sys[q0] = PS.sys[i];
      ++W.nHip;
   }
   // 3. las de la foto (con la V, el color y el nombre de Hipparcos si casan)
   for (j = 0; j < F.length; ++j) {
      var f2 = F[j], hi = fieldHip[j] - 1, v2, bp2;
      if (hi >= 0) { v2 = cat.v[hi]; bp2 = isFinite(cat.bv[hi]) ? c3SkyBpRpFromBV(cat.bv[hi]) : f2.bpRp; ++W.nMerged; }
      else { if (!isFinite(f2.g)) continue; v2 = c3SkyVfromG(f2.g, f2.bpRp); bp2 = f2.bpRp; }
      if (bp2 === null || bp2 === undefined) bp2 = NaN;       // (23-oct, tarde: sin BP−RP, NaN —el gris de cpSvStarRgb—; en la columna Float64 un null era 0, azulado)
      var hasD = (f2.x !== null && f2.x !== undefined && isFinite(f2.x)), d2 = hasD ? Math.sqrt(f2.x * f2.x + f2.y * f2.y + f2.z * f2.z) : NaN;
      var u2 = hasD && d2 > 0 ? [f2.x / d2, f2.y / d2, f2.z / d2] : c3SkyUnit(f2.ra, f2.dec);
      if (hasD && d2 > 0) put(f2.x, f2.y, f2.z, u2[0], u2[1], u2[2], d2, v2, bp2, hi >= 0 ? cat.hip[hi] : 0, f2.ref, hi >= 0 ? 2 : 1);
      else put(NaN, NaN, NaN, u2[0], u2[1], u2[2], NaN, v2, bp2, hi >= 0 ? cat.hip[hi] : 0, f2.ref, hi >= 0 ? 2 : 1);
      ++W.nField;
   }
   return W;
}

// RE-CENTRAR en `o` ({ x, y, z } pc; null o 0 = el Sol). `skip` (indice del mundo, o −1): la estrella en la que se esta.
// Devuelve { n, ux, uy, uz, m, d, sun: { ux, uy, uz, ra, dec, d, m } o null, order (indices de la mas debil a la mas brillante) }.
function c3SkyRecentre(W, o, skip) {
   var n = W.n, R = { n: n, ux: new Float64Array(n), uy: new Float64Array(n), uz: new Float64Array(n), m: new Float64Array(n), d: new Float64Array(n), sun: null, order: null };
   var ox = o ? o.x : 0, oy = o ? o.y : 0, oz = o ? o.z : 0, od = Math.sqrt(ox * ox + oy * oy + oz * oz), LN10 = Math.LN10;
   for (var i = 0; i < n; ++i) {
      if (i === skip) { R.m[i] = NaN; R.d[i] = 0; continue; }
      if (W.inf[i] || !(od > 0)) { R.ux[i] = W.ux[i]; R.uy[i] = W.uy[i]; R.uz[i] = W.uz[i]; R.m[i] = W.v[i]; R.d[i] = W.d[i]; continue; }
      // (la RESTA de los dos vectores: de donde se mira a la estrella)
      var dx = W.x[i] - ox, dy = W.y[i] - oy, dz = W.z[i] - oz, d1 = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (!(d1 > 1e-6)) { R.m[i] = NaN; R.d[i] = 0; continue; }
      R.ux[i] = dx / d1; R.uy[i] = dy / d1; R.uz[i] = dz / d1; R.d[i] = d1;
      R.m[i] = W.v[i] + 5 * Math.log(d1 / W.d[i]) / LN10;
   }
   if (od > 0) {
      // el Sol, desde alli: en la direccion contraria a la de la estrella desde el Sol
      var sx = -ox / od, sy = -oy / od, sz = -oz / od, rd = c3SkyDirToRaDec(sx, sy, sz);
      R.sun = { ux: sx, uy: sy, uz: sz, ra: rd.ra, dec: rd.dec, d: od, m: C3_SKYCAT.SUN_MV + 5 * Math.log(od / 10) / LN10 };
   }
   var ord = [];
   for (i = 0; i < n; ++i) if (isFinite(R.m[i])) ord.push(i);
   ord.sort(function(a, b) { return R.m[b] - R.m[a]; });
   R.order = ord;
   return R;
}

// LA MIRADA: base { f (adelante), e (este), nn (norte) } en (ra, dec). El norte celeste arriba.
function c3SkyBasis(ra, dec) {
   var k = Math.PI / 180, a = ra * k, d = dec * k, ca = Math.cos(a), sa = Math.sin(a), cd = Math.cos(d), sd = Math.sin(d);
   return { ra: ra, dec: dec, f: [cd * ca, cd * sa, sd], e: [-sa, ca, 0], nn: [-sd * ca, -sd * sa, cd] };
}
// ESTEREOGRAFICA: (X, Y) en radianes «de pantalla» (X hacia el este, Y al norte), o null detras (c < cmin).
// X = 2 x'/(1 + c): en el centro, 1 unidad = 1 radian.
function c3SkyStereo(B, ux, uy, uz, out, cmin) {
   var c = ux * B.f[0] + uy * B.f[1] + uz * B.f[2];
   if (c < (cmin === undefined ? -0.95 : cmin)) return false;
   var xe = ux * B.e[0] + uy * B.e[1] + uz * B.e[2], yn = ux * B.nn[0] + uy * B.nn[1] + uz * B.nn[2], q = 2 / (1 + c);
   out.X = xe * q; out.Y = yn * q; out.c = c;
   return true;
}
// La inversa: (X, Y) -> direccion unitaria [x, y, z].
function c3SkyStereoInv(B, X, Y) {
   var r = Math.sqrt(X * X + Y * Y);
   if (!(r > 0)) return [B.f[0], B.f[1], B.f[2]];
   var th = 2 * Math.atan(r / 2), s = Math.sin(th), c = Math.cos(th), ex = X / r, ny = Y / r;
   return [c * B.f[0] + s * (ex * B.e[0] + ny * B.nn[0]), c * B.f[1] + s * (ex * B.e[1] + ny * B.nn[1]), c * B.f[2] + s * (ex * B.e[2] + ny * B.nn[2])];
}
// Pixeles por radian (en el centro) para que el campo horizontal `fovDeg` llene el ancho `w`.
function c3SkyStereoK(w, fovDeg) { return (w / 2) / (2 * Math.tan(Math.max(1, Math.min(359, fovDeg)) * Math.PI / 180 / 4)); }
// HAMMER-AITOFF alrededor de la base B: { x, y } en [−2√2, 2√2] × [−√2, √2], el este a la izquierda (x negativa) — igual que c3Hammer.
function c3SkyHammerVec(B, ux, uy, uz, out) {
   var fw = ux * B.f[0] + uy * B.f[1] + uz * B.f[2], ea = ux * B.e[0] + uy * B.e[1] + uz * B.e[2], no = ux * B.nn[0] + uy * B.nn[1] + uz * B.nn[2];
   var lon = Math.atan2(ea, fw), lat = Math.asin(Math.max(-1, Math.min(1, no))), den = Math.sqrt(1 + Math.cos(lat) * Math.cos(lon / 2));
   out.x = -2 * Math.SQRT2 * Math.cos(lat) * Math.sin(lon / 2) / den; out.y = Math.SQRT2 * Math.sin(lat) / den; out.lon = lon;
   return true;
}
// La inversa de Hammer: (x, y) -> direccion, o null fuera de la elipse.
function c3SkyHammerInv(B, x, y) {
   if (x * x / 8 + y * y / 2 > 1) return null;
   var xe = -x, z = Math.sqrt(1 - xe * xe / 16 - y * y / 4), lon = 2 * Math.atan2(z * xe, 2 * (2 * z * z - 1)), lat = Math.asin(Math.max(-1, Math.min(1, z * y)));
   var fw = Math.cos(lat) * Math.cos(lon), ea = Math.cos(lat) * Math.sin(lon), no = Math.sin(lat);
   return [fw * B.f[0] + ea * B.e[0] + no * B.nn[0], fw * B.f[1] + ea * B.e[1] + no * B.nn[1], fw * B.f[2] + ea * B.e[2] + no * B.nn[2]];
}
// Mover la mirada arrastrando (dxPix, dyPix) con k pixeles por radian: el cielo sigue al raton.
function c3SkyGazeDrag(ra, dec, dxPix, dyPix, k) {
   var cd = Math.max(0.05, Math.cos(dec * Math.PI / 180)), r2 = ra + (dxPix / k) * 180 / Math.PI / cd, d2 = dec + (dyPix / k) * 180 / Math.PI;
   r2 = ((r2 % 360) + 360) % 360;
   return { ra: r2, dec: Math.max(-89.9, Math.min(89.9, d2)) };
}
// El centro (direccion media) de una figura vista desde alli: la suma de sus direcciones, normalizada.
function c3SkyCentroid(R, idxs) {
   var x = 0, y = 0, z = 0, n = 0;
   for (var i = 0; i < idxs.length; ++i) { var q = idxs[i]; if (q < 0 || !isFinite(R.m[q])) continue; x += R.ux[q]; y += R.uy[q]; z += R.uz[q]; ++n; }
   var r = Math.sqrt(x * x + y * y + z * z);
   return (n > 0 && r > 0) ? [x / r, y / r, z / r] : null;
}
