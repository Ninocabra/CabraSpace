// ============================================================================
// tm/galaxy.js — EL POTENCIAL DE LA VIA LACTEA y las ORBITAS de verdad (Cabra3D, A7, 15-oct-2026)
// ----------------------------------------------------------------------------
// Para la maquina del tiempo mas alla de ~1 Myr las rectas ya no valen (docs/maquina_del_tiempo.md §5).
// Aqui se integra la orbita de cada estrella Y la del Sol en un potencial de la Galaxia, y lo que se
// enseña es la diferencia (donde se ve la estrella desde el Sol), en el marco ICRS de la foto.
//
// EL POTENCIAL (23-oct-2026, tarde, decisión G1 de Nino: UN SOLO potencial en todo, el mejor): `MilkyWayPotential2022` de gala (v2;
// ajustado a la curva de rotación de Eilers et al. 2019), el de CabraShared/csh_galdyn.js —el mismo de la vista galáctica de Cabra3D y
// de CabraComposition (CabraComposition/docs/potencial_g1.md §7b)—. Aquí solo se cambian las unidades (csh_galdyn.js va en kpc y km/s;
// esto en pc y años) y el marco: R0 = 8 122 pc (GRAVITY 2018), z⊙ = 20,8 pc, v⊙ = (12,9; 245,6; 7,78) km/s galactocéntrica (Drimmel y
// Poggio 2018: el marco de astropy 4.0), vc(R0) = la del potencial, 229,4 km/s.
// ANTES (hasta el 23-oct por la mañana): MWPotential2014 (Bovy 2015) con R0 = 8 kpc, vc = 220 km/s, el Sol con (U, V + vc, W) de
// Schönrich 2010 y un bulbo de ley de potencias con su tabla Γ: a ±100 Myr el Sol quedaba ~4° de azimut lejos del de la vista
// galáctica (c3_gx_cases INFO, «la costura de los dos potenciales»). Ahora la costura es 0 (el mismo potencial y el mismo Sol).
// Lo que NINGUNO tiene: brazos espirales, la barra, nubes moleculares, encuentros (lo que acaba dispersando de verdad a las estrellas).
// Necesita CabraShared/csh_galdyn.js (lo incluyen Cabra3D.js y CabraStarAnalysis.js; las pruebas de node lo cargan antes).
//
// LA INTEGRACION: salto de rana (cinetico-deriva-cinetico), paso fijo, simplectica y reversible: la energia no deriva
// (test G2). Desde el 2-nov-2026 (decisión 2 de Nino) los miembros de un cúmulo sienten ademas su Plummer RIGIDO, centrado en
// la orbita del centro del cumulo (tm/timemachine.js, c3TmClusterSetup); antes eran particulas de prueba y se «evaporaban».
// Unidades: pc, años, pc/año. ES5 puro (node lo ejecuta: tests/c3_tm_cases.js).
// ============================================================================

var C3_GAL = {
   R0: 8122, Z0: 20.8,             // pc: = CSH_GD.R0_KPC, CSH_GD.ZSUN_KPC (GRAVITY 2018; Bennett y Bovy 2019)
   VSUN: [12.9, 245.6, 7.78],      // km/s: la velocidad galactocéntrica del Sol (= CSH_GD.VSUN_GC: Drimmel y Poggio 2018)
   MODEL: "MilkyWayPotential2022", // (el nombre, para los textos: gala v2, Eilers et al. 2019)
   DT_MAX: 2.5e5                    // años: el paso mas largo (una orbita del Sol, ~225 Myr, son ~900 pasos; la vertical, ~320)
};
// (de km²/s² por kpc a pc/año²: (km/s → pc/año)² / 1 000 pc)
function c3GalKmsPcyr2() { return C3_TM.KMS_PCYR * C3_TM.KMS_PCYR; }

// LA ACELERACION (pc/año²) en (x, y, z) pc, centro galactico en el origen, z hacia el polo norte galactico. out = [ax, ay, az].
var C3_GAL_TMP = [0, 0, 0];
function c3GalAccel(x, y, z, out) {
   var k = c3GalKmsPcyr2() / 1000, a = cshGdAcc(x / 1000, y / 1000, z / 1000, C3_GAL_TMP);
   out[0] = a[0] * k; out[1] = a[1] * k; out[2] = a[2] * k;
   return out;
}
// La energia potencial por unidad de masa (pc²/año²; para comprobar que el salto de rana la conserva).
function c3GalPhi(x, y, z) { return cshGdPotential(x / 1000, y / 1000, z / 1000) * c3GalKmsPcyr2(); }
// La velocidad circular (km/s) en R (pc), en el plano.
function c3GalVc(R) { return cshGdVcirc(R / 1000); }

// EL SOL en el marco galactocentrico (ejes paralelos a los galacticos heliocentricos: X hacia el centro, Y en el sentido de la
// rotacion, Z al polo norte). Posicion (pc) y velocidad (pc/año): la de astropy 4.0 (= cshGdSunState de csh_galdyn.js, en pc).
function c3GalSun() {
   var k = C3_TM.KMS_PCYR, u = C3_GAL.VSUN;
   return { x: -C3_GAL.R0, y: 0, z: C3_GAL.Z0, vx: u[0] * k, vy: u[1] * k, vz: u[2] * k };
}

// (2-nov-2026, decisiones 2 y 6 de Nino; docs/investigacion_orbitas_largo_plazo.md §3.4-3.5) COSTURAS de los rojos:
//   C3_TM_HERMITE = false  → la interpolación LINEAL de antes entre las K muestras de la tabla (180–280 pc de error a ±1 Ga);
//   C3_TM_PLUMMER = false  → sin la gravedad propia de los cúmulos (sus miembros, partículas de prueba: se «evaporan» en ~30 Ma).
var C3_TM_HERMITE = true;
var C3_TM_PLUMMER = true;

// Cuántos pasos da c3GalIntegrate para `times` con `dtMax` (la misma cuenta que su bucle: el centro de un cúmulo y sus miembros
// tienen que dar EXACTAMENTE los mismos pasos para que cada miembro sienta al centro en su sitio de ese paso).
function c3GalSteps(times, dtMax) {
   var t = 0, q = 0, dm = dtMax || C3_GAL.DT_MAX;
   for (var k = 0; k < times.length; ++k) { q += Math.max(1, Math.ceil(Math.abs(times[k] - t) / dm)); t = times[k]; }
   return q;
}
// LA BARRA (decisión 4; CabraShared/csh_galdyn.js `cshGdBarAdd`): su giro depende del instante. El ángulo de cada paso, una vez para
// todas las estrellas (todas dan los mismos pasos): Float64Array [cos, sin] por paso, o null sin barra.
function c3GalBarCS(times, dtMax) {
   if (typeof cshGdBarOn !== "function" || !cshGdBarOn()) return null;
   var n = c3GalSteps(times, dtMax), cs = new Float64Array(2 * (n + 1)), t = 0, q = 0, dm = dtMax || C3_GAL.DT_MAX, B = [0, 0];
   cshGdBarAngle(0, B); cs[0] = B[0]; cs[1] = B[1];
   for (var k = 0; k < times.length; ++k) {
      var span = times[k] - t, m = Math.max(1, Math.ceil(Math.abs(span) / dm)), dt = span / m;
      for (var j = 1; j <= m; ++j) { ++q; cshGdBarAngle((t + j * dt) / 1e6, B); cs[2 * q] = B[0]; cs[2 * q + 1] = B[1]; }
      t = times[k];
   }
   return cs;
}
var C3_GAL_TMPB = [0, 0, 0];
// La aceleración (pc/año²) con la barra en el paso q (cs = c3GalBarCS) y con el Plummer rígido de un cúmulo (pl = { gm pc³/año²,
// a2 pc², track: el centro en cada paso }).
function c3GalAccelQ(x, y, z, q, cs, pl, out) {
   c3GalAccel(x, y, z, out);
   if (cs !== null) {
      var k = c3GalKmsPcyr2() / 1000;
      C3_GAL_TMPB[0] = 0; C3_GAL_TMPB[1] = 0; C3_GAL_TMPB[2] = 0;
      cshGdBarAdd(x / 1000, y / 1000, z / 1000, cs[2 * q], cs[2 * q + 1], C3_GAL_TMPB);
      out[0] += C3_GAL_TMPB[0] * k; out[1] += C3_GAL_TMPB[1] * k; out[2] += C3_GAL_TMPB[2] * k;
   }
   if (pl !== null) {
      var T = pl.track, dx = x - T[3 * q], dy = y - T[3 * q + 1], dz = z - T[3 * q + 2], s2 = dx * dx + dy * dy + dz * dz + pl.a2, f = pl.gm / (s2 * Math.sqrt(s2));
      out[0] -= f * dx; out[1] -= f * dy; out[2] -= f * dz;
   }
   return out;
}

// INTEGRAR un estado galactocentrico: posiciones en los instantes `times` (crecientes en |t|, todos del mismo signo, empezando
// por 0 o no). Devuelve Float64Array de 3·len (x, y, z). Paso fijo: el mayor ≤ DT_MAX que divide el intervalo entre muestras.
// opt (2-nov): { outV: Float64Array(3·len) para las velocidades en esos instantes (la interpolación de Hermite), track: Float64Array
// donde apuntar la posición tras cada paso (el centro de un cúmulo), plummer: { gm, a2, track } (la gravedad del cúmulo), bar: c3GalBarCS }.
function c3GalIntegrate(s, times, dtMax, opt) {
   var n = times.length, out = new Float64Array(3 * n), a = [0, 0, 0], x = s.x, y = s.y, z = s.z, vx = s.vx, vy = s.vy, vz = s.vz, t = 0, dm = dtMax || C3_GAL.DT_MAX;
   var o = opt || {}, outV = o.outV || null, track = o.track || null, pl = o.plummer || null, cs = o.bar || null, q = 0;
   if (track !== null) { track[0] = x; track[1] = y; track[2] = z; }
   c3GalAccelQ(x, y, z, 0, cs, pl, a);
   for (var k = 0; k < n; ++k) {
      var span = times[k] - t, m = Math.max(1, Math.ceil(Math.abs(span) / dm)), dt = span / m;
      for (var j = 0; j < m; ++j) {
         vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
         x += dt * vx; y += dt * vy; z += dt * vz;
         ++q;
         if (track !== null) { track[3 * q] = x; track[3 * q + 1] = y; track[3 * q + 2] = z; }
         c3GalAccelQ(x, y, z, q, cs, pl, a);
         vx += 0.5 * dt * a[0]; vy += 0.5 * dt * a[1]; vz += 0.5 * dt * a[2];
      }
      t = times[k];
      out[3 * k] = x; out[3 * k + 1] = y; out[3 * k + 2] = z;
      if (outV !== null) { outV[3 * k] = vx; outV[3 * k + 1] = vy; outV[3 * k + 2] = vz; }
   }
   s.end = { x: x, y: y, z: z, vx: vx, vy: vy, vz: vz };
   return out;
}

// LA TABLA DE ORBITAS de la maquina del tiempo: para cada estrella de `tm`, donde se la ve desde el Sol (ICRS, pc) en K
// instantes de −R a +R alrededor de la foto. Se integra la estrella Y el Sol en el potencial, y se resta. `onProgress( f )`
// (0…1) para la barra. Devuelve { R, K, times, rel: Float32Array(n·K·3) } y la deja en tm.orbit.
// (2-nov-2026) Con la tabla van también las VELOCIDADES relativas (`vel`, pc/año, ICRS): c3TmOrbitAt interpola con Hermite cúbica.
// Y LOS CÚMULOS (tm.cls, c3TmClusterSetup): la órbita de su centro (`cRel`, `cVel`) y, si tiene masa, cada miembro siente además su
// Plummer rígido centrado en ese centro (decisión 2 de Nino).
// La estrella (o el centro) i en el estado galactocentrico de la foto.
function c3GalStateOf(e, sun) {
   var g = c3TmMul(C3_TM_AG, [e.x, e.y, e.z]), gv = c3TmMul(C3_TM_AG, [e.vx, e.vy, e.vz]);
   return { g: g, gv: gv, x: sun.x + g[0], y: sun.y + g[1], z: sun.z + g[2], vx: sun.vx + gv[0], vy: sun.vy + gv[1], vz: sun.vz + gv[2] };
}
// Guarda en rel/vel (fila r) la posicion y velocidad relativas al Sol (ICRS) en las K muestras.
function c3GalPutRows(rel, vel, r, K, half, s0, F, FV, B, BV, sF, sFV, sB, sBV) {
   for (var k = 0; k < K; ++k) {
      var dx, dy, dz, ux, uy, uz;
      if (k === half) { dx = s0.g[0]; dy = s0.g[1]; dz = s0.g[2]; ux = s0.gv[0]; uy = s0.gv[1]; uz = s0.gv[2]; }
      else if (k > half) { var f = 3 * (k - half - 1); dx = F[f] - sF[f]; dy = F[f + 1] - sF[f + 1]; dz = F[f + 2] - sF[f + 2]; ux = FV[f] - sFV[f]; uy = FV[f + 1] - sFV[f + 1]; uz = FV[f + 2] - sFV[f + 2]; }
      else { var b = 3 * (half - k - 1); dx = B[b] - sB[b]; dy = B[b + 1] - sB[b + 1]; dz = B[b + 2] - sB[b + 2]; ux = BV[b] - sBV[b]; uy = BV[b + 1] - sBV[b + 1]; uz = BV[b + 2] - sBV[b + 2]; }
      var ic = c3TmMulT(C3_TM_AG, [dx, dy, dz]), iv = c3TmMulT(C3_TM_AG, [ux, uy, uz]), o = (r * K + k) * 3;
      rel[o] = ic[0]; rel[o + 1] = ic[1]; rel[o + 2] = ic[2];
      vel[o] = iv[0]; vel[o + 1] = iv[1]; vel[o + 2] = iv[2];
   }
}
function c3TmOrbitTable(tm, R, K, onProgress) {
   K = K || 161;
   var half = (K - 1) / 2, fwd = [], bwd = [], i, k, times = new Float64Array(K);
   for (k = 1; k <= half; ++k) { fwd.push(R * k / half); bwd.push(-R * k / half); }
   for (k = 0; k < K; ++k) times[k] = -R + 2 * R * k / (K - 1);
   var dtMax = Math.min(C3_GAL.DT_MAX, R / half / 2), nq = c3GalSteps(fwd, dtMax);
   var barF = c3GalBarCS(fwd, dtMax), barB = c3GalBarCS(bwd, dtMax);
   function run(s0, times1, cs, pl, track) {
      var V = new Float64Array(3 * times1.length), P = c3GalIntegrate({ x: s0.x, y: s0.y, z: s0.z, vx: s0.vx, vy: s0.vy, vz: s0.vz }, times1, dtMax, { outV: V, bar: cs, plummer: pl, track: track || null });
      return { P: P, V: V };
   }
   var sun = c3GalSun(), sunS = { x: sun.x, y: sun.y, z: sun.z, vx: sun.vx, vy: sun.vy, vz: sun.vz }, SF = run(sunS, fwd, barF, null), SB = run(sunS, bwd, barB, null);
   // LOS CENTROS de los cúmulos: su órbita (sin su propia gravedad: es la del conjunto) y su sitio en CADA paso, para sus miembros
   var cls = tm.cls || [], nc = cls.length, cRel = new Float32Array(Math.max(1, nc) * K * 3), cVel = new Float32Array(Math.max(1, nc) * K * 3), plOf = {}, c;
   for (c = 0; c < nc; ++c) {
      var cc = cls[c], e0 = c3TmClusterStateAtPhoto(tm, c), s0c = c3GalStateOf(e0, sun), trF = new Float64Array(3 * (nq + 1)), trB = new Float64Array(3 * (nq + 1));
      var CF = run(s0c, fwd, barF, null, trF), CB = run(s0c, bwd, barB, null, trB);
      c3GalPutRows(cRel, cVel, c, K, half, s0c, CF.P, CF.V, CB.P, CB.V, SF.P, SF.V, SB.P, SB.V);
      if (C3_TM_PLUMMER === true && cc.gm > 0 && cc.a > 0) {
         var plF = { gm: cc.gm, a2: cc.a * cc.a, track: trF }, plB = { gm: cc.gm, a2: cc.a * cc.a, track: trB };
         for (var mI = 0; mI < cc.mem.length; ++mI) plOf[cc.mem[mI]] = [plF, plB];
      }
   }
   var rel = new Float32Array(tm.n * K * 3), vel = new Float32Array(tm.n * K * 3), lastTick = 0;
   for (i = 0; i < tm.n; ++i) {
      // el estado de la estrella en la foto (heliocentrico ICRS) -> galactico -> galactocentrico
      var st = c3GalStateOf(c3TmStateAtPhoto(tm, i), sun), pp = plOf[i] || [null, null];
      var F = run(st, fwd, barF, pp[0]), B = run(st, bwd, barB, pp[1]);
      c3GalPutRows(rel, vel, i, K, half, st, F.P, F.V, B.P, B.V, SF.P, SF.V, SB.P, SB.V);
      // (un punto de parada: si `onProgress` devuelve false —cerrando el script—, se deja a medias y no se guarda nada)
      if (typeof onProgress === "function" && (i - lastTick) >= 200) { lastTick = i; if (onProgress(i / tm.n) === false) return null; }
   }
   tm.orbit = { R: R, K: K, times: times, rel: rel, vel: vel, cRel: cRel, cVel: cVel, nc: nc, lsr: tm.lsr, bar: (barF !== null), plummer: (C3_TM_PLUMMER === true) };
   return tm.orbit;
}
// (2-nov-2026, decisión 5b) LA NUBE de la estrella elegida con órbitas: cada estado de la nube (c3TmCloudMake) integrado como las estrellas, con
// la misma escala y las mismas K muestras (Hermite), y la barra si la hay. Sin el Plummer de su cúmulo (la nube es de una estrella).
function c3TmCloudOrbit(tm, cl, R, K) {
   K = K || 161;
   var half = (K - 1) / 2, fwd = [], bwd = [], k;
   for (k = 1; k <= half; ++k) { fwd.push(R * k / half); bwd.push(-R * k / half); }
   var dtMax = Math.min(C3_GAL.DT_MAX, R / half / 2), barF = c3GalBarCS(fwd, dtMax), barB = c3GalBarCS(bwd, dtMax), sun = c3GalSun();
   function run(s0, t1, cs) { var V = new Float64Array(3 * t1.length), P = c3GalIntegrate({ x: s0.x, y: s0.y, z: s0.z, vx: s0.vx, vy: s0.vy, vz: s0.vz }, t1, dtMax, { outV: V, bar: cs }); return { P: P, V: V }; }
   var SF = run(sun, fwd, barF), SB = run(sun, bwd, barB), rel = new Float32Array(cl.n * K * 3), vel = new Float32Array(cl.n * K * 3);
   for (var q = 0; q < cl.n; ++q) {
      var st = c3GalStateOf(cl.st[q], sun), F = run(st, fwd, barF), B = run(st, bwd, barB);
      c3GalPutRows(rel, vel, q, K, half, st, F.P, F.V, B.P, B.V, SF.P, SF.V, SB.P, SB.V);
   }
   cl.orbit = { R: R, K: K, rel: rel, vel: vel };
   return cl.orbit;
}
// BLOQUE F (20-oct): EL MOVIMIENTO SUPUESTO de un objeto del que no se ha medido nada (una nebulosa sin estrellas ni medida en
// SIMBAD): que gira con la Galaxia en su sitio, en una ORBITA CIRCULAR de este mismo potencial (vc(R) de MilkyWayPotential2022, en el
// plano y en el sentido de la rotacion), visto desde el Sol (se le resta la velocidad del Sol, la galactocéntrica de astropy). Es lo que haria
// un objeto en reposo respecto al disco: lo cercano lo «arrastra» casi solo el movimiento peculiar del Sol (~18 km/s), y la
// rotacion diferencial suma unos km/s por kpc. En «Galactic orbits» sigue esa misma orbita circular: es coherente.
// Devuelve el estado heliocentrico ICRS { x, y, z, vx, vy, vz } y lo mismo como { pmRa, pmDec, rv } (c3TmPmRv).
function c3GalRotationRel(ra, dec, d) {
   var s0 = c3TmState(ra, dec, d, 0, 0, 0), g = c3TmMul(C3_TM_AG, [s0.x, s0.y, s0.z]), sun = c3GalSun();
   var X = sun.x + g[0], Y = sun.y + g[1], R = Math.sqrt(X * X + Y * Y);
   if (!(R > 1)) return null;
   var vc = c3GalVc(R) * C3_TM.KMS_PCYR, vx = vc * Y / R - sun.vx, vy = -vc * X / R - sun.vy, vz = -sun.vz;   // (en el Sol, X = −R0: v = (0, +vc, 0))
   var v = c3TmMulT(C3_TM_AG, [vx, vy, vz]), st = { x: s0.x, y: s0.y, z: s0.z, vx: v[0], vy: v[1], vz: v[2] }, pr = c3TmPmRv(st);
   return { state: st, pmRa: pr.pmRa, pmDec: pr.pmDec, rv: pr.rv, vcKms: vc / C3_TM.KMS_PCYR, R: R };
}
// Donde se ve la estrella i en el instante T segun la tabla (|T| > R se queda en el borde).
// (2-nov-2026, decisión 6) HERMITE CÚBICA con las velocidades de los dos extremos: la lineal cortaba la cuerda del arco que la estrella
// describe vista desde el Sol (error ≈ r θ²/8: 180–280 pc a ±1 Ga, con muestras cada 12,5 Ma); la de Hermite va como θ⁴ (medido en
// tests/c3_tm_cases.js, caso 8.9). Rojo: C3_TM_HERMITE = false.
function c3TmTableAt(rel, vel, O, i, T) {
   var K = O.K, f = (Math.max(-O.R, Math.min(O.R, T)) + O.R) / (2 * O.R) * (K - 1), k = Math.min(K - 2, Math.floor(f)), w = f - k, o = (i * K + k) * 3, p = o + 3;
   if (C3_TM_HERMITE !== true || !vel) return { x: rel[o] + (rel[p] - rel[o]) * w, y: rel[o + 1] + (rel[p + 1] - rel[o + 1]) * w, z: rel[o + 2] + (rel[p + 2] - rel[o + 2]) * w };
   var h = 2 * O.R / (K - 1), w2 = w * w, w3 = w2 * w, a0 = 2 * w3 - 3 * w2 + 1, b0 = (w3 - 2 * w2 + w) * h, a1 = 3 * w2 - 2 * w3, b1 = (w3 - w2) * h;
   return { x: a0 * rel[o] + b0 * vel[o] + a1 * rel[p] + b1 * vel[p],
            y: a0 * rel[o + 1] + b0 * vel[o + 1] + a1 * rel[p + 1] + b1 * vel[p + 1],
            z: a0 * rel[o + 2] + b0 * vel[o + 2] + a1 * rel[p + 2] + b1 * vel[p + 2] };
}
function c3TmOrbitAt(tm, i, T) { var O = tm.orbit; return c3TmTableAt(O.rel, O.vel, O, i, T); }
// El CENTRO del cúmulo c (el de tm.cls) en el instante T, de la tabla.
function c3TmClusterOrbitAt(tm, c, T) { var O = tm.orbit; return c3TmTableAt(O.cRel, O.cVel, O, c, T); }
