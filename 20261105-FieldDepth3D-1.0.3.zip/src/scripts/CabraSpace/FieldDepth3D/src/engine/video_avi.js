// [Cabra3D] COPIA de CabraPilot, rama integracion-1410c (097fba6), CabraCore/src/engine/video_avi.js (14-oct-2026). Costuras de Cabra3D marcadas «Cabra3D:»; ver tools/patch_copies.js.
// ============================================================================
// engine/video_avi.js — ESCRIBIR UN VIDEO SIN DEPENDENCIAS: AVI con MJPEG
// ----------------------------------------------------------------------------
// (13-oct-2026.) En la maquina de Nino no hay ffmpeg (ni en el PATH ni dentro de
// PixInsight) y el producto no puede depender de Python. Un AVI con video MJPEG
// se escribe con lo que hay: cada fotograma es un JPEG —que PJSR sabe guardar,
// `Bitmap.save( ruta.jpg, calidad )`— y el AVI es un RIFF con tres cabeceras, la
// lista de fotogramas y un indice:
//
//   RIFF <n> 'AVI '
//     LIST <192> 'hdrl'
//        'avih' <56>   la cabecera del fichero (cuantos fotogramas, tamaño, ritmo)
//        LIST <116> 'strl'
//           'strh' <56>   la del flujo de video ('vids', 'MJPG', ritmo = dwRate / dwScale)
//           'strf' <40>   BITMAPINFOHEADER (ancho, alto, 24 bits, 'MJPG')
//     LIST <n> 'movi'
//        '00dc' <n> …un JPEG entero… [un byte de relleno si n es impar]     × fotogramas
//     'idx1' <16 × fotogramas>
//        '00dc' 0x10 <donde empieza su trozo, contado desde la palabra 'movi'> <n>
//
// La cabecera mide SIEMPRE 224 bytes: se escribe primero con ceros en lo que aun
// no se sabe y al cerrar se vuelve sobre ella. No se acumula el video en memoria:
// fotograma → JPEG temporal → sus bytes al final del fichero → fuera el temporal.
//
// MEDIDO en `_tests/cp_video_avi_probe.log` y `cp_video_avi_probe2.log` (1.9.5 build
// 1706, V8), que es lo que decide como esta escrito esto:
//   · `new ByteArray( Uint8Array )` FUNCIONA (1 MB, 1 ms) y `ByteArray.toUint8Array()` tambien;
//     `new ByteArray( [1, 2, 3] )` LANZA, y `assign( a, b )` no es «pon b en a»: RELLENA;
//   · `File.write( ByteArray )`, `File.position` (leer y poner), y `openForReadWrite` +
//     `position = n` + `write` PARCHEAN sin cambiar el tamaño del fichero;
//   · `SeekMode_FromBegin`, `DataType_UInt32` y `DataType_ByteArray` NO existen: no hay
//     forma conocida de leer un TROZO; para validar se lee el fichero entero (`File.readFile`);
//   · `Bitmap.save( .jpg, calidad )` hace caso de la calidad y tarda 10 ms a 1280 × 720,
//     18 ms a 1920 × 1080 y 53 ms a 3840 × 2160; el JPEG empieza por FF D8 y acaba en FF D9.
//
// LA PARTE PURA (las cabeceras, el indice, el escritor sobre una «io» cualquiera y
// el validador) la ejecuta node: guardian L0-96, `_tests/cp_starfield_flight_cases.js`.
// La parte de PJSR (la «io» sobre `File`, el JPEG temporal, ffmpeg si lo hay) va al
// final y es corta. ES5. (OJO: ni `VERSION` ni `TITLE` como identificadores.)
// ============================================================================

var CP_AVI = {
   HEADER_BYTES: 224,
   // UN AVI CLASICO NO PASA DE 2 GB con garantias (el tamaño del RIFF es de 32 bits y muchos lectores lo tratan
   // con signo). Se parte ANTES, con holgura. (OpenDML / AVIX no esta hecho: se parte en ficheros.)
   LIMIT: 2000000000,
   VALIDATE_MAX: 600000000,           // el validador de PJSR lee el fichero ENTERO: por encima de esto no se intenta
   MP4_TIMEOUT_S: 900,
   // EL MP4 (cuando hay ffmpeg). MEDIDO el 13-oct-2026 en el portatil (`_tests/cp_starfield_flight_look.log` y
   // `cp_starfield_flight_check.py`; cifras en README_TESTS): libx264, preset y CRF de aqui; el intermedio es el AVI
   // propio a calidad 97 (doble compresion, medida contra los PNG sin perdida).
   MP4_CRF: 17, MP4_PRESET: "medium", MP4_SOURCE_QUALITY: 97,
   // EL FILTRO DE COLOR, ELEGIDO MIDIENDO (un fotograma sacado del MP4 contra su PNG original, media por canal, de 255):
   // con el filtro `scale` a secas el video salia 3,0 / 3,0 / 3,6 niveles MAS OSCURO (redondea mal); con `colorspace`,
   // 1,5 / 1,8 / 0,7, de los que 0,8 / 1,0 / 0,9 ya los trae el JPEG. Sin convertir (yuvj420p, rango completo) no hay
   // sesgo añadido, pero ese formato lo interpretan mal bastantes moviles y redes.
   MP4_COLOR: "colorspace=space=bt709:ispace=bt470bg:primaries=bt709:iprimaries=bt709:trc=bt709:itrc=bt709:irange=pc:range=tv:format=yuv420p"
};

function cpAviPutU32(a, pos, v) { v = v >>> 0; a[pos] = v & 255; a[pos + 1] = (v >>> 8) & 255; a[pos + 2] = (v >>> 16) & 255; a[pos + 3] = (v >>> 24) & 255; }
function cpAviPutU16(a, pos, v) { a[pos] = v & 255; a[pos + 1] = (v >>> 8) & 255; }
function cpAviPutTag(a, pos, s) { for (var i = 0; i < 4; ++i) a[pos + i] = s.charCodeAt(i) & 255; }
function cpAviGetU32(a, pos) { return (a[pos] | (a[pos + 1] << 8) | (a[pos + 2] << 16) | (a[pos + 3] << 24)) >>> 0; }
function cpAviGetTag(a, pos) { return String.fromCharCode(a[pos], a[pos + 1], a[pos + 2], a[pos + 3]); }

// El ritmo como fraccion: dwRate / dwScale fotogramas por segundo (30 → 30 / 1; 29,97 → 2997 / 100).
function cpAviRate(fps) {
   var f = (fps > 0 && isFinite(fps)) ? fps : 30, scale = 1;
   while (scale < 1000 && Math.abs(f * scale - Math.round(f * scale)) > 1e-9) scale *= 10;
   return { rate: Math.round(f * scale), scale: scale, usec: Math.round(1e6 / f) };
}
// Lo que ocupa un fotograma en la lista: su cabecera de 8, sus bytes y el relleno a par.
function cpAviChunkBytes(size) { return 8 + size + (size & 1); }

// LA CABECERA (224 bytes). `frames` fotogramas, `maxFrame` = el mayor (bytes), `moviBytes` = la suma de
// `cpAviChunkBytes` de todos. Con frames = 0 y lo demas a 0 es la cabecera provisional.
function cpAviHeader(width, height, fps, frames, maxFrame, moviBytes) {
   var a = new Uint8Array(CP_AVI.HEADER_BYTES), R = cpAviRate(fps), n = frames >>> 0, idx = 8 + 16 * n;
   cpAviPutTag(a, 0, "RIFF"); cpAviPutU32(a, 4, CP_AVI.HEADER_BYTES - 8 + moviBytes + idx); cpAviPutTag(a, 8, "AVI ");
   cpAviPutTag(a, 12, "LIST"); cpAviPutU32(a, 16, 192); cpAviPutTag(a, 20, "hdrl");
   // avih
   cpAviPutTag(a, 24, "avih"); cpAviPutU32(a, 28, 56);
   cpAviPutU32(a, 32, R.usec);                                   // dwMicroSecPerFrame
   cpAviPutU32(a, 36, Math.ceil(maxFrame * R.rate / R.scale));   // dwMaxBytesPerSec
   cpAviPutU32(a, 40, 0);                                        // dwPaddingGranularity
   cpAviPutU32(a, 44, 0x10);                                     // dwFlags: AVIF_HASINDEX
   cpAviPutU32(a, 48, n);                                        // dwTotalFrames
   cpAviPutU32(a, 52, 0);                                        // dwInitialFrames
   cpAviPutU32(a, 56, 1);                                        // dwStreams
   cpAviPutU32(a, 60, maxFrame);                                 // dwSuggestedBufferSize
   cpAviPutU32(a, 64, width); cpAviPutU32(a, 68, height);        // dwWidth, dwHeight (y cuatro reservados a 0)
   // strl
   cpAviPutTag(a, 88, "LIST"); cpAviPutU32(a, 92, 116); cpAviPutTag(a, 96, "strl");
   cpAviPutTag(a, 100, "strh"); cpAviPutU32(a, 104, 56);
   cpAviPutTag(a, 108, "vids"); cpAviPutTag(a, 112, "MJPG");
   cpAviPutU32(a, 116, 0);                                       // dwFlags
   cpAviPutU32(a, 120, 0);                                       // wPriority, wLanguage
   cpAviPutU32(a, 124, 0);                                       // dwInitialFrames
   cpAviPutU32(a, 128, R.scale); cpAviPutU32(a, 132, R.rate);    // dwScale, dwRate
   cpAviPutU32(a, 136, 0);                                       // dwStart
   cpAviPutU32(a, 140, n);                                       // dwLength
   cpAviPutU32(a, 144, maxFrame);                                // dwSuggestedBufferSize
   cpAviPutU32(a, 148, 0xFFFFFFFF);                              // dwQuality: -1 = la de fabrica del codec
   cpAviPutU32(a, 152, 0);                                       // dwSampleSize
   cpAviPutU16(a, 156, 0); cpAviPutU16(a, 158, 0); cpAviPutU16(a, 160, width); cpAviPutU16(a, 162, height);   // rcFrame
   // strf: BITMAPINFOHEADER
   cpAviPutTag(a, 164, "strf"); cpAviPutU32(a, 168, 40);
   cpAviPutU32(a, 172, 40); cpAviPutU32(a, 176, width); cpAviPutU32(a, 180, height);
   cpAviPutU16(a, 184, 1); cpAviPutU16(a, 186, 24);              // biPlanes, biBitCount
   cpAviPutTag(a, 188, "MJPG");                                  // biCompression
   cpAviPutU32(a, 192, width * height * 3);                      // biSizeImage (y cuatro campos a 0)
   // movi
   cpAviPutTag(a, 212, "LIST"); cpAviPutU32(a, 216, 4 + moviBytes); cpAviPutTag(a, 220, "movi");
   return a;
}
// EL INDICE: el trozo 'idx1' entero. `sizes` = los bytes de cada fotograma, por orden.
function cpAviIndex(sizes) {
   var n = sizes.length, a = new Uint8Array(8 + 16 * n), off = 4;
   cpAviPutTag(a, 0, "idx1"); cpAviPutU32(a, 4, 16 * n);
   for (var i = 0; i < n; ++i) {
      var p = 8 + 16 * i;
      cpAviPutTag(a, p, "00dc"); cpAviPutU32(a, p + 4, 0x10);    // AVIIF_KEYFRAME: en MJPEG todos lo son
      cpAviPutU32(a, p + 8, off); cpAviPutU32(a, p + 12, sizes[i]);
      off += cpAviChunkBytes(sizes[i]);
   }
   return a;
}
// Lo que medira el fichero con esos fotogramas.
function cpAviFileBytes(sizes) {
   var movi = 0;
   for (var i = 0; i < sizes.length; ++i) movi += cpAviChunkBytes(sizes[i]);
   return CP_AVI.HEADER_BYTES + movi + 8 + 16 * sizes.length;
}

// ¿CABE? Antes de grabar: con `frames` fotogramas de unos `bytesPerFrame` cada uno.
// Devuelve { ok (cabe en UN fichero), bytes, limit, parts (en cuantos ficheros se parte), framesPerPart,
//            advice: lo que se puede hacer para que quepa en uno ("lower-quality", "lower-resolution") }.
function cpAviPlan(width, height, fps, frames, bytesPerFrame, limit) {
   var L = (limit > 0) ? limit : CP_AVI.LIMIT, per = cpAviChunkBytes(Math.max(1, Math.round(bytesPerFrame))) + 16, n = Math.max(0, Math.round(frames));
   var bytes = CP_AVI.HEADER_BYTES + 8 + per * n, fpp = Math.max(1, Math.floor((L - CP_AVI.HEADER_BYTES - 8) / per)), parts = Math.max(1, Math.ceil(n / fpp));
   return { ok: (parts === 1), bytes: bytes, limit: L, parts: parts, framesPerPart: fpp, advice: (parts === 1) ? [] : ["lower-quality", "lower-resolution"] };
}

// Lo que hay que saber de un fotograma (un `Uint8Array`, o un `ByteArray` de PJSR): cuanto mide y si es un JPEG entero.
function cpAviBlob(blob) {
   var n = blob ? blob.length : 0, f = function(i) { return blob[i] & 255; };   // (20-oct: ByteArray.at() esta obsoleta; el operador [] vale para ByteArray y Uint8Array)
   if (!(n >= 4)) return { length: n, jpeg: false };
   return { length: n, jpeg: (f(0) === 0xFF && f(1) === 0xD8 && f(n - 2) === 0xFF && f(n - 1) === 0xD9) };
}
// El nombre de la parte k (1, 2, 3…) de un video partido: video.avi, video_part2.avi, video_part3.avi…
function cpAviPartPath(path, k) {
   if (k <= 1) return path;
   var dot = path.lastIndexOf("."), slash = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
   return (dot > slash) ? path.substring(0, dot) + "_part" + k + path.substring(dot) : path + "_part" + k;
}

// EL ESCRITOR, sobre una «io» cualquiera (la de PJSR es `cpAviIo`; los tests de node le dan una en memoria):
//   io.create( ruta )            abre el fichero para escribir (lo trunca)
//   io.write( bytes )            añade al final (un Uint8Array, o lo que `io` sepa escribir)
//   io.close()
//   io.patch( ruta, pos, bytes ) vuelve a un fichero ya cerrado y sobrescribe ahi, sin cambiar su tamaño
// Devuelve { add( fotograma ) -> { ok, why }, close() -> { ok, why, frames, bytes, files: [ { path, frames, bytes } ] },
//            abort(), frames(), bytes() }. `opts.limit` = el tope por fichero: al llegar, se cierra esa parte y se
// abre la siguiente sola (`cpAviPartPath`). Un fotograma que no es un JPEG entero NO se escribe (y se dice).
function cpAviWriter(io, path, width, height, fps, opts) {
   var o = opts || {}, limit = (o.limit > 0) ? o.limit : CP_AVI.LIMIT, files = [], cur = null, total = 0, failed = "", closed = false;
   function begin() {
      var p = cpAviPartPath(path, files.length + 1);
      io.create(p);
      io.write(cpAviHeader(width, height, fps, 0, 0, 0));
      cur = { path: p, sizes: [], movi: 0, max: 0 };
   }
   function end() {
      if (cur === null) return;
      var c = cur; cur = null;
      io.write(cpAviIndex(c.sizes));
      io.close();
      io.patch(c.path, 0, cpAviHeader(width, height, fps, c.sizes.length, c.max, c.movi));
      files.push({ path: c.path, frames: c.sizes.length, bytes: CP_AVI.HEADER_BYTES + c.movi + 8 + 16 * c.sizes.length });
   }
   function fail(why) { failed = why; return { ok: false, why: why }; }
   var W = {
      add: function(blob) {
         if (closed) return { ok: false, why: "closed" };
         if (failed) return { ok: false, why: failed };
         var b = cpAviBlob(blob);
         if (!b.jpeg) return { ok: false, why: "not a whole JPEG" };
         try {
            var need = cpAviChunkBytes(b.length) + 16;
            if (cur !== null && cur.sizes.length > 0 && CP_AVI.HEADER_BYTES + cur.movi + 8 + 16 * cur.sizes.length + need > limit) end();
            if (cur === null) begin();
            var head = new Uint8Array(8);
            cpAviPutTag(head, 0, "00dc"); cpAviPutU32(head, 4, b.length);
            io.write(head);
            io.write(blob);
            if (b.length & 1) io.write(new Uint8Array(1));
            cur.sizes.push(b.length); cur.movi += cpAviChunkBytes(b.length);
            if (b.length > cur.max) cur.max = b.length;
            ++total;
         } catch (e) { return fail(String(e)); }
         return { ok: true, why: "" };
      },
      close: function() {
         var out = { ok: false, why: failed, frames: total, bytes: 0, files: files };
         if (closed) { out.why = "closed"; return out; }
         closed = true;
         try { end(); } catch (e) { out.why = String(e); try { io.close(); } catch (e2) {} return out; }
         for (var i = 0; i < files.length; ++i) out.bytes += files[i].bytes;
         if (failed) return out;
         if (total === 0) { out.why = "no frames"; return out; }
         out.ok = true;
         return out;
      },
      abort: function() { closed = true; cur = null; try { io.close(); } catch (e) {} },
      frames: function() { return total; },
      bytes: function() { var n = 0; for (var i = 0; i < files.length; ++i) n += files[i].bytes; return n + ((cur !== null) ? CP_AVI.HEADER_BYTES + cur.movi : 0); }
   };
   return W;
}

// EL VALIDADOR: vuelve a LEER un AVI (sus bytes, en un `Uint8Array`) y comprueba que es coherente consigo mismo.
// No se fia de nada de lo que escribio el escritor: recorre los trozos por su tamaño. Devuelve
//   { ok, why: [ lo que no cuadra ], width, height, fps, frames (los que hay en 'movi'), sizes, offsets (desde 'movi'),
//     declared (los que dice la cabecera), indexed (las entradas del indice), bytes }
// QUE COMPRUEBA: RIFF / 'AVI ' y su tamaño contra el del fichero; las tres cabeceras con sus tamaños; que 'avih',
// 'strh' y 'strf' dicen el mismo ancho, alto y numero de fotogramas; 'vids' / 'MJPG' en los dos sitios; cada trozo
// '00dc' empieza por FF D8 y acaba en FF D9; el relleno a par; y el indice: tantas entradas como fotogramas, cada una
// con el sitio y el tamaño DE VERDAD de su trozo.
function cpAviParse(u8) {
   var out = { ok: false, why: [], width: 0, height: 0, fps: 0, frames: 0, sizes: [], offsets: [], declared: 0, indexed: 0, bytes: u8 ? u8.length : 0 }, n = out.bytes;
   function bad(s) { if (out.why.length < 12) out.why.push(s); }
   if (!(n >= CP_AVI.HEADER_BYTES + 8)) { bad("too short"); return out; }
   if (cpAviGetTag(u8, 0) !== "RIFF" || cpAviGetTag(u8, 8) !== "AVI ") { bad("not a RIFF AVI"); return out; }
   if (cpAviGetU32(u8, 4) !== n - 8) bad("RIFF size " + cpAviGetU32(u8, 4) + " != file size - 8 (" + (n - 8) + ")");
   var pos = 12, avih = -1, strh = -1, strf = -1, movi = -1, moviEnd = -1, idx = -1, idxLen = 0;
   function walk(from, to, depth) {
      var p = from;
      while (p + 8 <= to) {
         var tag = cpAviGetTag(u8, p), sz = cpAviGetU32(u8, p + 4), data = p + 8, next = data + sz + (sz & 1);
         if (data + sz > to) { bad("chunk '" + tag + "' at " + p + " runs past its container"); return; }
         if (tag === "LIST") {
            var type = cpAviGetTag(u8, data);
            if (type === "movi") { movi = data; moviEnd = data + sz; }
            else if (depth < 3) walk(data + 4, data + sz, depth + 1);
         } else if (tag === "avih") { avih = data; if (sz !== 56) bad("avih size " + sz); }
         else if (tag === "strh") { strh = data; if (sz !== 56) bad("strh size " + sz); }
         else if (tag === "strf") { strf = data; if (sz < 40) bad("strf size " + sz); }
         else if (tag === "idx1") { idx = data; idxLen = sz; }
         p = next;
      }
      if (p !== to && p !== to + 1) bad("container ending at " + to + " has " + (to - p) + " loose bytes");
   }
   walk(pos, n, 0);
   if (avih < 0 || strh < 0 || strf < 0) { bad("missing avih / strh / strf"); return out; }
   if (movi < 0) { bad("missing movi"); return out; }
   out.width = cpAviGetU32(u8, avih + 32); out.height = cpAviGetU32(u8, avih + 36); out.declared = cpAviGetU32(u8, avih + 16);
   var scale = cpAviGetU32(u8, strh + 20), rate = cpAviGetU32(u8, strh + 24), usec = cpAviGetU32(u8, avih);
   out.fps = (scale > 0) ? rate / scale : 0;
   if (!(out.fps > 0)) bad("no frame rate");
   else if (Math.abs(usec - 1e6 / out.fps) > 1) bad("avih says " + usec + " us per frame and strh says " + out.fps + " fps");
   if (cpAviGetTag(u8, strh) !== "vids" || cpAviGetTag(u8, strh + 4) !== "MJPG") bad("stream is not vids / MJPG");
   if (cpAviGetTag(u8, strf + 16) !== "MJPG") bad("strf compression is not MJPG");
   if (cpAviGetU32(u8, strf + 4) !== out.width || cpAviGetU32(u8, strf + 8) !== out.height) bad("strf size differs from avih");
   if (cpAviGetU32(u8, strh + 32) !== out.declared) bad("strh length " + cpAviGetU32(u8, strh + 32) + " != avih frames " + out.declared);
   if (!(cpAviGetU32(u8, avih + 12) & 0x10)) bad("avih does not flag the index");
   if (cpAviGetU32(u8, avih + 24) !== 1) bad("not exactly one stream");
   // los fotogramas, uno por uno
   var p = movi + 4, maxSz = 0;
   while (p + 8 <= moviEnd) {
      var tag = cpAviGetTag(u8, p), sz = cpAviGetU32(u8, p + 4), d = p + 8;
      if (d + sz > moviEnd) { bad("frame " + out.frames + " runs past movi"); break; }
      if (tag !== "00dc") bad("chunk '" + tag + "' in movi");
      else {
         if (!(sz >= 4 && u8[d] === 0xFF && u8[d + 1] === 0xD8)) bad("frame " + out.frames + " does not start with FF D8");
         else if (!(u8[d + sz - 2] === 0xFF && u8[d + sz - 1] === 0xD9)) bad("frame " + out.frames + " does not end with FF D9");
         out.offsets.push(p - movi); out.sizes.push(sz); ++out.frames;
         if (sz > maxSz) maxSz = sz;
      }
      p = d + sz + (sz & 1);
   }
   if (p !== moviEnd) bad("movi has " + (moviEnd - p) + " loose bytes at its end");
   if (out.frames !== out.declared) bad(out.frames + " frames in movi, the header says " + out.declared);
   if (cpAviGetU32(u8, avih + 28) < maxSz) bad("suggested buffer smaller than the largest frame");
   // el indice
   if (idx < 0) bad("missing idx1");
   else {
      out.indexed = Math.floor(idxLen / 16);
      if (idxLen % 16 !== 0 || out.indexed !== out.frames) bad("idx1 has " + (idxLen / 16) + " entries for " + out.frames + " frames");
      for (var i = 0; i < out.indexed && i < out.frames; ++i) {
         var e = idx + 16 * i, off = cpAviGetU32(u8, e + 8), esz = cpAviGetU32(u8, e + 12);
         if (cpAviGetTag(u8, e) !== "00dc") { bad("index entry " + i + " is not 00dc"); break; }
         if (off !== out.offsets[i] || esz !== out.sizes[i]) { bad("index entry " + i + " points to " + off + " (" + esz + " bytes); the frame is at " + out.offsets[i] + " (" + out.sizes[i] + " bytes)"); break; }
         if (!(cpAviGetU32(u8, e + 4) & 0x10)) { bad("index entry " + i + " is not a keyframe"); break; }
      }
   }
   out.ok = (out.why.length === 0 && out.frames > 0);
   if (out.frames === 0) bad("no frames");
   return out;
}

// ===========================================================================
// LA PARTE DE PJSR (lo de arriba no toca PixInsight)
// ===========================================================================
// La «io» del escritor sobre `File`. Lo que llegue como `Uint8Array` se pasa a `ByteArray`; un `ByteArray` (lo que
// da `File.readFile` de un JPEG) se escribe tal cual, sin pasar por JavaScript.
function cpAviIo() {
   var f = null;
   function bytes(b) { return (b instanceof Uint8Array) ? new ByteArray(b) : b; }
   return {
      create: function(path) { f = new File; f.createForWriting(path); },
      write: function(b) { f.write(bytes(b)); },
      close: function() { if (f !== null) { var g = f; f = null; g.close(); } },
      patch: function(path, pos, b) {
         var g = new File;
         g.openForReadWrite(path);
         try { g.position = pos; g.write(bytes(b)); } finally { g.close(); }
      }
   };
}
// UN VIDEO, de bitmaps. Devuelve el escritor de `cpAviWriter` con dos cosas mas:
//   addBitmap( bitmap, calidad ) -> { ok, why, bytes }     (85, 92 o 97; el JPEG temporal se borra)
//   addJpegFile( ruta )          -> { ok, why, bytes }
// El bitmap tiene que medir lo que se dijo al abrir. `opts` = { limit, tempDir }.
function cpAviOpen(path, width, height, fps, opts) {
   var o = opts || {}, W = cpAviWriter(cpAviIo(), path, width, height, fps, o);
   var dir = String(o.tempDir || File.systemTempDirectory).split("\\").join("/"), tmp = dir + "/cp_avi_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ".jpg";
   W.addJpegFile = function(file) {
      var b = null;
      try { b = File.readFile(file); } catch (e) { return { ok: false, why: String(e), bytes: 0 }; }
      var r = W.add(b);
      return { ok: r.ok, why: r.why, bytes: b.length };
   };
   W.addBitmap = function(bitmap, quality) {
      if (bitmap.width !== width || bitmap.height !== height) return { ok: false, why: "frame is " + bitmap.width + "x" + bitmap.height + ", the video is " + width + "x" + height, bytes: 0 };
      try { bitmap.save(tmp, (quality > 0) ? quality : 92); } catch (e) { return { ok: false, why: String(e), bytes: 0 }; }
      var r = W.addJpegFile(tmp);
      try { File.remove(tmp); } catch (e2) {}
      return r;
   };
   return W;
}
// VALIDAR UN FICHERO ya escrito (lo lee entero: hasta VALIDATE_MAX). Devuelve lo de `cpAviParse`, mas `skipped`
// si era demasiado grande para leerlo (entonces NO esta validado y se dice).
function cpAviValidateFile(path) {
   var size = -1;
   try { size = (new FileInfo(path)).size; } catch (e) {}
   if (!(size > 0)) return { ok: false, why: ["no such file"], frames: 0, skipped: false, bytes: 0 };
   if (size > CP_AVI.VALIDATE_MAX) return { ok: false, why: ["too large to read back"], frames: 0, skipped: true, bytes: size };
   var r;
   try { r = cpAviParse(File.readFile(path).toUint8Array()); } catch (e2) { return { ok: false, why: [String(e2)], frames: 0, skipped: false, bytes: size }; }
   r.skipped = false;
   return r;
}

// ¿HAY ffmpeg? (3-nov-2026, CPD C3) SOLO SI EL USUARIO LO HA ELEGIDO: la decision y la busqueda son de CabraShared/csh_ffmpeg.js
// (cshFfmpegFind), comun a los scripts. De fabrica NO se usa ffmpeg y el video sale en AVI, el camino de serie; con «MP4 · ffmpeg
// chosen by me» se usa el ejecutable que el usuario eligio; con «MP4 · find ffmpeg for me», la busqueda de antes (CABRAPILOT_FFMPEG,
// lo recordado, el PATH, winget). Sin csh_ffmpeg.js incluido, como "off" (nunca se lanza nada sin que se haya elegido).
// No lanza ningun proceso y NUNCA lanza una excepcion. Devuelve { available, path, probe (ffprobe, si esta al lado), from, mode, why }.
// (OJO: ni en un comentario se puede escribir aqui una barra seguida de un asterisco: el preprocesador de PJSR lo toma
// por el principio de un comentario de bloque y el fichero NO COMPILA, sin log. Visto el 13-oct-2026.)
var CP_AVI_FFMPEG_CACHE = null;
// COSTURAS PARA PRUEBAS: si se recuerda lo encontrado (en una pasada sin pantalla, no: las pruebas no tocan lo recordado de verdad).
var CP_AVI_SETTINGS_KEY = CP_SETTINGS_PREFIX + "/Video/ffmpeg";   // (lo ultimo encontrado en «auto»; el modo y la ruta elegida van al lado: csh_ffmpeg.js)
var CP_AVI_REMEMBER = (typeof CP_NO_MAIN === "undefined" || !CP_NO_MAIN);
function cpAviFfmpeg(refresh) {
   if (CP_AVI_FFMPEG_CACHE !== null && refresh !== true) return CP_AVI_FFMPEG_CACHE;
   var out = { available: false, path: "", probe: "", from: "off", mode: "off", why: "csh_ffmpeg.js not included" };
   try { if (typeof cshFfmpegFind === "function") out = cshFfmpegFind(CP_SETTINGS_PREFIX, { remember: CP_AVI_REMEMBER === true }); } catch (e) {}
   CP_AVI_FFMPEG_CACHE = out;
   return out;
}
// Los argumentos de ffmpeg para pasar a MP4 (puro: lo prueba node). `inputs` = lo que va delante (-i …).
//   · H.264 en MP4, `yuv420p` (lo que abre cualquier movil) y `+faststart` (empieza a verse sin bajarlo entero);
//   · EL COLOR: un JPEG lleva matriz BT.601 y rango completo; el video va en BT.709 y rango de video, CONVERTIDO
//     (no solo etiquetado: etiquetar sin convertir cambia los colores) y dicho en el fichero. Con el filtro
//     `colorspace` y SOLO la matriz y el rango (los primarios y la curva ya son los del video): ver CP_AVI.MP4_COLOR;
//   · `opts.encoder` = "libx264" (de fabrica: CRF, el que da la calidad) | "h264_nvenc" (la grafica: mas rapido).
function cpAviMp4Args(inputs, mp4Path, opts) {
   var o = opts || {}, enc = (o.encoder === "h264_nvenc") ? "h264_nvenc" : "libx264", crf = String((o.crf > 0) ? o.crf : CP_AVI.MP4_CRF);
   var a = ["-y", "-hide_banner", "-loglevel", "warning"].concat(inputs);
   a = a.concat(["-vf", CP_AVI.MP4_COLOR, "-an", "-c:v", enc]);
   if (enc === "libx264") a = a.concat(["-preset", String(o.preset || CP_AVI.MP4_PRESET), "-crf", crf]);
   else a = a.concat(["-preset", "p6", "-rc", "vbr", "-cq", crf, "-b:v", "0"]);
   return a.concat(["-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv", "-movflags", "+faststart", mp4Path]);
}
// DE AVI A MP4, si hay ffmpeg. `avi` = una ruta o varias (las partes de un video partido: se pegan). Con tope de
// tiempo y lo que el programa haya dicho. `opts` = { crf, preset, encoder, timeoutS, onTick( s ) -> false cancela }.
// Devuelve { ok, why, seconds, bytes, log, how ("wait" = lo dijo waitForFinished | "state" = se vio por isRunning), ticks, tickMaxMs }.
var C3_AVI_LOSTEXIT = false;   // costura del ROJO de tests/c3_mp4_hang_probe.js: true = el bucle de antes, que solo se fia de waitForFinished
function cpAviToMp4(avi, mp4Path, opts) {
   var o = opts || {}, ff = cpAviFfmpeg(), out = { ok: false, why: "", seconds: 0, bytes: 0, log: "" };
   if (!ff.available) { out.why = "ffmpeg not available"; return out; }
   var list = (avi instanceof Array) ? avi : [avi], inputs = ["-i", String(list[0])], listFile = "";
   var t0 = Date.now(), limit = 1000 * ((o.timeoutS > 0) ? o.timeoutS : CP_AVI.MP4_TIMEOUT_S), p = null;
   try {
      if (list.length > 1) {
         listFile = File.systemTempDirectory.split("\\").join("/") + "/cp_avi_parts_" + Date.now() + ".txt";
         var text = "";
         for (var i = 0; i < list.length; ++i) text += "file '" + String(list[i]).split("\\").join("/").split("'").join("'\\''") + "'\n";
         File.writeTextFile(listFile, text);
         inputs = ["-f", "concat", "-safe", "0", "-i", listFile];
      }
      p = new ExternalProcess;
      p.onStandardOutputDataAvailable = function() { try { out.log += String(p.stdout); } catch (e) {} };
      p.onStandardErrorDataAvailable = function() { try { out.log += String(p.stderr); } catch (e) {} };
      p.start(ff.path, cpAviMp4Args(inputs, mp4Path, o));
      // [Cabra3D, 24-oct-2026] EL FIN SE MIRA TAMBIEN POR EL ESTADO, no solo por lo que devuelve waitForFinished.
      // MEDIDO (CabraComposition `tests/cc_mp4_hang_probe.log`; ficha CabraBase pjsr/waitforfinished-pierde-el-fin-...): si ffmpeg
      // muere mientras `onTick` atiende eventos (el de la interfaz hace processEvents), ese processEvents se come el aviso de
      // «ha terminado» y desde entonces waitForFinished(250) devuelve false AL INSTANTE (isRunning false, exitCode 0): el bucle
      // viejo giraba hasta el tope (900 s) con el MP4 ya escrito entero y lo daba por «timed out». Rojo de la sonda: C3_AVI_LOSTEXIT = true.
      var done = false, lost = (C3_AVI_LOSTEXIT === true), tk;
      out.how = ""; out.ticks = 0; out.tickMaxMs = 0;
      while (!done && Date.now() - t0 < limit) {
         done = p.waitForFinished(250);
         if (done) { out.how = "wait"; break; }
         if (!lost) {
            var running = true;
            try { running = (p.isRunning === true || p.isStarting === true); } catch (eR) {}
            if (!running) { done = true; out.how = "state"; break; }
         }
         if (typeof o.onTick === "function") {
            tk = Date.now();
            var go = o.onTick((Date.now() - t0) / 1000);
            ++out.ticks; out.tickMaxMs = Math.max(out.tickMaxMs, Date.now() - tk);
            if (go === false) break;
         }
      }
      out.seconds = (Date.now() - t0) / 1000;
      if (!done) { try { p.kill(); } catch (eK) {} out.why = (Date.now() - t0 >= limit) ? "timed out" : "cancelled"; }
      else if (p.exitCode !== 0) out.why = "ffmpeg exit code " + p.exitCode;
      else {
         try { out.bytes = (new FileInfo(mp4Path)).size; } catch (eB) {}
         out.ok = (out.bytes > 0);
         if (!out.ok) out.why = "ffmpeg wrote nothing";
      }
   } catch (e2) { out.why = String(e2); }
   try { if (listFile.length > 0) File.remove(listFile); } catch (e3) {}
   if (out.log.length > 4000) out.log = out.log.substring(out.log.length - 4000);
   return out;
}
