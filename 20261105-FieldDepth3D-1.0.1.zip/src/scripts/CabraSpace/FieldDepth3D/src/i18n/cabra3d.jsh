// ============================================================================
// i18n/cabra3d.jsh — LO PROPIO DE Cabra3D: castellano de las cadenas y tooltips (EN y ES)
// ----------------------------------------------------------------------------
// Se fusiona encima de i18n/from_cabrapilot.jsh (lo de los modulos copiados). La interfaz
// se escribe en ingles (`optT("…")`) y aqui va su castellano; los tooltips, por clave.
// ============================================================================

var C3_OWN_ES = {
   "1 galaxy or group": "1 galaxia o grupo", "1 quasar": "1 cuásar",
   "distances, 3D and a time machine": "distancias, 3D y una máquina del tiempo",
   "Image": "Imagen", "Astrometry": "Astrometría", "Solve": "Resolver", "HR diagram": "Diagrama HR", "Distances": "Distancias",
   "Choose an image above": "Elige una imagen arriba",
   "Preparing the photo…": "Preparando la foto…",
   "Open an image in PixInsight first": "Abre antes una imagen en PixInsight",
   "No image is open: open one in PixInsight and press ⟳.": "No hay ninguna imagen abierta: abre una en PixInsight y pulsa ⟳.",
   "Black and white: the colours will come from Gaia": "Blanco y negro: los colores saldrán de Gaia",
   "No colour calibration in its history (SPCC recommended)": "Sin calibración de color en su historial (se recomienda SPCC)",
   "Colour calibrated (%s)": "Color calibrado (%s)",
   "stretched": "estirada", "linear": "lineal",
   "Solved: ImageSolver is not needed": "Resuelta: no hace falta ImageSolver",
   "Not solved: it will be solved when you open a view": "Sin resolver: se resolverá al abrir una vista",
   "%s · %d × %d px · %s": "%s · %d × %d px · %s",
   "Solving the image with ImageSolver…": "Resolviendo la imagen con ImageSolver…",
   "Solved in %s s.": "Resuelta en %s s.",
   "Could not solve the image": "No se ha podido resolver la imagen",
   "not installed": "no instalado",
   "no image is selected.": "no hay ninguna imagen elegida.",
   "ImageSolver cancelled by the user": "ImageSolver cancelado por el usuario",
   "ImageSolver could not start: ": "ImageSolver no ha podido arrancar: ",
   "ImageSolver did not get a valid solution (give it the centre and the pixel scale in its dialog).": "ImageSolver no ha dado una solución válida (dale el centro y la escala del píxel en su diálogo).",
   "The ImageSolver library is not loaded: run Script > Astrometry > ImageSolver on the image and try again.": "La librería de ImageSolver no está cargada: ejecuta Script > Astrometry > ImageSolver sobre la imagen y vuelve a probar.",
   "This image has not been read yet: press «Show in 3D».": "Esta imagen aún no se ha leído: pulsa «Ver en 3D».",
   "stars removed with its own star mask": "estrellas quitadas con su propia máscara de estrellas",
   // --- la maquina del tiempo ---
   "TIME MACHINE": "MÁQUINA DEL TIEMPO",
   "now · the photo": "ahora · la foto", "year": "año", "years": "años", "yr": "años", "kyr": "mil años", "Myr": "Ma", "Gyr": "Ga",
   "year %s": "año %s", "year %s BCE": "año %s a. C.",
   "Straight lines, from the Sun": "Rectas, desde el Sol", "Galactic orbits": "Órbitas galácticas", "Straight lines, from the LSR": "Rectas, desde el LSR",
   "straight lines": "rectas",
   "Beyond ~1 Myr the straight lines drift ~1 % from the real orbits: try «Galactic orbits».": "Pasado ~1 Ma las rectas se separan ~1 % de las órbitas reales: prueba «Órbitas galácticas».",
   "Beyond ~10 Myr straight lines no longer describe the motion (the stars orbit the Galaxy, they do not fly straight): choose «Galactic orbits» in the motion list.": "Pasados ~10 Ma las rectas ya no describen el movimiento (las estrellas giran en torno a la Galaxia, no van en línea recta): elige «Órbitas galácticas» en la lista de movimiento.",
   "The physics and its limits are in docs/maquina_del_tiempo.md (straight-line motion 0.1 % off the orbit at 0.1 Myr, 1 % at 1 Myr, 12 % at 10 Myr; measured).": "La física y sus límites están en docs/maquina_del_tiempo.md (la recta se separa de la órbita un 0,1 % a 0,1 Ma, un 1 % a 1 Ma y un 12 % a 10 Ma; medido).",
   "The time machine needs the astrometric solution of the photo to place the stars.": "La máquina del tiempo necesita la solución astrométrica de la foto para colocar las estrellas.",
   "No star of this field has both a distance and a proper motion: there is nothing to move.": "Ninguna estrella de este campo tiene a la vez distancia y movimiento propio: no hay nada que mover.",
   "(sky only: no radial velocity)": "(solo en el cielo: sin velocidad radial)",
   "apex": "ápex",
   "Taking the stars out of the photo (for the time machine)…": "Quitando las estrellas de la foto (para la máquina del tiempo)…",
   "Asking VizieR for the radial velocities (Gaia DR3)…": "Pidiendo a VizieR las velocidades radiales (Gaia DR3)…",
   "A TIME MACHINE THROUGH": "UNA MÁQUINA DEL TIEMPO POR",
   "Choose a folder for the video (▾ in the flight row).": "Elige una carpeta para el vídeo (▾ en la fila del vuelo).",
   "Could not record the time machine": "No se ha podido grabar la máquina del tiempo",
   "Recording the time machine to %s": "Grabando la máquina del tiempo en %s",
   "Time machine video saved: %s (%s MB, %d frames)": "Vídeo de la máquina del tiempo guardado: %s (%s MB, %d fotogramas)",
   "The dust map (Zenodo) did not answer.": "El mapa de polvo (Zenodo) no contestó.",
   "Dust": "Polvo",
   "Reading the 3D dust map for this field (Edenhofer et al. 2024)…": "Leyendo el mapa 3D de polvo de este campo (Edenhofer et al. 2024)…",
   "Reading the 3D dust map for this field (Edenhofer et al. 2024)… %d %%": "Leyendo el mapa 3D de polvo de este campo (Edenhofer et al. 2024)… %d %%",
   "Asking VizieR for the temperatures of the stars (Gaia DR3)…": "Pidiendo a VizieR las temperaturas de las estrellas (Gaia DR3)…",
   "VizieR did not answer: asking the ESA Gaia archive for the temperatures of the stars (Gaia DR3)…": "VizieR no contestó: pidiendo al archivo de Gaia de la ESA las temperaturas de las estrellas (Gaia DR3)…",
   "The dust map has nothing for this field.": "El mapa de polvo no tiene nada para este campo.",
   "The dust map could not be read": "No se pudo leer el mapa de polvo",
   "Dust: %s lines of sight, %s kB read%s · Edenhofer et al. 2024": "Polvo: %s líneas de visión, %s kB leídos%s · Edenhofer et al. 2024",
   "(from the cache)": "(de la caché)",
   "AV PER KPC": "AV POR KPC",
   "%s: HTTP %s (the server is failing)": "%s: HTTP %s (el servidor está fallando)",
   "%s: HTTP %s (the request was refused)": "%s: HTTP %s (rechazó la consulta)",
   "%s did not answer in time": "%s no contestó a tiempo",
   "%s: nothing in this field": "%s: nada en este campo",
   "%s: no connection (no network?)": "%s: sin conexión (¿sin red?)",
   "Retrying the online sources…": "Reintentando las fuentes de internet…",
   "Retry": "Reintentar",
   "From this PixInsight (local Gaia DR3 database): positions, parallaxes, proper motions and G, BP, RP of %s stars.": "De este PixInsight (la base Gaia DR3 local): posiciones, paralajes, movimientos propios y G, BP, RP de %s estrellas.",
   "distances from the local parallaxes only (no real errors, no RUWE, no Bailer-Jones).": "distancias solo con las paralajes locales (sin sus errores reales, sin RUWE, sin Bailer-Jones).",
   "VizieR: real parallax errors, RUWE and Bailer-Jones distances for %s stars; local against VizieR parallax: median difference %s mas (%s stars differ by more than 0.001 mas and keep the local one).": "VizieR: errores reales de la paralaje, RUWE y distancias de Bailer-Jones de %s estrellas; paralaje local frente a la de VizieR: diferencia mediana %s mas (%s estrellas difieren en más de 0,001 mas y se quedan con la local).",
   "no radial velocities: in the time machine every star is hollow (assumed 0).": "sin velocidades radiales: en la máquina del tiempo todas las estrellas van huecas (se supone 0).",
   "VizieR: %s radial velocities (Gaia DR3)%s.": "VizieR: %s velocidades radiales (Gaia DR3)%s.",
   "Radial velocities uncorrected: the server that answered does not give the RVS magnitude and the ESA archive did not answer, so Gaia's bias (Katz et al. 2023) stays in, about 0.2 km/s.": "Velocidades radiales sin corregir: el servidor que contestó no da la magnitud RVS y el archivo de la ESA no contestó, así que queda el sesgo de Gaia (Katz et al. 2023), unos 0,2 km/s.",
   "SIMBAD answered: no galaxy or quasar with a distance in this field.": "SIMBAD contestó: ninguna galaxia ni cuásar con distancia en este campo.",
   "no galaxies, quasars or nebulae from SIMBAD: stars and clusters only.": "sin galaxias, cuásares ni nebulosas de SIMBAD: solo estrellas y cúmulos.",
   "SIMBAD: the galaxies, quasars and nebulae of the field.": "SIMBAD: las galaxias, cuásares y nebulosas del campo.",
   "no dust map.": "sin mapa de polvo.",
   "Zenodo: the 3D dust map (Edenhofer et al. 2024), %s lines of sight%s.": "Zenodo: el mapa 3D de polvo (Edenhofer et al. 2024), %s líneas de visión%s.",
   "no Gaia temperatures: no check of the reddening.": "sin temperaturas de Gaia: sin comprobación del enrojecimiento.",
   "the dust layer stays off; press «Dust» again to retry (once read, it is kept in a cache).": "la capa de polvo queda apagada; pulsa «Dust» otra vez para reintentar (una vez leído, se guarda en caché).",
   "Show in 3D": "Ver en 3D",
   "Map: Edenhofer et al. 2024, 14' resolution, from %s to %s; beyond, no data. AV = 2.8 × E (their extinction curve).": "Mapa: Edenhofer et al. 2024, resolución de 14', de %s a %s; más allá, sin datos. AV = 2,8 × E (su curva de extinción).",
   "(the map stops at %s)": "(el mapa acaba en %s)",
   "Now": "Ahora", "now": "ahora", "Play": "Reproducir", "Pause": "Pausa", "Trails": "Estelas",
   "Where it is (along the line of sight, median of the field): %s": "Dónde está (a lo largo de la visual, mediana del campo): %s",
   "one layer": "una capa",
   "%s layers": "%s capas",
   "from %s to %s: %s, it dims %s mag": "de %s a %s: %s, apaga %s mag",
   "and %s thinner layers more": "y %s capas más finas",
   "No layer of dense dust: what there is, is spread thin along the way.": "Ninguna capa de polvo denso: el que hay está repartido, tenue, por el camino.",
   "very dense dust": "polvo muy denso",
   "dense dust": "polvo denso",
   "thin dust": "polvo tenue",
   "DUST DENSITY · AV PER KPC": "DENSIDAD DEL POLVO · AV POR KPC",
   "thin": "tenue",
   "dense": "denso",
   "very dense": "muy denso",
   "Dust layers in front of it": "Capas de polvo delante de ella",
   "No layer of dense dust in front of it.": "Ninguna capa de polvo denso delante de ella.",
   "3D VIEW": "VISTA 3D",
   "FLIGHT AND VIDEO": "VUELO Y VÍDEO",
   "the flight": "el vuelo",
   "the time machine: photo + 3D": "la máquina del tiempo: foto + 3D",
   "the time machine: 3D": "la máquina del tiempo: 3D",
   "the time machine: photo": "la máquina del tiempo: foto",
   "%s stars with a doubtful distance are not placed here.": "%s estrellas con una distancia dudosa no se colocan aquí.",
   "Close": "Cerrar",
   "Galactic orbits: each star and the Sun integrated in a model of the Milky Way, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), valid to about 100 Myr.": "Órbitas galácticas: cada estrella y el Sol integrados en un modelo de la Vía Láctea, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), válido hasta unos 100 Ma.",
   "Beyond ~100 Myr the model lacks the bar, the spiral arms and the encounters, which weigh more and more: take it as an illustration.": "Pasados ~100 Ma al modelo le faltan la barra, los brazos espirales y los encuentros, que pesan cada vez más: tómalo como una ilustración.",
   "Beyond ~500 Myr these are no longer the stars' real orbits: the bar, spiral arms and encounters have scattered them.": "Pasados ~500 Ma ya no son las órbitas reales de las estrellas: la barra, los brazos espirales y los encuentros las han dispersado.",
   "The sand-brown haze is interstellar dust. Its thickest layer, at %s, dims what is behind it by about %s magnitudes in visible light; all of it together, by about %s. Where it is thick, it is what makes the dark patches of a photo.": "La bruma pardo arena es polvo interestelar. Su capa más espesa, a %s, apaga lo que hay detrás unas %s magnitudes en luz visible; todo junto, unas %s. Donde es espeso, es lo que hace las manchas oscuras de una foto.",
   "%s stars of the field (%s cluster members at their own Gaia parallax, not at the cluster's distance) · Hammer-Aitoff projection of the whole sky; east to the left · Sun: M_V 4.83, M_G 4.67 · constellations: Roman 1987": "%s estrellas del campo (%s miembros de cúmulo a su propio paralaje de Gaia, no a la distancia del cúmulo) · proyección de Hammer-Aitoff de todo el cielo; el este a la izquierda · Sol: M_V 4,83, M_G 4,67 · constelaciones: Roman 1987",
   "%s stars of the field · Hammer-Aitoff projection of the whole sky; east to the left · Sun: M_V 4.83, M_G 4.67 · constellations: Roman 1987": "%s estrellas del campo · proyección de Hammer-Aitoff de todo el cielo; el este a la izquierda · Sol: M_V 4,83, M_G 4,67 · constelaciones: Roman 1987",
   "FLYING TO A G = %s STAR, TO SEE THE SKY FROM THERE": "VOLANDO A UNA ESTRELLA DE G = %s, PARA VER EL CIELO DESDE ALLÍ",
   "beyond the map, Gaia GSP-Phot gives it A0 = %s": "más allá del mapa, Gaia GSP-Phot le da A0 = %s",
   "Gaia's own extinction of those stars (GSP-Phot A0, ≈ AV) / map = %s (the conversion used is 2.8)": "La extinción que Gaia da a esas estrellas (GSP-Phot A0, ≈ AV) / mapa = %s (la conversión usada es 2,8)",
   "the Gaia temperatures did not arrive: no check of the reddening": "las temperaturas de Gaia no llegaron: sin comprobación del enrojecimiento",
   "Brown: interstellar dust in front (3D map of Edenhofer et al. 2024, 14' cells); the browner, the more dust, up to AV ≈ %s": "Marrón: polvo interestelar por delante (mapa 3D de Edenhofer et al. 2024, celdas de 14'); cuanto más marrón, más polvo, hasta AV ≈ %s",
   "Dust in front (map): AV ≈ %s": "Polvo delante (mapa): AV ≈ %s",
   "its colour says E(BP−RP) = %s (expected from the map ≈ %s)": "su color dice E(BP−RP) = %s (lo esperado por el mapa ≈ %s)",
   "no Gaia temperature to measure its reddening": "sin temperatura de Gaia para medir su enrojecimiento",
   "Dust: Edenhofer et al. 2024 3D map (E of Zhang, Green & Rix 2023; AV = 2.8 E; E(BP−RP) ≈ %s E with the Gaia coefficients of Babusiaux et al. 2018)": "Polvo: mapa 3D de Edenhofer et al. 2024 (E de Zhang, Green y Rix 2023; AV = 2,8 E; E(BP−RP) ≈ %s E con los coeficientes de Gaia de Babusiaux et al. 2018)",
   "Gaia DR3 GSP-Phot: Teff %s K, E(BP−RP) %s; intrinsic BP−RP of that temperature (Mamajek): %s": "Gaia DR3 GSP-Phot: Teff %s K, E(BP−RP) %s; BP−RP intrínseco de esa temperatura (Mamajek): %s",
   "now: the photo": "ahora: la foto",
   "%s million years": "%s millones de años",
   "%s years": "%s años",
   "in %s": "dentro de %s",
   "%s ago": "hace %s",
   "This is how this patch of sky will look: each star has moved with its own speed, and the nearest ones have moved the most.": "Así se verá este trozo de cielo: cada estrella se ha movido con su propia velocidad, y las más cercanas son las que más se han movido.",
   "This is how this patch of sky looked: each star was where its speed brings it back to, and the nearest ones have moved the most.": "Así se veía este trozo de cielo: cada estrella estaba donde su velocidad la lleva de vuelta, y las más cercanas son las que más se han movido.",
   "Motion: calculated orbits in a model of the Milky Way, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), integrated star by star and for the Sun.": "Movimiento: órbitas calculadas en un modelo de la Vía Láctea, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), integradas estrella a estrella y para el Sol.",
   "Motion: straight lines, seen from the Local Standard of Rest (without the Sun's own drift: Schönrich et al. 2010).": "Movimiento: rectas, vistas desde el Estándar Local de Reposo (sin la deriva propia del Sol: Schönrich et al. 2010).",
   "Motion: straight lines in space, seen from the Sun (valid to about 1 million years).": "Movimiento: rectas en el espacio, vistas desde el Sol (valen hasta un millón de años, más o menos).",
   "Of the %s stars that move: radial velocity from Gaia DR3 %s · from their cluster %s (members without one better than 1 km/s) · unknown %s (hollow dots: depth path uncertain)": "De las %s estrellas que se mueven: velocidad radial de Gaia DR3 %s · de su cúmulo %s (miembros sin una mejor que 1 km/s) · desconocida %s (puntos huecos: su camino en profundidad es incierto)",
   "%s of them have left the frame of the photo": "%s de ellas han salido del encuadre de la foto",
   "□ %s stars have come in from outside the photo (Gaia, as bright as the ones that move here; they are not in your photo)": "□ %s estrellas han entrado desde fuera de la foto (Gaia, tan brillantes como las que se mueven aquí; no están en tu foto)",
   "(searched up to %s° outside the photo: the ones coming from farther away are not drawn)": "(buscadas hasta %s° fuera de la foto: las que vienen de más lejos no se pintan)",
   "heading to RA %s, Dec %s (its apex, ±%s°)": "rumbo a AR %s, Dec %s (su ápex, ±%s°)",
   "literature: RA %s, Dec %s (%s)": "literatura: AR %s, Dec %s (%s)",
   "most compact %s (%s pc across)": "lo más compacto %s (%s pc de diámetro)",
   "%s pc across now, %s pc at this instant": "%s pc de diámetro ahora, %s pc en este instante",
   "A cluster spreads here because the Galaxy pulls its stars apart; its own gravity, not modelled, would hold it together longer.": "Aquí un cúmulo se deshace porque la Galaxia separa sus estrellas; su propia gravedad, que no se modela, lo mantendría unido más tiempo.",
   "Of the stars of this photo, the one that came closest to the Sun: G = %s (RA %s, Dec %s), %s away, %s": "De las estrellas de esta foto, la que más se acercó al Sol: G = %s (AR %s, Dec %s), a %s, %s",
   "Of the stars of this photo, the one that will come closest to the Sun: G = %s (RA %s, Dec %s), %s away, %s": "De las estrellas de esta foto, la que más se acercará al Sol: G = %s (AR %s, Dec %s), a %s, %s",
   "DUST IN THE BEAM": "POLVO EN EL HAZ",
   "The sand-brown haze is interstellar dust. There is little of it in this direction: the photo looks through clean space.": "La bruma pardo arena es polvo interestelar. En esta dirección hay poco: la foto mira a través de espacio limpio.",
   "Across the field, up to %s: AV ≈ %s (median) and up to %s (darkest line of sight); AV = 1 means 2.5 times fainter.": "En el campo, hasta %s: AV ≈ %s (mediana) y hasta %s (la línea de visión más oscura); AV = 1 es 2,5 veces más débil.",
   "Check with the colours of %s stars of the photo with G < %s: measured reddening vs map, slope = %s (between %s and %s; expected ≈ %s)": "Comprobación con los colores de %s estrellas de la foto con G < %s: enrojecimiento medido frente al mapa, pendiente = %s (entre %s y %s; se espera ≈ %s)",
   "Colour offset (temperature scale of GSP-Phot): %s mag": "Desfase de color (escala de temperatura de GSP-Phot): %s mag",
   "No check with the colours: only %s stars of the photo with G < %s have a Gaia temperature and dust in front; it needs at least %s to give the slope.": "Sin comprobación con los colores: solo %s estrellas de la foto con G < %s tienen temperatura de Gaia y polvo por delante; hacen falta al menos %s para dar la pendiente.",
   "No check with the colours: the %s stars of the photo with G < %s have almost the same dust in front (spread of AV %s mag; it needs at least %s mag): without spread there is no slope to measure.": "Sin comprobación con los colores: las %s estrellas de la foto con G < %s tienen casi el mismo polvo por delante (dispersión de AV %s mag; hacen falta al menos %s mag): sin dispersión no hay pendiente que medir.",
   "▾ fewer details": "▾ menos detalles",
   "▸ details and sources (click)": "▸ detalles y fuentes (clic)",
   "Words: Myr = a million years. ly = light-year (9.5 million million km); pc = parsec = 3.26 light-years. Radial velocity = how fast a star comes towards us or goes away, measured by Gaia from its spectrum; without it the star's path in depth is unknown (hollow dots). LSR = Local Standard of Rest, a point that circles the Galaxy beside the Sun; seen from it, the Sun's own drift disappears. Apex = the point of the sky a group of stars is heading to. AV = how much dust dims visible light, in magnitudes (1 = 2.5 times fainter).": "Palabras: Ma = un millón de años. al = año luz (9,5 billones de km); pc = pársec = 3,26 años luz. Velocidad radial = lo deprisa que una estrella se acerca o se aleja, medida por Gaia en su espectro; sin ella, su camino en profundidad no se conoce (puntos huecos). LSR = Estándar Local de Reposo, un punto que gira alrededor de la Galaxia junto al Sol; visto desde él, desaparece la deriva propia del Sol. Ápex = el punto del cielo hacia el que va un grupo de estrellas. AV = cuánto apaga el polvo la luz visible, en magnitudes (1 = 2,5 veces más débil).",
   "Sky from the star": "Cielo desde la estrella",
   "Choose a star first (click it in the 3D view or in the photo); it needs a distance. In «Perspective».": "Elige antes una estrella (clic en el 3D o en la foto); necesita distancia. En «Perspectiva».",
   "Choose a star with a distance first.": "Elige antes una estrella con distancia.",
   "THE SKY SEEN FROM A STAR OF THE PHOTO": "EL CIELO VISTO DESDE UNA ESTRELLA DE LA FOTO",
   "MILKY WAY": "VÍA LÁCTEA",
   "A G = %s star, %s from the Sun": "Una estrella de G = %s, a %s del Sol",
   "From there the Sun is a star of magnitude %s (G %s) in %s, %s away; the stars of this field are seen in other directions and with other brightnesses. Only the stars of the photo are drawn: of the rest of the sky there is no data here. Click to come back.": "Desde allí el Sol es una estrella de magnitud %s (G %s) en %s, a %s; las estrellas de este campo se ven en otras direcciones y con otros brillos. Solo se dibujan las estrellas de la foto: del resto del cielo aquí no hay datos. Clic para volver.",
   "where the photo looks": "donde mira la foto",
   "THE WHOLE SKY FROM THERE": "TODO EL CIELO DESDE ALLÍ",
   "THE FIELD OF THE PHOTO FROM THERE": "EL CAMPO DE LA FOTO DESDE ALLÍ",
   "%s° across · grey frame: the photo seen from the Sun · ring: where a star is seen from the Sun · dot: where it is seen from there, with its brightness from there": "%s° de lado · marco gris: la foto vista desde el Sol · anillo: dónde se ve una estrella desde el Sol · punto: dónde se ve desde allí, con su brillo desde allí",
   "the Sun · mag %s · %s": "el Sol · mag %s · %s",
   "Integrating %s orbits in the Milky Way…": "Integrando %s órbitas en la Vía Láctea…",
   "Integrating %s orbits in the Milky Way… %d %%": "Integrando %s órbitas en la Vía Láctea… %d %%",
   "(retrying)": "(reintentando)",
   "(from the cache: VizieR did not answer)": "(de la caché: VizieR no contestó)",
   "BROWN: DUST IN FRONT (3D MAP, EDENHOFER ET AL. 2024)": "MARRÓN: POLVO POR DELANTE (MAPA 3D, EDENHOFER ET AL. 2024)",
   "THE SAME STARS, AT THEIR DISTANCE (3D)": "LAS MISMAS ESTRELLAS, A SU DISTANCIA (3D)"
};

var C3_OWN_TIPS_EN = {
   // (AY-5, 2-nov-2026) el de CabraPilot hablaba del diagrama HR y de la tecla 2 / H; en Cabra3D no hay HR (vive en CabraStars): la barra tiene Foto y 3D
   "sf.fullscreen": "Full screen: the photo or the 3D view over the whole screen. Inside, a small bar (it hides by itself; move the mouse to bring it back) switches between Photo and 3D with their transitions. Keys: 1 / F photo, 3 / D 3D, Esc to leave",
   "c3.retry": "Something online did not answer (the status line says which server and why): ask it again. Everything from the local Gaia database keeps working meanwhile.",
   "grp.view": "How you see the scene: perspective or side, log or segments scale, light-years or parsecs, zoom, and the optional layers (photo stars, nebula distance, interstellar dust, the sky seen from a star).",
   "grp.flight": "How you move through it and record it: the flights (Dive, Orbit, Grand tour, My flight), their duration and preview; ONE «● Record» that records what you choose next to it (the flight, or the time machine), with its options ▾; and exporting the view.",
   "grp.time": "THE TIME MACHINE: the stars move with their proper motion and, when Gaia measured it, their radial velocity. The time ruler (now in the middle), play and «now», how far it goes, how they move, and their trails.",
   "rec.what": "What «● Record» records: the flight chosen above, or the time machine (16 s: the photo, back to the past, forward to the future) as photo with the 3D in an inset, only the 3D, or only the photo. Size, frame rate and folder: ▾.",
   "c3.close": "Close FieldDepth3D (also the window's ✕ and Esc): it stops whatever is playing, flying or recording and frees its memory.",
   "ui.splitter": "Drag to resize the panel",
   "c3.lang": "Interface language: English / Spanish",
   "c3.image": "The image to explore: any image open in PixInsight (by default, the active one). A colour image calibrated with SPCC gives the best colours; black and white works too (the colours then come from Gaia).",
   "c3.refresh": "Read again the list of images open in PixInsight",
   "c3.solve": "Solve the image with ImageSolver now. You do not need to: it is solved by itself when you open a view, and an image that already has a solution is never solved again.",
   "c3.dist": "Read this image and show it in 3D: what lies behind the photo, and how far: stars, clusters, nebulae and galaxies at their distance, in real 3D. Here live the flight, the video and the TIME MACHINE.",
   "c3.color.mono": "A black and white image is accepted: the colours of the stars come from the Gaia catalogue. For the colours measured in your photo, use a colour image calibrated with SPCC.",
   "c3.color.uncal": "No colour calibration (SPCC, PCC or ColorCalibration) was found in the history of this image. It works anyway; the colours measured in the photo are calibrated against Gaia star by star, but SPCC is recommended.",
   "c3.color.ok": "The colour of this image has been calibrated: the colours measured in it are reliable.",
   "c3.nogaia": "The Gaia DR3 database is not registered in this PixInsight: Process > Global > Gaia, the wrench icon, and select the database files (XPSD).",
   "tm.now": "Back to now (the photo), every star along its path",
   "tm.play": "Play the time machine across the whole range (and pause)",
   "tm.slider": "Move in time: the centre is now (the photo); left is the past, right the future. Finer near now.",
   "tm.label": "The instant shown, from the photo. Gold: the straight lines are getting approximate; red: they are no longer valid (use Galactic orbits).",
   "tm.range": "How far the time machine goes, each side of now",
   "tm.motion": "How the stars move. Straight lines from the Sun: what we would see (valid to ~1 Myr). Galactic orbits: each star and the Sun integrated in a model of the Milky Way, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), for millions of years (warning past 100 Myr). Straight lines from the LSR: without the reflex of the Sun's own motion. With a range of 10 Myr or more it switches to Galactic orbits by itself (straight lines no longer describe the motion); your choice comes back below.",
   "tm.trails": "Draw the path of some stars from the photo to the instant shown: the members of the clusters, the fastest ones and the chosen star (all of them would be a tangle)",
   "c3.dust": "Interstellar dust along the beam of the photo, from the 3D map of Edenhofer et al. 2024 (Gaia + 2MASS, 14' cells, 69 to 1 250 pc). In 3D, brown translucent clouds at their distance; on the photo, the dust in front of each patch; on a star's card, the dust the map puts in front of it against the reddening its colour MEASURES. Off by default; the first time it reads only this field from Zenodo (needs the network once, then it is cached).",
   "c3.skyfrom": "Fly to the chosen star and see the sky from there: the stars of the photo in their new directions and brightnesses (1/d²), and the Sun as one more star, with its magnitude and the constellation it would be in. Click, Esc or this button to come back."
};
var C3_OWN_TIPS_ES = {
   "sf.fullscreen": "Pantalla completa: la foto o la vista 3D en toda la pantalla. Dentro, una barra pequeña (se esconde sola; mueve el ratón para que vuelva) cambia entre Foto y 3D con sus transiciones. Teclas: 1 / F la foto, 3 / D el 3D, Esc para salir",
   "c3.retry": "Algo de internet no contestó (la línea de estado dice qué servidor y por qué): pedirlo otra vez. Mientras, todo lo de la base Gaia local sigue funcionando.",
   "grp.view": "Cómo ves la escena: perspectiva o de lado, escala logarítmica o por tramos, años luz o pársecs, zoom, y las capas opcionales (estrellas de la foto, distancia de la nebulosa, polvo interestelar, el cielo visto desde una estrella).",
   "grp.flight": "Cómo te mueves por ella y la grabas: los vuelos (Dive, Orbit, Grand tour, My flight), su duración y su vista previa; UN solo «● Record» que graba lo que elijas a su lado (el vuelo o la máquina del tiempo), con sus opciones ▾; y exportar la vista.",
   "grp.time": "LA MÁQUINA DEL TIEMPO: las estrellas se mueven con su movimiento propio y, cuando Gaia la midió, su velocidad radial. La regla del tiempo (ahora en el centro), reproducir y «ahora», hasta dónde llega, cómo se mueven y sus estelas.",
   "rec.what": "Qué graba «● Record»: el vuelo elegido arriba, o la máquina del tiempo (16 s: la foto, atrás al pasado, adelante al futuro) como foto con el 3D en un recuadro, solo el 3D o solo la foto. Tamaño, ritmo y carpeta: ▾.",
   "c3.close": "Cerrar FieldDepth3D (también el aspa de la ventana y Esc): para lo que se esté reproduciendo, volando o grabando y libera su memoria.",
   "ui.splitter": "Arrastra para redimensionar el panel",
   "c3.lang": "Idioma de la interfaz: inglés / castellano",
   "c3.image": "La imagen que se explora: cualquiera abierta en PixInsight (de fábrica, la activa). Una imagen en color calibrada con SPCC da los mejores colores; en blanco y negro también funciona (los colores salen entonces de Gaia).",
   "c3.refresh": "Volver a leer la lista de imágenes abiertas en PixInsight",
   "c3.solve": "Resolver ahora la imagen con ImageSolver. No hace falta: se resuelve sola al abrir una vista, y una imagen que ya tiene solución no se vuelve a resolver nunca.",
   "c3.dist": "Leer esta imagen y verla en 3D: lo que hay detrás de la foto, y a qué distancia: estrellas, cúmulos, nebulosas y galaxias en su sitio, en 3D de verdad. Aquí viven el vuelo, el vídeo y la MÁQUINA DEL TIEMPO.",
   "c3.color.mono": "Se admite una imagen en blanco y negro: los colores de las estrellas salen del catálogo Gaia. Para los colores medidos en tu foto, usa una imagen en color calibrada con SPCC.",
   "c3.color.uncal": "No se ha encontrado calibración de color (SPCC, PCC o ColorCalibration) en el historial de esta imagen. Funciona igual; los colores medidos en la foto se calibran contra Gaia estrella a estrella, pero se recomienda SPCC.",
   "c3.color.ok": "El color de esta imagen está calibrado: los colores medidos en ella son fiables.",
   "c3.nogaia": "La base de datos Gaia DR3 no está registrada en este PixInsight: Process > Global > Gaia, el icono de la llave inglesa, y elige los ficheros de la base (XPSD).",
   "tm.now": "Volver a ahora (la foto), cada estrella por su camino",
   "tm.play": "Reproducir la máquina del tiempo de punta a punta (y pausar)",
   "tm.slider": "Moverse en el tiempo: el centro es ahora (la foto); a la izquierda el pasado, a la derecha el futuro. Más fino cerca de ahora.",
   "tm.label": "El instante que se enseña, desde la foto. Dorado: las rectas empiezan a ser aproximadas; rojo: ya no valen (usa Órbitas galácticas).",
   "tm.range": "Hasta dónde llega la máquina del tiempo, a cada lado de ahora",
   "tm.motion": "Cómo se mueven las estrellas. Rectas desde el Sol: lo que veríamos (vale hasta ~1 Ma). Órbitas galácticas: cada estrella y el Sol integrados en un modelo de la Vía Láctea, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), durante millones de años (aviso pasados 100 Ma). Rectas desde el LSR: sin el reflejo del movimiento propio del Sol. Con un alcance de 10 Ma o más pasa sola a Órbitas galácticas (las rectas ya no describen el movimiento); por debajo vuelve lo que elegiste.",
   "tm.trails": "Dibujar el camino de algunas estrellas desde la foto hasta el instante que se enseña: las de los cúmulos, las más rápidas y la elegida (todas serían una maraña)",
   "c3.dust": "El polvo interestelar a lo largo del haz de la foto, del mapa 3D de Edenhofer et al. 2024 (Gaia + 2MASS, celdas de 14', de 69 a 1 250 pc). En 3D, nubes marrones translúcidas a su distancia; en la foto, el polvo que hay delante de cada zona; en la ficha de una estrella, el polvo que el mapa le pone delante frente al enrojecimiento que MIDE su color. Apagado de fábrica; la primera vez lee de Zenodo solo este campo (necesita la red una vez; luego queda en caché).",
   "c3.skyfrom": "Volar a la estrella elegida y ver el cielo desde allí: las estrellas de la foto en sus nuevas direcciones y brillos (1/d²), y el Sol como una estrella más, con su magnitud y la constelación en la que se vería. Clic, Esc o este botón para volver."
};

// --- Bloque A (20-oct): la pildora de blanco y negro, sin aviso --------------------------------------------------------
var C3_BLOCKA_ES = {
   "Black and white · colours from Gaia": "Blanco y negro · colores de Gaia"
};

(function() {
   var k;
   for (k in C3_BLOCKA_ES) C3_OWN_ES[k] = C3_BLOCKA_ES[k];
   for (k in C3_OWN_ES) C3_I18N_ES[k] = C3_OWN_ES[k];
   for (k in C3_OWN_TIPS_EN) C3_TOOLTIPS_EN[k] = C3_OWN_TIPS_EN[k];
   for (k in C3_OWN_TIPS_ES) C3_TOOLTIPS_ES[k] = C3_OWN_TIPS_ES[k];
})();

// ============================================================================
// BLOQUE B (20-oct, leyenda del polvo integrada en todas las vistas): tm/dust_ui.js, tm/hud.js, tm/timemachine_video.js
// ============================================================================
var C3_BLOCKB_ES = {
   "DUST IN FRONT · TOTAL AV": "POLVO POR DELANTE · AV TOTAL",
   "Colour of the 3D dust clouds: how much visible light the dust dims per kiloparsec (AV in magnitudes per kpc), on a logarithmic scale. Thin: under 1; dense: 1 to 10; very dense: 10 or more (the diffuse medium of the Galactic plane dims about 1–2 mag/kpc; a molecular cloud, tens to hundreds).":
      "Color de las nubes de polvo en 3D: cuánta luz visible apaga el polvo por kiloparsec (AV en magnitudes por kpc), en escala logarítmica. Tenue: menos de 1; denso: de 1 a 10; muy denso: 10 o más (el medio difuso del plano de la Galaxia apaga ~1–2 mag/kpc; una nube molecular, decenas o cientos).",
   "Brown tint of the photo: the dust in front of each part of the field, from the 3D map (Edenhofer et al. 2024, 14' cells). The browner, the more it dims visible light, as AV in magnitudes (1 magnitude = 2.5 times fainter) up to the darkest line of sight of the field.":
      "Tinte marrón de la foto: el polvo que hay delante de cada zona del campo, según el mapa 3D (Edenhofer et al. 2024, celdas de 14'). Cuanto más marrón, más apaga la luz visible, como AV en magnitudes (1 magnitud = 2,5 veces más tenue) hasta la línea de visión más oscura del campo.",
   "Interstellar dust (the sand-brown haze): its thickest layer, at %s, dims what is behind it by about %s mag; all of it together, by about %s mag.":
      "Polvo interestelar (la bruma pardo arena): su capa más gruesa, a %s, apaga lo que hay detrás unas %s mag; todo junto, unas %s mag.",
   "Interstellar dust (the sand-brown haze): there is little of it in this direction; the photo looks through clean space.":
      "Polvo interestelar (la bruma pardo arena): hay poco en esta dirección; la foto mira a través de espacio limpio."
};
(function() { for (var k in C3_BLOCKB_ES) C3_I18N_ES[k] = C3_BLOCKB_ES[k]; })();
// --- TAREA H (21-oct-2026): defectos visuales de la revision adversaria ---
var C3_TASKH_ES = {
   "Sky from the star: the whole sky as seen from there (Esc or «BACK» to return).": "Cielo desde la estrella: todo el cielo visto desde allí (Esc o «VOLVER» para regresar).",
   "Notes on the scale and the sources: point here to read them.": "Notas sobre la escala y las fuentes: señala aquí para leerlas.",
   "Notes: point here.": "Notas: señala aquí.",
   "Point at a star to see what it is.": "Señala una estrella para ver qué es.",
   "Point at a star, here or in the photo, to see what it is.": "Señala una estrella, aquí o en la foto, para ver qué es.",
   "%s more lines: point at this box to read them": "%s líneas más: señala este recuadro para leerlas",
   "hollow: no radial velocity (its depth is uncertain)": "hueca: sin velocidad radial (su profundidad es incierta)",
   "trail: its path since the photo": "estela: su camino desde la foto",
   "the photo": "la foto",
   "± Uncertainty": "± Incertidumbre", "Also what your photo doesn't show": "También lo que no se ve en tu foto", "Zones with no room on the box": "Zonas sin sitio en la caja",
   "Legend": "Leyenda", "DUST · AV/KPC": "POLVO · AV/KPC", "DUST · AV": "POLVO · AV", "no RV": "sin VR", "trail": "estela", "▸ details": "▸ detalles"
};
var C3_TASKH_TIPS_EN = {
   "c3.unseen": "Also what your photo doesn't show: by default only what you can see in your photo is drawn (the galaxies, quasars and groups that stand out from the noise at their position). Switch this on to also draw, hollow and dimmed, those of the catalogues that fall in your frame and have a distance but that your photo does NOT show. They are never the nearest or the farthest one and they are not part of the scale or of the counts of what you see. The Gaia stars that are not visible do not come back. Off by default; it is remembered.",
   "c3.errbars": "Distance uncertainty bars: the thin line along the depth axis of each galaxy, quasar or cluster shows the range its distance could have. For far objects it can be very long: many galaxies and quasars only have a PHOTOMETRIC redshift (GLADE+), good to about ±20–50 %, so their line can span a large part of the scale (especially in Segments). Switch them off for a cleaner scene: it applies to the 3D view, exports and legend; the distances themselves do not change. Remembered between sessions."
};
var C3_TASKH_TIPS_ES = {
   "c3.unseen": "También lo que no se ve en tu foto: de fábrica se pinta solo lo que se ve en tu foto (las galaxias, cuásares y grupos que destacan del ruido en su sitio). Enciéndelo para pintar también, huecos y atenuados, los de los catálogos que caen en tu encuadre y tienen distancia pero que tu foto NO enseña. Nunca son el más cercano ni el más lejano y no entran en la escala ni en las cuentas de lo que se ve. Las estrellas de Gaia que no se ven no vuelven. Apagado de fábrica; se recuerda.",
   "c3.errbars": "Barras de incertidumbre de la distancia: la línea fina a lo largo del eje de profundidad de cada galaxia, cuásar o cúmulo marca el intervalo en que podría estar su distancia. En lo lejano puede ser muy larga: muchas galaxias y cuásares solo tienen un corrimiento al rojo FOTOMÉTRICO (GLADE+), bueno a ±20–50 % más o menos, y su línea puede abarcar buena parte de la escala (sobre todo en Tramos). Apágalas para una escena más limpia: vale para la vista 3D, las exportaciones y la leyenda; las distancias no cambian. Se recuerda entre sesiones."
};
(function() {
   var k;
   for (k in C3_TASKH_ES) C3_I18N_ES[k] = C3_TASKH_ES[k];
   for (k in C3_TASKH_TIPS_EN) C3_TOOLTIPS_EN[k] = C3_TASKH_TIPS_EN[k];
   for (k in C3_TASKH_TIPS_ES) C3_TOOLTIPS_ES[k] = C3_TASKH_TIPS_ES[k];
})();

// ============================================================================
// --- Bloque D (20-oct): EDITOR DE CAMARAS de «My flight» (ui/flight_editor.js) -------------------------------------------
// ============================================================================
var C3_FLED_ES = {
   "MY CAMERAS": "MIS CÁMARAS", "1 view": "1 vista", "%d views": "%d vistas",
   "Clear all": "Borrar todo", "Confirm?": "¿Confirmar?",
   "No views yet.": "Aún no hay vistas.",
   "Move the 3D camera and press ＋ to save it here.": "Mueve la cámara del 3D y pulsa ＋ para guardarla aquí.",
   "View %d": "Vista %d",
   "turn %d° · tilt %d° · zoom ×%s": "giro %d° · inclinación %d° · zoom ×%s",
   "Went to view %d": "Vas a la vista %d",
   "View %d is now view %d": "La vista %d es ahora la %d",
   "View %d replaced with the current camera": "La vista %d es ahora la cámara actual",
   "View %d deleted": "Vista %d borrada",
   "All the views of «My flight» were deleted": "Se han borrado todas las vistas de «Mi vuelo»",
   "Move up": "Subir", "Move down": "Bajar", "Replace with the current camera": "Sustituir por la cámara actual",
   "Rename": "Renombrar", "Delete this view": "Borrar esta vista",
   // la transicion con que se llega a una vista y la pausa en ella
   "Smooth": "Suave", "Ease out": "Frena al llegar", "Ease in": "Llega rápido", "Linear": "Lineal", "Slow-mo": "Cámara lenta",
   "Smooth: flowing motion at constant speed, soft start and stop of the flight (the default)": "Suave: movimiento fluido a velocidad constante, con arranque y frenada suaves del vuelo (la de siempre)",
   "Ease out: leaves fast and brakes softly as it arrives": "Frena al llegar: sale rápido y frena con suavidad al llegar",
   "Ease in: leaves slowly and arrives fast": "Llega rápido: sale despacio y llega deprisa",
   "Linear: constant speed along this leg": "Lineal: velocidad constante en este tramo",
   "Slow motion: this leg lasts 2.5 times longer, with a soft start and stop": "Cámara lenta: este tramo dura 2,5 veces más, con arranque y frenada suaves",
   "Hold: the camera stays still on this view (click to change)": "Pausa: la cámara se queda quieta en esta vista (clic para cambiar)",
   "+ hold": "+ pausa", "hold %s s": "pausa %s s",
   "Arriving at view %d: %s": "Al llegar a la vista %d: %s",
   "The camera will stay %s s on view %d": "La cámara se quedará %s s en la vista %d",
   "No hold on view %d": "Sin pausa en la vista %d"
};
var C3_FLED_TIPS_EN = {
   "sf.flight.edit": "Your cameras: opens the list of the views of «My flight», one row each, with a thumbnail. Click a row to go to that camera; delete, reorder, replace or rename any of them.",
   "sf.flight.list": "Click a row to go to that camera. ▲ ▼ move it up or down, ⟳ replaces it with the camera you have now, ✎ renames it (or double-click its name), ✕ deletes it. The gold bar marks the view you are on. «Clear all» asks you to click twice. Mouse wheel scrolls. The two small boxes under each name are the transition into that view (Smooth, Ease out, Ease in, Linear, Slow-mo) and a hold (the camera stays still there): click one to change it.",
   "sf.flight.rename": "Type a name and press Enter (Esc cancels; empty = «View n»)"
};
var C3_FLED_TIPS_ES = {
   "sf.flight.edit": "Tus cámaras: abre la lista de las vistas de «Mi vuelo», una fila cada una y con su miniatura. Pulsa una fila para ir a esa cámara; borra, reordena, sustituye o renombra cualquiera.",
   "sf.flight.list": "Pulsa una fila para ir a esa cámara. ▲ ▼ la suben o la bajan, ⟳ la sustituye por la cámara que tienes ahora, ✎ la renombra (o doble clic en su nombre), ✕ la borra. La barra dorada marca la vista en la que estás. «Borrar todo» pide dos clics. La rueda desplaza la lista. Las dos cajitas bajo cada nombre son la transición con que se llega a esa vista (Suave, Frena al llegar, Llega rápido, Lineal, Cámara lenta) y una pausa (la cámara se queda quieta allí): pulsa una para cambiarla.",
   "sf.flight.rename": "Escribe un nombre y pulsa Intro (Esc cancela; vacío = «Vista n»)"
};
(function() {
   var k;
   for (k in C3_FLED_ES) C3_I18N_ES[k] = C3_FLED_ES[k];
   for (k in C3_FLED_TIPS_EN) C3_TOOLTIPS_EN[k] = C3_FLED_TIPS_EN[k];
   for (k in C3_FLED_TIPS_ES) C3_TOOLTIPS_ES[k] = C3_FLED_TIPS_ES[k];
})();

// ============================================================================
// Block G (20-oct-2026): LA PROFUNDIDAD DE LA FOTO y lo que de verdad se ve en ella (CabraShared/csh_depth*.js).
// Castellano de sus textos (la linea de estado, su tooltip y los motivos). Bloque contiguo, al final, a proposito.
// ============================================================================
(function() {
   var G_ES = {
      "Image depth: G ≈ %s (50 %%)": "Profundidad de la foto: G ≈ %s (50 %%)",
      "Image depth: G ≥ %s (deeper than the Gaia catalogue)": "Profundidad de la foto: G ≥ %s (más honda que el catálogo de Gaia)",
      "sky ≈ %s mag/arcsec²": "cielo ≈ %s mag/arcsec²",
      "in the photo:": "en la foto:",
      "%s catalogue objects too faint": "%s objetos de catálogo demasiado débiles",
      "%s outside the frame": "%s fuera del encuadre",
      "Image depth not measured: ": "Profundidad de la foto sin medir: ",
      "What is shown is what this photo really reaches, not everything the catalogues know in this patch of sky.": "Se enseña lo que esta foto alcanza de verdad, no todo lo que los catálogos conocen en este trozo de cielo.",
      "Depth: half of the isolated Gaia stars are detected (S/N ≥ 5 at their position) at G = %s; 90 %% at G = %s.": "Profundidad: la mitad de las estrellas aisladas de Gaia se detectan (S/R ≥ 5 en su sitio) en G = %s; el 90 %% en G = %s.",
      "Depth: more than 50 %% of the Gaia stars are detected down to G %s, the end of the catalogue: the photo goes deeper.": "Profundidad: más del 50 %% de las estrellas de Gaia se detectan hasta G %s, el final del catálogo: la foto llega más hondo.",
      "Independent check: the zero point of the photo and its sky noise put S/N = 5 at G = %s.": "Comprobación independiente: el punto cero de la foto y el ruido de su cielo ponen S/R = 5 en G = %s.",
      "Faintest surface brightness (3σ in 10″ boxes, Román et al. 2020): %s mag/arcsec² in G.": "Brillo superficial más débil (3σ en cajas de 10″, Román et al. 2020): %s mag/arcsec² en G.",
      "Surface brightness limit not given: ": "Sin límite de brillo superficial: ",
      "Stars: %s too faint for this photo are left out (%s of them had a distance).": "Estrellas: %s demasiado débiles para esta foto se quedan fuera (%s de ellas tenían distancia).",
      "Galaxies, quasars and other objects left out: ": "Galaxias, cuásares y otros objetos que se quedan fuera: ",
      "too faint (catalogue magnitude)": "demasiado débiles (magnitud del catálogo)",
      "too diffuse (below the surface brightness limit)": "demasiado difusos (por debajo del límite de brillo superficial)",
      "nothing at their position in the photo": "nada en su sitio en la foto",
      "no magnitude and no clean pixels to check": "sin magnitud y sin píxeles limpios para comprobarlo",
      "outside the frame": "fuera del encuadre",
      "%s galaxies are placed by their PHOTOMETRIC redshift (GLADE+): their distance is uncertain by 20 %% or more and they are drawn as doubtful.": "%s galaxias van colocadas por su corrimiento al rojo FOTOMÉTRICO (GLADE+): su distancia tiene un 20 %% o más de incertidumbre y se dibujan como dudosas.",
      "Besides SIMBAD: ": "Además de SIMBAD: ",
      "%s visible of %s new": "%s se ven de %s nuevas",
      "did not answer": "no contestó",
      " (from %s)": " (de %s)",                     // (29-oct, P8: GLADE+ / Quaia de un espejo de VizieR)
      "too few bright stars to fix the zero point.": "muy pocas estrellas brillantes para fijar el punto cero.",
      "the photo is not linear (stretched): there is no zero point for the sky.": "la foto no es lineal (está estirada): no hay punto cero para el cielo.",
      "unknown pixel scale.": "escala del píxel desconocida.",
      "the sky boxes could not be read.": "no se han podido leer las cajas del cielo.",
      "the photo is too small for 10\" boxes.": "la foto es demasiado pequeña para cajas de 10\".",
      "too crowded: fewer than 30 sky boxes without stars.": "demasiado poblada: menos de 30 cajas de cielo sin estrellas.",
      "there is no image to measure.": "no hay imagen que medir.",
      "too few unsaturated, isolated Gaia stars in the photo.": "muy pocas estrellas de Gaia aisladas y sin saturar en la foto.",
      "too few Gaia stars to build the completeness curve.": "muy pocas estrellas de Gaia para la curva de completitud.",
      "the pixels could not be read.": "no se han podido leer los píxeles.",
      "stars of the Milky Way according to Gaia (parallax or proper motion)": "estrellas de la Vía Láctea según Gaia (paralaje o movimiento propio)",
      // (23-oct-2026: lo que se ve A OJO)
      "Nothing could be checked against the photo: galaxies and quasars are shown as the catalogues give them.": "No se ha podido comprobar nada contra la foto: las galaxias y los cuásares salen como los dan los catálogos.",
      "This photo shows stars down to G ≥ %s (deeper than the Gaia catalogue)": "Esta foto enseña estrellas hasta G ≥ %s (más honda que el catálogo de Gaia)",
      "This photo shows down to G ≈ %s": "Esta foto llega a la vista hasta G ≈ %s",
      "%s catalogue objects not visible in the photo": "%s objetos de catálogo que no se ven en la foto",
      "Shown in depth only what you can see in the photo: signal-to-noise of %s or more at its position, against the noise of the photo there and of its own surroundings (S/N 5 says the light is there; by eye it only stands out from about %s).": "En profundidad solo se pinta lo que se ve en la foto: señal/ruido de %s o más en su sitio, frente al ruido de la foto allí y al de su alrededor (S/R 5 dice que la luz está; a ojo solo destaca desde unos %s).",
      "By eye: half of the isolated Gaia stars stand out at G = %s; 90 %% at G = %s.": "A ojo: la mitad de las estrellas de Gaia aisladas destaca a G = %s; el 90 %% a G = %s.",
      "What you can see in the photo but no catalogue gives a distance for cannot be placed in 3D: the 3D view does not invent distances.": "Lo que se ve en la foto y ningún catálogo da con distancia no se puede colocar en 3D: la vista 3D no inventa distancias.",
      "Also shown, hollow, %s catalogue objects that are NOT visible in your photo (switch on).": "Se pintan también, huecos, %s objetos de catálogo que NO se ven en tu foto (interruptor encendido).",
      "%s catalogue objects in the frame with a distance are not visible in your photo and are not drawn (switch «also what your photo doesn't show»: off).": "%s objetos de catálogo del encuadre con distancia no se ven en tu foto y no se pintan (interruptor «también lo que no se ve en tu foto»: apagado).",
      "they do not stand out from the noise at their position in the photo": "no destacan del ruido en su sitio de la foto",
      "not visible in the photo: %s Gaia stars and %s galaxies, quasars or groups": "no se ven en la foto: %s estrellas de Gaia y %s galaxias, cuásares o grupos",
      "%s of the catalogues that your photo does NOT show (hollow, dimmed)": "%s de los catálogos que tu foto NO enseña (huecos, apagados)",
      "Only what this photo shows is drawn (by eye down to %s).": "Solo se pinta lo que esta foto enseña (a ojo, hasta %s).",
      "Only what this photo shows is drawn (by eye down to %s): %s Gaia stars and %s galaxies, quasars or groups of the catalogues that it does not show are left out.": "Solo se pinta lo que esta foto enseña (a ojo, hasta %s): se dejan fuera %s estrellas de Gaia y %s galaxias, cuásares o grupos de los catálogos que no enseña.",
      // (24-oct-2026, H2 de Gemini: el pie con «tambien lo que no se ve» encendido)
      "Drawn: what this photo shows (by eye down to %s) and, hollow, %s galaxies, quasars or groups of the catalogues that it does NOT show.": "Se pinta lo que esta foto enseña (a ojo, hasta %s) y, huecos, %s galaxias, cuásares o grupos de los catálogos que NO enseña.",
      "Left out: %s Gaia stars and %s other galaxies, quasars or groups of the catalogues.": "Se dejan fuera: %s estrellas de Gaia y %s galaxias, cuásares o grupos más de los catálogos.",
      // (24-oct-2026, D1 = A' de Nino: lo que pasa la vara por poco, S/R 12 a 20, se pinta «debil»)
      "faint": "débil",
      "faint · barely visible: S/N %s; zoom in to see it": "débil · apenas visible: S/R %s; amplía para verlo",
      "%s of them FAINT in your photo (dashed ring)": "%s de ellos DÉBILES en tu foto (anillo discontinuo)",
      "%s of the galaxies, quasars or groups are FAINT (S/N %s to %s): barely visible, drawn with a dashed ring; zoom in to see them.": "%s de las galaxias, cuásares o grupos son DÉBILES (S/R %s a %s): apenas se ven, con el anillo discontinuo; amplía para verlos.",
      // (26-oct-2026, A'b de Nino: lo «debil» tambien en las estrellas; la palabra y la ficha son las de siempre)
      "%s of the stars are FAINT (S/N %s to %s): barely visible, drawn with a dashed ring; zoom in to see them.": "%s de las estrellas son DÉBILES (S/R %s a %s): apenas se ven, con el anillo discontinuo; amplía para verlas.",
      "%s of the stars FAINT in your photo (dashed ring)": "%s de las estrellas DÉBILES en tu foto (anillo discontinuo)"
   };
   for (var k in G_ES) C3_I18N_ES[k] = G_ES[k];
})();

// ============================================================================
// --- Bloque F (20-oct): LO QUE NO ES UNA ESTRELLA en la maquina del tiempo (tm/timemachine_ui.js) -------------------------
// (nebulosas y cumulos que se mueven, el frente de luz, la expansion y las cifras de lo lejano con su nombre)
// ============================================================================
var C3_BLOCKF_ES = {
   "median of its %s Gaia DR3 stars": "mediana de sus %s estrellas de Gaia DR3",
   "median of %s Gaia DR3 radial velocities of its stars": "mediana de %s velocidades radiales de Gaia DR3 de sus estrellas",
   "the cluster %s": "el cúmulo %s",
   "the cluster %s (median of its Gaia DR3 radial velocities)": "el cúmulo %s (mediana de sus velocidades radiales de Gaia DR3)",
   "assumed: it turns with the Galaxy (circular orbit in MilkyWayPotential2022): nothing measured": "supuesto: gira con la Galaxia (órbita circular en MilkyWayPotential2022): no hay nada medido",
   "LIGHT FRONT": "FRENTE DE LUZ", "(comoving)": "(comóvil)",
   "%s Gyr": "%s Ga", "%s billion years": "%s mil millones de años",
   "%s Gly": "%s G al", "%s billion light years": "%s mil millones de años luz",
   "z = %s · light travel %s · today %s (comoving)": "z = %s · viaje de la luz %s · hoy %s (comóvil)",
   "light travel time %s": "tiempo de viaje de la luz %s",
   "distance today (comoving) %s": "distancia hoy (comóvil) %s",
   "when its light left, it was %s away": "cuando salió su luz estaba a %s",
   "Cosmology: %s. Light travel time = how long ago its light left (lookback); distance today = comoving (proper distance now); when the light left = comoving / (1 + z).":
      "Cosmología: %s. Tiempo de viaje de la luz = cuánto hace que salió su luz; distancia hoy = comóvil (la distancia propia de ahora); cuando salió la luz = comóvil / (1 + z).",
   "%s: the light of this photo had not left it yet": "%s: la luz de esta foto aún no había salido de él",
   "%s: the light of this photo was already on its way, %s from us": "%s: la luz de esta foto ya venía de camino, a %s de nosotros",
   "%s: the light leaving the Sun today will have reached it": "%s: la luz que sale hoy del Sol ya le habrá llegado",
   "%s: the light leaving the Sun today will not have reached it yet": "%s: la luz que sale hoy del Sol aún no le habrá llegado",
   "%s it was %s away (the Universe %s %% smaller)": "%s estaba a %s (el universo, un %s %% más pequeño)",
   "%s it will be %s away (the Universe %s %% larger)": "%s estará a %s (el universo, un %s %% más grande)",
   "it does not move here: its motion across the sky is not measured (millionths of an arcsecond a year)": "aquí no se mueve: su movimiento en el cielo no está medido (millonésimas de segundo de arco al año)",
   "SIMBAD": "SIMBAD", "its stars (Gaia DR3)": "sus estrellas (Gaia DR3)", "its cluster": "su cúmulo", "assumed (the Galaxy's rotation)": "supuesto (la rotación de la Galaxia)",
   "moves with: %s": "se mueve con: %s",
   "motion: in the sky %s, in depth %s": "movimiento: en el cielo %s, en profundidad %s",
   "In the time machine: proper motion %s, %s mas/yr%s (%s) · radial velocity %s km/s%s (%s).": "En la máquina del tiempo: movimiento propio %s, %s mas/año%s (%s) · velocidad radial %s km/s%s (%s).",
   "SIMBAD gives %s, %s mas/yr%s": "SIMBAD da %s, %s mas/año%s",
   "its %s Gaia stars give %s, %s mas/yr": "sus %s estrellas de Gaia dan %s, %s mas/año",
   "Also measured": "También medido",
   "%s: %s′ from here across the sky, %s in depth": "%s: a %s′ de aquí en el cielo, %s en profundidad",
   "Asking SIMBAD for the motions of the nebulae and clusters…": "Pidiendo a SIMBAD el movimiento de las nebulosas y los cúmulos…",
   "all of them": "todo", "none of them": "nada", "%s of %s": "%s de %s",
   "Light front (the pale dashed frame): %s the light that makes this photo was %s from us; of what you see, %s had not yet sent it.":
      "Frente de luz (el marco claro a trazos): %s la luz que forma esta foto estaba a %s de nosotros; de lo que ves, aún no la había emitido: %s.",
   "Light front (the pale dashed frame): %s the light leaving the Sun now will be %s away; of what you see, %s will have received it.":
      "Frente de luz (el marco claro a trazos): %s la luz que sale ahora del Sol estará a %s; de lo que ves, la habrá recibido: %s.",
   "Galaxies and quasars do not move here: their motion across the sky (millionths of an arcsecond a year) is measured for almost none of them.":
      "Las galaxias y los cuásares no se mueven aquí: su movimiento en el cielo (millonésimas de segundo de arco al año) no está medido casi para ninguna.",
   "Cosmic expansion: %s the far galaxies were %s %% closer (scale factor %s); in the box, %s %% of its depth.":
      "Expansión del universo: %s las galaxias lejanas estaban un %s %% más cerca (factor de escala %s); en la caja, un %s %% de su fondo.",
   "Cosmic expansion: %s the far galaxies will be %s %% farther (scale factor %s); in the box, %s %% of its depth.":
      "Expansión del universo: %s las galaxias lejanas estarán un %s %% más lejos (factor de escala %s); en la caja, un %s %% de su fondo.",
   "Nebulae and clusters move like the stars (%s): %s with a measured motion (SIMBAD or their own Gaia DR3 stars), %s with a motion partly or wholly assumed (the Galaxy's rotation, where nothing is measured).":
      "Las nebulosas y los cúmulos se mueven como las estrellas (%s): %s con un movimiento medido (SIMBAD o sus propias estrellas de Gaia DR3), %s con un movimiento supuesto en todo o en parte (la rotación de la Galaxia, donde no hay nada medido).",
   "(SIMBAD did not answer: their own motions are missing.)": "(SIMBAD no ha contestado: faltan sus propios movimientos.)"
};
(function() { for (var k in C3_BLOCKF_ES) C3_I18N_ES[k] = C3_BLOCKF_ES[k]; })();

// ---------------------------------------------------------------------------
// BLOQUE E (20-oct-2026): «Sky from the star» como planetario (tm/sky_view.js, tm/skyfrom_ui.js). Un bloque propio, al
// final, que se fusiona encima de lo anterior (y sustituye el tooltip de «c3.skyfrom»).
// ---------------------------------------------------------------------------
var C3_SKYE_ES = {
   "A G = %s star of the photo": "Una estrella de la foto de G = %s",
   "in the photo (Gaia DR3)": "en la foto (Gaia DR3)",
   "the Sun · V %s": "el Sol · V %s",
   "BACK": "VOLVER", "PERSPECTIVE": "PERSPECTIVA", "ALL SKY": "TODO EL CIELO", "LINES": "LÍNEAS", "NAMES": "NOMBRES", "GRID": "RETÍCULA", "PHOTO": "FOTO",
   "MAG ≤ %s": "MAG ≤ %s", "LOOK AT": "MIRAR A", "THE SUN": "EL SOL", "THE PHOTO FIELD": "EL CAMPO DE LA FOTO", "FIELD CENTRE": "CENTRO DE LA FOTO",
   "FROM": "DESDE", "THE STAR": "LA ESTRELLA", "GO THERE": "IR ALLÍ",
   "THE SKY SEEN FROM THE SUN": "EL CIELO VISTO DESDE EL SOL",
   "THE SKY SEEN FROM ANOTHER STAR": "EL CIELO VISTO DESDE OTRA ESTRELLA",
   "The real sky: as seen from the Sun (and from the Earth)": "El cielo de verdad: visto desde el Sol (y desde la Tierra)",
   "%s, %s from the Sun": "%s, a %s del Sol",
   "%s stars to V %s, each in its real direction and brightness. Press «FROM: THE STAR» to see how the same sky looks from the star.": "%s estrellas hasta V %s, cada una en su dirección y con su brillo de verdad. Pulsa «DESDE: LA ESTRELLA» para ver cómo se ve este mismo cielo desde la estrella.",
   "From there the Sun is a star of magnitude %s in %s, %s away. Each star is drawn in its direction and with its brightness from there (1/d²); the constellation figures are the ones we know, drawn in 3D: that is why they deform. %s stars without a reliable parallax stay at infinity (direction and brightness as from the Sun).": "Desde allí el Sol es una estrella de magnitud %s en %s, a %s. Cada estrella se dibuja en su dirección y con su brillo desde allí (1/d²); las figuras de las constelaciones son las que conocemos, dibujadas en 3D: por eso se deforman. %s estrellas sin una paralaje fiable se quedan en el infinito (dirección y brillo como desde el Sol).",
   "Hipparcos (ESA 1997; van Leeuwen 2007) to V 8 + %s stars of the photo (Gaia DR3; %s of them are also in Hipparcos: drawn once) · figures and star names: Stellarium «modern» (CC BY-SA 4.0) · the Sun's constellation: Roman 1987 · %s projection, east to the left · drag to look around, wheel to zoom, double click to centre, click a star for its card": "Hipparcos (ESA 1997; van Leeuwen 2007) hasta V 8 + %s estrellas de la foto (Gaia DR3; %s de ellas están también en Hipparcos: se dibujan una vez) · figuras y nombres de estrellas: Stellarium «modern» (CC BY-SA 4.0) · la constelación del Sol: Roman 1987 · proyección %s, el este a la izquierda · arrastra para mirar alrededor, la rueda acerca, doble clic centra, clic en una estrella para su ficha",
   "Hammer-Aitoff": "Hammer-Aitoff", "stereographic": "estereográfica",
   "The bright-star catalogue could not be read (%s): only the stars of the photo are drawn.": "No se ha podido leer el catálogo de estrellas brillantes (%s): solo se dibujan las estrellas de la foto.",
   "centre RA %s, Dec %s": "centro AR %s, Dec %s",
   "looking at RA %s, Dec %s · %s° across": "mirando a AR %s, Dec %s · %s° de lado a lado",
   "the Sun": "el Sol",
   "%s of the 88 constellation figures we know now lie within 40° of the Sun.": "%s de las 88 figuras de constelaciones que conocemos quedan ahora a menos de 40° del Sol.",
   "the photo": "la foto", "the photo (as seen from the Sun)": "la foto (vista desde el Sol)", "its stars, as seen from here": "sus estrellas, vistas desde aquí",
   "From here: mag %s · %s": "Desde aquí: mag %s · %s",
   "From the Sun: mag %s · %s": "Desde el Sol: mag %s · %s",
   "Among the constellations we know, it is in %s": "Entre las constelaciones que conocemos, está en %s",
   "mag %s · no reliable parallax: placed at infinity (same direction and brightness from anywhere)": "mag %s · sin paralaje fiable: puesta en el infinito (la misma dirección y el mismo brillo desde cualquier sitio)"
};
var C3_SKYE_TIPS_EN = {
   "c3.skyfrom": "Fly to the chosen star and look at the WHOLE sky from there, like a planetarium: the bright stars of Hipparcos and the stars of the photo, each in its new direction and with its new brightness (1/d²), the Sun as one more star, and the constellation figures we know drawn in 3D, so you see them deform. Drag to look around, wheel to zoom, hover a star for its card. «✕ Back», Esc or this button to come back.",
   "c3sky.back": "Back to the 3D view (also Esc or «✦ Sky from the star»)",
   "c3sky.persp": "Perspective: what you would see looking in one direction (stereographic, from 10° to 180° across). Drag to look around; the wheel zooms; zooming out past 180° shows the whole sky.",
   "c3sky.all": "The whole sky in one map (Hammer-Aitoff, equal area), centred where you look. Drag to turn it; the wheel zooms back into perspective under the cursor.",
   "c3sky.lines": "The constellation figures (Stellarium «modern»), drawn between the real 3D positions of their stars: seen from another star they deform or break apart. A stroke longer than 20° fades with its length and one longer than 70° is not drawn (it would cross half the sky)",
   "c3sky.names": "Names: of the constellations (at the centre of their figure, as seen from here) and of the brightest stars",
   "c3sky.grid": "The RA/Dec grid (every 30° and every 2 h). Directions do not change with the place you look from: the grid is the same everywhere",
   "c3sky.photo": "The photo: its outline (the directions it covers, as seen from the Sun) and all its stars, even the faint ones (as faint dots), in the places they are seen from here",
   "c3sky.mag": "Faintest magnitude drawn (as seen from here): − fewer stars, + more (from 3 to 8)",
   "c3sky.lookSun": "Look at the Sun (from here it is just one more star)",
   "c3sky.lookField": "Look where the stars of the photo are seen from here (from a star inside the field they may be spread all over the sky)",
   "c3sky.lookCentre": "Look in the direction the photo looks from the Earth",
   "c3sky.fromStar": "See the sky from the chosen star",
   "c3sky.fromSun": "See the same sky from the Sun, to compare: the real sky",
   "c3sky.go": "Go to this star and see the sky from it"
};
var C3_SKYE_TIPS_ES = {
   "c3.skyfrom": "Volar a la estrella elegida y mirar TODO el cielo desde allí, como en un planetario: las estrellas brillantes de Hipparcos y las de la foto, cada una en su nueva dirección y con su nuevo brillo (1/d²), el Sol como una estrella más, y las figuras de las constelaciones que conocemos dibujadas en 3D, para verlas deformarse. Arrastra para mirar alrededor, la rueda acerca, pasa por encima de una estrella para su ficha. «✕ Volver», Esc o este botón para volver.",
   "c3sky.back": "Volver a la vista 3D (también Esc o «✦ Cielo desde la estrella»)",
   "c3sky.persp": "Perspectiva: lo que verías mirando en una dirección (estereográfica, de 10° a 180° de lado a lado). Arrastra para mirar alrededor; la rueda acerca; alejar más allá de 180° enseña todo el cielo.",
   "c3sky.all": "Todo el cielo en un mapa (Hammer-Aitoff, de igual área), centrado donde miras. Arrastra para girarlo; la rueda vuelve a la perspectiva bajo el cursor.",
   "c3sky.lines": "Las figuras de las constelaciones (Stellarium «modern»), dibujadas entre las posiciones 3D de verdad de sus estrellas: vistas desde otra estrella se deforman o se rompen. Un trazo de más de 20° se apaga con su largo y uno de más de 70° no se dibuja (cruzaría medio cielo)",
   "c3sky.names": "Nombres: de las constelaciones (en el centro de su figura, vista desde aquí) y de las estrellas más brillantes",
   "c3sky.grid": "La retícula AR/Dec (cada 30° y cada 2 h). Las direcciones no cambian con el sitio desde el que se mira: la retícula es la misma en todas partes",
   "c3sky.photo": "La foto: su contorno (las direcciones que abarca, vistas desde el Sol) y todas sus estrellas, también las débiles (como puntos tenues), donde se ven desde aquí",
   "c3sky.mag": "Magnitud más débil que se dibuja (vista desde aquí): − menos estrellas, + más (de 3 a 8)",
   "c3sky.lookSun": "Mirar al Sol (desde aquí es una estrella más)",
   "c3sky.lookField": "Mirar donde se ven desde aquí las estrellas de la foto (desde una estrella del campo pueden quedar repartidas por todo el cielo)",
   "c3sky.lookCentre": "Mirar en la dirección en la que mira la foto desde la Tierra",
   "c3sky.fromStar": "Ver el cielo desde la estrella elegida",
   "c3sky.fromSun": "Ver el mismo cielo desde el Sol, para comparar: el cielo de verdad",
   "c3sky.go": "Ir a esta estrella y ver el cielo desde ella"
};
(function() {
   var k;
   for (k in C3_SKYE_ES) C3_I18N_ES[k] = C3_SKYE_ES[k];
   for (k in C3_SKYE_TIPS_EN) C3_TOOLTIPS_EN[k] = C3_SKYE_TIPS_EN[k];
   for (k in C3_SKYE_TIPS_ES) C3_TOOLTIPS_ES[k] = C3_SKYE_TIPS_ES[k];
})();
// --- H5/H6 (21-oct) ---
// H5: el editor de camaras (pie «▾ n more», ayuda en el tooltip). H6: el planetario (lineas apagadas lejos, la bruma de la foto,
// la paralaje del sistema, nombres de la IAU). Un bloque propio al final, que se fusiona encima de lo anterior.
var C3_H56_ES = {
   "%d above": "%d arriba", "%d more": "%d más",
   "Show the next views (also with the mouse wheel)": "Ver las vistas siguientes (también con la rueda del ratón)",
   "Show the previous views (also with the mouse wheel)": "Ver las vistas anteriores (también con la rueda del ratón)",
   "Constellation lines are off: from here %s of the 88 figures we know crowd within 40° of the Sun (press «LINES» to draw them anyway).": "Las líneas de las constelaciones están apagadas: desde aquí %s de las 88 figuras que conocemos se apiñan a menos de 40° del Sol (pulsa «LÍNEAS» para dibujarlas igualmente).",
   "Distance: the parallax of its system (weighted mean of its components within 30″, Hipparcos)": "Distancia: la paralaje de su sistema (media ponderada de sus componentes a menos de 30″, Hipparcos)",
   "%s AU": "%s ua",
   "Hipparcos (ESA 1997; van Leeuwen 2007) to V 8 + %s stars of the photo (Gaia DR3; %s of them are also in Hipparcos: drawn once) · figures: Stellarium «modern» (CC BY-SA 4.0) · star names: IAU (WGSN) · stars of one system share its parallax · the Sun's constellation: Roman 1987 · %s projection, east to the left · drag to look around, wheel to zoom, double click to centre, click a star for its card": "Hipparcos (ESA 1997; van Leeuwen 2007) hasta V 8 + %s estrellas de la foto (Gaia DR3; %s de ellas están también en Hipparcos: se dibujan una vez) · figuras: Stellarium «modern» (CC BY-SA 4.0) · nombres de estrellas: IAU (WGSN) · las estrellas de un mismo sistema comparten su paralaje · la constelación del Sol: Roman 1987 · proyección %s, el este a la izquierda · arrastra para mirar alrededor, la rueda acerca, doble clic centra, clic en una estrella para su ficha"
};
var C3_H56_TIPS_EN = {
   "c3sky.lines": "The constellation figures (Stellarium «modern»), drawn between the real 3D positions of their stars: seen from another star they deform or break apart. A stroke longer than 20° fades with its length and one longer than 70° is not drawn (it would cross half the sky). From more than 50 ly away (or when more than 30 figures crowd within 40° of the Sun) they start off: they would form a hedgehog around the Sun",
   "c3sky.photo": "The photo: its outline (the directions it covers, as seen from the Sun) and its stars in the places they are seen from here: the ones brighter than the limit as usual, and of the fainter ones only the 1 500 brightest as seen from here, each one a faint dot"
};
var C3_H56_TIPS_ES = {
   "c3sky.lines": "Las figuras de las constelaciones (Stellarium «modern»), dibujadas entre las posiciones 3D de verdad de sus estrellas: vistas desde otra estrella se deforman o se rompen. Un trazo de más de 20° se apaga con su largo y uno de más de 70° no se dibuja (cruzaría medio cielo). A más de 50 al del Sol (o si más de 30 figuras se apiñan a menos de 40° del Sol) empiezan apagadas: formarían un erizo alrededor del Sol",
   "c3sky.photo": "La foto: su contorno (las direcciones que abarca, vistas desde el Sol) y sus estrellas donde se ven desde aquí: las más brillantes que el límite como las demás y, de las más débiles, solo las 1 500 más brillantes vistas desde aquí, cada una un punto tenue"
};
(function() {
   var k;
   for (k in C3_H56_ES) C3_I18N_ES[k] = C3_H56_ES[k];
   for (k in C3_H56_TIPS_EN) C3_TOOLTIPS_EN[k] = C3_H56_TIPS_EN[k];
   for (k in C3_H56_TIPS_ES) C3_TOOLTIPS_ES[k] = C3_H56_TIPS_ES[k];
})();

// --- tarea «nombres en las placas» (21-oct-2026): el PAPEL de un destacado con su clase, en la segunda linea de la placa ---
var C3_NAMES_ES = {
   "nearest cluster": "cúmulo más cercano", "farthest cluster": "cúmulo más lejano",
   "nearest galaxy": "galaxia más cercana", "farthest galaxy": "galaxia más lejana",
   "nearest quasar": "cuásar más cercano", "farthest quasar": "cuásar más lejano",
   "nearest group of galaxies": "grupo de galaxias más cercano", "farthest group of galaxies": "grupo de galaxias más lejano",
   "nearest nebula": "nebulosa más cercana", "farthest nebula": "nebulosa más lejana",
   "nearest object": "objeto más cercano", "farthest object": "objeto más lejano"
};
(function() { for (var k in C3_NAMES_ES) C3_I18N_ES[k] = C3_NAMES_ES[k]; })();

// --- nombres legibles de SIMBAD (21-oct-2026) ---
var C3_NAMES2_ES = {
   "Asking SIMBAD for the names of the objects…": "Pidiendo a SIMBAD los nombres de los objetos…",
   "no readable names from SIMBAD: the plates keep their Gaia DR3 number.": "sin nombres legibles de SIMBAD: las placas se quedan con su número de Gaia DR3.",
   "SIMBAD: highlighted objects with a readable name instead of their Gaia DR3 number: %s.": "SIMBAD: objetos destacados con un nombre legible en vez de su número de Gaia DR3: %s."
};
(function() { for (var k in C3_NAMES2_ES) C3_I18N_ES[k] = C3_NAMES2_ES[k]; })();

// --- lo lejano de VizieR que no contesta (27-oct-2026, D3: tm/netstatus.js) ---
var C3_FARNET_ES = {
   "%s — no %s": "%s — sin %s",
   "without %s: the farthest galaxies and quasars of the field may be missing, so the farthest object shown may not be the farthest in the photo.": "sin %s: pueden faltar las galaxias y los cuásares más lejanos del campo, así que el objeto más lejano que se enseña puede no ser el más lejano de la foto."
};
(function() { for (var k in C3_FARNET_ES) C3_I18N_ES[k] = C3_FARNET_ES[k]; })();

// --- la foto sin estrellas propia, con la lista de Gaia (21-oct-2026): que metodo se ha usado y que con StarXTerminator o StarNet2 saldria mas limpio ---
var C3_STARLESS_ES = {
   "its own method (Gaia star positions and a morphological opening)": "su método propio (posiciones de estrellas de Gaia y una apertura morfológica)",
   "its own morphological opening": "su apertura morfológica propia",
   "StarXTerminator or StarNet2, if you have them, give a cleaner result.": "StarXTerminator o StarNet2, si los tienes, dan un resultado más limpio.",
   "Stars of the photo (nebula layers and time machine) removed with %s.": "Estrellas de la foto (capas de las nebulosas y máquina del tiempo) quitadas con %s."
};
(function() { for (var k in C3_STARLESS_ES) C3_I18N_ES[k] = C3_STARLESS_ES[k]; })();

// --- las estrellas del desplegable «Stars», tambien en la foto 2D (21-oct-2026; ui/photo_stars_overlay.js): el tooltip lo dice ---
var C3_OVST_TIPS_EN = {
   "sf.stars": "How the stars are drawn, in the 3D view AND on the photo. «Gaia»: a dot with the catalogue colour (the default); the photo shows a thin ring on each star in that colour (ring colours get a saturation boost so that differences can be seen). «Photo colour»: the dot takes the colour the star has in your photo; the photo rings take it too, and a SECOND ring marks the stars whose photo colour differs from Gaia beyond the scatter of your photo (the footer counts them, redder and bluer; with a well calibrated photo most look alike, that is physics). «Photo»: each star as your camera recorded it, cut out of the photo and placed at its distance (it shrinks with depth; in a flight it brightens as you approach); on the photo those stars carry NO ring (the photo is already that cut-out) and only the stars the 3D keeps as a dot are ringed. «Photo size»: the same keeping the size it has in the photo; its rings have the size the star measures in the photo. Only stars the photo separates cleanly get a cut-out; cluster members and stars with a close neighbour keep their dot. Size and colour are those of the photo, not of the star. Stars with a doubtful distance (RUWE of 1.4 or more) are drawn hollow in the 3D and with a dashed ring on the photo. To hide the rings and see your photo clean, use the button at the top left of the photo (the option here stays as it is). Rings are hidden while the time machine is away from «now» (the photo then shows the stars where they were). Your choice is remembered"
};
var C3_OVST_TIPS_ES = {
   "sf.stars": "Cómo se pintan las estrellas, en la vista 3D Y en la foto. «Gaia»: un punto con el color del catálogo (de fábrica); la foto muestra un anillo fino en cada estrella de ese color (los colores de los anillos llevan un realce de saturación para que se vean las diferencias). «Color de la foto»: el punto toma el color que la estrella tiene en tu foto; los anillos de la foto también, y un SEGUNDO anillo marca las estrellas cuyo color en la foto difiere del de Gaia más allá de la dispersión de tu foto (el pie las cuenta, más rojas y más azules; con una foto bien calibrada la mayoría se parece: es física). «Foto»: cada estrella como la registró tu cámara, recortada de la foto y colocada a su distancia (mengua con la profundidad; en un vuelo gana brillo al acercarse); en la foto esas estrellas NO llevan anillo (la foto ya es ese recorte) y solo se anillan las que el 3D deja como punto. «Tamaño de la foto»: lo mismo con el tamaño que tiene en la foto; sus anillos tienen el tamaño que mide la estrella en la foto. Solo llevan recorte las que la foto separa limpias; los miembros de un cúmulo y las que tienen una vecina cerca se quedan con su punto. El tamaño y el color son los de la foto, no los de la estrella. Las estrellas de distancia dudosa (RUWE de 1,4 o más) se pintan huecas en el 3D y con un anillo a trazos en la foto. Para ocultar los anillos y ver tu foto limpia, usa el botón de arriba a la izquierda de la foto (la opción de aquí se queda como está). Los anillos se ocultan con la máquina del tiempo lejos de «ahora» (la foto entonces muestra las estrellas donde estaban). Se recuerda tu elección"
};
(function() {
   var k;
   C3_I18N_ES["%s of %s stars: the photo colour differs from Gaia (%s redder, %s bluer); double ring."] = "%s de %s estrellas: el color de la foto difiere del de Gaia (%s más rojas, %s más azules); doble anillo.";
   C3_I18N_ES["On average the photo is redder than Gaia (%s)."] = "De media la foto es más roja que Gaia (%s).";
   C3_I18N_ES["On average the photo is bluer than Gaia (%s)."] = "De media la foto es más azul que Gaia (%s).";
   C3_I18N_ES["%s stars with a doubtful distance (RUWE of 1.4 or more) are drawn hollow."] = "%s estrellas con distancia dudosa (RUWE de 1,4 o más) se pintan huecas.";
   C3_I18N_ES["%s stars with a doubtful distance (RUWE of 1.4 or more)"] = "%s estrellas con distancia dudosa (RUWE de 1,4 o más)";
   for (k in C3_OVST_TIPS_EN) C3_TOOLTIPS_EN[k] = C3_OVST_TIPS_EN[k];
   for (k in C3_OVST_TIPS_ES) C3_TOOLTIPS_ES[k] = C3_OVST_TIPS_ES[k];
})();

// --- el primer vistazo y el campo entero despues (22-oct-2026; ui/starfield_panel.js CP_SFUI_PROGRESSIVE) ---
(function() {
   C3_I18N_ES["Reading all the Gaia stars of the field…"] = "Leyendo todas las estrellas de Gaia del campo…";
   C3_I18N_ES["photometry"] = "fotometría";
   C3_I18N_ES["depth of the photo"] = "profundidad de la foto";
   C3_I18N_ES["first look: the stars down to G %s, reading the rest…"] = "primer vistazo: las estrellas hasta G %s, leyendo el resto…";
   C3_I18N_ES["only the stars down to G %s: the whole field could not be read"] = "solo las estrellas hasta G %s: no se pudo leer el campo entero";
})();

// --- el afinado con la cadena de CabraShared (22-oct-2026, tarde; tm/netstatus.js): quien dio las distancias si VizieR no pudo ---
(function() {
   C3_I18N_ES["%s answered something that is not the table"] = "%s contestó algo que no es la tabla";
   C3_I18N_ES["%s — distances from %s"] = "%s — distancias de %s";
   C3_I18N_ES["%s — distances from %s, without Bailer-Jones"] = "%s — distancias de %s, sin Bailer-Jones";
   C3_I18N_ES["VizieR did not answer"] = "VizieR no contestó";
   C3_I18N_ES["%s (backup for VizieR): real parallax errors, RUWE and Bailer-Jones distances for %s stars; local against its parallax: median difference %s mas (%s stars differ by more than 0.001 mas and keep the local one)."] = "%s (respaldo de VizieR): errores reales de la paralaje, RUWE y distancias de Bailer-Jones de %s estrellas; paralaje local frente a la suya: diferencia mediana %s mas (%s estrellas difieren en más de 0,001 mas y se quedan con la local).";
   C3_I18N_ES["%s (backup for VizieR): real parallax errors and RUWE for %s stars, WITHOUT Bailer-Jones distances (distances from the parallax); local against its parallax: median difference %s mas (%s stars differ by more than 0.001 mas and keep the local one)."] = "%s (respaldo de VizieR): errores reales de la paralaje y RUWE de %s estrellas, SIN distancias de Bailer-Jones (distancias por la paralaje); paralaje local frente a la suya: diferencia mediana %s mas (%s estrellas difieren en más de 0,001 mas y se quedan con la local).";
})();

// --- LA VISTA GALACTICA (23-oct-2026; tm/galaxy_view.js; el mapa lleva sus cadenas en CabraShared/csh_galaxy_i18n.js) ---
var C3_GX_TIPS_EN = {
   "gx.field": "The 3D view of the field: the photo and what lies behind it, at its distance (the view of always).",
   "gx.galaxy": "The stars of this field in the Milky Way: where they are and their orbits round the Galaxy (those with a distance, a proper motion and a radial velocity: Gaia DR3, or that of their cluster). The time machine moves them along their orbits. The map and the physics are those of StellarChemistry, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023).",
   "gx.top": "The Milky Way seen from its north pole (X–Y): the Sun below the centre, the Galaxy turning clockwise. Drag: move · wheel: zoom at the cursor · double-click: whole view · click: choose a star (the same one in the photo).",
   "gx.edge": "Distance from the centre (R) against height above the disc (z): how far each star climbs out of the plane. Drag: move · wheel: zoom · double-click: whole view · click: choose a star.",
   "gx.3d": "The Galaxy in 3D, with the 3D camera. Drag: turn · Shift or right button + drag: move · wheel: travel towards the cursor · double-click: whole view · click: choose a star.",
   "gx.orbits": "Draw the orbit of each star: 420 million years centred on today (about two turns of the Sun). The chosen one, all that is integrated, with its pericentre, apocentre, Zmax and eccentricity (2 billion years, as in StellarChemistry).",
   "gx.dust": "The dust of the whole Galaxy, measured TODAY. With the time machine it turns with the Galaxy (each ring at its own speed, the same potential as the stars: near the Sun it barely moves with respect to the Sun) and loses its shape with the life of the clouds (half of today's structure is gone after 14 Myr, τ = 20 Myr; Kim et al. 2022, Chevance et al. 2020): beyond 20 Myr its position is illustrative and beyond ~80 Myr only the smooth disc remains. Edge-on, if the sheet would be too thin to see, it is drawn thicker (the legend says ×n). MEASURED within 4.8 kpc of the Sun: Vergely, Lallement & Cox 2022 (A&A 664, A174; 50 pc cube, Gaia + 2MASS) and, within 1.2 kpc, Edenhofer et al. 2024 (A&A 685, A82: the same map as the field's «Dust»). Beyond, a MODEL: the smooth disc of Galaxia (Sharma et al. 2011; scale length 4.2 kpc, height 88 pc) scaled to match the measured column at 3.8–4.8 kpc. The seam is drawn dashed and the model is greyer and fainter: it never passes for a measurement. From above and in 3D, the dust crossed vertically (A_V); edge-on, the mean of the whole ring (at most 20 % of each ring is measured). A light haze: orbits, stars and the Sun always read on top.",
   "gx.col.gaia": "Colour of each star: its Gaia colour (BP−RP), the same as the dots of the 3D view of the field.",
   "gx.col.dist": "Colour of each star: its distance from the Sun (blue near, cream at a few hundred parsecs, gold at a few kiloparsecs).",
   "gx.record": "Records the time machine in the galaxy view chosen (from above, edge-on or 3D turning slowly) as a video, now, with the size, frame rate, title and folder chosen (▾ changes them). The same button cancels."
};
var C3_GX_TIPS_ES = {
   "gx.field": "La vista 3D del campo: la foto y lo que hay detrás, a su distancia (la de siempre).",
   "gx.galaxy": "Las estrellas de este campo en la Vía Láctea: dónde están y sus órbitas alrededor de la Galaxia (las que tienen distancia, movimiento propio y velocidad radial: de Gaia DR3, o la de su cúmulo). La máquina del tiempo las mueve por sus órbitas. El mapa y la física son los de StellarChemistry, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023).",
   "gx.top": "La Vía Láctea vista desde su polo norte (X–Y): el Sol debajo del centro y la Galaxia girando como las agujas del reloj. Arrastrar: mover · rueda: acercar hacia el cursor · doble clic: vista entera · clic: elegir una estrella (la misma en la foto).",
   "gx.edge": "Distancia al centro (R) frente a altura sobre el disco (z): cuánto se sale cada estrella del plano. Arrastrar: mover · rueda: acercar · doble clic: vista entera · clic: elegir una estrella.",
   "gx.3d": "La Galaxia en 3D, con la cámara del 3D. Arrastrar: girar · Mayús o botón derecho + arrastrar: mover · rueda: avanzar hacia el cursor · doble clic: vista entera · clic: elegir una estrella.",
   "gx.orbits": "Dibujar la órbita de cada estrella: 420 millones de años centrados en hoy (unas dos vueltas del Sol). La elegida, todo lo integrado, con su pericentro, apocentro, Zmax y excentricidad (2000 millones de años, como en StellarChemistry).",
   "gx.dust": "El polvo de la Galaxia entera, medido HOY. Con la máquina del tiempo gira con la Galaxia (cada anillo a su velocidad, el mismo potencial que las estrellas: cerca del Sol apenas se mueve respecto al Sol) y pierde su forma con la vida de las nubes (la mitad de la estructura de hoy se ha ido a los 14 Ma, τ = 20 Ma; Kim et al. 2022, Chevance et al. 2020): pasados 20 Ma su posición es ilustrativa y pasados ~80 Ma solo queda el disco liso. De canto, si la lámina quedara demasiado fina para verse, se dibuja más gruesa (la leyenda dice ×n). MEDIDO hasta 4,8 kpc del Sol: Vergely, Lallement y Cox 2022 (A&A 664, A174; cubo de 50 pc, Gaia + 2MASS) y, hasta 1,2 kpc, Edenhofer et al. 2024 (A&A 685, A82: el mismo mapa del «Polvo» del campo). Más allá, un MODELO: el disco liso de Galaxia (Sharma et al. 2011; escala radial 4,2 kpc, altura 88 pc) ajustado a la columna medida a 3,8–4,8 kpc. La costura va a trazos y el modelo, más gris y más tenue: nunca pasa por medido. Desde arriba y en 3D, el polvo que se cruza en vertical (A_V); de canto, la media del anillo entero (de cada anillo, como mucho el 20 % es medido). Una bruma tenue: las órbitas, las estrellas y el Sol se leen siempre encima.",
   "gx.col.gaia": "Color de cada estrella: su color de Gaia (BP−RP), el mismo de los puntos de la vista 3D del campo.",
   "gx.col.dist": "Color de cada estrella: su distancia al Sol (azul cerca, crema a unos cientos de pársecs, oro a unos kilopársecs).",
   "gx.record": "Graba la máquina del tiempo en la vista galáctica elegida (desde arriba, de canto o en 3D girando despacio) en un vídeo, ya, con el tamaño, el ritmo, el título y la carpeta elegidos (▾ los cambia). El mismo botón cancela."
};
(function() {
   var k;
   C3_I18N_ES["Field"] = "Campo";
   C3_I18N_ES["Galaxy"] = "Galaxia";
   C3_I18N_ES["From above"] = "Desde arriba";
   C3_I18N_ES["Edge-on"] = "De canto";
   C3_I18N_ES["Orbits"] = "Órbitas";
   C3_I18N_ES["Colour"] = "Color";
   C3_I18N_ES["Distance"] = "Distancia";
   C3_I18N_ES["THE GALAXY"] = "LA GALAXIA";
   C3_I18N_ES["where its stars are in the Milky Way"] = "dónde están sus estrellas en la Vía Láctea";
   C3_I18N_ES["Field view only: switch to 3D VIEW › Field."] = "Solo en la vista del campo: pasa a VISTA 3D › Campo.";
   C3_I18N_ES["Flights go through the field: switch to 3D VIEW › Field. In the galaxy, ● Record records the time machine: choose it beside ● Record."] = "Los vuelos van por el campo: pasa a VISTA 3D › Campo. En la galaxia, ● Grabar graba la máquina del tiempo: elígela junto a ● Grabar.";
   C3_I18N_ES["the time machine: photo + galaxy"] = "la máquina del tiempo: foto + galaxia";
   C3_I18N_ES["the time machine: galaxy"] = "la máquina del tiempo: galaxia";
   // (26-oct: los vuelos por la galaxia, tm/galaxy_flight.js)
   C3_I18N_ES["A FLIGHT THROUGH THE MILKY WAY"] = "UN VUELO POR LA VÍA LÁCTEA";
   C3_I18N_ES["«My flight» is made of views of the field's 3D box: in the galaxy choose Dive, Orbit or Grand tour (or switch to 3D VIEW › Field)."] = "«Mi vuelo» se hace con vistas de la caja 3D del campo: en la galaxia elige Zambullida, Órbita o El gran viaje (o pasa a VISTA 3D › Campo).";
   C3_I18N_ES["the flight through the galaxy"] = "el vuelo por la galaxia";
   C3_I18N_ES["No star of this field has an orbit yet: the galaxy flights follow them (the status line says why)."] = "Ninguna estrella de este campo tiene órbita todavía: los vuelos por la galaxia las siguen (la línea de estado dice por qué).";
   C3_I18N_ES["Galaxy: %s stars of this field with an orbit (%s without radial velocity yet)"] = "Galaxia: %s estrellas de este campo con órbita (%s aún sin velocidad radial)";
   C3_I18N_ES["%s with their own Gaia DR3 radial velocity, %s with that of their cluster."] = "%s con su propia velocidad radial de Gaia DR3, %s con la de su cúmulo.";
   C3_I18N_ES["The map: orbits integrated in MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023): the same potential as the field's «Galactic orbits» and StellarChemistry."] = "El mapa: órbitas integradas en MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023): el mismo potencial que las «Órbitas galácticas» del campo y StellarChemistry.";
   C3_I18N_ES["Integrating %s orbits in the Milky Way (MilkyWayPotential2022)…"] = "Integrando %s órbitas en la Vía Láctea (MilkyWayPotential2022)…";
   C3_I18N_ES["Integrating %s orbits in the Milky Way (MilkyWayPotential2022)… %d %%"] = "Integrando %s órbitas en la Vía Láctea (MilkyWayPotential2022)… %d %%";
   C3_I18N_ES["radial velocity of its cluster"] = "velocidad radial de su cúmulo";
   C3_I18N_ES["radial velocity of Gaia DR3"] = "velocidad radial de Gaia DR3";
   C3_I18N_ES["%s with the cluster's radial velocity"] = "%s con la velocidad radial del cúmulo";
   C3_I18N_ES["orbits in MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), the same as the time machine of the field"] = "órbitas en MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023), el mismo de la máquina del tiempo del campo";
   C3_I18N_ES["THE SAME STARS IN THE MILKY WAY"] = "LAS MISMAS ESTRELLAS EN LA VÍA LÁCTEA";
   C3_I18N_ES["orbits in the Milky Way (MilkyWayPotential2022)"] = "órbitas en la Vía Láctea (MilkyWayPotential2022)";
   // (23-oct-2026, tarde) la escala propia de la galaxia y el mapa sin ninguna órbita
   C3_GX_TIPS_EN["gx.range"] = "How far the time machine goes in the galaxy, each side of now. The galaxy has its own scale (remembered apart from the field's): at less than ±10 Myr the stars barely move on a map of kiloparsecs. Back in the Field, its own scale returns.";
   C3_GX_TIPS_ES["gx.range"] = "Hasta dónde llega la máquina del tiempo en la galaxia, a cada lado de ahora. La galaxia tiene su propia escala (recordada aparte de la del campo): a menos de ±10 Ma las estrellas apenas se mueven en un mapa de kilopársecs. Al volver a Campo, vuelve la suya.";
   C3_I18N_ES["The whole field is still being read from Gaia; then VizieR is asked for the radial velocities."] = "Aún se está leyendo de Gaia el campo entero; después se piden a VizieR las velocidades radiales.";
   C3_I18N_ES["Waiting for the radial velocities (Gaia DR3, from VizieR, GAVO or ESA): an orbit needs a distance, a proper motion and a radial velocity. They arrive in a few seconds."] = "Esperando las velocidades radiales (Gaia DR3, de VizieR, GAVO o ESA): una órbita necesita distancia, movimiento propio y velocidad radial. Llegan en unos segundos.";
   C3_I18N_ES["Neither VizieR nor its backups GAVO and ESA sent the radial velocities (Gaia DR3) and there is no copy in the cache: without them no star has an orbit. «↻ Retry» in the status line asks again."] = "Ni VizieR ni sus respaldos GAVO y ESA han enviado las velocidades radiales (Gaia DR3) y no hay copia en la caché: sin ellas ninguna estrella tiene órbita. «↻ Reintentar» en la línea de estado las vuelve a pedir.";
   C3_I18N_ES["Gaia DR3 measures the radial velocity only of the brighter stars (G up to about 15): none of this field has one, nor a cluster that gives it its own."] = "Gaia DR3 solo mide la velocidad radial de las estrellas más brillantes (hasta G ≈ 15): ninguna de este campo la tiene, ni un cúmulo que le dé la suya.";
   // (23-oct-2026, noche; revisión visual) en la galaxia, el MOVIMIENTO es siempre por órbitas (el mismo potencial que el mapa); la típica del campo
   C3_GX_TIPS_EN["gx.motion"] = "In the galaxy view the time machine always moves the stars along their Galactic orbits, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023): the same potential that draws the map, also in the photo and in the video. Straight lines are only an approximation for the field (valid to ~1 Myr): back in 3D VIEW › Field, the motion chosen there returns.";
   C3_GX_TIPS_ES["gx.motion"] = "En la vista Galaxia la máquina del tiempo mueve siempre las estrellas por sus órbitas galácticas, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023): el mismo potencial que dibuja el mapa, también en la foto y en el vídeo. Las rectas solo son una aproximación para el campo (valen hasta ~1 Ma): al volver a VISTA 3D › Campo, vuelve el movimiento elegido allí.";
   C3_I18N_ES["a typical star of the field (closest to the median orbit)"] = "una estrella típica del campo (la más cercana a la órbita mediana)";
   for (k in C3_GX_TIPS_EN) C3_TOOLTIPS_EN[k] = C3_GX_TIPS_EN[k];
   for (k in C3_GX_TIPS_ES) C3_TOOLTIPS_ES[k] = C3_GX_TIPS_ES[k];
})();

// (27-oct-2026) las cadenas de la ficha de la Galaxia (tm/galaxy_card.js) y del nombre-enlace (ui/star_link.js), que esos ficheros definen
// dentro de si: tambien AQUI, en el diccionario, para que la prueba de «todo tiene castellano» (tests/c3_blockF_cases.js F3.2) las vea.
// Mismo texto que alli (si cambia uno, el otro).
(function() {
   C3_I18N_ES["Galaxy"] = "Galaxia";
   C3_I18N_ES["not on a bound orbit"] = "sin órbita ligada";
   C3_I18N_ES["≈ approximate: it passes so close to the Galactic centre that the energy was not conserved even with a 16 times finer step"] = "≈ aproximada: pasa tan cerca del centro de la Galaxia que la energía no se conservó ni con un paso 16 veces más fino";     // (27-oct, R2)
   C3_I18N_ES["no orbit: no radial velocity"] = "sin órbita: sin velocidad radial";
   C3_I18N_ES["not on the map: it needs a distance and a radial velocity"] = "no está en el mapa: le falta la distancia o la velocidad radial";
   C3_I18N_ES["distance from the Galactic centre (R) and height over the plane (z)"] = "distancia al centro galáctico (R) y altura sobre el plano (z)";
   C3_I18N_ES["Orbit over the next 2 Gyr (pericentre, apocentre, maximum height, eccentricity)"] = "Órbita en los próximos 2 Ga (pericentro, apocentro, altura máxima, excentricidad)";
   C3_I18N_ES["Open in SIMBAD"] = "Abrir en SIMBAD";
})();

// (27-oct-2026, noche) la RV con reserva GAVO (tm/timemachine_run.js, tm/netstatus.js): de donde salen las velocidades radiales
(function() {
   C3_I18N_ES["%s — radial velocities from %s"] = "%s — velocidades radiales de %s";
   C3_I18N_ES["%s (backup for VizieR): %s radial velocities (Gaia DR3, gaia.dr3lite)%s."] = "%s (respaldo de VizieR): %s velocidades radiales (Gaia DR3, gaia.dr3lite)%s.";
   C3_I18N_ES["(from the cache: %s)"] = "(de la caché: %s)";
   // (28-oct, V7) el tooltip de la leyenda estrecha del 3D a lienzo pequeño: lo que la leyenda ya no pinta
   C3_I18N_ES["Also in this map:"] = "Además, en este mapa:";
   // (28-oct, A) la ficha de un objeto cuyo tamaño sale de OpenNGC porque SIMBAD no lo tiene (M 82)
   C3_I18N_ES["size from OpenNGC (%s): SIMBAD has none"] = "tamaño de OpenNGC (%s): SIMBAD no lo tiene";
   // (29-oct, barrido) la reserva de SIMBAD en la linea de estado (tm/netstatus.js): estaban registradas alli, fuera de la tabla, y la prueba
   // de castellano de toda la interfaz (tests/c3_blockF_cases.js F3.2) no las veia. Su sitio es este (regla 2 del CLAUDE.md).
   C3_I18N_ES["SIMBAD (CDS) did not answer — answered by %s"] = "SIMBAD (CDS) no contestó — contestó %s";
   C3_I18N_ES["%s (backup for SIMBAD (CDS)): the galaxies, quasars and nebulae of the field."] = "%s (respaldo de SIMBAD (CDS)): las galaxias, cuásares y nebulosas del campo.";
   C3_I18N_ES["%s (backup for SIMBAD (CDS)): the distances of the nebulae of the field."] = "%s (respaldo de SIMBAD (CDS)): las distancias de las nebulosas del campo.";
   // (29-oct, P8) la reserva de VizieR para GLADE+ / Quaia (CabraShared csh_net.js cshVizierGet; la linea de estado en tm/netstatus.js)
   C3_I18N_ES["VizieR (CDS) did not answer — %s from %s"] = "VizieR (CDS) no contestó — %s de %s";
   C3_I18N_ES["%s (backup for VizieR (CDS)): %s, the farthest galaxies and quasars of the field."] = "%s (respaldo de VizieR (CDS)): %s, las galaxias y cuásares más lejanos del campo.";
   // (1-nov, D3 del video de formacion) la «mas cercana / mas lejana» deja fuera las estrellas de distancia DUDOSA (RUWE >= 1,4, pintadas huecas): el rotulo lo dice
   C3_I18N_ES["nearest star with a reliable distance"] = "la estrella más cercana con distancia fiable";
   C3_I18N_ES["farthest star with a reliable distance"] = "la estrella más lejana con distancia fiable";
   // (1-nov, D4) la entrada de la leyenda para las estrellas que entran desde fuera de la foto (tm/tm_incoming.js): cuadrado abierto
   C3_I18N_ES["open square: comes in from outside your photo (Gaia; no radial velocity)"] = "cuadrado: entra desde fuera de tu foto (Gaia; sin velocidad radial)";
   C3_I18N_ES["comes in"] = "entra";
   // (1-nov, D8) el pie de «Photo» / «Photo size» mientras todas las estrellas sean puntos
   C3_I18N_ES["From here the stars are still points: zoom the 3D in and they open into their cut-outs of the photo («Photo» makes them smaller with depth, «Photo size» keeps their size in the photo)."] = "De lejos las estrellas siguen siendo puntos: acerca el 3D y se abren en sus recortes de la foto («Foto» las hace más pequeñas con la profundidad, «Tamaño de la foto» conserva su tamaño en la foto).";
})();

// (2-nov-2026, decisiones 1A, 2, 3A y 4 de Nino; docs/investigacion_orbitas_largo_plazo.md) el paso solo a órbitas, la gravedad propia de los cúmulos
// (escapadas en gris) y su edad
(function() {
   C3_I18N_ES["Orbits · auto"] = "Órbitas · auto";
   C3_I18N_ES["«Galactic orbits» has been chosen by itself because the range is 10 Myr or more: straight lines drift from the real orbits by 12–14 %% at 10 Myr, and more and more after (the stars circle the Galaxy, they do not fly straight). Below 10 Myr your choice, «%s», comes back. You can still pick a straight line here to compare."] =
      "«Órbitas galácticas» se ha elegido sola porque el alcance es de 10 Ma o más: las rectas se separan de las órbitas de verdad un 12–14 %% a 10 Ma, y cada vez más después (las estrellas giran alrededor de la Galaxia, no van en línea recta). Por debajo de 10 Ma vuelve lo que elegiste, «%s». Aún puedes elegir aquí una recta para comparar.";
   C3_I18N_ES["«Galactic orbits» chosen by itself for a range of 10 Myr or more; «%s» comes back below."] = "«Órbitas galácticas» elegida sola para un alcance de 10 Ma o más; por debajo vuelve «%s».";
   C3_I18N_ES["%s · not yet formed (age ≈ %s, Hunt & Reffert 2023): its stars are not drawn"] = "%s · aún no se había formado (edad ≈ %s, Hunt y Reffert 2023): sus estrellas no se dibujan";
   C3_I18N_ES["%s · %s %% still bound, %s %% escaped"] = "%s · %s %% siguen unidas, %s %% escapadas";
   C3_I18N_ES["%s: its members move with the cluster plus %s %% of how far Gaia says they depart from it on the sky (the rest is explained by Gaia's errors); the centre moves with their median."] =
      "%s: sus miembros se mueven con el cúmulo más el %s %% de lo que Gaia dice que se separan de él en el cielo (el resto lo explican los errores de Gaia); el centro se mueve con su mediana.";
   C3_I18N_ES["%s: Jacobi radius %s pc = the tidal radius rt of Hunt & Reffert 2023 (%s° at %s pc); mass ≈ %s M☉, the one that makes rt its Jacobi radius in MilkyWayPotential2022 at R = %s kpc; a rigid Plummer sphere of scale %s pc (their r50) holds its stars, with «Galactic orbits». Escaped = farther than the Jacobi radius from the centre (grey)."] =
      "%s: radio de Jacobi %s pc = el radio de marea rt de Hunt y Reffert 2023 (%s° a %s pc); masa ≈ %s M☉, la que hace de rt su radio de Jacobi en MilkyWayPotential2022 a R = %s kpc; una esfera de Plummer rígida de escala %s pc (su r50) sujeta sus estrellas, con «Órbitas galácticas». Escapada = más lejos del centro que el radio de Jacobi (gris).";
   C3_I18N_ES["%s: age ≈ %s (log age %s, Hunt & Reffert 2023): before that its stars are not drawn."] = "%s: edad ≈ %s (log de la edad %s, Hunt y Reffert 2023): antes no se dibujan sus estrellas.";
   C3_I18N_ES["A cluster's own gravity is a rigid Plummer sphere, not every star pulling on every other; without the molecular clouds that shake real clusters, it holds them together somewhat too long (real ones dissolve in 0.1–0.25 Gyr)."] =
      "La gravedad propia de un cúmulo es una esfera de Plummer rígida, no cada estrella tirando de todas las demás; sin las nubes moleculares que zarandean a los cúmulos de verdad, los mantiene unidos algo de más (los reales se deshacen en 0,1–0,25 Ga).";
   C3_I18N_ES["With the rotating bar (Dehnen 2000 quadrupole; pattern speed %s km/s/kpc, angle %s°, strength %s)."] = "Con la barra que gira (cuadrupolo de Dehnen 2000; velocidad de patrón %s km/s/kpc, ángulo %s°, intensidad %s).";
   // (2-nov-2026, noche: decisión Q2b) lo dibujado lleva la barra; la ficha no
   C3_I18N_ES["The drawn orbit includes the rotating bar (Dehnen 2000); these numbers do not (axisymmetric potential, comparable with the literature and with StellarChemistry), so the line can rise higher than this Zmax."] = "La órbita dibujada lleva la barra que gira (Dehnen 2000); estas cifras no (potencial sin barra, comparable con la literatura y con StellarChemistry): por eso la línea puede subir más que esta Zmax.";
   C3_I18N_ES["The chosen star's numbers (pericentre, apocentre, Zmax, e) are without the bar, as in StellarChemistry."] = "Las cifras de la elegida (pericentro, apocentro, Zmax, e) son sin la barra, como en StellarChemistry.";
   C3_I18N_ES["Beyond ~100 Myr the model lacks the spiral arms and the encounters with clouds, which weigh more and more: take it as an illustration."] = "Pasados ~100 Ma al modelo le faltan los brazos espirales y los encuentros con las nubes, que pesan cada vez más: tómalo como una ilustración.";
   // (decisión 5: el cono que apaga lo que no se sabe y la nube de la elegida)
   C3_I18N_ES["%s stars faded out: where they are at this instant is not known to better than a tenth of the photo"] = "%s estrellas se han apagado: en este instante su sitio no se sabe mejor que una décima parte de la foto";
   // (Q3 = A, 2-nov, noche: no se esconden, se quedan al 25 %; Q1 = A: el suelo virial)
   C3_I18N_ES["%s stars uncertain, drawn faint (25 %%): where they are at this instant is not known to better than a tenth of the photo"] = "%s estrellas inciertas, pintadas tenues (25 %%): en este instante su sitio no se sabe mejor que una décima parte de la foto";
   C3_I18N_ES["%s: Gaia's errors explain most of what its members seem to depart on the sky, so they keep at least the internal motion its own gravity gives: %s km/s (virial dispersion of a Plummer sphere of its mass and r50); the centre moves with their median."] =
      "%s: los errores de Gaia explican casi todo lo que sus miembros parecen separarse en el cielo, así que conservan como poco el movimiento interno que le da su propia gravedad: %s km/s (dispersión virial de una esfera de Plummer de su masa y su r50); el centro se mueve con su mediana.";
   C3_I18N_ES["A star dims down to a quarter when its error passes %s° in the sky (a tenth of the photo's short side) or a quarter of its distance in depth, from its Gaia errors: distance interval, proper motion (%s), radial velocity (30 km/s assumed without one)."] =
      "Una estrella se atenúa hasta una cuarta parte cuando su error pasa de %s° en el cielo (una décima parte del lado menor de la foto) o de una cuarta parte de su distancia en profundidad, por sus errores de Gaia: intervalo de distancia, movimiento propio (%s), velocidad radial (30 km/s supuestos si no la tiene).";
   // (2-nov, Q4: de dónde salió el error del movimiento propio)
   C3_I18N_ES["each star's own Gaia error"] = "el error de Gaia de cada estrella";
   C3_I18N_ES["each star's own Gaia error for %s of them; for the other %s, the typical Gaia error for its magnitude"] = "el error de Gaia de cada estrella en %s de ellas; en las otras %s, el error típico de Gaia para su magnitud";
   C3_I18N_ES["the typical Gaia error for its magnitude: the local database has no per-star errors and the network refinement did not bring them"] = "el error típico de Gaia para su magnitud: la base local no trae errores por estrella y el afinado en red no los ha traído";
   C3_I18N_ES["The amber cloud: %s possible places of the chosen star at this instant, from its Gaia errors (Monte Carlo; proper motion ± %s mas/yr, %s)."] = "La nube ámbar: %s sitios posibles de la estrella elegida en este instante, por sus errores de Gaia (Monte Carlo; movimiento propio ± %s mas/año, %s).";
   C3_I18N_ES["its own"] = "el suyo";
   C3_I18N_ES["typical for its magnitude"] = "el típico para su magnitud";
   // (5-nov-2026) el catalogo de nebulosas sin bajar (tm/netstatus.js)
   C3_I18N_ES["nebula catalogue not downloaded: the nebula stays on the photo"] = "catálogo de nebulosas sin bajar: la nebulosa se queda en la foto";
   C3_I18N_ES["Sharpless nebula catalogue (VizieR): %s. It is not included in the package (licence): it is downloaded the first time it is needed, and without it the nebula of the photo stays on the photo plane instead of at its distance. «↻ Retry» tries again now."] =
      "Catálogo de nebulosas de Sharpless (VizieR): %s. No va en el paquete (licencia): se baja la primera vez que hace falta y, sin él, la nebulosa de la foto se queda en el plano de la foto en vez de a su distancia. «↻ Reintentar» lo vuelve a intentar ahora.";
})();
