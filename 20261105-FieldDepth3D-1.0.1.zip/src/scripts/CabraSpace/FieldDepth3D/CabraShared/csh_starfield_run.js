// ============================================================================
// CabraShared/csh_starfield_run.js — EL CAMPO DE ESTRELLAS: lo que toca PixInsight (catalogos, fotometria, montaje,
// afinado en red, SIMBAD y nebulosas). UNA sola copia para CabraStars, Cabra3D y CabraStarAnalysis (15-oct-2026).
// ----------------------------------------------------------------------------
// PROCEDENCIA: CabraPilot integracion-1410c, CabraCore/src/engine/starfield_run.js:184-505 y 537-964, que CabraStars
// (lib/cs_run.js) y Cabra3D (src/engine/starfield_run.js) tenian copiado dos veces y ya divergian en 29 funciones.
// Se queda la version MAS AMPLIA de cada pieza:
//   · de CabraStars: Gaia por red si no hay base local (csh_gaia.js), afinado con respaldo en el archivo de ESA,
//     fallos de red con servidor y causa (csh_net.js), los puntos del HR (`res.hr`), la secuencia principal completa;
//   · de Cabra3D: lo lejano de SIMBAD (`cpStarfieldDeepSky`) y las nebulosas de Sharpless (`cpStarfieldNebulae`).
// La red, la base Gaia y la astrometria estan en csh_net.js, csh_gaia.js y csh_astrometry.js.
// ============================================================================

// ---- desde engine/starfield_run.js:184 ----
var CP_STARFIELD_FILE = #__FILE__;

// COSTURAS PARA PRUEBAS. La bateria no depende de la red ni de que haya una base
// Gaia registrada en su instancia: prueba con respuestas grabadas y con extractos
// reales del proceso (`_tests/cp_starfield_fx_*.csv`).
//   CP_SF_HTTP_HOOK( url, opts ) -> { ok, code, text, message }: las dos consultas
//      de red la usan EN VEZ de salir a la red.
//   CP_SF_GAIA_HOOK( field, magLimit, maxStars ) -> { ok, code, rows, ms,
//      truncated }: las filas del proceso Gaia, EN VEZ de ejecutarlo.
var CP_SF_GAIA_HOOK = null;
// Tope de una consulta, de principio a fin (conexion + respuesta). MEDIDO el
// 13-oct-2026: SIMBAD 0,5-2,7 s; TAPVizieR 6,3 s. El archivo de ESA tardo 41-55 s
// ese mismo dia (y 1,8 s por la mañana): por eso NO es el camino.
var CP_SF_SIMBAD_TAP = "https://simbad.cds.unistra.fr/simbad/sim-tap/sync";
var CP_SF_VIZIER_TAP = "https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync";

// Los catalogos empaquetados, leidos una vez: { ok, error, clusters, mainSequence }.
var CP_SF_CATALOGS = null;

// ---------------------------------------------------------------------------
// EL MOTIVO, EN TEXTO. Las funciones puras devuelven CODIGOS (estables: los
// tests los comparan); aqui se convierten en una frase para el usuario.
// ---------------------------------------------------------------------------
function cpStarfieldReasonText(code) {
   switch (String(code || "")) {
   case "": return "";
   case "no-view": return optT("no image is selected.");
   case "no-solution": return optT("the image has no astrometric solution: solve it first.");
   case "no-gaia": return optT("no Gaia database is registered in this PixInsight instance (Process > Global > Gaia > Preferences).");
   case "no-gaia-net": return optT("no local Gaia database, and the network did not answer either.");
   case "gaia-failed": return optT("the Gaia process did not finish the search (see the console).");
   case "no-stars": return optT("the Gaia database has no stars in this field.");
   case "no-catalogs": return optT("the packaged cluster catalogues could not be read.");
   case "mono": return optT("the image has a single channel: there is no colour to measure. Using Gaia colours.");
   case "nonlinear": return optT("the image is not linear: star fluxes are no longer proportional to brightness. Using Gaia colours.");
   case "reference-system": return optT("the astrometric solution is not in ICRS: star positions are not exact enough to measure them. Using Gaia colours.");
   case "few-stars": return optT("too few unsaturated, isolated stars to calibrate the photometry. Using Gaia colours.");
   case "colour-mismatch": return optT("the colour of the image does not follow the colour of the stars (narrowband or swapped channels?). Using Gaia colours.");
   case "measure-failed": return optT("the stars could not be measured in the image. Using Gaia colours.");
   case "colour-range": return optT("the colour of the image stops following the colour of the reddest (or bluest) stars: those are not placed with the colour of the image.");
   case "not-requested": return optT("photometry in the image was not requested. Using Gaia colours.");
   case "no-network": return optT("the service did not answer in time.");
   case "bad-answer": return optT("the service answered something that is not a table.");
   case "no-objects": return optT("the service knows no object with a distance or a redshift in this field.");
   case "no-rows": return optT("the service returned no star with a reliable parallax in this field.");
   case "no-catalog-pm": return optT("the catalogue gives no proper motion for this cluster.");
   case "no-nebula": return optT("no nebula of the Sharpless catalogue reaches this field.");
   case "no-nebula-catalog": return optT("the packaged nebula catalogue could not be read.");
   case "no-control": return optT("the cluster fills the frame and there are no field stars to compare with.");
   case "too-few": return optT("fewer than ten stars share the proper motion of the cluster.");
   case "not-significant": return optT("the stars that share the proper motion of the cluster are no more than the field would give by chance.");
   }
   return String(code);
}

// ---------------------------------------------------------------------------
// LOS CATALOGOS EMPAQUETADOS (src/data/starfield/, ver su PROVENANCE.txt)
// ---------------------------------------------------------------------------
// (CabraShared: los datos van en CabraShared/data/, junto a este fichero; PROVENANCE.txt dice de donde sale cada uno)
function cpSfDataDir() {
   var here = (File.extractDrive(CP_STARFIELD_FILE) + File.extractDirectory(CP_STARFIELD_FILE)).split("\\").join("/");
   if (here.charAt(here.length - 1) !== "/") here += "/";
   return here + "data/";
}

// (28-oct-2026, A) El tamaño de las galaxias NGC/IC/Messier de OpenNGC (data/galaxy_sizes_openngc.csv, ~400 kB): se lee UNA
// vez y solo si algun objeto de SIMBAD lo necesita (`cshSizeNeeds`). Si no se puede leer: { byKey: {}, rows: 0, error }.
var CSH_GALAXY_SIZES = null;
function cshGalaxySizes() {
   if (CSH_GALAXY_SIZES !== null) return CSH_GALAXY_SIZES;
   try { CSH_GALAXY_SIZES = cshOpenNgcSizes(File.readTextFile(cpSfDataDir() + "galaxy_sizes_openngc.csv")); }
   catch (e) { CSH_GALAXY_SIZES = { byKey: {}, rows: 0, meta: {}, error: String(e.message || e) }; }
   return CSH_GALAXY_SIZES;
}

function cpSfCatalogs() {
   if (CP_SF_CATALOGS !== null)
      return CP_SF_CATALOGS;
   var out = { ok: false, error: "", clusters: [], mainSequence: [], nebulae: [], nebulaError: "" };
   try {
      var dir = cpSfDataDir();
      // (3-nov-2026, CPD C8) en el paquete no va la parte de Baumgardt: csh_thirdparty.js la baja la primera vez y la casa con Harris
      // (si el script no lo incluye, o en el repositorio, globulars.csv tal cual)
      var gt = (typeof cshTpGlobularsText === "function") ? cshTpGlobularsText(dir) : { text: File.readTextFile(dir + "globulars.csv"), from: "repo" };
      out.globularsFrom = gt.from; if (gt.why) out.globularsWhy = gt.why;
      out.clusters = cpSfClusterCatalog(gt.text, File.readTextFile(dir + "clusters_hr23.csv"));
      out.mainSequence = cpSfMainSequence(File.readTextFile(dir + "main_sequence.csv"));
      out.ok = (out.clusters.length > 0);
      if (!out.ok) out.error = "empty";
   } catch (e) {
      out.error = String(e.message || e);
   }
   // (Cabra3D) las nebulosas de Sharpless empaquetadas
   // (3-nov-2026, CPD C8) en el paquete nebulae.csv no va: csh_thirdparty.js lo arma la primera vez con las tres tablas de VizieR (https)
   try {
      if (typeof cshTpNebulaeText === "function") {
         var nt = cshTpNebulaeText(cpSfDataDir());
         out.nebulaeFrom = nt.from;
         if (nt.text.length > 0) out.nebulae = cpSfNebulaCatalog(nt.text); else { out.nebulae = []; out.nebulaError = nt.why || "not available"; }
      } else out.nebulae = cpSfNebulaCatalog(File.readTextFile(cpSfDataDir() + "nebulae.csv"));
   } catch (eN) { out.nebulae = []; out.nebulaError = String(eN.message || eN); }
   // (CabraStars) la secuencia principal entera, con L, R y M, para la ficha y la clase evolutiva (solo si el script la lee)
   try { out.msFull = (typeof csMsTable === "function") ? csMsTable(File.readTextFile(cpSfDataDir() + "main_sequence.csv")) : []; } catch (eM) { out.msFull = []; }
   // Un fallo de lectura NO se guarda: puede ser pasajero y dejaria el modulo sin catalogos toda la sesion.
   if (out.ok) CP_SF_CATALOGS = out;
   return out;
}
// (5-nov-2026) EL CATALOGO DE NEBULOSAS QUE NO SE PUDO BAJAR se vuelve a pedir sin cerrar el script: en el paso de las nebulosas de cada
// imagen, si ya paso el plazo del sello .fail (csh_thirdparty.js: 5 min si fue la red), y al momento con force (el «↻ Retry» de Cabra3D).
// CSH_SF_NEB_RELOAD = false: como antes (lo que se leyo al cargar los catalogos vale toda la ejecucion).
var CSH_SF_NEB_RELOAD = true;
function cpSfNebulaeReload(cats, force) {
   if (!cats || CSH_SF_NEB_RELOAD !== true || (cats.nebulae && cats.nebulae.length > 0) || typeof cshTpNebulaeText !== "function") return cats;
   try {
      var nt = cshTpNebulaeText(cpSfDataDir(), { force: force === true });
      cats.nebulaeFrom = nt.from;
      if (nt.text.length > 0) { cats.nebulae = cpSfNebulaCatalog(nt.text); cats.nebulaError = ""; } else cats.nebulaError = nt.why || "not available";
   } catch (e) { cats.nebulaError = String(e.message || e); }
   return cats;
}

function cpStarfieldMainSequence() {
   return cpSfCatalogs().mainSequence;
}

// (28-oct-2026, E3) LA MISMA secuencia con el color en el sistema de Gaia DR3 (bpRp; el de la tabla, en bpRpDr2), por la UNICA
// conversion (CabraShared/csh_mainseq.js, `cshMsSequenceDr3`). Es la que DIBUJA el HR de CabraStars y CabraStarAnalysis (la linea
// discontinua y las letras espectrales), igual que el analisis (`csMsTable`). `cpStarfieldMainSequence` sigue en DR2: Cabra3D
// (dust_run.js `c3DustIntrinsic`) la lee asi y convierte por su cuenta. Requiere csh_mainseq.js incluido.
var CP_SF_MS_DR3 = null;
function cpStarfieldMainSequenceDr3() {
   var ms = cpStarfieldMainSequence();
   if (CP_SF_MS_DR3 === null || CP_SF_MS_DR3.src !== ms || CP_SF_MS_DR3.on !== CSH_MS_DR3) CP_SF_MS_DR3 = { src: ms, on: CSH_MS_DR3, rows: cshMsSequenceDr3(ms) };
   return CP_SF_MS_DR3.rows;
}

// ---------------------------------------------------------------------------
// LA GEOMETRIA DEL CAMPO: centro, radio que cubre las cuatro esquinas, escala,
// epoca y la funcion que lleva de cielo a pixel. Devuelve { ok, code, ra, dec,
// radiusDeg, width, height, scaleArcsec, epochJD, epochKnown, years,
// referenceSystem, project( ra, dec ) -> { x, y } | null }.
// ---------------------------------------------------------------------------
function cpSfField(view) {
   var out = { ok: false, code: "", project: null, ra: 0, dec: 0, radiusDeg: 0, width: 0, height: 0, scaleArcsec: 0, epochJD: 0, epochKnown: false,
               years: 0, referenceSystem: "" };
   if (!optSafeView(view)) { out.code = "no-view"; return out; }
   var md = cpAnnotMetadata(view);
   if (md === null) { out.code = "no-solution"; return out; }
   var w = 0, h = 0;
   try { w = view.image.width; h = view.image.height; } catch (e1) {}
   var c = null, far = 0;
   try {
      c = md.Convert_I_RD(new Point(w / 2, h / 2));
      var corners = [[0, 0], [w, 0], [0, h], [w, h]];
      for (var i = 0; i < corners.length; ++i) {
         var p = md.Convert_I_RD(new Point(corners[i][0], corners[i][1]));
         if (p && isFinite(p.x) && isFinite(p.y)) far = Math.max(far, cpSfSeparation(c.x, c.y, p.x, p.y));
      }
   } catch (e2) { c = null; }
   if (!c || !isFinite(c.x) || !isFinite(c.y) || !(far > 0)) { out.code = "no-solution"; return out; }
   out.ra = c.x; out.dec = c.y; out.radiusDeg = far; out.width = w; out.height = h;
   // De cielo a pixel con la libreria (`Convert_RD_I`: ver la nota de annotations.js sobre por que no el nucleo).
   out.project = function(ra, dec) {
      try {
         var q = md.Convert_RD_I(new Point(ra, dec));
         return (q && isFinite(q.x) && isFinite(q.y)) ? { x: q.x, y: q.y } : null;
      } catch (eP) { return null; }
   };
   out.unproject = function(x, y) {
      try {
         var q = md.Convert_I_RD(new Point(x, y));
         return (q && isFinite(q.x) && isFinite(q.y)) ? { ra: q.x, dec: q.y } : null;
      } catch (eU) { return null; }
   };
   try { out.scaleArcsec = md.resolution * 3600; } catch (e3) {}
   try { out.referenceSystem = String(md.referenceSystem || "ICRS").toUpperCase(); } catch (e4) { out.referenceSystem = "ICRS"; }
   // La epoca. `cpAnnotMetadata` pone J2000 cuando la imagen no dice cuando se tomo: mover las estrellas
   // 16 años HACIA ATRAS con eso seria inventar. Sin fecha, las posiciones se quedan en J2016,0 y se dice.
   var jd = 0;
   try { jd = Number(md.observationTime); } catch (e5) {}
   out.epochKnown = (isFinite(jd) && jd > 0 && jd !== CP_ANNOT_DEFAULT_EPOCH);
   out.epochJD = out.epochKnown ? jd : CP_SF.GAIA_EPOCH_JD;
   out.years = (out.epochJD - CP_SF.GAIA_EPOCH_JD) / 365.25;
   out.ok = true;
   return out;
}

// UN CAMPO SIN IMAGEN: un encuadre de `width` x `height` pixeles centrado en
// (ra, dec), norte arriba y este a la izquierda, proyeccion gnomonica, a
// `scaleArcsec` segundos por pixel. Es lo que deja probar el motor entero sobre
// M 13 o las Pleyades sin tener una foto suya: `cpSfBuildField( campo, null )`.
// `years` (opcional) = años desde J2016,0.
function cpSfSyntheticField(ra, dec, width, height, scaleArcsec, years) {
   var k = Math.PI / 180, s = scaleArcsec / 3600 * k, a0 = ra * k, d0 = dec * k;
   var half = Math.sqrt(width * width + height * height) / 2 * scaleArcsec / 3600;
   return { ok: true, code: "", ra: ra, dec: dec, radiusDeg: half, width: width, height: height, scaleArcsec: scaleArcsec,
            epochJD: CP_SF.GAIA_EPOCH_JD + (years || 0) * 365.25, epochKnown: true, years: years || 0, referenceSystem: "ICRS",
            project: function(r, d) {
               var a = r * k, dd = d * k;
               var cosc = Math.sin(d0) * Math.sin(dd) + Math.cos(d0) * Math.cos(dd) * Math.cos(a - a0);
               if (!(cosc > 0.01)) return null;
               var xi = Math.cos(dd) * Math.sin(a - a0) / cosc, eta = (Math.cos(d0) * Math.sin(dd) - Math.sin(d0) * Math.cos(dd) * Math.cos(a - a0)) / cosc;
               return { x: width / 2 - xi / s, y: height / 2 - eta / s };
            },
            // (la inversa de la gnomonica: de pixel a cielo)
            unproject: function(x, y) {
               var xi = (width / 2 - x) * s, eta = (height / 2 - y) * s, rho = Math.sqrt(xi * xi + eta * eta), c = Math.atan(rho);
               if (!(rho > 0)) return { ra: ra, dec: dec };
               var dd = Math.asin(Math.cos(c) * Math.sin(d0) + eta * Math.sin(c) * Math.cos(d0) / rho);
               var a = a0 + Math.atan2(xi * Math.sin(c), rho * Math.cos(d0) * Math.cos(c) - eta * Math.sin(d0) * Math.sin(c));
               return { ra: ((a / k) % 360 + 360) % 360, dec: dd / k };
            } };
}









// ---------------------------------------------------------------------------
// LA FOTOMETRIA EN LA IMAGEN: leer los pixeles
// ----------------------------------------------------------------------------
// APERTURA FORZADA en la posicion que da Gaia (llevada a la epoca de la imagen),
// con fondo local en un anillo, en los tres canales con LA MISMA mascara. No se

// ---- desde engine/starfield_run.js:537 ----
var CP_SF_PHOT_APERTURE = 1.5;      // en FWHM. Diseño, MEDIDO (ver arriba)
var CP_SF_PHOT_SATURATION = 0.9;    // diseño: fraccion del maximo del canal a partir de la cual un pixel esta saturado
var CP_SF_PHOT_CONTAMINATION = 0.05;// diseño: flujo ajeno maximo en la apertura (0,05 mag, lo que ya dispersa el color medido)
var CP_SF_PHOT_RECENTRE_SNR = 50;   // diseño: por debajo, el centro es el previsto (mas el desplazamiento comun)
var CP_SF_PHOT_CAL_STARS = 4000;    // diseño: las mas brillantes que se miden para calibrar

function cpSfBoxMedian(arr, n) {
   var a = arr.subarray(0, n);
   a.sort();
   return (n % 2) ? a[n >> 1] : (a[(n >> 1) - 1] + a[n >> 1]) / 2;
}

// La FWHM en pixeles y el desplazamiento comun de la imagen respecto a Gaia, de
// estrellas brillantes sin saturar (canal verde). FWHM: area por encima de la
// mitad del maximo, sobre fondo local; mediana de hasta 60. Desplazamiento:
// mediana de (centroide - posicion prevista). Con menos de 5, fwhm 0 (no se ha
// podido medir). Devuelve { fwhm, dx, dy, n }.
function cpSfMeasureSeeing(img, stars, order, satLevel) {
   var W = img.width, H = img.height, R = 15, side = 2 * R + 1;
   var buf = new Float32Array(side * side), ring = new Float32Array(side * side), vals = [], sx = [], sy = [];
   for (var q = 0; q < order.length && vals.length < 60; ++q) {
      var s = stars[order[q]];
      // La libreria da el CENTRO del pixel (i, j) en (i + 0,5; j + 0,5); aqui se trabaja con indices de pixel.
      // MEDIDO: sin restar ese medio pixel, el desplazamiento comun salia (-0,58; -0,50), (-0,43; -0,37),
      // (-0,54; -0,48) y (-0,51; -0,54) px en cuatro imagenes distintas.
      var x = Math.round(s.x - 0.5), y = Math.round(s.y - 0.5);
      if (x < R + 1 || y < R + 1 || x >= W - R - 1 || y >= H - R - 1) continue;
      img.getSamples(buf, new Rect(x - R, y - R, x + R + 1, y + R + 1), 1);
      var nr = 0, peak = -1e30, i, dx, dy;
      for (dy = -R; dy <= R; ++dy)
         for (dx = -R; dx <= R; ++dx) {
            var v = buf[(dy + R) * side + (dx + R)], r2 = dx * dx + dy * dy;
            if (r2 >= 100 && r2 <= 225) ring[nr++] = v;
            if (r2 <= 16 && v > peak) peak = v;
         }
      if (nr < 50) continue;
      var bg = cpSfBoxMedian(ring, nr);
      for (i = 0; i < nr; ++i) ring[i] = Math.abs(ring[i] - bg);
      var dev = 1.4826 * cpSfBoxMedian(ring, nr);
      if (peak >= satLevel[1] || !(peak - bg > 30 * dev)) continue;
      var half = bg + (peak - bg) / 2, area = 0, sw = 0, cx = 0, cy = 0;
      for (dy = -8; dy <= 8; ++dy)
         for (dx = -8; dx <= 8; ++dx) {
            var u = buf[(dy + R) * side + (dx + R)];
            if (u > half) { ++area; sw += u - half; cx += (u - half) * dx; cy += (u - half) * dy; }
         }
      if (area < 3 || area >= 200 || !(sw > 0)) continue;
      vals.push(2 * Math.sqrt(area / Math.PI));
      sx.push(x + cx / sw - (s.x - 0.5)); sy.push(y + cy / sw - (s.y - 0.5));
   }
   if (vals.length < 5) return { fwhm: 0, dx: 0, dy: 0, n: vals.length };
   return { fwhm: cpSfMedian(vals), dx: cpSfMedian(sx), dy: cpSfMedian(sy), n: vals.length };
}

function cpSfMeasureStars(view, stars, opts) {
   var o = opts || {};
   var out = { ok: false, code: "", fwhm: 0, aperture: 0, annulus: [0, 0], offset: [0, 0], measured: 0, samples: [] };
   var img = view.image, W = img.width, H = img.height;
   if (img.numberOfChannels < 3 || !img.isColor) { out.code = "mono"; return out; }
   var c, i;
   var satLevel = [1, 1, 1];
   for (c = 0; c < 3; ++c) {
      img.selectedChannel = c;
      satLevel[c] = CP_SF_PHOT_SATURATION * img.maximum();
   }
   img.resetSelections();
   // Las de dentro del encuadre, de brillante a debil.
   var order = [];
   for (i = 0; i < stars.length; ++i) if (stars[i].inFrame && stars[i].g !== null) order.push(i);
   order.sort(function(p, q) { return stars[p].g - stars[q].g; });
   if (typeof cshYield === "function") cshYield();
   var seeing = cpSfMeasureSeeing(img, stars, order, satLevel);
   if (typeof cshYield === "function") cshYield();
   var fwhm = seeing.fwhm;
   if (!(fwhm > 0)) { out.code = "few-stars"; return out; }
   var k = (o.aperture > 0) ? o.aperture : CP_SF_PHOT_APERTURE;
   var rAp = Math.max(2.5, Math.min(15, k * fwhm));
   var rIn = Math.max(rAp + 2, 2.5 * fwhm), rOut = Math.min(28, rIn + Math.max(3, fwhm));
   if (rIn >= rOut - 2) rIn = rOut - 3;
   out.fwhm = fwhm; out.aperture = rAp; out.annulus = [rIn, rOut]; out.offset = [seeing.dx, seeing.dy];
   var R = Math.ceil(rOut) + 1, side = 2 * R + 1;
   var buf = [new Float32Array(side * side), new Float32Array(side * side), new Float32Array(side * side)];
   var ring = new Float32Array(side * side);

   // Las vecinas: rejilla de todas las del encuadre. `sigma` de la gaussiana = FWHM / 2,355.
   var sigmaPsf = fwhm / 2.3548, reach = rAp + 4 * sigmaPsf, cell = Math.max(4, reach), grid = {}, key;
   if (typeof cshYield === "function") cshYield();
   for (i = 0; i < order.length; ++i) {
      if ((i & 4095) === 4095) if (typeof cshYield === "function") cshYield();
      var sg = stars[order[i]];
      key = Math.floor(sg.x / cell) + "," + Math.floor(sg.y / cell);
      (grid[key] || (grid[key] = [])).push(order[i]);
   }
   function contamination(idx) {
      var s0 = stars[idx], gx = Math.floor(s0.x / cell), gy = Math.floor(s0.y / cell), sum = 0;
      for (var ax = -1; ax <= 1; ++ax)
         for (var ay = -1; ay <= 1; ++ay) {
            var list = grid[(gx + ax) + "," + (gy + ay)];
            if (!list) continue;
            for (var n = 0; n < list.length; ++n) {
               if (list[n] === idx) continue;
               var s1 = stars[list[n]], ddx = s1.x - s0.x, ddy = s1.y - s0.y, d = Math.sqrt(ddx * ddx + ddy * ddy);
               if (d > reach) continue;
               var t = (d - rAp) / sigmaPsf;
               sum += Math.pow(10, -0.4 * (s1.g - s0.g)) * ((t <= 0) ? 1 : 0.5 * Math.exp(-t * t / 2));
            }
         }
      return sum;
   }

   // Que estrellas se miden: las que calibran (las mas brillantes) y las que tienen distancia.
   var maxStars = (o.photStars > 0) ? o.photStars : 20000, calStars = (o.calStars > 0) ? o.calStars : CP_SF_PHOT_CAL_STARS;
   var todo = [];
   if (typeof cshYield === "function") cshYield();
   for (i = 0; i < order.length && todo.length < maxStars; ++i)
      if (i < calStars || stars[order[i]].dist) todo.push(order[i]);

   var maxShift = Math.max(1.5, 0.75 * fwhm);
   var rAp2 = (rAp + 0.5) * (rAp + 0.5), rIn2 = rIn * rIn, rOut2 = rOut * rOut, yieldOk = (typeof cshYield === "function");
   for (var q = 0; q < todo.length; ++q) {
      if (yieldOk && (q & 15) === 15) cshYield();
      var idx = todo[q], s = stars[idx];
      var tx = s.x - 0.5 + seeing.dx, ty = s.y - 0.5 + seeing.dy;      // indices de pixel (ver cpSfMeasureSeeing)
      var x0 = Math.round(tx), y0 = Math.round(ty);
      if (x0 < R + 1 || y0 < R + 1 || x0 >= W - R - 1 || y0 >= H - R - 1) continue;
      var rect = new Rect(x0 - R, y0 - R, x0 + R + 1, y0 + R + 1);
      for (c = 0; c < 3; ++c) img.getSamples(buf[c], rect, c);
      var bg = [0, 0, 0], sig = [0, 0, 0], dx, dy, r2, v, nr;
      for (c = 0; c < 3; ++c) {
         nr = 0;
         for (dy = -R; dy <= R; ++dy)
            for (dx = -R; dx <= R; ++dx) {
               r2 = dx * dx + dy * dy;
               if (r2 >= rIn2 && r2 <= rOut2) ring[nr++] = buf[c][(dy + R) * side + (dx + R)];
            }
         bg[c] = cpSfBoxMedian(ring, nr);
         for (i = 0; i < nr; ++i) ring[i] = Math.abs(ring[i] - bg[c]);
         sig[c] = 1.4826 * cpSfBoxMedian(ring, nr);
      }
      // el centro: el previsto (con el desplazamiento comun) y, solo con señal de sobra, el centroide propio
      var px = tx - x0, py = ty - y0, sw = 0, sx = 0, sy = 0, nIn = 0, fIn = 0;
      for (dy = -R; dy <= R; ++dy)
         for (dx = -R; dx <= R; ++dx) {
            var ex = dx - px, ey = dy - py;
            if (ex * ex + ey * ey > rAp * rAp) continue;
            v = buf[1][(dy + R) * side + (dx + R)] - bg[1];
            ++nIn; fIn += v;
            if (v > 0) { sw += v; sx += v * dx; sy += v * dy; }
         }
      var cx = px, cy = py;
      if (sw > 0 && sig[1] > 0 && fIn / (sig[1] * Math.sqrt(Math.max(1, nIn))) >= CP_SF_PHOT_RECENTRE_SNR) {
         var mx = sx / sw, my = sy / sw;
         if (Math.sqrt((mx - px) * (mx - px) + (my - py) * (my - py)) <= maxShift) { cx = mx; cy = my; }
      }
      // el flujo, con el borde de la apertura suavizado a un pixel
      var flux = [0, 0, 0], nAp = 0, sat = false;
      for (dy = -R; dy <= R; ++dy)
         for (dx = -R; dx <= R; ++dx) {
            var fx = dx - cx, fy = dy - cy, d2 = fx * fx + fy * fy;
            if (d2 > rAp2) continue;
            var wgt = Math.min(1, Math.max(0, rAp + 0.5 - Math.sqrt(d2)));
            if (wgt <= 0) continue;
            nAp += wgt;
            var at = (dy + R) * side + (dx + R);
            for (c = 0; c < 3; ++c) {
               v = buf[c][at];
               if (v >= satLevel[c]) sat = true;
               flux[c] += wgt * (v - bg[c]);
            }
         }
      var snr = Infinity;
      for (c = 0; c < 3; ++c) {
         var sn = (sig[c] > 0 && nAp > 0) ? flux[c] / (sig[c] * Math.sqrt(nAp)) : 0;
         if (sn < snr) snr = sn;
      }
      out.samples.push({ star: idx, r: flux[0], g: flux[1], b: flux[2], snr: snr, saturated: sat,
                         blended: (contamination(idx) > CP_SF_PHOT_CONTAMINATION), G: s.g, bpRp: s.bpRp, colorSuspect: s.colorSuspect });
   }
   out.measured = out.samples.length;
   out.ok = (out.measured > 0);
   if (!out.ok) out.code = "few-stars";
   return out;
}

// La fotometria entera sobre `result` (lee, calibra y deja `star.phot`). Devuelve
// lo que va a `result.photometry`. `opts.aperture` (en FWHM) es para el barrido de la sonda.
function cpSfPhotometry(view, result, opts) {
   var o = opts || {};
   var out = { ok: false, code: "", why: "", alternative: "gaia", method: null, calibration: null, flagged: { faint: 0, outOfRange: 0, magMismatch: 0, colourMismatch: 0 }, note: "", noteText: "" };
   var stars = result.stars, i;
   for (i = 0; i < stars.length; ++i) stars[i].phot = null;
   function no(code) { out.code = code; out.why = cpStarfieldReasonText(code); return out; }
   if (o.photometry === false) return no("not-requested");
   var img = null;
   try { img = view.image; } catch (e0) {}
   if (!img) return no("no-view");
   if (img.numberOfChannels < 3 || !img.isColor) return no("mono");
   if (!cpViewIsLinear(view)) return no("nonlinear");
   if (result.field.referenceSystem !== "ICRS") return no("reference-system");
   var m = null;
   // Si la lectura LANZA no es «pocas estrellas»: se dice aparte y el error se queda en el resultado.
   try { m = cpSfMeasureStars(view, stars, o); }
   catch (e1) {
      out.error = String(e1.message || e1);
      return no("measure-failed");
   }
   if (!m.ok) return no(m.code || "few-stars");
   out.method = { kind: "forced aperture at the Gaia position, local sky annulus, same mask in R, G and B", fwhmPx: m.fwhm, aperturePx: m.aperture,
                  annulusPx: m.annulus, offsetPx: m.offset, measured: m.measured };
   var cal = cpSfPhotCalibrate(m.samples);
   out.calibration = { n: cal.n, slope: cal.slope, color: cal.color, mag: cal.mag, holdout: cal.holdout, byMag: cal.byMag, byColor: cal.byColor, rejected: cal.rejected };
   if (!cal.ok) return no(cal.code);
   // Donde se ha VISTO que el color de la foto deja de seguir al de las estrellas (las enanas M), se avisa.
   out.flagged = cal.flagged;
   if (cal.color.range.minWhy === "bias" || cal.color.range.maxWhy === "bias") { out.note = "colour-range"; out.noteText = cpStarfieldReasonText("colour-range"); }
   for (i = 0; i < m.samples.length; ++i) {
      var sm = m.samples[i], st = cal.stars[i];
      stars[sm.star].phot = { ok: (st !== null), r: sm.r, g: sm.g, b: sm.b, snr: sm.snr, saturated: sm.saturated, blended: sm.blended,
                              color: st ? st.color : null, mag: st ? st.mag : null, inRange: st ? st.inRange : false,
                              use: st ? st.use : false, why: st ? st.why : (sm.saturated ? "saturated" : "blended") };
   }
   out.ok = true;
   out.alternative = "";
   return out;
}

// ---------------------------------------------------------------------------
// cpStarfieldBuild: lo local, de una vez
// ---------------------------------------------------------------------------
function cpStarfieldBuild(view, opts) {
   var field = cpSfField(view);
   if (!field.ok) {
      var bad = cpSfEmptyResult();
      bad.code = field.code;
      bad.why = cpStarfieldReasonText(field.code);
      return bad;
   }
   return cpSfBuildField(field, view, opts);
}

function cpSfEmptyResult() {
   return { ok: false, code: "", why: "", version: CP_SF.RESULT_FORMAT, field: null,
            gaia: { ok: false, code: "", release: "", count: 0, inFrame: 0, magLimit: 0, truncated: false, ms: 0 },
            stars: [], clusters: [], unconfirmed: [],
            distances: { cluster: 0, bailerJones: 0, parallaxOnline: 0, parallaxLocal: 0, none: 0, suspect: 0 },
            photometry: { ok: false, code: "not-requested", why: "", alternative: "gaia", method: null, calibration: null,
                          flagged: { faint: 0, outOfRange: 0, magMismatch: 0, colourMismatch: 0 }, note: "", noteText: "" },
            hr: null, refine: null, deepSky: null, nebulae: null, timings: { gaiaMs: 0, starsMs: 0, clustersMs: 0, photometryMs: 0, totalMs: 0 } };
}

// Lo mismo a partir de un CAMPO (de `cpSfField` o de `cpSfSyntheticField`). `view`
// puede ser null: entonces no hay foto que medir y el HR sale con los colores de Gaia.
function cpSfBuildField(field, view, opts) {
   var o = opts || {};
   var tAll = Date.now();
   var res = cpSfEmptyResult();
   function progress(stage, info) { if (typeof o.onProgress === "function") { try { o.onProgress(stage, info || {}); } catch (eP) {} } }
   function fail(code) { res.code = code; res.why = cpStarfieldReasonText(code); res.timings.totalMs = Date.now() - tAll; return res; }

   res.field = { ra: field.ra, dec: field.dec, radiusDeg: field.radiusDeg, width: field.width, height: field.height, scaleArcsec: field.scaleArcsec,
                 epochJD: field.epochJD, epochKnown: field.epochKnown, years: field.years, referenceSystem: field.referenceSystem };
   // La funcion de cielo a pixel se queda con el resultado: la necesita cpStarfieldDeepSky. No es un dato.
   res._project = field.project;
   res._unproject = (typeof field.unproject === "function") ? field.unproject : null;      // (pixel -> cielo: la huella de una nebulosa)

   // --- Gaia ----------------------------------------------------------------
   var magLimit = (o.magLimit > 0) ? o.magLimit : 21, maxStars = (o.maxStars > 0) ? o.maxStars : 300000;
   var hooked = (typeof CP_SF_GAIA_HOOK === "function");
   var src = hooked ? { ok: true, code: "", release: null, name: "hook" } : cpSfGaiaSource(), q = null;
   // GAIA LOCAL PRIMERO (encargo de Nino, 15-oct): si la base DR3 de PixInsight esta, de ella salen posicion, paralaje,
   // movimiento propio y G/BP/RP. Solo sin base local —y con la red permitida— se piden esos mismos campos a VizieR.
   if (!src.ok && o.netFallback === true) {
      progress("gaia-net", {});
      magLimit = Math.min(magLimit, CSH_GAIA_NET.MAG); maxStars = Math.min(maxStars, CSH_GAIA_NET.MAX);
      q = cshGaiaNetSearch(field, magLimit, maxStars, o);
      res.gaia.source = "vizier";
      if (!q.ok) {
         res.net = q.net; res.gaia.code = "no-gaia-net";
         res.code = "no-gaia-net"; res.why = cpStarfieldReasonText("no-gaia") + " " + (q.netAll || [q.net]).map(cshNetText).join(" ");
         res.timings.totalMs = Date.now() - tAll; return res;
      }
      src = { ok: true, code: "", release: null, name: (q.server || "VizieR") + " · Gaia DR3" };
      res.gaia.server = q.server || "";
   } else {
      if (!src.ok) { res.gaia.code = src.code; return fail(src.code); }
      progress("gaia", { release: src.name });
      q = hooked ? CP_SF_GAIA_HOOK(field, magLimit, maxStars) : cpSfGaiaSearch(src.release, field.ra, field.dec, field.radiusDeg, magLimit, maxStars);
      res.gaia.source = hooked ? "hook" : "local";
   }
   res.gaia.release = src.name; res.gaia.magLimit = magLimit; res.gaia.ms = q.ms; res.gaia.truncated = q.truncated;
   res.timings.gaiaMs = q.ms;
   if (!q.ok) { res.gaia.code = q.code; return fail(q.code); }
   // (cero estrellas con la consulta HECHA: de verdad no hay ninguna hasta esa magnitud; un fallo de red no llega aqui)
   if (q.rows.length === 0) { res.gaia.code = "no-stars"; fail("no-stars"); res.why = format(optT("the Gaia catalogue (%s) has no stars in this field down to G %s: the field really is empty to that depth."), res.gaia.source === "vizier" ? "VizieR" : optT("local database"), String(magLimit)); return res; }

   // --- las estrellas, en la epoca de la imagen y en pixeles ---------------------
   var t0 = Date.now(), stars = [], inFrame = 0, yieldOk = (typeof cshYield === "function");      // (cshYield: Cabra3D, 22-oct; csh_net.js)
   for (var i = 0; i < q.rows.length; ++i) {
      if (yieldOk && (i & 511) === 511) cshYield();
      var s = cpSfStarFromRow(q.rows[i], field.years);
      var p = field.project(s.ra, s.dec);
      if (p !== null) {
         s.x = p.x; s.y = p.y;
         s.inFrame = (p.x >= 0 && p.y >= 0 && p.x <= field.width && p.y <= field.height);
         if (s.inFrame) ++inFrame;
      }
      stars.push(s);
   }
   res.stars = stars;
   res.gaia.ok = true; res.gaia.count = stars.length; res.gaia.inFrame = inFrame;
   res.timings.starsMs = Date.now() - t0;

   // --- los cumulos ----------------------------------------------------------
   t0 = Date.now();
   progress("clusters", {});
   cpSfBuildClusters(res, o);
   res.distances = cpSfAssignDistances(stars, res.clusters);
   res.timings.clustersMs = Date.now() - t0;

   // --- la fotometria en la imagen --------------------------------------------
   t0 = Date.now();
   progress("photometry", {});
   res.photometry = cpSfPhotometry(view, res, o);
   res.timings.photometryMs = Date.now() - t0;
   // --- (Block G, 20-oct-2026) LA PROFUNDIDAD DE LA FOTO y, con ella, solo las estrellas que la foto alcanza -------
   // (csh_depth_run.js; solo si quien llama lo pide —Cabra3D enciende CSH_DEPTH_ON—: para los demas, como siempre)
   if (view && typeof cshDepthWanted === "function" && cshDepthWanted(o)) {
      t0 = Date.now();
      progress("depth", {});
      try { cshDepthApply(view, res, o); } catch (eD) { res.depth = { ok: false, code: "measure-failed", error: String(eD.message || eD) }; }
      res.timings.depthMs = Date.now() - t0;
   }
   res.hr = cpStarfieldHr(res, "image");

   res.ok = true;
   if (o.online === true) {
      cpStarfieldRefine(res, o);
      if (o.deepSky !== false) cpStarfieldDeepSky(res, o);          // (Cabra3D lo pide; CabraStars pasa deepSky: false)
   }
   res.timings.totalMs = Date.now() - tAll;
   return res;
}

// Los cumulos de `res.stars`: los del catalogo que se confirman y, si se pide, los
// grupos de movimiento propio que no estan en el. Deja `res.clusters` y `res.unconfirmed`.
function cpSfBuildClusters(res, opts) {
   var o = opts || {}, stars = res.stars, f = res.field;
   var cats = cpSfCatalogs();
   res.clusters = []; res.unconfirmed = [];
   function place(obj) {
      obj.x = null; obj.y = null; obj.inFrame = false;
      var p = (typeof res._project === "function") ? res._project(obj.ra, obj.dec) : null;
      if (p !== null) { obj.x = p.x; obj.y = p.y; obj.inFrame = (p.x >= 0 && p.y >= 0 && p.x <= f.width && p.y <= f.height); }
   }
   var found = [], near = [], i;
   if (cats.ok) {
      near = cpSfClustersNear(cats.clusters, f.ra, f.dec, f.radiusDeg);
      for (i = 0; i < near.length; ++i) {
         if (typeof cshYield === "function") cshYield();
         var cl = near[i], m = cpSfClusterMembers(stars, cl, o);
         if (m.confirmed && cl.dist !== null) {
            var c = { id: cl.id, name: cl.name, kind: cl.kind, origin: "catalog", catalog: cl.catalog, aliases: cl.aliases, ra: cl.ra, dec: cl.dec,
                      coreRadiusDeg: cl.coreRadius, selRadiusDeg: cl.selRadius, pm: m.pm, dist: cl.dist, n: m.n, members: m.members, purity: m.purity,
                      significance: m.significance, parallax: m.parallax, tiers: m.tiers, confirmed: true, extra: cl.extra };
            place(c);
            found.push(c);
         } else {
            var u = { id: cl.id, name: cl.name, kind: cl.kind, code: m.confirmed ? "no-distance" : m.code, ra: cl.ra, dec: cl.dec };
            place(u);
            res.unconfirmed.push({ id: u.id, name: u.name, kind: u.kind, code: u.code, inFrame: u.inFrame });
         }
      }
   } else
      res.catalogsError = cats.error;
   if (o.blind !== false) {
      var groups = cpSfFindPmGroups(stars, {});
      for (i = 0; i < groups.length; ++i) {
         var g = groups[i], known = false;
         for (var k = 0; k < found.length; ++k) {
            var dr = found[k].pm.catalogRa - g.pmRa, dd = found[k].pm.catalogDec - g.pmDec;
            if (Math.sqrt(dr * dr + dd * dd) <= Math.max(1, 2 * g.scale)) { known = true; found[k].blind = { pmRa: g.pmRa, pmDec: g.pmDec, n: g.n, scale: g.scale }; break; }
         }
         if (known) continue;
         var par = cpSfMeanParallax(stars, g.stars);
         // ¿Es un cumulo del catalogo que la via del catalogo no llego a confirmar? Mismo movimiento propio y
         // el grumo cae dentro de su radio: lleva su nombre y SU distancia, no una paralaje media.
         var twin = null;
         for (var t = 0; t < near.length && twin === null; ++t) {
            var nc = near[t];
            if (nc.dist === null || nc.pmRa === null || nc.pmDec === null) continue;
            var er = nc.pmRa - g.pmRa, ed = nc.pmDec - g.pmDec;
            if (Math.sqrt(er * er + ed * ed) <= Math.max(1, 2 * g.scale) &&
                cpSfSeparation(nc.ra, nc.dec, g.ra, g.dec) <= Math.max(0.25, nc.selRadius || 0))
               twin = nc;
         }
         if (twin !== null) {
            var tw = { id: twin.id, name: twin.name, kind: twin.kind, origin: "blind", catalog: twin.catalog, aliases: twin.aliases, ra: twin.ra, dec: twin.dec,
                       coreRadiusDeg: twin.coreRadius, selRadiusDeg: twin.selRadius, pm: { ra: g.pmRa, dec: g.pmDec, catalogRa: twin.pmRa, catalogDec: twin.pmDec },
                       dist: twin.dist, n: g.stars.length, members: g.stars, purity: null, significance: g.significance, parallax: par, confirmed: true,
                       extra: twin.extra, blind: { pmRa: g.pmRa, pmDec: g.pmDec, n: g.n, scale: g.scale, concentration: g.concentration, isolated: g.isolated } };
            place(tw);
            found.push(tw);
            for (var u2 = res.unconfirmed.length - 1; u2 >= 0; --u2) if (res.unconfirmed[u2].id === twin.id) res.unconfirmed.splice(u2, 1);
            continue;
         }
         // No esta en el catalogo: distancia por paralaje MEDIA con el punto cero, y su suelo sistematico.
         if (par.mean === null || !(par.pcZeroPoint > 0)) continue;
         var pz = par.mean - CP_SF.PLX_ZERO_POINT, e = par.error;   // (27-oct) par.error ya lleva el suelo sistematico (cpSfMeanParallax): no se suma otra vez
         if (!(pz - e > 0)) continue;
         var cand = { id: "", name: "", kind: "candidate", origin: "blind", catalog: null, aliases: [], ra: g.ra, dec: g.dec, coreRadiusDeg: g.radius,
                      selRadiusDeg: null, pm: { ra: g.pmRa, dec: g.pmDec, catalogRa: null, catalogDec: null },
                      dist: { pc: 1000 / pz, lo: 1000 / (pz + e), hi: 1000 / (pz - e), source: "cluster-parallax",
                              interval: "error of the mean + 0.01 mas systematic", ref: "mean Gaia parallax of the members, zero point -0.017 mas" },
                      n: g.stars.length, members: g.stars, purity: null, significance: g.significance, parallax: par, confirmed: true,
                      blind: { pmRa: g.pmRa, pmDec: g.pmDec, n: g.n, scale: g.scale, concentration: g.concentration, isolated: g.isolated } };
         place(cand);
         found.push(cand);
      }
   }
   found.sort(function(a, b) { return b.n - a.n; });
   res.clusters = found;
}

// ---------------------------------------------------------------------------
// cpStarfieldHr: los puntos del diagrama, de la foto o de Gaia
// ---------------------------------------------------------------------------
function cpStarfieldHr(result, source) {
   var wantImage = (source !== "gaia");
   var useImage = (wantImage && result.photometry && result.photometry.ok === true);
   var hr = cpSfHrPoints(result.stars, useImage ? ((source === "mixed") ? "mixed" : "image") : "gaia");
   hr.requested = wantImage ? ((source === "mixed") ? "mixed" : "image") : "gaia";
   hr.fallback = (wantImage && !useImage);
   hr.why = hr.fallback ? result.photometry.why : "";
   hr.code = hr.fallback ? result.photometry.code : "";
   return hr;
}

// ---------------------------------------------------------------------------
// cpStarfieldRefine: VizieR (Gaia DR3 + Bailer-Jones 2021)
// ---------------------------------------------------------------------------
function cpStarfieldRefine(result, opts) {
   var o = opts || {};
   var out = { ok: false, code: "", why: "", rows: 0, matched: 0, unmatched: 0, plxMismatch: 0, ms: 0, source: "TAPVizieR: I/355/gaiadr3 + I/352/gedr3dis" };
   function no(code) { out.code = code; out.why = cpStarfieldReasonText(code); return out; }
   if (!result || !result.ok || !result.field) return no("no-view");
   result.refine = out;
   var f = result.field;
   // (F2, 22-oct-2026) `opts.chain === "full"`: la cadena completa con respaldos (cshRefineChain, abajo). Sin la opcion, lo de
   // siempre (VizieR y, si no contesta, ESA sin union): Cabra3D lo envuelve y sus pruebas leen los servidores que fallan.
   if (o.chain === "full") return cshRefineChain(result, o, out);
   var url = cpSfTapUrl(CP_SF_VIZIER_TAP, cpSfRefineAdql(f.ra, f.dec, f.radiusDeg));
   var r = cpSfHttpText(url, { timeoutS: o.httpTimeoutS, onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress("refine", { elapsedMs: ms }); } });
   out.server = cshNetServer(url);
   // (si VizieR no contesta, lo MISMO al archivo de ESA, con las columnas renombradas como las de VizieR: 15-oct, VizieR
   // dio HTTP 503 mas de una hora. Ahi no hay XPsamp: queda sin dato y el espectro se intenta igual)
   if (!r.ok && typeof CSH_ESA_TAP === "string") {
      out.tried = [r.net];
      var urlE = cpSfTapUrl(CSH_ESA_TAP, cshRefineAdqlEsa(f.ra, f.dec, f.radiusDeg));
      var rE = cpSfHttpText(urlE, { timeoutS: o.httpTimeoutS, onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress("refine", { elapsedMs: ms }); } });
      if (rE.ok) { r = rE; url = urlE; out.server = cshNetServer(urlE); out.source = "ESA Gaia archive: gaiadr3.gaia_source (sin Bailer-Jones ni A0)"; out.fallback = true; }
   }
   out.ms = r.ms;
   if (!r.ok) { no("no-network"); out.net = (out.tried && out.tried.length) ? out.tried[0] : r.net; out.why = cshNetText(out.net) + (out.tried && r.net ? " " + cshNetText(r.net) : ""); return out; }
   if (!cpSfLooksLikeCsv(r.text, "RA_ICRS")) { no("bad-answer"); out.net = cshNetFail(url, { code: r.code }, false); out.net.kind = "bad"; out.why = cshNetText(out.net); return out; }
   var rows = cpSfRefineRows(r.text);
   out.rows = rows.length;
   if (rows.length === 0) return no("no-rows");
   var m = cpSfRefineApply(result.stars, rows);
   out.matched = m.matched; out.unmatched = m.unmatched; out.plxMismatch = m.plxMismatch;
   result.distances = cpSfAssignDistances(result.stars, result.clusters);
   result.hr = cpStarfieldHr(result, "image");
   out.ok = true;
   return out;
}

// ---------------------------------------------------------------------------
// (F2, 22-oct-2026) EL AFINADO CON LA CADENA COMPLETA: cpStarfieldRefine(result, { chain: "full", ... })
// ---------------------------------------------------------------------------
// Orden: TAPVizieR (CDS) -> GAVO (Heidelberg; Gaia EDR3 = misma astrometria) -> archivo de ESA con Bailer-Jones
// (external.gaiaedr3_distance) -> espejo de VizieR en CfA por ASU -> archivo de ESA sin union (lo de siempre: sin
// Bailer-Jones ni A0). Un servidor que no contesta, da HTTP de error o contesta con HTTP 200 algo que NO es la tabla (un
// VOTable de error, una pagina HTML, un cuerpo vacio) cede al siguiente. Una tabla buena SIN filas no cede: es la respuesta
// («no-rows», como siempre). Cada peticion va por `cpSfHttpText` (la global: las envolturas de quien llama la ven) con
// redirecciones y un reintento ante un fallo pasajero (`o.retry`, 1 por defecto; csh_net.js). Sin cortacircuitos.
// La salida tiene la MISMA forma que la de siempre (`ok, code, why, rows, matched, unmatched, plxMismatch, ms, source, server,
// fallback, tried, net`) y ademas: `chain: "full"`, `missing` (columnas que ese servidor no trae), `attempts` (cada intento:
// { server, kind, http, ms }) y, del espejo ASU, `bjRows` (filas con Bailer-Jones).
// COSTURA: CSH_REFINE_SERVERS(f) -> la lista (pruebas: servidores de mentira); o `o.servers`.
function cshRefineServerList(f) {
   if (typeof CSH_REFINE_SERVERS === "function") { try { var L = CSH_REFINE_SERVERS(f); if (L && L.length) return L; } catch (eS) {} }
   var noGsp = ["RV", "e_RV", "Teff", "logg", "[Fe/H]", "AG", "E(BP-RP)", "XPsamp", "A0", "NSS"];
   return [
      { id: "vizier", name: "VizieR (CDS)", url: cpSfTapUrl(CP_SF_VIZIER_TAP, cpSfRefineAdql(f.ra, f.dec, f.radiusDeg)), parse: "csv", bj: true, missing: [],
        source: "TAPVizieR: I/355/gaiadr3 + I/352/gedr3dis" },
      { id: "gavo", name: "GAVO (Heidelberg, Gaia EDR3)", url: cpSfTapUrl(CSH_GAVO_TAP, cshRefineAdqlGavo(f.ra, f.dec, f.radiusDeg)), parse: "csv", bj: true, missing: noGsp,
        source: "GAVO DC (Heidelberg): gaia.edr3lite + gedr3dist.main — Gaia EDR3 (same astrometry as DR3), Bailer-Jones 2021; no DR3 RV, GSP-Phot, XP or NSS" },
      { id: "esa-bj", name: "ESA Gaia archive", url: cpSfTapUrl(CSH_ESA_TAP, cshRefineAdqlEsa(f.ra, f.dec, f.radiusDeg, true)), parse: "csv", bj: true, missing: ["XPsamp", "A0"],
        source: "ESA Gaia archive: gaiadr3.gaia_source + external.gaiaedr3_distance (Bailer-Jones 2021; sin XP ni A0)" },
      { id: "idia-asu", name: "VizieR (IDIA mirror)", url: cshRefineAsuUrl(f.ra, f.dec, f.radiusDeg, 0, CSH_IDIA_ASU), parse: "asu", bj: true, missing: [],
        source: "VizieR IDIA mirror (ASU): I/355/gaiadr3 + I/352/gedr3dis" },
      { id: "cfa-asu", name: "VizieR (CfA mirror)", url: cshRefineAsuUrl(f.ra, f.dec, f.radiusDeg), parse: "asu", bj: true, missing: [],
        source: "VizieR CfA mirror (ASU): I/355/gaiadr3 + I/352/gedr3dis" },
      { id: "esa", name: "ESA Gaia archive", url: cpSfTapUrl(CSH_ESA_TAP, cshRefineAdqlEsa(f.ra, f.dec, f.radiusDeg)), parse: "csv", bj: false, missing: ["rgeo", "b_rgeo", "B_rgeo", "XPsamp", "A0"],
        source: "ESA Gaia archive: gaiadr3.gaia_source (sin Bailer-Jones ni A0)" }];
}
var CSH_REFINE_SERVERS = null;
// ¿Es la tabla? (con csh_netfail.js incluido, su juicio —HTML, VOTable de error, vacio—; si no, la cabecera CSV)
function cshRefineJudge(r, parse) {
   var text = String(r.text || "");
   var check = (parse === "asu") ? function(t) { var a = cshRefineAsuToCsv(t); return a.ok; } : function(t) { return cpSfLooksLikeCsv(t, "RA_ICRS"); };
   if (typeof cshNfJudge === "function") return cshNfJudge({ code: (r.code > 0) ? r.code : 200, text: text, cut: false, aborted: false }, check);
   var good = false; try { good = check(text); } catch (e) {}
   return { ok: good, kind: good ? "" : "bad", why: good ? "" : "not the expected table", http: r.code || 0 };
}
function cshRefineChain(result, o, out) {
   var f = result.field, list = o.servers || cshRefineServerList(f), t0 = Date.now(), fails = [], nBad = 0, nNet = 0, got = null, gotSv = null;
   out.chain = "full"; out.attempts = []; out.source = ""; out.server = "";
   var retry = (o.retry !== undefined) ? o.retry : 1;
   for (var i = 0; i < list.length && !got; ++i) {
      var sv = list[i];
      if (typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) break;
      var r = cpSfHttpText(sv.url, { timeoutS: o.httpTimeoutS, follow: true, retry: retry, next: (i + 1 < list.length) ? list[i + 1].name : "",   // (27-oct: la linea de la consola dice a quien se pasa)
                                    onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress("refine", { elapsedMs: ms, server: sv.name }); } });
      var att = { server: sv.name, id: sv.id, kind: "", http: (r.code > 0) ? r.code : 0, ms: r.ms };
      out.attempts.push(att);
      if (!r.ok) {
         var n = r.net || cshNetFail(sv.url, r, r.cut === true); n.server = sv.name;
         att.kind = n.kind; fails.push(n); if (n.kind === "bad") ++nBad; else ++nNet;
         if (r.aborted) break;
         continue;
      }
      var j = cshRefineJudge(r, sv.parse);
      if (!j.ok) {
         var nb = cshNetFail(sv.url, { code: r.code }, false); nb.kind = "bad"; nb.server = sv.name; nb.why = j.why;
         att.kind = "bad"; att.why = j.why; fails.push(nb); ++nBad;
         continue;
      }
      att.kind = "ok"; got = r; gotSv = sv;
   }
   out.ms = Date.now() - t0;
   out.tried = fails.slice();
   if (!got) {
      out.code = (nBad > 0 && nNet === 0) ? "bad-answer" : "no-network";
      out.net = fails.length ? fails[0] : cshNetFail(list.length ? list[0].url : "", { code: 0 }, false);
      var seen = {}, said = [];
      for (var k = 0; k < fails.length; ++k) { var tx = cshNetText(fails[k]); if (!seen[tx]) { seen[tx] = true; said.push(tx); } }
      out.why = said.length ? said.join(" ") : cpStarfieldReasonText(out.code);
      return out;
   }
   out.server = gotSv.name; out.source = gotSv.source; out.missing = (gotSv.missing || []).slice(); out.serverId = gotSv.id;
   // (29-oct-2026 (noche)) «vizier» es la TAP del CDS, pero desde P8 cpSfHttpText la lleva sola a los espejos de VizieR (IDIA, NAO) si el CDS
   // falla: entonces se dice QUIEN contesto —el intento del CDS con su fallo y el del espejo— en vez de «VizieR (CDS)» (c3_net 5)
   if (gotSv.id === "vizier" && got.fallback === true && got.server && got.attempts && got.attempts.length) {   // (con el CDS recordado caido solo se pregunta al espejo: 1 intento)
      var mirId = function(nm) { return /IDIA/i.test(nm) ? "idia-asu" : /NAO/i.test(nm) ? "nao-asu" : "vizier-mirror"; };
      var mid = mirId(got.server), inner = [];
      for (var ia = 0; ia < got.attempts.length; ++ia) {
         var ga = got.attempts[ia];
         inner.push({ server: ga.server, id: (ga.server === CSH_VIZIER_CDS_NAME) ? "vizier" : mirId(ga.server), kind: ga.kind, http: ga.http, ms: ga.ms });
      }
      out.attempts.splice(out.attempts.length - 1, 1);
      out.attempts = out.attempts.concat(inner);
      out.server = got.server; out.serverId = mid;
      out.source = got.server + " (ASU): I/355/gaiadr3 + I/352/gedr3dis — TAPVizieR did not give the table";
   }
   out.fallback = (gotSv.bj !== true);                    // (como antes: true = sin distancias de Bailer-Jones)
   var csv = got.text;
   if (gotSv.parse === "asu") { var a = cshRefineAsuToCsv(got.text); csv = a.csv; out.bjRows = a.withDist; out.distRows = a.distRows; }
   var rows = cpSfRefineRows(csv);
   out.rows = rows.length;
   if (rows.length === 0) { out.code = "no-rows"; out.why = cpStarfieldReasonText("no-rows"); return out; }
   var m = cpSfRefineApply(result.stars, rows);
   out.matched = m.matched; out.unmatched = m.unmatched; out.plxMismatch = m.plxMismatch;
   result.distances = cpSfAssignDistances(result.stars, result.clusters);
   result.hr = cpStarfieldHr(result, "image");
   out.ok = true;
   return out;
}

// ---- (de Cabra3D: lo lejano —SIMBAD— y las nebulosas; CabraStars no lo pide) ----
// ---------------------------------------------------------------------------
// cpStarfieldDeepSky: SIMBAD
// ---------------------------------------------------------------------------
var CSH_DEEPSKY_PARALLEL = true;        // (29-oct-2026 (noche)) false: SIMBAD, GLADE+ y Quaia en serie, como antes (ver cpStarfieldDeepSky)
function cpStarfieldDeepSky(result, opts) {
   var o = opts || {};
   var out = { ok: false, code: "", why: "", count: 0, inFrame: 0, withDistance: 0, ms: 0, objects: [], server: "", fallback: false, source: "SIMBAD TAP: basic + otypedef + mesDistance" };
   function no(code) { out.code = code; out.why = cpStarfieldReasonText(code); return out; }
   if (!result || !result.ok || !result.field) return no("no-view");
   result.deepSky = out;
   var f = result.field;
   // (Block G: con la profundidad medida, SIMBAD trae tambien las magnitudes —para saber si cada objeto se ve—)
   var depthOn = (result.depth && result.depth.ok === true && typeof cshDepthDeepSky === "function");
   var url = cpSfTapUrl(CP_SF_SIMBAD_TAP, cpSfSimbadAdql(f.ra, f.dec, f.radiusDeg, depthOn));
   var hopts = { timeoutS: o.httpTimeoutS, onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress("deepsky", { elapsedMs: ms }); } };
   // (29-oct-2026 (noche)) LAS TRES A LA VEZ: SIMBAD, GLADE+ y Quaia no dependen una de otra (solo del campo). Antes iban en serie: con el CDS caido,
   // 25 s en Abell 39 y 24 s en NGC 1560 (10 s de SIMBAD-CDS + Harvard, 10 s de VizieR-CDS + IDIA, IDIA; tests/csh_batch_speed_c3_antes.log).
   // Con el lote comun (../CabraShared/csh_batch.js: cshHttpMany, la misma cadena de cada una) lo de GLADE+ y Quaia queda en `pre` y
   // cshDepthDeepSky lo usa en vez de pedirlo. Sin el lote, con el gancho de pruebas (cuentan las visitas) o CSH_DEEPSKY_PARALLEL = false: como antes.
   var pre = null, r = null;
   if (CSH_DEEPSKY_PARALLEL !== false && typeof cshHttpMany === "function" && typeof CP_SF_HTTP_HOOK !== "function" && depthOn && o.extraSources !== false && typeof cshDepthExtraList === "function") {
      var items = [{ url: url, opts: hopts }], ex = cshDepthExtraList();
      for (var e = 0; e < ex.length; ++e) items.push({ url: cshDepthExtraUrl(ex[e], f), opts: hopts });
      var rs = cshHttpMany(items);
      r = rs[0]; pre = {};
      for (var e2 = 1; e2 < items.length; ++e2) pre[items[e2].url] = rs[e2];
   } else r = cpSfHttpText(url, hopts);
   out.ms = r.ms;
   // (28-oct-2026, tarde) QUIEN contesto (la reserva de SIMBAD, csh_net.js cshSimbadGet): para la linea de estado de quien lo pinte.
   // `fallback` = true solo si contesto el espejo (si todo fallo, `server` es el ultimo que se intento y `fallback` es false).
   out.server = r.server || ""; out.fallback = (r.ok === true && r.fallback === true);
   if (!r.ok) return no("no-network");
   if (!cpSfLooksLikeCsv(r.text, "main_id")) return no("bad-answer");
   var objs = cpSfSimbadObjects(r.text, {});
   // (28-oct-2026, A) lo que SIMBAD no mide (M 82), de OpenNGC empaquetado (csh_starfield.js `cshSizeFallback`). ANTES de la
   // profundidad: `cshDepthDeepSky` mira el tamaño (una galaxia sin el es «puntual» y se busca su gemela en Gaia).
   if (CSH_SIZE_FALLBACK === true && cshSizeNeeds(objs)) {
      var gs = cshGalaxySizes();
      out.sizeFallback = cshSizeFallback(objs, gs);
      if (gs.error) out.sizeFallback.error = gs.error;
   }
   for (var i = 0; i < objs.length; ++i) {
      var ob = objs[i];
      ob.inFrame = false; ob.cluster = -1;
      var p = (typeof result._project === "function") ? result._project(ob.ra, ob.dec) : null;
      if (p !== null) { ob.x = p.x; ob.y = p.y; ob.inFrame = (p.x >= 0 && p.y >= 0 && p.x <= f.width && p.y <= f.height); }
      // Un cumulo de estrellas de SIMBAD que ya es uno de los nuestros: su distancia es la del catalogo.
      if (ob.cls === "star-cluster")
         for (var k = 0; k < result.clusters.length; ++k) {
            var cl = result.clusters[k];
            if (cl.origin === "catalog" && cpSfSeparation(ob.ra, ob.dec, cl.ra, cl.dec) <= Math.max(0.05, cl.coreRadiusDeg || 0)) {
               ob.cluster = k;
               ob.dist = { pc: cl.dist.pc, lo: cl.dist.lo, hi: cl.dist.hi, source: "cluster-catalog", kind: "direct", quality: "good", interval: cl.dist.interval, ref: cl.dist.ref };
               break;
            }
         }
      if (ob.inFrame) ++out.inFrame;
      if (ob.dist !== null) ++out.withDistance;
      out.objects.push(ob);
   }
   // (Block G) lo que de verdad se ve: mas fuentes (GLADE+, Quaia) y fuera lo que la foto no alcanza o cae fuera del
   // encuadre, a `hidden` con su razon (csh_depth_run.js)
   out.simbadCount = out.objects.length;
   if (depthOn) {
      var od = o;
      if (pre) { od = {}; for (var ko in o) if (o.hasOwnProperty(ko)) od[ko] = o[ko]; od.prefetch = pre; }
      try { cshDepthDeepSky(result, out, od); } catch (eD) { out.depthError = String(eD.message || eD); }
   }
   out.count = out.objects.length;
   if (out.count === 0 && !(out.hiddenCount > 0)) return no("no-objects");
   out.ok = true;
   return out;
}

// ---------------------------------------------------------------------------
// LAS NEBULOSAS DEL CAMPO Y SU DISTANCIA (14-oct-2026). RED (SIMBAD TAP, dos consultas pequeñas por identificador).
// Las nebulosas del catalogo de Sharpless (empaquetado) cuyo disco toca la foto; para cada una, la distancia por el
// orden de `cpSfNebulaPick` (engine/starfield.js) con SU FUENTE y SU ERROR. Si SIMBAD no contesta, se sigue con lo
// empaquetado (Foster y Brunt, WISE) y con los cumulos de la foto, y se dice (`simbad: "failed"`).
//   opts: onProgress, httpTimeoutS, manual ({ "<id>": { pc, err } }: lo escrito a mano, que manda)
//   -> result.nebulae = { ok, code, why, ms, count, withDistance, simbad ("ok" | "failed" | ""), server, fallback (28-oct: quien contesto a SIMBAD; true = el espejo), source,
//                         objects: [ nebula ] }
//   nebula = { id ("Sh 2-132"), sh2, name (el de SIMBAD si lo tiene: «LBN 102.79-00.92»), simbadType, ra, dec,
//              sizeArcmin (diametro de Sharpless), radiusDeg, foot (`cpSfNebulaFootprint`: su huella en la foto),
//              inFrame, dist (la elegida, o null), candidates ([ { source, dist, used, why } ]), members (cuantas
//              estrellas de SIMBAD con paralaje) }
// ---------------------------------------------------------------------------
var CP_SF_NEB_GRID = [48, 32];      // diseño: la rejilla con la que se mira que parte de la foto cubre una nebulosa (1 536 puntos, < 0,1 s)

function cpSfSimbadQuery(adql, o, stage) {
   return cpSfHttpText(cpSfTapUrl(CP_SF_SIMBAD_TAP, adql), { timeoutS: o.httpTimeoutS, onProgress: function(ms) { if (typeof o.onProgress === "function") o.onProgress(stage, { elapsedMs: ms }); } });
}

function cpStarfieldNebulae(result, opts) {
   var o = opts || {}, t0 = Date.now();
   var out = { ok: false, code: "", why: "", ms: 0, count: 0, withDistance: 0, simbad: "", server: "", fallback: false, objects: [],
               source: "Sharpless 1959 (VizieR VII/20) · SIMBAD TAP (mesDistance, h_link) · Foster & Brunt 2015 · Anderson et al. 2014" };
   function no(code) { out.code = code; out.why = cpStarfieldReasonText(code); out.ms = Date.now() - t0; return out; }
   if (!result || !result.ok || !result.field) return no("no-view");
   result.nebulae = out;
   var f = result.field, cats = cpSfCatalogs();
   // (5-nov-2026) sin catalogo (no va en el paquete; si la descarga fallo): se vuelve a pedir y, si sigue sin estar, el porque va en
   // out.catalogWhy (Cabra3D lo dice en su linea de estado)
   if (!cats.nebulae || cats.nebulae.length === 0) cats = cpSfNebulaeReload(cats, o.forceCatalog === true);
   if (!cats.nebulae || cats.nebulae.length === 0) { out.catalogWhy = String(cats.nebulaError || ""); return no("no-nebula-catalog"); }
   var near = cpSfNebulaeNear(cats.nebulae, f.ra, f.dec, f.radiusDeg), i;
   if (near.length === 0) return no("no-nebula");
   // la rejilla de cielo de la foto (una vez)
   var grid = null;
   if (typeof result._unproject === "function") {
      grid = { nx: CP_SF_NEB_GRID[0], ny: CP_SF_NEB_GRID[1], width: f.width, height: f.height, ra: [], dec: [] };
      for (var gy = 0; gy < grid.ny; ++gy)
         for (var gx = 0; gx < grid.nx; ++gx) {
            var q = result._unproject((gx + 0.5) * f.width / grid.nx, (gy + 0.5) * f.height / grid.ny);
            grid.ra.push(q ? q.ra : null); grid.dec.push(q ? q.dec : null);
         }
   }
   var inside = [];
   for (i = 0; i < near.length; ++i) {
      var foot = cpSfNebulaFootprint(near[i].ra, near[i].dec, near[i].radiusDeg, grid);
      if (foot !== null) inside.push({ neb: near[i], foot: foot });
   }
   if (inside.length === 0) return no("no-nebula");
   var ids = [];
   for (i = 0; i < inside.length; ++i) ids.push(inside[i].neb.id);
   // SIMBAD: el objeto de cada una (y sus distancias) y las estrellas que cuelgan de ella
   var S = {}, C = {};
   var r1 = cpSfSimbadQuery(cpSfNebulaAdql(ids), o, "nebulae");
   if (r1.ok && cpSfLooksLikeCsv(r1.text, "main_id")) {
      S = cpSfNebulaSimbad(r1.text);
      out.simbad = "ok";
      out.server = r1.server || ""; out.fallback = (r1.fallback === true);      // (28-oct, tarde: quien contesto; ver cpStarfieldDeepSky)
      var r2 = cpSfSimbadQuery(cpSfNebulaChildrenAdql(ids), o, "nebulae");
      if (r2.ok && cpSfLooksLikeCsv(r2.text, "main_id")) { C = cpSfNebulaChildren(r2.text); if (r2.fallback === true && !out.fallback) { out.server = r2.server || ""; out.fallback = true; } }
      else out.simbad = "failed";
   } else out.simbad = "failed";
   var manual = o.manual || {};
   for (i = 0; i < inside.length; ++i) {
      var nb = inside[i].neb, n = nb.sh2, sm = S[n] || null, members = cpSfNebulaMembersParallax(C[n] || []);
      var pick = cpSfNebulaPick({ manual: cpSfNebulaManualDistance(manual[nb.id]), simbad: sm ? sm.dist : null, fb: nb.fb, wise: nb.wise, members: members,
                                  cluster: cpSfNebulaClusterInside(nb, result.clusters) });
      var ob = { id: nb.id, sh2: n, name: (sm && sm.name.length > 0) ? sm.name : nb.id, simbadType: sm ? sm.otype : "", ra: nb.ra, dec: nb.dec,
                 sizeArcmin: nb.diamArcmin, radiusDeg: nb.radiusDeg, foot: inside[i].foot, inFrame: true, dist: pick.dist, candidates: pick.list,
                 members: (C[n] || []).length };
      if (ob.dist !== null) ++out.withDistance;
      out.objects.push(ob);
   }
   // de la que mas foto cubre a la que menos
   out.objects.sort(function(a, b) { return (b.foot.frac - a.foot.frac) || (a.sh2 - b.sh2); });
   out.count = out.objects.length;
   out.ok = true;
   out.ms = Date.now() - t0;
   return out;
}
