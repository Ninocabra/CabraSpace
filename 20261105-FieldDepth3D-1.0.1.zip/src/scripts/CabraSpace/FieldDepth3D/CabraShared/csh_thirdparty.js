// ============================================================================
// CabraShared/csh_thirdparty.js — DATOS DE TERCEROS SIN LICENCIA DE REDISTRIBUCION: SE BAJAN LA PRIMERA VEZ (3-nov-2026, CPD C8)
// ----------------------------------------------------------------------------
// Reglas CPD 7.3 y 4.6: lo que no tiene licencia de redistribucion no va en el paquete; se puede bajar en ejecucion de su fuente,
// por https, guardado fuera de la instalacion y con comprobacion de integridad. Dos ficheros de CabraShared/data estaban asi:
//   1. globulars.csv: la parte de Baumgardt et al. 2023 (distancias, errores, movimientos propios y posiciones). El paquete lleva
//      globulars_harris.csv (Harris 2010, redistribuible) y la tabla de Baumgardt se baja de su web:
//         https://people.smp.uq.edu.au/HolgerBaumgardt/globular/orbits_table.txt   (43 346 bytes el 3-nov-2026)
//      y se casa con Harris COMO LO HACIA el constructor del 13-oct (cp_starfield_catalogs_build.py de CabraPilot: por posicion a menos de
//      0,05 grados, y si no, por el nombre canonico; los que solo estan en Baumgardt, al final). El resultado es el MISMO texto de datos que
//      globulars.csv (lo comprueba tests/c3_cpd.js, fila a fila).
//   2. nebulae.csv: Sharpless 1959 + Foster y Brunt 2015 + Anderson et al. 2014 (WISE), de VizieR, «free of usage in a scientific
//      context», sin licencia de redistribucion. Se bajan las tres tablas por ASU (https) del espejo de VizieR que conteste (IDIA,
//      CDS, CfA) y se arma nebulae.csv como lo hacia cp_starfield_nebulae_build.py (galacticas -> ICRS con la matriz de Hipparcos;
//      cruces por el numero de Sharpless; fuera los que caen a mas de un diametro —minimo 0,2 grados—; WISE: la de mayor radio).
// DONDE: <cache comun>/thirdparty/ (cshCacheRoot de csh_net.js: %LOCALAPPDATA%\CabraScripts\cache\thirdparty en Windows,
//   ~/Library/Caches/CabraScripts/cache/thirdparty en macOS, $XDG_CACHE_HOME o ~/.cache/CabraScripts/cache/thirdparty en Linux).
//   Nunca dentro de la instalacion de PixInsight.
// INTEGRIDAD: cada fichero bajado se comprueba ANTES de usarlo (forma: cabecera, numero de filas, columnas numericas; Sharpless: las
//   313 regiones numeradas 1-313) y se guarda sellado con su SHA-256 (cshCacheSave); al leerlo de la cache se comprueba el sello
//   (cshCacheLoad: si no cuadra se borra y se vuelve a bajar). Se apunta ademas si es la version REVISADA el 3-nov (tamaño y SHA-256
//   de CSH_TP.*.reviewed): si la fuente cambia, se usa igual si pasa las comprobaciones y se dice en la consola.
// SIN RED: la funcion sigue sin esos datos y lo dice en la consola: los globulares con lo de Harris (sin distancia de Baumgardt ni
//   movimiento propio), y sin nebulosas de Sharpless. (5-nov) Cabra3D lo dice ademas en su linea de estado (tm/netstatus.js) y «↻ Retry»
//   lo vuelve a pedir (cpSfNebulaeReload, csh_starfield_run.js). Visto con FieldDepth3D 1.0.0: IDIA contestaba 200 sin mandar nada, CDS
//   caido; el sello .fail dejaba 30 min sin nebulosas y sin decirlo (tests/c3_neb_tp_probe.js de Cabra3D).
// EN EL REPOSITORIO globulars.csv y nebulae.csv siguen estando (los usan las pruebas y CabraComposition): si estan, se usan tal cual.
//   CSH_TP_PACKAGED = true hace como en el paquete (los ignora): lo usan las pruebas.
// API: cshTpGlobularsText(dir, o) y cshTpNebulaeText(dir, o) -> { text, from: "repo" | "built" | "partial" | "none", why, notes: [] }
//      cshTpFetch(key, o) -> { ok, text, from: "cache" | "net", why, reviewed }    · o.hook(url) (pruebas) -> { ok, text } en vez de la red
// ES5. Sin «barra asterisco» en comentarios.
// ============================================================================
#ifndef __CSH_THIRDPARTY_JS
#define __CSH_THIRDPARTY_JS

var CSH_TP_PACKAGED = false;
var CSH_TP_HOOK = null;          // pruebas: function(url) -> { ok, text, code } en lugar de la red
var CSH_TP_LOG = [];             // { key, url, ok, from, why }
var CSH_TP_TIMEOUT_S = 30;
var CSH_TP_STALL_S = 15;         // (5-nov) un espejo que dice 200 y no manda nada se deja a los 15 s sin datos (IDIA el 5-nov: 0 bytes en 69 s; CfA, 0,5 s)
var CSH_TP_RETRY_MIN = 30;       // (3-nov, revisión) tras un fallo total con alguna respuesta MALA (HTTP 4xx, tabla rota), minutos sin volver a intentarlo
var CSH_TP_RETRY_NET_MIN = 5;    // (5-nov) tras un fallo total SOLO de red (sin conexión, sin datos a tiempo, HTTP 5xx), minutos sin volver a intentarlo
var CSH_TP_DEAD = {};            // servidor -> true si no contestó en esta sesión: (5-nov) se le pregunta el ÚLTIMO (antes se saltaba)
var CSH_TP_PREF = "";            // (5-nov) el servidor que dio la última tabla en esta sesión: se le pregunta el PRIMERO
var CSH_TP_ASU = ["https://vizier.idia.ac.za/viz-bin/asu-tsv", "https://vizier.cds.unistra.fr/viz-bin/asu-tsv", "https://vizier.cfa.harvard.edu/viz-bin/asu-tsv"];
var CSH_TP = {
   baumgardt: { file: "baumgardt_orbits_table.txt", urls: ["https://people.smp.uq.edu.au/HolgerBaumgardt/globular/orbits_table.txt"],
                reviewed: { bytes: 43346, sha256: "c95a085586e11e29a655a69fb9c31116072f774209ce561c11c92de1ede4bda3" } },
   sharpless: { file: "vizier_VII_20_catalog.tsv", asu: "-source=VII/20/catalog&-out=Sh2,GLon,GLat,Diam&-out.max=unlimited" },
   fosterbrunt: { file: "vizier_J_AJ_150_147_table2.tsv", asu: "-source=J/AJ/150/147/table2&-out=HII,GLON,GLAT,r,dr,Ns&-out.max=unlimited" },
   wise: { file: "vizier_J_ApJS_212_1_wisecat.tsv", asu: "-source=J/ApJS/212/1/wisecat&-out=WISE,HIIName,GLON,GLAT,Rad,Dist,e_Dist,KDA,Meth&-out.max=unlimited&Dist=%3E0" }
};

function cshTpDir() {
   var d = cshCacheRoot() + "thirdparty";
   try { if (!File.directoryExists(d)) File.createDirectory(d, true); } catch (e) {}
   return d;
}
function cshTpSay(s) { try { console.warningln("<end><cbr>** " + s); } catch (e) {} }

// una descarga por https (curl con tope; sin curl, NetworkTransfer). -> { ok, text, code, why, net }
// (5-nov) net = true si el fallo fue de RED (sin conexión, sin datos a tiempo, HTTP 5xx): decide cuánto se espera a reintentar (sello .fail)
function cshTpGet(url) {
   if (!/^https:/i.test(String(url))) return { ok: false, text: "", code: 0, why: "not https", net: false };
   if (typeof CSH_TP_HOOK === "function") {
      var h = CSH_TP_HOOK(url) || {}, hc = h.code || (h.ok ? 200 : 0);
      return { ok: h.ok === true, text: String(h.text || ""), code: hc, why: h.why || "", net: (h.net === true || (h.ok !== true && (hc === 0 || hc >= 500))) };
   }
   var out = { ok: false, text: "", code: 0, why: "", net: false };
   try {
      if (cshHasCurl()) {
         var tmp = cshTmpPath("csh_tp", ".txt");
         // (5-nov) --speed-limit/--speed-time: un espejo que contesta 200 y se queda callado (IDIA el 5-nov) no se espera los 30 s enteros
         var r = cshCurlRun(["-L", "--proto", "=https", "--proto-redir", "=https", "--connect-timeout", "10", "-m", String(CSH_TP_TIMEOUT_S),
                             "--speed-limit", "1", "--speed-time", String(CSH_TP_STALL_S), "-o", tmp, url], { timeoutS: CSH_TP_TIMEOUT_S });
         out.code = r.code;
         try { if (File.exists(tmp)) { out.text = String(File.readTextFile(tmp)); File.remove(tmp); } } catch (eR) {}
         out.ok = (r.code === 200 && out.text.length > 0 && !(r.exit > 0));
         if (!out.ok) {
            out.why = r.cut ? "no answer" : (r.exit === 28) ? "no data in time (HTTP " + r.code + ")" : ("HTTP " + r.code + (r.exit > 0 ? ", curl exit " + r.exit : ""));
            out.net = (r.cut || r.exit === 28 || r.code === 0 || r.code >= 500 || (r.code === 200 && out.text.length === 0));
         }
      } else {
         var n = cshNetworkGet(url);
         out.code = n.code; out.ok = (n.ok && n.code === 200 && n.data);
         if (out.ok) out.text = n.data.utf8ToString(); else { out.why = "HTTP " + n.code + " " + (n.message || ""); out.net = (n.code === 0 || n.code >= 500); }
      }
   } catch (e) { out.why = String(e.message || e); out.net = true; }
   return out;
}

// -- comprobar la FORMA de cada tabla antes de usarla -> "" si vale, o el porque
function cshTpCheck(key, text) {
   var t = String(text || "");
   if (/^\s*</.test(t)) return "an HTML or XML page, not the table";
   if (key === "baumgardt") {
      if (t.indexOf("#Cluster") < 0) return "no «#Cluster» header";
      var rows = cshTpBaumRows(t);
      if (rows.length < 150) return rows.length + " clusters (expected at least 150)";
      return "";
   }
   if (/#INFO\s+Error=/i.test(t)) return "VizieR error: " + (/Error=([^\n]*)/i.exec(t) || ["", ""])[1];
   var T = cshTpTsv(t);
   if (key === "sharpless") {
      if (T.rows.length !== 313) return T.rows.length + " regions (expected 313)";
      for (var i = 0; i < T.rows.length; ++i) if (parseInt(T.get(T.rows[i], "Sh2"), 10) !== i + 1) return "regions not numbered 1-313";
      return "";
   }
   if (key === "fosterbrunt") return (T.rows.length >= 100) ? "" : T.rows.length + " rows (expected at least 100)";
   if (key === "wise") return (T.rows.length >= 1000) ? "" : T.rows.length + " rows (expected at least 1000)";
   return "unknown table";
}

// LA TABLA, de la cache sellada o de la red. -> { ok, text, from, why, reviewed }
function cshTpFetch(key, o) {
   o = o || {};
   var D = CSH_TP[key], out = { ok: false, text: "", from: "", why: "", reviewed: null };
   if (!D) { out.why = "unknown"; return out; }
   var path = cshTpDir() + "/" + D.file;
   var ld = cshCacheLoad(path);
   if (ld.ok && cshTpCheck(key, ld.text) === "") { out.ok = true; out.text = ld.text; out.from = "cache"; out.reviewed = ld.meta ? ld.meta.reviewed : null; CSH_TP_LOG.push({ key: key, ok: true, from: "cache" }); return out; }
   if (ld.why === "integrity") cshTpSay("CabraShared: the cached copy of " + D.file + " did not match its SHA-256 seal: deleted, downloading it again.");
   // (3-nov, revisión) SIN RED NO SE ESPERA CADA VEZ: tras un fallo total, CSH_TP_RETRY_MIN minutos sin volver a probar (sello <fichero>.fail,
   // en la misma carpeta); y un servidor que no contestó en esta sesión no se vuelve a esperar para la tabla siguiente (CSH_TP_DEAD).
   // (5-nov) el sello dice además SI FUE LA RED («<ms> net»: se reintenta a los CSH_TP_RETRY_NET_MIN) o una respuesta mala («<ms> bad»:
   // CSH_TP_RETRY_MIN). El de antes (solo «<ms>») cuenta como de red. o.honorFail (pruebas): con CSH_TP_HOOK, el sello también vale.
   var failP = path + ".fail", now = Date.now(), seal = (CSH_TP_HOOK === null || o.honorFail === true);
   if (o.force !== true && seal) {
      try { if (File.exists(failP)) { var fw = cshTpFailWait(File.readTextFile(failP), now); if (fw.left > 0) { out.why = "not available (tried " + fw.ago + " min ago; next try after " + fw.min + " min)"; out.retryMin = fw.left; return out; } } } catch (eF) {}
   }
   // (5-nov) TODOS los espejos, en este orden: el que dio la última tabla primero, los que no contestaron en esta sesión al final (antes se
   // saltaban: si el único que contestaba era uno de ellos, la tabla no salía)
   var urls = cshTpOrder(D.urls || CSH_TP_ASU.map(function(b) { return b + "?" + D.asu; })), whys = [], allNet = true;
   for (var i = 0; i < urls.length; ++i) {
      var host = cshNetHost(urls[i]);
      var g = cshTpGet(urls[i]);
      if (!g.ok && g.net === true) CSH_TP_DEAD[host] = true;
      var bad = g.ok ? cshTpCheck(key, g.text) : (g.why || "no answer");
      CSH_TP_LOG.push({ key: key, url: urls[i], ok: bad === "", from: "net", why: bad });
      if (bad !== "") { if (!(g.ok !== true && g.net === true)) allNet = false; whys.push(cshNetServer(urls[i]) + ": " + bad); continue; }
      CSH_TP_PREF = host; delete CSH_TP_DEAD[host];
      var rv = null;
      if (D.reviewed) { var s = cshSum(g.text, "sha256"); rv = !!(s && s.bytes === D.reviewed.bytes && s.sum === D.reviewed.sha256); if (s && !rv) cshTpSay("CabraShared: " + D.file + " has changed since it was reviewed (3-nov-2026); it passes the checks and is used."); }
      cshCacheSave(path, g.text, { url: urls[i], at: (new Date()).toISOString(), reviewed: rv });
      try { if (File.exists(failP)) File.remove(failP); } catch (eRm) {}
      out.ok = true; out.text = g.text; out.from = "net"; out.reviewed = rv;
      return out;
   }
   out.why = whys.join(" · ") || "no answer";
   out.net = allNet;
   try { if (seal) File.writeTextFile(failP, String(now) + (allNet ? " net" : " bad")); } catch (eW) {}
   return out;
}
// (5-nov) el sello .fail -> { min (el plazo que le toca), ago (minutos desde el fallo), left (minutos que faltan; 0 = ya se puede) }
function cshTpFailWait(text, now) {
   var m = /^\s*(\d+)\s*(net|bad)?\s*$/.exec(String(text || "")), out = { min: 0, ago: 0, left: 0 };
   if (!m) return out;
   out.min = (m[2] === "bad") ? CSH_TP_RETRY_MIN : CSH_TP_RETRY_NET_MIN;
   var dt = now - Number(m[1]);
   out.ago = Math.round(dt / 60000);
   if (isFinite(dt) && dt >= 0 && dt < out.min * 60000) out.left = Math.max(1, Math.ceil((out.min * 60000 - dt) / 60000));
   return out;
}
// (5-nov) el orden de los espejos: el que dio la última tabla, luego el orden de siempre, y al final los que no contestaron en esta sesión
function cshTpOrder(urls) {
   var a = [], b = [], c = [];
   for (var i = 0; i < urls.length; ++i) {
      var h = cshNetHost(urls[i]);
      if (CSH_TP_PREF !== "" && h === CSH_TP_PREF) a.push(urls[i]); else if (CSH_TP_DEAD[h] === true) c.push(urls[i]); else b.push(urls[i]);
   }
   return a.concat(b, c);
}

// --- utilidades de lectura ---------------------------------------------------------------------------------------------------------
function cshTpTsv(text) {
   var L = String(text).replace(/\r/g, "").split("\n"), i = 0, head = null, rows = [];
   for (; i < L.length; ++i) { if (L[i].length === 0 || L[i].charAt(0) === "#") continue; head = L[i].split("\t").map(function(s) { return s.replace(/^\s+|\s+$/g, ""); }); break; }
   if (!head) return { cols: [], rows: [], get: function() { return ""; } };
   i += 1;                                                     // ASU: tras la cabecera, la linea de unidades y la de guiones; los datos empiezan despues de los guiones
   for (var g = i; g < Math.min(L.length, i + 3); ++g) if (/^[-\t ]+$/.test(L[g]) && L[g].indexOf("-") >= 0) { i = g + 1; break; }
   for (; i < L.length; ++i) {
      if (L[i].replace(/\s+/g, "").length === 0 || L[i].charAt(0) === "#") continue;
      rows.push(L[i].split("\t").map(function(s) { return s.replace(/^\s+|\s+$/g, ""); }));
   }
   var ix = {}; for (var k = 0; k < head.length; ++k) ix[head[k]] = k;
   return { cols: head, rows: rows, get: function(r, c) { return (ix[c] === undefined) ? "" : String(r[ix[c]] === undefined ? "" : r[ix[c]]); } };
}
function cshTpNum(s) { s = String(s === undefined || s === null ? "" : s).replace(/^\s+|\s+$/g, ""); if (s === "" || /^[.]+$/.test(s)) return null; var v = Number(s); return isFinite(v) ? v : null; }
// la «fmt» del constructor: n decimales, sin ceros de la derecha; "-0" -> "0"
function cshTpFmt(v, nd) {
   if (v === null || v === undefined) return "";
   var s = v.toFixed(nd);
   if (s.indexOf(".") >= 0) s = s.replace(/0+$/, "").replace(/[.]$/, "");
   return (s === "-0" || s === "") ? "0" : s;
}
// el «%g» de Python (6 cifras significativas, sin ceros de la derecha) para los valores de estas tablas
function cshTpG(v) {
   if (v === null || v === undefined) return "";
   if (v === 0) return "0";
   var e = Math.floor(Math.log(Math.abs(v)) / Math.LN10);
   if (e < -4 || e >= 6) { var m = v.toExponential(5).replace(/0+e/, "e").replace(/[.]e/, "e"); return m.replace(/e([+-])(\d)$/, "e$10$2"); }
   var s = v.toFixed(Math.max(0, 5 - e));
   if (s.indexOf(".") >= 0) s = s.replace(/0+$/, "").replace(/[.]$/, "");
   return s;
}
function cshTpSep(a1, d1, a2, d2) {
   var r = Math.PI / 180, x = Math.sin((d2 - d1) * r / 2), y = Math.sin((a2 - a1) * r / 2);
   var s = x * x + Math.cos(d1 * r) * Math.cos(d2 * r) * y * y;
   return 2 * Math.asin(Math.min(1, Math.sqrt(s))) / r;
}
function cshTpSepAcos(ra1, de1, ra2, de2) {
   var r = Math.PI / 180, c = Math.sin(de1 * r) * Math.sin(de2 * r) + Math.cos(de1 * r) * Math.cos(de2 * r) * Math.cos((ra1 - ra2) * r);
   return Math.acos(Math.max(-1, Math.min(1, c))) / r;
}
// galacticas -> ICRS, matriz de Hipparcos (ESA 1997, vol. 1, §1.5.3): la del constructor
function cshTpGalToIcrs(l, b) {
   var A = [[-0.0548755604162154, -0.8734370902348850, -0.4838350155487132], [0.4941094278755837, -0.4448296299600112, 0.7469822444972189], [-0.8676661490190047, -0.1980763734312015, 0.4559837761750669]];
   var r = Math.PI / 180, L = l * r, B = b * r, g = [Math.cos(B) * Math.cos(L), Math.cos(B) * Math.sin(L), Math.sin(B)], e = [0, 0, 0];
   for (var i = 0; i < 3; ++i) e[i] = A[0][i] * g[0] + A[1][i] * g[1] + A[2][i] * g[2];
   var ra = Math.atan2(e[1], e[0]) / r; ra = ((ra % 360) + 360) % 360;
   return { ra: ra, dec: Math.asin(Math.max(-1, Math.min(1, e[2]))) / r };
}

// --- 1. LOS GLOBULARES ----------------------------------------------------------------------------------------------------------
function cshTpBaumRows(text) {
   var out = [], L = String(text).replace(/\r/g, "").split("\n");
   for (var i = 0; i < L.length; ++i) {
      var l = L[i];
      if (l.charAt(0) === "#" || l.replace(/\s+/g, "").length === 0) continue;
      var t = l.replace(/^\s+|\s+$/g, "").split(/\s+/);
      if (t.length < 13) continue;
      var v = [Number(t[1]), Number(t[2]), Number(t[5]), Number(t[6]), Number(t[10]), Number(t[12])];
      if (!v.every(isFinite)) continue;
      out.push({ name: t[0].split("_").join(" "), ra: v[0], dec: v[1], rsunB: v[2], eRsunB: v[3], pmra: v[4], pmdec: v[5] });
   }
   return out;
}
function cshTpNorm(n) { return String(n).replace(/[\s_-]+/g, "").toUpperCase(); }
function cshTpCanon(n) { return cshTpNorm(n).replace("TERZAN", "TER").replace("DJORG", "DJOR"); }
// harrisText = globulars_harris.csv; baum = filas de cshTpBaumRows (o null: sin red) -> el texto con las columnas de globulars.csv
function cshTpMergeGlobulars(harrisText, baum) {
   var L = String(harrisText).replace(/\r/g, "").split("\n"), head = [], cols = null, rows = [], i;
   for (i = 0; i < L.length; ++i) {
      if (L[i].charAt(0) === "#") { head.push(L[i]); continue; }
      if (L[i].length === 0) continue;
      if (cols === null) { cols = L[i].split(";"); continue; }
      rows.push(L[i].split(";"));
   }
   var ix = {}; for (i = 0; i < cols.length; ++i) ix[cols[i]] = i;
   var H = [], stubs = [];
   for (i = 0; i < rows.length; ++i) { if (rows[i][ix.ra] === "") stubs.push(rows[i]); else H.push(rows[i]); }
   var used = {}, j;
   function put(r, b) {
      r[ix.ra] = cshTpFmt(b.ra, 5); r[ix.dec] = cshTpFmt(b.dec, 5); r[ix.rsunB] = cshTpFmt(b.rsunB, 2); r[ix.eRsunB] = cshTpFmt(b.eRsunB, 2);
      r[ix.pmra] = cshTpFmt(b.pmra, 3); r[ix.pmdec] = cshTpFmt(b.pmdec, 3); r.__b = true;
   }
   if (baum) {
      for (i = 0; i < H.length; ++i) {
         var ra = Number(H[i][ix.ra]), de = Number(H[i][ix.dec]), best = -1, bd = 1e9;
         for (j = 0; j < baum.length; ++j) { if (used[j]) continue; var d = cshTpSep(ra, de, baum[j].ra, baum[j].dec); if (d < bd) { bd = d; best = j; } }
         if (best >= 0 && bd < 0.05) { used[best] = true; put(H[i], baum[best]); }
      }
      for (j = 0; j < baum.length; ++j) {
         if (used[j]) continue;
         for (i = 0; i < H.length; ++i) if (!H[i].__b && cshTpCanon(H[i][ix.id]) === cshTpCanon(baum[j].name)) { used[j] = true; put(H[i], baum[j]); break; }
      }
      for (j = 0; j < baum.length; ++j) {
         if (used[j]) continue;
         var r = null;
         for (i = 0; i < stubs.length; ++i) if (stubs[i][ix.id] === baum[j].name) { r = stubs[i]; break; }
         if (r === null) { r = []; for (i = 0; i < cols.length; ++i) r.push(""); r[ix.id] = baum[j].name; }
         put(r, baum[j]);
         H.push(r);
      }
   }
   var out = head.concat([cols.join(";")]);
   for (i = 0; i < H.length; ++i) out.push(H[i].slice(0, cols.length).join(";"));
   return out.join("\n") + "\n";
}
function cshTpGlobularsText(dir, o) {
   o = o || {};
   var out = { text: "", from: "none", why: "", notes: [] };
   try { if (CSH_TP_PACKAGED !== true && File.exists(dir + "globulars.csv")) { out.text = File.readTextFile(dir + "globulars.csv"); out.from = "repo"; return out; } } catch (e0) {}
   var harris = "";
   try { harris = File.readTextFile(dir + "globulars_harris.csv"); } catch (e1) { out.why = "globulars_harris.csv: " + e1; return out; }
   var f = cshTpFetch("baumgardt", o);
   if (f.ok) { out.text = cshTpMergeGlobulars(harris, cshTpBaumRows(f.text)); out.from = "built"; out.notes.push("Baumgardt " + f.from); return out; }
   out.text = cshTpMergeGlobulars(harris, null); out.from = "partial"; out.why = f.why;
   cshTpSay("Globular clusters without the Baumgardt et al. database (distances and proper motions): it could not be downloaded (" + f.why + "). Using Harris 2010 only.");
   return out;
}

// --- 2. LAS NEBULOSAS ------------------------------------------------------------------------------------------------------------
function cshTpBuildNebulae(shText, fbText, wiText) {
   var SH = cshTpTsv(shText), FB = cshTpTsv(fbText), WI = cshTpTsv(wiText), neb = {}, i, n, m;
   for (i = 0; i < SH.rows.length; ++i) {
      n = parseInt(SH.get(SH.rows[i], "Sh2"), 10);
      var p = cshTpGalToIcrs(Number(SH.get(SH.rows[i], "GLon")), Number(SH.get(SH.rows[i], "GLat")));
      neb[n] = { ra: p.ra, dec: p.dec, diam: cshTpNum(SH.get(SH.rows[i], "Diam")), fb: null, wise: null };
   }
   var dropped = [];
   for (i = 0; i < FB.rows.length; ++i) {
      m = /^\s*Sh2-(\d+)\s*$/.exec(FB.get(FB.rows[i], "HII"));
      if (!m) continue;
      n = parseInt(m[1], 10);
      if (!neb[n]) continue;
      var q = cshTpGalToIcrs(Number(FB.get(FB.rows[i], "GLON")), Number(FB.get(FB.rows[i], "GLAT")));
      var d = cshTpSepAcos(neb[n].ra, neb[n].dec, q.ra, q.dec);
      if (!(d < Math.max(0.2, (neb[n].diam || 0) / 60))) { dropped.push("F&B Sh2-" + n); continue; }
      neb[n].fb = [cshTpNum(FB.get(FB.rows[i], "r")), cshTpNum(FB.get(FB.rows[i], "dr")), Math.round(cshTpNum(FB.get(FB.rows[i], "Ns")) || 0)];
   }
   for (i = 0; i < WI.rows.length; ++i) {
      var names = WI.get(WI.rows[i], "HIIName"), re = /(?:^|[ ;])S(\d{1,3})(?=$|[ ;])/g;
      while ((m = re.exec(names)) !== null) {
         n = parseInt(m[1], 10);
         if (!neb[n]) continue;
         var rad = cshTpNum(WI.get(WI.rows[i], "Rad")) || 0, w = cshTpGalToIcrs(Number(WI.get(WI.rows[i], "GLON")), Number(WI.get(WI.rows[i], "GLAT")));
         var dw = cshTpSepAcos(neb[n].ra, neb[n].dec, w.ra, w.dec);
         if (!(dw < Math.max(0.2, (neb[n].diam || 0) / 60))) { dropped.push("WISE " + WI.get(WI.rows[i], "WISE") + " (S" + n + ")"); continue; }
         var cand = [cshTpNum(WI.get(WI.rows[i], "Dist")), cshTpNum(WI.get(WI.rows[i], "e_Dist")), WI.get(WI.rows[i], "KDA"), WI.get(WI.rows[i], "Meth"), WI.get(WI.rows[i], "WISE"), rad];
         if (neb[n].wise !== null && rad <= neb[n].wise[5]) continue;
         neb[n].wise = cand;
      }
   }
   var out = ["sh2,ra,dec,diam_arcmin,fb_kpc,fb_err_kpc,fb_n,wise_id,wise_kpc,wise_err_kpc,wise_kda,wise_method"];
   var keys = Object.keys(neb).map(Number).sort(function(a, b) { return a - b; });
   for (i = 0; i < keys.length; ++i) {
      var e = neb[keys[i]], f = e.fb || [null, null, 0], x = e.wise || [null, null, "", "", ""];
      out.push([keys[i], e.ra.toFixed(4), e.dec.toFixed(4), cshTpG(e.diam), cshTpG(f[0]), cshTpG(f[1]), (f[0] !== null) ? String(f[2]) : "",
                (x[0] !== null) ? x[4] : "", cshTpG(x[0]), cshTpG(x[1]), (x[0] !== null) ? x[2] : "", (x[0] !== null) ? x[3] : ""].join(","));
   }
   return { text: out.join("\n") + "\n", dropped: dropped };
}
function cshTpNebulaeText(dir, o) {
   o = o || {};
   var out = { text: "", from: "none", why: "", notes: [] };
   try { if (CSH_TP_PACKAGED !== true && File.exists(dir + "nebulae.csv")) { out.text = File.readTextFile(dir + "nebulae.csv"); out.from = "repo"; return out; } } catch (e0) {}
   var t = {}, keys = ["sharpless", "fosterbrunt", "wise"], whys = [];
   for (var i = 0; i < keys.length; ++i) {
      var f = cshTpFetch(keys[i], o);
      if (f.ok) t[keys[i]] = f.text; else whys.push(keys[i] + ": " + f.why);
      if (i === 0 && !f.ok) break;             // (sin Sharpless no hay lista de nebulosas: no se esperan las otras dos)
   }
   if (!t.sharpless) {
      out.why = whys.join(" · ");
      cshTpSay("Emission nebulae (Sharpless) not available: the catalogue could not be downloaded from VizieR (" + out.why + "). The 3D view goes on without them.");
      return out;
   }
   var b = cshTpBuildNebulae(t.sharpless, t.fosterbrunt || "", t.wise || "");
   out.text = b.text; out.from = (t.fosterbrunt && t.wise) ? "built" : "partial"; out.notes = b.dropped;
   if (out.from === "partial") { out.why = whys.join(" · "); cshTpSay("Emission nebulae without some distances: " + out.why); }
   return out;
}

#endif
