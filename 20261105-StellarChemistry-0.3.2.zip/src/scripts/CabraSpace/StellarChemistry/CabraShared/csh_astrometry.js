// ============================================================================
// CabraShared/csh_astrometry.js — LA IMAGEN Y SU SOLUCION: ¿tiene WCS?, leerla, y resolverla SOLO si hace falta
// ----------------------------------------------------------------------------
// Peticion de Nino (14-oct): «si la imagen se puede resolver (WCS ya presente) NO se llama a ImageSolver; si no, se
// resuelve». Habia tres versiones (CabraStars `csSolveIfNeeded`, Cabra3D `c3EnsureSolved`, CabraComposition
// `ccSolveView`) con la misma receta de CabraPilot (engine/astrometry.js `cpSolveAstrometry`). Esta es la UNION de lo
// mejor de cada una:
//   · de Cabra3D: borrar las propiedades de una solucion vieja, dar J2000 si no hay fecha (sin ella la base Gaia local
//     no carga: «Missing observation time metadata», c3_probe_solve.log), RBF de placa delgada, costura de pruebas y
//     contador de llamadas («una imagen resuelta NO llama a ImageSolver»);
//   · de CabraStars: la semilla explicita (pruebas) y el aviso de progreso;
//   · de las tres: si el intento automatico falla y hay PANTALLA, el dialogo de ImageSolver (centro y escala a mano).
// `cshEnsureSolved( view, o )` -> { ok, state ("already" | "solved" | "failed" | "cancelled" | "disabled"), why, ms, blind (lo identifico el solver ciego de 1.9.6), noIndex }
//   o = { onProgress(text), hint: { ra, dec, resolution }, dialog (bool; por defecto: solo con pantalla), allow (bool) }
// COSTURA DE PRUEBAS: CSH_SOLVE_HOOK( window ) -> { ok, why } EN VEZ de ImageSolver; CSH_SOLVE_CALLS cuenta las llamadas.
// La libreria ImageSolver la incluye el script principal (modo libreria). ES5.
// ============================================================================

var CP_ANNOT_DEFAULT_EPOCH = 2451545.0;        // J2000: lo que se pone cuando la imagen no dice cuando se tomo
var CSH_SOLVE_HOOK = null;
var CSH_SOLVE_CALLS = 0;
var CSH_WCS_STALE = ["PCL:AstrometricSolution:Information", "PCL:AstrometricSolution:SplineWorldTransformation"];

// Una vista utilizable: existe, no es nula, tiene imagen y ventana (CabraPilot engine/inherited.js + CabraStars).
function optSafeView(view) {
   try {
      var notNull = true;
      try { if (typeof view.isNull !== "undefined") notNull = (view.isNull === false); } catch (e0) { notNull = true; }
      if (!(view && typeof view === "object" && notNull && view.image && view.window)) return false;
      try { if (!(view.image.width > 0)) return false; } catch (e1) {}
      return true;
   } catch (e) { return false; }
}

// ¿Tiene la vista una solucion astrometrica? El indicador del nucleo, la propiedad de la proyeccion, o claves WCS.
function cpHasAstrometricSolution(view) {
   if (!optSafeView(view)) return false;
   try { if (view.window && view.window.hasAstrometricSolution) return true; } catch (eAuth) {}
   try { var projection = view.propertyValue("PCL:AstrometricSolution:ProjectionSystem"); if (projection !== null && projection !== undefined && String(projection).length > 0) return true; } catch (e0) {}
   try {
      var kw = view.window.keywords;
      for (var i = 0; i < kw.length; ++i) { var name = (kw[i].name || "").toUpperCase(); if (name === "CTYPE1" || name === "CRVAL1" || name === "CD1_1" || name === "PC1_1") return true; }
   } catch (e1) {}
   return false;
}
function cshHasSolution(view) { return cpHasAstrometricSolution(view); }

// (30-oct-2026) LA SOLUCION SE LEE UNA VEZ. Medido en Pleyades con CJ_PROFILE: ExtractMetadata tarda 4 s (el modelo de splines) y se llamaba al previsualizar y otra vez al analizar: dos huecos de 4 s
// con la ventana parada antes de que hubiera nada que tocar. Se recuerda la ultima, por una huella de la solucion: si se vuelve a resolver la imagen en la misma ventana, cambia (csh_mdmemo_pi.js C3).
// Sin propiedades de la solucion (solo cabecera FITS), sin huella: se lee cada vez, como antes. Nadie escribe en el objeto salvo observationTime, con el mismo J2000 en los dos sitios. Rojo: CSH_NET_BREAK=nomdmemo.
var CSH_MD_MEMO = null;
function cshSolutionStamp(view) {
   try {
      var P = ["ReferenceCelestialCoordinates", "ReferenceImageCoordinates", "LinearTransformationMatrix", "ProjectionSystem", "CreationTime"], s = [view.fullId, view.image.width, view.image.height], got = false;
      for (var i = 0; i < P.length; ++i) {
         var v = view.propertyValue("AstrometricSolution:" + P[i]);                  // (ImageSolver 6.5; hasta 6.3, con PCL: delante. Medido: Pleyades y Abell 39, csh_mdmemo_sonda.js)
         if (v === null || v === undefined) v = view.propertyValue("PCL:AstrometricSolution:" + P[i]);
         var t = (v === null || v === undefined) ? "" : ((typeof v.toArray === "function") ? v.toArray().join(",") : String(v));
         if (i === 0 && t !== "") got = true;
         s.push(t);
      }
      return got ? s.join("|") : "";
   } catch (e) { return ""; }
}
function cshMetadataRead(view) {
   var stamp = (typeof cshNetBrk === "function" && cshNetBrk("nomdmemo")) ? "" : cshSolutionStamp(view);
   if (stamp !== "" && CSH_MD_MEMO && CSH_MD_MEMO.stamp === stamp) return CSH_MD_MEMO.md;
   var md = new AstrometricMetadata;
   md.ExtractMetadata(view.window);
   if (stamp !== "" && md && md.projection) CSH_MD_MEMO = { stamp: stamp, md: md };
   return md;
}
// La solucion leida con la libreria de ImageSolver (`AstrometricMetadata`). null si no hay.
function cpAnnotMetadata(view) {
   if (!optSafeView(view) || !cpHasAstrometricSolution(view) || typeof AstrometricMetadata !== "function") return null;
   var md = null;
   try { md = cshMetadataRead(view); }
   catch (e) { try { console.warningln(cshT("could not read the astrometric solution: ") + (e.message || e)); } catch (eW) {} return null; }
   if (!md || !md.projection) return null;
   if (!md.observationTime) md.observationTime = CP_ANNOT_DEFAULT_EPOCH;   // (sin esto, Load LANZA con una imagen sin DATE-OBS)
   return md;
}

// ¿LINEAL? (CabraPilot engine/image_manager.js, la version de Cabra3D): la propiedad del nucleo si la hay, y si no las
// tres señales con sus umbrales (mediana < 0,10, MAD < 0,008, MTF necesaria < 0,15). La calibracion fotometrica vuelve a
// comprobarlo con la pendiente de la magnitud (`nonlinear`). (CabraStars usaba una heuristica propia —mediana < 0,08 y
// el historial—: se unifica en esta, la de CabraPilot.)
function cshMtf(m, x) {
   if (x <= 0) return 0; if (x >= 1) return 1; if (m === x) return 0.5;
   return (m - 1) * x / ((2 * m - 1) * x - m);
}
// (30-oct-2026) EL STF DE LA VISTA (Nino: «cuando cargo la imagen, tengo un color diferente que la imagen que veo en el Workspace»):
// la foto de los paneles se pinta con el MISMO STF que la vista tiene en PixInsight; el estirado automático propio queda solo
// para cuando la vista no tiene ninguno. `view.stf` (medido, CabraStars/tests/cs_probe_stf.log): por canal R, G, B, L
// [m, c0, c1, r0, r1]; recién abierta, la identidad [0.5, 0, 1, 0, 1] en los cuatro. En gris PixInsight usa la fila 0 (R/K).
// Devuelve [{ m, c0, c1, r0, r1 }] (3 filas en color, 1 en gris) o null si es la identidad o no se puede leer.
// Rojo: CSH_STF_BREAK = "noview" (se ignora el STF de la vista, como antes).
var CSH_STF_BREAK = "";
function cshViewStf(view, nc) {
   if (CSH_STF_BREAK === "noview") return null;
   var s = null;
   try { s = view.stf; } catch (e) { return null; }
   if (!s || !s.length) return null;
   var n = (nc >= 3) ? 3 : 1, out = [], any = false;
   for (var c = 0; c < n; ++c) {
      var r = s[c];
      if (!r || r.length < 3) return null;
      var o = { m: +r[0], c0: +r[1], c1: +r[2], r0: (r.length > 3) ? +r[3] : 0, r1: (r.length > 4) ? +r[4] : 1 };
      if (!(isFinite(o.m) && isFinite(o.c0) && isFinite(o.c1) && o.c1 > o.c0)) return null;
      if (Math.abs(o.m - 0.5) > 1e-6 || o.c0 > 1e-9 || o.c1 < 1 - 1e-9 || Math.abs(o.r0) > 1e-9 || Math.abs(o.r1 - 1) > 1e-9) any = true;
      out.push(o);
   }
   return any ? out : null;
}
// Un valor a través de una fila de STF (como lo hace PixInsight: recorte c0-c1, MTF, expansión r0-r1)
function cshStfValue(o, v) {
   var x = (v - o.c0) / (o.c1 - o.c0);
   x = (x <= 0) ? 0 : (x >= 1) ? 1 : cshMtf(o.m, x);
   return o.r0 + x * (o.r1 - o.r0);
}
// (31-oct-2026) ¿LINEAL O YA ESTIRADA? La regla de arriba (mediana, MAD y MTF) fallaba en los dos sentidos: la MAD de `view.image.MAD()` mezcla los tres
// canales, y una foto lineal con fondos distintos por canal salía «no lineal» (Soul Nebula, 0,0134). Y era una regla sobre el FONDO: no dice nada de una imagen
// terminada con el cielo oscuro. Lo que separa las dos familias es LA COLA: en una lineal el 1 % más brillante apenas se separa del cielo, en una estirada sí.
//   Es NO lineal si mediana > 0,20, o si p99 − mediana > 0,035 Y p99,9 − mediana > 0,30 (sobre la media de los canales nominales; unas 400 000 muestras, ~60 ms).
//   Medido (CabraStars/docs/lineal_vs_no_lineal_31oct.md): 16 de 16 lineales reales bien (la mayor cola, Orion: 0,0218 / 0,272) y los 5 finales reales bien
//   (la menor cola, NGC 3184: 0,0515 / 0,401). Estirados fuertes de otras curvas, bien. Se escapan estirados suaves (gamma 0,7; arcsinh 20): salen «lineales»
//   y reciben el estirado automático; quien lo vea mal pone un STF en PixInsight y manda ese (cshViewStf).
// Rojo: CSH_LIN_BREAK = "old" (la regla de antes).
var CSH_LIN = { MED_HI: 0.20, TAIL99: 0.035, TAIL999: 0.30, SAMPLES: 400000 };
var CSH_LIN_BREAK = "";
function cshLinearStats(view) {
   var img = view.image, nc = 1;
   try { nc = Math.min(3, img.numberOfNominalChannels); } catch (eN) { nc = img.isColor ? 3 : 1; }
   var W = img.width, H = img.height, st = Math.max(1, Math.floor(Math.sqrt(W * H / CSH_LIN.SAMPLES))), nr = Math.floor(H / st), nw = Math.floor(W / st);
   var S = new Float32Array(nr * nw), row = new Float32Array(W), k;
   for (var c = 0; c < nc; ++c) {
      k = 0;
      for (var y = 0; y < nr; ++y) {
         img.getSamples(row, new Rect(0, y * st, W, y * st + 1), c);
         for (var x = 0; x < nw; ++x) S[k++] += row[x * st] / nc;
      }
   }
   S.sort();
   var N = S.length, med = S[N >> 1];
   return { med: med, tail99: S[Math.min(N - 1, Math.floor(0.99 * N))] - med, tail999: S[Math.min(N - 1, Math.floor(0.999 * N))] - med };
}
function cpViewIsLinear(view) {
   if (!optSafeView(view)) return false;
   try { if (view.image && ("isLinear" in view.image)) { var p = view.image["isLinear"]; if (p === true || p === false) return p; } } catch (eP) {}
   if (CSH_LIN_BREAK === "old") {
      var med0, mad0;
      try { med0 = view.image.median(); mad0 = view.image.MAD(); } catch (e0) { return false; }
      if (med0 === 0 && mad0 === 0) return true;
      var c00 = Math.max(0, med0 - 2.8 * mad0), m0 = cshMtf(0.25, med0 - c00);
      if (!isFinite(m0)) m0 = 0.5;
      return (med0 < 0.10) && (mad0 < 0.008) && (m0 < 0.15);
   }
   var s;
   try { s = cshLinearStats(view); } catch (e) { return false; }
   return !(s.med > CSH_LIN.MED_HI || (s.tail99 > CSH_LIN.TAIL99 && s.tail999 > CSH_LIN.TAIL999));
}
// (31-oct-2026) CÓMO SE PINTA LA FOTO, UNA SOLA REGLA PARA TODOS (Nino: «las que ya están estiradas no tenemos que estirarlas»; antes cada script tenía la suya:
// CabraStars estiraba canal a canal todo canal con mediana < 0,2, y CabraComposition, si la media de medianas < 0,08):
//   "view"  la vista tiene STF en PixInsight: ese, sea lineal o no · "none" ya estirada: tal cual ·
//   "mad-linked" lineal con el color calibrado o gris (conserva el equilibrio de SPCC) · "mad-unlinked" lineal sin calibrar (cada canal el suyo).
// Fondo del cielo del estirado automático: el 12 % que pidió Nino el 20-oct (con el 0,25 del AutoSTF salía lavada), ahora en los cuatro.
var CSH_STF_BKG = 0.12;
function cshPhotoStretchMode(view) {
   if (!optSafeView(view)) return "none";
   var nc = 1;
   try { nc = view.image.numberOfChannels; } catch (e) {}
   if (cshViewStf(view, nc)) return "view";
   if (!cpViewIsLinear(view)) return "none";
   var c = cshColorStatus(view);
   return (c.mono || c.calibrated) ? "mad-linked" : "mad-unlinked";
}
// Las filas del estirado automático: medianas y MAD NORMALIZADAS (×1,4826) por canal → [{ c0, m }], enlazadas si `linked`. El MTF es el de PixInsight.
function cshAutoStfRows(meds, mads, linked) {
   var out = [], n = meds.length, a = 0, b = 0, c;
   for (c = 0; c < n; ++c) { a += meds[c]; b += mads[c]; }
   a /= n; b /= n;
   for (c = 0; c < n; ++c) {
      var med = linked ? a : meds[c], mad = linked ? b : mads[c], c0 = Math.max(0, Math.min(1, med - 2.8 * mad));
      out.push({ c0: c0, m: cshMtf(CSH_STF_BKG, Math.max(1e-6, med - c0)) });
   }
   return out;
}

// (F2, 22-oct-2026) Los espejos de VizieR para ImageSolver, en orden: CfA y NAO, los de la lista de PixInsight
// (pjsr/astrometry/AstronomicalCatalogs.js, «VizieR mirrors») PERO SIN su «/vizier/» final: ImageSolver pide
// <servidor> + "viz-bin/asu-tsv?…" y, MEDIDO el 22-oct, https://vizier.cfa.harvard.edu/vizier/viz-bin/asu-tsv y
// el de NAO (vizier.nao.ac.jp/vizier/viz-bin/asu-tsv, solo http) dan HTTP 404; en la raiz (…/viz-bin/asu-tsv) contestan 200 con la tabla.
// (La primera version con la lista tal cual fallo asi: cs_test_f2_pi.js P4, «Catalog error: GaiaDR2» en los dos espejos.)
// NAO por http (por https no contesto: 21 s y nada). COSTURA: CSH_SOLVE_CFG_HOOK(solver, servidor) tras montar cada solver
// (las pruebas fuerzan el catalogo en linea y un servidor que no contesta).
// (31-oct-2026) PixInsight 1.9.6 solo admite los espejos HTTPS de su lista (CDS, CfA, IUCAA, INASAN, IDIA) y convierte el resto a CDS: pedir NAO acababa en CDS, ya caido (MEDIDO: cs_test_f2_pi P4b, «Failed to connect to
// vizier.cds.unistra.fr» con el servidor NAO). Alli se salta NAO y queda IDIA, el de la lista que contesto el dia que los demas callaban (csh_net.js).
// (3-nov-2026, CPD C1) Sin NAO: solo por http (reglas CPD 6.3: todo por https). Quedan CfA e IDIA, los dos por https.
var CSH_SOLVE_MIRRORS = [["https://vizier.cfa.harvard.edu/", "VizieR CfA (Harvard)"], ["https://vizier.idia.ac.za/", "VizieR IDIA (Cape Town)"]];
var CSH_SOLVE_CFG_HOOK = null;
// ¿Fallo ImageSolver por la DESCARGA del catalogo de VizieR? El motor lanza «Catalog error: <catalogo>» cuando el catalogo
// queda sin objetos (la descarga no llego o no se pudo leer); solo cuenta si el catalogo es de VizieR (los de VizieR
// construyen una URL: UrlBuilder; el Gaia local XPSD no).
function cshSolverVizierFailed(solver, why) {
   if (!/Catalog error/i.test(String(why || ""))) return false;
   try { var c = solver ? solver.catalog : null; return !!(c && typeof c.UrlBuilder === "function"); } catch (e) { return false; }
}

// ¿Hay pantalla? Ningun dialogo modal cuando CUALQUIERA de estas tres cosas dice que no (M8, 31-oct-2026, PixInsight 1.9.6):
//   · el parametro non_interactive de los scripts (lo ponen las pruebas y el Event Script de WBPP);
//   · CoreApplication.automationMode: PixInsight arrancado con --automation-mode (no abre cuadros modales; un dialogo nuestro cuelga);
//   · CoreApplication.nonInteractive: hay abierta una seccion no interactiva (beginNonInteractive sin su endNonInteractive).
// Cada una solo cuenta si existe y vale true (en 1.9.5 o sin ella: lo de siempre). En un PixInsight normal las tres son false.
function cshAutomationReason() {
   try { if (Parameters.getBoolean("non_interactive")) return "non_interactive"; } catch (e0) {}
   try { if (typeof CoreApplication !== "undefined" && CoreApplication.automationMode === true) return "automationMode"; } catch (e1) {}
   try { if (typeof CoreApplication !== "undefined" && CoreApplication.nonInteractive === true) return "nonInteractive"; } catch (e2) {}
   return "";
}
function cshInteractive() { return cshAutomationReason() === ""; }
function cshImageSolverAvailable() { try { return (typeof ImageSolver === "function"); } catch (e) { return false; } }
function cshKillSolverDiagnostics() {
   var trash = ["stars", "matches", "distortion"];
   for (var i = 0; i < trash.length; ++i) { try { var w = ImageWindow.windowById(trash[i]); if (w != null && !w.isNull) w.forceClose(); } catch (e) {} }
}

function cshEnsureSolved(view, o) {
   o = o || {};
   var t0 = Date.now(), out = { ok: false, state: "failed", why: "", ms: 0 };
   if (!optSafeView(view)) { out.why = cshT("no image is selected."); return out; }
   if (cpHasAstrometricSolution(view)) { out.ok = true; out.state = "already"; out.ms = Date.now() - t0; return out; }
   if (o.allow === false) { out.state = "disabled"; out.why = "solving disabled"; return out; }
   ++CSH_SOLVE_CALLS;
   var win = view.window;
   if (typeof CSH_SOLVE_HOOK === "function") {
      var h = CSH_SOLVE_HOOK(win) || {};
      out.ok = (h.ok === true) && cpHasAstrometricSolution(view); out.state = out.ok ? "solved" : "failed"; out.why = String(h.why || "");
      out.ms = Date.now() - t0;
      return out;
   }
   if (!cshImageSolverAvailable()) { out.why = cshT("The ImageSolver library is not loaded: run Script > Astrometry > ImageSolver on the image and try again."); return out; }
   if (typeof o.onProgress === "function") { try { o.onProgress(cshT("Solving the image with ImageSolver…")); } catch (eP0) {} }
   try { win.show(); win.bringToFront(); win.currentView = win.mainView; } catch (eP) {}
   for (var i = 0; i < CSH_WCS_STALE.length; ++i) { try { view.deleteProperty(CSH_WCS_STALE[i]); } catch (eD) {} }
   var solver = null, first = "";
   // (F2) el solver, montado igual cada vez (la segunda, para un espejo de VizieR: `server`)
   function makeSolver(server) {
      var sv = new ImageSolver();
      sv.initialize(win, false);
      try { if (!sv.metadata.observationTime) sv.metadata.observationTime = CP_ANNOT_DEFAULT_EPOCH; } catch (eT) {}
      try { sv.solverCfg.distortionCorrection = true; } catch (e0) {}
      try { sv.solverCfg.rbfType = RBFType_DDMThinPlateSpline; } catch (e1) {}
      if (o.hint) {
         try { if (isFinite(o.hint.ra)) sv.metadata.ra = o.hint.ra; if (isFinite(o.hint.dec)) sv.metadata.dec = o.hint.dec; if (o.hint.resolution > 0) sv.metadata.resolution = o.hint.resolution; } catch (eH) {}
         try { sv.userSeed = { coordinates: isFinite(o.hint.ra) && isFinite(o.hint.dec), scale: o.hint.resolution > 0 }; } catch (eU) {}   // (1.9.6) sin esto, ImageSolver no se fia de la semilla y va directo al ciego
      }
      // (31-oct-2026) SOLVER CIEGO DE PIXINSIGHT 1.9.6: ImageSolver 6.6 identifica el campo sin coordenadas, o si las de la cabecera son malas, y sigue con su proceso completo (Gaia y distorsion).
      // Automatic es su valor de fabrica; se fija porque el modo guardado en el dialogo podria ser Disabled. Sin indice astrometrico, o en 1.9.5 (sin BlindSolverMode), la ruta de siempre.
      try { if (typeof BlindSolverMode !== "undefined") sv.solverCfg.blindSolver = BlindSolverMode.Automatic; } catch (eB) {}
      if (typeof CSH_SOLVE_CFG_HOOK === "function") { try { CSH_SOLVE_CFG_HOOK(sv, server || ""); } catch (eK) {} }
      if (server) { try { sv.solverCfg.vizierServer = server; } catch (eS) {} }
      return sv;
   }
   try { solver = makeSolver(""); } catch (eInit) { out.why = cshT("ImageSolver could not start: ") + (eInit.message || eInit); out.ms = Date.now() - t0; return out; }
   try { solver.solveImage(win); } catch (eAuto) { first = String(eAuto.message || eAuto); try { console.warningln("CabraShared: automatic ImageSolver attempt failed: " + first); } catch (eW) {} }
   cshKillSolverDiagnostics();
   if (cpHasAstrometricSolution(view)) { out.ok = true; out.state = "solved"; try { out.blind = !!solver.blindSolution; } catch (eBS) {} out.ms = Date.now() - t0; return out; }
   // (F2, 22-oct-2026) SI FALLO POR VizieR (la descarga del catalogo: «Catalog error» con un catalogo de VizieR, no el Gaia
   // local), otra vez con los ESPEJOS de VizieR de la lista de PixInsight (pjsr/astrometry/AstronomicalCatalogs.js): CfA y
   // luego NAO. Solo en ese caso: un fallo por pocas estrellas o por la semilla no se repite (no lo arreglaria un espejo).
   out.mirrors = [];
   var why0 = first;
   for (var mi = 0; mi < CSH_SOLVE_MIRRORS.length && cshSolverVizierFailed(solver, why0); ++mi) {
      var mr = CSH_SOLVE_MIRRORS[mi], cur = "";
      try { cur = String(solver.solverCfg.vizierServer || ""); } catch (eC) {}
      if (cur === mr[0]) continue;
      if (!/^https:/.test(mr[0])) continue;      // (3-nov-2026, CPD C1) nunca un servidor que no sea https, aunque alguien lo meta en la lista
      try { console.warningln("CabraShared: VizieR failed for ImageSolver (" + why0 + "): trying the mirror " + mr[1] + " <raw>" + mr[0] + "</raw>"); } catch (eW3) {}
      if (typeof o.onProgress === "function") { try { o.onProgress(cshT("Solving the image with ImageSolver…") + " (" + mr[1] + ")"); } catch (eP2) {} }
      why0 = "";
      try { solver = makeSolver(mr[0]); solver.solveImage(win); } catch (eM) { why0 = String(eM.message || eM); }
      cshKillSolverDiagnostics();
      out.mirrors.push({ server: mr[0], name: mr[1], why: why0 });
      if (cpHasAstrometricSolution(view)) { out.ok = true; out.state = "solved"; out.mirror = mr[1]; try { out.blind = !!solver.blindSolution; } catch (eBS3) {} out.ms = Date.now() - t0; return out; }
   }
   // segunda pasada: el dialogo de ImageSolver (centro y escala a mano). Solo con pantalla.
   var dialog = ((o.dialog === undefined) ? true : (o.dialog === true)) && cshInteractive();      // (M8) pedirlo no basta: en automatizacion nunca
   if (dialog && typeof ImageSolverDialog === "function") {
      try {
         var metadata = null;
         try { metadata = solver.metadata; } catch (eM) {}
         if (metadata != null) {
            var dlg = new ImageSolverDialog(solver.solverCfg, metadata, true);
            if (!dlg.execute()) { cshKillSolverDiagnostics(); out.state = "cancelled"; out.why = cshT("ImageSolver cancelled by the user"); out.ms = Date.now() - t0; return out; }
            try { solver.solverCfg = dlg.solverCfg; solver.metadata = dlg.metadata; solver.userSeed = { coordinates: true, scale: true }; } catch (eCfg) {}
            if (typeof o.onProgress === "function") { try { o.onProgress(cshT("Solving the image with ImageSolver…")); } catch (eP1) {} }
            solver.solveImage(win);
         }
      } catch (eSolve) { first = String(eSolve.message || eSolve); try { console.warningln("CabraShared: ImageSolver failed: " + first); } catch (eW2) {} }
      cshKillSolverDiagnostics();
   }
   out.ok = cpHasAstrometricSolution(view);
   out.state = out.ok ? "solved" : "failed";
   if (!out.ok) {
      out.why = cshT("ImageSolver did not get a valid solution (give it the centre and the pixel scale in its dialog)."); out.first = first;
      try { if (typeof BlindSolverMode !== "undefined" && solver.astrometricIndexFilePath().length === 0) { out.noIndex = true; out.why += " " + cshT("To solve without coordinates, choose an astrometric index file in the preferences of the Gaia process."); } } catch (eNI) {}
   }
   try { if (out.ok) out.blind = !!solver.blindSolution; } catch (eBS2) {}
   out.ms = Date.now() - t0;
   return out;
}

// ¿Color, calibrado? (consejo, no bloqueo). La lista de CabraPilot (engine/image_manager.js) en el historial de la sesion y
// en el guardado en el fichero (propiedad PixInsight:ProcessingHistory, que vio CabraComposition). -> { mono, calibrated, how }
var CSH_COLOR_CAL_PROCESSES = ["SpectrophotometricColorCalibration", "PhotometricColorCalibration", "ColorCalibration"];
function cshColorStatus(view) {
   var out = { mono: false, calibrated: false, how: "" };
   if (!optSafeView(view)) return out;
   try { out.mono = (view.image.numberOfChannels < 3); } catch (e0) {}
   if (out.mono) return out;
   function scan(container) {
      var n = 0;
      try { n = container.length; } catch (e) { return ""; }
      for (var i = 0; i < n; ++i) {
         var pid = "";
         try { pid = String(container.at ? container.at(i).processId() : container[i].processId()); } catch (e1) { continue; }
         if (CSH_COLOR_CAL_PROCESSES.indexOf(pid) >= 0) return pid;
      }
      return "";
   }
   var how = "";
   try { how = scan(view.initialProcessing); } catch (e2) {}
   if (!how) try { how = scan(view.processing); } catch (e3) {}
   if (!how) try { var ph = String(view.propertyValue("PixInsight:ProcessingHistory") || ""); for (var k = 0; k < CSH_COLOR_CAL_PROCESSES.length && !how; ++k) if (ph.indexOf(CSH_COLOR_CAL_PROCESSES[k]) >= 0) how = CSH_COLOR_CAL_PROCESSES[k]; } catch (e4) {}
   out.calibrated = how.length > 0; out.how = how;
   return out;
}
