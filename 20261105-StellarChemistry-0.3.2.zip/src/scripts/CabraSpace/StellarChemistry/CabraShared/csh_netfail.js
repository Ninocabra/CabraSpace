#ifndef __CSH_NETFAIL_JS
#define __CSH_NETFAIL_JS
// ============================================================================
// CabraShared/csh_netfail.js — LOS CATALOGOS CON RESPALDO, COMUN (F2, 22-oct-2026)
// ----------------------------------------------------------------------------
// PROCEDENCIA: CabraStars lib/cs_netfail.js (F1, 22-oct-2026; probado: tests/cs_test_netfail.js 17/17 y cs_test_netreal.js
// contra la red de verdad), subido aqui con el prefijo csh (csNf* -> cshNf*, CS_NF* -> CSH_NF*, csAsu* -> cshAsu*) para que
// lo usen los demas scripts. CabraStars lo incluye desde lib/cs_netfail.js (capa fina: su subcarpeta de cache y su gancho de
// capas). NADIE MAS lo usa todavia: incluirlo no cambia nada de quien no llame a cshNf*.
// Una lista ORDENADA de servidores por dato; se prueba uno tras otro y el primero que contesta BIEN gana.
//   · «Contestar mal» = HTTP 5xx o 4xx, tiempo agotado, sin conexion, una pagina HTML (Cloudflare, una pasarela caida),
//     un VOTable de error con HTTP 200, o un cuerpo vacio o que no es lo esperado (`check` de cada servidor).
//   · CORTACIRCUITOS por servidor dentro de la sesion: un servidor que dio 5xx, tiempo agotado o sin conexion queda
//     «abierto» CSH_NF.OPEN_MS y las peticiones siguientes no esperan su plazo (se salta y se dice). `cshNfResetBreakers()`
//     lo cierra («Retry»). `spec.breaker: false` no lo mira ni lo abre.
//   · CACHE EN DISCO en %LOCALAPPDATA%\CabraScripts\cache\<CSH_NF_CACHE_SUB>\ (csh_net.js `cshCacheRoot`; no %TEMP%, que
//     Windows limpia), con clave = huella de la consulta LOGICA (no de la URL: la misma consulta a otro servidor reutiliza la
//     copia). Se usa como ULTIMO RECURSO (cache: "last") y la respuesta lo dice («from cache (fecha)»); "first" para datos
//     fijos; "none" sin cache.
// La llamada de red es la COMUN (csh_net.js: `cshCurlRun`, con su bombeo de la interfaz y el corte al cerrar); aqui se
// añade -L (redirecciones) y el plazo de conexion.
// COSTURAS DE PRUEBA: CSH_NF_HOOK(url, opts) -> { ok, code, text, timeout } en vez de curl; CP_SF_HTTP_HOOK (todo GET) sigue
// valiendo; y CSH_NF_KIND_HOOK_GET() -> function(kind, url) | null, el gancho por clase de dato (CabraStars: CS_LAYER_HOOK).
// ES5 (lo prueba node: CabraStars/tests/cs_test_netfail.js, con File y getEnvironmentVariable de mentira).
// ============================================================================

var CSH_NF = { OPEN_MS: 10 * 60 * 1000, TIMEOUT_S: 25, CONNECT_S: 8, CONNECT_HEDGE_S: 5, MAX_REDIRS: 4 };
var CSH_NF_HOOK = null;
var CSH_NF_CACHE_DIR = null;            // pruebas: otra carpeta (con la barra final)
var CSH_NF_BREAKER = {};                // servidor (host + primer tramo de la ruta) -> { until, net }
var CSH_NF_CLOCK = function() { return Date.now(); };
var CSH_NF_TRACE = null;                // pruebas: un array donde se apunta cada intento
var CSH_NF_CACHE_SUB = "net";          // la subcarpeta de la cache (CabraStars: "cabrastars", la de siempre)
var CSH_NF_KIND_HOOK_GET = null;       // pruebas: function() -> el gancho por clase de dato (function(kind, url)) o null
function cshNfKindHook() {
   if (typeof CSH_NF_KIND_HOOK_GET !== "function") return null;
   try { var h = CSH_NF_KIND_HOOK_GET(); return (typeof h === "function") ? h : null; } catch (e) { return null; }
}
// los nombres que se dicen en la interfaz (los de CabraShared, mas los respaldos)
var CSH_NF_NAMES = [["vizier.cfa.harvard.edu", "VizieR (CfA mirror)"], ["vizier.nao.ac.jp", "VizieR (NAO Japan mirror)"], ["vizier.idia.ac.za", "VizieR (IDIA mirror)"],
                   ["tapvizier", "VizieR (CDS)"], ["vizier.cds", "VizieR (CDS)"], ["gaia.ari.uni-heidelberg.de", "Gaia archive (ARI Heidelberg)"], ["gea.esac.esa.int", "ESA Gaia archive"],
                   ["vsx.aavso.org", "AAVSO VSX"], ["voparis-tap-planeto", "exoplanet.eu (Paris Observatory)"], ["exoplanetarchive", "NASA Exoplanet Archive"],
                   ["stev.oapd", "PARSEC (Padova)"], ["irsa.ipac", "IRSA (Caltech)"], ["zenodo", "Zenodo (CERN)"],
                    ["dc.g-vo.org", "GAVO (Heidelberg)"]];

function cshNfHost(url) { var m = /^[a-z]+:[/][/]([^/:?]+)/i.exec(String(url || "")); return m ? m[1].toLowerCase() : ""; }
// El «servidor» del cortacircuitos: host + primer tramo de la ruta (el TAP y el servicio de datos de ESA caen por separado)
function cshNfServerKey(url) { var m = /^[a-z]+:[/][/]([^/:?]+)(?::\d+)?([/][^/?]*)?/i.exec(String(url || "")); return m ? (m[1] + (m[2] || "")).toLowerCase() : String(url || ""); }
function cshNfName(url) {
   var h = cshNfHost(url);
   for (var i = 0; i < CSH_NF_NAMES.length; ++i) if (h.indexOf(CSH_NF_NAMES[i][0]) >= 0) return CSH_NF_NAMES[i][1];
   return (typeof cshNetServer === "function") ? cshNetServer(url) : (h || "?");
}

// ---------------------------------------------------------------------------
// UNA peticion (GET, o POST con `o.post` = cuerpo). { ok, code, text, ms, cut, aborted }
// ---------------------------------------------------------------------------
function cshNfGet(url, o) {
   o = o || {};
   var out = { ok: false, code: 0, text: "", ms: 0, cut: false, aborted: false }, t0 = Date.now(), limitS = (o.timeoutS > 0) ? o.timeoutS : CSH_NF.TIMEOUT_S;
   function fromHook(h) {
      h = h || {};
      out.ok = (h.ok === true); out.code = (typeof h.code === "number") ? h.code : (out.ok ? 200 : 0); out.text = String(h.text || ""); out.cut = (h.timeout === true);
      out.ms = (h.ms > 0) ? h.ms : (Date.now() - t0);
      return out;
   }
   if (typeof CSH_NF_HOOK === "function") return fromHook(CSH_NF_HOOK(url, o));
   var kh = o.kind ? cshNfKindHook() : null;
   if (kh) { var lh = kh(o.kind, url); if (lh) return fromHook(lh); }
   if (typeof CP_SF_HTTP_HOOK === "function" && !o.post) { var r0 = cpSfHttpTextRaw(url, { timeoutS: limitS, onProgress: o.onProgress }); out.ok = r0.ok; out.code = r0.code; out.text = r0.text; out.cut = r0.cut === true; out.ms = r0.ms; return out; }
   if (typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) { out.aborted = true; return out; }
   var A = cshNfArgs(url, o);
   if (!A) return out;
   var c = cshCurlRun(A.args, { timeoutS: A.limitS, onTick: (typeof o.onProgress === "function") ? function(ms) { o.onProgress(ms); } : null });
   return cshNfGetFinish(c, A, t0);
}
// (29-oct-2026 (noche), el lote comun csh_batch.js) cshNfGet partida: ¿la contesta un gancho o el cierre (sin curl)? · los argumentos de curl ·
// la respuesta a partir de lo que dijo curl. La espera en serie y la del lote hacen la MISMA peticion y la juzgan igual.
function cshNfGetLazy(url, o) {
   o = o || {};
   if (typeof CSH_NF_HOOK === "function") return true;
   if (o.kind && cshNfKindHook() !== null) return true;
   if (typeof CP_SF_HTTP_HOOK === "function" && !o.post) return true;
   if (typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) return true;
   return false;
}
// -> { args (completos, con -o y la URL), tmp, body, limitS } | null (no se pudo escribir el cuerpo del POST)
function cshNfArgs(url, o) {
   o = o || {};
   var limitS = (o.timeoutS > 0) ? o.timeoutS : CSH_NF.TIMEOUT_S, tmp = cshTmpPath("cs_nf", ".txt"), body = "";
   // (30-oct-2026) `hedgeS` (cshNfReqOpts): hay otro servidor detras y este no manda ni un byte en esos segundos: al siguiente, con el plazo de conexion corto
   var connS = (o.hedgeS > 0) ? Math.min(CSH_NF.CONNECT_S, CSH_NF.CONNECT_HEDGE_S) : CSH_NF.CONNECT_S;
   var args = ["-L", "--proto", "=https", "--proto-redir", "=https", "--max-redirs", String(CSH_NF.MAX_REDIRS), "--connect-timeout", String(Math.min(connS, limitS)), "-m", String(Math.round(limitS)), "-o", tmp];
   if (o.hedgeS > 0) args = args.concat(["--speed-limit", "1", "--speed-time", String(o.hedgeS)]);
   if (o.post) { body = tmp + ".form"; try { File.writeTextFile(body, String(o.post)); } catch (eB) { return null; } args.push("--data-binary"); args.push("@" + body); }
   args.push(url);
   return { args: args, tmp: tmp, body: body, limitS: limitS };
}
function cshNfGetFinish(c, A, t0) {
   var out = { ok: false, code: 0, text: "", ms: 0, cut: false, aborted: false };
   out.code = c.code; out.cut = c.cut === true; out.aborted = c.aborted === true;
   try { if (File.exists(A.tmp)) { out.text = File.readTextFile(A.tmp); File.remove(A.tmp); } } catch (eR) {}
   try { if (A.body && File.exists(A.body)) File.remove(A.body); } catch (eR2) {}
   out.ok = (!out.cut && !out.aborted && c.exit === 0 && out.code >= 200 && out.code < 300 && out.text.length > 0);
   out.ms = Date.now() - t0;
   return out;
}

// ---------------------------------------------------------------------------
// ¿CONTESTO BIEN? r = la salida de cshNfGet; check = lo que tiene que ser:
//   { csv: "columna" } · { tsv: "columna" } (ASU de VizieR) · { json: "clave" } · { has: "texto" } · function(text) -> bool
// -> { ok, kind: "" | "http" | "timeout" | "offline" | "bad" | "aborted", why, http }
// ---------------------------------------------------------------------------
function cshNfJudge(r, check) {
   var out = { ok: false, kind: "", why: "", http: (r && r.code > 0) ? r.code : 0 };
   if (!r) { out.kind = "offline"; out.why = "no answer"; return out; }
   if (r.aborted) { out.kind = "aborted"; out.why = "aborted"; return out; }
   if (r.cut) { out.kind = "timeout"; out.why = "no answer in time"; return out; }
   if (!(r.code > 0)) { out.kind = "offline"; out.why = "no connection"; return out; }
   if (r.code >= 400) { out.kind = "http"; out.why = "HTTP " + r.code; return out; }
   var text = String(r.text || ""), head = text.substring(0, 600).replace(/^\s+/, ""), low = head.toLowerCase();
   if (text.replace(/\s+/g, "").length === 0) { out.kind = "bad"; out.why = "empty answer"; return out; }
   if (low.indexOf("<!doctype html") === 0 || low.indexOf("<html") >= 0 || low.indexOf("<head") >= 0 || low.indexOf("<body") >= 0) { out.kind = "bad"; out.why = "an HTML page, not data"; return out; }
   if (low.indexOf("<votable") >= 0 || (low.indexOf("<?xml") === 0 && low.indexOf("error") >= 0)) {
      if (/query_status[^>]*error|<info[^>]*error|status="error"/i.test(text.substring(0, 4000)) || !(check && check.xml)) { out.kind = "bad"; out.why = "an error document (VOTable)"; return out; }
   }
   var good = true;
   if (typeof check === "function") { try { good = (check(text) === true); } catch (eC) { good = false; } }
   else if (check && check.csv) good = (head.indexOf("<") < 0 && head.split("\n")[0].indexOf(check.csv) >= 0);
   else if (check && check.tsv) good = cshAsuHeaderOk(text, check.tsv);
   else if (check && check.json) { try { var j = JSON.parse(text); good = !!(j && (check.json === true || j[check.json] !== undefined)); } catch (eJ) { good = false; } }
   else if (check && check.has) good = (text.indexOf(check.has) >= 0);
   if (!good) { out.kind = "bad"; out.why = "not the expected table"; return out; }
   out.ok = true;
   return out;
}
// El «net» de siempre (el que entiende cshNetText de CabraShared) a partir de un juicio
function cshNfNet(url, j) {
   var kind = (j.kind === "http") ? "http" : (j.kind === "timeout") ? "timeout" : (j.kind === "bad") ? "bad" : "offline";
   return { server: cshNfName(url), host: cshNfHost(url), http: j.http || 0, kind: kind, why: j.why };
}

// ---------------------------------------------------------------------------
// EL CORTACIRCUITOS
// ---------------------------------------------------------------------------
// (30-oct-2026) Y EN DISCO (csh_net.js cshHealth*): cada Script > Execute empezaba con el cortacircuitos vacio y volvia a esperar los plazos (medido: la ficha de una estrella en Abell 39,
// CDS 8 s + ESA 20 s antes de que ARI contestara en 0,5 s, en CADA script). Lo que abrio otro script hace menos de CSH_NF.OPEN_MS sigue abierto aqui. Se hidrata al mirarlo.
function cshNfIsOpen(url) {
   var key = cshNfServerKey(url), b = CSH_NF_BREAKER[key];
   if (!b && typeof cshHealthUntil === "function") {
      var u = cshHealthUntil("nf:" + key);
      if (u > 0) b = CSH_NF_BREAKER[key] = { until: u, at: cshHealthAt("nf:" + key), fromDisk: true, net: { server: cshNfName(url), host: cshNfHost(url), http: 0, kind: "timeout" } };
      // (30-oct-2026) lo que el resto de la red ya sabe del CDS: el TAP de VizieR acaba de callar en esta misma tanda. La ficha de una estrella no le paga otros 5 s (medido: Abell 39, CDS caido, 75,5 + 5,6 s)
      else if (key.indexOf("tapvizier.") === 0 && cshHealthUntil("vizier") > 0) b = CSH_NF_BREAKER[key] = { until: cshHealthUntil("vizier"), at: cshHealthAt("vizier"), viaVizier: true, fromDisk: true, net: { server: cshNfName(url), host: cshNfHost(url), http: 0, kind: "timeout" } };
   }
   if (b && b.viaVizier === true && typeof cshHealthUntil === "function" && cshHealthUntil("vizier") <= 0) { delete CSH_NF_BREAKER[key]; return false; }     // (el CDS ha vuelto)
   return !!(b && CSH_NF_CLOCK() < b.until);
}
function cshNfTrip(url, net) {
   CSH_NF_BREAKER[cshNfServerKey(url)] = { until: CSH_NF_CLOCK() + CSH_NF.OPEN_MS, net: net, at: CSH_NF_CLOCK() };
   if (typeof cshHealthMark === "function") cshHealthMark("nf:" + cshNfServerKey(url), net ? net.kind : "", CSH_NF.OPEN_MS / 1000);
}
// («Reintentar» o la red que vuelve: se pregunta otra vez a todos, tambien a los que la memoria del disco saltaria)
function cshNfResetBreakers() {
   CSH_NF_BREAKER = {};
   if (typeof cshHealthClearPrefix === "function") { cshHealthClearPrefix("nf:"); cshHealthClear("vizier"); cshHealthClear("simbad"); cshHealthClear("esa-rvcorr"); }
   if (typeof CSH_VIZIER_DOWN_UNTIL !== "undefined") CSH_VIZIER_DOWN_UNTIL = 0;
   if (typeof CSH_SIMBAD_DOWN_UNTIL !== "undefined") CSH_SIMBAD_DOWN_UNTIL = 0;
}
function cshNfOpenList() { var out = [], now = CSH_NF_CLOCK(); for (var k in CSH_NF_BREAKER) if (CSH_NF_BREAKER[k].until > now) out.push(k); return out; }

// ---------------------------------------------------------------------------
// LA CACHE EN DISCO
// ---------------------------------------------------------------------------
function cshNfEnv(name) { return cshEnv(name); }
function cshNfCacheDir() {
   var d = CSH_NF_CACHE_DIR;
   if (!d) d = cshCacheRoot() + (CSH_NF_CACHE_SUB ? String(CSH_NF_CACHE_SUB).replace(/[^A-Za-z0-9_-]+/g, "_") + "/" : "");
   // (File.createDirectory con la barra final crea Y lanza: CabraBase/pjsr/trampas-del-arnes-pjsr.md)
   try { var nd = d.replace(/[/]+$/, ""); if (!File.directoryExists(nd)) File.createDirectory(nd, true); } catch (e) {}
   return d;
}
// La clave de la cache: la huella comun (csh_net.js `cshHash16`, la misma de CabraStars F1)
function cshNfHash(s) { return cshHash16(s); }
function cshNfCachePath(key) {
   var tag = String(key).split("|")[0].replace(/[^A-Za-z0-9_-]+/g, "_").substring(0, 24);
   return cshNfCacheDir() + (tag ? tag + "_" : "") + cshNfHash(key) + ".json";
}
// (CabraStars F1) Con un gancho de pruebas puesto (la red de mentira) la cache de VERDAD no se lee ni se escribe: una respuesta inventada no
// puede quedar guardada como dato (medido el 22-oct: una prueba dejo «0 variables» falsas en la cache de Nino) ni una copia vieja
// tapar el fallo que la prueba simula. Las pruebas de la cache ponen su propia carpeta (CSH_NF_CACHE_DIR) y entonces si.
function cshNfCacheOn() {
   if (CSH_NF_CACHE_DIR) return true;
   return !(typeof CSH_NF_HOOK === "function" || (typeof CP_SF_HTTP_HOOK !== "undefined" && typeof CP_SF_HTTP_HOOK === "function") || cshNfKindHook() !== null);
}
function cshNfCacheGet(key) {
   if (!cshNfCacheOn()) return null;
   try {
      var p = cshNfCachePath(key);
      if (!File.exists(p)) return null;
      var j = JSON.parse(File.readTextFile(p));
      if (!j || typeof j.text !== "string" || j.key !== String(key)) return null;
      return j;
   } catch (e) { return null; }
}
function cshNfCachePut(key, text, server, url) {
   if (!cshNfCacheOn()) return false;
   try { File.writeTextFile(cshNfCachePath(key), JSON.stringify({ key: String(key), date: (new Date(CSH_NF_CLOCK())).toISOString(), server: server, url: url, text: String(text) })); return true; } catch (e) { return false; }
}
// «2026-10-22» de una fecha ISO (lo que se dice en la interfaz: «from cache (2026-10-22)»)
function cshNfDay(iso) { return String(iso || "").substring(0, 10); }

// ---------------------------------------------------------------------------
// PEDIR UN DATO a su lista de servidores.
// spec = { key (la consulta logica: la clave de la cache), cache: "last" | "first" | "none", breaker (false: sin cortacircuitos),
//          servers: [ { url, check, post, noTrip: [codigos que no abren el cortacircuitos], name } ], timeoutS, onProgress, kind }
// -> { ok, text, server, url, index, fromCache, cacheDate, tried: [ { server, url, kind, why, http, ms, skipped } ],
//      code: "" | "no-network" | "server-error" | "bad-answer" | "aborted", net (el ultimo fallo, para cshNetText) }
// ---------------------------------------------------------------------------
function cshNfFetch(spec) {
   var F = cshNfFetchPlan(spec);
   if (F.done) return F.out;
   for (; F.i < F.list.length; ++F.i) {
      if (cshNfFetchSkip(F)) continue;
      var sv = F.list[F.i];
      if (cshNfFetchStep(F, F.i, cshNfGet(sv.url, cshNfReqOpts(F, F.i))) !== "next") return F.out;
   }
   return cshNfFetchEnd(F);
}
// (30-oct-2026) cshNfFetch con cesion: quien no manda un byte en `hedgeS` segundos cede al siguiente (cshNfReqOpts/cshNfArgs) y el cortacircuitos lo recuerda. La cesion no quita cobertura: si
// al final nadie contesto, a quien se le corto por callado (ni por conexion ni por el plazo entero) se le pregunta otra vez con su plazo entero. El peor caso (todos callados) sube a lo sumo ese plazo.
function cshNfFetchHedged(spec, hedgeS) {
   var S = {}, k; for (k in spec) if (spec.hasOwnProperty(k)) S[k] = spec[k];
   S.hedgeS = hedgeS;
   var f = cshNfFetch(S);
   if (f.ok || f.code === "aborted" || !f.tried || cshNetBrk("nohedge")) return f;
   var limit = ((S.timeoutS > 0) ? S.timeoutS : CSH_NF.TIMEOUT_S) * 1000, again = [], svs = S.servers || [], i, j;
   for (i = 0; i < f.tried.length; ++i) {
      var t = f.tried[i];
      if (t.skipped || t.ms < hedgeS * 1000 - 300 || t.ms >= limit - 300) continue;
      for (j = 0; j < svs.length; ++j) if (svs[j].url === t.url) again.push(svs[j]);
   }
   if (!again.length) return f;
   S.hedgeS = 0; S.breaker = false; S.servers = again;
   return cshNfFetch(S);
}
// (29-oct-2026 (noche), el lote comun csh_batch.js) cshNfFetch partida para que el lote (cshNfFetchMany) recorra la MISMA lista:
//   cshNfFetchPlan(spec) -> F { list, out, i, done (la cache «first» ya contesto) } · cshNfFetchSkip(F) -> true si el cortacircuitos
//   salta el servidor F.i (y lo apunta) · cshNfReqOpts(F, i) · cshNfFetchStep(F, i, r) -> "ok" | "stop" | "next" · cshNfFetchEnd(F) -> out
// (30-oct-2026) LA MEMORIA DEL DISCO NO DEJA SIN PREGUNTAR. Si TODOS los de la lista estan marcados y alguna marca viene de un Execute anterior, se pregunta igual: la memoria sirve para ceder el
// paso a otro, no para quedarse sin respuesta porque hace 8 min fallaran. La primera ronda de cada Execute la paga como antes; lo que falle ahi se recuerda ya en esta sesion, y eso si salta.
function cshNfForgetDiskIfAllOpen(list) {
   if (cshNetBrk("allopenskip")) return;
   var i, keys = [];
   for (i = 0; i < list.length; ++i) { if (!cshNfIsOpen(list[i].url)) return; keys.push(cshNfServerKey(list[i].url)); }
   for (i = 0; i < keys.length; ++i) {
      var b = CSH_NF_BREAKER[keys[i]];
      if (b && b.fromDisk === true) { CSH_NF_BREAKER[keys[i]] = { until: 0, at: 0 }; if (b.viaVizier !== true) cshHealthClear("nf:" + keys[i]); }
   }
}
function cshNfFetchPlan(spec) {
   var S = spec || {}, mode = S.cache || "last", out = { ok: false, text: "", server: "", url: "", index: -1, fromCache: false, cacheDate: "", tried: [], code: "", net: null };
   var key = (S.key !== undefined && S.key !== null) ? String(S.key) : "";
   var F = { S: S, mode: mode, key: key, out: out, list: S.servers || [], i: 0, nOff: 0, nSrv: 0, nBad: 0, nSkip: 0, useBreaker: (S.breaker !== false), done: false };
   if (F.useBreaker && F.list.length > 0) cshNfForgetDiskIfAllOpen(F.list);
   if (mode === "first" && key) {
      var c0 = cshNfCacheGet(key);
      if (c0) { out.ok = true; out.text = c0.text; out.server = c0.server || ""; out.url = c0.url || ""; out.fromCache = true; out.cacheDate = c0.date || ""; out.cacheFirst = true; F.done = true; }
   }
   return F;
}
function cshNfFetchSkip(F) {
   var sv = F.list[F.i], url = sv.url, name = sv.name || cshNfName(url);
   if (!(F.useBreaker && cshNfIsOpen(url))) return false;
   var b = CSH_NF_BREAKER[cshNfServerKey(url)], t = { server: name, url: url, kind: "", why: "", http: 0, ms: 0, skipped: true };
   t.kind = b.net ? b.net.kind : "offline"; t.why = "skipped: it failed " + Math.round((CSH_NF_CLOCK() - b.at) / 1000) + " s ago";
   t.net = b.net || { server: name, host: cshNfHost(url), http: 0, kind: "offline" };
   F.out.tried.push(t); F.out.net = t.net; ++F.nSkip;
   if (t.kind === "offline") ++F.nOff; else ++F.nSrv;
   if (CSH_NF_TRACE) CSH_NF_TRACE.push({ url: url, skipped: true });
   return true;
}
// (30-oct-2026) spec.hedgeS: mientras quede otro servidor vivo detras, este no se espera hasta su plazo si calla (ver cshNfArgs). El ultimo, con su plazo entero.
function cshNfReqOpts(F, i) {
   var sv = F.list[i], hedge = 0;
   if (F.S.hedgeS > 0 && !cshNetBrk("nohedge")) for (var j = i + 1; j < F.list.length && !hedge; ++j) if (!(F.useBreaker && cshNfIsOpen(F.list[j].url))) hedge = F.S.hedgeS;
   return { timeoutS: sv.timeoutS || F.S.timeoutS, onProgress: F.S.onProgress, post: sv.post, kind: F.S.kind, hedgeS: hedge };
}
function cshNfFetchStep(F, i, r) {
   var sv = F.list[i], url = sv.url, name = sv.name || cshNfName(url), out = F.out, t = { server: name, url: url, kind: "", why: "", http: 0, ms: 0, skipped: false };
   var j = cshNfJudge(r, sv.check);
   t.kind = j.kind; t.why = j.why; t.http = j.http; t.ms = r.ms;
   if (CSH_NF_TRACE) CSH_NF_TRACE.push({ url: url, kind: j.kind, http: j.http, ms: r.ms });
   if (j.kind === "aborted") { out.code = "aborted"; out.tried.push(t); return "stop"; }
   if (j.ok) {
      // (30-oct-2026) contesto un marcado (la segunda pasada de cshNfFetchHedged pregunta sin cortacircuitos a quien se le corto por la cesion): deja de estarlo, o la siguiente estrella se quedaria sin el. Rojo: CSH_NET_BREAK=keeptrip
      if (!F.useBreaker && CSH_NF_BREAKER[cshNfServerKey(url)] && !cshNetBrk("keeptrip")) { CSH_NF_BREAKER[cshNfServerKey(url)] = { until: 0, at: 0 }; if (typeof cshHealthClear === "function") cshHealthClear("nf:" + cshNfServerKey(url)); }
      out.ok = true; out.text = r.text; out.server = name; out.url = url; out.index = i; out.tried.push(t);
      if (F.key && F.mode !== "none") cshNfCachePut(F.key, r.text, name, url);
      return "ok";
   }
   t.net = cshNfNet(url, j); t.net.server = name;
   out.tried.push(t); out.net = t.net;
   // (abren el cortacircuitos: el servidor caido —5xx—, el que no contesta a tiempo y el que no se alcanza; un 4xx o una
   // respuesta mala dicen que el servidor VIVE: la consulta no le gusto)
   var trip = (j.kind === "timeout" || j.kind === "offline" || (j.kind === "http" && j.http >= 500 && !(sv.noTrip && sv.noTrip.indexOf(j.http) >= 0)));
   if (trip && F.useBreaker) cshNfTrip(url, t.net);
   if (j.kind === "offline") ++F.nOff; else if (j.kind === "bad") ++F.nBad; else ++F.nSrv;
   return "next";
}
function cshNfFetchEnd(F) {
   var out = F.out;
   // ninguno contesto bien: la cache, como ultimo recurso
   if (F.key && F.mode === "last") {
      var c1 = cshNfCacheGet(F.key);
      if (c1) { out.ok = true; out.text = c1.text; out.server = c1.server || ""; out.url = c1.url || ""; out.fromCache = true; out.cacheDate = c1.date || ""; return out; }
   }
   out.code = (F.nSrv > 0) ? "server-error" : (F.nBad > 0) ? "bad-answer" : "no-network";
   if (F.list.length === 0) out.code = "no-network";
   return out;
}
// Lo que se dice de un intento entero: los servidores que fallaron (con su porque) y, si vino de la cache, de cuando es.
function cshNfText(r) {
   if (!r) return "";
   var bits = [];
   for (var i = 0; i < r.tried.length; ++i) {
      var t = r.tried[i];
      if (t.kind === "" || !t.net) continue;
      bits.push(t.skipped ? format(cshT("%s skipped (it did not answer a moment ago)."), t.server) : cshNetText(t.net));
   }
   if (r.fromCache && !r.cacheFirst) bits.push(format(cshT("Using the copy from cache (%s)."), cshNfDay(r.cacheDate)));
   else if (r.ok && r.index > 0) bits.push(format(cshT("Answered by %s."), r.server));
   return bits.join(" ");
}
// La fuente de un dato, para decirla: «VizieR (CDS)» · «ESA Gaia archive» · «from cache (2026-10-22)»
function cshNfSourceText(r) {
   if (!r || !r.ok) return "";
   return r.fromCache ? format(cshT("from cache (%s)"), cshNfDay(r.cacheDate)) : r.server;
}

// ---------------------------------------------------------------------------
// LA TABLA ASU de VizieR (asu-tsv: comentarios «#», cabecera, unidades, guiones y datos separados por tabuladores)
// ---------------------------------------------------------------------------
function cshAsuLines(text) {
   var L = String(text || "").split("\n"), out = [];
   for (var i = 0; i < L.length; ++i) { var s = L[i].replace(/\r$/, ""); if (s.length === 0 || s.charAt(0) === "#") continue; out.push(s); }
   return out;
}
function cshAsuHeaderOk(text, col) { var L = cshAsuLines(text); return L.length >= 1 && L[0].indexOf("<") < 0 && L[0].split("\t").map(function(c) { return c.replace(/^\s+|\s+$/g, ""); }).indexOf(col) >= 0; }
function cshAsuParse(text) {
   var L = cshAsuLines(text), out = { cols: [], rows: [] }, i;
   if (!L.length) return out;
   out.cols = L[0].split("\t").map(function(c) { return c.replace(/^\s+|\s+$/g, ""); });
   for (i = 1; i < L.length; ++i) {
      if (/^[-\t ]+$/.test(L[i])) continue;                                     // la fila de guiones
      var cells = L[i].split("\t");
      if (i === 1 && !/[0-9]/.test(L[i].replace(/deg|mag|AU|d\b/g, ""))) continue;   // la fila de unidades
      var row = {};
      for (var c = 0; c < out.cols.length; ++c) row[out.cols[c]] = (c < cells.length) ? cells[c].replace(/^\s+|\s+$/g, "") : "";
      out.rows.push(row);
   }
   return out;
}
// Una columna de una fila con varios nombres posibles (VizieR o el archivo de Gaia)
function cshNfCol(row, names) { for (var i = 0; i < names.length; ++i) if (row[names[i]] !== undefined && row[names[i]] !== "") return row[names[i]]; return undefined; }

// ---------------------------------------------------------------------------
// EN PARALELO: lanzar una peticion sin esperar y recogerla despues (B9: IRSA mientras VizieR contesta).
// ---------------------------------------------------------------------------
function cshNfStart(url, o) {
   o = o || {};
   var h = { url: url, proc: null, tmp: "", t0: Date.now(), limitS: (o.timeoutS > 0) ? o.timeoutS : CSH_NF.TIMEOUT_S, done: null, kind: o.kind };
   if (typeof CSH_NF_HOOK === "function" || typeof CP_SF_HTTP_HOOK === "function" || (o.kind && cshNfKindHook() !== null) || cshNfIsOpen(url)) return h;   // (sin proceso: se pide al recoger)
   try {
      h.tmp = cshTmpPath("cs_nf_par", ".txt");
      h.proc = new ExternalProcess;
      h.proc.start(CSH_CURL, ["-s", "-S", "-w", "%{http_code}", "-L", "--proto", "=https", "--proto-redir", "=https", "--max-redirs", String(CSH_NF.MAX_REDIRS), "--connect-timeout", String(CSH_NF.CONNECT_S), "-m", String(Math.round(h.limitS)), "-o", h.tmp, url]);
   } catch (e) { h.proc = null; }
   return h;
}
function cshNfFinish(h) {
   if (!h.proc) return cshNfGet(h.url, { timeoutS: h.limitS, kind: h.kind });
   var out = { ok: false, code: 0, text: "", ms: 0, cut: false, aborted: false }, pump = (typeof CSH_NET_PUMP === "function");
   for (;;) {
      var busy = false;
      try { busy = (h.proc.isRunning === true || h.proc.isStarting === true); } catch (eB) {}
      if (!busy) break;
      try { h.proc.waitForFinished(pump ? 5 : 100); } catch (eW) {}
      if ((typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) || (pump && CSH_NET_PUMP() === true)) { out.aborted = true; try { h.proc.kill(); } catch (eK) {} break; }
      if (Date.now() - h.t0 > (h.limitS + 3) * 1000) { out.cut = true; try { h.proc.kill(); } catch (eK2) {} break; }
   }
   var said = ""; try { said = h.proc.stdout.utf8ToString(); } catch (eO) {}
   var m = /(\d{3})\s*$/.exec(said); out.code = m ? parseInt(m[1], 10) : 0;
   var ex = -1; try { ex = h.proc.exitCode; } catch (eX) {}
   try { if (File.exists(h.tmp)) { out.text = File.readTextFile(h.tmp); File.remove(h.tmp); } } catch (eR) {}
   out.ok = (!out.cut && !out.aborted && ex === 0 && out.code >= 200 && out.code < 300 && out.text.length > 0);
   out.ms = Date.now() - h.t0;
   return out;
}
#endif
