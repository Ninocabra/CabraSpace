// ============================================================================
// CabraShared/csh_net.js — LA RED: curl con tope, señal de vida y corte al cerrar; y el PORQUE de cada fallo
// ----------------------------------------------------------------------------
// UNA implementacion para los cuatro scripts (15-oct-2026). Antes habia tres esperas de curl casi iguales:
// CabraStars `cpSfHttpTextRaw` (GET, bombeo de la interfaz), Cabra3D `c3CurlRanges` (rangos HTTP del polvo) y
// CabraComposition `ccHttpTapOnce` (POST a TAP con la consulta en un fichero). Las tres esperan igual:
//   `cshCurlRun( args, o )` — lanza curl, espera en vueltas cortas, bombea la interfaz (CSH_NET_PUMP), corta al cerrar
//   (CSH_ABORT o lo que diga `o.abort()`), corta al pasar el tope, y devuelve el codigo HTTP y la salida de curl.
// Y una sola forma de decir por que fallo (encargo de Nino, 15-oct: un fallo de red NUNCA sale como «no hay nada»):
//   `cshNetFail( url, r, cut )` -> { server, host, http, kind: "http" | "timeout" | "offline" | "bad" }
//   `cshNetText( n )`           -> «VizieR (CDS) did not answer: HTTP 503 — the server is down or overloaded.»
// NetworkTransfer solo si no hay curl: no deja cortar una respuesta lenta (CabraBase/pjsr/networktransfer-plazos-y-502.md).
// ES5. Sin «barra barra» en las expresiones regulares (el preprocesador de PJSR lo toma por comentario).
// ============================================================================

// (3-nov-2026, CPD C10) EL SISTEMA Y EL curl DE CADA SISTEMA. Antes: "C:/Windows/System32/curl.exe" fijo (en macOS y Linux no habia red por
// curl). Ahora por CoreApplication.platform (MEDIDO en 1.9.6, tests/c3_cpd_probe.log: «Windows»; en macOS «MacOSX», en Linux «Linux», S):
//   Windows  -> %SystemRoot%/System32/curl.exe (el de Windows 10/11)
//   macOS    -> /usr/bin/curl (viene con el sistema)
//   Linux    -> /usr/bin/curl, si no /bin/curl o /usr/local/bin/curl (el primero que exista)
// Si no existe ninguno, CSH_CURL = "" y cshHasCurl() es false: los caminos que tienen NetworkTransfer lo usan. Fuera de PixInsight
// (node, en las pruebas) no hay CoreApplication ni File: queda la ruta de Windows de siempre, que es lo que las pruebas esperan.
// API COMUN (lo puede usar cualquier script en lugar de su propia ruta fija, p. ej. CC_CURL de StellarChemistry): cshPlatform(), cshCurlPath(platform, exists).
// COSTURA ROJA (pruebas): CSH_NET_BREAK=fixedcurl -> la ruta de Windows en cualquier sistema (como antes del 3-nov).
function cshPlatform() {
   try { if (typeof CoreApplication !== "undefined" && CoreApplication.platform) { var p = String(CoreApplication.platform); return /mac|darwin|osx/i.test(p) ? "macos" : /linux|freebsd|unix/i.test(p) ? "linux" : /win/i.test(p) ? "windows" : p.toLowerCase(); } } catch (e) {}
   return "windows";
}
function cshCurlPath(platform, exists) {
   var pf = platform || cshPlatform(), has = (typeof exists === "function") ? exists : function(p) { try { return (typeof File !== "undefined") ? File.exists(p) : true; } catch (e) { return false; } };
   var brk = false; try { brk = (typeof cshNetBrk === "function") && cshNetBrk("fixedcurl"); } catch (eB) {}
   if (brk || pf === "windows") {
      var root = ""; try { root = (typeof cshEnv === "function") ? cshEnv("SystemRoot") : ""; } catch (eR) {}
      var w = ((root.length > 0 && !brk) ? root.split("\\").join("/") : "C:/Windows") + "/System32/curl.exe";
      return (brk || has(w)) ? w : "";
   }
   var c = (pf === "macos") ? ["/usr/bin/curl"] : ["/usr/bin/curl", "/bin/curl", "/usr/local/bin/curl"];
   for (var i = 0; i < c.length; ++i) if (has(c[i])) return c[i];
   return "";
}
var CSH_CURL = "C:/Windows/System32/curl.exe";
try { if (typeof CoreApplication !== "undefined" && typeof File !== "undefined") CSH_CURL = cshCurlPath(); } catch (eCurl) {}
// La interfaz pone aqui una funcion que bombea sus eventos mientras se espera a la red; si DEVUELVE true (el dialogo
// se esta cerrando), la espera mata curl y vuelve.
var CSH_NET_PUMP = null;
var CSH_NET_PUMP_WAIT_MS = 5;
// Cerrando: toda espera en curso se corta y no se lanza ninguna mas (lo ponen los cierres de csh_close.js).
var CSH_ABORT = false;
// ATENDER LA INTERFAZ (24-oct-2026): `processEvents()` suelto es OBSOLETO en PixInsight 1.9.5 y cada uso saca en la consola
// «** Warning: processEvents() is deprecated: Use CoreApplication.processEvents() instead.». La forma vigente es
// CoreApplication.processEvents(); la suelta queda solo de respaldo si el host no tuviera la nueva (medido en sonda: ambas existen
// en 1.9.5 y solo la suelta avisa). Ficha: CabraBase/pjsr/pjsr-apis-verificadas.md.
function cshProcessEvents() {
   if (CSH_PAINTING > 0) return;                                  // (con un pintado abierto, no: ver CSH_PAINTING)
   if (typeof CoreApplication !== "undefined" && typeof CoreApplication.processEvents === "function") { CoreApplication.processEvents(); return; }   // (sin try: lo que lance, lo ve quien llama, como antes)
   if (typeof processEvents === "function") processEvents();
}
// LOS BUCLES LARGOS TAMBIEN ATIENDEN LA INTERFAZ (Cabra3D, 22-oct-2026): leer y casar la respuesta de VizieR de las Pleyades
// (20 000 filas contra 90 000 estrellas) eran 0,5-0,8 s de interfaz parada justo al llegar. `cshYield()` va dentro de esos
// bucles: si quien llama ha puesto CSH_NET_PUMP (Cabra3D mientras un paso de red; CabraStarAnalysis en su cola), bombea como
// mucho cada CSH_YIELD_MS; si no, no hace nada (los demas scripts, como siempre). Si el bombeo dice «cerrando», lanza: el
// bucle no sigue sobre una ventana que se va. CSH_YIELD_ON = false: sin bombear (el control en rojo de c3_perf).
var CSH_YIELD_ON = true, CSH_YIELD_MS = 40, CSH_YIELD_LAST = 0;      // (40 ms de trabajo + ~30 de un dibujo: huecos de ~70 ms y el trabajo a ~60 %)
var CSH_YIELD_IN = false;              // (lo que se pinta DENTRO de un bombeo no vuelve a bombear: sin reentrar en el pintado)
// NUNCA SE BOMBEA CON UN PINTADO ABIERTO (Cabra3D, 26-oct-2026; tests/c3_paint_crash.js). El onPaint de la foto de Cabra3D mide en su primer
// pintado el desfase local foto − Gaia (cshDepthSeeing, con cshYield dentro); con la red en vivo (CSH_NET_PUMP puesto) eso atendia eventos
// DENTRO del onPaint, Qt pintaba otro control de la misma ventana (el mismo motor de pintado: el backing store) y al acabar dejaba al
// pintor de fuera SIN ESTADO: «C0000005 … QRasterPaintEngine::renderHintsChanged / QTransform::type» en la siguiente orden de dibujo.
// Quien abre un Graphics sobre un control en su onPaint sube CSH_PAINTING mientras pinta; con el > 0 ni cshYield ni cshProcessEvents
// ni la espera de curl bombean (el trabajo sigue, solo sin atender la interfaz durante ese pintado).
var CSH_PAINTING = 0;
function cshYield() {
   if (CSH_YIELD_ON !== true || CSH_YIELD_IN === true || CSH_PAINTING > 0 || typeof CSH_NET_PUMP !== "function") return;
   var t = Date.now();
   if (t - CSH_YIELD_LAST < CSH_YIELD_MS) return;
   var stop = false;
   CSH_YIELD_IN = true;
   try { stop = (CSH_NET_PUMP() === true); } catch (e) {} finally { CSH_YIELD_IN = false; }
   CSH_YIELD_LAST = Date.now();
   if (stop || CSH_ABORT === true) throw new Error("cancelled: the window is closing");
}

function cshTmpPath(prefix, ext) {
   return String(File.systemTempDirectory).split("\\").join("/") + "/" + prefix + "_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + (ext || "");
}

// (F2, 22-oct-2026) LA CARPETA DE CACHE COMUN: %LOCALAPPDATA%\CabraScripts\cache\ (con la barra final). No %TEMP%: Windows
// la limpia. La usan el polvo y las caches de Cabra3D (csh_dust.js `c3CacheDir`) y los catalogos con respaldo
// (csh_netfail.js, en su subcarpeta). Se crea si no existe. CSH_CACHE_ROOT (pruebas): otra carpeta.
var CSH_CACHE_ROOT = null;
// (22-oct, tarde, Cabra3D: la global `getEnvironmentVariable` esta obsoleta en PixInsight 1.9 —aviso en la consola, Cabra3D
// tests/c3_blockA_repro.js A5—: primero System.getEnvironmentVariable; la global solo si no existe, p. ej. en node)
function cshEnv(name) { try { return String(((typeof System !== "undefined" && typeof System.getEnvironmentVariable === "function") ? System.getEnvironmentVariable(name) : getEnvironmentVariable(name)) || ""); } catch (e) { return ""; } }
// (3-nov-2026, CPD C10) LA CARPETA DE CADA SISTEMA (antes, en macOS y Linux caia en ~/AppData/Local, que no es de esos sistemas):
//   Windows  %LOCALAPPDATA%\CabraScripts\cache\          (si falta la variable: <home>/AppData/Local/CabraScripts/cache/)
//   macOS    ~/Library/Caches/CabraScripts/cache/
//   Linux    $XDG_CACHE_HOME/CabraScripts/cache/          (si no esta definida: ~/.cache/CabraScripts/cache/)
// (File.systemCacheDirectory existe en 1.9.6 pero en Windows es %TEMP% —MEDIDO, tests/c3_cpd_probe.log—, que Windows limpia: no se usa.)
// cshCacheRootFor(platform, env(name), home) es la parte pura (la prueban node y c3_cpd); CSH_CACHE_ROOT (pruebas) manda sobre todo.
function cshCacheRootFor(platform, env, home) {
   var h = String(home || "").split("\\").join("/").replace(/[/]+$/, "");
   if (platform === "macos") return h + "/Library/Caches/CabraScripts/cache/";
   if (platform === "linux") { var x = String(env("XDG_CACHE_HOME") || "").split("\\").join("/").replace(/[/]+$/, ""); return (x.length > 0 ? x : h + "/.cache") + "/CabraScripts/cache/"; }
   var la = String(env("LOCALAPPDATA") || "").split("\\").join("/").replace(/[/]+$/, "");
   return (la.length > 0 ? la : h + "/AppData/Local") + "/CabraScripts/cache/";
}
function cshCacheRoot() {
   var d = CSH_CACHE_ROOT;
   if (!d) {
      var home = ""; try { home = String(File.homeDirectory); } catch (eH) {}
      d = cshCacheRootFor(cshPlatform(), cshEnv, home);
   }
   d = String(d).split("\\").join("/").replace(/[/]*$/, "/");
   // (File.createDirectory con la barra final crea Y lanza: CabraBase/pjsr/trampas-del-arnes-pjsr.md)
   try { var nd = d.replace(/[/]+$/, ""); if (!File.directoryExists(nd)) File.createDirectory(nd, true); } catch (e) {}
   return d;
}
// Huella de un texto: FNV-1a de 32 bits en dos pasadas con semillas distintas -> 16 cifras hexadecimales. (La MISMA que
// `csNfHash` de CabraStars F1: las claves de su cache en disco no cambian.)
function cshHash16(s) {
   s = String(s);
   function fnv(seed) { var h = seed >>> 0; for (var i = 0; i < s.length; ++i) { h ^= s.charCodeAt(i); h = Math.imul ? Math.imul(h, 16777619) >>> 0 : ((h * 16777619) % 4294967296) >>> 0; } return ("0000000" + h.toString(16)).slice(-8); }
   return fnv(2166136261) + fnv(84696351);
}

// ---------------------------------------------------------------------------
// (3-nov-2026, CPD C6) LA HUELLA DE LO DESCARGADO Y DE LA CACHE: una funcion comun para todos los scripts.
// PJSR 1.9.6 trae CryptographicHash (MEDIDO, tests/c3_cpd_probe.log): new CryptographicHash(CryptographicHash.SHA256).hash(ByteArray)
// -> ByteArray; el SHA-256 de «abc» dio ba7816bf…f20015ad, el vector de FIPS 180-2. Se usa SHA-256 sobre los bytes UTF-8 del texto
// (new ByteArray(texto)). Fuera de PixInsight (node, en las pruebas) no existe: se usa la huella FNV de 64 bits de cshHash16 y se dice
// en `alg` ("fnv64"); un fichero sellado con un algoritmo que aqui no hay NO se da por bueno.
//   cshSum(text [, alg])               -> { alg: "sha256" | "fnv64", sum: hex, bytes }
//   cshCacheSave(path, text, meta)     -> true | false. Escribe «CSHSUM {alg,sum,bytes,meta}\n» + el texto.
//   cshCacheLoad(path, o)              -> { ok, text, meta, why: "" | "missing" | "legacy" | "integrity" | "read", legacy }
//        Si la huella o el tamaño no cuadran, BORRA el fichero (se volvera a bajar) y devuelve ok = false, why = "integrity".
//        Un fichero de antes del 3-nov (sin sello) solo vale con o.legacy = true (y se dice: legacy = true); quien lo acepta lo vuelve a guardar sellado.
//        o.expect = { bytes, sha256 }: ademas, el tamaño y la huella conocidos de antemano (p. ej. los de un catalogo publicado).
// Lo usan c3CacheRead/Write (csh_dust.js: polvo, nombres de SIMBAD, RV, Teff…), la cache de respuestas TAP (cshHttpCache*) y los
// datos de terceros que se bajan la primera vez (csh_thirdparty.js). Cualquier otra cache de un script (la TAP de StellarChemistry,
// la de PARSEC de StellarPopulations) puede usar cshCacheSave/cshCacheLoad tal cual.
// COSTURA ROJA: CSH_NET_BREAK=nosum -> cshCacheLoad no comprueba la huella (como antes del 3-nov: lo que haya en disco se da por bueno).
var CSH_SUM_TAG = "CSHSUM ";
function cshSumAlgs() { return (typeof CryptographicHash !== "undefined" && typeof ByteArray !== "undefined") ? ["sha256", "fnv64"] : ["fnv64"]; }
function cshSum(text, alg) {
   var s = String(text), a = alg || cshSumAlgs()[0];
   if (a === "sha256") {
      if (cshSumAlgs()[0] !== "sha256") return null;
      var ba = new ByteArray(s);
      return { alg: "sha256", sum: String(new CryptographicHash(CryptographicHash.SHA256).hash(ba).toHex()).toLowerCase(), bytes: ba.length };
   }
   if (a === "fnv64") {
      var n = 0; try { n = (typeof ByteArray !== "undefined") ? new ByteArray(s).length : (typeof Buffer !== "undefined" ? Buffer.byteLength(s, "utf8") : s.length); } catch (eN) { n = s.length; }
      return { alg: "fnv64", sum: cshHash16(s), bytes: n };
   }
   return null;
}
function cshCacheSave(path, text, meta) {
   try {
      var h = cshSum(text);
      if (meta !== undefined) h.meta = meta;
      File.writeTextFile(path, CSH_SUM_TAG + JSON.stringify(h) + "\n" + String(text));
      return true;
   } catch (e) { return false; }
}
function cshCacheLoad(path, o) {
   o = o || {};
   var out = { ok: false, text: "", meta: null, why: "", legacy: false };
   var t = null;
   try { if (!File.exists(path)) { out.why = "missing"; return out; } t = String(File.readTextFile(path)); } catch (e) { out.why = "read"; return out; }
   function bad(why) { out.why = why; try { File.remove(path); } catch (eR) {} return out; }
   if (t.indexOf(CSH_SUM_TAG) !== 0) {
      if (o.legacy !== true) return bad("legacy");
      if (o.expect && !cshSumExpect(t, o.expect)) return bad("integrity");
      out.ok = true; out.legacy = true; out.text = t; return out;
   }
   var nl = t.indexOf("\n"), h = null;
   if (nl < 0) return bad("integrity");
   try { h = JSON.parse(t.substring(CSH_SUM_TAG.length, nl)); } catch (eJ) { return bad("integrity"); }
   var body = t.substring(nl + 1);
   if (!cshNetBrk("nosum")) {
      var c = h ? cshSum(body, h.alg) : null;
      if (!c || c.sum !== String(h.sum) || c.bytes !== h.bytes) return bad("integrity");
      if (o.expect && !cshSumExpect(body, o.expect)) return bad("integrity");
   }
   out.ok = true; out.text = body; out.meta = (h && h.meta !== undefined) ? h.meta : null;
   return out;
}
// ¿cuadra con lo conocido de antemano? expect = { bytes, sha256 } (cualquiera de los dos; sin sha256 en node solo se mira el tamaño)
function cshSumExpect(text, expect) {
   if (!expect) return true;
   var c = cshSum(text, (expect.sha256 && cshSumAlgs()[0] === "sha256") ? "sha256" : "fnv64");
   if (!c) return false;
   if (expect.bytes > 0 && c.bytes !== expect.bytes) return false;
   if (expect.sha256 && c.alg === "sha256" && c.sum !== String(expect.sha256).toLowerCase()) return false;
   return true;
}

// ---------------------------------------------------------------------------
// (30-oct-2026) LA VELOCIDAD DE CARGA (docs/velocidad-carga-30oct.md; Nino: «es muy decepcionante abrir el script y no poder hacer nada durante 3 minutos»).
// MEDIDO en frio con el CDS caido (CabraShared/tests/journey/, 30-oct 10:47-10:56, Abell 39): lo que mas pesa no son los datos (IDIA da 200-1800 kB en 2-4 s)
// sino esperar a quien no contesta, y CADA Script > Execute es un contexto JS nuevo: CSH_VIZIER_DOWN_UNTIL, CSH_SIMBAD_DOWN_UNTIL, CSH_NF_BREAKER y CC_CDS mueren al
// cerrar la ventana y la siguiente vuelve a pagarlo todo. Dos memorias EN DISCO, en la carpeta de cache comun, que valen para los cuatro scripts:
//   1. net_health.json: quien no contesto (el CDS de VizieR y de SIMBAD, los servidores del cortacircuitos, el espejo callado para una tabla), con caducidad
//      (30 min por defecto). NO deja a nadie sin servidor: al «caido» se le pregunta el ultimo, o cuando caduca.
//   2. http/ (cshHttpCache*): las respuestas buenas de los TAP de catalogos fijos (VizieR, SIMBAD, ESA, GAVO), 30 dias: abrir otra vez la misma imagen (o la misma
//      imagen en otro script) no pregunta nada.
// SOLO con CSH_NET_LIVE (cshNetLiveOn(): la llaman los main de los scripts y las sondas de tiempos): una prueba, con su red de mentira, no lee ni deja huella.
// COSTURAS ROJAS (CSH_NET_BREAK, variable o entorno, separadas por comas): nohealth (memoria solo de la sesion) · noshortconn (10 s de conexion y reintento, como
// antes) · nohttpcache (sin la cache de respuestas).
// ---------------------------------------------------------------------------
var CSH_NET_LIVE = false;
var CSH_NET_BREAK = "";
function cshNetLiveOn() { CSH_NET_LIVE = true; }
function cshNetBrk(name) { return ("," + String(CSH_NET_BREAK || "") + "," + "" + ",").indexOf("," + name + ",") >= 0; }

// ---------------------------------------------------------------------------
// LA VELOCIDAD RADIAL DE GAIA DR3, CORREGIDA: UNA receta para todos los scripts (30-oct-2026; decision D de Nino, revision de Codex D1-H4)
// ---------------------------------------------------------------------------
// radial_velocity de DR3 NO lleva dos correcciones que publican sus autores. Vivian solo en Cabra3D (tm/timemachine_run.js, c3TmRvBias); aqui, para que la misma estrella de la misma RV en todos.
//   · Katz et al. 2023, A&A 674, A5, Ec. 5 (rv_template_teff < 8500 K): grvs_mag < 11 -> 0; si no, 0,02755·grvs² − 0,55863·grvs + 2,81129 km/s.
//   · Blomme et al. 2023, A&A 674, A7, Ec. 1 (8500 ≤ rv_template_teff ≤ 14500 K y 6 ≤ grvs_mag ≤ 12): 7,98 − 1,135·grvs_mag km/s. Fuera de esos intervalos, sin correccion.
//   Lo que devuelve cshRvBias es lo que hay que RESTAR a la RV del catalogo. Sin grvs_mag o sin plantilla: null (no se estima).
// DE DONDE SALEN LAS DOS COLUMNAS: MEDIDO el 30-oct en el espejo de IDIA y en ARI (el dia que CDS, CfA, NAO y ESA estaban callados): I/355/gaiadr3 las trae como GRVSmag y RVtempTeff, con el mismo valor que
// grvs_mag y rv_template_teff de gaiadr3.gaia_source. Por eso van EN LAS CONSULTAS QUE YA SE HACEN (cpSfRefineAdql, ccGaiaAdql, csStarDetailsAdql, c3TmRvAdql) y la correccion no pide ni espera nada mas.
// COSTURA ROJA: CSH_NET_BREAK=norvscols -> las consultas sin las dos columnas (como hasta el 30-oct): las RV salen tal cual del catalogo y `kind` es "no-info".
function cshRvColsOn() { return !cshNetBrk("norvscols"); }
function cshRvColsSql(prefix, sep) { return cshRvColsOn() ? (prefix + "GRVSmag" + sep + prefix + "RVtempTeff" + sep) : ""; }
function cshRvBias(grvs, tteff, noHot) {
   if (grvs === null || grvs === undefined || !isFinite(grvs) || tteff === null || tteff === undefined || !isFinite(tteff)) return null;
   if (tteff >= 8500) {
      if (noHot === true || tteff > 14500 || grvs < 6 || grvs > 12) return 0;
      return 7.98 - 1.135 * grvs;                                                     // Blomme et al. 2023, Ec. 1
   }
   if (grvs < 11) return 0;
   return 0.02755 * grvs * grvs - 0.55863 * grvs + 2.81129;                         // Katz et al. 2023, Ec. 5
}
// -> { v (la que se usa), cat (la del catalogo), kind, bias }. kind: "katz" | "blomme" (corregida) · "none" (la receta dice que a esta no le toca) · "no-info" (sin los datos: sin corregir, y la ficha lo dice).
function cshRvCorrect(rv, grvs, tteff) {
   var b = cshRvBias(grvs, tteff);
   if (b === null) return { v: rv, cat: rv, kind: "no-info", bias: 0 };
   if (b === 0) return { v: rv, cat: rv, kind: "none", bias: 0 };
   return { v: rv - b, cat: rv, kind: (tteff >= 8500) ? "blomme" : "katz", bias: b };
}
// (30 min y no 10: lo que manda es que el medido p1_D, a 12 min del primer fallo, volvia a pagar 5 s de SIMBAD, 5 de CDS y 10 de ESA; y el riesgo es pequeño: los espejos dan los mismos datos y lo que
//  no tienen se le sigue preguntando al CDS al final, que si contesta borra la memoria. El cortacircuitos de la ficha (CSH_NF.OPEN_MS) sigue en 10 min.)
var CSH_HEALTH_TTL_S = 1800;
var CSH_HEALTH_FILE = null;             // pruebas: otro fichero
var CSH_HEALTH = null;                  // lo leido del disco (una vez por ejecucion) mas lo apuntado: clave -> { until, at, why }
function cshHealthOn() { return CSH_NET_LIVE === true && typeof CP_SF_HTTP_HOOK !== "function" && !cshNetBrk("nohealth"); }
function cshHealthPath() { return CSH_HEALTH_FILE || (cshCacheRoot() + "net_health.json"); }
function cshHealthLoad() {
   if (CSH_HEALTH) return CSH_HEALTH;
   CSH_HEALTH = {};
   try {
      var p = cshHealthPath();
      if (File.exists(p)) { var j = JSON.parse(File.readTextFile(p)), now = cshSimbadNow(); for (var k in j) if (j.hasOwnProperty(k) && j[k] && j[k].until > now) CSH_HEALTH[k] = j[k]; }
   } catch (e) {}
   return CSH_HEALTH;
}
function cshHealthSave() { try { File.writeTextFile(cshHealthPath(), JSON.stringify(CSH_HEALTH || {})); } catch (e) {} }
// -> hasta cuando se da por caido (ms) o 0
function cshHealthUntil(key) { if (!cshHealthOn()) return 0; var e = cshHealthLoad()[key]; return (e && e.until > cshSimbadNow()) ? e.until : 0; }
function cshHealthAt(key) { if (!cshHealthOn()) return 0; var e = cshHealthLoad()[key]; return e ? e.at : 0; }
function cshHealthMark(key, why, ttlS) {
   if (!cshHealthOn()) return;
   var now = cshSimbadNow(), h = cshHealthLoad();
   h[key] = { until: now + ((ttlS > 0) ? ttlS : CSH_HEALTH_TTL_S) * 1000, at: now, why: String(why || "") };
   cshHealthSave();
}
function cshHealthClear(key) { if (!cshHealthOn()) return; var h = cshHealthLoad(); if (h[key]) { delete h[key]; cshHealthSave(); } }
// las claves vivas con ese prefijo
function cshHealthKeys(prefix) {
   if (!cshHealthOn()) return [];
   var h = cshHealthLoad(), out = [], now = cshSimbadNow();
   for (var k in h) if (h.hasOwnProperty(k) && k.indexOf(prefix) === 0 && h[k].until > now) out.push(k);
   return out;
}
function cshHealthClearPrefix(prefix) {
   if (!cshHealthOn()) return;
   var h = cshHealthLoad(), n = 0;
   for (var k in h) if (h.hasOwnProperty(k) && k.indexOf(prefix) === 0) { delete h[k]; ++n; }
   if (n) cshHealthSave();
}
// EL PLAZO DE CONEXION AL CDS cuando hay a quien mas preguntar. 5 s: una conexion sana al CDS tarda < 0,2 s y con una SYN perdida Windows la repite a los 3 s
// (cc_pixinsight.js CC_CONNECT_DOWN_S, 29-oct). Y SIN reintento de un plazo de conexion agotado (lo que hacia 10 + 1 + 10 = 21 s, medido el 30-oct): un 5xx rapido si se repite.
var CSH_CDS_CONNECT_S = 5;

// LA CACHE DE RESPUESTAS. Clave = la URL entera (la consulta del CDS, sirva quien sirva: el mismo CSV). Solo una tabla con filas, de un TAP de catalogos fijos; nunca un
// fallo, un vacio (un espejo puede contestar 0 filas de paso: Codex R2 H-1) ni una respuesta de prueba. «Reintentar» pregunta lo que fallo, que no esta aqui.
var CSH_HTTP_CACHE_TTL_DAYS = 30;
var CSH_HTTP_CACHE_MAX_MB = 300;        // medido el 30-oct: un campo denso (Pleyades) deja ~10 MB; al pasarse se borran las mas viejas (solo de esta carpeta)
var CSH_HTTP_CACHE_SWEPT = false;
function cshHttpCacheOn(url, o) {
   if (CSH_NET_LIVE !== true || typeof CP_SF_HTTP_HOOK === "function" || cshNetBrk("nohttpcache")) return false;
   if (o && (o.noMirror === true || o.noCache === true)) return false;
   var u = String(url);
   return u.indexOf(CSH_VIZIER_CDS) === 0 || u.indexOf(CSH_SIMBAD_CDS) === 0 || (typeof CSH_ESA_TAP === "string" && u.indexOf(CSH_ESA_TAP) === 0) || (typeof CSH_GAVO_TAP === "string" && u.indexOf(CSH_GAVO_TAP) === 0);
}
function cshHttpCacheDir() {
   var d = cshCacheRoot() + "http";
   try { if (!File.directoryExists(d)) File.createDirectory(d, true); } catch (e) {}
   return d;
}
function cshHttpCacheGet(url, o) {
   if (!cshHttpCacheOn(url, o)) return null;
   try {
      var p = cshHttpCacheDir() + "/" + cshHash16(url) + ".txt";
      if (!File.exists(p)) return null;
      var ld = cshCacheLoad(p);                   // (3-nov, CPD C6) con su huella: si no cuadra (o es de antes, sin sello), se borra y se vuelve a pedir
      if (!ld.ok) return null;
      var t = ld.text, nl = t.indexOf("\n");
      if (nl < 0) return null;
      var h = JSON.parse(t.substring(0, nl));
      if (!h || h.url !== String(url) || cshSimbadNow() - h.at > CSH_HTTP_CACHE_TTL_DAYS * 86400000) return null;
      return { ok: true, code: 200, text: t.substring(nl + 1), ms: 0, message: "", transport: "cache", cut: false, aborted: false, server: h.server || "", fallback: h.fallback === true, attempts: (h.fallback === true) ? [{ server: h.server || "", kind: "ok", http: 200, ms: 0 }] : [], empty: false, cached: true, cacheDate: h.date || "" };     // (attempts: sin él, el afinado decía «VizieR (CDS)» de lo bajado de IDIA: visto en p1_D)
   } catch (e) { return null; }
}
// -> r (para poder envolver la llamada)
function cshHttpCachePut(url, o, r) {
   if (!r || r.ok !== true || r.empty === true || r.cached === true || !cshHttpCacheOn(url, o)) return r;
   try {
      var text = String(r.text || ""), body = text.replace(/\s+$/, "");
      if (!cshSimbadIsTable(text) || body.indexOf("\n") < 0 || text.length > 64000000) return r;      // (solo la cabecera = 0 filas: no se guarda)
      var now = cshSimbadNow(), h = { url: String(url), at: now, date: (new Date(now)).toISOString(), server: r.server || cshNetServer(url), fallback: r.fallback === true };
      cshCacheSave(cshHttpCacheDir() + "/" + cshHash16(url) + ".txt", JSON.stringify(h) + "\n" + text);      // (3-nov, CPD C6) sellado con su huella
      cshHttpCacheSweep();
   } catch (e) {}
   return r;
}
// una vez por ejecucion: fuera lo caducado y, si la carpeta pasa del tope, lo mas viejo. Solo ficheros <huella>.txt de ESTA carpeta (regenerables: se vuelven a pedir).
function cshHttpCacheSweep() {
   if (CSH_HTTP_CACHE_SWEPT) return;
   CSH_HTTP_CACHE_SWEPT = true;
   try {
      var dir = cshHttpCacheDir(), L = [], total = 0, now = Date.now(), ff = new FileFind, i;
      if (ff.begin(dir + "/*.txt")) {
         do { if (ff.isDirectory !== true && /^[0-9a-f]{16}[.]txt$/.test(ff.name)) { var t = 0; try { t = ff.lastModified.getTime(); } catch (eT) {} L.push({ n: ff.name, s: ff.size, t: t }); total += ff.size; } } while (ff.next());
      }
      try { ff.end(); } catch (eE) {}
      L.sort(function(a, b) { return a.t - b.t; });
      var maxB = CSH_HTTP_CACHE_MAX_MB * 1048576, ttl = CSH_HTTP_CACHE_TTL_DAYS * 86400000;
      for (i = 0; i < L.length; ++i) {
         if (!(total > maxB || (L[i].t > 0 && now - L[i].t > ttl))) continue;
         try { File.remove(dir + "/" + L[i].n); total -= L[i].s; } catch (eR) {}
      }
   } catch (e) {}
}

// curl con sus argumentos (sin -w: se añade aqui). o = { timeoutS, waitMs, onTick(ms), tickMs, abort() -> bool, pump: false }
// -> { started, exit, code (HTTP, 0 sin conexion), cut (tope), aborted, ms, said }
function cshCurlRun(args, o) {
   o = o || {};
   var out = { started: false, exit: -1, code: 0, cut: false, aborted: false, ms: 0, said: "" }, t0 = Date.now();
   var limitS = (o.timeoutS > 0) ? o.timeoutS : 25, proc = null;
   var pump = (o.pump !== false && typeof CSH_NET_PUMP === "function");
   // (bombeando, vueltas de CSH_NET_PUMP_WAIT_MS: lo que tarda en atender la interfaz es eso como mucho. Con 15 ms, girar el 3D de
   // Cabra3D durante la red iba a 43 ms entre fotogramas frente a 35 sin red —tests/c3_perf.js, 20-oct-2026—)
   var wait = (o.waitMs > 0) ? o.waitMs : (pump ? CSH_NET_PUMP_WAIT_MS : 100);
   try {
      proc = new ExternalProcess;
      proc.start(CSH_CURL, ["-s", "-S", "-w", "%{http_code}"].concat(args));
      out.started = true;
      var nextTick = 0;
      for (;;) {
         try { proc.waitForFinished(wait); } catch (eW) {}
         var stop = (CSH_ABORT === true);
         if (!stop && pump && CSH_PAINTING === 0) { CSH_YIELD_IN = true; try { stop = (CSH_NET_PUMP() === true); } catch (eQ) {} finally { CSH_YIELD_IN = false; } }
         else if (!stop && typeof o.idle === "function") { try { o.idle(); } catch (eI) {} }
         if (!stop && typeof o.abort === "function") { try { stop = (o.abort() === true); } catch (eA) {} }
         if (stop) { out.aborted = true; try { proc.kill(); } catch (eK2) {} break; }   // (sin esperar: el cierre tiene que ser inmediato)
         var busy = false;
         try { busy = (proc.isRunning === true || proc.isStarting === true); } catch (eB) {}
         if (!busy) break;
         if (typeof o.onTick === "function" && Date.now() >= nextTick) { try { o.onTick(Date.now() - t0); } catch (eT) {} nextTick = Date.now() + ((o.tickMs > 0) ? o.tickMs : 500); }
         if (Date.now() - t0 > (limitS + (o.graceS >= 0 ? o.graceS : 3)) * 1000) {
            out.cut = true;
            try { proc.kill(); } catch (eK) {}
            try { proc.waitForFinished(2000); } catch (eW2) {}
            break;
         }
      }
      try { out.exit = proc.exitCode; } catch (eX) {}
      try { out.said = proc.stdout.utf8ToString(); } catch (eO) { out.said = ""; }
   } catch (e) { out.message = String(e.message || e); }
   var m = /(\d{3})\s*$/.exec(String(out.said));
   out.code = m ? parseInt(m[1], 10) : 0;
   out.ms = Date.now() - t0;
   return out;
}
function cshHasCurl() { try { return (CSH_CURL.length > 0 && File.exists(CSH_CURL)); } catch (e) { return false; } }

// Sin curl: NetworkTransfer (espera lo que el servidor tarde).
function cshNetworkGet(url) {
   var out = { ok: false, code: 0, data: null, message: "" };
   try {
      var nt = new NetworkTransfer, chunks = new ByteArray;
      nt.setURL(url);
      nt.onDownloadDataAvailable = function(data) { chunks.add(data); return true; };
      out.ok = nt.download();
      out.code = nt.responseCode;
      out.data = chunks;
      if (!out.ok) out.message = String(nt.errorInformation || "");
   } catch (e) { out.message = String(e.message || e); }
   return out;
}

// ---------------------------------------------------------------------------
// LA RED QUE FALLA, CON NOMBRE Y CODIGO
// ---------------------------------------------------------------------------
// (27-oct-2026: los respaldos por su nombre y ANTES que «vizier» —el espejo de CfA contiene «vizier» y salia como «VizieR (CDS)»—;
// GAVO salia como «dc.g-vo.org». Los mismos nombres que CSH_NF_NAMES de csh_netfail.js. 28-oct: el espejo de SIMBAD en Harvard,
// la reserva de SIMBAD —cshSimbadGet, mas abajo—, antes que «simbad»: si no, salia como «SIMBAD (CDS)»)
var CSH_NET_SERVERS = [["vizier.cfa.harvard.edu", "VizieR (CfA mirror)"], ["vizier.nao.ac.jp", "VizieR (NAO Japan mirror)"], ["vizier.idia.ac.za", "VizieR (IDIA mirror)"], ["dc.g-vo.org", "GAVO (Heidelberg)"],
                       ["tapvizier", "VizieR (CDS)"], ["vizier", "VizieR (CDS)"], ["simbad.harvard.edu", "SIMBAD (Harvard mirror)"], ["simbad", "SIMBAD (CDS)"], ["gea.esac.esa.int", "ESA Gaia archive"],
                       ["exoplanetarchive", "NASA Exoplanet Archive"], ["stev.oapd", "PARSEC (Padova)"], ["irsa.ipac", "IRSA (Caltech)"], ["zenodo", "Zenodo (CERN)"]];
function cshNetHost(url) { var m = /^[a-z]+:[/][/]([^/:?]+)/i.exec(String(url || "")); return m ? m[1] : ""; }
function cshNetServer(url) { var h = cshNetHost(url); for (var i = 0; i < CSH_NET_SERVERS.length; ++i) if (h.indexOf(CSH_NET_SERVERS[i][0]) >= 0) return CSH_NET_SERVERS[i][1]; return h || "?"; }
// r = la salida de una peticion { code (HTTP, 0 si no hubo conexion) }; cut = tiempo agotado -> por que fallo
function cshNetFail(url, r, cut) {
   var code = (r && r.code > 0) ? r.code : 0;
   var kind = cut ? "timeout" : (code >= 400) ? "http" : (code >= 200 && code < 300) ? "bad" : "offline";
   return { server: cshNetServer(url), host: cshNetHost(url), http: code, kind: kind };
}
// La clase de 4 casillas que usan Cabra3D y CabraComposition: "server" (5xx) · "refused" (4xx) · "timeout" · "offline".
function cshNetKind4(code, message, cut) {
   var c = code | 0, m = String(message || "");
   if (c >= 500) return "server";
   if (c >= 400) return "refused";
   if (cut || /no answer|timed? ?out|exit 28/i.test(m)) return "timeout";
   return "offline";
}
function cshNetText(n) {
   if (!n) return cshT("the service did not answer in time.");
   var why = (n.kind === "http") ? format(cshT("HTTP %d — %s"), n.http, n.http >= 500 ? cshT("the server is down or overloaded") : cshT("the query was refused"))
           : (n.kind === "timeout") ? cshT("no answer in time")
           : (n.kind === "bad") ? cshT("it answered something that is not a table")
           : cshT("no connection (no network, or the server cannot be reached)");
   return format(cshT("%s did not answer: %s."), n.server, why);
}

// ---------------------------------------------------------------------------
// (27-oct-2026) LA LINEA DE LA CONSOLA cuando una peticion falla: corta y legible, sin la URL.
// Antes: «CabraShared: curl exit 0, HTTP 503 · https://tapvizier…/sync?REQUEST=doQueryLANG=ADQLFORMAT=csv…». Los «&» NO se perdian
// antes: se los COME la consola de PixInsight al pintar (interpreta «&…» como entidad; sonda en la 239 el 27-oct con
// Console.beginLog: «a&LANG=b» sale «aLANG=b», «a & b» sale «a  b»; «&amp;» y <raw>…</raw> si llegan). Ahora:
//   «CabraShared: VizieR (CDS) HTTP 503 - I/355/gaiadr3 (RV); trying GAVO (Heidelberg)...»
// (SOLO ASCII: lo capturado con Console.endLog sacaba «—» y «…» como «â»; asi no hay duda de como se ve)
// servidor + motivo + tabla consultada (o.what, o la sacada del ADQL de la URL) + a quien se pide despues (o.next, si quien llama lo
// sabe). Todo lo que va a la consola pasa por cshConsoleEsc. La URL entera solo con CSH_NET_DEBUG = true (escapada).
// ---------------------------------------------------------------------------
var CSH_NET_DEBUG = false;
var CSH_NET_LAST_LINE = "";            // la ultima linea dicha (para las pruebas: lo que se ve sin leer la consola)
function cshConsoleEsc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
// Las tablas de una consulta TAP por URL (FROM / JOIN del ADQL de QUERY=); si no es TAP, el ultimo tramo de la ruta. «» si nada.
function cshNetWhat(url) {
   var u = String(url || ""), m = /[?&]QUERY=([^&]*)/i.exec(u), q = "";
   if (m) { try { q = decodeURIComponent(m[1].replace(/\+/g, " ")); } catch (eD) { q = m[1]; } }
   if (q) {
      var re = /\b(?:FROM|JOIN)\s+("[^"]+"|[A-Za-z0-9_.]+)/gi, t, out = [];
      while ((t = re.exec(q)) !== null) { var nm = t[1].replace(/"/g, ""); if (out.indexOf(nm) < 0) out.push(nm); }
      if (out.length) return out.join(" + ");
   }
   var p = /^[a-z]+:[/][/][^/?]+([^?]*)/i.exec(u), seg = p ? p[1].split("/") : [];
   while (seg.length && !seg[seg.length - 1]) seg.pop();
   return seg.length ? seg[seg.length - 1] : "";
}
// El motivo, corto: «HTTP 503», «no answer in 30 s», «host not found», «connection refused», «no connection», «empty answer».
function cshNetReason(out, c, limitS) {
   var exit = (c && typeof c.exit === "number") ? c.exit : -1, code = (out && out.code > 0) ? out.code : 0;
   if (out && out.aborted) return "stopped";
   // (lo que de verdad se espero: con el plazo de CONEXION —10 s— curl se rinde antes que el -m; medido el 27-oct: 10 s, no 30)
   if ((out && out.cut) || exit === 28) return "no answer in " + Math.round((out && out.ms > 0) ? out.ms / 1000 : (limitS || 0)) + " s";
   if (code >= 300) return "HTTP " + code;
   if (exit === 6) return "host not found (curl 6)";
   if (exit === 7) return "connection refused (curl 7)";
   if (exit > 0) return "no connection (curl " + exit + ")";
   if (code >= 200) return "empty answer (HTTP " + code + ")";
   return "no connection";
}
function cshNetConsoleLine(url, out, o, c, limitS) {
   o = o || {};
   var what = o.what ? String(o.what) : cshNetWhat(url);
   return "CabraShared: " + cshNetServer(url) + " " + cshNetReason(out, c, limitS) + (what ? " - " + what : "") + (o.next ? "; trying " + o.next + "..." : "");
}
function cshNetSay(url, out, o, c, limitS) {
   var line = cshNetConsoleLine(url, out, o, c, limitS);
   CSH_NET_LAST_LINE = line;
   try { console.warningln(cshConsoleEsc(line)); if (CSH_NET_DEBUG === true) console.writeln(cshConsoleEsc("  " + url)); } catch (eL) {}
   return line;
}

// ---------------------------------------------------------------------------
// GET de texto (TAP por URL). El motor del campo de estrellas (csh_starfield_run.js) y las capas lo usan.
// Devuelve { ok, code, text, ms, message, transport, cut, net (si falla) }.
// COSTURA DE PRUEBAS: CP_SF_HTTP_HOOK( url, opts ) -> { ok, code, text, message, timeout } EN VEZ de la red.
// ---------------------------------------------------------------------------
var CP_SF_HTTP_HOOK = null;
var CP_SF_HTTP_TIMEOUT_S = 25;
// (29-oct-2026 (noche)) Quien lleva la cuenta de los fallos de red (Cabra3D, tm/netstatus.js) pone aqui function(url, r): el lote comun (csh_batch.js)
// la llama con cada peticion que hace por su cuenta (las de cpSfHttpText ya las ve quien envuelve cpSfHttpText).
var CSH_HTTP_NOTE = null;
// (F2) Lo que vale cuando la llamada no dice nada de `follow` / `retry` (ver cpSfHttpTextRaw). Por defecto, como antes.
var CSH_HTTP_DEFAULTS = { follow: false, retry: 0 };
function cpSfHttpText(url, opts) {
   // (30-oct-2026) una tabla que ya se pidio (esta sesion, otra, otro script), de la cache de respuestas (arriba, cshHttpCache*)
   var hit = cshHttpCacheGet(url, opts);
   if (hit) return hit;
   return cshHttpCachePut(url, opts, cshHttpTextLive(url, opts));
}
function cshHttpTextLive(url, opts) {
   // (28-oct-2026, B4) UNA PETICION AL TAP DE SIMBAD DEL CDS lleva su reserva —el espejo de Harvard— sin que quien llama haga nada
   // (lo lejano y las nebulosas de csh_starfield_run.js, el enlace de csh_link.js). `noMirror` es la peticion simple de dentro (la que
   // hace cshSimbadGet a cada servidor). (28-oct, tarde: ya no se mira `opts.next` —el nombre del siguiente servidor, que solo sirve para
   // el aviso—: era la salida de Cabra3D, que tenia SU cadena —c3SimbadGet—; ahora Cabra3D usa cshSimbadGet y no hay otra que respetar.)
   if (CSH_SIMBAD_BACKUP !== false && !(opts && opts.noMirror === true) && String(url).indexOf(CSH_SIMBAD_CDS) === 0) {
      var g = cshSimbadGet(url, opts, null), rg = g.ok ? g.r : (g.first || g.r);
      if (rg) { rg.server = g.server; rg.fallback = g.fallback; rg.attempts = g.attempts; }
      return rg;
   }
   // (29-oct-2026, P8) Y UNA PETICION AL TAP DE VizieR DEL CDS lleva la suya —los espejos de VizieR por ASU, ver cshVizierGet— igual, sin que
   // quien llama haga nada (GLADE+ y Quaia de csh_depth_run.js, el polvo de Cabra3D, las capas…). Solo si la consulta se puede decir en ASU
   // (un cono y filtros simples: cshVizierAdqlToAsu); si no (JOIN, IN, alias…), solo el CDS, como antes.
   if (CSH_VIZIER_BACKUP !== false && !(opts && opts.noMirror === true) && String(url).indexOf(CSH_VIZIER_CDS) === 0) {
      var gv = cshVizierGet(url, opts), rv = gv.ok ? gv.r : (gv.first || gv.r);
      if (rv) { rv.server = gv.server; rv.fallback = gv.fallback; rv.attempts = gv.attempts; rv.empty = (gv.empty === true); }
      return rv;
   }
   return cshRawNet(url, cpSfHttpTextRaw(url, opts));
}
function cpSfHttpTextRaw(url, opts) {
   var o = opts || {};
   var out = { ok: false, code: -1, text: "", ms: 0, message: "", transport: "" };
   var t0 = Date.now(), limitS = (o.timeoutS > 0) ? o.timeoutS : CP_SF_HTTP_TIMEOUT_S;
   function tick() { if (typeof o.onProgress === "function") { try { o.onProgress(Date.now() - t0); } catch (eP) {} } }
   if (typeof CP_SF_HTTP_HOOK === "function") {
      out.transport = "hook";
      try {
         tick();
         var r = CP_SF_HTTP_HOOK(url, o) || {};
         out.cut = (r.timeout === true);
         out.ok = (r.ok === true); out.code = (typeof r.code === "number") ? r.code : (out.ok ? 200 : 0);
         out.text = String(r.text || ""); out.message = String(r.message || "");
      } catch (eH) { out.message = String(eH.message || eH); }
      out.ms = Date.now() - t0;
      return out;
   }
   if (CSH_ABORT === true) { out.code = 0; out.message = "aborted"; out.aborted = true; return out; }
   if (!cshHasCurl()) {
      out.transport = "NetworkTransfer";
      tick();
      var res = cshNetworkGet(url);
      out.code = res.code; out.message = res.message || "";
      if (res.ok && res.data) {
         try { out.text = res.data.utf8ToString(); } catch (eU) { out.text = ""; }
         out.ok = (res.code < 400 && out.text.length > 0);
      }
      out.ms = Date.now() - t0;
      return out;
   }
   var tmp = cshTmpPath("csh_get", ".csv"), ra = cshRawArgs(url, o);
   var c = cshCurlRun(ra.args.concat(["-o", tmp, url]), { timeoutS: ra.waitS, onTick: function() { tick(); } });
   return cshRawFinish(url, o, c, tmp, ra.limitS, t0);
}
// (29-oct-2026 (noche), el lote comun csh_batch.js) Los argumentos de curl de UNA peticion GET (sin «-o fichero» ni la URL) y el plazo de la
// espera; y la respuesta a partir de lo que dijo curl. Partidos de cpSfHttpTextRaw para que la espera en serie (cshCurlRun) y la del
// lote (cshBatchPool, sin bloquear) hagan EXACTAMENTE la misma peticion y la juzguen igual.
// (F2, 22-oct-2026) OPCIONES, apagadas por defecto (asi era antes): `follow` sigue redirecciones (-L, 4 como mucho) y
// `retry` (n) repite ante un fallo PASAJERO: HTTP 5xx (y 408/429) o tiempo agotado, siempre que el fallo llegue dentro de
// la ventana de reintento (`--retry-max-time` = plazo de conexion + 2 s): un 5xx rapido o un plazo de CONEXION agotado se
// repiten; un servidor que se queda callado hasta el tope (-m) no (eso doblaria la espera). Sin conexion (DNS, rechazo)
// no se repite: curl no lo cuenta como pasajero. Lo hace curl (--retry, pausa de 1 s).
// -> { args, limitS (el -m), waitS (lo que se espera a curl: el -m y, con reintento, sus ventanas) }
function cshRawArgs(url, o) {
   o = o || {};
   var limitS = (o.timeoutS > 0) ? o.timeoutS : CP_SF_HTTP_TIMEOUT_S;
   var D = (typeof CSH_HTTP_DEFAULTS === "object" && CSH_HTTP_DEFAULTS) ? CSH_HTTP_DEFAULTS : {};
   var follow = (o.follow !== undefined) ? (o.follow === true) : (D.follow === true);
   var retry = Math.max(0, Math.floor(Number((o.retry !== undefined) ? o.retry : (D.retry || 0)) || 0));
   // (30-oct-2026) `retryFast`: la ventana de reintento acaba ANTES del plazo de conexion: un 5xx rapido se repite, un plazo de conexion agotado no (detras hay otro servidor)
   var connS = (o.connectTimeoutS > 0) ? o.connectTimeoutS : 10, retryWin = (o.retryFast === true) ? Math.max(1, connS - 1) : connS + 2;
   var cargs = ["--connect-timeout", String(connS), "-m", String(Math.round(limitS))];
   if (follow) cargs = cargs.concat(["-L", "--proto", "=https", "--proto-redir", "=https", "--max-redirs", "4"]);
   if (retry > 0) cargs = cargs.concat(["--retry", String(retry), "--retry-delay", "1", "--retry-max-time", String(retryWin)]);
   // (29-oct-2026) `headers` = [ "Nombre: valor", … ] (opcional): Wikidata pide un User-Agent propio (con uno vacío contesta 403; medido el 29-oct)
   if (o.headers && o.headers.length) for (var ih = 0; ih < o.headers.length; ++ih) cargs = cargs.concat(["-H", String(o.headers[ih])]);
   return { args: cargs, limitS: limitS, waitS: limitS + ((retry > 0) ? retry * (retryWin + 1) : 0) };
}
// c = { exit, code, cut, aborted, message } (cshCurlRun o el lote); tmp = el fichero de salida (se lee y se borra)
function cshRawFinish(url, o, c, tmp, limitS, t0) {
   o = o || {};
   var out = { ok: false, code: -1, text: "", ms: 0, message: "", transport: "curl" };
   if (c.message) out.message = c.message;
   out.code = c.code; out.cut = c.cut; out.aborted = c.aborted;
   try { if (File.exists(tmp)) { out.text = File.readTextFile(tmp); File.remove(tmp); } } catch (eR) {}
   out.ok = (!c.cut && !c.aborted && c.exit === 0 && out.code >= 200 && out.code < 300 && out.text.length > 0);
   if (!out.ok && out.message.length === 0)
      out.message = c.cut ? "no answer in " + limitS + " s" : c.aborted ? "aborted" : "curl exit " + c.exit + ", HTTP " + out.code;
   out.ms = Date.now() - t0;
   if (!out.ok) cshNetSay(url, out, o, c, limitS);      // (27-oct: corta, sin la URL; ver cshNetConsoleLine)
   return out;
}
// Lo que cpSfHttpText añade a una respuesta en bruto que fallo: el porque (net)
function cshRawNet(url, r) {
   // (22-oct-2026, tarde, Cabra3D) curl que se rinde EL MISMO por su plazo (-m o --connect-timeout) sale con «curl exit 28, HTTP 0»
   // y no llega al corte de cshCurlRun: tambien es «no contesto a tiempo», no «sin conexion» (tests/c3_net.js 7: GAVO callado).
   if (r && !r.ok && !r.net) r.net = cshNetFail(url, r, r.cut === true || /^no answer in|^curl exit 28,/.test(String(r.message || "")));
   return r;
}

// ¿Es una tabla CSV lo que ha contestado el servicio? (Un error de TAP llega como un documento VOTable con HTTP 200
// o 400.) `column` es una que tiene que estar.
function cpSfLooksLikeCsv(text, column) {
   var head = String(text || "").substring(0, 400);
   return (head.indexOf("<") < 0 && head.split("\n")[0].indexOf(column) >= 0);
}
function cpSfTapUrl(base, adql) {
   return base + "?REQUEST=doQuery&LANG=ADQL&FORMAT=csv&MAXREC=200000&QUERY=" + encodeURIComponent(adql);
}

// ---------------------------------------------------------------------------
// (28-oct-2026, B4) LA RESERVA DE SIMBAD: el espejo oficial de Harvard (simbad.harvard.edu: el mismo servicio TAP sobre la misma base).
// UNA sola, para todos (la idea y los plazos son los de la antigua c3SimbadGet de Cabra3D, ya quitada: Cabra3D usa esta).
// Solo se activa si la URL pedida es la del CDS: una prueba que desvia SIMBAD a otro sitio NO pasa al espejo sin querer.
// PLAZOS: el CDS con los suyos (25 s, 10 de conexion) y el espejo con 15 s (8 de conexion; contesta en 0,4-1,3 s): el peor caso con
// todo caido alarga la espera a lo sumo 15 s sobre lo de siempre. Si el CDS fallo y el espejo SI contesto, durante CSH_SIMBAD_DOWN_S
// (120 s) se pregunta primero al espejo: sin esa memoria cada consulta (lejano, 2 de nebulosas, el enlace) esperaria 10 s a un CDS mudo.
// (la memoria no se usa con CP_SF_HTTP_HOOK: una prueba con la red de mentira no deja huella en la siguiente)
// COSTURA ROJA: CSH_SIMBAD_BACKUP = false -> solo el CDS, como antes.
// ---------------------------------------------------------------------------
var CSH_SIMBAD_CDS = "https://simbad.cds.unistra.fr/simbad/sim-tap/sync";
var CSH_SIMBAD_MIRROR = "https://simbad.harvard.edu/simbad/sim-tap/sync";
var CSH_SIMBAD_CDS_NAME = "SIMBAD (CDS)", CSH_SIMBAD_MIRROR_NAME = "SIMBAD (Harvard mirror)";
var CSH_SIMBAD_MIRROR_TIMEOUT_S = 15, CSH_SIMBAD_MIRROR_CONNECT_S = 8, CSH_SIMBAD_DOWN_S = 120;
var CSH_SIMBAD_BACKUP = true;
var CSH_SIMBAD_DOWN_UNTIL = 0;          // ms (Date.now) hasta cuando se da el CDS por caido
var CSH_SIMBAD_LAST = null;             // la ultima peticion: { server, fallback, attempts, ms } (la linea de estado de quien llama la lee)
var CSH_SIMBAD_CLOCK = null;            // pruebas: function() -> ms en lugar de Date.now
function cshSimbadNow() { return (typeof CSH_SIMBAD_CLOCK === "function") ? CSH_SIMBAD_CLOCK() : Date.now(); }
function cshSimbadReset() { CSH_SIMBAD_DOWN_UNTIL = 0; CSH_SIMBAD_LAST = null; }
// ¿Es la tabla? Nada vacio y ni un documento (HTML / VOTable de error) en la cabecera. Quien llama puede pasar la suya.
function cshSimbadIsTable(text) { var t = String(text || ""); return t.length > 0 && t.substring(0, 400).indexOf("<") < 0; }
// -> { r (la respuesta que vale o la ultima que fallo), first (la del CDS), ok, server, fallback, attempts: [{ server, kind, http, ms }] }
function cshSimbadGet(url, opts, isTable) {
   var P = cshSimbadPlan(url, opts, isTable);
   for (var i = 0; i < P.list.length; ++i) {
      if (i > 0 && typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) break;
      if (cshSimbadStep(P, i, cpSfHttpText(P.list[i].url, cshSimbadReqOpts(P, i))) !== "next") break;
   }
   return cshSimbadEnd(P);
}
// (29-oct-2026 (noche), el lote comun csh_batch.js) cshSimbadGet partida en tres para que el lote recorra LA MISMA cadena sin bloquear:
//   cshSimbadPlan -> P { list (los servidores, en orden), out, o, chk, t0 } · cshSimbadReqOpts(P, i) -> las opciones de la peticion i
//   cshSimbadStep(P, i, r) -> "ok" | "stop" | "next" (apunta el intento) · cshSimbadEnd(P) -> out (la memoria, el aviso, CSH_SIMBAD_LAST)
function cshSimbadPlan(url, opts, isTable) {
   var o = opts || {}, u = String(url), chk = (typeof isTable === "function") ? isTable : cshSimbadIsTable;
   var out = { r: null, first: null, ok: false, server: "", fallback: false, attempts: [] }, t0 = cshSimbadNow();
   var cds = { name: CSH_SIMBAD_CDS_NAME, url: u, timeoutS: o.timeoutS, connectTimeoutS: o.connectTimeoutS, cds: true }, list = [cds];
   if (CSH_SIMBAD_BACKUP !== false && u.indexOf(CSH_SIMBAD_CDS) === 0) {
      var base = (o.timeoutS > 0) ? o.timeoutS : CP_SF_HTTP_TIMEOUT_S;
      var mir = { name: CSH_SIMBAD_MIRROR_NAME, url: CSH_SIMBAD_MIRROR + u.substring(CSH_SIMBAD_CDS.length), timeoutS: Math.min(base, CSH_SIMBAD_MIRROR_TIMEOUT_S),
                  connectTimeoutS: Math.min((o.connectTimeoutS > 0) ? o.connectTimeoutS : 10, CSH_SIMBAD_MIRROR_CONNECT_S), cds: false };
      // (30-oct-2026) al CDS, CSH_CDS_CONNECT_S (hay espejo detras) y la memoria tambien la del disco (otro script, hace un rato)
      if (!cshNetBrk("noshortconn")) cds.connectTimeoutS = Math.min((o.connectTimeoutS > 0) ? o.connectTimeoutS : 10, CSH_CDS_CONNECT_S);
      list = (typeof CP_SF_HTTP_HOOK !== "function" && cshSimbadNow() < Math.max(CSH_SIMBAD_DOWN_UNTIL, cshHealthUntil("simbad"))) ? [mir, cds] : [cds, mir];
   }
   return { list: list, out: out, o: o, chk: chk, t0: t0 };
}
function cshSimbadReqOpts(P, i) {
   var sv = P.list[i], o = P.o;
   return { timeoutS: sv.timeoutS, connectTimeoutS: sv.connectTimeoutS, what: o.what || "", noMirror: true, onProgress: o.onProgress,
            next: (i + 1 < P.list.length) ? P.list[i + 1].name : (o.next || "") };
}
function cshSimbadStep(P, i, r) {
   var sv = P.list[i], out = P.out, good = !!(r && r.ok && P.chk(r.text));
   out.attempts.push({ server: sv.name, kind: good ? "ok" : (r && r.ok) ? "bad" : (r && r.cut) ? "timeout" : (r && r.code > 0) ? "http" : "offline", http: (r && r.code > 0) ? r.code : 0, ms: r ? r.ms : 0 });
   if (sv.cds && out.first === null) out.first = r;
   out.r = r; out.server = sv.name; out.fallback = !sv.cds;
   if (good) { out.ok = true; return "ok"; }
   if (r && r.aborted) return "stop";
   return "next";
}
function cshSimbadEnd(P) {
   var out = P.out, t0 = P.t0;
   if (out.first === null) out.first = out.r;
   // la memoria del CDS caido: solo si el CDS fallo DE VERDAD (sin conexion, tiempo, 5xx) y el espejo contesto
   if (typeof CP_SF_HTTP_HOOK !== "function" && out.attempts.length > 1) {
      var cdsAt = null; for (var k = 0; k < out.attempts.length; ++k) if (out.attempts[k].server === CSH_SIMBAD_CDS_NAME) cdsAt = out.attempts[k];
      if (cdsAt !== null && cdsAt.kind !== "ok" && out.ok && out.fallback && (cdsAt.kind !== "http" || cdsAt.http >= 500)) { CSH_SIMBAD_DOWN_UNTIL = cshSimbadNow() + CSH_SIMBAD_DOWN_S * 1000; cshHealthMark("simbad", cdsAt.kind); }
      else if (!out.ok && cshNetBrk("resetonfail")) CSH_SIMBAD_DOWN_UNTIL = 0;          // (la costura roja: como hasta el 30-oct; ver cshVizierEnd)
      else if (cdsAt !== null && (cdsAt.kind === "ok" || (cdsAt.kind === "http" && cdsAt.http < 500))) { CSH_SIMBAD_DOWN_UNTIL = 0; cshHealthClear("simbad"); }
   } else if (out.ok && !out.fallback && typeof CP_SF_HTTP_HOOK !== "function") { CSH_SIMBAD_DOWN_UNTIL = 0; cshHealthClear("simbad"); }
   if (out.ok && out.fallback) {
      var secs = (out.attempts[out.attempts.length - 1].ms / 1000).toFixed(1);
      try { console.noteln(cshConsoleEsc("CabraShared: " + ((out.attempts.length > 1) ? CSH_SIMBAD_CDS_NAME + " did not answer; answered by " + out.server + " in " + secs + " s"
                                                                                        : out.server + " answered in " + secs + " s (" + CSH_SIMBAD_CDS_NAME + " did not answer a moment ago)"))); } catch (eN) {}
   }
   CSH_SIMBAD_LAST = { server: out.server, fallback: out.fallback, ok: out.ok, attempts: out.attempts, ms: cshSimbadNow() - t0 };
   return out;
}

// ---------------------------------------------------------------------------
// (29-oct-2026, P8) LA RESERVA DE VizieR: los espejos oficiales de VizieR por ASU (asu-tsv), con la MISMA consulta dicha en ASU.
// Por que asi: ningun espejo tiene TAP (medido el 29-oct: /TAPVizieR/tap/sync da 404 en CfA, NAO e IDIA; INASAN rechaza la conexion,
// IUCAA no contesta en 8 s), y el CDS llevaba caido desde la noche del 28 (sin conexion en 8-10 s). Lo que si contesta es ASU
// (medido el 29-oct por la mañana, tres rondas, GLADE+ y Quaia en Abell 39 con 0,45°):
//   IDIA (Sudafrica)  https://vizier.idia.ac.za/viz-bin/asu-tsv  6 de 6 bien, 1,2-5,9 s (GLADE+ 557 filas, Quaia 12)
//   NAO  (Japon)      vizier.nao.ac.jp (solo http; fuera el 3-nov)  0,8-9,5 s pero 3 de 6 MAL: HTTP 200 con «#INFO Error=The database is not
//                                                               currently reachable» y sin tabla (por eso se mira la tabla, no el HTTP)
//   CfA  (Harvard)    vizier.cfa.harvard.edu/viz-bin/asu-tsv      conecta pero no contesta en 20 s (GLADE+, Quaia y hasta Gaia DR3): fuera
// Orden: IDIA y despues NAO. UNA sola funcion para todas las consultas a VizieR (la llama cpSfHttpText): ninguna por catalogo.
// QUE CONSULTAS: las que caben en ASU — «SELECT [TOP n] col, "col+", … FROM "tabla" WHERE 1=CONTAINS(POINT('ICRS',a,b),CIRCLE('ICRS',ra,dec,r))
// [AND col op numero …]» (op: > < >= <= =). Cualquier otra cosa (JOIN, alias, IN, OR, funciones, sin cono) -> null: solo el CDS.
// (29-oct-2026, motor unico) …salvo que csh_vizier.js (cshVzPlan) la sepa decir en varias peticiones: ver cshVizierGet, mas abajo.
// La respuesta del espejo se pasa al MISMO CSV que da TAPVizieR (cabecera = las columnas pedidas, en su orden; nulos vacios; «+» de delante de
// los numeros fuera) y quien llama la lee sin saber de donde vino. Si al espejo le falta una columna pedida, no vale (no se rellena a ciegas).
// PLAZOS: el CDS con los suyos; cada espejo CSH_VIZIER_MIRROR_TIMEOUT_S (15 s, 8 de conexion). Si el CDS fallo DE VERDAD (sin conexion,
// tiempo, 5xx) y un espejo contesto, durante CSH_VIZIER_DOWN_S (120 s) se pregunta primero a los espejos (como cshSimbadGet).
// COSTURA ROJA: CSH_VIZIER_BACKUP = false -> solo el CDS, como antes. CSH_VIZIER_MIRRORS se puede cambiar (pruebas: otra URL).
// (29-oct-2026, tarde; R1 H-1 de Codex, la misma familia que R2 H-1 de CabraComposition) UN ESPEJO QUE CONTESTA «0 FILAS» NO ES LA ULTIMA PALABRA:
// el 29-oct NAO dio a x19 en M 67 solo la cabecera de comentarios (0 filas) a las 07:00 y 329 filas a las 12:09, y otro espejo tenia la tabla.
// Un espejo con 0 filas queda como «vacio provisional» y se pregunta al siguiente; si alguno trae filas, manda; si ninguno y alguno contesto
// vacio y VALIDO, vale el vacio: ok, 0 filas y `empty: true` (tambien en la respuesta de cpSfHttpText). El vacio del CDS es definitivo (no se
// pregunta a nadie mas). cshVizierGet no guarda nada en cache, ni sus llamadores por la via ASU (grep del 29-oct): un vacio no se puede cachear.
// COSTURAS ROJAS: CSH_VIZIER_ACCEPT_EMPTY = true -> el primer espejo que contesta vacio se acepta (como antes); CSH_VIZIER_COMMENTS_EMPTY = false ->
// una respuesta de solo comentarios (el banner de VizieR, sin tabla ni «Error=») es «mala», no «vacia» (como antes);
// CSH_VIZIER_EMPTY_LOOSE = true -> CUALQUIER «solo comentarios» vale como vacio, aunque el espejo no haya entendido la peticion (el criterio de la mañana del 29-oct).
// ---------------------------------------------------------------------------
var CSH_VIZIER_CDS = "https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync";
var CSH_VIZIER_CDS_NAME = "VizieR (CDS)";
// (3-nov-2026, CPD C1) SIN EL ESPEJO DE NAO: solo contesta por http (por https no conecta: 000 a los 15 s, medido el 3-nov) y las reglas CPD 6.3
// piden https en todo. Queda IDIA. (Las pruebas que necesitan un segundo espejo lo ponen ellas: CSH_VIZIER_MIRRORS se puede cambiar.)
var CSH_VIZIER_MIRRORS = [{ name: "VizieR (IDIA mirror)", asu: "https://vizier.idia.ac.za/viz-bin/asu-tsv" }];
var CSH_VIZIER_MIRROR_TIMEOUT_S = 15, CSH_VIZIER_MIRROR_CONNECT_S = 8, CSH_VIZIER_DOWN_S = 120;
var CSH_VIZIER_BACKUP = true;
var CSH_VIZIER_ACCEPT_EMPTY = false, CSH_VIZIER_COMMENTS_EMPTY = true, CSH_VIZIER_EMPTY_LOOSE = false;       // (costuras rojas, ver arriba)
var CSH_VIZIER_DOWN_UNTIL = 0;
var CSH_VIZIER_LAST = null;             // la ultima peticion: { server, fallback, ok, attempts, ms, asu (null si no cabia en ASU) }
function cshVizierReset() { CSH_VIZIER_DOWN_UNTIL = 0; CSH_VIZIER_LAST = null; }
// La consulta de una URL de TAP por GET: { adql, maxrec } o null
function cshVizierQueryOf(url) {
   var u = String(url || ""), m = /[?&]QUERY=([^&]*)/i.exec(u), mx = /[?&]MAXREC=(\d+)/i.exec(u), q = "";
   if (!m) return null;
   try { q = decodeURIComponent(m[1].replace(/\+/g, " ")); } catch (eD) { return null; }
   return { adql: q, maxrec: mx ? parseInt(mx[1], 10) : 0 };
}
// ADQL -> ASU. -> { table, cols: [nombres], params: "texto tras el ?" } o null (no cabe: solo el CDS)
function cshVizierAdqlToAsu(adql, maxrec) {
   var s = String(adql || "").replace(/\s+/g, " ").replace(/^ | $/g, "");
   var m = /^SELECT (?:TOP (\d+) )?(.+?) FROM "([^"]+)" WHERE (.+)$/i.exec(s);
   if (!m) return null;
   var table = m[3];
   if (!/^[A-Za-z0-9_.+-]+([/][A-Za-z0-9_.+-]+)*$/.test(table)) return null;
   var ID = /^(?:"([^"]+)"|([A-Za-z_][A-Za-z0-9_]*))$/, cols = [], parts = m[2].split(","), i;
   for (i = 0; i < parts.length; ++i) {
      var c = ID.exec(parts[i].replace(/^ | $/g, ""));
      if (!c) return null;                                                     // (alias, funciones, «*»)
      cols.push(c[1] || c[2]);
   }
   var terms = m[4].split(/ AND /i), cone = null, cons = [];
   var CONE = /^(?:1 ?= ?)?CONTAINS ?\( ?POINT ?\( ?'ICRS' ?, ?[^,()]+ ?, ?[^,()]+ ?\) ?, ?CIRCLE ?\( ?'ICRS' ?, ?([-+]?[0-9.]+(?:[eE][-+]?\d+)?) ?, ?([-+]?[0-9.]+(?:[eE][-+]?\d+)?) ?, ?([0-9.]+(?:[eE][-+]?\d+)?) ?\) ?\)(?: ?= ?1)?$/i;
   var CMP = /^(?:"([^"]+)"|([A-Za-z_][A-Za-z0-9_]*)) ?(>=|<=|>|<|=) ?([-+]?[0-9.]+(?:[eE][-+]?\d+)?)$/;
   for (i = 0; i < terms.length; ++i) {
      var t = terms[i].replace(/^ | $/g, ""), k;
      if ((k = CONE.exec(t)) !== null) { if (cone) return null; cone = { ra: Number(k[1]), dec: Number(k[2]), r: Number(k[3]) }; continue; }
      if ((k = CMP.exec(t)) !== null) { cons.push([k[1] || k[2], k[3], k[4]]); continue; }
      return null;                                                             // (OR, IN, BETWEEN, IS NULL, …)
   }
   if (!cone || !isFinite(cone.ra) || !isFinite(cone.dec) || !(cone.r > 0)) return null;   // (sin cono, ASU traeria el catalogo entero)
   var max = m[1] ? parseInt(m[1], 10) : ((maxrec > 0) ? maxrec : 200000);
   var p = "-source=" + table + "&-c=" + cone.ra.toFixed(6) + (cone.dec >= 0 ? "%2B" : "") + cone.dec.toFixed(6) + "&-c.rd=" + String(cone.r) +
           "&-out.max=" + max + "&-oc.form=dec&-out=" + cols.map(function(x) { return encodeURIComponent(x); }).join(",");
   for (i = 0; i < cons.length; ++i) p += "&" + encodeURIComponent(cons[i][0]) + "=" + encodeURIComponent(cons[i][1] + cons[i][2]);
   return { table: table, cols: cols, params: p };
}
// ¿Es la respuesta de ASU «solo comentarios» Y un VACIO REAL? El banner de VizieR («VizieR Astronomical Server»), ninguna linea de datos
// (con tabuladores, sin «#»), ni «Error=» ni HTML/XML: lo que dio NAO para x19 en M 67 con 0 filas (29-oct).
// (29-oct, noche; verificacion R1-R3 con 84 respuestas reales de VizieR, IDIA y NAO) Eso solo no basta: un espejo que NO ENTIENDE la peticion
// (restriccion mal escrita; en NAO, una columna que no tiene) contesta tambien solo comentarios, sin «Error=», pero con «#RESOURCE=» y «#Name:»
// VACIOS y ninguna linea «#Column». El vacio de verdad trae «#Name: <la tabla pedida>» y una «#Column<TAB><col><TAB>» por CADA columna pedida.
// Por eso se pasan la tabla y las columnas: sin ellas (o con una sola que falte) NO es un vacio, es «no entendi la peticion».
// -> { empty: bool, why: texto }. Costura roja CSH_VIZIER_EMPTY_LOOSE = true: vale cualquier «solo comentarios» (el criterio de la mañana del 29-oct).
function cshVizierAsuCommentsOnly(text, table, cols) {
   var s = String(text || ""), L = s.split("\n"), i, res = { empty: false, why: "" };
   if (s.indexOf("VizieR Astronomical Server") < 0 || /Error=|QUERY_STATUS=ERROR/.test(s) || s.substring(0, 400).indexOf("<") >= 0) return res;
   for (i = 0; i < L.length; ++i) {
      var l = L[i].replace(/\r$/, "");
      if (l.length > 0 && l.charAt(0) !== "#" && l.indexOf("\t") >= 0) return res;
   }
   // (29-oct, motor unico) la costura roja, la de los dos motores: CSH_VIZIER_EMPTY_LOOSE o CSH_BREAK/CC_BREAK=emptyloose (cshVzLoose, csh_vizier.js)
   if (CSH_VIZIER_EMPTY_LOOSE === true || (typeof cshVzLoose === "function" && cshVzLoose())) { res.empty = true; return res; }
   var dc = cshVzDeclared(s, table, cols), lack = dc.lack;
   if (!dc.named) { res.why = "the mirror did not understand the request (empty #Name, no #Column)"; return res; }
   if (lack.length > 0 || !cols || cols.length === 0) { res.why = "the mirror did not understand the request (no #Column for " + (lack.length ? lack.join(", ") : "any column") + ")"; return res; }
   res.empty = true;
   return res;
}
// (29-oct, motor unico) LA REGLA DEL VACIO, UNA SOLA VEZ (antes escrita dos veces: aqui y en ccAsuRead de CabraComposition, hoy cshVzRead de
// csh_vizier.js): ¿declara la respuesta ASU la tabla pedida (#Name) y una #Column por cada columna pedida? -> { named, lack: [las que faltan] }
function cshVzDeclared(text, table, cols) {
   var L = String(text || "").split("\n"), i, named = false, have = {}, tb = String(table || "").toLowerCase(), lack = [];
   for (i = 0; i < L.length; ++i) {
      var l = L[i].replace(/\r$/, "");
      if (l.indexOf("#Name:") === 0) { if (tb.length > 0 && l.substring(6).replace(/^\s+|\s+$/g, "").toLowerCase() === tb) named = true; }
      else if (l.indexOf("#Column\t") === 0) { var cc = l.split("\t"); if (cc.length > 1) have[cc[1]] = true; }
   }
   for (i = 0; cols && i < cols.length; ++i) if (have[cols[i]] !== true) lack.push(cols[i]);
   return { named: named, lack: lack };
}
// La tabla ASU (asu-tsv) -> el CSV de TAPVizieR con las columnas pedidas. -> { ok, csv, rows, empty (0 filas), why }
// (29-oct, tarde) `empty`: la tabla viene con su cabecera y 0 filas, o la respuesta es solo comentarios (cshVizierAsuCommentsOnly): csv = la cabecera sola.
// Formato ASU: «#» comentarios, cabecera con tabuladores, unidades, guiones, filas; las celdas van alineadas con espacios.
// No vale: sin cabecera con TODAS las columnas pedidas (error de la base del espejo, columna que no existe), o sin la fila de guiones.
function cshVizierAsuToCsv(text, cols, table) {
   var out = { ok: false, csv: "", rows: 0, empty: false, why: "" }, L = String(text || "").split("\n"), i, h = -1, idx = null, yieldOk = (typeof cshYield === "function");
   function trim(x) { return String(x === undefined ? "" : x).replace(/^\s+|\s+$/g, ""); }
   for (i = 0; i < L.length && h < 0; ++i) {
      var s = L[i].replace(/\r$/, "");
      if (s.length === 0 || s.charAt(0) === "#" || (s.indexOf("\t") < 0 && cols.length > 1)) continue;
      var hc = s.split("\t").map(trim), ok = true, ix = [];
      for (var c = 0; c < cols.length; ++c) { var at = hc.indexOf(cols[c]); if (at < 0) { ok = false; break; } ix.push(at); }
      if (ok) { h = i; idx = ix; }
   }
   var co = (h < 0 && CSH_VIZIER_COMMENTS_EMPTY !== false) ? cshVizierAsuCommentsOnly(text, table, cols) : null;
   if (co !== null && co.empty) {
      out.ok = true; out.empty = true; out.why = "only comments, no table (0 rows)";
      out.csv = cols.map(function(x) { return /[",\n]/.test(x) ? "\"" + x.replace(/"/g, "\"\"") + "\"" : x; }).join(",") + "\n";
      return out;
   }
   if (co !== null && co.why) { out.why = co.why; return out; }
   if (h < 0) { out.why = /Error=/.test(String(text || "").substring(0, 4000)) ? "the mirror answered with an error, no table" : "no table with the columns asked for"; return out; }
   var d = -1;
   for (i = h + 1; i < Math.min(L.length, h + 4); ++i) { var sd = L[i].replace(/\r$/, ""); if (/^[-\t ]+$/.test(sd) && sd.indexOf("-") >= 0) { d = i; break; } }
   if (d < 0) { out.why = "no ASU table (no dashes row)"; return out; }
   function csvCell(v) { return /[",\n]/.test(v) ? "\"" + v.replace(/"/g, "\"\"") + "\"" : v; }
   var lines = [cols.map(csvCell).join(",")];
   for (i = d + 1; i < L.length; ++i) {
      if (yieldOk && (i & 1023) === 1023) cshYield();
      var r = L[i].replace(/\r$/, "");
      if (r.length === 0 || r.charAt(0) === "#") break;                        // (fin de la tabla)
      var cells = r.split("\t"), o2 = [];
      for (var k = 0; k < idx.length; ++k) {
         var v = trim(cells[idx[k]]);
         if (/^[+][0-9.]/.test(v)) v = v.substring(1);                         // (+27.938389 -> 27.938389, como TAP)
         o2.push(csvCell(v));
      }
      lines.push(o2.join(","));
      ++out.rows;
   }
   out.csv = lines.join("\n") + "\n";
   out.ok = true;
   out.empty = (out.rows === 0);
   return out;
}
// -> { r (la respuesta que vale —su .text ya en CSV de TAP— o la ultima que fallo), first (la del CDS), ok, server, fallback, attempts, asu,
//       empty (true = ok pero con 0 filas: ningun espejo trajo filas y uno contesto vacio; r.text es la cabecera sola) }
// (29-oct-2026, motor unico; docs/motor-vizier-unico.md) LO QUE NO CABE EN EL TRADUCTOR SENCILLO (JOIN, IS NOT NULL, TOP + ORDER BY) YA NO VA SOLO AL
// CDS: si csh_vizier.js esta cargado y su planificador (cshVzPlan, el de CabraComposition, con ctx.strict: todo el WHERE tiene que entenderse)
// la sabe decir, cada espejo la recibe en VARIAS peticiones ASU (una por tabla) y se monta en casa el MISMO CSV de TAP (cshVzMirrorAsk, de uno
// en uno para que la regla de los 0 filas, la memoria del CDS caido y los avisos sean los de siempre). Medido antes (fase 0, CDS caido,
// tests/csh_vizier_control_net_fase0.log): el afinado, la base Gaia, las RV, el Teff y la ficha FALLABAN en VizieR.
// Plazo de cada peticion: CSH_VIZIER_JOIN_TIMEOUT_S = 40 s (las tablas auxiliares van enteras por el cono: mas pesadas que la consulta sencilla;
// medido el 29-oct en Abell 39 a 0,3 grados: IDIA 1,6-4,0 s por consulta entera; NAO no contesto en 60 s). Un montaje con 0 filas NO vale como
// vacio (CSH_VIZIER_JOIN_EMPTY = false; ver abajo, la paramp de IDIA).
// COSTURA ROJA: CSH_VIZIER_JOIN = false -> solo el CDS para lo que no cabe (lo de antes).
var CSH_VIZIER_JOIN = true, CSH_VIZIER_JOIN_TIMEOUT_S = 40, CSH_VIZIER_JOIN_EMPTY = false;
function cshVizierGet(url, opts) {
   var P = cshVizierPlan(url, opts);
   for (var i = 0; i < P.list.length; ++i) {
      if (i > 0 && typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) break;
      var sv = P.list[i], r, mr = null;
      if (!sv.cds && P.vz) {
         // (motor unico) varias peticiones a ESTE espejo; el vacio provisional y el «siguiente» los decide este bucle, como con la sencilla
         var ts = Date.now(), last = null, ro = cshVizierReqOpts(P, i);
         // (29-oct-2026 (noche)) con el lote comun cargado (csh_batch.js) las peticiones de un espejo salen A LA VEZ (medido en Abell 39: la base y la
         // tabla auxiliar del afinado, 2,1 + 2,0 s en serie en IDIA; tests/csh_batch_speed_c3_antes.log). Con el gancho de pruebas, en serie (las
         // pruebas cuentan las visitas al gancho: tras un fallo no se pide la siguiente)
         var many = (typeof cshHttpMany === "function" && typeof CP_SF_HTTP_HOOK !== "function") ? function(urls) { var rs = cshHttpMany(urls.map(function(x) { return { url: x, opts: ro }; })); if (rs.length) last = rs[rs.length - 1] || last; return rs; } : null;
         mr = cshVzMirrorAsk(P.vz.plan, P.vz.reqs, { mirrors: [sv.mirror], adql: P.q.adql, acceptEmpty: true, abort: function() { return typeof CSH_ABORT !== "undefined" && CSH_ABORT === true; },
                                                 fetch: function(fu) { last = cpSfHttpText(fu, ro) || {}; return last; }, fetchMany: many });
         r = cshVizierJoinResp(mr, last, ts);
      } else r = cpSfHttpText(sv.url, cshVizierReqOpts(P, i));
      if (cshVizierStep(P, i, r, mr) !== "next") break;
   }
   return cshVizierEnd(P);
}
// (29-oct-2026 (noche), el lote comun csh_batch.js) cshVizierGet partida en piezas, como cshSimbadGet, para que el lote recorra LA MISMA cadena:
//   cshVizierPlan -> P { list, out, o, q, tr, vz, tname, prov, stopped, ansAt, t0 } · cshVizierReqOpts(P, i) · cshVizierJoinResp(mr, last, ts)
//   cshVizierStep(P, i, r, mr) -> "ok" | "stop" | "next" · cshVizierEnd(P) -> out
function cshVizierPlan(url, opts) {
   var o = opts || {}, u = String(url), t0 = cshSimbadNow();
   var out = { r: null, first: null, ok: false, server: "", fallback: false, attempts: [], asu: null, vz: null, empty: false };
   var q = (CSH_VIZIER_BACKUP !== false) ? cshVizierQueryOf(u) : null, tr = q ? cshVizierAdqlToAsu(q.adql, q.maxrec) : null, vz = null;
   if (q && !tr && CSH_VIZIER_JOIN !== false && typeof cshVzPlan === "function") {
      var pl = cshVzPlan(q.adql, "", { strict: true });
      if (pl.ok) { vz = { plan: pl, reqs: cshVzRequests(pl), table: pl.tables.map(function(x) { return x.table; }).join(" + ") }; if (q.maxrec > 0 && !(pl.top > 0)) pl.top = q.maxrec; }
   }
   out.asu = tr; out.vz = vz;
   var tname = tr ? tr.table : (vz ? vz.table : "");
   var cds = { name: CSH_VIZIER_CDS_NAME, url: u, timeoutS: o.timeoutS, connectTimeoutS: o.connectTimeoutS, cds: true }, list = [cds];
   if ((tr || vz) && CSH_VIZIER_MIRRORS && CSH_VIZIER_MIRRORS.length) {
      var base = (o.timeoutS > 0) ? o.timeoutS : CP_SF_HTTP_TIMEOUT_S, mirrors = [];
      for (var j = 0; j < CSH_VIZIER_MIRRORS.length; ++j)
         mirrors.push({ name: CSH_VIZIER_MIRRORS[j].name, url: CSH_VIZIER_MIRRORS[j].asu + "?" + (tr ? tr.params : vz.reqs[0].qs), mirror: CSH_VIZIER_MIRRORS[j],
                        timeoutS: tr ? Math.min(base, CSH_VIZIER_MIRROR_TIMEOUT_S) : CSH_VIZIER_JOIN_TIMEOUT_S,
                        connectTimeoutS: Math.min((o.connectTimeoutS > 0) ? o.connectTimeoutS : 10, CSH_VIZIER_MIRROR_CONNECT_S), cds: false });
      // (30-oct-2026) al CDS, CSH_CDS_CONNECT_S sin reintentar la conexion (hay espejos detras) y la memoria tambien la del disco (otro script, hace un rato)
      if (!cshNetBrk("noshortconn")) { cds.connectTimeoutS = Math.min((o.connectTimeoutS > 0) ? o.connectTimeoutS : 10, CSH_CDS_CONNECT_S); cds.retryFast = true; }
      list = (typeof CP_SF_HTTP_HOOK !== "function" && cshSimbadNow() < Math.max(CSH_VIZIER_DOWN_UNTIL, cshHealthUntil("vizier"))) ? mirrors.concat([cds]) : [cds].concat(mirrors);
   }
   return { list: list, out: out, o: o, q: q, tr: tr, vz: vz, tname: tname, prov: null, stopped: false, ansAt: -1, t0: t0 };
}
function cshVizierReqOpts(P, i) {
   var sv = P.list[i], o = P.o, nx = (i + 1 < P.list.length) ? P.list[i + 1].name : (o.next || "");
   // (29-oct-2026 (noche)) `follow` y `retry` de quien llama siguen valiendo: el afinado pide su reintento al CDS (c3_net 4); a los espejos no, que
   // tienen su plazo corto y detras va el siguiente
   return { timeoutS: sv.timeoutS, connectTimeoutS: sv.connectTimeoutS, what: o.what || P.tname, noMirror: true, onProgress: o.onProgress, next: nx,
            follow: o.follow, retry: sv.cds ? o.retry : undefined, retryFast: sv.retryFast === true };
}
// La respuesta de un espejo montada con varias peticiones (cshVzMirrorAsk) en la forma de una peticion simple
function cshVizierJoinResp(mr, last, ts) {
   var r;
   if (mr.ok) r = { ok: true, code: 200, text: mr.csv, ms: Date.now() - ts, message: "", transport: last ? last.transport : "", cut: false, aborted: false };
   else if (mr.last) { r = mr.last; r.ms = Date.now() - ts; }
   else r = { ok: true, code: (last && last.code) || 200, text: "", ms: Date.now() - ts, message: mr.why, cut: false, aborted: false };      // (contesto, pero no se pudo montar la tabla)
   return r;
}
function cshVizierStep(P, i, r, mr) {
   var sv = P.list[i], out = P.out, tname = P.tname, nx = (i + 1 < P.list.length) ? P.list[i + 1].name : (P.o.next || "");
   var good = false, why = "", emp = false;
   if (r && r.ok) {
      if (sv.cds) good = cshSimbadIsTable(r.text);
      else if (mr) {
         // (0 filas MONTADAS no se creen como «campo vacio»: medido el 29-oct, IDIA contesta a I/355/paramp con «E(BP-RP)» en -out las #Name y
         // #Column de un vacio de verdad y NINGUNA fila —con A0 o Teff solos si trae filas—. Se pregunta al siguiente y, si nadie trae filas,
         // FALLO: el llamador sigue con su respaldo (la ESA del Teff), en vez de quedarse con «0 estrellas». CSH_VIZIER_JOIN_EMPTY = true: se cree.)
         if (mr.ok) { r.rows = mr.rows; if (mr.rows === 0 && CSH_VIZIER_JOIN_EMPTY !== true) why = "0 rows in a rebuilt answer (not trusted as an empty field)"; else if (mr.rows === 0 && CSH_VIZIER_ACCEPT_EMPTY !== true) emp = true; else good = true; }
         else why = mr.badWhy || mr.why;
      } else {
         var cv = cshVizierAsuToCsv(r.text, P.tr.cols, P.tr.table);
         if (cv.ok) {
            r.asuText = r.text; r.text = cv.csv; r.rows = cv.rows;
            // (29-oct, tarde) 0 filas de un ESPEJO: vacio provisional (el PRIMERO que lo da), se pregunta al siguiente; solo si ninguno trae filas vale
            if (cv.rows === 0 && CSH_VIZIER_ACCEPT_EMPTY !== true) emp = true; else good = true;
         }
         else why = cv.why;
      }
      if (emp) {
         if (P.prov === null) P.prov = { r: r, server: sv.name, at: out.attempts.length };
         try { console.warningln(cshConsoleEsc("CabraShared: " + sv.name + " answered with 0 rows" + (tname ? " - " + tname : "") + ((i + 1 < P.list.length) ? "; asking " + nx + " too..." : ""))); } catch (eE) {}
      }
      if (!good && !emp) {
         r.net = cshNetFail(sv.url, r, false); r.net.kind = "bad";
         try { console.warningln(cshConsoleEsc("CabraShared: " + sv.name + " answered but not with the table (" + (why || "not a table") + ")" + (tname ? " - " + tname : "") + (nx ? "; trying " + nx + "..." : ""))); } catch (eW) {}
      }
   }
   out.attempts.push({ server: sv.name, kind: good ? "ok" : emp ? "empty" : (r && r.ok) ? "bad" : (r && r.cut) ? "timeout" : (r && r.code > 0) ? "http" : "offline", http: (r && r.code > 0) ? r.code : 0, ms: r ? r.ms : 0 });
   if (sv.cds && out.first === null) out.first = r;
   out.r = r; out.server = sv.name; out.fallback = !sv.cds;
   if (good) { out.ok = true; out.empty = (!sv.cds && r.rows === 0); P.ansAt = out.attempts.length - 1; return "ok"; }
   if (r && r.aborted) { P.stopped = true; return "stop"; }
   return "next";
}
function cshVizierEnd(P) {
   var out = P.out, prov = P.prov, ansAt = P.ansAt, tname = P.tname, t0 = P.t0;
   if (!P.stopped && typeof CSH_ABORT !== "undefined" && CSH_ABORT === true) P.stopped = true;
   // ningun espejo trajo filas (ni el CDS dio la tabla) y uno contesto vacio y valido: vale el vacio (ok, 0 filas, empty)
   if (!out.ok && prov !== null && !P.stopped) { out.ok = true; out.empty = true; out.r = prov.r; out.server = prov.server; out.fallback = true; ansAt = prov.at; }
   if (out.first === null) out.first = out.r;
   // la memoria del CDS caido: solo si el CDS fallo DE VERDAD (sin conexion, tiempo, 5xx) y un espejo contesto
   if (typeof CP_SF_HTTP_HOOK !== "function" && out.attempts.length > 1) {
      var cdsAt = null; for (var k2 = 0; k2 < out.attempts.length; ++k2) if (out.attempts[k2].server === CSH_VIZIER_CDS_NAME) cdsAt = out.attempts[k2];
      if (cdsAt !== null && cdsAt.kind !== "ok" && out.ok && out.fallback && (cdsAt.kind !== "http" || cdsAt.http >= 500)) { CSH_VIZIER_DOWN_UNTIL = cshSimbadNow() + CSH_VIZIER_DOWN_S * 1000; cshHealthMark("vizier", cdsAt.kind); }
      // (30-oct-2026, revision de Codex) que fallen TODOS (una tabla que los espejos no sirven, sin red) no dice que el CDS haya vuelto: la memoria la borra solo que EL CDS conteste.
      // Con la memoria del disco ya no cambiaba el orden (cshVizierPlan mira las dos); sin ella (no se pudo escribir), la consulta siguiente volvia a pagarle al CDS su plazo. Medido en csh_carga_node M12.
      else if (!out.ok && cshNetBrk("resetonfail")) CSH_VIZIER_DOWN_UNTIL = 0;
      else if (cdsAt !== null && (cdsAt.kind === "ok" || (cdsAt.kind === "http" && cdsAt.http < 500))) { CSH_VIZIER_DOWN_UNTIL = 0; cshHealthClear("vizier"); }
   } else if (out.ok && !out.fallback && typeof CP_SF_HTTP_HOOK !== "function") { CSH_VIZIER_DOWN_UNTIL = 0; cshHealthClear("vizier"); }
   if (out.ok && out.fallback) {
      var secs = (out.attempts[ansAt >= 0 ? ansAt : out.attempts.length - 1].ms / 1000).toFixed(1), cdsTried = false;
      for (var a = 0; a < out.attempts.length; ++a) if (out.attempts[a].server === CSH_VIZIER_CDS_NAME) cdsTried = true;
      try { console.noteln(cshConsoleEsc("CabraShared: " + (cdsTried ? CSH_VIZIER_CDS_NAME + " did not answer; " + tname + " answered by " + out.server + " in " + secs + " s"
                                                                     : tname + " from " + out.server + " in " + secs + " s (" + CSH_VIZIER_CDS_NAME + " did not answer a moment ago)"))); } catch (eN) {}
   }
   CSH_VIZIER_LAST = { server: out.server, fallback: out.fallback, ok: out.ok, empty: out.empty, attempts: out.attempts, ms: cshSimbadNow() - t0, asu: P.tr, vz: P.vz };
   return out;
}
