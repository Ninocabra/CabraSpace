// ============================================================================
// src/cc_i18n.js — la interfaz en inglés con su traducción al castellano
// ----------------------------------------------------------------------------
// ccT(key) devuelve el texto en el idioma elegido (CC_LANG: "en" | "es"; se
// recuerda entre sesiones). Las frases de la ciencia (biografía, poblaciones)
// están en cc_science.js (ccBiography, CC_POP_NAME), también en los dos.
// ES5 puro.
// ============================================================================
var CC_LANG = "en";
var CC_TXT = {
   title: ["StellarChemistry", "StellarChemistry"],          // (30-oct-2026) el nombre que se ve (antes CabraComposition); es marca: no se traduce
   subtitle: ["the chemical history of the stars in your image", "la historia química de las estrellas de tu imagen"],
   // --- el armazón (22-oct-2026: la interfaz «como CabraStars / Cabra3D») ---
   viewTitle: ["STELLAR CHEMISTRY · GALACTIC ARCHAEOLOGY", "STELLAR CHEMISTRY · ARQUEOLOGÍA GALÁCTICA"],
   imgRefreshTip: ["Read again the list of images open in PixInsight.", "Vuelve a leer la lista de imágenes abiertas en PixInsight."],
   astrometry: ["Astrometry", "Astrometría"],
   // (las píldoras, CORTAS: lo largo va a su ayuda —§11.7—; con los textos largos de CabraStars la barra no cabía a 1200 px
   //  lógicos y se cortaban: «Sin cali…», captura real de T9 del 22-oct)
   pillNoView: ["Open an image in PixInsight first", "Abre antes una imagen en PixInsight"],
   pillMono: ["Black and white: fine for the analysis (SPCC colour recommended)", "B/N: vale para el análisis (se aconseja color con SPCC)"],
   pillMonoTip: ["Black-and-white image: fine for the analysis (the chemistry comes from the catalogues). A colour image calibrated with SPCC is recommended for the look.",
                 "Imagen en B/N: vale para el análisis (la química sale de los catálogos). Para la vista se aconseja una imagen en color calibrada con SPCC."],
   pillSpcc: ["Colour calibrated with SPCC.", "Color calibrado con SPCC."],
   pillSpccTip: ["Colour calibrated with SPCC (found in its processing history).", "Color calibrado con SPCC (está en su historial de procesado)."],
   pillNoSpcc: ["No colour calibration in its history (SPCC recommended)", "Sin calibración de color en su historial (se aconseja SPCC)"],
   pillNoSpccTip: ["No colour calibration found in its processing history. Recommended, not required: the chemistry comes from the catalogues, not from the colours of your photo. With SPCC the “Real photo” view shows the true colours of the stars.",
                   "No hay calibración de color en su historial de procesado. Recomendado, no obligatorio: la química sale de los catálogos, no de los colores de tu foto. Con SPCC, la vista «Foto real» enseña el color verdadero de las estrellas."],
   pillSolved: ["Solved: ImageSolver is not needed", "Resuelta: no hace falta ImageSolver"],
   pillSolvedTip: ["Astrometric solution found: ImageSolver will not be run.", "Tiene solución astrométrica: no hace falta ImageSolver."],
   pillNotSolved: ["Not solved: “Analyse” will solve it with ImageSolver first", "Sin resolver: «Analizar» la resolverá antes con ImageSolver"],
   pillNotSolvedTip: ["No astrometric solution: “Analyse” will solve it first with ImageSolver.", "Sin solución astrométrica: «Analizar» la resolverá antes con ImageSolver."],
   // (22-oct, fase 1 de los cuatro grupos: «Volver a preguntar a los catálogos» deja de ser un botón de II; es Mayús + clic aquí)
   analyseTip: ["<html>Asks the catalogues (Gaia DR3, APOGEE, GALAH, LAMOST and the age catalogues, through VizieR) for every star of the frame and works out its chemistry, age, population and family. A field already analysed opens from the offline cache. If the image has no astrometric solution it is solved first with ImageSolver.<br><br><b>Shift + click</b>: asks every catalogue afresh, ignoring the offline cache.</html>",
                "<html>Pregunta a los catálogos (Gaia DR3, APOGEE, GALAH, LAMOST y los de edades, por VizieR) por cada estrella del encuadre y calcula su química, edad, población y familia. Un campo ya analizado se abre de la caché sin red. Si la imagen no tiene solución astrométrica, se resuelve antes con ImageSolver.<br><br><b>Mayús + clic</b>: vuelve a preguntar a todos los catálogos sin la caché.</html>"],
   fullTip: ["Fill the screen with the window (press again to go back to its size).", "La ventana ocupa la pantalla (pulsa otra vez para volver a su tamaño)."],
   toView: ["To view", "A vista"],
   toViewTip: ["The photo, the three diagrams, the star card and the timeline, as a new PixInsight image (twice the screen resolution).",
               "La foto, los tres diagramas, la ficha y la línea de tiempo, como una imagen nueva de PixInsight (al doble de la resolución de pantalla)."],
   toFile: ["To file…", "A fichero…"],
   toFileTip: ["The same, as a PNG file (remembers the last folder).", "Lo mismo, como fichero PNG (recuerda la última carpeta)."],
   tableCsv: ["Table CSV…", "Tabla CSV…"],
   exported: ["Exported", "Exportado"],
   exportFail: ["Could not export", "No se pudo exportar"],
   retryTip: ["Ask again only what did not answer (what is already here comes from the cache).", "Vuelve a pedir solo lo que no contestó (lo que ya está sale de la caché)."],
   grpView: ["View", "Vista"],
   grpViewSub: ["size by age · population rings · error bars · Milky Way backdrop", "tamaño por edad · anillos de población · barras de error · fondo de la Vía Láctea"],
   // --- los cuatro grupos (22-oct, noche: decisión de Nino, docs/plan_grupos_22oct.md) ---
   grpJourney: ["Journey and video", "Viaje y vídeo"],
   // (29-oct, Nino: «La Galaxia en el tiempo» se mudó a III · La Galaxia, su sitio natural; II cuenta el campo)
   grpJourneySub: ["the story of the field · grand tour · preview and recording", "la historia del campo · gran recorrido · vista previa y grabación"],
   grpJourneyHelp: ["Two videos of your field: “The story of the field” (time runs from the Big Bang to today and each star lights up when it was born) and “Grand tour” (a stop at each remarkable star). ▶ Preview plays it in the middle column, where the diagrams go (the photo is not touched); ● Record saves it (AVI by default; MP4 if you choose ffmpeg in ▾ Format) with a contact sheet. The video of the stars orbiting the Milky Way, “The Galaxy through time”, is in III · The Galaxy.",
                    "Dos vídeos de tu campo: «La historia del campo» (el tiempo corre del Big Bang a hoy y cada estrella se enciende al nacer) y «Gran recorrido» (una parada en cada estrella notable). ▶ Vista previa lo reproduce en la columna del medio, la de los diagramas (la foto no se toca); ● Grabar lo guarda (AVI de fábrica; MP4 si eliges ffmpeg en ▾ Formato) con una hoja de contacto. El vídeo de las estrellas orbitando la Vía Láctea, «La Galaxia en el tiempo», está en III · La Galaxia."],
   grpGalaxyHelp: ["The map of the Milky Way with the stars of your field, from above, edge-on or in 3D, today or along their orbits, coloured by population, age or [Fe/H]. While this group is open the map takes the place of the three diagrams (chemistry, age–metallicity and kinematic families); a click on a star chooses it (photo and card follow). The glow is the mass of the disc and the bulge of that same potential, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023). The Time ruler takes the map back to any moment since the Big Bang: each star goes to where it was along its orbit and only the ones already born are shown (stars without an age are not drawn in the past; the Sun appears 4.57 billion years ago). Those past positions are illustrative: they are computed with today's Galaxy, which ignores radial migration, the heating of the disc, mergers and that the Galaxy was different then. To watch it as a film, or record it: ▶ ● at the end of the Time row (“The Galaxy through time”: ▶ Preview plays it in place of the map, with the Time ruler following its clock; ● Record saves it with a contact sheet).",
                   "El mapa de la Vía Láctea con las estrellas de tu campo, desde arriba, de canto o en 3D, hoy o a lo largo de sus órbitas, coloreadas por población, edad o [Fe/H]. Mientras este grupo está abierto el mapa ocupa el sitio de los tres diagramas (química, edad–metalicidad y familias cinemáticas); un clic en una estrella la elige (la foto y la ficha la siguen). El resplandor es la masa del disco y del bulbo de ese mismo potencial, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023). La regla «Tiempo» lleva el mapa a cualquier momento desde el Big Bang: cada estrella va adonde estaba en su órbita y solo se ven las que ya habían nacido (las que no tienen edad no se pintan en el pasado; el Sol aparece hace 4570 millones de años). Esas posiciones pasadas son ilustrativas: se calculan con la Galaxia de hoy, que no tiene en cuenta la migración radial, el calentamiento del disco, las fusiones ni que la Galaxia era distinta. Para verlo como película, o grabarlo: ▶ ● al final de la fila «Tiempo» («La Galaxia en el tiempo»: ▶ Vista previa la reproduce en el sitio del mapa, con la regla «Tiempo» siguiendo su reloj; ● Grabar la guarda con una hoja de contacto)."],
   videoBusy: ["A video is being recorded: wait for it to finish (or ■ Cancel it).", "Se está grabando un vídeo: espera a que acabe (o ■ Cancélalo)."],
   wipJourney: ["Under construction: here will go the flight modes (“The story of the field”, “Grand tour”), the preview and the video recording.",
                "En construcción: aquí irán los modos de vuelo («La historia del campo», «Gran recorrido»), la vista previa y la grabación de vídeo."],
   grpGalaxy: ["The Galaxy", "La Galaxia"],
   grpGalaxySub: ["the Milky Way from above, edge-on and in 3D · orbits · back in time · video", "la Vía Láctea desde arriba, de canto y en 3D · órbitas · hacia atrás en el tiempo · vídeo"],
   wipGalaxy: ["Under construction: here will go the map of the Milky Way with the stars of the field (from above, edge-on and in 3D) and their orbits.",
               "En construcción: aquí irá el mapa de la Vía Láctea con las estrellas del campo (desde arriba, de canto y en 3D) y sus órbitas."],
   viewSubElem: ["colour: %1", "color: %1"],
   viewHelp: ["What is drawn on the stars and in the diagrams, and the element that colours the photo and goes on the vertical axis of the chemistry diagram.",
              "Lo que se pinta sobre las estrellas y en los diagramas, y el elemento que colorea la foto y va en el eje vertical del diagrama de química."],
   capElem: ["Choose an element: the stars of the photo are coloured by how much of it they have per iron atom, and the chemistry diagram puts it on its vertical axis. Fe (the default) is iron itself: the photo by [Fe/H] and the chemistry diagram by [α/Fe].",
             "Elige un elemento: las estrellas de la foto se colorean por cuánto tienen de él por cada átomo de hierro, y el diagrama de química lo pone en su eje vertical. Fe (lo de fábrica) es el propio hierro: la foto por [Fe/H] y el diagrama de química por [α/Fe]."],
   rowElement: ["Element", "Elemento"],
   elemSub: ["photo colour and chemistry axis · %1: %2 stars", "color de la foto y eje de la química · %1: %2 estrellas"],
   elemSubNone: ["photo colour and chemistry axis · choose the element", "color de la foto y eje de la química · elige el elemento"],
   elemSubMissing: ["no %1 in this field: showing [Fe/H] · %2 stars", "no hay %1 en este campo: se enseña [Fe/H] · %2 estrellas"],
   panelAEl: ["The photograph — stars by %1", "La foto — estrellas por %1"],
   capAEl: ["Each dot is a star of your photo with a spectrum: colour = its %1 (%2 per iron atom, against the Sun); grey = not measured; ring = the part of the Galaxy it belongs to.",
            "Cada punto es una estrella de tu foto con espectro: el color dice su %1 (%2 por cada átomo de hierro, frente al Sol); gris = sin medir; el anillo, a qué parte de la Galaxia pertenece."],
   panelBEl: ["Chemistry — %1 vs [Fe/H]", "Química — %1 frente a [Fe/H]"],
   capBEl: ["Right: more iron. Up: more %1 per iron atom.", "Derecha: más hierro. Arriba: más %1 por cada átomo de hierro."],
   elemGloss: ["%1: how much %2 the star has per iron atom, compared with the Sun, on a logarithmic scale (0 = like the Sun, +0.3 = twice as much, −0.3 = half). Blue = less, cream = like the Sun, gold = more; grey = not measured.",
               "%1: cuánto %2 tiene la estrella por cada átomo de hierro, comparado con el Sol, en escala logarítmica (0 = como el Sol, +0,3 = el doble, −0,3 = la mitad). Azul = menos, crema = como el Sol, oro = más; gris = sin medir."],
   legNoVal: ["not measured", "sin medir"],
   // --- el litio (23-oct): A(Li) absoluta, sus límites y B = A(Li) frente a Teff ---
   capALi: ["Each dot is a star of your photo: colour = its lithium A(Li), on a FIXED scale from 0 (none left) to 3.3 (the gas the Sun was born from); hollow grey ring = only an upper limit; ring around = the part of the Galaxy it belongs to.",
            "Cada punto es una estrella de tu foto: color = su litio A(Li), en una escala FIJA de 0 (no le queda) a 3,3 (el gas del que nació el Sol); anillo gris hueco = solo un límite superior; anillo alrededor = la parte de la Galaxia a la que pertenece."],
   liGloss: ["A(Li): how much lithium the star has, absolute (12 + log of lithium atoms per hydrogen atom), not per iron atom. Benchmarks: 1.05 the Sun’s surface today, 2.2 the oldest metal-poor stars (Spite plateau), 3.26 the gas the Sun was born from (meteorites). Blue = little, cream = in between, gold = a lot; hollow grey = an upper limit. GALAH DR4, 3D NLTE.",
             "A(Li): cuánto litio tiene la estrella, en absoluto (12 + log de átomos de litio por átomo de hidrógeno), no por átomo de hierro. Referencias: 1,05 la superficie del Sol hoy, 2,2 las estrellas más viejas y pobres en metales (meseta de Spite), 3,26 el gas del que nació el Sol (meteoritos). Azul = poco, crema = en medio, oro = mucho; gris hueco = un límite superior. GALAH DR4, 3D NLTE."],
   legLiUl: ["≤ upper limit", "≤ límite superior"],
   panelBLi: ["Lithium — A(Li) vs Teff", "Litio — A(Li) frente a Teff"],
   capBLi: ["Left: hotter stars (like an HR diagram). Up: more lithium. ▽ = upper limit.", "Izquierda: estrellas más calientes (como un diagrama HR). Arriba: más litio. ▽ = límite superior."],
   liDet: ["with A(Li)", "con A(Li)"],
   liUl: ["upper limits (▽)", "límites superiores (▽)"],
   liUlShort: ["limits ▽", "límites ▽"],
   liGiants: ["hollow = giants (log g < 3.5)", "huecas = gigantes (log g < 3,5)"],
   liRefs: ["lines: 3.26 meteorites · 2.2 Spite plateau · 1.5 lithium-rich giants · ☉ the Sun", "líneas: 3,26 meteoritos · 2,2 meseta de Spite · 1,5 gigantes ricas en litio · ☉ el Sol"],
   liMeteor: ["meteorites 3.26", "meteoritos 3,26"],
   liSpite: ["Spite plateau 2.2", "meseta de Spite 2,2"],
   liRich: ["Li-rich giants 1.5", "gigantes ricas 1,5"],
   liUlTip: ["%1 more with only an upper limit (▽ in the lithium diagram, hollow grey ring in the photo): the lithium is at most that value.", "%1 más con solo un límite superior (▽ en el diagrama del litio, anillo gris hueco en la foto): el litio es como mucho ese valor."],
   teffAxis: ["Teff (K)", "Teff (K)"],
   teffGloss: ["Effective temperature of the star’s surface, from the SAME survey that measured its lithium. Hot on the left, as in an HR diagram.", "Temperatura efectiva de la superficie de la estrella, del MISMO survey que midió su litio. Las calientes a la izquierda, como en un diagrama HR."],
   withEl: ["with %1", "con %1"],
   // (E4, 23-oct) la nube de referencia por elemento: de dónde sale (pie) o por qué no la hay (docs/referencia_elementos.md)
   noBackdropEl: ["no Milky Way backdrop for %1: %2", "sin fondo de la Vía Láctea para %1: %2"],
   noBackdropShort: ["no backdrop for %1", "sin fondo para %1"],
   noBackdropGiants: ["no background: the cloud is of giants", "sin fondo: la nube es de gigantes"],
   refGiants: ["giants", "gigantes"],
   refWhy_unreliable: ["APOGEE DR17 rates it less reliable and GALAH DR4 does not measure it", "APOGEE DR17 lo da por poco fiable y GALAH DR4 no lo mide"],
   refWhy_censored: ["GALAH DR4 detects it in too few stars (fewer than 1 in 5): the cloud would be that of the stars rich in it", "GALAH DR4 lo detecta en muy pocas estrellas (menos de 1 de cada 5): la nube sería la de las ricas en él"],
   refWhy_small: ["too few stars with a reliable value", "muy pocas estrellas con un valor fiable"],
   refWhy_pileup: ["in GALAH DR4 many values pile up at the solar starting value (0): the cloud would show that, not the Galaxy", "en GALAH DR4 muchos valores se amontonan en el valor de partida solar (0): la nube enseñaría eso, no la Galaxia"],
   refWhy_giantsonly: ["the cloud is made of giants and most of the stars drawn here are not", "la nube es de gigantes y la mayoría de las pintadas aquí no lo son"],
   refWhy_nodata: ["no survey with a large, reliable sample", "ningún survey con una muestra grande y fiable"],
   refLiFoot: ["backdrop: GALAH DR4, %1 detections (cloud) · %2 upper limits (dotted line)", "fondo: GALAH DR4, %1 detecciones (nube) · %2 límites superiores (línea de puntos)"],
   noBackdropLi: ["no lithium backdrop", "sin fondo del litio"],
   // --- la familia química, en la ficha (lo que era el grupo III) ---
   famChem: ["Chemical family", "Familia química"],
   famLine: ["family %1 of %2 · %3 stars · [Fe/H] %4", "familia %1 de %2 · %3 estrellas · [Fe/H] %4"],
   famNone: ["none: it shares its recipe with no other star of the field (%1)", "ninguna: no comparte su receta con otra estrella del campo (%1)"],
   famClick: ["click: highlight it in the panels", "clic: resaltarla en los paneles"],
   famUnclick: ["click: remove the highlight", "clic: quitar el resaltado"],
   famInField: ["In this field", "En este campo"],
   famWarn: ["Many compatible pairs: here chemistry alone does not separate families (or most of the field is one cluster).",
             "Muchos pares compatibles: aquí la química sola no separa familias (o casi todo el campo es un cúmulo)."],
   failedSee: ["catalogue(s) failed — see the “?” by the counts", "catálogo(s) fallaron: mira el «?» de las cifras"],
   rowStars: ["Stars", "Estrellas"],
   rowDiagrams: ["Diagrams", "Diagramas"],
   noImageName: ["No image", "Sin imagen"],
   notAnalysed: ["Not analysed yet: press “Analyse”.", "Sin analizar: pulsa «Analizar»."],
   analysing: ["Analysing…", "Analizando…"],
   fieldOf: ["field of %1° × %2°", "campo de %1° × %2°"],
   fehFrom: ["[Fe/H] from", "[Fe/H] de"],
   catsAnswered: ["%1 of %2 catalogues answered", "contestaron %1 de %2 catálogos"],
   allCached: ["all from the offline cache", "todo de la caché sin red"],
   split1Tip: ["drag: resize the photo and the panel · double click: back to half and half", "arrastrar: el tamaño de la foto y del panel · doble clic: mitad y mitad"],
   split2Tip: ["drag: resize the diagrams and the star card · double click: back to the default", "arrastrar: el tamaño de los diagramas y de la ficha · doble clic: el de fábrica"],
   wheelMore: ["↓ wheel: more", "↓ rueda: más"],
   analyse: ["Analyse", "Analizar"],
   refresh: ["Refresh", "Actualizar"],
   close: ["Close", "Cerrar"],
   retry: ["Retry", "Reintentar"],
   gaiaLocalAsk: ["Gaia database on this computer…", "Base Gaia de este ordenador…"],
   closeTip: ["Close StellarChemistry (the same as the window's close box or Esc). Stops any download in progress.",
              "Cerrar StellarChemistry (lo mismo que el aspa de la ventana o Esc). Para la descarga que esté en curso."],
   closing: ["Closing…", "Cerrando…"],
   // (22-oct, noche) la vista previa y la carga gradual
   previewPhoto: ["Preparing the photo…", "Preparando la foto…"],
   previewReady: ["%1 Gaia stars (G<17) in the frame, from this computer's Gaia %2 · press Analyse for their chemistry",
                  "%1 estrellas de Gaia (G<17) en el encuadre, de la base Gaia %2 de este ordenador · pulsa Analizar para su química"],
   previewReadyNoGaia: ["Photo ready · press Analyse to ask the catalogues", "Foto lista · pulsa Analizar para preguntar a los catálogos"],
   previewReadyNoSolution: ["Photo ready · no astrometric solution: Analyse will solve it first", "Foto lista · sin solución astrométrica: Analizar la resolverá antes"],
   waitingFor: ["waiting for", "esperando a"],
   fetchingN: ["Downloading the catalogues: %d of %d in", "Descargando los catálogos: %d de %d recibidos"],
   starsSoFar: ["stars with data so far", "estrellas con datos por ahora"],
   langTip: ["Interfaz en castellano", "English interface"],
   image: ["Image", "Imagen"],
   panelA: ["The photograph — stars by metallicity", "La foto — estrellas por metalicidad"],
   panelAPhoto: ["The photograph — as it is", "La foto — tal cual"],
   capAPhoto: ["Your photo as it is: the same stars, without marks. “Stars” colours each one by its iron.",
               "Tu foto tal cual: las mismas estrellas, sin marcas. «Estrellas» colorea cada una por su hierro."],
   aPhoto: ["Real photo", "Foto real"],
   aCompare: ["Compare", "Comparar"],
   aViewTipCmp: ["Compare: a curtain over the photo. On the left of the gold line, your photo, clean; on the right, the stars with their colours and rings. Drag the line. Nothing is recalculated; the zoom and the framing do not change.",
                 "Comparar: una cortinilla sobre la foto. A la izquierda de la línea dorada, tu foto limpia; a la derecha, las estrellas con sus colores y anillos. Arrastra la línea. No se recalcula nada; el zoom y el encuadre no cambian."],
   aComp: ["Stars", "Estrellas"],      // (30-oct-2026, Nino: «los cuatro iguales») la clave interna sigue siendo "comp"; el texto, el de CabraStars/Cabra3D/CabraStarAnalysis
   // (30-oct-2026, Nino: los cuatro iguales) el tooltip del conmutador «Real photo | Stars», que cambia con el estado (como en CabraStars, Cabra3D y CabraStarAnalysis)
   aViewTipOn: ["Stars on the photo: SHOWN (each star coloured by its metallicity, with its rings and the legend). “Real photo” shows your photo clean. Nothing is recalculated: “Stars” brings it back exactly the same. The zoom, the framing and the chosen star do not change. Your choice is remembered for the next time.",
                "Estrellas sobre la foto: VISIBLES (cada estrella coloreada por su metalicidad, con sus anillos y la leyenda). «Foto real» enseña tu foto limpia. No se recalcula nada: «Estrellas» lo devuelve exactamente igual. El zoom, el encuadre y la estrella elegida no cambian. Tu elección se recuerda para la próxima vez."],
   aViewTipOff: ["Stars on the photo: HIDDEN (your photo, clean). “Stars” shows again the colours and rings, exactly as you left them. Nothing is recalculated; the zoom, the framing and the chosen star do not change. Your choice is remembered for the next time.",
                 "Estrellas sobre la foto: OCULTAS (tu foto, limpia). «Estrellas» vuelve a mostrar los colores y los anillos, exactamente como los dejaste. No se recalcula nada; el zoom, el encuadre y la estrella elegida no cambian. Tu elección se recuerda para la próxima vez."],
   aPhotoNote: ["Your photo as it is (stretched for the screen). The colours and rings return with “Stars”.",
                "Tu foto tal cual (estirada para la pantalla). Los colores y los anillos vuelven con «Estrellas»."],
   panelB: ["Chemistry — [α/Fe] vs [Fe/H]", "Química — [α/Fe] frente a [Fe/H]"],
   panelC: ["Age–metallicity", "Edad–metalicidad"],
   timeline: ["The Milky Way through time", "La Vía Láctea en el tiempo"],
   secBio: ["Biography", "Biografía"],
   secCov: ["Coverage & sources", "Cobertura y fuentes"],
   secTag: ["Chemical families", "Familias químicas"],
   secView: ["Display", "Visualización"],
   secExport: ["Export", "Exportar"],
   sizeByAge: ["Size by age", "Tamaño por edad"],
   contours: ["Population contours", "Contornos de población"],
   errors: ["Error bars for every star", "Barras de error en todas"],
   backdrop: ["Milky Way reference backdrop", "Fondo de referencia de la Vía Láctea"],
   exportCsv: ["Save table (CSV)…", "Guardar tabla (CSV)…"],
   exportTip: ["<html>One row per star: adopted values, their uncertainties and the survey each one comes from.<br>The folder is remembered.</html>",
               "<html>Una fila por estrella: valores adoptados, sus incertidumbres y el survey de cada uno.<br>Se recuerda la carpeta.</html>"],
   noImage: ["Open a plate-solved image (or any image: it will be solved) and press Analyse.", "Abre una imagen resuelta (o cualquiera: se resolverá) y pulsa Analizar."],
   noSel: ["Click a star in any panel.", "Pulsa una estrella en cualquier panel."],
   solving: ["Solving the image (ImageSolver)…", "Resolviendo la imagen (ImageSolver)…"],
   photo: ["Preparing the photograph…", "Preparando la foto…"],
   ready: ["Ready", "Listo"],
   cached: ["from cache", "de la caché"],
   monoWarn: ["Black & white image: fine for the analysis; a colour image calibrated with SPCC is recommended for the look.", "Imagen en B/N: vale para el análisis; se aconseja color calibrado con SPCC para la vista."],
   spccWarn: ["Colour not calibrated with SPCC (recommended, not required).", "Color sin calibrar con SPCC (recomendado, no obligatorio)."],
   noData: ["no data", "sin datos"],
   withChem: ["with [Fe/H]", "con [Fe/H]"],
   inSomeCat: ["in some catalogue", "en algún catálogo"],
   mirrorUsed: ["VizieR (CDS) down · data from the %1 mirror (%2 queries)", "VizieR (CDS) caído · datos del espejo de %1 (%2 consultas)"],
   withAge: ["with age", "con edad"],
   withKin: ["with kinematics", "con cinemática"],
   gaiaStars: ["Gaia stars in the frame", "Estrellas Gaia en el encuadre"],
   source: ["source", "fuente"],
   families: ["families", "familias"],
   compatible: ["chemically compatible with a common origin", "químicamente compatibles con un origen común"],
   comoving: ["moving together", "se mueven juntas"],
   tagHonesty: ["Compatible ≠ sisters: in the disc, about 1 % of random pairs are chemical doppelgängers (Ness+18).",
                "Compatibles ≠ hermanas: en el disco, ~1 % de los pares al azar son dobles químicos (Ness+18)."],
   tagRate: ["Baseline in this field", "Línea base en este campo"],
   pairs: ["pairs", "pares"],
   population: ["Population", "Población"],
   chemistry: ["Chemistry", "Química"],
   kinematics: ["Kinematics", "Cinemática"],
   age: ["Age", "Edad"],
   otherAges: ["other estimates", "otras estimaciones"],
   distance: ["Distance", "Distancia"],
   rv: ["Radial velocity", "Velocidad radial"],
   fingerprint: ["Nucleosynthetic fingerprint", "Huella nucleosintética"],
   solarTwin: ["Solar twin", "Gemela solar"],
   from: ["from", "de"],
   tierA: ["calibrated method (among the most reliable)", "método calibrado (de las más fiables)"],
   tierB: ["isochrone, evolved star", "isócrona, estrella evolucionada"],
   tierC: ["isochrone on a dwarf: indicative only", "isócrona en enana: solo orientativa"],
   tierCgiant: ["isochrone on a giant: indicative only", "isócrona en gigante: solo orientativa"],
   backdropNote: ["backdrop", "fondo"],
   today: ["today", "hoy"],
   older: ["older", "más vieja"],
   younger: ["younger", "más joven"],
   field: ["the field", "el campo"],
   // --- la frase llana de cada vista (siempre a la vista) y su explicación larga (el «?») ---
   capA: ["Each dot is a star of your photo with a spectrum: colour = its iron, ring = the part of the Galaxy it belongs to.",
          "Cada punto es una estrella de tu foto con espectro: el color dice su hierro; el anillo, a qué parte de la Galaxia pertenece."],
   tipA: ["Colour: iron compared with the Sun (blue = poor, cream = like the Sun, gold = richer). Ring: thin disc (one ring), thick disc (two), halo (ring with a cross), accreted from another galaxy (ring with an x). Filled = measured with a ground-based spectrum (APOGEE, GALAH, LAMOST); hollow = only Gaia. Wheel = zoom, drag = move, double click = whole frame.",
          "Color: el hierro comparado con el Sol (azul = poco, crema = como el Sol, oro = más). Anillo: disco fino (uno), disco grueso (dos), halo (anillo con cruz), acretada de otra galaxia (anillo con aspa). Relleno = medida con un espectro desde tierra (APOGEE, GALAH, LAMOST); hueco = solo Gaia. Rueda = zoom, arrastrar = mover, doble clic = encuadre entero."],
   noPhotoA: ["The field — synthetic, no photo", "El campo — sintético, sin foto"],
   capANoPhoto: ["Each dot is a star of the field with a spectrum: colour = its iron, ring = the part of the Galaxy it belongs to.",
                 "Cada punto es una estrella del campo con espectro: el color dice su hierro; el anillo, a qué parte de la Galaxia pertenece."],
   tipFam: ["Chemical doppelgängers: stars with the same chemistry that are not siblings. Baseline: the fraction of random pairs in this field that come out compatible; if it is high, two stars looking alike proves little.",
            "Dobles químicos: estrellas con la misma química que no son hermanas. Línea base: qué fracción de parejas al azar del campo salen compatibles; si es alta, que dos estrellas se parezcan prueba poco."],
   capB: ["Right: more iron. Up: born faster (more magnesium per iron).",
          "Derecha: más hierro. Arriba: nació más deprisa (más magnesio por hierro)."],
   tipB: ["Each star by its chemistry. The grey cloud and its contour lines are about %REFN APOGEE stars: the Milky Way's two sequences (thin disc below, thick disc above). The dashed gold line separates them (Weinberg et al. 2019). Left of −1: the halo.",
          "Cada estrella por su química. La nube gris y sus curvas de nivel son unas %REFN estrellas de APOGEE: las dos secuencias de la Vía Láctea (disco fino abajo, disco grueso arriba). La línea dorada discontinua las separa (Weinberg et al. 2019). A la izquierda de −1: el halo."],
   capC: ["Left: older. Each bar shows how well that age is known.",
          "Izquierda: más viejas. La barra dice cuánto se sabe de cada edad."],
   tipC: ["Age against iron. The cloud is 53,000 subgiants with precise ages (Xiang & Rix 22): older stars have less iron, because the Galaxy enriched itself over time. Faint dots: indicative ages (main-sequence dwarfs). The vertical line at 13.8 Gyr is the age of the Universe.",
          "Edad frente a hierro. La nube son 53 000 subgigantes con edad precisa (Xiang & Rix 22): las más viejas tienen menos hierro, porque la Galaxia se fue enriqueciendo. Puntos tenues: edades orientativas (enanas). La línea vertical en 13,8 Ga es la edad del Universo."],
   capD: ["Right: turns with the Galaxy. Up: wider orbit. Boxes: swallowed galaxies.",
          "Derecha: gira con la Galaxia. Arriba: órbita más amplia. Recuadros: galaxias absorbidas."],
   tipD: ["Energy (E) against angular momentum (Lz) in the Milky Way potential MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023). The regions are those of Naidu et al. 2020, defined in the older gala v1 potential and shifted in energy by the difference between the two (about 1,000 km²/s² near the Sun). Stars from the same swallowed galaxy keep similar E and Lz for billions of years. The lower curve is the circular orbit (nothing goes below); the violet area, orbits with eccentricity > 0.7 (Gaia-Enceladus). The regions overlap: membership is probable, never certain.",
          "Energía (E) frente a momento angular (Lz) en el potencial de la Vía Láctea MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023). Las regiones son las de Naidu et al. 2020, definidas en el potencial anterior de gala (v1) y desplazadas en energía la diferencia entre los dos (unos 1 000 km²/s² cerca del Sol). Las estrellas de una misma galaxia absorbida conservan E y Lz parecidas durante miles de millones de años. La curva de abajo es la órbita circular (nada queda por debajo); la zona violeta, órbitas de excentricidad > 0,7 (Gaia-Enceladus). Las regiones se solapan: la pertenencia es probable, nunca segura."],
   capDT: ["Speed relative to the Sun's neighbourhood: far from the corner = fast (halo).",
           "Velocidad respecto al entorno del Sol: lejos de la esquina = rápida (halo)."],
   tipDT: ["Toomre diagram: V (along the rotation) against the other two components, relative to the local standard of rest. Circles of constant total speed. Thin-disc stars stay near the centre; halo stars are far out.",
           "Diagrama de Toomre: V (en el sentido de la rotación) frente a las otras dos componentes, respecto al reposo local. Círculos de velocidad total constante. Las del disco fino quedan cerca del centro; las del halo, muy fuera."],
   viewElz: ["E–Lz", "E–Lz"], viewToomre: ["Toomre", "Toomre"],
   panelD: ["Kinematic families", "Familias cinemáticas"],
   panelDT: ["Kinematic families", "Familias cinemáticas"],
   more: ["more", "más"],
   capT: ["When each star of the field was born (ticks) and the selected one (glow), against the history of the Galaxy.",
          "Cuándo nació cada estrella del campo (rayas) y la elegida (resplandor), sobre la historia de la Galaxia."],
   tipT: ["Bands: approximate epochs of the Milky Way, each with its reference (halo, thick and thin disc, the mergers with Gaia-Enceladus, Sequoia and the Helmi streams, dated as published, Sagittarius). The glow of the selected star is as wide as its age uncertainty. If it was born in another galaxy, its band lights up.",
          "Bandas: épocas aproximadas de la Vía Láctea, cada una con su referencia (halo, discos grueso y fino, las fusiones con Gaia-Enceladus, Sequoia y las corrientes de Helmi, con su fecha publicada, Sagitario). El resplandor de la estrella elegida es tan ancho como la incertidumbre de su edad. Si nació en otra galaxia, su banda se ilumina."],
   capFam: ["Stars with the same chemical recipe: they may have been born together (compatible, not certain).",
            "Estrellas con la misma receta química: quizá nacieron juntas (compatibles, no es seguro)."],
   capCov: ["How many stars in the frame have each piece of data, and which catalogue it comes from.",
            "Cuántas estrellas del encuadre tienen cada dato y de qué catálogo sale."],
   moreDetail: ["Technical detail", "Detalle técnico"],
   openSimbad: ["Open in SIMBAD", "Abrir en SIMBAD"],          // (26-oct) el nombre de la ficha, enlace a SIMBAD (cc_paint.js ccLinkTip)
   noStars: ["No star in this frame has spectroscopy in the catalogues (or the catalogues did not answer: see the “?” by the counts).",
             "Ninguna estrella de este encuadre tiene espectroscopía en los catálogos (o los catálogos no contestaron: mira el «?» de las cifras)."],
   offScale: ["off the scale (drawn at the edge)", "fuera de escala (en el borde)"],
   offScaleShort: ["at the edge", "en el borde"],          // (23-oct, noche: la forma corta de los pies; la larga, en su «?»)
   sunLabel: ["Sun", "Sol"],
   // (23-oct, revisor R15) lo que enseñan B, C, D, E y el mapa de III mientras la vista previa o la grabación de II ocupan la foto
   videoCover: ["▶ shown in the preview (middle column)", "▶ lo enseña la vista previa (columna del medio)"],
   videoCoverShort: ["▶ in the preview", "▶ en la vista previa"],
   // (23-oct) los avisos de la ficha (docs/contradicciones_ficha.md «Para la interfaz»; los datos, de cc_engine.js)
   liSelNone: ["chosen star: no A(Li)", "elegida: sin A(Li)"],
   gaiaDoubt: ["Doubtful Gaia", "Gaia dudoso"],
   gaiaDoubtTip: ["Doubtful Gaia match: the Gaia number given by %1 belongs to another star %2″ away; no distance or orbit.",
                  "Gaia dudoso: el número de Gaia que da %1 es el de otra estrella, a %2″; sin distancia ni órbita."],
   zmaxAlt: ["Zmax %1 kpc (%2 with the %3 RV)", "Zmax %1 kpc (%2 con la RV de %3)"],
   zmaxAltTip: ["Its greatest height above the disc is not well measured: two catalogues give different radial velocities, and this orbit changes a lot with it. The other figures of the orbit hardly move.",
                "Su altura máxima sobre el disco no está bien medida: dos catálogos dan velocidades radiales distintas y esta órbita cambia mucho con ella. Las demás cifras de la órbita apenas se mueven."],
   rvAlt: ["%1 gives %2", "%1 da %2"],
   rvAltTip: ["Another catalogue gives a radial velocity that does not match the adopted one (more than 3 σ and more than 2 km/s apart): a double star, or a bad measurement in one of them.",
              "Otro catálogo da una velocidad radial que no casa con la adoptada (más de 3 σ y más de 2 km/s de diferencia): una estrella doble, o una medida mala en uno de los dos."],
   rvAltUsed: [" · orbit with ± %1 km/s", " · órbita con ± %1 km/s"],
   rvAltUsedTip: ["So the orbit, the kinematics and the population use an uncertainty that covers both values (the catalogue error and the difference, added in quadrature); the row above shows the catalogue error.",
                  "Por eso la órbita, la cinemática y la población usan una incertidumbre que cubre los dos valores (el error del catálogo y la diferencia, sumados en cuadratura); la fila de arriba enseña el error del catálogo."],
   ageTension: ["age in tension with its family", "edad en tensión con su familia"],
   ageTensionTip: ["Its age (at most %1 Gyr) is younger than the merger of its family, Gaia-Enceladus (its stars were born more than %2 Gyr ago): the age or the family is wrong.",
                   "Su edad (como mucho %1 Ga) es más joven que el choque de su familia, Gaia-Enceladus (sus estrellas nacieron hace más de %2 Ga): falla la edad o la familia."],
   cacheNote: ["answers from the offline cache", "respuestas de la caché sin red"],
   noFamilies: ["No pair of stars is chemically compatible here.", "Aquí ningún par de estrellas es químicamente compatible."],
   galaxyHome: ["its birth galaxy", "su galaxia natal"],
   // (30-oct, decisión C) con P < 0,8 (ccFamFirm) no se afirma el nacimiento
   galaxyHomeMaybe: ["compatible with its orbit", "compatible con su órbita"],
   // (30-oct, N1 + D1-H5, decisión B) astrometría dudosa: la órbita se queda con este aviso, sin familia. %1 = RUWE 3,10 · distancia ± 34 %
   astroDoubt: ["doubtful astrometry (%1): orbit only indicative, no family", "astrometría dudosa (%1): órbita orientativa, sin familia"],
   astroDoubtTip: ["Gaia's fit of this star is poor (RUWE of 1.4 or more, often a close companion) or its distance has more than 20 % error. The orbit is computed all the same, but it may be far from the real one, so it gets no kinematic population and no family. The same rule as StellarPopulations.",
                   "El ajuste de Gaia a esta estrella es malo (RUWE de 1,4 o más, a menudo una compañera cercana) o su distancia tiene más de un 20 % de error. La órbita se calcula igual, pero puede estar lejos de la real: por eso no lleva población cinemática ni familia. La misma regla que StellarPopulations."],
   dynFamNone: ["not assigned", "sin asignar"],
   dynFamNoneNote: ["doubtful astrometry", "astrometría dudosa"],
   kinDoubtRuwe: ["doubtful astrometry (RUWE ≥ 1.4)", "astrometría dudosa (RUWE ≥ 1,4)"],
   kinUnbound: ["not bound: its velocity is in doubt", "no ligada: su velocidad está en duda"],
   // (30-oct, N2) E ≥ 0
   unboundWarn: ["unbound with these data: probably a bad value", "no ligada con estos datos: probablemente un dato malo"],
   unboundTip: ["With this distance and these velocities its total energy is positive: it would leave the Galaxy. Real escaping stars are extremely rare, so it is far more likely that the radial velocity or the distance is wrong. It gets no orbit, no kinematic population and no family.",
                "Con esta distancia y estas velocidades su energía total es positiva: se iría de la Galaxia. Las estrellas que escapan de verdad son rarísimas, así que es mucho más probable que esté mal la velocidad radial o la distancia. No lleva órbita, ni población cinemática, ni familia."],
   // (30-oct, D1-H4, decisión D) la RV de Gaia DR3
   rvCorrKatz: ["Katz+23 %1 km/s", "Katz+23 %1 km/s"],
   rvCorrBlomme: ["Blomme+23 %1 km/s", "Blomme+23 %1 km/s"],
   rvCorrNone: ["uncorrected", "sin corregir"],
   rvCorrTip: ["Gaia DR3 radial velocities carry a bias that grows with the star's faintness. It is removed as Gaia recommends (Katz et al. 2023; Blomme et al. 2023 for hot stars); catalogue value %1 km/s. The same in all four scripts.",
               "Las velocidades radiales de Gaia DR3 llevan un sesgo que crece con lo débil que es la estrella. Se quita como recomienda Gaia (Katz et al. 2023; Blomme et al. 2023 en las calientes); valor del catálogo %1 km/s. Igual en los cuatro scripts."],
   rvCorrNoneTip: ["Uncorrected: the bias of Gaia's radial velocities could not be removed because its RVS magnitude or template temperature is missing.",
                   "Sin corregir: no se pudo quitar el sesgo de las velocidades radiales de Gaia porque falta su magnitud RVS o la temperatura de su plantilla."]
};
// Los catálogos y las edades con nombre llano en cada idioma (la clave es la de cc_catalogs/cc_engine).
var CC_CAT_NAMES = {
   count: ["Gaia DR3 · stars in the frame", "Gaia DR3 · estrellas del encuadre"], galah: ["GALAH DR4", "GALAH DR4"], apogee: ["APOGEE DR17", "APOGEE DR17"],
   lamost: ["LAMOST DR11 (low resolution)", "LAMOST DR11 (baja resolución)"], x19: ["LAMOST DR5 abundances (Xiang+19)", "LAMOST DR5: abundancias (Xiang+19)"],
   gspspec: ["Gaia DR3 GSP-Spec", "Gaia DR3 GSP-Spec"], xpg: ["Gaia XP: metal-poor giants", "Gaia XP: gigantes pobres en metales"],
   gaia: ["Gaia DR3 + distances + FLAME", "Gaia DR3 + distancias + FLAME"], xr22: ["Subgiant ages (Xiang & Rix 22)", "Edades de subgigantes (Xiang & Rix 22)"],
   anders: ["APOGEE ages (Anders+23)", "Edades APOGEE (Anders+23)"], boin: ["Isochrone ages (Boin+26)", "Edades por isócronas (Boin+26)"],
   kord: ["Orbits and ages (Kordopatis+23)", "Órbitas y edades (Kordopatis+23)"]
};
function ccCatName(key, fallback) { var e = CC_CAT_NAMES[key]; return e ? e[CC_LANG === "es" ? 1 : 0] : (fallback || key); }
var CC_AGE_NAMES = {
   xr22: ["Xiang & Rix 22 (subgiants)", "Xiang & Rix 22 (subgigantes)"], anders23: ["Anders+23 (APOGEE, calibrated with asteroseismology)", "Anders+23 (APOGEE, calibrada con sismología)"],
   boin: ["Boin+26 (isochrones, 5 model grids)", "Boin+26 (isócronas, 5 rejillas de modelos)"], kord23: ["Kordopatis+23 (Gaia GSP-Spec isochrones)", "Kordopatis+23 (isócronas con Gaia GSP-Spec)"],
   "galah-iso": ["GALAH DR4 (isochrone, no error)", "GALAH DR4 (isócrona, sin error)"], flame: ["Gaia DR3 FLAME (solar-metallicity models)", "Gaia DR3 FLAME (modelos de metalicidad solar)"]
};
function ccAgeName(src) { var e = CC_AGE_NAMES[src]; return e ? e[CC_LANG === "es" ? 1 : 0] : src; }
// (2-nov-2026, S2 del vídeo de formación) El texto de tipB decía «46 000 estrellas de APOGEE» y la nube (CC_REF_ALPHA.n) tiene 40 990: el número
// ya no se escribe a mano, el texto lleva «%REFN» y sale de la constante, redondeado a 3 cifras como el pie del diagrama (cc_paint.js: «APOGEE DR17 (41 000)»).
// ROJO «refn46»: la cifra de antes, escrita a mano.
function ccRefNText(lang) {
   if (typeof ccBroken === "function" && ccBroken("refn46")) return lang === "es" ? "46 000" : "46,000";
   var n = (typeof CC_REF_ALPHA !== "undefined" && CC_REF_ALPHA) ? CC_REF_ALPHA.n : NaN;
   return ccIsNum(n) ? ccNice(n, lang, 3) : (lang === "es" ? "decenas de miles de" : "tens of thousands of");
}
function ccT(key) {
   var e = CC_TXT[key];
   if (!e) return key;
   var s = (CC_LANG === "es") ? e[1] : e[0];
   return (s.indexOf("%REFN") >= 0) ? s.replace("%REFN", ccRefNText(CC_LANG === "es" ? "es" : "en")) : s;
}

// (5-nov-2026) TOOLTIPS EN CAJAS DE ANCHO ACOTADO: todo tooltip de texto plano largo pasa por aquí (el común de CabraShared/csh_i18n.js:
// escapa, parte a ~72 letras y lo envuelve en <html>; el que ya trae etiquetas o es corto se queda igual). Se llama en CADA asignación,
// con el texto del idioma vigente: el cambio EN/ES en caliente vuelve a asignar y vuelve a partir.
function ccWrapTip(t) { return (typeof cshTipWrap === "function") ? cshTipWrap(t) : String(t === null || t === undefined ? "" : t); }

// (22-oct, integración de III) la glosa de la fila «Órbita» de la ficha (CC_GLOSS vive en cc_story.js, incluido antes que este fichero)
if (typeof CC_GLOSS !== "undefined" && !CC_GLOSS.orbit)
   CC_GLOSS.orbit = ["Its orbit round the Galactic centre, integrated 2 billion years in the same potential as the kinematic families, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023): closest (peri) and farthest (apo) distance from the centre, the greatest height above or below the disc (Zmax) and the eccentricity e (0 = circle). The same figures as its label in III · The Galaxy.",
                     "Su órbita alrededor del centro de la Galaxia, integrada 2000 millones de años en el mismo potencial que las familias cinemáticas, MilkyWayPotential2022 (gala, Price-Whelan 2017; Eilers et al. 2019; Darragh-Ford et al. 2023): la distancia más corta (peri) y más larga (apo) al centro, la mayor altura sobre o bajo el disco (Zmax) y la excentricidad e (0 = círculo). Las mismas cifras que su rótulo en III · La Galaxia."];

// (23-oct) EL LITIO: su nombre y la frase de su canal, tal cual las dejó la sesión del litio en docs/litio_y_mg_xiang.md §8 (fuentes allí: Spite & Spite
// 1982; Sbordone+10; Asplund+09; Iben 1967; Skumanich 1972; Pinsonneault 1997; Gao+19; Buder+25). Formato de CC_EL_OWN (cc_story.js): [corto EN, corto ES,
// largo EN, largo ES]. El litio vive en s.chem.li (no en s.chem.el): su modo propio en la foto y en B está en cc_paint.js (ccLiMode).
if (typeof CC_EL_NAME !== "undefined" && !CC_EL_NAME.Li) CC_EL_NAME.Li = ["lithium", "litio"];
// el litio no es «[Li/Fe]»: se da en absoluto, A(Li) (la etiqueta de cc_story.js, ccElLabel, cubierta aquí para el Li y nada más)
if (typeof ccElLabel === "function" && !ccElLabel.ccLi) { var ccElLabelBase = ccElLabel; ccElLabel = function(X) { return X === "Li" ? "A(Li)" : ccElLabelBase(X); }; ccElLabel.ccLi = true; }
if (typeof CC_EL_OWN !== "undefined" && !CC_EL_OWN.Li)
   CC_EL_OWN.Li = ["destroyed inside stars · a clock for dwarfs", "se destruye dentro de las estrellas · reloj de enanas",
                   "Lithium is not made inside stars the way iron or magnesium are: most of it was made in the Big Bang, and stars slowly destroy it, because it burns at about 2.5 million degrees and mixing carries it down to where it is that hot. So it is not compared with iron: its absolute amount, A(Li), is given instead. In a dwarf, the more lithium it keeps, the younger or hotter it is; giants have diluted almost all of it (below 1.5; above that it is a rarity). Benchmarks: the Sun’s surface today has 1.05; the gas the Sun formed from, 3.26; the oldest metal-poor stars all sit at 2.2 (the Spite plateau). A downward arrow is an upper limit: the lithium is at most that value.",
                   "El litio no se fabrica en las estrellas como el hierro o el magnesio: casi todo nació en el Big Bang y las estrellas lo van destruyendo, porque arde a unos 2,5 millones de grados y la mezcla lo baja hasta donde hace ese calor. Por eso no se compara con el hierro: se da su cantidad absoluta, A(Li). En una enana, cuanto más litio conserva, más joven o más caliente es; las gigantes lo han diluido casi todo (por debajo de 1,5; si pasa de ahí, es una rareza). Referencias: la superficie del Sol hoy tiene 1,05; el gas del que nació el Sol, 3,26; las estrellas más viejas y pobres en metales se quedan todas en 2,2 (la meseta de Spite). Una flecha hacia abajo es un límite: el litio es como mucho ese valor."];
