#ifndef __CC_JOURNEY_I18N_JS
#define __CC_JOURNEY_I18N_JS
// ============================================================================
// src/ui/cc_journey_i18n.js — las cadenas EN / ES de II · VIAJE Y VÍDEO (fase 2a, 22-oct-2026)
// ----------------------------------------------------------------------------
// MISMO FORMATO que CC_TXT de src/cc_i18n.js ({ clave: [en, es] }), con prefijo «j» para que se puedan FUSIONAR sin
// chocar (el integrador puede copiar este bloque dentro de CC_TXT y dejar ccJT como alias de ccT). ccJT(clave, a1, a2…)
// cambia %1, %2… por los argumentos. Sin clave aquí, cae a ccT (las del diálogo). ES5.
// ============================================================================
var CC_JTXT = {
   // --- el grupo (la cabecera la pinta el armazón; estas, por si el integrador las quiere) ---
   jGrp: ["JOURNEY AND VIDEO", "VIAJE Y VÍDEO"],
   // (29-oct, Nino: «La Galaxia en el tiempo» se mudó a III · La Galaxia —en II aparecía la Galaxia de la nada—: II cuenta el CAMPO)
   jGrpSub: ["the story of the field and a grand tour, as a video", "la historia del campo y un gran recorrido, en vídeo"],
   // --- los mandos ---
   jModeHistory: ["The story of the field", "La historia del campo"],
   jModeTour: ["Grand tour", "Gran recorrido"],
   jModeOrbits: ["The Galaxy through time", "La Galaxia en el tiempo"],      // (23-oct: sustituye a «Órbitas»; la clave del modo sigue siendo «orbits»; 29-oct: vive en III)
   jModeTip: ["The story of the field: time runs from the Big Bang to today and each star lights up when it was born (in the photo and in the three diagrams); the episodes of the Galaxy are named as they pass. Grand tour: a stop at each remarkable star of the field (the oldest with a reliable age, the most metal-poor, an accreted one, the highest α, the closest solar twin, the youngest), with its name plate. (The video of the stars orbiting the Milky Way, “The Galaxy through time”, is in III · The Galaxy.)",
              "La historia del campo: el tiempo corre del Big Bang a hoy y cada estrella se enciende al nacer (en la foto y en los tres diagramas); los episodios de la Galaxia se rotulan al pasar. Gran recorrido: una parada en cada estrella notable del campo (la más vieja con edad fiable, la más pobre, una acretada, la de α más alta, la gemela solar más parecida, la más joven), con su placa. (El vídeo de las estrellas orbitando la Vía Láctea, «La Galaxia en el tiempo», está en III · La Galaxia.)"],
   jPreview: ["Preview", "Vista previa"],
   jDragTip: ["Drag the hand to travel in time (or click on the dial to jump there). The preview carries on from there when you let go.", "Arrastra la manecilla para viajar en el tiempo (o pulsa en la esfera para saltar allí). Al soltar, la vista previa sigue desde ahí."],      // (26-oct, la manecilla que se arrastra)
   jStop: ["Stop", "Parar"],
   jRecord: ["Record", "Grabar"],
   jCancel: ["Cancel", "Cancelar"],
   jPreviewTip: ["Plays the main part of the video in real time at the top of the middle column (the photo with its clock and plate); the photo of the window is not touched. The diagrams below and the timeline under the photo follow the clock of the video: only the stars already born, and the cursor at its instant. The recording keeps the whole layout. A click on the preview (or ■ Stop) stops it.",
                 "Reproduce a tiempo real la parte principal del vídeo arriba de la columna del medio (la foto con su reloj y su placa); la foto de la ventana no se toca. Los diagramas de debajo y la línea de tiempo bajo la foto siguen el reloj del vídeo: solo las estrellas ya nacidas, y el cursor en su instante. La grabación lleva la maqueta entera. Un clic en la vista previa (o ■ Parar) la para."],
   // --- III · La Galaxia: el vídeo «La Galaxia en el tiempo» (29-oct; los mismos mandos y la misma grabadora que II) ---
   jGxVideo: ["Video", "Vídeo"],
   jGxVideoTip: ["“The Galaxy through time”: from the Big Bang to today the stars of the field are born and travel along their orbits round the Milky Way, with the episodes of the Galaxy named as they pass, and with the view (from above, edge-on or 3D, the camera turning) and the colours chosen above. The clock runs fast through the distant past and slows to orbit speed over the last 200 million years; past positions are illustrative (computed with today's Galaxy).",
                 "«La Galaxia en el tiempo»: del Big Bang a hoy las estrellas del campo nacen y recorren sus órbitas alrededor de la Vía Láctea, con los episodios de la Galaxia rotulados al pasar y con la vista (desde arriba, de canto o en 3D, con la cámara girando) y los colores elegidos arriba. El reloj corre deprisa por el pasado lejano y frena a la velocidad de las órbitas en los últimos 200 millones de años; las posiciones pasadas son ilustrativas (se calculan con la Galaxia de hoy)."],
   jPreviewTipGx: ["Plays “The Galaxy through time” in real time in the middle column, in place of the map; the photo is not touched. The Time ruler on its left follows its clock, and dragging the ruler (or the hand of the clock) travels in time. A click on the preview (or ■ Stop) stops it and the map stays at that instant.",
                   "Reproduce «La Galaxia en el tiempo» a tiempo real en la columna del medio, en el sitio del mapa; la foto no se toca. La regla «Tiempo», a su izquierda, sigue su reloj, y arrastrar la regla (o la manecilla del reloj) viaja en el tiempo. Un clic en la vista previa (o ■ Parar) la para y el mapa se queda en ese instante."],
   jRecordTipGx: ["Records “The Galaxy through time” as a video, with the view and colours chosen above and what is chosen under ▾. Now: %1, %2 fps, to %3.", "Graba «La Galaxia en el tiempo» como vídeo, con la vista y los colores elegidos arriba y lo elegido en ▾. Ahora: %1, %2 fps, en %3."],
   jBusyOther: ["Another video is being recorded: wait for it to finish (or ■ Cancel it).", "Se está grabando otro vídeo: espera a que acabe (o ■ Cancélalo)."],
   jOptTip: ["Video options: size, frame rate, title, folder and format (AVI, or MP4 with ffmpeg).", "Opciones del vídeo: tamaño, fotogramas por segundo, título, carpeta y formato (AVI, o MP4 con ffmpeg)."],
   jSize: ["Size", "Tamaño"],
   jTitle: ["Title", "Título"],
   jSaveTo: ["Save to", "Guardar en"],
   jSizeTip: ["The size of the video: 16:9 (normal), square or vertical for social networks (the frame is laid out for that shape).",
              "El tamaño del vídeo: 16:9 (normal), cuadrado o vertical para redes (el fotograma se compone para esa forma)."],
   jFpsTip: ["Frames per second.", "Fotogramas por segundo."],
   jTitleTip: ["The title shown at the start of the video (by default, the name of the image).", "El título que sale al principio del vídeo (de fábrica, el nombre de la imagen)."],
   jDirTip: ["The folder for the video (remembered).", "La carpeta del vídeo (se recuerda)."],
   jRecordTip: ["Records the chosen mode as a video, with what is chosen under ▾. Now: %1, %2 fps, to %3.", "Graba el modo elegido como vídeo, con lo elegido en ▾. Ahora: %1, %2 fps, en %3."],
   jFmtMp4: ["Format: MP4 (H.264).", "Formato: MP4 (H.264)."],
   // (3-nov-2026, CPD SC3) el formato y ffmpeg SOLO si el usuario lo elige (CabraShared/csh_ffmpeg.js; los textos EN son los de CSH_FFMPEG_TEXT y de FieldDepth3D)
   jFmtAviOff: ["Format: AVI (Motion JPEG). For MP4, choose ffmpeg in ▾ Format.", "Formato: AVI (Motion JPEG). Para MP4, elige ffmpeg en ▾ Formato."],
   jFmtAviNotFound: ["Format: AVI (Motion JPEG): ffmpeg was not found.", "Formato: AVI (Motion JPEG): no se ha encontrado ffmpeg."],
   jFmt: ["Format", "Formato"],
   jFf_off: ["AVI (no ffmpeg)", "AVI (sin ffmpeg)"],
   jFf_manual: ["MP4 · ffmpeg chosen by me…", "MP4 · el ffmpeg que yo elija…"],
   jFf_auto: ["MP4 · find ffmpeg for me", "MP4 · que busque ffmpeg solo"],
   jFmtTip: ["Video format. “AVI (no ffmpeg)” (default): the script writes the video itself, Motion JPEG, nothing else is needed. “MP4 · ffmpeg chosen by me”: you pick the ffmpeg executable with “…” and it turns the recorded AVI into MP4 (H.264, what phones and social networks play). “MP4 · find ffmpeg for me”: the script looks for ffmpeg in CABRAPILOT_FFMPEG, the last path found, the PATH and, on Windows, the winget folders. ffmpeg is a free program that is not part of this script, and it is only run if you choose one of the two MP4 options. Remembered (the same for the videos of II and III).",
             "Formato del vídeo. «AVI (sin ffmpeg)» (de fábrica): el script escribe el vídeo él solo, en Motion JPEG, sin nada más. «MP4 · el ffmpeg que yo elija»: eliges el ejecutable de ffmpeg con «…» y pasa el AVI grabado a MP4 (H.264, lo que abren móviles y redes). «MP4 · que busque ffmpeg solo»: el script busca ffmpeg en CABRAPILOT_FFMPEG, la última ruta encontrada, el PATH y, en Windows, las carpetas de winget. ffmpeg es un programa gratuito que no forma parte de este script, y solo se ejecuta si eliges una de las dos opciones MP4. Se recuerda (el mismo para los vídeos de II y III)."],
   jFfPickTip: ["Choose the ffmpeg executable (ffmpeg.exe on Windows). Used with “MP4 · ffmpeg chosen by me”. Remembered.", "Elige el ejecutable de ffmpeg (ffmpeg.exe en Windows). Se usa con «MP4 · el ffmpeg que yo elija». Se recuerda."],
   jSheetNote: ["A contact sheet (12 frames, PNG) is saved next to it.", "Al lado se guarda una hoja de contacto (12 fotogramas, PNG)."],
   jFolderCaption: ["Folder for the video", "Carpeta del vídeo"],
   jAskStop: ["Stop the recording?", "¿Parar la grabación?"],
   jAskKeep: ["Keep what was recorded (%1 s)", "Quedarse con lo grabado (%1 s)"],
   jAskDelete: ["Delete it", "Borrarla"],
   jAskContinue: ["Continue recording", "Seguir grabando"],
   // --- las líneas de ayuda y de estado ---
   jHintHistory: ["Time runs from the Big Bang to today: each star of the photo lights up when it was born.", "El tiempo corre del Big Bang a hoy: cada estrella de la foto se enciende al nacer."],
   jHintTour: ["A stop at each remarkable star of the field, with its plate (%1).", "Una parada en cada estrella notable del campo, con su placa (%1)."],
   jHintOrbits: ["From the Big Bang to today: %1 stars are born and orbit the Milky Way, with the view and colours above (%2 · %3).", "Del Big Bang a hoy: %1 estrellas nacen y orbitan la Vía Láctea, con la vista y los colores de arriba (%2 · %3)."],
   jNoOrbits: ["No star of this field has an orbit (it needs radial velocity and distance): “The Galaxy through time” has nothing to move.", "Ninguna estrella de este campo tiene órbita (hace falta velocidad radial y distancia): «La Galaxia en el tiempo» no tiene nada que mover."],
   jNoGalaxy: ["“The Galaxy through time” needs III · The Galaxy (not included in this script).", "«La Galaxia en el tiempo» necesita III · La Galaxia (no está incluida en este script)."],
   jNeedAnalysis: ["Analyse the image first: the video tells the story of its stars.", "Analiza antes la imagen: el vídeo cuenta la historia de sus estrellas."],
   jNoAges: ["No star of this field has a measured age: “The story of the field” has nothing to light up.", "Ninguna estrella de este campo tiene edad medida: «La historia del campo» no tiene nada que encender."],
   jNoStops: ["No star of this field meets any criterion of the tour (reliable age, well-measured metals, accreted, α, solar twin).", "Ninguna estrella de este campo cumple ningún criterio del recorrido (edad fiable, metales bien medidos, acretada, α, gemela solar)."],
   jBusy: ["Wait for the analysis to finish.", "Espera a que acabe el análisis."],
   jPreviewing: ["Preview of “%1” (%2 s), in the middle column: a click on it stops it.", "Vista previa de «%1» (%2 s), en la columna del medio: un clic en ella la para."],
   jRecording: ["Recording “%1” to %2", "Grabando «%1» en %2"],
   jPaused: ["Recording paused.", "Grabación en pausa."],
   jEncoding: ["Encoding the video (H.264)…", "Codificando el vídeo (H.264)…"],
   jEncodingStop: ["“■ Cancel” stops it.", "«■ Cancelar» lo para."],
   jEncodingCancel: ["Cancelling the encoding…", "Cancelando la codificación…"],
   jSaved: ["Video saved: %1 (%2 MB, %3 frames, %4 s)", "Vídeo guardado: %1 (%2 MB, %3 fotogramas, %4 s)"],
   jContact: ["contact sheet", "hoja de contacto"],
   jCancelled: ["Recording cancelled: nothing was saved.", "Grabación cancelada: no se ha guardado nada."],
   jFailed: ["Could not record the video", "No se pudo grabar el vídeo"],
   jChooseDir: ["Choose a folder for the video (▾).", "Elige una carpeta para el vídeo (▾)."],
   jFrames: ["%1 of %2 frames", "%1 de %2 fotogramas"],
   jLeft: ["about %1 left", "quedan unos %1"],
   jContactInfo: ["%1 · %2×%3 · %4 fps · %5 frames", "%1 · %2×%3 · %4 fps · %5 fotogramas"],
   // --- lo que se pinta en el fotograma ---
   jEyebrowHistory: ["The story of the field", "La historia del campo"],
   jEyebrowTour: ["Grand tour", "Gran recorrido"],
   jHistorySub: ["Each star lights up when it was born · %1 with a measured age", "Cada estrella se enciende al nacer · %1 con edad medida"],
   jTourSub: ["%1 stops: %2", "%1 paradas: %2"],
   jTourSub1: ["1 stop: %1", "1 parada: %1"],
   jCosmicClock: ["Cosmic clock", "Reloj cósmico"],
   jTodayWord: ["today", "hoy"],
   jGalaxyThen: ["The Galaxy, then", "La Galaxia, entonces"],
   jAlso: ["also: %1", "también: %1"],
   // (23-oct, noche, revisión visual 2: la placa decía «23 de 61 … · 91 sin edad» y la de III «… · 63 sin edad» con la MISMA frase y dos
   //  conjuntos distintos —152 con química, 124 con órbita—; ahora cada frase dice de qué conjunto habla. %3 = las de la foto con química)
   jBornCount: ["Of the %3 with chemistry: %1 of %2 with an age already born", "De las %3 con química: %1 de %2 con edad ya han nacido"],
   jNoAgeNote: ["%1 without an age: they never light up", "%1 sin edad: no se encienden"],
   // (23-oct, revisor R20: la placa final decía «HOY» + «Hoy: …» con el reloj diciendo «hoy» al lado; ahora la placa es «La Galaxia, ahora»)
   jTodayName: ["Every star of the field with an age, lit", "Todas las estrellas del campo con edad, encendidas"],
   jGalaxyNow: ["The Galaxy, now", "La Galaxia, ahora"],
   jRole_oldest: ["The oldest with a reliable age", "La más vieja con edad fiable"],
   jRole_poorest: ["The most metal-poor, well measured", "La más pobre en metales, bien medida"],
   jRole_accreted: ["An accreted star", "Una estrella acretada"],
   jRole_alpha: ["The highest α", "La de α más alta"],
   jRole_twin: ["The closest solar twin", "La gemela solar más parecida"],
   jRole_youngest: ["The youngest with a reliable age", "La más joven con edad fiable"],
   jRoleShort_oldest: ["the oldest", "la más vieja"],
   jRoleShort_poorest: ["the most metal-poor", "la más pobre"],
   jRoleShort_accreted: ["an accreted one", "una acretada"],
   jRoleShort_alpha: ["the highest α", "la de α más alta"],
   jRoleShort_twin: ["the solar twin", "la gemela solar"],
   jRoleShort_youngest: ["the youngest", "la más joven"],
   jStopN: ["stop %1 of %2", "parada %1 de %2"],
   jLy: ["%1 light years away", "a %1 años luz"],
   jTimeline: ["Timeline", "Línea de tiempo"]
};
function ccJT(key) {
   var e = CC_JTXT[key], t;
   // (costura de la sonda: jlang = las cadenas de aquí siempre en inglés, para ver en ROJO la mezcla de idiomas)
   if (e) t = (typeof CC_LANG !== "undefined" && CC_LANG === "es" && !(typeof CC_BREAK === "string" && CC_BREAK.indexOf("jlang") >= 0)) ? e[1] : e[0];
   else t = (typeof ccT === "function") ? ccT(key) : key;
   for (var i = 1; i < arguments.length; ++i) t = t.split("%" + i).join(String(arguments[i]));
   if (key === "jBornCount" && typeof CC_BREAK === "string" && CC_BREAK.indexOf("oldborn") >= 0 && t.indexOf(": ") > 0) t = t.substring(t.indexOf(": ") + 2);     // (ROJO «oldborn» de T22)
   return t;
}
// (3-nov-2026, CPD SC3) el título del selector de ffmpeg lo pone CabraShared/csh_ffmpeg.js con cshT (su tabla CSH_ES aún no lo trae): en castellano, aquí.
// PENDIENTE: pasarlo a CSH_ES de csh_i18n.js cuando StellarPopulations adopte csh_ffmpeg.js (así no lo repite cada script).
try { if (typeof CSH_ES === "object" && CSH_ES && !CSH_ES["Choose the ffmpeg executable"]) CSH_ES["Choose the ffmpeg executable"] = "Elige el ejecutable de ffmpeg"; } catch (eCshEs) {}
#endif
