// ============================================================================
// src/cc_pixinsight.js — LO QUE TOCA PIXINSIGHT: red (curl), caché, la imagen
// ----------------------------------------------------------------------------
//   ccHttpTap( adql, key, opts ) -> { ok, text, ms, message, cached }
//      POST a TAPVizieR con curl (la consulta va en un FICHERO: --data-urlencode
//      QUERY@fichero; así no hay comillas que pelear en la línea de órdenes).
//      Con curl y no con NetworkTransfer porque NetworkTransfer no corta una
//      respuesta lenta (su plazo es solo el de conexión: CabraBase/pjsr/
//      networktransfer-plazos-y-502.md) ni deja dar señal de vida.
//      Caché en disco por consulta (hash FNV-1a del ADQL): lo ya preguntado se
//      reabre sin red. opts: { refresh, timeoutS, onTick(ms), replayDir }.
//   ccFieldFromView( view ) -> field (cc_field.js) | { ok:false, code }
//   ccSolveView( view ) -> { ok, message }   (ImageSolver, UN intento automático)
//   ccPhotoBitmap( view, maxW ) -> { bitmap, factor, stretched, mono }
//   ccViewInfo( view ) -> { mono, linear?, spcc, channels }
//
// Procedencia: la espera de curl con tope y señal de vida es la de CabraPilot
// `engine/starfield_run.js` (cpSfHttpText); el auto-STF, `engine/stf.js`
// (cpStfMtf, cpStfFindMidtones, cpStfCompute); el intento de ImageSolver,
// `engine/astrometry.js` (cpSolveAstrometry), sin el segundo diálogo modal.
// ES5 (salvo lo que exige la librería ImageSolver, incluida desde el principal).
// ============================================================================

// (3-nov-2026, CPD SC2) EL curl DE CADA SISTEMA: el comun de CabraShared (csh_net.js cshCurlPath: %SystemRoot%/System32/curl.exe en Windows,
// /usr/bin/curl en macOS, /usr/bin|/bin|/usr/local/bin/curl en Linux; "" si no hay). Antes, "C:/Windows/System32/curl.exe" fijo: en macOS y Linux
// StellarChemistry no tenia red. CC_CURL sigue siendo el nombre de siempre (las pruebas lo leen o lo cambian) y vale lo que CSH_CURL.
var CC_CURL = CSH_CURL;
function ccHasCurl() { try { return String(CC_CURL || "").length > 0 && File.exists(CC_CURL); } catch (e) { return false; } }
var CC_HTTP_TIMEOUT_S = 60;      // diseño: la consulta más lenta medida fue de 4,9 s (Boin en M 67, tres tablas)
var CC_HTTP_HOOK = null;          // pruebas: function(adql, key, opts) -> respuesta, EN VEZ de la red
var CC_TRACE = false;             // rastro de tiempos del diálogo (pruebas)
var CC_ABORT = false;             // al cerrar: la descarga en curso se mata y no se lanza ninguna más
var CC_QUIET = false;             // la «zona tranquila»: con un proceso en marcha los manejadores no pintan
var CC_CONNECT_S = 10;            // plazo de CONEXIÓN de curl (el de siempre)
var CC_RETRY_PAUSE_MS = 1000;     // pausa antes del reintento (F2.2 de CabraShared: curl --retry-delay 1)
var CC_CACHE_OLD_DIR = null;      // (sin uso desde el 3-nov, CPD SC5: ya no se lee la caché vieja; se deja el nombre para las pruebas que lo ponen)
var CC_NET_LOG = null;            // pruebas: un array donde se apunta cada intento { url, key, kind, code, ms }
// CONTROLES EN ROJO (pruebas): CC_BREAK=nojudge,exit28,noretry,retrysilent,nofollow (separados por comas). («noold» ya no hace nada: no hay caché vieja.)
// Cada uno desmonta UN arreglo de F2 para ver su prueba en rojo.
function ccBreak(name) { return ("," + "" + ",").indexOf("," + name + ",") >= 0; }
// Los del lote (22-oct, noche) se inyectan también con la variable global CC_BREAK de cc_dialog.js (T14 de cc_pi_test.js):
//   serial = una consulta cada vez · nokill = al cerrar no se matan los curl del lote · nomirrorcache = lo del espejo no se guarda
function ccBrk(name) { return ccBreak(name) || (typeof ccBroken === "function" && ccBroken(name)); }

function ccHash(s) {
   var h = 2166136261, t = String(s);
   for (var i = 0; i < t.length; ++i) { h ^= t.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
   return ("00000000" + h.toString(16)).slice(-8);
}
function ccSlashes(p) { return String(p).split("\\").join("/"); }
function ccMkdirs(dir) {
   var d = ccSlashes(dir).replace(/\/+$/, "");
   if (File.directoryExists(d)) return true;
   try { File.createDirectory(d, true); } catch (e) {}     // (con barra final crea Y lanza: CabraBase/pjsr/trampas-del-arnes-pjsr.md)
   return File.directoryExists(d);
}
// LA CACHÉ (F2.6 de CabraShared): la carpeta común de los scripts, <caché común>/cabracomposition/ (`cshCacheRoot` de csh_net.js:
// %LOCALAPPDATA%\CabraScripts\cache en Windows, ~/Library/Caches/CabraScripts/cache en macOS, $XDG_CACHE_HOME o ~/.cache/CabraScripts/cache
// en Linux; no %TEMP%, que Windows limpia). Un fichero por consulta: <clave>_<FNV del ADQL>.csv.
// (3-nov-2026, CPD SC4, reglas 4.6/6.3: comprobación de integridad al leer la caché) cada fichero va SELLADO con su huella SHA-256 y su
// tamaño (cshCacheSave / cshCacheLoad de csh_net.js, la de todos los scripts). Al leerlo se comprueba: si no cuadra (un byte cambiado,
// cortado) se BORRA y la consulta se vuelve a pedir. Un fichero de antes del 3-nov (sin sello) no se puede comprobar: se descarta (una
// vez) y se vuelve a pedir. Además, como antes, solo vale si es una tabla (ccCacheGood).
// (3-nov-2026, CPD SC5) Ya NO se lee la caché VIEJA ~/.cabracomposition/cache (una carpeta en el home del usuario, sin integridad, sin
// documentar): lo que solo estuviera allí se vuelve a pedir una vez. Esa carpeta no se borra (es del usuario; se dice en la ayuda).
function ccCacheDir() {
   var d = ccSlashes(cshCacheRoot()).replace(/\/+$/, "") + "/cabracomposition";
   ccMkdirs(d);
   return d;
}
// ¿Es una respuesta de verdad lo que hay en un fichero de la caché? (antes se guardaba cualquier 200 que no dijera VOTABLE:
// una página HTML de una pasarela caída habría quedado como «dato»). El mismo juicio que a una respuesta de la red.
function ccCacheGood(text) { return cshNfJudge({ ok: true, code: 200, text: String(text || "") }, null).ok; }
function ccCacheRead(name) {
   try {
      var ld = cshCacheLoad(ccCacheDir() + "/" + name);         // (sello SHA-256 + tamaño; si no cuadra lo borra: why "integrity" | "legacy")
      if (ld.ok && ccCacheGood(ld.text)) return ld.text;
   } catch (e) {}
   return null;
}
function ccCacheWrite(name, text) { try { return cshCacheSave(ccCacheDir() + "/" + name, text) === true; } catch (e) { return false; } }

// El servidor de las consultas (para decir QUIÉN no contesta).
function ccTapHost() { var m = /^https?:\/\/([^\/]+)/.exec(String(CC_TAP_URL)); return m ? m[1] : String(CC_TAP_URL); }

// ---------------------------------------------------------------------------
// UNA PETICIÓN con curl y su JUICIO (F2.1 de CabraShared, `cshNfJudge`): una respuesta HTTP 200 que es un VOTable de
// error, una página HTML o un cuerpo vacío es un FALLO DEL SERVIDOR («bad»), no «ningún catálogo cubre este campo».
// `args` son los argumentos de curl SIN el fichero de salida `of`. -> { ok, text, code, exit, ms, message, aborted,
//   kind: "" | "timeout" | "offline" | "http" | "bad" | "aborted", netFail, netWhy: "" | "timeout" | "connect" | "http" | "bad" }
//   netFail = no se pudo PREGUNTAR (red, plazo, 5xx, 408/429 o respuesta que no es una tabla); un 4xx es la consulta.
// ---------------------------------------------------------------------------
function ccAttempt(args, of, limitS, o) {
   var t0 = Date.now(), c = null, msg = "";
   var saveCurl = CSH_CURL; CSH_CURL = CC_CURL;
   try {
      // (la espera de curl es la COMUN, ../CabraShared/csh_net.js: tope, señal de vida cada 200 ms, corte al cerrar con CC_ABORT)
      c = cshCurlRun(args.concat(["-o", of]), { timeoutS: limitS, waitMs: 100, pump: false, tickMs: 200, onTick: o.onTick, abort: function() { return CC_ABORT === true; } });
   } catch (e) { msg = String(e.message || e); } finally { CSH_CURL = saveCurl; }
   return ccAttemptJudge(c, of, limitS, t0, msg);
}
// El juicio de UN curl ya acabado (el de ccAttempt; lo usa también el lote, ccHttpBatch, con sus curl no bloqueantes).
//   c = { exit, code, cut, aborted, message } como lo devuelve cshCurlRun (null = no arrancó).
function ccAttemptJudge(c, of, limitS, t0, msg) {
   var out = { ok: false, text: "", code: 0, exit: -1, ms: 0, message: msg || "", aborted: false, kind: "", netFail: false, netWhy: "" };
   try { if (File.exists(of)) { out.text = File.readTextFile(of); File.remove(of); } } catch (eR) {}
   if (!c) { out.kind = "offline"; out.netFail = !CC_ABORT; out.netWhy = "connect"; out.ms = Date.now() - t0; return out; }
   out.exit = c.exit; out.code = c.code; out.aborted = (c.aborted === true);
   if (c.message) out.message = c.message;
   // curl que se rinde él mismo por su plazo (-m o --connect-timeout): «curl exit 28, HTTP 0». No llega al corte de cshCurlRun
   // (c.cut) y por el código sería «sin conexión»: es «no contesta» (F2, Cabra3D 22-oct-2026, tarde).
   var timedOut = (c.cut === true) || (c.exit === 28 && !ccBreak("exit28"));
   var j = cshNfJudge({ aborted: out.aborted, cut: timedOut, code: out.code, text: out.text }, null);
   if (ccBreak("nojudge") && !j.ok && j.kind === "bad") j = { ok: true, kind: "", why: "", http: out.code };   // (rojo: un 200 con error vale como respuesta)
   // (una respuesta completa solo si curl también acabó bien: con exit 18/56 la tabla llegaría cortada; y solo un 2xx: una
   //  redirección que no se siguió trae un cuerpo que no es la tabla)
   if (j.ok && out.exit !== 0) j = { ok: false, kind: "offline", why: "curl exit " + out.exit, http: out.code };
   else if (j.ok && !(out.code >= 200 && out.code < 300)) j = { ok: false, kind: "bad", why: "HTTP " + out.code + " (not followed)", http: out.code };
   out.ok = j.ok; out.kind = j.kind;
   if (out.aborted) out.message = "aborted";
   if (j.ok) { out.ms = Date.now() - t0; return out; }
   if (j.kind === "timeout") { out.netFail = true; out.netWhy = "timeout"; if (!out.message) out.message = c.cut ? "no answer in " + limitS + " s" : "no answer in time (curl exit " + out.exit + ")"; }
   else if (j.kind === "http") {
      out.netFail = (out.code >= 500 || out.code === 408 || out.code === 429);
      if (out.netFail) out.netWhy = "http";
      if (!out.message) out.message = "curl exit " + out.exit + ", HTTP " + out.code + (out.text ? " " + ccTapError(out.text) : "");
   }
   else if (j.kind === "bad") { out.netFail = true; out.netWhy = "bad"; if (!out.message) out.message = "HTTP " + out.code + ": " + j.why + (ccTapError(out.text) ? " · " + ccTapError(out.text) : ""); }
   else if (j.kind === "offline") { out.netFail = true; out.netWhy = "connect"; if (!out.message) out.message = "curl exit " + out.exit + ", HTTP " + out.code; }
   out.netFail = out.netFail && !CC_ABORT && !out.aborted;
   out.ms = Date.now() - t0;
   return out;
}

// ¿Un fallo PASAJERO que merece un reintento (F2.2: HTTP 5xx, 408/429, plazo de CONEXIÓN agotado, o una respuesta mala)?
// Un servidor que se queda callado hasta el tope (-m) NO se repite: doblaría la espera. Tampoco lo que tardó más que la ventana
// (plazo de conexión + 2 s), ni la consulta que el servidor rechaza (4xx), ni el cierre de la ventana.
function ccTransient(r, limitS) {
   if (r.ok || r.cached || r.aborted || !r.netFail) return false;
   if (ccBreak("noretry")) return false;
   if (ccBreak("retrysilent")) return true;                                   // (rojo: reintenta también al servidor callado)
   // (29-oct, noche) el CDS ya no conectó antes en esta sesión (CC_CDS, contado ANTES de este fallo): no se repite
   if (ccCdsStickyOn() && CC_CDS.fails >= 2 && (r.netWhy === "timeout" || r.netWhy === "connect")) return false;
   // (30-oct-2026) con espejos detrás, un plazo de conexión agotado tampoco se repite la primera vez (ver ccCdsShort): un 5xx rápido, sí
   if (ccCdsShort() && (r.netWhy === "timeout" || r.netWhy === "connect")) return false;
   if (r.ms > (CC_CONNECT_S + 2) * 1000) return false;
   if (r.netWhy === "timeout" && r.ms >= limitS * 1000 - 700) return false;   // se rindió por el tope total: callado
   return true;
}
// ---------------------------------------------------------------------------
// EL RESPALDO POR ESPEJO (F2): si TAPVizieR (CDS) no contesta, las mismas consultas van al ASU de un espejo de VizieR (cc_catalogs.js
// `ccAsuPlan`: IDIA y luego CfA, los dos por https; NAO, solo http, salió el 3-nov: CPD SC1) y llegan como el MISMO CSV (medido: tests/cc_node_asu.js, M 67, las 20 consultas, celda a celda).
// Solo para el TAPVizieR de verdad (CC_MIRROR_ON_URL): con otra URL en CC_TAP_URL —las pruebas con un servidor local— no hay espejo.
// ---------------------------------------------------------------------------
var CC_MIRROR_ON_URL = CC_TAP_URL;    // la URL cuyo fallo activa los espejos (pruebas: otra)
var CC_MIRROR_TIMEOUT_S = 120;        // plazo de CADA petición al espejo (los conos de Gaia son pesados)
var CC_DOWN_MS = 90000;               // tras un fallo del primario, a los espejos DIRECTOS durante este tiempo (no esperar su plazo en cada consulta)
var CC_RUN_GAP_MS = 6000;             // una pausa mayor entre dos consultas = otro análisis: se vuelve a probar el primario
var CC_NET = { downUntil: 0, lastFail: null, lastCall: 0, poly: null, memo: {}, mirror: "", viaMirror: 0, asked: 0 };
// (29-oct-2026, noche) LO QUE TARDA EN FRÍO. Medido (tests/cc_cold_probe.js, M 67, red real, caché vacía): 225,7 s, de los que el CDS caído
// fueron 23 s al empezar CADA análisis (10 s de conexión + 1 + 10 del reintento; ccNetReset borra la memoria en cada uno) y el resto,
// espejos callados (csh_batch.js, cshVzBatch: fanOut y stallS). Tres cosas nuevas:
//   · CC_MIRROR_STALL_S: un espejo que no manda ni un byte en 20 s se corta (los conos de Gaia más pesados de IDIA dan el primer byte
//     a los 0,78 s —medido—; CfA callado manda el primero a los 60,4 s y es vacío). El plazo total (CC_MIRROR_TIMEOUT_S) no cambia.
//   · LA MEMORIA DE SESIÓN DEL CDS (CC_CDS): si TAPVizieR no conectó en los últimos CC_DOWN_STICKY_MS, se le sigue preguntando en cada
//     análisis (nunca se salta: si vuelve, se usa), pero con CC_CONNECT_DOWN_S de plazo de conexión y SIN reintento. 5 s: con una SYN
//     perdida Windows la repite a los 3 s; una conexión sana al CDS tarda < 0,2 s. ccNetReset (cada análisis, «Reintentar») no la
//     borra; una respuesta buena del CDS, sí. Solo con el TAPVizieR de verdad (CC_STICKY_ON_URL): las pruebas con servidor local, no.
//   · El reintento del primer fallo ya no hace esperar a las demás consultas del lote: la primera en fallar reintenta (como antes); las
//     que fallan con ella van al espejo sin esperar (la memoria ya dice que el CDS no conecta).
// Costuras rojas: CC_BREAK=nostall (sin corte), nosticky (sin memoria de sesión), nofanout (espejos uno detrás de otro).
var CC_MIRROR_STALL_S = 20;
var CC_DOWN_STICKY_MS = 600000;
var CC_CONNECT_DOWN_S = 5;
var CC_STICKY_ON_URL = CC_TAP_URL;
var CC_CDS = { fails: 0, lastFail: 0 };
function ccStallS() { return ccBrk("nostall") ? 0 : CC_MIRROR_STALL_S; }
function ccStallArgs() { var s = ccStallS(); return (s > 0) ? ["--speed-limit", "1", "--speed-time", String(s)] : []; }
function ccCdsStickyOn() { return !ccBrk("nosticky") && String(CC_TAP_URL) === String(CC_STICKY_ON_URL); }
function ccCdsDown() {
   if (!ccCdsStickyOn()) return false;
   if (CC_CDS.fails > 0 && Date.now() - CC_CDS.lastFail > CC_DOWN_STICKY_MS) CC_CDS.fails = 0;
   return CC_CDS.fails > 0;
}
function ccCdsSeen(a) {
   if (!ccCdsStickyOn() || !a || a.aborted) return;
   if (a.ok) { CC_CDS.fails = 0; cshHealthClear("vizier"); return; }
   if (a.netFail && (a.netWhy === "timeout" || a.netWhy === "connect")) { ++CC_CDS.fails; CC_CDS.lastFail = Date.now(); cshHealthMark("vizier", a.netWhy); }
}
// (30-oct-2026) Con espejos detrás, siempre el plazo corto y sin repetir un plazo de conexión agotado (csh_net.js CSH_CDS_CONNECT_S; medido en Abell 39: 10 s los 8 del lote +
// 5 s del reintento de GALAH antes de preguntar a nadie más). Costura roja: CSH_NET_BREAK=noshortconn (como hasta hoy: 10 s y reintento mientras no haya memoria).
function ccCdsShort() { return ccCdsStickyOn() && ccMirrorEligible() && !cshNetBrk("noshortconn"); }
function ccCdsConnectS() { return (ccCdsDown() || ccCdsShort()) ? Math.min(CC_CONNECT_S, CC_CONNECT_DOWN_S) : CC_CONNECT_S; }
// (30-oct-2026) LA MEMORIA DEL DISCO (csh_net.js cshHealth*): cada Script > Execute empieza con CC_CDS y CC_NET vacíos y pagaba otra vez la espera al CDS. Si otro análisis u otro
// script lo vio caer hace menos de 10 min, se empieza directo por los espejos; lo que ellos no den se le pregunta al CDS al final (csh_batch.js mirrorEnd: nunca se le salta del todo).
function ccHealthSeed() {
   if (!ccCdsStickyOn() || !ccMirrorEligible() || CC_NET.downUntil > Date.now()) return;
   var u = cshHealthUntil("vizier");
   if (u > Date.now()) {
      CC_NET.downUntil = u;
      CC_NET.lastFail = { ok: false, text: "", ms: 0, message: "TAPVizieR did not answer a moment ago", cached: false, code: 0, host: ccTapHost(), server: ccTapHost(), kind: "offline", netFail: true, netWhy: "connect", fromDisk: true };
   }
}
// (30-oct-2026) EL ESPEJO CALLADO, TAMBIÉN EN DISCO. Medido en Abell 39: CfA calla 21 s con GALAH DR4 (y NAO y CfA con Kordopatis+23), en CADA análisis y en cada script, para acabar sin filas.
// Un espejo que no mandó ni un byte (exit 28) para una tabla: CC_MIRROR_SKIP_S sin preguntarle esa tabla; pasados, se le comprueba con CC_MIRROR_RECHECK_S en vez de CC_MIRROR_STALL_S, y si contesta se olvida.
// Tres versiones medidas el 30-oct. Saltarlo media hora perdía datos: en M 67, a la vez, CfA calló 21 s con GALAH DR4 a un análisis y al otro le dio 247 filas en 2,7 s (795 estrellas con catálogo frente a
// 857), y las pasadas siguientes se quedaban sin GALAH. Comprobarlo en CADA análisis costaba de más: Abell 39, la misma imagen otra vez, de 9 a 24 s para acabar. Hoy CfA contestó 2 de ~68.
// «Reintentar» lo olvida todo y le pregunta entero (ccNetForget). Lo demás de ese espejo sigue igual: NAO contesta a otras tablas. Costuras rojas: CC_BREAK=nosilent (sin memoria), silentskip (la versión que saltaba media hora).
var CC_MIRROR_SILENT_S = 1800, CC_MIRROR_SKIP_S = 300, CC_MIRROR_RECHECK_S = 8;
function ccMirrorKey(m, qs) {
   var t = /(?:^|&)-source=([^&]+)/.exec(String(qs));
   return t ? "ccmirror:" + m + "|" + decodeURIComponent(t[1]) : "";
}
function ccMirrorSilentSeen(m, qs, a) {
   if (ccBrk("nosilent") || !a) return;
   var k = ccMirrorKey(m, qs);
   if (!k) return;
   if (a.ok) { if (cshHealthUntil(k) > 0) cshHealthClear(k); }                 // (ha vuelto a contestar: se le espera entero otra vez)
   else if (a.exit === 28) cshHealthMark(k, "silent", CC_MIRROR_SILENT_S);
}
function ccMirrorStall(m, qs) {
   var full = ccStallS(), k = (full > 0 && !ccBrk("nosilent")) ? ccMirrorKey(m, qs) : "";
   return (k && cshHealthUntil(k) > 0) ? Math.min(full, CC_MIRROR_RECHECK_S) : full;
}
function ccMirrorSilent(m, adql) {
   if (ccBrk("nosilent")) return false;
   var keys = cshHealthKeys("ccmirror:" + m + "|"), s = String(adql), full = ccBrk("silentskip"), now = Date.now();
   for (var i = 0; i < keys.length; ++i) if (s.indexOf(keys[i].substring(keys[i].indexOf("|") + 1)) >= 0 && (full || now - cshHealthAt(keys[i]) < CC_MIRROR_SKIP_S * 1000)) return true;
   return false;
}
function ccNetForget() { cshHealthClearPrefix("ccmirror:"); cshHealthClear("vizier"); }      // («Reintentar»: se vuelve a preguntar a todos. NO al empezar cada análisis: eso es D.netReset)
// Para la interfaz: se puede llamar al empezar cada análisis y en «Reintentar» (si no, lo adivina por la pausa entre consultas).
function ccNetReset() { CC_NET.downUntil = 0; CC_NET.lastFail = null; CC_NET.memo = {}; CC_NET.mirror = ""; CC_NET.viaMirror = 0; CC_NET.asked = 0; ccHealthSeed(); }
// Lo que la interfaz puede decir: { mirror: "VizieR (CfA mirror)" | "", viaMirror: n consultas servidas por el espejo, primaryDown }
function ccNetStatus() { return { mirror: CC_NET.mirror, viaMirror: CC_NET.viaMirror, primaryDown: CC_NET.downUntil > Date.now() }; }
function ccMirrorEligible() { return !ccBreak("nomirror") && String(CC_TAP_URL) === String(CC_MIRROR_ON_URL); }
function ccNetNote(adql) {
   var now = Date.now();
   if (CC_NET.lastCall > 0 && now - CC_NET.lastCall > CC_RUN_GAP_MS) ccNetReset();
   var m = /POLYGON\('ICRS',([^)]*)\)/.exec(String(adql));
   if (m) {
      var n = m[1].split(","), poly = [], i;
      for (i = 0; i + 1 < n.length; i += 2) poly.push([parseFloat(n[i]), parseFloat(n[i + 1])]);
      if (poly.length >= 3) { var sig = m[1]; if (CC_NET.polySig !== sig) { CC_NET.memo = {}; CC_NET.polySig = sig; } CC_NET.poly = poly; }
   }
}
// Una consulta por los espejos -> { ok, text, server, rows, why }
// (29-oct-2026, motor unico) El bucle de espejos (con la regla de los 0 filas de Codex R2 H-1: vacío provisional, se pregunta al siguiente y solo
// si ninguno trae filas vale el vacío) es el COMÚN: cshVzMirrorAsk de ../CabraShared/csh_vizier.js (docs/motor-vizier-unico.md). Aquí solo lo de
// CabraComposition: su lista (CC_ASU_MIRRORS, con las tablas que un espejo no sirve), su memo (CC_NET.memo), su curl (ccAttempt, plazos de CC),
// su rastro (CC_NET_LOG) y su costura roja CC_BREAK=acceptempty. Los mensajes y el resultado son los de antes.
function ccMirrorTry(adql, key, o) {
   var out = { ok: false, text: "", server: "", why: "" }, plan = ccAsuPlan(adql, key, { poly: CC_NET.poly }), acc = ccBrk("acceptempty");
   if (!plan.ok) { out.why = "no mirror plan: " + plan.why; return out; }
   var mr = cshVzMirrorAsk(plan, ccAsuRequests(plan), { mirrors: CC_ASU_MIRRORS, adql: adql, memo: CC_NET.memo, acceptEmpty: acc, abort: function() { return CC_ABORT === true; },
      fetch: function(url, mm) {
         var a = ccAttempt(["-L", "--proto", "=https", "--proto-redir", "=https", "--max-redirs", "4", "--connect-timeout", String(CC_CONNECT_S), "-m", String(CC_MIRROR_TIMEOUT_S)].concat(ccStallArgs(), [url]),
                           ccSlashes(File.systemTempDirectory) + "/cc_m_" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ".tsv", CC_MIRROR_TIMEOUT_S, o);
         if (CC_NET_LOG) CC_NET_LOG.push({ url: mm.url, key: key, kind: a.kind || "ok", code: a.code, ms: a.ms, exit: a.exit, mirror: true });
         return a;
      } });
   if (mr.ok) { out.ok = true; out.text = mr.csv; out.server = mr.server; out.rows = mr.rows; if (mr.empty && !acc) out.empty = true; return out; }
   out.why = mr.why;
   return out;
}
function ccHttpTap(adql, key, opts) {
   var o = opts || {}, limitS = (o.timeoutS > 0) ? o.timeoutS : CC_HTTP_TIMEOUT_S;
   var live = (!CC_ABORT && !(o.replayDir) && typeof CC_HTTP_HOOK !== "function"), mirror = live && ccMirrorEligible();
   if (live) { ccNetNote(adql); ccHealthSeed(); }
   var down = mirror && CC_NET.downUntil > Date.now(), r;
   if (down) {
      // el primario cayó hace un momento: solo la caché (si la hay) y directo al espejo
      var oc = {}; for (var k0 in o) if (o.hasOwnProperty(k0)) oc[k0] = o[k0];
      oc.cacheOnly = true;
      r = ccHttpTapOnce(adql, key, oc);
      if (!r.ok && CC_NET.lastFail) { var lf = CC_NET.lastFail; r = { ok: false, text: "", ms: 0, message: lf.message, cached: false, code: lf.code, host: lf.host, server: lf.server, kind: lf.kind, netFail: lf.netFail, netWhy: lf.netWhy, skippedPrimary: true, fromDisk: lf.fromDisk === true }; }
   } else {
      r = ccHttpTapOnce(adql, key, o);
      if (live && ccTransient(r, limitS)) {
         var t = Date.now(); while (Date.now() - t < CC_RETRY_PAUSE_MS && !CC_ABORT) { try { CoreApplication.processEvents(); } catch (e) {} }
         if (CC_ABORT) return r;
         var r2 = ccHttpTapOnce(adql, key, o);
         r2.ms += r.ms; r2.retried = true; r2.firstMessage = r.message;
         r = r2;
      }
      if (mirror && r.ok && !r.cached) CC_NET.downUntil = 0;
      if (mirror && !r.ok && r.netFail) { CC_NET.downUntil = Date.now() + CC_DOWN_MS; CC_NET.lastFail = r; }
   }
   if (mirror && !r.ok && r.netFail && !CC_ABORT) {
      var t0 = Date.now(), mr = ccMirrorTry(adql, key, o);
      if (mr.ok) {
         CC_NET.mirror = mr.server; ++CC_NET.viaMirror;
         CC_NET.lastCall = Date.now();
         ccCacheMirror(adql, key, mr.text);
         return { ok: true, text: mr.text, ms: r.ms + (Date.now() - t0), message: "", cached: false, code: 200, host: mr.server, server: mr.server, mirror: mr.server, kind: "", netFail: false, netWhy: "", retried: r.retried === true, primaryFailed: r.message, empty: mr.empty === true };
      }
      // (30-oct-2026) como en el lote (csh_batch.js mirrorEnd): se saltó el primario solo por la memoria del disco y los espejos no la dan: se le pregunta antes de decir que no hay
      if (r.fromDisk && CC_NET.lastFail && CC_NET.lastFail.fromDisk === true) {
         var r3 = ccHttpTapOnce(adql, key, o);
         if (r3.ok) { CC_NET.downUntil = 0; CC_NET.lastCall = Date.now(); r3.ms += Date.now() - t0; return r3; }
         if (r3.netFail) { r3.fromDisk = false; CC_NET.lastFail = r3; }
         r = r3;
      }
      r.message = String(r.message || "") + (mr.why ? " · mirrors: " + mr.why : "");
      r.ms += Date.now() - t0;
   }
   if (live) CC_NET.lastCall = Date.now();
   return r;
}
function ccHttpTapOnce(adql, key, opts) {
   var o = opts || {}, t0 = Date.now();
   var out = { ok: false, text: "", ms: 0, message: "", cached: false };
   if (CC_ABORT) { out.message = "aborted"; return out; }
   var name = key + "_" + ccHash(adql) + ".csv";
   if (typeof CC_HTTP_HOOK === "function") {
      try { var r = CC_HTTP_HOOK(adql, key, o) || {}; out.ok = !!r.ok; out.text = String(r.text || ""); out.message = String(r.message || ""); out.cached = !!r.cached;
            out.code = r.code || 0; out.host = r.host || "hook"; out.netFail = !out.ok && (r.net === true || !(out.code >= 400 && out.code < 500)); }
      catch (eH) { out.message = String(eH); }
      out.ms = Date.now() - t0;
      return out;
   }
   if (o.replayDir) {
      var fx = ccSlashes(o.replayDir) + "/" + name;
      if (File.exists(fx)) { out.text = File.readTextFile(fx); out.ok = true; out.cached = true; }
      else out.message = "no recorded answer " + name;
      out.ms = Date.now() - t0;
      return out;
   }
   if (!o.refresh) {
      var hit = ccCacheRead(name);
      if (hit !== null) { out.text = hit; out.ok = true; out.cached = true; out.ms = Date.now() - t0; return out; }
   }
   if (o.cacheOnly) { out.message = "not in cache"; out.cacheMiss = true; out.ms = Date.now() - t0; return out; }
   if (!ccHasCurl()) { out.message = "curl not found" + (CC_CURL ? " at " + CC_CURL : " (no curl on this system)"); return out; }
   var tmp = ccSlashes(File.systemTempDirectory) + "/cc_" + Date.now() + "_" + Math.floor(Math.random() * 1e6);
   var qf = tmp + ".adql", of = tmp + ".csv", limitS = (o.timeoutS > 0) ? o.timeoutS : CC_HTTP_TIMEOUT_S, a;
   try {
      File.writeTextFile(qf, adql);
      a = ccAttempt(ccTapArgs(qf, limitS), of, limitS, o);
   } catch (e) {
      a = { ok: false, text: "", code: 0, exit: -1, ms: 0, message: String(e.message || e), aborted: false, kind: "offline", netFail: true, netWhy: "connect" };
   }
   try { if (File.exists(qf)) File.remove(qf); } catch (eQ) {}
   out = ccTapOut(a, key, name);
   out.ms = Date.now() - t0;
   return out;
}
// Los argumentos de curl para UNA consulta TAP (la consulta en el fichero `qf`), sin el fichero de salida.
function ccTapArgs(qf, limitS) {
   var args = [];
   // (F2.2) redirecciones: -L, y --post30x para que el formulario SE REENVÍE (curl cambia a GET en 301/302/303 y perdería la consulta)
   if (!ccBreak("nofollow")) args = ["-L", "--proto", "=https", "--proto-redir", "=https", "--max-redirs", "4", "--post301", "--post302", "--post303"];
   return args.concat(["--connect-timeout", String(ccCdsConnectS()), "-m", String(Math.round(limitS)),
                       "--data-urlencode", "REQUEST=doQuery", "--data-urlencode", "LANG=ADQL", "--data-urlencode", "FORMAT=csv",
                       "--data-urlencode", "QUERY@" + qf, CC_TAP_URL]);
}
// La respuesta de un intento al primario, en la forma de ccHttpTapOnce (y a la caché si es una tabla).
function ccTapOut(a, key, name) {
   var out = { ok: a.ok, text: a.text, ms: a.ms, message: a.message, cached: false, code: a.code, kind: a.kind, aborted: a.aborted };
   out.host = ccTapHost(); out.server = out.host;
   out.netFail = a.netFail; out.netWhy = a.netWhy;
   ccCdsSeen(a);
   if (CC_NET_LOG) CC_NET_LOG.push({ url: CC_TAP_URL, key: key, kind: a.kind || "ok", code: a.code, ms: a.ms, exit: a.exit });
   // Solo se guarda lo que es una tabla (el juicio ya descartó un error de TAP, una página HTML y un cuerpo vacío).
   if (out.ok) ccCacheWrite(name, out.text);
   return out;
}
// (22-oct, noche) Lo que dio un ESPEJO también va a la caché, con la clave de la consulta ADQL: es el MISMO CSV (tests/cc_node_asu.js,
// M 67: 0 celdas distintas salvo 9 de ~100 000 en la última cifra). Antes no se guardaba: con TAPVizieR caído (22-oct, 503 y plazos),
// la «caché llena» volvía a preguntar al espejo cada vez (medido: Abell 39, 20 s con la caché «llena», tests/cc_speed_antes_lleno.log).
// (29-oct, Codex R2 H-1) Una respuesta de espejo VACÍA (solo la cabecera) no se guarda: un espejo puede contestar «0 filas» de paso
// (NAO, 29-oct 07:00: 0 filas de x19 en M 67 frente a 329 a las 12:09) y en la caché, que no caduca, se quedaba para siempre.
function ccCsvRows(csv) { var L = String(csv || "").split("\n"), n = 0; for (var i = 1; i < L.length; ++i) if (L[i].replace(/\r$/, "").length > 0) ++n; return n; }
function ccCacheMirror(adql, key, csv) {
   if (ccBrk("nomirrorcache")) return;
   if (ccCsvRows(csv) === 0 && !ccBrk("cacheempty")) return;
   if (ccCacheGood(csv)) ccCacheWrite(key + "_" + ccHash(adql) + ".csv", csv);
}

// ---------------------------------------------------------------------------
// EL LOTE (22-oct-2026, noche): VARIAS CONSULTAS A LA VEZ. Antes las 12 iban una detrás de otra (cada curl esperaba al anterior:
// Abell 39, 17-20 s; M 67, 38 s; tests/cc_speed_antes_*.log). Aquí cada curl se lanza con ExternalProcess.start (no bloquea) y se
// sondean todos a la vez (waitForFinished corto + señal de vida con onTick, que en la interfaz atiende los eventos).
// Cada consulta recorre LA MISMA CASCADA que ccHttpTap (F2), por pasos y sin bloquear a las demás:
//   caché → primario (TAPVizieR) → si es un fallo pasajero, UN reintento tras 1 s (uno solo para todo el lote: si otra consulta ya
//   está reintentando, se espera a lo que diga, como la serie, en la que tras el primer fallo las demás iban directas al espejo) →
//   si el primario no contesta, el ESPEJO (IDIA y luego CfA, ccAsuPlan), con sus peticiones también a la vez → el fallo, con lo que
//   dijeron los espejos. Las causas (`kind`, `netWhy`, `code`, `host`) y los mensajes son los de ccHttpTap.
// Lo que no tiene red de verdad (el gancho CC_HTTP_HOOK de las pruebas, las respuestas grabadas, sin curl) se queda «perezoso»:
// take() devuelve null y el motor lo pregunta por ccHttpTap, en serie, como siempre (mismas visitas al gancho que antes).
//   ccHttpBatch(items [{ key, adql }], opts { refresh, timeoutS, onTick(ms, info) }) -> {
//     add(items), take(adql, key) -> respuesta (la de ccHttpTap) | null, pending() -> [claves], close() }
// ---------------------------------------------------------------------------
var CC_PAR_MAX = 8;          // curl vivos a la vez como mucho (primario + espejo). Diseño: las 8 consultas que no dependen de otras
                             // (6 surveys + 2 de edades) salen juntas; medido en T14 y tests/cc_speed_despues_*.log.
var CC_PAR_STATS = null;     // el último lote: { t0, maxLive, intervals: [[desde, hasta (ms), clave]], killed, lazy, cached }
var CC_PAR_PROCS = [];       // los curl vivos de TODOS los lotes (al cerrar no puede quedar ninguno)
function ccParLive() {
   var n = 0;
   for (var i = 0; i < CC_PAR_PROCS.length; ++i) { try { if (CC_PAR_PROCS[i].isRunning === true || CC_PAR_PROCS[i].isStarting === true) ++n; } catch (e) {} }
   return n;
}
// ¿Se pisan de verdad? (29-oct-2026 (noche): la cuenta es la COMUN, cshBatchOverlap de ../CabraShared/csh_batch.js)
function ccParOverlap(iv) { return cshBatchOverlap(iv); }
// (29-oct-2026 (noche)) EL LOTE ES EL COMUN: cshVzBatch de ../CabraShared/csh_batch.js (la misma cascada, movida tal cual). Aqui solo lo de
// CabraComposition: su primario (TAPVizieR por POST, ccTapArgs / ccTapOut), su juicio (ccAttemptJudge), su reintento (ccTransient), su
// lista de espejos (CC_ASU_MIRRORS + ccMirrorLacks), su planificador con el poligono (ccAsuPlan), su cache (ccCacheRead / ccCacheMirror),
// su memoria (CC_NET), sus plazos (CC_CONNECT_S, CC_MIRROR_TIMEOUT_S), su rastro (CC_NET_LOG) y sus costuras rojas (serial, nokill,
// acceptempty). CC_PAR_STATS y CC_PAR_PROCS siguen siendo los de siempre (las pruebas T14 los leen).
// Sin csh_batch.js incluido (un principal sin la linea nueva): un lote «perezoso» — take() devuelve null y el motor pregunta en serie.
function ccHttpBatch(items, opts) {
   var o = opts || {}, limitS = (o.timeoutS > 0) ? o.timeoutS : CC_HTTP_TIMEOUT_S;
   var live = (!CC_ABORT && !(o.replayDir) && typeof CC_HTTP_HOOK !== "function" && ccHasCurl()), mirror = live && ccMirrorEligible();
   CC_PAR_STATS = { t0: Date.now(), maxLive: 0, intervals: [], killed: 0, lazy: 0, cached: 0 };
   if (typeof cshVzBatch !== "function") return { add: function() {}, take: function() { return null; }, pending: function() { return []; }, close: function() {} };
   if (live && mirror) ccHealthSeed();
   return cshVzBatch(items, {
      live: live, mirror: mirror, limitS: limitS, max: ccBrk("serial") ? 1 : Math.max(1, (o.max > 0) ? Math.min(o.max, CC_PAR_MAX) : CC_PAR_MAX), noKill: ccBrk("nokill"), stats: CC_PAR_STATS, curl: CC_CURL,
      refresh: o.refresh, onTick: o.onTick, abort: function() { return CC_ABORT === true; },
      onLaunch: function(proc) { CC_PAR_PROCS.push(proc); }, onReap: function(proc) { var k = CC_PAR_PROCS.indexOf(proc); if (k >= 0) CC_PAR_PROCS.splice(k, 1); },
      tmp: function(ext) { return ccSlashes(File.systemTempDirectory) + "/cc_b" + Date.now() + "_" + Math.floor(Math.random() * 1e6) + ext; },
      judge: ccAttemptJudge, primaryArgs: ccTapArgs, primaryOut: function(a, it) { return ccTapOut(a, it.key, it.key + "_" + ccHash(it.adql) + ".csv"); },
      net: CC_NET, downMs: CC_DOWN_MS, transient: ccTransient, retryPauseMs: CC_RETRY_PAUSE_MS,
      mirrors: CC_ASU_MIRRORS, lacks: function(m, adql) { return ccMirrorLacks(m, adql) || (ccMirrorSilent(m, adql) ? "did not answer for this table a moment ago" : false); }, onMirrorSaid: ccMirrorSilentSeen, stallFor: ccMirrorStall,
      plan: function(adql, key) { return ccAsuPlan(adql, key, { poly: CC_NET.poly }); }, requests: ccAsuRequests, build: ccAsuBuild,
      acceptEmpty: function() { return ccBrk("acceptempty"); }, cacheMirror: ccCacheMirror,
      cacheRead: function(it) { return ccCacheRead(it.key + "_" + ccHash(it.adql) + ".csv"); }, note: ccNetNote,
      netLog: function(e) { if (CC_NET_LOG) CC_NET_LOG.push(e); }, connectS: CC_CONNECT_S, mirrorTimeoutS: CC_MIRROR_TIMEOUT_S,
      fanOut: !ccBrk("nofanout"), stallS: ccStallS() });
}

// ---------------------------------------------------------------------------
// LA IMAGEN
// ---------------------------------------------------------------------------
var CC_GAIA_EPOCH_JD = 2457389.0;     // J2016,0 (época de Gaia DR3)
var CC_DEFAULT_EPOCH_JD = 2451545.0;  // J2000: lo que pone la librería si la imagen no tiene fecha

// (comun: ../CabraShared/csh_astrometry.js — con WCS de cualquier tipo NO se llama a ImageSolver)
function ccHasSolution(view) { return cpHasAstrometricSolution(view); }
function ccMetadata(view) {
   if (!ccHasSolution(view) || typeof AstrometricMetadata !== "function") return null;
   var md = null;
   try { md = cshMetadataRead(view); } catch (e) { return null; }
   if (!md || !md.projection) return null;
   if (!md.observationTime) md.observationTime = CC_DEFAULT_EPOCH_JD;   // sin esto, Load lanza (CabraPilot)
   return md;
}
function ccFieldFromView(view) {
   var md = ccMetadata(view);
   if (!md) return { ok: false, code: "no-solution" };
   var w = view.image.width, h = view.image.height;
   // Convert_RD_I da el CENTRO del píxel (i, j) en (i + 0,5; j + 0,5): aquí se trabaja en ese
   // mismo sistema (x de 0 a w), que es el que usa el bitmap de la foto escalado.
   var project = function(ra, dec) {
      try { var q = md.Convert_RD_I(new Point(ra, dec)); return (q && isFinite(q.x) && isFinite(q.y)) ? { x: q.x, y: q.y } : null; } catch (e) { return null; }
   };
   var unproject = function(x, y) {
      try { var q = md.Convert_I_RD(new Point(x, y)); return (q && isFinite(q.x) && isFinite(q.y)) ? { ra: q.x, dec: q.y } : null; } catch (e) { return null; }
   };
   var jd = 0;
   try { jd = Number(md.observationTime); } catch (eJ) {}
   var known = (isFinite(jd) && jd > 0 && jd !== CC_DEFAULT_EPOCH_JD);
   var f = ccFieldFromFunctions(w, h, project, unproject, known ? (jd - CC_GAIA_EPOCH_JD) / 365.25 : 0);
   f.epochKnown = known;
   try { f.scaleArcsec = md.resolution * 3600; } catch (eS) {}
   if (!f.ok) f.code = "no-solution";
   return f;
}
// `interactive` (solo desde la interfaz, por un clic del usuario): si el intento automático
// falla, se abre el diálogo de ImageSolver para que el usuario dé centro, focal y píxel (como
// CabraPilot, cpSolveAstrometry). MEDIDO (tests/cc_solve_probe.log, 14-oct-2026): con un TIFF
// sin metadatos (PLEIADES_STACKED.tif) el intento automático falla en 1,3 s («format(): Invalid
// argument type») sin colgarse; el diálogo NO se ha visto en pantalla (G4 pendiente).
// La receta es la COMUN (../CabraShared/csh_astrometry.js); aqui se traduce a la forma de siempre { ok, message }.
// `interactive` (solo desde la interfaz, por un clic del usuario): si el intento automatico falla, el dialogo de
// ImageSolver. MEDIDO (tests/cc_solve_probe.log, 14-oct-2026): un TIFF sin metadatos falla en 1,3 s sin colgarse.
function ccSolveView(view, interactive) {
   if (ccHasSolution(view)) return { ok: true, message: "already solved" };
   if (typeof ImageSolver !== "function") return { ok: false, message: "the ImageSolver library is not loaded" };
   var r = cshEnsureSolved(view, { dialog: interactive === true });
   if (r.ok) return { ok: true, message: "solved with ImageSolver" };
   if (r.state === "cancelled") return { ok: false, message: "ImageSolver cancelled" };
   var first = r.first || "";
   return { ok: false, message: "ImageSolver found no solution" + (first ? " (" + first + ")" : "") + ": run Script > Astrometry > ImageSolver on the image and press Analyse again." };
}
// ¿Lleva el historial de la vista un SPCC? MEDIDO el 26-oct-2026 con imagenes calibradas de verdad (tests/cc_spcc_probe.log, PixInsight 1.9.5 b1706):
//   · SPCC ejecutado en ESTA sesion: aparece en view.processing (la unica señal que veia el codigo hasta hoy);
//   · un XISF calibrado antes y ABIERTO (el caso de Nino: NGC1514-RGB-MGC-SPCC.xisf, RGB.xisf…): aparece en view.initialProcessing, y NO en
//     view.processing (30 car., vacio) NI en la propiedad PixInsight:ProcessingHistory (view.propertyValue da «»). Con las dos de antes la
//     deteccion decia «sin SPCC» en TODOS sus ficheros (3 de 3 en rojo); el control PCC (WR134 RGB_PCC) y ColorCalibration clasico dan NO bien.
// Se miran las tres. (CabraShared `cshColorStatus` ya miraba initialProcessing: es el mismo criterio, solo SPCC.)
function ccHasSpcc(view) {
   var key = "SpectrophotometricColorCalibration";
   try { if (String(view.propertyValue("PixInsight:ProcessingHistory") || "").indexOf(key) >= 0) return true; } catch (e1) {}
   try { if (String(view.processing.toSource()).indexOf(key) >= 0) return true; } catch (e2) {}
   try { if (String(view.initialProcessing.toSource()).indexOf(key) >= 0) return true; } catch (e3) {}
   return false;
}
// Lo que se sabe de la imagen para aconsejar (sin bloquear): mono, lineal, SPCC.
function ccViewInfo(view) {
   var out = { channels: 1, mono: true, spcc: false, linearGuess: null, median: null };
   try { out.channels = view.image.numberOfChannels; out.mono = (out.channels < 3); } catch (e) {}
   out.spcc = ccHasSpcc(view);
   try { out.median = view.image.median(); out.linearGuess = out.median < 0.08; } catch (e3) {}
   return out;
}

// El auto-STF de PixInsight (AdP/AutoStretch.js; CabraPilot engine/stf.js).
function ccMtf(m, x) {
   if (!(x > 0)) return 0;
   if (x >= 1) return 1;
   if (m === 0.5) return x;
   var den = ((2 * m - 1) * x) - m;
   return Math.abs(den) < 1e-15 ? x : ((m - 1) * x) / den;
}
function ccFindMidtones(v0, v1) {
   if (!(v1 > 0)) return 0;
   if (v1 >= 1) return 1;
   var m0 = (v1 < v0) ? 0 : 0.5, m1 = (v1 < v0) ? 0.5 : 1;
   for (var i = 0; i < 100; ++i) {
      var m = (m0 + m1) / 2, v = ccMtf(m, v1);
      if (Math.abs(v - v0) < 5e-5) return m;
      if (v < v0) m1 = m; else m0 = m;
   }
   return (m0 + m1) / 2;
}
// La foto para el panel A: copia, auto-STF si es lineal (enlazado: conserva el color),
// y reducción por bloques con render(-n) (n <= 128: más tumba PixInsight, CabraBase/pjsr/image-render-reduccion-negativa.md).
function ccPhotoBitmap(view, maxW) {
   var out = { bitmap: null, factor: 1, stretched: false, mono: false, ms: 0 };
   var t0 = Date.now(), src = view.image, w = src.width, h = src.height;
   var n = Math.max(1, Math.min(128, Math.ceil(Math.max(w, h) / (maxW || 2000))));
   var img = new Image;
   try {
      img.assign(src);
      var nc = img.numberOfChannels;
      out.mono = (nc < 3);
      var med = [], mad = [], c;
      // (31-oct-2026) la regla comun (cshPhotoStretchMode, CabraShared/csh_astrometry.js). Antes: media de medianas < 0,08, que dejaba negra una lineal con
      // el cielo alto (Orion, 0,094). El STF de la vista, ESE: la foto sale con los colores del Workspace; ya estirada, tal cual.
      var sMode = cshPhotoStretchMode(view), vStf = (sMode === "view") ? cshViewStf(view, nc) : null;
      if (vStf) {
         var idv = [0.0, 0.5, 1.0, 0.0, 1.0], rv = [];
         for (c = 0; c < vStf.length; ++c) rv.push([vStf[c].c0, vStf[c].m, vStf[c].c1, vStf[c].r0, vStf[c].r1]);
         var htv = new HistogramTransformation;
         htv.H = (nc >= 3) ? [rv[0], rv[1], rv[2], idv, idv] : [idv, idv, idv, rv[0], idv];
         out.stretched = (htv.executeOn(img) !== false);
      } else if (sMode !== "none") {
         // Sin calibrar, NO enlazado: cada canal el suyo. Enlazado, una HSO de banda estrecha (Abell 39) salía con el
         // fondo granate (visto en la primera captura del 14-oct-2026). Con SPCC, enlazado: conserva su equilibrio.
         for (c = 0; c < Math.min(nc, 3); ++c) { img.selectedChannel = c; med.push(img.median()); mad.push(1.4826 * img.MAD()); }
         img.resetSelections();
         var auto = cshAutoStfRows(med, mad, sMode === "mad-linked"), rows = [], id = [0.0, 0.5, 1.0, 0.0, 1.0];
         for (c = 0; c < auto.length; ++c) rows.push([auto[c].c0, auto[c].m, 1.0, 0.0, 1.0]);
         var ht = new HistogramTransformation;
         ht.H = (nc >= 3) ? [rows[0], rows[1], rows[2], id, id] : [id, id, id, rows[0], id];
         out.stretched = (ht.executeOn(img) !== false);
      }
      out.bitmap = img.render(-n, false);
      out.factor = 1 / n;
   } finally {
      try { img.free(); } catch (eF) {}
   }
   out.ms = Date.now() - t0;
   return out;
}

// Ajustes recordados (Settings, clave propia). Lo escrito llega a disco al cerrar PixInsight.
var CC_SETTINGS = "CabraComposition";
function ccSettingRead(key, type, dflt) {
   try { var v = Settings.read(CC_SETTINGS + "/" + key, type); if (Settings.lastReadOK && v !== null && v !== undefined) return v; } catch (e) {}
   return dflt;
}
function ccSettingWrite(key, type, value) { try { Settings.write(CC_SETTINGS + "/" + key, type, value); } catch (e) {} }
