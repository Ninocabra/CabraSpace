#engine v8
// ============================================================================
// CabraComposition.js — ARQUEOLOGÍA QUÍMICA GALÁCTICA de una imagen (CabraScripts)
// ----------------------------------------------------------------------------
// No solo «qué estrella es», sino «de qué generación de la Galaxia forma parte»:
// para cada estrella de la foto con espectroscopía (Gaia DR3, GALAH DR4, APOGEE
// DR17, LAMOST), su [Fe/H], su [α/Fe] y demás abundancias, su edad con su
// incertidumbre, su población probable (disco fino / grueso / halo) y de qué
// survey sale cada dato. La foto y tres diagramas enlazados (α–Fe, edad–Fe, familias
// cinemáticas), la ficha de la elegida, la línea de tiempo de la Vía Láctea y familias químicas compatibles.
//
// Script INDEPENDIENTE: no necesita CabraPilot. Lo reutilizado se copió y se
// adaptó (procedencia en la cabecera de cada fichero de src/).
// Uso, estado y límites: README.md, HANDOFF.md y docs/.
// ============================================================================

#feature-id    StellarChemistry : CabraSpace > StellarChemistry
#feature-icon  @script_icons_dir/StellarChemistry.svg
#feature-info  StellarChemistry (formerly CabraComposition): galactic chemical archaeology of the stars in your image \
               (Gaia DR3, GALAH DR4, APOGEE DR17, LAMOST). CabraSpace project.

// Cabeceras de #define puros (inocuas bajo V8; Sizer.jsh NO: declara clases nativas).
#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/ColorSpace.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/PenStyle.jsh>
#include <pjsr/BrushStyle.jsh>
#include <pjsr/ButtonCodes.jsh>
#include <pjsr/UndoFlag.jsh>
#define Align_Expand  0
#define Align_Left    1
#define Align_Top     1
#define Align_Right   2
#define Align_Bottom  2
#define Align_Center  3

// La librería ImageSolver como LIBRERÍA (da AstrometricMetadata e ImageSolver sin su
// main). Igual que CabraPilot.js (rama integracion-1410c). OJO: define las macros
// VERSION y TITLE: ningún identificador de este script puede llamarse así.
#define SETTINGS_MODULE "ImageSolver"
#ifndef STAR_CSV_FILE
#define STAR_CSV_FILE (File.systemTempDirectory + format("/cc-stars-%03d.csv", CoreApplication.instance))
#endif
#define USE_SOLVER_LIBRARY
#include <../src/scripts/ImageSolver/ImageSolver.js>
#undef USE_SOLVER_LIBRARY

#ifndef CC_NO_MAIN
#define CC_NO_MAIN 0
#endif

// CabraShared (la biblioteca comun de CabraScripts): red, astrometria, Gaia local, Atlas, cierre
#include "CabraShared/csh_i18n.js"
#include "CabraShared/csh_atlas.js"
#include "CabraShared/csh_net.js"
#include "CabraShared/csh_vizier.js"       // (29-oct-2026) el motor de VizieR por los espejos ASU, uno para todos (docs/motor-vizier-unico.md)
#include "CabraShared/csh_batch.js"         // (29-oct-2026) el lote: varias descargas a la vez, para todos los scripts
#include "CabraShared/csh_web.js"           // (3-nov-2026, CPD) los enlaces de la ficha y la ayuda se abren en el navegador que trae PixInsight (Dialog.openBrowser); Aladin (WebGL) y la reserva, en el del sistema de cada plataforma
#include "CabraShared/csh_link.js"          // (26-oct-2026) abrir SIMBAD desde el nombre de la ficha (cc_paint.js ccLinkOfStar)
#include "CabraShared/csh_hipnames.js"      // (27-oct-2026) el catálogo Hipparcos y sus nombres: la ficha dice «Alcyone» como Cabra3D (cc_paint.js ccHipFill)
// (F2.1, 22-oct-2026: csh_netfail.js solo por el JUICIO de una respuesta, cshNfJudge; no se usan sus cortacircuitos ni su caché)
#include "CabraShared/csh_netfail.js"
#include "CabraShared/csh_astrometry.js"
#include "CabraShared/csh_gaia.js"
#include "CabraShared/csh_close.js"
#include "CabraShared/csh_pills.js"         // (30-oct-2026) el conmutador «Real photo | Stars» de dos pildoras, comun a los cuatro scripts
#include "CabraShared/csh_viewpref.js"      // (30-oct-2026) y su eleccion recordada entre sesiones (arranca en «Real photo»), comun a los cuatro
#include "CabraShared/csh_busy.js"           // (29-oct-2026) el relojito de «estoy pensando» sobre la foto 2D, comun a los cuatro scripts
// (24-oct-2026: el reloj analógico de los vídeos de II y III, puro; lo usan cc_journey_paint.js y cc_galaxy_ui.js)
#include "CabraShared/csh_clock.js"
#include "CabraShared/help/csh_help.js"      // (2-nov-2026) el boton «?» de la ayuda PIDoc (StellarChemistry / StellarChemistry_es), comun a todos

#include "CabraShared/csh_kinpop.js"   // (29-oct-2026) poblacion cinematica unica: Schonrich 2010 + Bensby 2014 + Juric (R4 H-2)
#include "src/cc_science.js"
#include "src/cc_dynamics.js"
#include "src/cc_story.js"
#include "src/cc_catalogs.js"
#include "src/cc_field.js"
#include "src/cc_engine.js"
#include "src/data/cc_reference.js"
#include "src/data/cc_reference_elements.js"
#include "src/cc_i18n.js"
#include "src/cc_pixinsight.js"
#include "src/cc_gaialocal.js"
#include "src/ui/cc_atlas.js"
#include "src/ui/cc_paint.js"
#include "src/ui/cc_frame.js"      // (el armazón común con CabraStars/Cabra3D; CabraStarAnalysis no lo incluye)
// II · VIAJE Y VÍDEO (fase 2a: los modos, el fotograma, LA grabadora —una sola, también para «Órbitas»— y sus mandos)
#include "src/ui/cc_journey_i18n.js"
#include "CabraShared/csh_ffmpeg.js"       // (3-nov-2026, CPD SC3) ffmpeg solo si el usuario lo elige: AVI (de fabrica) / el que elijo / buscalo tu
#include "src/ui/cc_journey_avi.js"
#include "src/ui/cc_journey.js"
#include "src/ui/cc_journey_paint.js"
#include "src/ui/cc_journey_video.js"
#include "src/ui/cc_journey_ui.js"
// III · LA GALAXIA (fase 2b: el modelo de las órbitas, el mapa, sus mandos y el fotograma del vídeo «Órbitas»)
#include "src/ui/cc_galaxy_i18n.js"
#include "src/ui/cc_galaxy.js"
#include "src/ui/cc_galaxy_paint.js"
#include "src/ui/cc_galaxy_ui.js"
// (los ganchos D.mountJourney / D.mountGalaxy de cc_dialog.js llaman a ccJourneyMount / ccGalaxyMount si existen: CabraStarAnalysis,
//  que no incluye nada de lo de arriba, sigue compilando sin ellos)
#include "src/ui/cc_dialog.js"

var CC_APP_VERSION = "0.3.1";

function ccMain() {
   cshNetLiveOn();                     // (30-oct-2026) las memorias de red en disco de csh_net.js: solo el script de verdad, no las pruebas
   try { console.show(); } catch (e) {}
   console.writeln("<b>StellarChemistry " + CC_APP_VERSION + "</b> — galactic chemical archaeology");
   var D = new CCDialog;
   D.execute();
   // al volver de execute() (aspa, Esc o «Cerrar»): nada queda vivo (tampoco una grabación de II ni la animación de III)
   try { D.timer.stop(); } catch (e2) {}
   try { if (D.endVideo) D.endVideo(); } catch (e2b) {}
   try { D.release(); } catch (e3) {}
   CC_ABORT = false;
   console.writeln("StellarChemistry: closed (" + (D.closedHow || "window") + ")");
   // (sin gc(): obsoleto en PixInsight 1.9.5, avisa «gc() is deprecated» y no hace nada bajo V8; no hay forma vigente que lo sustituya. 24-oct-2026)
}

if (!CC_NO_MAIN) ccMain();
